#### CLASS AdsPosition parent= int
#   field value__                        int                                                off=0x10 attr=606 
#   field Bottom                         AdsPosition                                        off=0x0 attr=8056 
#   field Centered                       AdsPosition                                        off=0x0 attr=8056 
#   field Left                           AdsPosition                                        off=0x0 attr=8056 
#   field Right                          AdsPosition                                        off=0x0 attr=8056 
#   field Custom                         AdsPosition                                        off=0x0 attr=8056 
