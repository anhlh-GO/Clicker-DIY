#### CLASS DreamHouse.ScreenInGame/<>c parent= object
#   field <>9                            DreamHouse.ScreenInGame/<>c                        off=0x0 attr=36 
#   field <>9__18_0                      System.Action                                      off=0x8 attr=16 
## .cctor() -> void
---- DreamHouse.ScreenInGame/<>c::.cctor 0x2d1d1ec
02d1d1ec: str     x30, [sp, #-0x20]!                         
02d1d1f0: stp     x20, x19, [sp, #0x10]                      
02d1d1f4: adrp    x19, #0x6630000                            
02d1d1f8: adrp    x20, #0x6269000                            
02d1d1fc: ldrb    w8, [x19, #0x25]                           
02d1d200: ldr     x20, [x20, #0xc78]                         T:DreamHouse.ScreenInGame/<>c
02d1d204: tbnz    w8, #0, #0x2d1d21c                         
02d1d208: adrp    x0, #0x6269000                             
02d1d20c: ldr     x0, [x0, #0xc78]                           T:DreamHouse.ScreenInGame/<>c
02d1d210: bl      #0x2b70db0                                 fn_2b70db0
02d1d214: mov     w8, #1                                     
02d1d218: strb    w8, [x19, #0x25]                           
02d1d21c: ldr     x0, [x20]                                  T:Trading.TradingSession/<>c__DisplayClass56_0
02d1d220: bl      #0x2b7104c                                 fn_2b7104c
02d1d224: mov     x1, xzr                                    
02d1d228: mov     x19, x0                                    
02d1d22c: bl      #0x4e53e9c                                 System.Object::.ctor
02d1d230: ldr     x8, [x20]                                  T:Trading.TradingSession/<>c__DisplayClass56_0
02d1d234: mov     x1, x19                                    
02d1d238: ldr     x8, [x8, #0xb8]                            
02d1d23c: str     x19, [x8]                                  
02d1d240: ldr     x8, [x20]                                  T:Trading.TradingSession/<>c__DisplayClass56_0
02d1d244: ldp     x20, x19, [sp, #0x10]                      
02d1d248: ldr     x0, [x8, #0xb8]                            
02d1d24c: ldr     x30, [sp], #0x20                           
02d1d250: b       #0x2b70d54                                 
## .ctor() -> void
---- DreamHouse.ScreenInGame/<>c::.ctor 0x2d1d254
02d1d254: mov     x1, xzr                                    
02d1d258: b       #0x4e53e9c                                 System.Object::.ctor
## <OnBackButtonClicked>b__18_0() -> void
---- DreamHouse.ScreenInGame/<>c::<OnBackButtonClicked>b__18_0 0x2d1d25c
02d1d25c: ret                                                
#### CLASS DreamHouse.ScreenInGame parent= ScreenBase
#   field _backButton                    UnityEngine.UI.Button                              off=0x38 attr=1 SerializeField
#   field _doneButton                    UnityEngine.UI.Button                              off=0x40 attr=1 SerializeField
#   field _listHomeButton                UnityEngine.UI.Button                              off=0x48 attr=1 SerializeField
#   field _progressBar                   DreamHouse.ProgressBar                             off=0x50 attr=1 SerializeField
#   field _decorItemPanel                DreamHouse.DecorItemPanel                          off=0x58 attr=1 SerializeField
#   field PrefKey_RateUsShown            string                                             off=0x0 attr=8051 
## get_DecorItemPanel() -> DreamHouse.DecorItemPanel
---- DreamHouse.ScreenInGame::get_DecorItemPanel 0x2d1c764
02d1c764: ldr     x0, [x0, #0x58]                            ._decorItemPanel
02d1c768: ret                                                
## OnDestroy() -> void
---- DreamHouse.ScreenInGame::OnDestroy 0x2d1c76c
02d1c76c: stp     x30, x23, [sp, #-0x30]!                    
02d1c770: stp     x22, x21, [sp, #0x10]                      
02d1c774: stp     x20, x19, [sp, #0x20]                      
02d1c778: adrp    x20, #0x6630000                            
02d1c77c: mov     x19, x0                                    
02d1c780: ldrb    w8, [x20, #0x1a]                           
02d1c784: tbnz    w8, #0, #0x2d1c7cc                         
02d1c788: adrp    x0, #0x6269000                             
02d1c78c: ldr     x0, [x0, #0xc40]                           M:DreamHouse.ScreenInGame::OnBackButtonClicked
02d1c790: bl      #0x2b70db0                                 fn_2b70db0
02d1c794: adrp    x0, #0x6269000                             
02d1c798: ldr     x0, [x0, #0xc48]                           M:DreamHouse.ScreenInGame::OnDoneButtonClicked
02d1c79c: bl      #0x2b70db0                                 fn_2b70db0
02d1c7a0: adrp    x0, #0x6269000                             
02d1c7a4: ldr     x0, [x0, #0xc50]                           M:DreamHouse.ScreenInGame::OnListHomeButtonClicked
02d1c7a8: bl      #0x2b70db0                                 fn_2b70db0
02d1c7ac: adrp    x0, #0x6269000                             
02d1c7b0: ldr     x0, [x0, #0xc58]                           M:DreamHouse.ScreenInGame::OnRoomInitializedCallback
02d1c7b4: bl      #0x2b70db0                                 fn_2b70db0
02d1c7b8: adrp    x0, #0x6265000                             
02d1c7bc: ldr     x0, [x0, #0x3f0]                           T:UnityEngine.Events.UnityAction
02d1c7c0: bl      #0x2b70db0                                 fn_2b70db0
02d1c7c4: mov     w8, #1                                     
02d1c7c8: strb    w8, [x20, #0x1a]                           
02d1c7cc: ldr     x8, [x19, #0x38]                           ._backButton
02d1c7d0: cbz     x8, #0x2d1c8dc                             
02d1c7d4: adrp    x22, #0x6265000                            
02d1c7d8: adrp    x21, #0x6269000                            
02d1c7dc: ldr     x22, [x22, #0x3f0]                         T:UnityEngine.Events.UnityAction
02d1c7e0: ldr     x21, [x21, #0xc40]                         M:DreamHouse.ScreenInGame::OnBackButtonClicked
02d1c7e4: ldr     x20, [x8, #0x100]                          
02d1c7e8: ldr     x0, [x22]                                  M:AdsManager::<OnApplicationPause>b__26_0
02d1c7ec: bl      #0x2b7104c                                 fn_2b7104c
02d1c7f0: ldr     x2, [x21]                                  T:Trading.TradingSession/<>c__DisplayClass56_0
02d1c7f4: mov     x1, x19                                    
02d1c7f8: mov     x3, xzr                                    
02d1c7fc: mov     x21, x0                                    
02d1c800: bl      #0x5b4cf98                                 UnityEngine.Events.UnityAction::.ctor
02d1c804: cbz     x20, #0x2d1c8dc                            
02d1c808: mov     x0, x20                                    
02d1c80c: mov     x1, x21                                    
02d1c810: mov     x2, xzr                                    
02d1c814: bl      #0x5b4d13c                                 UnityEngine.Events.UnityEvent::RemoveListener
02d1c818: ldr     x8, [x19, #0x40]                           ._doneButton
02d1c81c: cbz     x8, #0x2d1c8dc                             
02d1c820: adrp    x21, #0x6269000                            
02d1c824: ldr     x21, [x21, #0xc48]                         M:DreamHouse.ScreenInGame::OnDoneButtonClicked
02d1c828: ldr     x0, [x22]                                  M:AdsManager::<OnApplicationPause>b__26_0
02d1c82c: ldr     x20, [x8, #0x100]                          
02d1c830: bl      #0x2b7104c                                 fn_2b7104c
02d1c834: ldr     x2, [x21]                                  T:Trading.TradingSession/<>c__DisplayClass56_0
02d1c838: mov     x1, x19                                    
02d1c83c: mov     x3, xzr                                    
02d1c840: mov     x21, x0                                    
02d1c844: bl      #0x5b4cf98                                 UnityEngine.Events.UnityAction::.ctor
02d1c848: cbz     x20, #0x2d1c8dc                            
02d1c84c: mov     x0, x20                                    
02d1c850: mov     x1, x21                                    
02d1c854: mov     x2, xzr                                    
02d1c858: bl      #0x5b4d13c                                 UnityEngine.Events.UnityEvent::RemoveListener
02d1c85c: ldr     x8, [x19, #0x48]                           ._listHomeButton
02d1c860: cbz     x8, #0x2d1c8dc                             
02d1c864: adrp    x21, #0x6269000                            
02d1c868: ldr     x21, [x21, #0xc50]                         M:DreamHouse.ScreenInGame::OnListHomeButtonClicked
02d1c86c: ldr     x0, [x22]                                  M:AdsManager::<OnApplicationPause>b__26_0
02d1c870: ldr     x20, [x8, #0x100]                          
02d1c874: bl      #0x2b7104c                                 fn_2b7104c
02d1c878: ldr     x2, [x21]                                  T:Trading.TradingSession/<>c__DisplayClass56_0
02d1c87c: mov     x1, x19                                    
02d1c880: mov     x3, xzr                                    
02d1c884: mov     x21, x0                                    
02d1c888: bl      #0x5b4cf98                                 UnityEngine.Events.UnityAction::.ctor
02d1c88c: cbz     x20, #0x2d1c8dc                            
02d1c890: adrp    x23, #0x6269000                            
02d1c894: mov     x0, x20                                    
02d1c898: mov     x1, x21                                    
02d1c89c: ldr     x23, [x23, #0xc58]                         M:DreamHouse.ScreenInGame::OnRoomInitializedCallback
02d1c8a0: mov     x2, xzr                                    
02d1c8a4: bl      #0x5b4d13c                                 UnityEngine.Events.UnityEvent::RemoveListener
02d1c8a8: ldr     x0, [x22]                                  M:AdsManager::<OnApplicationPause>b__26_0
02d1c8ac: bl      #0x2b7104c                                 fn_2b7104c
02d1c8b0: ldr     x2, [x23]                                  T:Trading.TradingSession/<>c__DisplayClass56_0
02d1c8b4: mov     x1, x19                                    
02d1c8b8: mov     x3, xzr                                    
02d1c8bc: mov     x20, x0                                    
02d1c8c0: bl      #0x5b4cf98                                 UnityEngine.Events.UnityAction::.ctor
02d1c8c4: mov     x0, x20                                    
02d1c8c8: ldp     x20, x19, [sp, #0x20]                      
02d1c8cc: ldp     x22, x21, [sp, #0x10]                      
02d1c8d0: mov     x1, xzr                                    
02d1c8d4: ldp     x30, x23, [sp], #0x30                      
02d1c8d8: b       #0x2d187ac                                 DreamHouse.RoomController::remove_OnInitialized
02d1c8dc: bl      #0x2b7105c                                 fn_2b7105c
## OnInit(UIManager uiManager) -> void
---- DreamHouse.ScreenInGame::OnInit 0x2d1c8e0
02d1c8e0: stp     x30, x23, [sp, #-0x30]!                    
02d1c8e4: stp     x22, x21, [sp, #0x10]                      
02d1c8e8: stp     x20, x19, [sp, #0x20]                      
02d1c8ec: adrp    x21, #0x6630000                            
02d1c8f0: mov     x20, x1                                    
02d1c8f4: mov     x19, x0                                    
02d1c8f8: ldrb    w8, [x21, #0x1b]                           
02d1c8fc: tbnz    w8, #0, #0x2d1c944                         
02d1c900: adrp    x0, #0x6269000                             
02d1c904: ldr     x0, [x0, #0xc40]                           M:DreamHouse.ScreenInGame::OnBackButtonClicked
02d1c908: bl      #0x2b70db0                                 fn_2b70db0
02d1c90c: adrp    x0, #0x6269000                             
02d1c910: ldr     x0, [x0, #0xc48]                           M:DreamHouse.ScreenInGame::OnDoneButtonClicked
02d1c914: bl      #0x2b70db0                                 fn_2b70db0
02d1c918: adrp    x0, #0x6269000                             
02d1c91c: ldr     x0, [x0, #0xc50]                           M:DreamHouse.ScreenInGame::OnListHomeButtonClicked
02d1c920: bl      #0x2b70db0                                 fn_2b70db0
02d1c924: adrp    x0, #0x6269000                             
02d1c928: ldr     x0, [x0, #0xc58]                           M:DreamHouse.ScreenInGame::OnRoomInitializedCallback
02d1c92c: bl      #0x2b70db0                                 fn_2b70db0
02d1c930: adrp    x0, #0x6265000                             
02d1c934: ldr     x0, [x0, #0x3f0]                           T:UnityEngine.Events.UnityAction
02d1c938: bl      #0x2b70db0                                 fn_2b70db0
02d1c93c: mov     w8, #1                                     
02d1c940: strb    w8, [x21, #0x1b]                           
02d1c944: mov     x0, x19                                    
02d1c948: mov     x1, x20                                    
02d1c94c: mov     x2, xzr                                    
02d1c950: bl      #0x2cdd3c4                                 UIBase::OnInit
02d1c954: ldr     x8, [x19, #0x38]                           ._backButton
02d1c958: cbz     x8, #0x2d1ca70                             
02d1c95c: adrp    x22, #0x6265000                            
02d1c960: adrp    x21, #0x6269000                            
02d1c964: ldr     x22, [x22, #0x3f0]                         T:UnityEngine.Events.UnityAction
02d1c968: ldr     x21, [x21, #0xc40]                         M:DreamHouse.ScreenInGame::OnBackButtonClicked
02d1c96c: ldr     x20, [x8, #0x100]                          
02d1c970: ldr     x0, [x22]                                  M:AdsManager::<OnApplicationPause>b__26_0
02d1c974: bl      #0x2b7104c                                 fn_2b7104c
02d1c978: ldr     x2, [x21]                                  T:Trading.TradingSession/<>c__DisplayClass56_0
02d1c97c: mov     x1, x19                                    
02d1c980: mov     x3, xzr                                    
02d1c984: mov     x21, x0                                    
02d1c988: bl      #0x5b4cf98                                 UnityEngine.Events.UnityAction::.ctor
02d1c98c: cbz     x20, #0x2d1ca70                            
02d1c990: mov     x0, x20                                    
02d1c994: mov     x1, x21                                    
02d1c998: mov     x2, xzr                                    
02d1c99c: bl      #0x5b4d0ac                                 UnityEngine.Events.UnityEvent::AddListener
02d1c9a0: ldr     x8, [x19, #0x40]                           ._doneButton
02d1c9a4: cbz     x8, #0x2d1ca70                             
02d1c9a8: adrp    x21, #0x6269000                            
02d1c9ac: ldr     x21, [x21, #0xc48]                         M:DreamHouse.ScreenInGame::OnDoneButtonClicked
02d1c9b0: ldr     x0, [x22]                                  M:AdsManager::<OnApplicationPause>b__26_0
02d1c9b4: ldr     x20, [x8, #0x100]                          
02d1c9b8: bl      #0x2b7104c                                 fn_2b7104c
02d1c9bc: ldr     x2, [x21]                                  T:Trading.TradingSession/<>c__DisplayClass56_0
02d1c9c0: mov     x1, x19                                    
02d1c9c4: mov     x3, xzr                                    
02d1c9c8: mov     x21, x0                                    
02d1c9cc: bl      #0x5b4cf98                                 UnityEngine.Events.UnityAction::.ctor
02d1c9d0: cbz     x20, #0x2d1ca70                            
02d1c9d4: mov     x0, x20                                    
02d1c9d8: mov     x1, x21                                    
02d1c9dc: mov     x2, xzr                                    
02d1c9e0: bl      #0x5b4d0ac                                 UnityEngine.Events.UnityEvent::AddListener
02d1c9e4: ldr     x8, [x19, #0x48]                           ._listHomeButton
02d1c9e8: cbz     x8, #0x2d1ca70                             
02d1c9ec: adrp    x21, #0x6269000                            
02d1c9f0: ldr     x21, [x21, #0xc50]                         M:DreamHouse.ScreenInGame::OnListHomeButtonClicked
02d1c9f4: ldr     x0, [x22]                                  M:AdsManager::<OnApplicationPause>b__26_0
02d1c9f8: ldr     x20, [x8, #0x100]                          
02d1c9fc: bl      #0x2b7104c                                 fn_2b7104c
02d1ca00: ldr     x2, [x21]                                  T:Trading.TradingSession/<>c__DisplayClass56_0
02d1ca04: mov     x1, x19                                    
02d1ca08: mov     x3, xzr                                    
02d1ca0c: mov     x21, x0                                    
02d1ca10: bl      #0x5b4cf98                                 UnityEngine.Events.UnityAction::.ctor
02d1ca14: cbz     x20, #0x2d1ca70                            
02d1ca18: adrp    x23, #0x6269000                            
02d1ca1c: mov     x0, x20                                    
02d1ca20: mov     x1, x21                                    
02d1ca24: ldr     x23, [x23, #0xc58]                         M:DreamHouse.ScreenInGame::OnRoomInitializedCallback
02d1ca28: mov     x2, xzr                                    
02d1ca2c: bl      #0x5b4d0ac                                 UnityEngine.Events.UnityEvent::AddListener
02d1ca30: ldr     x0, [x22]                                  M:AdsManager::<OnApplicationPause>b__26_0
02d1ca34: bl      #0x2b7104c                                 fn_2b7104c
02d1ca38: ldr     x2, [x23]                                  T:Trading.TradingSession/<>c__DisplayClass56_0
02d1ca3c: mov     x1, x19                                    
02d1ca40: mov     x3, xzr                                    
02d1ca44: mov     x20, x0                                    
02d1ca48: bl      #0x5b4cf98                                 UnityEngine.Events.UnityAction::.ctor
02d1ca4c: mov     x0, x20                                    
02d1ca50: mov     x1, xzr                                    
02d1ca54: bl      #0x2d186f4                                 DreamHouse.RoomController::add_OnInitialized
02d1ca58: ldr     x0, [x19, #0x58]                           ._decorItemPanel
02d1ca5c: cbz     x0, #0x2d1ca70                             
02d1ca60: ldp     x20, x19, [sp, #0x20]                      
02d1ca64: ldp     x22, x21, [sp, #0x10]                      
02d1ca68: ldp     x30, x23, [sp], #0x30                      
02d1ca6c: b       #0x2d199cc                                 DreamHouse.DecorItemPanel::OnInit
02d1ca70: bl      #0x2b7105c                                 fn_2b7105c
## OnShow() -> void
---- DreamHouse.ScreenInGame::OnShow 0x2d1ca74
02d1ca74: stp     x30, x21, [sp, #-0x20]!                    
02d1ca78: stp     x20, x19, [sp, #0x10]                      
02d1ca7c: adrp    x21, #0x6630000                            
02d1ca80: adrp    x20, #0x6265000                            
02d1ca84: mov     x19, x0                                    
02d1ca88: ldrb    w8, [x21, #0x1c]                           
02d1ca8c: ldr     x20, [x20, #0x310]                         MS:WejoyService.Singleton`1::get_Instance
02d1ca90: tbnz    w8, #0, #0x2d1caa8                         
02d1ca94: adrp    x0, #0x6265000                             
02d1ca98: ldr     x0, [x0, #0x310]                           MS:WejoyService.Singleton`1::get_Instance
02d1ca9c: bl      #0x2b70db0                                 fn_2b70db0
02d1caa0: mov     w8, #1                                     
02d1caa4: strb    w8, [x21, #0x1c]                           
02d1caa8: mov     x0, x19                                    
02d1caac: mov     x1, xzr                                    
02d1cab0: bl      #0x2cdd6b8                                 UIBase::OnShow
02d1cab4: ldr     x0, [x20]                                  M:AdsManager::<OnApplicationPause>b__26_0
02d1cab8: bl      #0x3be7218                                 fn_3be7218
02d1cabc: cbz     x0, #0x2d1cad4                             
02d1cac0: mov     x1, xzr                                    
02d1cac4: bl      #0x2c8a7a4                                 AdsManager::ShowCollap
02d1cac8: ldp     x20, x19, [sp, #0x10]                      
02d1cacc: ldp     x30, x21, [sp], #0x20                      
02d1cad0: b       #0x2d1c1c8                                 DreamHouse.ScreenInGame::CheckShowBtnBack
02d1cad4: bl      #0x2b7105c                                 fn_2b7105c
## CheckShowBtnBack() -> void
---- DreamHouse.ScreenInGame::CheckShowBtnBack 0x2d1c1c8
02d1c1c8: str     x30, [sp, #-0x20]!                         
02d1c1cc: stp     x20, x19, [sp, #0x10]                      
02d1c1d0: adrp    x19, #0x6630000                            
02d1c1d4: adrp    x20, #0x6266000                            
02d1c1d8: ldrb    w8, [x19, #0x1d]                           
02d1c1dc: ldr     x20, [x20, #0x658]                         MS:MonoSingleton`1::get_Instance
02d1c1e0: tbnz    w8, #0, #0x2d1c204                         
02d1c1e4: adrp    x0, #0x6266000                             
02d1c1e8: ldr     x0, [x0, #0x750]                           MS:DataManager::GetData
02d1c1ec: bl      #0x2b70db0                                 fn_2b70db0
02d1c1f0: adrp    x0, #0x6266000                             
02d1c1f4: ldr     x0, [x0, #0x658]                           MS:MonoSingleton`1::get_Instance
02d1c1f8: bl      #0x2b70db0                                 fn_2b70db0
02d1c1fc: mov     w8, #1                                     
02d1c200: strb    w8, [x19, #0x1d]                           
02d1c204: ldr     x0, [x20]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d1c208: bl      #0x3769600                                 fn_3769600
02d1c20c: cbz     x0, #0x2d1c228                             
02d1c210: adrp    x8, #0x6266000                             
02d1c214: ldr     x8, [x8, #0x750]                           MS:DataManager::GetData
02d1c218: ldp     x20, x19, [sp, #0x10]                      
02d1c21c: ldr     x1, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d1c220: ldr     x30, [sp], #0x20                           
02d1c224: b       #0x3168dd0                                 
02d1c228: bl      #0x2b7105c                                 fn_2b7105c
## OnRoomInitializedCallback() -> void
---- DreamHouse.ScreenInGame::OnRoomInitializedCallback 0x2d1cad8
02d1cad8: str     x30, [sp, #-0x50]!                         
02d1cadc: stp     x26, x25, [sp, #0x10]                      
02d1cae0: stp     x24, x23, [sp, #0x20]                      
02d1cae4: stp     x22, x21, [sp, #0x30]                      
02d1cae8: stp     x20, x19, [sp, #0x40]                      
02d1caec: adrp    x20, #0x6630000                            
02d1caf0: mov     x19, x0                                    
02d1caf4: ldrb    w8, [x20, #0x1e]                           
02d1caf8: tbnz    w8, #0, #0x2d1cb40                         
02d1cafc: adrp    x0, #0x6269000                             
02d1cb00: ldr     x0, [x0, #0xac0]                           MS:MonoSingleton`1::get_Instance
02d1cb04: bl      #0x2b70db0                                 fn_2b70db0
02d1cb08: adrp    x0, #0x6269000                             
02d1cb0c: ldr     x0, [x0, #0xc60]                           M:DreamHouse.ScreenInGame::OnRoomCompletedCallback
02d1cb10: bl      #0x2b70db0                                 fn_2b70db0
02d1cb14: adrp    x0, #0x6269000                             
02d1cb18: ldr     x0, [x0, #0xc68]                           M:DreamHouse.ScreenInGame::OnStepChangedCallback
02d1cb1c: bl      #0x2b70db0                                 fn_2b70db0
02d1cb20: adrp    x0, #0x6269000                             
02d1cb24: ldr     x0, [x0, #0xa68]                           T:type19683(k15)
02d1cb28: bl      #0x2b70db0                                 fn_2b70db0
02d1cb2c: adrp    x0, #0x6265000                             
02d1cb30: ldr     x0, [x0, #0x3f0]                           T:UnityEngine.Events.UnityAction
02d1cb34: bl      #0x2b70db0                                 fn_2b70db0
02d1cb38: mov     w8, #1                                     
02d1cb3c: strb    w8, [x20, #0x1e]                           
02d1cb40: ldr     x0, [x19, #0x40]                           ._doneButton
02d1cb44: cbz     x0, #0x2d1cc74                             
02d1cb48: mov     x1, xzr                                    
02d1cb4c: bl      #0x5b339ec                                 UnityEngine.Component::get_gameObject
02d1cb50: cbz     x0, #0x2d1cc74                             
02d1cb54: mov     w1, wzr                                    
02d1cb58: mov     x2, xzr                                    
02d1cb5c: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d1cb60: ldr     x20, [x19, #0x58]                          ._decorItemPanel
02d1cb64: cbz     x20, #0x2d1cc74                            
02d1cb68: movi    d0, #0000000000000000                      
02d1cb6c: adrp    x21, #0x6269000                            
02d1cb70: mov     w1, wzr                                    
02d1cb74: ldr     x21, [x21, #0xac0]                         MS:MonoSingleton`1::get_Instance
02d1cb78: ldr     x0, [x20, #0x20]                           
02d1cb7c: mov     x2, xzr                                    
02d1cb80: bl      #0x2cf1928                                 FrameWorkUtility::SetActive
02d1cb84: str     xzr, [x20, #0x48]!                         ._listHomeButton
02d1cb88: mov     x0, x20                                    
02d1cb8c: mov     x1, xzr                                    
02d1cb90: bl      #0x2b70d54                                 fn_2b70d54
02d1cb94: ldr     x0, [x21]                                  T:Trading.TradingSession/<>c__DisplayClass56_0
02d1cb98: bl      #0x3769600                                 fn_3769600
02d1cb9c: cbz     x0, #0x2d1cc74                             
02d1cba0: ldr     x20, [x0, #0x40]                           S:'done_ad' ._doneButton
02d1cba4: cbz     x20, #0x2d1cc74                            
02d1cba8: ldr     x0, [x20, #0x40]                           ._doneButton
02d1cbac: cbz     x0, #0x2d1cc74                             
02d1cbb0: ldr     x21, [x19, #0x50]                          ._progressBar
02d1cbb4: ldr     w22, [x20, #0x48]                          ._listHomeButton
02d1cbb8: mov     x1, xzr                                    
02d1cbbc: bl      #0x2d15c30                                 DreamHouse.RoomConfig::GetDecorItemAssetCount
02d1cbc0: cbz     x21, #0x2d1cc74                            
02d1cbc4: adrp    x23, #0x6269000                            
02d1cbc8: adrp    x24, #0x6269000                            
02d1cbcc: adrp    x25, #0x6265000                            
02d1cbd0: adrp    x26, #0x6269000                            
02d1cbd4: ldr     x23, [x23, #0xa68]                         T:type19683(k15)
02d1cbd8: ldr     x24, [x24, #0xc68]                         M:DreamHouse.ScreenInGame::OnStepChangedCallback
02d1cbdc: ldr     x25, [x25, #0x3f0]                         T:UnityEngine.Events.UnityAction
02d1cbe0: ldr     x26, [x26, #0xc60]                         M:DreamHouse.ScreenInGame::OnRoomCompletedCallback
02d1cbe4: str     w0, [x21, #0x30]                           
02d1cbe8: mov     x0, x21                                    
02d1cbec: mov     w1, #1                                     
02d1cbf0: bl      #0x2d1c4c0                                 DreamHouse.ProgressBar::SetActive
02d1cbf4: mov     x0, x21                                    
02d1cbf8: mov     w1, w22                                    
02d1cbfc: bl      #0x2d1c528                                 DreamHouse.ProgressBar::SetProgressValue
02d1cc00: ldr     x0, [x23]                                  T:Trading.TradingSession/<>c__DisplayClass56_0
02d1cc04: bl      #0x2b7104c                                 fn_2b7104c
02d1cc08: ldr     x2, [x24]                                  T:Trading.TradingSession/<>c__DisplayClass56_0
02d1cc0c: mov     x1, x19                                    
02d1cc10: mov     x3, xzr                                    
02d1cc14: mov     x21, x0                                    
02d1cc18: bl      #0x3edf86c                                 fn_3edf86c
02d1cc1c: mov     x0, x20                                    
02d1cc20: mov     x1, x21                                    
02d1cc24: mov     x2, xzr                                    
02d1cc28: bl      #0x2d18864                                 DreamHouse.RoomController::add_OnStepChanged
02d1cc2c: ldr     x0, [x25]                                  M:AdsManager::<OnApplicationPause>b__26_0
02d1cc30: bl      #0x2b7104c                                 fn_2b7104c
02d1cc34: ldr     x2, [x26]                                  T:Trading.TradingSession/<>c__DisplayClass56_0
02d1cc38: mov     x1, x19                                    
02d1cc3c: mov     x3, xzr                                    
02d1cc40: mov     x21, x0                                    
02d1cc44: bl      #0x5b4cf98                                 UnityEngine.Events.UnityAction::.ctor
02d1cc48: mov     x0, x20                                    
02d1cc4c: mov     x1, x21                                    
02d1cc50: mov     x2, xzr                                    
02d1cc54: bl      #0x2d189c4                                 DreamHouse.RoomController::add_OnRoomCompleted
02d1cc58: mov     x0, x19                                    
02d1cc5c: ldp     x20, x19, [sp, #0x40]                      
02d1cc60: ldp     x22, x21, [sp, #0x30]                      
02d1cc64: ldp     x24, x23, [sp, #0x20]                      
02d1cc68: ldp     x26, x25, [sp, #0x10]                      
02d1cc6c: ldr     x30, [sp], #0x50                           
02d1cc70: b       #0x2d1cc78                                 DreamHouse.ScreenInGame::CheckShowButtonListHome
02d1cc74: bl      #0x2b7105c                                 fn_2b7105c
## OnStepChangedCallback(int currentStep) -> void
---- DreamHouse.ScreenInGame::OnStepChangedCallback 0x2d1cd00
02d1cd00: ldr     x0, [x0, #0x50]                            ._progressBar
02d1cd04: cbz     x0, #0x2d1cd14                             
02d1cd08: adrp    x8, #0x1084000                             
02d1cd0c: ldr     s0, [x8, #0xf10]                           [1084f10]=4110bc863e99999a f=0.3,9.04603
02d1cd10: b       #0x2d1c608                                 DreamHouse.ProgressBar::DoProgressValue
02d1cd14: str     x30, [sp, #-0x10]!                         
02d1cd18: bl      #0x2b7105c                                 fn_2b7105c
## OnRoomCompletedCallback() -> void
---- DreamHouse.ScreenInGame::OnRoomCompletedCallback 0x2d1cd1c
02d1cd1c: str     x30, [sp, #-0x10]!                         
02d1cd20: ldr     x0, [x0, #0x40]                            ._doneButton
02d1cd24: cbz     x0, #0x2d1cd44                             
02d1cd28: mov     x1, xzr                                    
02d1cd2c: bl      #0x5b339ec                                 UnityEngine.Component::get_gameObject
02d1cd30: cbz     x0, #0x2d1cd44                             
02d1cd34: mov     w1, #1                                     
02d1cd38: mov     x2, xzr                                    
02d1cd3c: ldr     x30, [sp], #0x10                           
02d1cd40: b       #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d1cd44: bl      #0x2b7105c                                 fn_2b7105c
## CheckShowButtonListHome() -> void
---- DreamHouse.ScreenInGame::CheckShowButtonListHome 0x2d1cc78
02d1cc78: stp     x30, x21, [sp, #-0x20]!                    
02d1cc7c: stp     x20, x19, [sp, #0x10]                      
02d1cc80: adrp    x20, #0x6630000                            
02d1cc84: adrp    x21, #0x6266000                            
02d1cc88: mov     x19, x0                                    
02d1cc8c: ldrb    w8, [x20, #0x1f]                           
02d1cc90: ldr     x21, [x21, #0x658]                         MS:MonoSingleton`1::get_Instance
02d1cc94: tbnz    w8, #0, #0x2d1ccb8                         
02d1cc98: adrp    x0, #0x6269000                             
02d1cc9c: ldr     x0, [x0, #0x9e8]                           MS:DataManager::GetData
02d1cca0: bl      #0x2b70db0                                 fn_2b70db0
02d1cca4: adrp    x0, #0x6266000                             
02d1cca8: ldr     x0, [x0, #0x658]                           MS:MonoSingleton`1::get_Instance
02d1ccac: bl      #0x2b70db0                                 fn_2b70db0
02d1ccb0: mov     w8, #1                                     
02d1ccb4: strb    w8, [x20, #0x1f]                           
02d1ccb8: ldr     x0, [x21]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d1ccbc: bl      #0x3769600                                 fn_3769600
02d1ccc0: cbz     x0, #0x2d1ccfc                             
02d1ccc4: adrp    x8, #0x6269000                             
02d1ccc8: ldr     x8, [x8, #0x9e8]                           MS:DataManager::GetData
02d1cccc: ldr     x1, [x8]                                   T:Trading.TradingSession/<>c__DisplayClass56_0
02d1ccd0: bl      #0x3168dd0                                 fn_3168dd0
02d1ccd4: ldr     x0, [x19, #0x48]                           ._listHomeButton
02d1ccd8: cbz     x0, #0x2d1ccfc                             
02d1ccdc: mov     x1, xzr                                    
02d1cce0: bl      #0x5b339ec                                 UnityEngine.Component::get_gameObject
02d1cce4: cbz     x0, #0x2d1ccfc                             
02d1cce8: ldp     x20, x19, [sp, #0x10]                      
02d1ccec: mov     w1, #1                                     
02d1ccf0: mov     x2, xzr                                    
02d1ccf4: ldp     x30, x21, [sp], #0x20                      
02d1ccf8: b       #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d1ccfc: bl      #0x2b7105c                                 fn_2b7105c
## get_RateUsShown() -> bool
---- DreamHouse.ScreenInGame::get_RateUsShown 0x2d1cd48
02d1cd48: str     x30, [sp, #-0x20]!                         
02d1cd4c: stp     x20, x19, [sp, #0x10]                      
02d1cd50: adrp    x19, #0x6630000                            
02d1cd54: adrp    x20, #0x6266000                            
02d1cd58: ldrb    w8, [x19, #0x20]                           
02d1cd5c: ldr     x20, [x20, #0xab0]                         S:'RateUsShown'
02d1cd60: tbnz    w8, #0, #0x2d1cd78                         
02d1cd64: adrp    x0, #0x6266000                             
02d1cd68: ldr     x0, [x0, #0xab0]                           S:'RateUsShown'
02d1cd6c: bl      #0x2b70db0                                 fn_2b70db0
02d1cd70: mov     w8, #1                                     
02d1cd74: strb    w8, [x19, #0x20]                           
02d1cd78: ldr     x0, [x20]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d1cd7c: mov     w1, wzr                                    
02d1cd80: mov     x2, xzr                                    
02d1cd84: bl      #0x5b2d1dc                                 UnityEngine.PlayerPrefs::GetInt
02d1cd88: ldp     x20, x19, [sp, #0x10]                      
02d1cd8c: cmp     w0, #1                                     
02d1cd90: cset    w0, eq                                     
02d1cd94: ldr     x30, [sp], #0x20                           
02d1cd98: ret                                                
## OnBackButtonClicked() -> void
---- DreamHouse.ScreenInGame::OnBackButtonClicked 0x2d1cd9c
02d1cd9c: stp     x30, x23, [sp, #-0x30]!                    
02d1cda0: stp     x22, x21, [sp, #0x10]                      
02d1cda4: stp     x20, x19, [sp, #0x20]                      
02d1cda8: adrp    x19, #0x6630000                            
02d1cdac: ldrb    w8, [x19, #0x21]                           
02d1cdb0: tbnz    w8, #0, #0x2d1ce10                         
02d1cdb4: adrp    x0, #0x6264000                             
02d1cdb8: ldr     x0, [x0, #0xf90]                           T:System.Action
02d1cdbc: bl      #0x2b70db0                                 fn_2b70db0
02d1cdc0: adrp    x0, #0x6266000                             
02d1cdc4: ldr     x0, [x0, #0x5e0]                           T:GameConfig
02d1cdc8: bl      #0x2b70db0                                 fn_2b70db0
02d1cdcc: adrp    x0, #0x6265000                             
02d1cdd0: ldr     x0, [x0, #0x10]                            MS:MonoSingleton`1::get_Instance
02d1cdd4: bl      #0x2b70db0                                 fn_2b70db0
02d1cdd8: adrp    x0, #0x6265000                             
02d1cddc: ldr     x0, [x0, #0x310]                           MS:WejoyService.Singleton`1::get_Instance
02d1cde0: bl      #0x2b70db0                                 fn_2b70db0
02d1cde4: adrp    x0, #0x6269000                             
02d1cde8: ldr     x0, [x0, #0xc70]                           M:DreamHouse.ScreenInGame/<>c::<OnBackButtonClicked>b__18_0
02d1cdec: bl      #0x2b70db0                                 fn_2b70db0
02d1cdf0: adrp    x0, #0x6269000                             
02d1cdf4: ldr     x0, [x0, #0xc78]                           T:DreamHouse.ScreenInGame/<>c
02d1cdf8: bl      #0x2b70db0                                 fn_2b70db0
02d1cdfc: adrp    x0, #0x6269000                             
02d1ce00: ldr     x0, [x0, #0xc80]                           S:'back_decor'
02d1ce04: bl      #0x2b70db0                                 fn_2b70db0
02d1ce08: mov     w8, #1                                     
02d1ce0c: strb    w8, [x19, #0x21]                           
02d1ce10: mov     x0, xzr                                    
02d1ce14: bl      #0x2d6eec8                                 Framework.AudioManager::get_Instance
02d1ce18: cbz     x0, #0x2d1cf74                             
02d1ce1c: movi    d1, #0000000000000000                      
02d1ce20: movi    d2, #0000000000000000                      
02d1ce24: adrp    x19, #0x6265000                            
02d1ce28: fmov    s0, #1.00000000                            
02d1ce2c: adrp    x23, #0x6269000                            
02d1ce30: adrp    x20, #0x6269000                            
02d1ce34: ldr     x19, [x19, #0x310]                         MS:WejoyService.Singleton`1::get_Instance
02d1ce38: ldr     x23, [x23, #0xc78]                         T:DreamHouse.ScreenInGame/<>c
02d1ce3c: ldr     x20, [x20, #0xc80]                         S:'back_decor'
02d1ce40: mov     w1, #1                                     
02d1ce44: mov     w2, wzr                                    
02d1ce48: mov     w3, wzr                                    
02d1ce4c: mov     x4, xzr                                    
02d1ce50: bl      #0x2d6f03c                                 Framework.AudioManager::PlaySound
02d1ce54: ldr     x0, [x19]                                  M:AdsManager::<OnApplicationPause>b__26_0
02d1ce58: bl      #0x3be7218                                 fn_3be7218
02d1ce5c: ldr     x8, [x23]                                  T:Trading.TradingSession/<>c__DisplayClass56_0
02d1ce60: mov     x19, x0                                    
02d1ce64: ldr     w9, [x8, #0xe4]                            
02d1ce68: cbnz    w9, #0x2d1ce78                             
02d1ce6c: mov     x0, x8                                     
02d1ce70: bl      #0x2b70f30                                 fn_2b70f30
02d1ce74: ldr     x8, [x23]                                  T:Trading.TradingSession/<>c__DisplayClass56_0
02d1ce78: ldr     x9, [x8, #0xb8]                            
02d1ce7c: ldr     x20, [x20]                                 T:Trading.TradingSession/<>c__DisplayClass56_0
02d1ce80: ldr     x21, [x9, #8]                              
02d1ce84: cbnz    x21, #0x2d1cee4                            
02d1ce88: ldr     w10, [x8, #0xe4]                           
02d1ce8c: cbnz    w10, #0x2d1cea0                            
02d1ce90: mov     x0, x8                                     
02d1ce94: bl      #0x2b70f30                                 fn_2b70f30
02d1ce98: ldr     x8, [x23]                                  T:Trading.TradingSession/<>c__DisplayClass56_0
02d1ce9c: ldr     x9, [x8, #0xb8]                            
02d1cea0: adrp    x8, #0x6264000                             
02d1cea4: ldr     x8, [x8, #0xf90]                           T:System.Action
02d1cea8: ldr     x22, [x9]                                  
02d1ceac: ldr     x0, [x8]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d1ceb0: bl      #0x2b7104c                                 fn_2b7104c
02d1ceb4: adrp    x8, #0x6269000                             
02d1ceb8: mov     x1, x22                                    
02d1cebc: mov     x3, xzr                                    
02d1cec0: ldr     x8, [x8, #0xc70]                           M:DreamHouse.ScreenInGame/<>c::<OnBackButtonClicked>b__18_0
02d1cec4: mov     x21, x0                                    
02d1cec8: ldr     x2, [x8]                                   T:Trading.TradingSession/<>c__DisplayClass56_0
02d1cecc: bl      #0x4d8ddbc                                 System.Action::.ctor
02d1ced0: ldr     x8, [x23]                                  T:Trading.TradingSession/<>c__DisplayClass56_0
02d1ced4: mov     x1, x21                                    
02d1ced8: ldr     x0, [x8, #0xb8]                            T:Trading.TradingSession/<>c__DisplayClass68_0
02d1cedc: str     x21, [x0, #8]!                             
02d1cee0: bl      #0x2b70d54                                 fn_2b70d54
02d1cee4: cbz     x19, #0x2d1cf74                            
02d1cee8: adrp    x23, #0x6265000                            
02d1ceec: adrp    x22, #0x6266000                            
02d1cef0: mov     x0, x19                                    
02d1cef4: ldr     x23, [x23, #0x10]                          MS:MonoSingleton`1::get_Instance
02d1cef8: ldr     x22, [x22, #0x5e0]                         T:GameConfig
02d1cefc: mov     x1, x20                                    
02d1cf00: mov     x2, x21                                    
02d1cf04: mov     w3, #1                                     
02d1cf08: mov     x4, xzr                                    
02d1cf0c: bl      #0x2c89698                                 AdsManager::ShowInter
02d1cf10: bl      #0x2d1cd48                                 DreamHouse.ScreenInGame::get_RateUsShown
02d1cf14: ldr     x8, [x23]                                  M:AdsManager::<OnApplicationPause>b__26_0
02d1cf18: mov     w20, w0                                    
02d1cf1c: mov     x0, x8                                     
02d1cf20: bl      #0x3769600                                 fn_3769600
02d1cf24: ldr     x8, [x22]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d1cf28: mov     x19, x0                                    
02d1cf2c: ldr     w9, [x8, #0xe4]                            [62690e4]=0 f=0,0
02d1cf30: tbz     w20, #0, #0x2d1cf6c                        
02d1cf34: cbnz    w9, #0x2d1cf40                             
02d1cf38: mov     x0, x8                                     
02d1cf3c: bl      #0x2b70f30                                 fn_2b70f30
02d1cf40: cbz     x19, #0x2d1cf74                            
02d1cf44: ldr     x8, [x22]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d1cf48: mov     x0, x19                                    
02d1cf4c: mov     w2, #1                                     
02d1cf50: ldp     x20, x19, [sp, #0x20]                      
02d1cf54: mov     x3, xzr                                    
02d1cf58: ldr     x8, [x8, #0xb8]                            T:Trading.TradingSession/<>c__DisplayClass68_0
02d1cf5c: ldp     x22, x21, [sp, #0x10]                      
02d1cf60: ldr     x1, [x8, #8]                               MS:System.Collections.Generic.List`1::RemoveAll
02d1cf64: ldp     x30, x23, [sp], #0x30                      
02d1cf68: b       #0x2ce9e58                                 SimpleSceneTransition::FlashIn
02d1cf6c: cbz     w9, #0x2d1cf78                             
02d1cf70: cbnz    x19, #0x2d1cf44                            
02d1cf74: bl      #0x2b7105c                                 fn_2b7105c
02d1cf78: mov     x0, x8                                     
02d1cf7c: bl      #0x2b70f30                                 fn_2b70f30
02d1cf80: cbnz    x19, #0x2d1cf44                            
02d1cf84: b       #0x2d1cf74                                 
## OnDoneButtonClicked() -> void
---- DreamHouse.ScreenInGame::OnDoneButtonClicked 0x2d1cf88
02d1cf88: str     x30, [sp, #-0x30]!                         
02d1cf8c: stp     x22, x21, [sp, #0x10]                      
02d1cf90: stp     x20, x19, [sp, #0x20]                      
02d1cf94: adrp    x20, #0x6630000                            
02d1cf98: mov     x19, x0                                    
02d1cf9c: ldrb    w8, [x20, #0x22]                           
02d1cfa0: tbnz    w8, #0, #0x2d1cfdc                         
02d1cfa4: adrp    x0, #0x6264000                             
02d1cfa8: ldr     x0, [x0, #0xf90]                           T:System.Action
02d1cfac: bl      #0x2b70db0                                 fn_2b70db0
02d1cfb0: adrp    x0, #0x6269000                             
02d1cfb4: ldr     x0, [x0, #0xc88]                           M:DreamHouse.ScreenInGame::<OnDoneButtonClicked>b__19_0
02d1cfb8: bl      #0x2b70db0                                 fn_2b70db0
02d1cfbc: adrp    x0, #0x6265000                             
02d1cfc0: ldr     x0, [x0, #0x310]                           MS:WejoyService.Singleton`1::get_Instance
02d1cfc4: bl      #0x2b70db0                                 fn_2b70db0
02d1cfc8: adrp    x0, #0x6269000                             
02d1cfcc: ldr     x0, [x0, #0xc90]                           S:'done_decor'
02d1cfd0: bl      #0x2b70db0                                 fn_2b70db0
02d1cfd4: mov     w8, #1                                     
02d1cfd8: strb    w8, [x20, #0x22]                           
02d1cfdc: mov     x0, xzr                                    
02d1cfe0: bl      #0x2d6eec8                                 Framework.AudioManager::get_Instance
02d1cfe4: cbz     x0, #0x2d1d07c                             
02d1cfe8: movi    d1, #0000000000000000                      
02d1cfec: movi    d2, #0000000000000000                      
02d1cff0: adrp    x20, #0x6265000                            
02d1cff4: fmov    s0, #1.00000000                            
02d1cff8: adrp    x21, #0x6264000                            
02d1cffc: adrp    x22, #0x6269000                            
02d1d000: ldr     x20, [x20, #0x310]                         MS:WejoyService.Singleton`1::get_Instance
02d1d004: ldr     x21, [x21, #0xf90]                         T:System.Action
02d1d008: b       #0x5e8fff4                                 
02d1d00c: mov     w1, #1                                     
02d1d010: mov     w2, wzr                                    
02d1d014: mov     w3, wzr                                    
02d1d018: mov     x4, xzr                                    
02d1d01c: bl      #0x2d6f03c                                 Framework.AudioManager::PlaySound
02d1d020: ldr     x0, [x20]                                  M:AdsManager::<OnApplicationPause>b__26_0
02d1d024: bl      #0x3be7218                                 fn_3be7218
02d1d028: ldr     x8, [x21]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d1d02c: mov     x20, x0                                    
02d1d030: mov     x0, x8                                     
02d1d034: bl      #0x2b7104c                                 fn_2b7104c
02d1d038: ldr     x2, [x22]                                  T:Trading.TradingSession/<>c__DisplayClass56_0
02d1d03c: mov     x1, x19                                    
02d1d040: mov     x3, xzr                                    
02d1d044: mov     x21, x0                                    
02d1d048: bl      #0x4d8ddbc                                 System.Action::.ctor
02d1d04c: cbz     x20, #0x2d1d07c                            
02d1d050: adrp    x8, #0x6269000                             
02d1d054: mov     x0, x20                                    
02d1d058: mov     x2, x21                                    
02d1d05c: ldr     x8, [x8, #0xc90]                           S:'done_decor'
02d1d060: ldp     x20, x19, [sp, #0x20]                      
02d1d064: ldp     x22, x21, [sp, #0x10]                      
02d1d068: mov     w3, #1                                     
02d1d06c: ldr     x1, [x8]                                   T:Trading.TradingSession/<>c__DisplayClass56_0
02d1d070: mov     x4, xzr                                    
02d1d074: ldr     x30, [sp], #0x30                           
02d1d078: b       #0x2c89698                                 AdsManager::ShowInter
02d1d07c: bl      #0x2b7105c                                 fn_2b7105c
## OnListHomeButtonClicked() -> void
---- DreamHouse.ScreenInGame::OnListHomeButtonClicked 0x2d1d080
02d1d080: str     x30, [sp, #-0x20]!                         
02d1d084: stp     x20, x19, [sp, #0x10]                      
02d1d088: adrp    x20, #0x6630000                            
02d1d08c: mov     x19, x0                                    
02d1d090: ldrb    w8, [x20, #0x23]                           
02d1d094: tbnz    w8, #0, #0x2d1d0ac                         
02d1d098: adrp    x0, #0x6269000                             
02d1d09c: ldr     x0, [x0, #0xc98]                           MS:UIManager::ShowPopup
02d1d0a0: bl      #0x2b70db0                                 fn_2b70db0
02d1d0a4: mov     w8, #1                                     
02d1d0a8: strb    w8, [x20, #0x23]                           
02d1d0ac: mov     x0, xzr                                    
02d1d0b0: bl      #0x2d6eec8                                 Framework.AudioManager::get_Instance
02d1d0b4: cbz     x0, #0x2d1d0f8                             
02d1d0b8: movi    d1, #0000000000000000                      
02d1d0bc: movi    d2, #0000000000000000                      
02d1d0c0: mov     w1, #1                                     
02d1d0c4: fmov    s0, #1.00000000                            
02d1d0c8: mov     w2, wzr                                    
02d1d0cc: mov     w3, wzr                                    
02d1d0d0: mov     x4, xzr                                    
02d1d0d4: bl      #0x2d6f03c                                 Framework.AudioManager::PlaySound
02d1d0d8: ldr     x0, [x19, #0x30]                           
02d1d0dc: cbz     x0, #0x2d1d0f8                             
02d1d0e0: adrp    x8, #0x6269000                             
02d1d0e4: ldr     x8, [x8, #0xc98]                           MS:UIManager::ShowPopup
02d1d0e8: ldp     x20, x19, [sp, #0x10]                      
02d1d0ec: ldr     x1, [x8]                                   T:Trading.TradingSession/<>c__DisplayClass56_0
02d1d0f0: ldr     x30, [sp], #0x20                           
02d1d0f4: b       #0x33fbfac                                 
02d1d0f8: bl      #0x2b7105c                                 fn_2b7105c
## .ctor() -> void
---- DreamHouse.ScreenInGame::.ctor 0x2d1d0fc
02d1d0fc: mov     x1, xzr                                    
02d1d100: b       #0x2cde678                                 ScreenBase::.ctor
## <OnDoneButtonClicked>b__19_0() -> void
---- DreamHouse.ScreenInGame::<OnDoneButtonClicked>b__19_0 0x2d1d104
02d1d104: stp     x30, x21, [sp, #-0x20]!                    
02d1d108: stp     x20, x19, [sp, #0x10]                      
02d1d10c: adrp    x20, #0x6630000                            
02d1d110: adrp    x21, #0x6269000                            
02d1d114: mov     x19, x0                                    
02d1d118: ldrb    w8, [x20, #0x24]                           
02d1d11c: ldr     x21, [x21, #0xac0]                         MS:MonoSingleton`1::get_Instance
02d1d120: tbnz    w8, #0, #0x2d1d15c                         
02d1d124: adrp    x0, #0x6266000                             
02d1d128: ldr     x0, [x0, #0x5e0]                           T:GameConfig
02d1d12c: bl      #0x2b70db0                                 fn_2b70db0
02d1d130: adrp    x0, #0x6269000                             
02d1d134: ldr     x0, [x0, #0xac0]                           MS:MonoSingleton`1::get_Instance
02d1d138: bl      #0x2b70db0                                 fn_2b70db0
02d1d13c: adrp    x0, #0x6265000                             
02d1d140: ldr     x0, [x0, #0x10]                            MS:MonoSingleton`1::get_Instance
02d1d144: bl      #0x2b70db0                                 fn_2b70db0
02d1d148: adrp    x0, #0x6269000                             
02d1d14c: ldr     x0, [x0, #0xca0]                           MS:UIManager::ShowPopup
02d1d150: bl      #0x2b70db0                                 fn_2b70db0
02d1d154: mov     w8, #1                                     
02d1d158: strb    w8, [x20, #0x24]                           
02d1d15c: ldr     x0, [x21]                                  T:Trading.TradingSession/<>c__DisplayClass56_0
02d1d160: bl      #0x3769600                                 fn_3769600
02d1d164: cbz     x0, #0x2d1d1e8                             
02d1d168: ldrb    w8, [x0, #0x50]                            ._progressBar
02d1d16c: cbz     w8, #0x2d1d1c8                             
02d1d170: adrp    x8, #0x6265000                             
02d1d174: adrp    x20, #0x6266000                            
02d1d178: ldr     x8, [x8, #0x10]                            MS:MonoSingleton`1::get_Instance
02d1d17c: ldr     x20, [x20, #0x5e0]                         T:GameConfig
02d1d180: ldr     x0, [x8]                                   M:AdsManager::<OnApplicationPause>b__26_0
02d1d184: bl      #0x3769600                                 fn_3769600
02d1d188: ldr     x8, [x20]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d1d18c: mov     x19, x0                                    
02d1d190: ldr     w9, [x8, #0xe4]                            [62650e4]=0 f=0,0
02d1d194: cbnz    w9, #0x2d1d1a0                             
02d1d198: mov     x0, x8                                     
02d1d19c: bl      #0x2b70f30                                 fn_2b70f30
02d1d1a0: cbz     x19, #0x2d1d1e8                            
02d1d1a4: ldr     x8, [x20]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d1d1a8: mov     x0, x19                                    
02d1d1ac: mov     w2, #1                                     
02d1d1b0: ldp     x20, x19, [sp, #0x10]                      
02d1d1b4: mov     x3, xzr                                    
02d1d1b8: ldr     x8, [x8, #0xb8]                            T:AdsManager/<>c__DisplayClass42_0
02d1d1bc: ldr     x1, [x8, #8]                               M:AdsManager::<OnApplicationPause>b__26_1
02d1d1c0: ldp     x30, x21, [sp], #0x20                      
02d1d1c4: b       #0x2ce9e58                                 SimpleSceneTransition::FlashIn
02d1d1c8: ldr     x0, [x19, #0x30]                           
02d1d1cc: cbz     x0, #0x2d1d1e8                             
02d1d1d0: adrp    x8, #0x6269000                             
02d1d1d4: ldr     x8, [x8, #0xca0]                           MS:UIManager::ShowPopup
02d1d1d8: ldp     x20, x19, [sp, #0x10]                      
02d1d1dc: ldr     x1, [x8]                                   T:Trading.TradingSession/<>c__DisplayClass56_0
02d1d1e0: ldp     x30, x21, [sp], #0x20                      
02d1d1e4: b       #0x33fbfac                                 
02d1d1e8: bl      #0x2b7105c                                 fn_2b7105c
