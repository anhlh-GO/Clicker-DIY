#### CLASS ClickerSaveDataItem parent= object
#   field Index                          int                                                off=0x10 attr=6 
#   field BaseKeycapId                   int                                                off=0x14 attr=6 
#   field SwitchId                       int                                                off=0x18 attr=6 
#   field KeycapId                       int                                                off=0x1c attr=6 
#   field KeycapColorId                  int                                                off=0x20 attr=6 
#   field KeychainId                     int                                                off=0x24 attr=6 
#   field DecorIdList                    System.Collections.Generic.List`1<int>             off=0x28 attr=6 
#   field Value                          int                                                off=0x30 attr=6 
## .ctor(int index, int baseKeycapId, int switchId, int keycapId, int keycapColorId, int keychainId, System.Collections.Generic.List`1<int> decorIdList) -> void
---- ClickerSaveDataItem::.ctor 0x2ca8b68
02ca8b68: str     x30, [sp, #-0x50]!                         
02ca8b6c: stp     x26, x25, [sp, #0x10]                      
02ca8b70: stp     x24, x23, [sp, #0x20]                      
02ca8b74: stp     x22, x21, [sp, #0x30]                      
02ca8b78: stp     x20, x19, [sp, #0x40]                      
02ca8b7c: mov     w25, w1                                    
02ca8b80: mov     x1, xzr                                    
02ca8b84: mov     x19, x7                                    
02ca8b88: mov     w20, w6                                    
02ca8b8c: mov     w21, w5                                    
02ca8b90: mov     w22, w4                                    
02ca8b94: mov     w23, w3                                    
02ca8b98: mov     w24, w2                                    
02ca8b9c: mov     x26, x0                                    
02ca8ba0: bl      #0x4e53e9c                                 System.Object::.ctor
02ca8ba4: str     x19, [x26, #0x28]!                         
02ca8ba8: mov     x0, x26                                    
02ca8bac: stp     w25, w24, [x26, #-0x18]                    
02ca8bb0: mov     x1, x19                                    
02ca8bb4: stp     w23, w22, [x26, #-0x10]                    
02ca8bb8: ldp     x24, x23, [sp, #0x20]                      
02ca8bbc: stp     w21, w20, [x26, #-8]                       
02ca8bc0: ldp     x20, x19, [sp, #0x40]                      
02ca8bc4: ldp     x22, x21, [sp, #0x30]                      
02ca8bc8: ldp     x26, x25, [sp, #0x10]                      
02ca8bcc: ldr     x30, [sp], #0x50                           
02ca8bd0: b       #0x2b70d54                                 
## .ctor() -> void
---- ClickerSaveDataItem::.ctor 0x2ca8bd4
02ca8bd4: str     x30, [sp, #-0x30]!                         
02ca8bd8: stp     x22, x21, [sp, #0x10]                      
02ca8bdc: stp     x20, x19, [sp, #0x20]                      
02ca8be0: adrp    x22, #0x662f000                            
02ca8be4: adrp    x21, #0x6266000                            
02ca8be8: adrp    x20, #0x6266000                            
02ca8bec: ldrb    w8, [x22, #0xb02]                          
02ca8bf0: ldr     x21, [x21, #0x648]                         T:type15061(k15)
02ca8bf4: ldr     x20, [x20, #0x650]                         MS:System.Collections.Generic.List`1::.ctor
02ca8bf8: mov     x19, x0                                    
02ca8bfc: tbnz    w8, #0, #0x2ca8c20                         
02ca8c00: adrp    x0, #0x6266000                             
02ca8c04: ldr     x0, [x0, #0x650]                           MS:System.Collections.Generic.List`1::.ctor
02ca8c08: bl      #0x2b70db0                                 fn_2b70db0
02ca8c0c: adrp    x0, #0x6266000                             
02ca8c10: ldr     x0, [x0, #0x648]                           T:type15061(k15)
02ca8c14: bl      #0x2b70db0                                 fn_2b70db0
02ca8c18: mov     w8, #1                                     
02ca8c1c: strb    w8, [x22, #0xb02]                          
02ca8c20: mov     x0, x19                                    
02ca8c24: mov     x1, xzr                                    
02ca8c28: bl      #0x4e53e9c                                 System.Object::.ctor
02ca8c2c: ldr     x0, [x21]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca8c30: stp     xzr, xzr, [x19, #0x10]                     .Index
02ca8c34: str     xzr, [x19, #0x20]                          .KeycapColorId
02ca8c38: bl      #0x2b7104c                                 fn_2b7104c
02ca8c3c: ldr     x1, [x20]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca8c40: mov     x20, x0                                    
02ca8c44: bl      #0x3569388                                 fn_3569388
02ca8c48: str     x20, [x19, #0x28]!                         .DecorIdList
02ca8c4c: mov     x0, x19                                    
02ca8c50: mov     x1, x20                                    
02ca8c54: ldp     x20, x19, [sp, #0x20]                      
02ca8c58: ldp     x22, x21, [sp, #0x10]                      
02ca8c5c: ldr     x30, [sp], #0x30                           
02ca8c60: b       #0x2b70d54                                 
