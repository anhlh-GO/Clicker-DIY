#### CLASS Clicker.SwitchUIItem parent= Clicker.ClickerUIItem
## OnSelected(bool isSelected) -> void
---- Clicker.SwitchUIItem::OnSelected 0x2d74798
02d74798: mov     x2, xzr                                    
02d7479c: b       #0x2d664a8                                 Clicker.ClickerUIItem::OnSelected
## PlayClickSound() -> void
---- Clicker.SwitchUIItem::PlayClickSound 0x2d747a0
02d747a0: ret                                                
## .ctor() -> void
---- Clicker.SwitchUIItem::.ctor 0x2d747a4
02d747a4: mov     x1, xzr                                    
02d747a8: b       #0x2d664b4                                 Clicker.ClickerUIItem::.ctor
