#### CLASS ScoopGame.BlindBagVisualAsset/<>c__DisplayClass1_0 parent= object
#   field id                             int                                                off=0x10 attr=6 
## .ctor() -> void
---- ScoopGame.BlindBagVisualAsset/<>c__DisplayClass1_0::.ctor 0x2d423d8
02d423d8: mov     x1, xzr                                    
02d423dc: b       #0x4e53e9c                                 System.Object::.ctor
## <GetData>b__0(ScoopGame.BlindBagVisualDataItem x) -> bool
---- ScoopGame.BlindBagVisualAsset/<>c__DisplayClass1_0::<GetData>b__0 0x2d423f0
02d423f0: cbz     x1, #0x2d42408                             
02d423f4: ldr     w8, [x1, #0x10]                            
02d423f8: ldr     w9, [x0, #0x10]                            .id
02d423fc: cmp     w8, w9                                     
02d42400: cset    w0, eq                                     
02d42404: ret                                                
02d42408: str     x30, [sp, #-0x10]!                         
02d4240c: bl      #0x2b7105c                                 fn_2b7105c
#### CLASS ScoopGame.BlindBagVisualAsset parent= UnityEngine.ScriptableObject
#   field _dataList                      System.Collections.Generic.List`1<ScoopGame.BlindBagVisualDataItem> off=0x18 attr=1 SerializeField
## GetData(int id) -> ScoopGame.BlindBagVisualDataItem
---- ScoopGame.BlindBagVisualAsset::GetData 0x2d32cd0
02d32cd0: str     x30, [sp, #-0x30]!                         
02d32cd4: stp     x22, x21, [sp, #0x10]                      
02d32cd8: stp     x20, x19, [sp, #0x20]                      
02d32cdc: adrp    x21, #0x6630000                            
02d32ce0: adrp    x22, #0x626a000                            
02d32ce4: mov     w19, w1                                    
02d32ce8: ldrb    w8, [x21, #0x1a3]                          
02d32cec: ldr     x22, [x22, #0x808]                         T:ScoopGame.BlindBagVisualAsset/<>c__DisplayClass1_0
02d32cf0: mov     x20, x0                                    
02d32cf4: tbnz    w8, #0, #0x2d32d30                         
02d32cf8: adrp    x0, #0x626a000                             
02d32cfc: ldr     x0, [x0, #0x810]                           MS:System.Collections.Generic.List`1::Find
02d32d00: bl      #0x2b70db0                                 fn_2b70db0
02d32d04: adrp    x0, #0x626a000                             
02d32d08: ldr     x0, [x0, #0x818]                           T:type57220(k15)
02d32d0c: bl      #0x2b70db0                                 fn_2b70db0
02d32d10: adrp    x0, #0x626a000                             
02d32d14: ldr     x0, [x0, #0x820]                           M:ScoopGame.BlindBagVisualAsset/<>c__DisplayClass1_0::<GetData>b__0
02d32d18: bl      #0x2b70db0                                 fn_2b70db0
02d32d1c: adrp    x0, #0x626a000                             
02d32d20: ldr     x0, [x0, #0x808]                           T:ScoopGame.BlindBagVisualAsset/<>c__DisplayClass1_0
02d32d24: bl      #0x2b70db0                                 fn_2b70db0
02d32d28: mov     w8, #1                                     
02d32d2c: strb    w8, [x21, #0x1a3]                          
02d32d30: ldr     x0, [x22]                                  T:type56879(k15)
02d32d34: bl      #0x2b7104c                                 fn_2b7104c
02d32d38: mov     x1, xzr                                    
02d32d3c: mov     x21, x0                                    
02d32d40: bl      #0x4e53e9c                                 System.Object::.ctor
02d32d44: cbz     x21, #0x2d32da4                            
02d32d48: adrp    x8, #0x626a000                             
02d32d4c: adrp    x22, #0x626a000                            
02d32d50: ldr     x8, [x8, #0x818]                           T:type57220(k15)
02d32d54: ldr     x22, [x22, #0x820]                         M:ScoopGame.BlindBagVisualAsset/<>c__DisplayClass1_0::<GetData>b__0
02d32d58: ldr     x20, [x20, #0x18]                          ._dataList
02d32d5c: str     w19, [x21, #0x10]                          
02d32d60: ldr     x0, [x8]                                   T:type56879(k15)
02d32d64: bl      #0x2b7104c                                 fn_2b7104c
02d32d68: ldr     x2, [x22]                                  T:type56879(k15)
02d32d6c: mov     x1, x21                                    
02d32d70: mov     x3, xzr                                    
02d32d74: mov     x19, x0                                    
02d32d78: bl      #0x399ba10                                 fn_399ba10
02d32d7c: cbz     x20, #0x2d32da4                            
02d32d80: adrp    x8, #0x626a000                             
02d32d84: mov     x0, x20                                    
02d32d88: mov     x1, x19                                    
02d32d8c: ldr     x8, [x8, #0x810]                           MS:System.Collections.Generic.List`1::Find
02d32d90: ldp     x20, x19, [sp, #0x20]                      
02d32d94: ldp     x22, x21, [sp, #0x10]                      
02d32d98: ldr     x2, [x8]                                   T:type56879(k15)
02d32d9c: ldr     x30, [sp], #0x30                           
02d32da0: b       #0x35a9868                                 
02d32da4: bl      #0x2b7105c                                 fn_2b7105c
## GetRandomData() -> ScoopGame.BlindBagVisualDataItem
---- ScoopGame.BlindBagVisualAsset::GetRandomData 0x2d336c4
02d336c4: str     x30, [sp, #-0x20]!                         
02d336c8: stp     x20, x19, [sp, #0x10]                      
02d336cc: adrp    x20, #0x6630000                            
02d336d0: mov     x19, x0                                    
02d336d4: ldrb    w8, [x20, #0x1a4]                          
02d336d8: tbnz    w8, #0, #0x2d336fc                         
02d336dc: adrp    x0, #0x626a000                             
02d336e0: ldr     x0, [x0, #0x888]                           MS:System.Collections.Generic.List`1::get_Count
02d336e4: bl      #0x2b70db0                                 fn_2b70db0
02d336e8: adrp    x0, #0x626a000                             
02d336ec: ldr     x0, [x0, #0x890]                           MS:System.Collections.Generic.List`1::get_Item
02d336f0: bl      #0x2b70db0                                 fn_2b70db0
02d336f4: mov     w8, #1                                     
02d336f8: strb    w8, [x20, #0x1a4]                          
02d336fc: ldr     x8, [x19, #0x18]                           ._dataList
02d33700: cbz     x8, #0x2d3373c                             
02d33704: ldr     w1, [x8, #0x18]                            
02d33708: mov     w0, wzr                                    
02d3370c: mov     x2, xzr                                    
02d33710: bl      #0x5b2e000                                 UnityEngine.Random::Range
02d33714: ldr     x8, [x19, #0x18]                           ._dataList
02d33718: cbz     x8, #0x2d3373c                             
02d3371c: adrp    x9, #0x626a000                             
02d33720: mov     w1, w0                                     
02d33724: mov     x0, x8                                     
02d33728: ldr     x9, [x9, #0x890]                           MS:System.Collections.Generic.List`1::get_Item
02d3372c: ldp     x20, x19, [sp, #0x10]                      
02d33730: ldr     x2, [x9]                                   T:type56879(k15)
02d33734: ldr     x30, [sp], #0x20                           
02d33738: b       #0x35a8f3c                                 
02d3373c: bl      #0x2b7105c                                 fn_2b7105c
## GetAllData() -> System.Collections.Generic.List`1<ScoopGame.BlindBagVisualDataItem>
---- ScoopGame.BlindBagVisualAsset::GetAllData 0x2d423e0
02d423e0: ldr     x0, [x0, #0x18]                            ._dataList
02d423e4: ret                                                
## .ctor() -> void
---- ScoopGame.BlindBagVisualAsset::.ctor 0x2d423e8
02d423e8: mov     x1, xzr                                    
02d423ec: b       #0x5b398f0                                 UnityEngine.ScriptableObject::.ctor
