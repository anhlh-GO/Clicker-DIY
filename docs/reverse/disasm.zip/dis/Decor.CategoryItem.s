#### CLASS Decor.CategoryItem/<>c__DisplayClass6_0 parent= object
#   field onClick                        System.Action`1<Decor.CategoryItem>                off=0x10 attr=6 
#   field <>4__this                      Decor.CategoryItem                                 off=0x18 attr=6 
## .ctor() -> void
---- Decor.CategoryItem/<>c__DisplayClass6_0::.ctor 0x2d26f30
02d26f30: mov     x1, xzr                                    
02d26f34: b       #0x4e53e9c                                 System.Object::.ctor
## <OnInit>b__0() -> void
---- Decor.CategoryItem/<>c__DisplayClass6_0::<OnInit>b__0 0x2d27138
02d27138: ldr     x8, [x0, #0x10]                            .onClick
02d2713c: cbz     x8, #0x2d27154                             
02d27140: ldr     x1, [x0, #0x18]                            .<>4__this
02d27144: ldr     x0, [x8, #0x40]                            
02d27148: ldr     x2, [x8, #0x28]                            
02d2714c: ldr     x3, [x8, #0x18]                            
02d27150: br      x3                                         
02d27154: ret                                                
#### CLASS Decor.CategoryItem parent= PoolElement
#   field _button                        UnityEngine.UI.Button                              off=0x28 attr=1 SerializeField
#   field _icon                          UnityEngine.UI.Image                               off=0x30 attr=1 SerializeField
#   field _iconNoti                      UnityEngine.GameObject                             off=0x38 attr=1 SerializeField
#   field _selected                      UnityEngine.GameObject                             off=0x40 attr=1 SerializeField
#   field _onSprite                      UnityEngine.Sprite                                 off=0x48 attr=1 
#   field _offSprite                     UnityEngine.Sprite                                 off=0x50 attr=1 
## OnInit(System.Action`1<Decor.CategoryItem> onClick) -> Decor.CategoryItem
---- Decor.CategoryItem::OnInit 0x2d26e3c
02d26e3c: str     x30, [sp, #-0x30]!                         
02d26e40: stp     x22, x21, [sp, #0x10]                      
02d26e44: stp     x20, x19, [sp, #0x20]                      
02d26e48: adrp    x21, #0x6630000                            
02d26e4c: adrp    x22, #0x626a000                            
02d26e50: mov     x20, x1                                    
02d26e54: ldrb    w8, [x21, #0x8a]                           
02d26e58: ldr     x22, [x22, #0x120]                         T:Decor.CategoryItem/<>c__DisplayClass6_0
02d26e5c: mov     x19, x0                                    
02d26e60: tbnz    w8, #0, #0x2d26e90                         
02d26e64: adrp    x0, #0x626a000                             
02d26e68: ldr     x0, [x0, #0x128]                           M:Decor.CategoryItem/<>c__DisplayClass6_0::<OnInit>b__0
02d26e6c: bl      #0x2b70db0                                 fn_2b70db0
02d26e70: adrp    x0, #0x626a000                             
02d26e74: ldr     x0, [x0, #0x120]                           T:Decor.CategoryItem/<>c__DisplayClass6_0
02d26e78: bl      #0x2b70db0                                 fn_2b70db0
02d26e7c: adrp    x0, #0x6265000                             
02d26e80: ldr     x0, [x0, #0x3f0]                           T:UnityEngine.Events.UnityAction
02d26e84: bl      #0x2b70db0                                 fn_2b70db0
02d26e88: mov     w8, #1                                     
02d26e8c: strb    w8, [x21, #0x8a]                           
02d26e90: ldr     x0, [x22]                                  T:type56879(k15)
02d26e94: bl      #0x2b7104c                                 fn_2b7104c
02d26e98: mov     x1, xzr                                    
02d26e9c: mov     x21, x0                                    
02d26ea0: bl      #0x4e53e9c                                 System.Object::.ctor
02d26ea4: cbz     x21, #0x2d26f2c                            
02d26ea8: mov     x0, x21                                    
02d26eac: mov     x1, x20                                    
02d26eb0: str     x20, [x0, #0x10]!                          
02d26eb4: bl      #0x2b70d54                                 fn_2b70d54
02d26eb8: mov     x0, x21                                    
02d26ebc: mov     x1, x19                                    
02d26ec0: str     x19, [x0, #0x18]!                          
02d26ec4: bl      #0x2b70d54                                 fn_2b70d54
02d26ec8: ldr     x8, [x19, #0x28]                           ._button
02d26ecc: cbz     x8, #0x2d26f2c                             
02d26ed0: adrp    x9, #0x6265000                             
02d26ed4: adrp    x22, #0x626a000                            
02d26ed8: ldr     x9, [x9, #0x3f0]                           T:UnityEngine.Events.UnityAction
02d26edc: ldr     x22, [x22, #0x128]                         M:Decor.CategoryItem/<>c__DisplayClass6_0::<OnInit>b__0
02d26ee0: ldr     x20, [x8, #0x100]                          
02d26ee4: ldr     x0, [x9]                                   M:AdsManager::<OnApplicationPause>b__26_0
02d26ee8: bl      #0x2b7104c                                 fn_2b7104c
02d26eec: ldr     x2, [x22]                                  T:type56879(k15)
02d26ef0: mov     x1, x21                                    
02d26ef4: mov     x3, xzr                                    
02d26ef8: mov     x22, x0                                    
02d26efc: bl      #0x5b4cf98                                 UnityEngine.Events.UnityAction::.ctor
02d26f00: cbz     x20, #0x2d26f2c                            
02d26f04: mov     x0, x20                                    
02d26f08: mov     x1, x22                                    
02d26f0c: mov     x2, xzr                                    
02d26f10: bl      #0x5b4d0ac                                 UnityEngine.Events.UnityEvent::AddListener
02d26f14: mov     x0, x19                                    
02d26f18: ldp     x20, x19, [sp, #0x20]                      
02d26f1c: ldp     x22, x21, [sp, #0x10]                      
02d26f20: mov     w1, wzr                                    
02d26f24: ldr     x30, [sp], #0x30                           
02d26f28: b       #0x2d26f38                                 Decor.CategoryItem::SetSelected
02d26f2c: bl      #0x2b7105c                                 fn_2b7105c
## SetIcon(UnityEngine.Sprite onSprite, UnityEngine.Sprite offSprite) -> Decor.CategoryItem
---- Decor.CategoryItem::SetIcon 0x2d26f94
02d26f94: stp     x30, x21, [sp, #-0x20]!                    
02d26f98: stp     x20, x19, [sp, #0x10]                      
02d26f9c: mov     x20, x2                                    
02d26fa0: mov     x19, x0                                    
02d26fa4: str     x1, [x0, #0x48]!                           ._onSprite
02d26fa8: bl      #0x2b70d54                                 fn_2b70d54
02d26fac: mov     x21, x19                                   
02d26fb0: mov     x1, x20                                    
02d26fb4: str     x20, [x21, #0x50]!                         ._offSprite
02d26fb8: mov     x0, x21                                    
02d26fbc: bl      #0x2b70d54                                 fn_2b70d54
02d26fc0: ldur    x0, [x21, #-0x20]                          
02d26fc4: cbz     x0, #0x2d26fe4                             
02d26fc8: ldr     x1, [x19, #0x50]                           ._offSprite
02d26fcc: mov     x2, xzr                                    
02d26fd0: bl      #0x5c45aa0                                 UnityEngine.UI.Image::set_sprite
02d26fd4: mov     x0, x19                                    
02d26fd8: ldp     x20, x19, [sp, #0x10]                      
02d26fdc: ldp     x30, x21, [sp], #0x20                      
02d26fe0: ret                                                
02d26fe4: bl      #0x2b7105c                                 fn_2b7105c
## SetActiveNotification(bool isActive) -> Decor.CategoryItem
---- Decor.CategoryItem::SetActiveNotification 0x2d26fe8
02d26fe8: stp     x30, x19, [sp, #-0x10]!                    
02d26fec: mov     x19, x0                                    
02d26ff0: ldr     x0, [x0, #0x38]                            ._iconNoti
02d26ff4: cbz     x0, #0x2d27010                             
02d26ff8: and     w1, w1, #1                                 
02d26ffc: mov     x2, xzr                                    
02d27000: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d27004: mov     x0, x19                                    
02d27008: ldp     x30, x19, [sp], #0x10                      
02d2700c: ret                                                
02d27010: bl      #0x2b7105c                                 fn_2b7105c
## SetSelected(bool isSelected) -> Decor.CategoryItem
---- Decor.CategoryItem::SetSelected 0x2d26f38
02d26f38: str     x30, [sp, #-0x20]!                         
02d26f3c: stp     x20, x19, [sp, #0x10]                      
02d26f40: mov     x19, x0                                    
02d26f44: ldr     x0, [x0, #0x40]                            ._selected
02d26f48: cbz     x0, #0x2d26f90                             
02d26f4c: mov     w20, w1                                    
02d26f50: and     w1, w1, #1                                 
02d26f54: mov     x2, xzr                                    
02d26f58: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d26f5c: ldr     x0, [x19, #0x30]                           ._icon
02d26f60: cbz     x0, #0x2d26f90                             
02d26f64: tst     w20, #1                                    
02d26f68: mov     w8, #0x50                                  
02d26f6c: mov     w9, #0x48                                  
02d26f70: csel    x8, x9, x8, ne                             
02d26f74: mov     x2, xzr                                    
02d26f78: ldr     x1, [x19, x8]                              
02d26f7c: bl      #0x5c45aa0                                 UnityEngine.UI.Image::set_sprite
02d26f80: mov     x0, x19                                    
02d26f84: ldp     x20, x19, [sp, #0x10]                      
02d26f88: ldr     x30, [sp], #0x20                           
02d26f8c: ret                                                
02d26f90: bl      #0x2b7105c                                 fn_2b7105c
## StartClickEffect() -> Decor.CategoryItem
---- Decor.CategoryItem::StartClickEffect 0x2d27014
02d27014: str     x30, [sp, #-0x30]!                         
02d27018: stp     x22, x21, [sp, #0x10]                      
02d2701c: stp     x20, x19, [sp, #0x20]                      
02d27020: mov     x19, x0                                    
02d27024: ldr     x0, [x0, #0x30]                            ._icon
02d27028: cbz     x0, #0x2d2712c                             
02d2702c: mov     x1, xzr                                    
02d27030: bl      #0x5c4e1ac                                 UnityEngine.UI.Graphic::get_rectTransform
02d27034: adrp    x21, #0x662f000                            
02d27038: mov     x20, x0                                    
02d2703c: ldrb    w8, [x21, #0xa74]                          
02d27040: cbnz    w8, #0x2d27058                             
02d27044: adrp    x0, #0x6264000                             
02d27048: ldr     x0, [x0, #0xd8]                            T:UnityEngine.Vector3
02d2704c: bl      #0x2b70db0                                 fn_2b70db0
02d27050: mov     w8, #1                                     
02d27054: strb    w8, [x21, #0xa74]                          
02d27058: cbz     x20, #0x2d2712c                            
02d2705c: adrp    x22, #0x6264000                            
02d27060: mov     x0, x20                                    
02d27064: mov     x1, xzr                                    
02d27068: ldr     x22, [x22, #0xd8]                          T:UnityEngine.Vector3
02d2706c: ldr     x8, [x22]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d27070: ldr     x8, [x8, #0xb8]                            
02d27074: ldp     s1, s2, [x8, #0x10]                        
02d27078: ldr     s0, [x8, #0xc]                             
02d2707c: bl      #0x5b470cc                                 UnityEngine.Transform::set_localScale
02d27080: ldr     x0, [x19, #0x30]                           ._icon
02d27084: cbz     x0, #0x2d2712c                             
02d27088: mov     x1, xzr                                    
02d2708c: bl      #0x5c4e1ac                                 UnityEngine.UI.Graphic::get_rectTransform
02d27090: mov     w1, wzr                                    
02d27094: mov     x2, xzr                                    
02d27098: bl      #0x2d9d5d0                                 DG.Tweening.ShortcutExtensions::DOKill
02d2709c: ldr     x0, [x19, #0x30]                           ._icon
02d270a0: cbz     x0, #0x2d2712c                             
02d270a4: mov     x1, xzr                                    
02d270a8: bl      #0x5c4e1ac                                 UnityEngine.UI.Graphic::get_rectTransform
02d270ac: ldrb    w8, [x21, #0xa74]                          
02d270b0: mov     x20, x0                                    
02d270b4: cbnz    w8, #0x2d270cc                             
02d270b8: adrp    x0, #0x6264000                             
02d270bc: ldr     x0, [x0, #0xd8]                            T:UnityEngine.Vector3
02d270c0: bl      #0x2b70db0                                 fn_2b70db0
02d270c4: mov     w8, #1                                     
02d270c8: strb    w8, [x21, #0xa74]                          
02d270cc: ldr     x8, [x22]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d270d0: mov     w9, #0xcccd                                
02d270d4: fmov    s4, #1.00000000                            
02d270d8: movk    w9, #0x3dcc, lsl #16                       
02d270dc: mov     x0, x20                                    
02d270e0: mov     w1, #0xa                                   
02d270e4: ldr     x8, [x8, #0xb8]                            
02d270e8: dup     v0.2s, w9                                  
02d270ec: adrp    x9, #0x1084000                             
02d270f0: ldr     s2, [x9, #0xeec]                           [1084eec]=457ff0003dcccccd f=0.1,4095
02d270f4: mov     x2, xzr                                    
02d270f8: ldur    d1, [x8, #0xc]                             
02d270fc: fmul    v0.2s, v1.2s, v0.2s                        
02d27100: ldr     s1, [x8, #0x14]                            
02d27104: adrp    x8, #0x1084000                             
02d27108: ldr     s3, [x8, #0xdd8]                           [1084dd8]=3f7333333e4ccccd f=0.2,0.95
02d2710c: fmul    s2, s1, s2                                 
02d27110: mov     s1, v0.s[1]                                
02d27114: bl      #0x2d9982c                                 DG.Tweening.ShortcutExtensions::DOPunchScale
02d27118: mov     x0, x19                                    
02d2711c: ldp     x20, x19, [sp, #0x20]                      
02d27120: ldp     x22, x21, [sp, #0x10]                      
02d27124: ldr     x30, [sp], #0x30                           
02d27128: ret                                                
02d2712c: bl      #0x2b7105c                                 fn_2b7105c
## .ctor() -> void
---- Decor.CategoryItem::.ctor 0x2d27130
02d27130: mov     x1, xzr                                    
02d27134: b       #0x2cd6228                                 PoolElement::.ctor
