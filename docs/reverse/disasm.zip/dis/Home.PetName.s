#### CLASS Home.PetName parent= int
#   field value__                        int                                                off=0x10 attr=606 
#   field chip                           Home.PetName                                       off=0x0 attr=8056 
#   field dog                            Home.PetName                                       off=0x0 attr=8056 
#   field reindeer                       Home.PetName                                       off=0x0 attr=8056 
#   field squidgame_girl                 Home.PetName                                       off=0x0 attr=8056 
#   field squidgame_solider              Home.PetName                                       off=0x0 attr=8056 
#   field bat_haloween                   Home.PetName                                       off=0x0 attr=8056 
#   field turkey                         Home.PetName                                       off=0x0 attr=8056 
#   field pet_christmas                  Home.PetName                                       off=0x0 attr=8056 
