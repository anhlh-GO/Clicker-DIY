#### CLASS Blindbag.BlindBagAnimation/<>c parent= object
#   field <>9                            Blindbag.BlindBagAnimation/<>c                     off=0x0 attr=36 
#   field <>9__21_0                      DG.Tweening.Core.DOGetter`1<float>                 off=0x8 attr=16 
## .cctor() -> void
---- Blindbag.BlindBagAnimation/<>c::.cctor 0x2d509c4
02d509c4: str     x30, [sp, #-0x20]!                         
02d509c8: stp     x20, x19, [sp, #0x10]                      
02d509cc: adrp    x19, #0x6630000                            
02d509d0: adrp    x20, #0x626b000                            
02d509d4: ldrb    w8, [x19, #0x254]                          
02d509d8: ldr     x20, [x20, #0x7c0]                         T:Blindbag.BlindBagAnimation/<>c
02d509dc: tbnz    w8, #0, #0x2d509f4                         
02d509e0: adrp    x0, #0x626b000                             
02d509e4: ldr     x0, [x0, #0x7c0]                           T:Blindbag.BlindBagAnimation/<>c
02d509e8: bl      #0x2b70db0                                 fn_2b70db0
02d509ec: mov     w8, #1                                     
02d509f0: strb    w8, [x19, #0x254]                          
02d509f4: ldr     x0, [x20]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d509f8: bl      #0x2b7104c                                 fn_2b7104c
02d509fc: mov     x1, xzr                                    
02d50a00: mov     x19, x0                                    
02d50a04: bl      #0x4e53e9c                                 System.Object::.ctor
02d50a08: ldr     x8, [x20]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d50a0c: mov     x1, x19                                    
02d50a10: ldr     x8, [x8, #0xb8]                            
02d50a14: str     x19, [x8]                                  
02d50a18: ldr     x8, [x20]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d50a1c: ldp     x20, x19, [sp, #0x10]                      
02d50a20: ldr     x0, [x8, #0xb8]                            
02d50a24: ldr     x30, [sp], #0x20                           
02d50a28: b       #0x2b70d54                                 
## .ctor() -> void
---- Blindbag.BlindBagAnimation/<>c::.ctor 0x2d50a2c
02d50a2c: mov     x1, xzr                                    
02d50a30: b       #0x4e53e9c                                 System.Object::.ctor
## <FadeOutSpine>b__21_0() -> float
---- Blindbag.BlindBagAnimation/<>c::<FadeOutSpine>b__21_0 0x2d50a34
02d50a34: fmov    s0, #1.00000000                            
02d50a38: ret                                                
#### CLASS Blindbag.BlindBagAnimation/<>c__DisplayClass20_0 parent= object
#   field onCompleted                    System.Action                                      off=0x10 attr=6 
## .ctor() -> void
---- Blindbag.BlindBagAnimation/<>c__DisplayClass20_0::.ctor 0x2d501b4
02d501b4: mov     x1, xzr                                    
02d501b8: b       #0x4e53e9c                                 System.Object::.ctor
## <FadeOut>b__0() -> void
---- Blindbag.BlindBagAnimation/<>c__DisplayClass20_0::<FadeOut>b__0 0x2d50a3c
02d50a3c: ldr     x8, [x0, #0x10]                            .onCompleted
02d50a40: cbz     x8, #0x2d50a54                             
02d50a44: ldr     x0, [x8, #0x40]                            
02d50a48: ldr     x1, [x8, #0x28]                            
02d50a4c: ldr     x2, [x8, #0x18]                            
02d50a50: br      x2                                         
02d50a54: ret                                                
#### CLASS Blindbag.BlindBagAnimation/<>c__DisplayClass21_0 parent= object
#   field skeleton                       Spine.Skeleton                                     off=0x10 attr=6 
#   field originalColor                  UnityEngine.Color                                  off=0x18 attr=6 
#   field onCompleted                    System.Action                                      off=0x28 attr=6 
## .ctor() -> void
---- Blindbag.BlindBagAnimation/<>c__DisplayClass21_0::.ctor 0x2d50418
02d50418: mov     x1, xzr                                    
02d5041c: b       #0x4e53e9c                                 System.Object::.ctor
## <FadeOutSpine>b__1(float alpha) -> void
---- Blindbag.BlindBagAnimation/<>c__DisplayClass21_0::<FadeOutSpine>b__1 0x2d50a58
02d50a58: ldp     s2, s1, [x0, #0x20]                        
02d50a5c: mov     x1, xzr                                    
02d50a60: ldr     x8, [x0, #0x10]                            .skeleton
02d50a64: fmul    s3, s1, s0                                 
02d50a68: ldp     s0, s1, [x0, #0x18]                        .originalColor
02d50a6c: mov     x0, x8                                     
02d50a70: b       #0x5014060                                 Spine.Unity.SkeletonExtensions::SetColor
## <FadeOutSpine>b__2() -> void
---- Blindbag.BlindBagAnimation/<>c__DisplayClass21_0::<FadeOutSpine>b__2 0x2d50a74
02d50a74: ldr     x8, [x0, #0x28]                            .onCompleted
02d50a78: cbz     x8, #0x2d50a8c                             
02d50a7c: ldr     x0, [x8, #0x40]                            
02d50a80: ldr     x1, [x8, #0x28]                            
02d50a84: ldr     x2, [x8, #0x18]                            
02d50a88: br      x2                                         
02d50a8c: ret                                                
#### CLASS Blindbag.BlindBagAnimation parent= PoolElement
#   field _isTriggered                   bool                                               off=0x28 attr=1 SerializeField
#   field _spineBag                      Spine.Unity.SkeletonAnimation                      off=0x30 attr=1 SerializeField
#   field OnScanItem                     System.Action`1<Blindbag.BlindBagAnimation>        off=0x38 attr=6 
#   field _id                            int                                                off=0x40 attr=1 
#   field _bagName                       string                                             off=0x48 attr=1 
#   field _price                         int                                                off=0x50 attr=1 
#   field _target                        UnityEngine.Transform                              off=0x58 attr=1 
#   field _cachedEuler                   UnityEngine.Vector3                                off=0x60 attr=1 
#   field _cachedPosition                UnityEngine.Vector3                                off=0x6c attr=1 
#   field _mainCamera                    UnityEngine.Camera                                 off=0x78 attr=1 
#   field _dragSpeed                     float                                              off=0x80 attr=1 
## get_Id() -> int
---- Blindbag.BlindBagAnimation::get_Id 0x2d500a8
02d500a8: ldr     w0, [x0, #0x40]                            ._id
02d500ac: ret                                                
## get_Price() -> int
---- Blindbag.BlindBagAnimation::get_Price 0x2d500b0
02d500b0: ldr     w0, [x0, #0x50]                            ._price
02d500b4: ret                                                
## get_BagName() -> string
---- Blindbag.BlindBagAnimation::get_BagName 0x2d500b8
02d500b8: ldr     x0, [x0, #0x48]                            ._bagName
02d500bc: ret                                                
## get_Visual() -> Spine.Unity.SkeletonAnimation
---- Blindbag.BlindBagAnimation::get_Visual 0x2d500c0
02d500c0: ldr     x0, [x0, #0x30]                            ._spineBag
02d500c4: ret                                                
## OnDespawned() -> void
---- Blindbag.BlindBagAnimation::OnDespawned 0x2d500c8
02d500c8: stp     x30, x19, [sp, #-0x10]!                    
02d500cc: mov     x19, x0                                    
02d500d0: bl      #0x2d500f4                                 Blindbag.BlindBagAnimation::RemoveCollider
02d500d4: mov     x0, x19                                    
02d500d8: mov     x1, xzr                                    
02d500dc: str     xzr, [x0, #0x38]!                          .OnScanItem
02d500e0: bl      #0x2b70d54                                 fn_2b70d54
02d500e4: mov     x0, x19                                    
02d500e8: mov     x1, xzr                                    
02d500ec: ldp     x30, x19, [sp], #0x10                      
02d500f0: b       #0x2cdcae4                                 PoolElement::OnDespawned
## FadeOut(float duration, System.Action onCompleted) -> void
---- Blindbag.BlindBagAnimation::FadeOut 0x2d4f62c
02d4f62c: str     d8, [sp, #-0x40]!                          
02d4f630: stp     x30, x23, [sp, #0x10]                      
02d4f634: stp     x22, x21, [sp, #0x20]                      
02d4f638: stp     x20, x19, [sp, #0x30]                      
02d4f63c: fmov    s8, s0                                     
02d4f640: adrp    x21, #0x6630000                            
02d4f644: adrp    x22, #0x626b000                            
02d4f648: ldrb    w8, [x21, #0x24e]                          
02d4f64c: ldr     x22, [x22, #0x748]                         T:Blindbag.BlindBagAnimation/<>c__DisplayClass20_0
02d4f650: mov     x20, x1                                    
02d4f654: mov     x19, x0                                    
02d4f658: tbnz    w8, #0, #0x2d4f688                         
02d4f65c: adrp    x0, #0x6264000                             
02d4f660: ldr     x0, [x0, #0xf90]                           T:System.Action
02d4f664: bl      #0x2b70db0                                 fn_2b70db0
02d4f668: adrp    x0, #0x626b000                             
02d4f66c: ldr     x0, [x0, #0x750]                           M:Blindbag.BlindBagAnimation/<>c__DisplayClass20_0::<FadeOut>b__0
02d4f670: bl      #0x2b70db0                                 fn_2b70db0
02d4f674: adrp    x0, #0x626b000                             
02d4f678: ldr     x0, [x0, #0x748]                           T:Blindbag.BlindBagAnimation/<>c__DisplayClass20_0
02d4f67c: bl      #0x2b70db0                                 fn_2b70db0
02d4f680: mov     w8, #1                                     
02d4f684: strb    w8, [x21, #0x24e]                          
02d4f688: ldr     x0, [x22]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d4f68c: bl      #0x2b7104c                                 fn_2b7104c
02d4f690: mov     x1, xzr                                    
02d4f694: mov     x21, x0                                    
02d4f698: bl      #0x4e53e9c                                 System.Object::.ctor
02d4f69c: cbz     x21, #0x2d4f70c                            
02d4f6a0: adrp    x22, #0x6264000                            
02d4f6a4: adrp    x23, #0x626b000                            
02d4f6a8: mov     x0, x21                                    
02d4f6ac: ldr     x22, [x22, #0xf90]                         T:System.Action
02d4f6b0: ldr     x23, [x23, #0x750]                         M:Blindbag.BlindBagAnimation/<>c__DisplayClass20_0::<FadeOut>b__0
02d4f6b4: mov     x1, x20                                    
02d4f6b8: str     x20, [x0, #0x10]!                          
02d4f6bc: bl      #0x2b70d54                                 fn_2b70d54
02d4f6c0: ldr     x0, [x19, #0x30]                           ._spineBag
02d4f6c4: mov     w1, wzr                                    
02d4f6c8: mov     x2, xzr                                    
02d4f6cc: bl      #0x2d9d5d0                                 DG.Tweening.ShortcutExtensions::DOKill
02d4f6d0: ldr     x0, [x22]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d4f6d4: bl      #0x2b7104c                                 fn_2b7104c
02d4f6d8: ldr     x2, [x23]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d4f6dc: mov     x1, x21                                    
02d4f6e0: mov     x3, xzr                                    
02d4f6e4: mov     x20, x0                                    
02d4f6e8: bl      #0x4d8ddbc                                 System.Action::.ctor
02d4f6ec: mov     x0, x19                                    
02d4f6f0: mov     x1, x20                                    
02d4f6f4: fmov    s0, s8                                     
02d4f6f8: ldp     x20, x19, [sp, #0x30]                      
02d4f6fc: ldp     x22, x21, [sp, #0x20]                      
02d4f700: ldp     x30, x23, [sp, #0x10]                      
02d4f704: ldr     d8, [sp], #0x40                            
02d4f708: b       #0x2d501bc                                 Blindbag.BlindBagAnimation::FadeOutSpine
02d4f70c: bl      #0x2b7105c                                 fn_2b7105c
## FadeOutSpine(float duration, System.Action onCompleted) -> void
---- Blindbag.BlindBagAnimation::FadeOutSpine 0x2d501bc
02d501bc: str     d8, [sp, #-0x60]!                          
02d501c0: stp     x30, x27, [sp, #0x10]                      
02d501c4: stp     x26, x25, [sp, #0x20]                      
02d501c8: stp     x24, x23, [sp, #0x30]                      
02d501cc: stp     x22, x21, [sp, #0x40]                      
02d501d0: stp     x20, x19, [sp, #0x50]                      
02d501d4: fmov    s8, s0                                     
02d501d8: adrp    x19, #0x6630000                            
02d501dc: adrp    x22, #0x626b000                            
02d501e0: ldrb    w8, [x19, #0x24f]                          
02d501e4: ldr     x22, [x22, #0x7a0]                         T:Blindbag.BlindBagAnimation/<>c__DisplayClass21_0
02d501e8: mov     x20, x1                                    
02d501ec: mov     x21, x0                                    
02d501f0: tbnz    w8, #0, #0x2d50274                         
02d501f4: adrp    x0, #0x6263000                             
02d501f8: ldr     x0, [x0, #0xfc0]                           T:type8528(k15)
02d501fc: bl      #0x2b70db0                                 fn_2b70db0
02d50200: adrp    x0, #0x6263000                             
02d50204: ldr     x0, [x0, #0xfc8]                           T:type8550(k15)
02d50208: bl      #0x2b70db0                                 fn_2b70db0
02d5020c: adrp    x0, #0x6263000                             
02d50210: ldr     x0, [x0, #0xfd0]                           T:DG.Tweening.DOTween
02d50214: bl      #0x2b70db0                                 fn_2b70db0
02d50218: adrp    x0, #0x6264000                             
02d5021c: ldr     x0, [x0, #0xe8]                            T:DG.Tweening.TweenCallback
02d50220: bl      #0x2b70db0                                 fn_2b70db0
02d50224: adrp    x0, #0x6266000                             
02d50228: ldr     x0, [x0, #0xc90]                           MS:DG.Tweening.TweenSettingsExtensions::OnComplete
02d5022c: bl      #0x2b70db0                                 fn_2b70db0
02d50230: adrp    x0, #0x626b000                             
02d50234: ldr     x0, [x0, #0x7a8]                           M:Blindbag.BlindBagAnimation/<>c::<FadeOutSpine>b__21_0
02d50238: bl      #0x2b70db0                                 fn_2b70db0
02d5023c: adrp    x0, #0x626b000                             
02d50240: ldr     x0, [x0, #0x7b0]                           M:Blindbag.BlindBagAnimation/<>c__DisplayClass21_0::<FadeOutSpine>b__1
02d50244: bl      #0x2b70db0                                 fn_2b70db0
02d50248: adrp    x0, #0x626b000                             
02d5024c: ldr     x0, [x0, #0x7b8]                           M:Blindbag.BlindBagAnimation/<>c__DisplayClass21_0::<FadeOutSpine>b__2
02d50250: bl      #0x2b70db0                                 fn_2b70db0
02d50254: adrp    x0, #0x626b000                             
02d50258: ldr     x0, [x0, #0x7a0]                           T:Blindbag.BlindBagAnimation/<>c__DisplayClass21_0
02d5025c: bl      #0x2b70db0                                 fn_2b70db0
02d50260: adrp    x0, #0x626b000                             
02d50264: ldr     x0, [x0, #0x7c0]                           T:Blindbag.BlindBagAnimation/<>c
02d50268: bl      #0x2b70db0                                 fn_2b70db0
02d5026c: mov     w8, #1                                     
02d50270: strb    w8, [x19, #0x24f]                          
02d50274: ldr     x0, [x22]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d50278: bl      #0x2b7104c                                 fn_2b7104c
02d5027c: mov     x1, xzr                                    
02d50280: mov     x19, x0                                    
02d50284: bl      #0x4e53e9c                                 System.Object::.ctor
02d50288: cbz     x19, #0x2d50414                            
02d5028c: mov     x0, x19                                    
02d50290: mov     x1, x20                                    
02d50294: str     x20, [x0, #0x28]!                          ._isTriggered
02d50298: bl      #0x2b70d54                                 fn_2b70d54
02d5029c: ldr     x0, [x21, #0x30]                           ._spineBag
02d502a0: cbz     x0, #0x2d50414                             
02d502a4: adrp    x22, #0x626b000                            
02d502a8: mov     x1, xzr                                    
02d502ac: ldr     x22, [x22, #0x7c0]                         T:Blindbag.BlindBagAnimation/<>c
02d502b0: bl      #0x5002600                                 Spine.Unity.SkeletonRenderer::get_Skeleton
02d502b4: mov     x20, x19                                   
02d502b8: mov     x1, x0                                     
02d502bc: str     x0, [x20, #0x10]!                          
02d502c0: mov     x0, x20                                    
02d502c4: bl      #0x2b70d54                                 fn_2b70d54
02d502c8: ldr     x0, [x20]                                  
02d502cc: mov     x1, xzr                                    
02d502d0: bl      #0x5013fe4                                 Spine.Unity.SkeletonExtensions::GetColor
02d502d4: ldr     x0, [x22]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d502d8: stp     s0, s1, [x20, #8]                          
02d502dc: stp     s2, s3, [x20, #0x10]                       
02d502e0: ldr     w8, [x0, #0xe4]                            [626b0e4]=0 f=0,0
02d502e4: cbnz    w8, #0x2d502f0                             
02d502e8: bl      #0x2b70f30                                 fn_2b70f30
02d502ec: ldr     x0, [x22]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d502f0: ldr     x8, [x0, #0xb8]                            S:'scoop_no_thank'
02d502f4: adrp    x25, #0x6263000                            
02d502f8: adrp    x24, #0x626b000                            
02d502fc: adrp    x23, #0x6263000                            
02d50300: ldr     x25, [x25, #0xfc8]                         T:type8550(k15)
02d50304: ldr     x24, [x24, #0x7b0]                         M:Blindbag.BlindBagAnimation/<>c__DisplayClass21_0::<FadeOutSpine>b__1
02d50308: ldr     x20, [x8, #8]                              
02d5030c: ldr     x23, [x23, #0xfd0]                         T:DG.Tweening.DOTween
02d50310: cbnz    x20, #0x2d5036c                            
02d50314: ldr     w9, [x0, #0xe4]                            [626b0e4]=0 f=0,0
02d50318: cbnz    w9, #0x2d50328                             
02d5031c: bl      #0x2b70f30                                 fn_2b70f30
02d50320: ldr     x8, [x22]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d50324: ldr     x8, [x8, #0xb8]                            
02d50328: adrp    x9, #0x6263000                             
02d5032c: ldr     x9, [x9, #0xfc0]                           T:type8528(k15)
02d50330: ldr     x21, [x8]                                  
02d50334: ldr     x0, [x9]                                   &2c5bbd4(=a9bd7bfdd503233f)
02d50338: bl      #0x2b7104c                                 fn_2b7104c
02d5033c: adrp    x8, #0x626b000                             
02d50340: mov     x1, x21                                    
02d50344: mov     x3, xzr                                    
02d50348: ldr     x8, [x8, #0x7a8]                           M:Blindbag.BlindBagAnimation/<>c::<FadeOutSpine>b__21_0
02d5034c: mov     x20, x0                                    
02d50350: ldr     x2, [x8]                                   T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d50354: bl      #0x44536ec                                 fn_44536ec
02d50358: ldr     x8, [x22]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d5035c: mov     x1, x20                                    
02d50360: ldr     x0, [x8, #0xb8]                            S:'scoop_no_thank'
02d50364: str     x20, [x0, #8]!                             
02d50368: bl      #0x2b70d54                                 fn_2b70d54
02d5036c: adrp    x27, #0x6264000                            
02d50370: adrp    x26, #0x626b000                            
02d50374: adrp    x22, #0x6266000                            
02d50378: ldr     x27, [x27, #0xe8]                          T:DG.Tweening.TweenCallback
02d5037c: ldr     x26, [x26, #0x7b8]                         M:Blindbag.BlindBagAnimation/<>c__DisplayClass21_0::<FadeOutSpine>b__2
02d50380: ldr     x22, [x22, #0xc90]                         MS:DG.Tweening.TweenSettingsExtensions::OnComplete
02d50384: ldr     x0, [x25]                                  &2c5bbd4(=a9bd7bfdd503233f)
02d50388: bl      #0x2b7104c                                 fn_2b7104c
02d5038c: ldr     x2, [x24]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d50390: mov     x1, x19                                    
02d50394: mov     x3, xzr                                    
02d50398: mov     x21, x0                                    
02d5039c: bl      #0x4454818                                 fn_4454818
02d503a0: ldr     x0, [x23]                                  &2c5bbd4(=a9bd7bfdd503233f)
02d503a4: ldr     w8, [x0, #0xe4]                            [626b0e4]=0 f=0,0
02d503a8: cbnz    w8, #0x2d503b0                             
02d503ac: bl      #0x2b70f30                                 fn_2b70f30
02d503b0: movi    d0, #0000000000000000                      
02d503b4: fmov    s1, s8                                     
02d503b8: mov     x0, x20                                    
02d503bc: mov     x1, x21                                    
02d503c0: mov     x2, xzr                                    
02d503c4: bl      #0x2d8b3b4                                 DG.Tweening.DOTween::To
02d503c8: ldr     x8, [x27]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d503cc: mov     x20, x0                                    
02d503d0: mov     x0, x8                                     
02d503d4: bl      #0x2b7104c                                 fn_2b7104c
02d503d8: ldr     x2, [x26]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d503dc: mov     x1, x19                                    
02d503e0: mov     x3, xzr                                    
02d503e4: mov     x21, x0                                    
02d503e8: bl      #0x2d89dc4                                 DG.Tweening.TweenCallback::.ctor
02d503ec: ldr     x2, [x22]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d503f0: mov     x0, x20                                    
02d503f4: mov     x1, x21                                    
02d503f8: ldp     x20, x19, [sp, #0x50]                      
02d503fc: ldp     x22, x21, [sp, #0x40]                      
02d50400: ldp     x24, x23, [sp, #0x30]                      
02d50404: ldp     x26, x25, [sp, #0x20]                      
02d50408: ldp     x30, x27, [sp, #0x10]                      
02d5040c: ldr     d8, [sp], #0x60                            
02d50410: b       #0x336f26c                                 
02d50414: bl      #0x2b7105c                                 fn_2b7105c
## SetSkinBag(Spine.Unity.SkeletonAnimation source) -> void
---- Blindbag.BlindBagAnimation::SetSkinBag 0x2d50420
02d50420: str     x30, [sp, #-0x20]!                         
02d50424: stp     x20, x19, [sp, #0x10]                      
02d50428: cbz     x1, #0x2d504d4                             
02d5042c: mov     x19, x0                                    
02d50430: mov     x0, x1                                     
02d50434: mov     x1, xzr                                    
02d50438: bl      #0x5002600                                 Spine.Unity.SkeletonRenderer::get_Skeleton
02d5043c: cbz     x0, #0x2d504d4                             
02d50440: ldr     x20, [x0, #0x58]                           ._target
02d50444: cbz     x20, #0x2d504c8                            
02d50448: ldr     x0, [x19, #0x30]                           ._spineBag
02d5044c: cbz     x0, #0x2d504d4                             
02d50450: mov     x1, xzr                                    
02d50454: bl      #0x5002600                                 Spine.Unity.SkeletonRenderer::get_Skeleton
02d50458: cbz     x0, #0x2d504d4                             
02d5045c: mov     x1, x20                                    
02d50460: mov     x2, xzr                                    
02d50464: bl      #0x4fa6330                                 Spine.Skeleton::SetSkin
02d50468: ldr     x0, [x19, #0x30]                           ._spineBag
02d5046c: cbz     x0, #0x2d504d4                             
02d50470: mov     x1, xzr                                    
02d50474: bl      #0x5002600                                 Spine.Unity.SkeletonRenderer::get_Skeleton
02d50478: cbz     x0, #0x2d504d4                             
02d5047c: mov     x1, xzr                                    
02d50480: bl      #0x4fa9890                                 Spine.Skeleton::SetSlotsToSetupPose
02d50484: ldr     x0, [x19, #0x30]                           ._spineBag
02d50488: cbz     x0, #0x2d504d4                             
02d5048c: mov     x1, xzr                                    
02d50490: bl      #0x4ff6f18                                 Spine.Unity.SkeletonAnimation::get_AnimationState
02d50494: ldr     x8, [x19, #0x30]                           ._spineBag
02d50498: cbz     x8, #0x2d504d4                             
02d5049c: mov     x19, x0                                    
02d504a0: mov     x0, x8                                     
02d504a4: mov     x1, xzr                                    
02d504a8: bl      #0x5002600                                 Spine.Unity.SkeletonRenderer::get_Skeleton
02d504ac: cbz     x19, #0x2d504d4                            
02d504b0: mov     x1, x0                                     
02d504b4: mov     x0, x19                                    
02d504b8: mov     x2, xzr                                    
02d504bc: ldp     x20, x19, [sp, #0x10]                      
02d504c0: ldr     x30, [sp], #0x20                           
02d504c4: b       #0x4f95698                                 Spine.AnimationState::Apply
02d504c8: ldp     x20, x19, [sp, #0x10]                      
02d504cc: ldr     x30, [sp], #0x20                           
02d504d0: ret                                                
02d504d4: bl      #0x2b7105c                                 fn_2b7105c
## SetData(string bagName, int price, int id) -> void
---- Blindbag.BlindBagAnimation::SetData 0x2d504d8
02d504d8: stp     x30, x21, [sp, #-0x20]!                    
02d504dc: stp     x20, x19, [sp, #0x10]                      
02d504e0: mov     x21, x0                                    
02d504e4: mov     w19, w3                                    
02d504e8: mov     w20, w2                                    
02d504ec: str     x1, [x21, #0x48]!                          ._bagName
02d504f0: mov     x0, x21                                    
02d504f4: bl      #0x2b70d54                                 fn_2b70d54
02d504f8: str     w20, [x21, #8]                             
02d504fc: stur    w19, [x21, #-8]                            
02d50500: ldp     x20, x19, [sp, #0x10]                      
02d50504: ldp     x30, x21, [sp], #0x20                      
02d50508: ret                                                
## AddCollider() -> void
---- Blindbag.BlindBagAnimation::AddCollider 0x2d5050c
02d5050c: str     x30, [sp, #-0x20]!                         
02d50510: stp     x20, x19, [sp, #0x10]                      
02d50514: adrp    x20, #0x6630000                            
02d50518: mov     x19, x0                                    
02d5051c: ldrb    w8, [x20, #0x250]                          
02d50520: tbnz    w8, #0, #0x2d50538                         
02d50524: adrp    x0, #0x626b000                             
02d50528: ldr     x0, [x0, #0x7c8]                           MS:UnityEngine.GameObject::AddComponent
02d5052c: bl      #0x2b70db0                                 fn_2b70db0
02d50530: mov     w8, #1                                     
02d50534: strb    w8, [x20, #0x250]                          
02d50538: mov     x0, x19                                    
02d5053c: bl      #0x2d500f4                                 Blindbag.BlindBagAnimation::RemoveCollider
02d50540: mov     x0, x19                                    
02d50544: mov     x1, xzr                                    
02d50548: bl      #0x5b339ec                                 UnityEngine.Component::get_gameObject
02d5054c: cbz     x0, #0x2d50568                             
02d50550: adrp    x8, #0x626b000                             
02d50554: ldr     x8, [x8, #0x7c8]                           MS:UnityEngine.GameObject::AddComponent
02d50558: ldp     x20, x19, [sp, #0x10]                      
02d5055c: ldr     x1, [x8]                                   T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d50560: ldr     x30, [sp], #0x20                           
02d50564: b       #0x31d1114                                 
02d50568: bl      #0x2b7105c                                 fn_2b7105c
## RemoveCollider() -> void
---- Blindbag.BlindBagAnimation::RemoveCollider 0x2d500f4
02d500f4: str     x30, [sp, #-0x20]!                         
02d500f8: stp     x20, x19, [sp, #0x10]                      
02d500fc: adrp    x20, #0x6630000                            
02d50100: mov     x19, x0                                    
02d50104: ldrb    w8, [x20, #0x251]                          
02d50108: tbnz    w8, #0, #0x2d5012c                         
02d5010c: adrp    x0, #0x626b000                             
02d50110: ldr     x0, [x0, #0x3c8]                           MS:UnityEngine.GameObject::GetComponent
02d50114: bl      #0x2b70db0                                 fn_2b70db0
02d50118: adrp    x0, #0x6263000                             
02d5011c: ldr     x0, [x0, #0x918]                           T:UnityEngine.Object
02d50120: bl      #0x2b70db0                                 fn_2b70db0
02d50124: mov     w8, #1                                     
02d50128: strb    w8, [x20, #0x251]                          
02d5012c: mov     x0, x19                                    
02d50130: mov     x1, xzr                                    
02d50134: bl      #0x5b339ec                                 UnityEngine.Component::get_gameObject
02d50138: cbz     x0, #0x2d501b0                             
02d5013c: adrp    x8, #0x626b000                             
02d50140: adrp    x20, #0x6263000                            
02d50144: ldr     x8, [x8, #0x3c8]                           MS:UnityEngine.GameObject::GetComponent
02d50148: ldr     x20, [x20, #0x918]                         T:UnityEngine.Object
02d5014c: ldr     x1, [x8]                                   T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d50150: bl      #0x31d11a4                                 fn_31d11a4
02d50154: ldr     x8, [x20]                                  &2c5bbd4(=a9bd7bfdd503233f)
02d50158: mov     x19, x0                                    
02d5015c: ldr     w9, [x8, #0xe4]                            [626b0e4]=0 f=0,0
02d50160: cbnz    w9, #0x2d5016c                             
02d50164: mov     x0, x8                                     
02d50168: bl      #0x2b70f30                                 fn_2b70f30
02d5016c: mov     x0, x19                                    
02d50170: mov     x1, xzr                                    
02d50174: mov     x2, xzr                                    
02d50178: bl      #0x5b3666c                                 UnityEngine.Object::op_Inequality
02d5017c: tbz     w0, #0, #0x2d501a4                         
02d50180: ldr     x0, [x20]                                  &2c5bbd4(=a9bd7bfdd503233f)
02d50184: ldr     w8, [x0, #0xe4]                            [62630e4]=0 f=0,0
02d50188: cbnz    w8, #0x2d50190                             
02d5018c: bl      #0x2b70f30                                 fn_2b70f30
02d50190: mov     x0, x19                                    
02d50194: ldp     x20, x19, [sp, #0x10]                      
02d50198: mov     x1, xzr                                    
02d5019c: ldr     x30, [sp], #0x20                           
02d501a0: b       #0x5b3ca38                                 UnityEngine.Object::Destroy
02d501a4: ldp     x20, x19, [sp, #0x10]                      
02d501a8: ldr     x30, [sp], #0x20                           
02d501ac: ret                                                
02d501b0: bl      #0x2b7105c                                 fn_2b7105c
## OnMouseButtonDown() -> void
---- Blindbag.BlindBagAnimation::OnMouseButtonDown 0x2d5056c
02d5056c: str     x30, [sp, #-0x20]!                         
02d50570: stp     x20, x19, [sp, #0x10]                      
02d50574: mov     x1, xzr                                    
02d50578: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02d5057c: adrp    x20, #0x662f000                            
02d50580: mov     x19, x0                                    
02d50584: ldrb    w8, [x20, #0x91a]                          
02d50588: cbnz    w8, #0x2d505a0                             
02d5058c: adrp    x0, #0x6264000                             
02d50590: ldr     x0, [x0, #0xd8]                            T:UnityEngine.Vector3
02d50594: bl      #0x2b70db0                                 fn_2b70db0
02d50598: mov     w8, #1                                     
02d5059c: strb    w8, [x20, #0x91a]                          
02d505a0: cbz     x19, #0x2d505d0                            
02d505a4: adrp    x8, #0x6264000                             
02d505a8: mov     x0, x19                                    
02d505ac: mov     x1, xzr                                    
02d505b0: ldr     x8, [x8, #0xd8]                            T:UnityEngine.Vector3
02d505b4: ldp     x20, x19, [sp, #0x10]                      
02d505b8: ldr     x8, [x8]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d505bc: ldr     x8, [x8, #0xb8]                            MS:DG.Tweening.Core.Extensions::SetSpecialStartupMode
02d505c0: ldp     s0, s1, [x8]                               
02d505c4: ldr     s2, [x8, #8]                               T:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass2_0
02d505c8: ldr     x30, [sp], #0x20                           
02d505cc: b       #0x5b46c88                                 UnityEngine.Transform::set_localEulerAngles
02d505d0: bl      #0x2b7105c                                 fn_2b7105c
## OnMouseButtonDrag() -> void
---- Blindbag.BlindBagAnimation::OnMouseButtonDrag 0x2d505d4
02d505d4: stp     d13, d12, [sp, #-0x50]!                    
02d505d8: stp     d11, d10, [sp, #0x10]                      
02d505dc: stp     d9, d8, [sp, #0x20]                        
02d505e0: str     x30, [sp, #0x30]                           
02d505e4: stp     x20, x19, [sp, #0x40]                      
02d505e8: adrp    x20, #0x6630000                            
02d505ec: mov     x19, x0                                    
02d505f0: ldrb    w8, [x20, #0x252]                          
02d505f4: tbnz    w8, #0, #0x2d50618                         
02d505f8: adrp    x0, #0x6266000                             
02d505fc: ldr     x0, [x0, #0x938]                           MS:UnityEngine.InputSystem.InputControl`1::ReadValue
02d50600: bl      #0x2b70db0                                 fn_2b70db0
02d50604: adrp    x0, #0x6263000                             
02d50608: ldr     x0, [x0, #0x918]                           T:UnityEngine.Object
02d5060c: bl      #0x2b70db0                                 fn_2b70db0
02d50610: mov     w8, #1                                     
02d50614: strb    w8, [x20, #0x252]                          
02d50618: ldrb    w8, [x19, #0x28]                           ._isTriggered
02d5061c: cbnz    w8, #0x2d507d4                             
02d50620: adrp    x8, #0x6263000                             
02d50624: ldr     x8, [x8, #0x918]                           T:UnityEngine.Object
02d50628: ldr     x20, [x19, #0x58]                          ._target
02d5062c: ldr     x0, [x8]                                   &2c5bbd4(=a9bd7bfdd503233f)
02d50630: ldr     w8, [x0, #0xe4]                            [62630e4]=0 f=0,0
02d50634: cbnz    w8, #0x2d5063c                             
02d50638: bl      #0x2b70f30                                 fn_2b70f30
02d5063c: mov     x0, x20                                    
02d50640: mov     x1, xzr                                    
02d50644: mov     x2, xzr                                    
02d50648: bl      #0x5b37d84                                 UnityEngine.Object::op_Equality
02d5064c: tbnz    w0, #0, #0x2d507d4                         
02d50650: adrp    x20, #0x662f000                            
02d50654: ldrb    w8, [x20, #0xbd9]                          
02d50658: cbnz    w8, #0x2d50670                             
02d5065c: adrp    x0, #0x6266000                             
02d50660: ldr     x0, [x0, #0x950]                           T:UnityEngine.InputSystem.Pointer
02d50664: bl      #0x2b70db0                                 fn_2b70db0
02d50668: mov     w8, #1                                     
02d5066c: strb    w8, [x20, #0xbd9]                          
02d50670: adrp    x8, #0x6266000                             
02d50674: ldr     x8, [x8, #0x950]                           T:UnityEngine.InputSystem.Pointer
02d50678: ldr     x8, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d5067c: ldr     x8, [x8, #0xb8]                            S:'banner_native_refresh_time'
02d50680: ldr     x8, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d50684: cbz     x8, #0x2d507d4                             
02d50688: ldr     x0, [x8, #0x188]                           S:'makeText'
02d5068c: cbz     x0, #0x2d507ec                             
02d50690: adrp    x8, #0x6266000                             
02d50694: ldr     x8, [x8, #0x938]                           MS:UnityEngine.InputSystem.InputControl`1::ReadValue
02d50698: ldr     x1, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d5069c: bl      #0x4a187c4                                 fn_4a187c4
02d506a0: movi    d2, #0000000000000000                      
02d506a4: movi    d3, #0000000000000000                      
02d506a8: mov     x0, x19                                    
02d506ac: bl      #0x2d507f0                                 Blindbag.BlindBagAnimation::WordPosition
02d506b0: mov     x0, x19                                    
02d506b4: mov     x1, xzr                                    
02d506b8: fmov    s8, s0                                     
02d506bc: fmov    s9, s1                                     
02d506c0: fmov    s10, s2                                    
02d506c4: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02d506c8: mov     x20, x0                                    
02d506cc: mov     x0, x19                                    
02d506d0: mov     x1, xzr                                    
02d506d4: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02d506d8: cbz     x0, #0x2d507ec                             
02d506dc: mov     x1, xzr                                    
02d506e0: bl      #0x5b467ac                                 UnityEngine.Transform::get_position
02d506e4: mov     x0, xzr                                    
02d506e8: fmov    s11, s0                                    
02d506ec: fmov    s12, s1                                    
02d506f0: fmov    s13, s2                                    
02d506f4: bl      #0x5b433a4                                 UnityEngine.Time::get_deltaTime
02d506f8: cbz     x20, #0x2d507ec                            
02d506fc: ldr     s1, [x19, #0x80]                           ._dragSpeed
02d50700: movi    d2, #0000000000000000                      
02d50704: fsub    s3, s8, s11                                
02d50708: mov     x0, x20                                    
02d5070c: mov     x1, xzr                                    
02d50710: fmul    s0, s0, s1                                 
02d50714: fmov    s1, #1.00000000                            
02d50718: fcmp    s0, s1                                     
02d5071c: fcsel   s1, s1, s0, gt                             
02d50720: fcmp    s0, #0.0                                   
02d50724: fsub    s0, s10, s13                               
02d50728: fcsel   s1, s2, s1, mi                             
02d5072c: fsub    s2, s9, s12                                
02d50730: fmul    s0, s0, s1                                 
02d50734: fmul    s4, s2, s1                                 
02d50738: fmul    s3, s3, s1                                 
02d5073c: fadd    s2, s13, s0                                
02d50740: fadd    s1, s12, s4                                
02d50744: fadd    s0, s11, s3                                
02d50748: bl      #0x5b46888                                 UnityEngine.Transform::set_position
02d5074c: mov     x0, x19                                    
02d50750: mov     x1, xzr                                    
02d50754: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02d50758: cbz     x0, #0x2d507ec                             
02d5075c: mov     x1, xzr                                    
02d50760: bl      #0x5b467ac                                 UnityEngine.Transform::get_position
02d50764: ldr     x0, [x19, #0x58]                           ._target
02d50768: cbz     x0, #0x2d507ec                             
02d5076c: mov     x1, xzr                                    
02d50770: fmov    s9, s0                                     
02d50774: fmov    s8, s1                                     
02d50778: bl      #0x5b467ac                                 UnityEngine.Transform::get_position
02d5077c: fabd    s0, s9, s0                                 
02d50780: fmov    s2, #1.00000000                            
02d50784: fcmp    s0, s2                                     
02d50788: b.pl    #0x2d507d4                                 
02d5078c: fabd    s0, s8, s1                                 
02d50790: fmov    s1, #0.50000000                            
02d50794: fcmp    s0, s1                                     
02d50798: b.pl    #0x2d507d4                                 
02d5079c: ldr     x8, [x19, #0x38]                           .OnScanItem
02d507a0: mov     w9, #1                                     
02d507a4: strb    w9, [x19, #0x28]                           ._isTriggered
02d507a8: cbz     x8, #0x2d507d4                             
02d507ac: mov     x1, x19                                    
02d507b0: ldp     x20, x19, [sp, #0x40]                      
02d507b4: ldp     d9, d8, [sp, #0x20]                        
02d507b8: ldr     x0, [x8, #0x40]                            S:'native_collap_ad_on_off'
02d507bc: ldp     d11, d10, [sp, #0x10]                      
02d507c0: ldr     x2, [x8, #0x28]                            S:'banner_ad_on_off'
02d507c4: ldr     x3, [x8, #0x18]                            S:'level_show_popuprate'
02d507c8: ldr     x30, [sp, #0x30]                           
02d507cc: ldp     d13, d12, [sp], #0x50                      
02d507d0: br      x3                                         
02d507d4: ldp     x20, x19, [sp, #0x40]                      
02d507d8: ldr     x30, [sp, #0x30]                           
02d507dc: ldp     d9, d8, [sp, #0x20]                        
02d507e0: ldp     d11, d10, [sp, #0x10]                      
02d507e4: ldp     d13, d12, [sp], #0x50                      
02d507e8: ret                                                
02d507ec: bl      #0x2b7105c                                 fn_2b7105c
## OnMouseButtonUp() -> void
---- Blindbag.BlindBagAnimation::OnMouseButtonUp 0x2d508b4
02d508b4: stp     x30, x19, [sp, #-0x10]!                    
02d508b8: ldrb    w8, [x0, #0x28]                            ._isTriggered
02d508bc: cbz     w8, #0x2d508c8                             
02d508c0: ldp     x30, x19, [sp], #0x10                      
02d508c4: ret                                                
02d508c8: mov     x1, xzr                                    
02d508cc: mov     x19, x0                                    
02d508d0: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02d508d4: cbz     x0, #0x2d5090c                             
02d508d8: ldp     s1, s2, [x19, #0x64]                       
02d508dc: mov     x1, xzr                                    
02d508e0: ldr     s0, [x19, #0x60]                           ._cachedEuler
02d508e4: bl      #0x5b46c88                                 UnityEngine.Transform::set_localEulerAngles
02d508e8: mov     x0, x19                                    
02d508ec: mov     x1, xzr                                    
02d508f0: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02d508f4: cbz     x0, #0x2d5090c                             
02d508f8: ldp     s0, s1, [x19, #0x6c]                       ._cachedPosition
02d508fc: mov     x1, xzr                                    
02d50900: ldr     s2, [x19, #0x74]                           
02d50904: ldp     x30, x19, [sp], #0x10                      
02d50908: b       #0x5b45cec                                 UnityEngine.Transform::set_localPosition
02d5090c: bl      #0x2b7105c                                 fn_2b7105c
## InitializedBuying(UnityEngine.Transform target) -> void
---- Blindbag.BlindBagAnimation::InitializedBuying 0x2d50910
02d50910: stp     x30, x21, [sp, #-0x20]!                    
02d50914: stp     x20, x19, [sp, #0x10]                      
02d50918: mov     x20, x1                                    
02d5091c: mov     x1, xzr                                    
02d50920: mov     x19, x0                                    
02d50924: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02d50928: mov     x21, x0                                    
02d5092c: mov     w0, #-0x46                                 
02d50930: mov     w1, #0x46                                  
02d50934: mov     x2, xzr                                    
02d50938: bl      #0x5b2e000                                 UnityEngine.Random::Range
02d5093c: cbz     x21, #0x2d509b0                            
02d50940: scvtf   s2, w0                                     
02d50944: movi    d0, #0000000000000000                      
02d50948: mov     x0, x21                                    
02d5094c: movi    d1, #0000000000000000                      
02d50950: mov     x1, xzr                                    
02d50954: bl      #0x5b46c88                                 UnityEngine.Transform::set_localEulerAngles
02d50958: mov     x0, x19                                    
02d5095c: mov     x1, xzr                                    
02d50960: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02d50964: cbz     x0, #0x2d509b0                             
02d50968: mov     x1, xzr                                    
02d5096c: bl      #0x5b46ba8                                 UnityEngine.Transform::get_localEulerAngles
02d50970: mov     x0, x19                                    
02d50974: mov     x1, xzr                                    
02d50978: stp     s0, s1, [x19, #0x60]                       ._cachedEuler
02d5097c: str     s2, [x19, #0x68]                           
02d50980: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02d50984: cbz     x0, #0x2d509b0                             
02d50988: mov     x1, xzr                                    
02d5098c: bl      #0x5b45c24                                 UnityEngine.Transform::get_localPosition
02d50990: str     x20, [x19, #0x58]!                         ._target
02d50994: mov     x0, x19                                    
02d50998: stp     s0, s1, [x19, #0x14]                       
02d5099c: mov     x1, x20                                    
02d509a0: str     s2, [x19, #0x1c]                           
02d509a4: ldp     x20, x19, [sp, #0x10]                      
02d509a8: ldp     x30, x21, [sp], #0x20                      
02d509ac: b       #0x2b70d54                                 
02d509b0: bl      #0x2b7105c                                 fn_2b7105c
## WordPosition(UnityEngine.Vector3 inputPosition, float z) -> UnityEngine.Vector3
---- Blindbag.BlindBagAnimation::WordPosition 0x2d507f0
02d507f0: stp     d11, d10, [sp, #-0x40]!                    
02d507f4: stp     d9, d8, [sp, #0x10]                        
02d507f8: stp     x30, x21, [sp, #0x20]                      
02d507fc: stp     x20, x19, [sp, #0x30]                      
02d50800: fmov    s8, s3                                     
02d50804: fmov    s9, s2                                     
02d50808: adrp    x21, #0x6630000                            
02d5080c: fmov    s10, s1                                    
02d50810: fmov    s11, s0                                    
02d50814: adrp    x20, #0x6263000                            
02d50818: ldrb    w8, [x21, #0x253]                          
02d5081c: ldr     x20, [x20, #0x918]                         T:UnityEngine.Object
02d50820: mov     x19, x0                                    
02d50824: tbnz    w8, #0, #0x2d5083c                         
02d50828: adrp    x0, #0x6263000                             
02d5082c: ldr     x0, [x0, #0x918]                           T:UnityEngine.Object
02d50830: bl      #0x2b70db0                                 fn_2b70db0
02d50834: mov     w8, #1                                     
02d50838: strb    w8, [x21, #0x253]                          
02d5083c: ldr     x0, [x20]                                  &2c5bbd4(=a9bd7bfdd503233f)
02d50840: ldr     x20, [x19, #0x78]!                         ._mainCamera
02d50844: ldr     w8, [x0, #0xe4]                            [62630e4]=0 f=0,0
02d50848: cbnz    w8, #0x2d50850                             
02d5084c: bl      #0x2b70f30                                 fn_2b70f30
02d50850: mov     x0, x20                                    
02d50854: mov     x1, xzr                                    
02d50858: mov     x2, xzr                                    
02d5085c: bl      #0x5b37d84                                 UnityEngine.Object::op_Equality
02d50860: tbz     w0, #0, #0x2d5087c                         
02d50864: mov     x0, xzr                                    
02d50868: bl      #0x5aefe28                                 UnityEngine.Camera::get_main
02d5086c: mov     x1, x0                                     
02d50870: str     x0, [x19]                                  
02d50874: mov     x0, x19                                    
02d50878: bl      #0x2b70d54                                 fn_2b70d54
02d5087c: ldr     x0, [x19]                                  
02d50880: cbz     x0, #0x2d508b0                             
02d50884: fmov    s0, s11                                    
02d50888: fmov    s1, s10                                    
02d5088c: mov     x1, xzr                                    
02d50890: fmov    s2, s9                                     
02d50894: bl      #0x5aefbb0                                 UnityEngine.Camera::ScreenToWorldPoint
02d50898: fmov    s2, s8                                     
02d5089c: ldp     x20, x19, [sp, #0x30]                      
02d508a0: ldp     x30, x21, [sp, #0x20]                      
02d508a4: ldp     d9, d8, [sp, #0x10]                        
02d508a8: ldp     d11, d10, [sp], #0x40                      
02d508ac: ret                                                
02d508b0: bl      #0x2b7105c                                 fn_2b7105c
## .ctor() -> void
---- Blindbag.BlindBagAnimation::.ctor 0x2d509b4
02d509b4: mov     w8, #0x41a00000                            
02d509b8: mov     x1, xzr                                    
02d509bc: str     w8, [x0, #0x80]                            ._dragSpeed
02d509c0: b       #0x2cd6228                                 PoolElement::.ctor
