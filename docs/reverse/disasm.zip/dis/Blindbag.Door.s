#### CLASS Blindbag.Door/<>c__DisplayClass4_0 parent= object
#   field <>4__this                      Blindbag.Door                                      off=0x10 attr=6 
#   field onCompleted                    System.Action                                      off=0x18 attr=6 
## .ctor() -> void
---- Blindbag.Door/<>c__DisplayClass4_0::.ctor 0x2d532a0
02d532a0: mov     x1, xzr                                    
02d532a4: b       #0x4e53e9c                                 System.Object::.ctor
## <Open>b__0() -> void
---- Blindbag.Door/<>c__DisplayClass4_0::<Open>b__0 0x2d532b0
02d532b0: stp     x30, x19, [sp, #-0x10]!                    
02d532b4: ldr     x8, [x0, #0x10]                            .<>4__this
02d532b8: cbz     x8, #0x2d53354                             
02d532bc: mov     x19, x0                                    
02d532c0: ldr     x0, [x8, #0x20]                            
02d532c4: cbz     x0, #0x2d53354                             
02d532c8: mov     x1, xzr                                    
02d532cc: bl      #0x5b339ec                                 UnityEngine.Component::get_gameObject
02d532d0: cbz     x0, #0x2d53354                             
02d532d4: mov     w1, wzr                                    
02d532d8: mov     x2, xzr                                    
02d532dc: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d532e0: ldr     x8, [x19, #0x10]                           .<>4__this
02d532e4: cbz     x8, #0x2d53354                             
02d532e8: ldr     x0, [x8, #0x28]                            
02d532ec: cbz     x0, #0x2d53354                             
02d532f0: mov     x1, xzr                                    
02d532f4: bl      #0x5b339ec                                 UnityEngine.Component::get_gameObject
02d532f8: cbz     x0, #0x2d53354                             
02d532fc: mov     w1, wzr                                    
02d53300: mov     x2, xzr                                    
02d53304: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d53308: ldr     x8, [x19, #0x10]                           .<>4__this
02d5330c: cbz     x8, #0x2d53354                             
02d53310: ldr     x0, [x8, #0x30]                            
02d53314: cbz     x0, #0x2d53354                             
02d53318: mov     x1, xzr                                    
02d5331c: bl      #0x5b339ec                                 UnityEngine.Component::get_gameObject
02d53320: cbz     x0, #0x2d53354                             
02d53324: mov     w1, wzr                                    
02d53328: mov     x2, xzr                                    
02d5332c: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d53330: ldr     x8, [x19, #0x18]                           .onCompleted
02d53334: cbz     x8, #0x2d5334c                             
02d53338: ldr     x0, [x8, #0x40]                            
02d5333c: ldr     x1, [x8, #0x28]                            
02d53340: ldr     x2, [x8, #0x18]                            
02d53344: ldp     x30, x19, [sp], #0x10                      
02d53348: br      x2                                         
02d5334c: ldp     x30, x19, [sp], #0x10                      
02d53350: ret                                                
02d53354: bl      #0x2b7105c                                 fn_2b7105c
#### CLASS Blindbag.Door parent= UnityEngine.MonoBehaviour
#   field _leftDoor                      UnityEngine.SpriteRenderer                         off=0x20 attr=1 SerializeField
#   field _rightDoor                     UnityEngine.SpriteRenderer                         off=0x28 attr=1 SerializeField
#   field _roof                          UnityEngine.SpriteRenderer                         off=0x30 attr=1 SerializeField
## OnInit() -> void
---- Blindbag.Door::OnInit 0x2d517d4
02d517d4: movi    d0, #0000000000000000                      
02d517d8: b       #0x2d53144                                 Blindbag.Door::Hide
## Open(float duration, System.Action onCompleted) -> void
---- Blindbag.Door::Open 0x2d510a4
02d510a4: str     d8, [sp, #-0x40]!                          
02d510a8: str     x30, [sp, #8]                              
02d510ac: stp     x24, x23, [sp, #0x10]                      
02d510b0: stp     x22, x21, [sp, #0x20]                      
02d510b4: stp     x20, x19, [sp, #0x30]                      
02d510b8: fmov    s8, s0                                     
02d510bc: adrp    x20, #0x6630000                            
02d510c0: adrp    x22, #0x626b000                            
02d510c4: ldrb    w8, [x20, #0x265]                          
02d510c8: ldr     x22, [x22, #0x828]                         T:Blindbag.Door/<>c__DisplayClass4_0
02d510cc: mov     x21, x1                                    
02d510d0: mov     x19, x0                                    
02d510d4: tbnz    w8, #0, #0x2d5111c                         
02d510d8: adrp    x0, #0x6264000                             
02d510dc: ldr     x0, [x0, #0xe8]                            T:DG.Tweening.TweenCallback
02d510e0: bl      #0x2b70db0                                 fn_2b70db0
02d510e4: adrp    x0, #0x6266000                             
02d510e8: ldr     x0, [x0, #0x928]                           MS:DG.Tweening.TweenSettingsExtensions::OnComplete
02d510ec: bl      #0x2b70db0                                 fn_2b70db0
02d510f0: adrp    x0, #0x6266000                             
02d510f4: ldr     x0, [x0, #0x880]                           MS:DG.Tweening.TweenSettingsExtensions::SetEase
02d510f8: bl      #0x2b70db0                                 fn_2b70db0
02d510fc: adrp    x0, #0x626b000                             
02d51100: ldr     x0, [x0, #0x830]                           M:Blindbag.Door/<>c__DisplayClass4_0::<Open>b__0
02d51104: bl      #0x2b70db0                                 fn_2b70db0
02d51108: adrp    x0, #0x626b000                             
02d5110c: ldr     x0, [x0, #0x828]                           T:Blindbag.Door/<>c__DisplayClass4_0
02d51110: bl      #0x2b70db0                                 fn_2b70db0
02d51114: mov     w8, #1                                     
02d51118: strb    w8, [x20, #0x265]                          
02d5111c: ldr     x0, [x22]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d51120: bl      #0x2b7104c                                 fn_2b7104c
02d51124: mov     x1, xzr                                    
02d51128: mov     x20, x0                                    
02d5112c: bl      #0x4e53e9c                                 System.Object::.ctor
02d51130: cbz     x20, #0x2d51298                            
02d51134: mov     x0, x20                                    
02d51138: mov     x1, x19                                    
02d5113c: str     x19, [x0, #0x10]!                          
02d51140: bl      #0x2b70d54                                 fn_2b70d54
02d51144: mov     x0, x20                                    
02d51148: mov     x1, x21                                    
02d5114c: str     x21, [x0, #0x18]!                          
02d51150: bl      #0x2b70d54                                 fn_2b70d54
02d51154: mov     x0, xzr                                    
02d51158: bl      #0x2d6eec8                                 Framework.AudioManager::get_Instance
02d5115c: cbz     x0, #0x2d51298                             
02d51160: movi    d1, #0000000000000000                      
02d51164: movi    d2, #0000000000000000                      
02d51168: mov     w1, #0x16                                  
02d5116c: fmov    s0, #1.00000000                            
02d51170: mov     w2, wzr                                    
02d51174: mov     w3, wzr                                    
02d51178: mov     x4, xzr                                    
02d5117c: bl      #0x2d6f03c                                 Framework.AudioManager::PlaySound
02d51180: ldr     x0, [x19, #0x20]                           ._leftDoor
02d51184: mov     w1, wzr                                    
02d51188: mov     x2, xzr                                    
02d5118c: bl      #0x2d9d5d0                                 DG.Tweening.ShortcutExtensions::DOKill
02d51190: ldr     x0, [x19, #0x20]                           ._leftDoor
02d51194: cbz     x0, #0x2d51298                             
02d51198: adrp    x23, #0x6266000                            
02d5119c: mov     x1, xzr                                    
02d511a0: ldr     x23, [x23, #0x880]                         MS:DG.Tweening.TweenSettingsExtensions::SetEase
02d511a4: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02d511a8: fmov    s1, s8                                     
02d511ac: fmov    s0, #-10.00000000                          
02d511b0: mov     w1, wzr                                    
02d511b4: mov     x2, xzr                                    
02d511b8: bl      #0x2d97eac                                 DG.Tweening.ShortcutExtensions::DOLocalMoveX
02d511bc: ldr     x2, [x23]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d511c0: mov     w1, #6                                     
02d511c4: bl      #0x336fa0c                                 fn_336fa0c
02d511c8: ldr     x0, [x19, #0x28]                           ._rightDoor
02d511cc: mov     w1, wzr                                    
02d511d0: mov     x2, xzr                                    
02d511d4: bl      #0x2d9d5d0                                 DG.Tweening.ShortcutExtensions::DOKill
02d511d8: ldr     x0, [x19, #0x28]                           ._rightDoor
02d511dc: cbz     x0, #0x2d51298                             
02d511e0: adrp    x21, #0x6264000                            
02d511e4: adrp    x22, #0x626b000                            
02d511e8: adrp    x24, #0x6266000                            
02d511ec: ldr     x21, [x21, #0xe8]                          T:DG.Tweening.TweenCallback
02d511f0: ldr     x22, [x22, #0x830]                         M:Blindbag.Door/<>c__DisplayClass4_0::<Open>b__0
02d511f4: ldr     x24, [x24, #0x928]                         MS:DG.Tweening.TweenSettingsExtensions::OnComplete
02d511f8: mov     x1, xzr                                    
02d511fc: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02d51200: fmov    s1, s8                                     
02d51204: fmov    s0, #10.00000000                           
02d51208: mov     w1, wzr                                    
02d5120c: mov     x2, xzr                                    
02d51210: bl      #0x2d97eac                                 DG.Tweening.ShortcutExtensions::DOLocalMoveX
02d51214: ldr     x2, [x23]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d51218: mov     w1, #6                                     
02d5121c: bl      #0x336fa0c                                 fn_336fa0c
02d51220: ldr     x8, [x21]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d51224: mov     x21, x0                                    
02d51228: mov     x0, x8                                     
02d5122c: bl      #0x2b7104c                                 fn_2b7104c
02d51230: ldr     x2, [x22]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d51234: mov     x1, x20                                    
02d51238: mov     x3, xzr                                    
02d5123c: mov     x22, x0                                    
02d51240: bl      #0x2d89dc4                                 DG.Tweening.TweenCallback::.ctor
02d51244: ldr     x2, [x24]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d51248: mov     x0, x21                                    
02d5124c: mov     x1, x22                                    
02d51250: bl      #0x336f26c                                 fn_336f26c
02d51254: ldr     x0, [x19, #0x30]                           ._roof
02d51258: cbz     x0, #0x2d51298                             
02d5125c: mov     x1, xzr                                    
02d51260: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02d51264: fmov    s1, s8                                     
02d51268: fmov    s0, #13.50000000                           
02d5126c: mov     w1, wzr                                    
02d51270: mov     x2, xzr                                    
02d51274: bl      #0x2d98060                                 DG.Tweening.ShortcutExtensions::DOLocalMoveY
02d51278: ldr     x2, [x23]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d5127c: ldp     x20, x19, [sp, #0x30]                      
02d51280: ldp     x22, x21, [sp, #0x20]                      
02d51284: mov     w1, #6                                     
02d51288: ldp     x24, x23, [sp, #0x10]                      
02d5128c: ldr     x30, [sp, #8]                              
02d51290: ldr     d8, [sp], #0x40                            
02d51294: b       #0x336fa0c                                 
02d51298: bl      #0x2b7105c                                 fn_2b7105c
## Hide(float duration) -> void
---- Blindbag.Door::Hide 0x2d53144
02d53144: str     d8, [sp, #-0x20]!                          
02d53148: str     x30, [sp, #8]                              
02d5314c: stp     x20, x19, [sp, #0x10]                      
02d53150: fmov    s8, s0                                     
02d53154: adrp    x20, #0x6630000                            
02d53158: mov     x19, x0                                    
02d5315c: ldrb    w8, [x20, #0x266]                          
02d53160: tbnz    w8, #0, #0x2d53178                         
02d53164: adrp    x0, #0x6266000                             
02d53168: ldr     x0, [x0, #0x880]                           MS:DG.Tweening.TweenSettingsExtensions::SetEase
02d5316c: bl      #0x2b70db0                                 fn_2b70db0
02d53170: mov     w8, #1                                     
02d53174: strb    w8, [x20, #0x266]                          
02d53178: ldr     x0, [x19, #0x20]                           ._leftDoor
02d5317c: cbz     x0, #0x2d5329c                             
02d53180: mov     x1, xzr                                    
02d53184: bl      #0x5b339ec                                 UnityEngine.Component::get_gameObject
02d53188: cbz     x0, #0x2d5329c                             
02d5318c: mov     w1, #1                                     
02d53190: mov     x2, xzr                                    
02d53194: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d53198: ldr     x0, [x19, #0x28]                           ._rightDoor
02d5319c: cbz     x0, #0x2d5329c                             
02d531a0: mov     x1, xzr                                    
02d531a4: bl      #0x5b339ec                                 UnityEngine.Component::get_gameObject
02d531a8: cbz     x0, #0x2d5329c                             
02d531ac: mov     w1, #1                                     
02d531b0: mov     x2, xzr                                    
02d531b4: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d531b8: ldr     x0, [x19, #0x30]                           ._roof
02d531bc: cbz     x0, #0x2d5329c                             
02d531c0: mov     x1, xzr                                    
02d531c4: bl      #0x5b339ec                                 UnityEngine.Component::get_gameObject
02d531c8: cbz     x0, #0x2d5329c                             
02d531cc: mov     w1, #1                                     
02d531d0: mov     x2, xzr                                    
02d531d4: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d531d8: ldr     x0, [x19, #0x20]                           ._leftDoor
02d531dc: mov     w1, wzr                                    
02d531e0: mov     x2, xzr                                    
02d531e4: bl      #0x2d9d5d0                                 DG.Tweening.ShortcutExtensions::DOKill
02d531e8: ldr     x0, [x19, #0x20]                           ._leftDoor
02d531ec: cbz     x0, #0x2d5329c                             
02d531f0: adrp    x20, #0x6266000                            
02d531f4: mov     x1, xzr                                    
02d531f8: ldr     x20, [x20, #0x880]                         MS:DG.Tweening.TweenSettingsExtensions::SetEase
02d531fc: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02d53200: movi    d0, #0000000000000000                      
02d53204: fmov    s1, s8                                     
02d53208: mov     w1, wzr                                    
02d5320c: mov     x2, xzr                                    
02d53210: bl      #0x2d97eac                                 DG.Tweening.ShortcutExtensions::DOLocalMoveX
02d53214: ldr     x2, [x20]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d53218: mov     w1, #1                                     
02d5321c: bl      #0x336fa0c                                 fn_336fa0c
02d53220: ldr     x0, [x19, #0x28]                           ._rightDoor
02d53224: mov     w1, wzr                                    
02d53228: mov     x2, xzr                                    
02d5322c: bl      #0x2d9d5d0                                 DG.Tweening.ShortcutExtensions::DOKill
02d53230: ldr     x0, [x19, #0x28]                           ._rightDoor
02d53234: cbz     x0, #0x2d5329c                             
02d53238: mov     x1, xzr                                    
02d5323c: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02d53240: movi    d0, #0000000000000000                      
02d53244: fmov    s1, s8                                     
02d53248: mov     w1, wzr                                    
02d5324c: mov     x2, xzr                                    
02d53250: bl      #0x2d97eac                                 DG.Tweening.ShortcutExtensions::DOLocalMoveX
02d53254: ldr     x2, [x20]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d53258: mov     w1, #1                                     
02d5325c: bl      #0x336fa0c                                 fn_336fa0c
02d53260: ldr     x0, [x19, #0x30]                           ._roof
02d53264: cbz     x0, #0x2d5329c                             
02d53268: mov     x1, xzr                                    
02d5326c: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02d53270: fmov    s1, s8                                     
02d53274: fmov    s0, #8.00000000                            
02d53278: mov     w1, wzr                                    
02d5327c: mov     x2, xzr                                    
02d53280: bl      #0x2d98060                                 DG.Tweening.ShortcutExtensions::DOLocalMoveY
02d53284: ldr     x2, [x20]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d53288: ldp     x20, x19, [sp, #0x10]                      
02d5328c: ldr     x30, [sp, #8]                              
02d53290: mov     w1, #1                                     
02d53294: ldr     d8, [sp], #0x20                            
02d53298: b       #0x336fa0c                                 
02d5329c: bl      #0x2b7105c                                 fn_2b7105c
## .ctor() -> void
---- Blindbag.Door::.ctor 0x2d532a8
02d532a8: mov     x1, xzr                                    
02d532ac: b       #0x5b397b0                                 UnityEngine.MonoBehaviour::.ctor
