#### CLASS Games.SpineColorChanger/<ChangeColor>d__1 parent= System.ValueType
#   field <>1__state                     int                                                off=0x10 attr=6 
#   field <>t__builder                   System.Runtime.CompilerServices.AsyncVoidMethodBuilder off=0x18 attr=6 
#   field <>4__this                      Games.SpineColorChanger                            off=0x38 attr=6 
#   field color                          UnityEngine.Color                                  off=0x40 attr=6 
#   field <>u__1                         Cysharp.Threading.Tasks.UniTask/Awaiter            off=0x50 attr=1 
## MoveNext() -> void
---- Games.SpineColorChanger/<ChangeColor>d__1::MoveNext 0x2d2fa40
02d2fa40: sub     sp, sp, #0x70                              
02d2fa44: str     x30, [sp, #0x30]                           
02d2fa48: stp     x24, x23, [sp, #0x40]                      
02d2fa4c: stp     x22, x21, [sp, #0x50]                      
02d2fa50: stp     x20, x19, [sp, #0x60]                      
02d2fa54: adrp    x20, #0x6630000                            
02d2fa58: mov     x19, x0                                    
02d2fa5c: ldrb    w8, [x20, #0xec]                           
02d2fa60: tbnz    w8, #0, #0x2d2fa84                         
02d2fa64: adrp    x0, #0x626a000                             
02d2fa68: ldr     x0, [x0, #0x620]                           MS:System.Runtime.CompilerServices.AsyncVoidMethodBuilder::AwaitUnsafeOnCompleted
02d2fa6c: bl      #0x2b70db0                                 fn_2b70db0
02d2fa70: adrp    x0, #0x6266000                             
02d2fa74: ldr     x0, [x0, #0xcc8]                           T:Cysharp.Threading.Tasks.UniTask
02d2fa78: bl      #0x2b70db0                                 fn_2b70db0
02d2fa7c: mov     w8, #1                                     
02d2fa80: strb    w8, [x20, #0xec]                           
02d2fa84: ldr     w8, [x19]                                  
02d2fa88: ldr     x22, [x19, #0x28]                          
02d2fa8c: stp     xzr, xzr, [sp, #0x10]                      
02d2fa90: str     wzr, [sp, #8]                              
02d2fa94: cbz     w8, #0x2d2fb2c                             
02d2fa98: adrp    x23, #0x6266000                            
02d2fa9c: ldr     x23, [x23, #0xcc8]                         T:Cysharp.Threading.Tasks.UniTask
02d2faa0: ldr     x0, [x23]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d2faa4: ldr     w8, [x0, #0xe4]                            [62660e4]=0 f=0,0
02d2faa8: cbnz    w8, #0x2d2fab0                             
02d2faac: bl      #0x2b70f30                                 fn_2b70f30
02d2fab0: adrp    x8, #0x1084000                             
02d2fab4: mov     w0, wzr                                    
02d2fab8: mov     w1, #8                                     
02d2fabc: ldr     s0, [x8, #0xeec]                           [1084eec]=457ff0003dcccccd f=0.1,4095
02d2fac0: mov     x2, xzr                                    
02d2fac4: mov     w3, wzr                                    
02d2fac8: mov     x4, xzr                                    
02d2facc: bl      #0x5447b08                                 Cysharp.Threading.Tasks.UniTask::WaitForSeconds
02d2fad0: stp     x0, x1, [sp, #0x20]                        
02d2fad4: add     x0, sp, #0x20                              
02d2fad8: mov     x1, xzr                                    
02d2fadc: bl      #0x2b70d54                                 fn_2b70d54
02d2fae0: adrp    x24, #0x662f000                            
02d2fae4: ldp     x20, x21, [sp, #0x20]                      
02d2fae8: ldrb    w8, [x24, #0xbdc]                          
02d2faec: stp     x20, x21, [sp, #0x10]                      
02d2faf0: cbnz    w8, #0x2d2fb08                             
02d2faf4: adrp    x0, #0x6266000                             
02d2faf8: ldr     x0, [x0, #0xcc8]                           T:Cysharp.Threading.Tasks.UniTask
02d2fafc: bl      #0x2b70db0                                 fn_2b70db0
02d2fb00: mov     w8, #1                                     
02d2fb04: strb    w8, [x24, #0xbdc]                          
02d2fb08: ldr     x0, [x23]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d2fb0c: ldr     w8, [x0, #0xe4]                            [62660e4]=0 f=0,0
02d2fb10: cbnz    w8, #0x2d2fb18                             
02d2fb14: bl      #0x2b70f30                                 fn_2b70f30
02d2fb18: adrp    x23, #0x662f000                            
02d2fb1c: ldrb    w8, [x23, #0xbdd]                          
02d2fb20: cbz     w8, #0x2d2fb44                             
02d2fb24: cbnz    x20, #0x2d2fb5c                            
02d2fb28: b       #0x2d2fbc4                                 
02d2fb2c: ldr     q0, [x19, #0x40]                           .color
02d2fb30: mov     w8, #-1                                    
02d2fb34: stp     xzr, xzr, [x19, #0x40]                     .color
02d2fb38: str     w8, [x19]                                  
02d2fb3c: str     q0, [sp, #0x10]                            
02d2fb40: b       #0x2d2fbc4                                 
02d2fb44: adrp    x0, #0x6266000                             
02d2fb48: ldr     x0, [x0, #0xcd0]                           T:Cysharp.Threading.Tasks.IUniTaskSource
02d2fb4c: bl      #0x2b70db0                                 fn_2b70db0
02d2fb50: mov     w8, #1                                     
02d2fb54: strb    w8, [x23, #0xbdd]                          
02d2fb58: cbz     x20, #0x2d2fbc4                            
02d2fb5c: adrp    x10, #0x6266000                            
02d2fb60: ldr     x8, [x20]                                  
02d2fb64: ldr     x10, [x10, #0xcd0]                         T:Cysharp.Threading.Tasks.IUniTaskSource
02d2fb68: ldrh    w9, [x8, #0x12e]                           
02d2fb6c: ldr     x1, [x10]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d2fb70: cbz     x9, #0x2d2fb94                             
02d2fb74: ldr     x10, [x8, #0xb0]                           [10840b0]=2e656e69676e4579 f=1.1252e+24,5.21666e-11
02d2fb78: add     x10, x10, #8                               &6266008
02d2fb7c: ldur    x11, [x10, #-8]                            
02d2fb80: cmp     x11, x1                                    
02d2fb84: b.eq    #0x2d2fba4                                 
02d2fb88: subs    x9, x9, #1                                 
02d2fb8c: add     x10, x10, #0x10                            &6266010
02d2fb90: b.ne    #0x2d2fb7c                                 
02d2fb94: mov     x0, x20                                    
02d2fb98: mov     w2, wzr                                    
02d2fb9c: bl      #0x2baa05c                                 fn_2baa05c
02d2fba0: b       #0x2d2fbb0                                 
02d2fba4: ldrsw   x9, [x10]                                  
02d2fba8: add     x8, x8, x9, lsl #4                         &1084000
02d2fbac: add     x0, x8, #0x138                             &1084138
02d2fbb0: ldp     x8, x2, [x0]                               
02d2fbb4: mov     x0, x20                                    
02d2fbb8: mov     w1, w21                                    
02d2fbbc: blr     x8                                         
02d2fbc0: cbz     w0, #0x2d2fcc8                             
02d2fbc4: adrp    x20, #0x662f000                            
02d2fbc8: ldrb    w8, [x20, #0xbde]                          
02d2fbcc: cbnz    w8, #0x2d2fbe4                             
02d2fbd0: adrp    x0, #0x6266000                             
02d2fbd4: ldr     x0, [x0, #0xcd0]                           T:Cysharp.Threading.Tasks.IUniTaskSource
02d2fbd8: bl      #0x2b70db0                                 fn_2b70db0
02d2fbdc: mov     w8, #1                                     
02d2fbe0: strb    w8, [x20, #0xbde]                          
02d2fbe4: ldr     x20, [sp, #0x10]                           
02d2fbe8: cbz     x20, #0x2d2fc58                            
02d2fbec: adrp    x10, #0x6266000                            
02d2fbf0: ldr     x8, [x20]                                  &2b706c4(=eb01011ff9400808)
02d2fbf4: ldr     x10, [x10, #0xcd0]                         T:Cysharp.Threading.Tasks.IUniTaskSource
02d2fbf8: ldrh    w21, [sp, #0x18]                           
02d2fbfc: ldrh    w9, [x8, #0x12e]                           
02d2fc00: ldr     x1, [x10]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d2fc04: cbz     x9, #0x2d2fc28                             
02d2fc08: ldr     x10, [x8, #0xb0]                           [10840b0]=2e656e69676e4579 f=1.1252e+24,5.21666e-11
02d2fc0c: add     x10, x10, #8                               &6266008
02d2fc10: ldur    x11, [x10, #-8]                            
02d2fc14: cmp     x11, x1                                    
02d2fc18: b.eq    #0x2d2fc38                                 
02d2fc1c: subs    x9, x9, #1                                 
02d2fc20: add     x10, x10, #0x10                            &6266010
02d2fc24: b.ne    #0x2d2fc10                                 
02d2fc28: mov     x0, x20                                    
02d2fc2c: mov     w2, #2                                     
02d2fc30: bl      #0x2baa05c                                 fn_2baa05c
02d2fc34: b       #0x2d2fc48                                 
02d2fc38: ldr     w9, [x10]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d2fc3c: add     w9, w9, #2                                 
02d2fc40: add     x8, x8, w9, sxtw #4                        &1084000
02d2fc44: add     x0, x8, #0x138                             &1084138
02d2fc48: ldp     x8, x2, [x0]                               
02d2fc4c: mov     x0, x20                                    
02d2fc50: mov     w1, w21                                    
02d2fc54: blr     x8                                         
02d2fc58: cbz     x22, #0x2d2fd00                            
02d2fc5c: ldr     x0, [x22, #0x20]                           
02d2fc60: cbz     x0, #0x2d2fd04                             
02d2fc64: mov     x1, xzr                                    
02d2fc68: bl      #0x5b04738                                 UnityEngine.Renderer::get_material
02d2fc6c: mov     x20, x0                                    
02d2fc70: cbz     x0, #0x2d2fd08                             
02d2fc74: ldp     s2, s3, [x19, #0x38]                       .<>4__this
02d2fc78: ldp     s0, s1, [x19, #0x30]                       
02d2fc7c: mov     x0, x20                                    
02d2fc80: mov     x1, xzr                                    
02d2fc84: bl      #0x5b06238                                 UnityEngine.Material::set_color
02d2fc88: ldr     x0, [x22, #0x20]                           
02d2fc8c: cbz     x0, #0x2d2fd0c                             
02d2fc90: mov     x1, x20                                    
02d2fc94: mov     x2, xzr                                    
02d2fc98: bl      #0x5b0473c                                 UnityEngine.Renderer::set_material
02d2fc9c: mov     w8, #-2                                    
02d2fca0: mov     x1, xzr                                    
02d2fca4: str     w8, [x19], #8                              
02d2fca8: mov     x0, x19                                    
02d2fcac: bl      #0x4d43b50                                 System.Runtime.CompilerServices.AsyncVoidMethodBuilder::SetResult
02d2fcb0: ldp     x20, x19, [sp, #0x60]                      
02d2fcb4: ldr     x30, [sp, #0x30]                           
02d2fcb8: ldp     x22, x21, [sp, #0x50]                      
02d2fcbc: ldp     x24, x23, [sp, #0x40]                      
02d2fcc0: add     sp, sp, #0x70                              
02d2fcc4: ret                                                
02d2fcc8: ldr     q0, [sp, #0x10]                            
02d2fccc: str     wzr, [x19]                                 
02d2fcd0: str     q0, [x19, #0x40]                           .color
02d2fcd4: add     x0, x19, #0x40                             
02d2fcd8: mov     x1, xzr                                    
02d2fcdc: bl      #0x2b70d54                                 fn_2b70d54
02d2fce0: adrp    x8, #0x626a000                             
02d2fce4: ldr     x8, [x8, #0x620]                           MS:System.Runtime.CompilerServices.AsyncVoidMethodBuilder::AwaitUnsafeOnCompleted
02d2fce8: ldr     x3, [x8]                                   T:type56879(k15)
02d2fcec: add     x0, x19, #8                                
02d2fcf0: add     x1, sp, #0x10                              
02d2fcf4: mov     x2, x19                                    
02d2fcf8: bl      #0x30c4cd8                                 fn_30c4cd8
02d2fcfc: b       #0x2d2fcb0                                 
02d2fd00: bl      #0x2b7105c                                 fn_2b7105c
02d2fd04: bl      #0x2b7105c                                 fn_2b7105c
02d2fd08: bl      #0x2b7105c                                 fn_2b7105c
02d2fd0c: bl      #0x2b7105c                                 fn_2b7105c
02d2fd10: b       #0x2d2fd3c                                 
02d2fd14: b       #0x2d2fd3c                                 
02d2fd18: b       #0x2d2fd3c                                 
02d2fd1c: b       #0x2d2fd3c                                 
02d2fd20: b       #0x2d2fd3c                                 
02d2fd24: b       #0x2d2fd3c                                 
02d2fd28: b       #0x2d2fd3c                                 
02d2fd2c: b       #0x2d2fd3c                                 
02d2fd30: b       #0x2d2fd3c                                 
02d2fd34: b       #0x2d2fd3c                                 
02d2fd38: b       #0x2d2fd3c                                 
02d2fd3c: mov     x20, x0                                    
02d2fd40: cmp     w1, #1                                     
02d2fd44: b.ne    #0x2d2fdd4                                 
02d2fd48: mov     x0, x20                                    
02d2fd4c: bl      #0x5e90260                                 fn_5e90260
02d2fd50: mov     x20, x0                                    
02d2fd54: adrp    x0, #0x6263000                             
02d2fd58: ldr     x0, [x0, #0xae0]                           T:System.Exception
02d2fd5c: bl      #0x2b70dc4                                 fn_2b70dc4
02d2fd60: ldr     x8, [x20]                                  &2b706c4(=eb01011ff9400808)
02d2fd64: ldr     x1, [x8]                                   T:type56879(k15)
02d2fd68: bl      #0x2b71464                                 fn_2b71464
02d2fd6c: tbz     w0, #0, #0x2d2fdac                         
02d2fd70: ldrsw   x21, [sp, #8]                              
02d2fd74: ldr     x20, [x20]                                 &2b706c4(=eb01011ff9400808)
02d2fd78: mov     x8, sp                                     
02d2fd7c: str     x20, [x8, x21, lsl #3]                     
02d2fd80: add     w8, w21, #1                                
02d2fd84: str     w8, [sp, #8]                               
02d2fd88: bl      #0x5e90270                                 fn_5e90270
02d2fd8c: mov     w8, #-2                                    
02d2fd90: mov     x1, x20                                    
02d2fd94: mov     x2, xzr                                    
02d2fd98: str     w8, [x19], #8                              
02d2fd9c: mov     x0, x19                                    
02d2fda0: bl      #0x4d43cc0                                 System.Runtime.CompilerServices.AsyncVoidMethodBuilder::SetException
02d2fda4: str     w21, [sp, #8]                              
02d2fda8: b       #0x2d2fcb0                                 
02d2fdac: mov     w0, #8                                     
02d2fdb0: bl      #0x5e90290                                 fn_5e90290
02d2fdb4: ldr     x8, [x20]                                  &2b706c4(=eb01011ff9400808)
02d2fdb8: str     x8, [x0]                                   
02d2fdbc: adrp    x1, #0x5e96000                             
02d2fdc0: add     x1, x1, #0x758                             &5e96758
02d2fdc4: mov     x2, xzr                                    
02d2fdc8: bl      #0x5e902a0                                 fn_5e902a0
02d2fdcc: mov     x20, x0                                    
02d2fdd0: bl      #0x5e90270                                 fn_5e90270
02d2fdd4: mov     x0, x20                                    
02d2fdd8: bl      #0x2c6051c                                 fn_2c6051c
02d2fddc: bl      #0x27369b8                                 fn_27369b8
## SetStateMachine(System.Runtime.CompilerServices.IAsyncStateMachine stateMachine) -> void
---- Games.SpineColorChanger/<ChangeColor>d__1::SetStateMachine 0x2d2fde0
02d2fde0: add     x0, x0, #8                                 
02d2fde4: mov     x2, xzr                                    
02d2fde8: b       #0x4d43a8c                                 System.Runtime.CompilerServices.AsyncVoidMethodBuilder::SetStateMachine
#### CLASS Games.SpineColorChanger parent= UnityEngine.MonoBehaviour
#   field _meshRenderer                  UnityEngine.MeshRenderer                           off=0x20 attr=1 SerializeField
## ChangeColor(UnityEngine.Color color) -> void
---- Games.SpineColorChanger::ChangeColor 0x2d2f910
02d2f910: sub     sp, sp, #0xb0                              
02d2f914: stp     d11, d10, [sp, #0x70]                      
02d2f918: stp     d9, d8, [sp, #0x80]                        
02d2f91c: stp     x30, x21, [sp, #0x90]                      
02d2f920: stp     x20, x19, [sp, #0xa0]                      
02d2f924: fmov    s8, s3                                     
02d2f928: fmov    s9, s2                                     
02d2f92c: adrp    x21, #0x6630000                            
02d2f930: fmov    s10, s1                                    
02d2f934: fmov    s11, s0                                    
02d2f938: adrp    x20, #0x626a000                            
02d2f93c: ldrb    w8, [x21, #0xeb]                           
02d2f940: ldr     x20, [x20, #0x618]                         MS:System.Runtime.CompilerServices.AsyncVoidMethodBuilder::Start
02d2f944: mov     x19, x0                                    
02d2f948: tbnz    w8, #0, #0x2d2f960                         
02d2f94c: adrp    x0, #0x626a000                             
02d2f950: ldr     x0, [x0, #0x618]                           MS:System.Runtime.CompilerServices.AsyncVoidMethodBuilder::Start
02d2f954: bl      #0x2b70db0                                 fn_2b70db0
02d2f958: mov     w8, #1                                     
02d2f95c: strb    w8, [x21, #0xeb]                           
02d2f960: movi    v0.2d, #0000000000000000                   
02d2f964: mov     x8, sp                                     
02d2f968: mov     x0, xzr                                    
02d2f96c: stp     q0, q0, [sp, #0x30]                        
02d2f970: stp     q0, q0, [sp, #0x50]                        
02d2f974: str     q0, [sp, #0x20]                            
02d2f978: bl      #0x4d43a24                                 System.Runtime.CompilerServices.AsyncVoidMethodBuilder::Create
02d2f97c: ldp     q0, q1, [sp]                               
02d2f980: add     x21, sp, #0x20                             
02d2f984: orr     x0, x21, #8                                
02d2f988: mov     x1, xzr                                    
02d2f98c: stur    q0, [sp, #0x28]                            
02d2f990: stur    q1, [sp, #0x38]                            
02d2f994: bl      #0x2b70d54                                 fn_2b70d54
02d2f998: add     x0, x21, #0x28                             &6630028
02d2f99c: mov     x1, x19                                    
02d2f9a0: str     x19, [sp, #0x48]                           
02d2f9a4: bl      #0x2b70d54                                 fn_2b70d54
02d2f9a8: ldr     x2, [x20]                                  T:type56879(k15)
02d2f9ac: mov     w8, #-1                                    
02d2f9b0: orr     x0, x21, #8                                
02d2f9b4: add     x1, sp, #0x20                              
02d2f9b8: stp     s11, s10, [sp, #0x50]                      
02d2f9bc: stp     s9, s8, [sp, #0x58]                        
02d2f9c0: str     w8, [sp, #0x20]                            
02d2f9c4: bl      #0x30c946c                                 fn_30c946c
02d2f9c8: ldp     x20, x19, [sp, #0xa0]                      
02d2f9cc: ldp     x30, x21, [sp, #0x90]                      
02d2f9d0: ldp     d9, d8, [sp, #0x80]                        
02d2f9d4: ldp     d11, d10, [sp, #0x70]                      
02d2f9d8: add     sp, sp, #0xb0                              
02d2f9dc: ret                                                
## ChangeColor(string hexColor) -> void
---- Games.SpineColorChanger::ChangeColor 0x2d2f9e0
02d2f9e0: sub     sp, sp, #0x20                              
02d2f9e4: stp     x30, x19, [sp, #0x10]                      
02d2f9e8: mov     x8, x1                                     
02d2f9ec: mov     x19, x0                                    
02d2f9f0: mov     x1, sp                                     
02d2f9f4: mov     x0, x8                                     
02d2f9f8: mov     x2, xzr                                    
02d2f9fc: stp     xzr, xzr, [sp]                             
02d2fa00: bl      #0x5b20fb8                                 UnityEngine.ColorUtility::TryParseHtmlString
02d2fa04: ldr     x0, [x19, #0x20]                           ._meshRenderer
02d2fa08: cbz     x0, #0x2d2fa34                             
02d2fa0c: mov     x1, xzr                                    
02d2fa10: bl      #0x5b04738                                 UnityEngine.Renderer::get_material
02d2fa14: cbz     x0, #0x2d2fa34                             
02d2fa18: ldp     s2, s3, [sp, #8]                           
02d2fa1c: mov     x1, xzr                                    
02d2fa20: ldp     s0, s1, [sp]                               
02d2fa24: bl      #0x5b06238                                 UnityEngine.Material::set_color
02d2fa28: ldp     x30, x19, [sp, #0x10]                      
02d2fa2c: add     sp, sp, #0x20                              
02d2fa30: ret                                                
02d2fa34: bl      #0x2b7105c                                 fn_2b7105c
## .ctor() -> void
---- Games.SpineColorChanger::.ctor 0x2d2fa38
02d2fa38: mov     x1, xzr                                    
02d2fa3c: b       #0x5b397b0                                 UnityEngine.MonoBehaviour::.ctor
