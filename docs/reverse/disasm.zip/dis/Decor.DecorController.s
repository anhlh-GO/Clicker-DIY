#### CLASS Decor.DecorController/<>c__DisplayClass11_0 parent= object
#   field categoryAsset                  Decor.CategoryAsset                                off=0x10 attr=6 
## .ctor() -> void
---- Decor.DecorController/<>c__DisplayClass11_0::.ctor 0x2d26a00
02d26a00: mov     x1, xzr                                    
02d26a04: b       #0x4e53e9c                                 System.Object::.ctor
## <OnOptionSelected>b__0(Decor.IItemChanger c) -> bool
---- Decor.DecorController/<>c__DisplayClass11_0::<OnOptionSelected>b__0 0x2d26c28
02d26c28: stp     x30, x19, [sp, #-0x10]!                    
02d26c2c: cbz     x1, #0x2d26c68                             
02d26c30: mov     x19, x0                                    
02d26c34: mov     x0, x1                                     
02d26c38: mov     x1, xzr                                    
02d26c3c: bl      #0x4e54610                                 System.Object::GetType
02d26c40: cbz     x0, #0x2d26c68                             
02d26c44: ldr     x8, [x0]                                   
02d26c48: ldp     x9, x1, [x8, #0x1b8]                       
02d26c4c: blr     x9                                         
02d26c50: ldr     x8, [x19, #0x10]                           .categoryAsset
02d26c54: cbz     x8, #0x2d26c68                             
02d26c58: ldr     x1, [x8, #0x18]                            
02d26c5c: mov     x2, xzr                                    
02d26c60: ldp     x30, x19, [sp], #0x10                      
02d26c64: b       #0x4ca52b8                                 System.String::op_Equality
02d26c68: bl      #0x2b7105c                                 fn_2b7105c
#### CLASS Decor.DecorController parent= MonoSingleton`1<Decor.DecorController>
#   field _itemChangers                  System.Collections.Generic.List`1<Decor.IItemChanger> off=0x20 attr=1 
#   field _characterMotion               Character.MotionStateMachine                       off=0x28 attr=1 
#   field _gameSession                   GameSession                                        off=0x30 attr=1 
#   field _decorAsset                    Decor.DecorAsset                                   off=0x38 attr=1 
#   field _dataDecor                     Decor.DataDecor                                    off=0x40 attr=1 
## get_CharacterMotion() -> Character.MotionStateMachine
---- Decor.DecorController::get_CharacterMotion 0x2d26228
02d26228: ldr     x0, [x0, #0x28]                            ._characterMotion
02d2622c: ret                                                
## Initiate() -> void
---- Decor.DecorController::Initiate 0x2d26230
02d26230: str     x30, [sp, #-0x30]!                         
02d26234: stp     x22, x21, [sp, #0x10]                      
02d26238: stp     x20, x19, [sp, #0x20]                      
02d2623c: adrp    x21, #0x6630000                            
02d26240: adrp    x22, #0x626a000                            
02d26244: adrp    x20, #0x6266000                            
02d26248: ldrb    w8, [x21, #0x80]                           
02d2624c: ldr     x22, [x22, #0x90]                          MS:MonoSingleton`1::Initiate
02d26250: ldr     x20, [x20, #0x658]                         MS:MonoSingleton`1::get_Instance
02d26254: mov     x19, x0                                    
02d26258: tbnz    w8, #0, #0x2d26294                         
02d2625c: adrp    x0, #0x6266000                             
02d26260: ldr     x0, [x0, #0x870]                           MS:DataManager::GetAsset
02d26264: bl      #0x2b70db0                                 fn_2b70db0
02d26268: adrp    x0, #0x6266000                             
02d2626c: ldr     x0, [x0, #0x878]                           MS:DataManager::GetData
02d26270: bl      #0x2b70db0                                 fn_2b70db0
02d26274: adrp    x0, #0x626a000                             
02d26278: ldr     x0, [x0, #0x90]                            MS:MonoSingleton`1::Initiate
02d2627c: bl      #0x2b70db0                                 fn_2b70db0
02d26280: adrp    x0, #0x6266000                             
02d26284: ldr     x0, [x0, #0x658]                           MS:MonoSingleton`1::get_Instance
02d26288: bl      #0x2b70db0                                 fn_2b70db0
02d2628c: mov     w8, #1                                     
02d26290: strb    w8, [x21, #0x80]                           
02d26294: ldr     x1, [x22]                                  T:type56879(k15)
02d26298: mov     x0, x19                                    
02d2629c: bl      #0x3769de4                                 fn_3769de4
02d262a0: ldr     x0, [x20]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d262a4: bl      #0x3769600                                 fn_3769600
02d262a8: cbz     x0, #0x2d26304                             
02d262ac: adrp    x8, #0x6266000                             
02d262b0: ldr     x8, [x8, #0x870]                           MS:DataManager::GetAsset
02d262b4: ldr     x1, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d262b8: bl      #0x3168af0                                 fn_3168af0
02d262bc: mov     x1, x0                                     
02d262c0: mov     x0, x19                                    
02d262c4: str     x1, [x0, #0x38]!                           ._decorAsset
02d262c8: bl      #0x2b70d54                                 fn_2b70d54
02d262cc: ldr     x0, [x20]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d262d0: bl      #0x3769600                                 fn_3769600
02d262d4: cbz     x0, #0x2d26304                             
02d262d8: adrp    x8, #0x6266000                             
02d262dc: ldr     x8, [x8, #0x878]                           MS:DataManager::GetData
02d262e0: ldr     x1, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d262e4: bl      #0x3168dd0                                 fn_3168dd0
02d262e8: str     x0, [x19, #0x40]!                          ._dataDecor
02d262ec: mov     x1, x0                                     
02d262f0: mov     x0, x19                                    
02d262f4: ldp     x20, x19, [sp, #0x20]                      
02d262f8: ldp     x22, x21, [sp, #0x10]                      
02d262fc: ldr     x30, [sp], #0x30                           
02d26300: b       #0x2b70d54                                 
02d26304: bl      #0x2b7105c                                 fn_2b7105c
## Start() -> void
---- Decor.DecorController::Start 0x2d26308
02d26308: str     x30, [sp, #-0x30]!                         
02d2630c: stp     x22, x21, [sp, #0x10]                      
02d26310: stp     x20, x19, [sp, #0x20]                      
02d26314: adrp    x20, #0x6630000                            
02d26318: adrp    x21, #0x6266000                            
02d2631c: mov     x19, x0                                    
02d26320: ldrb    w8, [x20, #0x81]                           
02d26324: ldr     x21, [x21, #0xac0]                         MS:MonoSingleton`1::get_Instance
02d26328: tbnz    w8, #0, #0x2d263a0                         
02d2632c: adrp    x0, #0x6263000                             
02d26330: ldr     x0, [x0, #0x928]                           T:UnityEngine.Debug
02d26334: bl      #0x2b70db0                                 fn_2b70db0
02d26338: adrp    x0, #0x626a000                             
02d2633c: ldr     x0, [x0, #0x98]                            MS:System.Linq.Enumerable::OfType
02d26340: bl      #0x2b70db0                                 fn_2b70db0
02d26344: adrp    x0, #0x626a000                             
02d26348: ldr     x0, [x0, #0xa0]                            MS:UnityEngine.GameObject::GetComponent
02d2634c: bl      #0x2b70db0                                 fn_2b70db0
02d26350: adrp    x0, #0x626a000                             
02d26354: ldr     x0, [x0, #0xa8]                            MS:System.Collections.Generic.List`1::.ctor
02d26358: bl      #0x2b70db0                                 fn_2b70db0
02d2635c: adrp    x0, #0x626a000                             
02d26360: ldr     x0, [x0, #0xb0]                            T:type56715(k15)
02d26364: bl      #0x2b70db0                                 fn_2b70db0
02d26368: adrp    x0, #0x6266000                             
02d2636c: ldr     x0, [x0, #0xac0]                           MS:MonoSingleton`1::get_Instance
02d26370: bl      #0x2b70db0                                 fn_2b70db0
02d26374: adrp    x0, #0x626a000                             
02d26378: ldr     x0, [x0, #0xb8]                            MS:UnityEngine.Object::FindObjectsOfType
02d2637c: bl      #0x2b70db0                                 fn_2b70db0
02d26380: adrp    x0, #0x6263000                             
02d26384: ldr     x0, [x0, #0x918]                           T:UnityEngine.Object
02d26388: bl      #0x2b70db0                                 fn_2b70db0
02d2638c: adrp    x0, #0x626a000                             
02d26390: ldr     x0, [x0, #0xc0]                            S:'Main character is null'
02d26394: bl      #0x2b70db0                                 fn_2b70db0
02d26398: mov     w8, #1                                     
02d2639c: strb    w8, [x20, #0x81]                           
02d263a0: ldr     x0, [x21]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d263a4: bl      #0x3769600                                 fn_3769600
02d263a8: mov     x20, x19                                   
02d263ac: mov     x1, x0                                     
02d263b0: str     x0, [x20, #0x30]!                          ._gameSession
02d263b4: mov     x0, x20                                    
02d263b8: bl      #0x2b70d54                                 fn_2b70d54
02d263bc: ldr     x0, [x20]                                  
02d263c0: cbz     x0, #0x2d26524                             
02d263c4: mov     w1, #1                                     
02d263c8: mov     x2, xzr                                    
02d263cc: bl      #0x2cacd8c                                 GameSession::SetActiveCharacter
02d263d0: ldr     x0, [x20]                                  
02d263d4: cbz     x0, #0x2d26524                             
02d263d8: mov     w1, #1                                     
02d263dc: mov     x2, xzr                                    
02d263e0: bl      #0x2cace00                                 GameSession::SetActiveBackground
02d263e4: ldr     x8, [x20]                                  
02d263e8: cbz     x8, #0x2d26524                             
02d263ec: adrp    x22, #0x6263000                            
02d263f0: ldr     x22, [x22, #0x918]                         T:UnityEngine.Object
02d263f4: ldr     x21, [x8, #0x20]                           
02d263f8: ldr     x0, [x22]                                  &2c5bbd4(=a9bd7bfdd503233f)
02d263fc: ldr     w9, [x0, #0xe4]                            [626a0e4]=0 f=0,0
02d26400: cbnz    w9, #0x2d26408                             
02d26404: bl      #0x2b70f30                                 fn_2b70f30
02d26408: mov     x0, x21                                    
02d2640c: mov     x1, xzr                                    
02d26410: mov     x2, xzr                                    
02d26414: bl      #0x5b37d84                                 UnityEngine.Object::op_Equality
02d26418: tbz     w0, #0, #0x2d26454                         
02d2641c: adrp    x8, #0x6263000                             
02d26420: ldr     x8, [x8, #0x928]                           T:UnityEngine.Debug
02d26424: ldr     x0, [x8]                                   &2c5bbd4(=a9bd7bfdd503233f)
02d26428: ldr     w8, [x0, #0xe4]                            [626a0e4]=0 f=0,0
02d2642c: cbnz    w8, #0x2d26434                             
02d26430: bl      #0x2b70f30                                 fn_2b70f30
02d26434: adrp    x8, #0x626a000                             
02d26438: mov     x1, xzr                                    
02d2643c: ldr     x8, [x8, #0xc0]                            S:'Main character is null'
02d26440: ldp     x20, x19, [sp, #0x20]                      
02d26444: ldp     x22, x21, [sp, #0x10]                      
02d26448: ldr     x0, [x8]                                   T:type56879(k15)
02d2644c: ldr     x30, [sp], #0x30                           
02d26450: b       #0x5af2840                                 UnityEngine.Debug::LogError
02d26454: ldr     x8, [x20]                                  
02d26458: cbz     x8, #0x2d26524                             
02d2645c: ldr     x0, [x8, #0x20]                            M:Decor.DataDecor/<>c__DisplayClass8_0::<NewData>b__0
02d26460: cbz     x0, #0x2d26524                             
02d26464: adrp    x8, #0x626a000                             
02d26468: ldr     x8, [x8, #0xa0]                            MS:UnityEngine.GameObject::GetComponent
02d2646c: ldr     x1, [x8]                                   T:type56879(k15)
02d26470: bl      #0x31d11a4                                 fn_31d11a4
02d26474: mov     x20, x19                                   
02d26478: mov     x1, x0                                     
02d2647c: str     x0, [x20, #0x28]!                          ._characterMotion
02d26480: mov     x0, x20                                    
02d26484: bl      #0x2b70d54                                 fn_2b70d54
02d26488: ldr     x0, [x20]                                  
02d2648c: cbz     x0, #0x2d26524                             
02d26490: ldr     x1, [x0, #0x38]                            MS:System.Collections.Generic.List`1::get_Item ._decorAsset
02d26494: mov     w2, #1                                     
02d26498: mov     x3, xzr                                    
02d2649c: bl      #0x2d75ce8                                 Character.MotionStateMachine::ChangeState
02d264a0: ldr     x0, [x22]                                  &2c5bbd4(=a9bd7bfdd503233f)
02d264a4: ldr     w8, [x0, #0xe4]                            [626a0e4]=0 f=0,0
02d264a8: cbnz    w8, #0x2d264b0                             
02d264ac: bl      #0x2b70f30                                 fn_2b70f30
02d264b0: adrp    x8, #0x626a000                             
02d264b4: ldr     x8, [x8, #0xb8]                            MS:UnityEngine.Object::FindObjectsOfType
02d264b8: ldr     x0, [x8]                                   T:type56879(k15)
02d264bc: bl      #0x3275dfc                                 fn_3275dfc
02d264c0: adrp    x8, #0x626a000                             
02d264c4: ldr     x8, [x8, #0x98]                            MS:System.Linq.Enumerable::OfType
02d264c8: ldr     x1, [x8]                                   T:type56879(k15)
02d264cc: bl      #0x318eccc                                 fn_318eccc
02d264d0: adrp    x8, #0x626a000                             
02d264d4: mov     x20, x0                                    
02d264d8: ldr     x8, [x8, #0xb0]                            T:type56715(k15)
02d264dc: ldr     x8, [x8]                                   T:type56879(k15)
02d264e0: mov     x0, x8                                     
02d264e4: bl      #0x2b7104c                                 fn_2b7104c
02d264e8: adrp    x8, #0x626a000                             
02d264ec: mov     x1, x20                                    
02d264f0: mov     x21, x0                                    
02d264f4: ldr     x8, [x8, #0xa8]                            MS:System.Collections.Generic.List`1::.ctor
02d264f8: ldr     x2, [x8]                                   T:type56879(k15)
02d264fc: bl      #0x35a8ae0                                 fn_35a8ae0
02d26500: mov     x0, x19                                    
02d26504: mov     x1, x21                                    
02d26508: str     x21, [x0, #0x20]!                          ._itemChangers
02d2650c: bl      #0x2b70d54                                 fn_2b70d54
02d26510: mov     x0, x19                                    
02d26514: ldp     x20, x19, [sp, #0x20]                      
02d26518: ldp     x22, x21, [sp, #0x10]                      
02d2651c: ldr     x30, [sp], #0x30                           
02d26520: b       #0x2d26528                                 Decor.DecorController::SetupSavedOptions
02d26524: bl      #0x2b7105c                                 fn_2b7105c
## OnEnable() -> void
---- Decor.DecorController::OnEnable 0x2d26588
02d26588: str     x30, [sp, #-0x30]!                         
02d2658c: stp     x22, x21, [sp, #0x10]                      
02d26590: stp     x20, x19, [sp, #0x20]                      
02d26594: adrp    x21, #0x6630000                            
02d26598: adrp    x22, #0x626a000                            
02d2659c: adrp    x20, #0x626a000                            
02d265a0: ldrb    w8, [x21, #0x82]                           
02d265a4: ldr     x22, [x22, #0xc8]                          T:type19696(k15)
02d265a8: ldr     x20, [x20, #0xd0]                          M:Decor.DecorController::OnOptionSelected
02d265ac: mov     x19, x0                                    
02d265b0: tbnz    w8, #0, #0x2d265d4                         
02d265b4: adrp    x0, #0x626a000                             
02d265b8: ldr     x0, [x0, #0xd0]                            M:Decor.DecorController::OnOptionSelected
02d265bc: bl      #0x2b70db0                                 fn_2b70db0
02d265c0: adrp    x0, #0x626a000                             
02d265c4: ldr     x0, [x0, #0xc8]                            T:type19696(k15)
02d265c8: bl      #0x2b70db0                                 fn_2b70db0
02d265cc: mov     w8, #1                                     
02d265d0: strb    w8, [x21, #0x82]                           
02d265d4: ldr     x0, [x22]                                  T:type56879(k15)
02d265d8: bl      #0x2b7104c                                 fn_2b7104c
02d265dc: ldr     x2, [x20]                                  T:type56879(k15)
02d265e0: mov     x1, x19                                    
02d265e4: mov     x3, xzr                                    
02d265e8: mov     x20, x0                                    
02d265ec: bl      #0x3edfee4                                 fn_3edfee4
02d265f0: mov     x0, x20                                    
02d265f4: ldp     x20, x19, [sp, #0x20]                      
02d265f8: ldp     x22, x21, [sp, #0x10]                      
02d265fc: ldr     x30, [sp], #0x30                           
02d26600: b       #0x2d26604                                 Decor.OptionPanel::add_OnOptionSelected
## OnDisable() -> void
---- Decor.DecorController::OnDisable 0x2d266d0
02d266d0: str     x30, [sp, #-0x30]!                         
02d266d4: stp     x22, x21, [sp, #0x10]                      
02d266d8: stp     x20, x19, [sp, #0x20]                      
02d266dc: adrp    x21, #0x6630000                            
02d266e0: adrp    x22, #0x626a000                            
02d266e4: adrp    x20, #0x626a000                            
02d266e8: ldrb    w8, [x21, #0x83]                           
02d266ec: ldr     x22, [x22, #0xc8]                          T:type19696(k15)
02d266f0: ldr     x20, [x20, #0xd0]                          M:Decor.DecorController::OnOptionSelected
02d266f4: mov     x19, x0                                    
02d266f8: tbnz    w8, #0, #0x2d2671c                         
02d266fc: adrp    x0, #0x626a000                             
02d26700: ldr     x0, [x0, #0xd0]                            M:Decor.DecorController::OnOptionSelected
02d26704: bl      #0x2b70db0                                 fn_2b70db0
02d26708: adrp    x0, #0x626a000                             
02d2670c: ldr     x0, [x0, #0xc8]                            T:type19696(k15)
02d26710: bl      #0x2b70db0                                 fn_2b70db0
02d26714: mov     w8, #1                                     
02d26718: strb    w8, [x21, #0x83]                           
02d2671c: ldr     x0, [x22]                                  T:type56879(k15)
02d26720: bl      #0x2b7104c                                 fn_2b7104c
02d26724: ldr     x2, [x20]                                  T:type56879(k15)
02d26728: mov     x1, x19                                    
02d2672c: mov     x3, xzr                                    
02d26730: mov     x20, x0                                    
02d26734: bl      #0x3edfee4                                 fn_3edfee4
02d26738: mov     x0, x20                                    
02d2673c: ldp     x20, x19, [sp, #0x20]                      
02d26740: ldp     x22, x21, [sp, #0x10]                      
02d26744: ldr     x30, [sp], #0x30                           
02d26748: b       #0x2d2674c                                 Decor.OptionPanel::remove_OnOptionSelected
## OnOptionSelected(int categoryIndex, int optionID) -> void
---- Decor.DecorController::OnOptionSelected 0x2d26818
02d26818: stp     x30, x25, [sp, #-0x40]!                    
02d2681c: stp     x24, x23, [sp, #0x10]                      
02d26820: stp     x22, x21, [sp, #0x20]                      
02d26824: stp     x20, x19, [sp, #0x30]                      
02d26828: adrp    x21, #0x6630000                            
02d2682c: adrp    x23, #0x626a000                            
02d26830: mov     w19, w2                                    
02d26834: ldrb    w8, [x21, #0x84]                           
02d26838: ldr     x23, [x23, #0xe0]                          T:Decor.DecorController/<>c__DisplayClass11_0
02d2683c: mov     w20, w1                                    
02d26840: mov     x22, x0                                    
02d26844: tbnz    w8, #0, #0x2d26898                         
02d26848: adrp    x0, #0x626a000                             
02d2684c: ldr     x0, [x0, #0xe8]                            T:Decor.IItemChanger
02d26850: bl      #0x2b70db0                                 fn_2b70db0
02d26854: adrp    x0, #0x626a000                             
02d26858: ldr     x0, [x0, #0xf0]                            MS:System.Collections.Generic.List`1::Find
02d2685c: bl      #0x2b70db0                                 fn_2b70db0
02d26860: adrp    x0, #0x6267000                             
02d26864: ldr     x0, [x0, #0xd20]                           MS:MonoSingleton`1::get_Instance
02d26868: bl      #0x2b70db0                                 fn_2b70db0
02d2686c: adrp    x0, #0x626a000                             
02d26870: ldr     x0, [x0, #0xf8]                            T:type57249(k15)
02d26874: bl      #0x2b70db0                                 fn_2b70db0
02d26878: adrp    x0, #0x626a000                             
02d2687c: ldr     x0, [x0, #0x100]                           M:Decor.DecorController/<>c__DisplayClass11_0::<OnOptionSelected>b__0
02d26880: bl      #0x2b70db0                                 fn_2b70db0
02d26884: adrp    x0, #0x626a000                             
02d26888: ldr     x0, [x0, #0xe0]                            T:Decor.DecorController/<>c__DisplayClass11_0
02d2688c: bl      #0x2b70db0                                 fn_2b70db0
02d26890: mov     w8, #1                                     
02d26894: strb    w8, [x21, #0x84]                           
02d26898: ldr     x0, [x23]                                  T:type56879(k15)
02d2689c: bl      #0x2b7104c                                 fn_2b7104c
02d268a0: mov     x1, xzr                                    
02d268a4: mov     x23, x0                                    
02d268a8: bl      #0x4e53e9c                                 System.Object::.ctor
02d268ac: ldr     x0, [x22, #0x38]                           
02d268b0: cbz     x0, #0x2d269fc                             
02d268b4: mov     w1, w20                                    
02d268b8: bl      #0x2d249f4                                 Decor.DecorAsset::GetCategoryAssetByIndex
02d268bc: cbz     x23, #0x2d269fc                            
02d268c0: adrp    x24, #0x626a000                            
02d268c4: adrp    x25, #0x626a000                            
02d268c8: mov     x21, x23                                   
02d268cc: mov     x1, x0                                     
02d268d0: ldr     x24, [x24, #0xf8]                          T:type57249(k15)
02d268d4: ldr     x25, [x25, #0x100]                         M:Decor.DecorController/<>c__DisplayClass11_0::<OnOptionSelected>b__0
02d268d8: str     x0, [x21, #0x10]!                          
02d268dc: mov     x0, x21                                    
02d268e0: bl      #0x2b70d54                                 fn_2b70d54
02d268e4: ldr     x0, [x24]                                  T:type56879(k15)
02d268e8: ldr     x22, [x22, #0x20]                          
02d268ec: bl      #0x2b7104c                                 fn_2b7104c
02d268f0: ldr     x2, [x25]                                  T:type56879(k15)
02d268f4: mov     x1, x23                                    
02d268f8: mov     x3, xzr                                    
02d268fc: mov     x24, x0                                    
02d26900: bl      #0x399ba10                                 fn_399ba10
02d26904: cbz     x22, #0x2d269fc                            
02d26908: adrp    x8, #0x626a000                             
02d2690c: mov     x0, x22                                    
02d26910: mov     x1, x24                                    
02d26914: ldr     x8, [x8, #0xf0]                            MS:System.Collections.Generic.List`1::Find
02d26918: ldr     x2, [x8]                                   T:type56879(k15)
02d2691c: bl      #0x35a9868                                 fn_35a9868
02d26920: cbz     x0, #0x2d26990                             
02d26924: adrp    x10, #0x626a000                            
02d26928: ldr     x8, [x0]                                   T:type56879(k15)
02d2692c: mov     x22, x0                                    
02d26930: ldr     x10, [x10, #0xe8]                          T:Decor.IItemChanger
02d26934: ldrh    w9, [x8, #0x12e]                           
02d26938: ldr     x1, [x10]                                  T:type56879(k15)
02d2693c: cbz     x9, #0x2d26960                             
02d26940: ldr     x10, [x8, #0xb0]                           T:type56715(k15)
02d26944: add     x10, x10, #8                               &626a008
02d26948: ldur    x11, [x10, #-8]                            
02d2694c: cmp     x11, x1                                    
02d26950: b.eq    #0x2d26970                                 
02d26954: subs    x9, x9, #1                                 
02d26958: add     x10, x10, #0x10                            &626a010
02d2695c: b.ne    #0x2d26948                                 
02d26960: mov     x0, x22                                    
02d26964: mov     w2, wzr                                    
02d26968: bl      #0x2baa05c                                 fn_2baa05c
02d2696c: b       #0x2d2697c                                 
02d26970: ldrsw   x9, [x10]                                  
02d26974: add     x8, x8, x9, lsl #4                         &626a000
02d26978: add     x0, x8, #0x138                             &626a138
02d2697c: ldp     x8, x3, [x0]                               
02d26980: mov     x0, x22                                    
02d26984: mov     w1, w20                                    
02d26988: mov     w2, w19                                    
02d2698c: blr     x8                                         
02d26990: cbz     w20, #0x2d269a8                            
02d26994: ldp     x20, x19, [sp, #0x30]                      
02d26998: ldp     x22, x21, [sp, #0x20]                      
02d2699c: ldp     x24, x23, [sp, #0x10]                      
02d269a0: ldp     x30, x25, [sp], #0x40                      
02d269a4: ret                                                
02d269a8: adrp    x8, #0x6267000                             
02d269ac: ldr     x8, [x8, #0xd20]                           MS:MonoSingleton`1::get_Instance
02d269b0: ldr     x0, [x8]                                   S:'didu'
02d269b4: bl      #0x3769600                                 fn_3769600
02d269b8: ldr     x8, [x21]                                  
02d269bc: cbz     x8, #0x2d269fc                             
02d269c0: mov     x20, x0                                    
02d269c4: mov     x0, x8                                     
02d269c8: mov     w1, w19                                    
02d269cc: bl      #0x2d24a4c                                 Decor.CategoryAsset::GetOptionDataByID
02d269d0: cbz     x0, #0x2d269fc                             
02d269d4: cbz     x20, #0x2d269fc                            
02d269d8: ldr     x2, [x0, #0x18]                            MS:System.Collections.Generic.List`1::Add
02d269dc: mov     x0, x20                                    
02d269e0: mov     w1, w19                                    
02d269e4: ldp     x20, x19, [sp, #0x30]                      
02d269e8: mov     x3, xzr                                    
02d269ec: ldp     x22, x21, [sp, #0x20]                      
02d269f0: ldp     x24, x23, [sp, #0x10]                      
02d269f4: ldp     x30, x25, [sp], #0x40                      
02d269f8: b       #0x2cf403c                                 Profile.ProfileManager::SetAvatar
02d269fc: bl      #0x2b7105c                                 fn_2b7105c
## SetupSavedOptions() -> void
---- Decor.DecorController::SetupSavedOptions 0x2d26528
02d26528: str     x30, [sp, #-0x20]!                         
02d2652c: stp     x20, x19, [sp, #0x10]                      
02d26530: mov     x19, x0                                    
02d26534: ldr     x0, [x0, #0x38]                            ._decorAsset
02d26538: cbz     x0, #0x2d26578                             
02d2653c: mov     w20, wzr                                   
02d26540: bl      #0x2d255ec                                 Decor.DecorAsset::GetCategoryAssetCount
02d26544: cmp     w20, w0                                    
02d26548: b.ge    #0x2d2657c                                 
02d2654c: ldr     x0, [x19, #0x40]                           ._dataDecor
02d26550: cbz     x0, #0x2d26578                             
02d26554: mov     w1, w20                                    
02d26558: bl      #0x2d25c44                                 Decor.DataDecor::GetSelectedItem
02d2655c: mov     w2, w0                                     
02d26560: mov     x0, x19                                    
02d26564: mov     w1, w20                                    
02d26568: bl      #0x2d26818                                 Decor.DecorController::OnOptionSelected
02d2656c: ldr     x0, [x19, #0x38]                           ._decorAsset
02d26570: add     w20, w20, #1                               
02d26574: cbnz    x0, #0x2d26540                             
02d26578: bl      #0x2b7105c                                 fn_2b7105c
02d2657c: ldp     x20, x19, [sp, #0x10]                      
02d26580: ldr     x30, [sp], #0x20                           
02d26584: ret                                                
## CanAnyBuyOption(int categoryIndex) -> bool
---- Decor.DecorController::CanAnyBuyOption 0x2d26a08
02d26a08: stp     x30, x27, [sp, #-0x50]!                    
02d26a0c: stp     x26, x25, [sp, #0x10]                      
02d26a10: stp     x24, x23, [sp, #0x20]                      
02d26a14: stp     x22, x21, [sp, #0x30]                      
02d26a18: stp     x20, x19, [sp, #0x40]                      
02d26a1c: adrp    x21, #0x6630000                            
02d26a20: mov     w19, w1                                    
02d26a24: mov     x20, x0                                    
02d26a28: ldrb    w8, [x21, #0x85]                           
02d26a2c: tbnz    w8, #0, #0x2d26a50                         
02d26a30: adrp    x0, #0x6266000                             
02d26a34: ldr     x0, [x0, #0x750]                           MS:DataManager::GetData
02d26a38: bl      #0x2b70db0                                 fn_2b70db0
02d26a3c: adrp    x0, #0x6266000                             
02d26a40: ldr     x0, [x0, #0x658]                           MS:MonoSingleton`1::get_Instance
02d26a44: bl      #0x2b70db0                                 fn_2b70db0
02d26a48: mov     w8, #1                                     
02d26a4c: strb    w8, [x21, #0x85]                           
02d26a50: ldr     x0, [x20, #0x38]                           ._decorAsset
02d26a54: cbz     x0, #0x2d26b34                             
02d26a58: mov     w1, w19                                    
02d26a5c: bl      #0x2d249f4                                 Decor.DecorAsset::GetCategoryAssetByIndex
02d26a60: cbz     x0, #0x2d26b34                             
02d26a64: mov     x21, x0                                    
02d26a68: bl      #0x2d25174                                 Decor.CategoryAsset::GetOptionDataCount
02d26a6c: cmp     w0, #0                                     
02d26a70: cset    w25, gt                                    
02d26a74: cmp     w0, #1                                     
02d26a78: b.lt    #0x2d26b18                                 
02d26a7c: adrp    x26, #0x6266000                            
02d26a80: adrp    x27, #0x6266000                            
02d26a84: mov     w22, wzr                                   
02d26a88: ldr     x26, [x26, #0x658]                         MS:MonoSingleton`1::get_Instance
02d26a8c: ldr     x27, [x27, #0x750]                         MS:DataManager::GetData
02d26a90: mov     x0, x21                                    
02d26a94: mov     w1, w22                                    
02d26a98: bl      #0x2d2511c                                 Decor.CategoryAsset::GetOptionDataByIndex
02d26a9c: cbz     x0, #0x2d26b34                             
02d26aa0: mov     x23, x0                                    
02d26aa4: ldr     x0, [x20, #0x40]                           ._dataDecor
02d26aa8: cbz     x0, #0x2d26b34                             
02d26aac: ldr     w2, [x23, #0x10]                           
02d26ab0: mov     w1, w19                                    
02d26ab4: bl      #0x2d25b24                                 Decor.DataDecor::HasUnlockedItem
02d26ab8: ldr     x8, [x26]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d26abc: mov     w24, w0                                    
02d26ac0: mov     x0, x8                                     
02d26ac4: bl      #0x3769600                                 fn_3769600
02d26ac8: cbz     x0, #0x2d26b34                             
02d26acc: ldr     x1, [x27]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d26ad0: bl      #0x3168dd0                                 fn_3168dd0
02d26ad4: cbz     x0, #0x2d26b34                             
02d26ad8: mov     x1, xzr                                    
02d26adc: bl      #0x2cabaf8                                 DataUser::GetMoney
02d26ae0: ldr     w8, [x23, #0x24]                           
02d26ae4: cmp     w0, w8                                     
02d26ae8: b.lt    #0x2d26b00                                 
02d26aec: ldr     w8, [x23, #0x20]                           
02d26af0: cmp     w8, #2                                     
02d26af4: cset    w8, ne                                     
02d26af8: orr     w8, w8, w24                                
02d26afc: tbz     w8, #0, #0x2d26b18                         
02d26b00: mov     x0, x21                                    
02d26b04: add     w22, w22, #1                               
02d26b08: bl      #0x2d25174                                 Decor.CategoryAsset::GetOptionDataCount
02d26b0c: cmp     w22, w0                                    
02d26b10: cset    w25, lt                                    
02d26b14: b.lt    #0x2d26a90                                 
02d26b18: and     w0, w25, #1                                
02d26b1c: ldp     x20, x19, [sp, #0x40]                      
02d26b20: ldp     x22, x21, [sp, #0x30]                      
02d26b24: ldp     x24, x23, [sp, #0x20]                      
02d26b28: ldp     x26, x25, [sp, #0x10]                      
02d26b2c: ldp     x30, x27, [sp], #0x50                      
02d26b30: ret                                                
02d26b34: bl      #0x2b7105c                                 fn_2b7105c
## OnDestroy() -> void
---- Decor.DecorController::OnDestroy 0x2d26b38
02d26b38: str     x30, [sp, #-0x20]!                         
02d26b3c: stp     x20, x19, [sp, #0x10]                      
02d26b40: adrp    x19, #0x6630000                            
02d26b44: adrp    x20, #0x6263000                            
02d26b48: ldrb    w8, [x19, #0x86]                           
02d26b4c: ldr     x20, [x20, #0xfd0]                         T:DG.Tweening.DOTween
02d26b50: tbnz    w8, #0, #0x2d26b68                         
02d26b54: adrp    x0, #0x6263000                             
02d26b58: ldr     x0, [x0, #0xfd0]                           T:DG.Tweening.DOTween
02d26b5c: bl      #0x2b70db0                                 fn_2b70db0
02d26b60: mov     w8, #1                                     
02d26b64: strb    w8, [x19, #0x86]                           
02d26b68: ldr     x0, [x20]                                  &2c5bbd4(=a9bd7bfdd503233f)
02d26b6c: ldr     w8, [x0, #0xe4]                            [62630e4]=0 f=0,0
02d26b70: cbnz    w8, #0x2d26b78                             
02d26b74: bl      #0x2b70f30                                 fn_2b70f30
02d26b78: ldp     x20, x19, [sp, #0x10]                      
02d26b7c: mov     w0, wzr                                    
02d26b80: mov     x1, xzr                                    
02d26b84: ldr     x30, [sp], #0x20                           
02d26b88: b       #0x2d8af8c                                 DG.Tweening.DOTween::Clear
## .ctor() -> void
---- Decor.DecorController::.ctor 0x2d26b8c
02d26b8c: stp     x30, x23, [sp, #-0x30]!                    
02d26b90: stp     x22, x21, [sp, #0x10]                      
02d26b94: stp     x20, x19, [sp, #0x20]                      
02d26b98: adrp    x22, #0x6630000                            
02d26b9c: adrp    x23, #0x626a000                            
02d26ba0: adrp    x20, #0x626a000                            
02d26ba4: adrp    x21, #0x626a000                            
02d26ba8: ldr     x23, [x23, #0xb0]                          T:type56715(k15)
02d26bac: ldrb    w8, [x22, #0x87]                           
02d26bb0: ldr     x20, [x20, #0x108]                         MS:System.Collections.Generic.List`1::.ctor
02d26bb4: ldr     x21, [x21, #0x110]                         MS:MonoSingleton`1::.ctor
02d26bb8: mov     x19, x0                                    
02d26bbc: tbnz    w8, #0, #0x2d26bec                         
02d26bc0: adrp    x0, #0x626a000                             
02d26bc4: ldr     x0, [x0, #0x108]                           MS:System.Collections.Generic.List`1::.ctor
02d26bc8: bl      #0x2b70db0                                 fn_2b70db0
02d26bcc: adrp    x0, #0x626a000                             
02d26bd0: ldr     x0, [x0, #0xb0]                            T:type56715(k15)
02d26bd4: bl      #0x2b70db0                                 fn_2b70db0
02d26bd8: adrp    x0, #0x626a000                             
02d26bdc: ldr     x0, [x0, #0x110]                           MS:MonoSingleton`1::.ctor
02d26be0: bl      #0x2b70db0                                 fn_2b70db0
02d26be4: mov     w8, #1                                     
02d26be8: strb    w8, [x22, #0x87]                           
02d26bec: ldr     x0, [x23]                                  T:type56879(k15)
02d26bf0: bl      #0x2b7104c                                 fn_2b7104c
02d26bf4: ldr     x1, [x20]                                  T:type56879(k15)
02d26bf8: mov     x20, x0                                    
02d26bfc: bl      #0x35a89a4                                 fn_35a89a4
02d26c00: mov     x0, x19                                    
02d26c04: mov     x1, x20                                    
02d26c08: str     x20, [x0, #0x20]!                          ._itemChangers
02d26c0c: bl      #0x2b70d54                                 fn_2b70d54
02d26c10: ldr     x1, [x21]                                  T:type56879(k15)
02d26c14: mov     x0, x19                                    
02d26c18: ldp     x20, x19, [sp, #0x20]                      
02d26c1c: ldp     x22, x21, [sp, #0x10]                      
02d26c20: ldp     x30, x23, [sp], #0x30                      
02d26c24: b       #0x3769e18                                 
