#### CLASS InterApplovinControl/<LoadInterstitialAfterDelay>d__6 parent= object
#   field <>1__state                     int                                                off=0x10 attr=1 
#   field <>2__current                   object                                             off=0x18 attr=1 
#   field delay                          float                                              off=0x20 attr=6 
#   field <>4__this                      InterApplovinControl                               off=0x28 attr=6 
## .ctor(int <>1__state) -> void
---- InterApplovinControl/<LoadInterstitialAfterDelay>d__6::.ctor 0x2c8e020
02c8e020: str     x30, [sp, #-0x20]!                         
02c8e024: stp     x20, x19, [sp, #0x10]                      
02c8e028: mov     w19, w1                                    
02c8e02c: mov     x1, xzr                                    
02c8e030: mov     x20, x0                                    
02c8e034: bl      #0x4e53e9c                                 System.Object::.ctor
02c8e038: str     w19, [x20, #0x10]                          .<>1__state
02c8e03c: ldp     x20, x19, [sp, #0x10]                      
02c8e040: ldr     x30, [sp], #0x20                           
02c8e044: ret                                                
## System.IDisposable.Dispose() -> void
---- InterApplovinControl/<LoadInterstitialAfterDelay>d__6::System.IDisposable.Dispose 0x2c8e0e8
02c8e0e8: ret                                                
## MoveNext() -> bool
---- InterApplovinControl/<LoadInterstitialAfterDelay>d__6::MoveNext 0x2c8e0ec
02c8e0ec: str     d8, [sp, #-0x30]!                          
02c8e0f0: stp     x30, x21, [sp, #0x10]                      
02c8e0f4: stp     x20, x19, [sp, #0x20]                      
02c8e0f8: adrp    x20, #0x662f000                            
02c8e0fc: mov     x19, x0                                    
02c8e100: ldrb    w8, [x20, #0x997]                          
02c8e104: tbnz    w8, #0, #0x2c8e11c                         
02c8e108: adrp    x0, #0x6264000                             
02c8e10c: ldr     x0, [x0, #0xf58]                           T:UnityEngine.WaitForSeconds
02c8e110: bl      #0x2b70db0                                 fn_2b70db0
02c8e114: mov     w8, #1                                     
02c8e118: strb    w8, [x20, #0x997]                          
02c8e11c: ldr     w21, [x19, #0x10]                          .<>1__state
02c8e120: cbz     w21, #0x2c8e144                            
02c8e124: cmp     w21, #1                                    
02c8e128: b.ne    #0x2c8e188                                 
02c8e12c: ldr     x8, [x19, #0x28]                           .<>4__this
02c8e130: mov     w9, #-1                                    
02c8e134: str     w9, [x19, #0x10]                           .<>1__state
02c8e138: cbz     x8, #0x2c8e1a0                             
02c8e13c: bl      #0x2c8df1c                                 InterApplovinControl::LoadInterstitial
02c8e140: b       #0x2c8e188                                 
02c8e144: adrp    x8, #0x6264000                             
02c8e148: mov     w9, #-1                                    
02c8e14c: ldr     x8, [x8, #0xf58]                           T:UnityEngine.WaitForSeconds
02c8e150: ldr     s8, [x19, #0x20]                           .delay
02c8e154: str     w9, [x19, #0x10]                           .<>1__state
02c8e158: ldr     x0, [x8]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c8e15c: bl      #0x2b7104c                                 fn_2b7104c
02c8e160: fmov    s0, s8                                     
02c8e164: mov     x1, xzr                                    
02c8e168: mov     x20, x0                                    
02c8e16c: bl      #0x5b3e5e8                                 UnityEngine.WaitForSeconds::.ctor
02c8e170: mov     x0, x19                                    
02c8e174: mov     x1, x20                                    
02c8e178: str     x20, [x0, #0x18]!                          .<>2__current
02c8e17c: bl      #0x2b70d54                                 fn_2b70d54
02c8e180: mov     w8, #1                                     
02c8e184: str     w8, [x19, #0x10]                           .<>1__state
02c8e188: cmp     w21, #0                                    
02c8e18c: ldp     x20, x19, [sp, #0x20]                      
02c8e190: ldp     x30, x21, [sp, #0x10]                      
02c8e194: cset    w0, eq                                     
02c8e198: ldr     d8, [sp], #0x30                            
02c8e19c: ret                                                
02c8e1a0: bl      #0x2b7105c                                 fn_2b7105c
## System.Collections.Generic.IEnumerator<System.Object>.get_Current() -> object
---- InterApplovinControl/<LoadInterstitialAfterDelay>d__6::System.Collections.Generic.IEnumerator<System.Object>.get_Current 0x2c8e1a4
02c8e1a4: ldr     x0, [x0, #0x18]                            .<>2__current
02c8e1a8: ret                                                
## System.Collections.IEnumerator.Reset() -> void
---- InterApplovinControl/<LoadInterstitialAfterDelay>d__6::System.Collections.IEnumerator.Reset 0x2c8e1ac
02c8e1ac: stp     x30, x19, [sp, #-0x10]!                    
02c8e1b0: adrp    x0, #0x6264000                             
02c8e1b4: ldr     x0, [x0, #0xf60]                           T:System.NotSupportedException
02c8e1b8: bl      #0x2b70dc4                                 fn_2b70dc4
02c8e1bc: bl      #0x2b7104c                                 fn_2b7104c
02c8e1c0: mov     x1, xzr                                    
02c8e1c4: mov     x19, x0                                    
02c8e1c8: bl      #0x4e14238                                 System.NotSupportedException::.ctor
02c8e1cc: adrp    x0, #0x6265000                             
02c8e1d0: ldr     x0, [x0, #0x3c8]                           M:InterApplovinControl/<LoadInterstitialAfterDelay>d__6::System.Collections.IEnumerator.Reset
02c8e1d4: bl      #0x2b70dc4                                 fn_2b70dc4
02c8e1d8: mov     x1, x0                                     
02c8e1dc: mov     x0, x19                                    
02c8e1e0: bl      #0x2b70f20                                 fn_2b70f20
## System.Collections.IEnumerator.get_Current() -> object
---- InterApplovinControl/<LoadInterstitialAfterDelay>d__6::System.Collections.IEnumerator.get_Current 0x2c8e1e4
02c8e1e4: ldr     x0, [x0, #0x18]                            .<>2__current
02c8e1e8: ret                                                
#### CLASS InterApplovinControl parent= ApplovinEventBase
#   field _action                        System.Action                                      off=0x30 attr=1 
## Start() -> void
---- InterApplovinControl::Start 0x2c8df14
02c8df14: str     wzr, [x0, #0x28]                           
02c8df18: ret                                                
## InitAd() -> void
---- InterApplovinControl::InitAd 0x2c8d0b0
02c8d0b0: stp     x30, x23, [sp, #-0x30]!                    
02c8d0b4: stp     x22, x21, [sp, #0x10]                      
02c8d0b8: stp     x20, x19, [sp, #0x20]                      
02c8d0bc: adrp    x20, #0x662f000                            
02c8d0c0: adrp    x21, #0x6265000                            
02c8d0c4: mov     x19, x0                                    
02c8d0c8: ldrb    w8, [x20, #0x992]                          
02c8d0cc: ldr     x21, [x21, #0x350]                         T:type7232(k15)
02c8d0d0: tbnz    w8, #0, #0x2c8d100                         
02c8d0d4: adrp    x0, #0x6265000                             
02c8d0d8: ldr     x0, [x0, #0x350]                           T:type7232(k15)
02c8d0dc: bl      #0x2b70db0                                 fn_2b70db0
02c8d0e0: adrp    x0, #0x6265000                             
02c8d0e4: ldr     x0, [x0, #0x358]                           T:type7234(k15)
02c8d0e8: bl      #0x2b70db0                                 fn_2b70db0
02c8d0ec: adrp    x0, #0x6265000                             
02c8d0f0: ldr     x0, [x0, #0x360]                           T:type7277(k15)
02c8d0f4: bl      #0x2b70db0                                 fn_2b70db0
02c8d0f8: mov     w8, #1                                     
02c8d0fc: strb    w8, [x20, #0x992]                          
02c8d100: ldr     x0, [x21]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c8d104: bl      #0x2b7104c                                 fn_2b7104c
02c8d108: cbz     x19, #0x2c8d258                            
02c8d10c: ldr     x8, [x19]                                  
02c8d110: adrp    x22, #0x6265000                            
02c8d114: adrp    x23, #0x6265000                            
02c8d118: ldr     x22, [x22, #0x358]                         T:type7234(k15)
02c8d11c: ldr     x23, [x23, #0x360]                         T:type7277(k15)
02c8d120: mov     x1, x19                                    
02c8d124: ldr     x2, [x8, #0x180]                           
02c8d128: mov     x3, xzr                                    
02c8d12c: mov     x20, x0                                    
02c8d130: bl      #0x453ce6c                                 fn_453ce6c
02c8d134: mov     x0, x20                                    
02c8d138: mov     x1, xzr                                    
02c8d13c: bl      #0x4c5b5ec                                 MaxSdkCallbacks/Interstitial::add_OnAdLoadedEvent
02c8d140: ldr     x0, [x22]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c8d144: bl      #0x2b7104c                                 fn_2b7104c
02c8d148: ldr     x8, [x19]                                  
02c8d14c: mov     x1, x19                                    
02c8d150: mov     x3, xzr                                    
02c8d154: mov     x20, x0                                    
02c8d158: ldr     x2, [x8, #0x190]                           
02c8d15c: bl      #0x453ce6c                                 fn_453ce6c
02c8d160: mov     x0, x20                                    
02c8d164: mov     x1, xzr                                    
02c8d168: bl      #0x4c5b804                                 MaxSdkCallbacks/Interstitial::add_OnAdLoadFailedEvent
02c8d16c: ldr     x0, [x21]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c8d170: bl      #0x2b7104c                                 fn_2b7104c
02c8d174: ldr     x8, [x19]                                  
02c8d178: mov     x1, x19                                    
02c8d17c: mov     x3, xzr                                    
02c8d180: mov     x20, x0                                    
02c8d184: ldr     x2, [x8, #0x1a0]                           
02c8d188: bl      #0x453ce6c                                 fn_453ce6c
02c8d18c: mov     x0, x20                                    
02c8d190: mov     x1, xzr                                    
02c8d194: bl      #0x4c5b9fc                                 MaxSdkCallbacks/Interstitial::add_OnAdDisplayedEvent
02c8d198: ldr     x0, [x23]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c8d19c: bl      #0x2b7104c                                 fn_2b7104c
02c8d1a0: ldr     x8, [x19]                                  
02c8d1a4: mov     x1, x19                                    
02c8d1a8: mov     x3, xzr                                    
02c8d1ac: mov     x20, x0                                    
02c8d1b0: ldr     x2, [x8, #0x1d0]                           
02c8d1b4: bl      #0x453e174                                 fn_453e174
02c8d1b8: mov     x0, x20                                    
02c8d1bc: mov     x1, xzr                                    
02c8d1c0: bl      #0x4c5bbf4                                 MaxSdkCallbacks/Interstitial::add_OnAdDisplayFailedEvent
02c8d1c4: ldr     x0, [x21]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c8d1c8: bl      #0x2b7104c                                 fn_2b7104c
02c8d1cc: ldr     x8, [x19]                                  
02c8d1d0: mov     x1, x19                                    
02c8d1d4: mov     x3, xzr                                    
02c8d1d8: mov     x20, x0                                    
02c8d1dc: ldr     x2, [x8, #0x1b0]                           
02c8d1e0: bl      #0x453ce6c                                 fn_453ce6c
02c8d1e4: mov     x0, x20                                    
02c8d1e8: mov     x1, xzr                                    
02c8d1ec: bl      #0x4c5bdec                                 MaxSdkCallbacks/Interstitial::add_OnAdClickedEvent
02c8d1f0: ldr     x0, [x21]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c8d1f4: bl      #0x2b7104c                                 fn_2b7104c
02c8d1f8: ldr     x8, [x19]                                  
02c8d1fc: mov     x1, x19                                    
02c8d200: mov     x3, xzr                                    
02c8d204: mov     x20, x0                                    
02c8d208: ldr     x2, [x8, #0x1c0]                           
02c8d20c: bl      #0x453ce6c                                 fn_453ce6c
02c8d210: mov     x0, x20                                    
02c8d214: mov     x1, xzr                                    
02c8d218: bl      #0x4c5c5cc                                 MaxSdkCallbacks/Interstitial::add_OnAdHiddenEvent
02c8d21c: ldr     x0, [x21]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c8d220: bl      #0x2b7104c                                 fn_2b7104c
02c8d224: ldr     x8, [x19]                                  
02c8d228: mov     x1, x19                                    
02c8d22c: mov     x3, xzr                                    
02c8d230: mov     x20, x0                                    
02c8d234: ldr     x2, [x8, #0x1e0]                           
02c8d238: bl      #0x453ce6c                                 fn_453ce6c
02c8d23c: mov     x0, x20                                    
02c8d240: mov     x1, xzr                                    
02c8d244: bl      #0x4c5bfe4                                 MaxSdkCallbacks/Interstitial::add_OnAdRevenuePaidEvent
02c8d248: ldp     x20, x19, [sp, #0x20]                      
02c8d24c: ldp     x22, x21, [sp, #0x10]                      
02c8d250: ldp     x30, x23, [sp], #0x30                      
02c8d254: b       #0x2c8df1c                                 InterApplovinControl::LoadInterstitial
02c8d258: bl      #0x2b7105c                                 fn_2b7105c
## IsAdReady() -> bool
---- InterApplovinControl::IsAdReady 0x2c8c8c8
02c8c8c8: str     x30, [sp, #-0x20]!                         
02c8c8cc: stp     x20, x19, [sp, #0x10]                      
02c8c8d0: adrp    x20, #0x662f000                            
02c8c8d4: adrp    x19, #0x6265000                            
02c8c8d8: ldrb    w8, [x20, #0x993]                          
02c8c8dc: ldr     x19, [x19, #0x2f8]                         T:MaxSdkAndroid
02c8c8e0: tbnz    w8, #0, #0x2c8c8f8                         
02c8c8e4: adrp    x0, #0x6265000                             
02c8c8e8: ldr     x0, [x0, #0x2f8]                           T:MaxSdkAndroid
02c8c8ec: bl      #0x2b70db0                                 fn_2b70db0
02c8c8f0: mov     w8, #1                                     
02c8c8f4: strb    w8, [x20, #0x993]                          
02c8c8f8: mov     w0, wzr                                    
02c8c8fc: bl      #0x2c8de38                                 KeyAds::Get
02c8c900: ldr     x8, [x19]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c8c904: mov     x19, x0                                    
02c8c908: ldr     w9, [x8, #0xe4]                            
02c8c90c: cbnz    w9, #0x2c8c918                             
02c8c910: mov     x0, x8                                     
02c8c914: bl      #0x2b70f30                                 fn_2b70f30
02c8c918: mov     x0, x19                                    
02c8c91c: ldp     x20, x19, [sp, #0x10]                      
02c8c920: mov     x1, xzr                                    
02c8c924: ldr     x30, [sp], #0x20                           
02c8c928: b       #0x4c539fc                                 MaxSdkAndroid::IsInterstitialReady
## LoadInterstitial() -> void
---- InterApplovinControl::LoadInterstitial 0x2c8df1c
02c8df1c: str     x30, [sp, #-0x20]!                         
02c8df20: stp     x20, x19, [sp, #0x10]                      
02c8df24: adrp    x20, #0x662f000                            
02c8df28: adrp    x19, #0x6265000                            
02c8df2c: ldrb    w8, [x20, #0x994]                          
02c8df30: ldr     x19, [x19, #0x2f8]                         T:MaxSdkAndroid
02c8df34: tbnz    w8, #0, #0x2c8df4c                         
02c8df38: adrp    x0, #0x6265000                             
02c8df3c: ldr     x0, [x0, #0x2f8]                           T:MaxSdkAndroid
02c8df40: bl      #0x2b70db0                                 fn_2b70db0
02c8df44: mov     w8, #1                                     
02c8df48: strb    w8, [x20, #0x994]                          
02c8df4c: mov     w0, wzr                                    
02c8df50: bl      #0x2c8de38                                 KeyAds::Get
02c8df54: ldr     x8, [x19]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c8df58: mov     x19, x0                                    
02c8df5c: ldr     w9, [x8, #0xe4]                            
02c8df60: cbnz    w9, #0x2c8df6c                             
02c8df64: mov     x0, x8                                     
02c8df68: bl      #0x2b70f30                                 fn_2b70f30
02c8df6c: mov     x0, x19                                    
02c8df70: ldp     x20, x19, [sp, #0x10]                      
02c8df74: mov     x1, xzr                                    
02c8df78: ldr     x30, [sp], #0x20                           
02c8df7c: b       #0x4c538e4                                 MaxSdkAndroid::LoadInterstitial
## TryLoadInterstitial() -> void
---- InterApplovinControl::TryLoadInterstitial 0x2c8df80
02c8df80: stp     x30, x19, [sp, #-0x10]!                    
02c8df84: fmov    s0, #2.00000000                            
02c8df88: mov     x19, x0                                    
02c8df8c: bl      #0x2c8dfa4                                 InterApplovinControl::LoadInterstitialAfterDelay
02c8df90: mov     x1, x0                                     
02c8df94: mov     x0, x19                                    
02c8df98: mov     x2, xzr                                    
02c8df9c: ldp     x30, x19, [sp], #0x10                      
02c8dfa0: b       #0x5b389f0                                 UnityEngine.MonoBehaviour::StartCoroutine
## LoadInterstitialAfterDelay(float delay) -> System.Collections.IEnumerator
---- InterApplovinControl::LoadInterstitialAfterDelay 0x2c8dfa4
02c8dfa4: str     d8, [sp, #-0x30]!                          
02c8dfa8: stp     x30, x21, [sp, #0x10]                      
02c8dfac: stp     x20, x19, [sp, #0x20]                      
02c8dfb0: fmov    s8, s0                                     
02c8dfb4: adrp    x20, #0x662f000                            
02c8dfb8: adrp    x21, #0x6265000                            
02c8dfbc: ldrb    w8, [x20, #0x995]                          
02c8dfc0: ldr     x21, [x21, #0x3c0]                         T:InterApplovinControl/<LoadInterstitialAfterDelay>d__6
02c8dfc4: mov     x19, x0                                    
02c8dfc8: tbnz    w8, #0, #0x2c8dfe0                         
02c8dfcc: adrp    x0, #0x6265000                             
02c8dfd0: ldr     x0, [x0, #0x3c0]                           T:InterApplovinControl/<LoadInterstitialAfterDelay>d__6
02c8dfd4: bl      #0x2b70db0                                 fn_2b70db0
02c8dfd8: mov     w8, #1                                     
02c8dfdc: strb    w8, [x20, #0x995]                          
02c8dfe0: ldr     x0, [x21]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c8dfe4: bl      #0x2b7104c                                 fn_2b7104c
02c8dfe8: mov     x1, xzr                                    
02c8dfec: mov     x20, x0                                    
02c8dff0: bl      #0x4e53e9c                                 System.Object::.ctor
02c8dff4: mov     x0, x20                                    
02c8dff8: mov     x1, x19                                    
02c8dffc: str     wzr, [x20, #0x10]                          
02c8e000: str     x19, [x0, #0x28]!                          
02c8e004: bl      #0x2b70d54                                 fn_2b70d54
02c8e008: mov     x0, x20                                    
02c8e00c: str     s8, [x20, #0x20]                           
02c8e010: ldp     x20, x19, [sp, #0x20]                      
02c8e014: ldp     x30, x21, [sp, #0x10]                      
02c8e018: ldr     d8, [sp], #0x30                            
02c8e01c: ret                                                
## ShowAd(string placment, System.Action action) -> void
---- InterApplovinControl::ShowAd 0x2c8cba4
02c8cba4: stp     x30, x23, [sp, #-0x30]!                    
02c8cba8: stp     x22, x21, [sp, #0x10]                      
02c8cbac: stp     x20, x19, [sp, #0x20]                      
02c8cbb0: adrp    x23, #0x662f000                            
02c8cbb4: adrp    x22, #0x6265000                            
02c8cbb8: mov     x19, x2                                    
02c8cbbc: ldrb    w8, [x23, #0x996]                          
02c8cbc0: ldr     x22, [x22, #0x2f8]                         T:MaxSdkAndroid
02c8cbc4: mov     x21, x1                                    
02c8cbc8: mov     x20, x0                                    
02c8cbcc: tbnz    w8, #0, #0x2c8cbe4                         
02c8cbd0: adrp    x0, #0x6265000                             
02c8cbd4: ldr     x0, [x0, #0x2f8]                           T:MaxSdkAndroid
02c8cbd8: bl      #0x2b70db0                                 fn_2b70db0
02c8cbdc: mov     w8, #1                                     
02c8cbe0: strb    w8, [x23, #0x996]                          
02c8cbe4: mov     x0, x20                                    
02c8cbe8: mov     x1, x21                                    
02c8cbec: str     x21, [x0, #0x20]!                          
02c8cbf0: bl      #0x2b70d54                                 fn_2b70d54
02c8cbf4: str     x19, [x20, #0x30]!                         ._action
02c8cbf8: mov     x0, x20                                    
02c8cbfc: mov     x1, x19                                    
02c8cc00: bl      #0x2b70d54                                 fn_2b70d54
02c8cc04: mov     w0, wzr                                    
02c8cc08: bl      #0x2c8de38                                 KeyAds::Get
02c8cc0c: ldr     x8, [x22]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c8cc10: mov     x19, x0                                    
02c8cc14: ldr     w9, [x8, #0xe4]                            
02c8cc18: cbnz    w9, #0x2c8cc24                             
02c8cc1c: mov     x0, x8                                     
02c8cc20: bl      #0x2b70f30                                 fn_2b70f30
02c8cc24: mov     x0, x19                                    
02c8cc28: mov     x1, xzr                                    
02c8cc2c: bl      #0x4c539fc                                 MaxSdkAndroid::IsInterstitialReady
02c8cc30: tbz     w0, #0, #0x2c8cc74                         
02c8cc34: mov     w0, wzr                                    
02c8cc38: bl      #0x2c8de38                                 KeyAds::Get
02c8cc3c: ldr     x8, [x22]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c8cc40: mov     x19, x0                                    
02c8cc44: ldr     w9, [x8, #0xe4]                            
02c8cc48: cbnz    w9, #0x2c8cc54                             
02c8cc4c: mov     x0, x8                                     
02c8cc50: bl      #0x2b70f30                                 fn_2b70f30
02c8cc54: mov     x0, x19                                    
02c8cc58: ldp     x20, x19, [sp, #0x20]                      
02c8cc5c: ldp     x22, x21, [sp, #0x10]                      
02c8cc60: mov     x1, xzr                                    
02c8cc64: mov     x2, xzr                                    
02c8cc68: mov     x3, xzr                                    
02c8cc6c: ldp     x30, x23, [sp], #0x30                      
02c8cc70: b       #0x4c53b28                                 MaxSdkAndroid::ShowInterstitial
02c8cc74: ldp     x20, x19, [sp, #0x20]                      
02c8cc78: ldp     x22, x21, [sp, #0x10]                      
02c8cc7c: ldp     x30, x23, [sp], #0x30                      
02c8cc80: ret                                                
## OnAdHiddenEvent(string adUnitID, MaxSdkBase/AdInfo adInfo) -> void
---- InterApplovinControl::OnAdHiddenEvent 0x2c8e048
02c8e048: stp     x30, x19, [sp, #-0x10]!                    
02c8e04c: mov     x19, x0                                    
02c8e050: bl      #0x2c8bea0                                 ApplovinEventBase::OnAdHiddenEvent
02c8e054: ldr     x8, [x19, #0x30]                           ._action
02c8e058: cbz     x8, #0x2c8e06c                             
02c8e05c: ldr     x9, [x8, #0x18]                            
02c8e060: ldr     x0, [x8, #0x40]                            
02c8e064: ldr     x1, [x8, #0x28]                            
02c8e068: blr     x9                                         
02c8e06c: ldp     x30, x19, [sp], #0x10                      
02c8e070: b       #0x2c8df1c                                 InterApplovinControl::LoadInterstitial
## OnAdDisplayFailedEvent(string adUnitId, MaxSdkBase/ErrorInfo errorInfo, MaxSdkBase/AdInfo adInfo) -> void
---- InterApplovinControl::OnAdDisplayFailedEvent 0x2c8e074
02c8e074: stp     x30, x19, [sp, #-0x10]!                    
02c8e078: mov     x19, x0                                    
02c8e07c: bl      #0x2c8bfac                                 ApplovinEventBase::OnAdDisplayFailedEvent
02c8e080: ldr     x8, [x19, #0x30]                           ._action
02c8e084: cbz     x8, #0x2c8e098                             
02c8e088: ldr     x9, [x8, #0x18]                            
02c8e08c: ldr     x0, [x8, #0x40]                            
02c8e090: ldr     x1, [x8, #0x28]                            
02c8e094: blr     x9                                         
02c8e098: fmov    s0, #2.00000000                            
02c8e09c: mov     x0, x19                                    
02c8e0a0: bl      #0x2c8dfa4                                 InterApplovinControl::LoadInterstitialAfterDelay
02c8e0a4: mov     x1, x0                                     
02c8e0a8: mov     x0, x19                                    
02c8e0ac: mov     x2, xzr                                    
02c8e0b0: ldp     x30, x19, [sp], #0x10                      
02c8e0b4: b       #0x5b389f0                                 UnityEngine.MonoBehaviour::StartCoroutine
## OnAdLoadFailedEvent(string adUnitId, MaxSdkBase/ErrorInfo errorInfo) -> void
---- InterApplovinControl::OnAdLoadFailedEvent 0x2c8e0b8
02c8e0b8: stp     x30, x19, [sp, #-0x10]!                    
02c8e0bc: mov     x19, x0                                    
02c8e0c0: bl      #0x2c8bb74                                 ApplovinEventBase::OnAdLoadFailedEvent
02c8e0c4: fmov    s0, #2.00000000                            
02c8e0c8: mov     x0, x19                                    
02c8e0cc: bl      #0x2c8dfa4                                 InterApplovinControl::LoadInterstitialAfterDelay
02c8e0d0: mov     x1, x0                                     
02c8e0d4: mov     x0, x19                                    
02c8e0d8: mov     x2, xzr                                    
02c8e0dc: ldp     x30, x19, [sp], #0x10                      
02c8e0e0: b       #0x5b389f0                                 UnityEngine.MonoBehaviour::StartCoroutine
## .ctor() -> void
---- InterApplovinControl::.ctor 0x2c8e0e4
02c8e0e4: b       #0x2c8c870                                 ApplovinEventBase::.ctor
