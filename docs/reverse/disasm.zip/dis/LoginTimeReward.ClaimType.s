#### CLASS LoginTimeReward.ClaimType parent= int
#   field value__                        int                                                off=0x10 attr=606 
#   field Free                           LoginTimeReward.ClaimType                          off=0x0 attr=8056 
#   field Ads                            LoginTimeReward.ClaimType                          off=0x0 attr=8056 
