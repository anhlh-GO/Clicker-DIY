#### CLASS ItemSpawner parent= PoolerBase`1<Item>
#   field _itemPrefab                    Item                                               off=0x30 attr=1 SerializeField
## Start() -> void
---- ItemSpawner::Start 0x2c865b8
02c865b8: stp     x30, x23, [sp, #-0x30]!                    
02c865bc: stp     x22, x21, [sp, #0x10]                      
02c865c0: stp     x20, x19, [sp, #0x20]                      
02c865c4: adrp    x23, #0x662f000                            
02c865c8: adrp    x22, #0x6264000                            
02c865cc: adrp    x21, #0x6264000                            
02c865d0: adrp    x20, #0x6264000                            
02c865d4: ldr     x22, [x22, #0xd60]                         MS:PoolerBase`1::InitPool
02c865d8: ldrb    w8, [x23, #0x94b]                          
02c865dc: ldr     x21, [x21, #0xd68]                         MS:PoolerBase`1::Get
02c865e0: ldr     x20, [x20, #0xd70]                         MS:PoolerBase`1::Release
02c865e4: mov     x19, x0                                    
02c865e8: tbnz    w8, #0, #0x2c86618                         
02c865ec: adrp    x0, #0x6264000                             
02c865f0: ldr     x0, [x0, #0xd68]                           MS:PoolerBase`1::Get
02c865f4: bl      #0x2b70db0                                 fn_2b70db0
02c865f8: adrp    x0, #0x6264000                             
02c865fc: ldr     x0, [x0, #0xd60]                           MS:PoolerBase`1::InitPool
02c86600: bl      #0x2b70db0                                 fn_2b70db0
02c86604: adrp    x0, #0x6264000                             
02c86608: ldr     x0, [x0, #0xd70]                           MS:PoolerBase`1::Release
02c8660c: bl      #0x2b70db0                                 fn_2b70db0
02c86610: mov     w8, #1                                     
02c86614: strb    w8, [x23, #0x94b]                          
02c86618: ldr     x1, [x19, #0x30]                           ._itemPrefab
02c8661c: ldr     x5, [x22]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c86620: mov     x0, x19                                    
02c86624: mov     w2, #0xa                                   
02c86628: mov     w3, #0x14                                  
02c8662c: mov     w4, wzr                                    
02c86630: bl      #0x39940d4                                 fn_39940d4
02c86634: ldr     x1, [x21]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c86638: mov     x0, x19                                    
02c8663c: bl      #0x39943a4                                 fn_39943a4
02c86640: ldr     x2, [x20]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c86644: mov     x1, x0                                     
02c86648: mov     x0, x19                                    
02c8664c: ldp     x20, x19, [sp, #0x20]                      
02c86650: ldp     x22, x21, [sp, #0x10]                      
02c86654: ldp     x30, x23, [sp], #0x30                      
02c86658: b       #0x39943d8                                 
## GetSetup(Item shape) -> void
---- ItemSpawner::GetSetup 0x2c8665c
02c8665c: str     x30, [sp, #-0x30]!                         
02c86660: stp     x22, x21, [sp, #0x10]                      
02c86664: stp     x20, x19, [sp, #0x20]                      
02c86668: adrp    x21, #0x662f000                            
02c8666c: adrp    x22, #0x6264000                            
02c86670: mov     x19, x1                                    
02c86674: ldrb    w8, [x21, #0x94c]                          
02c86678: ldr     x22, [x22, #0xd78]                         MS:PoolerBase`1::GetSetup
02c8667c: mov     x20, x0                                    
02c86680: tbnz    w8, #0, #0x2c86698                         
02c86684: adrp    x0, #0x6264000                             
02c86688: ldr     x0, [x0, #0xd78]                           MS:PoolerBase`1::GetSetup
02c8668c: bl      #0x2b70db0                                 fn_2b70db0
02c86690: mov     w8, #1                                     
02c86694: strb    w8, [x21, #0x94c]                          
02c86698: ldr     x2, [x22]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c8669c: mov     x0, x20                                    
02c866a0: mov     x1, x19                                    
02c866a4: bl      #0x39942f4                                 fn_39942f4
02c866a8: cbz     x19, #0x2c86710                            
02c866ac: mov     x0, x19                                    
02c866b0: mov     x1, xzr                                    
02c866b4: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02c866b8: adrp    x20, #0x662f000                            
02c866bc: mov     x19, x0                                    
02c866c0: ldrb    w8, [x20, #0x91a]                          
02c866c4: cbnz    w8, #0x2c866dc                             
02c866c8: adrp    x0, #0x6264000                             
02c866cc: ldr     x0, [x0, #0xd8]                            T:UnityEngine.Vector3
02c866d0: bl      #0x2b70db0                                 fn_2b70db0
02c866d4: mov     w8, #1                                     
02c866d8: strb    w8, [x20, #0x91a]                          
02c866dc: cbz     x19, #0x2c86710                            
02c866e0: adrp    x8, #0x6264000                             
02c866e4: mov     x0, x19                                    
02c866e8: mov     x1, xzr                                    
02c866ec: ldr     x8, [x8, #0xd8]                            T:UnityEngine.Vector3
02c866f0: ldp     x20, x19, [sp, #0x20]                      
02c866f4: ldp     x22, x21, [sp, #0x10]                      
02c866f8: ldr     x8, [x8]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c866fc: ldr     x8, [x8, #0xb8]                            MS:DG.Tweening.Core.Extensions::SetSpecialStartupMode
02c86700: ldp     s0, s1, [x8]                               
02c86704: ldr     s2, [x8, #8]                               T:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass2_0
02c86708: ldr     x30, [sp], #0x30                           
02c8670c: b       #0x5b46888                                 UnityEngine.Transform::set_position
02c86710: bl      #0x2b7105c                                 fn_2b7105c
## .ctor() -> void
---- ItemSpawner::.ctor 0x2c86714
02c86714: stp     x30, x21, [sp, #-0x20]!                    
02c86718: stp     x20, x19, [sp, #0x10]                      
02c8671c: adrp    x20, #0x662f000                            
02c86720: adrp    x21, #0x6264000                            
02c86724: mov     x19, x0                                    
02c86728: ldrb    w8, [x20, #0x94d]                          
02c8672c: ldr     x21, [x21, #0xd80]                         MS:PoolerBase`1::.ctor
02c86730: tbnz    w8, #0, #0x2c86748                         
02c86734: adrp    x0, #0x6264000                             
02c86738: ldr     x0, [x0, #0xd80]                           MS:PoolerBase`1::.ctor
02c8673c: bl      #0x2b70db0                                 fn_2b70db0
02c86740: mov     w8, #1                                     
02c86744: strb    w8, [x20, #0x94d]                          
02c86748: mov     x0, x19                                    
02c8674c: ldp     x20, x19, [sp, #0x10]                      
02c86750: ldr     x1, [x21]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c86754: ldp     x30, x21, [sp], #0x20                      
02c86758: b       #0x399441c                                 
