#### CLASS Framework.MinMaxRangeAttribute parent= UnityEngine.PropertyAttribute
#   field min                            float                                              off=0x14 attr=26 
#   field max                            float                                              off=0x18 attr=26 
## .ctor(float min, float max) -> void
---- Framework.MinMaxRangeAttribute::.ctor 0x2cb83d8
02cb83d8: stp     d9, d8, [sp, #-0x20]!                      
02cb83dc: stp     x30, x19, [sp, #0x10]                      
02cb83e0: mov     x1, xzr                                    
02cb83e4: fmov    s8, s1                                     
02cb83e8: fmov    s9, s0                                     
02cb83ec: mov     x19, x0                                    
02cb83f0: bl      #0x5b2d93c                                 UnityEngine.PropertyAttribute::.ctor
02cb83f4: stp     s9, s8, [x19, #0x14]                       .min
02cb83f8: ldp     x30, x19, [sp, #0x10]                      
02cb83fc: ldp     d9, d8, [sp], #0x20                        
02cb8400: ret                                                
