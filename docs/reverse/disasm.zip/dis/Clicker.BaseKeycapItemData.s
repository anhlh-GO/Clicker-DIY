#### CLASS Clicker.BaseKeycapItemData parent= object
#   field Id                             int                                                off=0x10 attr=6 
#   field Icon                           UnityEngine.Sprite                                 off=0x18 attr=6 
#   field SwitchAmount                   int                                                off=0x20 attr=6 
#   field OnPrinterSpr                   UnityEngine.Sprite                                 off=0x28 attr=6 
#   field OnTraySpr                      UnityEngine.Sprite                                 off=0x30 attr=6 
#   field BasePrinterObject              Clicker.BasePrinterObject                          off=0x38 attr=6 
#   field BaseKeycapObject               Clicker.BaseKeycapObject                           off=0x40 attr=6 
#   field UnlockMethod                   Clicker.UnlockMethod                               off=0x48 attr=6 
## .ctor() -> void
---- Clicker.BaseKeycapItemData::.ctor 0x2d5b4b8
02d5b4b8: mov     x1, xzr                                    
02d5b4bc: b       #0x4e53e9c                                 System.Object::.ctor
