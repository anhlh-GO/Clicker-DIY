#### CLASS BlindBagCollection.BlindBoxPlate/<>c parent= object
#   field <>9                            BlindBagCollection.BlindBoxPlate/<>c               off=0x0 attr=36 
#   field <>9__12_0                      System.Predicate`1<BlindBagCollection.BlindbagCollectionBox> off=0x8 attr=16 
## .cctor() -> void
---- BlindBagCollection.BlindBoxPlate/<>c::.cctor 0x2d38ba4
02d38ba4: str     x30, [sp, #-0x20]!                         
02d38ba8: stp     x20, x19, [sp, #0x10]                      
02d38bac: adrp    x19, #0x6630000                            
02d38bb0: adrp    x20, #0x626a000                            
02d38bb4: ldrb    w8, [x19, #0x13b]                          
02d38bb8: ldr     x20, [x20, #0x9f8]                         T:BlindBagCollection.BlindBoxPlate/<>c
02d38bbc: tbnz    w8, #0, #0x2d38bd4                         
02d38bc0: adrp    x0, #0x626a000                             
02d38bc4: ldr     x0, [x0, #0x9f8]                           T:BlindBagCollection.BlindBoxPlate/<>c
02d38bc8: bl      #0x2b70db0                                 fn_2b70db0
02d38bcc: mov     w8, #1                                     
02d38bd0: strb    w8, [x19, #0x13b]                          
02d38bd4: ldr     x0, [x20]                                  T:type56879(k15)
02d38bd8: bl      #0x2b7104c                                 fn_2b7104c
02d38bdc: mov     x1, xzr                                    
02d38be0: mov     x19, x0                                    
02d38be4: bl      #0x4e53e9c                                 System.Object::.ctor
02d38be8: ldr     x8, [x20]                                  T:type56879(k15)
02d38bec: mov     x1, x19                                    
02d38bf0: ldr     x8, [x8, #0xb8]                            
02d38bf4: str     x19, [x8]                                  
02d38bf8: ldr     x8, [x20]                                  T:type56879(k15)
02d38bfc: ldp     x20, x19, [sp, #0x10]                      
02d38c00: ldr     x0, [x8, #0xb8]                            
02d38c04: ldr     x30, [sp], #0x20                           
02d38c08: b       #0x2b70d54                                 
## .ctor() -> void
---- BlindBagCollection.BlindBoxPlate/<>c::.ctor 0x2d38c0c
02d38c0c: mov     x1, xzr                                    
02d38c10: b       #0x4e53e9c                                 System.Object::.ctor
## <get_DoneUnbox>b__12_0(BlindBagCollection.BlindbagCollectionBox x) -> bool
---- BlindBagCollection.BlindBoxPlate/<>c::<get_DoneUnbox>b__12_0 0x2d38c14
02d38c14: cbz     x1, #0x2d38c28                             
02d38c18: ldrb    w8, [x1, #0x91]                            
02d38c1c: cmp     w8, #0                                     
02d38c20: cset    w0, eq                                     
02d38c24: ret                                                
02d38c28: str     x30, [sp, #-0x10]!                         
02d38c2c: bl      #0x2b7105c                                 fn_2b7105c
#### CLASS BlindBagCollection.BlindBoxPlate/<>c__DisplayClass18_0 parent= object
#   field <>4__this                      BlindBagCollection.BlindBoxPlate                   off=0x10 attr=6 
#   field cachedIndex                    int                                                off=0x18 attr=6 
## .ctor() -> void
---- BlindBagCollection.BlindBoxPlate/<>c__DisplayClass18_0::.ctor 0x2d38af0
02d38af0: mov     x1, xzr                                    
02d38af4: b       #0x4e53e9c                                 System.Object::.ctor
## <CheckPopOutBlindBox>b__0() -> void
---- BlindBagCollection.BlindBoxPlate/<>c__DisplayClass18_0::<CheckPopOutBlindBox>b__0 0x2d38c30
02d38c30: stp     x30, x21, [sp, #-0x20]!                    
02d38c34: stp     x20, x19, [sp, #0x10]                      
02d38c38: adrp    x20, #0x6630000                            
02d38c3c: adrp    x21, #0x6267000                            
02d38c40: mov     x19, x0                                    
02d38c44: ldrb    w8, [x20, #0x13c]                          
02d38c48: ldr     x21, [x21, #0xea8]                         T:Framework.Vibration
02d38c4c: tbnz    w8, #0, #0x2d38c70                         
02d38c50: adrp    x0, #0x626a000                             
02d38c54: ldr     x0, [x0, #0xc18]                           MS:System.Collections.Generic.List`1::get_Item
02d38c58: bl      #0x2b70db0                                 fn_2b70db0
02d38c5c: adrp    x0, #0x6267000                             
02d38c60: ldr     x0, [x0, #0xea8]                           T:Framework.Vibration
02d38c64: bl      #0x2b70db0                                 fn_2b70db0
02d38c68: mov     w8, #1                                     
02d38c6c: strb    w8, [x20, #0x13c]                          
02d38c70: ldr     x0, [x21]                                  S:'didu'
02d38c74: ldr     w8, [x0, #0xe4]                            [62670e4]=0 f=0,0
02d38c78: cbnz    w8, #0x2d38c80                             
02d38c7c: bl      #0x2b70f30                                 fn_2b70f30
02d38c80: mov     w0, #0x3c                                  
02d38c84: mov     w1, #-1                                    
02d38c88: mov     w2, wzr                                    
02d38c8c: mov     x3, xzr                                    
02d38c90: bl      #0x2d6e144                                 Framework.Vibration::Vibrate
02d38c94: ldr     x8, [x19, #0x10]                           .<>4__this
02d38c98: cbz     x8, #0x2d38cc8                             
02d38c9c: ldr     x0, [x8, #0x28]                            
02d38ca0: cbz     x0, #0x2d38cc8                             
02d38ca4: adrp    x8, #0x626a000                             
02d38ca8: ldr     x8, [x8, #0xc18]                           MS:System.Collections.Generic.List`1::get_Item
02d38cac: ldr     w1, [x19, #0x18]                           .cachedIndex
02d38cb0: ldr     x2, [x8]                                   T:type56879(k15)
02d38cb4: bl      #0x35a8f3c                                 fn_35a8f3c
02d38cb8: cbz     x0, #0x2d38cc8                             
02d38cbc: ldp     x20, x19, [sp, #0x10]                      
02d38cc0: ldp     x30, x21, [sp], #0x20                      
02d38cc4: b       #0x2d321e0                                 BlindBagCollection.BlindbagCollectionBox::EnableClick
02d38cc8: bl      #0x2b7105c                                 fn_2b7105c
#### CLASS BlindBagCollection.BlindBoxPlate/<>c__DisplayClass19_0 parent= object
#   field obj                            BlindBagCollection.BlindbagCollectionBox           off=0x10 attr=6 
## .ctor() -> void
---- BlindBagCollection.BlindBoxPlate/<>c__DisplayClass19_0::.ctor 0x2d38af8
02d38af8: mov     x1, xzr                                    
02d38afc: b       #0x4e53e9c                                 System.Object::.ctor
## <AddMoreRandomBox>b__0() -> void
---- BlindBagCollection.BlindBoxPlate/<>c__DisplayClass19_0::<AddMoreRandomBox>b__0 0x2d38ccc
02d38ccc: stp     x30, x21, [sp, #-0x20]!                    
02d38cd0: stp     x20, x19, [sp, #0x10]                      
02d38cd4: adrp    x20, #0x6630000                            
02d38cd8: adrp    x21, #0x6267000                            
02d38cdc: mov     x19, x0                                    
02d38ce0: ldrb    w8, [x20, #0x13d]                          
02d38ce4: ldr     x21, [x21, #0xea8]                         T:Framework.Vibration
02d38ce8: tbnz    w8, #0, #0x2d38d00                         
02d38cec: adrp    x0, #0x6267000                             
02d38cf0: ldr     x0, [x0, #0xea8]                           T:Framework.Vibration
02d38cf4: bl      #0x2b70db0                                 fn_2b70db0
02d38cf8: mov     w8, #1                                     
02d38cfc: strb    w8, [x20, #0x13d]                          
02d38d00: ldr     x0, [x21]                                  S:'didu'
02d38d04: ldr     w8, [x0, #0xe4]                            [62670e4]=0 f=0,0
02d38d08: cbnz    w8, #0x2d38d10                             
02d38d0c: bl      #0x2b70f30                                 fn_2b70f30
02d38d10: mov     w0, #0x3c                                  
02d38d14: mov     w1, #-1                                    
02d38d18: mov     w2, wzr                                    
02d38d1c: mov     x3, xzr                                    
02d38d20: bl      #0x2d6e144                                 Framework.Vibration::Vibrate
02d38d24: ldr     x0, [x19, #0x10]                           .obj
02d38d28: cbz     x0, #0x2d38d38                             
02d38d2c: ldp     x20, x19, [sp, #0x10]                      
02d38d30: ldp     x30, x21, [sp], #0x20                      
02d38d34: b       #0x2d321e0                                 BlindBagCollection.BlindbagCollectionBox::EnableClick
02d38d38: bl      #0x2b7105c                                 fn_2b7105c
#### CLASS BlindBagCollection.BlindBoxPlate parent= UnityEngine.MonoBehaviour
#   field _blindBoxItem                  BlindBagCollection.BlindbagCollectionBox           off=0x20 attr=1 SerializeField
#   field _spawnedBlindBox               System.Collections.Generic.List`1<BlindBagCollection.BlindbagCollectionBox> off=0x28 attr=1 SerializeField
#   field _tfHolder                      UnityEngine.Transform                              off=0x30 attr=1 SerializeField
#   field _tfPlateHoldResult             UnityEngine.Transform                              off=0x38 attr=1 SerializeField
#   field _tfTopRight                    UnityEngine.Transform                              off=0x40 attr=1 SerializeField
#   field _tfBottomLeft                  UnityEngine.Transform                              off=0x48 attr=1 SerializeField
#   field _tfTopRightOpen                UnityEngine.Transform                              off=0x50 attr=1 SerializeField
#   field _tfBottomLeftOpen              UnityEngine.Transform                              off=0x58 attr=1 SerializeField
#   field _tfTopRightPlate               UnityEngine.Transform                              off=0x60 attr=1 SerializeField
#   field _tfBottomLeftPlate             UnityEngine.Transform                              off=0x68 attr=1 SerializeField
#   field _collider                      UnityEngine.Collider2D                             off=0x70 attr=1 SerializeField
#   field _currentBoxHold                int                                                off=0x78 attr=1 
## get_DoneUnbox() -> bool
---- BlindBagCollection.BlindBoxPlate::get_DoneUnbox 0x2d35350
02d35350: str     x30, [sp, #-0x30]!                         
02d35354: stp     x22, x21, [sp, #0x10]                      
02d35358: stp     x20, x19, [sp, #0x20]                      
02d3535c: adrp    x20, #0x6630000                            
02d35360: mov     x19, x0                                    
02d35364: ldrb    w8, [x20, #0x134]                          
02d35368: tbnz    w8, #0, #0x2d353c8                         
02d3536c: adrp    x0, #0x6263000                             
02d35370: ldr     x0, [x0, #0x928]                           T:UnityEngine.Debug
02d35374: bl      #0x2b70db0                                 fn_2b70db0
02d35378: adrp    x0, #0x626a000                             
02d3537c: ldr     x0, [x0, #0x9e0]                           MS:System.Collections.Generic.List`1::FindAll
02d35380: bl      #0x2b70db0                                 fn_2b70db0
02d35384: adrp    x0, #0x626a000                             
02d35388: ldr     x0, [x0, #0x878]                           MS:System.Collections.Generic.List`1::get_Count
02d3538c: bl      #0x2b70db0                                 fn_2b70db0
02d35390: adrp    x0, #0x626a000                             
02d35394: ldr     x0, [x0, #0x9e8]                           T:type57222(k15)
02d35398: bl      #0x2b70db0                                 fn_2b70db0
02d3539c: adrp    x0, #0x626a000                             
02d353a0: ldr     x0, [x0, #0x9f0]                           M:BlindBagCollection.BlindBoxPlate/<>c::<get_DoneUnbox>b__12_0
02d353a4: bl      #0x2b70db0                                 fn_2b70db0
02d353a8: adrp    x0, #0x626a000                             
02d353ac: ldr     x0, [x0, #0x9f8]                           T:BlindBagCollection.BlindBoxPlate/<>c
02d353b0: bl      #0x2b70db0                                 fn_2b70db0
02d353b4: adrp    x0, #0x626a000                             
02d353b8: ldr     x0, [x0, #0xa00]                           S:'dev log _spawnedBlindBox count GET {0}'
02d353bc: bl      #0x2b70db0                                 fn_2b70db0
02d353c0: mov     w8, #1                                     
02d353c4: strb    w8, [x20, #0x134]                          
02d353c8: ldr     x8, [x19, #0x28]                           ._spawnedBlindBox
02d353cc: cbz     x8, #0x2d354f4                             
02d353d0: adrp    x20, #0x626a000                            
02d353d4: adrp    x9, #0x6263000                             
02d353d8: adrp    x21, #0x6263000                            
02d353dc: ldr     x20, [x20, #0xa00]                         S:'dev log _spawnedBlindBox count GET {0}'
02d353e0: ldr     x9, [x9, #0x970]                           &6645c70(=0)
02d353e4: adrp    x22, #0x626a000                            
02d353e8: ldr     x21, [x21, #0x928]                         T:UnityEngine.Debug
02d353ec: ldr     w8, [x8, #0x18]                            
02d353f0: ldr     x22, [x22, #0x9f8]                         T:BlindBagCollection.BlindBoxPlate/<>c
02d353f4: ldr     x0, [x9, #0x48]                            &6263098(=0)
02d353f8: add     x1, sp, #0xc                               
02d353fc: str     w8, [sp, #0xc]                             
02d35400: bl      #0x2b70f38                                 fn_2b70f38
02d35404: ldr     x8, [x20]                                  T:type56879(k15)
02d35408: mov     x1, x0                                     
02d3540c: mov     x2, xzr                                    
02d35410: mov     x0, x8                                     
02d35414: bl      #0x4c9d0ec                                 System.String::Format
02d35418: ldr     x8, [x21]                                  &2c5bbd4(=a9bd7bfdd503233f)
02d3541c: mov     x20, x0                                    
02d35420: ldr     w9, [x8, #0xe4]                            
02d35424: cbnz    w9, #0x2d35430                             
02d35428: mov     x0, x8                                     
02d3542c: bl      #0x2b70f30                                 fn_2b70f30
02d35430: mov     x0, x20                                    
02d35434: mov     x1, xzr                                    
02d35438: bl      #0x5af21f4                                 UnityEngine.Debug::Log
02d3543c: ldr     x0, [x22]                                  T:type56879(k15)
02d35440: ldr     x19, [x19, #0x28]                          ._spawnedBlindBox
02d35444: ldr     w8, [x0, #0xe4]                            [626a0e4]=0 f=0,0
02d35448: cbnz    w8, #0x2d35454                             
02d3544c: bl      #0x2b70f30                                 fn_2b70f30
02d35450: ldr     x0, [x22]                                  T:type56879(k15)
02d35454: ldr     x8, [x0, #0xb8]                            MS:UnityEngine.Object::FindObjectsOfType
02d35458: ldr     x20, [x8, #8]                              
02d3545c: cbnz    x20, #0x2d354b8                            
02d35460: ldr     w9, [x0, #0xe4]                            [626a0e4]=0 f=0,0
02d35464: cbnz    w9, #0x2d35474                             
02d35468: bl      #0x2b70f30                                 fn_2b70f30
02d3546c: ldr     x8, [x22]                                  T:type56879(k15)
02d35470: ldr     x8, [x8, #0xb8]                            
02d35474: adrp    x9, #0x626a000                             
02d35478: ldr     x9, [x9, #0x9e8]                           T:type57222(k15)
02d3547c: ldr     x21, [x8]                                  
02d35480: ldr     x0, [x9]                                   T:type56879(k15)
02d35484: bl      #0x2b7104c                                 fn_2b7104c
02d35488: adrp    x8, #0x626a000                             
02d3548c: mov     x1, x21                                    
02d35490: mov     x3, xzr                                    
02d35494: ldr     x8, [x8, #0x9f0]                           M:BlindBagCollection.BlindBoxPlate/<>c::<get_DoneUnbox>b__12_0
02d35498: mov     x20, x0                                    
02d3549c: ldr     x2, [x8]                                   T:type56879(k15)
02d354a0: bl      #0x399ba10                                 fn_399ba10
02d354a4: ldr     x8, [x22]                                  T:type56879(k15)
02d354a8: mov     x1, x20                                    
02d354ac: ldr     x0, [x8, #0xb8]                            MS:UnityEngine.Object::FindObjectsOfType
02d354b0: str     x20, [x0, #8]!                             
02d354b4: bl      #0x2b70d54                                 fn_2b70d54
02d354b8: cbz     x19, #0x2d354f4                            
02d354bc: adrp    x8, #0x626a000                             
02d354c0: mov     x0, x19                                    
02d354c4: mov     x1, x20                                    
02d354c8: ldr     x8, [x8, #0x9e0]                           MS:System.Collections.Generic.List`1::FindAll
02d354cc: ldr     x2, [x8]                                   T:type56879(k15)
02d354d0: bl      #0x35a9914                                 fn_35a9914
02d354d4: cbz     x0, #0x2d354f4                             
02d354d8: ldr     w8, [x0, #0x18]                            MS:System.Collections.Generic.List`1::Add
02d354dc: ldp     x20, x19, [sp, #0x20]                      
02d354e0: ldp     x22, x21, [sp, #0x10]                      
02d354e4: cmp     w8, #0                                     
02d354e8: cset    w0, eq                                     
02d354ec: ldr     x30, [sp], #0x30                           
02d354f0: ret                                                
02d354f4: bl      #0x2b7105c                                 fn_2b7105c
## ClearPlate() -> void
---- BlindBagCollection.BlindBoxPlate::ClearPlate 0x2d3304c
02d3304c: sub     sp, sp, #0x70                              
02d33050: stp     x30, x23, [sp, #0x40]                      
02d33054: stp     x22, x21, [sp, #0x50]                      
02d33058: stp     x20, x19, [sp, #0x60]                      
02d3305c: adrp    x20, #0x6630000                            
02d33060: mov     x19, x0                                    
02d33064: ldrb    w8, [x20, #0x135]                          
02d33068: tbnz    w8, #0, #0x2d330bc                         
02d3306c: adrp    x0, #0x626a000                             
02d33070: ldr     x0, [x0, #0x840]                           MS:System.Collections.Generic.List`1/Enumerator::Dispose
02d33074: bl      #0x2b70db0                                 fn_2b70db0
02d33078: adrp    x0, #0x626a000                             
02d3307c: ldr     x0, [x0, #0x848]                           MS:System.Collections.Generic.List`1/Enumerator::MoveNext
02d33080: bl      #0x2b70db0                                 fn_2b70db0
02d33084: adrp    x0, #0x626a000                             
02d33088: ldr     x0, [x0, #0x850]                           MS:System.Collections.Generic.List`1/Enumerator::get_Current
02d3308c: bl      #0x2b70db0                                 fn_2b70db0
02d33090: adrp    x0, #0x626a000                             
02d33094: ldr     x0, [x0, #0x858]                           MS:System.Collections.Generic.List`1::Clear
02d33098: bl      #0x2b70db0                                 fn_2b70db0
02d3309c: adrp    x0, #0x626a000                             
02d330a0: ldr     x0, [x0, #0x860]                           MS:System.Collections.Generic.List`1::GetEnumerator
02d330a4: bl      #0x2b70db0                                 fn_2b70db0
02d330a8: adrp    x0, #0x6263000                             
02d330ac: ldr     x0, [x0, #0x918]                           T:UnityEngine.Object
02d330b0: bl      #0x2b70db0                                 fn_2b70db0
02d330b4: mov     w8, #1                                     
02d330b8: strb    w8, [x20, #0x135]                          
02d330bc: ldr     x0, [x19, #0x28]                           ._spawnedBlindBox
02d330c0: stp     xzr, xzr, [sp, #0x20]                      
02d330c4: str     xzr, [sp, #0x30]                           
02d330c8: cbz     x0, #0x2d331d0                             
02d330cc: adrp    x8, #0x626a000                             
02d330d0: adrp    x22, #0x626a000                            
02d330d4: adrp    x23, #0x6263000                            
02d330d8: ldr     x8, [x8, #0x860]                           MS:System.Collections.Generic.List`1::GetEnumerator
02d330dc: adrp    x21, #0x626a000                            
02d330e0: ldr     x22, [x22, #0x848]                         MS:System.Collections.Generic.List`1/Enumerator::MoveNext
02d330e4: ldr     x23, [x23, #0x918]                         T:UnityEngine.Object
02d330e8: ldr     x21, [x21, #0x840]                         MS:System.Collections.Generic.List`1/Enumerator::Dispose
02d330ec: ldr     x1, [x8]                                   T:type56879(k15)
02d330f0: add     x8, sp, #8                                 
02d330f4: bl      #0x35a9d9c                                 fn_35a9d9c
02d330f8: ldr     x8, [sp, #0x18]                            
02d330fc: ldur    q0, [sp, #8]                               
02d33100: str     x8, [sp, #0x30]                            
02d33104: add     x8, sp, #0x20                              
02d33108: str     q0, [sp, #0x20]                            
02d3310c: stp     xzr, x8, [sp, #8]                          
02d33110: ldr     x1, [x22]                                  T:type56879(k15)
02d33114: add     x0, sp, #0x20                              
02d33118: bl      #0x4690474                                 fn_4690474
02d3311c: tbz     w0, #0, #0x2d3317c                         
02d33120: ldr     x0, [x23]                                  &2c5bbd4(=a9bd7bfdd503233f)
02d33124: ldr     x20, [sp, #0x30]                           
02d33128: ldr     w8, [x0, #0xe4]                            [62630e4]=0 f=0,0
02d3312c: cbnz    w8, #0x2d33134                             
02d33130: bl      #0x2b70f30                                 fn_2b70f30
02d33134: mov     x0, x20                                    
02d33138: mov     x1, xzr                                    
02d3313c: mov     x2, xzr                                    
02d33140: bl      #0x5b3666c                                 UnityEngine.Object::op_Inequality
02d33144: tbz     w0, #0, #0x2d33110                         
02d33148: cbz     x20, #0x2d331cc                            
02d3314c: mov     x0, x20                                    
02d33150: mov     x1, xzr                                    
02d33154: bl      #0x5b339ec                                 UnityEngine.Component::get_gameObject
02d33158: mov     x20, x0                                    
02d3315c: ldr     x0, [x23]                                  &2c5bbd4(=a9bd7bfdd503233f)
02d33160: ldr     w8, [x0, #0xe4]                            [62630e4]=0 f=0,0
02d33164: cbnz    w8, #0x2d3316c                             
02d33168: bl      #0x2b70f30                                 fn_2b70f30
02d3316c: mov     x0, x20                                    
02d33170: mov     x1, xzr                                    
02d33174: bl      #0x5b3ca38                                 UnityEngine.Object::Destroy
02d33178: b       #0x2d33110                                 
02d3317c: ldr     x1, [x21]                                  T:type56879(k15)
02d33180: add     x0, sp, #0x20                              
02d33184: bl      #0x4690470                                 fn_4690470
02d33188: ldr     x8, [x19, #0x28]                           ._spawnedBlindBox
02d3318c: cbz     x8, #0x2d331d0                             
02d33190: ldp     w2, w9, [x8, #0x18]                        
02d33194: add     w9, w9, #1                                 
02d33198: cmp     w2, #1                                     
02d3319c: stp     wzr, w9, [x8, #0x18]                       
02d331a0: b.lt    #0x2d331b4                                 
02d331a4: ldr     x0, [x8, #0x10]                            T:Decor.DataDecor/CategoryData
02d331a8: mov     w1, wzr                                    
02d331ac: mov     x3, xzr                                    
02d331b0: bl      #0x4e3494c                                 System.Array::Clear
02d331b4: str     wzr, [x19, #0x78]                          ._currentBoxHold
02d331b8: ldp     x20, x19, [sp, #0x60]                      
02d331bc: ldp     x22, x21, [sp, #0x50]                      
02d331c0: ldp     x30, x23, [sp, #0x40]                      
02d331c4: add     sp, sp, #0x70                              
02d331c8: ret                                                
02d331cc: bl      #0x2b7105c                                 fn_2b7105c
02d331d0: bl      #0x2b7105c                                 fn_2b7105c
02d331d4: b       #0x2d331e4                                 
02d331d8: b       #0x2d331e4                                 
02d331dc: b       #0x2d331e4                                 
02d331e0: b       #0x2d331e4                                 
02d331e4: mov     x20, x0                                    
02d331e8: cmp     w1, #1                                     
02d331ec: b.ne    #0x2d33220                                 
02d331f0: mov     x0, x20                                    
02d331f4: bl      #0x5e90260                                 fn_5e90260
02d331f8: ldr     x20, [x0]                                  &2c5bbd4(=a9bd7bfdd503233f)
02d331fc: str     x20, [sp, #8]                              
02d33200: bl      #0x5e90270                                 fn_5e90270
02d33204: ldr     x0, [sp, #0x10]                            
02d33208: ldr     x1, [x21]                                  T:type56879(k15)
02d3320c: bl      #0x4690470                                 fn_4690470
02d33210: cbz     x20, #0x2d33188                            
02d33214: mov     x0, x20                                    
02d33218: bl      #0x2b71054                                 fn_2b71054
02d3321c: mov     x20, x0                                    
02d33220: add     x0, sp, #8                                 
02d33224: bl      #0x2738338                                 fn_2738338
02d33228: mov     x0, x20                                    
02d3322c: bl      #0x2c6051c                                 fn_2c6051c
02d33230: bl      #0x27369b8                                 fn_27369b8
## SpawnBlindBox(UnityEngine.Sprite charmSprite, string skinName, bool isLuck, RarityType rarityType) -> void
---- BlindBagCollection.BlindBoxPlate::SpawnBlindBox 0x2d33fb4
02d33fb4: sub     sp, sp, #0x90                              
02d33fb8: str     d14, [sp, #0x10]                           
02d33fbc: stp     d13, d12, [sp, #0x18]                      
02d33fc0: stp     d11, d10, [sp, #0x28]                      
02d33fc4: stp     d9, d8, [sp, #0x38]                        
02d33fc8: str     x30, [sp, #0x48]                           
02d33fcc: stp     x26, x25, [sp, #0x50]                      
02d33fd0: stp     x24, x23, [sp, #0x60]                      
02d33fd4: stp     x22, x21, [sp, #0x70]                      
02d33fd8: stp     x20, x19, [sp, #0x80]                      
02d33fdc: adrp    x24, #0x6630000                            
02d33fe0: mov     w20, w4                                    
02d33fe4: mov     w22, w3                                    
02d33fe8: ldrb    w8, [x24, #0x136]                          
02d33fec: mov     x23, x2                                    
02d33ff0: mov     x21, x1                                    
02d33ff4: mov     x19, x0                                    
02d33ff8: tbnz    w8, #0, #0x2d3404c                         
02d33ffc: adrp    x0, #0x6263000                             
02d34000: ldr     x0, [x0, #0x928]                           T:UnityEngine.Debug
02d34004: bl      #0x2b70db0                                 fn_2b70db0
02d34008: adrp    x0, #0x626a000                             
02d3400c: ldr     x0, [x0, #0x8a0]                           MS:System.Collections.Generic.List`1::Add
02d34010: bl      #0x2b70db0                                 fn_2b70db0
02d34014: adrp    x0, #0x626a000                             
02d34018: ldr     x0, [x0, #0x878]                           MS:System.Collections.Generic.List`1::get_Count
02d3401c: bl      #0x2b70db0                                 fn_2b70db0
02d34020: adrp    x0, #0x626a000                             
02d34024: ldr     x0, [x0, #0x8a8]                           MS:UnityEngine.Object::Instantiate
02d34028: bl      #0x2b70db0                                 fn_2b70db0
02d3402c: adrp    x0, #0x6263000                             
02d34030: ldr     x0, [x0, #0x918]                           T:UnityEngine.Object
02d34034: bl      #0x2b70db0                                 fn_2b70db0
02d34038: adrp    x0, #0x626a000                             
02d3403c: ldr     x0, [x0, #0x8b8]                           S:'dev log _spawnedBlindBox count {0}'
02d34040: bl      #0x2b70db0                                 fn_2b70db0
02d34044: mov     w8, #1                                     
02d34048: strb    w8, [x24, #0x136]                          
02d3404c: ldr     x0, [x19, #0x48]                           ._tfBottomLeft
02d34050: cbz     x0, #0x2d342a8                             
02d34054: mov     x1, xzr                                    
02d34058: bl      #0x5b467ac                                 UnityEngine.Transform::get_position
02d3405c: ldr     x0, [x19, #0x40]                           ._tfTopRight
02d34060: cbz     x0, #0x2d342a8                             
02d34064: mov     x1, xzr                                    
02d34068: fmov    s8, s0                                     
02d3406c: bl      #0x5b467ac                                 UnityEngine.Transform::get_position
02d34070: fmov    s1, s0                                     
02d34074: fmov    s0, s8                                     
02d34078: mov     x0, xzr                                    
02d3407c: bl      #0x5b2dfc0                                 UnityEngine.Random::Range
02d34080: ldr     x0, [x19, #0x48]                           ._tfBottomLeft
02d34084: cbz     x0, #0x2d342a8                             
02d34088: mov     x1, xzr                                    
02d3408c: fmov    s8, s0                                     
02d34090: bl      #0x5b467ac                                 UnityEngine.Transform::get_position
02d34094: ldr     x0, [x19, #0x40]                           ._tfTopRight
02d34098: cbz     x0, #0x2d342a8                             
02d3409c: mov     x1, xzr                                    
02d340a0: fmov    s9, s1                                     
02d340a4: bl      #0x5b467ac                                 UnityEngine.Transform::get_position
02d340a8: fmov    s0, s9                                     
02d340ac: mov     x0, xzr                                    
02d340b0: bl      #0x5b2dfc0                                 UnityEngine.Random::Range
02d340b4: ldr     x8, [x19, #0x28]                           ._spawnedBlindBox
02d340b8: cbz     x8, #0x2d342a8                             
02d340bc: fmov    s9, s0                                     
02d340c0: ldr     s0, [x8, #0x18]                            
02d340c4: adrp    x8, #0x1084000                             
02d340c8: ldr     s1, [x8, #0xeec]                           [1084eec]=457ff0003dcccccd f=0.1,4095
02d340cc: mov     w8, #0x43b40000                            
02d340d0: adrp    x25, #0x6263000                            
02d340d4: scvtf   s0, s0                                     
02d340d8: adrp    x26, #0x626a000                            
02d340dc: ldr     x25, [x25, #0x918]                         T:UnityEngine.Object
02d340e0: ldr     x26, [x26, #0x8a8]                         MS:UnityEngine.Object::Instantiate
02d340e4: mov     x0, xzr                                    
02d340e8: fmul    s10, s0, s1                                
02d340ec: movi    d0, #0000000000000000                      
02d340f0: fmov    s1, w8                                     
02d340f4: bl      #0x5b2dfc0                                 UnityEngine.Random::Range
02d340f8: adrp    x8, #0x1085000                             
02d340fc: ldr     x24, [x19, #0x20]                          ._blindBoxItem
02d34100: mov     x0, sp                                     
02d34104: ldr     s1, [x8, #0x10]                            [1085010]=4202c6f23c8efa35 f=0.0174533,32.6943
02d34108: mov     x1, xzr                                    
02d3410c: str     xzr, [sp]                                  
02d34110: fmul    s0, s0, s1                                 
02d34114: str     s0, [sp, #8]                               
02d34118: bl      #0x5b2607c                                 UnityEngine.Quaternion::Internal_FromEulerRad
02d3411c: fmov    s11, s0                                    
02d34120: fmov    s12, s1                                    
02d34124: ldr     x0, [x25]                                  &2c5bbd4(=a9bd7bfdd503233f)
02d34128: fmov    s13, s2                                    
02d3412c: fmov    s14, s3                                    
02d34130: ldr     x25, [x19, #0x30]                          ._tfHolder
02d34134: ldr     w8, [x0, #0xe4]                            [626a0e4]=0 f=0,0
02d34138: cbnz    w8, #0x2d34140                             
02d3413c: bl      #0x2b70f30                                 fn_2b70f30
02d34140: fmov    s0, s8                                     
02d34144: fmov    s1, s9                                     
02d34148: ldr     x2, [x26]                                  T:type56879(k15)
02d3414c: fmov    s2, s10                                    
02d34150: fmov    s3, s11                                    
02d34154: mov     x0, x24                                    
02d34158: fmov    s4, s12                                    
02d3415c: fmov    s5, s13                                    
02d34160: mov     x1, x25                                    
02d34164: fmov    s6, s14                                    
02d34168: bl      #0x3276204                                 fn_3276204
02d3416c: cbz     x0, #0x2d342a8                             
02d34170: mov     x1, x23                                    
02d34174: mov     x24, x0                                    
02d34178: bl      #0x2d31500                                 BlindBagCollection.BlindbagCollectionBox::SetSkinBag
02d3417c: and     w2, w22, #1                                
02d34180: mov     x0, x24                                    
02d34184: mov     x1, x21                                    
02d34188: mov     w3, w20                                    
02d3418c: bl      #0x2d31594                                 BlindBagCollection.BlindbagCollectionBox::SetData
02d34190: mov     x0, x24                                    
02d34194: bl      #0x2d314e4                                 BlindBagCollection.BlindbagCollectionBox::DisableClick
02d34198: ldr     x0, [x19, #0x28]                           ._spawnedBlindBox
02d3419c: cbz     x0, #0x2d342a8                             
02d341a0: adrp    x9, #0x626a000                             
02d341a4: ldr     x9, [x9, #0x8a0]                           MS:System.Collections.Generic.List`1::Add
02d341a8: ldr     w10, [x0, #0x1c]                           [626a01c]=0 f=0,0
02d341ac: ldr     x8, [x0, #0x10]                            T:Decor.DataDecor/CategoryData
02d341b0: ldr     x9, [x9]                                   T:type56879(k15)
02d341b4: add     w10, w10, #1                               
02d341b8: str     w10, [x0, #0x1c]                           
02d341bc: cbz     x8, #0x2d342a8                             
02d341c0: ldrsw   x10, [x0, #0x18]                           
02d341c4: ldr     w11, [x8, #0x18]                           [1085018]=47c34f803a83126f f=0.001,99999
02d341c8: cmp     w10, w11                                   
02d341cc: b.hs    #0x2d341f0                                 
02d341d0: add     x8, x8, x10, lsl #3                        &1085000
02d341d4: add     w9, w10, #1                                
02d341d8: mov     x1, x24                                    
02d341dc: str     w9, [x0, #0x18]                            
02d341e0: str     x24, [x8, #0x20]!                          
02d341e4: mov     x0, x8                                     
02d341e8: bl      #0x2b70d54                                 fn_2b70d54
02d341ec: b       #0x2d34204                                 
02d341f0: ldr     x8, [x9, #0x20]                            M:Decor.DataDecor/<>c__DisplayClass8_0::<NewData>b__0
02d341f4: mov     x1, x24                                    
02d341f8: ldr     x8, [x8, #0xc0]                            [10850c0]=bf800000bf800000 f=-1,-1
02d341fc: ldr     x2, [x8, #0x70]                            [1085070]=3f32b2b33e008081 f=0.12549,0.698039
02d34200: bl      #0x35a920c                                 fn_35a920c
02d34204: ldr     w9, [x19, #0x78]                           ._currentBoxHold
02d34208: ldr     x8, [x19, #0x28]                           ._spawnedBlindBox
02d3420c: add     w9, w9, #1                                 
02d34210: str     w9, [x19, #0x78]                           ._currentBoxHold
02d34214: cbz     x8, #0x2d342a8                             
02d34218: adrp    x9, #0x6263000                             
02d3421c: adrp    x19, #0x626a000                            
02d34220: adrp    x20, #0x6263000                            
02d34224: ldr     x9, [x9, #0x970]                           &6645c70(=0)
02d34228: ldr     x19, [x19, #0x8b8]                         S:'dev log _spawnedBlindBox count {0}'
02d3422c: ldr     w8, [x8, #0x18]                            [1085018]=47c34f803a83126f f=0.001,99999
02d34230: ldr     x20, [x20, #0x928]                         T:UnityEngine.Debug
02d34234: mov     x1, sp                                     
02d34238: ldr     x0, [x9, #0x48]                            &6263098(=0)
02d3423c: str     w8, [sp]                                   
02d34240: bl      #0x2b70f38                                 fn_2b70f38
02d34244: ldr     x8, [x19]                                  T:type56879(k15)
02d34248: mov     x1, x0                                     
02d3424c: mov     x2, xzr                                    
02d34250: mov     x0, x8                                     
02d34254: bl      #0x4c9d0ec                                 System.String::Format
02d34258: ldr     x8, [x20]                                  &2c5bbd4(=a9bd7bfdd503233f)
02d3425c: mov     x19, x0                                    
02d34260: ldr     w9, [x8, #0xe4]                            [10850e4]=4876e80000000002 f=2.8026e-45,252832
02d34264: cbnz    w9, #0x2d34270                             
02d34268: mov     x0, x8                                     
02d3426c: bl      #0x2b70f30                                 fn_2b70f30
02d34270: mov     x0, x19                                    
02d34274: mov     x1, xzr                                    
02d34278: bl      #0x5af21f4                                 UnityEngine.Debug::Log
02d3427c: ldp     x20, x19, [sp, #0x80]                      
02d34280: ldr     x30, [sp, #0x48]                           
02d34284: ldp     x22, x21, [sp, #0x70]                      
02d34288: ldr     d14, [sp, #0x10]                           
02d3428c: ldp     x24, x23, [sp, #0x60]                      
02d34290: ldp     x26, x25, [sp, #0x50]                      
02d34294: ldp     d9, d8, [sp, #0x38]                        
02d34298: ldp     d11, d10, [sp, #0x28]                      
02d3429c: ldp     d13, d12, [sp, #0x18]                      
02d342a0: add     sp, sp, #0x90                              
02d342a4: ret                                                
02d342a8: bl      #0x2b7105c                                 fn_2b7105c
## AutoSpawnBlindBox() -> void
---- BlindBagCollection.BlindBoxPlate::AutoSpawnBlindBox 0x2d33370
02d33370: str     d8, [sp, #-0x40]!                          
02d33374: str     x30, [sp, #8]                              
02d33378: stp     x24, x23, [sp, #0x10]                      
02d3337c: stp     x22, x21, [sp, #0x20]                      
02d33380: stp     x20, x19, [sp, #0x30]                      
02d33384: adrp    x20, #0x6630000                            
02d33388: mov     x19, x0                                    
02d3338c: ldrb    w8, [x20, #0x137]                          
02d33390: tbnz    w8, #0, #0x2d333cc                         
02d33394: adrp    x0, #0x626a000                             
02d33398: ldr     x0, [x0, #0x868]                           M:BlindBagCollection.BlindBoxPlate::CheckPopOutBlindBox
02d3339c: bl      #0x2b70db0                                 fn_2b70db0
02d333a0: adrp    x0, #0x626a000                             
02d333a4: ldr     x0, [x0, #0x870]                           M:BlindBagCollection.BlindBoxPlate::<AutoSpawnBlindBox>b__16_0
02d333a8: bl      #0x2b70db0                                 fn_2b70db0
02d333ac: adrp    x0, #0x626a000                             
02d333b0: ldr     x0, [x0, #0x878]                           MS:System.Collections.Generic.List`1::get_Count
02d333b4: bl      #0x2b70db0                                 fn_2b70db0
02d333b8: adrp    x0, #0x6264000                             
02d333bc: ldr     x0, [x0, #0xe8]                            T:DG.Tweening.TweenCallback
02d333c0: bl      #0x2b70db0                                 fn_2b70db0
02d333c4: mov     w8, #1                                     
02d333c8: strb    w8, [x20, #0x137]                          
02d333cc: ldr     x8, [x19, #0x28]                           ._spawnedBlindBox
02d333d0: cbz     x8, #0x2d33448                             
02d333d4: adrp    x21, #0x6264000                            
02d333d8: adrp    x22, #0x626a000                            
02d333dc: adrp    x9, #0x1084000                             
02d333e0: adrp    x23, #0x626a000                            
02d333e4: ldr     x21, [x21, #0xe8]                          T:DG.Tweening.TweenCallback
02d333e8: ldr     x22, [x22, #0x868]                         M:BlindBagCollection.BlindBoxPlate::CheckPopOutBlindBox
02d333ec: ldr     x23, [x23, #0x870]                         M:BlindBagCollection.BlindBoxPlate::<AutoSpawnBlindBox>b__16_0
02d333f0: ldr     s8, [x9, #0xeec]                           [1084eec]=457ff0003dcccccd f=0.1,4095
02d333f4: mov     w24, wzr                                   
02d333f8: ldr     x0, [x21]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d333fc: ldr     w20, [x8, #0x18]                           
02d33400: bl      #0x2b7104c                                 fn_2b7104c
02d33404: cmp     w24, w20                                   
02d33408: mov     x20, x0                                    
02d3340c: b.ge    #0x2d3344c                                 
02d33410: ldr     x2, [x22]                                  T:type56879(k15)
02d33414: mov     x0, x20                                    
02d33418: mov     x1, x19                                    
02d3341c: mov     x3, xzr                                    
02d33420: bl      #0x2d89dc4                                 DG.Tweening.TweenCallback::.ctor
02d33424: scvtf   s0, w24                                    
02d33428: mov     x0, x20                                    
02d3342c: mov     w1, #1                                     
02d33430: mov     x2, xzr                                    
02d33434: fmul    s0, s0, s8                                 
02d33438: bl      #0x2d8f37c                                 DG.Tweening.DOVirtual::DelayedCall
02d3343c: ldr     x8, [x19, #0x28]                           ._spawnedBlindBox
02d33440: add     w24, w24, #1                               
02d33444: cbnz    x8, #0x2d333f8                             
02d33448: bl      #0x2b7105c                                 fn_2b7105c
02d3344c: ldr     x2, [x23]                                  T:type56879(k15)
02d33450: mov     x0, x20                                    
02d33454: mov     x1, x19                                    
02d33458: mov     x3, xzr                                    
02d3345c: bl      #0x2d89dc4                                 DG.Tweening.TweenCallback::.ctor
02d33460: mov     x0, x20                                    
02d33464: ldp     x20, x19, [sp, #0x30]                      
02d33468: ldp     x22, x21, [sp, #0x20]                      
02d3346c: fmov    s0, #1.00000000                            
02d33470: ldp     x24, x23, [sp, #0x10]                      
02d33474: mov     w1, #1                                     
02d33478: ldr     x30, [sp, #8]                              
02d3347c: mov     x2, xzr                                    
02d33480: ldr     d8, [sp], #0x40                            
02d33484: b       #0x2d8f37c                                 DG.Tweening.DOVirtual::DelayedCall
## OnPointerDown(UnityEngine.EventSystems.PointerEventData eventData) -> void
---- BlindBagCollection.BlindBoxPlate::OnPointerDown 0x2d3874c
02d3874c: ret                                                
## CheckPopOutBlindBox() -> void
---- BlindBagCollection.BlindBoxPlate::CheckPopOutBlindBox 0x2d38750
02d38750: sub     sp, sp, #0x70                              
02d38754: stp     d9, d8, [sp, #0x10]                        
02d38758: stp     x30, x27, [sp, #0x20]                      
02d3875c: stp     x26, x25, [sp, #0x30]                      
02d38760: stp     x24, x23, [sp, #0x40]                      
02d38764: stp     x22, x21, [sp, #0x50]                      
02d38768: stp     x20, x19, [sp, #0x60]                      
02d3876c: adrp    x21, #0x6630000                            
02d38770: adrp    x20, #0x626a000                            
02d38774: mov     x19, x0                                    
02d38778: ldrb    w8, [x21, #0x138]                          
02d3877c: ldr     x20, [x20, #0xc10]                         T:BlindBagCollection.BlindBoxPlate/<>c__DisplayClass18_0
02d38780: tbnz    w8, #0, #0x2d38804                         
02d38784: adrp    x0, #0x6263000                             
02d38788: ldr     x0, [x0, #0x928]                           T:UnityEngine.Debug
02d3878c: bl      #0x2b70db0                                 fn_2b70db0
02d38790: adrp    x0, #0x626a000                             
02d38794: ldr     x0, [x0, #0xc18]                           MS:System.Collections.Generic.List`1::get_Item
02d38798: bl      #0x2b70db0                                 fn_2b70db0
02d3879c: adrp    x0, #0x6264000                             
02d387a0: ldr     x0, [x0, #0xe8]                            T:DG.Tweening.TweenCallback
02d387a4: bl      #0x2b70db0                                 fn_2b70db0
02d387a8: adrp    x0, #0x6266000                             
02d387ac: ldr     x0, [x0, #0xa88]                           MS:DG.Tweening.TweenSettingsExtensions::OnComplete
02d387b0: bl      #0x2b70db0                                 fn_2b70db0
02d387b4: adrp    x0, #0x6266000                             
02d387b8: ldr     x0, [x0, #0xa90]                           MS:DG.Tweening.TweenSettingsExtensions::SetDelay
02d387bc: bl      #0x2b70db0                                 fn_2b70db0
02d387c0: adrp    x0, #0x626a000                             
02d387c4: ldr     x0, [x0, #0xc20]                           M:BlindBagCollection.BlindBoxPlate/<>c__DisplayClass18_0::<CheckPopOutBlindBox>b__0
02d387c8: bl      #0x2b70db0                                 fn_2b70db0
02d387cc: adrp    x0, #0x626a000                             
02d387d0: ldr     x0, [x0, #0xc10]                           T:BlindBagCollection.BlindBoxPlate/<>c__DisplayClass18_0
02d387d4: bl      #0x2b70db0                                 fn_2b70db0
02d387d8: adrp    x0, #0x6267000                             
02d387dc: ldr     x0, [x0, #0xea8]                           T:Framework.Vibration
02d387e0: bl      #0x2b70db0                                 fn_2b70db0
02d387e4: adrp    x0, #0x626a000                             
02d387e8: ldr     x0, [x0, #0xc28]                           S:'curent box hold is {0}'
02d387ec: bl      #0x2b70db0                                 fn_2b70db0
02d387f0: adrp    x0, #0x626a000                             
02d387f4: ldr     x0, [x0, #0xc30]                           S:'CheckPopOutBlindBox '
02d387f8: bl      #0x2b70db0                                 fn_2b70db0
02d387fc: mov     w8, #1                                     
02d38800: strb    w8, [x21, #0x138]                          
02d38804: ldr     x0, [x20]                                  T:type56879(k15)
02d38808: str     wzr, [sp, #0xc]                            
02d3880c: bl      #0x2b7104c                                 fn_2b7104c
02d38810: mov     x1, xzr                                    
02d38814: mov     x20, x0                                    
02d38818: bl      #0x4e53e9c                                 System.Object::.ctor
02d3881c: cbz     x20, #0x2d38aec                            
02d38820: adrp    x21, #0x626a000                            
02d38824: adrp    x23, #0x6263000                            
02d38828: mov     x0, x20                                    
02d3882c: ldr     x21, [x21, #0xc30]                         S:'CheckPopOutBlindBox '
02d38830: ldr     x23, [x23, #0x928]                         T:UnityEngine.Debug
02d38834: mov     x1, x19                                    
02d38838: str     x19, [x0, #0x10]!                          
02d3883c: bl      #0x2b70d54                                 fn_2b70d54
02d38840: mov     x0, xzr                                    
02d38844: bl      #0x5b432fc                                 UnityEngine.Time::get_time
02d38848: add     x0, sp, #0xc                               
02d3884c: mov     x1, xzr                                    
02d38850: str     s0, [sp, #0xc]                             
02d38854: bl      #0x4e246d8                                 System.Single::ToString
02d38858: ldr     x8, [x21]                                  T:type56879(k15)
02d3885c: mov     x1, x0                                     
02d38860: mov     x2, xzr                                    
02d38864: mov     x0, x8                                     
02d38868: bl      #0x4c9c514                                 System.String::Concat
02d3886c: ldr     x8, [x23]                                  &2c5bbd4(=a9bd7bfdd503233f)
02d38870: mov     x21, x0                                    
02d38874: ldr     w9, [x8, #0xe4]                            
02d38878: cbnz    w9, #0x2d38884                             
02d3887c: mov     x0, x8                                     
02d38880: bl      #0x2b70f30                                 fn_2b70f30
02d38884: mov     x0, x21                                    
02d38888: mov     x1, xzr                                    
02d3888c: bl      #0x5af21f4                                 UnityEngine.Debug::Log
02d38890: ldr     w8, [x19, #0x78]                           ._currentBoxHold
02d38894: cmp     w8, #1                                     
02d38898: b.lt    #0x2d38acc                                 
02d3889c: mov     x0, xzr                                    
02d388a0: bl      #0x2d6eec8                                 Framework.AudioManager::get_Instance
02d388a4: cbz     x0, #0x2d38aec                             
02d388a8: movi    d1, #0000000000000000                      
02d388ac: movi    d2, #0000000000000000                      
02d388b0: adrp    x21, #0x6267000                            
02d388b4: fmov    s0, #1.00000000                            
02d388b8: ldr     x21, [x21, #0xea8]                         T:Framework.Vibration
02d388bc: mov     w1, #0x11                                  
02d388c0: mov     w2, wzr                                    
02d388c4: mov     w3, wzr                                    
02d388c8: mov     x4, xzr                                    
02d388cc: bl      #0x2d6f03c                                 Framework.AudioManager::PlaySound
02d388d0: ldr     x0, [x21]                                  S:'didu'
02d388d4: ldr     w8, [x0, #0xe4]                            [626a0e4]=0 f=0,0
02d388d8: cbnz    w8, #0x2d388e0                             
02d388dc: bl      #0x2b70f30                                 fn_2b70f30
02d388e0: mov     w0, #0x3c                                  
02d388e4: mov     w1, #-1                                    
02d388e8: mov     w2, wzr                                    
02d388ec: mov     x3, xzr                                    
02d388f0: bl      #0x2d6e144                                 Framework.Vibration::Vibrate
02d388f4: ldr     x0, [x19, #0x58]                           ._tfBottomLeftOpen
02d388f8: cbz     x0, #0x2d38aec                             
02d388fc: mov     x1, xzr                                    
02d38900: bl      #0x5b467ac                                 UnityEngine.Transform::get_position
02d38904: ldr     x0, [x19, #0x50]                           ._tfTopRightOpen
02d38908: cbz     x0, #0x2d38aec                             
02d3890c: mov     x1, xzr                                    
02d38910: fmov    s8, s0                                     
02d38914: bl      #0x5b467ac                                 UnityEngine.Transform::get_position
02d38918: fmov    s1, s0                                     
02d3891c: fmov    s0, s8                                     
02d38920: mov     x0, xzr                                    
02d38924: bl      #0x5b2dfc0                                 UnityEngine.Random::Range
02d38928: ldr     x0, [x19, #0x58]                           ._tfBottomLeftOpen
02d3892c: cbz     x0, #0x2d38aec                             
02d38930: mov     x1, xzr                                    
02d38934: fmov    s8, s0                                     
02d38938: bl      #0x5b467ac                                 UnityEngine.Transform::get_position
02d3893c: ldr     x0, [x19, #0x50]                           ._tfTopRightOpen
02d38940: cbz     x0, #0x2d38aec                             
02d38944: mov     x1, xzr                                    
02d38948: fmov    s9, s1                                     
02d3894c: bl      #0x5b467ac                                 UnityEngine.Transform::get_position
02d38950: fmov    s0, s9                                     
02d38954: mov     x0, xzr                                    
02d38958: bl      #0x5b2dfc0                                 UnityEngine.Random::Range
02d3895c: ldr     w8, [x19, #0x78]                           ._currentBoxHold
02d38960: ldr     x0, [x19, #0x28]                           ._spawnedBlindBox
02d38964: sub     w1, w8, #1                                 
02d38968: str     w1, [x20, #0x18]                           
02d3896c: cbz     x0, #0x2d38aec                             
02d38970: adrp    x22, #0x626a000                            
02d38974: fmov    s9, s0                                     
02d38978: ldr     x22, [x22, #0xc18]                         MS:System.Collections.Generic.List`1::get_Item
02d3897c: ldr     x2, [x22]                                  T:type56879(k15)
02d38980: bl      #0x35a8f3c                                 fn_35a8f3c
02d38984: cbz     x0, #0x2d38aec                             
02d38988: mov     x1, xzr                                    
02d3898c: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02d38990: ldr     x8, [x19, #0x28]                           ._spawnedBlindBox
02d38994: cbz     x8, #0x2d38aec                             
02d38998: ldr     w1, [x20, #0x18]                           MS:System.Collections.Generic.List`1::Add
02d3899c: ldr     x2, [x22]                                  T:type56879(k15)
02d389a0: mov     x21, x0                                    
02d389a4: mov     x0, x8                                     
02d389a8: bl      #0x35a8f3c                                 fn_35a8f3c
02d389ac: cbz     x0, #0x2d38aec                             
02d389b0: mov     x1, xzr                                    
02d389b4: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02d389b8: cbz     x0, #0x2d38aec                             
02d389bc: adrp    x22, #0x6266000                            
02d389c0: adrp    x25, #0x6264000                            
02d389c4: adrp    x26, #0x626a000                            
02d389c8: adrp    x27, #0x6266000                            
02d389cc: adrp    x24, #0x626a000                            
02d389d0: ldr     x22, [x22, #0xa90]                         MS:DG.Tweening.TweenSettingsExtensions::SetDelay
02d389d4: ldr     x25, [x25, #0xe8]                          T:DG.Tweening.TweenCallback
02d389d8: ldr     x26, [x26, #0xc20]                         M:BlindBagCollection.BlindBoxPlate/<>c__DisplayClass18_0::<CheckPopOutBlindBox>b__0
02d389dc: ldr     x27, [x27, #0xa88]                         MS:DG.Tweening.TweenSettingsExtensions::OnComplete
02d389e0: ldr     x24, [x24, #0xc28]                         S:'curent box hold is {0}'
02d389e4: mov     x1, xzr                                    
02d389e8: bl      #0x5b467ac                                 UnityEngine.Transform::get_position
02d389ec: fmov    s0, s8                                     
02d389f0: fmov    s1, s9                                     
02d389f4: mov     x0, x21                                    
02d389f8: fmov    s3, #3.00000000                            
02d389fc: fmov    s4, #0.50000000                            
02d38a00: mov     w1, #1                                     
02d38a04: mov     w2, wzr                                    
02d38a08: mov     x3, xzr                                    
02d38a0c: bl      #0x2d9abb0                                 DG.Tweening.ShortcutExtensions::DOJump
02d38a10: adrp    x8, #0x1084000                             
02d38a14: ldr     x1, [x22]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d38a18: ldr     s0, [x8, #0xda4]                           [1084da4]=3eb851ec3e19999a f=0.15,0.36
02d38a1c: bl      #0x336f7fc                                 fn_336f7fc
02d38a20: ldr     x8, [x25]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d38a24: mov     x21, x0                                    
02d38a28: mov     x0, x8                                     
02d38a2c: bl      #0x2b7104c                                 fn_2b7104c
02d38a30: ldr     x2, [x26]                                  T:type56879(k15)
02d38a34: mov     x1, x20                                    
02d38a38: mov     x3, xzr                                    
02d38a3c: mov     x22, x0                                    
02d38a40: bl      #0x2d89dc4                                 DG.Tweening.TweenCallback::.ctor
02d38a44: ldr     x2, [x27]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d38a48: mov     x0, x21                                    
02d38a4c: mov     x1, x22                                    
02d38a50: bl      #0x336f26c                                 fn_336f26c
02d38a54: adrp    x9, #0x6263000                             
02d38a58: ldr     w8, [x19, #0x78]                           ._currentBoxHold
02d38a5c: add     x1, sp, #8                                 
02d38a60: ldr     x9, [x9, #0x970]                           &6645c70(=0)
02d38a64: sub     w8, w8, #1                                 
02d38a68: ldr     x0, [x9, #0x48]                            &6263098(=0)
02d38a6c: str     w8, [x19, #0x78]                           ._currentBoxHold
02d38a70: str     w8, [sp, #8]                               
02d38a74: bl      #0x2b70f38                                 fn_2b70f38
02d38a78: ldr     x8, [x24]                                  T:type56879(k15)
02d38a7c: mov     x1, x0                                     
02d38a80: mov     x2, xzr                                    
02d38a84: mov     x0, x8                                     
02d38a88: bl      #0x4c9d0ec                                 System.String::Format
02d38a8c: ldr     x8, [x23]                                  &2c5bbd4(=a9bd7bfdd503233f)
02d38a90: mov     x20, x0                                    
02d38a94: ldr     w9, [x8, #0xe4]                            [10840e4]=2c2644327265746c f=4.54482e+30,2.36279e-12
02d38a98: cbnz    w9, #0x2d38aa4                             
02d38a9c: mov     x0, x8                                     
02d38aa0: bl      #0x2b70f30                                 fn_2b70f30
02d38aa4: mov     x0, x20                                    
02d38aa8: mov     x1, xzr                                    
02d38aac: bl      #0x5af21f4                                 UnityEngine.Debug::Log
02d38ab0: ldr     w8, [x19, #0x78]                           ._currentBoxHold
02d38ab4: cbnz    w8, #0x2d38acc                             
02d38ab8: ldr     x0, [x19, #0x70]                           ._collider
02d38abc: cbz     x0, #0x2d38aec                             
02d38ac0: mov     w1, wzr                                    
02d38ac4: mov     x2, xzr                                    
02d38ac8: bl      #0x5b33110                                 UnityEngine.Behaviour::set_enabled
02d38acc: ldp     x20, x19, [sp, #0x60]                      
02d38ad0: ldp     x22, x21, [sp, #0x50]                      
02d38ad4: ldp     x24, x23, [sp, #0x40]                      
02d38ad8: ldp     x26, x25, [sp, #0x30]                      
02d38adc: ldp     x30, x27, [sp, #0x20]                      
02d38ae0: ldp     d9, d8, [sp, #0x10]                        
02d38ae4: add     sp, sp, #0x70                              
02d38ae8: ret                                                
02d38aec: bl      #0x2b7105c                                 fn_2b7105c
## AddMoreRandomBox(UnityEngine.Sprite sprite, string skinName, bool isLuck, RarityType rarityType) -> void
---- BlindBagCollection.BlindBoxPlate::AddMoreRandomBox 0x2d33740
02d33740: sub     sp, sp, #0xb0                              
02d33744: stp     d15, d14, [sp, #0x20]                      
02d33748: stp     d13, d12, [sp, #0x30]                      
02d3374c: stp     d11, d10, [sp, #0x40]                      
02d33750: stp     d9, d8, [sp, #0x50]                        
02d33754: stp     x30, x27, [sp, #0x60]                      
02d33758: stp     x26, x25, [sp, #0x70]                      
02d3375c: stp     x24, x23, [sp, #0x80]                      
02d33760: stp     x22, x21, [sp, #0x90]                      
02d33764: stp     x20, x19, [sp, #0xa0]                      
02d33768: adrp    x20, #0x6630000                            
02d3376c: adrp    x25, #0x626a000                            
02d33770: mov     w22, w4                                    
02d33774: ldrb    w8, [x20, #0x139]                          
02d33778: ldr     x25, [x25, #0x898]                         T:BlindBagCollection.BlindBoxPlate/<>c__DisplayClass19_0
02d3377c: mov     w24, w3                                    
02d33780: mov     x21, x2                                    
02d33784: mov     x23, x1                                    
02d33788: mov     x19, x0                                    
02d3378c: tbnz    w8, #0, #0x2d3381c                         
02d33790: adrp    x0, #0x6263000                             
02d33794: ldr     x0, [x0, #0x928]                           T:UnityEngine.Debug
02d33798: bl      #0x2b70db0                                 fn_2b70db0
02d3379c: adrp    x0, #0x626a000                             
02d337a0: ldr     x0, [x0, #0x8a0]                           MS:System.Collections.Generic.List`1::Add
02d337a4: bl      #0x2b70db0                                 fn_2b70db0
02d337a8: adrp    x0, #0x626a000                             
02d337ac: ldr     x0, [x0, #0x878]                           MS:System.Collections.Generic.List`1::get_Count
02d337b0: bl      #0x2b70db0                                 fn_2b70db0
02d337b4: adrp    x0, #0x626a000                             
02d337b8: ldr     x0, [x0, #0x8a8]                           MS:UnityEngine.Object::Instantiate
02d337bc: bl      #0x2b70db0                                 fn_2b70db0
02d337c0: adrp    x0, #0x6263000                             
02d337c4: ldr     x0, [x0, #0x918]                           T:UnityEngine.Object
02d337c8: bl      #0x2b70db0                                 fn_2b70db0
02d337cc: adrp    x0, #0x6264000                             
02d337d0: ldr     x0, [x0, #0xe8]                            T:DG.Tweening.TweenCallback
02d337d4: bl      #0x2b70db0                                 fn_2b70db0
02d337d8: adrp    x0, #0x6266000                             
02d337dc: ldr     x0, [x0, #0xa88]                           MS:DG.Tweening.TweenSettingsExtensions::OnComplete
02d337e0: bl      #0x2b70db0                                 fn_2b70db0
02d337e4: adrp    x0, #0x6266000                             
02d337e8: ldr     x0, [x0, #0xa90]                           MS:DG.Tweening.TweenSettingsExtensions::SetDelay
02d337ec: bl      #0x2b70db0                                 fn_2b70db0
02d337f0: adrp    x0, #0x626a000                             
02d337f4: ldr     x0, [x0, #0x8b0]                           M:BlindBagCollection.BlindBoxPlate/<>c__DisplayClass19_0::<AddMoreRandomBox>b__0
02d337f8: bl      #0x2b70db0                                 fn_2b70db0
02d337fc: adrp    x0, #0x626a000                             
02d33800: ldr     x0, [x0, #0x898]                           T:BlindBagCollection.BlindBoxPlate/<>c__DisplayClass19_0
02d33804: bl      #0x2b70db0                                 fn_2b70db0
02d33808: adrp    x0, #0x626a000                             
02d3380c: ldr     x0, [x0, #0x8b8]                           S:'dev log _spawnedBlindBox count {0}'
02d33810: bl      #0x2b70db0                                 fn_2b70db0
02d33814: mov     w8, #1                                     
02d33818: strb    w8, [x20, #0x139]                          
02d3381c: ldr     x0, [x25]                                  T:type56879(k15)
02d33820: bl      #0x2b7104c                                 fn_2b7104c
02d33824: mov     x1, xzr                                    
02d33828: mov     x20, x0                                    
02d3382c: bl      #0x4e53e9c                                 System.Object::.ctor
02d33830: ldr     x0, [x19, #0x58]                           ._tfBottomLeftOpen
02d33834: cbz     x0, #0x2d33b60                             
02d33838: mov     x1, xzr                                    
02d3383c: bl      #0x5b467ac                                 UnityEngine.Transform::get_position
02d33840: ldr     x0, [x19, #0x50]                           ._tfTopRightOpen
02d33844: cbz     x0, #0x2d33b60                             
02d33848: mov     x1, xzr                                    
02d3384c: fmov    s8, s0                                     
02d33850: bl      #0x5b467ac                                 UnityEngine.Transform::get_position
02d33854: fmov    s1, s0                                     
02d33858: fmov    s0, s8                                     
02d3385c: mov     x0, xzr                                    
02d33860: bl      #0x5b2dfc0                                 UnityEngine.Random::Range
02d33864: ldr     x0, [x19, #0x58]                           ._tfBottomLeftOpen
02d33868: cbz     x0, #0x2d33b60                             
02d3386c: mov     x1, xzr                                    
02d33870: fmov    s9, s0                                     
02d33874: bl      #0x5b467ac                                 UnityEngine.Transform::get_position
02d33878: ldr     x0, [x19, #0x50]                           ._tfTopRightOpen
02d3387c: cbz     x0, #0x2d33b60                             
02d33880: mov     x1, xzr                                    
02d33884: fmov    s8, s1                                     
02d33888: str     s9, [sp, #0xc]                             
02d3388c: bl      #0x5b467ac                                 UnityEngine.Transform::get_position
02d33890: fmov    s0, s8                                     
02d33894: mov     x0, xzr                                    
02d33898: bl      #0x5b2dfc0                                 UnityEngine.Random::Range
02d3389c: ldr     x8, [x19, #0x28]                           ._spawnedBlindBox
02d338a0: cbz     x8, #0x2d33b60                             
02d338a4: fmov    s8, s0                                     
02d338a8: ldr     s9, [x8, #0x18]                            
02d338ac: movi    d0, #0000000000000000                      
02d338b0: mov     w8, #0x43b40000                            
02d338b4: mov     x0, xzr                                    
02d338b8: fmov    s1, w8                                     
02d338bc: bl      #0x5b2dfc0                                 UnityEngine.Random::Range
02d338c0: ldr     x25, [x19, #0x20]                          ._blindBoxItem
02d338c4: cbz     x25, #0x2d33b60                            
02d338c8: mov     x0, x25                                    
02d338cc: mov     x1, xzr                                    
02d338d0: fmov    s13, s0                                    
02d338d4: str     s8, [sp, #8]                               
02d338d8: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02d338dc: cbz     x0, #0x2d33b60                             
02d338e0: adrp    x26, #0x6263000                            
02d338e4: adrp    x27, #0x626a000                            
02d338e8: mov     x1, xzr                                    
02d338ec: ldr     x26, [x26, #0x918]                         T:UnityEngine.Object
02d338f0: ldr     x27, [x27, #0x8a8]                         MS:UnityEngine.Object::Instantiate
02d338f4: bl      #0x5b467ac                                 UnityEngine.Transform::get_position
02d338f8: adrp    x8, #0x1085000                             
02d338fc: fmov    s10, s0                                    
02d33900: add     x0, sp, #0x10                              
02d33904: ldr     s0, [x8, #0x10]                            [1085010]=4202c6f23c8efa35 f=0.0174533,32.6943
02d33908: mov     x1, xzr                                    
02d3390c: fmov    s11, s1                                    
02d33910: fmov    s12, s2                                    
02d33914: str     xzr, [sp, #0x10]                           
02d33918: fmul    s0, s13, s0                                
02d3391c: str     s0, [sp, #0x18]                            
02d33920: bl      #0x5b2607c                                 UnityEngine.Quaternion::Internal_FromEulerRad
02d33924: fmov    s13, s0                                    
02d33928: fmov    s14, s1                                    
02d3392c: ldr     x0, [x26]                                  &2c5bbd4(=a9bd7bfdd503233f)
02d33930: fmov    s15, s2                                    
02d33934: fmov    s8, s3                                     
02d33938: ldr     x26, [x19, #0x30]                          ._tfHolder
02d3393c: ldr     w8, [x0, #0xe4]                            [626a0e4]=0 f=0,0
02d33940: cbnz    w8, #0x2d33948                             
02d33944: bl      #0x2b70f30                                 fn_2b70f30
02d33948: fmov    s0, s10                                    
02d3394c: fmov    s1, s11                                    
02d33950: ldr     x2, [x27]                                  T:type56879(k15)
02d33954: fmov    s2, s12                                    
02d33958: fmov    s3, s13                                    
02d3395c: mov     x0, x25                                    
02d33960: fmov    s4, s14                                    
02d33964: fmov    s5, s15                                    
02d33968: mov     x1, x26                                    
02d3396c: fmov    s6, s8                                     
02d33970: bl      #0x3276204                                 fn_3276204
02d33974: cbz     x20, #0x2d33b60                            
02d33978: mov     x25, x20                                   
02d3397c: mov     x1, x0                                     
02d33980: str     x0, [x25, #0x10]!                          
02d33984: mov     x0, x25                                    
02d33988: bl      #0x2b70d54                                 fn_2b70d54
02d3398c: ldr     x0, [x25]                                  T:type56879(k15)
02d33990: cbz     x0, #0x2d33b60                             
02d33994: and     w2, w24, #1                                
02d33998: mov     x1, x23                                    
02d3399c: mov     w3, w22                                    
02d339a0: bl      #0x2d31594                                 BlindBagCollection.BlindbagCollectionBox::SetData
02d339a4: ldr     x0, [x25]                                  T:type56879(k15)
02d339a8: cbz     x0, #0x2d33b60                             
02d339ac: mov     x1, x21                                    
02d339b0: bl      #0x2d31500                                 BlindBagCollection.BlindbagCollectionBox::SetSkinBag
02d339b4: ldr     x0, [x25]                                  T:type56879(k15)
02d339b8: cbz     x0, #0x2d33b60                             
02d339bc: bl      #0x2d314e4                                 BlindBagCollection.BlindbagCollectionBox::DisableClick
02d339c0: ldr     x0, [x19, #0x28]                           ._spawnedBlindBox
02d339c4: cbz     x0, #0x2d33b60                             
02d339c8: adrp    x9, #0x626a000                             
02d339cc: ldr     x9, [x9, #0x8a0]                           MS:System.Collections.Generic.List`1::Add
02d339d0: ldr     w10, [x0, #0x1c]                           [626a01c]=0 f=0,0
02d339d4: ldr     x8, [x0, #0x10]                            T:Decor.DataDecor/CategoryData
02d339d8: ldr     x1, [x25]                                  T:type56879(k15)
02d339dc: ldr     x9, [x9]                                   T:type56879(k15)
02d339e0: add     w10, w10, #1                               
02d339e4: str     w10, [x0, #0x1c]                           
02d339e8: cbz     x8, #0x2d33b60                             
02d339ec: ldrsw   x10, [x0, #0x18]                           
02d339f0: ldr     w11, [x8, #0x18]                           [1085018]=47c34f803a83126f f=0.001,99999
02d339f4: cmp     w10, w11                                   
02d339f8: b.hs    #0x2d33a18                                 
02d339fc: add     x8, x8, x10, lsl #3                        &1085000
02d33a00: add     w9, w10, #1                                
02d33a04: str     w9, [x0, #0x18]                            
02d33a08: str     x1, [x8, #0x20]!                           
02d33a0c: mov     x0, x8                                     
02d33a10: bl      #0x2b70d54                                 fn_2b70d54
02d33a14: b       #0x2d33a28                                 
02d33a18: ldr     x8, [x9, #0x20]                            M:Decor.DataDecor/<>c__DisplayClass8_0::<NewData>b__0
02d33a1c: ldr     x8, [x8, #0xc0]                            [10850c0]=bf800000bf800000 f=-1,-1
02d33a20: ldr     x2, [x8, #0x70]                            [1085070]=3f32b2b33e008081 f=0.12549,0.698039
02d33a24: bl      #0x35a920c                                 fn_35a920c
02d33a28: ldr     x0, [x25]                                  T:type56879(k15)
02d33a2c: cbz     x0, #0x2d33b60                             
02d33a30: scvtf   s0, s9                                     
02d33a34: adrp    x8, #0x1084000                             
02d33a38: adrp    x21, #0x6266000                            
02d33a3c: ldr     s1, [x8, #0xeec]                           [1084eec]=457ff0003dcccccd f=0.1,4095
02d33a40: adrp    x22, #0x6264000                            
02d33a44: adrp    x23, #0x626a000                            
02d33a48: adrp    x24, #0x6266000                            
02d33a4c: ldr     x21, [x21, #0xa90]                         MS:DG.Tweening.TweenSettingsExtensions::SetDelay
02d33a50: ldr     x22, [x22, #0xe8]                          T:DG.Tweening.TweenCallback
02d33a54: ldr     x23, [x23, #0x8b0]                         M:BlindBagCollection.BlindBoxPlate/<>c__DisplayClass19_0::<AddMoreRandomBox>b__0
02d33a58: ldr     x24, [x24, #0xa88]                         MS:DG.Tweening.TweenSettingsExtensions::OnComplete
02d33a5c: mov     x1, xzr                                    
02d33a60: fmul    s8, s0, s1                                 
02d33a64: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02d33a68: fmov    s2, s8                                     
02d33a6c: fmov    s3, #3.00000000                            
02d33a70: mov     w1, #1                                     
02d33a74: fmov    s4, #1.00000000                            
02d33a78: ldp     s1, s0, [sp, #8]                           
02d33a7c: mov     w2, wzr                                    
02d33a80: mov     x3, xzr                                    
02d33a84: bl      #0x2d9abb0                                 DG.Tweening.ShortcutExtensions::DOJump
02d33a88: fmov    s0, #1.50000000                            
02d33a8c: ldr     x1, [x21]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d33a90: bl      #0x336f7fc                                 fn_336f7fc
02d33a94: ldr     x8, [x22]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d33a98: mov     x21, x0                                    
02d33a9c: mov     x0, x8                                     
02d33aa0: bl      #0x2b7104c                                 fn_2b7104c
02d33aa4: ldr     x2, [x23]                                  T:type56879(k15)
02d33aa8: mov     x1, x20                                    
02d33aac: mov     x3, xzr                                    
02d33ab0: mov     x22, x0                                    
02d33ab4: bl      #0x2d89dc4                                 DG.Tweening.TweenCallback::.ctor
02d33ab8: ldr     x2, [x24]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d33abc: mov     x0, x21                                    
02d33ac0: mov     x1, x22                                    
02d33ac4: bl      #0x336f26c                                 fn_336f26c
02d33ac8: ldr     x8, [x19, #0x28]                           ._spawnedBlindBox
02d33acc: cbz     x8, #0x2d33b60                             
02d33ad0: adrp    x9, #0x6263000                             
02d33ad4: adrp    x19, #0x626a000                            
02d33ad8: adrp    x20, #0x6263000                            
02d33adc: ldr     x9, [x9, #0x970]                           &6645c70(=0)
02d33ae0: ldr     x19, [x19, #0x8b8]                         S:'dev log _spawnedBlindBox count {0}'
02d33ae4: ldr     w8, [x8, #0x18]                            [1084018]=7974696c69745549 f=1.84613e+25,7.93162e+34
02d33ae8: ldr     x20, [x20, #0x928]                         T:UnityEngine.Debug
02d33aec: add     x1, sp, #0x10                              
02d33af0: ldr     x0, [x9, #0x48]                            &6263098(=0)
02d33af4: str     w8, [sp, #0x10]                            
02d33af8: bl      #0x2b70f38                                 fn_2b70f38
02d33afc: ldr     x8, [x19]                                  T:type56879(k15)
02d33b00: mov     x1, x0                                     
02d33b04: mov     x2, xzr                                    
02d33b08: mov     x0, x8                                     
02d33b0c: bl      #0x4c9d0ec                                 System.String::Format
02d33b10: ldr     x8, [x20]                                  &2c5bbd4(=a9bd7bfdd503233f)
02d33b14: mov     x19, x0                                    
02d33b18: ldr     w9, [x8, #0xe4]                            [10840e4]=2c2644327265746c f=4.54482e+30,2.36279e-12
02d33b1c: cbnz    w9, #0x2d33b28                             
02d33b20: mov     x0, x8                                     
02d33b24: bl      #0x2b70f30                                 fn_2b70f30
02d33b28: mov     x0, x19                                    
02d33b2c: mov     x1, xzr                                    
02d33b30: bl      #0x5af21f4                                 UnityEngine.Debug::Log
02d33b34: ldp     x20, x19, [sp, #0xa0]                      
02d33b38: ldp     x22, x21, [sp, #0x90]                      
02d33b3c: ldp     x24, x23, [sp, #0x80]                      
02d33b40: ldp     x26, x25, [sp, #0x70]                      
02d33b44: ldp     x30, x27, [sp, #0x60]                      
02d33b48: ldp     d9, d8, [sp, #0x50]                        
02d33b4c: ldp     d11, d10, [sp, #0x40]                      
02d33b50: ldp     d13, d12, [sp, #0x30]                      
02d33b54: ldp     d15, d14, [sp, #0x20]                      
02d33b58: add     sp, sp, #0xb0                              
02d33b5c: ret                                                
02d33b60: bl      #0x2b7105c                                 fn_2b7105c
## GetNewItem(UnityEngine.Transform item) -> void
---- BlindBagCollection.BlindBoxPlate::GetNewItem 0x2d3207c
02d3207c: stp     d9, d8, [sp, #-0x30]!                      
02d32080: str     x30, [sp, #0x10]                           
02d32084: stp     x20, x19, [sp, #0x20]                      
02d32088: mov     x20, x0                                    
02d3208c: ldr     x0, [x0, #0x68]                            ._tfBottomLeftPlate
02d32090: cbz     x0, #0x2d32144                             
02d32094: mov     x19, x1                                    
02d32098: mov     x1, xzr                                    
02d3209c: bl      #0x5b45c24                                 UnityEngine.Transform::get_localPosition
02d320a0: ldr     x0, [x20, #0x60]                           ._tfTopRightPlate
02d320a4: cbz     x0, #0x2d32144                             
02d320a8: mov     x1, xzr                                    
02d320ac: fmov    s8, s0                                     
02d320b0: bl      #0x5b45c24                                 UnityEngine.Transform::get_localPosition
02d320b4: fmov    s1, s0                                     
02d320b8: fmov    s0, s8                                     
02d320bc: mov     x0, xzr                                    
02d320c0: bl      #0x5b2dfc0                                 UnityEngine.Random::Range
02d320c4: ldr     x0, [x20, #0x68]                           ._tfBottomLeftPlate
02d320c8: cbz     x0, #0x2d32144                             
02d320cc: mov     x1, xzr                                    
02d320d0: fmov    s8, s0                                     
02d320d4: bl      #0x5b45c24                                 UnityEngine.Transform::get_localPosition
02d320d8: ldr     x0, [x20, #0x60]                           ._tfTopRightPlate
02d320dc: cbz     x0, #0x2d32144                             
02d320e0: mov     x1, xzr                                    
02d320e4: fmov    s9, s1                                     
02d320e8: bl      #0x5b45c24                                 UnityEngine.Transform::get_localPosition
02d320ec: fmov    s0, s9                                     
02d320f0: mov     x0, xzr                                    
02d320f4: bl      #0x5b2dfc0                                 UnityEngine.Random::Range
02d320f8: cbz     x19, #0x2d32144                            
02d320fc: ldr     x1, [x20, #0x38]                           ._tfPlateHoldResult
02d32100: mov     x0, x19                                    
02d32104: mov     x2, xzr                                    
02d32108: fmov    s9, s0                                     
02d3210c: bl      #0x5b472ec                                 UnityEngine.Transform::SetParent
02d32110: mov     x0, x19                                    
02d32114: ldp     x20, x19, [sp, #0x20]                      
02d32118: ldr     x30, [sp, #0x10]                           
02d3211c: movi    d2, #0000000000000000                      
02d32120: fmov    s3, #2.00000000                            
02d32124: fmov    s4, #0.50000000                            
02d32128: fmov    s0, s8                                     
02d3212c: fmov    s1, s9                                     
02d32130: mov     w1, #1                                     
02d32134: mov     w2, wzr                                    
02d32138: mov     x3, xzr                                    
02d3213c: ldp     d9, d8, [sp], #0x30                        
02d32140: b       #0x2d9b130                                 DG.Tweening.ShortcutExtensions::DOLocalJump
02d32144: bl      #0x2b7105c                                 fn_2b7105c
## .ctor() -> void
---- BlindBagCollection.BlindBoxPlate::.ctor 0x2d38b00
02d38b00: mov     x1, xzr                                    
02d38b04: b       #0x5b397b0                                 UnityEngine.MonoBehaviour::.ctor
## <AutoSpawnBlindBox>b__16_0() -> void
---- BlindBagCollection.BlindBoxPlate::<AutoSpawnBlindBox>b__16_0 0x2d38b08
02d38b08: stp     x30, x21, [sp, #-0x20]!                    
02d38b0c: stp     x20, x19, [sp, #0x10]                      
02d38b10: adrp    x20, #0x6630000                            
02d38b14: adrp    x21, #0x626a000                            
02d38b18: mov     x19, x0                                    
02d38b1c: ldrb    w8, [x20, #0x13a]                          
02d38b20: ldr     x21, [x21, #0x730]                         MS:MonoSingleton`1::get_Instance
02d38b24: tbnz    w8, #0, #0x2d38b48                         
02d38b28: adrp    x0, #0x626a000                             
02d38b2c: ldr     x0, [x0, #0xc18]                           MS:System.Collections.Generic.List`1::get_Item
02d38b30: bl      #0x2b70db0                                 fn_2b70db0
02d38b34: adrp    x0, #0x626a000                             
02d38b38: ldr     x0, [x0, #0x730]                           MS:MonoSingleton`1::get_Instance
02d38b3c: bl      #0x2b70db0                                 fn_2b70db0
02d38b40: mov     w8, #1                                     
02d38b44: strb    w8, [x20, #0x13a]                          
02d38b48: ldr     x0, [x21]                                  T:type56879(k15)
02d38b4c: bl      #0x3769600                                 fn_3769600
02d38b50: ldr     x8, [x19, #0x28]                           ._spawnedBlindBox
02d38b54: cbz     x8, #0x2d38ba0                             
02d38b58: adrp    x9, #0x626a000                             
02d38b5c: mov     x19, x0                                    
02d38b60: mov     x0, x8                                     
02d38b64: ldr     x9, [x9, #0xc18]                           MS:System.Collections.Generic.List`1::get_Item
02d38b68: mov     w1, wzr                                    
02d38b6c: ldr     x2, [x9]                                   T:type56879(k15)
02d38b70: bl      #0x35a8f3c                                 fn_35a8f3c
02d38b74: cbz     x0, #0x2d38ba0                             
02d38b78: mov     x1, xzr                                    
02d38b7c: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02d38b80: cbz     x19, #0x2d38ba0                            
02d38b84: mov     x1, x0                                     
02d38b88: mov     x0, x19                                    
02d38b8c: mov     w2, #1                                     
02d38b90: ldp     x20, x19, [sp, #0x10]                      
02d38b94: mov     x3, xzr                                    
02d38b98: ldp     x30, x21, [sp], #0x20                      
02d38b9c: b       #0x2d5699c                                 Blindbag.TutorialBlindBag::ShowTutorialUnbox
02d38ba0: bl      #0x2b7105c                                 fn_2b7105c
