#### CLASS Clicker.CreateMorePopup parent= PopupBase
#   field _btnCreateMore                 UnityEngine.UI.Button                              off=0x38 attr=1 SerializeField
#   field _btnNoThank                    UnityEngine.UI.Button                              off=0x40 attr=1 SerializeField
#   field _btnClose                      UnityEngine.UI.Button                              off=0x48 attr=1 SerializeField
#   field _tfPanel                       UnityEngine.Transform                              off=0x50 attr=1 SerializeField
## OnInit(UIManager uiManager) -> void
---- Clicker.CreateMorePopup::OnInit 0x2d68780
02d68780: stp     x30, x23, [sp, #-0x30]!                    
02d68784: stp     x22, x21, [sp, #0x10]                      
02d68788: stp     x20, x19, [sp, #0x20]                      
02d6878c: adrp    x21, #0x6630000                            
02d68790: mov     x20, x1                                    
02d68794: mov     x19, x0                                    
02d68798: ldrb    w8, [x21, #0x346]                          
02d6879c: tbnz    w8, #0, #0x2d687cc                         
02d687a0: adrp    x0, #0x626c000                             
02d687a4: ldr     x0, [x0, #0x2b0]                           M:Clicker.CreateMorePopup::OnBtnCreateMoreClick
02d687a8: bl      #0x2b70db0                                 fn_2b70db0
02d687ac: adrp    x0, #0x626c000                             
02d687b0: ldr     x0, [x0, #0x2b8]                           M:Clicker.CreateMorePopup::OnBtnNoThankClick
02d687b4: bl      #0x2b70db0                                 fn_2b70db0
02d687b8: adrp    x0, #0x6265000                             
02d687bc: ldr     x0, [x0, #0x3f0]                           T:UnityEngine.Events.UnityAction
02d687c0: bl      #0x2b70db0                                 fn_2b70db0
02d687c4: mov     w8, #1                                     
02d687c8: strb    w8, [x21, #0x346]                          
02d687cc: mov     x0, x19                                    
02d687d0: mov     x1, x20                                    
02d687d4: mov     x2, xzr                                    
02d687d8: bl      #0x2cdd3c4                                 UIBase::OnInit
02d687dc: ldr     x8, [x19, #0x38]                           ._btnCreateMore
02d687e0: cbz     x8, #0x2d688fc                             
02d687e4: ldr     x0, [x8, #0x100]                           
02d687e8: cbz     x0, #0x2d688fc                             
02d687ec: mov     x1, xzr                                    
02d687f0: bl      #0x5b4ce48                                 UnityEngine.Events.UnityEventBase::RemoveAllListeners
02d687f4: ldr     x8, [x19, #0x40]                           ._btnNoThank
02d687f8: cbz     x8, #0x2d688fc                             
02d687fc: ldr     x0, [x8, #0x100]                           
02d68800: cbz     x0, #0x2d688fc                             
02d68804: mov     x1, xzr                                    
02d68808: bl      #0x5b4ce48                                 UnityEngine.Events.UnityEventBase::RemoveAllListeners
02d6880c: ldr     x8, [x19, #0x48]                           ._btnClose
02d68810: cbz     x8, #0x2d688fc                             
02d68814: ldr     x0, [x8, #0x100]                           
02d68818: cbz     x0, #0x2d688fc                             
02d6881c: mov     x1, xzr                                    
02d68820: bl      #0x5b4ce48                                 UnityEngine.Events.UnityEventBase::RemoveAllListeners
02d68824: ldr     x8, [x19, #0x38]                           ._btnCreateMore
02d68828: cbz     x8, #0x2d688fc                             
02d6882c: adrp    x22, #0x6265000                            
02d68830: adrp    x21, #0x626c000                            
02d68834: ldr     x22, [x22, #0x3f0]                         T:UnityEngine.Events.UnityAction
02d68838: ldr     x21, [x21, #0x2b0]                         M:Clicker.CreateMorePopup::OnBtnCreateMoreClick
02d6883c: ldr     x20, [x8, #0x100]                          
02d68840: ldr     x0, [x22]                                  M:AdsManager::<OnApplicationPause>b__26_0
02d68844: bl      #0x2b7104c                                 fn_2b7104c
02d68848: ldr     x2, [x21]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d6884c: mov     x1, x19                                    
02d68850: mov     x3, xzr                                    
02d68854: mov     x21, x0                                    
02d68858: bl      #0x5b4cf98                                 UnityEngine.Events.UnityAction::.ctor
02d6885c: cbz     x20, #0x2d688fc                            
02d68860: mov     x0, x20                                    
02d68864: mov     x1, x21                                    
02d68868: mov     x2, xzr                                    
02d6886c: bl      #0x5b4d0ac                                 UnityEngine.Events.UnityEvent::AddListener
02d68870: ldr     x8, [x19, #0x40]                           ._btnNoThank
02d68874: cbz     x8, #0x2d688fc                             
02d68878: adrp    x23, #0x626c000                            
02d6887c: ldr     x23, [x23, #0x2b8]                         M:Clicker.CreateMorePopup::OnBtnNoThankClick
02d68880: ldr     x0, [x22]                                  M:AdsManager::<OnApplicationPause>b__26_0
02d68884: ldr     x20, [x8, #0x100]                          
02d68888: bl      #0x2b7104c                                 fn_2b7104c
02d6888c: ldr     x2, [x23]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d68890: mov     x1, x19                                    
02d68894: mov     x3, xzr                                    
02d68898: mov     x21, x0                                    
02d6889c: bl      #0x5b4cf98                                 UnityEngine.Events.UnityAction::.ctor
02d688a0: cbz     x20, #0x2d688fc                            
02d688a4: mov     x0, x20                                    
02d688a8: mov     x1, x21                                    
02d688ac: mov     x2, xzr                                    
02d688b0: bl      #0x5b4d0ac                                 UnityEngine.Events.UnityEvent::AddListener
02d688b4: ldr     x8, [x19, #0x48]                           ._btnClose
02d688b8: cbz     x8, #0x2d688fc                             
02d688bc: ldr     x0, [x22]                                  M:AdsManager::<OnApplicationPause>b__26_0
02d688c0: ldr     x20, [x8, #0x100]                          
02d688c4: bl      #0x2b7104c                                 fn_2b7104c
02d688c8: ldr     x2, [x23]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d688cc: mov     x1, x19                                    
02d688d0: mov     x3, xzr                                    
02d688d4: mov     x21, x0                                    
02d688d8: bl      #0x5b4cf98                                 UnityEngine.Events.UnityAction::.ctor
02d688dc: cbz     x20, #0x2d688fc                            
02d688e0: mov     x0, x20                                    
02d688e4: mov     x1, x21                                    
02d688e8: mov     x2, xzr                                    
02d688ec: ldp     x20, x19, [sp, #0x20]                      
02d688f0: ldp     x22, x21, [sp, #0x10]                      
02d688f4: ldp     x30, x23, [sp], #0x30                      
02d688f8: b       #0x5b4d0ac                                 UnityEngine.Events.UnityEvent::AddListener
02d688fc: bl      #0x2b7105c                                 fn_2b7105c
## OnShow() -> void
---- Clicker.CreateMorePopup::OnShow 0x2d68900
02d68900: str     x30, [sp, #-0x40]!                         
02d68904: stp     x24, x23, [sp, #0x10]                      
02d68908: stp     x22, x21, [sp, #0x20]                      
02d6890c: stp     x20, x19, [sp, #0x30]                      
02d68910: adrp    x21, #0x6630000                            
02d68914: adrp    x20, #0x6265000                            
02d68918: mov     x19, x0                                    
02d6891c: ldrb    w8, [x21, #0x347]                          
02d68920: ldr     x20, [x20, #0x310]                         MS:WejoyService.Singleton`1::get_Instance
02d68924: tbnz    w8, #0, #0x2d6896c                         
02d68928: adrp    x0, #0x626c000                             
02d6892c: ldr     x0, [x0, #0x2c0]                           M:Clicker.CreateMorePopup::<OnShow>b__5_0
02d68930: bl      #0x2b70db0                                 fn_2b70db0
02d68934: adrp    x0, #0x6265000                             
02d68938: ldr     x0, [x0, #0x310]                           MS:WejoyService.Singleton`1::get_Instance
02d6893c: bl      #0x2b70db0                                 fn_2b70db0
02d68940: adrp    x0, #0x6264000                             
02d68944: ldr     x0, [x0, #0xe8]                            T:DG.Tweening.TweenCallback
02d68948: bl      #0x2b70db0                                 fn_2b70db0
02d6894c: adrp    x0, #0x6266000                             
02d68950: ldr     x0, [x0, #0x928]                           MS:DG.Tweening.TweenSettingsExtensions::OnComplete
02d68954: bl      #0x2b70db0                                 fn_2b70db0
02d68958: adrp    x0, #0x6266000                             
02d6895c: ldr     x0, [x0, #0x880]                           MS:DG.Tweening.TweenSettingsExtensions::SetEase
02d68960: bl      #0x2b70db0                                 fn_2b70db0
02d68964: mov     w8, #1                                     
02d68968: strb    w8, [x21, #0x347]                          
02d6896c: mov     x0, x19                                    
02d68970: mov     x1, xzr                                    
02d68974: bl      #0x2cdd6b8                                 UIBase::OnShow
02d68978: ldr     x0, [x20]                                  M:AdsManager::<OnApplicationPause>b__26_0
02d6897c: bl      #0x3be7218                                 fn_3be7218
02d68980: cbz     x0, #0x2d68ab0                             
02d68984: mov     w1, #4                                     
02d68988: mov     x2, xzr                                    
02d6898c: bl      #0x2c8a650                                 AdsManager::ShowMREC
02d68990: ldr     x0, [x19, #0x38]                           ._btnCreateMore
02d68994: cbz     x0, #0x2d68ab0                             
02d68998: mov     w1, wzr                                    
02d6899c: mov     x2, xzr                                    
02d689a0: bl      #0x5e662d4                                 UnityEngine.UI.Selectable::set_interactable
02d689a4: ldr     x0, [x19, #0x40]                           ._btnNoThank
02d689a8: cbz     x0, #0x2d68ab0                             
02d689ac: mov     w1, wzr                                    
02d689b0: mov     x2, xzr                                    
02d689b4: bl      #0x5e662d4                                 UnityEngine.UI.Selectable::set_interactable
02d689b8: ldr     x0, [x19, #0x48]                           ._btnClose
02d689bc: cbz     x0, #0x2d68ab0                             
02d689c0: mov     w1, wzr                                    
02d689c4: mov     x2, xzr                                    
02d689c8: bl      #0x5e662d4                                 UnityEngine.UI.Selectable::set_interactable
02d689cc: ldr     x0, [x19, #0x50]                           ._tfPanel
02d689d0: mov     w1, wzr                                    
02d689d4: mov     x2, xzr                                    
02d689d8: bl      #0x2d9d5d0                                 DG.Tweening.ShortcutExtensions::DOKill
02d689dc: adrp    x21, #0x662f000                            
02d689e0: ldr     x20, [x19, #0x50]                          ._tfPanel
02d689e4: ldrb    w8, [x21, #0x91a]                          
02d689e8: cbnz    w8, #0x2d68a00                             
02d689ec: adrp    x0, #0x6264000                             
02d689f0: ldr     x0, [x0, #0xd8]                            T:UnityEngine.Vector3
02d689f4: bl      #0x2b70db0                                 fn_2b70db0
02d689f8: mov     w8, #1                                     
02d689fc: strb    w8, [x21, #0x91a]                          
02d68a00: cbz     x20, #0x2d68ab0                            
02d68a04: adrp    x8, #0x6264000                             
02d68a08: adrp    x21, #0x6266000                            
02d68a0c: adrp    x22, #0x6264000                            
02d68a10: ldr     x8, [x8, #0xd8]                            T:UnityEngine.Vector3
02d68a14: ldr     x21, [x21, #0x880]                         MS:DG.Tweening.TweenSettingsExtensions::SetEase
02d68a18: adrp    x23, #0x626c000                            
02d68a1c: adrp    x24, #0x6266000                            
02d68a20: mov     x0, x20                                    
02d68a24: mov     x1, xzr                                    
02d68a28: ldr     x8, [x8]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d68a2c: ldr     x22, [x22, #0xe8]                          T:DG.Tweening.TweenCallback
02d68a30: ldr     x23, [x23, #0x2c0]                         M:Clicker.CreateMorePopup::<OnShow>b__5_0
02d68a34: ldr     x8, [x8, #0xb8]                            MS:DG.Tweening.Core.Extensions::SetSpecialStartupMode
02d68a38: ldr     x24, [x24, #0x928]                         MS:DG.Tweening.TweenSettingsExtensions::OnComplete
02d68a3c: ldp     s1, s2, [x8, #4]                           
02d68a40: ldr     s0, [x8]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d68a44: bl      #0x5b470cc                                 UnityEngine.Transform::set_localScale
02d68a48: adrp    x8, #0x1084000                             
02d68a4c: fmov    s0, #1.00000000                            
02d68a50: ldr     x0, [x19, #0x50]                           ._tfPanel
02d68a54: ldr     s1, [x8, #0xf10]                           [1084f10]=4110bc863e99999a f=0.3,9.04603
02d68a58: mov     x1, xzr                                    
02d68a5c: bl      #0x2d98c98                                 DG.Tweening.ShortcutExtensions::DOScale
02d68a60: ldr     x2, [x21]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d68a64: mov     w1, #0x1b                                  
02d68a68: bl      #0x336fa0c                                 fn_336fa0c
02d68a6c: ldr     x8, [x22]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d68a70: mov     x20, x0                                    
02d68a74: mov     x0, x8                                     
02d68a78: bl      #0x2b7104c                                 fn_2b7104c
02d68a7c: ldr     x2, [x23]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d68a80: mov     x1, x19                                    
02d68a84: mov     x3, xzr                                    
02d68a88: mov     x21, x0                                    
02d68a8c: bl      #0x2d89dc4                                 DG.Tweening.TweenCallback::.ctor
02d68a90: ldr     x2, [x24]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d68a94: mov     x0, x20                                    
02d68a98: mov     x1, x21                                    
02d68a9c: ldp     x20, x19, [sp, #0x30]                      
02d68aa0: ldp     x22, x21, [sp, #0x20]                      
02d68aa4: ldp     x24, x23, [sp, #0x10]                      
02d68aa8: ldr     x30, [sp], #0x40                           
02d68aac: b       #0x336f26c                                 
02d68ab0: bl      #0x2b7105c                                 fn_2b7105c
## OnBtnCreateMoreClick() -> void
---- Clicker.CreateMorePopup::OnBtnCreateMoreClick 0x2d68ab4
02d68ab4: str     x30, [sp, #-0x30]!                         
02d68ab8: stp     x22, x21, [sp, #0x10]                      
02d68abc: stp     x20, x19, [sp, #0x20]                      
02d68ac0: adrp    x20, #0x6630000                            
02d68ac4: mov     x19, x0                                    
02d68ac8: ldrb    w8, [x20, #0x348]                          
02d68acc: tbnz    w8, #0, #0x2d68b08                         
02d68ad0: adrp    x0, #0x6264000                             
02d68ad4: ldr     x0, [x0, #0xf90]                           T:System.Action
02d68ad8: bl      #0x2b70db0                                 fn_2b70db0
02d68adc: adrp    x0, #0x626c000                             
02d68ae0: ldr     x0, [x0, #0x2c8]                           M:Clicker.CreateMorePopup::<OnBtnCreateMoreClick>b__6_0
02d68ae4: bl      #0x2b70db0                                 fn_2b70db0
02d68ae8: adrp    x0, #0x6265000                             
02d68aec: ldr     x0, [x0, #0x310]                           MS:WejoyService.Singleton`1::get_Instance
02d68af0: bl      #0x2b70db0                                 fn_2b70db0
02d68af4: adrp    x0, #0x626c000                             
02d68af8: ldr     x0, [x0, #0x2d0]                           S:'create_more'
02d68afc: bl      #0x2b70db0                                 fn_2b70db0
02d68b00: mov     w8, #1                                     
02d68b04: strb    w8, [x20, #0x348]                          
02d68b08: mov     x0, xzr                                    
02d68b0c: bl      #0x2d6eec8                                 Framework.AudioManager::get_Instance
02d68b10: cbz     x0, #0x2d68ba8                             
02d68b14: movi    d1, #0000000000000000                      
02d68b18: movi    d2, #0000000000000000                      
02d68b1c: adrp    x20, #0x6265000                            
02d68b20: fmov    s0, #1.00000000                            
02d68b24: adrp    x21, #0x6264000                            
02d68b28: adrp    x22, #0x626c000                            
02d68b2c: ldr     x20, [x20, #0x310]                         MS:WejoyService.Singleton`1::get_Instance
02d68b30: ldr     x21, [x21, #0xf90]                         T:System.Action
02d68b34: ldr     x22, [x22, #0x2c8]                         M:Clicker.CreateMorePopup::<OnBtnCreateMoreClick>b__6_0
02d68b38: mov     w1, #1                                     
02d68b3c: mov     w2, wzr                                    
02d68b40: mov     w3, wzr                                    
02d68b44: mov     x4, xzr                                    
02d68b48: bl      #0x2d6f03c                                 Framework.AudioManager::PlaySound
02d68b4c: ldr     x0, [x20]                                  M:AdsManager::<OnApplicationPause>b__26_0
02d68b50: bl      #0x3be7218                                 fn_3be7218
02d68b54: ldr     x8, [x21]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d68b58: mov     x20, x0                                    
02d68b5c: mov     x0, x8                                     
02d68b60: bl      #0x2b7104c                                 fn_2b7104c
02d68b64: ldr     x2, [x22]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d68b68: mov     x1, x19                                    
02d68b6c: mov     x3, xzr                                    
02d68b70: mov     x21, x0                                    
02d68b74: bl      #0x4d8ddbc                                 System.Action::.ctor
02d68b78: cbz     x20, #0x2d68ba8                            
02d68b7c: adrp    x8, #0x626c000                             
02d68b80: mov     x0, x20                                    
02d68b84: mov     x2, x21                                    
02d68b88: ldr     x8, [x8, #0x2d0]                           S:'create_more'
02d68b8c: ldp     x20, x19, [sp, #0x20]                      
02d68b90: ldp     x22, x21, [sp, #0x10]                      
02d68b94: mov     w3, #1                                     
02d68b98: ldr     x1, [x8]                                   M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d68b9c: mov     x4, xzr                                    
02d68ba0: ldr     x30, [sp], #0x30                           
02d68ba4: b       #0x2c89698                                 AdsManager::ShowInter
02d68ba8: bl      #0x2b7105c                                 fn_2b7105c
## OnHide() -> void
---- Clicker.CreateMorePopup::OnHide 0x2d68bac
02d68bac: stp     x30, x21, [sp, #-0x20]!                    
02d68bb0: stp     x20, x19, [sp, #0x10]                      
02d68bb4: adrp    x21, #0x6630000                            
02d68bb8: adrp    x20, #0x6265000                            
02d68bbc: mov     x19, x0                                    
02d68bc0: ldrb    w8, [x21, #0x349]                          
02d68bc4: ldr     x20, [x20, #0x310]                         MS:WejoyService.Singleton`1::get_Instance
02d68bc8: tbnz    w8, #0, #0x2d68be0                         
02d68bcc: adrp    x0, #0x6265000                             
02d68bd0: ldr     x0, [x0, #0x310]                           MS:WejoyService.Singleton`1::get_Instance
02d68bd4: bl      #0x2b70db0                                 fn_2b70db0
02d68bd8: mov     w8, #1                                     
02d68bdc: strb    w8, [x21, #0x349]                          
02d68be0: mov     x0, x19                                    
02d68be4: mov     x1, xzr                                    
02d68be8: bl      #0x2cddc10                                 UIBase::OnHide
02d68bec: ldr     x0, [x20]                                  M:AdsManager::<OnApplicationPause>b__26_0
02d68bf0: bl      #0x3be7218                                 fn_3be7218
02d68bf4: cbz     x0, #0x2d68c08                             
02d68bf8: ldp     x20, x19, [sp, #0x10]                      
02d68bfc: mov     x1, xzr                                    
02d68c00: ldp     x30, x21, [sp], #0x20                      
02d68c04: b       #0x2c88cec                                 AdsManager::HideMREC
02d68c08: bl      #0x2b7105c                                 fn_2b7105c
## OnBtnNoThankClick() -> void
---- Clicker.CreateMorePopup::OnBtnNoThankClick 0x2d68c0c
02d68c0c: str     x30, [sp, #-0x30]!                         
02d68c10: stp     x22, x21, [sp, #0x10]                      
02d68c14: stp     x20, x19, [sp, #0x20]                      
02d68c18: adrp    x20, #0x6630000                            
02d68c1c: mov     x19, x0                                    
02d68c20: ldrb    w8, [x20, #0x34a]                          
02d68c24: tbnz    w8, #0, #0x2d68c60                         
02d68c28: adrp    x0, #0x6264000                             
02d68c2c: ldr     x0, [x0, #0xf90]                           T:System.Action
02d68c30: bl      #0x2b70db0                                 fn_2b70db0
02d68c34: adrp    x0, #0x626c000                             
02d68c38: ldr     x0, [x0, #0x2d8]                           M:Clicker.CreateMorePopup::<OnBtnNoThankClick>b__8_0
02d68c3c: bl      #0x2b70db0                                 fn_2b70db0
02d68c40: adrp    x0, #0x6265000                             
02d68c44: ldr     x0, [x0, #0x310]                           MS:WejoyService.Singleton`1::get_Instance
02d68c48: bl      #0x2b70db0                                 fn_2b70db0
02d68c4c: adrp    x0, #0x626c000                             
02d68c50: ldr     x0, [x0, #0x2e0]                           S:'create_more_no_thank'
02d68c54: bl      #0x2b70db0                                 fn_2b70db0
02d68c58: mov     w8, #1                                     
02d68c5c: strb    w8, [x20, #0x34a]                          
02d68c60: mov     x0, xzr                                    
02d68c64: bl      #0x2d6eec8                                 Framework.AudioManager::get_Instance
02d68c68: cbz     x0, #0x2d68d00                             
02d68c6c: movi    d1, #0000000000000000                      
02d68c70: movi    d2, #0000000000000000                      
02d68c74: adrp    x20, #0x6265000                            
02d68c78: fmov    s0, #1.00000000                            
02d68c7c: adrp    x21, #0x6264000                            
02d68c80: adrp    x22, #0x626c000                            
02d68c84: ldr     x20, [x20, #0x310]                         MS:WejoyService.Singleton`1::get_Instance
02d68c88: ldr     x21, [x21, #0xf90]                         T:System.Action
02d68c8c: ldr     x22, [x22, #0x2d8]                         M:Clicker.CreateMorePopup::<OnBtnNoThankClick>b__8_0
02d68c90: mov     w1, #1                                     
02d68c94: mov     w2, wzr                                    
02d68c98: mov     w3, wzr                                    
02d68c9c: mov     x4, xzr                                    
02d68ca0: bl      #0x2d6f03c                                 Framework.AudioManager::PlaySound
02d68ca4: ldr     x0, [x20]                                  M:AdsManager::<OnApplicationPause>b__26_0
02d68ca8: bl      #0x3be7218                                 fn_3be7218
02d68cac: ldr     x8, [x21]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d68cb0: mov     x20, x0                                    
02d68cb4: mov     x0, x8                                     
02d68cb8: bl      #0x2b7104c                                 fn_2b7104c
02d68cbc: ldr     x2, [x22]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d68cc0: mov     x1, x19                                    
02d68cc4: mov     x3, xzr                                    
02d68cc8: mov     x21, x0                                    
02d68ccc: bl      #0x4d8ddbc                                 System.Action::.ctor
02d68cd0: cbz     x20, #0x2d68d00                            
02d68cd4: adrp    x8, #0x626c000                             
02d68cd8: mov     x0, x20                                    
02d68cdc: mov     x2, x21                                    
02d68ce0: ldr     x8, [x8, #0x2e0]                           S:'create_more_no_thank'
02d68ce4: ldp     x20, x19, [sp, #0x20]                      
02d68ce8: ldp     x22, x21, [sp, #0x10]                      
02d68cec: mov     w3, #1                                     
02d68cf0: ldr     x1, [x8]                                   M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d68cf4: mov     x4, xzr                                    
02d68cf8: ldr     x30, [sp], #0x30                           
02d68cfc: b       #0x2c89698                                 AdsManager::ShowInter
02d68d00: bl      #0x2b7105c                                 fn_2b7105c
## .ctor() -> void
---- Clicker.CreateMorePopup::.ctor 0x2d68d04
02d68d04: mov     x1, xzr                                    
02d68d08: b       #0x2cddba8                                 PopupBase::.ctor
## <OnShow>b__5_0() -> void
---- Clicker.CreateMorePopup::<OnShow>b__5_0 0x2d68d0c
02d68d0c: stp     x30, x19, [sp, #-0x10]!                    
02d68d10: mov     x19, x0                                    
02d68d14: ldr     x0, [x0, #0x38]                            ._btnCreateMore
02d68d18: cbz     x0, #0x2d68d54                             
02d68d1c: mov     w1, #1                                     
02d68d20: mov     x2, xzr                                    
02d68d24: bl      #0x5e662d4                                 UnityEngine.UI.Selectable::set_interactable
02d68d28: ldr     x0, [x19, #0x40]                           ._btnNoThank
02d68d2c: cbz     x0, #0x2d68d54                             
02d68d30: mov     w1, #1                                     
02d68d34: mov     x2, xzr                                    
02d68d38: bl      #0x5e662d4                                 UnityEngine.UI.Selectable::set_interactable
02d68d3c: ldr     x0, [x19, #0x48]                           ._btnClose
02d68d40: cbz     x0, #0x2d68d54                             
02d68d44: mov     w1, #1                                     
02d68d48: mov     x2, xzr                                    
02d68d4c: ldp     x30, x19, [sp], #0x10                      
02d68d50: b       #0x5e662d4                                 UnityEngine.UI.Selectable::set_interactable
02d68d54: bl      #0x2b7105c                                 fn_2b7105c
## <OnBtnCreateMoreClick>b__6_0() -> void
---- Clicker.CreateMorePopup::<OnBtnCreateMoreClick>b__6_0 0x2d68d58
02d68d58: str     x30, [sp, #-0x30]!                         
02d68d5c: stp     x22, x21, [sp, #0x10]                      
02d68d60: stp     x20, x19, [sp, #0x20]                      
02d68d64: adrp    x20, #0x6630000                            
02d68d68: mov     x19, x0                                    
02d68d6c: ldrb    w8, [x20, #0x34b]                          
02d68d70: tbnz    w8, #0, #0x2d68dc4                         
02d68d74: adrp    x0, #0x6266000                             
02d68d78: ldr     x0, [x0, #0x750]                           MS:DataManager::GetData
02d68d7c: bl      #0x2b70db0                                 fn_2b70db0
02d68d80: adrp    x0, #0x6265000                             
02d68d84: ldr     x0, [x0, #0xb38]                           T:DevTrack
02d68d88: bl      #0x2b70db0                                 fn_2b70db0
02d68d8c: adrp    x0, #0x6266000                             
02d68d90: ldr     x0, [x0, #0x5e0]                           T:GameConfig
02d68d94: bl      #0x2b70db0                                 fn_2b70db0
02d68d98: adrp    x0, #0x6265000                             
02d68d9c: ldr     x0, [x0, #0x10]                            MS:MonoSingleton`1::get_Instance
02d68da0: bl      #0x2b70db0                                 fn_2b70db0
02d68da4: adrp    x0, #0x6266000                             
02d68da8: ldr     x0, [x0, #0x658]                           MS:MonoSingleton`1::get_Instance
02d68dac: bl      #0x2b70db0                                 fn_2b70db0
02d68db0: adrp    x0, #0x6266000                             
02d68db4: ldr     x0, [x0, #0xb48]                           MS:MonoSingleton`1::get_Instance
02d68db8: bl      #0x2b70db0                                 fn_2b70db0
02d68dbc: mov     w8, #1                                     
02d68dc0: strb    w8, [x20, #0x34b]                          
02d68dc4: ldr     x0, [x19, #0x38]                           ._btnCreateMore
02d68dc8: cbz     x0, #0x2d68f9c                             
02d68dcc: mov     w1, wzr                                    
02d68dd0: mov     x2, xzr                                    
02d68dd4: bl      #0x5e662d4                                 UnityEngine.UI.Selectable::set_interactable
02d68dd8: ldr     x0, [x19, #0x40]                           ._btnNoThank
02d68ddc: cbz     x0, #0x2d68f9c                             
02d68de0: mov     w1, wzr                                    
02d68de4: mov     x2, xzr                                    
02d68de8: bl      #0x5e662d4                                 UnityEngine.UI.Selectable::set_interactable
02d68dec: ldr     x0, [x19, #0x48]                           ._btnClose
02d68df0: cbz     x0, #0x2d68f9c                             
02d68df4: adrp    x19, #0x6265000                            
02d68df8: adrp    x20, #0x6266000                            
02d68dfc: mov     w1, wzr                                    
02d68e00: ldr     x19, [x19, #0x10]                          MS:MonoSingleton`1::get_Instance
02d68e04: ldr     x20, [x20, #0x5e0]                         T:GameConfig
02d68e08: mov     x2, xzr                                    
02d68e0c: bl      #0x5e662d4                                 UnityEngine.UI.Selectable::set_interactable
02d68e10: ldr     x0, [x19]                                  M:AdsManager::<OnApplicationPause>b__26_0
02d68e14: bl      #0x3769600                                 fn_3769600
02d68e18: ldr     x8, [x20]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d68e1c: mov     x19, x0                                    
02d68e20: ldr     w9, [x8, #0xe4]                            
02d68e24: cbnz    w9, #0x2d68e30                             
02d68e28: mov     x0, x8                                     
02d68e2c: bl      #0x2b70f30                                 fn_2b70f30
02d68e30: cbz     x19, #0x2d68f9c                            
02d68e34: ldr     x8, [x20]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d68e38: adrp    x20, #0x6266000                            
02d68e3c: mov     x0, x19                                    
02d68e40: mov     w2, wzr                                    
02d68e44: mov     x3, xzr                                    
02d68e48: ldr     x8, [x8, #0xb8]                            
02d68e4c: ldr     x20, [x20, #0x658]                         MS:MonoSingleton`1::get_Instance
02d68e50: ldr     x1, [x8, #0x28]                            
02d68e54: bl      #0x2ce9e58                                 SimpleSceneTransition::FlashIn
02d68e58: ldr     x0, [x20]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d68e5c: bl      #0x3769600                                 fn_3769600
02d68e60: cbz     x0, #0x2d68f9c                             
02d68e64: adrp    x8, #0x6266000                             
02d68e68: adrp    x22, #0x6266000                            
02d68e6c: adrp    x21, #0x6265000                            
02d68e70: ldr     x8, [x8, #0x750]                           MS:DataManager::GetData
02d68e74: ldr     x22, [x22, #0xb48]                         MS:MonoSingleton`1::get_Instance
02d68e78: ldr     x21, [x21, #0xb38]                         T:DevTrack
02d68e7c: ldr     x1, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d68e80: bl      #0x3168dd0                                 fn_3168dd0
02d68e84: ldr     x8, [x22]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d68e88: mov     x19, x0                                    
02d68e8c: mov     x0, x8                                     
02d68e90: bl      #0x3769600                                 fn_3769600
02d68e94: ldr     x8, [x21]                                  M:AdsManager::<OnApplicationPause>b__26_0
02d68e98: mov     x20, x0                                    
02d68e9c: ldr     w9, [x8, #0xe4]                            [62660e4]=0 f=0,0
02d68ea0: cbnz    w9, #0x2d68eac                             
02d68ea4: mov     x0, x8                                     
02d68ea8: bl      #0x2b70f30                                 fn_2b70f30
02d68eac: cbz     x20, #0x2d68f9c                            
02d68eb0: ldr     x8, [x21]                                  M:AdsManager::<OnApplicationPause>b__26_0
02d68eb4: ldr     x8, [x8, #0xb8]                            S:'banner_native_refresh_time'
02d68eb8: ldr     x1, [x8, #0x348]                           S:"Unknown productId '"
02d68ebc: str     x1, [x20, #0x30]!                          
02d68ec0: mov     x0, x20                                    
02d68ec4: bl      #0x2b70d54                                 fn_2b70d54
02d68ec8: ldr     x0, [x22]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d68ecc: bl      #0x3769600                                 fn_3769600
02d68ed0: cbz     x19, #0x2d68f9c                            
02d68ed4: ldr     x8, [x19, #0x20]                           S:'dev log AdsManager show app open ad'
02d68ed8: cbz     x8, #0x2d68f9c                             
02d68edc: cbz     x0, #0x2d68f9c                             
02d68ee0: ldr     w8, [x8, #0x4c]                            [626604c]=0 f=0,0
02d68ee4: add     w9, w8, #1                                 
02d68ee8: ldr     x8, [x22]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d68eec: str     w9, [x0, #0x3c]                            
02d68ef0: mov     x0, x8                                     
02d68ef4: bl      #0x3769600                                 fn_3769600
02d68ef8: mov     x20, x0                                    
02d68efc: mov     x0, xzr                                    
02d68f00: bl      #0x5b432fc                                 UnityEngine.Time::get_time
02d68f04: cbz     x20, #0x2d68f9c                            
02d68f08: ldr     x8, [x19, #0x20]                           S:'dev log AdsManager show app open ad'
02d68f0c: str     s0, [x20, #0x38]                           ._btnCreateMore
02d68f10: cbz     x8, #0x2d68f9c                             
02d68f14: ldr     x9, [x21]                                  M:AdsManager::<OnApplicationPause>b__26_0
02d68f18: ldr     w8, [x8, #0x4c]                            [626604c]=0 f=0,0
02d68f1c: mov     x3, xzr                                    
02d68f20: ldr     x9, [x9, #0xb8]                            
02d68f24: add     w1, w8, #1                                 
02d68f28: ldr     x0, [x9, #0x348]                           
02d68f2c: ldr     x2, [x9, #0x1e8]                           
02d68f30: bl      #0x2c9c5c4                                 DevTrack::GameModeStart
02d68f34: ldr     x0, [x22]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d68f38: bl      #0x3769600                                 fn_3769600
02d68f3c: cbz     x0, #0x2d68f9c                             
02d68f40: ldr     x19, [x0, #0x30]                           S:'popup_rate_on_off'
02d68f44: ldr     x0, [x22]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d68f48: bl      #0x3769600                                 fn_3769600
02d68f4c: cbz     x0, #0x2d68f9c                             
02d68f50: ldr     x8, [x21]                                  M:AdsManager::<OnApplicationPause>b__26_0
02d68f54: ldr     w1, [x0, #0x3c]                            [626603c]=0 f=0,0
02d68f58: mov     x0, x19                                    
02d68f5c: mov     x4, xzr                                    
02d68f60: ldr     x8, [x8, #0xb8]                            S:'banner_native_refresh_time'
02d68f64: ldr     x2, [x8, #0x218]                           MS:System.Collections.Generic.List`1::.ctor
02d68f68: ldr     w3, [x8, #0x270]                           MS:System.Collections.Generic.List`1::GetEnumerator
02d68f6c: bl      #0x2c9c714                                 DevTrack::GameModeStepEnter
02d68f70: ldr     x0, [x22]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d68f74: bl      #0x3769600                                 fn_3769600
02d68f78: cbz     x0, #0x2d68f9c                             
02d68f7c: ldr     x8, [x21]                                  M:AdsManager::<OnApplicationPause>b__26_0
02d68f80: ldp     x20, x19, [sp, #0x20]                      
02d68f84: ldp     x22, x21, [sp, #0x10]                      
02d68f88: ldr     x8, [x8, #0xb8]                            S:'banner_native_refresh_time'
02d68f8c: ldr     x1, [x8, #0x218]                           MS:System.Collections.Generic.List`1::.ctor
02d68f90: str     x1, [x0, #0x40]!                           ._btnNoThank
02d68f94: ldr     x30, [sp], #0x30                           
02d68f98: b       #0x2b70d54                                 
02d68f9c: bl      #0x2b7105c                                 fn_2b7105c
## <OnBtnNoThankClick>b__8_0() -> void
---- Clicker.CreateMorePopup::<OnBtnNoThankClick>b__8_0 0x2d68fa0
02d68fa0: stp     x30, x19, [sp, #-0x10]!                    
02d68fa4: mov     x19, x0                                    
02d68fa8: ldr     x0, [x0, #0x38]                            ._btnCreateMore
02d68fac: cbz     x0, #0x2d68ff8                             
02d68fb0: mov     w1, wzr                                    
02d68fb4: mov     x2, xzr                                    
02d68fb8: bl      #0x5e662d4                                 UnityEngine.UI.Selectable::set_interactable
02d68fbc: ldr     x0, [x19, #0x40]                           ._btnNoThank
02d68fc0: cbz     x0, #0x2d68ff8                             
02d68fc4: mov     w1, wzr                                    
02d68fc8: mov     x2, xzr                                    
02d68fcc: bl      #0x5e662d4                                 UnityEngine.UI.Selectable::set_interactable
02d68fd0: ldr     x0, [x19, #0x48]                           ._btnClose
02d68fd4: cbz     x0, #0x2d68ff8                             
02d68fd8: mov     w1, wzr                                    
02d68fdc: mov     x2, xzr                                    
02d68fe0: bl      #0x5e662d4                                 UnityEngine.UI.Selectable::set_interactable
02d68fe4: ldr     x8, [x19]                                  
02d68fe8: mov     x0, x19                                    
02d68fec: ldp     x2, x1, [x8, #0x198]                       
02d68ff0: ldp     x30, x19, [sp], #0x10                      
02d68ff4: br      x2                                         
02d68ff8: bl      #0x2b7105c                                 fn_2b7105c
