#### CLASS Framework.HoldToScaleButton parent= UnityEngine.MonoBehaviour
#   field _scaleValue                    UnityEngine.Vector3                                off=0x20 attr=1 SerializeField
#   field _scaleTarget                   UnityEngine.Transform                              off=0x30 attr=1 SerializeField
#   field _baseScale                     UnityEngine.Vector3                                off=0x38 attr=1 
#   field _onHold                        bool                                               off=0x44 attr=1 
#   field _button                        UnityEngine.UI.Button                              off=0x48 attr=1 
## Awake() -> void
---- Framework.HoldToScaleButton::Awake 0x2cc433c
02cc433c: stp     x30, x21, [sp, #-0x20]!                    
02cc4340: stp     x20, x19, [sp, #0x10]                      
02cc4344: adrp    x20, #0x662f000                            
02cc4348: mov     x19, x0                                    
02cc434c: ldrb    w8, [x20, #0xc3d]                          
02cc4350: tbnz    w8, #0, #0x2cc4374                         
02cc4354: adrp    x0, #0x6267000                             
02cc4358: ldr     x0, [x0, #0x1b8]                           MS:UnityEngine.Component::GetComponent
02cc435c: bl      #0x2b70db0                                 fn_2b70db0
02cc4360: adrp    x0, #0x6263000                             
02cc4364: ldr     x0, [x0, #0x918]                           T:UnityEngine.Object
02cc4368: bl      #0x2b70db0                                 fn_2b70db0
02cc436c: mov     w8, #1                                     
02cc4370: strb    w8, [x20, #0xc3d]                          
02cc4374: mov     x0, x19                                    
02cc4378: mov     x1, xzr                                    
02cc437c: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02cc4380: cbz     x0, #0x2cc4418                             
02cc4384: adrp    x20, #0x6267000                            
02cc4388: adrp    x21, #0x6263000                            
02cc438c: mov     x1, xzr                                    
02cc4390: ldr     x20, [x20, #0x1b8]                         MS:UnityEngine.Component::GetComponent
02cc4394: ldr     x21, [x21, #0x918]                         T:UnityEngine.Object
02cc4398: bl      #0x5b46ff0                                 UnityEngine.Transform::get_localScale
02cc439c: ldr     x1, [x20]                                  S:'didu'
02cc43a0: mov     x0, x19                                    
02cc43a4: stp     s0, s1, [x19, #0x38]                       ._baseScale
02cc43a8: str     s2, [x19, #0x40]                           
02cc43ac: bl      #0x3140c84                                 fn_3140c84
02cc43b0: mov     x1, x0                                     
02cc43b4: mov     x0, x19                                    
02cc43b8: str     x1, [x0, #0x48]!                           ._button
02cc43bc: bl      #0x2b70d54                                 fn_2b70d54
02cc43c0: ldr     x0, [x21]                                  &2c5bbd4(=a9bd7bfdd503233f)
02cc43c4: mov     x20, x19                                   
02cc43c8: ldr     x21, [x20, #0x30]!                         MS:System.Nullable`1::get_HasValue ._scaleTarget
02cc43cc: ldr     w8, [x0, #0xe4]                            [62630e4]=0 f=0,0
02cc43d0: cbnz    w8, #0x2cc43d8                             
02cc43d4: bl      #0x2b70f30                                 fn_2b70f30
02cc43d8: mov     x0, x21                                    
02cc43dc: mov     x1, xzr                                    
02cc43e0: bl      #0x5b3bb1c                                 UnityEngine.Object::op_Implicit
02cc43e4: tbz     w0, #0, #0x2cc43f4                         
02cc43e8: ldp     x20, x19, [sp, #0x10]                      
02cc43ec: ldp     x30, x21, [sp], #0x20                      
02cc43f0: ret                                                
02cc43f4: mov     x0, x19                                    
02cc43f8: mov     x1, xzr                                    
02cc43fc: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02cc4400: mov     x1, x0                                     
02cc4404: mov     x0, x20                                    
02cc4408: str     x1, [x19, #0x30]                           ._scaleTarget
02cc440c: ldp     x20, x19, [sp, #0x10]                      
02cc4410: ldp     x30, x21, [sp], #0x20                      
02cc4414: b       #0x2b70d54                                 
02cc4418: bl      #0x2b7105c                                 fn_2b7105c
## OnDisable() -> void
---- Framework.HoldToScaleButton::OnDisable 0x2cc441c
02cc441c: stp     x30, x19, [sp, #-0x10]!                    
02cc4420: mov     x1, xzr                                    
02cc4424: mov     x19, x0                                    
02cc4428: strb    wzr, [x0, #0x44]                           ._onHold
02cc442c: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02cc4430: cbz     x0, #0x2cc4448                             
02cc4434: ldp     s0, s1, [x19, #0x38]                       ._baseScale
02cc4438: mov     x1, xzr                                    
02cc443c: ldr     s2, [x19, #0x40]                           
02cc4440: ldp     x30, x19, [sp], #0x10                      
02cc4444: b       #0x5b470cc                                 UnityEngine.Transform::set_localScale
02cc4448: bl      #0x2b7105c                                 fn_2b7105c
## OnPointerDown(UnityEngine.EventSystems.PointerEventData eventData) -> void
---- Framework.HoldToScaleButton::OnPointerDown 0x2cc444c
02cc444c: stp     x30, x19, [sp, #-0x10]!                    
02cc4450: ldr     x8, [x0, #0x48]                            ._button
02cc4454: cbz     x8, #0x2cc4494                             
02cc4458: ldrb    w8, [x8, #0xd8]                            
02cc445c: mov     x19, x0                                    
02cc4460: strb    w8, [x0, #0x44]                            ._onHold
02cc4464: cbz     w8, #0x2cc448c                             
02cc4468: mov     x0, x19                                    
02cc446c: mov     x1, xzr                                    
02cc4470: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02cc4474: cbz     x0, #0x2cc4494                             
02cc4478: ldp     s0, s1, [x19, #0x20]                       ._scaleValue
02cc447c: mov     x1, xzr                                    
02cc4480: ldr     s2, [x19, #0x28]                           
02cc4484: ldp     x30, x19, [sp], #0x10                      
02cc4488: b       #0x5b470cc                                 UnityEngine.Transform::set_localScale
02cc448c: ldp     x30, x19, [sp], #0x10                      
02cc4490: ret                                                
02cc4494: bl      #0x2b7105c                                 fn_2b7105c
## OnPointerExit(UnityEngine.EventSystems.PointerEventData eventData) -> void
---- Framework.HoldToScaleButton::OnPointerExit 0x2cc4498
02cc4498: stp     x30, x19, [sp, #-0x10]!                    
02cc449c: ldrb    w8, [x0, #0x44]                            ._onHold
02cc44a0: cbz     w8, #0x2cc44c8                             
02cc44a4: mov     x1, xzr                                    
02cc44a8: mov     x19, x0                                    
02cc44ac: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02cc44b0: cbz     x0, #0x2cc44d0                             
02cc44b4: ldp     s0, s1, [x19, #0x38]                       ._baseScale
02cc44b8: mov     x1, xzr                                    
02cc44bc: ldr     s2, [x19, #0x40]                           
02cc44c0: ldp     x30, x19, [sp], #0x10                      
02cc44c4: b       #0x5b470cc                                 UnityEngine.Transform::set_localScale
02cc44c8: ldp     x30, x19, [sp], #0x10                      
02cc44cc: ret                                                
02cc44d0: bl      #0x2b7105c                                 fn_2b7105c
## OnPointerUp(UnityEngine.EventSystems.PointerEventData eventData) -> void
---- Framework.HoldToScaleButton::OnPointerUp 0x2cc44d4
02cc44d4: stp     x30, x19, [sp, #-0x10]!                    
02cc44d8: mov     x1, xzr                                    
02cc44dc: mov     x19, x0                                    
02cc44e0: strb    wzr, [x0, #0x44]                           ._onHold
02cc44e4: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02cc44e8: cbz     x0, #0x2cc4500                             
02cc44ec: ldp     s0, s1, [x19, #0x38]                       ._baseScale
02cc44f0: mov     x1, xzr                                    
02cc44f4: ldr     s2, [x19, #0x40]                           
02cc44f8: ldp     x30, x19, [sp], #0x10                      
02cc44fc: b       #0x5b470cc                                 UnityEngine.Transform::set_localScale
02cc4500: bl      #0x2b7105c                                 fn_2b7105c
## OnPointerEnter(UnityEngine.EventSystems.PointerEventData eventData) -> void
---- Framework.HoldToScaleButton::OnPointerEnter 0x2cc4504
02cc4504: stp     x30, x19, [sp, #-0x10]!                    
02cc4508: ldrb    w8, [x0, #0x44]                            ._onHold
02cc450c: cbz     w8, #0x2cc4534                             
02cc4510: mov     x1, xzr                                    
02cc4514: mov     x19, x0                                    
02cc4518: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02cc451c: cbz     x0, #0x2cc453c                             
02cc4520: ldp     s0, s1, [x19, #0x20]                       ._scaleValue
02cc4524: mov     x1, xzr                                    
02cc4528: ldr     s2, [x19, #0x28]                           
02cc452c: ldp     x30, x19, [sp], #0x10                      
02cc4530: b       #0x5b470cc                                 UnityEngine.Transform::set_localScale
02cc4534: ldp     x30, x19, [sp], #0x10                      
02cc4538: ret                                                
02cc453c: bl      #0x2b7105c                                 fn_2b7105c
## .ctor() -> void
---- Framework.HoldToScaleButton::.ctor 0x2cc4540
02cc4540: mov     w8, #0x999a                                
02cc4544: mov     x1, xzr                                    
02cc4548: movk    w8, #0x3f99, lsl #16                       
02cc454c: dup     v0.2s, w8                                  
02cc4550: str     w8, [x0, #0x28]                            
02cc4554: str     d0, [x0, #0x20]                            ._scaleValue
02cc4558: b       #0x5b397b0                                 UnityEngine.MonoBehaviour::.ctor
