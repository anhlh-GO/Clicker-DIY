#### CLASS KeyAds parent= object
#   field _keysData                      KeysData                                           off=0x0 attr=11 
## Init(KeysData config) -> void
---- KeyAds::Init 0x2c9bbb8
02c9bbb8: stp     x30, x21, [sp, #-0x20]!                    
02c9bbbc: stp     x20, x19, [sp, #0x10]                      
02c9bbc0: adrp    x21, #0x662f000                            
02c9bbc4: adrp    x20, #0x6265000                            
02c9bbc8: mov     x19, x0                                    
02c9bbcc: ldrb    w8, [x21, #0xa47]                          
02c9bbd0: ldr     x20, [x20, #0x3b8]                         T:KeyAds
02c9bbd4: tbnz    w8, #0, #0x2c9bbec                         
02c9bbd8: adrp    x0, #0x6265000                             
02c9bbdc: ldr     x0, [x0, #0x3b8]                           T:KeyAds
02c9bbe0: bl      #0x2b70db0                                 fn_2b70db0
02c9bbe4: mov     w8, #1                                     
02c9bbe8: strb    w8, [x21, #0xa47]                          
02c9bbec: ldr     x8, [x20]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9bbf0: mov     x1, x19                                    
02c9bbf4: ldr     x8, [x8, #0xb8]                            
02c9bbf8: str     x19, [x8]                                  
02c9bbfc: ldr     x8, [x20]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9bc00: ldp     x20, x19, [sp, #0x10]                      
02c9bc04: ldr     x0, [x8, #0xb8]                            
02c9bc08: ldp     x30, x21, [sp], #0x20                      
02c9bc0c: b       #0x2b70d54                                 
## Get(AdFormat type) -> string
---- KeyAds::Get 0x2c8de38
02c8de38: str     x30, [sp, #-0x30]!                         
02c8de3c: stp     x22, x21, [sp, #0x10]                      
02c8de40: stp     x20, x19, [sp, #0x20]                      
02c8de44: adrp    x22, #0x662f000                            
02c8de48: adrp    x21, #0x6265000                            
02c8de4c: adrp    x20, #0x6263000                            
02c8de50: ldrb    w8, [x22, #0xa48]                          
02c8de54: ldr     x21, [x21, #0x3b8]                         T:KeyAds
02c8de58: ldr     x20, [x20, #0x918]                         T:UnityEngine.Object
02c8de5c: mov     w19, w0                                    
02c8de60: tbnz    w8, #0, #0x2c8de84                         
02c8de64: adrp    x0, #0x6265000                             
02c8de68: ldr     x0, [x0, #0x3b8]                           T:KeyAds
02c8de6c: bl      #0x2b70db0                                 fn_2b70db0
02c8de70: adrp    x0, #0x6263000                             
02c8de74: ldr     x0, [x0, #0x918]                           T:UnityEngine.Object
02c8de78: bl      #0x2b70db0                                 fn_2b70db0
02c8de7c: mov     w8, #1                                     
02c8de80: strb    w8, [x22, #0xa48]                          
02c8de84: ldr     x8, [x21]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c8de88: ldr     x0, [x20]                                  &2c5bbd4(=a9bd7bfdd503233f)
02c8de8c: ldr     x8, [x8, #0xb8]                            
02c8de90: ldr     w9, [x0, #0xe4]                            [62630e4]=0 f=0,0
02c8de94: ldr     x20, [x8]                                  
02c8de98: cbnz    w9, #0x2c8dea0                             
02c8de9c: bl      #0x2b70f30                                 fn_2b70f30
02c8dea0: mov     x0, x20                                    
02c8dea4: mov     x1, xzr                                    
02c8dea8: mov     x2, xzr                                    
02c8deac: bl      #0x5b3666c                                 UnityEngine.Object::op_Inequality
02c8deb0: tbz     w0, #0, #0x2c8ded8                         
02c8deb4: ldr     x8, [x21]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c8deb8: ldr     x8, [x8, #0xb8]                            
02c8debc: ldr     x0, [x8]                                   
02c8dec0: cbz     x0, #0x2c8defc                             
02c8dec4: mov     w1, w19                                    
02c8dec8: ldp     x20, x19, [sp, #0x20]                      
02c8decc: ldp     x22, x21, [sp, #0x10]                      
02c8ded0: ldr     x30, [sp], #0x30                           
02c8ded4: b       #0x2c9bc10                                 KeysData::GetAdKey
02c8ded8: adrp    x8, #0x6263000                             
02c8dedc: ldr     x8, [x8, #0x970]                           &6645c70(=0)
02c8dee0: ldp     x20, x19, [sp, #0x20]                      
02c8dee4: ldp     x22, x21, [sp, #0x10]                      
02c8dee8: ldr     x8, [x8, #0x90]                            &2c5beb4(=14c8d222d503245f)
02c8deec: ldr     x8, [x8, #0xb8]                            &6263108(=0)
02c8def0: ldr     x0, [x8]                                   &2c5bbd4(=a9bd7bfdd503233f)
02c8def4: ldr     x30, [sp], #0x30                           
02c8def8: ret                                                
02c8defc: bl      #0x2b7105c                                 fn_2b7105c
