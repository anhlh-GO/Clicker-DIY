#### CLASS Framework.WeightErrorHandlingType parent= int
#   field value__                        int                                                off=0x10 attr=606 
#   field SetWeightToOne                 Framework.WeightErrorHandlingType                  off=0x0 attr=8056 
#   field ThrowExceptionOnAdd            Framework.WeightErrorHandlingType                  off=0x0 attr=8056 
