#### CLASS NativeProduceBase`1/<RetryLoadNative>d__12 parent= object
#   field <>1__state                     int                                                off=0x0 attr=1 
#   field <>2__current                   object                                             off=0x0 attr=1 
#   field delaySeconds                   int                                                off=0x0 attr=6 
#   field <>4__this                      NativeProduceBase`1<T>                             off=0x0 attr=6 
##  .ctor (no body)
##  System.IDisposable.Dispose (no body)
##  MoveNext (no body)
##  System.Collections.Generic.IEnumerator<System.Object>.get_Current (no body)
##  System.Collections.IEnumerator.Reset (no body)
##  System.Collections.IEnumerator.get_Current (no body)
#### CLASS NativeProduceBase`1 parent= WejoyService.Singleton`1<T>
#   field nativeReady                    bool                                               off=0x0 attr=1 
#   field retryCoroutine                 UnityEngine.Coroutine                              off=0x0 attr=1 
#   field retryAttempt                   int                                                off=0x0 attr=1 
#   field RetryDelayStep                 int                                                off=0x0 attr=8051 
#   field adFormat                       AdFormat                                           off=0x0 attr=4 
#   field adKey                          string                                             off=0x0 attr=1 
##  SetAdFormat (no body)
##  get_IsAdReady (no body)
##  LoadAd (no body)
##  GetNativeAd (no body)
##  TryLoadNative (no body)
##  RetryLoadNative (no body)
##  OnNativeAdClicked (no body)
##  .ctor (no body)
