#### CLASS BlindBagCollection.ItemProbability parent= System.ValueType
#   field Item                           BlindBagCollection.CollectionItem                  off=0x10 attr=6 
#   field Probability                    float                                              off=0x28 attr=6 
