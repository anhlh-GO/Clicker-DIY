#### CLASS Games.CharacterLoadingSelector/<>c parent= object
#   field <>9                            Games.CharacterLoadingSelector/<>c                 off=0x0 attr=36 
#   field <>9__2_0                       System.Action`1<Games.RandomAnimationConfig>       off=0x8 attr=16 
## .cctor() -> void
---- Games.CharacterLoadingSelector/<>c::.cctor 0x2d30118
02d30118: str     x30, [sp, #-0x20]!                         
02d3011c: stp     x20, x19, [sp, #0x10]                      
02d30120: adrp    x19, #0x6630000                            
02d30124: adrp    x20, #0x626a000                            
02d30128: ldrb    w8, [x19, #0xee]                           
02d3012c: ldr     x20, [x20, #0x630]                         T:Games.CharacterLoadingSelector/<>c
02d30130: tbnz    w8, #0, #0x2d30148                         
02d30134: adrp    x0, #0x626a000                             
02d30138: ldr     x0, [x0, #0x630]                           T:Games.CharacterLoadingSelector/<>c
02d3013c: bl      #0x2b70db0                                 fn_2b70db0
02d30140: mov     w8, #1                                     
02d30144: strb    w8, [x19, #0xee]                           
02d30148: ldr     x0, [x20]                                  T:type56879(k15)
02d3014c: bl      #0x2b7104c                                 fn_2b7104c
02d30150: mov     x1, xzr                                    
02d30154: mov     x19, x0                                    
02d30158: bl      #0x4e53e9c                                 System.Object::.ctor
02d3015c: ldr     x8, [x20]                                  T:type56879(k15)
02d30160: mov     x1, x19                                    
02d30164: ldr     x8, [x8, #0xb8]                            
02d30168: str     x19, [x8]                                  
02d3016c: ldr     x8, [x20]                                  T:type56879(k15)
02d30170: ldp     x20, x19, [sp, #0x10]                      
02d30174: ldr     x0, [x8, #0xb8]                            
02d30178: ldr     x30, [sp], #0x20                           
02d3017c: b       #0x2b70d54                                 
## .ctor() -> void
---- Games.CharacterLoadingSelector/<>c::.ctor 0x2d30180
02d30180: mov     x1, xzr                                    
02d30184: b       #0x4e53e9c                                 System.Object::.ctor
## <Setup>b__2_0(Games.RandomAnimationConfig x) -> void
---- Games.CharacterLoadingSelector/<>c::<Setup>b__2_0 0x2d30188
02d30188: str     x30, [sp, #-0x10]!                         
02d3018c: cbz     x1, #0x2d301b4                             
02d30190: ldr     x0, [x1, #0x18]                            
02d30194: cbz     x0, #0x2d301b4                             
02d30198: mov     x1, xzr                                    
02d3019c: bl      #0x5b339ec                                 UnityEngine.Component::get_gameObject
02d301a0: cbz     x0, #0x2d301b4                             
02d301a4: mov     w1, wzr                                    
02d301a8: mov     x2, xzr                                    
02d301ac: ldr     x30, [sp], #0x10                           
02d301b0: b       #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d301b4: bl      #0x2b7105c                                 fn_2b7105c
#### CLASS Games.CharacterLoadingSelector/<>c__DisplayClass2_0 parent= object
#   field id                             int                                                off=0x10 attr=6 
## .ctor() -> void
---- Games.CharacterLoadingSelector/<>c__DisplayClass2_0::.ctor 0x2d30024
02d30024: mov     x1, xzr                                    
02d30028: b       #0x4e53e9c                                 System.Object::.ctor
## <Setup>b__1(Games.RandomAnimationConfig x) -> bool
---- Games.CharacterLoadingSelector/<>c__DisplayClass2_0::<Setup>b__1 0x2d301b8
02d301b8: cbz     x1, #0x2d301d0                             
02d301bc: ldr     w8, [x1, #0x10]                            
02d301c0: ldr     w9, [x0, #0x10]                            .id
02d301c4: cmp     w8, w9                                     
02d301c8: cset    w0, eq                                     
02d301cc: ret                                                
02d301d0: str     x30, [sp, #-0x10]!                         
02d301d4: bl      #0x2b7105c                                 fn_2b7105c
#### CLASS Games.CharacterLoadingSelector parent= UnityEngine.MonoBehaviour
#   field _randomAnimations              System.Collections.Generic.List`1<Games.RandomAnimationConfig> off=0x20 attr=1 SerializeField
#   field _currentAnimation              Games.RandomAnimation                              off=0x28 attr=1 
## Setup() -> void
---- Games.CharacterLoadingSelector::Setup 0x2d2fdf4
02d2fdf4: str     x30, [sp, #-0x40]!                         
02d2fdf8: stp     x24, x23, [sp, #0x10]                      
02d2fdfc: stp     x22, x21, [sp, #0x20]                      
02d2fe00: stp     x20, x19, [sp, #0x30]                      
02d2fe04: adrp    x20, #0x6630000                            
02d2fe08: adrp    x21, #0x626a000                            
02d2fe0c: adrp    x24, #0x626a000                            
02d2fe10: ldrb    w8, [x20, #0xed]                           
02d2fe14: ldr     x21, [x21, #0x628]                         T:Games.CharacterLoadingSelector/<>c__DisplayClass2_0
02d2fe18: ldr     x24, [x24, #0x630]                         T:Games.CharacterLoadingSelector/<>c
02d2fe1c: mov     x19, x0                                    
02d2fe20: tbnz    w8, #0, #0x2d2fea4                         
02d2fe24: adrp    x0, #0x626a000                             
02d2fe28: ldr     x0, [x0, #0x638]                           T:type53152(k15)
02d2fe2c: bl      #0x2b70db0                                 fn_2b70db0
02d2fe30: adrp    x0, #0x6266000                             
02d2fe34: ldr     x0, [x0, #0x878]                           MS:DataManager::GetData
02d2fe38: bl      #0x2b70db0                                 fn_2b70db0
02d2fe3c: adrp    x0, #0x626a000                             
02d2fe40: ldr     x0, [x0, #0x640]                           MS:System.Collections.Generic.List`1::Find
02d2fe44: bl      #0x2b70db0                                 fn_2b70db0
02d2fe48: adrp    x0, #0x626a000                             
02d2fe4c: ldr     x0, [x0, #0x648]                           MS:System.Collections.Generic.List`1::ForEach
02d2fe50: bl      #0x2b70db0                                 fn_2b70db0
02d2fe54: adrp    x0, #0x6266000                             
02d2fe58: ldr     x0, [x0, #0x658]                           MS:MonoSingleton`1::get_Instance
02d2fe5c: bl      #0x2b70db0                                 fn_2b70db0
02d2fe60: adrp    x0, #0x626a000                             
02d2fe64: ldr     x0, [x0, #0x650]                           T:type57273(k15)
02d2fe68: bl      #0x2b70db0                                 fn_2b70db0
02d2fe6c: adrp    x0, #0x626a000                             
02d2fe70: ldr     x0, [x0, #0x658]                           M:Games.CharacterLoadingSelector/<>c::<Setup>b__2_0
02d2fe74: bl      #0x2b70db0                                 fn_2b70db0
02d2fe78: adrp    x0, #0x626a000                             
02d2fe7c: ldr     x0, [x0, #0x660]                           M:Games.CharacterLoadingSelector/<>c__DisplayClass2_0::<Setup>b__1
02d2fe80: bl      #0x2b70db0                                 fn_2b70db0
02d2fe84: adrp    x0, #0x626a000                             
02d2fe88: ldr     x0, [x0, #0x628]                           T:Games.CharacterLoadingSelector/<>c__DisplayClass2_0
02d2fe8c: bl      #0x2b70db0                                 fn_2b70db0
02d2fe90: adrp    x0, #0x626a000                             
02d2fe94: ldr     x0, [x0, #0x630]                           T:Games.CharacterLoadingSelector/<>c
02d2fe98: bl      #0x2b70db0                                 fn_2b70db0
02d2fe9c: mov     w8, #1                                     
02d2fea0: strb    w8, [x20, #0xed]                           
02d2fea4: ldr     x0, [x21]                                  T:type56879(k15)
02d2fea8: bl      #0x2b7104c                                 fn_2b7104c
02d2feac: mov     x1, xzr                                    
02d2feb0: mov     x20, x0                                    
02d2feb4: bl      #0x4e53e9c                                 System.Object::.ctor
02d2feb8: ldr     x0, [x24]                                  T:type56879(k15)
02d2febc: ldr     x21, [x19, #0x20]                          ._randomAnimations
02d2fec0: ldr     w8, [x0, #0xe4]                            [626a0e4]=0 f=0,0
02d2fec4: cbnz    w8, #0x2d2fed0                             
02d2fec8: bl      #0x2b70f30                                 fn_2b70f30
02d2fecc: ldr     x0, [x24]                                  T:type56879(k15)
02d2fed0: ldr     x8, [x0, #0xb8]                            MS:UnityEngine.Object::FindObjectsOfType
02d2fed4: ldr     x22, [x8, #8]                              
02d2fed8: cbnz    x22, #0x2d2ff34                            
02d2fedc: ldr     w9, [x0, #0xe4]                            [626a0e4]=0 f=0,0
02d2fee0: cbnz    w9, #0x2d2fef0                             
02d2fee4: bl      #0x2b70f30                                 fn_2b70f30
02d2fee8: ldr     x8, [x24]                                  T:type56879(k15)
02d2feec: ldr     x8, [x8, #0xb8]                            
02d2fef0: adrp    x9, #0x626a000                             
02d2fef4: ldr     x9, [x9, #0x638]                           T:type53152(k15)
02d2fef8: ldr     x23, [x8]                                  
02d2fefc: ldr     x0, [x9]                                   T:type56879(k15)
02d2ff00: bl      #0x2b7104c                                 fn_2b7104c
02d2ff04: adrp    x8, #0x626a000                             
02d2ff08: mov     x1, x23                                    
02d2ff0c: mov     x3, xzr                                    
02d2ff10: ldr     x8, [x8, #0x658]                           M:Games.CharacterLoadingSelector/<>c::<Setup>b__2_0
02d2ff14: mov     x22, x0                                    
02d2ff18: ldr     x2, [x8]                                   T:type56879(k15)
02d2ff1c: bl      #0x453418c                                 fn_453418c
02d2ff20: ldr     x8, [x24]                                  T:type56879(k15)
02d2ff24: mov     x1, x22                                    
02d2ff28: ldr     x0, [x8, #0xb8]                            MS:UnityEngine.Object::FindObjectsOfType
02d2ff2c: str     x22, [x0, #8]!                             
02d2ff30: bl      #0x2b70d54                                 fn_2b70d54
02d2ff34: cbz     x21, #0x2d30020                            
02d2ff38: adrp    x8, #0x626a000                             
02d2ff3c: adrp    x23, #0x6266000                            
02d2ff40: mov     x0, x21                                    
02d2ff44: ldr     x8, [x8, #0x648]                           MS:System.Collections.Generic.List`1::ForEach
02d2ff48: ldr     x23, [x23, #0x658]                         MS:MonoSingleton`1::get_Instance
02d2ff4c: mov     x1, x22                                    
02d2ff50: ldr     x2, [x8]                                   T:type56879(k15)
02d2ff54: bl      #0x35a9ce4                                 fn_35a9ce4
02d2ff58: ldr     x0, [x23]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d2ff5c: bl      #0x3769600                                 fn_3769600
02d2ff60: cbz     x0, #0x2d30020                             
02d2ff64: adrp    x8, #0x6266000                             
02d2ff68: ldr     x8, [x8, #0x878]                           MS:DataManager::GetData
02d2ff6c: ldr     x1, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d2ff70: bl      #0x3168dd0                                 fn_3168dd0
02d2ff74: cbz     x0, #0x2d30020                             
02d2ff78: mov     w1, wzr                                    
02d2ff7c: mov     x2, xzr                                    
02d2ff80: bl      #0x2d25c44                                 Decor.DataDecor::GetSelectedItem
02d2ff84: cbz     x20, #0x2d30020                            
02d2ff88: adrp    x8, #0x626a000                             
02d2ff8c: adrp    x22, #0x626a000                            
02d2ff90: ldr     x8, [x8, #0x650]                           T:type57273(k15)
02d2ff94: ldr     x22, [x22, #0x660]                         M:Games.CharacterLoadingSelector/<>c__DisplayClass2_0::<Setup>b__1
02d2ff98: ldr     x21, [x19, #0x20]                          ._randomAnimations
02d2ff9c: str     w0, [x20, #0x10]                           
02d2ffa0: ldr     x8, [x8]                                   T:type56879(k15)
02d2ffa4: mov     x0, x8                                     
02d2ffa8: bl      #0x2b7104c                                 fn_2b7104c
02d2ffac: ldr     x2, [x22]                                  T:type56879(k15)
02d2ffb0: mov     x1, x20                                    
02d2ffb4: mov     x3, xzr                                    
02d2ffb8: mov     x22, x0                                    
02d2ffbc: bl      #0x399ba10                                 fn_399ba10
02d2ffc0: cbz     x21, #0x2d30020                            
02d2ffc4: adrp    x8, #0x626a000                             
02d2ffc8: mov     x0, x21                                    
02d2ffcc: mov     x1, x22                                    
02d2ffd0: ldr     x8, [x8, #0x640]                           MS:System.Collections.Generic.List`1::Find
02d2ffd4: ldr     x2, [x8]                                   T:type56879(k15)
02d2ffd8: bl      #0x35a9868                                 fn_35a9868
02d2ffdc: cbz     x0, #0x2d30020                             
02d2ffe0: ldr     x1, [x0, #0x18]                            MS:System.Collections.Generic.List`1::Add
02d2ffe4: str     x1, [x19, #0x28]!                          ._currentAnimation
02d2ffe8: mov     x0, x19                                    
02d2ffec: bl      #0x2b70d54                                 fn_2b70d54
02d2fff0: ldr     x0, [x19]                                  
02d2fff4: cbz     x0, #0x2d30020                             
02d2fff8: mov     x1, xzr                                    
02d2fffc: bl      #0x5b339ec                                 UnityEngine.Component::get_gameObject
02d30000: cbz     x0, #0x2d30020                             
02d30004: ldp     x20, x19, [sp, #0x30]                      
02d30008: mov     w1, #1                                     
02d3000c: ldp     x22, x21, [sp, #0x20]                      
02d30010: mov     x2, xzr                                    
02d30014: ldp     x24, x23, [sp, #0x10]                      
02d30018: ldr     x30, [sp], #0x40                           
02d3001c: b       #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d30020: bl      #0x2b7105c                                 fn_2b7105c
## PlayAnimation() -> void
---- Games.CharacterLoadingSelector::PlayAnimation 0x2d3002c
02d3002c: stp     x30, x19, [sp, #-0x10]!                    
02d30030: mov     x19, x0                                    
02d30034: bl      #0x2d2fdf4                                 Games.CharacterLoadingSelector::Setup
02d30038: ldr     x0, [x19, #0x28]                           ._currentAnimation
02d3003c: cbz     x0, #0x2d30048                             
02d30040: ldp     x30, x19, [sp], #0x10                      
02d30044: b       #0x2d3004c                                 Games.RandomAnimation::PlayRandomAnimation
02d30048: bl      #0x2b7105c                                 fn_2b7105c
## .ctor() -> void
---- Games.CharacterLoadingSelector::.ctor 0x2d30110
02d30110: mov     x1, xzr                                    
02d30114: b       #0x5b397b0                                 UnityEngine.MonoBehaviour::.ctor
