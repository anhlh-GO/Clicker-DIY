#### CLASS FsnBannerAd parent= object
#   field androidBannerAd                UnityEngine.AndroidJavaObject                      off=0x10 attr=1 
#   field onFsnLoadListener              AndroidOnFsnLoadListener                           off=0x18 attr=1 
#   field onFsnCompletedListener         AndroidOnFsnCompletedListener                      off=0x20 attr=1 
## .ctor() -> void
---- FsnBannerAd::.ctor 0x2c93c68
02c93c68: str     x30, [sp, #-0x30]!                         
02c93c6c: stp     x22, x21, [sp, #0x10]                      
02c93c70: stp     x20, x19, [sp, #0x20]                      
02c93c74: adrp    x21, #0x662f000                            
02c93c78: adrp    x20, #0x6264000                            
02c93c7c: mov     x19, x0                                    
02c93c80: ldrb    w8, [x21, #0x9e4]                          
02c93c84: ldr     x20, [x20, #0xa70]                         T:UnityEngine.Application
02c93c88: tbnz    w8, #0, #0x2c93cc4                         
02c93c8c: adrp    x0, #0x6263000                             
02c93c90: ldr     x0, [x0, #0xbd8]                           T:UnityEngine.AndroidJavaObject
02c93c94: bl      #0x2b70db0                                 fn_2b70db0
02c93c98: adrp    x0, #0x6264000                             
02c93c9c: ldr     x0, [x0, #0xa70]                           T:UnityEngine.Application
02c93ca0: bl      #0x2b70db0                                 fn_2b70db0
02c93ca4: adrp    x0, #0x6263000                             
02c93ca8: ldr     x0, [x0, #0xb70]                           MS:System.Array::Empty
02c93cac: bl      #0x2b70db0                                 fn_2b70db0
02c93cb0: adrp    x0, #0x6265000                             
02c93cb4: ldr     x0, [x0, #0x778]                           S:'com.ads.fsnforunity.fsnlib.BannerNAd'
02c93cb8: bl      #0x2b70db0                                 fn_2b70db0
02c93cbc: mov     w8, #1                                     
02c93cc0: strb    w8, [x21, #0x9e4]                          
02c93cc4: mov     x0, x19                                    
02c93cc8: mov     x1, xzr                                    
02c93ccc: bl      #0x4e53e9c                                 System.Object::.ctor
02c93cd0: ldr     x0, [x20]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c93cd4: ldr     w8, [x0, #0xe4]                            [62650e4]=0 f=0,0
02c93cd8: cbnz    w8, #0x2c93ce0                             
02c93cdc: bl      #0x2b70f30                                 fn_2b70f30
02c93ce0: mov     x0, xzr                                    
02c93ce4: bl      #0x5aeb18c                                 UnityEngine.Application::get_platform
02c93ce8: cmp     w0, #0xb                                   
02c93cec: b.ne    #0x2c93d98                                 
02c93cf0: adrp    x8, #0x6263000                             
02c93cf4: ldr     x8, [x8, #0xb70]                           MS:System.Array::Empty
02c93cf8: ldr     x20, [x8]                                  &2c5bbd4(=a9bd7bfdd503233f)
02c93cfc: ldr     x8, [x20, #0x38]                           M:UnityEngine.Rigidbody::MovePosition
02c93d00: cbnz    x8, #0x2c93d10                             
02c93d04: mov     x0, x20                                    
02c93d08: bl      #0x2ba9d7c                                 fn_2ba9d7c
02c93d0c: ldr     x8, [x20, #0x38]                           M:UnityEngine.Rigidbody::MovePosition
02c93d10: ldr     x0, [x8, #0x10]                            &2c498bc(=aa1f03e0d503245f)
02c93d14: add     x8, x0, #0x135                             &6265135
02c93d18: ldrh    w8, [x8]                                   
02c93d1c: tbnz    w8, #0, #0x2c93d24                         
02c93d20: bl      #0x2ba9d20                                 fn_2ba9d20
02c93d24: ldr     w8, [x0, #0xe4]                            [62650e4]=0 f=0,0
02c93d28: cbnz    w8, #0x2c93d30                             
02c93d2c: bl      #0x2b70f30                                 fn_2b70f30
02c93d30: ldr     x8, [x20, #0x38]                           M:UnityEngine.Rigidbody::MovePosition
02c93d34: adrp    x22, #0x6263000                            
02c93d38: adrp    x21, #0x6265000                            
02c93d3c: ldr     x0, [x8, #0x10]                            &2c498bc(=aa1f03e0d503245f)
02c93d40: ldr     x22, [x22, #0xbd8]                         T:UnityEngine.AndroidJavaObject
02c93d44: add     x8, x0, #0x135                             &6265135
02c93d48: ldrh    w8, [x8]                                   
02c93d4c: ldr     x21, [x21, #0x778]                         S:'com.ads.fsnforunity.fsnlib.BannerNAd'
02c93d50: tbnz    w8, #0, #0x2c93d58                         
02c93d54: bl      #0x2ba9d20                                 fn_2ba9d20
02c93d58: ldr     x8, [x0, #0xb8]                            T:AdsManager/<>c__DisplayClass42_0
02c93d5c: ldr     x0, [x22]                                  &2c5bbd4(=a9bd7bfdd503233f)
02c93d60: ldr     x20, [x8]                                  &2c5bbd4(=a9bd7bfdd503233f)
02c93d64: bl      #0x2b7104c                                 fn_2b7104c
02c93d68: ldr     x1, [x21]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c93d6c: mov     x2, x20                                    
02c93d70: mov     x3, xzr                                    
02c93d74: mov     x21, x0                                    
02c93d78: bl      #0x5ad5b2c                                 UnityEngine.AndroidJavaObject::.ctor
02c93d7c: str     x21, [x19, #0x10]!                         .androidBannerAd
02c93d80: mov     x0, x19                                    
02c93d84: mov     x1, x21                                    
02c93d88: ldp     x20, x19, [sp, #0x20]                      
02c93d8c: ldp     x22, x21, [sp, #0x10]                      
02c93d90: ldr     x30, [sp], #0x30                           
02c93d94: b       #0x2b70d54                                 
02c93d98: ldp     x20, x19, [sp, #0x20]                      
02c93d9c: ldp     x22, x21, [sp, #0x10]                      
02c93da0: ldr     x30, [sp], #0x30                           
02c93da4: ret                                                
## InitNativeBanner(string adUnitId, bool loadNewAfterClose, bool startMuteVideo, bool autoDismissWhenAdClicked) -> void
---- FsnBannerAd::InitNativeBanner 0x2c93da8
02c93da8: sub     sp, sp, #0x50                              
02c93dac: stp     x30, x25, [sp, #0x10]                      
02c93db0: stp     x24, x23, [sp, #0x20]                      
02c93db4: stp     x22, x21, [sp, #0x30]                      
02c93db8: stp     x20, x19, [sp, #0x40]                      
02c93dbc: adrp    x21, #0x662f000                            
02c93dc0: adrp    x25, #0x6264000                            
02c93dc4: mov     w19, w4                                    
02c93dc8: ldrb    w8, [x21, #0x9e5]                          
02c93dcc: ldr     x25, [x25, #0xa70]                         T:UnityEngine.Application
02c93dd0: mov     w22, w3                                    
02c93dd4: mov     w24, w2                                    
02c93dd8: mov     x23, x1                                    
02c93ddc: mov     x20, x0                                    
02c93de0: tbnz    w8, #0, #0x2c93e10                         
02c93de4: adrp    x0, #0x6264000                             
02c93de8: ldr     x0, [x0, #0xa70]                           T:UnityEngine.Application
02c93dec: bl      #0x2b70db0                                 fn_2b70db0
02c93df0: adrp    x0, #0x6263000                             
02c93df4: ldr     x0, [x0, #0xa80]                           T:type24502(k1d)
02c93df8: bl      #0x2b70db0                                 fn_2b70db0
02c93dfc: adrp    x0, #0x6265000                             
02c93e00: ldr     x0, [x0, #0x780]                           S:'InitNativeBanner'
02c93e04: bl      #0x2b70db0                                 fn_2b70db0
02c93e08: mov     w8, #1                                     
02c93e0c: strb    w8, [x21, #0x9e5]                          
02c93e10: ldr     x0, [x25]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c93e14: ldr     w8, [x0, #0xe4]                            [62650e4]=0 f=0,0
02c93e18: cbnz    w8, #0x2c93e20                             
02c93e1c: bl      #0x2b70f30                                 fn_2b70f30
02c93e20: mov     x0, xzr                                    
02c93e24: bl      #0x5aeb18c                                 UnityEngine.Application::get_platform
02c93e28: cmp     w0, #0xb                                   
02c93e2c: b.ne    #0x2c93f8c                                 
02c93e30: ldr     x20, [x20, #0x10]                          .androidBannerAd
02c93e34: cbz     x20, #0x2c93f8c                            
02c93e38: adrp    x8, #0x6263000                             
02c93e3c: mov     w1, #4                                     
02c93e40: ldr     x8, [x8, #0xa80]                           T:type24502(k1d)
02c93e44: ldr     x0, [x8]                                   &2c5bbd4(=a9bd7bfdd503233f)
02c93e48: bl      #0x2b70ea0                                 fn_2b70ea0
02c93e4c: cbz     x0, #0x2c93fb4                             
02c93e50: mov     x21, x0                                    
02c93e54: cbz     x23, #0x2c93e6c                            
02c93e58: ldr     x8, [x21]                                  &2b706c4(=eb01011ff9400808)
02c93e5c: mov     x0, x23                                    
02c93e60: ldr     x1, [x8, #0x40]                            [6263040]=0 f=0,0
02c93e64: bl      #0x2b70f34                                 fn_2b70f34
02c93e68: cbz     x0, #0x2c93fa8                             
02c93e6c: ldr     w8, [x21, #0x18]                           [662f018]=6000014 f=2.40742e-35,0 .onFsnLoadListener
02c93e70: cbz     w8, #0x2c93fa4                             
02c93e74: mov     x0, x21                                    
02c93e78: mov     x1, x23                                    
02c93e7c: and     w25, w24, #1                               
02c93e80: str     x23, [x0, #0x20]!                          .onFsnCompletedListener
02c93e84: bl      #0x2b70d54                                 fn_2b70d54
02c93e88: adrp    x24, #0x6263000                            
02c93e8c: add     x1, sp, #0xc                               
02c93e90: ldr     x24, [x24, #0x970]                         &6645c70(=0)
02c93e94: strb    w25, [sp, #0xc]                            
02c93e98: ldr     x0, [x24, #0x28]                           [6263028]=0 f=0,0
02c93e9c: bl      #0x2b70f38                                 fn_2b70f38
02c93ea0: mov     x23, x0                                    
02c93ea4: cbz     x0, #0x2c93ebc                             
02c93ea8: ldr     x8, [x21]                                  &2b706c4(=eb01011ff9400808)
02c93eac: mov     x0, x23                                    
02c93eb0: ldr     x1, [x8, #0x40]                            [6263040]=0 f=0,0
02c93eb4: bl      #0x2b70f34                                 fn_2b70f34
02c93eb8: cbz     x0, #0x2c93fa8                             
02c93ebc: ldr     w8, [x21, #0x18]                           [662f018]=6000014 f=2.40742e-35,0 .onFsnLoadListener
02c93ec0: tst     w8, #0xfffffffe                            
02c93ec4: b.eq    #0x2c93fa4                                 
02c93ec8: mov     x0, x21                                    
02c93ecc: mov     x1, x23                                    
02c93ed0: and     w22, w22, #1                               
02c93ed4: str     x23, [x0, #0x28]!                          
02c93ed8: bl      #0x2b70d54                                 fn_2b70d54
02c93edc: ldr     x0, [x24, #0x28]                           [6263028]=0 f=0,0
02c93ee0: add     x1, sp, #8                                 
02c93ee4: strb    w22, [sp, #8]                              
02c93ee8: bl      #0x2b70f38                                 fn_2b70f38
02c93eec: mov     x22, x0                                    
02c93ef0: cbz     x0, #0x2c93f08                             
02c93ef4: ldr     x8, [x21]                                  &2b706c4(=eb01011ff9400808)
02c93ef8: mov     x0, x22                                    
02c93efc: ldr     x1, [x8, #0x40]                            [6263040]=0 f=0,0
02c93f00: bl      #0x2b70f34                                 fn_2b70f34
02c93f04: cbz     x0, #0x2c93fa8                             
02c93f08: ldr     w8, [x21, #0x18]                           [662f018]=6000014 f=2.40742e-35,0 .onFsnLoadListener
02c93f0c: cmp     w8, #2                                     
02c93f10: b.ls    #0x2c93fa4                                 
02c93f14: mov     x0, x21                                    
02c93f18: mov     x1, x22                                    
02c93f1c: and     w19, w19, #1                               
02c93f20: str     x22, [x0, #0x30]!                          
02c93f24: bl      #0x2b70d54                                 fn_2b70d54
02c93f28: ldr     x0, [x24, #0x28]                           [6263028]=0 f=0,0
02c93f2c: add     x1, sp, #4                                 
02c93f30: strb    w19, [sp, #4]                              
02c93f34: bl      #0x2b70f38                                 fn_2b70f38
02c93f38: mov     x19, x0                                    
02c93f3c: cbz     x0, #0x2c93f54                             
02c93f40: ldr     x8, [x21]                                  &2b706c4(=eb01011ff9400808)
02c93f44: mov     x0, x19                                    
02c93f48: ldr     x1, [x8, #0x40]                            [6263040]=0 f=0,0
02c93f4c: bl      #0x2b70f34                                 fn_2b70f34
02c93f50: cbz     x0, #0x2c93fa8                             
02c93f54: ldr     w8, [x21, #0x18]                           [662f018]=6000014 f=2.40742e-35,0 .onFsnLoadListener
02c93f58: tst     w8, #0xfffffffc                            
02c93f5c: b.eq    #0x2c93fa4                                 
02c93f60: mov     x0, x21                                    
02c93f64: mov     x1, x19                                    
02c93f68: str     x19, [x0, #0x38]!                          
02c93f6c: bl      #0x2b70d54                                 fn_2b70d54
02c93f70: adrp    x8, #0x6265000                             
02c93f74: mov     x0, x20                                    
02c93f78: mov     x2, x21                                    
02c93f7c: ldr     x8, [x8, #0x780]                           S:'InitNativeBanner'
02c93f80: mov     x3, xzr                                    
02c93f84: ldr     x1, [x8]                                   M:AdsManager::<OnApplicationPause>b__26_0
02c93f88: bl      #0x5ad5e34                                 UnityEngine.AndroidJavaObject::Call
02c93f8c: ldp     x20, x19, [sp, #0x40]                      
02c93f90: ldp     x22, x21, [sp, #0x30]                      
02c93f94: ldp     x24, x23, [sp, #0x20]                      
02c93f98: ldp     x30, x25, [sp, #0x10]                      
02c93f9c: add     sp, sp, #0x50                              
02c93fa0: ret                                                
02c93fa4: bl      #0x2b71064                                 fn_2b71064
02c93fa8: bl      #0x2b71080                                 fn_2b71080
02c93fac: mov     x1, xzr                                    
02c93fb0: bl      #0x2b70f20                                 fn_2b70f20
02c93fb4: bl      #0x2b7105c                                 fn_2b7105c
## SetBannerNativeListener(System.Action`2<int,string> onLoadingCompleted, System.Action onLoadingStarted, System.Action`4<string,string,double,string> onAdPaid) -> void
---- FsnBannerAd::SetBannerNativeListener 0x2c93fb8
02c93fb8: str     x30, [sp, #-0x40]!                         
02c93fbc: stp     x24, x23, [sp, #0x10]                      
02c93fc0: stp     x22, x21, [sp, #0x20]                      
02c93fc4: stp     x20, x19, [sp, #0x30]                      
02c93fc8: adrp    x23, #0x662f000                            
02c93fcc: adrp    x24, #0x6264000                            
02c93fd0: mov     x20, x3                                    
02c93fd4: ldrb    w8, [x23, #0x9e6]                          
02c93fd8: ldr     x24, [x24, #0xa70]                         T:UnityEngine.Application
02c93fdc: mov     x21, x2                                    
02c93fe0: mov     x22, x1                                    
02c93fe4: mov     x19, x0                                    
02c93fe8: tbnz    w8, #0, #0x2c94024                         
02c93fec: adrp    x0, #0x6265000                             
02c93ff0: ldr     x0, [x0, #0x710]                           T:AndroidOnFsnLoadListener
02c93ff4: bl      #0x2b70db0                                 fn_2b70db0
02c93ff8: adrp    x0, #0x6264000                             
02c93ffc: ldr     x0, [x0, #0xa70]                           T:UnityEngine.Application
02c94000: bl      #0x2b70db0                                 fn_2b70db0
02c94004: adrp    x0, #0x6263000                             
02c94008: ldr     x0, [x0, #0xa80]                           T:type24502(k1d)
02c9400c: bl      #0x2b70db0                                 fn_2b70db0
02c94010: adrp    x0, #0x6265000                             
02c94014: ldr     x0, [x0, #0x788]                           S:'SetBannerNativeListener'
02c94018: bl      #0x2b70db0                                 fn_2b70db0
02c9401c: mov     w8, #1                                     
02c94020: strb    w8, [x23, #0x9e6]                          
02c94024: ldr     x0, [x24]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c94028: ldr     w8, [x0, #0xe4]                            [62650e4]=0 f=0,0
02c9402c: cbnz    w8, #0x2c94034                             
02c94030: bl      #0x2b70f30                                 fn_2b70f30
02c94034: mov     x0, xzr                                    
02c94038: bl      #0x5aeb18c                                 UnityEngine.Application::get_platform
02c9403c: cmp     w0, #0xb                                   
02c94040: b.ne    #0x2c940fc                                 
02c94044: adrp    x8, #0x6265000                             
02c94048: ldr     x8, [x8, #0x710]                           T:AndroidOnFsnLoadListener
02c9404c: ldr     x0, [x8]                                   M:AdsManager::<OnApplicationPause>b__26_0
02c94050: bl      #0x2b7104c                                 fn_2b7104c
02c94054: mov     x1, x22                                    
02c94058: mov     x2, x21                                    
02c9405c: mov     x3, x20                                    
02c94060: mov     x23, x0                                    
02c94064: bl      #0x2c933dc                                 AndroidOnFsnLoadListener::.ctor
02c94068: str     x23, [x19, #0x18]!                         .onFsnLoadListener
02c9406c: mov     x0, x19                                    
02c94070: mov     x1, x23                                    
02c94074: bl      #0x2b70d54                                 fn_2b70d54
02c94078: ldur    x20, [x19, #-8]                            
02c9407c: cbz     x20, #0x2c940fc                            
02c94080: adrp    x8, #0x6263000                             
02c94084: mov     w1, #1                                     
02c94088: ldr     x8, [x8, #0xa80]                           T:type24502(k1d)
02c9408c: ldr     x0, [x8]                                   &2c5bbd4(=a9bd7bfdd503233f)
02c94090: bl      #0x2b70ea0                                 fn_2b70ea0
02c94094: cbz     x0, #0x2c94110                             
02c94098: ldr     x19, [x19]                                 
02c9409c: mov     x21, x0                                    
02c940a0: cbz     x19, #0x2c940b8                            
02c940a4: ldr     x8, [x21]                                  
02c940a8: mov     x0, x19                                    
02c940ac: ldr     x1, [x8, #0x40]                            [6263040]=0 f=0,0
02c940b0: bl      #0x2b70f34                                 fn_2b70f34
02c940b4: cbz     x0, #0x2c94118                             
02c940b8: ldr     w8, [x21, #0x18]                           .onFsnLoadListener
02c940bc: cbz     w8, #0x2c94114                             
02c940c0: mov     x0, x21                                    
02c940c4: mov     x1, x19                                    
02c940c8: str     x19, [x0, #0x20]!                          .onFsnCompletedListener
02c940cc: bl      #0x2b70d54                                 fn_2b70d54
02c940d0: adrp    x8, #0x6265000                             
02c940d4: mov     x0, x20                                    
02c940d8: mov     x2, x21                                    
02c940dc: ldr     x8, [x8, #0x788]                           S:'SetBannerNativeListener'
02c940e0: ldp     x20, x19, [sp, #0x30]                      
02c940e4: ldp     x22, x21, [sp, #0x20]                      
02c940e8: mov     x3, xzr                                    
02c940ec: ldp     x24, x23, [sp, #0x10]                      
02c940f0: ldr     x1, [x8]                                   M:AdsManager::<OnApplicationPause>b__26_0
02c940f4: ldr     x30, [sp], #0x40                           
02c940f8: b       #0x5ad5e34                                 UnityEngine.AndroidJavaObject::Call
02c940fc: ldp     x20, x19, [sp, #0x30]                      
02c94100: ldp     x22, x21, [sp, #0x20]                      
02c94104: ldp     x24, x23, [sp, #0x10]                      
02c94108: ldr     x30, [sp], #0x40                           
02c9410c: ret                                                
02c94110: bl      #0x2b7105c                                 fn_2b7105c
02c94114: bl      #0x2b71064                                 fn_2b71064
02c94118: bl      #0x2b71080                                 fn_2b71080
02c9411c: mov     x1, xzr                                    
02c94120: bl      #0x2b70f20                                 fn_2b70f20
## LoadBannerAd() -> void
---- FsnBannerAd::LoadBannerAd 0x2c94124
02c94124: stp     x30, x21, [sp, #-0x20]!                    
02c94128: stp     x20, x19, [sp, #0x10]                      
02c9412c: adrp    x20, #0x662f000                            
02c94130: adrp    x21, #0x6264000                            
02c94134: mov     x19, x0                                    
02c94138: ldrb    w8, [x20, #0x9e7]                          
02c9413c: ldr     x21, [x21, #0xa70]                         T:UnityEngine.Application
02c94140: tbnz    w8, #0, #0x2c941a0                         
02c94144: adrp    x0, #0x6263000                             
02c94148: ldr     x0, [x0, #0xc40]                           T:UnityEngine.AndroidJavaClass
02c9414c: bl      #0x2b70db0                                 fn_2b70db0
02c94150: adrp    x0, #0x6263000                             
02c94154: ldr     x0, [x0, #0xc50]                           MS:UnityEngine.AndroidJavaObject::GetStatic
02c94158: bl      #0x2b70db0                                 fn_2b70db0
02c9415c: adrp    x0, #0x6264000                             
02c94160: ldr     x0, [x0, #0xa70]                           T:UnityEngine.Application
02c94164: bl      #0x2b70db0                                 fn_2b70db0
02c94168: adrp    x0, #0x6263000                             
02c9416c: ldr     x0, [x0, #0xa80]                           T:type24502(k1d)
02c94170: bl      #0x2b70db0                                 fn_2b70db0
02c94174: adrp    x0, #0x6265000                             
02c94178: ldr     x0, [x0, #0x730]                           S:'com.unity3d.player.UnityPlayer'
02c9417c: bl      #0x2b70db0                                 fn_2b70db0
02c94180: adrp    x0, #0x6265000                             
02c94184: ldr     x0, [x0, #0x790]                           S:'LoadBannerAd'
02c94188: bl      #0x2b70db0                                 fn_2b70db0
02c9418c: adrp    x0, #0x6265000                             
02c94190: ldr     x0, [x0, #0x738]                           S:'currentActivity'
02c94194: bl      #0x2b70db0                                 fn_2b70db0
02c94198: mov     w8, #1                                     
02c9419c: strb    w8, [x20, #0x9e7]                          
02c941a0: ldr     x0, [x21]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c941a4: ldr     w8, [x0, #0xe4]                            [62650e4]=0 f=0,0
02c941a8: cbnz    w8, #0x2c941b0                             
02c941ac: bl      #0x2b70f30                                 fn_2b70f30
02c941b0: mov     x0, xzr                                    
02c941b4: bl      #0x5aeb18c                                 UnityEngine.Application::get_platform
02c941b8: cmp     w0, #0xb                                   
02c941bc: b.ne    #0x2c94288                                 
02c941c0: adrp    x8, #0x6263000                             
02c941c4: adrp    x20, #0x6265000                            
02c941c8: ldr     x8, [x8, #0xc40]                           T:UnityEngine.AndroidJavaClass
02c941cc: ldr     x20, [x20, #0x730]                         S:'com.unity3d.player.UnityPlayer'
02c941d0: ldr     x0, [x8]                                   &2c5bbd4(=a9bd7bfdd503233f)
02c941d4: bl      #0x2b7104c                                 fn_2b7104c
02c941d8: ldr     x1, [x20]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c941dc: mov     x2, xzr                                    
02c941e0: mov     x20, x0                                    
02c941e4: bl      #0x5ad2f6c                                 UnityEngine.AndroidJavaClass::.ctor
02c941e8: cbz     x20, #0x2c94294                            
02c941ec: adrp    x8, #0x6265000                             
02c941f0: adrp    x9, #0x6263000                             
02c941f4: mov     x0, x20                                    
02c941f8: ldr     x8, [x8, #0x738]                           S:'currentActivity'
02c941fc: ldr     x9, [x9, #0xc50]                           MS:UnityEngine.AndroidJavaObject::GetStatic
02c94200: ldr     x1, [x8]                                   M:AdsManager::<OnApplicationPause>b__26_0
02c94204: ldr     x2, [x9]                                   &2c5bbd4(=a9bd7bfdd503233f)
02c94208: bl      #0x3121808                                 fn_3121808
02c9420c: ldr     x19, [x19, #0x10]                          .androidBannerAd
02c94210: cbz     x19, #0x2c94288                            
02c94214: adrp    x8, #0x6263000                             
02c94218: mov     x20, x0                                    
02c9421c: mov     w1, #1                                     
02c94220: ldr     x8, [x8, #0xa80]                           T:type24502(k1d)
02c94224: ldr     x0, [x8]                                   &2c5bbd4(=a9bd7bfdd503233f)
02c94228: bl      #0x2b70ea0                                 fn_2b70ea0
02c9422c: cbz     x0, #0x2c94294                             
02c94230: mov     x21, x0                                    
02c94234: cbz     x20, #0x2c9424c                            
02c94238: ldr     x8, [x21]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c9423c: mov     x0, x20                                    
02c94240: ldr     x1, [x8, #0x40]                            [6263040]=0 f=0,0
02c94244: bl      #0x2b70f34                                 fn_2b70f34
02c94248: cbz     x0, #0x2c9429c                             
02c9424c: ldr     w8, [x21, #0x18]                           M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass2_0::<DOSetFloat>b__1 .onFsnLoadListener
02c94250: cbz     w8, #0x2c94298                             
02c94254: mov     x0, x21                                    
02c94258: mov     x1, x20                                    
02c9425c: str     x20, [x0, #0x20]!                          .onFsnCompletedListener
02c94260: bl      #0x2b70d54                                 fn_2b70d54
02c94264: adrp    x8, #0x6265000                             
02c94268: mov     x0, x19                                    
02c9426c: mov     x2, x21                                    
02c94270: ldr     x8, [x8, #0x790]                           S:'LoadBannerAd'
02c94274: ldp     x20, x19, [sp, #0x10]                      
02c94278: mov     x3, xzr                                    
02c9427c: ldr     x1, [x8]                                   M:AdsManager::<OnApplicationPause>b__26_0
02c94280: ldp     x30, x21, [sp], #0x20                      
02c94284: b       #0x5ad5e34                                 UnityEngine.AndroidJavaObject::Call
02c94288: ldp     x20, x19, [sp, #0x10]                      
02c9428c: ldp     x30, x21, [sp], #0x20                      
02c94290: ret                                                
02c94294: bl      #0x2b7105c                                 fn_2b7105c
02c94298: bl      #0x2b71064                                 fn_2b71064
02c9429c: bl      #0x2b71080                                 fn_2b71080
02c942a0: mov     x1, xzr                                    
02c942a4: bl      #0x2b70f20                                 fn_2b70f20
## ShowBannerAd(System.Action`1<string> onAdCompleted, bool isBigBanner) -> void
---- FsnBannerAd::ShowBannerAd 0x2c942a8
02c942a8: sub     sp, sp, #0x40                              
02c942ac: stp     x30, x23, [sp, #0x10]                      
02c942b0: stp     x22, x21, [sp, #0x20]                      
02c942b4: stp     x20, x19, [sp, #0x30]                      
02c942b8: adrp    x22, #0x662f000                            
02c942bc: adrp    x23, #0x6264000                            
02c942c0: mov     w20, w2                                    
02c942c4: ldrb    w8, [x22, #0x9e8]                          
02c942c8: ldr     x23, [x23, #0xa70]                         T:UnityEngine.Application
02c942cc: mov     x21, x1                                    
02c942d0: mov     x19, x0                                    
02c942d4: tbnz    w8, #0, #0x2c9434c                         
02c942d8: adrp    x0, #0x6263000                             
02c942dc: ldr     x0, [x0, #0xc40]                           T:UnityEngine.AndroidJavaClass
02c942e0: bl      #0x2b70db0                                 fn_2b70db0
02c942e4: adrp    x0, #0x6263000                             
02c942e8: ldr     x0, [x0, #0xc50]                           MS:UnityEngine.AndroidJavaObject::GetStatic
02c942ec: bl      #0x2b70db0                                 fn_2b70db0
02c942f0: adrp    x0, #0x6265000                             
02c942f4: ldr     x0, [x0, #0x740]                           T:AndroidOnFsnCompletedListener
02c942f8: bl      #0x2b70db0                                 fn_2b70db0
02c942fc: adrp    x0, #0x6264000                             
02c94300: ldr     x0, [x0, #0xa70]                           T:UnityEngine.Application
02c94304: bl      #0x2b70db0                                 fn_2b70db0
02c94308: adrp    x0, #0x6263000                             
02c9430c: ldr     x0, [x0, #0xa80]                           T:type24502(k1d)
02c94310: bl      #0x2b70db0                                 fn_2b70db0
02c94314: adrp    x0, #0x6265000                             
02c94318: ldr     x0, [x0, #0x798]                           S:'ShowBannerAd'
02c9431c: bl      #0x2b70db0                                 fn_2b70db0
02c94320: adrp    x0, #0x6265000                             
02c94324: ldr     x0, [x0, #0x730]                           S:'com.unity3d.player.UnityPlayer'
02c94328: bl      #0x2b70db0                                 fn_2b70db0
02c9432c: adrp    x0, #0x6263000                             
02c94330: ldr     x0, [x0, #0xa90]                           S:''
02c94334: bl      #0x2b70db0                                 fn_2b70db0
02c94338: adrp    x0, #0x6265000                             
02c9433c: ldr     x0, [x0, #0x738]                           S:'currentActivity'
02c94340: bl      #0x2b70db0                                 fn_2b70db0
02c94344: mov     w8, #1                                     
02c94348: strb    w8, [x22, #0x9e8]                          
02c9434c: ldr     x0, [x23]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c94350: ldr     w8, [x0, #0xe4]                            [62650e4]=0 f=0,0
02c94354: cbnz    w8, #0x2c9435c                             
02c94358: bl      #0x2b70f30                                 fn_2b70f30
02c9435c: mov     x0, xzr                                    
02c94360: bl      #0x5aeb18c                                 UnityEngine.Application::get_platform
02c94364: cmp     w0, #0xb                                   
02c94368: b.ne    #0x2c944ec                                 
02c9436c: adrp    x8, #0x6263000                             
02c94370: adrp    x22, #0x6265000                            
02c94374: ldr     x8, [x8, #0xc40]                           T:UnityEngine.AndroidJavaClass
02c94378: ldr     x22, [x22, #0x730]                         S:'com.unity3d.player.UnityPlayer'
02c9437c: ldr     x0, [x8]                                   &2c5bbd4(=a9bd7bfdd503233f)
02c94380: bl      #0x2b7104c                                 fn_2b7104c
02c94384: ldr     x1, [x22]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c94388: mov     x2, xzr                                    
02c9438c: mov     x22, x0                                    
02c94390: bl      #0x5ad2f6c                                 UnityEngine.AndroidJavaClass::.ctor
02c94394: cbz     x22, #0x2c94534                            
02c94398: adrp    x8, #0x6265000                             
02c9439c: adrp    x9, #0x6263000                             
02c943a0: mov     x0, x22                                    
02c943a4: ldr     x8, [x8, #0x738]                           S:'currentActivity'
02c943a8: ldr     x9, [x9, #0xc50]                           MS:UnityEngine.AndroidJavaObject::GetStatic
02c943ac: ldr     x1, [x8]                                   M:AdsManager::<OnApplicationPause>b__26_0
02c943b0: ldr     x2, [x9]                                   &2c5bbd4(=a9bd7bfdd503233f)
02c943b4: bl      #0x3121808                                 fn_3121808
02c943b8: adrp    x8, #0x6265000                             
02c943bc: mov     x23, x0                                    
02c943c0: ldr     x8, [x8, #0x740]                           T:AndroidOnFsnCompletedListener
02c943c4: ldr     x8, [x8]                                   M:AdsManager::<OnApplicationPause>b__26_0
02c943c8: mov     x0, x8                                     
02c943cc: bl      #0x2b7104c                                 fn_2b7104c
02c943d0: mov     x1, x21                                    
02c943d4: mov     x22, x0                                    
02c943d8: bl      #0x2c93874                                 AndroidOnFsnCompletedListener::.ctor
02c943dc: str     x22, [x19, #0x20]!                         .onFsnCompletedListener
02c943e0: mov     x0, x19                                    
02c943e4: mov     x1, x22                                    
02c943e8: bl      #0x2b70d54                                 fn_2b70d54
02c943ec: ldur    x21, [x19, #-0x10]                         
02c943f0: cbz     x21, #0x2c9451c                            
02c943f4: adrp    x8, #0x6263000                             
02c943f8: mov     w1, #3                                     
02c943fc: ldr     x8, [x8, #0xa80]                           T:type24502(k1d)
02c94400: ldr     x0, [x8]                                   &2c5bbd4(=a9bd7bfdd503233f)
02c94404: bl      #0x2b70ea0                                 fn_2b70ea0
02c94408: cbz     x0, #0x2c94534                             
02c9440c: mov     x22, x0                                    
02c94410: cbz     x23, #0x2c94428                            
02c94414: ldr     x8, [x22]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c94418: mov     x0, x23                                    
02c9441c: ldr     x1, [x8, #0x40]                            [6263040]=0 f=0,0
02c94420: bl      #0x2b70f34                                 fn_2b70f34
02c94424: cbz     x0, #0x2c94538                             
02c94428: ldr     w8, [x22, #0x18]                           T:AdsManager/<IEHideAdResume>d__30
02c9442c: cbz     w8, #0x2c94530                             
02c94430: mov     x0, x22                                    
02c94434: mov     x1, x23                                    
02c94438: and     w20, w20, #1                               
02c9443c: str     x23, [x0, #0x20]!                          .onFsnCompletedListener
02c94440: bl      #0x2b70d54                                 fn_2b70d54
02c94444: adrp    x8, #0x6263000                             
02c94448: add     x1, sp, #0xc                               
02c9444c: ldr     x8, [x8, #0x970]                           &6645c70(=0)
02c94450: strb    w20, [sp, #0xc]                            
02c94454: ldr     x0, [x8, #0x28]                            [6263028]=0 f=0,0
02c94458: bl      #0x2b70f38                                 fn_2b70f38
02c9445c: mov     x20, x0                                    
02c94460: cbz     x0, #0x2c94478                             
02c94464: ldr     x8, [x22]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c94468: mov     x0, x20                                    
02c9446c: ldr     x1, [x8, #0x40]                            [6263040]=0 f=0,0
02c94470: bl      #0x2b70f34                                 fn_2b70f34
02c94474: cbz     x0, #0x2c94538                             
02c94478: ldr     w8, [x22, #0x18]                           T:AdsManager/<IEHideAdResume>d__30
02c9447c: tst     w8, #0xfffffffe                            
02c94480: b.eq    #0x2c94530                                 
02c94484: mov     x0, x22                                    
02c94488: mov     x1, x20                                    
02c9448c: str     x20, [x0, #0x28]!                          
02c94490: bl      #0x2b70d54                                 fn_2b70d54
02c94494: ldr     x19, [x19]                                 
02c94498: cbz     x19, #0x2c944b0                            
02c9449c: ldr     x8, [x22]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c944a0: mov     x0, x19                                    
02c944a4: ldr     x1, [x8, #0x40]                            [6263040]=0 f=0,0
02c944a8: bl      #0x2b70f34                                 fn_2b70f34
02c944ac: cbz     x0, #0x2c94538                             
02c944b0: ldr     w8, [x22, #0x18]                           T:AdsManager/<IEHideAdResume>d__30
02c944b4: cmp     w8, #2                                     
02c944b8: b.ls    #0x2c94530                                 
02c944bc: mov     x0, x22                                    
02c944c0: mov     x1, x19                                    
02c944c4: str     x19, [x0, #0x30]!                          
02c944c8: bl      #0x2b70d54                                 fn_2b70d54
02c944cc: adrp    x8, #0x6265000                             
02c944d0: mov     x0, x21                                    
02c944d4: mov     x2, x22                                    
02c944d8: ldr     x8, [x8, #0x798]                           S:'ShowBannerAd'
02c944dc: mov     x3, xzr                                    
02c944e0: ldr     x1, [x8]                                   M:AdsManager::<OnApplicationPause>b__26_0
02c944e4: bl      #0x5ad5e34                                 UnityEngine.AndroidJavaObject::Call
02c944e8: b       #0x2c9451c                                 
02c944ec: cbz     x21, #0x2c9451c                            
02c944f0: adrp    x8, #0x6263000                             
02c944f4: ldr     x8, [x8, #0xa90]                           S:''
02c944f8: ldr     x0, [x21, #0x40]                           
02c944fc: ldr     x2, [x21, #0x28]                           
02c94500: ldr     x3, [x21, #0x18]                           .onFsnLoadListener
02c94504: ldp     x20, x19, [sp, #0x30]                      
02c94508: ldp     x22, x21, [sp, #0x20]                      
02c9450c: ldr     x1, [x8]                                   &2c5bbd4(=a9bd7bfdd503233f)
02c94510: ldp     x30, x23, [sp, #0x10]                      
02c94514: add     sp, sp, #0x40                              
02c94518: br      x3                                         
02c9451c: ldp     x20, x19, [sp, #0x30]                      
02c94520: ldp     x22, x21, [sp, #0x20]                      
02c94524: ldp     x30, x23, [sp, #0x10]                      
02c94528: add     sp, sp, #0x40                              
02c9452c: ret                                                
02c94530: bl      #0x2b71064                                 fn_2b71064
02c94534: bl      #0x2b7105c                                 fn_2b7105c
02c94538: bl      #0x2b71080                                 fn_2b71080
02c9453c: mov     x1, xzr                                    
02c94540: bl      #0x2b70f20                                 fn_2b70f20
## HideBannerAd() -> void
---- FsnBannerAd::HideBannerAd 0x2c94544
02c94544: stp     x30, x21, [sp, #-0x20]!                    
02c94548: stp     x20, x19, [sp, #0x10]                      
02c9454c: adrp    x20, #0x662f000                            
02c94550: adrp    x21, #0x6264000                            
02c94554: mov     x19, x0                                    
02c94558: ldrb    w8, [x20, #0x9e9]                          
02c9455c: ldr     x21, [x21, #0xa70]                         T:UnityEngine.Application
02c94560: tbnz    w8, #0, #0x2c94590                         
02c94564: adrp    x0, #0x6264000                             
02c94568: ldr     x0, [x0, #0xa70]                           T:UnityEngine.Application
02c9456c: bl      #0x2b70db0                                 fn_2b70db0
02c94570: adrp    x0, #0x6263000                             
02c94574: ldr     x0, [x0, #0xb70]                           MS:System.Array::Empty
02c94578: bl      #0x2b70db0                                 fn_2b70db0
02c9457c: adrp    x0, #0x6265000                             
02c94580: ldr     x0, [x0, #0x7a0]                           S:'HideBannerAd'
02c94584: bl      #0x2b70db0                                 fn_2b70db0
02c94588: mov     w8, #1                                     
02c9458c: strb    w8, [x20, #0x9e9]                          
02c94590: ldr     x0, [x21]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c94594: ldr     w8, [x0, #0xe4]                            [62650e4]=0 f=0,0
02c94598: cbnz    w8, #0x2c945a0                             
02c9459c: bl      #0x2b70f30                                 fn_2b70f30
02c945a0: mov     x0, xzr                                    
02c945a4: bl      #0x5aeb18c                                 UnityEngine.Application::get_platform
02c945a8: cmp     w0, #0xb                                   
02c945ac: b.ne    #0x2c94638                                 
02c945b0: ldr     x19, [x19, #0x10]                          .androidBannerAd
02c945b4: cbz     x19, #0x2c94638                            
02c945b8: adrp    x8, #0x6263000                             
02c945bc: ldr     x8, [x8, #0xb70]                           MS:System.Array::Empty
02c945c0: ldr     x20, [x8]                                  &2c5bbd4(=a9bd7bfdd503233f)
02c945c4: ldr     x8, [x20, #0x38]                           [662f038]=6000016 f=2.40742e-35,0
02c945c8: cbnz    x8, #0x2c945d8                             
02c945cc: mov     x0, x20                                    
02c945d0: bl      #0x2ba9d7c                                 fn_2ba9d7c
02c945d4: ldr     x8, [x20, #0x38]                           [662f038]=6000016 f=2.40742e-35,0
02c945d8: ldr     x0, [x8, #0x10]                            &2c498bc(=aa1f03e0d503245f)
02c945dc: add     x8, x0, #0x135                             &6265135
02c945e0: ldrh    w8, [x8]                                   
02c945e4: tbnz    w8, #0, #0x2c945ec                         
02c945e8: bl      #0x2ba9d20                                 fn_2ba9d20
02c945ec: ldr     w8, [x0, #0xe4]                            [62650e4]=0 f=0,0
02c945f0: cbnz    w8, #0x2c945f8                             
02c945f4: bl      #0x2b70f30                                 fn_2b70f30
02c945f8: ldr     x8, [x20, #0x38]                           [662f038]=6000016 f=2.40742e-35,0
02c945fc: ldr     x0, [x8, #0x10]                            &2c498bc(=aa1f03e0d503245f)
02c94600: add     x8, x0, #0x135                             &6265135
02c94604: ldrh    w8, [x8]                                   
02c94608: tbnz    w8, #0, #0x2c94610                         
02c9460c: bl      #0x2ba9d20                                 fn_2ba9d20
02c94610: adrp    x9, #0x6265000                             
02c94614: ldr     x8, [x0, #0xb8]                            T:AdsManager/<>c__DisplayClass42_0
02c94618: mov     x0, x19                                    
02c9461c: ldr     x9, [x9, #0x7a0]                           S:'HideBannerAd'
02c94620: ldp     x20, x19, [sp, #0x10]                      
02c94624: ldr     x2, [x8]                                   &2c5bbd4(=a9bd7bfdd503233f)
02c94628: mov     x3, xzr                                    
02c9462c: ldr     x1, [x9]                                   M:AdsManager::<OnApplicationPause>b__26_0
02c94630: ldp     x30, x21, [sp], #0x20                      
02c94634: b       #0x5ad5e34                                 UnityEngine.AndroidJavaObject::Call
02c94638: ldp     x20, x19, [sp, #0x10]                      
02c9463c: ldp     x30, x21, [sp], #0x20                      
02c94640: ret                                                
## IsBannerAdReady() -> bool
---- FsnBannerAd::IsBannerAdReady 0x2c94644
02c94644: stp     x30, x21, [sp, #-0x20]!                    
02c94648: stp     x20, x19, [sp, #0x10]                      
02c9464c: adrp    x20, #0x662f000                            
02c94650: mov     x19, x0                                    
02c94654: ldrb    w8, [x20, #0x9ea]                          
02c94658: tbnz    w8, #0, #0x2c94688                         
02c9465c: adrp    x0, #0x6265000                             
02c94660: ldr     x0, [x0, #0x760]                           MS:UnityEngine.AndroidJavaObject::Call
02c94664: bl      #0x2b70db0                                 fn_2b70db0
02c94668: adrp    x0, #0x6263000                             
02c9466c: ldr     x0, [x0, #0xb70]                           MS:System.Array::Empty
02c94670: bl      #0x2b70db0                                 fn_2b70db0
02c94674: adrp    x0, #0x6265000                             
02c94678: ldr     x0, [x0, #0x7a8]                           S:'IsBannerAdReady'
02c9467c: bl      #0x2b70db0                                 fn_2b70db0
02c94680: mov     w8, #1                                     
02c94684: strb    w8, [x20, #0x9ea]                          
02c94688: ldr     x19, [x19, #0x10]                          .androidBannerAd
02c9468c: cbz     x19, #0x2c94718                            
02c94690: adrp    x8, #0x6263000                             
02c94694: ldr     x8, [x8, #0xb70]                           MS:System.Array::Empty
02c94698: ldr     x20, [x8]                                  &2c5bbd4(=a9bd7bfdd503233f)
02c9469c: ldr     x8, [x20, #0x38]                           [662f038]=6000016 f=2.40742e-35,0
02c946a0: cbnz    x8, #0x2c946b0                             
02c946a4: mov     x0, x20                                    
02c946a8: bl      #0x2ba9d7c                                 fn_2ba9d7c
02c946ac: ldr     x8, [x20, #0x38]                           [662f038]=6000016 f=2.40742e-35,0
02c946b0: ldr     x0, [x8, #0x10]                            &2c498bc(=aa1f03e0d503245f)
02c946b4: add     x8, x0, #0x135                             &6265135
02c946b8: ldrh    w8, [x8]                                   
02c946bc: tbnz    w8, #0, #0x2c946c4                         
02c946c0: bl      #0x2ba9d20                                 fn_2ba9d20
02c946c4: ldr     w8, [x0, #0xe4]                            [62650e4]=0 f=0,0
02c946c8: cbnz    w8, #0x2c946d0                             
02c946cc: bl      #0x2b70f30                                 fn_2b70f30
02c946d0: ldr     x8, [x20, #0x38]                           [662f038]=6000016 f=2.40742e-35,0
02c946d4: adrp    x20, #0x6265000                            
02c946d8: adrp    x21, #0x6265000                            
02c946dc: ldr     x0, [x8, #0x10]                            &2c498bc(=aa1f03e0d503245f)
02c946e0: ldr     x20, [x20, #0x7a8]                         S:'IsBannerAdReady'
02c946e4: add     x8, x0, #0x135                             &6265135
02c946e8: ldrh    w8, [x8]                                   
02c946ec: ldr     x21, [x21, #0x760]                         MS:UnityEngine.AndroidJavaObject::Call
02c946f0: tbnz    w8, #0, #0x2c946f8                         
02c946f4: bl      #0x2ba9d20                                 fn_2ba9d20
02c946f8: ldr     x8, [x0, #0xb8]                            T:AdsManager/<>c__DisplayClass42_0
02c946fc: ldr     x1, [x20]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c94700: mov     x0, x19                                    
02c94704: ldp     x20, x19, [sp, #0x10]                      
02c94708: ldr     x3, [x21]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9470c: ldr     x2, [x8]                                   &2c5bbd4(=a9bd7bfdd503233f)
02c94710: ldp     x30, x21, [sp], #0x20                      
02c94714: b       #0x311f6d4                                 
02c94718: ldp     x20, x19, [sp, #0x10]                      
02c9471c: mov     w0, wzr                                    
02c94720: ldp     x30, x21, [sp], #0x20                      
02c94724: ret                                                
## IsAdLoading() -> bool
---- FsnBannerAd::IsAdLoading 0x2c94728
02c94728: stp     x30, x21, [sp, #-0x20]!                    
02c9472c: stp     x20, x19, [sp, #0x10]                      
02c94730: adrp    x20, #0x662f000                            
02c94734: mov     x19, x0                                    
02c94738: ldrb    w8, [x20, #0x9eb]                          
02c9473c: tbnz    w8, #0, #0x2c9476c                         
02c94740: adrp    x0, #0x6265000                             
02c94744: ldr     x0, [x0, #0x760]                           MS:UnityEngine.AndroidJavaObject::Call
02c94748: bl      #0x2b70db0                                 fn_2b70db0
02c9474c: adrp    x0, #0x6263000                             
02c94750: ldr     x0, [x0, #0xb70]                           MS:System.Array::Empty
02c94754: bl      #0x2b70db0                                 fn_2b70db0
02c94758: adrp    x0, #0x6265000                             
02c9475c: ldr     x0, [x0, #0x770]                           S:'IsAdLoading'
02c94760: bl      #0x2b70db0                                 fn_2b70db0
02c94764: mov     w8, #1                                     
02c94768: strb    w8, [x20, #0x9eb]                          
02c9476c: ldr     x19, [x19, #0x10]                          .androidBannerAd
02c94770: cbz     x19, #0x2c947fc                            
02c94774: adrp    x8, #0x6263000                             
02c94778: ldr     x8, [x8, #0xb70]                           MS:System.Array::Empty
02c9477c: ldr     x20, [x8]                                  &2c5bbd4(=a9bd7bfdd503233f)
02c94780: ldr     x8, [x20, #0x38]                           [662f038]=6000016 f=2.40742e-35,0
02c94784: cbnz    x8, #0x2c94794                             
02c94788: mov     x0, x20                                    
02c9478c: bl      #0x2ba9d7c                                 fn_2ba9d7c
02c94790: ldr     x8, [x20, #0x38]                           [662f038]=6000016 f=2.40742e-35,0
02c94794: ldr     x0, [x8, #0x10]                            &2c498bc(=aa1f03e0d503245f)
02c94798: add     x8, x0, #0x135                             &6265135
02c9479c: ldrh    w8, [x8]                                   
02c947a0: tbnz    w8, #0, #0x2c947a8                         
02c947a4: bl      #0x2ba9d20                                 fn_2ba9d20
02c947a8: ldr     w8, [x0, #0xe4]                            [62650e4]=0 f=0,0
02c947ac: cbnz    w8, #0x2c947b4                             
02c947b0: bl      #0x2b70f30                                 fn_2b70f30
02c947b4: ldr     x8, [x20, #0x38]                           [662f038]=6000016 f=2.40742e-35,0
02c947b8: adrp    x20, #0x6265000                            
02c947bc: adrp    x21, #0x6265000                            
02c947c0: ldr     x0, [x8, #0x10]                            &2c498bc(=aa1f03e0d503245f)
02c947c4: ldr     x20, [x20, #0x770]                         S:'IsAdLoading'
02c947c8: add     x8, x0, #0x135                             &6265135
02c947cc: ldrh    w8, [x8]                                   
02c947d0: ldr     x21, [x21, #0x760]                         MS:UnityEngine.AndroidJavaObject::Call
02c947d4: tbnz    w8, #0, #0x2c947dc                         
02c947d8: bl      #0x2ba9d20                                 fn_2ba9d20
02c947dc: ldr     x8, [x0, #0xb8]                            T:AdsManager/<>c__DisplayClass42_0
02c947e0: ldr     x1, [x20]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c947e4: mov     x0, x19                                    
02c947e8: ldp     x20, x19, [sp, #0x10]                      
02c947ec: ldr     x3, [x21]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c947f0: ldr     x2, [x8]                                   &2c5bbd4(=a9bd7bfdd503233f)
02c947f4: ldp     x30, x21, [sp], #0x20                      
02c947f8: b       #0x311f6d4                                 
02c947fc: ldp     x20, x19, [sp, #0x10]                      
02c94800: mov     w0, wzr                                    
02c94804: ldp     x30, x21, [sp], #0x20                      
02c94808: ret                                                
## Release() -> void
---- FsnBannerAd::Release 0x2c9480c
02c9480c: stp     x30, x21, [sp, #-0x20]!                    
02c94810: stp     x20, x19, [sp, #0x10]                      
02c94814: adrp    x20, #0x662f000                            
02c94818: adrp    x21, #0x6264000                            
02c9481c: mov     x19, x0                                    
02c94820: ldrb    w8, [x20, #0x9ec]                          
02c94824: ldr     x21, [x21, #0xa70]                         T:UnityEngine.Application
02c94828: tbnz    w8, #0, #0x2c94840                         
02c9482c: adrp    x0, #0x6264000                             
02c94830: ldr     x0, [x0, #0xa70]                           T:UnityEngine.Application
02c94834: bl      #0x2b70db0                                 fn_2b70db0
02c94838: mov     w8, #1                                     
02c9483c: strb    w8, [x20, #0x9ec]                          
02c94840: ldr     x0, [x21]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c94844: ldr     w8, [x0, #0xe4]                            [62640e4]=0 f=0,0
02c94848: cbnz    w8, #0x2c94850                             
02c9484c: bl      #0x2b70f30                                 fn_2b70f30
02c94850: mov     x0, xzr                                    
02c94854: bl      #0x5aeb18c                                 UnityEngine.Application::get_platform
02c94858: cmp     w0, #0xb                                   
02c9485c: b.ne    #0x2c94888                                 
02c94860: ldr     x0, [x19, #0x10]!                          .androidBannerAd
02c94864: cbz     x0, #0x2c94870                             
02c94868: mov     x1, xzr                                    
02c9486c: bl      #0x5ad5140                                 UnityEngine.AndroidJavaObject::Dispose
02c94870: mov     x0, x19                                    
02c94874: str     xzr, [x19]                                 
02c94878: mov     x1, xzr                                    
02c9487c: ldp     x20, x19, [sp, #0x10]                      
02c94880: ldp     x30, x21, [sp], #0x20                      
02c94884: b       #0x2b70d54                                 
02c94888: ldp     x20, x19, [sp, #0x10]                      
02c9488c: ldp     x30, x21, [sp], #0x20                      
02c94890: ret                                                
