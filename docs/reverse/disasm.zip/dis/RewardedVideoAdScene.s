#### CLASS RewardedVideoAdScene/<>c parent= object
#   field <>9                            RewardedVideoAdScene/<>c                           off=0x0 attr=36 
#   field <>9__5_2                       AudienceNetwork.FBRewardedVideoAdBridgeCallback    off=0x8 attr=16 
#   field <>9__5_3                       AudienceNetwork.FBRewardedVideoAdBridgeCallback    off=0x10 attr=16 
#   field <>9__5_4                       AudienceNetwork.FBRewardedVideoAdBridgeCallback    off=0x18 attr=16 
#   field <>9__5_5                       AudienceNetwork.FBRewardedVideoAdBridgeCallback    off=0x20 attr=16 
## .cctor() -> void
---- RewardedVideoAdScene/<>c::.cctor 0x2c860a0
02c860a0: str     x30, [sp, #-0x20]!                         
02c860a4: stp     x20, x19, [sp, #0x10]                      
02c860a8: adrp    x19, #0x662f000                            
02c860ac: adrp    x20, #0x6264000                            
02c860b0: ldrb    w8, [x19, #0x93f]                          
02c860b4: ldr     x20, [x20, #0xcd8]                         T:RewardedVideoAdScene/<>c
02c860b8: tbnz    w8, #0, #0x2c860d0                         
02c860bc: adrp    x0, #0x6264000                             
02c860c0: ldr     x0, [x0, #0xcd8]                           T:RewardedVideoAdScene/<>c
02c860c4: bl      #0x2b70db0                                 fn_2b70db0
02c860c8: mov     w8, #1                                     
02c860cc: strb    w8, [x19, #0x93f]                          
02c860d0: ldr     x0, [x20]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c860d4: bl      #0x2b7104c                                 fn_2b7104c
02c860d8: mov     x1, xzr                                    
02c860dc: mov     x19, x0                                    
02c860e0: bl      #0x4e53e9c                                 System.Object::.ctor
02c860e4: ldr     x8, [x20]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c860e8: mov     x1, x19                                    
02c860ec: ldr     x8, [x8, #0xb8]                            
02c860f0: str     x19, [x8]                                  
02c860f4: ldr     x8, [x20]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c860f8: ldp     x20, x19, [sp, #0x10]                      
02c860fc: ldr     x0, [x8, #0xb8]                            
02c86100: ldr     x30, [sp], #0x20                           
02c86104: b       #0x2b70d54                                 
## .ctor() -> void
---- RewardedVideoAdScene/<>c::.ctor 0x2c86108
02c86108: mov     x1, xzr                                    
02c8610c: b       #0x4e53e9c                                 System.Object::.ctor
## <LoadRewardedVideo>b__5_2() -> void
---- RewardedVideoAdScene/<>c::<LoadRewardedVideo>b__5_2 0x2c86110
02c86110: str     x30, [sp, #-0x20]!                         
02c86114: stp     x20, x19, [sp, #0x10]                      
02c86118: adrp    x20, #0x662f000                            
02c8611c: adrp    x19, #0x6263000                            
02c86120: ldrb    w8, [x20, #0x940]                          
02c86124: ldr     x19, [x19, #0x928]                         T:UnityEngine.Debug
02c86128: tbnz    w8, #0, #0x2c8614c                         
02c8612c: adrp    x0, #0x6263000                             
02c86130: ldr     x0, [x0, #0x928]                           T:UnityEngine.Debug
02c86134: bl      #0x2b70db0                                 fn_2b70db0
02c86138: adrp    x0, #0x6264000                             
02c8613c: ldr     x0, [x0, #0xd38]                           S:'RewardedVideo ad logged impression.'
02c86140: bl      #0x2b70db0                                 fn_2b70db0
02c86144: mov     w8, #1                                     
02c86148: strb    w8, [x20, #0x940]                          
02c8614c: ldr     x0, [x19]                                  &2c5bbd4(=a9bd7bfdd503233f)
02c86150: adrp    x19, #0x6264000                            
02c86154: ldr     w8, [x0, #0xe4]                            [62640e4]=0 f=0,0
02c86158: ldr     x19, [x19, #0xd38]                         S:'RewardedVideo ad logged impression.'
02c8615c: cbnz    w8, #0x2c86164                             
02c86160: bl      #0x2b70f30                                 fn_2b70f30
02c86164: ldr     x0, [x19]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c86168: ldp     x20, x19, [sp, #0x10]                      
02c8616c: mov     x1, xzr                                    
02c86170: ldr     x30, [sp], #0x20                           
02c86174: b       #0x5af21f4                                 UnityEngine.Debug::Log
## <LoadRewardedVideo>b__5_3() -> void
---- RewardedVideoAdScene/<>c::<LoadRewardedVideo>b__5_3 0x2c86178
02c86178: str     x30, [sp, #-0x20]!                         
02c8617c: stp     x20, x19, [sp, #0x10]                      
02c86180: adrp    x20, #0x662f000                            
02c86184: adrp    x19, #0x6263000                            
02c86188: ldrb    w8, [x20, #0x941]                          
02c8618c: ldr     x19, [x19, #0x928]                         T:UnityEngine.Debug
02c86190: tbnz    w8, #0, #0x2c861b4                         
02c86194: adrp    x0, #0x6263000                             
02c86198: ldr     x0, [x0, #0x928]                           T:UnityEngine.Debug
02c8619c: bl      #0x2b70db0                                 fn_2b70db0
02c861a0: adrp    x0, #0x6264000                             
02c861a4: ldr     x0, [x0, #0xd40]                           S:'RewardedVideo ad clicked.'
02c861a8: bl      #0x2b70db0                                 fn_2b70db0
02c861ac: mov     w8, #1                                     
02c861b0: strb    w8, [x20, #0x941]                          
02c861b4: ldr     x0, [x19]                                  &2c5bbd4(=a9bd7bfdd503233f)
02c861b8: adrp    x19, #0x6264000                            
02c861bc: ldr     w8, [x0, #0xe4]                            [62640e4]=0 f=0,0
02c861c0: ldr     x19, [x19, #0xd40]                         S:'RewardedVideo ad clicked.'
02c861c4: cbnz    w8, #0x2c861cc                             
02c861c8: bl      #0x2b70f30                                 fn_2b70f30
02c861cc: ldr     x0, [x19]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c861d0: ldp     x20, x19, [sp, #0x10]                      
02c861d4: mov     x1, xzr                                    
02c861d8: ldr     x30, [sp], #0x20                           
02c861dc: b       #0x5af21f4                                 UnityEngine.Debug::Log
## <LoadRewardedVideo>b__5_4() -> void
---- RewardedVideoAdScene/<>c::<LoadRewardedVideo>b__5_4 0x2c861e0
02c861e0: str     x30, [sp, #-0x20]!                         
02c861e4: stp     x20, x19, [sp, #0x10]                      
02c861e8: adrp    x20, #0x662f000                            
02c861ec: adrp    x19, #0x6263000                            
02c861f0: ldrb    w8, [x20, #0x942]                          
02c861f4: ldr     x19, [x19, #0x928]                         T:UnityEngine.Debug
02c861f8: tbnz    w8, #0, #0x2c8621c                         
02c861fc: adrp    x0, #0x6263000                             
02c86200: ldr     x0, [x0, #0x928]                           T:UnityEngine.Debug
02c86204: bl      #0x2b70db0                                 fn_2b70db0
02c86208: adrp    x0, #0x6264000                             
02c8620c: ldr     x0, [x0, #0xd48]                           S:'Rewarded video ad validated by server'
02c86210: bl      #0x2b70db0                                 fn_2b70db0
02c86214: mov     w8, #1                                     
02c86218: strb    w8, [x20, #0x942]                          
02c8621c: ldr     x0, [x19]                                  &2c5bbd4(=a9bd7bfdd503233f)
02c86220: adrp    x19, #0x6264000                            
02c86224: ldr     w8, [x0, #0xe4]                            [62640e4]=0 f=0,0
02c86228: ldr     x19, [x19, #0xd48]                         S:'Rewarded video ad validated by server'
02c8622c: cbnz    w8, #0x2c86234                             
02c86230: bl      #0x2b70f30                                 fn_2b70f30
02c86234: ldr     x0, [x19]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c86238: ldp     x20, x19, [sp, #0x10]                      
02c8623c: mov     x1, xzr                                    
02c86240: ldr     x30, [sp], #0x20                           
02c86244: b       #0x5af21f4                                 UnityEngine.Debug::Log
## <LoadRewardedVideo>b__5_5() -> void
---- RewardedVideoAdScene/<>c::<LoadRewardedVideo>b__5_5 0x2c86248
02c86248: str     x30, [sp, #-0x20]!                         
02c8624c: stp     x20, x19, [sp, #0x10]                      
02c86250: adrp    x20, #0x662f000                            
02c86254: adrp    x19, #0x6263000                            
02c86258: ldrb    w8, [x20, #0x943]                          
02c8625c: ldr     x19, [x19, #0x928]                         T:UnityEngine.Debug
02c86260: tbnz    w8, #0, #0x2c86284                         
02c86264: adrp    x0, #0x6263000                             
02c86268: ldr     x0, [x0, #0x928]                           T:UnityEngine.Debug
02c8626c: bl      #0x2b70db0                                 fn_2b70db0
02c86270: adrp    x0, #0x6264000                             
02c86274: ldr     x0, [x0, #0xd50]                           S:'Rewarded video ad not validated, or no response from server'
02c86278: bl      #0x2b70db0                                 fn_2b70db0
02c8627c: mov     w8, #1                                     
02c86280: strb    w8, [x20, #0x943]                          
02c86284: ldr     x0, [x19]                                  &2c5bbd4(=a9bd7bfdd503233f)
02c86288: adrp    x19, #0x6264000                            
02c8628c: ldr     w8, [x0, #0xe4]                            [62640e4]=0 f=0,0
02c86290: ldr     x19, [x19, #0xd50]                         S:'Rewarded video ad not validated, or no response from server'
02c86294: cbnz    w8, #0x2c8629c                             
02c86298: bl      #0x2b70f30                                 fn_2b70f30
02c8629c: ldr     x0, [x19]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c862a0: ldp     x20, x19, [sp, #0x10]                      
02c862a4: mov     x1, xzr                                    
02c862a8: ldr     x30, [sp], #0x20                           
02c862ac: b       #0x5af21f4                                 UnityEngine.Debug::Log
#### CLASS RewardedVideoAdScene parent= BaseScene
#   field rewardedVideoAd                AudienceNetwork.RewardedVideoAd                    off=0x20 attr=1 
#   field isLoaded                       bool                                               off=0x28 attr=1 
#   field didClose                       bool                                               off=0x29 attr=1 
#   field statusLabel                    UnityEngine.UI.Text                                off=0x30 attr=6 
## Awake() -> void
---- RewardedVideoAdScene::Awake 0x2c8568c
02c8568c: str     x30, [sp, #-0x20]!                         
02c85690: stp     x20, x19, [sp, #0x10]                      
02c85694: adrp    x20, #0x662f000                            
02c85698: adrp    x19, #0x6264000                            
02c8569c: ldrb    w8, [x20, #0x936]                          
02c856a0: ldr     x19, [x19, #0xae8]                         T:SettingsScene
02c856a4: tbnz    w8, #0, #0x2c856bc                         
02c856a8: adrp    x0, #0x6264000                             
02c856ac: ldr     x0, [x0, #0xae8]                           T:SettingsScene
02c856b0: bl      #0x2b70db0                                 fn_2b70db0
02c856b4: mov     w8, #1                                     
02c856b8: strb    w8, [x20, #0x936]                          
02c856bc: mov     x0, xzr                                    
02c856c0: bl      #0x2ccc9d4                                 AudienceNetwork.AudienceNetworkAds::Initialize
02c856c4: ldr     x0, [x19]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c856c8: ldr     w8, [x0, #0xe4]                            [62640e4]=0 f=0,0
02c856cc: cbnz    w8, #0x2c856d4                             
02c856d0: bl      #0x2b70f30                                 fn_2b70f30
02c856d4: ldp     x20, x19, [sp, #0x10]                      
02c856d8: ldr     x30, [sp], #0x20                           
02c856dc: b       #0x2c84340                                 SettingsScene::InitializeSettings
## LoadRewardedVideo() -> void
---- RewardedVideoAdScene::LoadRewardedVideo 0x2c856e0
02c856e0: stp     x30, x25, [sp, #-0x40]!                    
02c856e4: stp     x24, x23, [sp, #0x10]                      
02c856e8: stp     x22, x21, [sp, #0x20]                      
02c856ec: stp     x20, x19, [sp, #0x30]                      
02c856f0: adrp    x20, #0x662f000                            
02c856f4: mov     x19, x0                                    
02c856f8: ldrb    w8, [x20, #0x937]                          
02c856fc: tbnz    w8, #0, #0x2c857d4                         
02c85700: adrp    x0, #0x6264000                             
02c85704: ldr     x0, [x0, #0xc78]                           T:AudienceNetwork.FBRewardedVideoAdBridgeCallback
02c85708: bl      #0x2b70db0                                 fn_2b70db0
02c8570c: adrp    x0, #0x6264000                             
02c85710: ldr     x0, [x0, #0xc80]                           T:AudienceNetwork.FBRewardedVideoAdBridgeErrorCallback
02c85714: bl      #0x2b70db0                                 fn_2b70db0
02c85718: adrp    x0, #0x6264000                             
02c8571c: ldr     x0, [x0, #0xc88]                           T:AudienceNetwork.RewardData
02c85720: bl      #0x2b70db0                                 fn_2b70db0
02c85724: adrp    x0, #0x6264000                             
02c85728: ldr     x0, [x0, #0xc90]                           M:RewardedVideoAdScene::<LoadRewardedVideo>b__5_0
02c8572c: bl      #0x2b70db0                                 fn_2b70db0
02c85730: adrp    x0, #0x6264000                             
02c85734: ldr     x0, [x0, #0xc98]                           M:RewardedVideoAdScene::<LoadRewardedVideo>b__5_1
02c85738: bl      #0x2b70db0                                 fn_2b70db0
02c8573c: adrp    x0, #0x6264000                             
02c85740: ldr     x0, [x0, #0xca0]                           M:RewardedVideoAdScene::<LoadRewardedVideo>b__5_6
02c85744: bl      #0x2b70db0                                 fn_2b70db0
02c85748: adrp    x0, #0x6264000                             
02c8574c: ldr     x0, [x0, #0xca8]                           M:RewardedVideoAdScene::<LoadRewardedVideo>b__5_7
02c85750: bl      #0x2b70db0                                 fn_2b70db0
02c85754: adrp    x0, #0x6264000                             
02c85758: ldr     x0, [x0, #0xcb0]                           T:AudienceNetwork.RewardedVideoAd
02c8575c: bl      #0x2b70db0                                 fn_2b70db0
02c85760: adrp    x0, #0x6264000                             
02c85764: ldr     x0, [x0, #0xcb8]                           M:RewardedVideoAdScene/<>c::<LoadRewardedVideo>b__5_2
02c85768: bl      #0x2b70db0                                 fn_2b70db0
02c8576c: adrp    x0, #0x6264000                             
02c85770: ldr     x0, [x0, #0xcc0]                           M:RewardedVideoAdScene/<>c::<LoadRewardedVideo>b__5_3
02c85774: bl      #0x2b70db0                                 fn_2b70db0
02c85778: adrp    x0, #0x6264000                             
02c8577c: ldr     x0, [x0, #0xcc8]                           M:RewardedVideoAdScene/<>c::<LoadRewardedVideo>b__5_4
02c85780: bl      #0x2b70db0                                 fn_2b70db0
02c85784: adrp    x0, #0x6264000                             
02c85788: ldr     x0, [x0, #0xcd0]                           M:RewardedVideoAdScene/<>c::<LoadRewardedVideo>b__5_5
02c8578c: bl      #0x2b70db0                                 fn_2b70db0
02c85790: adrp    x0, #0x6264000                             
02c85794: ldr     x0, [x0, #0xcd8]                           T:RewardedVideoAdScene/<>c
02c85798: bl      #0x2b70db0                                 fn_2b70db0
02c8579c: adrp    x0, #0x6264000                             
02c857a0: ldr     x0, [x0, #0xb50]                           S:'YOUR_PLACEMENT_ID'
02c857a4: bl      #0x2b70db0                                 fn_2b70db0
02c857a8: adrp    x0, #0x6264000                             
02c857ac: ldr     x0, [x0, #0xce0]                           S:'REWARD_ID'
02c857b0: bl      #0x2b70db0                                 fn_2b70db0
02c857b4: adrp    x0, #0x6264000                             
02c857b8: ldr     x0, [x0, #0xce8]                           S:'USER_ID'
02c857bc: bl      #0x2b70db0                                 fn_2b70db0
02c857c0: adrp    x0, #0x6264000                             
02c857c4: ldr     x0, [x0, #0xcf0]                           S:'Loading rewardedVideo ad...'
02c857c8: bl      #0x2b70db0                                 fn_2b70db0
02c857cc: mov     w8, #1                                     
02c857d0: strb    w8, [x20, #0x937]                          
02c857d4: ldr     x0, [x19, #0x30]                           .statusLabel
02c857d8: cbz     x0, #0x2c85c08                             
02c857dc: adrp    x8, #0x6264000                             
02c857e0: adrp    x23, #0x6264000                            
02c857e4: adrp    x22, #0x6264000                            
02c857e8: ldr     x8, [x8, #0xcf0]                           S:'Loading rewardedVideo ad...'
02c857ec: ldr     x23, [x23, #0xcb0]                         T:AudienceNetwork.RewardedVideoAd
02c857f0: ldr     x22, [x22, #0xb50]                         S:'YOUR_PLACEMENT_ID'
02c857f4: ldr     x9, [x0]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c857f8: adrp    x24, #0x6264000                            
02c857fc: ldr     x24, [x24, #0xc88]                         T:AudienceNetwork.RewardData
02c85800: ldr     x1, [x8]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c85804: ldr     x8, [x9, #0x5e8]                           
02c85808: ldr     x2, [x9, #0x5f0]                           
02c8580c: blr     x8                                         
02c85810: ldr     x0, [x23]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c85814: bl      #0x2b7104c                                 fn_2b7104c
02c85818: ldr     x1, [x22]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c8581c: mov     x2, xzr                                    
02c85820: mov     x21, x0                                    
02c85824: bl      #0x2cd18f4                                 AudienceNetwork.RewardedVideoAd::.ctor
02c85828: mov     x20, x19                                   
02c8582c: mov     x1, x21                                    
02c85830: str     x21, [x20, #0x20]!                         .rewardedVideoAd
02c85834: mov     x0, x20                                    
02c85838: bl      #0x2b70d54                                 fn_2b70d54
02c8583c: ldr     x0, [x24]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c85840: bl      #0x2b7104c                                 fn_2b7104c
02c85844: mov     x1, xzr                                    
02c85848: mov     x21, x0                                    
02c8584c: bl      #0x2cd0ea4                                 AudienceNetwork.RewardData::.ctor
02c85850: cbz     x21, #0x2c85c08                            
02c85854: adrp    x8, #0x6264000                             
02c85858: adrp    x24, #0x6264000                            
02c8585c: mov     x0, x21                                    
02c85860: ldr     x8, [x8, #0xce8]                           S:'USER_ID'
02c85864: ldr     x1, [x8]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c85868: ldr     x24, [x24, #0xce0]                         S:'REWARD_ID'
02c8586c: str     x1, [x0, #0x10]!                           
02c85870: bl      #0x2b70d54                                 fn_2b70d54
02c85874: ldr     x1, [x24]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c85878: mov     x0, x21                                    
02c8587c: str     x1, [x0, #0x18]!                           
02c85880: bl      #0x2b70d54                                 fn_2b70d54
02c85884: ldr     x0, [x23]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c85888: bl      #0x2b7104c                                 fn_2b7104c
02c8588c: ldr     x1, [x22]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c85890: mov     x2, x21                                    
02c85894: mov     x3, xzr                                    
02c85898: bl      #0x2cd18fc                                 AudienceNetwork.RewardedVideoAd::.ctor
02c8589c: ldr     x21, [x19, #0x20]                          .rewardedVideoAd
02c858a0: mov     x0, x19                                    
02c858a4: mov     x1, xzr                                    
02c858a8: bl      #0x5b339ec                                 UnityEngine.Component::get_gameObject
02c858ac: cbz     x21, #0x2c85c08                            
02c858b0: adrp    x24, #0x6264000                            
02c858b4: adrp    x22, #0x6264000                            
02c858b8: mov     x1, x0                                     
02c858bc: ldr     x24, [x24, #0xc78]                         T:AudienceNetwork.FBRewardedVideoAdBridgeCallback
02c858c0: ldr     x22, [x22, #0xc90]                         M:RewardedVideoAdScene::<LoadRewardedVideo>b__5_0
02c858c4: mov     x0, x21                                    
02c858c8: mov     x2, xzr                                    
02c858cc: bl      #0x2cd2480                                 AudienceNetwork.RewardedVideoAd::Register
02c858d0: ldr     x0, [x24]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c858d4: ldr     x21, [x19, #0x20]                          .rewardedVideoAd
02c858d8: bl      #0x2b7104c                                 fn_2b7104c
02c858dc: ldr     x2, [x22]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c858e0: mov     x1, x19                                    
02c858e4: mov     x3, xzr                                    
02c858e8: mov     x22, x0                                    
02c858ec: bl      #0x2cd0a70                                 AudienceNetwork.FBRewardedVideoAdBridgeCallback::.ctor
02c858f0: cbz     x21, #0x2c85c08                            
02c858f4: adrp    x23, #0x6264000                            
02c858f8: adrp    x25, #0x6264000                            
02c858fc: mov     x0, x21                                    
02c85900: ldr     x23, [x23, #0xc80]                         T:AudienceNetwork.FBRewardedVideoAdBridgeErrorCallback
02c85904: ldr     x25, [x25, #0xc98]                         M:RewardedVideoAdScene::<LoadRewardedVideo>b__5_1
02c85908: mov     x1, x22                                    
02c8590c: mov     x2, xzr                                    
02c85910: bl      #0x2cd0ed4                                 AudienceNetwork.RewardedVideoAd::set_RewardedVideoAdDidLoad
02c85914: ldr     x0, [x23]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c85918: ldr     x21, [x19, #0x20]                          .rewardedVideoAd
02c8591c: bl      #0x2b7104c                                 fn_2b7104c
02c85920: ldr     x2, [x25]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c85924: mov     x1, x19                                    
02c85928: mov     x3, xzr                                    
02c8592c: mov     x22, x0                                    
02c85930: bl      #0x2cd0b48                                 AudienceNetwork.FBRewardedVideoAdBridgeErrorCallback::.ctor
02c85934: cbz     x21, #0x2c85c08                            
02c85938: adrp    x25, #0x6264000                            
02c8593c: mov     x0, x21                                    
02c85940: mov     x1, x22                                    
02c85944: ldr     x25, [x25, #0xcd8]                         T:RewardedVideoAdScene/<>c
02c85948: mov     x2, xzr                                    
02c8594c: bl      #0x2cd10dc                                 AudienceNetwork.RewardedVideoAd::set_RewardedVideoAdDidFailWithError
02c85950: ldr     x0, [x25]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c85954: ldr     x21, [x20]                                 &2b706c4(=eb01011ff9400808)
02c85958: ldr     w8, [x0, #0xe4]                            [62640e4]=0 f=0,0
02c8595c: cbnz    w8, #0x2c85968                             
02c85960: bl      #0x2b70f30                                 fn_2b70f30
02c85964: ldr     x0, [x25]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c85968: ldr     x8, [x0, #0xb8]                            MS:DG.Tweening.Core.Extensions::SetSpecialStartupMode
02c8596c: ldr     x22, [x8, #8]                              T:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass2_0
02c85970: cbnz    x22, #0x2c859c4                            
02c85974: ldr     w9, [x0, #0xe4]                            [62640e4]=0 f=0,0
02c85978: cbnz    w9, #0x2c85988                             
02c8597c: bl      #0x2b70f30                                 fn_2b70f30
02c85980: ldr     x8, [x25]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c85984: ldr     x8, [x8, #0xb8]                            MS:DG.Tweening.Core.Extensions::SetSpecialStartupMode
02c85988: ldr     x0, [x24]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c8598c: ldr     x23, [x8]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c85990: bl      #0x2b7104c                                 fn_2b7104c
02c85994: adrp    x8, #0x6264000                             
02c85998: mov     x1, x23                                    
02c8599c: mov     x3, xzr                                    
02c859a0: ldr     x8, [x8, #0xcb8]                           M:RewardedVideoAdScene/<>c::<LoadRewardedVideo>b__5_2
02c859a4: mov     x22, x0                                    
02c859a8: ldr     x2, [x8]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c859ac: bl      #0x2cd0a70                                 AudienceNetwork.FBRewardedVideoAdBridgeCallback::.ctor
02c859b0: ldr     x8, [x25]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c859b4: mov     x1, x22                                    
02c859b8: ldr     x0, [x8, #0xb8]                            MS:DG.Tweening.Core.Extensions::SetSpecialStartupMode
02c859bc: str     x22, [x0, #8]!                             
02c859c0: bl      #0x2b70d54                                 fn_2b70d54
02c859c4: cbz     x21, #0x2c85c08                            
02c859c8: mov     x0, x21                                    
02c859cc: mov     x1, x22                                    
02c859d0: mov     x2, xzr                                    
02c859d4: bl      #0x2cd0fd8                                 AudienceNetwork.RewardedVideoAd::set_RewardedVideoAdWillLogImpression
02c859d8: ldr     x0, [x25]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c859dc: ldr     x21, [x20]                                 &2b706c4(=eb01011ff9400808)
02c859e0: ldr     w8, [x0, #0xe4]                            [62640e4]=0 f=0,0
02c859e4: cbnz    w8, #0x2c859f0                             
02c859e8: bl      #0x2b70f30                                 fn_2b70f30
02c859ec: ldr     x0, [x25]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c859f0: ldr     x8, [x0, #0xb8]                            MS:DG.Tweening.Core.Extensions::SetSpecialStartupMode
02c859f4: ldr     x22, [x8, #0x10]                           M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass2_0::<DOSetFloat>b__0
02c859f8: cbnz    x22, #0x2c85a4c                            
02c859fc: ldr     w9, [x0, #0xe4]                            [62640e4]=0 f=0,0
02c85a00: cbnz    w9, #0x2c85a10                             
02c85a04: bl      #0x2b70f30                                 fn_2b70f30
02c85a08: ldr     x8, [x25]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c85a0c: ldr     x8, [x8, #0xb8]                            MS:DG.Tweening.Core.Extensions::SetSpecialStartupMode
02c85a10: ldr     x0, [x24]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c85a14: ldr     x23, [x8]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c85a18: bl      #0x2b7104c                                 fn_2b7104c
02c85a1c: adrp    x8, #0x6264000                             
02c85a20: mov     x1, x23                                    
02c85a24: mov     x3, xzr                                    
02c85a28: ldr     x8, [x8, #0xcc0]                           M:RewardedVideoAdScene/<>c::<LoadRewardedVideo>b__5_3
02c85a2c: mov     x22, x0                                    
02c85a30: ldr     x2, [x8]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c85a34: bl      #0x2cd0a70                                 AudienceNetwork.FBRewardedVideoAdBridgeCallback::.ctor
02c85a38: ldr     x8, [x25]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c85a3c: mov     x1, x22                                    
02c85a40: ldr     x0, [x8, #0xb8]                            MS:DG.Tweening.Core.Extensions::SetSpecialStartupMode
02c85a44: str     x22, [x0, #0x10]!                          
02c85a48: bl      #0x2b70d54                                 fn_2b70d54
02c85a4c: cbz     x21, #0x2c85c08                            
02c85a50: mov     x0, x21                                    
02c85a54: mov     x1, x22                                    
02c85a58: mov     x2, xzr                                    
02c85a5c: bl      #0x2cd11e0                                 AudienceNetwork.RewardedVideoAd::set_RewardedVideoAdDidClick
02c85a60: ldr     x0, [x25]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c85a64: ldr     x21, [x20]                                 &2b706c4(=eb01011ff9400808)
02c85a68: ldr     w8, [x0, #0xe4]                            [62640e4]=0 f=0,0
02c85a6c: cbnz    w8, #0x2c85a78                             
02c85a70: bl      #0x2b70f30                                 fn_2b70f30
02c85a74: ldr     x0, [x25]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c85a78: ldr     x8, [x0, #0xb8]                            MS:DG.Tweening.Core.Extensions::SetSpecialStartupMode
02c85a7c: ldr     x22, [x8, #0x18]                           M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass2_0::<DOSetFloat>b__1
02c85a80: cbnz    x22, #0x2c85ad4                            
02c85a84: ldr     w9, [x0, #0xe4]                            [62640e4]=0 f=0,0
02c85a88: cbnz    w9, #0x2c85a98                             
02c85a8c: bl      #0x2b70f30                                 fn_2b70f30
02c85a90: ldr     x8, [x25]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c85a94: ldr     x8, [x8, #0xb8]                            MS:DG.Tweening.Core.Extensions::SetSpecialStartupMode
02c85a98: ldr     x0, [x24]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c85a9c: ldr     x23, [x8]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c85aa0: bl      #0x2b7104c                                 fn_2b7104c
02c85aa4: adrp    x8, #0x6264000                             
02c85aa8: mov     x1, x23                                    
02c85aac: mov     x3, xzr                                    
02c85ab0: ldr     x8, [x8, #0xcc8]                           M:RewardedVideoAdScene/<>c::<LoadRewardedVideo>b__5_4
02c85ab4: mov     x22, x0                                    
02c85ab8: ldr     x2, [x8]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c85abc: bl      #0x2cd0a70                                 AudienceNetwork.FBRewardedVideoAdBridgeCallback::.ctor
02c85ac0: ldr     x8, [x25]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c85ac4: mov     x1, x22                                    
02c85ac8: ldr     x0, [x8, #0xb8]                            MS:DG.Tweening.Core.Extensions::SetSpecialStartupMode
02c85acc: str     x22, [x0, #0x18]!                          
02c85ad0: bl      #0x2b70d54                                 fn_2b70d54
02c85ad4: cbz     x21, #0x2c85c08                            
02c85ad8: mov     x0, x21                                    
02c85adc: mov     x1, x22                                    
02c85ae0: mov     x2, xzr                                    
02c85ae4: bl      #0x2cd15f0                                 AudienceNetwork.RewardedVideoAd::set_RewardedVideoAdDidSucceed
02c85ae8: ldr     x0, [x25]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c85aec: ldr     x21, [x20]                                 &2b706c4(=eb01011ff9400808)
02c85af0: ldr     w8, [x0, #0xe4]                            [62640e4]=0 f=0,0
02c85af4: cbnz    w8, #0x2c85b00                             
02c85af8: bl      #0x2b70f30                                 fn_2b70f30
02c85afc: ldr     x0, [x25]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c85b00: ldr     x8, [x0, #0xb8]                            MS:DG.Tweening.Core.Extensions::SetSpecialStartupMode
02c85b04: ldr     x22, [x8, #0x20]                           T:DG.Tweening.DOTweenModulePhysics/<>c__DisplayClass0_0
02c85b08: cbnz    x22, #0x2c85b5c                            
02c85b0c: ldr     w9, [x0, #0xe4]                            [62640e4]=0 f=0,0
02c85b10: cbnz    w9, #0x2c85b20                             
02c85b14: bl      #0x2b70f30                                 fn_2b70f30
02c85b18: ldr     x8, [x25]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c85b1c: ldr     x8, [x8, #0xb8]                            MS:DG.Tweening.Core.Extensions::SetSpecialStartupMode
02c85b20: ldr     x0, [x24]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c85b24: ldr     x23, [x8]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c85b28: bl      #0x2b7104c                                 fn_2b7104c
02c85b2c: adrp    x8, #0x6264000                             
02c85b30: mov     x1, x23                                    
02c85b34: mov     x3, xzr                                    
02c85b38: ldr     x8, [x8, #0xcd0]                           M:RewardedVideoAdScene/<>c::<LoadRewardedVideo>b__5_5
02c85b3c: mov     x22, x0                                    
02c85b40: ldr     x2, [x8]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c85b44: bl      #0x2cd0a70                                 AudienceNetwork.FBRewardedVideoAdBridgeCallback::.ctor
02c85b48: ldr     x8, [x25]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c85b4c: mov     x1, x22                                    
02c85b50: ldr     x0, [x8, #0xb8]                            MS:DG.Tweening.Core.Extensions::SetSpecialStartupMode
02c85b54: str     x22, [x0, #0x20]!                          .rewardedVideoAd
02c85b58: bl      #0x2b70d54                                 fn_2b70d54
02c85b5c: cbz     x21, #0x2c85c08                            
02c85b60: adrp    x23, #0x6264000                            
02c85b64: mov     x0, x21                                    
02c85b68: mov     x1, x22                                    
02c85b6c: ldr     x23, [x23, #0xca0]                         M:RewardedVideoAdScene::<LoadRewardedVideo>b__5_6
02c85b70: mov     x2, xzr                                    
02c85b74: bl      #0x2cd16f4                                 AudienceNetwork.RewardedVideoAd::set_RewardedVideoAdDidFail
02c85b78: ldr     x0, [x24]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c85b7c: ldr     x21, [x19, #0x20]                          .rewardedVideoAd
02c85b80: bl      #0x2b7104c                                 fn_2b7104c
02c85b84: ldr     x2, [x23]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c85b88: mov     x1, x19                                    
02c85b8c: mov     x3, xzr                                    
02c85b90: mov     x22, x0                                    
02c85b94: bl      #0x2cd0a70                                 AudienceNetwork.FBRewardedVideoAdBridgeCallback::.ctor
02c85b98: cbz     x21, #0x2c85c08                            
02c85b9c: adrp    x23, #0x6264000                            
02c85ba0: mov     x0, x21                                    
02c85ba4: mov     x1, x22                                    
02c85ba8: ldr     x23, [x23, #0xca8]                         M:RewardedVideoAdScene::<LoadRewardedVideo>b__5_7
02c85bac: mov     x2, xzr                                    
02c85bb0: bl      #0x2cd13e8                                 AudienceNetwork.RewardedVideoAd::set_RewardedVideoAdDidClose
02c85bb4: ldr     x0, [x24]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c85bb8: ldr     x21, [x19, #0x20]                          .rewardedVideoAd
02c85bbc: bl      #0x2b7104c                                 fn_2b7104c
02c85bc0: ldr     x2, [x23]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c85bc4: mov     x1, x19                                    
02c85bc8: mov     x3, xzr                                    
02c85bcc: mov     x22, x0                                    
02c85bd0: bl      #0x2cd0a70                                 AudienceNetwork.FBRewardedVideoAdBridgeCallback::.ctor
02c85bd4: cbz     x21, #0x2c85c08                            
02c85bd8: mov     x0, x21                                    
02c85bdc: mov     x1, x22                                    
02c85be0: mov     x2, xzr                                    
02c85be4: bl      #0x2cd17f8                                 AudienceNetwork.RewardedVideoAd::set_RewardedVideoAdActivityDestroyed
02c85be8: ldr     x0, [x20]                                  &2b706c4(=eb01011ff9400808)
02c85bec: cbz     x0, #0x2c85c08                             
02c85bf0: ldp     x20, x19, [sp, #0x30]                      
02c85bf4: mov     x1, xzr                                    
02c85bf8: ldp     x22, x21, [sp, #0x20]                      
02c85bfc: ldp     x24, x23, [sp, #0x10]                      
02c85c00: ldp     x30, x25, [sp], #0x40                      
02c85c04: b       #0x2cd24e4                                 AudienceNetwork.RewardedVideoAd::LoadAd
02c85c08: bl      #0x2b7105c                                 fn_2b7105c
## ShowRewardedVideo() -> void
---- RewardedVideoAdScene::ShowRewardedVideo 0x2c85c0c
02c85c0c: str     x30, [sp, #-0x20]!                         
02c85c10: stp     x20, x19, [sp, #0x10]                      
02c85c14: adrp    x20, #0x662f000                            
02c85c18: mov     x19, x0                                    
02c85c1c: ldrb    w8, [x20, #0x938]                          
02c85c20: tbnz    w8, #0, #0x2c85c44                         
02c85c24: adrp    x0, #0x6264000                             
02c85c28: ldr     x0, [x0, #0xc10]                           S:'Ad not loaded. Click load to request an ad.'
02c85c2c: bl      #0x2b70db0                                 fn_2b70db0
02c85c30: adrp    x0, #0x6263000                             
02c85c34: ldr     x0, [x0, #0xa90]                           S:''
02c85c38: bl      #0x2b70db0                                 fn_2b70db0
02c85c3c: mov     w8, #1                                     
02c85c40: strb    w8, [x20, #0x938]                          
02c85c44: ldrb    w8, [x19, #0x28]                           .isLoaded
02c85c48: cbz     w8, #0x2c85c74                             
02c85c4c: ldr     x0, [x19, #0x20]                           .rewardedVideoAd
02c85c50: cbz     x0, #0x2c85ca0                             
02c85c54: mov     x1, xzr                                    
02c85c58: bl      #0x2cd2914                                 AudienceNetwork.RewardedVideoAd::Show
02c85c5c: ldr     x0, [x19, #0x30]                           .statusLabel
02c85c60: strb    wzr, [x19, #0x28]                          .isLoaded
02c85c64: cbz     x0, #0x2c85ca0                             
02c85c68: adrp    x8, #0x6263000                             
02c85c6c: ldr     x8, [x8, #0xa90]                           S:''
02c85c70: b       #0x2c85c84                                 
02c85c74: ldr     x0, [x19, #0x30]                           .statusLabel
02c85c78: cbz     x0, #0x2c85ca0                             
02c85c7c: adrp    x8, #0x6264000                             
02c85c80: ldr     x8, [x8, #0xc10]                           S:'Ad not loaded. Click load to request an ad.'
02c85c84: ldr     x9, [x0]                                   &2c5bbd4(=a9bd7bfdd503233f)
02c85c88: ldp     x20, x19, [sp, #0x10]                      
02c85c8c: ldr     x1, [x8]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c85c90: ldr     x2, [x9, #0x5f0]                           
02c85c94: ldr     x3, [x9, #0x5e8]                           
02c85c98: ldr     x30, [sp], #0x20                           
02c85c9c: br      x3                                         
02c85ca0: bl      #0x2b7105c                                 fn_2b7105c
## OnDestroy() -> void
---- RewardedVideoAdScene::OnDestroy 0x2c85ca4
02c85ca4: str     x30, [sp, #-0x20]!                         
02c85ca8: stp     x20, x19, [sp, #0x10]                      
02c85cac: adrp    x20, #0x662f000                            
02c85cb0: mov     x19, x0                                    
02c85cb4: ldrb    w8, [x20, #0x939]                          
02c85cb8: tbnz    w8, #0, #0x2c85cdc                         
02c85cbc: adrp    x0, #0x6263000                             
02c85cc0: ldr     x0, [x0, #0x928]                           T:UnityEngine.Debug
02c85cc4: bl      #0x2b70db0                                 fn_2b70db0
02c85cc8: adrp    x0, #0x6264000                             
02c85ccc: ldr     x0, [x0, #0xcf8]                           S:'RewardedVideoAdTest was destroyed!'
02c85cd0: bl      #0x2b70db0                                 fn_2b70db0
02c85cd4: mov     w8, #1                                     
02c85cd8: strb    w8, [x20, #0x939]                          
02c85cdc: ldr     x0, [x19, #0x20]                           .rewardedVideoAd
02c85ce0: adrp    x19, #0x6263000                            
02c85ce4: ldr     x19, [x19, #0x928]                         T:UnityEngine.Debug
02c85ce8: cbz     x0, #0x2c85cf4                             
02c85cec: mov     x1, xzr                                    
02c85cf0: bl      #0x2cd2130                                 AudienceNetwork.RewardedVideoAd::Dispose
02c85cf4: ldr     x0, [x19]                                  &2c5bbd4(=a9bd7bfdd503233f)
02c85cf8: adrp    x19, #0x6264000                            
02c85cfc: ldr     w8, [x0, #0xe4]                            [62640e4]=0 f=0,0
02c85d00: ldr     x19, [x19, #0xcf8]                         S:'RewardedVideoAdTest was destroyed!'
02c85d04: cbnz    w8, #0x2c85d0c                             
02c85d08: bl      #0x2b70f30                                 fn_2b70f30
02c85d0c: ldr     x0, [x19]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c85d10: ldp     x20, x19, [sp, #0x10]                      
02c85d14: mov     x1, xzr                                    
02c85d18: ldr     x30, [sp], #0x20                           
02c85d1c: b       #0x5af21f4                                 UnityEngine.Debug::Log
## NextScene() -> void
---- RewardedVideoAdScene::NextScene 0x2c85d20
02c85d20: str     x30, [sp, #-0x20]!                         
02c85d24: stp     x20, x19, [sp, #0x10]                      
02c85d28: adrp    x20, #0x662f000                            
02c85d2c: adrp    x19, #0x6264000                            
02c85d30: ldrb    w8, [x20, #0x93a]                          
02c85d34: ldr     x19, [x19, #0xb58]                         T:UnityEngine.SceneManagement.SceneManager
02c85d38: tbnz    w8, #0, #0x2c85d5c                         
02c85d3c: adrp    x0, #0x6264000                             
02c85d40: ldr     x0, [x0, #0xb58]                           T:UnityEngine.SceneManagement.SceneManager
02c85d44: bl      #0x2b70db0                                 fn_2b70db0
02c85d48: adrp    x0, #0x6264000                             
02c85d4c: ldr     x0, [x0, #0xd00]                           S:'InterstitialAdScene'
02c85d50: bl      #0x2b70db0                                 fn_2b70db0
02c85d54: mov     w8, #1                                     
02c85d58: strb    w8, [x20, #0x93a]                          
02c85d5c: ldr     x0, [x19]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c85d60: adrp    x19, #0x6264000                            
02c85d64: ldr     w8, [x0, #0xe4]                            [62640e4]=0 f=0,0
02c85d68: ldr     x19, [x19, #0xd00]                         S:'InterstitialAdScene'
02c85d6c: cbnz    w8, #0x2c85d74                             
02c85d70: bl      #0x2b70f30                                 fn_2b70f30
02c85d74: ldr     x0, [x19]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c85d78: ldp     x20, x19, [sp, #0x10]                      
02c85d7c: mov     x1, xzr                                    
02c85d80: ldr     x30, [sp], #0x20                           
02c85d84: b       #0x5b4f55c                                 UnityEngine.SceneManagement.SceneManager::LoadScene
## .ctor() -> void
---- RewardedVideoAdScene::.ctor 0x2c85d88
02c85d88: mov     x1, xzr                                    
02c85d8c: b       #0x5b397b0                                 UnityEngine.MonoBehaviour::.ctor
## <LoadRewardedVideo>b__5_0() -> void
---- RewardedVideoAdScene::<LoadRewardedVideo>b__5_0 0x2c85d90
02c85d90: stp     x30, x23, [sp, #-0x30]!                    
02c85d94: stp     x22, x21, [sp, #0x10]                      
02c85d98: stp     x20, x19, [sp, #0x20]                      
02c85d9c: adrp    x21, #0x662f000                            
02c85da0: adrp    x20, #0x6263000                            
02c85da4: mov     x19, x0                                    
02c85da8: ldrb    w8, [x21, #0x93b]                          
02c85dac: ldr     x20, [x20, #0x928]                         T:UnityEngine.Debug
02c85db0: tbnz    w8, #0, #0x2c85e04                         
02c85db4: adrp    x0, #0x6263000                             
02c85db8: ldr     x0, [x0, #0x928]                           T:UnityEngine.Debug
02c85dbc: bl      #0x2b70db0                                 fn_2b70db0
02c85dc0: adrp    x0, #0x6264000                             
02c85dc4: ldr     x0, [x0, #0xc28]                           S:'Ad loaded and is '
02c85dc8: bl      #0x2b70db0                                 fn_2b70db0
02c85dcc: adrp    x0, #0x6264000                             
02c85dd0: ldr     x0, [x0, #0xb88]                           S:'invalid'
02c85dd4: bl      #0x2b70db0                                 fn_2b70db0
02c85dd8: adrp    x0, #0x6264000                             
02c85ddc: ldr     x0, [x0, #0xb90]                           S:'valid'
02c85de0: bl      #0x2b70db0                                 fn_2b70db0
02c85de4: adrp    x0, #0x6264000                             
02c85de8: ldr     x0, [x0, #0xc30]                           S:'. Click show to present!'
02c85dec: bl      #0x2b70db0                                 fn_2b70db0
02c85df0: adrp    x0, #0x6264000                             
02c85df4: ldr     x0, [x0, #0xd08]                           S:'RewardedVideo ad loaded.'
02c85df8: bl      #0x2b70db0                                 fn_2b70db0
02c85dfc: mov     w8, #1                                     
02c85e00: strb    w8, [x21, #0x93b]                          
02c85e04: ldr     x0, [x20]                                  &2c5bbd4(=a9bd7bfdd503233f)
02c85e08: adrp    x20, #0x6264000                            
02c85e0c: ldr     w8, [x0, #0xe4]                            [62640e4]=0 f=0,0
02c85e10: ldr     x20, [x20, #0xd08]                         S:'RewardedVideo ad loaded.'
02c85e14: cbnz    w8, #0x2c85e1c                             
02c85e18: bl      #0x2b70f30                                 fn_2b70f30
02c85e1c: ldr     x0, [x20]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c85e20: mov     x1, xzr                                    
02c85e24: bl      #0x5af21f4                                 UnityEngine.Debug::Log
02c85e28: ldr     x0, [x19, #0x20]                           .rewardedVideoAd
02c85e2c: mov     w8, #1                                     
02c85e30: strh    w8, [x19, #0x28]                           .isLoaded
02c85e34: cbz     x0, #0x2c85ea8                             
02c85e38: adrp    x20, #0x6264000                            
02c85e3c: adrp    x21, #0x6264000                            
02c85e40: adrp    x22, #0x6264000                            
02c85e44: adrp    x23, #0x6264000                            
02c85e48: ldr     x20, [x20, #0xb90]                         S:'valid'
02c85e4c: ldr     x21, [x21, #0xb88]                         S:'invalid'
02c85e50: ldr     x22, [x22, #0xc28]                         S:'Ad loaded and is '
02c85e54: ldr     x23, [x23, #0xc30]                         S:'. Click show to present!'
02c85e58: mov     x1, xzr                                    
02c85e5c: bl      #0x2cd2748                                 AudienceNetwork.RewardedVideoAd::IsValid
02c85e60: tst     w0, #1                                     
02c85e64: ldr     x0, [x22]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c85e68: ldr     x2, [x23]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c85e6c: csel    x8, x20, x21, ne                           
02c85e70: ldr     x19, [x19, #0x30]                          .statusLabel
02c85e74: mov     x3, xzr                                    
02c85e78: ldr     x1, [x8]                                   
02c85e7c: bl      #0x4ca6dbc                                 System.String::Concat
02c85e80: cbz     x19, #0x2c85ea8                            
02c85e84: ldr     x8, [x19]                                  
02c85e88: mov     x1, x0                                     
02c85e8c: mov     x0, x19                                    
02c85e90: ldp     x20, x19, [sp, #0x20]                      
02c85e94: ldp     x22, x21, [sp, #0x10]                      
02c85e98: ldr     x2, [x8, #0x5f0]                           
02c85e9c: ldr     x3, [x8, #0x5e8]                           
02c85ea0: ldp     x30, x23, [sp], #0x30                      
02c85ea4: br      x3                                         
02c85ea8: bl      #0x2b7105c                                 fn_2b7105c
## <LoadRewardedVideo>b__5_1(string error) -> void
---- RewardedVideoAdScene::<LoadRewardedVideo>b__5_1 0x2c85eac
02c85eac: stp     x30, x23, [sp, #-0x30]!                    
02c85eb0: stp     x22, x21, [sp, #0x10]                      
02c85eb4: stp     x20, x19, [sp, #0x20]                      
02c85eb8: adrp    x22, #0x662f000                            
02c85ebc: adrp    x23, #0x6264000                            
02c85ec0: adrp    x21, #0x6263000                            
02c85ec4: ldrb    w8, [x22, #0x93c]                          
02c85ec8: ldr     x23, [x23, #0xd10]                         S:'RewardedVideo ad failed to load with error: '
02c85ecc: ldr     x21, [x21, #0x928]                         T:UnityEngine.Debug
02c85ed0: mov     x20, x1                                    
02c85ed4: mov     x19, x0                                    
02c85ed8: tbnz    w8, #0, #0x2c85f08                         
02c85edc: adrp    x0, #0x6263000                             
02c85ee0: ldr     x0, [x0, #0x928]                           T:UnityEngine.Debug
02c85ee4: bl      #0x2b70db0                                 fn_2b70db0
02c85ee8: adrp    x0, #0x6264000                             
02c85eec: ldr     x0, [x0, #0xd10]                           S:'RewardedVideo ad failed to load with error: '
02c85ef0: bl      #0x2b70db0                                 fn_2b70db0
02c85ef4: adrp    x0, #0x6264000                             
02c85ef8: ldr     x0, [x0, #0xd18]                           S:'RewardedVideo ad failed to load. Check console for details.'
02c85efc: bl      #0x2b70db0                                 fn_2b70db0
02c85f00: mov     w8, #1                                     
02c85f04: strb    w8, [x22, #0x93c]                          
02c85f08: ldr     x0, [x23]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c85f0c: mov     x1, x20                                    
02c85f10: mov     x2, xzr                                    
02c85f14: bl      #0x4c9c514                                 System.String::Concat
02c85f18: ldr     x8, [x21]                                  &2c5bbd4(=a9bd7bfdd503233f)
02c85f1c: mov     x20, x0                                    
02c85f20: ldr     w9, [x8, #0xe4]                            
02c85f24: cbnz    w9, #0x2c85f30                             
02c85f28: mov     x0, x8                                     
02c85f2c: bl      #0x2b70f30                                 fn_2b70f30
02c85f30: mov     x0, x20                                    
02c85f34: mov     x1, xzr                                    
02c85f38: bl      #0x5af21f4                                 UnityEngine.Debug::Log
02c85f3c: ldr     x0, [x19, #0x30]                           .statusLabel
02c85f40: cbz     x0, #0x2c85f6c                             
02c85f44: adrp    x8, #0x6264000                             
02c85f48: ldr     x8, [x8, #0xd18]                           S:'RewardedVideo ad failed to load. Check console for details.'
02c85f4c: ldr     x9, [x0]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c85f50: ldp     x20, x19, [sp, #0x20]                      
02c85f54: ldp     x22, x21, [sp, #0x10]                      
02c85f58: ldr     x1, [x8]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c85f5c: ldr     x2, [x9, #0x5f0]                           
02c85f60: ldr     x3, [x9, #0x5e8]                           
02c85f64: ldp     x30, x23, [sp], #0x30                      
02c85f68: br      x3                                         
02c85f6c: bl      #0x2b7105c                                 fn_2b7105c
## <LoadRewardedVideo>b__5_6() -> void
---- RewardedVideoAdScene::<LoadRewardedVideo>b__5_6 0x2c85f70
02c85f70: stp     x30, x21, [sp, #-0x20]!                    
02c85f74: stp     x20, x19, [sp, #0x10]                      
02c85f78: adrp    x21, #0x662f000                            
02c85f7c: adrp    x20, #0x6263000                            
02c85f80: mov     x19, x0                                    
02c85f84: ldrb    w8, [x21, #0x93d]                          
02c85f88: ldr     x20, [x20, #0x928]                         T:UnityEngine.Debug
02c85f8c: tbnz    w8, #0, #0x2c85fb0                         
02c85f90: adrp    x0, #0x6263000                             
02c85f94: ldr     x0, [x0, #0x928]                           T:UnityEngine.Debug
02c85f98: bl      #0x2b70db0                                 fn_2b70db0
02c85f9c: adrp    x0, #0x6264000                             
02c85fa0: ldr     x0, [x0, #0xd20]                           S:'Rewarded video ad did close.'
02c85fa4: bl      #0x2b70db0                                 fn_2b70db0
02c85fa8: mov     w8, #1                                     
02c85fac: strb    w8, [x21, #0x93d]                          
02c85fb0: ldr     x0, [x20]                                  &2c5bbd4(=a9bd7bfdd503233f)
02c85fb4: adrp    x20, #0x6264000                            
02c85fb8: ldr     w8, [x0, #0xe4]                            [62640e4]=0 f=0,0
02c85fbc: ldr     x20, [x20, #0xd20]                         S:'Rewarded video ad did close.'
02c85fc0: cbnz    w8, #0x2c85fc8                             
02c85fc4: bl      #0x2b70f30                                 fn_2b70f30
02c85fc8: ldr     x0, [x20]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c85fcc: mov     x1, xzr                                    
02c85fd0: bl      #0x5af21f4                                 UnityEngine.Debug::Log
02c85fd4: ldr     x0, [x19, #0x20]                           .rewardedVideoAd
02c85fd8: mov     w8, #1                                     
02c85fdc: strb    w8, [x19, #0x29]                           .didClose
02c85fe0: cbz     x0, #0x2c85ff4                             
02c85fe4: ldp     x20, x19, [sp, #0x10]                      
02c85fe8: mov     x1, xzr                                    
02c85fec: ldp     x30, x21, [sp], #0x20                      
02c85ff0: b       #0x2cd2130                                 AudienceNetwork.RewardedVideoAd::Dispose
02c85ff4: ldp     x20, x19, [sp, #0x10]                      
02c85ff8: ldp     x30, x21, [sp], #0x20                      
02c85ffc: ret                                                
## <LoadRewardedVideo>b__5_7() -> void
---- RewardedVideoAdScene::<LoadRewardedVideo>b__5_7 0x2c86000
02c86000: str     x30, [sp, #-0x20]!                         
02c86004: stp     x20, x19, [sp, #0x10]                      
02c86008: adrp    x20, #0x662f000                            
02c8600c: mov     x19, x0                                    
02c86010: ldrb    w8, [x20, #0x93e]                          
02c86014: tbnz    w8, #0, #0x2c86044                         
02c86018: adrp    x0, #0x6263000                             
02c8601c: ldr     x0, [x0, #0x928]                           T:UnityEngine.Debug
02c86020: bl      #0x2b70db0                                 fn_2b70db0
02c86024: adrp    x0, #0x6264000                             
02c86028: ldr     x0, [x0, #0xd28]                           S:'Game should resume. User should not get a reward.'
02c8602c: bl      #0x2b70db0                                 fn_2b70db0
02c86030: adrp    x0, #0x6264000                             
02c86034: ldr     x0, [x0, #0xd30]                           S:'Rewarded video activity destroyed without being closed first.'
02c86038: bl      #0x2b70db0                                 fn_2b70db0
02c8603c: mov     w8, #1                                     
02c86040: strb    w8, [x20, #0x93e]                          
02c86044: ldrb    w8, [x19, #0x29]                           .didClose
02c86048: cbz     w8, #0x2c86058                             
02c8604c: ldp     x20, x19, [sp, #0x10]                      
02c86050: ldr     x30, [sp], #0x20                           
02c86054: ret                                                
02c86058: adrp    x8, #0x6263000                             
02c8605c: ldr     x8, [x8, #0x928]                           T:UnityEngine.Debug
02c86060: ldr     x0, [x8]                                   &2c5bbd4(=a9bd7bfdd503233f)
02c86064: ldr     w8, [x0, #0xe4]                            [62640e4]=0 f=0,0
02c86068: cbnz    w8, #0x2c86070                             
02c8606c: bl      #0x2b70f30                                 fn_2b70f30
02c86070: adrp    x8, #0x6264000                             
02c86074: mov     x1, xzr                                    
02c86078: ldr     x8, [x8, #0xd30]                           S:'Rewarded video activity destroyed without being closed first.'
02c8607c: ldr     x0, [x8]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c86080: bl      #0x5af21f4                                 UnityEngine.Debug::Log
02c86084: adrp    x8, #0x6264000                             
02c86088: mov     x1, xzr                                    
02c8608c: ldr     x8, [x8, #0xd28]                           S:'Game should resume. User should not get a reward.'
02c86090: ldp     x20, x19, [sp, #0x10]                      
02c86094: ldr     x0, [x8]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c86098: ldr     x30, [sp], #0x20                           
02c8609c: b       #0x5af21f4                                 UnityEngine.Debug::Log
