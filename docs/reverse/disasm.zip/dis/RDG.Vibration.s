#### CLASS RDG.Vibration/PredefinedEffect parent= object
#   field EFFECT_CLICK                   int                                                off=0x0 attr=16 
#   field EFFECT_DOUBLE_CLICK            int                                                off=0x4 attr=16 
#   field EFFECT_HEAVY_CLICK             int                                                off=0x8 attr=16 
#   field EFFECT_TICK                    int                                                off=0xc attr=16 
#### CLASS RDG.Vibration/logLevel parent= int
#   field value__                        int                                                off=0x10 attr=606 
#   field Disabled                       RDG.Vibration/logLevel                             off=0x0 attr=8056 
#   field Info                           RDG.Vibration/logLevel                             off=0x0 attr=8056 
#   field Warning                        RDG.Vibration/logLevel                             off=0x0 attr=8056 
#### CLASS RDG.Vibration/<>c__DisplayClass10_0 parent= System.ValueType
#   field pattern                        long[]                                             off=0x10 attr=6 
#   field amplitudes                     int[]                                              off=0x18 attr=6 
#   field repeat                         int                                                off=0x20 attr=6 
#   field cancel                         bool                                               off=0x24 attr=6 
#### CLASS RDG.Vibration/<>c__DisplayClass11_0 parent= System.ValueType
#   field effectId                       int                                                off=0x10 attr=6 
#### CLASS RDG.Vibration/<>c__DisplayClass9_0 parent= System.ValueType
#   field milliseconds                   long                                               off=0x10 attr=6 
#   field amplitude                      int                                                off=0x18 attr=6 
#   field cancel                         bool                                               off=0x1c attr=6 
#### CLASS RDG.Vibration parent= object
#   field LogLevel                       RDG.Vibration/logLevel                             off=0x0 attr=16 
#   field vibrator                       UnityEngine.AndroidJavaObject                      off=0x8 attr=11 
#   field vibrationEffectClass           UnityEngine.AndroidJavaClass                       off=0x10 attr=11 
#   field defaultAmplitude               int                                                off=0x18 attr=11 
#   field ApiLevel                       int                                                off=0x1c attr=11 
#   field isInitialized                  bool                                               off=0x20 attr=11 
## doesSupportVibrationEffect() -> bool
---- RDG.Vibration::doesSupportVibrationEffect 0x2cfca0c
02cfca0c: str     x30, [sp, #-0x20]!                         
02cfca10: stp     x20, x19, [sp, #0x10]                      
02cfca14: adrp    x20, #0x662f000                            
02cfca18: adrp    x19, #0x6268000                            
02cfca1c: ldrb    w8, [x20, #0xedd]                          
02cfca20: ldr     x19, [x19, #0xcd8]                         T:RDG.Vibration
02cfca24: tbnz    w8, #0, #0x2cfca3c                         
02cfca28: adrp    x0, #0x6268000                             
02cfca2c: ldr     x0, [x0, #0xcd8]                           T:RDG.Vibration
02cfca30: bl      #0x2b70db0                                 fn_2b70db0
02cfca34: mov     w8, #1                                     
02cfca38: strb    w8, [x20, #0xedd]                          
02cfca3c: ldr     x0, [x19]                                  S:'{0}/2'
02cfca40: ldr     w8, [x0, #0xe4]                            [62680e4]=0 f=0,0
02cfca44: cbnz    w8, #0x2cfca50                             
02cfca48: bl      #0x2b70f30                                 fn_2b70f30
02cfca4c: ldr     x0, [x19]                                  S:'{0}/2'
02cfca50: ldr     x8, [x0, #0xb8]                            T:LuckyWheelPopup/<>c__DisplayClass54_0
02cfca54: ldp     x20, x19, [sp, #0x10]                      
02cfca58: ldr     w8, [x8, #0x1c]                            
02cfca5c: cmp     w8, #0x19                                  
02cfca60: cset    w0, gt                                     
02cfca64: ldr     x30, [sp], #0x20                           
02cfca68: ret                                                
## doesSupportPredefinedEffect() -> bool
---- RDG.Vibration::doesSupportPredefinedEffect 0x2cfca6c
02cfca6c: str     x30, [sp, #-0x20]!                         
02cfca70: stp     x20, x19, [sp, #0x10]                      
02cfca74: adrp    x20, #0x662f000                            
02cfca78: adrp    x19, #0x6268000                            
02cfca7c: ldrb    w8, [x20, #0xede]                          
02cfca80: ldr     x19, [x19, #0xcd8]                         T:RDG.Vibration
02cfca84: tbnz    w8, #0, #0x2cfca9c                         
02cfca88: adrp    x0, #0x6268000                             
02cfca8c: ldr     x0, [x0, #0xcd8]                           T:RDG.Vibration
02cfca90: bl      #0x2b70db0                                 fn_2b70db0
02cfca94: mov     w8, #1                                     
02cfca98: strb    w8, [x20, #0xede]                          
02cfca9c: ldr     x0, [x19]                                  S:'{0}/2'
02cfcaa0: ldr     w8, [x0, #0xe4]                            [62680e4]=0 f=0,0
02cfcaa4: cbnz    w8, #0x2cfcab0                             
02cfcaa8: bl      #0x2b70f30                                 fn_2b70f30
02cfcaac: ldr     x0, [x19]                                  S:'{0}/2'
02cfcab0: ldr     x8, [x0, #0xb8]                            T:LuckyWheelPopup/<>c__DisplayClass54_0
02cfcab4: ldp     x20, x19, [sp, #0x10]                      
02cfcab8: ldr     w8, [x8, #0x1c]                            
02cfcabc: cmp     w8, #0x1c                                  
02cfcac0: cset    w0, gt                                     
02cfcac4: ldr     x30, [sp], #0x20                           
02cfcac8: ret                                                
## Initialize() -> void
---- RDG.Vibration::Initialize 0x2cfcacc
02cfcacc: sub     sp, sp, #0x70                              
02cfcad0: stp     x30, x23, [sp, #0x40]                      
02cfcad4: stp     x22, x21, [sp, #0x50]                      
02cfcad8: stp     x20, x19, [sp, #0x60]                      
02cfcadc: adrp    x20, #0x662f000                            
02cfcae0: adrp    x19, #0x6264000                            
02cfcae4: ldrb    w8, [x20, #0xedf]                          
02cfcae8: ldr     x19, [x19, #0xa70]                         T:UnityEngine.Application
02cfcaec: tbnz    w8, #0, #0x2cfcc00                         
02cfcaf0: adrp    x0, #0x6263000                             
02cfcaf4: ldr     x0, [x0, #0xc40]                           T:UnityEngine.AndroidJavaClass
02cfcaf8: bl      #0x2b70db0                                 fn_2b70db0
02cfcafc: adrp    x0, #0x6267000                             
02cfcb00: ldr     x0, [x0, #0x3e0]                           MS:UnityEngine.AndroidJavaObject::Call
02cfcb04: bl      #0x2b70db0                                 fn_2b70db0
02cfcb08: adrp    x0, #0x6263000                             
02cfcb0c: ldr     x0, [x0, #0xc50]                           MS:UnityEngine.AndroidJavaObject::GetStatic
02cfcb10: bl      #0x2b70db0                                 fn_2b70db0
02cfcb14: adrp    x0, #0x6266000                             
02cfcb18: ldr     x0, [x0, #0x168]                           MS:UnityEngine.AndroidJavaObject::GetStatic
02cfcb1c: bl      #0x2b70db0                                 fn_2b70db0
02cfcb20: adrp    x0, #0x6264000                             
02cfcb24: ldr     x0, [x0, #0xa70]                           T:UnityEngine.Application
02cfcb28: bl      #0x2b70db0                                 fn_2b70db0
02cfcb2c: adrp    x0, #0x6263000                             
02cfcb30: ldr     x0, [x0, #0x980]                           T:System.IDisposable
02cfcb34: bl      #0x2b70db0                                 fn_2b70db0
02cfcb38: adrp    x0, #0x6263000                             
02cfcb3c: ldr     x0, [x0, #0xa80]                           T:type24502(k1d)
02cfcb40: bl      #0x2b70db0                                 fn_2b70db0
02cfcb44: adrp    x0, #0x6268000                             
02cfcb48: ldr     x0, [x0, #0xce0]                           T:RDG.Vibration/PredefinedEffect
02cfcb4c: bl      #0x2b70db0                                 fn_2b70db0
02cfcb50: adrp    x0, #0x6268000                             
02cfcb54: ldr     x0, [x0, #0xcd8]                           T:RDG.Vibration
02cfcb58: bl      #0x2b70db0                                 fn_2b70db0
02cfcb5c: adrp    x0, #0x6268000                             
02cfcb60: ldr     x0, [x0, #0xce8]                           S:'SDK_INT'
02cfcb64: bl      #0x2b70db0                                 fn_2b70db0
02cfcb68: adrp    x0, #0x6268000                             
02cfcb6c: ldr     x0, [x0, #0xcf0]                           S:'EFFECT_CLICK'
02cfcb70: bl      #0x2b70db0                                 fn_2b70db0
02cfcb74: adrp    x0, #0x6268000                             
02cfcb78: ldr     x0, [x0, #0xcf8]                           S:'android.os.VibrationEffect'
02cfcb7c: bl      #0x2b70db0                                 fn_2b70db0
02cfcb80: adrp    x0, #0x6265000                             
02cfcb84: ldr     x0, [x0, #0x730]                           S:'com.unity3d.player.UnityPlayer'
02cfcb88: bl      #0x2b70db0                                 fn_2b70db0
02cfcb8c: adrp    x0, #0x6268000                             
02cfcb90: ldr     x0, [x0, #0xd00]                           S:'DEFAULT_AMPLITUDE'
02cfcb94: bl      #0x2b70db0                                 fn_2b70db0
02cfcb98: adrp    x0, #0x6268000                             
02cfcb9c: ldr     x0, [x0, #0xd08]                           S:'vibrator'
02cfcba0: bl      #0x2b70db0                                 fn_2b70db0
02cfcba4: adrp    x0, #0x6268000                             
02cfcba8: ldr     x0, [x0, #0xd10]                           S:'getSystemService'
02cfcbac: bl      #0x2b70db0                                 fn_2b70db0
02cfcbb0: adrp    x0, #0x6268000                             
02cfcbb4: ldr     x0, [x0, #0xd18]                           S:'EFFECT_DOUBLE_CLICK'
02cfcbb8: bl      #0x2b70db0                                 fn_2b70db0
02cfcbbc: adrp    x0, #0x6268000                             
02cfcbc0: ldr     x0, [x0, #0xd20]                           S:'android.os.Build$VERSION'
02cfcbc4: bl      #0x2b70db0                                 fn_2b70db0
02cfcbc8: adrp    x0, #0x6268000                             
02cfcbcc: ldr     x0, [x0, #0xd28]                           S:'EFFECT_HEAVY_CLICK'
02cfcbd0: bl      #0x2b70db0                                 fn_2b70db0
02cfcbd4: adrp    x0, #0x6268000                             
02cfcbd8: ldr     x0, [x0, #0xd30]                           S:'Vibration component initialized'
02cfcbdc: bl      #0x2b70db0                                 fn_2b70db0
02cfcbe0: adrp    x0, #0x6268000                             
02cfcbe4: ldr     x0, [x0, #0xd38]                           S:'EFFECT_TICK'
02cfcbe8: bl      #0x2b70db0                                 fn_2b70db0
02cfcbec: adrp    x0, #0x6265000                             
02cfcbf0: ldr     x0, [x0, #0x738]                           S:'currentActivity'
02cfcbf4: bl      #0x2b70db0                                 fn_2b70db0
02cfcbf8: mov     w8, #1                                     
02cfcbfc: strb    w8, [x20, #0xedf]                          
02cfcc00: ldr     x0, [x19]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02cfcc04: stp     xzr, xzr, [sp, #0x30]                      
02cfcc08: str     xzr, [sp, #0x28]                           
02cfcc0c: ldr     w8, [x0, #0xe4]                            [62650e4]=0 f=0,0
02cfcc10: cbnz    w8, #0x2cfcc18                             
02cfcc14: bl      #0x2b70f30                                 fn_2b70f30
02cfcc18: adrp    x21, #0x6268000                            
02cfcc1c: mov     x0, xzr                                    
02cfcc20: ldr     x21, [x21, #0xcd8]                         T:RDG.Vibration
02cfcc24: bl      #0x5aeb258                                 UnityEngine.Application::get_isConsolePlatform
02cfcc28: tbz     w0, #0, #0x2cfcc34                         
02cfcc2c: mov     x0, xzr                                    
02cfcc30: bl      #0x5b1c460                                 UnityEngine.Handheld::Vibrate
02cfcc34: ldr     x0, [x21]                                  S:'{0}/2'
02cfcc38: ldr     w8, [x0, #0xe4]                            [62650e4]=0 f=0,0
02cfcc3c: cbnz    w8, #0x2cfcc48                             
02cfcc40: bl      #0x2b70f30                                 fn_2b70f30
02cfcc44: ldr     x0, [x21]                                  S:'{0}/2'
02cfcc48: ldr     x8, [x0, #0xb8]                            T:AdsManager/<>c__DisplayClass42_0
02cfcc4c: ldrb    w8, [x8, #0x20]                            
02cfcc50: cbnz    w8, #0x2cfd14c                             
02cfcc54: ldr     x0, [x19]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02cfcc58: ldr     w8, [x0, #0xe4]                            [62650e4]=0 f=0,0
02cfcc5c: cbnz    w8, #0x2cfcc64                             
02cfcc60: bl      #0x2b70f30                                 fn_2b70f30
02cfcc64: mov     x0, xzr                                    
02cfcc68: bl      #0x5aeb18c                                 UnityEngine.Application::get_platform
02cfcc6c: cmp     w0, #0xb                                   
02cfcc70: b.ne    #0x2cfd14c                                 
02cfcc74: adrp    x22, #0x6263000                            
02cfcc78: ldr     x22, [x22, #0xc40]                         T:UnityEngine.AndroidJavaClass
02cfcc7c: ldr     x0, [x22]                                  &2c5bbd4(=a9bd7bfdd503233f)
02cfcc80: bl      #0x2b7104c                                 fn_2b7104c
02cfcc84: adrp    x8, #0x6268000                             
02cfcc88: mov     x2, xzr                                    
02cfcc8c: mov     x19, x0                                    
02cfcc90: ldr     x8, [x8, #0xd20]                           S:'android.os.Build$VERSION'
02cfcc94: ldr     x1, [x8]                                   S:'{0}/2'
02cfcc98: bl      #0x5ad2f6c                                 UnityEngine.AndroidJavaClass::.ctor
02cfcc9c: add     x8, sp, #0x38                              
02cfcca0: str     x19, [sp, #0x38]                           
02cfcca4: stp     xzr, x8, [sp, #0x18]                       
02cfcca8: cbz     x19, #0x2cfd160                            
02cfccac: adrp    x8, #0x6268000                             
02cfccb0: adrp    x9, #0x6266000                             
02cfccb4: ldr     x8, [x8, #0xce8]                           S:'SDK_INT'
02cfccb8: ldr     x9, [x9, #0x168]                           MS:UnityEngine.AndroidJavaObject::GetStatic
02cfccbc: ldr     x1, [x8]                                   S:'{0}/2'
02cfccc0: ldr     x2, [x9]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cfccc4: mov     x0, x19                                    
02cfccc8: bl      #0x31217c8                                 fn_31217c8
02cfcccc: mov     w20, w0                                    
02cfccd0: ldr     x0, [x21]                                  S:'{0}/2'
02cfccd4: ldr     w8, [x0, #0xe4]                            [62650e4]=0 f=0,0
02cfccd8: cbnz    w8, #0x2cfcce4                             
02cfccdc: bl      #0x2b70f30                                 fn_2b70f30
02cfcce0: ldr     x0, [x21]                                  S:'{0}/2'
02cfcce4: ldr     x8, [x0, #0xb8]                            T:AdsManager/<>c__DisplayClass42_0
02cfcce8: mov     x19, xzr                                   
02cfccec: str     w20, [x8, #0x1c]                           
02cfccf0: add     x8, sp, #0x38                              
02cfccf4: ldr     x20, [x8]                                  S:'{0}/2'
02cfccf8: cbz     x20, #0x2cfcd5c                            
02cfccfc: adrp    x10, #0x6263000                            
02cfcd00: ldr     x8, [x20]                                  &2b706c4(=eb01011ff9400808)
02cfcd04: ldr     x10, [x10, #0x980]                         T:System.IDisposable
02cfcd08: ldrh    w9, [x8, #0x12e]                           
02cfcd0c: ldr     x1, [x10]                                  &2c5bbd4(=a9bd7bfdd503233f)
02cfcd10: cbz     x9, #0x2cfcd34                             
02cfcd14: ldr     x10, [x8, #0xb0]                           S:'penguin_close_mouth'
02cfcd18: add     x10, x10, #8                               &6263008
02cfcd1c: ldur    x11, [x10, #-8]                            
02cfcd20: cmp     x11, x1                                    
02cfcd24: b.eq    #0x2cfcd44                                 
02cfcd28: subs    x9, x9, #1                                 
02cfcd2c: add     x10, x10, #0x10                            &6263010
02cfcd30: b.ne    #0x2cfcd1c                                 
02cfcd34: mov     x0, x20                                    
02cfcd38: mov     w2, wzr                                    
02cfcd3c: bl      #0x2baa05c                                 fn_2baa05c
02cfcd40: b       #0x2cfcd50                                 
02cfcd44: ldrsw   x9, [x10]                                  
02cfcd48: add     x8, x8, x9, lsl #4                         &6268000
02cfcd4c: add     x0, x8, #0x138                             &6268138
02cfcd50: ldp     x8, x1, [x0]                               
02cfcd54: mov     x0, x20                                    
02cfcd58: blr     x8                                         
02cfcd5c: cbnz    x19, #0x2cfd164                            
02cfcd60: ldr     x0, [x22]                                  &2c5bbd4(=a9bd7bfdd503233f)
02cfcd64: bl      #0x2b7104c                                 fn_2b7104c
02cfcd68: adrp    x8, #0x6265000                             
02cfcd6c: mov     x2, xzr                                    
02cfcd70: mov     x19, x0                                    
02cfcd74: ldr     x8, [x8, #0x730]                           S:'com.unity3d.player.UnityPlayer'
02cfcd78: ldr     x1, [x8]                                   M:AdsManager::<OnApplicationPause>b__26_0
02cfcd7c: bl      #0x5ad2f6c                                 UnityEngine.AndroidJavaClass::.ctor
02cfcd80: add     x8, sp, #0x30                              
02cfcd84: str     x19, [sp, #0x30]                           
02cfcd88: stp     xzr, x8, [sp, #0x18]                       
02cfcd8c: cbz     x19, #0x2cfd16c                            
02cfcd90: adrp    x8, #0x6265000                             
02cfcd94: adrp    x9, #0x6263000                             
02cfcd98: ldr     x8, [x8, #0x738]                           S:'currentActivity'
02cfcd9c: ldr     x9, [x9, #0xc50]                           MS:UnityEngine.AndroidJavaObject::GetStatic
02cfcda0: ldr     x1, [x8]                                   M:AdsManager::<OnApplicationPause>b__26_0
02cfcda4: ldr     x2, [x9]                                   &2c5bbd4(=a9bd7bfdd503233f)
02cfcda8: mov     x0, x19                                    
02cfcdac: bl      #0x3121808                                 fn_3121808
02cfcdb0: mov     x19, x0                                    
02cfcdb4: add     x8, sp, #0x28                              
02cfcdb8: str     x0, [sp, #0x28]                            
02cfcdbc: stp     xzr, x8, [sp, #8]                          
02cfcdc0: cbz     x0, #0x2cfcf04                             
02cfcdc4: adrp    x8, #0x6263000                             
02cfcdc8: ldr     x8, [x8, #0xa80]                           T:type24502(k1d)
02cfcdcc: ldr     x0, [x8]                                   &2c5bbd4(=a9bd7bfdd503233f)
02cfcdd0: mov     w1, #1                                     
02cfcdd4: bl      #0x2b70ea0                                 fn_2b70ea0
02cfcdd8: mov     x20, x0                                    
02cfcddc: cbz     x0, #0x2cfd178                             
02cfcde0: adrp    x23, #0x6268000                            
02cfcde4: ldr     x23, [x23, #0xd08]                         S:'vibrator'
02cfcde8: ldr     x0, [x23]                                  S:'{0}/2'
02cfcdec: cbz     x0, #0x2cfce00                             
02cfcdf0: ldr     x8, [x20]                                  &2b706c4(=eb01011ff9400808)
02cfcdf4: ldr     x1, [x8, #0x40]                            [6263040]=0 f=0,0
02cfcdf8: bl      #0x2b70f34                                 fn_2b70f34
02cfcdfc: cbz     x0, #0x2cfd180                             
02cfce00: ldr     w8, [x20, #0x18]                           [662f018]=6000014 f=2.40742e-35,0 .defaultAmplitude
02cfce04: cbz     w8, #0x2cfd17c                             
02cfce08: ldr     x1, [x23]                                  S:'{0}/2'
02cfce0c: mov     x0, x20                                    
02cfce10: str     x1, [x0, #0x20]!                           .isInitialized
02cfce14: bl      #0x2b70d54                                 fn_2b70d54
02cfce18: adrp    x8, #0x6268000                             
02cfce1c: adrp    x9, #0x6267000                             
02cfce20: ldr     x8, [x8, #0xd10]                           S:'getSystemService'
02cfce24: ldr     x9, [x9, #0x3e0]                           MS:UnityEngine.AndroidJavaObject::Call
02cfce28: ldr     x1, [x8]                                   S:'{0}/2'
02cfce2c: ldr     x3, [x9]                                   S:'didu'
02cfce30: mov     x0, x19                                    
02cfce34: mov     x2, x20                                    
02cfce38: bl      #0x311f8b4                                 fn_311f8b4
02cfce3c: mov     x19, x0                                    
02cfce40: ldr     x0, [x21]                                  S:'{0}/2'
02cfce44: ldr     w8, [x0, #0xe4]                            [62650e4]=0 f=0,0
02cfce48: cbnz    w8, #0x2cfce54                             
02cfce4c: bl      #0x2b70f30                                 fn_2b70f30
02cfce50: ldr     x0, [x21]                                  S:'{0}/2'
02cfce54: ldr     x0, [x0, #0xb8]                            T:AdsManager/<>c__DisplayClass42_0
02cfce58: str     x19, [x0, #8]!                             
02cfce5c: mov     x1, x19                                    
02cfce60: bl      #0x2b70d54                                 fn_2b70d54
02cfce64: bl      #0x2cfca0c                                 RDG.Vibration::doesSupportVibrationEffect
02cfce68: tbz     w0, #0, #0x2cfcf10                         
02cfce6c: ldr     x0, [x22]                                  &2c5bbd4(=a9bd7bfdd503233f)
02cfce70: bl      #0x2b7104c                                 fn_2b7104c
02cfce74: adrp    x8, #0x6268000                             
02cfce78: mov     x19, x0                                    
02cfce7c: ldr     x8, [x8, #0xcf8]                           S:'android.os.VibrationEffect'
02cfce80: ldr     x1, [x8]                                   S:'{0}/2'
02cfce84: mov     x2, xzr                                    
02cfce88: bl      #0x5ad2f6c                                 UnityEngine.AndroidJavaClass::.ctor
02cfce8c: ldr     x0, [x21]                                  S:'{0}/2'
02cfce90: ldr     w8, [x0, #0xe4]                            [62650e4]=0 f=0,0
02cfce94: cbnz    w8, #0x2cfcea0                             
02cfce98: bl      #0x2b70f30                                 fn_2b70f30
02cfce9c: ldr     x0, [x21]                                  S:'{0}/2'
02cfcea0: ldr     x0, [x0, #0xb8]                            T:AdsManager/<>c__DisplayClass42_0
02cfcea4: str     x19, [x0, #0x10]!                          .vibrationEffectClass
02cfcea8: mov     x1, x19                                    
02cfceac: bl      #0x2b70d54                                 fn_2b70d54
02cfceb0: ldr     x8, [x21]                                  S:'{0}/2'
02cfceb4: ldr     x8, [x8, #0xb8]                            T:LuckyWheelPopup/<>c__DisplayClass54_0
02cfceb8: ldr     x0, [x8, #0x10]                            MS:DG.Tweening.TweenSettingsExtensions::SetLoops
02cfcebc: cbz     x0, #0x2cfd18c                             
02cfcec0: adrp    x8, #0x6268000                             
02cfcec4: adrp    x9, #0x6266000                             
02cfcec8: ldr     x8, [x8, #0xd00]                           S:'DEFAULT_AMPLITUDE'
02cfcecc: ldr     x9, [x9, #0x168]                           MS:UnityEngine.AndroidJavaObject::GetStatic
02cfced0: ldr     x1, [x8]                                   S:'{0}/2'
02cfced4: ldr     x2, [x9]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cfced8: bl      #0x31217c8                                 fn_31217c8
02cfcedc: mov     w8, w0                                     
02cfcee0: cmp     w0, #0xff                                  
02cfcee4: mov     w9, #0xff                                  
02cfcee8: ldr     x0, [x21]                                  S:'{0}/2'
02cfceec: csel    w8, w8, w9, lt                             
02cfcef0: cmp     w8, #1                                     
02cfcef4: ldr     x9, [x0, #0xb8]                            T:AdsManager/<>c__DisplayClass42_0
02cfcef8: csinc   w8, w8, wzr, gt                            
02cfcefc: str     w8, [x9, #0x18]                            
02cfcf00: b       #0x2cfcf14                                 
02cfcf04: mov     w23, wzr                                   
02cfcf08: mov     w22, #7                                    
02cfcf0c: b       #0x2cfd024                                 
02cfcf10: ldr     x0, [x21]                                  S:'{0}/2'
02cfcf14: ldr     w8, [x0, #0xe4]                            [62650e4]=0 f=0,0
02cfcf18: cbnz    w8, #0x2cfcf20                             
02cfcf1c: bl      #0x2b70f30                                 fn_2b70f30
02cfcf20: bl      #0x2cfca6c                                 RDG.Vibration::doesSupportPredefinedEffect
02cfcf24: tbz     w0, #0, #0x2cfd014                         
02cfcf28: ldr     x0, [x21]                                  S:'{0}/2'
02cfcf2c: ldr     w8, [x0, #0xe4]                            [62650e4]=0 f=0,0
02cfcf30: cbnz    w8, #0x2cfcf3c                             
02cfcf34: bl      #0x2b70f30                                 fn_2b70f30
02cfcf38: ldr     x0, [x21]                                  S:'{0}/2'
02cfcf3c: ldr     x8, [x0, #0xb8]                            T:AdsManager/<>c__DisplayClass42_0
02cfcf40: ldr     x0, [x8, #0x10]                            MS:DG.Tweening.TweenSettingsExtensions::SetLoops
02cfcf44: cbz     x0, #0x2cfd190                             
02cfcf48: adrp    x8, #0x6268000                             
02cfcf4c: adrp    x19, #0x6266000                            
02cfcf50: ldr     x8, [x8, #0xcf0]                           S:'EFFECT_CLICK'
02cfcf54: ldr     x19, [x19, #0x168]                         MS:UnityEngine.AndroidJavaObject::GetStatic
02cfcf58: ldr     x1, [x8]                                   S:'{0}/2'
02cfcf5c: ldr     x2, [x19]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cfcf60: bl      #0x31217c8                                 fn_31217c8
02cfcf64: adrp    x20, #0x6268000                            
02cfcf68: ldr     x20, [x20, #0xce0]                         T:RDG.Vibration/PredefinedEffect
02cfcf6c: ldr     x8, [x20]                                  S:'{0}/2'
02cfcf70: ldr     x8, [x8, #0xb8]                            T:LuckyWheelPopup/<>c__DisplayClass54_0
02cfcf74: str     w0, [x8]                                   
02cfcf78: ldr     x8, [x21]                                  S:'{0}/2'
02cfcf7c: ldr     x8, [x8, #0xb8]                            T:LuckyWheelPopup/<>c__DisplayClass54_0
02cfcf80: ldr     x0, [x8, #0x10]                            MS:DG.Tweening.TweenSettingsExtensions::SetLoops
02cfcf84: cbz     x0, #0x2cfd194                             
02cfcf88: adrp    x8, #0x6268000                             
02cfcf8c: ldr     x8, [x8, #0xd18]                           S:'EFFECT_DOUBLE_CLICK'
02cfcf90: ldr     x2, [x19]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cfcf94: ldr     x1, [x8]                                   S:'{0}/2'
02cfcf98: bl      #0x31217c8                                 fn_31217c8
02cfcf9c: ldr     x8, [x20]                                  S:'{0}/2'
02cfcfa0: ldr     x8, [x8, #0xb8]                            T:LuckyWheelPopup/<>c__DisplayClass54_0
02cfcfa4: str     w0, [x8, #4]                               
02cfcfa8: ldr     x8, [x21]                                  S:'{0}/2'
02cfcfac: ldr     x8, [x8, #0xb8]                            T:LuckyWheelPopup/<>c__DisplayClass54_0
02cfcfb0: ldr     x0, [x8, #0x10]                            MS:DG.Tweening.TweenSettingsExtensions::SetLoops
02cfcfb4: cbz     x0, #0x2cfd198                             
02cfcfb8: adrp    x8, #0x6268000                             
02cfcfbc: ldr     x8, [x8, #0xd28]                           S:'EFFECT_HEAVY_CLICK'
02cfcfc0: ldr     x2, [x19]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cfcfc4: ldr     x1, [x8]                                   S:'{0}/2'
02cfcfc8: bl      #0x31217c8                                 fn_31217c8
02cfcfcc: ldr     x8, [x20]                                  S:'{0}/2'
02cfcfd0: ldr     x9, [x21]                                  S:'{0}/2'
02cfcfd4: ldr     x8, [x8, #0xb8]                            T:LuckyWheelPopup/<>c__DisplayClass54_0
02cfcfd8: str     w0, [x8, #8]                               
02cfcfdc: ldr     x8, [x9, #0xb8]                            S:'banner_native_refresh_time'
02cfcfe0: ldr     x0, [x8, #0x10]                            MS:DG.Tweening.TweenSettingsExtensions::SetLoops
02cfcfe4: cbz     x0, #0x2cfd19c                             
02cfcfe8: adrp    x8, #0x6268000                             
02cfcfec: ldr     x8, [x8, #0xd38]                           S:'EFFECT_TICK'
02cfcff0: ldr     x2, [x19]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cfcff4: ldr     x1, [x8]                                   S:'{0}/2'
02cfcff8: bl      #0x31217c8                                 fn_31217c8
02cfcffc: ldr     x8, [x20]                                  S:'{0}/2'
02cfd000: mov     x19, xzr                                   
02cfd004: mov     w23, wzr                                   
02cfd008: ldr     x8, [x8, #0xb8]                            T:LuckyWheelPopup/<>c__DisplayClass54_0
02cfd00c: str     w0, [x8, #0xc]                             
02cfd010: b       #0x2cfd01c                                 
02cfd014: mov     x19, xzr                                   
02cfd018: mov     w23, wzr                                   
02cfd01c: mov     w22, #7                                    
02cfd020: add     x8, sp, #0x28                              
02cfd024: ldr     x20, [x8]                                  S:'{0}/2'
02cfd028: cbz     x20, #0x2cfd08c                            
02cfd02c: adrp    x10, #0x6263000                            
02cfd030: ldr     x8, [x20]                                  S:'{0}/2'
02cfd034: ldr     x10, [x10, #0x980]                         T:System.IDisposable
02cfd038: ldrh    w9, [x8, #0x12e]                           
02cfd03c: ldr     x1, [x10]                                  &2c5bbd4(=a9bd7bfdd503233f)
02cfd040: cbz     x9, #0x2cfd064                             
02cfd044: ldr     x10, [x8, #0xb0]                           S:'penguin_close_mouth'
02cfd048: add     x10, x10, #8                               &6263008
02cfd04c: ldur    x11, [x10, #-8]                            
02cfd050: cmp     x11, x1                                    
02cfd054: b.eq    #0x2cfd074                                 
02cfd058: subs    x9, x9, #1                                 
02cfd05c: add     x10, x10, #0x10                            &6263010
02cfd060: b.ne    #0x2cfd04c                                 
02cfd064: mov     x0, x20                                    
02cfd068: mov     w2, wzr                                    
02cfd06c: bl      #0x2baa05c                                 fn_2baa05c
02cfd070: b       #0x2cfd080                                 
02cfd074: ldrsw   x9, [x10]                                  
02cfd078: add     x8, x8, x9, lsl #4                         &6268000
02cfd07c: add     x0, x8, #0x138                             &6268138
02cfd080: ldp     x8, x1, [x0]                               
02cfd084: mov     x0, x20                                    
02cfd088: blr     x8                                         
02cfd08c: cbnz    x19, #0x2cfd170                            
02cfd090: tbz     w23, #0, #0x2cfd098                        
02cfd094: mov     w22, wzr                                   
02cfd098: ldr     x8, [sp, #0x20]                            
02cfd09c: ldr     x19, [x8]                                  S:'{0}/2'
02cfd0a0: cbz     x19, #0x2cfd104                            
02cfd0a4: adrp    x10, #0x6263000                            
02cfd0a8: ldr     x8, [x19]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cfd0ac: ldr     x10, [x10, #0x980]                         T:System.IDisposable
02cfd0b0: ldrh    w9, [x8, #0x12e]                           
02cfd0b4: ldr     x1, [x10]                                  &2c5bbd4(=a9bd7bfdd503233f)
02cfd0b8: cbz     x9, #0x2cfd0dc                             
02cfd0bc: ldr     x10, [x8, #0xb0]                           S:'penguin_close_mouth'
02cfd0c0: add     x10, x10, #8                               &6263008
02cfd0c4: ldur    x11, [x10, #-8]                            
02cfd0c8: cmp     x11, x1                                    
02cfd0cc: b.eq    #0x2cfd0ec                                 
02cfd0d0: subs    x9, x9, #1                                 
02cfd0d4: add     x10, x10, #0x10                            &6263010
02cfd0d8: b.ne    #0x2cfd0c4                                 
02cfd0dc: mov     x0, x19                                    
02cfd0e0: mov     w2, wzr                                    
02cfd0e4: bl      #0x2baa05c                                 fn_2baa05c
02cfd0e8: b       #0x2cfd0f8                                 
02cfd0ec: ldrsw   x9, [x10]                                  
02cfd0f0: add     x8, x8, x9, lsl #4                         &6268000
02cfd0f4: add     x0, x8, #0x138                             &6268138
02cfd0f8: ldp     x8, x1, [x0]                               
02cfd0fc: mov     x0, x19                                    
02cfd100: blr     x8                                         
02cfd104: ldr     x0, [sp, #0x18]                            
02cfd108: cbnz    x0, #0x2cfd168                             
02cfd10c: cmp     w22, #7                                    
02cfd110: b.eq    #0x2cfd118                                 
02cfd114: cbnz    w22, #0x2cfd14c                            
02cfd118: ldr     x0, [x21]                                  S:'{0}/2'
02cfd11c: ldr     w8, [x0, #0xe4]                            [62650e4]=0 f=0,0
02cfd120: cbnz    w8, #0x2cfd128                             
02cfd124: bl      #0x2b70f30                                 fn_2b70f30
02cfd128: adrp    x8, #0x6268000                             
02cfd12c: mov     w1, #1                                     
02cfd130: mov     w19, #1                                    
02cfd134: ldr     x8, [x8, #0xd30]                           S:'Vibration component initialized'
02cfd138: ldr     x0, [x8]                                   S:'{0}/2'
02cfd13c: bl      #0x2cfd2ac                                 RDG.Vibration::logAuto
02cfd140: ldr     x8, [x21]                                  S:'{0}/2'
02cfd144: ldr     x8, [x8, #0xb8]                            T:LuckyWheelPopup/<>c__DisplayClass54_0
02cfd148: strb    w19, [x8, #0x20]                           
02cfd14c: ldp     x20, x19, [sp, #0x60]                      
02cfd150: ldp     x22, x21, [sp, #0x50]                      
02cfd154: ldp     x30, x23, [sp, #0x40]                      
02cfd158: add     sp, sp, #0x70                              
02cfd15c: ret                                                
02cfd160: bl      #0x2b7105c                                 fn_2b7105c
02cfd164: mov     x0, x19                                    
02cfd168: bl      #0x2b71054                                 fn_2b71054
02cfd16c: bl      #0x2b7105c                                 fn_2b7105c
02cfd170: mov     x0, x19                                    
02cfd174: bl      #0x2b71054                                 fn_2b71054
02cfd178: bl      #0x2b7105c                                 fn_2b7105c
02cfd17c: bl      #0x2b71064                                 fn_2b71064
02cfd180: bl      #0x2b71080                                 fn_2b71080
02cfd184: mov     x1, xzr                                    
02cfd188: bl      #0x2b70f20                                 fn_2b70f20
02cfd18c: bl      #0x2b7105c                                 fn_2b7105c
02cfd190: bl      #0x2b7105c                                 fn_2b7105c
02cfd194: bl      #0x2b7105c                                 fn_2b7105c
02cfd198: bl      #0x2b7105c                                 fn_2b7105c
02cfd19c: bl      #0x2b7105c                                 fn_2b7105c
02cfd1a0: b       #0x2cfd230                                 
02cfd1a4: b       #0x2cfd230                                 
02cfd1a8: b       #0x2cfd230                                 
02cfd1ac: b       #0x2cfd230                                 
02cfd1b0: b       #0x2cfd230                                 
02cfd1b4: b       #0x2cfd230                                 
02cfd1b8: b       #0x2cfd230                                 
02cfd1bc: b       #0x2cfd230                                 
02cfd1c0: b       #0x2cfd230                                 
02cfd1c4: b       #0x2cfd230                                 
02cfd1c8: b       #0x2cfd230                                 
02cfd1cc: b       #0x2cfd230                                 
02cfd1d0: b       #0x2cfd230                                 
02cfd1d4: b       #0x2cfd230                                 
02cfd1d8: b       #0x2cfd224                                 
02cfd1dc: b       #0x2cfd224                                 
02cfd1e0: b       #0x2cfd1e8                                 
02cfd1e4: b       #0x2cfd230                                 
02cfd1e8: mov     x19, x0                                    
02cfd1ec: cmp     w1, #1                                     
02cfd1f0: b.ne    #0x2cfd214                                 
02cfd1f4: mov     x0, x19                                    
02cfd1f8: bl      #0x5e90260                                 fn_5e90260
02cfd1fc: ldr     x19, [x0]                                  M:AdsManager::<OnApplicationPause>b__26_0
02cfd200: str     x19, [sp, #0x18]                           
02cfd204: bl      #0x5e90270                                 fn_5e90270
02cfd208: ldr     x8, [sp, #0x20]                            
02cfd20c: b       #0x2cfccf4                                 
02cfd210: mov     x19, x0                                    
02cfd214: add     x0, sp, #0x18                              
02cfd218: bl      #0x27369c4                                 fn_27369c4
02cfd21c: b       #0x2cfd2a0                                 
02cfd220: b       #0x2cfd230                                 
02cfd224: mov     x20, x1                                    
02cfd228: mov     x19, x0                                    
02cfd22c: b       #0x2cfd274                                 
02cfd230: mov     x20, x1                                    
02cfd234: mov     x19, x0                                    
02cfd238: cmp     w20, #1                                    
02cfd23c: b.ne    #0x2cfd26c                                 
02cfd240: mov     x0, x19                                    
02cfd244: bl      #0x5e90260                                 fn_5e90260
02cfd248: ldr     x19, [x0]                                  M:AdsManager::<OnApplicationPause>b__26_0
02cfd24c: str     x19, [sp, #8]                              
02cfd250: bl      #0x5e90270                                 fn_5e90270
02cfd254: ldr     x8, [sp, #0x10]                            
02cfd258: mov     w22, wzr                                   
02cfd25c: mov     w23, #1                                    
02cfd260: b       #0x2cfd024                                 
02cfd264: mov     x20, x1                                    
02cfd268: mov     x19, x0                                    
02cfd26c: add     x0, sp, #8                                 
02cfd270: bl      #0x27369c4                                 fn_27369c4
02cfd274: cmp     w20, #1                                    
02cfd278: b.ne    #0x2cfd298                                 
02cfd27c: mov     x0, x19                                    
02cfd280: bl      #0x5e90260                                 fn_5e90260
02cfd284: ldr     x8, [x0]                                   M:AdsManager::<OnApplicationPause>b__26_0
02cfd288: str     x8, [sp, #0x18]                            
02cfd28c: bl      #0x5e90270                                 fn_5e90270
02cfd290: b       #0x2cfd094                                 
02cfd294: mov     x19, x0                                    
02cfd298: add     x0, sp, #0x18                              
02cfd29c: bl      #0x27369c4                                 fn_27369c4
02cfd2a0: mov     x0, x19                                    
02cfd2a4: bl      #0x2c6051c                                 fn_2c6051c
02cfd2a8: bl      #0x27369b8                                 fn_27369b8
## Vibrate(long milliseconds, int amplitude, bool cancel) -> void
---- RDG.Vibration::Vibrate 0x2cfd3c0
02cfd3c0: sub     sp, sp, #0x50                              
02cfd3c4: str     x30, [sp, #0x10]                           
02cfd3c8: stp     x24, x23, [sp, #0x20]                      
02cfd3cc: stp     x22, x21, [sp, #0x30]                      
02cfd3d0: stp     x20, x19, [sp, #0x40]                      
02cfd3d4: adrp    x24, #0x662f000                            
02cfd3d8: adrp    x22, #0x6268000                            
02cfd3dc: mov     w21, w2                                    
02cfd3e0: ldrb    w8, [x24, #0xee0]                          
02cfd3e4: ldr     x22, [x22, #0xcd8]                         T:RDG.Vibration
02cfd3e8: mov     w20, w1                                    
02cfd3ec: mov     x19, x0                                    
02cfd3f0: and     w23, w2, #1                                
02cfd3f4: tbnz    w8, #0, #0x2cfd448                         
02cfd3f8: adrp    x0, #0x6268000                             
02cfd3fc: ldr     x0, [x0, #0xcd8]                           T:RDG.Vibration
02cfd400: bl      #0x2b70db0                                 fn_2b70db0
02cfd404: adrp    x0, #0x6268000                             
02cfd408: ldr     x0, [x0, #0xd40]                           S:": Device doesn't have Amplitude Control, but Amplitude was set"
02cfd40c: bl      #0x2b70db0                                 fn_2b70db0
02cfd410: adrp    x0, #0x6268000                             
02cfd414: ldr     x0, [x0, #0xd48]                           S:": Device doesn't have Vibrator"
02cfd418: bl      #0x2b70db0                                 fn_2b70db0
02cfd41c: adrp    x0, #0x6268000                             
02cfd420: ldr     x0, [x0, #0xd50]                           S:': Not initialized'
02cfd424: bl      #0x2b70db0                                 fn_2b70db0
02cfd428: adrp    x0, #0x6268000                             
02cfd42c: ldr     x0, [x0, #0xd58]                           S:': Effect called'
02cfd430: bl      #0x2b70db0                                 fn_2b70db0
02cfd434: adrp    x0, #0x6268000                             
02cfd438: ldr     x0, [x0, #0xd60]                           S:': Legacy called'
02cfd43c: bl      #0x2b70db0                                 fn_2b70db0
02cfd440: mov     w8, #1                                     
02cfd444: strb    w8, [x24, #0xee0]                          
02cfd448: ldr     x0, [x22]                                  S:'{0}/2'
02cfd44c: stp     x19, xzr, [sp]                             
02cfd450: str     w20, [sp, #8]                              
02cfd454: ldr     w8, [x0, #0xe4]                            [62680e4]=0 f=0,0
02cfd458: strb    w23, [sp, #0xc]                            
02cfd45c: cbnz    w8, #0x2cfd464                             
02cfd460: bl      #0x2b70f30                                 fn_2b70f30
02cfd464: bl      #0x2cfcacc                                 RDG.Vibration::Initialize
02cfd468: ldr     x0, [x22]                                  S:'{0}/2'
02cfd46c: ldr     x8, [x0, #0xb8]                            T:LuckyWheelPopup/<>c__DisplayClass54_0
02cfd470: ldrb    w9, [x8, #0x20]                            
02cfd474: ldr     w8, [x0, #0xe4]                            [62680e4]=0 f=0,0
02cfd478: cbz     w9, #0x2cfd540                             
02cfd47c: cbnz    w8, #0x2cfd484                             
02cfd480: bl      #0x2b70f30                                 fn_2b70f30
02cfd484: bl      #0x2cfd6ec                                 RDG.Vibration::HasVibrator
02cfd488: tbz     w0, #0, #0x2cfd558                         
02cfd48c: tbz     w21, #0, #0x2cfd4a4                        
02cfd490: ldr     x0, [x22]                                  S:'{0}/2'
02cfd494: ldr     w8, [x0, #0xe4]                            [62680e4]=0 f=0,0
02cfd498: cbnz    w8, #0x2cfd4a0                             
02cfd49c: bl      #0x2b70f30                                 fn_2b70f30
02cfd4a0: bl      #0x2cfd818                                 RDG.Vibration::Cancel
02cfd4a4: ldr     x0, [x22]                                  S:'{0}/2'
02cfd4a8: ldr     w8, [x0, #0xe4]                            [62680e4]=0 f=0,0
02cfd4ac: cbnz    w8, #0x2cfd4b4                             
02cfd4b0: bl      #0x2b70f30                                 fn_2b70f30
02cfd4b4: bl      #0x2cfca0c                                 RDG.Vibration::doesSupportVibrationEffect
02cfd4b8: tbz     w0, #0, #0x2cfd578                         
02cfd4bc: cmp     w20, #0xff                                 
02cfd4c0: mov     w23, #0xff                                 
02cfd4c4: ldr     x0, [x22]                                  S:'{0}/2'
02cfd4c8: csel    w8, w20, w23, lt                           
02cfd4cc: cmp     w8, #0                                     
02cfd4d0: csinv   w21, w8, wzr, ge                           
02cfd4d4: cmp     w20, #0                                    
02cfd4d8: csel    w20, w23, w21, lt                          
02cfd4dc: cmp     w20, #0xff                                 
02cfd4e0: str     w20, [sp, #8]                              
02cfd4e4: b.eq    #0x2cfd5b8                                 
02cfd4e8: ldr     w8, [x0, #0xe4]                            [62680e4]=0 f=0,0
02cfd4ec: cbnz    w8, #0x2cfd4f4                             
02cfd4f0: bl      #0x2b70f30                                 fn_2b70f30
02cfd4f4: bl      #0x2cfd948                                 RDG.Vibration::HasAmplitudeControl
02cfd4f8: tbnz    w0, #0, #0x2cfd530                         
02cfd4fc: ldr     x0, [x22]                                  S:'{0}/2'
02cfd500: ldr     w8, [x0, #0xe4]                            [62680e4]=0 f=0,0
02cfd504: cbnz    w8, #0x2cfd50c                             
02cfd508: bl      #0x2b70f30                                 fn_2b70f30
02cfd50c: mov     x0, sp                                     
02cfd510: bl      #0x2cfd634                                 RDG.Vibration::<Vibrate>g__funcToStr|9_0
02cfd514: adrp    x8, #0x6268000                             
02cfd518: mov     x2, xzr                                    
02cfd51c: ldr     x8, [x8, #0xd40]                           S:": Device doesn't have Amplitude Control, but Amplitude was set"
02cfd520: ldr     x1, [x8]                                   S:'{0}/2'
02cfd524: bl      #0x4c9c514                                 System.String::Concat
02cfd528: mov     w1, #2                                     
02cfd52c: bl      #0x2cfd2ac                                 RDG.Vibration::logAuto
02cfd530: ldr     x0, [x22]                                  S:'{0}/2'
02cfd534: cbz     w20, #0x2cfd59c                            
02cfd538: mov     w23, w21                                   
02cfd53c: b       #0x2cfd5b8                                 
02cfd540: cbnz    w8, #0x2cfd548                             
02cfd544: bl      #0x2b70f30                                 fn_2b70f30
02cfd548: adrp    x20, #0x6268000                            
02cfd54c: mov     w19, #2                                    
02cfd550: ldr     x20, [x20, #0xd50]                         S:': Not initialized'
02cfd554: b       #0x2cfd604                                 
02cfd558: ldr     x0, [x22]                                  S:'{0}/2'
02cfd55c: ldr     w8, [x0, #0xe4]                            [62680e4]=0 f=0,0
02cfd560: cbnz    w8, #0x2cfd568                             
02cfd564: bl      #0x2b70f30                                 fn_2b70f30
02cfd568: adrp    x20, #0x6268000                            
02cfd56c: mov     w19, #2                                    
02cfd570: ldr     x20, [x20, #0xd48]                         S:": Device doesn't have Vibrator"
02cfd574: b       #0x2cfd604                                 
02cfd578: ldr     x0, [x22]                                  S:'{0}/2'
02cfd57c: ldr     w8, [x0, #0xe4]                            [62680e4]=0 f=0,0
02cfd580: cbnz    w8, #0x2cfd588                             
02cfd584: bl      #0x2b70f30                                 fn_2b70f30
02cfd588: mov     x0, x19                                    
02cfd58c: bl      #0x2cfdc94                                 RDG.Vibration::vibrateLegacy
02cfd590: adrp    x20, #0x6268000                            
02cfd594: ldr     x20, [x20, #0xd60]                         S:': Legacy called'
02cfd598: b       #0x2cfd600                                 
02cfd59c: ldr     w8, [x0, #0xe4]                            [62680e4]=0 f=0,0
02cfd5a0: cbnz    w8, #0x2cfd5ac                             
02cfd5a4: bl      #0x2b70f30                                 fn_2b70f30
02cfd5a8: ldr     x0, [x22]                                  S:'{0}/2'
02cfd5ac: ldr     x8, [x0, #0xb8]                            T:LuckyWheelPopup/<>c__DisplayClass54_0
02cfd5b0: ldr     w23, [x8, #0x18]                           M:LuckyWheelPopup/<>c__DisplayClass50_0::<RunAnimation>b__0
02cfd5b4: str     w23, [sp, #8]                              
02cfd5b8: ldr     w8, [x0, #0xe4]                            [62680e4]=0 f=0,0
02cfd5bc: cbnz    w8, #0x2cfd5c4                             
02cfd5c0: bl      #0x2b70f30                                 fn_2b70f30
02cfd5c4: bl      #0x2cfd948                                 RDG.Vibration::HasAmplitudeControl
02cfd5c8: mov     w8, w0                                     
02cfd5cc: ldr     x0, [x22]                                  S:'{0}/2'
02cfd5d0: tst     w8, #1                                     
02cfd5d4: mov     w8, #0xff                                  
02cfd5d8: ldr     w9, [x0, #0xe4]                            [62680e4]=0 f=0,0
02cfd5dc: csel    w20, w23, w8, ne                           
02cfd5e0: str     w20, [sp, #8]                              
02cfd5e4: cbnz    w9, #0x2cfd5ec                             
02cfd5e8: bl      #0x2b70f30                                 fn_2b70f30
02cfd5ec: mov     x0, x19                                    
02cfd5f0: mov     w1, w20                                    
02cfd5f4: bl      #0x2cfda88                                 RDG.Vibration::vibrateEffect
02cfd5f8: adrp    x20, #0x6268000                            
02cfd5fc: ldr     x20, [x20, #0xd58]                         S:': Effect called'
02cfd600: mov     w19, #1                                    
02cfd604: mov     x0, sp                                     
02cfd608: bl      #0x2cfd634                                 RDG.Vibration::<Vibrate>g__funcToStr|9_0
02cfd60c: ldr     x1, [x20]                                  S:'{0}/2'
02cfd610: mov     x2, xzr                                    
02cfd614: bl      #0x4c9c514                                 System.String::Concat
02cfd618: mov     w1, w19                                    
02cfd61c: ldp     x20, x19, [sp, #0x40]                      
02cfd620: ldp     x22, x21, [sp, #0x30]                      
02cfd624: ldr     x30, [sp, #0x10]                           
02cfd628: ldp     x24, x23, [sp, #0x20]                      
02cfd62c: add     sp, sp, #0x50                              
02cfd630: b       #0x2cfd2ac                                 RDG.Vibration::logAuto
## Vibrate(long[] pattern, int[] amplitudes, int repeat, bool cancel) -> void
---- RDG.Vibration::Vibrate 0x2cfddac
02cfddac: sub     sp, sp, #0x60                              
02cfddb0: str     x30, [sp, #0x20]                           
02cfddb4: stp     x24, x23, [sp, #0x30]                      
02cfddb8: stp     x22, x21, [sp, #0x40]                      
02cfddbc: stp     x20, x19, [sp, #0x50]                      
02cfddc0: adrp    x23, #0x662f000                            
02cfddc4: adrp    x22, #0x6268000                            
02cfddc8: mov     w19, w2                                    
02cfddcc: ldrb    w8, [x23, #0xee1]                          
02cfddd0: ldr     x22, [x22, #0xcd8]                         T:RDG.Vibration
02cfddd4: mov     x20, x1                                    
02cfddd8: mov     x21, x0                                    
02cfdddc: and     w24, w3, #1                                
02cfdde0: tbnz    w8, #0, #0x2cfde4c                         
02cfdde4: adrp    x0, #0x6268000                             
02cfdde8: ldr     x0, [x0, #0xcd8]                           T:RDG.Vibration
02cfddec: bl      #0x2b70db0                                 fn_2b70db0
02cfddf0: adrp    x0, #0x6268000                             
02cfddf4: ldr     x0, [x0, #0xd98]                           S:": Device doesn't have Amplitude Control, but Amplitudes was set"
02cfddf8: bl      #0x2b70db0                                 fn_2b70db0
02cfddfc: adrp    x0, #0x6268000                             
02cfde00: ldr     x0, [x0, #0xda0]                           S:': Effect with amplitudes called'
02cfde04: bl      #0x2b70db0                                 fn_2b70db0
02cfde08: adrp    x0, #0x6268000                             
02cfde0c: ldr     x0, [x0, #0xda8]                           S:': Length of Amplitudes array is not equal to Pattern array. Amplitudes'
02cfde10: bl      #0x2b70db0                                 fn_2b70db0
02cfde14: adrp    x0, #0x6268000                             
02cfde18: ldr     x0, [x0, #0xd48]                           S:": Device doesn't have Vibrator"
02cfde1c: bl      #0x2b70db0                                 fn_2b70db0
02cfde20: adrp    x0, #0x6268000                             
02cfde24: ldr     x0, [x0, #0xd50]                           S:': Not initialized'
02cfde28: bl      #0x2b70db0                                 fn_2b70db0
02cfde2c: adrp    x0, #0x6268000                             
02cfde30: ldr     x0, [x0, #0xd58]                           S:': Effect called'
02cfde34: bl      #0x2b70db0                                 fn_2b70db0
02cfde38: adrp    x0, #0x6268000                             
02cfde3c: ldr     x0, [x0, #0xd60]                           S:': Legacy called'
02cfde40: bl      #0x2b70db0                                 fn_2b70db0
02cfde44: mov     w8, #1                                     
02cfde48: strb    w8, [x23, #0xee1]                          
02cfde4c: add     x0, sp, #8                                 
02cfde50: mov     x1, x21                                    
02cfde54: stp     xzr, xzr, [sp, #0x10]                      
02cfde58: add     x23, sp, #8                                
02cfde5c: str     x21, [sp, #8]                              
02cfde60: bl      #0x2b70d54                                 fn_2b70d54
02cfde64: add     x0, x23, #8                                &662f008
02cfde68: mov     x1, x20                                    
02cfde6c: str     x20, [sp, #0x10]                           
02cfde70: bl      #0x2b70d54                                 fn_2b70d54
02cfde74: ldr     x0, [x22]                                  S:'{0}/2'
02cfde78: str     w19, [sp, #0x18]                           
02cfde7c: strb    w24, [sp, #0x1c]                           
02cfde80: ldr     w8, [x0, #0xe4]                            [62680e4]=0 f=0,0
02cfde84: cbnz    w8, #0x2cfde8c                             
02cfde88: bl      #0x2b70f30                                 fn_2b70f30
02cfde8c: bl      #0x2cfcacc                                 RDG.Vibration::Initialize
02cfde90: ldr     x0, [x22]                                  S:'{0}/2'
02cfde94: ldr     x8, [x0, #0xb8]                            T:LuckyWheelPopup/<>c__DisplayClass54_0
02cfde98: ldrb    w9, [x8, #0x20]                            
02cfde9c: ldr     w8, [x0, #0xe4]                            [62680e4]=0 f=0,0
02cfdea0: cbz     w9, #0x2cfe00c                             
02cfdea4: cbnz    w8, #0x2cfdeac                             
02cfdea8: bl      #0x2b70f30                                 fn_2b70f30
02cfdeac: bl      #0x2cfd6ec                                 RDG.Vibration::HasVibrator
02cfdeb0: tbz     w0, #0, #0x2cfe024                         
02cfdeb4: ldr     x19, [sp, #0x10]                           
02cfdeb8: cbz     x19, #0x2cfdf38                            
02cfdebc: ldr     x8, [sp, #8]                               
02cfdec0: cbz     x8, #0x2cfe0d8                             
02cfdec4: ldr     w9, [x19, #0x18]                           .defaultAmplitude
02cfdec8: ldr     w8, [x8, #0x18]                            
02cfdecc: cmp     w9, w8                                     
02cfded0: b.eq    #0x2cfdf20                                 
02cfded4: ldr     x0, [x22]                                  S:'{0}/2'
02cfded8: ldr     w8, [x0, #0xe4]                            [62680e4]=0 f=0,0
02cfdedc: cbnz    w8, #0x2cfdee4                             
02cfdee0: bl      #0x2b70f30                                 fn_2b70f30
02cfdee4: add     x0, sp, #8                                 
02cfdee8: bl      #0x2cfe0dc                                 RDG.Vibration::<Vibrate>g__funcToStr|10_0
02cfdeec: adrp    x8, #0x6268000                             
02cfdef0: mov     x2, xzr                                    
02cfdef4: ldr     x8, [x8, #0xda8]                           S:': Length of Amplitudes array is not equal to Pattern array. Amplitudes'
02cfdef8: ldr     x1, [x8]                                   S:'{0}/2'
02cfdefc: bl      #0x4c9c514                                 System.String::Concat
02cfdf00: mov     w1, #2                                     
02cfdf04: bl      #0x2cfd2ac                                 RDG.Vibration::logAuto
02cfdf08: add     x0, x23, #8                                &662f008
02cfdf0c: mov     x1, xzr                                    
02cfdf10: str     xzr, [sp, #0x10]                           
02cfdf14: bl      #0x2b70d54                                 fn_2b70d54
02cfdf18: ldr     x19, [sp, #0x10]                           
02cfdf1c: cbz     x19, #0x2cfdf38                            
02cfdf20: ldr     x0, [x22]                                  S:'{0}/2'
02cfdf24: ldr     w8, [x0, #0xe4]                            [62680e4]=0 f=0,0
02cfdf28: cbnz    w8, #0x2cfdf30                             
02cfdf2c: bl      #0x2b70f30                                 fn_2b70f30
02cfdf30: mov     x0, x19                                    
02cfdf34: bl      #0x2cfe2b8                                 RDG.Vibration::clampAmplitudesArray
02cfdf38: ldrb    w8, [sp, #0x1c]                            
02cfdf3c: tbz     w8, #0, #0x2cfdf54                         
02cfdf40: ldr     x0, [x22]                                  S:'{0}/2'
02cfdf44: ldr     w8, [x0, #0xe4]                            [62680e4]=0 f=0,0
02cfdf48: cbnz    w8, #0x2cfdf50                             
02cfdf4c: bl      #0x2b70f30                                 fn_2b70f30
02cfdf50: bl      #0x2cfd818                                 RDG.Vibration::Cancel
02cfdf54: ldr     x0, [x22]                                  S:'{0}/2'
02cfdf58: ldr     w8, [x0, #0xe4]                            [62680e4]=0 f=0,0
02cfdf5c: cbnz    w8, #0x2cfdf64                             
02cfdf60: bl      #0x2b70f30                                 fn_2b70f30
02cfdf64: bl      #0x2cfca0c                                 RDG.Vibration::doesSupportVibrationEffect
02cfdf68: tbz     w0, #0, #0x2cfe044                         
02cfdf6c: ldr     x8, [sp, #0x10]                            
02cfdf70: cbz     x8, #0x2cfe074                             
02cfdf74: ldr     x0, [x22]                                  S:'{0}/2'
02cfdf78: ldr     w8, [x0, #0xe4]                            [62680e4]=0 f=0,0
02cfdf7c: cbnz    w8, #0x2cfdf84                             
02cfdf80: bl      #0x2b70f30                                 fn_2b70f30
02cfdf84: bl      #0x2cfd948                                 RDG.Vibration::HasAmplitudeControl
02cfdf88: tbnz    w0, #0, #0x2cfdfd0                         
02cfdf8c: ldr     x0, [x22]                                  S:'{0}/2'
02cfdf90: ldr     w8, [x0, #0xe4]                            [62680e4]=0 f=0,0
02cfdf94: cbnz    w8, #0x2cfdf9c                             
02cfdf98: bl      #0x2b70f30                                 fn_2b70f30
02cfdf9c: add     x0, sp, #8                                 
02cfdfa0: bl      #0x2cfe0dc                                 RDG.Vibration::<Vibrate>g__funcToStr|10_0
02cfdfa4: adrp    x8, #0x6268000                             
02cfdfa8: mov     x2, xzr                                    
02cfdfac: ldr     x8, [x8, #0xd98]                           S:": Device doesn't have Amplitude Control, but Amplitudes was set"
02cfdfb0: ldr     x1, [x8]                                   S:'{0}/2'
02cfdfb4: bl      #0x4c9c514                                 System.String::Concat
02cfdfb8: mov     w1, #2                                     
02cfdfbc: bl      #0x2cfd2ac                                 RDG.Vibration::logAuto
02cfdfc0: add     x0, x23, #8                                &662f008
02cfdfc4: mov     x1, xzr                                    
02cfdfc8: str     xzr, [sp, #0x10]                           
02cfdfcc: bl      #0x2b70d54                                 fn_2b70d54
02cfdfd0: ldr     x19, [sp, #0x10]                           
02cfdfd4: cbz     x19, #0x2cfe074                            
02cfdfd8: ldr     x0, [x22]                                  S:'{0}/2'
02cfdfdc: ldr     x21, [sp, #8]                              
02cfdfe0: ldr     w20, [sp, #0x18]                           
02cfdfe4: ldr     w8, [x0, #0xe4]                            [62680e4]=0 f=0,0
02cfdfe8: cbnz    w8, #0x2cfdff0                             
02cfdfec: bl      #0x2b70f30                                 fn_2b70f30
02cfdff0: mov     x0, x21                                    
02cfdff4: mov     x1, x19                                    
02cfdff8: mov     w2, w20                                    
02cfdffc: bl      #0x2cfe314                                 RDG.Vibration::vibrateEffect
02cfe000: adrp    x20, #0x6268000                            
02cfe004: ldr     x20, [x20, #0xda0]                         S:': Effect with amplitudes called'
02cfe008: b       #0x2cfe0a0                                 
02cfe00c: cbnz    w8, #0x2cfe014                             
02cfe010: bl      #0x2b70f30                                 fn_2b70f30
02cfe014: adrp    x20, #0x6268000                            
02cfe018: mov     w19, #2                                    
02cfe01c: ldr     x20, [x20, #0xd50]                         S:': Not initialized'
02cfe020: b       #0x2cfe0a4                                 
02cfe024: ldr     x0, [x22]                                  S:'{0}/2'
02cfe028: ldr     w8, [x0, #0xe4]                            [62680e4]=0 f=0,0
02cfe02c: cbnz    w8, #0x2cfe034                             
02cfe030: bl      #0x2b70f30                                 fn_2b70f30
02cfe034: adrp    x20, #0x6268000                            
02cfe038: mov     w19, #2                                    
02cfe03c: ldr     x20, [x20, #0xd48]                         S:": Device doesn't have Vibrator"
02cfe040: b       #0x2cfe0a4                                 
02cfe044: ldr     x0, [x22]                                  S:'{0}/2'
02cfe048: ldr     x19, [sp, #8]                              
02cfe04c: ldr     w20, [sp, #0x18]                           
02cfe050: ldr     w8, [x0, #0xe4]                            [62680e4]=0 f=0,0
02cfe054: cbnz    w8, #0x2cfe05c                             
02cfe058: bl      #0x2b70f30                                 fn_2b70f30
02cfe05c: mov     x0, x19                                    
02cfe060: mov     w1, w20                                    
02cfe064: bl      #0x2cfe734                                 RDG.Vibration::vibrateLegacy
02cfe068: adrp    x20, #0x6268000                            
02cfe06c: ldr     x20, [x20, #0xd60]                         S:': Legacy called'
02cfe070: b       #0x2cfe0a0                                 
02cfe074: ldr     x0, [x22]                                  S:'{0}/2'
02cfe078: ldr     x19, [sp, #8]                              
02cfe07c: ldr     w20, [sp, #0x18]                           
02cfe080: ldr     w8, [x0, #0xe4]                            [62680e4]=0 f=0,0
02cfe084: cbnz    w8, #0x2cfe08c                             
02cfe088: bl      #0x2b70f30                                 fn_2b70f30
02cfe08c: mov     x0, x19                                    
02cfe090: mov     w1, w20                                    
02cfe094: bl      #0x2cfe528                                 RDG.Vibration::vibrateEffect
02cfe098: adrp    x20, #0x6268000                            
02cfe09c: ldr     x20, [x20, #0xd58]                         S:': Effect called'
02cfe0a0: mov     w19, #1                                    
02cfe0a4: add     x0, sp, #8                                 
02cfe0a8: bl      #0x2cfe0dc                                 RDG.Vibration::<Vibrate>g__funcToStr|10_0
02cfe0ac: ldr     x1, [x20]                                  S:'{0}/2'
02cfe0b0: mov     x2, xzr                                    
02cfe0b4: bl      #0x4c9c514                                 System.String::Concat
02cfe0b8: mov     w1, w19                                    
02cfe0bc: bl      #0x2cfd2ac                                 RDG.Vibration::logAuto
02cfe0c0: ldp     x20, x19, [sp, #0x50]                      
02cfe0c4: ldr     x30, [sp, #0x20]                           
02cfe0c8: ldp     x22, x21, [sp, #0x40]                      
02cfe0cc: ldp     x24, x23, [sp, #0x30]                      
02cfe0d0: add     sp, sp, #0x60                              
02cfe0d4: ret                                                
02cfe0d8: bl      #0x2b7105c                                 fn_2b7105c
## VibratePredefined(int effectId, bool cancel) -> void
---- RDG.Vibration::VibratePredefined 0x2cfe884
02cfe884: str     x30, [sp, #-0x30]!                         
02cfe888: stp     x22, x21, [sp, #0x10]                      
02cfe88c: stp     x20, x19, [sp, #0x20]                      
02cfe890: adrp    x22, #0x662f000                            
02cfe894: adrp    x21, #0x6268000                            
02cfe898: mov     w20, w1                                    
02cfe89c: ldrb    w8, [x22, #0xee2]                          
02cfe8a0: ldr     x21, [x21, #0xcd8]                         T:RDG.Vibration
02cfe8a4: mov     w19, w0                                    
02cfe8a8: tbnz    w8, #0, #0x2cfe8f0                         
02cfe8ac: adrp    x0, #0x6268000                             
02cfe8b0: ldr     x0, [x0, #0xcd8]                           T:RDG.Vibration
02cfe8b4: bl      #0x2b70db0                                 fn_2b70db0
02cfe8b8: adrp    x0, #0x6268000                             
02cfe8bc: ldr     x0, [x0, #0xdb8]                           S:': Predefined effect called'
02cfe8c0: bl      #0x2b70db0                                 fn_2b70db0
02cfe8c4: adrp    x0, #0x6268000                             
02cfe8c8: ldr     x0, [x0, #0xd48]                           S:": Device doesn't have Vibrator"
02cfe8cc: bl      #0x2b70db0                                 fn_2b70db0
02cfe8d0: adrp    x0, #0x6268000                             
02cfe8d4: ldr     x0, [x0, #0xd50]                           S:': Not initialized'
02cfe8d8: bl      #0x2b70db0                                 fn_2b70db0
02cfe8dc: adrp    x0, #0x6268000                             
02cfe8e0: ldr     x0, [x0, #0xdc0]                           S:": Device doesn't support Predefined Effects (Api Level >= 29)"
02cfe8e4: bl      #0x2b70db0                                 fn_2b70db0
02cfe8e8: mov     w8, #1                                     
02cfe8ec: strb    w8, [x22, #0xee2]                          
02cfe8f0: ldr     x0, [x21]                                  S:'{0}/2'
02cfe8f4: str     w19, [sp, #0xc]                            
02cfe8f8: ldr     w8, [x0, #0xe4]                            [62680e4]=0 f=0,0
02cfe8fc: cbnz    w8, #0x2cfe904                             
02cfe900: bl      #0x2b70f30                                 fn_2b70f30
02cfe904: bl      #0x2cfcacc                                 RDG.Vibration::Initialize
02cfe908: ldr     x0, [x21]                                  S:'{0}/2'
02cfe90c: ldr     x8, [x0, #0xb8]                            T:LuckyWheelPopup/<>c__DisplayClass54_0
02cfe910: ldrb    w9, [x8, #0x20]                            
02cfe914: ldr     w8, [x0, #0xe4]                            [62680e4]=0 f=0,0
02cfe918: cbz     w9, #0x2cfe988                             
02cfe91c: cbnz    w8, #0x2cfe924                             
02cfe920: bl      #0x2b70f30                                 fn_2b70f30
02cfe924: bl      #0x2cfd6ec                                 RDG.Vibration::HasVibrator
02cfe928: mov     w8, w0                                     
02cfe92c: ldr     x0, [x21]                                  S:'{0}/2'
02cfe930: ldr     w9, [x0, #0xe4]                            [62680e4]=0 f=0,0
02cfe934: tbz     w8, #0, #0x2cfe9a0                         
02cfe938: cbnz    w9, #0x2cfe940                             
02cfe93c: bl      #0x2b70f30                                 fn_2b70f30
02cfe940: bl      #0x2cfca6c                                 RDG.Vibration::doesSupportPredefinedEffect
02cfe944: tbz     w0, #0, #0x2cfe9b8                         
02cfe948: tbz     w20, #0, #0x2cfe960                        
02cfe94c: ldr     x0, [x21]                                  S:'{0}/2'
02cfe950: ldr     w8, [x0, #0xe4]                            [62680e4]=0 f=0,0
02cfe954: cbnz    w8, #0x2cfe95c                             
02cfe958: bl      #0x2b70f30                                 fn_2b70f30
02cfe95c: bl      #0x2cfd818                                 RDG.Vibration::Cancel
02cfe960: ldr     x0, [x21]                                  S:'{0}/2'
02cfe964: ldr     w8, [x0, #0xe4]                            [62680e4]=0 f=0,0
02cfe968: cbnz    w8, #0x2cfe970                             
02cfe96c: bl      #0x2b70f30                                 fn_2b70f30
02cfe970: mov     w0, w19                                    
02cfe974: bl      #0x2cfea74                                 RDG.Vibration::vibrateEffectPredefined
02cfe978: adrp    x20, #0x6268000                            
02cfe97c: mov     w19, #1                                    
02cfe980: ldr     x20, [x20, #0xdb8]                         S:': Predefined effect called'
02cfe984: b       #0x2cfe9d4                                 
02cfe988: cbnz    w8, #0x2cfe990                             
02cfe98c: bl      #0x2b70f30                                 fn_2b70f30
02cfe990: adrp    x20, #0x6268000                            
02cfe994: mov     w19, #2                                    
02cfe998: ldr     x20, [x20, #0xd50]                         S:': Not initialized'
02cfe99c: b       #0x2cfe9d4                                 
02cfe9a0: cbnz    w9, #0x2cfe9a8                             
02cfe9a4: bl      #0x2b70f30                                 fn_2b70f30
02cfe9a8: adrp    x20, #0x6268000                            
02cfe9ac: mov     w19, #2                                    
02cfe9b0: ldr     x20, [x20, #0xd48]                         S:": Device doesn't have Vibrator"
02cfe9b4: b       #0x2cfe9d4                                 
02cfe9b8: ldr     x0, [x21]                                  S:'{0}/2'
02cfe9bc: ldr     w8, [x0, #0xe4]                            [62680e4]=0 f=0,0
02cfe9c0: cbnz    w8, #0x2cfe9c8                             
02cfe9c4: bl      #0x2b70f30                                 fn_2b70f30
02cfe9c8: adrp    x20, #0x6268000                            
02cfe9cc: mov     w19, #2                                    
02cfe9d0: ldr     x20, [x20, #0xdc0]                         S:": Device doesn't support Predefined Effects (Api Level >= 29)"
02cfe9d4: add     x0, sp, #0xc                               
02cfe9d8: bl      #0x2cfe9fc                                 RDG.Vibration::<VibratePredefined>g__funcToStr|11_0
02cfe9dc: ldr     x1, [x20]                                  S:'{0}/2'
02cfe9e0: mov     x2, xzr                                    
02cfe9e4: bl      #0x4c9c514                                 System.String::Concat
02cfe9e8: mov     w1, w19                                    
02cfe9ec: ldp     x20, x19, [sp, #0x20]                      
02cfe9f0: ldp     x22, x21, [sp, #0x10]                      
02cfe9f4: ldr     x30, [sp], #0x30                           
02cfe9f8: b       #0x2cfd2ac                                 RDG.Vibration::logAuto
## ParsePattern(string pattern) -> long[]
---- RDG.Vibration::ParsePattern 0x2cfec70
02cfec70: str     x30, [sp, #-0x30]!                         
02cfec74: stp     x22, x21, [sp, #0x10]                      
02cfec78: stp     x20, x19, [sp, #0x20]                      
02cfec7c: adrp    x20, #0x662f000                            
02cfec80: mov     x19, x0                                    
02cfec84: ldrb    w8, [x20, #0xee3]                          
02cfec88: tbnz    w8, #0, #0x2cfeca0                         
02cfec8c: adrp    x0, #0x6268000                             
02cfec90: ldr     x0, [x0, #0xdd0]                           T:type24405(k1d)
02cfec94: bl      #0x2b70db0                                 fn_2b70db0
02cfec98: mov     w8, #1                                     
02cfec9c: strb    w8, [x20, #0xee3]                          
02cfeca0: adrp    x20, #0x6268000                            
02cfeca4: ldr     x20, [x20, #0xdd0]                         T:type24405(k1d)
02cfeca8: str     wzr, [sp, #0xc]                            
02cfecac: cbz     x19, #0x2cfed80                            
02cfecb0: mov     x0, x19                                    
02cfecb4: mov     x1, xzr                                    
02cfecb8: bl      #0x4cab1c4                                 System.String::Trim
02cfecbc: cbz     x0, #0x2cfed98                             
02cfecc0: mov     w1, #0x2c                                  
02cfecc4: mov     w2, wzr                                    
02cfecc8: mov     x3, xzr                                    
02cfeccc: bl      #0x4ca92f8                                 System.String::Split
02cfecd0: cbz     x0, #0x2cfed98                             
02cfecd4: mov     x19, x0                                    
02cfecd8: ldr     x0, [x20]                                  S:'{0}/2'
02cfecdc: ldr     w1, [x19, #0x18]                           .defaultAmplitude
02cfece0: bl      #0x2b70ea0                                 fn_2b70ea0
02cfece4: ldr     w8, [x19, #0x18]                           .defaultAmplitude
02cfece8: mov     x20, x0                                    
02cfecec: cmp     w8, #1                                     
02cfecf0: b.lt    #0x2cfed6c                                 
02cfecf4: mov     w21, #4                                    
02cfecf8: sub     x22, x21, #4                               
02cfecfc: cmp     w22, w8                                    
02cfed00: b.hs    #0x2cfed9c                                 
02cfed04: ldr     x0, [x19, x21, lsl #3]                     
02cfed08: cbz     x0, #0x2cfed98                             
02cfed0c: mov     x1, xzr                                    
02cfed10: bl      #0x4cab1c4                                 System.String::Trim
02cfed14: add     x1, sp, #0xc                               
02cfed18: mov     x2, xzr                                    
02cfed1c: bl      #0x4e0f150                                 System.Int32::TryParse
02cfed20: tbz     w0, #0, #0x2cfed40                         
02cfed24: cbz     x20, #0x2cfed98                            
02cfed28: ldr     w8, [x20, #0x18]                           M:LuckyWheelPopup/<>c__DisplayClass50_0::<RunAnimation>b__0 .defaultAmplitude
02cfed2c: cmp     w22, w8                                    
02cfed30: b.hs    #0x2cfed9c                                 
02cfed34: ldr     w8, [sp, #0xc]                             
02cfed38: bic     w8, w8, w8, asr #31                        
02cfed3c: b       #0x2cfed54                                 
02cfed40: cbz     x20, #0x2cfed98                            
02cfed44: ldr     w8, [x20, #0x18]                           M:LuckyWheelPopup/<>c__DisplayClass50_0::<RunAnimation>b__0 .defaultAmplitude
02cfed48: cmp     w22, w8                                    
02cfed4c: b.hs    #0x2cfed9c                                 
02cfed50: mov     x8, xzr                                    
02cfed54: str     x8, [x20, x21, lsl #3]                     
02cfed58: add     x21, x21, #1                               
02cfed5c: ldr     w8, [x19, #0x18]                           .defaultAmplitude
02cfed60: sub     w9, w21, #4                                
02cfed64: cmp     w9, w8                                     
02cfed68: b.lt    #0x2cfecf8                                 
02cfed6c: mov     x0, x20                                    
02cfed70: ldp     x20, x19, [sp, #0x20]                      
02cfed74: ldp     x22, x21, [sp, #0x10]                      
02cfed78: ldr     x30, [sp], #0x30                           
02cfed7c: ret                                                
02cfed80: ldr     x0, [x20]                                  S:'{0}/2'
02cfed84: ldp     x20, x19, [sp, #0x20]                      
02cfed88: ldp     x22, x21, [sp, #0x10]                      
02cfed8c: mov     w1, wzr                                    
02cfed90: ldr     x30, [sp], #0x30                           
02cfed94: b       #0x2b70ea0                                 
02cfed98: bl      #0x2b7105c                                 fn_2b7105c
02cfed9c: bl      #0x2b71064                                 fn_2b71064
## GetApiLevel() -> int
---- RDG.Vibration::GetApiLevel 0x2cfeda0
02cfeda0: str     x30, [sp, #-0x20]!                         
02cfeda4: stp     x20, x19, [sp, #0x10]                      
02cfeda8: adrp    x20, #0x662f000                            
02cfedac: adrp    x19, #0x6268000                            
02cfedb0: ldrb    w8, [x20, #0xee4]                          
02cfedb4: ldr     x19, [x19, #0xcd8]                         T:RDG.Vibration
02cfedb8: tbnz    w8, #0, #0x2cfedd0                         
02cfedbc: adrp    x0, #0x6268000                             
02cfedc0: ldr     x0, [x0, #0xcd8]                           T:RDG.Vibration
02cfedc4: bl      #0x2b70db0                                 fn_2b70db0
02cfedc8: mov     w8, #1                                     
02cfedcc: strb    w8, [x20, #0xee4]                          
02cfedd0: ldr     x0, [x19]                                  S:'{0}/2'
02cfedd4: ldr     w8, [x0, #0xe4]                            [62680e4]=0 f=0,0
02cfedd8: cbnz    w8, #0x2cfede4                             
02cfeddc: bl      #0x2b70f30                                 fn_2b70f30
02cfede0: ldr     x0, [x19]                                  S:'{0}/2'
02cfede4: ldr     x8, [x0, #0xb8]                            T:LuckyWheelPopup/<>c__DisplayClass54_0
02cfede8: ldp     x20, x19, [sp, #0x10]                      
02cfedec: ldr     w0, [x8, #0x1c]                            
02cfedf0: ldr     x30, [sp], #0x20                           
02cfedf4: ret                                                
## GetDefaultAmplitude() -> int
---- RDG.Vibration::GetDefaultAmplitude 0x2cfedf8
02cfedf8: str     x30, [sp, #-0x20]!                         
02cfedfc: stp     x20, x19, [sp, #0x10]                      
02cfee00: adrp    x20, #0x662f000                            
02cfee04: adrp    x19, #0x6268000                            
02cfee08: ldrb    w8, [x20, #0xee5]                          
02cfee0c: ldr     x19, [x19, #0xcd8]                         T:RDG.Vibration
02cfee10: tbnz    w8, #0, #0x2cfee28                         
02cfee14: adrp    x0, #0x6268000                             
02cfee18: ldr     x0, [x0, #0xcd8]                           T:RDG.Vibration
02cfee1c: bl      #0x2b70db0                                 fn_2b70db0
02cfee20: mov     w8, #1                                     
02cfee24: strb    w8, [x20, #0xee5]                          
02cfee28: ldr     x0, [x19]                                  S:'{0}/2'
02cfee2c: ldr     w8, [x0, #0xe4]                            [62680e4]=0 f=0,0
02cfee30: cbnz    w8, #0x2cfee3c                             
02cfee34: bl      #0x2b70f30                                 fn_2b70f30
02cfee38: ldr     x0, [x19]                                  S:'{0}/2'
02cfee3c: ldr     x8, [x0, #0xb8]                            T:LuckyWheelPopup/<>c__DisplayClass54_0
02cfee40: ldp     x20, x19, [sp, #0x10]                      
02cfee44: ldr     w0, [x8, #0x18]                            
02cfee48: ldr     x30, [sp], #0x20                           
02cfee4c: ret                                                
## HasVibrator() -> bool
---- RDG.Vibration::HasVibrator 0x2cfd6ec
02cfd6ec: stp     x30, x21, [sp, #-0x20]!                    
02cfd6f0: stp     x20, x19, [sp, #0x10]                      
02cfd6f4: adrp    x19, #0x662f000                            
02cfd6f8: adrp    x20, #0x6268000                            
02cfd6fc: ldrb    w8, [x19, #0xee6]                          
02cfd700: ldr     x20, [x20, #0xcd8]                         T:RDG.Vibration
02cfd704: tbnz    w8, #0, #0x2cfd740                         
02cfd708: adrp    x0, #0x6265000                             
02cfd70c: ldr     x0, [x0, #0x760]                           MS:UnityEngine.AndroidJavaObject::Call
02cfd710: bl      #0x2b70db0                                 fn_2b70db0
02cfd714: adrp    x0, #0x6263000                             
02cfd718: ldr     x0, [x0, #0xb70]                           MS:System.Array::Empty
02cfd71c: bl      #0x2b70db0                                 fn_2b70db0
02cfd720: adrp    x0, #0x6268000                             
02cfd724: ldr     x0, [x0, #0xcd8]                           T:RDG.Vibration
02cfd728: bl      #0x2b70db0                                 fn_2b70db0
02cfd72c: adrp    x0, #0x6268000                             
02cfd730: ldr     x0, [x0, #0xd70]                           S:'hasVibrator'
02cfd734: bl      #0x2b70db0                                 fn_2b70db0
02cfd738: mov     w8, #1                                     
02cfd73c: strb    w8, [x19, #0xee6]                          
02cfd740: ldr     x0, [x20]                                  S:'{0}/2'
02cfd744: ldr     w8, [x0, #0xe4]                            [62680e4]=0 f=0,0
02cfd748: cbnz    w8, #0x2cfd754                             
02cfd74c: bl      #0x2b70f30                                 fn_2b70f30
02cfd750: ldr     x0, [x20]                                  S:'{0}/2'
02cfd754: ldr     x8, [x0, #0xb8]                            T:LuckyWheelPopup/<>c__DisplayClass54_0
02cfd758: ldr     x19, [x8, #8]                              
02cfd75c: cbz     x19, #0x2cfd804                            
02cfd760: adrp    x21, #0x6263000                            
02cfd764: ldr     w8, [x0, #0xe4]                            [62680e4]=0 f=0,0
02cfd768: ldr     x21, [x21, #0xb70]                         MS:System.Array::Empty
02cfd76c: cbnz    w8, #0x2cfd780                             
02cfd770: bl      #0x2b70f30                                 fn_2b70f30
02cfd774: ldr     x8, [x20]                                  S:'{0}/2'
02cfd778: ldr     x8, [x8, #0xb8]                            
02cfd77c: ldr     x19, [x8, #8]                              
02cfd780: ldr     x20, [x21]                                 &2c5bbd4(=a9bd7bfdd503233f)
02cfd784: ldr     x8, [x20, #0x38]                           T:LuckyWheelPopup/<>c__DisplayClass53_0
02cfd788: cbnz    x8, #0x2cfd798                             
02cfd78c: mov     x0, x20                                    
02cfd790: bl      #0x2ba9d7c                                 fn_2ba9d7c
02cfd794: ldr     x8, [x20, #0x38]                           T:LuckyWheelPopup/<>c__DisplayClass53_0
02cfd798: ldr     x0, [x8, #0x10]                            
02cfd79c: add     x8, x0, #0x135                             &6268135
02cfd7a0: ldrh    w8, [x8]                                   
02cfd7a4: tbnz    w8, #0, #0x2cfd7ac                         
02cfd7a8: bl      #0x2ba9d20                                 fn_2ba9d20
02cfd7ac: ldr     w8, [x0, #0xe4]                            [62680e4]=0 f=0,0
02cfd7b0: cbnz    w8, #0x2cfd7b8                             
02cfd7b4: bl      #0x2b70f30                                 fn_2b70f30
02cfd7b8: ldr     x8, [x20, #0x38]                           T:LuckyWheelPopup/<>c__DisplayClass53_0
02cfd7bc: ldr     x0, [x8, #0x10]                            
02cfd7c0: add     x8, x0, #0x135                             &6268135
02cfd7c4: ldrh    w8, [x8]                                   
02cfd7c8: tbnz    w8, #0, #0x2cfd7d0                         
02cfd7cc: bl      #0x2ba9d20                                 fn_2ba9d20
02cfd7d0: cbz     x19, #0x2cfd814                            
02cfd7d4: adrp    x8, #0x6268000                             
02cfd7d8: adrp    x9, #0x6265000                             
02cfd7dc: ldr     x8, [x8, #0xd70]                           S:'hasVibrator'
02cfd7e0: ldr     x9, [x9, #0x760]                           MS:UnityEngine.AndroidJavaObject::Call
02cfd7e4: ldr     x10, [x0, #0xb8]                           T:LuckyWheelPopup/<>c__DisplayClass54_0
02cfd7e8: mov     x0, x19                                    
02cfd7ec: ldp     x20, x19, [sp, #0x10]                      
02cfd7f0: ldr     x2, [x10]                                  
02cfd7f4: ldr     x1, [x8]                                   S:'{0}/2'
02cfd7f8: ldr     x3, [x9]                                   M:AdsManager::<OnApplicationPause>b__26_0
02cfd7fc: ldp     x30, x21, [sp], #0x20                      
02cfd800: b       #0x311f6d4                                 
02cfd804: ldp     x20, x19, [sp, #0x10]                      
02cfd808: mov     w0, wzr                                    
02cfd80c: ldp     x30, x21, [sp], #0x20                      
02cfd810: ret                                                
02cfd814: bl      #0x2b7105c                                 fn_2b7105c
## HasAmplitudeControl() -> bool
---- RDG.Vibration::HasAmplitudeControl 0x2cfd948
02cfd948: str     x30, [sp, #-0x20]!                         
02cfd94c: stp     x20, x19, [sp, #0x10]                      
02cfd950: adrp    x20, #0x662f000                            
02cfd954: adrp    x19, #0x6268000                            
02cfd958: ldrb    w8, [x20, #0xee7]                          
02cfd95c: ldr     x19, [x19, #0xcd8]                         T:RDG.Vibration
02cfd960: tbnz    w8, #0, #0x2cfd99c                         
02cfd964: adrp    x0, #0x6265000                             
02cfd968: ldr     x0, [x0, #0x760]                           MS:UnityEngine.AndroidJavaObject::Call
02cfd96c: bl      #0x2b70db0                                 fn_2b70db0
02cfd970: adrp    x0, #0x6263000                             
02cfd974: ldr     x0, [x0, #0xb70]                           MS:System.Array::Empty
02cfd978: bl      #0x2b70db0                                 fn_2b70db0
02cfd97c: adrp    x0, #0x6268000                             
02cfd980: ldr     x0, [x0, #0xcd8]                           T:RDG.Vibration
02cfd984: bl      #0x2b70db0                                 fn_2b70db0
02cfd988: adrp    x0, #0x6268000                             
02cfd98c: ldr     x0, [x0, #0xd88]                           S:'hasAmplitudeControl'
02cfd990: bl      #0x2b70db0                                 fn_2b70db0
02cfd994: mov     w8, #1                                     
02cfd998: strb    w8, [x20, #0xee7]                          
02cfd99c: ldr     x0, [x19]                                  S:'{0}/2'
02cfd9a0: ldr     w8, [x0, #0xe4]                            [62680e4]=0 f=0,0
02cfd9a4: cbnz    w8, #0x2cfd9ac                             
02cfd9a8: bl      #0x2b70f30                                 fn_2b70f30
02cfd9ac: bl      #0x2cfd6ec                                 RDG.Vibration::HasVibrator
02cfd9b0: tbz     w0, #0, #0x2cfda74                         
02cfd9b4: ldr     x0, [x19]                                  S:'{0}/2'
02cfd9b8: ldr     w8, [x0, #0xe4]                            [62680e4]=0 f=0,0
02cfd9bc: cbnz    w8, #0x2cfd9c4                             
02cfd9c0: bl      #0x2b70f30                                 fn_2b70f30
02cfd9c4: bl      #0x2cfca0c                                 RDG.Vibration::doesSupportVibrationEffect
02cfd9c8: tbz     w0, #0, #0x2cfda74                         
02cfd9cc: ldr     x0, [x19]                                  S:'{0}/2'
02cfd9d0: ldr     w8, [x0, #0xe4]                            [62680e4]=0 f=0,0
02cfd9d4: cbnz    w8, #0x2cfd9e0                             
02cfd9d8: bl      #0x2b70f30                                 fn_2b70f30
02cfd9dc: ldr     x0, [x19]                                  S:'{0}/2'
02cfd9e0: adrp    x8, #0x6263000                             
02cfd9e4: ldr     x8, [x8, #0xb70]                           MS:System.Array::Empty
02cfd9e8: ldr     x9, [x0, #0xb8]                            T:LuckyWheelPopup/<>c__DisplayClass54_0
02cfd9ec: ldr     x20, [x8]                                  &2c5bbd4(=a9bd7bfdd503233f)
02cfd9f0: ldr     x19, [x9, #8]                              
02cfd9f4: ldr     x8, [x20, #0x38]                           [662f038]=6000016 f=2.40742e-35,0
02cfd9f8: cbnz    x8, #0x2cfda08                             
02cfd9fc: mov     x0, x20                                    
02cfda00: bl      #0x2ba9d7c                                 fn_2ba9d7c
02cfda04: ldr     x8, [x20, #0x38]                           [662f038]=6000016 f=2.40742e-35,0
02cfda08: ldr     x0, [x8, #0x10]                            &2c498bc(=aa1f03e0d503245f)
02cfda0c: add     x8, x0, #0x135                             &6268135
02cfda10: ldrh    w8, [x8]                                   
02cfda14: tbnz    w8, #0, #0x2cfda1c                         
02cfda18: bl      #0x2ba9d20                                 fn_2ba9d20
02cfda1c: ldr     w8, [x0, #0xe4]                            [62680e4]=0 f=0,0
02cfda20: cbnz    w8, #0x2cfda28                             
02cfda24: bl      #0x2b70f30                                 fn_2b70f30
02cfda28: ldr     x8, [x20, #0x38]                           [662f038]=6000016 f=2.40742e-35,0
02cfda2c: ldr     x0, [x8, #0x10]                            &2c498bc(=aa1f03e0d503245f)
02cfda30: add     x8, x0, #0x135                             &6268135
02cfda34: ldrh    w8, [x8]                                   
02cfda38: tbnz    w8, #0, #0x2cfda40                         
02cfda3c: bl      #0x2ba9d20                                 fn_2ba9d20
02cfda40: cbz     x19, #0x2cfda84                            
02cfda44: adrp    x8, #0x6268000                             
02cfda48: adrp    x10, #0x6265000                            
02cfda4c: ldr     x8, [x8, #0xd88]                           S:'hasAmplitudeControl'
02cfda50: ldr     x9, [x0, #0xb8]                            T:LuckyWheelPopup/<>c__DisplayClass54_0
02cfda54: ldr     x10, [x10, #0x760]                         MS:UnityEngine.AndroidJavaObject::Call
02cfda58: mov     x0, x19                                    
02cfda5c: ldp     x20, x19, [sp, #0x10]                      
02cfda60: ldr     x2, [x9]                                   
02cfda64: ldr     x1, [x8]                                   S:'{0}/2'
02cfda68: ldr     x3, [x10]                                  M:AdsManager::<OnApplicationPause>b__26_0
02cfda6c: ldr     x30, [sp], #0x20                           
02cfda70: b       #0x311f6d4                                 
02cfda74: ldp     x20, x19, [sp, #0x10]                      
02cfda78: mov     w0, wzr                                    
02cfda7c: ldr     x30, [sp], #0x20                           
02cfda80: ret                                                
02cfda84: bl      #0x2b7105c                                 fn_2b7105c
## Cancel() -> void
---- RDG.Vibration::Cancel 0x2cfd818
02cfd818: str     x30, [sp, #-0x20]!                         
02cfd81c: stp     x20, x19, [sp, #0x10]                      
02cfd820: adrp    x20, #0x662f000                            
02cfd824: adrp    x19, #0x6268000                            
02cfd828: ldrb    w8, [x20, #0xee8]                          
02cfd82c: ldr     x19, [x19, #0xcd8]                         T:RDG.Vibration
02cfd830: tbnz    w8, #0, #0x2cfd86c                         
02cfd834: adrp    x0, #0x6263000                             
02cfd838: ldr     x0, [x0, #0xb70]                           MS:System.Array::Empty
02cfd83c: bl      #0x2b70db0                                 fn_2b70db0
02cfd840: adrp    x0, #0x6268000                             
02cfd844: ldr     x0, [x0, #0xcd8]                           T:RDG.Vibration
02cfd848: bl      #0x2b70db0                                 fn_2b70db0
02cfd84c: adrp    x0, #0x6268000                             
02cfd850: ldr     x0, [x0, #0xd78]                           S:'cancel'
02cfd854: bl      #0x2b70db0                                 fn_2b70db0
02cfd858: adrp    x0, #0x6268000                             
02cfd85c: ldr     x0, [x0, #0xd80]                           S:'Cancel (): Called'
02cfd860: bl      #0x2b70db0                                 fn_2b70db0
02cfd864: mov     w8, #1                                     
02cfd868: strb    w8, [x20, #0xee8]                          
02cfd86c: ldr     x0, [x19]                                  S:'{0}/2'
02cfd870: ldr     w8, [x0, #0xe4]                            [62680e4]=0 f=0,0
02cfd874: cbnz    w8, #0x2cfd87c                             
02cfd878: bl      #0x2b70f30                                 fn_2b70f30
02cfd87c: bl      #0x2cfd6ec                                 RDG.Vibration::HasVibrator
02cfd880: tbz     w0, #0, #0x2cfd938                         
02cfd884: ldr     x0, [x19]                                  S:'{0}/2'
02cfd888: adrp    x20, #0x6263000                            
02cfd88c: ldr     w8, [x0, #0xe4]                            [62680e4]=0 f=0,0
02cfd890: ldr     x20, [x20, #0xb70]                         MS:System.Array::Empty
02cfd894: cbnz    w8, #0x2cfd8a0                             
02cfd898: bl      #0x2b70f30                                 fn_2b70f30
02cfd89c: ldr     x0, [x19]                                  S:'{0}/2'
02cfd8a0: ldr     x20, [x20]                                 &2c5bbd4(=a9bd7bfdd503233f)
02cfd8a4: ldr     x9, [x0, #0xb8]                            T:LuckyWheelPopup/<>c__DisplayClass54_0
02cfd8a8: ldr     x8, [x20, #0x38]                           &6260bd8(=0)
02cfd8ac: ldr     x19, [x9, #8]                              
02cfd8b0: cbnz    x8, #0x2cfd8c0                             
02cfd8b4: mov     x0, x20                                    
02cfd8b8: bl      #0x2ba9d7c                                 fn_2ba9d7c
02cfd8bc: ldr     x8, [x20, #0x38]                           &6260bd8(=0)
02cfd8c0: ldr     x0, [x8, #0x10]                            
02cfd8c4: add     x8, x0, #0x135                             &6268135
02cfd8c8: ldrh    w8, [x8]                                   
02cfd8cc: tbnz    w8, #0, #0x2cfd8d4                         
02cfd8d0: bl      #0x2ba9d20                                 fn_2ba9d20
02cfd8d4: ldr     w8, [x0, #0xe4]                            [62680e4]=0 f=0,0
02cfd8d8: cbnz    w8, #0x2cfd8e0                             
02cfd8dc: bl      #0x2b70f30                                 fn_2b70f30
02cfd8e0: ldr     x8, [x20, #0x38]                           &6260bd8(=0)
02cfd8e4: ldr     x0, [x8, #0x10]                            
02cfd8e8: add     x8, x0, #0x135                             &6268135
02cfd8ec: ldrh    w8, [x8]                                   
02cfd8f0: tbnz    w8, #0, #0x2cfd8f8                         
02cfd8f4: bl      #0x2ba9d20                                 fn_2ba9d20
02cfd8f8: cbz     x19, #0x2cfd944                            
02cfd8fc: adrp    x9, #0x6268000                             
02cfd900: ldr     x8, [x0, #0xb8]                            T:LuckyWheelPopup/<>c__DisplayClass54_0
02cfd904: mov     x0, x19                                    
02cfd908: ldr     x9, [x9, #0xd78]                           S:'cancel'
02cfd90c: mov     x3, xzr                                    
02cfd910: ldr     x2, [x8]                                   
02cfd914: ldr     x1, [x9]                                   S:'{0}/2'
02cfd918: bl      #0x5ad5e34                                 UnityEngine.AndroidJavaObject::Call
02cfd91c: adrp    x8, #0x6268000                             
02cfd920: mov     w1, #1                                     
02cfd924: ldr     x8, [x8, #0xd80]                           S:'Cancel (): Called'
02cfd928: ldp     x20, x19, [sp, #0x10]                      
02cfd92c: ldr     x0, [x8]                                   S:'{0}/2'
02cfd930: ldr     x30, [sp], #0x20                           
02cfd934: b       #0x2cfd2ac                                 RDG.Vibration::logAuto
02cfd938: ldp     x20, x19, [sp, #0x10]                      
02cfd93c: ldr     x30, [sp], #0x20                           
02cfd940: ret                                                
02cfd944: bl      #0x2b7105c                                 fn_2b7105c
## vibrateEffect(long milliseconds, int amplitude) -> void
---- RDG.Vibration::vibrateEffect 0x2cfda88
02cfda88: sub     sp, sp, #0x40                              
02cfda8c: str     x30, [sp, #0x10]                           
02cfda90: stp     x22, x21, [sp, #0x20]                      
02cfda94: stp     x20, x19, [sp, #0x30]                      
02cfda98: adrp    x22, #0x662f000                            
02cfda9c: adrp    x21, #0x6268000                            
02cfdaa0: mov     w19, w1                                    
02cfdaa4: ldrb    w8, [x22, #0xee9]                          
02cfdaa8: ldr     x21, [x21, #0xcd8]                         T:RDG.Vibration
02cfdaac: mov     x20, x0                                    
02cfdab0: tbnz    w8, #0, #0x2cfdaec                         
02cfdab4: adrp    x0, #0x6263000                             
02cfdab8: ldr     x0, [x0, #0x980]                           T:System.IDisposable
02cfdabc: bl      #0x2b70db0                                 fn_2b70db0
02cfdac0: adrp    x0, #0x6263000                             
02cfdac4: ldr     x0, [x0, #0xa80]                           T:type24502(k1d)
02cfdac8: bl      #0x2b70db0                                 fn_2b70db0
02cfdacc: adrp    x0, #0x6268000                             
02cfdad0: ldr     x0, [x0, #0xcd8]                           T:RDG.Vibration
02cfdad4: bl      #0x2b70db0                                 fn_2b70db0
02cfdad8: adrp    x0, #0x6268000                             
02cfdadc: ldr     x0, [x0, #0xd90]                           S:'vibrate'
02cfdae0: bl      #0x2b70db0                                 fn_2b70db0
02cfdae4: mov     w8, #1                                     
02cfdae8: strb    w8, [x22, #0xee9]                          
02cfdaec: ldr     x0, [x21]                                  S:'{0}/2'
02cfdaf0: str     xzr, [sp, #0x18]                           
02cfdaf4: ldr     w8, [x0, #0xe4]                            [62680e4]=0 f=0,0
02cfdaf8: cbnz    w8, #0x2cfdb00                             
02cfdafc: bl      #0x2b70f30                                 fn_2b70f30
02cfdb00: mov     x0, x20                                    
02cfdb04: mov     w1, w19                                    
02cfdb08: bl      #0x2cfee50                                 RDG.Vibration::createEffect_OneShot
02cfdb0c: mov     x8, x0                                     
02cfdb10: ldr     x0, [x21]                                  S:'{0}/2'
02cfdb14: add     x9, sp, #0x18                              
02cfdb18: str     x8, [sp, #0x18]                            
02cfdb1c: ldr     w8, [x0, #0xe4]                            [62680e4]=0 f=0,0
02cfdb20: stp     xzr, x9, [sp]                              
02cfdb24: cbnz    w8, #0x2cfdb30                             
02cfdb28: bl      #0x2b70f30                                 fn_2b70f30
02cfdb2c: ldr     x0, [x21]                                  S:'{0}/2'
02cfdb30: adrp    x8, #0x6263000                             
02cfdb34: ldr     x8, [x8, #0xa80]                           T:type24502(k1d)
02cfdb38: ldr     x9, [x0, #0xb8]                            T:LuckyWheelPopup/<>c__DisplayClass54_0
02cfdb3c: ldr     x19, [x9, #8]                              
02cfdb40: ldr     x0, [x8]                                   &2c5bbd4(=a9bd7bfdd503233f)
02cfdb44: mov     w1, #1                                     
02cfdb48: bl      #0x2b70ea0                                 fn_2b70ea0
02cfdb4c: mov     x20, x0                                    
02cfdb50: cbz     x0, #0x2cfdc30                             
02cfdb54: ldr     x21, [sp, #0x18]                           
02cfdb58: cbz     x21, #0x2cfdb70                            
02cfdb5c: ldr     x8, [x20]                                  
02cfdb60: ldr     x1, [x8, #0x40]                            [6263040]=0 f=0,0
02cfdb64: mov     x0, x21                                    
02cfdb68: bl      #0x2b70f34                                 fn_2b70f34
02cfdb6c: cbz     x0, #0x2cfdc40                             
02cfdb70: ldr     w8, [x20, #0x18]                           .defaultAmplitude
02cfdb74: cbz     w8, #0x2cfdc3c                             
02cfdb78: mov     x0, x20                                    
02cfdb7c: str     x21, [x0, #0x20]!                          .isInitialized
02cfdb80: mov     x1, x21                                    
02cfdb84: bl      #0x2b70d54                                 fn_2b70d54
02cfdb88: cbz     x19, #0x2cfdc30                            
02cfdb8c: adrp    x8, #0x6268000                             
02cfdb90: ldr     x8, [x8, #0xd90]                           S:'vibrate'
02cfdb94: ldr     x1, [x8]                                   S:'{0}/2'
02cfdb98: mov     x0, x19                                    
02cfdb9c: mov     x2, x20                                    
02cfdba0: mov     x3, xzr                                    
02cfdba4: bl      #0x5ad5e34                                 UnityEngine.AndroidJavaObject::Call
02cfdba8: mov     x19, xzr                                   
02cfdbac: add     x8, sp, #0x18                              
02cfdbb0: ldr     x20, [x8]                                  S:'{0}/2'
02cfdbb4: cbz     x20, #0x2cfdc18                            
02cfdbb8: adrp    x10, #0x6263000                            
02cfdbbc: ldr     x8, [x20]                                  
02cfdbc0: ldr     x10, [x10, #0x980]                         T:System.IDisposable
02cfdbc4: ldrh    w9, [x8, #0x12e]                           
02cfdbc8: ldr     x1, [x10]                                  &2c5bbd4(=a9bd7bfdd503233f)
02cfdbcc: cbz     x9, #0x2cfdbf0                             
02cfdbd0: ldr     x10, [x8, #0xb0]                           S:'penguin_close_mouth'
02cfdbd4: add     x10, x10, #8                               &6263008
02cfdbd8: ldur    x11, [x10, #-8]                            
02cfdbdc: cmp     x11, x1                                    
02cfdbe0: b.eq    #0x2cfdc00                                 
02cfdbe4: subs    x9, x9, #1                                 
02cfdbe8: add     x10, x10, #0x10                            &6263010
02cfdbec: b.ne    #0x2cfdbd8                                 
02cfdbf0: mov     x0, x20                                    
02cfdbf4: mov     w2, wzr                                    
02cfdbf8: bl      #0x2baa05c                                 fn_2baa05c
02cfdbfc: b       #0x2cfdc0c                                 
02cfdc00: ldrsw   x9, [x10]                                  
02cfdc04: add     x8, x8, x9, lsl #4                         &6268000
02cfdc08: add     x0, x8, #0x138                             &6268138
02cfdc0c: ldp     x8, x1, [x0]                               
02cfdc10: mov     x0, x20                                    
02cfdc14: blr     x8                                         
02cfdc18: cbnz    x19, #0x2cfdc34                            
02cfdc1c: ldp     x20, x19, [sp, #0x30]                      
02cfdc20: ldr     x30, [sp, #0x10]                           
02cfdc24: ldp     x22, x21, [sp, #0x20]                      
02cfdc28: add     sp, sp, #0x40                              
02cfdc2c: ret                                                
02cfdc30: bl      #0x2b7105c                                 fn_2b7105c
02cfdc34: mov     x0, x19                                    
02cfdc38: bl      #0x2b71054                                 fn_2b71054
02cfdc3c: bl      #0x2b71064                                 fn_2b71064
02cfdc40: bl      #0x2b71080                                 fn_2b71080
02cfdc44: mov     x1, xzr                                    
02cfdc48: bl      #0x2b70f20                                 fn_2b70f20
02cfdc4c: b       #0x2cfdc54                                 
02cfdc50: b       #0x2cfdc54                                 
02cfdc54: mov     x19, x0                                    
02cfdc58: cmp     w1, #1                                     
02cfdc5c: b.ne    #0x2cfdc80                                 
02cfdc60: mov     x0, x19                                    
02cfdc64: bl      #0x5e90260                                 fn_5e90260
02cfdc68: ldr     x19, [x0]                                  S:'{0}/2'
02cfdc6c: str     x19, [sp]                                  
02cfdc70: bl      #0x5e90270                                 fn_5e90270
02cfdc74: ldr     x8, [sp, #8]                               
02cfdc78: b       #0x2cfdbb0                                 
02cfdc7c: mov     x19, x0                                    
02cfdc80: mov     x0, sp                                     
02cfdc84: bl      #0x27369c4                                 fn_27369c4
02cfdc88: mov     x0, x19                                    
02cfdc8c: bl      #0x2c6051c                                 fn_2c6051c
02cfdc90: bl      #0x27369b8                                 fn_27369b8
## vibrateLegacy(long milliseconds) -> void
---- RDG.Vibration::vibrateLegacy 0x2cfdc94
02cfdc94: sub     sp, sp, #0x30                              
02cfdc98: stp     x30, x21, [sp, #0x10]                      
02cfdc9c: stp     x20, x19, [sp, #0x20]                      
02cfdca0: adrp    x21, #0x662f000                            
02cfdca4: adrp    x19, #0x6268000                            
02cfdca8: mov     x20, x0                                    
02cfdcac: ldrb    w8, [x21, #0xeea]                          
02cfdcb0: ldr     x19, [x19, #0xcd8]                         T:RDG.Vibration
02cfdcb4: tbnz    w8, #0, #0x2cfdce4                         
02cfdcb8: adrp    x0, #0x6263000                             
02cfdcbc: ldr     x0, [x0, #0xa80]                           T:type24502(k1d)
02cfdcc0: bl      #0x2b70db0                                 fn_2b70db0
02cfdcc4: adrp    x0, #0x6268000                             
02cfdcc8: ldr     x0, [x0, #0xcd8]                           T:RDG.Vibration
02cfdccc: bl      #0x2b70db0                                 fn_2b70db0
02cfdcd0: adrp    x0, #0x6268000                             
02cfdcd4: ldr     x0, [x0, #0xd90]                           S:'vibrate'
02cfdcd8: bl      #0x2b70db0                                 fn_2b70db0
02cfdcdc: mov     w8, #1                                     
02cfdce0: strb    w8, [x21, #0xeea]                          
02cfdce4: ldr     x0, [x19]                                  S:'{0}/2'
02cfdce8: adrp    x21, #0x6263000                            
02cfdcec: ldr     w8, [x0, #0xe4]                            [62680e4]=0 f=0,0
02cfdcf0: ldr     x21, [x21, #0xa80]                         T:type24502(k1d)
02cfdcf4: cbnz    w8, #0x2cfdd00                             
02cfdcf8: bl      #0x2b70f30                                 fn_2b70f30
02cfdcfc: ldr     x0, [x19]                                  S:'{0}/2'
02cfdd00: ldr     x8, [x0, #0xb8]                            T:LuckyWheelPopup/<>c__DisplayClass54_0
02cfdd04: ldr     x0, [x21]                                  &2c5bbd4(=a9bd7bfdd503233f)
02cfdd08: mov     w1, #1                                     
02cfdd0c: ldr     x19, [x8, #8]                              
02cfdd10: bl      #0x2b70ea0                                 fn_2b70ea0
02cfdd14: adrp    x8, #0x6263000                             
02cfdd18: mov     x21, x0                                    
02cfdd1c: add     x1, sp, #8                                 
02cfdd20: ldr     x8, [x8, #0x970]                           &6645c70(=0)
02cfdd24: str     x20, [sp, #8]                              
02cfdd28: ldr     x0, [x8, #0x68]                            &2c497cc(=d65f03c0d503245f)
02cfdd2c: bl      #0x2b70f38                                 fn_2b70f38
02cfdd30: cbz     x21, #0x2cfdd98                            
02cfdd34: mov     x20, x0                                    
02cfdd38: cbz     x0, #0x2cfdd50                             
02cfdd3c: ldr     x8, [x21]                                  &2c5bbd4(=a9bd7bfdd503233f)
02cfdd40: mov     x0, x20                                    
02cfdd44: ldr     x1, [x8, #0x40]                            [6263040]=0 f=0,0
02cfdd48: bl      #0x2b70f34                                 fn_2b70f34
02cfdd4c: cbz     x0, #0x2cfdda0                             
02cfdd50: ldr     w8, [x21, #0x18]                           &2c5d934(=d65f03c0d503245f) .defaultAmplitude
02cfdd54: cbz     w8, #0x2cfdd9c                             
02cfdd58: mov     x0, x21                                    
02cfdd5c: mov     x1, x20                                    
02cfdd60: str     x20, [x0, #0x20]!                          .isInitialized
02cfdd64: bl      #0x2b70d54                                 fn_2b70d54
02cfdd68: cbz     x19, #0x2cfdd98                            
02cfdd6c: adrp    x8, #0x6268000                             
02cfdd70: mov     x0, x19                                    
02cfdd74: mov     x2, x21                                    
02cfdd78: ldr     x8, [x8, #0xd90]                           S:'vibrate'
02cfdd7c: mov     x3, xzr                                    
02cfdd80: ldr     x1, [x8]                                   S:'{0}/2'
02cfdd84: bl      #0x5ad5e34                                 UnityEngine.AndroidJavaObject::Call
02cfdd88: ldp     x20, x19, [sp, #0x20]                      
02cfdd8c: ldp     x30, x21, [sp, #0x10]                      
02cfdd90: add     sp, sp, #0x30                              
02cfdd94: ret                                                
02cfdd98: bl      #0x2b7105c                                 fn_2b7105c
02cfdd9c: bl      #0x2b71064                                 fn_2b71064
02cfdda0: bl      #0x2b71080                                 fn_2b71080
02cfdda4: mov     x1, xzr                                    
02cfdda8: bl      #0x2b70f20                                 fn_2b70f20
## vibrateEffect(long[] pattern, int repeat) -> void
---- RDG.Vibration::vibrateEffect 0x2cfe528
02cfe528: sub     sp, sp, #0x40                              
02cfe52c: str     x30, [sp, #0x10]                           
02cfe530: stp     x22, x21, [sp, #0x20]                      
02cfe534: stp     x20, x19, [sp, #0x30]                      
02cfe538: adrp    x22, #0x662f000                            
02cfe53c: adrp    x21, #0x6268000                            
02cfe540: mov     w19, w1                                    
02cfe544: ldrb    w8, [x22, #0xeeb]                          
02cfe548: ldr     x21, [x21, #0xcd8]                         T:RDG.Vibration
02cfe54c: mov     x20, x0                                    
02cfe550: tbnz    w8, #0, #0x2cfe58c                         
02cfe554: adrp    x0, #0x6263000                             
02cfe558: ldr     x0, [x0, #0x980]                           T:System.IDisposable
02cfe55c: bl      #0x2b70db0                                 fn_2b70db0
02cfe560: adrp    x0, #0x6263000                             
02cfe564: ldr     x0, [x0, #0xa80]                           T:type24502(k1d)
02cfe568: bl      #0x2b70db0                                 fn_2b70db0
02cfe56c: adrp    x0, #0x6268000                             
02cfe570: ldr     x0, [x0, #0xcd8]                           T:RDG.Vibration
02cfe574: bl      #0x2b70db0                                 fn_2b70db0
02cfe578: adrp    x0, #0x6268000                             
02cfe57c: ldr     x0, [x0, #0xd90]                           S:'vibrate'
02cfe580: bl      #0x2b70db0                                 fn_2b70db0
02cfe584: mov     w8, #1                                     
02cfe588: strb    w8, [x22, #0xeeb]                          
02cfe58c: ldr     x0, [x21]                                  S:'{0}/2'
02cfe590: str     xzr, [sp, #0x18]                           
02cfe594: ldr     w8, [x0, #0xe4]                            [62680e4]=0 f=0,0
02cfe598: cbnz    w8, #0x2cfe5a0                             
02cfe59c: bl      #0x2b70f30                                 fn_2b70f30
02cfe5a0: mov     x0, x20                                    
02cfe5a4: mov     w1, w19                                    
02cfe5a8: bl      #0x2cfefd0                                 RDG.Vibration::createEffect_Waveform
02cfe5ac: mov     x8, x0                                     
02cfe5b0: ldr     x0, [x21]                                  S:'{0}/2'
02cfe5b4: add     x9, sp, #0x18                              
02cfe5b8: str     x8, [sp, #0x18]                            
02cfe5bc: ldr     w8, [x0, #0xe4]                            [62680e4]=0 f=0,0
02cfe5c0: stp     xzr, x9, [sp]                              
02cfe5c4: cbnz    w8, #0x2cfe5d0                             
02cfe5c8: bl      #0x2b70f30                                 fn_2b70f30
02cfe5cc: ldr     x0, [x21]                                  S:'{0}/2'
02cfe5d0: adrp    x8, #0x6263000                             
02cfe5d4: ldr     x8, [x8, #0xa80]                           T:type24502(k1d)
02cfe5d8: ldr     x9, [x0, #0xb8]                            T:LuckyWheelPopup/<>c__DisplayClass54_0
02cfe5dc: ldr     x19, [x9, #8]                              
02cfe5e0: ldr     x0, [x8]                                   &2c5bbd4(=a9bd7bfdd503233f)
02cfe5e4: mov     w1, #1                                     
02cfe5e8: bl      #0x2b70ea0                                 fn_2b70ea0
02cfe5ec: mov     x20, x0                                    
02cfe5f0: cbz     x0, #0x2cfe6d0                             
02cfe5f4: ldr     x21, [sp, #0x18]                           
02cfe5f8: cbz     x21, #0x2cfe610                            
02cfe5fc: ldr     x8, [x20]                                  
02cfe600: ldr     x1, [x8, #0x40]                            [6263040]=0 f=0,0
02cfe604: mov     x0, x21                                    
02cfe608: bl      #0x2b70f34                                 fn_2b70f34
02cfe60c: cbz     x0, #0x2cfe6e0                             
02cfe610: ldr     w8, [x20, #0x18]                           .defaultAmplitude
02cfe614: cbz     w8, #0x2cfe6dc                             
02cfe618: mov     x0, x20                                    
02cfe61c: str     x21, [x0, #0x20]!                          .isInitialized
02cfe620: mov     x1, x21                                    
02cfe624: bl      #0x2b70d54                                 fn_2b70d54
02cfe628: cbz     x19, #0x2cfe6d0                            
02cfe62c: adrp    x8, #0x6268000                             
02cfe630: ldr     x8, [x8, #0xd90]                           S:'vibrate'
02cfe634: ldr     x1, [x8]                                   S:'{0}/2'
02cfe638: mov     x0, x19                                    
02cfe63c: mov     x2, x20                                    
02cfe640: mov     x3, xzr                                    
02cfe644: bl      #0x5ad5e34                                 UnityEngine.AndroidJavaObject::Call
02cfe648: mov     x19, xzr                                   
02cfe64c: add     x8, sp, #0x18                              
02cfe650: ldr     x20, [x8]                                  S:'{0}/2'
02cfe654: cbz     x20, #0x2cfe6b8                            
02cfe658: adrp    x10, #0x6263000                            
02cfe65c: ldr     x8, [x20]                                  
02cfe660: ldr     x10, [x10, #0x980]                         T:System.IDisposable
02cfe664: ldrh    w9, [x8, #0x12e]                           
02cfe668: ldr     x1, [x10]                                  &2c5bbd4(=a9bd7bfdd503233f)
02cfe66c: cbz     x9, #0x2cfe690                             
02cfe670: ldr     x10, [x8, #0xb0]                           S:'penguin_close_mouth'
02cfe674: add     x10, x10, #8                               &6263008
02cfe678: ldur    x11, [x10, #-8]                            
02cfe67c: cmp     x11, x1                                    
02cfe680: b.eq    #0x2cfe6a0                                 
02cfe684: subs    x9, x9, #1                                 
02cfe688: add     x10, x10, #0x10                            &6263010
02cfe68c: b.ne    #0x2cfe678                                 
02cfe690: mov     x0, x20                                    
02cfe694: mov     w2, wzr                                    
02cfe698: bl      #0x2baa05c                                 fn_2baa05c
02cfe69c: b       #0x2cfe6ac                                 
02cfe6a0: ldrsw   x9, [x10]                                  
02cfe6a4: add     x8, x8, x9, lsl #4                         &6268000
02cfe6a8: add     x0, x8, #0x138                             &6268138
02cfe6ac: ldp     x8, x1, [x0]                               
02cfe6b0: mov     x0, x20                                    
02cfe6b4: blr     x8                                         
02cfe6b8: cbnz    x19, #0x2cfe6d4                            
02cfe6bc: ldp     x20, x19, [sp, #0x30]                      
02cfe6c0: ldr     x30, [sp, #0x10]                           
02cfe6c4: ldp     x22, x21, [sp, #0x20]                      
02cfe6c8: add     sp, sp, #0x40                              
02cfe6cc: ret                                                
02cfe6d0: bl      #0x2b7105c                                 fn_2b7105c
02cfe6d4: mov     x0, x19                                    
02cfe6d8: bl      #0x2b71054                                 fn_2b71054
02cfe6dc: bl      #0x2b71064                                 fn_2b71064
02cfe6e0: bl      #0x2b71080                                 fn_2b71080
02cfe6e4: mov     x1, xzr                                    
02cfe6e8: bl      #0x2b70f20                                 fn_2b70f20
02cfe6ec: b       #0x2cfe6f4                                 
02cfe6f0: b       #0x2cfe6f4                                 
02cfe6f4: mov     x19, x0                                    
02cfe6f8: cmp     w1, #1                                     
02cfe6fc: b.ne    #0x2cfe720                                 
02cfe700: mov     x0, x19                                    
02cfe704: bl      #0x5e90260                                 fn_5e90260
02cfe708: ldr     x19, [x0]                                  S:'{0}/2'
02cfe70c: str     x19, [sp]                                  
02cfe710: bl      #0x5e90270                                 fn_5e90270
02cfe714: ldr     x8, [sp, #8]                               
02cfe718: b       #0x2cfe650                                 
02cfe71c: mov     x19, x0                                    
02cfe720: mov     x0, sp                                     
02cfe724: bl      #0x27369c4                                 fn_27369c4
02cfe728: mov     x0, x19                                    
02cfe72c: bl      #0x2c6051c                                 fn_2c6051c
02cfe730: bl      #0x27369b8                                 fn_27369b8
## vibrateLegacy(long[] pattern, int repeat) -> void
---- RDG.Vibration::vibrateLegacy 0x2cfe734
02cfe734: str     x30, [sp, #-0x30]!                         
02cfe738: stp     x22, x21, [sp, #0x10]                      
02cfe73c: stp     x20, x19, [sp, #0x20]                      
02cfe740: adrp    x21, #0x662f000                            
02cfe744: adrp    x20, #0x6268000                            
02cfe748: mov     w19, w1                                    
02cfe74c: ldrb    w8, [x21, #0xeec]                          
02cfe750: ldr     x20, [x20, #0xcd8]                         T:RDG.Vibration
02cfe754: mov     x22, x0                                    
02cfe758: tbnz    w8, #0, #0x2cfe788                         
02cfe75c: adrp    x0, #0x6263000                             
02cfe760: ldr     x0, [x0, #0xa80]                           T:type24502(k1d)
02cfe764: bl      #0x2b70db0                                 fn_2b70db0
02cfe768: adrp    x0, #0x6268000                             
02cfe76c: ldr     x0, [x0, #0xcd8]                           T:RDG.Vibration
02cfe770: bl      #0x2b70db0                                 fn_2b70db0
02cfe774: adrp    x0, #0x6268000                             
02cfe778: ldr     x0, [x0, #0xd90]                           S:'vibrate'
02cfe77c: bl      #0x2b70db0                                 fn_2b70db0
02cfe780: mov     w8, #1                                     
02cfe784: strb    w8, [x21, #0xeec]                          
02cfe788: ldr     x0, [x20]                                  S:'{0}/2'
02cfe78c: adrp    x21, #0x6263000                            
02cfe790: ldr     w8, [x0, #0xe4]                            [62680e4]=0 f=0,0
02cfe794: ldr     x21, [x21, #0xa80]                         T:type24502(k1d)
02cfe798: cbnz    w8, #0x2cfe7a4                             
02cfe79c: bl      #0x2b70f30                                 fn_2b70f30
02cfe7a0: ldr     x0, [x20]                                  S:'{0}/2'
02cfe7a4: ldr     x8, [x0, #0xb8]                            T:LuckyWheelPopup/<>c__DisplayClass54_0
02cfe7a8: ldr     x0, [x21]                                  &2c5bbd4(=a9bd7bfdd503233f)
02cfe7ac: mov     w1, #2                                     
02cfe7b0: ldr     x20, [x8, #8]                              
02cfe7b4: bl      #0x2b70ea0                                 fn_2b70ea0
02cfe7b8: cbz     x0, #0x2cfe870                             
02cfe7bc: mov     x21, x0                                    
02cfe7c0: cbz     x22, #0x2cfe7d8                            
02cfe7c4: ldr     x8, [x21]                                  &2c5bbd4(=a9bd7bfdd503233f)
02cfe7c8: mov     x0, x22                                    
02cfe7cc: ldr     x1, [x8, #0x40]                            
02cfe7d0: bl      #0x2b70f34                                 fn_2b70f34
02cfe7d4: cbz     x0, #0x2cfe878                             
02cfe7d8: ldr     w8, [x21, #0x18]                           &2c5d934(=d65f03c0d503245f) .defaultAmplitude
02cfe7dc: cbz     w8, #0x2cfe874                             
02cfe7e0: mov     x0, x21                                    
02cfe7e4: mov     x1, x22                                    
02cfe7e8: str     x22, [x0, #0x20]!                          .isInitialized
02cfe7ec: bl      #0x2b70d54                                 fn_2b70d54
02cfe7f0: adrp    x8, #0x6263000                             
02cfe7f4: add     x1, sp, #0xc                               
02cfe7f8: ldr     x8, [x8, #0x970]                           &6645c70(=0)
02cfe7fc: str     w19, [sp, #0xc]                            
02cfe800: ldr     x0, [x8, #0x48]                            &6263098(=0)
02cfe804: bl      #0x2b70f38                                 fn_2b70f38
02cfe808: mov     x19, x0                                    
02cfe80c: cbz     x0, #0x2cfe824                             
02cfe810: ldr     x8, [x21]                                  &2c5bbd4(=a9bd7bfdd503233f)
02cfe814: mov     x0, x19                                    
02cfe818: ldr     x1, [x8, #0x40]                            [6263040]=0 f=0,0
02cfe81c: bl      #0x2b70f34                                 fn_2b70f34
02cfe820: cbz     x0, #0x2cfe878                             
02cfe824: ldr     w8, [x21, #0x18]                           &2c5d934(=d65f03c0d503245f) .defaultAmplitude
02cfe828: tst     w8, #0xfffffffe                            
02cfe82c: b.eq    #0x2cfe874                                 
02cfe830: mov     x0, x21                                    
02cfe834: mov     x1, x19                                    
02cfe838: str     x19, [x0, #0x28]!                          
02cfe83c: bl      #0x2b70d54                                 fn_2b70d54
02cfe840: cbz     x20, #0x2cfe870                            
02cfe844: adrp    x8, #0x6268000                             
02cfe848: mov     x0, x20                                    
02cfe84c: mov     x2, x21                                    
02cfe850: ldr     x8, [x8, #0xd90]                           S:'vibrate'
02cfe854: mov     x3, xzr                                    
02cfe858: ldr     x1, [x8]                                   S:'{0}/2'
02cfe85c: bl      #0x5ad5e34                                 UnityEngine.AndroidJavaObject::Call
02cfe860: ldp     x20, x19, [sp, #0x20]                      
02cfe864: ldp     x22, x21, [sp, #0x10]                      
02cfe868: ldr     x30, [sp], #0x30                           
02cfe86c: ret                                                
02cfe870: bl      #0x2b7105c                                 fn_2b7105c
02cfe874: bl      #0x2b71064                                 fn_2b71064
02cfe878: bl      #0x2b71080                                 fn_2b71080
02cfe87c: mov     x1, xzr                                    
02cfe880: bl      #0x2b70f20                                 fn_2b70f20
## vibrateEffect(long[] pattern, int[] amplitudes, int repeat) -> void
---- RDG.Vibration::vibrateEffect 0x2cfe314
02cfe314: sub     sp, sp, #0x50                              
02cfe318: stp     x30, x23, [sp, #0x20]                      
02cfe31c: stp     x22, x21, [sp, #0x30]                      
02cfe320: stp     x20, x19, [sp, #0x40]                      
02cfe324: adrp    x23, #0x662f000                            
02cfe328: adrp    x22, #0x6268000                            
02cfe32c: mov     w19, w2                                    
02cfe330: ldrb    w8, [x23, #0xeed]                          
02cfe334: ldr     x22, [x22, #0xcd8]                         T:RDG.Vibration
02cfe338: mov     x20, x1                                    
02cfe33c: mov     x21, x0                                    
02cfe340: tbnz    w8, #0, #0x2cfe37c                         
02cfe344: adrp    x0, #0x6263000                             
02cfe348: ldr     x0, [x0, #0x980]                           T:System.IDisposable
02cfe34c: bl      #0x2b70db0                                 fn_2b70db0
02cfe350: adrp    x0, #0x6263000                             
02cfe354: ldr     x0, [x0, #0xa80]                           T:type24502(k1d)
02cfe358: bl      #0x2b70db0                                 fn_2b70db0
02cfe35c: adrp    x0, #0x6268000                             
02cfe360: ldr     x0, [x0, #0xcd8]                           T:RDG.Vibration
02cfe364: bl      #0x2b70db0                                 fn_2b70db0
02cfe368: adrp    x0, #0x6268000                             
02cfe36c: ldr     x0, [x0, #0xd90]                           S:'vibrate'
02cfe370: bl      #0x2b70db0                                 fn_2b70db0
02cfe374: mov     w8, #1                                     
02cfe378: strb    w8, [x23, #0xeed]                          
02cfe37c: ldr     x0, [x22]                                  S:'{0}/2'
02cfe380: str     xzr, [sp, #0x18]                           
02cfe384: ldr     w8, [x0, #0xe4]                            [62680e4]=0 f=0,0
02cfe388: cbnz    w8, #0x2cfe390                             
02cfe38c: bl      #0x2b70f30                                 fn_2b70f30
02cfe390: mov     x0, x21                                    
02cfe394: mov     x1, x20                                    
02cfe398: mov     w2, w19                                    
02cfe39c: bl      #0x2cff134                                 RDG.Vibration::createEffect_Waveform
02cfe3a0: mov     x8, x0                                     
02cfe3a4: ldr     x0, [x22]                                  S:'{0}/2'
02cfe3a8: add     x9, sp, #0x18                              
02cfe3ac: str     x8, [sp, #0x18]                            
02cfe3b0: ldr     w8, [x0, #0xe4]                            [62680e4]=0 f=0,0
02cfe3b4: stp     xzr, x9, [sp, #8]                          
02cfe3b8: cbnz    w8, #0x2cfe3c4                             
02cfe3bc: bl      #0x2b70f30                                 fn_2b70f30
02cfe3c0: ldr     x0, [x22]                                  S:'{0}/2'
02cfe3c4: adrp    x8, #0x6263000                             
02cfe3c8: ldr     x8, [x8, #0xa80]                           T:type24502(k1d)
02cfe3cc: ldr     x9, [x0, #0xb8]                            T:LuckyWheelPopup/<>c__DisplayClass54_0
02cfe3d0: ldr     x19, [x9, #8]                              
02cfe3d4: ldr     x0, [x8]                                   &2c5bbd4(=a9bd7bfdd503233f)
02cfe3d8: mov     w1, #1                                     
02cfe3dc: bl      #0x2b70ea0                                 fn_2b70ea0
02cfe3e0: mov     x20, x0                                    
02cfe3e4: cbz     x0, #0x2cfe4c4                             
02cfe3e8: ldr     x21, [sp, #0x18]                           
02cfe3ec: cbz     x21, #0x2cfe404                            
02cfe3f0: ldr     x8, [x20]                                  
02cfe3f4: ldr     x1, [x8, #0x40]                            [6263040]=0 f=0,0
02cfe3f8: mov     x0, x21                                    
02cfe3fc: bl      #0x2b70f34                                 fn_2b70f34
02cfe400: cbz     x0, #0x2cfe4d4                             
02cfe404: ldr     w8, [x20, #0x18]                           .defaultAmplitude
02cfe408: cbz     w8, #0x2cfe4d0                             
02cfe40c: mov     x0, x20                                    
02cfe410: str     x21, [x0, #0x20]!                          .isInitialized
02cfe414: mov     x1, x21                                    
02cfe418: bl      #0x2b70d54                                 fn_2b70d54
02cfe41c: cbz     x19, #0x2cfe4c4                            
02cfe420: adrp    x8, #0x6268000                             
02cfe424: ldr     x8, [x8, #0xd90]                           S:'vibrate'
02cfe428: ldr     x1, [x8]                                   S:'{0}/2'
02cfe42c: mov     x0, x19                                    
02cfe430: mov     x2, x20                                    
02cfe434: mov     x3, xzr                                    
02cfe438: bl      #0x5ad5e34                                 UnityEngine.AndroidJavaObject::Call
02cfe43c: mov     x19, xzr                                   
02cfe440: add     x8, sp, #0x18                              
02cfe444: ldr     x20, [x8]                                  S:'{0}/2'
02cfe448: cbz     x20, #0x2cfe4ac                            
02cfe44c: adrp    x10, #0x6263000                            
02cfe450: ldr     x8, [x20]                                  
02cfe454: ldr     x10, [x10, #0x980]                         T:System.IDisposable
02cfe458: ldrh    w9, [x8, #0x12e]                           
02cfe45c: ldr     x1, [x10]                                  &2c5bbd4(=a9bd7bfdd503233f)
02cfe460: cbz     x9, #0x2cfe484                             
02cfe464: ldr     x10, [x8, #0xb0]                           S:'penguin_close_mouth'
02cfe468: add     x10, x10, #8                               &6263008
02cfe46c: ldur    x11, [x10, #-8]                            
02cfe470: cmp     x11, x1                                    
02cfe474: b.eq    #0x2cfe494                                 
02cfe478: subs    x9, x9, #1                                 
02cfe47c: add     x10, x10, #0x10                            &6263010
02cfe480: b.ne    #0x2cfe46c                                 
02cfe484: mov     x0, x20                                    
02cfe488: mov     w2, wzr                                    
02cfe48c: bl      #0x2baa05c                                 fn_2baa05c
02cfe490: b       #0x2cfe4a0                                 
02cfe494: ldrsw   x9, [x10]                                  
02cfe498: add     x8, x8, x9, lsl #4                         &6268000
02cfe49c: add     x0, x8, #0x138                             &6268138
02cfe4a0: ldp     x8, x1, [x0]                               
02cfe4a4: mov     x0, x20                                    
02cfe4a8: blr     x8                                         
02cfe4ac: cbnz    x19, #0x2cfe4c8                            
02cfe4b0: ldp     x20, x19, [sp, #0x40]                      
02cfe4b4: ldp     x22, x21, [sp, #0x30]                      
02cfe4b8: ldp     x30, x23, [sp, #0x20]                      
02cfe4bc: add     sp, sp, #0x50                              
02cfe4c0: ret                                                
02cfe4c4: bl      #0x2b7105c                                 fn_2b7105c
02cfe4c8: mov     x0, x19                                    
02cfe4cc: bl      #0x2b71054                                 fn_2b71054
02cfe4d0: bl      #0x2b71064                                 fn_2b71064
02cfe4d4: bl      #0x2b71080                                 fn_2b71080
02cfe4d8: mov     x1, xzr                                    
02cfe4dc: bl      #0x2b70f20                                 fn_2b70f20
02cfe4e0: b       #0x2cfe4e8                                 
02cfe4e4: b       #0x2cfe4e8                                 
02cfe4e8: mov     x19, x0                                    
02cfe4ec: cmp     w1, #1                                     
02cfe4f0: b.ne    #0x2cfe514                                 
02cfe4f4: mov     x0, x19                                    
02cfe4f8: bl      #0x5e90260                                 fn_5e90260
02cfe4fc: ldr     x19, [x0]                                  S:'{0}/2'
02cfe500: str     x19, [sp, #8]                              
02cfe504: bl      #0x5e90270                                 fn_5e90270
02cfe508: ldr     x8, [sp, #0x10]                            
02cfe50c: b       #0x2cfe444                                 
02cfe510: mov     x19, x0                                    
02cfe514: add     x0, sp, #8                                 
02cfe518: bl      #0x27369c4                                 fn_27369c4
02cfe51c: mov     x0, x19                                    
02cfe520: bl      #0x2c6051c                                 fn_2c6051c
02cfe524: bl      #0x27369b8                                 fn_27369b8
## vibrateEffectPredefined(int effectId) -> void
---- RDG.Vibration::vibrateEffectPredefined 0x2cfea74
02cfea74: sub     sp, sp, #0x40                              
02cfea78: stp     x30, x21, [sp, #0x20]                      
02cfea7c: stp     x20, x19, [sp, #0x30]                      
02cfea80: adrp    x21, #0x662f000                            
02cfea84: adrp    x20, #0x6268000                            
02cfea88: mov     w19, w0                                    
02cfea8c: ldrb    w8, [x21, #0xeee]                          
02cfea90: ldr     x20, [x20, #0xcd8]                         T:RDG.Vibration
02cfea94: tbnz    w8, #0, #0x2cfead0                         
02cfea98: adrp    x0, #0x6263000                             
02cfea9c: ldr     x0, [x0, #0x980]                           T:System.IDisposable
02cfeaa0: bl      #0x2b70db0                                 fn_2b70db0
02cfeaa4: adrp    x0, #0x6263000                             
02cfeaa8: ldr     x0, [x0, #0xa80]                           T:type24502(k1d)
02cfeaac: bl      #0x2b70db0                                 fn_2b70db0
02cfeab0: adrp    x0, #0x6268000                             
02cfeab4: ldr     x0, [x0, #0xcd8]                           T:RDG.Vibration
02cfeab8: bl      #0x2b70db0                                 fn_2b70db0
02cfeabc: adrp    x0, #0x6268000                             
02cfeac0: ldr     x0, [x0, #0xd90]                           S:'vibrate'
02cfeac4: bl      #0x2b70db0                                 fn_2b70db0
02cfeac8: mov     w8, #1                                     
02cfeacc: strb    w8, [x21, #0xeee]                          
02cfead0: ldr     x0, [x20]                                  S:'{0}/2'
02cfead4: str     xzr, [sp, #0x18]                           
02cfead8: ldr     w8, [x0, #0xe4]                            [62680e4]=0 f=0,0
02cfeadc: cbnz    w8, #0x2cfeae4                             
02cfeae0: bl      #0x2b70f30                                 fn_2b70f30
02cfeae4: mov     w0, w19                                    
02cfeae8: bl      #0x2cff2d8                                 RDG.Vibration::createEffect_Predefined
02cfeaec: mov     x8, x0                                     
02cfeaf0: ldr     x0, [x20]                                  S:'{0}/2'
02cfeaf4: add     x9, sp, #0x18                              
02cfeaf8: str     x8, [sp, #0x18]                            
02cfeafc: ldr     w8, [x0, #0xe4]                            [62680e4]=0 f=0,0
02cfeb00: stp     xzr, x9, [sp, #8]                          
02cfeb04: cbnz    w8, #0x2cfeb10                             
02cfeb08: bl      #0x2b70f30                                 fn_2b70f30
02cfeb0c: ldr     x0, [x20]                                  S:'{0}/2'
02cfeb10: adrp    x8, #0x6263000                             
02cfeb14: ldr     x8, [x8, #0xa80]                           T:type24502(k1d)
02cfeb18: ldr     x9, [x0, #0xb8]                            T:LuckyWheelPopup/<>c__DisplayClass54_0
02cfeb1c: ldr     x19, [x9, #8]                              
02cfeb20: ldr     x0, [x8]                                   &2c5bbd4(=a9bd7bfdd503233f)
02cfeb24: mov     w1, #1                                     
02cfeb28: bl      #0x2b70ea0                                 fn_2b70ea0
02cfeb2c: mov     x20, x0                                    
02cfeb30: cbz     x0, #0x2cfec0c                             
02cfeb34: ldr     x21, [sp, #0x18]                           
02cfeb38: cbz     x21, #0x2cfeb50                            
02cfeb3c: ldr     x8, [x20]                                  S:'{0}/2'
02cfeb40: ldr     x1, [x8, #0x40]                            [6263040]=0 f=0,0
02cfeb44: mov     x0, x21                                    
02cfeb48: bl      #0x2b70f34                                 fn_2b70f34
02cfeb4c: cbz     x0, #0x2cfec1c                             
02cfeb50: ldr     w8, [x20, #0x18]                           M:LuckyWheelPopup/<>c__DisplayClass50_0::<RunAnimation>b__0 .defaultAmplitude
02cfeb54: cbz     w8, #0x2cfec18                             
02cfeb58: mov     x0, x20                                    
02cfeb5c: str     x21, [x0, #0x20]!                          .isInitialized
02cfeb60: mov     x1, x21                                    
02cfeb64: bl      #0x2b70d54                                 fn_2b70d54
02cfeb68: cbz     x19, #0x2cfec0c                            
02cfeb6c: adrp    x8, #0x6268000                             
02cfeb70: ldr     x8, [x8, #0xd90]                           S:'vibrate'
02cfeb74: ldr     x1, [x8]                                   S:'{0}/2'
02cfeb78: mov     x0, x19                                    
02cfeb7c: mov     x2, x20                                    
02cfeb80: mov     x3, xzr                                    
02cfeb84: bl      #0x5ad5e34                                 UnityEngine.AndroidJavaObject::Call
02cfeb88: mov     x19, xzr                                   
02cfeb8c: add     x8, sp, #0x18                              
02cfeb90: ldr     x20, [x8]                                  S:'{0}/2'
02cfeb94: cbz     x20, #0x2cfebf8                            
02cfeb98: adrp    x10, #0x6263000                            
02cfeb9c: ldr     x8, [x20]                                  S:'{0}/2'
02cfeba0: ldr     x10, [x10, #0x980]                         T:System.IDisposable
02cfeba4: ldrh    w9, [x8, #0x12e]                           
02cfeba8: ldr     x1, [x10]                                  &2c5bbd4(=a9bd7bfdd503233f)
02cfebac: cbz     x9, #0x2cfebd0                             
02cfebb0: ldr     x10, [x8, #0xb0]                           S:'penguin_close_mouth'
02cfebb4: add     x10, x10, #8                               &6263008
02cfebb8: ldur    x11, [x10, #-8]                            
02cfebbc: cmp     x11, x1                                    
02cfebc0: b.eq    #0x2cfebe0                                 
02cfebc4: subs    x9, x9, #1                                 
02cfebc8: add     x10, x10, #0x10                            &6263010
02cfebcc: b.ne    #0x2cfebb8                                 
02cfebd0: mov     x0, x20                                    
02cfebd4: mov     w2, wzr                                    
02cfebd8: bl      #0x2baa05c                                 fn_2baa05c
02cfebdc: b       #0x2cfebec                                 
02cfebe0: ldrsw   x9, [x10]                                  
02cfebe4: add     x8, x8, x9, lsl #4                         &6268000
02cfebe8: add     x0, x8, #0x138                             &6268138
02cfebec: ldp     x8, x1, [x0]                               
02cfebf0: mov     x0, x20                                    
02cfebf4: blr     x8                                         
02cfebf8: cbnz    x19, #0x2cfec10                            
02cfebfc: ldp     x20, x19, [sp, #0x30]                      
02cfec00: ldp     x30, x21, [sp, #0x20]                      
02cfec04: add     sp, sp, #0x40                              
02cfec08: ret                                                
02cfec0c: bl      #0x2b7105c                                 fn_2b7105c
02cfec10: mov     x0, x19                                    
02cfec14: bl      #0x2b71054                                 fn_2b71054
02cfec18: bl      #0x2b71064                                 fn_2b71064
02cfec1c: bl      #0x2b71080                                 fn_2b71080
02cfec20: mov     x1, xzr                                    
02cfec24: bl      #0x2b70f20                                 fn_2b70f20
02cfec28: b       #0x2cfec30                                 
02cfec2c: b       #0x2cfec30                                 
02cfec30: mov     x19, x0                                    
02cfec34: cmp     w1, #1                                     
02cfec38: b.ne    #0x2cfec5c                                 
02cfec3c: mov     x0, x19                                    
02cfec40: bl      #0x5e90260                                 fn_5e90260
02cfec44: ldr     x19, [x0]                                  S:'{0}/2'
02cfec48: str     x19, [sp, #8]                              
02cfec4c: bl      #0x5e90270                                 fn_5e90270
02cfec50: ldr     x8, [sp, #0x10]                            
02cfec54: b       #0x2cfeb90                                 
02cfec58: mov     x19, x0                                    
02cfec5c: add     x0, sp, #8                                 
02cfec60: bl      #0x27369c4                                 fn_27369c4
02cfec64: mov     x0, x19                                    
02cfec68: bl      #0x2c6051c                                 fn_2c6051c
02cfec6c: bl      #0x27369b8                                 fn_27369b8
## createEffect_OneShot(long milliseconds, int amplitude) -> UnityEngine.AndroidJavaObject
---- RDG.Vibration::createEffect_OneShot 0x2cfee50
02cfee50: sub     sp, sp, #0x40                              
02cfee54: stp     x30, x23, [sp, #0x10]                      
02cfee58: stp     x22, x21, [sp, #0x20]                      
02cfee5c: stp     x20, x19, [sp, #0x30]                      
02cfee60: adrp    x21, #0x662f000                            
02cfee64: adrp    x20, #0x6268000                            
02cfee68: mov     w19, w1                                    
02cfee6c: ldrb    w8, [x21, #0xeef]                          
02cfee70: ldr     x20, [x20, #0xcd8]                         T:RDG.Vibration
02cfee74: mov     x22, x0                                    
02cfee78: tbnz    w8, #0, #0x2cfeeb4                         
02cfee7c: adrp    x0, #0x6266000                             
02cfee80: ldr     x0, [x0, #0x160]                           MS:UnityEngine.AndroidJavaObject::CallStatic
02cfee84: bl      #0x2b70db0                                 fn_2b70db0
02cfee88: adrp    x0, #0x6263000                             
02cfee8c: ldr     x0, [x0, #0xa80]                           T:type24502(k1d)
02cfee90: bl      #0x2b70db0                                 fn_2b70db0
02cfee94: adrp    x0, #0x6268000                             
02cfee98: ldr     x0, [x0, #0xcd8]                           T:RDG.Vibration
02cfee9c: bl      #0x2b70db0                                 fn_2b70db0
02cfeea0: adrp    x0, #0x6268000                             
02cfeea4: ldr     x0, [x0, #0xdd8]                           S:'createOneShot'
02cfeea8: bl      #0x2b70db0                                 fn_2b70db0
02cfeeac: mov     w8, #1                                     
02cfeeb0: strb    w8, [x21, #0xeef]                          
02cfeeb4: ldr     x0, [x20]                                  S:'{0}/2'
02cfeeb8: adrp    x21, #0x6263000                            
02cfeebc: ldr     w8, [x0, #0xe4]                            [62680e4]=0 f=0,0
02cfeec0: ldr     x21, [x21, #0xa80]                         T:type24502(k1d)
02cfeec4: cbnz    w8, #0x2cfeed0                             
02cfeec8: bl      #0x2b70f30                                 fn_2b70f30
02cfeecc: ldr     x0, [x20]                                  S:'{0}/2'
02cfeed0: ldr     x8, [x0, #0xb8]                            T:LuckyWheelPopup/<>c__DisplayClass54_0
02cfeed4: ldr     x0, [x21]                                  &2c5bbd4(=a9bd7bfdd503233f)
02cfeed8: mov     w1, #2                                     
02cfeedc: ldr     x20, [x8, #0x10]                           
02cfeee0: bl      #0x2b70ea0                                 fn_2b70ea0
02cfeee4: adrp    x23, #0x6263000                            
02cfeee8: mov     x21, x0                                    
02cfeeec: add     x1, sp, #8                                 
02cfeef0: ldr     x23, [x23, #0x970]                         &6645c70(=0)
02cfeef4: str     x22, [sp, #8]                              
02cfeef8: ldr     x0, [x23, #0x68]                           &2c497cc(=d65f03c0d503245f)
02cfeefc: bl      #0x2b70f38                                 fn_2b70f38
02cfef00: cbz     x21, #0x2cfefbc                            
02cfef04: mov     x22, x0                                    
02cfef08: cbz     x0, #0x2cfef20                             
02cfef0c: ldr     x8, [x21]                                  &2c5bbd4(=a9bd7bfdd503233f)
02cfef10: mov     x0, x22                                    
02cfef14: ldr     x1, [x8, #0x40]                            
02cfef18: bl      #0x2b70f34                                 fn_2b70f34
02cfef1c: cbz     x0, #0x2cfefc4                             
02cfef20: ldr     w8, [x21, #0x18]                           &2c5d934(=d65f03c0d503245f) .defaultAmplitude
02cfef24: cbz     w8, #0x2cfefc0                             
02cfef28: mov     x0, x21                                    
02cfef2c: mov     x1, x22                                    
02cfef30: str     x22, [x0, #0x20]!                          .isInitialized
02cfef34: bl      #0x2b70d54                                 fn_2b70d54
02cfef38: ldr     x0, [x23, #0x48]                           &6263098(=0)
02cfef3c: add     x1, sp, #4                                 
02cfef40: str     w19, [sp, #4]                              
02cfef44: bl      #0x2b70f38                                 fn_2b70f38
02cfef48: mov     x19, x0                                    
02cfef4c: cbz     x0, #0x2cfef64                             
02cfef50: ldr     x8, [x21]                                  &2c5bbd4(=a9bd7bfdd503233f)
02cfef54: mov     x0, x19                                    
02cfef58: ldr     x1, [x8, #0x40]                            
02cfef5c: bl      #0x2b70f34                                 fn_2b70f34
02cfef60: cbz     x0, #0x2cfefc4                             
02cfef64: ldr     w8, [x21, #0x18]                           &2c5d934(=d65f03c0d503245f) .defaultAmplitude
02cfef68: tst     w8, #0xfffffffe                            
02cfef6c: b.eq    #0x2cfefc0                                 
02cfef70: mov     x0, x21                                    
02cfef74: mov     x1, x19                                    
02cfef78: str     x19, [x0, #0x28]!                          
02cfef7c: bl      #0x2b70d54                                 fn_2b70d54
02cfef80: cbz     x20, #0x2cfefbc                            
02cfef84: adrp    x8, #0x6268000                             
02cfef88: adrp    x9, #0x6266000                             
02cfef8c: mov     x0, x20                                    
02cfef90: ldr     x8, [x8, #0xdd8]                           S:'createOneShot'
02cfef94: ldr     x9, [x9, #0x160]                           MS:UnityEngine.AndroidJavaObject::CallStatic
02cfef98: mov     x2, x21                                    
02cfef9c: ldr     x1, [x8]                                   S:'{0}/2'
02cfefa0: ldr     x3, [x9]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cfefa4: bl      #0x31200ac                                 fn_31200ac
02cfefa8: ldp     x20, x19, [sp, #0x30]                      
02cfefac: ldp     x22, x21, [sp, #0x20]                      
02cfefb0: ldp     x30, x23, [sp, #0x10]                      
02cfefb4: add     sp, sp, #0x40                              
02cfefb8: ret                                                
02cfefbc: bl      #0x2b7105c                                 fn_2b7105c
02cfefc0: bl      #0x2b71064                                 fn_2b71064
02cfefc4: bl      #0x2b71080                                 fn_2b71080
02cfefc8: mov     x1, xzr                                    
02cfefcc: bl      #0x2b70f20                                 fn_2b70f20
## createEffect_Predefined(int effectId) -> UnityEngine.AndroidJavaObject
---- RDG.Vibration::createEffect_Predefined 0x2cff2d8
02cff2d8: sub     sp, sp, #0x30                              
02cff2dc: stp     x30, x21, [sp, #0x10]                      
02cff2e0: stp     x20, x19, [sp, #0x20]                      
02cff2e4: adrp    x21, #0x662f000                            
02cff2e8: adrp    x20, #0x6268000                            
02cff2ec: mov     w19, w0                                    
02cff2f0: ldrb    w8, [x21, #0xef0]                          
02cff2f4: ldr     x20, [x20, #0xcd8]                         T:RDG.Vibration
02cff2f8: tbnz    w8, #0, #0x2cff334                         
02cff2fc: adrp    x0, #0x6266000                             
02cff300: ldr     x0, [x0, #0x160]                           MS:UnityEngine.AndroidJavaObject::CallStatic
02cff304: bl      #0x2b70db0                                 fn_2b70db0
02cff308: adrp    x0, #0x6263000                             
02cff30c: ldr     x0, [x0, #0xa80]                           T:type24502(k1d)
02cff310: bl      #0x2b70db0                                 fn_2b70db0
02cff314: adrp    x0, #0x6268000                             
02cff318: ldr     x0, [x0, #0xcd8]                           T:RDG.Vibration
02cff31c: bl      #0x2b70db0                                 fn_2b70db0
02cff320: adrp    x0, #0x6268000                             
02cff324: ldr     x0, [x0, #0xde8]                           S:'createPredefined'
02cff328: bl      #0x2b70db0                                 fn_2b70db0
02cff32c: mov     w8, #1                                     
02cff330: strb    w8, [x21, #0xef0]                          
02cff334: ldr     x0, [x20]                                  S:'{0}/2'
02cff338: adrp    x21, #0x6263000                            
02cff33c: ldr     w8, [x0, #0xe4]                            [62680e4]=0 f=0,0
02cff340: ldr     x21, [x21, #0xa80]                         T:type24502(k1d)
02cff344: cbnz    w8, #0x2cff350                             
02cff348: bl      #0x2b70f30                                 fn_2b70f30
02cff34c: ldr     x0, [x20]                                  S:'{0}/2'
02cff350: ldr     x8, [x0, #0xb8]                            T:LuckyWheelPopup/<>c__DisplayClass54_0
02cff354: ldr     x0, [x21]                                  &2c5bbd4(=a9bd7bfdd503233f)
02cff358: mov     w1, #1                                     
02cff35c: ldr     x20, [x8, #0x10]                           
02cff360: bl      #0x2b70ea0                                 fn_2b70ea0
02cff364: adrp    x8, #0x6263000                             
02cff368: mov     x21, x0                                    
02cff36c: add     x1, sp, #0xc                               
02cff370: ldr     x8, [x8, #0x970]                           &6645c70(=0)
02cff374: str     w19, [sp, #0xc]                            
02cff378: ldr     x0, [x8, #0x48]                            &6263098(=0)
02cff37c: bl      #0x2b70f38                                 fn_2b70f38
02cff380: cbz     x21, #0x2cff3f0                            
02cff384: mov     x19, x0                                    
02cff388: cbz     x0, #0x2cff3a0                             
02cff38c: ldr     x8, [x21]                                  &2c5bbd4(=a9bd7bfdd503233f)
02cff390: mov     x0, x19                                    
02cff394: ldr     x1, [x8, #0x40]                            [6263040]=0 f=0,0
02cff398: bl      #0x2b70f34                                 fn_2b70f34
02cff39c: cbz     x0, #0x2cff3f8                             
02cff3a0: ldr     w8, [x21, #0x18]                           &2c5d934(=d65f03c0d503245f) .defaultAmplitude
02cff3a4: cbz     w8, #0x2cff3f4                             
02cff3a8: mov     x0, x21                                    
02cff3ac: mov     x1, x19                                    
02cff3b0: str     x19, [x0, #0x20]!                          .isInitialized
02cff3b4: bl      #0x2b70d54                                 fn_2b70d54
02cff3b8: cbz     x20, #0x2cff3f0                            
02cff3bc: adrp    x8, #0x6268000                             
02cff3c0: adrp    x9, #0x6266000                             
02cff3c4: mov     x0, x20                                    
02cff3c8: ldr     x8, [x8, #0xde8]                           S:'createPredefined'
02cff3cc: ldr     x9, [x9, #0x160]                           MS:UnityEngine.AndroidJavaObject::CallStatic
02cff3d0: mov     x2, x21                                    
02cff3d4: ldr     x1, [x8]                                   S:'{0}/2'
02cff3d8: ldr     x3, [x9]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cff3dc: bl      #0x31200ac                                 fn_31200ac
02cff3e0: ldp     x20, x19, [sp, #0x20]                      
02cff3e4: ldp     x30, x21, [sp, #0x10]                      
02cff3e8: add     sp, sp, #0x30                              
02cff3ec: ret                                                
02cff3f0: bl      #0x2b7105c                                 fn_2b7105c
02cff3f4: bl      #0x2b71064                                 fn_2b71064
02cff3f8: bl      #0x2b71080                                 fn_2b71080
02cff3fc: mov     x1, xzr                                    
02cff400: bl      #0x2b70f20                                 fn_2b70f20
## createEffect_Waveform(long[] timings, int[] amplitudes, int repeat) -> UnityEngine.AndroidJavaObject
---- RDG.Vibration::createEffect_Waveform 0x2cff134
02cff134: sub     sp, sp, #0x40                              
02cff138: stp     x30, x23, [sp, #0x10]                      
02cff13c: stp     x22, x21, [sp, #0x20]                      
02cff140: stp     x20, x19, [sp, #0x30]                      
02cff144: adrp    x22, #0x662f000                            
02cff148: adrp    x21, #0x6268000                            
02cff14c: mov     w19, w2                                    
02cff150: ldrb    w8, [x22, #0xef1]                          
02cff154: ldr     x21, [x21, #0xcd8]                         T:RDG.Vibration
02cff158: mov     x20, x1                                    
02cff15c: mov     x23, x0                                    
02cff160: tbnz    w8, #0, #0x2cff19c                         
02cff164: adrp    x0, #0x6266000                             
02cff168: ldr     x0, [x0, #0x160]                           MS:UnityEngine.AndroidJavaObject::CallStatic
02cff16c: bl      #0x2b70db0                                 fn_2b70db0
02cff170: adrp    x0, #0x6263000                             
02cff174: ldr     x0, [x0, #0xa80]                           T:type24502(k1d)
02cff178: bl      #0x2b70db0                                 fn_2b70db0
02cff17c: adrp    x0, #0x6268000                             
02cff180: ldr     x0, [x0, #0xcd8]                           T:RDG.Vibration
02cff184: bl      #0x2b70db0                                 fn_2b70db0
02cff188: adrp    x0, #0x6268000                             
02cff18c: ldr     x0, [x0, #0xde0]                           S:'createWaveform'
02cff190: bl      #0x2b70db0                                 fn_2b70db0
02cff194: mov     w8, #1                                     
02cff198: strb    w8, [x22, #0xef1]                          
02cff19c: ldr     x0, [x21]                                  S:'{0}/2'
02cff1a0: adrp    x22, #0x6263000                            
02cff1a4: ldr     w8, [x0, #0xe4]                            [62680e4]=0 f=0,0
02cff1a8: ldr     x22, [x22, #0xa80]                         T:type24502(k1d)
02cff1ac: cbnz    w8, #0x2cff1b8                             
02cff1b0: bl      #0x2b70f30                                 fn_2b70f30
02cff1b4: ldr     x0, [x21]                                  S:'{0}/2'
02cff1b8: ldr     x8, [x0, #0xb8]                            T:LuckyWheelPopup/<>c__DisplayClass54_0
02cff1bc: ldr     x0, [x22]                                  &2c5bbd4(=a9bd7bfdd503233f)
02cff1c0: mov     w1, #3                                     
02cff1c4: ldr     x21, [x8, #0x10]                           
02cff1c8: bl      #0x2b70ea0                                 fn_2b70ea0
02cff1cc: cbz     x0, #0x2cff2c8                             
02cff1d0: mov     x22, x0                                    
02cff1d4: cbz     x23, #0x2cff1ec                            
02cff1d8: ldr     x8, [x22]                                  &2c5bbd4(=a9bd7bfdd503233f)
02cff1dc: mov     x0, x23                                    
02cff1e0: ldr     x1, [x8, #0x40]                            
02cff1e4: bl      #0x2b70f34                                 fn_2b70f34
02cff1e8: cbz     x0, #0x2cff2cc                             
02cff1ec: ldr     w8, [x22, #0x18]                           &2c5d934(=d65f03c0d503245f)
02cff1f0: cbz     w8, #0x2cff2c4                             
02cff1f4: mov     x0, x22                                    
02cff1f8: mov     x1, x23                                    
02cff1fc: str     x23, [x0, #0x20]!                          .isInitialized
02cff200: bl      #0x2b70d54                                 fn_2b70d54
02cff204: cbz     x20, #0x2cff21c                            
02cff208: ldr     x8, [x22]                                  &2c5bbd4(=a9bd7bfdd503233f)
02cff20c: mov     x0, x20                                    
02cff210: ldr     x1, [x8, #0x40]                            
02cff214: bl      #0x2b70f34                                 fn_2b70f34
02cff218: cbz     x0, #0x2cff2cc                             
02cff21c: ldr     w8, [x22, #0x18]                           &2c5d934(=d65f03c0d503245f)
02cff220: tst     w8, #0xfffffffe                            
02cff224: b.eq    #0x2cff2c4                                 
02cff228: mov     x0, x22                                    
02cff22c: mov     x1, x20                                    
02cff230: str     x20, [x0, #0x28]!                          
02cff234: bl      #0x2b70d54                                 fn_2b70d54
02cff238: adrp    x8, #0x6263000                             
02cff23c: add     x1, sp, #0xc                               
02cff240: ldr     x8, [x8, #0x970]                           &6645c70(=0)
02cff244: str     w19, [sp, #0xc]                            
02cff248: ldr     x0, [x8, #0x48]                            &6263098(=0)
02cff24c: bl      #0x2b70f38                                 fn_2b70f38
02cff250: mov     x19, x0                                    
02cff254: cbz     x0, #0x2cff26c                             
02cff258: ldr     x8, [x22]                                  &2c5bbd4(=a9bd7bfdd503233f)
02cff25c: mov     x0, x19                                    
02cff260: ldr     x1, [x8, #0x40]                            [6263040]=0 f=0,0
02cff264: bl      #0x2b70f34                                 fn_2b70f34
02cff268: cbz     x0, #0x2cff2cc                             
02cff26c: ldr     w8, [x22, #0x18]                           &2c5d934(=d65f03c0d503245f)
02cff270: cmp     w8, #2                                     
02cff274: b.ls    #0x2cff2c4                                 
02cff278: mov     x0, x22                                    
02cff27c: mov     x1, x19                                    
02cff280: str     x19, [x0, #0x30]!                          
02cff284: bl      #0x2b70d54                                 fn_2b70d54
02cff288: cbz     x21, #0x2cff2c8                            
02cff28c: adrp    x8, #0x6268000                             
02cff290: adrp    x9, #0x6266000                             
02cff294: mov     x0, x21                                    
02cff298: ldr     x8, [x8, #0xde0]                           S:'createWaveform'
02cff29c: ldr     x9, [x9, #0x160]                           MS:UnityEngine.AndroidJavaObject::CallStatic
02cff2a0: mov     x2, x22                                    
02cff2a4: ldr     x1, [x8]                                   S:'{0}/2'
02cff2a8: ldr     x3, [x9]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cff2ac: bl      #0x31200ac                                 fn_31200ac
02cff2b0: ldp     x20, x19, [sp, #0x30]                      
02cff2b4: ldp     x22, x21, [sp, #0x20]                      
02cff2b8: ldp     x30, x23, [sp, #0x10]                      
02cff2bc: add     sp, sp, #0x40                              
02cff2c0: ret                                                
02cff2c4: bl      #0x2b71064                                 fn_2b71064
02cff2c8: bl      #0x2b7105c                                 fn_2b7105c
02cff2cc: bl      #0x2b71080                                 fn_2b71080
02cff2d0: mov     x1, xzr                                    
02cff2d4: bl      #0x2b70f20                                 fn_2b70f20
## createEffect_Waveform(long[] timings, int repeat) -> UnityEngine.AndroidJavaObject
---- RDG.Vibration::createEffect_Waveform 0x2cfefd0
02cfefd0: str     x30, [sp, #-0x30]!                         
02cfefd4: stp     x22, x21, [sp, #0x10]                      
02cfefd8: stp     x20, x19, [sp, #0x20]                      
02cfefdc: adrp    x22, #0x662f000                            
02cfefe0: adrp    x20, #0x6268000                            
02cfefe4: mov     w19, w1                                    
02cfefe8: ldrb    w8, [x22, #0xef2]                          
02cfefec: ldr     x20, [x20, #0xcd8]                         T:RDG.Vibration
02cfeff0: mov     x21, x0                                    
02cfeff4: tbnz    w8, #0, #0x2cff030                         
02cfeff8: adrp    x0, #0x6266000                             
02cfeffc: ldr     x0, [x0, #0x160]                           MS:UnityEngine.AndroidJavaObject::CallStatic
02cff000: bl      #0x2b70db0                                 fn_2b70db0
02cff004: adrp    x0, #0x6263000                             
02cff008: ldr     x0, [x0, #0xa80]                           T:type24502(k1d)
02cff00c: bl      #0x2b70db0                                 fn_2b70db0
02cff010: adrp    x0, #0x6268000                             
02cff014: ldr     x0, [x0, #0xcd8]                           T:RDG.Vibration
02cff018: bl      #0x2b70db0                                 fn_2b70db0
02cff01c: adrp    x0, #0x6268000                             
02cff020: ldr     x0, [x0, #0xde0]                           S:'createWaveform'
02cff024: bl      #0x2b70db0                                 fn_2b70db0
02cff028: mov     w8, #1                                     
02cff02c: strb    w8, [x22, #0xef2]                          
02cff030: ldr     x0, [x20]                                  S:'{0}/2'
02cff034: adrp    x22, #0x6263000                            
02cff038: ldr     w8, [x0, #0xe4]                            [62680e4]=0 f=0,0
02cff03c: ldr     x22, [x22, #0xa80]                         T:type24502(k1d)
02cff040: cbnz    w8, #0x2cff04c                             
02cff044: bl      #0x2b70f30                                 fn_2b70f30
02cff048: ldr     x0, [x20]                                  S:'{0}/2'
02cff04c: ldr     x8, [x0, #0xb8]                            T:LuckyWheelPopup/<>c__DisplayClass54_0
02cff050: ldr     x0, [x22]                                  &2c5bbd4(=a9bd7bfdd503233f)
02cff054: mov     w1, #2                                     
02cff058: ldr     x20, [x8, #0x10]                           
02cff05c: bl      #0x2b70ea0                                 fn_2b70ea0
02cff060: cbz     x0, #0x2cff120                             
02cff064: mov     x22, x0                                    
02cff068: cbz     x21, #0x2cff080                            
02cff06c: ldr     x8, [x22]                                  &2c5bbd4(=a9bd7bfdd503233f)
02cff070: mov     x0, x21                                    
02cff074: ldr     x1, [x8, #0x40]                            
02cff078: bl      #0x2b70f34                                 fn_2b70f34
02cff07c: cbz     x0, #0x2cff128                             
02cff080: ldr     w8, [x22, #0x18]                           &2c5d934(=d65f03c0d503245f)
02cff084: cbz     w8, #0x2cff124                             
02cff088: mov     x0, x22                                    
02cff08c: mov     x1, x21                                    
02cff090: str     x21, [x0, #0x20]!                          .isInitialized
02cff094: bl      #0x2b70d54                                 fn_2b70d54
02cff098: adrp    x8, #0x6263000                             
02cff09c: add     x1, sp, #0xc                               
02cff0a0: ldr     x8, [x8, #0x970]                           &6645c70(=0)
02cff0a4: str     w19, [sp, #0xc]                            
02cff0a8: ldr     x0, [x8, #0x48]                            &6263098(=0)
02cff0ac: bl      #0x2b70f38                                 fn_2b70f38
02cff0b0: mov     x19, x0                                    
02cff0b4: cbz     x0, #0x2cff0cc                             
02cff0b8: ldr     x8, [x22]                                  &2c5bbd4(=a9bd7bfdd503233f)
02cff0bc: mov     x0, x19                                    
02cff0c0: ldr     x1, [x8, #0x40]                            [6263040]=0 f=0,0
02cff0c4: bl      #0x2b70f34                                 fn_2b70f34
02cff0c8: cbz     x0, #0x2cff128                             
02cff0cc: ldr     w8, [x22, #0x18]                           &2c5d934(=d65f03c0d503245f)
02cff0d0: tst     w8, #0xfffffffe                            
02cff0d4: b.eq    #0x2cff124                                 
02cff0d8: mov     x0, x22                                    
02cff0dc: mov     x1, x19                                    
02cff0e0: str     x19, [x0, #0x28]!                          
02cff0e4: bl      #0x2b70d54                                 fn_2b70d54
02cff0e8: cbz     x20, #0x2cff120                            
02cff0ec: adrp    x8, #0x6268000                             
02cff0f0: adrp    x9, #0x6266000                             
02cff0f4: mov     x0, x20                                    
02cff0f8: ldr     x8, [x8, #0xde0]                           S:'createWaveform'
02cff0fc: ldr     x9, [x9, #0x160]                           MS:UnityEngine.AndroidJavaObject::CallStatic
02cff100: mov     x2, x22                                    
02cff104: ldr     x1, [x8]                                   S:'{0}/2'
02cff108: ldr     x3, [x9]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cff10c: bl      #0x31200ac                                 fn_31200ac
02cff110: ldp     x20, x19, [sp, #0x20]                      
02cff114: ldp     x22, x21, [sp, #0x10]                      
02cff118: ldr     x30, [sp], #0x30                           
02cff11c: ret                                                
02cff120: bl      #0x2b7105c                                 fn_2b7105c
02cff124: bl      #0x2b71064                                 fn_2b71064
02cff128: bl      #0x2b71080                                 fn_2b71080
02cff12c: mov     x1, xzr                                    
02cff130: bl      #0x2b70f20                                 fn_2b70f20
## logAuto(string text, RDG.Vibration/logLevel level) -> void
---- RDG.Vibration::logAuto 0x2cfd2ac
02cfd2ac: stp     x30, x21, [sp, #-0x20]!                    
02cfd2b0: stp     x20, x19, [sp, #0x10]                      
02cfd2b4: adrp    x21, #0x662f000                            
02cfd2b8: mov     w20, w1                                    
02cfd2bc: mov     x19, x0                                    
02cfd2c0: ldrb    w8, [x21, #0xef3]                          
02cfd2c4: tbnz    w8, #0, #0x2cfd2e8                         
02cfd2c8: adrp    x0, #0x6263000                             
02cfd2cc: ldr     x0, [x0, #0x928]                           T:UnityEngine.Debug
02cfd2d0: bl      #0x2b70db0                                 fn_2b70db0
02cfd2d4: adrp    x0, #0x6268000                             
02cfd2d8: ldr     x0, [x0, #0xcd8]                           T:RDG.Vibration
02cfd2dc: bl      #0x2b70db0                                 fn_2b70db0
02cfd2e0: mov     w8, #1                                     
02cfd2e4: strb    w8, [x21, #0xef3]                          
02cfd2e8: cbz     x19, #0x2cfd3b4                            
02cfd2ec: cmp     w20, #1                                    
02cfd2f0: csinc   w8, w20, wzr, hi                           
02cfd2f4: cmp     w8, #1                                     
02cfd2f8: b.eq    #0x2cfd35c                                 
02cfd2fc: cmp     w8, #2                                     
02cfd300: b.ne    #0x2cfd3b4                                 
02cfd304: adrp    x20, #0x6268000                            
02cfd308: ldr     x20, [x20, #0xcd8]                         T:RDG.Vibration
02cfd30c: ldr     x0, [x20]                                  S:'{0}/2'
02cfd310: ldr     w8, [x0, #0xe4]                            [62680e4]=0 f=0,0
02cfd314: cbnz    w8, #0x2cfd320                             
02cfd318: bl      #0x2b70f30                                 fn_2b70f30
02cfd31c: ldr     x0, [x20]                                  S:'{0}/2'
02cfd320: ldr     x8, [x0, #0xb8]                            T:LuckyWheelPopup/<>c__DisplayClass54_0
02cfd324: ldr     w8, [x8]                                   
02cfd328: cmp     w8, #2                                     
02cfd32c: b.ne    #0x2cfd3b4                                 
02cfd330: adrp    x8, #0x6263000                             
02cfd334: ldr     x8, [x8, #0x928]                           T:UnityEngine.Debug
02cfd338: ldr     x0, [x8]                                   &2c5bbd4(=a9bd7bfdd503233f)
02cfd33c: ldr     w8, [x0, #0xe4]                            [62680e4]=0 f=0,0
02cfd340: cbnz    w8, #0x2cfd348                             
02cfd344: bl      #0x2b70f30                                 fn_2b70f30
02cfd348: mov     x0, x19                                    
02cfd34c: ldp     x20, x19, [sp, #0x10]                      
02cfd350: mov     x1, xzr                                    
02cfd354: ldp     x30, x21, [sp], #0x20                      
02cfd358: b       #0x5af2c94                                 UnityEngine.Debug::LogWarning
02cfd35c: adrp    x20, #0x6268000                            
02cfd360: ldr     x20, [x20, #0xcd8]                         T:RDG.Vibration
02cfd364: ldr     x0, [x20]                                  S:'{0}/2'
02cfd368: ldr     w8, [x0, #0xe4]                            [62680e4]=0 f=0,0
02cfd36c: cbnz    w8, #0x2cfd378                             
02cfd370: bl      #0x2b70f30                                 fn_2b70f30
02cfd374: ldr     x0, [x20]                                  S:'{0}/2'
02cfd378: ldr     x8, [x0, #0xb8]                            T:LuckyWheelPopup/<>c__DisplayClass54_0
02cfd37c: ldr     w8, [x8]                                   &2c5bbd4(=a9bd7bfdd503233f)
02cfd380: cmp     w8, #1                                     
02cfd384: b.lt    #0x2cfd3b4                                 
02cfd388: adrp    x8, #0x6263000                             
02cfd38c: ldr     x8, [x8, #0x928]                           T:UnityEngine.Debug
02cfd390: ldr     x0, [x8]                                   &2c5bbd4(=a9bd7bfdd503233f)
02cfd394: ldr     w8, [x0, #0xe4]                            [62680e4]=0 f=0,0
02cfd398: cbnz    w8, #0x2cfd3a0                             
02cfd39c: bl      #0x2b70f30                                 fn_2b70f30
02cfd3a0: mov     x0, x19                                    
02cfd3a4: ldp     x20, x19, [sp, #0x10]                      
02cfd3a8: mov     x1, xzr                                    
02cfd3ac: ldp     x30, x21, [sp], #0x20                      
02cfd3b0: b       #0x5af21f4                                 UnityEngine.Debug::Log
02cfd3b4: ldp     x20, x19, [sp, #0x10]                      
02cfd3b8: ldp     x30, x21, [sp], #0x20                      
02cfd3bc: ret                                                
## arrToStr(long[] array) -> string
---- RDG.Vibration::arrToStr 0x2cff404
02cff404: str     x30, [sp, #-0x20]!                         
02cff408: stp     x20, x19, [sp, #0x10]                      
02cff40c: adrp    x20, #0x662f000                            
02cff410: mov     x19, x0                                    
02cff414: ldrb    w8, [x20, #0xef4]                          
02cff418: tbnz    w8, #0, #0x2cff448                         
02cff41c: adrp    x0, #0x6268000                             
02cff420: ldr     x0, [x0, #0xdf0]                           MS:System.String::Join
02cff424: bl      #0x2b70db0                                 fn_2b70db0
02cff428: adrp    x0, #0x6263000                             
02cff42c: ldr     x0, [x0, #0x9b0]                           S:'null'
02cff430: bl      #0x2b70db0                                 fn_2b70db0
02cff434: adrp    x0, #0x6266000                             
02cff438: ldr     x0, [x0, #0x2f8]                           S:', '
02cff43c: bl      #0x2b70db0                                 fn_2b70db0
02cff440: mov     w8, #1                                     
02cff444: strb    w8, [x20, #0xef4]                          
02cff448: cbz     x19, #0x2cff474                            
02cff44c: adrp    x8, #0x6266000                             
02cff450: adrp    x9, #0x6268000                             
02cff454: mov     x1, x19                                    
02cff458: ldr     x8, [x8, #0x2f8]                           S:', '
02cff45c: ldr     x9, [x9, #0xdf0]                           MS:System.String::Join
02cff460: ldp     x20, x19, [sp, #0x10]                      
02cff464: ldr     x0, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cff468: ldr     x2, [x9]                                   S:'{0}/2'
02cff46c: ldr     x30, [sp], #0x20                           
02cff470: b       #0x3346e00                                 
02cff474: adrp    x8, #0x6263000                             
02cff478: ldr     x8, [x8, #0x9b0]                           S:'null'
02cff47c: ldp     x20, x19, [sp, #0x10]                      
02cff480: ldr     x0, [x8]                                   &2c5bbd4(=a9bd7bfdd503233f)
02cff484: ldr     x30, [sp], #0x20                           
02cff488: ret                                                
## arrToStr(int[] array) -> string
---- RDG.Vibration::arrToStr 0x2cff48c
02cff48c: str     x30, [sp, #-0x20]!                         
02cff490: stp     x20, x19, [sp, #0x10]                      
02cff494: adrp    x20, #0x662f000                            
02cff498: mov     x19, x0                                    
02cff49c: ldrb    w8, [x20, #0xef5]                          
02cff4a0: tbnz    w8, #0, #0x2cff4d0                         
02cff4a4: adrp    x0, #0x6268000                             
02cff4a8: ldr     x0, [x0, #0xdf8]                           MS:System.String::Join
02cff4ac: bl      #0x2b70db0                                 fn_2b70db0
02cff4b0: adrp    x0, #0x6263000                             
02cff4b4: ldr     x0, [x0, #0x9b0]                           S:'null'
02cff4b8: bl      #0x2b70db0                                 fn_2b70db0
02cff4bc: adrp    x0, #0x6266000                             
02cff4c0: ldr     x0, [x0, #0x2f8]                           S:', '
02cff4c4: bl      #0x2b70db0                                 fn_2b70db0
02cff4c8: mov     w8, #1                                     
02cff4cc: strb    w8, [x20, #0xef5]                          
02cff4d0: cbz     x19, #0x2cff4fc                            
02cff4d4: adrp    x8, #0x6266000                             
02cff4d8: adrp    x9, #0x6268000                             
02cff4dc: mov     x1, x19                                    
02cff4e0: ldr     x8, [x8, #0x2f8]                           S:', '
02cff4e4: ldr     x9, [x9, #0xdf8]                           MS:System.String::Join
02cff4e8: ldp     x20, x19, [sp, #0x10]                      
02cff4ec: ldr     x0, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cff4f0: ldr     x2, [x9]                                   S:'{0}/2'
02cff4f4: ldr     x30, [sp], #0x20                           
02cff4f8: b       #0x3346d28                                 
02cff4fc: adrp    x8, #0x6263000                             
02cff500: ldr     x8, [x8, #0x9b0]                           S:'null'
02cff504: ldp     x20, x19, [sp, #0x10]                      
02cff508: ldr     x0, [x8]                                   &2c5bbd4(=a9bd7bfdd503233f)
02cff50c: ldr     x30, [sp], #0x20                           
02cff510: ret                                                
## clampAmplitudesArray(int[] amplitudes) -> void
---- RDG.Vibration::clampAmplitudesArray 0x2cfe2b8
02cfe2b8: str     x30, [sp, #-0x10]!                         
02cfe2bc: cbz     x0, #0x2cfe310                             
02cfe2c0: ldr     x9, [x0, #0x18]                            .defaultAmplitude
02cfe2c4: cmp     w9, #1                                     
02cfe2c8: b.lt    #0x2cfe304                                 
02cfe2cc: bic     w8, w9, w9, asr #31                        
02cfe2d0: and     x9, x9, #0xffffffff                        
02cfe2d4: add     x10, x0, #0x20                             
02cfe2d8: mov     w11, #0xff                                 
02cfe2dc: cbz     x9, #0x2cfe30c                             
02cfe2e0: ldr     w12, [x10]                                 
02cfe2e4: sub     x8, x8, #1                                 
02cfe2e8: sub     x9, x9, #1                                 
02cfe2ec: cmp     w12, #0xff                                 
02cfe2f0: csel    w12, w12, w11, lt                          
02cfe2f4: cmp     w12, #1                                    
02cfe2f8: csinc   w12, w12, wzr, gt                          
02cfe2fc: str     w12, [x10], #4                             
02cfe300: cbnz    x8, #0x2cfe2dc                             
02cfe304: ldr     x30, [sp], #0x10                           
02cfe308: ret                                                
02cfe30c: bl      #0x2b71064                                 fn_2b71064
02cfe310: bl      #0x2b7105c                                 fn_2b7105c
## .cctor() -> void
---- RDG.Vibration::.cctor 0x2cff514
02cff514: str     x30, [sp, #-0x20]!                         
02cff518: stp     x20, x19, [sp, #0x10]                      
02cff51c: adrp    x20, #0x662f000                            
02cff520: adrp    x19, #0x6268000                            
02cff524: ldrb    w8, [x20, #0xef6]                          
02cff528: ldr     x19, [x19, #0xcd8]                         T:RDG.Vibration
02cff52c: tbnz    w8, #0, #0x2cff544                         
02cff530: adrp    x0, #0x6268000                             
02cff534: ldr     x0, [x0, #0xcd8]                           T:RDG.Vibration
02cff538: bl      #0x2b70db0                                 fn_2b70db0
02cff53c: mov     w8, #1                                     
02cff540: strb    w8, [x20, #0xef6]                          
02cff544: ldr     x8, [x19]                                  S:'{0}/2'
02cff548: mov     x1, xzr                                    
02cff54c: ldr     x0, [x8, #0xb8]                            
02cff550: str     wzr, [x0]                                  
02cff554: str     xzr, [x0, #8]!                             
02cff558: bl      #0x2b70d54                                 fn_2b70d54
02cff55c: ldr     x8, [x19]                                  S:'{0}/2'
02cff560: mov     x1, xzr                                    
02cff564: ldr     x0, [x8, #0xb8]                            
02cff568: str     xzr, [x0, #0x10]!                          .vibrationEffectClass
02cff56c: bl      #0x2b70d54                                 fn_2b70d54
02cff570: ldr     x8, [x19]                                  S:'{0}/2'
02cff574: adrp    x9, #0x1041000                             
02cff578: ldr     d0, [x9, #0x2d0]                           [10412d0]=1000000ff f=3.57331e-43,1.4013e-45
02cff57c: ldp     x20, x19, [sp, #0x10]                      
02cff580: ldr     x8, [x8, #0xb8]                            
02cff584: str     d0, [x8, #0x18]                            
02cff588: strb    wzr, [x8, #0x20]                           
02cff58c: ldr     x30, [sp], #0x20                           
02cff590: ret                                                
## <Vibrate>g__funcToStr|9_0(RDG.Vibration/<>c__DisplayClass9_0 ) -> string
---- RDG.Vibration::<Vibrate>g__funcToStr|9_0 0x2cfd634
02cfd634: sub     sp, sp, #0x40                              
02cfd638: stp     x30, x23, [sp, #0x10]                      
02cfd63c: stp     x22, x21, [sp, #0x20]                      
02cfd640: stp     x20, x19, [sp, #0x30]                      
02cfd644: adrp    x20, #0x662f000                            
02cfd648: adrp    x22, #0x6268000                            
02cfd64c: mov     x19, x0                                    
02cfd650: ldrb    w8, [x20, #0xef7]                          
02cfd654: ldr     x22, [x22, #0xd68]                         S:'Vibrate ({0}, {1}, {2})'
02cfd658: tbnz    w8, #0, #0x2cfd670                         
02cfd65c: adrp    x0, #0x6268000                             
02cfd660: ldr     x0, [x0, #0xd68]                           S:'Vibrate ({0}, {1}, {2})'
02cfd664: bl      #0x2b70db0                                 fn_2b70db0
02cfd668: mov     w8, #1                                     
02cfd66c: strb    w8, [x20, #0xef7]                          
02cfd670: adrp    x23, #0x6263000                            
02cfd674: add     x1, sp, #8                                 
02cfd678: ldr     x23, [x23, #0x970]                         &6645c70(=0)
02cfd67c: ldr     x8, [x19]                                  
02cfd680: ldr     x0, [x23, #0x68]                           &2c497cc(=d65f03c0d503245f)
02cfd684: str     x8, [sp, #8]                               
02cfd688: bl      #0x2b70f38                                 fn_2b70f38
02cfd68c: mov     x20, x0                                    
02cfd690: ldr     w8, [x19, #8]                              
02cfd694: ldr     x0, [x23, #0x48]                           &6263098(=0)
02cfd698: add     x1, sp, #4                                 
02cfd69c: str     w8, [sp, #4]                               
02cfd6a0: bl      #0x2b70f38                                 fn_2b70f38
02cfd6a4: mov     x21, x0                                    
02cfd6a8: ldrb    w8, [x19, #0xc]                            
02cfd6ac: ldr     x0, [x23, #0x28]                           [6263028]=0 f=0,0
02cfd6b0: mov     x1, sp                                     
02cfd6b4: strb    w8, [sp]                                   
02cfd6b8: bl      #0x2b70f38                                 fn_2b70f38
02cfd6bc: ldr     x8, [x22]                                  S:'{0}/2'
02cfd6c0: mov     x3, x0                                     
02cfd6c4: mov     x1, x20                                    
02cfd6c8: mov     x2, x21                                    
02cfd6cc: mov     x4, xzr                                    
02cfd6d0: mov     x0, x8                                     
02cfd6d4: bl      #0x4ca7764                                 System.String::Format
02cfd6d8: ldp     x20, x19, [sp, #0x30]                      
02cfd6dc: ldp     x22, x21, [sp, #0x20]                      
02cfd6e0: ldp     x30, x23, [sp, #0x10]                      
02cfd6e4: add     sp, sp, #0x40                              
02cfd6e8: ret                                                
## <Vibrate>g__funcToStr|10_0(RDG.Vibration/<>c__DisplayClass10_0 ) -> string
---- RDG.Vibration::<Vibrate>g__funcToStr|10_0 0x2cfe0dc
02cfe0dc: str     x30, [sp, #-0x30]!                         
02cfe0e0: stp     x22, x21, [sp, #0x10]                      
02cfe0e4: stp     x20, x19, [sp, #0x20]                      
02cfe0e8: adrp    x21, #0x662f000                            
02cfe0ec: adrp    x22, #0x6263000                            
02cfe0f0: adrp    x19, #0x6268000                            
02cfe0f4: ldrb    w8, [x21, #0xef8]                          
02cfe0f8: ldr     x22, [x22, #0xa80]                         T:type24502(k1d)
02cfe0fc: ldr     x19, [x19, #0xcd8]                         T:RDG.Vibration
02cfe100: mov     x20, x0                                    
02cfe104: tbnz    w8, #0, #0x2cfe134                         
02cfe108: adrp    x0, #0x6263000                             
02cfe10c: ldr     x0, [x0, #0xa80]                           T:type24502(k1d)
02cfe110: bl      #0x2b70db0                                 fn_2b70db0
02cfe114: adrp    x0, #0x6268000                             
02cfe118: ldr     x0, [x0, #0xcd8]                           T:RDG.Vibration
02cfe11c: bl      #0x2b70db0                                 fn_2b70db0
02cfe120: adrp    x0, #0x6268000                             
02cfe124: ldr     x0, [x0, #0xdb0]                           S:'Vibrate (({0}), ({1}), {2}, {3})'
02cfe128: bl      #0x2b70db0                                 fn_2b70db0
02cfe12c: mov     w8, #1                                     
02cfe130: strb    w8, [x21, #0xef8]                          
02cfe134: ldr     x0, [x22]                                  &2c5bbd4(=a9bd7bfdd503233f)
02cfe138: mov     w1, #4                                     
02cfe13c: bl      #0x2b70ea0                                 fn_2b70ea0
02cfe140: ldr     x8, [x19]                                  S:'{0}/2'
02cfe144: ldr     x21, [x20]                                 
02cfe148: mov     x19, x0                                    
02cfe14c: ldr     w9, [x8, #0xe4]                            
02cfe150: cbnz    w9, #0x2cfe15c                             
02cfe154: mov     x0, x8                                     
02cfe158: bl      #0x2b70f30                                 fn_2b70f30
02cfe15c: mov     x0, x21                                    
02cfe160: bl      #0x2cff404                                 RDG.Vibration::arrToStr
02cfe164: cbz     x19, #0x2cfe2b4                            
02cfe168: mov     x21, x0                                    
02cfe16c: cbz     x0, #0x2cfe184                             
02cfe170: ldr     x8, [x19]                                  S:'{0}/2'
02cfe174: mov     x0, x21                                    
02cfe178: ldr     x1, [x8, #0x40]                            
02cfe17c: bl      #0x2b70f34                                 fn_2b70f34
02cfe180: cbz     x0, #0x2cfe2a8                             
02cfe184: ldr     w8, [x19, #0x18]                           M:LuckyWheelPopup/<>c__DisplayClass50_0::<RunAnimation>b__0 .defaultAmplitude
02cfe188: cbz     w8, #0x2cfe2a4                             
02cfe18c: mov     x0, x19                                    
02cfe190: mov     x1, x21                                    
02cfe194: str     x21, [x0, #0x20]!                          .isInitialized
02cfe198: bl      #0x2b70d54                                 fn_2b70d54
02cfe19c: ldr     x0, [x20, #8]                              
02cfe1a0: bl      #0x2cff48c                                 RDG.Vibration::arrToStr
02cfe1a4: mov     x21, x0                                    
02cfe1a8: cbz     x0, #0x2cfe1c0                             
02cfe1ac: ldr     x8, [x19]                                  S:'{0}/2'
02cfe1b0: mov     x0, x21                                    
02cfe1b4: ldr     x1, [x8, #0x40]                            
02cfe1b8: bl      #0x2b70f34                                 fn_2b70f34
02cfe1bc: cbz     x0, #0x2cfe2a8                             
02cfe1c0: ldr     w8, [x19, #0x18]                           M:LuckyWheelPopup/<>c__DisplayClass50_0::<RunAnimation>b__0 .defaultAmplitude
02cfe1c4: tst     w8, #0xfffffffe                            
02cfe1c8: b.eq    #0x2cfe2a4                                 
02cfe1cc: mov     x0, x19                                    
02cfe1d0: mov     x1, x21                                    
02cfe1d4: str     x21, [x0, #0x28]!                          
02cfe1d8: bl      #0x2b70d54                                 fn_2b70d54
02cfe1dc: adrp    x22, #0x6263000                            
02cfe1e0: add     x1, sp, #0xc                               
02cfe1e4: ldr     x22, [x22, #0x970]                         &6645c70(=0)
02cfe1e8: ldr     w8, [x20, #0x10]                           .vibrationEffectClass
02cfe1ec: ldr     x0, [x22, #0x48]                           &6263098(=0)
02cfe1f0: str     w8, [sp, #0xc]                             
02cfe1f4: bl      #0x2b70f38                                 fn_2b70f38
02cfe1f8: mov     x21, x0                                    
02cfe1fc: cbz     x0, #0x2cfe214                             
02cfe200: ldr     x8, [x19]                                  S:'{0}/2'
02cfe204: mov     x0, x21                                    
02cfe208: ldr     x1, [x8, #0x40]                            
02cfe20c: bl      #0x2b70f34                                 fn_2b70f34
02cfe210: cbz     x0, #0x2cfe2a8                             
02cfe214: ldr     w8, [x19, #0x18]                           M:LuckyWheelPopup/<>c__DisplayClass50_0::<RunAnimation>b__0 .defaultAmplitude
02cfe218: cmp     w8, #2                                     
02cfe21c: b.ls    #0x2cfe2a4                                 
02cfe220: mov     x0, x19                                    
02cfe224: mov     x1, x21                                    
02cfe228: str     x21, [x0, #0x30]!                          
02cfe22c: bl      #0x2b70d54                                 fn_2b70d54
02cfe230: ldrb    w8, [x20, #0x14]                           
02cfe234: ldr     x0, [x22, #0x28]                           [6263028]=0 f=0,0
02cfe238: add     x1, sp, #8                                 
02cfe23c: strb    w8, [sp, #8]                               
02cfe240: bl      #0x2b70f38                                 fn_2b70f38
02cfe244: mov     x20, x0                                    
02cfe248: cbz     x0, #0x2cfe260                             
02cfe24c: ldr     x8, [x19]                                  S:'{0}/2'
02cfe250: mov     x0, x20                                    
02cfe254: ldr     x1, [x8, #0x40]                            
02cfe258: bl      #0x2b70f34                                 fn_2b70f34
02cfe25c: cbz     x0, #0x2cfe2a8                             
02cfe260: ldr     w8, [x19, #0x18]                           M:LuckyWheelPopup/<>c__DisplayClass50_0::<RunAnimation>b__0 .defaultAmplitude
02cfe264: tst     w8, #0xfffffffc                            
02cfe268: b.eq    #0x2cfe2a4                                 
02cfe26c: adrp    x21, #0x6268000                            
02cfe270: mov     x0, x19                                    
02cfe274: mov     x1, x20                                    
02cfe278: ldr     x21, [x21, #0xdb0]                         S:'Vibrate (({0}), ({1}), {2}, {3})'
02cfe27c: str     x20, [x0, #0x38]!                          
02cfe280: bl      #0x2b70d54                                 fn_2b70d54
02cfe284: ldr     x0, [x21]                                  S:'{0}/2'
02cfe288: mov     x1, x19                                    
02cfe28c: mov     x2, xzr                                    
02cfe290: bl      #0x4ca77a8                                 System.String::Format
02cfe294: ldp     x20, x19, [sp, #0x20]                      
02cfe298: ldp     x22, x21, [sp, #0x10]                      
02cfe29c: ldr     x30, [sp], #0x30                           
02cfe2a0: ret                                                
02cfe2a4: bl      #0x2b71064                                 fn_2b71064
02cfe2a8: bl      #0x2b71080                                 fn_2b71080
02cfe2ac: mov     x1, xzr                                    
02cfe2b0: bl      #0x2b70f20                                 fn_2b70f20
02cfe2b4: bl      #0x2b7105c                                 fn_2b7105c
## <VibratePredefined>g__funcToStr|11_0(RDG.Vibration/<>c__DisplayClass11_0 ) -> string
---- RDG.Vibration::<VibratePredefined>g__funcToStr|11_0 0x2cfe9fc
02cfe9fc: sub     sp, sp, #0x30                              
02cfea00: stp     x30, x21, [sp, #0x10]                      
02cfea04: stp     x20, x19, [sp, #0x20]                      
02cfea08: adrp    x21, #0x662f000                            
02cfea0c: adrp    x20, #0x6268000                            
02cfea10: mov     x19, x0                                    
02cfea14: ldrb    w8, [x21, #0xef9]                          
02cfea18: ldr     x20, [x20, #0xdc8]                         S:'VibratePredefined ({0})'
02cfea1c: tbnz    w8, #0, #0x2cfea34                         
02cfea20: adrp    x0, #0x6268000                             
02cfea24: ldr     x0, [x0, #0xdc8]                           S:'VibratePredefined ({0})'
02cfea28: bl      #0x2b70db0                                 fn_2b70db0
02cfea2c: mov     w8, #1                                     
02cfea30: strb    w8, [x21, #0xef9]                          
02cfea34: adrp    x8, #0x6263000                             
02cfea38: add     x1, sp, #0xc                               
02cfea3c: ldr     x8, [x8, #0x970]                           &6645c70(=0)
02cfea40: ldr     w9, [x19]                                  
02cfea44: ldr     x0, [x8, #0x48]                            &6263098(=0)
02cfea48: str     w9, [sp, #0xc]                             
02cfea4c: bl      #0x2b70f38                                 fn_2b70f38
02cfea50: ldr     x8, [x20]                                  S:'{0}/2'
02cfea54: mov     x1, x0                                     
02cfea58: mov     x2, xzr                                    
02cfea5c: mov     x0, x8                                     
02cfea60: bl      #0x4c9d0ec                                 System.String::Format
02cfea64: ldp     x20, x19, [sp, #0x20]                      
02cfea68: ldp     x30, x21, [sp, #0x10]                      
02cfea6c: add     sp, sp, #0x30                              
02cfea70: ret                                                
