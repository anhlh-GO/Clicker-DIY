#### CLASS LoginTimeReward.LoginTimeRewardPopup/<>c parent= object
#   field <>9                            LoginTimeReward.LoginTimeRewardPopup/<>c           off=0x0 attr=36 
#   field <>9__19_0                      System.Action`1<DailyLoginRewardUIItem>            off=0x8 attr=16 
#   field <>9__20_0                      System.Action`1<DailyLoginRewardUIItem>            off=0x10 attr=16 
#   field <>9__22_0                      System.Action`1<DailyLoginRewardUIItem>            off=0x18 attr=16 
## .cctor() -> void
---- LoginTimeReward.LoginTimeRewardPopup/<>c::.cctor 0x2d5afd8
02d5afd8: str     x30, [sp, #-0x20]!                         
02d5afdc: stp     x20, x19, [sp, #0x10]                      
02d5afe0: adrp    x19, #0x6630000                            
02d5afe4: adrp    x20, #0x626b000                            
02d5afe8: ldrb    w8, [x19, #0x2b9]                          
02d5afec: ldr     x20, [x20, #0xb48]                         T:LoginTimeReward.LoginTimeRewardPopup/<>c
02d5aff0: tbnz    w8, #0, #0x2d5b008                         
02d5aff4: adrp    x0, #0x626b000                             
02d5aff8: ldr     x0, [x0, #0xb48]                           T:LoginTimeReward.LoginTimeRewardPopup/<>c
02d5affc: bl      #0x2b70db0                                 fn_2b70db0
02d5b000: mov     w8, #1                                     
02d5b004: strb    w8, [x19, #0x2b9]                          
02d5b008: ldr     x0, [x20]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d5b00c: bl      #0x2b7104c                                 fn_2b7104c
02d5b010: mov     x1, xzr                                    
02d5b014: mov     x19, x0                                    
02d5b018: bl      #0x4e53e9c                                 System.Object::.ctor
02d5b01c: ldr     x8, [x20]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d5b020: mov     x1, x19                                    
02d5b024: ldr     x8, [x8, #0xb8]                            
02d5b028: str     x19, [x8]                                  
02d5b02c: ldr     x8, [x20]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d5b030: ldp     x20, x19, [sp, #0x10]                      
02d5b034: ldr     x0, [x8, #0xb8]                            
02d5b038: ldr     x30, [sp], #0x20                           
02d5b03c: b       #0x2b70d54                                 
## .ctor() -> void
---- LoginTimeReward.LoginTimeRewardPopup/<>c::.ctor 0x2d5b040
02d5b040: mov     x1, xzr                                    
02d5b044: b       #0x4e53e9c                                 System.Object::.ctor
## <LoadRewardData>b__19_0(DailyLoginRewardUIItem x) -> void
---- LoginTimeReward.LoginTimeRewardPopup/<>c::<LoadRewardData>b__19_0 0x2d5b048
02d5b048: cbz     x1, #0x2d5b058                             
02d5b04c: mov     x0, x1                                     
02d5b050: mov     x1, xzr                                    
02d5b054: b       #0x2cb76dc                                 DailyLoginRewardUIItem::UpdateProcess
02d5b058: str     x30, [sp, #-0x10]!                         
02d5b05c: bl      #0x2b7105c                                 fn_2b7105c
## <OnHide>b__20_0(DailyLoginRewardUIItem x) -> void
---- LoginTimeReward.LoginTimeRewardPopup/<>c::<OnHide>b__20_0 0x2d5b060
02d5b060: cbz     x1, #0x2d5b070                             
02d5b064: mov     x0, x1                                     
02d5b068: mov     x1, xzr                                    
02d5b06c: b       #0x2cb7e54                                 DailyLoginRewardUIItem::HideVisual
02d5b070: str     x30, [sp, #-0x10]!                         
02d5b074: bl      #0x2b7105c                                 fn_2b7105c
## <ClaimReward>b__22_0(DailyLoginRewardUIItem x) -> void
---- LoginTimeReward.LoginTimeRewardPopup/<>c::<ClaimReward>b__22_0 0x2d5b078
02d5b078: cbz     x1, #0x2d5b088                             
02d5b07c: mov     x0, x1                                     
02d5b080: mov     x1, xzr                                    
02d5b084: b       #0x2cb76dc                                 DailyLoginRewardUIItem::UpdateProcess
02d5b088: str     x30, [sp, #-0x10]!                         
02d5b08c: bl      #0x2b7105c                                 fn_2b7105c
#### CLASS LoginTimeReward.LoginTimeRewardPopup parent= PopupBase
#   field _closeButton                   UnityEngine.UI.Button                              off=0x38 attr=1 SerializeField
#   field _closeButton2                  UnityEngine.UI.Button                              off=0x40 attr=1 SerializeField
#   field _dailyLoginRewardUIItem        DailyLoginRewardUIItem                             off=0x48 attr=1 SerializeField
#   field _rewardUIItemList              System.Collections.Generic.List`1<DailyLoginRewardUIItem> off=0x50 attr=1 SerializeField
#   field _itemHolder                    UnityEngine.Transform                              off=0x58 attr=1 SerializeField
#   field _goNoti                        UnityEngine.GameObject                             off=0x60 attr=1 SerializeField
#   field _goTimerBG                     UnityEngine.GameObject                             off=0x68 attr=1 SerializeField
#   field _goTimer                       UnityEngine.GameObject                             off=0x70 attr=1 SerializeField
#   field _txtTimer                      TMPro.TextMeshProUGUI                              off=0x78 attr=1 SerializeField
#   field _loginTimeRewardConfig         LoginTimeReward.LoginTimeRewardConfig              off=0x80 attr=1 SerializeField
#   field _decorKeycapConfig             Clicker.DecorKeycapConfig                          off=0x88 attr=1 SerializeField
#   field _tfPanel                       UnityEngine.Transform                              off=0x90 attr=1 SerializeField
#   field _header                        UnityEngine.RectTransform                          off=0x98 attr=1 SerializeField
#   field _cachedAnchor                  UnityEngine.Vector2                                off=0xa0 attr=1 
#   field _rectMoneyManager              UnityEngine.RectTransform                          off=0xa8 attr=1 
#   field _nextTimer                     float                                              off=0xb0 attr=1 
## OnInit(UIManager uiManager) -> void
---- LoginTimeReward.LoginTimeRewardPopup::OnInit 0x2d59770
02d59770: stp     x30, x23, [sp, #-0x30]!                    
02d59774: stp     x22, x21, [sp, #0x10]                      
02d59778: stp     x20, x19, [sp, #0x20]                      
02d5977c: adrp    x21, #0x6630000                            
02d59780: mov     x20, x1                                    
02d59784: mov     x19, x0                                    
02d59788: ldrb    w8, [x21, #0x2af]                          
02d5978c: tbnz    w8, #0, #0x2d597b0                         
02d59790: adrp    x0, #0x626b000                             
02d59794: ldr     x0, [x0, #0xb18]                           M:LoginTimeReward.LoginTimeRewardPopup::OnBtnCloseClick
02d59798: bl      #0x2b70db0                                 fn_2b70db0
02d5979c: adrp    x0, #0x6265000                             
02d597a0: ldr     x0, [x0, #0x3f0]                           T:UnityEngine.Events.UnityAction
02d597a4: bl      #0x2b70db0                                 fn_2b70db0
02d597a8: mov     w8, #1                                     
02d597ac: strb    w8, [x21, #0x2af]                          
02d597b0: mov     x0, x19                                    
02d597b4: mov     x1, x20                                    
02d597b8: mov     x2, xzr                                    
02d597bc: bl      #0x2cdd3c4                                 UIBase::OnInit
02d597c0: ldr     x0, [x19, #0x48]                           ._dailyLoginRewardUIItem
02d597c4: cbz     x0, #0x2d5989c                             
02d597c8: mov     x1, xzr                                    
02d597cc: bl      #0x5b339ec                                 UnityEngine.Component::get_gameObject
02d597d0: cbz     x0, #0x2d5989c                             
02d597d4: mov     x1, xzr                                    
02d597d8: bl      #0x5b36bfc                                 UnityEngine.GameObject::get_activeSelf
02d597dc: tbz     w0, #0, #0x2d59800                         
02d597e0: ldr     x0, [x19, #0x48]                           ._dailyLoginRewardUIItem
02d597e4: cbz     x0, #0x2d5989c                             
02d597e8: mov     x1, xzr                                    
02d597ec: bl      #0x5b339ec                                 UnityEngine.Component::get_gameObject
02d597f0: cbz     x0, #0x2d5989c                             
02d597f4: mov     w1, wzr                                    
02d597f8: mov     x2, xzr                                    
02d597fc: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d59800: ldr     x8, [x19, #0x38]                           ._closeButton
02d59804: cbz     x8, #0x2d5989c                             
02d59808: adrp    x23, #0x6265000                            
02d5980c: adrp    x22, #0x626b000                            
02d59810: ldr     x23, [x23, #0x3f0]                         T:UnityEngine.Events.UnityAction
02d59814: ldr     x22, [x22, #0xb18]                         M:LoginTimeReward.LoginTimeRewardPopup::OnBtnCloseClick
02d59818: ldr     x20, [x8, #0x100]                          
02d5981c: ldr     x0, [x23]                                  M:AdsManager::<OnApplicationPause>b__26_0
02d59820: bl      #0x2b7104c                                 fn_2b7104c
02d59824: ldr     x2, [x22]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d59828: mov     x1, x19                                    
02d5982c: mov     x3, xzr                                    
02d59830: mov     x21, x0                                    
02d59834: bl      #0x5b4cf98                                 UnityEngine.Events.UnityAction::.ctor
02d59838: cbz     x20, #0x2d5989c                            
02d5983c: mov     x0, x20                                    
02d59840: mov     x1, x21                                    
02d59844: mov     x2, xzr                                    
02d59848: bl      #0x5b4d0ac                                 UnityEngine.Events.UnityEvent::AddListener
02d5984c: ldr     x8, [x19, #0x40]                           ._closeButton2
02d59850: cbz     x8, #0x2d5989c                             
02d59854: ldr     x0, [x23]                                  M:AdsManager::<OnApplicationPause>b__26_0
02d59858: ldr     x20, [x8, #0x100]                          
02d5985c: bl      #0x2b7104c                                 fn_2b7104c
02d59860: ldr     x2, [x22]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d59864: mov     x1, x19                                    
02d59868: mov     x3, xzr                                    
02d5986c: mov     x21, x0                                    
02d59870: bl      #0x5b4cf98                                 UnityEngine.Events.UnityAction::.ctor
02d59874: cbz     x20, #0x2d5989c                            
02d59878: mov     x0, x20                                    
02d5987c: mov     x1, x21                                    
02d59880: mov     x2, xzr                                    
02d59884: bl      #0x5b4d0ac                                 UnityEngine.Events.UnityEvent::AddListener
02d59888: mov     x0, x19                                    
02d5988c: ldp     x20, x19, [sp, #0x20]                      
02d59890: ldp     x22, x21, [sp, #0x10]                      
02d59894: ldp     x30, x23, [sp], #0x30                      
02d59898: b       #0x2d598a0                                 LoginTimeReward.LoginTimeRewardPopup::SpawnUIItem
02d5989c: bl      #0x2b7105c                                 fn_2b7105c
## SpawnUIItem() -> void
---- LoginTimeReward.LoginTimeRewardPopup::SpawnUIItem 0x2d598a0
02d598a0: stp     x30, x27, [sp, #-0x50]!                    
02d598a4: stp     x26, x25, [sp, #0x10]                      
02d598a8: stp     x24, x23, [sp, #0x20]                      
02d598ac: stp     x22, x21, [sp, #0x30]                      
02d598b0: stp     x20, x19, [sp, #0x40]                      
02d598b4: adrp    x20, #0x6630000                            
02d598b8: mov     x19, x0                                    
02d598bc: ldrb    w8, [x20, #0x2b0]                          
02d598c0: tbnz    w8, #0, #0x2d59920                         
02d598c4: adrp    x0, #0x626b000                             
02d598c8: ldr     x0, [x0, #0xb20]                           MS:System.Collections.Generic.List`1::Add
02d598cc: bl      #0x2b70db0                                 fn_2b70db0
02d598d0: adrp    x0, #0x626b000                             
02d598d4: ldr     x0, [x0, #0xb28]                           MS:System.Collections.Generic.List`1::get_Count
02d598d8: bl      #0x2b70db0                                 fn_2b70db0
02d598dc: adrp    x0, #0x6266000                             
02d598e0: ldr     x0, [x0, #0x8d8]                           MS:System.Collections.Generic.List`1::get_Count
02d598e4: bl      #0x2b70db0                                 fn_2b70db0
02d598e8: adrp    x0, #0x626b000                             
02d598ec: ldr     x0, [x0, #0xb30]                           MS:System.Collections.Generic.List`1::get_Item
02d598f0: bl      #0x2b70db0                                 fn_2b70db0
02d598f4: adrp    x0, #0x626b000                             
02d598f8: ldr     x0, [x0, #0xb38]                           MS:System.Collections.Generic.List`1::get_Item
02d598fc: bl      #0x2b70db0                                 fn_2b70db0
02d59900: adrp    x0, #0x626b000                             
02d59904: ldr     x0, [x0, #0xb40]                           MS:UnityEngine.Object::Instantiate
02d59908: bl      #0x2b70db0                                 fn_2b70db0
02d5990c: adrp    x0, #0x6263000                             
02d59910: ldr     x0, [x0, #0x918]                           T:UnityEngine.Object
02d59914: bl      #0x2b70db0                                 fn_2b70db0
02d59918: mov     w8, #1                                     
02d5991c: strb    w8, [x20, #0x2b0]                          
02d59920: ldr     x8, [x19, #0x80]                           ._loginTimeRewardConfig
02d59924: cbz     x8, #0x2d59a9c                             
02d59928: ldr     x0, [x19, #0x50]                           ._rewardUIItemList
02d5992c: cbz     x0, #0x2d59a9c                             
02d59930: ldr     x20, [x8, #0x18]                           
02d59934: cbz     x20, #0x2d59a9c                            
02d59938: adrp    x23, #0x626b000                            
02d5993c: adrp    x24, #0x626b000                            
02d59940: adrp    x25, #0x6263000                            
02d59944: adrp    x26, #0x626b000                            
02d59948: adrp    x27, #0x626b000                            
02d5994c: ldr     x23, [x23, #0xb38]                         MS:System.Collections.Generic.List`1::get_Item
02d59950: ldr     x24, [x24, #0xb30]                         MS:System.Collections.Generic.List`1::get_Item
02d59954: ldr     x25, [x25, #0x918]                         T:UnityEngine.Object
02d59958: ldr     x26, [x26, #0xb40]                         MS:UnityEngine.Object::Instantiate
02d5995c: ldr     x27, [x27, #0xb20]                         MS:System.Collections.Generic.List`1::Add
02d59960: ldr     w8, [x0, #0x18]                            &2c5d934(=d65f03c0d503245f)
02d59964: ldr     w9, [x20, #0x18]                           
02d59968: cmp     w8, w9                                     
02d5996c: b.ge    #0x2d59a28                                 
02d59970: ldr     x0, [x25]                                  &2c5bbd4(=a9bd7bfdd503233f)
02d59974: ldr     x21, [x19, #0x48]                          ._dailyLoginRewardUIItem
02d59978: ldr     x22, [x19, #0x58]                          ._itemHolder
02d5997c: ldr     w8, [x0, #0xe4]                            [62630e4]=0 f=0,0
02d59980: cbnz    w8, #0x2d59988                             
02d59984: bl      #0x2b70f30                                 fn_2b70f30
02d59988: ldr     x2, [x26]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d5998c: mov     x0, x21                                    
02d59990: mov     x1, x22                                    
02d59994: bl      #0x3275fcc                                 fn_3275fcc
02d59998: cbz     x0, #0x2d59a9c                             
02d5999c: mov     x1, xzr                                    
02d599a0: mov     x21, x0                                    
02d599a4: bl      #0x5b339ec                                 UnityEngine.Component::get_gameObject
02d599a8: cbz     x0, #0x2d59a9c                             
02d599ac: mov     w1, #1                                     
02d599b0: mov     x2, xzr                                    
02d599b4: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d599b8: ldr     x0, [x19, #0x50]                           ._rewardUIItemList
02d599bc: cbz     x0, #0x2d59a9c                             
02d599c0: ldr     w10, [x0, #0x1c]                           [626301c]=0 f=0,0
02d599c4: ldr     x8, [x0, #0x10]                            &2c498bc(=aa1f03e0d503245f)
02d599c8: ldr     x9, [x27]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d599cc: add     w10, w10, #1                               
02d599d0: str     w10, [x0, #0x1c]                           
02d599d4: cbz     x8, #0x2d59a9c                             
02d599d8: ldrsw   x10, [x0, #0x18]                           
02d599dc: ldr     w11, [x8, #0x18]                           
02d599e0: cmp     w10, w11                                   
02d599e4: b.hs    #0x2d59a08                                 
02d599e8: add     x8, x8, x10, lsl #3                        
02d599ec: add     w9, w10, #1                                
02d599f0: mov     x1, x21                                    
02d599f4: str     w9, [x0, #0x18]                            
02d599f8: str     x21, [x8, #0x20]!                          
02d599fc: mov     x0, x8                                     
02d59a00: bl      #0x2b70d54                                 fn_2b70d54
02d59a04: b       #0x2d59a1c                                 
02d59a08: ldr     x8, [x9, #0x20]                            
02d59a0c: mov     x1, x21                                    
02d59a10: ldr     x8, [x8, #0xc0]                            
02d59a14: ldr     x2, [x8, #0x70]                            
02d59a18: bl      #0x35a920c                                 fn_35a920c
02d59a1c: ldr     x0, [x19, #0x50]                           ._rewardUIItemList
02d59a20: cbnz    x0, #0x2d59960                             
02d59a24: b       #0x2d59a9c                                 
02d59a28: mov     w21, wzr                                   
02d59a2c: ldr     w8, [x0, #0x18]                            &2c5d934(=d65f03c0d503245f)
02d59a30: cmp     w21, w8                                    
02d59a34: b.ge    #0x2d59aa0                                 
02d59a38: ldr     x2, [x23]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d59a3c: mov     w1, w21                                    
02d59a40: bl      #0x35a8f3c                                 fn_35a8f3c
02d59a44: cbz     x0, #0x2d59a9c                             
02d59a48: mov     x1, x19                                    
02d59a4c: mov     x2, xzr                                    
02d59a50: bl      #0x2cb7324                                 DailyLoginRewardUIItem::Init
02d59a54: ldr     x0, [x19, #0x50]                           ._rewardUIItemList
02d59a58: cbz     x0, #0x2d59a9c                             
02d59a5c: ldr     x2, [x23]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d59a60: mov     w1, w21                                    
02d59a64: bl      #0x35a8f3c                                 fn_35a8f3c
02d59a68: ldr     x2, [x24]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d59a6c: mov     x22, x0                                    
02d59a70: mov     x0, x20                                    
02d59a74: mov     w1, w21                                    
02d59a78: bl      #0x35a8f3c                                 fn_35a8f3c
02d59a7c: cbz     x22, #0x2d59a9c                            
02d59a80: mov     x1, x0                                     
02d59a84: mov     x0, x22                                    
02d59a88: mov     x2, xzr                                    
02d59a8c: bl      #0x2cb744c                                 DailyLoginRewardUIItem::SetData
02d59a90: ldr     x0, [x19, #0x50]                           ._rewardUIItemList
02d59a94: add     w21, w21, #1                               
02d59a98: cbnz    x0, #0x2d59a2c                             
02d59a9c: bl      #0x2b7105c                                 fn_2b7105c
02d59aa0: ldp     x20, x19, [sp, #0x40]                      
02d59aa4: ldp     x22, x21, [sp, #0x30]                      
02d59aa8: ldp     x24, x23, [sp, #0x20]                      
02d59aac: ldp     x26, x25, [sp, #0x10]                      
02d59ab0: ldp     x30, x27, [sp], #0x50                      
02d59ab4: ret                                                
## OnShow() -> void
---- LoginTimeReward.LoginTimeRewardPopup::OnShow 0x2d59ab8
02d59ab8: stp     d9, d8, [sp, #-0x40]!                      
02d59abc: stp     x30, x23, [sp, #0x10]                      
02d59ac0: stp     x22, x21, [sp, #0x20]                      
02d59ac4: stp     x20, x19, [sp, #0x30]                      
02d59ac8: adrp    x20, #0x6630000                            
02d59acc: adrp    x21, #0x6266000                            
02d59ad0: mov     x19, x0                                    
02d59ad4: ldrb    w8, [x20, #0x2b1]                          
02d59ad8: ldr     x21, [x21, #0xaa0]                         MS:MonoSingleton`1::get_Instance
02d59adc: tbnz    w8, #0, #0x2d59b24                         
02d59ae0: adrp    x0, #0x6264000                             
02d59ae4: ldr     x0, [x0, #0xd88]                           MS:UnityEngine.Component::GetComponent
02d59ae8: bl      #0x2b70db0                                 fn_2b70db0
02d59aec: adrp    x0, #0x626b000                             
02d59af0: ldr     x0, [x0, #0xb28]                           MS:System.Collections.Generic.List`1::get_Count
02d59af4: bl      #0x2b70db0                                 fn_2b70db0
02d59af8: adrp    x0, #0x626b000                             
02d59afc: ldr     x0, [x0, #0xb38]                           MS:System.Collections.Generic.List`1::get_Item
02d59b00: bl      #0x2b70db0                                 fn_2b70db0
02d59b04: adrp    x0, #0x6266000                             
02d59b08: ldr     x0, [x0, #0xaa0]                           MS:MonoSingleton`1::get_Instance
02d59b0c: bl      #0x2b70db0                                 fn_2b70db0
02d59b10: adrp    x0, #0x6266000                             
02d59b14: ldr     x0, [x0, #0x880]                           MS:DG.Tweening.TweenSettingsExtensions::SetEase
02d59b18: bl      #0x2b70db0                                 fn_2b70db0
02d59b1c: mov     w8, #1                                     
02d59b20: strb    w8, [x20, #0x2b1]                          
02d59b24: mov     x0, x19                                    
02d59b28: mov     x1, xzr                                    
02d59b2c: bl      #0x2cdd6b8                                 UIBase::OnShow
02d59b30: ldr     x0, [x21]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d59b34: bl      #0x3769600                                 fn_3769600
02d59b38: cbz     x0, #0x2d59cdc                             
02d59b3c: adrp    x8, #0x6264000                             
02d59b40: ldr     x8, [x8, #0xd88]                           MS:UnityEngine.Component::GetComponent
02d59b44: ldr     x1, [x8]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d59b48: bl      #0x3140c84                                 fn_3140c84
02d59b4c: mov     x20, x19                                   
02d59b50: mov     x1, x0                                     
02d59b54: str     x0, [x20, #0xa8]!                          ._rectMoneyManager
02d59b58: mov     x0, x20                                    
02d59b5c: bl      #0x2b70d54                                 fn_2b70d54
02d59b60: ldr     x0, [x20]                                  
02d59b64: cbz     x0, #0x2d59cdc                             
02d59b68: mov     x1, xzr                                    
02d59b6c: bl      #0x5b45734                                 UnityEngine.RectTransform::get_anchoredPosition
02d59b70: ldr     x0, [x21]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d59b74: stp     s0, s1, [x19, #0xa0]                       ._cachedAnchor
02d59b78: bl      #0x3769600                                 fn_3769600
02d59b7c: ldr     x8, [x19, #0x98]                           ._header
02d59b80: cbz     x8, #0x2d59cdc                             
02d59b84: mov     x20, x0                                    
02d59b88: mov     x0, x8                                     
02d59b8c: mov     x1, xzr                                    
02d59b90: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02d59b94: cbz     x20, #0x2d59cdc                            
02d59b98: mov     x1, x0                                     
02d59b9c: mov     x0, x20                                    
02d59ba0: mov     x2, xzr                                    
02d59ba4: bl      #0x2cdac14                                 MoneyManager::SetCurrentParent
02d59ba8: mov     w8, #-0x3d100000                           
02d59bac: ldr     x0, [x19, #0xa8]                           ._rectMoneyManager
02d59bb0: mov     x1, xzr                                    
02d59bb4: fmov    s0, w8                                     
02d59bb8: bl      #0x2dbf2fc                                 Redcode.Extensions.RectTransformExtensions::SetAnchoredPositionY
02d59bbc: mov     x0, x19                                    
02d59bc0: bl      #0x2d59cf4                                 LoginTimeReward.LoginTimeRewardPopup::LoadRewardData
02d59bc4: ldr     x0, [x19, #0x90]                           ._tfPanel
02d59bc8: mov     w1, wzr                                    
02d59bcc: mov     x2, xzr                                    
02d59bd0: bl      #0x2d9d5d0                                 DG.Tweening.ShortcutExtensions::DOKill
02d59bd4: adrp    x21, #0x662f000                            
02d59bd8: ldr     x20, [x19, #0x90]                          ._tfPanel
02d59bdc: ldrb    w8, [x21, #0x91a]                          
02d59be0: cbnz    w8, #0x2d59bf8                             
02d59be4: adrp    x0, #0x6264000                             
02d59be8: ldr     x0, [x0, #0xd8]                            T:UnityEngine.Vector3
02d59bec: bl      #0x2b70db0                                 fn_2b70db0
02d59bf0: mov     w8, #1                                     
02d59bf4: strb    w8, [x21, #0x91a]                          
02d59bf8: cbz     x20, #0x2d59cdc                            
02d59bfc: adrp    x22, #0x6264000                            
02d59c00: adrp    x21, #0x6266000                            
02d59c04: mov     x0, x20                                    
02d59c08: ldr     x22, [x22, #0xd8]                          T:UnityEngine.Vector3
02d59c0c: mov     x1, xzr                                    
02d59c10: ldr     x8, [x22]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d59c14: ldr     x8, [x8, #0xb8]                            MS:DG.Tweening.Core.Extensions::SetSpecialStartupMode
02d59c18: ldr     x21, [x21, #0x880]                         MS:DG.Tweening.TweenSettingsExtensions::SetEase
02d59c1c: ldp     s1, s2, [x8, #4]                           
02d59c20: ldr     s0, [x8]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d59c24: bl      #0x5b470cc                                 UnityEngine.Transform::set_localScale
02d59c28: adrp    x23, #0x662f000                            
02d59c2c: ldr     x20, [x19, #0x90]                          ._tfPanel
02d59c30: ldrb    w8, [x23, #0xa74]                          
02d59c34: cbnz    w8, #0x2d59c4c                             
02d59c38: adrp    x0, #0x6264000                             
02d59c3c: ldr     x0, [x0, #0xd8]                            T:UnityEngine.Vector3
02d59c40: bl      #0x2b70db0                                 fn_2b70db0
02d59c44: mov     w8, #1                                     
02d59c48: strb    w8, [x23, #0xa74]                          
02d59c4c: ldr     x8, [x22]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d59c50: mov     x0, x20                                    
02d59c54: mov     x1, xzr                                    
02d59c58: ldr     x8, [x8, #0xb8]                            MS:DG.Tweening.Core.Extensions::SetSpecialStartupMode
02d59c5c: ldp     s0, s1, [x8, #0xc]                         
02d59c60: ldr     s2, [x8, #0x14]                            [6264014]=0 f=0,0
02d59c64: adrp    x8, #0x1084000                             
02d59c68: ldr     s3, [x8, #0xf10]                           [1084f10]=4110bc863e99999a f=0.3,9.04603
02d59c6c: bl      #0x2d98af8                                 DG.Tweening.ShortcutExtensions::DOScale
02d59c70: ldr     x2, [x21]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d59c74: mov     w1, #0x1b                                  
02d59c78: bl      #0x336fa0c                                 fn_336fa0c
02d59c7c: ldr     x0, [x19, #0x50]                           ._rewardUIItemList
02d59c80: cbz     x0, #0x2d59cdc                             
02d59c84: adrp    x21, #0x626b000                            
02d59c88: adrp    x8, #0x1084000                             
02d59c8c: adrp    x9, #0x1084000                             
02d59c90: ldr     x21, [x21, #0xb38]                         MS:System.Collections.Generic.List`1::get_Item
02d59c94: ldr     s8, [x8, #0xdfc]                           [1084dfc]=3f2666663d4ccccd f=0.05,0.65
02d59c98: ldr     s9, [x9, #0xda4]                           [1084da4]=3eb851ec3e19999a f=0.15,0.36
02d59c9c: mov     w20, wzr                                   
02d59ca0: ldr     w8, [x0, #0x18]                            M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass2_0::<DOSetFloat>b__1
02d59ca4: cmp     w20, w8                                    
02d59ca8: b.ge    #0x2d59ce0                                 
02d59cac: ldr     x2, [x21]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d59cb0: mov     w1, w20                                    
02d59cb4: bl      #0x35a8f3c                                 fn_35a8f3c
02d59cb8: cbz     x0, #0x2d59cdc                             
02d59cbc: scvtf   s0, w20                                    
02d59cc0: mov     x1, xzr                                    
02d59cc4: fmul    s0, s0, s8                                 
02d59cc8: fadd    s0, s0, s9                                 
02d59ccc: bl      #0x2cb7b14                                 DailyLoginRewardUIItem::AnimShow
02d59cd0: ldr     x0, [x19, #0x50]                           ._rewardUIItemList
02d59cd4: add     w20, w20, #1                               
02d59cd8: cbnz    x0, #0x2d59ca0                             
02d59cdc: bl      #0x2b7105c                                 fn_2b7105c
02d59ce0: ldp     x20, x19, [sp, #0x30]                      
02d59ce4: ldp     x22, x21, [sp, #0x20]                      
02d59ce8: ldp     x30, x23, [sp, #0x10]                      
02d59cec: ldp     d9, d8, [sp], #0x40                        
02d59cf0: ret                                                
## LoadRewardData() -> void
---- LoginTimeReward.LoginTimeRewardPopup::LoadRewardData 0x2d59cf4
02d59cf4: str     x30, [sp, #-0x30]!                         
02d59cf8: stp     x22, x21, [sp, #0x10]                      
02d59cfc: stp     x20, x19, [sp, #0x20]                      
02d59d00: adrp    x20, #0x6630000                            
02d59d04: adrp    x22, #0x626b000                            
02d59d08: mov     x19, x0                                    
02d59d0c: ldrb    w8, [x20, #0x2b2]                          
02d59d10: ldr     x22, [x22, #0xb48]                         T:LoginTimeReward.LoginTimeRewardPopup/<>c
02d59d14: tbnz    w8, #0, #0x2d59d50                         
02d59d18: adrp    x0, #0x626b000                             
02d59d1c: ldr     x0, [x0, #0xb50]                           T:type53126(k15)
02d59d20: bl      #0x2b70db0                                 fn_2b70db0
02d59d24: adrp    x0, #0x626b000                             
02d59d28: ldr     x0, [x0, #0xb58]                           MS:System.Collections.Generic.List`1::ForEach
02d59d2c: bl      #0x2b70db0                                 fn_2b70db0
02d59d30: adrp    x0, #0x626b000                             
02d59d34: ldr     x0, [x0, #0xb60]                           M:LoginTimeReward.LoginTimeRewardPopup/<>c::<LoadRewardData>b__19_0
02d59d38: bl      #0x2b70db0                                 fn_2b70db0
02d59d3c: adrp    x0, #0x626b000                             
02d59d40: ldr     x0, [x0, #0xb48]                           T:LoginTimeReward.LoginTimeRewardPopup/<>c
02d59d44: bl      #0x2b70db0                                 fn_2b70db0
02d59d48: mov     w8, #1                                     
02d59d4c: strb    w8, [x20, #0x2b2]                          
02d59d50: ldr     x0, [x22]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d59d54: ldr     x19, [x19, #0x50]                          ._rewardUIItemList
02d59d58: ldr     w8, [x0, #0xe4]                            [626b0e4]=0 f=0,0
02d59d5c: cbnz    w8, #0x2d59d68                             
02d59d60: bl      #0x2b70f30                                 fn_2b70f30
02d59d64: ldr     x0, [x22]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d59d68: ldr     x8, [x0, #0xb8]                            S:'scoop_no_thank'
02d59d6c: ldr     x20, [x8, #8]                              
02d59d70: cbnz    x20, #0x2d59dcc                            
02d59d74: ldr     w9, [x0, #0xe4]                            [626b0e4]=0 f=0,0
02d59d78: cbnz    w9, #0x2d59d88                             
02d59d7c: bl      #0x2b70f30                                 fn_2b70f30
02d59d80: ldr     x8, [x22]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d59d84: ldr     x8, [x8, #0xb8]                            
02d59d88: adrp    x9, #0x626b000                             
02d59d8c: ldr     x9, [x9, #0xb50]                           T:type53126(k15)
02d59d90: ldr     x21, [x8]                                  
02d59d94: ldr     x0, [x9]                                   T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d59d98: bl      #0x2b7104c                                 fn_2b7104c
02d59d9c: adrp    x8, #0x626b000                             
02d59da0: mov     x1, x21                                    
02d59da4: mov     x3, xzr                                    
02d59da8: ldr     x8, [x8, #0xb60]                           M:LoginTimeReward.LoginTimeRewardPopup/<>c::<LoadRewardData>b__19_0
02d59dac: mov     x20, x0                                    
02d59db0: ldr     x2, [x8]                                   T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d59db4: bl      #0x453418c                                 fn_453418c
02d59db8: ldr     x8, [x22]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d59dbc: mov     x1, x20                                    
02d59dc0: ldr     x0, [x8, #0xb8]                            S:'scoop_no_thank'
02d59dc4: str     x20, [x0, #8]!                             
02d59dc8: bl      #0x2b70d54                                 fn_2b70d54
02d59dcc: cbz     x19, #0x2d59df4                            
02d59dd0: adrp    x8, #0x626b000                             
02d59dd4: mov     x0, x19                                    
02d59dd8: mov     x1, x20                                    
02d59ddc: ldr     x8, [x8, #0xb58]                           MS:System.Collections.Generic.List`1::ForEach
02d59de0: ldp     x20, x19, [sp, #0x20]                      
02d59de4: ldp     x22, x21, [sp, #0x10]                      
02d59de8: ldr     x2, [x8]                                   T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d59dec: ldr     x30, [sp], #0x30                           
02d59df0: b       #0x35a9ce4                                 
02d59df4: bl      #0x2b7105c                                 fn_2b7105c
## OnHide() -> void
---- LoginTimeReward.LoginTimeRewardPopup::OnHide 0x2d59df8
02d59df8: str     x30, [sp, #-0x30]!                         
02d59dfc: stp     x22, x21, [sp, #0x10]                      
02d59e00: stp     x20, x19, [sp, #0x20]                      
02d59e04: adrp    x20, #0x6630000                            
02d59e08: mov     x19, x0                                    
02d59e0c: ldrb    w8, [x20, #0x2b3]                          
02d59e10: tbnz    w8, #0, #0x2d59e58                         
02d59e14: adrp    x0, #0x626b000                             
02d59e18: ldr     x0, [x0, #0xb50]                           T:type53126(k15)
02d59e1c: bl      #0x2b70db0                                 fn_2b70db0
02d59e20: adrp    x0, #0x626b000                             
02d59e24: ldr     x0, [x0, #0xb58]                           MS:System.Collections.Generic.List`1::ForEach
02d59e28: bl      #0x2b70db0                                 fn_2b70db0
02d59e2c: adrp    x0, #0x6266000                             
02d59e30: ldr     x0, [x0, #0xaa0]                           MS:MonoSingleton`1::get_Instance
02d59e34: bl      #0x2b70db0                                 fn_2b70db0
02d59e38: adrp    x0, #0x626b000                             
02d59e3c: ldr     x0, [x0, #0xb68]                           M:LoginTimeReward.LoginTimeRewardPopup/<>c::<OnHide>b__20_0
02d59e40: bl      #0x2b70db0                                 fn_2b70db0
02d59e44: adrp    x0, #0x626b000                             
02d59e48: ldr     x0, [x0, #0xb48]                           T:LoginTimeReward.LoginTimeRewardPopup/<>c
02d59e4c: bl      #0x2b70db0                                 fn_2b70db0
02d59e50: mov     w8, #1                                     
02d59e54: strb    w8, [x20, #0x2b3]                          
02d59e58: mov     x0, x19                                    
02d59e5c: mov     x1, xzr                                    
02d59e60: bl      #0x2cddc10                                 UIBase::OnHide
02d59e64: ldr     x0, [x19, #0xa8]                           ._rectMoneyManager
02d59e68: cbz     x0, #0x2d59f40                             
02d59e6c: adrp    x20, #0x6266000                            
02d59e70: mov     x1, xzr                                    
02d59e74: ldr     x20, [x20, #0xaa0]                         MS:MonoSingleton`1::get_Instance
02d59e78: ldp     s0, s1, [x19, #0xa0]                       ._cachedAnchor
02d59e7c: bl      #0x5b45800                                 UnityEngine.RectTransform::set_anchoredPosition
02d59e80: ldr     x0, [x20]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d59e84: bl      #0x3769600                                 fn_3769600
02d59e88: cbz     x0, #0x2d59f40                             
02d59e8c: adrp    x22, #0x626b000                            
02d59e90: mov     x1, xzr                                    
02d59e94: ldr     x22, [x22, #0xb48]                         T:LoginTimeReward.LoginTimeRewardPopup/<>c
02d59e98: bl      #0x2cdb2e8                                 MoneyManager::BackToParent
02d59e9c: ldr     x0, [x22]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d59ea0: ldr     x19, [x19, #0x50]                          ._rewardUIItemList
02d59ea4: ldr     w8, [x0, #0xe4]                            [626b0e4]=0 f=0,0
02d59ea8: cbnz    w8, #0x2d59eb4                             
02d59eac: bl      #0x2b70f30                                 fn_2b70f30
02d59eb0: ldr     x0, [x22]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d59eb4: ldr     x8, [x0, #0xb8]                            S:'scoop_no_thank'
02d59eb8: ldr     x20, [x8, #0x10]                           
02d59ebc: cbnz    x20, #0x2d59f18                            
02d59ec0: ldr     w9, [x0, #0xe4]                            [626b0e4]=0 f=0,0
02d59ec4: cbnz    w9, #0x2d59ed4                             
02d59ec8: bl      #0x2b70f30                                 fn_2b70f30
02d59ecc: ldr     x8, [x22]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d59ed0: ldr     x8, [x8, #0xb8]                            
02d59ed4: adrp    x9, #0x626b000                             
02d59ed8: ldr     x9, [x9, #0xb50]                           T:type53126(k15)
02d59edc: ldr     x21, [x8]                                  
02d59ee0: ldr     x0, [x9]                                   T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d59ee4: bl      #0x2b7104c                                 fn_2b7104c
02d59ee8: adrp    x8, #0x626b000                             
02d59eec: mov     x1, x21                                    
02d59ef0: mov     x3, xzr                                    
02d59ef4: ldr     x8, [x8, #0xb68]                           M:LoginTimeReward.LoginTimeRewardPopup/<>c::<OnHide>b__20_0
02d59ef8: mov     x20, x0                                    
02d59efc: ldr     x2, [x8]                                   T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d59f00: bl      #0x453418c                                 fn_453418c
02d59f04: ldr     x8, [x22]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d59f08: mov     x1, x20                                    
02d59f0c: ldr     x0, [x8, #0xb8]                            S:'scoop_no_thank'
02d59f10: str     x20, [x0, #0x10]!                          
02d59f14: bl      #0x2b70d54                                 fn_2b70d54
02d59f18: cbz     x19, #0x2d59f40                            
02d59f1c: adrp    x8, #0x626b000                             
02d59f20: mov     x0, x19                                    
02d59f24: mov     x1, x20                                    
02d59f28: ldr     x8, [x8, #0xb58]                           MS:System.Collections.Generic.List`1::ForEach
02d59f2c: ldp     x20, x19, [sp, #0x20]                      
02d59f30: ldp     x22, x21, [sp, #0x10]                      
02d59f34: ldr     x2, [x8]                                   T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d59f38: ldr     x30, [sp], #0x30                           
02d59f3c: b       #0x35a9ce4                                 
02d59f40: bl      #0x2b7105c                                 fn_2b7105c
## OnBtnCloseClick() -> void
---- LoginTimeReward.LoginTimeRewardPopup::OnBtnCloseClick 0x2d59f44
02d59f44: stp     x30, x23, [sp, #-0x30]!                    
02d59f48: stp     x22, x21, [sp, #0x10]                      
02d59f4c: stp     x20, x19, [sp, #0x20]                      
02d59f50: adrp    x20, #0x6630000                            
02d59f54: mov     x19, x0                                    
02d59f58: ldrb    w8, [x20, #0x2b4]                          
02d59f5c: tbnz    w8, #0, #0x2d59fa4                         
02d59f60: adrp    x0, #0x6264000                             
02d59f64: ldr     x0, [x0, #0xf90]                           T:System.Action
02d59f68: bl      #0x2b70db0                                 fn_2b70db0
02d59f6c: adrp    x0, #0x626b000                             
02d59f70: ldr     x0, [x0, #0xb70]                           M:LoginTimeReward.LoginTimeRewardPopup::<OnBtnCloseClick>b__21_0
02d59f74: bl      #0x2b70db0                                 fn_2b70db0
02d59f78: adrp    x0, #0x6265000                             
02d59f7c: ldr     x0, [x0, #0x310]                           MS:WejoyService.Singleton`1::get_Instance
02d59f80: bl      #0x2b70db0                                 fn_2b70db0
02d59f84: adrp    x0, #0x6267000                             
02d59f88: ldr     x0, [x0, #0xea8]                           T:Framework.Vibration
02d59f8c: bl      #0x2b70db0                                 fn_2b70db0
02d59f90: adrp    x0, #0x626b000                             
02d59f94: ldr     x0, [x0, #0xb78]                           S:'close_login'
02d59f98: bl      #0x2b70db0                                 fn_2b70db0
02d59f9c: mov     w8, #1                                     
02d59fa0: strb    w8, [x20, #0x2b4]                          
02d59fa4: mov     x0, xzr                                    
02d59fa8: bl      #0x2d6eec8                                 Framework.AudioManager::get_Instance
02d59fac: cbz     x0, #0x2d5a070                             
02d59fb0: movi    d1, #0000000000000000                      
02d59fb4: movi    d2, #0000000000000000                      
02d59fb8: adrp    x23, #0x6267000                            
02d59fbc: fmov    s0, #1.00000000                            
02d59fc0: adrp    x22, #0x6265000                            
02d59fc4: adrp    x20, #0x6264000                            
02d59fc8: adrp    x21, #0x626b000                            
02d59fcc: ldr     x23, [x23, #0xea8]                         T:Framework.Vibration
02d59fd0: ldr     x22, [x22, #0x310]                         MS:WejoyService.Singleton`1::get_Instance
02d59fd4: ldr     x20, [x20, #0xf90]                         T:System.Action
02d59fd8: ldr     x21, [x21, #0xb70]                         M:LoginTimeReward.LoginTimeRewardPopup::<OnBtnCloseClick>b__21_0
02d59fdc: mov     w1, #1                                     
02d59fe0: mov     w2, wzr                                    
02d59fe4: mov     w3, wzr                                    
02d59fe8: mov     x4, xzr                                    
02d59fec: bl      #0x2d6f03c                                 Framework.AudioManager::PlaySound
02d59ff0: ldr     x0, [x23]                                  S:'didu'
02d59ff4: ldr     w8, [x0, #0xe4]                            [626b0e4]=0 f=0,0
02d59ff8: cbnz    w8, #0x2d5a000                             
02d59ffc: bl      #0x2b70f30                                 fn_2b70f30
02d5a000: mov     w0, #0x64                                  
02d5a004: mov     w1, #-1                                    
02d5a008: mov     w2, wzr                                    
02d5a00c: mov     x3, xzr                                    
02d5a010: bl      #0x2d6e144                                 Framework.Vibration::Vibrate
02d5a014: ldr     x0, [x22]                                  M:AdsManager::<OnApplicationPause>b__26_0
02d5a018: bl      #0x3be7218                                 fn_3be7218
02d5a01c: ldr     x8, [x20]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d5a020: mov     x20, x0                                    
02d5a024: mov     x0, x8                                     
02d5a028: bl      #0x2b7104c                                 fn_2b7104c
02d5a02c: ldr     x2, [x21]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d5a030: mov     x1, x19                                    
02d5a034: mov     x3, xzr                                    
02d5a038: mov     x21, x0                                    
02d5a03c: bl      #0x4d8ddbc                                 System.Action::.ctor
02d5a040: cbz     x20, #0x2d5a070                            
02d5a044: adrp    x8, #0x626b000                             
02d5a048: mov     x0, x20                                    
02d5a04c: mov     x2, x21                                    
02d5a050: ldr     x8, [x8, #0xb78]                           S:'close_login'
02d5a054: ldp     x20, x19, [sp, #0x20]                      
02d5a058: ldp     x22, x21, [sp, #0x10]                      
02d5a05c: mov     w3, #1                                     
02d5a060: ldr     x1, [x8]                                   T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d5a064: mov     x4, xzr                                    
02d5a068: ldp     x30, x23, [sp], #0x30                      
02d5a06c: b       #0x2c89698                                 AdsManager::ShowInter
02d5a070: bl      #0x2b7105c                                 fn_2b7105c
## ClaimReward(DailyLoginRewardUIItem item) -> void
---- LoginTimeReward.LoginTimeRewardPopup::ClaimReward 0x2d5a074
02d5a074: str     x30, [sp, #-0x40]!                         
02d5a078: stp     x24, x23, [sp, #0x10]                      
02d5a07c: stp     x22, x21, [sp, #0x20]                      
02d5a080: stp     x20, x19, [sp, #0x30]                      
02d5a084: adrp    x21, #0x6630000                            
02d5a088: adrp    x22, #0x6266000                            
02d5a08c: mov     x20, x1                                    
02d5a090: ldrb    w8, [x21, #0x2b5]                          
02d5a094: ldr     x22, [x22, #0x658]                         MS:MonoSingleton`1::get_Instance
02d5a098: mov     x19, x0                                    
02d5a09c: tbnz    w8, #0, #0x2d5a138                         
02d5a0a0: adrp    x0, #0x626b000                             
02d5a0a4: ldr     x0, [x0, #0xb50]                           T:type53126(k15)
02d5a0a8: bl      #0x2b70db0                                 fn_2b70db0
02d5a0ac: adrp    x0, #0x6266000                             
02d5a0b0: ldr     x0, [x0, #0x8d0]                           MS:DataManager::GetData
02d5a0b4: bl      #0x2b70db0                                 fn_2b70db0
02d5a0b8: adrp    x0, #0x6266000                             
02d5a0bc: ldr     x0, [x0, #0x750]                           MS:DataManager::GetData
02d5a0c0: bl      #0x2b70db0                                 fn_2b70db0
02d5a0c4: adrp    x0, #0x6266000                             
02d5a0c8: ldr     x0, [x0, #0x820]                           MS:System.Collections.Generic.List`1::Contains
02d5a0cc: bl      #0x2b70db0                                 fn_2b70db0
02d5a0d0: adrp    x0, #0x626b000                             
02d5a0d4: ldr     x0, [x0, #0xb58]                           MS:System.Collections.Generic.List`1::ForEach
02d5a0d8: bl      #0x2b70db0                                 fn_2b70db0
02d5a0dc: adrp    x0, #0x6266000                             
02d5a0e0: ldr     x0, [x0, #0xdd8]                           MS:System.Collections.Generic.List`1::get_Item
02d5a0e4: bl      #0x2b70db0                                 fn_2b70db0
02d5a0e8: adrp    x0, #0x626b000                             
02d5a0ec: ldr     x0, [x0, #0xae8]                           MS:System.Collections.Generic.List`1::set_Item
02d5a0f0: bl      #0x2b70db0                                 fn_2b70db0
02d5a0f4: adrp    x0, #0x6266000                             
02d5a0f8: ldr     x0, [x0, #0xaa0]                           MS:MonoSingleton`1::get_Instance
02d5a0fc: bl      #0x2b70db0                                 fn_2b70db0
02d5a100: adrp    x0, #0x6266000                             
02d5a104: ldr     x0, [x0, #0x658]                           MS:MonoSingleton`1::get_Instance
02d5a108: bl      #0x2b70db0                                 fn_2b70db0
02d5a10c: adrp    x0, #0x626b000                             
02d5a110: ldr     x0, [x0, #0xb80]                           M:LoginTimeReward.LoginTimeRewardPopup/<>c::<ClaimReward>b__22_0
02d5a114: bl      #0x2b70db0                                 fn_2b70db0
02d5a118: adrp    x0, #0x626b000                             
02d5a11c: ldr     x0, [x0, #0xb48]                           T:LoginTimeReward.LoginTimeRewardPopup/<>c
02d5a120: bl      #0x2b70db0                                 fn_2b70db0
02d5a124: adrp    x0, #0x626b000                             
02d5a128: ldr     x0, [x0, #0xb88]                           MS:UIManager::ShowPopup
02d5a12c: bl      #0x2b70db0                                 fn_2b70db0
02d5a130: mov     w8, #1                                     
02d5a134: strb    w8, [x21, #0x2b5]                          
02d5a138: ldr     x0, [x22]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d5a13c: bl      #0x3769600                                 fn_3769600
02d5a140: cbz     x0, #0x2d5a490                             
02d5a144: adrp    x8, #0x6266000                             
02d5a148: ldr     x8, [x8, #0x8d0]                           MS:DataManager::GetData
02d5a14c: ldr     x1, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d5a150: bl      #0x3168dd0                                 fn_3168dd0
02d5a154: cbz     x0, #0x2d5a490                             
02d5a158: ldr     x8, [x0, #0x20]                            M:ScoopGame.CategoryAsset/<>c__DisplayClass4_0::<GetOptionDataByID>b__0
02d5a15c: mov     x21, x0                                    
02d5a160: cbz     x8, #0x2d5a490                             
02d5a164: cbz     x20, #0x2d5a490                            
02d5a168: ldr     x9, [x20, #0xb8]                           
02d5a16c: cbz     x9, #0x2d5a490                             
02d5a170: ldr     x0, [x8, #0x20]                            S:'inter_ad_capping_time'
02d5a174: cbz     x0, #0x2d5a490                             
02d5a178: adrp    x8, #0x6266000                             
02d5a17c: ldr     x8, [x8, #0xdd8]                           MS:System.Collections.Generic.List`1::get_Item
02d5a180: ldr     w1, [x9, #0x10]                            
02d5a184: ldr     x2, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d5a188: bl      #0x4baf438                                 fn_4baf438
02d5a18c: tbz     w0, #0, #0x2d5a1a4                         
02d5a190: ldp     x20, x19, [sp, #0x30]                      
02d5a194: ldp     x22, x21, [sp, #0x20]                      
02d5a198: ldp     x24, x23, [sp, #0x10]                      
02d5a19c: ldr     x30, [sp], #0x40                           
02d5a1a0: ret                                                
02d5a1a4: ldr     x9, [x21, #0x20]                           
02d5a1a8: cbz     x9, #0x2d5a490                             
02d5a1ac: ldr     x8, [x20, #0xb8]                           
02d5a1b0: cbz     x8, #0x2d5a490                             
02d5a1b4: ldr     x0, [x9, #0x20]                            
02d5a1b8: cbz     x0, #0x2d5a490                             
02d5a1bc: adrp    x9, #0x626b000                             
02d5a1c0: mov     w2, #1                                     
02d5a1c4: ldr     x9, [x9, #0xae8]                           MS:System.Collections.Generic.List`1::set_Item
02d5a1c8: ldr     w1, [x8, #0x10]                            S:'mrec_ad_on_off'
02d5a1cc: ldr     x3, [x9]                                   T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d5a1d0: bl      #0x4baf48c                                 fn_4baf48c
02d5a1d4: ldr     x0, [x22]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d5a1d8: bl      #0x3769600                                 fn_3769600
02d5a1dc: cbz     x0, #0x2d5a490                             
02d5a1e0: adrp    x8, #0x6266000                             
02d5a1e4: ldr     x8, [x8, #0x750]                           MS:DataManager::GetData
02d5a1e8: ldr     x1, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d5a1ec: bl      #0x3168dd0                                 fn_3168dd0
02d5a1f0: ldr     x8, [x20, #0xb8]                           
02d5a1f4: cbz     x8, #0x2d5a490                             
02d5a1f8: ldr     w8, [x8, #0x18]                            S:'level_show_popuprate'
02d5a1fc: mov     x21, x0                                    
02d5a200: cmp     w8, #1                                     
02d5a204: b.gt    #0x2d5a27c                                 
02d5a208: cbz     w8, #0x2d5a344                             
02d5a20c: cmp     w8, #1                                     
02d5a210: b.ne    #0x2d5a3e0                                 
02d5a214: ldr     x0, [x19, #0x88]                           ._decorKeycapConfig
02d5a218: cbz     x0, #0x2d5a490                             
02d5a21c: bl      #0x2d5a494                                 Clicker.DecorKeycapConfig::GetRandomDataLockedCommon
02d5a220: cbz     x21, #0x2d5a490                            
02d5a224: ldr     x8, [x21, #0x20]                           
02d5a228: cbz     x8, #0x2d5a490                             
02d5a22c: adrp    x23, #0x6266000                            
02d5a230: mov     x22, x0                                    
02d5a234: mov     w24, #0xb                                  
02d5a238: ldr     x23, [x23, #0x820]                         MS:System.Collections.Generic.List`1::Contains
02d5a23c: cbz     x22, #0x2d5a490                            
02d5a240: ldr     x0, [x8, #0x60]                            S:'open_ad_on_off'
02d5a244: cbz     x0, #0x2d5a490                             
02d5a248: ldr     w1, [x22, #0x10]                           S:'mrec_ad_on_off'
02d5a24c: ldr     x2, [x23]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d5a250: bl      #0x3569f98                                 fn_3569f98
02d5a254: tbz     w0, #0, #0x2d5a3a8                         
02d5a258: subs    w24, w24, #1                               
02d5a25c: b.eq    #0x2d5a378                                 
02d5a260: ldr     x0, [x19, #0x88]                           ._decorKeycapConfig
02d5a264: cbz     x0, #0x2d5a490                             
02d5a268: bl      #0x2d5a494                                 Clicker.DecorKeycapConfig::GetRandomDataLockedCommon
02d5a26c: ldr     x8, [x21, #0x20]                           
02d5a270: mov     x22, x0                                    
02d5a274: cbnz    x8, #0x2d5a23c                             
02d5a278: b       #0x2d5a490                                 
02d5a27c: cmp     w8, #2                                     
02d5a280: b.eq    #0x2d5a2f4                                 
02d5a284: cmp     w8, #3                                     
02d5a288: b.ne    #0x2d5a3e0                                 
02d5a28c: ldr     x0, [x19, #0x88]                           ._decorKeycapConfig
02d5a290: cbz     x0, #0x2d5a490                             
02d5a294: bl      #0x2d5a698                                 Clicker.DecorKeycapConfig::GetRandomDataLockedRare
02d5a298: cbz     x21, #0x2d5a490                            
02d5a29c: ldr     x8, [x21, #0x20]                           
02d5a2a0: cbz     x8, #0x2d5a490                             
02d5a2a4: adrp    x23, #0x6266000                            
02d5a2a8: mov     x22, x0                                    
02d5a2ac: mov     w24, #0xb                                  
02d5a2b0: ldr     x23, [x23, #0x820]                         MS:System.Collections.Generic.List`1::Contains
02d5a2b4: cbz     x22, #0x2d5a490                            
02d5a2b8: ldr     x0, [x8, #0x60]                            S:'open_ad_on_off'
02d5a2bc: cbz     x0, #0x2d5a490                             
02d5a2c0: ldr     w1, [x22, #0x10]                           S:'mrec_ad_on_off'
02d5a2c4: ldr     x2, [x23]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d5a2c8: bl      #0x3569f98                                 fn_3569f98
02d5a2cc: tbz     w0, #0, #0x2d5a3a8                         
02d5a2d0: subs    w24, w24, #1                               
02d5a2d4: b.eq    #0x2d5a378                                 
02d5a2d8: ldr     x0, [x19, #0x88]                           ._decorKeycapConfig
02d5a2dc: cbz     x0, #0x2d5a490                             
02d5a2e0: bl      #0x2d5a698                                 Clicker.DecorKeycapConfig::GetRandomDataLockedRare
02d5a2e4: ldr     x8, [x21, #0x20]                           
02d5a2e8: mov     x22, x0                                    
02d5a2ec: cbnz    x8, #0x2d5a2b4                             
02d5a2f0: b       #0x2d5a490                                 
02d5a2f4: bl      #0x2d5a8a4                                 LoginTimeReward.LoginTimeRewardPopup::GetIdSkinUnclaimed
02d5a2f8: tbnz    w0, #0x1f, #0x2d5a344                      
02d5a2fc: ldr     x8, [x19]                                  
02d5a300: mov     w21, w0                                    
02d5a304: mov     x0, x19                                    
02d5a308: ldp     x9, x1, [x8, #0x198]                       
02d5a30c: blr     x9                                         
02d5a310: mov     w1, w21                                    
02d5a314: bl      #0x2d5aba0                                 LoginTimeReward.LoginTimeRewardPopup::UnlockDecorCharacterSkin
02d5a318: ldr     x0, [x19, #0x30]                           
02d5a31c: cbz     x0, #0x2d5a490                             
02d5a320: adrp    x8, #0x626b000                             
02d5a324: ldr     x8, [x8, #0xb88]                           MS:UIManager::ShowPopup
02d5a328: ldr     x1, [x8]                                   T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d5a32c: bl      #0x33fbfac                                 fn_33fbfac
02d5a330: cbz     x0, #0x2d5a490                             
02d5a334: mov     w1, w21                                    
02d5a338: mov     x2, xzr                                    
02d5a33c: bl      #0x2d590f0                                 LoginTimeReward.ClaimLoginRewardPopup::ShowDecorSkinContent
02d5a340: b       #0x2d5a3e0                                 
02d5a344: adrp    x8, #0x6266000                             
02d5a348: ldr     x8, [x8, #0xaa0]                           MS:MonoSingleton`1::get_Instance
02d5a34c: ldr     x0, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d5a350: bl      #0x3769600                                 fn_3769600
02d5a354: ldr     x8, [x20, #0xb8]                           
02d5a358: cbz     x8, #0x2d5a490                             
02d5a35c: cbz     x0, #0x2d5a490                             
02d5a360: ldr     w1, [x8, #0x1c]                            [626601c]=0 f=0,0
02d5a364: mov     w2, #0xa                                   
02d5a368: mov     x3, xzr                                    
02d5a36c: mov     x4, xzr                                    
02d5a370: bl      #0x2cdaf30                                 MoneyManager::CollectMoney
02d5a374: b       #0x2d5a3e0                                 
02d5a378: adrp    x8, #0x6266000                             
02d5a37c: ldr     x8, [x8, #0xaa0]                           MS:MonoSingleton`1::get_Instance
02d5a380: ldr     x0, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d5a384: bl      #0x3769600                                 fn_3769600
02d5a388: ldr     x8, [x20, #0xb8]                           
02d5a38c: cbz     x8, #0x2d5a490                             
02d5a390: cbz     x0, #0x2d5a490                             
02d5a394: ldr     w1, [x8, #0x1c]                            [626601c]=0 f=0,0
02d5a398: mov     w2, #0xa                                   
02d5a39c: mov     x3, xzr                                    
02d5a3a0: mov     x4, xzr                                    
02d5a3a4: bl      #0x2cdaf30                                 MoneyManager::CollectMoney
02d5a3a8: ldr     w1, [x22, #0x10]                           S:'mrec_ad_on_off'
02d5a3ac: mov     x0, x21                                    
02d5a3b0: mov     x2, xzr                                    
02d5a3b4: bl      #0x2cabc2c                                 DataUser::UnlockClickerDecor
02d5a3b8: ldr     x0, [x19, #0x30]                           
02d5a3bc: cbz     x0, #0x2d5a490                             
02d5a3c0: adrp    x8, #0x626b000                             
02d5a3c4: ldr     x8, [x8, #0xb88]                           MS:UIManager::ShowPopup
02d5a3c8: ldr     x1, [x8]                                   T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d5a3cc: bl      #0x33fbfac                                 fn_33fbfac
02d5a3d0: cbz     x0, #0x2d5a490                             
02d5a3d4: ldr     x1, [x22, #0x28]                           S:'banner_ad_on_off'
02d5a3d8: mov     x2, xzr                                    
02d5a3dc: bl      #0x2d59058                                 LoginTimeReward.ClaimLoginRewardPopup::ShowUnlockDecorKeycap
02d5a3e0: adrp    x22, #0x626b000                            
02d5a3e4: ldr     x22, [x22, #0xb48]                         T:LoginTimeReward.LoginTimeRewardPopup/<>c
02d5a3e8: ldr     x19, [x19, #0x50]                          ._rewardUIItemList
02d5a3ec: ldr     x0, [x22]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d5a3f0: ldr     w8, [x0, #0xe4]                            [626b0e4]=0 f=0,0
02d5a3f4: cbnz    w8, #0x2d5a400                             
02d5a3f8: bl      #0x2b70f30                                 fn_2b70f30
02d5a3fc: ldr     x0, [x22]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d5a400: ldr     x8, [x0, #0xb8]                            S:'scoop_no_thank'
02d5a404: ldr     x20, [x8, #0x18]                           T:type57265(k15)
02d5a408: cbnz    x20, #0x2d5a464                            
02d5a40c: ldr     w9, [x0, #0xe4]                            [626b0e4]=0 f=0,0
02d5a410: cbnz    w9, #0x2d5a420                             
02d5a414: bl      #0x2b70f30                                 fn_2b70f30
02d5a418: ldr     x8, [x22]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d5a41c: ldr     x8, [x8, #0xb8]                            S:'scoop_no_thank'
02d5a420: adrp    x9, #0x626b000                             
02d5a424: ldr     x9, [x9, #0xb50]                           T:type53126(k15)
02d5a428: ldr     x21, [x8]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d5a42c: ldr     x0, [x9]                                   T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d5a430: bl      #0x2b7104c                                 fn_2b7104c
02d5a434: adrp    x8, #0x626b000                             
02d5a438: mov     x1, x21                                    
02d5a43c: mov     x3, xzr                                    
02d5a440: ldr     x8, [x8, #0xb80]                           M:LoginTimeReward.LoginTimeRewardPopup/<>c::<ClaimReward>b__22_0
02d5a444: mov     x20, x0                                    
02d5a448: ldr     x2, [x8]                                   T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d5a44c: bl      #0x453418c                                 fn_453418c
02d5a450: ldr     x8, [x22]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d5a454: mov     x1, x20                                    
02d5a458: ldr     x0, [x8, #0xb8]                            S:'scoop_no_thank'
02d5a45c: str     x20, [x0, #0x18]!                          
02d5a460: bl      #0x2b70d54                                 fn_2b70d54
02d5a464: cbz     x19, #0x2d5a490                            
02d5a468: adrp    x8, #0x626b000                             
02d5a46c: mov     x0, x19                                    
02d5a470: mov     x1, x20                                    
02d5a474: ldr     x8, [x8, #0xb58]                           MS:System.Collections.Generic.List`1::ForEach
02d5a478: ldp     x20, x19, [sp, #0x30]                      
02d5a47c: ldp     x22, x21, [sp, #0x20]                      
02d5a480: ldp     x24, x23, [sp, #0x10]                      
02d5a484: ldr     x2, [x8]                                   T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d5a488: ldr     x30, [sp], #0x40                           
02d5a48c: b       #0x35a9ce4                                 
02d5a490: bl      #0x2b7105c                                 fn_2b7105c
## Update() -> void
---- LoginTimeReward.LoginTimeRewardPopup::Update 0x2d5ac1c
02d5ac1c: str     d8, [sp, #-0x20]!                          
02d5ac20: stp     x30, x19, [sp, #0x10]                      
02d5ac24: mov     x19, x0                                    
02d5ac28: ldr     s8, [x0, #0xb0]                            ._nextTimer
02d5ac2c: mov     x0, xzr                                    
02d5ac30: bl      #0x5b432fc                                 UnityEngine.Time::get_time
02d5ac34: fcmp    s8, s0                                     
02d5ac38: b.pl    #0x2d5ac60                                 
02d5ac3c: mov     x0, xzr                                    
02d5ac40: bl      #0x5b432fc                                 UnityEngine.Time::get_time
02d5ac44: fmov    s1, #1.00000000                            
02d5ac48: mov     x0, x19                                    
02d5ac4c: fadd    s0, s0, s1                                 
02d5ac50: str     s0, [x19, #0xb0]                           ._nextTimer
02d5ac54: ldp     x30, x19, [sp, #0x10]                      
02d5ac58: ldr     d8, [sp], #0x20                            
02d5ac5c: b       #0x2d5ac6c                                 LoginTimeReward.LoginTimeRewardPopup::UpdateRewardStatus
02d5ac60: ldp     x30, x19, [sp, #0x10]                      
02d5ac64: ldr     d8, [sp], #0x20                            
02d5ac68: ret                                                
## UpdateRewardStatus() -> void
---- LoginTimeReward.LoginTimeRewardPopup::UpdateRewardStatus 0x2d5ac6c
02d5ac6c: sub     sp, sp, #0x60                              
02d5ac70: str     d8, [sp, #0x10]                            
02d5ac74: str     x30, [sp, #0x18]                           
02d5ac78: stp     x26, x25, [sp, #0x20]                      
02d5ac7c: stp     x24, x23, [sp, #0x30]                      
02d5ac80: stp     x22, x21, [sp, #0x40]                      
02d5ac84: stp     x20, x19, [sp, #0x50]                      
02d5ac88: adrp    x21, #0x6630000                            
02d5ac8c: adrp    x20, #0x6266000                            
02d5ac90: mov     x19, x0                                    
02d5ac94: ldrb    w8, [x21, #0x2b6]                          
02d5ac98: ldr     x20, [x20, #0xde0]                         MS:MonoSingleton`1::get_Instance
02d5ac9c: tbnz    w8, #0, #0x2d5ad20                         
02d5aca0: adrp    x0, #0x6266000                             
02d5aca4: ldr     x0, [x0, #0x8d0]                           MS:DataManager::GetData
02d5aca8: bl      #0x2b70db0                                 fn_2b70db0
02d5acac: adrp    x0, #0x6266000                             
02d5acb0: ldr     x0, [x0, #0x8d8]                           MS:System.Collections.Generic.List`1::get_Count
02d5acb4: bl      #0x2b70db0                                 fn_2b70db0
02d5acb8: adrp    x0, #0x626b000                             
02d5acbc: ldr     x0, [x0, #0xb30]                           MS:System.Collections.Generic.List`1::get_Item
02d5acc0: bl      #0x2b70db0                                 fn_2b70db0
02d5acc4: adrp    x0, #0x6266000                             
02d5acc8: ldr     x0, [x0, #0xdd8]                           MS:System.Collections.Generic.List`1::get_Item
02d5accc: bl      #0x2b70db0                                 fn_2b70db0
02d5acd0: adrp    x0, #0x6266000                             
02d5acd4: ldr     x0, [x0, #0xde0]                           MS:MonoSingleton`1::get_Instance
02d5acd8: bl      #0x2b70db0                                 fn_2b70db0
02d5acdc: adrp    x0, #0x6266000                             
02d5ace0: ldr     x0, [x0, #0x658]                           MS:MonoSingleton`1::get_Instance
02d5ace4: bl      #0x2b70db0                                 fn_2b70db0
02d5ace8: adrp    x0, #0x626b000                             
02d5acec: ldr     x0, [x0, #0xbc0]                           MS:System.Nullable`1::.ctor
02d5acf0: bl      #0x2b70db0                                 fn_2b70db0
02d5acf4: adrp    x0, #0x626b000                             
02d5acf8: ldr     x0, [x0, #0xbc8]                           MS:System.Nullable`1::get_HasValue
02d5acfc: bl      #0x2b70db0                                 fn_2b70db0
02d5ad00: adrp    x0, #0x626b000                             
02d5ad04: ldr     x0, [x0, #0xbd0]                           MS:System.Nullable`1::get_Value
02d5ad08: bl      #0x2b70db0                                 fn_2b70db0
02d5ad0c: adrp    x0, #0x626b000                             
02d5ad10: ldr     x0, [x0, #0xbd8]                           S:'{0:D2}:{1:D2}'
02d5ad14: bl      #0x2b70db0                                 fn_2b70db0
02d5ad18: mov     w8, #1                                     
02d5ad1c: strb    w8, [x21, #0x2b6]                          
02d5ad20: ldr     x0, [x20]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d5ad24: str     xzr, [sp, #8]                              
02d5ad28: bl      #0x3769600                                 fn_3769600
02d5ad2c: cbz     x0, #0x2d5afc0                             
02d5ad30: adrp    x20, #0x6266000                            
02d5ad34: mov     x1, xzr                                    
02d5ad38: ldr     x20, [x20, #0x658]                         MS:MonoSingleton`1::get_Instance
02d5ad3c: bl      #0x2cadeb8                                 PlayTimeTracker::GetSecondRoundDown
02d5ad40: ldr     x8, [x20]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d5ad44: mov     w20, w0                                    
02d5ad48: mov     x0, x8                                     
02d5ad4c: bl      #0x3769600                                 fn_3769600
02d5ad50: cbz     x0, #0x2d5afc0                             
02d5ad54: adrp    x8, #0x6266000                             
02d5ad58: ldr     x8, [x8, #0x8d0]                           MS:DataManager::GetData
02d5ad5c: ldr     x1, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d5ad60: bl      #0x3168dd0                                 fn_3168dd0
02d5ad64: ldr     x8, [x19, #0x80]                           ._loginTimeRewardConfig
02d5ad68: cbz     x8, #0x2d5afc0                             
02d5ad6c: ldr     x22, [x8, #0x18]                           S:'level_show_popuprate'
02d5ad70: cbz     x22, #0x2d5afc0                            
02d5ad74: ldr     w8, [x22, #0x18]                           
02d5ad78: cmp     w8, #1                                     
02d5ad7c: b.lt    #0x2d5ae00                                 
02d5ad80: adrp    x26, #0x6266000                            
02d5ad84: adrp    x25, #0x626b000                            
02d5ad88: mov     x21, x0                                    
02d5ad8c: ldr     x26, [x26, #0xdd8]                         MS:System.Collections.Generic.List`1::get_Item
02d5ad90: ldr     x25, [x25, #0xb30]                         MS:System.Collections.Generic.List`1::get_Item
02d5ad94: mov     w23, wzr                                   
02d5ad98: mov     w24, wzr                                   
02d5ad9c: cbz     x21, #0x2d5afc0                            
02d5ada0: ldr     x8, [x21, #0x20]                           
02d5ada4: cbz     x8, #0x2d5afc0                             
02d5ada8: ldr     x0, [x8, #0x20]                            S:'inter_ad_capping_time'
02d5adac: cbz     x0, #0x2d5afc0                             
02d5adb0: ldr     x2, [x26]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d5adb4: mov     w1, w23                                    
02d5adb8: bl      #0x4baf438                                 fn_4baf438
02d5adbc: tbnz    w0, #0, #0x2d5adec                         
02d5adc0: ldr     x2, [x25]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d5adc4: mov     x0, x22                                    
02d5adc8: mov     w1, w23                                    
02d5adcc: bl      #0x35a8f3c                                 fn_35a8f3c
02d5add0: cbz     x0, #0x2d5afc0                             
02d5add4: ldr     w8, [x0, #0x14]                            [626b014]=0 f=0,0
02d5add8: lsl     w9, w8, #6                                 
02d5addc: sub     w8, w9, w8, lsl #2                         
02d5ade0: cmp     w20, w8                                    
02d5ade4: b.lt    #0x2d5ae08                                 
02d5ade8: mov     w24, #1                                    
02d5adec: ldr     w8, [x22, #0x18]                           
02d5adf0: add     w23, w23, #1                               
02d5adf4: cmp     w23, w8                                    
02d5adf8: b.lt    #0x2d5ad9c                                 
02d5adfc: b       #0x2d5ae44                                 
02d5ae00: mov     w24, wzr                                   
02d5ae04: b       #0x2d5ae44                                 
02d5ae08: ldr     x2, [x25]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d5ae0c: mov     x0, x22                                    
02d5ae10: mov     w1, w23                                    
02d5ae14: bl      #0x35a8f3c                                 fn_35a8f3c
02d5ae18: cbz     x0, #0x2d5afc0                             
02d5ae1c: ldr     w8, [x0, #0x14]                            [626b014]=0 f=0,0
02d5ae20: mov     w9, #0x3c                                  
02d5ae24: neg     w10, w20                                   
02d5ae28: add     x0, sp, #8                                 
02d5ae2c: madd    w8, w8, w9, w10                            
02d5ae30: scvtf   s0, w8                                     
02d5ae34: adrp    x8, #0x626b000                             
02d5ae38: ldr     x8, [x8, #0xbc0]                           MS:System.Nullable`1::.ctor
02d5ae3c: ldr     x1, [x8]                                   T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d5ae40: bl      #0x38ee838                                 fn_38ee838
02d5ae44: ldr     x0, [x19, #0x60]                           ._goNoti
02d5ae48: cbz     x0, #0x2d5afc0                             
02d5ae4c: and     w1, w24, #1                                
02d5ae50: mov     x2, xzr                                    
02d5ae54: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d5ae58: ldrb    w8, [sp, #8]                               
02d5ae5c: ldr     x0, [x19, #0x68]                           ._goTimerBG
02d5ae60: cbz     w8, #0x2d5af7c                             
02d5ae64: cbz     x0, #0x2d5afc0                             
02d5ae68: mov     w1, #1                                     
02d5ae6c: mov     x2, xzr                                    
02d5ae70: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d5ae74: ldr     x0, [x19, #0x70]                           ._goTimer
02d5ae78: cbz     x0, #0x2d5afc0                             
02d5ae7c: adrp    x20, #0x626b000                            
02d5ae80: adrp    x21, #0x626b000                            
02d5ae84: mov     w1, #1                                     
02d5ae88: ldr     x20, [x20, #0xbd0]                         MS:System.Nullable`1::get_Value
02d5ae8c: ldr     x21, [x21, #0xbd8]                         S:'{0:D2}:{1:D2}'
02d5ae90: mov     x2, xzr                                    
02d5ae94: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d5ae98: ldr     x1, [x20]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d5ae9c: ldr     x19, [x19, #0x78]                          ._txtTimer
02d5aea0: add     x0, sp, #8                                 
02d5aea4: bl      #0x38ee850                                 fn_38ee850
02d5aea8: fcvtzs  w8, s0                                     
02d5aeac: mov     w22, #0x8889                               
02d5aeb0: adrp    x23, #0x6263000                            
02d5aeb4: movk    w22, #0x8888, lsl #16                      
02d5aeb8: ldr     x23, [x23, #0x970]                         &6645c70(=0)
02d5aebc: add     x1, sp, #4                                 
02d5aec0: ldr     x0, [x23, #0x48]                           &6263098(=0)
02d5aec4: smull   x9, w8, w22                                
02d5aec8: lsr     x9, x9, #0x20                              
02d5aecc: add     w8, w9, w8                                 
02d5aed0: mov     w9, #0x7f800000                            
02d5aed4: fmov    s8, w9                                     
02d5aed8: asr     w10, w8, #5                                
02d5aedc: mov     w9, #0xddde                                
02d5aee0: movk    w9, #0xfddd, lsl #16                       
02d5aee4: add     w8, w10, w8, lsr #31                       
02d5aee8: fcmp    s0, s8                                     
02d5aeec: csel    w8, w9, w8, eq                             
02d5aef0: str     w8, [sp, #4]                               
02d5aef4: bl      #0x2b70f38                                 fn_2b70f38
02d5aef8: ldr     x1, [x20]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d5aefc: mov     x20, x0                                    
02d5af00: add     x0, sp, #8                                 
02d5af04: bl      #0x38ee850                                 fn_38ee850
02d5af08: fcvtzs  w9, s0                                     
02d5af0c: mov     w8, #0x3c                                  
02d5af10: fcmp    s0, s8                                     
02d5af14: ldr     x0, [x23, #0x48]                           &6263098(=0)
02d5af18: mov     x1, sp                                     
02d5af1c: smull   x10, w9, w22                               
02d5af20: lsr     x10, x10, #0x20                            
02d5af24: add     w10, w10, w9                               
02d5af28: asr     w11, w10, #5                               
02d5af2c: add     w10, w11, w10, lsr #31                     
02d5af30: msub    w8, w10, w8, w9                            
02d5af34: mov     w9, #-8                                    
02d5af38: csel    w8, w9, w8, eq                             
02d5af3c: str     w8, [sp]                                   
02d5af40: bl      #0x2b70f38                                 fn_2b70f38
02d5af44: ldr     x8, [x21]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d5af48: mov     x2, x0                                     
02d5af4c: mov     x1, x20                                    
02d5af50: mov     x3, xzr                                    
02d5af54: mov     x0, x8                                     
02d5af58: bl      #0x4ca7720                                 System.String::Format
02d5af5c: cbz     x19, #0x2d5afc0                            
02d5af60: ldr     x8, [x19]                                  
02d5af64: mov     x1, x0                                     
02d5af68: mov     x0, x19                                    
02d5af6c: ldr     x9, [x8, #0x558]                           MS:UnityEngine.Object::Instantiate
02d5af70: ldr     x2, [x8, #0x560]                           M:ScoopGame.SelectCard::OnBtnAdUnlockClick
02d5af74: blr     x9                                         
02d5af78: b       #0x2d5afa0                                 
02d5af7c: cbz     x0, #0x2d5afc0                             
02d5af80: mov     w1, wzr                                    
02d5af84: mov     x2, xzr                                    
02d5af88: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d5af8c: ldr     x0, [x19, #0x70]                           ._goTimer
02d5af90: cbz     x0, #0x2d5afc0                             
02d5af94: mov     w1, wzr                                    
02d5af98: mov     x2, xzr                                    
02d5af9c: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d5afa0: ldp     x20, x19, [sp, #0x50]                      
02d5afa4: ldr     x30, [sp, #0x18]                           
02d5afa8: ldp     x22, x21, [sp, #0x40]                      
02d5afac: ldr     d8, [sp, #0x10]                            
02d5afb0: ldp     x24, x23, [sp, #0x30]                      
02d5afb4: ldp     x26, x25, [sp, #0x20]                      
02d5afb8: add     sp, sp, #0x60                              
02d5afbc: ret                                                
02d5afc0: bl      #0x2b7105c                                 fn_2b7105c
## GetIdSkinUnclaimed() -> int
---- LoginTimeReward.LoginTimeRewardPopup::GetIdSkinUnclaimed 0x2d5a8a4
02d5a8a4: sub     sp, sp, #0x80                              
02d5a8a8: stp     x30, x25, [sp, #0x40]                      
02d5a8ac: stp     x24, x23, [sp, #0x50]                      
02d5a8b0: stp     x22, x21, [sp, #0x60]                      
02d5a8b4: stp     x20, x19, [sp, #0x70]                      
02d5a8b8: adrp    x22, #0x6630000                            
02d5a8bc: adrp    x21, #0x6266000                            
02d5a8c0: adrp    x19, #0x6266000                            
02d5a8c4: adrp    x20, #0x6266000                            
02d5a8c8: ldr     x21, [x21, #0x648]                         T:type15061(k15)
02d5a8cc: ldrb    w8, [x22, #0x2b7]                          
02d5a8d0: ldr     x19, [x19, #0x650]                         MS:System.Collections.Generic.List`1::.ctor
02d5a8d4: ldr     x20, [x20, #0x658]                         MS:MonoSingleton`1::get_Instance
02d5a8d8: tbnz    w8, #0, #0x2d5a974                         
02d5a8dc: adrp    x0, #0x6266000                             
02d5a8e0: ldr     x0, [x0, #0x870]                           MS:DataManager::GetAsset
02d5a8e4: bl      #0x2b70db0                                 fn_2b70db0
02d5a8e8: adrp    x0, #0x6266000                             
02d5a8ec: ldr     x0, [x0, #0x878]                           MS:DataManager::GetData
02d5a8f0: bl      #0x2b70db0                                 fn_2b70db0
02d5a8f4: adrp    x0, #0x626b000                             
02d5a8f8: ldr     x0, [x0, #0xba0]                           MS:System.Collections.Generic.List`1/Enumerator::Dispose
02d5a8fc: bl      #0x2b70db0                                 fn_2b70db0
02d5a900: adrp    x0, #0x626b000                             
02d5a904: ldr     x0, [x0, #0xba8]                           MS:System.Collections.Generic.List`1/Enumerator::MoveNext
02d5a908: bl      #0x2b70db0                                 fn_2b70db0
02d5a90c: adrp    x0, #0x626b000                             
02d5a910: ldr     x0, [x0, #0xbb0]                           MS:System.Collections.Generic.List`1/Enumerator::get_Current
02d5a914: bl      #0x2b70db0                                 fn_2b70db0
02d5a918: adrp    x0, #0x6266000                             
02d5a91c: ldr     x0, [x0, #0x818]                           MS:System.Collections.Generic.List`1::Add
02d5a920: bl      #0x2b70db0                                 fn_2b70db0
02d5a924: adrp    x0, #0x626b000                             
02d5a928: ldr     x0, [x0, #0xbb8]                           MS:System.Collections.Generic.List`1::GetEnumerator
02d5a92c: bl      #0x2b70db0                                 fn_2b70db0
02d5a930: adrp    x0, #0x6266000                             
02d5a934: ldr     x0, [x0, #0x650]                           MS:System.Collections.Generic.List`1::.ctor
02d5a938: bl      #0x2b70db0                                 fn_2b70db0
02d5a93c: adrp    x0, #0x6268000                             
02d5a940: ldr     x0, [x0, #0xea8]                           MS:System.Collections.Generic.List`1::get_Count
02d5a944: bl      #0x2b70db0                                 fn_2b70db0
02d5a948: adrp    x0, #0x626a000                             
02d5a94c: ldr     x0, [x0, #0x310]                           MS:System.Collections.Generic.List`1::get_Item
02d5a950: bl      #0x2b70db0                                 fn_2b70db0
02d5a954: adrp    x0, #0x6266000                             
02d5a958: ldr     x0, [x0, #0x648]                           T:type15061(k15)
02d5a95c: bl      #0x2b70db0                                 fn_2b70db0
02d5a960: adrp    x0, #0x6266000                             
02d5a964: ldr     x0, [x0, #0x658]                           MS:MonoSingleton`1::get_Instance
02d5a968: bl      #0x2b70db0                                 fn_2b70db0
02d5a96c: mov     w8, #1                                     
02d5a970: strb    w8, [x22, #0x2b7]                          
02d5a974: ldr     x0, [x21]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d5a978: stp     xzr, xzr, [sp, #0x20]                      
02d5a97c: str     xzr, [sp, #0x30]                           
02d5a980: bl      #0x2b7104c                                 fn_2b7104c
02d5a984: ldr     x1, [x19]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d5a988: mov     x19, x0                                    
02d5a98c: bl      #0x3569388                                 fn_3569388
02d5a990: ldr     x0, [x20]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d5a994: bl      #0x3769600                                 fn_3769600
02d5a998: cbz     x0, #0x2d5ab38                             
02d5a99c: adrp    x8, #0x6266000                             
02d5a9a0: ldr     x8, [x8, #0x870]                           MS:DataManager::GetAsset
02d5a9a4: ldr     x1, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d5a9a8: bl      #0x3168af0                                 fn_3168af0
02d5a9ac: cbz     x0, #0x2d5ab38                             
02d5a9b0: mov     w1, wzr                                    
02d5a9b4: mov     x2, xzr                                    
02d5a9b8: bl      #0x2d249f4                                 Decor.DecorAsset::GetCategoryAssetByIndex
02d5a9bc: cbz     x0, #0x2d5ab38                             
02d5a9c0: ldr     x21, [x0, #0x30]                           S:'popup_rate_on_off'
02d5a9c4: ldr     x0, [x20]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d5a9c8: bl      #0x3769600                                 fn_3769600
02d5a9cc: cbz     x0, #0x2d5ab38                             
02d5a9d0: adrp    x8, #0x6266000                             
02d5a9d4: ldr     x8, [x8, #0x878]                           MS:DataManager::GetData
02d5a9d8: ldr     x1, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d5a9dc: bl      #0x3168dd0                                 fn_3168dd0
02d5a9e0: cbz     x21, #0x2d5ab38                            
02d5a9e4: adrp    x8, #0x626b000                             
02d5a9e8: adrp    x24, #0x626b000                            
02d5a9ec: adrp    x25, #0x6266000                            
02d5a9f0: ldr     x8, [x8, #0xbb8]                           MS:System.Collections.Generic.List`1::GetEnumerator
02d5a9f4: adrp    x22, #0x626a000                            
02d5a9f8: adrp    x23, #0x626b000                            
02d5a9fc: ldr     x24, [x24, #0xba8]                         MS:System.Collections.Generic.List`1/Enumerator::MoveNext
02d5aa00: ldr     x25, [x25, #0x818]                         MS:System.Collections.Generic.List`1::Add
02d5aa04: ldr     x22, [x22, #0x310]                         MS:System.Collections.Generic.List`1::get_Item
02d5aa08: ldr     x23, [x23, #0xba0]                         MS:System.Collections.Generic.List`1/Enumerator::Dispose
02d5aa0c: ldr     x1, [x8]                                   T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d5aa10: mov     x20, x0                                    
02d5aa14: add     x8, sp, #8                                 
02d5aa18: mov     x0, x21                                    
02d5aa1c: bl      #0x35a9d9c                                 fn_35a9d9c
02d5aa20: ldr     x8, [sp, #0x18]                            
02d5aa24: ldur    q0, [sp, #8]                               
02d5aa28: str     x8, [sp, #0x30]                            
02d5aa2c: add     x8, sp, #0x20                              
02d5aa30: str     q0, [sp, #0x20]                            
02d5aa34: stp     xzr, x8, [sp, #8]                          
02d5aa38: ldr     x1, [x24]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d5aa3c: add     x0, sp, #0x20                              
02d5aa40: bl      #0x4690474                                 fn_4690474
02d5aa44: tbz     w0, #0, #0x2d5aad8                         
02d5aa48: ldr     x21, [sp, #0x30]                           
02d5aa4c: cbz     x21, #0x2d5ab2c                            
02d5aa50: ldr     w8, [x21, #0x20]                           S:'inter_ad_capping_time'
02d5aa54: cbz     w8, #0x2d5aa38                             
02d5aa58: cmp     w8, #3                                     
02d5aa5c: b.eq    #0x2d5aa38                                 
02d5aa60: cbz     x20, #0x2d5ab30                            
02d5aa64: ldr     w2, [x21, #0x10]                           S:'mrec_ad_on_off'
02d5aa68: mov     x0, x20                                    
02d5aa6c: mov     w1, wzr                                    
02d5aa70: mov     x3, xzr                                    
02d5aa74: bl      #0x2d25b24                                 Decor.DataDecor::HasUnlockedItem
02d5aa78: tbnz    w0, #0, #0x2d5aa38                         
02d5aa7c: cbz     x19, #0x2d5ab34                            
02d5aa80: ldr     w10, [x19, #0x1c]                          [626601c]=0 f=0,0
02d5aa84: ldr     x8, [x19, #0x10]                           S:'mrec_ad_on_off'
02d5aa88: ldr     w1, [x21, #0x10]                           S:'mrec_ad_on_off'
02d5aa8c: ldr     x9, [x25]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d5aa90: add     w10, w10, #1                               
02d5aa94: str     w10, [x19, #0x1c]                          
02d5aa98: cbz     x8, #0x2d5ab34                             
02d5aa9c: ldrsw   x10, [x19, #0x18]                          
02d5aaa0: ldr     w11, [x8, #0x18]                           T:type57265(k15)
02d5aaa4: cmp     w10, w11                                   
02d5aaa8: b.hs    #0x2d5aac0                                 
02d5aaac: add     x8, x8, x10, lsl #2                        &626b000
02d5aab0: add     w9, w10, #1                                
02d5aab4: str     w9, [x19, #0x18]                           
02d5aab8: str     w1, [x8, #0x20]                            
02d5aabc: b       #0x2d5aa38                                 
02d5aac0: ldr     x8, [x9, #0x20]                            
02d5aac4: ldr     x8, [x8, #0xc0]                            MS:System.Runtime.CompilerServices.AsyncVoidMethodBuilder::AwaitUnsafeOnCompleted
02d5aac8: ldr     x2, [x8, #0x70]                            M:ScoopGame.CharmFlyToBasket/<>c__DisplayClass15_0::<ShowNewCharm>b__1
02d5aacc: mov     x0, x19                                    
02d5aad0: bl      #0x3569c18                                 fn_3569c18
02d5aad4: b       #0x2d5aa38                                 
02d5aad8: ldr     x1, [x23]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d5aadc: add     x0, sp, #0x20                              
02d5aae0: bl      #0x4690470                                 fn_4690470
02d5aae4: cbz     x19, #0x2d5ab38                            
02d5aae8: ldr     w1, [x19, #0x18]                           S:'level_show_popuprate'
02d5aaec: cbz     w1, #0x2d5ab10                             
02d5aaf0: mov     w0, wzr                                    
02d5aaf4: mov     x2, xzr                                    
02d5aaf8: bl      #0x5b2e000                                 UnityEngine.Random::Range
02d5aafc: ldr     x2, [x22]                                  T:type56879(k15)
02d5ab00: mov     w1, w0                                     
02d5ab04: mov     x0, x19                                    
02d5ab08: bl      #0x3569920                                 fn_3569920
02d5ab0c: b       #0x2d5ab14                                 
02d5ab10: mov     w0, #-1                                    
02d5ab14: ldp     x20, x19, [sp, #0x70]                      
02d5ab18: ldp     x22, x21, [sp, #0x60]                      
02d5ab1c: ldp     x24, x23, [sp, #0x50]                      
02d5ab20: ldp     x30, x25, [sp, #0x40]                      
02d5ab24: add     sp, sp, #0x80                              
02d5ab28: ret                                                
02d5ab2c: bl      #0x2b7105c                                 fn_2b7105c
02d5ab30: bl      #0x2b7105c                                 fn_2b7105c
02d5ab34: bl      #0x2b7105c                                 fn_2b7105c
02d5ab38: bl      #0x2b7105c                                 fn_2b7105c
02d5ab3c: b       #0x2d5ab50                                 
02d5ab40: b       #0x2d5ab50                                 
02d5ab44: b       #0x2d5ab50                                 
02d5ab48: b       #0x2d5ab50                                 
02d5ab4c: b       #0x2d5ab50                                 
02d5ab50: mov     x20, x0                                    
02d5ab54: cmp     w1, #1                                     
02d5ab58: b.ne    #0x2d5ab8c                                 
02d5ab5c: mov     x0, x20                                    
02d5ab60: bl      #0x5e90260                                 fn_5e90260
02d5ab64: ldr     x20, [x0]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d5ab68: str     x20, [sp, #8]                              
02d5ab6c: bl      #0x5e90270                                 fn_5e90270
02d5ab70: ldr     x0, [sp, #0x10]                            
02d5ab74: ldr     x1, [x23]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d5ab78: bl      #0x4690470                                 fn_4690470
02d5ab7c: cbz     x20, #0x2d5aae4                            
02d5ab80: mov     x0, x20                                    
02d5ab84: bl      #0x2b71054                                 fn_2b71054
02d5ab88: mov     x20, x0                                    
02d5ab8c: add     x0, sp, #8                                 
02d5ab90: bl      #0x27387b4                                 fn_27387b4
02d5ab94: mov     x0, x20                                    
02d5ab98: bl      #0x2c6051c                                 fn_2c6051c
02d5ab9c: bl      #0x27369b8                                 fn_27369b8
## UnlockDecorCharacterSkin(int id) -> void
---- LoginTimeReward.LoginTimeRewardPopup::UnlockDecorCharacterSkin 0x2d5aba0
02d5aba0: stp     x30, x21, [sp, #-0x20]!                    
02d5aba4: stp     x20, x19, [sp, #0x10]                      
02d5aba8: adrp    x20, #0x6630000                            
02d5abac: adrp    x21, #0x6266000                            
02d5abb0: mov     w19, w1                                    
02d5abb4: ldrb    w8, [x20, #0x2b8]                          
02d5abb8: ldr     x21, [x21, #0x658]                         MS:MonoSingleton`1::get_Instance
02d5abbc: tbnz    w8, #0, #0x2d5abe0                         
02d5abc0: adrp    x0, #0x6266000                             
02d5abc4: ldr     x0, [x0, #0x878]                           MS:DataManager::GetData
02d5abc8: bl      #0x2b70db0                                 fn_2b70db0
02d5abcc: adrp    x0, #0x6266000                             
02d5abd0: ldr     x0, [x0, #0x658]                           MS:MonoSingleton`1::get_Instance
02d5abd4: bl      #0x2b70db0                                 fn_2b70db0
02d5abd8: mov     w8, #1                                     
02d5abdc: strb    w8, [x20, #0x2b8]                          
02d5abe0: ldr     x0, [x21]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d5abe4: bl      #0x3769600                                 fn_3769600
02d5abe8: cbz     x0, #0x2d5ac18                             
02d5abec: adrp    x8, #0x6266000                             
02d5abf0: ldr     x8, [x8, #0x878]                           MS:DataManager::GetData
02d5abf4: ldr     x1, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d5abf8: bl      #0x3168dd0                                 fn_3168dd0
02d5abfc: cbz     x0, #0x2d5ac18                             
02d5ac00: mov     w2, w19                                    
02d5ac04: ldp     x20, x19, [sp, #0x10]                      
02d5ac08: mov     w1, wzr                                    
02d5ac0c: mov     x3, xzr                                    
02d5ac10: ldp     x30, x21, [sp], #0x20                      
02d5ac14: b       #0x2d259d8                                 Decor.DataDecor::UnlockItem
02d5ac18: bl      #0x2b7105c                                 fn_2b7105c
## .ctor() -> void
---- LoginTimeReward.LoginTimeRewardPopup::.ctor 0x2d5afc4
02d5afc4: mov     x1, xzr                                    
02d5afc8: b       #0x2cddba8                                 PopupBase::.ctor
## <OnBtnCloseClick>b__21_0() -> void
---- LoginTimeReward.LoginTimeRewardPopup::<OnBtnCloseClick>b__21_0 0x2d5afcc
02d5afcc: ldr     x8, [x0]                                   
02d5afd0: ldp     x2, x1, [x8, #0x198]                       
02d5afd4: br      x2                                         
