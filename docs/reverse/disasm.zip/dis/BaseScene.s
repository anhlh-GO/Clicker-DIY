#### CLASS BaseScene parent= UnityEngine.MonoBehaviour
## Update() -> void
---- BaseScene::Update 0x2c84bf8
02c84bf8: str     x30, [sp, #-0x20]!                         
02c84bfc: stp     x20, x19, [sp, #0x10]                      
02c84c00: adrp    x20, #0x662f000                            
02c84c04: adrp    x19, #0x6264000                            
02c84c08: ldrb    w8, [x20, #0x928]                          
02c84c0c: ldr     x19, [x19, #0xa70]                         T:UnityEngine.Application
02c84c10: tbnz    w8, #0, #0x2c84c28                         
02c84c14: adrp    x0, #0x6264000                             
02c84c18: ldr     x0, [x0, #0xa70]                           T:UnityEngine.Application
02c84c1c: bl      #0x2b70db0                                 fn_2b70db0
02c84c20: mov     w8, #1                                     
02c84c24: strb    w8, [x20, #0x928]                          
02c84c28: ldr     x0, [x19]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c84c2c: ldr     w8, [x0, #0xe4]                            [62640e4]=0 f=0,0
02c84c30: cbnz    w8, #0x2c84c38                             
02c84c34: bl      #0x2b70f30                                 fn_2b70f30
02c84c38: mov     x0, xzr                                    
02c84c3c: bl      #0x5aeb18c                                 UnityEngine.Application::get_platform
02c84c40: cmp     w0, #0xb                                   
02c84c44: b.ne    #0x2c84c78                                 
02c84c48: mov     w0, #0x1b                                  
02c84c4c: mov     x1, xzr                                    
02c84c50: bl      #0x5bb7cc0                                 UnityEngine.Input::GetKey
02c84c54: tbz     w0, #0, #0x2c84c78                         
02c84c58: ldr     x0, [x19]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c84c5c: ldr     w8, [x0, #0xe4]                            [62640e4]=0 f=0,0
02c84c60: cbnz    w8, #0x2c84c68                             
02c84c64: bl      #0x2b70f30                                 fn_2b70f30
02c84c68: ldp     x20, x19, [sp, #0x10]                      
02c84c6c: mov     x0, xzr                                    
02c84c70: ldr     x30, [sp], #0x20                           
02c84c74: b       #0x5aea3c8                                 UnityEngine.Application::Quit
02c84c78: ldp     x20, x19, [sp, #0x10]                      
02c84c7c: ldr     x30, [sp], #0x20                           
02c84c80: ret                                                
## LoadSettingsScene() -> void
---- BaseScene::LoadSettingsScene 0x2c84c84
02c84c84: str     x30, [sp, #-0x20]!                         
02c84c88: stp     x20, x19, [sp, #0x10]                      
02c84c8c: adrp    x20, #0x662f000                            
02c84c90: adrp    x19, #0x6264000                            
02c84c94: ldrb    w8, [x20, #0x929]                          
02c84c98: ldr     x19, [x19, #0xb58]                         T:UnityEngine.SceneManagement.SceneManager
02c84c9c: tbnz    w8, #0, #0x2c84cc0                         
02c84ca0: adrp    x0, #0x6264000                             
02c84ca4: ldr     x0, [x0, #0xb58]                           T:UnityEngine.SceneManagement.SceneManager
02c84ca8: bl      #0x2b70db0                                 fn_2b70db0
02c84cac: adrp    x0, #0x6264000                             
02c84cb0: ldr     x0, [x0, #0xbb0]                           S:'SettingsScene'
02c84cb4: bl      #0x2b70db0                                 fn_2b70db0
02c84cb8: mov     w8, #1                                     
02c84cbc: strb    w8, [x20, #0x929]                          
02c84cc0: ldr     x0, [x19]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c84cc4: adrp    x19, #0x6264000                            
02c84cc8: ldr     w8, [x0, #0xe4]                            [62640e4]=0 f=0,0
02c84ccc: ldr     x19, [x19, #0xbb0]                         S:'SettingsScene'
02c84cd0: cbnz    w8, #0x2c84cd8                             
02c84cd4: bl      #0x2b70f30                                 fn_2b70f30
02c84cd8: ldr     x0, [x19]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c84cdc: ldp     x20, x19, [sp, #0x10]                      
02c84ce0: mov     x1, xzr                                    
02c84ce4: ldr     x30, [sp], #0x20                           
02c84ce8: b       #0x5b4f55c                                 UnityEngine.SceneManagement.SceneManager::LoadScene
## .ctor() -> void
---- BaseScene::.ctor 0x2c848d8
02c848d8: mov     x1, xzr                                    
02c848dc: b       #0x5b397b0                                 UnityEngine.MonoBehaviour::.ctor
