#### CLASS DailyTask.DataDailyTask/TaskProgress parent= object
#   field TaskId                         int                                                off=0x10 attr=6 
#   field ProgressValue                  int                                                off=0x14 attr=6 
#   field RewardValue                    int                                                off=0x18 attr=6 
## .ctor() -> void
---- DailyTask.DataDailyTask/TaskProgress::.ctor 0x2d2c480
02d2c480: mov     x1, xzr                                    
02d2c484: b       #0x4e53e9c                                 System.Object::.ctor
#### CLASS DailyTask.DataDailyTask/DataSaveDailyTask parent= object
#   field IsFirstTime                    bool                                               off=0x10 attr=6 
#   field LastLoginDateString            string                                             off=0x18 attr=6 
#   field CompletedTasks                 System.Collections.Generic.List`1<DailyTask.DataDailyTask/TaskProgress> off=0x20 attr=6 
#   field InprogressTasks                System.Collections.Generic.List`1<DailyTask.DataDailyTask/TaskProgress> off=0x28 attr=6 
## .ctor() -> void
---- DailyTask.DataDailyTask/DataSaveDailyTask::.ctor 0x2d2c308
02d2c308: mov     x1, xzr                                    
02d2c30c: b       #0x4e53e9c                                 System.Object::.ctor
#### CLASS DailyTask.DataDailyTask/<>c__DisplayClass18_0 parent= object
#   field taskId                         int                                                off=0x10 attr=6 
## .ctor() -> void
---- DailyTask.DataDailyTask/<>c__DisplayClass18_0::.ctor 0x2d2c468
02d2c468: mov     x1, xzr                                    
02d2c46c: b       #0x4e53e9c                                 System.Object::.ctor
## <IsValidTask>b__0(DailyTask.Mission x) -> bool
---- DailyTask.DataDailyTask/<>c__DisplayClass18_0::<IsValidTask>b__0 0x2d2c4a0
02d2c4a0: cbz     x1, #0x2d2c4b8                             
02d2c4a4: ldr     w8, [x1, #0x10]                            
02d2c4a8: ldr     w9, [x0, #0x10]                            .taskId
02d2c4ac: cmp     w8, w9                                     
02d2c4b0: cset    w0, eq                                     
02d2c4b4: ret                                                
02d2c4b8: str     x30, [sp, #-0x10]!                         
02d2c4bc: bl      #0x2b7105c                                 fn_2b7105c
#### CLASS DailyTask.DataDailyTask/<>c__DisplayClass20_0 parent= object
#   field taskId                         int                                                off=0x10 attr=6 
## .ctor() -> void
---- DailyTask.DataDailyTask/<>c__DisplayClass20_0::.ctor 0x2d2c470
02d2c470: mov     x1, xzr                                    
02d2c474: b       #0x4e53e9c                                 System.Object::.ctor
## <IsTaskCompleted>b__0(DailyTask.DataDailyTask/TaskProgress task) -> bool
---- DailyTask.DataDailyTask/<>c__DisplayClass20_0::<IsTaskCompleted>b__0 0x2d2c4c0
02d2c4c0: cbz     x1, #0x2d2c4d8                             
02d2c4c4: ldr     w8, [x1, #0x10]                            
02d2c4c8: ldr     w9, [x0, #0x10]                            .taskId
02d2c4cc: cmp     w8, w9                                     
02d2c4d0: cset    w0, eq                                     
02d2c4d4: ret                                                
02d2c4d8: str     x30, [sp, #-0x10]!                         
02d2c4dc: bl      #0x2b7105c                                 fn_2b7105c
#### CLASS DailyTask.DataDailyTask/<>c__DisplayClass21_0 parent= object
#   field taskId                         int                                                off=0x10 attr=6 
## .ctor() -> void
---- DailyTask.DataDailyTask/<>c__DisplayClass21_0::.ctor 0x2d2c478
02d2c478: mov     x1, xzr                                    
02d2c47c: b       #0x4e53e9c                                 System.Object::.ctor
## <AddCompletedTask>b__0(DailyTask.DataDailyTask/TaskProgress task) -> bool
---- DailyTask.DataDailyTask/<>c__DisplayClass21_0::<AddCompletedTask>b__0 0x2d2c4e0
02d2c4e0: cbz     x1, #0x2d2c4f8                             
02d2c4e4: ldr     w8, [x1, #0x10]                            
02d2c4e8: ldr     w9, [x0, #0x10]                            .taskId
02d2c4ec: cmp     w8, w9                                     
02d2c4f0: cset    w0, eq                                     
02d2c4f4: ret                                                
02d2c4f8: str     x30, [sp, #-0x10]!                         
02d2c4fc: bl      #0x2b7105c                                 fn_2b7105c
#### CLASS DailyTask.DataDailyTask/<>c__DisplayClass23_0 parent= object
#   field taskId                         int                                                off=0x10 attr=6 
## .ctor() -> void
---- DailyTask.DataDailyTask/<>c__DisplayClass23_0::.ctor 0x2d2c488
02d2c488: mov     x1, xzr                                    
02d2c48c: b       #0x4e53e9c                                 System.Object::.ctor
## <UpdateInProgressTask>b__0(DailyTask.DataDailyTask/TaskProgress task) -> bool
---- DailyTask.DataDailyTask/<>c__DisplayClass23_0::<UpdateInProgressTask>b__0 0x2d2c500
02d2c500: cbz     x1, #0x2d2c518                             
02d2c504: ldr     w8, [x1, #0x10]                            
02d2c508: ldr     w9, [x0, #0x10]                            .taskId
02d2c50c: cmp     w8, w9                                     
02d2c510: cset    w0, eq                                     
02d2c514: ret                                                
02d2c518: str     x30, [sp, #-0x10]!                         
02d2c51c: bl      #0x2b7105c                                 fn_2b7105c
#### CLASS DailyTask.DataDailyTask/<>c__DisplayClass24_0 parent= object
#   field taskId                         int                                                off=0x10 attr=6 
## .ctor() -> void
---- DailyTask.DataDailyTask/<>c__DisplayClass24_0::.ctor 0x2d2c490
02d2c490: mov     x1, xzr                                    
02d2c494: b       #0x4e53e9c                                 System.Object::.ctor
## <GetProgressOfTask>b__0(DailyTask.DataDailyTask/TaskProgress task) -> bool
---- DailyTask.DataDailyTask/<>c__DisplayClass24_0::<GetProgressOfTask>b__0 0x2d2c520
02d2c520: cbz     x1, #0x2d2c538                             
02d2c524: ldr     w8, [x1, #0x10]                            
02d2c528: ldr     w9, [x0, #0x10]                            .taskId
02d2c52c: cmp     w8, w9                                     
02d2c530: cset    w0, eq                                     
02d2c534: ret                                                
02d2c538: str     x30, [sp, #-0x10]!                         
02d2c53c: bl      #0x2b7105c                                 fn_2b7105c
#### CLASS DailyTask.DataDailyTask parent= GameData
#   field _dataSave                      DailyTask.DataDailyTask/DataSaveDailyTask          off=0x20 attr=1 SerializeField
#   field _timeTracker                   float                                              off=0x28 attr=1 
#   field TIME_UPDATE_INTERVAL           float                                              off=0x0 attr=8051 
## get_DataSave() -> DailyTask.DataDailyTask/DataSaveDailyTask
---- DailyTask.DataDailyTask::get_DataSave 0x2d2bfd0
02d2bfd0: ldr     x0, [x0, #0x20]                            ._dataSave
02d2bfd4: ret                                                
## set_DataSave(DailyTask.DataDailyTask/DataSaveDailyTask value) -> void
---- DailyTask.DataDailyTask::set_DataSave 0x2d2bfd8
02d2bfd8: str     x1, [x0, #0x20]!                           ._dataSave
02d2bfdc: b       #0x2b70d54                                 
## Update() -> void
---- DailyTask.DataDailyTask::Update 0x2d2bfe0
02d2bfe0: str     d8, [sp, #-0x30]!                          
02d2bfe4: stp     x30, x21, [sp, #0x10]                      
02d2bfe8: stp     x20, x19, [sp, #0x20]                      
02d2bfec: adrp    x20, #0x6630000                            
02d2bff0: mov     x19, x0                                    
02d2bff4: ldrb    w8, [x20, #0xbe]                           
02d2bff8: tbnz    w8, #0, #0x2d2c01c                         
02d2bffc: adrp    x0, #0x6266000                             
02d2c000: ldr     x0, [x0, #0x5e0]                           T:GameConfig
02d2c004: bl      #0x2b70db0                                 fn_2b70db0
02d2c008: adrp    x0, #0x6267000                             
02d2c00c: ldr     x0, [x0, #0xbb0]                           MS:MonoSingleton`1::get_Instance
02d2c010: bl      #0x2b70db0                                 fn_2b70db0
02d2c014: mov     w8, #1                                     
02d2c018: strb    w8, [x20, #0xbe]                           
02d2c01c: ldr     s8, [x19, #0x28]                           ._timeTracker
02d2c020: mov     x0, xzr                                    
02d2c024: bl      #0x5b433a4                                 UnityEngine.Time::get_deltaTime
02d2c028: fadd    s0, s8, s0                                 
02d2c02c: mov     w8, #0x42700000                            
02d2c030: fmov    s1, w8                                     
02d2c034: fcmp    s0, s1                                     
02d2c038: str     s0, [x19, #0x28]                           ._timeTracker
02d2c03c: b.ge    #0x2d2c050                                 
02d2c040: ldp     x20, x19, [sp, #0x20]                      
02d2c044: ldp     x30, x21, [sp, #0x10]                      
02d2c048: ldr     d8, [sp], #0x30                            
02d2c04c: ret                                                
02d2c050: adrp    x21, #0x6267000                            
02d2c054: adrp    x20, #0x6266000                            
02d2c058: ldr     x21, [x21, #0xbb0]                         MS:MonoSingleton`1::get_Instance
02d2c05c: ldr     x20, [x20, #0x5e0]                         T:GameConfig
02d2c060: str     wzr, [x19, #0x28]                          ._timeTracker
02d2c064: ldr     x0, [x21]                                  S:'didu'
02d2c068: bl      #0x3769600                                 fn_3769600
02d2c06c: ldr     x8, [x20]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d2c070: mov     x19, x0                                    
02d2c074: ldr     w9, [x8, #0xe4]                            
02d2c078: cbnz    w9, #0x2d2c084                             
02d2c07c: mov     x0, x8                                     
02d2c080: bl      #0x2b70f30                                 fn_2b70f30
02d2c084: cbz     x19, #0x2d2c0cc                            
02d2c088: ldr     x8, [x20]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d2c08c: mov     x0, x19                                    
02d2c090: mov     w2, #1                                     
02d2c094: ldr     x8, [x8, #0xb8]                            
02d2c098: ldr     w1, [x8, #0xac]                            
02d2c09c: bl      #0x2d28eec                                 DailyTask.DailyTaskController::ProgressTask
02d2c0a0: ldr     x0, [x21]                                  S:'didu'
02d2c0a4: bl      #0x3769600                                 fn_3769600
02d2c0a8: cbz     x0, #0x2d2c0cc                             
02d2c0ac: ldr     x8, [x20]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d2c0b0: ldp     x20, x19, [sp, #0x20]                      
02d2c0b4: ldp     x30, x21, [sp, #0x10]                      
02d2c0b8: mov     w2, #1                                     
02d2c0bc: ldr     x8, [x8, #0xb8]                            
02d2c0c0: ldr     w1, [x8, #0xb8]                            
02d2c0c4: ldr     d8, [sp], #0x30                            
02d2c0c8: b       #0x2d28eec                                 DailyTask.DailyTaskController::ProgressTask
02d2c0cc: bl      #0x2b7105c                                 fn_2b7105c
## SaveData() -> void
---- DailyTask.DataDailyTask::SaveData 0x2d2c0d0
02d2c0d0: stp     x30, x21, [sp, #-0x20]!                    
02d2c0d4: stp     x20, x19, [sp, #0x10]                      
02d2c0d8: adrp    x20, #0x6630000                            
02d2c0dc: adrp    x21, #0x6266000                            
02d2c0e0: mov     x19, x0                                    
02d2c0e4: ldrb    w8, [x20, #0xbf]                           
02d2c0e8: ldr     x21, [x21, #0x658]                         MS:MonoSingleton`1::get_Instance
02d2c0ec: tbnz    w8, #0, #0x2d2c110                         
02d2c0f0: adrp    x0, #0x626a000                             
02d2c0f4: ldr     x0, [x0, #0x468]                           MS:DataManager::SaveData
02d2c0f8: bl      #0x2b70db0                                 fn_2b70db0
02d2c0fc: adrp    x0, #0x6266000                             
02d2c100: ldr     x0, [x0, #0x658]                           MS:MonoSingleton`1::get_Instance
02d2c104: bl      #0x2b70db0                                 fn_2b70db0
02d2c108: mov     w8, #1                                     
02d2c10c: strb    w8, [x20, #0xbf]                           
02d2c110: ldr     x0, [x21]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d2c114: bl      #0x3769600                                 fn_3769600
02d2c118: ldr     x8, [x19]                                  
02d2c11c: mov     x20, x0                                    
02d2c120: mov     x0, x19                                    
02d2c124: ldr     x9, [x8, #0x2a8]                           
02d2c128: ldr     x1, [x8, #0x2b0]                           
02d2c12c: blr     x9                                         
02d2c130: cbz     x20, #0x2d2c158                            
02d2c134: adrp    x8, #0x626a000                             
02d2c138: mov     x1, x0                                     
02d2c13c: mov     x0, x20                                    
02d2c140: ldr     x8, [x8, #0x468]                           MS:DataManager::SaveData
02d2c144: ldr     x2, [x19, #0x20]                           ._dataSave
02d2c148: ldp     x20, x19, [sp, #0x10]                      
02d2c14c: ldr     x3, [x8]                                   T:type56879(k15)
02d2c150: ldp     x30, x21, [sp], #0x20                      
02d2c154: b       #0x3169790                                 
02d2c158: bl      #0x2b7105c                                 fn_2b7105c
## LoadData() -> void
---- DailyTask.DataDailyTask::LoadData 0x2d2c15c
02d2c15c: stp     x30, x21, [sp, #-0x20]!                    
02d2c160: stp     x20, x19, [sp, #0x10]                      
02d2c164: adrp    x20, #0x6630000                            
02d2c168: adrp    x21, #0x6266000                            
02d2c16c: mov     x19, x0                                    
02d2c170: ldrb    w8, [x20, #0xc0]                           
02d2c174: ldr     x21, [x21, #0x658]                         MS:MonoSingleton`1::get_Instance
02d2c178: tbnz    w8, #0, #0x2d2c19c                         
02d2c17c: adrp    x0, #0x626a000                             
02d2c180: ldr     x0, [x0, #0x470]                           MS:DataManager::LoadData
02d2c184: bl      #0x2b70db0                                 fn_2b70db0
02d2c188: adrp    x0, #0x6266000                             
02d2c18c: ldr     x0, [x0, #0x658]                           MS:MonoSingleton`1::get_Instance
02d2c190: bl      #0x2b70db0                                 fn_2b70db0
02d2c194: mov     w8, #1                                     
02d2c198: strb    w8, [x20, #0xc0]                           
02d2c19c: ldr     x0, [x21]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d2c1a0: bl      #0x3769600                                 fn_3769600
02d2c1a4: ldr     x8, [x19]                                  
02d2c1a8: mov     x20, x0                                    
02d2c1ac: mov     x0, x19                                    
02d2c1b0: ldr     x9, [x8, #0x2a8]                           
02d2c1b4: ldr     x1, [x8, #0x2b0]                           
02d2c1b8: blr     x9                                         
02d2c1bc: cbz     x20, #0x2d2c1f0                            
02d2c1c0: adrp    x8, #0x626a000                             
02d2c1c4: mov     x1, x0                                     
02d2c1c8: mov     x0, x20                                    
02d2c1cc: ldr     x8, [x8, #0x470]                           MS:DataManager::LoadData
02d2c1d0: ldr     x2, [x8]                                   T:type56879(k15)
02d2c1d4: bl      #0x31690b0                                 fn_31690b0
02d2c1d8: str     x0, [x19, #0x20]!                          ._dataSave
02d2c1dc: mov     x1, x0                                     
02d2c1e0: mov     x0, x19                                    
02d2c1e4: ldp     x20, x19, [sp, #0x10]                      
02d2c1e8: ldp     x30, x21, [sp], #0x20                      
02d2c1ec: b       #0x2b70d54                                 
02d2c1f0: bl      #0x2b7105c                                 fn_2b7105c
## NewData() -> void
---- DailyTask.DataDailyTask::NewData 0x2d2c1f4
02d2c1f4: stp     x30, x23, [sp, #-0x30]!                    
02d2c1f8: stp     x22, x21, [sp, #0x10]                      
02d2c1fc: stp     x20, x19, [sp, #0x20]                      
02d2c200: adrp    x21, #0x6630000                            
02d2c204: adrp    x20, #0x626a000                            
02d2c208: mov     x19, x0                                    
02d2c20c: ldrb    w8, [x21, #0xc1]                           
02d2c210: ldr     x20, [x20, #0x348]                         T:DailyTask.DataDailyTask/DataSaveDailyTask
02d2c214: tbnz    w8, #0, #0x2d2c244                         
02d2c218: adrp    x0, #0x626a000                             
02d2c21c: ldr     x0, [x0, #0x348]                           T:DailyTask.DataDailyTask/DataSaveDailyTask
02d2c220: bl      #0x2b70db0                                 fn_2b70db0
02d2c224: adrp    x0, #0x626a000                             
02d2c228: ldr     x0, [x0, #0x330]                           MS:System.Collections.Generic.List`1::.ctor
02d2c22c: bl      #0x2b70db0                                 fn_2b70db0
02d2c230: adrp    x0, #0x626a000                             
02d2c234: ldr     x0, [x0, #0x328]                           T:type15589(k15)
02d2c238: bl      #0x2b70db0                                 fn_2b70db0
02d2c23c: mov     w8, #1                                     
02d2c240: strb    w8, [x21, #0xc1]                           
02d2c244: mov     x0, x19                                    
02d2c248: mov     x1, xzr                                    
02d2c24c: bl      #0x2cac6e0                                 GameData::NewData
02d2c250: ldr     x0, [x20]                                  T:type56879(k15)
02d2c254: bl      #0x2b7104c                                 fn_2b7104c
02d2c258: mov     x1, xzr                                    
02d2c25c: mov     x20, x0                                    
02d2c260: bl      #0x4e53e9c                                 System.Object::.ctor
02d2c264: cbz     x20, #0x2d2c304                            
02d2c268: adrp    x22, #0x626a000                            
02d2c26c: adrp    x23, #0x626a000                            
02d2c270: mov     w8, #1                                     
02d2c274: ldr     x22, [x22, #0x328]                         T:type15589(k15)
02d2c278: ldr     x23, [x23, #0x330]                         MS:System.Collections.Generic.List`1::.ctor
02d2c27c: strb    w8, [x20, #0x10]                           
02d2c280: ldr     x0, [x22]                                  T:type56879(k15)
02d2c284: bl      #0x2b7104c                                 fn_2b7104c
02d2c288: ldr     x1, [x23]                                  T:type56879(k15)
02d2c28c: mov     x21, x0                                    
02d2c290: bl      #0x35a89a4                                 fn_35a89a4
02d2c294: mov     x0, x20                                    
02d2c298: mov     x1, x21                                    
02d2c29c: str     x21, [x0, #0x28]!                          ._timeTracker
02d2c2a0: bl      #0x2b70d54                                 fn_2b70d54
02d2c2a4: ldr     x0, [x22]                                  T:type56879(k15)
02d2c2a8: bl      #0x2b7104c                                 fn_2b7104c
02d2c2ac: ldr     x1, [x23]                                  T:type56879(k15)
02d2c2b0: mov     x21, x0                                    
02d2c2b4: bl      #0x35a89a4                                 fn_35a89a4
02d2c2b8: mov     x0, x20                                    
02d2c2bc: mov     x1, x21                                    
02d2c2c0: str     x21, [x0, #0x20]!                          ._dataSave
02d2c2c4: bl      #0x2b70d54                                 fn_2b70d54
02d2c2c8: adrp    x8, #0x6263000                             
02d2c2cc: mov     x0, x20                                    
02d2c2d0: ldr     x8, [x8, #0x970]                           &6645c70(=0)
02d2c2d4: ldr     x8, [x8, #0x90]                            &2c5beb4(=14c8d222d503245f)
02d2c2d8: ldr     x8, [x8, #0xb8]                            &6263108(=0)
02d2c2dc: ldr     x1, [x8]                                   &2c5bbd4(=a9bd7bfdd503233f)
02d2c2e0: str     x1, [x0, #0x18]!                           
02d2c2e4: bl      #0x2b70d54                                 fn_2b70d54
02d2c2e8: str     x20, [x19, #0x20]!                         ._dataSave
02d2c2ec: mov     x0, x19                                    
02d2c2f0: mov     x1, x20                                    
02d2c2f4: ldp     x20, x19, [sp, #0x20]                      
02d2c2f8: ldp     x22, x21, [sp, #0x10]                      
02d2c2fc: ldp     x30, x23, [sp], #0x30                      
02d2c300: b       #0x2b70d54                                 
02d2c304: bl      #0x2b7105c                                 fn_2b7105c
## ResetForNewDay() -> void
---- DailyTask.DataDailyTask::ResetForNewDay 0x2d2a8b0
02d2a8b0: stp     x30, x23, [sp, #-0x30]!                    
02d2a8b4: stp     x22, x21, [sp, #0x10]                      
02d2a8b8: stp     x20, x19, [sp, #0x20]                      
02d2a8bc: adrp    x20, #0x6630000                            
02d2a8c0: mov     x19, x0                                    
02d2a8c4: ldrb    w8, [x20, #0xc2]                           
02d2a8c8: tbnz    w8, #0, #0x2d2a8f8                         
02d2a8cc: adrp    x0, #0x626a000                             
02d2a8d0: ldr     x0, [x0, #0x348]                           T:DailyTask.DataDailyTask/DataSaveDailyTask
02d2a8d4: bl      #0x2b70db0                                 fn_2b70db0
02d2a8d8: adrp    x0, #0x626a000                             
02d2a8dc: ldr     x0, [x0, #0x330]                           MS:System.Collections.Generic.List`1::.ctor
02d2a8e0: bl      #0x2b70db0                                 fn_2b70db0
02d2a8e4: adrp    x0, #0x626a000                             
02d2a8e8: ldr     x0, [x0, #0x328]                           T:type15589(k15)
02d2a8ec: bl      #0x2b70db0                                 fn_2b70db0
02d2a8f0: mov     w8, #1                                     
02d2a8f4: strb    w8, [x20, #0xc2]                           
02d2a8f8: ldr     x8, [x19, #0x20]!                          ._dataSave
02d2a8fc: cbz     x8, #0x2d2a9bc                             
02d2a900: adrp    x9, #0x626a000                             
02d2a904: ldr     x9, [x9, #0x348]                           T:DailyTask.DataDailyTask/DataSaveDailyTask
02d2a908: ldrb    w21, [x8, #0x10]                           
02d2a90c: ldr     x0, [x9]                                   T:type56879(k15)
02d2a910: bl      #0x2b7104c                                 fn_2b7104c
02d2a914: mov     x1, xzr                                    
02d2a918: mov     x20, x0                                    
02d2a91c: bl      #0x4e53e9c                                 System.Object::.ctor
02d2a920: cbz     x20, #0x2d2a9bc                            
02d2a924: adrp    x22, #0x626a000                            
02d2a928: adrp    x23, #0x626a000                            
02d2a92c: ldr     x22, [x22, #0x328]                         T:type15589(k15)
02d2a930: ldr     x23, [x23, #0x330]                         MS:System.Collections.Generic.List`1::.ctor
02d2a934: strb    w21, [x20, #0x10]                          
02d2a938: ldr     x0, [x22]                                  T:type56879(k15)
02d2a93c: bl      #0x2b7104c                                 fn_2b7104c
02d2a940: ldr     x1, [x23]                                  T:type56879(k15)
02d2a944: mov     x21, x0                                    
02d2a948: bl      #0x35a89a4                                 fn_35a89a4
02d2a94c: mov     x0, x20                                    
02d2a950: mov     x1, x21                                    
02d2a954: str     x21, [x0, #0x28]!                          ._timeTracker
02d2a958: bl      #0x2b70d54                                 fn_2b70d54
02d2a95c: ldr     x0, [x22]                                  T:type56879(k15)
02d2a960: bl      #0x2b7104c                                 fn_2b7104c
02d2a964: ldr     x1, [x23]                                  T:type56879(k15)
02d2a968: mov     x21, x0                                    
02d2a96c: bl      #0x35a89a4                                 fn_35a89a4
02d2a970: mov     x0, x20                                    
02d2a974: mov     x1, x21                                    
02d2a978: str     x21, [x0, #0x20]!                          ._dataSave
02d2a97c: bl      #0x2b70d54                                 fn_2b70d54
02d2a980: adrp    x8, #0x6263000                             
02d2a984: mov     x0, x20                                    
02d2a988: ldr     x8, [x8, #0x970]                           &6645c70(=0)
02d2a98c: ldr     x8, [x8, #0x90]                            &2c5beb4(=14c8d222d503245f)
02d2a990: ldr     x8, [x8, #0xb8]                            &6263108(=0)
02d2a994: ldr     x1, [x8]                                   &2c5bbd4(=a9bd7bfdd503233f)
02d2a998: str     x1, [x0, #0x18]!                           
02d2a99c: bl      #0x2b70d54                                 fn_2b70d54
02d2a9a0: mov     x0, x19                                    
02d2a9a4: mov     x1, x20                                    
02d2a9a8: str     x20, [x19]                                 
02d2a9ac: ldp     x20, x19, [sp, #0x20]                      
02d2a9b0: ldp     x22, x21, [sp, #0x10]                      
02d2a9b4: ldp     x30, x23, [sp], #0x30                      
02d2a9b8: b       #0x2b70d54                                 
02d2a9bc: bl      #0x2b7105c                                 fn_2b7105c
## SetFirstTime(bool isFirstTime) -> void
---- DailyTask.DataDailyTask::SetFirstTime 0x2d2c310
02d2c310: ldr     x8, [x0, #0x20]                            ._dataSave
02d2c314: cbz     x8, #0x2d2c330                             
02d2c318: and     w9, w1, #1                                 
02d2c31c: strb    w9, [x8, #0x10]                            
02d2c320: ldr     x8, [x0]                                   
02d2c324: ldr     x1, [x8, #0x260]                           
02d2c328: ldr     x2, [x8, #0x258]                           
02d2c32c: br      x2                                         
02d2c330: str     x30, [sp, #-0x10]!                         
02d2c334: bl      #0x2b7105c                                 fn_2b7105c
## IsFirstTime() -> bool
---- DailyTask.DataDailyTask::IsFirstTime 0x2d2c338
02d2c338: ldr     x8, [x0, #0x20]                            ._dataSave
02d2c33c: cbz     x8, #0x2d2c348                             
02d2c340: ldrb    w0, [x8, #0x10]                            
02d2c344: ret                                                
02d2c348: str     x30, [sp, #-0x10]!                         
02d2c34c: bl      #0x2b7105c                                 fn_2b7105c
## GetLastLoginDate() -> System.DateTime
---- DailyTask.DataDailyTask::GetLastLoginDate 0x2d2a50c
02d2a50c: str     x30, [sp, #-0x20]!                         
02d2a510: stp     x20, x19, [sp, #0x10]                      
02d2a514: adrp    x20, #0x6630000                            
02d2a518: mov     x19, x0                                    
02d2a51c: ldrb    w8, [x20, #0xc3]                           
02d2a520: tbnz    w8, #0, #0x2d2a538                         
02d2a524: adrp    x0, #0x6266000                             
02d2a528: ldr     x0, [x0, #0x128]                           T:System.DateTime
02d2a52c: bl      #0x2b70db0                                 fn_2b70db0
02d2a530: mov     w8, #1                                     
02d2a534: strb    w8, [x20, #0xc3]                           
02d2a538: ldr     x8, [x19, #0x20]                           ._dataSave
02d2a53c: cbz     x8, #0x2d2a5b8                             
02d2a540: ldr     x0, [x8, #0x18]                            
02d2a544: mov     x1, xzr                                    
02d2a548: bl      #0x4ca6234                                 System.String::IsNullOrEmpty
02d2a54c: tbz     w0, #0, #0x2d2a580                         
02d2a550: adrp    x19, #0x6266000                            
02d2a554: ldr     x19, [x19, #0x128]                         T:System.DateTime
02d2a558: ldr     x0, [x19]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d2a55c: ldr     w8, [x0, #0xe4]                            [62660e4]=0 f=0,0
02d2a560: cbnz    w8, #0x2d2a56c                             
02d2a564: bl      #0x2b70f30                                 fn_2b70f30
02d2a568: ldr     x0, [x19]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d2a56c: ldr     x8, [x0, #0xb8]                            S:'banner_native_refresh_time'
02d2a570: ldp     x20, x19, [sp, #0x10]                      
02d2a574: ldr     x0, [x8, #0x10]                            
02d2a578: ldr     x30, [sp], #0x20                           
02d2a57c: ret                                                
02d2a580: ldr     x8, [x19, #0x20]                           S:'inter_ad_capping_time' ._dataSave
02d2a584: cbz     x8, #0x2d2a5b8                             
02d2a588: adrp    x9, #0x6266000                             
02d2a58c: ldr     x9, [x9, #0x128]                           T:System.DateTime
02d2a590: ldr     x19, [x8, #0x18]                           
02d2a594: ldr     x0, [x9]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d2a598: ldr     w9, [x0, #0xe4]                            [62660e4]=0 f=0,0
02d2a59c: cbnz    w9, #0x2d2a5a4                             
02d2a5a0: bl      #0x2b70f30                                 fn_2b70f30
02d2a5a4: mov     x0, x19                                    
02d2a5a8: ldp     x20, x19, [sp, #0x10]                      
02d2a5ac: mov     x1, xzr                                    
02d2a5b0: ldr     x30, [sp], #0x20                           
02d2a5b4: b       #0x4df2914                                 System.DateTime::Parse
02d2a5b8: bl      #0x2b7105c                                 fn_2b7105c
## SaveLastLoginDate() -> void
---- DailyTask.DataDailyTask::SaveLastLoginDate 0x2d2a5bc
02d2a5bc: sub     sp, sp, #0x30                              
02d2a5c0: stp     x30, x21, [sp, #0x10]                      
02d2a5c4: stp     x20, x19, [sp, #0x20]                      
02d2a5c8: adrp    x21, #0x6630000                            
02d2a5cc: adrp    x20, #0x6266000                            
02d2a5d0: mov     x19, x0                                    
02d2a5d4: ldrb    w8, [x21, #0xc4]                           
02d2a5d8: ldr     x20, [x20, #0x128]                         T:System.DateTime
02d2a5dc: tbnz    w8, #0, #0x2d2a5f4                         
02d2a5e0: adrp    x0, #0x6266000                             
02d2a5e4: ldr     x0, [x0, #0x128]                           T:System.DateTime
02d2a5e8: bl      #0x2b70db0                                 fn_2b70db0
02d2a5ec: mov     w8, #1                                     
02d2a5f0: strb    w8, [x21, #0xc4]                           
02d2a5f4: ldr     x0, [x20]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d2a5f8: ldr     x20, [x19, #0x20]                          ._dataSave
02d2a5fc: str     xzr, [sp, #8]                              
02d2a600: ldr     w8, [x0, #0xe4]                            [62660e4]=0 f=0,0
02d2a604: cbnz    w8, #0x2d2a60c                             
02d2a608: bl      #0x2b70f30                                 fn_2b70f30
02d2a60c: mov     x0, xzr                                    
02d2a610: bl      #0x4df285c                                 System.DateTime::get_Today
02d2a614: str     x0, [sp, #8]                               
02d2a618: add     x0, sp, #8                                 
02d2a61c: mov     x1, xzr                                    
02d2a620: bl      #0x4df3550                                 System.DateTime::ToString
02d2a624: cbz     x20, #0x2d2a65c                            
02d2a628: mov     x1, x0                                     
02d2a62c: str     x0, [x20, #0x18]!                          
02d2a630: mov     x0, x20                                    
02d2a634: bl      #0x2b70d54                                 fn_2b70d54
02d2a638: ldr     x8, [x19]                                  
02d2a63c: mov     x0, x19                                    
02d2a640: ldr     x9, [x8, #0x258]                           
02d2a644: ldr     x1, [x8, #0x260]                           
02d2a648: blr     x9                                         
02d2a64c: ldp     x20, x19, [sp, #0x20]                      
02d2a650: ldp     x30, x21, [sp, #0x10]                      
02d2a654: add     sp, sp, #0x30                              
02d2a658: ret                                                
02d2a65c: bl      #0x2b7105c                                 fn_2b7105c
## GetCurrentDailyTasks() -> System.Collections.Generic.List`1<DailyTask.DataDailyTask/TaskProgress>
---- DailyTask.DataDailyTask::GetCurrentDailyTasks 0x2d2a660
02d2a660: sub     sp, sp, #0x80                              
02d2a664: stp     x30, x25, [sp, #0x40]                      
02d2a668: stp     x24, x23, [sp, #0x50]                      
02d2a66c: stp     x22, x21, [sp, #0x60]                      
02d2a670: stp     x20, x19, [sp, #0x70]                      
02d2a674: adrp    x22, #0x6630000                            
02d2a678: adrp    x21, #0x626a000                            
02d2a67c: adrp    x20, #0x626a000                            
02d2a680: ldrb    w8, [x22, #0xc5]                           
02d2a684: ldr     x21, [x21, #0x328]                         T:type15589(k15)
02d2a688: ldr     x20, [x20, #0x330]                         MS:System.Collections.Generic.List`1::.ctor
02d2a68c: mov     x19, x0                                    
02d2a690: tbnz    w8, #0, #0x2d2a6fc                         
02d2a694: adrp    x0, #0x626a000                             
02d2a698: ldr     x0, [x0, #0x2d8]                           MS:System.Collections.Generic.List`1/Enumerator::Dispose
02d2a69c: bl      #0x2b70db0                                 fn_2b70db0
02d2a6a0: adrp    x0, #0x626a000                             
02d2a6a4: ldr     x0, [x0, #0x2e0]                           MS:System.Collections.Generic.List`1/Enumerator::MoveNext
02d2a6a8: bl      #0x2b70db0                                 fn_2b70db0
02d2a6ac: adrp    x0, #0x626a000                             
02d2a6b0: ldr     x0, [x0, #0x2e8]                           MS:System.Collections.Generic.List`1/Enumerator::get_Current
02d2a6b4: bl      #0x2b70db0                                 fn_2b70db0
02d2a6b8: adrp    x0, #0x626a000                             
02d2a6bc: ldr     x0, [x0, #0x338]                           MS:System.Collections.Generic.List`1::AddRange
02d2a6c0: bl      #0x2b70db0                                 fn_2b70db0
02d2a6c4: adrp    x0, #0x626a000                             
02d2a6c8: ldr     x0, [x0, #0x340]                           MS:System.Collections.Generic.List`1::Add
02d2a6cc: bl      #0x2b70db0                                 fn_2b70db0
02d2a6d0: adrp    x0, #0x626a000                             
02d2a6d4: ldr     x0, [x0, #0x2f0]                           MS:System.Collections.Generic.List`1::GetEnumerator
02d2a6d8: bl      #0x2b70db0                                 fn_2b70db0
02d2a6dc: adrp    x0, #0x626a000                             
02d2a6e0: ldr     x0, [x0, #0x330]                           MS:System.Collections.Generic.List`1::.ctor
02d2a6e4: bl      #0x2b70db0                                 fn_2b70db0
02d2a6e8: adrp    x0, #0x626a000                             
02d2a6ec: ldr     x0, [x0, #0x328]                           T:type15589(k15)
02d2a6f0: bl      #0x2b70db0                                 fn_2b70db0
02d2a6f4: mov     w8, #1                                     
02d2a6f8: strb    w8, [x22, #0xc5]                           
02d2a6fc: ldr     x0, [x21]                                  T:type56879(k15)
02d2a700: stp     xzr, xzr, [sp, #0x20]                      
02d2a704: str     xzr, [sp, #0x30]                           
02d2a708: bl      #0x2b7104c                                 fn_2b7104c
02d2a70c: ldr     x1, [x20]                                  T:type56879(k15)
02d2a710: mov     x20, x0                                    
02d2a714: bl      #0x35a89a4                                 fn_35a89a4
02d2a718: ldr     x8, [x19, #0x20]                           ._dataSave
02d2a71c: cbz     x8, #0x2d2a84c                             
02d2a720: ldr     x0, [x8, #0x28]                            
02d2a724: cbz     x0, #0x2d2a84c                             
02d2a728: adrp    x8, #0x626a000                             
02d2a72c: adrp    x24, #0x626a000                            
02d2a730: adrp    x25, #0x626a000                            
02d2a734: ldr     x8, [x8, #0x2f0]                           MS:System.Collections.Generic.List`1::GetEnumerator
02d2a738: adrp    x22, #0x626a000                            
02d2a73c: adrp    x23, #0x626a000                            
02d2a740: ldr     x24, [x24, #0x2e0]                         MS:System.Collections.Generic.List`1/Enumerator::MoveNext
02d2a744: ldr     x25, [x25, #0x340]                         MS:System.Collections.Generic.List`1::Add
02d2a748: ldr     x22, [x22, #0x338]                         MS:System.Collections.Generic.List`1::AddRange
02d2a74c: ldr     x23, [x23, #0x2d8]                         MS:System.Collections.Generic.List`1/Enumerator::Dispose
02d2a750: ldr     x1, [x8]                                   T:type56879(k15)
02d2a754: add     x8, sp, #8                                 
02d2a758: bl      #0x35a9d9c                                 fn_35a9d9c
02d2a75c: ldr     x8, [sp, #0x18]                            
02d2a760: ldur    q0, [sp, #8]                               
02d2a764: str     x8, [sp, #0x30]                            
02d2a768: add     x8, sp, #0x20                              
02d2a76c: str     q0, [sp, #0x20]                            
02d2a770: stp     xzr, x8, [sp, #8]                          
02d2a774: ldr     x1, [x24]                                  T:type56879(k15)
02d2a778: add     x0, sp, #0x20                              
02d2a77c: bl      #0x4690474                                 fn_4690474
02d2a780: tbz     w0, #0, #0x2d2a800                         
02d2a784: ldr     x21, [sp, #0x30]                           
02d2a788: cbz     x21, #0x2d2a844                            
02d2a78c: ldr     w1, [x21, #0x10]                           T:Decor.DataDecor/CategoryData
02d2a790: mov     x0, x19                                    
02d2a794: bl      #0x2d2b26c                                 DailyTask.DataDailyTask::IsTaskCompleted
02d2a798: tbnz    w0, #0, #0x2d2a774                         
02d2a79c: cbz     x20, #0x2d2a848                            
02d2a7a0: ldr     w10, [x20, #0x1c]                          [626a01c]=0 f=0,0
02d2a7a4: ldr     x8, [x20, #0x10]                           T:Decor.DataDecor/CategoryData
02d2a7a8: ldr     x9, [x25]                                  T:type56879(k15)
02d2a7ac: add     w10, w10, #1                               
02d2a7b0: str     w10, [x20, #0x1c]                          
02d2a7b4: cbz     x8, #0x2d2a848                             
02d2a7b8: ldrsw   x10, [x20, #0x18]                          
02d2a7bc: ldr     w11, [x8, #0x18]                           MS:System.Collections.Generic.List`1::Add
02d2a7c0: cmp     w10, w11                                   
02d2a7c4: b.hs    #0x2d2a7e4                                 
02d2a7c8: add     x0, x8, x10, lsl #3                        &626a000
02d2a7cc: add     w9, w10, #1                                
02d2a7d0: str     w9, [x20, #0x18]                           
02d2a7d4: str     x21, [x0, #0x20]!                          ._dataSave
02d2a7d8: mov     x1, x21                                    
02d2a7dc: bl      #0x2b70d54                                 fn_2b70d54
02d2a7e0: b       #0x2d2a774                                 
02d2a7e4: ldr     x8, [x9, #0x20]                            
02d2a7e8: ldr     x8, [x8, #0xc0]                            S:'Main character is null'
02d2a7ec: ldr     x2, [x8, #0x70]                            MS:System.Collections.Generic.List`1::FindIndex
02d2a7f0: mov     x0, x20                                    
02d2a7f4: mov     x1, x21                                    
02d2a7f8: bl      #0x35a920c                                 fn_35a920c
02d2a7fc: b       #0x2d2a774                                 
02d2a800: ldr     x1, [x23]                                  T:type56879(k15)
02d2a804: add     x0, sp, #0x20                              
02d2a808: bl      #0x4690470                                 fn_4690470
02d2a80c: ldr     x8, [x19, #0x20]                           ._dataSave
02d2a810: cbz     x8, #0x2d2a84c                             
02d2a814: cbz     x20, #0x2d2a84c                            
02d2a818: ldr     x1, [x8, #0x20]                            M:Decor.DataDecor/<>c__DisplayClass8_0::<NewData>b__0
02d2a81c: ldr     x2, [x22]                                  T:type56879(k15)
02d2a820: mov     x0, x20                                    
02d2a824: bl      #0x35a941c                                 fn_35a941c
02d2a828: mov     x0, x20                                    
02d2a82c: ldp     x20, x19, [sp, #0x70]                      
02d2a830: ldp     x22, x21, [sp, #0x60]                      
02d2a834: ldp     x24, x23, [sp, #0x50]                      
02d2a838: ldp     x30, x25, [sp, #0x40]                      
02d2a83c: add     sp, sp, #0x80                              
02d2a840: ret                                                
02d2a844: bl      #0x2b7105c                                 fn_2b7105c
02d2a848: bl      #0x2b7105c                                 fn_2b7105c
02d2a84c: bl      #0x2b7105c                                 fn_2b7105c
02d2a850: b       #0x2d2a860                                 
02d2a854: b       #0x2d2a860                                 
02d2a858: b       #0x2d2a860                                 
02d2a85c: b       #0x2d2a860                                 
02d2a860: mov     x21, x0                                    
02d2a864: cmp     w1, #1                                     
02d2a868: b.ne    #0x2d2a89c                                 
02d2a86c: mov     x0, x21                                    
02d2a870: bl      #0x5e90260                                 fn_5e90260
02d2a874: ldr     x21, [x0]                                  T:type56879(k15)
02d2a878: str     x21, [sp, #8]                              
02d2a87c: bl      #0x5e90270                                 fn_5e90270
02d2a880: ldr     x0, [sp, #0x10]                            
02d2a884: ldr     x1, [x23]                                  T:type56879(k15)
02d2a888: bl      #0x4690470                                 fn_4690470
02d2a88c: cbz     x21, #0x2d2a80c                            
02d2a890: mov     x0, x21                                    
02d2a894: bl      #0x2b71054                                 fn_2b71054
02d2a898: mov     x21, x0                                    
02d2a89c: add     x0, sp, #8                                 
02d2a8a0: bl      #0x2738168                                 fn_2738168
02d2a8a4: mov     x0, x21                                    
02d2a8a8: bl      #0x2c6051c                                 fn_2c6051c
02d2a8ac: bl      #0x27369b8                                 fn_27369b8
## IsValidTask(int taskId) -> bool
---- DailyTask.DataDailyTask::IsValidTask 0x2d2c350
02d2c350: stp     x30, x21, [sp, #-0x20]!                    
02d2c354: stp     x20, x19, [sp, #0x10]                      
02d2c358: adrp    x20, #0x6630000                            
02d2c35c: adrp    x21, #0x626a000                            
02d2c360: mov     w19, w1                                    
02d2c364: ldrb    w8, [x20, #0xc6]                           
02d2c368: ldr     x21, [x21, #0x478]                         T:DailyTask.DataDailyTask/<>c__DisplayClass18_0
02d2c36c: tbnz    w8, #0, #0x2d2c3c0                         
02d2c370: adrp    x0, #0x626a000                             
02d2c374: ldr     x0, [x0, #0x2b8]                           MS:DataManager::GetAsset
02d2c378: bl      #0x2b70db0                                 fn_2b70db0
02d2c37c: adrp    x0, #0x626a000                             
02d2c380: ldr     x0, [x0, #0x3e8]                           MS:System.Collections.Generic.List`1::Find
02d2c384: bl      #0x2b70db0                                 fn_2b70db0
02d2c388: adrp    x0, #0x6266000                             
02d2c38c: ldr     x0, [x0, #0x658]                           MS:MonoSingleton`1::get_Instance
02d2c390: bl      #0x2b70db0                                 fn_2b70db0
02d2c394: adrp    x0, #0x626a000                             
02d2c398: ldr     x0, [x0, #0x3f0]                           T:type57262(k15)
02d2c39c: bl      #0x2b70db0                                 fn_2b70db0
02d2c3a0: adrp    x0, #0x626a000                             
02d2c3a4: ldr     x0, [x0, #0x480]                           M:DailyTask.DataDailyTask/<>c__DisplayClass18_0::<IsValidTask>b__0
02d2c3a8: bl      #0x2b70db0                                 fn_2b70db0
02d2c3ac: adrp    x0, #0x626a000                             
02d2c3b0: ldr     x0, [x0, #0x478]                           T:DailyTask.DataDailyTask/<>c__DisplayClass18_0
02d2c3b4: bl      #0x2b70db0                                 fn_2b70db0
02d2c3b8: mov     w8, #1                                     
02d2c3bc: strb    w8, [x20, #0xc6]                           
02d2c3c0: ldr     x0, [x21]                                  T:type56879(k15)
02d2c3c4: bl      #0x2b7104c                                 fn_2b7104c
02d2c3c8: mov     x1, xzr                                    
02d2c3cc: mov     x20, x0                                    
02d2c3d0: bl      #0x4e53e9c                                 System.Object::.ctor
02d2c3d4: cbz     x20, #0x2d2c464                            
02d2c3d8: adrp    x8, #0x6266000                             
02d2c3dc: ldr     x8, [x8, #0x658]                           MS:MonoSingleton`1::get_Instance
02d2c3e0: str     w19, [x20, #0x10]                          
02d2c3e4: ldr     x0, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d2c3e8: bl      #0x3769600                                 fn_3769600
02d2c3ec: cbz     x0, #0x2d2c464                             
02d2c3f0: adrp    x8, #0x626a000                             
02d2c3f4: ldr     x8, [x8, #0x2b8]                           MS:DataManager::GetAsset
02d2c3f8: ldr     x1, [x8]                                   T:type56879(k15)
02d2c3fc: bl      #0x3168af0                                 fn_3168af0
02d2c400: cbz     x0, #0x2d2c464                             
02d2c404: adrp    x8, #0x626a000                             
02d2c408: adrp    x21, #0x626a000                            
02d2c40c: ldr     x8, [x8, #0x3f0]                           T:type57262(k15)
02d2c410: ldr     x21, [x21, #0x480]                         M:DailyTask.DataDailyTask/<>c__DisplayClass18_0::<IsValidTask>b__0
02d2c414: ldr     x19, [x0, #0x18]                           MS:System.Collections.Generic.List`1::Add
02d2c418: ldr     x0, [x8]                                   T:type56879(k15)
02d2c41c: bl      #0x2b7104c                                 fn_2b7104c
02d2c420: ldr     x2, [x21]                                  T:type56879(k15)
02d2c424: mov     x1, x20                                    
02d2c428: mov     x3, xzr                                    
02d2c42c: mov     x21, x0                                    
02d2c430: bl      #0x399ba10                                 fn_399ba10
02d2c434: cbz     x19, #0x2d2c464                            
02d2c438: adrp    x8, #0x626a000                             
02d2c43c: mov     x0, x19                                    
02d2c440: mov     x1, x21                                    
02d2c444: ldr     x8, [x8, #0x3e8]                           MS:System.Collections.Generic.List`1::Find
02d2c448: ldr     x2, [x8]                                   T:type56879(k15)
02d2c44c: bl      #0x35a9868                                 fn_35a9868
02d2c450: ldp     x20, x19, [sp, #0x10]                      
02d2c454: cmp     x0, #0                                     
02d2c458: cset    w0, ne                                     
02d2c45c: ldp     x30, x21, [sp], #0x20                      
02d2c460: ret                                                
02d2c464: bl      #0x2b7105c                                 fn_2b7105c
## IsTaskTodayHaveSomethingWrong() -> bool
---- DailyTask.DataDailyTask::IsTaskTodayHaveSomethingWrong 0x2d2a168
02d2a168: sub     sp, sp, #0x70                              
02d2a16c: stp     x30, x23, [sp, #0x40]                      
02d2a170: stp     x22, x21, [sp, #0x50]                      
02d2a174: stp     x20, x19, [sp, #0x60]                      
02d2a178: adrp    x20, #0x6630000                            
02d2a17c: mov     x19, x0                                    
02d2a180: ldrb    w8, [x20, #0xc7]                           
02d2a184: tbnz    w8, #0, #0x2d2a1c0                         
02d2a188: adrp    x0, #0x626a000                             
02d2a18c: ldr     x0, [x0, #0x2d8]                           MS:System.Collections.Generic.List`1/Enumerator::Dispose
02d2a190: bl      #0x2b70db0                                 fn_2b70db0
02d2a194: adrp    x0, #0x626a000                             
02d2a198: ldr     x0, [x0, #0x2e0]                           MS:System.Collections.Generic.List`1/Enumerator::MoveNext
02d2a19c: bl      #0x2b70db0                                 fn_2b70db0
02d2a1a0: adrp    x0, #0x626a000                             
02d2a1a4: ldr     x0, [x0, #0x2e8]                           MS:System.Collections.Generic.List`1/Enumerator::get_Current
02d2a1a8: bl      #0x2b70db0                                 fn_2b70db0
02d2a1ac: adrp    x0, #0x626a000                             
02d2a1b0: ldr     x0, [x0, #0x2f0]                           MS:System.Collections.Generic.List`1::GetEnumerator
02d2a1b4: bl      #0x2b70db0                                 fn_2b70db0
02d2a1b8: mov     w8, #1                                     
02d2a1bc: strb    w8, [x20, #0xc7]                           
02d2a1c0: ldr     x8, [x19, #0x20]                           ._dataSave
02d2a1c4: stp     xzr, xzr, [sp, #0x20]                      
02d2a1c8: str     xzr, [sp, #0x30]                           
02d2a1cc: cbz     x8, #0x2d2a2e0                             
02d2a1d0: ldr     x0, [x8, #0x28]                            
02d2a1d4: cbz     x0, #0x2d2a2e0                             
02d2a1d8: adrp    x23, #0x626a000                            
02d2a1dc: adrp    x22, #0x626a000                            
02d2a1e0: adrp    x21, #0x626a000                            
02d2a1e4: ldr     x23, [x23, #0x2f0]                         MS:System.Collections.Generic.List`1::GetEnumerator
02d2a1e8: ldr     x22, [x22, #0x2e0]                         MS:System.Collections.Generic.List`1/Enumerator::MoveNext
02d2a1ec: ldr     x21, [x21, #0x2d8]                         MS:System.Collections.Generic.List`1/Enumerator::Dispose
02d2a1f0: add     x8, sp, #8                                 
02d2a1f4: ldr     x1, [x23]                                  T:type56879(k15)
02d2a1f8: bl      #0x35a9d9c                                 fn_35a9d9c
02d2a1fc: ldr     x8, [sp, #0x18]                            
02d2a200: ldur    q0, [sp, #8]                               
02d2a204: str     x8, [sp, #0x30]                            
02d2a208: add     x8, sp, #0x20                              
02d2a20c: str     q0, [sp, #0x20]                            
02d2a210: stp     xzr, x8, [sp, #8]                          
02d2a214: ldr     x1, [x22]                                  T:type56879(k15)
02d2a218: add     x0, sp, #0x20                              
02d2a21c: bl      #0x4690474                                 fn_4690474
02d2a220: tbz     w0, #0, #0x2d2a23c                         
02d2a224: ldr     x8, [sp, #0x30]                            
02d2a228: cbz     x8, #0x2d2a2d8                             
02d2a22c: ldr     w1, [x8, #0x10]                            
02d2a230: bl      #0x2d2c350                                 DailyTask.DataDailyTask::IsValidTask
02d2a234: tbnz    w0, #0, #0x2d2a214                         
02d2a238: b       #0x2d2a2a0                                 
02d2a23c: ldr     x1, [x21]                                  T:type56879(k15)
02d2a240: add     x0, sp, #0x20                              
02d2a244: bl      #0x4690470                                 fn_4690470
02d2a248: ldr     x8, [x19, #0x20]                           ._dataSave
02d2a24c: cbz     x8, #0x2d2a2e0                             
02d2a250: ldr     x0, [x8, #0x20]                            
02d2a254: cbz     x0, #0x2d2a2e0                             
02d2a258: ldr     x1, [x23]                                  T:type56879(k15)
02d2a25c: add     x8, sp, #8                                 
02d2a260: bl      #0x35a9d9c                                 fn_35a9d9c
02d2a264: ldr     x8, [sp, #0x18]                            
02d2a268: ldur    q0, [sp, #8]                               
02d2a26c: str     x8, [sp, #0x30]                            
02d2a270: add     x8, sp, #0x20                              
02d2a274: str     q0, [sp, #0x20]                            
02d2a278: stp     xzr, x8, [sp, #8]                          
02d2a27c: ldr     x1, [x22]                                  T:type56879(k15)
02d2a280: add     x0, sp, #0x20                              
02d2a284: bl      #0x4690474                                 fn_4690474
02d2a288: tbz     w0, #0, #0x2d2a2b4                         
02d2a28c: ldr     x8, [sp, #0x30]                            
02d2a290: cbz     x8, #0x2d2a2dc                             
02d2a294: ldr     w1, [x8, #0x10]                            
02d2a298: bl      #0x2d2c350                                 DailyTask.DataDailyTask::IsValidTask
02d2a29c: tbnz    w0, #0, #0x2d2a27c                         
02d2a2a0: ldr     x1, [x21]                                  T:type56879(k15)
02d2a2a4: add     x0, sp, #0x20                              
02d2a2a8: bl      #0x4690470                                 fn_4690470
02d2a2ac: mov     w0, #1                                     
02d2a2b0: b       #0x2d2a2c4                                 
02d2a2b4: ldr     x1, [x21]                                  T:type56879(k15)
02d2a2b8: add     x0, sp, #0x20                              
02d2a2bc: bl      #0x4690470                                 fn_4690470
02d2a2c0: mov     w0, wzr                                    
02d2a2c4: ldp     x20, x19, [sp, #0x60]                      
02d2a2c8: ldp     x22, x21, [sp, #0x50]                      
02d2a2cc: ldp     x30, x23, [sp, #0x40]                      
02d2a2d0: add     sp, sp, #0x70                              
02d2a2d4: ret                                                
02d2a2d8: bl      #0x2b7105c                                 fn_2b7105c
02d2a2dc: bl      #0x2b7105c                                 fn_2b7105c
02d2a2e0: bl      #0x2b7105c                                 fn_2b7105c
02d2a2e4: b       #0x2d2a2ec                                 
02d2a2e8: b       #0x2d2a2ec                                 
02d2a2ec: mov     x20, x0                                    
02d2a2f0: cmp     w1, #1                                     
02d2a2f4: b.ne    #0x2d2a328                                 
02d2a2f8: mov     x0, x20                                    
02d2a2fc: bl      #0x5e90260                                 fn_5e90260
02d2a300: ldr     x19, [x0]                                  T:type56879(k15)
02d2a304: str     x19, [sp, #8]                              
02d2a308: bl      #0x5e90270                                 fn_5e90270
02d2a30c: ldr     x0, [sp, #0x10]                            
02d2a310: ldr     x1, [x21]                                  T:type56879(k15)
02d2a314: bl      #0x4690470                                 fn_4690470
02d2a318: cbz     x19, #0x2d2a2c0                            
02d2a31c: mov     x0, x19                                    
02d2a320: bl      #0x2b71054                                 fn_2b71054
02d2a324: mov     x20, x0                                    
02d2a328: add     x0, sp, #8                                 
02d2a32c: bl      #0x2738168                                 fn_2738168
02d2a330: b       #0x2d2a380                                 
02d2a334: b       #0x2d2a33c                                 
02d2a338: b       #0x2d2a33c                                 
02d2a33c: mov     x20, x0                                    
02d2a340: cmp     w1, #1                                     
02d2a344: b.ne    #0x2d2a378                                 
02d2a348: mov     x0, x20                                    
02d2a34c: bl      #0x5e90260                                 fn_5e90260
02d2a350: ldr     x20, [x0]                                  T:type56879(k15)
02d2a354: str     x20, [sp, #8]                              
02d2a358: bl      #0x5e90270                                 fn_5e90270
02d2a35c: ldr     x0, [sp, #0x10]                            
02d2a360: ldr     x1, [x21]                                  T:type56879(k15)
02d2a364: bl      #0x4690470                                 fn_4690470
02d2a368: cbz     x20, #0x2d2a248                            
02d2a36c: mov     x0, x20                                    
02d2a370: bl      #0x2b71054                                 fn_2b71054
02d2a374: mov     x20, x0                                    
02d2a378: add     x0, sp, #8                                 
02d2a37c: bl      #0x2738168                                 fn_2738168
02d2a380: mov     x0, x20                                    
02d2a384: bl      #0x2c6051c                                 fn_2c6051c
02d2a388: bl      #0x27369b8                                 fn_27369b8
## IsTaskCompleted(int taskId) -> bool
---- DailyTask.DataDailyTask::IsTaskCompleted 0x2d2b26c
02d2b26c: str     x30, [sp, #-0x30]!                         
02d2b270: stp     x22, x21, [sp, #0x10]                      
02d2b274: stp     x20, x19, [sp, #0x20]                      
02d2b278: adrp    x21, #0x6630000                            
02d2b27c: adrp    x22, #0x626a000                            
02d2b280: mov     w19, w1                                    
02d2b284: ldrb    w8, [x21, #0xc8]                           
02d2b288: ldr     x22, [x22, #0x3a0]                         T:DailyTask.DataDailyTask/<>c__DisplayClass20_0
02d2b28c: mov     x20, x0                                    
02d2b290: tbnz    w8, #0, #0x2d2b2cc                         
02d2b294: adrp    x0, #0x626a000                             
02d2b298: ldr     x0, [x0, #0x228]                           MS:System.Collections.Generic.List`1::Exists
02d2b29c: bl      #0x2b70db0                                 fn_2b70db0
02d2b2a0: adrp    x0, #0x626a000                             
02d2b2a4: ldr     x0, [x0, #0x230]                           T:type57305(k15)
02d2b2a8: bl      #0x2b70db0                                 fn_2b70db0
02d2b2ac: adrp    x0, #0x626a000                             
02d2b2b0: ldr     x0, [x0, #0x3a8]                           M:DailyTask.DataDailyTask/<>c__DisplayClass20_0::<IsTaskCompleted>b__0
02d2b2b4: bl      #0x2b70db0                                 fn_2b70db0
02d2b2b8: adrp    x0, #0x626a000                             
02d2b2bc: ldr     x0, [x0, #0x3a0]                           T:DailyTask.DataDailyTask/<>c__DisplayClass20_0
02d2b2c0: bl      #0x2b70db0                                 fn_2b70db0
02d2b2c4: mov     w8, #1                                     
02d2b2c8: strb    w8, [x21, #0xc8]                           
02d2b2cc: ldr     x0, [x22]                                  T:type56879(k15)
02d2b2d0: bl      #0x2b7104c                                 fn_2b7104c
02d2b2d4: mov     x1, xzr                                    
02d2b2d8: mov     x21, x0                                    
02d2b2dc: bl      #0x4e53e9c                                 System.Object::.ctor
02d2b2e0: cbz     x21, #0x2d2b348                            
02d2b2e4: ldr     x8, [x20, #0x20]                           ._dataSave
02d2b2e8: str     w19, [x21, #0x10]                          
02d2b2ec: cbz     x8, #0x2d2b348                             
02d2b2f0: adrp    x9, #0x626a000                             
02d2b2f4: adrp    x20, #0x626a000                            
02d2b2f8: ldr     x9, [x9, #0x230]                           T:type57305(k15)
02d2b2fc: ldr     x20, [x20, #0x3a8]                         M:DailyTask.DataDailyTask/<>c__DisplayClass20_0::<IsTaskCompleted>b__0
02d2b300: ldr     x19, [x8, #0x20]                           
02d2b304: ldr     x0, [x9]                                   T:type56879(k15)
02d2b308: bl      #0x2b7104c                                 fn_2b7104c
02d2b30c: ldr     x2, [x20]                                  T:type56879(k15)
02d2b310: mov     x1, x21                                    
02d2b314: mov     x3, xzr                                    
02d2b318: mov     x20, x0                                    
02d2b31c: bl      #0x399ba10                                 fn_399ba10
02d2b320: cbz     x19, #0x2d2b348                            
02d2b324: adrp    x8, #0x626a000                             
02d2b328: mov     x0, x19                                    
02d2b32c: mov     x1, x20                                    
02d2b330: ldr     x8, [x8, #0x228]                           MS:System.Collections.Generic.List`1::Exists
02d2b334: ldp     x20, x19, [sp, #0x20]                      
02d2b338: ldp     x22, x21, [sp, #0x10]                      
02d2b33c: ldr     x2, [x8]                                   T:type56879(k15)
02d2b340: ldr     x30, [sp], #0x30                           
02d2b344: b       #0x35a9844                                 
02d2b348: bl      #0x2b7105c                                 fn_2b7105c
## AddCompletedTask(int taskId) -> void
---- DailyTask.DataDailyTask::AddCompletedTask 0x2d2b09c
02d2b09c: str     x30, [sp, #-0x30]!                         
02d2b0a0: stp     x22, x21, [sp, #0x10]                      
02d2b0a4: stp     x20, x19, [sp, #0x20]                      
02d2b0a8: adrp    x21, #0x6630000                            
02d2b0ac: adrp    x22, #0x626a000                            
02d2b0b0: mov     w20, w1                                    
02d2b0b4: ldrb    w8, [x21, #0xc9]                           
02d2b0b8: ldr     x22, [x22, #0x380]                         T:DailyTask.DataDailyTask/<>c__DisplayClass21_0
02d2b0bc: mov     x19, x0                                    
02d2b0c0: tbnz    w8, #0, #0x2d2b114                         
02d2b0c4: adrp    x0, #0x626a000                             
02d2b0c8: ldr     x0, [x0, #0x340]                           MS:System.Collections.Generic.List`1::Add
02d2b0cc: bl      #0x2b70db0                                 fn_2b70db0
02d2b0d0: adrp    x0, #0x626a000                             
02d2b0d4: ldr     x0, [x0, #0x388]                           MS:System.Collections.Generic.List`1::Find
02d2b0d8: bl      #0x2b70db0                                 fn_2b70db0
02d2b0dc: adrp    x0, #0x626a000                             
02d2b0e0: ldr     x0, [x0, #0x390]                           MS:System.Collections.Generic.List`1::Remove
02d2b0e4: bl      #0x2b70db0                                 fn_2b70db0
02d2b0e8: adrp    x0, #0x626a000                             
02d2b0ec: ldr     x0, [x0, #0x230]                           T:type57305(k15)
02d2b0f0: bl      #0x2b70db0                                 fn_2b70db0
02d2b0f4: adrp    x0, #0x626a000                             
02d2b0f8: ldr     x0, [x0, #0x398]                           M:DailyTask.DataDailyTask/<>c__DisplayClass21_0::<AddCompletedTask>b__0
02d2b0fc: bl      #0x2b70db0                                 fn_2b70db0
02d2b100: adrp    x0, #0x626a000                             
02d2b104: ldr     x0, [x0, #0x380]                           T:DailyTask.DataDailyTask/<>c__DisplayClass21_0
02d2b108: bl      #0x2b70db0                                 fn_2b70db0
02d2b10c: mov     w8, #1                                     
02d2b110: strb    w8, [x21, #0xc9]                           
02d2b114: ldr     x0, [x22]                                  T:type56879(k15)
02d2b118: bl      #0x2b7104c                                 fn_2b7104c
02d2b11c: mov     x1, xzr                                    
02d2b120: mov     x21, x0                                    
02d2b124: bl      #0x4e53e9c                                 System.Object::.ctor
02d2b128: cbz     x21, #0x2d2b260                            
02d2b12c: mov     x0, x19                                    
02d2b130: mov     w1, w20                                    
02d2b134: str     w20, [x21, #0x10]                          
02d2b138: bl      #0x2d2b26c                                 DailyTask.DataDailyTask::IsTaskCompleted
02d2b13c: tbz     w0, #0, #0x2d2b150                         
02d2b140: ldp     x20, x19, [sp, #0x20]                      
02d2b144: ldp     x22, x21, [sp, #0x10]                      
02d2b148: ldr     x30, [sp], #0x30                           
02d2b14c: ret                                                
02d2b150: ldr     x8, [x19, #0x20]                           ._dataSave
02d2b154: cbz     x8, #0x2d2b260                             
02d2b158: adrp    x9, #0x626a000                             
02d2b15c: ldr     x9, [x9, #0x230]                           T:type57305(k15)
02d2b160: ldr     x20, [x8, #0x28]                           
02d2b164: ldr     x0, [x9]                                   T:type56879(k15)
02d2b168: bl      #0x2b7104c                                 fn_2b7104c
02d2b16c: adrp    x8, #0x626a000                             
02d2b170: mov     x1, x21                                    
02d2b174: mov     x3, xzr                                    
02d2b178: ldr     x8, [x8, #0x398]                           M:DailyTask.DataDailyTask/<>c__DisplayClass21_0::<AddCompletedTask>b__0
02d2b17c: mov     x22, x0                                    
02d2b180: ldr     x2, [x8]                                   T:type56879(k15)
02d2b184: bl      #0x399ba10                                 fn_399ba10
02d2b188: cbz     x20, #0x2d2b260                            
02d2b18c: adrp    x8, #0x626a000                             
02d2b190: mov     x0, x20                                    
02d2b194: mov     x1, x22                                    
02d2b198: ldr     x8, [x8, #0x388]                           MS:System.Collections.Generic.List`1::Find
02d2b19c: ldr     x2, [x8]                                   T:type56879(k15)
02d2b1a0: bl      #0x35a9868                                 fn_35a9868
02d2b1a4: ldr     x8, [x19, #0x20]                           ._dataSave
02d2b1a8: cbz     x8, #0x2d2b260                             
02d2b1ac: mov     x20, x0                                    
02d2b1b0: ldr     x0, [x8, #0x20]                            M:Decor.DataDecor/<>c__DisplayClass8_0::<NewData>b__0
02d2b1b4: cbz     x0, #0x2d2b260                             
02d2b1b8: adrp    x9, #0x626a000                             
02d2b1bc: ldr     x9, [x9, #0x340]                           MS:System.Collections.Generic.List`1::Add
02d2b1c0: ldr     w10, [x0, #0x1c]                           [626a01c]=0 f=0,0
02d2b1c4: ldr     x8, [x0, #0x10]                            T:Decor.DataDecor/CategoryData
02d2b1c8: ldr     x9, [x9]                                   T:type56879(k15)
02d2b1cc: add     w10, w10, #1                               
02d2b1d0: str     w10, [x0, #0x1c]                           
02d2b1d4: cbz     x8, #0x2d2b260                             
02d2b1d8: ldrsw   x10, [x0, #0x18]                           
02d2b1dc: ldr     w11, [x8, #0x18]                           MS:System.Collections.Generic.List`1::Add
02d2b1e0: cmp     w10, w11                                   
02d2b1e4: b.hs    #0x2d2b208                                 
02d2b1e8: add     x8, x8, x10, lsl #3                        &626a000
02d2b1ec: add     w9, w10, #1                                
02d2b1f0: mov     x1, x20                                    
02d2b1f4: str     w9, [x0, #0x18]                            
02d2b1f8: str     x20, [x8, #0x20]!                          
02d2b1fc: mov     x0, x8                                     
02d2b200: bl      #0x2b70d54                                 fn_2b70d54
02d2b204: b       #0x2d2b21c                                 
02d2b208: ldr     x8, [x9, #0x20]                            M:Decor.DataDecor/<>c__DisplayClass8_0::<NewData>b__0
02d2b20c: mov     x1, x20                                    
02d2b210: ldr     x8, [x8, #0xc0]                            S:'Main character is null'
02d2b214: ldr     x2, [x8, #0x70]                            MS:System.Collections.Generic.List`1::FindIndex
02d2b218: bl      #0x35a920c                                 fn_35a920c
02d2b21c: ldr     x8, [x19, #0x20]                           ._dataSave
02d2b220: cbz     x8, #0x2d2b260                             
02d2b224: ldr     x0, [x8, #0x28]                            T:Decor.DataDecor/<>c__DisplayClass8_0
02d2b228: cbz     x0, #0x2d2b260                             
02d2b22c: adrp    x8, #0x626a000                             
02d2b230: mov     x1, x20                                    
02d2b234: ldr     x8, [x8, #0x390]                           MS:System.Collections.Generic.List`1::Remove
02d2b238: ldr     x2, [x8]                                   T:type56879(k15)
02d2b23c: bl      #0x35aa7b4                                 fn_35aa7b4
02d2b240: ldr     x8, [x19]                                  
02d2b244: mov     x0, x19                                    
02d2b248: ldp     x20, x19, [sp, #0x20]                      
02d2b24c: ldp     x22, x21, [sp, #0x10]                      
02d2b250: ldr     x1, [x8, #0x260]                           MS:System.Collections.Generic.List`1/Enumerator::Dispose
02d2b254: ldr     x2, [x8, #0x258]                           M:Decor.OptionPanel::<Refresh>b__19_0
02d2b258: ldr     x30, [sp], #0x30                           
02d2b25c: br      x2                                         
02d2b260: bl      #0x2b7105c                                 fn_2b7105c
## AddInProgressTask(int taskId, int progressValue, int rewardValue) -> void
---- DailyTask.DataDailyTask::AddInProgressTask 0x2d2adc8
02d2adc8: stp     x30, x23, [sp, #-0x30]!                    
02d2adcc: stp     x22, x21, [sp, #0x10]                      
02d2add0: stp     x20, x19, [sp, #0x20]                      
02d2add4: adrp    x20, #0x6630000                            
02d2add8: mov     w21, w3                                    
02d2addc: mov     w22, w2                                    
02d2ade0: ldrb    w8, [x20, #0xca]                           
02d2ade4: mov     w23, w1                                    
02d2ade8: mov     x19, x0                                    
02d2adec: tbnz    w8, #0, #0x2d2ae10                         
02d2adf0: adrp    x0, #0x626a000                             
02d2adf4: ldr     x0, [x0, #0x340]                           MS:System.Collections.Generic.List`1::Add
02d2adf8: bl      #0x2b70db0                                 fn_2b70db0
02d2adfc: adrp    x0, #0x626a000                             
02d2ae00: ldr     x0, [x0, #0x358]                           T:DailyTask.DataDailyTask/TaskProgress
02d2ae04: bl      #0x2b70db0                                 fn_2b70db0
02d2ae08: mov     w8, #1                                     
02d2ae0c: strb    w8, [x20, #0xca]                           
02d2ae10: mov     x0, x19                                    
02d2ae14: mov     w1, w23                                    
02d2ae18: bl      #0x2d2b26c                                 DailyTask.DataDailyTask::IsTaskCompleted
02d2ae1c: tbz     w0, #0, #0x2d2ae30                         
02d2ae20: ldp     x20, x19, [sp, #0x20]                      
02d2ae24: ldp     x22, x21, [sp, #0x10]                      
02d2ae28: ldp     x30, x23, [sp], #0x30                      
02d2ae2c: ret                                                
02d2ae30: adrp    x8, #0x626a000                             
02d2ae34: ldr     x8, [x8, #0x358]                           T:DailyTask.DataDailyTask/TaskProgress
02d2ae38: ldr     x0, [x8]                                   T:type56879(k15)
02d2ae3c: bl      #0x2b7104c                                 fn_2b7104c
02d2ae40: mov     x1, xzr                                    
02d2ae44: mov     x20, x0                                    
02d2ae48: bl      #0x4e53e9c                                 System.Object::.ctor
02d2ae4c: cbz     x20, #0x2d2aeec                            
02d2ae50: ldr     x8, [x19, #0x20]                           ._dataSave
02d2ae54: stp     w23, w22, [x20, #0x10]                     
02d2ae58: str     w21, [x20, #0x18]                          
02d2ae5c: cbz     x8, #0x2d2aeec                             
02d2ae60: ldr     x0, [x8, #0x28]                            T:Decor.DataDecor/<>c__DisplayClass8_0
02d2ae64: cbz     x0, #0x2d2aeec                             
02d2ae68: adrp    x9, #0x626a000                             
02d2ae6c: ldr     x9, [x9, #0x340]                           MS:System.Collections.Generic.List`1::Add
02d2ae70: ldr     w10, [x0, #0x1c]                           [626a01c]=0 f=0,0
02d2ae74: ldr     x8, [x0, #0x10]                            T:Decor.DataDecor/CategoryData
02d2ae78: ldr     x9, [x9]                                   T:type56879(k15)
02d2ae7c: add     w10, w10, #1                               
02d2ae80: str     w10, [x0, #0x1c]                           
02d2ae84: cbz     x8, #0x2d2aeec                             
02d2ae88: ldrsw   x10, [x0, #0x18]                           
02d2ae8c: ldr     w11, [x8, #0x18]                           MS:System.Collections.Generic.List`1::Add
02d2ae90: cmp     w10, w11                                   
02d2ae94: b.hs    #0x2d2aeb8                                 
02d2ae98: add     x8, x8, x10, lsl #3                        &626a000
02d2ae9c: add     w9, w10, #1                                
02d2aea0: mov     x1, x20                                    
02d2aea4: str     w9, [x0, #0x18]                            
02d2aea8: str     x20, [x8, #0x20]!                          
02d2aeac: mov     x0, x8                                     
02d2aeb0: bl      #0x2b70d54                                 fn_2b70d54
02d2aeb4: b       #0x2d2aecc                                 
02d2aeb8: ldr     x8, [x9, #0x20]                            M:Decor.DataDecor/<>c__DisplayClass8_0::<NewData>b__0
02d2aebc: mov     x1, x20                                    
02d2aec0: ldr     x8, [x8, #0xc0]                            S:'Main character is null'
02d2aec4: ldr     x2, [x8, #0x70]                            MS:System.Collections.Generic.List`1::FindIndex
02d2aec8: bl      #0x35a920c                                 fn_35a920c
02d2aecc: ldr     x8, [x19]                                  
02d2aed0: mov     x0, x19                                    
02d2aed4: ldp     x20, x19, [sp, #0x20]                      
02d2aed8: ldp     x22, x21, [sp, #0x10]                      
02d2aedc: ldr     x1, [x8, #0x260]                           MS:System.Collections.Generic.List`1/Enumerator::Dispose
02d2aee0: ldr     x2, [x8, #0x258]                           M:Decor.OptionPanel::<Refresh>b__19_0
02d2aee4: ldp     x30, x23, [sp], #0x30                      
02d2aee8: br      x2                                         
02d2aeec: bl      #0x2b7105c                                 fn_2b7105c
## UpdateInProgressTask(int taskId, int progressValue) -> void
---- DailyTask.DataDailyTask::UpdateInProgressTask 0x2d2b480
02d2b480: stp     x30, x23, [sp, #-0x30]!                    
02d2b484: stp     x22, x21, [sp, #0x10]                      
02d2b488: stp     x20, x19, [sp, #0x20]                      
02d2b48c: adrp    x22, #0x6630000                            
02d2b490: adrp    x23, #0x626a000                            
02d2b494: mov     w20, w2                                    
02d2b498: ldrb    w8, [x22, #0xcb]                           
02d2b49c: ldr     x23, [x23, #0x3c0]                         T:DailyTask.DataDailyTask/<>c__DisplayClass23_0
02d2b4a0: mov     w21, w1                                    
02d2b4a4: mov     x19, x0                                    
02d2b4a8: tbnz    w8, #0, #0x2d2b4e4                         
02d2b4ac: adrp    x0, #0x626a000                             
02d2b4b0: ldr     x0, [x0, #0x388]                           MS:System.Collections.Generic.List`1::Find
02d2b4b4: bl      #0x2b70db0                                 fn_2b70db0
02d2b4b8: adrp    x0, #0x626a000                             
02d2b4bc: ldr     x0, [x0, #0x230]                           T:type57305(k15)
02d2b4c0: bl      #0x2b70db0                                 fn_2b70db0
02d2b4c4: adrp    x0, #0x626a000                             
02d2b4c8: ldr     x0, [x0, #0x3c8]                           M:DailyTask.DataDailyTask/<>c__DisplayClass23_0::<UpdateInProgressTask>b__0
02d2b4cc: bl      #0x2b70db0                                 fn_2b70db0
02d2b4d0: adrp    x0, #0x626a000                             
02d2b4d4: ldr     x0, [x0, #0x3c0]                           T:DailyTask.DataDailyTask/<>c__DisplayClass23_0
02d2b4d8: bl      #0x2b70db0                                 fn_2b70db0
02d2b4dc: mov     w8, #1                                     
02d2b4e0: strb    w8, [x22, #0xcb]                           
02d2b4e4: ldr     x0, [x23]                                  T:type56879(k15)
02d2b4e8: bl      #0x2b7104c                                 fn_2b7104c
02d2b4ec: mov     x1, xzr                                    
02d2b4f0: mov     x22, x0                                    
02d2b4f4: bl      #0x4e53e9c                                 System.Object::.ctor
02d2b4f8: cbz     x22, #0x2d2b5a4                            
02d2b4fc: mov     x0, x19                                    
02d2b500: mov     w1, w21                                    
02d2b504: str     w21, [x22, #0x10]                          
02d2b508: bl      #0x2d2b26c                                 DailyTask.DataDailyTask::IsTaskCompleted
02d2b50c: tbz     w0, #0, #0x2d2b520                         
02d2b510: ldp     x20, x19, [sp, #0x20]                      
02d2b514: ldp     x22, x21, [sp, #0x10]                      
02d2b518: ldp     x30, x23, [sp], #0x30                      
02d2b51c: ret                                                
02d2b520: ldr     x8, [x19, #0x20]                           ._dataSave
02d2b524: cbz     x8, #0x2d2b5a4                             
02d2b528: adrp    x9, #0x626a000                             
02d2b52c: ldr     x9, [x9, #0x230]                           T:type57305(k15)
02d2b530: ldr     x21, [x8, #0x28]                           
02d2b534: ldr     x0, [x9]                                   T:type56879(k15)
02d2b538: bl      #0x2b7104c                                 fn_2b7104c
02d2b53c: adrp    x8, #0x626a000                             
02d2b540: mov     x1, x22                                    
02d2b544: mov     x3, xzr                                    
02d2b548: ldr     x8, [x8, #0x3c8]                           M:DailyTask.DataDailyTask/<>c__DisplayClass23_0::<UpdateInProgressTask>b__0
02d2b54c: mov     x23, x0                                    
02d2b550: ldr     x2, [x8]                                   T:type56879(k15)
02d2b554: bl      #0x399ba10                                 fn_399ba10
02d2b558: cbz     x21, #0x2d2b5a4                            
02d2b55c: adrp    x8, #0x626a000                             
02d2b560: mov     x0, x21                                    
02d2b564: mov     x1, x23                                    
02d2b568: ldr     x8, [x8, #0x388]                           MS:System.Collections.Generic.List`1::Find
02d2b56c: ldr     x2, [x8]                                   T:type56879(k15)
02d2b570: bl      #0x35a9868                                 fn_35a9868
02d2b574: cbz     x0, #0x2d2b5a4                             
02d2b578: ldr     w8, [x0, #0x14]                            [626a014]=0 f=0,0
02d2b57c: ldp     x22, x21, [sp, #0x10]                      
02d2b580: add     w8, w8, w20                                
02d2b584: str     w8, [x0, #0x14]                            
02d2b588: mov     x0, x19                                    
02d2b58c: ldr     x8, [x19]                                  
02d2b590: ldp     x20, x19, [sp, #0x20]                      
02d2b594: ldr     x1, [x8, #0x260]                           MS:System.Collections.Generic.List`1/Enumerator::Dispose
02d2b598: ldr     x2, [x8, #0x258]                           M:Decor.OptionPanel::<Refresh>b__19_0
02d2b59c: ldp     x30, x23, [sp], #0x30                      
02d2b5a0: br      x2                                         
02d2b5a4: bl      #0x2b7105c                                 fn_2b7105c
## GetProgressOfTask(int taskId) -> int
---- DailyTask.DataDailyTask::GetProgressOfTask 0x2d2b5a8
02d2b5a8: str     x30, [sp, #-0x30]!                         
02d2b5ac: stp     x22, x21, [sp, #0x10]                      
02d2b5b0: stp     x20, x19, [sp, #0x20]                      
02d2b5b4: adrp    x21, #0x6630000                            
02d2b5b8: adrp    x22, #0x626a000                            
02d2b5bc: mov     w19, w1                                    
02d2b5c0: ldrb    w8, [x21, #0xcc]                           
02d2b5c4: ldr     x22, [x22, #0x3d0]                         T:DailyTask.DataDailyTask/<>c__DisplayClass24_0
02d2b5c8: mov     x20, x0                                    
02d2b5cc: tbnz    w8, #0, #0x2d2b608                         
02d2b5d0: adrp    x0, #0x626a000                             
02d2b5d4: ldr     x0, [x0, #0x388]                           MS:System.Collections.Generic.List`1::Find
02d2b5d8: bl      #0x2b70db0                                 fn_2b70db0
02d2b5dc: adrp    x0, #0x626a000                             
02d2b5e0: ldr     x0, [x0, #0x230]                           T:type57305(k15)
02d2b5e4: bl      #0x2b70db0                                 fn_2b70db0
02d2b5e8: adrp    x0, #0x626a000                             
02d2b5ec: ldr     x0, [x0, #0x3d8]                           M:DailyTask.DataDailyTask/<>c__DisplayClass24_0::<GetProgressOfTask>b__0
02d2b5f0: bl      #0x2b70db0                                 fn_2b70db0
02d2b5f4: adrp    x0, #0x626a000                             
02d2b5f8: ldr     x0, [x0, #0x3d0]                           T:DailyTask.DataDailyTask/<>c__DisplayClass24_0
02d2b5fc: bl      #0x2b70db0                                 fn_2b70db0
02d2b600: mov     w8, #1                                     
02d2b604: strb    w8, [x21, #0xcc]                           
02d2b608: ldr     x0, [x22]                                  T:type56879(k15)
02d2b60c: bl      #0x2b7104c                                 fn_2b7104c
02d2b610: mov     x1, xzr                                    
02d2b614: mov     x21, x0                                    
02d2b618: bl      #0x4e53e9c                                 System.Object::.ctor
02d2b61c: cbz     x21, #0x2d2b690                            
02d2b620: ldr     x8, [x20, #0x20]                           ._dataSave
02d2b624: str     w19, [x21, #0x10]                          
02d2b628: cbz     x8, #0x2d2b690                             
02d2b62c: adrp    x9, #0x626a000                             
02d2b630: adrp    x20, #0x626a000                            
02d2b634: ldr     x9, [x9, #0x230]                           T:type57305(k15)
02d2b638: ldr     x20, [x20, #0x3d8]                         M:DailyTask.DataDailyTask/<>c__DisplayClass24_0::<GetProgressOfTask>b__0
02d2b63c: ldr     x19, [x8, #0x28]                           
02d2b640: ldr     x0, [x9]                                   T:type56879(k15)
02d2b644: bl      #0x2b7104c                                 fn_2b7104c
02d2b648: ldr     x2, [x20]                                  T:type56879(k15)
02d2b64c: mov     x1, x21                                    
02d2b650: mov     x3, xzr                                    
02d2b654: mov     x20, x0                                    
02d2b658: bl      #0x399ba10                                 fn_399ba10
02d2b65c: cbz     x19, #0x2d2b690                            
02d2b660: adrp    x8, #0x626a000                             
02d2b664: mov     x0, x19                                    
02d2b668: mov     x1, x20                                    
02d2b66c: ldr     x8, [x8, #0x388]                           MS:System.Collections.Generic.List`1::Find
02d2b670: ldr     x2, [x8]                                   T:type56879(k15)
02d2b674: bl      #0x35a9868                                 fn_35a9868
02d2b678: cbz     x0, #0x2d2b680                             
02d2b67c: ldr     w0, [x0, #0x14]                            [626a014]=0 f=0,0
02d2b680: ldp     x20, x19, [sp, #0x20]                      
02d2b684: ldp     x22, x21, [sp, #0x10]                      
02d2b688: ldr     x30, [sp], #0x30                           
02d2b68c: ret                                                
02d2b690: bl      #0x2b7105c                                 fn_2b7105c
## .ctor() -> void
---- DailyTask.DataDailyTask::.ctor 0x2d2c498
02d2c498: mov     x1, xzr                                    
02d2c49c: b       #0x2ca9988                                 GameData::.ctor
