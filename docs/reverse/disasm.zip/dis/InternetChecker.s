#### CLASS InternetChecker/<ICheckInternet>d__5 parent= object
#   field <>1__state                     int                                                off=0x10 attr=1 
#   field <>2__current                   object                                             off=0x18 attr=1 
#   field <>4__this                      InternetChecker                                    off=0x20 attr=6 
## .ctor(int <>1__state) -> void
---- InternetChecker/<ICheckInternet>d__5::.ctor 0x2ca3aa0
02ca3aa0: str     x30, [sp, #-0x20]!                         
02ca3aa4: stp     x20, x19, [sp, #0x10]                      
02ca3aa8: mov     w19, w1                                    
02ca3aac: mov     x1, xzr                                    
02ca3ab0: mov     x20, x0                                    
02ca3ab4: bl      #0x4e53e9c                                 System.Object::.ctor
02ca3ab8: str     w19, [x20, #0x10]                          .<>1__state
02ca3abc: ldp     x20, x19, [sp, #0x10]                      
02ca3ac0: ldr     x30, [sp], #0x20                           
02ca3ac4: ret                                                
## System.IDisposable.Dispose() -> void
---- InternetChecker/<ICheckInternet>d__5::System.IDisposable.Dispose 0x2ca3b2c
02ca3b2c: ret                                                
## MoveNext() -> bool
---- InternetChecker/<ICheckInternet>d__5::MoveNext 0x2ca3b30
02ca3b30: stp     x30, x21, [sp, #-0x20]!                    
02ca3b34: stp     x20, x19, [sp, #0x10]                      
02ca3b38: adrp    x20, #0x662f000                            
02ca3b3c: mov     x19, x0                                    
02ca3b40: ldrb    w8, [x20, #0xac1]                          
02ca3b44: tbnz    w8, #0, #0x2ca3b5c                         
02ca3b48: adrp    x0, #0x6265000                             
02ca3b4c: ldr     x0, [x0, #0xaa8]                           T:UnityEngine.WaitForSecondsRealtime
02ca3b50: bl      #0x2b70db0                                 fn_2b70db0
02ca3b54: mov     w8, #1                                     
02ca3b58: strb    w8, [x20, #0xac1]                          
02ca3b5c: ldr     w21, [x19, #0x10]                          .<>1__state
02ca3b60: cbz     w21, #0x2ca3ba8                            
02ca3b64: cmp     w21, #1                                    
02ca3b68: b.ne    #0x2ca3be8                                 
02ca3b6c: ldr     x20, [x19, #0x20]                          .<>4__this
02ca3b70: mov     w8, #-1                                    
02ca3b74: str     w8, [x19, #0x10]                           .<>1__state
02ca3b78: cbz     x20, #0x2ca3bfc                            
02ca3b7c: ldr     x19, [x20, #0x20]                          &2b706f0(=d65f03c0f9400800) .<>4__this
02ca3b80: bl      #0x2ca3ac8                                 InternetChecker::HasInternet
02ca3b84: cbz     x19, #0x2ca3bfc                            
02ca3b88: mov     w8, #1                                     
02ca3b8c: mov     x2, xzr                                    
02ca3b90: bic     w1, w8, w0                                 
02ca3b94: mov     x0, x19                                    
02ca3b98: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02ca3b9c: mov     x0, x20                                    
02ca3ba0: bl      #0x2ca39e0                                 InternetChecker::CheckInternetStatus
02ca3ba4: b       #0x2ca3be8                                 
02ca3ba8: adrp    x8, #0x6265000                             
02ca3bac: mov     w9, #-1                                    
02ca3bb0: ldr     x8, [x8, #0xaa8]                           T:UnityEngine.WaitForSecondsRealtime
02ca3bb4: str     w9, [x19, #0x10]                           .<>1__state
02ca3bb8: ldr     x0, [x8]                                   M:AdsManager::<OnApplicationPause>b__26_0
02ca3bbc: bl      #0x2b7104c                                 fn_2b7104c
02ca3bc0: fmov    s0, #3.00000000                            
02ca3bc4: mov     x1, xzr                                    
02ca3bc8: mov     x20, x0                                    
02ca3bcc: bl      #0x5b3e6e4                                 UnityEngine.WaitForSecondsRealtime::.ctor
02ca3bd0: mov     x0, x19                                    
02ca3bd4: mov     x1, x20                                    
02ca3bd8: str     x20, [x0, #0x18]!                          .<>2__current
02ca3bdc: bl      #0x2b70d54                                 fn_2b70d54
02ca3be0: mov     w8, #1                                     
02ca3be4: str     w8, [x19, #0x10]                           .<>1__state
02ca3be8: ldp     x20, x19, [sp, #0x10]                      
02ca3bec: cmp     w21, #0                                    
02ca3bf0: cset    w0, eq                                     
02ca3bf4: ldp     x30, x21, [sp], #0x20                      
02ca3bf8: ret                                                
02ca3bfc: bl      #0x2b7105c                                 fn_2b7105c
## System.Collections.Generic.IEnumerator<System.Object>.get_Current() -> object
---- InternetChecker/<ICheckInternet>d__5::System.Collections.Generic.IEnumerator<System.Object>.get_Current 0x2ca3c00
02ca3c00: ldr     x0, [x0, #0x18]                            .<>2__current
02ca3c04: ret                                                
## System.Collections.IEnumerator.Reset() -> void
---- InternetChecker/<ICheckInternet>d__5::System.Collections.IEnumerator.Reset 0x2ca3c08
02ca3c08: stp     x30, x19, [sp, #-0x10]!                    
02ca3c0c: adrp    x0, #0x6264000                             
02ca3c10: ldr     x0, [x0, #0xf60]                           T:System.NotSupportedException
02ca3c14: bl      #0x2b70dc4                                 fn_2b70dc4
02ca3c18: bl      #0x2b7104c                                 fn_2b7104c
02ca3c1c: mov     x1, xzr                                    
02ca3c20: mov     x19, x0                                    
02ca3c24: bl      #0x4e14238                                 System.NotSupportedException::.ctor
02ca3c28: adrp    x0, #0x6266000                             
02ca3c2c: ldr     x0, [x0, #0x120]                           M:InternetChecker/<ICheckInternet>d__5::System.Collections.IEnumerator.Reset
02ca3c30: bl      #0x2b70dc4                                 fn_2b70dc4
02ca3c34: mov     x1, x0                                     
02ca3c38: mov     x0, x19                                    
02ca3c3c: bl      #0x2b70f20                                 fn_2b70f20
## System.Collections.IEnumerator.get_Current() -> object
---- InternetChecker/<ICheckInternet>d__5::System.Collections.IEnumerator.get_Current 0x2ca3c40
02ca3c40: ldr     x0, [x0, #0x18]                            .<>2__current
02ca3c44: ret                                                
#### CLASS InternetChecker parent= UnityEngine.MonoBehaviour
#   field CheckTime                      int                                                off=0x0 attr=8051 
#   field _goView                        UnityEngine.GameObject                             off=0x20 attr=1 SerializeField
#   field _coroutineCheck                UnityEngine.Coroutine                              off=0x28 attr=1 
## Start() -> void
---- InternetChecker::Start 0x2ca39b4
02ca39b4: stp     x30, x19, [sp, #-0x10]!                    
02ca39b8: mov     x19, x0                                    
02ca39bc: ldr     x0, [x0, #0x20]                            ._goView
02ca39c0: cbz     x0, #0x2ca39dc                             
02ca39c4: mov     w1, wzr                                    
02ca39c8: mov     x2, xzr                                    
02ca39cc: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02ca39d0: mov     x0, x19                                    
02ca39d4: ldp     x30, x19, [sp], #0x10                      
02ca39d8: b       #0x2ca39e0                                 InternetChecker::CheckInternetStatus
02ca39dc: bl      #0x2b7105c                                 fn_2b7105c
## CheckInternetStatus() -> void
---- InternetChecker::CheckInternetStatus 0x2ca39e0
02ca39e0: str     x30, [sp, #-0x20]!                         
02ca39e4: stp     x20, x19, [sp, #0x10]                      
02ca39e8: mov     x20, x0                                    
02ca39ec: mov     x19, x0                                    
02ca39f0: ldr     x1, [x20, #0x28]!                          ._coroutineCheck
02ca39f4: cbz     x1, #0x2ca3a04                             
02ca39f8: mov     x0, x19                                    
02ca39fc: mov     x2, xzr                                    
02ca3a00: bl      #0x5b38c4c                                 UnityEngine.MonoBehaviour::StopCoroutine
02ca3a04: mov     x0, x19                                    
02ca3a08: bl      #0x2ca3a34                                 InternetChecker::ICheckInternet
02ca3a0c: mov     x1, x0                                     
02ca3a10: mov     x0, x19                                    
02ca3a14: mov     x2, xzr                                    
02ca3a18: bl      #0x5b389f0                                 UnityEngine.MonoBehaviour::StartCoroutine
02ca3a1c: mov     x1, x0                                     
02ca3a20: mov     x0, x20                                    
02ca3a24: str     x1, [x19, #0x28]                           ._coroutineCheck
02ca3a28: ldp     x20, x19, [sp, #0x10]                      
02ca3a2c: ldr     x30, [sp], #0x20                           
02ca3a30: b       #0x2b70d54                                 
## ICheckInternet() -> System.Collections.IEnumerator
---- InternetChecker::ICheckInternet 0x2ca3a34
02ca3a34: stp     x30, x21, [sp, #-0x20]!                    
02ca3a38: stp     x20, x19, [sp, #0x10]                      
02ca3a3c: adrp    x20, #0x662f000                            
02ca3a40: adrp    x21, #0x6266000                            
02ca3a44: mov     x19, x0                                    
02ca3a48: ldrb    w8, [x20, #0xabf]                          
02ca3a4c: ldr     x21, [x21, #0x118]                         T:InternetChecker/<ICheckInternet>d__5
02ca3a50: tbnz    w8, #0, #0x2ca3a68                         
02ca3a54: adrp    x0, #0x6266000                             
02ca3a58: ldr     x0, [x0, #0x118]                           T:InternetChecker/<ICheckInternet>d__5
02ca3a5c: bl      #0x2b70db0                                 fn_2b70db0
02ca3a60: mov     w8, #1                                     
02ca3a64: strb    w8, [x20, #0xabf]                          
02ca3a68: ldr     x0, [x21]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca3a6c: bl      #0x2b7104c                                 fn_2b7104c
02ca3a70: mov     x1, xzr                                    
02ca3a74: mov     x20, x0                                    
02ca3a78: bl      #0x4e53e9c                                 System.Object::.ctor
02ca3a7c: mov     x0, x20                                    
02ca3a80: mov     x1, x19                                    
02ca3a84: str     wzr, [x20, #0x10]                          
02ca3a88: str     x19, [x0, #0x20]!                          ._goView
02ca3a8c: bl      #0x2b70d54                                 fn_2b70d54
02ca3a90: mov     x0, x20                                    
02ca3a94: ldp     x20, x19, [sp, #0x10]                      
02ca3a98: ldp     x30, x21, [sp], #0x20                      
02ca3a9c: ret                                                
## HasInternet() -> bool
---- InternetChecker::HasInternet 0x2ca3ac8
02ca3ac8: str     x30, [sp, #-0x20]!                         
02ca3acc: stp     x20, x19, [sp, #0x10]                      
02ca3ad0: adrp    x19, #0x662f000                            
02ca3ad4: adrp    x20, #0x6264000                            
02ca3ad8: ldrb    w8, [x19, #0xac0]                          
02ca3adc: ldr     x20, [x20, #0xa70]                         T:UnityEngine.Application
02ca3ae0: tbnz    w8, #0, #0x2ca3af8                         
02ca3ae4: adrp    x0, #0x6264000                             
02ca3ae8: ldr     x0, [x0, #0xa70]                           T:UnityEngine.Application
02ca3aec: bl      #0x2b70db0                                 fn_2b70db0
02ca3af0: mov     w8, #1                                     
02ca3af4: strb    w8, [x19, #0xac0]                          
02ca3af8: ldr     x0, [x20]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02ca3afc: ldr     w8, [x0, #0xe4]                            [62640e4]=0 f=0,0
02ca3b00: cbnz    w8, #0x2ca3b08                             
02ca3b04: bl      #0x2b70f30                                 fn_2b70f30
02ca3b08: mov     x0, xzr                                    
02ca3b0c: bl      #0x5aeb318                                 UnityEngine.Application::get_internetReachability
02ca3b10: ldp     x20, x19, [sp, #0x10]                      
02ca3b14: cmp     w0, #0                                     
02ca3b18: cset    w0, ne                                     
02ca3b1c: ldr     x30, [sp], #0x20                           
02ca3b20: ret                                                
## .ctor() -> void
---- InternetChecker::.ctor 0x2ca3b24
02ca3b24: mov     x1, xzr                                    
02ca3b28: b       #0x5b397b0                                 UnityEngine.MonoBehaviour::.ctor
