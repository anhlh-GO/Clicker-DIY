#### CLASS Framework.RangedInt parent= System.ValueType
#   field min                            int                                                off=0x10 attr=6 
#   field max                            int                                                off=0x14 attr=6 
## .ctor(int min, int max) -> void
---- Framework.RangedInt::.ctor 0x2cb840c
02cb840c: stp     w1, w2, [x0]                               
02cb8410: ret                                                
