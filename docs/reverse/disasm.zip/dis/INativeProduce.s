#### CLASS INativeProduce parent= None
##  SetAdFormat (no body)
