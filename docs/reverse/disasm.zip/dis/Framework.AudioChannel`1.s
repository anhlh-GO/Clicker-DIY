#### CLASS Framework.AudioChannel`1/<>c__DisplayClass13_0 parent= object
#   field <>4__this                      Framework.AudioChannel`1<T>                        off=0x0 attr=6 
#   field volume                         float                                              off=0x0 attr=6 
##  .ctor (no body)
##  <FadePlay>b__0 (no body)
##  <FadePlay>b__1 (no body)
##  <FadePlay>b__2 (no body)
#### CLASS Framework.AudioChannel`1 parent= object
#   field ChannelId                      string                                             off=0x0 attr=6 
#   field PlayKey                        string                                             off=0x0 attr=6 
#   field AudioKey                       T                                                  off=0x0 attr=6 
#   field IsPlay                         bool                                               off=0x0 attr=6 
#   field Source                         UnityEngine.AudioSource                            off=0x0 attr=6 
#   field IsTaken                        bool                                               off=0x0 attr=6 
#   field IsBorrow                       bool                                               off=0x0 attr=6 
#   field _autoStopTween                 DG.Tweening.Tween                                  off=0x0 attr=1 
##  get_IsMute (no body)
##  set_IsMute (no body)
##  .ctor (no body)
##  Play (no body)
##  FadePlay (no body)
##  Stop (no body)
##  FadeStop (no body)
##  <Play>b__12_0 (no body)
##  <Play>b__12_1 (no body)
##  <FadeStop>b__15_0 (no body)
