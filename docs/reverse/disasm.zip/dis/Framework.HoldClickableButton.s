#### CLASS Framework.HoldClickableButton parent= UnityEngine.MonoBehaviour
#   field _holdDuration                  float                                              off=0x20 attr=1 SerializeField
#   field OnClicked                      System.Action                                      off=0x28 attr=1 CompilerGeneratedAttribute
#   field OnHoldClicked                  System.Action                                      off=0x30 attr=1 CompilerGeneratedAttribute
#   field _isHoldingButton               bool                                               off=0x38 attr=1 
#   field _elapsedTime                   float                                              off=0x3c attr=1 
## add_OnClicked(System.Action value) -> void
---- Framework.HoldClickableButton::add_OnClicked 0x2cc3fb8
02cc3fb8: str     x30, [sp, #-0x30]!                         
02cc3fbc: stp     x22, x21, [sp, #0x10]                      
02cc3fc0: stp     x20, x19, [sp, #0x20]                      
02cc3fc4: adrp    x21, #0x662f000                            
02cc3fc8: mov     x19, x1                                    
02cc3fcc: mov     x20, x0                                    
02cc3fd0: ldrb    w8, [x21, #0xc39]                          
02cc3fd4: tbnz    w8, #0, #0x2cc3fec                         
02cc3fd8: adrp    x0, #0x6264000                             
02cc3fdc: ldr     x0, [x0, #0xf90]                           T:System.Action
02cc3fe0: bl      #0x2b70db0                                 fn_2b70db0
02cc3fe4: mov     w8, #1                                     
02cc3fe8: strb    w8, [x21, #0xc39]                          
02cc3fec: adrp    x22, #0x6264000                            
02cc3ff0: ldr     x22, [x22, #0xf90]                         T:System.Action
02cc3ff4: ldr     x21, [x20, #0x28]!                         .OnClicked
02cc3ff8: mov     x0, x21                                    
02cc3ffc: mov     x1, x19                                    
02cc4000: mov     x2, xzr                                    
02cc4004: bl      #0x4e570ac                                 System.Delegate::Combine
02cc4008: mov     x8, x0                                     
02cc400c: cbz     x0, #0x2cc4020                             
02cc4010: ldr     x1, [x22]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02cc4014: ldr     x9, [x8]                                   
02cc4018: cmp     x9, x1                                     
02cc401c: b.ne    #0x2cc404c                                 
02cc4020: mov     x0, x20                                    
02cc4024: mov     x1, x8                                     
02cc4028: mov     x2, x21                                    
02cc402c: bl      #0x2ba9880                                 fn_2ba9880
02cc4030: cmp     x0, x21                                    
02cc4034: mov     x21, x0                                    
02cc4038: b.ne    #0x2cc3ff8                                 
02cc403c: ldp     x20, x19, [sp, #0x20]                      
02cc4040: ldp     x22, x21, [sp, #0x10]                      
02cc4044: ldr     x30, [sp], #0x30                           
02cc4048: ret                                                
02cc404c: mov     x0, x8                                     
02cc4050: bl      #0x2b713dc                                 fn_2b713dc
## remove_OnClicked(System.Action value) -> void
---- Framework.HoldClickableButton::remove_OnClicked 0x2cc4054
02cc4054: str     x30, [sp, #-0x30]!                         
02cc4058: stp     x22, x21, [sp, #0x10]                      
02cc405c: stp     x20, x19, [sp, #0x20]                      
02cc4060: adrp    x21, #0x662f000                            
02cc4064: mov     x19, x1                                    
02cc4068: mov     x20, x0                                    
02cc406c: ldrb    w8, [x21, #0xc3a]                          
02cc4070: tbnz    w8, #0, #0x2cc4088                         
02cc4074: adrp    x0, #0x6264000                             
02cc4078: ldr     x0, [x0, #0xf90]                           T:System.Action
02cc407c: bl      #0x2b70db0                                 fn_2b70db0
02cc4080: mov     w8, #1                                     
02cc4084: strb    w8, [x21, #0xc3a]                          
02cc4088: adrp    x22, #0x6264000                            
02cc408c: ldr     x22, [x22, #0xf90]                         T:System.Action
02cc4090: ldr     x21, [x20, #0x28]!                         .OnClicked
02cc4094: mov     x0, x21                                    
02cc4098: mov     x1, x19                                    
02cc409c: mov     x2, xzr                                    
02cc40a0: bl      #0x4e57298                                 System.Delegate::Remove
02cc40a4: mov     x8, x0                                     
02cc40a8: cbz     x0, #0x2cc40bc                             
02cc40ac: ldr     x1, [x22]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02cc40b0: ldr     x9, [x8]                                   
02cc40b4: cmp     x9, x1                                     
02cc40b8: b.ne    #0x2cc40e8                                 
02cc40bc: mov     x0, x20                                    
02cc40c0: mov     x1, x8                                     
02cc40c4: mov     x2, x21                                    
02cc40c8: bl      #0x2ba9880                                 fn_2ba9880
02cc40cc: cmp     x0, x21                                    
02cc40d0: mov     x21, x0                                    
02cc40d4: b.ne    #0x2cc4094                                 
02cc40d8: ldp     x20, x19, [sp, #0x20]                      
02cc40dc: ldp     x22, x21, [sp, #0x10]                      
02cc40e0: ldr     x30, [sp], #0x30                           
02cc40e4: ret                                                
02cc40e8: mov     x0, x8                                     
02cc40ec: bl      #0x2b713dc                                 fn_2b713dc
## add_OnHoldClicked(System.Action value) -> void
---- Framework.HoldClickableButton::add_OnHoldClicked 0x2cc40f0
02cc40f0: str     x30, [sp, #-0x30]!                         
02cc40f4: stp     x22, x21, [sp, #0x10]                      
02cc40f8: stp     x20, x19, [sp, #0x20]                      
02cc40fc: adrp    x21, #0x662f000                            
02cc4100: mov     x19, x1                                    
02cc4104: mov     x20, x0                                    
02cc4108: ldrb    w8, [x21, #0xc3b]                          
02cc410c: tbnz    w8, #0, #0x2cc4124                         
02cc4110: adrp    x0, #0x6264000                             
02cc4114: ldr     x0, [x0, #0xf90]                           T:System.Action
02cc4118: bl      #0x2b70db0                                 fn_2b70db0
02cc411c: mov     w8, #1                                     
02cc4120: strb    w8, [x21, #0xc3b]                          
02cc4124: adrp    x22, #0x6264000                            
02cc4128: ldr     x22, [x22, #0xf90]                         T:System.Action
02cc412c: ldr     x21, [x20, #0x30]!                         .OnHoldClicked
02cc4130: mov     x0, x21                                    
02cc4134: mov     x1, x19                                    
02cc4138: mov     x2, xzr                                    
02cc413c: bl      #0x4e570ac                                 System.Delegate::Combine
02cc4140: mov     x8, x0                                     
02cc4144: cbz     x0, #0x2cc4158                             
02cc4148: ldr     x1, [x22]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02cc414c: ldr     x9, [x8]                                   
02cc4150: cmp     x9, x1                                     
02cc4154: b.ne    #0x2cc4184                                 
02cc4158: mov     x0, x20                                    
02cc415c: mov     x1, x8                                     
02cc4160: mov     x2, x21                                    
02cc4164: bl      #0x2ba9880                                 fn_2ba9880
02cc4168: cmp     x0, x21                                    
02cc416c: mov     x21, x0                                    
02cc4170: b.ne    #0x2cc4130                                 
02cc4174: ldp     x20, x19, [sp, #0x20]                      
02cc4178: ldp     x22, x21, [sp, #0x10]                      
02cc417c: ldr     x30, [sp], #0x30                           
02cc4180: ret                                                
02cc4184: mov     x0, x8                                     
02cc4188: bl      #0x2b713dc                                 fn_2b713dc
## remove_OnHoldClicked(System.Action value) -> void
---- Framework.HoldClickableButton::remove_OnHoldClicked 0x2cc418c
02cc418c: str     x30, [sp, #-0x30]!                         
02cc4190: stp     x22, x21, [sp, #0x10]                      
02cc4194: stp     x20, x19, [sp, #0x20]                      
02cc4198: adrp    x21, #0x662f000                            
02cc419c: mov     x19, x1                                    
02cc41a0: mov     x20, x0                                    
02cc41a4: ldrb    w8, [x21, #0xc3c]                          
02cc41a8: tbnz    w8, #0, #0x2cc41c0                         
02cc41ac: adrp    x0, #0x6264000                             
02cc41b0: ldr     x0, [x0, #0xf90]                           T:System.Action
02cc41b4: bl      #0x2b70db0                                 fn_2b70db0
02cc41b8: mov     w8, #1                                     
02cc41bc: strb    w8, [x21, #0xc3c]                          
02cc41c0: adrp    x22, #0x6264000                            
02cc41c4: ldr     x22, [x22, #0xf90]                         T:System.Action
02cc41c8: ldr     x21, [x20, #0x30]!                         .OnHoldClicked
02cc41cc: mov     x0, x21                                    
02cc41d0: mov     x1, x19                                    
02cc41d4: mov     x2, xzr                                    
02cc41d8: bl      #0x4e57298                                 System.Delegate::Remove
02cc41dc: mov     x8, x0                                     
02cc41e0: cbz     x0, #0x2cc41f4                             
02cc41e4: ldr     x1, [x22]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02cc41e8: ldr     x9, [x8]                                   
02cc41ec: cmp     x9, x1                                     
02cc41f0: b.ne    #0x2cc4220                                 
02cc41f4: mov     x0, x20                                    
02cc41f8: mov     x1, x8                                     
02cc41fc: mov     x2, x21                                    
02cc4200: bl      #0x2ba9880                                 fn_2ba9880
02cc4204: cmp     x0, x21                                    
02cc4208: mov     x21, x0                                    
02cc420c: b.ne    #0x2cc41cc                                 
02cc4210: ldp     x20, x19, [sp, #0x20]                      
02cc4214: ldp     x22, x21, [sp, #0x10]                      
02cc4218: ldr     x30, [sp], #0x30                           
02cc421c: ret                                                
02cc4220: mov     x0, x8                                     
02cc4224: bl      #0x2b713dc                                 fn_2b713dc
## OnPointerDown(UnityEngine.EventSystems.PointerEventData eventData) -> void
---- Framework.HoldClickableButton::OnPointerDown 0x2cc4228
02cc4228: mov     w8, #1                                     
02cc422c: str     wzr, [x0, #0x3c]                           ._elapsedTime
02cc4230: strb    w8, [x0, #0x38]                            ._isHoldingButton
02cc4234: ret                                                
## ToggleHoldingButton(bool isPointerDown) -> void
---- Framework.HoldClickableButton::ToggleHoldingButton 0x2cc4238
02cc4238: strb    w1, [x0, #0x38]                            ._isHoldingButton
02cc423c: tbz     w1, #0, #0x2cc4244                         
02cc4240: str     wzr, [x0, #0x3c]                           ._elapsedTime
02cc4244: ret                                                
## OnPointerUp(UnityEngine.EventSystems.PointerEventData eventData) -> void
---- Framework.HoldClickableButton::OnPointerUp 0x2cc4248
02cc4248: stp     x30, x19, [sp, #-0x10]!                    
02cc424c: ldrb    w8, [x0, #0x38]                            ._isHoldingButton
02cc4250: mov     x19, x0                                    
02cc4254: cbz     w8, #0x2cc4270                             
02cc4258: ldr     x8, [x19, #0x28]                           .OnClicked
02cc425c: cbz     x8, #0x2cc4270                             
02cc4260: ldr     x9, [x8, #0x18]                            
02cc4264: ldr     x0, [x8, #0x40]                            
02cc4268: ldr     x1, [x8, #0x28]                            
02cc426c: blr     x9                                         
02cc4270: strb    wzr, [x19, #0x38]                          ._isHoldingButton
02cc4274: ldp     x30, x19, [sp], #0x10                      
02cc4278: ret                                                
## ManageButtonInteraction(bool isPointerUp) -> void
---- Framework.HoldClickableButton::ManageButtonInteraction 0x2cc427c
02cc427c: str     d8, [sp, #-0x20]!                          
02cc4280: stp     x30, x19, [sp, #0x10]                      
02cc4284: ldrb    w8, [x0, #0x38]                            ._isHoldingButton
02cc4288: cbz     w8, #0x2cc42e4                             
02cc428c: mov     x19, x0                                    
02cc4290: tbz     w1, #0, #0x2cc42a0                         
02cc4294: ldr     x8, [x19, #0x28]                           .OnClicked
02cc4298: cbnz    x8, #0x2cc42cc                             
02cc429c: b       #0x2cc42e4                                 
02cc42a0: ldr     s8, [x19, #0x3c]                           ._elapsedTime
02cc42a4: mov     x0, xzr                                    
02cc42a8: bl      #0x5b433a4                                 UnityEngine.Time::get_deltaTime
02cc42ac: fadd    s0, s8, s0                                 
02cc42b0: ldr     s1, [x19, #0x20]                           ._holdDuration
02cc42b4: fcmp    s0, s1                                     
02cc42b8: str     s0, [x19, #0x3c]                           ._elapsedTime
02cc42bc: b.le    #0x2cc42e4                                 
02cc42c0: ldr     x8, [x19, #0x30]                           .OnHoldClicked
02cc42c4: strb    wzr, [x19, #0x38]                          ._isHoldingButton
02cc42c8: cbz     x8, #0x2cc42e4                             
02cc42cc: ldp     x30, x19, [sp, #0x10]                      
02cc42d0: ldr     x0, [x8, #0x40]                            
02cc42d4: ldr     x1, [x8, #0x28]                            
02cc42d8: ldr     x2, [x8, #0x18]                            
02cc42dc: ldr     d8, [sp], #0x20                            
02cc42e0: br      x2                                         
02cc42e4: ldp     x30, x19, [sp, #0x10]                      
02cc42e8: ldr     d8, [sp], #0x20                            
02cc42ec: ret                                                
## Click() -> void
---- Framework.HoldClickableButton::Click 0x2cc42f0
02cc42f0: ldr     x8, [x0, #0x28]                            .OnClicked
02cc42f4: cbz     x8, #0x2cc4308                             
02cc42f8: ldr     x0, [x8, #0x40]                            
02cc42fc: ldr     x1, [x8, #0x28]                            
02cc4300: ldr     x2, [x8, #0x18]                            
02cc4304: br      x2                                         
02cc4308: ret                                                
## HoldClick() -> void
---- Framework.HoldClickableButton::HoldClick 0x2cc430c
02cc430c: ldr     x8, [x0, #0x30]                            .OnHoldClicked
02cc4310: strb    wzr, [x0, #0x38]                           ._isHoldingButton
02cc4314: cbz     x8, #0x2cc4328                             
02cc4318: ldr     x0, [x8, #0x40]                            
02cc431c: ldr     x1, [x8, #0x28]                            
02cc4320: ldr     x2, [x8, #0x18]                            
02cc4324: br      x2                                         
02cc4328: ret                                                
## Update() -> void
---- Framework.HoldClickableButton::Update 0x2cc432c
02cc432c: mov     w1, wzr                                    
02cc4330: b       #0x2cc427c                                 Framework.HoldClickableButton::ManageButtonInteraction
## .ctor() -> void
---- Framework.HoldClickableButton::.ctor 0x2cc4334
02cc4334: mov     x1, xzr                                    
02cc4338: b       #0x5b397b0                                 UnityEngine.MonoBehaviour::.ctor
