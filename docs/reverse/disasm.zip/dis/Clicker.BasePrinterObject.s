#### CLASS Clicker.BasePrinterObject parent= UnityEngine.MonoBehaviour
#   field _tfTop                         UnityEngine.Transform                              off=0x20 attr=1 SerializeField
#   field _tfBottom                      UnityEngine.Transform                              off=0x28 attr=1 SerializeField
## get_Top() -> UnityEngine.Transform
---- Clicker.BasePrinterObject::get_Top 0x2d61730
02d61730: ldr     x0, [x0, #0x20]                            ._tfTop
02d61734: ret                                                
## get_Bottom() -> UnityEngine.Transform
---- Clicker.BasePrinterObject::get_Bottom 0x2d61738
02d61738: ldr     x0, [x0, #0x28]                            ._tfBottom
02d6173c: ret                                                
## .ctor() -> void
---- Clicker.BasePrinterObject::.ctor 0x2d61740
02d61740: mov     x1, xzr                                    
02d61744: b       #0x5b397b0                                 UnityEngine.MonoBehaviour::.ctor
