#### CLASS DailyReward.SpecialDayItem parent= DailyMission.DailyItemBase
#   field _goCheckBox                    UnityEngine.GameObject                             off=0x68 attr=1 SerializeField
## SetUpData() -> void
---- DailyReward.SpecialDayItem::SetUpData 0x2cf3dd8
02cf3dd8: stp     x30, x19, [sp, #-0x10]!                    
02cf3ddc: mov     x1, xzr                                    
02cf3de0: mov     x19, x0                                    
02cf3de4: bl      #0x2d7652c                                 DailyMission.DailyItemBase::SetUpData
02cf3de8: ldr     x0, [x19, #0x68]                           ._goCheckBox
02cf3dec: cbz     x0, #0x2cf3e00                             
02cf3df0: mov     w1, wzr                                    
02cf3df4: mov     x2, xzr                                    
02cf3df8: ldp     x30, x19, [sp], #0x10                      
02cf3dfc: b       #0x5b36b38                                 UnityEngine.GameObject::SetActive
02cf3e00: bl      #0x2b7105c                                 fn_2b7105c
## OnRefresh() -> void
---- DailyReward.SpecialDayItem::OnRefresh 0x2cf3e04
02cf3e04: stp     x30, x19, [sp, #-0x10]!                    
02cf3e08: mov     x1, xzr                                    
02cf3e0c: mov     x19, x0                                    
02cf3e10: bl      #0x2d76530                                 DailyMission.DailyItemBase::OnRefresh
02cf3e14: mov     x0, x19                                    
02cf3e18: mov     x1, xzr                                    
02cf3e1c: bl      #0x2d7675c                                 DailyMission.DailyItemBase::GetStatus
02cf3e20: mov     w1, w0                                     
02cf3e24: mov     x0, x19                                    
02cf3e28: ldp     x30, x19, [sp], #0x10                      
02cf3e2c: b       #0x2cf3e30                                 DailyReward.SpecialDayItem::EnableIcon
## EnableIcon(DailyMission.DailyItemStatus status) -> void
---- DailyReward.SpecialDayItem::EnableIcon 0x2cf3e30
02cf3e30: cmp     w1, #1                                     
02cf3e34: b.ne    #0x2cf3e4c                                 
02cf3e38: ldr     x0, [x0, #0x68]                            ._goCheckBox
02cf3e3c: cbz     x0, #0x2cf3e50                             
02cf3e40: mov     w1, #1                                     
02cf3e44: mov     x2, xzr                                    
02cf3e48: b       #0x5b36b38                                 UnityEngine.GameObject::SetActive
02cf3e4c: ret                                                
02cf3e50: str     x30, [sp, #-0x10]!                         
02cf3e54: bl      #0x2b7105c                                 fn_2b7105c
## .ctor() -> void
---- DailyReward.SpecialDayItem::.ctor 0x2cf3e58
02cf3e58: mov     x1, xzr                                    
02cf3e5c: b       #0x2d770f4                                 DailyMission.DailyItemBase::.ctor
