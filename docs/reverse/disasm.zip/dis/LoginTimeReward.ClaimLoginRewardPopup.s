#### CLASS LoginTimeReward.ClaimLoginRewardPopup parent= PopupBase
#   field _unlockCharmContent            UnityEngine.GameObject                             off=0x38 attr=1 SerializeField
#   field _unlockDecorContent            UnityEngine.GameObject                             off=0x40 attr=1 SerializeField
#   field _imgDecorKeycap                UnityEngine.UI.Image                               off=0x48 attr=1 SerializeField
#   field _imgSkinDecor                  UnityEngine.UI.Image                               off=0x50 attr=1 SerializeField
#   field _btnClose                      UnityEngine.UI.Button                              off=0x58 attr=1 SerializeField
#   field _btnCollectKeycap              UnityEngine.UI.Button                              off=0x60 attr=1 SerializeField
#   field _btnClaimSkinDecor             UnityEngine.UI.Button                              off=0x68 attr=1 SerializeField
#   field _tfPanel                       UnityEngine.Transform                              off=0x70 attr=1 SerializeField
#   field _imgSkinDecorAnim              UnityEngine.UI.Image                               off=0x78 attr=1 HeaderAttribute,SerializeField
#   field _skinDecorHolder               UnityEngine.Transform                              off=0x80 attr=1 SerializeField
#   field _skinDecorStartPos             UnityEngine.Transform                              off=0x88 attr=1 SerializeField
#   field _tfButtonDecorAtHome           UnityEngine.Transform                              off=0x90 attr=1 SerializeField
#   field _tfButtonDecor                 UnityEngine.Transform                              off=0x98 attr=1 SerializeField
#   field _goBackgroundAnim              UnityEngine.GameObject                             off=0xa0 attr=1 SerializeField
#   field _isShowSkinContent             bool                                               off=0xa8 attr=1 
## OnInit(UIManager uiManager) -> void
---- LoginTimeReward.ClaimLoginRewardPopup::OnInit 0x2d58eec
02d58eec: str     x30, [sp, #-0x30]!                         
02d58ef0: stp     x22, x21, [sp, #0x10]                      
02d58ef4: stp     x20, x19, [sp, #0x20]                      
02d58ef8: adrp    x21, #0x6630000                            
02d58efc: mov     x20, x1                                    
02d58f00: mov     x19, x0                                    
02d58f04: ldrb    w8, [x21, #0x2a9]                          
02d58f08: tbnz    w8, #0, #0x2d58f44                         
02d58f0c: adrp    x0, #0x626b000                             
02d58f10: ldr     x0, [x0, #0xaf0]                           M:LoginTimeReward.ClaimLoginRewardPopup::OnClickBtnClaimSkinDecor
02d58f14: bl      #0x2b70db0                                 fn_2b70db0
02d58f18: adrp    x0, #0x626b000                             
02d58f1c: ldr     x0, [x0, #0xaf8]                           M:LoginTimeReward.ClaimLoginRewardPopup::OnClickBtnClose
02d58f20: bl      #0x2b70db0                                 fn_2b70db0
02d58f24: adrp    x0, #0x626b000                             
02d58f28: ldr     x0, [x0, #0xb00]                           M:LoginTimeReward.ClaimLoginRewardPopup::OnClickBtnCollectKeycap
02d58f2c: bl      #0x2b70db0                                 fn_2b70db0
02d58f30: adrp    x0, #0x6265000                             
02d58f34: ldr     x0, [x0, #0x3f0]                           T:UnityEngine.Events.UnityAction
02d58f38: bl      #0x2b70db0                                 fn_2b70db0
02d58f3c: mov     w8, #1                                     
02d58f40: strb    w8, [x21, #0x2a9]                          
02d58f44: mov     x0, x19                                    
02d58f48: mov     x1, x20                                    
02d58f4c: mov     x2, xzr                                    
02d58f50: bl      #0x2cdd3c4                                 UIBase::OnInit
02d58f54: ldr     x8, [x19, #0x58]                           ._btnClose
02d58f58: cbz     x8, #0x2d59054                             
02d58f5c: adrp    x22, #0x6265000                            
02d58f60: adrp    x21, #0x626b000                            
02d58f64: ldr     x22, [x22, #0x3f0]                         T:UnityEngine.Events.UnityAction
02d58f68: ldr     x21, [x21, #0xaf8]                         M:LoginTimeReward.ClaimLoginRewardPopup::OnClickBtnClose
02d58f6c: ldr     x20, [x8, #0x100]                          
02d58f70: ldr     x0, [x22]                                  M:AdsManager::<OnApplicationPause>b__26_0
02d58f74: bl      #0x2b7104c                                 fn_2b7104c
02d58f78: ldr     x2, [x21]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d58f7c: mov     x1, x19                                    
02d58f80: mov     x3, xzr                                    
02d58f84: mov     x21, x0                                    
02d58f88: bl      #0x5b4cf98                                 UnityEngine.Events.UnityAction::.ctor
02d58f8c: cbz     x20, #0x2d59054                            
02d58f90: mov     x0, x20                                    
02d58f94: mov     x1, x21                                    
02d58f98: mov     x2, xzr                                    
02d58f9c: bl      #0x5b4d0ac                                 UnityEngine.Events.UnityEvent::AddListener
02d58fa0: ldr     x8, [x19, #0x60]                           ._btnCollectKeycap
02d58fa4: cbz     x8, #0x2d59054                             
02d58fa8: adrp    x21, #0x626b000                            
02d58fac: ldr     x21, [x21, #0xb00]                         M:LoginTimeReward.ClaimLoginRewardPopup::OnClickBtnCollectKeycap
02d58fb0: ldr     x0, [x22]                                  M:AdsManager::<OnApplicationPause>b__26_0
02d58fb4: ldr     x20, [x8, #0x100]                          
02d58fb8: bl      #0x2b7104c                                 fn_2b7104c
02d58fbc: ldr     x2, [x21]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d58fc0: mov     x1, x19                                    
02d58fc4: mov     x3, xzr                                    
02d58fc8: mov     x21, x0                                    
02d58fcc: bl      #0x5b4cf98                                 UnityEngine.Events.UnityAction::.ctor
02d58fd0: cbz     x20, #0x2d59054                            
02d58fd4: mov     x0, x20                                    
02d58fd8: mov     x1, x21                                    
02d58fdc: mov     x2, xzr                                    
02d58fe0: bl      #0x5b4d0ac                                 UnityEngine.Events.UnityEvent::AddListener
02d58fe4: ldr     x8, [x19, #0x68]                           ._btnClaimSkinDecor
02d58fe8: cbz     x8, #0x2d59054                             
02d58fec: adrp    x21, #0x626b000                            
02d58ff0: ldr     x21, [x21, #0xaf0]                         M:LoginTimeReward.ClaimLoginRewardPopup::OnClickBtnClaimSkinDecor
02d58ff4: ldr     x0, [x22]                                  M:AdsManager::<OnApplicationPause>b__26_0
02d58ff8: ldr     x20, [x8, #0x100]                          
02d58ffc: bl      #0x2b7104c                                 fn_2b7104c
02d59000: ldr     x2, [x21]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d59004: mov     x1, x19                                    
02d59008: mov     x3, xzr                                    
02d5900c: mov     x21, x0                                    
02d59010: bl      #0x5b4cf98                                 UnityEngine.Events.UnityAction::.ctor
02d59014: cbz     x20, #0x2d59054                            
02d59018: mov     x0, x20                                    
02d5901c: mov     x1, x21                                    
02d59020: mov     x2, xzr                                    
02d59024: bl      #0x5b4d0ac                                 UnityEngine.Events.UnityEvent::AddListener
02d59028: ldr     x0, [x19, #0x80]                           ._skinDecorHolder
02d5902c: cbz     x0, #0x2d59054                             
02d59030: mov     x1, xzr                                    
02d59034: bl      #0x5b339ec                                 UnityEngine.Component::get_gameObject
02d59038: cbz     x0, #0x2d59054                             
02d5903c: ldp     x20, x19, [sp, #0x20]                      
02d59040: mov     w1, wzr                                    
02d59044: ldp     x22, x21, [sp, #0x10]                      
02d59048: mov     x2, xzr                                    
02d5904c: ldr     x30, [sp], #0x30                           
02d59050: b       #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d59054: bl      #0x2b7105c                                 fn_2b7105c
## ShowUnlockDecorKeycap(UnityEngine.Sprite sprite) -> void
---- LoginTimeReward.ClaimLoginRewardPopup::ShowUnlockDecorKeycap 0x2d59058
02d59058: str     x30, [sp, #-0x20]!                         
02d5905c: stp     x20, x19, [sp, #0x10]                      
02d59060: mov     x20, x0                                    
02d59064: ldr     x0, [x0, #0x38]                            ._unlockCharmContent
02d59068: cbz     x0, #0x2d590ec                             
02d5906c: mov     x19, x1                                    
02d59070: mov     w1, #1                                     
02d59074: mov     x2, xzr                                    
02d59078: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d5907c: ldr     x0, [x20, #0x40]                           ._unlockDecorContent
02d59080: cbz     x0, #0x2d590ec                             
02d59084: mov     w1, wzr                                    
02d59088: mov     x2, xzr                                    
02d5908c: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d59090: ldr     x0, [x20, #0x60]                           ._btnCollectKeycap
02d59094: cbz     x0, #0x2d590ec                             
02d59098: mov     x1, xzr                                    
02d5909c: bl      #0x5b339ec                                 UnityEngine.Component::get_gameObject
02d590a0: cbz     x0, #0x2d590ec                             
02d590a4: mov     w1, #1                                     
02d590a8: mov     x2, xzr                                    
02d590ac: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d590b0: ldr     x0, [x20, #0x68]                           ._btnClaimSkinDecor
02d590b4: cbz     x0, #0x2d590ec                             
02d590b8: mov     x1, xzr                                    
02d590bc: bl      #0x5b339ec                                 UnityEngine.Component::get_gameObject
02d590c0: cbz     x0, #0x2d590ec                             
02d590c4: mov     w1, wzr                                    
02d590c8: mov     x2, xzr                                    
02d590cc: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d590d0: ldr     x0, [x20, #0x48]                           ._imgDecorKeycap
02d590d4: cbz     x0, #0x2d590ec                             
02d590d8: mov     x1, x19                                    
02d590dc: ldp     x20, x19, [sp, #0x10]                      
02d590e0: mov     x2, xzr                                    
02d590e4: ldr     x30, [sp], #0x20                           
02d590e8: b       #0x5c45aa0                                 UnityEngine.UI.Image::set_sprite
02d590ec: bl      #0x2b7105c                                 fn_2b7105c
## ShowDecorSkinContent(int id) -> void
---- LoginTimeReward.ClaimLoginRewardPopup::ShowDecorSkinContent 0x2d590f0
02d590f0: stp     x30, x21, [sp, #-0x20]!                    
02d590f4: stp     x20, x19, [sp, #0x10]                      
02d590f8: adrp    x21, #0x6630000                            
02d590fc: mov     w20, w1                                    
02d59100: mov     x19, x0                                    
02d59104: ldrb    w8, [x21, #0x2aa]                          
02d59108: tbnz    w8, #0, #0x2d5912c                         
02d5910c: adrp    x0, #0x6266000                             
02d59110: ldr     x0, [x0, #0x870]                           MS:DataManager::GetAsset
02d59114: bl      #0x2b70db0                                 fn_2b70db0
02d59118: adrp    x0, #0x6266000                             
02d5911c: ldr     x0, [x0, #0x658]                           MS:MonoSingleton`1::get_Instance
02d59120: bl      #0x2b70db0                                 fn_2b70db0
02d59124: mov     w8, #1                                     
02d59128: strb    w8, [x21, #0x2aa]                          
02d5912c: ldr     x0, [x19, #0x38]                           ._unlockCharmContent
02d59130: cbz     x0, #0x2d5921c                             
02d59134: mov     w1, wzr                                    
02d59138: mov     x2, xzr                                    
02d5913c: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d59140: ldr     x0, [x19, #0x40]                           ._unlockDecorContent
02d59144: cbz     x0, #0x2d5921c                             
02d59148: mov     w1, #1                                     
02d5914c: mov     x2, xzr                                    
02d59150: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d59154: ldr     x0, [x19, #0x60]                           ._btnCollectKeycap
02d59158: cbz     x0, #0x2d5921c                             
02d5915c: mov     x1, xzr                                    
02d59160: bl      #0x5b339ec                                 UnityEngine.Component::get_gameObject
02d59164: cbz     x0, #0x2d5921c                             
02d59168: mov     w1, wzr                                    
02d5916c: mov     x2, xzr                                    
02d59170: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d59174: ldr     x0, [x19, #0x68]                           ._btnClaimSkinDecor
02d59178: cbz     x0, #0x2d5921c                             
02d5917c: mov     x1, xzr                                    
02d59180: bl      #0x5b339ec                                 UnityEngine.Component::get_gameObject
02d59184: cbz     x0, #0x2d5921c                             
02d59188: adrp    x21, #0x6266000                            
02d5918c: mov     w1, #1                                     
02d59190: mov     x2, xzr                                    
02d59194: ldr     x21, [x21, #0x658]                         MS:MonoSingleton`1::get_Instance
02d59198: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d5919c: ldr     x0, [x21]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d591a0: bl      #0x3769600                                 fn_3769600
02d591a4: cbz     x0, #0x2d5921c                             
02d591a8: adrp    x8, #0x6266000                             
02d591ac: ldr     x8, [x8, #0x870]                           MS:DataManager::GetAsset
02d591b0: ldr     x1, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d591b4: bl      #0x3168af0                                 fn_3168af0
02d591b8: cbz     x0, #0x2d5921c                             
02d591bc: mov     w1, wzr                                    
02d591c0: mov     x2, xzr                                    
02d591c4: bl      #0x2d249f4                                 Decor.DecorAsset::GetCategoryAssetByIndex
02d591c8: cbz     x0, #0x2d5921c                             
02d591cc: mov     w1, w20                                    
02d591d0: mov     x2, xzr                                    
02d591d4: bl      #0x2d24a4c                                 Decor.CategoryAsset::GetOptionDataByID
02d591d8: cbz     x0, #0x2d59208                             
02d591dc: mov     x20, x0                                    
02d591e0: ldr     x0, [x19, #0x50]                           ._imgSkinDecor
02d591e4: cbz     x0, #0x2d5921c                             
02d591e8: ldr     x1, [x20, #0x18]                           
02d591ec: mov     x2, xzr                                    
02d591f0: bl      #0x5c45aa0                                 UnityEngine.UI.Image::set_sprite
02d591f4: ldr     x0, [x19, #0x78]                           ._imgSkinDecorAnim
02d591f8: cbz     x0, #0x2d5921c                             
02d591fc: ldr     x1, [x20, #0x18]                           
02d59200: mov     x2, xzr                                    
02d59204: bl      #0x5c45aa0                                 UnityEngine.UI.Image::set_sprite
02d59208: mov     w8, #1                                     
02d5920c: strb    w8, [x19, #0xa8]                           ._isShowSkinContent
02d59210: ldp     x20, x19, [sp, #0x10]                      
02d59214: ldp     x30, x21, [sp], #0x20                      
02d59218: ret                                                
02d5921c: bl      #0x2b7105c                                 fn_2b7105c
## OnShow() -> void
---- LoginTimeReward.ClaimLoginRewardPopup::OnShow 0x2d59220
02d59220: stp     x30, x21, [sp, #-0x20]!                    
02d59224: stp     x20, x19, [sp, #0x10]                      
02d59228: adrp    x20, #0x6630000                            
02d5922c: mov     x19, x0                                    
02d59230: ldrb    w8, [x20, #0x2ab]                          
02d59234: tbnz    w8, #0, #0x2d5924c                         
02d59238: adrp    x0, #0x6266000                             
02d5923c: ldr     x0, [x0, #0x880]                           MS:DG.Tweening.TweenSettingsExtensions::SetEase
02d59240: bl      #0x2b70db0                                 fn_2b70db0
02d59244: mov     w8, #1                                     
02d59248: strb    w8, [x20, #0x2ab]                          
02d5924c: ldr     x0, [x19, #0xa0]                           ._goBackgroundAnim
02d59250: cbz     x0, #0x2d5930c                             
02d59254: mov     w1, wzr                                    
02d59258: mov     x2, xzr                                    
02d5925c: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d59260: ldr     x0, [x19, #0x80]                           ._skinDecorHolder
02d59264: cbz     x0, #0x2d5930c                             
02d59268: mov     x1, xzr                                    
02d5926c: bl      #0x5b339ec                                 UnityEngine.Component::get_gameObject
02d59270: cbz     x0, #0x2d5930c                             
02d59274: mov     w1, wzr                                    
02d59278: mov     x2, xzr                                    
02d5927c: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d59280: mov     x0, x19                                    
02d59284: mov     x1, xzr                                    
02d59288: bl      #0x2cdd6b8                                 UIBase::OnShow
02d5928c: adrp    x21, #0x662f000                            
02d59290: ldr     x20, [x19, #0x70]                          ._tfPanel
02d59294: ldrb    w8, [x21, #0x91a]                          
02d59298: cbnz    w8, #0x2d592b0                             
02d5929c: adrp    x0, #0x6264000                             
02d592a0: ldr     x0, [x0, #0xd8]                            T:UnityEngine.Vector3
02d592a4: bl      #0x2b70db0                                 fn_2b70db0
02d592a8: mov     w8, #1                                     
02d592ac: strb    w8, [x21, #0x91a]                          
02d592b0: cbz     x20, #0x2d5930c                            
02d592b4: adrp    x8, #0x6264000                             
02d592b8: adrp    x21, #0x6266000                            
02d592bc: mov     x0, x20                                    
02d592c0: ldr     x8, [x8, #0xd8]                            T:UnityEngine.Vector3
02d592c4: mov     x1, xzr                                    
02d592c8: ldr     x8, [x8]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d592cc: ldr     x8, [x8, #0xb8]                            MS:DG.Tweening.Core.Extensions::SetSpecialStartupMode
02d592d0: ldr     x21, [x21, #0x880]                         MS:DG.Tweening.TweenSettingsExtensions::SetEase
02d592d4: ldp     s1, s2, [x8, #4]                           
02d592d8: ldr     s0, [x8]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d592dc: bl      #0x5b470cc                                 UnityEngine.Transform::set_localScale
02d592e0: adrp    x8, #0x1084000                             
02d592e4: fmov    s0, #1.00000000                            
02d592e8: ldr     x0, [x19, #0x70]                           ._tfPanel
02d592ec: ldr     s1, [x8, #0xf10]                           [1084f10]=4110bc863e99999a f=0.3,9.04603
02d592f0: mov     x1, xzr                                    
02d592f4: bl      #0x2d98c98                                 DG.Tweening.ShortcutExtensions::DOScale
02d592f8: ldp     x20, x19, [sp, #0x10]                      
02d592fc: mov     w1, #0x1b                                  
02d59300: ldr     x2, [x21]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d59304: ldp     x30, x21, [sp], #0x20                      
02d59308: b       #0x336fa0c                                 
02d5930c: bl      #0x2b7105c                                 fn_2b7105c
## OnHide() -> void
---- LoginTimeReward.ClaimLoginRewardPopup::OnHide 0x2d59310
02d59310: mov     x1, xzr                                    
02d59314: b       #0x2cddc10                                 UIBase::OnHide
## OnClickBtnClose() -> void
---- LoginTimeReward.ClaimLoginRewardPopup::OnClickBtnClose 0x2d59318
02d59318: stp     x30, x19, [sp, #-0x10]!                    
02d5931c: ldrb    w8, [x0, #0xa8]                            ._isShowSkinContent
02d59320: mov     x19, x0                                    
02d59324: cbz     w8, #0x2d59334                             
02d59328: mov     x0, x19                                    
02d5932c: ldp     x30, x19, [sp], #0x10                      
02d59330: b       #0x2d59378                                 LoginTimeReward.ClaimLoginRewardPopup::OnClickBtnClaimSkinDecor
02d59334: mov     x0, xzr                                    
02d59338: bl      #0x2d6eec8                                 Framework.AudioManager::get_Instance
02d5933c: cbz     x0, #0x2d59374                             
02d59340: movi    d1, #0000000000000000                      
02d59344: movi    d2, #0000000000000000                      
02d59348: mov     w1, #1                                     
02d5934c: fmov    s0, #1.00000000                            
02d59350: mov     w2, wzr                                    
02d59354: mov     w3, wzr                                    
02d59358: mov     x4, xzr                                    
02d5935c: bl      #0x2d6f03c                                 Framework.AudioManager::PlaySound
02d59360: ldr     x8, [x19]                                  
02d59364: mov     x0, x19                                    
02d59368: ldp     x2, x1, [x8, #0x198]                       
02d5936c: ldp     x30, x19, [sp], #0x10                      
02d59370: br      x2                                         
02d59374: bl      #0x2b7105c                                 fn_2b7105c
## OnClickBtnCollectKeycap() -> void
---- LoginTimeReward.ClaimLoginRewardPopup::OnClickBtnCollectKeycap 0x2d595e4
02d595e4: stp     x30, x19, [sp, #-0x10]!                    
02d595e8: mov     x19, x0                                    
02d595ec: mov     x0, xzr                                    
02d595f0: bl      #0x2d6eec8                                 Framework.AudioManager::get_Instance
02d595f4: cbz     x0, #0x2d5962c                             
02d595f8: movi    d1, #0000000000000000                      
02d595fc: movi    d2, #0000000000000000                      
02d59600: mov     w1, #1                                     
02d59604: fmov    s0, #1.00000000                            
02d59608: mov     w2, wzr                                    
02d5960c: mov     w3, wzr                                    
02d59610: mov     x4, xzr                                    
02d59614: bl      #0x2d6f03c                                 Framework.AudioManager::PlaySound
02d59618: ldr     x8, [x19]                                  
02d5961c: mov     x0, x19                                    
02d59620: ldp     x2, x1, [x8, #0x198]                       
02d59624: ldp     x30, x19, [sp], #0x10                      
02d59628: br      x2                                         
02d5962c: bl      #0x2b7105c                                 fn_2b7105c
## OnClickBtnClaimSkinDecor() -> void
---- LoginTimeReward.ClaimLoginRewardPopup::OnClickBtnClaimSkinDecor 0x2d59378
02d59378: str     d8, [sp, #-0x50]!                          
02d5937c: stp     x30, x25, [sp, #0x10]                      
02d59380: stp     x24, x23, [sp, #0x20]                      
02d59384: stp     x22, x21, [sp, #0x30]                      
02d59388: stp     x20, x19, [sp, #0x40]                      
02d5938c: adrp    x20, #0x6630000                            
02d59390: mov     x19, x0                                    
02d59394: ldrb    w8, [x20, #0x2ac]                          
02d59398: tbnz    w8, #0, #0x2d593e0                         
02d5939c: adrp    x0, #0x626b000                             
02d593a0: ldr     x0, [x0, #0xb08]                           M:LoginTimeReward.ClaimLoginRewardPopup::<OnClickBtnClaimSkinDecor>b__22_0
02d593a4: bl      #0x2b70db0                                 fn_2b70db0
02d593a8: adrp    x0, #0x6264000                             
02d593ac: ldr     x0, [x0, #0xe8]                            T:DG.Tweening.TweenCallback
02d593b0: bl      #0x2b70db0                                 fn_2b70db0
02d593b4: adrp    x0, #0x6266000                             
02d593b8: ldr     x0, [x0, #0x928]                           MS:DG.Tweening.TweenSettingsExtensions::OnComplete
02d593bc: bl      #0x2b70db0                                 fn_2b70db0
02d593c0: adrp    x0, #0x6266000                             
02d593c4: ldr     x0, [x0, #0xe08]                           MS:DG.Tweening.TweenSettingsExtensions::SetDelay
02d593c8: bl      #0x2b70db0                                 fn_2b70db0
02d593cc: adrp    x0, #0x6266000                             
02d593d0: ldr     x0, [x0, #0x880]                           MS:DG.Tweening.TweenSettingsExtensions::SetEase
02d593d4: bl      #0x2b70db0                                 fn_2b70db0
02d593d8: mov     w8, #1                                     
02d593dc: strb    w8, [x20, #0x2ac]                          
02d593e0: mov     x0, xzr                                    
02d593e4: bl      #0x2d6eec8                                 Framework.AudioManager::get_Instance
02d593e8: cbz     x0, #0x2d595e0                             
02d593ec: movi    d1, #0000000000000000                      
02d593f0: movi    d2, #0000000000000000                      
02d593f4: mov     w1, #1                                     
02d593f8: fmov    s0, #1.00000000                            
02d593fc: mov     w2, wzr                                    
02d59400: mov     w3, wzr                                    
02d59404: mov     x4, xzr                                    
02d59408: bl      #0x2d6f03c                                 Framework.AudioManager::PlaySound
02d5940c: ldr     x0, [x19, #0x88]                           ._skinDecorStartPos
02d59410: cbz     x0, #0x2d595e0                             
02d59414: ldr     x20, [x19, #0x80]                          ._skinDecorHolder
02d59418: mov     x1, xzr                                    
02d5941c: bl      #0x5b467ac                                 UnityEngine.Transform::get_position
02d59420: cbz     x20, #0x2d595e0                            
02d59424: mov     x0, x20                                    
02d59428: mov     x1, xzr                                    
02d5942c: bl      #0x5b46888                                 UnityEngine.Transform::set_position
02d59430: ldr     x0, [x19, #0x90]                           ._tfButtonDecorAtHome
02d59434: cbz     x0, #0x2d595e0                             
02d59438: ldr     x20, [x19, #0x98]                          ._tfButtonDecor
02d5943c: mov     x1, xzr                                    
02d59440: bl      #0x5b467ac                                 UnityEngine.Transform::get_position
02d59444: cbz     x20, #0x2d595e0                            
02d59448: mov     x0, x20                                    
02d5944c: mov     x1, xzr                                    
02d59450: bl      #0x5b46888                                 UnityEngine.Transform::set_position
02d59454: adrp    x21, #0x662f000                            
02d59458: ldr     x20, [x19, #0x80]                          ._skinDecorHolder
02d5945c: ldrb    w8, [x21, #0xa74]                          
02d59460: cbnz    w8, #0x2d59478                             
02d59464: adrp    x0, #0x6264000                             
02d59468: ldr     x0, [x0, #0xd8]                            T:UnityEngine.Vector3
02d5946c: bl      #0x2b70db0                                 fn_2b70db0
02d59470: mov     w8, #1                                     
02d59474: strb    w8, [x21, #0xa74]                          
02d59478: cbz     x20, #0x2d595e0                            
02d5947c: adrp    x8, #0x6264000                             
02d59480: adrp    x21, #0x6266000                            
02d59484: mov     x0, x20                                    
02d59488: ldr     x8, [x8, #0xd8]                            T:UnityEngine.Vector3
02d5948c: mov     x1, xzr                                    
02d59490: ldr     x8, [x8]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d59494: ldr     x8, [x8, #0xb8]                            MS:DG.Tweening.Core.Extensions::SetSpecialStartupMode
02d59498: ldr     x21, [x21, #0xe08]                         MS:DG.Tweening.TweenSettingsExtensions::SetDelay
02d5949c: ldp     s1, s2, [x8, #0x10]                        
02d594a0: ldr     s0, [x8, #0xc]                             [626400c]=0 f=0,0
02d594a4: bl      #0x5b470cc                                 UnityEngine.Transform::set_localScale
02d594a8: movi    d0, #0000000000000000                      
02d594ac: movi    d1, #0000000000000000                      
02d594b0: ldr     x0, [x19, #0x70]                           ._tfPanel
02d594b4: mov     x1, xzr                                    
02d594b8: bl      #0x2d98c98                                 DG.Tweening.ShortcutExtensions::DOScale
02d594bc: adrp    x8, #0x1084000                             
02d594c0: ldr     x1, [x21]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d594c4: ldr     s0, [x8, #0xeec]                           [1084eec]=457ff0003dcccccd f=0.1,4095
02d594c8: bl      #0x336f7fc                                 fn_336f7fc
02d594cc: ldr     x0, [x19, #0xa0]                           ._goBackgroundAnim
02d594d0: cbz     x0, #0x2d595e0                             
02d594d4: mov     w1, #1                                     
02d594d8: mov     x2, xzr                                    
02d594dc: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d594e0: ldr     x0, [x19, #0x80]                           ._skinDecorHolder
02d594e4: cbz     x0, #0x2d595e0                             
02d594e8: mov     x1, xzr                                    
02d594ec: bl      #0x5b339ec                                 UnityEngine.Component::get_gameObject
02d594f0: cbz     x0, #0x2d595e0                             
02d594f4: mov     w1, #1                                     
02d594f8: mov     x2, xzr                                    
02d594fc: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d59500: ldr     x0, [x19, #0x98]                           ._tfButtonDecor
02d59504: cbz     x0, #0x2d595e0                             
02d59508: adrp    x25, #0x6266000                            
02d5950c: adrp    x24, #0x6264000                            
02d59510: adrp    x23, #0x626b000                            
02d59514: adrp    x22, #0x6266000                            
02d59518: ldr     x25, [x25, #0x880]                         MS:DG.Tweening.TweenSettingsExtensions::SetEase
02d5951c: ldr     x24, [x24, #0xe8]                          T:DG.Tweening.TweenCallback
02d59520: ldr     x23, [x23, #0xb08]                         M:LoginTimeReward.ClaimLoginRewardPopup::<OnClickBtnClaimSkinDecor>b__22_0
02d59524: ldr     x22, [x22, #0x928]                         MS:DG.Tweening.TweenSettingsExtensions::OnComplete
02d59528: ldr     x20, [x19, #0x80]                          ._skinDecorHolder
02d5952c: mov     x1, xzr                                    
02d59530: bl      #0x5b467ac                                 UnityEngine.Transform::get_position
02d59534: adrp    x8, #0x1084000                             
02d59538: mov     x0, x20                                    
02d5953c: mov     w1, wzr                                    
02d59540: ldr     s8, [x8, #0xcc4]                           [1084cc4]=3f8000543f4ccccd f=0.8,1.00001
02d59544: mov     x2, xzr                                    
02d59548: fmov    s3, s8                                     
02d5954c: bl      #0x2d975e4                                 DG.Tweening.ShortcutExtensions::DOMove
02d59550: fmov    s0, #0.50000000                            
02d59554: ldr     x1, [x21]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d59558: bl      #0x336f7fc                                 fn_336f7fc
02d5955c: ldr     x2, [x25]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d59560: mov     w1, #0x1a                                  
02d59564: bl      #0x336fa0c                                 fn_336fa0c
02d59568: fmov    s1, s8                                     
02d5956c: adrp    x8, #0x1084000                             
02d59570: ldr     x0, [x19, #0x80]                           ._skinDecorHolder
02d59574: ldr     s0, [x8, #0xf10]                           [1084f10]=4110bc863e99999a f=0.3,9.04603
02d59578: mov     x1, xzr                                    
02d5957c: bl      #0x2d98c98                                 DG.Tweening.ShortcutExtensions::DOScale
02d59580: fmov    s0, #0.50000000                            
02d59584: ldr     x1, [x21]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d59588: bl      #0x336f7fc                                 fn_336f7fc
02d5958c: ldr     x2, [x25]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d59590: mov     w1, #0x1a                                  
02d59594: bl      #0x336fa0c                                 fn_336fa0c
02d59598: ldr     x8, [x24]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d5959c: mov     x20, x0                                    
02d595a0: mov     x0, x8                                     
02d595a4: bl      #0x2b7104c                                 fn_2b7104c
02d595a8: ldr     x2, [x23]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d595ac: mov     x1, x19                                    
02d595b0: mov     x3, xzr                                    
02d595b4: mov     x21, x0                                    
02d595b8: bl      #0x2d89dc4                                 DG.Tweening.TweenCallback::.ctor
02d595bc: ldr     x2, [x22]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d595c0: mov     x0, x20                                    
02d595c4: mov     x1, x21                                    
02d595c8: ldp     x20, x19, [sp, #0x40]                      
02d595cc: ldp     x22, x21, [sp, #0x30]                      
02d595d0: ldp     x24, x23, [sp, #0x20]                      
02d595d4: ldp     x30, x25, [sp, #0x10]                      
02d595d8: ldr     d8, [sp], #0x50                            
02d595dc: b       #0x336f26c                                 
02d595e0: bl      #0x2b7105c                                 fn_2b7105c
## .ctor() -> void
---- LoginTimeReward.ClaimLoginRewardPopup::.ctor 0x2d59630
02d59630: mov     x1, xzr                                    
02d59634: b       #0x2cddba8                                 PopupBase::.ctor
## <OnClickBtnClaimSkinDecor>b__22_0() -> void
---- LoginTimeReward.ClaimLoginRewardPopup::<OnClickBtnClaimSkinDecor>b__22_0 0x2d59638
02d59638: stp     x30, x23, [sp, #-0x30]!                    
02d5963c: stp     x22, x21, [sp, #0x10]                      
02d59640: stp     x20, x19, [sp, #0x20]                      
02d59644: adrp    x20, #0x6630000                            
02d59648: mov     x19, x0                                    
02d5964c: ldrb    w8, [x20, #0x2ad]                          
02d59650: tbnz    w8, #0, #0x2d5968c                         
02d59654: adrp    x0, #0x626b000                             
02d59658: ldr     x0, [x0, #0xb10]                           M:LoginTimeReward.ClaimLoginRewardPopup::<OnClickBtnClaimSkinDecor>b__22_1
02d5965c: bl      #0x2b70db0                                 fn_2b70db0
02d59660: adrp    x0, #0x6264000                             
02d59664: ldr     x0, [x0, #0xe8]                            T:DG.Tweening.TweenCallback
02d59668: bl      #0x2b70db0                                 fn_2b70db0
02d5966c: adrp    x0, #0x6266000                             
02d59670: ldr     x0, [x0, #0x928]                           MS:DG.Tweening.TweenSettingsExtensions::OnComplete
02d59674: bl      #0x2b70db0                                 fn_2b70db0
02d59678: adrp    x0, #0x6268000                             
02d5967c: ldr     x0, [x0, #0x10]                            MS:DG.Tweening.TweenSettingsExtensions::SetLoops
02d59680: bl      #0x2b70db0                                 fn_2b70db0
02d59684: mov     w8, #1                                     
02d59688: strb    w8, [x20, #0x2ad]                          
02d5968c: ldr     x0, [x19, #0x80]                           ._skinDecorHolder
02d59690: cbz     x0, #0x2d59738                             
02d59694: mov     x1, xzr                                    
02d59698: bl      #0x5b339ec                                 UnityEngine.Component::get_gameObject
02d5969c: cbz     x0, #0x2d59738                             
02d596a0: adrp    x20, #0x6268000                            
02d596a4: adrp    x21, #0x6264000                            
02d596a8: adrp    x22, #0x626b000                            
02d596ac: adrp    x23, #0x6266000                            
02d596b0: ldr     x20, [x20, #0x10]                          MS:DG.Tweening.TweenSettingsExtensions::SetLoops
02d596b4: ldr     x21, [x21, #0xe8]                          T:DG.Tweening.TweenCallback
02d596b8: ldr     x22, [x22, #0xb10]                         M:LoginTimeReward.ClaimLoginRewardPopup::<OnClickBtnClaimSkinDecor>b__22_1
02d596bc: ldr     x23, [x23, #0x928]                         MS:DG.Tweening.TweenSettingsExtensions::OnComplete
02d596c0: mov     w1, wzr                                    
02d596c4: mov     x2, xzr                                    
02d596c8: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d596cc: adrp    x8, #0x1084000                             
02d596d0: adrp    x9, #0x1084000                             
02d596d4: ldr     x0, [x19, #0x98]                           ._tfButtonDecor
02d596d8: ldr     s0, [x8, #0xcf4]                           [1084cf4]=431d80003f99999a f=1.2,157.5
02d596dc: ldr     s1, [x9, #0xeec]                           [1084eec]=457ff0003dcccccd f=0.1,4095
02d596e0: mov     x1, xzr                                    
02d596e4: bl      #0x2d98c98                                 DG.Tweening.ShortcutExtensions::DOScale
02d596e8: ldr     x3, [x20]                                  S:'{0}/2'
02d596ec: mov     w1, #2                                     
02d596f0: mov     w2, #1                                     
02d596f4: bl      #0x336fe74                                 fn_336fe74
02d596f8: ldr     x8, [x21]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d596fc: mov     x20, x0                                    
02d59700: mov     x0, x8                                     
02d59704: bl      #0x2b7104c                                 fn_2b7104c
02d59708: ldr     x2, [x22]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d5970c: mov     x1, x19                                    
02d59710: mov     x3, xzr                                    
02d59714: mov     x21, x0                                    
02d59718: bl      #0x2d89dc4                                 DG.Tweening.TweenCallback::.ctor
02d5971c: mov     x0, x20                                    
02d59720: mov     x1, x21                                    
02d59724: ldr     x2, [x23]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d59728: ldp     x20, x19, [sp, #0x20]                      
02d5972c: ldp     x22, x21, [sp, #0x10]                      
02d59730: ldp     x30, x23, [sp], #0x30                      
02d59734: b       #0x336f26c                                 
02d59738: bl      #0x2b7105c                                 fn_2b7105c
## <OnClickBtnClaimSkinDecor>b__22_1() -> void
---- LoginTimeReward.ClaimLoginRewardPopup::<OnClickBtnClaimSkinDecor>b__22_1 0x2d5973c
02d5973c: stp     x30, x19, [sp, #-0x10]!                    
02d59740: mov     x19, x0                                    
02d59744: ldr     x0, [x0, #0xa0]                            ._goBackgroundAnim
02d59748: cbz     x0, #0x2d5976c                             
02d5974c: mov     w1, wzr                                    
02d59750: mov     x2, xzr                                    
02d59754: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d59758: ldr     x8, [x19]                                  
02d5975c: mov     x0, x19                                    
02d59760: ldp     x2, x1, [x8, #0x198]                       
02d59764: ldp     x30, x19, [sp], #0x10                      
02d59768: br      x2                                         
02d5976c: bl      #0x2b7105c                                 fn_2b7105c
