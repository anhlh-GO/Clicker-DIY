#### CLASS ApplovinEventBase parent= UnityEngine.MonoBehaviour
#   field placment                       string                                             off=0x20 attr=4 
#   field _adFormat                      AdFormat                                           off=0x28 attr=4 
## OnAdLoadedEvent(string adUnitId, MaxSdkBase/AdInfo adInfo) -> void
---- ApplovinEventBase::OnAdLoadedEvent 0x2c8b780
02c8b780: str     x30, [sp, #-0x30]!                         
02c8b784: stp     x22, x21, [sp, #0x10]                      
02c8b788: stp     x20, x19, [sp, #0x20]                      
02c8b78c: adrp    x21, #0x662f000                            
02c8b790: mov     x19, x2                                    
02c8b794: mov     x20, x0                                    
02c8b798: ldrb    w8, [x21, #0x980]                          
02c8b79c: tbnz    w8, #0, #0x2c8b7cc                         
02c8b7a0: adrp    x0, #0x6265000                             
02c8b7a4: ldr     x0, [x0, #0x1d8]                           S:'_OnAdLoadedEvent_'
02c8b7a8: bl      #0x2b70db0                                 fn_2b70db0
02c8b7ac: adrp    x0, #0x6265000                             
02c8b7b0: ldr     x0, [x0, #0x1e0]                           S:'_OnAdLoadedEvent'
02c8b7b4: bl      #0x2b70db0                                 fn_2b70db0
02c8b7b8: adrp    x0, #0x6265000                             
02c8b7bc: ldr     x0, [x0, #0x1e8]                           S:'_AD'
02c8b7c0: bl      #0x2b70db0                                 fn_2b70db0
02c8b7c4: mov     w8, #1                                     
02c8b7c8: strb    w8, [x21, #0x980]                          
02c8b7cc: cbz     x19, #0x2c8b888                            
02c8b7d0: adrp    x22, #0x6265000                            
02c8b7d4: adrp    x21, #0x6265000                            
02c8b7d8: mov     x2, xzr                                    
02c8b7dc: ldr     x22, [x22, #0x1e8]                         S:'_AD'
02c8b7e0: ldr     x21, [x21, #0x1e0]                         S:'_OnAdLoadedEvent'
02c8b7e4: ldr     x0, [x19, #0x18]                           
02c8b7e8: ldr     x1, [x22]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c8b7ec: bl      #0x4c9c514                                 System.String::Concat
02c8b7f0: ldr     x8, [x19, #0x18]                           
02c8b7f4: ldr     x1, [x21]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c8b7f8: mov     x21, x0                                    
02c8b7fc: mov     x2, xzr                                    
02c8b800: mov     x0, x8                                     
02c8b804: bl      #0x4c9c514                                 System.String::Concat
02c8b808: mov     x1, x0                                     
02c8b80c: mov     x0, x21                                    
02c8b810: mov     x2, xzr                                    
02c8b814: bl      #0x2c8b88c                                 AnalyticsManager::LogAdsEvent
02c8b818: ldr     x0, [x20, #0x20]                           .placment
02c8b81c: mov     x1, xzr                                    
02c8b820: bl      #0x4ca6234                                 System.String::IsNullOrEmpty
02c8b824: tbz     w0, #0, #0x2c8b838                         
02c8b828: ldp     x20, x19, [sp, #0x20]                      
02c8b82c: ldp     x22, x21, [sp, #0x10]                      
02c8b830: ldr     x30, [sp], #0x30                           
02c8b834: ret                                                
02c8b838: ldr     x0, [x19, #0x18]                           
02c8b83c: ldr     x1, [x22]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c8b840: mov     x2, xzr                                    
02c8b844: bl      #0x4c9c514                                 System.String::Concat
02c8b848: adrp    x9, #0x6265000                             
02c8b84c: mov     x3, xzr                                    
02c8b850: ldr     x9, [x9, #0x1d8]                           S:'_OnAdLoadedEvent_'
02c8b854: ldr     x8, [x19, #0x18]                           
02c8b858: ldr     x2, [x20, #0x20]                           .placment
02c8b85c: mov     x19, x0                                    
02c8b860: ldr     x1, [x9]                                   M:AdsManager::<OnApplicationPause>b__26_0
02c8b864: mov     x0, x8                                     
02c8b868: bl      #0x4ca6dbc                                 System.String::Concat
02c8b86c: mov     x1, x0                                     
02c8b870: mov     x0, x19                                    
02c8b874: mov     x2, xzr                                    
02c8b878: ldp     x20, x19, [sp, #0x20]                      
02c8b87c: ldp     x22, x21, [sp, #0x10]                      
02c8b880: ldr     x30, [sp], #0x30                           
02c8b884: b       #0x2c8b88c                                 AnalyticsManager::LogAdsEvent
02c8b888: bl      #0x2b7105c                                 fn_2b7105c
## OnAdLoadFailedEvent(string adUnitId, MaxSdkBase/ErrorInfo errorInfo) -> void
---- ApplovinEventBase::OnAdLoadFailedEvent 0x2c8bb74
02c8bb74: sub     sp, sp, #0x40                              
02c8bb78: stp     x30, x23, [sp, #0x10]                      
02c8bb7c: stp     x22, x21, [sp, #0x20]                      
02c8bb80: stp     x20, x19, [sp, #0x30]                      
02c8bb84: adrp    x21, #0x662f000                            
02c8bb88: mov     x19, x2                                    
02c8bb8c: mov     x20, x0                                    
02c8bb90: ldrb    w8, [x21, #0x981]                          
02c8bb94: tbnz    w8, #0, #0x2c8bbd0                         
02c8bb98: adrp    x0, #0x6265000                             
02c8bb9c: ldr     x0, [x0, #0x210]                           T:AdFormat
02c8bba0: bl      #0x2b70db0                                 fn_2b70db0
02c8bba4: adrp    x0, #0x6265000                             
02c8bba8: ldr     x0, [x0, #0x218]                           S:'{0}_OnAdLoadFailedEvent'
02c8bbac: bl      #0x2b70db0                                 fn_2b70db0
02c8bbb0: adrp    x0, #0x6265000                             
02c8bbb4: ldr     x0, [x0, #0x220]                           S:'{0}_AD'
02c8bbb8: bl      #0x2b70db0                                 fn_2b70db0
02c8bbbc: adrp    x0, #0x6265000                             
02c8bbc0: ldr     x0, [x0, #0x228]                           S:'OnAdLoadFailedEvent '
02c8bbc4: bl      #0x2b70db0                                 fn_2b70db0
02c8bbc8: mov     w8, #1                                     
02c8bbcc: strb    w8, [x21, #0x981]                          
02c8bbd0: cbz     x19, #0x2c8bc84                            
02c8bbd4: adrp    x8, #0x6265000                             
02c8bbd8: adrp    x22, #0x6265000                            
02c8bbdc: adrp    x21, #0x6265000                            
02c8bbe0: ldr     x8, [x8, #0x228]                           S:'OnAdLoadFailedEvent '
02c8bbe4: adrp    x23, #0x6265000                            
02c8bbe8: ldr     x22, [x22, #0x210]                         T:AdFormat
02c8bbec: ldr     x21, [x21, #0x220]                         S:'{0}_AD'
02c8bbf0: ldr     x23, [x23, #0x218]                         S:'{0}_OnAdLoadFailedEvent'
02c8bbf4: ldr     x1, [x19, #0x18]                           
02c8bbf8: ldr     x0, [x8]                                   M:AdsManager::<OnApplicationPause>b__26_0
02c8bbfc: mov     x2, xzr                                    
02c8bc00: bl      #0x4c9c514                                 System.String::Concat
02c8bc04: mov     x1, xzr                                    
02c8bc08: bl      #0x2ca09f8                                 WLog::LogError
02c8bc0c: ldr     w8, [x20, #0x28]                           ._adFormat
02c8bc10: ldr     x0, [x22]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c8bc14: add     x1, sp, #0xc                               
02c8bc18: str     w8, [sp, #0xc]                             
02c8bc1c: bl      #0x2b70f38                                 fn_2b70f38
02c8bc20: ldr     x8, [x21]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c8bc24: mov     x1, x0                                     
02c8bc28: mov     x2, xzr                                    
02c8bc2c: mov     x0, x8                                     
02c8bc30: bl      #0x4c9d0ec                                 System.String::Format
02c8bc34: mov     x21, x0                                    
02c8bc38: ldr     w8, [x20, #0x28]                           ._adFormat
02c8bc3c: ldr     x0, [x22]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c8bc40: add     x1, sp, #8                                 
02c8bc44: str     w8, [sp, #8]                               
02c8bc48: bl      #0x2b70f38                                 fn_2b70f38
02c8bc4c: ldr     x8, [x23]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c8bc50: mov     x1, x0                                     
02c8bc54: mov     x2, xzr                                    
02c8bc58: mov     x0, x8                                     
02c8bc5c: bl      #0x4c9d0ec                                 System.String::Format
02c8bc60: ldr     x2, [x19, #0x18]                           
02c8bc64: mov     x1, x0                                     
02c8bc68: mov     x0, x21                                    
02c8bc6c: bl      #0x2c8b88c                                 AnalyticsManager::LogAdsEvent
02c8bc70: ldp     x20, x19, [sp, #0x30]                      
02c8bc74: ldp     x22, x21, [sp, #0x20]                      
02c8bc78: ldp     x30, x23, [sp, #0x10]                      
02c8bc7c: add     sp, sp, #0x40                              
02c8bc80: ret                                                
02c8bc84: bl      #0x2b7105c                                 fn_2b7105c
## OnAdDisplayedEvent(string adUnitID, MaxSdkBase/AdInfo adInfo) -> void
---- ApplovinEventBase::OnAdDisplayedEvent 0x2c8bc88
02c8bc88: str     x30, [sp, #-0x30]!                         
02c8bc8c: stp     x22, x21, [sp, #0x10]                      
02c8bc90: stp     x20, x19, [sp, #0x20]                      
02c8bc94: adrp    x21, #0x662f000                            
02c8bc98: mov     x19, x2                                    
02c8bc9c: mov     x20, x0                                    
02c8bca0: ldrb    w8, [x21, #0x982]                          
02c8bca4: tbnz    w8, #0, #0x2c8bcd4                         
02c8bca8: adrp    x0, #0x6265000                             
02c8bcac: ldr     x0, [x0, #0x230]                           S:'_OnAdDisplayedEvent'
02c8bcb0: bl      #0x2b70db0                                 fn_2b70db0
02c8bcb4: adrp    x0, #0x6265000                             
02c8bcb8: ldr     x0, [x0, #0x238]                           S:'_OnAdDisplayedEvent_'
02c8bcbc: bl      #0x2b70db0                                 fn_2b70db0
02c8bcc0: adrp    x0, #0x6265000                             
02c8bcc4: ldr     x0, [x0, #0x1e8]                           S:'_AD'
02c8bcc8: bl      #0x2b70db0                                 fn_2b70db0
02c8bccc: mov     w8, #1                                     
02c8bcd0: strb    w8, [x21, #0x982]                          
02c8bcd4: cbz     x19, #0x2c8bd90                            
02c8bcd8: adrp    x22, #0x6265000                            
02c8bcdc: adrp    x21, #0x6265000                            
02c8bce0: mov     x2, xzr                                    
02c8bce4: ldr     x22, [x22, #0x1e8]                         S:'_AD'
02c8bce8: ldr     x21, [x21, #0x230]                         S:'_OnAdDisplayedEvent'
02c8bcec: ldr     x0, [x19, #0x18]                           
02c8bcf0: ldr     x1, [x22]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c8bcf4: bl      #0x4c9c514                                 System.String::Concat
02c8bcf8: ldr     x8, [x19, #0x18]                           
02c8bcfc: ldr     x1, [x21]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c8bd00: mov     x21, x0                                    
02c8bd04: mov     x2, xzr                                    
02c8bd08: mov     x0, x8                                     
02c8bd0c: bl      #0x4c9c514                                 System.String::Concat
02c8bd10: mov     x1, x0                                     
02c8bd14: mov     x0, x21                                    
02c8bd18: mov     x2, xzr                                    
02c8bd1c: bl      #0x2c8b88c                                 AnalyticsManager::LogAdsEvent
02c8bd20: ldr     x0, [x20, #0x20]                           .placment
02c8bd24: mov     x1, xzr                                    
02c8bd28: bl      #0x4ca6234                                 System.String::IsNullOrEmpty
02c8bd2c: tbz     w0, #0, #0x2c8bd40                         
02c8bd30: ldp     x20, x19, [sp, #0x20]                      
02c8bd34: ldp     x22, x21, [sp, #0x10]                      
02c8bd38: ldr     x30, [sp], #0x30                           
02c8bd3c: ret                                                
02c8bd40: ldr     x0, [x19, #0x18]                           
02c8bd44: ldr     x1, [x22]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c8bd48: mov     x2, xzr                                    
02c8bd4c: bl      #0x4c9c514                                 System.String::Concat
02c8bd50: adrp    x9, #0x6265000                             
02c8bd54: mov     x3, xzr                                    
02c8bd58: ldr     x9, [x9, #0x238]                           S:'_OnAdDisplayedEvent_'
02c8bd5c: ldr     x8, [x19, #0x18]                           
02c8bd60: ldr     x2, [x20, #0x20]                           .placment
02c8bd64: mov     x19, x0                                    
02c8bd68: ldr     x1, [x9]                                   M:AdsManager::<OnApplicationPause>b__26_0
02c8bd6c: mov     x0, x8                                     
02c8bd70: bl      #0x4ca6dbc                                 System.String::Concat
02c8bd74: mov     x1, x0                                     
02c8bd78: mov     x0, x19                                    
02c8bd7c: mov     x2, xzr                                    
02c8bd80: ldp     x20, x19, [sp, #0x20]                      
02c8bd84: ldp     x22, x21, [sp, #0x10]                      
02c8bd88: ldr     x30, [sp], #0x30                           
02c8bd8c: b       #0x2c8b88c                                 AnalyticsManager::LogAdsEvent
02c8bd90: bl      #0x2b7105c                                 fn_2b7105c
## OnAdClickedEvent(string adUnitId, MaxSdkBase/AdInfo adInfo) -> void
---- ApplovinEventBase::OnAdClickedEvent 0x2c8bd94
02c8bd94: str     x30, [sp, #-0x30]!                         
02c8bd98: stp     x22, x21, [sp, #0x10]                      
02c8bd9c: stp     x20, x19, [sp, #0x20]                      
02c8bda0: adrp    x21, #0x662f000                            
02c8bda4: mov     x19, x2                                    
02c8bda8: mov     x20, x0                                    
02c8bdac: ldrb    w8, [x21, #0x983]                          
02c8bdb0: tbnz    w8, #0, #0x2c8bde0                         
02c8bdb4: adrp    x0, #0x6265000                             
02c8bdb8: ldr     x0, [x0, #0x240]                           S:'_OnAdClickedEvent_'
02c8bdbc: bl      #0x2b70db0                                 fn_2b70db0
02c8bdc0: adrp    x0, #0x6265000                             
02c8bdc4: ldr     x0, [x0, #0x248]                           S:'_OnAdClickedEvent'
02c8bdc8: bl      #0x2b70db0                                 fn_2b70db0
02c8bdcc: adrp    x0, #0x6265000                             
02c8bdd0: ldr     x0, [x0, #0x1e8]                           S:'_AD'
02c8bdd4: bl      #0x2b70db0                                 fn_2b70db0
02c8bdd8: mov     w8, #1                                     
02c8bddc: strb    w8, [x21, #0x983]                          
02c8bde0: cbz     x19, #0x2c8be9c                            
02c8bde4: adrp    x22, #0x6265000                            
02c8bde8: adrp    x21, #0x6265000                            
02c8bdec: mov     x2, xzr                                    
02c8bdf0: ldr     x22, [x22, #0x1e8]                         S:'_AD'
02c8bdf4: ldr     x21, [x21, #0x248]                         S:'_OnAdClickedEvent'
02c8bdf8: ldr     x0, [x19, #0x18]                           
02c8bdfc: ldr     x1, [x22]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c8be00: bl      #0x4c9c514                                 System.String::Concat
02c8be04: ldr     x8, [x19, #0x18]                           
02c8be08: ldr     x1, [x21]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c8be0c: mov     x21, x0                                    
02c8be10: mov     x2, xzr                                    
02c8be14: mov     x0, x8                                     
02c8be18: bl      #0x4c9c514                                 System.String::Concat
02c8be1c: mov     x1, x0                                     
02c8be20: mov     x0, x21                                    
02c8be24: mov     x2, xzr                                    
02c8be28: bl      #0x2c8b88c                                 AnalyticsManager::LogAdsEvent
02c8be2c: ldr     x0, [x20, #0x20]                           .placment
02c8be30: mov     x1, xzr                                    
02c8be34: bl      #0x4ca6234                                 System.String::IsNullOrEmpty
02c8be38: tbz     w0, #0, #0x2c8be4c                         
02c8be3c: ldp     x20, x19, [sp, #0x20]                      
02c8be40: ldp     x22, x21, [sp, #0x10]                      
02c8be44: ldr     x30, [sp], #0x30                           
02c8be48: ret                                                
02c8be4c: ldr     x0, [x19, #0x18]                           
02c8be50: ldr     x1, [x22]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c8be54: mov     x2, xzr                                    
02c8be58: bl      #0x4c9c514                                 System.String::Concat
02c8be5c: adrp    x9, #0x6265000                             
02c8be60: mov     x3, xzr                                    
02c8be64: ldr     x9, [x9, #0x240]                           S:'_OnAdClickedEvent_'
02c8be68: ldr     x8, [x19, #0x18]                           
02c8be6c: ldr     x2, [x20, #0x20]                           .placment
02c8be70: mov     x19, x0                                    
02c8be74: ldr     x1, [x9]                                   M:AdsManager::<OnApplicationPause>b__26_0
02c8be78: mov     x0, x8                                     
02c8be7c: bl      #0x4ca6dbc                                 System.String::Concat
02c8be80: mov     x1, x0                                     
02c8be84: mov     x0, x19                                    
02c8be88: mov     x2, xzr                                    
02c8be8c: ldp     x20, x19, [sp, #0x20]                      
02c8be90: ldp     x22, x21, [sp, #0x10]                      
02c8be94: ldr     x30, [sp], #0x30                           
02c8be98: b       #0x2c8b88c                                 AnalyticsManager::LogAdsEvent
02c8be9c: bl      #0x2b7105c                                 fn_2b7105c
## OnAdHiddenEvent(string adUnitID, MaxSdkBase/AdInfo adInfo) -> void
---- ApplovinEventBase::OnAdHiddenEvent 0x2c8bea0
02c8bea0: str     x30, [sp, #-0x30]!                         
02c8bea4: stp     x22, x21, [sp, #0x10]                      
02c8bea8: stp     x20, x19, [sp, #0x20]                      
02c8beac: adrp    x21, #0x662f000                            
02c8beb0: mov     x19, x2                                    
02c8beb4: mov     x20, x0                                    
02c8beb8: ldrb    w8, [x21, #0x984]                          
02c8bebc: tbnz    w8, #0, #0x2c8beec                         
02c8bec0: adrp    x0, #0x6265000                             
02c8bec4: ldr     x0, [x0, #0x250]                           S:'_OnAdHiddenEvent'
02c8bec8: bl      #0x2b70db0                                 fn_2b70db0
02c8becc: adrp    x0, #0x6265000                             
02c8bed0: ldr     x0, [x0, #0x258]                           S:'_OnAdHiddenEvent_'
02c8bed4: bl      #0x2b70db0                                 fn_2b70db0
02c8bed8: adrp    x0, #0x6265000                             
02c8bedc: ldr     x0, [x0, #0x1e8]                           S:'_AD'
02c8bee0: bl      #0x2b70db0                                 fn_2b70db0
02c8bee4: mov     w8, #1                                     
02c8bee8: strb    w8, [x21, #0x984]                          
02c8beec: cbz     x19, #0x2c8bfa8                            
02c8bef0: adrp    x22, #0x6265000                            
02c8bef4: adrp    x21, #0x6265000                            
02c8bef8: mov     x2, xzr                                    
02c8befc: ldr     x22, [x22, #0x1e8]                         S:'_AD'
02c8bf00: ldr     x21, [x21, #0x250]                         S:'_OnAdHiddenEvent'
02c8bf04: ldr     x0, [x19, #0x18]                           
02c8bf08: ldr     x1, [x22]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c8bf0c: bl      #0x4c9c514                                 System.String::Concat
02c8bf10: ldr     x8, [x19, #0x18]                           
02c8bf14: ldr     x1, [x21]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c8bf18: mov     x21, x0                                    
02c8bf1c: mov     x2, xzr                                    
02c8bf20: mov     x0, x8                                     
02c8bf24: bl      #0x4c9c514                                 System.String::Concat
02c8bf28: mov     x1, x0                                     
02c8bf2c: mov     x0, x21                                    
02c8bf30: mov     x2, xzr                                    
02c8bf34: bl      #0x2c8b88c                                 AnalyticsManager::LogAdsEvent
02c8bf38: ldr     x0, [x20, #0x20]                           .placment
02c8bf3c: mov     x1, xzr                                    
02c8bf40: bl      #0x4ca6234                                 System.String::IsNullOrEmpty
02c8bf44: tbz     w0, #0, #0x2c8bf58                         
02c8bf48: ldp     x20, x19, [sp, #0x20]                      
02c8bf4c: ldp     x22, x21, [sp, #0x10]                      
02c8bf50: ldr     x30, [sp], #0x30                           
02c8bf54: ret                                                
02c8bf58: ldr     x0, [x19, #0x18]                           
02c8bf5c: ldr     x1, [x22]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c8bf60: mov     x2, xzr                                    
02c8bf64: bl      #0x4c9c514                                 System.String::Concat
02c8bf68: adrp    x9, #0x6265000                             
02c8bf6c: mov     x3, xzr                                    
02c8bf70: ldr     x9, [x9, #0x258]                           S:'_OnAdHiddenEvent_'
02c8bf74: ldr     x8, [x19, #0x18]                           
02c8bf78: ldr     x2, [x20, #0x20]                           .placment
02c8bf7c: mov     x19, x0                                    
02c8bf80: ldr     x1, [x9]                                   M:AdsManager::<OnApplicationPause>b__26_0
02c8bf84: mov     x0, x8                                     
02c8bf88: bl      #0x4ca6dbc                                 System.String::Concat
02c8bf8c: mov     x1, x0                                     
02c8bf90: mov     x0, x19                                    
02c8bf94: mov     x2, xzr                                    
02c8bf98: ldp     x20, x19, [sp, #0x20]                      
02c8bf9c: ldp     x22, x21, [sp, #0x10]                      
02c8bfa0: ldr     x30, [sp], #0x30                           
02c8bfa4: b       #0x2c8b88c                                 AnalyticsManager::LogAdsEvent
02c8bfa8: bl      #0x2b7105c                                 fn_2b7105c
## OnAdDisplayFailedEvent(string adUnitId, MaxSdkBase/ErrorInfo errorInfo, MaxSdkBase/AdInfo adInfo) -> void
---- ApplovinEventBase::OnAdDisplayFailedEvent 0x2c8bfac
02c8bfac: stp     x30, x23, [sp, #-0x30]!                    
02c8bfb0: stp     x22, x21, [sp, #0x10]                      
02c8bfb4: stp     x20, x19, [sp, #0x20]                      
02c8bfb8: adrp    x22, #0x662f000                            
02c8bfbc: mov     x19, x3                                    
02c8bfc0: mov     x21, x2                                    
02c8bfc4: ldrb    w8, [x22, #0x985]                          
02c8bfc8: mov     x20, x0                                    
02c8bfcc: tbnz    w8, #0, #0x2c8c014                         
02c8bfd0: adrp    x0, #0x6265000                             
02c8bfd4: ldr     x0, [x0, #0x260]                           S:' '
02c8bfd8: bl      #0x2b70db0                                 fn_2b70db0
02c8bfdc: adrp    x0, #0x6265000                             
02c8bfe0: ldr     x0, [x0, #0x268]                           S:'OnAdAdFailedToDisplayEvent '
02c8bfe4: bl      #0x2b70db0                                 fn_2b70db0
02c8bfe8: adrp    x0, #0x6265000                             
02c8bfec: ldr     x0, [x0, #0x270]                           S:'_OnAdDisplayFailedEvent_'
02c8bff0: bl      #0x2b70db0                                 fn_2b70db0
02c8bff4: adrp    x0, #0x6265000                             
02c8bff8: ldr     x0, [x0, #0x278]                           S:'_OnAdDisplayFailedEvent'
02c8bffc: bl      #0x2b70db0                                 fn_2b70db0
02c8c000: adrp    x0, #0x6265000                             
02c8c004: ldr     x0, [x0, #0x1e8]                           S:'_AD'
02c8c008: bl      #0x2b70db0                                 fn_2b70db0
02c8c00c: mov     w8, #1                                     
02c8c010: strb    w8, [x22, #0x985]                          
02c8c014: cbz     x19, #0x2c8c104                            
02c8c018: cbz     x21, #0x2c8c104                            
02c8c01c: adrp    x8, #0x6265000                             
02c8c020: adrp    x9, #0x6265000                             
02c8c024: adrp    x22, #0x6265000                            
02c8c028: ldr     x8, [x8, #0x268]                           S:'OnAdAdFailedToDisplayEvent '
02c8c02c: ldr     x9, [x9, #0x260]                           S:' '
02c8c030: adrp    x23, #0x6265000                            
02c8c034: ldr     x22, [x22, #0x1e8]                         S:'_AD'
02c8c038: ldr     x23, [x23, #0x278]                         S:'_OnAdDisplayFailedEvent'
02c8c03c: ldr     x1, [x19, #0x18]                           
02c8c040: ldr     x3, [x21, #0x18]                           
02c8c044: ldr     x0, [x8]                                   M:AdsManager::<OnApplicationPause>b__26_0
02c8c048: ldr     x2, [x9]                                   M:AdsManager::<OnApplicationPause>b__26_0
02c8c04c: mov     x4, xzr                                    
02c8c050: bl      #0x4ca7320                                 System.String::Concat
02c8c054: mov     x1, xzr                                    
02c8c058: bl      #0x2ca09f8                                 WLog::LogError
02c8c05c: ldr     x0, [x19, #0x18]                           
02c8c060: ldr     x1, [x22]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c8c064: mov     x2, xzr                                    
02c8c068: bl      #0x4c9c514                                 System.String::Concat
02c8c06c: ldr     x8, [x19, #0x18]                           
02c8c070: ldr     x1, [x23]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c8c074: mov     x21, x0                                    
02c8c078: mov     x2, xzr                                    
02c8c07c: mov     x0, x8                                     
02c8c080: bl      #0x4c9c514                                 System.String::Concat
02c8c084: mov     x1, x0                                     
02c8c088: mov     x0, x21                                    
02c8c08c: mov     x2, xzr                                    
02c8c090: bl      #0x2c8b88c                                 AnalyticsManager::LogAdsEvent
02c8c094: ldr     x0, [x20, #0x20]                           .placment
02c8c098: mov     x1, xzr                                    
02c8c09c: bl      #0x4ca6234                                 System.String::IsNullOrEmpty
02c8c0a0: tbz     w0, #0, #0x2c8c0b4                         
02c8c0a4: ldp     x20, x19, [sp, #0x20]                      
02c8c0a8: ldp     x22, x21, [sp, #0x10]                      
02c8c0ac: ldp     x30, x23, [sp], #0x30                      
02c8c0b0: ret                                                
02c8c0b4: ldr     x0, [x19, #0x18]                           
02c8c0b8: ldr     x1, [x22]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c8c0bc: mov     x2, xzr                                    
02c8c0c0: bl      #0x4c9c514                                 System.String::Concat
02c8c0c4: adrp    x9, #0x6265000                             
02c8c0c8: mov     x3, xzr                                    
02c8c0cc: ldr     x9, [x9, #0x270]                           S:'_OnAdDisplayFailedEvent_'
02c8c0d0: ldr     x8, [x19, #0x18]                           
02c8c0d4: ldr     x2, [x20, #0x20]                           .placment
02c8c0d8: mov     x19, x0                                    
02c8c0dc: ldr     x1, [x9]                                   M:AdsManager::<OnApplicationPause>b__26_0
02c8c0e0: mov     x0, x8                                     
02c8c0e4: bl      #0x4ca6dbc                                 System.String::Concat
02c8c0e8: mov     x1, x0                                     
02c8c0ec: mov     x0, x19                                    
02c8c0f0: mov     x2, xzr                                    
02c8c0f4: ldp     x20, x19, [sp, #0x20]                      
02c8c0f8: ldp     x22, x21, [sp, #0x10]                      
02c8c0fc: ldp     x30, x23, [sp], #0x30                      
02c8c100: b       #0x2c8b88c                                 AnalyticsManager::LogAdsEvent
02c8c104: bl      #0x2b7105c                                 fn_2b7105c
## OnAdRevenuePaidEvent(string adUnitId, MaxSdkBase/AdInfo adInfo) -> void
---- ApplovinEventBase::OnAdRevenuePaidEvent 0x2c8c108
02c8c108: stp     x30, x19, [sp, #-0x10]!                    
02c8c10c: mov     x0, x2                                     
02c8c110: mov     x19, x2                                    
02c8c114: bl      #0x2c8c124                                 AnalyticsManager::LogFirebaseApplovinRevenue
02c8c118: mov     x0, x19                                    
02c8c11c: ldp     x30, x19, [sp], #0x10                      
02c8c120: b       #0x2c8c5c8                                 AnalyticsManager::LogAppsflyerApplovinRevenue
## .ctor() -> void
---- ApplovinEventBase::.ctor 0x2c8c870
02c8c870: stp     x30, x21, [sp, #-0x20]!                    
02c8c874: stp     x20, x19, [sp, #0x10]                      
02c8c878: adrp    x20, #0x662f000                            
02c8c87c: adrp    x21, #0x6263000                            
02c8c880: mov     x19, x0                                    
02c8c884: ldrb    w8, [x20, #0x986]                          
02c8c888: ldr     x21, [x21, #0xa90]                         S:''
02c8c88c: tbnz    w8, #0, #0x2c8c8a4                         
02c8c890: adrp    x0, #0x6263000                             
02c8c894: ldr     x0, [x0, #0xa90]                           S:''
02c8c898: bl      #0x2b70db0                                 fn_2b70db0
02c8c89c: mov     w8, #1                                     
02c8c8a0: strb    w8, [x20, #0x986]                          
02c8c8a4: ldr     x1, [x21]                                  &2c5bbd4(=a9bd7bfdd503233f)
02c8c8a8: mov     x0, x19                                    
02c8c8ac: str     x1, [x0, #0x20]!                           .placment
02c8c8b0: bl      #0x2b70d54                                 fn_2b70d54
02c8c8b4: mov     x0, x19                                    
02c8c8b8: ldp     x20, x19, [sp, #0x10]                      
02c8c8bc: mov     x1, xzr                                    
02c8c8c0: ldp     x30, x21, [sp], #0x20                      
02c8c8c4: b       #0x5b397b0                                 UnityEngine.MonoBehaviour::.ctor
