#### CLASS Decor.CategoryPanel parent= UnityEngine.MonoBehaviour
#   field _contentParent                 UnityEngine.RectTransform                          off=0x20 attr=1 SerializeField
#   field _categoryItems                 System.Collections.Generic.List`1<Decor.CategoryItem> off=0x28 attr=1 SerializeField
#   field _selectedCategoryItem          Decor.CategoryItem                                 off=0x30 attr=1 
#   field _decorPanel                    Decor.DecorPanel                                   off=0x38 attr=1 
## OnInit(Decor.DecorPanel decorPanel) -> void
---- Decor.CategoryPanel::OnInit 0x2d27158
02d27158: stp     x30, x19, [sp, #-0x10]!                    
02d2715c: mov     x19, x0                                    
02d27160: str     x1, [x0, #0x38]!                           ._decorPanel
02d27164: bl      #0x2b70d54                                 fn_2b70d54
02d27168: mov     x0, x19                                    
02d2716c: ldp     x30, x19, [sp], #0x10                      
02d27170: b       #0x2d27174                                 Decor.CategoryPanel::Setup
## SelectDefaultCategory() -> void
---- Decor.CategoryPanel::SelectDefaultCategory 0x2d273ac
02d273ac: str     x30, [sp, #-0x20]!                         
02d273b0: stp     x20, x19, [sp, #0x10]                      
02d273b4: adrp    x20, #0x6630000                            
02d273b8: mov     x19, x0                                    
02d273bc: ldrb    w8, [x20, #0x8b]                           
02d273c0: tbnz    w8, #0, #0x2d273d8                         
02d273c4: adrp    x0, #0x626a000                             
02d273c8: ldr     x0, [x0, #0x168]                           MS:System.Collections.Generic.List`1::get_Item
02d273cc: bl      #0x2b70db0                                 fn_2b70db0
02d273d0: mov     w8, #1                                     
02d273d4: strb    w8, [x20, #0x8b]                           
02d273d8: ldr     x0, [x19, #0x28]                           ._categoryItems
02d273dc: cbz     x0, #0x2d27410                             
02d273e0: adrp    x8, #0x626a000                             
02d273e4: mov     w1, wzr                                    
02d273e8: ldr     x8, [x8, #0x168]                           MS:System.Collections.Generic.List`1::get_Item
02d273ec: ldr     x2, [x8]                                   T:type56879(k15)
02d273f0: bl      #0x35a8f3c                                 fn_35a8f3c
02d273f4: mov     x1, x0                                     
02d273f8: mov     x0, x19                                    
02d273fc: bl      #0x2d27414                                 Decor.CategoryPanel::SelectedCategory
02d27400: mov     x0, x19                                    
02d27404: ldp     x20, x19, [sp, #0x10]                      
02d27408: ldr     x30, [sp], #0x20                           
02d2740c: b       #0x2d27568                                 Decor.CategoryPanel::Refresh
02d27410: bl      #0x2b7105c                                 fn_2b7105c
## Setup() -> void
---- Decor.CategoryPanel::Setup 0x2d27174
02d27174: sub     sp, sp, #0x80                              
02d27178: str     x30, [sp, #0x30]                           
02d2717c: stp     x26, x25, [sp, #0x40]                      
02d27180: stp     x24, x23, [sp, #0x50]                      
02d27184: stp     x22, x21, [sp, #0x60]                      
02d27188: stp     x20, x19, [sp, #0x70]                      
02d2718c: adrp    x20, #0x6630000                            
02d27190: mov     x19, x0                                    
02d27194: ldrb    w8, [x20, #0x8c]                           
02d27198: tbnz    w8, #0, #0x2d27210                         
02d2719c: adrp    x0, #0x626a000                             
02d271a0: ldr     x0, [x0, #0x130]                           T:type6841(k15)
02d271a4: bl      #0x2b70db0                                 fn_2b70db0
02d271a8: adrp    x0, #0x626a000                             
02d271ac: ldr     x0, [x0, #0x138]                           M:Decor.CategoryPanel::OnCategoryItemClicked
02d271b0: bl      #0x2b70db0                                 fn_2b70db0
02d271b4: adrp    x0, #0x6266000                             
02d271b8: ldr     x0, [x0, #0x870]                           MS:DataManager::GetAsset
02d271bc: bl      #0x2b70db0                                 fn_2b70db0
02d271c0: adrp    x0, #0x626a000                             
02d271c4: ldr     x0, [x0, #0x140]                           MS:System.Collections.Generic.List`1/Enumerator::Dispose
02d271c8: bl      #0x2b70db0                                 fn_2b70db0
02d271cc: adrp    x0, #0x626a000                             
02d271d0: ldr     x0, [x0, #0x148]                           MS:System.Collections.Generic.List`1/Enumerator::MoveNext
02d271d4: bl      #0x2b70db0                                 fn_2b70db0
02d271d8: adrp    x0, #0x626a000                             
02d271dc: ldr     x0, [x0, #0x150]                           MS:System.Collections.Generic.List`1/Enumerator::get_Current
02d271e0: bl      #0x2b70db0                                 fn_2b70db0
02d271e4: adrp    x0, #0x626a000                             
02d271e8: ldr     x0, [x0, #0x158]                           MS:System.Collections.Generic.List`1::Clear
02d271ec: bl      #0x2b70db0                                 fn_2b70db0
02d271f0: adrp    x0, #0x626a000                             
02d271f4: ldr     x0, [x0, #0x160]                           MS:System.Collections.Generic.List`1::GetEnumerator
02d271f8: bl      #0x2b70db0                                 fn_2b70db0
02d271fc: adrp    x0, #0x6266000                             
02d27200: ldr     x0, [x0, #0x658]                           MS:MonoSingleton`1::get_Instance
02d27204: bl      #0x2b70db0                                 fn_2b70db0
02d27208: mov     w8, #1                                     
02d2720c: strb    w8, [x20, #0x8c]                           
02d27210: ldr     x8, [x19, #0x28]                           ._categoryItems
02d27214: stp     xzr, xzr, [sp, #0x18]                      
02d27218: str     xzr, [sp, #0x28]                           
02d2721c: cbz     x8, #0x2d27348                             
02d27220: ldp     w2, w9, [x8, #0x18]                        
02d27224: adrp    x20, #0x6266000                            
02d27228: ldr     x20, [x20, #0x658]                         MS:MonoSingleton`1::get_Instance
02d2722c: add     w9, w9, #1                                 
02d27230: cmp     w2, #1                                     
02d27234: stp     wzr, w9, [x8, #0x18]                       
02d27238: b.lt    #0x2d2724c                                 
02d2723c: ldr     x0, [x8, #0x10]                            
02d27240: mov     w1, wzr                                    
02d27244: mov     x3, xzr                                    
02d27248: bl      #0x4e3494c                                 System.Array::Clear
02d2724c: ldr     x0, [x20]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d27250: bl      #0x3769600                                 fn_3769600
02d27254: cbz     x0, #0x2d27348                             
02d27258: adrp    x8, #0x6266000                             
02d2725c: ldr     x8, [x8, #0x870]                           MS:DataManager::GetAsset
02d27260: ldr     x1, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d27264: bl      #0x3168af0                                 fn_3168af0
02d27268: cbz     x0, #0x2d27348                             
02d2726c: ldr     x0, [x0, #0x18]                            S:'level_show_popuprate'
02d27270: cbz     x0, #0x2d27348                             
02d27274: adrp    x8, #0x626a000                             
02d27278: adrp    x23, #0x626a000                            
02d2727c: adrp    x24, #0x626a000                            
02d27280: ldr     x8, [x8, #0x160]                           MS:System.Collections.Generic.List`1::GetEnumerator
02d27284: adrp    x25, #0x626a000                            
02d27288: adrp    x22, #0x626a000                            
02d2728c: ldr     x23, [x23, #0x148]                         MS:System.Collections.Generic.List`1/Enumerator::MoveNext
02d27290: ldr     x24, [x24, #0x130]                         T:type6841(k15)
02d27294: ldr     x25, [x25, #0x138]                         M:Decor.CategoryPanel::OnCategoryItemClicked
02d27298: ldr     x22, [x22, #0x140]                         MS:System.Collections.Generic.List`1/Enumerator::Dispose
02d2729c: ldr     x1, [x8]                                   T:type56879(k15)
02d272a0: add     x8, sp, #0x18                              
02d272a4: add     x20, sp, #0x18                             
02d272a8: bl      #0x35a9d9c                                 fn_35a9d9c
02d272ac: stp     xzr, x20, [sp, #8]                         
02d272b0: ldr     x1, [x23]                                  T:type56879(k15)
02d272b4: add     x0, sp, #0x18                              
02d272b8: bl      #0x4690474                                 fn_4690474
02d272bc: tbz     w0, #0, #0x2d27310                         
02d272c0: ldr     x26, [sp, #0x28]                           
02d272c4: mov     x0, x19                                    
02d272c8: bl      #0x2d27668                                 Decor.CategoryPanel::CreateCategoryItem
02d272cc: mov     x20, x0                                    
02d272d0: ldr     x0, [x24]                                  T:type56879(k15)
02d272d4: bl      #0x2b7104c                                 fn_2b7104c
02d272d8: mov     x21, x0                                    
02d272dc: ldr     x2, [x25]                                  T:type56879(k15)
02d272e0: mov     x1, x19                                    
02d272e4: mov     x3, xzr                                    
02d272e8: bl      #0x453418c                                 fn_453418c
02d272ec: cbz     x20, #0x2d27340                            
02d272f0: mov     x0, x20                                    
02d272f4: mov     x1, x21                                    
02d272f8: bl      #0x2d26e3c                                 Decor.CategoryItem::OnInit
02d272fc: cbz     x26, #0x2d27344                            
02d27300: ldp     x1, x2, [x26, #0x20]                       
02d27304: mov     x0, x20                                    
02d27308: bl      #0x2d26f94                                 Decor.CategoryItem::SetIcon
02d2730c: b       #0x2d272b0                                 
02d27310: ldr     x1, [x22]                                  T:type56879(k15)
02d27314: add     x0, sp, #0x18                              
02d27318: bl      #0x4690470                                 fn_4690470
02d2731c: mov     x0, x19                                    
02d27320: bl      #0x2d27568                                 Decor.CategoryPanel::Refresh
02d27324: ldp     x20, x19, [sp, #0x70]                      
02d27328: ldr     x30, [sp, #0x30]                           
02d2732c: ldp     x22, x21, [sp, #0x60]                      
02d27330: ldp     x24, x23, [sp, #0x50]                      
02d27334: ldp     x26, x25, [sp, #0x40]                      
02d27338: add     sp, sp, #0x80                              
02d2733c: ret                                                
02d27340: bl      #0x2b7105c                                 fn_2b7105c
02d27344: bl      #0x2b7105c                                 fn_2b7105c
02d27348: bl      #0x2b7105c                                 fn_2b7105c
02d2734c: b       #0x2d27364                                 
02d27350: b       #0x2d27364                                 
02d27354: b       #0x2d27364                                 
02d27358: b       #0x2d27364                                 
02d2735c: b       #0x2d27364                                 
02d27360: b       #0x2d27364                                 
02d27364: cmp     w1, #1                                     
02d27368: b.ne    #0x2d27394                                 
02d2736c: bl      #0x5e90260                                 fn_5e90260
02d27370: ldr     x20, [x0]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d27374: str     x20, [sp, #8]                              
02d27378: bl      #0x5e90270                                 fn_5e90270
02d2737c: ldr     x0, [sp, #0x10]                            
02d27380: ldr     x1, [x22]                                  T:type56879(k15)
02d27384: bl      #0x4690470                                 fn_4690470
02d27388: cbz     x20, #0x2d2731c                            
02d2738c: mov     x0, x20                                    
02d27390: bl      #0x2b71054                                 fn_2b71054
02d27394: mov     x19, x0                                    
02d27398: add     x0, sp, #8                                 
02d2739c: bl      #0x2738108                                 fn_2738108
02d273a0: mov     x0, x19                                    
02d273a4: bl      #0x2c6051c                                 fn_2c6051c
02d273a8: bl      #0x27369b8                                 fn_27369b8
## Refresh() -> void
---- Decor.CategoryPanel::Refresh 0x2d27568
02d27568: str     x30, [sp, #-0x40]!                         
02d2756c: stp     x24, x23, [sp, #0x10]                      
02d27570: stp     x22, x21, [sp, #0x20]                      
02d27574: stp     x20, x19, [sp, #0x30]                      
02d27578: adrp    x20, #0x6630000                            
02d2757c: mov     x19, x0                                    
02d27580: ldrb    w8, [x20, #0x8d]                           
02d27584: tbnz    w8, #0, #0x2d275b4                         
02d27588: adrp    x0, #0x626a000                             
02d2758c: ldr     x0, [x0, #0x178]                           MS:System.Collections.Generic.List`1::get_Count
02d27590: bl      #0x2b70db0                                 fn_2b70db0
02d27594: adrp    x0, #0x626a000                             
02d27598: ldr     x0, [x0, #0x168]                           MS:System.Collections.Generic.List`1::get_Item
02d2759c: bl      #0x2b70db0                                 fn_2b70db0
02d275a0: adrp    x0, #0x626a000                             
02d275a4: ldr     x0, [x0, #0x180]                           MS:MonoSingleton`1::get_Instance
02d275a8: bl      #0x2b70db0                                 fn_2b70db0
02d275ac: mov     w8, #1                                     
02d275b0: strb    w8, [x20, #0x8d]                           
02d275b4: ldr     x8, [x19, #0x28]                           ._categoryItems
02d275b8: cbz     x8, #0x2d27638                             
02d275bc: adrp    x23, #0x626a000                            
02d275c0: adrp    x24, #0x626a000                            
02d275c4: mov     w22, wzr                                   
02d275c8: ldr     x23, [x23, #0x180]                         MS:MonoSingleton`1::get_Instance
02d275cc: ldr     x24, [x24, #0x168]                         MS:System.Collections.Generic.List`1::get_Item
02d275d0: mov     w20, wzr                                   
02d275d4: ldr     w8, [x8, #0x18]                            
02d275d8: cmp     w20, w8                                    
02d275dc: b.ge    #0x2d2763c                                 
02d275e0: ldr     x0, [x23]                                  T:type56879(k15)
02d275e4: bl      #0x3769600                                 fn_3769600
02d275e8: cbz     x0, #0x2d27638                             
02d275ec: mov     w1, w20                                    
02d275f0: bl      #0x2d26a08                                 Decor.DecorController::CanAnyBuyOption
02d275f4: ldr     x8, [x19, #0x28]                           ._categoryItems
02d275f8: cbz     x8, #0x2d27638                             
02d275fc: ldr     x2, [x24]                                  T:type56879(k15)
02d27600: mov     w21, w0                                    
02d27604: mov     x0, x8                                     
02d27608: mov     w1, w20                                    
02d2760c: bl      #0x35a8f3c                                 fn_35a8f3c
02d27610: cbz     x0, #0x2d27638                             
02d27614: ldr     x0, [x0, #0x38]                            MS:System.Collections.Generic.List`1::get_Item ._decorPanel
02d27618: cbz     x0, #0x2d27638                             
02d2761c: and     w1, w21, #1                                
02d27620: mov     x2, xzr                                    
02d27624: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d27628: ldr     x8, [x19, #0x28]                           ._categoryItems
02d2762c: orr     w22, w21, w22                              
02d27630: add     w20, w20, #1                               
02d27634: cbnz    x8, #0x2d275d4                             
02d27638: bl      #0x2b7105c                                 fn_2b7105c
02d2763c: ldr     x8, [x19, #0x38]                           ._decorPanel
02d27640: cbz     x8, #0x2d27638                             
02d27644: ldr     x0, [x8, #0x50]                            
02d27648: cbz     x0, #0x2d27638                             
02d2764c: and     w1, w22, #1                                
02d27650: ldp     x20, x19, [sp, #0x30]                      
02d27654: ldp     x22, x21, [sp, #0x20]                      
02d27658: mov     x2, xzr                                    
02d2765c: ldp     x24, x23, [sp, #0x10]                      
02d27660: ldr     x30, [sp], #0x40                           
02d27664: b       #0x5b36b38                                 UnityEngine.GameObject::SetActive
## SelectedCategory(Decor.CategoryItem categoryItem) -> void
---- Decor.CategoryPanel::SelectedCategory 0x2d27414
02d27414: str     x30, [sp, #-0x30]!                         
02d27418: stp     x22, x21, [sp, #0x10]                      
02d2741c: stp     x20, x19, [sp, #0x20]                      
02d27420: adrp    x22, #0x6630000                            
02d27424: adrp    x21, #0x6263000                            
02d27428: mov     x20, x1                                    
02d2742c: ldrb    w8, [x22, #0x8e]                           
02d27430: ldr     x21, [x21, #0x918]                         T:UnityEngine.Object
02d27434: mov     x19, x0                                    
02d27438: tbnz    w8, #0, #0x2d27474                         
02d2743c: adrp    x0, #0x6266000                             
02d27440: ldr     x0, [x0, #0x878]                           MS:DataManager::GetData
02d27444: bl      #0x2b70db0                                 fn_2b70db0
02d27448: adrp    x0, #0x626a000                             
02d2744c: ldr     x0, [x0, #0x170]                           MS:System.Collections.Generic.List`1::IndexOf
02d27450: bl      #0x2b70db0                                 fn_2b70db0
02d27454: adrp    x0, #0x6266000                             
02d27458: ldr     x0, [x0, #0x658]                           MS:MonoSingleton`1::get_Instance
02d2745c: bl      #0x2b70db0                                 fn_2b70db0
02d27460: adrp    x0, #0x6263000                             
02d27464: ldr     x0, [x0, #0x918]                           T:UnityEngine.Object
02d27468: bl      #0x2b70db0                                 fn_2b70db0
02d2746c: mov     w8, #1                                     
02d27470: strb    w8, [x22, #0x8e]                           
02d27474: ldr     x0, [x21]                                  &2c5bbd4(=a9bd7bfdd503233f)
02d27478: mov     x21, x19                                   
02d2747c: ldr     x22, [x21, #0x30]!                         &16c9019(=424f4c475f32314e) ._selectedCategoryItem
02d27480: ldr     w8, [x0, #0xe4]                            [62630e4]=0 f=0,0
02d27484: cbnz    w8, #0x2d2748c                             
02d27488: bl      #0x2b70f30                                 fn_2b70f30
02d2748c: mov     x0, x22                                    
02d27490: mov     x1, xzr                                    
02d27494: mov     x2, xzr                                    
02d27498: bl      #0x5b3666c                                 UnityEngine.Object::op_Inequality
02d2749c: tbz     w0, #0, #0x2d274c0                         
02d274a0: ldr     x0, [x21]                                  &2c5bbd4(=a9bd7bfdd503233f)
02d274a4: cbz     x0, #0x2d27564                             
02d274a8: mov     w1, wzr                                    
02d274ac: bl      #0x2d26f38                                 Decor.CategoryItem::SetSelected
02d274b0: mov     x0, x21                                    
02d274b4: mov     x1, xzr                                    
02d274b8: str     xzr, [x21]                                 
02d274bc: bl      #0x2b70d54                                 fn_2b70d54
02d274c0: mov     x0, x21                                    
02d274c4: mov     x1, x20                                    
02d274c8: str     x20, [x21]                                 
02d274cc: bl      #0x2b70d54                                 fn_2b70d54
02d274d0: ldr     x0, [x21]                                  &2c5bbd4(=a9bd7bfdd503233f)
02d274d4: cbz     x0, #0x2d27564                             
02d274d8: mov     w1, #1                                     
02d274dc: bl      #0x2d26f38                                 Decor.CategoryItem::SetSelected
02d274e0: ldr     x0, [x19, #0x28]                           ._categoryItems
02d274e4: cbz     x0, #0x2d27564                             
02d274e8: adrp    x8, #0x626a000                             
02d274ec: adrp    x20, #0x6266000                            
02d274f0: ldr     x8, [x8, #0x170]                           MS:System.Collections.Generic.List`1::IndexOf
02d274f4: ldr     x20, [x20, #0x658]                         MS:MonoSingleton`1::get_Instance
02d274f8: ldr     x1, [x21]                                  &2c5bbd4(=a9bd7bfdd503233f)
02d274fc: ldr     x2, [x8]                                   T:type56879(k15)
02d27500: bl      #0x35a9f48                                 fn_35a9f48
02d27504: ldr     x8, [x20]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d27508: mov     w20, w0                                    
02d2750c: mov     x0, x8                                     
02d27510: bl      #0x3769600                                 fn_3769600
02d27514: cbz     x0, #0x2d27564                             
02d27518: adrp    x8, #0x6266000                             
02d2751c: ldr     x8, [x8, #0x878]                           MS:DataManager::GetData
02d27520: ldr     x1, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d27524: bl      #0x3168dd0                                 fn_3168dd0
02d27528: cbz     x0, #0x2d27564                             
02d2752c: mov     w1, w20                                    
02d27530: bl      #0x2d25c44                                 Decor.DataDecor::GetSelectedItem
02d27534: ldr     x8, [x19, #0x38]                           ._decorPanel
02d27538: cbz     x8, #0x2d27564                             
02d2753c: mov     w19, w0                                    
02d27540: ldr     x0, [x8, #0x48]                            S:'native_full_srceen_id'
02d27544: cbz     x0, #0x2d27564                             
02d27548: mov     w1, w20                                    
02d2754c: bl      #0x2d27864                                 Decor.OptionPanel::Setup
02d27550: mov     w1, w19                                    
02d27554: ldp     x20, x19, [sp, #0x20]                      
02d27558: ldp     x22, x21, [sp, #0x10]                      
02d2755c: ldr     x30, [sp], #0x30                           
02d27560: b       #0x2d27b48                                 Decor.OptionPanel::SelectedOptionItemByIndex
02d27564: bl      #0x2b7105c                                 fn_2b7105c
## CreateCategoryItem() -> Decor.CategoryItem
---- Decor.CategoryPanel::CreateCategoryItem 0x2d27668
02d27668: str     d10, [sp, #-0x40]!                         
02d2766c: stp     d9, d8, [sp, #8]                           
02d27670: str     x30, [sp, #0x18]                           
02d27674: stp     x22, x21, [sp, #0x20]                      
02d27678: stp     x20, x19, [sp, #0x30]                      
02d2767c: adrp    x20, #0x6630000                            
02d27680: adrp    x21, #0x6266000                            
02d27684: mov     x19, x0                                    
02d27688: ldrb    w8, [x20, #0x8f]                           
02d2768c: ldr     x21, [x21, #0xd20]                         MS:MonoSingleton`1::get_Instance
02d27690: tbnz    w8, #0, #0x2d276c0                         
02d27694: adrp    x0, #0x626a000                             
02d27698: ldr     x0, [x0, #0x188]                           MS:UnityEngine.Component::GetComponent
02d2769c: bl      #0x2b70db0                                 fn_2b70db0
02d276a0: adrp    x0, #0x626a000                             
02d276a4: ldr     x0, [x0, #0x190]                           MS:System.Collections.Generic.List`1::Add
02d276a8: bl      #0x2b70db0                                 fn_2b70db0
02d276ac: adrp    x0, #0x6266000                             
02d276b0: ldr     x0, [x0, #0xd20]                           MS:MonoSingleton`1::get_Instance
02d276b4: bl      #0x2b70db0                                 fn_2b70db0
02d276b8: mov     w8, #1                                     
02d276bc: strb    w8, [x20, #0x8f]                           
02d276c0: ldr     x0, [x21]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d276c4: bl      #0x3769600                                 fn_3769600
02d276c8: adrp    x21, #0x662f000                            
02d276cc: mov     x20, x0                                    
02d276d0: ldrb    w8, [x21, #0x91a]                          
02d276d4: cbnz    w8, #0x2d276ec                             
02d276d8: adrp    x0, #0x6264000                             
02d276dc: ldr     x0, [x0, #0xd8]                            T:UnityEngine.Vector3
02d276e0: bl      #0x2b70db0                                 fn_2b70db0
02d276e4: mov     w8, #1                                     
02d276e8: strb    w8, [x21, #0x91a]                          
02d276ec: adrp    x21, #0x6264000                            
02d276f0: adrp    x22, #0x662f000                            
02d276f4: ldr     x21, [x21, #0xd8]                          T:UnityEngine.Vector3
02d276f8: ldrb    w9, [x22, #0xbdf]                          
02d276fc: ldr     x8, [x21]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d27700: ldr     x8, [x8, #0xb8]                            
02d27704: ldp     s8, s9, [x8]                               
02d27708: ldr     s10, [x8, #8]                              
02d2770c: cbnz    w9, #0x2d27724                             
02d27710: adrp    x0, #0x6266000                             
02d27714: ldr     x0, [x0, #0xd30]                           T:UnityEngine.Quaternion
02d27718: bl      #0x2b70db0                                 fn_2b70db0
02d2771c: mov     w8, #1                                     
02d27720: strb    w8, [x22, #0xbdf]                          
02d27724: cbz     x20, #0x2d27844                            
02d27728: adrp    x8, #0x6266000                             
02d2772c: fmov    s0, s8                                     
02d27730: fmov    s1, s9                                     
02d27734: ldr     x8, [x8, #0xd30]                           T:UnityEngine.Quaternion
02d27738: fmov    s2, s10                                    
02d2773c: ldr     x2, [x19, #0x20]                           ._contentParent
02d27740: mov     x0, x20                                    
02d27744: mov     w1, #6                                     
02d27748: mov     x3, xzr                                    
02d2774c: ldr     x8, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d27750: ldr     x8, [x8, #0xb8]                            S:'banner_native_refresh_time'
02d27754: ldp     s5, s6, [x8, #8]                           
02d27758: ldp     s3, s4, [x8]                               
02d2775c: bl      #0x2cdcef0                                 PoolManager::SpawnObject
02d27760: cbz     x0, #0x2d27844                             
02d27764: adrp    x8, #0x626a000                             
02d27768: ldr     x8, [x8, #0x188]                           MS:UnityEngine.Component::GetComponent
02d2776c: ldr     x1, [x8]                                   T:type56879(k15)
02d27770: bl      #0x3140c84                                 fn_3140c84
02d27774: adrp    x22, #0x662f000                            
02d27778: mov     x20, x0                                    
02d2777c: ldrb    w8, [x22, #0xa74]                          
02d27780: cbnz    w8, #0x2d27798                             
02d27784: adrp    x0, #0x6264000                             
02d27788: ldr     x0, [x0, #0xd8]                            T:UnityEngine.Vector3
02d2778c: bl      #0x2b70db0                                 fn_2b70db0
02d27790: mov     w8, #1                                     
02d27794: strb    w8, [x22, #0xa74]                          
02d27798: cbz     x20, #0x2d27844                            
02d2779c: ldr     x8, [x21]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d277a0: ldr     x9, [x20]                                  
02d277a4: mov     x0, x20                                    
02d277a8: ldr     x8, [x8, #0xb8]                            MS:UnityEngine.Object::FindObjectsOfType
02d277ac: ldp     s1, s2, [x8, #0x10]                        
02d277b0: ldr     s0, [x8, #0xc]                             [626a00c]=0 f=0,0
02d277b4: ldp     x8, x1, [x9, #0x1b8]                       
02d277b8: blr     x8                                         
02d277bc: ldr     x0, [x19, #0x28]                           ._categoryItems
02d277c0: cbz     x0, #0x2d27844                             
02d277c4: adrp    x9, #0x626a000                             
02d277c8: ldr     x9, [x9, #0x190]                           MS:System.Collections.Generic.List`1::Add
02d277cc: ldr     w10, [x0, #0x1c]                           [626401c]=0 f=0,0
02d277d0: ldr     x8, [x0, #0x10]                            M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass2_0::<DOSetFloat>b__0
02d277d4: ldr     x9, [x9]                                   T:type56879(k15)
02d277d8: add     w10, w10, #1                               
02d277dc: str     w10, [x0, #0x1c]                           
02d277e0: cbz     x8, #0x2d27844                             
02d277e4: ldrsw   x10, [x0, #0x18]                           
02d277e8: ldr     w11, [x8, #0x18]                           MS:System.Collections.Generic.List`1::Add
02d277ec: cmp     w10, w11                                   
02d277f0: b.hs    #0x2d27814                                 
02d277f4: add     x8, x8, x10, lsl #3                        &626a000
02d277f8: add     w9, w10, #1                                
02d277fc: mov     x1, x20                                    
02d27800: str     w9, [x0, #0x18]                            
02d27804: str     x20, [x8, #0x20]!                          
02d27808: mov     x0, x8                                     
02d2780c: bl      #0x2b70d54                                 fn_2b70d54
02d27810: b       #0x2d27828                                 
02d27814: ldr     x8, [x9, #0x20]                            M:Decor.DataDecor/<>c__DisplayClass8_0::<NewData>b__0
02d27818: mov     x1, x20                                    
02d2781c: ldr     x8, [x8, #0xc0]                            S:'Main character is null'
02d27820: ldr     x2, [x8, #0x70]                            MS:System.Collections.Generic.List`1::FindIndex
02d27824: bl      #0x35a920c                                 fn_35a920c
02d27828: mov     x0, x20                                    
02d2782c: ldp     x20, x19, [sp, #0x30]                      
02d27830: ldp     x22, x21, [sp, #0x20]                      
02d27834: ldr     x30, [sp, #0x18]                           
02d27838: ldp     d9, d8, [sp, #8]                           
02d2783c: ldr     d10, [sp], #0x40                           
02d27840: ret                                                
02d27844: bl      #0x2b7105c                                 fn_2b7105c
## OnCategoryItemClicked(Decor.CategoryItem categoryItem) -> void
---- Decor.CategoryPanel::OnCategoryItemClicked 0x2d27bd4
02d27bd4: stp     x30, x21, [sp, #-0x20]!                    
02d27bd8: stp     x20, x19, [sp, #0x10]                      
02d27bdc: adrp    x21, #0x6630000                            
02d27be0: mov     x19, x1                                    
02d27be4: mov     x20, x0                                    
02d27be8: ldrb    w8, [x21, #0x90]                           
02d27bec: tbnz    w8, #0, #0x2d27c04                         
02d27bf0: adrp    x0, #0x6267000                             
02d27bf4: ldr     x0, [x0, #0xd50]                           MS:MonoSingleton`1::get_Instance
02d27bf8: bl      #0x2b70db0                                 fn_2b70db0
02d27bfc: mov     w8, #1                                     
02d27c00: strb    w8, [x21, #0x90]                           
02d27c04: mov     x0, x20                                    
02d27c08: bl      #0x2d27568                                 Decor.CategoryPanel::Refresh
02d27c0c: mov     x0, xzr                                    
02d27c10: bl      #0x2d6eec8                                 Framework.AudioManager::get_Instance
02d27c14: cbz     x0, #0x2d27c78                             
02d27c18: movi    d1, #0000000000000000                      
02d27c1c: movi    d2, #0000000000000000                      
02d27c20: adrp    x21, #0x6267000                            
02d27c24: fmov    s0, #1.00000000                            
02d27c28: ldr     x21, [x21, #0xd50]                         MS:MonoSingleton`1::get_Instance
02d27c2c: mov     w1, #1                                     
02d27c30: mov     w2, wzr                                    
02d27c34: mov     w3, wzr                                    
02d27c38: mov     x4, xzr                                    
02d27c3c: bl      #0x2d6f03c                                 Framework.AudioManager::PlaySound
02d27c40: ldr     x0, [x21]                                  S:'didu'
02d27c44: bl      #0x3769600                                 fn_3769600
02d27c48: cbz     x0, #0x2d27c78                             
02d27c4c: mov     w1, #4                                     
02d27c50: mov     x2, xzr                                    
02d27c54: bl      #0x2cc6ee0                                 Framework.VibrationManager::Haptic
02d27c58: cbz     x19, #0x2d27c78                            
02d27c5c: mov     x0, x19                                    
02d27c60: bl      #0x2d27014                                 Decor.CategoryItem::StartClickEffect
02d27c64: mov     x0, x20                                    
02d27c68: mov     x1, x19                                    
02d27c6c: ldp     x20, x19, [sp, #0x10]                      
02d27c70: ldp     x30, x21, [sp], #0x20                      
02d27c74: b       #0x2d27414                                 Decor.CategoryPanel::SelectedCategory
02d27c78: bl      #0x2b7105c                                 fn_2b7105c
## .ctor() -> void
---- Decor.CategoryPanel::.ctor 0x2d27c7c
02d27c7c: str     x30, [sp, #-0x30]!                         
02d27c80: stp     x22, x21, [sp, #0x10]                      
02d27c84: stp     x20, x19, [sp, #0x20]                      
02d27c88: adrp    x21, #0x6630000                            
02d27c8c: adrp    x22, #0x626a000                            
02d27c90: adrp    x20, #0x626a000                            
02d27c94: ldrb    w8, [x21, #0x91]                           
02d27c98: ldr     x22, [x22, #0x1c0]                         T:type56653(k15)
02d27c9c: ldr     x20, [x20, #0x1c8]                         MS:System.Collections.Generic.List`1::.ctor
02d27ca0: mov     x19, x0                                    
02d27ca4: tbnz    w8, #0, #0x2d27cc8                         
02d27ca8: adrp    x0, #0x626a000                             
02d27cac: ldr     x0, [x0, #0x1c8]                           MS:System.Collections.Generic.List`1::.ctor
02d27cb0: bl      #0x2b70db0                                 fn_2b70db0
02d27cb4: adrp    x0, #0x626a000                             
02d27cb8: ldr     x0, [x0, #0x1c0]                           T:type56653(k15)
02d27cbc: bl      #0x2b70db0                                 fn_2b70db0
02d27cc0: mov     w8, #1                                     
02d27cc4: strb    w8, [x21, #0x91]                           
02d27cc8: ldr     x0, [x22]                                  T:type56879(k15)
02d27ccc: bl      #0x2b7104c                                 fn_2b7104c
02d27cd0: ldr     x1, [x20]                                  T:type56879(k15)
02d27cd4: mov     x20, x0                                    
02d27cd8: bl      #0x35a89a4                                 fn_35a89a4
02d27cdc: mov     x0, x19                                    
02d27ce0: mov     x1, x20                                    
02d27ce4: str     x20, [x0, #0x28]!                          ._categoryItems
02d27ce8: bl      #0x2b70d54                                 fn_2b70d54
02d27cec: mov     x0, x19                                    
02d27cf0: ldp     x20, x19, [sp, #0x20]                      
02d27cf4: ldp     x22, x21, [sp, #0x10]                      
02d27cf8: mov     x1, xzr                                    
02d27cfc: ldr     x30, [sp], #0x30                           
02d27d00: b       #0x5b397b0                                 UnityEngine.MonoBehaviour::.ctor
