#### CLASS DailyMission.NormalDayItem parent= DailyMission.DailyItemBase
#   field _coinText                      TMPro.TextMeshProUGUI                              off=0x68 attr=1 SerializeField
#   field _iconGoldImage                 UnityEngine.UI.Image                               off=0x70 attr=1 SerializeField
#   field _iconItemImage                 UnityEngine.UI.Image                               off=0x78 attr=1 SerializeField
#   field _goCheckBox                    UnityEngine.GameObject                             off=0x80 attr=1 SerializeField
## SetUpData() -> void
---- DailyMission.NormalDayItem::SetUpData 0x2d77104
02d77104: sub     sp, sp, #0x30                              
02d77108: stp     x30, x21, [sp, #0x10]                      
02d7710c: stp     x20, x19, [sp, #0x20]                      
02d77110: adrp    x20, #0x6630000                            
02d77114: mov     x19, x0                                    
02d77118: ldrb    w8, [x20, #0x3dc]                          
02d7711c: tbnz    w8, #0, #0x2d77134                         
02d77120: adrp    x0, #0x6264000                             
02d77124: ldr     x0, [x0, #0xd90]                           S:'{0}'
02d77128: bl      #0x2b70db0                                 fn_2b70db0
02d7712c: mov     w8, #1                                     
02d77130: strb    w8, [x20, #0x3dc]                          
02d77134: ldr     x8, [x19, #0x60]                           
02d77138: cbz     x8, #0x2d77274                             
02d7713c: ldr     x0, [x19, #0x70]                           ._iconGoldImage
02d77140: cbz     x0, #0x2d77274                             
02d77144: ldr     x1, [x8, #0x10]                            
02d77148: mov     x2, xzr                                    
02d7714c: bl      #0x5c45aa0                                 UnityEngine.UI.Image::set_sprite
02d77150: ldr     x8, [x19, #0x60]                           
02d77154: cbz     x8, #0x2d77274                             
02d77158: ldr     x0, [x19, #0x78]                           ._iconItemImage
02d7715c: cbz     x0, #0x2d77274                             
02d77160: ldr     x1, [x8, #0x10]                            
02d77164: mov     x2, xzr                                    
02d77168: bl      #0x5c45aa0                                 UnityEngine.UI.Image::set_sprite
02d7716c: ldr     x8, [x19, #0x60]                           
02d77170: cbz     x8, #0x2d77274                             
02d77174: adrp    x9, #0x6263000                             
02d77178: adrp    x21, #0x6264000                            
02d7717c: add     x1, sp, #0xc                               
02d77180: ldr     x9, [x9, #0x970]                           &6645c70(=0)
02d77184: ldr     x21, [x21, #0xd90]                         S:'{0}'
02d77188: ldr     w8, [x8, #0x1c]                            
02d7718c: ldr     x20, [x19, #0x68]                          ._coinText
02d77190: ldr     x0, [x9, #0x48]                            &6263098(=0)
02d77194: str     w8, [sp, #0xc]                             
02d77198: bl      #0x2b70f38                                 fn_2b70f38
02d7719c: ldr     x8, [x21]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d771a0: mov     x1, x0                                     
02d771a4: mov     x2, xzr                                    
02d771a8: mov     x0, x8                                     
02d771ac: bl      #0x4c9d0ec                                 System.String::Format
02d771b0: cbz     x20, #0x2d77274                            
02d771b4: ldr     x8, [x20]                                  
02d771b8: mov     x1, x0                                     
02d771bc: mov     x0, x20                                    
02d771c0: ldr     x9, [x8, #0x558]                           
02d771c4: ldr     x2, [x8, #0x560]                           
02d771c8: blr     x9                                         
02d771cc: ldr     x0, [x19, #0x50]                           
02d771d0: cbz     x0, #0x2d77274                             
02d771d4: ldr     w1, [x19, #0x48]                           
02d771d8: bl      #0x2d76398                                 DailyMission.DailyConfig::GetConfig
02d771dc: cbz     x0, #0x2d77274                             
02d771e0: ldr     x8, [x19, #0x70]                           ._iconGoldImage
02d771e4: cbz     x8, #0x2d77274                             
02d771e8: ldrb    w20, [x0, #0x18]                           
02d771ec: mov     x0, x8                                     
02d771f0: mov     x1, xzr                                    
02d771f4: bl      #0x5b339ec                                 UnityEngine.Component::get_gameObject
02d771f8: cbz     x0, #0x2d77274                             
02d771fc: cmp     w20, #0                                    
02d77200: mov     x2, xzr                                    
02d77204: cset    w1, ne                                     
02d77208: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d7720c: ldr     x0, [x19, #0x78]                           ._iconItemImage
02d77210: cbz     x0, #0x2d77274                             
02d77214: mov     x1, xzr                                    
02d77218: bl      #0x5b339ec                                 UnityEngine.Component::get_gameObject
02d7721c: cbz     x0, #0x2d77274                             
02d77220: cmp     w20, #0                                    
02d77224: mov     x2, xzr                                    
02d77228: cset    w1, eq                                     
02d7722c: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d77230: ldr     x0, [x19, #0x68]                           ._coinText
02d77234: cbz     x0, #0x2d77274                             
02d77238: mov     x1, xzr                                    
02d7723c: bl      #0x5b339ec                                 UnityEngine.Component::get_gameObject
02d77240: cbz     x0, #0x2d77274                             
02d77244: mov     w1, #1                                     
02d77248: mov     x2, xzr                                    
02d7724c: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d77250: ldr     x0, [x19, #0x80]                           ._goCheckBox
02d77254: cbz     x0, #0x2d77274                             
02d77258: mov     w1, wzr                                    
02d7725c: mov     x2, xzr                                    
02d77260: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d77264: ldp     x20, x19, [sp, #0x20]                      
02d77268: ldp     x30, x21, [sp, #0x10]                      
02d7726c: add     sp, sp, #0x30                              
02d77270: ret                                                
02d77274: bl      #0x2b7105c                                 fn_2b7105c
## OnRefresh() -> void
---- DailyMission.NormalDayItem::OnRefresh 0x2d77278
02d77278: stp     x30, x19, [sp, #-0x10]!                    
02d7727c: mov     x19, x0                                    
02d77280: bl      #0x2d76530                                 DailyMission.DailyItemBase::OnRefresh
02d77284: mov     x0, x19                                    
02d77288: bl      #0x2d7675c                                 DailyMission.DailyItemBase::GetStatus
02d7728c: mov     w1, w0                                     
02d77290: mov     x0, x19                                    
02d77294: ldp     x30, x19, [sp], #0x10                      
02d77298: b       #0x2d7729c                                 DailyMission.NormalDayItem::EnableIcon
## EnableIcon(DailyMission.DailyItemStatus status) -> void
---- DailyMission.NormalDayItem::EnableIcon 0x2d7729c
02d7729c: str     x30, [sp, #-0x20]!                         
02d772a0: stp     x20, x19, [sp, #0x10]                      
02d772a4: cmp     w1, #1                                     
02d772a8: mov     x19, x0                                    
02d772ac: b.ne    #0x2d772cc                                 
02d772b0: ldr     x0, [x19, #0x80]                           ._goCheckBox
02d772b4: cbz     x0, #0x2d7735c                             
02d772b8: mov     x1, xzr                                    
02d772bc: bl      #0x5b37654                                 UnityEngine.GameObject::get_gameObject
02d772c0: cbz     x0, #0x2d7735c                             
02d772c4: mov     w1, #1                                     
02d772c8: b       #0x2d7734c                                 
02d772cc: ldr     x0, [x19, #0x50]                           
02d772d0: cbz     x0, #0x2d7735c                             
02d772d4: ldr     w1, [x19, #0x48]                           
02d772d8: bl      #0x2d76398                                 DailyMission.DailyConfig::GetConfig
02d772dc: cbz     x0, #0x2d7735c                             
02d772e0: ldr     x8, [x19, #0x70]                           ._iconGoldImage
02d772e4: cbz     x8, #0x2d7735c                             
02d772e8: ldrb    w20, [x0, #0x18]                           
02d772ec: mov     x0, x8                                     
02d772f0: mov     x1, xzr                                    
02d772f4: bl      #0x5b339ec                                 UnityEngine.Component::get_gameObject
02d772f8: cbz     x0, #0x2d7735c                             
02d772fc: cmp     w20, #0                                    
02d77300: mov     x2, xzr                                    
02d77304: cset    w1, ne                                     
02d77308: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d7730c: ldr     x0, [x19, #0x78]                           ._iconItemImage
02d77310: cbz     x0, #0x2d7735c                             
02d77314: mov     x1, xzr                                    
02d77318: bl      #0x5b339ec                                 UnityEngine.Component::get_gameObject
02d7731c: cbz     x0, #0x2d7735c                             
02d77320: cmp     w20, #0                                    
02d77324: mov     x2, xzr                                    
02d77328: cset    w1, eq                                     
02d7732c: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d77330: ldr     x0, [x19, #0x68]                           ._coinText
02d77334: cbz     x0, #0x2d7735c                             
02d77338: mov     x1, xzr                                    
02d7733c: bl      #0x5b339ec                                 UnityEngine.Component::get_gameObject
02d77340: cbz     x0, #0x2d7735c                             
02d77344: cmp     w20, #0                                    
02d77348: cset    w1, ne                                     
02d7734c: ldp     x20, x19, [sp, #0x10]                      
02d77350: mov     x2, xzr                                    
02d77354: ldr     x30, [sp], #0x20                           
02d77358: b       #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d7735c: bl      #0x2b7105c                                 fn_2b7105c
## .ctor() -> void
---- DailyMission.NormalDayItem::.ctor 0x2d77360
02d77360: mov     x1, xzr                                    
02d77364: b       #0x5b397b0                                 UnityEngine.MonoBehaviour::.ctor
