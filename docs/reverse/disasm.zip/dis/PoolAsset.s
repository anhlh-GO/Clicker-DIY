#### CLASS PoolAsset/<>c__DisplayClass1_0 parent= object
#   field poolType                       PoolType                                           off=0x10 attr=6 
## .ctor() -> void
---- PoolAsset/<>c__DisplayClass1_0::.ctor 0x2cdc7c8
02cdc7c8: mov     x1, xzr                                    
02cdc7cc: b       #0x4e53e9c                                 System.Object::.ctor
## <GetPoolElement>b__0(PoolData x) -> bool
---- PoolAsset/<>c__DisplayClass1_0::<GetPoolElement>b__0 0x2cdc858
02cdc858: cbz     x1, #0x2cdc870                             
02cdc85c: ldr     w8, [x1, #0x10]                            
02cdc860: ldr     w9, [x0, #0x10]                            .poolType
02cdc864: cmp     w8, w9                                     
02cdc868: cset    w0, eq                                     
02cdc86c: ret                                                
02cdc870: str     x30, [sp, #-0x10]!                         
02cdc874: bl      #0x2b7105c                                 fn_2b7105c
#### CLASS PoolAsset parent= UnityEngine.ScriptableObject
#   field poolDataList                   System.Collections.Generic.List`1<PoolData>        off=0x18 attr=6 
## GetPoolElement(PoolType poolType) -> UnityEngine.Transform
---- PoolAsset::GetPoolElement 0x2cdc5dc
02cdc5dc: str     x30, [sp, #-0x30]!                         
02cdc5e0: stp     x22, x21, [sp, #0x10]                      
02cdc5e4: stp     x20, x19, [sp, #0x20]                      
02cdc5e8: adrp    x19, #0x662f000                            
02cdc5ec: adrp    x22, #0x6267000                            
02cdc5f0: mov     w20, w1                                    
02cdc5f4: ldrb    w8, [x19, #0xd72]                          
02cdc5f8: ldr     x22, [x22, #0xcc0]                         T:PoolAsset/<>c__DisplayClass1_0
02cdc5fc: mov     x21, x0                                    
02cdc600: tbnz    w8, #0, #0x2cdc63c                         
02cdc604: adrp    x0, #0x6267000                             
02cdc608: ldr     x0, [x0, #0xcc8]                           MS:System.Collections.Generic.List`1::Find
02cdc60c: bl      #0x2b70db0                                 fn_2b70db0
02cdc610: adrp    x0, #0x6267000                             
02cdc614: ldr     x0, [x0, #0xcd0]                           T:type57271(k15)
02cdc618: bl      #0x2b70db0                                 fn_2b70db0
02cdc61c: adrp    x0, #0x6267000                             
02cdc620: ldr     x0, [x0, #0xcd8]                           M:PoolAsset/<>c__DisplayClass1_0::<GetPoolElement>b__0
02cdc624: bl      #0x2b70db0                                 fn_2b70db0
02cdc628: adrp    x0, #0x6267000                             
02cdc62c: ldr     x0, [x0, #0xcc0]                           T:PoolAsset/<>c__DisplayClass1_0
02cdc630: bl      #0x2b70db0                                 fn_2b70db0
02cdc634: mov     w8, #1                                     
02cdc638: strb    w8, [x19, #0xd72]                          
02cdc63c: ldr     x0, [x22]                                  S:'didu'
02cdc640: bl      #0x2b7104c                                 fn_2b7104c
02cdc644: mov     x1, xzr                                    
02cdc648: mov     x19, x0                                    
02cdc64c: bl      #0x4e53e9c                                 System.Object::.ctor
02cdc650: cbz     x19, #0x2cdc790                            
02cdc654: adrp    x8, #0x6267000                             
02cdc658: ldr     x8, [x8, #0xcd0]                           T:type57271(k15)
02cdc65c: ldr     x21, [x21, #0x18]                          .poolDataList
02cdc660: str     w20, [x19, #0x10]                          
02cdc664: ldr     x0, [x8]                                   S:'didu'
02cdc668: bl      #0x2b7104c                                 fn_2b7104c
02cdc66c: adrp    x8, #0x6267000                             
02cdc670: mov     x20, x0                                    
02cdc674: ldr     x8, [x8, #0xcd8]                           M:PoolAsset/<>c__DisplayClass1_0::<GetPoolElement>b__0
02cdc678: ldr     x2, [x8]                                   S:'didu'
02cdc67c: mov     x1, x19                                    
02cdc680: mov     x3, xzr                                    
02cdc684: bl      #0x399ba10                                 fn_399ba10
02cdc688: cbz     x21, #0x2cdc6bc                            
02cdc68c: adrp    x8, #0x6267000                             
02cdc690: ldr     x8, [x8, #0xcc8]                           MS:System.Collections.Generic.List`1::Find
02cdc694: ldr     x2, [x8]                                   S:'didu'
02cdc698: mov     x0, x21                                    
02cdc69c: mov     x1, x20                                    
02cdc6a0: bl      #0x35a9868                                 fn_35a9868
02cdc6a4: cbz     x0, #0x2cdc6c0                             
02cdc6a8: ldr     x0, [x0, #0x18]                            S:'android.content.Intent' .poolDataList
02cdc6ac: ldp     x20, x19, [sp, #0x20]                      
02cdc6b0: ldp     x22, x21, [sp, #0x10]                      
02cdc6b4: ldr     x30, [sp], #0x30                           
02cdc6b8: ret                                                
02cdc6bc: bl      #0x2b7105c                                 fn_2b7105c
02cdc6c0: bl      #0x2b7105c                                 fn_2b7105c
02cdc6c4: b       #0x2cdc6c8                                 
02cdc6c8: mov     x20, x0                                    
02cdc6cc: cmp     w1, #1                                     
02cdc6d0: b.ne    #0x2cdc7bc                                 
02cdc6d4: mov     x0, x20                                    
02cdc6d8: bl      #0x5e90260                                 fn_5e90260
02cdc6dc: mov     x20, x0                                    
02cdc6e0: adrp    x0, #0x6263000                             
02cdc6e4: ldr     x0, [x0, #0xae0]                           T:System.Exception
02cdc6e8: bl      #0x2b70dc4                                 fn_2b70dc4
02cdc6ec: ldr     x8, [x20]                                  
02cdc6f0: ldr     x1, [x8]                                   S:'didu'
02cdc6f4: bl      #0x2b71464                                 fn_2b71464
02cdc6f8: tbz     w0, #0, #0x2cdc794                         
02cdc6fc: bl      #0x5e90270                                 fn_5e90270
02cdc700: adrp    x0, #0x6263000                             
02cdc704: ldr     x0, [x0, #0xa80]                           T:type24502(k1d)
02cdc708: bl      #0x2b70dc4                                 fn_2b70dc4
02cdc70c: mov     w1, #1                                     
02cdc710: bl      #0x2b70ea0                                 fn_2b70ea0
02cdc714: ldr     w8, [x19, #0x10]                           &2b706e8(=14cc74f191004000)
02cdc718: mov     x20, x0                                    
02cdc71c: adrp    x0, #0x6267000                             
02cdc720: str     w8, [sp, #0xc]                             
02cdc724: ldr     x0, [x0, #0xce0]                           T:PoolType
02cdc728: bl      #0x2b70dc4                                 fn_2b70dc4
02cdc72c: add     x1, sp, #0xc                               
02cdc730: bl      #0x2b70f38                                 fn_2b70f38
02cdc734: cbz     x20, #0x2cdc790                            
02cdc738: mov     x19, x0                                    
02cdc73c: mov     x0, x20                                    
02cdc740: mov     x1, x19                                    
02cdc744: bl      #0x2736dcc                                 fn_2736dcc
02cdc748: mov     x0, x20                                    
02cdc74c: mov     x1, xzr                                    
02cdc750: mov     x2, x19                                    
02cdc754: bl      #0x2736bf8                                 fn_2736bf8
02cdc758: adrp    x0, #0x6263000                             
02cdc75c: ldr     x0, [x0, #0x928]                           T:UnityEngine.Debug
02cdc760: bl      #0x2b70dc4                                 fn_2b70dc4
02cdc764: ldr     w8, [x0, #0xe4]                            [62630e4]=0 f=0,0
02cdc768: cbnz    w8, #0x2cdc770                             
02cdc76c: bl      #0x2b70f30                                 fn_2b70f30
02cdc770: adrp    x0, #0x6267000                             
02cdc774: ldr     x0, [x0, #0xce8]                           S:'Missing Prefab of {0}!!!'
02cdc778: bl      #0x2b70dc4                                 fn_2b70dc4
02cdc77c: mov     x1, x20                                    
02cdc780: mov     x2, xzr                                    
02cdc784: bl      #0x5af2a60                                 UnityEngine.Debug::LogErrorFormat
02cdc788: mov     x0, xzr                                    
02cdc78c: b       #0x2cdc6ac                                 
02cdc790: bl      #0x2b7105c                                 fn_2b7105c
02cdc794: mov     w0, #8                                     
02cdc798: bl      #0x5e90290                                 fn_5e90290
02cdc79c: ldr     x8, [x20]                                  
02cdc7a0: str     x8, [x0]                                   
02cdc7a4: adrp    x1, #0x5e96000                             
02cdc7a8: add     x1, x1, #0x758                             &5e96758
02cdc7ac: mov     x2, xzr                                    
02cdc7b0: bl      #0x5e902a0                                 fn_5e902a0
02cdc7b4: mov     x20, x0                                    
02cdc7b8: bl      #0x5e90270                                 fn_5e90270
02cdc7bc: mov     x0, x20                                    
02cdc7c0: bl      #0x2c6051c                                 fn_2c6051c
02cdc7c4: bl      #0x27369b8                                 fn_27369b8
## .ctor() -> void
---- PoolAsset::.ctor 0x2cdc7d0
02cdc7d0: str     x30, [sp, #-0x30]!                         
02cdc7d4: stp     x22, x21, [sp, #0x10]                      
02cdc7d8: stp     x20, x19, [sp, #0x20]                      
02cdc7dc: adrp    x21, #0x662f000                            
02cdc7e0: adrp    x22, #0x6267000                            
02cdc7e4: adrp    x20, #0x6267000                            
02cdc7e8: ldrb    w8, [x21, #0xd73]                          
02cdc7ec: ldr     x22, [x22, #0xcf0]                         T:type56780(k15)
02cdc7f0: ldr     x20, [x20, #0xcf8]                         MS:System.Collections.Generic.List`1::.ctor
02cdc7f4: mov     x19, x0                                    
02cdc7f8: tbnz    w8, #0, #0x2cdc81c                         
02cdc7fc: adrp    x0, #0x6267000                             
02cdc800: ldr     x0, [x0, #0xcf8]                           MS:System.Collections.Generic.List`1::.ctor
02cdc804: bl      #0x2b70db0                                 fn_2b70db0
02cdc808: adrp    x0, #0x6267000                             
02cdc80c: ldr     x0, [x0, #0xcf0]                           T:type56780(k15)
02cdc810: bl      #0x2b70db0                                 fn_2b70db0
02cdc814: mov     w8, #1                                     
02cdc818: strb    w8, [x21, #0xd73]                          
02cdc81c: ldr     x0, [x22]                                  S:'didu'
02cdc820: bl      #0x2b7104c                                 fn_2b7104c
02cdc824: ldr     x1, [x20]                                  S:'didu'
02cdc828: mov     x20, x0                                    
02cdc82c: bl      #0x35a89a4                                 fn_35a89a4
02cdc830: mov     x0, x19                                    
02cdc834: mov     x1, x20                                    
02cdc838: str     x20, [x0, #0x18]!                          .poolDataList
02cdc83c: bl      #0x2b70d54                                 fn_2b70d54
02cdc840: mov     x0, x19                                    
02cdc844: ldp     x20, x19, [sp, #0x20]                      
02cdc848: ldp     x22, x21, [sp, #0x10]                      
02cdc84c: mov     x1, xzr                                    
02cdc850: ldr     x30, [sp], #0x30                           
02cdc854: b       #0x5b398f0                                 UnityEngine.ScriptableObject::.ctor
