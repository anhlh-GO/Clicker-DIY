#### CLASS Framework.ScrollRectExtension parent= object
## CalculateFocusedScrollPosition(UnityEngine.UI.ScrollRect scrollView, UnityEngine.Vector2 focusPoint) -> UnityEngine.Vector2
---- Framework.ScrollRectExtension::CalculateFocusedScrollPosition 0x2cb9c00
02cb9c00: stp     d15, d14, [sp, #-0x60]!                    
02cb9c04: stp     d13, d12, [sp, #0x10]                      
02cb9c08: stp     d11, d10, [sp, #0x20]                      
02cb9c0c: stp     d9, d8, [sp, #0x30]                        
02cb9c10: str     x30, [sp, #0x40]                           
02cb9c14: stp     x20, x19, [sp, #0x50]                      
02cb9c18: fmov    s8, s1                                     
02cb9c1c: fmov    s9, s0                                     
02cb9c20: adrp    x20, #0x662f000                            
02cb9c24: ldrb    w8, [x20, #0xbea]                          
02cb9c28: mov     x19, x0                                    
02cb9c2c: tbnz    w8, #0, #0x2cb9c50                         
02cb9c30: adrp    x0, #0x6264000                             
02cb9c34: ldr     x0, [x0, #0x8f8]                           T:UnityEngine.RectTransform
02cb9c38: bl      #0x2b70db0                                 fn_2b70db0
02cb9c3c: adrp    x0, #0x6264000                             
02cb9c40: ldr     x0, [x0, #0x798]                           T:UnityEngine.Rect
02cb9c44: bl      #0x2b70db0                                 fn_2b70db0
02cb9c48: mov     w8, #1                                     
02cb9c4c: strb    w8, [x20, #0xbea]                          
02cb9c50: cbz     x19, #0x2cb9d88                            
02cb9c54: ldr     x0, [x19, #0x20]                           
02cb9c58: cbz     x0, #0x2cb9d88                             
02cb9c5c: adrp    x20, #0x6264000                            
02cb9c60: mov     x1, xzr                                    
02cb9c64: ldr     x20, [x20, #0x798]                         T:UnityEngine.Rect
02cb9c68: bl      #0x5b45334                                 UnityEngine.RectTransform::get_rect
02cb9c6c: fmov    s11, s2                                    
02cb9c70: ldr     x0, [x20]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02cb9c74: fmov    s10, s3                                    
02cb9c78: ldr     w8, [x0, #0xe4]                            [62640e4]=0 f=0,0
02cb9c7c: cbnz    w8, #0x2cb9c84                             
02cb9c80: bl      #0x2b70f30                                 fn_2b70f30
02cb9c84: ldr     x0, [x19, #0x20]                           
02cb9c88: cbz     x0, #0x2cb9d88                             
02cb9c8c: mov     x1, xzr                                    
02cb9c90: bl      #0x5b466dc                                 UnityEngine.Transform::get_parent
02cb9c94: cbz     x0, #0x2cb9d88                             
02cb9c98: adrp    x8, #0x6264000                             
02cb9c9c: ldr     x8, [x8, #0x8f8]                           T:UnityEngine.RectTransform
02cb9ca0: ldr     x1, [x8]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02cb9ca4: ldr     x8, [x0]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02cb9ca8: cmp     x8, x1                                     
02cb9cac: b.ne    #0x2cb9d8c                                 
02cb9cb0: mov     x1, xzr                                    
02cb9cb4: bl      #0x5b45334                                 UnityEngine.RectTransform::get_rect
02cb9cb8: ldr     x0, [x19, #0x20]                           
02cb9cbc: cbz     x0, #0x2cb9d88                             
02cb9cc0: mov     x1, xzr                                    
02cb9cc4: fmov    s14, s2                                    
02cb9cc8: fmov    s12, s3                                    
02cb9ccc: bl      #0x5b46ff0                                 UnityEngine.Transform::get_localScale
02cb9cd0: mov     x0, x19                                    
02cb9cd4: mov     x1, xzr                                    
02cb9cd8: fmov    s15, s0                                    
02cb9cdc: fmov    s13, s1                                    
02cb9ce0: bl      #0x5e647a4                                 UnityEngine.UI.ScrollRect::get_normalizedPosition
02cb9ce4: ldrb    w8, [x19, #0x28]                           
02cb9ce8: cbz     w8, #0x2cb9d28                             
02cb9cec: fmul    s2, s11, s15                               
02cb9cf0: fcmp    s2, s14                                    
02cb9cf4: b.le    #0x2cb9d28                                 
02cb9cf8: fmov    s0, #-0.50000000                           
02cb9cfc: fmul    s3, s9, s15                                
02cb9d00: fsub    s2, s2, s14                                
02cb9d04: fmul    s0, s14, s0                                
02cb9d08: fadd    s0, s3, s0                                 
02cb9d0c: movi    d3, #0000000000000000                      
02cb9d10: fdiv    s0, s0, s2                                 
02cb9d14: fmov    s2, #1.00000000                            
02cb9d18: fcmp    s0, s2                                     
02cb9d1c: fcsel   s2, s2, s0, gt                             
02cb9d20: fcmp    s0, #0.0                                   
02cb9d24: fcsel   s0, s3, s2, mi                             
02cb9d28: ldrb    w8, [x19, #0x29]                           
02cb9d2c: cbz     w8, #0x2cb9d6c                             
02cb9d30: fmul    s2, s10, s13                               
02cb9d34: fcmp    s2, s12                                    
02cb9d38: b.le    #0x2cb9d6c                                 
02cb9d3c: fmov    s1, #-0.50000000                           
02cb9d40: fmul    s3, s8, s13                                
02cb9d44: fsub    s2, s2, s12                                
02cb9d48: fmul    s1, s12, s1                                
02cb9d4c: fadd    s1, s3, s1                                 
02cb9d50: movi    d3, #0000000000000000                      
02cb9d54: fdiv    s1, s1, s2                                 
02cb9d58: fmov    s2, #1.00000000                            
02cb9d5c: fcmp    s1, s2                                     
02cb9d60: fcsel   s2, s2, s1, gt                             
02cb9d64: fcmp    s1, #0.0                                   
02cb9d68: fcsel   s1, s3, s2, mi                             
02cb9d6c: ldp     x20, x19, [sp, #0x50]                      
02cb9d70: ldr     x30, [sp, #0x40]                           
02cb9d74: ldp     d9, d8, [sp, #0x30]                        
02cb9d78: ldp     d11, d10, [sp, #0x20]                      
02cb9d7c: ldp     d13, d12, [sp, #0x10]                      
02cb9d80: ldp     d15, d14, [sp], #0x60                      
02cb9d84: ret                                                
02cb9d88: bl      #0x2b7105c                                 fn_2b7105c
02cb9d8c: bl      #0x2b713dc                                 fn_2b713dc
## CalculateFocusedScrollPosition(UnityEngine.UI.ScrollRect scrollView, UnityEngine.RectTransform item) -> UnityEngine.Vector2
---- Framework.ScrollRectExtension::CalculateFocusedScrollPosition 0x2cb9d90
02cb9d90: stp     d11, d10, [sp, #-0x50]!                    
02cb9d94: stp     d9, d8, [sp, #0x10]                        
02cb9d98: stp     x30, x23, [sp, #0x20]                      
02cb9d9c: stp     x22, x21, [sp, #0x30]                      
02cb9da0: stp     x20, x19, [sp, #0x40]                      
02cb9da4: adrp    x20, #0x662f000                            
02cb9da8: mov     x22, x1                                    
02cb9dac: mov     x19, x0                                    
02cb9db0: ldrb    w8, [x20, #0xbeb]                          
02cb9db4: tbnz    w8, #0, #0x2cb9dcc                         
02cb9db8: adrp    x0, #0x6264000                             
02cb9dbc: ldr     x0, [x0, #0x798]                           T:UnityEngine.Rect
02cb9dc0: bl      #0x2b70db0                                 fn_2b70db0
02cb9dc4: mov     w8, #1                                     
02cb9dc8: strb    w8, [x20, #0xbeb]                          
02cb9dcc: cbz     x19, #0x2cb9eb0                            
02cb9dd0: cbz     x22, #0x2cb9eb0                            
02cb9dd4: adrp    x23, #0x6264000                            
02cb9dd8: mov     x0, x22                                    
02cb9ddc: mov     x1, xzr                                    
02cb9de0: ldr     x23, [x23, #0x798]                         T:UnityEngine.Rect
02cb9de4: ldr     x20, [x19, #0x20]                          
02cb9de8: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02cb9dec: mov     x21, x0                                    
02cb9df0: mov     x0, x22                                    
02cb9df4: mov     x1, xzr                                    
02cb9df8: bl      #0x5b45334                                 UnityEngine.RectTransform::get_rect
02cb9dfc: fmov    s8, s0                                     
02cb9e00: fmov    s9, s1                                     
02cb9e04: ldr     x0, [x23]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02cb9e08: fmov    s10, s2                                    
02cb9e0c: fmov    s11, s3                                    
02cb9e10: ldr     w8, [x0, #0xe4]                            [62640e4]=0 f=0,0
02cb9e14: cbnz    w8, #0x2cb9e1c                             
02cb9e18: bl      #0x2b70f30                                 fn_2b70f30
02cb9e1c: cbz     x21, #0x2cb9eb0                            
02cb9e20: fmov    s0, #0.50000000                            
02cb9e24: movi    d2, #0000000000000000                      
02cb9e28: mov     x0, x21                                    
02cb9e2c: mov     x1, xzr                                    
02cb9e30: fmul    s1, s11, s0                                
02cb9e34: fmul    s0, s10, s0                                
02cb9e38: fadd    s1, s9, s1                                 
02cb9e3c: fadd    s0, s8, s0                                 
02cb9e40: bl      #0x5b48000                                 UnityEngine.Transform::TransformPoint
02cb9e44: cbz     x20, #0x2cb9eb0                            
02cb9e48: mov     x0, x20                                    
02cb9e4c: mov     x1, xzr                                    
02cb9e50: bl      #0x5b480f8                                 UnityEngine.Transform::InverseTransformPoint
02cb9e54: ldr     x0, [x19, #0x20]                           
02cb9e58: cbz     x0, #0x2cb9eb0                             
02cb9e5c: mov     x1, xzr                                    
02cb9e60: fmov    s8, s0                                     
02cb9e64: fmov    s9, s1                                     
02cb9e68: bl      #0x5b45334                                 UnityEngine.RectTransform::get_rect
02cb9e6c: ldr     x0, [x19, #0x20]                           
02cb9e70: cbz     x0, #0x2cb9eb0                             
02cb9e74: mov     x1, xzr                                    
02cb9e78: fmov    s10, s2                                    
02cb9e7c: fmov    s11, s3                                    
02cb9e80: bl      #0x5b45a5c                                 UnityEngine.RectTransform::get_pivot
02cb9e84: fmul    s0, s10, s0                                
02cb9e88: fmul    s1, s11, s1                                
02cb9e8c: mov     x0, x19                                    
02cb9e90: ldp     x20, x19, [sp, #0x40]                      
02cb9e94: ldp     x22, x21, [sp, #0x30]                      
02cb9e98: ldp     x30, x23, [sp, #0x20]                      
02cb9e9c: fadd    s0, s8, s0                                 
02cb9ea0: fadd    s1, s9, s1                                 
02cb9ea4: ldp     d9, d8, [sp, #0x10]                        
02cb9ea8: ldp     d11, d10, [sp], #0x50                      
02cb9eac: b       #0x2cb9c00                                 Framework.ScrollRectExtension::CalculateFocusedScrollPosition
02cb9eb0: bl      #0x2b7105c                                 fn_2b7105c
## FocusAtPoint(UnityEngine.UI.ScrollRect scrollView, UnityEngine.Vector2 focusPoint) -> void
---- Framework.ScrollRectExtension::FocusAtPoint 0x2cb9eb4
02cb9eb4: stp     x30, x19, [sp, #-0x10]!                    
02cb9eb8: mov     x19, x0                                    
02cb9ebc: bl      #0x2cb9c00                                 Framework.ScrollRectExtension::CalculateFocusedScrollPosition
02cb9ec0: cbz     x19, #0x2cb9ed4                            
02cb9ec4: mov     x0, x19                                    
02cb9ec8: mov     x1, xzr                                    
02cb9ecc: ldp     x30, x19, [sp], #0x10                      
02cb9ed0: b       #0x5e64a04                                 UnityEngine.UI.ScrollRect::set_normalizedPosition
02cb9ed4: bl      #0x2b7105c                                 fn_2b7105c
## FocusOnItem(UnityEngine.UI.ScrollRect scrollView, UnityEngine.RectTransform item) -> void
---- Framework.ScrollRectExtension::FocusOnItem 0x2cb9ed8
02cb9ed8: stp     x30, x19, [sp, #-0x10]!                    
02cb9edc: mov     x19, x0                                    
02cb9ee0: bl      #0x2cb9d90                                 Framework.ScrollRectExtension::CalculateFocusedScrollPosition
02cb9ee4: cbz     x19, #0x2cb9ef8                            
02cb9ee8: mov     x0, x19                                    
02cb9eec: mov     x1, xzr                                    
02cb9ef0: ldp     x30, x19, [sp], #0x10                      
02cb9ef4: b       #0x5e64a04                                 UnityEngine.UI.ScrollRect::set_normalizedPosition
02cb9ef8: bl      #0x2b7105c                                 fn_2b7105c
