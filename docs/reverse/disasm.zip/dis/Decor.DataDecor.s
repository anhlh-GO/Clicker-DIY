#### CLASS Decor.DataDecor/CategoryData parent= object
#   field ID                             int                                                off=0x10 attr=6 
#   field SelectedItemID                 int                                                off=0x14 attr=6 
#   field UnlockedItems                  System.Collections.Generic.List`1<int>             off=0x18 attr=6 
## .ctor() -> void
---- Decor.DataDecor/CategoryData::.ctor 0x2d259d0
02d259d0: mov     x1, xzr                                    
02d259d4: b       #0x4e53e9c                                 System.Object::.ctor
#### CLASS Decor.DataDecor/DataSaveDecor parent= object
#   field CategoryDataList               System.Collections.Generic.List`1<Decor.DataDecor/CategoryData> off=0x10 attr=6 
## .ctor() -> void
---- Decor.DataDecor/DataSaveDecor::.ctor 0x2d259c0
02d259c0: mov     x1, xzr                                    
02d259c4: b       #0x4e53e9c                                 System.Object::.ctor
#### CLASS Decor.DataDecor/<>c__DisplayClass7_0 parent= object
#   field i                              int                                                off=0x10 attr=6 
## .ctor() -> void
---- Decor.DataDecor/<>c__DisplayClass7_0::.ctor 0x2d255dc
02d255dc: mov     x1, xzr                                    
02d255e0: b       #0x4e53e9c                                 System.Object::.ctor
## <LoadData>b__0(Decor.DataDecor/CategoryData x) -> bool
---- Decor.DataDecor/<>c__DisplayClass7_0::<LoadData>b__0 0x2d25cb8
02d25cb8: cbz     x1, #0x2d25cd0                             
02d25cbc: ldr     w8, [x1, #0x10]                            
02d25cc0: ldr     w9, [x0, #0x10]                            .i
02d25cc4: cmp     w8, w9                                     
02d25cc8: cset    w0, eq                                     
02d25ccc: ret                                                
02d25cd0: str     x30, [sp, #-0x10]!                         
02d25cd4: bl      #0x2b7105c                                 fn_2b7105c
#### CLASS Decor.DataDecor/<>c__DisplayClass7_1 parent= object
#   field userUnlockData                 Decor.DataDecor/CategoryData                       off=0x10 attr=6 
## .ctor() -> void
---- Decor.DataDecor/<>c__DisplayClass7_1::.ctor 0x2d255e4
02d255e4: mov     x1, xzr                                    
02d255e8: b       #0x4e53e9c                                 System.Object::.ctor
## <LoadData>b__1(Decor.OptionData x) -> void
---- Decor.DataDecor/<>c__DisplayClass7_1::<LoadData>b__1 0x2d25cd8
02d25cd8: stp     x30, x21, [sp, #-0x20]!                    
02d25cdc: stp     x20, x19, [sp, #0x10]                      
02d25ce0: adrp    x21, #0x6630000                            
02d25ce4: mov     x19, x1                                    
02d25ce8: mov     x20, x0                                    
02d25cec: ldrb    w8, [x21, #0x77]                           
02d25cf0: tbnz    w8, #0, #0x2d25d14                         
02d25cf4: adrp    x0, #0x6266000                             
02d25cf8: ldr     x0, [x0, #0x818]                           MS:System.Collections.Generic.List`1::Add
02d25cfc: bl      #0x2b70db0                                 fn_2b70db0
02d25d00: adrp    x0, #0x6266000                             
02d25d04: ldr     x0, [x0, #0x820]                           MS:System.Collections.Generic.List`1::Contains
02d25d08: bl      #0x2b70db0                                 fn_2b70db0
02d25d0c: mov     w8, #1                                     
02d25d10: strb    w8, [x21, #0x77]                           
02d25d14: cbz     x19, #0x2d25dc0                            
02d25d18: ldr     w8, [x19, #0x20]                           
02d25d1c: cbnz    w8, #0x2d25d9c                             
02d25d20: ldr     x8, [x20, #0x10]                           .userUnlockData
02d25d24: cbz     x8, #0x2d25dc0                             
02d25d28: ldr     x0, [x8, #0x18]                            
02d25d2c: cbz     x0, #0x2d25dc0                             
02d25d30: adrp    x8, #0x6266000                             
02d25d34: ldr     x8, [x8, #0x820]                           MS:System.Collections.Generic.List`1::Contains
02d25d38: ldr     w1, [x19, #0x10]                           .userUnlockData
02d25d3c: ldr     x2, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d25d40: bl      #0x3569f98                                 fn_3569f98
02d25d44: tbnz    w0, #0, #0x2d25d9c                         
02d25d48: ldr     x8, [x20, #0x10]                           .userUnlockData
02d25d4c: cbz     x8, #0x2d25dc0                             
02d25d50: ldr     x0, [x8, #0x18]                            S:'level_show_popuprate'
02d25d54: cbz     x0, #0x2d25dc0                             
02d25d58: adrp    x9, #0x6266000                             
02d25d5c: ldr     x9, [x9, #0x818]                           MS:System.Collections.Generic.List`1::Add
02d25d60: ldr     w10, [x0, #0x1c]                           [626601c]=0 f=0,0
02d25d64: ldr     x8, [x0, #0x10]                            S:'mrec_ad_on_off' .userUnlockData
02d25d68: ldr     w1, [x19, #0x10]                           .userUnlockData
02d25d6c: ldr     x9, [x9]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d25d70: add     w10, w10, #1                               
02d25d74: str     w10, [x0, #0x1c]                           
02d25d78: cbz     x8, #0x2d25dc0                             
02d25d7c: ldrsw   x10, [x0, #0x18]                           
02d25d80: ldr     w11, [x8, #0x18]                           S:'level_show_popuprate'
02d25d84: cmp     w10, w11                                   
02d25d88: b.hs    #0x2d25da8                                 
02d25d8c: add     x8, x8, x10, lsl #2                        &6266000
02d25d90: add     w9, w10, #1                                
02d25d94: str     w9, [x0, #0x18]                            
02d25d98: str     w1, [x8, #0x20]                            
02d25d9c: ldp     x20, x19, [sp, #0x10]                      
02d25da0: ldp     x30, x21, [sp], #0x20                      
02d25da4: ret                                                
02d25da8: ldr     x8, [x9, #0x20]                            S:'inter_ad_capping_time'
02d25dac: ldp     x20, x19, [sp, #0x10]                      
02d25db0: ldr     x8, [x8, #0xc0]                            T:Firebase.RemoteConfig.ConfigValue
02d25db4: ldr     x2, [x8, #0x70]                            S:'open_ad_id'
02d25db8: ldp     x30, x21, [sp], #0x20                      
02d25dbc: b       #0x3569c18                                 
02d25dc0: bl      #0x2b7105c                                 fn_2b7105c
#### CLASS Decor.DataDecor/<>c__DisplayClass8_0 parent= object
#   field categoryData                   Decor.DataDecor/CategoryData                       off=0x10 attr=6 
## .ctor() -> void
---- Decor.DataDecor/<>c__DisplayClass8_0::.ctor 0x2d259c8
02d259c8: mov     x1, xzr                                    
02d259cc: b       #0x4e53e9c                                 System.Object::.ctor
## <NewData>b__0(Decor.OptionData x) -> void
---- Decor.DataDecor/<>c__DisplayClass8_0::<NewData>b__0 0x2d25dc4
02d25dc4: stp     x30, x21, [sp, #-0x20]!                    
02d25dc8: stp     x20, x19, [sp, #0x10]                      
02d25dcc: adrp    x21, #0x6630000                            
02d25dd0: mov     x19, x1                                    
02d25dd4: mov     x20, x0                                    
02d25dd8: ldrb    w8, [x21, #0x78]                           
02d25ddc: tbnz    w8, #0, #0x2d25df4                         
02d25de0: adrp    x0, #0x6266000                             
02d25de4: ldr     x0, [x0, #0x818]                           MS:System.Collections.Generic.List`1::Add
02d25de8: bl      #0x2b70db0                                 fn_2b70db0
02d25dec: mov     w8, #1                                     
02d25df0: strb    w8, [x21, #0x78]                           
02d25df4: cbz     x19, #0x2d25e78                            
02d25df8: ldr     w8, [x19, #0x20]                           
02d25dfc: cbnz    w8, #0x2d25e54                             
02d25e00: ldr     x8, [x20, #0x10]                           .categoryData
02d25e04: cbz     x8, #0x2d25e78                             
02d25e08: ldr     x0, [x8, #0x18]                            
02d25e0c: cbz     x0, #0x2d25e78                             
02d25e10: adrp    x9, #0x6266000                             
02d25e14: ldr     x9, [x9, #0x818]                           MS:System.Collections.Generic.List`1::Add
02d25e18: ldr     w10, [x0, #0x1c]                           [626601c]=0 f=0,0
02d25e1c: ldr     x8, [x0, #0x10]                            S:'mrec_ad_on_off' .categoryData
02d25e20: ldr     w1, [x19, #0x10]                           .categoryData
02d25e24: ldr     x9, [x9]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d25e28: add     w10, w10, #1                               
02d25e2c: str     w10, [x0, #0x1c]                           
02d25e30: cbz     x8, #0x2d25e78                             
02d25e34: ldrsw   x10, [x0, #0x18]                           
02d25e38: ldr     w11, [x8, #0x18]                           
02d25e3c: cmp     w10, w11                                   
02d25e40: b.hs    #0x2d25e60                                 
02d25e44: add     x8, x8, x10, lsl #2                        
02d25e48: add     w9, w10, #1                                
02d25e4c: str     w9, [x0, #0x18]                            
02d25e50: str     w1, [x8, #0x20]                            
02d25e54: ldp     x20, x19, [sp, #0x10]                      
02d25e58: ldp     x30, x21, [sp], #0x20                      
02d25e5c: ret                                                
02d25e60: ldr     x8, [x9, #0x20]                            S:'inter_ad_capping_time'
02d25e64: ldp     x20, x19, [sp, #0x10]                      
02d25e68: ldr     x8, [x8, #0xc0]                            
02d25e6c: ldr     x2, [x8, #0x70]                            
02d25e70: ldp     x30, x21, [sp], #0x20                      
02d25e74: b       #0x3569c18                                 
02d25e78: bl      #0x2b7105c                                 fn_2b7105c
#### CLASS Decor.DataDecor parent= GameData
#   field _dataSave                      Decor.DataDecor/DataSaveDecor                      off=0x20 attr=1 SerializeField
## get_DataSave() -> Decor.DataDecor/DataSaveDecor
---- Decor.DataDecor::get_DataSave 0x2d252bc
02d252bc: ldr     x0, [x0, #0x20]                            ._dataSave
02d252c0: ret                                                
## set_DataSave(Decor.DataDecor/DataSaveDecor value) -> void
---- Decor.DataDecor::set_DataSave 0x2d252c4
02d252c4: str     x1, [x0, #0x20]!                           ._dataSave
02d252c8: b       #0x2b70d54                                 
## SaveData() -> void
---- Decor.DataDecor::SaveData 0x2d252cc
02d252cc: stp     x30, x21, [sp, #-0x20]!                    
02d252d0: stp     x20, x19, [sp, #0x10]                      
02d252d4: adrp    x20, #0x6630000                            
02d252d8: adrp    x21, #0x6266000                            
02d252dc: mov     x19, x0                                    
02d252e0: ldrb    w8, [x20, #0x70]                           
02d252e4: ldr     x21, [x21, #0x658]                         MS:MonoSingleton`1::get_Instance
02d252e8: tbnz    w8, #0, #0x2d2530c                         
02d252ec: adrp    x0, #0x6269000                             
02d252f0: ldr     x0, [x0, #0xfa0]                           MS:DataManager::SaveData
02d252f4: bl      #0x2b70db0                                 fn_2b70db0
02d252f8: adrp    x0, #0x6266000                             
02d252fc: ldr     x0, [x0, #0x658]                           MS:MonoSingleton`1::get_Instance
02d25300: bl      #0x2b70db0                                 fn_2b70db0
02d25304: mov     w8, #1                                     
02d25308: strb    w8, [x20, #0x70]                           
02d2530c: ldr     x0, [x21]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d25310: bl      #0x3769600                                 fn_3769600
02d25314: ldr     x8, [x19]                                  
02d25318: mov     x20, x0                                    
02d2531c: mov     x0, x19                                    
02d25320: ldr     x9, [x8, #0x2a8]                           
02d25324: ldr     x1, [x8, #0x2b0]                           
02d25328: blr     x9                                         
02d2532c: cbz     x20, #0x2d25354                            
02d25330: adrp    x8, #0x6269000                             
02d25334: mov     x1, x0                                     
02d25338: mov     x0, x20                                    
02d2533c: ldr     x8, [x8, #0xfa0]                           MS:DataManager::SaveData
02d25340: ldr     x2, [x19, #0x20]                           ._dataSave
02d25344: ldp     x20, x19, [sp, #0x10]                      
02d25348: ldr     x3, [x8]                                   T:Trading.TradingSession/<>c__DisplayClass56_0
02d2534c: ldp     x30, x21, [sp], #0x20                      
02d25350: b       #0x3169790                                 
02d25354: bl      #0x2b7105c                                 fn_2b7105c
## LoadData() -> void
---- Decor.DataDecor::LoadData 0x2d25358
02d25358: stp     x29, x30, [sp, #-0x60]!                    
02d2535c: stp     x28, x27, [sp, #0x10]                      
02d25360: stp     x26, x25, [sp, #0x20]                      
02d25364: stp     x24, x23, [sp, #0x30]                      
02d25368: stp     x22, x21, [sp, #0x40]                      
02d2536c: stp     x20, x19, [sp, #0x50]                      
02d25370: adrp    x20, #0x6630000                            
02d25374: adrp    x21, #0x6266000                            
02d25378: mov     x19, x0                                    
02d2537c: ldrb    w8, [x20, #0x71]                           
02d25380: ldr     x21, [x21, #0x658]                         MS:MonoSingleton`1::get_Instance
02d25384: tbnz    w8, #0, #0x2d25414                         
02d25388: adrp    x0, #0x6269000                             
02d2538c: ldr     x0, [x0, #0xfa8]                           T:type53148(k15)
02d25390: bl      #0x2b70db0                                 fn_2b70db0
02d25394: adrp    x0, #0x6266000                             
02d25398: ldr     x0, [x0, #0x870]                           MS:DataManager::GetAsset
02d2539c: bl      #0x2b70db0                                 fn_2b70db0
02d253a0: adrp    x0, #0x6269000                             
02d253a4: ldr     x0, [x0, #0xfb0]                           MS:DataManager::LoadData
02d253a8: bl      #0x2b70db0                                 fn_2b70db0
02d253ac: adrp    x0, #0x6269000                             
02d253b0: ldr     x0, [x0, #0xfb8]                           MS:System.Collections.Generic.List`1::Find
02d253b4: bl      #0x2b70db0                                 fn_2b70db0
02d253b8: adrp    x0, #0x6269000                             
02d253bc: ldr     x0, [x0, #0xfc0]                           MS:System.Collections.Generic.List`1::ForEach
02d253c0: bl      #0x2b70db0                                 fn_2b70db0
02d253c4: adrp    x0, #0x6266000                             
02d253c8: ldr     x0, [x0, #0x658]                           MS:MonoSingleton`1::get_Instance
02d253cc: bl      #0x2b70db0                                 fn_2b70db0
02d253d0: adrp    x0, #0x6269000                             
02d253d4: ldr     x0, [x0, #0xfc8]                           T:type57306(k15)
02d253d8: bl      #0x2b70db0                                 fn_2b70db0
02d253dc: adrp    x0, #0x6269000                             
02d253e0: ldr     x0, [x0, #0xfd0]                           M:Decor.DataDecor/<>c__DisplayClass7_0::<LoadData>b__0
02d253e4: bl      #0x2b70db0                                 fn_2b70db0
02d253e8: adrp    x0, #0x6269000                             
02d253ec: ldr     x0, [x0, #0xfd8]                           T:Decor.DataDecor/<>c__DisplayClass7_0
02d253f0: bl      #0x2b70db0                                 fn_2b70db0
02d253f4: adrp    x0, #0x6269000                             
02d253f8: ldr     x0, [x0, #0xfe0]                           M:Decor.DataDecor/<>c__DisplayClass7_1::<LoadData>b__1
02d253fc: bl      #0x2b70db0                                 fn_2b70db0
02d25400: adrp    x0, #0x6269000                             
02d25404: ldr     x0, [x0, #0xfe8]                           T:Decor.DataDecor/<>c__DisplayClass7_1
02d25408: bl      #0x2b70db0                                 fn_2b70db0
02d2540c: mov     w8, #1                                     
02d25410: strb    w8, [x20, #0x71]                           
02d25414: ldr     x0, [x21]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d25418: bl      #0x3769600                                 fn_3769600
02d2541c: ldr     x8, [x19]                                  
02d25420: mov     x20, x0                                    
02d25424: mov     x0, x19                                    
02d25428: ldr     x9, [x8, #0x2a8]                           
02d2542c: ldr     x1, [x8, #0x2b0]                           
02d25430: blr     x9                                         
02d25434: cbz     x20, #0x2d255d8                            
02d25438: adrp    x8, #0x6269000                             
02d2543c: mov     x1, x0                                     
02d25440: mov     x0, x20                                    
02d25444: ldr     x8, [x8, #0xfb0]                           MS:DataManager::LoadData
02d25448: ldr     x2, [x8]                                   T:Trading.TradingSession/<>c__DisplayClass56_0
02d2544c: bl      #0x31690b0                                 fn_31690b0
02d25450: mov     x1, x0                                     
02d25454: str     x0, [x19, #0x20]!                          ._dataSave
02d25458: mov     x0, x19                                    
02d2545c: bl      #0x2b70d54                                 fn_2b70d54
02d25460: ldr     x0, [x21]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d25464: bl      #0x3769600                                 fn_3769600
02d25468: cbz     x0, #0x2d255d8                             
02d2546c: adrp    x8, #0x6266000                             
02d25470: adrp    x20, #0x6269000                            
02d25474: ldr     x8, [x8, #0x870]                           MS:DataManager::GetAsset
02d25478: ldr     x20, [x20, #0xfd8]                         T:Decor.DataDecor/<>c__DisplayClass7_0
02d2547c: ldr     x1, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d25480: bl      #0x3168af0                                 fn_3168af0
02d25484: ldr     x8, [x20]                                  T:Trading.TradingSession/<>c__DisplayClass56_0
02d25488: mov     x20, x0                                    
02d2548c: mov     x0, x8                                     
02d25490: bl      #0x2b7104c                                 fn_2b7104c
02d25494: mov     x1, xzr                                    
02d25498: mov     x21, x0                                    
02d2549c: bl      #0x4e53e9c                                 System.Object::.ctor
02d254a0: cbz     x21, #0x2d255d8                            
02d254a4: str     wzr, [x21, #0x10]                          
02d254a8: cbz     x20, #0x2d255d8                            
02d254ac: mov     x0, x20                                    
02d254b0: bl      #0x2d255ec                                 Decor.DecorAsset::GetCategoryAssetCount
02d254b4: cmp     w0, #1                                     
02d254b8: b.lt    #0x2d255bc                                 
02d254bc: adrp    x29, #0x6269000                            
02d254c0: adrp    x26, #0x6269000                            
02d254c4: adrp    x27, #0x6269000                            
02d254c8: adrp    x28, #0x6269000                            
02d254cc: ldr     x29, [x29, #0xfb8]                         MS:System.Collections.Generic.List`1::Find
02d254d0: ldr     x26, [x26, #0xfa8]                         T:type53148(k15)
02d254d4: ldr     x27, [x27, #0xfe0]                         M:Decor.DataDecor/<>c__DisplayClass7_1::<LoadData>b__1
02d254d8: ldr     x28, [x28, #0xfc0]                         MS:System.Collections.Generic.List`1::ForEach
02d254dc: adrp    x8, #0x6269000                             
02d254e0: ldr     x8, [x8, #0xfe8]                           T:Decor.DataDecor/<>c__DisplayClass7_1
02d254e4: ldr     x0, [x8]                                   T:Trading.TradingSession/<>c__DisplayClass56_0
02d254e8: bl      #0x2b7104c                                 fn_2b7104c
02d254ec: mov     x1, xzr                                    
02d254f0: mov     x22, x0                                    
02d254f4: bl      #0x4e53e9c                                 System.Object::.ctor
02d254f8: ldr     w1, [x21, #0x10]                           S:'mrec_ad_on_off'
02d254fc: mov     x0, x20                                    
02d25500: bl      #0x2d249f4                                 Decor.DecorAsset::GetCategoryAssetByIndex
02d25504: ldr     x8, [x19]                                  
02d25508: cbz     x8, #0x2d255d8                             
02d2550c: ldr     x24, [x8, #0x10]                           M:Trading.TradingSession/<>c__DisplayClass56_0::<RemovePlayerItem>b__0
02d25510: adrp    x8, #0x6269000                             
02d25514: mov     x23, x0                                    
02d25518: ldr     x8, [x8, #0xfc8]                           T:type57306(k15)
02d2551c: ldr     x0, [x8]                                   T:Trading.TradingSession/<>c__DisplayClass56_0
02d25520: bl      #0x2b7104c                                 fn_2b7104c
02d25524: adrp    x8, #0x6269000                             
02d25528: mov     x1, x21                                    
02d2552c: mov     x3, xzr                                    
02d25530: ldr     x8, [x8, #0xfd0]                           M:Decor.DataDecor/<>c__DisplayClass7_0::<LoadData>b__0
02d25534: mov     x25, x0                                    
02d25538: ldr     x2, [x8]                                   T:Trading.TradingSession/<>c__DisplayClass56_0
02d2553c: bl      #0x399ba10                                 fn_399ba10
02d25540: cbz     x24, #0x2d255d8                            
02d25544: ldr     x2, [x29]                                  T:Trading.TradingSession/<>c__DisplayClass56_0
02d25548: mov     x0, x24                                    
02d2554c: mov     x1, x25                                    
02d25550: bl      #0x35a9868                                 fn_35a9868
02d25554: cbz     x22, #0x2d255d8                            
02d25558: mov     x1, x0                                     
02d2555c: mov     x0, x22                                    
02d25560: str     x1, [x0, #0x10]!                           
02d25564: bl      #0x2b70d54                                 fn_2b70d54
02d25568: cbz     x23, #0x2d255d8                            
02d2556c: ldr     x0, [x26]                                  T:Trading.TradingSession/<>c__DisplayClass56_0
02d25570: ldr     x23, [x23, #0x30]                          
02d25574: bl      #0x2b7104c                                 fn_2b7104c
02d25578: ldr     x2, [x27]                                  T:Trading.TradingSession/<>c__DisplayClass56_0
02d2557c: mov     x1, x22                                    
02d25580: mov     x3, xzr                                    
02d25584: mov     x24, x0                                    
02d25588: bl      #0x453418c                                 fn_453418c
02d2558c: cbz     x23, #0x2d255d8                            
02d25590: ldr     x2, [x28]                                  T:Trading.TradingSession/<>c__DisplayClass56_0
02d25594: mov     x0, x23                                    
02d25598: mov     x1, x24                                    
02d2559c: bl      #0x35a9ce4                                 fn_35a9ce4
02d255a0: ldr     w8, [x21, #0x10]                           S:'mrec_ad_on_off'
02d255a4: mov     x0, x20                                    
02d255a8: add     w22, w8, #1                                
02d255ac: str     w22, [x21, #0x10]                          
02d255b0: bl      #0x2d255ec                                 Decor.DecorAsset::GetCategoryAssetCount
02d255b4: cmp     w22, w0                                    
02d255b8: b.lt    #0x2d254dc                                 
02d255bc: ldp     x20, x19, [sp, #0x50]                      
02d255c0: ldp     x22, x21, [sp, #0x40]                      
02d255c4: ldp     x24, x23, [sp, #0x30]                      
02d255c8: ldp     x26, x25, [sp, #0x20]                      
02d255cc: ldp     x28, x27, [sp, #0x10]                      
02d255d0: ldp     x29, x30, [sp], #0x60                      
02d255d4: ret                                                
02d255d8: bl      #0x2b7105c                                 fn_2b7105c
## NewData() -> void
---- Decor.DataDecor::NewData 0x2d25634
02d25634: sub     sp, sp, #0x70                              
02d25638: stp     x29, x30, [sp, #0x10]                      
02d2563c: stp     x28, x27, [sp, #0x20]                      
02d25640: stp     x26, x25, [sp, #0x30]                      
02d25644: stp     x24, x23, [sp, #0x40]                      
02d25648: stp     x22, x21, [sp, #0x50]                      
02d2564c: stp     x20, x19, [sp, #0x60]                      
02d25650: adrp    x23, #0x6630000                            
02d25654: adrp    x20, #0x6269000                            
02d25658: adrp    x22, #0x626a000                            
02d2565c: adrp    x21, #0x626a000                            
02d25660: ldr     x20, [x20, #0xff8]                         T:Decor.DataDecor/DataSaveDecor
02d25664: ldrb    w8, [x23, #0x72]                           
02d25668: ldr     x22, [x22]                                 T:type56879(k15)
02d2566c: ldr     x21, [x21, #8]                             MS:System.Collections.Generic.List`1::.ctor
02d25670: mov     x19, x0                                    
02d25674: tbnz    w8, #0, #0x2d25734                         
02d25678: adrp    x0, #0x6269000                             
02d2567c: ldr     x0, [x0, #0xfa8]                           T:type53148(k15)
02d25680: bl      #0x2b70db0                                 fn_2b70db0
02d25684: adrp    x0, #0x626a000                             
02d25688: ldr     x0, [x0, #0x10]                            T:Decor.DataDecor/CategoryData
02d2568c: bl      #0x2b70db0                                 fn_2b70db0
02d25690: adrp    x0, #0x6266000                             
02d25694: ldr     x0, [x0, #0x870]                           MS:DataManager::GetAsset
02d25698: bl      #0x2b70db0                                 fn_2b70db0
02d2569c: adrp    x0, #0x6269000                             
02d256a0: ldr     x0, [x0, #0xff8]                           T:Decor.DataDecor/DataSaveDecor
02d256a4: bl      #0x2b70db0                                 fn_2b70db0
02d256a8: adrp    x0, #0x6263000                             
02d256ac: ldr     x0, [x0, #0x928]                           T:UnityEngine.Debug
02d256b0: bl      #0x2b70db0                                 fn_2b70db0
02d256b4: adrp    x0, #0x626a000                             
02d256b8: ldr     x0, [x0, #0x18]                            MS:System.Collections.Generic.List`1::Add
02d256bc: bl      #0x2b70db0                                 fn_2b70db0
02d256c0: adrp    x0, #0x6269000                             
02d256c4: ldr     x0, [x0, #0xfc0]                           MS:System.Collections.Generic.List`1::ForEach
02d256c8: bl      #0x2b70db0                                 fn_2b70db0
02d256cc: adrp    x0, #0x6266000                             
02d256d0: ldr     x0, [x0, #0x650]                           MS:System.Collections.Generic.List`1::.ctor
02d256d4: bl      #0x2b70db0                                 fn_2b70db0
02d256d8: adrp    x0, #0x626a000                             
02d256dc: ldr     x0, [x0, #8]                               MS:System.Collections.Generic.List`1::.ctor
02d256e0: bl      #0x2b70db0                                 fn_2b70db0
02d256e4: adrp    x0, #0x6266000                             
02d256e8: ldr     x0, [x0, #0x648]                           T:type15061(k15)
02d256ec: bl      #0x2b70db0                                 fn_2b70db0
02d256f0: adrp    x0, #0x626a000                             
02d256f4: ldr     x0, [x0]                                   T:type56879(k15)
02d256f8: bl      #0x2b70db0                                 fn_2b70db0
02d256fc: adrp    x0, #0x6266000                             
02d25700: ldr     x0, [x0, #0x658]                           MS:MonoSingleton`1::get_Instance
02d25704: bl      #0x2b70db0                                 fn_2b70db0
02d25708: adrp    x0, #0x626a000                             
02d2570c: ldr     x0, [x0, #0x20]                            M:Decor.DataDecor/<>c__DisplayClass8_0::<NewData>b__0 ._dataSave
02d25710: bl      #0x2b70db0                                 fn_2b70db0
02d25714: adrp    x0, #0x626a000                             
02d25718: ldr     x0, [x0, #0x28]                            T:Decor.DataDecor/<>c__DisplayClass8_0
02d2571c: bl      #0x2b70db0                                 fn_2b70db0
02d25720: adrp    x0, #0x626a000                             
02d25724: ldr     x0, [x0, #0x30]                            S:'======================================================  i : '
02d25728: bl      #0x2b70db0                                 fn_2b70db0
02d2572c: mov     w8, #1                                     
02d25730: strb    w8, [x23, #0x72]                           
02d25734: ldr     x0, [x20]                                  T:Trading.TradingSession/<>c__DisplayClass56_0
02d25738: str     wzr, [sp, #0xc]                            
02d2573c: bl      #0x2b7104c                                 fn_2b7104c
02d25740: mov     x1, xzr                                    
02d25744: mov     x20, x0                                    
02d25748: bl      #0x4e53e9c                                 System.Object::.ctor
02d2574c: str     x20, [x19, #0x20]!                         ._dataSave
02d25750: mov     x0, x19                                    
02d25754: mov     x1, x20                                    
02d25758: bl      #0x2b70d54                                 fn_2b70d54
02d2575c: ldr     x0, [x22]                                  T:type56879(k15)
02d25760: ldr     x20, [x19]                                 
02d25764: bl      #0x2b7104c                                 fn_2b7104c
02d25768: ldr     x1, [x21]                                  T:type56879(k15)
02d2576c: mov     x21, x0                                    
02d25770: bl      #0x35a89a4                                 fn_35a89a4
02d25774: cbz     x20, #0x2d259bc                            
02d25778: adrp    x22, #0x6266000                            
02d2577c: mov     x1, x21                                    
02d25780: ldr     x22, [x22, #0x658]                         MS:MonoSingleton`1::get_Instance
02d25784: str     x21, [x20, #0x10]!                         
02d25788: mov     x0, x20                                    
02d2578c: bl      #0x2b70d54                                 fn_2b70d54
02d25790: ldr     x0, [x22]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d25794: bl      #0x3769600                                 fn_3769600
02d25798: cbz     x0, #0x2d259bc                             
02d2579c: adrp    x8, #0x6266000                             
02d257a0: ldr     x8, [x8, #0x870]                           MS:DataManager::GetAsset
02d257a4: ldr     x1, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d257a8: bl      #0x3168af0                                 fn_3168af0
02d257ac: str     wzr, [sp, #0xc]                            
02d257b0: cbz     x0, #0x2d259bc                             
02d257b4: mov     x20, x0                                    
02d257b8: bl      #0x2d255ec                                 Decor.DecorAsset::GetCategoryAssetCount
02d257bc: cmp     w0, #1                                     
02d257c0: b.lt    #0x2d2599c                                 
02d257c4: adrp    x25, #0x6266000                            
02d257c8: adrp    x26, #0x6269000                            
02d257cc: adrp    x27, #0x626a000                            
02d257d0: adrp    x28, #0x6269000                            
02d257d4: adrp    x29, #0x626a000                            
02d257d8: ldr     x25, [x25, #0x650]                         MS:System.Collections.Generic.List`1::.ctor
02d257dc: ldr     x26, [x26, #0xfa8]                         T:type53148(k15)
02d257e0: ldr     x27, [x27, #0x20]                          M:Decor.DataDecor/<>c__DisplayClass8_0::<NewData>b__0
02d257e4: ldr     x28, [x28, #0xfc0]                         MS:System.Collections.Generic.List`1::ForEach
02d257e8: ldr     x29, [x29, #0x18]                          MS:System.Collections.Generic.List`1::Add
02d257ec: adrp    x8, #0x626a000                             
02d257f0: ldr     x8, [x8, #0x28]                            T:Decor.DataDecor/<>c__DisplayClass8_0
02d257f4: ldr     x0, [x8]                                   T:type56879(k15)
02d257f8: bl      #0x2b7104c                                 fn_2b7104c
02d257fc: mov     x1, xzr                                    
02d25800: mov     x21, x0                                    
02d25804: bl      #0x4e53e9c                                 System.Object::.ctor
02d25808: add     x0, sp, #0xc                               
02d2580c: mov     x1, xzr                                    
02d25810: bl      #0x4e0ea3c                                 System.Int32::ToString
02d25814: adrp    x8, #0x626a000                             
02d25818: mov     x1, x0                                     
02d2581c: mov     x2, xzr                                    
02d25820: ldr     x8, [x8, #0x30]                            S:'======================================================  i : '
02d25824: ldr     x8, [x8]                                   T:type56879(k15)
02d25828: mov     x0, x8                                     
02d2582c: bl      #0x4c9c514                                 System.String::Concat
02d25830: adrp    x8, #0x6263000                             
02d25834: mov     x22, x0                                    
02d25838: ldr     x8, [x8, #0x928]                           T:UnityEngine.Debug
02d2583c: ldr     x8, [x8]                                   &2c5bbd4(=a9bd7bfdd503233f)
02d25840: ldr     w9, [x8, #0xe4]                            [62630e4]=0 f=0,0
02d25844: cbnz    w9, #0x2d25850                             
02d25848: mov     x0, x8                                     
02d2584c: bl      #0x2b70f30                                 fn_2b70f30
02d25850: mov     x0, x22                                    
02d25854: mov     x1, xzr                                    
02d25858: bl      #0x5af2840                                 UnityEngine.Debug::LogError
02d2585c: adrp    x8, #0x626a000                             
02d25860: ldr     x8, [x8, #0x10]                            T:Decor.DataDecor/CategoryData
02d25864: ldr     x0, [x8]                                   T:type56879(k15)
02d25868: bl      #0x2b7104c                                 fn_2b7104c
02d2586c: mov     x1, xzr                                    
02d25870: mov     x23, x0                                    
02d25874: bl      #0x4e53e9c                                 System.Object::.ctor
02d25878: cbz     x21, #0x2d259bc                            
02d2587c: mov     x22, x21                                   
02d25880: mov     x1, x23                                    
02d25884: str     x23, [x22, #0x10]!                         
02d25888: mov     x0, x22                                    
02d2588c: bl      #0x2b70d54                                 fn_2b70d54
02d25890: ldr     x23, [x22]                                 M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d25894: cbz     x23, #0x2d259bc                            
02d25898: adrp    x9, #0x6266000                             
02d2589c: ldr     w8, [sp, #0xc]                             
02d258a0: ldr     x9, [x9, #0x648]                           T:type15061(k15)
02d258a4: str     w8, [x23, #0x10]                           
02d258a8: ldr     x0, [x9]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d258ac: bl      #0x2b7104c                                 fn_2b7104c
02d258b0: ldr     x1, [x25]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d258b4: mov     x24, x0                                    
02d258b8: bl      #0x3569388                                 fn_3569388
02d258bc: str     x24, [x23, #0x18]!                         
02d258c0: mov     x0, x23                                    
02d258c4: mov     x1, x24                                    
02d258c8: bl      #0x2b70d54                                 fn_2b70d54
02d258cc: ldr     w1, [sp, #0xc]                             
02d258d0: mov     x0, x20                                    
02d258d4: bl      #0x2d249f4                                 Decor.DecorAsset::GetCategoryAssetByIndex
02d258d8: cbz     x0, #0x2d259bc                             
02d258dc: ldr     x23, [x0, #0x30]                           S:'======================================================  i : '
02d258e0: ldr     x0, [x26]                                  T:Trading.TradingSession/<>c__DisplayClass56_0
02d258e4: bl      #0x2b7104c                                 fn_2b7104c
02d258e8: ldr     x2, [x27]                                  T:type56879(k15)
02d258ec: mov     x1, x21                                    
02d258f0: mov     x3, xzr                                    
02d258f4: mov     x24, x0                                    
02d258f8: bl      #0x453418c                                 fn_453418c
02d258fc: cbz     x23, #0x2d259bc                            
02d25900: ldr     x2, [x28]                                  T:Trading.TradingSession/<>c__DisplayClass56_0
02d25904: mov     x0, x23                                    
02d25908: mov     x1, x24                                    
02d2590c: bl      #0x35a9ce4                                 fn_35a9ce4
02d25910: ldr     x1, [x22]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d25914: cbz     x1, #0x2d259bc                             
02d25918: ldr     x8, [x19]                                  
02d2591c: str     wzr, [x1, #0x14]                           
02d25920: cbz     x8, #0x2d259bc                             
02d25924: ldr     x0, [x8, #0x10]                            T:Decor.DataDecor/CategoryData
02d25928: cbz     x0, #0x2d259bc                             
02d2592c: ldr     w10, [x0, #0x1c]                           [626a01c]=0 f=0,0
02d25930: ldr     x8, [x0, #0x10]                            T:Decor.DataDecor/CategoryData
02d25934: ldr     x9, [x29]                                  T:type56879(k15)
02d25938: add     w10, w10, #1                               
02d2593c: str     w10, [x0, #0x1c]                           
02d25940: cbz     x8, #0x2d259bc                             
02d25944: ldrsw   x10, [x0, #0x18]                           
02d25948: ldr     w11, [x8, #0x18]                           MS:System.Collections.Generic.List`1::Add
02d2594c: cmp     w10, w11                                   
02d25950: b.hs    #0x2d25970                                 
02d25954: add     x8, x8, x10, lsl #3                        &626a000
02d25958: add     w9, w10, #1                                
02d2595c: str     w9, [x0, #0x18]                            
02d25960: str     x1, [x8, #0x20]!                           
02d25964: mov     x0, x8                                     
02d25968: bl      #0x2b70d54                                 fn_2b70d54
02d2596c: b       #0x2d25980                                 
02d25970: ldr     x8, [x9, #0x20]                            S:'inter_ad_capping_time'
02d25974: ldr     x8, [x8, #0xc0]                            S:'Main character is null'
02d25978: ldr     x2, [x8, #0x70]                            MS:System.Collections.Generic.List`1::FindIndex
02d2597c: bl      #0x35a920c                                 fn_35a920c
02d25980: ldr     w8, [sp, #0xc]                             
02d25984: mov     x0, x20                                    
02d25988: add     w21, w8, #1                                
02d2598c: str     w21, [sp, #0xc]                            
02d25990: bl      #0x2d255ec                                 Decor.DecorAsset::GetCategoryAssetCount
02d25994: cmp     w21, w0                                    
02d25998: b.lt    #0x2d257ec                                 
02d2599c: ldp     x20, x19, [sp, #0x60]                      
02d259a0: ldp     x22, x21, [sp, #0x50]                      
02d259a4: ldp     x24, x23, [sp, #0x40]                      
02d259a8: ldp     x26, x25, [sp, #0x30]                      
02d259ac: ldp     x28, x27, [sp, #0x20]                      
02d259b0: ldp     x29, x30, [sp, #0x10]                      
02d259b4: add     sp, sp, #0x70                              
02d259b8: ret                                                
02d259bc: bl      #0x2b7105c                                 fn_2b7105c
## UnlockItem(int categoryIndex, int itemID) -> bool
---- Decor.DataDecor::UnlockItem 0x2d259d8
02d259d8: stp     x30, x23, [sp, #-0x30]!                    
02d259dc: stp     x22, x21, [sp, #0x10]                      
02d259e0: stp     x20, x19, [sp, #0x20]                      
02d259e4: adrp    x21, #0x6630000                            
02d259e8: mov     w20, w2                                    
02d259ec: mov     w22, w1                                    
02d259f0: ldrb    w8, [x21, #0x73]                           
02d259f4: mov     x19, x0                                    
02d259f8: tbnz    w8, #0, #0x2d25a28                         
02d259fc: adrp    x0, #0x6266000                             
02d25a00: ldr     x0, [x0, #0x818]                           MS:System.Collections.Generic.List`1::Add
02d25a04: bl      #0x2b70db0                                 fn_2b70db0
02d25a08: adrp    x0, #0x6266000                             
02d25a0c: ldr     x0, [x0, #0x820]                           MS:System.Collections.Generic.List`1::Contains
02d25a10: bl      #0x2b70db0                                 fn_2b70db0
02d25a14: adrp    x0, #0x626a000                             
02d25a18: ldr     x0, [x0, #0x38]                            MS:System.Collections.Generic.List`1::get_Item
02d25a1c: bl      #0x2b70db0                                 fn_2b70db0
02d25a20: mov     w8, #1                                     
02d25a24: strb    w8, [x21, #0x73]                           
02d25a28: ldr     x8, [x19, #0x20]                           ._dataSave
02d25a2c: cbz     x8, #0x2d25b20                             
02d25a30: ldr     x0, [x8, #0x10]                            
02d25a34: cbz     x0, #0x2d25b20                             
02d25a38: adrp    x23, #0x626a000                            
02d25a3c: mov     w1, w22                                    
02d25a40: ldr     x23, [x23, #0x38]                          MS:System.Collections.Generic.List`1::get_Item
02d25a44: ldr     x2, [x23]                                  T:type56879(k15)
02d25a48: bl      #0x35a8f3c                                 fn_35a8f3c
02d25a4c: cbz     x0, #0x2d25b20                             
02d25a50: ldr     x0, [x0, #0x18]                            MS:System.Collections.Generic.List`1::Add
02d25a54: cbz     x0, #0x2d25b20                             
02d25a58: adrp    x8, #0x6266000                             
02d25a5c: mov     w1, w20                                    
02d25a60: ldr     x8, [x8, #0x820]                           MS:System.Collections.Generic.List`1::Contains
02d25a64: ldr     x2, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d25a68: bl      #0x3569f98                                 fn_3569f98
02d25a6c: mov     w21, w0                                    
02d25a70: tbnz    w0, #0, #0x2d25b08                         
02d25a74: ldr     x8, [x19, #0x20]                           ._dataSave
02d25a78: cbz     x8, #0x2d25b20                             
02d25a7c: ldr     x0, [x8, #0x10]                            S:'mrec_ad_on_off'
02d25a80: cbz     x0, #0x2d25b20                             
02d25a84: ldr     x2, [x23]                                  T:type56879(k15)
02d25a88: mov     w1, w22                                    
02d25a8c: bl      #0x35a8f3c                                 fn_35a8f3c
02d25a90: cbz     x0, #0x2d25b20                             
02d25a94: ldr     x0, [x0, #0x18]                            MS:System.Collections.Generic.List`1::Add
02d25a98: cbz     x0, #0x2d25b20                             
02d25a9c: adrp    x9, #0x6266000                             
02d25aa0: ldr     x9, [x9, #0x818]                           MS:System.Collections.Generic.List`1::Add
02d25aa4: ldr     w10, [x0, #0x1c]                           [626a01c]=0 f=0,0
02d25aa8: ldr     x8, [x0, #0x10]                            T:Decor.DataDecor/CategoryData
02d25aac: ldr     x9, [x9]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d25ab0: add     w10, w10, #1                               
02d25ab4: str     w10, [x0, #0x1c]                           
02d25ab8: cbz     x8, #0x2d25b20                             
02d25abc: ldrsw   x10, [x0, #0x18]                           
02d25ac0: ldr     w11, [x8, #0x18]                           S:'level_show_popuprate'
02d25ac4: cmp     w10, w11                                   
02d25ac8: b.hs    #0x2d25ae0                                 
02d25acc: add     x8, x8, x10, lsl #2                        &6266000
02d25ad0: add     w9, w10, #1                                
02d25ad4: str     w9, [x0, #0x18]                            
02d25ad8: str     w20, [x8, #0x20]                           
02d25adc: b       #0x2d25af4                                 
02d25ae0: ldr     x8, [x9, #0x20]                            S:'inter_ad_capping_time'
02d25ae4: mov     w1, w20                                    
02d25ae8: ldr     x8, [x8, #0xc0]                            T:Firebase.RemoteConfig.ConfigValue
02d25aec: ldr     x2, [x8, #0x70]                            S:'open_ad_id'
02d25af0: bl      #0x3569c18                                 fn_3569c18
02d25af4: ldr     x8, [x19]                                  
02d25af8: mov     x0, x19                                    
02d25afc: ldr     x9, [x8, #0x258]                           MS:System.Collections.Generic.List`1/Enumerator::Dispose
02d25b00: ldr     x1, [x8, #0x260]                           MS:System.Collections.Generic.List`1/Enumerator::MoveNext
02d25b04: blr     x9                                         
02d25b08: mov     w8, #1                                     
02d25b0c: ldp     x20, x19, [sp, #0x20]                      
02d25b10: bic     w0, w8, w21                                
02d25b14: ldp     x22, x21, [sp, #0x10]                      
02d25b18: ldp     x30, x23, [sp], #0x30                      
02d25b1c: ret                                                
02d25b20: bl      #0x2b7105c                                 fn_2b7105c
## HasUnlockedItem(int categoryIndex, int itemID) -> bool
---- Decor.DataDecor::HasUnlockedItem 0x2d25b24
02d25b24: str     x30, [sp, #-0x30]!                         
02d25b28: stp     x22, x21, [sp, #0x10]                      
02d25b2c: stp     x20, x19, [sp, #0x20]                      
02d25b30: adrp    x22, #0x6630000                            
02d25b34: mov     w19, w2                                    
02d25b38: mov     w20, w1                                    
02d25b3c: ldrb    w8, [x22, #0x74]                           
02d25b40: mov     x21, x0                                    
02d25b44: tbnz    w8, #0, #0x2d25b68                         
02d25b48: adrp    x0, #0x6266000                             
02d25b4c: ldr     x0, [x0, #0x820]                           MS:System.Collections.Generic.List`1::Contains
02d25b50: bl      #0x2b70db0                                 fn_2b70db0
02d25b54: adrp    x0, #0x626a000                             
02d25b58: ldr     x0, [x0, #0x38]                            MS:System.Collections.Generic.List`1::get_Item
02d25b5c: bl      #0x2b70db0                                 fn_2b70db0
02d25b60: mov     w8, #1                                     
02d25b64: strb    w8, [x22, #0x74]                           
02d25b68: ldr     x8, [x21, #0x20]                           ._dataSave
02d25b6c: cbz     x8, #0x2d25bb8                             
02d25b70: ldr     x0, [x8, #0x10]                            
02d25b74: cbz     x0, #0x2d25bb8                             
02d25b78: adrp    x8, #0x626a000                             
02d25b7c: mov     w1, w20                                    
02d25b80: ldr     x8, [x8, #0x38]                            MS:System.Collections.Generic.List`1::get_Item
02d25b84: ldr     x2, [x8]                                   T:type56879(k15)
02d25b88: bl      #0x35a8f3c                                 fn_35a8f3c
02d25b8c: cbz     x0, #0x2d25bb8                             
02d25b90: ldr     x0, [x0, #0x18]                            MS:System.Collections.Generic.List`1::Add
02d25b94: cbz     x0, #0x2d25bb8                             
02d25b98: adrp    x8, #0x6266000                             
02d25b9c: mov     w1, w19                                    
02d25ba0: ldr     x8, [x8, #0x820]                           MS:System.Collections.Generic.List`1::Contains
02d25ba4: ldp     x20, x19, [sp, #0x20]                      
02d25ba8: ldp     x22, x21, [sp, #0x10]                      
02d25bac: ldr     x2, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d25bb0: ldr     x30, [sp], #0x30                           
02d25bb4: b       #0x3569f98                                 
02d25bb8: bl      #0x2b7105c                                 fn_2b7105c
## SetSelectedItem(int categoryIndex, int itemID) -> void
---- Decor.DataDecor::SetSelectedItem 0x2d25bbc
02d25bbc: str     x30, [sp, #-0x30]!                         
02d25bc0: stp     x22, x21, [sp, #0x10]                      
02d25bc4: stp     x20, x19, [sp, #0x20]                      
02d25bc8: adrp    x22, #0x6630000                            
02d25bcc: mov     w20, w2                                    
02d25bd0: mov     w21, w1                                    
02d25bd4: ldrb    w8, [x22, #0x75]                           
02d25bd8: mov     x19, x0                                    
02d25bdc: tbnz    w8, #0, #0x2d25bf4                         
02d25be0: adrp    x0, #0x626a000                             
02d25be4: ldr     x0, [x0, #0x38]                            MS:System.Collections.Generic.List`1::get_Item
02d25be8: bl      #0x2b70db0                                 fn_2b70db0
02d25bec: mov     w8, #1                                     
02d25bf0: strb    w8, [x22, #0x75]                           
02d25bf4: ldr     x8, [x19, #0x20]                           ._dataSave
02d25bf8: cbz     x8, #0x2d25c40                             
02d25bfc: ldr     x0, [x8, #0x10]                            
02d25c00: cbz     x0, #0x2d25c40                             
02d25c04: adrp    x8, #0x626a000                             
02d25c08: mov     w1, w21                                    
02d25c0c: ldr     x8, [x8, #0x38]                            MS:System.Collections.Generic.List`1::get_Item
02d25c10: ldr     x2, [x8]                                   T:type56879(k15)
02d25c14: bl      #0x35a8f3c                                 fn_35a8f3c
02d25c18: cbz     x0, #0x2d25c40                             
02d25c1c: str     w20, [x0, #0x14]                           
02d25c20: mov     x0, x19                                    
02d25c24: ldr     x8, [x19]                                  
02d25c28: ldp     x20, x19, [sp, #0x20]                      
02d25c2c: ldp     x22, x21, [sp, #0x10]                      
02d25c30: ldr     x1, [x8, #0x260]                           MS:System.Collections.Generic.List`1/Enumerator::Dispose
02d25c34: ldr     x2, [x8, #0x258]                           M:Decor.OptionPanel::<Refresh>b__19_0
02d25c38: ldr     x30, [sp], #0x30                           
02d25c3c: br      x2                                         
02d25c40: bl      #0x2b7105c                                 fn_2b7105c
## GetSelectedItem(int categoryIndex) -> int
---- Decor.DataDecor::GetSelectedItem 0x2d25c44
02d25c44: stp     x30, x21, [sp, #-0x20]!                    
02d25c48: stp     x20, x19, [sp, #0x10]                      
02d25c4c: adrp    x21, #0x6630000                            
02d25c50: mov     w19, w1                                    
02d25c54: mov     x20, x0                                    
02d25c58: ldrb    w8, [x21, #0x76]                           
02d25c5c: tbnz    w8, #0, #0x2d25c74                         
02d25c60: adrp    x0, #0x626a000                             
02d25c64: ldr     x0, [x0, #0x38]                            MS:System.Collections.Generic.List`1::get_Item
02d25c68: bl      #0x2b70db0                                 fn_2b70db0
02d25c6c: mov     w8, #1                                     
02d25c70: strb    w8, [x21, #0x76]                           
02d25c74: ldr     x8, [x20, #0x20]                           ._dataSave
02d25c78: cbz     x8, #0x2d25cac                             
02d25c7c: ldr     x0, [x8, #0x10]                            
02d25c80: cbz     x0, #0x2d25cac                             
02d25c84: adrp    x8, #0x626a000                             
02d25c88: mov     w1, w19                                    
02d25c8c: ldr     x8, [x8, #0x38]                            MS:System.Collections.Generic.List`1::get_Item
02d25c90: ldr     x2, [x8]                                   T:type56879(k15)
02d25c94: bl      #0x35a8f3c                                 fn_35a8f3c
02d25c98: cbz     x0, #0x2d25cac                             
02d25c9c: ldp     x20, x19, [sp, #0x10]                      
02d25ca0: ldr     w0, [x0, #0x14]                            [626a014]=0 f=0,0
02d25ca4: ldp     x30, x21, [sp], #0x20                      
02d25ca8: ret                                                
02d25cac: bl      #0x2b7105c                                 fn_2b7105c
## .ctor() -> void
---- Decor.DataDecor::.ctor 0x2d25cb0
02d25cb0: mov     x1, xzr                                    
02d25cb4: b       #0x2ca9988                                 GameData::.ctor
