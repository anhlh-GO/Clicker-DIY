#### CLASS Framework.SpriteRendererExtension parent= object
## SetAlpha(UnityEngine.SpriteRenderer sr, float alpha) -> void
---- Framework.SpriteRendererExtension::SetAlpha 0x2cb9efc
02cb9efc: str     d8, [sp, #-0x20]!                          
02cb9f00: stp     x30, x19, [sp, #0x10]                      
02cb9f04: cbz     x0, #0x2cb9f30                             
02cb9f08: mov     x1, xzr                                    
02cb9f0c: mov     x19, x0                                    
02cb9f10: fmov    s8, s0                                     
02cb9f14: bl      #0x5ae7044                                 UnityEngine.SpriteRenderer::get_color
02cb9f18: mov     x0, x19                                    
02cb9f1c: ldp     x30, x19, [sp, #0x10]                      
02cb9f20: fmov    s3, s8                                     
02cb9f24: mov     x1, xzr                                    
02cb9f28: ldr     d8, [sp], #0x20                            
02cb9f2c: b       #0x5ae711c                                 UnityEngine.SpriteRenderer::set_color
02cb9f30: bl      #0x2b7105c                                 fn_2b7105c
## FitCamera(UnityEngine.SpriteRenderer sr, UnityEngine.Camera camera) -> void
---- Framework.SpriteRendererExtension::FitCamera 0x2cb9f34
02cb9f34: sub     sp, sp, #0x80                              
02cb9f38: stp     d13, d12, [sp, #0x20]                      
02cb9f3c: stp     d11, d10, [sp, #0x30]                      
02cb9f40: stp     d9, d8, [sp, #0x40]                        
02cb9f44: str     x30, [sp, #0x50]                           
02cb9f48: stp     x22, x21, [sp, #0x60]                      
02cb9f4c: stp     x20, x19, [sp, #0x70]                      
02cb9f50: cbz     x1, #0x2cba12c                             
02cb9f54: mov     x20, x1                                    
02cb9f58: mov     x19, x0                                    
02cb9f5c: mov     x0, x1                                     
02cb9f60: mov     x1, xzr                                    
02cb9f64: bl      #0x5aedd28                                 UnityEngine.Camera::get_orthographic
02cb9f68: tbz     w0, #0, #0x2cba014                         
02cb9f6c: mov     x0, x20                                    
02cb9f70: mov     x1, xzr                                    
02cb9f74: bl      #0x5aedba0                                 UnityEngine.Camera::get_orthographicSize
02cb9f78: mov     x0, xzr                                    
02cb9f7c: fmov    s8, s0                                     
02cb9f80: bl      #0x5afb724                                 UnityEngine.Screen::get_height
02cb9f84: mov     w22, w0                                    
02cb9f88: mov     x0, xzr                                    
02cb9f8c: bl      #0x5afb6fc                                 UnityEngine.Screen::get_width
02cb9f90: cbz     x19, #0x2cba12c                            
02cb9f94: mov     w21, w0                                    
02cb9f98: mov     x0, x19                                    
02cb9f9c: mov     x1, xzr                                    
02cb9fa0: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02cb9fa4: mov     x20, x0                                    
02cb9fa8: mov     x0, x19                                    
02cb9fac: mov     x1, xzr                                    
02cb9fb0: bl      #0x5ae6cfc                                 UnityEngine.SpriteRenderer::get_sprite
02cb9fb4: cbz     x0, #0x2cba12c                             
02cb9fb8: add     x8, sp, #8                                 
02cb9fbc: mov     x1, xzr                                    
02cb9fc0: bl      #0x5ae7d34                                 UnityEngine.Sprite::get_bounds
02cb9fc4: ldr     s9, [sp, #0x14]                            
02cb9fc8: mov     x0, x19                                    
02cb9fcc: mov     x1, xzr                                    
02cb9fd0: bl      #0x5ae6cfc                                 UnityEngine.SpriteRenderer::get_sprite
02cb9fd4: cbz     x0, #0x2cba12c                             
02cb9fd8: add     x8, sp, #8                                 
02cb9fdc: mov     x1, xzr                                    
02cb9fe0: bl      #0x5ae7d34                                 UnityEngine.Sprite::get_bounds
02cb9fe4: cbz     x20, #0x2cba12c                            
02cb9fe8: fadd    s0, s8, s8                                 
02cb9fec: scvtf   s1, w22                                    
02cb9ff0: fdiv    s2, s0, s1                                 
02cb9ff4: ldr     s1, [sp, #0x18]                            
02cb9ff8: fadd    s1, s1, s1                                 
02cb9ffc: fdiv    s1, s0, s1                                 
02cba000: scvtf   s0, w21                                    
02cba004: fmul    s0, s2, s0                                 
02cba008: fadd    s2, s9, s9                                 
02cba00c: fdiv    s0, s0, s2                                 
02cba010: b       #0x2cba0fc                                 
02cba014: cbz     x19, #0x2cba12c                            
02cba018: mov     x0, x19                                    
02cba01c: mov     x1, xzr                                    
02cba020: bl      #0x5ae6cfc                                 UnityEngine.SpriteRenderer::get_sprite
02cba024: cbz     x0, #0x2cba12c                             
02cba028: add     x8, sp, #8                                 
02cba02c: mov     x1, xzr                                    
02cba030: bl      #0x5ae7d34                                 UnityEngine.Sprite::get_bounds
02cba034: ldr     s12, [sp, #0x18]                           
02cba038: mov     x0, x19                                    
02cba03c: mov     x1, xzr                                    
02cba040: bl      #0x5ae6cfc                                 UnityEngine.SpriteRenderer::get_sprite
02cba044: cbz     x0, #0x2cba12c                             
02cba048: add     x8, sp, #8                                 
02cba04c: mov     x1, xzr                                    
02cba050: bl      #0x5ae7d34                                 UnityEngine.Sprite::get_bounds
02cba054: ldr     s13, [sp, #0x14]                           
02cba058: mov     x0, x19                                    
02cba05c: mov     x1, xzr                                    
02cba060: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02cba064: cbz     x0, #0x2cba12c                             
02cba068: mov     x1, xzr                                    
02cba06c: bl      #0x5b467ac                                 UnityEngine.Transform::get_position
02cba070: mov     x0, x20                                    
02cba074: mov     x1, xzr                                    
02cba078: fmov    s8, s2                                     
02cba07c: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02cba080: cbz     x0, #0x2cba12c                             
02cba084: mov     x1, xzr                                    
02cba088: bl      #0x5b467ac                                 UnityEngine.Transform::get_position
02cba08c: mov     x0, x20                                    
02cba090: mov     x1, xzr                                    
02cba094: fmov    s9, s2                                     
02cba098: bl      #0x5aed7fc                                 UnityEngine.Camera::get_fieldOfView
02cba09c: mov     x0, x20                                    
02cba0a0: mov     x1, xzr                                    
02cba0a4: fmov    s11, s0                                    
02cba0a8: bl      #0x5aee0f4                                 UnityEngine.Camera::get_aspect
02cba0ac: mov     x0, x19                                    
02cba0b0: mov     x1, xzr                                    
02cba0b4: fmov    s10, s0                                    
02cba0b8: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02cba0bc: cbz     x0, #0x2cba12c                             
02cba0c0: adrp    x8, #0x1085000                             
02cba0c4: fmov    s1, #0.50000000                            
02cba0c8: mov     x20, x0                                    
02cba0cc: ldr     s0, [x8, #0x10]                            [1085010]=4202c6f23c8efa35 f=0.0174533,32.6943
02cba0d0: fmul    s0, s11, s0                                
02cba0d4: fadd    s11, s12, s12                              
02cba0d8: fadd    s12, s13, s13                              
02cba0dc: fmul    s0, s0, s1                                 
02cba0e0: bl      #0x5e902e0                                 fn_5e902e0
02cba0e4: fsub    s1, s8, s9                                 
02cba0e8: fadd    s0, s0, s0                                 
02cba0ec: fmul    s0, s1, s0                                 
02cba0f0: fdiv    s1, s0, s11                                
02cba0f4: fmul    s0, s10, s0                                
02cba0f8: fdiv    s0, s0, s12                                
02cba0fc: fmov    s2, #1.00000000                            
02cba100: mov     x0, x20                                    
02cba104: mov     x1, xzr                                    
02cba108: bl      #0x5b470cc                                 UnityEngine.Transform::set_localScale
02cba10c: ldp     x20, x19, [sp, #0x70]                      
02cba110: ldr     x30, [sp, #0x50]                           
02cba114: ldp     x22, x21, [sp, #0x60]                      
02cba118: ldp     d9, d8, [sp, #0x40]                        
02cba11c: ldp     d11, d10, [sp, #0x30]                      
02cba120: ldp     d13, d12, [sp, #0x20]                      
02cba124: add     sp, sp, #0x80                              
02cba128: ret                                                
02cba12c: bl      #0x2b7105c                                 fn_2b7105c
