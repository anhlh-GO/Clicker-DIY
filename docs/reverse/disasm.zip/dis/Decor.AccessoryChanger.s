#### CLASS Decor.AccessoryChanger parent= UnityEngine.MonoBehaviour
#   field _spriteRenderer                UnityEngine.SpriteRenderer                         off=0x20 attr=1 SerializeField
#   field _currentID                     int                                                off=0x28 attr=1 
## Awake() -> void
---- Decor.AccessoryChanger::Awake 0x2d24838
02d24838: mov     w8, #-1                                    
02d2483c: str     w8, [x0, #0x28]                            ._currentID
02d24840: ret                                                
## ChangeItem(int categoryIndex, int optionID) -> void
---- Decor.AccessoryChanger::ChangeItem 0x2d24844
02d24844: stp     x30, x23, [sp, #-0x30]!                    
02d24848: stp     x22, x21, [sp, #0x10]                      
02d2484c: stp     x20, x19, [sp, #0x20]                      
02d24850: adrp    x22, #0x6630000                            
02d24854: mov     w20, w2                                    
02d24858: mov     w21, w1                                    
02d2485c: ldrb    w8, [x22, #0x64]                           
02d24860: mov     x19, x0                                    
02d24864: tbnz    w8, #0, #0x2d24894                         
02d24868: adrp    x0, #0x6266000                             
02d2486c: ldr     x0, [x0, #0x870]                           MS:DataManager::GetAsset
02d24870: bl      #0x2b70db0                                 fn_2b70db0
02d24874: adrp    x0, #0x6266000                             
02d24878: ldr     x0, [x0, #0x658]                           MS:MonoSingleton`1::get_Instance
02d2487c: bl      #0x2b70db0                                 fn_2b70db0
02d24880: adrp    x0, #0x6266000                             
02d24884: ldr     x0, [x0, #0x880]                           MS:DG.Tweening.TweenSettingsExtensions::SetEase
02d24888: bl      #0x2b70db0                                 fn_2b70db0
02d2488c: mov     w8, #1                                     
02d24890: strb    w8, [x22, #0x64]                           
02d24894: ldr     w8, [x19, #0x28]                           ._currentID
02d24898: cmp     w8, w20                                    
02d2489c: b.ne    #0x2d248b0                                 
02d248a0: ldp     x20, x19, [sp, #0x20]                      
02d248a4: ldp     x22, x21, [sp, #0x10]                      
02d248a8: ldp     x30, x23, [sp], #0x30                      
02d248ac: ret                                                
02d248b0: adrp    x8, #0x6266000                             
02d248b4: ldr     x8, [x8, #0x658]                           MS:MonoSingleton`1::get_Instance
02d248b8: str     w20, [x19, #0x28]                          ._currentID
02d248bc: ldr     x0, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d248c0: bl      #0x3769600                                 fn_3769600
02d248c4: cbz     x0, #0x2d249f0                             
02d248c8: adrp    x8, #0x6266000                             
02d248cc: ldr     x8, [x8, #0x870]                           MS:DataManager::GetAsset
02d248d0: ldr     x1, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d248d4: bl      #0x3168af0                                 fn_3168af0
02d248d8: cbz     x0, #0x2d249f0                             
02d248dc: mov     w1, w21                                    
02d248e0: bl      #0x2d249f4                                 Decor.DecorAsset::GetCategoryAssetByIndex
02d248e4: cbz     x0, #0x2d249f0                             
02d248e8: mov     w1, w20                                    
02d248ec: bl      #0x2d24a4c                                 Decor.CategoryAsset::GetOptionDataByID
02d248f0: mov     x20, x0                                    
02d248f4: mov     x0, x19                                    
02d248f8: mov     x1, xzr                                    
02d248fc: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02d24900: mov     w1, wzr                                    
02d24904: mov     x2, xzr                                    
02d24908: bl      #0x2d9d5d0                                 DG.Tweening.ShortcutExtensions::DOKill
02d2490c: mov     x0, x19                                    
02d24910: mov     x1, xzr                                    
02d24914: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02d24918: adrp    x22, #0x662f000                            
02d2491c: mov     x21, x0                                    
02d24920: ldrb    w8, [x22, #0x91a]                          
02d24924: cbnz    w8, #0x2d2493c                             
02d24928: adrp    x0, #0x6264000                             
02d2492c: ldr     x0, [x0, #0xd8]                            T:UnityEngine.Vector3
02d24930: bl      #0x2b70db0                                 fn_2b70db0
02d24934: mov     w8, #1                                     
02d24938: strb    w8, [x22, #0x91a]                          
02d2493c: cbz     x21, #0x2d249f0                            
02d24940: adrp    x22, #0x6264000                            
02d24944: mov     x0, x21                                    
02d24948: mov     x1, xzr                                    
02d2494c: ldr     x22, [x22, #0xd8]                          T:UnityEngine.Vector3
02d24950: ldr     x8, [x22]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d24954: ldr     x8, [x8, #0xb8]                            S:'banner_native_refresh_time'
02d24958: ldp     s1, s2, [x8, #4]                           
02d2495c: ldr     s0, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d24960: bl      #0x5b470cc                                 UnityEngine.Transform::set_localScale
02d24964: mov     x0, x19                                    
02d24968: mov     x1, xzr                                    
02d2496c: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02d24970: adrp    x23, #0x662f000                            
02d24974: mov     x21, x0                                    
02d24978: ldrb    w8, [x23, #0xa74]                          
02d2497c: cbnz    w8, #0x2d24994                             
02d24980: adrp    x0, #0x6264000                             
02d24984: ldr     x0, [x0, #0xd8]                            T:UnityEngine.Vector3
02d24988: bl      #0x2b70db0                                 fn_2b70db0
02d2498c: mov     w8, #1                                     
02d24990: strb    w8, [x23, #0xa74]                          
02d24994: ldr     x8, [x22]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d24998: mov     x0, x21                                    
02d2499c: mov     x1, xzr                                    
02d249a0: ldr     x8, [x8, #0xb8]                            S:'banner_native_refresh_time'
02d249a4: ldp     s0, s1, [x8, #0xc]                         
02d249a8: ldr     s2, [x8, #0x14]                            [6266014]=0 f=0,0
02d249ac: adrp    x8, #0x1084000                             
02d249b0: ldr     s3, [x8, #0xda8]                           [1084da8]=da242603eb851ec f=0.36,1e-30
02d249b4: bl      #0x2d98af8                                 DG.Tweening.ShortcutExtensions::DOScale
02d249b8: adrp    x8, #0x6266000                             
02d249bc: mov     w1, #0x1b                                  
02d249c0: ldr     x8, [x8, #0x880]                           MS:DG.Tweening.TweenSettingsExtensions::SetEase
02d249c4: ldr     x2, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d249c8: bl      #0x336fa0c                                 fn_336fa0c
02d249cc: cbz     x20, #0x2d249f0                            
02d249d0: ldr     x0, [x19, #0x20]                           ._spriteRenderer
02d249d4: cbz     x0, #0x2d249f0                             
02d249d8: ldr     x1, [x20, #0x40]                           
02d249dc: ldp     x20, x19, [sp, #0x20]                      
02d249e0: ldp     x22, x21, [sp, #0x10]                      
02d249e4: mov     x2, xzr                                    
02d249e8: ldp     x30, x23, [sp], #0x30                      
02d249ec: b       #0x5ae6dcc                                 UnityEngine.SpriteRenderer::set_sprite
02d249f0: bl      #0x2b7105c                                 fn_2b7105c
## .ctor() -> void
---- Decor.AccessoryChanger::.ctor 0x2d24b24
02d24b24: mov     x1, xzr                                    
02d24b28: b       #0x5b397b0                                 UnityEngine.MonoBehaviour::.ctor
