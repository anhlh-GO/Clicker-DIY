#### CLASS Blindbag.MarketButton parent= UnityEngine.MonoBehaviour
#   field onClick                        UnityEngine.Events.UnityEvent                      off=0x20 attr=6 
#   field _button                        UnityEngine.UI.Button                              off=0x28 attr=1 SerializeField
#   field _onSprite                      UnityEngine.Sprite                                 off=0x30 attr=1 SerializeField
#   field _offSprite                     UnityEngine.Sprite                                 off=0x38 attr=1 SerializeField
#   field _enableToClick                 bool                                               off=0x40 attr=1 
## OnEnable() -> void
---- Blindbag.MarketButton::OnEnable 0x2d579e8
02d579e8: stp     x30, x21, [sp, #-0x20]!                    
02d579ec: stp     x20, x19, [sp, #0x10]                      
02d579f0: adrp    x20, #0x6630000                            
02d579f4: mov     x19, x0                                    
02d579f8: ldrb    w8, [x20, #0x296]                          
02d579fc: tbnz    w8, #0, #0x2d57a20                         
02d57a00: adrp    x0, #0x626b000                             
02d57a04: ldr     x0, [x0, #0xa70]                           M:Blindbag.MarketButton::OnSelectedButtonClicked
02d57a08: bl      #0x2b70db0                                 fn_2b70db0
02d57a0c: adrp    x0, #0x6265000                             
02d57a10: ldr     x0, [x0, #0x3f0]                           T:UnityEngine.Events.UnityAction
02d57a14: bl      #0x2b70db0                                 fn_2b70db0
02d57a18: mov     w8, #1                                     
02d57a1c: strb    w8, [x20, #0x296]                          
02d57a20: ldr     x8, [x19, #0x28]                           ._button
02d57a24: cbz     x8, #0x2d57a74                             
02d57a28: adrp    x9, #0x6265000                             
02d57a2c: adrp    x21, #0x626b000                            
02d57a30: ldr     x9, [x9, #0x3f0]                           T:UnityEngine.Events.UnityAction
02d57a34: ldr     x21, [x21, #0xa70]                         M:Blindbag.MarketButton::OnSelectedButtonClicked
02d57a38: ldr     x20, [x8, #0x100]                          
02d57a3c: ldr     x0, [x9]                                   M:AdsManager::<OnApplicationPause>b__26_0
02d57a40: bl      #0x2b7104c                                 fn_2b7104c
02d57a44: ldr     x2, [x21]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d57a48: mov     x1, x19                                    
02d57a4c: mov     x3, xzr                                    
02d57a50: mov     x21, x0                                    
02d57a54: bl      #0x5b4cf98                                 UnityEngine.Events.UnityAction::.ctor
02d57a58: cbz     x20, #0x2d57a74                            
02d57a5c: mov     x0, x20                                    
02d57a60: ldp     x20, x19, [sp, #0x10]                      
02d57a64: mov     x1, x21                                    
02d57a68: mov     x2, xzr                                    
02d57a6c: ldp     x30, x21, [sp], #0x20                      
02d57a70: b       #0x5b4d0ac                                 UnityEngine.Events.UnityEvent::AddListener
02d57a74: bl      #0x2b7105c                                 fn_2b7105c
## OnDisable() -> void
---- Blindbag.MarketButton::OnDisable 0x2d57a78
02d57a78: stp     x30, x21, [sp, #-0x20]!                    
02d57a7c: stp     x20, x19, [sp, #0x10]                      
02d57a80: adrp    x20, #0x6630000                            
02d57a84: mov     x19, x0                                    
02d57a88: ldrb    w8, [x20, #0x297]                          
02d57a8c: tbnz    w8, #0, #0x2d57ab0                         
02d57a90: adrp    x0, #0x626b000                             
02d57a94: ldr     x0, [x0, #0xa70]                           M:Blindbag.MarketButton::OnSelectedButtonClicked
02d57a98: bl      #0x2b70db0                                 fn_2b70db0
02d57a9c: adrp    x0, #0x6265000                             
02d57aa0: ldr     x0, [x0, #0x3f0]                           T:UnityEngine.Events.UnityAction
02d57aa4: bl      #0x2b70db0                                 fn_2b70db0
02d57aa8: mov     w8, #1                                     
02d57aac: strb    w8, [x20, #0x297]                          
02d57ab0: ldr     x8, [x19, #0x28]                           ._button
02d57ab4: cbz     x8, #0x2d57b04                             
02d57ab8: adrp    x9, #0x6265000                             
02d57abc: adrp    x21, #0x626b000                            
02d57ac0: ldr     x9, [x9, #0x3f0]                           T:UnityEngine.Events.UnityAction
02d57ac4: ldr     x21, [x21, #0xa70]                         M:Blindbag.MarketButton::OnSelectedButtonClicked
02d57ac8: ldr     x20, [x8, #0x100]                          
02d57acc: ldr     x0, [x9]                                   M:AdsManager::<OnApplicationPause>b__26_0
02d57ad0: bl      #0x2b7104c                                 fn_2b7104c
02d57ad4: ldr     x2, [x21]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d57ad8: mov     x1, x19                                    
02d57adc: mov     x3, xzr                                    
02d57ae0: mov     x21, x0                                    
02d57ae4: bl      #0x5b4cf98                                 UnityEngine.Events.UnityAction::.ctor
02d57ae8: cbz     x20, #0x2d57b04                            
02d57aec: mov     x0, x20                                    
02d57af0: ldp     x20, x19, [sp, #0x10]                      
02d57af4: mov     x1, x21                                    
02d57af8: mov     x2, xzr                                    
02d57afc: ldp     x30, x21, [sp], #0x20                      
02d57b00: b       #0x5b4d13c                                 UnityEngine.Events.UnityEvent::RemoveListener
02d57b04: bl      #0x2b7105c                                 fn_2b7105c
## OnSelectedButtonClicked() -> void
---- Blindbag.MarketButton::OnSelectedButtonClicked 0x2d57b08
02d57b08: ldrb    w8, [x0, #0x40]                            ._enableToClick
02d57b0c: cbz     w8, #0x2d57b20                             
02d57b10: ldr     x0, [x0, #0x20]                            .onClick
02d57b14: cbz     x0, #0x2d57b20                             
02d57b18: mov     x1, xzr                                    
02d57b1c: b       #0x5b4d278                                 UnityEngine.Events.UnityEvent::Invoke
02d57b20: ret                                                
## EnableState(bool value) -> void
---- Blindbag.MarketButton::EnableState 0x2d57b24
02d57b24: str     x30, [sp, #-0x20]!                         
02d57b28: stp     x20, x19, [sp, #0x10]                      
02d57b2c: mov     x19, x0                                    
02d57b30: ldr     x0, [x0, #0x28]                            ._button
02d57b34: strb    w1, [x19, #0x40]                           ._enableToClick
02d57b38: cbz     x0, #0x2d57b70                             
02d57b3c: mov     w20, w1                                    
02d57b40: mov     x1, xzr                                    
02d57b44: bl      #0x5e66470                                 UnityEngine.UI.Selectable::get_image
02d57b48: cbz     x0, #0x2d57b70                             
02d57b4c: tst     w20, #1                                    
02d57b50: mov     w8, #0x38                                  
02d57b54: mov     w9, #0x30                                  
02d57b58: csel    x8, x9, x8, ne                             
02d57b5c: mov     x2, xzr                                    
02d57b60: ldr     x1, [x19, x8]                              
02d57b64: ldp     x20, x19, [sp, #0x10]                      
02d57b68: ldr     x30, [sp], #0x20                           
02d57b6c: b       #0x5c45aa0                                 UnityEngine.UI.Image::set_sprite
02d57b70: bl      #0x2b7105c                                 fn_2b7105c
## .ctor() -> void
---- Blindbag.MarketButton::.ctor 0x2d57b74
02d57b74: mov     x1, xzr                                    
02d57b78: b       #0x5b397b0                                 UnityEngine.MonoBehaviour::.ctor
