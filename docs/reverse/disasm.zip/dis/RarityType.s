#### CLASS RarityType parent= int
#   field value__                        int                                                off=0x10 attr=606 
#   field Common                         RarityType                                         off=0x0 attr=8056 
#   field Rare                           RarityType                                         off=0x0 attr=8056 
#   field Epic                           RarityType                                         off=0x0 attr=8056 
#   field Legendary                      RarityType                                         off=0x0 attr=8056 
#   field Special                        RarityType                                         off=0x0 attr=8056 
