#### CLASS Framework.LayerMaskHelper parent= object
## Create(string[] layerNames) -> UnityEngine.LayerMask
---- Framework.LayerMaskHelper::Create 0x2cc0c64
02cc0c64: b       #0x2cb8df8                                 Framework.LayerMaskHelper::NamesToMask
## NamesToMask(string[] layerNames) -> UnityEngine.LayerMask
---- Framework.LayerMaskHelper::NamesToMask 0x2cb8df8
02cb8df8: str     x30, [sp, #-0x40]!                         
02cb8dfc: stp     x24, x23, [sp, #0x10]                      
02cb8e00: stp     x22, x21, [sp, #0x20]                      
02cb8e04: stp     x20, x19, [sp, #0x30]                      
02cb8e08: mov     x19, x0                                    
02cb8e0c: mov     w0, wzr                                    
02cb8e10: mov     x1, xzr                                    
02cb8e14: bl      #0x5b3766c                                 UnityEngine.LayerMask::op_Implicit
02cb8e18: cbz     x19, #0x2cb8e98                            
02cb8e1c: ldr     x8, [x19, #0x18]                           
02cb8e20: cmp     w8, #1                                     
02cb8e24: b.lt    #0x2cb8e80                                 
02cb8e28: mov     x22, xzr                                   
02cb8e2c: and     x8, x8, #0xffffffff                        
02cb8e30: add     x23, x19, #0x20                            
02cb8e34: mov     w24, #1                                    
02cb8e38: cmp     x22, w8, uxtw                              
02cb8e3c: b.hs    #0x2cb8e94                                 
02cb8e40: ldr     x20, [x23, x22, lsl #3]                    
02cb8e44: mov     w0, w0                                     
02cb8e48: mov     x1, xzr                                    
02cb8e4c: bl      #0x5b37668                                 UnityEngine.LayerMask::op_Implicit
02cb8e50: mov     w21, w0                                    
02cb8e54: mov     x0, x20                                    
02cb8e58: mov     x1, xzr                                    
02cb8e5c: bl      #0x5b37788                                 UnityEngine.LayerMask::NameToLayer
02cb8e60: lsl     w8, w24, w0                                
02cb8e64: mov     x1, xzr                                    
02cb8e68: orr     w0, w8, w21                                
02cb8e6c: bl      #0x5b3766c                                 UnityEngine.LayerMask::op_Implicit
02cb8e70: ldr     w8, [x19, #0x18]                           
02cb8e74: add     x22, x22, #1                               
02cb8e78: cmp     x22, w8, sxtw                              
02cb8e7c: b.lt    #0x2cb8e38                                 
02cb8e80: ldp     x20, x19, [sp, #0x30]                      
02cb8e84: ldp     x22, x21, [sp, #0x20]                      
02cb8e88: ldp     x24, x23, [sp, #0x10]                      
02cb8e8c: ldr     x30, [sp], #0x40                           
02cb8e90: ret                                                
02cb8e94: bl      #0x2b71064                                 fn_2b71064
02cb8e98: bl      #0x2b7105c                                 fn_2b7105c
## Create(int[] layerNumbers) -> UnityEngine.LayerMask
---- Framework.LayerMaskHelper::Create 0x2cc0c68
02cc0c68: b       #0x2cc0c6c                                 Framework.LayerMaskHelper::LayerNumbersToMask
## LayerNumbersToMask(int[] layerNumbers) -> UnityEngine.LayerMask
---- Framework.LayerMaskHelper::LayerNumbersToMask 0x2cc0c6c
02cc0c6c: stp     x30, x23, [sp, #-0x30]!                    
02cc0c70: stp     x22, x21, [sp, #0x10]                      
02cc0c74: stp     x20, x19, [sp, #0x20]                      
02cc0c78: mov     x19, x0                                    
02cc0c7c: mov     w0, wzr                                    
02cc0c80: mov     x1, xzr                                    
02cc0c84: bl      #0x5b3766c                                 UnityEngine.LayerMask::op_Implicit
02cc0c88: cbz     x19, #0x2cc0cf4                            
02cc0c8c: ldr     x8, [x19, #0x18]                           
02cc0c90: cmp     w8, #1                                     
02cc0c94: b.lt    #0x2cc0ce0                                 
02cc0c98: mov     x20, xzr                                   
02cc0c9c: and     x8, x8, #0xffffffff                        
02cc0ca0: add     x21, x19, #0x20                            
02cc0ca4: mov     w22, #1                                    
02cc0ca8: cmp     x20, w8, uxtw                              
02cc0cac: b.hs    #0x2cc0cf0                                 
02cc0cb0: ldr     w23, [x21, x20, lsl #2]                    
02cc0cb4: mov     w0, w0                                     
02cc0cb8: mov     x1, xzr                                    
02cc0cbc: bl      #0x5b37668                                 UnityEngine.LayerMask::op_Implicit
02cc0cc0: lsl     w8, w22, w23                               
02cc0cc4: mov     x1, xzr                                    
02cc0cc8: orr     w0, w8, w0                                 
02cc0ccc: bl      #0x5b3766c                                 UnityEngine.LayerMask::op_Implicit
02cc0cd0: ldr     w8, [x19, #0x18]                           
02cc0cd4: add     x20, x20, #1                               
02cc0cd8: cmp     x20, w8, sxtw                              
02cc0cdc: b.lt    #0x2cc0ca8                                 
02cc0ce0: ldp     x20, x19, [sp, #0x20]                      
02cc0ce4: ldp     x22, x21, [sp, #0x10]                      
02cc0ce8: ldp     x30, x23, [sp], #0x30                      
02cc0cec: ret                                                
02cc0cf0: bl      #0x2b71064                                 fn_2b71064
02cc0cf4: bl      #0x2b7105c                                 fn_2b7105c
