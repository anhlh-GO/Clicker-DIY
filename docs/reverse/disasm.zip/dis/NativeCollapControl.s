#### CLASS NativeCollapControl/<>c parent= object
#   field <>9                            NativeCollapControl/<>c                            off=0x0 attr=36 
#   field <>9__18_1                      System.Action                                      off=0x8 attr=16 
#   field <>9__18_2                      System.Action`4<string,string,double,string>       off=0x10 attr=16 
## .cctor() -> void
---- NativeCollapControl/<>c::.cctor 0x2c9924c
02c9924c: str     x30, [sp, #-0x20]!                         
02c99250: stp     x20, x19, [sp, #0x10]                      
02c99254: adrp    x19, #0x662f000                            
02c99258: adrp    x20, #0x6265000                            
02c9925c: ldrb    w8, [x19, #0xa29]                          
02c99260: ldr     x20, [x20, #0x998]                         T:NativeCollapControl/<>c
02c99264: tbnz    w8, #0, #0x2c9927c                         
02c99268: adrp    x0, #0x6265000                             
02c9926c: ldr     x0, [x0, #0x998]                           T:NativeCollapControl/<>c
02c99270: bl      #0x2b70db0                                 fn_2b70db0
02c99274: mov     w8, #1                                     
02c99278: strb    w8, [x19, #0xa29]                          
02c9927c: ldr     x0, [x20]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c99280: bl      #0x2b7104c                                 fn_2b7104c
02c99284: mov     x1, xzr                                    
02c99288: mov     x19, x0                                    
02c9928c: bl      #0x4e53e9c                                 System.Object::.ctor
02c99290: ldr     x8, [x20]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c99294: mov     x1, x19                                    
02c99298: ldr     x8, [x8, #0xb8]                            
02c9929c: str     x19, [x8]                                  
02c992a0: ldr     x8, [x20]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c992a4: ldp     x20, x19, [sp, #0x10]                      
02c992a8: ldr     x0, [x8, #0xb8]                            
02c992ac: ldr     x30, [sp], #0x20                           
02c992b0: b       #0x2b70d54                                 
## .ctor() -> void
---- NativeCollapControl/<>c::.ctor 0x2c992b4
02c992b4: mov     x1, xzr                                    
02c992b8: b       #0x4e53e9c                                 System.Object::.ctor
## <RegisterListener>b__18_1() -> void
---- NativeCollapControl/<>c::<RegisterListener>b__18_1 0x2c992bc
02c992bc: ret                                                
## <RegisterListener>b__18_2(string adSource, string adUnitId, double valueMicros, string currencyCode) -> void
---- NativeCollapControl/<>c::<RegisterListener>b__18_2 0x2c992c0
02c992c0: str     d8, [sp, #-0x50]!                          
02c992c4: stp     x30, x25, [sp, #0x10]                      
02c992c8: stp     x24, x23, [sp, #0x20]                      
02c992cc: stp     x22, x21, [sp, #0x30]                      
02c992d0: stp     x20, x19, [sp, #0x40]                      
02c992d4: fmov    d8, d0                                     
02c992d8: adrp    x23, #0x662f000                            
02c992dc: adrp    x24, #0x6265000                            
02c992e0: adrp    x22, #0x6265000                            
02c992e4: ldrb    w8, [x23, #0xa2a]                          
02c992e8: ldr     x24, [x24, #0x2e8]                         T:type8944(k15)
02c992ec: ldr     x22, [x22, #0x2e0]                         MS:System.Collections.Generic.Dictionary`2::.ctor
02c992f0: mov     x19, x3                                    
02c992f4: mov     x20, x2                                    
02c992f8: mov     x21, x1                                    
02c992fc: tbnz    w8, #0, #0x2c99350                         
02c99300: adrp    x0, #0x6265000                             
02c99304: ldr     x0, [x0, #0x2d8]                           MS:System.Collections.Generic.Dictionary`2::Add
02c99308: bl      #0x2b70db0                                 fn_2b70db0
02c9930c: adrp    x0, #0x6265000                             
02c99310: ldr     x0, [x0, #0x2e0]                           MS:System.Collections.Generic.Dictionary`2::.ctor
02c99314: bl      #0x2b70db0                                 fn_2b70db0
02c99318: adrp    x0, #0x6265000                             
02c9931c: ldr     x0, [x0, #0x2e8]                           T:type8944(k15)
02c99320: bl      #0x2b70db0                                 fn_2b70db0
02c99324: adrp    x0, #0x6265000                             
02c99328: ldr     x0, [x0, #0x280]                           S:'ad_unit_name'
02c9932c: bl      #0x2b70db0                                 fn_2b70db0
02c99330: adrp    x0, #0x6265000                             
02c99334: ldr     x0, [x0, #0x2a8]                           S:'ad_source'
02c99338: bl      #0x2b70db0                                 fn_2b70db0
02c9933c: adrp    x0, #0x6265000                             
02c99340: ldr     x0, [x0, #0x2b0]                           S:'currency'
02c99344: bl      #0x2b70db0                                 fn_2b70db0
02c99348: mov     w8, #1                                     
02c9934c: strb    w8, [x23, #0xa2a]                          
02c99350: ldr     x0, [x24]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c99354: bl      #0x2b7104c                                 fn_2b7104c
02c99358: ldr     x1, [x22]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9935c: mov     x22, x0                                    
02c99360: bl      #0x452b8a0                                 fn_452b8a0
02c99364: cbz     x22, #0x2c993f8                            
02c99368: adrp    x8, #0x6265000                             
02c9936c: adrp    x23, #0x6265000                            
02c99370: adrp    x24, #0x6265000                            
02c99374: ldr     x8, [x8, #0x2a8]                           S:'ad_source'
02c99378: ldr     x23, [x23, #0x2d8]                         MS:System.Collections.Generic.Dictionary`2::Add
02c9937c: adrp    x25, #0x6265000                            
02c99380: ldr     x24, [x24, #0x280]                         S:'ad_unit_name'
02c99384: ldr     x25, [x25, #0x2b0]                         S:'currency'
02c99388: mov     x0, x22                                    
02c9938c: ldr     x1, [x8]                                   M:AdsManager::<OnApplicationPause>b__26_0
02c99390: ldr     x3, [x23]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c99394: mov     x2, x21                                    
02c99398: bl      #0x452c61c                                 fn_452c61c
02c9939c: ldr     x1, [x24]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c993a0: ldr     x3, [x23]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c993a4: mov     x0, x22                                    
02c993a8: mov     x2, x20                                    
02c993ac: bl      #0x452c61c                                 fn_452c61c
02c993b0: ldr     x1, [x25]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c993b4: ldr     x3, [x23]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c993b8: mov     x0, x22                                    
02c993bc: mov     x2, x19                                    
02c993c0: bl      #0x452c61c                                 fn_452c61c
02c993c4: fmov    d0, d8                                     
02c993c8: mov     x0, x22                                    
02c993cc: mov     w1, #0xa                                   
02c993d0: bl      #0x2c993fc                                 AnalyticsManager::LogAppsflyerAdmobRevenue
02c993d4: mov     x0, x22                                    
02c993d8: ldp     x20, x19, [sp, #0x40]                      
02c993dc: ldp     x22, x21, [sp, #0x30]                      
02c993e0: mov     w1, #0xa                                   
02c993e4: ldp     x24, x23, [sp, #0x20]                      
02c993e8: fmov    d0, d8                                     
02c993ec: ldp     x30, x25, [sp, #0x10]                      
02c993f0: ldr     d8, [sp], #0x50                            
02c993f4: b       #0x2c996c8                                 AnalyticsManager::LogFirebaseAdmobRevenue
02c993f8: bl      #0x2b7105c                                 fn_2b7105c
#### CLASS NativeCollapControl/<>c__DisplayClass20_0 parent= object
#   field <>4__this                      NativeCollapControl                                off=0x10 attr=6 
#   field onAdClosed                     System.Action                                      off=0x18 attr=6 
## .ctor() -> void
---- NativeCollapControl/<>c__DisplayClass20_0::.ctor 0x2c98f28
02c98f28: mov     x1, xzr                                    
02c98f2c: b       #0x4e53e9c                                 System.Object::.ctor
## <ShowAd>b__0(string errorMessage) -> void
---- NativeCollapControl/<>c__DisplayClass20_0::<ShowAd>b__0 0x2c99b4c
02c99b4c: stp     x30, x21, [sp, #-0x20]!                    
02c99b50: stp     x20, x19, [sp, #0x10]                      
02c99b54: adrp    x21, #0x662f000                            
02c99b58: mov     x20, x1                                    
02c99b5c: mov     x19, x0                                    
02c99b60: ldrb    w8, [x21, #0xa2b]                          
02c99b64: tbnz    w8, #0, #0x2c99b94                         
02c99b68: adrp    x0, #0x6263000                             
02c99b6c: ldr     x0, [x0, #0x928]                           T:UnityEngine.Debug
02c99b70: bl      #0x2b70db0                                 fn_2b70db0
02c99b74: adrp    x0, #0x6265000                             
02c99b78: ldr     x0, [x0, #0x9c0]                           S:'] ShowAd callback. error='
02c99b7c: bl      #0x2b70db0                                 fn_2b70db0
02c99b80: adrp    x0, #0x6265000                             
02c99b84: ldr     x0, [x0, #0x5d8]                           S:'[NativeCollapControl '
02c99b88: bl      #0x2b70db0                                 fn_2b70db0
02c99b8c: mov     w8, #1                                     
02c99b90: strb    w8, [x21, #0xa2b]                          
02c99b94: ldr     x8, [x19, #0x10]                           .<>4__this
02c99b98: cbz     x8, #0x2c99c04                             
02c99b9c: adrp    x9, #0x6265000                             
02c99ba0: adrp    x10, #0x6265000                            
02c99ba4: adrp    x21, #0x6263000                            
02c99ba8: ldr     x9, [x9, #0x5d8]                           S:'[NativeCollapControl '
02c99bac: ldr     x10, [x10, #0x9c0]                         S:'] ShowAd callback. error='
02c99bb0: ldr     x21, [x21, #0x928]                         T:UnityEngine.Debug
02c99bb4: ldr     x1, [x8, #0x30]                            
02c99bb8: mov     x3, x20                                    
02c99bbc: mov     x4, xzr                                    
02c99bc0: ldr     x0, [x9]                                   M:AdsManager::<OnApplicationPause>b__26_0
02c99bc4: ldr     x2, [x10]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c99bc8: bl      #0x4ca7320                                 System.String::Concat
02c99bcc: ldr     x8, [x21]                                  &2c5bbd4(=a9bd7bfdd503233f)
02c99bd0: mov     x20, x0                                    
02c99bd4: ldr     w9, [x8, #0xe4]                            
02c99bd8: cbnz    w9, #0x2c99be4                             
02c99bdc: mov     x0, x8                                     
02c99be0: bl      #0x2b70f30                                 fn_2b70f30
02c99be4: mov     x0, x20                                    
02c99be8: mov     x1, xzr                                    
02c99bec: bl      #0x5af21f4                                 UnityEngine.Debug::Log
02c99bf0: ldr     x0, [x19, #0x10]                           .<>4__this
02c99bf4: cbz     x0, #0x2c99c04                             
02c99bf8: ldp     x20, x19, [sp, #0x10]                      
02c99bfc: ldp     x30, x21, [sp], #0x20                      
02c99c00: b       #0x2c98ef0                                 NativeCollapControl::HandleAdDismissed
02c99c04: bl      #0x2b7105c                                 fn_2b7105c
## <ShowAd>b__1(string errorMessage) -> void
---- NativeCollapControl/<>c__DisplayClass20_0::<ShowAd>b__1 0x2c99c08
02c99c08: stp     x30, x21, [sp, #-0x20]!                    
02c99c0c: stp     x20, x19, [sp, #0x10]                      
02c99c10: adrp    x21, #0x662f000                            
02c99c14: mov     x20, x1                                    
02c99c18: mov     x19, x0                                    
02c99c1c: ldrb    w8, [x21, #0xa2c]                          
02c99c20: tbnz    w8, #0, #0x2c99c50                         
02c99c24: adrp    x0, #0x6263000                             
02c99c28: ldr     x0, [x0, #0x928]                           T:UnityEngine.Debug
02c99c2c: bl      #0x2b70db0                                 fn_2b70db0
02c99c30: adrp    x0, #0x6265000                             
02c99c34: ldr     x0, [x0, #0x9c8]                           S:'] ShowAd close callback. error='
02c99c38: bl      #0x2b70db0                                 fn_2b70db0
02c99c3c: adrp    x0, #0x6265000                             
02c99c40: ldr     x0, [x0, #0x5d8]                           S:'[NativeCollapControl '
02c99c44: bl      #0x2b70db0                                 fn_2b70db0
02c99c48: mov     w8, #1                                     
02c99c4c: strb    w8, [x21, #0xa2c]                          
02c99c50: ldr     x8, [x19, #0x10]                           .<>4__this
02c99c54: cbz     x8, #0x2c99ce4                             
02c99c58: adrp    x9, #0x6265000                             
02c99c5c: adrp    x10, #0x6265000                            
02c99c60: adrp    x21, #0x6263000                            
02c99c64: ldr     x9, [x9, #0x5d8]                           S:'[NativeCollapControl '
02c99c68: ldr     x10, [x10, #0x9c8]                         S:'] ShowAd close callback. error='
02c99c6c: ldr     x21, [x21, #0x928]                         T:UnityEngine.Debug
02c99c70: ldr     x1, [x8, #0x30]                            
02c99c74: mov     x3, x20                                    
02c99c78: mov     x4, xzr                                    
02c99c7c: ldr     x0, [x9]                                   M:AdsManager::<OnApplicationPause>b__26_0
02c99c80: ldr     x2, [x10]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c99c84: bl      #0x4ca7320                                 System.String::Concat
02c99c88: ldr     x8, [x21]                                  &2c5bbd4(=a9bd7bfdd503233f)
02c99c8c: mov     x20, x0                                    
02c99c90: ldr     w9, [x8, #0xe4]                            
02c99c94: cbnz    w9, #0x2c99ca0                             
02c99c98: mov     x0, x8                                     
02c99c9c: bl      #0x2b70f30                                 fn_2b70f30
02c99ca0: mov     x0, x20                                    
02c99ca4: mov     x1, xzr                                    
02c99ca8: bl      #0x5af21f4                                 UnityEngine.Debug::Log
02c99cac: ldr     x0, [x19, #0x10]                           .<>4__this
02c99cb0: cbz     x0, #0x2c99ce4                             
02c99cb4: bl      #0x2c98ef0                                 NativeCollapControl::HandleAdDismissed
02c99cb8: ldr     x8, [x19, #0x18]                           .onAdClosed
02c99cbc: cbz     x8, #0x2c99cd8                             
02c99cc0: ldp     x20, x19, [sp, #0x10]                      
02c99cc4: ldr     x0, [x8, #0x40]                            
02c99cc8: ldr     x1, [x8, #0x28]                            
02c99ccc: ldr     x2, [x8, #0x18]                            
02c99cd0: ldp     x30, x21, [sp], #0x20                      
02c99cd4: br      x2                                         
02c99cd8: ldp     x20, x19, [sp, #0x10]                      
02c99cdc: ldp     x30, x21, [sp], #0x20                      
02c99ce0: ret                                                
02c99ce4: bl      #0x2b7105c                                 fn_2b7105c
#### CLASS NativeCollapControl/<ReloadCoroutine>d__23 parent= object
#   field <>1__state                     int                                                off=0x10 attr=1 
#   field <>2__current                   object                                             off=0x18 attr=1 
#   field <>4__this                      NativeCollapControl                                off=0x20 attr=6 
## .ctor(int <>1__state) -> void
---- NativeCollapControl/<ReloadCoroutine>d__23::.ctor 0x2c98ff8
02c98ff8: str     x30, [sp, #-0x20]!                         
02c98ffc: stp     x20, x19, [sp, #0x10]                      
02c99000: mov     w19, w1                                    
02c99004: mov     x1, xzr                                    
02c99008: mov     x20, x0                                    
02c9900c: bl      #0x4e53e9c                                 System.Object::.ctor
02c99010: str     w19, [x20, #0x10]                          .<>1__state
02c99014: ldp     x20, x19, [sp, #0x10]                      
02c99018: ldr     x30, [sp], #0x20                           
02c9901c: ret                                                
## System.IDisposable.Dispose() -> void
---- NativeCollapControl/<ReloadCoroutine>d__23::System.IDisposable.Dispose 0x2c99ce8
02c99ce8: ret                                                
## MoveNext() -> bool
---- NativeCollapControl/<ReloadCoroutine>d__23::MoveNext 0x2c99cec
02c99cec: str     d8, [sp, #-0x20]!                          
02c99cf0: str     x30, [sp, #8]                              
02c99cf4: stp     x20, x19, [sp, #0x10]                      
02c99cf8: adrp    x20, #0x662f000                            
02c99cfc: mov     x19, x0                                    
02c99d00: ldrb    w8, [x20, #0xa2d]                          
02c99d04: tbnz    w8, #0, #0x2c99d1c                         
02c99d08: adrp    x0, #0x6264000                             
02c99d0c: ldr     x0, [x0, #0xf58]                           T:UnityEngine.WaitForSeconds
02c99d10: bl      #0x2b70db0                                 fn_2b70db0
02c99d14: mov     w8, #1                                     
02c99d18: strb    w8, [x20, #0xa2d]                          
02c99d1c: ldr     w8, [x19, #0x10]                           .<>1__state
02c99d20: ldr     x20, [x19, #0x20]                          .<>4__this
02c99d24: cmp     w8, #1                                     
02c99d28: b.eq    #0x2c99d90                                 
02c99d2c: cbnz    w8, #0x2c99df4                             
02c99d30: mov     w8, #-1                                    
02c99d34: str     w8, [x19, #0x10]                           .<>1__state
02c99d38: cbz     x20, #0x2c99e08                            
02c99d3c: ldp     w0, w8, [x20, #0x38]                       
02c99d40: cmp     w0, w8                                     
02c99d44: b.ge    #0x2c99de4                                 
02c99d48: fmov    s0, #1.00000000                            
02c99d4c: bl      #0x5e902b0                                 fn_5e902b0
02c99d50: adrp    x8, #0x6264000                             
02c99d54: fadd    s8, s0, s0                                 
02c99d58: ldr     x8, [x8, #0xf58]                           T:UnityEngine.WaitForSeconds
02c99d5c: ldr     x0, [x8]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c99d60: bl      #0x2b7104c                                 fn_2b7104c
02c99d64: fmov    s0, s8                                     
02c99d68: mov     x1, xzr                                    
02c99d6c: mov     x20, x0                                    
02c99d70: bl      #0x5b3e5e8                                 UnityEngine.WaitForSeconds::.ctor
02c99d74: str     x20, [x19, #0x18]!                         .<>2__current
02c99d78: mov     x0, x19                                    
02c99d7c: mov     x1, x20                                    
02c99d80: bl      #0x2b70d54                                 fn_2b70d54
02c99d84: mov     w0, #1                                     
02c99d88: stur    w0, [x19, #-8]                             
02c99d8c: b       #0x2c99df8                                 
02c99d90: mov     w8, #-1                                    
02c99d94: str     w8, [x19, #0x10]                           .<>1__state
02c99d98: cbz     x20, #0x2c99e08                            
02c99d9c: mov     x19, x20                                   
02c99da0: mov     x1, xzr                                    
02c99da4: str     xzr, [x19, #0x40]!                         
02c99da8: mov     x0, x19                                    
02c99dac: bl      #0x2b70d54                                 fn_2b70d54
02c99db0: ldur    w8, [x19, #-8]                             
02c99db4: add     w8, w8, #1                                 
02c99db8: stur    w8, [x19, #-8]                             
02c99dbc: bl      #0x2c98a20                                 NativeCollapControl::get_IsEnabled
02c99dc0: tbz     w0, #0, #0x2c99df4                         
02c99dc4: ldr     x0, [x20, #0x20]                           &2b706f0(=d65f03c0f9400800) .<>4__this
02c99dc8: cbz     x0, #0x2c99dd4                             
02c99dcc: bl      #0x2c9575c                                 FsnCollapAd::IsAdReady
02c99dd0: tbnz    w0, #0, #0x2c99df4                         
02c99dd4: ldr     x1, [x20, #0x28]                           [662f028]=6000015 f=2.40742e-35,0
02c99dd8: mov     x0, x20                                    
02c99ddc: bl      #0x2c98ad0                                 NativeCollapControl::LoadCollapAd
02c99de0: b       #0x2c99df4                                 
02c99de4: str     xzr, [x20, #0x40]!                         
02c99de8: mov     x0, x20                                    
02c99dec: mov     x1, xzr                                    
02c99df0: bl      #0x2b70d54                                 fn_2b70d54
02c99df4: mov     w0, wzr                                    
02c99df8: ldp     x20, x19, [sp, #0x10]                      
02c99dfc: ldr     x30, [sp, #8]                              
02c99e00: ldr     d8, [sp], #0x20                            
02c99e04: ret                                                
02c99e08: bl      #0x2b7105c                                 fn_2b7105c
## System.Collections.Generic.IEnumerator<System.Object>.get_Current() -> object
---- NativeCollapControl/<ReloadCoroutine>d__23::System.Collections.Generic.IEnumerator<System.Object>.get_Current 0x2c99e0c
02c99e0c: ldr     x0, [x0, #0x18]                            .<>2__current
02c99e10: ret                                                
## System.Collections.IEnumerator.Reset() -> void
---- NativeCollapControl/<ReloadCoroutine>d__23::System.Collections.IEnumerator.Reset 0x2c99e14
02c99e14: stp     x30, x19, [sp, #-0x10]!                    
02c99e18: adrp    x0, #0x6264000                             
02c99e1c: ldr     x0, [x0, #0xf60]                           T:System.NotSupportedException
02c99e20: bl      #0x2b70dc4                                 fn_2b70dc4
02c99e24: bl      #0x2b7104c                                 fn_2b7104c
02c99e28: mov     x1, xzr                                    
02c99e2c: mov     x19, x0                                    
02c99e30: bl      #0x4e14238                                 System.NotSupportedException::.ctor
02c99e34: adrp    x0, #0x6265000                             
02c99e38: ldr     x0, [x0, #0x9d0]                           M:NativeCollapControl/<ReloadCoroutine>d__23::System.Collections.IEnumerator.Reset
02c99e3c: bl      #0x2b70dc4                                 fn_2b70dc4
02c99e40: mov     x1, x0                                     
02c99e44: mov     x0, x19                                    
02c99e48: bl      #0x2b70f20                                 fn_2b70f20
## System.Collections.IEnumerator.get_Current() -> object
---- NativeCollapControl/<ReloadCoroutine>d__23::System.Collections.IEnumerator.get_Current 0x2c99e4c
02c99e4c: ldr     x0, [x0, #0x18]                            .<>2__current
02c99e50: ret                                                
#### CLASS NativeCollapControl parent= UnityEngine.MonoBehaviour
#   field _primaryAd                     FsnCollapAd                                        off=0x20 attr=1 
#   field _adID                          string                                             off=0x28 attr=1 
#   field _logTag                        string                                             off=0x30 attr=1 
#   field _retryAttempt                  int                                                off=0x38 attr=1 
#   field _maxRetryAttempts              int                                                off=0x3c attr=21 
#   field _reloadCoroutine               UnityEngine.Coroutine                              off=0x40 attr=1 
#   field _isShowing                     bool                                               off=0x48 attr=1 
#   field _actionClose                   System.Action                                      off=0x50 attr=1 
## get_IsEnabled() -> bool
---- NativeCollapControl::get_IsEnabled 0x2c98a20
02c98a20: str     x30, [sp, #-0x20]!                         
02c98a24: stp     x20, x19, [sp, #0x10]                      
02c98a28: adrp    x20, #0x662f000                            
02c98a2c: adrp    x19, #0x6264000                            
02c98a30: ldrb    w8, [x20, #0xa1f]                          
02c98a34: ldr     x19, [x19, #0xfc0]                         T:RemoteConfigManager
02c98a38: tbnz    w8, #0, #0x2c98a50                         
02c98a3c: adrp    x0, #0x6264000                             
02c98a40: ldr     x0, [x0, #0xfc0]                           T:RemoteConfigManager
02c98a44: bl      #0x2b70db0                                 fn_2b70db0
02c98a48: mov     w8, #1                                     
02c98a4c: strb    w8, [x20, #0xa1f]                          
02c98a50: ldr     x0, [x19]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c98a54: ldr     w8, [x0, #0xe4]                            [62640e4]=0 f=0,0
02c98a58: cbnz    w8, #0x2c98a60                             
02c98a5c: bl      #0x2b70f30                                 fn_2b70f30
02c98a60: adrp    x20, #0x662f000                            
02c98a64: ldrb    w8, [x20, #0xa88]                          
02c98a68: cbnz    w8, #0x2c98a80                             
02c98a6c: adrp    x0, #0x6264000                             
02c98a70: ldr     x0, [x0, #0xfc0]                           T:RemoteConfigManager
02c98a74: bl      #0x2b70db0                                 fn_2b70db0
02c98a78: mov     w8, #1                                     
02c98a7c: strb    w8, [x20, #0xa88]                          
02c98a80: ldr     x0, [x19]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c98a84: ldr     w8, [x0, #0xe4]                            [62640e4]=0 f=0,0
02c98a88: cbnz    w8, #0x2c98a94                             
02c98a8c: bl      #0x2b70f30                                 fn_2b70f30
02c98a90: ldr     x0, [x19]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c98a94: ldr     x8, [x0, #0xb8]                            MS:DG.Tweening.Core.Extensions::SetSpecialStartupMode
02c98a98: ldp     x20, x19, [sp, #0x10]                      
02c98a9c: ldrb    w0, [x8, #0x3a]                            
02c98aa0: ldr     x30, [sp], #0x20                           
02c98aa4: ret                                                
## get_IsReady() -> bool
---- NativeCollapControl::get_IsReady 0x2c98aa8
02c98aa8: ldr     x0, [x0, #0x20]                            ._primaryAd
02c98aac: cbz     x0, #0x2c98ab4                             
02c98ab0: b       #0x2c9575c                                 FsnCollapAd::IsAdReady
02c98ab4: ret                                                
## get_NativeLoaded() -> bool
---- NativeCollapControl::get_NativeLoaded 0x2c98ab8
02c98ab8: ldr     x0, [x0, #0x20]                            ._primaryAd
02c98abc: cbz     x0, #0x2c98ac4                             
02c98ac0: b       #0x2c9575c                                 FsnCollapAd::IsAdReady
02c98ac4: ret                                                
## get_IsShowing() -> bool
---- NativeCollapControl::get_IsShowing 0x2c98ac8
02c98ac8: ldrb    w0, [x0, #0x48]                            ._isShowing
02c98acc: ret                                                
## LoadAd(string adID, string logTag) -> void
---- NativeCollapControl::LoadAd 0x2c92654
02c92654: stp     x30, x23, [sp, #-0x30]!                    
02c92658: stp     x22, x21, [sp, #0x10]                      
02c9265c: stp     x20, x19, [sp, #0x20]                      
02c92660: adrp    x21, #0x662f000                            
02c92664: mov     x20, x2                                    
02c92668: mov     x22, x1                                    
02c9266c: ldrb    w8, [x21, #0xa20]                          
02c92670: mov     x19, x0                                    
02c92674: tbnz    w8, #0, #0x2c92698                         
02c92678: adrp    x0, #0x6265000                             
02c9267c: ldr     x0, [x0, #0x488]                           T:KeyTest
02c92680: bl      #0x2b70db0                                 fn_2b70db0
02c92684: adrp    x0, #0x6265000                             
02c92688: ldr     x0, [x0, #0x310]                           MS:WejoyService.Singleton`1::get_Instance
02c9268c: bl      #0x2b70db0                                 fn_2b70db0
02c92690: mov     w8, #1                                     
02c92694: strb    w8, [x21, #0xa20]                          
02c92698: mov     x0, x22                                    
02c9269c: mov     x1, xzr                                    
02c926a0: bl      #0x4ca6234                                 System.String::IsNullOrEmpty
02c926a4: tbz     w0, #0, #0x2c926b4                         
02c926a8: mov     w0, #0xa                                   
02c926ac: bl      #0x2c8de38                                 KeyAds::Get
02c926b0: mov     x22, x0                                    
02c926b4: cbz     x19, #0x2c92744                            
02c926b8: adrp    x23, #0x6265000                            
02c926bc: mov     x21, x19                                   
02c926c0: mov     x1, x22                                    
02c926c4: ldr     x23, [x23, #0x310]                         MS:WejoyService.Singleton`1::get_Instance
02c926c8: str     x22, [x21, #0x28]!                         ._adID
02c926cc: mov     x0, x21                                    
02c926d0: bl      #0x2b70d54                                 fn_2b70d54
02c926d4: ldr     x0, [x23]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c926d8: bl      #0x3be7218                                 fn_3be7218
02c926dc: cbz     x0, #0x2c92744                             
02c926e0: ldrb    w8, [x0, #0x31]                            
02c926e4: cbz     w8, #0x2c92718                             
02c926e8: adrp    x22, #0x6265000                            
02c926ec: ldr     x22, [x22, #0x488]                         T:KeyTest
02c926f0: ldr     x0, [x22]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c926f4: ldr     w8, [x0, #0xe4]                            [62650e4]=0 f=0,0
02c926f8: cbnz    w8, #0x2c92704                             
02c926fc: bl      #0x2b70f30                                 fn_2b70f30
02c92700: ldr     x0, [x22]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c92704: ldr     x8, [x0, #0xb8]                            T:AdsManager/<>c__DisplayClass42_0
02c92708: mov     x0, x21                                    
02c9270c: ldr     x1, [x8, #0x20]                            
02c92710: str     x1, [x21]                                  
02c92714: bl      #0x2b70d54                                 fn_2b70d54
02c92718: mov     x0, x19                                    
02c9271c: mov     x1, x20                                    
02c92720: str     x20, [x0, #0x30]!                          ._logTag
02c92724: bl      #0x2b70d54                                 fn_2b70d54
02c92728: ldr     x1, [x19, #0x28]                           ._adID
02c9272c: mov     x0, x19                                    
02c92730: str     wzr, [x19, #0x38]                          ._retryAttempt
02c92734: ldp     x20, x19, [sp, #0x20]                      
02c92738: ldp     x22, x21, [sp, #0x10]                      
02c9273c: ldp     x30, x23, [sp], #0x30                      
02c92740: b       #0x2c98ad0                                 NativeCollapControl::LoadCollapAd
02c92744: bl      #0x2b7105c                                 fn_2b7105c
## LoadCollapAd(string adID) -> void
---- NativeCollapControl::LoadCollapAd 0x2c98ad0
02c98ad0: str     x30, [sp, #-0x30]!                         
02c98ad4: stp     x22, x21, [sp, #0x10]                      
02c98ad8: stp     x20, x19, [sp, #0x20]                      
02c98adc: adrp    x21, #0x662f000                            
02c98ae0: mov     x19, x1                                    
02c98ae4: mov     x20, x0                                    
02c98ae8: ldrb    w8, [x21, #0xa21]                          
02c98aec: tbnz    w8, #0, #0x2c98b34                         
02c98af0: adrp    x0, #0x6263000                             
02c98af4: ldr     x0, [x0, #0x928]                           T:UnityEngine.Debug
02c98af8: bl      #0x2b70db0                                 fn_2b70db0
02c98afc: adrp    x0, #0x6265000                             
02c98b00: ldr     x0, [x0, #0x960]                           T:FsnCollapAd
02c98b04: bl      #0x2b70db0                                 fn_2b70db0
02c98b08: adrp    x0, #0x6265000                             
02c98b0c: ldr     x0, [x0, #0x968]                           S:'] LoadCollapAd skipped: already ready or loading.'
02c98b10: bl      #0x2b70db0                                 fn_2b70db0
02c98b14: adrp    x0, #0x6265000                             
02c98b18: ldr     x0, [x0, #0x5d8]                           S:'[NativeCollapControl '
02c98b1c: bl      #0x2b70db0                                 fn_2b70db0
02c98b20: adrp    x0, #0x6265000                             
02c98b24: ldr     x0, [x0, #0x970]                           S:'] Load request sent for AdID: '
02c98b28: bl      #0x2b70db0                                 fn_2b70db0
02c98b2c: mov     w8, #1                                     
02c98b30: strb    w8, [x21, #0xa21]                          
02c98b34: bl      #0x2c98a20                                 NativeCollapControl::get_IsEnabled
02c98b38: tbz     w0, #0, #0x2c98b88                         
02c98b3c: mov     x21, x20                                   
02c98b40: ldr     x0, [x21, #0x20]!                          &2b706f0(=d65f03c0f9400800) ._primaryAd
02c98b44: cbz     x0, #0x2c98b98                             
02c98b48: bl      #0x2c9575c                                 FsnCollapAd::IsAdReady
02c98b4c: tbnz    w0, #0, #0x2c98b60                         
02c98b50: ldr     x0, [x21]                                  &2b706c4(=eb01011ff9400808)
02c98b54: cbz     x0, #0x2c98b98                             
02c98b58: bl      #0x2c95840                                 FsnCollapAd::IsAdLoading
02c98b5c: tbz     w0, #0, #0x2c98b98                         
02c98b60: adrp    x8, #0x6265000                             
02c98b64: adrp    x9, #0x6265000                             
02c98b68: mov     x3, xzr                                    
02c98b6c: ldr     x8, [x8, #0x5d8]                           S:'[NativeCollapControl '
02c98b70: ldr     x9, [x9, #0x968]                           S:'] LoadCollapAd skipped: already ready or loading.'
02c98b74: ldr     x1, [x20, #0x30]                           ._logTag
02c98b78: ldr     x0, [x8]                                   M:AdsManager::<OnApplicationPause>b__26_0
02c98b7c: ldr     x2, [x9]                                   M:AdsManager::<OnApplicationPause>b__26_0
02c98b80: bl      #0x4ca6dbc                                 System.String::Concat
02c98b84: b       #0x2c98c34                                 
02c98b88: ldp     x20, x19, [sp, #0x20]                      
02c98b8c: ldp     x22, x21, [sp, #0x10]                      
02c98b90: ldr     x30, [sp], #0x30                           
02c98b94: ret                                                
02c98b98: mov     x0, x20                                    
02c98b9c: bl      #0x2c98c70                                 NativeCollapControl::StopReloadCoroutine
02c98ba0: ldr     x0, [x20, #0x20]                           ._primaryAd
02c98ba4: cbz     x0, #0x2c98bac                             
02c98ba8: bl      #0x2c95924                                 FsnCollapAd::Release
02c98bac: adrp    x8, #0x6265000                             
02c98bb0: ldr     x8, [x8, #0x960]                           T:FsnCollapAd
02c98bb4: ldr     x0, [x8]                                   M:AdsManager::<OnApplicationPause>b__26_0
02c98bb8: bl      #0x2b7104c                                 fn_2b7104c
02c98bbc: mov     x22, x0                                    
02c98bc0: bl      #0x2c94894                                 FsnCollapAd::.ctor
02c98bc4: mov     x0, x21                                    
02c98bc8: mov     x1, x22                                    
02c98bcc: str     x22, [x21]                                 
02c98bd0: bl      #0x2b70d54                                 fn_2b70d54
02c98bd4: ldr     x0, [x21]                                  &2b706c4(=eb01011ff9400808)
02c98bd8: cbz     x0, #0x2c98c6c                             
02c98bdc: mov     x1, x19                                    
02c98be0: mov     w2, wzr                                    
02c98be4: mov     w3, #1                                     
02c98be8: mov     w4, #1                                     
02c98bec: mov     w5, wzr                                    
02c98bf0: bl      #0x2c949d4                                 FsnCollapAd::Init
02c98bf4: ldr     x1, [x20, #0x20]                           ._primaryAd
02c98bf8: mov     x0, x20                                    
02c98bfc: bl      #0x2c98cb4                                 NativeCollapControl::RegisterListener
02c98c00: ldr     x0, [x20, #0x20]                           ._primaryAd
02c98c04: cbz     x0, #0x2c98c6c                             
02c98c08: bl      #0x2c94fcc                                 FsnCollapAd::LoadAd
02c98c0c: adrp    x8, #0x6265000                             
02c98c10: adrp    x9, #0x6265000                             
02c98c14: mov     x3, x19                                    
02c98c18: ldr     x8, [x8, #0x5d8]                           S:'[NativeCollapControl '
02c98c1c: ldr     x9, [x9, #0x970]                           S:'] Load request sent for AdID: '
02c98c20: ldr     x1, [x20, #0x30]                           ._logTag
02c98c24: mov     x4, xzr                                    
02c98c28: ldr     x0, [x8]                                   M:AdsManager::<OnApplicationPause>b__26_0
02c98c2c: ldr     x2, [x9]                                   M:AdsManager::<OnApplicationPause>b__26_0
02c98c30: bl      #0x4ca7320                                 System.String::Concat
02c98c34: adrp    x8, #0x6263000                             
02c98c38: mov     x19, x0                                    
02c98c3c: ldr     x8, [x8, #0x928]                           T:UnityEngine.Debug
02c98c40: ldr     x8, [x8]                                   &2c5bbd4(=a9bd7bfdd503233f)
02c98c44: ldr     w9, [x8, #0xe4]                            [62630e4]=0 f=0,0
02c98c48: cbnz    w9, #0x2c98c54                             
02c98c4c: mov     x0, x8                                     
02c98c50: bl      #0x2b70f30                                 fn_2b70f30
02c98c54: mov     x0, x19                                    
02c98c58: ldp     x20, x19, [sp, #0x20]                      
02c98c5c: ldp     x22, x21, [sp, #0x10]                      
02c98c60: mov     x1, xzr                                    
02c98c64: ldr     x30, [sp], #0x30                           
02c98c68: b       #0x5af21f4                                 UnityEngine.Debug::Log
02c98c6c: bl      #0x2b7105c                                 fn_2b7105c
## RegisterListener(FsnCollapAd ad) -> void
---- NativeCollapControl::RegisterListener 0x2c98cb4
02c98cb4: stp     x30, x27, [sp, #-0x50]!                    
02c98cb8: stp     x26, x25, [sp, #0x10]                      
02c98cbc: stp     x24, x23, [sp, #0x20]                      
02c98cc0: stp     x22, x21, [sp, #0x30]                      
02c98cc4: stp     x20, x19, [sp, #0x40]                      
02c98cc8: adrp    x21, #0x662f000                            
02c98ccc: mov     x19, x1                                    
02c98cd0: mov     x20, x0                                    
02c98cd4: ldrb    w8, [x21, #0xa22]                          
02c98cd8: tbnz    w8, #0, #0x2c98d50                         
02c98cdc: adrp    x0, #0x6265000                             
02c98ce0: ldr     x0, [x0, #0x4e0]                           T:type7027(k15)
02c98ce4: bl      #0x2b70db0                                 fn_2b70db0
02c98ce8: adrp    x0, #0x6265000                             
02c98cec: ldr     x0, [x0, #0x870]                           T:type7171(k15)
02c98cf0: bl      #0x2b70db0                                 fn_2b70db0
02c98cf4: adrp    x0, #0x6265000                             
02c98cf8: ldr     x0, [x0, #0x878]                           T:type7291(k15)
02c98cfc: bl      #0x2b70db0                                 fn_2b70db0
02c98d00: adrp    x0, #0x6264000                             
02c98d04: ldr     x0, [x0, #0xf90]                           T:System.Action
02c98d08: bl      #0x2b70db0                                 fn_2b70db0
02c98d0c: adrp    x0, #0x6265000                             
02c98d10: ldr     x0, [x0, #0x978]                           M:NativeCollapControl::<RegisterListener>b__18_0
02c98d14: bl      #0x2b70db0                                 fn_2b70db0
02c98d18: adrp    x0, #0x6265000                             
02c98d1c: ldr     x0, [x0, #0x980]                           M:NativeCollapControl::<RegisterListener>b__18_3
02c98d20: bl      #0x2b70db0                                 fn_2b70db0
02c98d24: adrp    x0, #0x6265000                             
02c98d28: ldr     x0, [x0, #0x988]                           M:NativeCollapControl/<>c::<RegisterListener>b__18_1
02c98d2c: bl      #0x2b70db0                                 fn_2b70db0
02c98d30: adrp    x0, #0x6265000                             
02c98d34: ldr     x0, [x0, #0x990]                           M:NativeCollapControl/<>c::<RegisterListener>b__18_2
02c98d38: bl      #0x2b70db0                                 fn_2b70db0
02c98d3c: adrp    x0, #0x6265000                             
02c98d40: ldr     x0, [x0, #0x998]                           T:NativeCollapControl/<>c
02c98d44: bl      #0x2b70db0                                 fn_2b70db0
02c98d48: mov     w8, #1                                     
02c98d4c: strb    w8, [x21, #0xa22]                          
02c98d50: cbz     x19, #0x2c98ed8                            
02c98d54: adrp    x8, #0x6265000                             
02c98d58: adrp    x21, #0x6265000                            
02c98d5c: adrp    x25, #0x6265000                            
02c98d60: ldr     x8, [x8, #0x870]                           T:type7171(k15)
02c98d64: ldr     x21, [x21, #0x978]                         M:NativeCollapControl::<RegisterListener>b__18_0
02c98d68: ldr     x25, [x25, #0x998]                         T:NativeCollapControl/<>c
02c98d6c: ldr     x0, [x8]                                   M:AdsManager::<OnApplicationPause>b__26_0
02c98d70: bl      #0x2b7104c                                 fn_2b7104c
02c98d74: ldr     x2, [x21]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c98d78: mov     x1, x20                                    
02c98d7c: mov     x3, xzr                                    
02c98d80: mov     x21, x0                                    
02c98d84: bl      #0x453c1e0                                 fn_453c1e0
02c98d88: ldr     x0, [x25]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c98d8c: ldr     w8, [x0, #0xe4]                            [62650e4]=0 f=0,0
02c98d90: cbnz    w8, #0x2c98d9c                             
02c98d94: bl      #0x2b70f30                                 fn_2b70f30
02c98d98: ldr     x0, [x25]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c98d9c: ldr     x8, [x0, #0xb8]                            T:AdsManager/<>c__DisplayClass42_0
02c98da0: ldr     x22, [x8, #8]                              M:AdsManager::<OnApplicationPause>b__26_1
02c98da4: cbnz    x22, #0x2c98e04                            
02c98da8: ldr     w9, [x0, #0xe4]                            [62650e4]=0 f=0,0
02c98dac: cbnz    w9, #0x2c98dbc                             
02c98db0: bl      #0x2b70f30                                 fn_2b70f30
02c98db4: ldr     x8, [x25]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c98db8: ldr     x8, [x8, #0xb8]                            T:AdsManager/<>c__DisplayClass42_0
02c98dbc: adrp    x9, #0x6264000                             
02c98dc0: ldr     x9, [x9, #0xf90]                           T:System.Action
02c98dc4: ldr     x23, [x8]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c98dc8: ldr     x0, [x9]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c98dcc: bl      #0x2b7104c                                 fn_2b7104c
02c98dd0: adrp    x8, #0x6265000                             
02c98dd4: mov     x1, x23                                    
02c98dd8: mov     x3, xzr                                    
02c98ddc: ldr     x8, [x8, #0x988]                           M:NativeCollapControl/<>c::<RegisterListener>b__18_1
02c98de0: mov     x22, x0                                    
02c98de4: ldr     x2, [x8]                                   M:AdsManager::<OnApplicationPause>b__26_0
02c98de8: bl      #0x4d8ddbc                                 System.Action::.ctor
02c98dec: ldr     x8, [x25]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c98df0: mov     x1, x22                                    
02c98df4: ldr     x0, [x8, #0xb8]                            T:AdsManager/<>c__DisplayClass42_0
02c98df8: str     x22, [x0, #8]!                             
02c98dfc: bl      #0x2b70d54                                 fn_2b70d54
02c98e00: ldr     x0, [x25]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c98e04: ldr     w8, [x0, #0xe4]                            [62650e4]=0 f=0,0
02c98e08: cbnz    w8, #0x2c98e14                             
02c98e0c: bl      #0x2b70f30                                 fn_2b70f30
02c98e10: ldr     x0, [x25]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c98e14: ldr     x8, [x0, #0xb8]                            T:AdsManager/<>c__DisplayClass42_0
02c98e18: adrp    x27, #0x6265000                            
02c98e1c: adrp    x26, #0x6265000                            
02c98e20: ldr     x27, [x27, #0x4e0]                         T:type7027(k15)
02c98e24: ldr     x23, [x8, #0x10]                           MS:MonoSingleton`1::get_Instance
02c98e28: ldr     x26, [x26, #0x980]                         M:NativeCollapControl::<RegisterListener>b__18_3
02c98e2c: cbnz    x23, #0x2c98e88                            
02c98e30: ldr     w9, [x0, #0xe4]                            [62650e4]=0 f=0,0
02c98e34: cbnz    w9, #0x2c98e44                             
02c98e38: bl      #0x2b70f30                                 fn_2b70f30
02c98e3c: ldr     x8, [x25]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c98e40: ldr     x8, [x8, #0xb8]                            T:AdsManager/<>c__DisplayClass42_0
02c98e44: adrp    x9, #0x6265000                             
02c98e48: ldr     x9, [x9, #0x878]                           T:type7291(k15)
02c98e4c: ldr     x24, [x8]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c98e50: ldr     x0, [x9]                                   M:AdsManager::<OnApplicationPause>b__26_0
02c98e54: bl      #0x2b7104c                                 fn_2b7104c
02c98e58: adrp    x8, #0x6265000                             
02c98e5c: mov     x1, x24                                    
02c98e60: mov     x3, xzr                                    
02c98e64: ldr     x8, [x8, #0x990]                           M:NativeCollapControl/<>c::<RegisterListener>b__18_2
02c98e68: mov     x23, x0                                    
02c98e6c: ldr     x2, [x8]                                   M:AdsManager::<OnApplicationPause>b__26_0
02c98e70: bl      #0x453ea7c                                 fn_453ea7c
02c98e74: ldr     x8, [x25]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c98e78: mov     x1, x23                                    
02c98e7c: ldr     x0, [x8, #0xb8]                            T:AdsManager/<>c__DisplayClass42_0
02c98e80: str     x23, [x0, #0x10]!                          
02c98e84: bl      #0x2b70d54                                 fn_2b70d54
02c98e88: mov     x0, x19                                    
02c98e8c: mov     x1, x21                                    
02c98e90: mov     x2, x22                                    
02c98e94: mov     x3, x23                                    
02c98e98: bl      #0x2c94c38                                 FsnCollapAd::SetFsnListener
02c98e9c: ldr     x0, [x27]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c98ea0: bl      #0x2b7104c                                 fn_2b7104c
02c98ea4: ldr     x2, [x26]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c98ea8: mov     x1, x20                                    
02c98eac: mov     x3, xzr                                    
02c98eb0: mov     x21, x0                                    
02c98eb4: bl      #0x453418c                                 fn_453418c
02c98eb8: mov     x0, x19                                    
02c98ebc: mov     x1, x21                                    
02c98ec0: ldp     x20, x19, [sp, #0x40]                      
02c98ec4: ldp     x22, x21, [sp, #0x30]                      
02c98ec8: ldp     x24, x23, [sp, #0x20]                      
02c98ecc: ldp     x26, x25, [sp, #0x10]                      
02c98ed0: ldp     x30, x27, [sp], #0x50                      
02c98ed4: b       #0x2c94da4                                 FsnCollapAd::SetOnCloseListener
02c98ed8: ldp     x20, x19, [sp, #0x40]                      
02c98edc: ldp     x22, x21, [sp, #0x30]                      
02c98ee0: ldp     x24, x23, [sp, #0x20]                      
02c98ee4: ldp     x26, x25, [sp, #0x10]                      
02c98ee8: ldp     x30, x27, [sp], #0x50                      
02c98eec: ret                                                
## HandleAdDismissed() -> void
---- NativeCollapControl::HandleAdDismissed 0x2c98ef0
02c98ef0: stp     x30, x19, [sp, #-0x10]!                    
02c98ef4: mov     x1, xzr                                    
02c98ef8: ldr     x19, [x0, #0x50]!                          ._actionClose
02c98efc: sturb   wzr, [x0, #-8]                             
02c98f00: str     xzr, [x0]                                  
02c98f04: bl      #0x2b70d54                                 fn_2b70d54
02c98f08: cbz     x19, #0x2c98f20                            
02c98f0c: ldr     x0, [x19, #0x40]                           ._reloadCoroutine
02c98f10: ldr     x1, [x19, #0x28]                           ._adID
02c98f14: ldr     x2, [x19, #0x18]                           
02c98f18: ldp     x30, x19, [sp], #0x10                      
02c98f1c: br      x2                                         
02c98f20: ldp     x30, x19, [sp], #0x10                      
02c98f24: ret                                                
## ShowAd(System.Action onAdCompleted, System.Action onAdClosed) -> void
---- NativeCollapControl::ShowAd 0x2c91230
02c91230: sub     sp, sp, #0x70                              
02c91234: stp     x30, x27, [sp, #0x20]                      
02c91238: stp     x26, x25, [sp, #0x30]                      
02c9123c: stp     x24, x23, [sp, #0x40]                      
02c91240: stp     x22, x21, [sp, #0x50]                      
02c91244: stp     x20, x19, [sp, #0x60]                      
02c91248: adrp    x21, #0x662f000                            
02c9124c: adrp    x23, #0x6265000                            
02c91250: mov     x22, x2                                    
02c91254: ldrb    w8, [x21, #0xa23]                          
02c91258: ldr     x23, [x23, #0x5b0]                         T:NativeCollapControl/<>c__DisplayClass20_0
02c9125c: mov     x19, x1                                    
02c91260: mov     x20, x0                                    
02c91264: tbnz    w8, #0, #0x2c912e8                         
02c91268: adrp    x0, #0x6265000                             
02c9126c: ldr     x0, [x0, #0x4e0]                           T:type7027(k15)
02c91270: bl      #0x2b70db0                                 fn_2b70db0
02c91274: adrp    x0, #0x6263000                             
02c91278: ldr     x0, [x0, #0x928]                           T:UnityEngine.Debug
02c9127c: bl      #0x2b70db0                                 fn_2b70db0
02c91280: adrp    x0, #0x6263000                             
02c91284: ldr     x0, [x0, #0xa80]                           T:type24502(k1d)
02c91288: bl      #0x2b70db0                                 fn_2b70db0
02c9128c: adrp    x0, #0x6265000                             
02c91290: ldr     x0, [x0, #0x5b8]                           M:NativeCollapControl/<>c__DisplayClass20_0::<ShowAd>b__0
02c91294: bl      #0x2b70db0                                 fn_2b70db0
02c91298: adrp    x0, #0x6265000                             
02c9129c: ldr     x0, [x0, #0x5c0]                           M:NativeCollapControl/<>c__DisplayClass20_0::<ShowAd>b__1
02c912a0: bl      #0x2b70db0                                 fn_2b70db0
02c912a4: adrp    x0, #0x6265000                             
02c912a8: ldr     x0, [x0, #0x5b0]                           T:NativeCollapControl/<>c__DisplayClass20_0
02c912ac: bl      #0x2b70db0                                 fn_2b70db0
02c912b0: adrp    x0, #0x6265000                             
02c912b4: ldr     x0, [x0, #0x5c8]                           S:'[NativeCollapControl {0}] ShowAd requested. enabled={1}, ready={2}, sh'
02c912b8: bl      #0x2b70db0                                 fn_2b70db0
02c912bc: adrp    x0, #0x6265000                             
02c912c0: ldr     x0, [x0, #0x5d0]                           S:'[NativeCollapControl {0}] ShowAd skipped. enabled={1}, ready={2}, show'
02c912c4: bl      #0x2b70db0                                 fn_2b70db0
02c912c8: adrp    x0, #0x6265000                             
02c912cc: ldr     x0, [x0, #0x5d8]                           S:'[NativeCollapControl '
02c912d0: bl      #0x2b70db0                                 fn_2b70db0
02c912d4: adrp    x0, #0x6265000                             
02c912d8: ldr     x0, [x0, #0x5e0]                           S:'] Showing native collapse ad. adID='
02c912dc: bl      #0x2b70db0                                 fn_2b70db0
02c912e0: mov     w8, #1                                     
02c912e4: strb    w8, [x21, #0xa23]                          
02c912e8: ldr     x0, [x23]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c912ec: bl      #0x2b7104c                                 fn_2b7104c
02c912f0: mov     x1, xzr                                    
02c912f4: mov     x21, x0                                    
02c912f8: bl      #0x4e53e9c                                 System.Object::.ctor
02c912fc: cbz     x21, #0x2c91794                            
02c91300: adrp    x26, #0x6263000                            
02c91304: mov     x0, x21                                    
02c91308: mov     x1, x20                                    
02c9130c: ldr     x26, [x26, #0xa80]                         T:type24502(k1d)
02c91310: str     x20, [x0, #0x10]!                          
02c91314: bl      #0x2b70d54                                 fn_2b70d54
02c91318: mov     x0, x21                                    
02c9131c: mov     x1, x22                                    
02c91320: str     x22, [x0, #0x18]!                          
02c91324: bl      #0x2b70d54                                 fn_2b70d54
02c91328: ldr     x0, [x26]                                  &2c5bbd4(=a9bd7bfdd503233f)
02c9132c: mov     w1, #5                                     
02c91330: bl      #0x2b70ea0                                 fn_2b70ea0
02c91334: cbz     x0, #0x2c91794                             
02c91338: ldr     x23, [x20, #0x30]                          ._logTag
02c9133c: mov     x22, x0                                    
02c91340: cbz     x23, #0x2c91358                            
02c91344: ldr     x8, [x22]                                  
02c91348: mov     x0, x23                                    
02c9134c: ldr     x1, [x8, #0x40]                            
02c91350: bl      #0x2b70f34                                 fn_2b70f34
02c91354: cbz     x0, #0x2c91788                             
02c91358: ldr     w8, [x22, #0x18]                           
02c9135c: cbz     w8, #0x2c91784                             
02c91360: mov     x0, x22                                    
02c91364: mov     x1, x23                                    
02c91368: str     x23, [x0, #0x20]!                          ._primaryAd
02c9136c: bl      #0x2b70d54                                 fn_2b70d54
02c91370: bl      #0x2c98a20                                 NativeCollapControl::get_IsEnabled
02c91374: adrp    x24, #0x6263000                            
02c91378: and     w8, w0, #1                                 
02c9137c: add     x1, sp, #0x1c                              
02c91380: ldr     x24, [x24, #0x970]                         &6645c70(=0)
02c91384: strb    w8, [sp, #0x1c]                            
02c91388: ldr     x0, [x24, #0x28]                           [6263028]=0 f=0,0
02c9138c: bl      #0x2b70f38                                 fn_2b70f38
02c91390: mov     x23, x0                                    
02c91394: cbz     x0, #0x2c913ac                             
02c91398: ldr     x8, [x22]                                  
02c9139c: mov     x0, x23                                    
02c913a0: ldr     x1, [x8, #0x40]                            
02c913a4: bl      #0x2b70f34                                 fn_2b70f34
02c913a8: cbz     x0, #0x2c91788                             
02c913ac: ldr     w8, [x22, #0x18]                           
02c913b0: tst     w8, #0xfffffffe                            
02c913b4: b.eq    #0x2c91784                                 
02c913b8: mov     x0, x22                                    
02c913bc: mov     x1, x23                                    
02c913c0: str     x23, [x0, #0x28]!                          ._adID
02c913c4: bl      #0x2b70d54                                 fn_2b70d54
02c913c8: ldr     x0, [x20, #0x20]                           ._primaryAd
02c913cc: cbz     x0, #0x2c913d4                             
02c913d0: bl      #0x2c9575c                                 FsnCollapAd::IsAdReady
02c913d4: and     w8, w0, #1                                 
02c913d8: ldr     x0, [x24, #0x28]                           [6263028]=0 f=0,0
02c913dc: add     x1, sp, #0x18                              
02c913e0: strb    w8, [sp, #0x18]                            
02c913e4: bl      #0x2b70f38                                 fn_2b70f38
02c913e8: mov     x23, x0                                    
02c913ec: cbz     x0, #0x2c91404                             
02c913f0: ldr     x8, [x22]                                  
02c913f4: mov     x0, x23                                    
02c913f8: ldr     x1, [x8, #0x40]                            
02c913fc: bl      #0x2b70f34                                 fn_2b70f34
02c91400: cbz     x0, #0x2c91788                             
02c91404: ldr     w8, [x22, #0x18]                           
02c91408: cmp     w8, #2                                     
02c9140c: b.ls    #0x2c91784                                 
02c91410: mov     x0, x22                                    
02c91414: mov     x1, x23                                    
02c91418: str     x23, [x0, #0x30]!                          ._logTag
02c9141c: bl      #0x2b70d54                                 fn_2b70d54
02c91420: ldrb    w8, [x20, #0x48]                           ._isShowing
02c91424: ldr     x0, [x24, #0x28]                           [6263028]=0 f=0,0
02c91428: add     x1, sp, #0x14                              
02c9142c: strb    w8, [sp, #0x14]                            
02c91430: bl      #0x2b70f38                                 fn_2b70f38
02c91434: mov     x23, x0                                    
02c91438: cbz     x0, #0x2c91450                             
02c9143c: ldr     x8, [x22]                                  
02c91440: mov     x0, x23                                    
02c91444: ldr     x1, [x8, #0x40]                            
02c91448: bl      #0x2b70f34                                 fn_2b70f34
02c9144c: cbz     x0, #0x2c91788                             
02c91450: ldr     w8, [x22, #0x18]                           
02c91454: tst     w8, #0xfffffffc                            
02c91458: b.eq    #0x2c91784                                 
02c9145c: mov     x0, x22                                    
02c91460: mov     x1, x23                                    
02c91464: str     x23, [x0, #0x38]!                          ._retryAttempt
02c91468: bl      #0x2b70d54                                 fn_2b70d54
02c9146c: ldr     x23, [x20, #0x28]                          ._adID
02c91470: cbz     x23, #0x2c91488                            
02c91474: ldr     x8, [x22]                                  
02c91478: mov     x0, x23                                    
02c9147c: ldr     x1, [x8, #0x40]                            
02c91480: bl      #0x2b70f34                                 fn_2b70f34
02c91484: cbz     x0, #0x2c91788                             
02c91488: ldr     w8, [x22, #0x18]                           
02c9148c: cmp     w8, #4                                     
02c91490: b.ls    #0x2c91784                                 
02c91494: adrp    x27, #0x6265000                            
02c91498: adrp    x25, #0x6263000                            
02c9149c: mov     x0, x22                                    
02c914a0: ldr     x27, [x27, #0x5c8]                         S:'[NativeCollapControl {0}] ShowAd requested. enabled={1}, ready={2}, sh'
02c914a4: ldr     x25, [x25, #0x928]                         T:UnityEngine.Debug
02c914a8: mov     x1, x23                                    
02c914ac: str     x23, [x0, #0x40]!                          ._reloadCoroutine
02c914b0: bl      #0x2b70d54                                 fn_2b70d54
02c914b4: ldr     x0, [x27]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c914b8: mov     x1, x22                                    
02c914bc: mov     x2, xzr                                    
02c914c0: bl      #0x4ca77a8                                 System.String::Format
02c914c4: ldr     x8, [x25]                                  &2c5bbd4(=a9bd7bfdd503233f)
02c914c8: mov     x22, x0                                    
02c914cc: ldr     w9, [x8, #0xe4]                            
02c914d0: cbnz    w9, #0x2c914dc                             
02c914d4: mov     x0, x8                                     
02c914d8: bl      #0x2b70f30                                 fn_2b70f30
02c914dc: mov     x0, x22                                    
02c914e0: mov     x1, xzr                                    
02c914e4: bl      #0x5af21f4                                 UnityEngine.Debug::Log
02c914e8: bl      #0x2c98a20                                 NativeCollapControl::get_IsEnabled
02c914ec: tbz     w0, #0, #0x2c91508                         
02c914f0: ldr     x0, [x20, #0x20]                           ._primaryAd
02c914f4: cbz     x0, #0x2c91508                             
02c914f8: bl      #0x2c9575c                                 FsnCollapAd::IsAdReady
02c914fc: tbz     w0, #0, #0x2c91508                         
02c91500: ldrb    w8, [x20, #0x48]                           ._isShowing
02c91504: cbz     w8, #0x2c916b4                             
02c91508: ldr     x0, [x26]                                  &2c5bbd4(=a9bd7bfdd503233f)
02c9150c: mov     w1, #4                                     
02c91510: bl      #0x2b70ea0                                 fn_2b70ea0
02c91514: cbz     x0, #0x2c91794                             
02c91518: ldr     x22, [x20, #0x30]                          ._logTag
02c9151c: mov     x21, x0                                    
02c91520: cbz     x22, #0x2c91538                            
02c91524: ldr     x8, [x21]                                  &2b706c4(=eb01011ff9400808)
02c91528: mov     x0, x22                                    
02c9152c: ldr     x1, [x8, #0x40]                            
02c91530: bl      #0x2b70f34                                 fn_2b70f34
02c91534: cbz     x0, #0x2c91788                             
02c91538: ldr     w8, [x21, #0x18]                           [662f018]=6000014 f=2.40742e-35,0
02c9153c: cbz     w8, #0x2c91784                             
02c91540: mov     x0, x21                                    
02c91544: mov     x1, x22                                    
02c91548: str     x22, [x0, #0x20]!                          ._primaryAd
02c9154c: bl      #0x2b70d54                                 fn_2b70d54
02c91550: bl      #0x2c98a20                                 NativeCollapControl::get_IsEnabled
02c91554: ldr     x8, [x24, #0x28]                           [6263028]=0 f=0,0
02c91558: and     w9, w0, #1                                 
02c9155c: add     x1, sp, #0x10                              
02c91560: strb    w9, [sp, #0x10]                            
02c91564: mov     x0, x8                                     
02c91568: bl      #0x2b70f38                                 fn_2b70f38
02c9156c: mov     x22, x0                                    
02c91570: cbz     x0, #0x2c91588                             
02c91574: ldr     x8, [x21]                                  &2b706c4(=eb01011ff9400808)
02c91578: mov     x0, x22                                    
02c9157c: ldr     x1, [x8, #0x40]                            
02c91580: bl      #0x2b70f34                                 fn_2b70f34
02c91584: cbz     x0, #0x2c91788                             
02c91588: ldr     w8, [x21, #0x18]                           [662f018]=6000014 f=2.40742e-35,0
02c9158c: tst     w8, #0xfffffffe                            
02c91590: b.eq    #0x2c91784                                 
02c91594: mov     x0, x21                                    
02c91598: mov     x1, x22                                    
02c9159c: str     x22, [x0, #0x28]!                          ._adID
02c915a0: bl      #0x2b70d54                                 fn_2b70d54
02c915a4: ldr     x0, [x20, #0x20]                           ._primaryAd
02c915a8: cbz     x0, #0x2c915b0                             
02c915ac: bl      #0x2c9575c                                 FsnCollapAd::IsAdReady
02c915b0: and     w8, w0, #1                                 
02c915b4: ldr     x0, [x24, #0x28]                           [6263028]=0 f=0,0
02c915b8: add     x1, sp, #0xc                               
02c915bc: strb    w8, [sp, #0xc]                             
02c915c0: bl      #0x2b70f38                                 fn_2b70f38
02c915c4: mov     x22, x0                                    
02c915c8: cbz     x0, #0x2c915e0                             
02c915cc: ldr     x8, [x21]                                  &2b706c4(=eb01011ff9400808)
02c915d0: mov     x0, x22                                    
02c915d4: ldr     x1, [x8, #0x40]                            
02c915d8: bl      #0x2b70f34                                 fn_2b70f34
02c915dc: cbz     x0, #0x2c91788                             
02c915e0: ldr     w8, [x21, #0x18]                           [662f018]=6000014 f=2.40742e-35,0
02c915e4: cmp     w8, #2                                     
02c915e8: b.ls    #0x2c91784                                 
02c915ec: mov     x0, x21                                    
02c915f0: mov     x1, x22                                    
02c915f4: str     x22, [x0, #0x30]!                          ._logTag
02c915f8: bl      #0x2b70d54                                 fn_2b70d54
02c915fc: ldrb    w8, [x20, #0x48]                           ._isShowing
02c91600: ldr     x0, [x24, #0x28]                           [6263028]=0 f=0,0
02c91604: add     x1, sp, #8                                 
02c91608: strb    w8, [sp, #8]                               
02c9160c: bl      #0x2b70f38                                 fn_2b70f38
02c91610: mov     x20, x0                                    
02c91614: cbz     x0, #0x2c9162c                             
02c91618: ldr     x8, [x21]                                  &2b706c4(=eb01011ff9400808)
02c9161c: mov     x0, x20                                    
02c91620: ldr     x1, [x8, #0x40]                            
02c91624: bl      #0x2b70f34                                 fn_2b70f34
02c91628: cbz     x0, #0x2c91788                             
02c9162c: ldr     w8, [x21, #0x18]                           [662f018]=6000014 f=2.40742e-35,0
02c91630: tst     w8, #0xfffffffc                            
02c91634: b.eq    #0x2c91784                                 
02c91638: adrp    x22, #0x6265000                            
02c9163c: mov     x0, x21                                    
02c91640: mov     x1, x20                                    
02c91644: ldr     x22, [x22, #0x5d0]                         S:'[NativeCollapControl {0}] ShowAd skipped. enabled={1}, ready={2}, show'
02c91648: str     x20, [x0, #0x38]!                          ._retryAttempt
02c9164c: bl      #0x2b70d54                                 fn_2b70d54
02c91650: ldr     x0, [x22]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c91654: mov     x1, x21                                    
02c91658: mov     x2, xzr                                    
02c9165c: bl      #0x4ca77a8                                 System.String::Format
02c91660: ldr     x8, [x25]                                  &2c5bbd4(=a9bd7bfdd503233f)
02c91664: mov     x20, x0                                    
02c91668: ldr     w9, [x8, #0xe4]                            
02c9166c: cbnz    w9, #0x2c91678                             
02c91670: mov     x0, x8                                     
02c91674: bl      #0x2b70f30                                 fn_2b70f30
02c91678: mov     x0, x20                                    
02c9167c: mov     x1, xzr                                    
02c91680: bl      #0x5af2c94                                 UnityEngine.Debug::LogWarning
02c91684: cbz     x19, #0x2c91698                            
02c91688: ldr     x8, [x19, #0x18]                           
02c9168c: ldr     x0, [x19, #0x40]                           ._reloadCoroutine
02c91690: ldr     x1, [x19, #0x28]                           ._adID
02c91694: blr     x8                                         
02c91698: ldp     x20, x19, [sp, #0x60]                      
02c9169c: ldp     x22, x21, [sp, #0x50]                      
02c916a0: ldp     x24, x23, [sp, #0x40]                      
02c916a4: ldp     x26, x25, [sp, #0x30]                      
02c916a8: ldp     x30, x27, [sp, #0x20]                      
02c916ac: add     sp, sp, #0x70                              
02c916b0: ret                                                
02c916b4: mov     x22, x20                                   
02c916b8: mov     x1, x19                                    
02c916bc: str     x19, [x22, #0x50]!                         
02c916c0: mov     x0, x22                                    
02c916c4: bl      #0x2b70d54                                 fn_2b70d54
02c916c8: adrp    x8, #0x6265000                             
02c916cc: adrp    x9, #0x6265000                             
02c916d0: mov     w10, #1                                    
02c916d4: ldr     x8, [x8, #0x5d8]                           S:'[NativeCollapControl '
02c916d8: ldr     x9, [x9, #0x5e0]                           S:'] Showing native collapse ad. adID='
02c916dc: mov     x4, xzr                                    
02c916e0: ldp     x3, x1, [x22, #-0x28]                      
02c916e4: sturb   w10, [x22, #-8]                            
02c916e8: ldr     x0, [x8]                                   M:AdsManager::<OnApplicationPause>b__26_0
02c916ec: ldr     x2, [x9]                                   M:AdsManager::<OnApplicationPause>b__26_0
02c916f0: bl      #0x4ca7320                                 System.String::Concat
02c916f4: ldr     x8, [x25]                                  &2c5bbd4(=a9bd7bfdd503233f)
02c916f8: mov     x19, x0                                    
02c916fc: ldr     w9, [x8, #0xe4]                            [62650e4]=0 f=0,0
02c91700: cbnz    w9, #0x2c9170c                             
02c91704: mov     x0, x8                                     
02c91708: bl      #0x2b70f30                                 fn_2b70f30
02c9170c: mov     x0, x19                                    
02c91710: mov     x1, xzr                                    
02c91714: bl      #0x5af21f4                                 UnityEngine.Debug::Log
02c91718: adrp    x22, #0x6265000                            
02c9171c: ldr     x22, [x22, #0x4e0]                         T:type7027(k15)
02c91720: ldr     x19, [x20, #0x20]                          ._primaryAd
02c91724: ldr     x0, [x22]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c91728: bl      #0x2b7104c                                 fn_2b7104c
02c9172c: adrp    x8, #0x6265000                             
02c91730: mov     x1, x21                                    
02c91734: mov     x3, xzr                                    
02c91738: ldr     x8, [x8, #0x5b8]                           M:NativeCollapControl/<>c__DisplayClass20_0::<ShowAd>b__0
02c9173c: mov     x20, x0                                    
02c91740: ldr     x2, [x8]                                   M:AdsManager::<OnApplicationPause>b__26_0
02c91744: bl      #0x453418c                                 fn_453418c
02c91748: ldr     x0, [x22]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9174c: bl      #0x2b7104c                                 fn_2b7104c
02c91750: adrp    x8, #0x6265000                             
02c91754: mov     x1, x21                                    
02c91758: mov     x3, xzr                                    
02c9175c: ldr     x8, [x8, #0x5c0]                           M:NativeCollapControl/<>c__DisplayClass20_0::<ShowAd>b__1
02c91760: mov     x22, x0                                    
02c91764: ldr     x2, [x8]                                   M:AdsManager::<OnApplicationPause>b__26_0
02c91768: bl      #0x453418c                                 fn_453418c
02c9176c: cbz     x19, #0x2c91794                            
02c91770: mov     x0, x19                                    
02c91774: mov     x1, x20                                    
02c91778: mov     x2, x22                                    
02c9177c: bl      #0x2c95150                                 FsnCollapAd::ShowAd
02c91780: b       #0x2c91698                                 
02c91784: bl      #0x2b71064                                 fn_2b71064
02c91788: bl      #0x2b71080                                 fn_2b71080
02c9178c: mov     x1, xzr                                    
02c91790: bl      #0x2b70f20                                 fn_2b70f20
02c91794: bl      #0x2b7105c                                 fn_2b7105c
## HideAd(System.Action actionClose) -> void
---- NativeCollapControl::HideAd 0x2c91798
02c91798: sub     sp, sp, #0x50                              
02c9179c: stp     x30, x25, [sp, #0x10]                      
02c917a0: stp     x24, x23, [sp, #0x20]                      
02c917a4: stp     x22, x21, [sp, #0x30]                      
02c917a8: stp     x20, x19, [sp, #0x40]                      
02c917ac: adrp    x21, #0x662f000                            
02c917b0: adrp    x24, #0x6265000                            
02c917b4: adrp    x23, #0x6263000                            
02c917b8: ldrb    w8, [x21, #0xa24]                          
02c917bc: ldr     x24, [x24, #0x5e8]                         S:'[NativeCollapControl {0}] HideAd requested. showing={1}, adExists={2}'
02c917c0: ldr     x23, [x23, #0x928]                         T:UnityEngine.Debug
02c917c4: mov     x19, x1                                    
02c917c8: mov     x20, x0                                    
02c917cc: tbnz    w8, #0, #0x2c91808                         
02c917d0: adrp    x0, #0x6263000                             
02c917d4: ldr     x0, [x0, #0x928]                           T:UnityEngine.Debug
02c917d8: bl      #0x2b70db0                                 fn_2b70db0
02c917dc: adrp    x0, #0x6265000                             
02c917e0: ldr     x0, [x0, #0x5e8]                           S:'[NativeCollapControl {0}] HideAd requested. showing={1}, adExists={2}'
02c917e4: bl      #0x2b70db0                                 fn_2b70db0
02c917e8: adrp    x0, #0x6265000                             
02c917ec: ldr     x0, [x0, #0x5f0]                           S:'] HideAd skipped: ad is not showing.'
02c917f0: bl      #0x2b70db0                                 fn_2b70db0
02c917f4: adrp    x0, #0x6265000                             
02c917f8: ldr     x0, [x0, #0x5d8]                           S:'[NativeCollapControl '
02c917fc: bl      #0x2b70db0                                 fn_2b70db0
02c91800: mov     w8, #1                                     
02c91804: strb    w8, [x21, #0xa24]                          
02c91808: adrp    x25, #0x6263000                            
02c9180c: add     x1, sp, #0xc                               
02c91810: ldr     x25, [x25, #0x970]                         &6645c70(=0)
02c91814: ldrb    w8, [x20, #0x48]                           ._isShowing
02c91818: ldr     x21, [x20, #0x30]                          ._logTag
02c9181c: ldr     x0, [x25, #0x28]                           [6263028]=0 f=0,0
02c91820: strb    w8, [sp, #0xc]                             
02c91824: bl      #0x2b70f38                                 fn_2b70f38
02c91828: ldr     x8, [x20, #0x20]                           ._primaryAd
02c9182c: mov     x22, x0                                    
02c91830: ldr     x0, [x25, #0x28]                           [6263028]=0 f=0,0
02c91834: add     x1, sp, #8                                 
02c91838: cmp     x8, #0                                     
02c9183c: cset    w8, ne                                     
02c91840: strb    w8, [sp, #8]                               
02c91844: bl      #0x2b70f38                                 fn_2b70f38
02c91848: ldr     x8, [x24]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9184c: mov     x3, x0                                     
02c91850: mov     x1, x21                                    
02c91854: mov     x2, x22                                    
02c91858: mov     x4, xzr                                    
02c9185c: mov     x0, x8                                     
02c91860: bl      #0x4ca7764                                 System.String::Format
02c91864: ldr     x8, [x23]                                  &2c5bbd4(=a9bd7bfdd503233f)
02c91868: mov     x21, x0                                    
02c9186c: ldr     w9, [x8, #0xe4]                            
02c91870: cbnz    w9, #0x2c9187c                             
02c91874: mov     x0, x8                                     
02c91878: bl      #0x2b70f30                                 fn_2b70f30
02c9187c: mov     x0, x21                                    
02c91880: mov     x1, xzr                                    
02c91884: bl      #0x5af21f4                                 UnityEngine.Debug::Log
02c91888: ldrb    w8, [x20, #0x48]                           ._isShowing
02c9188c: cbz     w8, #0x2c918bc                             
02c91890: ldr     x8, [x20, #0x20]                           ._primaryAd
02c91894: cbz     x8, #0x2c918bc                             
02c91898: str     x19, [x20, #0x50]!                         ._actionClose
02c9189c: mov     x0, x20                                    
02c918a0: mov     x1, x19                                    
02c918a4: sturb   wzr, [x20, #-8]                            
02c918a8: bl      #0x2b70d54                                 fn_2b70d54
02c918ac: ldur    x0, [x20, #-0x30]                          
02c918b0: cbz     x0, #0x2c91918                             
02c918b4: bl      #0x2c9565c                                 FsnCollapAd::HideAd
02c918b8: b       #0x2c91918                                 
02c918bc: adrp    x8, #0x6265000                             
02c918c0: adrp    x9, #0x6265000                             
02c918c4: mov     x3, xzr                                    
02c918c8: ldr     x8, [x8, #0x5d8]                           S:'[NativeCollapControl '
02c918cc: ldr     x9, [x9, #0x5f0]                           S:'] HideAd skipped: ad is not showing.'
02c918d0: ldr     x1, [x20, #0x30]                           ._logTag
02c918d4: ldr     x0, [x8]                                   M:AdsManager::<OnApplicationPause>b__26_0
02c918d8: ldr     x2, [x9]                                   M:AdsManager::<OnApplicationPause>b__26_0
02c918dc: bl      #0x4ca6dbc                                 System.String::Concat
02c918e0: ldr     x8, [x23]                                  &2c5bbd4(=a9bd7bfdd503233f)
02c918e4: mov     x20, x0                                    
02c918e8: ldr     w9, [x8, #0xe4]                            [62650e4]=0 f=0,0
02c918ec: cbnz    w9, #0x2c918f8                             
02c918f0: mov     x0, x8                                     
02c918f4: bl      #0x2b70f30                                 fn_2b70f30
02c918f8: mov     x0, x20                                    
02c918fc: mov     x1, xzr                                    
02c91900: bl      #0x5af2c94                                 UnityEngine.Debug::LogWarning
02c91904: cbz     x19, #0x2c91918                            
02c91908: ldr     x8, [x19, #0x18]                           
02c9190c: ldr     x0, [x19, #0x40]                           ._reloadCoroutine
02c91910: ldr     x1, [x19, #0x28]                           ._adID
02c91914: blr     x8                                         
02c91918: ldp     x20, x19, [sp, #0x40]                      
02c9191c: ldp     x22, x21, [sp, #0x30]                      
02c91920: ldp     x24, x23, [sp, #0x20]                      
02c91924: ldp     x30, x25, [sp, #0x10]                      
02c91928: add     sp, sp, #0x50                              
02c9192c: ret                                                
## TryReloadAd() -> void
---- NativeCollapControl::TryReloadAd 0x2c98f30
02c98f30: str     x30, [sp, #-0x20]!                         
02c98f34: stp     x20, x19, [sp, #0x10]                      
02c98f38: mov     x19, x0                                    
02c98f3c: bl      #0x2c98a20                                 NativeCollapControl::get_IsEnabled
02c98f40: tbz     w0, #0, #0x2c98f50                         
02c98f44: mov     x20, x19                                   
02c98f48: ldr     x8, [x20, #0x40]!                          ._reloadCoroutine
02c98f4c: cbz     x8, #0x2c98f5c                             
02c98f50: ldp     x20, x19, [sp, #0x10]                      
02c98f54: ldr     x30, [sp], #0x20                           
02c98f58: ret                                                
02c98f5c: mov     x0, x19                                    
02c98f60: bl      #0x2c98f8c                                 NativeCollapControl::ReloadCoroutine
02c98f64: mov     x1, x0                                     
02c98f68: mov     x0, x19                                    
02c98f6c: mov     x2, xzr                                    
02c98f70: bl      #0x5b389f0                                 UnityEngine.MonoBehaviour::StartCoroutine
02c98f74: mov     x1, x0                                     
02c98f78: mov     x0, x20                                    
02c98f7c: str     x1, [x19, #0x40]                           ._reloadCoroutine
02c98f80: ldp     x20, x19, [sp, #0x10]                      
02c98f84: ldr     x30, [sp], #0x20                           
02c98f88: b       #0x2b70d54                                 
## ReloadCoroutine() -> System.Collections.IEnumerator
---- NativeCollapControl::ReloadCoroutine 0x2c98f8c
02c98f8c: stp     x30, x21, [sp, #-0x20]!                    
02c98f90: stp     x20, x19, [sp, #0x10]                      
02c98f94: adrp    x20, #0x662f000                            
02c98f98: adrp    x21, #0x6265000                            
02c98f9c: mov     x19, x0                                    
02c98fa0: ldrb    w8, [x20, #0xa25]                          
02c98fa4: ldr     x21, [x21, #0x9a0]                         T:NativeCollapControl/<ReloadCoroutine>d__23
02c98fa8: tbnz    w8, #0, #0x2c98fc0                         
02c98fac: adrp    x0, #0x6265000                             
02c98fb0: ldr     x0, [x0, #0x9a0]                           T:NativeCollapControl/<ReloadCoroutine>d__23
02c98fb4: bl      #0x2b70db0                                 fn_2b70db0
02c98fb8: mov     w8, #1                                     
02c98fbc: strb    w8, [x20, #0xa25]                          
02c98fc0: ldr     x0, [x21]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c98fc4: bl      #0x2b7104c                                 fn_2b7104c
02c98fc8: mov     x1, xzr                                    
02c98fcc: mov     x20, x0                                    
02c98fd0: bl      #0x4e53e9c                                 System.Object::.ctor
02c98fd4: mov     x0, x20                                    
02c98fd8: mov     x1, x19                                    
02c98fdc: str     wzr, [x20, #0x10]                          
02c98fe0: str     x19, [x0, #0x20]!                          ._primaryAd
02c98fe4: bl      #0x2b70d54                                 fn_2b70d54
02c98fe8: mov     x0, x20                                    
02c98fec: ldp     x20, x19, [sp, #0x10]                      
02c98ff0: ldp     x30, x21, [sp], #0x20                      
02c98ff4: ret                                                
## StopReloadCoroutine() -> void
---- NativeCollapControl::StopReloadCoroutine 0x2c98c70
02c98c70: str     x30, [sp, #-0x20]!                         
02c98c74: stp     x20, x19, [sp, #0x10]                      
02c98c78: mov     x20, x0                                    
02c98c7c: ldr     x1, [x20, #0x40]!                          ._reloadCoroutine
02c98c80: cbz     x1, #0x2c98ca8                             
02c98c84: mov     x2, xzr                                    
02c98c88: mov     x19, x0                                    
02c98c8c: bl      #0x5b38c4c                                 UnityEngine.MonoBehaviour::StopCoroutine
02c98c90: mov     x0, x20                                    
02c98c94: str     xzr, [x19, #0x40]                          ._reloadCoroutine
02c98c98: mov     x1, xzr                                    
02c98c9c: ldp     x20, x19, [sp, #0x10]                      
02c98ca0: ldr     x30, [sp], #0x20                           
02c98ca4: b       #0x2b70d54                                 
02c98ca8: ldp     x20, x19, [sp, #0x10]                      
02c98cac: ldr     x30, [sp], #0x20                           
02c98cb0: ret                                                
## OnDestroy() -> void
---- NativeCollapControl::OnDestroy 0x2c99020
02c99020: stp     x30, x19, [sp, #-0x10]!                    
02c99024: mov     x19, x0                                    
02c99028: bl      #0x2c98c70                                 NativeCollapControl::StopReloadCoroutine
02c9902c: ldr     x0, [x19, #0x20]                           ._primaryAd
02c99030: cbz     x0, #0x2c9903c                             
02c99034: ldp     x30, x19, [sp], #0x10                      
02c99038: b       #0x2c95924                                 FsnCollapAd::Release
02c9903c: ldp     x30, x19, [sp], #0x10                      
02c99040: ret                                                
## .ctor() -> void
---- NativeCollapControl::.ctor 0x2c99044
02c99044: stp     x30, x21, [sp, #-0x20]!                    
02c99048: stp     x20, x19, [sp, #0x10]                      
02c9904c: adrp    x21, #0x662f000                            
02c99050: adrp    x20, #0x6263000                            
02c99054: mov     x19, x0                                    
02c99058: ldrb    w8, [x21, #0xa26]                          
02c9905c: ldr     x20, [x20, #0xa90]                         S:''
02c99060: tbnz    w8, #0, #0x2c99078                         
02c99064: adrp    x0, #0x6263000                             
02c99068: ldr     x0, [x0, #0xa90]                           S:''
02c9906c: bl      #0x2b70db0                                 fn_2b70db0
02c99070: mov     w8, #1                                     
02c99074: strb    w8, [x21, #0xa26]                          
02c99078: ldr     x1, [x20]                                  &2c5bbd4(=a9bd7bfdd503233f)
02c9907c: mov     x0, x19                                    
02c99080: str     x1, [x0, #0x28]!                           ._adID
02c99084: bl      #0x2b70d54                                 fn_2b70d54
02c99088: ldr     x1, [x20]                                  &2c5bbd4(=a9bd7bfdd503233f)
02c9908c: mov     x0, x19                                    
02c99090: str     x1, [x0, #0x30]!                           ._logTag
02c99094: bl      #0x2b70d54                                 fn_2b70d54
02c99098: mov     w8, #0xa                                   
02c9909c: mov     x0, x19                                    
02c990a0: mov     x1, xzr                                    
02c990a4: str     w8, [x19, #0x3c]                           ._maxRetryAttempts
02c990a8: ldp     x20, x19, [sp, #0x10]                      
02c990ac: ldp     x30, x21, [sp], #0x20                      
02c990b0: b       #0x5b397b0                                 UnityEngine.MonoBehaviour::.ctor
## <RegisterListener>b__18_0(int errorCode, string errorMessage) -> void
---- NativeCollapControl::<RegisterListener>b__18_0 0x2c990b4
02c990b4: str     x30, [sp, #-0x40]!                         
02c990b8: stp     x24, x23, [sp, #0x10]                      
02c990bc: stp     x22, x21, [sp, #0x20]                      
02c990c0: stp     x20, x19, [sp, #0x30]                      
02c990c4: adrp    x22, #0x662f000                            
02c990c8: adrp    x24, #0x6265000                            
02c990cc: adrp    x23, #0x6263000                            
02c990d0: ldrb    w8, [x22, #0xa27]                          
02c990d4: ldr     x24, [x24, #0x9a8]                         S:'[NativeCollapControl {0}] Loading completed: {1}, {2}'
02c990d8: ldr     x23, [x23, #0x928]                         T:UnityEngine.Debug
02c990dc: mov     x21, x2                                    
02c990e0: mov     w20, w1                                    
02c990e4: mov     x19, x0                                    
02c990e8: tbnz    w8, #0, #0x2c9910c                         
02c990ec: adrp    x0, #0x6263000                             
02c990f0: ldr     x0, [x0, #0x928]                           T:UnityEngine.Debug
02c990f4: bl      #0x2b70db0                                 fn_2b70db0
02c990f8: adrp    x0, #0x6265000                             
02c990fc: ldr     x0, [x0, #0x9a8]                           S:'[NativeCollapControl {0}] Loading completed: {1}, {2}'
02c99100: bl      #0x2b70db0                                 fn_2b70db0
02c99104: mov     w8, #1                                     
02c99108: strb    w8, [x22, #0xa27]                          
02c9910c: adrp    x8, #0x6263000                             
02c99110: add     x1, sp, #0xc                               
02c99114: ldr     x8, [x8, #0x970]                           &6645c70(=0)
02c99118: ldr     x22, [x19, #0x30]                          ._logTag
02c9911c: str     w20, [sp, #0xc]                            
02c99120: ldr     x0, [x8, #0x48]                            &6263098(=0)
02c99124: bl      #0x2b70f38                                 fn_2b70f38
02c99128: ldr     x8, [x24]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9912c: mov     x2, x0                                     
02c99130: mov     x1, x22                                    
02c99134: mov     x3, x21                                    
02c99138: mov     x4, xzr                                    
02c9913c: mov     x0, x8                                     
02c99140: bl      #0x4ca7764                                 System.String::Format
02c99144: ldr     x8, [x23]                                  &2c5bbd4(=a9bd7bfdd503233f)
02c99148: mov     x21, x0                                    
02c9914c: ldr     w9, [x8, #0xe4]                            [62630e4]=0 f=0,0
02c99150: cbnz    w9, #0x2c9915c                             
02c99154: mov     x0, x8                                     
02c99158: bl      #0x2b70f30                                 fn_2b70f30
02c9915c: mov     x0, x21                                    
02c99160: mov     x1, xzr                                    
02c99164: bl      #0x5af21f4                                 UnityEngine.Debug::Log
02c99168: cbz     w20, #0x2c99178                            
02c9916c: mov     x0, x19                                    
02c99170: bl      #0x2c98f30                                 NativeCollapControl::TryReloadAd
02c99174: b       #0x2c9917c                                 
02c99178: str     wzr, [x19, #0x38]                          ._retryAttempt
02c9917c: ldp     x20, x19, [sp, #0x30]                      
02c99180: ldp     x22, x21, [sp, #0x20]                      
02c99184: ldp     x24, x23, [sp, #0x10]                      
02c99188: ldr     x30, [sp], #0x40                           
02c9918c: ret                                                
## <RegisterListener>b__18_3(string err) -> void
---- NativeCollapControl::<RegisterListener>b__18_3 0x2c99190
02c99190: str     x30, [sp, #-0x40]!                         
02c99194: stp     x24, x23, [sp, #0x10]                      
02c99198: stp     x22, x21, [sp, #0x20]                      
02c9919c: stp     x20, x19, [sp, #0x30]                      
02c991a0: adrp    x23, #0x662f000                            
02c991a4: adrp    x22, #0x6265000                            
02c991a8: adrp    x24, #0x6265000                            
02c991ac: adrp    x21, #0x6263000                            
02c991b0: ldr     x22, [x22, #0x5d8]                         S:'[NativeCollapControl '
02c991b4: ldrb    w8, [x23, #0xa28]                          
02c991b8: ldr     x24, [x24, #0x9b0]                         S:'] Ad closed: '
02c991bc: ldr     x21, [x21, #0x928]                         T:UnityEngine.Debug
02c991c0: mov     x20, x1                                    
02c991c4: mov     x19, x0                                    
02c991c8: tbnz    w8, #0, #0x2c991f8                         
02c991cc: adrp    x0, #0x6263000                             
02c991d0: ldr     x0, [x0, #0x928]                           T:UnityEngine.Debug
02c991d4: bl      #0x2b70db0                                 fn_2b70db0
02c991d8: adrp    x0, #0x6265000                             
02c991dc: ldr     x0, [x0, #0x5d8]                           S:'[NativeCollapControl '
02c991e0: bl      #0x2b70db0                                 fn_2b70db0
02c991e4: adrp    x0, #0x6265000                             
02c991e8: ldr     x0, [x0, #0x9b0]                           S:'] Ad closed: '
02c991ec: bl      #0x2b70db0                                 fn_2b70db0
02c991f0: mov     w8, #1                                     
02c991f4: strb    w8, [x23, #0xa28]                          
02c991f8: ldr     x1, [x19, #0x30]                           ._logTag
02c991fc: ldr     x0, [x22]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c99200: mov     x3, x20                                    
02c99204: ldr     x2, [x24]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c99208: mov     x4, xzr                                    
02c9920c: bl      #0x4ca7320                                 System.String::Concat
02c99210: ldr     x8, [x21]                                  &2c5bbd4(=a9bd7bfdd503233f)
02c99214: mov     x20, x0                                    
02c99218: ldr     w9, [x8, #0xe4]                            
02c9921c: cbnz    w9, #0x2c99228                             
02c99220: mov     x0, x8                                     
02c99224: bl      #0x2b70f30                                 fn_2b70f30
02c99228: mov     x0, x20                                    
02c9922c: mov     x1, xzr                                    
02c99230: bl      #0x5af21f4                                 UnityEngine.Debug::Log
02c99234: mov     x0, x19                                    
02c99238: ldp     x20, x19, [sp, #0x30]                      
02c9923c: ldp     x22, x21, [sp, #0x20]                      
02c99240: ldp     x24, x23, [sp, #0x10]                      
02c99244: ldr     x30, [sp], #0x40                           
02c99248: b       #0x2c98ef0                                 NativeCollapControl::HandleAdDismissed
