#### CLASS LevelData parent= GameData
#   field _levelSave                     LevelSaveData                                      off=0x20 attr=1 SerializeField
## get_LevelSave() -> LevelSaveData
---- LevelData::get_LevelSave 0x2cad00c
02cad00c: ldr     x0, [x0, #0x20]                            ._levelSave
02cad010: ret                                                
## set_LevelSave(LevelSaveData value) -> void
---- LevelData::set_LevelSave 0x2cad014
02cad014: str     x1, [x0, #0x20]!                           ._levelSave
02cad018: b       #0x2b70d54                                 
## get_CurrentLevelId() -> int
---- LevelData::get_CurrentLevelId 0x2cad01c
02cad01c: ldr     x8, [x0, #0x20]                            ._levelSave
02cad020: cbz     x8, #0x2cad02c                             
02cad024: ldr     w0, [x8, #0x10]                            
02cad028: ret                                                
02cad02c: str     x30, [sp, #-0x10]!                         
02cad030: bl      #0x2b7105c                                 fn_2b7105c
## set_CurrentLevelId(int value) -> void
---- LevelData::set_CurrentLevelId 0x2cad034
02cad034: ldr     x8, [x0, #0x20]                            ._levelSave
02cad038: cbz     x8, #0x2cad044                             
02cad03c: str     w1, [x8, #0x10]                            
02cad040: ret                                                
02cad044: str     x30, [sp, #-0x10]!                         
02cad048: bl      #0x2b7105c                                 fn_2b7105c
## get_HighestLevelId() -> int
---- LevelData::get_HighestLevelId 0x2cad04c
02cad04c: ldr     x8, [x0, #0x20]                            ._levelSave
02cad050: cbz     x8, #0x2cad05c                             
02cad054: ldr     w0, [x8, #0x14]                            
02cad058: ret                                                
02cad05c: str     x30, [sp, #-0x10]!                         
02cad060: bl      #0x2b7105c                                 fn_2b7105c
## set_HighestLevelId(int value) -> void
---- LevelData::set_HighestLevelId 0x2cad064
02cad064: ldr     x8, [x0, #0x20]                            ._levelSave
02cad068: cbz     x8, #0x2cad074                             
02cad06c: str     w1, [x8, #0x14]                            
02cad070: ret                                                
02cad074: str     x30, [sp, #-0x10]!                         
02cad078: bl      #0x2b7105c                                 fn_2b7105c
## GetCurrentLevel() -> int
---- LevelData::GetCurrentLevel 0x2cad07c
02cad07c: ldr     x8, [x0, #0x20]                            ._levelSave
02cad080: cbz     x8, #0x2cad08c                             
02cad084: ldr     w0, [x8, #0x10]                            
02cad088: ret                                                
02cad08c: str     x30, [sp, #-0x10]!                         
02cad090: bl      #0x2b7105c                                 fn_2b7105c
## SaveData() -> void
---- LevelData::SaveData 0x2cad094
02cad094: stp     x30, x21, [sp, #-0x20]!                    
02cad098: stp     x20, x19, [sp, #0x10]                      
02cad09c: adrp    x20, #0x662f000                            
02cad0a0: adrp    x21, #0x6266000                            
02cad0a4: mov     x19, x0                                    
02cad0a8: ldrb    w8, [x20, #0xb39]                          
02cad0ac: ldr     x21, [x21, #0x658]                         MS:MonoSingleton`1::get_Instance
02cad0b0: tbnz    w8, #0, #0x2cad0d4                         
02cad0b4: adrp    x0, #0x6266000                             
02cad0b8: ldr     x0, [x0, #0x898]                           MS:DataManager::SaveData
02cad0bc: bl      #0x2b70db0                                 fn_2b70db0
02cad0c0: adrp    x0, #0x6266000                             
02cad0c4: ldr     x0, [x0, #0x658]                           MS:MonoSingleton`1::get_Instance
02cad0c8: bl      #0x2b70db0                                 fn_2b70db0
02cad0cc: mov     w8, #1                                     
02cad0d0: strb    w8, [x20, #0xb39]                          
02cad0d4: ldr     x0, [x21]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cad0d8: bl      #0x3769600                                 fn_3769600
02cad0dc: mov     x20, x0                                    
02cad0e0: mov     x0, x19                                    
02cad0e4: mov     x1, xzr                                    
02cad0e8: bl      #0x4e54610                                 System.Object::GetType
02cad0ec: cbz     x0, #0x2cad128                             
02cad0f0: ldr     x8, [x0]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cad0f4: ldr     x9, [x8, #0x2f8]                           
02cad0f8: ldr     x1, [x8, #0x300]                           
02cad0fc: blr     x9                                         
02cad100: cbz     x20, #0x2cad128                            
02cad104: adrp    x8, #0x6266000                             
02cad108: mov     x1, x0                                     
02cad10c: mov     x0, x20                                    
02cad110: ldr     x8, [x8, #0x898]                           MS:DataManager::SaveData
02cad114: ldr     x2, [x19, #0x20]                           ._levelSave
02cad118: ldp     x20, x19, [sp, #0x10]                      
02cad11c: ldr     x3, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cad120: ldp     x30, x21, [sp], #0x20                      
02cad124: b       #0x3169790                                 
02cad128: bl      #0x2b7105c                                 fn_2b7105c
## LoadData() -> void
---- LevelData::LoadData 0x2cad12c
02cad12c: stp     x30, x21, [sp, #-0x20]!                    
02cad130: stp     x20, x19, [sp, #0x10]                      
02cad134: adrp    x20, #0x662f000                            
02cad138: adrp    x21, #0x6266000                            
02cad13c: mov     x19, x0                                    
02cad140: ldrb    w8, [x20, #0xb3a]                          
02cad144: ldr     x21, [x21, #0x658]                         MS:MonoSingleton`1::get_Instance
02cad148: tbnz    w8, #0, #0x2cad16c                         
02cad14c: adrp    x0, #0x6266000                             
02cad150: ldr     x0, [x0, #0x8a0]                           MS:DataManager::LoadData
02cad154: bl      #0x2b70db0                                 fn_2b70db0
02cad158: adrp    x0, #0x6266000                             
02cad15c: ldr     x0, [x0, #0x658]                           MS:MonoSingleton`1::get_Instance
02cad160: bl      #0x2b70db0                                 fn_2b70db0
02cad164: mov     w8, #1                                     
02cad168: strb    w8, [x20, #0xb3a]                          
02cad16c: ldr     x0, [x21]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cad170: bl      #0x3769600                                 fn_3769600
02cad174: mov     x20, x0                                    
02cad178: mov     x0, x19                                    
02cad17c: mov     x1, xzr                                    
02cad180: bl      #0x4e54610                                 System.Object::GetType
02cad184: cbz     x0, #0x2cad1cc                             
02cad188: ldr     x8, [x0]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cad18c: ldr     x9, [x8, #0x2f8]                           
02cad190: ldr     x1, [x8, #0x300]                           
02cad194: blr     x9                                         
02cad198: cbz     x20, #0x2cad1cc                            
02cad19c: adrp    x8, #0x6266000                             
02cad1a0: mov     x1, x0                                     
02cad1a4: mov     x0, x20                                    
02cad1a8: ldr     x8, [x8, #0x8a0]                           MS:DataManager::LoadData
02cad1ac: ldr     x2, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cad1b0: bl      #0x31690b0                                 fn_31690b0
02cad1b4: str     x0, [x19, #0x20]!                          ._levelSave
02cad1b8: mov     x1, x0                                     
02cad1bc: mov     x0, x19                                    
02cad1c0: ldp     x20, x19, [sp, #0x10]                      
02cad1c4: ldp     x30, x21, [sp], #0x20                      
02cad1c8: b       #0x2b70d54                                 
02cad1cc: bl      #0x2b7105c                                 fn_2b7105c
## NewData() -> void
---- LevelData::NewData 0x2cad1d0
02cad1d0: stp     x30, x21, [sp, #-0x20]!                    
02cad1d4: stp     x20, x19, [sp, #0x10]                      
02cad1d8: adrp    x20, #0x662f000                            
02cad1dc: adrp    x21, #0x6266000                            
02cad1e0: mov     x19, x0                                    
02cad1e4: ldrb    w8, [x20, #0xb3b]                          
02cad1e8: ldr     x21, [x21, #0x8a8]                         T:LevelSaveData
02cad1ec: tbnz    w8, #0, #0x2cad204                         
02cad1f0: adrp    x0, #0x6266000                             
02cad1f4: ldr     x0, [x0, #0x8a8]                           T:LevelSaveData
02cad1f8: bl      #0x2b70db0                                 fn_2b70db0
02cad1fc: mov     w8, #1                                     
02cad200: strb    w8, [x20, #0xb3b]                          
02cad204: ldr     x0, [x21]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cad208: bl      #0x2b7104c                                 fn_2b7104c
02cad20c: mov     x1, xzr                                    
02cad210: mov     x20, x0                                    
02cad214: bl      #0x4e53e9c                                 System.Object::.ctor
02cad218: adrp    x8, #0x1040000                             
02cad21c: mov     x0, x19                                    
02cad220: mov     x1, x20                                    
02cad224: ldr     d0, [x8, #0x928]                           [1040928]=1 f=1.4013e-45,0
02cad228: str     x20, [x0, #0x20]!                          ._levelSave
02cad22c: str     d0, [x20, #0x10]                           
02cad230: bl      #0x2b70d54                                 fn_2b70d54
02cad234: ldr     x8, [x19]                                  
02cad238: mov     x0, x19                                    
02cad23c: ldp     x20, x19, [sp, #0x10]                      
02cad240: ldr     x1, [x8, #0x260]                           [1040260]=0 f=0,0
02cad244: ldr     x2, [x8, #0x258]                           [1040258]=55e00000402 f=1.43773e-42,1.92538e-42
02cad248: ldp     x30, x21, [sp], #0x20                      
02cad24c: br      x2                                         
## PassLevel() -> void
---- LevelData::PassLevel 0x2cad250
02cad250: ldr     x8, [x0, #0x20]                            ._levelSave
02cad254: cbz     x8, #0x2cad280                             
02cad258: ldp     w9, w10, [x8, #0x10]                       
02cad25c: cmp     w9, w10                                    
02cad260: b.le    #0x2cad268                                 
02cad264: str     w9, [x8, #0x14]                            
02cad268: add     w9, w9, #1                                 
02cad26c: str     w9, [x8, #0x10]                            
02cad270: ldr     x8, [x0]                                   
02cad274: ldr     x1, [x8, #0x260]                           
02cad278: ldr     x2, [x8, #0x258]                           
02cad27c: br      x2                                         
02cad280: str     x30, [sp, #-0x10]!                         
02cad284: bl      #0x2b7105c                                 fn_2b7105c
## .ctor() -> void
---- LevelData::.ctor 0x2cad288
02cad288: mov     x1, xzr                                    
02cad28c: b       #0x5b397b0                                 UnityEngine.MonoBehaviour::.ctor
