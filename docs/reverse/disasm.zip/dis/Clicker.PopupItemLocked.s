#### CLASS Clicker.PopupItemLocked parent= PopupBase
#   field _imgItem                       UnityEngine.UI.Image                               off=0x38 attr=1 SerializeField
#   field _tfPanel                       UnityEngine.Transform                              off=0x40 attr=1 SerializeField
#   field _btnClose                      UnityEngine.UI.Button                              off=0x48 attr=1 SerializeField
## OnInit(UIManager uiManager) -> void
---- Clicker.PopupItemLocked::OnInit 0x2d7013c
02d7013c: stp     x30, x21, [sp, #-0x20]!                    
02d70140: stp     x20, x19, [sp, #0x10]                      
02d70144: adrp    x21, #0x6630000                            
02d70148: mov     x20, x1                                    
02d7014c: mov     x19, x0                                    
02d70150: ldrb    w8, [x21, #0x39c]                          
02d70154: tbnz    w8, #0, #0x2d70178                         
02d70158: adrp    x0, #0x626c000                             
02d7015c: ldr     x0, [x0, #0x548]                           M:Clicker.PopupItemLocked::OnCloseClick
02d70160: bl      #0x2b70db0                                 fn_2b70db0
02d70164: adrp    x0, #0x6265000                             
02d70168: ldr     x0, [x0, #0x3f0]                           T:UnityEngine.Events.UnityAction
02d7016c: bl      #0x2b70db0                                 fn_2b70db0
02d70170: mov     w8, #1                                     
02d70174: strb    w8, [x21, #0x39c]                          
02d70178: mov     x0, x19                                    
02d7017c: mov     x1, x20                                    
02d70180: mov     x2, xzr                                    
02d70184: bl      #0x2cdd3c4                                 UIBase::OnInit
02d70188: ldr     x8, [x19, #0x48]                           ._btnClose
02d7018c: cbz     x8, #0x2d70254                             
02d70190: ldr     x0, [x8, #0x100]                           
02d70194: cbz     x0, #0x2d70254                             
02d70198: mov     x1, xzr                                    
02d7019c: bl      #0x5b4ce48                                 UnityEngine.Events.UnityEventBase::RemoveAllListeners
02d701a0: ldr     x8, [x19, #0x48]                           ._btnClose
02d701a4: cbz     x8, #0x2d70254                             
02d701a8: adrp    x9, #0x6265000                             
02d701ac: adrp    x21, #0x626c000                            
02d701b0: ldr     x9, [x9, #0x3f0]                           T:UnityEngine.Events.UnityAction
02d701b4: ldr     x21, [x21, #0x548]                         M:Clicker.PopupItemLocked::OnCloseClick
02d701b8: ldr     x20, [x8, #0x100]                          
02d701bc: ldr     x0, [x9]                                   M:AdsManager::<OnApplicationPause>b__26_0
02d701c0: bl      #0x2b7104c                                 fn_2b7104c
02d701c4: ldr     x2, [x21]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d701c8: mov     x1, x19                                    
02d701cc: mov     x3, xzr                                    
02d701d0: mov     x21, x0                                    
02d701d4: bl      #0x5b4cf98                                 UnityEngine.Events.UnityAction::.ctor
02d701d8: cbz     x20, #0x2d70254                            
02d701dc: mov     x0, x20                                    
02d701e0: mov     x1, x21                                    
02d701e4: mov     x2, xzr                                    
02d701e8: bl      #0x5b4d0ac                                 UnityEngine.Events.UnityEvent::AddListener
02d701ec: adrp    x21, #0x662f000                            
02d701f0: ldr     x20, [x19, #0x40]                          ._tfPanel
02d701f4: ldrb    w8, [x21, #0x91a]                          
02d701f8: cbnz    w8, #0x2d70210                             
02d701fc: adrp    x0, #0x6264000                             
02d70200: ldr     x0, [x0, #0xd8]                            T:UnityEngine.Vector3
02d70204: bl      #0x2b70db0                                 fn_2b70db0
02d70208: mov     w8, #1                                     
02d7020c: strb    w8, [x21, #0x91a]                          
02d70210: cbz     x20, #0x2d70254                            
02d70214: adrp    x8, #0x6264000                             
02d70218: mov     x0, x20                                    
02d7021c: mov     x1, xzr                                    
02d70220: ldr     x8, [x8, #0xd8]                            T:UnityEngine.Vector3
02d70224: ldr     x8, [x8]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d70228: ldr     x8, [x8, #0xb8]                            MS:DG.Tweening.Core.Extensions::SetSpecialStartupMode
02d7022c: ldp     s1, s2, [x8, #4]                           
02d70230: ldr     s0, [x8]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d70234: bl      #0x5b470cc                                 UnityEngine.Transform::set_localScale
02d70238: ldr     x0, [x19, #0x48]                           ._btnClose
02d7023c: cbz     x0, #0x2d70254                             
02d70240: ldp     x20, x19, [sp, #0x10]                      
02d70244: mov     w1, wzr                                    
02d70248: mov     x2, xzr                                    
02d7024c: ldp     x30, x21, [sp], #0x20                      
02d70250: b       #0x5e662d4                                 UnityEngine.UI.Selectable::set_interactable
02d70254: bl      #0x2b7105c                                 fn_2b7105c
## OnShow() -> void
---- Clicker.PopupItemLocked::OnShow 0x2d70258
02d70258: str     x30, [sp, #-0x40]!                         
02d7025c: stp     x24, x23, [sp, #0x10]                      
02d70260: stp     x22, x21, [sp, #0x20]                      
02d70264: stp     x20, x19, [sp, #0x30]                      
02d70268: adrp    x23, #0x6266000                            
02d7026c: adrp    x24, #0x6630000                            
02d70270: adrp    x20, #0x6264000                            
02d70274: adrp    x21, #0x626c000                            
02d70278: adrp    x22, #0x6266000                            
02d7027c: ldr     x23, [x23, #0x880]                         MS:DG.Tweening.TweenSettingsExtensions::SetEase
02d70280: ldr     x20, [x20, #0xe8]                          T:DG.Tweening.TweenCallback
02d70284: ldrb    w8, [x24, #0x39d]                          
02d70288: ldr     x21, [x21, #0x550]                         M:Clicker.PopupItemLocked::<OnShow>b__4_0
02d7028c: ldr     x22, [x22, #0x928]                         MS:DG.Tweening.TweenSettingsExtensions::OnComplete
02d70290: mov     x19, x0                                    
02d70294: tbnz    w8, #0, #0x2d702d0                         
02d70298: adrp    x0, #0x626c000                             
02d7029c: ldr     x0, [x0, #0x550]                           M:Clicker.PopupItemLocked::<OnShow>b__4_0
02d702a0: bl      #0x2b70db0                                 fn_2b70db0
02d702a4: adrp    x0, #0x6264000                             
02d702a8: ldr     x0, [x0, #0xe8]                            T:DG.Tweening.TweenCallback
02d702ac: bl      #0x2b70db0                                 fn_2b70db0
02d702b0: adrp    x0, #0x6266000                             
02d702b4: ldr     x0, [x0, #0x928]                           MS:DG.Tweening.TweenSettingsExtensions::OnComplete
02d702b8: bl      #0x2b70db0                                 fn_2b70db0
02d702bc: adrp    x0, #0x6266000                             
02d702c0: ldr     x0, [x0, #0x880]                           MS:DG.Tweening.TweenSettingsExtensions::SetEase
02d702c4: bl      #0x2b70db0                                 fn_2b70db0
02d702c8: mov     w8, #1                                     
02d702cc: strb    w8, [x24, #0x39d]                          
02d702d0: mov     x0, x19                                    
02d702d4: mov     x1, xzr                                    
02d702d8: bl      #0x2cdd6b8                                 UIBase::OnShow
02d702dc: adrp    x8, #0x1084000                             
02d702e0: fmov    s0, #1.00000000                            
02d702e4: ldr     x0, [x19, #0x40]                           ._tfPanel
02d702e8: ldr     s1, [x8, #0xdd8]                           [1084dd8]=3f7333333e4ccccd f=0.2,0.95
02d702ec: mov     x1, xzr                                    
02d702f0: bl      #0x2d98c98                                 DG.Tweening.ShortcutExtensions::DOScale
02d702f4: ldr     x2, [x23]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d702f8: mov     w1, #0x1b                                  
02d702fc: bl      #0x336fa0c                                 fn_336fa0c
02d70300: ldr     x8, [x20]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d70304: mov     x20, x0                                    
02d70308: mov     x0, x8                                     
02d7030c: bl      #0x2b7104c                                 fn_2b7104c
02d70310: ldr     x2, [x21]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d70314: mov     x1, x19                                    
02d70318: mov     x3, xzr                                    
02d7031c: mov     x21, x0                                    
02d70320: bl      #0x2d89dc4                                 DG.Tweening.TweenCallback::.ctor
02d70324: ldr     x2, [x22]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d70328: mov     x0, x20                                    
02d7032c: mov     x1, x21                                    
02d70330: ldp     x20, x19, [sp, #0x30]                      
02d70334: ldp     x22, x21, [sp, #0x20]                      
02d70338: ldp     x24, x23, [sp, #0x10]                      
02d7033c: ldr     x30, [sp], #0x40                           
02d70340: b       #0x336f26c                                 
## ShowWithItem(UnityEngine.Sprite sprite) -> void
---- Clicker.PopupItemLocked::ShowWithItem 0x2d70344
02d70344: ldr     x0, [x0, #0x38]                            ._imgItem
02d70348: cbz     x0, #0x2d70354                             
02d7034c: mov     x2, xzr                                    
02d70350: b       #0x5c45aa0                                 UnityEngine.UI.Image::set_sprite
02d70354: str     x30, [sp, #-0x10]!                         
02d70358: bl      #0x2b7105c                                 fn_2b7105c
## OnCloseClick() -> void
---- Clicker.PopupItemLocked::OnCloseClick 0x2d7035c
02d7035c: str     x30, [sp, #-0x30]!                         
02d70360: stp     x22, x21, [sp, #0x10]                      
02d70364: stp     x20, x19, [sp, #0x20]                      
02d70368: adrp    x20, #0x6630000                            
02d7036c: mov     x19, x0                                    
02d70370: ldrb    w8, [x20, #0x39e]                          
02d70374: tbnz    w8, #0, #0x2d703a4                         
02d70378: adrp    x0, #0x626c000                             
02d7037c: ldr     x0, [x0, #0x558]                           M:Clicker.PopupItemLocked::<OnCloseClick>b__6_0
02d70380: bl      #0x2b70db0                                 fn_2b70db0
02d70384: adrp    x0, #0x6264000                             
02d70388: ldr     x0, [x0, #0xe8]                            T:DG.Tweening.TweenCallback
02d7038c: bl      #0x2b70db0                                 fn_2b70db0
02d70390: adrp    x0, #0x6266000                             
02d70394: ldr     x0, [x0, #0x928]                           MS:DG.Tweening.TweenSettingsExtensions::OnComplete
02d70398: bl      #0x2b70db0                                 fn_2b70db0
02d7039c: mov     w8, #1                                     
02d703a0: strb    w8, [x20, #0x39e]                          
02d703a4: bl      #0x2d6eec8                                 Framework.AudioManager::get_Instance
02d703a8: cbz     x0, #0x2d70448                             
02d703ac: movi    d1, #0000000000000000                      
02d703b0: movi    d2, #0000000000000000                      
02d703b4: mov     w1, #1                                     
02d703b8: fmov    s0, #1.00000000                            
02d703bc: mov     w2, wzr                                    
02d703c0: mov     w3, wzr                                    
02d703c4: bl      #0x2d6f03c                                 Framework.AudioManager::PlaySound
02d703c8: ldr     x0, [x19, #0x48]                           ._btnClose
02d703cc: cbz     x0, #0x2d70448                             
02d703d0: adrp    x20, #0x6264000                            
02d703d4: adrp    x21, #0x626c000                            
02d703d8: adrp    x22, #0x6266000                            
02d703dc: ldr     x20, [x20, #0xe8]                          T:DG.Tweening.TweenCallback
02d703e0: ldr     x21, [x21, #0x558]                         M:Clicker.PopupItemLocked::<OnCloseClick>b__6_0
02d703e4: ldr     x22, [x22, #0x928]                         MS:DG.Tweening.TweenSettingsExtensions::OnComplete
02d703e8: mov     w1, wzr                                    
02d703ec: mov     x2, xzr                                    
02d703f0: bl      #0x5e662d4                                 UnityEngine.UI.Selectable::set_interactable
02d703f4: movi    d0, #0000000000000000                      
02d703f8: movi    d1, #0000000000000000                      
02d703fc: ldr     x0, [x19, #0x40]                           ._tfPanel
02d70400: mov     x1, xzr                                    
02d70404: bl      #0x2d98c98                                 DG.Tweening.ShortcutExtensions::DOScale
02d70408: ldr     x8, [x20]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d7040c: mov     x20, x0                                    
02d70410: mov     x0, x8                                     
02d70414: bl      #0x2b7104c                                 fn_2b7104c
02d70418: ldr     x2, [x21]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d7041c: mov     x1, x19                                    
02d70420: mov     x3, xzr                                    
02d70424: mov     x21, x0                                    
02d70428: bl      #0x2d89dc4                                 DG.Tweening.TweenCallback::.ctor
02d7042c: ldr     x2, [x22]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d70430: mov     x0, x20                                    
02d70434: mov     x1, x21                                    
02d70438: ldp     x20, x19, [sp, #0x20]                      
02d7043c: ldp     x22, x21, [sp, #0x10]                      
02d70440: ldr     x30, [sp], #0x30                           
02d70444: b       #0x336f26c                                 
02d70448: bl      #0x2b7105c                                 fn_2b7105c
## .ctor() -> void
---- Clicker.PopupItemLocked::.ctor 0x2d7044c
02d7044c: mov     x1, xzr                                    
02d70450: b       #0x2cddba8                                 PopupBase::.ctor
## <OnShow>b__4_0() -> void
---- Clicker.PopupItemLocked::<OnShow>b__4_0 0x2d70454
02d70454: ldr     x0, [x0, #0x48]                            ._btnClose
02d70458: cbz     x0, #0x2d70468                             
02d7045c: mov     w1, #1                                     
02d70460: mov     x2, xzr                                    
02d70464: b       #0x5e662d4                                 UnityEngine.UI.Selectable::set_interactable
02d70468: str     x30, [sp, #-0x10]!                         
02d7046c: bl      #0x2b7105c                                 fn_2b7105c
## <OnCloseClick>b__6_0() -> void
---- Clicker.PopupItemLocked::<OnCloseClick>b__6_0 0x2d70470
02d70470: ldr     x8, [x0]                                   
02d70474: ldp     x2, x1, [x8, #0x198]                       
02d70478: br      x2                                         
