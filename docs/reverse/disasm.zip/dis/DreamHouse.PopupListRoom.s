#### CLASS DreamHouse.PopupListRoom parent= PopupBase
#   field _btnClose                      UnityEngine.UI.Button                              off=0x38 attr=1 SerializeField
#   field _panel                         UnityEngine.RectTransform                          off=0x40 attr=1 SerializeField
#   field _roomItemPrefab                DreamHouse.RoomItemUI                              off=0x48 attr=1 SerializeField
#   field _content                       UnityEngine.RectTransform                          off=0x50 attr=1 SerializeField
#   field _roomItems                     System.Collections.Generic.List`1<DreamHouse.RoomItemUI> off=0x58 attr=1 SerializeField
#   field _dreamHouseAsset               DreamHouse.DreamHouseAsset                         off=0x60 attr=1 
#   field _selectedRoomItem              DreamHouse.RoomItemUI                              off=0x68 attr=1 
#   field _dreamHouseController          DreamHouse.DreamHouseController                    off=0x70 attr=1 
## OnDestroy() -> void
---- DreamHouse.PopupListRoom::OnDestroy 0x2d1b3dc
02d1b3dc: stp     x30, x23, [sp, #-0x30]!                    
02d1b3e0: stp     x22, x21, [sp, #0x10]                      
02d1b3e4: stp     x20, x19, [sp, #0x20]                      
02d1b3e8: adrp    x20, #0x6630000                            
02d1b3ec: mov     x19, x0                                    
02d1b3f0: ldrb    w8, [x20, #0xa]                            
02d1b3f4: tbnz    w8, #0, #0x2d1b424                         
02d1b3f8: adrp    x0, #0x6269000                             
02d1b3fc: ldr     x0, [x0, #0xb80]                           M:DreamHouse.PopupListRoom::OnButtonCloseClicked
02d1b400: bl      #0x2b70db0                                 fn_2b70db0
02d1b404: adrp    x0, #0x6269000                             
02d1b408: ldr     x0, [x0, #0xb88]                           M:DreamHouse.PopupListRoom::OnRoomInitializedCallback
02d1b40c: bl      #0x2b70db0                                 fn_2b70db0
02d1b410: adrp    x0, #0x6265000                             
02d1b414: ldr     x0, [x0, #0x3f0]                           T:UnityEngine.Events.UnityAction
02d1b418: bl      #0x2b70db0                                 fn_2b70db0
02d1b41c: mov     w8, #1                                     
02d1b420: strb    w8, [x20, #0xa]                            
02d1b424: ldr     x8, [x19, #0x38]                           ._btnClose
02d1b428: cbz     x8, #0x2d1b4ac                             
02d1b42c: adrp    x22, #0x6265000                            
02d1b430: adrp    x21, #0x6269000                            
02d1b434: ldr     x22, [x22, #0x3f0]                         T:UnityEngine.Events.UnityAction
02d1b438: ldr     x21, [x21, #0xb80]                         M:DreamHouse.PopupListRoom::OnButtonCloseClicked
02d1b43c: ldr     x20, [x8, #0x100]                          
02d1b440: ldr     x0, [x22]                                  M:AdsManager::<OnApplicationPause>b__26_0
02d1b444: bl      #0x2b7104c                                 fn_2b7104c
02d1b448: ldr     x2, [x21]                                  T:Trading.TradingSession/<>c__DisplayClass56_0
02d1b44c: mov     x1, x19                                    
02d1b450: mov     x3, xzr                                    
02d1b454: mov     x21, x0                                    
02d1b458: bl      #0x5b4cf98                                 UnityEngine.Events.UnityAction::.ctor
02d1b45c: cbz     x20, #0x2d1b4ac                            
02d1b460: adrp    x23, #0x6269000                            
02d1b464: mov     x0, x20                                    
02d1b468: mov     x1, x21                                    
02d1b46c: ldr     x23, [x23, #0xb88]                         M:DreamHouse.PopupListRoom::OnRoomInitializedCallback
02d1b470: mov     x2, xzr                                    
02d1b474: bl      #0x5b4d13c                                 UnityEngine.Events.UnityEvent::RemoveListener
02d1b478: ldr     x0, [x22]                                  M:AdsManager::<OnApplicationPause>b__26_0
02d1b47c: bl      #0x2b7104c                                 fn_2b7104c
02d1b480: ldr     x2, [x23]                                  T:Trading.TradingSession/<>c__DisplayClass56_0
02d1b484: mov     x1, x19                                    
02d1b488: mov     x3, xzr                                    
02d1b48c: mov     x20, x0                                    
02d1b490: bl      #0x5b4cf98                                 UnityEngine.Events.UnityAction::.ctor
02d1b494: mov     x0, x20                                    
02d1b498: ldp     x20, x19, [sp, #0x20]                      
02d1b49c: ldp     x22, x21, [sp, #0x10]                      
02d1b4a0: mov     x1, xzr                                    
02d1b4a4: ldp     x30, x23, [sp], #0x30                      
02d1b4a8: b       #0x2d187ac                                 DreamHouse.RoomController::remove_OnInitialized
02d1b4ac: bl      #0x2b7105c                                 fn_2b7105c
## OnInit(UIManager uiManager) -> void
---- DreamHouse.PopupListRoom::OnInit 0x2d1b4b0
02d1b4b0: sub     sp, sp, #0xa0                              
02d1b4b4: stp     x29, x30, [sp, #0x40]                      
02d1b4b8: stp     x28, x27, [sp, #0x50]                      
02d1b4bc: stp     x26, x25, [sp, #0x60]                      
02d1b4c0: stp     x24, x23, [sp, #0x70]                      
02d1b4c4: stp     x22, x21, [sp, #0x80]                      
02d1b4c8: stp     x20, x19, [sp, #0x90]                      
02d1b4cc: adrp    x21, #0x6630000                            
02d1b4d0: mov     x20, x1                                    
02d1b4d4: mov     x19, x0                                    
02d1b4d8: ldrb    w8, [x21, #0xb]                            
02d1b4dc: tbnz    w8, #0, #0x2d1b5b4                         
02d1b4e0: adrp    x0, #0x6269000                             
02d1b4e4: ldr     x0, [x0, #0xb90]                           T:type7005(k15)
02d1b4e8: bl      #0x2b70db0                                 fn_2b70db0
02d1b4ec: adrp    x0, #0x6269000                             
02d1b4f0: ldr     x0, [x0, #0x9e0]                           MS:DataManager::GetAsset
02d1b4f4: bl      #0x2b70db0                                 fn_2b70db0
02d1b4f8: adrp    x0, #0x6269000                             
02d1b4fc: ldr     x0, [x0, #0xb98]                           MS:System.Collections.Generic.List`1/Enumerator::Dispose
02d1b500: bl      #0x2b70db0                                 fn_2b70db0
02d1b504: adrp    x0, #0x6269000                             
02d1b508: ldr     x0, [x0, #0xba0]                           MS:System.Collections.Generic.List`1/Enumerator::MoveNext
02d1b50c: bl      #0x2b70db0                                 fn_2b70db0
02d1b510: adrp    x0, #0x6269000                             
02d1b514: ldr     x0, [x0, #0xba8]                           MS:System.Collections.Generic.List`1/Enumerator::get_Current
02d1b518: bl      #0x2b70db0                                 fn_2b70db0
02d1b51c: adrp    x0, #0x6269000                             
02d1b520: ldr     x0, [x0, #0xbb0]                           MS:System.Collections.Generic.List`1::Add
02d1b524: bl      #0x2b70db0                                 fn_2b70db0
02d1b528: adrp    x0, #0x6269000                             
02d1b52c: ldr     x0, [x0, #0xbb8]                           MS:System.Collections.Generic.List`1::GetEnumerator
02d1b530: bl      #0x2b70db0                                 fn_2b70db0
02d1b534: adrp    x0, #0x6269000                             
02d1b538: ldr     x0, [x0, #0xbc0]                           MS:System.Collections.Generic.List`1::.ctor
02d1b53c: bl      #0x2b70db0                                 fn_2b70db0
02d1b540: adrp    x0, #0x6269000                             
02d1b544: ldr     x0, [x0, #0xbc8]                           T:type56799(k15)
02d1b548: bl      #0x2b70db0                                 fn_2b70db0
02d1b54c: adrp    x0, #0x6269000                             
02d1b550: ldr     x0, [x0, #0xac0]                           MS:MonoSingleton`1::get_Instance
02d1b554: bl      #0x2b70db0                                 fn_2b70db0
02d1b558: adrp    x0, #0x6266000                             
02d1b55c: ldr     x0, [x0, #0x658]                           MS:MonoSingleton`1::get_Instance
02d1b560: bl      #0x2b70db0                                 fn_2b70db0
02d1b564: adrp    x0, #0x6269000                             
02d1b568: ldr     x0, [x0, #0xbd0]                           MS:UnityEngine.Object::Instantiate
02d1b56c: bl      #0x2b70db0                                 fn_2b70db0
02d1b570: adrp    x0, #0x6263000                             
02d1b574: ldr     x0, [x0, #0x918]                           T:UnityEngine.Object
02d1b578: bl      #0x2b70db0                                 fn_2b70db0
02d1b57c: adrp    x0, #0x6269000                             
02d1b580: ldr     x0, [x0, #0xb80]                           M:DreamHouse.PopupListRoom::OnButtonCloseClicked
02d1b584: bl      #0x2b70db0                                 fn_2b70db0
02d1b588: adrp    x0, #0x6269000                             
02d1b58c: ldr     x0, [x0, #0xb88]                           M:DreamHouse.PopupListRoom::OnRoomInitializedCallback
02d1b590: bl      #0x2b70db0                                 fn_2b70db0
02d1b594: adrp    x0, #0x6269000                             
02d1b598: ldr     x0, [x0, #0xbd8]                           M:DreamHouse.PopupListRoom::OnSelectRoomCallback
02d1b59c: bl      #0x2b70db0                                 fn_2b70db0
02d1b5a0: adrp    x0, #0x6265000                             
02d1b5a4: ldr     x0, [x0, #0x3f0]                           T:UnityEngine.Events.UnityAction
02d1b5a8: bl      #0x2b70db0                                 fn_2b70db0
02d1b5ac: mov     w8, #1                                     
02d1b5b0: strb    w8, [x21, #0xb]                            
02d1b5b4: mov     x0, x19                                    
02d1b5b8: mov     x1, x20                                    
02d1b5bc: mov     x2, xzr                                    
02d1b5c0: stp     xzr, xzr, [sp, #0x20]                      
02d1b5c4: str     xzr, [sp, #0x30]                           
02d1b5c8: bl      #0x2cdd3c4                                 UIBase::OnInit
02d1b5cc: ldr     x8, [x19, #0x38]                           ._btnClose
02d1b5d0: cbz     x8, #0x2d1b854                             
02d1b5d4: adrp    x22, #0x6265000                            
02d1b5d8: adrp    x21, #0x6269000                            
02d1b5dc: ldr     x22, [x22, #0x3f0]                         T:UnityEngine.Events.UnityAction
02d1b5e0: ldr     x21, [x21, #0xb80]                         M:DreamHouse.PopupListRoom::OnButtonCloseClicked
02d1b5e4: ldr     x20, [x8, #0x100]                          
02d1b5e8: ldr     x0, [x22]                                  M:AdsManager::<OnApplicationPause>b__26_0
02d1b5ec: bl      #0x2b7104c                                 fn_2b7104c
02d1b5f0: ldr     x2, [x21]                                  T:Trading.TradingSession/<>c__DisplayClass56_0
02d1b5f4: mov     x1, x19                                    
02d1b5f8: mov     x3, xzr                                    
02d1b5fc: mov     x21, x0                                    
02d1b600: bl      #0x5b4cf98                                 UnityEngine.Events.UnityAction::.ctor
02d1b604: cbz     x20, #0x2d1b854                            
02d1b608: adrp    x23, #0x6269000                            
02d1b60c: adrp    x24, #0x6269000                            
02d1b610: adrp    x25, #0x6266000                            
02d1b614: ldr     x23, [x23, #0xb88]                         M:DreamHouse.PopupListRoom::OnRoomInitializedCallback
02d1b618: ldr     x24, [x24, #0xac0]                         MS:MonoSingleton`1::get_Instance
02d1b61c: ldr     x25, [x25, #0x658]                         MS:MonoSingleton`1::get_Instance
02d1b620: mov     x0, x20                                    
02d1b624: mov     x1, x21                                    
02d1b628: mov     x2, xzr                                    
02d1b62c: bl      #0x5b4d0ac                                 UnityEngine.Events.UnityEvent::AddListener
02d1b630: ldr     x0, [x22]                                  M:AdsManager::<OnApplicationPause>b__26_0
02d1b634: bl      #0x2b7104c                                 fn_2b7104c
02d1b638: ldr     x2, [x23]                                  T:Trading.TradingSession/<>c__DisplayClass56_0
02d1b63c: mov     x1, x19                                    
02d1b640: mov     x3, xzr                                    
02d1b644: mov     x20, x0                                    
02d1b648: bl      #0x5b4cf98                                 UnityEngine.Events.UnityAction::.ctor
02d1b64c: mov     x0, x20                                    
02d1b650: mov     x1, xzr                                    
02d1b654: bl      #0x2d186f4                                 DreamHouse.RoomController::add_OnInitialized
02d1b658: ldr     x0, [x24]                                  T:Trading.TradingSession/<>c__DisplayClass56_0
02d1b65c: bl      #0x3769600                                 fn_3769600
02d1b660: mov     x1, x0                                     
02d1b664: mov     x0, x19                                    
02d1b668: str     x1, [x0, #0x70]!                           ._dreamHouseController
02d1b66c: bl      #0x2b70d54                                 fn_2b70d54
02d1b670: ldr     x0, [x25]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d1b674: bl      #0x3769600                                 fn_3769600
02d1b678: cbz     x0, #0x2d1b854                             
02d1b67c: adrp    x8, #0x6269000                             
02d1b680: adrp    x20, #0x6269000                            
02d1b684: adrp    x22, #0x6269000                            
02d1b688: ldr     x8, [x8, #0x9e0]                           MS:DataManager::GetAsset
02d1b68c: ldr     x20, [x20, #0xbc8]                         T:type56799(k15)
02d1b690: ldr     x22, [x22, #0xbc0]                         MS:System.Collections.Generic.List`1::.ctor
02d1b694: ldr     x1, [x8]                                   T:Trading.TradingSession/<>c__DisplayClass56_0
02d1b698: bl      #0x3168af0                                 fn_3168af0
02d1b69c: mov     x21, x19                                   
02d1b6a0: mov     x1, x0                                     
02d1b6a4: str     x0, [x21, #0x60]!                          ._dreamHouseAsset
02d1b6a8: mov     x0, x21                                    
02d1b6ac: bl      #0x2b70d54                                 fn_2b70d54
02d1b6b0: ldr     x0, [x20]                                  T:Trading.TradingSession/<>c__DisplayClass56_0
02d1b6b4: bl      #0x2b7104c                                 fn_2b7104c
02d1b6b8: ldr     x1, [x22]                                  T:Trading.TradingSession/<>c__DisplayClass56_0
02d1b6bc: mov     x22, x0                                    
02d1b6c0: bl      #0x35a89a4                                 fn_35a89a4
02d1b6c4: mov     x20, x19                                   
02d1b6c8: mov     x1, x22                                    
02d1b6cc: str     x22, [x20, #0x58]!                         ._roomItems
02d1b6d0: mov     x0, x20                                    
02d1b6d4: bl      #0x2b70d54                                 fn_2b70d54
02d1b6d8: ldr     x8, [x21]                                  T:Trading.TradingSession/<>c__DisplayClass56_0
02d1b6dc: cbz     x8, #0x2d1b854                             
02d1b6e0: ldr     x0, [x8, #0x18]                            M:Trading.TradingSession::<ValidateTrade>b__57_0
02d1b6e4: cbz     x0, #0x2d1b854                             
02d1b6e8: adrp    x8, #0x6269000                             
02d1b6ec: adrp    x25, #0x6269000                            
02d1b6f0: adrp    x26, #0x6263000                            
02d1b6f4: ldr     x8, [x8, #0xbb8]                           MS:System.Collections.Generic.List`1::GetEnumerator
02d1b6f8: adrp    x27, #0x6269000                            
02d1b6fc: adrp    x28, #0x6269000                            
02d1b700: adrp    x29, #0x6269000                            
02d1b704: adrp    x24, #0x6269000                            
02d1b708: ldr     x25, [x25, #0xba0]                         MS:System.Collections.Generic.List`1/Enumerator::MoveNext
02d1b70c: ldr     x26, [x26, #0x918]                         T:UnityEngine.Object
02d1b710: ldr     x27, [x27, #0xbd0]                         MS:UnityEngine.Object::Instantiate
02d1b714: ldr     x28, [x28, #0xb90]                         T:type7005(k15)
02d1b718: ldr     x29, [x29, #0xbd8]                         M:DreamHouse.PopupListRoom::OnSelectRoomCallback
02d1b71c: ldr     x24, [x24, #0xbb0]                         MS:System.Collections.Generic.List`1::Add
02d1b720: ldr     x1, [x8]                                   T:Trading.TradingSession/<>c__DisplayClass56_0
02d1b724: add     x8, sp, #8                                 
02d1b728: bl      #0x35a9d9c                                 fn_35a9d9c
02d1b72c: ldr     x8, [sp, #0x18]                            
02d1b730: ldur    q0, [sp, #8]                               
02d1b734: str     x8, [sp, #0x30]                            
02d1b738: add     x8, sp, #0x20                              
02d1b73c: str     q0, [sp, #0x20]                            
02d1b740: stp     xzr, x8, [sp, #8]                          
02d1b744: ldr     x1, [x25]                                  T:Trading.TradingSession/<>c__DisplayClass56_0
02d1b748: add     x0, sp, #0x20                              
02d1b74c: bl      #0x4690474                                 fn_4690474
02d1b750: tbz     w0, #0, #0x2d1b818                         
02d1b754: ldr     x0, [x26]                                  &2c5bbd4(=a9bd7bfdd503233f)
02d1b758: ldp     x21, x23, [x19, #0x48]                     ._roomItemPrefab
02d1b75c: ldr     x22, [sp, #0x30]                           
02d1b760: ldr     w8, [x0, #0xe4]                            [62650e4]=0 f=0,0
02d1b764: cbnz    w8, #0x2d1b76c                             
02d1b768: bl      #0x2b70f30                                 fn_2b70f30
02d1b76c: ldr     x2, [x27]                                  T:Trading.TradingSession/<>c__DisplayClass56_0
02d1b770: mov     x0, x21                                    
02d1b774: mov     x1, x23                                    
02d1b778: bl      #0x3275fcc                                 fn_3275fcc
02d1b77c: mov     x21, x0                                    
02d1b780: ldr     x0, [x28]                                  T:Trading.TradingSession/<>c__DisplayClass56_0
02d1b784: bl      #0x2b7104c                                 fn_2b7104c
02d1b788: mov     x23, x0                                    
02d1b78c: ldr     x2, [x29]                                  T:Trading.TradingSession/<>c__DisplayClass56_0
02d1b790: mov     x1, x19                                    
02d1b794: mov     x3, xzr                                    
02d1b798: bl      #0x453418c                                 fn_453418c
02d1b79c: cbz     x21, #0x2d1b850                            
02d1b7a0: mov     x0, x21                                    
02d1b7a4: mov     x1, x22                                    
02d1b7a8: mov     x2, x23                                    
02d1b7ac: bl      #0x2d1b8cc                                 DreamHouse.RoomItemUI::OnInit
02d1b7b0: ldr     x0, [x20]                                  T:Trading.TradingSession/<>c__DisplayClass56_0
02d1b7b4: cbz     x0, #0x2d1b84c                             
02d1b7b8: ldr     w10, [x0, #0x1c]                           [626501c]=0 f=0,0
02d1b7bc: ldr     x8, [x0, #0x10]                            MS:MonoSingleton`1::get_Instance
02d1b7c0: ldr     x9, [x24]                                  T:Trading.TradingSession/<>c__DisplayClass56_0
02d1b7c4: add     w10, w10, #1                               
02d1b7c8: str     w10, [x0, #0x1c]                           
02d1b7cc: cbz     x8, #0x2d1b84c                             
02d1b7d0: ldrsw   x10, [x0, #0x18]                           
02d1b7d4: ldr     w11, [x8, #0x18]                           M:Trading.TradingSession::<ValidateTrade>b__57_0
02d1b7d8: cmp     w10, w11                                   
02d1b7dc: b.hs    #0x2d1b800                                 
02d1b7e0: add     x8, x8, x10, lsl #3                        &6269000
02d1b7e4: add     w9, w10, #1                                
02d1b7e8: str     w9, [x0, #0x18]                            
02d1b7ec: str     x21, [x8, #0x20]!                          
02d1b7f0: mov     x0, x8                                     
02d1b7f4: mov     x1, x21                                    
02d1b7f8: bl      #0x2b70d54                                 fn_2b70d54
02d1b7fc: b       #0x2d1b744                                 
02d1b800: ldr     x8, [x9, #0x20]                            
02d1b804: ldr     x8, [x8, #0xc0]                            MS:System.Linq.Enumerable::Select
02d1b808: ldr     x2, [x8, #0x70]                            T:Trading.TradingSession/<>c__DisplayClass63_0
02d1b80c: mov     x1, x21                                    
02d1b810: bl      #0x35a920c                                 fn_35a920c
02d1b814: b       #0x2d1b744                                 
02d1b818: adrp    x8, #0x6269000                             
02d1b81c: add     x0, sp, #0x20                              
02d1b820: ldr     x8, [x8, #0xb98]                           MS:System.Collections.Generic.List`1/Enumerator::Dispose
02d1b824: ldr     x1, [x8]                                   T:Trading.TradingSession/<>c__DisplayClass56_0
02d1b828: bl      #0x4690470                                 fn_4690470
02d1b82c: ldp     x20, x19, [sp, #0x90]                      
02d1b830: ldp     x22, x21, [sp, #0x80]                      
02d1b834: ldp     x24, x23, [sp, #0x70]                      
02d1b838: ldp     x26, x25, [sp, #0x60]                      
02d1b83c: ldp     x28, x27, [sp, #0x50]                      
02d1b840: ldp     x29, x30, [sp, #0x40]                      
02d1b844: add     sp, sp, #0xa0                              
02d1b848: ret                                                
02d1b84c: bl      #0x2b7105c                                 fn_2b7105c
02d1b850: bl      #0x2b7105c                                 fn_2b7105c
02d1b854: bl      #0x2b7105c                                 fn_2b7105c
02d1b858: b       #0x2d1b874                                 
02d1b85c: b       #0x2d1b874                                 
02d1b860: b       #0x2d1b874                                 
02d1b864: b       #0x2d1b874                                 
02d1b868: b       #0x2d1b874                                 
02d1b86c: b       #0x2d1b874                                 
02d1b870: b       #0x2d1b874                                 
02d1b874: mov     x19, x0                                    
02d1b878: cmp     w1, #1                                     
02d1b87c: b.ne    #0x2d1b8b8                                 
02d1b880: mov     x0, x19                                    
02d1b884: bl      #0x5e90260                                 fn_5e90260
02d1b888: ldr     x19, [x0]                                  M:AdsManager::<OnApplicationPause>b__26_0
02d1b88c: str     x19, [sp, #8]                              
02d1b890: bl      #0x5e90270                                 fn_5e90270
02d1b894: adrp    x8, #0x6269000                             
02d1b898: ldr     x0, [sp, #0x10]                            
02d1b89c: ldr     x8, [x8, #0xb98]                           MS:System.Collections.Generic.List`1/Enumerator::Dispose
02d1b8a0: ldr     x1, [x8]                                   T:Trading.TradingSession/<>c__DisplayClass56_0
02d1b8a4: bl      #0x4690470                                 fn_4690470
02d1b8a8: cbz     x19, #0x2d1b82c                            
02d1b8ac: mov     x0, x19                                    
02d1b8b0: bl      #0x2b71054                                 fn_2b71054
02d1b8b4: mov     x19, x0                                    
02d1b8b8: add     x0, sp, #8                                 
02d1b8bc: bl      #0x273806c                                 fn_273806c
02d1b8c0: mov     x0, x19                                    
02d1b8c4: bl      #0x2c6051c                                 fn_2c6051c
02d1b8c8: bl      #0x27369b8                                 fn_27369b8
## OnShow() -> void
---- DreamHouse.PopupListRoom::OnShow 0x2d1ba00
02d1ba00: stp     x30, x21, [sp, #-0x20]!                    
02d1ba04: stp     x20, x19, [sp, #0x10]                      
02d1ba08: adrp    x21, #0x6630000                            
02d1ba0c: adrp    x20, #0x6265000                            
02d1ba10: mov     x19, x0                                    
02d1ba14: ldrb    w8, [x21, #0xc]                            
02d1ba18: ldr     x20, [x20, #0x310]                         MS:WejoyService.Singleton`1::get_Instance
02d1ba1c: tbnz    w8, #0, #0x2d1ba34                         
02d1ba20: adrp    x0, #0x6265000                             
02d1ba24: ldr     x0, [x0, #0x310]                           MS:WejoyService.Singleton`1::get_Instance
02d1ba28: bl      #0x2b70db0                                 fn_2b70db0
02d1ba2c: mov     w8, #1                                     
02d1ba30: strb    w8, [x21, #0xc]                            
02d1ba34: mov     x0, x19                                    
02d1ba38: mov     x1, xzr                                    
02d1ba3c: bl      #0x2cdd6b8                                 UIBase::OnShow
02d1ba40: mov     x0, x19                                    
02d1ba44: bl      #0x2d1ba68                                 DreamHouse.PopupListRoom::Refresh
02d1ba48: ldr     x0, [x20]                                  M:AdsManager::<OnApplicationPause>b__26_0
02d1ba4c: bl      #0x3be7218                                 fn_3be7218
02d1ba50: cbz     x0, #0x2d1ba64                             
02d1ba54: ldp     x20, x19, [sp, #0x10]                      
02d1ba58: mov     x1, xzr                                    
02d1ba5c: ldp     x30, x21, [sp], #0x20                      
02d1ba60: b       #0x2c8a7a4                                 AdsManager::ShowCollap
02d1ba64: bl      #0x2b7105c                                 fn_2b7105c
## Refresh() -> void
---- DreamHouse.PopupListRoom::Refresh 0x2d1ba68
02d1ba68: stp     x30, x21, [sp, #-0x20]!                    
02d1ba6c: stp     x20, x19, [sp, #0x10]                      
02d1ba70: adrp    x20, #0x6630000                            
02d1ba74: adrp    x21, #0x6266000                            
02d1ba78: mov     x19, x0                                    
02d1ba7c: ldrb    w8, [x20, #0xd]                            
02d1ba80: ldr     x21, [x21, #0x658]                         MS:MonoSingleton`1::get_Instance
02d1ba84: tbnz    w8, #0, #0x2d1bac0                         
02d1ba88: adrp    x0, #0x6269000                             
02d1ba8c: ldr     x0, [x0, #0x9e8]                           MS:DataManager::GetData
02d1ba90: bl      #0x2b70db0                                 fn_2b70db0
02d1ba94: adrp    x0, #0x6269000                             
02d1ba98: ldr     x0, [x0, #0xbf0]                           MS:System.Collections.Generic.List`1::get_Count
02d1ba9c: bl      #0x2b70db0                                 fn_2b70db0
02d1baa0: adrp    x0, #0x6269000                             
02d1baa4: ldr     x0, [x0, #0xbf8]                           MS:System.Collections.Generic.List`1::get_Item
02d1baa8: bl      #0x2b70db0                                 fn_2b70db0
02d1baac: adrp    x0, #0x6266000                             
02d1bab0: ldr     x0, [x0, #0x658]                           MS:MonoSingleton`1::get_Instance
02d1bab4: bl      #0x2b70db0                                 fn_2b70db0
02d1bab8: mov     w8, #1                                     
02d1babc: strb    w8, [x20, #0xd]                            
02d1bac0: ldr     x0, [x21]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d1bac4: bl      #0x3769600                                 fn_3769600
02d1bac8: cbz     x0, #0x2d1bb20                             
02d1bacc: adrp    x8, #0x6269000                             
02d1bad0: ldr     x8, [x8, #0x9e8]                           MS:DataManager::GetData
02d1bad4: ldr     x1, [x8]                                   T:Trading.TradingSession/<>c__DisplayClass56_0
02d1bad8: bl      #0x3168dd0                                 fn_3168dd0
02d1badc: ldr     x0, [x19, #0x58]                           ._roomItems
02d1bae0: cbz     x0, #0x2d1bb20                             
02d1bae4: adrp    x21, #0x6269000                            
02d1bae8: mov     w20, wzr                                   
02d1baec: ldr     x21, [x21, #0xbf8]                         MS:System.Collections.Generic.List`1::get_Item
02d1baf0: ldr     w8, [x0, #0x18]                            S:'level_show_popuprate'
02d1baf4: cmp     w20, w8                                    
02d1baf8: b.ge    #0x2d1bb24                                 
02d1bafc: ldr     x2, [x21]                                  T:Trading.TradingSession/<>c__DisplayClass56_0
02d1bb00: mov     w1, w20                                    
02d1bb04: bl      #0x35a8f3c                                 fn_35a8f3c
02d1bb08: cbz     x0, #0x2d1bb20                             
02d1bb0c: mov     w1, #1                                     
02d1bb10: bl      #0x2d1bb30                                 DreamHouse.RoomItemUI::SetUnlocked
02d1bb14: ldr     x0, [x19, #0x58]                           ._roomItems
02d1bb18: add     w20, w20, #1                               
02d1bb1c: cbnz    x0, #0x2d1baf0                             
02d1bb20: bl      #0x2b7105c                                 fn_2b7105c
02d1bb24: ldp     x20, x19, [sp, #0x10]                      
02d1bb28: ldp     x30, x21, [sp], #0x20                      
02d1bb2c: ret                                                
## OnRoomInitializedCallback() -> void
---- DreamHouse.PopupListRoom::OnRoomInitializedCallback 0x2d1bba4
02d1bba4: str     x30, [sp, #-0x20]!                         
02d1bba8: stp     x20, x19, [sp, #0x10]                      
02d1bbac: adrp    x20, #0x6630000                            
02d1bbb0: mov     x19, x0                                    
02d1bbb4: ldrb    w8, [x20, #0xe]                            
02d1bbb8: tbnz    w8, #0, #0x2d1bbd0                         
02d1bbbc: adrp    x0, #0x6269000                             
02d1bbc0: ldr     x0, [x0, #0xbf8]                           MS:System.Collections.Generic.List`1::get_Item
02d1bbc4: bl      #0x2b70db0                                 fn_2b70db0
02d1bbc8: mov     w8, #1                                     
02d1bbcc: strb    w8, [x20, #0xe]                            
02d1bbd0: ldr     x8, [x19, #0x70]                           ._dreamHouseController
02d1bbd4: cbz     x8, #0x2d1bc28                             
02d1bbd8: ldr     x8, [x8, #0x40]                            
02d1bbdc: cbz     x8, #0x2d1bc28                             
02d1bbe0: ldr     x0, [x19, #0x60]                           ._dreamHouseAsset
02d1bbe4: cbz     x0, #0x2d1bc28                             
02d1bbe8: ldr     x1, [x8, #0x40]                            
02d1bbec: mov     x2, xzr                                    
02d1bbf0: bl      #0x2d15a14                                 DreamHouse.DreamHouseAsset::GetRoomConfigIndex
02d1bbf4: ldr     x8, [x19, #0x58]                           ._roomItems
02d1bbf8: cbz     x8, #0x2d1bc28                             
02d1bbfc: adrp    x9, #0x6269000                             
02d1bc00: mov     w1, w0                                     
02d1bc04: mov     x0, x8                                     
02d1bc08: ldr     x9, [x9, #0xbf8]                           MS:System.Collections.Generic.List`1::get_Item
02d1bc0c: ldr     x2, [x9]                                   T:Trading.TradingSession/<>c__DisplayClass56_0
02d1bc10: bl      #0x35a8f3c                                 fn_35a8f3c
02d1bc14: mov     x1, x0                                     
02d1bc18: mov     x0, x19                                    
02d1bc1c: ldp     x20, x19, [sp, #0x10]                      
02d1bc20: ldr     x30, [sp], #0x20                           
02d1bc24: b       #0x2d1bc2c                                 DreamHouse.PopupListRoom::SetSelectedRoom
02d1bc28: bl      #0x2b7105c                                 fn_2b7105c
## SetSelectedRoom(DreamHouse.RoomItemUI roomItem) -> void
---- DreamHouse.PopupListRoom::SetSelectedRoom 0x2d1bc2c
02d1bc2c: str     x30, [sp, #-0x30]!                         
02d1bc30: stp     x22, x21, [sp, #0x10]                      
02d1bc34: stp     x20, x19, [sp, #0x20]                      
02d1bc38: adrp    x21, #0x6630000                            
02d1bc3c: adrp    x22, #0x6263000                            
02d1bc40: mov     x19, x1                                    
02d1bc44: ldrb    w8, [x21, #0xf]                            
02d1bc48: ldr     x22, [x22, #0x918]                         T:UnityEngine.Object
02d1bc4c: mov     x20, x0                                    
02d1bc50: tbnz    w8, #0, #0x2d1bc68                         
02d1bc54: adrp    x0, #0x6263000                             
02d1bc58: ldr     x0, [x0, #0x918]                           T:UnityEngine.Object
02d1bc5c: bl      #0x2b70db0                                 fn_2b70db0
02d1bc60: mov     w8, #1                                     
02d1bc64: strb    w8, [x21, #0xf]                            
02d1bc68: ldr     x0, [x22]                                  &2c5bbd4(=a9bd7bfdd503233f)
02d1bc6c: ldr     x21, [x20, #0x68]!                         ._selectedRoomItem
02d1bc70: ldr     w8, [x0, #0xe4]                            [62630e4]=0 f=0,0
02d1bc74: cbnz    w8, #0x2d1bc7c                             
02d1bc78: bl      #0x2b70f30                                 fn_2b70f30
02d1bc7c: mov     x0, x21                                    
02d1bc80: mov     x1, xzr                                    
02d1bc84: mov     x2, xzr                                    
02d1bc88: bl      #0x5b3666c                                 UnityEngine.Object::op_Inequality
02d1bc8c: tbz     w0, #0, #0x2d1bcd4                         
02d1bc90: ldr     x0, [x22]                                  &2c5bbd4(=a9bd7bfdd503233f)
02d1bc94: ldr     x21, [x20]                                 
02d1bc98: ldr     w8, [x0, #0xe4]                            [62630e4]=0 f=0,0
02d1bc9c: cbnz    w8, #0x2d1bca4                             
02d1bca0: bl      #0x2b70f30                                 fn_2b70f30
02d1bca4: mov     x0, x21                                    
02d1bca8: mov     x1, x19                                    
02d1bcac: mov     x2, xzr                                    
02d1bcb0: bl      #0x5b3666c                                 UnityEngine.Object::op_Inequality
02d1bcb4: tbz     w0, #0, #0x2d1bcd4                         
02d1bcb8: ldr     x8, [x20]                                  
02d1bcbc: cbz     x8, #0x2d1bd0c                             
02d1bcc0: ldr     x0, [x8, #0x38]                            
02d1bcc4: cbz     x0, #0x2d1bd0c                             
02d1bcc8: mov     w1, wzr                                    
02d1bccc: mov     x2, xzr                                    
02d1bcd0: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d1bcd4: mov     x0, x20                                    
02d1bcd8: mov     x1, x19                                    
02d1bcdc: str     x19, [x20]                                 
02d1bce0: bl      #0x2b70d54                                 fn_2b70d54
02d1bce4: ldr     x8, [x20]                                  
02d1bce8: cbz     x8, #0x2d1bd0c                             
02d1bcec: ldr     x0, [x8, #0x38]                            
02d1bcf0: cbz     x0, #0x2d1bd0c                             
02d1bcf4: ldp     x20, x19, [sp, #0x20]                      
02d1bcf8: mov     w1, #1                                     
02d1bcfc: ldp     x22, x21, [sp, #0x10]                      
02d1bd00: mov     x2, xzr                                    
02d1bd04: ldr     x30, [sp], #0x30                           
02d1bd08: b       #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d1bd0c: bl      #0x2b7105c                                 fn_2b7105c
## OnSelectRoomCallback(DreamHouse.RoomItemUI selectedRoom) -> void
---- DreamHouse.PopupListRoom::OnSelectRoomCallback 0x2d1bd2c
02d1bd2c: stp     x30, x21, [sp, #-0x20]!                    
02d1bd30: stp     x20, x19, [sp, #0x10]                      
02d1bd34: adrp    x21, #0x6630000                            
02d1bd38: mov     x20, x1                                    
02d1bd3c: mov     x19, x0                                    
02d1bd40: ldrb    w8, [x21, #0x10]                           
02d1bd44: tbnz    w8, #0, #0x2d1bd68                         
02d1bd48: adrp    x0, #0x6269000                             
02d1bd4c: ldr     x0, [x0, #0xc00]                           MS:System.Collections.Generic.List`1::IndexOf
02d1bd50: bl      #0x2b70db0                                 fn_2b70db0
02d1bd54: adrp    x0, #0x6263000                             
02d1bd58: ldr     x0, [x0, #0x918]                           T:UnityEngine.Object
02d1bd5c: bl      #0x2b70db0                                 fn_2b70db0
02d1bd60: mov     w8, #1                                     
02d1bd64: strb    w8, [x21, #0x10]                           
02d1bd68: mov     x0, xzr                                    
02d1bd6c: bl      #0x2d6eec8                                 Framework.AudioManager::get_Instance
02d1bd70: cbz     x0, #0x2d1be5c                             
02d1bd74: movi    d1, #0000000000000000                      
02d1bd78: movi    d2, #0000000000000000                      
02d1bd7c: adrp    x21, #0x6263000                            
02d1bd80: fmov    s0, #1.00000000                            
02d1bd84: ldr     x21, [x21, #0x918]                         T:UnityEngine.Object
02d1bd88: mov     w1, #1                                     
02d1bd8c: mov     w2, wzr                                    
02d1bd90: mov     w3, wzr                                    
02d1bd94: mov     x4, xzr                                    
02d1bd98: bl      #0x2d6f03c                                 Framework.AudioManager::PlaySound
02d1bd9c: ldr     x0, [x21]                                  &2c5bbd4(=a9bd7bfdd503233f)
02d1bda0: ldr     x21, [x19, #0x68]                          ._selectedRoomItem
02d1bda4: ldr     w8, [x0, #0xe4]                            [62630e4]=0 f=0,0
02d1bda8: cbnz    w8, #0x2d1bdb0                             
02d1bdac: bl      #0x2b70f30                                 fn_2b70f30
02d1bdb0: mov     x0, x21                                    
02d1bdb4: mov     x1, x20                                    
02d1bdb8: mov     x2, xzr                                    
02d1bdbc: bl      #0x5b37d84                                 UnityEngine.Object::op_Equality
02d1bdc0: tbz     w0, #0, #0x2d1bdd0                         
02d1bdc4: ldp     x20, x19, [sp, #0x10]                      
02d1bdc8: ldp     x30, x21, [sp], #0x20                      
02d1bdcc: ret                                                
02d1bdd0: ldr     x0, [x19, #0x58]                           ._roomItems
02d1bdd4: cbz     x0, #0x2d1be5c                             
02d1bdd8: adrp    x8, #0x6269000                             
02d1bddc: mov     x1, x20                                    
02d1bde0: ldr     x8, [x8, #0xc00]                           MS:System.Collections.Generic.List`1::IndexOf
02d1bde4: ldr     x2, [x8]                                   T:Trading.TradingSession/<>c__DisplayClass56_0
02d1bde8: bl      #0x35a9f48                                 fn_35a9f48
02d1bdec: ldr     x8, [x19, #0x70]                           ._dreamHouseController
02d1bdf0: cbz     x8, #0x2d1be5c                             
02d1bdf4: mov     w21, w0                                    
02d1bdf8: ldr     x0, [x8, #0x30]                            MS:System.Collections.Generic.Dictionary`2::set_Item
02d1bdfc: cbz     x0, #0x2d1be5c                             
02d1be00: mov     w1, w21                                    
02d1be04: mov     x2, xzr                                    
02d1be08: bl      #0x2d166d0                                 DreamHouse.DataDreamHouse::SetCurrentRoomIndex
02d1be0c: ldr     x8, [x19, #0x70]                           ._dreamHouseController
02d1be10: cbz     x8, #0x2d1be5c                             
02d1be14: ldr     x0, [x8, #0x30]                            MS:System.Collections.Generic.Dictionary`2::set_Item
02d1be18: cbz     x0, #0x2d1be5c                             
02d1be1c: mov     x1, xzr                                    
02d1be20: bl      #0x2d170d8                                 DreamHouse.DataDreamHouse::LoadCurrentRoomSteps
02d1be24: ldr     x0, [x19, #0x70]                           ._dreamHouseController
02d1be28: cbz     x0, #0x2d1be5c                             
02d1be2c: mov     w1, w21                                    
02d1be30: mov     x2, xzr                                    
02d1be34: bl      #0x2d17cbc                                 DreamHouse.DreamHouseController::StartRoom
02d1be38: mov     x0, x19                                    
02d1be3c: mov     x1, x20                                    
02d1be40: bl      #0x2d1bc2c                                 DreamHouse.PopupListRoom::SetSelectedRoom
02d1be44: ldr     x8, [x19]                                  
02d1be48: mov     x0, x19                                    
02d1be4c: ldp     x20, x19, [sp, #0x10]                      
02d1be50: ldp     x2, x1, [x8, #0x198]                       
02d1be54: ldp     x30, x21, [sp], #0x20                      
02d1be58: br      x2                                         
02d1be5c: bl      #0x2b7105c                                 fn_2b7105c
## OnButtonCloseClicked() -> void
---- DreamHouse.PopupListRoom::OnButtonCloseClicked 0x2d1be60
02d1be60: stp     x30, x19, [sp, #-0x10]!                    
02d1be64: mov     x19, x0                                    
02d1be68: mov     x0, xzr                                    
02d1be6c: bl      #0x2d6eec8                                 Framework.AudioManager::get_Instance
02d1be70: cbz     x0, #0x2d1bea8                             
02d1be74: movi    d1, #0000000000000000                      
02d1be78: movi    d2, #0000000000000000                      
02d1be7c: mov     w1, #1                                     
02d1be80: fmov    s0, #1.00000000                            
02d1be84: mov     w2, wzr                                    
02d1be88: mov     w3, wzr                                    
02d1be8c: mov     x4, xzr                                    
02d1be90: bl      #0x2d6f03c                                 Framework.AudioManager::PlaySound
02d1be94: ldr     x8, [x19]                                  
02d1be98: mov     x0, x19                                    
02d1be9c: ldp     x2, x1, [x8, #0x198]                       
02d1bea0: ldp     x30, x19, [sp], #0x10                      
02d1bea4: br      x2                                         
02d1bea8: bl      #0x2b7105c                                 fn_2b7105c
## .ctor() -> void
---- DreamHouse.PopupListRoom::.ctor 0x2d1beac
02d1beac: mov     x1, xzr                                    
02d1beb0: b       #0x2cddba8                                 PopupBase::.ctor
