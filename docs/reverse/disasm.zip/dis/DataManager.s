#### CLASS DataManager/<>c__10`1 parent= object
#   field <>9                            DataManager/<>c__10`1<T>                           off=0x0 attr=36 
#   field <>9__10_0                      System.Predicate`1<UnityEngine.ScriptableObject>   off=0x0 attr=16 
##  .cctor (no body)
##  .ctor (no body)
##  <GetAsset>b__10_0 (no body)
#### CLASS DataManager/<>c__11`1 parent= object
#   field <>9                            DataManager/<>c__11`1<T>                           off=0x0 attr=36 
#   field <>9__11_0                      System.Predicate`1<GameData>                       off=0x0 attr=16 
##  .cctor (no body)
##  .ctor (no body)
##  <GetData>b__11_0 (no body)
#### CLASS DataManager parent= MonoSingleton`1<DataManager>
#   field SaveType                       ESaveType                                          off=0x20 attr=6 
#   field AssetsList                     System.Collections.Generic.List`1<UnityEngine.ScriptableObject> off=0x28 attr=6 
#   field GameDatasList                  System.Collections.Generic.List`1<GameData>        off=0x30 attr=6 
#   field FLUSH_INTERVAL                 float                                              off=0x0 attr=8051 
#   field _lastSavedData                 System.Collections.Generic.Dictionary`2<string,string> off=0x38 attr=21 
#   field _isPrefsDirty                  bool                                               off=0x40 attr=1 
#   field _flushTimer                    float                                              off=0x44 attr=1 
#   field OnBeforeSaveAll                System.Action                                      off=0x0 attr=11 CompilerGeneratedAttribute
## get__savePath() -> string
---- DataManager::get__savePath 0x2ca9ce0
02ca9ce0: str     x30, [sp, #-0x20]!                         
02ca9ce4: stp     x20, x19, [sp, #0x10]                      
02ca9ce8: adrp    x20, #0x662f000                            
02ca9cec: adrp    x19, #0x6266000                            
02ca9cf0: ldrb    w8, [x20, #0xb10]                          
02ca9cf4: ldr     x19, [x19, #0x748]                         S:'/Save'
02ca9cf8: tbnz    w8, #0, #0x2ca9d10                         
02ca9cfc: adrp    x0, #0x6266000                             
02ca9d00: ldr     x0, [x0, #0x748]                           S:'/Save'
02ca9d04: bl      #0x2b70db0                                 fn_2b70db0
02ca9d08: mov     w8, #1                                     
02ca9d0c: strb    w8, [x20, #0xb10]                          
02ca9d10: mov     x0, xzr                                    
02ca9d14: bl      #0x2cc162c                                 Framework.PathUtils::GetDataPath
02ca9d18: ldr     x1, [x19]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca9d1c: ldp     x20, x19, [sp, #0x10]                      
02ca9d20: mov     x2, xzr                                    
02ca9d24: ldr     x30, [sp], #0x20                           
02ca9d28: b       #0x4c9c514                                 System.String::Concat
## get_IsFirstGameSession() -> bool
---- DataManager::get_IsFirstGameSession 0x2ca9d2c
02ca9d2c: str     x30, [sp, #-0x20]!                         
02ca9d30: stp     x20, x19, [sp, #0x10]                      
02ca9d34: adrp    x19, #0x662f000                            
02ca9d38: adrp    x20, #0x6266000                            
02ca9d3c: ldrb    w8, [x19, #0xb11]                          
02ca9d40: ldr     x20, [x20, #0x658]                         MS:MonoSingleton`1::get_Instance
02ca9d44: tbnz    w8, #0, #0x2ca9d68                         
02ca9d48: adrp    x0, #0x6266000                             
02ca9d4c: ldr     x0, [x0, #0x750]                           MS:DataManager::GetData
02ca9d50: bl      #0x2b70db0                                 fn_2b70db0
02ca9d54: adrp    x0, #0x6266000                             
02ca9d58: ldr     x0, [x0, #0x658]                           MS:MonoSingleton`1::get_Instance
02ca9d5c: bl      #0x2b70db0                                 fn_2b70db0
02ca9d60: mov     w8, #1                                     
02ca9d64: strb    w8, [x19, #0xb11]                          
02ca9d68: ldr     x0, [x20]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca9d6c: bl      #0x3769600                                 fn_3769600
02ca9d70: cbz     x0, #0x2ca9da8                             
02ca9d74: adrp    x8, #0x6266000                             
02ca9d78: ldr     x8, [x8, #0x750]                           MS:DataManager::GetData
02ca9d7c: ldr     x1, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca9d80: bl      #0x3168dd0                                 fn_3168dd0
02ca9d84: cbz     x0, #0x2ca9da8                             
02ca9d88: ldr     x8, [x0, #0x20]                            S:'inter_ad_capping_time' .SaveType
02ca9d8c: cbz     x8, #0x2ca9da8                             
02ca9d90: ldrb    w8, [x8, #0x3a]                            
02ca9d94: ldp     x20, x19, [sp, #0x10]                      
02ca9d98: cmp     w8, #0                                     
02ca9d9c: cset    w0, eq                                     
02ca9da0: ldr     x30, [sp], #0x20                           
02ca9da4: ret                                                
02ca9da8: bl      #0x2b7105c                                 fn_2b7105c
## DeleteSave() -> void
---- DataManager::DeleteSave 0x2ca9dac
02ca9dac: str     x30, [sp, #-0x20]!                         
02ca9db0: stp     x20, x19, [sp, #0x10]                      
02ca9db4: adrp    x20, #0x662f000                            
02ca9db8: mov     x19, x0                                    
02ca9dbc: ldrb    w8, [x20, #0xb12]                          
02ca9dc0: tbnz    w8, #0, #0x2ca9dfc                         
02ca9dc4: adrp    x0, #0x6263000                             
02ca9dc8: ldr     x0, [x0, #0x928]                           T:UnityEngine.Debug
02ca9dcc: bl      #0x2b70db0                                 fn_2b70db0
02ca9dd0: adrp    x0, #0x6266000                             
02ca9dd4: ldr     x0, [x0, #0x758]                           MS:System.Collections.Generic.Dictionary`2::Clear
02ca9dd8: bl      #0x2b70db0                                 fn_2b70db0
02ca9ddc: adrp    x0, #0x6266000                             
02ca9de0: ldr     x0, [x0, #0x760]                           S:'Folder exists. Deleting the folder...'
02ca9de4: bl      #0x2b70db0                                 fn_2b70db0
02ca9de8: adrp    x0, #0x6266000                             
02ca9dec: ldr     x0, [x0, #0x768]                           S:'Folder deleted.'
02ca9df0: bl      #0x2b70db0                                 fn_2b70db0
02ca9df4: mov     w8, #1                                     
02ca9df8: strb    w8, [x20, #0xb12]                          
02ca9dfc: ldr     x0, [x19, #0x38]                           ._lastSavedData
02ca9e00: cbz     x0, #0x2ca9f2c                             
02ca9e04: adrp    x8, #0x6266000                             
02ca9e08: ldr     x8, [x8, #0x758]                           MS:System.Collections.Generic.Dictionary`2::Clear
02ca9e0c: ldr     x1, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca9e10: bl      #0x452c7a4                                 fn_452c7a4
02ca9e14: ldr     w8, [x19, #0x20]                           .SaveType
02ca9e18: cmp     w8, #1                                     
02ca9e1c: b.eq    #0x2ca9e34                                 
02ca9e20: cbnz    w8, #0x2ca9e94                             
02ca9e24: ldp     x20, x19, [sp, #0x10]                      
02ca9e28: mov     x0, xzr                                    
02ca9e2c: ldr     x30, [sp], #0x20                           
02ca9e30: b       #0x5b2d8ec                                 UnityEngine.PlayerPrefs::DeleteAll
02ca9e34: bl      #0x2ca9ce0                                 DataManager::get__savePath
02ca9e38: mov     x1, xzr                                    
02ca9e3c: bl      #0x4dd8ac0                                 System.IO.Directory::Exists
02ca9e40: tbz     w0, #0, #0x2ca9e94                         
02ca9e44: adrp    x8, #0x6263000                             
02ca9e48: ldr     x8, [x8, #0x928]                           T:UnityEngine.Debug
02ca9e4c: ldr     x0, [x8]                                   &2c5bbd4(=a9bd7bfdd503233f)
02ca9e50: ldr     w8, [x0, #0xe4]                            [62660e4]=0 f=0,0
02ca9e54: cbnz    w8, #0x2ca9e5c                             
02ca9e58: bl      #0x2b70f30                                 fn_2b70f30
02ca9e5c: adrp    x8, #0x6266000                             
02ca9e60: ldr     x8, [x8, #0x760]                           S:'Folder exists. Deleting the folder...'
02ca9e64: ldr     x0, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca9e68: mov     x1, xzr                                    
02ca9e6c: bl      #0x5af21f4                                 UnityEngine.Debug::Log
02ca9e70: bl      #0x2ca9ce0                                 DataManager::get__savePath
02ca9e74: mov     w1, #1                                     
02ca9e78: mov     x2, xzr                                    
02ca9e7c: bl      #0x4dd90d0                                 System.IO.Directory::Delete
02ca9e80: adrp    x8, #0x6266000                             
02ca9e84: ldr     x8, [x8, #0x768]                           S:'Folder deleted.'
02ca9e88: ldr     x0, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca9e8c: mov     x1, xzr                                    
02ca9e90: bl      #0x5af21f4                                 UnityEngine.Debug::Log
02ca9e94: ldp     x20, x19, [sp, #0x10]                      
02ca9e98: ldr     x30, [sp], #0x20                           
02ca9e9c: ret                                                
02ca9ea0: b       #0x2ca9eac                                 
02ca9ea4: b       #0x2ca9eac                                 
02ca9ea8: b       #0x2ca9eac                                 
02ca9eac: mov     x19, x0                                    
02ca9eb0: cmp     w1, #1                                     
02ca9eb4: b.ne    #0x2ca9f58                                 
02ca9eb8: mov     x0, x19                                    
02ca9ebc: bl      #0x5e90260                                 fn_5e90260
02ca9ec0: mov     x19, x0                                    
02ca9ec4: adrp    x0, #0x6263000                             
02ca9ec8: ldr     x0, [x0, #0xae0]                           T:System.Exception
02ca9ecc: bl      #0x2b70dc4                                 fn_2b70dc4
02ca9ed0: ldr     x8, [x19]                                  
02ca9ed4: ldr     x1, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca9ed8: bl      #0x2b71464                                 fn_2b71464
02ca9edc: tbz     w0, #0, #0x2ca9f30                         
02ca9ee0: ldr     x19, [x19]                                 
02ca9ee4: bl      #0x5e90270                                 fn_5e90270
02ca9ee8: cbz     x19, #0x2ca9f2c                            
02ca9eec: ldr     x8, [x19]                                  
02ca9ef0: mov     x0, x19                                    
02ca9ef4: ldp     x9, x1, [x8, #0x188]                       
02ca9ef8: blr     x9                                         
02ca9efc: mov     x19, x0                                    
02ca9f00: adrp    x0, #0x6263000                             
02ca9f04: ldr     x0, [x0, #0x928]                           T:UnityEngine.Debug
02ca9f08: bl      #0x2b70dc4                                 fn_2b70dc4
02ca9f0c: ldr     w8, [x0, #0xe4]                            [62630e4]=0 f=0,0
02ca9f10: cbnz    w8, #0x2ca9f18                             
02ca9f14: bl      #0x2b70f30                                 fn_2b70f30
02ca9f18: mov     x0, x19                                    
02ca9f1c: ldp     x20, x19, [sp, #0x10]                      
02ca9f20: mov     x1, xzr                                    
02ca9f24: ldr     x30, [sp], #0x20                           
02ca9f28: b       #0x5af2840                                 UnityEngine.Debug::LogError
02ca9f2c: bl      #0x2b7105c                                 fn_2b7105c
02ca9f30: mov     w0, #8                                     
02ca9f34: bl      #0x5e90290                                 fn_5e90290
02ca9f38: ldr     x8, [x19]                                  
02ca9f3c: str     x8, [x0]                                   
02ca9f40: adrp    x1, #0x5e96000                             
02ca9f44: add     x1, x1, #0x758                             &5e96758
02ca9f48: mov     x2, xzr                                    
02ca9f4c: bl      #0x5e902a0                                 fn_5e902a0
02ca9f50: mov     x19, x0                                    
02ca9f54: bl      #0x5e90270                                 fn_5e90270
02ca9f58: mov     x0, x19                                    
02ca9f5c: bl      #0x2c6051c                                 fn_2c6051c
02ca9f60: bl      #0x27369b8                                 fn_27369b8
## CreateFolder() -> void
---- DataManager::CreateFolder 0x2ca9f64
02ca9f64: str     x30, [sp, #-0x20]!                         
02ca9f68: stp     x20, x19, [sp, #0x10]                      
02ca9f6c: adrp    x20, #0x662f000                            
02ca9f70: mov     x19, x0                                    
02ca9f74: ldrb    w8, [x20, #0xb13]                          
02ca9f78: tbnz    w8, #0, #0x2ca9f9c                         
02ca9f7c: adrp    x0, #0x6263000                             
02ca9f80: ldr     x0, [x0, #0x928]                           T:UnityEngine.Debug
02ca9f84: bl      #0x2b70db0                                 fn_2b70db0
02ca9f88: adrp    x0, #0x6266000                             
02ca9f8c: ldr     x0, [x0, #0x770]                           S:'save path : '
02ca9f90: bl      #0x2b70db0                                 fn_2b70db0
02ca9f94: mov     w8, #1                                     
02ca9f98: strb    w8, [x20, #0xb13]                          
02ca9f9c: ldr     w8, [x19, #0x20]                           .SaveType
02ca9fa0: cbz     w8, #0x2ca9fb4                             
02ca9fa4: bl      #0x2ca9ce0                                 DataManager::get__savePath
02ca9fa8: mov     x1, xzr                                    
02ca9fac: bl      #0x4dd8ac0                                 System.IO.Directory::Exists
02ca9fb0: tbz     w0, #0, #0x2ca9fc0                         
02ca9fb4: ldp     x20, x19, [sp, #0x10]                      
02ca9fb8: ldr     x30, [sp], #0x20                           
02ca9fbc: ret                                                
02ca9fc0: bl      #0x2ca9ce0                                 DataManager::get__savePath
02ca9fc4: mov     x1, xzr                                    
02ca9fc8: bl      #0x4dd8938                                 System.IO.Directory::CreateDirectory
02ca9fcc: bl      #0x2ca9ce0                                 DataManager::get__savePath
02ca9fd0: adrp    x8, #0x6266000                             
02ca9fd4: mov     x1, x0                                     
02ca9fd8: mov     x2, xzr                                    
02ca9fdc: ldr     x8, [x8, #0x770]                           S:'save path : '
02ca9fe0: ldr     x8, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca9fe4: mov     x0, x8                                     
02ca9fe8: bl      #0x4c9c514                                 System.String::Concat
02ca9fec: adrp    x8, #0x6263000                             
02ca9ff0: mov     x19, x0                                    
02ca9ff4: ldr     x8, [x8, #0x928]                           T:UnityEngine.Debug
02ca9ff8: ldr     x8, [x8]                                   &2c5bbd4(=a9bd7bfdd503233f)
02ca9ffc: ldr     w9, [x8, #0xe4]                            [62630e4]=0 f=0,0
02caa000: cbnz    w9, #0x2caa00c                             
02caa004: mov     x0, x8                                     
02caa008: bl      #0x2b70f30                                 fn_2b70f30
02caa00c: mov     x0, x19                                    
02caa010: ldp     x20, x19, [sp, #0x10]                      
02caa014: mov     x1, xzr                                    
02caa018: ldr     x30, [sp], #0x20                           
02caa01c: b       #0x5af21f4                                 UnityEngine.Debug::Log
## Initiate() -> void
---- DataManager::Initiate 0x2caa020
02caa020: sub     sp, sp, #0x90                              
02caa024: str     x30, [sp, #0x40]                           
02caa028: stp     x26, x25, [sp, #0x50]                      
02caa02c: stp     x24, x23, [sp, #0x60]                      
02caa030: stp     x22, x21, [sp, #0x70]                      
02caa034: stp     x20, x19, [sp, #0x80]                      
02caa038: adrp    x21, #0x662f000                            
02caa03c: adrp    x20, #0x6266000                            
02caa040: mov     x19, x0                                    
02caa044: ldrb    w8, [x21, #0xb14]                          
02caa048: ldr     x20, [x20, #0x778]                         MS:MonoSingleton`1::Initiate
02caa04c: tbnz    w8, #0, #0x2caa0b8                         
02caa050: adrp    x0, #0x6263000                             
02caa054: ldr     x0, [x0, #0x928]                           T:UnityEngine.Debug
02caa058: bl      #0x2b70db0                                 fn_2b70db0
02caa05c: adrp    x0, #0x6266000                             
02caa060: ldr     x0, [x0, #0x780]                           MS:System.Collections.Generic.List`1/Enumerator::Dispose
02caa064: bl      #0x2b70db0                                 fn_2b70db0
02caa068: adrp    x0, #0x6266000                             
02caa06c: ldr     x0, [x0, #0x788]                           MS:System.Collections.Generic.List`1/Enumerator::MoveNext
02caa070: bl      #0x2b70db0                                 fn_2b70db0
02caa074: adrp    x0, #0x6266000                             
02caa078: ldr     x0, [x0, #0x790]                           MS:System.Collections.Generic.List`1/Enumerator::get_Current
02caa07c: bl      #0x2b70db0                                 fn_2b70db0
02caa080: adrp    x0, #0x6266000                             
02caa084: ldr     x0, [x0, #0x798]                           MS:System.Collections.Generic.List`1::GetEnumerator
02caa088: bl      #0x2b70db0                                 fn_2b70db0
02caa08c: adrp    x0, #0x6266000                             
02caa090: ldr     x0, [x0, #0x778]                           MS:MonoSingleton`1::Initiate
02caa094: bl      #0x2b70db0                                 fn_2b70db0
02caa098: adrp    x0, #0x6263000                             
02caa09c: ldr     x0, [x0, #0xa80]                           T:type24502(k1d)
02caa0a0: bl      #0x2b70db0                                 fn_2b70db0
02caa0a4: adrp    x0, #0x6266000                             
02caa0a8: ldr     x0, [x0, #0x7a0]                           S:'{0} has Update!!'
02caa0ac: bl      #0x2b70db0                                 fn_2b70db0
02caa0b0: mov     w8, #1                                     
02caa0b4: strb    w8, [x21, #0xb14]                          
02caa0b8: ldr     x1, [x20]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02caa0bc: mov     x0, x19                                    
02caa0c0: stp     xzr, xzr, [sp, #0x20]                      
02caa0c4: str     xzr, [sp, #0x30]                           
02caa0c8: bl      #0x3769de4                                 fn_3769de4
02caa0cc: mov     x0, x19                                    
02caa0d0: bl      #0x2ca9f64                                 DataManager::CreateFolder
02caa0d4: ldr     x0, [x19, #0x30]                           .GameDatasList
02caa0d8: cbz     x0, #0x2caa288                             
02caa0dc: adrp    x8, #0x6266000                             
02caa0e0: adrp    x23, #0x6266000                            
02caa0e4: adrp    x24, #0x6263000                            
02caa0e8: ldr     x8, [x8, #0x798]                           MS:System.Collections.Generic.List`1::GetEnumerator
02caa0ec: adrp    x25, #0x6263000                            
02caa0f0: adrp    x26, #0x6266000                            
02caa0f4: adrp    x22, #0x6266000                            
02caa0f8: ldr     x23, [x23, #0x788]                         MS:System.Collections.Generic.List`1/Enumerator::MoveNext
02caa0fc: ldr     x24, [x24, #0xa80]                         T:type24502(k1d)
02caa100: ldr     x25, [x25, #0x928]                         T:UnityEngine.Debug
02caa104: ldr     x26, [x26, #0x7a0]                         S:'{0} has Update!!'
02caa108: ldr     x22, [x22, #0x780]                         MS:System.Collections.Generic.List`1/Enumerator::Dispose
02caa10c: ldr     x1, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02caa110: add     x8, sp, #8                                 
02caa114: bl      #0x35a9d9c                                 fn_35a9d9c
02caa118: ldr     x8, [sp, #0x18]                            
02caa11c: ldur    q0, [sp, #8]                               
02caa120: str     x8, [sp, #0x30]                            
02caa124: add     x8, sp, #0x20                              
02caa128: str     q0, [sp, #0x20]                            
02caa12c: stp     xzr, x8, [sp, #8]                          
02caa130: ldr     x1, [x23]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02caa134: add     x0, sp, #0x20                              
02caa138: bl      #0x4690474                                 fn_4690474
02caa13c: tbz     w0, #0, #0x2caa248                         
02caa140: ldr     x19, [sp, #0x30]                           
02caa144: cbz     x19, #0x2caa270                            
02caa148: ldr     x8, [x19]                                  
02caa14c: ldr     x1, [x8, #0x280]                           S:'  - '
02caa150: ldr     x9, [x8, #0x278]                           MS:System.Collections.Generic.List`1::get_Count
02caa154: mov     x0, x19                                    
02caa158: blr     x9                                         
02caa15c: ldr     x8, [x19]                                  
02caa160: tbz     w0, #0, #0x2caa20c                         
02caa164: ldr     x1, [x8, #0x290]                           S:'{0} products fetched from store.'
02caa168: ldr     x9, [x8, #0x288]                           S:' | '
02caa16c: mov     x0, x19                                    
02caa170: blr     x9                                         
02caa174: ldr     x8, [x19]                                  
02caa178: tbz     w0, #0, #0x2caa220                         
02caa17c: ldr     x1, [x8, #0x240]                           S:'Registering {0} product(s) with the store.'
02caa180: ldr     x9, [x8, #0x238]                           S:"Product '"
02caa184: mov     x0, x19                                    
02caa188: blr     x9                                         
02caa18c: ldr     x0, [x24]                                  &2c5bbd4(=a9bd7bfdd503233f)
02caa190: mov     w1, #1                                     
02caa194: bl      #0x2b70ea0                                 fn_2b70ea0
02caa198: ldr     x8, [x19]                                  
02caa19c: mov     x20, x0                                    
02caa1a0: ldr     x1, [x8, #0x2b0]                           T:type11754(k15)
02caa1a4: ldr     x9, [x8, #0x2a8]                           T:UnityEngine.Purchasing.ICart
02caa1a8: mov     x0, x19                                    
02caa1ac: blr     x9                                         
02caa1b0: cbz     x20, #0x2caa274                            
02caa1b4: mov     x21, x0                                    
02caa1b8: cbz     x0, #0x2caa1d0                             
02caa1bc: ldr     x8, [x20]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02caa1c0: ldr     x1, [x8, #0x40]                            S:'native_collap_ad_on_off'
02caa1c4: mov     x0, x21                                    
02caa1c8: bl      #0x2b70f34                                 fn_2b70f34
02caa1cc: cbz     x0, #0x2caa27c                             
02caa1d0: ldr     w8, [x20, #0x18]                           S:'level_show_popuprate'
02caa1d4: cbz     w8, #0x2caa278                             
02caa1d8: mov     x0, x20                                    
02caa1dc: str     x21, [x0, #0x20]!                          .SaveType
02caa1e0: mov     x1, x21                                    
02caa1e4: bl      #0x2b70d54                                 fn_2b70d54
02caa1e8: ldr     x0, [x25]                                  &2c5bbd4(=a9bd7bfdd503233f)
02caa1ec: ldr     w8, [x0, #0xe4]                            [62660e4]=0 f=0,0
02caa1f0: cbnz    w8, #0x2caa1f8                             
02caa1f4: bl      #0x2b70f30                                 fn_2b70f30
02caa1f8: ldr     x0, [x26]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02caa1fc: mov     x1, x20                                    
02caa200: mov     x2, xzr                                    
02caa204: bl      #0x5af2a60                                 UnityEngine.Debug::LogErrorFormat
02caa208: b       #0x2caa230                                 
02caa20c: ldr     x1, [x8, #0x230]                           T:UnityEngine.Purchasing.ProductDefinition
02caa210: ldr     x9, [x8, #0x228]                           T:type15233(k15)
02caa214: mov     x0, x19                                    
02caa218: blr     x9                                         
02caa21c: b       #0x2caa230                                 
02caa220: ldr     x1, [x8, #0x270]                           MS:System.Collections.Generic.List`1::GetEnumerator
02caa224: ldr     x9, [x8, #0x268]                           MS:System.Collections.Generic.List`1/Enumerator::get_Current
02caa228: mov     x0, x19                                    
02caa22c: blr     x9                                         
02caa230: ldr     x8, [x19]                                  
02caa234: ldr     x1, [x8, #0x220]                           MS:System.Collections.Generic.List`1::get_Count
02caa238: ldr     x9, [x8, #0x218]                           MS:System.Collections.Generic.List`1::.ctor
02caa23c: mov     x0, x19                                    
02caa240: blr     x9                                         
02caa244: b       #0x2caa130                                 
02caa248: ldr     x1, [x22]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02caa24c: add     x0, sp, #0x20                              
02caa250: bl      #0x4690470                                 fn_4690470
02caa254: ldp     x20, x19, [sp, #0x80]                      
02caa258: ldr     x30, [sp, #0x40]                           
02caa25c: ldp     x22, x21, [sp, #0x70]                      
02caa260: ldp     x24, x23, [sp, #0x60]                      
02caa264: ldp     x26, x25, [sp, #0x50]                      
02caa268: add     sp, sp, #0x90                              
02caa26c: ret                                                
02caa270: bl      #0x2b7105c                                 fn_2b7105c
02caa274: bl      #0x2b7105c                                 fn_2b7105c
02caa278: bl      #0x2b71064                                 fn_2b71064
02caa27c: bl      #0x2b71080                                 fn_2b71080
02caa280: mov     x1, xzr                                    
02caa284: bl      #0x2b70f20                                 fn_2b70f20
02caa288: bl      #0x2b7105c                                 fn_2b7105c
02caa28c: b       #0x2caa2b4                                 
02caa290: b       #0x2caa2b4                                 
02caa294: b       #0x2caa2b4                                 
02caa298: b       #0x2caa2b4                                 
02caa29c: b       #0x2caa2b4                                 
02caa2a0: b       #0x2caa2b4                                 
02caa2a4: b       #0x2caa2b4                                 
02caa2a8: b       #0x2caa2b4                                 
02caa2ac: b       #0x2caa2b4                                 
02caa2b0: b       #0x2caa2b4                                 
02caa2b4: mov     x19, x0                                    
02caa2b8: cmp     w1, #1                                     
02caa2bc: b.ne    #0x2caa2f0                                 
02caa2c0: mov     x0, x19                                    
02caa2c4: bl      #0x5e90260                                 fn_5e90260
02caa2c8: ldr     x19, [x0]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02caa2cc: str     x19, [sp, #8]                              
02caa2d0: bl      #0x5e90270                                 fn_5e90270
02caa2d4: ldr     x0, [sp, #0x10]                            
02caa2d8: ldr     x1, [x22]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02caa2dc: bl      #0x4690470                                 fn_4690470
02caa2e0: cbz     x19, #0x2caa254                            
02caa2e4: mov     x0, x19                                    
02caa2e8: bl      #0x2b71054                                 fn_2b71054
02caa2ec: mov     x19, x0                                    
02caa2f0: add     x0, sp, #8                                 
02caa2f4: bl      #0x2736fac                                 fn_2736fac
02caa2f8: mov     x0, x19                                    
02caa2fc: bl      #0x2c6051c                                 fn_2c6051c
02caa300: bl      #0x27369b8                                 fn_27369b8
##  GetAsset (no body)
##  GetData (no body)
## add_OnBeforeSaveAll(System.Action value) -> void
---- DataManager::add_OnBeforeSaveAll 0x2caa304
02caa304: str     x30, [sp, #-0x30]!                         
02caa308: stp     x22, x21, [sp, #0x10]                      
02caa30c: stp     x20, x19, [sp, #0x20]                      
02caa310: adrp    x20, #0x662f000                            
02caa314: adrp    x21, #0x6266000                            
02caa318: mov     x19, x0                                    
02caa31c: ldrb    w8, [x20, #0xb15]                          
02caa320: ldr     x21, [x21, #0x7a8]                         T:DataManager
02caa324: tbnz    w8, #0, #0x2caa348                         
02caa328: adrp    x0, #0x6264000                             
02caa32c: ldr     x0, [x0, #0xf90]                           T:System.Action
02caa330: bl      #0x2b70db0                                 fn_2b70db0
02caa334: adrp    x0, #0x6266000                             
02caa338: ldr     x0, [x0, #0x7a8]                           T:DataManager
02caa33c: bl      #0x2b70db0                                 fn_2b70db0
02caa340: mov     w8, #1                                     
02caa344: strb    w8, [x20, #0xb15]                          
02caa348: ldr     x8, [x21]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02caa34c: adrp    x22, #0x6264000                            
02caa350: ldr     x8, [x8, #0xb8]                            
02caa354: ldr     x22, [x22, #0xf90]                         T:System.Action
02caa358: ldr     x20, [x8]                                  
02caa35c: mov     x0, x20                                    
02caa360: mov     x1, x19                                    
02caa364: mov     x2, xzr                                    
02caa368: bl      #0x4e570ac                                 System.Delegate::Combine
02caa36c: mov     x8, x0                                     
02caa370: cbz     x0, #0x2caa384                             
02caa374: ldr     x1, [x22]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02caa378: ldr     x9, [x8]                                   
02caa37c: cmp     x9, x1                                     
02caa380: b.ne    #0x2caa3b4                                 
02caa384: ldr     x9, [x21]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02caa388: mov     x1, x8                                     
02caa38c: mov     x2, x20                                    
02caa390: ldr     x0, [x9, #0xb8]                            
02caa394: bl      #0x2ba9880                                 fn_2ba9880
02caa398: cmp     x0, x20                                    
02caa39c: mov     x20, x0                                    
02caa3a0: b.ne    #0x2caa35c                                 
02caa3a4: ldp     x20, x19, [sp, #0x20]                      
02caa3a8: ldp     x22, x21, [sp, #0x10]                      
02caa3ac: ldr     x30, [sp], #0x30                           
02caa3b0: ret                                                
02caa3b4: mov     x0, x8                                     
02caa3b8: bl      #0x2b713dc                                 fn_2b713dc
## remove_OnBeforeSaveAll(System.Action value) -> void
---- DataManager::remove_OnBeforeSaveAll 0x2caa3bc
02caa3bc: str     x30, [sp, #-0x30]!                         
02caa3c0: stp     x22, x21, [sp, #0x10]                      
02caa3c4: stp     x20, x19, [sp, #0x20]                      
02caa3c8: adrp    x20, #0x662f000                            
02caa3cc: adrp    x21, #0x6266000                            
02caa3d0: mov     x19, x0                                    
02caa3d4: ldrb    w8, [x20, #0xb16]                          
02caa3d8: ldr     x21, [x21, #0x7a8]                         T:DataManager
02caa3dc: tbnz    w8, #0, #0x2caa400                         
02caa3e0: adrp    x0, #0x6264000                             
02caa3e4: ldr     x0, [x0, #0xf90]                           T:System.Action
02caa3e8: bl      #0x2b70db0                                 fn_2b70db0
02caa3ec: adrp    x0, #0x6266000                             
02caa3f0: ldr     x0, [x0, #0x7a8]                           T:DataManager
02caa3f4: bl      #0x2b70db0                                 fn_2b70db0
02caa3f8: mov     w8, #1                                     
02caa3fc: strb    w8, [x20, #0xb16]                          
02caa400: ldr     x8, [x21]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02caa404: adrp    x22, #0x6264000                            
02caa408: ldr     x8, [x8, #0xb8]                            
02caa40c: ldr     x22, [x22, #0xf90]                         T:System.Action
02caa410: ldr     x20, [x8]                                  
02caa414: mov     x0, x20                                    
02caa418: mov     x1, x19                                    
02caa41c: mov     x2, xzr                                    
02caa420: bl      #0x4e57298                                 System.Delegate::Remove
02caa424: mov     x8, x0                                     
02caa428: cbz     x0, #0x2caa43c                             
02caa42c: ldr     x1, [x22]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02caa430: ldr     x9, [x8]                                   
02caa434: cmp     x9, x1                                     
02caa438: b.ne    #0x2caa46c                                 
02caa43c: ldr     x9, [x21]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02caa440: mov     x1, x8                                     
02caa444: mov     x2, x20                                    
02caa448: ldr     x0, [x9, #0xb8]                            
02caa44c: bl      #0x2ba9880                                 fn_2ba9880
02caa450: cmp     x0, x20                                    
02caa454: mov     x20, x0                                    
02caa458: b.ne    #0x2caa414                                 
02caa45c: ldp     x20, x19, [sp, #0x20]                      
02caa460: ldp     x22, x21, [sp, #0x10]                      
02caa464: ldr     x30, [sp], #0x30                           
02caa468: ret                                                
02caa46c: mov     x0, x8                                     
02caa470: bl      #0x2b713dc                                 fn_2b713dc
##  SaveData (no body)
## SaveDataToPlayerPrefs(string key, string data) -> void
---- DataManager::SaveDataToPlayerPrefs 0x2caa474
02caa474: stp     x30, x19, [sp, #-0x10]!                    
02caa478: mov     x19, x0                                    
02caa47c: mov     x0, x1                                     
02caa480: mov     x1, x2                                     
02caa484: mov     x2, xzr                                    
02caa488: bl      #0x5b2d398                                 UnityEngine.PlayerPrefs::SetString
02caa48c: mov     w8, #1                                     
02caa490: strb    w8, [x19, #0x40]                           ._isPrefsDirty
02caa494: ldp     x30, x19, [sp], #0x10                      
02caa498: ret                                                
## FlushData() -> void
---- DataManager::FlushData 0x2caa49c
02caa49c: ldrb    w9, [x0, #0x40]                            ._isPrefsDirty
02caa4a0: str     wzr, [x0, #0x44]                           ._flushTimer
02caa4a4: cbz     w9, #0x2caa4b8                             
02caa4a8: mov     x8, x0                                     
02caa4ac: mov     x0, xzr                                    
02caa4b0: strb    wzr, [x8, #0x40]                           
02caa4b4: b       #0x5b2d914                                 UnityEngine.PlayerPrefs::Save
02caa4b8: ret                                                
## Update() -> void
---- DataManager::Update 0x2caa4bc
02caa4bc: str     d8, [sp, #-0x20]!                          
02caa4c0: stp     x30, x19, [sp, #0x10]                      
02caa4c4: ldrb    w8, [x0, #0x40]                            ._isPrefsDirty
02caa4c8: cbz     w8, #0x2caa510                             
02caa4cc: mov     x19, x0                                    
02caa4d0: ldr     s8, [x0, #0x44]                            ._flushTimer
02caa4d4: mov     x0, xzr                                    
02caa4d8: bl      #0x5b4341c                                 UnityEngine.Time::get_unscaledDeltaTime
02caa4dc: fadd    s0, s8, s0                                 
02caa4e0: fmov    s1, #30.00000000                           
02caa4e4: fcmp    s0, s1                                     
02caa4e8: str     s0, [x19, #0x44]                           ._flushTimer
02caa4ec: b.lt    #0x2caa510                                 
02caa4f0: ldrb    w8, [x19, #0x40]                           ._isPrefsDirty
02caa4f4: str     wzr, [x19, #0x44]                          ._flushTimer
02caa4f8: cbz     w8, #0x2caa510                             
02caa4fc: strb    wzr, [x19, #0x40]                          ._isPrefsDirty
02caa500: ldp     x30, x19, [sp, #0x10]                      
02caa504: mov     x0, xzr                                    
02caa508: ldr     d8, [sp], #0x20                            
02caa50c: b       #0x5b2d914                                 UnityEngine.PlayerPrefs::Save
02caa510: ldp     x30, x19, [sp, #0x10]                      
02caa514: ldr     d8, [sp], #0x20                            
02caa518: ret                                                
## SaveDataToFile(string key, byte[] data) -> void
---- DataManager::SaveDataToFile 0x2caa51c
02caa51c: str     x30, [sp, #-0x30]!                         
02caa520: stp     x22, x21, [sp, #0x10]                      
02caa524: stp     x20, x19, [sp, #0x20]                      
02caa528: adrp    x22, #0x662f000                            
02caa52c: adrp    x21, #0x6264000                            
02caa530: mov     x19, x2                                    
02caa534: ldrb    w8, [x22, #0xb17]                          
02caa538: ldr     x21, [x21, #0xe48]                         S:'/'
02caa53c: mov     x20, x1                                    
02caa540: str     x2, [sp, #8]                               
02caa544: tbnz    w8, #0, #0x2caa55c                         
02caa548: adrp    x0, #0x6264000                             
02caa54c: ldr     x0, [x0, #0xe48]                           S:'/'
02caa550: bl      #0x2b70db0                                 fn_2b70db0
02caa554: mov     w8, #1                                     
02caa558: strb    w8, [x22, #0xb17]                          
02caa55c: bl      #0x2ca9ce0                                 DataManager::get__savePath
02caa560: ldr     x1, [x21]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02caa564: mov     x2, x20                                    
02caa568: mov     x3, xzr                                    
02caa56c: bl      #0x4ca6dbc                                 System.String::Concat
02caa570: add     x1, sp, #8                                 
02caa574: mov     x20, x0                                    
02caa578: bl      #0x2caa598                                 DataManager::SimpleEncrypt
02caa57c: mov     x0, x20                                    
02caa580: mov     x1, x19                                    
02caa584: mov     x2, xzr                                    
02caa588: ldp     x20, x19, [sp, #0x20]                      
02caa58c: ldp     x22, x21, [sp, #0x10]                      
02caa590: ldr     x30, [sp], #0x30                           
02caa594: b       #0x4dda7b8                                 System.IO.File::WriteAllBytes
## SimpleEncrypt(byte[] data) -> void
---- DataManager::SimpleEncrypt 0x2caa598
02caa598: stp     x30, x21, [sp, #-0x20]!                    
02caa59c: stp     x20, x19, [sp, #0x10]                      
02caa5a0: adrp    x20, #0x662f000                            
02caa5a4: adrp    x21, #0x6264000                            
02caa5a8: mov     x19, x1                                    
02caa5ac: ldrb    w8, [x20, #0xb18]                          
02caa5b0: ldr     x21, [x21, #0xa70]                         T:UnityEngine.Application
02caa5b4: tbnz    w8, #0, #0x2caa5d8                         
02caa5b8: adrp    x0, #0x6264000                             
02caa5bc: ldr     x0, [x0, #0xa70]                           T:UnityEngine.Application
02caa5c0: bl      #0x2b70db0                                 fn_2b70db0
02caa5c4: adrp    x0, #0x6266000                             
02caa5c8: ldr     x0, [x0, #0x7b0]                           M:DataManager::SimpleEncrypt
02caa5cc: bl      #0x2b70db0                                 fn_2b70db0
02caa5d0: mov     w8, #1                                     
02caa5d4: strb    w8, [x20, #0xb18]                          
02caa5d8: ldr     x0, [x21]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02caa5dc: ldr     w8, [x0, #0xe4]                            [62660e4]=0 f=0,0
02caa5e0: cbnz    w8, #0x2caa5e8                             
02caa5e4: bl      #0x2b70f30                                 fn_2b70f30
02caa5e8: mov     x0, xzr                                    
02caa5ec: bl      #0x5aed094                                 UnityEngine.Application::get_isEditor
02caa5f0: tbz     w0, #0, #0x2caa600                         
02caa5f4: ldp     x20, x19, [sp, #0x10]                      
02caa5f8: ldp     x30, x21, [sp], #0x20                      
02caa5fc: ret                                                
02caa600: mov     x0, xzr                                    
02caa604: bl      #0x4cbf4a8                                 System.Text.Encoding::get_UTF8
02caa608: mov     x20, x0                                    
02caa60c: mov     x0, xzr                                    
02caa610: bl      #0x5b409bc                                 UnityEngine.SystemInfo::get_deviceUniqueIdentifier
02caa614: cbz     x20, #0x2caa694                            
02caa618: ldr     x8, [x20]                                  &2b706c4(=eb01011ff9400808)
02caa61c: mov     x1, x0                                     
02caa620: mov     x0, x20                                    
02caa624: ldr     x9, [x8, #0x258]                           
02caa628: ldr     x2, [x8, #0x260]                           
02caa62c: blr     x9                                         
02caa630: cbz     x0, #0x2caa694                             
02caa634: ldr     x10, [x19]                                 
02caa638: cbz     x10, #0x2caa694                            
02caa63c: ldrsw   x8, [x0, #0x18]                            
02caa640: mov     x9, xzr                                    
02caa644: ldr     w11, [x10, #0x18]                          
02caa648: cmp     x9, w11, sxtw                              
02caa64c: b.ge    #0x2caa5f4                                 
02caa650: cmp     x9, x11                                    
02caa654: b.hs    #0x2caa698                                 
02caa658: sdiv    x11, x9, x8                                
02caa65c: ldr     w12, [x0, #0x18]                           S:'level_show_popuprate'
02caa660: nop                                                
02caa664: msub    x11, x11, x8, x9                           
02caa668: cmp     w11, w12                                   
02caa66c: b.hs    #0x2caa698                                 
02caa670: add     x10, x10, x9                               
02caa674: add     x11, x0, x11                               &6266000
02caa678: add     x9, x9, #1                                 
02caa67c: ldrb    w12, [x10, #0x20]                          
02caa680: ldrb    w11, [x11, #0x20]                          
02caa684: eor     w11, w11, w12                              
02caa688: strb    w11, [x10, #0x20]                          
02caa68c: ldr     x10, [x19]                                 
02caa690: cbnz    x10, #0x2caa644                            
02caa694: bl      #0x2b7105c                                 fn_2b7105c
02caa698: bl      #0x2b71064                                 fn_2b71064
##  LoadData (no body)
##  LoadDataFromPlayerPrefs (no body)
##  LoadDataFromFile (no body)
## HasData(string key) -> bool
---- DataManager::HasData 0x2caa69c
02caa69c: sub     sp, sp, #0x30                              
02caa6a0: stp     x30, x21, [sp, #0x10]                      
02caa6a4: stp     x20, x19, [sp, #0x20]                      
02caa6a8: adrp    x21, #0x662f000                            
02caa6ac: mov     x19, x1                                    
02caa6b0: mov     x20, x0                                    
02caa6b4: ldrb    w8, [x21, #0xb19]                          
02caa6b8: tbnz    w8, #0, #0x2caa6dc                         
02caa6bc: adrp    x0, #0x6266000                             
02caa6c0: ldr     x0, [x0, #0x7b8]                           T:ESaveType
02caa6c4: bl      #0x2b70db0                                 fn_2b70db0
02caa6c8: adrp    x0, #0x6264000                             
02caa6cc: ldr     x0, [x0, #0xe48]                           S:'/'
02caa6d0: bl      #0x2b70db0                                 fn_2b70db0
02caa6d4: mov     w8, #1                                     
02caa6d8: strb    w8, [x21, #0xb19]                          
02caa6dc: ldr     w8, [x20, #0x20]                           .SaveType
02caa6e0: cmp     w8, #1                                     
02caa6e4: b.eq    #0x2caa704                                 
02caa6e8: cbnz    w8, #0x2caa734                             
02caa6ec: mov     x0, x19                                    
02caa6f0: ldp     x20, x19, [sp, #0x20]                      
02caa6f4: ldp     x30, x21, [sp, #0x10]                      
02caa6f8: mov     x1, xzr                                    
02caa6fc: add     sp, sp, #0x30                              
02caa700: b       #0x5b2d73c                                 UnityEngine.PlayerPrefs::HasKey
02caa704: bl      #0x2ca9ce0                                 DataManager::get__savePath
02caa708: adrp    x8, #0x6264000                             
02caa70c: mov     x2, x19                                    
02caa710: mov     x3, xzr                                    
02caa714: ldr     x8, [x8, #0xe48]                           S:'/'
02caa718: ldr     x1, [x8]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02caa71c: bl      #0x4ca6dbc                                 System.String::Concat
02caa720: ldp     x20, x19, [sp, #0x20]                      
02caa724: mov     x1, xzr                                    
02caa728: ldp     x30, x21, [sp, #0x10]                      
02caa72c: add     sp, sp, #0x30                              
02caa730: b       #0x4dcc654                                 System.IO.File::Exists
02caa734: adrp    x9, #0x6266000                             
02caa738: add     x1, sp, #0xc                               
02caa73c: ldr     x9, [x9, #0x7b8]                           T:ESaveType
02caa740: str     w8, [sp, #0xc]                             
02caa744: ldr     x0, [x9]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02caa748: bl      #0x2b70f38                                 fn_2b70f38
02caa74c: mov     x1, xzr                                    
02caa750: bl      #0x2cd5058                                 <PrivateImplementationDetails>::ThrowSwitchExpressionException
02caa754: ldp     x20, x19, [sp, #0x20]                      
02caa758: mov     w0, wzr                                    
02caa75c: ldp     x30, x21, [sp, #0x10]                      
02caa760: add     sp, sp, #0x30                              
02caa764: ret                                                
## LoadAllData() -> void
---- DataManager::LoadAllData 0x2caa768
02caa768: sub     sp, sp, #0x50                              
02caa76c: stp     x30, x21, [sp, #0x30]                      
02caa770: stp     x20, x19, [sp, #0x40]                      
02caa774: adrp    x20, #0x662f000                            
02caa778: mov     x19, x0                                    
02caa77c: ldrb    w8, [x20, #0xb1a]                          
02caa780: tbnz    w8, #0, #0x2caa7bc                         
02caa784: adrp    x0, #0x6266000                             
02caa788: ldr     x0, [x0, #0x780]                           MS:System.Collections.Generic.List`1/Enumerator::Dispose
02caa78c: bl      #0x2b70db0                                 fn_2b70db0
02caa790: adrp    x0, #0x6266000                             
02caa794: ldr     x0, [x0, #0x788]                           MS:System.Collections.Generic.List`1/Enumerator::MoveNext
02caa798: bl      #0x2b70db0                                 fn_2b70db0
02caa79c: adrp    x0, #0x6266000                             
02caa7a0: ldr     x0, [x0, #0x790]                           MS:System.Collections.Generic.List`1/Enumerator::get_Current
02caa7a4: bl      #0x2b70db0                                 fn_2b70db0
02caa7a8: adrp    x0, #0x6266000                             
02caa7ac: ldr     x0, [x0, #0x798]                           MS:System.Collections.Generic.List`1::GetEnumerator
02caa7b0: bl      #0x2b70db0                                 fn_2b70db0
02caa7b4: mov     w8, #1                                     
02caa7b8: strb    w8, [x20, #0xb1a]                          
02caa7bc: ldr     x0, [x19, #0x30]                           .GameDatasList
02caa7c0: stp     xzr, xzr, [sp, #0x18]                      
02caa7c4: str     xzr, [sp, #0x28]                           
02caa7c8: cbz     x0, #0x2caa844                             
02caa7cc: adrp    x8, #0x6266000                             
02caa7d0: adrp    x19, #0x6266000                            
02caa7d4: adrp    x20, #0x6266000                            
02caa7d8: ldr     x8, [x8, #0x798]                           MS:System.Collections.Generic.List`1::GetEnumerator
02caa7dc: ldr     x19, [x19, #0x788]                         MS:System.Collections.Generic.List`1/Enumerator::MoveNext
02caa7e0: ldr     x20, [x20, #0x780]                         MS:System.Collections.Generic.List`1/Enumerator::Dispose
02caa7e4: add     x21, sp, #0x18                             
02caa7e8: ldr     x1, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02caa7ec: add     x8, sp, #0x18                              
02caa7f0: bl      #0x35a9d9c                                 fn_35a9d9c
02caa7f4: stp     xzr, x21, [sp, #8]                         
02caa7f8: ldr     x1, [x19]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02caa7fc: add     x0, sp, #0x18                              
02caa800: bl      #0x4690474                                 fn_4690474
02caa804: tbz     w0, #0, #0x2caa824                         
02caa808: ldr     x0, [sp, #0x28]                            
02caa80c: cbz     x0, #0x2caa840                             
02caa810: ldr     x8, [x0]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02caa814: ldr     x1, [x8, #0x270]                           MS:System.Collections.Generic.List`1::GetEnumerator
02caa818: ldr     x9, [x8, #0x268]                           MS:System.Collections.Generic.List`1/Enumerator::get_Current
02caa81c: blr     x9                                         
02caa820: b       #0x2caa7f8                                 
02caa824: ldr     x1, [x20]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02caa828: add     x0, sp, #0x18                              
02caa82c: bl      #0x4690470                                 fn_4690470
02caa830: ldp     x20, x19, [sp, #0x40]                      
02caa834: ldp     x30, x21, [sp, #0x30]                      
02caa838: add     sp, sp, #0x50                              
02caa83c: ret                                                
02caa840: bl      #0x2b7105c                                 fn_2b7105c
02caa844: bl      #0x2b7105c                                 fn_2b7105c
02caa848: b       #0x2caa850                                 
02caa84c: b       #0x2caa850                                 
02caa850: mov     x19, x0                                    
02caa854: cmp     w1, #1                                     
02caa858: b.ne    #0x2caa88c                                 
02caa85c: mov     x0, x19                                    
02caa860: bl      #0x5e90260                                 fn_5e90260
02caa864: ldr     x19, [x0]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02caa868: str     x19, [sp, #8]                              
02caa86c: bl      #0x5e90270                                 fn_5e90270
02caa870: ldr     x0, [sp, #0x10]                            
02caa874: ldr     x1, [x20]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02caa878: bl      #0x4690470                                 fn_4690470
02caa87c: cbz     x19, #0x2caa830                            
02caa880: mov     x0, x19                                    
02caa884: bl      #0x2b71054                                 fn_2b71054
02caa888: mov     x19, x0                                    
02caa88c: add     x0, sp, #8                                 
02caa890: bl      #0x2736fac                                 fn_2736fac
02caa894: mov     x0, x19                                    
02caa898: bl      #0x2c6051c                                 fn_2c6051c
02caa89c: bl      #0x27369b8                                 fn_27369b8
## SaveAllData() -> void
---- DataManager::SaveAllData 0x2caa8a0
02caa8a0: sub     sp, sp, #0x60                              
02caa8a4: str     x30, [sp, #0x30]                           
02caa8a8: stp     x22, x21, [sp, #0x40]                      
02caa8ac: stp     x20, x19, [sp, #0x50]                      
02caa8b0: adrp    x21, #0x662f000                            
02caa8b4: adrp    x20, #0x6266000                            
02caa8b8: mov     x19, x0                                    
02caa8bc: ldrb    w8, [x21, #0xb1b]                          
02caa8c0: ldr     x20, [x20, #0x7a8]                         T:DataManager
02caa8c4: tbnz    w8, #0, #0x2caa90c                         
02caa8c8: adrp    x0, #0x6266000                             
02caa8cc: ldr     x0, [x0, #0x7a8]                           T:DataManager
02caa8d0: bl      #0x2b70db0                                 fn_2b70db0
02caa8d4: adrp    x0, #0x6266000                             
02caa8d8: ldr     x0, [x0, #0x780]                           MS:System.Collections.Generic.List`1/Enumerator::Dispose
02caa8dc: bl      #0x2b70db0                                 fn_2b70db0
02caa8e0: adrp    x0, #0x6266000                             
02caa8e4: ldr     x0, [x0, #0x788]                           MS:System.Collections.Generic.List`1/Enumerator::MoveNext
02caa8e8: bl      #0x2b70db0                                 fn_2b70db0
02caa8ec: adrp    x0, #0x6266000                             
02caa8f0: ldr     x0, [x0, #0x790]                           MS:System.Collections.Generic.List`1/Enumerator::get_Current
02caa8f4: bl      #0x2b70db0                                 fn_2b70db0
02caa8f8: adrp    x0, #0x6266000                             
02caa8fc: ldr     x0, [x0, #0x798]                           MS:System.Collections.Generic.List`1::GetEnumerator
02caa900: bl      #0x2b70db0                                 fn_2b70db0
02caa904: mov     w8, #1                                     
02caa908: strb    w8, [x21, #0xb1b]                          
02caa90c: ldr     x8, [x20]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02caa910: stp     xzr, xzr, [sp, #0x18]                      
02caa914: str     xzr, [sp, #0x28]                           
02caa918: ldr     x8, [x8, #0xb8]                            
02caa91c: ldr     x8, [x8]                                   
02caa920: cbz     x8, #0x2caa934                             
02caa924: ldr     x9, [x8, #0x18]                            
02caa928: ldr     x0, [x8, #0x40]                            
02caa92c: ldr     x1, [x8, #0x28]                            
02caa930: blr     x9                                         
02caa934: ldr     x0, [x19, #0x30]                           .GameDatasList
02caa938: cbz     x0, #0x2caa9d0                             
02caa93c: adrp    x8, #0x6266000                             
02caa940: adrp    x20, #0x6266000                            
02caa944: adrp    x21, #0x6266000                            
02caa948: ldr     x8, [x8, #0x798]                           MS:System.Collections.Generic.List`1::GetEnumerator
02caa94c: ldr     x20, [x20, #0x788]                         MS:System.Collections.Generic.List`1/Enumerator::MoveNext
02caa950: ldr     x21, [x21, #0x780]                         MS:System.Collections.Generic.List`1/Enumerator::Dispose
02caa954: add     x22, sp, #0x18                             
02caa958: ldr     x1, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02caa95c: add     x8, sp, #0x18                              
02caa960: bl      #0x35a9d9c                                 fn_35a9d9c
02caa964: stp     xzr, x22, [sp, #8]                         
02caa968: ldr     x1, [x20]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02caa96c: add     x0, sp, #0x18                              
02caa970: bl      #0x4690474                                 fn_4690474
02caa974: tbz     w0, #0, #0x2caa994                         
02caa978: ldr     x0, [sp, #0x28]                            
02caa97c: cbz     x0, #0x2caa9cc                             
02caa980: ldr     x8, [x0]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02caa984: ldr     x1, [x8, #0x260]                           MS:System.Collections.Generic.List`1/Enumerator::MoveNext
02caa988: ldr     x9, [x8, #0x258]                           MS:System.Collections.Generic.List`1/Enumerator::Dispose
02caa98c: blr     x9                                         
02caa990: b       #0x2caa968                                 
02caa994: ldr     x1, [x21]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02caa998: add     x0, sp, #0x18                              
02caa99c: bl      #0x4690470                                 fn_4690470
02caa9a0: ldrb    w8, [x19, #0x40]                           ._isPrefsDirty
02caa9a4: str     wzr, [x19, #0x44]                          ._flushTimer
02caa9a8: cbz     w8, #0x2caa9b8                             
02caa9ac: mov     x0, xzr                                    
02caa9b0: strb    wzr, [x19, #0x40]                          ._isPrefsDirty
02caa9b4: bl      #0x5b2d914                                 UnityEngine.PlayerPrefs::Save
02caa9b8: ldp     x20, x19, [sp, #0x50]                      
02caa9bc: ldr     x30, [sp, #0x30]                           
02caa9c0: ldp     x22, x21, [sp, #0x40]                      
02caa9c4: add     sp, sp, #0x60                              
02caa9c8: ret                                                
02caa9cc: bl      #0x2b7105c                                 fn_2b7105c
02caa9d0: bl      #0x2b7105c                                 fn_2b7105c
02caa9d4: b       #0x2caa9dc                                 
02caa9d8: b       #0x2caa9dc                                 
02caa9dc: mov     x20, x0                                    
02caa9e0: cmp     w1, #1                                     
02caa9e4: b.ne    #0x2caaa18                                 
02caa9e8: mov     x0, x20                                    
02caa9ec: bl      #0x5e90260                                 fn_5e90260
02caa9f0: ldr     x20, [x0]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02caa9f4: str     x20, [sp, #8]                              
02caa9f8: bl      #0x5e90270                                 fn_5e90270
02caa9fc: ldr     x0, [sp, #0x10]                            
02caaa00: ldr     x1, [x21]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02caaa04: bl      #0x4690470                                 fn_4690470
02caaa08: cbz     x20, #0x2caa9a0                            
02caaa0c: mov     x0, x20                                    
02caaa10: bl      #0x2b71054                                 fn_2b71054
02caaa14: mov     x20, x0                                    
02caaa18: add     x0, sp, #8                                 
02caaa1c: bl      #0x2736fac                                 fn_2736fac
02caaa20: mov     x0, x20                                    
02caaa24: bl      #0x2c6051c                                 fn_2c6051c
02caaa28: bl      #0x27369b8                                 fn_27369b8
## DeleteAllData() -> void
---- DataManager::DeleteAllData 0x2caaa2c
02caaa2c: sub     sp, sp, #0x50                              
02caaa30: stp     x30, x21, [sp, #0x30]                      
02caaa34: stp     x20, x19, [sp, #0x40]                      
02caaa38: adrp    x20, #0x662f000                            
02caaa3c: mov     x19, x0                                    
02caaa40: ldrb    w8, [x20, #0xb1c]                          
02caaa44: tbnz    w8, #0, #0x2caaa80                         
02caaa48: adrp    x0, #0x6266000                             
02caaa4c: ldr     x0, [x0, #0x780]                           MS:System.Collections.Generic.List`1/Enumerator::Dispose
02caaa50: bl      #0x2b70db0                                 fn_2b70db0
02caaa54: adrp    x0, #0x6266000                             
02caaa58: ldr     x0, [x0, #0x788]                           MS:System.Collections.Generic.List`1/Enumerator::MoveNext
02caaa5c: bl      #0x2b70db0                                 fn_2b70db0
02caaa60: adrp    x0, #0x6266000                             
02caaa64: ldr     x0, [x0, #0x790]                           MS:System.Collections.Generic.List`1/Enumerator::get_Current
02caaa68: bl      #0x2b70db0                                 fn_2b70db0
02caaa6c: adrp    x0, #0x6266000                             
02caaa70: ldr     x0, [x0, #0x798]                           MS:System.Collections.Generic.List`1::GetEnumerator
02caaa74: bl      #0x2b70db0                                 fn_2b70db0
02caaa78: mov     w8, #1                                     
02caaa7c: strb    w8, [x20, #0xb1c]                          
02caaa80: ldr     x0, [x19, #0x30]                           .GameDatasList
02caaa84: stp     xzr, xzr, [sp, #0x18]                      
02caaa88: str     xzr, [sp, #0x28]                           
02caaa8c: cbz     x0, #0x2caab08                             
02caaa90: adrp    x8, #0x6266000                             
02caaa94: adrp    x19, #0x6266000                            
02caaa98: adrp    x20, #0x6266000                            
02caaa9c: ldr     x8, [x8, #0x798]                           MS:System.Collections.Generic.List`1::GetEnumerator
02caaaa0: ldr     x19, [x19, #0x788]                         MS:System.Collections.Generic.List`1/Enumerator::MoveNext
02caaaa4: ldr     x20, [x20, #0x780]                         MS:System.Collections.Generic.List`1/Enumerator::Dispose
02caaaa8: add     x21, sp, #0x18                             
02caaaac: ldr     x1, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02caaab0: add     x8, sp, #0x18                              
02caaab4: bl      #0x35a9d9c                                 fn_35a9d9c
02caaab8: stp     xzr, x21, [sp, #8]                         
02caaabc: ldr     x1, [x19]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02caaac0: add     x0, sp, #0x18                              
02caaac4: bl      #0x4690474                                 fn_4690474
02caaac8: tbz     w0, #0, #0x2caaae8                         
02caaacc: ldr     x0, [sp, #0x28]                            
02caaad0: cbz     x0, #0x2caab04                             
02caaad4: ldr     x8, [x0]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02caaad8: ldr     x1, [x8, #0x230]                           T:UnityEngine.Purchasing.ProductDefinition
02caaadc: ldr     x9, [x8, #0x228]                           T:type15233(k15)
02caaae0: blr     x9                                         
02caaae4: b       #0x2caaabc                                 
02caaae8: ldr     x1, [x20]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02caaaec: add     x0, sp, #0x18                              
02caaaf0: bl      #0x4690470                                 fn_4690470
02caaaf4: ldp     x20, x19, [sp, #0x40]                      
02caaaf8: ldp     x30, x21, [sp, #0x30]                      
02caaafc: add     sp, sp, #0x50                              
02caab00: ret                                                
02caab04: bl      #0x2b7105c                                 fn_2b7105c
02caab08: bl      #0x2b7105c                                 fn_2b7105c
02caab0c: b       #0x2caab14                                 
02caab10: b       #0x2caab14                                 
02caab14: mov     x19, x0                                    
02caab18: cmp     w1, #1                                     
02caab1c: b.ne    #0x2caab50                                 
02caab20: mov     x0, x19                                    
02caab24: bl      #0x5e90260                                 fn_5e90260
02caab28: ldr     x19, [x0]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02caab2c: str     x19, [sp, #8]                              
02caab30: bl      #0x5e90270                                 fn_5e90270
02caab34: ldr     x0, [sp, #0x10]                            
02caab38: ldr     x1, [x20]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02caab3c: bl      #0x4690470                                 fn_4690470
02caab40: cbz     x19, #0x2caaaf4                            
02caab44: mov     x0, x19                                    
02caab48: bl      #0x2b71054                                 fn_2b71054
02caab4c: mov     x19, x0                                    
02caab50: add     x0, sp, #8                                 
02caab54: bl      #0x2736fac                                 fn_2736fac
02caab58: mov     x0, x19                                    
02caab5c: bl      #0x2c6051c                                 fn_2c6051c
02caab60: bl      #0x27369b8                                 fn_27369b8
## OnApplicationQuit() -> void
---- DataManager::OnApplicationQuit 0x2caab64
02caab64: b       #0x2caa8a0                                 DataManager::SaveAllData
## OnApplicationPause(bool pauseStatus) -> void
---- DataManager::OnApplicationPause 0x2caab68
02caab68: tbz     w1, #0, #0x2caab70                         
02caab6c: b       #0x2caa8a0                                 DataManager::SaveAllData
02caab70: ret                                                
## .ctor() -> void
---- DataManager::.ctor 0x2caab74
02caab74: stp     x30, x27, [sp, #-0x50]!                    
02caab78: stp     x26, x25, [sp, #0x10]                      
02caab7c: stp     x24, x23, [sp, #0x20]                      
02caab80: stp     x22, x21, [sp, #0x30]                      
02caab84: stp     x20, x19, [sp, #0x40]                      
02caab88: adrp    x26, #0x6266000                            
02caab8c: adrp    x20, #0x6266000                            
02caab90: adrp    x25, #0x6266000                            
02caab94: adrp    x24, #0x6266000                            
02caab98: adrp    x27, #0x662f000                            
02caab9c: adrp    x23, #0x6265000                            
02caaba0: adrp    x22, #0x6265000                            
02caaba4: adrp    x21, #0x6266000                            
02caaba8: ldr     x26, [x26, #0x7c0]                         T:type56803(k15)
02caabac: ldr     x20, [x20, #0x7c8]                         MS:System.Collections.Generic.List`1::.ctor
02caabb0: ldr     x25, [x25, #0x7d0]                         T:type56700(k15)
02caabb4: ldr     x24, [x24, #0x7d8]                         MS:System.Collections.Generic.List`1::.ctor
02caabb8: ldr     x23, [x23, #0x2e8]                         T:type8944(k15)
02caabbc: ldrb    w8, [x27, #0xb1d]                          
02caabc0: ldr     x22, [x22, #0x2e0]                         MS:System.Collections.Generic.Dictionary`2::.ctor
02caabc4: ldr     x21, [x21, #0x7e0]                         MS:MonoSingleton`1::.ctor
02caabc8: mov     x19, x0                                    
02caabcc: tbnz    w8, #0, #0x2caac2c                         
02caabd0: adrp    x0, #0x6265000                             
02caabd4: ldr     x0, [x0, #0x2e0]                           MS:System.Collections.Generic.Dictionary`2::.ctor
02caabd8: bl      #0x2b70db0                                 fn_2b70db0
02caabdc: adrp    x0, #0x6265000                             
02caabe0: ldr     x0, [x0, #0x2e8]                           T:type8944(k15)
02caabe4: bl      #0x2b70db0                                 fn_2b70db0
02caabe8: adrp    x0, #0x6266000                             
02caabec: ldr     x0, [x0, #0x7c8]                           MS:System.Collections.Generic.List`1::.ctor
02caabf0: bl      #0x2b70db0                                 fn_2b70db0
02caabf4: adrp    x0, #0x6266000                             
02caabf8: ldr     x0, [x0, #0x7d8]                           MS:System.Collections.Generic.List`1::.ctor
02caabfc: bl      #0x2b70db0                                 fn_2b70db0
02caac00: adrp    x0, #0x6266000                             
02caac04: ldr     x0, [x0, #0x7d0]                           T:type56700(k15)
02caac08: bl      #0x2b70db0                                 fn_2b70db0
02caac0c: adrp    x0, #0x6266000                             
02caac10: ldr     x0, [x0, #0x7c0]                           T:type56803(k15)
02caac14: bl      #0x2b70db0                                 fn_2b70db0
02caac18: adrp    x0, #0x6266000                             
02caac1c: ldr     x0, [x0, #0x7e0]                           MS:MonoSingleton`1::.ctor
02caac20: bl      #0x2b70db0                                 fn_2b70db0
02caac24: mov     w8, #1                                     
02caac28: strb    w8, [x27, #0xb1d]                          
02caac2c: ldr     x0, [x26]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02caac30: bl      #0x2b7104c                                 fn_2b7104c
02caac34: ldr     x1, [x20]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02caac38: mov     x20, x0                                    
02caac3c: bl      #0x35a89a4                                 fn_35a89a4
02caac40: mov     x0, x19                                    
02caac44: mov     x1, x20                                    
02caac48: str     x20, [x0, #0x28]!                          .AssetsList
02caac4c: bl      #0x2b70d54                                 fn_2b70d54
02caac50: ldr     x0, [x25]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02caac54: bl      #0x2b7104c                                 fn_2b7104c
02caac58: ldr     x1, [x24]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02caac5c: mov     x20, x0                                    
02caac60: bl      #0x35a89a4                                 fn_35a89a4
02caac64: mov     x0, x19                                    
02caac68: mov     x1, x20                                    
02caac6c: str     x20, [x0, #0x30]!                          .GameDatasList
02caac70: bl      #0x2b70d54                                 fn_2b70d54
02caac74: ldr     x0, [x23]                                  M:AdsManager::<OnApplicationPause>b__26_0
02caac78: bl      #0x2b7104c                                 fn_2b7104c
02caac7c: ldr     x1, [x22]                                  M:AdsManager::<OnApplicationPause>b__26_0
02caac80: mov     x20, x0                                    
02caac84: bl      #0x452b8a0                                 fn_452b8a0
02caac88: mov     x0, x19                                    
02caac8c: mov     x1, x20                                    
02caac90: str     x20, [x0, #0x38]!                          ._lastSavedData
02caac94: bl      #0x2b70d54                                 fn_2b70d54
02caac98: ldr     x1, [x21]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02caac9c: mov     x0, x19                                    
02caaca0: ldp     x20, x19, [sp, #0x40]                      
02caaca4: ldp     x22, x21, [sp, #0x30]                      
02caaca8: ldp     x24, x23, [sp, #0x20]                      
02caacac: ldp     x26, x25, [sp, #0x10]                      
02caacb0: ldp     x30, x27, [sp], #0x50                      
02caacb4: b       #0x3769e18                                 
