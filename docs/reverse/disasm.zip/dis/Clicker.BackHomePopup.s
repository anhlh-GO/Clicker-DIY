#### CLASS Clicker.BackHomePopup/<>c parent= object
#   field <>9                            Clicker.BackHomePopup/<>c                          off=0x0 attr=36 
#   field <>9__6_0                       System.Action                                      off=0x8 attr=16 
## .cctor() -> void
---- Clicker.BackHomePopup/<>c::.cctor 0x2d662e4
02d662e4: str     x30, [sp, #-0x20]!                         
02d662e8: stp     x20, x19, [sp, #0x10]                      
02d662ec: adrp    x19, #0x6630000                            
02d662f0: adrp    x20, #0x626c000                            
02d662f4: ldrb    w8, [x19, #0x332]                          
02d662f8: ldr     x20, [x20, #0x190]                         T:Clicker.BackHomePopup/<>c
02d662fc: tbnz    w8, #0, #0x2d66314                         
02d66300: adrp    x0, #0x626c000                             
02d66304: ldr     x0, [x0, #0x190]                           T:Clicker.BackHomePopup/<>c
02d66308: bl      #0x2b70db0                                 fn_2b70db0
02d6630c: mov     w8, #1                                     
02d66310: strb    w8, [x19, #0x332]                          
02d66314: ldr     x0, [x20]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d66318: bl      #0x2b7104c                                 fn_2b7104c
02d6631c: mov     x1, xzr                                    
02d66320: mov     x19, x0                                    
02d66324: bl      #0x4e53e9c                                 System.Object::.ctor
02d66328: ldr     x8, [x20]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d6632c: mov     x1, x19                                    
02d66330: ldr     x8, [x8, #0xb8]                            
02d66334: str     x19, [x8]                                  
02d66338: ldr     x8, [x20]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d6633c: ldp     x20, x19, [sp, #0x10]                      
02d66340: ldr     x0, [x8, #0xb8]                            
02d66344: ldr     x30, [sp], #0x20                           
02d66348: b       #0x2b70d54                                 
## .ctor() -> void
---- Clicker.BackHomePopup/<>c::.ctor 0x2d6634c
02d6634c: mov     x1, xzr                                    
02d66350: b       #0x4e53e9c                                 System.Object::.ctor
## <OnBtnConfirmClick>b__6_0() -> void
---- Clicker.BackHomePopup/<>c::<OnBtnConfirmClick>b__6_0 0x2d66354
02d66354: str     d8, [sp, #-0x40]!                          
02d66358: stp     x30, x23, [sp, #0x10]                      
02d6635c: stp     x22, x21, [sp, #0x20]                      
02d66360: stp     x20, x19, [sp, #0x30]                      
02d66364: adrp    x19, #0x6630000                            
02d66368: adrp    x21, #0x6265000                            
02d6636c: adrp    x20, #0x6266000                            
02d66370: ldrb    w8, [x19, #0x333]                          
02d66374: ldr     x21, [x21, #0x10]                          MS:MonoSingleton`1::get_Instance
02d66378: ldr     x20, [x20, #0x5e0]                         T:GameConfig
02d6637c: tbnz    w8, #0, #0x2d663b8                         
02d66380: adrp    x0, #0x6265000                             
02d66384: ldr     x0, [x0, #0xb38]                           T:DevTrack
02d66388: bl      #0x2b70db0                                 fn_2b70db0
02d6638c: adrp    x0, #0x6266000                             
02d66390: ldr     x0, [x0, #0x5e0]                           T:GameConfig
02d66394: bl      #0x2b70db0                                 fn_2b70db0
02d66398: adrp    x0, #0x6265000                             
02d6639c: ldr     x0, [x0, #0x10]                            MS:MonoSingleton`1::get_Instance
02d663a0: bl      #0x2b70db0                                 fn_2b70db0
02d663a4: adrp    x0, #0x6266000                             
02d663a8: ldr     x0, [x0, #0xb48]                           MS:MonoSingleton`1::get_Instance
02d663ac: bl      #0x2b70db0                                 fn_2b70db0
02d663b0: mov     w8, #1                                     
02d663b4: strb    w8, [x19, #0x333]                          
02d663b8: ldr     x0, [x21]                                  M:AdsManager::<OnApplicationPause>b__26_0
02d663bc: bl      #0x3769600                                 fn_3769600
02d663c0: ldr     x8, [x20]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d663c4: mov     x19, x0                                    
02d663c8: ldr     w9, [x8, #0xe4]                            
02d663cc: cbnz    w9, #0x2d663d8                             
02d663d0: mov     x0, x8                                     
02d663d4: bl      #0x2b70f30                                 fn_2b70f30
02d663d8: cbz     x19, #0x2d664a0                            
02d663dc: ldr     x8, [x20]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d663e0: adrp    x23, #0x6266000                            
02d663e4: mov     x0, x19                                    
02d663e8: mov     w2, wzr                                    
02d663ec: mov     x3, xzr                                    
02d663f0: ldr     x8, [x8, #0xb8]                            
02d663f4: ldr     x23, [x23, #0xb48]                         MS:MonoSingleton`1::get_Instance
02d663f8: ldr     x1, [x8, #8]                               
02d663fc: bl      #0x2ce9e58                                 SimpleSceneTransition::FlashIn
02d66400: ldr     x0, [x23]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d66404: bl      #0x3769600                                 fn_3769600
02d66408: cbz     x0, #0x2d664a0                             
02d6640c: ldr     x19, [x0, #0x30]                           S:'popup_rate_on_off'
02d66410: ldr     x0, [x23]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d66414: bl      #0x3769600                                 fn_3769600
02d66418: cbz     x0, #0x2d664a0                             
02d6641c: ldr     w20, [x0, #0x3c]                           [626603c]=0 f=0,0
02d66420: ldr     x0, [x23]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d66424: bl      #0x3769600                                 fn_3769600
02d66428: cbz     x0, #0x2d664a0                             
02d6642c: adrp    x22, #0x6265000                            
02d66430: mov     x8, x0                                     
02d66434: ldr     x22, [x22, #0xb38]                         T:DevTrack
02d66438: ldr     x21, [x8, #0x40]                           
02d6643c: ldr     x0, [x22]                                  M:AdsManager::<OnApplicationPause>b__26_0
02d66440: ldr     w9, [x0, #0xe4]                            [62660e4]=0 f=0,0
02d66444: cbnz    w9, #0x2d66450                             
02d66448: bl      #0x2b70f30                                 fn_2b70f30
02d6644c: ldr     x0, [x22]                                  M:AdsManager::<OnApplicationPause>b__26_0
02d66450: ldr     x8, [x0, #0xb8]                            S:'banner_native_refresh_time'
02d66454: mov     x0, xzr                                    
02d66458: ldr     x22, [x8, #0x3b0]                          
02d6645c: bl      #0x5b432fc                                 UnityEngine.Time::get_time
02d66460: ldr     x0, [x23]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d66464: fmov    s8, s0                                     
02d66468: bl      #0x3769600                                 fn_3769600
02d6646c: cbz     x0, #0x2d664a0                             
02d66470: ldr     s0, [x0, #0x38]                            S:'native_collap_id'
02d66474: mov     x0, x19                                    
02d66478: mov     w1, w20                                    
02d6647c: mov     x2, x21                                    
02d66480: mov     x3, x22                                    
02d66484: mov     x4, xzr                                    
02d66488: ldp     x20, x19, [sp, #0x30]                      
02d6648c: fsub    s0, s8, s0                                 
02d66490: ldp     x22, x21, [sp, #0x20]                      
02d66494: ldp     x30, x23, [sp, #0x10]                      
02d66498: ldr     d8, [sp], #0x40                            
02d6649c: b       #0x2c9cae4                                 DevTrack::GameModeExit
02d664a0: bl      #0x2b7105c                                 fn_2b7105c
#### CLASS Clicker.BackHomePopup parent= PopupBase
#   field _btnConfirm                    UnityEngine.UI.Button                              off=0x38 attr=1 SerializeField
#   field _btnCancel                     UnityEngine.UI.Button                              off=0x40 attr=1 SerializeField
#   field _btnCancel2                    UnityEngine.UI.Button                              off=0x48 attr=1 SerializeField
#   field _tfPanel                       UnityEngine.Transform                              off=0x50 attr=1 SerializeField
## OnInit(UIManager uiManager) -> void
---- Clicker.BackHomePopup::OnInit 0x2d65c88
02d65c88: stp     x30, x23, [sp, #-0x30]!                    
02d65c8c: stp     x22, x21, [sp, #0x10]                      
02d65c90: stp     x20, x19, [sp, #0x20]                      
02d65c94: adrp    x21, #0x6630000                            
02d65c98: mov     x20, x1                                    
02d65c9c: mov     x19, x0                                    
02d65ca0: ldrb    w8, [x21, #0x32e]                          
02d65ca4: tbnz    w8, #0, #0x2d65cd4                         
02d65ca8: adrp    x0, #0x626c000                             
02d65cac: ldr     x0, [x0, #0x170]                           M:Clicker.BackHomePopup::OnBtnCancelClick
02d65cb0: bl      #0x2b70db0                                 fn_2b70db0
02d65cb4: adrp    x0, #0x626c000                             
02d65cb8: ldr     x0, [x0, #0x178]                           M:Clicker.BackHomePopup::OnBtnConfirmClick
02d65cbc: bl      #0x2b70db0                                 fn_2b70db0
02d65cc0: adrp    x0, #0x6265000                             
02d65cc4: ldr     x0, [x0, #0x3f0]                           T:UnityEngine.Events.UnityAction
02d65cc8: bl      #0x2b70db0                                 fn_2b70db0
02d65ccc: mov     w8, #1                                     
02d65cd0: strb    w8, [x21, #0x32e]                          
02d65cd4: mov     x0, x19                                    
02d65cd8: mov     x1, x20                                    
02d65cdc: mov     x2, xzr                                    
02d65ce0: bl      #0x2cdd3c4                                 UIBase::OnInit
02d65ce4: ldr     x8, [x19, #0x38]                           ._btnConfirm
02d65ce8: cbz     x8, #0x2d65e50                             
02d65cec: ldr     x0, [x8, #0x100]                           
02d65cf0: cbz     x0, #0x2d65e50                             
02d65cf4: mov     x1, xzr                                    
02d65cf8: bl      #0x5b4ce48                                 UnityEngine.Events.UnityEventBase::RemoveAllListeners
02d65cfc: ldr     x8, [x19, #0x40]                           ._btnCancel
02d65d00: cbz     x8, #0x2d65e50                             
02d65d04: ldr     x0, [x8, #0x100]                           
02d65d08: cbz     x0, #0x2d65e50                             
02d65d0c: mov     x1, xzr                                    
02d65d10: bl      #0x5b4ce48                                 UnityEngine.Events.UnityEventBase::RemoveAllListeners
02d65d14: ldr     x8, [x19, #0x48]                           ._btnCancel2
02d65d18: cbz     x8, #0x2d65e50                             
02d65d1c: ldr     x0, [x8, #0x100]                           
02d65d20: cbz     x0, #0x2d65e50                             
02d65d24: mov     x1, xzr                                    
02d65d28: bl      #0x5b4ce48                                 UnityEngine.Events.UnityEventBase::RemoveAllListeners
02d65d2c: ldr     x8, [x19, #0x38]                           ._btnConfirm
02d65d30: cbz     x8, #0x2d65e50                             
02d65d34: adrp    x22, #0x6265000                            
02d65d38: adrp    x21, #0x626c000                            
02d65d3c: ldr     x22, [x22, #0x3f0]                         T:UnityEngine.Events.UnityAction
02d65d40: ldr     x21, [x21, #0x178]                         M:Clicker.BackHomePopup::OnBtnConfirmClick
02d65d44: ldr     x20, [x8, #0x100]                          
02d65d48: ldr     x0, [x22]                                  M:AdsManager::<OnApplicationPause>b__26_0
02d65d4c: bl      #0x2b7104c                                 fn_2b7104c
02d65d50: ldr     x2, [x21]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d65d54: mov     x1, x19                                    
02d65d58: mov     x3, xzr                                    
02d65d5c: mov     x21, x0                                    
02d65d60: bl      #0x5b4cf98                                 UnityEngine.Events.UnityAction::.ctor
02d65d64: cbz     x20, #0x2d65e50                            
02d65d68: mov     x0, x20                                    
02d65d6c: mov     x1, x21                                    
02d65d70: mov     x2, xzr                                    
02d65d74: bl      #0x5b4d0ac                                 UnityEngine.Events.UnityEvent::AddListener
02d65d78: ldr     x8, [x19, #0x40]                           ._btnCancel
02d65d7c: cbz     x8, #0x2d65e50                             
02d65d80: adrp    x23, #0x626c000                            
02d65d84: ldr     x23, [x23, #0x170]                         M:Clicker.BackHomePopup::OnBtnCancelClick
02d65d88: ldr     x0, [x22]                                  M:AdsManager::<OnApplicationPause>b__26_0
02d65d8c: ldr     x20, [x8, #0x100]                          
02d65d90: bl      #0x2b7104c                                 fn_2b7104c
02d65d94: ldr     x2, [x23]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d65d98: mov     x1, x19                                    
02d65d9c: mov     x3, xzr                                    
02d65da0: mov     x21, x0                                    
02d65da4: bl      #0x5b4cf98                                 UnityEngine.Events.UnityAction::.ctor
02d65da8: cbz     x20, #0x2d65e50                            
02d65dac: mov     x0, x20                                    
02d65db0: mov     x1, x21                                    
02d65db4: mov     x2, xzr                                    
02d65db8: bl      #0x5b4d0ac                                 UnityEngine.Events.UnityEvent::AddListener
02d65dbc: ldr     x8, [x19, #0x48]                           ._btnCancel2
02d65dc0: cbz     x8, #0x2d65e50                             
02d65dc4: ldr     x0, [x22]                                  M:AdsManager::<OnApplicationPause>b__26_0
02d65dc8: ldr     x20, [x8, #0x100]                          
02d65dcc: bl      #0x2b7104c                                 fn_2b7104c
02d65dd0: ldr     x2, [x23]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d65dd4: mov     x1, x19                                    
02d65dd8: mov     x3, xzr                                    
02d65ddc: mov     x21, x0                                    
02d65de0: bl      #0x5b4cf98                                 UnityEngine.Events.UnityAction::.ctor
02d65de4: cbz     x20, #0x2d65e50                            
02d65de8: mov     x0, x20                                    
02d65dec: mov     x1, x21                                    
02d65df0: mov     x2, xzr                                    
02d65df4: bl      #0x5b4d0ac                                 UnityEngine.Events.UnityEvent::AddListener
02d65df8: adrp    x20, #0x662f000                            
02d65dfc: ldr     x19, [x19, #0x50]                          ._tfPanel
02d65e00: ldrb    w8, [x20, #0x91a]                          
02d65e04: cbnz    w8, #0x2d65e1c                             
02d65e08: adrp    x0, #0x6264000                             
02d65e0c: ldr     x0, [x0, #0xd8]                            T:UnityEngine.Vector3
02d65e10: bl      #0x2b70db0                                 fn_2b70db0
02d65e14: mov     w8, #1                                     
02d65e18: strb    w8, [x20, #0x91a]                          
02d65e1c: cbz     x19, #0x2d65e50                            
02d65e20: adrp    x8, #0x6264000                             
02d65e24: mov     x0, x19                                    
02d65e28: mov     x1, xzr                                    
02d65e2c: ldr     x8, [x8, #0xd8]                            T:UnityEngine.Vector3
02d65e30: ldp     x20, x19, [sp, #0x20]                      
02d65e34: ldp     x22, x21, [sp, #0x10]                      
02d65e38: ldr     x8, [x8]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d65e3c: ldr     x8, [x8, #0xb8]                            MS:DG.Tweening.Core.Extensions::SetSpecialStartupMode
02d65e40: ldp     s0, s1, [x8]                               
02d65e44: ldr     s2, [x8, #8]                               T:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass2_0
02d65e48: ldp     x30, x23, [sp], #0x30                      
02d65e4c: b       #0x5b470cc                                 UnityEngine.Transform::set_localScale
02d65e50: bl      #0x2b7105c                                 fn_2b7105c
## OnShow() -> void
---- Clicker.BackHomePopup::OnShow 0x2d65e54
02d65e54: stp     x30, x23, [sp, #-0x30]!                    
02d65e58: stp     x22, x21, [sp, #0x10]                      
02d65e5c: stp     x20, x19, [sp, #0x20]                      
02d65e60: adrp    x20, #0x6630000                            
02d65e64: adrp    x21, #0x6265000                            
02d65e68: mov     x19, x0                                    
02d65e6c: ldrb    w8, [x20, #0x32f]                          
02d65e70: ldr     x21, [x21, #0x310]                         MS:WejoyService.Singleton`1::get_Instance
02d65e74: tbnz    w8, #0, #0x2d65ebc                         
02d65e78: adrp    x0, #0x626c000                             
02d65e7c: ldr     x0, [x0, #0x180]                           M:Clicker.BackHomePopup::<OnShow>b__5_0
02d65e80: bl      #0x2b70db0                                 fn_2b70db0
02d65e84: adrp    x0, #0x6265000                             
02d65e88: ldr     x0, [x0, #0x310]                           MS:WejoyService.Singleton`1::get_Instance
02d65e8c: bl      #0x2b70db0                                 fn_2b70db0
02d65e90: adrp    x0, #0x6264000                             
02d65e94: ldr     x0, [x0, #0xe8]                            T:DG.Tweening.TweenCallback
02d65e98: bl      #0x2b70db0                                 fn_2b70db0
02d65e9c: adrp    x0, #0x6266000                             
02d65ea0: ldr     x0, [x0, #0x928]                           MS:DG.Tweening.TweenSettingsExtensions::OnComplete
02d65ea4: bl      #0x2b70db0                                 fn_2b70db0
02d65ea8: adrp    x0, #0x6266000                             
02d65eac: ldr     x0, [x0, #0x880]                           MS:DG.Tweening.TweenSettingsExtensions::SetEase
02d65eb0: bl      #0x2b70db0                                 fn_2b70db0
02d65eb4: mov     w8, #1                                     
02d65eb8: strb    w8, [x20, #0x32f]                          
02d65ebc: ldr     x0, [x21]                                  M:AdsManager::<OnApplicationPause>b__26_0
02d65ec0: bl      #0x3be7218                                 fn_3be7218
02d65ec4: cbz     x0, #0x2d65f9c                             
02d65ec8: mov     w1, #4                                     
02d65ecc: mov     x2, xzr                                    
02d65ed0: bl      #0x2c8a650                                 AdsManager::ShowMREC
02d65ed4: mov     x0, x19                                    
02d65ed8: mov     x1, xzr                                    
02d65edc: bl      #0x2cdd6b8                                 UIBase::OnShow
02d65ee0: ldr     x0, [x19, #0x38]                           ._btnConfirm
02d65ee4: cbz     x0, #0x2d65f9c                             
02d65ee8: mov     w1, wzr                                    
02d65eec: mov     x2, xzr                                    
02d65ef0: bl      #0x5e662d4                                 UnityEngine.UI.Selectable::set_interactable
02d65ef4: ldr     x0, [x19, #0x40]                           ._btnCancel
02d65ef8: cbz     x0, #0x2d65f9c                             
02d65efc: mov     w1, wzr                                    
02d65f00: mov     x2, xzr                                    
02d65f04: bl      #0x5e662d4                                 UnityEngine.UI.Selectable::set_interactable
02d65f08: ldr     x0, [x19, #0x48]                           ._btnCancel2
02d65f0c: cbz     x0, #0x2d65f9c                             
02d65f10: adrp    x20, #0x6266000                            
02d65f14: adrp    x21, #0x6264000                            
02d65f18: adrp    x22, #0x626c000                            
02d65f1c: adrp    x23, #0x6266000                            
02d65f20: ldr     x20, [x20, #0x880]                         MS:DG.Tweening.TweenSettingsExtensions::SetEase
02d65f24: ldr     x21, [x21, #0xe8]                          T:DG.Tweening.TweenCallback
02d65f28: ldr     x22, [x22, #0x180]                         M:Clicker.BackHomePopup::<OnShow>b__5_0
02d65f2c: ldr     x23, [x23, #0x928]                         MS:DG.Tweening.TweenSettingsExtensions::OnComplete
02d65f30: mov     w1, wzr                                    
02d65f34: mov     x2, xzr                                    
02d65f38: bl      #0x5e662d4                                 UnityEngine.UI.Selectable::set_interactable
02d65f3c: fmov    s0, #1.00000000                            
02d65f40: fmov    s1, #0.50000000                            
02d65f44: ldr     x0, [x19, #0x50]                           ._tfPanel
02d65f48: mov     x1, xzr                                    
02d65f4c: bl      #0x2d98c98                                 DG.Tweening.ShortcutExtensions::DOScale
02d65f50: ldr     x2, [x20]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d65f54: mov     w1, #0x1b                                  
02d65f58: bl      #0x336fa0c                                 fn_336fa0c
02d65f5c: ldr     x8, [x21]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d65f60: mov     x20, x0                                    
02d65f64: mov     x0, x8                                     
02d65f68: bl      #0x2b7104c                                 fn_2b7104c
02d65f6c: ldr     x2, [x22]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d65f70: mov     x1, x19                                    
02d65f74: mov     x3, xzr                                    
02d65f78: mov     x21, x0                                    
02d65f7c: bl      #0x2d89dc4                                 DG.Tweening.TweenCallback::.ctor
02d65f80: mov     x0, x20                                    
02d65f84: mov     x1, x21                                    
02d65f88: ldr     x2, [x23]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d65f8c: ldp     x20, x19, [sp, #0x20]                      
02d65f90: ldp     x22, x21, [sp, #0x10]                      
02d65f94: ldp     x30, x23, [sp], #0x30                      
02d65f98: b       #0x336f26c                                 
02d65f9c: bl      #0x2b7105c                                 fn_2b7105c
## OnBtnConfirmClick() -> void
---- Clicker.BackHomePopup::OnBtnConfirmClick 0x2d65fa0
02d65fa0: stp     x30, x23, [sp, #-0x30]!                    
02d65fa4: stp     x22, x21, [sp, #0x10]                      
02d65fa8: stp     x20, x19, [sp, #0x20]                      
02d65fac: adrp    x20, #0x6630000                            
02d65fb0: mov     x19, x0                                    
02d65fb4: ldrb    w8, [x20, #0x330]                          
02d65fb8: tbnz    w8, #0, #0x2d66000                         
02d65fbc: adrp    x0, #0x6264000                             
02d65fc0: ldr     x0, [x0, #0xf90]                           T:System.Action
02d65fc4: bl      #0x2b70db0                                 fn_2b70db0
02d65fc8: adrp    x0, #0x6265000                             
02d65fcc: ldr     x0, [x0, #0x310]                           MS:WejoyService.Singleton`1::get_Instance
02d65fd0: bl      #0x2b70db0                                 fn_2b70db0
02d65fd4: adrp    x0, #0x626c000                             
02d65fd8: ldr     x0, [x0, #0x188]                           M:Clicker.BackHomePopup/<>c::<OnBtnConfirmClick>b__6_0
02d65fdc: bl      #0x2b70db0                                 fn_2b70db0
02d65fe0: adrp    x0, #0x626c000                             
02d65fe4: ldr     x0, [x0, #0x190]                           T:Clicker.BackHomePopup/<>c
02d65fe8: bl      #0x2b70db0                                 fn_2b70db0
02d65fec: adrp    x0, #0x626c000                             
02d65ff0: ldr     x0, [x0, #0x198]                           S:'blind_bag_home'
02d65ff4: bl      #0x2b70db0                                 fn_2b70db0
02d65ff8: mov     w8, #1                                     
02d65ffc: strb    w8, [x20, #0x330]                          
02d66000: ldr     x0, [x19, #0x38]                           ._btnConfirm
02d66004: cbz     x0, #0x2d66138                             
02d66008: mov     w1, wzr                                    
02d6600c: mov     x2, xzr                                    
02d66010: bl      #0x5e662d4                                 UnityEngine.UI.Selectable::set_interactable
02d66014: ldr     x0, [x19, #0x40]                           ._btnCancel
02d66018: cbz     x0, #0x2d66138                             
02d6601c: mov     w1, wzr                                    
02d66020: mov     x2, xzr                                    
02d66024: bl      #0x5e662d4                                 UnityEngine.UI.Selectable::set_interactable
02d66028: ldr     x0, [x19, #0x48]                           ._btnCancel2
02d6602c: cbz     x0, #0x2d66138                             
02d66030: mov     w1, wzr                                    
02d66034: mov     x2, xzr                                    
02d66038: bl      #0x5e662d4                                 UnityEngine.UI.Selectable::set_interactable
02d6603c: mov     x0, xzr                                    
02d66040: bl      #0x2d6eec8                                 Framework.AudioManager::get_Instance
02d66044: cbz     x0, #0x2d66138                             
02d66048: movi    d1, #0000000000000000                      
02d6604c: movi    d2, #0000000000000000                      
02d66050: adrp    x19, #0x6265000                            
02d66054: fmov    s0, #1.00000000                            
02d66058: adrp    x23, #0x626c000                            
02d6605c: adrp    x20, #0x626c000                            
02d66060: ldr     x19, [x19, #0x310]                         MS:WejoyService.Singleton`1::get_Instance
02d66064: ldr     x23, [x23, #0x190]                         T:Clicker.BackHomePopup/<>c
02d66068: ldr     x20, [x20, #0x198]                         S:'blind_bag_home'
02d6606c: mov     w1, #1                                     
02d66070: mov     w2, wzr                                    
02d66074: mov     w3, wzr                                    
02d66078: mov     x4, xzr                                    
02d6607c: bl      #0x2d6f03c                                 Framework.AudioManager::PlaySound
02d66080: ldr     x0, [x19]                                  M:AdsManager::<OnApplicationPause>b__26_0
02d66084: bl      #0x3be7218                                 fn_3be7218
02d66088: ldr     x8, [x23]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d6608c: mov     x19, x0                                    
02d66090: ldr     w9, [x8, #0xe4]                            
02d66094: cbnz    w9, #0x2d660a4                             
02d66098: mov     x0, x8                                     
02d6609c: bl      #0x2b70f30                                 fn_2b70f30
02d660a0: ldr     x8, [x23]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d660a4: ldr     x9, [x8, #0xb8]                            
02d660a8: ldr     x20, [x20]                                 M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d660ac: ldr     x21, [x9, #8]                              
02d660b0: cbnz    x21, #0x2d66110                            
02d660b4: ldr     w10, [x8, #0xe4]                           
02d660b8: cbnz    w10, #0x2d660cc                            
02d660bc: mov     x0, x8                                     
02d660c0: bl      #0x2b70f30                                 fn_2b70f30
02d660c4: ldr     x8, [x23]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d660c8: ldr     x9, [x8, #0xb8]                            
02d660cc: adrp    x8, #0x6264000                             
02d660d0: ldr     x8, [x8, #0xf90]                           T:System.Action
02d660d4: ldr     x22, [x9]                                  
02d660d8: ldr     x0, [x8]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d660dc: bl      #0x2b7104c                                 fn_2b7104c
02d660e0: adrp    x8, #0x626c000                             
02d660e4: mov     x1, x22                                    
02d660e8: mov     x3, xzr                                    
02d660ec: ldr     x8, [x8, #0x188]                           M:Clicker.BackHomePopup/<>c::<OnBtnConfirmClick>b__6_0
02d660f0: mov     x21, x0                                    
02d660f4: ldr     x2, [x8]                                   M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d660f8: bl      #0x4d8ddbc                                 System.Action::.ctor
02d660fc: ldr     x8, [x23]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d66100: mov     x1, x21                                    
02d66104: ldr     x0, [x8, #0xb8]                            MS:System.Collections.Generic.List`1::Add
02d66108: str     x21, [x0, #8]!                             
02d6610c: bl      #0x2b70d54                                 fn_2b70d54
02d66110: cbz     x19, #0x2d66138                            
02d66114: mov     x0, x19                                    
02d66118: mov     x1, x20                                    
02d6611c: mov     x2, x21                                    
02d66120: ldp     x20, x19, [sp, #0x20]                      
02d66124: mov     w3, #1                                     
02d66128: ldp     x22, x21, [sp, #0x10]                      
02d6612c: mov     x4, xzr                                    
02d66130: ldp     x30, x23, [sp], #0x30                      
02d66134: b       #0x2c89698                                 AdsManager::ShowInter
02d66138: bl      #0x2b7105c                                 fn_2b7105c
## OnBtnCancelClick() -> void
---- Clicker.BackHomePopup::OnBtnCancelClick 0x2d6613c
02d6613c: str     x30, [sp, #-0x30]!                         
02d66140: stp     x22, x21, [sp, #0x10]                      
02d66144: stp     x20, x19, [sp, #0x20]                      
02d66148: adrp    x20, #0x6630000                            
02d6614c: mov     x19, x0                                    
02d66150: ldrb    w8, [x20, #0x331]                          
02d66154: tbnz    w8, #0, #0x2d66190                         
02d66158: adrp    x0, #0x6264000                             
02d6615c: ldr     x0, [x0, #0xf90]                           T:System.Action
02d66160: bl      #0x2b70db0                                 fn_2b70db0
02d66164: adrp    x0, #0x626c000                             
02d66168: ldr     x0, [x0, #0x1a0]                           M:Clicker.BackHomePopup::<OnBtnCancelClick>b__7_0
02d6616c: bl      #0x2b70db0                                 fn_2b70db0
02d66170: adrp    x0, #0x6265000                             
02d66174: ldr     x0, [x0, #0x310]                           MS:WejoyService.Singleton`1::get_Instance
02d66178: bl      #0x2b70db0                                 fn_2b70db0
02d6617c: adrp    x0, #0x626c000                             
02d66180: ldr     x0, [x0, #0x1a8]                           S:'blind_bag_cancel_home'
02d66184: bl      #0x2b70db0                                 fn_2b70db0
02d66188: mov     w8, #1                                     
02d6618c: strb    w8, [x20, #0x331]                          
02d66190: mov     x0, xzr                                    
02d66194: bl      #0x2d6eec8                                 Framework.AudioManager::get_Instance
02d66198: cbz     x0, #0x2d66244                             
02d6619c: movi    d1, #0000000000000000                      
02d661a0: movi    d2, #0000000000000000                      
02d661a4: adrp    x20, #0x6265000                            
02d661a8: fmov    s0, #1.00000000                            
02d661ac: ldr     x20, [x20, #0x310]                         MS:WejoyService.Singleton`1::get_Instance
02d661b0: mov     w1, #1                                     
02d661b4: mov     w2, wzr                                    
02d661b8: mov     w3, wzr                                    
02d661bc: mov     x4, xzr                                    
02d661c0: bl      #0x2d6f03c                                 Framework.AudioManager::PlaySound
02d661c4: ldr     x0, [x20]                                  M:AdsManager::<OnApplicationPause>b__26_0
02d661c8: bl      #0x3be7218                                 fn_3be7218
02d661cc: cbz     x0, #0x2d66244                             
02d661d0: adrp    x21, #0x6264000                            
02d661d4: adrp    x22, #0x626c000                            
02d661d8: mov     x1, xzr                                    
02d661dc: ldr     x21, [x21, #0xf90]                         T:System.Action
02d661e0: ldr     x22, [x22, #0x1a0]                         M:Clicker.BackHomePopup::<OnBtnCancelClick>b__7_0
02d661e4: bl      #0x2c88cec                                 AdsManager::HideMREC
02d661e8: ldr     x0, [x20]                                  M:AdsManager::<OnApplicationPause>b__26_0
02d661ec: bl      #0x3be7218                                 fn_3be7218
02d661f0: ldr     x8, [x21]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d661f4: mov     x20, x0                                    
02d661f8: mov     x0, x8                                     
02d661fc: bl      #0x2b7104c                                 fn_2b7104c
02d66200: ldr     x2, [x22]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d66204: mov     x1, x19                                    
02d66208: mov     x3, xzr                                    
02d6620c: mov     x21, x0                                    
02d66210: bl      #0x4d8ddbc                                 System.Action::.ctor
02d66214: cbz     x20, #0x2d66244                            
02d66218: adrp    x8, #0x626c000                             
02d6621c: mov     x0, x20                                    
02d66220: mov     x2, x21                                    
02d66224: ldr     x8, [x8, #0x1a8]                           S:'blind_bag_cancel_home'
02d66228: ldp     x20, x19, [sp, #0x20]                      
02d6622c: ldp     x22, x21, [sp, #0x10]                      
02d66230: mov     w3, #1                                     
02d66234: ldr     x1, [x8]                                   M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d66238: mov     x4, xzr                                    
02d6623c: ldr     x30, [sp], #0x30                           
02d66240: b       #0x2c89698                                 AdsManager::ShowInter
02d66244: bl      #0x2b7105c                                 fn_2b7105c
## .ctor() -> void
---- Clicker.BackHomePopup::.ctor 0x2d66248
02d66248: mov     x1, xzr                                    
02d6624c: b       #0x2cddba8                                 PopupBase::.ctor
## <OnShow>b__5_0() -> void
---- Clicker.BackHomePopup::<OnShow>b__5_0 0x2d66250
02d66250: stp     x30, x19, [sp, #-0x10]!                    
02d66254: mov     x19, x0                                    
02d66258: ldr     x0, [x0, #0x38]                            ._btnConfirm
02d6625c: cbz     x0, #0x2d66298                             
02d66260: mov     w1, #1                                     
02d66264: mov     x2, xzr                                    
02d66268: bl      #0x5e662d4                                 UnityEngine.UI.Selectable::set_interactable
02d6626c: ldr     x0, [x19, #0x40]                           ._btnCancel
02d66270: cbz     x0, #0x2d66298                             
02d66274: mov     w1, #1                                     
02d66278: mov     x2, xzr                                    
02d6627c: bl      #0x5e662d4                                 UnityEngine.UI.Selectable::set_interactable
02d66280: ldr     x0, [x19, #0x48]                           ._btnCancel2
02d66284: cbz     x0, #0x2d66298                             
02d66288: mov     w1, #1                                     
02d6628c: mov     x2, xzr                                    
02d66290: ldp     x30, x19, [sp], #0x10                      
02d66294: b       #0x5e662d4                                 UnityEngine.UI.Selectable::set_interactable
02d66298: bl      #0x2b7105c                                 fn_2b7105c
## <OnBtnCancelClick>b__7_0() -> void
---- Clicker.BackHomePopup::<OnBtnCancelClick>b__7_0 0x2d6629c
02d6629c: stp     x30, x19, [sp, #-0x10]!                    
02d662a0: mov     x19, x0                                    
02d662a4: ldr     x0, [x0, #0x38]                            ._btnConfirm
02d662a8: cbz     x0, #0x2d662e0                             
02d662ac: mov     w1, wzr                                    
02d662b0: mov     x2, xzr                                    
02d662b4: bl      #0x5e662d4                                 UnityEngine.UI.Selectable::set_interactable
02d662b8: ldr     x0, [x19, #0x40]                           ._btnCancel
02d662bc: cbz     x0, #0x2d662e0                             
02d662c0: mov     w1, wzr                                    
02d662c4: mov     x2, xzr                                    
02d662c8: bl      #0x5e662d4                                 UnityEngine.UI.Selectable::set_interactable
02d662cc: ldr     x8, [x19]                                  
02d662d0: mov     x0, x19                                    
02d662d4: ldp     x2, x1, [x8, #0x198]                       
02d662d8: ldp     x30, x19, [sp], #0x10                      
02d662dc: br      x2                                         
02d662e0: bl      #0x2b7105c                                 fn_2b7105c
