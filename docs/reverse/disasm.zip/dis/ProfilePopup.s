#### CLASS ProfilePopup/<>c__DisplayClass12_0 parent= object
#   field usingLanguage                  string                                             off=0x10 attr=6 
## .ctor() -> void
---- ProfilePopup/<>c__DisplayClass12_0::.ctor 0x2ce682c
02ce682c: mov     x1, xzr                                    
02ce6830: b       #0x4e53e9c                                 System.Object::.ctor
## <UpdateLanguage>b__0(LanguageDataItem x) -> bool
---- ProfilePopup/<>c__DisplayClass12_0::<UpdateLanguage>b__0 0x2ce6dc8
02ce6dc8: cbz     x1, #0x2ce6de0                             
02ce6dcc: ldr     x8, [x1, #0x10]                            
02ce6dd0: ldr     x1, [x0, #0x10]                            .usingLanguage
02ce6dd4: mov     x2, xzr                                    
02ce6dd8: mov     x0, x8                                     
02ce6ddc: b       #0x4ca52b8                                 System.String::op_Equality
02ce6de0: str     x30, [sp, #-0x10]!                         
02ce6de4: bl      #0x2b7105c                                 fn_2b7105c
#### CLASS ProfilePopup parent= PopupBase
#   field _panel                         UnityEngine.Transform                              off=0x38 attr=1 SerializeField
#   field _settingPanel                  SettingPanel                                       off=0x40 attr=1 SerializeField
#   field _closeButton                   UnityEngine.UI.Button                              off=0x48 attr=1 SerializeField
#   field _closeFullscreenButton         UnityEngine.UI.Button                              off=0x50 attr=1 SerializeField
#   field _container                     UnityEngine.Transform                              off=0x58 attr=1 SerializeField
#   field _restoreButton                 UnityEngine.UI.Button                              off=0x60 attr=1 SerializeField
#   field _txtLanguage                   TMPro.TextMeshProUGUI                              off=0x68 attr=1 SerializeField
#   field _prevlanguageButton            UnityEngine.UI.Button                              off=0x70 attr=1 SerializeField
#   field _nextlanguageButton            UnityEngine.UI.Button                              off=0x78 attr=1 SerializeField
#   field RestoreCheck                   System.Action                                      off=0x80 attr=6 
#   field _closeAction                   System.Action                                      off=0x88 attr=1 
## OnInit(UIManager uiManager) -> void
---- ProfilePopup::OnInit 0x2ce641c
02ce641c: str     x30, [sp, #-0x30]!                         
02ce6420: stp     x22, x21, [sp, #0x10]                      
02ce6424: stp     x20, x19, [sp, #0x20]                      
02ce6428: adrp    x21, #0x662f000                            
02ce642c: mov     x20, x1                                    
02ce6430: mov     x19, x0                                    
02ce6434: ldrb    w8, [x21, #0xde5]                          
02ce6438: tbnz    w8, #0, #0x2ce648c                         
02ce643c: adrp    x0, #0x6268000                             
02ce6440: ldr     x0, [x0, #0x1e0]                           M:ProfilePopup::<OnInit>b__11_0
02ce6444: bl      #0x2b70db0                                 fn_2b70db0
02ce6448: adrp    x0, #0x6268000                             
02ce644c: ldr     x0, [x0, #0x1e8]                           M:ProfilePopup::<OnInit>b__11_1
02ce6450: bl      #0x2b70db0                                 fn_2b70db0
02ce6454: adrp    x0, #0x6268000                             
02ce6458: ldr     x0, [x0, #0x1f0]                           M:ProfilePopup::<OnInit>b__11_2
02ce645c: bl      #0x2b70db0                                 fn_2b70db0
02ce6460: adrp    x0, #0x6268000                             
02ce6464: ldr     x0, [x0, #0x1f8]                           M:ProfilePopup::<OnInit>b__11_3
02ce6468: bl      #0x2b70db0                                 fn_2b70db0
02ce646c: adrp    x0, #0x6268000                             
02ce6470: ldr     x0, [x0, #0x200]                           M:ProfilePopup::<OnInit>b__11_4
02ce6474: bl      #0x2b70db0                                 fn_2b70db0
02ce6478: adrp    x0, #0x6265000                             
02ce647c: ldr     x0, [x0, #0x3f0]                           T:UnityEngine.Events.UnityAction
02ce6480: bl      #0x2b70db0                                 fn_2b70db0
02ce6484: mov     w8, #1                                     
02ce6488: strb    w8, [x21, #0xde5]                          
02ce648c: mov     x0, x19                                    
02ce6490: mov     x1, x20                                    
02ce6494: bl      #0x2cdd3c4                                 UIBase::OnInit
02ce6498: ldr     x0, [x19, #0x40]                           ._settingPanel
02ce649c: cbz     x0, #0x2ce6634                             
02ce64a0: bl      #0x2ce6638                                 SettingPanel::OnInit
02ce64a4: ldr     x8, [x19, #0x48]                           ._closeButton
02ce64a8: cbz     x8, #0x2ce6634                             
02ce64ac: adrp    x22, #0x6265000                            
02ce64b0: adrp    x21, #0x6268000                            
02ce64b4: ldr     x22, [x22, #0x3f0]                         T:UnityEngine.Events.UnityAction
02ce64b8: ldr     x21, [x21, #0x1e0]                         M:ProfilePopup::<OnInit>b__11_0
02ce64bc: ldr     x20, [x8, #0x100]                          
02ce64c0: ldr     x0, [x22]                                  M:AdsManager::<OnApplicationPause>b__26_0
02ce64c4: bl      #0x2b7104c                                 fn_2b7104c
02ce64c8: ldr     x2, [x21]                                  S:'{0}/2'
02ce64cc: mov     x1, x19                                    
02ce64d0: mov     x3, xzr                                    
02ce64d4: mov     x21, x0                                    
02ce64d8: bl      #0x5b4cf98                                 UnityEngine.Events.UnityAction::.ctor
02ce64dc: cbz     x20, #0x2ce6634                            
02ce64e0: mov     x0, x20                                    
02ce64e4: mov     x1, x21                                    
02ce64e8: mov     x2, xzr                                    
02ce64ec: bl      #0x5b4d0ac                                 UnityEngine.Events.UnityEvent::AddListener
02ce64f0: ldr     x8, [x19, #0x60]                           ._restoreButton
02ce64f4: cbz     x8, #0x2ce6634                             
02ce64f8: adrp    x21, #0x6268000                            
02ce64fc: ldr     x21, [x21, #0x1e8]                         M:ProfilePopup::<OnInit>b__11_1
02ce6500: ldr     x0, [x22]                                  M:AdsManager::<OnApplicationPause>b__26_0
02ce6504: ldr     x20, [x8, #0x100]                          
02ce6508: bl      #0x2b7104c                                 fn_2b7104c
02ce650c: ldr     x2, [x21]                                  S:'{0}/2'
02ce6510: mov     x1, x19                                    
02ce6514: mov     x3, xzr                                    
02ce6518: mov     x21, x0                                    
02ce651c: bl      #0x5b4cf98                                 UnityEngine.Events.UnityAction::.ctor
02ce6520: cbz     x20, #0x2ce6634                            
02ce6524: mov     x0, x20                                    
02ce6528: mov     x1, x21                                    
02ce652c: mov     x2, xzr                                    
02ce6530: bl      #0x5b4d0ac                                 UnityEngine.Events.UnityEvent::AddListener
02ce6534: ldr     x8, [x19, #0x50]                           ._closeFullscreenButton
02ce6538: cbz     x8, #0x2ce6634                             
02ce653c: adrp    x21, #0x6268000                            
02ce6540: ldr     x21, [x21, #0x1f0]                         M:ProfilePopup::<OnInit>b__11_2
02ce6544: ldr     x0, [x22]                                  M:AdsManager::<OnApplicationPause>b__26_0
02ce6548: ldr     x20, [x8, #0x100]                          
02ce654c: bl      #0x2b7104c                                 fn_2b7104c
02ce6550: ldr     x2, [x21]                                  S:'{0}/2'
02ce6554: mov     x1, x19                                    
02ce6558: mov     x3, xzr                                    
02ce655c: mov     x21, x0                                    
02ce6560: bl      #0x5b4cf98                                 UnityEngine.Events.UnityAction::.ctor
02ce6564: cbz     x20, #0x2ce6634                            
02ce6568: mov     x0, x20                                    
02ce656c: mov     x1, x21                                    
02ce6570: mov     x2, xzr                                    
02ce6574: bl      #0x5b4d0ac                                 UnityEngine.Events.UnityEvent::AddListener
02ce6578: ldr     x8, [x19, #0x78]                           ._nextlanguageButton
02ce657c: cbz     x8, #0x2ce6634                             
02ce6580: adrp    x21, #0x6268000                            
02ce6584: ldr     x21, [x21, #0x1f8]                         M:ProfilePopup::<OnInit>b__11_3
02ce6588: ldr     x0, [x22]                                  M:AdsManager::<OnApplicationPause>b__26_0
02ce658c: ldr     x20, [x8, #0x100]                          
02ce6590: bl      #0x2b7104c                                 fn_2b7104c
02ce6594: ldr     x2, [x21]                                  S:'{0}/2'
02ce6598: mov     x1, x19                                    
02ce659c: mov     x3, xzr                                    
02ce65a0: mov     x21, x0                                    
02ce65a4: bl      #0x5b4cf98                                 UnityEngine.Events.UnityAction::.ctor
02ce65a8: cbz     x20, #0x2ce6634                            
02ce65ac: mov     x0, x20                                    
02ce65b0: mov     x1, x21                                    
02ce65b4: mov     x2, xzr                                    
02ce65b8: bl      #0x5b4d0ac                                 UnityEngine.Events.UnityEvent::AddListener
02ce65bc: ldr     x8, [x19, #0x70]                           ._prevlanguageButton
02ce65c0: cbz     x8, #0x2ce6634                             
02ce65c4: adrp    x21, #0x6268000                            
02ce65c8: ldr     x21, [x21, #0x200]                         M:ProfilePopup::<OnInit>b__11_4
02ce65cc: ldr     x0, [x22]                                  M:AdsManager::<OnApplicationPause>b__26_0
02ce65d0: ldr     x20, [x8, #0x100]                          
02ce65d4: bl      #0x2b7104c                                 fn_2b7104c
02ce65d8: ldr     x2, [x21]                                  S:'{0}/2'
02ce65dc: mov     x1, x19                                    
02ce65e0: mov     x3, xzr                                    
02ce65e4: mov     x21, x0                                    
02ce65e8: bl      #0x5b4cf98                                 UnityEngine.Events.UnityAction::.ctor
02ce65ec: cbz     x20, #0x2ce6634                            
02ce65f0: mov     x0, x20                                    
02ce65f4: mov     x1, x21                                    
02ce65f8: mov     x2, xzr                                    
02ce65fc: bl      #0x5b4d0ac                                 UnityEngine.Events.UnityEvent::AddListener
02ce6600: ldr     x0, [x19, #0x60]                           ._restoreButton
02ce6604: cbz     x0, #0x2ce6634                             
02ce6608: mov     x1, xzr                                    
02ce660c: bl      #0x5b339ec                                 UnityEngine.Component::get_gameObject
02ce6610: cbz     x0, #0x2ce6634                             
02ce6614: mov     w1, wzr                                    
02ce6618: mov     x2, xzr                                    
02ce661c: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02ce6620: mov     x0, x19                                    
02ce6624: ldp     x20, x19, [sp, #0x20]                      
02ce6628: ldp     x22, x21, [sp, #0x10]                      
02ce662c: ldr     x30, [sp], #0x30                           
02ce6630: b       #0x2ce666c                                 ProfilePopup::UpdateLanguage
02ce6634: bl      #0x2b7105c                                 fn_2b7105c
## UpdateLanguage() -> void
---- ProfilePopup::UpdateLanguage 0x2ce666c
02ce666c: stp     x30, x23, [sp, #-0x30]!                    
02ce6670: stp     x22, x21, [sp, #0x10]                      
02ce6674: stp     x20, x19, [sp, #0x20]                      
02ce6678: adrp    x20, #0x662f000                            
02ce667c: adrp    x21, #0x6268000                            
02ce6680: adrp    x22, #0x6266000                            
02ce6684: ldrb    w8, [x20, #0xde6]                          
02ce6688: ldr     x21, [x21, #0x208]                         T:ProfilePopup/<>c__DisplayClass12_0
02ce668c: ldr     x22, [x22, #0x658]                         MS:MonoSingleton`1::get_Instance
02ce6690: mov     x19, x0                                    
02ce6694: tbnz    w8, #0, #0x2ce6700                         
02ce6698: adrp    x0, #0x6268000                             
02ce669c: ldr     x0, [x0, #0x210]                           MS:DataManager::GetAsset
02ce66a0: bl      #0x2b70db0                                 fn_2b70db0
02ce66a4: adrp    x0, #0x6266000                             
02ce66a8: ldr     x0, [x0, #0x750]                           MS:DataManager::GetData
02ce66ac: bl      #0x2b70db0                                 fn_2b70db0
02ce66b0: adrp    x0, #0x6267000                             
02ce66b4: ldr     x0, [x0, #0xac0]                           MS:System.Collections.Generic.List`1::Find
02ce66b8: bl      #0x2b70db0                                 fn_2b70db0
02ce66bc: adrp    x0, #0x6266000                             
02ce66c0: ldr     x0, [x0, #0x9f0]                           T:Assets.SimpleLocalization.Scripts.LocalizationManager
02ce66c4: bl      #0x2b70db0                                 fn_2b70db0
02ce66c8: adrp    x0, #0x6266000                             
02ce66cc: ldr     x0, [x0, #0x658]                           MS:MonoSingleton`1::get_Instance
02ce66d0: bl      #0x2b70db0                                 fn_2b70db0
02ce66d4: adrp    x0, #0x6267000                             
02ce66d8: ldr     x0, [x0, #0xac8]                           T:type57257(k15)
02ce66dc: bl      #0x2b70db0                                 fn_2b70db0
02ce66e0: adrp    x0, #0x6268000                             
02ce66e4: ldr     x0, [x0, #0x218]                           M:ProfilePopup/<>c__DisplayClass12_0::<UpdateLanguage>b__0
02ce66e8: bl      #0x2b70db0                                 fn_2b70db0
02ce66ec: adrp    x0, #0x6268000                             
02ce66f0: ldr     x0, [x0, #0x208]                           T:ProfilePopup/<>c__DisplayClass12_0
02ce66f4: bl      #0x2b70db0                                 fn_2b70db0
02ce66f8: mov     w8, #1                                     
02ce66fc: strb    w8, [x20, #0xde6]                          
02ce6700: ldr     x0, [x21]                                  S:'{0}/2'
02ce6704: bl      #0x2b7104c                                 fn_2b7104c
02ce6708: mov     x1, xzr                                    
02ce670c: mov     x20, x0                                    
02ce6710: bl      #0x4e53e9c                                 System.Object::.ctor
02ce6714: ldr     x0, [x22]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ce6718: bl      #0x3769600                                 fn_3769600
02ce671c: cbz     x0, #0x2ce6828                             
02ce6720: adrp    x8, #0x6268000                             
02ce6724: ldr     x8, [x8, #0x210]                           MS:DataManager::GetAsset
02ce6728: ldr     x1, [x8]                                   S:'{0}/2'
02ce672c: bl      #0x3168af0                                 fn_3168af0
02ce6730: cbz     x0, #0x2ce6828                             
02ce6734: ldr     x21, [x0, #0x18]                           M:LuckyWheelPopup/<>c__DisplayClass50_0::<RunAnimation>b__0
02ce6738: ldr     x0, [x22]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ce673c: bl      #0x3769600                                 fn_3769600
02ce6740: cbz     x0, #0x2ce6828                             
02ce6744: adrp    x8, #0x6266000                             
02ce6748: ldr     x8, [x8, #0x750]                           MS:DataManager::GetData
02ce674c: ldr     x1, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ce6750: bl      #0x3168dd0                                 fn_3168dd0
02ce6754: cbz     x0, #0x2ce6828                             
02ce6758: ldr     x8, [x0, #0x20]                            T:LuckyWheelPopup/<SpinAnimation>d__51
02ce675c: cbz     x8, #0x2ce6828                             
02ce6760: cbz     x20, #0x2ce6828                            
02ce6764: adrp    x22, #0x6267000                            
02ce6768: adrp    x23, #0x6268000                            
02ce676c: mov     x0, x20                                    
02ce6770: ldr     x22, [x22, #0xac8]                         T:type57257(k15)
02ce6774: ldr     x1, [x8, #0x28]                            S:'banner_ad_on_off'
02ce6778: ldr     x23, [x23, #0x218]                         M:ProfilePopup/<>c__DisplayClass12_0::<UpdateLanguage>b__0
02ce677c: str     x1, [x0, #0x10]!                           
02ce6780: bl      #0x2b70d54                                 fn_2b70d54
02ce6784: ldr     x0, [x22]                                  S:'didu'
02ce6788: bl      #0x2b7104c                                 fn_2b7104c
02ce678c: ldr     x2, [x23]                                  S:'{0}/2'
02ce6790: mov     x1, x20                                    
02ce6794: mov     x3, xzr                                    
02ce6798: mov     x22, x0                                    
02ce679c: bl      #0x399ba10                                 fn_399ba10
02ce67a0: cbz     x21, #0x2ce6828                            
02ce67a4: adrp    x8, #0x6267000                             
02ce67a8: mov     x0, x21                                    
02ce67ac: mov     x1, x22                                    
02ce67b0: ldr     x8, [x8, #0xac0]                           MS:System.Collections.Generic.List`1::Find
02ce67b4: ldr     x2, [x8]                                   S:'didu'
02ce67b8: bl      #0x35a9868                                 fn_35a9868
02ce67bc: cbz     x0, #0x2ce6818                             
02ce67c0: adrp    x8, #0x6266000                             
02ce67c4: ldr     x8, [x8, #0x9f0]                           T:Assets.SimpleLocalization.Scripts.LocalizationManager
02ce67c8: ldr     x19, [x19, #0x68]                          ._txtLanguage
02ce67cc: ldr     x20, [x0, #0x10]                           MS:DG.Tweening.TweenSettingsExtensions::SetLoops
02ce67d0: ldr     x8, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ce67d4: ldr     w9, [x8, #0xe4]                            [62660e4]=0 f=0,0
02ce67d8: cbnz    w9, #0x2ce67e4                             
02ce67dc: mov     x0, x8                                     
02ce67e0: bl      #0x2b70f30                                 fn_2b70f30
02ce67e4: mov     x0, x20                                    
02ce67e8: mov     x1, xzr                                    
02ce67ec: bl      #0x2d76794                                 Assets.SimpleLocalization.Scripts.LocalizationManager::Localize
02ce67f0: cbz     x19, #0x2ce6828                            
02ce67f4: ldr     x8, [x19]                                  
02ce67f8: mov     x1, x0                                     
02ce67fc: mov     x0, x19                                    
02ce6800: ldp     x20, x19, [sp, #0x20]                      
02ce6804: ldp     x22, x21, [sp, #0x10]                      
02ce6808: ldr     x2, [x8, #0x560]                           MS:NFramework.GoogleSheetConfigSO`1::OpenSheet
02ce680c: ldr     x3, [x8, #0x558]                           MS:NFramework.GoogleSheetConfigSO`1::.ctor
02ce6810: ldp     x30, x23, [sp], #0x30                      
02ce6814: br      x3                                         
02ce6818: ldp     x20, x19, [sp, #0x20]                      
02ce681c: ldp     x22, x21, [sp, #0x10]                      
02ce6820: ldp     x30, x23, [sp], #0x30                      
02ce6824: ret                                                
02ce6828: bl      #0x2b7105c                                 fn_2b7105c
## ChangeToNextLanguage() -> void
---- ProfilePopup::ChangeToNextLanguage 0x2ce6834
02ce6834: str     x30, [sp, #-0x30]!                         
02ce6838: stp     x22, x21, [sp, #0x10]                      
02ce683c: stp     x20, x19, [sp, #0x20]                      
02ce6840: adrp    x21, #0x662f000                            
02ce6844: adrp    x20, #0x6266000                            
02ce6848: mov     x19, x0                                    
02ce684c: ldrb    w8, [x21, #0xde7]                          
02ce6850: ldr     x20, [x20, #0x658]                         MS:MonoSingleton`1::get_Instance
02ce6854: tbnz    w8, #0, #0x2ce6890                         
02ce6858: adrp    x0, #0x6268000                             
02ce685c: ldr     x0, [x0, #0x210]                           MS:DataManager::GetAsset
02ce6860: bl      #0x2b70db0                                 fn_2b70db0
02ce6864: adrp    x0, #0x6266000                             
02ce6868: ldr     x0, [x0, #0x750]                           MS:DataManager::GetData
02ce686c: bl      #0x2b70db0                                 fn_2b70db0
02ce6870: adrp    x0, #0x6266000                             
02ce6874: ldr     x0, [x0, #0x9f0]                           T:Assets.SimpleLocalization.Scripts.LocalizationManager
02ce6878: bl      #0x2b70db0                                 fn_2b70db0
02ce687c: adrp    x0, #0x6266000                             
02ce6880: ldr     x0, [x0, #0x658]                           MS:MonoSingleton`1::get_Instance
02ce6884: bl      #0x2b70db0                                 fn_2b70db0
02ce6888: mov     w8, #1                                     
02ce688c: strb    w8, [x21, #0xde7]                          
02ce6890: ldr     x0, [x20]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ce6894: bl      #0x3769600                                 fn_3769600
02ce6898: cbz     x0, #0x2ce6964                             
02ce689c: adrp    x8, #0x6266000                             
02ce68a0: ldr     x8, [x8, #0x750]                           MS:DataManager::GetData
02ce68a4: ldr     x1, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ce68a8: bl      #0x3168dd0                                 fn_3168dd0
02ce68ac: ldr     x8, [x20]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ce68b0: mov     x20, x0                                    
02ce68b4: mov     x0, x8                                     
02ce68b8: bl      #0x3769600                                 fn_3769600
02ce68bc: cbz     x0, #0x2ce6964                             
02ce68c0: adrp    x8, #0x6268000                             
02ce68c4: ldr     x8, [x8, #0x210]                           MS:DataManager::GetAsset
02ce68c8: ldr     x1, [x8]                                   S:'{0}/2'
02ce68cc: bl      #0x3168af0                                 fn_3168af0
02ce68d0: cbz     x20, #0x2ce6964                            
02ce68d4: ldr     x8, [x20, #0x20]                           S:'inter_ad_capping_time'
02ce68d8: cbz     x8, #0x2ce6964                             
02ce68dc: cbz     x0, #0x2ce6964                             
02ce68e0: ldr     x1, [x8, #0x28]                            T:LuckyWheelPopup/<>c__DisplayClass52_0
02ce68e4: bl      #0x2cd9298                                 LocalizeAsset::GetNextData
02ce68e8: cbz     x0, #0x2ce6954                             
02ce68ec: adrp    x8, #0x6266000                             
02ce68f0: mov     x21, x0                                    
02ce68f4: ldr     x8, [x8, #0x9f0]                           T:Assets.SimpleLocalization.Scripts.LocalizationManager
02ce68f8: ldr     x22, [x21, #0x10]                          &2b706e8(=14cc74f191004000)
02ce68fc: ldr     x0, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ce6900: ldr     w8, [x0, #0xe4]                            [62660e4]=0 f=0,0
02ce6904: cbnz    w8, #0x2ce690c                             
02ce6908: bl      #0x2b70f30                                 fn_2b70f30
02ce690c: mov     x0, x22                                    
02ce6910: mov     x1, xzr                                    
02ce6914: bl      #0x2d7ac14                                 Assets.SimpleLocalization.Scripts.LocalizationManager::set_Language
02ce6918: ldr     x0, [x20, #0x20]                           S:'inter_ad_capping_time'
02ce691c: cbz     x0, #0x2ce6964                             
02ce6920: ldr     x1, [x21, #0x10]                           &2b706e8(=14cc74f191004000)
02ce6924: str     x1, [x0, #0x28]!                           
02ce6928: bl      #0x2b70d54                                 fn_2b70d54
02ce692c: ldr     x8, [x20]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ce6930: mov     x0, x20                                    
02ce6934: ldr     x9, [x8, #0x258]                           MS:System.Collections.Generic.List`1/Enumerator::Dispose
02ce6938: ldr     x1, [x8, #0x260]                           MS:System.Collections.Generic.List`1/Enumerator::MoveNext
02ce693c: blr     x9                                         
02ce6940: mov     x0, x19                                    
02ce6944: ldp     x20, x19, [sp, #0x20]                      
02ce6948: ldp     x22, x21, [sp, #0x10]                      
02ce694c: ldr     x30, [sp], #0x30                           
02ce6950: b       #0x2ce666c                                 ProfilePopup::UpdateLanguage
02ce6954: ldp     x20, x19, [sp, #0x20]                      
02ce6958: ldp     x22, x21, [sp, #0x10]                      
02ce695c: ldr     x30, [sp], #0x30                           
02ce6960: ret                                                
02ce6964: bl      #0x2b7105c                                 fn_2b7105c
## ChangeToPrevLanguage() -> void
---- ProfilePopup::ChangeToPrevLanguage 0x2ce6968
02ce6968: str     x30, [sp, #-0x30]!                         
02ce696c: stp     x22, x21, [sp, #0x10]                      
02ce6970: stp     x20, x19, [sp, #0x20]                      
02ce6974: adrp    x21, #0x662f000                            
02ce6978: adrp    x20, #0x6266000                            
02ce697c: mov     x19, x0                                    
02ce6980: ldrb    w8, [x21, #0xde8]                          
02ce6984: ldr     x20, [x20, #0x658]                         MS:MonoSingleton`1::get_Instance
02ce6988: tbnz    w8, #0, #0x2ce69c4                         
02ce698c: adrp    x0, #0x6268000                             
02ce6990: ldr     x0, [x0, #0x210]                           MS:DataManager::GetAsset
02ce6994: bl      #0x2b70db0                                 fn_2b70db0
02ce6998: adrp    x0, #0x6266000                             
02ce699c: ldr     x0, [x0, #0x750]                           MS:DataManager::GetData
02ce69a0: bl      #0x2b70db0                                 fn_2b70db0
02ce69a4: adrp    x0, #0x6266000                             
02ce69a8: ldr     x0, [x0, #0x9f0]                           T:Assets.SimpleLocalization.Scripts.LocalizationManager
02ce69ac: bl      #0x2b70db0                                 fn_2b70db0
02ce69b0: adrp    x0, #0x6266000                             
02ce69b4: ldr     x0, [x0, #0x658]                           MS:MonoSingleton`1::get_Instance
02ce69b8: bl      #0x2b70db0                                 fn_2b70db0
02ce69bc: mov     w8, #1                                     
02ce69c0: strb    w8, [x21, #0xde8]                          
02ce69c4: ldr     x0, [x20]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ce69c8: bl      #0x3769600                                 fn_3769600
02ce69cc: cbz     x0, #0x2ce6a98                             
02ce69d0: adrp    x8, #0x6266000                             
02ce69d4: ldr     x8, [x8, #0x750]                           MS:DataManager::GetData
02ce69d8: ldr     x1, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ce69dc: bl      #0x3168dd0                                 fn_3168dd0
02ce69e0: ldr     x8, [x20]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ce69e4: mov     x20, x0                                    
02ce69e8: mov     x0, x8                                     
02ce69ec: bl      #0x3769600                                 fn_3769600
02ce69f0: cbz     x0, #0x2ce6a98                             
02ce69f4: adrp    x8, #0x6268000                             
02ce69f8: ldr     x8, [x8, #0x210]                           MS:DataManager::GetAsset
02ce69fc: ldr     x1, [x8]                                   S:'{0}/2'
02ce6a00: bl      #0x3168af0                                 fn_3168af0
02ce6a04: cbz     x20, #0x2ce6a98                            
02ce6a08: ldr     x8, [x20, #0x20]                           S:'inter_ad_capping_time'
02ce6a0c: cbz     x8, #0x2ce6a98                             
02ce6a10: cbz     x0, #0x2ce6a98                             
02ce6a14: ldr     x1, [x8, #0x28]                            T:LuckyWheelPopup/<>c__DisplayClass52_0
02ce6a18: bl      #0x2cd93e8                                 LocalizeAsset::GetPreviousData
02ce6a1c: cbz     x0, #0x2ce6a88                             
02ce6a20: adrp    x8, #0x6266000                             
02ce6a24: mov     x21, x0                                    
02ce6a28: ldr     x8, [x8, #0x9f0]                           T:Assets.SimpleLocalization.Scripts.LocalizationManager
02ce6a2c: ldr     x22, [x21, #0x10]                          &2b706e8(=14cc74f191004000)
02ce6a30: ldr     x0, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ce6a34: ldr     w8, [x0, #0xe4]                            [62660e4]=0 f=0,0
02ce6a38: cbnz    w8, #0x2ce6a40                             
02ce6a3c: bl      #0x2b70f30                                 fn_2b70f30
02ce6a40: mov     x0, x22                                    
02ce6a44: mov     x1, xzr                                    
02ce6a48: bl      #0x2d7ac14                                 Assets.SimpleLocalization.Scripts.LocalizationManager::set_Language
02ce6a4c: ldr     x0, [x20, #0x20]                           S:'inter_ad_capping_time'
02ce6a50: cbz     x0, #0x2ce6a98                             
02ce6a54: ldr     x1, [x21, #0x10]                           &2b706e8(=14cc74f191004000)
02ce6a58: str     x1, [x0, #0x28]!                           
02ce6a5c: bl      #0x2b70d54                                 fn_2b70d54
02ce6a60: ldr     x8, [x20]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ce6a64: mov     x0, x20                                    
02ce6a68: ldr     x9, [x8, #0x258]                           MS:System.Collections.Generic.List`1/Enumerator::Dispose
02ce6a6c: ldr     x1, [x8, #0x260]                           MS:System.Collections.Generic.List`1/Enumerator::MoveNext
02ce6a70: blr     x9                                         
02ce6a74: mov     x0, x19                                    
02ce6a78: ldp     x20, x19, [sp, #0x20]                      
02ce6a7c: ldp     x22, x21, [sp, #0x10]                      
02ce6a80: ldr     x30, [sp], #0x30                           
02ce6a84: b       #0x2ce666c                                 ProfilePopup::UpdateLanguage
02ce6a88: ldp     x20, x19, [sp, #0x20]                      
02ce6a8c: ldp     x22, x21, [sp, #0x10]                      
02ce6a90: ldr     x30, [sp], #0x30                           
02ce6a94: ret                                                
02ce6a98: bl      #0x2b7105c                                 fn_2b7105c
## OnShow() -> void
---- ProfilePopup::OnShow 0x2ce6a9c
02ce6a9c: str     x30, [sp, #-0x40]!                         
02ce6aa0: stp     x24, x23, [sp, #0x10]                      
02ce6aa4: stp     x22, x21, [sp, #0x20]                      
02ce6aa8: stp     x20, x19, [sp, #0x30]                      
02ce6aac: adrp    x20, #0x662f000                            
02ce6ab0: mov     x19, x0                                    
02ce6ab4: ldrb    w8, [x20, #0xde9]                          
02ce6ab8: tbnz    w8, #0, #0x2ce6adc                         
02ce6abc: adrp    x0, #0x6265000                             
02ce6ac0: ldr     x0, [x0, #0x310]                           MS:WejoyService.Singleton`1::get_Instance
02ce6ac4: bl      #0x2b70db0                                 fn_2b70db0
02ce6ac8: adrp    x0, #0x6266000                             
02ce6acc: ldr     x0, [x0, #0x880]                           MS:DG.Tweening.TweenSettingsExtensions::SetEase
02ce6ad0: bl      #0x2b70db0                                 fn_2b70db0
02ce6ad4: mov     w8, #1                                     
02ce6ad8: strb    w8, [x20, #0xde9]                          
02ce6adc: movi    d0, #0000000000000000                      
02ce6ae0: ldr     x0, [x19, #0x28]                           
02ce6ae4: mov     w1, #1                                     
02ce6ae8: mov     x2, xzr                                    
02ce6aec: mov     w20, #1                                    
02ce6af0: bl      #0x2cf1928                                 FrameWorkUtility::SetActive
02ce6af4: ldr     x0, [x19, #0x40]                           ._settingPanel
02ce6af8: strb    w20, [x19, #0x20]                          
02ce6afc: cbz     x0, #0x2ce6bf4                             
02ce6b00: bl      #0x2ce6bf8                                 SettingPanel::OnShow
02ce6b04: ldr     x0, [x19, #0x58]                           ._container
02ce6b08: mov     w1, wzr                                    
02ce6b0c: mov     x2, xzr                                    
02ce6b10: bl      #0x2d9d5d0                                 DG.Tweening.ShortcutExtensions::DOKill
02ce6b14: adrp    x21, #0x662f000                            
02ce6b18: ldr     x20, [x19, #0x58]                          ._container
02ce6b1c: ldrb    w8, [x21, #0x91a]                          
02ce6b20: cbnz    w8, #0x2ce6b38                             
02ce6b24: adrp    x0, #0x6264000                             
02ce6b28: ldr     x0, [x0, #0xd8]                            T:UnityEngine.Vector3
02ce6b2c: bl      #0x2b70db0                                 fn_2b70db0
02ce6b30: mov     w8, #1                                     
02ce6b34: strb    w8, [x21, #0x91a]                          
02ce6b38: cbz     x20, #0x2ce6bf4                            
02ce6b3c: adrp    x23, #0x6264000                            
02ce6b40: adrp    x22, #0x6266000                            
02ce6b44: adrp    x21, #0x6265000                            
02ce6b48: ldr     x23, [x23, #0xd8]                          T:UnityEngine.Vector3
02ce6b4c: mov     x0, x20                                    
02ce6b50: mov     x1, xzr                                    
02ce6b54: ldr     x8, [x23]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02ce6b58: ldr     x22, [x22, #0x880]                         MS:DG.Tweening.TweenSettingsExtensions::SetEase
02ce6b5c: ldr     x8, [x8, #0xb8]                            
02ce6b60: ldr     x21, [x21, #0x310]                         MS:WejoyService.Singleton`1::get_Instance
02ce6b64: ldp     s1, s2, [x8, #4]                           
02ce6b68: ldr     s0, [x8]                                   
02ce6b6c: bl      #0x5b470cc                                 UnityEngine.Transform::set_localScale
02ce6b70: adrp    x24, #0x662f000                            
02ce6b74: ldr     x20, [x19, #0x58]                          ._container
02ce6b78: ldrb    w8, [x24, #0xa74]                          
02ce6b7c: cbnz    w8, #0x2ce6b94                             
02ce6b80: adrp    x0, #0x6264000                             
02ce6b84: ldr     x0, [x0, #0xd8]                            T:UnityEngine.Vector3
02ce6b88: bl      #0x2b70db0                                 fn_2b70db0
02ce6b8c: mov     w8, #1                                     
02ce6b90: strb    w8, [x24, #0xa74]                          
02ce6b94: ldr     x8, [x23]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02ce6b98: mov     x0, x20                                    
02ce6b9c: mov     x1, xzr                                    
02ce6ba0: ldr     x8, [x8, #0xb8]                            
02ce6ba4: ldp     s0, s1, [x8, #0xc]                         
02ce6ba8: ldr     s2, [x8, #0x14]                            
02ce6bac: adrp    x8, #0x1084000                             
02ce6bb0: ldr     s3, [x8, #0xe60]                           [1084e60]=bc8efa353eb33333 f=0.35,-0.0174533
02ce6bb4: bl      #0x2d98af8                                 DG.Tweening.ShortcutExtensions::DOScale
02ce6bb8: ldr     x2, [x22]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ce6bbc: mov     w1, #0x1b                                  
02ce6bc0: bl      #0x336fa0c                                 fn_336fa0c
02ce6bc4: mov     x0, x19                                    
02ce6bc8: bl      #0x2ce666c                                 ProfilePopup::UpdateLanguage
02ce6bcc: ldr     x0, [x21]                                  M:AdsManager::<OnApplicationPause>b__26_0
02ce6bd0: bl      #0x3be7218                                 fn_3be7218
02ce6bd4: cbz     x0, #0x2ce6bf4                             
02ce6bd8: ldp     x20, x19, [sp, #0x30]                      
02ce6bdc: mov     w1, #4                                     
02ce6be0: ldp     x22, x21, [sp, #0x20]                      
02ce6be4: mov     x2, xzr                                    
02ce6be8: ldp     x24, x23, [sp, #0x10]                      
02ce6bec: ldr     x30, [sp], #0x40                           
02ce6bf0: b       #0x2c8a650                                 AdsManager::ShowMREC
02ce6bf4: bl      #0x2b7105c                                 fn_2b7105c
## OnHide() -> void
---- ProfilePopup::OnHide 0x2ce6c2c
02ce6c2c: str     x30, [sp, #-0x20]!                         
02ce6c30: stp     x20, x19, [sp, #0x10]                      
02ce6c34: adrp    x20, #0x662f000                            
02ce6c38: mov     x19, x0                                    
02ce6c3c: ldrb    w8, [x20, #0xdea]                          
02ce6c40: tbnz    w8, #0, #0x2ce6c58                         
02ce6c44: adrp    x0, #0x6265000                             
02ce6c48: ldr     x0, [x0, #0x310]                           MS:WejoyService.Singleton`1::get_Instance
02ce6c4c: bl      #0x2b70db0                                 fn_2b70db0
02ce6c50: mov     w8, #1                                     
02ce6c54: strb    w8, [x20, #0xdea]                          
02ce6c58: movi    d0, #0000000000000000                      
02ce6c5c: ldr     x0, [x19, #0x28]                           
02ce6c60: mov     w1, wzr                                    
02ce6c64: mov     x2, xzr                                    
02ce6c68: bl      #0x2cf1928                                 FrameWorkUtility::SetActive
02ce6c6c: ldr     x8, [x19, #0x40]                           ._settingPanel
02ce6c70: strb    wzr, [x19, #0x20]                          
02ce6c74: cbz     x8, #0x2ce6cb4                             
02ce6c78: ldr     x8, [x19, #0x88]                           ._closeAction
02ce6c7c: adrp    x19, #0x6265000                            
02ce6c80: ldr     x19, [x19, #0x310]                         MS:WejoyService.Singleton`1::get_Instance
02ce6c84: cbz     x8, #0x2ce6c98                             
02ce6c88: ldr     x9, [x8, #0x18]                            
02ce6c8c: ldr     x0, [x8, #0x40]                            
02ce6c90: ldr     x1, [x8, #0x28]                            
02ce6c94: blr     x9                                         
02ce6c98: ldr     x0, [x19]                                  M:AdsManager::<OnApplicationPause>b__26_0
02ce6c9c: bl      #0x3be7218                                 fn_3be7218
02ce6ca0: cbz     x0, #0x2ce6cb4                             
02ce6ca4: ldp     x20, x19, [sp, #0x10]                      
02ce6ca8: mov     x1, xzr                                    
02ce6cac: ldr     x30, [sp], #0x20                           
02ce6cb0: b       #0x2c88cec                                 AdsManager::HideMREC
02ce6cb4: bl      #0x2b7105c                                 fn_2b7105c
## RegisterCloseAction(System.Action value) -> void
---- ProfilePopup::RegisterCloseAction 0x2ce6cbc
02ce6cbc: str     x1, [x0, #0x88]!                           ._closeAction
02ce6cc0: b       #0x2b70d54                                 
## .ctor() -> void
---- ProfilePopup::.ctor 0x2ce6cc4
02ce6cc4: mov     x1, xzr                                    
02ce6cc8: b       #0x5b397b0                                 UnityEngine.MonoBehaviour::.ctor
## <OnInit>b__11_0() -> void
---- ProfilePopup::<OnInit>b__11_0 0x2ce6ccc
02ce6ccc: stp     x30, x19, [sp, #-0x10]!                    
02ce6cd0: movi    d1, #0000000000000000                      
02ce6cd4: movi    d2, #0000000000000000                      
02ce6cd8: mov     x19, x0                                    
02ce6cdc: fmov    s0, #1.00000000                            
02ce6ce0: mov     w0, #1                                     
02ce6ce4: mov     w1, wzr                                    
02ce6ce8: mov     w2, wzr                                    
02ce6cec: mov     x3, xzr                                    
02ce6cf0: bl      #0x2d84264                                 Framework.AudioHelper::PlaySound
02ce6cf4: ldr     x8, [x19]                                  
02ce6cf8: mov     x0, x19                                    
02ce6cfc: ldp     x2, x1, [x8, #0x198]                       
02ce6d00: ldp     x30, x19, [sp], #0x10                      
02ce6d04: br      x2                                         
## <OnInit>b__11_1() -> void
---- ProfilePopup::<OnInit>b__11_1 0x2ce6d08
02ce6d08: ldr     x8, [x0, #0x80]                            .RestoreCheck
02ce6d0c: cbz     x8, #0x2ce6d20                             
02ce6d10: ldr     x0, [x8, #0x40]                            
02ce6d14: ldr     x1, [x8, #0x28]                            
02ce6d18: ldr     x2, [x8, #0x18]                            
02ce6d1c: br      x2                                         
02ce6d20: ret                                                
## <OnInit>b__11_2() -> void
---- ProfilePopup::<OnInit>b__11_2 0x2ce6d24
02ce6d24: stp     x30, x19, [sp, #-0x10]!                    
02ce6d28: movi    d1, #0000000000000000                      
02ce6d2c: movi    d2, #0000000000000000                      
02ce6d30: mov     x19, x0                                    
02ce6d34: fmov    s0, #1.00000000                            
02ce6d38: mov     w0, #1                                     
02ce6d3c: mov     w1, wzr                                    
02ce6d40: mov     w2, wzr                                    
02ce6d44: mov     x3, xzr                                    
02ce6d48: bl      #0x2d84264                                 Framework.AudioHelper::PlaySound
02ce6d4c: ldr     x8, [x19]                                  
02ce6d50: mov     x0, x19                                    
02ce6d54: ldp     x2, x1, [x8, #0x198]                       
02ce6d58: ldp     x30, x19, [sp], #0x10                      
02ce6d5c: br      x2                                         
## <OnInit>b__11_3() -> void
---- ProfilePopup::<OnInit>b__11_3 0x2ce6d60
02ce6d60: stp     x30, x19, [sp, #-0x10]!                    
02ce6d64: movi    d1, #0000000000000000                      
02ce6d68: movi    d2, #0000000000000000                      
02ce6d6c: mov     x19, x0                                    
02ce6d70: fmov    s0, #1.00000000                            
02ce6d74: mov     w0, #1                                     
02ce6d78: mov     w1, wzr                                    
02ce6d7c: mov     w2, wzr                                    
02ce6d80: mov     x3, xzr                                    
02ce6d84: bl      #0x2d84264                                 Framework.AudioHelper::PlaySound
02ce6d88: mov     x0, x19                                    
02ce6d8c: ldp     x30, x19, [sp], #0x10                      
02ce6d90: b       #0x2ce6834                                 ProfilePopup::ChangeToNextLanguage
## <OnInit>b__11_4() -> void
---- ProfilePopup::<OnInit>b__11_4 0x2ce6d94
02ce6d94: stp     x30, x19, [sp, #-0x10]!                    
02ce6d98: movi    d1, #0000000000000000                      
02ce6d9c: movi    d2, #0000000000000000                      
02ce6da0: mov     x19, x0                                    
02ce6da4: fmov    s0, #1.00000000                            
02ce6da8: mov     w0, #1                                     
02ce6dac: mov     w1, wzr                                    
02ce6db0: mov     w2, wzr                                    
02ce6db4: mov     x3, xzr                                    
02ce6db8: bl      #0x2d84264                                 Framework.AudioHelper::PlaySound
02ce6dbc: mov     x0, x19                                    
02ce6dc0: ldp     x30, x19, [sp], #0x10                      
02ce6dc4: b       #0x2ce6968                                 ProfilePopup::ChangeToPrevLanguage
