#### CLASS LuckyWheelRewardConfig parent= object
#   field RewardId                       string                                             off=0x10 attr=6 
#   field Rate                           int                                                off=0x18 attr=6 
#   field Reward                         ELuckyWheelReward                                  off=0x1c attr=6 
#   field RewardAmount                   float                                              off=0x20 attr=6 
## .ctor() -> void
---- LuckyWheelRewardConfig::.ctor 0x2ca89d4
02ca89d4: mov     x1, xzr                                    
02ca89d8: b       #0x4e53e9c                                 System.Object::.ctor
