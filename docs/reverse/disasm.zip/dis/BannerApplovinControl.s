#### CLASS BannerApplovinControl parent= ApplovinEventBase
## Start() -> void
---- BannerApplovinControl::Start 0x2c8dc04
02c8dc04: mov     w8, #2                                     
02c8dc08: str     w8, [x0, #0x28]                            
02c8dc0c: ret                                                
## InitAd() -> void
---- BannerApplovinControl::InitAd 0x2c8dc10
02c8dc10: str     x30, [sp, #-0x40]!                         
02c8dc14: stp     x24, x23, [sp, #0x10]                      
02c8dc18: stp     x22, x21, [sp, #0x20]                      
02c8dc1c: stp     x20, x19, [sp, #0x30]                      
02c8dc20: adrp    x20, #0x662f000                            
02c8dc24: adrp    x21, #0x6265000                            
02c8dc28: mov     x19, x0                                    
02c8dc2c: ldrb    w8, [x20, #0x98f]                          
02c8dc30: ldr     x21, [x21, #0x3a0]                         T:MaxSdkBase/AdViewConfiguration
02c8dc34: tbnz    w8, #0, #0x2c8dc88                         
02c8dc38: adrp    x0, #0x6265000                             
02c8dc3c: ldr     x0, [x0, #0x350]                           T:type7232(k15)
02c8dc40: bl      #0x2b70db0                                 fn_2b70db0
02c8dc44: adrp    x0, #0x6265000                             
02c8dc48: ldr     x0, [x0, #0x358]                           T:type7234(k15)
02c8dc4c: bl      #0x2b70db0                                 fn_2b70db0
02c8dc50: adrp    x0, #0x6265000                             
02c8dc54: ldr     x0, [x0, #0x3a0]                           T:MaxSdkBase/AdViewConfiguration
02c8dc58: bl      #0x2b70db0                                 fn_2b70db0
02c8dc5c: adrp    x0, #0x6265000                             
02c8dc60: ldr     x0, [x0, #0x3a8]                           M:BannerApplovinControl::OnAdCollapsedEvent
02c8dc64: bl      #0x2b70db0                                 fn_2b70db0
02c8dc68: adrp    x0, #0x6265000                             
02c8dc6c: ldr     x0, [x0, #0x3b0]                           M:BannerApplovinControl::OnAdExpandedEvent
02c8dc70: bl      #0x2b70db0                                 fn_2b70db0
02c8dc74: adrp    x0, #0x6265000                             
02c8dc78: ldr     x0, [x0, #0x2f8]                           T:MaxSdkAndroid
02c8dc7c: bl      #0x2b70db0                                 fn_2b70db0
02c8dc80: mov     w8, #1                                     
02c8dc84: strb    w8, [x20, #0x98f]                          
02c8dc88: ldr     x0, [x21]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c8dc8c: bl      #0x2b7104c                                 fn_2b7104c
02c8dc90: mov     w1, #7                                     
02c8dc94: mov     x2, xzr                                    
02c8dc98: mov     x20, x0                                    
02c8dc9c: bl      #0x4c563a8                                 MaxSdkBase/AdViewConfiguration::.ctor
02c8dca0: cbz     x20, #0x2c8de34                            
02c8dca4: adrp    x21, #0x6265000                            
02c8dca8: adrp    x22, #0x6265000                            
02c8dcac: mov     w0, #2                                     
02c8dcb0: ldr     x21, [x21, #0x2f8]                         T:MaxSdkAndroid
02c8dcb4: ldr     x22, [x22, #0x350]                         T:type7232(k15)
02c8dcb8: strb    wzr, [x20, #0x1c]                          
02c8dcbc: bl      #0x2c8de38                                 KeyAds::Get
02c8dcc0: ldr     x8, [x21]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c8dcc4: mov     x21, x0                                    
02c8dcc8: ldr     w9, [x8, #0xe4]                            
02c8dccc: cbnz    w9, #0x2c8dcd8                             
02c8dcd0: mov     x0, x8                                     
02c8dcd4: bl      #0x2b70f30                                 fn_2b70f30
02c8dcd8: mov     x0, x21                                    
02c8dcdc: mov     x1, x20                                    
02c8dce0: mov     x2, xzr                                    
02c8dce4: bl      #0x4c50578                                 MaxSdkAndroid::CreateBanner
02c8dce8: mov     w0, #2                                     
02c8dcec: bl      #0x2c8de38                                 KeyAds::Get
02c8dcf0: movi    d0, #0000000000000000                      
02c8dcf4: movi    d1, #0000000000000000                      
02c8dcf8: mov     x1, xzr                                    
02c8dcfc: movi    d2, #0000000000000000                      
02c8dd00: fmov    s3, #1.00000000                            
02c8dd04: bl      #0x4c51634                                 MaxSdkAndroid::SetBannerBackgroundColor
02c8dd08: ldr     x0, [x22]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c8dd0c: bl      #0x2b7104c                                 fn_2b7104c
02c8dd10: cbz     x19, #0x2c8de34                            
02c8dd14: adrp    x24, #0x6265000                            
02c8dd18: adrp    x23, #0x6265000                            
02c8dd1c: adrp    x21, #0x6265000                            
02c8dd20: ldr     x24, [x24, #0x358]                         T:type7234(k15)
02c8dd24: ldr     x8, [x19]                                  
02c8dd28: ldr     x23, [x23, #0x3b0]                         M:BannerApplovinControl::OnAdExpandedEvent
02c8dd2c: ldr     x21, [x21, #0x3a8]                         M:BannerApplovinControl::OnAdCollapsedEvent
02c8dd30: mov     x1, x19                                    
02c8dd34: mov     x3, xzr                                    
02c8dd38: ldr     x2, [x8, #0x180]                           
02c8dd3c: mov     x20, x0                                    
02c8dd40: bl      #0x453ce6c                                 fn_453ce6c
02c8dd44: mov     x0, x20                                    
02c8dd48: mov     x1, xzr                                    
02c8dd4c: bl      #0x4c5eb74                                 MaxSdkCallbacks/Banner::add_OnAdLoadedEvent
02c8dd50: ldr     x0, [x24]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c8dd54: bl      #0x2b7104c                                 fn_2b7104c
02c8dd58: ldr     x8, [x19]                                  
02c8dd5c: mov     x1, x19                                    
02c8dd60: mov     x3, xzr                                    
02c8dd64: mov     x20, x0                                    
02c8dd68: ldr     x2, [x8, #0x190]                           
02c8dd6c: bl      #0x453ce6c                                 fn_453ce6c
02c8dd70: mov     x0, x20                                    
02c8dd74: mov     x1, xzr                                    
02c8dd78: bl      #0x4c5ed8c                                 MaxSdkCallbacks/Banner::add_OnAdLoadFailedEvent
02c8dd7c: ldr     x0, [x22]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c8dd80: bl      #0x2b7104c                                 fn_2b7104c
02c8dd84: ldr     x8, [x19]                                  
02c8dd88: mov     x1, x19                                    
02c8dd8c: mov     x3, xzr                                    
02c8dd90: mov     x20, x0                                    
02c8dd94: ldr     x2, [x8, #0x1b0]                           
02c8dd98: bl      #0x453ce6c                                 fn_453ce6c
02c8dd9c: mov     x0, x20                                    
02c8dda0: mov     x1, xzr                                    
02c8dda4: bl      #0x4c5ef84                                 MaxSdkCallbacks/Banner::add_OnAdClickedEvent
02c8dda8: ldr     x0, [x22]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c8ddac: bl      #0x2b7104c                                 fn_2b7104c
02c8ddb0: ldr     x8, [x19]                                  
02c8ddb4: mov     x1, x19                                    
02c8ddb8: mov     x3, xzr                                    
02c8ddbc: mov     x20, x0                                    
02c8ddc0: ldr     x2, [x8, #0x1e0]                           
02c8ddc4: bl      #0x453ce6c                                 fn_453ce6c
02c8ddc8: mov     x0, x20                                    
02c8ddcc: mov     x1, xzr                                    
02c8ddd0: bl      #0x4c5f17c                                 MaxSdkCallbacks/Banner::add_OnAdRevenuePaidEvent
02c8ddd4: ldr     x0, [x22]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c8ddd8: bl      #0x2b7104c                                 fn_2b7104c
02c8dddc: ldr     x2, [x23]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c8dde0: mov     x1, x19                                    
02c8dde4: mov     x3, xzr                                    
02c8dde8: mov     x20, x0                                    
02c8ddec: bl      #0x453ce6c                                 fn_453ce6c
02c8ddf0: mov     x0, x20                                    
02c8ddf4: mov     x1, xzr                                    
02c8ddf8: bl      #0x4c5f56c                                 MaxSdkCallbacks/Banner::add_OnAdExpandedEvent
02c8ddfc: ldr     x0, [x22]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c8de00: bl      #0x2b7104c                                 fn_2b7104c
02c8de04: ldr     x2, [x21]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c8de08: mov     x1, x19                                    
02c8de0c: mov     x3, xzr                                    
02c8de10: mov     x20, x0                                    
02c8de14: bl      #0x453ce6c                                 fn_453ce6c
02c8de18: mov     x0, x20                                    
02c8de1c: ldp     x20, x19, [sp, #0x30]                      
02c8de20: ldp     x22, x21, [sp, #0x20]                      
02c8de24: mov     x1, xzr                                    
02c8de28: ldp     x24, x23, [sp, #0x10]                      
02c8de2c: ldr     x30, [sp], #0x40                           
02c8de30: b       #0x4c5f764                                 MaxSdkCallbacks/Banner::add_OnAdCollapsedEvent
02c8de34: bl      #0x2b7105c                                 fn_2b7105c
## ShowAd() -> void
---- BannerApplovinControl::ShowAd 0x2c8cd94
02c8cd94: stp     x30, x21, [sp, #-0x20]!                    
02c8cd98: stp     x20, x19, [sp, #0x10]                      
02c8cd9c: adrp    x20, #0x662f000                            
02c8cda0: adrp    x21, #0x6265000                            
02c8cda4: adrp    x19, #0x6265000                            
02c8cda8: ldrb    w8, [x20, #0x990]                          
02c8cdac: ldr     x21, [x21, #0x320]                         S:'Show Banner'
02c8cdb0: ldr     x19, [x19, #0x2f8]                         T:MaxSdkAndroid
02c8cdb4: tbnz    w8, #0, #0x2c8cdd8                         
02c8cdb8: adrp    x0, #0x6265000                             
02c8cdbc: ldr     x0, [x0, #0x2f8]                           T:MaxSdkAndroid
02c8cdc0: bl      #0x2b70db0                                 fn_2b70db0
02c8cdc4: adrp    x0, #0x6265000                             
02c8cdc8: ldr     x0, [x0, #0x320]                           S:'Show Banner'
02c8cdcc: bl      #0x2b70db0                                 fn_2b70db0
02c8cdd0: mov     w8, #1                                     
02c8cdd4: strb    w8, [x20, #0x990]                          
02c8cdd8: ldr     x0, [x21]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c8cddc: mov     x1, xzr                                    
02c8cde0: bl      #0x2ca09f8                                 WLog::LogError
02c8cde4: mov     w0, #2                                     
02c8cde8: bl      #0x2c8de38                                 KeyAds::Get
02c8cdec: ldr     x8, [x19]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c8cdf0: mov     x19, x0                                    
02c8cdf4: ldr     w9, [x8, #0xe4]                            
02c8cdf8: cbnz    w9, #0x2c8ce04                             
02c8cdfc: mov     x0, x8                                     
02c8ce00: bl      #0x2b70f30                                 fn_2b70f30
02c8ce04: mov     x0, x19                                    
02c8ce08: ldp     x20, x19, [sp, #0x10]                      
02c8ce0c: mov     x1, xzr                                    
02c8ce10: ldp     x30, x21, [sp], #0x20                      
02c8ce14: b       #0x4c512ec                                 MaxSdkAndroid::ShowBanner
## HideAd() -> void
---- BannerApplovinControl::HideAd 0x2c8ce2c
02c8ce2c: stp     x30, x21, [sp, #-0x20]!                    
02c8ce30: stp     x20, x19, [sp, #0x10]                      
02c8ce34: adrp    x20, #0x662f000                            
02c8ce38: adrp    x21, #0x6265000                            
02c8ce3c: adrp    x19, #0x6265000                            
02c8ce40: ldrb    w8, [x20, #0x991]                          
02c8ce44: ldr     x21, [x21, #0x328]                         S:'Hide Banner'
02c8ce48: ldr     x19, [x19, #0x2f8]                         T:MaxSdkAndroid
02c8ce4c: tbnz    w8, #0, #0x2c8ce70                         
02c8ce50: adrp    x0, #0x6265000                             
02c8ce54: ldr     x0, [x0, #0x2f8]                           T:MaxSdkAndroid
02c8ce58: bl      #0x2b70db0                                 fn_2b70db0
02c8ce5c: adrp    x0, #0x6265000                             
02c8ce60: ldr     x0, [x0, #0x328]                           S:'Hide Banner'
02c8ce64: bl      #0x2b70db0                                 fn_2b70db0
02c8ce68: mov     w8, #1                                     
02c8ce6c: strb    w8, [x20, #0x991]                          
02c8ce70: ldr     x0, [x21]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c8ce74: mov     x1, xzr                                    
02c8ce78: bl      #0x2ca09f8                                 WLog::LogError
02c8ce7c: mov     w0, #2                                     
02c8ce80: bl      #0x2c8de38                                 KeyAds::Get
02c8ce84: ldr     x8, [x19]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c8ce88: mov     x19, x0                                    
02c8ce8c: ldr     w9, [x8, #0xe4]                            
02c8ce90: cbnz    w9, #0x2c8ce9c                             
02c8ce94: mov     x0, x8                                     
02c8ce98: bl      #0x2b70f30                                 fn_2b70f30
02c8ce9c: mov     x0, x19                                    
02c8cea0: ldp     x20, x19, [sp, #0x10]                      
02c8cea4: mov     x1, xzr                                    
02c8cea8: ldp     x30, x21, [sp], #0x20                      
02c8ceac: b       #0x4c5151c                                 MaxSdkAndroid::HideBanner
## OnAdLoadedEvent(string adUnitId, MaxSdkBase/AdInfo adInfo) -> void
---- BannerApplovinControl::OnAdLoadedEvent 0x2c8df00
02c8df00: b       #0x2c8b780                                 ApplovinEventBase::OnAdLoadedEvent
## OnAdLoadFailedEvent(string adUnitId, MaxSdkBase/ErrorInfo errorInfo) -> void
---- BannerApplovinControl::OnAdLoadFailedEvent 0x2c8df04
02c8df04: b       #0x2c8bb74                                 ApplovinEventBase::OnAdLoadFailedEvent
## OnAdExpandedEvent(string adUnitID, MaxSdkBase/AdInfo adInfo) -> void
---- BannerApplovinControl::OnAdExpandedEvent 0x2c8df08
02c8df08: ret                                                
## OnAdCollapsedEvent(string adUnitID, MaxSdkBase/AdInfo adInfo) -> void
---- BannerApplovinControl::OnAdCollapsedEvent 0x2c8df0c
02c8df0c: ret                                                
## .ctor() -> void
---- BannerApplovinControl::.ctor 0x2c8df10
02c8df10: b       #0x2c8c870                                 ApplovinEventBase::.ctor
