#### CLASS Framework.CenterOfMass/AutomaticSetModes parent= int
#   field value__                        int                                                off=0x10 attr=606 
#   field Awake                          Framework.CenterOfMass/AutomaticSetModes           off=0x0 attr=8056 
#   field Start                          Framework.CenterOfMass/AutomaticSetModes           off=0x0 attr=8056 
#   field ScriptOnly                     Framework.CenterOfMass/AutomaticSetModes           off=0x0 attr=8056 
#### CLASS Framework.CenterOfMass parent= UnityEngine.MonoBehaviour
#   field _centerOfMassOffset            UnityEngine.Vector3                                off=0x20 attr=1 HeaderAttribute,SerializeField
#   field _automaticSetMode              Framework.CenterOfMass/AutomaticSetModes           off=0x2c attr=1 HeaderAttribute,SerializeField
#   field _autoDestroyComponentAfterSet  bool                                               off=0x30 attr=1 SerializeField
#   field gizmoPointSize                 float                                              off=0x34 attr=6 HeaderAttribute
#   field gizmoCenter                    UnityEngine.Vector3                                off=0x38 attr=1 
#   field rb                             UnityEngine.Rigidbody                              off=0x48 attr=1 
#   field rb2d                           UnityEngine.Rigidbody2D                            off=0x50 attr=1 
## Awake() -> void
---- Framework.CenterOfMass::Awake 0x2cc61c0
02cc61c0: ldr     w8, [x0, #0x2c]                            ._automaticSetMode
02cc61c4: cbz     w8, #0x2cc61cc                             
02cc61c8: ret                                                
02cc61cc: ldr     x8, [x0]                                   
02cc61d0: ldp     x2, x1, [x8, #0x198]                       
02cc61d4: br      x2                                         
## Start() -> void
---- Framework.CenterOfMass::Start 0x2cc61d8
02cc61d8: ldr     w8, [x0, #0x2c]                            ._automaticSetMode
02cc61dc: cmp     w8, #1                                     
02cc61e0: b.ne    #0x2cc61f0                                 
02cc61e4: ldr     x8, [x0]                                   
02cc61e8: ldp     x2, x1, [x8, #0x198]                       
02cc61ec: br      x2                                         
02cc61f0: ret                                                
## SetCenterOfMass() -> void
---- Framework.CenterOfMass::SetCenterOfMass 0x2cc61f4
02cc61f4: str     x30, [sp, #-0x30]!                         
02cc61f8: stp     x22, x21, [sp, #0x10]                      
02cc61fc: stp     x20, x19, [sp, #0x20]                      
02cc6200: adrp    x20, #0x662f000                            
02cc6204: adrp    x21, #0x6264000                            
02cc6208: adrp    x22, #0x6263000                            
02cc620c: ldrb    w8, [x20, #0xc51]                          
02cc6210: ldr     x21, [x21, #0x8b8]                         MS:UnityEngine.Component::GetComponent
02cc6214: ldr     x22, [x22, #0x918]                         T:UnityEngine.Object
02cc6218: mov     x19, x0                                    
02cc621c: tbnz    w8, #0, #0x2cc6258                         
02cc6220: adrp    x0, #0x6264000                             
02cc6224: ldr     x0, [x0, #0xa70]                           T:UnityEngine.Application
02cc6228: bl      #0x2b70db0                                 fn_2b70db0
02cc622c: adrp    x0, #0x6264000                             
02cc6230: ldr     x0, [x0, #0x8b0]                           MS:UnityEngine.Component::GetComponent
02cc6234: bl      #0x2b70db0                                 fn_2b70db0
02cc6238: adrp    x0, #0x6264000                             
02cc623c: ldr     x0, [x0, #0x8b8]                           MS:UnityEngine.Component::GetComponent
02cc6240: bl      #0x2b70db0                                 fn_2b70db0
02cc6244: adrp    x0, #0x6263000                             
02cc6248: ldr     x0, [x0, #0x918]                           T:UnityEngine.Object
02cc624c: bl      #0x2b70db0                                 fn_2b70db0
02cc6250: mov     w8, #1                                     
02cc6254: strb    w8, [x20, #0xc51]                          
02cc6258: ldr     x1, [x21]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02cc625c: mov     x0, x19                                    
02cc6260: bl      #0x3140c84                                 fn_3140c84
02cc6264: mov     x20, x19                                   
02cc6268: mov     x1, x0                                     
02cc626c: str     x0, [x20, #0x48]!                          .rb
02cc6270: mov     x0, x20                                    
02cc6274: bl      #0x2b70d54                                 fn_2b70d54
02cc6278: ldr     x0, [x22]                                  &2c5bbd4(=a9bd7bfdd503233f)
02cc627c: ldr     x21, [x20]                                 &2b706c4(=eb01011ff9400808)
02cc6280: ldr     w8, [x0, #0xe4]                            [62630e4]=0 f=0,0
02cc6284: cbnz    w8, #0x2cc628c                             
02cc6288: bl      #0x2b70f30                                 fn_2b70f30
02cc628c: mov     x0, x21                                    
02cc6290: mov     x1, xzr                                    
02cc6294: mov     x2, xzr                                    
02cc6298: bl      #0x5b37d84                                 UnityEngine.Object::op_Equality
02cc629c: tbz     w0, #0, #0x2cc62c4                         
02cc62a0: adrp    x8, #0x6264000                             
02cc62a4: mov     x0, x19                                    
02cc62a8: ldr     x8, [x8, #0x8b0]                           MS:UnityEngine.Component::GetComponent
02cc62ac: ldr     x1, [x8]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02cc62b0: bl      #0x3140c84                                 fn_3140c84
02cc62b4: mov     x1, x0                                     
02cc62b8: mov     x0, x19                                    
02cc62bc: str     x1, [x0, #0x50]!                           .rb2d
02cc62c0: bl      #0x2b70d54                                 fn_2b70d54
02cc62c4: ldr     x0, [x22]                                  &2c5bbd4(=a9bd7bfdd503233f)
02cc62c8: ldr     x21, [x20]                                 &2b706c4(=eb01011ff9400808)
02cc62cc: ldr     w8, [x0, #0xe4]                            [62630e4]=0 f=0,0
02cc62d0: cbnz    w8, #0x2cc62d8                             
02cc62d4: bl      #0x2b70f30                                 fn_2b70f30
02cc62d8: mov     x0, x21                                    
02cc62dc: mov     x1, xzr                                    
02cc62e0: mov     x2, xzr                                    
02cc62e4: bl      #0x5b3666c                                 UnityEngine.Object::op_Inequality
02cc62e8: tbz     w0, #0, #0x2cc6308                         
02cc62ec: ldr     x0, [x20]                                  &2b706c4(=eb01011ff9400808)
02cc62f0: cbz     x0, #0x2cc63a8                             
02cc62f4: ldp     s1, s2, [x19, #0x24]                       
02cc62f8: mov     x1, xzr                                    
02cc62fc: ldr     s0, [x19, #0x20]                           ._centerOfMassOffset
02cc6300: bl      #0x5bd0b68                                 UnityEngine.Rigidbody::set_centerOfMass
02cc6304: b       #0x2cc6344                                 
02cc6308: ldr     x0, [x22]                                  &2c5bbd4(=a9bd7bfdd503233f)
02cc630c: ldr     x20, [x19, #0x50]                          .rb2d
02cc6310: ldr     w8, [x0, #0xe4]                            [62630e4]=0 f=0,0
02cc6314: cbnz    w8, #0x2cc631c                             
02cc6318: bl      #0x2b70f30                                 fn_2b70f30
02cc631c: mov     x0, x20                                    
02cc6320: mov     x1, xzr                                    
02cc6324: mov     x2, xzr                                    
02cc6328: bl      #0x5b3666c                                 UnityEngine.Object::op_Inequality
02cc632c: tbz     w0, #0, #0x2cc6344                         
02cc6330: ldr     x0, [x19, #0x50]                           .rb2d
02cc6334: cbz     x0, #0x2cc63a8                             
02cc6338: ldp     s0, s1, [x19, #0x20]                       ._centerOfMassOffset
02cc633c: mov     x1, xzr                                    
02cc6340: bl      #0x5bbec0c                                 UnityEngine.Rigidbody2D::set_centerOfMass
02cc6344: ldrb    w8, [x19, #0x30]                           ._autoDestroyComponentAfterSet
02cc6348: cbz     w8, #0x2cc6398                             
02cc634c: adrp    x8, #0x6264000                             
02cc6350: ldr     x8, [x8, #0xa70]                           T:UnityEngine.Application
02cc6354: ldr     x0, [x8]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02cc6358: ldr     w8, [x0, #0xe4]                            [62630e4]=0 f=0,0
02cc635c: cbnz    w8, #0x2cc6364                             
02cc6360: bl      #0x2b70f30                                 fn_2b70f30
02cc6364: mov     x0, xzr                                    
02cc6368: bl      #0x5aea438                                 UnityEngine.Application::get_isPlaying
02cc636c: tbz     w0, #0, #0x2cc6398                         
02cc6370: ldr     x0, [x22]                                  &2c5bbd4(=a9bd7bfdd503233f)
02cc6374: ldr     w8, [x0, #0xe4]                            [62630e4]=0 f=0,0
02cc6378: cbnz    w8, #0x2cc6380                             
02cc637c: bl      #0x2b70f30                                 fn_2b70f30
02cc6380: mov     x0, x19                                    
02cc6384: ldp     x20, x19, [sp, #0x20]                      
02cc6388: ldp     x22, x21, [sp, #0x10]                      
02cc638c: mov     x1, xzr                                    
02cc6390: ldr     x30, [sp], #0x30                           
02cc6394: b       #0x5b3ca38                                 UnityEngine.Object::Destroy
02cc6398: ldp     x20, x19, [sp, #0x20]                      
02cc639c: ldp     x22, x21, [sp, #0x10]                      
02cc63a0: ldr     x30, [sp], #0x30                           
02cc63a4: ret                                                
02cc63a8: bl      #0x2b7105c                                 fn_2b7105c
## OnDrawGizmosSelected() -> void
---- Framework.CenterOfMass::OnDrawGizmosSelected 0x2cc63ac
02cc63ac: stp     x30, x19, [sp, #-0x10]!                    
02cc63b0: mov     x1, xzr                                    
02cc63b4: mov     x19, x0                                    
02cc63b8: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02cc63bc: cbz     x0, #0x2cc63e0                             
02cc63c0: ldp     s1, s2, [x19, #0x24]                       
02cc63c4: mov     x1, xzr                                    
02cc63c8: ldr     s0, [x19, #0x20]                           ._centerOfMassOffset
02cc63cc: bl      #0x5b48000                                 UnityEngine.Transform::TransformPoint
02cc63d0: stp     s0, s1, [x19, #0x38]                       .gizmoCenter
02cc63d4: str     s2, [x19, #0x40]                           
02cc63d8: ldp     x30, x19, [sp], #0x10                      
02cc63dc: ret                                                
02cc63e0: bl      #0x2b7105c                                 fn_2b7105c
## .ctor() -> void
---- Framework.CenterOfMass::.ctor 0x2cc63e4
02cc63e4: mov     w8, #1                                     
02cc63e8: mov     x1, xzr                                    
02cc63ec: strb    w8, [x0, #0x30]                            ._autoDestroyComponentAfterSet
02cc63f0: mov     w8, #0xcccd                                
02cc63f4: movk    w8, #0x3dcc, lsl #16                       
02cc63f8: str     w8, [x0, #0x34]                            .gizmoPointSize
02cc63fc: b       #0x5b397b0                                 UnityEngine.MonoBehaviour::.ctor
