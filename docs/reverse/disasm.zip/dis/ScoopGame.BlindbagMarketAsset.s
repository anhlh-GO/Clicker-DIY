#### CLASS ScoopGame.BlindbagMarketAsset/<>c__DisplayClass2_0 parent= object
#   field id                             int                                                off=0x10 attr=6 
## .ctor() -> void
---- ScoopGame.BlindbagMarketAsset/<>c__DisplayClass2_0::.ctor 0x2d3bfac
02d3bfac: mov     x1, xzr                                    
02d3bfb0: b       #0x4e53e9c                                 System.Object::.ctor
## <GetData>b__0(ScoopGame.BlindBagMarketDataItem data) -> bool
---- ScoopGame.BlindbagMarketAsset/<>c__DisplayClass2_0::<GetData>b__0 0x2d3c05c
02d3c05c: cbz     x1, #0x2d3c074                             
02d3c060: ldr     w8, [x1, #0x10]                            
02d3c064: ldr     w9, [x0, #0x10]                            .id
02d3c068: cmp     w8, w9                                     
02d3c06c: cset    w0, eq                                     
02d3c070: ret                                                
02d3c074: str     x30, [sp, #-0x10]!                         
02d3c078: bl      #0x2b7105c                                 fn_2b7105c
## <GetData>b__1(ScoopGame.BlindBagMarketDataItem data) -> bool
---- ScoopGame.BlindbagMarketAsset/<>c__DisplayClass2_0::<GetData>b__1 0x2d3c07c
02d3c07c: cbz     x1, #0x2d3c094                             
02d3c080: ldr     w8, [x1, #0x10]                            
02d3c084: ldr     w9, [x0, #0x10]                            .id
02d3c088: cmp     w8, w9                                     
02d3c08c: cset    w0, eq                                     
02d3c090: ret                                                
02d3c094: str     x30, [sp, #-0x10]!                         
02d3c098: bl      #0x2b7105c                                 fn_2b7105c
#### CLASS ScoopGame.BlindbagMarketAsset parent= UnityEngine.ScriptableObject
#   field _dataList                      System.Collections.Generic.List`1<ScoopGame.BlindBagMarketDataItem> off=0x18 attr=1 SerializeField
#   field _dataListAB                    System.Collections.Generic.List`1<ScoopGame.BlindBagMarketDataItem> off=0x20 attr=1 SerializeField
## GetData(int id) -> ScoopGame.BlindBagMarketDataItem
---- ScoopGame.BlindbagMarketAsset::GetData 0x2d3be4c
02d3be4c: str     x30, [sp, #-0x30]!                         
02d3be50: stp     x22, x21, [sp, #0x10]                      
02d3be54: stp     x20, x19, [sp, #0x20]                      
02d3be58: adrp    x20, #0x6630000                            
02d3be5c: adrp    x22, #0x626a000                            
02d3be60: mov     w21, w1                                    
02d3be64: ldrb    w8, [x20, #0x163]                          
02d3be68: ldr     x22, [x22, #0xd40]                         T:ScoopGame.BlindbagMarketAsset/<>c__DisplayClass2_0
02d3be6c: mov     x19, x0                                    
02d3be70: tbnz    w8, #0, #0x2d3bec4                         
02d3be74: adrp    x0, #0x626a000                             
02d3be78: ldr     x0, [x0, #0xd48]                           MS:System.Collections.Generic.List`1::Find
02d3be7c: bl      #0x2b70db0                                 fn_2b70db0
02d3be80: adrp    x0, #0x626a000                             
02d3be84: ldr     x0, [x0, #0xd50]                           T:type57219(k15)
02d3be88: bl      #0x2b70db0                                 fn_2b70db0
02d3be8c: adrp    x0, #0x6264000                             
02d3be90: ldr     x0, [x0, #0xfc0]                           T:RemoteConfigManager
02d3be94: bl      #0x2b70db0                                 fn_2b70db0
02d3be98: adrp    x0, #0x626a000                             
02d3be9c: ldr     x0, [x0, #0xd58]                           M:ScoopGame.BlindbagMarketAsset/<>c__DisplayClass2_0::<GetData>b__0
02d3bea0: bl      #0x2b70db0                                 fn_2b70db0
02d3bea4: adrp    x0, #0x626a000                             
02d3bea8: ldr     x0, [x0, #0xd60]                           M:ScoopGame.BlindbagMarketAsset/<>c__DisplayClass2_0::<GetData>b__1
02d3beac: bl      #0x2b70db0                                 fn_2b70db0
02d3beb0: adrp    x0, #0x626a000                             
02d3beb4: ldr     x0, [x0, #0xd40]                           T:ScoopGame.BlindbagMarketAsset/<>c__DisplayClass2_0
02d3beb8: bl      #0x2b70db0                                 fn_2b70db0
02d3bebc: mov     w8, #1                                     
02d3bec0: strb    w8, [x20, #0x163]                          
02d3bec4: ldr     x0, [x22]                                  T:type56879(k15)
02d3bec8: bl      #0x2b7104c                                 fn_2b7104c
02d3becc: mov     x1, xzr                                    
02d3bed0: mov     x20, x0                                    
02d3bed4: bl      #0x4e53e9c                                 System.Object::.ctor
02d3bed8: cbz     x20, #0x2d3bfa8                            
02d3bedc: adrp    x22, #0x6264000                            
02d3bee0: ldr     x22, [x22, #0xfc0]                         T:RemoteConfigManager
02d3bee4: str     w21, [x20, #0x10]                          
02d3bee8: ldr     x0, [x22]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d3beec: ldr     w8, [x0, #0xe4]                            [626a0e4]=0 f=0,0
02d3bef0: cbnz    w8, #0x2d3bef8                             
02d3bef4: bl      #0x2b70f30                                 fn_2b70f30
02d3bef8: adrp    x21, #0x662f000                            
02d3befc: ldrb    w8, [x21, #0xbc1]                          
02d3bf00: cbnz    w8, #0x2d3bf18                             
02d3bf04: adrp    x0, #0x6264000                             
02d3bf08: ldr     x0, [x0, #0xfc0]                           T:RemoteConfigManager
02d3bf0c: bl      #0x2b70db0                                 fn_2b70db0
02d3bf10: mov     w8, #1                                     
02d3bf14: strb    w8, [x21, #0xbc1]                          
02d3bf18: ldr     x0, [x22]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d3bf1c: adrp    x21, #0x626a000                            
02d3bf20: ldr     w8, [x0, #0xe4]                            [62640e4]=0 f=0,0
02d3bf24: ldr     x21, [x21, #0xd50]                         T:type57219(k15)
02d3bf28: cbnz    w8, #0x2d3bf34                             
02d3bf2c: bl      #0x2b70f30                                 fn_2b70f30
02d3bf30: ldr     x0, [x22]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d3bf34: ldr     x8, [x0, #0xb8]                            MS:DG.Tweening.Core.Extensions::SetSpecialStartupMode
02d3bf38: ldr     x0, [x21]                                  T:type56879(k15)
02d3bf3c: ldr     w8, [x8, #0x10]                            
02d3bf40: cmp     w8, #1                                     
02d3bf44: b.ne    #0x2d3bf5c                                 
02d3bf48: ldr     x19, [x19, #0x18]                          ._dataList
02d3bf4c: bl      #0x2b7104c                                 fn_2b7104c
02d3bf50: adrp    x8, #0x626a000                             
02d3bf54: ldr     x8, [x8, #0xd58]                           M:ScoopGame.BlindbagMarketAsset/<>c__DisplayClass2_0::<GetData>b__0
02d3bf58: b       #0x2d3bf6c                                 
02d3bf5c: ldr     x19, [x19, #0x20]                          ._dataListAB
02d3bf60: bl      #0x2b7104c                                 fn_2b7104c
02d3bf64: adrp    x8, #0x626a000                             
02d3bf68: ldr     x8, [x8, #0xd60]                           M:ScoopGame.BlindbagMarketAsset/<>c__DisplayClass2_0::<GetData>b__1
02d3bf6c: ldr     x2, [x8]                                   T:type56879(k15)
02d3bf70: mov     x1, x20                                    
02d3bf74: mov     x3, xzr                                    
02d3bf78: mov     x21, x0                                    
02d3bf7c: bl      #0x399ba10                                 fn_399ba10
02d3bf80: cbz     x19, #0x2d3bfa8                            
02d3bf84: adrp    x8, #0x626a000                             
02d3bf88: mov     x0, x19                                    
02d3bf8c: mov     x1, x21                                    
02d3bf90: ldr     x8, [x8, #0xd48]                           MS:System.Collections.Generic.List`1::Find
02d3bf94: ldp     x20, x19, [sp, #0x20]                      
02d3bf98: ldp     x22, x21, [sp, #0x10]                      
02d3bf9c: ldr     x2, [x8]                                   T:type56879(k15)
02d3bfa0: ldr     x30, [sp], #0x30                           
02d3bfa4: b       #0x35a9868                                 
02d3bfa8: bl      #0x2b7105c                                 fn_2b7105c
## GetAllData() -> System.Collections.Generic.List`1<ScoopGame.BlindBagMarketDataItem>
---- ScoopGame.BlindbagMarketAsset::GetAllData 0x2d3bfb4
02d3bfb4: stp     x30, x21, [sp, #-0x20]!                    
02d3bfb8: stp     x20, x19, [sp, #0x10]                      
02d3bfbc: adrp    x21, #0x6630000                            
02d3bfc0: adrp    x20, #0x6264000                            
02d3bfc4: mov     x19, x0                                    
02d3bfc8: ldrb    w8, [x21, #0x164]                          
02d3bfcc: ldr     x20, [x20, #0xfc0]                         T:RemoteConfigManager
02d3bfd0: tbnz    w8, #0, #0x2d3bfe8                         
02d3bfd4: adrp    x0, #0x6264000                             
02d3bfd8: ldr     x0, [x0, #0xfc0]                           T:RemoteConfigManager
02d3bfdc: bl      #0x2b70db0                                 fn_2b70db0
02d3bfe0: mov     w8, #1                                     
02d3bfe4: strb    w8, [x21, #0x164]                          
02d3bfe8: ldr     x0, [x20]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d3bfec: ldr     w8, [x0, #0xe4]                            [62640e4]=0 f=0,0
02d3bff0: cbnz    w8, #0x2d3bff8                             
02d3bff4: bl      #0x2b70f30                                 fn_2b70f30
02d3bff8: adrp    x21, #0x662f000                            
02d3bffc: ldrb    w8, [x21, #0xbc1]                          
02d3c000: cbnz    w8, #0x2d3c018                             
02d3c004: adrp    x0, #0x6264000                             
02d3c008: ldr     x0, [x0, #0xfc0]                           T:RemoteConfigManager
02d3c00c: bl      #0x2b70db0                                 fn_2b70db0
02d3c010: mov     w8, #1                                     
02d3c014: strb    w8, [x21, #0xbc1]                          
02d3c018: ldr     x0, [x20]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d3c01c: ldr     w8, [x0, #0xe4]                            [62640e4]=0 f=0,0
02d3c020: cbnz    w8, #0x2d3c02c                             
02d3c024: bl      #0x2b70f30                                 fn_2b70f30
02d3c028: ldr     x0, [x20]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d3c02c: ldr     x8, [x0, #0xb8]                            MS:DG.Tweening.Core.Extensions::SetSpecialStartupMode
02d3c030: mov     w9, #0x18                                  
02d3c034: ldr     w8, [x8, #0x10]                            
02d3c038: cmp     w8, #1                                     
02d3c03c: mov     w8, #0x20                                  
02d3c040: csel    x8, x9, x8, eq                             
02d3c044: ldr     x0, [x19, x8]                              
02d3c048: ldp     x20, x19, [sp, #0x10]                      
02d3c04c: ldp     x30, x21, [sp], #0x20                      
02d3c050: ret                                                
## .ctor() -> void
---- ScoopGame.BlindbagMarketAsset::.ctor 0x2d3c054
02d3c054: mov     x1, xzr                                    
02d3c058: b       #0x5b398f0                                 UnityEngine.ScriptableObject::.ctor
