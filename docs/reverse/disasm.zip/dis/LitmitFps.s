#### CLASS LitmitFps parent= UnityEngine.MonoBehaviour
#   field targetFrameRate                int                                                off=0x20 attr=1 SerializeField
## Start() -> void
---- LitmitFps::Start 0x2cd6b10
02cd6b10: stp     x30, x21, [sp, #-0x20]!                    
02cd6b14: stp     x20, x19, [sp, #0x10]                      
02cd6b18: adrp    x21, #0x662f000                            
02cd6b1c: adrp    x20, #0x6264000                            
02cd6b20: mov     x19, x0                                    
02cd6b24: ldrb    w8, [x21, #0xd2e]                          
02cd6b28: ldr     x20, [x20, #0xa70]                         T:UnityEngine.Application
02cd6b2c: tbnz    w8, #0, #0x2cd6b44                         
02cd6b30: adrp    x0, #0x6264000                             
02cd6b34: ldr     x0, [x0, #0xa70]                           T:UnityEngine.Application
02cd6b38: bl      #0x2b70db0                                 fn_2b70db0
02cd6b3c: mov     w8, #1                                     
02cd6b40: strb    w8, [x21, #0xd2e]                          
02cd6b44: mov     w0, wzr                                    
02cd6b48: mov     x1, xzr                                    
02cd6b4c: bl      #0x5b003a4                                 UnityEngine.QualitySettings::set_vSyncCount
02cd6b50: ldr     x0, [x20]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02cd6b54: ldr     w19, [x19, #0x20]                          .targetFrameRate
02cd6b58: ldr     w8, [x0, #0xe4]                            [62640e4]=0 f=0,0
02cd6b5c: cbnz    w8, #0x2cd6b64                             
02cd6b60: bl      #0x2b70f30                                 fn_2b70f30
02cd6b64: mov     w0, w19                                    
02cd6b68: ldp     x20, x19, [sp, #0x10]                      
02cd6b6c: mov     x1, xzr                                    
02cd6b70: ldp     x30, x21, [sp], #0x20                      
02cd6b74: b       #0x5aeb0d8                                 UnityEngine.Application::set_targetFrameRate
## .ctor() -> void
---- LitmitFps::.ctor 0x2cd6b78
02cd6b78: mov     w8, #0x3c                                  
02cd6b7c: mov     x1, xzr                                    
02cd6b80: str     w8, [x0, #0x20]                            .targetFrameRate
02cd6b84: b       #0x5b397b0                                 UnityEngine.MonoBehaviour::.ctor
