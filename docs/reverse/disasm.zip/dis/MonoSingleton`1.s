#### CLASS MonoSingleton`1 parent= UnityEngine.MonoBehaviour
#   field m_Instance                     T                                                  off=0x0 attr=11 
##  get_Instance (no body)
##  Awake (no body)
##  Initiate (no body)
##  OnApplicationQuit (no body)
##  .ctor (no body)
