#### CLASS Framework.RangedFloat parent= System.ValueType
#   field min                            float                                              off=0x10 attr=6 
#   field max                            float                                              off=0x14 attr=6 
## .ctor(float min, float max) -> void
---- Framework.RangedFloat::.ctor 0x2cb8404
02cb8404: stp     s0, s1, [x0]                               
02cb8408: ret                                                
