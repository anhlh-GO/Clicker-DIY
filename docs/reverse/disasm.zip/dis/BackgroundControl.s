#### CLASS BackgroundControl parent= MonoSingleton`1<BackgroundControl>
#   field _scaleFit                      bool                                               off=0x20 attr=1 SerializeField
#   field _renderer                      UnityEngine.SpriteRenderer                         off=0x28 attr=1 
#   field _mainCamera                    UnityEngine.Camera                                 off=0x30 attr=1 
## ScaleFit() -> void
---- BackgroundControl::ScaleFit 0x2cafaf8
02cafaf8: sub     sp, sp, #0x50                              
02cafafc: stp     d9, d8, [sp, #0x20]                        
02cafb00: stp     x30, x21, [sp, #0x30]                      
02cafb04: stp     x20, x19, [sp, #0x40]                      
02cafb08: adrp    x20, #0x662f000                            
02cafb0c: mov     x19, x0                                    
02cafb10: ldrb    w8, [x20, #0xb5d]                          
02cafb14: tbnz    w8, #0, #0x2cafb2c                         
02cafb18: adrp    x0, #0x6266000                             
02cafb1c: ldr     x0, [x0, #0x910]                           MS:UnityEngine.Component::GetComponent
02cafb20: bl      #0x2b70db0                                 fn_2b70db0
02cafb24: mov     w8, #1                                     
02cafb28: strb    w8, [x20, #0xb5d]                          
02cafb2c: ldrb    w8, [x19, #0x20]                           ._scaleFit
02cafb30: cbz     w8, #0x2cafc34                             
02cafb34: adrp    x8, #0x6266000                             
02cafb38: mov     x0, x19                                    
02cafb3c: ldr     x8, [x8, #0x910]                           MS:UnityEngine.Component::GetComponent
02cafb40: ldr     x1, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cafb44: bl      #0x3140c84                                 fn_3140c84
02cafb48: mov     x20, x19                                   
02cafb4c: mov     x1, x0                                     
02cafb50: str     x0, [x20, #0x28]!                          ._renderer
02cafb54: mov     x0, x20                                    
02cafb58: bl      #0x2b70d54                                 fn_2b70d54
02cafb5c: mov     x0, xzr                                    
02cafb60: bl      #0x5aefe28                                 UnityEngine.Camera::get_main
02cafb64: mov     x21, x19                                   
02cafb68: mov     x1, x0                                     
02cafb6c: str     x0, [x21, #0x30]!                          ._mainCamera
02cafb70: mov     x0, x21                                    
02cafb74: bl      #0x2b70d54                                 fn_2b70d54
02cafb78: ldr     x0, [x21]                                  
02cafb7c: cbz     x0, #0x2cafc48                             
02cafb80: mov     x1, xzr                                    
02cafb84: bl      #0x5aedba0                                 UnityEngine.Camera::get_orthographicSize
02cafb88: ldr     x0, [x21]                                  
02cafb8c: cbz     x0, #0x2cafc48                             
02cafb90: mov     x1, xzr                                    
02cafb94: fmov    s8, s0                                     
02cafb98: bl      #0x5aee0f4                                 UnityEngine.Camera::get_aspect
02cafb9c: ldr     x0, [x20]                                  &2b706c4(=eb01011ff9400808)
02cafba0: cbz     x0, #0x2cafc48                             
02cafba4: fadd    s1, s8, s8                                 
02cafba8: add     x8, sp, #8                                 
02cafbac: mov     x1, xzr                                    
02cafbb0: fmul    s8, s1, s0                                 
02cafbb4: bl      #0x5b02028                                 UnityEngine.Renderer::get_bounds
02cafbb8: ldr     s0, [sp, #0x14]                            
02cafbbc: mov     x0, x19                                    
02cafbc0: mov     x1, xzr                                    
02cafbc4: fadd    s9, s0, s0                                 
02cafbc8: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02cafbcc: fcmp    s9, s8                                     
02cafbd0: mov     x19, x0                                    
02cafbd4: b.le    #0x2cafc18                                 
02cafbd8: adrp    x20, #0x662f000                            
02cafbdc: ldrb    w8, [x20, #0xa74]                          
02cafbe0: cbnz    w8, #0x2cafbf8                             
02cafbe4: adrp    x0, #0x6264000                             
02cafbe8: ldr     x0, [x0, #0xd8]                            T:UnityEngine.Vector3
02cafbec: bl      #0x2b70db0                                 fn_2b70db0
02cafbf0: mov     w8, #1                                     
02cafbf4: strb    w8, [x20, #0xa74]                          
02cafbf8: cbz     x19, #0x2cafc48                            
02cafbfc: adrp    x8, #0x6264000                             
02cafc00: ldr     x8, [x8, #0xd8]                            T:UnityEngine.Vector3
02cafc04: ldr     x8, [x8]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02cafc08: ldr     x8, [x8, #0xb8]                            MS:DG.Tweening.Core.Extensions::SetSpecialStartupMode
02cafc0c: ldp     s1, s2, [x8, #0x10]                        
02cafc10: ldr     s0, [x8, #0xc]                             [626400c]=0 f=0,0
02cafc14: b       #0x2cafc28                                 
02cafc18: cbz     x19, #0x2cafc48                            
02cafc1c: fdiv    s0, s8, s9                                 
02cafc20: fmov    s1, #1.00000000                            
02cafc24: fmov    s2, #1.00000000                            
02cafc28: mov     x0, x19                                    
02cafc2c: mov     x1, xzr                                    
02cafc30: bl      #0x5b470cc                                 UnityEngine.Transform::set_localScale
02cafc34: ldp     x20, x19, [sp, #0x40]                      
02cafc38: ldp     x30, x21, [sp, #0x30]                      
02cafc3c: ldp     d9, d8, [sp, #0x20]                        
02cafc40: add     sp, sp, #0x50                              
02cafc44: ret                                                
02cafc48: bl      #0x2b7105c                                 fn_2b7105c
## Start() -> void
---- BackgroundControl::Start 0x2cafc4c
02cafc4c: b       #0x2cafaf8                                 BackgroundControl::ScaleFit
## SetActive(bool isActive) -> void
---- BackgroundControl::SetActive 0x2cafc50
02cafc50: ldr     x0, [x0, #0x28]                            ._renderer
02cafc54: cbz     x0, #0x2cafc64                             
02cafc58: and     w1, w1, #1                                 
02cafc5c: mov     x2, xzr                                    
02cafc60: b       #0x5b02fc4                                 UnityEngine.Renderer::set_enabled
02cafc64: str     x30, [sp, #-0x10]!                         
02cafc68: bl      #0x2b7105c                                 fn_2b7105c
## .ctor() -> void
---- BackgroundControl::.ctor 0x2cafc6c
02cafc6c: stp     x30, x21, [sp, #-0x20]!                    
02cafc70: stp     x20, x19, [sp, #0x10]                      
02cafc74: adrp    x21, #0x662f000                            
02cafc78: adrp    x20, #0x6266000                            
02cafc7c: mov     x19, x0                                    
02cafc80: ldrb    w8, [x21, #0xb5e]                          
02cafc84: ldr     x20, [x20, #0x9b8]                         MS:MonoSingleton`1::.ctor
02cafc88: tbnz    w8, #0, #0x2cafca0                         
02cafc8c: adrp    x0, #0x6266000                             
02cafc90: ldr     x0, [x0, #0x9b8]                           MS:MonoSingleton`1::.ctor
02cafc94: bl      #0x2b70db0                                 fn_2b70db0
02cafc98: mov     w8, #1                                     
02cafc9c: strb    w8, [x21, #0xb5e]                          
02cafca0: mov     w8, #1                                     
02cafca4: ldr     x1, [x20]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cafca8: mov     x0, x19                                    
02cafcac: strb    w8, [x19, #0x20]                           ._scaleFit
02cafcb0: ldp     x20, x19, [sp, #0x10]                      
02cafcb4: ldp     x30, x21, [sp], #0x20                      
02cafcb8: b       #0x3769e18                                 
