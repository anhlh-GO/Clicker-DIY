#### CLASS NativeInterController parent= WejoyService.Singleton`1<NativeInterController>
#   field _nativeInter                   NativeInter                                        off=0x20 attr=1 SerializeField
## ShowAd(string placement, System.Action actionClose) -> void
---- NativeInterController::ShowAd 0x2c9b500
02c9b500: str     x30, [sp, #-0x40]!                         
02c9b504: stp     x24, x23, [sp, #0x10]                      
02c9b508: stp     x22, x21, [sp, #0x20]                      
02c9b50c: stp     x20, x19, [sp, #0x30]                      
02c9b510: adrp    x21, #0x662f000                            
02c9b514: adrp    x23, #0x6263000                            
02c9b518: mov     x19, x2                                    
02c9b51c: ldrb    w8, [x21, #0xa3c]                          
02c9b520: ldr     x23, [x23, #0x918]                         T:UnityEngine.Object
02c9b524: mov     x20, x1                                    
02c9b528: mov     x22, x0                                    
02c9b52c: tbnz    w8, #0, #0x2c9b550                         
02c9b530: adrp    x0, #0x6265000                             
02c9b534: ldr     x0, [x0, #0xa78]                           MS:UnityEngine.Object::Instantiate
02c9b538: bl      #0x2b70db0                                 fn_2b70db0
02c9b53c: adrp    x0, #0x6263000                             
02c9b540: ldr     x0, [x0, #0x918]                           T:UnityEngine.Object
02c9b544: bl      #0x2b70db0                                 fn_2b70db0
02c9b548: mov     w8, #1                                     
02c9b54c: strb    w8, [x21, #0xa3c]                          
02c9b550: adrp    x24, #0x6265000                            
02c9b554: mov     x0, x22                                    
02c9b558: mov     x1, xzr                                    
02c9b55c: ldr     x24, [x24, #0xa78]                         MS:UnityEngine.Object::Instantiate
02c9b560: ldr     x21, [x22, #0x20]                          
02c9b564: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02c9b568: ldr     x8, [x23]                                  &2c5bbd4(=a9bd7bfdd503233f)
02c9b56c: mov     x22, x0                                    
02c9b570: ldr     w9, [x8, #0xe4]                            
02c9b574: cbnz    w9, #0x2c9b580                             
02c9b578: mov     x0, x8                                     
02c9b57c: bl      #0x2b70f30                                 fn_2b70f30
02c9b580: ldr     x2, [x24]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9b584: mov     x0, x21                                    
02c9b588: mov     x1, x22                                    
02c9b58c: bl      #0x3275fcc                                 fn_3275fcc
02c9b590: cbz     x0, #0x2c9b5b0                             
02c9b594: mov     x1, x20                                    
02c9b598: mov     x2, x19                                    
02c9b59c: ldp     x20, x19, [sp, #0x30]                      
02c9b5a0: ldp     x22, x21, [sp, #0x20]                      
02c9b5a4: ldp     x24, x23, [sp, #0x10]                      
02c9b5a8: ldr     x30, [sp], #0x40                           
02c9b5ac: b       #0x2c9b218                                 NativeInter::ShowAd
02c9b5b0: bl      #0x2b7105c                                 fn_2b7105c
## .ctor() -> void
---- NativeInterController::.ctor 0x2c9b5b4
02c9b5b4: stp     x30, x21, [sp, #-0x20]!                    
02c9b5b8: stp     x20, x19, [sp, #0x10]                      
02c9b5bc: adrp    x20, #0x662f000                            
02c9b5c0: adrp    x21, #0x6265000                            
02c9b5c4: mov     x19, x0                                    
02c9b5c8: ldrb    w8, [x20, #0xa3d]                          
02c9b5cc: ldr     x21, [x21, #0xa80]                         MS:WejoyService.Singleton`1::.ctor
02c9b5d0: tbnz    w8, #0, #0x2c9b5e8                         
02c9b5d4: adrp    x0, #0x6265000                             
02c9b5d8: ldr     x0, [x0, #0xa80]                           MS:WejoyService.Singleton`1::.ctor
02c9b5dc: bl      #0x2b70db0                                 fn_2b70db0
02c9b5e0: mov     w8, #1                                     
02c9b5e4: strb    w8, [x20, #0xa3d]                          
02c9b5e8: mov     x0, x19                                    
02c9b5ec: ldp     x20, x19, [sp, #0x10]                      
02c9b5f0: ldr     x1, [x21]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9b5f4: ldp     x30, x21, [sp], #0x20                      
02c9b5f8: b       #0x3be76dc                                 
