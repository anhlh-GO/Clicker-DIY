#### CLASS Clicker.GlowSprite2DItem parent= PoolElement
#   field _light2D                       UnityEngine.Rendering.Universal.Light2D            off=0x28 attr=1 SerializeField
#   field _spreadLight2D                 UnityEngine.Rendering.Universal.Light2D            off=0x30 attr=1 SerializeField
#   field _glowStrength                  float                                              off=0x0 attr=8051 
#   field _upTime                        float                                              off=0x0 attr=8051 
#   field _downTime                      float                                              off=0x0 attr=8051 
#   field _currentValue                  float                                              off=0x38 attr=1 
#   field _glowTween                     DG.Tweening.Tween                                  off=0x40 attr=1 
## Awake() -> void
---- Clicker.GlowSprite2DItem::Awake 0x2d63184
02d63184: str     x30, [sp, #-0x10]!                         
02d63188: ldr     x8, [x0, #0x28]                            ._light2D
02d6318c: cbz     x8, #0x2d631ac                             
02d63190: ldr     x9, [x0, #0x30]                            ._spreadLight2D
02d63194: str     wzr, [x8, #0x40]                           
02d63198: cbz     x9, #0x2d631ac                             
02d6319c: str     wzr, [x9, #0x40]                           
02d631a0: str     wzr, [x0, #0x38]                           ._currentValue
02d631a4: ldr     x30, [sp], #0x10                           
02d631a8: ret                                                
02d631ac: bl      #0x2b7105c                                 fn_2b7105c
## SetColor(UnityEngine.Color color) -> void
---- Clicker.GlowSprite2DItem::SetColor 0x2d631b0
02d631b0: str     x30, [sp, #-0x10]!                         
02d631b4: ldr     x8, [x0, #0x28]                            ._light2D
02d631b8: cbz     x8, #0x2d631dc                             
02d631bc: stp     s0, s1, [x8, #0x30]                        
02d631c0: stp     s2, s3, [x8, #0x38]                        
02d631c4: ldr     x8, [x0, #0x30]                            ._spreadLight2D
02d631c8: cbz     x8, #0x2d631dc                             
02d631cc: stp     s0, s1, [x8, #0x30]                        
02d631d0: stp     s2, s3, [x8, #0x38]                        
02d631d4: ldr     x30, [sp], #0x10                           
02d631d8: ret                                                
02d631dc: bl      #0x2b7105c                                 fn_2b7105c
## SetSprite(UnityEngine.Sprite sprite) -> void
---- Clicker.GlowSprite2DItem::SetSprite 0x2d631e0
02d631e0: ldr     x0, [x0, #0x28]                            ._light2D
02d631e4: cbz     x0, #0x2d631f0                             
02d631e8: str     x1, [x0, #0x58]!                           
02d631ec: b       #0x2b70d54                                 
02d631f0: str     x30, [sp, #-0x10]!                         
02d631f4: bl      #0x2b7105c                                 fn_2b7105c
## DoGlow() -> void
---- Clicker.GlowSprite2DItem::DoGlow 0x2d631f8
02d631f8: stp     x29, x30, [sp, #-0x60]!                    
02d631fc: stp     x28, x27, [sp, #0x10]                      
02d63200: stp     x26, x25, [sp, #0x20]                      
02d63204: stp     x24, x23, [sp, #0x30]                      
02d63208: stp     x22, x21, [sp, #0x40]                      
02d6320c: stp     x20, x19, [sp, #0x50]                      
02d63210: adrp    x20, #0x6630000                            
02d63214: mov     x19, x0                                    
02d63218: ldrb    w8, [x20, #0x308]                          
02d6321c: tbnz    w8, #0, #0x2d632a0                         
02d63220: adrp    x0, #0x6263000                             
02d63224: ldr     x0, [x0, #0xfc0]                           T:type8528(k15)
02d63228: bl      #0x2b70db0                                 fn_2b70db0
02d6322c: adrp    x0, #0x6263000                             
02d63230: ldr     x0, [x0, #0xfc8]                           T:type8550(k15)
02d63234: bl      #0x2b70db0                                 fn_2b70db0
02d63238: adrp    x0, #0x6263000                             
02d6323c: ldr     x0, [x0, #0xfd0]                           T:DG.Tweening.DOTween
02d63240: bl      #0x2b70db0                                 fn_2b70db0
02d63244: adrp    x0, #0x626b000                             
02d63248: ldr     x0, [x0, #0xff0]                           M:Clicker.GlowSprite2DItem::<DoGlow>b__10_0
02d6324c: bl      #0x2b70db0                                 fn_2b70db0
02d63250: adrp    x0, #0x626b000                             
02d63254: ldr     x0, [x0, #0xff8]                           M:Clicker.GlowSprite2DItem::<DoGlow>b__10_1
02d63258: bl      #0x2b70db0                                 fn_2b70db0
02d6325c: adrp    x0, #0x626c000                             
02d63260: ldr     x0, [x0]                                   M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d63264: bl      #0x2b70db0                                 fn_2b70db0
02d63268: adrp    x0, #0x626c000                             
02d6326c: ldr     x0, [x0, #8]                               M:Clicker.GlowSprite2DItem::<DoGlow>b__10_3
02d63270: bl      #0x2b70db0                                 fn_2b70db0
02d63274: adrp    x0, #0x6264000                             
02d63278: ldr     x0, [x0, #0xe8]                            T:DG.Tweening.TweenCallback
02d6327c: bl      #0x2b70db0                                 fn_2b70db0
02d63280: adrp    x0, #0x6266000                             
02d63284: ldr     x0, [x0, #0xc90]                           MS:DG.Tweening.TweenSettingsExtensions::OnComplete
02d63288: bl      #0x2b70db0                                 fn_2b70db0
02d6328c: adrp    x0, #0x6267000                             
02d63290: ldr     x0, [x0, #0x970]                           MS:DG.Tweening.TweenSettingsExtensions::OnUpdate
02d63294: bl      #0x2b70db0                                 fn_2b70db0
02d63298: mov     w8, #1                                     
02d6329c: strb    w8, [x20, #0x308]                          
02d632a0: adrp    x23, #0x6263000                            
02d632a4: adrp    x21, #0x626b000                            
02d632a8: adrp    x29, #0x6263000                            
02d632ac: adrp    x22, #0x626b000                            
02d632b0: mov     x20, x19                                   
02d632b4: adrp    x28, #0x6263000                            
02d632b8: ldr     x23, [x23, #0xfc0]                         T:type8528(k15)
02d632bc: ldr     x21, [x21, #0xff0]                         M:Clicker.GlowSprite2DItem::<DoGlow>b__10_0
02d632c0: ldr     x29, [x29, #0xfc8]                         T:type8550(k15)
02d632c4: ldr     x22, [x22, #0xff8]                         M:Clicker.GlowSprite2DItem::<DoGlow>b__10_1
02d632c8: ldr     x0, [x20, #0x40]!                          ._glowTween
02d632cc: ldr     x28, [x28, #0xfd0]                         T:DG.Tweening.DOTween
02d632d0: cbz     x0, #0x2d632e0                             
02d632d4: mov     w1, wzr                                    
02d632d8: mov     x2, xzr                                    
02d632dc: bl      #0x2d8fe94                                 DG.Tweening.TweenExtensions::Kill
02d632e0: adrp    x25, #0x6264000                            
02d632e4: adrp    x27, #0x626c000                            
02d632e8: adrp    x26, #0x6267000                            
02d632ec: adrp    x24, #0x626c000                            
02d632f0: ldr     x25, [x25, #0xe8]                          T:DG.Tweening.TweenCallback
02d632f4: ldr     x27, [x27]                                 M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d632f8: ldr     x26, [x26, #0x970]                         MS:DG.Tweening.TweenSettingsExtensions::OnUpdate
02d632fc: ldr     x24, [x24, #8]                             M:Clicker.GlowSprite2DItem::<DoGlow>b__10_3
02d63300: ldr     x0, [x23]                                  &2c5bbd4(=a9bd7bfdd503233f)
02d63304: bl      #0x2b7104c                                 fn_2b7104c
02d63308: ldr     x2, [x21]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d6330c: mov     x1, x19                                    
02d63310: mov     x3, xzr                                    
02d63314: mov     x21, x0                                    
02d63318: bl      #0x44536ec                                 fn_44536ec
02d6331c: ldr     x0, [x29]                                  &2c5bbd4(=a9bd7bfdd503233f)
02d63320: bl      #0x2b7104c                                 fn_2b7104c
02d63324: ldr     x2, [x22]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d63328: mov     x1, x19                                    
02d6332c: mov     x3, xzr                                    
02d63330: mov     x22, x0                                    
02d63334: bl      #0x4454818                                 fn_4454818
02d63338: ldr     x0, [x28]                                  &2c5bbd4(=a9bd7bfdd503233f)
02d6333c: ldr     w8, [x0, #0xe4]                            [62670e4]=0 f=0,0
02d63340: cbnz    w8, #0x2d63348                             
02d63344: bl      #0x2b70f30                                 fn_2b70f30
02d63348: adrp    x8, #0x1084000                             
02d6334c: mov     x0, x21                                    
02d63350: mov     x1, x22                                    
02d63354: ldr     s0, [x8, #0xeec]                           [1084eec]=457ff0003dcccccd f=0.1,4095
02d63358: mov     x2, xzr                                    
02d6335c: fmov    s1, s0                                     
02d63360: bl      #0x2d8b3b4                                 DG.Tweening.DOTween::To
02d63364: ldr     x8, [x25]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d63368: mov     x21, x0                                    
02d6336c: mov     x0, x8                                     
02d63370: bl      #0x2b7104c                                 fn_2b7104c
02d63374: ldr     x2, [x27]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d63378: mov     x1, x19                                    
02d6337c: mov     x3, xzr                                    
02d63380: mov     x22, x0                                    
02d63384: bl      #0x2d89dc4                                 DG.Tweening.TweenCallback::.ctor
02d63388: ldr     x2, [x26]                                  S:'didu'
02d6338c: mov     x0, x21                                    
02d63390: mov     x1, x22                                    
02d63394: bl      #0x336f3a0                                 fn_336f3a0
02d63398: ldr     x8, [x25]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d6339c: mov     x21, x0                                    
02d633a0: mov     x0, x8                                     
02d633a4: bl      #0x2b7104c                                 fn_2b7104c
02d633a8: ldr     x2, [x24]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d633ac: mov     x1, x19                                    
02d633b0: mov     x3, xzr                                    
02d633b4: mov     x22, x0                                    
02d633b8: bl      #0x2d89dc4                                 DG.Tweening.TweenCallback::.ctor
02d633bc: adrp    x8, #0x6266000                             
02d633c0: mov     x0, x21                                    
02d633c4: mov     x1, x22                                    
02d633c8: ldr     x8, [x8, #0xc90]                           MS:DG.Tweening.TweenSettingsExtensions::OnComplete
02d633cc: ldr     x2, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d633d0: bl      #0x336f26c                                 fn_336f26c
02d633d4: mov     x1, x0                                     
02d633d8: mov     x0, x20                                    
02d633dc: str     x1, [x19, #0x40]                           ._glowTween
02d633e0: ldp     x20, x19, [sp, #0x50]                      
02d633e4: ldp     x22, x21, [sp, #0x40]                      
02d633e8: ldp     x24, x23, [sp, #0x30]                      
02d633ec: ldp     x26, x25, [sp, #0x20]                      
02d633f0: ldp     x28, x27, [sp, #0x10]                      
02d633f4: ldp     x29, x30, [sp], #0x60                      
02d633f8: b       #0x2b70d54                                 
## .ctor() -> void
---- Clicker.GlowSprite2DItem::.ctor 0x2d633fc
02d633fc: mov     x1, xzr                                    
02d63400: b       #0x2cd6228                                 PoolElement::.ctor
## <DoGlow>b__10_0() -> float
---- Clicker.GlowSprite2DItem::<DoGlow>b__10_0 0x2d63404
02d63404: ldr     s0, [x0, #0x38]                            ._currentValue
02d63408: ret                                                
## <DoGlow>b__10_1(float x) -> void
---- Clicker.GlowSprite2DItem::<DoGlow>b__10_1 0x2d6340c
02d6340c: str     s0, [x0, #0x38]                            ._currentValue
02d63410: ret                                                
## <DoGlow>b__10_2() -> void
---- Clicker.GlowSprite2DItem::<DoGlow>b__10_2 0x2d63414
02d63414: str     x30, [sp, #-0x10]!                         
02d63418: ldr     x9, [x0, #0x28]                            ._light2D
02d6341c: cbz     x9, #0x2d63448                             
02d63420: ldr     s0, [x0, #0x38]                            ._currentValue
02d63424: ldr     x8, [x0, #0x30]                            ._spreadLight2D
02d63428: str     s0, [x9, #0x40]                            
02d6342c: cbz     x8, #0x2d63448                             
02d63430: adrp    x9, #0x1084000                             
02d63434: ldr     s1, [x9, #0xeec]                           [1084eec]=457ff0003dcccccd f=0.1,4095
02d63438: fdiv    s0, s0, s1                                 
02d6343c: str     s0, [x8, #0x40]                            
02d63440: ldr     x30, [sp], #0x10                           
02d63444: ret                                                
02d63448: bl      #0x2b7105c                                 fn_2b7105c
## <DoGlow>b__10_3() -> void
---- Clicker.GlowSprite2DItem::<DoGlow>b__10_3 0x2d6344c
02d6344c: stp     x30, x27, [sp, #-0x50]!                    
02d63450: stp     x26, x25, [sp, #0x10]                      
02d63454: stp     x24, x23, [sp, #0x20]                      
02d63458: stp     x22, x21, [sp, #0x30]                      
02d6345c: stp     x20, x19, [sp, #0x40]                      
02d63460: adrp    x27, #0x6263000                            
02d63464: adrp    x20, #0x626c000                            
02d63468: adrp    x23, #0x6630000                            
02d6346c: adrp    x24, #0x6263000                            
02d63470: adrp    x21, #0x626c000                            
02d63474: adrp    x22, #0x6263000                            
02d63478: ldr     x27, [x27, #0xfc0]                         T:type8528(k15)
02d6347c: ldr     x20, [x20, #0x10]                          M:Clicker.GlowSprite2DItem::<DoGlow>b__10_4
02d63480: ldr     x24, [x24, #0xfc8]                         T:type8550(k15)
02d63484: ldrb    w8, [x23, #0x309]                          
02d63488: ldr     x21, [x21, #0x18]                          M:Clicker.GlowSprite2DItem::<DoGlow>b__10_5
02d6348c: ldr     x22, [x22, #0xfd0]                         T:DG.Tweening.DOTween
02d63490: mov     x19, x0                                    
02d63494: tbnz    w8, #0, #0x2d63500                         
02d63498: adrp    x0, #0x6263000                             
02d6349c: ldr     x0, [x0, #0xfc0]                           T:type8528(k15)
02d634a0: bl      #0x2b70db0                                 fn_2b70db0
02d634a4: adrp    x0, #0x6263000                             
02d634a8: ldr     x0, [x0, #0xfc8]                           T:type8550(k15)
02d634ac: bl      #0x2b70db0                                 fn_2b70db0
02d634b0: adrp    x0, #0x6263000                             
02d634b4: ldr     x0, [x0, #0xfd0]                           T:DG.Tweening.DOTween
02d634b8: bl      #0x2b70db0                                 fn_2b70db0
02d634bc: adrp    x0, #0x626c000                             
02d634c0: ldr     x0, [x0, #0x10]                            M:Clicker.GlowSprite2DItem::<DoGlow>b__10_4
02d634c4: bl      #0x2b70db0                                 fn_2b70db0
02d634c8: adrp    x0, #0x626c000                             
02d634cc: ldr     x0, [x0, #0x18]                            M:Clicker.GlowSprite2DItem::<DoGlow>b__10_5
02d634d0: bl      #0x2b70db0                                 fn_2b70db0
02d634d4: adrp    x0, #0x626c000                             
02d634d8: ldr     x0, [x0, #0x20]                            M:Clicker.GlowSprite2DItem::<DoGlow>b__10_6
02d634dc: bl      #0x2b70db0                                 fn_2b70db0
02d634e0: adrp    x0, #0x6264000                             
02d634e4: ldr     x0, [x0, #0xe8]                            T:DG.Tweening.TweenCallback
02d634e8: bl      #0x2b70db0                                 fn_2b70db0
02d634ec: adrp    x0, #0x6267000                             
02d634f0: ldr     x0, [x0, #0x970]                           MS:DG.Tweening.TweenSettingsExtensions::OnUpdate
02d634f4: bl      #0x2b70db0                                 fn_2b70db0
02d634f8: mov     w8, #1                                     
02d634fc: strb    w8, [x23, #0x309]                          
02d63500: adrp    x26, #0x6264000                            
02d63504: adrp    x25, #0x626c000                            
02d63508: adrp    x23, #0x6267000                            
02d6350c: ldr     x26, [x26, #0xe8]                          T:DG.Tweening.TweenCallback
02d63510: ldr     x25, [x25, #0x20]                          M:Clicker.GlowSprite2DItem::<DoGlow>b__10_6
02d63514: ldr     x23, [x23, #0x970]                         MS:DG.Tweening.TweenSettingsExtensions::OnUpdate
02d63518: ldr     x0, [x27]                                  &2c5bbd4(=a9bd7bfdd503233f)
02d6351c: bl      #0x2b7104c                                 fn_2b7104c
02d63520: ldr     x2, [x20]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d63524: mov     x1, x19                                    
02d63528: mov     x3, xzr                                    
02d6352c: mov     x20, x0                                    
02d63530: bl      #0x44536ec                                 fn_44536ec
02d63534: ldr     x0, [x24]                                  &2c5bbd4(=a9bd7bfdd503233f)
02d63538: bl      #0x2b7104c                                 fn_2b7104c
02d6353c: ldr     x2, [x21]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d63540: mov     x1, x19                                    
02d63544: mov     x3, xzr                                    
02d63548: mov     x21, x0                                    
02d6354c: bl      #0x4454818                                 fn_4454818
02d63550: ldr     x0, [x22]                                  &2c5bbd4(=a9bd7bfdd503233f)
02d63554: ldr     w8, [x0, #0xe4]                            [62670e4]=0 f=0,0
02d63558: cbnz    w8, #0x2d63560                             
02d6355c: bl      #0x2b70f30                                 fn_2b70f30
02d63560: movi    d0, #0000000000000000                      
02d63564: fmov    s1, #0.50000000                            
02d63568: mov     x0, x20                                    
02d6356c: mov     x1, x21                                    
02d63570: mov     x2, xzr                                    
02d63574: bl      #0x2d8b3b4                                 DG.Tweening.DOTween::To
02d63578: ldr     x8, [x26]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d6357c: mov     x20, x0                                    
02d63580: mov     x0, x8                                     
02d63584: bl      #0x2b7104c                                 fn_2b7104c
02d63588: ldr     x2, [x25]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d6358c: mov     x1, x19                                    
02d63590: mov     x3, xzr                                    
02d63594: mov     x21, x0                                    
02d63598: bl      #0x2d89dc4                                 DG.Tweening.TweenCallback::.ctor
02d6359c: ldr     x2, [x23]                                  S:'didu'
02d635a0: mov     x0, x20                                    
02d635a4: mov     x1, x21                                    
02d635a8: bl      #0x336f3a0                                 fn_336f3a0
02d635ac: str     x0, [x19, #0x40]!                          ._glowTween
02d635b0: mov     x1, x0                                     
02d635b4: mov     x0, x19                                    
02d635b8: ldp     x20, x19, [sp, #0x40]                      
02d635bc: ldp     x22, x21, [sp, #0x30]                      
02d635c0: ldp     x24, x23, [sp, #0x20]                      
02d635c4: ldp     x26, x25, [sp, #0x10]                      
02d635c8: ldp     x30, x27, [sp], #0x50                      
02d635cc: b       #0x2b70d54                                 
## <DoGlow>b__10_4() -> float
---- Clicker.GlowSprite2DItem::<DoGlow>b__10_4 0x2d635d0
02d635d0: ldr     s0, [x0, #0x38]                            ._currentValue
02d635d4: ret                                                
## <DoGlow>b__10_5(float x) -> void
---- Clicker.GlowSprite2DItem::<DoGlow>b__10_5 0x2d635d8
02d635d8: str     s0, [x0, #0x38]                            ._currentValue
02d635dc: ret                                                
## <DoGlow>b__10_6() -> void
---- Clicker.GlowSprite2DItem::<DoGlow>b__10_6 0x2d635e0
02d635e0: str     x30, [sp, #-0x10]!                         
02d635e4: ldr     x9, [x0, #0x28]                            ._light2D
02d635e8: cbz     x9, #0x2d63614                             
02d635ec: ldr     s0, [x0, #0x38]                            ._currentValue
02d635f0: ldr     x8, [x0, #0x30]                            ._spreadLight2D
02d635f4: str     s0, [x9, #0x40]                            
02d635f8: cbz     x8, #0x2d63614                             
02d635fc: adrp    x9, #0x1084000                             
02d63600: ldr     s1, [x9, #0xeec]                           [1084eec]=457ff0003dcccccd f=0.1,4095
02d63604: fdiv    s0, s0, s1                                 
02d63608: str     s0, [x8, #0x40]                            
02d6360c: ldr     x30, [sp], #0x10                           
02d63610: ret                                                
02d63614: bl      #0x2b7105c                                 fn_2b7105c
