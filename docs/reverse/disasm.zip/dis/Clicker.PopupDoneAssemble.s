#### CLASS Clicker.PopupDoneAssemble parent= PopupBase
#   field _btnContinue                   UnityEngine.UI.Button                              off=0x38 attr=1 SerializeField
#   field _fxConfetti                    AssetKits.ParticleImage.ParticleImage              off=0x40 attr=1 SerializeField
## OnInit(UIManager uiManager) -> void
---- Clicker.PopupDoneAssemble::OnInit 0x2d6fbfc
02d6fbfc: stp     x30, x21, [sp, #-0x20]!                    
02d6fc00: stp     x20, x19, [sp, #0x10]                      
02d6fc04: adrp    x21, #0x6630000                            
02d6fc08: mov     x20, x1                                    
02d6fc0c: mov     x19, x0                                    
02d6fc10: ldrb    w8, [x21, #0x398]                          
02d6fc14: tbnz    w8, #0, #0x2d6fc38                         
02d6fc18: adrp    x0, #0x626c000                             
02d6fc1c: ldr     x0, [x0, #0x520]                           M:Clicker.PopupDoneAssemble::<OnInit>b__2_0
02d6fc20: bl      #0x2b70db0                                 fn_2b70db0
02d6fc24: adrp    x0, #0x6265000                             
02d6fc28: ldr     x0, [x0, #0x3f0]                           T:UnityEngine.Events.UnityAction
02d6fc2c: bl      #0x2b70db0                                 fn_2b70db0
02d6fc30: mov     w8, #1                                     
02d6fc34: strb    w8, [x21, #0x398]                          
02d6fc38: mov     x0, x19                                    
02d6fc3c: mov     x1, x20                                    
02d6fc40: mov     x2, xzr                                    
02d6fc44: bl      #0x2cdd3c4                                 UIBase::OnInit
02d6fc48: ldr     x8, [x19, #0x38]                           ._btnContinue
02d6fc4c: cbz     x8, #0x2d6fcb4                             
02d6fc50: ldr     x0, [x8, #0x100]                           
02d6fc54: cbz     x0, #0x2d6fcb4                             
02d6fc58: mov     x1, xzr                                    
02d6fc5c: bl      #0x5b4ce48                                 UnityEngine.Events.UnityEventBase::RemoveAllListeners
02d6fc60: ldr     x8, [x19, #0x38]                           ._btnContinue
02d6fc64: cbz     x8, #0x2d6fcb4                             
02d6fc68: adrp    x9, #0x6265000                             
02d6fc6c: adrp    x21, #0x626c000                            
02d6fc70: ldr     x9, [x9, #0x3f0]                           T:UnityEngine.Events.UnityAction
02d6fc74: ldr     x21, [x21, #0x520]                         M:Clicker.PopupDoneAssemble::<OnInit>b__2_0
02d6fc78: ldr     x20, [x8, #0x100]                          
02d6fc7c: ldr     x0, [x9]                                   M:AdsManager::<OnApplicationPause>b__26_0
02d6fc80: bl      #0x2b7104c                                 fn_2b7104c
02d6fc84: ldr     x2, [x21]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d6fc88: mov     x1, x19                                    
02d6fc8c: mov     x3, xzr                                    
02d6fc90: mov     x21, x0                                    
02d6fc94: bl      #0x5b4cf98                                 UnityEngine.Events.UnityAction::.ctor
02d6fc98: cbz     x20, #0x2d6fcb4                            
02d6fc9c: mov     x0, x20                                    
02d6fca0: ldp     x20, x19, [sp, #0x10]                      
02d6fca4: mov     x1, x21                                    
02d6fca8: mov     x2, xzr                                    
02d6fcac: ldp     x30, x21, [sp], #0x20                      
02d6fcb0: b       #0x5b4d0ac                                 UnityEngine.Events.UnityEvent::AddListener
02d6fcb4: bl      #0x2b7105c                                 fn_2b7105c
## OnShow() -> void
---- Clicker.PopupDoneAssemble::OnShow 0x2d6fcb8
02d6fcb8: stp     x30, x19, [sp, #-0x10]!                    
02d6fcbc: mov     x1, xzr                                    
02d6fcc0: mov     x19, x0                                    
02d6fcc4: bl      #0x2cdd6b8                                 UIBase::OnShow
02d6fcc8: bl      #0x2d6eec8                                 Framework.AudioManager::get_Instance
02d6fccc: cbz     x0, #0x2d6fd10                             
02d6fcd0: movi    d1, #0000000000000000                      
02d6fcd4: movi    d2, #0000000000000000                      
02d6fcd8: mov     w1, #0x2d                                  
02d6fcdc: fmov    s0, #1.00000000                            
02d6fce0: mov     w2, wzr                                    
02d6fce4: mov     w3, wzr                                    
02d6fce8: bl      #0x2d6f03c                                 Framework.AudioManager::PlaySound
02d6fcec: ldr     x0, [x19, #0x40]                           ._fxConfetti
02d6fcf0: cbz     x0, #0x2d6fd10                             
02d6fcf4: mov     x1, xzr                                    
02d6fcf8: bl      #0x5b339ec                                 UnityEngine.Component::get_gameObject
02d6fcfc: cbz     x0, #0x2d6fd10                             
02d6fd00: mov     w1, #1                                     
02d6fd04: mov     x2, xzr                                    
02d6fd08: ldp     x30, x19, [sp], #0x10                      
02d6fd0c: b       #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d6fd10: bl      #0x2b7105c                                 fn_2b7105c
## OnHide() -> void
---- Clicker.PopupDoneAssemble::OnHide 0x2d6fd14
02d6fd14: stp     x30, x19, [sp, #-0x10]!                    
02d6fd18: mov     x1, xzr                                    
02d6fd1c: mov     x19, x0                                    
02d6fd20: bl      #0x2cddc10                                 UIBase::OnHide
02d6fd24: ldr     x0, [x19, #0x40]                           ._fxConfetti
02d6fd28: cbz     x0, #0x2d6fd58                             
02d6fd2c: mov     x1, xzr                                    
02d6fd30: bl      #0x4f871ec                                 AssetKits.ParticleImage.ParticleImage::Stop
02d6fd34: ldr     x0, [x19, #0x40]                           ._fxConfetti
02d6fd38: cbz     x0, #0x2d6fd58                             
02d6fd3c: mov     x1, xzr                                    
02d6fd40: bl      #0x5b339ec                                 UnityEngine.Component::get_gameObject
02d6fd44: cbz     x0, #0x2d6fd58                             
02d6fd48: mov     w1, wzr                                    
02d6fd4c: mov     x2, xzr                                    
02d6fd50: ldp     x30, x19, [sp], #0x10                      
02d6fd54: b       #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d6fd58: bl      #0x2b7105c                                 fn_2b7105c
## .ctor() -> void
---- Clicker.PopupDoneAssemble::.ctor 0x2d6fd5c
02d6fd5c: mov     x1, xzr                                    
02d6fd60: b       #0x2cddba8                                 PopupBase::.ctor
## <OnInit>b__2_0() -> void
---- Clicker.PopupDoneAssemble::<OnInit>b__2_0 0x2d6fd64
02d6fd64: str     x30, [sp, #-0x30]!                         
02d6fd68: stp     x22, x21, [sp, #0x10]                      
02d6fd6c: stp     x20, x19, [sp, #0x20]                      
02d6fd70: adrp    x21, #0x6630000                            
02d6fd74: adrp    x20, #0x6266000                            
02d6fd78: mov     x19, x0                                    
02d6fd7c: ldrb    w8, [x21, #0x399]                          
02d6fd80: ldr     x20, [x20, #0x658]                         MS:MonoSingleton`1::get_Instance
02d6fd84: tbnz    w8, #0, #0x2d6fde4                         
02d6fd88: adrp    x0, #0x6264000                             
02d6fd8c: ldr     x0, [x0, #0xf90]                           T:System.Action
02d6fd90: bl      #0x2b70db0                                 fn_2b70db0
02d6fd94: adrp    x0, #0x6266000                             
02d6fd98: ldr     x0, [x0, #0x750]                           MS:DataManager::GetData
02d6fd9c: bl      #0x2b70db0                                 fn_2b70db0
02d6fda0: adrp    x0, #0x6265000                             
02d6fda4: ldr     x0, [x0, #0xb38]                           T:DevTrack
02d6fda8: bl      #0x2b70db0                                 fn_2b70db0
02d6fdac: adrp    x0, #0x6266000                             
02d6fdb0: ldr     x0, [x0, #0x658]                           MS:MonoSingleton`1::get_Instance
02d6fdb4: bl      #0x2b70db0                                 fn_2b70db0
02d6fdb8: adrp    x0, #0x626c000                             
02d6fdbc: ldr     x0, [x0, #0x528]                           M:Clicker.PopupDoneAssemble::<OnInit>g__ContinueToLivestream|2_1
02d6fdc0: bl      #0x2b70db0                                 fn_2b70db0
02d6fdc4: adrp    x0, #0x6265000                             
02d6fdc8: ldr     x0, [x0, #0x310]                           MS:WejoyService.Singleton`1::get_Instance
02d6fdcc: bl      #0x2b70db0                                 fn_2b70db0
02d6fdd0: adrp    x0, #0x626c000                             
02d6fdd4: ldr     x0, [x0, #0x530]                           S:'countinue'
02d6fdd8: bl      #0x2b70db0                                 fn_2b70db0
02d6fddc: mov     w8, #1                                     
02d6fde0: strb    w8, [x21, #0x399]                          
02d6fde4: bl      #0x2d6ff04                                 Framework.AudioHelper::PlayClickSound
02d6fde8: ldr     x0, [x20]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d6fdec: bl      #0x3769600                                 fn_3769600
02d6fdf0: cbz     x0, #0x2d6ff00                             
02d6fdf4: adrp    x21, #0x6266000                            
02d6fdf8: ldr     x21, [x21, #0x750]                         MS:DataManager::GetData
02d6fdfc: ldr     x1, [x21]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d6fe00: bl      #0x3168dd0                                 fn_3168dd0
02d6fe04: cbz     x0, #0x2d6ff00                             
02d6fe08: ldr     x8, [x0, #0x20]                            M:Clicker.GlowSprite2DItem::<DoGlow>b__10_6
02d6fe0c: cbz     x8, #0x2d6ff00                             
02d6fe10: ldrb    w8, [x8, #0x3a]                            
02d6fe14: cbz     w8, #0x2d6fe4c                             
02d6fe18: adrp    x22, #0x6265000                            
02d6fe1c: ldr     x22, [x22, #0xb38]                         T:DevTrack
02d6fe20: ldr     x0, [x22]                                  M:AdsManager::<OnApplicationPause>b__26_0
02d6fe24: ldr     w8, [x0, #0xe4]                            [626c0e4]=0 f=0,0
02d6fe28: cbnz    w8, #0x2d6fe34                             
02d6fe2c: bl      #0x2b70f30                                 fn_2b70f30
02d6fe30: ldr     x0, [x22]                                  M:AdsManager::<OnApplicationPause>b__26_0
02d6fe34: ldr     x8, [x0, #0xb8]                            MS:System.Collections.Generic.List`1::Add
02d6fe38: mov     x3, xzr                                    
02d6fe3c: ldr     x0, [x8, #0x1f8]                           
02d6fe40: ldr     x1, [x8, #0x258]                           
02d6fe44: ldr     w2, [x8, #0x290]                           
02d6fe48: bl      #0x2c9c1e0                                 DevTrack::OnboardingStep
02d6fe4c: ldr     x0, [x20]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d6fe50: bl      #0x3769600                                 fn_3769600
02d6fe54: cbz     x0, #0x2d6ff00                             
02d6fe58: ldr     x1, [x21]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d6fe5c: bl      #0x3168dd0                                 fn_3168dd0
02d6fe60: cbz     x0, #0x2d6ff00                             
02d6fe64: ldr     x8, [x0, #0x20]                            M:Clicker.GlowSprite2DItem::<DoGlow>b__10_6
02d6fe68: cbz     x8, #0x2d6ff00                             
02d6fe6c: ldr     w8, [x8, #0x3c]                            
02d6fe70: cmp     w8, #4                                     
02d6fe74: b.ge    #0x2d6fe8c                                 
02d6fe78: mov     x0, x19                                    
02d6fe7c: ldp     x20, x19, [sp, #0x20]                      
02d6fe80: ldp     x22, x21, [sp, #0x10]                      
02d6fe84: ldr     x30, [sp], #0x30                           
02d6fe88: b       #0x2d6ffa8                                 Clicker.PopupDoneAssemble::<OnInit>g__ContinueToLivestream|2_1
02d6fe8c: adrp    x8, #0x6265000                             
02d6fe90: ldr     x8, [x8, #0x310]                           MS:WejoyService.Singleton`1::get_Instance
02d6fe94: ldr     x0, [x8]                                   M:AdsManager::<OnApplicationPause>b__26_0
02d6fe98: bl      #0x3be7218                                 fn_3be7218
02d6fe9c: adrp    x8, #0x6264000                             
02d6fea0: mov     x20, x0                                    
02d6fea4: ldr     x8, [x8, #0xf90]                           T:System.Action
02d6fea8: ldr     x8, [x8]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d6feac: mov     x0, x8                                     
02d6feb0: bl      #0x2b7104c                                 fn_2b7104c
02d6feb4: adrp    x8, #0x626c000                             
02d6feb8: mov     x1, x19                                    
02d6febc: mov     x3, xzr                                    
02d6fec0: ldr     x8, [x8, #0x528]                           M:Clicker.PopupDoneAssemble::<OnInit>g__ContinueToLivestream|2_1
02d6fec4: mov     x21, x0                                    
02d6fec8: ldr     x2, [x8]                                   M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d6fecc: bl      #0x4d8ddbc                                 System.Action::.ctor
02d6fed0: cbz     x20, #0x2d6ff00                            
02d6fed4: adrp    x8, #0x626c000                             
02d6fed8: mov     x0, x20                                    
02d6fedc: mov     x2, x21                                    
02d6fee0: ldr     x8, [x8, #0x530]                           S:'countinue'
02d6fee4: ldp     x20, x19, [sp, #0x20]                      
02d6fee8: ldp     x22, x21, [sp, #0x10]                      
02d6feec: mov     w3, #1                                     
02d6fef0: ldr     x1, [x8]                                   M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d6fef4: mov     x4, xzr                                    
02d6fef8: ldr     x30, [sp], #0x30                           
02d6fefc: b       #0x2c89698                                 AdsManager::ShowInter
02d6ff00: bl      #0x2b7105c                                 fn_2b7105c
## <OnInit>g__ContinueToLivestream|2_1() -> void
---- Clicker.PopupDoneAssemble::<OnInit>g__ContinueToLivestream|2_1 0x2d6ffa8
02d6ffa8: stp     x30, x23, [sp, #-0x30]!                    
02d6ffac: stp     x22, x21, [sp, #0x10]                      
02d6ffb0: stp     x20, x19, [sp, #0x20]                      
02d6ffb4: adrp    x22, #0x6630000                            
02d6ffb8: adrp    x23, #0x6265000                            
02d6ffbc: adrp    x20, #0x6264000                            
02d6ffc0: adrp    x21, #0x626c000                            
02d6ffc4: ldr     x23, [x23, #0x310]                         MS:WejoyService.Singleton`1::get_Instance
02d6ffc8: ldrb    w8, [x22, #0x39a]                          
02d6ffcc: ldr     x20, [x20, #0xf90]                         T:System.Action
02d6ffd0: ldr     x21, [x21, #0x538]                         M:Clicker.PopupDoneAssemble::<OnInit>b__2_2
02d6ffd4: mov     x19, x0                                    
02d6ffd8: tbnz    w8, #0, #0x2d70014                         
02d6ffdc: adrp    x0, #0x6264000                             
02d6ffe0: ldr     x0, [x0, #0xf90]                           T:System.Action
02d6ffe4: bl      #0x2b70db0                                 fn_2b70db0
02d6ffe8: adrp    x0, #0x626c000                             
02d6ffec: ldr     x0, [x0, #0x538]                           M:Clicker.PopupDoneAssemble::<OnInit>b__2_2
02d6fff0: bl      #0x2b70db0                                 fn_2b70db0
02d6fff4: adrp    x0, #0x6265000                             
02d6fff8: ldr     x0, [x0, #0x310]                           MS:WejoyService.Singleton`1::get_Instance
02d6fffc: bl      #0x2b70db0                                 fn_2b70db0
02d70000: adrp    x0, #0x626c000                             
02d70004: ldr     x0, [x0, #0x530]                           S:'countinue'
02d70008: bl      #0x2b70db0                                 fn_2b70db0
02d7000c: mov     w8, #1                                     
02d70010: strb    w8, [x22, #0x39a]                          
02d70014: ldr     x0, [x23]                                  M:AdsManager::<OnApplicationPause>b__26_0
02d70018: bl      #0x3be7218                                 fn_3be7218
02d7001c: ldr     x8, [x20]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d70020: mov     x20, x0                                    
02d70024: mov     x0, x8                                     
02d70028: bl      #0x2b7104c                                 fn_2b7104c
02d7002c: ldr     x2, [x21]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d70030: mov     x1, x19                                    
02d70034: mov     x3, xzr                                    
02d70038: mov     x21, x0                                    
02d7003c: bl      #0x4d8ddbc                                 System.Action::.ctor
02d70040: cbz     x20, #0x2d70070                            
02d70044: adrp    x8, #0x626c000                             
02d70048: mov     x0, x20                                    
02d7004c: mov     x2, x21                                    
02d70050: ldr     x8, [x8, #0x530]                           S:'countinue'
02d70054: ldp     x20, x19, [sp, #0x20]                      
02d70058: ldp     x22, x21, [sp, #0x10]                      
02d7005c: mov     w3, #1                                     
02d70060: ldr     x1, [x8]                                   M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d70064: mov     x4, xzr                                    
02d70068: ldp     x30, x23, [sp], #0x30                      
02d7006c: b       #0x2c89698                                 AdsManager::ShowInter
02d70070: bl      #0x2b7105c                                 fn_2b7105c
## <OnInit>b__2_2() -> void
---- Clicker.PopupDoneAssemble::<OnInit>b__2_2 0x2d70074
02d70074: stp     x30, x21, [sp, #-0x20]!                    
02d70078: stp     x20, x19, [sp, #0x10]                      
02d7007c: adrp    x21, #0x6630000                            
02d70080: adrp    x20, #0x626b000                            
02d70084: mov     x19, x0                                    
02d70088: ldrb    w8, [x21, #0x39b]                          
02d7008c: ldr     x20, [x20, #0xee0]                         MS:MonoSingleton`1::get_Instance
02d70090: tbnz    w8, #0, #0x2d700cc                         
02d70094: adrp    x0, #0x6267000                             
02d70098: ldr     x0, [x0, #0xbd0]                           MS:MonoSingleton`1::get_Instance
02d7009c: bl      #0x2b70db0                                 fn_2b70db0
02d700a0: adrp    x0, #0x626b000                             
02d700a4: ldr     x0, [x0, #0xee0]                           MS:MonoSingleton`1::get_Instance
02d700a8: bl      #0x2b70db0                                 fn_2b70db0
02d700ac: adrp    x0, #0x6265000                             
02d700b0: ldr     x0, [x0, #0x310]                           MS:WejoyService.Singleton`1::get_Instance
02d700b4: bl      #0x2b70db0                                 fn_2b70db0
02d700b8: adrp    x0, #0x626c000                             
02d700bc: ldr     x0, [x0, #0x540]                           MS:UIManager::ShowScreen
02d700c0: bl      #0x2b70db0                                 fn_2b70db0
02d700c4: mov     w8, #1                                     
02d700c8: strb    w8, [x21, #0x39b]                          
02d700cc: ldr     x8, [x19]                                  
02d700d0: mov     x0, x19                                    
02d700d4: ldp     x9, x1, [x8, #0x198]                       
02d700d8: blr     x9                                         
02d700dc: ldr     x0, [x20]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d700e0: bl      #0x3769600                                 fn_3769600
02d700e4: cbz     x0, #0x2d70138                             
02d700e8: adrp    x19, #0x6267000                            
02d700ec: mov     x1, xzr                                    
02d700f0: ldr     x19, [x19, #0xbd0]                         MS:MonoSingleton`1::get_Instance
02d700f4: bl      #0x2d6d3e8                                 Clicker.KeycapMakerController::MoveResultToCenter
02d700f8: ldr     x0, [x19]                                  S:'didu'
02d700fc: bl      #0x3769600                                 fn_3769600
02d70100: cbz     x0, #0x2d70138                             
02d70104: adrp    x8, #0x626c000                             
02d70108: adrp    x19, #0x6265000                            
02d7010c: ldr     x8, [x8, #0x540]                           MS:UIManager::ShowScreen
02d70110: ldr     x19, [x19, #0x310]                         MS:WejoyService.Singleton`1::get_Instance
02d70114: ldr     x1, [x8]                                   M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d70118: bl      #0x33fc0e8                                 fn_33fc0e8
02d7011c: ldr     x0, [x19]                                  M:AdsManager::<OnApplicationPause>b__26_0
02d70120: bl      #0x3be7218                                 fn_3be7218
02d70124: cbz     x0, #0x2d70138                             
02d70128: ldp     x20, x19, [sp, #0x10]                      
02d7012c: mov     x1, xzr                                    
02d70130: ldp     x30, x21, [sp], #0x20                      
02d70134: b       #0x2c8a7a4                                 AdsManager::ShowCollap
02d70138: bl      #0x2b7105c                                 fn_2b7105c
