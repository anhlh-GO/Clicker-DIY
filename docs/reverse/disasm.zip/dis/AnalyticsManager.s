#### CLASS AnalyticsManager parent= WejoyService.Singleton`1<AnalyticsManager>
## LogAdsEvent(string eventName, string placement, string error) -> void
---- AnalyticsManager::LogAdsEvent 0x2c8b88c
02c8b88c: stp     x30, x25, [sp, #-0x40]!                    
02c8b890: stp     x24, x23, [sp, #0x10]                      
02c8b894: stp     x22, x21, [sp, #0x20]                      
02c8b898: stp     x20, x19, [sp, #0x30]                      
02c8b89c: adrp    x23, #0x662f000                            
02c8b8a0: adrp    x22, #0x6265000                            
02c8b8a4: mov     x21, x2                                    
02c8b8a8: ldrb    w8, [x23, #0xa4b]                          
02c8b8ac: ldr     x22, [x22, #0x1f0]                         T:type24519(k1d)
02c8b8b0: mov     x20, x1                                    
02c8b8b4: mov     x19, x0                                    
02c8b8b8: tbnz    w8, #0, #0x2c8b900                         
02c8b8bc: adrp    x0, #0x6265000                             
02c8b8c0: ldr     x0, [x0, #0x1f8]                           T:Firebase.Analytics.FirebaseAnalytics
02c8b8c4: bl      #0x2b70db0                                 fn_2b70db0
02c8b8c8: adrp    x0, #0x6265000                             
02c8b8cc: ldr     x0, [x0, #0x1f0]                           T:type24519(k1d)
02c8b8d0: bl      #0x2b70db0                                 fn_2b70db0
02c8b8d4: adrp    x0, #0x6265000                             
02c8b8d8: ldr     x0, [x0, #0x200]                           T:Firebase.Analytics.Parameter
02c8b8dc: bl      #0x2b70db0                                 fn_2b70db0
02c8b8e0: adrp    x0, #0x6265000                             
02c8b8e4: ldr     x0, [x0, #0x208]                           S:'placement'
02c8b8e8: bl      #0x2b70db0                                 fn_2b70db0
02c8b8ec: adrp    x0, #0x6263000                             
02c8b8f0: ldr     x0, [x0, #0xb38]                           S:'error'
02c8b8f4: bl      #0x2b70db0                                 fn_2b70db0
02c8b8f8: mov     w8, #1                                     
02c8b8fc: strb    w8, [x23, #0xa4b]                          
02c8b900: adrp    x24, #0x6265000                            
02c8b904: adrp    x25, #0x6265000                            
02c8b908: adrp    x23, #0x6265000                            
02c8b90c: ldr     x24, [x24, #0x200]                         T:Firebase.Analytics.Parameter
02c8b910: ldr     x25, [x25, #0x208]                         S:'placement'
02c8b914: ldr     x23, [x23, #0x1f8]                         T:Firebase.Analytics.FirebaseAnalytics
02c8b918: ldr     x0, [x22]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c8b91c: cbz     x21, #0x2c8b9a0                            
02c8b920: mov     w1, #1                                     
02c8b924: bl      #0x2b70ea0                                 fn_2b70ea0
02c8b928: mov     x21, x0                                    
02c8b92c: ldr     x0, [x24]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c8b930: bl      #0x2b7104c                                 fn_2b7104c
02c8b934: ldr     x1, [x25]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c8b938: mov     x22, x0                                    
02c8b93c: mov     x2, x20                                    
02c8b940: mov     x3, xzr                                    
02c8b944: bl      #0x2e07b48                                 Firebase.Analytics.Parameter::.ctor
02c8b948: cbz     x21, #0x2c8ba88                            
02c8b94c: cbz     x22, #0x2c8b964                            
02c8b950: ldr     x8, [x21]                                  
02c8b954: ldr     x1, [x8, #0x40]                            
02c8b958: mov     x0, x22                                    
02c8b95c: bl      #0x2b70f34                                 fn_2b70f34
02c8b960: cbz     x0, #0x2c8ba90                             
02c8b964: ldr     w8, [x21, #0x18]                           
02c8b968: cbz     w8, #0x2c8ba8c                             
02c8b96c: mov     x0, x21                                    
02c8b970: str     x22, [x0, #0x20]!                          
02c8b974: mov     x1, x22                                    
02c8b978: bl      #0x2b70d54                                 fn_2b70d54
02c8b97c: ldr     x0, [x23]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c8b980: ldr     w8, [x0, #0xe4]                            [62630e4]=0 f=0,0
02c8b984: cbnz    w8, #0x2c8b98c                             
02c8b988: bl      #0x2b70f30                                 fn_2b70f30
02c8b98c: mov     x0, x19                                    
02c8b990: mov     x1, x21                                    
02c8b994: mov     x2, xzr                                    
02c8b998: bl      #0x2e052d8                                 Firebase.Analytics.FirebaseAnalytics::LogEvent
02c8b99c: b       #0x2c8ba74                                 
02c8b9a0: mov     w1, #2                                     
02c8b9a4: bl      #0x2b70ea0                                 fn_2b70ea0
02c8b9a8: mov     x21, x0                                    
02c8b9ac: ldr     x0, [x24]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c8b9b0: bl      #0x2b7104c                                 fn_2b7104c
02c8b9b4: ldr     x1, [x25]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c8b9b8: mov     x22, x0                                    
02c8b9bc: mov     x2, x20                                    
02c8b9c0: mov     x3, xzr                                    
02c8b9c4: bl      #0x2e07b48                                 Firebase.Analytics.Parameter::.ctor
02c8b9c8: cbz     x21, #0x2c8ba9c                            
02c8b9cc: cbz     x22, #0x2c8b9e4                            
02c8b9d0: ldr     x8, [x21]                                  
02c8b9d4: ldr     x1, [x8, #0x40]                            
02c8b9d8: mov     x0, x22                                    
02c8b9dc: bl      #0x2b70f34                                 fn_2b70f34
02c8b9e0: cbz     x0, #0x2c8baa8                             
02c8b9e4: ldr     w8, [x21, #0x18]                           
02c8b9e8: cbz     w8, #0x2c8baa0                             
02c8b9ec: mov     x0, x21                                    
02c8b9f0: str     x22, [x0, #0x20]!                          
02c8b9f4: mov     x1, x22                                    
02c8b9f8: bl      #0x2b70d54                                 fn_2b70d54
02c8b9fc: ldr     x0, [x24]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c8ba00: bl      #0x2b7104c                                 fn_2b7104c
02c8ba04: adrp    x8, #0x6263000                             
02c8ba08: mov     x22, x0                                    
02c8ba0c: ldr     x8, [x8, #0xb38]                           S:'error'
02c8ba10: ldr     x1, [x8]                                   &2c5bbd4(=a9bd7bfdd503233f)
02c8ba14: mov     x2, x20                                    
02c8ba18: mov     x3, xzr                                    
02c8ba1c: bl      #0x2e07b48                                 Firebase.Analytics.Parameter::.ctor
02c8ba20: cbz     x22, #0x2c8ba38                            
02c8ba24: ldr     x8, [x21]                                  
02c8ba28: ldr     x1, [x8, #0x40]                            [6263040]=0 f=0,0
02c8ba2c: mov     x0, x22                                    
02c8ba30: bl      #0x2b70f34                                 fn_2b70f34
02c8ba34: cbz     x0, #0x2c8bab4                             
02c8ba38: ldr     w8, [x21, #0x18]                           
02c8ba3c: tst     w8, #0xfffffffe                            
02c8ba40: b.eq    #0x2c8baa4                                 
02c8ba44: mov     x0, x21                                    
02c8ba48: str     x22, [x0, #0x28]!                          
02c8ba4c: mov     x1, x22                                    
02c8ba50: bl      #0x2b70d54                                 fn_2b70d54
02c8ba54: ldr     x0, [x23]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c8ba58: ldr     w8, [x0, #0xe4]                            [62630e4]=0 f=0,0
02c8ba5c: cbnz    w8, #0x2c8ba64                             
02c8ba60: bl      #0x2b70f30                                 fn_2b70f30
02c8ba64: mov     x0, x19                                    
02c8ba68: mov     x1, x21                                    
02c8ba6c: mov     x2, xzr                                    
02c8ba70: bl      #0x2e052d8                                 Firebase.Analytics.FirebaseAnalytics::LogEvent
02c8ba74: ldp     x20, x19, [sp, #0x30]                      
02c8ba78: ldp     x22, x21, [sp, #0x20]                      
02c8ba7c: ldp     x24, x23, [sp, #0x10]                      
02c8ba80: ldp     x30, x25, [sp], #0x40                      
02c8ba84: ret                                                
02c8ba88: bl      #0x2b7105c                                 fn_2b7105c
02c8ba8c: bl      #0x2b71064                                 fn_2b71064
02c8ba90: bl      #0x2b71080                                 fn_2b71080
02c8ba94: mov     x1, xzr                                    
02c8ba98: bl      #0x2b70f20                                 fn_2b70f20
02c8ba9c: bl      #0x2b7105c                                 fn_2b7105c
02c8baa0: bl      #0x2b71064                                 fn_2b71064
02c8baa4: bl      #0x2b71064                                 fn_2b71064
02c8baa8: bl      #0x2b71080                                 fn_2b71080
02c8baac: mov     x1, xzr                                    
02c8bab0: bl      #0x2b70f20                                 fn_2b70f20
02c8bab4: bl      #0x2b71080                                 fn_2b71080
02c8bab8: mov     x1, xzr                                    
02c8babc: bl      #0x2b70f20                                 fn_2b70f20
02c8bac0: b       #0x2c8bad0                                 
02c8bac4: b       #0x2c8bad0                                 
02c8bac8: b       #0x2c8bad0                                 
02c8bacc: b       #0x2c8bad0                                 
02c8bad0: mov     x19, x0                                    
02c8bad4: cmp     w1, #1                                     
02c8bad8: b.ne    #0x2c8bb68                                 
02c8badc: mov     x0, x19                                    
02c8bae0: bl      #0x5e90260                                 fn_5e90260
02c8bae4: mov     x19, x0                                    
02c8bae8: adrp    x0, #0x6263000                             
02c8baec: ldr     x0, [x0, #0xae0]                           T:System.Exception
02c8baf0: bl      #0x2b70dc4                                 fn_2b70dc4
02c8baf4: ldr     x8, [x19]                                  
02c8baf8: ldr     x1, [x8]                                   &2c5bbd4(=a9bd7bfdd503233f)
02c8bafc: bl      #0x2b71464                                 fn_2b71464
02c8bb00: tbz     w0, #0, #0x2c8bb40                         
02c8bb04: ldr     x19, [x19]                                 
02c8bb08: bl      #0x5e90270                                 fn_5e90270
02c8bb0c: adrp    x0, #0x6263000                             
02c8bb10: ldr     x0, [x0, #0x928]                           T:UnityEngine.Debug
02c8bb14: bl      #0x2b70dc4                                 fn_2b70dc4
02c8bb18: ldr     w8, [x0, #0xe4]                            [62630e4]=0 f=0,0
02c8bb1c: cbnz    w8, #0x2c8bb24                             
02c8bb20: bl      #0x2b70f30                                 fn_2b70f30
02c8bb24: mov     x0, x19                                    
02c8bb28: ldp     x20, x19, [sp, #0x30]                      
02c8bb2c: ldp     x22, x21, [sp, #0x20]                      
02c8bb30: mov     x1, xzr                                    
02c8bb34: ldp     x24, x23, [sp, #0x10]                      
02c8bb38: ldp     x30, x25, [sp], #0x40                      
02c8bb3c: b       #0x5af2840                                 UnityEngine.Debug::LogError
02c8bb40: mov     w0, #8                                     
02c8bb44: bl      #0x5e90290                                 fn_5e90290
02c8bb48: ldr     x8, [x19]                                  
02c8bb4c: str     x8, [x0]                                   
02c8bb50: adrp    x1, #0x5e96000                             
02c8bb54: add     x1, x1, #0x758                             &5e96758
02c8bb58: mov     x2, xzr                                    
02c8bb5c: bl      #0x5e902a0                                 fn_5e902a0
02c8bb60: mov     x19, x0                                    
02c8bb64: bl      #0x5e90270                                 fn_5e90270
02c8bb68: mov     x0, x19                                    
02c8bb6c: bl      #0x2c6051c                                 fn_2c6051c
02c8bb70: bl      #0x27369b8                                 fn_27369b8
## LogFirebaseApplovinRevenue(MaxSdkBase/AdInfo adInfo) -> void
---- AnalyticsManager::LogFirebaseApplovinRevenue 0x2c8c124
02c8c124: str     d8, [sp, #-0x40]!                          
02c8c128: stp     x30, x23, [sp, #0x10]                      
02c8c12c: stp     x22, x21, [sp, #0x20]                      
02c8c130: stp     x20, x19, [sp, #0x30]                      
02c8c134: adrp    x19, #0x662f000                            
02c8c138: mov     x20, x0                                    
02c8c13c: ldrb    w8, [x19, #0xa4c]                          
02c8c140: tbnz    w8, #0, #0x2c8c1e8                         
02c8c144: adrp    x0, #0x6265000                             
02c8c148: ldr     x0, [x0, #0x1f8]                           T:Firebase.Analytics.FirebaseAnalytics
02c8c14c: bl      #0x2b70db0                                 fn_2b70db0
02c8c150: adrp    x0, #0x6265000                             
02c8c154: ldr     x0, [x0, #0x1f0]                           T:type24519(k1d)
02c8c158: bl      #0x2b70db0                                 fn_2b70db0
02c8c15c: adrp    x0, #0x6265000                             
02c8c160: ldr     x0, [x0, #0x200]                           T:Firebase.Analytics.Parameter
02c8c164: bl      #0x2b70db0                                 fn_2b70db0
02c8c168: adrp    x0, #0x6265000                             
02c8c16c: ldr     x0, [x0, #0x280]                           S:'ad_unit_name'
02c8c170: bl      #0x2b70db0                                 fn_2b70db0
02c8c174: adrp    x0, #0x6265000                             
02c8c178: ldr     x0, [x0, #0x288]                           S:'ad_format'
02c8c17c: bl      #0x2b70db0                                 fn_2b70db0
02c8c180: adrp    x0, #0x6265000                             
02c8c184: ldr     x0, [x0, #0x290]                           S:'AppLovin'
02c8c188: bl      #0x2b70db0                                 fn_2b70db0
02c8c18c: adrp    x0, #0x6265000                             
02c8c190: ldr     x0, [x0, #0x298]                           S:'ad_impression_abi'
02c8c194: bl      #0x2b70db0                                 fn_2b70db0
02c8c198: adrp    x0, #0x6265000                             
02c8c19c: ldr     x0, [x0, #0x2a0]                           S:'value'
02c8c1a0: bl      #0x2b70db0                                 fn_2b70db0
02c8c1a4: adrp    x0, #0x6265000                             
02c8c1a8: ldr     x0, [x0, #0x2a8]                           S:'ad_source'
02c8c1ac: bl      #0x2b70db0                                 fn_2b70db0
02c8c1b0: adrp    x0, #0x6265000                             
02c8c1b4: ldr     x0, [x0, #0x2b0]                           S:'currency'
02c8c1b8: bl      #0x2b70db0                                 fn_2b70db0
02c8c1bc: adrp    x0, #0x6265000                             
02c8c1c0: ldr     x0, [x0, #0x2b8]                           S:'USD'
02c8c1c4: bl      #0x2b70db0                                 fn_2b70db0
02c8c1c8: adrp    x0, #0x6265000                             
02c8c1cc: ldr     x0, [x0, #0x2c0]                           S:'ad_impression'
02c8c1d0: bl      #0x2b70db0                                 fn_2b70db0
02c8c1d4: adrp    x0, #0x6265000                             
02c8c1d8: ldr     x0, [x0, #0x2c8]                           S:'ad_platform'
02c8c1dc: bl      #0x2b70db0                                 fn_2b70db0
02c8c1e0: mov     w8, #1                                     
02c8c1e4: strb    w8, [x19, #0xa4c]                          
02c8c1e8: cbz     x20, #0x2c8c498                            
02c8c1ec: adrp    x8, #0x6265000                             
02c8c1f0: ldr     x8, [x8, #0x1f0]                           T:type24519(k1d)
02c8c1f4: ldr     d8, [x20, #0x40]                           
02c8c1f8: ldr     x0, [x8]                                   M:AdsManager::<OnApplicationPause>b__26_0
02c8c1fc: mov     w1, #6                                     
02c8c200: bl      #0x2b70ea0                                 fn_2b70ea0
02c8c204: adrp    x23, #0x6265000                            
02c8c208: mov     x19, x0                                    
02c8c20c: ldr     x23, [x23, #0x200]                         T:Firebase.Analytics.Parameter
02c8c210: ldr     x0, [x23]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c8c214: bl      #0x2b7104c                                 fn_2b7104c
02c8c218: adrp    x8, #0x6265000                             
02c8c21c: adrp    x9, #0x6265000                             
02c8c220: mov     x21, x0                                    
02c8c224: ldr     x8, [x8, #0x2c8]                           S:'ad_platform'
02c8c228: ldr     x9, [x9, #0x290]                           S:'AppLovin'
02c8c22c: ldr     x1, [x8]                                   M:AdsManager::<OnApplicationPause>b__26_0
02c8c230: ldr     x2, [x9]                                   M:AdsManager::<OnApplicationPause>b__26_0
02c8c234: mov     x3, xzr                                    
02c8c238: bl      #0x2e07b48                                 Firebase.Analytics.Parameter::.ctor
02c8c23c: cbz     x19, #0x2c8c49c                            
02c8c240: cbz     x21, #0x2c8c258                            
02c8c244: ldr     x8, [x19]                                  &2b706c4(=eb01011ff9400808)
02c8c248: ldr     x1, [x8, #0x40]                            S:'done_ad'
02c8c24c: mov     x0, x21                                    
02c8c250: bl      #0x2b70f34                                 fn_2b70f34
02c8c254: cbz     x0, #0x2c8c4b8                             
02c8c258: ldr     w8, [x19, #0x18]                           [662f018]=6000014 f=2.40742e-35,0
02c8c25c: cbz     w8, #0x2c8c4a0                             
02c8c260: mov     x0, x19                                    
02c8c264: str     x21, [x0, #0x20]!                          
02c8c268: mov     x1, x21                                    
02c8c26c: bl      #0x2b70d54                                 fn_2b70d54
02c8c270: ldr     x22, [x20, #0x20]                          
02c8c274: ldr     x0, [x23]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c8c278: bl      #0x2b7104c                                 fn_2b7104c
02c8c27c: adrp    x8, #0x6265000                             
02c8c280: mov     x21, x0                                    
02c8c284: ldr     x8, [x8, #0x2a8]                           S:'ad_source'
02c8c288: ldr     x1, [x8]                                   M:AdsManager::<OnApplicationPause>b__26_0
02c8c28c: mov     x2, x22                                    
02c8c290: mov     x3, xzr                                    
02c8c294: bl      #0x2e07b48                                 Firebase.Analytics.Parameter::.ctor
02c8c298: cbz     x21, #0x2c8c2b0                            
02c8c29c: ldr     x8, [x19]                                  &2b706c4(=eb01011ff9400808)
02c8c2a0: ldr     x1, [x8, #0x40]                            S:'done_ad'
02c8c2a4: mov     x0, x21                                    
02c8c2a8: bl      #0x2b70f34                                 fn_2b70f34
02c8c2ac: cbz     x0, #0x2c8c4c4                             
02c8c2b0: ldr     w8, [x19, #0x18]                           [662f018]=6000014 f=2.40742e-35,0
02c8c2b4: tst     w8, #0xfffffffe                            
02c8c2b8: b.eq    #0x2c8c4a4                                 
02c8c2bc: mov     x0, x19                                    
02c8c2c0: str     x21, [x0, #0x28]!                          
02c8c2c4: mov     x1, x21                                    
02c8c2c8: bl      #0x2b70d54                                 fn_2b70d54
02c8c2cc: ldr     x22, [x20, #0x10]                          
02c8c2d0: ldr     x0, [x23]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c8c2d4: bl      #0x2b7104c                                 fn_2b7104c
02c8c2d8: adrp    x8, #0x6265000                             
02c8c2dc: mov     x21, x0                                    
02c8c2e0: ldr     x8, [x8, #0x280]                           S:'ad_unit_name'
02c8c2e4: ldr     x1, [x8]                                   M:AdsManager::<OnApplicationPause>b__26_0
02c8c2e8: mov     x2, x22                                    
02c8c2ec: mov     x3, xzr                                    
02c8c2f0: bl      #0x2e07b48                                 Firebase.Analytics.Parameter::.ctor
02c8c2f4: cbz     x21, #0x2c8c30c                            
02c8c2f8: ldr     x8, [x19]                                  &2b706c4(=eb01011ff9400808)
02c8c2fc: ldr     x1, [x8, #0x40]                            S:'done_ad'
02c8c300: mov     x0, x21                                    
02c8c304: bl      #0x2b70f34                                 fn_2b70f34
02c8c308: cbz     x0, #0x2c8c4d0                             
02c8c30c: ldr     w8, [x19, #0x18]                           [662f018]=6000014 f=2.40742e-35,0
02c8c310: cmp     w8, #2                                     
02c8c314: b.ls    #0x2c8c4a8                                 
02c8c318: mov     x0, x19                                    
02c8c31c: str     x21, [x0, #0x30]!                          
02c8c320: mov     x1, x21                                    
02c8c324: bl      #0x2b70d54                                 fn_2b70d54
02c8c328: ldr     x21, [x20, #0x18]                          
02c8c32c: ldr     x0, [x23]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c8c330: bl      #0x2b7104c                                 fn_2b7104c
02c8c334: adrp    x8, #0x6265000                             
02c8c338: mov     x20, x0                                    
02c8c33c: ldr     x8, [x8, #0x288]                           S:'ad_format'
02c8c340: ldr     x1, [x8]                                   M:AdsManager::<OnApplicationPause>b__26_0
02c8c344: mov     x2, x21                                    
02c8c348: mov     x3, xzr                                    
02c8c34c: bl      #0x2e07b48                                 Firebase.Analytics.Parameter::.ctor
02c8c350: cbz     x20, #0x2c8c368                            
02c8c354: ldr     x8, [x19]                                  &2b706c4(=eb01011ff9400808)
02c8c358: ldr     x1, [x8, #0x40]                            S:'done_ad'
02c8c35c: mov     x0, x20                                    
02c8c360: bl      #0x2b70f34                                 fn_2b70f34
02c8c364: cbz     x0, #0x2c8c4dc                             
02c8c368: ldr     w8, [x19, #0x18]                           [662f018]=6000014 f=2.40742e-35,0
02c8c36c: tst     w8, #0xfffffffc                            
02c8c370: b.eq    #0x2c8c4ac                                 
02c8c374: mov     x0, x19                                    
02c8c378: str     x20, [x0, #0x38]!                          
02c8c37c: mov     x1, x20                                    
02c8c380: bl      #0x2b70d54                                 fn_2b70d54
02c8c384: ldr     x0, [x23]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c8c388: bl      #0x2b7104c                                 fn_2b7104c
02c8c38c: adrp    x8, #0x6265000                             
02c8c390: mov     x20, x0                                    
02c8c394: ldr     x8, [x8, #0x2a0]                           S:'value'
02c8c398: ldr     x1, [x8]                                   M:AdsManager::<OnApplicationPause>b__26_0
02c8c39c: fmov    d0, d8                                     
02c8c3a0: mov     x2, xzr                                    
02c8c3a4: bl      #0x2e07bf4                                 Firebase.Analytics.Parameter::.ctor
02c8c3a8: cbz     x20, #0x2c8c3c0                            
02c8c3ac: ldr     x8, [x19]                                  &2b706c4(=eb01011ff9400808)
02c8c3b0: ldr     x1, [x8, #0x40]                            S:'done_ad'
02c8c3b4: mov     x0, x20                                    
02c8c3b8: bl      #0x2b70f34                                 fn_2b70f34
02c8c3bc: cbz     x0, #0x2c8c4e8                             
02c8c3c0: ldr     w8, [x19, #0x18]                           [662f018]=6000014 f=2.40742e-35,0
02c8c3c4: cmp     w8, #4                                     
02c8c3c8: b.ls    #0x2c8c4b0                                 
02c8c3cc: mov     x0, x19                                    
02c8c3d0: str     x20, [x0, #0x40]!                          
02c8c3d4: mov     x1, x20                                    
02c8c3d8: bl      #0x2b70d54                                 fn_2b70d54
02c8c3dc: ldr     x0, [x23]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c8c3e0: bl      #0x2b7104c                                 fn_2b7104c
02c8c3e4: adrp    x8, #0x6265000                             
02c8c3e8: adrp    x9, #0x6265000                             
02c8c3ec: mov     x20, x0                                    
02c8c3f0: ldr     x8, [x8, #0x2b0]                           S:'currency'
02c8c3f4: ldr     x9, [x9, #0x2b8]                           S:'USD'
02c8c3f8: ldr     x1, [x8]                                   M:AdsManager::<OnApplicationPause>b__26_0
02c8c3fc: ldr     x2, [x9]                                   M:AdsManager::<OnApplicationPause>b__26_0
02c8c400: mov     x3, xzr                                    
02c8c404: bl      #0x2e07b48                                 Firebase.Analytics.Parameter::.ctor
02c8c408: cbz     x20, #0x2c8c420                            
02c8c40c: ldr     x8, [x19]                                  &2b706c4(=eb01011ff9400808)
02c8c410: ldr     x1, [x8, #0x40]                            S:'done_ad'
02c8c414: mov     x0, x20                                    
02c8c418: bl      #0x2b70f34                                 fn_2b70f34
02c8c41c: cbz     x0, #0x2c8c4f4                             
02c8c420: ldr     w8, [x19, #0x18]                           [662f018]=6000014 f=2.40742e-35,0
02c8c424: cmp     w8, #5                                     
02c8c428: b.ls    #0x2c8c4b4                                 
02c8c42c: mov     x0, x19                                    
02c8c430: str     x20, [x0, #0x48]!                          
02c8c434: mov     x1, x20                                    
02c8c438: bl      #0x2b70d54                                 fn_2b70d54
02c8c43c: adrp    x8, #0x6265000                             
02c8c440: ldr     x8, [x8, #0x1f8]                           T:Firebase.Analytics.FirebaseAnalytics
02c8c444: ldr     x0, [x8]                                   M:AdsManager::<OnApplicationPause>b__26_0
02c8c448: ldr     w8, [x0, #0xe4]                            [62650e4]=0 f=0,0
02c8c44c: cbnz    w8, #0x2c8c454                             
02c8c450: bl      #0x2b70f30                                 fn_2b70f30
02c8c454: adrp    x8, #0x6265000                             
02c8c458: ldr     x8, [x8, #0x2c0]                           S:'ad_impression'
02c8c45c: ldr     x0, [x8]                                   M:AdsManager::<OnApplicationPause>b__26_0
02c8c460: mov     x1, x19                                    
02c8c464: mov     x2, xzr                                    
02c8c468: bl      #0x2e052d8                                 Firebase.Analytics.FirebaseAnalytics::LogEvent
02c8c46c: adrp    x8, #0x6265000                             
02c8c470: ldr     x8, [x8, #0x298]                           S:'ad_impression_abi'
02c8c474: ldr     x0, [x8]                                   M:AdsManager::<OnApplicationPause>b__26_0
02c8c478: mov     x1, x19                                    
02c8c47c: mov     x2, xzr                                    
02c8c480: bl      #0x2e052d8                                 Firebase.Analytics.FirebaseAnalytics::LogEvent
02c8c484: ldp     x20, x19, [sp, #0x30]                      
02c8c488: ldp     x22, x21, [sp, #0x20]                      
02c8c48c: ldp     x30, x23, [sp, #0x10]                      
02c8c490: ldr     d8, [sp], #0x40                            
02c8c494: ret                                                
02c8c498: bl      #0x2b7105c                                 fn_2b7105c
02c8c49c: bl      #0x2b7105c                                 fn_2b7105c
02c8c4a0: bl      #0x2b71064                                 fn_2b71064
02c8c4a4: bl      #0x2b71064                                 fn_2b71064
02c8c4a8: bl      #0x2b71064                                 fn_2b71064
02c8c4ac: bl      #0x2b71064                                 fn_2b71064
02c8c4b0: bl      #0x2b71064                                 fn_2b71064
02c8c4b4: bl      #0x2b71064                                 fn_2b71064
02c8c4b8: bl      #0x2b71080                                 fn_2b71080
02c8c4bc: mov     x1, xzr                                    
02c8c4c0: bl      #0x2b70f20                                 fn_2b70f20
02c8c4c4: bl      #0x2b71080                                 fn_2b71080
02c8c4c8: mov     x1, xzr                                    
02c8c4cc: bl      #0x2b70f20                                 fn_2b70f20
02c8c4d0: bl      #0x2b71080                                 fn_2b71080
02c8c4d4: mov     x1, xzr                                    
02c8c4d8: bl      #0x2b70f20                                 fn_2b70f20
02c8c4dc: bl      #0x2b71080                                 fn_2b71080
02c8c4e0: mov     x1, xzr                                    
02c8c4e4: bl      #0x2b70f20                                 fn_2b70f20
02c8c4e8: bl      #0x2b71080                                 fn_2b71080
02c8c4ec: mov     x1, xzr                                    
02c8c4f0: bl      #0x2b70f20                                 fn_2b70f20
02c8c4f4: bl      #0x2b71080                                 fn_2b71080
02c8c4f8: mov     x1, xzr                                    
02c8c4fc: bl      #0x2b70f20                                 fn_2b70f20
02c8c500: b       #0x2c8c524                                 
02c8c504: b       #0x2c8c524                                 
02c8c508: b       #0x2c8c524                                 
02c8c50c: b       #0x2c8c524                                 
02c8c510: b       #0x2c8c524                                 
02c8c514: b       #0x2c8c524                                 
02c8c518: b       #0x2c8c524                                 
02c8c51c: b       #0x2c8c524                                 
02c8c520: b       #0x2c8c524                                 
02c8c524: mov     x19, x0                                    
02c8c528: cmp     w1, #1                                     
02c8c52c: b.ne    #0x2c8c5bc                                 
02c8c530: mov     x0, x19                                    
02c8c534: bl      #0x5e90260                                 fn_5e90260
02c8c538: mov     x19, x0                                    
02c8c53c: adrp    x0, #0x6263000                             
02c8c540: ldr     x0, [x0, #0xae0]                           T:System.Exception
02c8c544: bl      #0x2b70dc4                                 fn_2b70dc4
02c8c548: ldr     x8, [x19]                                  &2b706c4(=eb01011ff9400808)
02c8c54c: ldr     x1, [x8]                                   M:AdsManager::<OnApplicationPause>b__26_0
02c8c550: bl      #0x2b71464                                 fn_2b71464
02c8c554: tbz     w0, #0, #0x2c8c594                         
02c8c558: ldr     x19, [x19]                                 &2b706c4(=eb01011ff9400808)
02c8c55c: bl      #0x5e90270                                 fn_5e90270
02c8c560: adrp    x0, #0x6263000                             
02c8c564: ldr     x0, [x0, #0x928]                           T:UnityEngine.Debug
02c8c568: bl      #0x2b70dc4                                 fn_2b70dc4
02c8c56c: ldr     w8, [x0, #0xe4]                            [62630e4]=0 f=0,0
02c8c570: cbnz    w8, #0x2c8c578                             
02c8c574: bl      #0x2b70f30                                 fn_2b70f30
02c8c578: mov     x0, x19                                    
02c8c57c: ldp     x20, x19, [sp, #0x30]                      
02c8c580: ldp     x22, x21, [sp, #0x20]                      
02c8c584: mov     x1, xzr                                    
02c8c588: ldp     x30, x23, [sp, #0x10]                      
02c8c58c: ldr     d8, [sp], #0x40                            
02c8c590: b       #0x5af2840                                 UnityEngine.Debug::LogError
02c8c594: mov     w0, #8                                     
02c8c598: bl      #0x5e90290                                 fn_5e90290
02c8c59c: ldr     x8, [x19]                                  &2b706c4(=eb01011ff9400808)
02c8c5a0: str     x8, [x0]                                   
02c8c5a4: adrp    x1, #0x5e96000                             
02c8c5a8: add     x1, x1, #0x758                             &5e96758
02c8c5ac: mov     x2, xzr                                    
02c8c5b0: bl      #0x5e902a0                                 fn_5e902a0
02c8c5b4: mov     x19, x0                                    
02c8c5b8: bl      #0x5e90270                                 fn_5e90270
02c8c5bc: mov     x0, x19                                    
02c8c5c0: bl      #0x2c6051c                                 fn_2c6051c
02c8c5c4: bl      #0x27369b8                                 fn_27369b8
## GetAdInfo(object adObject) -> GoogleMobileAds.Api.ResponseInfo
---- AnalyticsManager::GetAdInfo 0x2c9bf4c
02c9bf4c: str     x30, [sp, #-0x20]!                         
02c9bf50: stp     x20, x19, [sp, #0x10]                      
02c9bf54: adrp    x20, #0x662f000                            
02c9bf58: mov     x19, x0                                    
02c9bf5c: ldrb    w8, [x20, #0xa4d]                          
02c9bf60: tbnz    w8, #0, #0x2c9bf9c                         
02c9bf64: adrp    x0, #0x6265000                             
02c9bf68: ldr     x0, [x0, #0xb10]                           T:GoogleMobileAds.Api.AppOpenAd
02c9bf6c: bl      #0x2b70db0                                 fn_2b70db0
02c9bf70: adrp    x0, #0x6265000                             
02c9bf74: ldr     x0, [x0, #0xb18]                           T:GoogleMobileAds.Api.InterstitialAd
02c9bf78: bl      #0x2b70db0                                 fn_2b70db0
02c9bf7c: adrp    x0, #0x6265000                             
02c9bf80: ldr     x0, [x0, #0xb20]                           T:GoogleMobileAds.Api.RewardedAd
02c9bf84: bl      #0x2b70db0                                 fn_2b70db0
02c9bf88: adrp    x0, #0x6265000                             
02c9bf8c: ldr     x0, [x0, #0xb28]                           T:GoogleMobileAds.Api.RewardedInterstitialAd
02c9bf90: bl      #0x2b70db0                                 fn_2b70db0
02c9bf94: mov     w8, #1                                     
02c9bf98: strb    w8, [x20, #0xa4d]                          
02c9bf9c: cbz     x19, #0x2c9c058                            
02c9bfa0: adrp    x8, #0x6265000                             
02c9bfa4: ldr     x8, [x8, #0xb10]                           T:GoogleMobileAds.Api.AppOpenAd
02c9bfa8: ldr     x10, [x8]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9bfac: ldr     x8, [x19]                                  
02c9bfb0: ldrb    w9, [x8, #0x130]                           
02c9bfb4: ldrb    w11, [x10, #0x130]                         
02c9bfb8: cmp     w9, w11                                    
02c9bfbc: b.lo    #0x2c9bfd4                                 
02c9bfc0: ldr     x12, [x8, #0xc8]                           M:AdsManager/<>c__DisplayClass42_0::<ShowInterAdmob>b__1
02c9bfc4: add     x11, x12, x11, lsl #3                      
02c9bfc8: ldur    x11, [x11, #-8]                            
02c9bfcc: cmp     x11, x10                                   
02c9bfd0: b.eq    #0x2c9c068                                 
02c9bfd4: adrp    x10, #0x6265000                            
02c9bfd8: ldr     x10, [x10, #0xb18]                         T:GoogleMobileAds.Api.InterstitialAd
02c9bfdc: ldr     x10, [x10]                                 M:AdsManager::<OnApplicationPause>b__26_0
02c9bfe0: ldrb    w11, [x10, #0x130]                         
02c9bfe4: cmp     w9, w11                                    
02c9bfe8: b.lo    #0x2c9c000                                 
02c9bfec: ldr     x12, [x8, #0xc8]                           M:AdsManager/<>c__DisplayClass42_0::<ShowInterAdmob>b__1
02c9bff0: add     x11, x12, x11, lsl #3                      
02c9bff4: ldur    x11, [x11, #-8]                            
02c9bff8: cmp     x11, x10                                   
02c9bffc: b.eq    #0x2c9c07c                                 
02c9c000: adrp    x10, #0x6265000                            
02c9c004: ldr     x10, [x10, #0xb20]                         T:GoogleMobileAds.Api.RewardedAd
02c9c008: ldr     x10, [x10]                                 M:AdsManager::<OnApplicationPause>b__26_0
02c9c00c: ldrb    w11, [x10, #0x130]                         
02c9c010: cmp     w9, w11                                    
02c9c014: b.lo    #0x2c9c02c                                 
02c9c018: ldr     x12, [x8, #0xc8]                           M:AdsManager/<>c__DisplayClass42_0::<ShowInterAdmob>b__1
02c9c01c: add     x11, x12, x11, lsl #3                      
02c9c020: ldur    x11, [x11, #-8]                            
02c9c024: cmp     x11, x10                                   
02c9c028: b.eq    #0x2c9c090                                 
02c9c02c: adrp    x10, #0x6265000                            
02c9c030: ldr     x10, [x10, #0xb28]                         T:GoogleMobileAds.Api.RewardedInterstitialAd
02c9c034: ldr     x10, [x10]                                 M:AdsManager::<OnApplicationPause>b__26_0
02c9c038: ldrb    w11, [x10, #0x130]                         
02c9c03c: cmp     w9, w11                                    
02c9c040: b.lo    #0x2c9c058                                 
02c9c044: ldr     x8, [x8, #0xc8]                            M:AdsManager/<>c__DisplayClass42_0::<ShowInterAdmob>b__1
02c9c048: add     x8, x8, x11, lsl #3                        &6265000
02c9c04c: ldur    x8, [x8, #-8]                              
02c9c050: cmp     x8, x10                                    
02c9c054: b.eq    #0x2c9c0a4                                 
02c9c058: ldp     x20, x19, [sp, #0x10]                      
02c9c05c: mov     x0, xzr                                    
02c9c060: ldr     x30, [sp], #0x20                           
02c9c064: ret                                                
02c9c068: mov     x0, x19                                    
02c9c06c: ldp     x20, x19, [sp, #0x10]                      
02c9c070: mov     x1, xzr                                    
02c9c074: ldr     x30, [sp], #0x20                           
02c9c078: b       #0x4c35a00                                 GoogleMobileAds.Api.AppOpenAd::GetResponseInfo
02c9c07c: mov     x0, x19                                    
02c9c080: ldp     x20, x19, [sp, #0x10]                      
02c9c084: mov     x1, xzr                                    
02c9c088: ldr     x30, [sp], #0x20                           
02c9c08c: b       #0x4c3a74c                                 GoogleMobileAds.Api.InterstitialAd::GetResponseInfo
02c9c090: mov     x0, x19                                    
02c9c094: ldp     x20, x19, [sp, #0x10]                      
02c9c098: mov     x1, xzr                                    
02c9c09c: ldr     x30, [sp], #0x20                           
02c9c0a0: b       #0x4c40f18                                 GoogleMobileAds.Api.RewardedAd::GetResponseInfo
02c9c0a4: mov     x0, x19                                    
02c9c0a8: ldp     x20, x19, [sp, #0x10]                      
02c9c0ac: mov     x1, xzr                                    
02c9c0b0: ldr     x30, [sp], #0x20                           
02c9c0b4: b       #0x4c43ca8                                 GoogleMobileAds.Api.RewardedInterstitialAd::GetResponseInfo
## LogFirebaseAdmobRevenue(AdFormat adFormat, GoogleMobileAds.Api.AdValue adValue, object adObject) -> void
---- AnalyticsManager::LogFirebaseAdmobRevenue 0x2c8ffb4
02c8ffb4: sub     sp, sp, #0x60                              
02c8ffb8: stp     x30, x25, [sp, #0x20]                      
02c8ffbc: stp     x24, x23, [sp, #0x30]                      
02c8ffc0: stp     x22, x21, [sp, #0x40]                      
02c8ffc4: stp     x20, x19, [sp, #0x50]                      
02c8ffc8: adrp    x22, #0x662f000                            
02c8ffcc: mov     x19, x2                                    
02c8ffd0: mov     x20, x1                                    
02c8ffd4: ldrb    w8, [x22, #0xa4e]                          
02c8ffd8: mov     w21, w0                                    
02c8ffdc: tbnz    w8, #0, #0x2c90090                         
02c8ffe0: adrp    x0, #0x6265000                             
02c8ffe4: ldr     x0, [x0, #0x210]                           T:AdFormat
02c8ffe8: bl      #0x2b70db0                                 fn_2b70db0
02c8ffec: adrp    x0, #0x6265000                             
02c8fff0: ldr     x0, [x0, #0x1f8]                           T:Firebase.Analytics.FirebaseAnalytics
02c8fff4: bl      #0x2b70db0                                 fn_2b70db0
02c8fff8: adrp    x0, #0x6265000                             
02c8fffc: ldr     x0, [x0, #0x1f0]                           T:type24519(k1d)
02c90000: bl      #0x2b70db0                                 fn_2b70db0
02c90004: adrp    x0, #0x6265000                             
02c90008: ldr     x0, [x0, #0x200]                           T:Firebase.Analytics.Parameter
02c9000c: bl      #0x2b70db0                                 fn_2b70db0
02c90010: adrp    x0, #0x6264000                             
02c90014: ldr     x0, [x0, #0xd90]                           S:'{0}'
02c90018: bl      #0x2b70db0                                 fn_2b70db0
02c9001c: adrp    x0, #0x6265000                             
02c90020: ldr     x0, [x0, #0x280]                           S:'ad_unit_name'
02c90024: bl      #0x2b70db0                                 fn_2b70db0
02c90028: adrp    x0, #0x6265000                             
02c9002c: ldr     x0, [x0, #0x288]                           S:'ad_format'
02c90030: bl      #0x2b70db0                                 fn_2b70db0
02c90034: adrp    x0, #0x6265000                             
02c90038: ldr     x0, [x0, #0x298]                           S:'ad_impression_abi'
02c9003c: bl      #0x2b70db0                                 fn_2b70db0
02c90040: adrp    x0, #0x6265000                             
02c90044: ldr     x0, [x0, #0x2a0]                           S:'value'
02c90048: bl      #0x2b70db0                                 fn_2b70db0
02c9004c: adrp    x0, #0x6265000                             
02c90050: ldr     x0, [x0, #0x2a8]                           S:'ad_source'
02c90054: bl      #0x2b70db0                                 fn_2b70db0
02c90058: adrp    x0, #0x6265000                             
02c9005c: ldr     x0, [x0, #0x2b0]                           S:'currency'
02c90060: bl      #0x2b70db0                                 fn_2b70db0
02c90064: adrp    x0, #0x6265000                             
02c90068: ldr     x0, [x0, #0x2b8]                           S:'USD'
02c9006c: bl      #0x2b70db0                                 fn_2b70db0
02c90070: adrp    x0, #0x6265000                             
02c90074: ldr     x0, [x0, #0x2c0]                           S:'ad_impression'
02c90078: bl      #0x2b70db0                                 fn_2b70db0
02c9007c: adrp    x0, #0x6265000                             
02c90080: ldr     x0, [x0, #0x2c8]                           S:'ad_platform'
02c90084: bl      #0x2b70db0                                 fn_2b70db0
02c90088: mov     w8, #1                                     
02c9008c: strb    w8, [x22, #0xa4e]                          
02c90090: mov     x0, x19                                    
02c90094: str     wzr, [sp, #0x18]                           
02c90098: bl      #0x2c9bf4c                                 AnalyticsManager::GetAdInfo
02c9009c: cbz     x0, #0x2c903a4                             
02c900a0: adrp    x8, #0x6265000                             
02c900a4: mov     x22, x0                                    
02c900a8: ldr     x8, [x8, #0x1f0]                           T:type24519(k1d)
02c900ac: ldr     x0, [x8]                                   M:AdsManager::<OnApplicationPause>b__26_0
02c900b0: mov     w1, #6                                     
02c900b4: bl      #0x2b70ea0                                 fn_2b70ea0
02c900b8: mov     x19, x0                                    
02c900bc: mov     x0, x22                                    
02c900c0: mov     x1, xzr                                    
02c900c4: bl      #0x4c3f3ec                                 GoogleMobileAds.Api.ResponseInfo::GetMediationAdapterClassName
02c900c8: adrp    x25, #0x6265000                            
02c900cc: mov     x24, x0                                    
02c900d0: ldr     x25, [x25, #0x200]                         T:Firebase.Analytics.Parameter
02c900d4: ldr     x0, [x25]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c900d8: bl      #0x2b7104c                                 fn_2b7104c
02c900dc: adrp    x8, #0x6265000                             
02c900e0: mov     x23, x0                                    
02c900e4: ldr     x8, [x8, #0x2c8]                           S:'ad_platform'
02c900e8: ldr     x1, [x8]                                   M:AdsManager::<OnApplicationPause>b__26_0
02c900ec: mov     x2, x24                                    
02c900f0: mov     x3, xzr                                    
02c900f4: bl      #0x2e07b48                                 Firebase.Analytics.Parameter::.ctor
02c900f8: cbz     x19, #0x2c903bc                            
02c900fc: cbz     x23, #0x2c90114                            
02c90100: ldr     x8, [x19]                                  
02c90104: ldr     x1, [x8, #0x40]                            S:'done_ad'
02c90108: mov     x0, x23                                    
02c9010c: bl      #0x2b70f34                                 fn_2b70f34
02c90110: cbz     x0, #0x2c903e0                             
02c90114: ldr     w8, [x19, #0x18]                           
02c90118: cbz     w8, #0x2c903c0                             
02c9011c: mov     x0, x19                                    
02c90120: str     x23, [x0, #0x20]!                          
02c90124: mov     x1, x23                                    
02c90128: bl      #0x2b70d54                                 fn_2b70d54
02c9012c: mov     x0, x22                                    
02c90130: mov     x1, xzr                                    
02c90134: bl      #0x4c3efbc                                 GoogleMobileAds.Api.ResponseInfo::GetLoadedAdapterResponseInfo
02c90138: cbz     x0, #0x2c903c4                             
02c9013c: mov     x1, xzr                                    
02c90140: bl      #0x4c33d98                                 GoogleMobileAds.Api.AdapterResponseInfo::get_AdSourceName
02c90144: mov     x23, x0                                    
02c90148: ldr     x0, [x25]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9014c: bl      #0x2b7104c                                 fn_2b7104c
02c90150: adrp    x8, #0x6265000                             
02c90154: mov     x22, x0                                    
02c90158: ldr     x8, [x8, #0x2a8]                           S:'ad_source'
02c9015c: ldr     x1, [x8]                                   M:AdsManager::<OnApplicationPause>b__26_0
02c90160: mov     x2, x23                                    
02c90164: mov     x3, xzr                                    
02c90168: bl      #0x2e07b48                                 Firebase.Analytics.Parameter::.ctor
02c9016c: cbz     x22, #0x2c90184                            
02c90170: ldr     x8, [x19]                                  
02c90174: ldr     x1, [x8, #0x40]                            S:'done_ad'
02c90178: mov     x0, x22                                    
02c9017c: bl      #0x2b70f34                                 fn_2b70f34
02c90180: cbz     x0, #0x2c903ec                             
02c90184: ldr     w8, [x19, #0x18]                           
02c90188: tst     w8, #0xfffffffe                            
02c9018c: b.eq    #0x2c903c8                                 
02c90190: mov     x0, x19                                    
02c90194: str     x22, [x0, #0x28]!                          
02c90198: mov     x1, x22                                    
02c9019c: bl      #0x2b70d54                                 fn_2b70d54
02c901a0: mov     w0, w21                                    
02c901a4: bl      #0x2c8de38                                 KeyAds::Get
02c901a8: mov     x23, x0                                    
02c901ac: ldr     x0, [x25]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c901b0: bl      #0x2b7104c                                 fn_2b7104c
02c901b4: adrp    x8, #0x6265000                             
02c901b8: mov     x22, x0                                    
02c901bc: ldr     x8, [x8, #0x280]                           S:'ad_unit_name'
02c901c0: ldr     x1, [x8]                                   M:AdsManager::<OnApplicationPause>b__26_0
02c901c4: mov     x2, x23                                    
02c901c8: mov     x3, xzr                                    
02c901cc: bl      #0x2e07b48                                 Firebase.Analytics.Parameter::.ctor
02c901d0: cbz     x22, #0x2c901e8                            
02c901d4: ldr     x8, [x19]                                  
02c901d8: ldr     x1, [x8, #0x40]                            S:'done_ad'
02c901dc: mov     x0, x22                                    
02c901e0: bl      #0x2b70f34                                 fn_2b70f34
02c901e4: cbz     x0, #0x2c903f8                             
02c901e8: ldr     w8, [x19, #0x18]                           
02c901ec: cmp     w8, #2                                     
02c901f0: b.ls    #0x2c903cc                                 
02c901f4: mov     x0, x19                                    
02c901f8: str     x22, [x0, #0x30]!                          
02c901fc: mov     x1, x22                                    
02c90200: bl      #0x2b70d54                                 fn_2b70d54
02c90204: adrp    x8, #0x6265000                             
02c90208: ldr     x8, [x8, #0x210]                           T:AdFormat
02c9020c: str     w21, [sp, #0xc]                            
02c90210: ldr     x0, [x8]                                   M:AdsManager::<OnApplicationPause>b__26_0
02c90214: add     x1, sp, #0xc                               
02c90218: bl      #0x2b70f38                                 fn_2b70f38
02c9021c: mov     x1, x0                                     
02c90220: adrp    x8, #0x6264000                             
02c90224: ldr     x8, [x8, #0xd90]                           S:'{0}'
02c90228: ldr     x0, [x8]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c9022c: mov     x2, xzr                                    
02c90230: bl      #0x4c9d0ec                                 System.String::Format
02c90234: mov     x22, x0                                    
02c90238: ldr     x0, [x25]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9023c: bl      #0x2b7104c                                 fn_2b7104c
02c90240: adrp    x8, #0x6265000                             
02c90244: mov     x21, x0                                    
02c90248: ldr     x8, [x8, #0x288]                           S:'ad_format'
02c9024c: ldr     x1, [x8]                                   M:AdsManager::<OnApplicationPause>b__26_0
02c90250: mov     x2, x22                                    
02c90254: mov     x3, xzr                                    
02c90258: bl      #0x2e07b48                                 Firebase.Analytics.Parameter::.ctor
02c9025c: cbz     x21, #0x2c90274                            
02c90260: ldr     x8, [x19]                                  
02c90264: ldr     x1, [x8, #0x40]                            S:'done_ad'
02c90268: mov     x0, x21                                    
02c9026c: bl      #0x2b70f34                                 fn_2b70f34
02c90270: cbz     x0, #0x2c90404                             
02c90274: ldr     w8, [x19, #0x18]                           
02c90278: tst     w8, #0xfffffffc                            
02c9027c: b.eq    #0x2c903d0                                 
02c90280: mov     x0, x19                                    
02c90284: str     x21, [x0, #0x38]!                          
02c90288: mov     x1, x21                                    
02c9028c: bl      #0x2b70d54                                 fn_2b70d54
02c90290: cbz     x20, #0x2c903d4                            
02c90294: ldr     x21, [x20, #0x18]                          
02c90298: ldr     x0, [x25]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9029c: bl      #0x2b7104c                                 fn_2b7104c
02c902a0: adrp    x8, #0x1041000                             
02c902a4: scvtf   d0, x21                                    
02c902a8: mov     x20, x0                                    
02c902ac: ldr     d1, [x8, #0xb0]                            [10410b0]=412e848000000000 f=0,10.9073
02c902b0: adrp    x8, #0x6265000                             
02c902b4: ldr     x8, [x8, #0x2a0]                           S:'value'
02c902b8: ldr     x1, [x8]                                   M:AdsManager::<OnApplicationPause>b__26_0
02c902bc: fdiv    d0, d0, d1                                 
02c902c0: mov     x2, xzr                                    
02c902c4: bl      #0x2e07bf4                                 Firebase.Analytics.Parameter::.ctor
02c902c8: cbz     x20, #0x2c902e0                            
02c902cc: ldr     x8, [x19]                                  
02c902d0: ldr     x1, [x8, #0x40]                            S:'done_ad'
02c902d4: mov     x0, x20                                    
02c902d8: bl      #0x2b70f34                                 fn_2b70f34
02c902dc: cbz     x0, #0x2c90410                             
02c902e0: ldr     w8, [x19, #0x18]                           
02c902e4: cmp     w8, #4                                     
02c902e8: b.ls    #0x2c903d8                                 
02c902ec: mov     x0, x19                                    
02c902f0: str     x20, [x0, #0x40]!                          
02c902f4: mov     x1, x20                                    
02c902f8: bl      #0x2b70d54                                 fn_2b70d54
02c902fc: ldr     x0, [x25]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c90300: bl      #0x2b7104c                                 fn_2b7104c
02c90304: adrp    x8, #0x6265000                             
02c90308: adrp    x9, #0x6265000                             
02c9030c: mov     x20, x0                                    
02c90310: ldr     x8, [x8, #0x2b0]                           S:'currency'
02c90314: ldr     x9, [x9, #0x2b8]                           S:'USD'
02c90318: ldr     x1, [x8]                                   M:AdsManager::<OnApplicationPause>b__26_0
02c9031c: ldr     x2, [x9]                                   M:AdsManager::<OnApplicationPause>b__26_0
02c90320: mov     x3, xzr                                    
02c90324: bl      #0x2e07b48                                 Firebase.Analytics.Parameter::.ctor
02c90328: cbz     x20, #0x2c90340                            
02c9032c: ldr     x8, [x19]                                  
02c90330: ldr     x1, [x8, #0x40]                            S:'done_ad'
02c90334: mov     x0, x20                                    
02c90338: bl      #0x2b70f34                                 fn_2b70f34
02c9033c: cbz     x0, #0x2c9041c                             
02c90340: ldr     w8, [x19, #0x18]                           
02c90344: cmp     w8, #5                                     
02c90348: b.ls    #0x2c903dc                                 
02c9034c: mov     x0, x19                                    
02c90350: str     x20, [x0, #0x48]!                          
02c90354: mov     x1, x20                                    
02c90358: bl      #0x2b70d54                                 fn_2b70d54
02c9035c: adrp    x8, #0x6265000                             
02c90360: ldr     x8, [x8, #0x1f8]                           T:Firebase.Analytics.FirebaseAnalytics
02c90364: ldr     x0, [x8]                                   M:AdsManager::<OnApplicationPause>b__26_0
02c90368: ldr     w8, [x0, #0xe4]                            [62650e4]=0 f=0,0
02c9036c: cbnz    w8, #0x2c90374                             
02c90370: bl      #0x2b70f30                                 fn_2b70f30
02c90374: adrp    x8, #0x6265000                             
02c90378: ldr     x8, [x8, #0x2c0]                           S:'ad_impression'
02c9037c: ldr     x0, [x8]                                   M:AdsManager::<OnApplicationPause>b__26_0
02c90380: mov     x1, x19                                    
02c90384: mov     x2, xzr                                    
02c90388: bl      #0x2e052d8                                 Firebase.Analytics.FirebaseAnalytics::LogEvent
02c9038c: adrp    x8, #0x6265000                             
02c90390: ldr     x8, [x8, #0x298]                           S:'ad_impression_abi'
02c90394: ldr     x0, [x8]                                   M:AdsManager::<OnApplicationPause>b__26_0
02c90398: mov     x1, x19                                    
02c9039c: mov     x2, xzr                                    
02c903a0: bl      #0x2e052d8                                 Firebase.Analytics.FirebaseAnalytics::LogEvent
02c903a4: ldp     x20, x19, [sp, #0x50]                      
02c903a8: ldp     x22, x21, [sp, #0x40]                      
02c903ac: ldp     x24, x23, [sp, #0x30]                      
02c903b0: ldp     x30, x25, [sp, #0x20]                      
02c903b4: add     sp, sp, #0x60                              
02c903b8: ret                                                
02c903bc: bl      #0x2b7105c                                 fn_2b7105c
02c903c0: bl      #0x2b71064                                 fn_2b71064
02c903c4: bl      #0x2b7105c                                 fn_2b7105c
02c903c8: bl      #0x2b71064                                 fn_2b71064
02c903cc: bl      #0x2b71064                                 fn_2b71064
02c903d0: bl      #0x2b71064                                 fn_2b71064
02c903d4: bl      #0x2b7105c                                 fn_2b7105c
02c903d8: bl      #0x2b71064                                 fn_2b71064
02c903dc: bl      #0x2b71064                                 fn_2b71064
02c903e0: bl      #0x2b71080                                 fn_2b71080
02c903e4: mov     x1, xzr                                    
02c903e8: bl      #0x2b70f20                                 fn_2b70f20
02c903ec: bl      #0x2b71080                                 fn_2b71080
02c903f0: mov     x1, xzr                                    
02c903f4: bl      #0x2b70f20                                 fn_2b70f20
02c903f8: bl      #0x2b71080                                 fn_2b71080
02c903fc: mov     x1, xzr                                    
02c90400: bl      #0x2b70f20                                 fn_2b70f20
02c90404: bl      #0x2b71080                                 fn_2b71080
02c90408: mov     x1, xzr                                    
02c9040c: bl      #0x2b70f20                                 fn_2b70f20
02c90410: bl      #0x2b71080                                 fn_2b71080
02c90414: mov     x1, xzr                                    
02c90418: bl      #0x2b70f20                                 fn_2b70f20
02c9041c: bl      #0x2b71080                                 fn_2b71080
02c90420: mov     x1, xzr                                    
02c90424: bl      #0x2b70f20                                 fn_2b70f20
02c90428: b       #0x2c90464                                 
02c9042c: b       #0x2c90464                                 
02c90430: b       #0x2c90464                                 
02c90434: b       #0x2c90464                                 
02c90438: b       #0x2c90464                                 
02c9043c: b       #0x2c90464                                 
02c90440: b       #0x2c90464                                 
02c90444: b       #0x2c90464                                 
02c90448: b       #0x2c90464                                 
02c9044c: b       #0x2c90464                                 
02c90450: b       #0x2c90464                                 
02c90454: b       #0x2c90464                                 
02c90458: b       #0x2c90464                                 
02c9045c: b       #0x2c90464                                 
02c90460: b       #0x2c90464                                 
02c90464: mov     x19, x0                                    
02c90468: cmp     w1, #1                                     
02c9046c: b.ne    #0x2c904e4                                 
02c90470: mov     x0, x19                                    
02c90474: bl      #0x5e90260                                 fn_5e90260
02c90478: adrp    x8, #0x6263000                             
02c9047c: mov     x19, x0                                    
02c90480: ldr     x8, [x8, #0x970]                           &6645c70(=0)
02c90484: ldr     x9, [x0]                                   M:AdsManager::<OnApplicationPause>b__26_0
02c90488: ldr     x0, [x8, #0x10]                            &2c498bc(=aa1f03e0d503245f)
02c9048c: ldr     x1, [x9]                                   M:AdsManager::<OnApplicationPause>b__26_0
02c90490: bl      #0x2b71464                                 fn_2b71464
02c90494: tbz     w0, #0, #0x2c904bc                         
02c90498: ldrsw   x20, [sp, #0x18]                           
02c9049c: ldr     x8, [x19]                                  
02c904a0: add     x9, sp, #0x10                              
02c904a4: str     x8, [x9, x20, lsl #3]                      
02c904a8: add     w8, w20, #1                                
02c904ac: str     w8, [sp, #0x18]                            
02c904b0: bl      #0x5e90270                                 fn_5e90270
02c904b4: str     w20, [sp, #0x18]                           
02c904b8: b       #0x2c903a4                                 
02c904bc: mov     w0, #8                                     
02c904c0: bl      #0x5e90290                                 fn_5e90290
02c904c4: ldr     x8, [x19]                                  
02c904c8: str     x8, [x0]                                   
02c904cc: adrp    x1, #0x5e96000                             
02c904d0: add     x1, x1, #0x758                             &5e96758
02c904d4: mov     x2, xzr                                    
02c904d8: bl      #0x5e902a0                                 fn_5e902a0
02c904dc: mov     x19, x0                                    
02c904e0: bl      #0x5e90270                                 fn_5e90270
02c904e4: mov     x0, x19                                    
02c904e8: bl      #0x2c6051c                                 fn_2c6051c
02c904ec: bl      #0x27369b8                                 fn_27369b8
## LogFirebaseAdmobRevenue(System.Collections.Generic.Dictionary`2<string,string> parameters, AdFormat adFormat, double revenue) -> void
---- AnalyticsManager::LogFirebaseAdmobRevenue 0x2c996c8
02c996c8: sub     sp, sp, #0x70                              
02c996cc: str     d8, [sp, #0x20]                            
02c996d0: str     x30, [sp, #0x28]                           
02c996d4: stp     x26, x25, [sp, #0x30]                      
02c996d8: stp     x24, x23, [sp, #0x40]                      
02c996dc: stp     x22, x21, [sp, #0x50]                      
02c996e0: stp     x20, x19, [sp, #0x60]                      
02c996e4: fmov    d8, d0                                     
02c996e8: adrp    x22, #0x662f000                            
02c996ec: adrp    x19, #0x6265000                            
02c996f0: ldrb    w8, [x22, #0xa4f]                          
02c996f4: ldr     x19, [x19, #0x1f0]                         T:type24519(k1d)
02c996f8: mov     w20, w1                                    
02c996fc: mov     x21, x0                                    
02c99700: tbnz    w8, #0, #0x2c997a8                         
02c99704: adrp    x0, #0x6265000                             
02c99708: ldr     x0, [x0, #0x210]                           T:AdFormat
02c9970c: bl      #0x2b70db0                                 fn_2b70db0
02c99710: adrp    x0, #0x6265000                             
02c99714: ldr     x0, [x0, #0x9b8]                           MS:System.Collections.Generic.Dictionary`2::get_Item
02c99718: bl      #0x2b70db0                                 fn_2b70db0
02c9971c: adrp    x0, #0x6265000                             
02c99720: ldr     x0, [x0, #0x1f8]                           T:Firebase.Analytics.FirebaseAnalytics
02c99724: bl      #0x2b70db0                                 fn_2b70db0
02c99728: adrp    x0, #0x6265000                             
02c9972c: ldr     x0, [x0, #0x1f0]                           T:type24519(k1d)
02c99730: bl      #0x2b70db0                                 fn_2b70db0
02c99734: adrp    x0, #0x6265000                             
02c99738: ldr     x0, [x0, #0x200]                           T:Firebase.Analytics.Parameter
02c9973c: bl      #0x2b70db0                                 fn_2b70db0
02c99740: adrp    x0, #0x6264000                             
02c99744: ldr     x0, [x0, #0xd90]                           S:'{0}'
02c99748: bl      #0x2b70db0                                 fn_2b70db0
02c9974c: adrp    x0, #0x6265000                             
02c99750: ldr     x0, [x0, #0x280]                           S:'ad_unit_name'
02c99754: bl      #0x2b70db0                                 fn_2b70db0
02c99758: adrp    x0, #0x6265000                             
02c9975c: ldr     x0, [x0, #0x288]                           S:'ad_format'
02c99760: bl      #0x2b70db0                                 fn_2b70db0
02c99764: adrp    x0, #0x6265000                             
02c99768: ldr     x0, [x0, #0x2a0]                           S:'value'
02c9976c: bl      #0x2b70db0                                 fn_2b70db0
02c99770: adrp    x0, #0x6265000                             
02c99774: ldr     x0, [x0, #0x2a8]                           S:'ad_source'
02c99778: bl      #0x2b70db0                                 fn_2b70db0
02c9977c: adrp    x0, #0x6265000                             
02c99780: ldr     x0, [x0, #0x2b0]                           S:'currency'
02c99784: bl      #0x2b70db0                                 fn_2b70db0
02c99788: adrp    x0, #0x6265000                             
02c9978c: ldr     x0, [x0, #0x2b8]                           S:'USD'
02c99790: bl      #0x2b70db0                                 fn_2b70db0
02c99794: adrp    x0, #0x6265000                             
02c99798: ldr     x0, [x0, #0x2c0]                           S:'ad_impression'
02c9979c: bl      #0x2b70db0                                 fn_2b70db0
02c997a0: mov     w8, #1                                     
02c997a4: strb    w8, [x22, #0xa4f]                          
02c997a8: ldr     x0, [x19]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c997ac: str     wzr, [sp, #0x18]                           
02c997b0: mov     w1, #5                                     
02c997b4: bl      #0x2b70ea0                                 fn_2b70ea0
02c997b8: cbz     x21, #0x2c99a3c                            
02c997bc: adrp    x26, #0x6265000                            
02c997c0: adrp    x25, #0x6265000                            
02c997c4: mov     x19, x0                                    
02c997c8: ldr     x26, [x26, #0x2a8]                         S:'ad_source'
02c997cc: ldr     x25, [x25, #0x9b8]                         MS:System.Collections.Generic.Dictionary`2::get_Item
02c997d0: ldr     x1, [x26]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c997d4: ldr     x2, [x25]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c997d8: mov     x0, x21                                    
02c997dc: bl      #0x452c59c                                 fn_452c59c
02c997e0: adrp    x24, #0x6265000                            
02c997e4: mov     x23, x0                                    
02c997e8: ldr     x24, [x24, #0x200]                         T:Firebase.Analytics.Parameter
02c997ec: ldr     x0, [x24]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c997f0: bl      #0x2b7104c                                 fn_2b7104c
02c997f4: ldr     x1, [x26]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c997f8: mov     x22, x0                                    
02c997fc: mov     x2, x23                                    
02c99800: mov     x3, xzr                                    
02c99804: bl      #0x2e07b48                                 Firebase.Analytics.Parameter::.ctor
02c99808: cbz     x19, #0x2c99a40                            
02c9980c: cbz     x22, #0x2c99824                            
02c99810: ldr     x8, [x19]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c99814: ldr     x1, [x8, #0x40]                            
02c99818: mov     x0, x22                                    
02c9981c: bl      #0x2b70f34                                 fn_2b70f34
02c99820: cbz     x0, #0x2c99a58                             
02c99824: ldr     w8, [x19, #0x18]                           T:AdsManager/<IEHideAdResume>d__30
02c99828: cbz     w8, #0x2c99a44                             
02c9982c: mov     x0, x19                                    
02c99830: str     x22, [x0, #0x20]!                          
02c99834: mov     x1, x22                                    
02c99838: bl      #0x2b70d54                                 fn_2b70d54
02c9983c: adrp    x23, #0x6265000                            
02c99840: ldr     x23, [x23, #0x280]                         S:'ad_unit_name'
02c99844: ldr     x2, [x25]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c99848: ldr     x1, [x23]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9984c: mov     x0, x21                                    
02c99850: bl      #0x452c59c                                 fn_452c59c
02c99854: mov     x22, x0                                    
02c99858: ldr     x0, [x24]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9985c: bl      #0x2b7104c                                 fn_2b7104c
02c99860: ldr     x1, [x23]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c99864: mov     x21, x0                                    
02c99868: mov     x2, x22                                    
02c9986c: mov     x3, xzr                                    
02c99870: bl      #0x2e07b48                                 Firebase.Analytics.Parameter::.ctor
02c99874: cbz     x21, #0x2c9988c                            
02c99878: ldr     x8, [x19]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9987c: ldr     x1, [x8, #0x40]                            
02c99880: mov     x0, x21                                    
02c99884: bl      #0x2b70f34                                 fn_2b70f34
02c99888: cbz     x0, #0x2c99a64                             
02c9988c: ldr     w8, [x19, #0x18]                           T:AdsManager/<IEHideAdResume>d__30
02c99890: tst     w8, #0xfffffffe                            
02c99894: b.eq    #0x2c99a48                                 
02c99898: mov     x0, x19                                    
02c9989c: str     x21, [x0, #0x28]!                          
02c998a0: mov     x1, x21                                    
02c998a4: bl      #0x2b70d54                                 fn_2b70d54
02c998a8: adrp    x8, #0x6265000                             
02c998ac: ldr     x8, [x8, #0x210]                           T:AdFormat
02c998b0: str     w20, [sp, #0xc]                            
02c998b4: ldr     x0, [x8]                                   M:AdsManager::<OnApplicationPause>b__26_0
02c998b8: add     x1, sp, #0xc                               
02c998bc: bl      #0x2b70f38                                 fn_2b70f38
02c998c0: mov     x1, x0                                     
02c998c4: adrp    x8, #0x6264000                             
02c998c8: ldr     x8, [x8, #0xd90]                           S:'{0}'
02c998cc: ldr     x0, [x8]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c998d0: mov     x2, xzr                                    
02c998d4: bl      #0x4c9d0ec                                 System.String::Format
02c998d8: mov     x21, x0                                    
02c998dc: ldr     x0, [x24]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c998e0: bl      #0x2b7104c                                 fn_2b7104c
02c998e4: adrp    x8, #0x6265000                             
02c998e8: mov     x20, x0                                    
02c998ec: ldr     x8, [x8, #0x288]                           S:'ad_format'
02c998f0: ldr     x1, [x8]                                   M:AdsManager::<OnApplicationPause>b__26_0
02c998f4: mov     x2, x21                                    
02c998f8: mov     x3, xzr                                    
02c998fc: bl      #0x2e07b48                                 Firebase.Analytics.Parameter::.ctor
02c99900: cbz     x20, #0x2c99918                            
02c99904: ldr     x8, [x19]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c99908: ldr     x1, [x8, #0x40]                            S:'done_ad'
02c9990c: mov     x0, x20                                    
02c99910: bl      #0x2b70f34                                 fn_2b70f34
02c99914: cbz     x0, #0x2c99a70                             
02c99918: ldr     w8, [x19, #0x18]                           T:AdsManager/<IEHideAdResume>d__30
02c9991c: cmp     w8, #2                                     
02c99920: b.ls    #0x2c99a4c                                 
02c99924: mov     x0, x19                                    
02c99928: str     x20, [x0, #0x30]!                          
02c9992c: mov     x1, x20                                    
02c99930: bl      #0x2b70d54                                 fn_2b70d54
02c99934: ldr     x0, [x24]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c99938: bl      #0x2b7104c                                 fn_2b7104c
02c9993c: adrp    x8, #0x6265000                             
02c99940: mov     x20, x0                                    
02c99944: ldr     x8, [x8, #0x2a0]                           S:'value'
02c99948: ldr     x1, [x8]                                   M:AdsManager::<OnApplicationPause>b__26_0
02c9994c: fmov    d0, d8                                     
02c99950: mov     x2, xzr                                    
02c99954: bl      #0x2e07bf4                                 Firebase.Analytics.Parameter::.ctor
02c99958: cbz     x20, #0x2c99970                            
02c9995c: ldr     x8, [x19]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c99960: ldr     x1, [x8, #0x40]                            S:'done_ad'
02c99964: mov     x0, x20                                    
02c99968: bl      #0x2b70f34                                 fn_2b70f34
02c9996c: cbz     x0, #0x2c99a7c                             
02c99970: ldr     w8, [x19, #0x18]                           T:AdsManager/<IEHideAdResume>d__30
02c99974: tst     w8, #0xfffffffc                            
02c99978: b.eq    #0x2c99a50                                 
02c9997c: mov     x0, x19                                    
02c99980: str     x20, [x0, #0x38]!                          
02c99984: mov     x1, x20                                    
02c99988: bl      #0x2b70d54                                 fn_2b70d54
02c9998c: ldr     x0, [x24]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c99990: bl      #0x2b7104c                                 fn_2b7104c
02c99994: adrp    x8, #0x6265000                             
02c99998: adrp    x9, #0x6265000                             
02c9999c: mov     x20, x0                                    
02c999a0: ldr     x8, [x8, #0x2b0]                           S:'currency'
02c999a4: ldr     x9, [x9, #0x2b8]                           S:'USD'
02c999a8: ldr     x1, [x8]                                   M:AdsManager::<OnApplicationPause>b__26_0
02c999ac: ldr     x2, [x9]                                   M:AdsManager::<OnApplicationPause>b__26_0
02c999b0: mov     x3, xzr                                    
02c999b4: bl      #0x2e07b48                                 Firebase.Analytics.Parameter::.ctor
02c999b8: cbz     x20, #0x2c999d0                            
02c999bc: ldr     x8, [x19]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c999c0: ldr     x1, [x8, #0x40]                            S:'done_ad'
02c999c4: mov     x0, x20                                    
02c999c8: bl      #0x2b70f34                                 fn_2b70f34
02c999cc: cbz     x0, #0x2c99a88                             
02c999d0: ldr     w8, [x19, #0x18]                           T:AdsManager/<IEHideAdResume>d__30
02c999d4: cmp     w8, #4                                     
02c999d8: b.ls    #0x2c99a54                                 
02c999dc: mov     x0, x19                                    
02c999e0: str     x20, [x0, #0x40]!                          
02c999e4: mov     x1, x20                                    
02c999e8: bl      #0x2b70d54                                 fn_2b70d54
02c999ec: adrp    x8, #0x6265000                             
02c999f0: ldr     x8, [x8, #0x1f8]                           T:Firebase.Analytics.FirebaseAnalytics
02c999f4: ldr     x0, [x8]                                   M:AdsManager::<OnApplicationPause>b__26_0
02c999f8: ldr     w8, [x0, #0xe4]                            [62650e4]=0 f=0,0
02c999fc: cbnz    w8, #0x2c99a04                             
02c99a00: bl      #0x2b70f30                                 fn_2b70f30
02c99a04: adrp    x8, #0x6265000                             
02c99a08: ldr     x8, [x8, #0x2c0]                           S:'ad_impression'
02c99a0c: ldr     x0, [x8]                                   M:AdsManager::<OnApplicationPause>b__26_0
02c99a10: mov     x1, x19                                    
02c99a14: mov     x2, xzr                                    
02c99a18: bl      #0x2e052d8                                 Firebase.Analytics.FirebaseAnalytics::LogEvent
02c99a1c: ldp     x20, x19, [sp, #0x60]                      
02c99a20: ldr     x30, [sp, #0x28]                           
02c99a24: ldp     x22, x21, [sp, #0x50]                      
02c99a28: ldr     d8, [sp, #0x20]                            
02c99a2c: ldp     x24, x23, [sp, #0x40]                      
02c99a30: ldp     x26, x25, [sp, #0x30]                      
02c99a34: add     sp, sp, #0x70                              
02c99a38: ret                                                
02c99a3c: bl      #0x2b7105c                                 fn_2b7105c
02c99a40: bl      #0x2b7105c                                 fn_2b7105c
02c99a44: bl      #0x2b71064                                 fn_2b71064
02c99a48: bl      #0x2b71064                                 fn_2b71064
02c99a4c: bl      #0x2b71064                                 fn_2b71064
02c99a50: bl      #0x2b71064                                 fn_2b71064
02c99a54: bl      #0x2b71064                                 fn_2b71064
02c99a58: bl      #0x2b71080                                 fn_2b71080
02c99a5c: mov     x1, xzr                                    
02c99a60: bl      #0x2b70f20                                 fn_2b70f20
02c99a64: bl      #0x2b71080                                 fn_2b71080
02c99a68: mov     x1, xzr                                    
02c99a6c: bl      #0x2b70f20                                 fn_2b70f20
02c99a70: bl      #0x2b71080                                 fn_2b71080
02c99a74: mov     x1, xzr                                    
02c99a78: bl      #0x2b70f20                                 fn_2b70f20
02c99a7c: bl      #0x2b71080                                 fn_2b71080
02c99a80: mov     x1, xzr                                    
02c99a84: bl      #0x2b70f20                                 fn_2b70f20
02c99a88: bl      #0x2b71080                                 fn_2b71080
02c99a8c: mov     x1, xzr                                    
02c99a90: bl      #0x2b70f20                                 fn_2b70f20
02c99a94: b       #0x2c99ac0                                 
02c99a98: b       #0x2c99ac0                                 
02c99a9c: b       #0x2c99ac0                                 
02c99aa0: b       #0x2c99ac0                                 
02c99aa4: b       #0x2c99ac0                                 
02c99aa8: b       #0x2c99ac0                                 
02c99aac: b       #0x2c99ac0                                 
02c99ab0: b       #0x2c99ac0                                 
02c99ab4: b       #0x2c99ac0                                 
02c99ab8: b       #0x2c99ac0                                 
02c99abc: b       #0x2c99ac0                                 
02c99ac0: mov     x19, x0                                    
02c99ac4: cmp     w1, #1                                     
02c99ac8: b.ne    #0x2c99b40                                 
02c99acc: mov     x0, x19                                    
02c99ad0: bl      #0x5e90260                                 fn_5e90260
02c99ad4: adrp    x8, #0x6263000                             
02c99ad8: mov     x19, x0                                    
02c99adc: ldr     x8, [x8, #0x970]                           &6645c70(=0)
02c99ae0: ldr     x9, [x0]                                   M:AdsManager::<OnApplicationPause>b__26_0
02c99ae4: ldr     x0, [x8, #0x10]                            &2c498bc(=aa1f03e0d503245f)
02c99ae8: ldr     x1, [x9]                                   M:AdsManager::<OnApplicationPause>b__26_0
02c99aec: bl      #0x2b71464                                 fn_2b71464
02c99af0: tbz     w0, #0, #0x2c99b18                         
02c99af4: ldrsw   x20, [sp, #0x18]                           
02c99af8: ldr     x8, [x19]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c99afc: add     x9, sp, #0x10                              
02c99b00: str     x8, [x9, x20, lsl #3]                      
02c99b04: add     w8, w20, #1                                
02c99b08: str     w8, [sp, #0x18]                            
02c99b0c: bl      #0x5e90270                                 fn_5e90270
02c99b10: str     w20, [sp, #0x18]                           
02c99b14: b       #0x2c99a1c                                 
02c99b18: mov     w0, #8                                     
02c99b1c: bl      #0x5e90290                                 fn_5e90290
02c99b20: ldr     x8, [x19]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c99b24: str     x8, [x0]                                   
02c99b28: adrp    x1, #0x5e96000                             
02c99b2c: add     x1, x1, #0x758                             &5e96758
02c99b30: mov     x2, xzr                                    
02c99b34: bl      #0x5e902a0                                 fn_5e902a0
02c99b38: mov     x19, x0                                    
02c99b3c: bl      #0x5e90270                                 fn_5e90270
02c99b40: mov     x0, x19                                    
02c99b44: bl      #0x2c6051c                                 fn_2c6051c
02c99b48: bl      #0x27369b8                                 fn_27369b8
## LogAppsflyerEvent(string eventName, System.Collections.Generic.Dictionary`2<string,string> eventValues) -> void
---- AnalyticsManager::LogAppsflyerEvent 0x2c89794
02c89794: stp     x30, x23, [sp, #-0x30]!                    
02c89798: stp     x22, x21, [sp, #0x10]                      
02c8979c: stp     x20, x19, [sp, #0x20]                      
02c897a0: adrp    x22, #0x662f000                            
02c897a4: adrp    x21, #0x6263000                            
02c897a8: adrp    x23, #0x6263000                            
02c897ac: ldrb    w8, [x22, #0xa50]                          
02c897b0: ldr     x21, [x21, #0xa90]                         S:''
02c897b4: ldr     x23, [x23, #0x900]                         T:AppsFlyerSDK.AppsFlyer
02c897b8: mov     x19, x1                                    
02c897bc: mov     x20, x0                                    
02c897c0: tbnz    w8, #0, #0x2c897e4                         
02c897c4: adrp    x0, #0x6263000                             
02c897c8: ldr     x0, [x0, #0x900]                           T:AppsFlyerSDK.AppsFlyer
02c897cc: bl      #0x2b70db0                                 fn_2b70db0
02c897d0: adrp    x0, #0x6263000                             
02c897d4: ldr     x0, [x0, #0xa90]                           S:''
02c897d8: bl      #0x2b70db0                                 fn_2b70db0
02c897dc: mov     w8, #1                                     
02c897e0: strb    w8, [x22, #0xa50]                          
02c897e4: ldr     x0, [x23]                                  &2c5bbd4(=a9bd7bfdd503233f)
02c897e8: ldr     x21, [x21]                                 &2c5bbd4(=a9bd7bfdd503233f)
02c897ec: ldr     w8, [x0, #0xe4]                            [62630e4]=0 f=0,0
02c897f0: cbnz    w8, #0x2c897f8                             
02c897f4: bl      #0x2b70f30                                 fn_2b70f30
02c897f8: cmp     x20, #0                                    
02c897fc: mov     x1, x19                                    
02c89800: mov     x2, xzr                                    
02c89804: csel    x0, x21, x20, eq                           
02c89808: ldp     x20, x19, [sp, #0x20]                      
02c8980c: ldp     x22, x21, [sp, #0x10]                      
02c89810: ldp     x30, x23, [sp], #0x30                      
02c89814: b       #0x2c67020                                 AppsFlyerSDK.AppsFlyer::sendEvent
## LogAppsflyerApplovinRevenue(MaxSdkBase/AdInfo adInfo) -> void
---- AnalyticsManager::LogAppsflyerApplovinRevenue 0x2c8c5c8
02c8c5c8: str     d8, [sp, #-0x70]!                          
02c8c5cc: stp     x29, x30, [sp, #0x10]                      
02c8c5d0: stp     x28, x27, [sp, #0x20]                      
02c8c5d4: stp     x26, x25, [sp, #0x30]                      
02c8c5d8: stp     x24, x23, [sp, #0x40]                      
02c8c5dc: stp     x22, x21, [sp, #0x50]                      
02c8c5e0: stp     x20, x19, [sp, #0x60]                      
02c8c5e4: adrp    x20, #0x662f000                            
02c8c5e8: mov     x19, x0                                    
02c8c5ec: ldrb    w8, [x20, #0xa51]                          
02c8c5f0: tbnz    w8, #0, #0x2c8c6b0                         
02c8c5f4: adrp    x0, #0x6265000                             
02c8c5f8: ldr     x0, [x0, #0x2d0]                           T:AppsFlyerSDK.AFAdRevenueData
02c8c5fc: bl      #0x2b70db0                                 fn_2b70db0
02c8c600: adrp    x0, #0x6263000                             
02c8c604: ldr     x0, [x0, #0x900]                           T:AppsFlyerSDK.AppsFlyer
02c8c608: bl      #0x2b70db0                                 fn_2b70db0
02c8c60c: adrp    x0, #0x6265000                             
02c8c610: ldr     x0, [x0, #0x2d8]                           MS:System.Collections.Generic.Dictionary`2::Add
02c8c614: bl      #0x2b70db0                                 fn_2b70db0
02c8c618: adrp    x0, #0x6265000                             
02c8c61c: ldr     x0, [x0, #0x2e0]                           MS:System.Collections.Generic.Dictionary`2::.ctor
02c8c620: bl      #0x2b70db0                                 fn_2b70db0
02c8c624: adrp    x0, #0x6265000                             
02c8c628: ldr     x0, [x0, #0x2e8]                           T:type8944(k15)
02c8c62c: bl      #0x2b70db0                                 fn_2b70db0
02c8c630: adrp    x0, #0x6264000                             
02c8c634: ldr     x0, [x0, #0xd90]                           S:'{0}'
02c8c638: bl      #0x2b70db0                                 fn_2b70db0
02c8c63c: adrp    x0, #0x6265000                             
02c8c640: ldr     x0, [x0, #0x280]                           S:'ad_unit_name'
02c8c644: bl      #0x2b70db0                                 fn_2b70db0
02c8c648: adrp    x0, #0x6265000                             
02c8c64c: ldr     x0, [x0, #0x288]                           S:'ad_format'
02c8c650: bl      #0x2b70db0                                 fn_2b70db0
02c8c654: adrp    x0, #0x6265000                             
02c8c658: ldr     x0, [x0, #0x2a0]                           S:'value'
02c8c65c: bl      #0x2b70db0                                 fn_2b70db0
02c8c660: adrp    x0, #0x6265000                             
02c8c664: ldr     x0, [x0, #0x2a8]                           S:'ad_source'
02c8c668: bl      #0x2b70db0                                 fn_2b70db0
02c8c66c: adrp    x0, #0x6265000                             
02c8c670: ldr     x0, [x0, #0x2b0]                           S:'currency'
02c8c674: bl      #0x2b70db0                                 fn_2b70db0
02c8c678: adrp    x0, #0x6265000                             
02c8c67c: ldr     x0, [x0, #0x2b8]                           S:'USD'
02c8c680: bl      #0x2b70db0                                 fn_2b70db0
02c8c684: adrp    x0, #0x6265000                             
02c8c688: ldr     x0, [x0, #0x2c8]                           S:'ad_platform'
02c8c68c: bl      #0x2b70db0                                 fn_2b70db0
02c8c690: adrp    x0, #0x6265000                             
02c8c694: ldr     x0, [x0, #0x208]                           S:'placement'
02c8c698: bl      #0x2b70db0                                 fn_2b70db0
02c8c69c: adrp    x0, #0x6265000                             
02c8c6a0: ldr     x0, [x0, #0x2f0]                           S:'appLovin'
02c8c6a4: bl      #0x2b70db0                                 fn_2b70db0
02c8c6a8: mov     w8, #1                                     
02c8c6ac: strb    w8, [x20, #0xa51]                          
02c8c6b0: cbz     x19, #0x2c8c868                            
02c8c6b4: adrp    x8, #0x6265000                             
02c8c6b8: adrp    x20, #0x6265000                            
02c8c6bc: ldr     x8, [x8, #0x2e8]                           T:type8944(k15)
02c8c6c0: ldr     x20, [x20, #0x2e0]                         MS:System.Collections.Generic.Dictionary`2::.ctor
02c8c6c4: ldr     d8, [x19, #0x40]                           
02c8c6c8: ldr     x0, [x8]                                   M:AdsManager::<OnApplicationPause>b__26_0
02c8c6cc: bl      #0x2b7104c                                 fn_2b7104c
02c8c6d0: ldr     x1, [x20]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c8c6d4: mov     x20, x0                                    
02c8c6d8: bl      #0x452b8a0                                 fn_452b8a0
02c8c6dc: cbz     x20, #0x2c8c868                            
02c8c6e0: adrp    x8, #0x6265000                             
02c8c6e4: adrp    x9, #0x6265000                             
02c8c6e8: adrp    x21, #0x6265000                            
02c8c6ec: ldr     x8, [x8, #0x2c8]                           S:'ad_platform'
02c8c6f0: ldr     x9, [x9, #0x2f0]                           S:'appLovin'
02c8c6f4: ldr     x21, [x21, #0x2d8]                         MS:System.Collections.Generic.Dictionary`2::Add
02c8c6f8: adrp    x28, #0x6265000                            
02c8c6fc: adrp    x29, #0x6265000                            
02c8c700: adrp    x22, #0x6265000                            
02c8c704: adrp    x24, #0x6265000                            
02c8c708: adrp    x27, #0x6264000                            
02c8c70c: adrp    x26, #0x6265000                            
02c8c710: adrp    x25, #0x6265000                            
02c8c714: adrp    x23, #0x6265000                            
02c8c718: ldr     x28, [x28, #0x2a8]                         S:'ad_source'
02c8c71c: ldr     x29, [x29, #0x280]                         S:'ad_unit_name'
02c8c720: ldr     x22, [x22, #0x288]                         S:'ad_format'
02c8c724: ldr     x24, [x24, #0x208]                         S:'placement'
02c8c728: ldr     x27, [x27, #0xd90]                         S:'{0}'
02c8c72c: ldr     x26, [x26, #0x2a0]                         S:'value'
02c8c730: ldr     x25, [x25, #0x2b0]                         S:'currency'
02c8c734: ldr     x23, [x23, #0x2b8]                         S:'USD'
02c8c738: ldr     x1, [x8]                                   M:AdsManager::<OnApplicationPause>b__26_0
02c8c73c: ldr     x2, [x9]                                   M:AdsManager::<OnApplicationPause>b__26_0
02c8c740: ldr     x3, [x21]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c8c744: mov     x0, x20                                    
02c8c748: bl      #0x452c61c                                 fn_452c61c
02c8c74c: ldr     x2, [x19, #0x20]                           
02c8c750: ldr     x1, [x28]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c8c754: mov     x0, x20                                    
02c8c758: ldr     x3, [x21]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c8c75c: bl      #0x452c61c                                 fn_452c61c
02c8c760: ldr     x2, [x19, #0x10]                           
02c8c764: ldr     x1, [x29]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c8c768: mov     x0, x20                                    
02c8c76c: ldr     x3, [x21]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c8c770: bl      #0x452c61c                                 fn_452c61c
02c8c774: ldr     x2, [x19, #0x18]                           
02c8c778: ldr     x1, [x22]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c8c77c: mov     x0, x20                                    
02c8c780: ldr     x3, [x21]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c8c784: bl      #0x452c61c                                 fn_452c61c
02c8c788: ldr     x2, [x19, #0x30]                           
02c8c78c: ldr     x1, [x24]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c8c790: mov     x0, x20                                    
02c8c794: ldr     x3, [x21]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c8c798: bl      #0x452c61c                                 fn_452c61c
02c8c79c: adrp    x8, #0x6263000                             
02c8c7a0: add     x1, sp, #8                                 
02c8c7a4: ldr     x8, [x8, #0x970]                           &6645c70(=0)
02c8c7a8: str     d8, [sp, #8]                               
02c8c7ac: ldr     x0, [x8, #0x80]                            &2c498bc(=aa1f03e0d503245f)
02c8c7b0: bl      #0x2b70f38                                 fn_2b70f38
02c8c7b4: ldr     x8, [x27]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c8c7b8: mov     x1, x0                                     
02c8c7bc: mov     x2, xzr                                    
02c8c7c0: mov     x0, x8                                     
02c8c7c4: bl      #0x4c9d0ec                                 System.String::Format
02c8c7c8: ldr     x1, [x26]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c8c7cc: ldr     x3, [x21]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c8c7d0: mov     x2, x0                                     
02c8c7d4: mov     x0, x20                                    
02c8c7d8: bl      #0x452c61c                                 fn_452c61c
02c8c7dc: ldr     x1, [x25]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c8c7e0: ldr     x2, [x23]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c8c7e4: mov     x0, x20                                    
02c8c7e8: ldr     x3, [x21]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c8c7ec: bl      #0x452c61c                                 fn_452c61c
02c8c7f0: adrp    x8, #0x6265000                             
02c8c7f4: ldr     x21, [x19, #0x20]                          
02c8c7f8: ldr     x8, [x8, #0x2d0]                           T:AppsFlyerSDK.AFAdRevenueData
02c8c7fc: ldr     x0, [x8]                                   M:AdsManager::<OnApplicationPause>b__26_0
02c8c800: bl      #0x2b7104c                                 fn_2b7104c
02c8c804: fmov    d0, d8                                     
02c8c808: ldr     x3, [x23]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c8c80c: mov     x1, x21                                    
02c8c810: mov     w2, #3                                     
02c8c814: mov     x4, xzr                                    
02c8c818: mov     x19, x0                                    
02c8c81c: bl      #0x2c66b2c                                 AppsFlyerSDK.AFAdRevenueData::.ctor
02c8c820: adrp    x8, #0x6263000                             
02c8c824: ldr     x8, [x8, #0x900]                           T:AppsFlyerSDK.AppsFlyer
02c8c828: ldr     x0, [x8]                                   &2c5bbd4(=a9bd7bfdd503233f)
02c8c82c: ldr     w8, [x0, #0xe4]                            [62650e4]=0 f=0,0
02c8c830: cbnz    w8, #0x2c8c838                             
02c8c834: bl      #0x2b70f30                                 fn_2b70f30
02c8c838: mov     x0, x19                                    
02c8c83c: mov     x1, x20                                    
02c8c840: mov     x2, xzr                                    
02c8c844: bl      #0x2c67cf8                                 AppsFlyerSDK.AppsFlyer::logAdRevenue
02c8c848: ldp     x20, x19, [sp, #0x60]                      
02c8c84c: ldp     x22, x21, [sp, #0x50]                      
02c8c850: ldp     x24, x23, [sp, #0x40]                      
02c8c854: ldp     x26, x25, [sp, #0x30]                      
02c8c858: ldp     x28, x27, [sp, #0x20]                      
02c8c85c: ldp     x29, x30, [sp, #0x10]                      
02c8c860: ldr     d8, [sp], #0x70                            
02c8c864: ret                                                
02c8c868: bl      #0x2b7105c                                 fn_2b7105c
## LogAppsflyerAdmobRevenue(AdFormat adFormat, GoogleMobileAds.Api.AdValue adValue, object adObject, string placement) -> void
---- AnalyticsManager::LogAppsflyerAdmobRevenue 0x2c904f0
02c904f0: sub     sp, sp, #0x80                              
02c904f4: stp     d9, d8, [sp, #0x10]                        
02c904f8: stp     x29, x30, [sp, #0x20]                      
02c904fc: stp     x28, x27, [sp, #0x30]                      
02c90500: stp     x26, x25, [sp, #0x40]                      
02c90504: stp     x24, x23, [sp, #0x50]                      
02c90508: stp     x22, x21, [sp, #0x60]                      
02c9050c: stp     x20, x19, [sp, #0x70]                      
02c90510: adrp    x22, #0x662f000                            
02c90514: mov     x21, x3                                    
02c90518: mov     x20, x2                                    
02c9051c: ldrb    w8, [x22, #0xa52]                          
02c90520: mov     x19, x1                                    
02c90524: mov     w23, w0                                    
02c90528: tbnz    w8, #0, #0x2c905e8                         
02c9052c: adrp    x0, #0x6265000                             
02c90530: ldr     x0, [x0, #0x2d0]                           T:AppsFlyerSDK.AFAdRevenueData
02c90534: bl      #0x2b70db0                                 fn_2b70db0
02c90538: adrp    x0, #0x6265000                             
02c9053c: ldr     x0, [x0, #0x210]                           T:AdFormat
02c90540: bl      #0x2b70db0                                 fn_2b70db0
02c90544: adrp    x0, #0x6263000                             
02c90548: ldr     x0, [x0, #0x900]                           T:AppsFlyerSDK.AppsFlyer
02c9054c: bl      #0x2b70db0                                 fn_2b70db0
02c90550: adrp    x0, #0x6265000                             
02c90554: ldr     x0, [x0, #0x2d8]                           MS:System.Collections.Generic.Dictionary`2::Add
02c90558: bl      #0x2b70db0                                 fn_2b70db0
02c9055c: adrp    x0, #0x6265000                             
02c90560: ldr     x0, [x0, #0x2e0]                           MS:System.Collections.Generic.Dictionary`2::.ctor
02c90564: bl      #0x2b70db0                                 fn_2b70db0
02c90568: adrp    x0, #0x6265000                             
02c9056c: ldr     x0, [x0, #0x2e8]                           T:type8944(k15)
02c90570: bl      #0x2b70db0                                 fn_2b70db0
02c90574: adrp    x0, #0x6264000                             
02c90578: ldr     x0, [x0, #0xd90]                           S:'{0}'
02c9057c: bl      #0x2b70db0                                 fn_2b70db0
02c90580: adrp    x0, #0x6265000                             
02c90584: ldr     x0, [x0, #0x280]                           S:'ad_unit_name'
02c90588: bl      #0x2b70db0                                 fn_2b70db0
02c9058c: adrp    x0, #0x6265000                             
02c90590: ldr     x0, [x0, #0x288]                           S:'ad_format'
02c90594: bl      #0x2b70db0                                 fn_2b70db0
02c90598: adrp    x0, #0x6265000                             
02c9059c: ldr     x0, [x0, #0x2a0]                           S:'value'
02c905a0: bl      #0x2b70db0                                 fn_2b70db0
02c905a4: adrp    x0, #0x6265000                             
02c905a8: ldr     x0, [x0, #0x2a8]                           S:'ad_source'
02c905ac: bl      #0x2b70db0                                 fn_2b70db0
02c905b0: adrp    x0, #0x6265000                             
02c905b4: ldr     x0, [x0, #0x2b0]                           S:'currency'
02c905b8: bl      #0x2b70db0                                 fn_2b70db0
02c905bc: adrp    x0, #0x6265000                             
02c905c0: ldr     x0, [x0, #0x2b8]                           S:'USD'
02c905c4: bl      #0x2b70db0                                 fn_2b70db0
02c905c8: adrp    x0, #0x6265000                             
02c905cc: ldr     x0, [x0, #0x2c8]                           S:'ad_platform'
02c905d0: bl      #0x2b70db0                                 fn_2b70db0
02c905d4: adrp    x0, #0x6265000                             
02c905d8: ldr     x0, [x0, #0x208]                           S:'placement'
02c905dc: bl      #0x2b70db0                                 fn_2b70db0
02c905e0: mov     w8, #1                                     
02c905e4: strb    w8, [x22, #0xa52]                          
02c905e8: mov     x0, x20                                    
02c905ec: bl      #0x2c9bf4c                                 AnalyticsManager::GetAdInfo
02c905f0: cbz     x0, #0x2c90814                             
02c905f4: adrp    x8, #0x6265000                             
02c905f8: adrp    x20, #0x6265000                            
02c905fc: mov     x22, x0                                    
02c90600: ldr     x8, [x8, #0x2e8]                           T:type8944(k15)
02c90604: ldr     x20, [x20, #0x2e0]                         MS:System.Collections.Generic.Dictionary`2::.ctor
02c90608: ldr     x0, [x8]                                   M:AdsManager::<OnApplicationPause>b__26_0
02c9060c: bl      #0x2b7104c                                 fn_2b7104c
02c90610: ldr     x1, [x20]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c90614: mov     x20, x0                                    
02c90618: bl      #0x452b8a0                                 fn_452b8a0
02c9061c: mov     x0, x22                                    
02c90620: mov     x1, xzr                                    
02c90624: bl      #0x4c3f3ec                                 GoogleMobileAds.Api.ResponseInfo::GetMediationAdapterClassName
02c90628: cbz     x20, #0x2c90838                            
02c9062c: adrp    x8, #0x6265000                             
02c90630: adrp    x24, #0x6265000                            
02c90634: mov     x2, x0                                     
02c90638: ldr     x8, [x8, #0x2c8]                           S:'ad_platform'
02c9063c: ldr     x24, [x24, #0x2d8]                         MS:System.Collections.Generic.Dictionary`2::Add
02c90640: mov     x0, x20                                    
02c90644: ldr     x1, [x8]                                   M:AdsManager::<OnApplicationPause>b__26_0
02c90648: ldr     x3, [x24]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9064c: bl      #0x452c61c                                 fn_452c61c
02c90650: mov     x0, x22                                    
02c90654: mov     x1, xzr                                    
02c90658: bl      #0x4c3efbc                                 GoogleMobileAds.Api.ResponseInfo::GetLoadedAdapterResponseInfo
02c9065c: cbz     x0, #0x2c90838                             
02c90660: adrp    x27, #0x6265000                            
02c90664: adrp    x28, #0x6265000                            
02c90668: adrp    x29, #0x6265000                            
02c9066c: adrp    x25, #0x6264000                            
02c90670: adrp    x26, #0x6265000                            
02c90674: ldr     x27, [x27, #0x2a8]                         S:'ad_source'
02c90678: ldr     x28, [x28, #0x280]                         S:'ad_unit_name'
02c9067c: ldr     x29, [x29, #0x210]                         T:AdFormat
02c90680: ldr     x25, [x25, #0xd90]                         S:'{0}'
02c90684: ldr     x26, [x26, #0x288]                         S:'ad_format'
02c90688: mov     x1, xzr                                    
02c9068c: bl      #0x4c33d98                                 GoogleMobileAds.Api.AdapterResponseInfo::get_AdSourceName
02c90690: ldr     x1, [x27]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c90694: ldr     x3, [x24]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c90698: mov     x2, x0                                     
02c9069c: mov     x0, x20                                    
02c906a0: bl      #0x452c61c                                 fn_452c61c
02c906a4: mov     w0, w23                                    
02c906a8: bl      #0x2c8de38                                 KeyAds::Get
02c906ac: ldr     x1, [x28]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c906b0: ldr     x3, [x24]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c906b4: mov     x2, x0                                     
02c906b8: mov     x0, x20                                    
02c906bc: bl      #0x452c61c                                 fn_452c61c
02c906c0: ldr     x0, [x29]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c906c4: add     x1, sp, #0xc                               
02c906c8: str     w23, [sp, #0xc]                            
02c906cc: bl      #0x2b70f38                                 fn_2b70f38
02c906d0: ldr     x8, [x25]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c906d4: mov     x1, x0                                     
02c906d8: mov     x2, xzr                                    
02c906dc: mov     x0, x8                                     
02c906e0: bl      #0x4c9d0ec                                 System.String::Format
02c906e4: ldr     x1, [x26]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c906e8: ldr     x3, [x24]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c906ec: mov     x2, x0                                     
02c906f0: mov     x0, x20                                    
02c906f4: bl      #0x452c61c                                 fn_452c61c
02c906f8: adrp    x8, #0x6265000                             
02c906fc: mov     x0, x20                                    
02c90700: mov     x2, x21                                    
02c90704: ldr     x8, [x8, #0x208]                           S:'placement'
02c90708: ldr     x3, [x24]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9070c: ldr     x1, [x8]                                   M:AdsManager::<OnApplicationPause>b__26_0
02c90710: bl      #0x452c61c                                 fn_452c61c
02c90714: cbz     x19, #0x2c90838                            
02c90718: ldr     d0, [x19, #0x18]                           
02c9071c: adrp    x8, #0x1041000                             
02c90720: adrp    x21, #0x6265000                            
02c90724: ldr     d8, [x8, #0xb0]                            [10410b0]=412e848000000000 f=0,10.9073
02c90728: adrp    x8, #0x6263000                             
02c9072c: ldr     x21, [x21, #0x2a0]                         S:'value'
02c90730: scvtf   d0, d0                                     
02c90734: ldr     x8, [x8, #0x970]                           &6645c70(=0)
02c90738: adrp    x26, #0x6265000                            
02c9073c: adrp    x23, #0x6265000                            
02c90740: ldr     x26, [x26, #0x2b0]                         S:'currency'
02c90744: mov     x1, sp                                     
02c90748: ldr     x23, [x23, #0x2b8]                         S:'USD'
02c9074c: ldr     x0, [x8, #0x80]                            &2c498bc(=aa1f03e0d503245f)
02c90750: fdiv    d0, d0, d8                                 
02c90754: str     d0, [sp]                                   
02c90758: bl      #0x2b70f38                                 fn_2b70f38
02c9075c: ldr     x8, [x25]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c90760: mov     x1, x0                                     
02c90764: mov     x2, xzr                                    
02c90768: mov     x0, x8                                     
02c9076c: bl      #0x4c9d0ec                                 System.String::Format
02c90770: ldr     x1, [x21]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c90774: ldr     x3, [x24]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c90778: mov     x2, x0                                     
02c9077c: mov     x0, x20                                    
02c90780: bl      #0x452c61c                                 fn_452c61c
02c90784: ldr     x1, [x26]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c90788: ldr     x2, [x23]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9078c: mov     x0, x20                                    
02c90790: ldr     x3, [x24]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c90794: bl      #0x452c61c                                 fn_452c61c
02c90798: mov     x0, x22                                    
02c9079c: mov     x1, xzr                                    
02c907a0: bl      #0x4c3efbc                                 GoogleMobileAds.Api.ResponseInfo::GetLoadedAdapterResponseInfo
02c907a4: cbz     x0, #0x2c90838                             
02c907a8: adrp    x21, #0x6265000                            
02c907ac: adrp    x22, #0x6263000                            
02c907b0: mov     x1, xzr                                    
02c907b4: ldr     x21, [x21, #0x2d0]                         T:AppsFlyerSDK.AFAdRevenueData
02c907b8: ldr     x22, [x22, #0x900]                         T:AppsFlyerSDK.AppsFlyer
02c907bc: bl      #0x4c33d98                                 GoogleMobileAds.Api.AdapterResponseInfo::get_AdSourceName
02c907c0: ldr     x8, [x21]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c907c4: ldr     d9, [x19, #0x18]                           
02c907c8: mov     x21, x0                                    
02c907cc: mov     x0, x8                                     
02c907d0: bl      #0x2b7104c                                 fn_2b7104c
02c907d4: scvtf   d0, d9                                     
02c907d8: ldr     x3, [x23]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c907dc: mov     x1, x21                                    
02c907e0: mov     w2, #1                                     
02c907e4: mov     x4, xzr                                    
02c907e8: mov     x19, x0                                    
02c907ec: fdiv    d0, d0, d8                                 
02c907f0: bl      #0x2c66b2c                                 AppsFlyerSDK.AFAdRevenueData::.ctor
02c907f4: ldr     x0, [x22]                                  &2c5bbd4(=a9bd7bfdd503233f)
02c907f8: ldr     w8, [x0, #0xe4]                            [62650e4]=0 f=0,0
02c907fc: cbnz    w8, #0x2c90804                             
02c90800: bl      #0x2b70f30                                 fn_2b70f30
02c90804: mov     x0, x19                                    
02c90808: mov     x1, x20                                    
02c9080c: mov     x2, xzr                                    
02c90810: bl      #0x2c67cf8                                 AppsFlyerSDK.AppsFlyer::logAdRevenue
02c90814: ldp     x20, x19, [sp, #0x70]                      
02c90818: ldp     x22, x21, [sp, #0x60]                      
02c9081c: ldp     x24, x23, [sp, #0x50]                      
02c90820: ldp     x26, x25, [sp, #0x40]                      
02c90824: ldp     x28, x27, [sp, #0x30]                      
02c90828: ldp     x29, x30, [sp, #0x20]                      
02c9082c: ldp     d9, d8, [sp, #0x10]                        
02c90830: add     sp, sp, #0x80                              
02c90834: ret                                                
02c90838: bl      #0x2b7105c                                 fn_2b7105c
## LogAppsflyerAdmobRevenue(System.Collections.Generic.Dictionary`2<string,string> parameters, AdFormat adFormat, double revenue) -> void
---- AnalyticsManager::LogAppsflyerAdmobRevenue 0x2c993fc
02c993fc: sub     sp, sp, #0x80                              
02c99400: str     d8, [sp, #0x10]                            
02c99404: stp     x29, x30, [sp, #0x20]                      
02c99408: stp     x28, x27, [sp, #0x30]                      
02c9940c: stp     x26, x25, [sp, #0x40]                      
02c99410: stp     x24, x23, [sp, #0x50]                      
02c99414: stp     x22, x21, [sp, #0x60]                      
02c99418: stp     x20, x19, [sp, #0x70]                      
02c9941c: fmov    d8, d0                                     
02c99420: adrp    x22, #0x662f000                            
02c99424: adrp    x23, #0x6265000                            
02c99428: adrp    x20, #0x6265000                            
02c9942c: ldrb    w8, [x22, #0xa53]                          
02c99430: ldr     x23, [x23, #0x2e8]                         T:type8944(k15)
02c99434: ldr     x20, [x20, #0x2e0]                         MS:System.Collections.Generic.Dictionary`2::.ctor
02c99438: mov     w21, w1                                    
02c9943c: mov     x19, x0                                    
02c99440: tbnz    w8, #0, #0x2c994f4                         
02c99444: adrp    x0, #0x6265000                             
02c99448: ldr     x0, [x0, #0x2d0]                           T:AppsFlyerSDK.AFAdRevenueData
02c9944c: bl      #0x2b70db0                                 fn_2b70db0
02c99450: adrp    x0, #0x6265000                             
02c99454: ldr     x0, [x0, #0x210]                           T:AdFormat
02c99458: bl      #0x2b70db0                                 fn_2b70db0
02c9945c: adrp    x0, #0x6263000                             
02c99460: ldr     x0, [x0, #0x900]                           T:AppsFlyerSDK.AppsFlyer
02c99464: bl      #0x2b70db0                                 fn_2b70db0
02c99468: adrp    x0, #0x6265000                             
02c9946c: ldr     x0, [x0, #0x2d8]                           MS:System.Collections.Generic.Dictionary`2::Add
02c99470: bl      #0x2b70db0                                 fn_2b70db0
02c99474: adrp    x0, #0x6265000                             
02c99478: ldr     x0, [x0, #0x2e0]                           MS:System.Collections.Generic.Dictionary`2::.ctor
02c9947c: bl      #0x2b70db0                                 fn_2b70db0
02c99480: adrp    x0, #0x6265000                             
02c99484: ldr     x0, [x0, #0x9b8]                           MS:System.Collections.Generic.Dictionary`2::get_Item
02c99488: bl      #0x2b70db0                                 fn_2b70db0
02c9948c: adrp    x0, #0x6265000                             
02c99490: ldr     x0, [x0, #0x2e8]                           T:type8944(k15)
02c99494: bl      #0x2b70db0                                 fn_2b70db0
02c99498: adrp    x0, #0x6264000                             
02c9949c: ldr     x0, [x0, #0xd90]                           S:'{0}'
02c994a0: bl      #0x2b70db0                                 fn_2b70db0
02c994a4: adrp    x0, #0x6265000                             
02c994a8: ldr     x0, [x0, #0x280]                           S:'ad_unit_name'
02c994ac: bl      #0x2b70db0                                 fn_2b70db0
02c994b0: adrp    x0, #0x6265000                             
02c994b4: ldr     x0, [x0, #0x288]                           S:'ad_format'
02c994b8: bl      #0x2b70db0                                 fn_2b70db0
02c994bc: adrp    x0, #0x6265000                             
02c994c0: ldr     x0, [x0, #0x2a0]                           S:'value'
02c994c4: bl      #0x2b70db0                                 fn_2b70db0
02c994c8: adrp    x0, #0x6265000                             
02c994cc: ldr     x0, [x0, #0x2a8]                           S:'ad_source'
02c994d0: bl      #0x2b70db0                                 fn_2b70db0
02c994d4: adrp    x0, #0x6265000                             
02c994d8: ldr     x0, [x0, #0x2b0]                           S:'currency'
02c994dc: bl      #0x2b70db0                                 fn_2b70db0
02c994e0: adrp    x0, #0x6265000                             
02c994e4: ldr     x0, [x0, #0x2b8]                           S:'USD'
02c994e8: bl      #0x2b70db0                                 fn_2b70db0
02c994ec: mov     w8, #1                                     
02c994f0: strb    w8, [x22, #0xa53]                          
02c994f4: ldr     x0, [x23]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c994f8: bl      #0x2b7104c                                 fn_2b7104c
02c994fc: ldr     x1, [x20]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c99500: mov     x20, x0                                    
02c99504: bl      #0x452b8a0                                 fn_452b8a0
02c99508: cbz     x19, #0x2c996c4                            
02c9950c: adrp    x23, #0x6265000                            
02c99510: adrp    x24, #0x6265000                            
02c99514: mov     x0, x19                                    
02c99518: ldr     x23, [x23, #0x2a8]                         S:'ad_source'
02c9951c: ldr     x24, [x24, #0x9b8]                         MS:System.Collections.Generic.Dictionary`2::get_Item
02c99520: ldr     x1, [x23]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c99524: ldr     x2, [x24]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c99528: bl      #0x452c59c                                 fn_452c59c
02c9952c: cbz     x20, #0x2c996c4                            
02c99530: adrp    x27, #0x6265000                            
02c99534: adrp    x26, #0x6265000                            
02c99538: adrp    x28, #0x6265000                            
02c9953c: ldr     x27, [x27, #0x2d8]                         MS:System.Collections.Generic.Dictionary`2::Add
02c99540: adrp    x22, #0x6264000                            
02c99544: adrp    x29, #0x6265000                            
02c99548: adrp    x25, #0x6265000                            
02c9954c: ldr     x26, [x26, #0x280]                         S:'ad_unit_name'
02c99550: ldr     x28, [x28, #0x210]                         T:AdFormat
02c99554: ldr     x22, [x22, #0xd90]                         S:'{0}'
02c99558: ldr     x29, [x29, #0x288]                         S:'ad_format'
02c9955c: ldr     x25, [x25, #0x2b8]                         S:'USD'
02c99560: ldr     x1, [x23]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c99564: ldr     x3, [x27]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c99568: mov     x2, x0                                     
02c9956c: mov     x0, x20                                    
02c99570: bl      #0x452c61c                                 fn_452c61c
02c99574: ldr     x1, [x26]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c99578: ldr     x2, [x24]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9957c: mov     x0, x19                                    
02c99580: bl      #0x452c59c                                 fn_452c59c
02c99584: ldr     x1, [x26]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c99588: ldr     x3, [x27]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9958c: mov     x2, x0                                     
02c99590: mov     x0, x20                                    
02c99594: bl      #0x452c61c                                 fn_452c61c
02c99598: ldr     x0, [x28]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9959c: add     x1, sp, #0x1c                              
02c995a0: str     w21, [sp, #0x1c]                           
02c995a4: bl      #0x2b70f38                                 fn_2b70f38
02c995a8: ldr     x8, [x22]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c995ac: mov     x1, x0                                     
02c995b0: mov     x2, xzr                                    
02c995b4: mov     x0, x8                                     
02c995b8: bl      #0x4c9d0ec                                 System.String::Format
02c995bc: ldr     x1, [x29]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c995c0: ldr     x3, [x27]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c995c4: mov     x2, x0                                     
02c995c8: mov     x0, x20                                    
02c995cc: bl      #0x452c61c                                 fn_452c61c
02c995d0: adrp    x8, #0x6263000                             
02c995d4: add     x1, sp, #8                                 
02c995d8: ldr     x8, [x8, #0x970]                           &6645c70(=0)
02c995dc: str     d8, [sp, #8]                               
02c995e0: ldr     x0, [x8, #0x80]                            &2c498bc(=aa1f03e0d503245f)
02c995e4: bl      #0x2b70f38                                 fn_2b70f38
02c995e8: ldr     x8, [x22]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c995ec: mov     x1, x0                                     
02c995f0: mov     x2, xzr                                    
02c995f4: mov     x0, x8                                     
02c995f8: bl      #0x4c9d0ec                                 System.String::Format
02c995fc: adrp    x8, #0x6265000                             
02c99600: mov     x2, x0                                     
02c99604: mov     x0, x20                                    
02c99608: ldr     x8, [x8, #0x2a0]                           S:'value'
02c9960c: ldr     x3, [x27]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c99610: ldr     x1, [x8]                                   M:AdsManager::<OnApplicationPause>b__26_0
02c99614: bl      #0x452c61c                                 fn_452c61c
02c99618: adrp    x8, #0x6265000                             
02c9961c: mov     x0, x20                                    
02c99620: ldr     x8, [x8, #0x2b0]                           S:'currency'
02c99624: ldr     x2, [x25]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c99628: ldr     x3, [x27]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9962c: ldr     x1, [x8]                                   M:AdsManager::<OnApplicationPause>b__26_0
02c99630: bl      #0x452c61c                                 fn_452c61c
02c99634: ldr     x1, [x23]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c99638: ldr     x2, [x24]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9963c: mov     x0, x19                                    
02c99640: bl      #0x452c59c                                 fn_452c59c
02c99644: adrp    x8, #0x6265000                             
02c99648: mov     x21, x0                                    
02c9964c: ldr     x8, [x8, #0x2d0]                           T:AppsFlyerSDK.AFAdRevenueData
02c99650: ldr     x8, [x8]                                   M:AdsManager::<OnApplicationPause>b__26_0
02c99654: mov     x0, x8                                     
02c99658: bl      #0x2b7104c                                 fn_2b7104c
02c9965c: fmov    d0, d8                                     
02c99660: ldr     x3, [x25]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c99664: mov     x1, x21                                    
02c99668: mov     w2, #1                                     
02c9966c: mov     x4, xzr                                    
02c99670: mov     x19, x0                                    
02c99674: bl      #0x2c66b2c                                 AppsFlyerSDK.AFAdRevenueData::.ctor
02c99678: adrp    x8, #0x6263000                             
02c9967c: ldr     x8, [x8, #0x900]                           T:AppsFlyerSDK.AppsFlyer
02c99680: ldr     x0, [x8]                                   &2c5bbd4(=a9bd7bfdd503233f)
02c99684: ldr     w8, [x0, #0xe4]                            [62650e4]=0 f=0,0
02c99688: cbnz    w8, #0x2c99690                             
02c9968c: bl      #0x2b70f30                                 fn_2b70f30
02c99690: mov     x0, x19                                    
02c99694: mov     x1, x20                                    
02c99698: mov     x2, xzr                                    
02c9969c: bl      #0x2c67cf8                                 AppsFlyerSDK.AppsFlyer::logAdRevenue
02c996a0: ldp     x20, x19, [sp, #0x70]                      
02c996a4: ldr     d8, [sp, #0x10]                            
02c996a8: ldp     x22, x21, [sp, #0x60]                      
02c996ac: ldp     x24, x23, [sp, #0x50]                      
02c996b0: ldp     x26, x25, [sp, #0x40]                      
02c996b4: ldp     x28, x27, [sp, #0x30]                      
02c996b8: ldp     x29, x30, [sp, #0x20]                      
02c996bc: add     sp, sp, #0x80                              
02c996c0: ret                                                
02c996c4: bl      #0x2b7105c                                 fn_2b7105c
## LogAdjustApplovinRevenue(object temp) -> void
---- AnalyticsManager::LogAdjustApplovinRevenue 0x2c8c86c
02c8c86c: ret                                                
## LogAdjustAdmobRevenue(object adFormat, object adValue, object ad) -> void
---- AnalyticsManager::LogAdjustAdmobRevenue 0x2c9083c
02c9083c: ret                                                
## .ctor() -> void
---- AnalyticsManager::.ctor 0x2c9c0b8
02c9c0b8: stp     x30, x21, [sp, #-0x20]!                    
02c9c0bc: stp     x20, x19, [sp, #0x10]                      
02c9c0c0: adrp    x20, #0x662f000                            
02c9c0c4: adrp    x21, #0x6265000                            
02c9c0c8: mov     x19, x0                                    
02c9c0cc: ldrb    w8, [x20, #0xa54]                          
02c9c0d0: ldr     x21, [x21, #0xb30]                         MS:WejoyService.Singleton`1::.ctor
02c9c0d4: tbnz    w8, #0, #0x2c9c0ec                         
02c9c0d8: adrp    x0, #0x6265000                             
02c9c0dc: ldr     x0, [x0, #0xb30]                           MS:WejoyService.Singleton`1::.ctor
02c9c0e0: bl      #0x2b70db0                                 fn_2b70db0
02c9c0e4: mov     w8, #1                                     
02c9c0e8: strb    w8, [x20, #0xa54]                          
02c9c0ec: mov     x0, x19                                    
02c9c0f0: ldp     x20, x19, [sp, #0x10]                      
02c9c0f4: ldr     x1, [x21]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9c0f8: ldp     x30, x21, [sp], #0x20                      
02c9c0fc: b       #0x3be76dc                                 
