#### CLASS Framework.SeparatorAttribute parent= UnityEngine.PropertyAttribute
#   field title                          string                                             off=0x18 attr=26 
#   field withOffset                     bool                                               off=0x20 attr=26 
#   field colorIndex                     int                                                off=0x24 attr=26 
## .ctor(string title, bool withOffset, int colorIndex) -> void
---- Framework.SeparatorAttribute::.ctor 0x2cb849c
02cb849c: str     x30, [sp, #-0x30]!                         
02cb84a0: stp     x22, x21, [sp, #0x10]                      
02cb84a4: stp     x20, x19, [sp, #0x20]                      
02cb84a8: mov     x21, x1                                    
02cb84ac: mov     x1, xzr                                    
02cb84b0: mov     w19, w3                                    
02cb84b4: mov     w20, w2                                    
02cb84b8: mov     x22, x0                                    
02cb84bc: bl      #0x5b2d93c                                 UnityEngine.PropertyAttribute::.ctor
02cb84c0: str     x21, [x22, #0x18]!                         
02cb84c4: mov     x0, x22                                    
02cb84c8: mov     x1, x21                                    
02cb84cc: bl      #0x2b70d54                                 fn_2b70d54
02cb84d0: strb    w20, [x22, #8]                             
02cb84d4: str     w19, [x22, #0xc]                           
02cb84d8: ldp     x20, x19, [sp, #0x20]                      
02cb84dc: ldp     x22, x21, [sp, #0x10]                      
02cb84e0: ldr     x30, [sp], #0x30                           
02cb84e4: ret                                                
