#### CLASS IDataManager parent= None
##  GetAsset (no body)
##  GetData (no body)
