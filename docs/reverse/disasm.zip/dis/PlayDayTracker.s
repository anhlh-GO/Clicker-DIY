#### CLASS PlayDayTracker parent= object
#   field FirstDayPlayed                 string                                             off=0x0 attr=8051 
#   field LastDayPlayed                  string                                             off=0x0 attr=8051 
#   field TimePlayedCount                string                                             off=0x0 attr=8051 
#   field StreakDayCount                 string                                             off=0x0 attr=8051 
#   field DateFormat                     string                                             off=0x0 attr=31 
## get_Today() -> System.DateTime
---- PlayDayTracker::get_Today 0x2ca3c48
02ca3c48: str     x30, [sp, #-0x20]!                         
02ca3c4c: stp     x20, x19, [sp, #0x10]                      
02ca3c50: adrp    x20, #0x662f000                            
02ca3c54: adrp    x19, #0x6266000                            
02ca3c58: ldrb    w8, [x20, #0xac2]                          
02ca3c5c: ldr     x19, [x19, #0x128]                         T:System.DateTime
02ca3c60: tbnz    w8, #0, #0x2ca3c78                         
02ca3c64: adrp    x0, #0x6266000                             
02ca3c68: ldr     x0, [x0, #0x128]                           T:System.DateTime
02ca3c6c: bl      #0x2b70db0                                 fn_2b70db0
02ca3c70: mov     w8, #1                                     
02ca3c74: strb    w8, [x20, #0xac2]                          
02ca3c78: ldr     x0, [x19]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca3c7c: str     xzr, [sp, #8]                              
02ca3c80: ldr     w8, [x0, #0xe4]                            [62660e4]=0 f=0,0
02ca3c84: cbnz    w8, #0x2ca3c8c                             
02ca3c88: bl      #0x2b70f30                                 fn_2b70f30
02ca3c8c: mov     x0, xzr                                    
02ca3c90: bl      #0x4df25c8                                 System.DateTime::get_Now
02ca3c94: str     x0, [sp, #8]                               
02ca3c98: add     x0, sp, #8                                 
02ca3c9c: mov     x1, xzr                                    
02ca3ca0: bl      #0x4df1f38                                 System.DateTime::get_Date
02ca3ca4: ldp     x20, x19, [sp, #0x10]                      
02ca3ca8: ldr     x30, [sp], #0x20                           
02ca3cac: ret                                                
## GetReturnDays() -> int
---- PlayDayTracker::GetReturnDays 0x2ca3cb0
02ca3cb0: sub     sp, sp, #0x30                              
02ca3cb4: stp     x30, x21, [sp, #0x10]                      
02ca3cb8: stp     x20, x19, [sp, #0x20]                      
02ca3cbc: adrp    x19, #0x662f000                            
02ca3cc0: adrp    x20, #0x6266000                            
02ca3cc4: ldrb    w8, [x19, #0xac3]                          
02ca3cc8: ldr     x20, [x20, #0x130]                         S:'FirstDayPlayed'
02ca3ccc: tbnz    w8, #0, #0x2ca3d08                         
02ca3cd0: adrp    x0, #0x6266000                             
02ca3cd4: ldr     x0, [x0, #0x128]                           T:System.DateTime
02ca3cd8: bl      #0x2b70db0                                 fn_2b70db0
02ca3cdc: adrp    x0, #0x6266000                             
02ca3ce0: ldr     x0, [x0, #0x138]                           T:PlayDayTracker
02ca3ce4: bl      #0x2b70db0                                 fn_2b70db0
02ca3ce8: adrp    x0, #0x6265000                             
02ca3cec: ldr     x0, [x0, #0xf98]                           T:System.TimeSpan
02ca3cf0: bl      #0x2b70db0                                 fn_2b70db0
02ca3cf4: adrp    x0, #0x6266000                             
02ca3cf8: ldr     x0, [x0, #0x130]                           S:'FirstDayPlayed'
02ca3cfc: bl      #0x2b70db0                                 fn_2b70db0
02ca3d00: mov     w8, #1                                     
02ca3d04: strb    w8, [x19, #0xac3]                          
02ca3d08: adrp    x21, #0x6266000                            
02ca3d0c: adrp    x19, #0x6266000                            
02ca3d10: mov     x1, xzr                                    
02ca3d14: ldr     x21, [x21, #0x138]                         T:PlayDayTracker
02ca3d18: ldr     x19, [x19, #0x128]                         T:System.DateTime
02ca3d1c: ldr     x0, [x20]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca3d20: stp     xzr, xzr, [sp]                             
02ca3d24: bl      #0x5b2d73c                                 UnityEngine.PlayerPrefs::HasKey
02ca3d28: tbz     w0, #0, #0x2ca3db4                         
02ca3d2c: ldr     x0, [x20]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca3d30: mov     x1, xzr                                    
02ca3d34: bl      #0x5b2d6f4                                 UnityEngine.PlayerPrefs::GetString
02ca3d38: ldr     x8, [x19]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca3d3c: mov     x19, x0                                    
02ca3d40: ldr     w9, [x8, #0xe4]                            
02ca3d44: cbnz    w9, #0x2ca3d50                             
02ca3d48: mov     x0, x8                                     
02ca3d4c: bl      #0x2b70f30                                 fn_2b70f30
02ca3d50: adrp    x20, #0x6265000                            
02ca3d54: mov     x0, x19                                    
02ca3d58: mov     x1, xzr                                    
02ca3d5c: ldr     x20, [x20, #0xf98]                         T:System.TimeSpan
02ca3d60: bl      #0x4df2914                                 System.DateTime::Parse
02ca3d64: ldr     x8, [x21]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca3d68: mov     x19, x0                                    
02ca3d6c: ldr     w9, [x8, #0xe4]                            
02ca3d70: cbnz    w9, #0x2ca3d7c                             
02ca3d74: mov     x0, x8                                     
02ca3d78: bl      #0x2b70f30                                 fn_2b70f30
02ca3d7c: bl      #0x2ca3c48                                 PlayDayTracker::get_Today
02ca3d80: mov     x1, x19                                    
02ca3d84: mov     x2, xzr                                    
02ca3d88: bl      #0x4df3fb4                                 System.DateTime::op_Subtraction
02ca3d8c: ldr     x8, [x20]                                  M:AdsManager::<OnApplicationPause>b__26_0
02ca3d90: str     x0, [sp]                                   
02ca3d94: ldr     w9, [x8, #0xe4]                            
02ca3d98: cbnz    w9, #0x2ca3da4                             
02ca3d9c: mov     x0, x8                                     
02ca3da0: bl      #0x2b70f30                                 fn_2b70f30
02ca3da4: mov     x0, sp                                     
02ca3da8: mov     x1, xzr                                    
02ca3dac: bl      #0x4e292b8                                 System.TimeSpan::get_Days
02ca3db0: b       #0x2ca3e1c                                 
02ca3db4: ldr     x0, [x21]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca3db8: ldr     w8, [x0, #0xe4]                            [62660e4]=0 f=0,0
02ca3dbc: cbnz    w8, #0x2ca3dc4                             
02ca3dc0: bl      #0x2b70f30                                 fn_2b70f30
02ca3dc4: bl      #0x2ca3c48                                 PlayDayTracker::get_Today
02ca3dc8: ldr     x9, [x21]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca3dcc: mov     x8, x0                                     
02ca3dd0: ldr     x0, [x19]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca3dd4: str     x8, [sp, #8]                               
02ca3dd8: ldr     x9, [x9, #0xb8]                            
02ca3ddc: ldr     w8, [x0, #0xe4]                            [62660e4]=0 f=0,0
02ca3de0: ldr     x19, [x9]                                  
02ca3de4: cbnz    w8, #0x2ca3dec                             
02ca3de8: bl      #0x2b70f30                                 fn_2b70f30
02ca3dec: add     x0, sp, #8                                 
02ca3df0: mov     x1, x19                                    
02ca3df4: mov     x2, xzr                                    
02ca3df8: bl      #0x4df35b0                                 System.DateTime::ToString
02ca3dfc: ldr     x8, [x20]                                  M:AdsManager::<OnApplicationPause>b__26_0
02ca3e00: mov     x1, x0                                     
02ca3e04: mov     x2, xzr                                    
02ca3e08: mov     x0, x8                                     
02ca3e0c: bl      #0x5b2d398                                 UnityEngine.PlayerPrefs::SetString
02ca3e10: mov     x0, xzr                                    
02ca3e14: bl      #0x5b2d914                                 UnityEngine.PlayerPrefs::Save
02ca3e18: mov     w0, wzr                                    
02ca3e1c: ldp     x20, x19, [sp, #0x20]                      
02ca3e20: ldp     x30, x21, [sp, #0x10]                      
02ca3e24: add     sp, sp, #0x30                              
02ca3e28: ret                                                
## GetPlayedDays() -> int
---- PlayDayTracker::GetPlayedDays 0x2ca3e2c
02ca3e2c: str     x30, [sp, #-0x40]!                         
02ca3e30: stp     x24, x23, [sp, #0x10]                      
02ca3e34: stp     x22, x21, [sp, #0x20]                      
02ca3e38: stp     x20, x19, [sp, #0x30]                      
02ca3e3c: adrp    x19, #0x662f000                            
02ca3e40: adrp    x21, #0x6266000                            
02ca3e44: ldrb    w8, [x19, #0xac4]                          
02ca3e48: ldr     x21, [x21, #0x140]                         S:'LastDayPlayed'
02ca3e4c: tbnz    w8, #0, #0x2ca3e88                         
02ca3e50: adrp    x0, #0x6266000                             
02ca3e54: ldr     x0, [x0, #0x128]                           T:System.DateTime
02ca3e58: bl      #0x2b70db0                                 fn_2b70db0
02ca3e5c: adrp    x0, #0x6266000                             
02ca3e60: ldr     x0, [x0, #0x138]                           T:PlayDayTracker
02ca3e64: bl      #0x2b70db0                                 fn_2b70db0
02ca3e68: adrp    x0, #0x6266000                             
02ca3e6c: ldr     x0, [x0, #0x140]                           S:'LastDayPlayed'
02ca3e70: bl      #0x2b70db0                                 fn_2b70db0
02ca3e74: adrp    x0, #0x6266000                             
02ca3e78: ldr     x0, [x0, #0x148]                           S:'TimePlayedCount'
02ca3e7c: bl      #0x2b70db0                                 fn_2b70db0
02ca3e80: mov     w8, #1                                     
02ca3e84: strb    w8, [x19, #0xac4]                          
02ca3e88: adrp    x24, #0x6266000                            
02ca3e8c: adrp    x23, #0x6266000                            
02ca3e90: adrp    x22, #0x6266000                            
02ca3e94: ldr     x24, [x24, #0x138]                         T:PlayDayTracker
02ca3e98: ldr     x23, [x23, #0x128]                         T:System.DateTime
02ca3e9c: ldr     x22, [x22, #0x148]                         S:'TimePlayedCount'
02ca3ea0: ldr     x0, [x21]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca3ea4: mov     x1, xzr                                    
02ca3ea8: str     xzr, [sp, #8]                              
02ca3eac: bl      #0x5b2d73c                                 UnityEngine.PlayerPrefs::HasKey
02ca3eb0: tbz     w0, #0, #0x2ca3fa0                         
02ca3eb4: ldr     x0, [x21]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca3eb8: mov     x1, xzr                                    
02ca3ebc: bl      #0x5b2d6f4                                 UnityEngine.PlayerPrefs::GetString
02ca3ec0: ldr     x8, [x23]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca3ec4: mov     x19, x0                                    
02ca3ec8: ldr     w9, [x8, #0xe4]                            
02ca3ecc: cbnz    w9, #0x2ca3ed8                             
02ca3ed0: mov     x0, x8                                     
02ca3ed4: bl      #0x2b70f30                                 fn_2b70f30
02ca3ed8: mov     x0, x19                                    
02ca3edc: mov     x1, xzr                                    
02ca3ee0: bl      #0x4df2914                                 System.DateTime::Parse
02ca3ee4: ldr     x8, [x24]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca3ee8: mov     x19, x0                                    
02ca3eec: ldr     w9, [x8, #0xe4]                            
02ca3ef0: cbnz    w9, #0x2ca3efc                             
02ca3ef4: mov     x0, x8                                     
02ca3ef8: bl      #0x2b70f30                                 fn_2b70f30
02ca3efc: bl      #0x2ca3c48                                 PlayDayTracker::get_Today
02ca3f00: mov     x1, x19                                    
02ca3f04: mov     x2, xzr                                    
02ca3f08: bl      #0x4df41c4                                 System.DateTime::op_GreaterThan
02ca3f0c: ldr     x8, [x22]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca3f10: mov     w20, w0                                    
02ca3f14: mov     w1, #1                                     
02ca3f18: mov     x2, xzr                                    
02ca3f1c: mov     x0, x8                                     
02ca3f20: bl      #0x5b2d1dc                                 UnityEngine.PlayerPrefs::GetInt
02ca3f24: mov     w19, w0                                    
02ca3f28: tbz     w20, #0, #0x2ca4018                        
02ca3f2c: ldr     x0, [x22]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca3f30: add     w19, w19, #1                               
02ca3f34: mov     x2, xzr                                    
02ca3f38: mov     w1, w19                                    
02ca3f3c: bl      #0x5b2d184                                 UnityEngine.PlayerPrefs::SetInt
02ca3f40: ldr     x0, [x24]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca3f44: ldr     w8, [x0, #0xe4]                            [62660e4]=0 f=0,0
02ca3f48: cbnz    w8, #0x2ca3f50                             
02ca3f4c: bl      #0x2b70f30                                 fn_2b70f30
02ca3f50: bl      #0x2ca3c48                                 PlayDayTracker::get_Today
02ca3f54: ldr     x9, [x24]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca3f58: mov     x8, x0                                     
02ca3f5c: ldr     x0, [x23]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca3f60: str     x8, [sp, #8]                               
02ca3f64: ldr     x9, [x9, #0xb8]                            
02ca3f68: ldr     w8, [x0, #0xe4]                            [62660e4]=0 f=0,0
02ca3f6c: ldr     x20, [x9]                                  
02ca3f70: cbnz    w8, #0x2ca3f78                             
02ca3f74: bl      #0x2b70f30                                 fn_2b70f30
02ca3f78: add     x0, sp, #8                                 
02ca3f7c: mov     x1, x20                                    
02ca3f80: mov     x2, xzr                                    
02ca3f84: bl      #0x4df35b0                                 System.DateTime::ToString
02ca3f88: ldr     x8, [x21]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca3f8c: mov     x1, x0                                     
02ca3f90: mov     x2, xzr                                    
02ca3f94: mov     x0, x8                                     
02ca3f98: bl      #0x5b2d398                                 UnityEngine.PlayerPrefs::SetString
02ca3f9c: b       #0x2ca4010                                 
02ca3fa0: ldr     x0, [x24]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca3fa4: ldr     w8, [x0, #0xe4]                            [62660e4]=0 f=0,0
02ca3fa8: cbnz    w8, #0x2ca3fb0                             
02ca3fac: bl      #0x2b70f30                                 fn_2b70f30
02ca3fb0: bl      #0x2ca3c48                                 PlayDayTracker::get_Today
02ca3fb4: ldr     x9, [x24]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca3fb8: mov     x8, x0                                     
02ca3fbc: ldr     x0, [x23]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca3fc0: str     x8, [sp, #8]                               
02ca3fc4: ldr     x9, [x9, #0xb8]                            
02ca3fc8: ldr     w8, [x0, #0xe4]                            [62660e4]=0 f=0,0
02ca3fcc: ldr     x19, [x9]                                  
02ca3fd0: cbnz    w8, #0x2ca3fd8                             
02ca3fd4: bl      #0x2b70f30                                 fn_2b70f30
02ca3fd8: add     x0, sp, #8                                 
02ca3fdc: mov     x1, x19                                    
02ca3fe0: mov     x2, xzr                                    
02ca3fe4: bl      #0x4df35b0                                 System.DateTime::ToString
02ca3fe8: ldr     x8, [x21]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca3fec: mov     x1, x0                                     
02ca3ff0: mov     x2, xzr                                    
02ca3ff4: mov     x0, x8                                     
02ca3ff8: bl      #0x5b2d398                                 UnityEngine.PlayerPrefs::SetString
02ca3ffc: ldr     x0, [x22]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca4000: mov     w1, #1                                     
02ca4004: mov     x2, xzr                                    
02ca4008: mov     w19, #1                                    
02ca400c: bl      #0x5b2d184                                 UnityEngine.PlayerPrefs::SetInt
02ca4010: mov     x0, xzr                                    
02ca4014: bl      #0x5b2d914                                 UnityEngine.PlayerPrefs::Save
02ca4018: mov     w0, w19                                    
02ca401c: ldp     x20, x19, [sp, #0x30]                      
02ca4020: ldp     x22, x21, [sp, #0x20]                      
02ca4024: ldp     x24, x23, [sp, #0x10]                      
02ca4028: ldr     x30, [sp], #0x40                           
02ca402c: ret                                                
## GetStreakDay() -> int
---- PlayDayTracker::GetStreakDay 0x2ca4030
02ca4030: sub     sp, sp, #0x50                              
02ca4034: str     x30, [sp, #0x10]                           
02ca4038: stp     x24, x23, [sp, #0x20]                      
02ca403c: stp     x22, x21, [sp, #0x30]                      
02ca4040: stp     x20, x19, [sp, #0x40]                      
02ca4044: adrp    x19, #0x662f000                            
02ca4048: adrp    x22, #0x6266000                            
02ca404c: adrp    x21, #0x6266000                            
02ca4050: ldrb    w8, [x19, #0xac5]                          
02ca4054: ldr     x22, [x22, #0x150]                         S:'StreakDayCount'
02ca4058: ldr     x21, [x21, #0x140]                         S:'LastDayPlayed'
02ca405c: tbnz    w8, #0, #0x2ca4098                         
02ca4060: adrp    x0, #0x6266000                             
02ca4064: ldr     x0, [x0, #0x128]                           T:System.DateTime
02ca4068: bl      #0x2b70db0                                 fn_2b70db0
02ca406c: adrp    x0, #0x6266000                             
02ca4070: ldr     x0, [x0, #0x138]                           T:PlayDayTracker
02ca4074: bl      #0x2b70db0                                 fn_2b70db0
02ca4078: adrp    x0, #0x6266000                             
02ca407c: ldr     x0, [x0, #0x140]                           S:'LastDayPlayed'
02ca4080: bl      #0x2b70db0                                 fn_2b70db0
02ca4084: adrp    x0, #0x6266000                             
02ca4088: ldr     x0, [x0, #0x150]                           S:'StreakDayCount'
02ca408c: bl      #0x2b70db0                                 fn_2b70db0
02ca4090: mov     w8, #1                                     
02ca4094: strb    w8, [x19, #0xac5]                          
02ca4098: adrp    x24, #0x6266000                            
02ca409c: adrp    x23, #0x6266000                            
02ca40a0: mov     w1, wzr                                    
02ca40a4: ldr     x24, [x24, #0x138]                         T:PlayDayTracker
02ca40a8: ldr     x23, [x23, #0x128]                         T:System.DateTime
02ca40ac: ldr     x0, [x22]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca40b0: mov     x2, xzr                                    
02ca40b4: str     xzr, [sp, #0x18]                           
02ca40b8: str     xzr, [sp, #8]                              
02ca40bc: bl      #0x5b2d1dc                                 UnityEngine.PlayerPrefs::GetInt
02ca40c0: ldr     x8, [x21]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca40c4: mov     w19, w0                                    
02ca40c8: mov     x1, xzr                                    
02ca40cc: mov     x0, x8                                     
02ca40d0: bl      #0x5b2d73c                                 UnityEngine.PlayerPrefs::HasKey
02ca40d4: tbz     w0, #0, #0x2ca4190                         
02ca40d8: ldr     x0, [x21]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca40dc: mov     x1, xzr                                    
02ca40e0: bl      #0x5b2d6f4                                 UnityEngine.PlayerPrefs::GetString
02ca40e4: ldr     x8, [x23]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca40e8: mov     x20, x0                                    
02ca40ec: ldr     w9, [x8, #0xe4]                            
02ca40f0: cbnz    w9, #0x2ca40fc                             
02ca40f4: mov     x0, x8                                     
02ca40f8: bl      #0x2b70f30                                 fn_2b70f30
02ca40fc: mov     x0, x20                                    
02ca4100: mov     x1, xzr                                    
02ca4104: bl      #0x4df2914                                 System.DateTime::Parse
02ca4108: ldr     x8, [x24]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca410c: mov     x20, x0                                    
02ca4110: str     x0, [sp, #0x18]                            
02ca4114: ldr     w9, [x8, #0xe4]                            
02ca4118: cbnz    w9, #0x2ca4124                             
02ca411c: mov     x0, x8                                     
02ca4120: bl      #0x2b70f30                                 fn_2b70f30
02ca4124: bl      #0x2ca3c48                                 PlayDayTracker::get_Today
02ca4128: mov     x1, x20                                    
02ca412c: mov     x2, xzr                                    
02ca4130: bl      #0x4df401c                                 System.DateTime::op_Equality
02ca4134: tbnz    w0, #0, #0x2ca42cc                         
02ca4138: ldr     x0, [x24]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca413c: ldr     w8, [x0, #0xe4]                            [62660e4]=0 f=0,0
02ca4140: cbnz    w8, #0x2ca4148                             
02ca4144: bl      #0x2b70f30                                 fn_2b70f30
02ca4148: bl      #0x2ca3c48                                 PlayDayTracker::get_Today
02ca414c: ldr     x8, [x23]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca4150: mov     x20, x0                                    
02ca4154: ldr     w9, [x8, #0xe4]                            
02ca4158: cbnz    w9, #0x2ca4164                             
02ca415c: mov     x0, x8                                     
02ca4160: bl      #0x2b70f30                                 fn_2b70f30
02ca4164: fmov    d0, #1.00000000                            
02ca4168: add     x0, sp, #0x18                              
02ca416c: mov     x1, xzr                                    
02ca4170: bl      #0x4df0f9c                                 System.DateTime::AddDays
02ca4174: mov     x1, x0                                     
02ca4178: mov     x0, x20                                    
02ca417c: mov     x2, xzr                                    
02ca4180: bl      #0x4df401c                                 System.DateTime::op_Equality
02ca4184: tbz     w0, #0, #0x2ca4204                         
02ca4188: add     w19, w19, #1                               
02ca418c: b       #0x2ca4258                                 
02ca4190: ldr     x0, [x24]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca4194: ldr     w8, [x0, #0xe4]                            [62660e4]=0 f=0,0
02ca4198: cbnz    w8, #0x2ca41a0                             
02ca419c: bl      #0x2b70f30                                 fn_2b70f30
02ca41a0: bl      #0x2ca3c48                                 PlayDayTracker::get_Today
02ca41a4: ldr     x9, [x24]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca41a8: mov     x8, x0                                     
02ca41ac: ldr     x0, [x23]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca41b0: str     x8, [sp, #8]                               
02ca41b4: ldr     x9, [x9, #0xb8]                            
02ca41b8: ldr     w8, [x0, #0xe4]                            [62660e4]=0 f=0,0
02ca41bc: ldr     x19, [x9]                                  
02ca41c0: cbnz    w8, #0x2ca41c8                             
02ca41c4: bl      #0x2b70f30                                 fn_2b70f30
02ca41c8: add     x0, sp, #8                                 
02ca41cc: mov     x1, x19                                    
02ca41d0: mov     x2, xzr                                    
02ca41d4: bl      #0x4df35b0                                 System.DateTime::ToString
02ca41d8: ldr     x8, [x21]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca41dc: mov     x1, x0                                     
02ca41e0: mov     x2, xzr                                    
02ca41e4: mov     x0, x8                                     
02ca41e8: bl      #0x5b2d398                                 UnityEngine.PlayerPrefs::SetString
02ca41ec: ldr     x0, [x22]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca41f0: mov     w1, #1                                     
02ca41f4: mov     x2, xzr                                    
02ca41f8: mov     w19, #1                                    
02ca41fc: bl      #0x5b2d184                                 UnityEngine.PlayerPrefs::SetInt
02ca4200: b       #0x2ca42c4                                 
02ca4204: ldr     x0, [x24]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca4208: ldr     w8, [x0, #0xe4]                            [62660e4]=0 f=0,0
02ca420c: cbnz    w8, #0x2ca4214                             
02ca4210: bl      #0x2b70f30                                 fn_2b70f30
02ca4214: bl      #0x2ca3c48                                 PlayDayTracker::get_Today
02ca4218: ldr     x8, [x23]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca421c: mov     x20, x0                                    
02ca4220: ldr     w9, [x8, #0xe4]                            
02ca4224: cbnz    w9, #0x2ca4230                             
02ca4228: mov     x0, x8                                     
02ca422c: bl      #0x2b70f30                                 fn_2b70f30
02ca4230: fmov    d0, #1.00000000                            
02ca4234: add     x0, sp, #0x18                              
02ca4238: mov     x1, xzr                                    
02ca423c: bl      #0x4df0f9c                                 System.DateTime::AddDays
02ca4240: mov     x1, x0                                     
02ca4244: mov     x0, x20                                    
02ca4248: mov     x2, xzr                                    
02ca424c: bl      #0x4df41c4                                 System.DateTime::op_GreaterThan
02ca4250: tst     w0, #1                                     
02ca4254: csinc   w19, w19, wzr, eq                          
02ca4258: ldr     x0, [x22]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca425c: mov     w1, w19                                    
02ca4260: mov     x2, xzr                                    
02ca4264: bl      #0x5b2d184                                 UnityEngine.PlayerPrefs::SetInt
02ca4268: ldr     x0, [x24]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca426c: ldr     w8, [x0, #0xe4]                            [62660e4]=0 f=0,0
02ca4270: cbnz    w8, #0x2ca4278                             
02ca4274: bl      #0x2b70f30                                 fn_2b70f30
02ca4278: bl      #0x2ca3c48                                 PlayDayTracker::get_Today
02ca427c: ldr     x9, [x24]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca4280: mov     x8, x0                                     
02ca4284: ldr     x0, [x23]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca4288: str     x8, [sp, #8]                               
02ca428c: ldr     x9, [x9, #0xb8]                            
02ca4290: ldr     w8, [x0, #0xe4]                            [62660e4]=0 f=0,0
02ca4294: ldr     x20, [x9]                                  
02ca4298: cbnz    w8, #0x2ca42a0                             
02ca429c: bl      #0x2b70f30                                 fn_2b70f30
02ca42a0: add     x0, sp, #8                                 
02ca42a4: mov     x1, x20                                    
02ca42a8: mov     x2, xzr                                    
02ca42ac: bl      #0x4df35b0                                 System.DateTime::ToString
02ca42b0: ldr     x8, [x21]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca42b4: mov     x1, x0                                     
02ca42b8: mov     x2, xzr                                    
02ca42bc: mov     x0, x8                                     
02ca42c0: bl      #0x5b2d398                                 UnityEngine.PlayerPrefs::SetString
02ca42c4: mov     x0, xzr                                    
02ca42c8: bl      #0x5b2d914                                 UnityEngine.PlayerPrefs::Save
02ca42cc: mov     w0, w19                                    
02ca42d0: ldp     x20, x19, [sp, #0x40]                      
02ca42d4: ldp     x22, x21, [sp, #0x30]                      
02ca42d8: ldr     x30, [sp, #0x10]                           
02ca42dc: ldp     x24, x23, [sp, #0x20]                      
02ca42e0: add     sp, sp, #0x50                              
02ca42e4: ret                                                
## .cctor() -> void
---- PlayDayTracker::.cctor 0x2ca42e8
02ca42e8: stp     x30, x21, [sp, #-0x20]!                    
02ca42ec: stp     x20, x19, [sp, #0x10]                      
02ca42f0: adrp    x21, #0x662f000                            
02ca42f4: adrp    x20, #0x6266000                            
02ca42f8: adrp    x19, #0x6266000                            
02ca42fc: ldrb    w8, [x21, #0xac6]                          
02ca4300: ldr     x20, [x20, #0x158]                         S:'yyyy-MM-dd'
02ca4304: ldr     x19, [x19, #0x138]                         T:PlayDayTracker
02ca4308: tbnz    w8, #0, #0x2ca432c                         
02ca430c: adrp    x0, #0x6266000                             
02ca4310: ldr     x0, [x0, #0x138]                           T:PlayDayTracker
02ca4314: bl      #0x2b70db0                                 fn_2b70db0
02ca4318: adrp    x0, #0x6266000                             
02ca431c: ldr     x0, [x0, #0x158]                           S:'yyyy-MM-dd'
02ca4320: bl      #0x2b70db0                                 fn_2b70db0
02ca4324: mov     w8, #1                                     
02ca4328: strb    w8, [x21, #0xac6]                          
02ca432c: ldr     x8, [x19]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca4330: ldr     x1, [x20]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca4334: ldr     x8, [x8, #0xb8]                            
02ca4338: str     x1, [x8]                                   
02ca433c: ldr     x8, [x19]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca4340: ldp     x20, x19, [sp, #0x10]                      
02ca4344: ldr     x0, [x8, #0xb8]                            
02ca4348: ldp     x30, x21, [sp], #0x20                      
02ca434c: b       #0x2b70d54                                 
