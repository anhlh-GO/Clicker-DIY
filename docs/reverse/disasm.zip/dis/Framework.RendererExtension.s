#### CLASS Framework.RendererExtension parent= object
## IsVisibleFromCamera(UnityEngine.Renderer renderer, UnityEngine.Camera camera) -> bool
---- Framework.RendererExtension::IsVisibleFromCamera 0x2cb9854
02cb9854: sub     sp, sp, #0x50                              
02cb9858: str     x30, [sp, #0x30]                           
02cb985c: stp     x20, x19, [sp, #0x40]                      
02cb9860: mov     x20, x0                                    
02cb9864: mov     x0, x1                                     
02cb9868: mov     x1, xzr                                    
02cb986c: bl      #0x5af69f0                                 UnityEngine.GeometryUtility::CalculateFrustumPlanes
02cb9870: cbz     x20, #0x2cb9928                            
02cb9874: mov     x19, x0                                    
02cb9878: add     x8, sp, #0x18                              
02cb987c: mov     x0, x20                                    
02cb9880: mov     x1, xzr                                    
02cb9884: bl      #0x5b02028                                 UnityEngine.Renderer::get_bounds
02cb9888: adrp    x20, #0x662f000                            
02cb988c: ldur    q0, [sp, #0x18]                            
02cb9890: ldr     x8, [sp, #0x28]                            
02cb9894: ldrb    w9, [x20, #0xca3]                          
02cb9898: str     q0, [sp]                                   
02cb989c: str     x8, [sp, #0x10]                            
02cb98a0: cbnz    w9, #0x2cb98c4                             
02cb98a4: adrp    x0, #0x6266000                             
02cb98a8: ldr     x0, [x0, #0xe90]                           MS:System.MemoryExtensions::AsSpan
02cb98ac: bl      #0x2b70db0                                 fn_2b70db0
02cb98b0: adrp    x0, #0x6266000                             
02cb98b4: ldr     x0, [x0, #0xe98]                           MS:System.Span`1::op_Implicit
02cb98b8: bl      #0x2b70db0                                 fn_2b70db0
02cb98bc: mov     w8, #1                                     
02cb98c0: strb    w8, [x20, #0xca3]                          
02cb98c4: adrp    x8, #0x6266000                             
02cb98c8: ldr     x8, [x8, #0xe90]                           MS:System.MemoryExtensions::AsSpan
02cb98cc: ldr     x0, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cb98d0: ldr     x8, [x0, #0x38]                            S:'native_collap_id'
02cb98d4: cbz     x8, #0x2cb98e8                             
02cb98d8: cbz     x19, #0x2cb98f0                            
02cb98dc: ldr     w1, [x19, #0x18]                           
02cb98e0: add     x0, x19, #0x20                             
02cb98e4: b       #0x2cb98f8                                 
02cb98e8: bl      #0x2ba9d7c                                 fn_2ba9d7c
02cb98ec: cbnz    x19, #0x2cb98dc                            
02cb98f0: mov     x0, xzr                                    
02cb98f4: mov     x1, xzr                                    
02cb98f8: adrp    x8, #0x6266000                             
02cb98fc: ldr     x8, [x8, #0xe98]                           MS:System.Span`1::op_Implicit
02cb9900: ldr     x2, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cb9904: bl      #0x3c3ba14                                 fn_3c3ba14
02cb9908: mov     x2, sp                                     
02cb990c: mov     x3, xzr                                    
02cb9910: bl      #0x5af6e98                                 UnityEngine.GeometryUtility::Internal_TestPlanesAABB
02cb9914: ldp     x20, x19, [sp, #0x40]                      
02cb9918: and     w0, w0, #1                                 
02cb991c: ldr     x30, [sp, #0x30]                           
02cb9920: add     sp, sp, #0x50                              
02cb9924: ret                                                
02cb9928: bl      #0x2b7105c                                 fn_2b7105c
