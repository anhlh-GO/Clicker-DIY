#### CLASS FsnAd parent= object
#   field androidFsnAd                   UnityEngine.AndroidJavaObject                      off=0x10 attr=1 
#   field onFsnLoadListener              AndroidOnFsnLoadListener                           off=0x18 attr=1 
#   field onFsnCompletedListener         AndroidOnFsnCompletedListener                      off=0x20 attr=1 
## .ctor() -> void
---- FsnAd::.ctor 0x2c92ecc
02c92ecc: str     x30, [sp, #-0x30]!                         
02c92ed0: stp     x22, x21, [sp, #0x10]                      
02c92ed4: stp     x20, x19, [sp, #0x20]                      
02c92ed8: adrp    x21, #0x662f000                            
02c92edc: adrp    x20, #0x6264000                            
02c92ee0: mov     x19, x0                                    
02c92ee4: ldrb    w8, [x21, #0x9db]                          
02c92ee8: ldr     x20, [x20, #0xa70]                         T:UnityEngine.Application
02c92eec: tbnz    w8, #0, #0x2c92f28                         
02c92ef0: adrp    x0, #0x6263000                             
02c92ef4: ldr     x0, [x0, #0xbd8]                           T:UnityEngine.AndroidJavaObject
02c92ef8: bl      #0x2b70db0                                 fn_2b70db0
02c92efc: adrp    x0, #0x6264000                             
02c92f00: ldr     x0, [x0, #0xa70]                           T:UnityEngine.Application
02c92f04: bl      #0x2b70db0                                 fn_2b70db0
02c92f08: adrp    x0, #0x6263000                             
02c92f0c: ldr     x0, [x0, #0xb70]                           MS:System.Array::Empty
02c92f10: bl      #0x2b70db0                                 fn_2b70db0
02c92f14: adrp    x0, #0x6265000                             
02c92f18: ldr     x0, [x0, #0x700]                           S:'com.ads.fsnforunity.fsnlib.FsnAd'
02c92f1c: bl      #0x2b70db0                                 fn_2b70db0
02c92f20: mov     w8, #1                                     
02c92f24: strb    w8, [x21, #0x9db]                          
02c92f28: mov     x0, x19                                    
02c92f2c: mov     x1, xzr                                    
02c92f30: bl      #0x4e53e9c                                 System.Object::.ctor
02c92f34: ldr     x0, [x20]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c92f38: ldr     w8, [x0, #0xe4]                            [62650e4]=0 f=0,0
02c92f3c: cbnz    w8, #0x2c92f44                             
02c92f40: bl      #0x2b70f30                                 fn_2b70f30
02c92f44: mov     x0, xzr                                    
02c92f48: bl      #0x5aeb18c                                 UnityEngine.Application::get_platform
02c92f4c: cmp     w0, #0xb                                   
02c92f50: b.ne    #0x2c92ffc                                 
02c92f54: adrp    x8, #0x6263000                             
02c92f58: ldr     x8, [x8, #0xb70]                           MS:System.Array::Empty
02c92f5c: ldr     x20, [x8]                                  &2c5bbd4(=a9bd7bfdd503233f)
02c92f60: ldr     x8, [x20, #0x38]                           M:UnityEngine.Rigidbody::MovePosition
02c92f64: cbnz    x8, #0x2c92f74                             
02c92f68: mov     x0, x20                                    
02c92f6c: bl      #0x2ba9d7c                                 fn_2ba9d7c
02c92f70: ldr     x8, [x20, #0x38]                           M:UnityEngine.Rigidbody::MovePosition
02c92f74: ldr     x0, [x8, #0x10]                            &2c498bc(=aa1f03e0d503245f)
02c92f78: add     x8, x0, #0x135                             &6265135
02c92f7c: ldrh    w8, [x8]                                   
02c92f80: tbnz    w8, #0, #0x2c92f88                         
02c92f84: bl      #0x2ba9d20                                 fn_2ba9d20
02c92f88: ldr     w8, [x0, #0xe4]                            [62650e4]=0 f=0,0
02c92f8c: cbnz    w8, #0x2c92f94                             
02c92f90: bl      #0x2b70f30                                 fn_2b70f30
02c92f94: ldr     x8, [x20, #0x38]                           M:UnityEngine.Rigidbody::MovePosition
02c92f98: adrp    x22, #0x6263000                            
02c92f9c: adrp    x21, #0x6265000                            
02c92fa0: ldr     x0, [x8, #0x10]                            &2c498bc(=aa1f03e0d503245f)
02c92fa4: ldr     x22, [x22, #0xbd8]                         T:UnityEngine.AndroidJavaObject
02c92fa8: add     x8, x0, #0x135                             &6265135
02c92fac: ldrh    w8, [x8]                                   
02c92fb0: ldr     x21, [x21, #0x700]                         S:'com.ads.fsnforunity.fsnlib.FsnAd'
02c92fb4: tbnz    w8, #0, #0x2c92fbc                         
02c92fb8: bl      #0x2ba9d20                                 fn_2ba9d20
02c92fbc: ldr     x8, [x0, #0xb8]                            T:AdsManager/<>c__DisplayClass42_0
02c92fc0: ldr     x0, [x22]                                  &2c5bbd4(=a9bd7bfdd503233f)
02c92fc4: ldr     x20, [x8]                                  &2c5bbd4(=a9bd7bfdd503233f)
02c92fc8: bl      #0x2b7104c                                 fn_2b7104c
02c92fcc: ldr     x1, [x21]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c92fd0: mov     x2, x20                                    
02c92fd4: mov     x3, xzr                                    
02c92fd8: mov     x21, x0                                    
02c92fdc: bl      #0x5ad5b2c                                 UnityEngine.AndroidJavaObject::.ctor
02c92fe0: str     x21, [x19, #0x10]!                         .androidFsnAd
02c92fe4: mov     x0, x19                                    
02c92fe8: mov     x1, x21                                    
02c92fec: ldp     x20, x19, [sp, #0x20]                      
02c92ff0: ldp     x22, x21, [sp, #0x10]                      
02c92ff4: ldr     x30, [sp], #0x30                           
02c92ff8: b       #0x2b70d54                                 
02c92ffc: ldp     x20, x19, [sp, #0x20]                      
02c93000: ldp     x22, x21, [sp, #0x10]                      
02c93004: ldr     x30, [sp], #0x30                           
02c93008: ret                                                
## Init(string adUnitId, int countDownSec, bool loadNewAfterClose, bool startMuteVideo, bool autoDismissWhenAdClicked) -> void
---- FsnAd::Init 0x2c9300c
02c9300c: sub     sp, sp, #0x60                              
02c93010: str     x30, [sp, #0x10]                           
02c93014: stp     x26, x25, [sp, #0x20]                      
02c93018: stp     x24, x23, [sp, #0x30]                      
02c9301c: stp     x22, x21, [sp, #0x40]                      
02c93020: stp     x20, x19, [sp, #0x50]                      
02c93024: adrp    x21, #0x662f000                            
02c93028: adrp    x26, #0x6264000                            
02c9302c: mov     w19, w5                                    
02c93030: ldrb    w8, [x21, #0x9dc]                          
02c93034: ldr     x26, [x26, #0xa70]                         T:UnityEngine.Application
02c93038: mov     w22, w4                                    
02c9303c: mov     w23, w3                                    
02c93040: mov     w24, w2                                    
02c93044: mov     x25, x1                                    
02c93048: mov     x20, x0                                    
02c9304c: tbnz    w8, #0, #0x2c9307c                         
02c93050: adrp    x0, #0x6264000                             
02c93054: ldr     x0, [x0, #0xa70]                           T:UnityEngine.Application
02c93058: bl      #0x2b70db0                                 fn_2b70db0
02c9305c: adrp    x0, #0x6263000                             
02c93060: ldr     x0, [x0, #0xa80]                           T:type24502(k1d)
02c93064: bl      #0x2b70db0                                 fn_2b70db0
02c93068: adrp    x0, #0x6265000                             
02c9306c: ldr     x0, [x0, #0x708]                           S:'Init'
02c93070: bl      #0x2b70db0                                 fn_2b70db0
02c93074: mov     w8, #1                                     
02c93078: strb    w8, [x21, #0x9dc]                          
02c9307c: ldr     x0, [x26]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c93080: ldr     w8, [x0, #0xe4]                            [62650e4]=0 f=0,0
02c93084: cbnz    w8, #0x2c9308c                             
02c93088: bl      #0x2b70f30                                 fn_2b70f30
02c9308c: mov     x0, xzr                                    
02c93090: bl      #0x5aeb18c                                 UnityEngine.Application::get_platform
02c93094: cmp     w0, #0xb                                   
02c93098: b.ne    #0x2c93240                                 
02c9309c: ldr     x20, [x20, #0x10]                          .androidFsnAd
02c930a0: cbz     x20, #0x2c93240                            
02c930a4: adrp    x8, #0x6263000                             
02c930a8: mov     w1, #5                                     
02c930ac: ldr     x8, [x8, #0xa80]                           T:type24502(k1d)
02c930b0: ldr     x0, [x8]                                   &2c5bbd4(=a9bd7bfdd503233f)
02c930b4: bl      #0x2b70ea0                                 fn_2b70ea0
02c930b8: cbz     x0, #0x2c9326c                             
02c930bc: mov     x21, x0                                    
02c930c0: cbz     x25, #0x2c930d8                            
02c930c4: ldr     x8, [x21]                                  &2b706c4(=eb01011ff9400808)
02c930c8: mov     x0, x25                                    
02c930cc: ldr     x1, [x8, #0x40]                            [6263040]=0 f=0,0
02c930d0: bl      #0x2b70f34                                 fn_2b70f34
02c930d4: cbz     x0, #0x2c93260                             
02c930d8: ldr     w8, [x21, #0x18]                           [662f018]=6000014 f=2.40742e-35,0 .onFsnLoadListener
02c930dc: cbz     w8, #0x2c9325c                             
02c930e0: mov     x0, x21                                    
02c930e4: mov     x1, x25                                    
02c930e8: str     x25, [x0, #0x20]!                          .onFsnCompletedListener
02c930ec: bl      #0x2b70d54                                 fn_2b70d54
02c930f0: adrp    x25, #0x6263000                            
02c930f4: add     x1, sp, #0x1c                              
02c930f8: ldr     x25, [x25, #0x970]                         &6645c70(=0)
02c930fc: str     w24, [sp, #0x1c]                           
02c93100: ldr     x0, [x25, #0x48]                           &6263098(=0)
02c93104: bl      #0x2b70f38                                 fn_2b70f38
02c93108: mov     x24, x0                                    
02c9310c: cbz     x0, #0x2c93124                             
02c93110: ldr     x8, [x21]                                  &2b706c4(=eb01011ff9400808)
02c93114: mov     x0, x24                                    
02c93118: ldr     x1, [x8, #0x40]                            [6263040]=0 f=0,0
02c9311c: bl      #0x2b70f34                                 fn_2b70f34
02c93120: cbz     x0, #0x2c93260                             
02c93124: ldr     w8, [x21, #0x18]                           [662f018]=6000014 f=2.40742e-35,0 .onFsnLoadListener
02c93128: tst     w8, #0xfffffffe                            
02c9312c: b.eq    #0x2c9325c                                 
02c93130: mov     x0, x21                                    
02c93134: mov     x1, x24                                    
02c93138: and     w23, w23, #1                               
02c9313c: str     x24, [x0, #0x28]!                          
02c93140: bl      #0x2b70d54                                 fn_2b70d54
02c93144: ldr     x0, [x25, #0x28]                           [6263028]=0 f=0,0
02c93148: add     x1, sp, #0x18                              
02c9314c: strb    w23, [sp, #0x18]                           
02c93150: bl      #0x2b70f38                                 fn_2b70f38
02c93154: mov     x23, x0                                    
02c93158: cbz     x0, #0x2c93170                             
02c9315c: ldr     x8, [x21]                                  &2b706c4(=eb01011ff9400808)
02c93160: mov     x0, x23                                    
02c93164: ldr     x1, [x8, #0x40]                            [6263040]=0 f=0,0
02c93168: bl      #0x2b70f34                                 fn_2b70f34
02c9316c: cbz     x0, #0x2c93260                             
02c93170: ldr     w8, [x21, #0x18]                           [662f018]=6000014 f=2.40742e-35,0 .onFsnLoadListener
02c93174: cmp     w8, #2                                     
02c93178: b.ls    #0x2c9325c                                 
02c9317c: mov     x0, x21                                    
02c93180: mov     x1, x23                                    
02c93184: and     w22, w22, #1                               
02c93188: str     x23, [x0, #0x30]!                          
02c9318c: bl      #0x2b70d54                                 fn_2b70d54
02c93190: ldr     x0, [x25, #0x28]                           [6263028]=0 f=0,0
02c93194: add     x1, sp, #0xc                               
02c93198: strb    w22, [sp, #0xc]                            
02c9319c: bl      #0x2b70f38                                 fn_2b70f38
02c931a0: mov     x22, x0                                    
02c931a4: cbz     x0, #0x2c931bc                             
02c931a8: ldr     x8, [x21]                                  &2b706c4(=eb01011ff9400808)
02c931ac: mov     x0, x22                                    
02c931b0: ldr     x1, [x8, #0x40]                            [6263040]=0 f=0,0
02c931b4: bl      #0x2b70f34                                 fn_2b70f34
02c931b8: cbz     x0, #0x2c93260                             
02c931bc: ldr     w8, [x21, #0x18]                           [662f018]=6000014 f=2.40742e-35,0 .onFsnLoadListener
02c931c0: tst     w8, #0xfffffffc                            
02c931c4: b.eq    #0x2c9325c                                 
02c931c8: mov     x0, x21                                    
02c931cc: mov     x1, x22                                    
02c931d0: and     w19, w19, #1                               
02c931d4: str     x22, [x0, #0x38]!                          
02c931d8: bl      #0x2b70d54                                 fn_2b70d54
02c931dc: ldr     x0, [x25, #0x28]                           [6263028]=0 f=0,0
02c931e0: add     x1, sp, #8                                 
02c931e4: strb    w19, [sp, #8]                              
02c931e8: bl      #0x2b70f38                                 fn_2b70f38
02c931ec: mov     x19, x0                                    
02c931f0: cbz     x0, #0x2c93208                             
02c931f4: ldr     x8, [x21]                                  &2b706c4(=eb01011ff9400808)
02c931f8: mov     x0, x19                                    
02c931fc: ldr     x1, [x8, #0x40]                            [6263040]=0 f=0,0
02c93200: bl      #0x2b70f34                                 fn_2b70f34
02c93204: cbz     x0, #0x2c93260                             
02c93208: ldr     w8, [x21, #0x18]                           [662f018]=6000014 f=2.40742e-35,0 .onFsnLoadListener
02c9320c: cmp     w8, #4                                     
02c93210: b.ls    #0x2c9325c                                 
02c93214: mov     x0, x21                                    
02c93218: mov     x1, x19                                    
02c9321c: str     x19, [x0, #0x40]!                          
02c93220: bl      #0x2b70d54                                 fn_2b70d54
02c93224: adrp    x8, #0x6265000                             
02c93228: mov     x0, x20                                    
02c9322c: mov     x2, x21                                    
02c93230: ldr     x8, [x8, #0x708]                           S:'Init'
02c93234: mov     x3, xzr                                    
02c93238: ldr     x1, [x8]                                   M:AdsManager::<OnApplicationPause>b__26_0
02c9323c: bl      #0x5ad5e34                                 UnityEngine.AndroidJavaObject::Call
02c93240: ldp     x20, x19, [sp, #0x50]                      
02c93244: ldr     x30, [sp, #0x10]                           
02c93248: ldp     x22, x21, [sp, #0x40]                      
02c9324c: ldp     x24, x23, [sp, #0x30]                      
02c93250: ldp     x26, x25, [sp, #0x20]                      
02c93254: add     sp, sp, #0x60                              
02c93258: ret                                                
02c9325c: bl      #0x2b71064                                 fn_2b71064
02c93260: bl      #0x2b71080                                 fn_2b71080
02c93264: mov     x1, xzr                                    
02c93268: bl      #0x2b70f20                                 fn_2b70f20
02c9326c: bl      #0x2b7105c                                 fn_2b7105c
## SetFsnListener(System.Action`2<int,string> onLoadingCompleted, System.Action onLoadingStarted, System.Action`4<string,string,double,string> onAdPaid) -> void
---- FsnAd::SetFsnListener 0x2c93270
02c93270: str     x30, [sp, #-0x40]!                         
02c93274: stp     x24, x23, [sp, #0x10]                      
02c93278: stp     x22, x21, [sp, #0x20]                      
02c9327c: stp     x20, x19, [sp, #0x30]                      
02c93280: adrp    x23, #0x662f000                            
02c93284: adrp    x24, #0x6264000                            
02c93288: mov     x20, x3                                    
02c9328c: ldrb    w8, [x23, #0x9dd]                          
02c93290: ldr     x24, [x24, #0xa70]                         T:UnityEngine.Application
02c93294: mov     x21, x2                                    
02c93298: mov     x22, x1                                    
02c9329c: mov     x19, x0                                    
02c932a0: tbnz    w8, #0, #0x2c932dc                         
02c932a4: adrp    x0, #0x6265000                             
02c932a8: ldr     x0, [x0, #0x710]                           T:AndroidOnFsnLoadListener
02c932ac: bl      #0x2b70db0                                 fn_2b70db0
02c932b0: adrp    x0, #0x6264000                             
02c932b4: ldr     x0, [x0, #0xa70]                           T:UnityEngine.Application
02c932b8: bl      #0x2b70db0                                 fn_2b70db0
02c932bc: adrp    x0, #0x6263000                             
02c932c0: ldr     x0, [x0, #0xa80]                           T:type24502(k1d)
02c932c4: bl      #0x2b70db0                                 fn_2b70db0
02c932c8: adrp    x0, #0x6265000                             
02c932cc: ldr     x0, [x0, #0x718]                           S:'SetFsnListener'
02c932d0: bl      #0x2b70db0                                 fn_2b70db0
02c932d4: mov     w8, #1                                     
02c932d8: strb    w8, [x23, #0x9dd]                          
02c932dc: ldr     x0, [x24]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c932e0: ldr     w8, [x0, #0xe4]                            [62650e4]=0 f=0,0
02c932e4: cbnz    w8, #0x2c932ec                             
02c932e8: bl      #0x2b70f30                                 fn_2b70f30
02c932ec: mov     x0, xzr                                    
02c932f0: bl      #0x5aeb18c                                 UnityEngine.Application::get_platform
02c932f4: cmp     w0, #0xb                                   
02c932f8: b.ne    #0x2c933b4                                 
02c932fc: adrp    x8, #0x6265000                             
02c93300: ldr     x8, [x8, #0x710]                           T:AndroidOnFsnLoadListener
02c93304: ldr     x0, [x8]                                   M:AdsManager::<OnApplicationPause>b__26_0
02c93308: bl      #0x2b7104c                                 fn_2b7104c
02c9330c: mov     x1, x22                                    
02c93310: mov     x2, x21                                    
02c93314: mov     x3, x20                                    
02c93318: mov     x23, x0                                    
02c9331c: bl      #0x2c933dc                                 AndroidOnFsnLoadListener::.ctor
02c93320: str     x23, [x19, #0x18]!                         .onFsnLoadListener
02c93324: mov     x0, x19                                    
02c93328: mov     x1, x23                                    
02c9332c: bl      #0x2b70d54                                 fn_2b70d54
02c93330: ldur    x20, [x19, #-8]                            
02c93334: cbz     x20, #0x2c933b4                            
02c93338: adrp    x8, #0x6263000                             
02c9333c: mov     w1, #1                                     
02c93340: ldr     x8, [x8, #0xa80]                           T:type24502(k1d)
02c93344: ldr     x0, [x8]                                   &2c5bbd4(=a9bd7bfdd503233f)
02c93348: bl      #0x2b70ea0                                 fn_2b70ea0
02c9334c: cbz     x0, #0x2c933c8                             
02c93350: ldr     x19, [x19]                                 
02c93354: mov     x21, x0                                    
02c93358: cbz     x19, #0x2c93370                            
02c9335c: ldr     x8, [x21]                                  
02c93360: mov     x0, x19                                    
02c93364: ldr     x1, [x8, #0x40]                            [6263040]=0 f=0,0
02c93368: bl      #0x2b70f34                                 fn_2b70f34
02c9336c: cbz     x0, #0x2c933d0                             
02c93370: ldr     w8, [x21, #0x18]                           .onFsnLoadListener
02c93374: cbz     w8, #0x2c933cc                             
02c93378: mov     x0, x21                                    
02c9337c: mov     x1, x19                                    
02c93380: str     x19, [x0, #0x20]!                          .onFsnCompletedListener
02c93384: bl      #0x2b70d54                                 fn_2b70d54
02c93388: adrp    x8, #0x6265000                             
02c9338c: mov     x0, x20                                    
02c93390: mov     x2, x21                                    
02c93394: ldr     x8, [x8, #0x718]                           S:'SetFsnListener'
02c93398: ldp     x20, x19, [sp, #0x30]                      
02c9339c: ldp     x22, x21, [sp, #0x20]                      
02c933a0: mov     x3, xzr                                    
02c933a4: ldp     x24, x23, [sp, #0x10]                      
02c933a8: ldr     x1, [x8]                                   M:AdsManager::<OnApplicationPause>b__26_0
02c933ac: ldr     x30, [sp], #0x40                           
02c933b0: b       #0x5ad5e34                                 UnityEngine.AndroidJavaObject::Call
02c933b4: ldp     x20, x19, [sp, #0x30]                      
02c933b8: ldp     x22, x21, [sp, #0x20]                      
02c933bc: ldp     x24, x23, [sp, #0x10]                      
02c933c0: ldr     x30, [sp], #0x40                           
02c933c4: ret                                                
02c933c8: bl      #0x2b7105c                                 fn_2b7105c
02c933cc: bl      #0x2b71064                                 fn_2b71064
02c933d0: bl      #0x2b71080                                 fn_2b71080
02c933d4: mov     x1, xzr                                    
02c933d8: bl      #0x2b70f20                                 fn_2b70f20
## LoadAd() -> void
---- FsnAd::LoadAd 0x2c934b0
02c934b0: stp     x30, x21, [sp, #-0x20]!                    
02c934b4: stp     x20, x19, [sp, #0x10]                      
02c934b8: adrp    x20, #0x662f000                            
02c934bc: adrp    x21, #0x6264000                            
02c934c0: mov     x19, x0                                    
02c934c4: ldrb    w8, [x20, #0x9de]                          
02c934c8: ldr     x21, [x21, #0xa70]                         T:UnityEngine.Application
02c934cc: tbnz    w8, #0, #0x2c9352c                         
02c934d0: adrp    x0, #0x6263000                             
02c934d4: ldr     x0, [x0, #0xc40]                           T:UnityEngine.AndroidJavaClass
02c934d8: bl      #0x2b70db0                                 fn_2b70db0
02c934dc: adrp    x0, #0x6263000                             
02c934e0: ldr     x0, [x0, #0xc50]                           MS:UnityEngine.AndroidJavaObject::GetStatic
02c934e4: bl      #0x2b70db0                                 fn_2b70db0
02c934e8: adrp    x0, #0x6264000                             
02c934ec: ldr     x0, [x0, #0xa70]                           T:UnityEngine.Application
02c934f0: bl      #0x2b70db0                                 fn_2b70db0
02c934f4: adrp    x0, #0x6263000                             
02c934f8: ldr     x0, [x0, #0xa80]                           T:type24502(k1d)
02c934fc: bl      #0x2b70db0                                 fn_2b70db0
02c93500: adrp    x0, #0x6265000                             
02c93504: ldr     x0, [x0, #0x728]                           S:'LoadAd'
02c93508: bl      #0x2b70db0                                 fn_2b70db0
02c9350c: adrp    x0, #0x6265000                             
02c93510: ldr     x0, [x0, #0x730]                           S:'com.unity3d.player.UnityPlayer'
02c93514: bl      #0x2b70db0                                 fn_2b70db0
02c93518: adrp    x0, #0x6265000                             
02c9351c: ldr     x0, [x0, #0x738]                           S:'currentActivity'
02c93520: bl      #0x2b70db0                                 fn_2b70db0
02c93524: mov     w8, #1                                     
02c93528: strb    w8, [x20, #0x9de]                          
02c9352c: ldr     x0, [x21]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c93530: ldr     w8, [x0, #0xe4]                            [62650e4]=0 f=0,0
02c93534: cbnz    w8, #0x2c9353c                             
02c93538: bl      #0x2b70f30                                 fn_2b70f30
02c9353c: mov     x0, xzr                                    
02c93540: bl      #0x5aeb18c                                 UnityEngine.Application::get_platform
02c93544: cmp     w0, #0xb                                   
02c93548: b.ne    #0x2c93614                                 
02c9354c: adrp    x8, #0x6263000                             
02c93550: adrp    x20, #0x6265000                            
02c93554: ldr     x8, [x8, #0xc40]                           T:UnityEngine.AndroidJavaClass
02c93558: ldr     x20, [x20, #0x730]                         S:'com.unity3d.player.UnityPlayer'
02c9355c: ldr     x0, [x8]                                   &2c5bbd4(=a9bd7bfdd503233f)
02c93560: bl      #0x2b7104c                                 fn_2b7104c
02c93564: ldr     x1, [x20]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c93568: mov     x2, xzr                                    
02c9356c: mov     x20, x0                                    
02c93570: bl      #0x5ad2f6c                                 UnityEngine.AndroidJavaClass::.ctor
02c93574: cbz     x20, #0x2c93620                            
02c93578: adrp    x8, #0x6265000                             
02c9357c: adrp    x9, #0x6263000                             
02c93580: mov     x0, x20                                    
02c93584: ldr     x8, [x8, #0x738]                           S:'currentActivity'
02c93588: ldr     x9, [x9, #0xc50]                           MS:UnityEngine.AndroidJavaObject::GetStatic
02c9358c: ldr     x1, [x8]                                   M:AdsManager::<OnApplicationPause>b__26_0
02c93590: ldr     x2, [x9]                                   &2c5bbd4(=a9bd7bfdd503233f)
02c93594: bl      #0x3121808                                 fn_3121808
02c93598: ldr     x19, [x19, #0x10]                          .androidFsnAd
02c9359c: cbz     x19, #0x2c93614                            
02c935a0: adrp    x8, #0x6263000                             
02c935a4: mov     x20, x0                                    
02c935a8: mov     w1, #1                                     
02c935ac: ldr     x8, [x8, #0xa80]                           T:type24502(k1d)
02c935b0: ldr     x0, [x8]                                   &2c5bbd4(=a9bd7bfdd503233f)
02c935b4: bl      #0x2b70ea0                                 fn_2b70ea0
02c935b8: cbz     x0, #0x2c93620                             
02c935bc: mov     x21, x0                                    
02c935c0: cbz     x20, #0x2c935d8                            
02c935c4: ldr     x8, [x21]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c935c8: mov     x0, x20                                    
02c935cc: ldr     x1, [x8, #0x40]                            [6263040]=0 f=0,0
02c935d0: bl      #0x2b70f34                                 fn_2b70f34
02c935d4: cbz     x0, #0x2c93628                             
02c935d8: ldr     w8, [x21, #0x18]                           M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass2_0::<DOSetFloat>b__1 .onFsnLoadListener
02c935dc: cbz     w8, #0x2c93624                             
02c935e0: mov     x0, x21                                    
02c935e4: mov     x1, x20                                    
02c935e8: str     x20, [x0, #0x20]!                          .onFsnCompletedListener
02c935ec: bl      #0x2b70d54                                 fn_2b70d54
02c935f0: adrp    x8, #0x6265000                             
02c935f4: mov     x0, x19                                    
02c935f8: mov     x2, x21                                    
02c935fc: ldr     x8, [x8, #0x728]                           S:'LoadAd'
02c93600: ldp     x20, x19, [sp, #0x10]                      
02c93604: mov     x3, xzr                                    
02c93608: ldr     x1, [x8]                                   M:AdsManager::<OnApplicationPause>b__26_0
02c9360c: ldp     x30, x21, [sp], #0x20                      
02c93610: b       #0x5ad5e34                                 UnityEngine.AndroidJavaObject::Call
02c93614: ldp     x20, x19, [sp, #0x10]                      
02c93618: ldp     x30, x21, [sp], #0x20                      
02c9361c: ret                                                
02c93620: bl      #0x2b7105c                                 fn_2b7105c
02c93624: bl      #0x2b71064                                 fn_2b71064
02c93628: bl      #0x2b71080                                 fn_2b71080
02c9362c: mov     x1, xzr                                    
02c93630: bl      #0x2b70f20                                 fn_2b70f20
## ShowAd(System.Action`1<string> onAdCompleted) -> void
---- FsnAd::ShowAd 0x2c93634
02c93634: str     x30, [sp, #-0x30]!                         
02c93638: stp     x22, x21, [sp, #0x10]                      
02c9363c: stp     x20, x19, [sp, #0x20]                      
02c93640: adrp    x21, #0x662f000                            
02c93644: adrp    x22, #0x6264000                            
02c93648: mov     x20, x1                                    
02c9364c: ldrb    w8, [x21, #0x9df]                          
02c93650: ldr     x22, [x22, #0xa70]                         T:UnityEngine.Application
02c93654: mov     x19, x0                                    
02c93658: tbnz    w8, #0, #0x2c936d0                         
02c9365c: adrp    x0, #0x6263000                             
02c93660: ldr     x0, [x0, #0xc40]                           T:UnityEngine.AndroidJavaClass
02c93664: bl      #0x2b70db0                                 fn_2b70db0
02c93668: adrp    x0, #0x6263000                             
02c9366c: ldr     x0, [x0, #0xc50]                           MS:UnityEngine.AndroidJavaObject::GetStatic
02c93670: bl      #0x2b70db0                                 fn_2b70db0
02c93674: adrp    x0, #0x6265000                             
02c93678: ldr     x0, [x0, #0x740]                           T:AndroidOnFsnCompletedListener
02c9367c: bl      #0x2b70db0                                 fn_2b70db0
02c93680: adrp    x0, #0x6264000                             
02c93684: ldr     x0, [x0, #0xa70]                           T:UnityEngine.Application
02c93688: bl      #0x2b70db0                                 fn_2b70db0
02c9368c: adrp    x0, #0x6263000                             
02c93690: ldr     x0, [x0, #0xa80]                           T:type24502(k1d)
02c93694: bl      #0x2b70db0                                 fn_2b70db0
02c93698: adrp    x0, #0x6265000                             
02c9369c: ldr     x0, [x0, #0x730]                           S:'com.unity3d.player.UnityPlayer'
02c936a0: bl      #0x2b70db0                                 fn_2b70db0
02c936a4: adrp    x0, #0x6263000                             
02c936a8: ldr     x0, [x0, #0xa90]                           S:''
02c936ac: bl      #0x2b70db0                                 fn_2b70db0
02c936b0: adrp    x0, #0x6265000                             
02c936b4: ldr     x0, [x0, #0x748]                           S:'ShowAd'
02c936b8: bl      #0x2b70db0                                 fn_2b70db0
02c936bc: adrp    x0, #0x6265000                             
02c936c0: ldr     x0, [x0, #0x738]                           S:'currentActivity'
02c936c4: bl      #0x2b70db0                                 fn_2b70db0
02c936c8: mov     w8, #1                                     
02c936cc: strb    w8, [x21, #0x9df]                          
02c936d0: ldr     x0, [x22]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c936d4: ldr     w8, [x0, #0xe4]                            [62650e4]=0 f=0,0
02c936d8: cbnz    w8, #0x2c936e0                             
02c936dc: bl      #0x2b70f30                                 fn_2b70f30
02c936e0: mov     x0, xzr                                    
02c936e4: bl      #0x5aeb18c                                 UnityEngine.Application::get_platform
02c936e8: cmp     w0, #0xb                                   
02c936ec: b.ne    #0x2c93824                                 
02c936f0: adrp    x8, #0x6263000                             
02c936f4: adrp    x21, #0x6265000                            
02c936f8: ldr     x8, [x8, #0xc40]                           T:UnityEngine.AndroidJavaClass
02c936fc: ldr     x21, [x21, #0x730]                         S:'com.unity3d.player.UnityPlayer'
02c93700: ldr     x0, [x8]                                   &2c5bbd4(=a9bd7bfdd503233f)
02c93704: bl      #0x2b7104c                                 fn_2b7104c
02c93708: ldr     x1, [x21]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9370c: mov     x2, xzr                                    
02c93710: mov     x21, x0                                    
02c93714: bl      #0x5ad2f6c                                 UnityEngine.AndroidJavaClass::.ctor
02c93718: cbz     x21, #0x2c93860                            
02c9371c: adrp    x8, #0x6265000                             
02c93720: adrp    x9, #0x6263000                             
02c93724: mov     x0, x21                                    
02c93728: ldr     x8, [x8, #0x738]                           S:'currentActivity'
02c9372c: ldr     x9, [x9, #0xc50]                           MS:UnityEngine.AndroidJavaObject::GetStatic
02c93730: ldr     x1, [x8]                                   M:AdsManager::<OnApplicationPause>b__26_0
02c93734: ldr     x2, [x9]                                   &2c5bbd4(=a9bd7bfdd503233f)
02c93738: bl      #0x3121808                                 fn_3121808
02c9373c: adrp    x8, #0x6265000                             
02c93740: mov     x22, x0                                    
02c93744: ldr     x8, [x8, #0x740]                           T:AndroidOnFsnCompletedListener
02c93748: ldr     x8, [x8]                                   M:AdsManager::<OnApplicationPause>b__26_0
02c9374c: mov     x0, x8                                     
02c93750: bl      #0x2b7104c                                 fn_2b7104c
02c93754: mov     x1, x20                                    
02c93758: mov     x21, x0                                    
02c9375c: bl      #0x2c93874                                 AndroidOnFsnCompletedListener::.ctor
02c93760: str     x21, [x19, #0x20]!                         .onFsnCompletedListener
02c93764: mov     x0, x19                                    
02c93768: mov     x1, x21                                    
02c9376c: bl      #0x2b70d54                                 fn_2b70d54
02c93770: ldur    x20, [x19, #-0x10]                         
02c93774: cbz     x20, #0x2c93850                            
02c93778: adrp    x8, #0x6263000                             
02c9377c: mov     w1, #2                                     
02c93780: ldr     x8, [x8, #0xa80]                           T:type24502(k1d)
02c93784: ldr     x0, [x8]                                   &2c5bbd4(=a9bd7bfdd503233f)
02c93788: bl      #0x2b70ea0                                 fn_2b70ea0
02c9378c: cbz     x0, #0x2c93860                             
02c93790: mov     x21, x0                                    
02c93794: cbz     x22, #0x2c937ac                            
02c93798: ldr     x8, [x21]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9379c: mov     x0, x22                                    
02c937a0: ldr     x1, [x8, #0x40]                            [6263040]=0 f=0,0
02c937a4: bl      #0x2b70f34                                 fn_2b70f34
02c937a8: cbz     x0, #0x2c93868                             
02c937ac: ldr     w8, [x21, #0x18]                           T:AdsManager/<IEHideAdResume>d__30 .onFsnLoadListener
02c937b0: cbz     w8, #0x2c93864                             
02c937b4: mov     x0, x21                                    
02c937b8: mov     x1, x22                                    
02c937bc: str     x22, [x0, #0x20]!                          .onFsnCompletedListener
02c937c0: bl      #0x2b70d54                                 fn_2b70d54
02c937c4: ldr     x19, [x19]                                 
02c937c8: cbz     x19, #0x2c937e0                            
02c937cc: ldr     x8, [x21]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c937d0: mov     x0, x19                                    
02c937d4: ldr     x1, [x8, #0x40]                            [6263040]=0 f=0,0
02c937d8: bl      #0x2b70f34                                 fn_2b70f34
02c937dc: cbz     x0, #0x2c93868                             
02c937e0: ldr     w8, [x21, #0x18]                           T:AdsManager/<IEHideAdResume>d__30 .onFsnLoadListener
02c937e4: tst     w8, #0xfffffffe                            
02c937e8: b.eq    #0x2c93864                                 
02c937ec: mov     x0, x21                                    
02c937f0: mov     x1, x19                                    
02c937f4: str     x19, [x0, #0x28]!                          
02c937f8: bl      #0x2b70d54                                 fn_2b70d54
02c937fc: adrp    x8, #0x6265000                             
02c93800: mov     x0, x20                                    
02c93804: mov     x2, x21                                    
02c93808: ldr     x8, [x8, #0x748]                           S:'ShowAd'
02c9380c: ldp     x20, x19, [sp, #0x20]                      
02c93810: ldp     x22, x21, [sp, #0x10]                      
02c93814: mov     x3, xzr                                    
02c93818: ldr     x1, [x8]                                   M:AdsManager::<OnApplicationPause>b__26_0
02c9381c: ldr     x30, [sp], #0x30                           
02c93820: b       #0x5ad5e34                                 UnityEngine.AndroidJavaObject::Call
02c93824: cbz     x20, #0x2c93850                            
02c93828: adrp    x8, #0x6263000                             
02c9382c: ldr     x8, [x8, #0xa90]                           S:''
02c93830: ldr     x0, [x20, #0x40]                           
02c93834: ldr     x2, [x20, #0x28]                           
02c93838: ldr     x3, [x20, #0x18]                           .onFsnLoadListener
02c9383c: ldp     x20, x19, [sp, #0x20]                      
02c93840: ldp     x22, x21, [sp, #0x10]                      
02c93844: ldr     x1, [x8]                                   &2c5bbd4(=a9bd7bfdd503233f)
02c93848: ldr     x30, [sp], #0x30                           
02c9384c: br      x3                                         
02c93850: ldp     x20, x19, [sp, #0x20]                      
02c93854: ldp     x22, x21, [sp, #0x10]                      
02c93858: ldr     x30, [sp], #0x30                           
02c9385c: ret                                                
02c93860: bl      #0x2b7105c                                 fn_2b7105c
02c93864: bl      #0x2b71064                                 fn_2b71064
02c93868: bl      #0x2b71080                                 fn_2b71080
02c9386c: mov     x1, xzr                                    
02c93870: bl      #0x2b70f20                                 fn_2b70f20
## HideAd() -> void
---- FsnAd::HideAd 0x2c93918
02c93918: stp     x30, x21, [sp, #-0x20]!                    
02c9391c: stp     x20, x19, [sp, #0x10]                      
02c93920: adrp    x20, #0x662f000                            
02c93924: adrp    x21, #0x6264000                            
02c93928: mov     x19, x0                                    
02c9392c: ldrb    w8, [x20, #0x9e0]                          
02c93930: ldr     x21, [x21, #0xa70]                         T:UnityEngine.Application
02c93934: tbnz    w8, #0, #0x2c93964                         
02c93938: adrp    x0, #0x6264000                             
02c9393c: ldr     x0, [x0, #0xa70]                           T:UnityEngine.Application
02c93940: bl      #0x2b70db0                                 fn_2b70db0
02c93944: adrp    x0, #0x6263000                             
02c93948: ldr     x0, [x0, #0xb70]                           MS:System.Array::Empty
02c9394c: bl      #0x2b70db0                                 fn_2b70db0
02c93950: adrp    x0, #0x6265000                             
02c93954: ldr     x0, [x0, #0x758]                           S:'HideAd'
02c93958: bl      #0x2b70db0                                 fn_2b70db0
02c9395c: mov     w8, #1                                     
02c93960: strb    w8, [x20, #0x9e0]                          
02c93964: ldr     x0, [x21]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c93968: ldr     w8, [x0, #0xe4]                            [62650e4]=0 f=0,0
02c9396c: cbnz    w8, #0x2c93974                             
02c93970: bl      #0x2b70f30                                 fn_2b70f30
02c93974: mov     x0, xzr                                    
02c93978: bl      #0x5aeb18c                                 UnityEngine.Application::get_platform
02c9397c: cmp     w0, #0xb                                   
02c93980: b.ne    #0x2c93a0c                                 
02c93984: ldr     x19, [x19, #0x10]                          .androidFsnAd
02c93988: cbz     x19, #0x2c93a0c                            
02c9398c: adrp    x8, #0x6263000                             
02c93990: ldr     x8, [x8, #0xb70]                           MS:System.Array::Empty
02c93994: ldr     x20, [x8]                                  &2c5bbd4(=a9bd7bfdd503233f)
02c93998: ldr     x8, [x20, #0x38]                           [662f038]=6000016 f=2.40742e-35,0
02c9399c: cbnz    x8, #0x2c939ac                             
02c939a0: mov     x0, x20                                    
02c939a4: bl      #0x2ba9d7c                                 fn_2ba9d7c
02c939a8: ldr     x8, [x20, #0x38]                           [662f038]=6000016 f=2.40742e-35,0
02c939ac: ldr     x0, [x8, #0x10]                            &2c498bc(=aa1f03e0d503245f)
02c939b0: add     x8, x0, #0x135                             &6265135
02c939b4: ldrh    w8, [x8]                                   
02c939b8: tbnz    w8, #0, #0x2c939c0                         
02c939bc: bl      #0x2ba9d20                                 fn_2ba9d20
02c939c0: ldr     w8, [x0, #0xe4]                            [62650e4]=0 f=0,0
02c939c4: cbnz    w8, #0x2c939cc                             
02c939c8: bl      #0x2b70f30                                 fn_2b70f30
02c939cc: ldr     x8, [x20, #0x38]                           [662f038]=6000016 f=2.40742e-35,0
02c939d0: ldr     x0, [x8, #0x10]                            &2c498bc(=aa1f03e0d503245f)
02c939d4: add     x8, x0, #0x135                             &6265135
02c939d8: ldrh    w8, [x8]                                   
02c939dc: tbnz    w8, #0, #0x2c939e4                         
02c939e0: bl      #0x2ba9d20                                 fn_2ba9d20
02c939e4: adrp    x9, #0x6265000                             
02c939e8: ldr     x8, [x0, #0xb8]                            T:AdsManager/<>c__DisplayClass42_0
02c939ec: mov     x0, x19                                    
02c939f0: ldr     x9, [x9, #0x758]                           S:'HideAd'
02c939f4: ldp     x20, x19, [sp, #0x10]                      
02c939f8: ldr     x2, [x8]                                   &2c5bbd4(=a9bd7bfdd503233f)
02c939fc: mov     x3, xzr                                    
02c93a00: ldr     x1, [x9]                                   M:AdsManager::<OnApplicationPause>b__26_0
02c93a04: ldp     x30, x21, [sp], #0x20                      
02c93a08: b       #0x5ad5e34                                 UnityEngine.AndroidJavaObject::Call
02c93a0c: ldp     x20, x19, [sp, #0x10]                      
02c93a10: ldp     x30, x21, [sp], #0x20                      
02c93a14: ret                                                
## IsAdReady() -> bool
---- FsnAd::IsAdReady 0x2c93a18
02c93a18: stp     x30, x21, [sp, #-0x20]!                    
02c93a1c: stp     x20, x19, [sp, #0x10]                      
02c93a20: adrp    x20, #0x662f000                            
02c93a24: mov     x19, x0                                    
02c93a28: ldrb    w8, [x20, #0x9e1]                          
02c93a2c: tbnz    w8, #0, #0x2c93a5c                         
02c93a30: adrp    x0, #0x6265000                             
02c93a34: ldr     x0, [x0, #0x760]                           MS:UnityEngine.AndroidJavaObject::Call
02c93a38: bl      #0x2b70db0                                 fn_2b70db0
02c93a3c: adrp    x0, #0x6263000                             
02c93a40: ldr     x0, [x0, #0xb70]                           MS:System.Array::Empty
02c93a44: bl      #0x2b70db0                                 fn_2b70db0
02c93a48: adrp    x0, #0x6265000                             
02c93a4c: ldr     x0, [x0, #0x768]                           S:'IsAdReady'
02c93a50: bl      #0x2b70db0                                 fn_2b70db0
02c93a54: mov     w8, #1                                     
02c93a58: strb    w8, [x20, #0x9e1]                          
02c93a5c: ldr     x19, [x19, #0x10]                          .androidFsnAd
02c93a60: cbz     x19, #0x2c93aec                            
02c93a64: adrp    x8, #0x6263000                             
02c93a68: ldr     x8, [x8, #0xb70]                           MS:System.Array::Empty
02c93a6c: ldr     x20, [x8]                                  &2c5bbd4(=a9bd7bfdd503233f)
02c93a70: ldr     x8, [x20, #0x38]                           [662f038]=6000016 f=2.40742e-35,0
02c93a74: cbnz    x8, #0x2c93a84                             
02c93a78: mov     x0, x20                                    
02c93a7c: bl      #0x2ba9d7c                                 fn_2ba9d7c
02c93a80: ldr     x8, [x20, #0x38]                           [662f038]=6000016 f=2.40742e-35,0
02c93a84: ldr     x0, [x8, #0x10]                            &2c498bc(=aa1f03e0d503245f)
02c93a88: add     x8, x0, #0x135                             &6265135
02c93a8c: ldrh    w8, [x8]                                   
02c93a90: tbnz    w8, #0, #0x2c93a98                         
02c93a94: bl      #0x2ba9d20                                 fn_2ba9d20
02c93a98: ldr     w8, [x0, #0xe4]                            [62650e4]=0 f=0,0
02c93a9c: cbnz    w8, #0x2c93aa4                             
02c93aa0: bl      #0x2b70f30                                 fn_2b70f30
02c93aa4: ldr     x8, [x20, #0x38]                           [662f038]=6000016 f=2.40742e-35,0
02c93aa8: adrp    x20, #0x6265000                            
02c93aac: adrp    x21, #0x6265000                            
02c93ab0: ldr     x0, [x8, #0x10]                            &2c498bc(=aa1f03e0d503245f)
02c93ab4: ldr     x20, [x20, #0x768]                         S:'IsAdReady'
02c93ab8: add     x8, x0, #0x135                             &6265135
02c93abc: ldrh    w8, [x8]                                   
02c93ac0: ldr     x21, [x21, #0x760]                         MS:UnityEngine.AndroidJavaObject::Call
02c93ac4: tbnz    w8, #0, #0x2c93acc                         
02c93ac8: bl      #0x2ba9d20                                 fn_2ba9d20
02c93acc: ldr     x8, [x0, #0xb8]                            T:AdsManager/<>c__DisplayClass42_0
02c93ad0: ldr     x1, [x20]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c93ad4: mov     x0, x19                                    
02c93ad8: ldp     x20, x19, [sp, #0x10]                      
02c93adc: ldr     x3, [x21]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c93ae0: ldr     x2, [x8]                                   &2c5bbd4(=a9bd7bfdd503233f)
02c93ae4: ldp     x30, x21, [sp], #0x20                      
02c93ae8: b       #0x311f6d4                                 
02c93aec: ldp     x20, x19, [sp, #0x10]                      
02c93af0: mov     w0, wzr                                    
02c93af4: ldp     x30, x21, [sp], #0x20                      
02c93af8: ret                                                
## IsAdLoading() -> bool
---- FsnAd::IsAdLoading 0x2c93afc
02c93afc: stp     x30, x21, [sp, #-0x20]!                    
02c93b00: stp     x20, x19, [sp, #0x10]                      
02c93b04: adrp    x20, #0x662f000                            
02c93b08: mov     x19, x0                                    
02c93b0c: ldrb    w8, [x20, #0x9e2]                          
02c93b10: tbnz    w8, #0, #0x2c93b40                         
02c93b14: adrp    x0, #0x6265000                             
02c93b18: ldr     x0, [x0, #0x760]                           MS:UnityEngine.AndroidJavaObject::Call
02c93b1c: bl      #0x2b70db0                                 fn_2b70db0
02c93b20: adrp    x0, #0x6263000                             
02c93b24: ldr     x0, [x0, #0xb70]                           MS:System.Array::Empty
02c93b28: bl      #0x2b70db0                                 fn_2b70db0
02c93b2c: adrp    x0, #0x6265000                             
02c93b30: ldr     x0, [x0, #0x770]                           S:'IsAdLoading'
02c93b34: bl      #0x2b70db0                                 fn_2b70db0
02c93b38: mov     w8, #1                                     
02c93b3c: strb    w8, [x20, #0x9e2]                          
02c93b40: ldr     x19, [x19, #0x10]                          .androidFsnAd
02c93b44: cbz     x19, #0x2c93bd0                            
02c93b48: adrp    x8, #0x6263000                             
02c93b4c: ldr     x8, [x8, #0xb70]                           MS:System.Array::Empty
02c93b50: ldr     x20, [x8]                                  &2c5bbd4(=a9bd7bfdd503233f)
02c93b54: ldr     x8, [x20, #0x38]                           [662f038]=6000016 f=2.40742e-35,0
02c93b58: cbnz    x8, #0x2c93b68                             
02c93b5c: mov     x0, x20                                    
02c93b60: bl      #0x2ba9d7c                                 fn_2ba9d7c
02c93b64: ldr     x8, [x20, #0x38]                           [662f038]=6000016 f=2.40742e-35,0
02c93b68: ldr     x0, [x8, #0x10]                            &2c498bc(=aa1f03e0d503245f)
02c93b6c: add     x8, x0, #0x135                             &6265135
02c93b70: ldrh    w8, [x8]                                   
02c93b74: tbnz    w8, #0, #0x2c93b7c                         
02c93b78: bl      #0x2ba9d20                                 fn_2ba9d20
02c93b7c: ldr     w8, [x0, #0xe4]                            [62650e4]=0 f=0,0
02c93b80: cbnz    w8, #0x2c93b88                             
02c93b84: bl      #0x2b70f30                                 fn_2b70f30
02c93b88: ldr     x8, [x20, #0x38]                           [662f038]=6000016 f=2.40742e-35,0
02c93b8c: adrp    x20, #0x6265000                            
02c93b90: adrp    x21, #0x6265000                            
02c93b94: ldr     x0, [x8, #0x10]                            &2c498bc(=aa1f03e0d503245f)
02c93b98: ldr     x20, [x20, #0x770]                         S:'IsAdLoading'
02c93b9c: add     x8, x0, #0x135                             &6265135
02c93ba0: ldrh    w8, [x8]                                   
02c93ba4: ldr     x21, [x21, #0x760]                         MS:UnityEngine.AndroidJavaObject::Call
02c93ba8: tbnz    w8, #0, #0x2c93bb0                         
02c93bac: bl      #0x2ba9d20                                 fn_2ba9d20
02c93bb0: ldr     x8, [x0, #0xb8]                            T:AdsManager/<>c__DisplayClass42_0
02c93bb4: ldr     x1, [x20]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c93bb8: mov     x0, x19                                    
02c93bbc: ldp     x20, x19, [sp, #0x10]                      
02c93bc0: ldr     x3, [x21]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c93bc4: ldr     x2, [x8]                                   &2c5bbd4(=a9bd7bfdd503233f)
02c93bc8: ldp     x30, x21, [sp], #0x20                      
02c93bcc: b       #0x311f6d4                                 
02c93bd0: ldp     x20, x19, [sp, #0x10]                      
02c93bd4: mov     w0, wzr                                    
02c93bd8: ldp     x30, x21, [sp], #0x20                      
02c93bdc: ret                                                
## Release() -> void
---- FsnAd::Release 0x2c93be0
02c93be0: stp     x30, x21, [sp, #-0x20]!                    
02c93be4: stp     x20, x19, [sp, #0x10]                      
02c93be8: adrp    x20, #0x662f000                            
02c93bec: adrp    x21, #0x6264000                            
02c93bf0: mov     x19, x0                                    
02c93bf4: ldrb    w8, [x20, #0x9e3]                          
02c93bf8: ldr     x21, [x21, #0xa70]                         T:UnityEngine.Application
02c93bfc: tbnz    w8, #0, #0x2c93c14                         
02c93c00: adrp    x0, #0x6264000                             
02c93c04: ldr     x0, [x0, #0xa70]                           T:UnityEngine.Application
02c93c08: bl      #0x2b70db0                                 fn_2b70db0
02c93c0c: mov     w8, #1                                     
02c93c10: strb    w8, [x20, #0x9e3]                          
02c93c14: ldr     x0, [x21]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c93c18: ldr     w8, [x0, #0xe4]                            [62640e4]=0 f=0,0
02c93c1c: cbnz    w8, #0x2c93c24                             
02c93c20: bl      #0x2b70f30                                 fn_2b70f30
02c93c24: mov     x0, xzr                                    
02c93c28: bl      #0x5aeb18c                                 UnityEngine.Application::get_platform
02c93c2c: cmp     w0, #0xb                                   
02c93c30: b.ne    #0x2c93c5c                                 
02c93c34: ldr     x0, [x19, #0x10]!                          .androidFsnAd
02c93c38: cbz     x0, #0x2c93c44                             
02c93c3c: mov     x1, xzr                                    
02c93c40: bl      #0x5ad5140                                 UnityEngine.AndroidJavaObject::Dispose
02c93c44: mov     x0, x19                                    
02c93c48: str     xzr, [x19]                                 
02c93c4c: mov     x1, xzr                                    
02c93c50: ldp     x20, x19, [sp, #0x10]                      
02c93c54: ldp     x30, x21, [sp], #0x20                      
02c93c58: b       #0x2b70d54                                 
02c93c5c: ldp     x20, x19, [sp, #0x10]                      
02c93c60: ldp     x30, x21, [sp], #0x20                      
02c93c64: ret                                                
