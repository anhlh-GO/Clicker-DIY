#### CLASS IAPRewardItem parent= object
#   field RewardType                     IAPRewardType                                      off=0x10 attr=6 
#   field Value                          int                                                off=0x14 attr=6 
## .ctor() -> void
---- IAPRewardItem::.ctor 0x2ca49b0
02ca49b0: mov     x1, xzr                                    
02ca49b4: b       #0x4e53e9c                                 System.Object::.ctor
