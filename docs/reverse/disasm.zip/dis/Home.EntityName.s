#### CLASS Home.EntityName parent= int
#   field value__                        int                                                off=0x10 attr=606 
#   field Pet                            Home.EntityName                                    off=0x0 attr=8056 
#   field LuckyWheel                     Home.EntityName                                    off=0x0 attr=8056 
#   field Character                      Home.EntityName                                    off=0x0 attr=8056 
