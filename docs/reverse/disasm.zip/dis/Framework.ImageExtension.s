#### CLASS Framework.ImageExtension parent= object
## SetSizeByWidth(UnityEngine.UI.Image img, float width) -> void
---- Framework.ImageExtension::SetSizeByWidth 0x2cb8b24
02cb8b24: sub     sp, sp, #0x50                              
02cb8b28: str     d10, [sp, #0x20]                           
02cb8b2c: stp     d9, d8, [sp, #0x28]                        
02cb8b30: str     x30, [sp, #0x38]                           
02cb8b34: stp     x20, x19, [sp, #0x40]                      
02cb8b38: fmov    s8, s0                                     
02cb8b3c: adrp    x20, #0x662f000                            
02cb8b40: mov     x19, x0                                    
02cb8b44: ldrb    w8, [x20, #0xbe4]                          
02cb8b48: tbnz    w8, #0, #0x2cb8b60                         
02cb8b4c: adrp    x0, #0x6263000                             
02cb8b50: ldr     x0, [x0, #0x918]                           T:UnityEngine.Object
02cb8b54: bl      #0x2b70db0                                 fn_2b70db0
02cb8b58: mov     w8, #1                                     
02cb8b5c: strb    w8, [x20, #0xbe4]                          
02cb8b60: cbz     x19, #0x2cb8c08                            
02cb8b64: adrp    x8, #0x6263000                             
02cb8b68: ldr     x8, [x8, #0x918]                           T:UnityEngine.Object
02cb8b6c: ldr     x20, [x19, #0xd8]                          
02cb8b70: ldr     x0, [x8]                                   &2c5bbd4(=a9bd7bfdd503233f)
02cb8b74: ldr     w8, [x0, #0xe4]                            [62630e4]=0 f=0,0
02cb8b78: cbnz    w8, #0x2cb8b80                             
02cb8b7c: bl      #0x2b70f30                                 fn_2b70f30
02cb8b80: mov     x0, x20                                    
02cb8b84: mov     x1, xzr                                    
02cb8b88: mov     x2, xzr                                    
02cb8b8c: bl      #0x5b37d84                                 UnityEngine.Object::op_Equality
02cb8b90: tbnz    w0, #0, #0x2cb8bf0                         
02cb8b94: ldr     x20, [x19, #0xd8]                          
02cb8b98: cbz     x20, #0x2cb8c08                            
02cb8b9c: add     x8, sp, #8                                 
02cb8ba0: mov     x0, x20                                    
02cb8ba4: mov     x1, xzr                                    
02cb8ba8: bl      #0x5ae7d34                                 UnityEngine.Sprite::get_bounds
02cb8bac: ldr     s9, [sp, #0x18]                            
02cb8bb0: add     x8, sp, #8                                 
02cb8bb4: mov     x0, x20                                    
02cb8bb8: mov     x1, xzr                                    
02cb8bbc: bl      #0x5ae7d34                                 UnityEngine.Sprite::get_bounds
02cb8bc0: ldr     s10, [sp, #0x14]                           
02cb8bc4: mov     x0, x19                                    
02cb8bc8: mov     x1, xzr                                    
02cb8bcc: bl      #0x5c4e1ac                                 UnityEngine.UI.Graphic::get_rectTransform
02cb8bd0: cbz     x0, #0x2cb8c08                             
02cb8bd4: fadd    s0, s9, s9                                 
02cb8bd8: fadd    s1, s10, s10                               
02cb8bdc: mov     x1, xzr                                    
02cb8be0: fdiv    s0, s0, s1                                 
02cb8be4: fmul    s1, s0, s8                                 
02cb8be8: fmov    s0, s8                                     
02cb8bec: bl      #0x5b45994                                 UnityEngine.RectTransform::set_sizeDelta
02cb8bf0: ldp     x20, x19, [sp, #0x40]                      
02cb8bf4: ldr     x30, [sp, #0x38]                           
02cb8bf8: ldp     d9, d8, [sp, #0x28]                        
02cb8bfc: ldr     d10, [sp, #0x20]                           
02cb8c00: add     sp, sp, #0x50                              
02cb8c04: ret                                                
02cb8c08: bl      #0x2b7105c                                 fn_2b7105c
## SetSizeByHeight(UnityEngine.UI.Image img, float height) -> void
---- Framework.ImageExtension::SetSizeByHeight 0x2cb8c0c
02cb8c0c: sub     sp, sp, #0x50                              
02cb8c10: str     d10, [sp, #0x20]                           
02cb8c14: stp     d9, d8, [sp, #0x28]                        
02cb8c18: str     x30, [sp, #0x38]                           
02cb8c1c: stp     x20, x19, [sp, #0x40]                      
02cb8c20: fmov    s8, s0                                     
02cb8c24: adrp    x20, #0x662f000                            
02cb8c28: mov     x19, x0                                    
02cb8c2c: ldrb    w8, [x20, #0xbe5]                          
02cb8c30: tbnz    w8, #0, #0x2cb8c48                         
02cb8c34: adrp    x0, #0x6263000                             
02cb8c38: ldr     x0, [x0, #0x918]                           T:UnityEngine.Object
02cb8c3c: bl      #0x2b70db0                                 fn_2b70db0
02cb8c40: mov     w8, #1                                     
02cb8c44: strb    w8, [x20, #0xbe5]                          
02cb8c48: cbz     x19, #0x2cb8cf0                            
02cb8c4c: adrp    x8, #0x6263000                             
02cb8c50: ldr     x8, [x8, #0x918]                           T:UnityEngine.Object
02cb8c54: ldr     x20, [x19, #0xd8]                          
02cb8c58: ldr     x0, [x8]                                   &2c5bbd4(=a9bd7bfdd503233f)
02cb8c5c: ldr     w8, [x0, #0xe4]                            [62630e4]=0 f=0,0
02cb8c60: cbnz    w8, #0x2cb8c68                             
02cb8c64: bl      #0x2b70f30                                 fn_2b70f30
02cb8c68: mov     x0, x20                                    
02cb8c6c: mov     x1, xzr                                    
02cb8c70: mov     x2, xzr                                    
02cb8c74: bl      #0x5b37d84                                 UnityEngine.Object::op_Equality
02cb8c78: tbnz    w0, #0, #0x2cb8cd8                         
02cb8c7c: ldr     x20, [x19, #0xd8]                          
02cb8c80: cbz     x20, #0x2cb8cf0                            
02cb8c84: add     x8, sp, #8                                 
02cb8c88: mov     x0, x20                                    
02cb8c8c: mov     x1, xzr                                    
02cb8c90: bl      #0x5ae7d34                                 UnityEngine.Sprite::get_bounds
02cb8c94: ldr     s9, [sp, #0x18]                            
02cb8c98: add     x8, sp, #8                                 
02cb8c9c: mov     x0, x20                                    
02cb8ca0: mov     x1, xzr                                    
02cb8ca4: bl      #0x5ae7d34                                 UnityEngine.Sprite::get_bounds
02cb8ca8: ldr     s10, [sp, #0x14]                           
02cb8cac: mov     x0, x19                                    
02cb8cb0: mov     x1, xzr                                    
02cb8cb4: bl      #0x5c4e1ac                                 UnityEngine.UI.Graphic::get_rectTransform
02cb8cb8: cbz     x0, #0x2cb8cf0                             
02cb8cbc: fadd    s0, s9, s9                                 
02cb8cc0: fadd    s1, s10, s10                               
02cb8cc4: mov     x1, xzr                                    
02cb8cc8: fdiv    s0, s0, s1                                 
02cb8ccc: fmov    s1, s8                                     
02cb8cd0: fdiv    s0, s8, s0                                 
02cb8cd4: bl      #0x5b45994                                 UnityEngine.RectTransform::set_sizeDelta
02cb8cd8: ldp     x20, x19, [sp, #0x40]                      
02cb8cdc: ldr     x30, [sp, #0x38]                           
02cb8ce0: ldp     d9, d8, [sp, #0x28]                        
02cb8ce4: ldr     d10, [sp, #0x20]                           
02cb8ce8: add     sp, sp, #0x50                              
02cb8cec: ret                                                
02cb8cf0: bl      #0x2b7105c                                 fn_2b7105c
## SetAlpha(UnityEngine.UI.Image img, float alpha) -> void
---- Framework.ImageExtension::SetAlpha 0x2cb8cf4
02cb8cf4: str     d8, [sp, #-0x20]!                          
02cb8cf8: stp     x30, x19, [sp, #0x10]                      
02cb8cfc: cbz     x0, #0x2cb8d38                             
02cb8d00: ldr     x8, [x0]                                   
02cb8d04: mov     x19, x0                                    
02cb8d08: fmov    s8, s0                                     
02cb8d0c: ldr     x9, [x8, #0x298]                           
02cb8d10: ldr     x1, [x8, #0x2a0]                           
02cb8d14: blr     x9                                         
02cb8d18: ldr     x8, [x19]                                  
02cb8d1c: mov     x0, x19                                    
02cb8d20: fmov    s3, s8                                     
02cb8d24: ldp     x30, x19, [sp, #0x10]                      
02cb8d28: ldr     x2, [x8, #0x2a8]                           
02cb8d2c: ldr     x1, [x8, #0x2b0]                           
02cb8d30: ldr     d8, [sp], #0x20                            
02cb8d34: br      x2                                         
02cb8d38: bl      #0x2b7105c                                 fn_2b7105c
