#### CLASS Framework.FPSCounter/Anchor parent= int
#   field value__                        int                                                off=0x10 attr=606 
#   field LeftTop                        Framework.FPSCounter/Anchor                        off=0x0 attr=8056 
#   field LeftBottom                     Framework.FPSCounter/Anchor                        off=0x0 attr=8056 
#   field RightTop                       Framework.FPSCounter/Anchor                        off=0x0 attr=8056 
#   field RightBottom                    Framework.FPSCounter/Anchor                        off=0x0 attr=8056 
#### CLASS Framework.FPSCounter parent= UnityEngine.MonoBehaviour
#   field editorOnly                     bool                                               off=0x20 attr=6 
#   field _updateInterval                float                                              off=0x24 attr=1 SeparatorAttribute,SerializeField
#   field _targetFrameRate               int                                                off=0x28 attr=1 SerializeField
#   field _anchor                        Framework.FPSCounter/Anchor                        off=0x2c attr=1 SeparatorAttribute,SerializeField
#   field _xOffset                       int                                                off=0x30 attr=1 SerializeField
#   field _yOffset                       int                                                off=0x34 attr=1 SerializeField
#   field _goodColor                     UnityEngine.Color                                  off=0x38 attr=1 SeparatorAttribute,SerializeField
#   field _okColor                       UnityEngine.Color                                  off=0x48 attr=1 SerializeField
#   field _badColor                      UnityEngine.Color                                  off=0x58 attr=1 SerializeField
#   field _idleTime                      float                                              off=0x68 attr=1 
#   field _elapsed                       float                                              off=0x6c attr=1 
#   field _frames                        int                                                off=0x70 attr=1 
#   field _fps                           float                                              off=0x74 attr=1 
#   field _okFps                         float                                              off=0x78 attr=1 
#   field _badFps                        float                                              off=0x7c attr=1 
#   field _rect                          UnityEngine.Rect                                   off=0x80 attr=1 
#   field _style                         UnityEngine.GUIStyle                               off=0x90 attr=1 
## Awake() -> void
---- Framework.FPSCounter::Awake 0x2cc6474
02cc6474: stp     x30, x21, [sp, #-0x20]!                    
02cc6478: stp     x20, x19, [sp, #0x10]                      
02cc647c: adrp    x20, #0x662f000                            
02cc6480: mov     x19, x0                                    
02cc6484: ldrb    w8, [x20, #0xc53]                          
02cc6488: tbnz    w8, #0, #0x2cc64b8                         
02cc648c: adrp    x0, #0x6264000                             
02cc6490: ldr     x0, [x0, #0xa70]                           T:UnityEngine.Application
02cc6494: bl      #0x2b70db0                                 fn_2b70db0
02cc6498: adrp    x0, #0x6267000                             
02cc649c: ldr     x0, [x0, #0x2b8]                           T:UnityEngine.GUIStyle
02cc64a0: bl      #0x2b70db0                                 fn_2b70db0
02cc64a4: adrp    x0, #0x6263000                             
02cc64a8: ldr     x0, [x0, #0x918]                           T:UnityEngine.Object
02cc64ac: bl      #0x2b70db0                                 fn_2b70db0
02cc64b0: mov     w8, #1                                     
02cc64b4: strb    w8, [x20, #0xc53]                          
02cc64b8: ldrb    w8, [x19, #0x20]                           .editorOnly
02cc64bc: cbz     w8, #0x2cc64e4                             
02cc64c0: adrp    x8, #0x6264000                             
02cc64c4: ldr     x8, [x8, #0xa70]                           T:UnityEngine.Application
02cc64c8: ldr     x0, [x8]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02cc64cc: ldr     w8, [x0, #0xe4]                            [62630e4]=0 f=0,0
02cc64d0: cbnz    w8, #0x2cc64d8                             
02cc64d4: bl      #0x2b70f30                                 fn_2b70f30
02cc64d8: mov     x0, xzr                                    
02cc64dc: bl      #0x5aed094                                 UnityEngine.Application::get_isEditor
02cc64e0: tbz     w0, #0, #0x2cc65ac                         
02cc64e4: adrp    x8, #0x6267000                             
02cc64e8: ldr     x8, [x8, #0x2b8]                           T:UnityEngine.GUIStyle
02cc64ec: ldr     x0, [x8]                                   S:'didu'
02cc64f0: bl      #0x2b7104c                                 fn_2b7104c
02cc64f4: mov     x1, xzr                                    
02cc64f8: mov     x21, x0                                    
02cc64fc: bl      #0x5b97bc0                                 UnityEngine.GUIStyle::.ctor
02cc6500: mov     x20, x19                                   
02cc6504: mov     x1, x21                                    
02cc6508: str     x21, [x20, #0x90]!                         ._style
02cc650c: mov     x0, x20                                    
02cc6510: bl      #0x2b70d54                                 fn_2b70d54
02cc6514: ldr     x0, [x20]                                  &2b706c4(=eb01011ff9400808)
02cc6518: cbz     x0, #0x2cc6634                             
02cc651c: mov     w1, wzr                                    
02cc6520: mov     x2, xzr                                    
02cc6524: bl      #0x5b9a5a8                                 UnityEngine.GUIStyle::set_alignment
02cc6528: ldr     x20, [x20]                                 &2b706c4(=eb01011ff9400808)
02cc652c: mov     x0, xzr                                    
02cc6530: bl      #0x5afb724                                 UnityEngine.Screen::get_height
02cc6534: cbz     x20, #0x2cc6634                            
02cc6538: mov     w8, #0x851f                                
02cc653c: mov     x2, xzr                                    
02cc6540: movk    w8, #0x51eb, lsl #16                       
02cc6544: smull   x8, w0, w8                                 
02cc6548: mov     x0, x20                                    
02cc654c: lsr     x9, x8, #0x3f                              
02cc6550: asr     x8, x8, #0x24                              
02cc6554: add     w1, w8, w9                                 
02cc6558: bl      #0x5b9ad5c                                 UnityEngine.GUIStyle::set_fontSize
02cc655c: ldr     s0, [x19, #0x28]                           ._targetFrameRate
02cc6560: mov     w8, #0x42c80000                            
02cc6564: fmov    s1, w8                                     
02cc6568: adrp    x8, #0x1040000                             
02cc656c: scvtf   s0, s0                                     
02cc6570: ldr     d2, [x8, #0x608]                           [1040608]=c2200000c1200000 f=-10,-40
02cc6574: ldr     w8, [x19, #0x2c]                           ._anchor
02cc6578: orr     w9, w8, #2                                 
02cc657c: cmp     w9, #3                                     
02cc6580: fdiv    s1, s0, s1                                 
02cc6584: dup     v0.2s, v0.s[0]                             
02cc6588: fmul    v1.2s, v2.2s, v1.s[0]                      
02cc658c: fadd    v0.2s, v0.2s, v1.2s                        
02cc6590: str     d0, [x19, #0x78]                           ._okFps
02cc6594: b.ne    #0x2cc65d8                                 
02cc6598: mov     x0, xzr                                    
02cc659c: bl      #0x5afb724                                 UnityEngine.Screen::get_height
02cc65a0: ldr     w8, [x19, #0x2c]                           ._anchor
02cc65a4: sub     w20, w0, #0x28                             
02cc65a8: b       #0x2cc65dc                                 
02cc65ac: adrp    x8, #0x6263000                             
02cc65b0: ldr     x8, [x8, #0x918]                           T:UnityEngine.Object
02cc65b4: ldr     x0, [x8]                                   &2c5bbd4(=a9bd7bfdd503233f)
02cc65b8: ldr     w8, [x0, #0xe4]                            [62630e4]=0 f=0,0
02cc65bc: cbnz    w8, #0x2cc65c4                             
02cc65c0: bl      #0x2b70f30                                 fn_2b70f30
02cc65c4: mov     x0, x19                                    
02cc65c8: ldp     x20, x19, [sp, #0x10]                      
02cc65cc: mov     x1, xzr                                    
02cc65d0: ldp     x30, x21, [sp], #0x20                      
02cc65d4: b       #0x5b3ca38                                 UnityEngine.Object::Destroy
02cc65d8: mov     w20, wzr                                   
02cc65dc: and     w8, w8, #0xfffffffe                        
02cc65e0: cmp     w8, #2                                     
02cc65e4: b.ne    #0x2cc65f8                                 
02cc65e8: mov     x0, xzr                                    
02cc65ec: bl      #0x5afb6fc                                 UnityEngine.Screen::get_width
02cc65f0: sub     w8, w0, #0xaa                              
02cc65f4: b       #0x2cc65fc                                 
02cc65f8: mov     w8, wzr                                    
02cc65fc: ldp     w9, w10, [x19, #0x30]                      ._xOffset
02cc6600: add     w8, w9, w8                                 
02cc6604: adrp    x9, #0x1040000                             
02cc6608: add     w10, w10, w20                              
02cc660c: scvtf   s0, w8                                     
02cc6610: ldr     d1, [x9, #0x938]                           [1040938]=42200000432a0000 f=170,40
02cc6614: scvtf   s2, w10                                    
02cc6618: str     d1, [x19, #0x88]                           
02cc661c: ldr     s1, [x19, #0x24]                           ._updateInterval
02cc6620: stp     s0, s2, [x19, #0x80]                       ._rect
02cc6624: str     s1, [x19, #0x6c]                           ._elapsed
02cc6628: ldp     x20, x19, [sp, #0x10]                      
02cc662c: ldp     x30, x21, [sp], #0x20                      
02cc6630: ret                                                
02cc6634: bl      #0x2b7105c                                 fn_2b7105c
## Update() -> void
---- Framework.FPSCounter::Update 0x2cc6638
02cc6638: sub     sp, sp, #0x30                              
02cc663c: str     d8, [sp, #0x10]                            
02cc6640: str     x30, [sp, #0x18]                           
02cc6644: stp     x20, x19, [sp, #0x20]                      
02cc6648: adrp    x20, #0x662f000                            
02cc664c: mov     x19, x0                                    
02cc6650: ldrb    w8, [x20, #0xc54]                          
02cc6654: tbnz    w8, #0, #0x2cc666c                         
02cc6658: adrp    x0, #0x6264000                             
02cc665c: ldr     x0, [x0, #0xa70]                           T:UnityEngine.Application
02cc6660: bl      #0x2b70db0                                 fn_2b70db0
02cc6664: mov     w8, #1                                     
02cc6668: strb    w8, [x20, #0xc54]                          
02cc666c: ldrb    w8, [x19, #0x20]                           .editorOnly
02cc6670: cbz     w8, #0x2cc6698                             
02cc6674: adrp    x8, #0x6264000                             
02cc6678: ldr     x8, [x8, #0xa70]                           T:UnityEngine.Application
02cc667c: ldr     x0, [x8]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02cc6680: ldr     w8, [x0, #0xe4]                            [62640e4]=0 f=0,0
02cc6684: cbnz    w8, #0x2cc668c                             
02cc6688: bl      #0x2b70f30                                 fn_2b70f30
02cc668c: mov     x0, xzr                                    
02cc6690: bl      #0x5aed094                                 UnityEngine.Application::get_isEditor
02cc6694: tbz     w0, #0, #0x2cc6768                         
02cc6698: ldr     s8, [x19, #0x68]                           ._idleTime
02cc669c: fcmp    s8, #0.0                                   
02cc66a0: b.le    #0x2cc66b8                                 
02cc66a4: mov     x0, xzr                                    
02cc66a8: bl      #0x5b433a4                                 UnityEngine.Time::get_deltaTime
02cc66ac: fsub    s0, s8, s0                                 
02cc66b0: str     s0, [x19, #0x68]                           ._idleTime
02cc66b4: b       #0x2cc6768                                 
02cc66b8: ldr     s8, [x19, #0x6c]                           ._elapsed
02cc66bc: mov     x0, xzr                                    
02cc66c0: bl      #0x5b433a4                                 UnityEngine.Time::get_deltaTime
02cc66c4: fadd    s0, s8, s0                                 
02cc66c8: ldr     s1, [x19, #0x24]                           ._updateInterval
02cc66cc: ldr     w8, [x19, #0x70]                           ._frames
02cc66d0: add     w8, w8, #1                                 
02cc66d4: str     w8, [x19, #0x70]                           ._frames
02cc66d8: fcmp    s0, s1                                     
02cc66dc: str     s0, [x19, #0x6c]                           ._elapsed
02cc66e0: b.lt    #0x2cc6768                                 
02cc66e4: scvtf   s1, w8                                     
02cc66e8: add     x0, sp, #8                                 
02cc66ec: fdiv    s8, s1, s0                                 
02cc66f0: fcvt    d0, s8                                     
02cc66f4: bl      #0x5e902c0                                 fn_5e902c0
02cc66f8: fcmp    s8, #0.0                                   
02cc66fc: b.ge    #0x2cc6718                                 
02cc6700: fmov    d1, #-0.50000000                           
02cc6704: fcmp    d0, d1                                     
02cc6708: b.ne    #0x2cc6744                                 
02cc670c: ldr     d0, [sp, #8]                               
02cc6710: fmov    s2, #-1.00000000                           
02cc6714: b       #0x2cc672c                                 
02cc6718: fmov    d1, #0.50000000                            
02cc671c: fcmp    d0, d1                                     
02cc6720: b.ne    #0x2cc6754                                 
02cc6724: ldr     d0, [sp, #8]                               
02cc6728: fmov    s2, #1.00000000                            
02cc672c: fcvt    s1, d0                                     
02cc6730: fcvtzs  x8, d0                                     
02cc6734: fadd    s0, s1, s2                                 
02cc6738: tst     x8, #1                                     
02cc673c: fcsel   s0, s1, s0, eq                             
02cc6740: b       #0x2cc6760                                 
02cc6744: fmov    s0, #-0.50000000                           
02cc6748: fadd    s0, s8, s0                                 
02cc674c: frintp  s0, s0                                     
02cc6750: b       #0x2cc6760                                 
02cc6754: fmov    s0, #0.50000000                            
02cc6758: fadd    s0, s8, s0                                 
02cc675c: frintm  s0, s0                                     
02cc6760: str     s0, [x19, #0x74]                           ._fps
02cc6764: stur    xzr, [x19, #0x6c]                          ._elapsed
02cc6768: ldp     x20, x19, [sp, #0x20]                      
02cc676c: ldr     x30, [sp, #0x18]                           
02cc6770: ldr     d8, [sp, #0x10]                            
02cc6774: add     sp, sp, #0x30                              
02cc6778: ret                                                
## OnGUI() -> void
---- Framework.FPSCounter::OnGUI 0x2cc677c
02cc677c: sub     sp, sp, #0x50                              
02cc6780: stp     d11, d10, [sp, #0x10]                      
02cc6784: stp     d9, d8, [sp, #0x20]                        
02cc6788: stp     x30, x21, [sp, #0x30]                      
02cc678c: stp     x20, x19, [sp, #0x40]                      
02cc6790: adrp    x20, #0x662f000                            
02cc6794: mov     x19, x0                                    
02cc6798: ldrb    w8, [x20, #0xc55]                          
02cc679c: tbnz    w8, #0, #0x2cc67cc                         
02cc67a0: adrp    x0, #0x6264000                             
02cc67a4: ldr     x0, [x0, #0xa70]                           T:UnityEngine.Application
02cc67a8: bl      #0x2b70db0                                 fn_2b70db0
02cc67ac: adrp    x0, #0x6267000                             
02cc67b0: ldr     x0, [x0, #0x2c0]                           T:UnityEngine.GUI
02cc67b4: bl      #0x2b70db0                                 fn_2b70db0
02cc67b8: adrp    x0, #0x6267000                             
02cc67bc: ldr     x0, [x0, #0x2c8]                           S:'FPS: '
02cc67c0: bl      #0x2b70db0                                 fn_2b70db0
02cc67c4: mov     w8, #1                                     
02cc67c8: strb    w8, [x20, #0xc55]                          
02cc67cc: ldrb    w8, [x19, #0x20]                           .editorOnly
02cc67d0: str     wzr, [sp, #0xc]                            
02cc67d4: cbz     w8, #0x2cc67fc                             
02cc67d8: adrp    x8, #0x6264000                             
02cc67dc: ldr     x8, [x8, #0xa70]                           T:UnityEngine.Application
02cc67e0: ldr     x0, [x8]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02cc67e4: ldr     w8, [x0, #0xe4]                            [62670e4]=0 f=0,0
02cc67e8: cbnz    w8, #0x2cc67f0                             
02cc67ec: bl      #0x2b70f30                                 fn_2b70f30
02cc67f0: mov     x0, xzr                                    
02cc67f4: bl      #0x5aed094                                 UnityEngine.Application::get_isEditor
02cc67f8: tbz     w0, #0, #0x2cc6944                         
02cc67fc: ldp     s0, s1, [x19, #0x74]                       ._fps
02cc6800: fcmp    s0, s1                                     
02cc6804: b.ls    #0x2cc681c                                 
02cc6808: add     x8, x19, #0x38                             
02cc680c: add     x9, x19, #0x3c                             
02cc6810: add     x10, x19, #0x40                            
02cc6814: add     x11, x19, #0x44                            
02cc6818: b       #0x2cc682c                                 
02cc681c: add     x8, x19, #0x48                             
02cc6820: add     x9, x19, #0x4c                             
02cc6824: add     x10, x19, #0x50                            
02cc6828: add     x11, x19, #0x54                            
02cc682c: ldr     s1, [x19, #0x7c]                           ._badFps
02cc6830: fcmp    s0, s1                                     
02cc6834: b.hi    #0x2cc6848                                 
02cc6838: add     x8, x19, #0x58                             
02cc683c: add     x9, x19, #0x5c                             
02cc6840: add     x10, x19, #0x60                            
02cc6844: add     x11, x19, #0x64                            
02cc6848: ldr     x0, [x19, #0x90]                           ._style
02cc684c: cbz     x0, #0x2cc695c                             
02cc6850: ldr     s8, [x8]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02cc6854: ldr     s9, [x9]                                   
02cc6858: mov     x1, xzr                                    
02cc685c: ldr     s10, [x10]                                 
02cc6860: ldr     s11, [x11]                                 
02cc6864: bl      #0x5b99850                                 UnityEngine.GUIStyle::get_normal
02cc6868: cbz     x0, #0x2cc695c                             
02cc686c: fmov    s0, s8                                     
02cc6870: fmov    s1, s9                                     
02cc6874: adrp    x20, #0x6267000                            
02cc6878: fmov    s2, s10                                    
02cc687c: fmov    s3, s11                                    
02cc6880: adrp    x21, #0x6267000                            
02cc6884: ldr     x20, [x20, #0x2c8]                         S:'FPS: '
02cc6888: ldr     x21, [x21, #0x2c0]                         T:UnityEngine.GUI
02cc688c: mov     x1, xzr                                    
02cc6890: bl      #0x5b998a0                                 UnityEngine.GUIStyleState::set_textColor
02cc6894: mov     w8, #0x7f800000                            
02cc6898: ldr     s0, [x19, #0x74]                           ._fps
02cc689c: add     x0, sp, #0xc                               
02cc68a0: fmov    s1, w8                                     
02cc68a4: ldp     s8, s9, [x19, #0x80]                       ._rect
02cc68a8: fcvtzs  w9, s0                                     
02cc68ac: mov     w8, #-0xffffffff80000000                   
02cc68b0: mov     x1, xzr                                    
02cc68b4: ldp     s10, s11, [x19, #0x88]                     
02cc68b8: fcmp    s0, s1                                     
02cc68bc: csel    w8, w8, w9, eq                             
02cc68c0: str     w8, [sp, #0xc]                             
02cc68c4: bl      #0x4e0ea3c                                 System.Int32::ToString
02cc68c8: ldr     x8, [x20]                                  S:'didu'
02cc68cc: mov     x1, x0                                     
02cc68d0: mov     x2, xzr                                    
02cc68d4: mov     x0, x8                                     
02cc68d8: bl      #0x4c9c514                                 System.String::Concat
02cc68dc: ldr     x8, [x21]                                  S:'didu'
02cc68e0: ldr     x20, [x19, #0x90]                          ._style
02cc68e4: mov     x21, x0                                    
02cc68e8: ldr     w9, [x8, #0xe4]                            [62640e4]=0 f=0,0
02cc68ec: cbnz    w9, #0x2cc68f8                             
02cc68f0: mov     x0, x8                                     
02cc68f4: bl      #0x2b70f30                                 fn_2b70f30
02cc68f8: fmov    s0, s8                                     
02cc68fc: fmov    s1, s9                                     
02cc6900: mov     x0, x21                                    
02cc6904: fmov    s2, s10                                    
02cc6908: fmov    s3, s11                                    
02cc690c: mov     x1, x20                                    
02cc6910: mov     x2, xzr                                    
02cc6914: bl      #0x5b8ce7c                                 UnityEngine.GUI::Label
02cc6918: ldr     x0, [x19, #0x90]                           ._style
02cc691c: cbz     x0, #0x2cc695c                             
02cc6920: mov     x1, xzr                                    
02cc6924: bl      #0x5b99850                                 UnityEngine.GUIStyle::get_normal
02cc6928: mov     x19, x0                                    
02cc692c: mov     x0, xzr                                    
02cc6930: bl      #0x5b8baf8                                 UnityEngine.GUI::get_color
02cc6934: cbz     x19, #0x2cc695c                            
02cc6938: mov     x0, x19                                    
02cc693c: mov     x1, xzr                                    
02cc6940: bl      #0x5b998a0                                 UnityEngine.GUIStyleState::set_textColor
02cc6944: ldp     x20, x19, [sp, #0x40]                      
02cc6948: ldp     x30, x21, [sp, #0x30]                      
02cc694c: ldp     d9, d8, [sp, #0x20]                        
02cc6950: ldp     d11, d10, [sp, #0x10]                      
02cc6954: add     sp, sp, #0x50                              
02cc6958: ret                                                
02cc695c: bl      #0x2b7105c                                 fn_2b7105c
## .ctor() -> void
---- Framework.FPSCounter::.ctor 0x2cc6960
02cc6960: stp     x30, x21, [sp, #-0x20]!                    
02cc6964: stp     x20, x19, [sp, #0x10]                      
02cc6968: adrp    x21, #0x662f000                            
02cc696c: adrp    x20, #0x6266000                            
02cc6970: mov     x19, x0                                    
02cc6974: ldrb    w8, [x21, #0xc56]                          
02cc6978: ldr     x20, [x20, #0xfd0]                         T:Framework.ColorHelper
02cc697c: tbnz    w8, #0, #0x2cc6994                         
02cc6980: adrp    x0, #0x6266000                             
02cc6984: ldr     x0, [x0, #0xfd0]                           T:Framework.ColorHelper
02cc6988: bl      #0x2b70db0                                 fn_2b70db0
02cc698c: mov     w8, #1                                     
02cc6990: strb    w8, [x21, #0xc56]                          
02cc6994: mov     x8, #0x3f800000                            
02cc6998: ldr     x0, [x20]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cc699c: movk    x8, #0x3c, lsl #32                         
02cc69a0: stur    x8, [x19, #0x24]                           ._updateInterval
02cc69a4: ldr     w8, [x0, #0xe4]                            [62660e4]=0 f=0,0
02cc69a8: cbnz    w8, #0x2cc69b4                             
02cc69ac: bl      #0x2b70f30                                 fn_2b70f30
02cc69b0: ldr     x0, [x20]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cc69b4: ldr     x8, [x0, #0xb8]                            S:'banner_native_refresh_time'
02cc69b8: mov     x1, xzr                                    
02cc69bc: ldr     q0, [x8, #0x4c0]                           
02cc69c0: stur    q0, [x19, #0x38]                           ._goodColor
02cc69c4: ldr     x8, [x0, #0xb8]                            S:'banner_native_refresh_time'
02cc69c8: ldr     q0, [x8, #0x8a0]                           
02cc69cc: stur    q0, [x19, #0x48]                           ._okColor
02cc69d0: ldr     x8, [x0, #0xb8]                            S:'banner_native_refresh_time'
02cc69d4: mov     x0, x19                                    
02cc69d8: ldr     q0, [x8, #0x710]                           
02cc69dc: mov     w8, #0x40000000                            
02cc69e0: str     w8, [x19, #0x68]                           ._idleTime
02cc69e4: stur    q0, [x19, #0x58]                           ._badColor
02cc69e8: ldp     x20, x19, [sp, #0x10]                      
02cc69ec: ldp     x30, x21, [sp], #0x20                      
02cc69f0: b       #0x5b397b0                                 UnityEngine.MonoBehaviour::.ctor
