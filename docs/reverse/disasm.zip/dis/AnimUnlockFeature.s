#### CLASS AnimUnlockFeature/<>c__DisplayClass19_0 parent= object
#   field <>4__this                      AnimUnlockFeature                                  off=0x10 attr=6 
#   field destination                    UnityEngine.UI.Image                               off=0x18 attr=6 
#   field onDone                         System.Action                                      off=0x20 attr=6 
#   field <>9__1                         DG.Tweening.TweenCallback                          off=0x28 attr=6 
## .ctor() -> void
---- AnimUnlockFeature/<>c__DisplayClass19_0::.ctor 0x2caf738
02caf738: mov     x1, xzr                                    
02caf73c: b       #0x4e53e9c                                 System.Object::.ctor
## <AnimFlyToPos>b__0() -> void
---- AnimUnlockFeature/<>c__DisplayClass19_0::<AnimFlyToPos>b__0 0x2caf978
02caf978: stp     x30, x23, [sp, #-0x30]!                    
02caf97c: stp     x22, x21, [sp, #0x10]                      
02caf980: stp     x20, x19, [sp, #0x20]                      
02caf984: adrp    x20, #0x662f000                            
02caf988: mov     x19, x0                                    
02caf98c: ldrb    w8, [x20, #0xb5c]                          
02caf990: tbnz    w8, #0, #0x2caf9cc                         
02caf994: adrp    x0, #0x6264000                             
02caf998: ldr     x0, [x0, #0xe8]                            T:DG.Tweening.TweenCallback
02caf99c: bl      #0x2b70db0                                 fn_2b70db0
02caf9a0: adrp    x0, #0x6266000                             
02caf9a4: ldr     x0, [x0, #0x928]                           MS:DG.Tweening.TweenSettingsExtensions::OnComplete
02caf9a8: bl      #0x2b70db0                                 fn_2b70db0
02caf9ac: adrp    x0, #0x6266000                             
02caf9b0: ldr     x0, [x0, #0x880]                           MS:DG.Tweening.TweenSettingsExtensions::SetEase
02caf9b4: bl      #0x2b70db0                                 fn_2b70db0
02caf9b8: adrp    x0, #0x6266000                             
02caf9bc: ldr     x0, [x0, #0x9b0]                           M:AnimUnlockFeature/<>c__DisplayClass19_0::<AnimFlyToPos>b__1
02caf9c0: bl      #0x2b70db0                                 fn_2b70db0
02caf9c4: mov     w8, #1                                     
02caf9c8: strb    w8, [x20, #0xb5c]                          
02caf9cc: ldr     x8, [x19, #0x10]                           .<>4__this
02caf9d0: cbz     x8, #0x2cafaa4                             
02caf9d4: ldr     x0, [x8, #0x68]                            
02caf9d8: cbz     x0, #0x2cafaa4                             
02caf9dc: mov     x1, xzr                                    
02caf9e0: bl      #0x5c4e1ac                                 UnityEngine.UI.Graphic::get_rectTransform
02caf9e4: ldr     x8, [x19, #0x18]                           .destination
02caf9e8: cbz     x8, #0x2cafaa4                             
02caf9ec: mov     x20, x0                                    
02caf9f0: ldr     x21, [x19, #0x10]                          .<>4__this
02caf9f4: mov     x0, x8                                     
02caf9f8: mov     x1, xzr                                    
02caf9fc: bl      #0x5c4e1ac                                 UnityEngine.UI.Graphic::get_rectTransform
02cafa00: cbz     x21, #0x2cafaa4                            
02cafa04: adrp    x21, #0x6266000                            
02cafa08: adrp    x23, #0x6266000                            
02cafa0c: mov     x1, x0                                     
02cafa10: ldr     x21, [x21, #0x880]                         MS:DG.Tweening.TweenSettingsExtensions::SetEase
02cafa14: ldr     x23, [x23, #0x928]                         MS:DG.Tweening.TweenSettingsExtensions::OnComplete
02cafa18: bl      #0x2caf740                                 AnimUnlockFeature::GetWorldCenter
02cafa1c: fmov    s3, #1.00000000                            
02cafa20: mov     x0, x20                                    
02cafa24: mov     w1, wzr                                    
02cafa28: mov     x2, xzr                                    
02cafa2c: bl      #0x2d975e4                                 DG.Tweening.ShortcutExtensions::DOMove
02cafa30: ldr     x2, [x21]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cafa34: mov     w1, #0x1a                                  
02cafa38: bl      #0x336fa0c                                 fn_336fa0c
02cafa3c: mov     x21, x19                                   
02cafa40: mov     x20, x0                                    
02cafa44: ldr     x22, [x21, #0x28]!                         S:'banner_ad_on_off' .<>9__1
02cafa48: cbnz    x22, #0x2cafa88                            
02cafa4c: adrp    x8, #0x6264000                             
02cafa50: ldr     x8, [x8, #0xe8]                            T:DG.Tweening.TweenCallback
02cafa54: ldr     x0, [x8]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02cafa58: bl      #0x2b7104c                                 fn_2b7104c
02cafa5c: adrp    x8, #0x6266000                             
02cafa60: mov     x1, x19                                    
02cafa64: mov     x3, xzr                                    
02cafa68: ldr     x8, [x8, #0x9b0]                           M:AnimUnlockFeature/<>c__DisplayClass19_0::<AnimFlyToPos>b__1
02cafa6c: mov     x22, x0                                    
02cafa70: ldr     x2, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cafa74: bl      #0x2d89dc4                                 DG.Tweening.TweenCallback::.ctor
02cafa78: mov     x0, x21                                    
02cafa7c: mov     x1, x22                                    
02cafa80: str     x22, [x19, #0x28]                          .<>9__1
02cafa84: bl      #0x2b70d54                                 fn_2b70d54
02cafa88: mov     x0, x20                                    
02cafa8c: mov     x1, x22                                    
02cafa90: ldr     x2, [x23]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cafa94: ldp     x20, x19, [sp, #0x20]                      
02cafa98: ldp     x22, x21, [sp, #0x10]                      
02cafa9c: ldp     x30, x23, [sp], #0x30                      
02cafaa0: b       #0x336f26c                                 
02cafaa4: bl      #0x2b7105c                                 fn_2b7105c
## <AnimFlyToPos>b__1() -> void
---- AnimUnlockFeature/<>c__DisplayClass19_0::<AnimFlyToPos>b__1 0x2cafaa8
02cafaa8: stp     x30, x19, [sp, #-0x10]!                    
02cafaac: ldr     x8, [x0, #0x20]                            .onDone
02cafab0: mov     x19, x0                                    
02cafab4: cbz     x8, #0x2cafac8                             
02cafab8: ldr     x9, [x8, #0x18]                            
02cafabc: ldr     x0, [x8, #0x40]                            
02cafac0: ldr     x1, [x8, #0x28]                            
02cafac4: blr     x9                                         
02cafac8: ldr     x8, [x19, #0x10]                           .<>4__this
02cafacc: cbz     x8, #0x2cafaf4                             
02cafad0: ldr     x0, [x8, #0x68]                            
02cafad4: cbz     x0, #0x2cafaf4                             
02cafad8: mov     x1, xzr                                    
02cafadc: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02cafae0: movi    d0, #0000000000000000                      
02cafae4: movi    d1, #0000000000000000                      
02cafae8: mov     x1, xzr                                    
02cafaec: ldp     x30, x19, [sp], #0x10                      
02cafaf0: b       #0x2d98c98                                 DG.Tweening.ShortcutExtensions::DOScale
02cafaf4: bl      #0x2b7105c                                 fn_2b7105c
#### CLASS AnimUnlockFeature parent= UnityEngine.MonoBehaviour
#   field _btnPartTime                   HomeButton                                         off=0x20 attr=1 SerializeField
#   field _btnLuckyScoop                 HomeButton                                         off=0x28 attr=1 SerializeField
#   field _btnDreamHouse                 HomeButton                                         off=0x30 attr=1 SerializeField
#   field _btnDecor                      HomeButton                                         off=0x38 attr=1 SerializeField
#   field _btnDailyTask                  HomeButton                                         off=0x40 attr=1 SerializeField
#   field _btnLoginTime                  HomeButton                                         off=0x48 attr=1 SerializeField
#   field _btnBlindBag                   HomeButton                                         off=0x50 attr=1 SerializeField
#   field _btnDumplingBlindBox           HomeButton                                         off=0x58 attr=1 SerializeField
#   field _goCover                       UnityEngine.GameObject                             off=0x60 attr=1 SerializeField
#   field _imgTutorial                   UnityEngine.UI.Image                               off=0x68 attr=1 SerializeField
## Awake() -> void
---- AnimUnlockFeature::Awake 0x2caee40
02caee40: str     x30, [sp, #-0x20]!                         
02caee44: stp     x20, x19, [sp, #0x10]                      
02caee48: mov     x19, x0                                    
02caee4c: ldr     x0, [x0, #0x60]                            ._goCover
02caee50: cbz     x0, #0x2caeec4                             
02caee54: mov     w1, wzr                                    
02caee58: mov     x2, xzr                                    
02caee5c: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02caee60: ldr     x0, [x19, #0x68]                           ._imgTutorial
02caee64: cbz     x0, #0x2caeec4                             
02caee68: mov     x1, xzr                                    
02caee6c: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02caee70: adrp    x20, #0x662f000                            
02caee74: mov     x19, x0                                    
02caee78: ldrb    w8, [x20, #0x91a]                          
02caee7c: cbnz    w8, #0x2caee94                             
02caee80: adrp    x0, #0x6264000                             
02caee84: ldr     x0, [x0, #0xd8]                            T:UnityEngine.Vector3
02caee88: bl      #0x2b70db0                                 fn_2b70db0
02caee8c: mov     w8, #1                                     
02caee90: strb    w8, [x20, #0x91a]                          
02caee94: cbz     x19, #0x2caeec4                            
02caee98: adrp    x8, #0x6264000                             
02caee9c: mov     x0, x19                                    
02caeea0: mov     x1, xzr                                    
02caeea4: ldr     x8, [x8, #0xd8]                            T:UnityEngine.Vector3
02caeea8: ldp     x20, x19, [sp, #0x10]                      
02caeeac: ldr     x8, [x8]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02caeeb0: ldr     x8, [x8, #0xb8]                            MS:DG.Tweening.Core.Extensions::SetSpecialStartupMode
02caeeb4: ldp     s0, s1, [x8]                               
02caeeb8: ldr     s2, [x8, #8]                               T:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass2_0
02caeebc: ldr     x30, [sp], #0x20                           
02caeec0: b       #0x5b470cc                                 UnityEngine.Transform::set_localScale
02caeec4: bl      #0x2b7105c                                 fn_2b7105c
## ShowUnlockPartTime() -> void
---- AnimUnlockFeature::ShowUnlockPartTime 0x2caeec8
02caeec8: stp     x30, x21, [sp, #-0x20]!                    
02caeecc: stp     x20, x19, [sp, #0x10]                      
02caeed0: adrp    x20, #0x662f000                            
02caeed4: mov     x19, x0                                    
02caeed8: ldrb    w8, [x20, #0xb52]                          
02caeedc: tbnz    w8, #0, #0x2caef00                         
02caeee0: adrp    x0, #0x6264000                             
02caeee4: ldr     x0, [x0, #0xf90]                           T:System.Action
02caeee8: bl      #0x2b70db0                                 fn_2b70db0
02caeeec: adrp    x0, #0x6266000                             
02caeef0: ldr     x0, [x0, #0x958]                           M:AnimUnlockFeature::<ShowUnlockPartTime>b__11_0
02caeef4: bl      #0x2b70db0                                 fn_2b70db0
02caeef8: mov     w8, #1                                     
02caeefc: strb    w8, [x20, #0xb52]                          
02caef00: ldr     x0, [x19, #0x60]                           ._goCover
02caef04: cbz     x0, #0x2caef78                             
02caef08: mov     w1, #1                                     
02caef0c: mov     x2, xzr                                    
02caef10: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02caef14: ldr     x8, [x19, #0x20]                           ._btnPartTime
02caef18: cbz     x8, #0x2caef78                             
02caef1c: ldr     x0, [x8, #0x28]                            
02caef20: cbz     x0, #0x2caef78                             
02caef24: adrp    x20, #0x6264000                            
02caef28: adrp    x21, #0x6266000                            
02caef2c: mov     x1, xzr                                    
02caef30: ldr     x20, [x20, #0xf90]                         T:System.Action
02caef34: ldr     x21, [x21, #0x958]                         M:AnimUnlockFeature::<ShowUnlockPartTime>b__11_0
02caef38: bl      #0x5e66470                                 UnityEngine.UI.Selectable::get_image
02caef3c: ldr     x8, [x20]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02caef40: mov     x20, x0                                    
02caef44: mov     x0, x8                                     
02caef48: bl      #0x2b7104c                                 fn_2b7104c
02caef4c: ldr     x2, [x21]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02caef50: mov     x1, x19                                    
02caef54: mov     x3, xzr                                    
02caef58: mov     x21, x0                                    
02caef5c: bl      #0x4d8ddbc                                 System.Action::.ctor
02caef60: mov     x0, x19                                    
02caef64: mov     x1, x20                                    
02caef68: mov     x2, x21                                    
02caef6c: ldp     x20, x19, [sp, #0x10]                      
02caef70: ldp     x30, x21, [sp], #0x20                      
02caef74: b       #0x2caef98                                 AnimUnlockFeature::AnimFlyToPos
02caef78: bl      #0x2b7105c                                 fn_2b7105c
## ShowUnlockDailyTask() -> void
---- AnimUnlockFeature::ShowUnlockDailyTask 0x2caf24c
02caf24c: stp     x30, x21, [sp, #-0x20]!                    
02caf250: stp     x20, x19, [sp, #0x10]                      
02caf254: adrp    x20, #0x662f000                            
02caf258: mov     x19, x0                                    
02caf25c: ldrb    w8, [x20, #0xb53]                          
02caf260: tbnz    w8, #0, #0x2caf284                         
02caf264: adrp    x0, #0x6264000                             
02caf268: ldr     x0, [x0, #0xf90]                           T:System.Action
02caf26c: bl      #0x2b70db0                                 fn_2b70db0
02caf270: adrp    x0, #0x6266000                             
02caf274: ldr     x0, [x0, #0x978]                           M:AnimUnlockFeature::<ShowUnlockDailyTask>b__12_0
02caf278: bl      #0x2b70db0                                 fn_2b70db0
02caf27c: mov     w8, #1                                     
02caf280: strb    w8, [x20, #0xb53]                          
02caf284: ldr     x0, [x19, #0x60]                           ._goCover
02caf288: cbz     x0, #0x2caf2fc                             
02caf28c: mov     w1, #1                                     
02caf290: mov     x2, xzr                                    
02caf294: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02caf298: ldr     x8, [x19, #0x40]                           ._btnDailyTask
02caf29c: cbz     x8, #0x2caf2fc                             
02caf2a0: ldr     x0, [x8, #0x28]                            
02caf2a4: cbz     x0, #0x2caf2fc                             
02caf2a8: adrp    x20, #0x6264000                            
02caf2ac: adrp    x21, #0x6266000                            
02caf2b0: mov     x1, xzr                                    
02caf2b4: ldr     x20, [x20, #0xf90]                         T:System.Action
02caf2b8: ldr     x21, [x21, #0x978]                         M:AnimUnlockFeature::<ShowUnlockDailyTask>b__12_0
02caf2bc: bl      #0x5e66470                                 UnityEngine.UI.Selectable::get_image
02caf2c0: ldr     x8, [x20]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02caf2c4: mov     x20, x0                                    
02caf2c8: mov     x0, x8                                     
02caf2cc: bl      #0x2b7104c                                 fn_2b7104c
02caf2d0: ldr     x2, [x21]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02caf2d4: mov     x1, x19                                    
02caf2d8: mov     x3, xzr                                    
02caf2dc: mov     x21, x0                                    
02caf2e0: bl      #0x4d8ddbc                                 System.Action::.ctor
02caf2e4: mov     x0, x19                                    
02caf2e8: mov     x1, x20                                    
02caf2ec: mov     x2, x21                                    
02caf2f0: ldp     x20, x19, [sp, #0x10]                      
02caf2f4: ldp     x30, x21, [sp], #0x20                      
02caf2f8: b       #0x2caef98                                 AnimUnlockFeature::AnimFlyToPos
02caf2fc: bl      #0x2b7105c                                 fn_2b7105c
## ShowUnlockLoginTime() -> void
---- AnimUnlockFeature::ShowUnlockLoginTime 0x2caf300
02caf300: stp     x30, x21, [sp, #-0x20]!                    
02caf304: stp     x20, x19, [sp, #0x10]                      
02caf308: adrp    x20, #0x662f000                            
02caf30c: mov     x19, x0                                    
02caf310: ldrb    w8, [x20, #0xb54]                          
02caf314: tbnz    w8, #0, #0x2caf338                         
02caf318: adrp    x0, #0x6264000                             
02caf31c: ldr     x0, [x0, #0xf90]                           T:System.Action
02caf320: bl      #0x2b70db0                                 fn_2b70db0
02caf324: adrp    x0, #0x6266000                             
02caf328: ldr     x0, [x0, #0x980]                           M:AnimUnlockFeature::<ShowUnlockLoginTime>b__13_0
02caf32c: bl      #0x2b70db0                                 fn_2b70db0
02caf330: mov     w8, #1                                     
02caf334: strb    w8, [x20, #0xb54]                          
02caf338: ldr     x0, [x19, #0x60]                           ._goCover
02caf33c: cbz     x0, #0x2caf3b0                             
02caf340: mov     w1, #1                                     
02caf344: mov     x2, xzr                                    
02caf348: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02caf34c: ldr     x8, [x19, #0x48]                           ._btnLoginTime
02caf350: cbz     x8, #0x2caf3b0                             
02caf354: ldr     x0, [x8, #0x28]                            
02caf358: cbz     x0, #0x2caf3b0                             
02caf35c: adrp    x20, #0x6264000                            
02caf360: adrp    x21, #0x6266000                            
02caf364: mov     x1, xzr                                    
02caf368: ldr     x20, [x20, #0xf90]                         T:System.Action
02caf36c: ldr     x21, [x21, #0x980]                         M:AnimUnlockFeature::<ShowUnlockLoginTime>b__13_0
02caf370: bl      #0x5e66470                                 UnityEngine.UI.Selectable::get_image
02caf374: ldr     x8, [x20]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02caf378: mov     x20, x0                                    
02caf37c: mov     x0, x8                                     
02caf380: bl      #0x2b7104c                                 fn_2b7104c
02caf384: ldr     x2, [x21]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02caf388: mov     x1, x19                                    
02caf38c: mov     x3, xzr                                    
02caf390: mov     x21, x0                                    
02caf394: bl      #0x4d8ddbc                                 System.Action::.ctor
02caf398: mov     x0, x19                                    
02caf39c: mov     x1, x20                                    
02caf3a0: mov     x2, x21                                    
02caf3a4: ldp     x20, x19, [sp, #0x10]                      
02caf3a8: ldp     x30, x21, [sp], #0x20                      
02caf3ac: b       #0x2caef98                                 AnimUnlockFeature::AnimFlyToPos
02caf3b0: bl      #0x2b7105c                                 fn_2b7105c
## ShowUnlockBlindBag() -> void
---- AnimUnlockFeature::ShowUnlockBlindBag 0x2caf3b4
02caf3b4: stp     x30, x21, [sp, #-0x20]!                    
02caf3b8: stp     x20, x19, [sp, #0x10]                      
02caf3bc: adrp    x20, #0x662f000                            
02caf3c0: mov     x19, x0                                    
02caf3c4: ldrb    w8, [x20, #0xb55]                          
02caf3c8: tbnz    w8, #0, #0x2caf3ec                         
02caf3cc: adrp    x0, #0x6264000                             
02caf3d0: ldr     x0, [x0, #0xf90]                           T:System.Action
02caf3d4: bl      #0x2b70db0                                 fn_2b70db0
02caf3d8: adrp    x0, #0x6266000                             
02caf3dc: ldr     x0, [x0, #0x988]                           M:AnimUnlockFeature::<ShowUnlockBlindBag>b__14_0
02caf3e0: bl      #0x2b70db0                                 fn_2b70db0
02caf3e4: mov     w8, #1                                     
02caf3e8: strb    w8, [x20, #0xb55]                          
02caf3ec: ldr     x0, [x19, #0x60]                           ._goCover
02caf3f0: cbz     x0, #0x2caf464                             
02caf3f4: mov     w1, #1                                     
02caf3f8: mov     x2, xzr                                    
02caf3fc: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02caf400: ldr     x8, [x19, #0x50]                           ._btnBlindBag
02caf404: cbz     x8, #0x2caf464                             
02caf408: ldr     x0, [x8, #0x28]                            
02caf40c: cbz     x0, #0x2caf464                             
02caf410: adrp    x20, #0x6264000                            
02caf414: adrp    x21, #0x6266000                            
02caf418: mov     x1, xzr                                    
02caf41c: ldr     x20, [x20, #0xf90]                         T:System.Action
02caf420: ldr     x21, [x21, #0x988]                         M:AnimUnlockFeature::<ShowUnlockBlindBag>b__14_0
02caf424: bl      #0x5e66470                                 UnityEngine.UI.Selectable::get_image
02caf428: ldr     x8, [x20]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02caf42c: mov     x20, x0                                    
02caf430: mov     x0, x8                                     
02caf434: bl      #0x2b7104c                                 fn_2b7104c
02caf438: ldr     x2, [x21]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02caf43c: mov     x1, x19                                    
02caf440: mov     x3, xzr                                    
02caf444: mov     x21, x0                                    
02caf448: bl      #0x4d8ddbc                                 System.Action::.ctor
02caf44c: mov     x0, x19                                    
02caf450: mov     x1, x20                                    
02caf454: mov     x2, x21                                    
02caf458: ldp     x20, x19, [sp, #0x10]                      
02caf45c: ldp     x30, x21, [sp], #0x20                      
02caf460: b       #0x2caef98                                 AnimUnlockFeature::AnimFlyToPos
02caf464: bl      #0x2b7105c                                 fn_2b7105c
## ShowUnlockDumplingBlindBox() -> void
---- AnimUnlockFeature::ShowUnlockDumplingBlindBox 0x2caf468
02caf468: stp     x30, x21, [sp, #-0x20]!                    
02caf46c: stp     x20, x19, [sp, #0x10]                      
02caf470: adrp    x20, #0x662f000                            
02caf474: mov     x19, x0                                    
02caf478: ldrb    w8, [x20, #0xb56]                          
02caf47c: tbnz    w8, #0, #0x2caf4a0                         
02caf480: adrp    x0, #0x6264000                             
02caf484: ldr     x0, [x0, #0xf90]                           T:System.Action
02caf488: bl      #0x2b70db0                                 fn_2b70db0
02caf48c: adrp    x0, #0x6266000                             
02caf490: ldr     x0, [x0, #0x990]                           M:AnimUnlockFeature::<ShowUnlockDumplingBlindBox>b__15_0
02caf494: bl      #0x2b70db0                                 fn_2b70db0
02caf498: mov     w8, #1                                     
02caf49c: strb    w8, [x20, #0xb56]                          
02caf4a0: ldr     x0, [x19, #0x60]                           ._goCover
02caf4a4: cbz     x0, #0x2caf518                             
02caf4a8: mov     w1, #1                                     
02caf4ac: mov     x2, xzr                                    
02caf4b0: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02caf4b4: ldr     x8, [x19, #0x58]                           ._btnDumplingBlindBox
02caf4b8: cbz     x8, #0x2caf518                             
02caf4bc: ldr     x0, [x8, #0x28]                            
02caf4c0: cbz     x0, #0x2caf518                             
02caf4c4: adrp    x20, #0x6264000                            
02caf4c8: adrp    x21, #0x6266000                            
02caf4cc: mov     x1, xzr                                    
02caf4d0: ldr     x20, [x20, #0xf90]                         T:System.Action
02caf4d4: ldr     x21, [x21, #0x990]                         M:AnimUnlockFeature::<ShowUnlockDumplingBlindBox>b__15_0
02caf4d8: bl      #0x5e66470                                 UnityEngine.UI.Selectable::get_image
02caf4dc: ldr     x8, [x20]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02caf4e0: mov     x20, x0                                    
02caf4e4: mov     x0, x8                                     
02caf4e8: bl      #0x2b7104c                                 fn_2b7104c
02caf4ec: ldr     x2, [x21]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02caf4f0: mov     x1, x19                                    
02caf4f4: mov     x3, xzr                                    
02caf4f8: mov     x21, x0                                    
02caf4fc: bl      #0x4d8ddbc                                 System.Action::.ctor
02caf500: mov     x0, x19                                    
02caf504: mov     x1, x20                                    
02caf508: mov     x2, x21                                    
02caf50c: ldp     x20, x19, [sp, #0x10]                      
02caf510: ldp     x30, x21, [sp], #0x20                      
02caf514: b       #0x2caef98                                 AnimUnlockFeature::AnimFlyToPos
02caf518: bl      #0x2b7105c                                 fn_2b7105c
## ShowUnlockLuckyScoop() -> void
---- AnimUnlockFeature::ShowUnlockLuckyScoop 0x2caf51c
02caf51c: stp     x30, x21, [sp, #-0x20]!                    
02caf520: stp     x20, x19, [sp, #0x10]                      
02caf524: adrp    x20, #0x662f000                            
02caf528: mov     x19, x0                                    
02caf52c: ldrb    w8, [x20, #0xb57]                          
02caf530: tbnz    w8, #0, #0x2caf554                         
02caf534: adrp    x0, #0x6264000                             
02caf538: ldr     x0, [x0, #0xf90]                           T:System.Action
02caf53c: bl      #0x2b70db0                                 fn_2b70db0
02caf540: adrp    x0, #0x6266000                             
02caf544: ldr     x0, [x0, #0x998]                           M:AnimUnlockFeature::<ShowUnlockLuckyScoop>b__16_0
02caf548: bl      #0x2b70db0                                 fn_2b70db0
02caf54c: mov     w8, #1                                     
02caf550: strb    w8, [x20, #0xb57]                          
02caf554: ldr     x0, [x19, #0x60]                           ._goCover
02caf558: cbz     x0, #0x2caf5cc                             
02caf55c: mov     w1, #1                                     
02caf560: mov     x2, xzr                                    
02caf564: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02caf568: ldr     x8, [x19, #0x28]                           ._btnLuckyScoop
02caf56c: cbz     x8, #0x2caf5cc                             
02caf570: ldr     x0, [x8, #0x28]                            
02caf574: cbz     x0, #0x2caf5cc                             
02caf578: adrp    x20, #0x6264000                            
02caf57c: adrp    x21, #0x6266000                            
02caf580: mov     x1, xzr                                    
02caf584: ldr     x20, [x20, #0xf90]                         T:System.Action
02caf588: ldr     x21, [x21, #0x998]                         M:AnimUnlockFeature::<ShowUnlockLuckyScoop>b__16_0
02caf58c: bl      #0x5e66470                                 UnityEngine.UI.Selectable::get_image
02caf590: ldr     x8, [x20]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02caf594: mov     x20, x0                                    
02caf598: mov     x0, x8                                     
02caf59c: bl      #0x2b7104c                                 fn_2b7104c
02caf5a0: ldr     x2, [x21]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02caf5a4: mov     x1, x19                                    
02caf5a8: mov     x3, xzr                                    
02caf5ac: mov     x21, x0                                    
02caf5b0: bl      #0x4d8ddbc                                 System.Action::.ctor
02caf5b4: mov     x0, x19                                    
02caf5b8: mov     x1, x20                                    
02caf5bc: mov     x2, x21                                    
02caf5c0: ldp     x20, x19, [sp, #0x10]                      
02caf5c4: ldp     x30, x21, [sp], #0x20                      
02caf5c8: b       #0x2caef98                                 AnimUnlockFeature::AnimFlyToPos
02caf5cc: bl      #0x2b7105c                                 fn_2b7105c
## ShowUnlockDreamHouse() -> void
---- AnimUnlockFeature::ShowUnlockDreamHouse 0x2caf5d0
02caf5d0: stp     x30, x21, [sp, #-0x20]!                    
02caf5d4: stp     x20, x19, [sp, #0x10]                      
02caf5d8: adrp    x20, #0x662f000                            
02caf5dc: mov     x19, x0                                    
02caf5e0: ldrb    w8, [x20, #0xb58]                          
02caf5e4: tbnz    w8, #0, #0x2caf608                         
02caf5e8: adrp    x0, #0x6264000                             
02caf5ec: ldr     x0, [x0, #0xf90]                           T:System.Action
02caf5f0: bl      #0x2b70db0                                 fn_2b70db0
02caf5f4: adrp    x0, #0x6266000                             
02caf5f8: ldr     x0, [x0, #0x9a0]                           M:AnimUnlockFeature::<ShowUnlockDreamHouse>b__17_0
02caf5fc: bl      #0x2b70db0                                 fn_2b70db0
02caf600: mov     w8, #1                                     
02caf604: strb    w8, [x20, #0xb58]                          
02caf608: ldr     x0, [x19, #0x60]                           ._goCover
02caf60c: cbz     x0, #0x2caf680                             
02caf610: mov     w1, #1                                     
02caf614: mov     x2, xzr                                    
02caf618: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02caf61c: ldr     x8, [x19, #0x30]                           ._btnDreamHouse
02caf620: cbz     x8, #0x2caf680                             
02caf624: ldr     x0, [x8, #0x28]                            
02caf628: cbz     x0, #0x2caf680                             
02caf62c: adrp    x20, #0x6264000                            
02caf630: adrp    x21, #0x6266000                            
02caf634: mov     x1, xzr                                    
02caf638: ldr     x20, [x20, #0xf90]                         T:System.Action
02caf63c: ldr     x21, [x21, #0x9a0]                         M:AnimUnlockFeature::<ShowUnlockDreamHouse>b__17_0
02caf640: bl      #0x5e66470                                 UnityEngine.UI.Selectable::get_image
02caf644: ldr     x8, [x20]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02caf648: mov     x20, x0                                    
02caf64c: mov     x0, x8                                     
02caf650: bl      #0x2b7104c                                 fn_2b7104c
02caf654: ldr     x2, [x21]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02caf658: mov     x1, x19                                    
02caf65c: mov     x3, xzr                                    
02caf660: mov     x21, x0                                    
02caf664: bl      #0x4d8ddbc                                 System.Action::.ctor
02caf668: mov     x0, x19                                    
02caf66c: mov     x1, x20                                    
02caf670: mov     x2, x21                                    
02caf674: ldp     x20, x19, [sp, #0x10]                      
02caf678: ldp     x30, x21, [sp], #0x20                      
02caf67c: b       #0x2caef98                                 AnimUnlockFeature::AnimFlyToPos
02caf680: bl      #0x2b7105c                                 fn_2b7105c
## ShowUnlockDecor() -> void
---- AnimUnlockFeature::ShowUnlockDecor 0x2caf684
02caf684: stp     x30, x21, [sp, #-0x20]!                    
02caf688: stp     x20, x19, [sp, #0x10]                      
02caf68c: adrp    x20, #0x662f000                            
02caf690: mov     x19, x0                                    
02caf694: ldrb    w8, [x20, #0xb59]                          
02caf698: tbnz    w8, #0, #0x2caf6bc                         
02caf69c: adrp    x0, #0x6264000                             
02caf6a0: ldr     x0, [x0, #0xf90]                           T:System.Action
02caf6a4: bl      #0x2b70db0                                 fn_2b70db0
02caf6a8: adrp    x0, #0x6266000                             
02caf6ac: ldr     x0, [x0, #0x9a8]                           M:AnimUnlockFeature::<ShowUnlockDecor>b__18_0
02caf6b0: bl      #0x2b70db0                                 fn_2b70db0
02caf6b4: mov     w8, #1                                     
02caf6b8: strb    w8, [x20, #0xb59]                          
02caf6bc: ldr     x0, [x19, #0x60]                           ._goCover
02caf6c0: cbz     x0, #0x2caf734                             
02caf6c4: mov     w1, #1                                     
02caf6c8: mov     x2, xzr                                    
02caf6cc: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02caf6d0: ldr     x8, [x19, #0x38]                           ._btnDecor
02caf6d4: cbz     x8, #0x2caf734                             
02caf6d8: ldr     x0, [x8, #0x28]                            
02caf6dc: cbz     x0, #0x2caf734                             
02caf6e0: adrp    x20, #0x6264000                            
02caf6e4: adrp    x21, #0x6266000                            
02caf6e8: mov     x1, xzr                                    
02caf6ec: ldr     x20, [x20, #0xf90]                         T:System.Action
02caf6f0: ldr     x21, [x21, #0x9a8]                         M:AnimUnlockFeature::<ShowUnlockDecor>b__18_0
02caf6f4: bl      #0x5e66470                                 UnityEngine.UI.Selectable::get_image
02caf6f8: ldr     x8, [x20]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02caf6fc: mov     x20, x0                                    
02caf700: mov     x0, x8                                     
02caf704: bl      #0x2b7104c                                 fn_2b7104c
02caf708: ldr     x2, [x21]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02caf70c: mov     x1, x19                                    
02caf710: mov     x3, xzr                                    
02caf714: mov     x21, x0                                    
02caf718: bl      #0x4d8ddbc                                 System.Action::.ctor
02caf71c: mov     x0, x19                                    
02caf720: mov     x1, x20                                    
02caf724: mov     x2, x21                                    
02caf728: ldp     x20, x19, [sp, #0x10]                      
02caf72c: ldp     x30, x21, [sp], #0x20                      
02caf730: b       #0x2caef98                                 AnimUnlockFeature::AnimFlyToPos
02caf734: bl      #0x2b7105c                                 fn_2b7105c
## AnimFlyToPos(UnityEngine.UI.Image destination, System.Action onDone) -> void
---- AnimUnlockFeature::AnimFlyToPos 0x2caef98
02caef98: str     d8, [sp, #-0x40]!                          
02caef9c: stp     x30, x23, [sp, #0x10]                      
02caefa0: stp     x22, x21, [sp, #0x20]                      
02caefa4: stp     x20, x19, [sp, #0x30]                      
02caefa8: adrp    x19, #0x662f000                            
02caefac: adrp    x21, #0x6266000                            
02caefb0: mov     x22, x2                                    
02caefb4: ldrb    w8, [x19, #0xb5a]                          
02caefb8: ldr     x21, [x21, #0x960]                         T:AnimUnlockFeature/<>c__DisplayClass19_0
02caefbc: mov     x23, x1                                    
02caefc0: mov     x20, x0                                    
02caefc4: tbnz    w8, #0, #0x2caf018                         
02caefc8: adrp    x0, #0x6264000                             
02caefcc: ldr     x0, [x0, #0x798]                           T:UnityEngine.Rect
02caefd0: bl      #0x2b70db0                                 fn_2b70db0
02caefd4: adrp    x0, #0x6264000                             
02caefd8: ldr     x0, [x0, #0xe8]                            T:DG.Tweening.TweenCallback
02caefdc: bl      #0x2b70db0                                 fn_2b70db0
02caefe0: adrp    x0, #0x6266000                             
02caefe4: ldr     x0, [x0, #0x928]                           MS:DG.Tweening.TweenSettingsExtensions::OnComplete
02caefe8: bl      #0x2b70db0                                 fn_2b70db0
02caefec: adrp    x0, #0x6266000                             
02caeff0: ldr     x0, [x0, #0x880]                           MS:DG.Tweening.TweenSettingsExtensions::SetEase
02caeff4: bl      #0x2b70db0                                 fn_2b70db0
02caeff8: adrp    x0, #0x6266000                             
02caeffc: ldr     x0, [x0, #0x968]                           M:AnimUnlockFeature/<>c__DisplayClass19_0::<AnimFlyToPos>b__0
02caf000: bl      #0x2b70db0                                 fn_2b70db0
02caf004: adrp    x0, #0x6266000                             
02caf008: ldr     x0, [x0, #0x960]                           T:AnimUnlockFeature/<>c__DisplayClass19_0
02caf00c: bl      #0x2b70db0                                 fn_2b70db0
02caf010: mov     w8, #1                                     
02caf014: strb    w8, [x19, #0xb5a]                          
02caf018: ldr     x0, [x21]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02caf01c: bl      #0x2b7104c                                 fn_2b7104c
02caf020: mov     x1, xzr                                    
02caf024: mov     x19, x0                                    
02caf028: bl      #0x4e53e9c                                 System.Object::.ctor
02caf02c: cbz     x19, #0x2caf248                            
02caf030: mov     x0, x19                                    
02caf034: mov     x1, x20                                    
02caf038: str     x20, [x0, #0x10]!                          
02caf03c: bl      #0x2b70d54                                 fn_2b70d54
02caf040: mov     x21, x19                                   
02caf044: mov     x1, x23                                    
02caf048: str     x23, [x21, #0x18]!                         
02caf04c: mov     x0, x21                                    
02caf050: bl      #0x2b70d54                                 fn_2b70d54
02caf054: mov     x0, x19                                    
02caf058: mov     x1, x22                                    
02caf05c: str     x22, [x0, #0x20]!                          ._btnPartTime
02caf060: bl      #0x2b70d54                                 fn_2b70d54
02caf064: ldr     x0, [x20, #0x68]                           ._imgTutorial
02caf068: cbz     x0, #0x2caf248                             
02caf06c: mov     x1, xzr                                    
02caf070: bl      #0x5c4e1ac                                 UnityEngine.UI.Graphic::get_rectTransform
02caf074: ldr     x8, [x21]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02caf078: cbz     x8, #0x2caf248                             
02caf07c: mov     x22, x0                                    
02caf080: mov     x0, x8                                     
02caf084: mov     x1, xzr                                    
02caf088: bl      #0x5c4e1ac                                 UnityEngine.UI.Graphic::get_rectTransform
02caf08c: cbz     x0, #0x2caf248                             
02caf090: adrp    x23, #0x6264000                            
02caf094: mov     x1, xzr                                    
02caf098: ldr     x23, [x23, #0x798]                         T:UnityEngine.Rect
02caf09c: bl      #0x5b45334                                 UnityEngine.RectTransform::get_rect
02caf0a0: ldr     x0, [x23]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02caf0a4: fmov    s8, s2                                     
02caf0a8: ldr     w8, [x0, #0xe4]                            [62660e4]=0 f=0,0
02caf0ac: cbnz    w8, #0x2caf0b4                             
02caf0b0: bl      #0x2b70f30                                 fn_2b70f30
02caf0b4: ldr     x0, [x21]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02caf0b8: cbz     x0, #0x2caf248                             
02caf0bc: mov     x1, xzr                                    
02caf0c0: bl      #0x5c4e1ac                                 UnityEngine.UI.Graphic::get_rectTransform
02caf0c4: cbz     x0, #0x2caf248                             
02caf0c8: mov     x1, xzr                                    
02caf0cc: bl      #0x5b45334                                 UnityEngine.RectTransform::get_rect
02caf0d0: cbz     x22, #0x2caf248                            
02caf0d4: fmov    s0, s8                                     
02caf0d8: fmov    s1, s3                                     
02caf0dc: mov     x0, x22                                    
02caf0e0: mov     x1, xzr                                    
02caf0e4: bl      #0x5b45994                                 UnityEngine.RectTransform::set_sizeDelta
02caf0e8: ldr     x8, [x21]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02caf0ec: cbz     x8, #0x2caf248                             
02caf0f0: ldr     x0, [x20, #0x68]                           ._imgTutorial
02caf0f4: cbz     x0, #0x2caf248                             
02caf0f8: ldr     x1, [x8, #0xd8]                            
02caf0fc: mov     x2, xzr                                    
02caf100: bl      #0x5c45aa0                                 UnityEngine.UI.Image::set_sprite
02caf104: ldr     x0, [x20, #0x68]                           ._imgTutorial
02caf108: cbz     x0, #0x2caf248                             
02caf10c: mov     x1, xzr                                    
02caf110: bl      #0x5c4e1ac                                 UnityEngine.UI.Graphic::get_rectTransform
02caf114: adrp    x22, #0x662f000                            
02caf118: mov     x21, x0                                    
02caf11c: ldrb    w8, [x22, #0xbda]                          
02caf120: cbnz    w8, #0x2caf138                             
02caf124: adrp    x0, #0x6266000                             
02caf128: ldr     x0, [x0, #0x970]                           T:UnityEngine.Vector2
02caf12c: bl      #0x2b70db0                                 fn_2b70db0
02caf130: mov     w8, #1                                     
02caf134: strb    w8, [x22, #0xbda]                          
02caf138: cbz     x21, #0x2caf248                            
02caf13c: adrp    x8, #0x6266000                             
02caf140: mov     x0, x21                                    
02caf144: mov     x1, xzr                                    
02caf148: ldr     x8, [x8, #0x970]                           T:UnityEngine.Vector2
02caf14c: ldr     x8, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02caf150: ldr     x8, [x8, #0xb8]                            S:'banner_native_refresh_time'
02caf154: ldp     s0, s1, [x8]                               
02caf158: bl      #0x5b45800                                 UnityEngine.RectTransform::set_anchoredPosition
02caf15c: ldr     x0, [x20, #0x68]                           ._imgTutorial
02caf160: cbz     x0, #0x2caf248                             
02caf164: mov     x1, xzr                                    
02caf168: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02caf16c: adrp    x22, #0x662f000                            
02caf170: mov     x21, x0                                    
02caf174: ldrb    w8, [x22, #0x91a]                          
02caf178: cbnz    w8, #0x2caf190                             
02caf17c: adrp    x0, #0x6264000                             
02caf180: ldr     x0, [x0, #0xd8]                            T:UnityEngine.Vector3
02caf184: bl      #0x2b70db0                                 fn_2b70db0
02caf188: mov     w8, #1                                     
02caf18c: strb    w8, [x22, #0x91a]                          
02caf190: cbz     x21, #0x2caf248                            
02caf194: adrp    x8, #0x6264000                             
02caf198: mov     x0, x21                                    
02caf19c: mov     x1, xzr                                    
02caf1a0: ldr     x8, [x8, #0xd8]                            T:UnityEngine.Vector3
02caf1a4: ldr     x8, [x8]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02caf1a8: ldr     x8, [x8, #0xb8]                            MS:DG.Tweening.Core.Extensions::SetSpecialStartupMode
02caf1ac: ldp     s1, s2, [x8, #4]                           
02caf1b0: ldr     s0, [x8]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02caf1b4: bl      #0x5b470cc                                 UnityEngine.Transform::set_localScale
02caf1b8: ldr     x0, [x20, #0x68]                           ._imgTutorial
02caf1bc: cbz     x0, #0x2caf248                             
02caf1c0: adrp    x20, #0x6266000                            
02caf1c4: adrp    x21, #0x6264000                            
02caf1c8: adrp    x22, #0x6266000                            
02caf1cc: adrp    x23, #0x6266000                            
02caf1d0: ldr     x20, [x20, #0x880]                         MS:DG.Tweening.TweenSettingsExtensions::SetEase
02caf1d4: ldr     x21, [x21, #0xe8]                          T:DG.Tweening.TweenCallback
02caf1d8: ldr     x22, [x22, #0x968]                         M:AnimUnlockFeature/<>c__DisplayClass19_0::<AnimFlyToPos>b__0
02caf1dc: ldr     x23, [x23, #0x928]                         MS:DG.Tweening.TweenSettingsExtensions::OnComplete
02caf1e0: mov     x1, xzr                                    
02caf1e4: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02caf1e8: fmov    s0, #1.00000000                            
02caf1ec: fmov    s1, #0.50000000                            
02caf1f0: mov     x1, xzr                                    
02caf1f4: bl      #0x2d98c98                                 DG.Tweening.ShortcutExtensions::DOScale
02caf1f8: ldr     x2, [x20]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02caf1fc: mov     w1, #0x1b                                  
02caf200: bl      #0x336fa0c                                 fn_336fa0c
02caf204: ldr     x8, [x21]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02caf208: mov     x20, x0                                    
02caf20c: mov     x0, x8                                     
02caf210: bl      #0x2b7104c                                 fn_2b7104c
02caf214: ldr     x2, [x22]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02caf218: mov     x1, x19                                    
02caf21c: mov     x3, xzr                                    
02caf220: mov     x21, x0                                    
02caf224: bl      #0x2d89dc4                                 DG.Tweening.TweenCallback::.ctor
02caf228: ldr     x2, [x23]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02caf22c: mov     x0, x20                                    
02caf230: mov     x1, x21                                    
02caf234: ldp     x20, x19, [sp, #0x30]                      
02caf238: ldp     x22, x21, [sp, #0x20]                      
02caf23c: ldp     x30, x23, [sp, #0x10]                      
02caf240: ldr     d8, [sp], #0x40                            
02caf244: b       #0x336f26c                                 
02caf248: bl      #0x2b7105c                                 fn_2b7105c
## GetWorldCenter(UnityEngine.RectTransform rt) -> UnityEngine.Vector3
---- AnimUnlockFeature::GetWorldCenter 0x2caf740
02caf740: stp     x30, x21, [sp, #-0x20]!                    
02caf744: stp     x20, x19, [sp, #0x10]                      
02caf748: adrp    x19, #0x662f000                            
02caf74c: adrp    x21, #0x6264000                            
02caf750: mov     x20, x1                                    
02caf754: ldrb    w8, [x19, #0xb5b]                          
02caf758: ldr     x21, [x21, #0x270]                         T:type24806(k1d)
02caf75c: tbnz    w8, #0, #0x2caf774                         
02caf760: adrp    x0, #0x6264000                             
02caf764: ldr     x0, [x0, #0x270]                           T:type24806(k1d)
02caf768: bl      #0x2b70db0                                 fn_2b70db0
02caf76c: mov     w8, #1                                     
02caf770: strb    w8, [x19, #0xb5b]                          
02caf774: ldr     x0, [x21]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02caf778: mov     w1, #4                                     
02caf77c: bl      #0x2b70ea0                                 fn_2b70ea0
02caf780: cbz     x20, #0x2caf7e4                            
02caf784: mov     x19, x0                                    
02caf788: mov     x0, x20                                    
02caf78c: mov     x2, xzr                                    
02caf790: mov     x1, x19                                    
02caf794: bl      #0x5b46250                                 UnityEngine.RectTransform::GetWorldCorners
02caf798: cbz     x19, #0x2caf7e4                            
02caf79c: ldr     w8, [x19, #0x18]                           [662f018]=6000014 f=2.40742e-35,0
02caf7a0: cbz     w8, #0x2caf7e8                             
02caf7a4: cmp     w8, #2                                     
02caf7a8: b.ls    #0x2caf7e8                                 
02caf7ac: ldr     d0, [x19, #0x20]                           &2b706f0(=d65f03c0f9400800) ._btnPartTime
02caf7b0: ldr     d1, [x19, #0x38]                           [662f038]=6000016 f=2.40742e-35,0 ._btnDecor
02caf7b4: ldr     s2, [x19, #0x28]                           [662f028]=6000015 f=2.40742e-35,0 ._btnLuckyScoop
02caf7b8: ldr     s3, [x19, #0x40]                           &2b70700(=14cc750491004000) ._btnDailyTask
02caf7bc: ldp     x20, x19, [sp, #0x10]                      
02caf7c0: fadd    v0.2s, v0.2s, v1.2s                        
02caf7c4: movi    v1.2s, #0x3f, lsl #24                      
02caf7c8: fadd    s2, s2, s3                                 
02caf7cc: fmul    v0.2s, v0.2s, v1.2s                        
02caf7d0: fmov    s1, #0.50000000                            
02caf7d4: fmul    s2, s2, s1                                 
02caf7d8: mov     s1, v0.s[1]                                
02caf7dc: ldp     x30, x21, [sp], #0x20                      
02caf7e0: ret                                                
02caf7e4: bl      #0x2b7105c                                 fn_2b7105c
02caf7e8: bl      #0x2b71064                                 fn_2b71064
## .ctor() -> void
---- AnimUnlockFeature::.ctor 0x2caf7ec
02caf7ec: mov     x1, xzr                                    
02caf7f0: b       #0x5b397b0                                 UnityEngine.MonoBehaviour::.ctor
## <ShowUnlockPartTime>b__11_0() -> void
---- AnimUnlockFeature::<ShowUnlockPartTime>b__11_0 0x2caf7f4
02caf7f4: stp     x30, x19, [sp, #-0x10]!                    
02caf7f8: mov     x19, x0                                    
02caf7fc: ldr     x0, [x0, #0x60]                            ._goCover
02caf800: cbz     x0, #0x2caf820                             
02caf804: mov     w1, wzr                                    
02caf808: mov     x2, xzr                                    
02caf80c: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02caf810: ldr     x8, [x19, #0x20]                           ._btnPartTime
02caf814: cbz     x8, #0x2caf820                             
02caf818: ldp     x30, x19, [sp], #0x10                      
02caf81c: ret                                                
02caf820: bl      #0x2b7105c                                 fn_2b7105c
## <ShowUnlockDailyTask>b__12_0() -> void
---- AnimUnlockFeature::<ShowUnlockDailyTask>b__12_0 0x2caf828
02caf828: stp     x30, x19, [sp, #-0x10]!                    
02caf82c: mov     x19, x0                                    
02caf830: ldr     x0, [x0, #0x60]                            ._goCover
02caf834: cbz     x0, #0x2caf854                             
02caf838: mov     w1, wzr                                    
02caf83c: mov     x2, xzr                                    
02caf840: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02caf844: ldr     x8, [x19, #0x40]                           ._btnDailyTask
02caf848: cbz     x8, #0x2caf854                             
02caf84c: ldp     x30, x19, [sp], #0x10                      
02caf850: ret                                                
02caf854: bl      #0x2b7105c                                 fn_2b7105c
## <ShowUnlockLoginTime>b__13_0() -> void
---- AnimUnlockFeature::<ShowUnlockLoginTime>b__13_0 0x2caf858
02caf858: stp     x30, x19, [sp, #-0x10]!                    
02caf85c: mov     x19, x0                                    
02caf860: ldr     x0, [x0, #0x60]                            ._goCover
02caf864: cbz     x0, #0x2caf884                             
02caf868: mov     w1, wzr                                    
02caf86c: mov     x2, xzr                                    
02caf870: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02caf874: ldr     x8, [x19, #0x48]                           ._btnLoginTime
02caf878: cbz     x8, #0x2caf884                             
02caf87c: ldp     x30, x19, [sp], #0x10                      
02caf880: ret                                                
02caf884: bl      #0x2b7105c                                 fn_2b7105c
## <ShowUnlockBlindBag>b__14_0() -> void
---- AnimUnlockFeature::<ShowUnlockBlindBag>b__14_0 0x2caf888
02caf888: stp     x30, x19, [sp, #-0x10]!                    
02caf88c: mov     x19, x0                                    
02caf890: ldr     x0, [x0, #0x60]                            ._goCover
02caf894: cbz     x0, #0x2caf8b4                             
02caf898: mov     w1, wzr                                    
02caf89c: mov     x2, xzr                                    
02caf8a0: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02caf8a4: ldr     x8, [x19, #0x50]                           ._btnBlindBag
02caf8a8: cbz     x8, #0x2caf8b4                             
02caf8ac: ldp     x30, x19, [sp], #0x10                      
02caf8b0: ret                                                
02caf8b4: bl      #0x2b7105c                                 fn_2b7105c
## <ShowUnlockDumplingBlindBox>b__15_0() -> void
---- AnimUnlockFeature::<ShowUnlockDumplingBlindBox>b__15_0 0x2caf8b8
02caf8b8: stp     x30, x19, [sp, #-0x10]!                    
02caf8bc: mov     x19, x0                                    
02caf8c0: ldr     x0, [x0, #0x60]                            ._goCover
02caf8c4: cbz     x0, #0x2caf8e4                             
02caf8c8: mov     w1, wzr                                    
02caf8cc: mov     x2, xzr                                    
02caf8d0: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02caf8d4: ldr     x8, [x19, #0x58]                           ._btnDumplingBlindBox
02caf8d8: cbz     x8, #0x2caf8e4                             
02caf8dc: ldp     x30, x19, [sp], #0x10                      
02caf8e0: ret                                                
02caf8e4: bl      #0x2b7105c                                 fn_2b7105c
## <ShowUnlockLuckyScoop>b__16_0() -> void
---- AnimUnlockFeature::<ShowUnlockLuckyScoop>b__16_0 0x2caf8e8
02caf8e8: stp     x30, x19, [sp, #-0x10]!                    
02caf8ec: mov     x19, x0                                    
02caf8f0: ldr     x0, [x0, #0x60]                            ._goCover
02caf8f4: cbz     x0, #0x2caf914                             
02caf8f8: mov     w1, wzr                                    
02caf8fc: mov     x2, xzr                                    
02caf900: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02caf904: ldr     x8, [x19, #0x28]                           ._btnLuckyScoop
02caf908: cbz     x8, #0x2caf914                             
02caf90c: ldp     x30, x19, [sp], #0x10                      
02caf910: ret                                                
02caf914: bl      #0x2b7105c                                 fn_2b7105c
## <ShowUnlockDreamHouse>b__17_0() -> void
---- AnimUnlockFeature::<ShowUnlockDreamHouse>b__17_0 0x2caf918
02caf918: stp     x30, x19, [sp, #-0x10]!                    
02caf91c: mov     x19, x0                                    
02caf920: ldr     x0, [x0, #0x60]                            ._goCover
02caf924: cbz     x0, #0x2caf944                             
02caf928: mov     w1, wzr                                    
02caf92c: mov     x2, xzr                                    
02caf930: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02caf934: ldr     x8, [x19, #0x30]                           ._btnDreamHouse
02caf938: cbz     x8, #0x2caf944                             
02caf93c: ldp     x30, x19, [sp], #0x10                      
02caf940: ret                                                
02caf944: bl      #0x2b7105c                                 fn_2b7105c
## <ShowUnlockDecor>b__18_0() -> void
---- AnimUnlockFeature::<ShowUnlockDecor>b__18_0 0x2caf948
02caf948: stp     x30, x19, [sp, #-0x10]!                    
02caf94c: mov     x19, x0                                    
02caf950: ldr     x0, [x0, #0x60]                            ._goCover
02caf954: cbz     x0, #0x2caf974                             
02caf958: mov     w1, wzr                                    
02caf95c: mov     x2, xzr                                    
02caf960: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02caf964: ldr     x8, [x19, #0x38]                           ._btnDecor
02caf968: cbz     x8, #0x2caf974                             
02caf96c: ldp     x30, x19, [sp], #0x10                      
02caf970: ret                                                
02caf974: bl      #0x2b7105c                                 fn_2b7105c
