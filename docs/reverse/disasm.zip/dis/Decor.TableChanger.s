#### CLASS Decor.TableChanger parent= UnityEngine.MonoBehaviour
#   field _spriteRenderer                UnityEngine.SpriteRenderer                         off=0x20 attr=1 SerializeField
## ChangeItem(int categoryIndex, int optionID) -> void
---- Decor.TableChanger::ChangeItem 0x2d26d88
02d26d88: stp     x30, x23, [sp, #-0x30]!                    
02d26d8c: stp     x22, x21, [sp, #0x10]                      
02d26d90: stp     x20, x19, [sp, #0x20]                      
02d26d94: adrp    x22, #0x6630000                            
02d26d98: adrp    x23, #0x6266000                            
02d26d9c: mov     w20, w2                                    
02d26da0: ldrb    w8, [x22, #0x89]                           
02d26da4: ldr     x23, [x23, #0x658]                         MS:MonoSingleton`1::get_Instance
02d26da8: mov     w21, w1                                    
02d26dac: mov     x19, x0                                    
02d26db0: tbnz    w8, #0, #0x2d26dd4                         
02d26db4: adrp    x0, #0x6266000                             
02d26db8: ldr     x0, [x0, #0x870]                           MS:DataManager::GetAsset
02d26dbc: bl      #0x2b70db0                                 fn_2b70db0
02d26dc0: adrp    x0, #0x6266000                             
02d26dc4: ldr     x0, [x0, #0x658]                           MS:MonoSingleton`1::get_Instance
02d26dc8: bl      #0x2b70db0                                 fn_2b70db0
02d26dcc: mov     w8, #1                                     
02d26dd0: strb    w8, [x22, #0x89]                           
02d26dd4: ldr     x0, [x23]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d26dd8: bl      #0x3769600                                 fn_3769600
02d26ddc: cbz     x0, #0x2d26e30                             
02d26de0: adrp    x8, #0x6266000                             
02d26de4: ldr     x8, [x8, #0x870]                           MS:DataManager::GetAsset
02d26de8: ldr     x1, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d26dec: bl      #0x3168af0                                 fn_3168af0
02d26df0: cbz     x0, #0x2d26e30                             
02d26df4: mov     w1, w21                                    
02d26df8: bl      #0x2d249f4                                 Decor.DecorAsset::GetCategoryAssetByIndex
02d26dfc: cbz     x0, #0x2d26e30                             
02d26e00: mov     w1, w20                                    
02d26e04: bl      #0x2d24a4c                                 Decor.CategoryAsset::GetOptionDataByID
02d26e08: cbz     x0, #0x2d26e30                             
02d26e0c: ldr     x8, [x19, #0x20]                           ._spriteRenderer
02d26e10: cbz     x8, #0x2d26e30                             
02d26e14: ldp     x20, x19, [sp, #0x20]                      
02d26e18: mov     x2, xzr                                    
02d26e1c: ldp     x22, x21, [sp, #0x10]                      
02d26e20: ldr     x1, [x0, #0x40]                            S:'native_collap_ad_on_off'
02d26e24: mov     x0, x8                                     
02d26e28: ldp     x30, x23, [sp], #0x30                      
02d26e2c: b       #0x5ae6dcc                                 UnityEngine.SpriteRenderer::set_sprite
02d26e30: bl      #0x2b7105c                                 fn_2b7105c
## .ctor() -> void
---- Decor.TableChanger::.ctor 0x2d26e34
02d26e34: mov     x1, xzr                                    
02d26e38: b       #0x5b397b0                                 UnityEngine.MonoBehaviour::.ctor
