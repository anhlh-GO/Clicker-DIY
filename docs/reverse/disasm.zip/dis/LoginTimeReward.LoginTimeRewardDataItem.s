#### CLASS LoginTimeReward.LoginTimeRewardDataItem parent= object
#   field Id                             int                                                off=0x10 attr=6 
#   field Minute                         int                                                off=0x14 attr=6 
#   field RewardType                     LoginTimeReward.RewardType                         off=0x18 attr=6 
#   field RewardAmount                   int                                                off=0x1c attr=6 
#   field ClaimType                      LoginTimeReward.ClaimType                          off=0x20 attr=6 
## .ctor() -> void
---- LoginTimeReward.LoginTimeRewardDataItem::.ctor 0x2d5b1a0
02d5b1a0: mov     x1, xzr                                    
02d5b1a4: b       #0x4e53e9c                                 System.Object::.ctor
