#### CLASS Decor.DecorChanger parent= UnityEngine.MonoBehaviour
#   field _spriteRenderer                UnityEngine.SpriteRenderer                         off=0x20 attr=1 SerializeField
## ChangeItem(int categoryIndex, int optionID) -> void
---- Decor.DecorChanger::ChangeItem 0x2d26174
02d26174: stp     x30, x23, [sp, #-0x30]!                    
02d26178: stp     x22, x21, [sp, #0x10]                      
02d2617c: stp     x20, x19, [sp, #0x20]                      
02d26180: adrp    x22, #0x6630000                            
02d26184: adrp    x23, #0x6266000                            
02d26188: mov     w20, w2                                    
02d2618c: ldrb    w8, [x22, #0x7f]                           
02d26190: ldr     x23, [x23, #0x658]                         MS:MonoSingleton`1::get_Instance
02d26194: mov     w21, w1                                    
02d26198: mov     x19, x0                                    
02d2619c: tbnz    w8, #0, #0x2d261c0                         
02d261a0: adrp    x0, #0x6266000                             
02d261a4: ldr     x0, [x0, #0x870]                           MS:DataManager::GetAsset
02d261a8: bl      #0x2b70db0                                 fn_2b70db0
02d261ac: adrp    x0, #0x6266000                             
02d261b0: ldr     x0, [x0, #0x658]                           MS:MonoSingleton`1::get_Instance
02d261b4: bl      #0x2b70db0                                 fn_2b70db0
02d261b8: mov     w8, #1                                     
02d261bc: strb    w8, [x22, #0x7f]                           
02d261c0: ldr     x0, [x23]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d261c4: bl      #0x3769600                                 fn_3769600
02d261c8: cbz     x0, #0x2d2621c                             
02d261cc: adrp    x8, #0x6266000                             
02d261d0: ldr     x8, [x8, #0x870]                           MS:DataManager::GetAsset
02d261d4: ldr     x1, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d261d8: bl      #0x3168af0                                 fn_3168af0
02d261dc: cbz     x0, #0x2d2621c                             
02d261e0: mov     w1, w21                                    
02d261e4: bl      #0x2d249f4                                 Decor.DecorAsset::GetCategoryAssetByIndex
02d261e8: cbz     x0, #0x2d2621c                             
02d261ec: mov     w1, w20                                    
02d261f0: bl      #0x2d24a4c                                 Decor.CategoryAsset::GetOptionDataByID
02d261f4: cbz     x0, #0x2d2621c                             
02d261f8: ldr     x8, [x19, #0x20]                           ._spriteRenderer
02d261fc: cbz     x8, #0x2d2621c                             
02d26200: ldp     x20, x19, [sp, #0x20]                      
02d26204: mov     x2, xzr                                    
02d26208: ldp     x22, x21, [sp, #0x10]                      
02d2620c: ldr     x1, [x0, #0x40]                            S:'native_collap_ad_on_off'
02d26210: mov     x0, x8                                     
02d26214: ldp     x30, x23, [sp], #0x30                      
02d26218: b       #0x5ae6dcc                                 UnityEngine.SpriteRenderer::set_sprite
02d2621c: bl      #0x2b7105c                                 fn_2b7105c
## .ctor() -> void
---- Decor.DecorChanger::.ctor 0x2d26220
02d26220: mov     x1, xzr                                    
02d26224: b       #0x5b397b0                                 UnityEngine.MonoBehaviour::.ctor
