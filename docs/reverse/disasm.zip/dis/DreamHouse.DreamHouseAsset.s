#### CLASS DreamHouse.DreamHouseAsset parent= GameAsset
#   field Rooms                          System.Collections.Generic.List`1<DreamHouse.RoomConfig> off=0x18 attr=6 
## GetRoomConfigByIndex(int index) -> DreamHouse.RoomConfig
---- DreamHouse.DreamHouseAsset::GetRoomConfigByIndex 0x2d1590c
02d1590c: sub     sp, sp, #0x30                              
02d15910: stp     x30, x21, [sp, #0x10]                      
02d15914: stp     x20, x19, [sp, #0x20]                      
02d15918: adrp    x21, #0x662f000                            
02d1591c: mov     w19, w1                                    
02d15920: mov     x20, x0                                    
02d15924: ldrb    w8, [x21, #0xfce]                          
02d15928: tbnz    w8, #0, #0x2d15964                         
02d1592c: adrp    x0, #0x6263000                             
02d15930: ldr     x0, [x0, #0x928]                           T:UnityEngine.Debug
02d15934: bl      #0x2b70db0                                 fn_2b70db0
02d15938: adrp    x0, #0x6269000                             
02d1593c: ldr     x0, [x0, #0x888]                           MS:System.Collections.Generic.List`1::get_Count
02d15940: bl      #0x2b70db0                                 fn_2b70db0
02d15944: adrp    x0, #0x6269000                             
02d15948: ldr     x0, [x0, #0x890]                           MS:System.Collections.Generic.List`1::get_Item
02d1594c: bl      #0x2b70db0                                 fn_2b70db0
02d15950: adrp    x0, #0x6269000                             
02d15954: ldr     x0, [x0, #0x898]                           S:'Index {0} is out of range for Rooms.'
02d15958: bl      #0x2b70db0                                 fn_2b70db0
02d1595c: mov     w8, #1                                     
02d15960: strb    w8, [x21, #0xfce]                          
02d15964: tbnz    w19, #0x1f, #0x2d1599c                     
02d15968: ldr     x0, [x20, #0x18]                           .Rooms
02d1596c: cbz     x0, #0x2d15a10                             
02d15970: ldr     w8, [x0, #0x18]                            M:Trading.TradingSession::<ValidateTrade>b__57_0 .Rooms
02d15974: cmp     w8, w19                                    
02d15978: b.le    #0x2d1599c                                 
02d1597c: adrp    x8, #0x6269000                             
02d15980: mov     w1, w19                                    
02d15984: ldr     x8, [x8, #0x890]                           MS:System.Collections.Generic.List`1::get_Item
02d15988: ldp     x20, x19, [sp, #0x20]                      
02d1598c: ldp     x30, x21, [sp, #0x10]                      
02d15990: ldr     x2, [x8]                                   T:Trading.TradingSession/<>c__DisplayClass56_0
02d15994: add     sp, sp, #0x30                              
02d15998: b       #0x35a8f3c                                 
02d1599c: adrp    x8, #0x6263000                             
02d159a0: adrp    x20, #0x6269000                            
02d159a4: adrp    x21, #0x6263000                            
02d159a8: ldr     x8, [x8, #0x970]                           &6645c70(=0)
02d159ac: ldr     x20, [x20, #0x898]                         S:'Index {0} is out of range for Rooms.'
02d159b0: ldr     x21, [x21, #0x928]                         T:UnityEngine.Debug
02d159b4: add     x1, sp, #0xc                               
02d159b8: str     w19, [sp, #0xc]                            
02d159bc: ldr     x0, [x8, #0x48]                            &6263098(=0)
02d159c0: bl      #0x2b70f38                                 fn_2b70f38
02d159c4: ldr     x8, [x20]                                  T:Trading.TradingSession/<>c__DisplayClass56_0
02d159c8: mov     x1, x0                                     
02d159cc: mov     x2, xzr                                    
02d159d0: mov     x0, x8                                     
02d159d4: bl      #0x4c9d0ec                                 System.String::Format
02d159d8: ldr     x8, [x21]                                  &2c5bbd4(=a9bd7bfdd503233f)
02d159dc: mov     x19, x0                                    
02d159e0: ldr     w9, [x8, #0xe4]                            [62630e4]=0 f=0,0
02d159e4: cbnz    w9, #0x2d159f0                             
02d159e8: mov     x0, x8                                     
02d159ec: bl      #0x2b70f30                                 fn_2b70f30
02d159f0: mov     x0, x19                                    
02d159f4: mov     x1, xzr                                    
02d159f8: bl      #0x5af2840                                 UnityEngine.Debug::LogError
02d159fc: ldp     x20, x19, [sp, #0x20]                      
02d15a00: mov     x0, xzr                                    
02d15a04: ldp     x30, x21, [sp, #0x10]                      
02d15a08: add     sp, sp, #0x30                              
02d15a0c: ret                                                
02d15a10: bl      #0x2b7105c                                 fn_2b7105c
## GetRoomConfigIndex(DreamHouse.RoomConfig roomConfig) -> int
---- DreamHouse.DreamHouseAsset::GetRoomConfigIndex 0x2d15a14
02d15a14: stp     x30, x21, [sp, #-0x20]!                    
02d15a18: stp     x20, x19, [sp, #0x10]                      
02d15a1c: adrp    x21, #0x662f000                            
02d15a20: mov     x19, x1                                    
02d15a24: mov     x20, x0                                    
02d15a28: ldrb    w8, [x21, #0xfcf]                          
02d15a2c: tbnz    w8, #0, #0x2d15a74                         
02d15a30: adrp    x0, #0x6263000                             
02d15a34: ldr     x0, [x0, #0x928]                           T:UnityEngine.Debug
02d15a38: bl      #0x2b70db0                                 fn_2b70db0
02d15a3c: adrp    x0, #0x6269000                             
02d15a40: ldr     x0, [x0, #0x8a0]                           MS:System.Collections.Generic.List`1::Contains
02d15a44: bl      #0x2b70db0                                 fn_2b70db0
02d15a48: adrp    x0, #0x6269000                             
02d15a4c: ldr     x0, [x0, #0x8a8]                           MS:System.Collections.Generic.List`1::IndexOf
02d15a50: bl      #0x2b70db0                                 fn_2b70db0
02d15a54: adrp    x0, #0x6269000                             
02d15a58: ldr     x0, [x0, #0x8b0]                           S:' not found in Rooms.'
02d15a5c: bl      #0x2b70db0                                 fn_2b70db0
02d15a60: adrp    x0, #0x6269000                             
02d15a64: ldr     x0, [x0, #0x8b8]                           S:'RoomConfig '
02d15a68: bl      #0x2b70db0                                 fn_2b70db0
02d15a6c: mov     w8, #1                                     
02d15a70: strb    w8, [x21, #0xfcf]                          
02d15a74: ldr     x0, [x20, #0x18]                           .Rooms
02d15a78: cbz     x0, #0x2d15b1c                             
02d15a7c: adrp    x8, #0x6269000                             
02d15a80: mov     x1, x19                                    
02d15a84: ldr     x8, [x8, #0x8a0]                           MS:System.Collections.Generic.List`1::Contains
02d15a88: ldr     x2, [x8]                                   T:Trading.TradingSession/<>c__DisplayClass56_0
02d15a8c: bl      #0x35a95a8                                 fn_35a95a8
02d15a90: tbz     w0, #0, #0x2d15ab8                         
02d15a94: ldr     x0, [x20, #0x18]                           .Rooms
02d15a98: cbz     x0, #0x2d15b1c                             
02d15a9c: adrp    x8, #0x6269000                             
02d15aa0: mov     x1, x19                                    
02d15aa4: ldr     x8, [x8, #0x8a8]                           MS:System.Collections.Generic.List`1::IndexOf
02d15aa8: ldp     x20, x19, [sp, #0x10]                      
02d15aac: ldr     x2, [x8]                                   T:Trading.TradingSession/<>c__DisplayClass56_0
02d15ab0: ldp     x30, x21, [sp], #0x20                      
02d15ab4: b       #0x35a9f48                                 
02d15ab8: cbz     x19, #0x2d15b1c                            
02d15abc: adrp    x8, #0x6269000                             
02d15ac0: adrp    x9, #0x6269000                             
02d15ac4: mov     x3, xzr                                    
02d15ac8: ldr     x8, [x8, #0x8b8]                           S:'RoomConfig '
02d15acc: ldr     x9, [x9, #0x8b0]                           S:' not found in Rooms.'
02d15ad0: ldr     x1, [x19, #0x18]                           .Rooms
02d15ad4: ldr     x0, [x8]                                   T:Trading.TradingSession/<>c__DisplayClass56_0
02d15ad8: ldr     x2, [x9]                                   T:Trading.TradingSession/<>c__DisplayClass56_0
02d15adc: bl      #0x4ca6dbc                                 System.String::Concat
02d15ae0: adrp    x8, #0x6263000                             
02d15ae4: mov     x19, x0                                    
02d15ae8: ldr     x8, [x8, #0x928]                           T:UnityEngine.Debug
02d15aec: ldr     x8, [x8]                                   &2c5bbd4(=a9bd7bfdd503233f)
02d15af0: ldr     w9, [x8, #0xe4]                            [62630e4]=0 f=0,0
02d15af4: cbnz    w9, #0x2d15b00                             
02d15af8: mov     x0, x8                                     
02d15afc: bl      #0x2b70f30                                 fn_2b70f30
02d15b00: mov     x0, x19                                    
02d15b04: mov     x1, xzr                                    
02d15b08: bl      #0x5af2840                                 UnityEngine.Debug::LogError
02d15b0c: ldp     x20, x19, [sp, #0x10]                      
02d15b10: mov     w0, #-1                                    
02d15b14: ldp     x30, x21, [sp], #0x20                      
02d15b18: ret                                                
02d15b1c: bl      #0x2b7105c                                 fn_2b7105c
## .ctor() -> void
---- DreamHouse.DreamHouseAsset::.ctor 0x2d15b20
02d15b20: mov     x1, xzr                                    
02d15b24: b       #0x2cae4f0                                 GameAsset::.ctor
