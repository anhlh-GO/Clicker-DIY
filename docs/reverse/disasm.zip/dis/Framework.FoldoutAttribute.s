#### CLASS Framework.FoldoutAttribute parent= UnityEngine.PropertyAttribute
#   field name                           string                                             off=0x18 attr=26 
#   field foldEverything                 bool                                               off=0x20 attr=26 
## .ctor(string name, bool foldEverything) -> void
---- Framework.FoldoutAttribute::.ctor 0x2cb83a0
02cb83a0: stp     x30, x21, [sp, #-0x20]!                    
02cb83a4: stp     x20, x19, [sp, #0x10]                      
02cb83a8: mov     x20, x1                                    
02cb83ac: mov     x1, xzr                                    
02cb83b0: mov     w19, w2                                    
02cb83b4: mov     x21, x0                                    
02cb83b8: bl      #0x5b2d93c                                 UnityEngine.PropertyAttribute::.ctor
02cb83bc: str     x20, [x21, #0x18]!                         .name
02cb83c0: mov     x1, x20                                    
02cb83c4: strb    w19, [x21, #8]                             
02cb83c8: ldp     x20, x19, [sp, #0x10]                      
02cb83cc: mov     x0, x21                                    
02cb83d0: ldp     x30, x21, [sp], #0x20                      
02cb83d4: b       #0x2b70d54                                 
