#### CLASS AdsManager/<>c__DisplayClass18_0 parent= object
#   field requestComplete                bool                                               off=0x10 attr=6 
## .ctor() -> void
---- AdsManager/<>c__DisplayClass18_0::.ctor 0x2c8ab00
02c8ab00: mov     x1, xzr                                    
02c8ab04: b       #0x4e53e9c                                 System.Object::.ctor
## <IRequestConsent>b__0() -> void
---- AdsManager/<>c__DisplayClass18_0::<IRequestConsent>b__0 0x2c8ab08
02c8ab08: mov     w8, #1                                     
02c8ab0c: strb    w8, [x0, #0x10]                            .requestComplete
02c8ab10: ret                                                
#### CLASS AdsManager/<>c__DisplayClass32_0 parent= object
#   field action                         System.Action                                      off=0x10 attr=6 
#   field <>4__this                      AdsManager                                         off=0x18 attr=6 
## .ctor() -> void
---- AdsManager/<>c__DisplayClass32_0::.ctor 0x2c89470
02c89470: mov     x1, xzr                                    
02c89474: b       #0x4e53e9c                                 System.Object::.ctor
## <ShowAppOpenLoading>g__OnComplete|0() -> void
---- AdsManager/<>c__DisplayClass32_0::<ShowAppOpenLoading>g__OnComplete|0 0x2c89478
02c89478: stp     x30, x19, [sp, #-0x10]!                    
02c8947c: ldr     x8, [x0, #0x10]                            .action
02c89480: mov     x19, x0                                    
02c89484: cbz     x8, #0x2c89498                             
02c89488: ldr     x9, [x8, #0x18]                            
02c8948c: ldr     x0, [x8, #0x40]                            
02c89490: ldr     x1, [x8, #0x28]                            
02c89494: blr     x9                                         
02c89498: ldr     x0, [x19, #0x18]                           .<>4__this
02c8949c: cbz     x0, #0x2c894b0                             
02c894a0: mov     w8, #1                                     
02c894a4: strb    w8, [x0, #0x4a]                            
02c894a8: ldp     x30, x19, [sp], #0x10                      
02c894ac: b       #0x2c8a4e8                                 AdsManager::ShowBanner
02c894b0: bl      #0x2b7105c                                 fn_2b7105c
#### CLASS AdsManager/<>c__DisplayClass42_0 parent= object
#   field <>4__this                      AdsManager                                         off=0x10 attr=6 
#   field action                         System.Action                                      off=0x18 attr=6 
## .ctor() -> void
---- AdsManager/<>c__DisplayClass42_0::.ctor 0x2c8a0b4
02c8a0b4: mov     x1, xzr                                    
02c8a0b8: b       #0x4e53e9c                                 System.Object::.ctor
## <ShowInterAdmob>b__0() -> void
---- AdsManager/<>c__DisplayClass42_0::<ShowInterAdmob>b__0 0x2c8ab14
02c8ab14: stp     x30, x19, [sp, #-0x10]!                    
02c8ab18: mov     x19, x0                                    
02c8ab1c: ldr     x0, [x0, #0x10]                            .<>4__this
02c8ab20: cbz     x0, #0x2c8ab50                             
02c8ab24: ldr     x8, [x19, #0x18]                           .action
02c8ab28: strb    wzr, [x0, #0x4b]                           
02c8ab2c: cbz     x8, #0x2c8ab48                             
02c8ab30: ldr     x9, [x8, #0x18]                            
02c8ab34: ldr     x0, [x8, #0x40]                            
02c8ab38: ldr     x1, [x8, #0x28]                            
02c8ab3c: blr     x9                                         
02c8ab40: ldr     x0, [x19, #0x10]                           .<>4__this
02c8ab44: cbz     x0, #0x2c8ab50                             
02c8ab48: ldp     x30, x19, [sp], #0x10                      
02c8ab4c: b       #0x2c88954                                 AdsManager::ResetCapping
02c8ab50: bl      #0x2b7105c                                 fn_2b7105c
## <ShowInterAdmob>b__1() -> void
---- AdsManager/<>c__DisplayClass42_0::<ShowInterAdmob>b__1 0x2c8ab54
02c8ab54: stp     x30, x19, [sp, #-0x10]!                    
02c8ab58: mov     x19, x0                                    
02c8ab5c: ldr     x0, [x0, #0x10]                            .<>4__this
02c8ab60: cbz     x0, #0x2c8ab90                             
02c8ab64: ldr     x8, [x19, #0x18]                           .action
02c8ab68: strb    wzr, [x0, #0x4b]                           
02c8ab6c: cbz     x8, #0x2c8ab88                             
02c8ab70: ldr     x9, [x8, #0x18]                            
02c8ab74: ldr     x0, [x8, #0x40]                            
02c8ab78: ldr     x1, [x8, #0x28]                            
02c8ab7c: blr     x9                                         
02c8ab80: ldr     x0, [x19, #0x10]                           .<>4__this
02c8ab84: cbz     x0, #0x2c8ab90                             
02c8ab88: ldp     x30, x19, [sp], #0x10                      
02c8ab8c: b       #0x2c88954                                 AdsManager::ResetCapping
02c8ab90: bl      #0x2b7105c                                 fn_2b7105c
#### CLASS AdsManager/<>c__DisplayClass43_0 parent= object
#   field <>4__this                      AdsManager                                         off=0x10 attr=6 
#   field placment                       string                                             off=0x18 attr=6 
#   field action                         System.Action                                      off=0x20 attr=6 
#   field wasAudioPaused                 bool                                               off=0x28 attr=6 
#   field <>9__3                         System.Action                                      off=0x30 attr=6 
## .ctor() -> void
---- AdsManager/<>c__DisplayClass43_0::.ctor 0x2c8a16c
02c8a16c: mov     x1, xzr                                    
02c8a170: b       #0x4e53e9c                                 System.Object::.ctor
## <ShowInterDouble>g__ResumeGameAudio|0() -> void
---- AdsManager/<>c__DisplayClass43_0::<ShowInterDouble>g__ResumeGameAudio|0 0x2c8a258
02c8a258: ldrb    w0, [x0, #0x28]                            .wasAudioPaused
02c8a25c: mov     x1, xzr                                    
02c8a260: b       #0x5adf0f8                                 UnityEngine.AudioListener::set_pause
## <ShowInterDouble>b__1() -> void
---- AdsManager/<>c__DisplayClass43_0::<ShowInterDouble>b__1 0x2c8ab94
02c8ab94: stp     x30, x23, [sp, #-0x30]!                    
02c8ab98: stp     x22, x21, [sp, #0x10]                      
02c8ab9c: stp     x20, x19, [sp, #0x20]                      
02c8aba0: adrp    x20, #0x662f000                            
02c8aba4: mov     x19, x0                                    
02c8aba8: ldrb    w8, [x20, #0x976]                          
02c8abac: tbnz    w8, #0, #0x2c8ac0c                         
02c8abb0: adrp    x0, #0x6264000                             
02c8abb4: ldr     x0, [x0, #0xf90]                           T:System.Action
02c8abb8: bl      #0x2b70db0                                 fn_2b70db0
02c8abbc: adrp    x0, #0x6263000                             
02c8abc0: ldr     x0, [x0, #0x928]                           T:UnityEngine.Debug
02c8abc4: bl      #0x2b70db0                                 fn_2b70db0
02c8abc8: adrp    x0, #0x6265000                             
02c8abcc: ldr     x0, [x0, #0x168]                           M:AdsManager/<>c__DisplayClass43_0::<ShowInterDouble>b__3
02c8abd0: bl      #0x2b70db0                                 fn_2b70db0
02c8abd4: adrp    x0, #0x6265000                             
02c8abd8: ldr     x0, [x0, #0x80]                            S:'af_inters_load_fail'
02c8abdc: bl      #0x2b70db0                                 fn_2b70db0
02c8abe0: adrp    x0, #0x6265000                             
02c8abe4: ldr     x0, [x0, #0x170]                           S:'dev log AdsManager show inter max after native fullscreen'
02c8abe8: bl      #0x2b70db0                                 fn_2b70db0
02c8abec: adrp    x0, #0x6265000                             
02c8abf0: ldr     x0, [x0, #0x90]                            S:'af_inters_available'
02c8abf4: bl      #0x2b70db0                                 fn_2b70db0
02c8abf8: adrp    x0, #0x6265000                             
02c8abfc: ldr     x0, [x0, #0x98]                            S:'[Inter] show failed'
02c8ac00: bl      #0x2b70db0                                 fn_2b70db0
02c8ac04: mov     w8, #1                                     
02c8ac08: strb    w8, [x20, #0x976]                          
02c8ac0c: ldr     x0, [x19, #0x10]                           .<>4__this
02c8ac10: cbz     x0, #0x2c8ad8c                             
02c8ac14: bl      #0x2c88f94                                 AdsManager::HideAdResume
02c8ac18: ldr     x0, [x19, #0x10]                           .<>4__this
02c8ac1c: cbz     x0, #0x2c8ad8c                             
02c8ac20: bl      #0x2c88954                                 AdsManager::ResetCapping
02c8ac24: ldr     x8, [x19, #0x10]                           .<>4__this
02c8ac28: cbz     x8, #0x2c8ad8c                             
02c8ac2c: ldr     x8, [x8, #0x20]                            
02c8ac30: cbz     x8, #0x2c8ad8c                             
02c8ac34: ldr     x8, [x8, #0x20]                            
02c8ac38: cbz     x8, #0x2c8ad8c                             
02c8ac3c: bl      #0x2c8c8c8                                 InterApplovinControl::IsAdReady
02c8ac40: tbz     w0, #0, #0x2c8ad18                         
02c8ac44: adrp    x8, #0x6263000                             
02c8ac48: ldr     x8, [x8, #0x928]                           T:UnityEngine.Debug
02c8ac4c: ldr     x0, [x8]                                   &2c5bbd4(=a9bd7bfdd503233f)
02c8ac50: ldr     w8, [x0, #0xe4]                            [62650e4]=0 f=0,0
02c8ac54: cbnz    w8, #0x2c8ac5c                             
02c8ac58: bl      #0x2b70f30                                 fn_2b70f30
02c8ac5c: adrp    x8, #0x6265000                             
02c8ac60: mov     x1, xzr                                    
02c8ac64: ldr     x8, [x8, #0x170]                           S:'dev log AdsManager show inter max after native fullscreen'
02c8ac68: ldr     x0, [x8]                                   M:AdsManager::<OnApplicationPause>b__26_0
02c8ac6c: bl      #0x5af21f4                                 UnityEngine.Debug::Log
02c8ac70: adrp    x8, #0x6265000                             
02c8ac74: mov     x1, xzr                                    
02c8ac78: ldr     x8, [x8, #0x90]                            S:'af_inters_available'
02c8ac7c: ldr     x0, [x8]                                   M:AdsManager::<OnApplicationPause>b__26_0
02c8ac80: bl      #0x2c89794                                 AnalyticsManager::LogAppsflyerEvent
02c8ac84: ldr     x0, [x19, #0x10]                           .<>4__this
02c8ac88: cbz     x0, #0x2c8ad8c                             
02c8ac8c: ldr     w8, [x0, #0x58]                            S:'dev log AdsManager show inter max'
02c8ac90: add     w8, w8, #1                                 
02c8ac94: str     w8, [x0, #0x58]                            
02c8ac98: bl      #0x2c88f94                                 AdsManager::HideAdResume
02c8ac9c: ldr     x8, [x19, #0x10]                           .<>4__this
02c8aca0: cbz     x8, #0x2c8ad8c                             
02c8aca4: mov     x22, x19                                   
02c8aca8: ldr     x23, [x8, #0x20]                           S:'dev log AdsManager show app open ad'
02c8acac: ldr     x21, [x22, #0x30]!                         
02c8acb0: ldur    x20, [x22, #-0x18]                         
02c8acb4: cbnz    x21, #0x2c8acf4                            
02c8acb8: adrp    x8, #0x6264000                             
02c8acbc: ldr     x8, [x8, #0xf90]                           T:System.Action
02c8acc0: ldr     x0, [x8]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c8acc4: bl      #0x2b7104c                                 fn_2b7104c
02c8acc8: adrp    x8, #0x6265000                             
02c8accc: mov     x1, x19                                    
02c8acd0: mov     x3, xzr                                    
02c8acd4: ldr     x8, [x8, #0x168]                           M:AdsManager/<>c__DisplayClass43_0::<ShowInterDouble>b__3
02c8acd8: mov     x21, x0                                    
02c8acdc: ldr     x2, [x8]                                   M:AdsManager::<OnApplicationPause>b__26_0
02c8ace0: bl      #0x4d8ddbc                                 System.Action::.ctor
02c8ace4: mov     x0, x22                                    
02c8ace8: mov     x1, x21                                    
02c8acec: str     x21, [x19, #0x30]                          .<>9__3
02c8acf0: bl      #0x2b70d54                                 fn_2b70d54
02c8acf4: cbz     x23, #0x2c8ad8c                            
02c8acf8: ldr     x0, [x23, #0x20]                           
02c8acfc: cbz     x0, #0x2c8ad8c                             
02c8ad00: mov     x1, x20                                    
02c8ad04: mov     x2, x21                                    
02c8ad08: ldp     x20, x19, [sp, #0x20]                      
02c8ad0c: ldp     x22, x21, [sp, #0x10]                      
02c8ad10: ldp     x30, x23, [sp], #0x30                      
02c8ad14: b       #0x2c8cba4                                 InterApplovinControl::ShowAd
02c8ad18: adrp    x8, #0x6265000                             
02c8ad1c: mov     x1, xzr                                    
02c8ad20: ldr     x8, [x8, #0x80]                            S:'af_inters_load_fail'
02c8ad24: ldr     x0, [x8]                                   M:AdsManager::<OnApplicationPause>b__26_0
02c8ad28: bl      #0x2c89794                                 AnalyticsManager::LogAppsflyerEvent
02c8ad2c: adrp    x8, #0x6265000                             
02c8ad30: mov     x1, xzr                                    
02c8ad34: ldr     x8, [x8, #0x98]                            S:'[Inter] show failed'
02c8ad38: ldr     x0, [x8]                                   M:AdsManager::<OnApplicationPause>b__26_0
02c8ad3c: bl      #0x2ca09f8                                 WLog::LogError
02c8ad40: ldrb    w0, [x19, #0x28]                           .wasAudioPaused
02c8ad44: mov     x1, xzr                                    
02c8ad48: bl      #0x5adf0f8                                 UnityEngine.AudioListener::set_pause
02c8ad4c: ldr     x9, [x19, #0x10]                           .<>4__this
02c8ad50: cbz     x9, #0x2c8ad8c                             
02c8ad54: ldr     x8, [x19, #0x20]                           .action
02c8ad58: strb    wzr, [x9, #0x4b]                           
02c8ad5c: cbz     x8, #0x2c8ad7c                             
02c8ad60: ldp     x20, x19, [sp, #0x20]                      
02c8ad64: ldr     x0, [x8, #0x40]                            S:'done_ad'
02c8ad68: ldp     x22, x21, [sp, #0x10]                      
02c8ad6c: ldr     x1, [x8, #0x28]                            T:AdsManager/<ISetAOAInterval>d__33
02c8ad70: ldr     x2, [x8, #0x18]                            T:AdsManager/<IEHideAdResume>d__30
02c8ad74: ldp     x30, x23, [sp], #0x30                      
02c8ad78: br      x2                                         
02c8ad7c: ldp     x20, x19, [sp, #0x20]                      
02c8ad80: ldp     x22, x21, [sp, #0x10]                      
02c8ad84: ldp     x30, x23, [sp], #0x30                      
02c8ad88: ret                                                
02c8ad8c: bl      #0x2b7105c                                 fn_2b7105c
## <ShowInterDouble>b__3() -> void
---- AdsManager/<>c__DisplayClass43_0::<ShowInterDouble>b__3 0x2c8ad90
02c8ad90: str     x30, [sp, #-0x20]!                         
02c8ad94: stp     x20, x19, [sp, #0x10]                      
02c8ad98: adrp    x20, #0x662f000                            
02c8ad9c: mov     x19, x0                                    
02c8ada0: ldrb    w8, [x20, #0x977]                          
02c8ada4: tbnz    w8, #0, #0x2c8adbc                         
02c8ada8: adrp    x0, #0x6265000                             
02c8adac: ldr     x0, [x0, #0x178]                           S:'af_inters_displayed'
02c8adb0: bl      #0x2b70db0                                 fn_2b70db0
02c8adb4: mov     w8, #1                                     
02c8adb8: strb    w8, [x20, #0x977]                          
02c8adbc: ldr     x0, [x19, #0x10]                           .<>4__this
02c8adc0: cbz     x0, #0x2c8ae20                             
02c8adc4: adrp    x20, #0x6265000                            
02c8adc8: ldr     x20, [x20, #0x178]                         S:'af_inters_displayed'
02c8adcc: bl      #0x2c88f94                                 AdsManager::HideAdResume
02c8add0: ldr     x0, [x20]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c8add4: mov     x1, xzr                                    
02c8add8: bl      #0x2c89794                                 AnalyticsManager::LogAppsflyerEvent
02c8addc: ldrb    w0, [x19, #0x28]                           .wasAudioPaused
02c8ade0: mov     x1, xzr                                    
02c8ade4: bl      #0x5adf0f8                                 UnityEngine.AudioListener::set_pause
02c8ade8: ldr     x0, [x19, #0x10]                           .<>4__this
02c8adec: cbz     x0, #0x2c8ae20                             
02c8adf0: ldr     x8, [x19, #0x20]                           .action
02c8adf4: strb    wzr, [x0, #0x4b]                           
02c8adf8: cbz     x8, #0x2c8ae14                             
02c8adfc: ldr     x9, [x8, #0x18]                            
02c8ae00: ldr     x0, [x8, #0x40]                            
02c8ae04: ldr     x1, [x8, #0x28]                            
02c8ae08: blr     x9                                         
02c8ae0c: ldr     x0, [x19, #0x10]                           .<>4__this
02c8ae10: cbz     x0, #0x2c8ae20                             
02c8ae14: ldp     x20, x19, [sp, #0x10]                      
02c8ae18: ldr     x30, [sp], #0x20                           
02c8ae1c: b       #0x2c88954                                 AdsManager::ResetCapping
02c8ae20: bl      #0x2b7105c                                 fn_2b7105c
## <ShowInterDouble>b__2() -> void
---- AdsManager/<>c__DisplayClass43_0::<ShowInterDouble>b__2 0x2c8ae24
02c8ae24: str     x30, [sp, #-0x30]!                         
02c8ae28: stp     x22, x21, [sp, #0x10]                      
02c8ae2c: stp     x20, x19, [sp, #0x20]                      
02c8ae30: adrp    x22, #0x662f000                            
02c8ae34: adrp    x21, #0x6265000                            
02c8ae38: adrp    x20, #0x6263000                            
02c8ae3c: ldrb    w8, [x22, #0x978]                          
02c8ae40: ldr     x21, [x21, #0x178]                         S:'af_inters_displayed'
02c8ae44: ldr     x20, [x20, #0x928]                         T:UnityEngine.Debug
02c8ae48: mov     x19, x0                                    
02c8ae4c: tbnz    w8, #0, #0x2c8ae7c                         
02c8ae50: adrp    x0, #0x6263000                             
02c8ae54: ldr     x0, [x0, #0x928]                           T:UnityEngine.Debug
02c8ae58: bl      #0x2b70db0                                 fn_2b70db0
02c8ae5c: adrp    x0, #0x6265000                             
02c8ae60: ldr     x0, [x0, #0x178]                           S:'af_inters_displayed'
02c8ae64: bl      #0x2b70db0                                 fn_2b70db0
02c8ae68: adrp    x0, #0x6265000                             
02c8ae6c: ldr     x0, [x0, #0x180]                           S:'dev log AdsManager show native after inter'
02c8ae70: bl      #0x2b70db0                                 fn_2b70db0
02c8ae74: mov     w8, #1                                     
02c8ae78: strb    w8, [x22, #0x978]                          
02c8ae7c: adrp    x22, #0x6265000                            
02c8ae80: mov     x1, xzr                                    
02c8ae84: ldr     x22, [x22, #0x180]                         S:'dev log AdsManager show native after inter'
02c8ae88: ldr     x0, [x21]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c8ae8c: bl      #0x2c89794                                 AnalyticsManager::LogAppsflyerEvent
02c8ae90: ldr     x0, [x20]                                  &2c5bbd4(=a9bd7bfdd503233f)
02c8ae94: ldr     w8, [x0, #0xe4]                            [62650e4]=0 f=0,0
02c8ae98: cbnz    w8, #0x2c8aea0                             
02c8ae9c: bl      #0x2b70f30                                 fn_2b70f30
02c8aea0: ldr     x0, [x22]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c8aea4: mov     x1, xzr                                    
02c8aea8: bl      #0x5af21f4                                 UnityEngine.Debug::Log
02c8aeac: ldr     x0, [x19, #0x10]                           .<>4__this
02c8aeb0: cbz     x0, #0x2c8af00                             
02c8aeb4: bl      #0x2c88f94                                 AdsManager::HideAdResume
02c8aeb8: ldrb    w0, [x19, #0x28]                           .wasAudioPaused
02c8aebc: mov     x1, xzr                                    
02c8aec0: bl      #0x5adf0f8                                 UnityEngine.AudioListener::set_pause
02c8aec4: ldr     x0, [x19, #0x10]                           .<>4__this
02c8aec8: cbz     x0, #0x2c8af00                             
02c8aecc: ldr     x8, [x19, #0x20]                           .action
02c8aed0: strb    wzr, [x0, #0x4b]                           
02c8aed4: cbz     x8, #0x2c8aef0                             
02c8aed8: ldr     x9, [x8, #0x18]                            
02c8aedc: ldr     x0, [x8, #0x40]                            
02c8aee0: ldr     x1, [x8, #0x28]                            
02c8aee4: blr     x9                                         
02c8aee8: ldr     x0, [x19, #0x10]                           .<>4__this
02c8aeec: cbz     x0, #0x2c8af00                             
02c8aef0: ldp     x20, x19, [sp, #0x20]                      
02c8aef4: ldp     x22, x21, [sp, #0x10]                      
02c8aef8: ldr     x30, [sp], #0x30                           
02c8aefc: b       #0x2c88954                                 AdsManager::ResetCapping
02c8af00: bl      #0x2b7105c                                 fn_2b7105c
#### CLASS AdsManager/<>c__DisplayClass44_0 parent= object
#   field <>4__this                      AdsManager                                         off=0x10 attr=6 
#   field action                         System.Action                                      off=0x18 attr=6 
#   field wasAudioPaused                 bool                                               off=0x20 attr=6 
## .ctor() -> void
---- AdsManager/<>c__DisplayClass44_0::.ctor 0x2c8a264
02c8a264: mov     x1, xzr                                    
02c8a268: b       #0x4e53e9c                                 System.Object::.ctor
## <ShowNativeInterBackFill>g__ResumeGameAudio|0() -> void
---- AdsManager/<>c__DisplayClass44_0::<ShowNativeInterBackFill>g__ResumeGameAudio|0 0x2c8a28c
02c8a28c: ldrb    w0, [x0, #0x20]                            .wasAudioPaused
02c8a290: mov     x1, xzr                                    
02c8a294: b       #0x5adf0f8                                 UnityEngine.AudioListener::set_pause
## <ShowNativeInterBackFill>b__1() -> void
---- AdsManager/<>c__DisplayClass44_0::<ShowNativeInterBackFill>b__1 0x2c8af04
02c8af04: stp     x30, x21, [sp, #-0x20]!                    
02c8af08: stp     x20, x19, [sp, #0x10]                      
02c8af0c: adrp    x21, #0x662f000                            
02c8af10: adrp    x20, #0x6263000                            
02c8af14: mov     x19, x0                                    
02c8af18: ldrb    w8, [x21, #0x979]                          
02c8af1c: ldr     x20, [x20, #0x928]                         T:UnityEngine.Debug
02c8af20: tbnz    w8, #0, #0x2c8af5c                         
02c8af24: adrp    x0, #0x6263000                             
02c8af28: ldr     x0, [x0, #0x928]                           T:UnityEngine.Debug
02c8af2c: bl      #0x2b70db0                                 fn_2b70db0
02c8af30: adrp    x0, #0x6265000                             
02c8af34: ldr     x0, [x0, #0x170]                           S:'dev log AdsManager show inter max after native fullscreen'
02c8af38: bl      #0x2b70db0                                 fn_2b70db0
02c8af3c: adrp    x0, #0x6265000                             
02c8af40: ldr     x0, [x0, #0x178]                           S:'af_inters_displayed'
02c8af44: bl      #0x2b70db0                                 fn_2b70db0
02c8af48: adrp    x0, #0x6265000                             
02c8af4c: ldr     x0, [x0, #0x90]                            S:'af_inters_available'
02c8af50: bl      #0x2b70db0                                 fn_2b70db0
02c8af54: mov     w8, #1                                     
02c8af58: strb    w8, [x21, #0x979]                          
02c8af5c: ldr     x0, [x20]                                  &2c5bbd4(=a9bd7bfdd503233f)
02c8af60: adrp    x21, #0x6265000                            
02c8af64: adrp    x20, #0x6265000                            
02c8af68: ldr     x21, [x21, #0x170]                         S:'dev log AdsManager show inter max after native fullscreen'
02c8af6c: ldr     w8, [x0, #0xe4]                            [62650e4]=0 f=0,0
02c8af70: ldr     x20, [x20, #0x90]                          S:'af_inters_available'
02c8af74: cbnz    w8, #0x2c8af7c                             
02c8af78: bl      #0x2b70f30                                 fn_2b70f30
02c8af7c: ldr     x0, [x21]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c8af80: mov     x1, xzr                                    
02c8af84: bl      #0x5af21f4                                 UnityEngine.Debug::Log
02c8af88: ldr     x0, [x20]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c8af8c: mov     x1, xzr                                    
02c8af90: bl      #0x2c89794                                 AnalyticsManager::LogAppsflyerEvent
02c8af94: ldr     x0, [x19, #0x10]                           .<>4__this
02c8af98: cbz     x0, #0x2c8b004                             
02c8af9c: ldr     w8, [x0, #0x58]                            S:'dev log AdsManager show inter max'
02c8afa0: adrp    x20, #0x6265000                            
02c8afa4: ldr     x20, [x20, #0x178]                         S:'af_inters_displayed'
02c8afa8: add     w8, w8, #1                                 
02c8afac: str     w8, [x0, #0x58]                            
02c8afb0: bl      #0x2c88f94                                 AdsManager::HideAdResume
02c8afb4: ldr     x0, [x20]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c8afb8: mov     x1, xzr                                    
02c8afbc: bl      #0x2c89794                                 AnalyticsManager::LogAppsflyerEvent
02c8afc0: ldrb    w0, [x19, #0x20]                           .wasAudioPaused
02c8afc4: mov     x1, xzr                                    
02c8afc8: bl      #0x5adf0f8                                 UnityEngine.AudioListener::set_pause
02c8afcc: ldr     x0, [x19, #0x10]                           .<>4__this
02c8afd0: cbz     x0, #0x2c8b004                             
02c8afd4: ldr     x8, [x19, #0x18]                           .action
02c8afd8: strb    wzr, [x0, #0x4b]                           
02c8afdc: cbz     x8, #0x2c8aff8                             
02c8afe0: ldr     x9, [x8, #0x18]                            
02c8afe4: ldr     x0, [x8, #0x40]                            
02c8afe8: ldr     x1, [x8, #0x28]                            
02c8afec: blr     x9                                         
02c8aff0: ldr     x0, [x19, #0x10]                           .<>4__this
02c8aff4: cbz     x0, #0x2c8b004                             
02c8aff8: ldp     x20, x19, [sp, #0x10]                      
02c8affc: ldp     x30, x21, [sp], #0x20                      
02c8b000: b       #0x2c88954                                 AdsManager::ResetCapping
02c8b004: bl      #0x2b7105c                                 fn_2b7105c
## <ShowNativeInterBackFill>b__2() -> void
---- AdsManager/<>c__DisplayClass44_0::<ShowNativeInterBackFill>b__2 0x2c8b008
02c8b008: str     x30, [sp, #-0x30]!                         
02c8b00c: stp     x22, x21, [sp, #0x10]                      
02c8b010: stp     x20, x19, [sp, #0x20]                      
02c8b014: adrp    x22, #0x662f000                            
02c8b018: adrp    x21, #0x6265000                            
02c8b01c: adrp    x20, #0x6263000                            
02c8b020: ldrb    w8, [x22, #0x97a]                          
02c8b024: ldr     x21, [x21, #0x178]                         S:'af_inters_displayed'
02c8b028: ldr     x20, [x20, #0x928]                         T:UnityEngine.Debug
02c8b02c: mov     x19, x0                                    
02c8b030: tbnz    w8, #0, #0x2c8b060                         
02c8b034: adrp    x0, #0x6263000                             
02c8b038: ldr     x0, [x0, #0x928]                           T:UnityEngine.Debug
02c8b03c: bl      #0x2b70db0                                 fn_2b70db0
02c8b040: adrp    x0, #0x6265000                             
02c8b044: ldr     x0, [x0, #0x178]                           S:'af_inters_displayed'
02c8b048: bl      #0x2b70db0                                 fn_2b70db0
02c8b04c: adrp    x0, #0x6265000                             
02c8b050: ldr     x0, [x0, #0x180]                           S:'dev log AdsManager show native after inter'
02c8b054: bl      #0x2b70db0                                 fn_2b70db0
02c8b058: mov     w8, #1                                     
02c8b05c: strb    w8, [x22, #0x97a]                          
02c8b060: adrp    x22, #0x6265000                            
02c8b064: mov     x1, xzr                                    
02c8b068: ldr     x22, [x22, #0x180]                         S:'dev log AdsManager show native after inter'
02c8b06c: ldr     x0, [x21]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c8b070: bl      #0x2c89794                                 AnalyticsManager::LogAppsflyerEvent
02c8b074: ldr     x0, [x20]                                  &2c5bbd4(=a9bd7bfdd503233f)
02c8b078: ldr     w8, [x0, #0xe4]                            [62650e4]=0 f=0,0
02c8b07c: cbnz    w8, #0x2c8b084                             
02c8b080: bl      #0x2b70f30                                 fn_2b70f30
02c8b084: ldr     x0, [x22]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c8b088: mov     x1, xzr                                    
02c8b08c: bl      #0x5af21f4                                 UnityEngine.Debug::Log
02c8b090: ldr     x0, [x19, #0x10]                           .<>4__this
02c8b094: cbz     x0, #0x2c8b0e4                             
02c8b098: bl      #0x2c88f94                                 AdsManager::HideAdResume
02c8b09c: ldrb    w0, [x19, #0x20]                           .wasAudioPaused
02c8b0a0: mov     x1, xzr                                    
02c8b0a4: bl      #0x5adf0f8                                 UnityEngine.AudioListener::set_pause
02c8b0a8: ldr     x0, [x19, #0x10]                           .<>4__this
02c8b0ac: cbz     x0, #0x2c8b0e4                             
02c8b0b0: ldr     x8, [x19, #0x18]                           .action
02c8b0b4: strb    wzr, [x0, #0x4b]                           
02c8b0b8: cbz     x8, #0x2c8b0d4                             
02c8b0bc: ldr     x9, [x8, #0x18]                            
02c8b0c0: ldr     x0, [x8, #0x40]                            
02c8b0c4: ldr     x1, [x8, #0x28]                            
02c8b0c8: blr     x9                                         
02c8b0cc: ldr     x0, [x19, #0x10]                           .<>4__this
02c8b0d0: cbz     x0, #0x2c8b0e4                             
02c8b0d4: ldp     x20, x19, [sp, #0x20]                      
02c8b0d8: ldp     x22, x21, [sp, #0x10]                      
02c8b0dc: ldr     x30, [sp], #0x30                           
02c8b0e0: b       #0x2c88954                                 AdsManager::ResetCapping
02c8b0e4: bl      #0x2b7105c                                 fn_2b7105c
#### CLASS AdsManager/<>c__DisplayClass46_0 parent= object
#   field action                         System.Action                                      off=0x10 attr=6 
#   field <>4__this                      AdsManager                                         off=0x18 attr=6 
## .ctor() -> void
---- AdsManager/<>c__DisplayClass46_0::.ctor 0x2c8a4b8
02c8a4b8: mov     x1, xzr                                    
02c8a4bc: b       #0x4e53e9c                                 System.Object::.ctor
## <ShowRewarded>b__0() -> void
---- AdsManager/<>c__DisplayClass46_0::<ShowRewarded>b__0 0x2c8b0e8
02c8b0e8: str     x30, [sp, #-0x30]!                         
02c8b0ec: stp     x22, x21, [sp, #0x10]                      
02c8b0f0: stp     x20, x19, [sp, #0x20]                      
02c8b0f4: adrp    x21, #0x662f000                            
02c8b0f8: adrp    x20, #0x6263000                            
02c8b0fc: mov     x19, x0                                    
02c8b100: ldrb    w8, [x21, #0x97b]                          
02c8b104: ldr     x20, [x20, #0x928]                         T:UnityEngine.Debug
02c8b108: tbnz    w8, #0, #0x2c8b144                         
02c8b10c: adrp    x0, #0x6263000                             
02c8b110: ldr     x0, [x0, #0x928]                           T:UnityEngine.Debug
02c8b114: bl      #0x2b70db0                                 fn_2b70db0
02c8b118: adrp    x0, #0x6265000                             
02c8b11c: ldr     x0, [x0, #0x188]                           S:'dev log AdsManager show rewarded 2'
02c8b120: bl      #0x2b70db0                                 fn_2b70db0
02c8b124: adrp    x0, #0x6265000                             
02c8b128: ldr     x0, [x0, #0x190]                           S:'af_rewarded_completed'
02c8b12c: bl      #0x2b70db0                                 fn_2b70db0
02c8b130: adrp    x0, #0x6265000                             
02c8b134: ldr     x0, [x0, #0x198]                           S:'af_rewarded_displayed'
02c8b138: bl      #0x2b70db0                                 fn_2b70db0
02c8b13c: mov     w8, #1                                     
02c8b140: strb    w8, [x21, #0x97b]                          
02c8b144: ldr     x0, [x20]                                  &2c5bbd4(=a9bd7bfdd503233f)
02c8b148: adrp    x22, #0x6265000                            
02c8b14c: adrp    x21, #0x6265000                            
02c8b150: adrp    x20, #0x6265000                            
02c8b154: ldr     x22, [x22, #0x188]                         S:'dev log AdsManager show rewarded 2'
02c8b158: ldr     x21, [x21, #0x198]                         S:'af_rewarded_displayed'
02c8b15c: ldr     w8, [x0, #0xe4]                            [62650e4]=0 f=0,0
02c8b160: ldr     x20, [x20, #0x190]                         S:'af_rewarded_completed'
02c8b164: cbnz    w8, #0x2c8b16c                             
02c8b168: bl      #0x2b70f30                                 fn_2b70f30
02c8b16c: ldr     x0, [x22]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c8b170: mov     x1, xzr                                    
02c8b174: bl      #0x5af21f4                                 UnityEngine.Debug::Log
02c8b178: ldr     x0, [x21]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c8b17c: mov     x1, xzr                                    
02c8b180: bl      #0x2c89794                                 AnalyticsManager::LogAppsflyerEvent
02c8b184: ldr     x0, [x20]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c8b188: mov     x1, xzr                                    
02c8b18c: bl      #0x2c89794                                 AnalyticsManager::LogAppsflyerEvent
02c8b190: ldr     x8, [x19, #0x10]                           .action
02c8b194: cbz     x8, #0x2c8b1a8                             
02c8b198: ldr     x9, [x8, #0x18]                            
02c8b19c: ldr     x0, [x8, #0x40]                            
02c8b1a0: ldr     x1, [x8, #0x28]                            
02c8b1a4: blr     x9                                         
02c8b1a8: ldr     x0, [x19, #0x18]                           .<>4__this
02c8b1ac: cbz     x0, #0x2c8b1c0                             
02c8b1b0: ldp     x20, x19, [sp, #0x20]                      
02c8b1b4: ldp     x22, x21, [sp, #0x10]                      
02c8b1b8: ldr     x30, [sp], #0x30                           
02c8b1bc: b       #0x2c88954                                 AdsManager::ResetCapping
02c8b1c0: bl      #0x2b7105c                                 fn_2b7105c
#### CLASS AdsManager/<IEHideAdResume>d__30 parent= object
#   field <>1__state                     int                                                off=0x10 attr=1 
#   field <>2__current                   object                                             off=0x18 attr=1 
#   field <>4__this                      AdsManager                                         off=0x20 attr=6 
## .ctor(int <>1__state) -> void
---- AdsManager/<IEHideAdResume>d__30::.ctor 0x2c89054
02c89054: str     x30, [sp, #-0x20]!                         
02c89058: stp     x20, x19, [sp, #0x10]                      
02c8905c: mov     w19, w1                                    
02c89060: mov     x1, xzr                                    
02c89064: mov     x20, x0                                    
02c89068: bl      #0x4e53e9c                                 System.Object::.ctor
02c8906c: str     w19, [x20, #0x10]                          .<>1__state
02c89070: ldp     x20, x19, [sp, #0x10]                      
02c89074: ldr     x30, [sp], #0x20                           
02c89078: ret                                                
## System.IDisposable.Dispose() -> void
---- AdsManager/<IEHideAdResume>d__30::System.IDisposable.Dispose 0x2c8b1c4
02c8b1c4: ret                                                
## MoveNext() -> bool
---- AdsManager/<IEHideAdResume>d__30::MoveNext 0x2c8b1c8
02c8b1c8: stp     x30, x21, [sp, #-0x20]!                    
02c8b1cc: stp     x20, x19, [sp, #0x10]                      
02c8b1d0: adrp    x20, #0x662f000                            
02c8b1d4: mov     x19, x0                                    
02c8b1d8: ldrb    w8, [x20, #0x97c]                          
02c8b1dc: tbnz    w8, #0, #0x2c8b1f4                         
02c8b1e0: adrp    x0, #0x6264000                             
02c8b1e4: ldr     x0, [x0, #0xf58]                           T:UnityEngine.WaitForSeconds
02c8b1e8: bl      #0x2b70db0                                 fn_2b70db0
02c8b1ec: mov     w8, #1                                     
02c8b1f0: strb    w8, [x20, #0x97c]                          
02c8b1f4: ldr     w21, [x19, #0x10]                          .<>1__state
02c8b1f8: ldr     x8, [x19, #0x20]                           .<>4__this
02c8b1fc: cbz     w21, #0x2c8b220                            
02c8b200: cmp     w21, #1                                    
02c8b204: b.ne    #0x2c8b268                                 
02c8b208: mov     w9, #-1                                    
02c8b20c: str     w9, [x19, #0x10]                           .<>1__state
02c8b210: cbz     x8, #0x2c8b27c                             
02c8b214: mov     w9, #1                                     
02c8b218: strb    w9, [x8, #0x4a]                            
02c8b21c: b       #0x2c8b268                                 
02c8b220: mov     w9, #-1                                    
02c8b224: str     w9, [x19, #0x10]                           .<>1__state
02c8b228: cbz     x8, #0x2c8b27c                             
02c8b22c: adrp    x9, #0x6264000                             
02c8b230: ldr     x9, [x9, #0xf58]                           T:UnityEngine.WaitForSeconds
02c8b234: strb    wzr, [x8, #0x4a]                           
02c8b238: ldr     x0, [x9]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c8b23c: bl      #0x2b7104c                                 fn_2b7104c
02c8b240: fmov    s0, #2.00000000                            
02c8b244: mov     x1, xzr                                    
02c8b248: mov     x20, x0                                    
02c8b24c: bl      #0x5b3e5e8                                 UnityEngine.WaitForSeconds::.ctor
02c8b250: str     x20, [x19, #0x18]!                         .<>2__current
02c8b254: mov     x0, x19                                    
02c8b258: mov     x1, x20                                    
02c8b25c: bl      #0x2b70d54                                 fn_2b70d54
02c8b260: mov     w8, #1                                     
02c8b264: stur    w8, [x19, #-8]                             
02c8b268: ldp     x20, x19, [sp, #0x10]                      
02c8b26c: cmp     w21, #0                                    
02c8b270: cset    w0, eq                                     
02c8b274: ldp     x30, x21, [sp], #0x20                      
02c8b278: ret                                                
02c8b27c: bl      #0x2b7105c                                 fn_2b7105c
## System.Collections.Generic.IEnumerator<System.Object>.get_Current() -> object
---- AdsManager/<IEHideAdResume>d__30::System.Collections.Generic.IEnumerator<System.Object>.get_Current 0x2c8b280
02c8b280: ldr     x0, [x0, #0x18]                            .<>2__current
02c8b284: ret                                                
## System.Collections.IEnumerator.Reset() -> void
---- AdsManager/<IEHideAdResume>d__30::System.Collections.IEnumerator.Reset 0x2c8b288
02c8b288: stp     x30, x19, [sp, #-0x10]!                    
02c8b28c: adrp    x0, #0x6264000                             
02c8b290: ldr     x0, [x0, #0xf60]                           T:System.NotSupportedException
02c8b294: bl      #0x2b70dc4                                 fn_2b70dc4
02c8b298: bl      #0x2b7104c                                 fn_2b7104c
02c8b29c: mov     x1, xzr                                    
02c8b2a0: mov     x19, x0                                    
02c8b2a4: bl      #0x4e14238                                 System.NotSupportedException::.ctor
02c8b2a8: adrp    x0, #0x6265000                             
02c8b2ac: ldr     x0, [x0, #0x1a0]                           M:AdsManager/<IEHideAdResume>d__30::System.Collections.IEnumerator.Reset
02c8b2b0: bl      #0x2b70dc4                                 fn_2b70dc4
02c8b2b4: mov     x1, x0                                     
02c8b2b8: mov     x0, x19                                    
02c8b2bc: bl      #0x2b70f20                                 fn_2b70f20
## System.Collections.IEnumerator.get_Current() -> object
---- AdsManager/<IEHideAdResume>d__30::System.Collections.IEnumerator.get_Current 0x2c8b2c0
02c8b2c0: ldr     x0, [x0, #0x18]                            .<>2__current
02c8b2c4: ret                                                
#### CLASS AdsManager/<IRequestConsent>d__18 parent= object
#   field <>1__state                     int                                                off=0x10 attr=1 
#   field <>2__current                   object                                             off=0x18 attr=1 
#   field <>4__this                      AdsManager                                         off=0x20 attr=6 
#   field <>8__1                         AdsManager/<>c__DisplayClass18_0                   off=0x28 attr=1 
#   field onComplete                     System.Action                                      off=0x30 attr=6 
#   field <previousTimeScale>5__2        float                                              off=0x38 attr=1 
#   field <deadline>5__3                 float                                              off=0x3c attr=1 
## .ctor(int <>1__state) -> void
---- AdsManager/<IRequestConsent>d__18::.ctor 0x2c88c24
02c88c24: str     x30, [sp, #-0x20]!                         
02c88c28: stp     x20, x19, [sp, #0x10]                      
02c88c2c: mov     w19, w1                                    
02c88c30: mov     x1, xzr                                    
02c88c34: mov     x20, x0                                    
02c88c38: bl      #0x4e53e9c                                 System.Object::.ctor
02c88c3c: str     w19, [x20, #0x10]                          .<>1__state
02c88c40: ldp     x20, x19, [sp, #0x10]                      
02c88c44: ldr     x30, [sp], #0x20                           
02c88c48: ret                                                
## System.IDisposable.Dispose() -> void
---- AdsManager/<IRequestConsent>d__18::System.IDisposable.Dispose 0x2c8b2c8
02c8b2c8: ret                                                
## MoveNext() -> bool
---- AdsManager/<IRequestConsent>d__18::MoveNext 0x2c8b2cc
02c8b2cc: sub     sp, sp, #0x40                              
02c8b2d0: stp     x30, x23, [sp, #0x10]                      
02c8b2d4: stp     x22, x21, [sp, #0x20]                      
02c8b2d8: stp     x20, x19, [sp, #0x30]                      
02c8b2dc: adrp    x20, #0x662f000                            
02c8b2e0: mov     x19, x0                                    
02c8b2e4: ldrb    w8, [x20, #0x97d]                          
02c8b2e8: tbnz    w8, #0, #0x2c8b330                         
02c8b2ec: adrp    x0, #0x6264000                             
02c8b2f0: ldr     x0, [x0, #0xf90]                           T:System.Action
02c8b2f4: bl      #0x2b70db0                                 fn_2b70db0
02c8b2f8: adrp    x0, #0x6263000                             
02c8b2fc: ldr     x0, [x0, #0x928]                           T:UnityEngine.Debug
02c8b300: bl      #0x2b70db0                                 fn_2b70db0
02c8b304: adrp    x0, #0x6265000                             
02c8b308: ldr     x0, [x0, #0x1a8]                           M:AdsManager/<>c__DisplayClass18_0::<IRequestConsent>b__0
02c8b30c: bl      #0x2b70db0                                 fn_2b70db0
02c8b310: adrp    x0, #0x6265000                             
02c8b314: ldr     x0, [x0, #0x1b0]                           T:AdsManager/<>c__DisplayClass18_0
02c8b318: bl      #0x2b70db0                                 fn_2b70db0
02c8b31c: adrp    x0, #0x6265000                             
02c8b320: ldr     x0, [x0, #0x1b8]                           S:'GDPR consent request timed out after {0} seconds. Continuing.'
02c8b324: bl      #0x2b70db0                                 fn_2b70db0
02c8b328: mov     w8, #1                                     
02c8b32c: strb    w8, [x20, #0x97d]                          
02c8b330: ldr     w8, [x19, #0x10]                           .<>1__state
02c8b334: ldr     x22, [x19, #0x20]                          .<>4__this
02c8b338: cmp     w8, #1                                     
02c8b33c: b.eq    #0x2c8b404                                 
02c8b340: cbnz    w8, #0x2c8b4e8                             
02c8b344: adrp    x8, #0x6265000                             
02c8b348: mov     w9, #-1                                    
02c8b34c: ldr     x8, [x8, #0x1b0]                           T:AdsManager/<>c__DisplayClass18_0
02c8b350: str     w9, [x19, #0x10]                           .<>1__state
02c8b354: ldr     x0, [x8]                                   M:AdsManager::<OnApplicationPause>b__26_0
02c8b358: bl      #0x2b7104c                                 fn_2b7104c
02c8b35c: mov     x1, xzr                                    
02c8b360: mov     x21, x0                                    
02c8b364: bl      #0x4e53e9c                                 System.Object::.ctor
02c8b368: mov     x20, x19                                   
02c8b36c: mov     x1, x21                                    
02c8b370: str     x21, [x20, #0x28]!                         .<>8__1
02c8b374: mov     x0, x20                                    
02c8b378: bl      #0x2b70d54                                 fn_2b70d54
02c8b37c: ldr     x8, [x20]                                  &2b706c4(=eb01011ff9400808)
02c8b380: cbz     x8, #0x2c8b500                             
02c8b384: mov     x0, xzr                                    
02c8b388: strb    wzr, [x8, #0x10]                           
02c8b38c: bl      #0x5b43494                                 UnityEngine.Time::get_timeScale
02c8b390: str     s0, [x19, #0x38]                           .<previousTimeScale>5__2
02c8b394: cbz     x22, #0x2c8b500                            
02c8b398: adrp    x8, #0x6264000                             
02c8b39c: ldr     x8, [x8, #0xf90]                           T:System.Action
02c8b3a0: ldr     x23, [x22, #0x28]                          
02c8b3a4: ldr     x21, [x20]                                 &2b706c4(=eb01011ff9400808)
02c8b3a8: ldr     x0, [x8]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c8b3ac: bl      #0x2b7104c                                 fn_2b7104c
02c8b3b0: adrp    x8, #0x6265000                             
02c8b3b4: mov     x1, x21                                    
02c8b3b8: mov     x3, xzr                                    
02c8b3bc: ldr     x8, [x8, #0x1a8]                           M:AdsManager/<>c__DisplayClass18_0::<IRequestConsent>b__0
02c8b3c0: mov     x20, x0                                    
02c8b3c4: ldr     x2, [x8]                                   M:AdsManager::<OnApplicationPause>b__26_0
02c8b3c8: bl      #0x4d8ddbc                                 System.Action::.ctor
02c8b3cc: cbz     x23, #0x2c8b500                            
02c8b3d0: ldr     x0, [x23, #0x48]                           
02c8b3d4: cbz     x0, #0x2c8b500                             
02c8b3d8: mov     x1, x20                                    
02c8b3dc: bl      #0x2c90970                                 GoogleMobileAdsConsentController::StartRequest
02c8b3e0: mov     x0, xzr                                    
02c8b3e4: bl      #0x5b3e6bc                                 UnityEngine.Time::get_realtimeSinceStartup
02c8b3e8: fmov    s1, #1.00000000                            
02c8b3ec: ldr     s2, [x22, #0x34]                           
02c8b3f0: fcmp    s2, s1                                     
02c8b3f4: fcsel   s1, s1, s2, mi                             
02c8b3f8: fadd    s0, s0, s1                                 
02c8b3fc: str     s0, [x19, #0x3c]                           .<deadline>5__3
02c8b400: b       #0x2c8b40c                                 
02c8b404: mov     w8, #-1                                    
02c8b408: str     w8, [x19, #0x10]                           .<>1__state
02c8b40c: ldr     x8, [x19, #0x28]                           .<>8__1
02c8b410: cbz     x8, #0x2c8b500                             
02c8b414: ldrb    w9, [x8, #0x10]                            
02c8b418: cbnz    w9, #0x2c8b454                             
02c8b41c: mov     x0, xzr                                    
02c8b420: bl      #0x5b3e6bc                                 UnityEngine.Time::get_realtimeSinceStartup
02c8b424: ldr     s1, [x19, #0x3c]                           .<deadline>5__3
02c8b428: fcmp    s0, s1                                     
02c8b42c: b.pl    #0x2c8b44c                                 
02c8b430: str     xzr, [x19, #0x18]!                         .<>2__current
02c8b434: mov     x0, x19                                    
02c8b438: mov     x1, xzr                                    
02c8b43c: bl      #0x2b70d54                                 fn_2b70d54
02c8b440: mov     w0, #1                                     
02c8b444: stur    w0, [x19, #-8]                             
02c8b448: b       #0x2c8b4ec                                 
02c8b44c: ldr     x8, [x19, #0x28]                           .<>8__1
02c8b450: cbz     x8, #0x2c8b500                             
02c8b454: ldrb    w8, [x8, #0x10]                            
02c8b458: cbnz    w8, #0x2c8b4d0                             
02c8b45c: cbz     x22, #0x2c8b500                            
02c8b460: adrp    x8, #0x6263000                             
02c8b464: add     x1, sp, #0xc                               
02c8b468: ldr     x8, [x8, #0x970]                           &6645c70(=0)
02c8b46c: ldr     s0, [x22, #0x34]                           
02c8b470: ldr     x0, [x8, #0x78]                            &2c498b4(=d65f03c0d503245f)
02c8b474: str     s0, [sp, #0xc]                             
02c8b478: bl      #0x2b70f38                                 fn_2b70f38
02c8b47c: adrp    x8, #0x6265000                             
02c8b480: mov     x1, x0                                     
02c8b484: mov     x2, xzr                                    
02c8b488: ldr     x8, [x8, #0x1b8]                           S:'GDPR consent request timed out after {0} seconds. Continuing.'
02c8b48c: ldr     x8, [x8]                                   M:AdsManager::<OnApplicationPause>b__26_0
02c8b490: mov     x0, x8                                     
02c8b494: bl      #0x4c9d0ec                                 System.String::Format
02c8b498: adrp    x8, #0x6263000                             
02c8b49c: mov     x20, x0                                    
02c8b4a0: ldr     x8, [x8, #0x928]                           T:UnityEngine.Debug
02c8b4a4: ldr     x8, [x8]                                   &2c5bbd4(=a9bd7bfdd503233f)
02c8b4a8: ldr     w9, [x8, #0xe4]                            [62630e4]=0 f=0,0
02c8b4ac: cbnz    w9, #0x2c8b4b8                             
02c8b4b0: mov     x0, x8                                     
02c8b4b4: bl      #0x2b70f30                                 fn_2b70f30
02c8b4b8: mov     x0, x20                                    
02c8b4bc: mov     x1, xzr                                    
02c8b4c0: bl      #0x5af2c94                                 UnityEngine.Debug::LogWarning
02c8b4c4: ldr     s0, [x19, #0x38]                           .<previousTimeScale>5__2
02c8b4c8: mov     x0, xzr                                    
02c8b4cc: bl      #0x5b434bc                                 UnityEngine.Time::set_timeScale
02c8b4d0: ldr     x8, [x19, #0x30]                           .onComplete
02c8b4d4: cbz     x8, #0x2c8b4e8                             
02c8b4d8: ldr     x9, [x8, #0x18]                            &2c5d934(=d65f03c0d503245f)
02c8b4dc: ldr     x0, [x8, #0x40]                            [6263040]=0 f=0,0
02c8b4e0: ldr     x1, [x8, #0x28]                            [6263028]=0 f=0,0
02c8b4e4: blr     x9                                         
02c8b4e8: mov     w0, wzr                                    
02c8b4ec: ldp     x20, x19, [sp, #0x30]                      
02c8b4f0: ldp     x22, x21, [sp, #0x20]                      
02c8b4f4: ldp     x30, x23, [sp, #0x10]                      
02c8b4f8: add     sp, sp, #0x40                              
02c8b4fc: ret                                                
02c8b500: bl      #0x2b7105c                                 fn_2b7105c
## System.Collections.Generic.IEnumerator<System.Object>.get_Current() -> object
---- AdsManager/<IRequestConsent>d__18::System.Collections.Generic.IEnumerator<System.Object>.get_Current 0x2c8b518
02c8b518: ldr     x0, [x0, #0x18]                            .<>2__current
02c8b51c: ret                                                
## System.Collections.IEnumerator.Reset() -> void
---- AdsManager/<IRequestConsent>d__18::System.Collections.IEnumerator.Reset 0x2c8b520
02c8b520: stp     x30, x19, [sp, #-0x10]!                    
02c8b524: adrp    x0, #0x6264000                             
02c8b528: ldr     x0, [x0, #0xf60]                           T:System.NotSupportedException
02c8b52c: bl      #0x2b70dc4                                 fn_2b70dc4
02c8b530: bl      #0x2b7104c                                 fn_2b7104c
02c8b534: mov     x1, xzr                                    
02c8b538: mov     x19, x0                                    
02c8b53c: bl      #0x4e14238                                 System.NotSupportedException::.ctor
02c8b540: adrp    x0, #0x6265000                             
02c8b544: ldr     x0, [x0, #0x1c0]                           M:AdsManager/<IRequestConsent>d__18::System.Collections.IEnumerator.Reset
02c8b548: bl      #0x2b70dc4                                 fn_2b70dc4
02c8b54c: mov     x1, x0                                     
02c8b550: mov     x0, x19                                    
02c8b554: bl      #0x2b70f20                                 fn_2b70f20
## System.Collections.IEnumerator.get_Current() -> object
---- AdsManager/<IRequestConsent>d__18::System.Collections.IEnumerator.get_Current 0x2c8b558
02c8b558: ldr     x0, [x0, #0x18]                            .<>2__current
02c8b55c: ret                                                
#### CLASS AdsManager/<ISetAOAInterval>d__33 parent= object
#   field <>1__state                     int                                                off=0x10 attr=1 
#   field <>2__current                   object                                             off=0x18 attr=1 
#   field <>4__this                      AdsManager                                         off=0x20 attr=6 
#   field time                           float                                              off=0x28 attr=6 
## .ctor(int <>1__state) -> void
---- AdsManager/<ISetAOAInterval>d__33::.ctor 0x2c894b4
02c894b4: str     x30, [sp, #-0x20]!                         
02c894b8: stp     x20, x19, [sp, #0x10]                      
02c894bc: mov     w19, w1                                    
02c894c0: mov     x1, xzr                                    
02c894c4: mov     x20, x0                                    
02c894c8: bl      #0x4e53e9c                                 System.Object::.ctor
02c894cc: str     w19, [x20, #0x10]                          .<>1__state
02c894d0: ldp     x20, x19, [sp, #0x10]                      
02c894d4: ldr     x30, [sp], #0x20                           
02c894d8: ret                                                
## System.IDisposable.Dispose() -> void
---- AdsManager/<ISetAOAInterval>d__33::System.IDisposable.Dispose 0x2c8b560
02c8b560: ret                                                
## MoveNext() -> bool
---- AdsManager/<ISetAOAInterval>d__33::MoveNext 0x2c8b564
02c8b564: str     d8, [sp, #-0x30]!                          
02c8b568: stp     x30, x21, [sp, #0x10]                      
02c8b56c: stp     x20, x19, [sp, #0x20]                      
02c8b570: adrp    x20, #0x662f000                            
02c8b574: mov     x19, x0                                    
02c8b578: ldrb    w8, [x20, #0x97e]                          
02c8b57c: tbnz    w8, #0, #0x2c8b594                         
02c8b580: adrp    x0, #0x6264000                             
02c8b584: ldr     x0, [x0, #0xf58]                           T:UnityEngine.WaitForSeconds
02c8b588: bl      #0x2b70db0                                 fn_2b70db0
02c8b58c: mov     w8, #1                                     
02c8b590: strb    w8, [x20, #0x97e]                          
02c8b594: ldr     w21, [x19, #0x10]                          .<>1__state
02c8b598: ldr     x8, [x19, #0x20]                           .<>4__this
02c8b59c: cbz     w21, #0x2c8b5c0                            
02c8b5a0: cmp     w21, #1                                    
02c8b5a4: b.ne    #0x2c8b60c                                 
02c8b5a8: mov     w9, #-1                                    
02c8b5ac: str     w9, [x19, #0x10]                           .<>1__state
02c8b5b0: cbz     x8, #0x2c8b624                             
02c8b5b4: mov     w9, #1                                     
02c8b5b8: strb    w9, [x8, #0x49]                            
02c8b5bc: b       #0x2c8b60c                                 
02c8b5c0: mov     w9, #-1                                    
02c8b5c4: str     w9, [x19, #0x10]                           .<>1__state
02c8b5c8: cbz     x8, #0x2c8b624                             
02c8b5cc: adrp    x9, #0x6264000                             
02c8b5d0: ldr     x9, [x9, #0xf58]                           T:UnityEngine.WaitForSeconds
02c8b5d4: ldr     s8, [x19, #0x28]                           .time
02c8b5d8: strb    wzr, [x8, #0x49]                           
02c8b5dc: ldr     x0, [x9]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c8b5e0: bl      #0x2b7104c                                 fn_2b7104c
02c8b5e4: fmov    s0, s8                                     
02c8b5e8: mov     x1, xzr                                    
02c8b5ec: mov     x20, x0                                    
02c8b5f0: bl      #0x5b3e5e8                                 UnityEngine.WaitForSeconds::.ctor
02c8b5f4: str     x20, [x19, #0x18]!                         .<>2__current
02c8b5f8: mov     x0, x19                                    
02c8b5fc: mov     x1, x20                                    
02c8b600: bl      #0x2b70d54                                 fn_2b70d54
02c8b604: mov     w8, #1                                     
02c8b608: stur    w8, [x19, #-8]                             
02c8b60c: cmp     w21, #0                                    
02c8b610: ldp     x20, x19, [sp, #0x20]                      
02c8b614: ldp     x30, x21, [sp, #0x10]                      
02c8b618: cset    w0, eq                                     
02c8b61c: ldr     d8, [sp], #0x30                            
02c8b620: ret                                                
02c8b624: bl      #0x2b7105c                                 fn_2b7105c
## System.Collections.Generic.IEnumerator<System.Object>.get_Current() -> object
---- AdsManager/<ISetAOAInterval>d__33::System.Collections.Generic.IEnumerator<System.Object>.get_Current 0x2c8b628
02c8b628: ldr     x0, [x0, #0x18]                            .<>2__current
02c8b62c: ret                                                
## System.Collections.IEnumerator.Reset() -> void
---- AdsManager/<ISetAOAInterval>d__33::System.Collections.IEnumerator.Reset 0x2c8b630
02c8b630: stp     x30, x19, [sp, #-0x10]!                    
02c8b634: adrp    x0, #0x6264000                             
02c8b638: ldr     x0, [x0, #0xf60]                           T:System.NotSupportedException
02c8b63c: bl      #0x2b70dc4                                 fn_2b70dc4
02c8b640: bl      #0x2b7104c                                 fn_2b7104c
02c8b644: mov     x1, xzr                                    
02c8b648: mov     x19, x0                                    
02c8b64c: bl      #0x4e14238                                 System.NotSupportedException::.ctor
02c8b650: adrp    x0, #0x6265000                             
02c8b654: ldr     x0, [x0, #0x1c8]                           M:AdsManager/<ISetAOAInterval>d__33::System.Collections.IEnumerator.Reset
02c8b658: bl      #0x2b70dc4                                 fn_2b70dc4
02c8b65c: mov     x1, x0                                     
02c8b660: mov     x0, x19                                    
02c8b664: bl      #0x2b70f20                                 fn_2b70f20
## System.Collections.IEnumerator.get_Current() -> object
---- AdsManager/<ISetAOAInterval>d__33::System.Collections.IEnumerator.get_Current 0x2c8b668
02c8b668: ldr     x0, [x0, #0x18]                            .<>2__current
02c8b66c: ret                                                
#### CLASS AdsManager/<ISetInterCapping>d__45 parent= object
#   field <>1__state                     int                                                off=0x10 attr=1 
#   field <>2__current                   object                                             off=0x18 attr=1 
#   field <>4__this                      AdsManager                                         off=0x20 attr=6 
#   field time                           float                                              off=0x28 attr=6 
## .ctor(int <>1__state) -> void
---- AdsManager/<ISetInterCapping>d__45::.ctor 0x2c8a298
02c8a298: str     x30, [sp, #-0x20]!                         
02c8a29c: stp     x20, x19, [sp, #0x10]                      
02c8a2a0: mov     w19, w1                                    
02c8a2a4: mov     x1, xzr                                    
02c8a2a8: mov     x20, x0                                    
02c8a2ac: bl      #0x4e53e9c                                 System.Object::.ctor
02c8a2b0: str     w19, [x20, #0x10]                          .<>1__state
02c8a2b4: ldp     x20, x19, [sp, #0x10]                      
02c8a2b8: ldr     x30, [sp], #0x20                           
02c8a2bc: ret                                                
## System.IDisposable.Dispose() -> void
---- AdsManager/<ISetInterCapping>d__45::System.IDisposable.Dispose 0x2c8b670
02c8b670: ret                                                
## MoveNext() -> bool
---- AdsManager/<ISetInterCapping>d__45::MoveNext 0x2c8b674
02c8b674: str     d8, [sp, #-0x30]!                          
02c8b678: stp     x30, x21, [sp, #0x10]                      
02c8b67c: stp     x20, x19, [sp, #0x20]                      
02c8b680: adrp    x20, #0x662f000                            
02c8b684: mov     x19, x0                                    
02c8b688: ldrb    w8, [x20, #0x97f]                          
02c8b68c: tbnz    w8, #0, #0x2c8b6a4                         
02c8b690: adrp    x0, #0x6264000                             
02c8b694: ldr     x0, [x0, #0xf58]                           T:UnityEngine.WaitForSeconds
02c8b698: bl      #0x2b70db0                                 fn_2b70db0
02c8b69c: mov     w8, #1                                     
02c8b6a0: strb    w8, [x20, #0x97f]                          
02c8b6a4: ldr     w21, [x19, #0x10]                          .<>1__state
02c8b6a8: ldr     x8, [x19, #0x20]                           .<>4__this
02c8b6ac: cbz     w21, #0x2c8b6d0                            
02c8b6b0: cmp     w21, #1                                    
02c8b6b4: b.ne    #0x2c8b71c                                 
02c8b6b8: mov     w9, #-1                                    
02c8b6bc: str     w9, [x19, #0x10]                           .<>1__state
02c8b6c0: cbz     x8, #0x2c8b734                             
02c8b6c4: mov     w9, #1                                     
02c8b6c8: strb    w9, [x8, #0x38]                            
02c8b6cc: b       #0x2c8b71c                                 
02c8b6d0: mov     w9, #-1                                    
02c8b6d4: str     w9, [x19, #0x10]                           .<>1__state
02c8b6d8: cbz     x8, #0x2c8b734                             
02c8b6dc: adrp    x9, #0x6264000                             
02c8b6e0: ldr     x9, [x9, #0xf58]                           T:UnityEngine.WaitForSeconds
02c8b6e4: ldr     s8, [x19, #0x28]                           .time
02c8b6e8: strb    wzr, [x8, #0x38]                           
02c8b6ec: ldr     x0, [x9]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c8b6f0: bl      #0x2b7104c                                 fn_2b7104c
02c8b6f4: fmov    s0, s8                                     
02c8b6f8: mov     x1, xzr                                    
02c8b6fc: mov     x20, x0                                    
02c8b700: bl      #0x5b3e5e8                                 UnityEngine.WaitForSeconds::.ctor
02c8b704: str     x20, [x19, #0x18]!                         .<>2__current
02c8b708: mov     x0, x19                                    
02c8b70c: mov     x1, x20                                    
02c8b710: bl      #0x2b70d54                                 fn_2b70d54
02c8b714: mov     w8, #1                                     
02c8b718: stur    w8, [x19, #-8]                             
02c8b71c: cmp     w21, #0                                    
02c8b720: ldp     x20, x19, [sp, #0x20]                      
02c8b724: ldp     x30, x21, [sp, #0x10]                      
02c8b728: cset    w0, eq                                     
02c8b72c: ldr     d8, [sp], #0x30                            
02c8b730: ret                                                
02c8b734: bl      #0x2b7105c                                 fn_2b7105c
## System.Collections.Generic.IEnumerator<System.Object>.get_Current() -> object
---- AdsManager/<ISetInterCapping>d__45::System.Collections.Generic.IEnumerator<System.Object>.get_Current 0x2c8b738
02c8b738: ldr     x0, [x0, #0x18]                            .<>2__current
02c8b73c: ret                                                
## System.Collections.IEnumerator.Reset() -> void
---- AdsManager/<ISetInterCapping>d__45::System.Collections.IEnumerator.Reset 0x2c8b740
02c8b740: stp     x30, x19, [sp, #-0x10]!                    
02c8b744: adrp    x0, #0x6264000                             
02c8b748: ldr     x0, [x0, #0xf60]                           T:System.NotSupportedException
02c8b74c: bl      #0x2b70dc4                                 fn_2b70dc4
02c8b750: bl      #0x2b7104c                                 fn_2b7104c
02c8b754: mov     x1, xzr                                    
02c8b758: mov     x19, x0                                    
02c8b75c: bl      #0x4e14238                                 System.NotSupportedException::.ctor
02c8b760: adrp    x0, #0x6265000                             
02c8b764: ldr     x0, [x0, #0x1d0]                           M:AdsManager/<ISetInterCapping>d__45::System.Collections.IEnumerator.Reset
02c8b768: bl      #0x2b70dc4                                 fn_2b70dc4
02c8b76c: mov     x1, x0                                     
02c8b770: mov     x0, x19                                    
02c8b774: bl      #0x2b70f20                                 fn_2b70f20
## System.Collections.IEnumerator.get_Current() -> object
---- AdsManager/<ISetInterCapping>d__45::System.Collections.IEnumerator.get_Current 0x2c8b778
02c8b778: ldr     x0, [x0, #0x18]                            .<>2__current
02c8b77c: ret                                                
#### CLASS AdsManager parent= WejoyService.Singleton`1<AdsManager>
#   field _applonvinManager              ApplovinManager                                    off=0x20 attr=1 SerializeField
#   field _googleMobileAdsManager        GoogleMobileAdsManager                             off=0x28 attr=1 SerializeField
#   field _testMode                      bool                                               off=0x30 attr=1 SerializeField
#   field _testAd                        bool                                               off=0x31 attr=1 SerializeField
#   field _consentTimeout                float                                              off=0x34 attr=1 SerializeField,MinAttribute
#   field _isDoneCapping                 bool                                               off=0x38 attr=1 
#   field cappingCoroutine               UnityEngine.Coroutine                              off=0x40 attr=1 
#   field _isRemoveAd                    bool                                               off=0x48 attr=1 
#   field RemoveAdsPrefsKey              string                                             off=0x0 attr=8051 
#   field _isDoneAOAInterval             bool                                               off=0x49 attr=1 
#   field _canShowResumeAd               bool                                               off=0x4a attr=1 
#   field _isShowingInter                bool                                               off=0x4b attr=1 
#   field _wasPausedDuringInter          bool                                               off=0x4c attr=1 
#   field _coroutineHideAdResume         UnityEngine.Coroutine                              off=0x50 attr=1 
#   field _interMaxShownCount            int                                                off=0x58 attr=1 
## get_IsTestMode() -> bool
---- AdsManager::get_IsTestMode 0x2c885d4
02c885d4: ldrb    w0, [x0, #0x30]                            ._testMode
02c885d8: ret                                                
## get_IsTestAd() -> bool
---- AdsManager::get_IsTestAd 0x2c885dc
02c885dc: ldrb    w0, [x0, #0x31]                            ._testAd
02c885e0: ret                                                
## get_IsRemoveAd() -> bool
---- AdsManager::get_IsRemoveAd 0x2c885e4
02c885e4: ldrb    w0, [x0, #0x48]                            ._isRemoveAd
02c885e8: ret                                                
## Start() -> void
---- AdsManager::Start 0x2c885ec
02c885ec: stp     x30, x25, [sp, #-0x40]!                    
02c885f0: stp     x24, x23, [sp, #0x10]                      
02c885f4: stp     x22, x21, [sp, #0x20]                      
02c885f8: stp     x20, x19, [sp, #0x30]                      
02c885fc: adrp    x21, #0x662f000                            
02c88600: adrp    x20, #0x6263000                            
02c88604: mov     x19, x0                                    
02c88608: ldrb    w8, [x21, #0x95c]                          
02c8860c: ldr     x20, [x20, #0x928]                         T:UnityEngine.Debug
02c88610: tbnz    w8, #0, #0x2c8867c                         
02c88614: adrp    x0, #0x6264000                             
02c88618: ldr     x0, [x0, #0xf90]                           T:System.Action
02c8861c: bl      #0x2b70db0                                 fn_2b70db0
02c88620: adrp    x0, #0x6264000                             
02c88624: ldr     x0, [x0, #0xf98]                           M:AdsManager::CheckRemoveAdsPurchase
02c88628: bl      #0x2b70db0                                 fn_2b70db0
02c8862c: adrp    x0, #0x6264000                             
02c88630: ldr     x0, [x0, #0xa70]                           T:UnityEngine.Application
02c88634: bl      #0x2b70db0                                 fn_2b70db0
02c88638: adrp    x0, #0x6263000                             
02c8863c: ldr     x0, [x0, #0x928]                           T:UnityEngine.Debug
02c88640: bl      #0x2b70db0                                 fn_2b70db0
02c88644: adrp    x0, #0x6264000                             
02c88648: ldr     x0, [x0, #0xfa0]                           T:UnityEngine.ILogger
02c8864c: bl      #0x2b70db0                                 fn_2b70db0
02c88650: adrp    x0, #0x6263000                             
02c88654: ldr     x0, [x0, #0x918]                           T:UnityEngine.Object
02c88658: bl      #0x2b70db0                                 fn_2b70db0
02c8865c: adrp    x0, #0x6264000                             
02c88660: ldr     x0, [x0, #0xfa8]                           MS:WejoyService.Singleton`1::get_Instance
02c88664: bl      #0x2b70db0                                 fn_2b70db0
02c88668: adrp    x0, #0x6264000                             
02c8866c: ldr     x0, [x0, #0xfb0]                           S:'_remove_ads'
02c88670: bl      #0x2b70db0                                 fn_2b70db0
02c88674: mov     w8, #1                                     
02c88678: strb    w8, [x21, #0x95c]                          
02c8867c: ldr     x0, [x20]                                  &2c5bbd4(=a9bd7bfdd503233f)
02c88680: ldr     w8, [x0, #0xe4]                            [62640e4]=0 f=0,0
02c88684: cbnz    w8, #0x2c8868c                             
02c88688: bl      #0x2b70f30                                 fn_2b70f30
02c8868c: adrp    x21, #0x662f000                            
02c88690: ldrb    w8, [x21, #0xa77]                          
02c88694: cbnz    w8, #0x2c886ac                             
02c88698: adrp    x0, #0x6263000                             
02c8869c: ldr     x0, [x0, #0x928]                           T:UnityEngine.Debug
02c886a0: bl      #0x2b70db0                                 fn_2b70db0
02c886a4: mov     w8, #1                                     
02c886a8: strb    w8, [x21, #0xa77]                          
02c886ac: ldr     x0, [x20]                                  &2c5bbd4(=a9bd7bfdd503233f)
02c886b0: ldr     w8, [x0, #0xe4]                            [62630e4]=0 f=0,0
02c886b4: cbnz    w8, #0x2c886c0                             
02c886b8: bl      #0x2b70f30                                 fn_2b70f30
02c886bc: ldr     x0, [x20]                                  &2c5bbd4(=a9bd7bfdd503233f)
02c886c0: ldr     x8, [x0, #0xb8]                            &6263108(=0)
02c886c4: ldr     x20, [x8, #8]                              
02c886c8: cbz     x20, #0x2c8885c                            
02c886cc: adrp    x10, #0x6264000                            
02c886d0: ldr     x8, [x20]                                  &2c5bbd4(=a9bd7bfdd503233f)
02c886d4: adrp    x21, #0x6264000                            
02c886d8: ldr     x10, [x10, #0xfa0]                         T:UnityEngine.ILogger
02c886dc: ldr     x21, [x21, #0xa70]                         T:UnityEngine.Application
02c886e0: ldrb    w24, [x19, #0x30]                          ._testMode
02c886e4: ldrh    w9, [x8, #0x12e]                           
02c886e8: ldr     x1, [x10]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c886ec: cbz     x9, #0x2c88710                             
02c886f0: ldr     x10, [x8, #0xb0]                           
02c886f4: add     x10, x10, #8                               &6264008
02c886f8: ldur    x11, [x10, #-8]                            
02c886fc: cmp     x11, x1                                    
02c88700: b.eq    #0x2c88720                                 
02c88704: subs    x9, x9, #1                                 
02c88708: add     x10, x10, #0x10                            &6264010
02c8870c: b.ne    #0x2c886f8                                 
02c88710: mov     x0, x20                                    
02c88714: mov     w2, #2                                     
02c88718: bl      #0x2baa05c                                 fn_2baa05c
02c8871c: b       #0x2c88730                                 
02c88720: ldr     w9, [x10]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c88724: add     w9, w9, #2                                 
02c88728: add     x8, x8, w9, sxtw #4                        
02c8872c: add     x0, x8, #0x138                             
02c88730: adrp    x25, #0x6264000                            
02c88734: adrp    x22, #0x6264000                            
02c88738: adrp    x23, #0x6263000                            
02c8873c: ldr     x25, [x25, #0xfb0]                         S:'_remove_ads'
02c88740: ldr     x22, [x22, #0xfa8]                         MS:WejoyService.Singleton`1::get_Instance
02c88744: ldr     x23, [x23, #0x918]                         T:UnityEngine.Object
02c88748: ldp     x8, x2, [x0]                               
02c8874c: cmp     w24, #0                                    
02c88750: cset    w1, ne                                     
02c88754: mov     x0, x20                                    
02c88758: blr     x8                                         
02c8875c: ldr     x0, [x21]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c88760: ldr     w8, [x0, #0xe4]                            [62630e4]=0 f=0,0
02c88764: cbnz    w8, #0x2c8876c                             
02c88768: bl      #0x2b70f30                                 fn_2b70f30
02c8876c: mov     x0, xzr                                    
02c88770: bl      #0x5aeac78                                 UnityEngine.Application::get_identifier
02c88774: ldr     x1, [x25]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c88778: mov     x2, xzr                                    
02c8877c: bl      #0x4c9c514                                 System.String::Concat
02c88780: mov     w1, wzr                                    
02c88784: mov     x2, xzr                                    
02c88788: bl      #0x5b2d1dc                                 UnityEngine.PlayerPrefs::GetInt
02c8878c: ldr     x8, [x22]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c88790: cmp     w0, #1                                     
02c88794: cset    w9, eq                                     
02c88798: mov     x0, x8                                     
02c8879c: strb    w9, [x19, #0x48]                           ._isRemoveAd
02c887a0: bl      #0x3be7218                                 fn_3be7218
02c887a4: ldr     x8, [x23]                                  &2c5bbd4(=a9bd7bfdd503233f)
02c887a8: mov     x20, x0                                    
02c887ac: ldr     w9, [x8, #0xe4]                            
02c887b0: cbnz    w9, #0x2c887bc                             
02c887b4: mov     x0, x8                                     
02c887b8: bl      #0x2b70f30                                 fn_2b70f30
02c887bc: mov     x0, x20                                    
02c887c0: mov     x1, xzr                                    
02c887c4: mov     x2, xzr                                    
02c887c8: bl      #0x5b3666c                                 UnityEngine.Object::op_Inequality
02c887cc: tbz     w0, #0, #0x2c8883c                         
02c887d0: ldr     x0, [x22]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c887d4: bl      #0x3be7218                                 fn_3be7218
02c887d8: adrp    x8, #0x6264000                             
02c887dc: mov     x20, x0                                    
02c887e0: ldr     x8, [x8, #0xf90]                           T:System.Action
02c887e4: ldr     x8, [x8]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c887e8: mov     x0, x8                                     
02c887ec: bl      #0x2b7104c                                 fn_2b7104c
02c887f0: adrp    x8, #0x6264000                             
02c887f4: mov     x1, x19                                    
02c887f8: mov     x3, xzr                                    
02c887fc: ldr     x8, [x8, #0xf98]                           M:AdsManager::CheckRemoveAdsPurchase
02c88800: mov     x21, x0                                    
02c88804: ldr     x2, [x8]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c88808: bl      #0x4d8ddbc                                 System.Action::.ctor
02c8880c: cbz     x20, #0x2c8885c                            
02c88810: mov     x0, x20                                    
02c88814: mov     x1, x21                                    
02c88818: mov     x2, xzr                                    
02c8881c: bl      #0x2ca49c0                                 IAPManager::add_OnIAPReady
02c88820: ldr     x0, [x22]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c88824: bl      #0x3be7218                                 fn_3be7218
02c88828: cbz     x0, #0x2c8885c                             
02c8882c: ldrb    w8, [x0, #0x30]                            ._testMode
02c88830: cbz     w8, #0x2c8883c                             
02c88834: mov     x0, x19                                    
02c88838: bl      #0x2c88860                                 AdsManager::CheckRemoveAdsPurchase
02c8883c: mov     x0, x19                                    
02c88840: bl      #0x2c888ec                                 AdsManager::LoadAd
02c88844: mov     x0, x19                                    
02c88848: ldp     x20, x19, [sp, #0x30]                      
02c8884c: ldp     x22, x21, [sp, #0x20]                      
02c88850: ldp     x24, x23, [sp, #0x10]                      
02c88854: ldp     x30, x25, [sp], #0x40                      
02c88858: b       #0x2c88954                                 AdsManager::ResetCapping
02c8885c: bl      #0x2b7105c                                 fn_2b7105c
## LoadAd() -> void
---- AdsManager::LoadAd 0x2c888ec
02c888ec: str     x30, [sp, #-0x20]!                         
02c888f0: stp     x20, x19, [sp, #0x10]                      
02c888f4: adrp    x20, #0x662f000                            
02c888f8: mov     x19, x0                                    
02c888fc: ldrb    w8, [x20, #0x95d]                          
02c88900: tbnz    w8, #0, #0x2c88918                         
02c88904: adrp    x0, #0x6264000                             
02c88908: ldr     x0, [x0, #0xfb8]                           S:'init_done'
02c8890c: bl      #0x2b70db0                                 fn_2b70db0
02c88910: mov     w8, #1                                     
02c88914: strb    w8, [x20, #0x95d]                          
02c88918: ldr     x0, [x19, #0x20]                           ._applonvinManager
02c8891c: cbz     x0, #0x2c88950                             
02c88920: bl      #0x2c8c990                                 ApplovinManager::Initialized
02c88924: ldr     x0, [x19, #0x28]                           ._googleMobileAdsManager
02c88928: cbz     x0, #0x2c88950                             
02c8892c: adrp    x19, #0x6264000                            
02c88930: ldr     x19, [x19, #0xfb8]                         S:'init_done'
02c88934: bl      #0x2c88a2c                                 GoogleMobileAdsManager::RequestAd
02c88938: ldr     x0, [x19]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c8893c: ldp     x20, x19, [sp, #0x10]                      
02c88940: mov     x1, xzr                                    
02c88944: mov     x2, xzr                                    
02c88948: ldr     x30, [sp], #0x20                           
02c8894c: b       #0x2d77fe8                                 WejoyService.Tracking.TrackingManager::LogEvent
02c88950: bl      #0x2b7105c                                 fn_2b7105c
## RequestConsent(System.Action onComplete) -> void
---- AdsManager::RequestConsent 0x2c88b7c
02c88b7c: stp     x30, x19, [sp, #-0x10]!                    
02c88b80: mov     x19, x0                                    
02c88b84: bl      #0x2c88b9c                                 AdsManager::IRequestConsent
02c88b88: mov     x1, x0                                     
02c88b8c: mov     x0, x19                                    
02c88b90: mov     x2, xzr                                    
02c88b94: ldp     x30, x19, [sp], #0x10                      
02c88b98: b       #0x5b389f0                                 UnityEngine.MonoBehaviour::StartCoroutine
## IRequestConsent(System.Action onComplete) -> System.Collections.IEnumerator
---- AdsManager::IRequestConsent 0x2c88b9c
02c88b9c: str     x30, [sp, #-0x30]!                         
02c88ba0: stp     x22, x21, [sp, #0x10]                      
02c88ba4: stp     x20, x19, [sp, #0x20]                      
02c88ba8: adrp    x21, #0x662f000                            
02c88bac: adrp    x22, #0x6264000                            
02c88bb0: mov     x19, x1                                    
02c88bb4: ldrb    w8, [x21, #0x95e]                          
02c88bb8: ldr     x22, [x22, #0xfe8]                         T:AdsManager/<IRequestConsent>d__18
02c88bbc: mov     x20, x0                                    
02c88bc0: tbnz    w8, #0, #0x2c88bd8                         
02c88bc4: adrp    x0, #0x6264000                             
02c88bc8: ldr     x0, [x0, #0xfe8]                           T:AdsManager/<IRequestConsent>d__18
02c88bcc: bl      #0x2b70db0                                 fn_2b70db0
02c88bd0: mov     w8, #1                                     
02c88bd4: strb    w8, [x21, #0x95e]                          
02c88bd8: ldr     x0, [x22]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c88bdc: bl      #0x2b7104c                                 fn_2b7104c
02c88be0: mov     x1, xzr                                    
02c88be4: mov     x21, x0                                    
02c88be8: bl      #0x4e53e9c                                 System.Object::.ctor
02c88bec: mov     x0, x21                                    
02c88bf0: mov     x1, x20                                    
02c88bf4: str     wzr, [x21, #0x10]                          
02c88bf8: str     x20, [x0, #0x20]!                          ._applonvinManager
02c88bfc: bl      #0x2b70d54                                 fn_2b70d54
02c88c00: mov     x0, x21                                    
02c88c04: mov     x1, x19                                    
02c88c08: str     x19, [x0, #0x30]!                          ._testMode
02c88c0c: bl      #0x2b70d54                                 fn_2b70d54
02c88c10: mov     x0, x21                                    
02c88c14: ldp     x20, x19, [sp, #0x20]                      
02c88c18: ldp     x22, x21, [sp, #0x10]                      
02c88c1c: ldr     x30, [sp], #0x30                           
02c88c20: ret                                                
## CheckRemoveAdsPurchase() -> void
---- AdsManager::CheckRemoveAdsPurchase 0x2c88860
02c88860: stp     x30, x21, [sp, #-0x20]!                    
02c88864: stp     x20, x19, [sp, #0x10]                      
02c88868: adrp    x21, #0x662f000                            
02c8886c: adrp    x20, #0x6264000                            
02c88870: mov     x19, x0                                    
02c88874: ldrb    w8, [x21, #0x95f]                          
02c88878: ldr     x20, [x20, #0xfa8]                         MS:WejoyService.Singleton`1::get_Instance
02c8887c: tbnz    w8, #0, #0x2c88894                         
02c88880: adrp    x0, #0x6264000                             
02c88884: ldr     x0, [x0, #0xfa8]                           MS:WejoyService.Singleton`1::get_Instance
02c88888: bl      #0x2b70db0                                 fn_2b70db0
02c8888c: mov     w8, #1                                     
02c88890: strb    w8, [x21, #0x95f]                          
02c88894: ldr     x0, [x20]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c88898: bl      #0x3be7218                                 fn_3be7218
02c8889c: cbz     x0, #0x2c888e8                             
02c888a0: mov     w1, wzr                                    
02c888a4: mov     x2, xzr                                    
02c888a8: bl      #0x2ca7198                                 IAPManager::IsPurchased
02c888ac: ldr     x8, [x20]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c888b0: mov     w20, w0                                    
02c888b4: mov     x0, x8                                     
02c888b8: bl      #0x3be7218                                 fn_3be7218
02c888bc: cbz     x0, #0x2c888e8                             
02c888c0: mov     w1, #1                                     
02c888c4: mov     x2, xzr                                    
02c888c8: bl      #0x2ca7198                                 IAPManager::IsPurchased
02c888cc: mov     w8, w0                                     
02c888d0: mov     x0, x19                                    
02c888d4: orr     w8, w20, w8                                
02c888d8: ldp     x20, x19, [sp, #0x10]                      
02c888dc: and     w1, w8, #1                                 
02c888e0: ldp     x30, x21, [sp], #0x20                      
02c888e4: b       #0x2c88c4c                                 AdsManager::SetRemoveAdsState
02c888e8: bl      #0x2b7105c                                 fn_2b7105c
## SetRemoveAdsState(bool isPurchased) -> void
---- AdsManager::SetRemoveAdsState 0x2c88c4c
02c88c4c: strb    w1, [x0, #0x48]                            ._isRemoveAd
02c88c50: tbz     w1, #0, #0x2c88c6c                         
02c88c54: stp     x30, x19, [sp, #-0x10]!                    
02c88c58: mov     x19, x0                                    
02c88c5c: bl      #0x2c88c70                                 AdsManager::HideBanner
02c88c60: mov     x0, x19                                    
02c88c64: ldp     x30, x19, [sp], #0x10                      
02c88c68: b       #0x2c88cec                                 AdsManager::HideMREC
02c88c6c: ret                                                
## RemoveAds() -> void
---- AdsManager::RemoveAds 0x2c88d70
02c88d70: stp     x30, x21, [sp, #-0x20]!                    
02c88d74: stp     x20, x19, [sp, #0x10]                      
02c88d78: adrp    x21, #0x662f000                            
02c88d7c: adrp    x20, #0x6264000                            
02c88d80: mov     x19, x0                                    
02c88d84: ldrb    w8, [x21, #0x960]                          
02c88d88: ldr     x20, [x20, #0xa70]                         T:UnityEngine.Application
02c88d8c: tbnz    w8, #0, #0x2c88db0                         
02c88d90: adrp    x0, #0x6264000                             
02c88d94: ldr     x0, [x0, #0xa70]                           T:UnityEngine.Application
02c88d98: bl      #0x2b70db0                                 fn_2b70db0
02c88d9c: adrp    x0, #0x6264000                             
02c88da0: ldr     x0, [x0, #0xfb0]                           S:'_remove_ads'
02c88da4: bl      #0x2b70db0                                 fn_2b70db0
02c88da8: mov     w8, #1                                     
02c88dac: strb    w8, [x21, #0x960]                          
02c88db0: ldr     x0, [x20]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c88db4: adrp    x20, #0x6264000                            
02c88db8: ldr     w8, [x0, #0xe4]                            [62640e4]=0 f=0,0
02c88dbc: ldr     x20, [x20, #0xfb0]                         S:'_remove_ads'
02c88dc0: cbnz    w8, #0x2c88dc8                             
02c88dc4: bl      #0x2b70f30                                 fn_2b70f30
02c88dc8: mov     x0, xzr                                    
02c88dcc: bl      #0x5aeac78                                 UnityEngine.Application::get_identifier
02c88dd0: ldr     x1, [x20]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c88dd4: mov     x2, xzr                                    
02c88dd8: bl      #0x4c9c514                                 System.String::Concat
02c88ddc: mov     w1, #1                                     
02c88de0: mov     x2, xzr                                    
02c88de4: mov     w20, #1                                    
02c88de8: bl      #0x5b2d184                                 UnityEngine.PlayerPrefs::SetInt
02c88dec: mov     x0, xzr                                    
02c88df0: bl      #0x5b2d914                                 UnityEngine.PlayerPrefs::Save
02c88df4: mov     x0, x19                                    
02c88df8: strb    w20, [x19, #0x48]                          ._isRemoveAd
02c88dfc: bl      #0x2c88c70                                 AdsManager::HideBanner
02c88e00: mov     x0, x19                                    
02c88e04: ldp     x20, x19, [sp, #0x10]                      
02c88e08: ldp     x30, x21, [sp], #0x20                      
02c88e0c: b       #0x2c88cec                                 AdsManager::HideMREC
## OnApplicationPause(bool pause) -> void
---- AdsManager::OnApplicationPause 0x2c88e10
02c88e10: stp     x30, x21, [sp, #-0x20]!                    
02c88e14: stp     x20, x19, [sp, #0x10]                      
02c88e18: adrp    x21, #0x662f000                            
02c88e1c: mov     w20, w1                                    
02c88e20: mov     x19, x0                                    
02c88e24: ldrb    w8, [x21, #0x961]                          
02c88e28: tbnz    w8, #0, #0x2c88e70                         
02c88e2c: adrp    x0, #0x6264000                             
02c88e30: ldr     x0, [x0, #0xf90]                           T:System.Action
02c88e34: bl      #0x2b70db0                                 fn_2b70db0
02c88e38: adrp    x0, #0x6265000                             
02c88e3c: ldr     x0, [x0]                                   M:AdsManager::<OnApplicationPause>b__26_0
02c88e40: bl      #0x2b70db0                                 fn_2b70db0
02c88e44: adrp    x0, #0x6265000                             
02c88e48: ldr     x0, [x0, #8]                               M:AdsManager::<OnApplicationPause>b__26_1
02c88e4c: bl      #0x2b70db0                                 fn_2b70db0
02c88e50: adrp    x0, #0x6265000                             
02c88e54: ldr     x0, [x0, #0x10]                            MS:MonoSingleton`1::get_Instance
02c88e58: bl      #0x2b70db0                                 fn_2b70db0
02c88e5c: adrp    x0, #0x6264000                             
02c88e60: ldr     x0, [x0, #0xe8]                            T:DG.Tweening.TweenCallback
02c88e64: bl      #0x2b70db0                                 fn_2b70db0
02c88e68: mov     w8, #1                                     
02c88e6c: strb    w8, [x21, #0x961]                          
02c88e70: tbz     w20, #0, #0x2c88e88                        
02c88e74: ldrb    w8, [x19, #0x4b]                           ._isShowingInter
02c88e78: cbz     w8, #0x2c88e94                             
02c88e7c: mov     w8, #1                                     
02c88e80: strb    w8, [x19, #0x4c]                           ._wasPausedDuringInter
02c88e84: b       #0x2c88e94                                 
02c88e88: ldrb    w8, [x19, #0x4c]                           ._wasPausedDuringInter
02c88e8c: cbz     w8, #0x2c88ea0                             
02c88e90: strb    wzr, [x19, #0x4c]                          ._wasPausedDuringInter
02c88e94: ldp     x20, x19, [sp, #0x10]                      
02c88e98: ldp     x30, x21, [sp], #0x20                      
02c88e9c: ret                                                
02c88ea0: ldrb    w8, [x19, #0x4a]                           ._canShowResumeAd
02c88ea4: cbz     w8, #0x2c88e94                             
02c88ea8: ldrb    w8, [x19, #0x4b]                           ._isShowingInter
02c88eac: cbnz    w8, #0x2c88e94                             
02c88eb0: mov     x0, x19                                    
02c88eb4: bl      #0x2c88c70                                 AdsManager::HideBanner
02c88eb8: mov     x0, x19                                    
02c88ebc: bl      #0x2c88cec                                 AdsManager::HideMREC
02c88ec0: mov     x0, x19                                    
02c88ec4: bl      #0x2c88f70                                 AdsManager::HideCollap
02c88ec8: adrp    x8, #0x6264000                             
02c88ecc: ldr     x8, [x8, #0xe8]                            T:DG.Tweening.TweenCallback
02c88ed0: ldr     x0, [x8]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c88ed4: bl      #0x2b7104c                                 fn_2b7104c
02c88ed8: adrp    x8, #0x6265000                             
02c88edc: mov     x1, x19                                    
02c88ee0: mov     x3, xzr                                    
02c88ee4: ldr     x8, [x8]                                   M:AdsManager::<OnApplicationPause>b__26_0
02c88ee8: mov     x20, x0                                    
02c88eec: ldr     x2, [x8]                                   M:AdsManager::<OnApplicationPause>b__26_0
02c88ef0: bl      #0x2d89dc4                                 DG.Tweening.TweenCallback::.ctor
02c88ef4: fmov    s0, #1.00000000                            
02c88ef8: mov     x0, x20                                    
02c88efc: mov     w1, #1                                     
02c88f00: mov     x2, xzr                                    
02c88f04: bl      #0x2d8f37c                                 DG.Tweening.DOVirtual::DelayedCall
02c88f08: adrp    x8, #0x6265000                             
02c88f0c: ldr     x8, [x8, #0x10]                            MS:MonoSingleton`1::get_Instance
02c88f10: ldr     x0, [x8]                                   M:AdsManager::<OnApplicationPause>b__26_0
02c88f14: bl      #0x3769600                                 fn_3769600
02c88f18: adrp    x8, #0x6264000                             
02c88f1c: mov     x20, x0                                    
02c88f20: ldr     x8, [x8, #0xf90]                           T:System.Action
02c88f24: ldr     x8, [x8]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c88f28: mov     x0, x8                                     
02c88f2c: bl      #0x2b7104c                                 fn_2b7104c
02c88f30: adrp    x8, #0x6265000                             
02c88f34: mov     x1, x19                                    
02c88f38: mov     x3, xzr                                    
02c88f3c: ldr     x8, [x8, #8]                               M:AdsManager::<OnApplicationPause>b__26_1
02c88f40: mov     x21, x0                                    
02c88f44: ldr     x2, [x8]                                   M:AdsManager::<OnApplicationPause>b__26_0
02c88f48: bl      #0x4d8ddbc                                 System.Action::.ctor
02c88f4c: cbz     x20, #0x2c88f6c                            
02c88f50: mov     x0, x20                                    
02c88f54: ldp     x20, x19, [sp, #0x10]                      
02c88f58: fmov    s0, #1.50000000                            
02c88f5c: mov     x1, x21                                    
02c88f60: mov     x2, xzr                                    
02c88f64: ldp     x30, x21, [sp], #0x20                      
02c88f68: b       #0x2ce9f1c                                 SimpleSceneTransition::FlashIn
02c88f6c: bl      #0x2b7105c                                 fn_2b7105c
## StartShowAdResume() -> void
---- AdsManager::StartShowAdResume 0x2c88f88
02c88f88: mov     w8, #1                                     
02c88f8c: strb    w8, [x0, #0x4a]                            ._canShowResumeAd
02c88f90: ret                                                
## HideAdResume() -> void
---- AdsManager::HideAdResume 0x2c88f94
02c88f94: str     x30, [sp, #-0x20]!                         
02c88f98: stp     x20, x19, [sp, #0x10]                      
02c88f9c: mov     x20, x0                                    
02c88fa0: mov     x19, x0                                    
02c88fa4: ldr     x1, [x20, #0x50]!                          ._coroutineHideAdResume
02c88fa8: cbz     x1, #0x2c88fb8                             
02c88fac: mov     x0, x19                                    
02c88fb0: mov     x2, xzr                                    
02c88fb4: bl      #0x5b38c4c                                 UnityEngine.MonoBehaviour::StopCoroutine
02c88fb8: mov     x0, x19                                    
02c88fbc: bl      #0x2c88fe8                                 AdsManager::IEHideAdResume
02c88fc0: mov     x1, x0                                     
02c88fc4: mov     x0, x19                                    
02c88fc8: mov     x2, xzr                                    
02c88fcc: bl      #0x5b389f0                                 UnityEngine.MonoBehaviour::StartCoroutine
02c88fd0: mov     x1, x0                                     
02c88fd4: mov     x0, x20                                    
02c88fd8: str     x1, [x19, #0x50]                           ._coroutineHideAdResume
02c88fdc: ldp     x20, x19, [sp, #0x10]                      
02c88fe0: ldr     x30, [sp], #0x20                           
02c88fe4: b       #0x2b70d54                                 
## IEHideAdResume() -> System.Collections.IEnumerator
---- AdsManager::IEHideAdResume 0x2c88fe8
02c88fe8: stp     x30, x21, [sp, #-0x20]!                    
02c88fec: stp     x20, x19, [sp, #0x10]                      
02c88ff0: adrp    x20, #0x662f000                            
02c88ff4: adrp    x21, #0x6265000                            
02c88ff8: mov     x19, x0                                    
02c88ffc: ldrb    w8, [x20, #0x962]                          
02c89000: ldr     x21, [x21, #0x18]                          T:AdsManager/<IEHideAdResume>d__30
02c89004: tbnz    w8, #0, #0x2c8901c                         
02c89008: adrp    x0, #0x6265000                             
02c8900c: ldr     x0, [x0, #0x18]                            T:AdsManager/<IEHideAdResume>d__30
02c89010: bl      #0x2b70db0                                 fn_2b70db0
02c89014: mov     w8, #1                                     
02c89018: strb    w8, [x20, #0x962]                          
02c8901c: ldr     x0, [x21]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c89020: bl      #0x2b7104c                                 fn_2b7104c
02c89024: mov     x1, xzr                                    
02c89028: mov     x20, x0                                    
02c8902c: bl      #0x4e53e9c                                 System.Object::.ctor
02c89030: mov     x0, x20                                    
02c89034: mov     x1, x19                                    
02c89038: str     wzr, [x20, #0x10]                          
02c8903c: str     x19, [x0, #0x20]!                          ._applonvinManager
02c89040: bl      #0x2b70d54                                 fn_2b70d54
02c89044: mov     x0, x20                                    
02c89048: ldp     x20, x19, [sp, #0x10]                      
02c8904c: ldp     x30, x21, [sp], #0x20                      
02c89050: ret                                                
## ShowAppOpenAd(string placement, System.Action action) -> void
---- AdsManager::ShowAppOpenAd 0x2c8907c
02c8907c: str     x30, [sp, #-0x40]!                         
02c89080: stp     x24, x23, [sp, #0x10]                      
02c89084: stp     x22, x21, [sp, #0x20]                      
02c89088: stp     x20, x19, [sp, #0x30]                      
02c8908c: adrp    x22, #0x662f000                            
02c89090: adrp    x23, #0x6263000                            
02c89094: mov     x19, x2                                    
02c89098: ldrb    w8, [x22, #0x963]                          
02c8909c: ldr     x23, [x23, #0x928]                         T:UnityEngine.Debug
02c890a0: mov     x20, x1                                    
02c890a4: mov     x21, x0                                    
02c890a8: tbnz    w8, #0, #0x2c890d8                         
02c890ac: adrp    x0, #0x6263000                             
02c890b0: ldr     x0, [x0, #0x928]                           T:UnityEngine.Debug
02c890b4: bl      #0x2b70db0                                 fn_2b70db0
02c890b8: adrp    x0, #0x6264000                             
02c890bc: ldr     x0, [x0, #0xfc0]                           T:RemoteConfigManager
02c890c0: bl      #0x2b70db0                                 fn_2b70db0
02c890c4: adrp    x0, #0x6265000                             
02c890c8: ldr     x0, [x0, #0x20]                            S:'dev log AdsManager show app open ad' ._applonvinManager
02c890cc: bl      #0x2b70db0                                 fn_2b70db0
02c890d0: mov     w8, #1                                     
02c890d4: strb    w8, [x22, #0x963]                          
02c890d8: adrp    x24, #0x6265000                            
02c890dc: adrp    x22, #0x6264000                            
02c890e0: mov     x0, x21                                    
02c890e4: ldr     x24, [x24, #0x20]                          S:'dev log AdsManager show app open ad'
02c890e8: ldr     x22, [x22, #0xfc0]                         T:RemoteConfigManager
02c890ec: bl      #0x2c88f94                                 AdsManager::HideAdResume
02c890f0: ldr     x0, [x23]                                  &2c5bbd4(=a9bd7bfdd503233f)
02c890f4: ldr     w8, [x0, #0xe4]                            [62650e4]=0 f=0,0
02c890f8: cbnz    w8, #0x2c89100                             
02c890fc: bl      #0x2b70f30                                 fn_2b70f30
02c89100: ldr     x0, [x24]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c89104: mov     x1, xzr                                    
02c89108: bl      #0x5af21f4                                 UnityEngine.Debug::Log
02c8910c: ldr     x0, [x22]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c89110: ldr     w8, [x0, #0xe4]                            [62650e4]=0 f=0,0
02c89114: cbnz    w8, #0x2c8911c                             
02c89118: bl      #0x2b70f30                                 fn_2b70f30
02c8911c: adrp    x23, #0x662f000                            
02c89120: ldrb    w8, [x23, #0xa78]                          
02c89124: cbnz    w8, #0x2c8913c                             
02c89128: adrp    x0, #0x6264000                             
02c8912c: ldr     x0, [x0, #0xfc0]                           T:RemoteConfigManager
02c89130: bl      #0x2b70db0                                 fn_2b70db0
02c89134: mov     w8, #1                                     
02c89138: strb    w8, [x23, #0xa78]                          
02c8913c: ldr     x0, [x22]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c89140: ldr     w8, [x0, #0xe4]                            [62640e4]=0 f=0,0
02c89144: cbnz    w8, #0x2c89150                             
02c89148: bl      #0x2b70f30                                 fn_2b70f30
02c8914c: ldr     x0, [x22]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c89150: ldr     x8, [x0, #0xb8]                            MS:DG.Tweening.Core.Extensions::SetSpecialStartupMode
02c89154: ldrb    w8, [x8, #3]                               
02c89158: cbz     w8, #0x2c89164                             
02c8915c: ldrb    w8, [x21, #0x30]                           ._testMode
02c89160: cbz     w8, #0x2c8919c                             
02c89164: cbz     x19, #0x2c89188                            
02c89168: ldr     x0, [x19, #0x40]                           .cappingCoroutine
02c8916c: ldr     x1, [x19, #0x28]                           ._googleMobileAdsManager
02c89170: ldr     x2, [x19, #0x18]                           
02c89174: ldp     x20, x19, [sp, #0x30]                      
02c89178: ldp     x22, x21, [sp, #0x20]                      
02c8917c: ldp     x24, x23, [sp, #0x10]                      
02c89180: ldr     x30, [sp], #0x40                           
02c89184: br      x2                                         
02c89188: ldp     x20, x19, [sp, #0x30]                      
02c8918c: ldp     x22, x21, [sp, #0x20]                      
02c89190: ldp     x24, x23, [sp, #0x10]                      
02c89194: ldr     x30, [sp], #0x40                           
02c89198: ret                                                
02c8919c: ldrb    w8, [x21, #0x49]                           ._isDoneAOAInterval
02c891a0: cbz     w8, #0x2c89164                             
02c891a4: ldr     w8, [x0, #0xe4]                            [62640e4]=0 f=0,0
02c891a8: strb    wzr, [x21, #0x49]                          ._isDoneAOAInterval
02c891ac: cbnz    w8, #0x2c891b4                             
02c891b0: bl      #0x2b70f30                                 fn_2b70f30
02c891b4: adrp    x23, #0x662f000                            
02c891b8: ldrb    w8, [x23, #0xa79]                          
02c891bc: cbnz    w8, #0x2c891d4                             
02c891c0: adrp    x0, #0x6264000                             
02c891c4: ldr     x0, [x0, #0xfc0]                           T:RemoteConfigManager
02c891c8: bl      #0x2b70db0                                 fn_2b70db0
02c891cc: mov     w8, #1                                     
02c891d0: strb    w8, [x23, #0xa79]                          
02c891d4: ldr     x0, [x22]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c891d8: ldr     w8, [x0, #0xe4]                            [62640e4]=0 f=0,0
02c891dc: cbnz    w8, #0x2c891e8                             
02c891e0: bl      #0x2b70f30                                 fn_2b70f30
02c891e4: ldr     x0, [x22]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c891e8: ldr     x8, [x0, #0xb8]                            MS:DG.Tweening.Core.Extensions::SetSpecialStartupMode
02c891ec: mov     x0, x21                                    
02c891f0: ldr     s0, [x8, #8]                               
02c891f4: scvtf   s0, s0                                     
02c891f8: bl      #0x2c89234                                 AdsManager::ISetAOAInterval
02c891fc: mov     x1, x0                                     
02c89200: mov     x0, x21                                    
02c89204: mov     x2, xzr                                    
02c89208: bl      #0x5b389f0                                 UnityEngine.MonoBehaviour::StartCoroutine
02c8920c: ldr     x0, [x21, #0x28]                           ._googleMobileAdsManager
02c89210: cbz     x0, #0x2c89230                             
02c89214: mov     x1, x20                                    
02c89218: mov     x2, x19                                    
02c8921c: ldp     x20, x19, [sp, #0x30]                      
02c89220: ldp     x22, x21, [sp, #0x20]                      
02c89224: ldp     x24, x23, [sp, #0x10]                      
02c89228: ldr     x30, [sp], #0x40                           
02c8922c: b       #0x2c892b0                                 GoogleMobileAdsManager::ShowAppOpen
02c89230: bl      #0x2b7105c                                 fn_2b7105c
## ShowAppOpenLoading(string placement, System.Action action) -> void
---- AdsManager::ShowAppOpenLoading 0x2c89314
02c89314: stp     x30, x23, [sp, #-0x30]!                    
02c89318: stp     x22, x21, [sp, #0x10]                      
02c8931c: stp     x20, x19, [sp, #0x20]                      
02c89320: adrp    x21, #0x662f000                            
02c89324: adrp    x23, #0x6265000                            
02c89328: mov     x22, x2                                    
02c8932c: ldrb    w8, [x21, #0x964]                          
02c89330: ldr     x23, [x23, #0x30]                          T:AdsManager/<>c__DisplayClass32_0
02c89334: mov     x19, x1                                    
02c89338: mov     x20, x0                                    
02c8933c: tbnz    w8, #0, #0x2c89378                         
02c89340: adrp    x0, #0x6264000                             
02c89344: ldr     x0, [x0, #0xf90]                           T:System.Action
02c89348: bl      #0x2b70db0                                 fn_2b70db0
02c8934c: adrp    x0, #0x6264000                             
02c89350: ldr     x0, [x0, #0xfc0]                           T:RemoteConfigManager
02c89354: bl      #0x2b70db0                                 fn_2b70db0
02c89358: adrp    x0, #0x6265000                             
02c8935c: ldr     x0, [x0, #0x38]                            M:AdsManager/<>c__DisplayClass32_0::<ShowAppOpenLoading>g__OnComplete|0 ._isDoneCapping
02c89360: bl      #0x2b70db0                                 fn_2b70db0
02c89364: adrp    x0, #0x6265000                             
02c89368: ldr     x0, [x0, #0x30]                            T:AdsManager/<>c__DisplayClass32_0 ._testMode
02c8936c: bl      #0x2b70db0                                 fn_2b70db0
02c89370: mov     w8, #1                                     
02c89374: strb    w8, [x21, #0x964]                          
02c89378: ldr     x0, [x23]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c8937c: bl      #0x2b7104c                                 fn_2b7104c
02c89380: mov     x1, xzr                                    
02c89384: mov     x21, x0                                    
02c89388: bl      #0x4e53e9c                                 System.Object::.ctor
02c8938c: cbz     x21, #0x2c8946c                            
02c89390: adrp    x23, #0x6264000                            
02c89394: mov     x0, x21                                    
02c89398: mov     x1, x22                                    
02c8939c: ldr     x23, [x23, #0xfc0]                         T:RemoteConfigManager
02c893a0: str     x22, [x0, #0x10]!                          
02c893a4: bl      #0x2b70d54                                 fn_2b70d54
02c893a8: mov     x0, x21                                    
02c893ac: mov     x1, x20                                    
02c893b0: str     x20, [x0, #0x18]!                          
02c893b4: bl      #0x2b70d54                                 fn_2b70d54
02c893b8: ldr     x0, [x23]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c893bc: ldr     w8, [x0, #0xe4]                            [62650e4]=0 f=0,0
02c893c0: cbnz    w8, #0x2c893c8                             
02c893c4: bl      #0x2b70f30                                 fn_2b70f30
02c893c8: adrp    x22, #0x662f000                            
02c893cc: ldrb    w8, [x22, #0xa78]                          
02c893d0: cbnz    w8, #0x2c893e8                             
02c893d4: adrp    x0, #0x6264000                             
02c893d8: ldr     x0, [x0, #0xfc0]                           T:RemoteConfigManager
02c893dc: bl      #0x2b70db0                                 fn_2b70db0
02c893e0: mov     w8, #1                                     
02c893e4: strb    w8, [x22, #0xa78]                          
02c893e8: ldr     x0, [x23]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c893ec: ldr     w8, [x0, #0xe4]                            [62640e4]=0 f=0,0
02c893f0: cbnz    w8, #0x2c893fc                             
02c893f4: bl      #0x2b70f30                                 fn_2b70f30
02c893f8: ldr     x0, [x23]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c893fc: ldr     x8, [x0, #0xb8]                            MS:DG.Tweening.Core.Extensions::SetSpecialStartupMode
02c89400: ldrb    w8, [x8, #3]                               
02c89404: cbz     w8, #0x2c89410                             
02c89408: ldrb    w8, [x20, #0x30]                           ._testMode
02c8940c: cbz     w8, #0x2c89424                             
02c89410: mov     x0, x21                                    
02c89414: ldp     x20, x19, [sp, #0x20]                      
02c89418: ldp     x22, x21, [sp, #0x10]                      
02c8941c: ldp     x30, x23, [sp], #0x30                      
02c89420: b       #0x2c89478                                 AdsManager/<>c__DisplayClass32_0::<ShowAppOpenLoading>g__OnComplete|0
02c89424: adrp    x8, #0x6264000                             
02c89428: ldr     x8, [x8, #0xf90]                           T:System.Action
02c8942c: ldr     x0, [x8]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c89430: bl      #0x2b7104c                                 fn_2b7104c
02c89434: adrp    x8, #0x6265000                             
02c89438: mov     x1, x21                                    
02c8943c: mov     x3, xzr                                    
02c89440: ldr     x8, [x8, #0x38]                            M:AdsManager/<>c__DisplayClass32_0::<ShowAppOpenLoading>g__OnComplete|0
02c89444: mov     x22, x0                                    
02c89448: ldr     x2, [x8]                                   M:AdsManager::<OnApplicationPause>b__26_0
02c8944c: bl      #0x4d8ddbc                                 System.Action::.ctor
02c89450: mov     x0, x20                                    
02c89454: mov     x1, x19                                    
02c89458: mov     x2, x22                                    
02c8945c: ldp     x20, x19, [sp, #0x20]                      
02c89460: ldp     x22, x21, [sp, #0x10]                      
02c89464: ldp     x30, x23, [sp], #0x30                      
02c89468: b       #0x2c8907c                                 AdsManager::ShowAppOpenAd
02c8946c: bl      #0x2b7105c                                 fn_2b7105c
## ISetAOAInterval(float time) -> System.Collections.IEnumerator
---- AdsManager::ISetAOAInterval 0x2c89234
02c89234: str     d8, [sp, #-0x30]!                          
02c89238: stp     x30, x21, [sp, #0x10]                      
02c8923c: stp     x20, x19, [sp, #0x20]                      
02c89240: fmov    s8, s0                                     
02c89244: adrp    x20, #0x662f000                            
02c89248: adrp    x21, #0x6265000                            
02c8924c: ldrb    w8, [x20, #0x965]                          
02c89250: ldr     x21, [x21, #0x28]                          T:AdsManager/<ISetAOAInterval>d__33 ._googleMobileAdsManager
02c89254: mov     x19, x0                                    
02c89258: tbnz    w8, #0, #0x2c89270                         
02c8925c: adrp    x0, #0x6265000                             
02c89260: ldr     x0, [x0, #0x28]                            T:AdsManager/<ISetAOAInterval>d__33 ._googleMobileAdsManager
02c89264: bl      #0x2b70db0                                 fn_2b70db0
02c89268: mov     w8, #1                                     
02c8926c: strb    w8, [x20, #0x965]                          
02c89270: ldr     x0, [x21]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c89274: bl      #0x2b7104c                                 fn_2b7104c
02c89278: mov     x1, xzr                                    
02c8927c: mov     x20, x0                                    
02c89280: bl      #0x4e53e9c                                 System.Object::.ctor
02c89284: mov     x0, x20                                    
02c89288: mov     x1, x19                                    
02c8928c: str     wzr, [x20, #0x10]                          
02c89290: str     x19, [x0, #0x20]!                          ._applonvinManager
02c89294: bl      #0x2b70d54                                 fn_2b70d54
02c89298: mov     x0, x20                                    
02c8929c: str     s8, [x20, #0x28]                           ._googleMobileAdsManager
02c892a0: ldp     x20, x19, [sp, #0x20]                      
02c892a4: ldp     x30, x21, [sp, #0x10]                      
02c892a8: ldr     d8, [sp], #0x30                            
02c892ac: ret                                                
## get_CanShowInter() -> bool
---- AdsManager::get_CanShowInter 0x2c894dc
02c894dc: stp     x30, x21, [sp, #-0x20]!                    
02c894e0: stp     x20, x19, [sp, #0x10]                      
02c894e4: adrp    x20, #0x662f000                            
02c894e8: mov     x19, x0                                    
02c894ec: ldrb    w8, [x20, #0x966]                          
02c894f0: tbnz    w8, #0, #0x2c89508                         
02c894f4: adrp    x0, #0x6264000                             
02c894f8: ldr     x0, [x0, #0xfc0]                           T:RemoteConfigManager
02c894fc: bl      #0x2b70db0                                 fn_2b70db0
02c89500: mov     w8, #1                                     
02c89504: strb    w8, [x20, #0x966]                          
02c89508: ldrb    w8, [x19, #0x38]                           ._isDoneCapping
02c8950c: cbz     w8, #0x2c89580                             
02c89510: bl      #0x2c89590                                 AdsManager::get_IsDoneAd
02c89514: tbz     w0, #0, #0x2c89580                         
02c89518: adrp    x20, #0x6264000                            
02c8951c: ldr     x20, [x20, #0xfc0]                         T:RemoteConfigManager
02c89520: ldr     x0, [x20]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c89524: ldr     w8, [x0, #0xe4]                            [62640e4]=0 f=0,0
02c89528: cbnz    w8, #0x2c89530                             
02c8952c: bl      #0x2b70f30                                 fn_2b70f30
02c89530: adrp    x21, #0x662f000                            
02c89534: ldrb    w8, [x21, #0xa7a]                          
02c89538: cbnz    w8, #0x2c89550                             
02c8953c: adrp    x0, #0x6264000                             
02c89540: ldr     x0, [x0, #0xfc0]                           T:RemoteConfigManager
02c89544: bl      #0x2b70db0                                 fn_2b70db0
02c89548: mov     w8, #1                                     
02c8954c: strb    w8, [x21, #0xa7a]                          
02c89550: ldr     x0, [x20]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c89554: ldr     w8, [x0, #0xe4]                            [62640e4]=0 f=0,0
02c89558: cbnz    w8, #0x2c89564                             
02c8955c: bl      #0x2b70f30                                 fn_2b70f30
02c89560: ldr     x0, [x20]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c89564: ldr     x8, [x0, #0xb8]                            MS:DG.Tweening.Core.Extensions::SetSpecialStartupMode
02c89568: ldrb    w8, [x8]                                   
02c8956c: cbz     w8, #0x2c89580                             
02c89570: ldrb    w8, [x19, #0x30]                           ._testMode
02c89574: cmp     w8, #0                                     
02c89578: cset    w0, eq                                     
02c8957c: b       #0x2c89584                                 
02c89580: mov     w0, wzr                                    
02c89584: ldp     x20, x19, [sp, #0x10]                      
02c89588: ldp     x30, x21, [sp], #0x20                      
02c8958c: ret                                                
## get_IsDoneAd() -> bool
---- AdsManager::get_IsDoneAd 0x2c89590
02c89590: str     x30, [sp, #-0x20]!                         
02c89594: stp     x20, x19, [sp, #0x10]                      
02c89598: adrp    x19, #0x662f000                            
02c8959c: adrp    x20, #0x6265000                            
02c895a0: ldrb    w8, [x19, #0x967]                          
02c895a4: ldr     x20, [x20, #0x40]                          S:'done_ad' .cappingCoroutine
02c895a8: tbnz    w8, #0, #0x2c895c0                         
02c895ac: adrp    x0, #0x6265000                             
02c895b0: ldr     x0, [x0, #0x40]                            S:'done_ad' .cappingCoroutine
02c895b4: bl      #0x2b70db0                                 fn_2b70db0
02c895b8: mov     w8, #1                                     
02c895bc: strb    w8, [x19, #0x967]                          
02c895c0: ldr     x0, [x20]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c895c4: ldp     x20, x19, [sp, #0x10]                      
02c895c8: mov     x1, xzr                                    
02c895cc: ldr     x30, [sp], #0x20                           
02c895d0: b       #0x5b2d73c                                 UnityEngine.PlayerPrefs::HasKey
## SetStartShowAd() -> void
---- AdsManager::SetStartShowAd 0x2c895d4
02c895d4: str     x30, [sp, #-0x20]!                         
02c895d8: stp     x20, x19, [sp, #0x10]                      
02c895dc: adrp    x19, #0x662f000                            
02c895e0: adrp    x20, #0x6265000                            
02c895e4: ldrb    w8, [x19, #0x968]                          
02c895e8: ldr     x20, [x20, #0x40]                          S:'done_ad' .cappingCoroutine
02c895ec: tbnz    w8, #0, #0x2c89604                         
02c895f0: adrp    x0, #0x6265000                             
02c895f4: ldr     x0, [x0, #0x40]                            S:'done_ad' .cappingCoroutine
02c895f8: bl      #0x2b70db0                                 fn_2b70db0
02c895fc: mov     w8, #1                                     
02c89600: strb    w8, [x19, #0x968]                          
02c89604: ldr     x0, [x20]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c89608: ldp     x20, x19, [sp, #0x10]                      
02c8960c: mov     w1, wzr                                    
02c89610: mov     x2, xzr                                    
02c89614: ldr     x30, [sp], #0x20                           
02c89618: b       #0x5b2d184                                 UnityEngine.PlayerPrefs::SetInt
## ResetCapping() -> void
---- AdsManager::ResetCapping 0x2c88954
02c88954: str     x30, [sp, #-0x30]!                         
02c88958: stp     x22, x21, [sp, #0x10]                      
02c8895c: stp     x20, x19, [sp, #0x20]                      
02c88960: adrp    x20, #0x662f000                            
02c88964: mov     x19, x0                                    
02c88968: ldrb    w8, [x20, #0x969]                          
02c8896c: tbnz    w8, #0, #0x2c88984                         
02c88970: adrp    x0, #0x6264000                             
02c88974: ldr     x0, [x0, #0xfc0]                           T:RemoteConfigManager
02c88978: bl      #0x2b70db0                                 fn_2b70db0
02c8897c: mov     w8, #1                                     
02c88980: strb    w8, [x20, #0x969]                          
02c88984: mov     x20, x19                                   
02c88988: adrp    x21, #0x6264000                            
02c8898c: ldr     x1, [x20, #0x40]!                          &2b70700(=14cc750491004000) .cappingCoroutine
02c88990: ldr     x21, [x21, #0xfc0]                         T:RemoteConfigManager
02c88994: cbz     x1, #0x2c889a4                             
02c88998: mov     x0, x19                                    
02c8899c: mov     x2, xzr                                    
02c889a0: bl      #0x5b38c4c                                 UnityEngine.MonoBehaviour::StopCoroutine
02c889a4: ldr     x0, [x21]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c889a8: ldr     w8, [x0, #0xe4]                            [62640e4]=0 f=0,0
02c889ac: cbnz    w8, #0x2c889b4                             
02c889b0: bl      #0x2b70f30                                 fn_2b70f30
02c889b4: adrp    x22, #0x662f000                            
02c889b8: ldrb    w8, [x22, #0xa7b]                          
02c889bc: cbnz    w8, #0x2c889d4                             
02c889c0: adrp    x0, #0x6264000                             
02c889c4: ldr     x0, [x0, #0xfc0]                           T:RemoteConfigManager
02c889c8: bl      #0x2b70db0                                 fn_2b70db0
02c889cc: mov     w8, #1                                     
02c889d0: strb    w8, [x22, #0xa7b]                          
02c889d4: ldr     x0, [x21]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c889d8: ldr     w8, [x0, #0xe4]                            [62640e4]=0 f=0,0
02c889dc: cbnz    w8, #0x2c889e8                             
02c889e0: bl      #0x2b70f30                                 fn_2b70f30
02c889e4: ldr     x0, [x21]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c889e8: ldr     x8, [x0, #0xb8]                            MS:DG.Tweening.Core.Extensions::SetSpecialStartupMode
02c889ec: mov     x0, x19                                    
02c889f0: ldr     s0, [x8, #4]                               
02c889f4: scvtf   s0, s0                                     
02c889f8: bl      #0x2c8961c                                 AdsManager::ISetInterCapping
02c889fc: mov     x1, x0                                     
02c88a00: mov     x0, x19                                    
02c88a04: mov     x2, xzr                                    
02c88a08: bl      #0x5b389f0                                 UnityEngine.MonoBehaviour::StartCoroutine
02c88a0c: mov     x1, x0                                     
02c88a10: mov     x0, x20                                    
02c88a14: str     x1, [x19, #0x40]                           .cappingCoroutine
02c88a18: ldp     x20, x19, [sp, #0x20]                      
02c88a1c: ldp     x22, x21, [sp, #0x10]                      
02c88a20: ldr     x30, [sp], #0x30                           
02c88a24: b       #0x2b70d54                                 
## ShowInter(string placment, System.Action action, bool isDoubleAd) -> void
---- AdsManager::ShowInter 0x2c89698
02c89698: str     x30, [sp, #-0x40]!                         
02c8969c: stp     x24, x23, [sp, #0x10]                      
02c896a0: stp     x22, x21, [sp, #0x20]                      
02c896a4: stp     x20, x19, [sp, #0x30]                      
02c896a8: adrp    x24, #0x662f000                            
02c896ac: adrp    x23, #0x6263000                            
02c896b0: mov     w21, w3                                    
02c896b4: ldrb    w8, [x24, #0x96a]                          
02c896b8: ldr     x23, [x23, #0x928]                         T:UnityEngine.Debug
02c896bc: mov     x19, x2                                    
02c896c0: mov     x20, x1                                    
02c896c4: mov     x22, x0                                    
02c896c8: tbnz    w8, #0, #0x2c89704                         
02c896cc: adrp    x0, #0x6263000                             
02c896d0: ldr     x0, [x0, #0x928]                           T:UnityEngine.Debug
02c896d4: bl      #0x2b70db0                                 fn_2b70db0
02c896d8: adrp    x0, #0x6265000                             
02c896dc: ldr     x0, [x0, #0x50]                            S:'af_inters_call_show' ._coroutineHideAdResume
02c896e0: bl      #0x2b70db0                                 fn_2b70db0
02c896e4: adrp    x0, #0x6265000                             
02c896e8: ldr     x0, [x0, #0x58]                            S:'dev log AdsManager show inter max' ._interMaxShownCount
02c896ec: bl      #0x2b70db0                                 fn_2b70db0
02c896f0: adrp    x0, #0x6265000                             
02c896f4: ldr     x0, [x0, #0x60]                            S:'af_inters_passed_capping_time'
02c896f8: bl      #0x2b70db0                                 fn_2b70db0
02c896fc: mov     w8, #1                                     
02c89700: strb    w8, [x24, #0x96a]                          
02c89704: ldr     x0, [x23]                                  &2c5bbd4(=a9bd7bfdd503233f)
02c89708: adrp    x24, #0x6265000                            
02c8970c: adrp    x23, #0x6265000                            
02c89710: ldr     x24, [x24, #0x58]                          S:'dev log AdsManager show inter max'
02c89714: ldr     w8, [x0, #0xe4]                            [62650e4]=0 f=0,0
02c89718: ldr     x23, [x23, #0x50]                          S:'af_inters_call_show'
02c8971c: cbnz    w8, #0x2c89724                             
02c89720: bl      #0x2b70f30                                 fn_2b70f30
02c89724: ldr     x0, [x24]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c89728: mov     x1, xzr                                    
02c8972c: bl      #0x5af21f4                                 UnityEngine.Debug::Log
02c89730: ldr     x0, [x23]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c89734: mov     x1, xzr                                    
02c89738: bl      #0x2c89794                                 AnalyticsManager::LogAppsflyerEvent
02c8973c: mov     x0, x22                                    
02c89740: bl      #0x2c894dc                                 AdsManager::get_CanShowInter
02c89744: tbz     w0, #0, #0x2c8975c                         
02c89748: adrp    x8, #0x6265000                             
02c8974c: mov     x1, xzr                                    
02c89750: ldr     x8, [x8, #0x60]                            S:'af_inters_passed_capping_time'
02c89754: ldr     x0, [x8]                                   M:AdsManager::<OnApplicationPause>b__26_0
02c89758: bl      #0x2c89794                                 AnalyticsManager::LogAppsflyerEvent
02c8975c: mov     x0, x22                                    
02c89760: mov     x1, x20                                    
02c89764: mov     x2, x19                                    
02c89768: tbz     w21, #0, #0x2c89780                        
02c8976c: ldp     x20, x19, [sp, #0x30]                      
02c89770: ldp     x22, x21, [sp, #0x20]                      
02c89774: ldp     x24, x23, [sp, #0x10]                      
02c89778: ldr     x30, [sp], #0x40                           
02c8977c: b       #0x2c89818                                 AdsManager::ShowInterDouble
02c89780: ldp     x20, x19, [sp, #0x30]                      
02c89784: ldp     x22, x21, [sp, #0x20]                      
02c89788: ldp     x24, x23, [sp, #0x10]                      
02c8978c: ldr     x30, [sp], #0x40                           
02c89790: b       #0x2c89b2c                                 AdsManager::ShowNativeInterBackFill
## ShowInterAdmob(string placment, System.Action action) -> void
---- AdsManager::ShowInterAdmob 0x2c89e30
02c89e30: stp     x30, x25, [sp, #-0x40]!                    
02c89e34: stp     x24, x23, [sp, #0x10]                      
02c89e38: stp     x22, x21, [sp, #0x20]                      
02c89e3c: stp     x20, x19, [sp, #0x30]                      
02c89e40: adrp    x21, #0x662f000                            
02c89e44: adrp    x23, #0x6265000                            
02c89e48: mov     x22, x2                                    
02c89e4c: ldrb    w8, [x21, #0x96b]                          
02c89e50: ldr     x23, [x23, #0xb8]                          T:AdsManager/<>c__DisplayClass42_0
02c89e54: mov     x19, x1                                    
02c89e58: mov     x20, x0                                    
02c89e5c: tbnz    w8, #0, #0x2c89ed4                         
02c89e60: adrp    x0, #0x6264000                             
02c89e64: ldr     x0, [x0, #0xf90]                           T:System.Action
02c89e68: bl      #0x2b70db0                                 fn_2b70db0
02c89e6c: adrp    x0, #0x6263000                             
02c89e70: ldr     x0, [x0, #0x928]                           T:UnityEngine.Debug
02c89e74: bl      #0x2b70db0                                 fn_2b70db0
02c89e78: adrp    x0, #0x6265000                             
02c89e7c: ldr     x0, [x0, #0xc0]                            M:AdsManager/<>c__DisplayClass42_0::<ShowInterAdmob>b__0
02c89e80: bl      #0x2b70db0                                 fn_2b70db0
02c89e84: adrp    x0, #0x6265000                             
02c89e88: ldr     x0, [x0, #0xc8]                            M:AdsManager/<>c__DisplayClass42_0::<ShowInterAdmob>b__1
02c89e8c: bl      #0x2b70db0                                 fn_2b70db0
02c89e90: adrp    x0, #0x6265000                             
02c89e94: ldr     x0, [x0, #0xb8]                            T:AdsManager/<>c__DisplayClass42_0
02c89e98: bl      #0x2b70db0                                 fn_2b70db0
02c89e9c: adrp    x0, #0x6265000                             
02c89ea0: ldr     x0, [x0, #0xd0]                            S:'admob_inters_displayed'
02c89ea4: bl      #0x2b70db0                                 fn_2b70db0
02c89ea8: adrp    x0, #0x6265000                             
02c89eac: ldr     x0, [x0, #0xd8]                            S:'dev log AdsManager show inter admob'
02c89eb0: bl      #0x2b70db0                                 fn_2b70db0
02c89eb4: adrp    x0, #0x6265000                             
02c89eb8: ldr     x0, [x0, #0xe0]                            S:'dev log AdsManager inter admob nofill, show inter max backfill'
02c89ebc: bl      #0x2b70db0                                 fn_2b70db0
02c89ec0: adrp    x0, #0x6265000                             
02c89ec4: ldr     x0, [x0, #0x98]                            S:'[Inter] show failed'
02c89ec8: bl      #0x2b70db0                                 fn_2b70db0
02c89ecc: mov     w8, #1                                     
02c89ed0: strb    w8, [x21, #0x96b]                          
02c89ed4: ldr     x0, [x23]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c89ed8: bl      #0x2b7104c                                 fn_2b7104c
02c89edc: mov     x1, xzr                                    
02c89ee0: mov     x21, x0                                    
02c89ee4: bl      #0x4e53e9c                                 System.Object::.ctor
02c89ee8: cbz     x21, #0x2c8a0b0                            
02c89eec: adrp    x24, #0x6263000                            
02c89ef0: adrp    x25, #0x6265000                            
02c89ef4: mov     x0, x21                                    
02c89ef8: ldr     x24, [x24, #0x928]                         T:UnityEngine.Debug
02c89efc: ldr     x25, [x25, #0xd8]                          S:'dev log AdsManager show inter admob'
02c89f00: mov     x1, x20                                    
02c89f04: str     x20, [x0, #0x10]!                          
02c89f08: bl      #0x2b70d54                                 fn_2b70d54
02c89f0c: mov     x23, x21                                   
02c89f10: mov     x1, x22                                    
02c89f14: str     x22, [x23, #0x18]!                         
02c89f18: mov     x0, x23                                    
02c89f1c: bl      #0x2b70d54                                 fn_2b70d54
02c89f20: ldr     x0, [x24]                                  &2c5bbd4(=a9bd7bfdd503233f)
02c89f24: ldr     w8, [x0, #0xe4]                            [62650e4]=0 f=0,0
02c89f28: cbnz    w8, #0x2c89f30                             
02c89f2c: bl      #0x2b70f30                                 fn_2b70f30
02c89f30: ldr     x0, [x25]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c89f34: mov     x1, xzr                                    
02c89f38: bl      #0x5af21f4                                 UnityEngine.Debug::Log
02c89f3c: mov     x0, x20                                    
02c89f40: bl      #0x2c894dc                                 AdsManager::get_CanShowInter
02c89f44: tbz     w0, #0, #0x2c8a074                         
02c89f48: mov     x0, x20                                    
02c89f4c: bl      #0x2c88f94                                 AdsManager::HideAdResume
02c89f50: ldr     x0, [x20, #0x28]                           ._googleMobileAdsManager
02c89f54: cbz     x0, #0x2c8a0b0                             
02c89f58: bl      #0x2c8a0bc                                 GoogleMobileAdsManager::get_IsInterReady
02c89f5c: tbz     w0, #0, #0x2c89fc4                         
02c89f60: adrp    x8, #0x6264000                             
02c89f64: mov     w9, #1                                     
02c89f68: ldr     x8, [x8, #0xf90]                           T:System.Action
02c89f6c: ldr     x19, [x20, #0x28]                          ._googleMobileAdsManager
02c89f70: strb    w9, [x20, #0x4b]                           ._isShowingInter
02c89f74: ldr     x0, [x8]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c89f78: bl      #0x2b7104c                                 fn_2b7104c
02c89f7c: adrp    x8, #0x6265000                             
02c89f80: mov     x1, x21                                    
02c89f84: mov     x3, xzr                                    
02c89f88: ldr     x8, [x8, #0xc0]                            M:AdsManager/<>c__DisplayClass42_0::<ShowInterAdmob>b__0
02c89f8c: mov     x20, x0                                    
02c89f90: ldr     x2, [x8]                                   M:AdsManager::<OnApplicationPause>b__26_0
02c89f94: bl      #0x4d8ddbc                                 System.Action::.ctor
02c89f98: cbz     x19, #0x2c8a0b0                            
02c89f9c: adrp    x8, #0x6265000                             
02c89fa0: mov     x0, x19                                    
02c89fa4: mov     x2, x20                                    
02c89fa8: ldr     x8, [x8, #0xd0]                            S:'admob_inters_displayed'
02c89fac: ldp     x20, x19, [sp, #0x30]                      
02c89fb0: ldp     x22, x21, [sp, #0x20]                      
02c89fb4: ldp     x24, x23, [sp, #0x10]                      
02c89fb8: ldr     x1, [x8]                                   M:AdsManager::<OnApplicationPause>b__26_0
02c89fbc: ldp     x30, x25, [sp], #0x40                      
02c89fc0: b       #0x2c8a0e0                                 GoogleMobileAdsManager::ShowInter
02c89fc4: ldr     x8, [x20, #0x20]                           ._applonvinManager
02c89fc8: cbz     x8, #0x2c8a0b0                             
02c89fcc: ldr     x8, [x8, #0x20]                            S:'dev log AdsManager show app open ad'
02c89fd0: cbz     x8, #0x2c8a0b0                             
02c89fd4: bl      #0x2c8c8c8                                 InterApplovinControl::IsAdReady
02c89fd8: tbz     w0, #0, #0x2c8a060                         
02c89fdc: ldr     x0, [x24]                                  &2c5bbd4(=a9bd7bfdd503233f)
02c89fe0: ldr     w8, [x0, #0xe4]                            [62650e4]=0 f=0,0
02c89fe4: cbnz    w8, #0x2c89fec                             
02c89fe8: bl      #0x2b70f30                                 fn_2b70f30
02c89fec: adrp    x8, #0x6265000                             
02c89ff0: mov     x1, xzr                                    
02c89ff4: ldr     x8, [x8, #0xe0]                            S:'dev log AdsManager inter admob nofill, show inter max backfill'
02c89ff8: ldr     x0, [x8]                                   M:AdsManager::<OnApplicationPause>b__26_0
02c89ffc: bl      #0x5af21f4                                 UnityEngine.Debug::Log
02c8a000: adrp    x8, #0x6264000                             
02c8a004: mov     w9, #1                                     
02c8a008: ldr     x8, [x8, #0xf90]                           T:System.Action
02c8a00c: ldr     x22, [x20, #0x20]                          ._applonvinManager
02c8a010: strb    w9, [x20, #0x4b]                           ._isShowingInter
02c8a014: ldr     x0, [x8]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c8a018: bl      #0x2b7104c                                 fn_2b7104c
02c8a01c: adrp    x8, #0x6265000                             
02c8a020: mov     x1, x21                                    
02c8a024: mov     x3, xzr                                    
02c8a028: ldr     x8, [x8, #0xc8]                            M:AdsManager/<>c__DisplayClass42_0::<ShowInterAdmob>b__1
02c8a02c: mov     x20, x0                                    
02c8a030: ldr     x2, [x8]                                   M:AdsManager::<OnApplicationPause>b__26_0
02c8a034: bl      #0x4d8ddbc                                 System.Action::.ctor
02c8a038: cbz     x22, #0x2c8a0b0                            
02c8a03c: ldr     x0, [x22, #0x20]                           
02c8a040: cbz     x0, #0x2c8a0b0                             
02c8a044: mov     x1, x19                                    
02c8a048: mov     x2, x20                                    
02c8a04c: ldp     x20, x19, [sp, #0x30]                      
02c8a050: ldp     x22, x21, [sp, #0x20]                      
02c8a054: ldp     x24, x23, [sp, #0x10]                      
02c8a058: ldp     x30, x25, [sp], #0x40                      
02c8a05c: b       #0x2c8cba4                                 InterApplovinControl::ShowAd
02c8a060: adrp    x8, #0x6265000                             
02c8a064: mov     x1, xzr                                    
02c8a068: ldr     x8, [x8, #0x98]                            S:'[Inter] show failed'
02c8a06c: ldr     x0, [x8]                                   M:AdsManager::<OnApplicationPause>b__26_0
02c8a070: bl      #0x2ca09f8                                 WLog::LogError
02c8a074: ldr     x8, [x23]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c8a078: cbz     x8, #0x2c8a09c                             
02c8a07c: ldp     x20, x19, [sp, #0x30]                      
02c8a080: ldr     x0, [x8, #0x40]                            S:'done_ad'
02c8a084: ldp     x22, x21, [sp, #0x20]                      
02c8a088: ldr     x1, [x8, #0x28]                            T:AdsManager/<ISetAOAInterval>d__33
02c8a08c: ldr     x2, [x8, #0x18]                            T:AdsManager/<IEHideAdResume>d__30
02c8a090: ldp     x24, x23, [sp, #0x10]                      
02c8a094: ldp     x30, x25, [sp], #0x40                      
02c8a098: br      x2                                         
02c8a09c: ldp     x20, x19, [sp, #0x30]                      
02c8a0a0: ldp     x22, x21, [sp, #0x20]                      
02c8a0a4: ldp     x24, x23, [sp, #0x10]                      
02c8a0a8: ldp     x30, x25, [sp], #0x40                      
02c8a0ac: ret                                                
02c8a0b0: bl      #0x2b7105c                                 fn_2b7105c
## ShowInterDouble(string placment, System.Action action) -> void
---- AdsManager::ShowInterDouble 0x2c89818
02c89818: stp     x30, x23, [sp, #-0x30]!                    
02c8981c: stp     x22, x21, [sp, #0x10]                      
02c89820: stp     x20, x19, [sp, #0x20]                      
02c89824: adrp    x20, #0x662f000                            
02c89828: adrp    x23, #0x6265000                            
02c8982c: mov     x21, x2                                    
02c89830: ldrb    w8, [x20, #0x96c]                          
02c89834: ldr     x23, [x23, #0x68]                          T:AdsManager/<>c__DisplayClass43_0
02c89838: mov     x22, x1                                    
02c8983c: mov     x19, x0                                    
02c89840: tbnz    w8, #0, #0x2c898c4                         
02c89844: adrp    x0, #0x6264000                             
02c89848: ldr     x0, [x0, #0xf90]                           T:System.Action
02c8984c: bl      #0x2b70db0                                 fn_2b70db0
02c89850: adrp    x0, #0x6263000                             
02c89854: ldr     x0, [x0, #0x928]                           T:UnityEngine.Debug
02c89858: bl      #0x2b70db0                                 fn_2b70db0
02c8985c: adrp    x0, #0x6264000                             
02c89860: ldr     x0, [x0, #0xfc0]                           T:RemoteConfigManager
02c89864: bl      #0x2b70db0                                 fn_2b70db0
02c89868: adrp    x0, #0x6265000                             
02c8986c: ldr     x0, [x0, #0x70]                            M:AdsManager/<>c__DisplayClass43_0::<ShowInterDouble>b__1
02c89870: bl      #0x2b70db0                                 fn_2b70db0
02c89874: adrp    x0, #0x6265000                             
02c89878: ldr     x0, [x0, #0x78]                            M:AdsManager/<>c__DisplayClass43_0::<ShowInterDouble>b__2
02c8987c: bl      #0x2b70db0                                 fn_2b70db0
02c89880: adrp    x0, #0x6265000                             
02c89884: ldr     x0, [x0, #0x68]                            T:AdsManager/<>c__DisplayClass43_0
02c89888: bl      #0x2b70db0                                 fn_2b70db0
02c8988c: adrp    x0, #0x6265000                             
02c89890: ldr     x0, [x0, #0x80]                            S:'af_inters_load_fail'
02c89894: bl      #0x2b70db0                                 fn_2b70db0
02c89898: adrp    x0, #0x6265000                             
02c8989c: ldr     x0, [x0, #0x88]                            S:'dev log AdsManager show native fullscreen before inter max'
02c898a0: bl      #0x2b70db0                                 fn_2b70db0
02c898a4: adrp    x0, #0x6265000                             
02c898a8: ldr     x0, [x0, #0x90]                            S:'af_inters_available'
02c898ac: bl      #0x2b70db0                                 fn_2b70db0
02c898b0: adrp    x0, #0x6265000                             
02c898b4: ldr     x0, [x0, #0x98]                            S:'[Inter] show failed'
02c898b8: bl      #0x2b70db0                                 fn_2b70db0
02c898bc: mov     w8, #1                                     
02c898c0: strb    w8, [x20, #0x96c]                          
02c898c4: ldr     x0, [x23]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c898c8: bl      #0x2b7104c                                 fn_2b7104c
02c898cc: mov     x1, xzr                                    
02c898d0: mov     x20, x0                                    
02c898d4: bl      #0x4e53e9c                                 System.Object::.ctor
02c898d8: cbz     x20, #0x2c89b28                            
02c898dc: mov     x0, x20                                    
02c898e0: mov     x1, x19                                    
02c898e4: str     x19, [x0, #0x10]!                          
02c898e8: bl      #0x2b70d54                                 fn_2b70d54
02c898ec: mov     x0, x20                                    
02c898f0: mov     x1, x22                                    
02c898f4: str     x22, [x0, #0x18]!                          
02c898f8: bl      #0x2b70d54                                 fn_2b70d54
02c898fc: mov     x22, x20                                   
02c89900: mov     x1, x21                                    
02c89904: str     x21, [x22, #0x20]!                         
02c89908: mov     x0, x22                                    
02c8990c: bl      #0x2b70d54                                 fn_2b70d54
02c89910: mov     x0, x19                                    
02c89914: bl      #0x2c894dc                                 AdsManager::get_CanShowInter
02c89918: tbz     w0, #0, #0x2c89a18                         
02c8991c: mov     x0, xzr                                    
02c89920: bl      #0x5adf0d0                                 UnityEngine.AudioListener::get_pause
02c89924: and     w8, w0, #1                                 
02c89928: mov     w0, #1                                     
02c8992c: mov     x1, xzr                                    
02c89930: strb    w8, [x20, #0x28]                           ._googleMobileAdsManager
02c89934: bl      #0x5adf0f8                                 UnityEngine.AudioListener::set_pause
02c89938: adrp    x21, #0x6264000                            
02c8993c: ldr     x21, [x21, #0xfc0]                         T:RemoteConfigManager
02c89940: ldr     x0, [x21]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c89944: ldr     w8, [x0, #0xe4]                            [62650e4]=0 f=0,0
02c89948: cbnz    w8, #0x2c89950                             
02c8994c: bl      #0x2b70f30                                 fn_2b70f30
02c89950: adrp    x22, #0x662f000                            
02c89954: ldrb    w8, [x22, #0xa7c]                          
02c89958: cbnz    w8, #0x2c89970                             
02c8995c: adrp    x0, #0x6264000                             
02c89960: ldr     x0, [x0, #0xfc0]                           T:RemoteConfigManager
02c89964: bl      #0x2b70db0                                 fn_2b70db0
02c89968: mov     w8, #1                                     
02c8996c: strb    w8, [x22, #0xa7c]                          
02c89970: ldr     x0, [x21]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c89974: ldr     w8, [x0, #0xe4]                            [62640e4]=0 f=0,0
02c89978: cbnz    w8, #0x2c89984                             
02c8997c: bl      #0x2b70f30                                 fn_2b70f30
02c89980: ldr     x0, [x21]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c89984: ldr     x8, [x0, #0xb8]                            MS:DG.Tweening.Core.Extensions::SetSpecialStartupMode
02c89988: ldrb    w8, [x8, #0x14]                            
02c8998c: cbz     w8, #0x2c89a3c                             
02c89990: adrp    x8, #0x6263000                             
02c89994: ldr     x8, [x8, #0x928]                           T:UnityEngine.Debug
02c89998: ldr     x0, [x8]                                   &2c5bbd4(=a9bd7bfdd503233f)
02c8999c: ldr     w8, [x0, #0xe4]                            [62640e4]=0 f=0,0
02c899a0: cbnz    w8, #0x2c899a8                             
02c899a4: bl      #0x2b70f30                                 fn_2b70f30
02c899a8: adrp    x8, #0x6265000                             
02c899ac: mov     x1, xzr                                    
02c899b0: ldr     x8, [x8, #0x88]                            S:'dev log AdsManager show native fullscreen before inter max'
02c899b4: ldr     x0, [x8]                                   M:AdsManager::<OnApplicationPause>b__26_0
02c899b8: bl      #0x5af21f4                                 UnityEngine.Debug::Log
02c899bc: mov     x0, x19                                    
02c899c0: bl      #0x2c88f94                                 AdsManager::HideAdResume
02c899c4: adrp    x8, #0x6264000                             
02c899c8: mov     w9, #1                                     
02c899cc: ldr     x8, [x8, #0xf90]                           T:System.Action
02c899d0: ldr     x21, [x19, #0x28]                          ._googleMobileAdsManager
02c899d4: strb    w9, [x19, #0x4b]                           ._isShowingInter
02c899d8: ldr     x0, [x8]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c899dc: bl      #0x2b7104c                                 fn_2b7104c
02c899e0: adrp    x8, #0x6265000                             
02c899e4: mov     x1, x20                                    
02c899e8: mov     x3, xzr                                    
02c899ec: ldr     x8, [x8, #0x70]                            M:AdsManager/<>c__DisplayClass43_0::<ShowInterDouble>b__1
02c899f0: mov     x19, x0                                    
02c899f4: ldr     x2, [x8]                                   M:AdsManager::<OnApplicationPause>b__26_0
02c899f8: bl      #0x4d8ddbc                                 System.Action::.ctor
02c899fc: cbz     x21, #0x2c89b28                            
02c89a00: mov     x0, x21                                    
02c89a04: mov     x2, x19                                    
02c89a08: ldp     x20, x19, [sp, #0x20]                      
02c89a0c: ldp     x22, x21, [sp, #0x10]                      
02c89a10: ldp     x30, x23, [sp], #0x30                      
02c89a14: b       #0x2c8a174                                 GoogleMobileAdsManager::ShowNativeInter
02c89a18: ldr     x8, [x22]                                  &2b706c4(=eb01011ff9400808)
02c89a1c: cbz     x8, #0x2c89b18                             
02c89a20: ldp     x20, x19, [sp, #0x20]                      
02c89a24: ldr     x0, [x8, #0x40]                            S:'done_ad'
02c89a28: ldp     x22, x21, [sp, #0x10]                      
02c89a2c: ldr     x1, [x8, #0x28]                            T:AdsManager/<ISetAOAInterval>d__33
02c89a30: ldr     x2, [x8, #0x18]                            T:AdsManager/<IEHideAdResume>d__30
02c89a34: ldp     x30, x23, [sp], #0x30                      
02c89a38: br      x2                                         
02c89a3c: mov     x0, x19                                    
02c89a40: bl      #0x2c88f94                                 AdsManager::HideAdResume
02c89a44: ldr     x8, [x19, #0x20]                           ._applonvinManager
02c89a48: cbz     x8, #0x2c89b28                             
02c89a4c: ldr     x8, [x8, #0x20]                            S:'dev log AdsManager show app open ad'
02c89a50: cbz     x8, #0x2c89b28                             
02c89a54: bl      #0x2c8c8c8                                 InterApplovinControl::IsAdReady
02c89a58: tbz     w0, #0, #0x2c89adc                         
02c89a5c: adrp    x8, #0x6265000                             
02c89a60: mov     x1, xzr                                    
02c89a64: ldr     x8, [x8, #0x90]                            S:'af_inters_available'
02c89a68: ldr     x0, [x8]                                   M:AdsManager::<OnApplicationPause>b__26_0
02c89a6c: bl      #0x2c89794                                 AnalyticsManager::LogAppsflyerEvent
02c89a70: adrp    x9, #0x6264000                             
02c89a74: ldr     w8, [x19, #0x58]                           ._interMaxShownCount
02c89a78: mov     w10, #1                                    
02c89a7c: ldr     x9, [x9, #0xf90]                           T:System.Action
02c89a80: ldr     x22, [x19, #0x20]                          ._applonvinManager
02c89a84: ldr     x21, [x20, #0x18]                          [662f018]=6000014 f=2.40742e-35,0
02c89a88: add     w8, w8, #1                                 
02c89a8c: strb    w10, [x19, #0x4b]                          ._isShowingInter
02c89a90: ldr     x0, [x9]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c89a94: str     w8, [x19, #0x58]                           ._interMaxShownCount
02c89a98: bl      #0x2b7104c                                 fn_2b7104c
02c89a9c: adrp    x8, #0x6265000                             
02c89aa0: mov     x1, x20                                    
02c89aa4: mov     x3, xzr                                    
02c89aa8: ldr     x8, [x8, #0x78]                            M:AdsManager/<>c__DisplayClass43_0::<ShowInterDouble>b__2
02c89aac: mov     x19, x0                                    
02c89ab0: ldr     x2, [x8]                                   M:AdsManager::<OnApplicationPause>b__26_0
02c89ab4: bl      #0x4d8ddbc                                 System.Action::.ctor
02c89ab8: cbz     x22, #0x2c89b28                            
02c89abc: ldr     x0, [x22, #0x20]                           &2b706f0(=d65f03c0f9400800)
02c89ac0: cbz     x0, #0x2c89b28                             
02c89ac4: mov     x1, x21                                    
02c89ac8: mov     x2, x19                                    
02c89acc: ldp     x20, x19, [sp, #0x20]                      
02c89ad0: ldp     x22, x21, [sp, #0x10]                      
02c89ad4: ldp     x30, x23, [sp], #0x30                      
02c89ad8: b       #0x2c8cba4                                 InterApplovinControl::ShowAd
02c89adc: adrp    x8, #0x6265000                             
02c89ae0: mov     x1, xzr                                    
02c89ae4: ldr     x8, [x8, #0x80]                            S:'af_inters_load_fail'
02c89ae8: ldr     x0, [x8]                                   M:AdsManager::<OnApplicationPause>b__26_0
02c89aec: bl      #0x2c89794                                 AnalyticsManager::LogAppsflyerEvent
02c89af0: adrp    x8, #0x6265000                             
02c89af4: mov     x1, xzr                                    
02c89af8: ldr     x8, [x8, #0x98]                            S:'[Inter] show failed'
02c89afc: ldr     x0, [x8]                                   M:AdsManager::<OnApplicationPause>b__26_0
02c89b00: bl      #0x2ca09f8                                 WLog::LogError
02c89b04: ldrb    w0, [x20, #0x28]                           ._googleMobileAdsManager
02c89b08: mov     x1, xzr                                    
02c89b0c: bl      #0x5adf0f8                                 UnityEngine.AudioListener::set_pause
02c89b10: ldr     x8, [x20, #0x20]                           &2b706f0(=d65f03c0f9400800) ._applonvinManager
02c89b14: cbnz    x8, #0x2c89a20                             
02c89b18: ldp     x20, x19, [sp, #0x20]                      
02c89b1c: ldp     x22, x21, [sp, #0x10]                      
02c89b20: ldp     x30, x23, [sp], #0x30                      
02c89b24: ret                                                
02c89b28: bl      #0x2b7105c                                 fn_2b7105c
## ShowNativeInterBackFill(string placment, System.Action action) -> void
---- AdsManager::ShowNativeInterBackFill 0x2c89b2c
02c89b2c: stp     x30, x23, [sp, #-0x30]!                    
02c89b30: stp     x22, x21, [sp, #0x10]                      
02c89b34: stp     x20, x19, [sp, #0x20]                      
02c89b38: adrp    x21, #0x662f000                            
02c89b3c: adrp    x23, #0x6265000                            
02c89b40: mov     x22, x2                                    
02c89b44: ldrb    w8, [x21, #0x96d]                          
02c89b48: ldr     x23, [x23, #0xa0]                          T:AdsManager/<>c__DisplayClass44_0
02c89b4c: mov     x20, x1                                    
02c89b50: mov     x19, x0                                    
02c89b54: tbnz    w8, #0, #0x2c89bd8                         
02c89b58: adrp    x0, #0x6264000                             
02c89b5c: ldr     x0, [x0, #0xf90]                           T:System.Action
02c89b60: bl      #0x2b70db0                                 fn_2b70db0
02c89b64: adrp    x0, #0x6263000                             
02c89b68: ldr     x0, [x0, #0x928]                           T:UnityEngine.Debug
02c89b6c: bl      #0x2b70db0                                 fn_2b70db0
02c89b70: adrp    x0, #0x6264000                             
02c89b74: ldr     x0, [x0, #0xfc0]                           T:RemoteConfigManager
02c89b78: bl      #0x2b70db0                                 fn_2b70db0
02c89b7c: adrp    x0, #0x6265000                             
02c89b80: ldr     x0, [x0, #0xa8]                            M:AdsManager/<>c__DisplayClass44_0::<ShowNativeInterBackFill>b__1
02c89b84: bl      #0x2b70db0                                 fn_2b70db0
02c89b88: adrp    x0, #0x6265000                             
02c89b8c: ldr     x0, [x0, #0xb0]                            M:AdsManager/<>c__DisplayClass44_0::<ShowNativeInterBackFill>b__2
02c89b90: bl      #0x2b70db0                                 fn_2b70db0
02c89b94: adrp    x0, #0x6265000                             
02c89b98: ldr     x0, [x0, #0xa0]                            T:AdsManager/<>c__DisplayClass44_0
02c89b9c: bl      #0x2b70db0                                 fn_2b70db0
02c89ba0: adrp    x0, #0x6265000                             
02c89ba4: ldr     x0, [x0, #0x80]                            S:'af_inters_load_fail'
02c89ba8: bl      #0x2b70db0                                 fn_2b70db0
02c89bac: adrp    x0, #0x6265000                             
02c89bb0: ldr     x0, [x0, #0x88]                            S:'dev log AdsManager show native fullscreen before inter max'
02c89bb4: bl      #0x2b70db0                                 fn_2b70db0
02c89bb8: adrp    x0, #0x6265000                             
02c89bbc: ldr     x0, [x0, #0x90]                            S:'af_inters_available'
02c89bc0: bl      #0x2b70db0                                 fn_2b70db0
02c89bc4: adrp    x0, #0x6265000                             
02c89bc8: ldr     x0, [x0, #0x98]                            S:'[Inter] show failed'
02c89bcc: bl      #0x2b70db0                                 fn_2b70db0
02c89bd0: mov     w8, #1                                     
02c89bd4: strb    w8, [x21, #0x96d]                          
02c89bd8: ldr     x0, [x23]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c89bdc: bl      #0x2b7104c                                 fn_2b7104c
02c89be0: mov     x1, xzr                                    
02c89be4: mov     x21, x0                                    
02c89be8: bl      #0x4e53e9c                                 System.Object::.ctor
02c89bec: cbz     x21, #0x2c89e2c                            
02c89bf0: mov     x0, x21                                    
02c89bf4: mov     x1, x19                                    
02c89bf8: str     x19, [x0, #0x10]!                          
02c89bfc: bl      #0x2b70d54                                 fn_2b70d54
02c89c00: mov     x23, x21                                   
02c89c04: mov     x1, x22                                    
02c89c08: str     x22, [x23, #0x18]!                         
02c89c0c: mov     x0, x23                                    
02c89c10: bl      #0x2b70d54                                 fn_2b70d54
02c89c14: mov     x0, x19                                    
02c89c18: bl      #0x2c894dc                                 AdsManager::get_CanShowInter
02c89c1c: tbz     w0, #0, #0x2c89d2c                         
02c89c20: mov     x0, xzr                                    
02c89c24: bl      #0x5adf0d0                                 UnityEngine.AudioListener::get_pause
02c89c28: and     w8, w0, #1                                 
02c89c2c: mov     w0, #1                                     
02c89c30: mov     x1, xzr                                    
02c89c34: strb    w8, [x21, #0x20]                           ._applonvinManager
02c89c38: bl      #0x5adf0f8                                 UnityEngine.AudioListener::set_pause
02c89c3c: adrp    x22, #0x6264000                            
02c89c40: ldr     x22, [x22, #0xfc0]                         T:RemoteConfigManager
02c89c44: ldr     x0, [x22]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c89c48: ldr     w8, [x0, #0xe4]                            [62650e4]=0 f=0,0
02c89c4c: cbnz    w8, #0x2c89c54                             
02c89c50: bl      #0x2b70f30                                 fn_2b70f30
02c89c54: adrp    x23, #0x662f000                            
02c89c58: ldrb    w8, [x23, #0xa7c]                          
02c89c5c: cbnz    w8, #0x2c89c74                             
02c89c60: adrp    x0, #0x6264000                             
02c89c64: ldr     x0, [x0, #0xfc0]                           T:RemoteConfigManager
02c89c68: bl      #0x2b70db0                                 fn_2b70db0
02c89c6c: mov     w8, #1                                     
02c89c70: strb    w8, [x23, #0xa7c]                          
02c89c74: ldr     x0, [x22]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c89c78: ldr     w8, [x0, #0xe4]                            [62640e4]=0 f=0,0
02c89c7c: cbnz    w8, #0x2c89c88                             
02c89c80: bl      #0x2b70f30                                 fn_2b70f30
02c89c84: ldr     x0, [x22]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c89c88: ldr     x8, [x0, #0xb8]                            MS:DG.Tweening.Core.Extensions::SetSpecialStartupMode
02c89c8c: ldrb    w8, [x8, #0x14]                            
02c89c90: cbz     w8, #0x2c89d38                             
02c89c94: ldr     x0, [x19, #0x28]                           ._googleMobileAdsManager
02c89c98: cbz     x0, #0x2c89e2c                             
02c89c9c: bl      #0x2c8a26c                                 GoogleMobileAdsManager::get_IsNativeInterReady
02c89ca0: tbz     w0, #0, #0x2c89d38                         
02c89ca4: adrp    x8, #0x6263000                             
02c89ca8: ldr     x8, [x8, #0x928]                           T:UnityEngine.Debug
02c89cac: ldr     x0, [x8]                                   &2c5bbd4(=a9bd7bfdd503233f)
02c89cb0: ldr     w8, [x0, #0xe4]                            [62640e4]=0 f=0,0
02c89cb4: cbnz    w8, #0x2c89cbc                             
02c89cb8: bl      #0x2b70f30                                 fn_2b70f30
02c89cbc: adrp    x8, #0x6265000                             
02c89cc0: mov     x1, xzr                                    
02c89cc4: ldr     x8, [x8, #0x88]                            S:'dev log AdsManager show native fullscreen before inter max'
02c89cc8: ldr     x0, [x8]                                   M:AdsManager::<OnApplicationPause>b__26_0
02c89ccc: bl      #0x5af21f4                                 UnityEngine.Debug::Log
02c89cd0: mov     x0, x19                                    
02c89cd4: bl      #0x2c88f94                                 AdsManager::HideAdResume
02c89cd8: adrp    x8, #0x6264000                             
02c89cdc: mov     w9, #1                                     
02c89ce0: ldr     x8, [x8, #0xf90]                           T:System.Action
02c89ce4: ldr     x20, [x19, #0x28]                          ._googleMobileAdsManager
02c89ce8: strb    w9, [x19, #0x4b]                           ._isShowingInter
02c89cec: ldr     x0, [x8]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c89cf0: bl      #0x2b7104c                                 fn_2b7104c
02c89cf4: adrp    x8, #0x6265000                             
02c89cf8: mov     x1, x21                                    
02c89cfc: mov     x3, xzr                                    
02c89d00: ldr     x8, [x8, #0xa8]                            M:AdsManager/<>c__DisplayClass44_0::<ShowNativeInterBackFill>b__1
02c89d04: mov     x19, x0                                    
02c89d08: ldr     x2, [x8]                                   M:AdsManager::<OnApplicationPause>b__26_0
02c89d0c: bl      #0x4d8ddbc                                 System.Action::.ctor
02c89d10: cbz     x20, #0x2c89e2c                            
02c89d14: mov     x0, x20                                    
02c89d18: mov     x2, x19                                    
02c89d1c: ldp     x20, x19, [sp, #0x20]                      
02c89d20: ldp     x22, x21, [sp, #0x10]                      
02c89d24: ldp     x30, x23, [sp], #0x30                      
02c89d28: b       #0x2c8a174                                 GoogleMobileAdsManager::ShowNativeInter
02c89d2c: ldr     x8, [x23]                                  &2b706c4(=eb01011ff9400808)
02c89d30: cbnz    x8, #0x2c89e10                             
02c89d34: b       #0x2c89e2c                                 
02c89d38: mov     x0, x19                                    
02c89d3c: bl      #0x2c88f94                                 AdsManager::HideAdResume
02c89d40: ldr     x8, [x19, #0x20]                           ._applonvinManager
02c89d44: cbz     x8, #0x2c89e2c                             
02c89d48: ldr     x8, [x8, #0x20]                            S:'dev log AdsManager show app open ad'
02c89d4c: cbz     x8, #0x2c89e2c                             
02c89d50: bl      #0x2c8c8c8                                 InterApplovinControl::IsAdReady
02c89d54: tbz     w0, #0, #0x2c89dd4                         
02c89d58: adrp    x8, #0x6265000                             
02c89d5c: mov     x1, xzr                                    
02c89d60: ldr     x8, [x8, #0x90]                            S:'af_inters_available'
02c89d64: ldr     x0, [x8]                                   M:AdsManager::<OnApplicationPause>b__26_0
02c89d68: bl      #0x2c89794                                 AnalyticsManager::LogAppsflyerEvent
02c89d6c: adrp    x9, #0x6264000                             
02c89d70: ldr     w8, [x19, #0x58]                           ._interMaxShownCount
02c89d74: mov     w10, #1                                    
02c89d78: ldr     x9, [x9, #0xf90]                           T:System.Action
02c89d7c: ldr     x22, [x19, #0x20]                          ._applonvinManager
02c89d80: strb    w10, [x19, #0x4b]                          ._isShowingInter
02c89d84: add     w8, w8, #1                                 
02c89d88: ldr     x0, [x9]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c89d8c: str     w8, [x19, #0x58]                           ._interMaxShownCount
02c89d90: bl      #0x2b7104c                                 fn_2b7104c
02c89d94: adrp    x8, #0x6265000                             
02c89d98: mov     x1, x21                                    
02c89d9c: mov     x3, xzr                                    
02c89da0: ldr     x8, [x8, #0xb0]                            M:AdsManager/<>c__DisplayClass44_0::<ShowNativeInterBackFill>b__2
02c89da4: mov     x19, x0                                    
02c89da8: ldr     x2, [x8]                                   M:AdsManager::<OnApplicationPause>b__26_0
02c89dac: bl      #0x4d8ddbc                                 System.Action::.ctor
02c89db0: cbz     x22, #0x2c89e2c                            
02c89db4: ldr     x0, [x22, #0x20]                           T:DG.Tweening.DOTweenModulePhysics/<>c__DisplayClass0_0
02c89db8: cbz     x0, #0x2c89e2c                             
02c89dbc: mov     x1, x20                                    
02c89dc0: mov     x2, x19                                    
02c89dc4: ldp     x20, x19, [sp, #0x20]                      
02c89dc8: ldp     x22, x21, [sp, #0x10]                      
02c89dcc: ldp     x30, x23, [sp], #0x30                      
02c89dd0: b       #0x2c8cba4                                 InterApplovinControl::ShowAd
02c89dd4: adrp    x8, #0x6265000                             
02c89dd8: mov     x1, xzr                                    
02c89ddc: ldr     x8, [x8, #0x80]                            S:'af_inters_load_fail'
02c89de0: ldr     x0, [x8]                                   M:AdsManager::<OnApplicationPause>b__26_0
02c89de4: bl      #0x2c89794                                 AnalyticsManager::LogAppsflyerEvent
02c89de8: adrp    x8, #0x6265000                             
02c89dec: mov     x1, xzr                                    
02c89df0: ldr     x8, [x8, #0x98]                            S:'[Inter] show failed'
02c89df4: ldr     x0, [x8]                                   M:AdsManager::<OnApplicationPause>b__26_0
02c89df8: bl      #0x2ca09f8                                 WLog::LogError
02c89dfc: ldrb    w0, [x21, #0x20]                           ._applonvinManager
02c89e00: mov     x1, xzr                                    
02c89e04: bl      #0x5adf0f8                                 UnityEngine.AudioListener::set_pause
02c89e08: ldr     x8, [x21, #0x18]                           [662f018]=6000014 f=2.40742e-35,0
02c89e0c: cbz     x8, #0x2c89e2c                             
02c89e10: ldp     x20, x19, [sp, #0x20]                      
02c89e14: ldr     x0, [x8, #0x40]                            S:'done_ad'
02c89e18: ldp     x22, x21, [sp, #0x10]                      
02c89e1c: ldr     x1, [x8, #0x28]                            T:AdsManager/<ISetAOAInterval>d__33
02c89e20: ldr     x2, [x8, #0x18]                            T:AdsManager/<IEHideAdResume>d__30
02c89e24: ldp     x30, x23, [sp], #0x30                      
02c89e28: br      x2                                         
02c89e2c: bl      #0x2b7105c                                 fn_2b7105c
## ISetInterCapping(float time) -> System.Collections.IEnumerator
---- AdsManager::ISetInterCapping 0x2c8961c
02c8961c: str     d8, [sp, #-0x30]!                          
02c89620: stp     x30, x21, [sp, #0x10]                      
02c89624: stp     x20, x19, [sp, #0x20]                      
02c89628: fmov    s8, s0                                     
02c8962c: adrp    x20, #0x662f000                            
02c89630: adrp    x21, #0x6265000                            
02c89634: ldrb    w8, [x20, #0x96e]                          
02c89638: ldr     x21, [x21, #0x48]                          T:AdsManager/<ISetInterCapping>d__45 ._isRemoveAd
02c8963c: mov     x19, x0                                    
02c89640: tbnz    w8, #0, #0x2c89658                         
02c89644: adrp    x0, #0x6265000                             
02c89648: ldr     x0, [x0, #0x48]                            T:AdsManager/<ISetInterCapping>d__45 ._isRemoveAd
02c8964c: bl      #0x2b70db0                                 fn_2b70db0
02c89650: mov     w8, #1                                     
02c89654: strb    w8, [x20, #0x96e]                          
02c89658: ldr     x0, [x21]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c8965c: bl      #0x2b7104c                                 fn_2b7104c
02c89660: mov     x1, xzr                                    
02c89664: mov     x20, x0                                    
02c89668: bl      #0x4e53e9c                                 System.Object::.ctor
02c8966c: mov     x0, x20                                    
02c89670: mov     x1, x19                                    
02c89674: str     wzr, [x20, #0x10]                          
02c89678: str     x19, [x0, #0x20]!                          ._applonvinManager
02c8967c: bl      #0x2b70d54                                 fn_2b70d54
02c89680: mov     x0, x20                                    
02c89684: str     s8, [x20, #0x28]                           ._googleMobileAdsManager
02c89688: ldp     x20, x19, [sp, #0x20]                      
02c8968c: ldp     x30, x21, [sp, #0x10]                      
02c89690: ldr     d8, [sp], #0x30                            
02c89694: ret                                                
## ShowRewarded(string placment, System.Action action) -> void
---- AdsManager::ShowRewarded 0x2c8a2c0
02c8a2c0: stp     x30, x25, [sp, #-0x40]!                    
02c8a2c4: stp     x24, x23, [sp, #0x10]                      
02c8a2c8: stp     x22, x21, [sp, #0x20]                      
02c8a2cc: stp     x20, x19, [sp, #0x30]                      
02c8a2d0: adrp    x21, #0x662f000                            
02c8a2d4: adrp    x23, #0x6265000                            
02c8a2d8: mov     x22, x2                                    
02c8a2dc: ldrb    w8, [x21, #0x96f]                          
02c8a2e0: ldr     x23, [x23, #0xf8]                          T:AdsManager/<>c__DisplayClass46_0
02c8a2e4: mov     x19, x1                                    
02c8a2e8: mov     x20, x0                                    
02c8a2ec: tbnz    w8, #0, #0x2c8a358                         
02c8a2f0: adrp    x0, #0x6264000                             
02c8a2f4: ldr     x0, [x0, #0xf90]                           T:System.Action
02c8a2f8: bl      #0x2b70db0                                 fn_2b70db0
02c8a2fc: adrp    x0, #0x6263000                             
02c8a300: ldr     x0, [x0, #0x928]                           T:UnityEngine.Debug
02c8a304: bl      #0x2b70db0                                 fn_2b70db0
02c8a308: adrp    x0, #0x6265000                             
02c8a30c: ldr     x0, [x0, #0x100]                           M:AdsManager/<>c__DisplayClass46_0::<ShowRewarded>b__0
02c8a310: bl      #0x2b70db0                                 fn_2b70db0
02c8a314: adrp    x0, #0x6265000                             
02c8a318: ldr     x0, [x0, #0xf8]                            T:AdsManager/<>c__DisplayClass46_0
02c8a31c: bl      #0x2b70db0                                 fn_2b70db0
02c8a320: adrp    x0, #0x6265000                             
02c8a324: ldr     x0, [x0, #0x108]                           S:'af_rewarded_load_fail'
02c8a328: bl      #0x2b70db0                                 fn_2b70db0
02c8a32c: adrp    x0, #0x6265000                             
02c8a330: ldr     x0, [x0, #0x110]                           S:'af_rewarded_call_show'
02c8a334: bl      #0x2b70db0                                 fn_2b70db0
02c8a338: adrp    x0, #0x6265000                             
02c8a33c: ldr     x0, [x0, #0x118]                           S:'dev log AdsManager show rewarded'
02c8a340: bl      #0x2b70db0                                 fn_2b70db0
02c8a344: adrp    x0, #0x6265000                             
02c8a348: ldr     x0, [x0, #0x120]                           S:'af_rewarded_available'
02c8a34c: bl      #0x2b70db0                                 fn_2b70db0
02c8a350: mov     w8, #1                                     
02c8a354: strb    w8, [x21, #0x96f]                          
02c8a358: ldr     x0, [x23]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c8a35c: bl      #0x2b7104c                                 fn_2b7104c
02c8a360: mov     x1, xzr                                    
02c8a364: mov     x21, x0                                    
02c8a368: bl      #0x4e53e9c                                 System.Object::.ctor
02c8a36c: cbz     x21, #0x2c8a4b4                            
02c8a370: adrp    x25, #0x6263000                            
02c8a374: adrp    x24, #0x6265000                            
02c8a378: mov     x23, x21                                   
02c8a37c: ldr     x25, [x25, #0x928]                         T:UnityEngine.Debug
02c8a380: ldr     x24, [x24, #0x118]                         S:'dev log AdsManager show rewarded'
02c8a384: mov     x1, x22                                    
02c8a388: str     x22, [x23, #0x10]!                         
02c8a38c: mov     x0, x23                                    
02c8a390: bl      #0x2b70d54                                 fn_2b70d54
02c8a394: mov     x0, x21                                    
02c8a398: mov     x1, x20                                    
02c8a39c: str     x20, [x0, #0x18]!                          
02c8a3a0: bl      #0x2b70d54                                 fn_2b70d54
02c8a3a4: ldr     x0, [x25]                                  &2c5bbd4(=a9bd7bfdd503233f)
02c8a3a8: ldr     w8, [x0, #0xe4]                            [62650e4]=0 f=0,0
02c8a3ac: cbnz    w8, #0x2c8a3b4                             
02c8a3b0: bl      #0x2b70f30                                 fn_2b70f30
02c8a3b4: ldr     x0, [x24]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c8a3b8: mov     x1, xzr                                    
02c8a3bc: bl      #0x5af21f4                                 UnityEngine.Debug::Log
02c8a3c0: ldrb    w8, [x20, #0x30]                           ._testMode
02c8a3c4: cbz     w8, #0x2c8a3f0                             
02c8a3c8: ldr     x8, [x23]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c8a3cc: cbz     x8, #0x2c8a4b4                             
02c8a3d0: ldp     x20, x19, [sp, #0x30]                      
02c8a3d4: ldr     x0, [x8, #0x40]                            
02c8a3d8: ldp     x22, x21, [sp, #0x20]                      
02c8a3dc: ldr     x1, [x8, #0x28]                            
02c8a3e0: ldr     x2, [x8, #0x18]                            
02c8a3e4: ldp     x24, x23, [sp, #0x10]                      
02c8a3e8: ldp     x30, x25, [sp], #0x40                      
02c8a3ec: br      x2                                         
02c8a3f0: adrp    x8, #0x6265000                             
02c8a3f4: mov     x1, xzr                                    
02c8a3f8: ldr     x8, [x8, #0x110]                           S:'af_rewarded_call_show'
02c8a3fc: ldr     x0, [x8]                                   M:AdsManager::<OnApplicationPause>b__26_0
02c8a400: bl      #0x2c89794                                 AnalyticsManager::LogAppsflyerEvent
02c8a404: ldr     x8, [x20, #0x20]                           ._applonvinManager
02c8a408: cbz     x8, #0x2c8a4b4                             
02c8a40c: ldr     x8, [x8, #0x28]                            T:AdsManager/<ISetAOAInterval>d__33
02c8a410: cbz     x8, #0x2c8a4b4                             
02c8a414: bl      #0x2c8c92c                                 RewardApplovinControl::IsAdReady
02c8a418: tbz     w0, #0, #0x2c8a490                         
02c8a41c: adrp    x8, #0x6265000                             
02c8a420: mov     x1, xzr                                    
02c8a424: ldr     x8, [x8, #0x120]                           S:'af_rewarded_available'
02c8a428: ldr     x0, [x8]                                   M:AdsManager::<OnApplicationPause>b__26_0
02c8a42c: bl      #0x2c89794                                 AnalyticsManager::LogAppsflyerEvent
02c8a430: mov     x0, x20                                    
02c8a434: bl      #0x2c88f94                                 AdsManager::HideAdResume
02c8a438: adrp    x8, #0x6264000                             
02c8a43c: ldr     x8, [x8, #0xf90]                           T:System.Action
02c8a440: ldr     x22, [x20, #0x20]                          ._applonvinManager
02c8a444: ldr     x0, [x8]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c8a448: bl      #0x2b7104c                                 fn_2b7104c
02c8a44c: adrp    x8, #0x6265000                             
02c8a450: mov     x1, x21                                    
02c8a454: mov     x3, xzr                                    
02c8a458: ldr     x8, [x8, #0x100]                           M:AdsManager/<>c__DisplayClass46_0::<ShowRewarded>b__0
02c8a45c: mov     x20, x0                                    
02c8a460: ldr     x2, [x8]                                   M:AdsManager::<OnApplicationPause>b__26_0
02c8a464: bl      #0x4d8ddbc                                 System.Action::.ctor
02c8a468: cbz     x22, #0x2c8a4b4                            
02c8a46c: ldr     x0, [x22, #0x28]                           
02c8a470: cbz     x0, #0x2c8a4b4                             
02c8a474: mov     x1, x19                                    
02c8a478: mov     x2, x20                                    
02c8a47c: ldp     x20, x19, [sp, #0x30]                      
02c8a480: ldp     x22, x21, [sp, #0x20]                      
02c8a484: ldp     x24, x23, [sp, #0x10]                      
02c8a488: ldp     x30, x25, [sp], #0x40                      
02c8a48c: b       #0x2c8cc84                                 RewardApplovinControl::ShowAd
02c8a490: adrp    x8, #0x6265000                             
02c8a494: mov     x1, xzr                                    
02c8a498: ldr     x8, [x8, #0x108]                           S:'af_rewarded_load_fail'
02c8a49c: ldp     x20, x19, [sp, #0x30]                      
02c8a4a0: ldp     x22, x21, [sp, #0x20]                      
02c8a4a4: ldp     x24, x23, [sp, #0x10]                      
02c8a4a8: ldr     x0, [x8]                                   M:AdsManager::<OnApplicationPause>b__26_0
02c8a4ac: ldp     x30, x25, [sp], #0x40                      
02c8a4b0: b       #0x2c89794                                 AnalyticsManager::LogAppsflyerEvent
02c8a4b4: bl      #0x2b7105c                                 fn_2b7105c
## ShowBanner() -> void
---- AdsManager::ShowBanner 0x2c8a4e8
02c8a4e8: stp     x30, x21, [sp, #-0x20]!                    
02c8a4ec: stp     x20, x19, [sp, #0x10]                      
02c8a4f0: adrp    x21, #0x662f000                            
02c8a4f4: adrp    x20, #0x6263000                            
02c8a4f8: mov     x19, x0                                    
02c8a4fc: ldrb    w8, [x21, #0x970]                          
02c8a500: ldr     x20, [x20, #0x928]                         T:UnityEngine.Debug
02c8a504: tbnz    w8, #0, #0x2c8a54c                         
02c8a508: adrp    x0, #0x6265000                             
02c8a50c: ldr     x0, [x0, #0x128]                           M:AdsManager::<ShowBanner>b__47_0
02c8a510: bl      #0x2b70db0                                 fn_2b70db0
02c8a514: adrp    x0, #0x6263000                             
02c8a518: ldr     x0, [x0, #0x928]                           T:UnityEngine.Debug
02c8a51c: bl      #0x2b70db0                                 fn_2b70db0
02c8a520: adrp    x0, #0x6264000                             
02c8a524: ldr     x0, [x0, #0xfc0]                           T:RemoteConfigManager
02c8a528: bl      #0x2b70db0                                 fn_2b70db0
02c8a52c: adrp    x0, #0x6264000                             
02c8a530: ldr     x0, [x0, #0xe8]                            T:DG.Tweening.TweenCallback
02c8a534: bl      #0x2b70db0                                 fn_2b70db0
02c8a538: adrp    x0, #0x6265000                             
02c8a53c: ldr     x0, [x0, #0x130]                           S:'dev log AdsManager show banner'
02c8a540: bl      #0x2b70db0                                 fn_2b70db0
02c8a544: mov     w8, #1                                     
02c8a548: strb    w8, [x21, #0x970]                          
02c8a54c: ldr     x0, [x20]                                  &2c5bbd4(=a9bd7bfdd503233f)
02c8a550: adrp    x21, #0x6265000                            
02c8a554: adrp    x20, #0x6264000                            
02c8a558: ldr     x21, [x21, #0x130]                         S:'dev log AdsManager show banner'
02c8a55c: ldr     w8, [x0, #0xe4]                            [62650e4]=0 f=0,0
02c8a560: ldr     x20, [x20, #0xfc0]                         T:RemoteConfigManager
02c8a564: cbnz    w8, #0x2c8a56c                             
02c8a568: bl      #0x2b70f30                                 fn_2b70f30
02c8a56c: ldr     x0, [x21]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c8a570: mov     x1, xzr                                    
02c8a574: bl      #0x5af21f4                                 UnityEngine.Debug::Log
02c8a578: ldr     x0, [x20]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c8a57c: ldr     w8, [x0, #0xe4]                            [62650e4]=0 f=0,0
02c8a580: cbnz    w8, #0x2c8a588                             
02c8a584: bl      #0x2b70f30                                 fn_2b70f30
02c8a588: adrp    x21, #0x662f000                            
02c8a58c: ldrb    w8, [x21, #0xa7d]                          
02c8a590: cbnz    w8, #0x2c8a5a8                             
02c8a594: adrp    x0, #0x6264000                             
02c8a598: ldr     x0, [x0, #0xfc0]                           T:RemoteConfigManager
02c8a59c: bl      #0x2b70db0                                 fn_2b70db0
02c8a5a0: mov     w8, #1                                     
02c8a5a4: strb    w8, [x21, #0xa7d]                          
02c8a5a8: ldr     x0, [x20]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c8a5ac: ldr     w8, [x0, #0xe4]                            [62640e4]=0 f=0,0
02c8a5b0: cbnz    w8, #0x2c8a5bc                             
02c8a5b4: bl      #0x2b70f30                                 fn_2b70f30
02c8a5b8: ldr     x0, [x20]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c8a5bc: ldr     x8, [x0, #0xb8]                            MS:DG.Tweening.Core.Extensions::SetSpecialStartupMode
02c8a5c0: ldrb    w8, [x8, #2]                               
02c8a5c4: cbz     w8, #0x2c8a5d0                             
02c8a5c8: ldrb    w8, [x19, #0x30]                           ._testMode
02c8a5cc: cbz     w8, #0x2c8a5dc                             
02c8a5d0: ldp     x20, x19, [sp, #0x10]                      
02c8a5d4: ldp     x30, x21, [sp], #0x20                      
02c8a5d8: ret                                                
02c8a5dc: adrp    x8, #0x6264000                             
02c8a5e0: ldr     x8, [x8, #0xe8]                            T:DG.Tweening.TweenCallback
02c8a5e4: ldr     x0, [x8]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c8a5e8: bl      #0x2b7104c                                 fn_2b7104c
02c8a5ec: adrp    x8, #0x6265000                             
02c8a5f0: mov     x1, x19                                    
02c8a5f4: mov     x3, xzr                                    
02c8a5f8: ldr     x8, [x8, #0x128]                           M:AdsManager::<ShowBanner>b__47_0
02c8a5fc: mov     x20, x0                                    
02c8a600: ldr     x2, [x8]                                   M:AdsManager::<OnApplicationPause>b__26_0
02c8a604: bl      #0x2d89dc4                                 DG.Tweening.TweenCallback::.ctor
02c8a608: mov     x0, x20                                    
02c8a60c: ldp     x20, x19, [sp, #0x10]                      
02c8a610: fmov    s0, #0.50000000                            
02c8a614: mov     w1, #1                                     
02c8a618: mov     x2, xzr                                    
02c8a61c: ldp     x30, x21, [sp], #0x20                      
02c8a620: b       #0x2d8f37c                                 DG.Tweening.DOVirtual::DelayedCall
## HideBanner() -> void
---- AdsManager::HideBanner 0x2c88c70
02c88c70: stp     x30, x21, [sp, #-0x20]!                    
02c88c74: stp     x20, x19, [sp, #0x10]                      
02c88c78: adrp    x21, #0x662f000                            
02c88c7c: adrp    x20, #0x6263000                            
02c88c80: mov     x19, x0                                    
02c88c84: ldrb    w8, [x21, #0x971]                          
02c88c88: ldr     x20, [x20, #0x928]                         T:UnityEngine.Debug
02c88c8c: tbnz    w8, #0, #0x2c88cb0                         
02c88c90: adrp    x0, #0x6263000                             
02c88c94: ldr     x0, [x0, #0x928]                           T:UnityEngine.Debug
02c88c98: bl      #0x2b70db0                                 fn_2b70db0
02c88c9c: adrp    x0, #0x6264000                             
02c88ca0: ldr     x0, [x0, #0xff0]                           S:'dev log AdsManager hide banner'
02c88ca4: bl      #0x2b70db0                                 fn_2b70db0
02c88ca8: mov     w8, #1                                     
02c88cac: strb    w8, [x21, #0x971]                          
02c88cb0: ldr     x0, [x20]                                  &2c5bbd4(=a9bd7bfdd503233f)
02c88cb4: adrp    x20, #0x6264000                            
02c88cb8: ldr     w8, [x0, #0xe4]                            [62640e4]=0 f=0,0
02c88cbc: ldr     x20, [x20, #0xff0]                         S:'dev log AdsManager hide banner'
02c88cc0: cbnz    w8, #0x2c88cc8                             
02c88cc4: bl      #0x2b70f30                                 fn_2b70f30
02c88cc8: ldr     x0, [x20]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c88ccc: mov     x1, xzr                                    
02c88cd0: bl      #0x5af21f4                                 UnityEngine.Debug::Log
02c88cd4: ldr     x0, [x19, #0x28]                           ._googleMobileAdsManager
02c88cd8: cbz     x0, #0x2c88ce8                             
02c88cdc: ldp     x20, x19, [sp, #0x10]                      
02c88ce0: ldp     x30, x21, [sp], #0x20                      
02c88ce4: b       #0x2c8a624                                 GoogleMobileAdsManager::HideBanner
02c88ce8: bl      #0x2b7105c                                 fn_2b7105c
## ShowMREC(AdsPosition adsPosition) -> void
---- AdsManager::ShowMREC 0x2c8a650
02c8a650: str     x30, [sp, #-0x30]!                         
02c8a654: stp     x22, x21, [sp, #0x10]                      
02c8a658: stp     x20, x19, [sp, #0x20]                      
02c8a65c: adrp    x22, #0x662f000                            
02c8a660: adrp    x21, #0x6263000                            
02c8a664: mov     w19, w1                                    
02c8a668: ldrb    w8, [x22, #0x972]                          
02c8a66c: ldr     x21, [x21, #0x928]                         T:UnityEngine.Debug
02c8a670: mov     x20, x0                                    
02c8a674: tbnz    w8, #0, #0x2c8a6a4                         
02c8a678: adrp    x0, #0x6263000                             
02c8a67c: ldr     x0, [x0, #0x928]                           T:UnityEngine.Debug
02c8a680: bl      #0x2b70db0                                 fn_2b70db0
02c8a684: adrp    x0, #0x6264000                             
02c8a688: ldr     x0, [x0, #0xfc0]                           T:RemoteConfigManager
02c8a68c: bl      #0x2b70db0                                 fn_2b70db0
02c8a690: adrp    x0, #0x6265000                             
02c8a694: ldr     x0, [x0, #0x138]                           S:'dev log AdsManager show mrec'
02c8a698: bl      #0x2b70db0                                 fn_2b70db0
02c8a69c: mov     w8, #1                                     
02c8a6a0: strb    w8, [x22, #0x972]                          
02c8a6a4: ldr     x0, [x21]                                  &2c5bbd4(=a9bd7bfdd503233f)
02c8a6a8: adrp    x22, #0x6265000                            
02c8a6ac: adrp    x21, #0x6264000                            
02c8a6b0: ldr     x22, [x22, #0x138]                         S:'dev log AdsManager show mrec'
02c8a6b4: ldr     w8, [x0, #0xe4]                            [62650e4]=0 f=0,0
02c8a6b8: ldr     x21, [x21, #0xfc0]                         T:RemoteConfigManager
02c8a6bc: cbnz    w8, #0x2c8a6c4                             
02c8a6c0: bl      #0x2b70f30                                 fn_2b70f30
02c8a6c4: ldr     x0, [x22]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c8a6c8: mov     x1, xzr                                    
02c8a6cc: bl      #0x5af21f4                                 UnityEngine.Debug::Log
02c8a6d0: ldr     x0, [x21]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c8a6d4: ldr     w8, [x0, #0xe4]                            [62650e4]=0 f=0,0
02c8a6d8: cbnz    w8, #0x2c8a6e0                             
02c8a6dc: bl      #0x2b70f30                                 fn_2b70f30
02c8a6e0: adrp    x22, #0x662f000                            
02c8a6e4: ldrb    w8, [x22, #0xa7e]                          
02c8a6e8: cbnz    w8, #0x2c8a700                             
02c8a6ec: adrp    x0, #0x6264000                             
02c8a6f0: ldr     x0, [x0, #0xfc0]                           T:RemoteConfigManager
02c8a6f4: bl      #0x2b70db0                                 fn_2b70db0
02c8a6f8: mov     w8, #1                                     
02c8a6fc: strb    w8, [x22, #0xa7e]                          
02c8a700: ldr     x0, [x21]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c8a704: ldr     w8, [x0, #0xe4]                            [62640e4]=0 f=0,0
02c8a708: cbnz    w8, #0x2c8a714                             
02c8a70c: bl      #0x2b70f30                                 fn_2b70f30
02c8a710: ldr     x0, [x21]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c8a714: ldr     x8, [x0, #0xb8]                            MS:DG.Tweening.Core.Extensions::SetSpecialStartupMode
02c8a718: ldrb    w8, [x8, #1]                               
02c8a71c: cbz     w8, #0x2c8a728                             
02c8a720: ldrb    w8, [x20, #0x30]                           ._testMode
02c8a724: cbz     w8, #0x2c8a738                             
02c8a728: ldp     x20, x19, [sp, #0x20]                      
02c8a72c: ldp     x22, x21, [sp, #0x10]                      
02c8a730: ldr     x30, [sp], #0x30                           
02c8a734: ret                                                
02c8a738: mov     x0, x20                                    
02c8a73c: bl      #0x2c88f70                                 AdsManager::HideCollap
02c8a740: mov     x0, x20                                    
02c8a744: cbz     w19, #0x2c8a750                            
02c8a748: bl      #0x2c8a4e8                                 AdsManager::ShowBanner
02c8a74c: b       #0x2c8a754                                 
02c8a750: bl      #0x2c88c70                                 AdsManager::HideBanner
02c8a754: ldr     x8, [x20, #0x20]                           ._applonvinManager
02c8a758: cbz     x8, #0x2c8a778                             
02c8a75c: ldr     x0, [x8, #0x38]                            
02c8a760: cbz     x0, #0x2c8a778                             
02c8a764: mov     w1, w19                                    
02c8a768: ldp     x20, x19, [sp, #0x20]                      
02c8a76c: ldp     x22, x21, [sp, #0x10]                      
02c8a770: ldr     x30, [sp], #0x30                           
02c8a774: b       #0x2c8ceb0                                 MrecApplovinControl::ShowAd
02c8a778: bl      #0x2b7105c                                 fn_2b7105c
## HideMREC() -> void
---- AdsManager::HideMREC 0x2c88cec
02c88cec: stp     x30, x21, [sp, #-0x20]!                    
02c88cf0: stp     x20, x19, [sp, #0x10]                      
02c88cf4: adrp    x21, #0x662f000                            
02c88cf8: adrp    x20, #0x6263000                            
02c88cfc: mov     x19, x0                                    
02c88d00: ldrb    w8, [x21, #0x973]                          
02c88d04: ldr     x20, [x20, #0x928]                         T:UnityEngine.Debug
02c88d08: tbnz    w8, #0, #0x2c88d2c                         
02c88d0c: adrp    x0, #0x6263000                             
02c88d10: ldr     x0, [x0, #0x928]                           T:UnityEngine.Debug
02c88d14: bl      #0x2b70db0                                 fn_2b70db0
02c88d18: adrp    x0, #0x6264000                             
02c88d1c: ldr     x0, [x0, #0xff8]                           S:'dev log AdsManager hide mrec'
02c88d20: bl      #0x2b70db0                                 fn_2b70db0
02c88d24: mov     w8, #1                                     
02c88d28: strb    w8, [x21, #0x973]                          
02c88d2c: ldr     x0, [x20]                                  &2c5bbd4(=a9bd7bfdd503233f)
02c88d30: adrp    x20, #0x6264000                            
02c88d34: ldr     w8, [x0, #0xe4]                            [62640e4]=0 f=0,0
02c88d38: ldr     x20, [x20, #0xff8]                         S:'dev log AdsManager hide mrec'
02c88d3c: cbnz    w8, #0x2c88d44                             
02c88d40: bl      #0x2b70f30                                 fn_2b70f30
02c88d44: ldr     x0, [x20]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c88d48: mov     x1, xzr                                    
02c88d4c: bl      #0x5af21f4                                 UnityEngine.Debug::Log
02c88d50: ldr     x8, [x19, #0x20]                           ._applonvinManager
02c88d54: cbz     x8, #0x2c88d6c                             
02c88d58: ldr     x8, [x8, #0x38]                            
02c88d5c: cbz     x8, #0x2c88d6c                             
02c88d60: ldp     x20, x19, [sp, #0x10]                      
02c88d64: ldp     x30, x21, [sp], #0x20                      
02c88d68: b       #0x2c8cfb4                                 MrecApplovinControl::HideAd
02c88d6c: bl      #0x2b7105c                                 fn_2b7105c
## ShowCollap() -> void
---- AdsManager::ShowCollap 0x2c8a7a4
02c8a7a4: stp     x30, x19, [sp, #-0x10]!                    
02c8a7a8: mov     x19, x0                                    
02c8a7ac: ldr     x0, [x0, #0x28]                            ._googleMobileAdsManager
02c8a7b0: cbz     x0, #0x2c8a7dc                             
02c8a7b4: bl      #0x2c8a7e0                                 GoogleMobileAdsManager::get_IsCollapShowing
02c8a7b8: tbz     w0, #0, #0x2c8a7c4                         
02c8a7bc: ldp     x30, x19, [sp], #0x10                      
02c8a7c0: ret                                                
02c8a7c4: mov     x0, x19                                    
02c8a7c8: bl      #0x2c88cec                                 AdsManager::HideMREC
02c8a7cc: ldr     x0, [x19, #0x28]                           ._googleMobileAdsManager
02c8a7d0: cbz     x0, #0x2c8a7dc                             
02c8a7d4: ldp     x30, x19, [sp], #0x10                      
02c8a7d8: b       #0x2c8a818                                 GoogleMobileAdsManager::ShowCollap
02c8a7dc: bl      #0x2b7105c                                 fn_2b7105c
## HideCollap() -> void
---- AdsManager::HideCollap 0x2c88f70
02c88f70: ldr     x0, [x0, #0x28]                            ._googleMobileAdsManager
02c88f74: cbz     x0, #0x2c88f80                             
02c88f78: mov     x1, xzr                                    
02c88f7c: b       #0x2c8a920                                 GoogleMobileAdsManager::HideCollap
02c88f80: str     x30, [sp, #-0x10]!                         
02c88f84: bl      #0x2b7105c                                 fn_2b7105c
## .ctor() -> void
---- AdsManager::.ctor 0x2c8a960
02c8a960: stp     x30, x21, [sp, #-0x20]!                    
02c8a964: stp     x20, x19, [sp, #0x10]                      
02c8a968: adrp    x21, #0x662f000                            
02c8a96c: adrp    x20, #0x6265000                            
02c8a970: mov     x19, x0                                    
02c8a974: ldrb    w8, [x21, #0x974]                          
02c8a978: ldr     x20, [x20, #0x148]                         MS:WejoyService.Singleton`1::.ctor
02c8a97c: tbnz    w8, #0, #0x2c8a994                         
02c8a980: adrp    x0, #0x6265000                             
02c8a984: ldr     x0, [x0, #0x148]                           MS:WejoyService.Singleton`1::.ctor
02c8a988: bl      #0x2b70db0                                 fn_2b70db0
02c8a98c: mov     w8, #1                                     
02c8a990: strb    w8, [x21, #0x974]                          
02c8a994: mov     w8, #0x41a00000                            
02c8a998: ldr     x1, [x20]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c8a99c: mov     x0, x19                                    
02c8a9a0: str     w8, [x19, #0x34]                           ._consentTimeout
02c8a9a4: mov     w8, #1                                     
02c8a9a8: strb    w8, [x19, #0x49]                           ._isDoneAOAInterval
02c8a9ac: ldp     x20, x19, [sp, #0x10]                      
02c8a9b0: ldp     x30, x21, [sp], #0x20                      
02c8a9b4: b       #0x3be76dc                                 
## <OnApplicationPause>b__26_0() -> void
---- AdsManager::<OnApplicationPause>b__26_0 0x2c8a9b8
02c8a9b8: b       #0x2c88c70                                 AdsManager::HideBanner
## <OnApplicationPause>b__26_1() -> void
---- AdsManager::<OnApplicationPause>b__26_1 0x2c8a9bc
02c8a9bc: stp     x30, x23, [sp, #-0x30]!                    
02c8a9c0: stp     x22, x21, [sp, #0x10]                      
02c8a9c4: stp     x20, x19, [sp, #0x20]                      
02c8a9c8: adrp    x22, #0x662f000                            
02c8a9cc: adrp    x23, #0x6264000                            
02c8a9d0: adrp    x20, #0x6265000                            
02c8a9d4: adrp    x21, #0x6265000                            
02c8a9d8: ldr     x23, [x23, #0xf90]                         T:System.Action
02c8a9dc: ldrb    w8, [x22, #0x975]                          
02c8a9e0: ldr     x20, [x20, #0x150]                         M:AdsManager::<OnApplicationPause>b__26_2
02c8a9e4: ldr     x21, [x21, #0x158]                         S:'resume'
02c8a9e8: mov     x19, x0                                    
02c8a9ec: tbnz    w8, #0, #0x2c8aa1c                         
02c8a9f0: adrp    x0, #0x6264000                             
02c8a9f4: ldr     x0, [x0, #0xf90]                           T:System.Action
02c8a9f8: bl      #0x2b70db0                                 fn_2b70db0
02c8a9fc: adrp    x0, #0x6265000                             
02c8aa00: ldr     x0, [x0, #0x150]                           M:AdsManager::<OnApplicationPause>b__26_2
02c8aa04: bl      #0x2b70db0                                 fn_2b70db0
02c8aa08: adrp    x0, #0x6265000                             
02c8aa0c: ldr     x0, [x0, #0x158]                           S:'resume'
02c8aa10: bl      #0x2b70db0                                 fn_2b70db0
02c8aa14: mov     w8, #1                                     
02c8aa18: strb    w8, [x22, #0x975]                          
02c8aa1c: ldr     x0, [x23]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c8aa20: bl      #0x2b7104c                                 fn_2b7104c
02c8aa24: ldr     x2, [x20]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c8aa28: mov     x1, x19                                    
02c8aa2c: mov     x3, xzr                                    
02c8aa30: mov     x20, x0                                    
02c8aa34: bl      #0x4d8ddbc                                 System.Action::.ctor
02c8aa38: ldr     x1, [x21]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c8aa3c: mov     x0, x19                                    
02c8aa40: mov     x2, x20                                    
02c8aa44: ldp     x20, x19, [sp, #0x20]                      
02c8aa48: ldp     x22, x21, [sp, #0x10]                      
02c8aa4c: ldp     x30, x23, [sp], #0x30                      
02c8aa50: b       #0x2c8907c                                 AdsManager::ShowAppOpenAd
## <OnApplicationPause>b__26_2() -> void
---- AdsManager::<OnApplicationPause>b__26_2 0x2c8aa54
02c8aa54: b       #0x2c8a4e8                                 AdsManager::ShowBanner
## <ShowBanner>b__47_0() -> void
---- AdsManager::<ShowBanner>b__47_0 0x2c8aa58
02c8aa58: ldr     x0, [x0, #0x28]                            ._googleMobileAdsManager
02c8aa5c: cbz     x0, #0x2c8aa64                             
02c8aa60: b       #0x2c8aa6c                                 GoogleMobileAdsManager::ShowBanner
02c8aa64: str     x30, [sp, #-0x10]!                         
02c8aa68: bl      #0x2b7105c                                 fn_2b7105c
