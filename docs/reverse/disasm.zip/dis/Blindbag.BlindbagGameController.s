#### CLASS Blindbag.BlindbagGameController/<BuyItemsCompletedHandler>d__28 parent= System.ValueType
#   field <>1__state                     int                                                off=0x10 attr=6 
#   field <>t__builder                   System.Runtime.CompilerServices.AsyncVoidMethodBuilder off=0x18 attr=6 
#   field <>4__this                      Blindbag.BlindbagGameController                    off=0x38 attr=6 
#   field <>u__1                         Cysharp.Threading.Tasks.UniTask/Awaiter            off=0x40 attr=1 
## MoveNext() -> void
---- Blindbag.BlindbagGameController/<BuyItemsCompletedHandler>d__28::MoveNext 0x2d52a18
02d52a18: sub     sp, sp, #0x90                              
02d52a1c: str     d8, [sp, #0x40]                            
02d52a20: stp     x30, x25, [sp, #0x50]                      
02d52a24: stp     x24, x23, [sp, #0x60]                      
02d52a28: stp     x22, x21, [sp, #0x70]                      
02d52a2c: stp     x20, x19, [sp, #0x80]                      
02d52a30: adrp    x20, #0x6630000                            
02d52a34: mov     x19, x0                                    
02d52a38: ldrb    w8, [x20, #0x264]                          
02d52a3c: tbnz    w8, #0, #0x2d52ac0                         
02d52a40: adrp    x0, #0x626b000                             
02d52a44: ldr     x0, [x0, #0x940]                           MS:System.Runtime.CompilerServices.AsyncVoidMethodBuilder::AwaitUnsafeOnCompleted
02d52a48: bl      #0x2b70db0                                 fn_2b70db0
02d52a4c: adrp    x0, #0x6263000                             
02d52a50: ldr     x0, [x0, #0x928]                           T:UnityEngine.Debug
02d52a54: bl      #0x2b70db0                                 fn_2b70db0
02d52a58: adrp    x0, #0x6265000                             
02d52a5c: ldr     x0, [x0, #0xb38]                           T:DevTrack
02d52a60: bl      #0x2b70db0                                 fn_2b70db0
02d52a64: adrp    x0, #0x6266000                             
02d52a68: ldr     x0, [x0, #0x5e0]                           T:GameConfig
02d52a6c: bl      #0x2b70db0                                 fn_2b70db0
02d52a70: adrp    x0, #0x6266000                             
02d52a74: ldr     x0, [x0, #0xaa0]                           MS:MonoSingleton`1::get_Instance
02d52a78: bl      #0x2b70db0                                 fn_2b70db0
02d52a7c: adrp    x0, #0x6265000                             
02d52a80: ldr     x0, [x0, #0x10]                            MS:MonoSingleton`1::get_Instance .<>1__state
02d52a84: bl      #0x2b70db0                                 fn_2b70db0
02d52a88: adrp    x0, #0x6266000                             
02d52a8c: ldr     x0, [x0, #0xb48]                           MS:MonoSingleton`1::get_Instance
02d52a90: bl      #0x2b70db0                                 fn_2b70db0
02d52a94: adrp    x0, #0x626b000                             
02d52a98: ldr     x0, [x0, #0x948]                           MS:UIManager::HideScreen
02d52a9c: bl      #0x2b70db0                                 fn_2b70db0
02d52aa0: adrp    x0, #0x6266000                             
02d52aa4: ldr     x0, [x0, #0xcc8]                           T:Cysharp.Threading.Tasks.UniTask
02d52aa8: bl      #0x2b70db0                                 fn_2b70db0
02d52aac: adrp    x0, #0x626b000                             
02d52ab0: ldr     x0, [x0, #0x950]                           S:'TODO buy complete handle'
02d52ab4: bl      #0x2b70db0                                 fn_2b70db0
02d52ab8: mov     w8, #1                                     
02d52abc: strb    w8, [x20, #0x264]                          
02d52ac0: ldr     w8, [x19]                                  
02d52ac4: ldr     x22, [x19, #0x28]                          
02d52ac8: stp     xzr, xzr, [sp, #0x20]                      
02d52acc: str     wzr, [sp, #0x18]                           
02d52ad0: cbz     w8, #0x2d52c24                             
02d52ad4: cbz     x22, #0x2d52f0c                            
02d52ad8: ldr     x0, [x22, #0x38]                           
02d52adc: cbz     x0, #0x2d52f10                             
02d52ae0: bl      #0x2d4f83c                                 Blindbag.Basket::GetTotalPrice
02d52ae4: adrp    x8, #0x6266000                             
02d52ae8: mov     w20, w0                                    
02d52aec: ldr     x8, [x8, #0xaa0]                           MS:MonoSingleton`1::get_Instance
02d52af0: ldr     x0, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d52af4: bl      #0x3769600                                 fn_3769600
02d52af8: cbz     x0, #0x2d52f14                             
02d52afc: neg     w1, w20                                    
02d52b00: mov     x2, xzr                                    
02d52b04: bl      #0x2cdac78                                 MoneyManager::UpdateMoney
02d52b08: mov     x0, xzr                                    
02d52b0c: bl      #0x2d6eec8                                 Framework.AudioManager::get_Instance
02d52b10: cbz     x0, #0x2d52f18                             
02d52b14: movi    d1, #0000000000000000                      
02d52b18: movi    d2, #0000000000000000                      
02d52b1c: mov     w1, #0x2f                                  
02d52b20: fmov    s0, #1.00000000                            
02d52b24: mov     w2, wzr                                    
02d52b28: mov     w3, wzr                                    
02d52b2c: mov     x4, xzr                                    
02d52b30: bl      #0x2d6f03c                                 Framework.AudioManager::PlaySound
02d52b34: adrp    x20, #0x6266000                            
02d52b38: ldr     x20, [x20, #0xcc8]                         T:Cysharp.Threading.Tasks.UniTask
02d52b3c: ldr     x0, [x20]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d52b40: ldr     w8, [x0, #0xe4]                            [626b0e4]=0 f=0,0
02d52b44: cbnz    w8, #0x2d52b4c                             
02d52b48: bl      #0x2b70f30                                 fn_2b70f30
02d52b4c: fmov    s0, #2.00000000                            
02d52b50: mov     w0, wzr                                    
02d52b54: mov     w1, #8                                     
02d52b58: mov     x2, xzr                                    
02d52b5c: mov     w3, wzr                                    
02d52b60: mov     x4, xzr                                    
02d52b64: bl      #0x5447b08                                 Cysharp.Threading.Tasks.UniTask::WaitForSeconds
02d52b68: stp     x0, x1, [sp, #0x30]                        
02d52b6c: add     x0, sp, #0x30                              
02d52b70: mov     x1, xzr                                    
02d52b74: bl      #0x2b70d54                                 fn_2b70d54
02d52b78: adrp    x21, #0x662f000                            
02d52b7c: ldr     q0, [sp, #0x30]                            
02d52b80: ldrb    w8, [x21, #0xbdc]                          
02d52b84: str     q0, [sp, #0x20]                            
02d52b88: cbnz    w8, #0x2d52ba0                             
02d52b8c: adrp    x0, #0x6266000                             
02d52b90: ldr     x0, [x0, #0xcc8]                           T:Cysharp.Threading.Tasks.UniTask
02d52b94: bl      #0x2b70db0                                 fn_2b70db0
02d52b98: mov     w8, #1                                     
02d52b9c: strb    w8, [x21, #0xbdc]                          
02d52ba0: ldr     x0, [x20]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d52ba4: ldr     w8, [x0, #0xe4]                            [62660e4]=0 f=0,0
02d52ba8: cbnz    w8, #0x2d52bb0                             
02d52bac: bl      #0x2b70f30                                 fn_2b70f30
02d52bb0: adrp    x20, #0x662f000                            
02d52bb4: ldrb    w8, [x20, #0xbdd]                          
02d52bb8: cbnz    w8, #0x2d52bd0                             
02d52bbc: adrp    x0, #0x6266000                             
02d52bc0: ldr     x0, [x0, #0xcd0]                           T:Cysharp.Threading.Tasks.IUniTaskSource
02d52bc4: bl      #0x2b70db0                                 fn_2b70db0
02d52bc8: mov     w8, #1                                     
02d52bcc: strb    w8, [x20, #0xbdd]                          
02d52bd0: ldr     x20, [sp, #0x20]                           
02d52bd4: cbz     x20, #0x2d52c5c                            
02d52bd8: adrp    x10, #0x6266000                            
02d52bdc: ldr     x8, [x20]                                  &2b706c4(=eb01011ff9400808)
02d52be0: ldr     x10, [x10, #0xcd0]                         T:Cysharp.Threading.Tasks.IUniTaskSource
02d52be4: ldrh    w21, [sp, #0x28]                           
02d52be8: ldrh    w9, [x8, #0x12e]                           
02d52bec: ldr     x1, [x10]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d52bf0: cbz     x9, #0x2d52c14                             
02d52bf4: ldr     x10, [x8, #0xb0]                           S:'native_banner_ad_on_off'
02d52bf8: add     x10, x10, #8                               &6266008
02d52bfc: ldur    x11, [x10, #-8]                            
02d52c00: cmp     x11, x1                                    
02d52c04: b.eq    #0x2d52c3c                                 
02d52c08: subs    x9, x9, #1                                 
02d52c0c: add     x10, x10, #0x10                            &6266010
02d52c10: b.ne    #0x2d52bfc                                 
02d52c14: mov     x0, x20                                    
02d52c18: mov     w2, wzr                                    
02d52c1c: bl      #0x2baa05c                                 fn_2baa05c
02d52c20: b       #0x2d52c48                                 
02d52c24: ldr     q0, [x19, #0x30]                           
02d52c28: mov     w8, #-1                                    
02d52c2c: stp     xzr, xzr, [x19, #0x30]                     
02d52c30: str     w8, [x19]                                  
02d52c34: str     q0, [sp, #0x20]                            
02d52c38: b       #0x2d52c5c                                 
02d52c3c: ldrsw   x9, [x10]                                  
02d52c40: add     x8, x8, x9, lsl #4                         &6266000
02d52c44: add     x0, x8, #0x138                             &6266138
02d52c48: ldp     x8, x2, [x0]                               
02d52c4c: mov     x0, x20                                    
02d52c50: mov     w1, w21                                    
02d52c54: blr     x8                                         
02d52c58: cbz     w0, #0x2d52eac                             
02d52c5c: adrp    x20, #0x662f000                            
02d52c60: ldrb    w8, [x20, #0xbde]                          
02d52c64: cbnz    w8, #0x2d52c7c                             
02d52c68: adrp    x0, #0x6266000                             
02d52c6c: ldr     x0, [x0, #0xcd0]                           T:Cysharp.Threading.Tasks.IUniTaskSource
02d52c70: bl      #0x2b70db0                                 fn_2b70db0
02d52c74: mov     w8, #1                                     
02d52c78: strb    w8, [x20, #0xbde]                          
02d52c7c: ldr     x20, [sp, #0x20]                           
02d52c80: cbz     x20, #0x2d52cf0                            
02d52c84: adrp    x10, #0x6266000                            
02d52c88: ldr     x8, [x20]                                  &2b706c4(=eb01011ff9400808)
02d52c8c: ldr     x10, [x10, #0xcd0]                         T:Cysharp.Threading.Tasks.IUniTaskSource
02d52c90: ldrh    w21, [sp, #0x28]                           
02d52c94: ldrh    w9, [x8, #0x12e]                           
02d52c98: ldr     x1, [x10]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d52c9c: cbz     x9, #0x2d52cc0                             
02d52ca0: ldr     x10, [x8, #0xb0]                           S:'native_banner_ad_on_off'
02d52ca4: add     x10, x10, #8                               &6266008
02d52ca8: ldur    x11, [x10, #-8]                            
02d52cac: cmp     x11, x1                                    
02d52cb0: b.eq    #0x2d52cd0                                 
02d52cb4: subs    x9, x9, #1                                 
02d52cb8: add     x10, x10, #0x10                            &6266010
02d52cbc: b.ne    #0x2d52ca8                                 
02d52cc0: mov     x0, x20                                    
02d52cc4: mov     w2, #2                                     
02d52cc8: bl      #0x2baa05c                                 fn_2baa05c
02d52ccc: b       #0x2d52ce0                                 
02d52cd0: ldr     w9, [x10]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d52cd4: add     w9, w9, #2                                 
02d52cd8: add     x8, x8, w9, sxtw #4                        &6266000
02d52cdc: add     x0, x8, #0x138                             &6266138
02d52ce0: ldp     x8, x2, [x0]                               
02d52ce4: mov     x0, x20                                    
02d52ce8: mov     w1, w21                                    
02d52cec: blr     x8                                         
02d52cf0: cbz     x22, #0x2d52ee4                            
02d52cf4: ldr     x0, [x22, #0x50]                           
02d52cf8: cbz     x0, #0x2d52ee8                             
02d52cfc: mov     w1, wzr                                    
02d52d00: bl      #0x2d5178c                                 Blindbag.ScanMachine::SetActive
02d52d04: ldr     x0, [x22, #0x70]                           
02d52d08: cbz     x0, #0x2d52eec                             
02d52d0c: adrp    x8, #0x626b000                             
02d52d10: ldr     x8, [x8, #0x948]                           MS:UIManager::HideScreen
02d52d14: ldr     x1, [x8]                                   T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d52d18: bl      #0x33fbe70                                 fn_33fbe70
02d52d1c: adrp    x8, #0x6263000                             
02d52d20: ldr     x8, [x8, #0x928]                           T:UnityEngine.Debug
02d52d24: ldr     x0, [x8]                                   &2c5bbd4(=a9bd7bfdd503233f)
02d52d28: ldr     w8, [x0, #0xe4]                            [62660e4]=0 f=0,0
02d52d2c: cbnz    w8, #0x2d52d34                             
02d52d30: bl      #0x2b70f30                                 fn_2b70f30
02d52d34: adrp    x8, #0x626b000                             
02d52d38: ldr     x8, [x8, #0x950]                           S:'TODO buy complete handle'
02d52d3c: ldr     x0, [x8]                                   T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d52d40: mov     x1, xzr                                    
02d52d44: bl      #0x5af21f4                                 UnityEngine.Debug::Log
02d52d48: adrp    x8, #0x6265000                             
02d52d4c: ldr     x8, [x8, #0x10]                            MS:MonoSingleton`1::get_Instance
02d52d50: ldr     x0, [x8]                                   M:AdsManager::<OnApplicationPause>b__26_0
02d52d54: bl      #0x3769600                                 fn_3769600
02d52d58: adrp    x21, #0x6266000                            
02d52d5c: mov     x20, x0                                    
02d52d60: ldr     x21, [x21, #0x5e0]                         T:GameConfig
02d52d64: ldr     x0, [x21]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d52d68: ldr     w8, [x0, #0xe4]                            [62660e4]=0 f=0,0
02d52d6c: cbnz    w8, #0x2d52d74                             
02d52d70: bl      #0x2b70f30                                 fn_2b70f30
02d52d74: cbz     x20, #0x2d52ef0                            
02d52d78: ldr     x8, [x21]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d52d7c: ldr     x8, [x8, #0xb8]                            T:AdsManager/<>c__DisplayClass42_0
02d52d80: ldr     x1, [x8, #0x20]                            S:'dev log AdsManager show app open ad'
02d52d84: mov     x0, x20                                    
02d52d88: mov     w2, wzr                                    
02d52d8c: mov     x3, xzr                                    
02d52d90: bl      #0x2ce9e58                                 SimpleSceneTransition::FlashIn
02d52d94: adrp    x24, #0x6266000                            
02d52d98: ldr     x24, [x24, #0xb48]                         MS:MonoSingleton`1::get_Instance
02d52d9c: ldr     x0, [x24]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d52da0: bl      #0x3769600                                 fn_3769600
02d52da4: cbz     x0, #0x2d52ef4                             
02d52da8: ldr     x20, [x0, #0x30]                           S:'popup_rate_on_off'
02d52dac: ldr     x0, [x24]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d52db0: bl      #0x3769600                                 fn_3769600
02d52db4: mov     x8, x0                                     
02d52db8: cbz     x0, #0x2d52ef8                             
02d52dbc: adrp    x25, #0x6265000                            
02d52dc0: ldr     x25, [x25, #0xb38]                         T:DevTrack
02d52dc4: ldr     w21, [x8, #0x3c]                           [626503c]=0 f=0,0
02d52dc8: ldr     x0, [x25]                                  M:AdsManager::<OnApplicationPause>b__26_0
02d52dcc: ldr     w9, [x0, #0xe4]                            [62660e4]=0 f=0,0
02d52dd0: cbnz    w9, #0x2d52ddc                             
02d52dd4: bl      #0x2b70f30                                 fn_2b70f30
02d52dd8: ldr     x0, [x25]                                  M:AdsManager::<OnApplicationPause>b__26_0
02d52ddc: ldr     x8, [x0, #0xb8]                            S:'banner_native_refresh_time'
02d52de0: ldr     x22, [x8, #0x2b0]                          S:'currency'
02d52de4: ldr     w23, [x8, #0x2d8]                          MS:System.Collections.Generic.Dictionary`2::Add
02d52de8: mov     x0, xzr                                    
02d52dec: bl      #0x5b432fc                                 UnityEngine.Time::get_time
02d52df0: fmov    s8, s0                                     
02d52df4: ldr     x0, [x24]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d52df8: bl      #0x3769600                                 fn_3769600
02d52dfc: cbz     x0, #0x2d52efc                             
02d52e00: ldr     s0, [x0, #0x38]                            S:'native_collap_id' .<>4__this
02d52e04: fsub    s0, s8, s0                                 
02d52e08: mov     x0, x20                                    
02d52e0c: mov     w1, w21                                    
02d52e10: mov     x2, x22                                    
02d52e14: mov     w3, w23                                    
02d52e18: mov     x4, xzr                                    
02d52e1c: bl      #0x2c9c898                                 DevTrack::GameModeStepComplete
02d52e20: ldr     x0, [x24]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d52e24: bl      #0x3769600                                 fn_3769600
02d52e28: cbz     x0, #0x2d52f00                             
02d52e2c: ldr     x20, [x0, #0x30]                           S:'popup_rate_on_off'
02d52e30: ldr     x0, [x24]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d52e34: bl      #0x3769600                                 fn_3769600
02d52e38: cbz     x0, #0x2d52f04                             
02d52e3c: ldr     x8, [x25]                                  M:AdsManager::<OnApplicationPause>b__26_0
02d52e40: ldr     w1, [x0, #0x3c]                            [626603c]=0 f=0,0
02d52e44: ldr     x8, [x8, #0xb8]                            T:AdsManager/<>c__DisplayClass42_0
02d52e48: ldr     x2, [x8, #0x2b8]                           S:'USD'
02d52e4c: ldr     w3, [x8, #0x2dc]                           [62652dc]=0 f=0,0
02d52e50: mov     x0, x20                                    
02d52e54: mov     x4, xzr                                    
02d52e58: bl      #0x2c9c714                                 DevTrack::GameModeStepEnter
02d52e5c: ldr     x0, [x24]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d52e60: bl      #0x3769600                                 fn_3769600
02d52e64: cbz     x0, #0x2d52f08                             
02d52e68: ldr     x8, [x25]                                  M:AdsManager::<OnApplicationPause>b__26_0
02d52e6c: ldr     x8, [x8, #0xb8]                            T:AdsManager/<>c__DisplayClass42_0
02d52e70: ldr     x1, [x8, #0x2b8]                           S:'USD'
02d52e74: str     x1, [x0, #0x40]!                           .<>u__1
02d52e78: bl      #0x2b70d54                                 fn_2b70d54
02d52e7c: mov     w8, #-2                                    
02d52e80: mov     x1, xzr                                    
02d52e84: str     w8, [x19], #8                              
02d52e88: mov     x0, x19                                    
02d52e8c: bl      #0x4d43b50                                 System.Runtime.CompilerServices.AsyncVoidMethodBuilder::SetResult
02d52e90: ldp     x20, x19, [sp, #0x80]                      
02d52e94: ldr     d8, [sp, #0x40]                            
02d52e98: ldp     x22, x21, [sp, #0x70]                      
02d52e9c: ldp     x24, x23, [sp, #0x60]                      
02d52ea0: ldp     x30, x25, [sp, #0x50]                      
02d52ea4: add     sp, sp, #0x90                              
02d52ea8: ret                                                
02d52eac: ldr     q0, [sp, #0x20]                            
02d52eb0: str     wzr, [x19]                                 
02d52eb4: str     q0, [x19, #0x30]                           
02d52eb8: add     x0, x19, #0x30                             
02d52ebc: mov     x1, xzr                                    
02d52ec0: bl      #0x2b70d54                                 fn_2b70d54
02d52ec4: adrp    x8, #0x626b000                             
02d52ec8: ldr     x8, [x8, #0x940]                           MS:System.Runtime.CompilerServices.AsyncVoidMethodBuilder::AwaitUnsafeOnCompleted
02d52ecc: ldr     x3, [x8]                                   T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d52ed0: add     x0, x19, #8                                
02d52ed4: add     x1, sp, #0x20                              
02d52ed8: mov     x2, x19                                    
02d52edc: bl      #0x30c2abc                                 fn_30c2abc
02d52ee0: b       #0x2d52e90                                 
02d52ee4: bl      #0x2b7105c                                 fn_2b7105c
02d52ee8: bl      #0x2b7105c                                 fn_2b7105c
02d52eec: bl      #0x2b7105c                                 fn_2b7105c
02d52ef0: bl      #0x2b7105c                                 fn_2b7105c
02d52ef4: bl      #0x2b7105c                                 fn_2b7105c
02d52ef8: bl      #0x2b7105c                                 fn_2b7105c
02d52efc: bl      #0x2b7105c                                 fn_2b7105c
02d52f00: bl      #0x2b7105c                                 fn_2b7105c
02d52f04: bl      #0x2b7105c                                 fn_2b7105c
02d52f08: bl      #0x2b7105c                                 fn_2b7105c
02d52f0c: bl      #0x2b7105c                                 fn_2b7105c
02d52f10: bl      #0x2b7105c                                 fn_2b7105c
02d52f14: bl      #0x2b7105c                                 fn_2b7105c
02d52f18: bl      #0x2b7105c                                 fn_2b7105c
02d52f1c: b       #0x2d52f98                                 
02d52f20: b       #0x2d52f98                                 
02d52f24: b       #0x2d52f98                                 
02d52f28: b       #0x2d52f98                                 
02d52f2c: b       #0x2d52f98                                 
02d52f30: b       #0x2d52f98                                 
02d52f34: b       #0x2d52f98                                 
02d52f38: b       #0x2d52f98                                 
02d52f3c: b       #0x2d52f98                                 
02d52f40: b       #0x2d52f98                                 
02d52f44: b       #0x2d52f98                                 
02d52f48: b       #0x2d52f98                                 
02d52f4c: b       #0x2d52f98                                 
02d52f50: b       #0x2d52f98                                 
02d52f54: b       #0x2d52f98                                 
02d52f58: b       #0x2d52f98                                 
02d52f5c: b       #0x2d52f98                                 
02d52f60: b       #0x2d52f98                                 
02d52f64: b       #0x2d52f98                                 
02d52f68: b       #0x2d52f98                                 
02d52f6c: b       #0x2d52f98                                 
02d52f70: mov     x20, x0                                    
02d52f74: b       #0x2d52f9c                                 
02d52f78: b       #0x2d52f98                                 
02d52f7c: b       #0x2d52f98                                 
02d52f80: b       #0x2d52f98                                 
02d52f84: b       #0x2d52f98                                 
02d52f88: b       #0x2d52f98                                 
02d52f8c: b       #0x2d52f98                                 
02d52f90: b       #0x2d52f98                                 
02d52f94: b       #0x2d52f98                                 
02d52f98: mov     x20, x0                                    
02d52f9c: cmp     w1, #1                                     
02d52fa0: b.ne    #0x2d53094                                 
02d52fa4: mov     x0, x20                                    
02d52fa8: bl      #0x5e90260                                 fn_5e90260
02d52fac: mov     x20, x0                                    
02d52fb0: adrp    x0, #0x6263000                             
02d52fb4: ldr     x0, [x0, #0xae0]                           T:System.Exception
02d52fb8: bl      #0x2b70dc4                                 fn_2b70dc4
02d52fbc: ldr     x8, [x20]                                  &2b706c4(=eb01011ff9400808)
02d52fc0: ldr     x1, [x8]                                   T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d52fc4: bl      #0x2b71464                                 fn_2b71464
02d52fc8: tbz     w0, #0, #0x2d53048                         
02d52fcc: ldrsw   x21, [sp, #0x18]                           
02d52fd0: ldr     x20, [x20]                                 &2b706c4(=eb01011ff9400808)
02d52fd4: add     x8, sp, #8                                 
02d52fd8: str     x20, [x8, x21, lsl #3]                     
02d52fdc: add     w8, w21, #1                                
02d52fe0: str     w8, [sp, #0x18]                            
02d52fe4: bl      #0x5e90270                                 fn_5e90270
02d52fe8: cbz     x20, #0x2d5306c                            
02d52fec: ldr     x8, [x20]                                  &2b706c4(=eb01011ff9400808)
02d52ff0: ldp     x9, x1, [x8, #0x188]                       
02d52ff4: mov     x0, x20                                    
02d52ff8: blr     x9                                         
02d52ffc: mov     x20, x0                                    
02d53000: adrp    x0, #0x626b000                             
02d53004: ldr     x0, [x0, #0x958]                           S:'ex :'
02d53008: bl      #0x2b70dc4                                 fn_2b70dc4
02d5300c: mov     x1, x20                                    
02d53010: mov     x2, xzr                                    
02d53014: bl      #0x4c9c514                                 System.String::Concat
02d53018: mov     x20, x0                                    
02d5301c: adrp    x0, #0x6263000                             
02d53020: ldr     x0, [x0, #0x928]                           T:UnityEngine.Debug
02d53024: bl      #0x2b70dc4                                 fn_2b70dc4
02d53028: ldr     w8, [x0, #0xe4]                            [62630e4]=0 f=0,0
02d5302c: cbnz    w8, #0x2d53034                             
02d53030: bl      #0x2b70f30                                 fn_2b70f30
02d53034: mov     x0, x20                                    
02d53038: mov     x1, xzr                                    
02d5303c: bl      #0x5af2840                                 UnityEngine.Debug::LogError
02d53040: str     w21, [sp, #0x18]                           
02d53044: b       #0x2d52e7c                                 
02d53048: mov     w0, #8                                     
02d5304c: bl      #0x5e90290                                 fn_5e90290
02d53050: ldr     x8, [x20]                                  &2b706c4(=eb01011ff9400808)
02d53054: str     x8, [x0]                                   
02d53058: adrp    x1, #0x5e96000                             
02d5305c: add     x1, x1, #0x758                             &5e96758
02d53060: mov     x2, xzr                                    
02d53064: bl      #0x5e902a0                                 fn_5e902a0
02d53068: b       #0x2d53124                                 
02d5306c: bl      #0x2b7105c                                 fn_2b7105c
02d53070: b       #0x2d53090                                 
02d53074: b       #0x2d53090                                 
02d53078: b       #0x2d53090                                 
02d5307c: mov     x21, x1                                    
02d53080: mov     x20, x0                                    
02d53084: bl      #0x5e90270                                 fn_5e90270
02d53088: mov     w1, w21                                    
02d5308c: b       #0x2d53094                                 
02d53090: mov     x20, x0                                    
02d53094: mov     w8, #1                                     
02d53098: cmp     w1, w8                                     
02d5309c: b.ne    #0x2d5312c                                 
02d530a0: mov     x0, x20                                    
02d530a4: bl      #0x5e90260                                 fn_5e90260
02d530a8: mov     x20, x0                                    
02d530ac: adrp    x0, #0x6263000                             
02d530b0: ldr     x0, [x0, #0xae0]                           T:System.Exception
02d530b4: bl      #0x2b70dc4                                 fn_2b70dc4
02d530b8: ldr     x8, [x20]                                  &2b706c4(=eb01011ff9400808)
02d530bc: ldr     x1, [x8]                                   T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d530c0: bl      #0x2b71464                                 fn_2b71464
02d530c4: tbz     w0, #0, #0x2d53104                         
02d530c8: ldrsw   x21, [sp, #0x18]                           
02d530cc: ldr     x20, [x20]                                 &2b706c4(=eb01011ff9400808)
02d530d0: add     x8, sp, #8                                 
02d530d4: str     x20, [x8, x21, lsl #3]                     
02d530d8: add     w8, w21, #1                                
02d530dc: str     w8, [sp, #0x18]                            
02d530e0: bl      #0x5e90270                                 fn_5e90270
02d530e4: mov     w8, #-2                                    
02d530e8: mov     x1, x20                                    
02d530ec: mov     x2, xzr                                    
02d530f0: str     w8, [x19], #8                              
02d530f4: mov     x0, x19                                    
02d530f8: bl      #0x4d43cc0                                 System.Runtime.CompilerServices.AsyncVoidMethodBuilder::SetException
02d530fc: str     w21, [sp, #0x18]                           
02d53100: b       #0x2d52e90                                 
02d53104: mov     w0, #8                                     
02d53108: bl      #0x5e90290                                 fn_5e90290
02d5310c: ldr     x8, [x20]                                  &2b706c4(=eb01011ff9400808)
02d53110: str     x8, [x0]                                   
02d53114: adrp    x1, #0x5e96000                             
02d53118: add     x1, x1, #0x758                             &5e96758
02d5311c: mov     x2, xzr                                    
02d53120: bl      #0x5e902a0                                 fn_5e902a0
02d53124: mov     x20, x0                                    
02d53128: bl      #0x5e90270                                 fn_5e90270
02d5312c: mov     x0, x20                                    
02d53130: bl      #0x2c6051c                                 fn_2c6051c
02d53134: bl      #0x27369b8                                 fn_27369b8
## SetStateMachine(System.Runtime.CompilerServices.IAsyncStateMachine stateMachine) -> void
---- Blindbag.BlindbagGameController/<BuyItemsCompletedHandler>d__28::SetStateMachine 0x2d53138
02d53138: add     x0, x0, #8                                 
02d5313c: mov     x2, xzr                                    
02d53140: b       #0x4d43a8c                                 System.Runtime.CompilerServices.AsyncVoidMethodBuilder::SetStateMachine
#### CLASS Blindbag.BlindbagGameController parent= UnityEngine.MonoBehaviour
#   field _inputHandler                  Blindbag.InputHandler                              off=0x20 attr=1 SerializeField
#   field _itemContainer                 UnityEngine.Transform                              off=0x28 attr=1 SerializeField
#   field _storeGo                       UnityEngine.GameObject                             off=0x30 attr=1 SerializeField
#   field _basket                        Blindbag.Basket                                    off=0x38 attr=1 SerializeField
#   field _basketCollider                UnityEngine.BoxCollider2D                          off=0x40 attr=1 SerializeField
#   field _orderBagPrefab                Blindbag.BlindBagAnimation                         off=0x48 attr=1 SerializeField
#   field _scanMachine                   Blindbag.ScanMachine                               off=0x50 attr=1 SerializeField
#   field _door                          Blindbag.Door                                      off=0x58 attr=1 SerializeField
#   field _tfShopAndTable                UnityEngine.Transform                              off=0x60 attr=1 SerializeField
#   field _asset                         ScoopGame.BlindbagMarketAsset                      off=0x68 attr=1 SerializeField
#   field UIManager                      UIManager                                          off=0x70 attr=6 
#   field _gameSession                   GameSession                                        off=0x78 attr=1 
## get_Asset() -> ScoopGame.BlindbagMarketAsset
---- Blindbag.BlindbagGameController::get_Asset 0x2d50a90
02d50a90: ldr     x0, [x0, #0x68]                            ._asset
02d50a94: ret                                                
## get_Door() -> Blindbag.Door
---- Blindbag.BlindbagGameController::get_Door 0x2d50a98
02d50a98: ldr     x0, [x0, #0x58]                            ._door
02d50a9c: ret                                                
## get_Basket() -> Blindbag.Basket
---- Blindbag.BlindbagGameController::get_Basket 0x2d50aa0
02d50aa0: ldr     x0, [x0, #0x38]                            ._basket
02d50aa4: ret                                                
## get_OrderBagPrefab() -> Blindbag.BlindBagAnimation
---- Blindbag.BlindbagGameController::get_OrderBagPrefab 0x2d50aa8
02d50aa8: ldr     x0, [x0, #0x48]                            ._orderBagPrefab
02d50aac: ret                                                
## get_ScanMachine() -> Blindbag.ScanMachine
---- Blindbag.BlindbagGameController::get_ScanMachine 0x2d50ab0
02d50ab0: ldr     x0, [x0, #0x50]                            ._scanMachine
02d50ab4: ret                                                
## OnEnable() -> void
---- Blindbag.BlindbagGameController::OnEnable 0x2d50ab8
02d50ab8: stp     x30, x23, [sp, #-0x30]!                    
02d50abc: stp     x22, x21, [sp, #0x10]                      
02d50ac0: stp     x20, x19, [sp, #0x20]                      
02d50ac4: adrp    x19, #0x6630000                            
02d50ac8: mov     x20, x0                                    
02d50acc: ldrb    w8, [x19, #0x255]                          
02d50ad0: tbnz    w8, #0, #0x2d50af4                         
02d50ad4: adrp    x0, #0x626b000                             
02d50ad8: ldr     x0, [x0, #0x7d0]                           M:Blindbag.BlindbagGameController::OnClickedHandler
02d50adc: bl      #0x2b70db0                                 fn_2b70db0
02d50ae0: adrp    x0, #0x6265000                             
02d50ae4: ldr     x0, [x0, #0x3f0]                           T:UnityEngine.Events.UnityAction
02d50ae8: bl      #0x2b70db0                                 fn_2b70db0
02d50aec: mov     w8, #1                                     
02d50af0: strb    w8, [x19, #0x255]                          
02d50af4: ldr     x19, [x20, #0x20]                          ._inputHandler
02d50af8: cbz     x19, #0x2d50b88                            
02d50afc: adrp    x23, #0x6265000                            
02d50b00: adrp    x22, #0x626b000                            
02d50b04: ldr     x23, [x23, #0x3f0]                         T:UnityEngine.Events.UnityAction
02d50b08: ldr     x22, [x22, #0x7d0]                         M:Blindbag.BlindbagGameController::OnClickedHandler
02d50b0c: ldr     x21, [x19, #0x48]!                         ._orderBagPrefab
02d50b10: ldr     x0, [x23]                                  M:AdsManager::<OnApplicationPause>b__26_0
02d50b14: bl      #0x2b7104c                                 fn_2b7104c
02d50b18: ldr     x2, [x22]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d50b1c: mov     x1, x20                                    
02d50b20: mov     x3, xzr                                    
02d50b24: mov     x22, x0                                    
02d50b28: bl      #0x5b4cf98                                 UnityEngine.Events.UnityAction::.ctor
02d50b2c: mov     x0, x21                                    
02d50b30: mov     x1, x22                                    
02d50b34: mov     x2, xzr                                    
02d50b38: bl      #0x4e570ac                                 System.Delegate::Combine
02d50b3c: mov     x8, x0                                     
02d50b40: cbz     x0, #0x2d50b6c                             
02d50b44: ldr     x1, [x23]                                  M:AdsManager::<OnApplicationPause>b__26_0
02d50b48: ldr     x9, [x8]                                   
02d50b4c: cmp     x9, x1                                     
02d50b50: b.ne    #0x2d50b64                                 
02d50b54: str     x8, [x19]                                  
02d50b58: ldr     x9, [x8]                                   
02d50b5c: cmp     x9, x1                                     
02d50b60: b.eq    #0x2d50b70                                 
02d50b64: mov     x0, x8                                     
02d50b68: bl      #0x2b713dc                                 fn_2b713dc
02d50b6c: str     xzr, [x19]                                 
02d50b70: mov     x0, x19                                    
02d50b74: ldp     x20, x19, [sp, #0x20]                      
02d50b78: ldp     x22, x21, [sp, #0x10]                      
02d50b7c: mov     x1, x8                                     
02d50b80: ldp     x30, x23, [sp], #0x30                      
02d50b84: b       #0x2b70d54                                 
02d50b88: bl      #0x2b7105c                                 fn_2b7105c
## OnDisable() -> void
---- Blindbag.BlindbagGameController::OnDisable 0x2d50b8c
02d50b8c: stp     x30, x23, [sp, #-0x30]!                    
02d50b90: stp     x22, x21, [sp, #0x10]                      
02d50b94: stp     x20, x19, [sp, #0x20]                      
02d50b98: adrp    x19, #0x6630000                            
02d50b9c: mov     x20, x0                                    
02d50ba0: ldrb    w8, [x19, #0x256]                          
02d50ba4: tbnz    w8, #0, #0x2d50bc8                         
02d50ba8: adrp    x0, #0x626b000                             
02d50bac: ldr     x0, [x0, #0x7d0]                           M:Blindbag.BlindbagGameController::OnClickedHandler
02d50bb0: bl      #0x2b70db0                                 fn_2b70db0
02d50bb4: adrp    x0, #0x6265000                             
02d50bb8: ldr     x0, [x0, #0x3f0]                           T:UnityEngine.Events.UnityAction
02d50bbc: bl      #0x2b70db0                                 fn_2b70db0
02d50bc0: mov     w8, #1                                     
02d50bc4: strb    w8, [x19, #0x256]                          
02d50bc8: ldr     x19, [x20, #0x20]                          ._inputHandler
02d50bcc: cbz     x19, #0x2d50c5c                            
02d50bd0: adrp    x23, #0x6265000                            
02d50bd4: adrp    x22, #0x626b000                            
02d50bd8: ldr     x23, [x23, #0x3f0]                         T:UnityEngine.Events.UnityAction
02d50bdc: ldr     x22, [x22, #0x7d0]                         M:Blindbag.BlindbagGameController::OnClickedHandler
02d50be0: ldr     x21, [x19, #0x48]!                         ._orderBagPrefab
02d50be4: ldr     x0, [x23]                                  M:AdsManager::<OnApplicationPause>b__26_0
02d50be8: bl      #0x2b7104c                                 fn_2b7104c
02d50bec: ldr     x2, [x22]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d50bf0: mov     x1, x20                                    
02d50bf4: mov     x3, xzr                                    
02d50bf8: mov     x22, x0                                    
02d50bfc: bl      #0x5b4cf98                                 UnityEngine.Events.UnityAction::.ctor
02d50c00: mov     x0, x21                                    
02d50c04: mov     x1, x22                                    
02d50c08: mov     x2, xzr                                    
02d50c0c: bl      #0x4e57298                                 System.Delegate::Remove
02d50c10: mov     x8, x0                                     
02d50c14: cbz     x0, #0x2d50c40                             
02d50c18: ldr     x1, [x23]                                  M:AdsManager::<OnApplicationPause>b__26_0
02d50c1c: ldr     x9, [x8]                                   
02d50c20: cmp     x9, x1                                     
02d50c24: b.ne    #0x2d50c38                                 
02d50c28: str     x8, [x19]                                  
02d50c2c: ldr     x9, [x8]                                   
02d50c30: cmp     x9, x1                                     
02d50c34: b.eq    #0x2d50c44                                 
02d50c38: mov     x0, x8                                     
02d50c3c: bl      #0x2b713dc                                 fn_2b713dc
02d50c40: str     xzr, [x19]                                 
02d50c44: mov     x0, x19                                    
02d50c48: ldp     x20, x19, [sp, #0x20]                      
02d50c4c: ldp     x22, x21, [sp, #0x10]                      
02d50c50: mov     x1, x8                                     
02d50c54: ldp     x30, x23, [sp], #0x30                      
02d50c58: b       #0x2b70d54                                 
02d50c5c: bl      #0x2b7105c                                 fn_2b7105c
## Awake() -> void
---- Blindbag.BlindbagGameController::Awake 0x2d50c60
02d50c60: b       #0x2d50c64                                 Blindbag.BlindbagGameController::Initialized
## Start() -> void
---- Blindbag.BlindbagGameController::Start 0x2d50dc8
02d50dc8: stp     x30, x23, [sp, #-0x30]!                    
02d50dcc: stp     x22, x21, [sp, #0x10]                      
02d50dd0: stp     x20, x19, [sp, #0x20]                      
02d50dd4: adrp    x20, #0x6630000                            
02d50dd8: adrp    x21, #0x6265000                            
02d50ddc: mov     x19, x0                                    
02d50de0: ldrb    w8, [x20, #0x257]                          
02d50de4: ldr     x21, [x21, #0x10]                          MS:MonoSingleton`1::get_Instance
02d50de8: tbnz    w8, #0, #0x2d50e3c                         
02d50dec: adrp    x0, #0x626b000                             
02d50df0: ldr     x0, [x0, #0x808]                           M:Blindbag.BlindbagGameController::OnOpenDoorHandler
02d50df4: bl      #0x2b70db0                                 fn_2b70db0
02d50df8: adrp    x0, #0x626b000                             
02d50dfc: ldr     x0, [x0, #0x810]                           MS:Framework.GameObjectExtension::SetActive
02d50e00: bl      #0x2b70db0                                 fn_2b70db0
02d50e04: adrp    x0, #0x6266000                             
02d50e08: ldr     x0, [x0, #0xac0]                           MS:MonoSingleton`1::get_Instance
02d50e0c: bl      #0x2b70db0                                 fn_2b70db0
02d50e10: adrp    x0, #0x6265000                             
02d50e14: ldr     x0, [x0, #0x10]                            MS:MonoSingleton`1::get_Instance
02d50e18: bl      #0x2b70db0                                 fn_2b70db0
02d50e1c: adrp    x0, #0x626b000                             
02d50e20: ldr     x0, [x0, #0x818]                           MS:UIManager::ShowScreen
02d50e24: bl      #0x2b70db0                                 fn_2b70db0
02d50e28: adrp    x0, #0x6265000                             
02d50e2c: ldr     x0, [x0, #0x3f0]                           T:UnityEngine.Events.UnityAction
02d50e30: bl      #0x2b70db0                                 fn_2b70db0
02d50e34: mov     w8, #1                                     
02d50e38: strb    w8, [x20, #0x257]                          
02d50e3c: ldr     x0, [x21]                                  M:AdsManager::<OnApplicationPause>b__26_0
02d50e40: bl      #0x3769600                                 fn_3769600
02d50e44: cbz     x0, #0x2d50f78                             
02d50e48: mov     x1, xzr                                    
02d50e4c: bl      #0x2cdff7c                                 SimpleSceneTransition::FadeOut
02d50e50: ldr     x0, [x19, #0x70]                           .UIManager
02d50e54: cbz     x0, #0x2d50f78                             
02d50e58: adrp    x8, #0x626b000                             
02d50e5c: ldr     x8, [x8, #0x818]                           MS:UIManager::ShowScreen
02d50e60: ldr     x1, [x8]                                   T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d50e64: bl      #0x33fc0e8                                 fn_33fc0e8
02d50e68: cbz     x0, #0x2d50f78                             
02d50e6c: adrp    x23, #0x6265000                            
02d50e70: adrp    x22, #0x626b000                            
02d50e74: mov     x20, x0                                    
02d50e78: ldr     x23, [x23, #0x3f0]                         T:UnityEngine.Events.UnityAction
02d50e7c: ldr     x22, [x22, #0x808]                         M:Blindbag.BlindbagGameController::OnOpenDoorHandler
02d50e80: ldr     x21, [x20, #0x40]!                         ._basketCollider
02d50e84: ldr     x0, [x23]                                  M:AdsManager::<OnApplicationPause>b__26_0
02d50e88: bl      #0x2b7104c                                 fn_2b7104c
02d50e8c: ldr     x2, [x22]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d50e90: mov     x1, x19                                    
02d50e94: mov     x3, xzr                                    
02d50e98: mov     x22, x0                                    
02d50e9c: bl      #0x5b4cf98                                 UnityEngine.Events.UnityAction::.ctor
02d50ea0: mov     x0, x21                                    
02d50ea4: mov     x1, x22                                    
02d50ea8: mov     x2, xzr                                    
02d50eac: bl      #0x4e570ac                                 System.Delegate::Combine
02d50eb0: mov     x8, x0                                     
02d50eb4: cbz     x0, #0x2d50ee0                             
02d50eb8: ldr     x1, [x23]                                  M:AdsManager::<OnApplicationPause>b__26_0
02d50ebc: ldr     x9, [x8]                                   T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d50ec0: cmp     x9, x1                                     
02d50ec4: b.ne    #0x2d50ed8                                 
02d50ec8: str     x8, [x20]                                  
02d50ecc: ldr     x9, [x8]                                   T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d50ed0: cmp     x9, x1                                     
02d50ed4: b.eq    #0x2d50ee4                                 
02d50ed8: mov     x0, x8                                     
02d50edc: bl      #0x2b713dc                                 fn_2b713dc
02d50ee0: str     xzr, [x20]                                 
02d50ee4: adrp    x21, #0x6266000                            
02d50ee8: mov     x0, x20                                    
02d50eec: mov     x1, x8                                     
02d50ef0: ldr     x21, [x21, #0xac0]                         MS:MonoSingleton`1::get_Instance
02d50ef4: bl      #0x2b70d54                                 fn_2b70d54
02d50ef8: ldr     x0, [x21]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d50efc: bl      #0x3769600                                 fn_3769600
02d50f00: mov     x20, x19                                   
02d50f04: mov     x1, x0                                     
02d50f08: str     x0, [x20, #0x78]!                          ._gameSession
02d50f0c: mov     x0, x20                                    
02d50f10: bl      #0x2b70d54                                 fn_2b70d54
02d50f14: ldr     x0, [x20]                                  
02d50f18: cbz     x0, #0x2d50f78                             
02d50f1c: mov     x1, xzr                                    
02d50f20: bl      #0x2cac928                                 GameSession::get_CharacterContainer
02d50f24: cbz     x0, #0x2d50f78                             
02d50f28: mov     x1, xzr                                    
02d50f2c: bl      #0x5b368f0                                 UnityEngine.GameObject::get_transform
02d50f30: adrp    x8, #0x1084000                             
02d50f34: mov     x1, xzr                                    
02d50f38: ldr     s0, [x8, #0xfb8]                           [1084fb8]=3fe38e39bec28f5c f=-0.38,1.77778
02d50f3c: bl      #0x2dbfda4                                 Redcode.Extensions.TransformExtensions::SetLocalPositionY
02d50f40: ldr     x0, [x20]                                  
02d50f44: cbz     x0, #0x2d50f78                             
02d50f48: adrp    x20, #0x626b000                            
02d50f4c: mov     w1, wzr                                    
02d50f50: mov     x2, xzr                                    
02d50f54: ldr     x20, [x20, #0x810]                         MS:Framework.GameObjectExtension::SetActive
02d50f58: bl      #0x2cacd8c                                 GameSession::SetActiveCharacter
02d50f5c: ldr     x0, [x19, #0x58]                           ._door
02d50f60: ldr     x2, [x20]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d50f64: mov     w1, #1                                     
02d50f68: ldp     x20, x19, [sp, #0x20]                      
02d50f6c: ldp     x22, x21, [sp, #0x10]                      
02d50f70: ldp     x30, x23, [sp], #0x30                      
02d50f74: b       #0x31d24a4                                 
02d50f78: bl      #0x2b7105c                                 fn_2b7105c
## FullBasketTrigger() -> void
---- Blindbag.BlindbagGameController::FullBasketTrigger 0x2d50f7c
02d50f7c: str     x30, [sp, #-0x20]!                         
02d50f80: stp     x20, x19, [sp, #0x10]                      
02d50f84: adrp    x20, #0x6630000                            
02d50f88: mov     x19, x0                                    
02d50f8c: ldrb    w8, [x20, #0x258]                          
02d50f90: tbnz    w8, #0, #0x2d50fa8                         
02d50f94: adrp    x0, #0x626b000                             
02d50f98: ldr     x0, [x0, #0x740]                           MS:UIManager::GetScreen
02d50f9c: bl      #0x2b70db0                                 fn_2b70db0
02d50fa0: mov     w8, #1                                     
02d50fa4: strb    w8, [x20, #0x258]                          
02d50fa8: ldr     x0, [x19, #0x70]                           .UIManager
02d50fac: cbz     x0, #0x2d50fd4                             
02d50fb0: adrp    x8, #0x626b000                             
02d50fb4: ldr     x8, [x8, #0x740]                           MS:UIManager::GetScreen
02d50fb8: ldr     x1, [x8]                                   T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d50fbc: bl      #0x33fbbd0                                 fn_33fbbd0
02d50fc0: cbz     x0, #0x2d50fd4                             
02d50fc4: ldp     x20, x19, [sp, #0x10]                      
02d50fc8: fmov    s0, #1.00000000                            
02d50fcc: ldr     x30, [sp], #0x20                           
02d50fd0: b       #0x2d50fd8                                 Blindbag.StoreScreen::ShowCartFullNotification
02d50fd4: bl      #0x2b7105c                                 fn_2b7105c
## OnOpenDoorHandler() -> void
---- Blindbag.BlindbagGameController::OnOpenDoorHandler 0x2d51014
02d51014: str     x30, [sp, #-0x30]!                         
02d51018: stp     x22, x21, [sp, #0x10]                      
02d5101c: stp     x20, x19, [sp, #0x20]                      
02d51020: adrp    x20, #0x6630000                            
02d51024: adrp    x22, #0x6264000                            
02d51028: adrp    x21, #0x626b000                            
02d5102c: ldrb    w8, [x20, #0x259]                          
02d51030: ldr     x22, [x22, #0xf90]                         T:System.Action
02d51034: ldr     x21, [x21, #0x820]                         M:Blindbag.BlindbagGameController::<OnOpenDoorHandler>b__27_0
02d51038: mov     x19, x0                                    
02d5103c: tbnz    w8, #0, #0x2d51060                         
02d51040: adrp    x0, #0x6264000                             
02d51044: ldr     x0, [x0, #0xf90]                           T:System.Action
02d51048: bl      #0x2b70db0                                 fn_2b70db0
02d5104c: adrp    x0, #0x626b000                             
02d51050: ldr     x0, [x0, #0x820]                           M:Blindbag.BlindbagGameController::<OnOpenDoorHandler>b__27_0
02d51054: bl      #0x2b70db0                                 fn_2b70db0
02d51058: mov     w8, #1                                     
02d5105c: strb    w8, [x20, #0x259]                          
02d51060: ldr     x0, [x22]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d51064: ldr     x20, [x19, #0x58]                          ._door
02d51068: bl      #0x2b7104c                                 fn_2b7104c
02d5106c: ldr     x2, [x21]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d51070: mov     x1, x19                                    
02d51074: mov     x3, xzr                                    
02d51078: mov     x21, x0                                    
02d5107c: bl      #0x4d8ddbc                                 System.Action::.ctor
02d51080: cbz     x20, #0x2d510a0                            
02d51084: mov     x0, x20                                    
02d51088: mov     x1, x21                                    
02d5108c: fmov    s0, #1.00000000                            
02d51090: ldp     x20, x19, [sp, #0x20]                      
02d51094: ldp     x22, x21, [sp, #0x10]                      
02d51098: ldr     x30, [sp], #0x30                           
02d5109c: b       #0x2d510a4                                 Blindbag.Door::Open
02d510a0: bl      #0x2b7105c                                 fn_2b7105c
## BuyItemsCompletedHandler() -> void
---- Blindbag.BlindbagGameController::BuyItemsCompletedHandler 0x2d5129c
02d5129c: sub     sp, sp, #0x80                              
02d512a0: stp     x30, x21, [sp, #0x60]                      
02d512a4: stp     x20, x19, [sp, #0x70]                      
02d512a8: adrp    x21, #0x6630000                            
02d512ac: adrp    x20, #0x626b000                            
02d512b0: mov     x19, x0                                    
02d512b4: ldrb    w8, [x21, #0x25a]                          
02d512b8: ldr     x20, [x20, #0x838]                         MS:System.Runtime.CompilerServices.AsyncVoidMethodBuilder::Start
02d512bc: tbnz    w8, #0, #0x2d512d4                         
02d512c0: adrp    x0, #0x626b000                             
02d512c4: ldr     x0, [x0, #0x838]                           MS:System.Runtime.CompilerServices.AsyncVoidMethodBuilder::Start
02d512c8: bl      #0x2b70db0                                 fn_2b70db0
02d512cc: mov     w8, #1                                     
02d512d0: strb    w8, [x21, #0x25a]                          
02d512d4: movi    v0.2d, #0000000000000000                   
02d512d8: mov     x8, sp                                     
02d512dc: mov     x0, xzr                                    
02d512e0: stp     q0, q0, [sp, #0x20]                        
02d512e4: stp     q0, q0, [sp, #0x40]                        
02d512e8: bl      #0x4d43a24                                 System.Runtime.CompilerServices.AsyncVoidMethodBuilder::Create
02d512ec: ldp     q0, q1, [sp]                               
02d512f0: add     x21, sp, #0x20                             
02d512f4: orr     x0, x21, #8                                
02d512f8: mov     x1, xzr                                    
02d512fc: stur    q0, [sp, #0x28]                            
02d51300: stur    q1, [sp, #0x38]                            
02d51304: bl      #0x2b70d54                                 fn_2b70d54
02d51308: add     x0, x21, #0x28                             &6630028
02d5130c: mov     x1, x19                                    
02d51310: str     x19, [sp, #0x48]                           
02d51314: bl      #0x2b70d54                                 fn_2b70d54
02d51318: ldr     x2, [x20]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d5131c: mov     w8, #-1                                    
02d51320: orr     x0, x21, #8                                
02d51324: add     x1, sp, #0x20                              
02d51328: str     w8, [sp, #0x20]                            
02d5132c: bl      #0x30c65b8                                 fn_30c65b8
02d51330: ldp     x20, x19, [sp, #0x70]                      
02d51334: ldp     x30, x21, [sp, #0x60]                      
02d51338: add     sp, sp, #0x80                              
02d5133c: ret                                                
## OrderingCompletedHandler() -> void
---- Blindbag.BlindbagGameController::OrderingCompletedHandler 0x2d51340
02d51340: stp     x30, x19, [sp, #-0x10]!                    
02d51344: mov     x19, x0                                    
02d51348: ldr     x0, [x0, #0x50]                            ._scanMachine
02d5134c: cbz     x0, #0x2d51360                             
02d51350: bl      #0x2d51364                                 Blindbag.ScanMachine::OnBuyCompleted
02d51354: mov     x0, x19                                    
02d51358: ldp     x30, x19, [sp], #0x10                      
02d5135c: b       #0x2d5129c                                 Blindbag.BlindbagGameController::BuyItemsCompletedHandler
02d51360: bl      #0x2b7105c                                 fn_2b7105c
## Initialized() -> void
---- Blindbag.BlindbagGameController::Initialized 0x2d50c64
02d50c64: str     x30, [sp, #-0x30]!                         
02d50c68: stp     x22, x21, [sp, #0x10]                      
02d50c6c: stp     x20, x19, [sp, #0x20]                      
02d50c70: adrp    x20, #0x6630000                            
02d50c74: mov     x19, x0                                    
02d50c78: ldrb    w8, [x20, #0x25b]                          
02d50c7c: tbnz    w8, #0, #0x2d50cd0                         
02d50c80: adrp    x0, #0x626b000                             
02d50c84: ldr     x0, [x0, #0x7d8]                           T:type53137(k15)
02d50c88: bl      #0x2b70db0                                 fn_2b70db0
02d50c8c: adrp    x0, #0x626b000                             
02d50c90: ldr     x0, [x0, #0x7e0]                           M:Blindbag.BlindbagGameController::<Initialized>b__30_0
02d50c94: bl      #0x2b70db0                                 fn_2b70db0
02d50c98: adrp    x0, #0x626b000                             
02d50c9c: ldr     x0, [x0, #0x7e8]                           MS:UnityEngine.Component::GetComponentsInChildren
02d50ca0: bl      #0x2b70db0                                 fn_2b70db0
02d50ca4: adrp    x0, #0x626b000                             
02d50ca8: ldr     x0, [x0, #0x7f0]                           MS:System.Linq.Enumerable::ToList
02d50cac: bl      #0x2b70db0                                 fn_2b70db0
02d50cb0: adrp    x0, #0x626b000                             
02d50cb4: ldr     x0, [x0, #0x7f8]                           MS:Framework.GameObjectExtension::SetActive
02d50cb8: bl      #0x2b70db0                                 fn_2b70db0
02d50cbc: adrp    x0, #0x626b000                             
02d50cc0: ldr     x0, [x0, #0x800]                           MS:System.Collections.Generic.List`1::ForEach
02d50cc4: bl      #0x2b70db0                                 fn_2b70db0
02d50cc8: mov     w8, #1                                     
02d50ccc: strb    w8, [x20, #0x25b]                          
02d50cd0: ldr     x0, [x19, #0x28]                           ._itemContainer
02d50cd4: cbz     x0, #0x2d50dc4                             
02d50cd8: adrp    x8, #0x626b000                             
02d50cdc: adrp    x20, #0x626b000                            
02d50ce0: adrp    x21, #0x626b000                            
02d50ce4: ldr     x8, [x8, #0x7e8]                           MS:UnityEngine.Component::GetComponentsInChildren
02d50ce8: adrp    x22, #0x626b000                            
02d50cec: ldr     x20, [x20, #0x7f0]                         MS:System.Linq.Enumerable::ToList
02d50cf0: ldr     x21, [x21, #0x7d8]                         T:type53137(k15)
02d50cf4: ldr     x22, [x22, #0x7e0]                         M:Blindbag.BlindbagGameController::<Initialized>b__30_0
02d50cf8: ldr     x1, [x8]                                   T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d50cfc: bl      #0x314172c                                 fn_314172c
02d50d00: ldr     x1, [x20]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d50d04: bl      #0x319eb2c                                 fn_319eb2c
02d50d08: ldr     x8, [x21]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d50d0c: mov     x20, x0                                    
02d50d10: mov     x0, x8                                     
02d50d14: bl      #0x2b7104c                                 fn_2b7104c
02d50d18: ldr     x2, [x22]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d50d1c: mov     x1, x19                                    
02d50d20: mov     x3, xzr                                    
02d50d24: mov     x21, x0                                    
02d50d28: bl      #0x453418c                                 fn_453418c
02d50d2c: cbz     x20, #0x2d50dc4                            
02d50d30: adrp    x8, #0x626b000                             
02d50d34: mov     x0, x20                                    
02d50d38: mov     x1, x21                                    
02d50d3c: ldr     x8, [x8, #0x800]                           MS:System.Collections.Generic.List`1::ForEach
02d50d40: ldr     x2, [x8]                                   T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d50d44: bl      #0x35a9ce4                                 fn_35a9ce4
02d50d48: ldr     x0, [x19, #0x38]                           ._basket
02d50d4c: cbz     x0, #0x2d50dc4                             
02d50d50: mov     x1, x19                                    
02d50d54: str     x19, [x0, #0x30]!                          ._storeGo
02d50d58: bl      #0x2b70d54                                 fn_2b70d54
02d50d5c: ldr     x0, [x19, #0x50]                           ._scanMachine
02d50d60: cbz     x0, #0x2d50dc4                             
02d50d64: mov     x1, x19                                    
02d50d68: bl      #0x2d516bc                                 Blindbag.ScanMachine::OnInitialized
02d50d6c: ldr     x0, [x19, #0x50]                           ._scanMachine
02d50d70: cbz     x0, #0x2d50dc4                             
02d50d74: mov     w1, wzr                                    
02d50d78: bl      #0x2d5178c                                 Blindbag.ScanMachine::SetActive
02d50d7c: ldr     x0, [x19, #0x30]                           ._storeGo
02d50d80: cbz     x0, #0x2d50dc4                             
02d50d84: adrp    x20, #0x626b000                            
02d50d88: mov     w1, #1                                     
02d50d8c: mov     x2, xzr                                    
02d50d90: ldr     x20, [x20, #0x7f8]                         MS:Framework.GameObjectExtension::SetActive
02d50d94: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d50d98: ldr     x0, [x19, #0x38]                           ._basket
02d50d9c: ldr     x2, [x20]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d50da0: mov     w1, #1                                     
02d50da4: bl      #0x31d24a4                                 fn_31d24a4
02d50da8: ldr     x0, [x19, #0x58]                           ._door
02d50dac: cbz     x0, #0x2d50dc4                             
02d50db0: ldp     x20, x19, [sp, #0x20]                      
02d50db4: movi    d0, #0000000000000000                      
02d50db8: ldp     x22, x21, [sp, #0x10]                      
02d50dbc: ldr     x30, [sp], #0x30                           
02d50dc0: b       #0x2d53144                                 Blindbag.Door::Hide
02d50dc4: bl      #0x2b7105c                                 fn_2b7105c
## GetItemInStore(int id) -> Blindbag.ItemBase
---- Blindbag.BlindbagGameController::GetItemInStore 0x2d517dc
02d517dc: sub     sp, sp, #0x60                              
02d517e0: str     x30, [sp, #0x30]                           
02d517e4: stp     x22, x21, [sp, #0x40]                      
02d517e8: stp     x20, x19, [sp, #0x50]                      
02d517ec: adrp    x21, #0x6630000                            
02d517f0: mov     w19, w1                                    
02d517f4: mov     x20, x0                                    
02d517f8: ldrb    w8, [x21, #0x25c]                          
02d517fc: tbnz    w8, #0, #0x2d51850                         
02d51800: adrp    x0, #0x626b000                             
02d51804: ldr     x0, [x0, #0x7e8]                           MS:UnityEngine.Component::GetComponentsInChildren
02d51808: bl      #0x2b70db0                                 fn_2b70db0
02d5180c: adrp    x0, #0x626b000                             
02d51810: ldr     x0, [x0, #0x7f0]                           MS:System.Linq.Enumerable::ToList
02d51814: bl      #0x2b70db0                                 fn_2b70db0
02d51818: adrp    x0, #0x626b000                             
02d5181c: ldr     x0, [x0, #0x898]                           MS:System.Collections.Generic.List`1/Enumerator::Dispose
02d51820: bl      #0x2b70db0                                 fn_2b70db0
02d51824: adrp    x0, #0x626b000                             
02d51828: ldr     x0, [x0, #0x8a0]                           MS:System.Collections.Generic.List`1/Enumerator::MoveNext
02d5182c: bl      #0x2b70db0                                 fn_2b70db0
02d51830: adrp    x0, #0x626b000                             
02d51834: ldr     x0, [x0, #0x8a8]                           MS:System.Collections.Generic.List`1/Enumerator::get_Current
02d51838: bl      #0x2b70db0                                 fn_2b70db0
02d5183c: adrp    x0, #0x626b000                             
02d51840: ldr     x0, [x0, #0x8b0]                           MS:System.Collections.Generic.List`1::GetEnumerator
02d51844: bl      #0x2b70db0                                 fn_2b70db0
02d51848: mov     w8, #1                                     
02d5184c: strb    w8, [x21, #0x25c]                          
02d51850: ldr     x0, [x20, #0x28]                           ._itemContainer
02d51854: stp     xzr, xzr, [sp, #0x18]                      
02d51858: str     xzr, [sp, #0x28]                           
02d5185c: cbz     x0, #0x2d51904                             
02d51860: adrp    x8, #0x626b000                             
02d51864: adrp    x20, #0x626b000                            
02d51868: ldr     x8, [x8, #0x7e8]                           MS:UnityEngine.Component::GetComponentsInChildren
02d5186c: ldr     x20, [x20, #0x7f0]                         MS:System.Linq.Enumerable::ToList
02d51870: ldr     x1, [x8]                                   T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d51874: bl      #0x314172c                                 fn_314172c
02d51878: ldr     x1, [x20]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d5187c: bl      #0x319eb2c                                 fn_319eb2c
02d51880: cbz     x0, #0x2d51904                             
02d51884: adrp    x8, #0x626b000                             
02d51888: adrp    x22, #0x626b000                            
02d5188c: adrp    x21, #0x626b000                            
02d51890: ldr     x8, [x8, #0x8b0]                           MS:System.Collections.Generic.List`1::GetEnumerator
02d51894: ldr     x22, [x22, #0x8a0]                         MS:System.Collections.Generic.List`1/Enumerator::MoveNext
02d51898: ldr     x21, [x21, #0x898]                         MS:System.Collections.Generic.List`1/Enumerator::Dispose
02d5189c: add     x20, sp, #0x18                             
02d518a0: ldr     x1, [x8]                                   T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d518a4: add     x8, sp, #0x18                              
02d518a8: bl      #0x35a9d9c                                 fn_35a9d9c
02d518ac: stp     xzr, x20, [sp, #8]                         
02d518b0: ldr     x1, [x22]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d518b4: add     x0, sp, #0x18                              
02d518b8: bl      #0x4690474                                 fn_4690474
02d518bc: tbz     w0, #0, #0x2d518d8                         
02d518c0: ldr     x20, [sp, #0x28]                           
02d518c4: cbz     x20, #0x2d51900                            
02d518c8: ldr     w8, [x20, #0x20]                           M:ScoopGame.CategoryAsset/<>c__DisplayClass4_0::<GetOptionDataByID>b__0 ._inputHandler
02d518cc: cmp     w8, w19                                    
02d518d0: b.ne    #0x2d518b0                                 
02d518d4: b       #0x2d518dc                                 
02d518d8: mov     x20, xzr                                   
02d518dc: ldr     x1, [x21]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d518e0: add     x0, sp, #0x18                              
02d518e4: bl      #0x4690470                                 fn_4690470
02d518e8: mov     x0, x20                                    
02d518ec: ldp     x20, x19, [sp, #0x50]                      
02d518f0: ldp     x22, x21, [sp, #0x40]                      
02d518f4: ldr     x30, [sp, #0x30]                           
02d518f8: add     sp, sp, #0x60                              
02d518fc: ret                                                
02d51900: bl      #0x2b7105c                                 fn_2b7105c
02d51904: bl      #0x2b7105c                                 fn_2b7105c
02d51908: b       #0x2d5190c                                 
02d5190c: mov     x19, x0                                    
02d51910: cmp     w1, #1                                     
02d51914: b.ne    #0x2d51950                                 
02d51918: mov     x0, x19                                    
02d5191c: bl      #0x5e90260                                 fn_5e90260
02d51920: ldr     x19, [x0]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d51924: str     x19, [sp, #8]                              
02d51928: bl      #0x5e90270                                 fn_5e90270
02d5192c: ldr     x0, [sp, #0x10]                            
02d51930: ldr     x1, [x21]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d51934: bl      #0x4690470                                 fn_4690470
02d51938: cbnz    x19, #0x2d51944                            
02d5193c: mov     x20, xzr                                   
02d51940: b       #0x2d518e8                                 
02d51944: mov     x0, x19                                    
02d51948: bl      #0x2b71054                                 fn_2b71054
02d5194c: mov     x19, x0                                    
02d51950: add     x0, sp, #8                                 
02d51954: bl      #0x2738718                                 fn_2738718
02d51958: mov     x0, x19                                    
02d5195c: bl      #0x2c6051c                                 fn_2c6051c
02d51960: bl      #0x27369b8                                 fn_27369b8
## OnClickedHandler() -> void
---- Blindbag.BlindbagGameController::OnClickedHandler 0x2d51964
02d51964: sub     sp, sp, #0xa0                              
02d51968: stp     d11, d10, [sp, #0x60]                      
02d5196c: stp     d9, d8, [sp, #0x70]                        
02d51970: str     x30, [sp, #0x80]                           
02d51974: stp     x20, x19, [sp, #0x90]                      
02d51978: adrp    x19, #0x6630000                            
02d5197c: ldrb    w8, [x19, #0x25d]                          
02d51980: tbnz    w8, #0, #0x2d519c8                         
02d51984: adrp    x0, #0x626b000                             
02d51988: ldr     x0, [x0, #0x8b8]                           MS:UnityEngine.Component::GetComponent
02d5198c: bl      #0x2b70db0                                 fn_2b70db0
02d51990: adrp    x0, #0x626b000                             
02d51994: ldr     x0, [x0, #0x8c0]                           T:Jelly.IClickable
02d51998: bl      #0x2b70db0                                 fn_2b70db0
02d5199c: adrp    x0, #0x6266000                             
02d519a0: ldr     x0, [x0, #0x938]                           MS:UnityEngine.InputSystem.InputControl`1::ReadValue
02d519a4: bl      #0x2b70db0                                 fn_2b70db0
02d519a8: adrp    x0, #0x6263000                             
02d519ac: ldr     x0, [x0, #0x918]                           T:UnityEngine.Object
02d519b0: bl      #0x2b70db0                                 fn_2b70db0
02d519b4: adrp    x0, #0x6266000                             
02d519b8: ldr     x0, [x0, #0x940]                           T:UnityEngine.Physics2D
02d519bc: bl      #0x2b70db0                                 fn_2b70db0
02d519c0: mov     w8, #1                                     
02d519c4: strb    w8, [x19, #0x25d]                          
02d519c8: movi    v0.2d, #0000000000000000                   
02d519cc: adrp    x19, #0x662f000                            
02d519d0: str     wzr, [sp, #0x50]                           
02d519d4: ldrb    w8, [x19, #0xbd9]                          
02d519d8: stp     q0, q0, [sp, #0x30]                        
02d519dc: cbnz    w8, #0x2d519f4                             
02d519e0: adrp    x0, #0x6266000                             
02d519e4: ldr     x0, [x0, #0x950]                           T:UnityEngine.InputSystem.Pointer
02d519e8: bl      #0x2b70db0                                 fn_2b70db0
02d519ec: mov     w8, #1                                     
02d519f0: strb    w8, [x19, #0xbd9]                          
02d519f4: adrp    x8, #0x6266000                             
02d519f8: ldr     x8, [x8, #0x950]                           T:UnityEngine.InputSystem.Pointer
02d519fc: ldr     x8, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d51a00: ldr     x8, [x8, #0xb8]                            S:'banner_native_refresh_time'
02d51a04: ldr     x19, [x8]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d51a08: cbz     x19, #0x2d51b9c                            
02d51a0c: mov     x0, xzr                                    
02d51a10: bl      #0x5aefe28                                 UnityEngine.Camera::get_main
02d51a14: ldr     x8, [x19, #0x188]                          [662f188]=600006a f=2.40744e-35,0
02d51a18: cbz     x8, #0x2d51bb4                             
02d51a1c: adrp    x9, #0x6266000                             
02d51a20: mov     x19, x0                                    
02d51a24: mov     x0, x8                                     
02d51a28: ldr     x9, [x9, #0x938]                           MS:UnityEngine.InputSystem.InputControl`1::ReadValue
02d51a2c: ldr     x1, [x9]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d51a30: bl      #0x4a187c4                                 fn_4a187c4
02d51a34: cbz     x19, #0x2d51bb4                            
02d51a38: movi    d2, #0000000000000000                      
02d51a3c: adrp    x20, #0x6266000                            
02d51a40: mov     x0, x19                                    
02d51a44: ldr     x20, [x20, #0x940]                         T:UnityEngine.Physics2D
02d51a48: mov     x1, xzr                                    
02d51a4c: bl      #0x5aefbb0                                 UnityEngine.Camera::ScreenToWorldPoint
02d51a50: fmov    s8, s0                                     
02d51a54: fmov    s9, s1                                     
02d51a58: adrp    x19, #0x662f000                            
02d51a5c: ldrb    w8, [x19, #0xbda]                          
02d51a60: cbnz    w8, #0x2d51a78                             
02d51a64: adrp    x0, #0x6266000                             
02d51a68: ldr     x0, [x0, #0x970]                           T:UnityEngine.Vector2
02d51a6c: bl      #0x2b70db0                                 fn_2b70db0
02d51a70: mov     w8, #1                                     
02d51a74: strb    w8, [x19, #0xbda]                          
02d51a78: adrp    x8, #0x6266000                             
02d51a7c: adrp    x19, #0x6263000                            
02d51a80: ldr     x8, [x8, #0x970]                           T:UnityEngine.Vector2
02d51a84: ldr     x0, [x20]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d51a88: ldr     x8, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d51a8c: ldr     x8, [x8, #0xb8]                            S:'banner_native_refresh_time'
02d51a90: ldr     x19, [x19, #0x918]                         T:UnityEngine.Object
02d51a94: ldr     w9, [x0, #0xe4]                            [62660e4]=0 f=0,0
02d51a98: ldp     s10, s11, [x8]                             
02d51a9c: cbnz    w9, #0x2d51aa4                             
02d51aa0: bl      #0x2b70f30                                 fn_2b70f30
02d51aa4: mov     w9, #0x42c80000                            
02d51aa8: fmov    s0, s8                                     
02d51aac: fmov    s1, s9                                     
02d51ab0: fmov    s2, s10                                    
02d51ab4: fmov    s3, s11                                    
02d51ab8: add     x8, sp, #0xc                               
02d51abc: fmov    s4, w9                                     
02d51ac0: mov     x0, xzr                                    
02d51ac4: bl      #0x5bbcac8                                 UnityEngine.Physics2D::Raycast
02d51ac8: ldur    q0, [sp, #0xc]                             
02d51acc: ldur    q1, [sp, #0x1c]                            
02d51ad0: add     x0, sp, #0x30                              
02d51ad4: ldr     w8, [sp, #0x2c]                            
02d51ad8: mov     x1, xzr                                    
02d51adc: stp     q0, q1, [sp, #0x30]                        
02d51ae0: str     w8, [sp, #0x50]                            
02d51ae4: bl      #0x5bbe11c                                 UnityEngine.RaycastHit2D::get_collider
02d51ae8: ldr     x8, [x19]                                  &2c5bbd4(=a9bd7bfdd503233f)
02d51aec: mov     x19, x0                                    
02d51af0: ldr     w9, [x8, #0xe4]                            [62660e4]=0 f=0,0
02d51af4: cbnz    w9, #0x2d51b00                             
02d51af8: mov     x0, x8                                     
02d51afc: bl      #0x2b70f30                                 fn_2b70f30
02d51b00: mov     x0, x19                                    
02d51b04: mov     x1, xzr                                    
02d51b08: mov     x2, xzr                                    
02d51b0c: bl      #0x5b37d84                                 UnityEngine.Object::op_Equality
02d51b10: tbnz    w0, #0, #0x2d51b9c                         
02d51b14: add     x0, sp, #0x30                              
02d51b18: mov     x1, xzr                                    
02d51b1c: bl      #0x5bbe11c                                 UnityEngine.RaycastHit2D::get_collider
02d51b20: cbz     x0, #0x2d51bb4                             
02d51b24: adrp    x8, #0x626b000                             
02d51b28: ldr     x8, [x8, #0x8b8]                           MS:UnityEngine.Component::GetComponent
02d51b2c: ldr     x1, [x8]                                   T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d51b30: bl      #0x3140c84                                 fn_3140c84
02d51b34: cbz     x0, #0x2d51b9c                             
02d51b38: adrp    x10, #0x626b000                            
02d51b3c: ldr     x8, [x0]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d51b40: mov     x19, x0                                    
02d51b44: ldr     x10, [x10, #0x8c0]                         T:Jelly.IClickable
02d51b48: ldrh    w9, [x8, #0x12e]                           
02d51b4c: ldr     x1, [x10]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d51b50: cbz     x9, #0x2d51b74                             
02d51b54: ldr     x10, [x8, #0xb0]                           T:ScoopGame.CompletedPopup/<>c
02d51b58: add     x10, x10, #8                               &626b008
02d51b5c: ldur    x11, [x10, #-8]                            
02d51b60: cmp     x11, x1                                    
02d51b64: b.eq    #0x2d51b84                                 
02d51b68: subs    x9, x9, #1                                 
02d51b6c: add     x10, x10, #0x10                            &626b010
02d51b70: b.ne    #0x2d51b5c                                 
02d51b74: mov     x0, x19                                    
02d51b78: mov     w2, wzr                                    
02d51b7c: bl      #0x2baa05c                                 fn_2baa05c
02d51b80: b       #0x2d51b90                                 
02d51b84: ldrsw   x9, [x10]                                  
02d51b88: add     x8, x8, x9, lsl #4                         &626b000
02d51b8c: add     x0, x8, #0x138                             &626b138
02d51b90: ldp     x8, x1, [x0]                               
02d51b94: mov     x0, x19                                    
02d51b98: blr     x8                                         
02d51b9c: ldp     x20, x19, [sp, #0x90]                      
02d51ba0: ldr     x30, [sp, #0x80]                           
02d51ba4: ldp     d9, d8, [sp, #0x70]                        
02d51ba8: ldp     d11, d10, [sp, #0x60]                      
02d51bac: add     sp, sp, #0xa0                              
02d51bb0: ret                                                
02d51bb4: bl      #0x2b7105c                                 fn_2b7105c
## EnableConfirmOrderButton(bool enable) -> void
---- Blindbag.BlindbagGameController::EnableConfirmOrderButton 0x2d4f5bc
02d4f5bc: stp     x30, x21, [sp, #-0x20]!                    
02d4f5c0: stp     x20, x19, [sp, #0x10]                      
02d4f5c4: adrp    x21, #0x6630000                            
02d4f5c8: mov     w19, w1                                    
02d4f5cc: mov     x20, x0                                    
02d4f5d0: ldrb    w8, [x21, #0x25e]                          
02d4f5d4: tbnz    w8, #0, #0x2d4f5ec                         
02d4f5d8: adrp    x0, #0x626b000                             
02d4f5dc: ldr     x0, [x0, #0x740]                           MS:UIManager::GetScreen
02d4f5e0: bl      #0x2b70db0                                 fn_2b70db0
02d4f5e4: mov     w8, #1                                     
02d4f5e8: strb    w8, [x21, #0x25e]                          
02d4f5ec: ldr     x0, [x20, #0x70]                           .UIManager
02d4f5f0: cbz     x0, #0x2d4f620                             
02d4f5f4: adrp    x8, #0x626b000                             
02d4f5f8: ldr     x8, [x8, #0x740]                           MS:UIManager::GetScreen
02d4f5fc: ldr     x1, [x8]                                   T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d4f600: bl      #0x33fbbd0                                 fn_33fbbd0
02d4f604: cbz     x0, #0x2d4f620                             
02d4f608: ldr     x0, [x0, #0x48]                            T:type56654(k15) ._orderBagPrefab
02d4f60c: cbz     x0, #0x2d4f620                             
02d4f610: and     w1, w19, #1                                
02d4f614: ldp     x20, x19, [sp, #0x10]                      
02d4f618: ldp     x30, x21, [sp], #0x20                      
02d4f61c: b       #0x2d57b24                                 Blindbag.MarketButton::EnableState
02d4f620: bl      #0x2b7105c                                 fn_2b7105c
## UpdateBasket() -> void
---- Blindbag.BlindbagGameController::UpdateBasket 0x2d4fdb4
02d4fdb4: stp     x30, x21, [sp, #-0x20]!                    
02d4fdb8: stp     x20, x19, [sp, #0x10]                      
02d4fdbc: adrp    x19, #0x6630000                            
02d4fdc0: mov     x20, x0                                    
02d4fdc4: ldrb    w8, [x19, #0x25f]                          
02d4fdc8: tbnz    w8, #0, #0x2d4fde0                         
02d4fdcc: adrp    x0, #0x626b000                             
02d4fdd0: ldr     x0, [x0, #0x740]                           MS:UIManager::GetScreen
02d4fdd4: bl      #0x2b70db0                                 fn_2b70db0
02d4fdd8: mov     w8, #1                                     
02d4fddc: strb    w8, [x19, #0x25f]                          
02d4fde0: ldr     x0, [x20, #0x38]                           ._basket
02d4fde4: cbz     x0, #0x2d4fe58                             
02d4fde8: bl      #0x2d4f740                                 Blindbag.Basket::GetTotalItem
02d4fdec: ldr     x8, [x20, #0x38]                           ._basket
02d4fdf0: cbz     x8, #0x2d4fe58                             
02d4fdf4: mov     w19, w0                                    
02d4fdf8: mov     x0, x8                                     
02d4fdfc: bl      #0x2d4f83c                                 Blindbag.Basket::GetTotalPrice
02d4fe00: ldr     x8, [x20, #0x70]                           .UIManager
02d4fe04: cbz     x8, #0x2d4fe58                             
02d4fe08: adrp    x9, #0x626b000                             
02d4fe0c: mov     w20, w0                                    
02d4fe10: mov     x0, x8                                     
02d4fe14: ldr     x9, [x9, #0x740]                           MS:UIManager::GetScreen
02d4fe18: ldr     x1, [x9]                                   T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d4fe1c: bl      #0x33fbbd0                                 fn_33fbbd0
02d4fe20: cbz     x0, #0x2d4fe58                             
02d4fe24: mov     w1, w19                                    
02d4fe28: mov     x21, x0                                    
02d4fe2c: bl      #0x2d51bd0                                 Blindbag.StoreScreen::SetItemCounter
02d4fe30: mov     x0, x21                                    
02d4fe34: mov     w1, w20                                    
02d4fe38: bl      #0x2d51c58                                 Blindbag.StoreScreen::SetPrice
02d4fe3c: ldr     x0, [x21, #0x48]                           ._orderBagPrefab
02d4fe40: cbz     x0, #0x2d4fe58                             
02d4fe44: cmp     w19, #0                                    
02d4fe48: ldp     x20, x19, [sp, #0x10]                      
02d4fe4c: cset    w1, gt                                     
02d4fe50: ldp     x30, x21, [sp], #0x20                      
02d4fe54: b       #0x2d57b24                                 Blindbag.MarketButton::EnableState
02d4fe58: bl      #0x2b7105c                                 fn_2b7105c
## OrderItemsHandler() -> void
---- Blindbag.BlindbagGameController::OrderItemsHandler 0x2d51ca0
02d51ca0: stp     x30, x23, [sp, #-0x30]!                    
02d51ca4: stp     x22, x21, [sp, #0x10]                      
02d51ca8: stp     x20, x19, [sp, #0x20]                      
02d51cac: adrp    x20, #0x6630000                            
02d51cb0: mov     x19, x0                                    
02d51cb4: ldrb    w8, [x20, #0x260]                          
02d51cb8: tbnz    w8, #0, #0x2d51d00                         
02d51cbc: adrp    x0, #0x626b000                             
02d51cc0: ldr     x0, [x0, #0x8d0]                           M:Blindbag.BlindbagGameController::<OrderItemsHandler>b__35_0
02d51cc4: bl      #0x2b70db0                                 fn_2b70db0
02d51cc8: adrp    x0, #0x6264000                             
02d51ccc: ldr     x0, [x0, #0xe8]                            T:DG.Tweening.TweenCallback
02d51cd0: bl      #0x2b70db0                                 fn_2b70db0
02d51cd4: adrp    x0, #0x6266000                             
02d51cd8: ldr     x0, [x0, #0x928]                           MS:DG.Tweening.TweenSettingsExtensions::OnComplete
02d51cdc: bl      #0x2b70db0                                 fn_2b70db0
02d51ce0: adrp    x0, #0x6266000                             
02d51ce4: ldr     x0, [x0, #0x880]                           MS:DG.Tweening.TweenSettingsExtensions::SetEase
02d51ce8: bl      #0x2b70db0                                 fn_2b70db0
02d51cec: adrp    x0, #0x626b000                             
02d51cf0: ldr     x0, [x0, #0x740]                           MS:UIManager::GetScreen
02d51cf4: bl      #0x2b70db0                                 fn_2b70db0
02d51cf8: mov     w8, #1                                     
02d51cfc: strb    w8, [x20, #0x260]                          
02d51d00: ldr     x0, [x19, #0x70]                           .UIManager
02d51d04: cbz     x0, #0x2d51dd8                             
02d51d08: adrp    x8, #0x626b000                             
02d51d0c: ldr     x8, [x8, #0x740]                           MS:UIManager::GetScreen
02d51d10: ldr     x1, [x8]                                   T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d51d14: bl      #0x33fbbd0                                 fn_33fbbd0
02d51d18: cbz     x0, #0x2d51dd8                             
02d51d1c: ldr     x0, [x0, #0x68]                            M:ScoopGame.CharmFlyToBasket/<>c__DisplayClass15_0::<ShowNewCharm>b__0 ._asset
02d51d20: cbz     x0, #0x2d51dd8                             
02d51d24: mov     w1, #1                                     
02d51d28: mov     x2, xzr                                    
02d51d2c: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d51d30: ldr     x0, [x19, #0x40]                           ._basketCollider
02d51d34: cbz     x0, #0x2d51dd8                             
02d51d38: mov     w1, wzr                                    
02d51d3c: mov     x2, xzr                                    
02d51d40: bl      #0x5b33110                                 UnityEngine.Behaviour::set_enabled
02d51d44: ldr     x0, [x19, #0x50]                           ._scanMachine
02d51d48: cbz     x0, #0x2d51dd8                             
02d51d4c: adrp    x20, #0x6266000                            
02d51d50: adrp    x21, #0x6264000                            
02d51d54: adrp    x22, #0x626b000                            
02d51d58: adrp    x23, #0x6266000                            
02d51d5c: ldr     x20, [x20, #0x880]                         MS:DG.Tweening.TweenSettingsExtensions::SetEase
02d51d60: ldr     x21, [x21, #0xe8]                          T:DG.Tweening.TweenCallback
02d51d64: ldr     x22, [x22, #0x8d0]                         M:Blindbag.BlindbagGameController::<OrderItemsHandler>b__35_0
02d51d68: ldr     x23, [x23, #0x928]                         MS:DG.Tweening.TweenSettingsExtensions::OnComplete
02d51d6c: mov     w1, #1                                     
02d51d70: bl      #0x2d5178c                                 Blindbag.ScanMachine::SetActive
02d51d74: fmov    s0, #-30.00000000                          
02d51d78: fmov    s1, #1.00000000                            
02d51d7c: ldr     x0, [x19, #0x60]                           ._tfShopAndTable
02d51d80: mov     w1, wzr                                    
02d51d84: mov     x2, xzr                                    
02d51d88: bl      #0x2d97eac                                 DG.Tweening.ShortcutExtensions::DOLocalMoveX
02d51d8c: ldr     x2, [x20]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d51d90: mov     w1, #1                                     
02d51d94: bl      #0x336fa0c                                 fn_336fa0c
02d51d98: ldr     x8, [x21]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d51d9c: mov     x20, x0                                    
02d51da0: mov     x0, x8                                     
02d51da4: bl      #0x2b7104c                                 fn_2b7104c
02d51da8: ldr     x2, [x22]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d51dac: mov     x1, x19                                    
02d51db0: mov     x3, xzr                                    
02d51db4: mov     x21, x0                                    
02d51db8: bl      #0x2d89dc4                                 DG.Tweening.TweenCallback::.ctor
02d51dbc: mov     x0, x20                                    
02d51dc0: mov     x1, x21                                    
02d51dc4: ldr     x2, [x23]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d51dc8: ldp     x20, x19, [sp, #0x20]                      
02d51dcc: ldp     x22, x21, [sp, #0x10]                      
02d51dd0: ldp     x30, x23, [sp], #0x30                      
02d51dd4: b       #0x336f26c                                 
02d51dd8: bl      #0x2b7105c                                 fn_2b7105c
## .ctor() -> void
---- Blindbag.BlindbagGameController::.ctor 0x2d51df8
02d51df8: mov     x1, xzr                                    
02d51dfc: b       #0x5b397b0                                 UnityEngine.MonoBehaviour::.ctor
## <OnOpenDoorHandler>b__27_0() -> void
---- Blindbag.BlindbagGameController::<OnOpenDoorHandler>b__27_0 0x2d51e00
02d51e00: str     x30, [sp, #-0x40]!                         
02d51e04: stp     x24, x23, [sp, #0x10]                      
02d51e08: stp     x22, x21, [sp, #0x20]                      
02d51e0c: stp     x20, x19, [sp, #0x30]                      
02d51e10: adrp    x20, #0x6630000                            
02d51e14: mov     x19, x0                                    
02d51e18: ldrb    w8, [x20, #0x261]                          
02d51e1c: tbnz    w8, #0, #0x2d51e7c                         
02d51e20: adrp    x0, #0x626b000                             
02d51e24: ldr     x0, [x0, #0x8d8]                           M:Blindbag.BlindbagGameController::BuyItemsCompletedHandler
02d51e28: bl      #0x2b70db0                                 fn_2b70db0
02d51e2c: adrp    x0, #0x626b000                             
02d51e30: ldr     x0, [x0, #0x8e0]                           M:Blindbag.BlindbagGameController::OrderItemsHandler
02d51e34: bl      #0x2b70db0                                 fn_2b70db0
02d51e38: adrp    x0, #0x626b000                             
02d51e3c: ldr     x0, [x0, #0x810]                           MS:Framework.GameObjectExtension::SetActive
02d51e40: bl      #0x2b70db0                                 fn_2b70db0
02d51e44: adrp    x0, #0x626a000                             
02d51e48: ldr     x0, [x0, #0x730]                           MS:MonoSingleton`1::get_Instance
02d51e4c: bl      #0x2b70db0                                 fn_2b70db0
02d51e50: adrp    x0, #0x626b000                             
02d51e54: ldr     x0, [x0, #0x8e8]                           MS:UIManager::HideScreen
02d51e58: bl      #0x2b70db0                                 fn_2b70db0
02d51e5c: adrp    x0, #0x626b000                             
02d51e60: ldr     x0, [x0, #0x8f0]                           MS:UIManager::ShowScreen
02d51e64: bl      #0x2b70db0                                 fn_2b70db0
02d51e68: adrp    x0, #0x6265000                             
02d51e6c: ldr     x0, [x0, #0x3f0]                           T:UnityEngine.Events.UnityAction
02d51e70: bl      #0x2b70db0                                 fn_2b70db0
02d51e74: mov     w8, #1                                     
02d51e78: strb    w8, [x20, #0x261]                          
02d51e7c: ldr     x0, [x19, #0x70]                           .UIManager
02d51e80: cbz     x0, #0x2d52018                             
02d51e84: adrp    x8, #0x626b000                             
02d51e88: ldr     x8, [x8, #0x8e8]                           MS:UIManager::HideScreen
02d51e8c: ldr     x1, [x8]                                   T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d51e90: bl      #0x33fbe70                                 fn_33fbe70
02d51e94: ldr     x0, [x19, #0x70]                           .UIManager
02d51e98: cbz     x0, #0x2d52018                             
02d51e9c: adrp    x8, #0x626b000                             
02d51ea0: ldr     x8, [x8, #0x8f0]                           MS:UIManager::ShowScreen
02d51ea4: ldr     x1, [x8]                                   T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d51ea8: bl      #0x33fc0e8                                 fn_33fc0e8
02d51eac: cbz     x0, #0x2d52018                             
02d51eb0: adrp    x24, #0x6265000                            
02d51eb4: adrp    x23, #0x626b000                            
02d51eb8: mov     x20, x0                                    
02d51ebc: ldr     x24, [x24, #0x3f0]                         T:UnityEngine.Events.UnityAction
02d51ec0: ldr     x23, [x23, #0x8e0]                         M:Blindbag.BlindbagGameController::OrderItemsHandler
02d51ec4: mov     x21, x0                                    
02d51ec8: ldr     x22, [x21, #0xb0]!                         
02d51ecc: ldr     x0, [x24]                                  M:AdsManager::<OnApplicationPause>b__26_0
02d51ed0: bl      #0x2b7104c                                 fn_2b7104c
02d51ed4: ldr     x2, [x23]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d51ed8: mov     x1, x19                                    
02d51edc: mov     x3, xzr                                    
02d51ee0: mov     x23, x0                                    
02d51ee4: bl      #0x5b4cf98                                 UnityEngine.Events.UnityAction::.ctor
02d51ee8: mov     x0, x22                                    
02d51eec: mov     x1, x23                                    
02d51ef0: mov     x2, xzr                                    
02d51ef4: bl      #0x4e570ac                                 System.Delegate::Combine
02d51ef8: mov     x8, x0                                     
02d51efc: cbz     x0, #0x2d51f24                             
02d51f00: ldr     x1, [x24]                                  M:AdsManager::<OnApplicationPause>b__26_0
02d51f04: ldr     x9, [x8]                                   T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d51f08: cmp     x9, x1                                     
02d51f0c: b.ne    #0x2d51f98                                 
02d51f10: str     x8, [x21]                                  
02d51f14: ldr     x9, [x8]                                   T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d51f18: cmp     x9, x1                                     
02d51f1c: b.eq    #0x2d51f28                                 
02d51f20: b       #0x2d51f98                                 
02d51f24: str     xzr, [x21]                                 
02d51f28: adrp    x23, #0x626b000                            
02d51f2c: mov     x0, x21                                    
02d51f30: mov     x1, x8                                     
02d51f34: ldr     x23, [x23, #0x8d8]                         M:Blindbag.BlindbagGameController::BuyItemsCompletedHandler
02d51f38: bl      #0x2b70d54                                 fn_2b70d54
02d51f3c: mov     x21, x20                                   
02d51f40: ldr     x0, [x24]                                  M:AdsManager::<OnApplicationPause>b__26_0
02d51f44: ldr     x22, [x21, #0xb8]!                         
02d51f48: bl      #0x2b7104c                                 fn_2b7104c
02d51f4c: ldr     x2, [x23]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d51f50: mov     x1, x19                                    
02d51f54: mov     x3, xzr                                    
02d51f58: mov     x23, x0                                    
02d51f5c: bl      #0x5b4cf98                                 UnityEngine.Events.UnityAction::.ctor
02d51f60: mov     x0, x22                                    
02d51f64: mov     x1, x23                                    
02d51f68: mov     x2, xzr                                    
02d51f6c: bl      #0x4e570ac                                 System.Delegate::Combine
02d51f70: mov     x8, x0                                     
02d51f74: cbz     x0, #0x2d51fa0                             
02d51f78: ldr     x1, [x24]                                  M:AdsManager::<OnApplicationPause>b__26_0
02d51f7c: ldr     x9, [x8]                                   T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d51f80: cmp     x9, x1                                     
02d51f84: b.ne    #0x2d51f98                                 
02d51f88: str     x8, [x21]                                  
02d51f8c: ldr     x9, [x8]                                   T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d51f90: cmp     x9, x1                                     
02d51f94: b.eq    #0x2d51fa4                                 
02d51f98: mov     x0, x8                                     
02d51f9c: bl      #0x2b713dc                                 fn_2b713dc
02d51fa0: str     xzr, [x21]                                 
02d51fa4: mov     x0, x21                                    
02d51fa8: mov     x1, x8                                     
02d51fac: bl      #0x2b70d54                                 fn_2b70d54
02d51fb0: ldr     x0, [x20, #0x60]                           ._tfShopAndTable
02d51fb4: cbz     x0, #0x2d52018                             
02d51fb8: adrp    x21, #0x626b000                            
02d51fbc: mov     w1, #1                                     
02d51fc0: mov     x2, xzr                                    
02d51fc4: ldr     x21, [x21, #0x810]                         MS:Framework.GameObjectExtension::SetActive
02d51fc8: mov     w20, #1                                    
02d51fcc: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d51fd0: ldr     x0, [x19, #0x58]                           ._door
02d51fd4: ldr     x2, [x21]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d51fd8: mov     w1, wzr                                    
02d51fdc: bl      #0x31d24a4                                 fn_31d24a4
02d51fe0: ldr     x8, [x19, #0x20]                           ._inputHandler
02d51fe4: cbz     x8, #0x2d52018                             
02d51fe8: adrp    x9, #0x626a000                             
02d51fec: ldr     x9, [x9, #0x730]                           MS:MonoSingleton`1::get_Instance
02d51ff0: strb    w20, [x8, #0x20]                           
02d51ff4: ldr     x0, [x9]                                   T:type56879(k15)
02d51ff8: bl      #0x3769600                                 fn_3769600
02d51ffc: cbz     x0, #0x2d52018                             
02d52000: ldp     x20, x19, [sp, #0x30]                      
02d52004: mov     w1, #1                                     
02d52008: ldp     x22, x21, [sp, #0x20]                      
02d5200c: ldp     x24, x23, [sp, #0x10]                      
02d52010: ldr     x30, [sp], #0x40                           
02d52014: b       #0x2d52038                                 Blindbag.TutorialBlindBag::ShowTutorialClickBagOnShelf
02d52018: bl      #0x2b7105c                                 fn_2b7105c
## <Initialized>b__30_0(Blindbag.ItemBase x) -> void
---- Blindbag.BlindbagGameController::<Initialized>b__30_0 0x2d52094
02d52094: cbz     x1, #0x2d520a8                             
02d52098: mov     x8, x0                                     
02d5209c: mov     x0, x1                                     
02d520a0: mov     x1, x8                                     
02d520a4: b       #0x2d520b0                                 Blindbag.ItemBase::OnInit
02d520a8: str     x30, [sp, #-0x10]!                         
02d520ac: bl      #0x2b7105c                                 fn_2b7105c
## <OrderItemsHandler>b__35_0() -> void
---- Blindbag.BlindbagGameController::<OrderItemsHandler>b__35_0 0x2d52138
02d52138: str     x30, [sp, #-0x30]!                         
02d5213c: stp     x22, x21, [sp, #0x10]                      
02d52140: stp     x20, x19, [sp, #0x20]                      
02d52144: adrp    x20, #0x6630000                            
02d52148: adrp    x21, #0x626a000                            
02d5214c: mov     x19, x0                                    
02d52150: ldrb    w8, [x20, #0x262]                          
02d52154: ldr     x21, [x21, #0x730]                         MS:MonoSingleton`1::get_Instance
02d52158: tbnz    w8, #0, #0x2d521a0                         
02d5215c: adrp    x0, #0x626b000                             
02d52160: ldr     x0, [x0, #0x8f8]                           M:Blindbag.BlindbagGameController::<OrderItemsHandler>b__35_1
02d52164: bl      #0x2b70db0                                 fn_2b70db0
02d52168: adrp    x0, #0x626a000                             
02d5216c: ldr     x0, [x0, #0x730]                           MS:MonoSingleton`1::get_Instance
02d52170: bl      #0x2b70db0                                 fn_2b70db0
02d52174: adrp    x0, #0x6264000                             
02d52178: ldr     x0, [x0, #0xe8]                            T:DG.Tweening.TweenCallback
02d5217c: bl      #0x2b70db0                                 fn_2b70db0
02d52180: adrp    x0, #0x6266000                             
02d52184: ldr     x0, [x0, #0x928]                           MS:DG.Tweening.TweenSettingsExtensions::OnComplete
02d52188: bl      #0x2b70db0                                 fn_2b70db0
02d5218c: adrp    x0, #0x626b000                             
02d52190: ldr     x0, [x0, #0x740]                           MS:UIManager::GetScreen
02d52194: bl      #0x2b70db0                                 fn_2b70db0
02d52198: mov     w8, #1                                     
02d5219c: strb    w8, [x20, #0x262]                          
02d521a0: ldr     x0, [x21]                                  T:type56879(k15)
02d521a4: bl      #0x3769600                                 fn_3769600
02d521a8: cbz     x0, #0x2d522b4                             
02d521ac: mov     w1, #1                                     
02d521b0: bl      #0x2d522b8                                 Blindbag.TutorialBlindBag::ShowTutorialScanItem
02d521b4: ldr     x0, [x19, #0x28]                           ._itemContainer
02d521b8: cbz     x0, #0x2d522b4                             
02d521bc: mov     x1, xzr                                    
02d521c0: bl      #0x5b339ec                                 UnityEngine.Component::get_gameObject
02d521c4: cbz     x0, #0x2d522b4                             
02d521c8: mov     w1, wzr                                    
02d521cc: mov     x2, xzr                                    
02d521d0: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d521d4: ldr     x0, [x19, #0x30]                           ._storeGo
02d521d8: cbz     x0, #0x2d522b4                             
02d521dc: mov     w1, wzr                                    
02d521e0: mov     x2, xzr                                    
02d521e4: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d521e8: ldr     x0, [x19, #0x38]                           ._basket
02d521ec: cbz     x0, #0x2d522b4                             
02d521f0: ldr     x20, [x19, #0x50]                          ._scanMachine
02d521f4: bl      #0x2d4f034                                 Blindbag.Basket::GetOrderingBags
02d521f8: cbz     x20, #0x2d522b4                            
02d521fc: mov     x1, x0                                     
02d52200: mov     x0, x20                                    
02d52204: bl      #0x2d52314                                 Blindbag.ScanMachine::SetData
02d52208: ldr     x0, [x19, #0x70]                           .UIManager
02d5220c: cbz     x0, #0x2d522b4                             
02d52210: adrp    x8, #0x626b000                             
02d52214: ldr     x8, [x8, #0x740]                           MS:UIManager::GetScreen
02d52218: ldr     x1, [x8]                                   T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d5221c: bl      #0x33fbbd0                                 fn_33fbbd0
02d52220: cbz     x0, #0x2d522b4                             
02d52224: ldr     x0, [x0, #0x68]                            M:ScoopGame.CharmFlyToBasket/<>c__DisplayClass15_0::<ShowNewCharm>b__0 ._asset
02d52228: cbz     x0, #0x2d522b4                             
02d5222c: mov     w1, wzr                                    
02d52230: mov     x2, xzr                                    
02d52234: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d52238: ldr     x0, [x19, #0x38]                           ._basket
02d5223c: cbz     x0, #0x2d522b4                             
02d52240: adrp    x20, #0x6264000                            
02d52244: adrp    x21, #0x626b000                            
02d52248: adrp    x22, #0x6266000                            
02d5224c: ldr     x20, [x20, #0xe8]                          T:DG.Tweening.TweenCallback
02d52250: ldr     x21, [x21, #0x8f8]                         M:Blindbag.BlindbagGameController::<OrderItemsHandler>b__35_1
02d52254: ldr     x22, [x22, #0x928]                         MS:DG.Tweening.TweenSettingsExtensions::OnComplete
02d52258: mov     x1, xzr                                    
02d5225c: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02d52260: fmov    s0, #-12.50000000                          
02d52264: fmov    s1, #1.00000000                            
02d52268: mov     w1, wzr                                    
02d5226c: mov     x2, xzr                                    
02d52270: bl      #0x2d98060                                 DG.Tweening.ShortcutExtensions::DOLocalMoveY
02d52274: ldr     x8, [x20]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d52278: mov     x20, x0                                    
02d5227c: mov     x0, x8                                     
02d52280: bl      #0x2b7104c                                 fn_2b7104c
02d52284: ldr     x2, [x21]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d52288: mov     x1, x19                                    
02d5228c: mov     x3, xzr                                    
02d52290: mov     x21, x0                                    
02d52294: bl      #0x2d89dc4                                 DG.Tweening.TweenCallback::.ctor
02d52298: ldr     x2, [x22]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d5229c: mov     x0, x20                                    
02d522a0: mov     x1, x21                                    
02d522a4: ldp     x20, x19, [sp, #0x20]                      
02d522a8: ldp     x22, x21, [sp, #0x10]                      
02d522ac: ldr     x30, [sp], #0x30                           
02d522b0: b       #0x336f26c                                 
02d522b4: bl      #0x2b7105c                                 fn_2b7105c
## <OrderItemsHandler>b__35_1() -> void
---- Blindbag.BlindbagGameController::<OrderItemsHandler>b__35_1 0x2d529cc
02d529cc: stp     x30, x21, [sp, #-0x20]!                    
02d529d0: stp     x20, x19, [sp, #0x10]                      
02d529d4: adrp    x21, #0x6630000                            
02d529d8: adrp    x20, #0x626b000                            
02d529dc: mov     x19, x0                                    
02d529e0: ldrb    w8, [x21, #0x263]                          
02d529e4: ldr     x20, [x20, #0x7f8]                         MS:Framework.GameObjectExtension::SetActive
02d529e8: tbnz    w8, #0, #0x2d52a00                         
02d529ec: adrp    x0, #0x626b000                             
02d529f0: ldr     x0, [x0, #0x7f8]                           MS:Framework.GameObjectExtension::SetActive
02d529f4: bl      #0x2b70db0                                 fn_2b70db0
02d529f8: mov     w8, #1                                     
02d529fc: strb    w8, [x21, #0x263]                          
02d52a00: ldr     x0, [x19, #0x38]                           ._basket
02d52a04: ldr     x2, [x20]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d52a08: mov     w1, wzr                                    
02d52a0c: ldp     x20, x19, [sp, #0x10]                      
02d52a10: ldp     x30, x21, [sp], #0x20                      
02d52a14: b       #0x31d24a4                                 
