#### CLASS PoolManager parent= MonoSingleton`1<PoolManager>
#   field poolAsset                      PoolAsset                                          off=0x20 attr=1 SerializeField
#   field poolDestroy                    PathologicalGames.SpawnPool                        off=0x28 attr=1 SerializeField
#   field poolDontDestroy                PathologicalGames.SpawnPool                        off=0x30 attr=1 SerializeField
## Initiate() -> void
---- PoolManager::Initiate 0x2cdcc14
02cdcc14: stp     x30, x21, [sp, #-0x20]!                    
02cdcc18: stp     x20, x19, [sp, #0x10]                      
02cdcc1c: adrp    x21, #0x662f000                            
02cdcc20: adrp    x20, #0x6263000                            
02cdcc24: mov     x19, x0                                    
02cdcc28: ldrb    w8, [x21, #0xd76]                          
02cdcc2c: ldr     x20, [x20, #0x918]                         T:UnityEngine.Object
02cdcc30: tbnz    w8, #0, #0x2cdcc48                         
02cdcc34: adrp    x0, #0x6263000                             
02cdcc38: ldr     x0, [x0, #0x918]                           T:UnityEngine.Object
02cdcc3c: bl      #0x2b70db0                                 fn_2b70db0
02cdcc40: mov     w8, #1                                     
02cdcc44: strb    w8, [x21, #0xd76]                          
02cdcc48: mov     x0, x19                                    
02cdcc4c: mov     x1, xzr                                    
02cdcc50: bl      #0x5b339ec                                 UnityEngine.Component::get_gameObject
02cdcc54: ldr     x8, [x20]                                  &2c5bbd4(=a9bd7bfdd503233f)
02cdcc58: mov     x19, x0                                    
02cdcc5c: ldr     w9, [x8, #0xe4]                            
02cdcc60: cbnz    w9, #0x2cdcc6c                             
02cdcc64: mov     x0, x8                                     
02cdcc68: bl      #0x2b70f30                                 fn_2b70f30
02cdcc6c: mov     x0, x19                                    
02cdcc70: ldp     x20, x19, [sp, #0x10]                      
02cdcc74: mov     x1, xzr                                    
02cdcc78: ldp     x30, x21, [sp], #0x20                      
02cdcc7c: b       #0x5b3ccec                                 UnityEngine.Object::DontDestroyOnLoad
## SpawnDontDestroy(UnityEngine.Transform prefab) -> UnityEngine.Transform
---- PoolManager::SpawnDontDestroy 0x2cdcc80
02cdcc80: str     x30, [sp, #-0x30]!                         
02cdcc84: stp     x22, x21, [sp, #0x10]                      
02cdcc88: stp     x20, x19, [sp, #0x20]                      
02cdcc8c: adrp    x21, #0x662f000                            
02cdcc90: adrp    x22, #0x6263000                            
02cdcc94: mov     x20, x1                                    
02cdcc98: ldrb    w8, [x21, #0xd77]                          
02cdcc9c: ldr     x22, [x22, #0x918]                         T:UnityEngine.Object
02cdcca0: mov     x19, x0                                    
02cdcca4: tbnz    w8, #0, #0x2cdccd4                         
02cdcca8: adrp    x0, #0x6263000                             
02cdccac: ldr     x0, [x0, #0x928]                           T:UnityEngine.Debug
02cdccb0: bl      #0x2b70db0                                 fn_2b70db0
02cdccb4: adrp    x0, #0x6263000                             
02cdccb8: ldr     x0, [x0, #0x918]                           T:UnityEngine.Object
02cdccbc: bl      #0x2b70db0                                 fn_2b70db0
02cdccc0: adrp    x0, #0x6267000                             
02cdccc4: ldr     x0, [x0, #0x948]                           S:'[error]Cant spawn, Missing prefab'
02cdccc8: bl      #0x2b70db0                                 fn_2b70db0
02cdcccc: mov     w8, #1                                     
02cdccd0: strb    w8, [x21, #0xd77]                          
02cdccd4: ldr     x0, [x22]                                  &2c5bbd4(=a9bd7bfdd503233f)
02cdccd8: ldr     w8, [x0, #0xe4]                            [62670e4]=0 f=0,0
02cdccdc: cbnz    w8, #0x2cdcce4                             
02cdcce0: bl      #0x2b70f30                                 fn_2b70f30
02cdcce4: mov     x0, x20                                    
02cdcce8: mov     x1, xzr                                    
02cdccec: mov     x2, xzr                                    
02cdccf0: bl      #0x5b37d84                                 UnityEngine.Object::op_Equality
02cdccf4: tbz     w0, #0, #0x2cdcd2c                         
02cdccf8: adrp    x8, #0x6263000                             
02cdccfc: adrp    x19, #0x6267000                            
02cdcd00: ldr     x8, [x8, #0x928]                           T:UnityEngine.Debug
02cdcd04: ldr     x0, [x8]                                   &2c5bbd4(=a9bd7bfdd503233f)
02cdcd08: ldr     w8, [x0, #0xe4]                            [62670e4]=0 f=0,0
02cdcd0c: ldr     x19, [x19, #0x948]                         S:'[error]Cant spawn, Missing prefab'
02cdcd10: cbnz    w8, #0x2cdcd18                             
02cdcd14: bl      #0x2b70f30                                 fn_2b70f30
02cdcd18: ldr     x0, [x19]                                  S:'didu'
02cdcd1c: mov     x1, xzr                                    
02cdcd20: bl      #0x5af2840                                 UnityEngine.Debug::LogError
02cdcd24: mov     x19, xzr                                   
02cdcd28: b       #0x2cdcd50                                 
02cdcd2c: ldr     x0, [x19, #0x30]                           MS:System.Nullable`1::get_HasValue .poolDontDestroy
02cdcd30: cbz     x0, #0x2cdcd64                             
02cdcd34: mov     x1, x20                                    
02cdcd38: mov     x2, xzr                                    
02cdcd3c: bl      #0x2cf84f4                                 PathologicalGames.SpawnPool::Spawn
02cdcd40: ldr     x2, [x19, #0x30]                           MS:System.Nullable`1::get_HasValue .poolDontDestroy
02cdcd44: mov     x1, x0                                     
02cdcd48: mov     x19, x0                                    
02cdcd4c: bl      #0x2cdcd68                                 PoolManager::AssignPool
02cdcd50: mov     x0, x19                                    
02cdcd54: ldp     x20, x19, [sp, #0x20]                      
02cdcd58: ldp     x22, x21, [sp, #0x10]                      
02cdcd5c: ldr     x30, [sp], #0x30                           
02cdcd60: ret                                                
02cdcd64: bl      #0x2b7105c                                 fn_2b7105c
## SpawnObject(PoolType poolType) -> UnityEngine.Transform
---- PoolManager::SpawnObject 0x2cdcdd4
02cdcdd4: stp     x30, x19, [sp, #-0x10]!                    
02cdcdd8: mov     x19, x0                                    
02cdcddc: ldr     x0, [x0, #0x20]                            .poolAsset
02cdcde0: cbz     x0, #0x2cdce04                             
02cdcde4: bl      #0x2cdc5dc                                 PoolAsset::GetPoolElement
02cdcde8: cbz     x0, #0x2cdce04                             
02cdcdec: mov     x1, xzr                                    
02cdcdf0: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02cdcdf4: mov     x1, x0                                     
02cdcdf8: mov     x0, x19                                    
02cdcdfc: ldp     x30, x19, [sp], #0x10                      
02cdce00: b       #0x2cdce08                                 PoolManager::SpawnObject
02cdce04: bl      #0x2b7105c                                 fn_2b7105c
## SpawnObject(PoolType poolType, UnityEngine.Vector3 position, UnityEngine.Quaternion rotation, UnityEngine.Transform parent) -> UnityEngine.Transform
---- PoolManager::SpawnObject 0x2cdcef0
02cdcef0: str     d14, [sp, #-0x50]!                         
02cdcef4: stp     d13, d12, [sp, #8]                         
02cdcef8: stp     d11, d10, [sp, #0x18]                      
02cdcefc: stp     d9, d8, [sp, #0x28]                        
02cdcf00: str     x30, [sp, #0x38]                           
02cdcf04: stp     x20, x19, [sp, #0x40]                      
02cdcf08: mov     x20, x0                                    
02cdcf0c: ldr     x0, [x0, #0x20]                            .poolAsset
02cdcf10: cbz     x0, #0x2cdcf88                             
02cdcf14: mov     x19, x2                                    
02cdcf18: fmov    s8, s6                                     
02cdcf1c: fmov    s9, s5                                     
02cdcf20: fmov    s10, s4                                    
02cdcf24: fmov    s11, s3                                    
02cdcf28: fmov    s12, s2                                    
02cdcf2c: fmov    s13, s1                                    
02cdcf30: fmov    s14, s0                                    
02cdcf34: bl      #0x2cdc5dc                                 PoolAsset::GetPoolElement
02cdcf38: cbz     x0, #0x2cdcf88                             
02cdcf3c: mov     x1, xzr                                    
02cdcf40: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02cdcf44: mov     x1, x0                                     
02cdcf48: mov     x0, x20                                    
02cdcf4c: fmov    s1, s13                                    
02cdcf50: fmov    s2, s12                                    
02cdcf54: fmov    s3, s11                                    
02cdcf58: fmov    s4, s10                                    
02cdcf5c: fmov    s5, s9                                     
02cdcf60: fmov    s6, s8                                     
02cdcf64: mov     x2, x19                                    
02cdcf68: ldp     x20, x19, [sp, #0x40]                      
02cdcf6c: ldr     x30, [sp, #0x38]                           
02cdcf70: ldp     d9, d8, [sp, #0x28]                        
02cdcf74: fmov    s0, s14                                    
02cdcf78: ldp     d11, d10, [sp, #0x18]                      
02cdcf7c: ldp     d13, d12, [sp, #8]                         
02cdcf80: ldr     d14, [sp], #0x50                           
02cdcf84: b       #0x2cd69bc                                 PoolManager::SpawnObject
02cdcf88: bl      #0x2b7105c                                 fn_2b7105c
## SpawnPoolElement(PoolType poolType) -> PoolElement
---- PoolManager::SpawnPoolElement 0x2cdcf8c
02cdcf8c: stp     x30, x21, [sp, #-0x20]!                    
02cdcf90: stp     x20, x19, [sp, #0x10]                      
02cdcf94: adrp    x21, #0x662f000                            
02cdcf98: mov     w20, w1                                    
02cdcf9c: mov     x19, x0                                    
02cdcfa0: ldrb    w8, [x21, #0xd78]                          
02cdcfa4: tbnz    w8, #0, #0x2cdcfbc                         
02cdcfa8: adrp    x0, #0x6267000                             
02cdcfac: ldr     x0, [x0, #0xd00]                           MS:UnityEngine.Component::GetComponent
02cdcfb0: bl      #0x2b70db0                                 fn_2b70db0
02cdcfb4: mov     w8, #1                                     
02cdcfb8: strb    w8, [x21, #0xd78]                          
02cdcfbc: ldr     x0, [x19, #0x20]                           .poolAsset
02cdcfc0: cbz     x0, #0x2cdd000                             
02cdcfc4: mov     w1, w20                                    
02cdcfc8: bl      #0x2cdc5dc                                 PoolAsset::GetPoolElement
02cdcfcc: cbz     x0, #0x2cdd000                             
02cdcfd0: mov     x1, xzr                                    
02cdcfd4: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02cdcfd8: mov     x1, x0                                     
02cdcfdc: mov     x0, x19                                    
02cdcfe0: bl      #0x2cdce08                                 PoolManager::SpawnObject
02cdcfe4: cbz     x0, #0x2cdd000                             
02cdcfe8: adrp    x8, #0x6267000                             
02cdcfec: ldr     x8, [x8, #0xd00]                           MS:UnityEngine.Component::GetComponent
02cdcff0: ldp     x20, x19, [sp, #0x10]                      
02cdcff4: ldr     x1, [x8]                                   S:'didu'
02cdcff8: ldp     x30, x21, [sp], #0x20                      
02cdcffc: b       #0x3140c84                                 
02cdd000: bl      #0x2b7105c                                 fn_2b7105c
## SpawnPoolElement(PoolType poolType, UnityEngine.Vector3 position, UnityEngine.Quaternion rotation, UnityEngine.Transform parent) -> PoolElement
---- PoolManager::SpawnPoolElement 0x2cdd004
02cdd004: str     d14, [sp, #-0x60]!                         
02cdd008: stp     d13, d12, [sp, #8]                         
02cdd00c: stp     d11, d10, [sp, #0x18]                      
02cdd010: stp     d9, d8, [sp, #0x28]                        
02cdd014: str     x30, [sp, #0x38]                           
02cdd018: stp     x22, x21, [sp, #0x40]                      
02cdd01c: stp     x20, x19, [sp, #0x50]                      
02cdd020: fmov    s8, s6                                     
02cdd024: fmov    s9, s5                                     
02cdd028: adrp    x22, #0x662f000                            
02cdd02c: fmov    s10, s4                                    
02cdd030: fmov    s11, s3                                    
02cdd034: ldrb    w8, [x22, #0xd79]                          
02cdd038: fmov    s12, s2                                    
02cdd03c: fmov    s13, s1                                    
02cdd040: mov     x19, x2                                    
02cdd044: fmov    s14, s0                                    
02cdd048: mov     w21, w1                                    
02cdd04c: mov     x20, x0                                    
02cdd050: tbnz    w8, #0, #0x2cdd068                         
02cdd054: adrp    x0, #0x6267000                             
02cdd058: ldr     x0, [x0, #0xd00]                           MS:UnityEngine.Component::GetComponent
02cdd05c: bl      #0x2b70db0                                 fn_2b70db0
02cdd060: mov     w8, #1                                     
02cdd064: strb    w8, [x22, #0xd79]                          
02cdd068: ldr     x0, [x20, #0x20]                           .poolAsset
02cdd06c: cbz     x0, #0x2cdd0e0                             
02cdd070: mov     w1, w21                                    
02cdd074: bl      #0x2cdc5dc                                 PoolAsset::GetPoolElement
02cdd078: cbz     x0, #0x2cdd0e0                             
02cdd07c: mov     x1, xzr                                    
02cdd080: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02cdd084: fmov    s0, s14                                    
02cdd088: fmov    s1, s13                                    
02cdd08c: mov     x1, x0                                     
02cdd090: fmov    s2, s12                                    
02cdd094: fmov    s3, s11                                    
02cdd098: mov     x0, x20                                    
02cdd09c: fmov    s4, s10                                    
02cdd0a0: fmov    s5, s9                                     
02cdd0a4: mov     x2, x19                                    
02cdd0a8: fmov    s6, s8                                     
02cdd0ac: bl      #0x2cd69bc                                 PoolManager::SpawnObject
02cdd0b0: cbz     x0, #0x2cdd0e0                             
02cdd0b4: adrp    x8, #0x6267000                             
02cdd0b8: ldr     x8, [x8, #0xd00]                           MS:UnityEngine.Component::GetComponent
02cdd0bc: ldp     x20, x19, [sp, #0x50]                      
02cdd0c0: ldp     x22, x21, [sp, #0x40]                      
02cdd0c4: ldr     x30, [sp, #0x38]                           
02cdd0c8: ldp     d9, d8, [sp, #0x28]                        
02cdd0cc: ldr     x1, [x8]                                   S:'didu'
02cdd0d0: ldp     d11, d10, [sp, #0x18]                      
02cdd0d4: ldp     d13, d12, [sp, #8]                         
02cdd0d8: ldr     d14, [sp], #0x60                           
02cdd0dc: b       #0x3140c84                                 
02cdd0e0: bl      #0x2b7105c                                 fn_2b7105c
## SpawnObject(UnityEngine.Transform prefab) -> UnityEngine.Transform
---- PoolManager::SpawnObject 0x2cdce08
02cdce08: str     x30, [sp, #-0x30]!                         
02cdce0c: stp     x22, x21, [sp, #0x10]                      
02cdce10: stp     x20, x19, [sp, #0x20]                      
02cdce14: adrp    x21, #0x662f000                            
02cdce18: adrp    x22, #0x6263000                            
02cdce1c: mov     x20, x1                                    
02cdce20: ldrb    w8, [x21, #0xd7a]                          
02cdce24: ldr     x22, [x22, #0x918]                         T:UnityEngine.Object
02cdce28: mov     x19, x0                                    
02cdce2c: tbnz    w8, #0, #0x2cdce5c                         
02cdce30: adrp    x0, #0x6263000                             
02cdce34: ldr     x0, [x0, #0x928]                           T:UnityEngine.Debug
02cdce38: bl      #0x2b70db0                                 fn_2b70db0
02cdce3c: adrp    x0, #0x6263000                             
02cdce40: ldr     x0, [x0, #0x918]                           T:UnityEngine.Object
02cdce44: bl      #0x2b70db0                                 fn_2b70db0
02cdce48: adrp    x0, #0x6267000                             
02cdce4c: ldr     x0, [x0, #0x948]                           S:'[error]Cant spawn, Missing prefab'
02cdce50: bl      #0x2b70db0                                 fn_2b70db0
02cdce54: mov     w8, #1                                     
02cdce58: strb    w8, [x21, #0xd7a]                          
02cdce5c: ldr     x0, [x22]                                  &2c5bbd4(=a9bd7bfdd503233f)
02cdce60: ldr     w8, [x0, #0xe4]                            [62670e4]=0 f=0,0
02cdce64: cbnz    w8, #0x2cdce6c                             
02cdce68: bl      #0x2b70f30                                 fn_2b70f30
02cdce6c: mov     x0, x20                                    
02cdce70: mov     x1, xzr                                    
02cdce74: mov     x2, xzr                                    
02cdce78: bl      #0x5b37d84                                 UnityEngine.Object::op_Equality
02cdce7c: tbz     w0, #0, #0x2cdceb4                         
02cdce80: adrp    x8, #0x6263000                             
02cdce84: adrp    x19, #0x6267000                            
02cdce88: ldr     x8, [x8, #0x928]                           T:UnityEngine.Debug
02cdce8c: ldr     x0, [x8]                                   &2c5bbd4(=a9bd7bfdd503233f)
02cdce90: ldr     w8, [x0, #0xe4]                            [62670e4]=0 f=0,0
02cdce94: ldr     x19, [x19, #0x948]                         S:'[error]Cant spawn, Missing prefab'
02cdce98: cbnz    w8, #0x2cdcea0                             
02cdce9c: bl      #0x2b70f30                                 fn_2b70f30
02cdcea0: ldr     x0, [x19]                                  S:'didu'
02cdcea4: mov     x1, xzr                                    
02cdcea8: bl      #0x5af2840                                 UnityEngine.Debug::LogError
02cdceac: mov     x19, xzr                                   
02cdceb0: b       #0x2cdced8                                 
02cdceb4: ldr     x0, [x19, #0x28]                           S:'[^A-Za-z0-9_. ]+' .poolDestroy
02cdceb8: cbz     x0, #0x2cdceec                             
02cdcebc: mov     x1, x20                                    
02cdcec0: mov     x2, xzr                                    
02cdcec4: bl      #0x2cf84f4                                 PathologicalGames.SpawnPool::Spawn
02cdcec8: ldr     x2, [x19, #0x28]                           S:'[^A-Za-z0-9_. ]+' .poolDestroy
02cdcecc: mov     x1, x0                                     
02cdced0: mov     x19, x0                                    
02cdced4: bl      #0x2cdcd68                                 PoolManager::AssignPool
02cdced8: mov     x0, x19                                    
02cdcedc: ldp     x20, x19, [sp, #0x20]                      
02cdcee0: ldp     x22, x21, [sp, #0x10]                      
02cdcee4: ldr     x30, [sp], #0x30                           
02cdcee8: ret                                                
02cdceec: bl      #0x2b7105c                                 fn_2b7105c
## SpawnObject(UnityEngine.Transform prefab, UnityEngine.Vector3 position, UnityEngine.Quaternion rotation) -> UnityEngine.Transform
---- PoolManager::SpawnObject 0x2cdd0e4
02cdd0e4: str     d14, [sp, #-0x60]!                         
02cdd0e8: stp     d13, d12, [sp, #8]                         
02cdd0ec: stp     d11, d10, [sp, #0x18]                      
02cdd0f0: stp     d9, d8, [sp, #0x28]                        
02cdd0f4: str     x30, [sp, #0x38]                           
02cdd0f8: stp     x22, x21, [sp, #0x40]                      
02cdd0fc: stp     x20, x19, [sp, #0x50]                      
02cdd100: fmov    s8, s6                                     
02cdd104: fmov    s9, s5                                     
02cdd108: adrp    x21, #0x662f000                            
02cdd10c: fmov    s10, s4                                    
02cdd110: fmov    s11, s3                                    
02cdd114: adrp    x22, #0x6263000                            
02cdd118: fmov    s12, s2                                    
02cdd11c: fmov    s13, s1                                    
02cdd120: ldrb    w8, [x21, #0xd7b]                          
02cdd124: fmov    s14, s0                                    
02cdd128: ldr     x22, [x22, #0x918]                         T:UnityEngine.Object
02cdd12c: mov     x20, x1                                    
02cdd130: mov     x19, x0                                    
02cdd134: tbnz    w8, #0, #0x2cdd164                         
02cdd138: adrp    x0, #0x6263000                             
02cdd13c: ldr     x0, [x0, #0x928]                           T:UnityEngine.Debug
02cdd140: bl      #0x2b70db0                                 fn_2b70db0
02cdd144: adrp    x0, #0x6263000                             
02cdd148: ldr     x0, [x0, #0x918]                           T:UnityEngine.Object
02cdd14c: bl      #0x2b70db0                                 fn_2b70db0
02cdd150: adrp    x0, #0x6267000                             
02cdd154: ldr     x0, [x0, #0x948]                           S:'[error]Cant spawn, Missing prefab'
02cdd158: bl      #0x2b70db0                                 fn_2b70db0
02cdd15c: mov     w8, #1                                     
02cdd160: strb    w8, [x21, #0xd7b]                          
02cdd164: ldr     x0, [x22]                                  &2c5bbd4(=a9bd7bfdd503233f)
02cdd168: ldr     w8, [x0, #0xe4]                            [62670e4]=0 f=0,0
02cdd16c: cbnz    w8, #0x2cdd174                             
02cdd170: bl      #0x2b70f30                                 fn_2b70f30
02cdd174: mov     x0, x20                                    
02cdd178: mov     x1, xzr                                    
02cdd17c: mov     x2, xzr                                    
02cdd180: bl      #0x5b37d84                                 UnityEngine.Object::op_Equality
02cdd184: tbz     w0, #0, #0x2cdd1bc                         
02cdd188: adrp    x8, #0x6263000                             
02cdd18c: adrp    x19, #0x6267000                            
02cdd190: ldr     x8, [x8, #0x928]                           T:UnityEngine.Debug
02cdd194: ldr     x0, [x8]                                   &2c5bbd4(=a9bd7bfdd503233f)
02cdd198: ldr     w8, [x0, #0xe4]                            [62670e4]=0 f=0,0
02cdd19c: ldr     x19, [x19, #0x948]                         S:'[error]Cant spawn, Missing prefab'
02cdd1a0: cbnz    w8, #0x2cdd1a8                             
02cdd1a4: bl      #0x2b70f30                                 fn_2b70f30
02cdd1a8: ldr     x0, [x19]                                  S:'didu'
02cdd1ac: mov     x1, xzr                                    
02cdd1b0: bl      #0x5af2840                                 UnityEngine.Debug::LogError
02cdd1b4: mov     x19, xzr                                   
02cdd1b8: b       #0x2cdd1fc                                 
02cdd1bc: ldr     x0, [x19, #0x28]                           S:'[^A-Za-z0-9_. ]+' .poolDestroy
02cdd1c0: cbz     x0, #0x2cdd220                             
02cdd1c4: fmov    s0, s14                                    
02cdd1c8: fmov    s1, s13                                    
02cdd1cc: mov     x1, x20                                    
02cdd1d0: fmov    s2, s12                                    
02cdd1d4: fmov    s3, s11                                    
02cdd1d8: mov     x2, xzr                                    
02cdd1dc: fmov    s4, s10                                    
02cdd1e0: fmov    s5, s9                                     
02cdd1e4: fmov    s6, s8                                     
02cdd1e8: bl      #0x2cf8410                                 PathologicalGames.SpawnPool::Spawn
02cdd1ec: ldr     x2, [x19, #0x28]                           S:'[^A-Za-z0-9_. ]+' .poolDestroy
02cdd1f0: mov     x1, x0                                     
02cdd1f4: mov     x19, x0                                    
02cdd1f8: bl      #0x2cdcd68                                 PoolManager::AssignPool
02cdd1fc: mov     x0, x19                                    
02cdd200: ldp     x20, x19, [sp, #0x50]                      
02cdd204: ldp     x22, x21, [sp, #0x40]                      
02cdd208: ldr     x30, [sp, #0x38]                           
02cdd20c: ldp     d9, d8, [sp, #0x28]                        
02cdd210: ldp     d11, d10, [sp, #0x18]                      
02cdd214: ldp     d13, d12, [sp, #8]                         
02cdd218: ldr     d14, [sp], #0x60                           
02cdd21c: ret                                                
02cdd220: bl      #0x2b7105c                                 fn_2b7105c
## SpawnObject(UnityEngine.Transform prefab, UnityEngine.Vector3 position, UnityEngine.Quaternion rotation, UnityEngine.Transform parent) -> UnityEngine.Transform
---- PoolManager::SpawnObject 0x2cd69bc
02cd69bc: str     d14, [sp, #-0x70]!                         
02cd69c0: stp     d13, d12, [sp, #0x10]                      
02cd69c4: stp     d11, d10, [sp, #0x20]                      
02cd69c8: stp     d9, d8, [sp, #0x30]                        
02cd69cc: stp     x30, x23, [sp, #0x40]                      
02cd69d0: stp     x22, x21, [sp, #0x50]                      
02cd69d4: stp     x20, x19, [sp, #0x60]                      
02cd69d8: fmov    s8, s6                                     
02cd69dc: fmov    s9, s5                                     
02cd69e0: adrp    x22, #0x662f000                            
02cd69e4: fmov    s10, s4                                    
02cd69e8: fmov    s11, s3                                    
02cd69ec: adrp    x23, #0x6263000                            
02cd69f0: fmov    s12, s2                                    
02cd69f4: fmov    s13, s1                                    
02cd69f8: ldrb    w8, [x22, #0xd7c]                          
02cd69fc: fmov    s14, s0                                    
02cd6a00: ldr     x23, [x23, #0x918]                         T:UnityEngine.Object
02cd6a04: mov     x19, x2                                    
02cd6a08: mov     x21, x1                                    
02cd6a0c: mov     x20, x0                                    
02cd6a10: tbnz    w8, #0, #0x2cd6a40                         
02cd6a14: adrp    x0, #0x6263000                             
02cd6a18: ldr     x0, [x0, #0x928]                           T:UnityEngine.Debug
02cd6a1c: bl      #0x2b70db0                                 fn_2b70db0
02cd6a20: adrp    x0, #0x6263000                             
02cd6a24: ldr     x0, [x0, #0x918]                           T:UnityEngine.Object
02cd6a28: bl      #0x2b70db0                                 fn_2b70db0
02cd6a2c: adrp    x0, #0x6267000                             
02cd6a30: ldr     x0, [x0, #0x948]                           S:'[error]Cant spawn, Missing prefab'
02cd6a34: bl      #0x2b70db0                                 fn_2b70db0
02cd6a38: mov     w8, #1                                     
02cd6a3c: strb    w8, [x22, #0xd7c]                          
02cd6a40: ldr     x0, [x23]                                  &2c5bbd4(=a9bd7bfdd503233f)
02cd6a44: ldr     w8, [x0, #0xe4]                            [62670e4]=0 f=0,0
02cd6a48: cbnz    w8, #0x2cd6a50                             
02cd6a4c: bl      #0x2b70f30                                 fn_2b70f30
02cd6a50: mov     x0, x21                                    
02cd6a54: mov     x1, xzr                                    
02cd6a58: mov     x2, xzr                                    
02cd6a5c: bl      #0x5b37d84                                 UnityEngine.Object::op_Equality
02cd6a60: tbz     w0, #0, #0x2cd6a98                         
02cd6a64: adrp    x8, #0x6263000                             
02cd6a68: adrp    x19, #0x6267000                            
02cd6a6c: ldr     x8, [x8, #0x928]                           T:UnityEngine.Debug
02cd6a70: ldr     x0, [x8]                                   &2c5bbd4(=a9bd7bfdd503233f)
02cd6a74: ldr     w8, [x0, #0xe4]                            [62670e4]=0 f=0,0
02cd6a78: ldr     x19, [x19, #0x948]                         S:'[error]Cant spawn, Missing prefab'
02cd6a7c: cbnz    w8, #0x2cd6a84                             
02cd6a80: bl      #0x2b70f30                                 fn_2b70f30
02cd6a84: ldr     x0, [x19]                                  S:'didu'
02cd6a88: mov     x1, xzr                                    
02cd6a8c: bl      #0x5af2840                                 UnityEngine.Debug::LogError
02cd6a90: mov     x19, xzr                                   
02cd6a94: b       #0x2cd6adc                                 
02cd6a98: ldr     x0, [x20, #0x28]                           .poolDestroy
02cd6a9c: cbz     x0, #0x2cd6b00                             
02cd6aa0: fmov    s0, s14                                    
02cd6aa4: fmov    s1, s13                                    
02cd6aa8: mov     x1, x21                                    
02cd6aac: fmov    s2, s12                                    
02cd6ab0: fmov    s3, s11                                    
02cd6ab4: mov     x2, x19                                    
02cd6ab8: fmov    s4, s10                                    
02cd6abc: fmov    s5, s9                                     
02cd6ac0: mov     x3, xzr                                    
02cd6ac4: fmov    s6, s8                                     
02cd6ac8: bl      #0x2cf7b50                                 PathologicalGames.SpawnPool::Spawn
02cd6acc: ldr     x2, [x20, #0x28]                           .poolDestroy
02cd6ad0: mov     x1, x0                                     
02cd6ad4: mov     x19, x0                                    
02cd6ad8: bl      #0x2cdcd68                                 PoolManager::AssignPool
02cd6adc: mov     x0, x19                                    
02cd6ae0: ldp     x20, x19, [sp, #0x60]                      
02cd6ae4: ldp     x22, x21, [sp, #0x50]                      
02cd6ae8: ldp     x30, x23, [sp, #0x40]                      
02cd6aec: ldp     d9, d8, [sp, #0x30]                        
02cd6af0: ldp     d11, d10, [sp, #0x20]                      
02cd6af4: ldp     d13, d12, [sp, #0x10]                      
02cd6af8: ldr     d14, [sp], #0x70                           
02cd6afc: ret                                                
02cd6b00: bl      #0x2b7105c                                 fn_2b7105c
## AssignPool(UnityEngine.Transform clone, PathologicalGames.SpawnPool pool) -> UnityEngine.Transform
---- PoolManager::AssignPool 0x2cdcd68
02cdcd68: stp     x30, x21, [sp, #-0x20]!                    
02cdcd6c: stp     x20, x19, [sp, #0x10]                      
02cdcd70: adrp    x21, #0x662f000                            
02cdcd74: mov     x20, x2                                    
02cdcd78: mov     x19, x1                                    
02cdcd7c: ldrb    w8, [x21, #0xd7d]                          
02cdcd80: tbnz    w8, #0, #0x2cdcd98                         
02cdcd84: adrp    x0, #0x6267000                             
02cdcd88: ldr     x0, [x0, #0xd00]                           MS:UnityEngine.Component::GetComponent
02cdcd8c: bl      #0x2b70db0                                 fn_2b70db0
02cdcd90: mov     w8, #1                                     
02cdcd94: strb    w8, [x21, #0xd7d]                          
02cdcd98: cbz     x19, #0x2cdcdd0                            
02cdcd9c: adrp    x8, #0x6267000                             
02cdcda0: mov     x0, x19                                    
02cdcda4: ldr     x8, [x8, #0xd00]                           MS:UnityEngine.Component::GetComponent
02cdcda8: ldr     x1, [x8]                                   S:'didu'
02cdcdac: bl      #0x3140c84                                 fn_3140c84
02cdcdb0: cbz     x0, #0x2cdcdc0                             
02cdcdb4: mov     x1, x20                                    
02cdcdb8: str     x20, [x0, #0x20]!                          .poolAsset
02cdcdbc: bl      #0x2b70d54                                 fn_2b70d54
02cdcdc0: mov     x0, x19                                    
02cdcdc4: ldp     x20, x19, [sp, #0x10]                      
02cdcdc8: ldp     x30, x21, [sp], #0x20                      
02cdcdcc: ret                                                
02cdcdd0: bl      #0x2b7105c                                 fn_2b7105c
## DeSpawnAll() -> void
---- PoolManager::DeSpawnAll 0x2cdd224
02cdd224: ldr     x0, [x0, #0x28]                            .poolDestroy
02cdd228: cbz     x0, #0x2cdd234                             
02cdd22c: mov     x1, xzr                                    
02cdd230: b       #0x2cf934c                                 PathologicalGames.SpawnPool::DespawnAll
02cdd234: ret                                                
## DespawnObject(UnityEngine.Transform clone) -> void
---- PoolManager::DespawnObject 0x2cdc9f4
02cdc9f4: stp     x30, x21, [sp, #-0x20]!                    
02cdc9f8: stp     x20, x19, [sp, #0x10]                      
02cdc9fc: adrp    x21, #0x662f000                            
02cdca00: mov     x19, x1                                    
02cdca04: mov     x20, x0                                    
02cdca08: ldrb    w8, [x21, #0xd7e]                          
02cdca0c: tbnz    w8, #0, #0x2cdca24                         
02cdca10: adrp    x0, #0x6263000                             
02cdca14: ldr     x0, [x0, #0x918]                           T:UnityEngine.Object
02cdca18: bl      #0x2b70db0                                 fn_2b70db0
02cdca1c: mov     w8, #1                                     
02cdca20: strb    w8, [x21, #0xd7e]                          
02cdca24: ldr     x0, [x20, #0x28]                           .poolDestroy
02cdca28: cbz     x0, #0x2cdcadc                             
02cdca2c: mov     x1, x19                                    
02cdca30: mov     x2, xzr                                    
02cdca34: bl      #0x2cf9428                                 PathologicalGames.SpawnPool::IsSpawned
02cdca38: tbz     w0, #0, #0x2cdca7c                         
02cdca3c: ldr     x0, [x20, #0x28]                           .poolDestroy
02cdca40: cbz     x0, #0x2cdcadc                             
02cdca44: mov     x1, x19                                    
02cdca48: mov     x2, xzr                                    
02cdca4c: bl      #0x2cf8fb4                                 PathologicalGames.SpawnPool::Despawn
02cdca50: ldr     x0, [x20, #0x28]                           .poolDestroy
02cdca54: cbz     x0, #0x2cdcadc                             
02cdca58: mov     x1, xzr                                    
02cdca5c: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02cdca60: cbz     x19, #0x2cdcadc                            
02cdca64: mov     x1, x0                                     
02cdca68: mov     x0, x19                                    
02cdca6c: mov     x2, xzr                                    
02cdca70: ldp     x20, x19, [sp, #0x10]                      
02cdca74: ldp     x30, x21, [sp], #0x20                      
02cdca78: b       #0x5b472ec                                 UnityEngine.Transform::SetParent
02cdca7c: adrp    x8, #0x6263000                             
02cdca80: ldr     x8, [x8, #0x918]                           T:UnityEngine.Object
02cdca84: ldr     x0, [x8]                                   &2c5bbd4(=a9bd7bfdd503233f)
02cdca88: ldr     w8, [x0, #0xe4]                            [62630e4]=0 f=0,0
02cdca8c: cbnz    w8, #0x2cdca94                             
02cdca90: bl      #0x2b70f30                                 fn_2b70f30
02cdca94: mov     x0, x19                                    
02cdca98: mov     x1, xzr                                    
02cdca9c: mov     x2, xzr                                    
02cdcaa0: bl      #0x5b3666c                                 UnityEngine.Object::op_Inequality
02cdcaa4: tbz     w0, #0, #0x2cdcad0                         
02cdcaa8: cbz     x19, #0x2cdcadc                            
02cdcaac: mov     x0, x19                                    
02cdcab0: mov     x1, xzr                                    
02cdcab4: bl      #0x5b339ec                                 UnityEngine.Component::get_gameObject
02cdcab8: cbz     x0, #0x2cdcadc                             
02cdcabc: ldp     x20, x19, [sp, #0x10]                      
02cdcac0: mov     w1, wzr                                    
02cdcac4: mov     x2, xzr                                    
02cdcac8: ldp     x30, x21, [sp], #0x20                      
02cdcacc: b       #0x5b36b38                                 UnityEngine.GameObject::SetActive
02cdcad0: ldp     x20, x19, [sp, #0x10]                      
02cdcad4: ldp     x30, x21, [sp], #0x20                      
02cdcad8: ret                                                
02cdcadc: bl      #0x2b7105c                                 fn_2b7105c
## .ctor() -> void
---- PoolManager::.ctor 0x2cdd238
02cdd238: stp     x30, x21, [sp, #-0x20]!                    
02cdd23c: stp     x20, x19, [sp, #0x10]                      
02cdd240: adrp    x20, #0x662f000                            
02cdd244: adrp    x21, #0x6267000                            
02cdd248: mov     x19, x0                                    
02cdd24c: ldrb    w8, [x20, #0xd7f]                          
02cdd250: ldr     x21, [x21, #0xd08]                         MS:MonoSingleton`1::.ctor
02cdd254: tbnz    w8, #0, #0x2cdd26c                         
02cdd258: adrp    x0, #0x6267000                             
02cdd25c: ldr     x0, [x0, #0xd08]                           MS:MonoSingleton`1::.ctor
02cdd260: bl      #0x2b70db0                                 fn_2b70db0
02cdd264: mov     w8, #1                                     
02cdd268: strb    w8, [x20, #0xd7f]                          
02cdd26c: mov     x0, x19                                    
02cdd270: ldp     x20, x19, [sp, #0x10]                      
02cdd274: ldr     x1, [x21]                                  S:'didu'
02cdd278: ldp     x30, x21, [sp], #0x20                      
02cdd27c: b       #0x3769e18                                 
