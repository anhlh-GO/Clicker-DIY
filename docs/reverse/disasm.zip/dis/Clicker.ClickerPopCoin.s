#### CLASS Clicker.ClickerPopCoin/<>c__DisplayClass11_0 parent= object
#   field <>4__this                      Clicker.ClickerPopCoin                             off=0x10 attr=6 
#   field coinInstance                   PoolElement                                        off=0x18 attr=6 
## .ctor() -> void
---- Clicker.ClickerPopCoin/<>c__DisplayClass11_0::.ctor 0x2d5da98
02d5da98: mov     x1, xzr                                    
02d5da9c: b       #0x4e53e9c                                 System.Object::.ctor
## <SpawnOneCoin>b__0() -> void
---- Clicker.ClickerPopCoin/<>c__DisplayClass11_0::<SpawnOneCoin>b__0 0x2d5de1c
02d5de1c: ldr     x8, [x0, #0x10]                            .<>4__this
02d5de20: cbz     x8, #0x2d5de30                             
02d5de24: ldr     x1, [x0, #0x18]                            .coinInstance
02d5de28: mov     x0, x8                                     
02d5de2c: b       #0x2d5db64                                 Clicker.ClickerPopCoin::MoveCoinTask
02d5de30: str     x30, [sp, #-0x10]!                         
02d5de34: bl      #0x2b7105c                                 fn_2b7105c
#### CLASS Clicker.ClickerPopCoin/<>c__DisplayClass12_0 parent= object
#   field coinInstance                   PoolElement                                        off=0x10 attr=6 
#   field <>4__this                      Clicker.ClickerPopCoin                             off=0x18 attr=6 
## .ctor() -> void
---- Clicker.ClickerPopCoin/<>c__DisplayClass12_0::.ctor 0x2d5dcc0
02d5dcc0: mov     x1, xzr                                    
02d5dcc4: b       #0x4e53e9c                                 System.Object::.ctor
## <MoveCoinTask>b__0() -> void
---- Clicker.ClickerPopCoin/<>c__DisplayClass12_0::<MoveCoinTask>b__0 0x2d5de38
02d5de38: stp     x30, x21, [sp, #-0x20]!                    
02d5de3c: stp     x20, x19, [sp, #0x10]                      
02d5de40: adrp    x20, #0x6630000                            
02d5de44: mov     x19, x0                                    
02d5de48: ldrb    w8, [x20, #0x2df]                          
02d5de4c: tbnz    w8, #0, #0x2d5de64                         
02d5de50: adrp    x0, #0x6263000                             
02d5de54: ldr     x0, [x0, #0x918]                           T:UnityEngine.Object
02d5de58: bl      #0x2b70db0                                 fn_2b70db0
02d5de5c: mov     w8, #1                                     
02d5de60: strb    w8, [x20, #0x2df]                          
02d5de64: mov     x0, xzr                                    
02d5de68: bl      #0x2d6eec8                                 Framework.AudioManager::get_Instance
02d5de6c: cbz     x0, #0x2d5df1c                             
02d5de70: movi    d1, #0000000000000000                      
02d5de74: movi    d2, #0000000000000000                      
02d5de78: adrp    x8, #0x1084000                             
02d5de7c: adrp    x21, #0x6263000                            
02d5de80: ldr     s0, [x8, #0xf10]                           [1084f10]=4110bc863e99999a f=0.3,9.04603
02d5de84: mov     w1, #6                                     
02d5de88: ldr     x21, [x21, #0x918]                         T:UnityEngine.Object
02d5de8c: mov     w2, wzr                                    
02d5de90: mov     w3, wzr                                    
02d5de94: mov     x4, xzr                                    
02d5de98: bl      #0x2d6f03c                                 Framework.AudioManager::PlaySound
02d5de9c: ldr     x0, [x21]                                  &2c5bbd4(=a9bd7bfdd503233f)
02d5dea0: ldr     x20, [x19, #0x10]                          .coinInstance
02d5dea4: ldr     w8, [x0, #0xe4]                            [62630e4]=0 f=0,0
02d5dea8: cbnz    w8, #0x2d5deb0                             
02d5deac: bl      #0x2b70f30                                 fn_2b70f30
02d5deb0: mov     x0, x20                                    
02d5deb4: mov     x1, xzr                                    
02d5deb8: bl      #0x5b3bb1c                                 UnityEngine.Object::op_Implicit
02d5debc: tbz     w0, #0, #0x2d5df08                         
02d5dec0: ldr     x0, [x19, #0x10]                           .coinInstance
02d5dec4: cbz     x0, #0x2d5df1c                             
02d5dec8: mov     x1, xzr                                    
02d5decc: bl      #0x5b339ec                                 UnityEngine.Component::get_gameObject
02d5ded0: ldr     x8, [x21]                                  &2c5bbd4(=a9bd7bfdd503233f)
02d5ded4: mov     x20, x0                                    
02d5ded8: ldr     w9, [x8, #0xe4]                            [10840e4]=2c2644327265746c f=4.54482e+30,2.36279e-12
02d5dedc: cbnz    w9, #0x2d5dee8                             
02d5dee0: mov     x0, x8                                     
02d5dee4: bl      #0x2b70f30                                 fn_2b70f30
02d5dee8: mov     x0, x20                                    
02d5deec: mov     x1, xzr                                    
02d5def0: bl      #0x5b3bb1c                                 UnityEngine.Object::op_Implicit
02d5def4: tbz     w0, #0, #0x2d5df08                         
02d5def8: ldr     x0, [x19, #0x10]                           .coinInstance
02d5defc: cbz     x0, #0x2d5df1c                             
02d5df00: mov     x1, xzr                                    
02d5df04: bl      #0x2cdc880                                 PoolElement::DespawnSelf
02d5df08: ldr     x0, [x19, #0x18]                           .<>4__this
02d5df0c: cbz     x0, #0x2d5df1c                             
02d5df10: ldp     x20, x19, [sp, #0x10]                      
02d5df14: ldp     x30, x21, [sp], #0x20                      
02d5df18: b       #0x2d5dcc8                                 Clicker.ClickerPopCoin::ReactToCollectionCoin
02d5df1c: bl      #0x2b7105c                                 fn_2b7105c
#### CLASS Clicker.ClickerPopCoin parent= MonoSingleton`1<Clicker.ClickerPopCoin>
#   field _prefabType                    PoolType                                           off=0x20 attr=1 SerializeField
#   field _coinParent                    UnityEngine.Transform                              off=0x28 attr=1 SerializeField
#   field _rectCoinHolder                UnityEngine.RectTransform                          off=0x30 attr=1 SerializeField
#   field _endPosition                   UnityEngine.RectTransform                          off=0x38 attr=1 SerializeField
#   field _coinLabel                     UnityEngine.RectTransform                          off=0x40 attr=1 SerializeField
#   field _duration                      float                                              off=0x48 attr=1 SerializeField
#   field _uiCamera                      UnityEngine.Camera                                 off=0x50 attr=1 SerializeField
#   field _minX                          float                                              off=0x58 attr=1 HeaderAttribute,SerializeField
#   field _maxX                          float                                              off=0x5c attr=1 SerializeField
#   field _minY                          float                                              off=0x60 attr=1 SerializeField
#   field _maxY                          float                                              off=0x64 attr=1 SerializeField
## SpawnOneCoin(UnityEngine.Vector3 spawnPos) -> void
---- Clicker.ClickerPopCoin::SpawnOneCoin 0x2d5d7c4
02d5d7c4: str     d12, [sp, #-0x60]!                         
02d5d7c8: stp     d11, d10, [sp, #8]                         
02d5d7cc: stp     d9, d8, [sp, #0x18]                        
02d5d7d0: str     x30, [sp, #0x28]                           
02d5d7d4: stp     x24, x23, [sp, #0x30]                      
02d5d7d8: stp     x22, x21, [sp, #0x40]                      
02d5d7dc: stp     x20, x19, [sp, #0x50]                      
02d5d7e0: fmov    s8, s2                                     
02d5d7e4: fmov    s9, s1                                     
02d5d7e8: adrp    x19, #0x6630000                            
02d5d7ec: fmov    s10, s0                                    
02d5d7f0: adrp    x21, #0x626b000                            
02d5d7f4: ldrb    w8, [x19, #0x2da]                          
02d5d7f8: ldr     x21, [x21, #0xdd0]                         T:Clicker.ClickerPopCoin/<>c__DisplayClass11_0
02d5d7fc: mov     x20, x0                                    
02d5d800: tbnz    w8, #0, #0x2d5d848                         
02d5d804: adrp    x0, #0x6266000                             
02d5d808: ldr     x0, [x0, #0xd20]                           MS:MonoSingleton`1::get_Instance
02d5d80c: bl      #0x2b70db0                                 fn_2b70db0
02d5d810: adrp    x0, #0x6264000                             
02d5d814: ldr     x0, [x0, #0xe8]                            T:DG.Tweening.TweenCallback
02d5d818: bl      #0x2b70db0                                 fn_2b70db0
02d5d81c: adrp    x0, #0x6266000                             
02d5d820: ldr     x0, [x0, #0xa88]                           MS:DG.Tweening.TweenSettingsExtensions::OnComplete
02d5d824: bl      #0x2b70db0                                 fn_2b70db0
02d5d828: adrp    x0, #0x626b000                             
02d5d82c: ldr     x0, [x0, #0xdd8]                           M:Clicker.ClickerPopCoin/<>c__DisplayClass11_0::<SpawnOneCoin>b__0
02d5d830: bl      #0x2b70db0                                 fn_2b70db0
02d5d834: adrp    x0, #0x626b000                             
02d5d838: ldr     x0, [x0, #0xdd0]                           T:Clicker.ClickerPopCoin/<>c__DisplayClass11_0
02d5d83c: bl      #0x2b70db0                                 fn_2b70db0
02d5d840: mov     w8, #1                                     
02d5d844: strb    w8, [x19, #0x2da]                          
02d5d848: ldr     x0, [x21]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d5d84c: bl      #0x2b7104c                                 fn_2b7104c
02d5d850: mov     x1, xzr                                    
02d5d854: mov     x19, x0                                    
02d5d858: bl      #0x4e53e9c                                 System.Object::.ctor
02d5d85c: cbz     x19, #0x2d5da94                            
02d5d860: adrp    x21, #0x6266000                            
02d5d864: mov     x0, x19                                    
02d5d868: mov     x1, x20                                    
02d5d86c: ldr     x21, [x21, #0xd20]                         MS:MonoSingleton`1::get_Instance
02d5d870: str     x20, [x0, #0x10]!                          
02d5d874: bl      #0x2b70d54                                 fn_2b70d54
02d5d878: fmov    s0, s10                                    
02d5d87c: fmov    s1, s9                                     
02d5d880: ldr     x1, [x20, #0x30]                           ._rectCoinHolder
02d5d884: fmov    s2, s8                                     
02d5d888: mov     x0, x20                                    
02d5d88c: bl      #0x2d5daa0                                 Clicker.ClickerPopCoin::WorldToCanvasLocal
02d5d890: ldr     x0, [x21]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d5d894: fmov    s8, s0                                     
02d5d898: fmov    s9, s1                                     
02d5d89c: bl      #0x3769600                                 fn_3769600
02d5d8a0: adrp    x23, #0x662f000                            
02d5d8a4: ldr     w21, [x20, #0x20]                          ._prefabType
02d5d8a8: mov     x22, x0                                    
02d5d8ac: ldrb    w8, [x23, #0x91a]                          
02d5d8b0: cbnz    w8, #0x2d5d8c8                             
02d5d8b4: adrp    x0, #0x6264000                             
02d5d8b8: ldr     x0, [x0, #0xd8]                            T:UnityEngine.Vector3
02d5d8bc: bl      #0x2b70db0                                 fn_2b70db0
02d5d8c0: mov     w8, #1                                     
02d5d8c4: strb    w8, [x23, #0x91a]                          
02d5d8c8: adrp    x23, #0x6264000                            
02d5d8cc: adrp    x24, #0x662f000                            
02d5d8d0: ldr     x23, [x23, #0xd8]                          T:UnityEngine.Vector3
02d5d8d4: ldrb    w9, [x24, #0xbdf]                          
02d5d8d8: ldr     x8, [x23]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d5d8dc: ldr     x8, [x8, #0xb8]                            
02d5d8e0: ldp     s10, s11, [x8]                             
02d5d8e4: ldr     s12, [x8, #8]                              
02d5d8e8: cbnz    w9, #0x2d5d900                             
02d5d8ec: adrp    x0, #0x6266000                             
02d5d8f0: ldr     x0, [x0, #0xd30]                           T:UnityEngine.Quaternion
02d5d8f4: bl      #0x2b70db0                                 fn_2b70db0
02d5d8f8: mov     w8, #1                                     
02d5d8fc: strb    w8, [x24, #0xbdf]                          
02d5d900: cbz     x22, #0x2d5da94                            
02d5d904: adrp    x8, #0x6266000                             
02d5d908: fmov    s0, s10                                    
02d5d90c: fmov    s1, s11                                    
02d5d910: ldr     x8, [x8, #0xd30]                           T:UnityEngine.Quaternion
02d5d914: fmov    s2, s12                                    
02d5d918: ldr     x2, [x20, #0x28]                           ._coinParent
02d5d91c: mov     x0, x22                                    
02d5d920: mov     w1, w21                                    
02d5d924: mov     x3, xzr                                    
02d5d928: ldr     x8, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d5d92c: ldr     x8, [x8, #0xb8]                            S:'banner_native_refresh_time'
02d5d930: ldp     s5, s6, [x8, #8]                           
02d5d934: ldp     s3, s4, [x8]                               
02d5d938: bl      #0x2cdd004                                 PoolManager::SpawnPoolElement
02d5d93c: mov     x21, x19                                   
02d5d940: mov     x1, x0                                     
02d5d944: str     x0, [x21, #0x18]!                          
02d5d948: mov     x0, x21                                    
02d5d94c: bl      #0x2b70d54                                 fn_2b70d54
02d5d950: ldr     x0, [x21]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d5d954: cbz     x0, #0x2d5da94                             
02d5d958: mov     x1, xzr                                    
02d5d95c: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02d5d960: adrp    x24, #0x662f000                            
02d5d964: mov     x22, x0                                    
02d5d968: ldrb    w8, [x24, #0xa74]                          
02d5d96c: cbnz    w8, #0x2d5d984                             
02d5d970: adrp    x0, #0x6264000                             
02d5d974: ldr     x0, [x0, #0xd8]                            T:UnityEngine.Vector3
02d5d978: bl      #0x2b70db0                                 fn_2b70db0
02d5d97c: mov     w8, #1                                     
02d5d980: strb    w8, [x24, #0xa74]                          
02d5d984: cbz     x22, #0x2d5da94                            
02d5d988: ldr     x8, [x23]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d5d98c: mov     x0, x22                                    
02d5d990: mov     x1, xzr                                    
02d5d994: ldr     x8, [x8, #0xb8]                            S:'banner_native_refresh_time'
02d5d998: ldp     s1, s2, [x8, #0x10]                        
02d5d99c: ldr     s0, [x8, #0xc]                             [626600c]=0 f=0,0
02d5d9a0: bl      #0x5b470cc                                 UnityEngine.Transform::set_localScale
02d5d9a4: ldr     x0, [x21]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d5d9a8: cbz     x0, #0x2d5da94                             
02d5d9ac: mov     x1, xzr                                    
02d5d9b0: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02d5d9b4: cbz     x0, #0x2d5da94                             
02d5d9b8: movi    d2, #0000000000000000                      
02d5d9bc: fmov    s0, s8                                     
02d5d9c0: mov     x1, xzr                                    
02d5d9c4: fmov    s1, s9                                     
02d5d9c8: bl      #0x5b45cec                                 UnityEngine.Transform::set_localPosition
02d5d9cc: ldp     s0, s1, [x20, #0x58]                       ._minX
02d5d9d0: mov     x0, xzr                                    
02d5d9d4: bl      #0x5b2dfc0                                 UnityEngine.Random::Range
02d5d9d8: ldp     s2, s1, [x20, #0x60]                       ._minY
02d5d9dc: fmov    s10, s0                                    
02d5d9e0: mov     x0, xzr                                    
02d5d9e4: fmov    s0, s2                                     
02d5d9e8: bl      #0x5b2dfc0                                 UnityEngine.Random::Range
02d5d9ec: ldr     x0, [x21]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d5d9f0: cbz     x0, #0x2d5da94                             
02d5d9f4: adrp    x20, #0x6264000                            
02d5d9f8: adrp    x21, #0x626b000                            
02d5d9fc: adrp    x22, #0x6266000                            
02d5da00: ldr     x20, [x20, #0xe8]                          T:DG.Tweening.TweenCallback
02d5da04: ldr     x21, [x21, #0xdd8]                         M:Clicker.ClickerPopCoin/<>c__DisplayClass11_0::<SpawnOneCoin>b__0
02d5da08: ldr     x22, [x22, #0xa88]                         MS:DG.Tweening.TweenSettingsExtensions::OnComplete
02d5da0c: mov     x1, xzr                                    
02d5da10: fadd    s9, s9, s0                                 
02d5da14: fadd    s8, s8, s10                                
02d5da18: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02d5da1c: movi    d2, #0000000000000000                      
02d5da20: fmov    s0, s8                                     
02d5da24: adrp    x8, #0x1084000                             
02d5da28: fmov    s1, s9                                     
02d5da2c: fmov    s3, #10.00000000                           
02d5da30: ldr     s4, [x8, #0xdd8]                           [1084dd8]=3f7333333e4ccccd f=0.2,0.95
02d5da34: mov     w1, #1                                     
02d5da38: mov     w2, wzr                                    
02d5da3c: mov     x3, xzr                                    
02d5da40: bl      #0x2d9b130                                 DG.Tweening.ShortcutExtensions::DOLocalJump
02d5da44: ldr     x8, [x20]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d5da48: mov     x20, x0                                    
02d5da4c: mov     x0, x8                                     
02d5da50: bl      #0x2b7104c                                 fn_2b7104c
02d5da54: ldr     x2, [x21]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d5da58: mov     x1, x19                                    
02d5da5c: mov     x3, xzr                                    
02d5da60: mov     x21, x0                                    
02d5da64: bl      #0x2d89dc4                                 DG.Tweening.TweenCallback::.ctor
02d5da68: ldr     x2, [x22]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d5da6c: mov     x0, x20                                    
02d5da70: mov     x1, x21                                    
02d5da74: ldp     x20, x19, [sp, #0x50]                      
02d5da78: ldr     x30, [sp, #0x28]                           
02d5da7c: ldp     x22, x21, [sp, #0x40]                      
02d5da80: ldp     x24, x23, [sp, #0x30]                      
02d5da84: ldp     d9, d8, [sp, #0x18]                        
02d5da88: ldp     d11, d10, [sp, #8]                         
02d5da8c: ldr     d12, [sp], #0x60                           
02d5da90: b       #0x336f26c                                 
02d5da94: bl      #0x2b7105c                                 fn_2b7105c
## MoveCoinTask(PoolElement coinInstance) -> void
---- Clicker.ClickerPopCoin::MoveCoinTask 0x2d5db64
02d5db64: stp     x30, x25, [sp, #-0x40]!                    
02d5db68: stp     x24, x23, [sp, #0x10]                      
02d5db6c: stp     x22, x21, [sp, #0x20]                      
02d5db70: stp     x20, x19, [sp, #0x30]                      
02d5db74: adrp    x20, #0x6630000                            
02d5db78: adrp    x22, #0x626b000                            
02d5db7c: mov     x21, x1                                    
02d5db80: ldrb    w8, [x20, #0x2db]                          
02d5db84: ldr     x22, [x22, #0xde0]                         T:Clicker.ClickerPopCoin/<>c__DisplayClass12_0
02d5db88: mov     x19, x0                                    
02d5db8c: tbnz    w8, #0, #0x2d5dbd4                         
02d5db90: adrp    x0, #0x6264000                             
02d5db94: ldr     x0, [x0, #0xe8]                            T:DG.Tweening.TweenCallback
02d5db98: bl      #0x2b70db0                                 fn_2b70db0
02d5db9c: adrp    x0, #0x6266000                             
02d5dba0: ldr     x0, [x0, #0x928]                           MS:DG.Tweening.TweenSettingsExtensions::OnComplete
02d5dba4: bl      #0x2b70db0                                 fn_2b70db0
02d5dba8: adrp    x0, #0x6266000                             
02d5dbac: ldr     x0, [x0, #0x880]                           MS:DG.Tweening.TweenSettingsExtensions::SetEase
02d5dbb0: bl      #0x2b70db0                                 fn_2b70db0
02d5dbb4: adrp    x0, #0x626b000                             
02d5dbb8: ldr     x0, [x0, #0xde8]                           M:Clicker.ClickerPopCoin/<>c__DisplayClass12_0::<MoveCoinTask>b__0
02d5dbbc: bl      #0x2b70db0                                 fn_2b70db0
02d5dbc0: adrp    x0, #0x626b000                             
02d5dbc4: ldr     x0, [x0, #0xde0]                           T:Clicker.ClickerPopCoin/<>c__DisplayClass12_0
02d5dbc8: bl      #0x2b70db0                                 fn_2b70db0
02d5dbcc: mov     w8, #1                                     
02d5dbd0: strb    w8, [x20, #0x2db]                          
02d5dbd4: ldr     x0, [x22]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d5dbd8: bl      #0x2b7104c                                 fn_2b7104c
02d5dbdc: mov     x1, xzr                                    
02d5dbe0: mov     x20, x0                                    
02d5dbe4: bl      #0x4e53e9c                                 System.Object::.ctor
02d5dbe8: cbz     x20, #0x2d5dcbc                            
02d5dbec: mov     x22, x20                                   
02d5dbf0: mov     x1, x21                                    
02d5dbf4: str     x21, [x22, #0x10]!                         
02d5dbf8: mov     x0, x22                                    
02d5dbfc: bl      #0x2b70d54                                 fn_2b70d54
02d5dc00: mov     x0, x20                                    
02d5dc04: mov     x1, x19                                    
02d5dc08: str     x19, [x0, #0x18]!                          
02d5dc0c: bl      #0x2b70d54                                 fn_2b70d54
02d5dc10: ldr     x0, [x22]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d5dc14: cbz     x0, #0x2d5dcbc                             
02d5dc18: mov     x1, xzr                                    
02d5dc1c: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02d5dc20: ldr     x8, [x19, #0x38]                           ._endPosition
02d5dc24: cbz     x8, #0x2d5dcbc                             
02d5dc28: adrp    x22, #0x6266000                            
02d5dc2c: adrp    x23, #0x6264000                            
02d5dc30: adrp    x24, #0x626b000                            
02d5dc34: adrp    x25, #0x6266000                            
02d5dc38: mov     x21, x0                                    
02d5dc3c: ldr     x22, [x22, #0x880]                         MS:DG.Tweening.TweenSettingsExtensions::SetEase
02d5dc40: ldr     x23, [x23, #0xe8]                          T:DG.Tweening.TweenCallback
02d5dc44: ldr     x24, [x24, #0xde8]                         M:Clicker.ClickerPopCoin/<>c__DisplayClass12_0::<MoveCoinTask>b__0
02d5dc48: ldr     x25, [x25, #0x928]                         MS:DG.Tweening.TweenSettingsExtensions::OnComplete
02d5dc4c: mov     x0, x8                                     
02d5dc50: mov     x1, xzr                                    
02d5dc54: bl      #0x5b45c24                                 UnityEngine.Transform::get_localPosition
02d5dc58: ldr     s3, [x19, #0x48]                           ._duration
02d5dc5c: mov     x0, x21                                    
02d5dc60: mov     w1, wzr                                    
02d5dc64: mov     x2, xzr                                    
02d5dc68: bl      #0x2d97cf0                                 DG.Tweening.ShortcutExtensions::DOLocalMove
02d5dc6c: ldr     x2, [x22]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d5dc70: mov     w1, #0x1a                                  
02d5dc74: bl      #0x336fa0c                                 fn_336fa0c
02d5dc78: ldr     x8, [x23]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d5dc7c: mov     x19, x0                                    
02d5dc80: mov     x0, x8                                     
02d5dc84: bl      #0x2b7104c                                 fn_2b7104c
02d5dc88: ldr     x2, [x24]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d5dc8c: mov     x1, x20                                    
02d5dc90: mov     x3, xzr                                    
02d5dc94: mov     x21, x0                                    
02d5dc98: bl      #0x2d89dc4                                 DG.Tweening.TweenCallback::.ctor
02d5dc9c: mov     x0, x19                                    
02d5dca0: mov     x1, x21                                    
02d5dca4: ldr     x2, [x25]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d5dca8: ldp     x20, x19, [sp, #0x30]                      
02d5dcac: ldp     x22, x21, [sp, #0x20]                      
02d5dcb0: ldp     x24, x23, [sp, #0x10]                      
02d5dcb4: ldp     x30, x25, [sp], #0x40                      
02d5dcb8: b       #0x336f26c                                 
02d5dcbc: bl      #0x2b7105c                                 fn_2b7105c
## ReactToCollectionCoin() -> void
---- Clicker.ClickerPopCoin::ReactToCollectionCoin 0x2d5dcc8
02d5dcc8: str     x30, [sp, #-0x30]!                         
02d5dccc: stp     x22, x21, [sp, #0x10]                      
02d5dcd0: stp     x20, x19, [sp, #0x20]                      
02d5dcd4: adrp    x20, #0x6630000                            
02d5dcd8: mov     x19, x0                                    
02d5dcdc: ldrb    w8, [x20, #0x2dc]                          
02d5dce0: tbnz    w8, #0, #0x2d5dd04                         
02d5dce4: adrp    x0, #0x6266000                             
02d5dce8: ldr     x0, [x0, #0xaa0]                           MS:MonoSingleton`1::get_Instance
02d5dcec: bl      #0x2b70db0                                 fn_2b70db0
02d5dcf0: adrp    x0, #0x6264000                             
02d5dcf4: ldr     x0, [x0, #0x108]                           MS:DG.Tweening.TweenSettingsExtensions::SetEase
02d5dcf8: bl      #0x2b70db0                                 fn_2b70db0
02d5dcfc: mov     w8, #1                                     
02d5dd00: strb    w8, [x20, #0x2dc]                          
02d5dd04: ldr     x0, [x19, #0x40]                           ._coinLabel
02d5dd08: mov     w1, wzr                                    
02d5dd0c: mov     x2, xzr                                    
02d5dd10: bl      #0x2d9d5d0                                 DG.Tweening.ShortcutExtensions::DOKill
02d5dd14: adrp    x21, #0x662f000                            
02d5dd18: ldr     x20, [x19, #0x40]                          ._coinLabel
02d5dd1c: ldrb    w8, [x21, #0xa74]                          
02d5dd20: cbnz    w8, #0x2d5dd38                             
02d5dd24: adrp    x0, #0x6264000                             
02d5dd28: ldr     x0, [x0, #0xd8]                            T:UnityEngine.Vector3
02d5dd2c: bl      #0x2b70db0                                 fn_2b70db0
02d5dd30: mov     w8, #1                                     
02d5dd34: strb    w8, [x21, #0xa74]                          
02d5dd38: cbz     x20, #0x2d5ddc8                            
02d5dd3c: adrp    x8, #0x6264000                             
02d5dd40: adrp    x21, #0x6264000                            
02d5dd44: adrp    x22, #0x6266000                            
02d5dd48: ldr     x8, [x8, #0xd8]                            T:UnityEngine.Vector3
02d5dd4c: mov     x0, x20                                    
02d5dd50: mov     x1, xzr                                    
02d5dd54: ldr     x8, [x8]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d5dd58: ldr     x21, [x21, #0x108]                         MS:DG.Tweening.TweenSettingsExtensions::SetEase
02d5dd5c: ldr     x8, [x8, #0xb8]                            MS:DG.Tweening.Core.Extensions::SetSpecialStartupMode
02d5dd60: ldr     x22, [x22, #0xaa0]                         MS:MonoSingleton`1::get_Instance
02d5dd64: ldp     s1, s2, [x8, #0x10]                        
02d5dd68: ldr     s0, [x8, #0xc]                             [626400c]=0 f=0,0
02d5dd6c: bl      #0x5b470cc                                 UnityEngine.Transform::set_localScale
02d5dd70: adrp    x8, #0x1084000                             
02d5dd74: fmov    s0, #0.50000000                            
02d5dd78: fmov    s1, #0.50000000                            
02d5dd7c: fmov    s2, #0.50000000                            
02d5dd80: fmov    s4, #1.00000000                            
02d5dd84: ldr     x0, [x19, #0x40]                           ._coinLabel
02d5dd88: ldr     s3, [x8, #0xeec]                           [1084eec]=457ff0003dcccccd f=0.1,4095
02d5dd8c: mov     w1, #0xa                                   
02d5dd90: mov     x2, xzr                                    
02d5dd94: bl      #0x2d9982c                                 DG.Tweening.ShortcutExtensions::DOPunchScale
02d5dd98: ldr     x2, [x21]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d5dd9c: mov     w1, #0x19                                  
02d5dda0: bl      #0x336fa0c                                 fn_336fa0c
02d5dda4: ldr     x0, [x22]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d5dda8: bl      #0x3769600                                 fn_3769600
02d5ddac: cbz     x0, #0x2d5ddc8                             
02d5ddb0: ldp     x20, x19, [sp, #0x20]                      
02d5ddb4: mov     w1, #1                                     
02d5ddb8: ldp     x22, x21, [sp, #0x10]                      
02d5ddbc: mov     x2, xzr                                    
02d5ddc0: ldr     x30, [sp], #0x30                           
02d5ddc4: b       #0x2cdac78                                 MoneyManager::UpdateMoney
02d5ddc8: bl      #0x2b7105c                                 fn_2b7105c
## WorldToCanvasLocal(UnityEngine.Vector3 worldPos, UnityEngine.RectTransform targetRect) -> UnityEngine.Vector2
---- Clicker.ClickerPopCoin::WorldToCanvasLocal 0x2d5daa0
02d5daa0: str     d10, [sp, #-0x40]!                         
02d5daa4: stp     d9, d8, [sp, #0x10]                        
02d5daa8: stp     x30, x21, [sp, #0x20]                      
02d5daac: stp     x20, x19, [sp, #0x30]                      
02d5dab0: fmov    s8, s2                                     
02d5dab4: fmov    s9, s1                                     
02d5dab8: adrp    x21, #0x6630000                            
02d5dabc: fmov    s10, s0                                    
02d5dac0: ldrb    w8, [x21, #0x2dd]                          
02d5dac4: mov     x19, x1                                    
02d5dac8: mov     x20, x0                                    
02d5dacc: tbnz    w8, #0, #0x2d5dae4                         
02d5dad0: adrp    x0, #0x6264000                             
02d5dad4: ldr     x0, [x0, #0x790]                           T:UnityEngine.RectTransformUtility
02d5dad8: bl      #0x2b70db0                                 fn_2b70db0
02d5dadc: mov     w8, #1                                     
02d5dae0: strb    w8, [x21, #0x2dd]                          
02d5dae4: mov     x0, xzr                                    
02d5dae8: str     xzr, [sp, #8]                              
02d5daec: bl      #0x5aefe28                                 UnityEngine.Camera::get_main
02d5daf0: cbz     x0, #0x2d5db60                             
02d5daf4: fmov    s0, s10                                    
02d5daf8: fmov    s1, s9                                     
02d5dafc: adrp    x21, #0x6264000                            
02d5db00: fmov    s2, s8                                     
02d5db04: ldr     x21, [x21, #0x790]                         T:UnityEngine.RectTransformUtility
02d5db08: mov     x1, xzr                                    
02d5db0c: bl      #0x5aefba0                                 UnityEngine.Camera::WorldToScreenPoint
02d5db10: fmov    s8, s0                                     
02d5db14: ldr     x0, [x21]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d5db18: fmov    s9, s1                                     
02d5db1c: ldr     x20, [x20, #0x50]                          ._uiCamera
02d5db20: ldr     w8, [x0, #0xe4]                            [62640e4]=0 f=0,0
02d5db24: cbnz    w8, #0x2d5db2c                             
02d5db28: bl      #0x2b70f30                                 fn_2b70f30
02d5db2c: fmov    s0, s8                                     
02d5db30: fmov    s1, s9                                     
02d5db34: add     x2, sp, #8                                 
02d5db38: mov     x0, x19                                    
02d5db3c: mov     x1, x20                                    
02d5db40: mov     x3, xzr                                    
02d5db44: bl      #0x5e47a80                                 UnityEngine.RectTransformUtility::ScreenPointToLocalPointInRectangle
02d5db48: ldp     s0, s1, [sp, #8]                           
02d5db4c: ldp     x20, x19, [sp, #0x30]                      
02d5db50: ldp     x30, x21, [sp, #0x20]                      
02d5db54: ldp     d9, d8, [sp, #0x10]                        
02d5db58: ldr     d10, [sp], #0x40                           
02d5db5c: ret                                                
02d5db60: bl      #0x2b7105c                                 fn_2b7105c
## .ctor() -> void
---- Clicker.ClickerPopCoin::.ctor 0x2d5ddcc
02d5ddcc: stp     x30, x21, [sp, #-0x20]!                    
02d5ddd0: stp     x20, x19, [sp, #0x10]                      
02d5ddd4: adrp    x21, #0x6630000                            
02d5ddd8: adrp    x20, #0x626b000                            
02d5dddc: mov     x19, x0                                    
02d5dde0: ldrb    w8, [x21, #0x2de]                          
02d5dde4: ldr     x20, [x20, #0xdf0]                         MS:MonoSingleton`1::.ctor
02d5dde8: tbnz    w8, #0, #0x2d5de00                         
02d5ddec: adrp    x0, #0x626b000                             
02d5ddf0: ldr     x0, [x0, #0xdf0]                           MS:MonoSingleton`1::.ctor
02d5ddf4: bl      #0x2b70db0                                 fn_2b70db0
02d5ddf8: mov     w8, #1                                     
02d5ddfc: strb    w8, [x21, #0x2de]                          
02d5de00: mov     w8, #5                                     
02d5de04: ldr     x1, [x20]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d5de08: mov     x0, x19                                    
02d5de0c: str     w8, [x19, #0x20]                           ._prefabType
02d5de10: ldp     x20, x19, [sp, #0x10]                      
02d5de14: ldp     x30, x21, [sp], #0x20                      
02d5de18: b       #0x3769e18                                 
