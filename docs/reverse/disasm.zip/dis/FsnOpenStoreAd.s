#### CLASS FsnOpenStoreAd parent= object
#   field androidOpenStoreAd             UnityEngine.AndroidJavaObject                      off=0x10 attr=1 
#   field onFsnLoadListener              AndroidOnFsnLoadListener                           off=0x18 attr=1 
#   field onFsnCompletedListener         AndroidOnFsnCompletedListener                      off=0x20 attr=1 
## .ctor() -> void
---- FsnOpenStoreAd::.ctor 0x2c959ac
02c959ac: str     x30, [sp, #-0x30]!                         
02c959b0: stp     x22, x21, [sp, #0x10]                      
02c959b4: stp     x20, x19, [sp, #0x20]                      
02c959b8: adrp    x21, #0x662f000                            
02c959bc: adrp    x20, #0x6264000                            
02c959c0: mov     x19, x0                                    
02c959c4: ldrb    w8, [x21, #0x9f7]                          
02c959c8: ldr     x20, [x20, #0xa70]                         T:UnityEngine.Application
02c959cc: tbnz    w8, #0, #0x2c95a08                         
02c959d0: adrp    x0, #0x6263000                             
02c959d4: ldr     x0, [x0, #0xbd8]                           T:UnityEngine.AndroidJavaObject
02c959d8: bl      #0x2b70db0                                 fn_2b70db0
02c959dc: adrp    x0, #0x6264000                             
02c959e0: ldr     x0, [x0, #0xa70]                           T:UnityEngine.Application
02c959e4: bl      #0x2b70db0                                 fn_2b70db0
02c959e8: adrp    x0, #0x6263000                             
02c959ec: ldr     x0, [x0, #0xb70]                           MS:System.Array::Empty
02c959f0: bl      #0x2b70db0                                 fn_2b70db0
02c959f4: adrp    x0, #0x6265000                             
02c959f8: ldr     x0, [x0, #0x700]                           S:'com.ads.fsnforunity.fsnlib.FsnAd'
02c959fc: bl      #0x2b70db0                                 fn_2b70db0
02c95a00: mov     w8, #1                                     
02c95a04: strb    w8, [x21, #0x9f7]                          
02c95a08: mov     x0, x19                                    
02c95a0c: mov     x1, xzr                                    
02c95a10: bl      #0x4e53e9c                                 System.Object::.ctor
02c95a14: ldr     x0, [x20]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c95a18: ldr     w8, [x0, #0xe4]                            [62650e4]=0 f=0,0
02c95a1c: cbnz    w8, #0x2c95a24                             
02c95a20: bl      #0x2b70f30                                 fn_2b70f30
02c95a24: mov     x0, xzr                                    
02c95a28: bl      #0x5aeb18c                                 UnityEngine.Application::get_platform
02c95a2c: cmp     w0, #0xb                                   
02c95a30: b.ne    #0x2c95adc                                 
02c95a34: adrp    x8, #0x6263000                             
02c95a38: ldr     x8, [x8, #0xb70]                           MS:System.Array::Empty
02c95a3c: ldr     x20, [x8]                                  &2c5bbd4(=a9bd7bfdd503233f)
02c95a40: ldr     x8, [x20, #0x38]                           M:UnityEngine.Rigidbody::MovePosition
02c95a44: cbnz    x8, #0x2c95a54                             
02c95a48: mov     x0, x20                                    
02c95a4c: bl      #0x2ba9d7c                                 fn_2ba9d7c
02c95a50: ldr     x8, [x20, #0x38]                           M:UnityEngine.Rigidbody::MovePosition
02c95a54: ldr     x0, [x8, #0x10]                            &2c498bc(=aa1f03e0d503245f)
02c95a58: add     x8, x0, #0x135                             &6265135
02c95a5c: ldrh    w8, [x8]                                   
02c95a60: tbnz    w8, #0, #0x2c95a68                         
02c95a64: bl      #0x2ba9d20                                 fn_2ba9d20
02c95a68: ldr     w8, [x0, #0xe4]                            [62650e4]=0 f=0,0
02c95a6c: cbnz    w8, #0x2c95a74                             
02c95a70: bl      #0x2b70f30                                 fn_2b70f30
02c95a74: ldr     x8, [x20, #0x38]                           M:UnityEngine.Rigidbody::MovePosition
02c95a78: adrp    x22, #0x6263000                            
02c95a7c: adrp    x21, #0x6265000                            
02c95a80: ldr     x0, [x8, #0x10]                            &2c498bc(=aa1f03e0d503245f)
02c95a84: ldr     x22, [x22, #0xbd8]                         T:UnityEngine.AndroidJavaObject
02c95a88: add     x8, x0, #0x135                             &6265135
02c95a8c: ldrh    w8, [x8]                                   
02c95a90: ldr     x21, [x21, #0x700]                         S:'com.ads.fsnforunity.fsnlib.FsnAd'
02c95a94: tbnz    w8, #0, #0x2c95a9c                         
02c95a98: bl      #0x2ba9d20                                 fn_2ba9d20
02c95a9c: ldr     x8, [x0, #0xb8]                            T:AdsManager/<>c__DisplayClass42_0
02c95aa0: ldr     x0, [x22]                                  &2c5bbd4(=a9bd7bfdd503233f)
02c95aa4: ldr     x20, [x8]                                  &2c5bbd4(=a9bd7bfdd503233f)
02c95aa8: bl      #0x2b7104c                                 fn_2b7104c
02c95aac: ldr     x1, [x21]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c95ab0: mov     x2, x20                                    
02c95ab4: mov     x3, xzr                                    
02c95ab8: mov     x21, x0                                    
02c95abc: bl      #0x5ad5b2c                                 UnityEngine.AndroidJavaObject::.ctor
02c95ac0: str     x21, [x19, #0x10]!                         .androidOpenStoreAd
02c95ac4: mov     x0, x19                                    
02c95ac8: mov     x1, x21                                    
02c95acc: ldp     x20, x19, [sp, #0x20]                      
02c95ad0: ldp     x22, x21, [sp, #0x10]                      
02c95ad4: ldr     x30, [sp], #0x30                           
02c95ad8: b       #0x2b70d54                                 
02c95adc: ldp     x20, x19, [sp, #0x20]                      
02c95ae0: ldp     x22, x21, [sp, #0x10]                      
02c95ae4: ldr     x30, [sp], #0x30                           
02c95ae8: ret                                                
## Init(string adUnitId, int countDownSec, bool loadNewAfterClose, bool startMuteVideo, bool autoDismissWhenAdClicked) -> void
---- FsnOpenStoreAd::Init 0x2c95aec
02c95aec: sub     sp, sp, #0x60                              
02c95af0: str     x30, [sp, #0x10]                           
02c95af4: stp     x26, x25, [sp, #0x20]                      
02c95af8: stp     x24, x23, [sp, #0x30]                      
02c95afc: stp     x22, x21, [sp, #0x40]                      
02c95b00: stp     x20, x19, [sp, #0x50]                      
02c95b04: adrp    x21, #0x662f000                            
02c95b08: adrp    x26, #0x6264000                            
02c95b0c: mov     w19, w5                                    
02c95b10: ldrb    w8, [x21, #0x9f8]                          
02c95b14: ldr     x26, [x26, #0xa70]                         T:UnityEngine.Application
02c95b18: mov     w22, w4                                    
02c95b1c: mov     w23, w3                                    
02c95b20: mov     w24, w2                                    
02c95b24: mov     x25, x1                                    
02c95b28: mov     x20, x0                                    
02c95b2c: tbnz    w8, #0, #0x2c95b5c                         
02c95b30: adrp    x0, #0x6264000                             
02c95b34: ldr     x0, [x0, #0xa70]                           T:UnityEngine.Application
02c95b38: bl      #0x2b70db0                                 fn_2b70db0
02c95b3c: adrp    x0, #0x6263000                             
02c95b40: ldr     x0, [x0, #0xa80]                           T:type24502(k1d)
02c95b44: bl      #0x2b70db0                                 fn_2b70db0
02c95b48: adrp    x0, #0x6265000                             
02c95b4c: ldr     x0, [x0, #0x708]                           S:'Init'
02c95b50: bl      #0x2b70db0                                 fn_2b70db0
02c95b54: mov     w8, #1                                     
02c95b58: strb    w8, [x21, #0x9f8]                          
02c95b5c: ldr     x0, [x26]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c95b60: ldr     w8, [x0, #0xe4]                            [62650e4]=0 f=0,0
02c95b64: cbnz    w8, #0x2c95b6c                             
02c95b68: bl      #0x2b70f30                                 fn_2b70f30
02c95b6c: mov     x0, xzr                                    
02c95b70: bl      #0x5aeb18c                                 UnityEngine.Application::get_platform
02c95b74: cmp     w0, #0xb                                   
02c95b78: b.ne    #0x2c95d20                                 
02c95b7c: ldr     x20, [x20, #0x10]                          .androidOpenStoreAd
02c95b80: cbz     x20, #0x2c95d20                            
02c95b84: adrp    x8, #0x6263000                             
02c95b88: mov     w1, #5                                     
02c95b8c: ldr     x8, [x8, #0xa80]                           T:type24502(k1d)
02c95b90: ldr     x0, [x8]                                   &2c5bbd4(=a9bd7bfdd503233f)
02c95b94: bl      #0x2b70ea0                                 fn_2b70ea0
02c95b98: cbz     x0, #0x2c95d4c                             
02c95b9c: mov     x21, x0                                    
02c95ba0: cbz     x25, #0x2c95bb8                            
02c95ba4: ldr     x8, [x21]                                  &2b706c4(=eb01011ff9400808)
02c95ba8: mov     x0, x25                                    
02c95bac: ldr     x1, [x8, #0x40]                            [6263040]=0 f=0,0
02c95bb0: bl      #0x2b70f34                                 fn_2b70f34
02c95bb4: cbz     x0, #0x2c95d40                             
02c95bb8: ldr     w8, [x21, #0x18]                           [662f018]=6000014 f=2.40742e-35,0 .onFsnLoadListener
02c95bbc: cbz     w8, #0x2c95d3c                             
02c95bc0: mov     x0, x21                                    
02c95bc4: mov     x1, x25                                    
02c95bc8: str     x25, [x0, #0x20]!                          .onFsnCompletedListener
02c95bcc: bl      #0x2b70d54                                 fn_2b70d54
02c95bd0: adrp    x25, #0x6263000                            
02c95bd4: add     x1, sp, #0x1c                              
02c95bd8: ldr     x25, [x25, #0x970]                         &6645c70(=0)
02c95bdc: str     w24, [sp, #0x1c]                           
02c95be0: ldr     x0, [x25, #0x48]                           &6263098(=0)
02c95be4: bl      #0x2b70f38                                 fn_2b70f38
02c95be8: mov     x24, x0                                    
02c95bec: cbz     x0, #0x2c95c04                             
02c95bf0: ldr     x8, [x21]                                  &2b706c4(=eb01011ff9400808)
02c95bf4: mov     x0, x24                                    
02c95bf8: ldr     x1, [x8, #0x40]                            [6263040]=0 f=0,0
02c95bfc: bl      #0x2b70f34                                 fn_2b70f34
02c95c00: cbz     x0, #0x2c95d40                             
02c95c04: ldr     w8, [x21, #0x18]                           [662f018]=6000014 f=2.40742e-35,0 .onFsnLoadListener
02c95c08: tst     w8, #0xfffffffe                            
02c95c0c: b.eq    #0x2c95d3c                                 
02c95c10: mov     x0, x21                                    
02c95c14: mov     x1, x24                                    
02c95c18: and     w23, w23, #1                               
02c95c1c: str     x24, [x0, #0x28]!                          
02c95c20: bl      #0x2b70d54                                 fn_2b70d54
02c95c24: ldr     x0, [x25, #0x28]                           [6263028]=0 f=0,0
02c95c28: add     x1, sp, #0x18                              
02c95c2c: strb    w23, [sp, #0x18]                           
02c95c30: bl      #0x2b70f38                                 fn_2b70f38
02c95c34: mov     x23, x0                                    
02c95c38: cbz     x0, #0x2c95c50                             
02c95c3c: ldr     x8, [x21]                                  &2b706c4(=eb01011ff9400808)
02c95c40: mov     x0, x23                                    
02c95c44: ldr     x1, [x8, #0x40]                            [6263040]=0 f=0,0
02c95c48: bl      #0x2b70f34                                 fn_2b70f34
02c95c4c: cbz     x0, #0x2c95d40                             
02c95c50: ldr     w8, [x21, #0x18]                           [662f018]=6000014 f=2.40742e-35,0 .onFsnLoadListener
02c95c54: cmp     w8, #2                                     
02c95c58: b.ls    #0x2c95d3c                                 
02c95c5c: mov     x0, x21                                    
02c95c60: mov     x1, x23                                    
02c95c64: and     w22, w22, #1                               
02c95c68: str     x23, [x0, #0x30]!                          
02c95c6c: bl      #0x2b70d54                                 fn_2b70d54
02c95c70: ldr     x0, [x25, #0x28]                           [6263028]=0 f=0,0
02c95c74: add     x1, sp, #0xc                               
02c95c78: strb    w22, [sp, #0xc]                            
02c95c7c: bl      #0x2b70f38                                 fn_2b70f38
02c95c80: mov     x22, x0                                    
02c95c84: cbz     x0, #0x2c95c9c                             
02c95c88: ldr     x8, [x21]                                  &2b706c4(=eb01011ff9400808)
02c95c8c: mov     x0, x22                                    
02c95c90: ldr     x1, [x8, #0x40]                            [6263040]=0 f=0,0
02c95c94: bl      #0x2b70f34                                 fn_2b70f34
02c95c98: cbz     x0, #0x2c95d40                             
02c95c9c: ldr     w8, [x21, #0x18]                           [662f018]=6000014 f=2.40742e-35,0 .onFsnLoadListener
02c95ca0: tst     w8, #0xfffffffc                            
02c95ca4: b.eq    #0x2c95d3c                                 
02c95ca8: mov     x0, x21                                    
02c95cac: mov     x1, x22                                    
02c95cb0: and     w19, w19, #1                               
02c95cb4: str     x22, [x0, #0x38]!                          
02c95cb8: bl      #0x2b70d54                                 fn_2b70d54
02c95cbc: ldr     x0, [x25, #0x28]                           [6263028]=0 f=0,0
02c95cc0: add     x1, sp, #8                                 
02c95cc4: strb    w19, [sp, #8]                              
02c95cc8: bl      #0x2b70f38                                 fn_2b70f38
02c95ccc: mov     x19, x0                                    
02c95cd0: cbz     x0, #0x2c95ce8                             
02c95cd4: ldr     x8, [x21]                                  &2b706c4(=eb01011ff9400808)
02c95cd8: mov     x0, x19                                    
02c95cdc: ldr     x1, [x8, #0x40]                            [6263040]=0 f=0,0
02c95ce0: bl      #0x2b70f34                                 fn_2b70f34
02c95ce4: cbz     x0, #0x2c95d40                             
02c95ce8: ldr     w8, [x21, #0x18]                           [662f018]=6000014 f=2.40742e-35,0 .onFsnLoadListener
02c95cec: cmp     w8, #4                                     
02c95cf0: b.ls    #0x2c95d3c                                 
02c95cf4: mov     x0, x21                                    
02c95cf8: mov     x1, x19                                    
02c95cfc: str     x19, [x0, #0x40]!                          
02c95d00: bl      #0x2b70d54                                 fn_2b70d54
02c95d04: adrp    x8, #0x6265000                             
02c95d08: mov     x0, x20                                    
02c95d0c: mov     x2, x21                                    
02c95d10: ldr     x8, [x8, #0x708]                           S:'Init'
02c95d14: mov     x3, xzr                                    
02c95d18: ldr     x1, [x8]                                   M:AdsManager::<OnApplicationPause>b__26_0
02c95d1c: bl      #0x5ad5e34                                 UnityEngine.AndroidJavaObject::Call
02c95d20: ldp     x20, x19, [sp, #0x50]                      
02c95d24: ldr     x30, [sp, #0x10]                           
02c95d28: ldp     x22, x21, [sp, #0x40]                      
02c95d2c: ldp     x24, x23, [sp, #0x30]                      
02c95d30: ldp     x26, x25, [sp, #0x20]                      
02c95d34: add     sp, sp, #0x60                              
02c95d38: ret                                                
02c95d3c: bl      #0x2b71064                                 fn_2b71064
02c95d40: bl      #0x2b71080                                 fn_2b71080
02c95d44: mov     x1, xzr                                    
02c95d48: bl      #0x2b70f20                                 fn_2b70f20
02c95d4c: bl      #0x2b7105c                                 fn_2b7105c
## SetFsnListener(System.Action`2<int,string> onLoadingCompleted, System.Action onLoadingStarted, System.Action`4<string,string,double,string> onAdPaid) -> void
---- FsnOpenStoreAd::SetFsnListener 0x2c95d50
02c95d50: str     x30, [sp, #-0x40]!                         
02c95d54: stp     x24, x23, [sp, #0x10]                      
02c95d58: stp     x22, x21, [sp, #0x20]                      
02c95d5c: stp     x20, x19, [sp, #0x30]                      
02c95d60: adrp    x23, #0x662f000                            
02c95d64: adrp    x24, #0x6264000                            
02c95d68: mov     x20, x3                                    
02c95d6c: ldrb    w8, [x23, #0x9f9]                          
02c95d70: ldr     x24, [x24, #0xa70]                         T:UnityEngine.Application
02c95d74: mov     x21, x2                                    
02c95d78: mov     x22, x1                                    
02c95d7c: mov     x19, x0                                    
02c95d80: tbnz    w8, #0, #0x2c95dbc                         
02c95d84: adrp    x0, #0x6265000                             
02c95d88: ldr     x0, [x0, #0x710]                           T:AndroidOnFsnLoadListener
02c95d8c: bl      #0x2b70db0                                 fn_2b70db0
02c95d90: adrp    x0, #0x6264000                             
02c95d94: ldr     x0, [x0, #0xa70]                           T:UnityEngine.Application
02c95d98: bl      #0x2b70db0                                 fn_2b70db0
02c95d9c: adrp    x0, #0x6263000                             
02c95da0: ldr     x0, [x0, #0xa80]                           T:type24502(k1d)
02c95da4: bl      #0x2b70db0                                 fn_2b70db0
02c95da8: adrp    x0, #0x6265000                             
02c95dac: ldr     x0, [x0, #0x718]                           S:'SetFsnListener'
02c95db0: bl      #0x2b70db0                                 fn_2b70db0
02c95db4: mov     w8, #1                                     
02c95db8: strb    w8, [x23, #0x9f9]                          
02c95dbc: ldr     x0, [x24]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c95dc0: ldr     w8, [x0, #0xe4]                            [62650e4]=0 f=0,0
02c95dc4: cbnz    w8, #0x2c95dcc                             
02c95dc8: bl      #0x2b70f30                                 fn_2b70f30
02c95dcc: mov     x0, xzr                                    
02c95dd0: bl      #0x5aeb18c                                 UnityEngine.Application::get_platform
02c95dd4: cmp     w0, #0xb                                   
02c95dd8: b.ne    #0x2c95e94                                 
02c95ddc: adrp    x8, #0x6265000                             
02c95de0: ldr     x8, [x8, #0x710]                           T:AndroidOnFsnLoadListener
02c95de4: ldr     x0, [x8]                                   M:AdsManager::<OnApplicationPause>b__26_0
02c95de8: bl      #0x2b7104c                                 fn_2b7104c
02c95dec: mov     x1, x22                                    
02c95df0: mov     x2, x21                                    
02c95df4: mov     x3, x20                                    
02c95df8: mov     x23, x0                                    
02c95dfc: bl      #0x2c933dc                                 AndroidOnFsnLoadListener::.ctor
02c95e00: str     x23, [x19, #0x18]!                         .onFsnLoadListener
02c95e04: mov     x0, x19                                    
02c95e08: mov     x1, x23                                    
02c95e0c: bl      #0x2b70d54                                 fn_2b70d54
02c95e10: ldur    x20, [x19, #-8]                            
02c95e14: cbz     x20, #0x2c95e94                            
02c95e18: adrp    x8, #0x6263000                             
02c95e1c: mov     w1, #1                                     
02c95e20: ldr     x8, [x8, #0xa80]                           T:type24502(k1d)
02c95e24: ldr     x0, [x8]                                   &2c5bbd4(=a9bd7bfdd503233f)
02c95e28: bl      #0x2b70ea0                                 fn_2b70ea0
02c95e2c: cbz     x0, #0x2c95ea8                             
02c95e30: ldr     x19, [x19]                                 
02c95e34: mov     x21, x0                                    
02c95e38: cbz     x19, #0x2c95e50                            
02c95e3c: ldr     x8, [x21]                                  
02c95e40: mov     x0, x19                                    
02c95e44: ldr     x1, [x8, #0x40]                            [6263040]=0 f=0,0
02c95e48: bl      #0x2b70f34                                 fn_2b70f34
02c95e4c: cbz     x0, #0x2c95eb0                             
02c95e50: ldr     w8, [x21, #0x18]                           .onFsnLoadListener
02c95e54: cbz     w8, #0x2c95eac                             
02c95e58: mov     x0, x21                                    
02c95e5c: mov     x1, x19                                    
02c95e60: str     x19, [x0, #0x20]!                          .onFsnCompletedListener
02c95e64: bl      #0x2b70d54                                 fn_2b70d54
02c95e68: adrp    x8, #0x6265000                             
02c95e6c: mov     x0, x20                                    
02c95e70: mov     x2, x21                                    
02c95e74: ldr     x8, [x8, #0x718]                           S:'SetFsnListener'
02c95e78: ldp     x20, x19, [sp, #0x30]                      
02c95e7c: ldp     x22, x21, [sp, #0x20]                      
02c95e80: mov     x3, xzr                                    
02c95e84: ldp     x24, x23, [sp, #0x10]                      
02c95e88: ldr     x1, [x8]                                   M:AdsManager::<OnApplicationPause>b__26_0
02c95e8c: ldr     x30, [sp], #0x40                           
02c95e90: b       #0x5ad5e34                                 UnityEngine.AndroidJavaObject::Call
02c95e94: ldp     x20, x19, [sp, #0x30]                      
02c95e98: ldp     x22, x21, [sp, #0x20]                      
02c95e9c: ldp     x24, x23, [sp, #0x10]                      
02c95ea0: ldr     x30, [sp], #0x40                           
02c95ea4: ret                                                
02c95ea8: bl      #0x2b7105c                                 fn_2b7105c
02c95eac: bl      #0x2b71064                                 fn_2b71064
02c95eb0: bl      #0x2b71080                                 fn_2b71080
02c95eb4: mov     x1, xzr                                    
02c95eb8: bl      #0x2b70f20                                 fn_2b70f20
## LoadAd() -> void
---- FsnOpenStoreAd::LoadAd 0x2c95ebc
02c95ebc: stp     x30, x21, [sp, #-0x20]!                    
02c95ec0: stp     x20, x19, [sp, #0x10]                      
02c95ec4: adrp    x20, #0x662f000                            
02c95ec8: adrp    x21, #0x6264000                            
02c95ecc: mov     x19, x0                                    
02c95ed0: ldrb    w8, [x20, #0x9fa]                          
02c95ed4: ldr     x21, [x21, #0xa70]                         T:UnityEngine.Application
02c95ed8: tbnz    w8, #0, #0x2c95f38                         
02c95edc: adrp    x0, #0x6263000                             
02c95ee0: ldr     x0, [x0, #0xc40]                           T:UnityEngine.AndroidJavaClass
02c95ee4: bl      #0x2b70db0                                 fn_2b70db0
02c95ee8: adrp    x0, #0x6263000                             
02c95eec: ldr     x0, [x0, #0xc50]                           MS:UnityEngine.AndroidJavaObject::GetStatic
02c95ef0: bl      #0x2b70db0                                 fn_2b70db0
02c95ef4: adrp    x0, #0x6264000                             
02c95ef8: ldr     x0, [x0, #0xa70]                           T:UnityEngine.Application
02c95efc: bl      #0x2b70db0                                 fn_2b70db0
02c95f00: adrp    x0, #0x6263000                             
02c95f04: ldr     x0, [x0, #0xa80]                           T:type24502(k1d)
02c95f08: bl      #0x2b70db0                                 fn_2b70db0
02c95f0c: adrp    x0, #0x6265000                             
02c95f10: ldr     x0, [x0, #0x728]                           S:'LoadAd'
02c95f14: bl      #0x2b70db0                                 fn_2b70db0
02c95f18: adrp    x0, #0x6265000                             
02c95f1c: ldr     x0, [x0, #0x730]                           S:'com.unity3d.player.UnityPlayer'
02c95f20: bl      #0x2b70db0                                 fn_2b70db0
02c95f24: adrp    x0, #0x6265000                             
02c95f28: ldr     x0, [x0, #0x738]                           S:'currentActivity'
02c95f2c: bl      #0x2b70db0                                 fn_2b70db0
02c95f30: mov     w8, #1                                     
02c95f34: strb    w8, [x20, #0x9fa]                          
02c95f38: ldr     x0, [x21]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c95f3c: ldr     w8, [x0, #0xe4]                            [62650e4]=0 f=0,0
02c95f40: cbnz    w8, #0x2c95f48                             
02c95f44: bl      #0x2b70f30                                 fn_2b70f30
02c95f48: mov     x0, xzr                                    
02c95f4c: bl      #0x5aeb18c                                 UnityEngine.Application::get_platform
02c95f50: cmp     w0, #0xb                                   
02c95f54: b.ne    #0x2c96020                                 
02c95f58: adrp    x8, #0x6263000                             
02c95f5c: adrp    x20, #0x6265000                            
02c95f60: ldr     x8, [x8, #0xc40]                           T:UnityEngine.AndroidJavaClass
02c95f64: ldr     x20, [x20, #0x730]                         S:'com.unity3d.player.UnityPlayer'
02c95f68: ldr     x0, [x8]                                   &2c5bbd4(=a9bd7bfdd503233f)
02c95f6c: bl      #0x2b7104c                                 fn_2b7104c
02c95f70: ldr     x1, [x20]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c95f74: mov     x2, xzr                                    
02c95f78: mov     x20, x0                                    
02c95f7c: bl      #0x5ad2f6c                                 UnityEngine.AndroidJavaClass::.ctor
02c95f80: cbz     x20, #0x2c9602c                            
02c95f84: adrp    x8, #0x6265000                             
02c95f88: adrp    x9, #0x6263000                             
02c95f8c: mov     x0, x20                                    
02c95f90: ldr     x8, [x8, #0x738]                           S:'currentActivity'
02c95f94: ldr     x9, [x9, #0xc50]                           MS:UnityEngine.AndroidJavaObject::GetStatic
02c95f98: ldr     x1, [x8]                                   M:AdsManager::<OnApplicationPause>b__26_0
02c95f9c: ldr     x2, [x9]                                   &2c5bbd4(=a9bd7bfdd503233f)
02c95fa0: bl      #0x3121808                                 fn_3121808
02c95fa4: ldr     x19, [x19, #0x10]                          .androidOpenStoreAd
02c95fa8: cbz     x19, #0x2c96020                            
02c95fac: adrp    x8, #0x6263000                             
02c95fb0: mov     x20, x0                                    
02c95fb4: mov     w1, #1                                     
02c95fb8: ldr     x8, [x8, #0xa80]                           T:type24502(k1d)
02c95fbc: ldr     x0, [x8]                                   &2c5bbd4(=a9bd7bfdd503233f)
02c95fc0: bl      #0x2b70ea0                                 fn_2b70ea0
02c95fc4: cbz     x0, #0x2c9602c                             
02c95fc8: mov     x21, x0                                    
02c95fcc: cbz     x20, #0x2c95fe4                            
02c95fd0: ldr     x8, [x21]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c95fd4: mov     x0, x20                                    
02c95fd8: ldr     x1, [x8, #0x40]                            [6263040]=0 f=0,0
02c95fdc: bl      #0x2b70f34                                 fn_2b70f34
02c95fe0: cbz     x0, #0x2c96034                             
02c95fe4: ldr     w8, [x21, #0x18]                           M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass2_0::<DOSetFloat>b__1 .onFsnLoadListener
02c95fe8: cbz     w8, #0x2c96030                             
02c95fec: mov     x0, x21                                    
02c95ff0: mov     x1, x20                                    
02c95ff4: str     x20, [x0, #0x20]!                          .onFsnCompletedListener
02c95ff8: bl      #0x2b70d54                                 fn_2b70d54
02c95ffc: adrp    x8, #0x6265000                             
02c96000: mov     x0, x19                                    
02c96004: mov     x2, x21                                    
02c96008: ldr     x8, [x8, #0x728]                           S:'LoadAd'
02c9600c: ldp     x20, x19, [sp, #0x10]                      
02c96010: mov     x3, xzr                                    
02c96014: ldr     x1, [x8]                                   M:AdsManager::<OnApplicationPause>b__26_0
02c96018: ldp     x30, x21, [sp], #0x20                      
02c9601c: b       #0x5ad5e34                                 UnityEngine.AndroidJavaObject::Call
02c96020: ldp     x20, x19, [sp, #0x10]                      
02c96024: ldp     x30, x21, [sp], #0x20                      
02c96028: ret                                                
02c9602c: bl      #0x2b7105c                                 fn_2b7105c
02c96030: bl      #0x2b71064                                 fn_2b71064
02c96034: bl      #0x2b71080                                 fn_2b71080
02c96038: mov     x1, xzr                                    
02c9603c: bl      #0x2b70f20                                 fn_2b70f20
## ShowAd(System.Action`1<string> onAdCompleted) -> void
---- FsnOpenStoreAd::ShowAd 0x2c96040
02c96040: str     x30, [sp, #-0x30]!                         
02c96044: stp     x22, x21, [sp, #0x10]                      
02c96048: stp     x20, x19, [sp, #0x20]                      
02c9604c: adrp    x21, #0x662f000                            
02c96050: adrp    x22, #0x6264000                            
02c96054: mov     x20, x1                                    
02c96058: ldrb    w8, [x21, #0x9fb]                          
02c9605c: ldr     x22, [x22, #0xa70]                         T:UnityEngine.Application
02c96060: mov     x19, x0                                    
02c96064: tbnz    w8, #0, #0x2c960dc                         
02c96068: adrp    x0, #0x6263000                             
02c9606c: ldr     x0, [x0, #0xc40]                           T:UnityEngine.AndroidJavaClass
02c96070: bl      #0x2b70db0                                 fn_2b70db0
02c96074: adrp    x0, #0x6263000                             
02c96078: ldr     x0, [x0, #0xc50]                           MS:UnityEngine.AndroidJavaObject::GetStatic
02c9607c: bl      #0x2b70db0                                 fn_2b70db0
02c96080: adrp    x0, #0x6265000                             
02c96084: ldr     x0, [x0, #0x740]                           T:AndroidOnFsnCompletedListener
02c96088: bl      #0x2b70db0                                 fn_2b70db0
02c9608c: adrp    x0, #0x6264000                             
02c96090: ldr     x0, [x0, #0xa70]                           T:UnityEngine.Application
02c96094: bl      #0x2b70db0                                 fn_2b70db0
02c96098: adrp    x0, #0x6263000                             
02c9609c: ldr     x0, [x0, #0xa80]                           T:type24502(k1d)
02c960a0: bl      #0x2b70db0                                 fn_2b70db0
02c960a4: adrp    x0, #0x6265000                             
02c960a8: ldr     x0, [x0, #0x730]                           S:'com.unity3d.player.UnityPlayer'
02c960ac: bl      #0x2b70db0                                 fn_2b70db0
02c960b0: adrp    x0, #0x6265000                             
02c960b4: ldr     x0, [x0, #0x7d8]                           S:'ShowOpenStoreAd'
02c960b8: bl      #0x2b70db0                                 fn_2b70db0
02c960bc: adrp    x0, #0x6263000                             
02c960c0: ldr     x0, [x0, #0xa90]                           S:''
02c960c4: bl      #0x2b70db0                                 fn_2b70db0
02c960c8: adrp    x0, #0x6265000                             
02c960cc: ldr     x0, [x0, #0x738]                           S:'currentActivity'
02c960d0: bl      #0x2b70db0                                 fn_2b70db0
02c960d4: mov     w8, #1                                     
02c960d8: strb    w8, [x21, #0x9fb]                          
02c960dc: ldr     x0, [x22]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c960e0: ldr     w8, [x0, #0xe4]                            [62650e4]=0 f=0,0
02c960e4: cbnz    w8, #0x2c960ec                             
02c960e8: bl      #0x2b70f30                                 fn_2b70f30
02c960ec: mov     x0, xzr                                    
02c960f0: bl      #0x5aeb18c                                 UnityEngine.Application::get_platform
02c960f4: cmp     w0, #0xb                                   
02c960f8: b.ne    #0x2c96230                                 
02c960fc: adrp    x8, #0x6263000                             
02c96100: adrp    x21, #0x6265000                            
02c96104: ldr     x8, [x8, #0xc40]                           T:UnityEngine.AndroidJavaClass
02c96108: ldr     x21, [x21, #0x730]                         S:'com.unity3d.player.UnityPlayer'
02c9610c: ldr     x0, [x8]                                   &2c5bbd4(=a9bd7bfdd503233f)
02c96110: bl      #0x2b7104c                                 fn_2b7104c
02c96114: ldr     x1, [x21]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c96118: mov     x2, xzr                                    
02c9611c: mov     x21, x0                                    
02c96120: bl      #0x5ad2f6c                                 UnityEngine.AndroidJavaClass::.ctor
02c96124: cbz     x21, #0x2c9626c                            
02c96128: adrp    x8, #0x6265000                             
02c9612c: adrp    x9, #0x6263000                             
02c96130: mov     x0, x21                                    
02c96134: ldr     x8, [x8, #0x738]                           S:'currentActivity'
02c96138: ldr     x9, [x9, #0xc50]                           MS:UnityEngine.AndroidJavaObject::GetStatic
02c9613c: ldr     x1, [x8]                                   M:AdsManager::<OnApplicationPause>b__26_0
02c96140: ldr     x2, [x9]                                   &2c5bbd4(=a9bd7bfdd503233f)
02c96144: bl      #0x3121808                                 fn_3121808
02c96148: adrp    x8, #0x6265000                             
02c9614c: mov     x22, x0                                    
02c96150: ldr     x8, [x8, #0x740]                           T:AndroidOnFsnCompletedListener
02c96154: ldr     x8, [x8]                                   M:AdsManager::<OnApplicationPause>b__26_0
02c96158: mov     x0, x8                                     
02c9615c: bl      #0x2b7104c                                 fn_2b7104c
02c96160: mov     x1, x20                                    
02c96164: mov     x21, x0                                    
02c96168: bl      #0x2c93874                                 AndroidOnFsnCompletedListener::.ctor
02c9616c: str     x21, [x19, #0x20]!                         .onFsnCompletedListener
02c96170: mov     x0, x19                                    
02c96174: mov     x1, x21                                    
02c96178: bl      #0x2b70d54                                 fn_2b70d54
02c9617c: ldur    x20, [x19, #-0x10]                         
02c96180: cbz     x20, #0x2c9625c                            
02c96184: adrp    x8, #0x6263000                             
02c96188: mov     w1, #2                                     
02c9618c: ldr     x8, [x8, #0xa80]                           T:type24502(k1d)
02c96190: ldr     x0, [x8]                                   &2c5bbd4(=a9bd7bfdd503233f)
02c96194: bl      #0x2b70ea0                                 fn_2b70ea0
02c96198: cbz     x0, #0x2c9626c                             
02c9619c: mov     x21, x0                                    
02c961a0: cbz     x22, #0x2c961b8                            
02c961a4: ldr     x8, [x21]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c961a8: mov     x0, x22                                    
02c961ac: ldr     x1, [x8, #0x40]                            [6263040]=0 f=0,0
02c961b0: bl      #0x2b70f34                                 fn_2b70f34
02c961b4: cbz     x0, #0x2c96274                             
02c961b8: ldr     w8, [x21, #0x18]                           T:AdsManager/<IEHideAdResume>d__30 .onFsnLoadListener
02c961bc: cbz     w8, #0x2c96270                             
02c961c0: mov     x0, x21                                    
02c961c4: mov     x1, x22                                    
02c961c8: str     x22, [x0, #0x20]!                          .onFsnCompletedListener
02c961cc: bl      #0x2b70d54                                 fn_2b70d54
02c961d0: ldr     x19, [x19]                                 
02c961d4: cbz     x19, #0x2c961ec                            
02c961d8: ldr     x8, [x21]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c961dc: mov     x0, x19                                    
02c961e0: ldr     x1, [x8, #0x40]                            [6263040]=0 f=0,0
02c961e4: bl      #0x2b70f34                                 fn_2b70f34
02c961e8: cbz     x0, #0x2c96274                             
02c961ec: ldr     w8, [x21, #0x18]                           T:AdsManager/<IEHideAdResume>d__30 .onFsnLoadListener
02c961f0: tst     w8, #0xfffffffe                            
02c961f4: b.eq    #0x2c96270                                 
02c961f8: mov     x0, x21                                    
02c961fc: mov     x1, x19                                    
02c96200: str     x19, [x0, #0x28]!                          
02c96204: bl      #0x2b70d54                                 fn_2b70d54
02c96208: adrp    x8, #0x6265000                             
02c9620c: mov     x0, x20                                    
02c96210: mov     x2, x21                                    
02c96214: ldr     x8, [x8, #0x7d8]                           S:'ShowOpenStoreAd'
02c96218: ldp     x20, x19, [sp, #0x20]                      
02c9621c: ldp     x22, x21, [sp, #0x10]                      
02c96220: mov     x3, xzr                                    
02c96224: ldr     x1, [x8]                                   M:AdsManager::<OnApplicationPause>b__26_0
02c96228: ldr     x30, [sp], #0x30                           
02c9622c: b       #0x5ad5e34                                 UnityEngine.AndroidJavaObject::Call
02c96230: cbz     x20, #0x2c9625c                            
02c96234: adrp    x8, #0x6263000                             
02c96238: ldr     x8, [x8, #0xa90]                           S:''
02c9623c: ldr     x0, [x20, #0x40]                           
02c96240: ldr     x2, [x20, #0x28]                           
02c96244: ldr     x3, [x20, #0x18]                           .onFsnLoadListener
02c96248: ldp     x20, x19, [sp, #0x20]                      
02c9624c: ldp     x22, x21, [sp, #0x10]                      
02c96250: ldr     x1, [x8]                                   &2c5bbd4(=a9bd7bfdd503233f)
02c96254: ldr     x30, [sp], #0x30                           
02c96258: br      x3                                         
02c9625c: ldp     x20, x19, [sp, #0x20]                      
02c96260: ldp     x22, x21, [sp, #0x10]                      
02c96264: ldr     x30, [sp], #0x30                           
02c96268: ret                                                
02c9626c: bl      #0x2b7105c                                 fn_2b7105c
02c96270: bl      #0x2b71064                                 fn_2b71064
02c96274: bl      #0x2b71080                                 fn_2b71080
02c96278: mov     x1, xzr                                    
02c9627c: bl      #0x2b70f20                                 fn_2b70f20
## HideAd() -> void
---- FsnOpenStoreAd::HideAd 0x2c96280
02c96280: stp     x30, x21, [sp, #-0x20]!                    
02c96284: stp     x20, x19, [sp, #0x10]                      
02c96288: adrp    x20, #0x662f000                            
02c9628c: adrp    x21, #0x6264000                            
02c96290: mov     x19, x0                                    
02c96294: ldrb    w8, [x20, #0x9fc]                          
02c96298: ldr     x21, [x21, #0xa70]                         T:UnityEngine.Application
02c9629c: tbnz    w8, #0, #0x2c962cc                         
02c962a0: adrp    x0, #0x6264000                             
02c962a4: ldr     x0, [x0, #0xa70]                           T:UnityEngine.Application
02c962a8: bl      #0x2b70db0                                 fn_2b70db0
02c962ac: adrp    x0, #0x6263000                             
02c962b0: ldr     x0, [x0, #0xb70]                           MS:System.Array::Empty
02c962b4: bl      #0x2b70db0                                 fn_2b70db0
02c962b8: adrp    x0, #0x6265000                             
02c962bc: ldr     x0, [x0, #0x758]                           S:'HideAd'
02c962c0: bl      #0x2b70db0                                 fn_2b70db0
02c962c4: mov     w8, #1                                     
02c962c8: strb    w8, [x20, #0x9fc]                          
02c962cc: ldr     x0, [x21]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c962d0: ldr     w8, [x0, #0xe4]                            [62650e4]=0 f=0,0
02c962d4: cbnz    w8, #0x2c962dc                             
02c962d8: bl      #0x2b70f30                                 fn_2b70f30
02c962dc: mov     x0, xzr                                    
02c962e0: bl      #0x5aeb18c                                 UnityEngine.Application::get_platform
02c962e4: cmp     w0, #0xb                                   
02c962e8: b.ne    #0x2c96374                                 
02c962ec: ldr     x19, [x19, #0x10]                          .androidOpenStoreAd
02c962f0: cbz     x19, #0x2c96374                            
02c962f4: adrp    x8, #0x6263000                             
02c962f8: ldr     x8, [x8, #0xb70]                           MS:System.Array::Empty
02c962fc: ldr     x20, [x8]                                  &2c5bbd4(=a9bd7bfdd503233f)
02c96300: ldr     x8, [x20, #0x38]                           [662f038]=6000016 f=2.40742e-35,0
02c96304: cbnz    x8, #0x2c96314                             
02c96308: mov     x0, x20                                    
02c9630c: bl      #0x2ba9d7c                                 fn_2ba9d7c
02c96310: ldr     x8, [x20, #0x38]                           [662f038]=6000016 f=2.40742e-35,0
02c96314: ldr     x0, [x8, #0x10]                            &2c498bc(=aa1f03e0d503245f)
02c96318: add     x8, x0, #0x135                             &6265135
02c9631c: ldrh    w8, [x8]                                   
02c96320: tbnz    w8, #0, #0x2c96328                         
02c96324: bl      #0x2ba9d20                                 fn_2ba9d20
02c96328: ldr     w8, [x0, #0xe4]                            [62650e4]=0 f=0,0
02c9632c: cbnz    w8, #0x2c96334                             
02c96330: bl      #0x2b70f30                                 fn_2b70f30
02c96334: ldr     x8, [x20, #0x38]                           [662f038]=6000016 f=2.40742e-35,0
02c96338: ldr     x0, [x8, #0x10]                            &2c498bc(=aa1f03e0d503245f)
02c9633c: add     x8, x0, #0x135                             &6265135
02c96340: ldrh    w8, [x8]                                   
02c96344: tbnz    w8, #0, #0x2c9634c                         
02c96348: bl      #0x2ba9d20                                 fn_2ba9d20
02c9634c: adrp    x9, #0x6265000                             
02c96350: ldr     x8, [x0, #0xb8]                            T:AdsManager/<>c__DisplayClass42_0
02c96354: mov     x0, x19                                    
02c96358: ldr     x9, [x9, #0x758]                           S:'HideAd'
02c9635c: ldp     x20, x19, [sp, #0x10]                      
02c96360: ldr     x2, [x8]                                   &2c5bbd4(=a9bd7bfdd503233f)
02c96364: mov     x3, xzr                                    
02c96368: ldr     x1, [x9]                                   M:AdsManager::<OnApplicationPause>b__26_0
02c9636c: ldp     x30, x21, [sp], #0x20                      
02c96370: b       #0x5ad5e34                                 UnityEngine.AndroidJavaObject::Call
02c96374: ldp     x20, x19, [sp, #0x10]                      
02c96378: ldp     x30, x21, [sp], #0x20                      
02c9637c: ret                                                
## IsAdReady() -> bool
---- FsnOpenStoreAd::IsAdReady 0x2c96380
02c96380: stp     x30, x21, [sp, #-0x20]!                    
02c96384: stp     x20, x19, [sp, #0x10]                      
02c96388: adrp    x20, #0x662f000                            
02c9638c: mov     x19, x0                                    
02c96390: ldrb    w8, [x20, #0x9fd]                          
02c96394: tbnz    w8, #0, #0x2c963c4                         
02c96398: adrp    x0, #0x6265000                             
02c9639c: ldr     x0, [x0, #0x760]                           MS:UnityEngine.AndroidJavaObject::Call
02c963a0: bl      #0x2b70db0                                 fn_2b70db0
02c963a4: adrp    x0, #0x6263000                             
02c963a8: ldr     x0, [x0, #0xb70]                           MS:System.Array::Empty
02c963ac: bl      #0x2b70db0                                 fn_2b70db0
02c963b0: adrp    x0, #0x6265000                             
02c963b4: ldr     x0, [x0, #0x768]                           S:'IsAdReady'
02c963b8: bl      #0x2b70db0                                 fn_2b70db0
02c963bc: mov     w8, #1                                     
02c963c0: strb    w8, [x20, #0x9fd]                          
02c963c4: ldr     x19, [x19, #0x10]                          .androidOpenStoreAd
02c963c8: cbz     x19, #0x2c96454                            
02c963cc: adrp    x8, #0x6263000                             
02c963d0: ldr     x8, [x8, #0xb70]                           MS:System.Array::Empty
02c963d4: ldr     x20, [x8]                                  &2c5bbd4(=a9bd7bfdd503233f)
02c963d8: ldr     x8, [x20, #0x38]                           [662f038]=6000016 f=2.40742e-35,0
02c963dc: cbnz    x8, #0x2c963ec                             
02c963e0: mov     x0, x20                                    
02c963e4: bl      #0x2ba9d7c                                 fn_2ba9d7c
02c963e8: ldr     x8, [x20, #0x38]                           [662f038]=6000016 f=2.40742e-35,0
02c963ec: ldr     x0, [x8, #0x10]                            &2c498bc(=aa1f03e0d503245f)
02c963f0: add     x8, x0, #0x135                             &6265135
02c963f4: ldrh    w8, [x8]                                   
02c963f8: tbnz    w8, #0, #0x2c96400                         
02c963fc: bl      #0x2ba9d20                                 fn_2ba9d20
02c96400: ldr     w8, [x0, #0xe4]                            [62650e4]=0 f=0,0
02c96404: cbnz    w8, #0x2c9640c                             
02c96408: bl      #0x2b70f30                                 fn_2b70f30
02c9640c: ldr     x8, [x20, #0x38]                           [662f038]=6000016 f=2.40742e-35,0
02c96410: adrp    x20, #0x6265000                            
02c96414: adrp    x21, #0x6265000                            
02c96418: ldr     x0, [x8, #0x10]                            &2c498bc(=aa1f03e0d503245f)
02c9641c: ldr     x20, [x20, #0x768]                         S:'IsAdReady'
02c96420: add     x8, x0, #0x135                             &6265135
02c96424: ldrh    w8, [x8]                                   
02c96428: ldr     x21, [x21, #0x760]                         MS:UnityEngine.AndroidJavaObject::Call
02c9642c: tbnz    w8, #0, #0x2c96434                         
02c96430: bl      #0x2ba9d20                                 fn_2ba9d20
02c96434: ldr     x8, [x0, #0xb8]                            T:AdsManager/<>c__DisplayClass42_0
02c96438: ldr     x1, [x20]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9643c: mov     x0, x19                                    
02c96440: ldp     x20, x19, [sp, #0x10]                      
02c96444: ldr     x3, [x21]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c96448: ldr     x2, [x8]                                   &2c5bbd4(=a9bd7bfdd503233f)
02c9644c: ldp     x30, x21, [sp], #0x20                      
02c96450: b       #0x311f6d4                                 
02c96454: ldp     x20, x19, [sp, #0x10]                      
02c96458: mov     w0, wzr                                    
02c9645c: ldp     x30, x21, [sp], #0x20                      
02c96460: ret                                                
## IsAdLoading() -> bool
---- FsnOpenStoreAd::IsAdLoading 0x2c96464
02c96464: stp     x30, x21, [sp, #-0x20]!                    
02c96468: stp     x20, x19, [sp, #0x10]                      
02c9646c: adrp    x20, #0x662f000                            
02c96470: mov     x19, x0                                    
02c96474: ldrb    w8, [x20, #0x9fe]                          
02c96478: tbnz    w8, #0, #0x2c964a8                         
02c9647c: adrp    x0, #0x6265000                             
02c96480: ldr     x0, [x0, #0x760]                           MS:UnityEngine.AndroidJavaObject::Call
02c96484: bl      #0x2b70db0                                 fn_2b70db0
02c96488: adrp    x0, #0x6263000                             
02c9648c: ldr     x0, [x0, #0xb70]                           MS:System.Array::Empty
02c96490: bl      #0x2b70db0                                 fn_2b70db0
02c96494: adrp    x0, #0x6265000                             
02c96498: ldr     x0, [x0, #0x770]                           S:'IsAdLoading'
02c9649c: bl      #0x2b70db0                                 fn_2b70db0
02c964a0: mov     w8, #1                                     
02c964a4: strb    w8, [x20, #0x9fe]                          
02c964a8: ldr     x19, [x19, #0x10]                          .androidOpenStoreAd
02c964ac: cbz     x19, #0x2c96538                            
02c964b0: adrp    x8, #0x6263000                             
02c964b4: ldr     x8, [x8, #0xb70]                           MS:System.Array::Empty
02c964b8: ldr     x20, [x8]                                  &2c5bbd4(=a9bd7bfdd503233f)
02c964bc: ldr     x8, [x20, #0x38]                           [662f038]=6000016 f=2.40742e-35,0
02c964c0: cbnz    x8, #0x2c964d0                             
02c964c4: mov     x0, x20                                    
02c964c8: bl      #0x2ba9d7c                                 fn_2ba9d7c
02c964cc: ldr     x8, [x20, #0x38]                           [662f038]=6000016 f=2.40742e-35,0
02c964d0: ldr     x0, [x8, #0x10]                            &2c498bc(=aa1f03e0d503245f)
02c964d4: add     x8, x0, #0x135                             &6265135
02c964d8: ldrh    w8, [x8]                                   
02c964dc: tbnz    w8, #0, #0x2c964e4                         
02c964e0: bl      #0x2ba9d20                                 fn_2ba9d20
02c964e4: ldr     w8, [x0, #0xe4]                            [62650e4]=0 f=0,0
02c964e8: cbnz    w8, #0x2c964f0                             
02c964ec: bl      #0x2b70f30                                 fn_2b70f30
02c964f0: ldr     x8, [x20, #0x38]                           [662f038]=6000016 f=2.40742e-35,0
02c964f4: adrp    x20, #0x6265000                            
02c964f8: adrp    x21, #0x6265000                            
02c964fc: ldr     x0, [x8, #0x10]                            &2c498bc(=aa1f03e0d503245f)
02c96500: ldr     x20, [x20, #0x770]                         S:'IsAdLoading'
02c96504: add     x8, x0, #0x135                             &6265135
02c96508: ldrh    w8, [x8]                                   
02c9650c: ldr     x21, [x21, #0x760]                         MS:UnityEngine.AndroidJavaObject::Call
02c96510: tbnz    w8, #0, #0x2c96518                         
02c96514: bl      #0x2ba9d20                                 fn_2ba9d20
02c96518: ldr     x8, [x0, #0xb8]                            T:AdsManager/<>c__DisplayClass42_0
02c9651c: ldr     x1, [x20]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c96520: mov     x0, x19                                    
02c96524: ldp     x20, x19, [sp, #0x10]                      
02c96528: ldr     x3, [x21]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9652c: ldr     x2, [x8]                                   &2c5bbd4(=a9bd7bfdd503233f)
02c96530: ldp     x30, x21, [sp], #0x20                      
02c96534: b       #0x311f6d4                                 
02c96538: ldp     x20, x19, [sp, #0x10]                      
02c9653c: mov     w0, wzr                                    
02c96540: ldp     x30, x21, [sp], #0x20                      
02c96544: ret                                                
## Release() -> void
---- FsnOpenStoreAd::Release 0x2c96548
02c96548: stp     x30, x21, [sp, #-0x20]!                    
02c9654c: stp     x20, x19, [sp, #0x10]                      
02c96550: adrp    x20, #0x662f000                            
02c96554: adrp    x21, #0x6264000                            
02c96558: mov     x19, x0                                    
02c9655c: ldrb    w8, [x20, #0x9ff]                          
02c96560: ldr     x21, [x21, #0xa70]                         T:UnityEngine.Application
02c96564: tbnz    w8, #0, #0x2c9657c                         
02c96568: adrp    x0, #0x6264000                             
02c9656c: ldr     x0, [x0, #0xa70]                           T:UnityEngine.Application
02c96570: bl      #0x2b70db0                                 fn_2b70db0
02c96574: mov     w8, #1                                     
02c96578: strb    w8, [x20, #0x9ff]                          
02c9657c: ldr     x0, [x21]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c96580: ldr     w8, [x0, #0xe4]                            [62640e4]=0 f=0,0
02c96584: cbnz    w8, #0x2c9658c                             
02c96588: bl      #0x2b70f30                                 fn_2b70f30
02c9658c: mov     x0, xzr                                    
02c96590: bl      #0x5aeb18c                                 UnityEngine.Application::get_platform
02c96594: cmp     w0, #0xb                                   
02c96598: b.ne    #0x2c965c4                                 
02c9659c: ldr     x0, [x19, #0x10]!                          .androidOpenStoreAd
02c965a0: cbz     x0, #0x2c965ac                             
02c965a4: mov     x1, xzr                                    
02c965a8: bl      #0x5ad5140                                 UnityEngine.AndroidJavaObject::Dispose
02c965ac: mov     x0, x19                                    
02c965b0: str     xzr, [x19]                                 
02c965b4: mov     x1, xzr                                    
02c965b8: ldp     x20, x19, [sp, #0x10]                      
02c965bc: ldp     x30, x21, [sp], #0x20                      
02c965c0: b       #0x2b70d54                                 
02c965c4: ldp     x20, x19, [sp, #0x10]                      
02c965c8: ldp     x30, x21, [sp], #0x20                      
02c965cc: ret                                                
