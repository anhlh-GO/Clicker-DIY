#### CLASS Framework.RectTransformExtension parent= object
## SetSizeByWidth(UnityEngine.RectTransform rectTf, float width, float aspect) -> void
---- Framework.RectTransformExtension::SetSizeByWidth 0x2cb9594
02cb9594: cbz     x0, #0x2cb95a4                             
02cb9598: fmul    s1, s0, s1                                 
02cb959c: mov     x1, xzr                                    
02cb95a0: b       #0x5b45994                                 UnityEngine.RectTransform::set_sizeDelta
02cb95a4: str     x30, [sp, #-0x10]!                         
02cb95a8: bl      #0x2b7105c                                 fn_2b7105c
## SetSizeByHeight(UnityEngine.RectTransform rectTf, float height, float aspect) -> void
---- Framework.RectTransformExtension::SetSizeByHeight 0x2cb95ac
02cb95ac: cbz     x0, #0x2cb95c4                             
02cb95b0: fmov    s2, s0                                     
02cb95b4: fdiv    s0, s0, s1                                 
02cb95b8: mov     x1, xzr                                    
02cb95bc: fmov    s1, s2                                     
02cb95c0: b       #0x5b45994                                 UnityEngine.RectTransform::set_sizeDelta
02cb95c4: str     x30, [sp, #-0x10]!                         
02cb95c8: bl      #0x2b7105c                                 fn_2b7105c
## SetLeft(UnityEngine.RectTransform rt, float left) -> void
---- Framework.RectTransformExtension::SetLeft 0x2cb95cc
02cb95cc: str     d8, [sp, #-0x20]!                          
02cb95d0: stp     x30, x19, [sp, #0x10]                      
02cb95d4: cbz     x0, #0x2cb9600                             
02cb95d8: mov     x1, xzr                                    
02cb95dc: mov     x19, x0                                    
02cb95e0: fmov    s8, s0                                     
02cb95e4: bl      #0x5b45d7c                                 UnityEngine.RectTransform::get_offsetMin
02cb95e8: mov     x0, x19                                    
02cb95ec: ldp     x30, x19, [sp, #0x10]                      
02cb95f0: fmov    s0, s8                                     
02cb95f4: mov     x1, xzr                                    
02cb95f8: ldr     d8, [sp], #0x20                            
02cb95fc: b       #0x5b45dd0                                 UnityEngine.RectTransform::set_offsetMin
02cb9600: bl      #0x2b7105c                                 fn_2b7105c
## SetRight(UnityEngine.RectTransform rt, float right) -> void
---- Framework.RectTransformExtension::SetRight 0x2cb9604
02cb9604: str     d8, [sp, #-0x20]!                          
02cb9608: stp     x30, x19, [sp, #0x10]                      
02cb960c: cbz     x0, #0x2cb9638                             
02cb9610: mov     x1, xzr                                    
02cb9614: mov     x19, x0                                    
02cb9618: fmov    s8, s0                                     
02cb961c: bl      #0x5b45ec4                                 UnityEngine.RectTransform::get_offsetMax
02cb9620: mov     x0, x19                                    
02cb9624: ldp     x30, x19, [sp, #0x10]                      
02cb9628: fneg    s0, s8                                     
02cb962c: mov     x1, xzr                                    
02cb9630: ldr     d8, [sp], #0x20                            
02cb9634: b       #0x5b45f64                                 UnityEngine.RectTransform::set_offsetMax
02cb9638: bl      #0x2b7105c                                 fn_2b7105c
## SetTop(UnityEngine.RectTransform rt, float top) -> void
---- Framework.RectTransformExtension::SetTop 0x2cb963c
02cb963c: str     d8, [sp, #-0x20]!                          
02cb9640: stp     x30, x19, [sp, #0x10]                      
02cb9644: cbz     x0, #0x2cb9670                             
02cb9648: mov     x1, xzr                                    
02cb964c: mov     x19, x0                                    
02cb9650: fmov    s8, s0                                     
02cb9654: bl      #0x5b45ec4                                 UnityEngine.RectTransform::get_offsetMax
02cb9658: mov     x0, x19                                    
02cb965c: ldp     x30, x19, [sp, #0x10]                      
02cb9660: fneg    s1, s8                                     
02cb9664: mov     x1, xzr                                    
02cb9668: ldr     d8, [sp], #0x20                            
02cb966c: b       #0x5b45f64                                 UnityEngine.RectTransform::set_offsetMax
02cb9670: bl      #0x2b7105c                                 fn_2b7105c
## SetBottom(UnityEngine.RectTransform rt, float bottom) -> void
---- Framework.RectTransformExtension::SetBottom 0x2cb9674
02cb9674: str     d8, [sp, #-0x20]!                          
02cb9678: stp     x30, x19, [sp, #0x10]                      
02cb967c: cbz     x0, #0x2cb96a8                             
02cb9680: mov     x1, xzr                                    
02cb9684: mov     x19, x0                                    
02cb9688: fmov    s8, s0                                     
02cb968c: bl      #0x5b45d7c                                 UnityEngine.RectTransform::get_offsetMin
02cb9690: mov     x0, x19                                    
02cb9694: ldp     x30, x19, [sp, #0x10]                      
02cb9698: fmov    s1, s8                                     
02cb969c: mov     x1, xzr                                    
02cb96a0: ldr     d8, [sp], #0x20                            
02cb96a4: b       #0x5b45dd0                                 UnityEngine.RectTransform::set_offsetMin
02cb96a8: bl      #0x2b7105c                                 fn_2b7105c
## StretchFullParent(UnityEngine.RectTransform rt) -> void
---- Framework.RectTransformExtension::StretchFullParent 0x2cb96ac
02cb96ac: str     x30, [sp, #-0x30]!                         
02cb96b0: stp     x22, x21, [sp, #0x10]                      
02cb96b4: stp     x20, x19, [sp, #0x20]                      
02cb96b8: cbz     x0, #0x2cb9850                             
02cb96bc: mov     x1, xzr                                    
02cb96c0: mov     x19, x0                                    
02cb96c4: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02cb96c8: adrp    x21, #0x662f000                            
02cb96cc: mov     x20, x0                                    
02cb96d0: ldrb    w8, [x21, #0x91a]                          
02cb96d4: cbnz    w8, #0x2cb96ec                             
02cb96d8: adrp    x0, #0x6264000                             
02cb96dc: ldr     x0, [x0, #0xd8]                            T:UnityEngine.Vector3
02cb96e0: bl      #0x2b70db0                                 fn_2b70db0
02cb96e4: mov     w8, #1                                     
02cb96e8: strb    w8, [x21, #0x91a]                          
02cb96ec: cbz     x20, #0x2cb9850                            
02cb96f0: adrp    x21, #0x6264000                            
02cb96f4: mov     x0, x20                                    
02cb96f8: mov     x1, xzr                                    
02cb96fc: ldr     x21, [x21, #0xd8]                          T:UnityEngine.Vector3
02cb9700: ldr     x8, [x21]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02cb9704: ldr     x8, [x8, #0xb8]                            
02cb9708: ldp     s1, s2, [x8, #4]                           
02cb970c: ldr     s0, [x8]                                   
02cb9710: bl      #0x5b45cec                                 UnityEngine.Transform::set_localPosition
02cb9714: mov     x0, x19                                    
02cb9718: mov     x1, xzr                                    
02cb971c: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02cb9720: adrp    x22, #0x662f000                            
02cb9724: mov     x20, x0                                    
02cb9728: ldrb    w8, [x22, #0xa74]                          
02cb972c: cbnz    w8, #0x2cb9744                             
02cb9730: adrp    x0, #0x6264000                             
02cb9734: ldr     x0, [x0, #0xd8]                            T:UnityEngine.Vector3
02cb9738: bl      #0x2b70db0                                 fn_2b70db0
02cb973c: mov     w8, #1                                     
02cb9740: strb    w8, [x22, #0xa74]                          
02cb9744: cbz     x20, #0x2cb9850                            
02cb9748: ldr     x8, [x21]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02cb974c: mov     x0, x20                                    
02cb9750: mov     x1, xzr                                    
02cb9754: ldr     x8, [x8, #0xb8]                            
02cb9758: ldp     s1, s2, [x8, #0x10]                        
02cb975c: ldr     s0, [x8, #0xc]                             
02cb9760: bl      #0x5b470cc                                 UnityEngine.Transform::set_localScale
02cb9764: adrp    x20, #0x662f000                            
02cb9768: ldrb    w8, [x20, #0xbda]                          
02cb976c: cbnz    w8, #0x2cb9784                             
02cb9770: adrp    x0, #0x6266000                             
02cb9774: ldr     x0, [x0, #0x970]                           T:UnityEngine.Vector2
02cb9778: bl      #0x2b70db0                                 fn_2b70db0
02cb977c: mov     w8, #1                                     
02cb9780: strb    w8, [x20, #0xbda]                          
02cb9784: adrp    x21, #0x6266000                            
02cb9788: mov     x0, x19                                    
02cb978c: mov     x1, xzr                                    
02cb9790: ldr     x21, [x21, #0x970]                         T:UnityEngine.Vector2
02cb9794: ldr     x8, [x21]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cb9798: ldr     x8, [x8, #0xb8]                            
02cb979c: ldp     s0, s1, [x8]                               
02cb97a0: bl      #0x5b454d8                                 UnityEngine.RectTransform::set_anchorMin
02cb97a4: adrp    x22, #0x662f000                            
02cb97a8: ldrb    w8, [x22, #0xca2]                          
02cb97ac: cbnz    w8, #0x2cb97c4                             
02cb97b0: adrp    x0, #0x6266000                             
02cb97b4: ldr     x0, [x0, #0x970]                           T:UnityEngine.Vector2
02cb97b8: bl      #0x2b70db0                                 fn_2b70db0
02cb97bc: mov     w8, #1                                     
02cb97c0: strb    w8, [x22, #0xca2]                          
02cb97c4: ldr     x8, [x21]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cb97c8: mov     x0, x19                                    
02cb97cc: mov     x1, xzr                                    
02cb97d0: ldr     x8, [x8, #0xb8]                            
02cb97d4: ldp     s0, s1, [x8, #8]                           
02cb97d8: bl      #0x5b4566c                                 UnityEngine.RectTransform::set_anchorMax
02cb97dc: ldrb    w8, [x20, #0xbda]                          
02cb97e0: cbnz    w8, #0x2cb97f8                             
02cb97e4: adrp    x0, #0x6266000                             
02cb97e8: ldr     x0, [x0, #0x970]                           T:UnityEngine.Vector2
02cb97ec: bl      #0x2b70db0                                 fn_2b70db0
02cb97f0: mov     w8, #1                                     
02cb97f4: strb    w8, [x20, #0xbda]                          
02cb97f8: ldr     x8, [x21]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cb97fc: mov     x0, x19                                    
02cb9800: mov     x1, xzr                                    
02cb9804: ldr     x8, [x8, #0xb8]                            
02cb9808: ldp     s0, s1, [x8]                               
02cb980c: bl      #0x5b45dd0                                 UnityEngine.RectTransform::set_offsetMin
02cb9810: ldrb    w8, [x20, #0xbda]                          
02cb9814: cbnz    w8, #0x2cb982c                             
02cb9818: adrp    x0, #0x6266000                             
02cb981c: ldr     x0, [x0, #0x970]                           T:UnityEngine.Vector2
02cb9820: bl      #0x2b70db0                                 fn_2b70db0
02cb9824: mov     w8, #1                                     
02cb9828: strb    w8, [x20, #0xbda]                          
02cb982c: ldr     x8, [x21]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cb9830: mov     x0, x19                                    
02cb9834: mov     x1, xzr                                    
02cb9838: ldp     x20, x19, [sp, #0x20]                      
02cb983c: ldr     x8, [x8, #0xb8]                            
02cb9840: ldp     x22, x21, [sp, #0x10]                      
02cb9844: ldp     s0, s1, [x8]                               
02cb9848: ldr     x30, [sp], #0x30                           
02cb984c: b       #0x5b45f64                                 UnityEngine.RectTransform::set_offsetMax
02cb9850: bl      #0x2b7105c                                 fn_2b7105c
