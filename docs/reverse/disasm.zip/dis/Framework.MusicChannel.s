#### CLASS Framework.MusicChannel parent= UnityEngine.MonoBehaviour
#   field IsPlay                         bool                                               off=0x20 attr=6 
#   field Source                         UnityEngine.AudioSource                            off=0x28 attr=6 
#   field MusicKey                       Framework.EMusic                                   off=0x30 attr=6 
## get_IsMute() -> bool
---- Framework.MusicChannel::get_IsMute 0x2d86cdc
02d86cdc: ldr     x0, [x0, #0x28]                            .Source
02d86ce0: cbz     x0, #0x2d86cec                             
02d86ce4: mov     x1, xzr                                    
02d86ce8: b       #0x5adfd28                                 UnityEngine.AudioSource::get_mute
02d86cec: str     x30, [sp, #-0x10]!                         
02d86cf0: bl      #0x2b7105c                                 fn_2b7105c
## set_IsMute(bool value) -> void
---- Framework.MusicChannel::set_IsMute 0x2d84b9c
02d84b9c: ldr     x0, [x0, #0x28]                            .Source
02d84ba0: cbz     x0, #0x2d84bb0                             
02d84ba4: and     w1, w1, #1                                 
02d84ba8: mov     x2, xzr                                    
02d84bac: b       #0x5adfddc                                 UnityEngine.AudioSource::set_mute
02d84bb0: str     x30, [sp, #-0x10]!                         
02d84bb4: bl      #0x2b7105c                                 fn_2b7105c
## Play(Framework.EMusic musicKey, UnityEngine.AudioClip clip, float volume, float delay) -> void
---- Framework.MusicChannel::Play 0x2d853e0
02d853e0: stp     d9, d8, [sp, #-0x20]!                      
02d853e4: stp     x30, x19, [sp, #0x10]                      
02d853e8: mov     x19, x0                                    
02d853ec: ldr     x0, [x0, #0x28]                            .Source
02d853f0: mov     w8, #1                                     
02d853f4: strb    w8, [x19, #0x20]                           .IsPlay
02d853f8: str     w1, [x19, #0x30]                           .MusicKey
02d853fc: cbz     x0, #0x2d85458                             
02d85400: mov     x1, x2                                     
02d85404: mov     x2, xzr                                    
02d85408: fmov    s8, s1                                     
02d8540c: fmov    s9, s0                                     
02d85410: bl      #0x5adf8dc                                 UnityEngine.AudioSource::set_clip
02d85414: ldr     x0, [x19, #0x28]                           .Source
02d85418: cbz     x0, #0x2d85458                             
02d8541c: mov     w1, #1                                     
02d85420: mov     x2, xzr                                    
02d85424: bl      #0x5adfc64                                 UnityEngine.AudioSource::set_loop
02d85428: ldr     x0, [x19, #0x28]                           .Source
02d8542c: cbz     x0, #0x2d85458                             
02d85430: fmov    s0, s9                                     
02d85434: mov     x1, xzr                                    
02d85438: bl      #0x5adf65c                                 UnityEngine.AudioSource::set_volume
02d8543c: ldr     x0, [x19, #0x28]                           .Source
02d85440: cbz     x0, #0x2d85458                             
02d85444: ldp     x30, x19, [sp, #0x10]                      
02d85448: fmov    s0, s8                                     
02d8544c: mov     x1, xzr                                    
02d85450: ldp     d9, d8, [sp], #0x20                        
02d85454: b       #0x5adfa1c                                 UnityEngine.AudioSource::PlayDelayed
02d85458: bl      #0x2b7105c                                 fn_2b7105c
## SetVolume(float volume) -> void
---- Framework.MusicChannel::SetVolume 0x2d85594
02d85594: ldr     x0, [x0, #0x28]                            .Source
02d85598: cbz     x0, #0x2d855a4                             
02d8559c: mov     x1, xzr                                    
02d855a0: b       #0x5adf65c                                 UnityEngine.AudioSource::set_volume
02d855a4: str     x30, [sp, #-0x10]!                         
02d855a8: bl      #0x2b7105c                                 fn_2b7105c
## Stop() -> void
---- Framework.MusicChannel::Stop 0x2d855b4
02d855b4: stp     x30, x19, [sp, #-0x10]!                    
02d855b8: mov     x19, x0                                    
02d855bc: ldr     x0, [x0, #0x28]                            .Source
02d855c0: strb    wzr, [x19, #0x20]                          .IsPlay
02d855c4: cbz     x0, #0x2d855e0                             
02d855c8: mov     x1, xzr                                    
02d855cc: bl      #0x5adfa40                                 UnityEngine.AudioSource::Stop
02d855d0: mov     x0, x19                                    
02d855d4: mov     x1, xzr                                    
02d855d8: ldp     x30, x19, [sp], #0x10                      
02d855dc: b       #0x5b38f60                                 UnityEngine.MonoBehaviour::StopAllCoroutines
02d855e0: bl      #0x2b7105c                                 fn_2b7105c
## .ctor() -> void
---- Framework.MusicChannel::.ctor 0x2d86cf4
02d86cf4: mov     x1, xzr                                    
02d86cf8: b       #0x5b397b0                                 UnityEngine.MonoBehaviour::.ctor
