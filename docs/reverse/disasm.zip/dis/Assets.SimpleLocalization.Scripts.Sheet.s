#### CLASS Assets.SimpleLocalization.Scripts.Sheet parent= object
#   field Name                           string                                             off=0x10 attr=6 
#   field Id                             long                                               off=0x18 attr=6 
#   field TextAsset                      UnityEngine.TextAsset                              off=0x20 attr=6 
## .ctor() -> void
---- Assets.SimpleLocalization.Scripts.Sheet::.ctor 0x2d7cab0
02d7cab0: mov     x1, xzr                                    
02d7cab4: b       #0x4e53e9c                                 System.Object::.ctor
