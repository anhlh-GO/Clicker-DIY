#### CLASS DataLevel parent= GameData
#   field _levelSave                     DataLevelSave                                      off=0x20 attr=1 SerializeField
## get_LevelSave() -> DataLevelSave
---- DataLevel::get_LevelSave 0x2ca9a5c
02ca9a5c: ldr     x0, [x0, #0x20]                            ._levelSave
02ca9a60: ret                                                
## set_LevelSave(DataLevelSave value) -> void
---- DataLevel::set_LevelSave 0x2ca9a64
02ca9a64: str     x1, [x0, #0x20]!                           ._levelSave
02ca9a68: b       #0x2b70d54                                 
## get_CurrentLevelId() -> int
---- DataLevel::get_CurrentLevelId 0x2ca9a6c
02ca9a6c: ldr     x8, [x0, #0x20]                            ._levelSave
02ca9a70: cbz     x8, #0x2ca9a7c                             
02ca9a74: ldr     w0, [x8, #0x10]                            
02ca9a78: ret                                                
02ca9a7c: str     x30, [sp, #-0x10]!                         
02ca9a80: bl      #0x2b7105c                                 fn_2b7105c
## set_CurrentLevelId(int value) -> void
---- DataLevel::set_CurrentLevelId 0x2ca9a84
02ca9a84: ldr     x8, [x0, #0x20]                            ._levelSave
02ca9a88: cbz     x8, #0x2ca9a94                             
02ca9a8c: str     w1, [x8, #0x10]                            
02ca9a90: ret                                                
02ca9a94: str     x30, [sp, #-0x10]!                         
02ca9a98: bl      #0x2b7105c                                 fn_2b7105c
## get_HighestLevelId() -> int
---- DataLevel::get_HighestLevelId 0x2ca9a9c
02ca9a9c: ldr     x8, [x0, #0x20]                            ._levelSave
02ca9aa0: cbz     x8, #0x2ca9aac                             
02ca9aa4: ldr     w0, [x8, #0x14]                            
02ca9aa8: ret                                                
02ca9aac: str     x30, [sp, #-0x10]!                         
02ca9ab0: bl      #0x2b7105c                                 fn_2b7105c
## set_HighestLevelId(int value) -> void
---- DataLevel::set_HighestLevelId 0x2ca9ab4
02ca9ab4: ldr     x8, [x0, #0x20]                            ._levelSave
02ca9ab8: cbz     x8, #0x2ca9ac4                             
02ca9abc: str     w1, [x8, #0x14]                            
02ca9ac0: ret                                                
02ca9ac4: str     x30, [sp, #-0x10]!                         
02ca9ac8: bl      #0x2b7105c                                 fn_2b7105c
## GetCurrentLevel() -> int
---- DataLevel::GetCurrentLevel 0x2ca9acc
02ca9acc: ldr     x8, [x0, #0x20]                            ._levelSave
02ca9ad0: cbz     x8, #0x2ca9adc                             
02ca9ad4: ldr     w0, [x8, #0x10]                            
02ca9ad8: ret                                                
02ca9adc: str     x30, [sp, #-0x10]!                         
02ca9ae0: bl      #0x2b7105c                                 fn_2b7105c
## SaveData() -> void
---- DataLevel::SaveData 0x2ca9ae4
02ca9ae4: stp     x30, x21, [sp, #-0x20]!                    
02ca9ae8: stp     x20, x19, [sp, #0x10]                      
02ca9aec: adrp    x20, #0x662f000                            
02ca9af0: adrp    x21, #0x6266000                            
02ca9af4: mov     x19, x0                                    
02ca9af8: ldrb    w8, [x20, #0xb0d]                          
02ca9afc: ldr     x21, [x21, #0x658]                         MS:MonoSingleton`1::get_Instance
02ca9b00: tbnz    w8, #0, #0x2ca9b24                         
02ca9b04: adrp    x0, #0x6266000                             
02ca9b08: ldr     x0, [x0, #0x730]                           MS:DataManager::SaveData
02ca9b0c: bl      #0x2b70db0                                 fn_2b70db0
02ca9b10: adrp    x0, #0x6266000                             
02ca9b14: ldr     x0, [x0, #0x658]                           MS:MonoSingleton`1::get_Instance
02ca9b18: bl      #0x2b70db0                                 fn_2b70db0
02ca9b1c: mov     w8, #1                                     
02ca9b20: strb    w8, [x20, #0xb0d]                          
02ca9b24: ldr     x0, [x21]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca9b28: bl      #0x3769600                                 fn_3769600
02ca9b2c: mov     x20, x0                                    
02ca9b30: mov     x0, x19                                    
02ca9b34: mov     x1, xzr                                    
02ca9b38: bl      #0x4e54610                                 System.Object::GetType
02ca9b3c: cbz     x0, #0x2ca9b78                             
02ca9b40: ldr     x8, [x0]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca9b44: ldr     x9, [x8, #0x2f8]                           
02ca9b48: ldr     x1, [x8, #0x300]                           
02ca9b4c: blr     x9                                         
02ca9b50: cbz     x20, #0x2ca9b78                            
02ca9b54: adrp    x8, #0x6266000                             
02ca9b58: mov     x1, x0                                     
02ca9b5c: mov     x0, x20                                    
02ca9b60: ldr     x8, [x8, #0x730]                           MS:DataManager::SaveData
02ca9b64: ldr     x2, [x19, #0x20]                           ._levelSave
02ca9b68: ldp     x20, x19, [sp, #0x10]                      
02ca9b6c: ldr     x3, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca9b70: ldp     x30, x21, [sp], #0x20                      
02ca9b74: b       #0x3169790                                 
02ca9b78: bl      #0x2b7105c                                 fn_2b7105c
## LoadData() -> void
---- DataLevel::LoadData 0x2ca9b7c
02ca9b7c: stp     x30, x21, [sp, #-0x20]!                    
02ca9b80: stp     x20, x19, [sp, #0x10]                      
02ca9b84: adrp    x20, #0x662f000                            
02ca9b88: adrp    x21, #0x6266000                            
02ca9b8c: mov     x19, x0                                    
02ca9b90: ldrb    w8, [x20, #0xb0e]                          
02ca9b94: ldr     x21, [x21, #0x658]                         MS:MonoSingleton`1::get_Instance
02ca9b98: tbnz    w8, #0, #0x2ca9bbc                         
02ca9b9c: adrp    x0, #0x6266000                             
02ca9ba0: ldr     x0, [x0, #0x738]                           MS:DataManager::LoadData
02ca9ba4: bl      #0x2b70db0                                 fn_2b70db0
02ca9ba8: adrp    x0, #0x6266000                             
02ca9bac: ldr     x0, [x0, #0x658]                           MS:MonoSingleton`1::get_Instance
02ca9bb0: bl      #0x2b70db0                                 fn_2b70db0
02ca9bb4: mov     w8, #1                                     
02ca9bb8: strb    w8, [x20, #0xb0e]                          
02ca9bbc: ldr     x0, [x21]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca9bc0: bl      #0x3769600                                 fn_3769600
02ca9bc4: mov     x20, x0                                    
02ca9bc8: mov     x0, x19                                    
02ca9bcc: mov     x1, xzr                                    
02ca9bd0: bl      #0x4e54610                                 System.Object::GetType
02ca9bd4: cbz     x0, #0x2ca9c1c                             
02ca9bd8: ldr     x8, [x0]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca9bdc: ldr     x9, [x8, #0x2f8]                           
02ca9be0: ldr     x1, [x8, #0x300]                           
02ca9be4: blr     x9                                         
02ca9be8: cbz     x20, #0x2ca9c1c                            
02ca9bec: adrp    x8, #0x6266000                             
02ca9bf0: mov     x1, x0                                     
02ca9bf4: mov     x0, x20                                    
02ca9bf8: ldr     x8, [x8, #0x738]                           MS:DataManager::LoadData
02ca9bfc: ldr     x2, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca9c00: bl      #0x31690b0                                 fn_31690b0
02ca9c04: str     x0, [x19, #0x20]!                          ._levelSave
02ca9c08: mov     x1, x0                                     
02ca9c0c: mov     x0, x19                                    
02ca9c10: ldp     x20, x19, [sp, #0x10]                      
02ca9c14: ldp     x30, x21, [sp], #0x20                      
02ca9c18: b       #0x2b70d54                                 
02ca9c1c: bl      #0x2b7105c                                 fn_2b7105c
## NewData() -> void
---- DataLevel::NewData 0x2ca9c20
02ca9c20: stp     x30, x21, [sp, #-0x20]!                    
02ca9c24: stp     x20, x19, [sp, #0x10]                      
02ca9c28: adrp    x20, #0x662f000                            
02ca9c2c: adrp    x21, #0x6266000                            
02ca9c30: mov     x19, x0                                    
02ca9c34: ldrb    w8, [x20, #0xb0f]                          
02ca9c38: ldr     x21, [x21, #0x740]                         T:DataLevelSave
02ca9c3c: tbnz    w8, #0, #0x2ca9c54                         
02ca9c40: adrp    x0, #0x6266000                             
02ca9c44: ldr     x0, [x0, #0x740]                           T:DataLevelSave
02ca9c48: bl      #0x2b70db0                                 fn_2b70db0
02ca9c4c: mov     w8, #1                                     
02ca9c50: strb    w8, [x20, #0xb0f]                          
02ca9c54: ldr     x0, [x21]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca9c58: bl      #0x2b7104c                                 fn_2b7104c
02ca9c5c: mov     x1, xzr                                    
02ca9c60: mov     x20, x0                                    
02ca9c64: bl      #0x4e53e9c                                 System.Object::.ctor
02ca9c68: adrp    x8, #0x1040000                             
02ca9c6c: mov     x0, x19                                    
02ca9c70: mov     x1, x20                                    
02ca9c74: ldr     d0, [x8, #0x928]                           [1040928]=1 f=1.4013e-45,0
02ca9c78: str     x20, [x0, #0x20]!                          ._levelSave
02ca9c7c: str     d0, [x20, #0x10]                           
02ca9c80: bl      #0x2b70d54                                 fn_2b70d54
02ca9c84: ldr     x8, [x19]                                  
02ca9c88: mov     x0, x19                                    
02ca9c8c: ldp     x20, x19, [sp, #0x10]                      
02ca9c90: ldr     x1, [x8, #0x260]                           [1040260]=0 f=0,0
02ca9c94: ldr     x2, [x8, #0x258]                           [1040258]=55e00000402 f=1.43773e-42,1.92538e-42
02ca9c98: ldp     x30, x21, [sp], #0x20                      
02ca9c9c: br      x2                                         
## PassLevel() -> void
---- DataLevel::PassLevel 0x2ca9ca0
02ca9ca0: ldr     x8, [x0, #0x20]                            ._levelSave
02ca9ca4: cbz     x8, #0x2ca9cd0                             
02ca9ca8: ldp     w9, w10, [x8, #0x10]                       
02ca9cac: cmp     w9, w10                                    
02ca9cb0: b.le    #0x2ca9cb8                                 
02ca9cb4: str     w9, [x8, #0x14]                            
02ca9cb8: add     w9, w9, #1                                 
02ca9cbc: str     w9, [x8, #0x10]                            
02ca9cc0: ldr     x8, [x0]                                   
02ca9cc4: ldr     x1, [x8, #0x260]                           
02ca9cc8: ldr     x2, [x8, #0x258]                           
02ca9ccc: br      x2                                         
02ca9cd0: str     x30, [sp, #-0x10]!                         
02ca9cd4: bl      #0x2b7105c                                 fn_2b7105c
## .ctor() -> void
---- DataLevel::.ctor 0x2ca9cd8
02ca9cd8: mov     x1, xzr                                    
02ca9cdc: b       #0x5b397b0                                 UnityEngine.MonoBehaviour::.ctor
