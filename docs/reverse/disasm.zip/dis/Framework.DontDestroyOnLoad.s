#### CLASS Framework.DontDestroyOnLoad parent= UnityEngine.MonoBehaviour
## Awake() -> void
---- Framework.DontDestroyOnLoad::Awake 0x2cc6400
02cc6400: stp     x30, x21, [sp, #-0x20]!                    
02cc6404: stp     x20, x19, [sp, #0x10]                      
02cc6408: adrp    x21, #0x662f000                            
02cc640c: adrp    x20, #0x6263000                            
02cc6410: mov     x19, x0                                    
02cc6414: ldrb    w8, [x21, #0xc52]                          
02cc6418: ldr     x20, [x20, #0x918]                         T:UnityEngine.Object
02cc641c: tbnz    w8, #0, #0x2cc6434                         
02cc6420: adrp    x0, #0x6263000                             
02cc6424: ldr     x0, [x0, #0x918]                           T:UnityEngine.Object
02cc6428: bl      #0x2b70db0                                 fn_2b70db0
02cc642c: mov     w8, #1                                     
02cc6430: strb    w8, [x21, #0xc52]                          
02cc6434: mov     x0, x19                                    
02cc6438: mov     x1, xzr                                    
02cc643c: bl      #0x5b339ec                                 UnityEngine.Component::get_gameObject
02cc6440: ldr     x8, [x20]                                  &2c5bbd4(=a9bd7bfdd503233f)
02cc6444: mov     x19, x0                                    
02cc6448: ldr     w9, [x8, #0xe4]                            
02cc644c: cbnz    w9, #0x2cc6458                             
02cc6450: mov     x0, x8                                     
02cc6454: bl      #0x2b70f30                                 fn_2b70f30
02cc6458: mov     x0, x19                                    
02cc645c: ldp     x20, x19, [sp, #0x10]                      
02cc6460: mov     x1, xzr                                    
02cc6464: ldp     x30, x21, [sp], #0x20                      
02cc6468: b       #0x5b3ccec                                 UnityEngine.Object::DontDestroyOnLoad
## .ctor() -> void
---- Framework.DontDestroyOnLoad::.ctor 0x2cc646c
02cc646c: mov     x1, xzr                                    
02cc6470: b       #0x5b397b0                                 UnityEngine.MonoBehaviour::.ctor
