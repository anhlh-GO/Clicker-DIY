#### CLASS DailyTask.PopupDailyTaskTutorial/<OnShowAnim>d__6 parent= System.ValueType
#   field <>1__state                     int                                                off=0x10 attr=6 
#   field <>t__builder                   Cysharp.Threading.Tasks.CompilerServices.AsyncUniTaskVoidMethodBuilder off=0x18 attr=6 
#   field <>4__this                      DailyTask.PopupDailyTaskTutorial                   off=0x20 attr=6 
#   field <>7__wrap1                     System.Collections.Generic.List`1/Enumerator<UnityEngine.CanvasGroup> off=0x28 attr=1 
#   field <>u__1                         Cysharp.Threading.Tasks.UniTask/Awaiter            off=0x40 attr=1 
## MoveNext() -> void
---- DailyTask.PopupDailyTaskTutorial/<OnShowAnim>d__6::MoveNext 0x2d2eeac
02d2eeac: sub     sp, sp, #0xc0                              
02d2eeb0: stp     x30, x0, [sp, #0x80]                       
02d2eeb4: stp     x24, x23, [sp, #0x90]                      
02d2eeb8: stp     x22, x21, [sp, #0xa0]                      
02d2eebc: stp     x20, x19, [sp, #0xb0]                      
02d2eec0: adrp    x20, #0x6630000                            
02d2eec4: mov     x19, x0                                    
02d2eec8: ldrb    w8, [x20, #0xe7]                           
02d2eecc: tbnz    w8, #0, #0x2d2ef20                         
02d2eed0: adrp    x0, #0x626a000                             
02d2eed4: ldr     x0, [x0, #0x608]                           MS:Cysharp.Threading.Tasks.CompilerServices.AsyncUniTaskVoidMethodBuilder::AwaitUnsafeOnCompleted
02d2eed8: bl      #0x2b70db0                                 fn_2b70db0
02d2eedc: adrp    x0, #0x626a000                             
02d2eee0: ldr     x0, [x0, #0x5e0]                           MS:System.Collections.Generic.List`1/Enumerator::Dispose
02d2eee4: bl      #0x2b70db0                                 fn_2b70db0
02d2eee8: adrp    x0, #0x626a000                             
02d2eeec: ldr     x0, [x0, #0x5e8]                           MS:System.Collections.Generic.List`1/Enumerator::MoveNext
02d2eef0: bl      #0x2b70db0                                 fn_2b70db0
02d2eef4: adrp    x0, #0x626a000                             
02d2eef8: ldr     x0, [x0, #0x5f0]                           MS:System.Collections.Generic.List`1/Enumerator::get_Current
02d2eefc: bl      #0x2b70db0                                 fn_2b70db0
02d2ef00: adrp    x0, #0x626a000                             
02d2ef04: ldr     x0, [x0, #0x5f8]                           MS:System.Collections.Generic.List`1::GetEnumerator
02d2ef08: bl      #0x2b70db0                                 fn_2b70db0
02d2ef0c: adrp    x0, #0x6266000                             
02d2ef10: ldr     x0, [x0, #0xcc8]                           T:Cysharp.Threading.Tasks.UniTask
02d2ef14: bl      #0x2b70db0                                 fn_2b70db0
02d2ef18: mov     w8, #1                                     
02d2ef1c: strb    w8, [x20, #0xe7]                           
02d2ef20: str     wzr, [sp, #0x7c]                           
02d2ef24: adrp    x22, #0x626a000                            
02d2ef28: adrp    x23, #0x6266000                            
02d2ef2c: ldr     x22, [x22, #0x5e8]                         MS:System.Collections.Generic.List`1/Enumerator::MoveNext
02d2ef30: str     xzr, [sp, #0x68]                           
02d2ef34: adrp    x24, #0x6266000                            
02d2ef38: ldr     x23, [x23, #0xcc8]                         T:Cysharp.Threading.Tasks.UniTask
02d2ef3c: str     xzr, [sp, #0x60]                           
02d2ef40: ldr     w8, [x19]                                  
02d2ef44: str     wzr, [sp, #0x58]                           
02d2ef48: ldr     x19, [x19, #0x10]                          .<>1__state
02d2ef4c: ldr     x24, [x24, #0xcd0]                         T:Cysharp.Threading.Tasks.IUniTaskSource
02d2ef50: str     w8, [sp, #0x7c]                            
02d2ef54: cbz     w8, #0x2d2efbc                             
02d2ef58: cbz     x19, #0x2d2efec                            
02d2ef5c: ldr     x0, [x19, #0x48]                           
02d2ef60: cbz     x0, #0x2d2eff0                             
02d2ef64: adrp    x8, #0x626a000                             
02d2ef68: ldr     x8, [x8, #0x5f8]                           MS:System.Collections.Generic.List`1::GetEnumerator
02d2ef6c: ldr     x1, [x8]                                   T:type56879(k15)
02d2ef70: add     x8, sp, #0x10                              
02d2ef74: bl      #0x35a9d9c                                 fn_35a9d9c
02d2ef78: ldr     q0, [sp, #0x10]                            
02d2ef7c: ldr     x8, [sp, #0x20]                            
02d2ef80: ldr     x9, [sp, #0x88]                            
02d2ef84: str     q0, [sp, #0x30]                            
02d2ef88: str     x8, [sp, #0x40]                            
02d2ef8c: stur    q0, [x9, #0x18]                            
02d2ef90: str     x8, [x9, #0x28]                            
02d2ef94: add     x0, x9, #0x18                              
02d2ef98: mov     x1, xzr                                    
02d2ef9c: bl      #0x2b70d54                                 fn_2b70d54
02d2efa0: ldr     w8, [sp, #0x7c]                            
02d2efa4: add     x9, sp, #0x7c                              
02d2efa8: stp     xzr, x9, [sp, #0x30]                       
02d2efac: add     x9, sp, #0x88                              
02d2efb0: str     x9, [sp, #0x40]                            
02d2efb4: cbnz    w8, #0x2d2f090                             
02d2efb8: b       #0x2d2efcc                                 
02d2efbc: add     x8, sp, #0x7c                              
02d2efc0: add     x9, sp, #0x88                              
02d2efc4: stp     xzr, x8, [sp, #0x30]                       
02d2efc8: str     x9, [sp, #0x40]                            
02d2efcc: ldr     x8, [sp, #0x88]                            
02d2efd0: mov     w9, #-1                                    
02d2efd4: str     w9, [sp, #0x7c]                            
02d2efd8: ldr     q0, [x8, #0x30]                            S:'======================================================  i : '
02d2efdc: stp     xzr, xzr, [x8, #0x30]                      
02d2efe0: str     q0, [sp, #0x60]                            
02d2efe4: str     w9, [x8]                                   
02d2efe8: b       #0x2d2f004                                 
02d2efec: bl      #0x2b7105c                                 fn_2b7105c
02d2eff0: bl      #0x2b7105c                                 fn_2b7105c
02d2eff4: b       #0x2d2f2e8                                 
02d2eff8: b       #0x2d2f2e8                                 
02d2effc: b       #0x2d2f2e8                                 
02d2f000: b       #0x2d2f2e8                                 
02d2f004: adrp    x20, #0x662f000                            
02d2f008: ldrb    w8, [x20, #0xbde]                          
02d2f00c: cbnz    w8, #0x2d2f024                             
02d2f010: adrp    x0, #0x6266000                             
02d2f014: ldr     x0, [x0, #0xcd0]                           T:Cysharp.Threading.Tasks.IUniTaskSource
02d2f018: bl      #0x2b70db0                                 fn_2b70db0
02d2f01c: mov     w8, #1                                     
02d2f020: strb    w8, [x20, #0xbde]                          
02d2f024: ldr     x20, [sp, #0x60]                           
02d2f028: cbz     x20, #0x2d2f090                            
02d2f02c: ldr     x8, [x20]                                  &2b706c4(=eb01011ff9400808)
02d2f030: ldrh    w21, [sp, #0x68]                           
02d2f034: ldr     x1, [x24]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d2f038: ldrh    w9, [x8, #0x12e]                           
02d2f03c: cbz     x9, #0x2d2f060                             
02d2f040: ldr     x10, [x8, #0xb0]                           T:type56715(k15)
02d2f044: add     x10, x10, #8                               
02d2f048: ldur    x11, [x10, #-8]                            
02d2f04c: cmp     x11, x1                                    
02d2f050: b.eq    #0x2d2f070                                 
02d2f054: subs    x9, x9, #1                                 
02d2f058: add     x10, x10, #0x10                            
02d2f05c: b.ne    #0x2d2f048                                 
02d2f060: mov     x0, x20                                    
02d2f064: mov     w2, #2                                     
02d2f068: bl      #0x2baa05c                                 fn_2baa05c
02d2f06c: b       #0x2d2f080                                 
02d2f070: ldr     w9, [x10]                                  
02d2f074: add     w9, w9, #2                                 
02d2f078: add     x8, x8, w9, sxtw #4                        &626a000
02d2f07c: add     x0, x8, #0x138                             &626a138
02d2f080: ldp     x8, x2, [x0]                               
02d2f084: mov     x0, x20                                    
02d2f088: mov     w1, w21                                    
02d2f08c: blr     x8                                         
02d2f090: ldr     x1, [x22]                                  T:type56879(k15)
02d2f094: ldr     x8, [sp, #0x88]                            
02d2f098: add     x0, x8, #0x18                              &626a018
02d2f09c: bl      #0x4690474                                 fn_4690474
02d2f0a0: tbz     w0, #0, #0x2d2f218                         
02d2f0a4: ldr     x8, [sp, #0x88]                            
02d2f0a8: ldr     x0, [x8, #0x28]                            T:Decor.DataDecor/<>c__DisplayClass8_0
02d2f0ac: fmov    s0, #0.50000000                            
02d2f0b0: mov     w1, #1                                     
02d2f0b4: mov     x2, xzr                                    
02d2f0b8: bl      #0x2cf1928                                 FrameWorkUtility::SetActive
02d2f0bc: cbz     x19, #0x2d2f2bc                            
02d2f0c0: mov     x0, x19                                    
02d2f0c4: mov     x1, xzr                                    
02d2f0c8: bl      #0x5b37c84                                 UnityEngine.MonoBehaviour::get_destroyCancellationToken
02d2f0cc: mov     x20, x0                                    
02d2f0d0: ldr     x0, [x23]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d2f0d4: ldr     w8, [x0, #0xe4]                            [62660e4]=0 f=0,0
02d2f0d8: cbnz    w8, #0x2d2f0e0                             
02d2f0dc: bl      #0x2b70f30                                 fn_2b70f30
02d2f0e0: fmov    s0, #0.25000000                            
02d2f0e4: mov     w0, wzr                                    
02d2f0e8: mov     w1, #8                                     
02d2f0ec: mov     x2, x20                                    
02d2f0f0: mov     w3, wzr                                    
02d2f0f4: mov     x4, xzr                                    
02d2f0f8: bl      #0x5447b08                                 Cysharp.Threading.Tasks.UniTask::WaitForSeconds
02d2f0fc: stp     x0, x1, [sp, #0x10]                        
02d2f100: add     x0, sp, #0x10                              
02d2f104: mov     x1, xzr                                    
02d2f108: bl      #0x2b70d54                                 fn_2b70d54
02d2f10c: adrp    x20, #0x662f000                            
02d2f110: ldr     q0, [sp, #0x10]                            
02d2f114: ldrb    w8, [x20, #0xbdc]                          
02d2f118: str     q0, [sp, #0x60]                            
02d2f11c: cbnz    w8, #0x2d2f134                             
02d2f120: adrp    x0, #0x6266000                             
02d2f124: ldr     x0, [x0, #0xcc8]                           T:Cysharp.Threading.Tasks.UniTask
02d2f128: bl      #0x2b70db0                                 fn_2b70db0
02d2f12c: mov     w8, #1                                     
02d2f130: strb    w8, [x20, #0xbdc]                          
02d2f134: ldr     x0, [x23]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d2f138: ldr     w8, [x0, #0xe4]                            [62660e4]=0 f=0,0
02d2f13c: cbnz    w8, #0x2d2f144                             
02d2f140: bl      #0x2b70f30                                 fn_2b70f30
02d2f144: adrp    x20, #0x662f000                            
02d2f148: ldrb    w8, [x20, #0xbdd]                          
02d2f14c: cbnz    w8, #0x2d2f164                             
02d2f150: adrp    x0, #0x6266000                             
02d2f154: ldr     x0, [x0, #0xcd0]                           T:Cysharp.Threading.Tasks.IUniTaskSource
02d2f158: bl      #0x2b70db0                                 fn_2b70db0
02d2f15c: mov     w8, #1                                     
02d2f160: strb    w8, [x20, #0xbdd]                          
02d2f164: ldr     x20, [sp, #0x60]                           
02d2f168: cbz     x20, #0x2d2f004                            
02d2f16c: ldr     x8, [x20]                                  &2b706c4(=eb01011ff9400808)
02d2f170: ldrh    w21, [sp, #0x68]                           
02d2f174: ldr     x1, [x24]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d2f178: ldrh    w9, [x8, #0x12e]                           
02d2f17c: cbz     x9, #0x2d2f1a0                             
02d2f180: ldr     x10, [x8, #0xb0]                           T:type56715(k15)
02d2f184: add     x10, x10, #8                               
02d2f188: ldur    x11, [x10, #-8]                            
02d2f18c: cmp     x11, x1                                    
02d2f190: b.eq    #0x2d2f1b0                                 
02d2f194: subs    x9, x9, #1                                 
02d2f198: add     x10, x10, #0x10                            
02d2f19c: b.ne    #0x2d2f188                                 
02d2f1a0: mov     x0, x20                                    
02d2f1a4: mov     w2, wzr                                    
02d2f1a8: bl      #0x2baa05c                                 fn_2baa05c
02d2f1ac: b       #0x2d2f1bc                                 
02d2f1b0: ldrsw   x9, [x10]                                  
02d2f1b4: add     x8, x8, x9, lsl #4                         &626a000
02d2f1b8: add     x0, x8, #0x138                             &626a138
02d2f1bc: ldp     x8, x2, [x0]                               
02d2f1c0: mov     x0, x20                                    
02d2f1c4: mov     w1, w21                                    
02d2f1c8: blr     x8                                         
02d2f1cc: cbnz    w0, #0x2d2f004                             
02d2f1d0: ldr     x8, [sp, #0x88]                            
02d2f1d4: str     wzr, [sp, #0x7c]                           
02d2f1d8: str     wzr, [x8]                                  
02d2f1dc: ldr     q0, [sp, #0x60]                            
02d2f1e0: str     q0, [x8, #0x30]                            
02d2f1e4: add     x0, x8, #0x30                              &626a030
02d2f1e8: mov     x1, xzr                                    
02d2f1ec: bl      #0x2b70d54                                 fn_2b70d54
02d2f1f0: adrp    x8, #0x626a000                             
02d2f1f4: ldr     x8, [x8, #0x608]                           MS:Cysharp.Threading.Tasks.CompilerServices.AsyncUniTaskVoidMethodBuilder::AwaitUnsafeOnCompleted
02d2f1f8: ldr     x2, [sp, #0x88]                            
02d2f1fc: ldr     x3, [x8]                                   T:type56879(k15)
02d2f200: add     x0, x2, #8                                 
02d2f204: add     x1, sp, #0x60                              
02d2f208: bl      #0x2d2f804                                 fn_2d2f804
02d2f20c: mov     x20, xzr                                   
02d2f210: mov     w21, #7                                    
02d2f214: b       #0x2d2f220                                 
02d2f218: mov     x20, xzr                                   
02d2f21c: mov     w21, #8                                    
02d2f220: add     x8, sp, #0x7c                              
02d2f224: ldr     w8, [x8]                                   T:type56879(k15)
02d2f228: tbz     w8, #0x1f, #0x2d2f248                      
02d2f22c: adrp    x9, #0x626a000                             
02d2f230: ldr     x8, [sp, #0x40]                            
02d2f234: ldr     x9, [x9, #0x5e0]                           MS:System.Collections.Generic.List`1/Enumerator::Dispose
02d2f238: ldr     x8, [x8]                                   T:type56879(k15)
02d2f23c: ldr     x1, [x9]                                   T:type56879(k15)
02d2f240: add     x0, x8, #0x18                              &626a018
02d2f244: bl      #0x4690470                                 fn_4690470
02d2f248: cbnz    x20, #0x2d2f2c0                            
02d2f24c: orr     w8, w21, #8                                
02d2f250: cmp     w8, #8                                     
02d2f254: b.ne    #0x2d2f2a4                                 
02d2f258: ldr     x8, [sp, #0x88]                            
02d2f25c: stp     xzr, xzr, [x8, #0x20]                      
02d2f260: str     xzr, [x8, #0x18]                           
02d2f264: cbz     x19, #0x2d2f2c8                            
02d2f268: ldr     x0, [x19, #0x40]                           .<>u__1
02d2f26c: cbz     x0, #0x2d2f2cc                             
02d2f270: mov     w1, #1                                     
02d2f274: mov     x2, xzr                                    
02d2f278: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d2f27c: ldr     x0, [x19, #0x38]                           
02d2f280: cbz     x0, #0x2d2f2d0                             
02d2f284: mov     w1, #1                                     
02d2f288: mov     x2, xzr                                    
02d2f28c: bl      #0x5e662d4                                 UnityEngine.UI.Selectable::set_interactable
02d2f290: ldr     x0, [sp, #0x88]                            
02d2f294: mov     w8, #-2                                    
02d2f298: mov     x1, xzr                                    
02d2f29c: str     w8, [x0], #8                               
02d2f2a0: bl      #0x2d2f600                                 fn_2d2f600
02d2f2a4: ldp     x20, x19, [sp, #0xb0]                      
02d2f2a8: ldr     x30, [sp, #0x80]                           
02d2f2ac: ldp     x22, x21, [sp, #0xa0]                      
02d2f2b0: ldp     x24, x23, [sp, #0x90]                      
02d2f2b4: add     sp, sp, #0xc0                              
02d2f2b8: ret                                                
02d2f2bc: bl      #0x2b7105c                                 fn_2b7105c
02d2f2c0: mov     x0, x20                                    
02d2f2c4: bl      #0x2b71054                                 fn_2b71054
02d2f2c8: bl      #0x2b7105c                                 fn_2b7105c
02d2f2cc: bl      #0x2b7105c                                 fn_2b7105c
02d2f2d0: bl      #0x2b7105c                                 fn_2b7105c
02d2f2d4: b       #0x2d2f314                                 
02d2f2d8: b       #0x2d2f314                                 
02d2f2dc: b       #0x2d2f2e8                                 
02d2f2e0: b       #0x2d2f2e8                                 
02d2f2e4: b       #0x2d2f2e8                                 
02d2f2e8: mov     x19, x1                                    
02d2f2ec: str     x0, [sp, #8]                               
02d2f2f0: b       #0x2d2f348                                 
02d2f2f4: b       #0x2d2f314                                 
02d2f2f8: b       #0x2d2f314                                 
02d2f2fc: b       #0x2d2f314                                 
02d2f300: b       #0x2d2f314                                 
02d2f304: b       #0x2d2f314                                 
02d2f308: b       #0x2d2f314                                 
02d2f30c: b       #0x2d2f314                                 
02d2f310: b       #0x2d2f314                                 
02d2f314: cmp     w1, #1                                     
02d2f318: b.ne    #0x2d2f338                                 
02d2f31c: bl      #0x5e90260                                 fn_5e90260
02d2f320: ldr     x20, [x0]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d2f324: str     x20, [sp, #0x30]                           
02d2f328: bl      #0x5e90270                                 fn_5e90270
02d2f32c: ldr     x8, [sp, #0x38]                            
02d2f330: mov     w21, wzr                                   
02d2f334: b       #0x2d2f224                                 
02d2f338: mov     x19, x1                                    
02d2f33c: str     x0, [sp, #8]                               
02d2f340: add     x0, sp, #0x30                              
02d2f344: bl      #0x273823c                                 fn_273823c
02d2f348: cmp     w19, #1                                    
02d2f34c: b.ne    #0x2d2f3dc                                 
02d2f350: ldr     x0, [sp, #8]                               
02d2f354: bl      #0x5e90260                                 fn_5e90260
02d2f358: mov     x19, x0                                    
02d2f35c: adrp    x0, #0x6263000                             
02d2f360: ldr     x0, [x0, #0xae0]                           T:System.Exception
02d2f364: bl      #0x2b70dc4                                 fn_2b70dc4
02d2f368: ldr     x8, [x19]                                  
02d2f36c: ldr     x1, [x8]                                   T:type56879(k15)
02d2f370: bl      #0x2b71464                                 fn_2b71464
02d2f374: tbz     w0, #0, #0x2d2f3b4                         
02d2f378: ldrsw   x20, [sp, #0x58]                           
02d2f37c: ldr     x19, [x19]                                 
02d2f380: add     x8, sp, #0x50                              
02d2f384: str     x19, [x8, x20, lsl #3]                     
02d2f388: add     w8, w20, #1                                
02d2f38c: str     w8, [sp, #0x58]                            
02d2f390: bl      #0x5e90270                                 fn_5e90270
02d2f394: ldr     x0, [sp, #0x88]                            
02d2f398: mov     w8, #-2                                    
02d2f39c: mov     x1, x19                                    
02d2f3a0: mov     x2, xzr                                    
02d2f3a4: str     w8, [x0], #8                               
02d2f3a8: bl      #0x2d2f4e0                                 fn_2d2f4e0
02d2f3ac: str     w20, [sp, #0x58]                           
02d2f3b0: b       #0x2d2f2a4                                 
02d2f3b4: mov     w0, #8                                     
02d2f3b8: bl      #0x5e90290                                 fn_5e90290
02d2f3bc: ldr     x8, [x19]                                  
02d2f3c0: str     x8, [x0]                                   
02d2f3c4: adrp    x1, #0x5e96000                             
02d2f3c8: add     x1, x1, #0x758                             &5e96758
02d2f3cc: mov     x2, xzr                                    
02d2f3d0: bl      #0x5e902a0                                 fn_5e902a0
02d2f3d4: str     x0, [sp, #8]                               
02d2f3d8: bl      #0x5e90270                                 fn_5e90270
02d2f3dc: ldr     x0, [sp, #8]                               
02d2f3e0: bl      #0x2c6051c                                 fn_2c6051c
02d2f3e4: bl      #0x27369b8                                 fn_27369b8
## SetStateMachine(System.Runtime.CompilerServices.IAsyncStateMachine stateMachine) -> void
---- DailyTask.PopupDailyTaskTutorial/<OnShowAnim>d__6::SetStateMachine 0x2d2f3e8
02d2f3e8: add     x0, x0, #8                                 
02d2f3ec: mov     x2, xzr                                    
02d2f3f0: b       #0x54605f8                                 Cysharp.Threading.Tasks.CompilerServices.AsyncUniTaskVoidMethodBuilder::SetStateMachine
#### CLASS DailyTask.PopupDailyTaskTutorial parent= PopupBase
#   field _closeButton                   UnityEngine.UI.Button                              off=0x38 attr=1 SerializeField
#   field _textObject                    UnityEngine.GameObject                             off=0x40 attr=1 SerializeField
#   field _tutorialSteps                 System.Collections.Generic.List`1<UnityEngine.CanvasGroup> off=0x48 attr=1 SerializeField
## OnDestroy() -> void
---- DailyTask.PopupDailyTaskTutorial::OnDestroy 0x2d2ead0
02d2ead0: stp     x30, x21, [sp, #-0x20]!                    
02d2ead4: stp     x20, x19, [sp, #0x10]                      
02d2ead8: adrp    x20, #0x6630000                            
02d2eadc: mov     x19, x0                                    
02d2eae0: ldrb    w8, [x20, #0xe2]                           
02d2eae4: tbnz    w8, #0, #0x2d2eb08                         
02d2eae8: adrp    x0, #0x626a000                             
02d2eaec: ldr     x0, [x0, #0x5d8]                           M:DailyTask.PopupDailyTaskTutorial::OnButtonCloseClicked
02d2eaf0: bl      #0x2b70db0                                 fn_2b70db0
02d2eaf4: adrp    x0, #0x6265000                             
02d2eaf8: ldr     x0, [x0, #0x3f0]                           T:UnityEngine.Events.UnityAction
02d2eafc: bl      #0x2b70db0                                 fn_2b70db0
02d2eb00: mov     w8, #1                                     
02d2eb04: strb    w8, [x20, #0xe2]                           
02d2eb08: ldr     x8, [x19, #0x38]                           ._closeButton
02d2eb0c: cbz     x8, #0x2d2eb5c                             
02d2eb10: adrp    x9, #0x6265000                             
02d2eb14: adrp    x21, #0x626a000                            
02d2eb18: ldr     x9, [x9, #0x3f0]                           T:UnityEngine.Events.UnityAction
02d2eb1c: ldr     x21, [x21, #0x5d8]                         M:DailyTask.PopupDailyTaskTutorial::OnButtonCloseClicked
02d2eb20: ldr     x20, [x8, #0x100]                          
02d2eb24: ldr     x0, [x9]                                   M:AdsManager::<OnApplicationPause>b__26_0
02d2eb28: bl      #0x2b7104c                                 fn_2b7104c
02d2eb2c: ldr     x2, [x21]                                  T:type56879(k15)
02d2eb30: mov     x1, x19                                    
02d2eb34: mov     x3, xzr                                    
02d2eb38: mov     x21, x0                                    
02d2eb3c: bl      #0x5b4cf98                                 UnityEngine.Events.UnityAction::.ctor
02d2eb40: cbz     x20, #0x2d2eb5c                            
02d2eb44: mov     x0, x20                                    
02d2eb48: ldp     x20, x19, [sp, #0x10]                      
02d2eb4c: mov     x1, x21                                    
02d2eb50: mov     x2, xzr                                    
02d2eb54: ldp     x30, x21, [sp], #0x20                      
02d2eb58: b       #0x5b4d13c                                 UnityEngine.Events.UnityEvent::RemoveListener
02d2eb5c: bl      #0x2b7105c                                 fn_2b7105c
## OnInit(UIManager uiManager) -> void
---- DailyTask.PopupDailyTaskTutorial::OnInit 0x2d2eb60
02d2eb60: stp     x30, x21, [sp, #-0x20]!                    
02d2eb64: stp     x20, x19, [sp, #0x10]                      
02d2eb68: adrp    x21, #0x6630000                            
02d2eb6c: mov     x20, x1                                    
02d2eb70: mov     x19, x0                                    
02d2eb74: ldrb    w8, [x21, #0xe3]                           
02d2eb78: tbnz    w8, #0, #0x2d2eb9c                         
02d2eb7c: adrp    x0, #0x626a000                             
02d2eb80: ldr     x0, [x0, #0x5d8]                           M:DailyTask.PopupDailyTaskTutorial::OnButtonCloseClicked
02d2eb84: bl      #0x2b70db0                                 fn_2b70db0
02d2eb88: adrp    x0, #0x6265000                             
02d2eb8c: ldr     x0, [x0, #0x3f0]                           T:UnityEngine.Events.UnityAction
02d2eb90: bl      #0x2b70db0                                 fn_2b70db0
02d2eb94: mov     w8, #1                                     
02d2eb98: strb    w8, [x21, #0xe3]                           
02d2eb9c: mov     x0, x19                                    
02d2eba0: mov     x1, x20                                    
02d2eba4: mov     x2, xzr                                    
02d2eba8: bl      #0x2cdd3c4                                 UIBase::OnInit
02d2ebac: ldr     x8, [x19, #0x38]                           ._closeButton
02d2ebb0: cbz     x8, #0x2d2ec00                             
02d2ebb4: adrp    x9, #0x6265000                             
02d2ebb8: adrp    x21, #0x626a000                            
02d2ebbc: ldr     x9, [x9, #0x3f0]                           T:UnityEngine.Events.UnityAction
02d2ebc0: ldr     x21, [x21, #0x5d8]                         M:DailyTask.PopupDailyTaskTutorial::OnButtonCloseClicked
02d2ebc4: ldr     x20, [x8, #0x100]                          
02d2ebc8: ldr     x0, [x9]                                   M:AdsManager::<OnApplicationPause>b__26_0
02d2ebcc: bl      #0x2b7104c                                 fn_2b7104c
02d2ebd0: ldr     x2, [x21]                                  T:type56879(k15)
02d2ebd4: mov     x1, x19                                    
02d2ebd8: mov     x3, xzr                                    
02d2ebdc: mov     x21, x0                                    
02d2ebe0: bl      #0x5b4cf98                                 UnityEngine.Events.UnityAction::.ctor
02d2ebe4: cbz     x20, #0x2d2ec00                            
02d2ebe8: mov     x0, x20                                    
02d2ebec: ldp     x20, x19, [sp, #0x10]                      
02d2ebf0: mov     x1, x21                                    
02d2ebf4: mov     x2, xzr                                    
02d2ebf8: ldp     x30, x21, [sp], #0x20                      
02d2ebfc: b       #0x5b4d0ac                                 UnityEngine.Events.UnityEvent::AddListener
02d2ec00: bl      #0x2b7105c                                 fn_2b7105c
## OnShow() -> void
---- DailyTask.PopupDailyTaskTutorial::OnShow 0x2d2ec04
02d2ec04: sub     sp, sp, #0x60                              
02d2ec08: str     x30, [sp, #0x30]                           
02d2ec0c: stp     x22, x21, [sp, #0x40]                      
02d2ec10: stp     x20, x19, [sp, #0x50]                      
02d2ec14: adrp    x20, #0x6630000                            
02d2ec18: mov     x19, x0                                    
02d2ec1c: ldrb    w8, [x20, #0xe4]                           
02d2ec20: tbnz    w8, #0, #0x2d2ec5c                         
02d2ec24: adrp    x0, #0x626a000                             
02d2ec28: ldr     x0, [x0, #0x5e0]                           MS:System.Collections.Generic.List`1/Enumerator::Dispose
02d2ec2c: bl      #0x2b70db0                                 fn_2b70db0
02d2ec30: adrp    x0, #0x626a000                             
02d2ec34: ldr     x0, [x0, #0x5e8]                           MS:System.Collections.Generic.List`1/Enumerator::MoveNext
02d2ec38: bl      #0x2b70db0                                 fn_2b70db0
02d2ec3c: adrp    x0, #0x626a000                             
02d2ec40: ldr     x0, [x0, #0x5f0]                           MS:System.Collections.Generic.List`1/Enumerator::get_Current
02d2ec44: bl      #0x2b70db0                                 fn_2b70db0
02d2ec48: adrp    x0, #0x626a000                             
02d2ec4c: ldr     x0, [x0, #0x5f8]                           MS:System.Collections.Generic.List`1::GetEnumerator
02d2ec50: bl      #0x2b70db0                                 fn_2b70db0
02d2ec54: mov     w8, #1                                     
02d2ec58: strb    w8, [x20, #0xe4]                           
02d2ec5c: mov     x0, x19                                    
02d2ec60: mov     x1, xzr                                    
02d2ec64: stp     xzr, xzr, [sp, #0x18]                      
02d2ec68: str     xzr, [sp, #0x28]                           
02d2ec6c: strb    wzr, [sp, #0x3c]                           
02d2ec70: bl      #0x2cdd6b8                                 UIBase::OnShow
02d2ec74: ldr     x0, [x19, #0x48]                           ._tutorialSteps
02d2ec78: cbz     x0, #0x2d2ed30                             
02d2ec7c: adrp    x8, #0x626a000                             
02d2ec80: adrp    x20, #0x626a000                            
02d2ec84: adrp    x21, #0x626a000                            
02d2ec88: ldr     x8, [x8, #0x5f8]                           MS:System.Collections.Generic.List`1::GetEnumerator
02d2ec8c: ldr     x20, [x20, #0x5e8]                         MS:System.Collections.Generic.List`1/Enumerator::MoveNext
02d2ec90: ldr     x21, [x21, #0x5e0]                         MS:System.Collections.Generic.List`1/Enumerator::Dispose
02d2ec94: add     x22, sp, #0x18                             
02d2ec98: ldr     x1, [x8]                                   T:type56879(k15)
02d2ec9c: add     x8, sp, #0x18                              
02d2eca0: bl      #0x35a9d9c                                 fn_35a9d9c
02d2eca4: stp     xzr, x22, [sp, #8]                         
02d2eca8: ldr     x1, [x20]                                  T:type56879(k15)
02d2ecac: add     x0, sp, #0x18                              
02d2ecb0: bl      #0x4690474                                 fn_4690474
02d2ecb4: tbz     w0, #0, #0x2d2ecd0                         
02d2ecb8: ldr     x0, [sp, #0x28]                            
02d2ecbc: movi    d0, #0000000000000000                      
02d2ecc0: mov     w1, wzr                                    
02d2ecc4: mov     x2, xzr                                    
02d2ecc8: bl      #0x2cf1928                                 FrameWorkUtility::SetActive
02d2eccc: b       #0x2d2eca8                                 
02d2ecd0: ldr     x1, [x21]                                  T:type56879(k15)
02d2ecd4: add     x0, sp, #0x18                              
02d2ecd8: bl      #0x4690470                                 fn_4690470
02d2ecdc: ldr     x0, [x19, #0x40]                           ._textObject
02d2ece0: cbz     x0, #0x2d2ed30                             
02d2ece4: mov     w1, wzr                                    
02d2ece8: mov     x2, xzr                                    
02d2ecec: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d2ecf0: ldr     x0, [x19, #0x38]                           ._closeButton
02d2ecf4: cbz     x0, #0x2d2ed30                             
02d2ecf8: mov     w1, wzr                                    
02d2ecfc: mov     x2, xzr                                    
02d2ed00: bl      #0x5e662d4                                 UnityEngine.UI.Selectable::set_interactable
02d2ed04: mov     x0, x19                                    
02d2ed08: bl      #0x2d2ed88                                 DailyTask.PopupDailyTaskTutorial::OnShowAnim
02d2ed0c: strb    w0, [sp, #0x3c]                            
02d2ed10: add     x0, sp, #0x3c                              
02d2ed14: mov     x1, xzr                                    
02d2ed18: bl      #0x5460194                                 Cysharp.Threading.Tasks.UniTaskVoid::Forget
02d2ed1c: ldp     x20, x19, [sp, #0x50]                      
02d2ed20: ldr     x30, [sp, #0x30]                           
02d2ed24: ldp     x22, x21, [sp, #0x40]                      
02d2ed28: add     sp, sp, #0x60                              
02d2ed2c: ret                                                
02d2ed30: bl      #0x2b7105c                                 fn_2b7105c
02d2ed34: b       #0x2d2ed38                                 
02d2ed38: mov     x20, x0                                    
02d2ed3c: cmp     w1, #1                                     
02d2ed40: b.ne    #0x2d2ed74                                 
02d2ed44: mov     x0, x20                                    
02d2ed48: bl      #0x5e90260                                 fn_5e90260
02d2ed4c: ldr     x20, [x0]                                  T:type56879(k15)
02d2ed50: str     x20, [sp, #8]                              
02d2ed54: bl      #0x5e90270                                 fn_5e90270
02d2ed58: ldr     x0, [sp, #0x10]                            
02d2ed5c: ldr     x1, [x21]                                  T:type56879(k15)
02d2ed60: bl      #0x4690470                                 fn_4690470
02d2ed64: cbz     x20, #0x2d2ecdc                            
02d2ed68: mov     x0, x20                                    
02d2ed6c: bl      #0x2b71054                                 fn_2b71054
02d2ed70: mov     x20, x0                                    
02d2ed74: add     x0, sp, #8                                 
02d2ed78: bl      #0x273820c                                 fn_273820c
02d2ed7c: mov     x0, x20                                    
02d2ed80: bl      #0x2c6051c                                 fn_2c6051c
02d2ed84: bl      #0x27369b8                                 fn_27369b8
## OnShowAnim() -> Cysharp.Threading.Tasks.UniTaskVoid
---- DailyTask.PopupDailyTaskTutorial::OnShowAnim 0x2d2ed88
02d2ed88: sub     sp, sp, #0x60                              
02d2ed8c: stp     x30, x21, [sp, #0x40]                      
02d2ed90: stp     x20, x19, [sp, #0x50]                      
02d2ed94: adrp    x21, #0x6630000                            
02d2ed98: adrp    x20, #0x626a000                            
02d2ed9c: mov     x19, x0                                    
02d2eda0: ldrb    w8, [x21, #0xe5]                           
02d2eda4: ldr     x20, [x20, #0x600]                         MS:Cysharp.Threading.Tasks.CompilerServices.AsyncUniTaskVoidMethodBuilder::Start
02d2eda8: tbnz    w8, #0, #0x2d2edc0                         
02d2edac: adrp    x0, #0x626a000                             
02d2edb0: ldr     x0, [x0, #0x600]                           MS:Cysharp.Threading.Tasks.CompilerServices.AsyncUniTaskVoidMethodBuilder::Start
02d2edb4: bl      #0x2b70db0                                 fn_2b70db0
02d2edb8: mov     w8, #1                                     
02d2edbc: strb    w8, [x21, #0xe5]                           
02d2edc0: movi    v0.2d, #0000000000000000                   
02d2edc4: mov     x21, sp                                    
02d2edc8: mov     x1, xzr                                    
02d2edcc: orr     x0, x21, #8                                
02d2edd0: stp     q0, q0, [sp]                               
02d2edd4: stp     q0, q0, [sp, #0x20]                        
02d2edd8: bl      #0x2b70d54                                 fn_2b70d54
02d2eddc: add     x0, x21, #0x10                             &6630010
02d2ede0: mov     x1, x19                                    
02d2ede4: str     x19, [sp, #0x10]                           
02d2ede8: bl      #0x2b70d54                                 fn_2b70d54
02d2edec: ldr     x2, [x20]                                  T:type56879(k15)
02d2edf0: mov     w8, #-1                                    
02d2edf4: orr     x0, x21, #8                                
02d2edf8: mov     x1, sp                                     
02d2edfc: str     w8, [sp]                                   
02d2ee00: bl      #0x30b65c4                                 fn_30b65c4
02d2ee04: ldp     x20, x19, [sp, #0x50]                      
02d2ee08: mov     w0, wzr                                    
02d2ee0c: ldp     x30, x21, [sp, #0x40]                      
02d2ee10: add     sp, sp, #0x60                              
02d2ee14: ret                                                
## OnButtonCloseClicked() -> void
---- DailyTask.PopupDailyTaskTutorial::OnButtonCloseClicked 0x2d2ee18
02d2ee18: str     x30, [sp, #-0x20]!                         
02d2ee1c: stp     x20, x19, [sp, #0x10]                      
02d2ee20: adrp    x20, #0x6630000                            
02d2ee24: mov     x19, x0                                    
02d2ee28: ldrb    w8, [x20, #0xe6]                           
02d2ee2c: tbnz    w8, #0, #0x2d2ee44                         
02d2ee30: adrp    x0, #0x6266000                             
02d2ee34: ldr     x0, [x0, #0xba8]                           MS:UIManager::ShowPopup
02d2ee38: bl      #0x2b70db0                                 fn_2b70db0
02d2ee3c: mov     w8, #1                                     
02d2ee40: strb    w8, [x20, #0xe6]                           
02d2ee44: mov     x0, xzr                                    
02d2ee48: bl      #0x2d6eec8                                 Framework.AudioManager::get_Instance
02d2ee4c: cbz     x0, #0x2d2eea0                             
02d2ee50: movi    d1, #0000000000000000                      
02d2ee54: movi    d2, #0000000000000000                      
02d2ee58: mov     w1, #1                                     
02d2ee5c: fmov    s0, #1.00000000                            
02d2ee60: mov     w2, wzr                                    
02d2ee64: mov     w3, wzr                                    
02d2ee68: mov     x4, xzr                                    
02d2ee6c: bl      #0x2d6f03c                                 Framework.AudioManager::PlaySound
02d2ee70: ldr     x8, [x19]                                  
02d2ee74: mov     x0, x19                                    
02d2ee78: ldp     x9, x1, [x8, #0x198]                       
02d2ee7c: blr     x9                                         
02d2ee80: ldr     x0, [x19, #0x30]                           
02d2ee84: cbz     x0, #0x2d2eea0                             
02d2ee88: adrp    x8, #0x6266000                             
02d2ee8c: ldr     x8, [x8, #0xba8]                           MS:UIManager::ShowPopup
02d2ee90: ldp     x20, x19, [sp, #0x10]                      
02d2ee94: ldr     x1, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d2ee98: ldr     x30, [sp], #0x20                           
02d2ee9c: b       #0x33fbfac                                 
02d2eea0: bl      #0x2b7105c                                 fn_2b7105c
## .ctor() -> void
---- DailyTask.PopupDailyTaskTutorial::.ctor 0x2d2eea4
02d2eea4: mov     x1, xzr                                    
02d2eea8: b       #0x2cddba8                                 PopupBase::.ctor
