#### CLASS DreamHouse.ButtonObject parent= UnityEngine.MonoBehaviour
#   field OnButtonPressed                UnityEngine.Events.UnityEvent                      off=0x20 attr=6 
#   field OnButtonReleased               UnityEngine.Events.UnityEvent                      off=0x28 attr=6 
#   field _collider2D                    UnityEngine.Collider2D                             off=0x30 attr=1 SerializeField
#   field _isInteractable                bool                                               off=0x38 attr=1 
#   field <IsPressed>k__BackingField     bool                                               off=0x39 attr=1 CompilerGeneratedAttribute
## get_IsPressed() -> bool
---- DreamHouse.ButtonObject::get_IsPressed 0x2d15d90
02d15d90: ldrb    w0, [x0, #0x39]                            .<IsPressed>k__BackingField
02d15d94: ret                                                
## set_IsPressed(bool value) -> void
---- DreamHouse.ButtonObject::set_IsPressed 0x2d15d98
02d15d98: strb    w1, [x0, #0x39]                            .<IsPressed>k__BackingField
02d15d9c: ret                                                
## Awake() -> void
---- DreamHouse.ButtonObject::Awake 0x2d15da0
02d15da0: stp     x30, x21, [sp, #-0x20]!                    
02d15da4: stp     x20, x19, [sp, #0x10]                      
02d15da8: adrp    x20, #0x662f000                            
02d15dac: adrp    x21, #0x6269000                            
02d15db0: mov     x19, x0                                    
02d15db4: ldrb    w8, [x20, #0xfd3]                          
02d15db8: ldr     x21, [x21, #0x8f0]                         MS:UnityEngine.Component::GetComponent
02d15dbc: tbnz    w8, #0, #0x2d15dd4                         
02d15dc0: adrp    x0, #0x6269000                             
02d15dc4: ldr     x0, [x0, #0x8f0]                           MS:UnityEngine.Component::GetComponent
02d15dc8: bl      #0x2b70db0                                 fn_2b70db0
02d15dcc: mov     w8, #1                                     
02d15dd0: strb    w8, [x20, #0xfd3]                          
02d15dd4: ldr     x1, [x21]                                  T:Trading.TradingSession/<>c__DisplayClass56_0
02d15dd8: mov     x0, x19                                    
02d15ddc: bl      #0x3140c84                                 fn_3140c84
02d15de0: mov     x1, x0                                     
02d15de4: str     x0, [x19, #0x30]!                          ._collider2D
02d15de8: mov     x0, x19                                    
02d15dec: bl      #0x2b70d54                                 fn_2b70d54
02d15df0: strb    wzr, [x19, #9]                             
02d15df4: ldp     x20, x19, [sp, #0x10]                      
02d15df8: ldp     x30, x21, [sp], #0x20                      
02d15dfc: ret                                                
## OnPointerDown(UnityEngine.EventSystems.PointerEventData eventData) -> void
---- DreamHouse.ButtonObject::OnPointerDown 0x2d15e00
02d15e00: str     x30, [sp, #-0x20]!                         
02d15e04: stp     x20, x19, [sp, #0x10]                      
02d15e08: adrp    x20, #0x662f000                            
02d15e0c: mov     x19, x0                                    
02d15e10: ldrb    w8, [x20, #0xfd4]                          
02d15e14: tbnz    w8, #0, #0x2d15e2c                         
02d15e18: adrp    x0, #0x6266000                             
02d15e1c: ldr     x0, [x0, #0x948]                           T:Touch
02d15e20: bl      #0x2b70db0                                 fn_2b70db0
02d15e24: mov     w8, #1                                     
02d15e28: strb    w8, [x20, #0xfd4]                          
02d15e2c: ldrb    w8, [x19, #0x38]                           ._isInteractable
02d15e30: cbz     w8, #0x2d15e78                             
02d15e34: adrp    x8, #0x6266000                             
02d15e38: ldr     x8, [x8, #0x948]                           T:Touch
02d15e3c: ldr     x0, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d15e40: ldr     w8, [x0, #0xe4]                            [62660e4]=0 f=0,0
02d15e44: cbnz    w8, #0x2d15e4c                             
02d15e48: bl      #0x2b70f30                                 fn_2b70f30
02d15e4c: mov     x0, xzr                                    
02d15e50: bl      #0x2cd6230                                 Touch::IsPointerOverUIObject
02d15e54: tbnz    w0, #0, #0x2d15e78                         
02d15e58: ldr     x0, [x19, #0x20]                           .OnButtonPressed
02d15e5c: mov     w8, #1                                     
02d15e60: strb    w8, [x19, #0x39]                           .<IsPressed>k__BackingField
02d15e64: cbz     x0, #0x2d15e78                             
02d15e68: ldp     x20, x19, [sp, #0x10]                      
02d15e6c: mov     x1, xzr                                    
02d15e70: ldr     x30, [sp], #0x20                           
02d15e74: b       #0x5b4d278                                 UnityEngine.Events.UnityEvent::Invoke
02d15e78: ldp     x20, x19, [sp, #0x10]                      
02d15e7c: ldr     x30, [sp], #0x20                           
02d15e80: ret                                                
## OnPointerUp(UnityEngine.EventSystems.PointerEventData eventData) -> void
---- DreamHouse.ButtonObject::OnPointerUp 0x2d15e84
02d15e84: str     x30, [sp, #-0x20]!                         
02d15e88: stp     x20, x19, [sp, #0x10]                      
02d15e8c: adrp    x20, #0x662f000                            
02d15e90: mov     x19, x0                                    
02d15e94: ldrb    w8, [x20, #0xfd5]                          
02d15e98: tbnz    w8, #0, #0x2d15eb0                         
02d15e9c: adrp    x0, #0x6266000                             
02d15ea0: ldr     x0, [x0, #0x948]                           T:Touch
02d15ea4: bl      #0x2b70db0                                 fn_2b70db0
02d15ea8: mov     w8, #1                                     
02d15eac: strb    w8, [x20, #0xfd5]                          
02d15eb0: ldrb    w8, [x19, #0x38]                           ._isInteractable
02d15eb4: cbz     w8, #0x2d15ef8                             
02d15eb8: adrp    x8, #0x6266000                             
02d15ebc: ldr     x8, [x8, #0x948]                           T:Touch
02d15ec0: ldr     x0, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d15ec4: ldr     w8, [x0, #0xe4]                            [62660e4]=0 f=0,0
02d15ec8: cbnz    w8, #0x2d15ed0                             
02d15ecc: bl      #0x2b70f30                                 fn_2b70f30
02d15ed0: mov     x0, xzr                                    
02d15ed4: bl      #0x2cd6230                                 Touch::IsPointerOverUIObject
02d15ed8: tbnz    w0, #0, #0x2d15ef8                         
02d15edc: ldr     x0, [x19, #0x28]                           .OnButtonReleased
02d15ee0: strb    wzr, [x19, #0x39]                          .<IsPressed>k__BackingField
02d15ee4: cbz     x0, #0x2d15ef8                             
02d15ee8: ldp     x20, x19, [sp, #0x10]                      
02d15eec: mov     x1, xzr                                    
02d15ef0: ldr     x30, [sp], #0x20                           
02d15ef4: b       #0x5b4d278                                 UnityEngine.Events.UnityEvent::Invoke
02d15ef8: ldp     x20, x19, [sp, #0x10]                      
02d15efc: ldr     x30, [sp], #0x20                           
02d15f00: ret                                                
## SetInteractable(bool isInteractable) -> void
---- DreamHouse.ButtonObject::SetInteractable 0x2d15f04
02d15f04: str     x30, [sp, #-0x20]!                         
02d15f08: stp     x20, x19, [sp, #0x10]                      
02d15f0c: mov     x19, x0                                    
02d15f10: ldr     x0, [x0, #0x30]                            ._collider2D
02d15f14: cbz     x0, #0x2d15f38                             
02d15f18: and     w20, w1, #1                                
02d15f1c: mov     x2, xzr                                    
02d15f20: mov     w1, w20                                    
02d15f24: bl      #0x5b33110                                 UnityEngine.Behaviour::set_enabled
02d15f28: strb    w20, [x19, #0x38]                          ._isInteractable
02d15f2c: ldp     x20, x19, [sp, #0x10]                      
02d15f30: ldr     x30, [sp], #0x20                           
02d15f34: ret                                                
02d15f38: bl      #0x2b7105c                                 fn_2b7105c
## .ctor() -> void
---- DreamHouse.ButtonObject::.ctor 0x2d15f3c
02d15f3c: mov     w8, #1                                     
02d15f40: mov     x1, xzr                                    
02d15f44: strb    w8, [x0, #0x38]                            ._isInteractable
02d15f48: b       #0x5b397b0                                 UnityEngine.MonoBehaviour::.ctor
