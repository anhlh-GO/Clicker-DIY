#### CLASS LevelSaveData parent= object
#   field currentLevel                   int                                                off=0x10 attr=6 
#   field highestLevel                   int                                                off=0x14 attr=6 
## .ctor(int currentLevelId, int highestLevelId) -> void
---- LevelSaveData::.ctor 0x2cacfe0
02cacfe0: stp     x30, x21, [sp, #-0x20]!                    
02cacfe4: stp     x20, x19, [sp, #0x10]                      
02cacfe8: mov     w20, w1                                    
02cacfec: mov     x1, xzr                                    
02cacff0: mov     w19, w2                                    
02cacff4: mov     x21, x0                                    
02cacff8: bl      #0x4e53e9c                                 System.Object::.ctor
02cacffc: stp     w20, w19, [x21, #0x10]                     .currentLevel
02cad000: ldp     x20, x19, [sp, #0x10]                      
02cad004: ldp     x30, x21, [sp], #0x20                      
02cad008: ret                                                
