#### CLASS PopupNointernet parent= UnityEngine.MonoBehaviour
#   field _canvasGroup                   UnityEngine.CanvasGroup                            off=0x20 attr=1 SerializeField
#   field btnOk                          UnityEngine.UI.Button                              off=0x28 attr=1 SerializeField
#   field _cv                            UnityEngine.Canvas                                 off=0x30 attr=1 SerializeField
#   field _gr                            UnityEngine.UI.GraphicRaycaster                    off=0x38 attr=1 SerializeField
#   field isShow                         bool                                               off=0x40 attr=6 
## Awake() -> void
---- PopupNointernet::Awake 0x2ce5c74
02ce5c74: stp     x30, x21, [sp, #-0x20]!                    
02ce5c78: stp     x20, x19, [sp, #0x10]                      
02ce5c7c: adrp    x20, #0x662f000                            
02ce5c80: mov     x19, x0                                    
02ce5c84: ldrb    w8, [x20, #0xde2]                          
02ce5c88: tbnz    w8, #0, #0x2ce5cac                         
02ce5c8c: adrp    x0, #0x6268000                             
02ce5c90: ldr     x0, [x0, #0x1d0]                           M:PopupNointernet::OnBtnOkClicked
02ce5c94: bl      #0x2b70db0                                 fn_2b70db0
02ce5c98: adrp    x0, #0x6265000                             
02ce5c9c: ldr     x0, [x0, #0x3f0]                           T:UnityEngine.Events.UnityAction
02ce5ca0: bl      #0x2b70db0                                 fn_2b70db0
02ce5ca4: mov     w8, #1                                     
02ce5ca8: strb    w8, [x20, #0xde2]                          
02ce5cac: ldr     x8, [x19, #0x28]                           .btnOk
02ce5cb0: cbz     x8, #0x2ce5d30                             
02ce5cb4: adrp    x9, #0x6265000                             
02ce5cb8: adrp    x21, #0x6268000                            
02ce5cbc: ldr     x9, [x9, #0x3f0]                           T:UnityEngine.Events.UnityAction
02ce5cc0: ldr     x21, [x21, #0x1d0]                         M:PopupNointernet::OnBtnOkClicked
02ce5cc4: ldr     x20, [x8, #0x100]                          
02ce5cc8: ldr     x0, [x9]                                   M:AdsManager::<OnApplicationPause>b__26_0
02ce5ccc: bl      #0x2b7104c                                 fn_2b7104c
02ce5cd0: ldr     x2, [x21]                                  S:'{0}/2'
02ce5cd4: mov     x1, x19                                    
02ce5cd8: mov     x3, xzr                                    
02ce5cdc: mov     x21, x0                                    
02ce5ce0: bl      #0x5b4cf98                                 UnityEngine.Events.UnityAction::.ctor
02ce5ce4: cbz     x20, #0x2ce5d30                            
02ce5ce8: mov     x0, x20                                    
02ce5cec: mov     x1, x21                                    
02ce5cf0: mov     x2, xzr                                    
02ce5cf4: bl      #0x5b4d0ac                                 UnityEngine.Events.UnityEvent::AddListener
02ce5cf8: mov     x0, x19                                    
02ce5cfc: bl      #0x2ce5d34                                 PopupNointernet::OnHide
02ce5d00: ldr     x0, [x19, #0x30]                           ._cv
02ce5d04: cbz     x0, #0x2ce5d30                             
02ce5d08: mov     w1, wzr                                    
02ce5d0c: mov     x2, xzr                                    
02ce5d10: bl      #0x5b33110                                 UnityEngine.Behaviour::set_enabled
02ce5d14: ldr     x0, [x19, #0x38]                           ._gr
02ce5d18: cbz     x0, #0x2ce5d30                             
02ce5d1c: ldp     x20, x19, [sp, #0x10]                      
02ce5d20: mov     w1, wzr                                    
02ce5d24: mov     x2, xzr                                    
02ce5d28: ldp     x30, x21, [sp], #0x20                      
02ce5d2c: b       #0x5b33110                                 UnityEngine.Behaviour::set_enabled
02ce5d30: bl      #0x2b7105c                                 fn_2b7105c
## Update() -> void
---- PopupNointernet::Update 0x2ce5d94
02ce5d94: stp     x30, x21, [sp, #-0x20]!                    
02ce5d98: stp     x20, x19, [sp, #0x10]                      
02ce5d9c: adrp    x20, #0x662f000                            
02ce5da0: mov     x19, x0                                    
02ce5da4: ldrb    w8, [x20, #0xde3]                          
02ce5da8: tbnz    w8, #0, #0x2ce5dcc                         
02ce5dac: adrp    x0, #0x6264000                             
02ce5db0: ldr     x0, [x0, #0xa70]                           T:UnityEngine.Application
02ce5db4: bl      #0x2b70db0                                 fn_2b70db0
02ce5db8: adrp    x0, #0x6268000                             
02ce5dbc: ldr     x0, [x0, #0x1d8]                           S:'OfflinePlay'
02ce5dc0: bl      #0x2b70db0                                 fn_2b70db0
02ce5dc4: mov     w8, #1                                     
02ce5dc8: strb    w8, [x20, #0xde3]                          
02ce5dcc: adrp    x20, #0x6264000                            
02ce5dd0: adrp    x21, #0x6268000                            
02ce5dd4: ldr     x20, [x20, #0xa70]                         T:UnityEngine.Application
02ce5dd8: ldrb    w8, [x19, #0x40]                           .isShow
02ce5ddc: ldr     x21, [x21, #0x1d8]                         S:'OfflinePlay'
02ce5de0: cbz     w8, #0x2ce5e2c                             
02ce5de4: ldr     x0, [x20]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02ce5de8: ldr     w8, [x0, #0xe4]                            [62680e4]=0 f=0,0
02ce5dec: cbnz    w8, #0x2ce5df4                             
02ce5df0: bl      #0x2b70f30                                 fn_2b70f30
02ce5df4: mov     x0, xzr                                    
02ce5df8: bl      #0x5aeb318                                 UnityEngine.Application::get_internetReachability
02ce5dfc: cmp     w0, #1                                     
02ce5e00: b.eq    #0x2ce5e24                                 
02ce5e04: ldr     x0, [x20]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02ce5e08: ldr     w8, [x0, #0xe4]                            [62680e4]=0 f=0,0
02ce5e0c: cbnz    w8, #0x2ce5e14                             
02ce5e10: bl      #0x2b70f30                                 fn_2b70f30
02ce5e14: mov     x0, xzr                                    
02ce5e18: bl      #0x5aeb318                                 UnityEngine.Application::get_internetReachability
02ce5e1c: cmp     w0, #2                                     
02ce5e20: b.ne    #0x2ce5e2c                                 
02ce5e24: mov     x0, x19                                    
02ce5e28: bl      #0x2ce5d34                                 PopupNointernet::OnHide
02ce5e2c: ldr     x0, [x21]                                  S:'{0}/2'
02ce5e30: mov     x1, xzr                                    
02ce5e34: bl      #0x5b2d73c                                 UnityEngine.PlayerPrefs::HasKey
02ce5e38: tbnz    w0, #0, #0x2ce5e60                         
02ce5e3c: ldr     x0, [x20]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02ce5e40: ldr     w8, [x0, #0xe4]                            [62680e4]=0 f=0,0
02ce5e44: cbnz    w8, #0x2ce5e4c                             
02ce5e48: bl      #0x2b70f30                                 fn_2b70f30
02ce5e4c: mov     x0, xzr                                    
02ce5e50: bl      #0x5aeb318                                 UnityEngine.Application::get_internetReachability
02ce5e54: cbnz    w0, #0x2ce5e60                             
02ce5e58: ldrb    w8, [x19, #0x40]                           .isShow
02ce5e5c: cbz     w8, #0x2ce5e6c                             
02ce5e60: ldp     x20, x19, [sp, #0x10]                      
02ce5e64: ldp     x30, x21, [sp], #0x20                      
02ce5e68: ret                                                
02ce5e6c: mov     x0, x19                                    
02ce5e70: ldp     x20, x19, [sp, #0x10]                      
02ce5e74: ldp     x30, x21, [sp], #0x20                      
02ce5e78: b       #0x2ce5e7c                                 PopupNointernet::OnShow
## OnShow() -> void
---- PopupNointernet::OnShow 0x2ce5e7c
02ce5e7c: str     x30, [sp, #-0x20]!                         
02ce5e80: stp     x20, x19, [sp, #0x10]                      
02ce5e84: ldrb    w8, [x0, #0x40]                            .isShow
02ce5e88: cbz     w8, #0x2ce5e98                             
02ce5e8c: ldp     x20, x19, [sp, #0x10]                      
02ce5e90: ldr     x30, [sp], #0x20                           
02ce5e94: ret                                                
02ce5e98: mov     x19, x0                                    
02ce5e9c: ldr     x0, [x0, #0x30]                            ._cv
02ce5ea0: cbz     x0, #0x2ce5ee8                             
02ce5ea4: mov     w1, #1                                     
02ce5ea8: mov     x2, xzr                                    
02ce5eac: mov     w20, #1                                    
02ce5eb0: bl      #0x5b33110                                 UnityEngine.Behaviour::set_enabled
02ce5eb4: ldr     x0, [x19, #0x38]                           ._gr
02ce5eb8: cbz     x0, #0x2ce5ee8                             
02ce5ebc: mov     w1, #1                                     
02ce5ec0: mov     x2, xzr                                    
02ce5ec4: bl      #0x5b33110                                 UnityEngine.Behaviour::set_enabled
02ce5ec8: ldr     x0, [x19, #0x20]                           ._canvasGroup
02ce5ecc: strb    w20, [x19, #0x40]                          .isShow
02ce5ed0: movi    d0, #0000000000000000                      
02ce5ed4: ldp     x20, x19, [sp, #0x10]                      
02ce5ed8: mov     w1, #1                                     
02ce5edc: mov     x2, xzr                                    
02ce5ee0: ldr     x30, [sp], #0x20                           
02ce5ee4: b       #0x2cf1928                                 FrameWorkUtility::SetActive
02ce5ee8: bl      #0x2b7105c                                 fn_2b7105c
## OnHide() -> void
---- PopupNointernet::OnHide 0x2ce5d34
02ce5d34: stp     x30, x19, [sp, #-0x10]!                    
02ce5d38: ldrb    w8, [x0, #0x40]                            .isShow
02ce5d3c: cbz     w8, #0x2ce5d88                             
02ce5d40: movi    d0, #0000000000000000                      
02ce5d44: mov     x19, x0                                    
02ce5d48: ldr     x0, [x0, #0x20]                            ._canvasGroup
02ce5d4c: mov     w1, wzr                                    
02ce5d50: mov     x2, xzr                                    
02ce5d54: strb    wzr, [x19, #0x40]                          .isShow
02ce5d58: bl      #0x2cf1928                                 FrameWorkUtility::SetActive
02ce5d5c: ldr     x0, [x19, #0x30]                           ._cv
02ce5d60: cbz     x0, #0x2ce5d90                             
02ce5d64: mov     w1, wzr                                    
02ce5d68: mov     x2, xzr                                    
02ce5d6c: bl      #0x5b33110                                 UnityEngine.Behaviour::set_enabled
02ce5d70: ldr     x0, [x19, #0x38]                           ._gr
02ce5d74: cbz     x0, #0x2ce5d90                             
02ce5d78: mov     w1, wzr                                    
02ce5d7c: mov     x2, xzr                                    
02ce5d80: ldp     x30, x19, [sp], #0x10                      
02ce5d84: b       #0x5b33110                                 UnityEngine.Behaviour::set_enabled
02ce5d88: ldp     x30, x19, [sp], #0x10                      
02ce5d8c: ret                                                
02ce5d90: bl      #0x2b7105c                                 fn_2b7105c
## OnBtnOkClicked() -> void
---- PopupNointernet::OnBtnOkClicked 0x2ce5eec
02ce5eec: sub     sp, sp, #0x80                              
02ce5ef0: str     x30, [sp, #0x50]                           
02ce5ef4: stp     x22, x21, [sp, #0x60]                      
02ce5ef8: stp     x20, x19, [sp, #0x70]                      
02ce5efc: adrp    x20, #0x662f000                            
02ce5f00: adrp    x19, #0x6263000                            
02ce5f04: ldrb    w8, [x20, #0xde4]                          
02ce5f08: ldr     x19, [x19, #0xc40]                         T:UnityEngine.AndroidJavaClass
02ce5f0c: tbnz    w8, #0, #0x2ce5f90                         
02ce5f10: adrp    x0, #0x6263000                             
02ce5f14: ldr     x0, [x0, #0xc40]                           T:UnityEngine.AndroidJavaClass
02ce5f18: bl      #0x2b70db0                                 fn_2b70db0
02ce5f1c: adrp    x0, #0x6263000                             
02ce5f20: ldr     x0, [x0, #0xc50]                           MS:UnityEngine.AndroidJavaObject::GetStatic
02ce5f24: bl      #0x2b70db0                                 fn_2b70db0
02ce5f28: adrp    x0, #0x6263000                             
02ce5f2c: ldr     x0, [x0, #0xbd8]                           T:UnityEngine.AndroidJavaObject
02ce5f30: bl      #0x2b70db0                                 fn_2b70db0
02ce5f34: adrp    x0, #0x6263000                             
02ce5f38: ldr     x0, [x0, #0x980]                           T:System.IDisposable
02ce5f3c: bl      #0x2b70db0                                 fn_2b70db0
02ce5f40: adrp    x0, #0x6263000                             
02ce5f44: ldr     x0, [x0, #0xa80]                           T:type24502(k1d)
02ce5f48: bl      #0x2b70db0                                 fn_2b70db0
02ce5f4c: adrp    x0, #0x6267000                             
02ce5f50: ldr     x0, [x0, #8]                               S:'android.settings.WIFI_SETTINGS'
02ce5f54: bl      #0x2b70db0                                 fn_2b70db0
02ce5f58: adrp    x0, #0x6265000                             
02ce5f5c: ldr     x0, [x0, #0x730]                           S:'com.unity3d.player.UnityPlayer'
02ce5f60: bl      #0x2b70db0                                 fn_2b70db0
02ce5f64: adrp    x0, #0x6267000                             
02ce5f68: ldr     x0, [x0, #0x10]                            S:'startActivity'
02ce5f6c: bl      #0x2b70db0                                 fn_2b70db0
02ce5f70: adrp    x0, #0x6267000                             
02ce5f74: ldr     x0, [x0, #0x18]                            S:'android.content.Intent'
02ce5f78: bl      #0x2b70db0                                 fn_2b70db0
02ce5f7c: adrp    x0, #0x6265000                             
02ce5f80: ldr     x0, [x0, #0x738]                           S:'currentActivity'
02ce5f84: bl      #0x2b70db0                                 fn_2b70db0
02ce5f88: mov     w8, #1                                     
02ce5f8c: strb    w8, [x20, #0xde4]                          
02ce5f90: ldr     x0, [x19]                                  &2c5bbd4(=a9bd7bfdd503233f)
02ce5f94: str     xzr, [sp, #0x58]                           
02ce5f98: stp     xzr, xzr, [sp, #0x40]                      
02ce5f9c: str     wzr, [sp, #0x38]                           
02ce5fa0: bl      #0x2b7104c                                 fn_2b7104c
02ce5fa4: adrp    x8, #0x6265000                             
02ce5fa8: mov     x19, x0                                    
02ce5fac: ldr     x8, [x8, #0x730]                           S:'com.unity3d.player.UnityPlayer'
02ce5fb0: ldr     x1, [x8]                                   M:AdsManager::<OnApplicationPause>b__26_0
02ce5fb4: mov     x2, xzr                                    
02ce5fb8: bl      #0x5ad2f6c                                 UnityEngine.AndroidJavaClass::.ctor
02ce5fbc: adrp    x22, #0x6263000                            
02ce5fc0: add     x8, sp, #0x58                              
02ce5fc4: ldr     x22, [x22, #0x980]                         T:System.IDisposable
02ce5fc8: str     x19, [sp, #0x58]                           
02ce5fcc: stp     xzr, x8, [sp, #0x20]                       
02ce5fd0: cbz     x19, #0x2ce6254                            
02ce5fd4: adrp    x8, #0x6265000                             
02ce5fd8: adrp    x9, #0x6263000                             
02ce5fdc: ldr     x8, [x8, #0x738]                           S:'currentActivity'
02ce5fe0: ldr     x9, [x9, #0xc50]                           MS:UnityEngine.AndroidJavaObject::GetStatic
02ce5fe4: ldr     x1, [x8]                                   M:AdsManager::<OnApplicationPause>b__26_0
02ce5fe8: ldr     x2, [x9]                                   &2c5bbd4(=a9bd7bfdd503233f)
02ce5fec: mov     x0, x19                                    
02ce5ff0: bl      #0x3121808                                 fn_3121808
02ce5ff4: adrp    x21, #0x6263000                            
02ce5ff8: add     x8, sp, #0x48                              
02ce5ffc: ldr     x21, [x21, #0xa80]                         T:type24502(k1d)
02ce6000: str     x0, [sp, #0x48]                            
02ce6004: stp     xzr, x8, [sp, #0x10]                       
02ce6008: ldr     x0, [x21]                                  &2c5bbd4(=a9bd7bfdd503233f)
02ce600c: mov     w1, #1                                     
02ce6010: bl      #0x2b70ea0                                 fn_2b70ea0
02ce6014: mov     x19, x0                                    
02ce6018: cbz     x0, #0x2ce6258                             
02ce601c: adrp    x20, #0x6267000                            
02ce6020: ldr     x20, [x20, #8]                             S:'android.settings.WIFI_SETTINGS'
02ce6024: ldr     x0, [x20]                                  S:'didu'
02ce6028: cbz     x0, #0x2ce603c                             
02ce602c: ldr     x8, [x19]                                  &2c5bbd4(=a9bd7bfdd503233f)
02ce6030: ldr     x1, [x8, #0x40]                            S:'done_ad'
02ce6034: bl      #0x2b70f34                                 fn_2b70f34
02ce6038: cbz     x0, #0x2ce6274                             
02ce603c: ldr     w8, [x19, #0x18]                           &2c5d934(=d65f03c0d503245f)
02ce6040: cbz     w8, #0x2ce625c                             
02ce6044: ldr     x1, [x20]                                  S:'didu'
02ce6048: mov     x0, x19                                    
02ce604c: str     x1, [x0, #0x20]!                           ._canvasGroup
02ce6050: bl      #0x2b70d54                                 fn_2b70d54
02ce6054: adrp    x8, #0x6263000                             
02ce6058: ldr     x8, [x8, #0xbd8]                           T:UnityEngine.AndroidJavaObject
02ce605c: ldr     x0, [x8]                                   &2c5bbd4(=a9bd7bfdd503233f)
02ce6060: bl      #0x2b7104c                                 fn_2b7104c
02ce6064: adrp    x8, #0x6267000                             
02ce6068: mov     x20, x0                                    
02ce606c: ldr     x8, [x8, #0x18]                            S:'android.content.Intent'
02ce6070: ldr     x1, [x8]                                   S:'didu'
02ce6074: mov     x2, x19                                    
02ce6078: mov     x3, xzr                                    
02ce607c: bl      #0x5ad5b2c                                 UnityEngine.AndroidJavaObject::.ctor
02ce6080: ldr     x19, [sp, #0x48]                           
02ce6084: ldr     x0, [x21]                                  &2c5bbd4(=a9bd7bfdd503233f)
02ce6088: add     x8, sp, #0x40                              
02ce608c: str     x20, [sp, #0x40]                           
02ce6090: stp     xzr, x8, [sp]                              
02ce6094: mov     w1, #1                                     
02ce6098: bl      #0x2b70ea0                                 fn_2b70ea0
02ce609c: mov     x20, x0                                    
02ce60a0: cbz     x0, #0x2ce6250                             
02ce60a4: ldr     x21, [sp, #0x40]                           
02ce60a8: cbz     x21, #0x2ce60c0                            
02ce60ac: ldr     x8, [x20]                                  S:'didu'
02ce60b0: ldr     x1, [x8, #0x40]                            S:'<color=#'
02ce60b4: mov     x0, x21                                    
02ce60b8: bl      #0x2b70f34                                 fn_2b70f34
02ce60bc: cbz     x0, #0x2ce6280                             
02ce60c0: ldr     w8, [x20, #0x18]                           S:'android.content.Intent'
02ce60c4: cbz     w8, #0x2ce6268                             
02ce60c8: mov     x0, x20                                    
02ce60cc: str     x21, [x0, #0x20]!                          ._canvasGroup
02ce60d0: mov     x1, x21                                    
02ce60d4: bl      #0x2b70d54                                 fn_2b70d54
02ce60d8: cbz     x19, #0x2ce6250                            
02ce60dc: adrp    x8, #0x6267000                             
02ce60e0: ldr     x8, [x8, #0x10]                            S:'startActivity'
02ce60e4: ldr     x1, [x8]                                   S:'didu'
02ce60e8: mov     x0, x19                                    
02ce60ec: mov     x2, x20                                    
02ce60f0: mov     x3, xzr                                    
02ce60f4: bl      #0x5ad5e34                                 UnityEngine.AndroidJavaObject::Call
02ce60f8: mov     x19, xzr                                   
02ce60fc: add     x8, sp, #0x40                              
02ce6100: ldr     x20, [x8]                                  S:'didu'
02ce6104: cbz     x20, #0x2ce6160                            
02ce6108: ldr     x8, [x20]                                  S:'didu'
02ce610c: ldr     x1, [x22]                                  &2c5bbd4(=a9bd7bfdd503233f)
02ce6110: ldrh    w9, [x8, #0x12e]                           
02ce6114: cbz     x9, #0x2ce6138                             
02ce6118: ldr     x10, [x8, #0xb0]                           M:Framework.SceneUtils/<CRLoadSceneAsync>d__1::System.Collections.IEnumerator.Reset
02ce611c: add     x10, x10, #8                               
02ce6120: ldur    x11, [x10, #-8]                            
02ce6124: cmp     x11, x1                                    
02ce6128: b.eq    #0x2ce6148                                 
02ce612c: subs    x9, x9, #1                                 
02ce6130: add     x10, x10, #0x10                            
02ce6134: b.ne    #0x2ce6120                                 
02ce6138: mov     x0, x20                                    
02ce613c: mov     w2, wzr                                    
02ce6140: bl      #0x2baa05c                                 fn_2baa05c
02ce6144: b       #0x2ce6154                                 
02ce6148: ldrsw   x9, [x10]                                  
02ce614c: add     x8, x8, x9, lsl #4                         &6267000
02ce6150: add     x0, x8, #0x138                             &6267138
02ce6154: ldp     x8, x1, [x0]                               
02ce6158: mov     x0, x20                                    
02ce615c: blr     x8                                         
02ce6160: cbnz    x19, #0x2ce626c                            
02ce6164: ldr     x8, [sp, #0x18]                            
02ce6168: ldr     x19, [x8]                                  S:'didu'
02ce616c: cbz     x19, #0x2ce61c8                            
02ce6170: ldr     x8, [x19]                                  &2c5bbd4(=a9bd7bfdd503233f)
02ce6174: ldr     x1, [x22]                                  &2c5bbd4(=a9bd7bfdd503233f)
02ce6178: ldrh    w9, [x8, #0x12e]                           
02ce617c: cbz     x9, #0x2ce61a0                             
02ce6180: ldr     x10, [x8, #0xb0]                           M:Framework.SceneUtils/<CRLoadSceneAsync>d__1::System.Collections.IEnumerator.Reset
02ce6184: add     x10, x10, #8                               
02ce6188: ldur    x11, [x10, #-8]                            
02ce618c: cmp     x11, x1                                    
02ce6190: b.eq    #0x2ce61b0                                 
02ce6194: subs    x9, x9, #1                                 
02ce6198: add     x10, x10, #0x10                            
02ce619c: b.ne    #0x2ce6188                                 
02ce61a0: mov     x0, x19                                    
02ce61a4: mov     w2, wzr                                    
02ce61a8: bl      #0x2baa05c                                 fn_2baa05c
02ce61ac: b       #0x2ce61bc                                 
02ce61b0: ldrsw   x9, [x10]                                  
02ce61b4: add     x8, x8, x9, lsl #4                         &6267000
02ce61b8: add     x0, x8, #0x138                             &6267138
02ce61bc: ldp     x8, x1, [x0]                               
02ce61c0: mov     x0, x19                                    
02ce61c4: blr     x8                                         
02ce61c8: ldr     x0, [sp, #0x10]                            
02ce61cc: cbnz    x0, #0x2ce6264                             
02ce61d0: ldr     x8, [sp, #0x28]                            
02ce61d4: ldr     x19, [x8]                                  S:'didu'
02ce61d8: cbz     x19, #0x2ce6234                            
02ce61dc: ldr     x8, [x19]                                  &2c5bbd4(=a9bd7bfdd503233f)
02ce61e0: ldr     x1, [x22]                                  &2c5bbd4(=a9bd7bfdd503233f)
02ce61e4: ldrh    w9, [x8, #0x12e]                           
02ce61e8: cbz     x9, #0x2ce620c                             
02ce61ec: ldr     x10, [x8, #0xb0]                           M:Framework.SceneUtils/<CRLoadSceneAsync>d__1::System.Collections.IEnumerator.Reset
02ce61f0: add     x10, x10, #8                               
02ce61f4: ldur    x11, [x10, #-8]                            
02ce61f8: cmp     x11, x1                                    
02ce61fc: b.eq    #0x2ce621c                                 
02ce6200: subs    x9, x9, #1                                 
02ce6204: add     x10, x10, #0x10                            
02ce6208: b.ne    #0x2ce61f4                                 
02ce620c: mov     x0, x19                                    
02ce6210: mov     w2, wzr                                    
02ce6214: bl      #0x2baa05c                                 fn_2baa05c
02ce6218: b       #0x2ce6228                                 
02ce621c: ldrsw   x9, [x10]                                  
02ce6220: add     x8, x8, x9, lsl #4                         &6267000
02ce6224: add     x0, x8, #0x138                             &6267138
02ce6228: ldp     x8, x1, [x0]                               
02ce622c: mov     x0, x19                                    
02ce6230: blr     x8                                         
02ce6234: ldr     x0, [sp, #0x20]                            
02ce6238: cbnz    x0, #0x2ce6260                             
02ce623c: ldp     x20, x19, [sp, #0x70]                      
02ce6240: ldr     x30, [sp, #0x50]                           
02ce6244: ldp     x22, x21, [sp, #0x60]                      
02ce6248: add     sp, sp, #0x80                              
02ce624c: ret                                                
02ce6250: bl      #0x2b7105c                                 fn_2b7105c
02ce6254: bl      #0x2b7105c                                 fn_2b7105c
02ce6258: bl      #0x2b7105c                                 fn_2b7105c
02ce625c: bl      #0x2b71064                                 fn_2b71064
02ce6260: bl      #0x2b71054                                 fn_2b71054
02ce6264: bl      #0x2b71054                                 fn_2b71054
02ce6268: bl      #0x2b71064                                 fn_2b71064
02ce626c: mov     x0, x19                                    
02ce6270: bl      #0x2b71054                                 fn_2b71054
02ce6274: bl      #0x2b71080                                 fn_2b71080
02ce6278: mov     x1, xzr                                    
02ce627c: bl      #0x2b70f20                                 fn_2b70f20
02ce6280: bl      #0x2b71080                                 fn_2b71080
02ce6284: mov     x1, xzr                                    
02ce6288: bl      #0x2b70f20                                 fn_2b70f20
02ce628c: b       #0x2ce62cc                                 
02ce6290: b       #0x2ce62c0                                 
02ce6294: b       #0x2ce62a8                                 
02ce6298: b       #0x2ce62a8                                 
02ce629c: b       #0x2ce62c0                                 
02ce62a0: b       #0x2ce62b4                                 
02ce62a4: b       #0x2ce62c0                                 
02ce62a8: mov     x20, x1                                    
02ce62ac: mov     x19, x0                                    
02ce62b0: b       #0x2ce6338                                 
02ce62b4: mov     x20, x1                                    
02ce62b8: mov     x19, x0                                    
02ce62bc: b       #0x2ce6368                                 
02ce62c0: mov     x20, x1                                    
02ce62c4: mov     x19, x0                                    
02ce62c8: b       #0x2ce6308                                 
02ce62cc: mov     x20, x1                                    
02ce62d0: mov     x19, x0                                    
02ce62d4: cmp     w20, #1                                    
02ce62d8: b.ne    #0x2ce6300                                 
02ce62dc: mov     x0, x19                                    
02ce62e0: bl      #0x5e90260                                 fn_5e90260
02ce62e4: ldr     x19, [x0]                                  M:AdsManager::<OnApplicationPause>b__26_0
02ce62e8: str     x19, [sp]                                  
02ce62ec: bl      #0x5e90270                                 fn_5e90270
02ce62f0: ldr     x8, [sp, #8]                               
02ce62f4: b       #0x2ce6100                                 
02ce62f8: mov     x20, x1                                    
02ce62fc: mov     x19, x0                                    
02ce6300: mov     x0, sp                                     
02ce6304: bl      #0x27369c4                                 fn_27369c4
02ce6308: cmp     w20, #1                                    
02ce630c: b.ne    #0x2ce6330                                 
02ce6310: mov     x0, x19                                    
02ce6314: bl      #0x5e90260                                 fn_5e90260
02ce6318: ldr     x8, [x0]                                   M:AdsManager::<OnApplicationPause>b__26_0
02ce631c: str     x8, [sp, #0x10]                            
02ce6320: bl      #0x5e90270                                 fn_5e90270
02ce6324: b       #0x2ce6164                                 
02ce6328: mov     x20, x1                                    
02ce632c: mov     x19, x0                                    
02ce6330: add     x0, sp, #0x10                              
02ce6334: bl      #0x27369c4                                 fn_27369c4
02ce6338: cmp     w20, #1                                    
02ce633c: b.ne    #0x2ce6360                                 
02ce6340: mov     x0, x19                                    
02ce6344: bl      #0x5e90260                                 fn_5e90260
02ce6348: ldr     x8, [x0]                                   M:AdsManager::<OnApplicationPause>b__26_0
02ce634c: str     x8, [sp, #0x20]                            
02ce6350: bl      #0x5e90270                                 fn_5e90270
02ce6354: b       #0x2ce61d0                                 
02ce6358: mov     x20, x1                                    
02ce635c: mov     x19, x0                                    
02ce6360: add     x0, sp, #0x20                              
02ce6364: bl      #0x27369c4                                 fn_27369c4
02ce6368: cmp     w20, #1                                    
02ce636c: b.ne    #0x2ce6408                                 
02ce6370: mov     x0, x19                                    
02ce6374: bl      #0x5e90260                                 fn_5e90260
02ce6378: mov     x19, x0                                    
02ce637c: adrp    x0, #0x6263000                             
02ce6380: ldr     x0, [x0, #0xae0]                           T:System.Exception
02ce6384: bl      #0x2b70dc4                                 fn_2b70dc4
02ce6388: ldr     x8, [x19]                                  &2c5bbd4(=a9bd7bfdd503233f)
02ce638c: ldr     x1, [x8]                                   S:'didu'
02ce6390: bl      #0x2b71464                                 fn_2b71464
02ce6394: tbz     w0, #0, #0x2ce63e0                         
02ce6398: ldrsw   x20, [sp, #0x38]                           
02ce639c: ldr     x19, [x19]                                 &2c5bbd4(=a9bd7bfdd503233f)
02ce63a0: add     x8, sp, #0x30                              
02ce63a4: str     x19, [x8, x20, lsl #3]                     
02ce63a8: add     w8, w20, #1                                
02ce63ac: str     w8, [sp, #0x38]                            
02ce63b0: bl      #0x5e90270                                 fn_5e90270
02ce63b4: adrp    x0, #0x6263000                             
02ce63b8: ldr     x0, [x0, #0x928]                           T:UnityEngine.Debug
02ce63bc: bl      #0x2b70dc4                                 fn_2b70dc4
02ce63c0: ldr     w8, [x0, #0xe4]                            [62630e4]=0 f=0,0
02ce63c4: cbnz    w8, #0x2ce63cc                             
02ce63c8: bl      #0x2b70f30                                 fn_2b70f30
02ce63cc: mov     x0, x19                                    
02ce63d0: mov     x1, xzr                                    
02ce63d4: bl      #0x5aec808                                 UnityEngine.Debug::LogException
02ce63d8: str     w20, [sp, #0x38]                           
02ce63dc: b       #0x2ce623c                                 
02ce63e0: mov     w0, #8                                     
02ce63e4: bl      #0x5e90290                                 fn_5e90290
02ce63e8: ldr     x8, [x19]                                  &2c5bbd4(=a9bd7bfdd503233f)
02ce63ec: str     x8, [x0]                                   
02ce63f0: adrp    x1, #0x5e96000                             
02ce63f4: add     x1, x1, #0x758                             &5e96758
02ce63f8: mov     x2, xzr                                    
02ce63fc: bl      #0x5e902a0                                 fn_5e902a0
02ce6400: mov     x19, x0                                    
02ce6404: bl      #0x5e90270                                 fn_5e90270
02ce6408: mov     x0, x19                                    
02ce640c: bl      #0x2c6051c                                 fn_2c6051c
02ce6410: bl      #0x27369b8                                 fn_27369b8
## .ctor() -> void
---- PopupNointernet::.ctor 0x2ce6414
02ce6414: mov     x1, xzr                                    
02ce6418: b       #0x5b397b0                                 UnityEngine.MonoBehaviour::.ctor
