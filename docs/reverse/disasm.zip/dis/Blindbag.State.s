#### CLASS Blindbag.State parent= int
#   field value__                        int                                                off=0x10 attr=606 
#   field Free                           Blindbag.State                                     off=0x0 attr=8056 
#   field Moving                         Blindbag.State                                     off=0x0 attr=8056 
#   field Placed                         Blindbag.State                                     off=0x0 attr=8056 
