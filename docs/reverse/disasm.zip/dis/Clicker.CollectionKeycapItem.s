#### CLASS Clicker.CollectionKeycapItem parent= UnityEngine.MonoBehaviour
#   field _keycapGenerator               Clicker.KeycapGenerator                            off=0x20 attr=1 SerializeField
#   field _contentLock                   UnityEngine.GameObject                             off=0x28 attr=1 SerializeField
#   field _contentEmpty                  UnityEngine.GameObject                             off=0x30 attr=1 SerializeField
#   field _contentCanInspect             UnityEngine.GameObject                             off=0x38 attr=1 SerializeField
#   field _btnLock                       UnityEngine.UI.Button                              off=0x40 attr=1 SerializeField
#   field _btnAvailable                  UnityEngine.UI.Button                              off=0x48 attr=1 SerializeField
#   field _btnInspect                    UnityEngine.UI.Button                              off=0x50 attr=1 SerializeField
#   field _state                         Clicker.CollectionItemState                        off=0x58 attr=1 
#   field _screenClickerCollection       Clicker.ScreenClickerCollection                    off=0x60 attr=1 
## get_KeycapGenerator() -> Clicker.KeycapGenerator
---- Clicker.CollectionKeycapItem::get_KeycapGenerator 0x2d67968
02d67968: ldr     x0, [x0, #0x20]                            ._keycapGenerator
02d6796c: ret                                                
## get_State() -> Clicker.CollectionItemState
---- Clicker.CollectionKeycapItem::get_State 0x2d67970
02d67970: ldr     w0, [x0, #0x58]                            ._state
02d67974: ret                                                
## Awake() -> void
---- Clicker.CollectionKeycapItem::Awake 0x2d67978
02d67978: str     x30, [sp, #-0x30]!                         
02d6797c: stp     x22, x21, [sp, #0x10]                      
02d67980: stp     x20, x19, [sp, #0x20]                      
02d67984: adrp    x20, #0x6630000                            
02d67988: mov     x19, x0                                    
02d6798c: ldrb    w8, [x20, #0x33f]                          
02d67990: tbnz    w8, #0, #0x2d679cc                         
02d67994: adrp    x0, #0x626c000                             
02d67998: ldr     x0, [x0, #0x238]                           M:Clicker.CollectionKeycapItem::OnBtnAvailableClick
02d6799c: bl      #0x2b70db0                                 fn_2b70db0
02d679a0: adrp    x0, #0x626c000                             
02d679a4: ldr     x0, [x0, #0x240]                           M:Clicker.CollectionKeycapItem::OnBtnInspectClick
02d679a8: bl      #0x2b70db0                                 fn_2b70db0
02d679ac: adrp    x0, #0x626c000                             
02d679b0: ldr     x0, [x0, #0x248]                           M:Clicker.CollectionKeycapItem::OnBtnLockClick
02d679b4: bl      #0x2b70db0                                 fn_2b70db0
02d679b8: adrp    x0, #0x6265000                             
02d679bc: ldr     x0, [x0, #0x3f0]                           T:UnityEngine.Events.UnityAction
02d679c0: bl      #0x2b70db0                                 fn_2b70db0
02d679c4: mov     w8, #1                                     
02d679c8: strb    w8, [x20, #0x33f]                          
02d679cc: ldr     x8, [x19, #0x40]                           ._btnLock
02d679d0: cbz     x8, #0x2d67af4                             
02d679d4: ldr     x0, [x8, #0x100]                           
02d679d8: cbz     x0, #0x2d67af4                             
02d679dc: mov     x1, xzr                                    
02d679e0: bl      #0x5b4ce48                                 UnityEngine.Events.UnityEventBase::RemoveAllListeners
02d679e4: ldr     x8, [x19, #0x48]                           ._btnAvailable
02d679e8: cbz     x8, #0x2d67af4                             
02d679ec: ldr     x0, [x8, #0x100]                           
02d679f0: cbz     x0, #0x2d67af4                             
02d679f4: mov     x1, xzr                                    
02d679f8: bl      #0x5b4ce48                                 UnityEngine.Events.UnityEventBase::RemoveAllListeners
02d679fc: ldr     x8, [x19, #0x50]                           ._btnInspect
02d67a00: cbz     x8, #0x2d67af4                             
02d67a04: ldr     x0, [x8, #0x100]                           
02d67a08: cbz     x0, #0x2d67af4                             
02d67a0c: mov     x1, xzr                                    
02d67a10: bl      #0x5b4ce48                                 UnityEngine.Events.UnityEventBase::RemoveAllListeners
02d67a14: ldr     x8, [x19, #0x40]                           ._btnLock
02d67a18: cbz     x8, #0x2d67af4                             
02d67a1c: adrp    x22, #0x6265000                            
02d67a20: adrp    x21, #0x626c000                            
02d67a24: ldr     x22, [x22, #0x3f0]                         T:UnityEngine.Events.UnityAction
02d67a28: ldr     x21, [x21, #0x248]                         M:Clicker.CollectionKeycapItem::OnBtnLockClick
02d67a2c: ldr     x20, [x8, #0x100]                          
02d67a30: ldr     x0, [x22]                                  M:AdsManager::<OnApplicationPause>b__26_0
02d67a34: bl      #0x2b7104c                                 fn_2b7104c
02d67a38: ldr     x2, [x21]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d67a3c: mov     x1, x19                                    
02d67a40: mov     x3, xzr                                    
02d67a44: mov     x21, x0                                    
02d67a48: bl      #0x5b4cf98                                 UnityEngine.Events.UnityAction::.ctor
02d67a4c: cbz     x20, #0x2d67af4                            
02d67a50: mov     x0, x20                                    
02d67a54: mov     x1, x21                                    
02d67a58: mov     x2, xzr                                    
02d67a5c: bl      #0x5b4d0ac                                 UnityEngine.Events.UnityEvent::AddListener
02d67a60: ldr     x8, [x19, #0x48]                           ._btnAvailable
02d67a64: cbz     x8, #0x2d67af4                             
02d67a68: adrp    x21, #0x626c000                            
02d67a6c: ldr     x21, [x21, #0x238]                         M:Clicker.CollectionKeycapItem::OnBtnAvailableClick
02d67a70: ldr     x0, [x22]                                  M:AdsManager::<OnApplicationPause>b__26_0
02d67a74: ldr     x20, [x8, #0x100]                          
02d67a78: bl      #0x2b7104c                                 fn_2b7104c
02d67a7c: ldr     x2, [x21]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d67a80: mov     x1, x19                                    
02d67a84: mov     x3, xzr                                    
02d67a88: mov     x21, x0                                    
02d67a8c: bl      #0x5b4cf98                                 UnityEngine.Events.UnityAction::.ctor
02d67a90: cbz     x20, #0x2d67af4                            
02d67a94: mov     x0, x20                                    
02d67a98: mov     x1, x21                                    
02d67a9c: mov     x2, xzr                                    
02d67aa0: bl      #0x5b4d0ac                                 UnityEngine.Events.UnityEvent::AddListener
02d67aa4: ldr     x8, [x19, #0x50]                           ._btnInspect
02d67aa8: cbz     x8, #0x2d67af4                             
02d67aac: adrp    x21, #0x626c000                            
02d67ab0: ldr     x21, [x21, #0x240]                         M:Clicker.CollectionKeycapItem::OnBtnInspectClick
02d67ab4: ldr     x0, [x22]                                  M:AdsManager::<OnApplicationPause>b__26_0
02d67ab8: ldr     x20, [x8, #0x100]                          
02d67abc: bl      #0x2b7104c                                 fn_2b7104c
02d67ac0: ldr     x2, [x21]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d67ac4: mov     x1, x19                                    
02d67ac8: mov     x3, xzr                                    
02d67acc: mov     x21, x0                                    
02d67ad0: bl      #0x5b4cf98                                 UnityEngine.Events.UnityAction::.ctor
02d67ad4: cbz     x20, #0x2d67af4                            
02d67ad8: mov     x0, x20                                    
02d67adc: mov     x1, x21                                    
02d67ae0: mov     x2, xzr                                    
02d67ae4: ldp     x20, x19, [sp, #0x20]                      
02d67ae8: ldp     x22, x21, [sp, #0x10]                      
02d67aec: ldr     x30, [sp], #0x30                           
02d67af0: b       #0x5b4d0ac                                 UnityEngine.Events.UnityEvent::AddListener
02d67af4: bl      #0x2b7105c                                 fn_2b7105c
## Init(Clicker.ScreenClickerCollection screenClickerCollection) -> void
---- Clicker.CollectionKeycapItem::Init 0x2d67af8
02d67af8: str     x1, [x0, #0x60]!                           ._screenClickerCollection
02d67afc: b       #0x2b70d54                                 
## SetData(Clicker.CollectionItemState state, ClickerSaveDataItem data) -> void
---- Clicker.CollectionKeycapItem::SetData 0x2d5c58c
02d5c58c: str     x30, [sp, #-0x30]!                         
02d5c590: stp     x22, x21, [sp, #0x10]                      
02d5c594: stp     x20, x19, [sp, #0x20]                      
02d5c598: adrp    x22, #0x6630000                            
02d5c59c: mov     x20, x2                                    
02d5c5a0: mov     w21, w1                                    
02d5c5a4: ldrb    w8, [x22, #0x340]                          
02d5c5a8: mov     x19, x0                                    
02d5c5ac: tbnz    w8, #0, #0x2d5c5d0                         
02d5c5b0: adrp    x0, #0x6269000                             
02d5c5b4: ldr     x0, [x0, #0x3f8]                           MS:DataManager::GetData
02d5c5b8: bl      #0x2b70db0                                 fn_2b70db0
02d5c5bc: adrp    x0, #0x6266000                             
02d5c5c0: ldr     x0, [x0, #0x658]                           MS:MonoSingleton`1::get_Instance
02d5c5c4: bl      #0x2b70db0                                 fn_2b70db0
02d5c5c8: mov     w8, #1                                     
02d5c5cc: strb    w8, [x22, #0x340]                          
02d5c5d0: str     w21, [x19, #0x58]                          ._state
02d5c5d4: cbz     w21, #0x2d5c634                            
02d5c5d8: cmp     w21, #2                                    
02d5c5dc: b.eq    #0x2d5c5fc                                 
02d5c5e0: cmp     w21, #1                                    
02d5c5e4: b.ne    #0x2d5c63c                                 
02d5c5e8: mov     x0, x19                                    
02d5c5ec: ldp     x20, x19, [sp, #0x20]                      
02d5c5f0: ldp     x22, x21, [sp, #0x10]                      
02d5c5f4: ldr     x30, [sp], #0x30                           
02d5c5f8: b       #0x2d67b00                                 Clicker.CollectionKeycapItem::ShowVisualLocked
02d5c5fc: ldr     x0, [x19, #0x20]                           ._keycapGenerator
02d5c600: cbz     x0, #0x2d5c69c                             
02d5c604: mov     x1, x20                                    
02d5c608: bl      #0x2d67c58                                 Clicker.KeycapGenerator::CanGenerateThisItem
02d5c60c: tbz     w0, #0, #0x2d5c64c                         
02d5c610: mov     x0, x19                                    
02d5c614: bl      #0x2d67d54                                 Clicker.CollectionKeycapItem::ShowVisualCanInspect
02d5c618: ldr     x0, [x19, #0x20]                           ._keycapGenerator
02d5c61c: cbz     x0, #0x2d5c69c                             
02d5c620: mov     x1, x20                                    
02d5c624: ldp     x20, x19, [sp, #0x20]                      
02d5c628: ldp     x22, x21, [sp, #0x10]                      
02d5c62c: ldr     x30, [sp], #0x30                           
02d5c630: b       #0x2d67e00                                 Clicker.KeycapGenerator::GenerateKeycap
02d5c634: mov     x0, x19                                    
02d5c638: b       #0x2d5c68c                                 
02d5c63c: ldp     x20, x19, [sp, #0x20]                      
02d5c640: ldp     x22, x21, [sp, #0x10]                      
02d5c644: ldr     x30, [sp], #0x30                           
02d5c648: ret                                                
02d5c64c: adrp    x8, #0x6266000                             
02d5c650: ldr     x8, [x8, #0x658]                           MS:MonoSingleton`1::get_Instance
02d5c654: ldr     x0, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d5c658: bl      #0x3769600                                 fn_3769600
02d5c65c: cbz     x0, #0x2d5c69c                             
02d5c660: adrp    x8, #0x6269000                             
02d5c664: ldr     x8, [x8, #0x3f8]                           MS:DataManager::GetData
02d5c668: ldr     x1, [x8]                                   T:Trading.TradingSession/<>c__DisplayClass56_0
02d5c66c: bl      #0x3168dd0                                 fn_3168dd0
02d5c670: cbz     x20, #0x2d5c69c                            
02d5c674: cbz     x0, #0x2d5c69c                             
02d5c678: ldr     w1, [x20, #0x10]                           
02d5c67c: mov     x2, xzr                                    
02d5c680: bl      #0x2ca9854                                 DataClicker::RemoveSavedKeycap
02d5c684: mov     x0, x19                                    
02d5c688: str     wzr, [x19, #0x58]                          ._state
02d5c68c: ldp     x20, x19, [sp, #0x20]                      
02d5c690: ldp     x22, x21, [sp, #0x10]                      
02d5c694: ldr     x30, [sp], #0x30                           
02d5c698: b       #0x2d67bac                                 Clicker.CollectionKeycapItem::ShowVisualAvailable
02d5c69c: bl      #0x2b7105c                                 fn_2b7105c
## ShowVisualLocked() -> void
---- Clicker.CollectionKeycapItem::ShowVisualLocked 0x2d67b00
02d67b00: stp     x30, x19, [sp, #-0x10]!                    
02d67b04: mov     x19, x0                                    
02d67b08: ldr     x0, [x0, #0x40]                            ._btnLock
02d67b0c: cbz     x0, #0x2d67ba8                             
02d67b10: mov     x1, xzr                                    
02d67b14: bl      #0x5b339ec                                 UnityEngine.Component::get_gameObject
02d67b18: cbz     x0, #0x2d67ba8                             
02d67b1c: mov     w1, #1                                     
02d67b20: mov     x2, xzr                                    
02d67b24: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d67b28: ldr     x0, [x19, #0x48]                           ._btnAvailable
02d67b2c: cbz     x0, #0x2d67ba8                             
02d67b30: mov     x1, xzr                                    
02d67b34: bl      #0x5b339ec                                 UnityEngine.Component::get_gameObject
02d67b38: cbz     x0, #0x2d67ba8                             
02d67b3c: mov     w1, wzr                                    
02d67b40: mov     x2, xzr                                    
02d67b44: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d67b48: ldr     x0, [x19, #0x50]                           ._btnInspect
02d67b4c: cbz     x0, #0x2d67ba8                             
02d67b50: mov     x1, xzr                                    
02d67b54: bl      #0x5b339ec                                 UnityEngine.Component::get_gameObject
02d67b58: cbz     x0, #0x2d67ba8                             
02d67b5c: mov     w1, wzr                                    
02d67b60: mov     x2, xzr                                    
02d67b64: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d67b68: ldr     x0, [x19, #0x28]                           ._contentLock
02d67b6c: cbz     x0, #0x2d67ba8                             
02d67b70: mov     w1, #1                                     
02d67b74: mov     x2, xzr                                    
02d67b78: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d67b7c: ldr     x0, [x19, #0x30]                           ._contentEmpty
02d67b80: cbz     x0, #0x2d67ba8                             
02d67b84: mov     w1, wzr                                    
02d67b88: mov     x2, xzr                                    
02d67b8c: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d67b90: ldr     x0, [x19, #0x38]                           ._contentCanInspect
02d67b94: cbz     x0, #0x2d67ba8                             
02d67b98: mov     w1, wzr                                    
02d67b9c: mov     x2, xzr                                    
02d67ba0: ldp     x30, x19, [sp], #0x10                      
02d67ba4: b       #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d67ba8: bl      #0x2b7105c                                 fn_2b7105c
## ShowVisualAvailable() -> void
---- Clicker.CollectionKeycapItem::ShowVisualAvailable 0x2d67bac
02d67bac: stp     x30, x19, [sp, #-0x10]!                    
02d67bb0: mov     x19, x0                                    
02d67bb4: ldr     x0, [x0, #0x40]                            ._btnLock
02d67bb8: cbz     x0, #0x2d67c54                             
02d67bbc: mov     x1, xzr                                    
02d67bc0: bl      #0x5b339ec                                 UnityEngine.Component::get_gameObject
02d67bc4: cbz     x0, #0x2d67c54                             
02d67bc8: mov     w1, wzr                                    
02d67bcc: mov     x2, xzr                                    
02d67bd0: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d67bd4: ldr     x0, [x19, #0x48]                           ._btnAvailable
02d67bd8: cbz     x0, #0x2d67c54                             
02d67bdc: mov     x1, xzr                                    
02d67be0: bl      #0x5b339ec                                 UnityEngine.Component::get_gameObject
02d67be4: cbz     x0, #0x2d67c54                             
02d67be8: mov     w1, #1                                     
02d67bec: mov     x2, xzr                                    
02d67bf0: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d67bf4: ldr     x0, [x19, #0x50]                           ._btnInspect
02d67bf8: cbz     x0, #0x2d67c54                             
02d67bfc: mov     x1, xzr                                    
02d67c00: bl      #0x5b339ec                                 UnityEngine.Component::get_gameObject
02d67c04: cbz     x0, #0x2d67c54                             
02d67c08: mov     w1, wzr                                    
02d67c0c: mov     x2, xzr                                    
02d67c10: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d67c14: ldr     x0, [x19, #0x28]                           ._contentLock
02d67c18: cbz     x0, #0x2d67c54                             
02d67c1c: mov     w1, wzr                                    
02d67c20: mov     x2, xzr                                    
02d67c24: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d67c28: ldr     x0, [x19, #0x30]                           ._contentEmpty
02d67c2c: cbz     x0, #0x2d67c54                             
02d67c30: mov     w1, #1                                     
02d67c34: mov     x2, xzr                                    
02d67c38: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d67c3c: ldr     x0, [x19, #0x38]                           ._contentCanInspect
02d67c40: cbz     x0, #0x2d67c54                             
02d67c44: mov     w1, wzr                                    
02d67c48: mov     x2, xzr                                    
02d67c4c: ldp     x30, x19, [sp], #0x10                      
02d67c50: b       #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d67c54: bl      #0x2b7105c                                 fn_2b7105c
## ShowVisualCanInspect() -> void
---- Clicker.CollectionKeycapItem::ShowVisualCanInspect 0x2d67d54
02d67d54: stp     x30, x19, [sp, #-0x10]!                    
02d67d58: mov     x19, x0                                    
02d67d5c: ldr     x0, [x0, #0x40]                            ._btnLock
02d67d60: cbz     x0, #0x2d67dfc                             
02d67d64: mov     x1, xzr                                    
02d67d68: bl      #0x5b339ec                                 UnityEngine.Component::get_gameObject
02d67d6c: cbz     x0, #0x2d67dfc                             
02d67d70: mov     w1, wzr                                    
02d67d74: mov     x2, xzr                                    
02d67d78: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d67d7c: ldr     x0, [x19, #0x48]                           ._btnAvailable
02d67d80: cbz     x0, #0x2d67dfc                             
02d67d84: mov     x1, xzr                                    
02d67d88: bl      #0x5b339ec                                 UnityEngine.Component::get_gameObject
02d67d8c: cbz     x0, #0x2d67dfc                             
02d67d90: mov     w1, wzr                                    
02d67d94: mov     x2, xzr                                    
02d67d98: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d67d9c: ldr     x0, [x19, #0x50]                           ._btnInspect
02d67da0: cbz     x0, #0x2d67dfc                             
02d67da4: mov     x1, xzr                                    
02d67da8: bl      #0x5b339ec                                 UnityEngine.Component::get_gameObject
02d67dac: cbz     x0, #0x2d67dfc                             
02d67db0: mov     w1, #1                                     
02d67db4: mov     x2, xzr                                    
02d67db8: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d67dbc: ldr     x0, [x19, #0x28]                           ._contentLock
02d67dc0: cbz     x0, #0x2d67dfc                             
02d67dc4: mov     w1, wzr                                    
02d67dc8: mov     x2, xzr                                    
02d67dcc: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d67dd0: ldr     x0, [x19, #0x30]                           ._contentEmpty
02d67dd4: cbz     x0, #0x2d67dfc                             
02d67dd8: mov     w1, wzr                                    
02d67ddc: mov     x2, xzr                                    
02d67de0: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d67de4: ldr     x0, [x19, #0x38]                           ._contentCanInspect
02d67de8: cbz     x0, #0x2d67dfc                             
02d67dec: mov     w1, #1                                     
02d67df0: mov     x2, xzr                                    
02d67df4: ldp     x30, x19, [sp], #0x10                      
02d67df8: b       #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d67dfc: bl      #0x2b7105c                                 fn_2b7105c
## OnBtnLockClick() -> void
---- Clicker.CollectionKeycapItem::OnBtnLockClick 0x2d68304
02d68304: stp     x30, x21, [sp, #-0x20]!                    
02d68308: stp     x20, x19, [sp, #0x10]                      
02d6830c: adrp    x21, #0x6630000                            
02d68310: adrp    x20, #0x6267000                            
02d68314: mov     x19, x0                                    
02d68318: ldrb    w8, [x21, #0x341]                          
02d6831c: ldr     x20, [x20, #0xbd0]                         MS:MonoSingleton`1::get_Instance
02d68320: tbnz    w8, #0, #0x2d6835c                         
02d68324: adrp    x0, #0x6264000                             
02d68328: ldr     x0, [x0, #0xf90]                           T:System.Action
02d6832c: bl      #0x2b70db0                                 fn_2b70db0
02d68330: adrp    x0, #0x626c000                             
02d68334: ldr     x0, [x0, #0x288]                           M:Clicker.CollectionKeycapItem::<OnBtnLockClick>b__19_0
02d68338: bl      #0x2b70db0                                 fn_2b70db0
02d6833c: adrp    x0, #0x6267000                             
02d68340: ldr     x0, [x0, #0xbd0]                           MS:MonoSingleton`1::get_Instance
02d68344: bl      #0x2b70db0                                 fn_2b70db0
02d68348: adrp    x0, #0x626c000                             
02d6834c: ldr     x0, [x0, #0x290]                           MS:UIManager::ShowPopup
02d68350: bl      #0x2b70db0                                 fn_2b70db0
02d68354: mov     w8, #1                                     
02d68358: strb    w8, [x21, #0x341]                          
02d6835c: mov     x0, xzr                                    
02d68360: bl      #0x2d6ff04                                 Framework.AudioHelper::PlayClickSound
02d68364: ldr     x0, [x20]                                  S:'didu'
02d68368: bl      #0x3769600                                 fn_3769600
02d6836c: cbz     x0, #0x2d683d0                             
02d68370: adrp    x8, #0x626c000                             
02d68374: adrp    x20, #0x6264000                            
02d68378: adrp    x21, #0x626c000                            
02d6837c: ldr     x8, [x8, #0x290]                           MS:UIManager::ShowPopup
02d68380: ldr     x20, [x20, #0xf90]                         T:System.Action
02d68384: ldr     x21, [x21, #0x288]                         M:Clicker.CollectionKeycapItem::<OnBtnLockClick>b__19_0
02d68388: ldr     x1, [x8]                                   M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d6838c: bl      #0x33fbfac                                 fn_33fbfac
02d68390: ldr     x8, [x20]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d68394: mov     x20, x0                                    
02d68398: mov     x0, x8                                     
02d6839c: bl      #0x2b7104c                                 fn_2b7104c
02d683a0: ldr     x2, [x21]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d683a4: mov     x1, x19                                    
02d683a8: mov     x3, xzr                                    
02d683ac: mov     x21, x0                                    
02d683b0: bl      #0x4d8ddbc                                 System.Action::.ctor
02d683b4: cbz     x20, #0x2d683d0                            
02d683b8: mov     x0, x20                                    
02d683bc: ldp     x20, x19, [sp, #0x10]                      
02d683c0: mov     x1, x21                                    
02d683c4: mov     w2, #0x1f4                                 
02d683c8: ldp     x30, x21, [sp], #0x20                      
02d683cc: b       #0x2d672bc                                 Clicker.CollectionFullPopup::SetEventCallback
02d683d0: bl      #0x2b7105c                                 fn_2b7105c
## OnBtnAvailableClick() -> void
---- Clicker.CollectionKeycapItem::OnBtnAvailableClick 0x2d683d4
02d683d4: str     x30, [sp, #-0x20]!                         
02d683d8: stp     x20, x19, [sp, #0x10]                      
02d683dc: adrp    x20, #0x6630000                            
02d683e0: adrp    x19, #0x6267000                            
02d683e4: ldrb    w8, [x20, #0x342]                          
02d683e8: ldr     x19, [x19, #0xbd0]                         MS:MonoSingleton`1::get_Instance
02d683ec: tbnz    w8, #0, #0x2d68410                         
02d683f0: adrp    x0, #0x6267000                             
02d683f4: ldr     x0, [x0, #0xbd0]                           MS:MonoSingleton`1::get_Instance
02d683f8: bl      #0x2b70db0                                 fn_2b70db0
02d683fc: adrp    x0, #0x626c000                             
02d68400: ldr     x0, [x0, #0x298]                           MS:UIManager::ShowPopup
02d68404: bl      #0x2b70db0                                 fn_2b70db0
02d68408: mov     w8, #1                                     
02d6840c: strb    w8, [x20, #0x342]                          
02d68410: mov     x0, xzr                                    
02d68414: bl      #0x2d6ff04                                 Framework.AudioHelper::PlayClickSound
02d68418: ldr     x0, [x19]                                  S:'didu'
02d6841c: bl      #0x3769600                                 fn_3769600
02d68420: cbz     x0, #0x2d6843c                             
02d68424: adrp    x8, #0x626c000                             
02d68428: ldr     x8, [x8, #0x298]                           MS:UIManager::ShowPopup
02d6842c: ldp     x20, x19, [sp, #0x10]                      
02d68430: ldr     x1, [x8]                                   M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d68434: ldr     x30, [sp], #0x20                           
02d68438: b       #0x33fbfac                                 
02d6843c: bl      #0x2b7105c                                 fn_2b7105c
## OnBtnInspectClick() -> void
---- Clicker.CollectionKeycapItem::OnBtnInspectClick 0x2d68440
02d68440: stp     x30, x23, [sp, #-0x30]!                    
02d68444: stp     x22, x21, [sp, #0x10]                      
02d68448: stp     x20, x19, [sp, #0x20]                      
02d6844c: adrp    x23, #0x6630000                            
02d68450: adrp    x22, #0x6265000                            
02d68454: adrp    x20, #0x6264000                            
02d68458: adrp    x21, #0x626c000                            
02d6845c: ldr     x22, [x22, #0x310]                         MS:WejoyService.Singleton`1::get_Instance
02d68460: ldrb    w8, [x23, #0x343]                          
02d68464: ldr     x20, [x20, #0xf90]                         T:System.Action
02d68468: ldr     x21, [x21, #0x2a0]                         M:Clicker.CollectionKeycapItem::<OnBtnInspectClick>b__21_0
02d6846c: mov     x19, x0                                    
02d68470: tbnz    w8, #0, #0x2d684ac                         
02d68474: adrp    x0, #0x6264000                             
02d68478: ldr     x0, [x0, #0xf90]                           T:System.Action
02d6847c: bl      #0x2b70db0                                 fn_2b70db0
02d68480: adrp    x0, #0x626c000                             
02d68484: ldr     x0, [x0, #0x2a0]                           M:Clicker.CollectionKeycapItem::<OnBtnInspectClick>b__21_0
02d68488: bl      #0x2b70db0                                 fn_2b70db0
02d6848c: adrp    x0, #0x6265000                             
02d68490: ldr     x0, [x0, #0x310]                           MS:WejoyService.Singleton`1::get_Instance
02d68494: bl      #0x2b70db0                                 fn_2b70db0
02d68498: adrp    x0, #0x626c000                             
02d6849c: ldr     x0, [x0, #0x2a8]                           S:'collection_inspect'
02d684a0: bl      #0x2b70db0                                 fn_2b70db0
02d684a4: mov     w8, #1                                     
02d684a8: strb    w8, [x23, #0x343]                          
02d684ac: mov     x0, xzr                                    
02d684b0: bl      #0x2d6ff04                                 Framework.AudioHelper::PlayClickSound
02d684b4: ldr     x0, [x22]                                  M:AdsManager::<OnApplicationPause>b__26_0
02d684b8: bl      #0x3be7218                                 fn_3be7218
02d684bc: ldr     x8, [x20]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d684c0: mov     x20, x0                                    
02d684c4: mov     x0, x8                                     
02d684c8: bl      #0x2b7104c                                 fn_2b7104c
02d684cc: ldr     x2, [x21]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d684d0: mov     x1, x19                                    
02d684d4: mov     x3, xzr                                    
02d684d8: mov     x21, x0                                    
02d684dc: bl      #0x4d8ddbc                                 System.Action::.ctor
02d684e0: cbz     x20, #0x2d68510                            
02d684e4: adrp    x8, #0x626c000                             
02d684e8: mov     x0, x20                                    
02d684ec: mov     x2, x21                                    
02d684f0: ldr     x8, [x8, #0x2a8]                           S:'collection_inspect'
02d684f4: ldp     x20, x19, [sp, #0x20]                      
02d684f8: ldp     x22, x21, [sp, #0x10]                      
02d684fc: mov     w3, #1                                     
02d68500: ldr     x1, [x8]                                   M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d68504: mov     x4, xzr                                    
02d68508: ldp     x30, x23, [sp], #0x30                      
02d6850c: b       #0x2c89698                                 AdsManager::ShowInter
02d68510: bl      #0x2b7105c                                 fn_2b7105c
## .ctor() -> void
---- Clicker.CollectionKeycapItem::.ctor 0x2d68514
02d68514: mov     x1, xzr                                    
02d68518: b       #0x5b397b0                                 UnityEngine.MonoBehaviour::.ctor
## <OnBtnLockClick>b__19_0() -> void
---- Clicker.CollectionKeycapItem::<OnBtnLockClick>b__19_0 0x2d6851c
02d6851c: str     x30, [sp, #-0x20]!                         
02d68520: stp     x20, x19, [sp, #0x10]                      
02d68524: adrp    x20, #0x6630000                            
02d68528: mov     x19, x0                                    
02d6852c: ldrb    w8, [x20, #0x344]                          
02d68530: tbnz    w8, #0, #0x2d68554                         
02d68534: adrp    x0, #0x6269000                             
02d68538: ldr     x0, [x0, #0x3f8]                           MS:DataManager::GetData
02d6853c: bl      #0x2b70db0                                 fn_2b70db0
02d68540: adrp    x0, #0x6266000                             
02d68544: ldr     x0, [x0, #0x658]                           MS:MonoSingleton`1::get_Instance
02d68548: bl      #0x2b70db0                                 fn_2b70db0
02d6854c: mov     w8, #1                                     
02d68550: strb    w8, [x20, #0x344]                          
02d68554: ldr     x0, [x19, #0x60]                           ._screenClickerCollection
02d68558: cbz     x0, #0x2d685b4                             
02d6855c: adrp    x19, #0x6266000                            
02d68560: ldr     x19, [x19, #0x658]                         MS:MonoSingleton`1::get_Instance
02d68564: bl      #0x2d5cdb8                                 Clicker.ScreenClickerCollection::UnlockNewSlot
02d68568: ldr     x0, [x19]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d6856c: bl      #0x3769600                                 fn_3769600
02d68570: cbz     x0, #0x2d685b4                             
02d68574: adrp    x8, #0x6269000                             
02d68578: ldr     x8, [x8, #0x3f8]                           MS:DataManager::GetData
02d6857c: ldr     x1, [x8]                                   T:Trading.TradingSession/<>c__DisplayClass56_0
02d68580: bl      #0x3168dd0                                 fn_3168dd0
02d68584: cbz     x0, #0x2d685b4                             
02d68588: ldr     x8, [x0, #0x20]                            S:'inter_ad_capping_time' ._keycapGenerator
02d6858c: cbz     x8, #0x2d685b4                             
02d68590: ldr     w9, [x8, #0x10]                            M:Trading.TradingSession/<>c__DisplayClass56_0::<RemovePlayerItem>b__0
02d68594: ldp     x20, x19, [sp, #0x10]                      
02d68598: add     w9, w9, #1                                 
02d6859c: str     w9, [x8, #0x10]                            
02d685a0: ldr     x8, [x0]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d685a4: ldr     x1, [x8, #0x260]                           M:Trading.PopupTradingEmptyCollection::OnBtnLaterClick
02d685a8: ldr     x2, [x8, #0x258]                           M:Trading.PopupTradingEmptyCollection::OnBtnGoDiyClick
02d685ac: ldr     x30, [sp], #0x20                           
02d685b0: br      x2                                         
02d685b4: bl      #0x2b7105c                                 fn_2b7105c
## <OnBtnInspectClick>b__21_0() -> void
---- Clicker.CollectionKeycapItem::<OnBtnInspectClick>b__21_0 0x2d685b8
02d685b8: stp     x30, x21, [sp, #-0x20]!                    
02d685bc: stp     x20, x19, [sp, #0x10]                      
02d685c0: adrp    x20, #0x6630000                            
02d685c4: adrp    x21, #0x6267000                            
02d685c8: mov     x19, x0                                    
02d685cc: ldrb    w8, [x20, #0x345]                          
02d685d0: ldr     x21, [x21, #0xbd0]                         MS:MonoSingleton`1::get_Instance
02d685d4: tbnz    w8, #0, #0x2d685f8                         
02d685d8: adrp    x0, #0x6267000                             
02d685dc: ldr     x0, [x0, #0xbd0]                           MS:MonoSingleton`1::get_Instance
02d685e0: bl      #0x2b70db0                                 fn_2b70db0
02d685e4: adrp    x0, #0x6269000                             
02d685e8: ldr     x0, [x0, #0x5c8]                           MS:UIManager::GetScreen
02d685ec: bl      #0x2b70db0                                 fn_2b70db0
02d685f0: mov     w8, #1                                     
02d685f4: strb    w8, [x20, #0x345]                          
02d685f8: ldr     x0, [x21]                                  S:'didu'
02d685fc: bl      #0x3769600                                 fn_3769600
02d68600: cbz     x0, #0x2d68628                             
02d68604: adrp    x8, #0x6269000                             
02d68608: ldr     x8, [x8, #0x5c8]                           MS:UIManager::GetScreen
02d6860c: ldr     x1, [x8]                                   T:Trading.TradingSession/<>c__DisplayClass56_0
02d68610: bl      #0x33fbbd0                                 fn_33fbbd0
02d68614: cbz     x0, #0x2d68628                             
02d68618: mov     x1, x19                                    
02d6861c: ldp     x20, x19, [sp, #0x10]                      
02d68620: ldp     x30, x21, [sp], #0x20                      
02d68624: b       #0x2d5c894                                 Clicker.ScreenClickerCollection::ShowPreviewClick
02d68628: bl      #0x2b7105c                                 fn_2b7105c
