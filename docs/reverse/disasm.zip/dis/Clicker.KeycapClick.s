#### CLASS Clicker.KeycapClick/<>c__DisplayClass10_0 parent= object
#   field callBackEvent                  System.Action`1<int>                               off=0x10 attr=6 
#   field keycapIndex                    int                                                off=0x18 attr=6 
## .ctor() -> void
---- Clicker.KeycapClick/<>c__DisplayClass10_0::.ctor 0x2d638ec
02d638ec: mov     x1, xzr                                    
02d638f0: b       #0x4e53e9c                                 System.Object::.ctor
## <SetButtonSetupEvent>b__0() -> void
---- Clicker.KeycapClick/<>c__DisplayClass10_0::<SetButtonSetupEvent>b__0 0x2d63d38
02d63d38: ldr     x8, [x0, #0x10]                            .callBackEvent
02d63d3c: cbz     x8, #0x2d63d54                             
02d63d40: ldr     w1, [x0, #0x18]                            .keycapIndex
02d63d44: ldr     x0, [x8, #0x40]                            
02d63d48: ldr     x2, [x8, #0x28]                            
02d63d4c: ldr     x3, [x8, #0x18]                            
02d63d50: br      x3                                         
02d63d54: ret                                                
#### CLASS Clicker.KeycapClick parent= UnityEngine.MonoBehaviour
#   field _btnSetup                      UnityEngine.UI.Button                              off=0x20 attr=1 SerializeField
#   field _btnFullEventTrigger           UnityEngine.EventSystems.EventTrigger              off=0x28 attr=1 SerializeField
#   field _keycapObject                  Clicker.KeycapObject                               off=0x30 attr=1 
#   field _onSetupClick                  UnityEngine.Events.UnityEvent                      off=0x38 attr=1 
#   field _soundClick                    Framework.ESound                                   off=0x40 attr=1 
#   field _baseKeycapObject              Clicker.BaseKeycapObject                           off=0x48 attr=1 
#   field _glowSprite2DItem              Clicker.GlowSprite2DItem                           off=0x50 attr=1 
## Awake() -> void
---- Clicker.KeycapClick::Awake 0x2d63618
02d63618: stp     x30, x23, [sp, #-0x30]!                    
02d6361c: stp     x22, x21, [sp, #0x10]                      
02d63620: stp     x20, x19, [sp, #0x20]                      
02d63624: adrp    x20, #0x6630000                            
02d63628: adrp    x21, #0x626c000                            
02d6362c: mov     x19, x0                                    
02d63630: ldrb    w8, [x20, #0x30a]                          
02d63634: ldr     x21, [x21, #0x28]                          MS:UnityEngine.Component::GetComponentInParent ._btnFullEventTrigger
02d63638: tbnz    w8, #0, #0x2d636bc                         
02d6363c: adrp    x0, #0x626c000                             
02d63640: ldr     x0, [x0, #0x28]                            MS:UnityEngine.Component::GetComponentInParent ._btnFullEventTrigger
02d63644: bl      #0x2b70db0                                 fn_2b70db0
02d63648: adrp    x0, #0x626c000                             
02d6364c: ldr     x0, [x0, #0x30]                            T:UnityEngine.EventSystems.EventTrigger/Entry ._keycapObject
02d63650: bl      #0x2b70db0                                 fn_2b70db0
02d63654: adrp    x0, #0x626c000                             
02d63658: ldr     x0, [x0, #0x38]                            M:Clicker.KeycapClick::HandleSetup ._onSetupClick
02d6365c: bl      #0x2b70db0                                 fn_2b70db0
02d63660: adrp    x0, #0x626c000                             
02d63664: ldr     x0, [x0, #0x40]                            M:Clicker.KeycapClick::<Awake>b__7_0 ._soundClick
02d63668: bl      #0x2b70db0                                 fn_2b70db0
02d6366c: adrp    x0, #0x626c000                             
02d63670: ldr     x0, [x0, #0x48]                            MS:System.Collections.Generic.List`1::Add ._baseKeycapObject
02d63674: bl      #0x2b70db0                                 fn_2b70db0
02d63678: adrp    x0, #0x626c000                             
02d6367c: ldr     x0, [x0, #0x50]                            MS:System.Collections.Generic.List`1::Clear ._glowSprite2DItem
02d63680: bl      #0x2b70db0                                 fn_2b70db0
02d63684: adrp    x0, #0x626c000                             
02d63688: ldr     x0, [x0, #0x58]                            T:UnityEngine.EventSystems.EventTrigger/TriggerEvent
02d6368c: bl      #0x2b70db0                                 fn_2b70db0
02d63690: adrp    x0, #0x626c000                             
02d63694: ldr     x0, [x0, #0x60]                            T:type58819(k15)
02d63698: bl      #0x2b70db0                                 fn_2b70db0
02d6369c: adrp    x0, #0x6265000                             
02d636a0: ldr     x0, [x0, #0x3f0]                           T:UnityEngine.Events.UnityAction
02d636a4: bl      #0x2b70db0                                 fn_2b70db0
02d636a8: adrp    x0, #0x626c000                             
02d636ac: ldr     x0, [x0, #0x68]                            MS:UnityEngine.Events.UnityEvent`1::AddListener
02d636b0: bl      #0x2b70db0                                 fn_2b70db0
02d636b4: mov     w8, #1                                     
02d636b8: strb    w8, [x20, #0x30a]                          
02d636bc: ldr     x1, [x21]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d636c0: mov     x0, x19                                    
02d636c4: bl      #0x3141210                                 fn_3141210
02d636c8: mov     x20, x19                                   
02d636cc: mov     x1, x0                                     
02d636d0: str     x0, [x20, #0x30]!                          ._keycapObject
02d636d4: mov     x0, x20                                    
02d636d8: bl      #0x2b70d54                                 fn_2b70d54
02d636dc: ldur    x8, [x20, #-0x10]                          
02d636e0: cbz     x8, #0x2d638e0                             
02d636e4: ldr     x0, [x8, #0x100]                           
02d636e8: cbz     x0, #0x2d638e0                             
02d636ec: mov     x1, xzr                                    
02d636f0: bl      #0x5b4ce48                                 UnityEngine.Events.UnityEventBase::RemoveAllListeners
02d636f4: ldr     x8, [x19, #0x20]                           ._btnSetup
02d636f8: cbz     x8, #0x2d638e0                             
02d636fc: adrp    x9, #0x6265000                             
02d63700: adrp    x21, #0x626c000                            
02d63704: ldr     x9, [x9, #0x3f0]                           T:UnityEngine.Events.UnityAction
02d63708: ldr     x21, [x21, #0x38]                          M:Clicker.KeycapClick::HandleSetup ._onSetupClick
02d6370c: ldr     x20, [x8, #0x100]                          
02d63710: ldr     x0, [x9]                                   M:AdsManager::<OnApplicationPause>b__26_0
02d63714: bl      #0x2b7104c                                 fn_2b7104c
02d63718: ldr     x2, [x21]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d6371c: mov     x1, x19                                    
02d63720: mov     x3, xzr                                    
02d63724: mov     x21, x0                                    
02d63728: bl      #0x5b4cf98                                 UnityEngine.Events.UnityAction::.ctor
02d6372c: cbz     x20, #0x2d638e0                            
02d63730: adrp    x22, #0x626c000                            
02d63734: mov     x0, x20                                    
02d63738: mov     x1, x21                                    
02d6373c: ldr     x22, [x22, #0x30]                          T:UnityEngine.EventSystems.EventTrigger/Entry
02d63740: mov     x2, xzr                                    
02d63744: bl      #0x5b4d0ac                                 UnityEngine.Events.UnityEvent::AddListener
02d63748: ldr     x0, [x22]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d6374c: bl      #0x2b7104c                                 fn_2b7104c
02d63750: mov     x1, xzr                                    
02d63754: mov     x20, x0                                    
02d63758: bl      #0x5e79a28                                 UnityEngine.EventSystems.EventTrigger/Entry::.ctor
02d6375c: cbz     x20, #0x2d638e0                            
02d63760: adrp    x8, #0x626c000                             
02d63764: mov     w9, #2                                     
02d63768: ldr     x8, [x8, #0x58]                            T:UnityEngine.EventSystems.EventTrigger/TriggerEvent
02d6376c: str     w9, [x20, #0x10]                           
02d63770: ldr     x0, [x8]                                   M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d63774: bl      #0x2b7104c                                 fn_2b7104c
02d63778: mov     x1, xzr                                    
02d6377c: mov     x22, x0                                    
02d63780: bl      #0x5e799e0                                 UnityEngine.EventSystems.EventTrigger/TriggerEvent::.ctor
02d63784: mov     x21, x20                                   
02d63788: mov     x1, x22                                    
02d6378c: str     x22, [x21, #0x18]!                         
02d63790: mov     x0, x21                                    
02d63794: bl      #0x2b70d54                                 fn_2b70d54
02d63798: ldr     x0, [x19, #0x28]                           ._btnFullEventTrigger
02d6379c: cbz     x0, #0x2d638e0                             
02d637a0: mov     x1, xzr                                    
02d637a4: bl      #0x5e79794                                 UnityEngine.EventSystems.EventTrigger::get_triggers
02d637a8: cbz     x0, #0x2d638e0                             
02d637ac: ldp     w2, w8, [x0, #0x18]                        
02d637b0: add     w8, w8, #1                                 
02d637b4: cmp     w2, #1                                     
02d637b8: stp     wzr, w8, [x0, #0x18]                       
02d637bc: b.lt    #0x2d637d0                                 
02d637c0: ldr     x0, [x0, #0x10]                            M:Clicker.GlowSprite2DItem::<DoGlow>b__10_4
02d637c4: mov     w1, wzr                                    
02d637c8: mov     x3, xzr                                    
02d637cc: bl      #0x4e3494c                                 System.Array::Clear
02d637d0: ldr     x0, [x19, #0x28]                           ._btnFullEventTrigger
02d637d4: cbz     x0, #0x2d638e0                             
02d637d8: mov     x1, xzr                                    
02d637dc: bl      #0x5e79794                                 UnityEngine.EventSystems.EventTrigger::get_triggers
02d637e0: cbz     x0, #0x2d638e0                             
02d637e4: adrp    x9, #0x626c000                             
02d637e8: ldr     x9, [x9, #0x48]                            MS:System.Collections.Generic.List`1::Add
02d637ec: ldr     w10, [x0, #0x1c]                           [626c01c]=0 f=0,0
02d637f0: ldr     x8, [x0, #0x10]                            M:Clicker.GlowSprite2DItem::<DoGlow>b__10_4
02d637f4: ldr     x9, [x9]                                   M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d637f8: add     w10, w10, #1                               
02d637fc: str     w10, [x0, #0x1c]                           
02d63800: cbz     x8, #0x2d638e0                             
02d63804: ldrsw   x10, [x0, #0x18]                           
02d63808: ldr     w11, [x8, #0x18]                           M:Clicker.GlowSprite2DItem::<DoGlow>b__10_5
02d6380c: adrp    x23, #0x626c000                            
02d63810: adrp    x22, #0x626c000                            
02d63814: ldr     x23, [x23, #0x60]                          T:type58819(k15)
02d63818: ldr     x22, [x22, #0x40]                          M:Clicker.KeycapClick::<Awake>b__7_0
02d6381c: cmp     w10, w11                                   
02d63820: b.hs    #0x2d63844                                 
02d63824: add     x8, x8, x10, lsl #3                        &626c000
02d63828: add     w9, w10, #1                                
02d6382c: mov     x1, x20                                    
02d63830: str     w9, [x0, #0x18]                            
02d63834: str     x20, [x8, #0x20]!                          
02d63838: mov     x0, x8                                     
02d6383c: bl      #0x2b70d54                                 fn_2b70d54
02d63840: b       #0x2d63858                                 
02d63844: ldr     x8, [x9, #0x20]                            M:Clicker.GlowSprite2DItem::<DoGlow>b__10_6
02d63848: mov     x1, x20                                    
02d6384c: ldr     x8, [x8, #0xc0]                            MS:System.Collections.Generic.List`1::Contains
02d63850: ldr     x2, [x8, #0x70]                            M:Clicker.HandFollowClick::<ClickAt>b__2_0
02d63854: bl      #0x35a920c                                 fn_35a920c
02d63858: ldr     x0, [x23]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d6385c: ldr     x20, [x21]                                 M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d63860: bl      #0x2b7104c                                 fn_2b7104c
02d63864: ldr     x2, [x22]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d63868: mov     x1, x19                                    
02d6386c: mov     x3, xzr                                    
02d63870: mov     x21, x0                                    
02d63874: bl      #0x3edf9d4                                 fn_3edf9d4
02d63878: cbz     x20, #0x2d638e0                            
02d6387c: adrp    x8, #0x626c000                             
02d63880: mov     x0, x20                                    
02d63884: mov     x1, x21                                    
02d63888: ldr     x8, [x8, #0x68]                            MS:UnityEngine.Events.UnityEvent`1::AddListener
02d6388c: ldr     x2, [x8]                                   M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d63890: bl      #0x3ee64cc                                 fn_3ee64cc
02d63894: ldr     x0, [x19, #0x28]                           ._btnFullEventTrigger
02d63898: cbz     x0, #0x2d638e0                             
02d6389c: mov     x1, xzr                                    
02d638a0: bl      #0x5b339ec                                 UnityEngine.Component::get_gameObject
02d638a4: cbz     x0, #0x2d638e0                             
02d638a8: mov     w1, wzr                                    
02d638ac: mov     x2, xzr                                    
02d638b0: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d638b4: ldr     x0, [x19, #0x20]                           ._btnSetup
02d638b8: cbz     x0, #0x2d638e0                             
02d638bc: mov     x1, xzr                                    
02d638c0: bl      #0x5b339ec                                 UnityEngine.Component::get_gameObject
02d638c4: cbz     x0, #0x2d638e0                             
02d638c8: ldp     x20, x19, [sp, #0x20]                      
02d638cc: mov     w1, wzr                                    
02d638d0: ldp     x22, x21, [sp, #0x10]                      
02d638d4: mov     x2, xzr                                    
02d638d8: ldp     x30, x23, [sp], #0x30                      
02d638dc: b       #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d638e0: bl      #0x2b7105c                                 fn_2b7105c
## SetBaseKeycapObject(Clicker.BaseKeycapObject baseKeycapObject) -> void
---- Clicker.KeycapClick::SetBaseKeycapObject 0x2d638e4
02d638e4: str     x1, [x0, #0x48]!                           ._baseKeycapObject
02d638e8: b       #0x2b70d54                                 
## TurnModeSetup(bool isSetupOn) -> void
---- Clicker.KeycapClick::TurnModeSetup 0x2d61678
02d61678: str     x30, [sp, #-0x20]!                         
02d6167c: stp     x20, x19, [sp, #0x10]                      
02d61680: mov     x20, x0                                    
02d61684: ldr     x0, [x0, #0x28]                            ._btnFullEventTrigger
02d61688: cbz     x0, #0x2d616d4                             
02d6168c: mov     w19, w1                                    
02d61690: mov     x1, xzr                                    
02d61694: bl      #0x5b339ec                                 UnityEngine.Component::get_gameObject
02d61698: cbz     x0, #0x2d616d4                             
02d6169c: mov     w8, #1                                     
02d616a0: mov     x2, xzr                                    
02d616a4: bic     w1, w8, w19                                
02d616a8: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d616ac: ldr     x0, [x20, #0x20]                           ._btnSetup
02d616b0: cbz     x0, #0x2d616d4                             
02d616b4: mov     x1, xzr                                    
02d616b8: bl      #0x5b339ec                                 UnityEngine.Component::get_gameObject
02d616bc: cbz     x0, #0x2d616d4                             
02d616c0: and     w1, w19, #1                                
02d616c4: ldp     x20, x19, [sp, #0x10]                      
02d616c8: mov     x2, xzr                                    
02d616cc: ldr     x30, [sp], #0x20                           
02d616d0: b       #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d616d4: bl      #0x2b7105c                                 fn_2b7105c
## SetButtonSetupEvent(System.Action`1<int> callBackEvent, int keycapIndex) -> void
---- Clicker.KeycapClick::SetButtonSetupEvent 0x2d5e3ec
02d5e3ec: stp     x30, x23, [sp, #-0x30]!                    
02d5e3f0: stp     x22, x21, [sp, #0x10]                      
02d5e3f4: stp     x20, x19, [sp, #0x20]                      
02d5e3f8: adrp    x22, #0x6630000                            
02d5e3fc: adrp    x23, #0x626b000                            
02d5e400: mov     w20, w2                                    
02d5e404: ldrb    w8, [x22, #0x30b]                          
02d5e408: ldr     x23, [x23, #0xe70]                         T:Clicker.KeycapClick/<>c__DisplayClass10_0
02d5e40c: mov     x21, x1                                    
02d5e410: mov     x19, x0                                    
02d5e414: tbnz    w8, #0, #0x2d5e444                         
02d5e418: adrp    x0, #0x626b000                             
02d5e41c: ldr     x0, [x0, #0xe78]                           M:Clicker.KeycapClick/<>c__DisplayClass10_0::<SetButtonSetupEvent>b__0
02d5e420: bl      #0x2b70db0                                 fn_2b70db0
02d5e424: adrp    x0, #0x626b000                             
02d5e428: ldr     x0, [x0, #0xe70]                           T:Clicker.KeycapClick/<>c__DisplayClass10_0
02d5e42c: bl      #0x2b70db0                                 fn_2b70db0
02d5e430: adrp    x0, #0x6265000                             
02d5e434: ldr     x0, [x0, #0x3f0]                           T:UnityEngine.Events.UnityAction
02d5e438: bl      #0x2b70db0                                 fn_2b70db0
02d5e43c: mov     w8, #1                                     
02d5e440: strb    w8, [x22, #0x30b]                          
02d5e444: ldr     x0, [x23]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d5e448: bl      #0x2b7104c                                 fn_2b7104c
02d5e44c: mov     x1, xzr                                    
02d5e450: mov     x22, x0                                    
02d5e454: bl      #0x4e53e9c                                 System.Object::.ctor
02d5e458: cbz     x22, #0x2d5e4d4                            
02d5e45c: mov     x23, x22                                   
02d5e460: mov     x1, x21                                    
02d5e464: str     x21, [x23, #0x10]!                         
02d5e468: mov     x0, x23                                    
02d5e46c: bl      #0x2b70d54                                 fn_2b70d54
02d5e470: ldr     x0, [x19, #0x38]                           ._onSetupClick
02d5e474: str     w20, [x23, #8]                             
02d5e478: cbz     x0, #0x2d5e4d4                             
02d5e47c: adrp    x20, #0x6265000                            
02d5e480: adrp    x21, #0x626b000                            
02d5e484: mov     x1, xzr                                    
02d5e488: ldr     x20, [x20, #0x3f0]                         T:UnityEngine.Events.UnityAction
02d5e48c: ldr     x21, [x21, #0xe78]                         M:Clicker.KeycapClick/<>c__DisplayClass10_0::<SetButtonSetupEvent>b__0
02d5e490: bl      #0x5b4ce48                                 UnityEngine.Events.UnityEventBase::RemoveAllListeners
02d5e494: ldr     x0, [x20]                                  M:AdsManager::<OnApplicationPause>b__26_0
02d5e498: ldr     x19, [x19, #0x38]                          ._onSetupClick
02d5e49c: bl      #0x2b7104c                                 fn_2b7104c
02d5e4a0: ldr     x2, [x21]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d5e4a4: mov     x1, x22                                    
02d5e4a8: mov     x3, xzr                                    
02d5e4ac: mov     x20, x0                                    
02d5e4b0: bl      #0x5b4cf98                                 UnityEngine.Events.UnityAction::.ctor
02d5e4b4: cbz     x19, #0x2d5e4d4                            
02d5e4b8: mov     x0, x19                                    
02d5e4bc: mov     x1, x20                                    
02d5e4c0: mov     x2, xzr                                    
02d5e4c4: ldp     x20, x19, [sp, #0x20]                      
02d5e4c8: ldp     x22, x21, [sp, #0x10]                      
02d5e4cc: ldp     x30, x23, [sp], #0x30                      
02d5e4d0: b       #0x5b4d0ac                                 UnityEngine.Events.UnityEvent::AddListener
02d5e4d4: bl      #0x2b7105c                                 fn_2b7105c
## RemoveSetupEvent() -> void
---- Clicker.KeycapClick::RemoveSetupEvent 0x2d61220
02d61220: ldr     x0, [x0, #0x38]                            ._onSetupClick
02d61224: cbz     x0, #0x2d61230                             
02d61228: mov     x1, xzr                                    
02d6122c: b       #0x5b4ce48                                 UnityEngine.Events.UnityEventBase::RemoveAllListeners
02d61230: str     x30, [sp, #-0x10]!                         
02d61234: bl      #0x2b7105c                                 fn_2b7105c
## HandleClick() -> void
---- Clicker.KeycapClick::HandleClick 0x2d60624
02d60624: stp     x30, x23, [sp, #-0x30]!                    
02d60628: stp     x22, x21, [sp, #0x10]                      
02d6062c: stp     x20, x19, [sp, #0x20]                      
02d60630: adrp    x20, #0x6630000                            
02d60634: adrp    x21, #0x6263000                            
02d60638: mov     x19, x0                                    
02d6063c: ldrb    w8, [x20, #0x30c]                          
02d60640: ldr     x21, [x21, #0x918]                         T:UnityEngine.Object
02d60644: tbnz    w8, #0, #0x2d606bc                         
02d60648: adrp    x0, #0x626b000                             
02d6064c: ldr     x0, [x0, #0xf18]                           M:Clicker.KeycapClick::<HandleClick>b__12_0
02d60650: bl      #0x2b70db0                                 fn_2b70db0
02d60654: adrp    x0, #0x626b000                             
02d60658: ldr     x0, [x0, #0xf20]                           MS:MonoSingleton`1::get_Instance
02d6065c: bl      #0x2b70db0                                 fn_2b70db0
02d60660: adrp    x0, #0x6267000                             
02d60664: ldr     x0, [x0, #0xbd0]                           MS:MonoSingleton`1::get_Instance
02d60668: bl      #0x2b70db0                                 fn_2b70db0
02d6066c: adrp    x0, #0x626b000                             
02d60670: ldr     x0, [x0, #0xee0]                           MS:MonoSingleton`1::get_Instance
02d60674: bl      #0x2b70db0                                 fn_2b70db0
02d60678: adrp    x0, #0x6263000                             
02d6067c: ldr     x0, [x0, #0x918]                           T:UnityEngine.Object
02d60680: bl      #0x2b70db0                                 fn_2b70db0
02d60684: adrp    x0, #0x6264000                             
02d60688: ldr     x0, [x0, #0xe8]                            T:DG.Tweening.TweenCallback
02d6068c: bl      #0x2b70db0                                 fn_2b70db0
02d60690: adrp    x0, #0x6266000                             
02d60694: ldr     x0, [x0, #0x928]                           MS:DG.Tweening.TweenSettingsExtensions::OnComplete
02d60698: bl      #0x2b70db0                                 fn_2b70db0
02d6069c: adrp    x0, #0x626b000                             
02d606a0: ldr     x0, [x0, #0xf28]                           MS:UIManager::GetScreen
02d606a4: bl      #0x2b70db0                                 fn_2b70db0
02d606a8: adrp    x0, #0x6267000                             
02d606ac: ldr     x0, [x0, #0xea8]                           T:Framework.Vibration
02d606b0: bl      #0x2b70db0                                 fn_2b70db0
02d606b4: mov     w8, #1                                     
02d606b8: strb    w8, [x20, #0x30c]                          
02d606bc: ldr     x0, [x21]                                  &2c5bbd4(=a9bd7bfdd503233f)
02d606c0: ldr     x20, [x19, #0x30]                          ._keycapObject
02d606c4: ldr     w8, [x0, #0xe4]                            [62670e4]=0 f=0,0
02d606c8: cbnz    w8, #0x2d606d0                             
02d606cc: bl      #0x2b70f30                                 fn_2b70f30
02d606d0: mov     x0, x20                                    
02d606d4: mov     x1, xzr                                    
02d606d8: mov     x2, xzr                                    
02d606dc: bl      #0x5b37d84                                 UnityEngine.Object::op_Equality
02d606e0: tbnz    w0, #0, #0x2d60964                         
02d606e4: ldr     x0, [x19, #0x30]                           ._keycapObject
02d606e8: cbz     x0, #0x2d60974                             
02d606ec: mov     x1, xzr                                    
02d606f0: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02d606f4: mov     w1, wzr                                    
02d606f8: mov     x2, xzr                                    
02d606fc: bl      #0x2d9d5d0                                 DG.Tweening.ShortcutExtensions::DOKill
02d60700: ldr     x0, [x19, #0x30]                           ._keycapObject
02d60704: cbz     x0, #0x2d60974                             
02d60708: mov     x1, xzr                                    
02d6070c: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02d60710: adrp    x22, #0x662f000                            
02d60714: mov     x20, x0                                    
02d60718: ldrb    w8, [x22, #0xa74]                          
02d6071c: cbnz    w8, #0x2d60734                             
02d60720: adrp    x0, #0x6264000                             
02d60724: ldr     x0, [x0, #0xd8]                            T:UnityEngine.Vector3
02d60728: bl      #0x2b70db0                                 fn_2b70db0
02d6072c: mov     w8, #1                                     
02d60730: strb    w8, [x22, #0xa74]                          
02d60734: cbz     x20, #0x2d60974                            
02d60738: adrp    x8, #0x6264000                             
02d6073c: mov     x0, x20                                    
02d60740: mov     x1, xzr                                    
02d60744: ldr     x8, [x8, #0xd8]                            T:UnityEngine.Vector3
02d60748: ldr     x8, [x8]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d6074c: ldr     x8, [x8, #0xb8]                            MS:DG.Tweening.Core.Extensions::SetSpecialStartupMode
02d60750: ldp     s1, s2, [x8, #0x10]                        
02d60754: ldr     s0, [x8, #0xc]                             [626400c]=0 f=0,0
02d60758: bl      #0x5b470cc                                 UnityEngine.Transform::set_localScale
02d6075c: ldr     x8, [x19, #0x48]                           ._baseKeycapObject
02d60760: cbz     x8, #0x2d60974                             
02d60764: ldr     x0, [x19, #0x30]                           ._keycapObject
02d60768: cbz     x0, #0x2d60974                             
02d6076c: ldr     x20, [x8, #0x98]                           M:UnityEngine.Rigidbody::MoveRotation
02d60770: mov     x1, xzr                                    
02d60774: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02d60778: cbz     x20, #0x2d60974                            
02d6077c: mov     x1, x0                                     
02d60780: mov     x0, x20                                    
02d60784: bl      #0x2d638f4                                 Clicker.HandFollowClick::ClickAt
02d60788: adrp    x22, #0x6267000                            
02d6078c: ldr     x22, [x22, #0xbd0]                         MS:MonoSingleton`1::get_Instance
02d60790: ldr     x0, [x22]                                  S:'didu'
02d60794: bl      #0x3769600                                 fn_3769600
02d60798: cbz     x0, #0x2d60974                             
02d6079c: adrp    x23, #0x626b000                            
02d607a0: ldr     x23, [x23, #0xf28]                         MS:UIManager::GetScreen
02d607a4: ldr     x1, [x23]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d607a8: bl      #0x33fbbd0                                 fn_33fbbd0
02d607ac: ldr     x8, [x21]                                  &2c5bbd4(=a9bd7bfdd503233f)
02d607b0: mov     x20, x0                                    
02d607b4: ldr     w9, [x8, #0xe4]                            [62640e4]=0 f=0,0
02d607b8: cbnz    w9, #0x2d607c4                             
02d607bc: mov     x0, x8                                     
02d607c0: bl      #0x2b70f30                                 fn_2b70f30
02d607c4: mov     x0, x20                                    
02d607c8: mov     x1, xzr                                    
02d607cc: mov     x2, xzr                                    
02d607d0: bl      #0x5b3666c                                 UnityEngine.Object::op_Inequality
02d607d4: tbz     w0, #0, #0x2d6084c                         
02d607d8: ldr     x0, [x22]                                  S:'didu'
02d607dc: bl      #0x3769600                                 fn_3769600
02d607e0: cbz     x0, #0x2d60974                             
02d607e4: ldr     x1, [x23]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d607e8: bl      #0x33fbbd0                                 fn_33fbbd0
02d607ec: cbz     x0, #0x2d60974                             
02d607f0: ldrb    w8, [x0, #0x20]                            ._btnSetup
02d607f4: cbz     w8, #0x2d6084c                             
02d607f8: adrp    x8, #0x626b000                             
02d607fc: ldr     x8, [x8, #0xf20]                           MS:MonoSingleton`1::get_Instance
02d60800: ldr     x0, [x8]                                   T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d60804: bl      #0x3769600                                 fn_3769600
02d60808: mov     x20, x0                                    
02d6080c: mov     x0, x19                                    
02d60810: mov     x1, xzr                                    
02d60814: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02d60818: cbz     x0, #0x2d60974                             
02d6081c: mov     x1, xzr                                    
02d60820: bl      #0x5b467ac                                 UnityEngine.Transform::get_position
02d60824: cbz     x20, #0x2d60974                            
02d60828: mov     x0, x20                                    
02d6082c: bl      #0x2d5d7c4                                 Clicker.ClickerPopCoin::SpawnOneCoin
02d60830: adrp    x8, #0x626b000                             
02d60834: ldr     x8, [x8, #0xee0]                           MS:MonoSingleton`1::get_Instance
02d60838: ldr     x0, [x8]                                   T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d6083c: bl      #0x3769600                                 fn_3769600
02d60840: cbz     x0, #0x2d60974                             
02d60844: mov     w1, wzr                                    
02d60848: bl      #0x2d63a4c                                 Clicker.KeycapMakerController::ShowTapHandTutorial
02d6084c: adrp    x8, #0x6267000                             
02d60850: ldr     x8, [x8, #0xea8]                           T:Framework.Vibration
02d60854: ldr     x0, [x8]                                   S:'didu'
02d60858: ldr     w8, [x0, #0xe4]                            [62640e4]=0 f=0,0
02d6085c: cbnz    w8, #0x2d60864                             
02d60860: bl      #0x2b70f30                                 fn_2b70f30
02d60864: mov     w0, #0x28                                  
02d60868: mov     w1, #-1                                    
02d6086c: mov     w2, wzr                                    
02d60870: mov     x3, xzr                                    
02d60874: bl      #0x2d6e144                                 Framework.Vibration::Vibrate
02d60878: ldr     x0, [x21]                                  &2c5bbd4(=a9bd7bfdd503233f)
02d6087c: ldr     x20, [x19, #0x50]                          ._glowSprite2DItem
02d60880: ldr     w8, [x0, #0xe4]                            [62640e4]=0 f=0,0
02d60884: cbnz    w8, #0x2d6088c                             
02d60888: bl      #0x2b70f30                                 fn_2b70f30
02d6088c: mov     x0, x20                                    
02d60890: mov     x1, xzr                                    
02d60894: mov     x2, xzr                                    
02d60898: bl      #0x5b3666c                                 UnityEngine.Object::op_Inequality
02d6089c: tbz     w0, #0, #0x2d608ac                         
02d608a0: ldr     x0, [x19, #0x50]                           ._glowSprite2DItem
02d608a4: cbz     x0, #0x2d60974                             
02d608a8: bl      #0x2d631f8                                 Clicker.GlowSprite2DItem::DoGlow
02d608ac: ldr     x0, [x19, #0x30]                           ._keycapObject
02d608b0: cbz     x0, #0x2d60974                             
02d608b4: mov     x1, xzr                                    
02d608b8: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02d608bc: adrp    x8, #0x1084000                             
02d608c0: adrp    x9, #0x1084000                             
02d608c4: mov     w1, wzr                                    
02d608c8: ldr     s0, [x8, #0xc0c]                           [1084c0c]=3fc33333becccccd f=-0.4,1.525
02d608cc: ldr     s1, [x9, #0xeec]                           [1084eec]=457ff0003dcccccd f=0.1,4095
02d608d0: mov     x2, xzr                                    
02d608d4: bl      #0x2d98060                                 DG.Tweening.ShortcutExtensions::DOLocalMoveY
02d608d8: adrp    x8, #0x6264000                             
02d608dc: mov     x20, x0                                    
02d608e0: ldr     x8, [x8, #0xe8]                            T:DG.Tweening.TweenCallback
02d608e4: ldr     x8, [x8]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d608e8: mov     x0, x8                                     
02d608ec: bl      #0x2b7104c                                 fn_2b7104c
02d608f0: adrp    x8, #0x626b000                             
02d608f4: mov     x1, x19                                    
02d608f8: mov     x3, xzr                                    
02d608fc: ldr     x8, [x8, #0xf18]                           M:Clicker.KeycapClick::<HandleClick>b__12_0
02d60900: mov     x21, x0                                    
02d60904: ldr     x2, [x8]                                   T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d60908: bl      #0x2d89dc4                                 DG.Tweening.TweenCallback::.ctor
02d6090c: adrp    x8, #0x6266000                             
02d60910: mov     x0, x20                                    
02d60914: mov     x1, x21                                    
02d60918: ldr     x8, [x8, #0x928]                           MS:DG.Tweening.TweenSettingsExtensions::OnComplete
02d6091c: ldr     x2, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d60920: bl      #0x336f26c                                 fn_336f26c
02d60924: ldr     w8, [x19, #0x40]                           ._soundClick
02d60928: cbz     w8, #0x2d60964                             
02d6092c: mov     x0, xzr                                    
02d60930: bl      #0x2d6eec8                                 Framework.AudioManager::get_Instance
02d60934: cbz     x0, #0x2d60974                             
02d60938: ldr     w1, [x19, #0x40]                           ._soundClick
02d6093c: ldp     x20, x19, [sp, #0x20]                      
02d60940: ldp     x22, x21, [sp, #0x10]                      
02d60944: movi    d1, #0000000000000000                      
02d60948: movi    d2, #0000000000000000                      
02d6094c: fmov    s0, #1.00000000                            
02d60950: mov     w2, wzr                                    
02d60954: mov     w3, wzr                                    
02d60958: mov     x4, xzr                                    
02d6095c: ldp     x30, x23, [sp], #0x30                      
02d60960: b       #0x2d6f03c                                 Framework.AudioManager::PlaySound
02d60964: ldp     x20, x19, [sp, #0x20]                      
02d60968: ldp     x22, x21, [sp, #0x10]                      
02d6096c: ldp     x30, x23, [sp], #0x30                      
02d60970: ret                                                
02d60974: bl      #0x2b7105c                                 fn_2b7105c
## SetSoundClick(Framework.ESound soundClick) -> void
---- Clicker.KeycapClick::SetSoundClick 0x2d63b10
02d63b10: str     w1, [x0, #0x40]                            ._soundClick
02d63b14: ret                                                
## HandleSetup() -> void
---- Clicker.KeycapClick::HandleSetup 0x2d63b18
02d63b18: stp     x30, x21, [sp, #-0x20]!                    
02d63b1c: stp     x20, x19, [sp, #0x10]                      
02d63b20: adrp    x21, #0x6630000                            
02d63b24: adrp    x20, #0x6263000                            
02d63b28: mov     x19, x0                                    
02d63b2c: ldrb    w8, [x21, #0x30d]                          
02d63b30: ldr     x20, [x20, #0x918]                         T:UnityEngine.Object
02d63b34: tbnz    w8, #0, #0x2d63b4c                         
02d63b38: adrp    x0, #0x6263000                             
02d63b3c: ldr     x0, [x0, #0x918]                           T:UnityEngine.Object
02d63b40: bl      #0x2b70db0                                 fn_2b70db0
02d63b44: mov     w8, #1                                     
02d63b48: strb    w8, [x21, #0x30d]                          
02d63b4c: ldr     x0, [x20]                                  &2c5bbd4(=a9bd7bfdd503233f)
02d63b50: ldr     x20, [x19, #0x30]                          ._keycapObject
02d63b54: ldr     w8, [x0, #0xe4]                            [62630e4]=0 f=0,0
02d63b58: cbnz    w8, #0x2d63b60                             
02d63b5c: bl      #0x2b70f30                                 fn_2b70f30
02d63b60: mov     x0, x20                                    
02d63b64: mov     x1, xzr                                    
02d63b68: mov     x2, xzr                                    
02d63b6c: bl      #0x5b37d84                                 UnityEngine.Object::op_Equality
02d63b70: tbnz    w0, #0, #0x2d63b8c                         
02d63b74: ldr     x0, [x19, #0x38]                           ._onSetupClick
02d63b78: cbz     x0, #0x2d63b8c                             
02d63b7c: ldp     x20, x19, [sp, #0x10]                      
02d63b80: mov     x1, xzr                                    
02d63b84: ldp     x30, x21, [sp], #0x20                      
02d63b88: b       #0x5b4d278                                 UnityEngine.Events.UnityEvent::Invoke
02d63b8c: ldp     x20, x19, [sp, #0x10]                      
02d63b90: ldp     x30, x21, [sp], #0x20                      
02d63b94: ret                                                
## CreateGlowEffect(UnityEngine.Color color) -> void
---- Clicker.KeycapClick::CreateGlowEffect 0x2d60f78
02d60f78: stp     d11, d10, [sp, #-0x40]!                    
02d60f7c: stp     d9, d8, [sp, #0x10]                        
02d60f80: str     x30, [sp, #0x20]                           
02d60f84: stp     x20, x19, [sp, #0x30]                      
02d60f88: fmov    s8, s3                                     
02d60f8c: fmov    s9, s2                                     
02d60f90: adrp    x20, #0x6630000                            
02d60f94: fmov    s10, s1                                    
02d60f98: fmov    s11, s0                                    
02d60f9c: ldrb    w8, [x20, #0x30e]                          
02d60fa0: mov     x19, x0                                    
02d60fa4: tbnz    w8, #0, #0x2d60fbc                         
02d60fa8: adrp    x0, #0x626b000                             
02d60fac: ldr     x0, [x0, #0xda8]                           MS:MonoSingleton`1::get_Instance
02d60fb0: bl      #0x2b70db0                                 fn_2b70db0
02d60fb4: mov     w8, #1                                     
02d60fb8: strb    w8, [x20, #0x30e]                          
02d60fbc: ldr     x8, [x19, #0x30]                           ._keycapObject
02d60fc0: cbz     x8, #0x2d6117c                             
02d60fc4: ldr     x0, [x8, #0x20]                            
02d60fc8: cbz     x0, #0x2d6117c                             
02d60fcc: mov     x1, xzr                                    
02d60fd0: bl      #0x5b339ec                                 UnityEngine.Component::get_gameObject
02d60fd4: cbz     x0, #0x2d6117c                             
02d60fd8: mov     x1, xzr                                    
02d60fdc: bl      #0x5b36bfc                                 UnityEngine.GameObject::get_activeSelf
02d60fe0: tbz     w0, #0, #0x2d61048                         
02d60fe4: adrp    x8, #0x626b000                             
02d60fe8: ldr     x8, [x8, #0xda8]                           MS:MonoSingleton`1::get_Instance
02d60fec: ldr     x0, [x8]                                   T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d60ff0: bl      #0x3769600                                 fn_3769600
02d60ff4: ldr     x8, [x19, #0x30]                           ._keycapObject
02d60ff8: cbz     x8, #0x2d6117c                             
02d60ffc: mov     x20, x0                                    
02d61000: ldr     x0, [x8, #0x20]                            M:ScoopGame.CategoryAsset/<>c__DisplayClass4_0::<GetOptionDataByID>b__0
02d61004: cbz     x0, #0x2d6117c                             
02d61008: mov     x1, xzr                                    
02d6100c: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02d61010: cbz     x20, #0x2d6117c                            
02d61014: mov     x1, x0                                     
02d61018: mov     x0, x20                                    
02d6101c: bl      #0x2d63b98                                 Clicker.Light2DManager::BorrowGlowItem
02d61020: mov     x20, x19                                   
02d61024: mov     x1, x0                                     
02d61028: str     x0, [x20, #0x50]!                          ._glowSprite2DItem
02d6102c: mov     x0, x20                                    
02d61030: bl      #0x2b70d54                                 fn_2b70d54
02d61034: ldur    x8, [x20, #-0x20]                          
02d61038: cbz     x8, #0x2d6117c                             
02d6103c: ldr     x0, [x8, #0x20]                            M:ScoopGame.CategoryAsset/<>c__DisplayClass4_0::<GetOptionDataByID>b__0
02d61040: cbnz    x0, #0x2d610d0                             
02d61044: b       #0x2d6117c                                 
02d61048: ldr     x8, [x19, #0x30]                           ._keycapObject
02d6104c: cbz     x8, #0x2d6117c                             
02d61050: ldr     x0, [x8, #0x30]                            MS:System.Collections.Generic.List`1::IndexOf
02d61054: cbz     x0, #0x2d6117c                             
02d61058: mov     x1, xzr                                    
02d6105c: bl      #0x5b339ec                                 UnityEngine.Component::get_gameObject
02d61060: cbz     x0, #0x2d6117c                             
02d61064: mov     x1, xzr                                    
02d61068: bl      #0x5b36bfc                                 UnityEngine.GameObject::get_activeSelf
02d6106c: tbz     w0, #0, #0x2d610f4                         
02d61070: adrp    x8, #0x626b000                             
02d61074: ldr     x8, [x8, #0xda8]                           MS:MonoSingleton`1::get_Instance
02d61078: ldr     x0, [x8]                                   T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d6107c: bl      #0x3769600                                 fn_3769600
02d61080: ldr     x8, [x19, #0x30]                           ._keycapObject
02d61084: cbz     x8, #0x2d6117c                             
02d61088: mov     x20, x0                                    
02d6108c: ldr     x0, [x8, #0x30]                            MS:System.Collections.Generic.List`1::IndexOf
02d61090: cbz     x0, #0x2d6117c                             
02d61094: mov     x1, xzr                                    
02d61098: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02d6109c: cbz     x20, #0x2d6117c                            
02d610a0: mov     x1, x0                                     
02d610a4: mov     x0, x20                                    
02d610a8: bl      #0x2d63b98                                 Clicker.Light2DManager::BorrowGlowItem
02d610ac: mov     x20, x19                                   
02d610b0: mov     x1, x0                                     
02d610b4: str     x0, [x20, #0x50]!                          ._glowSprite2DItem
02d610b8: mov     x0, x20                                    
02d610bc: bl      #0x2b70d54                                 fn_2b70d54
02d610c0: ldur    x8, [x20, #-0x20]                          
02d610c4: cbz     x8, #0x2d6117c                             
02d610c8: ldr     x0, [x8, #0x30]                            MS:System.Collections.Generic.List`1::IndexOf
02d610cc: cbz     x0, #0x2d6117c                             
02d610d0: ldr     x20, [x20]                                 
02d610d4: mov     x1, xzr                                    
02d610d8: bl      #0x5ae6cfc                                 UnityEngine.SpriteRenderer::get_sprite
02d610dc: cbz     x20, #0x2d6117c                            
02d610e0: mov     x1, x0                                     
02d610e4: ldr     x0, [x20, #0x28]                           ._btnFullEventTrigger
02d610e8: cbz     x0, #0x2d6117c                             
02d610ec: str     x1, [x0, #0x58]!                           
02d610f0: bl      #0x2b70d54                                 fn_2b70d54
02d610f4: ldr     x0, [x19, #0x50]                           ._glowSprite2DItem
02d610f8: cbz     x0, #0x2d6117c                             
02d610fc: fmov    s0, s11                                    
02d61100: fmov    s1, s10                                    
02d61104: fmov    s2, s9                                     
02d61108: fmov    s3, s8                                     
02d6110c: bl      #0x2d631b0                                 Clicker.GlowSprite2DItem::SetColor
02d61110: ldr     x0, [x19, #0x50]                           ._glowSprite2DItem
02d61114: cbz     x0, #0x2d6117c                             
02d61118: mov     x1, xzr                                    
02d6111c: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02d61120: adrp    x20, #0x662f000                            
02d61124: mov     x19, x0                                    
02d61128: ldrb    w8, [x20, #0xa74]                          
02d6112c: cbnz    w8, #0x2d61144                             
02d61130: adrp    x0, #0x6264000                             
02d61134: ldr     x0, [x0, #0xd8]                            T:UnityEngine.Vector3
02d61138: bl      #0x2b70db0                                 fn_2b70db0
02d6113c: mov     w8, #1                                     
02d61140: strb    w8, [x20, #0xa74]                          
02d61144: cbz     x19, #0x2d6117c                            
02d61148: adrp    x8, #0x6264000                             
02d6114c: mov     x0, x19                                    
02d61150: mov     x1, xzr                                    
02d61154: ldr     x8, [x8, #0xd8]                            T:UnityEngine.Vector3
02d61158: ldp     x20, x19, [sp, #0x30]                      
02d6115c: ldp     d9, d8, [sp, #0x10]                        
02d61160: ldr     x30, [sp, #0x20]                           
02d61164: ldr     x8, [x8]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d61168: ldr     x8, [x8, #0xb8]                            MS:DG.Tweening.Core.Extensions::SetSpecialStartupMode
02d6116c: ldp     s0, s1, [x8, #0xc]                         
02d61170: ldr     s2, [x8, #0x14]                            [6264014]=0 f=0,0
02d61174: ldp     d11, d10, [sp], #0x40                      
02d61178: b       #0x5b470cc                                 UnityEngine.Transform::set_localScale
02d6117c: bl      #0x2b7105c                                 fn_2b7105c
## UpdateGlow() -> void
---- Clicker.KeycapClick::UpdateGlow 0x2d613c0
02d613c0: str     x30, [sp, #-0x30]!                         
02d613c4: stp     x22, x21, [sp, #0x10]                      
02d613c8: stp     x20, x19, [sp, #0x20]                      
02d613cc: adrp    x21, #0x6630000                            
02d613d0: adrp    x20, #0x6263000                            
02d613d4: mov     x19, x0                                    
02d613d8: ldrb    w8, [x21, #0x30f]                          
02d613dc: ldr     x20, [x20, #0x918]                         T:UnityEngine.Object
02d613e0: tbnz    w8, #0, #0x2d613f8                         
02d613e4: adrp    x0, #0x6263000                             
02d613e8: ldr     x0, [x0, #0x918]                           T:UnityEngine.Object
02d613ec: bl      #0x2b70db0                                 fn_2b70db0
02d613f0: mov     w8, #1                                     
02d613f4: strb    w8, [x21, #0x30f]                          
02d613f8: ldr     x0, [x20]                                  &2c5bbd4(=a9bd7bfdd503233f)
02d613fc: ldr     x20, [x19, #0x50]                          ._glowSprite2DItem
02d61400: ldr     w8, [x0, #0xe4]                            [62630e4]=0 f=0,0
02d61404: cbnz    w8, #0x2d6140c                             
02d61408: bl      #0x2b70f30                                 fn_2b70f30
02d6140c: mov     x0, x20                                    
02d61410: mov     x1, xzr                                    
02d61414: mov     x2, xzr                                    
02d61418: bl      #0x5b37d84                                 UnityEngine.Object::op_Equality
02d6141c: tbz     w0, #0, #0x2d61430                         
02d61420: ldp     x20, x19, [sp, #0x20]                      
02d61424: ldp     x22, x21, [sp, #0x10]                      
02d61428: ldr     x30, [sp], #0x30                           
02d6142c: ret                                                
02d61430: ldr     x8, [x19, #0x30]                           ._keycapObject
02d61434: cbz     x8, #0x2d61658                             
02d61438: ldr     x0, [x8, #0x20]                            
02d6143c: cbz     x0, #0x2d61658                             
02d61440: mov     x1, xzr                                    
02d61444: bl      #0x5b339ec                                 UnityEngine.Component::get_gameObject
02d61448: cbz     x0, #0x2d61658                             
02d6144c: mov     x1, xzr                                    
02d61450: bl      #0x5b36bfc                                 UnityEngine.GameObject::get_activeSelf
02d61454: adrp    x21, #0x6264000                            
02d61458: ldr     x21, [x21, #0xd8]                          T:UnityEngine.Vector3
02d6145c: tbz     w0, #0, #0x2d61508                         
02d61460: ldr     x0, [x19, #0x50]                           ._glowSprite2DItem
02d61464: cbz     x0, #0x2d61658                             
02d61468: mov     x1, xzr                                    
02d6146c: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02d61470: ldr     x8, [x19, #0x30]                           ._keycapObject
02d61474: cbz     x8, #0x2d61658                             
02d61478: mov     x20, x0                                    
02d6147c: ldr     x0, [x8, #0x20]                            
02d61480: cbz     x0, #0x2d61658                             
02d61484: mov     x1, xzr                                    
02d61488: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02d6148c: cbz     x20, #0x2d61658                            
02d61490: mov     x1, x0                                     
02d61494: mov     x0, x20                                    
02d61498: mov     x2, xzr                                    
02d6149c: bl      #0x5b472ec                                 UnityEngine.Transform::SetParent
02d614a0: ldr     x0, [x19, #0x50]                           ._glowSprite2DItem
02d614a4: cbz     x0, #0x2d61658                             
02d614a8: mov     x1, xzr                                    
02d614ac: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02d614b0: adrp    x22, #0x662f000                            
02d614b4: mov     x20, x0                                    
02d614b8: ldrb    w8, [x22, #0x91a]                          
02d614bc: cbnz    w8, #0x2d614d4                             
02d614c0: adrp    x0, #0x6264000                             
02d614c4: ldr     x0, [x0, #0xd8]                            T:UnityEngine.Vector3
02d614c8: bl      #0x2b70db0                                 fn_2b70db0
02d614cc: mov     w8, #1                                     
02d614d0: strb    w8, [x22, #0x91a]                          
02d614d4: cbz     x20, #0x2d61658                            
02d614d8: ldr     x8, [x21]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d614dc: mov     x0, x20                                    
02d614e0: mov     x1, xzr                                    
02d614e4: ldr     x8, [x8, #0xb8]                            
02d614e8: ldp     s1, s2, [x8, #4]                           
02d614ec: ldr     s0, [x8]                                   
02d614f0: bl      #0x5b45cec                                 UnityEngine.Transform::set_localPosition
02d614f4: ldr     x8, [x19, #0x30]                           ._keycapObject
02d614f8: cbz     x8, #0x2d61658                             
02d614fc: ldr     x0, [x8, #0x20]                            
02d61500: cbnz    x0, #0x2d615d4                             
02d61504: b       #0x2d61658                                 
02d61508: ldr     x8, [x19, #0x30]                           ._keycapObject
02d6150c: cbz     x8, #0x2d61658                             
02d61510: ldr     x0, [x8, #0x30]                            
02d61514: cbz     x0, #0x2d61658                             
02d61518: mov     x1, xzr                                    
02d6151c: bl      #0x5b339ec                                 UnityEngine.Component::get_gameObject
02d61520: cbz     x0, #0x2d61658                             
02d61524: mov     x1, xzr                                    
02d61528: bl      #0x5b36bfc                                 UnityEngine.GameObject::get_activeSelf
02d6152c: tbz     w0, #0, #0x2d615f8                         
02d61530: ldr     x0, [x19, #0x50]                           ._glowSprite2DItem
02d61534: cbz     x0, #0x2d61658                             
02d61538: mov     x1, xzr                                    
02d6153c: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02d61540: ldr     x8, [x19, #0x30]                           ._keycapObject
02d61544: cbz     x8, #0x2d61658                             
02d61548: mov     x20, x0                                    
02d6154c: ldr     x0, [x8, #0x30]                            
02d61550: cbz     x0, #0x2d61658                             
02d61554: mov     x1, xzr                                    
02d61558: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02d6155c: cbz     x20, #0x2d61658                            
02d61560: mov     x1, x0                                     
02d61564: mov     x0, x20                                    
02d61568: mov     x2, xzr                                    
02d6156c: bl      #0x5b472ec                                 UnityEngine.Transform::SetParent
02d61570: ldr     x0, [x19, #0x50]                           ._glowSprite2DItem
02d61574: cbz     x0, #0x2d61658                             
02d61578: mov     x1, xzr                                    
02d6157c: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02d61580: adrp    x22, #0x662f000                            
02d61584: mov     x20, x0                                    
02d61588: ldrb    w8, [x22, #0x91a]                          
02d6158c: cbnz    w8, #0x2d615a4                             
02d61590: adrp    x0, #0x6264000                             
02d61594: ldr     x0, [x0, #0xd8]                            T:UnityEngine.Vector3
02d61598: bl      #0x2b70db0                                 fn_2b70db0
02d6159c: mov     w8, #1                                     
02d615a0: strb    w8, [x22, #0x91a]                          
02d615a4: cbz     x20, #0x2d61658                            
02d615a8: ldr     x8, [x21]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d615ac: mov     x0, x20                                    
02d615b0: mov     x1, xzr                                    
02d615b4: ldr     x8, [x8, #0xb8]                            
02d615b8: ldp     s1, s2, [x8, #4]                           
02d615bc: ldr     s0, [x8]                                   
02d615c0: bl      #0x5b45cec                                 UnityEngine.Transform::set_localPosition
02d615c4: ldr     x8, [x19, #0x30]                           ._keycapObject
02d615c8: cbz     x8, #0x2d61658                             
02d615cc: ldr     x0, [x8, #0x30]                            
02d615d0: cbz     x0, #0x2d61658                             
02d615d4: ldr     x20, [x19, #0x50]                          ._glowSprite2DItem
02d615d8: mov     x1, xzr                                    
02d615dc: bl      #0x5ae6cfc                                 UnityEngine.SpriteRenderer::get_sprite
02d615e0: cbz     x20, #0x2d61658                            
02d615e4: mov     x1, x0                                     
02d615e8: ldr     x0, [x20, #0x28]                           [6263028]=0 f=0,0 ._btnFullEventTrigger
02d615ec: cbz     x0, #0x2d61658                             
02d615f0: str     x1, [x0, #0x58]!                           
02d615f4: bl      #0x2b70d54                                 fn_2b70d54
02d615f8: ldr     x0, [x19, #0x50]                           ._glowSprite2DItem
02d615fc: cbz     x0, #0x2d61658                             
02d61600: mov     x1, xzr                                    
02d61604: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02d61608: adrp    x20, #0x662f000                            
02d6160c: mov     x19, x0                                    
02d61610: ldrb    w8, [x20, #0xa74]                          
02d61614: cbnz    w8, #0x2d6162c                             
02d61618: adrp    x0, #0x6264000                             
02d6161c: ldr     x0, [x0, #0xd8]                            T:UnityEngine.Vector3
02d61620: bl      #0x2b70db0                                 fn_2b70db0
02d61624: mov     w8, #1                                     
02d61628: strb    w8, [x20, #0xa74]                          
02d6162c: cbz     x19, #0x2d61658                            
02d61630: ldr     x8, [x21]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d61634: mov     x0, x19                                    
02d61638: mov     x1, xzr                                    
02d6163c: ldp     x20, x19, [sp, #0x20]                      
02d61640: ldr     x8, [x8, #0xb8]                            
02d61644: ldp     x22, x21, [sp, #0x10]                      
02d61648: ldp     s0, s1, [x8, #0xc]                         
02d6164c: ldr     s2, [x8, #0x14]                            
02d61650: ldr     x30, [sp], #0x30                           
02d61654: b       #0x5b470cc                                 UnityEngine.Transform::set_localScale
02d61658: bl      #0x2b7105c                                 fn_2b7105c
## .ctor() -> void
---- Clicker.KeycapClick::.ctor 0x2d63c94
02d63c94: stp     x30, x21, [sp, #-0x20]!                    
02d63c98: stp     x20, x19, [sp, #0x10]                      
02d63c9c: adrp    x20, #0x6630000                            
02d63ca0: adrp    x21, #0x6267000                            
02d63ca4: mov     x19, x0                                    
02d63ca8: ldrb    w8, [x20, #0x310]                          
02d63cac: ldr     x21, [x21, #0xff0]                         T:UnityEngine.Events.UnityEvent
02d63cb0: tbnz    w8, #0, #0x2d63cc8                         
02d63cb4: adrp    x0, #0x6267000                             
02d63cb8: ldr     x0, [x0, #0xff0]                           T:UnityEngine.Events.UnityEvent
02d63cbc: bl      #0x2b70db0                                 fn_2b70db0
02d63cc0: mov     w8, #1                                     
02d63cc4: strb    w8, [x20, #0x310]                          
02d63cc8: ldr     x0, [x21]                                  S:'didu'
02d63ccc: bl      #0x2b7104c                                 fn_2b7104c
02d63cd0: mov     x1, xzr                                    
02d63cd4: mov     x20, x0                                    
02d63cd8: bl      #0x5b4d048                                 UnityEngine.Events.UnityEvent::.ctor
02d63cdc: mov     x0, x19                                    
02d63ce0: mov     x1, x20                                    
02d63ce4: str     x20, [x0, #0x38]!                          ._onSetupClick
02d63ce8: bl      #0x2b70d54                                 fn_2b70d54
02d63cec: mov     x0, x19                                    
02d63cf0: ldp     x20, x19, [sp, #0x10]                      
02d63cf4: mov     x1, xzr                                    
02d63cf8: ldp     x30, x21, [sp], #0x20                      
02d63cfc: b       #0x5b397b0                                 UnityEngine.MonoBehaviour::.ctor
## <Awake>b__7_0(UnityEngine.EventSystems.BaseEventData eventData) -> void
---- Clicker.KeycapClick::<Awake>b__7_0 0x2d63d00
02d63d00: b       #0x2d60624                                 Clicker.KeycapClick::HandleClick
## <HandleClick>b__12_0() -> void
---- Clicker.KeycapClick::<HandleClick>b__12_0 0x2d63d04
02d63d04: str     x30, [sp, #-0x10]!                         
02d63d08: ldr     x0, [x0, #0x30]                            ._keycapObject
02d63d0c: cbz     x0, #0x2d63d34                             
02d63d10: mov     x1, xzr                                    
02d63d14: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02d63d18: adrp    x8, #0x1084000                             
02d63d1c: movi    d0, #0000000000000000                      
02d63d20: mov     w1, wzr                                    
02d63d24: ldr     s1, [x8, #0xf40]                           [1084f40]=3f13cd3a3cf5c28f f=0.03,0.57735
02d63d28: mov     x2, xzr                                    
02d63d2c: ldr     x30, [sp], #0x10                           
02d63d30: b       #0x2d98060                                 DG.Tweening.ShortcutExtensions::DOLocalMoveY
02d63d34: bl      #0x2b7105c                                 fn_2b7105c
