#### CLASS CharmGame.LivestreamCharmScreen/<>c parent= object
#   field <>9                            CharmGame.LivestreamCharmScreen/<>c                off=0x0 attr=36 
#   field <>9__9_0                       DG.Tweening.TweenCallback                          off=0x8 attr=16 
## .cctor() -> void
---- CharmGame.LivestreamCharmScreen/<>c::.cctor 0x2d1dd50
02d1dd50: str     x30, [sp, #-0x20]!                         
02d1dd54: stp     x20, x19, [sp, #0x10]                      
02d1dd58: adrp    x19, #0x6630000                            
02d1dd5c: adrp    x20, #0x6269000                            
02d1dd60: ldrb    w8, [x19, #0x2c]                           
02d1dd64: ldr     x20, [x20, #0xce0]                         T:CharmGame.LivestreamCharmScreen/<>c
02d1dd68: tbnz    w8, #0, #0x2d1dd80                         
02d1dd6c: adrp    x0, #0x6269000                             
02d1dd70: ldr     x0, [x0, #0xce0]                           T:CharmGame.LivestreamCharmScreen/<>c
02d1dd74: bl      #0x2b70db0                                 fn_2b70db0
02d1dd78: mov     w8, #1                                     
02d1dd7c: strb    w8, [x19, #0x2c]                           
02d1dd80: ldr     x0, [x20]                                  T:Trading.TradingSession/<>c__DisplayClass56_0
02d1dd84: bl      #0x2b7104c                                 fn_2b7104c
02d1dd88: mov     x1, xzr                                    
02d1dd8c: mov     x19, x0                                    
02d1dd90: bl      #0x4e53e9c                                 System.Object::.ctor
02d1dd94: ldr     x8, [x20]                                  T:Trading.TradingSession/<>c__DisplayClass56_0
02d1dd98: mov     x1, x19                                    
02d1dd9c: ldr     x8, [x8, #0xb8]                            
02d1dda0: str     x19, [x8]                                  
02d1dda4: ldr     x8, [x20]                                  T:Trading.TradingSession/<>c__DisplayClass56_0
02d1dda8: ldp     x20, x19, [sp, #0x10]                      
02d1ddac: ldr     x0, [x8, #0xb8]                            
02d1ddb0: ldr     x30, [sp], #0x20                           
02d1ddb4: b       #0x2b70d54                                 
## .ctor() -> void
---- CharmGame.LivestreamCharmScreen/<>c::.ctor 0x2d1ddb8
02d1ddb8: mov     x1, xzr                                    
02d1ddbc: b       #0x4e53e9c                                 System.Object::.ctor
## <StartLive>b__9_0() -> void
---- CharmGame.LivestreamCharmScreen/<>c::<StartLive>b__9_0 0x2d1ddc0
02d1ddc0: ret                                                
#### CLASS CharmGame.LivestreamCharmScreen parent= ScreenBase
#   field _livestreamPanel               Livestream.LivestreamPanel                         off=0x38 attr=1 SerializeField
#   field _commentHandler                CommentHandler                                     off=0x40 attr=1 SerializeField
#   field _emojiFx                       UnityEngine.ParticleSystem                         off=0x48 attr=1 SerializeField
#   field _chatInput                     Livestream.ChatInput                               off=0x50 attr=1 SerializeField
#   field _countdownStartStream          CharmGame.CountDownStartStream                     off=0x58 attr=1 SerializeField
#   field _liveTime                      float                                              off=0x60 attr=1 
## get_CommentHandler() -> CommentHandler
---- CharmGame.LivestreamCharmScreen::get_CommentHandler 0x2d1d9e0
02d1d9e0: ldr     x0, [x0, #0x40]                            ._commentHandler
02d1d9e4: ret                                                
## OnInit(UIManager uiManager) -> void
---- CharmGame.LivestreamCharmScreen::OnInit 0x2d1d9e8
02d1d9e8: stp     x30, x19, [sp, #-0x10]!                    
02d1d9ec: mov     x2, xzr                                    
02d1d9f0: mov     x19, x0                                    
02d1d9f4: bl      #0x2cdd3c4                                 UIBase::OnInit
02d1d9f8: ldr     x0, [x19, #0x50]                           ._chatInput
02d1d9fc: cbz     x0, #0x2d1da1c                             
02d1da00: mov     x1, xzr                                    
02d1da04: bl      #0x2d11580                                 Livestream.ChatInput::OnInit
02d1da08: ldr     x0, [x19, #0x38]                           ._livestreamPanel
02d1da0c: cbz     x0, #0x2d1da1c                             
02d1da10: mov     x1, xzr                                    
02d1da14: ldp     x30, x19, [sp], #0x10                      
02d1da18: b       #0x2d11b9c                                 Livestream.LivestreamPanel::Initialized
02d1da1c: bl      #0x2b7105c                                 fn_2b7105c
## StartLive() -> void
---- CharmGame.LivestreamCharmScreen::StartLive 0x2d1da20
02d1da20: str     d8, [sp, #-0x30]!                          
02d1da24: stp     x30, x21, [sp, #0x10]                      
02d1da28: stp     x20, x19, [sp, #0x20]                      
02d1da2c: adrp    x20, #0x6630000                            
02d1da30: mov     x19, x0                                    
02d1da34: ldrb    w8, [x20, #0x2a]                           
02d1da38: tbnz    w8, #0, #0x2d1da80                         
02d1da3c: adrp    x0, #0x6267000                             
02d1da40: ldr     x0, [x0, #0xd50]                           MS:MonoSingleton`1::get_Instance
02d1da44: bl      #0x2b70db0                                 fn_2b70db0
02d1da48: adrp    x0, #0x6263000                             
02d1da4c: ldr     x0, [x0, #0x918]                           T:UnityEngine.Object
02d1da50: bl      #0x2b70db0                                 fn_2b70db0
02d1da54: adrp    x0, #0x6264000                             
02d1da58: ldr     x0, [x0, #0xe8]                            T:DG.Tweening.TweenCallback
02d1da5c: bl      #0x2b70db0                                 fn_2b70db0
02d1da60: adrp    x0, #0x6269000                             
02d1da64: ldr     x0, [x0, #0xcd8]                           M:CharmGame.LivestreamCharmScreen/<>c::<StartLive>b__9_0
02d1da68: bl      #0x2b70db0                                 fn_2b70db0
02d1da6c: adrp    x0, #0x6269000                             
02d1da70: ldr     x0, [x0, #0xce0]                           T:CharmGame.LivestreamCharmScreen/<>c
02d1da74: bl      #0x2b70db0                                 fn_2b70db0
02d1da78: mov     w8, #1                                     
02d1da7c: strb    w8, [x20, #0x2a]                           
02d1da80: mov     x0, xzr                                    
02d1da84: bl      #0x2d6eec8                                 Framework.AudioManager::get_Instance
02d1da88: cbz     x0, #0x2d1dbe0                             
02d1da8c: movi    d1, #0000000000000000                      
02d1da90: movi    d2, #0000000000000000                      
02d1da94: adrp    x20, #0x6267000                            
02d1da98: fmov    s0, #1.00000000                            
02d1da9c: ldr     x20, [x20, #0xd50]                         MS:MonoSingleton`1::get_Instance
02d1daa0: mov     w1, #1                                     
02d1daa4: mov     w2, wzr                                    
02d1daa8: mov     w3, wzr                                    
02d1daac: mov     x4, xzr                                    
02d1dab0: bl      #0x2d6f03c                                 Framework.AudioManager::PlaySound
02d1dab4: ldr     x0, [x20]                                  S:'didu'
02d1dab8: bl      #0x3769600                                 fn_3769600
02d1dabc: cbz     x0, #0x2d1dbe0                             
02d1dac0: adrp    x20, #0x6263000                            
02d1dac4: mov     w1, #4                                     
02d1dac8: mov     x2, xzr                                    
02d1dacc: ldr     x20, [x20, #0x918]                         T:UnityEngine.Object
02d1dad0: bl      #0x2cc6ee0                                 Framework.VibrationManager::Haptic
02d1dad4: ldr     x0, [x20]                                  &2c5bbd4(=a9bd7bfdd503233f)
02d1dad8: ldr     x20, [x19, #0x48]                          ._emojiFx
02d1dadc: ldr     w8, [x0, #0xe4]                            [62690e4]=0 f=0,0
02d1dae0: cbnz    w8, #0x2d1dae8                             
02d1dae4: bl      #0x2b70f30                                 fn_2b70f30
02d1dae8: mov     x0, x20                                    
02d1daec: mov     x1, xzr                                    
02d1daf0: mov     x2, xzr                                    
02d1daf4: bl      #0x5b3666c                                 UnityEngine.Object::op_Inequality
02d1daf8: tbz     w0, #0, #0x2d1db0c                         
02d1dafc: ldr     x0, [x19, #0x48]                           ._emojiFx
02d1db00: cbz     x0, #0x2d1dbe0                             
02d1db04: mov     x1, xzr                                    
02d1db08: bl      #0x5bba8cc                                 UnityEngine.ParticleSystem::Play
02d1db0c: ldr     x0, [x19, #0x50]                           ._chatInput
02d1db10: cbz     x0, #0x2d1dbe0                             
02d1db14: mov     x1, xzr                                    
02d1db18: bl      #0x5b339ec                                 UnityEngine.Component::get_gameObject
02d1db1c: cbz     x0, #0x2d1dbe0                             
02d1db20: mov     w1, #1                                     
02d1db24: mov     x2, xzr                                    
02d1db28: mov     w20, #1                                    
02d1db2c: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d1db30: ldr     x8, [x19, #0x40]                           ._commentHandler
02d1db34: cbz     x8, #0x2d1dbe0                             
02d1db38: adrp    x21, #0x6269000                            
02d1db3c: ldr     x21, [x21, #0xce0]                         T:CharmGame.LivestreamCharmScreen/<>c
02d1db40: ldr     s8, [x19, #0x60]                           ._liveTime
02d1db44: strb    w20, [x8, #0x20]                           
02d1db48: ldr     x0, [x21]                                  T:Trading.TradingSession/<>c__DisplayClass56_0
02d1db4c: ldr     w9, [x0, #0xe4]                            [62690e4]=0 f=0,0
02d1db50: cbnz    w9, #0x2d1db5c                             
02d1db54: bl      #0x2b70f30                                 fn_2b70f30
02d1db58: ldr     x0, [x21]                                  T:Trading.TradingSession/<>c__DisplayClass56_0
02d1db5c: ldr     x8, [x0, #0xb8]                            T:Trading.TradingSession/<>c__DisplayClass68_0
02d1db60: ldr     x19, [x8, #8]                              
02d1db64: cbnz    x19, #0x2d1dbc0                            
02d1db68: ldr     w9, [x0, #0xe4]                            [62690e4]=0 f=0,0
02d1db6c: cbnz    w9, #0x2d1db7c                             
02d1db70: bl      #0x2b70f30                                 fn_2b70f30
02d1db74: ldr     x8, [x21]                                  T:Trading.TradingSession/<>c__DisplayClass56_0
02d1db78: ldr     x8, [x8, #0xb8]                            
02d1db7c: adrp    x9, #0x6264000                             
02d1db80: ldr     x9, [x9, #0xe8]                            T:DG.Tweening.TweenCallback
02d1db84: ldr     x20, [x8]                                  
02d1db88: ldr     x0, [x9]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d1db8c: bl      #0x2b7104c                                 fn_2b7104c
02d1db90: adrp    x8, #0x6269000                             
02d1db94: mov     x1, x20                                    
02d1db98: mov     x3, xzr                                    
02d1db9c: ldr     x8, [x8, #0xcd8]                           M:CharmGame.LivestreamCharmScreen/<>c::<StartLive>b__9_0
02d1dba0: mov     x19, x0                                    
02d1dba4: ldr     x2, [x8]                                   T:Trading.TradingSession/<>c__DisplayClass56_0
02d1dba8: bl      #0x2d89dc4                                 DG.Tweening.TweenCallback::.ctor
02d1dbac: ldr     x8, [x21]                                  T:Trading.TradingSession/<>c__DisplayClass56_0
02d1dbb0: mov     x1, x19                                    
02d1dbb4: ldr     x0, [x8, #0xb8]                            T:Trading.TradingSession/<>c__DisplayClass68_0
02d1dbb8: str     x19, [x0, #8]!                             
02d1dbbc: bl      #0x2b70d54                                 fn_2b70d54
02d1dbc0: mov     x0, x19                                    
02d1dbc4: ldp     x20, x19, [sp, #0x20]                      
02d1dbc8: ldp     x30, x21, [sp, #0x10]                      
02d1dbcc: fmov    s0, s8                                     
02d1dbd0: mov     w1, #1                                     
02d1dbd4: mov     x2, xzr                                    
02d1dbd8: ldr     d8, [sp], #0x30                            
02d1dbdc: b       #0x2d8f37c                                 DG.Tweening.DOVirtual::DelayedCall
02d1dbe0: bl      #0x2b7105c                                 fn_2b7105c
## OnShow() -> void
---- CharmGame.LivestreamCharmScreen::OnShow 0x2d1dbe4
02d1dbe4: str     x30, [sp, #-0x30]!                         
02d1dbe8: stp     x22, x21, [sp, #0x10]                      
02d1dbec: stp     x20, x19, [sp, #0x20]                      
02d1dbf0: adrp    x20, #0x6630000                            
02d1dbf4: mov     x19, x0                                    
02d1dbf8: ldrb    w8, [x20, #0x2b]                           
02d1dbfc: tbnz    w8, #0, #0x2d1dc2c                         
02d1dc00: adrp    x0, #0x6264000                             
02d1dc04: ldr     x0, [x0, #0xf90]                           T:System.Action
02d1dc08: bl      #0x2b70db0                                 fn_2b70db0
02d1dc0c: adrp    x0, #0x6269000                             
02d1dc10: ldr     x0, [x0, #0xce8]                           M:CharmGame.LivestreamCharmScreen::StartLive
02d1dc14: bl      #0x2b70db0                                 fn_2b70db0
02d1dc18: adrp    x0, #0x6263000                             
02d1dc1c: ldr     x0, [x0, #0x918]                           T:UnityEngine.Object
02d1dc20: bl      #0x2b70db0                                 fn_2b70db0
02d1dc24: mov     w8, #1                                     
02d1dc28: strb    w8, [x20, #0x2b]                           
02d1dc2c: ldr     x0, [x19, #0x50]                           ._chatInput
02d1dc30: cbz     x0, #0x2d1dce4                             
02d1dc34: mov     x1, xzr                                    
02d1dc38: bl      #0x5b339ec                                 UnityEngine.Component::get_gameObject
02d1dc3c: cbz     x0, #0x2d1dce4                             
02d1dc40: adrp    x20, #0x6263000                            
02d1dc44: mov     w1, wzr                                    
02d1dc48: mov     x2, xzr                                    
02d1dc4c: ldr     x20, [x20, #0x918]                         T:UnityEngine.Object
02d1dc50: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d1dc54: ldr     x0, [x20]                                  &2c5bbd4(=a9bd7bfdd503233f)
02d1dc58: ldr     x20, [x19, #0x38]                          ._livestreamPanel
02d1dc5c: ldr     w8, [x0, #0xe4]                            [62630e4]=0 f=0,0
02d1dc60: cbnz    w8, #0x2d1dc68                             
02d1dc64: bl      #0x2b70f30                                 fn_2b70f30
02d1dc68: adrp    x22, #0x6264000                            
02d1dc6c: adrp    x21, #0x6269000                            
02d1dc70: mov     x0, x20                                    
02d1dc74: ldr     x22, [x22, #0xf90]                         T:System.Action
02d1dc78: ldr     x21, [x21, #0xce8]                         M:CharmGame.LivestreamCharmScreen::StartLive
02d1dc7c: mov     x1, xzr                                    
02d1dc80: mov     x2, xzr                                    
02d1dc84: bl      #0x5b3666c                                 UnityEngine.Object::op_Inequality
02d1dc88: tbz     w0, #0, #0x2d1dc9c                         
02d1dc8c: ldr     x0, [x19, #0x38]                           ._livestreamPanel
02d1dc90: cbz     x0, #0x2d1dc9c                             
02d1dc94: mov     x1, xzr                                    
02d1dc98: bl      #0x2d11ba0                                 Livestream.LivestreamPanel::OnShow
02d1dc9c: mov     x0, x19                                    
02d1dca0: mov     x1, xzr                                    
02d1dca4: bl      #0x2cdd6b8                                 UIBase::OnShow
02d1dca8: ldr     x0, [x22]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d1dcac: ldr     x20, [x19, #0x58]                          ._countdownStartStream
02d1dcb0: bl      #0x2b7104c                                 fn_2b7104c
02d1dcb4: ldr     x2, [x21]                                  T:Trading.TradingSession/<>c__DisplayClass56_0
02d1dcb8: mov     x1, x19                                    
02d1dcbc: mov     x3, xzr                                    
02d1dcc0: mov     x21, x0                                    
02d1dcc4: bl      #0x4d8ddbc                                 System.Action::.ctor
02d1dcc8: cbz     x20, #0x2d1dce4                            
02d1dccc: mov     x0, x20                                    
02d1dcd0: mov     x1, x21                                    
02d1dcd4: ldp     x20, x19, [sp, #0x20]                      
02d1dcd8: ldp     x22, x21, [sp, #0x10]                      
02d1dcdc: ldr     x30, [sp], #0x30                           
02d1dce0: b       #0x2d1d2a4                                 CharmGame.CountDownStartStream::StartCountDown
02d1dce4: bl      #0x2b7105c                                 fn_2b7105c
## OnHide() -> void
---- CharmGame.LivestreamCharmScreen::OnHide 0x2d1dce8
02d1dce8: stp     x30, x19, [sp, #-0x10]!                    
02d1dcec: mov     x1, xzr                                    
02d1dcf0: mov     x19, x0                                    
02d1dcf4: bl      #0x2cddc10                                 UIBase::OnHide
02d1dcf8: ldr     x0, [x19, #0x38]                           ._livestreamPanel
02d1dcfc: cbz     x0, #0x2d1dd3c                             
02d1dd00: mov     x1, xzr                                    
02d1dd04: bl      #0x2d11cdc                                 Livestream.LivestreamPanel::OnHide
02d1dd08: ldr     x0, [x19, #0x48]                           ._emojiFx
02d1dd0c: cbz     x0, #0x2d1dd3c                             
02d1dd10: mov     x1, xzr                                    
02d1dd14: bl      #0x5bba9c0                                 UnityEngine.ParticleSystem::Stop
02d1dd18: ldr     x0, [x19, #0x48]                           ._emojiFx
02d1dd1c: cbz     x0, #0x2d1dd3c                             
02d1dd20: mov     x1, xzr                                    
02d1dd24: bl      #0x5bbaa90                                 UnityEngine.ParticleSystem::Clear
02d1dd28: ldr     x8, [x19, #0x40]                           ._commentHandler
02d1dd2c: cbz     x8, #0x2d1dd3c                             
02d1dd30: strb    wzr, [x8, #0x20]                           
02d1dd34: ldp     x30, x19, [sp], #0x10                      
02d1dd38: ret                                                
02d1dd3c: bl      #0x2b7105c                                 fn_2b7105c
## .ctor() -> void
---- CharmGame.LivestreamCharmScreen::.ctor 0x2d1dd40
02d1dd40: mov     w8, #0x41200000                            
02d1dd44: mov     x1, xzr                                    
02d1dd48: str     w8, [x0, #0x60]                            ._liveTime
02d1dd4c: b       #0x2cde678                                 ScreenBase::.ctor
