#### CLASS Livestream.ItemGift parent= UnityEngine.MonoBehaviour
#   field _icon                          UnityEngine.UI.Image                               off=0x20 attr=1 SerializeField
## SetIcon(UnityEngine.Sprite icon) -> Livestream.ItemGift
---- Livestream.ItemGift::SetIcon 0x2d11a58
02d11a58: stp     x30, x19, [sp, #-0x10]!                    
02d11a5c: mov     x19, x0                                    
02d11a60: ldr     x0, [x0, #0x20]                            ._icon
02d11a64: cbz     x0, #0x2d11a7c                             
02d11a68: mov     x2, xzr                                    
02d11a6c: bl      #0x5c45aa0                                 UnityEngine.UI.Image::set_sprite
02d11a70: mov     x0, x19                                    
02d11a74: ldp     x30, x19, [sp], #0x10                      
02d11a78: ret                                                
02d11a7c: bl      #0x2b7105c                                 fn_2b7105c
## StartShowEffect() -> Livestream.ItemGift
---- Livestream.ItemGift::StartShowEffect 0x2d11a80
02d11a80: str     x30, [sp, #-0x30]!                         
02d11a84: stp     x22, x21, [sp, #0x10]                      
02d11a88: stp     x20, x19, [sp, #0x20]                      
02d11a8c: mov     x1, xzr                                    
02d11a90: mov     x19, x0                                    
02d11a94: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02d11a98: mov     w1, wzr                                    
02d11a9c: mov     x2, xzr                                    
02d11aa0: bl      #0x2d9d5d0                                 DG.Tweening.ShortcutExtensions::DOKill
02d11aa4: mov     x0, x19                                    
02d11aa8: mov     x1, xzr                                    
02d11aac: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02d11ab0: adrp    x21, #0x662f000                            
02d11ab4: mov     x20, x0                                    
02d11ab8: ldrb    w8, [x21, #0xa74]                          
02d11abc: cbnz    w8, #0x2d11ad4                             
02d11ac0: adrp    x0, #0x6264000                             
02d11ac4: ldr     x0, [x0, #0xd8]                            T:UnityEngine.Vector3
02d11ac8: bl      #0x2b70db0                                 fn_2b70db0
02d11acc: mov     w8, #1                                     
02d11ad0: strb    w8, [x21, #0xa74]                          
02d11ad4: cbz     x20, #0x2d11b88                            
02d11ad8: adrp    x22, #0x6264000                            
02d11adc: mov     x0, x20                                    
02d11ae0: mov     x1, xzr                                    
02d11ae4: ldr     x22, [x22, #0xd8]                          T:UnityEngine.Vector3
02d11ae8: ldr     x8, [x22]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d11aec: ldr     x8, [x8, #0xb8]                            
02d11af0: ldp     s1, s2, [x8, #0x10]                        
02d11af4: ldr     s0, [x8, #0xc]                             
02d11af8: bl      #0x5b470cc                                 UnityEngine.Transform::set_localScale
02d11afc: mov     x0, x19                                    
02d11b00: mov     x1, xzr                                    
02d11b04: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02d11b08: ldrb    w8, [x21, #0xa74]                          
02d11b0c: mov     x20, x0                                    
02d11b10: cbnz    w8, #0x2d11b28                             
02d11b14: adrp    x0, #0x6264000                             
02d11b18: ldr     x0, [x0, #0xd8]                            T:UnityEngine.Vector3
02d11b1c: bl      #0x2b70db0                                 fn_2b70db0
02d11b20: mov     w8, #1                                     
02d11b24: strb    w8, [x21, #0xa74]                          
02d11b28: ldr     x8, [x22]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d11b2c: mov     w9, #0xcccd                                
02d11b30: fmov    s4, #1.00000000                            
02d11b34: movk    w9, #0x3dcc, lsl #16                       
02d11b38: mov     x0, x20                                    
02d11b3c: mov     w1, #0xa                                   
02d11b40: ldr     x8, [x8, #0xb8]                            
02d11b44: dup     v0.2s, w9                                  
02d11b48: adrp    x9, #0x1084000                             
02d11b4c: ldr     s2, [x9, #0xeec]                           [1084eec]=457ff0003dcccccd f=0.1,4095
02d11b50: mov     x2, xzr                                    
02d11b54: ldur    d1, [x8, #0xc]                             
02d11b58: fmul    v0.2s, v1.2s, v0.2s                        
02d11b5c: ldr     s1, [x8, #0x14]                            
02d11b60: adrp    x8, #0x1084000                             
02d11b64: ldr     s3, [x8, #0xdd8]                           [1084dd8]=3f7333333e4ccccd f=0.2,0.95
02d11b68: fmul    s2, s1, s2                                 
02d11b6c: mov     s1, v0.s[1]                                
02d11b70: bl      #0x2d9982c                                 DG.Tweening.ShortcutExtensions::DOPunchScale
02d11b74: mov     x0, x19                                    
02d11b78: ldp     x20, x19, [sp, #0x20]                      
02d11b7c: ldp     x22, x21, [sp, #0x10]                      
02d11b80: ldr     x30, [sp], #0x30                           
02d11b84: ret                                                
02d11b88: bl      #0x2b7105c                                 fn_2b7105c
## .ctor() -> void
---- Livestream.ItemGift::.ctor 0x2d11b8c
02d11b8c: mov     x1, xzr                                    
02d11b90: b       #0x5b397b0                                 UnityEngine.MonoBehaviour::.ctor
