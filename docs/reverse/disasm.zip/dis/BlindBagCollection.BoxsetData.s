#### CLASS BlindBagCollection.BoxsetData parent= object
#   field BoxsetType                     BlindBagCollection.CollectionBoxsetType            off=0x10 attr=6 
#   field ItemTypes                      System.Collections.Generic.List`1<BlindBagCollection.CollectionItemType> off=0x18 attr=6 
## .ctor() -> void
---- BlindBagCollection.BoxsetData::.ctor 0x2d364c4
02d364c4: mov     x1, xzr                                    
02d364c8: b       #0x4e53e9c                                 System.Object::.ctor
