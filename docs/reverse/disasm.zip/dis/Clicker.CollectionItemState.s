#### CLASS Clicker.CollectionItemState parent= int
#   field value__                        int                                                off=0x10 attr=606 
#   field Available                      Clicker.CollectionItemState                        off=0x0 attr=8056 
#   field Locked                         Clicker.CollectionItemState                        off=0x0 attr=8056 
#   field CanInspect                     Clicker.CollectionItemState                        off=0x0 attr=8056 
