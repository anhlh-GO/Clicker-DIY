#### CLASS MoneyManager/<>c__DisplayClass20_0 parent= object
#   field oldMoney                       int                                                off=0x10 attr=6 
#   field <>4__this                      MoneyManager                                       off=0x18 attr=6 
## .ctor() -> void
---- MoneyManager/<>c__DisplayClass20_0::.ctor 0x2cdaf28
02cdaf28: mov     x1, xzr                                    
02cdaf2c: b       #0x4e53e9c                                 System.Object::.ctor
## <UpdateMoney>b__0() -> int
---- MoneyManager/<>c__DisplayClass20_0::<UpdateMoney>b__0 0x2cdb364
02cdb364: ldr     w0, [x0, #0x10]                            .oldMoney
02cdb368: ret                                                
## <UpdateMoney>b__1(int x) -> void
---- MoneyManager/<>c__DisplayClass20_0::<UpdateMoney>b__1 0x2cdb36c
02cdb36c: str     x30, [sp, #-0x20]!                         
02cdb370: stp     x20, x19, [sp, #0x10]                      
02cdb374: adrp    x20, #0x662f000                            
02cdb378: mov     x19, x0                                    
02cdb37c: str     w1, [sp, #0xc]                             
02cdb380: ldrb    w8, [x20, #0xd5d]                          
02cdb384: tbnz    w8, #0, #0x2cdb39c                         
02cdb388: adrp    x0, #0x6264000                             
02cdb38c: ldr     x0, [x0, #0x7a0]                           S:'N0'
02cdb390: bl      #0x2b70db0                                 fn_2b70db0
02cdb394: mov     w8, #1                                     
02cdb398: strb    w8, [x20, #0xd5d]                          
02cdb39c: ldr     x8, [x19, #0x18]                           .<>4__this
02cdb3a0: cbz     x8, #0x2cdb3e8                             
02cdb3a4: adrp    x9, #0x6264000                             
02cdb3a8: add     x0, sp, #0xc                               
02cdb3ac: mov     x2, xzr                                    
02cdb3b0: ldr     x9, [x9, #0x7a0]                           S:'N0'
02cdb3b4: ldr     x19, [x8, #0x28]                           
02cdb3b8: ldr     x1, [x9]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02cdb3bc: bl      #0x4e0ead0                                 System.Int32::ToString
02cdb3c0: cbz     x19, #0x2cdb3e8                            
02cdb3c4: ldr     x8, [x19]                                  
02cdb3c8: mov     x1, x0                                     
02cdb3cc: mov     x0, x19                                    
02cdb3d0: ldr     x9, [x8, #0x558]                           
02cdb3d4: ldr     x2, [x8, #0x560]                           
02cdb3d8: blr     x9                                         
02cdb3dc: ldp     x20, x19, [sp, #0x10]                      
02cdb3e0: ldr     x30, [sp], #0x20                           
02cdb3e4: ret                                                
02cdb3e8: bl      #0x2b7105c                                 fn_2b7105c
#### CLASS MoneyManager/<>c__DisplayClass21_0 parent= object
#   field <>4__this                      MoneyManager                                       off=0x10 attr=6 
#   field money                          int                                                off=0x18 attr=6 
#   field <>9__1                         DG.Tweening.TweenCallback                          off=0x20 attr=6 
## .ctor() -> void
---- MoneyManager/<>c__DisplayClass21_0::.ctor 0x2cdb0d8
02cdb0d8: mov     x1, xzr                                    
02cdb0dc: b       #0x4e53e9c                                 System.Object::.ctor
## <CollectMoney>b__0() -> void
---- MoneyManager/<>c__DisplayClass21_0::<CollectMoney>b__0 0x2cdb3ec
02cdb3ec: str     x30, [sp, #-0x30]!                         
02cdb3f0: stp     x22, x21, [sp, #0x10]                      
02cdb3f4: stp     x20, x19, [sp, #0x20]                      
02cdb3f8: adrp    x20, #0x662f000                            
02cdb3fc: mov     x19, x0                                    
02cdb400: ldrb    w8, [x20, #0xd5e]                          
02cdb404: tbnz    w8, #0, #0x2cdb428                         
02cdb408: adrp    x0, #0x6264000                             
02cdb40c: ldr     x0, [x0, #0xe8]                            T:DG.Tweening.TweenCallback
02cdb410: bl      #0x2b70db0                                 fn_2b70db0
02cdb414: adrp    x0, #0x6267000                             
02cdb418: ldr     x0, [x0, #0xbf8]                           M:MoneyManager/<>c__DisplayClass21_0::<CollectMoney>b__1
02cdb41c: bl      #0x2b70db0                                 fn_2b70db0
02cdb420: mov     w8, #1                                     
02cdb424: strb    w8, [x20, #0xd5e]                          
02cdb428: ldr     x0, [x19, #0x10]                           .<>4__this
02cdb42c: cbz     x0, #0x2cdb4b8                             
02cdb430: ldr     w1, [x19, #0x18]                           .money
02cdb434: bl      #0x2cdac78                                 MoneyManager::UpdateMoney
02cdb438: mov     x21, x19                                   
02cdb43c: ldr     x22, [x21, #0x20]!                         .<>9__1
02cdb440: ldur    x20, [x21, #-0x10]                         
02cdb444: cbnz    x22, #0x2cdb484                            
02cdb448: adrp    x8, #0x6264000                             
02cdb44c: ldr     x8, [x8, #0xe8]                            T:DG.Tweening.TweenCallback
02cdb450: ldr     x0, [x8]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02cdb454: bl      #0x2b7104c                                 fn_2b7104c
02cdb458: adrp    x8, #0x6267000                             
02cdb45c: mov     x1, x19                                    
02cdb460: mov     x3, xzr                                    
02cdb464: ldr     x8, [x8, #0xbf8]                           M:MoneyManager/<>c__DisplayClass21_0::<CollectMoney>b__1
02cdb468: mov     x22, x0                                    
02cdb46c: ldr     x2, [x8]                                   S:'didu'
02cdb470: bl      #0x2d89dc4                                 DG.Tweening.TweenCallback::.ctor
02cdb474: mov     x0, x21                                    
02cdb478: mov     x1, x22                                    
02cdb47c: str     x22, [x19, #0x20]                          .<>9__1
02cdb480: bl      #0x2b70d54                                 fn_2b70d54
02cdb484: fmov    s0, #2.00000000                            
02cdb488: mov     x0, x22                                    
02cdb48c: mov     w1, #1                                     
02cdb490: mov     x2, xzr                                    
02cdb494: bl      #0x2d8f37c                                 DG.Tweening.DOVirtual::DelayedCall
02cdb498: cbz     x20, #0x2cdb4b8                            
02cdb49c: str     x0, [x20, #0x50]!                          
02cdb4a0: mov     x1, x0                                     
02cdb4a4: mov     x0, x20                                    
02cdb4a8: ldp     x20, x19, [sp, #0x20]                      
02cdb4ac: ldp     x22, x21, [sp, #0x10]                      
02cdb4b0: ldr     x30, [sp], #0x30                           
02cdb4b4: b       #0x2b70d54                                 
02cdb4b8: bl      #0x2b7105c                                 fn_2b7105c
## <CollectMoney>b__1() -> void
---- MoneyManager/<>c__DisplayClass21_0::<CollectMoney>b__1 0x2cdb4bc
02cdb4bc: stp     x30, x19, [sp, #-0x10]!                    
02cdb4c0: mov     x19, x0                                    
02cdb4c4: ldr     x0, [x0, #0x10]                            .<>4__this
02cdb4c8: cbz     x0, #0x2cdb538                             
02cdb4cc: ldr     x8, [x0, #0x58]                            
02cdb4d0: cbz     x8, #0x2cdb4ec                             
02cdb4d4: ldr     x9, [x8, #0x18]                            
02cdb4d8: ldr     x0, [x8, #0x40]                            
02cdb4dc: ldr     x1, [x8, #0x28]                            
02cdb4e0: blr     x9                                         
02cdb4e4: ldr     x0, [x19, #0x10]                           .<>4__this
02cdb4e8: cbz     x0, #0x2cdb538                             
02cdb4ec: mov     x1, xzr                                    
02cdb4f0: str     xzr, [x0, #0x58]!                          
02cdb4f4: bl      #0x2b70d54                                 fn_2b70d54
02cdb4f8: ldr     x0, [x19, #0x10]                           .<>4__this
02cdb4fc: cbz     x0, #0x2cdb538                             
02cdb500: mov     x1, xzr                                    
02cdb504: str     xzr, [x0, #0x50]!                          
02cdb508: bl      #0x2b70d54                                 fn_2b70d54
02cdb50c: ldr     x0, [x19, #0x10]                           .<>4__this
02cdb510: cbz     x0, #0x2cdb538                             
02cdb514: mov     x1, xzr                                    
02cdb518: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02cdb51c: ldr     x8, [x19, #0x10]                           .<>4__this
02cdb520: cbz     x8, #0x2cdb538                             
02cdb524: cbz     x0, #0x2cdb538                             
02cdb528: ldr     x1, [x8, #0x48]                            
02cdb52c: mov     x2, xzr                                    
02cdb530: ldp     x30, x19, [sp], #0x10                      
02cdb534: b       #0x5b472ec                                 UnityEngine.Transform::SetParent
02cdb538: bl      #0x2b7105c                                 fn_2b7105c
#### CLASS MoneyManager/<>c__DisplayClass22_0 parent= object
#   field <>4__this                      MoneyManager                                       off=0x10 attr=6 
#   field money                          int                                                off=0x18 attr=6 
#   field onCompleted                    System.Action                                      off=0x20 attr=6 
#   field <>9__1                         DG.Tweening.TweenCallback                          off=0x28 attr=6 
## .ctor() -> void
---- MoneyManager/<>c__DisplayClass22_0::.ctor 0x2cdb264
02cdb264: mov     x1, xzr                                    
02cdb268: b       #0x4e53e9c                                 System.Object::.ctor
## <CollectMoney>b__0() -> void
---- MoneyManager/<>c__DisplayClass22_0::<CollectMoney>b__0 0x2cdb53c
02cdb53c: stp     x30, x21, [sp, #-0x20]!                    
02cdb540: stp     x20, x19, [sp, #0x10]                      
02cdb544: adrp    x20, #0x662f000                            
02cdb548: mov     x19, x0                                    
02cdb54c: ldrb    w8, [x20, #0xd5f]                          
02cdb550: tbnz    w8, #0, #0x2cdb574                         
02cdb554: adrp    x0, #0x6264000                             
02cdb558: ldr     x0, [x0, #0xe8]                            T:DG.Tweening.TweenCallback
02cdb55c: bl      #0x2b70db0                                 fn_2b70db0
02cdb560: adrp    x0, #0x6267000                             
02cdb564: ldr     x0, [x0, #0xc00]                           M:MoneyManager/<>c__DisplayClass22_0::<CollectMoney>b__1
02cdb568: bl      #0x2b70db0                                 fn_2b70db0
02cdb56c: mov     w8, #1                                     
02cdb570: strb    w8, [x20, #0xd5f]                          
02cdb574: ldr     x0, [x19, #0x10]                           .<>4__this
02cdb578: cbz     x0, #0x2cdb5e8                             
02cdb57c: ldr     w1, [x19, #0x18]                           .money
02cdb580: bl      #0x2cdac78                                 MoneyManager::UpdateMoney
02cdb584: mov     x20, x19                                   
02cdb588: ldr     x21, [x20, #0x28]!                         [662f028]=6000015 f=2.40742e-35,0 .<>9__1
02cdb58c: cbnz    x21, #0x2cdb5cc                            
02cdb590: adrp    x8, #0x6264000                             
02cdb594: ldr     x8, [x8, #0xe8]                            T:DG.Tweening.TweenCallback
02cdb598: ldr     x0, [x8]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02cdb59c: bl      #0x2b7104c                                 fn_2b7104c
02cdb5a0: adrp    x8, #0x6267000                             
02cdb5a4: mov     x1, x19                                    
02cdb5a8: mov     x3, xzr                                    
02cdb5ac: ldr     x8, [x8, #0xc00]                           M:MoneyManager/<>c__DisplayClass22_0::<CollectMoney>b__1
02cdb5b0: mov     x21, x0                                    
02cdb5b4: ldr     x2, [x8]                                   S:'didu'
02cdb5b8: bl      #0x2d89dc4                                 DG.Tweening.TweenCallback::.ctor
02cdb5bc: mov     x0, x20                                    
02cdb5c0: mov     x1, x21                                    
02cdb5c4: str     x21, [x19, #0x28]                          .<>9__1
02cdb5c8: bl      #0x2b70d54                                 fn_2b70d54
02cdb5cc: ldp     x20, x19, [sp, #0x10]                      
02cdb5d0: fmov    s0, #2.00000000                            
02cdb5d4: mov     x0, x21                                    
02cdb5d8: mov     w1, #1                                     
02cdb5dc: mov     x2, xzr                                    
02cdb5e0: ldp     x30, x21, [sp], #0x20                      
02cdb5e4: b       #0x2d8f37c                                 DG.Tweening.DOVirtual::DelayedCall
02cdb5e8: bl      #0x2b7105c                                 fn_2b7105c
## <CollectMoney>b__1() -> void
---- MoneyManager/<>c__DisplayClass22_0::<CollectMoney>b__1 0x2cdb5ec
02cdb5ec: stp     x30, x19, [sp, #-0x10]!                    
02cdb5f0: ldr     x8, [x0, #0x20]                            .onCompleted
02cdb5f4: mov     x19, x0                                    
02cdb5f8: cbz     x8, #0x2cdb60c                             
02cdb5fc: ldr     x9, [x8, #0x18]                            
02cdb600: ldr     x0, [x8, #0x40]                            
02cdb604: ldr     x1, [x8, #0x28]                            
02cdb608: blr     x9                                         
02cdb60c: ldr     x0, [x19, #0x10]                           .<>4__this
02cdb610: cbz     x0, #0x2cdb638                             
02cdb614: mov     x1, xzr                                    
02cdb618: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02cdb61c: ldr     x8, [x19, #0x10]                           .<>4__this
02cdb620: cbz     x8, #0x2cdb638                             
02cdb624: cbz     x0, #0x2cdb638                             
02cdb628: ldr     x1, [x8, #0x48]                            
02cdb62c: mov     x2, xzr                                    
02cdb630: ldp     x30, x19, [sp], #0x10                      
02cdb634: b       #0x5b472ec                                 UnityEngine.Transform::SetParent
02cdb638: bl      #0x2b7105c                                 fn_2b7105c
#### CLASS MoneyManager parent= MonoSingleton`1<MoneyManager>
#   field OnMoneyChanged                 UnityEngine.Events.UnityAction                     off=0x0 attr=11 CompilerGeneratedAttribute
#   field _canvasGroup                   UnityEngine.CanvasGroup                            off=0x20 attr=1 SerializeField
#   field _moneyText                     TMPro.TextMeshProUGUI                              off=0x28 attr=1 SerializeField
#   field _collectingCoin                JobGame.CollectingCoin                             off=0x30 attr=1 SerializeField
#   field _moneyItem                     Home.MoneyItem                                     off=0x38 attr=1 SerializeField
#   field _money                         int                                                off=0x40 attr=1 
#   field _defaultParent                 UnityEngine.Transform                              off=0x48 attr=1 
#   field _delayCallback                 DG.Tweening.Tween                                  off=0x50 attr=1 
#   field _onCompleted                   System.Action                                      off=0x58 attr=1 
## add_OnMoneyChanged(UnityEngine.Events.UnityAction value) -> void
---- MoneyManager::add_OnMoneyChanged 0x2cda8a8
02cda8a8: str     x30, [sp, #-0x30]!                         
02cda8ac: stp     x22, x21, [sp, #0x10]                      
02cda8b0: stp     x20, x19, [sp, #0x20]                      
02cda8b4: adrp    x20, #0x662f000                            
02cda8b8: adrp    x21, #0x6267000                            
02cda8bc: mov     x19, x0                                    
02cda8c0: ldrb    w8, [x20, #0xd54]                          
02cda8c4: ldr     x21, [x21, #0xba0]                         T:MoneyManager
02cda8c8: tbnz    w8, #0, #0x2cda8ec                         
02cda8cc: adrp    x0, #0x6267000                             
02cda8d0: ldr     x0, [x0, #0xba0]                           T:MoneyManager
02cda8d4: bl      #0x2b70db0                                 fn_2b70db0
02cda8d8: adrp    x0, #0x6265000                             
02cda8dc: ldr     x0, [x0, #0x3f0]                           T:UnityEngine.Events.UnityAction
02cda8e0: bl      #0x2b70db0                                 fn_2b70db0
02cda8e4: mov     w8, #1                                     
02cda8e8: strb    w8, [x20, #0xd54]                          
02cda8ec: ldr     x8, [x21]                                  S:'didu'
02cda8f0: adrp    x22, #0x6265000                            
02cda8f4: ldr     x8, [x8, #0xb8]                            
02cda8f8: ldr     x22, [x22, #0x3f0]                         T:UnityEngine.Events.UnityAction
02cda8fc: ldr     x20, [x8]                                  
02cda900: mov     x0, x20                                    
02cda904: mov     x1, x19                                    
02cda908: mov     x2, xzr                                    
02cda90c: bl      #0x4e570ac                                 System.Delegate::Combine
02cda910: mov     x8, x0                                     
02cda914: cbz     x0, #0x2cda928                             
02cda918: ldr     x1, [x22]                                  M:AdsManager::<OnApplicationPause>b__26_0
02cda91c: ldr     x9, [x8]                                   
02cda920: cmp     x9, x1                                     
02cda924: b.ne    #0x2cda958                                 
02cda928: ldr     x9, [x21]                                  S:'didu'
02cda92c: mov     x1, x8                                     
02cda930: mov     x2, x20                                    
02cda934: ldr     x0, [x9, #0xb8]                            
02cda938: bl      #0x2ba9880                                 fn_2ba9880
02cda93c: cmp     x0, x20                                    
02cda940: mov     x20, x0                                    
02cda944: b.ne    #0x2cda900                                 
02cda948: ldp     x20, x19, [sp, #0x20]                      
02cda94c: ldp     x22, x21, [sp, #0x10]                      
02cda950: ldr     x30, [sp], #0x30                           
02cda954: ret                                                
02cda958: mov     x0, x8                                     
02cda95c: bl      #0x2b713dc                                 fn_2b713dc
## remove_OnMoneyChanged(UnityEngine.Events.UnityAction value) -> void
---- MoneyManager::remove_OnMoneyChanged 0x2cda960
02cda960: str     x30, [sp, #-0x30]!                         
02cda964: stp     x22, x21, [sp, #0x10]                      
02cda968: stp     x20, x19, [sp, #0x20]                      
02cda96c: adrp    x20, #0x662f000                            
02cda970: adrp    x21, #0x6267000                            
02cda974: mov     x19, x0                                    
02cda978: ldrb    w8, [x20, #0xd55]                          
02cda97c: ldr     x21, [x21, #0xba0]                         T:MoneyManager
02cda980: tbnz    w8, #0, #0x2cda9a4                         
02cda984: adrp    x0, #0x6267000                             
02cda988: ldr     x0, [x0, #0xba0]                           T:MoneyManager
02cda98c: bl      #0x2b70db0                                 fn_2b70db0
02cda990: adrp    x0, #0x6265000                             
02cda994: ldr     x0, [x0, #0x3f0]                           T:UnityEngine.Events.UnityAction
02cda998: bl      #0x2b70db0                                 fn_2b70db0
02cda99c: mov     w8, #1                                     
02cda9a0: strb    w8, [x20, #0xd55]                          
02cda9a4: ldr     x8, [x21]                                  S:'didu'
02cda9a8: adrp    x22, #0x6265000                            
02cda9ac: ldr     x8, [x8, #0xb8]                            
02cda9b0: ldr     x22, [x22, #0x3f0]                         T:UnityEngine.Events.UnityAction
02cda9b4: ldr     x20, [x8]                                  
02cda9b8: mov     x0, x20                                    
02cda9bc: mov     x1, x19                                    
02cda9c0: mov     x2, xzr                                    
02cda9c4: bl      #0x4e57298                                 System.Delegate::Remove
02cda9c8: mov     x8, x0                                     
02cda9cc: cbz     x0, #0x2cda9e0                             
02cda9d0: ldr     x1, [x22]                                  M:AdsManager::<OnApplicationPause>b__26_0
02cda9d4: ldr     x9, [x8]                                   
02cda9d8: cmp     x9, x1                                     
02cda9dc: b.ne    #0x2cdaa10                                 
02cda9e0: ldr     x9, [x21]                                  S:'didu'
02cda9e4: mov     x1, x8                                     
02cda9e8: mov     x2, x20                                    
02cda9ec: ldr     x0, [x9, #0xb8]                            
02cda9f0: bl      #0x2ba9880                                 fn_2ba9880
02cda9f4: cmp     x0, x20                                    
02cda9f8: mov     x20, x0                                    
02cda9fc: b.ne    #0x2cda9b8                                 
02cdaa00: ldp     x20, x19, [sp, #0x20]                      
02cdaa04: ldp     x22, x21, [sp, #0x10]                      
02cdaa08: ldr     x30, [sp], #0x30                           
02cdaa0c: ret                                                
02cdaa10: mov     x0, x8                                     
02cdaa14: bl      #0x2b713dc                                 fn_2b713dc
## get_CollectingCoin() -> JobGame.CollectingCoin
---- MoneyManager::get_CollectingCoin 0x2cdaa18
02cdaa18: ldr     x0, [x0, #0x30]                            ._collectingCoin
02cdaa1c: ret                                                
## ShowMoneyAddOn(int value, float duration) -> void
---- MoneyManager::ShowMoneyAddOn 0x2cdaa20
02cdaa20: ldr     x0, [x0, #0x38]                            ._moneyItem
02cdaa24: cbz     x0, #0x2cdaa30                             
02cdaa28: mov     x2, xzr                                    
02cdaa2c: b       #0x2d24708                                 Home.MoneyItem::Show
02cdaa30: ret                                                
## Awake() -> void
---- MoneyManager::Awake 0x2cdaa34
02cdaa34: stp     x30, x21, [sp, #-0x20]!                    
02cdaa38: stp     x20, x19, [sp, #0x10]                      
02cdaa3c: adrp    x20, #0x662f000                            
02cdaa40: adrp    x21, #0x6266000                            
02cdaa44: mov     x19, x0                                    
02cdaa48: ldrb    w8, [x20, #0xd56]                          
02cdaa4c: ldr     x21, [x21, #0x658]                         MS:MonoSingleton`1::get_Instance
02cdaa50: tbnz    w8, #0, #0x2cdaa80                         
02cdaa54: adrp    x0, #0x6266000                             
02cdaa58: ldr     x0, [x0, #0x750]                           MS:DataManager::GetData
02cdaa5c: bl      #0x2b70db0                                 fn_2b70db0
02cdaa60: adrp    x0, #0x6266000                             
02cdaa64: ldr     x0, [x0, #0x658]                           MS:MonoSingleton`1::get_Instance
02cdaa68: bl      #0x2b70db0                                 fn_2b70db0
02cdaa6c: adrp    x0, #0x6264000                             
02cdaa70: ldr     x0, [x0, #0x7a0]                           S:'N0'
02cdaa74: bl      #0x2b70db0                                 fn_2b70db0
02cdaa78: mov     w8, #1                                     
02cdaa7c: strb    w8, [x20, #0xd56]                          
02cdaa80: ldr     x0, [x21]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cdaa84: bl      #0x3769600                                 fn_3769600
02cdaa88: cbz     x0, #0x2cdab18                             
02cdaa8c: adrp    x8, #0x6266000                             
02cdaa90: ldr     x8, [x8, #0x750]                           MS:DataManager::GetData
02cdaa94: ldr     x1, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cdaa98: bl      #0x3168dd0                                 fn_3168dd0
02cdaa9c: cbz     x0, #0x2cdab18                             
02cdaaa0: adrp    x21, #0x6264000                            
02cdaaa4: mov     x1, xzr                                    
02cdaaa8: ldr     x21, [x21, #0x7a0]                         S:'N0'
02cdaaac: bl      #0x2cabaf8                                 DataUser::GetMoney
02cdaab0: mov     x8, x19                                    
02cdaab4: ldr     x1, [x21]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02cdaab8: mov     x2, xzr                                    
02cdaabc: str     w0, [x8, #0x40]!                           
02cdaac0: ldur    x20, [x8, #-0x18]                          
02cdaac4: mov     x0, x8                                     
02cdaac8: bl      #0x4e0ead0                                 System.Int32::ToString
02cdaacc: cbz     x20, #0x2cdab18                            
02cdaad0: ldr     x8, [x20]                                  &2b706c4(=eb01011ff9400808)
02cdaad4: mov     x1, x0                                     
02cdaad8: mov     x0, x20                                    
02cdaadc: ldr     x9, [x8, #0x558]                           MS:NFramework.GoogleSheetConfigSO`1::.ctor
02cdaae0: ldr     x2, [x8, #0x560]                           MS:NFramework.GoogleSheetConfigSO`1::OpenSheet
02cdaae4: blr     x9                                         
02cdaae8: mov     x0, x19                                    
02cdaaec: mov     x1, xzr                                    
02cdaaf0: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02cdaaf4: cbz     x0, #0x2cdab18                             
02cdaaf8: mov     x1, xzr                                    
02cdaafc: bl      #0x5b466dc                                 UnityEngine.Transform::get_parent
02cdab00: str     x0, [x19, #0x48]!                          ._defaultParent
02cdab04: mov     x1, x0                                     
02cdab08: mov     x0, x19                                    
02cdab0c: ldp     x20, x19, [sp, #0x10]                      
02cdab10: ldp     x30, x21, [sp], #0x20                      
02cdab14: b       #0x2b70d54                                 
02cdab18: bl      #0x2b7105c                                 fn_2b7105c
## RefreshMoney() -> void
---- MoneyManager::RefreshMoney 0x2cdab1c
02cdab1c: stp     x30, x21, [sp, #-0x20]!                    
02cdab20: stp     x20, x19, [sp, #0x10]                      
02cdab24: adrp    x20, #0x662f000                            
02cdab28: adrp    x21, #0x6266000                            
02cdab2c: mov     x19, x0                                    
02cdab30: ldrb    w8, [x20, #0xd57]                          
02cdab34: ldr     x21, [x21, #0x658]                         MS:MonoSingleton`1::get_Instance
02cdab38: tbnz    w8, #0, #0x2cdab68                         
02cdab3c: adrp    x0, #0x6266000                             
02cdab40: ldr     x0, [x0, #0x750]                           MS:DataManager::GetData
02cdab44: bl      #0x2b70db0                                 fn_2b70db0
02cdab48: adrp    x0, #0x6266000                             
02cdab4c: ldr     x0, [x0, #0x658]                           MS:MonoSingleton`1::get_Instance
02cdab50: bl      #0x2b70db0                                 fn_2b70db0
02cdab54: adrp    x0, #0x6264000                             
02cdab58: ldr     x0, [x0, #0x7a0]                           S:'N0'
02cdab5c: bl      #0x2b70db0                                 fn_2b70db0
02cdab60: mov     w8, #1                                     
02cdab64: strb    w8, [x20, #0xd57]                          
02cdab68: ldr     x0, [x21]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cdab6c: bl      #0x3769600                                 fn_3769600
02cdab70: cbz     x0, #0x2cdabd4                             
02cdab74: adrp    x8, #0x6266000                             
02cdab78: ldr     x8, [x8, #0x750]                           MS:DataManager::GetData
02cdab7c: ldr     x1, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cdab80: bl      #0x3168dd0                                 fn_3168dd0
02cdab84: cbz     x0, #0x2cdabd4                             
02cdab88: adrp    x20, #0x6264000                            
02cdab8c: mov     x1, xzr                                    
02cdab90: ldr     x20, [x20, #0x7a0]                         S:'N0'
02cdab94: bl      #0x2cabaf8                                 DataUser::GetMoney
02cdab98: ldr     x1, [x20]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02cdab9c: str     w0, [x19, #0x40]!                          ._money
02cdaba0: ldur    x20, [x19, #-0x18]                         
02cdaba4: mov     x0, x19                                    
02cdaba8: mov     x2, xzr                                    
02cdabac: bl      #0x4e0ead0                                 System.Int32::ToString
02cdabb0: cbz     x20, #0x2cdabd4                            
02cdabb4: ldr     x8, [x20]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02cdabb8: mov     x1, x0                                     
02cdabbc: mov     x0, x20                                    
02cdabc0: ldp     x20, x19, [sp, #0x10]                      
02cdabc4: ldr     x2, [x8, #0x560]                           MS:NFramework.GoogleSheetConfigSO`1::OpenSheet
02cdabc8: ldr     x3, [x8, #0x558]                           MS:NFramework.GoogleSheetConfigSO`1::.ctor
02cdabcc: ldp     x30, x21, [sp], #0x20                      
02cdabd0: br      x3                                         
02cdabd4: bl      #0x2b7105c                                 fn_2b7105c
## UpdateParent() -> MoneyManager
---- MoneyManager::UpdateParent 0x2cdabd8
02cdabd8: stp     x30, x19, [sp, #-0x10]!                    
02cdabdc: mov     x1, xzr                                    
02cdabe0: mov     x19, x0                                    
02cdabe4: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02cdabe8: cbz     x0, #0x2cdac10                             
02cdabec: mov     x1, xzr                                    
02cdabf0: bl      #0x5b466dc                                 UnityEngine.Transform::get_parent
02cdabf4: mov     x1, x0                                     
02cdabf8: mov     x0, x19                                    
02cdabfc: str     x1, [x0, #0x48]!                           ._defaultParent
02cdac00: bl      #0x2b70d54                                 fn_2b70d54
02cdac04: mov     x0, x19                                    
02cdac08: ldp     x30, x19, [sp], #0x10                      
02cdac0c: ret                                                
02cdac10: bl      #0x2b7105c                                 fn_2b7105c
## SetCurrentParent(UnityEngine.Transform parent) -> MoneyManager
---- MoneyManager::SetCurrentParent 0x2cdac14
02cdac14: str     x30, [sp, #-0x20]!                         
02cdac18: stp     x20, x19, [sp, #0x10]                      
02cdac1c: mov     x20, x1                                    
02cdac20: mov     x1, xzr                                    
02cdac24: mov     x19, x0                                    
02cdac28: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02cdac2c: cbz     x0, #0x2cdac4c                             
02cdac30: mov     x1, x20                                    
02cdac34: mov     x2, xzr                                    
02cdac38: bl      #0x5b471a4                                 UnityEngine.Transform::set_parent
02cdac3c: mov     x0, x19                                    
02cdac40: ldp     x20, x19, [sp, #0x10]                      
02cdac44: ldr     x30, [sp], #0x20                           
02cdac48: ret                                                
02cdac4c: bl      #0x2b7105c                                 fn_2b7105c
## OnShow() -> void
---- MoneyManager::OnShow 0x2cdac50
02cdac50: movi    d0, #0000000000000000                      
02cdac54: ldr     x0, [x0, #0x20]                            ._canvasGroup
02cdac58: mov     w1, #1                                     
02cdac5c: mov     x2, xzr                                    
02cdac60: b       #0x2cf1928                                 FrameWorkUtility::SetActive
## OnHide() -> void
---- MoneyManager::OnHide 0x2cdac64
02cdac64: movi    d0, #0000000000000000                      
02cdac68: ldr     x0, [x0, #0x20]                            ._canvasGroup
02cdac6c: mov     w1, wzr                                    
02cdac70: mov     x2, xzr                                    
02cdac74: b       #0x2cf1928                                 FrameWorkUtility::SetActive
## UpdateMoney(int money) -> void
---- MoneyManager::UpdateMoney 0x2cdac78
02cdac78: stp     x30, x27, [sp, #-0x50]!                    
02cdac7c: stp     x26, x25, [sp, #0x10]                      
02cdac80: stp     x24, x23, [sp, #0x20]                      
02cdac84: stp     x22, x21, [sp, #0x30]                      
02cdac88: stp     x20, x19, [sp, #0x40]                      
02cdac8c: adrp    x21, #0x662f000                            
02cdac90: adrp    x22, #0x6267000                            
02cdac94: mov     w19, w1                                    
02cdac98: ldrb    w8, [x21, #0xd58]                          
02cdac9c: ldr     x22, [x22, #0xba8]                         T:MoneyManager/<>c__DisplayClass20_0
02cdaca0: mov     x20, x0                                    
02cdaca4: tbnz    w8, #0, #0x2cdad34                         
02cdaca8: adrp    x0, #0x6264000                             
02cdacac: ldr     x0, [x0, #0x6b0]                           T:type8523(k15)
02cdacb0: bl      #0x2b70db0                                 fn_2b70db0
02cdacb4: adrp    x0, #0x6264000                             
02cdacb8: ldr     x0, [x0, #0x6b8]                           T:type8545(k15)
02cdacbc: bl      #0x2b70db0                                 fn_2b70db0
02cdacc0: adrp    x0, #0x6263000                             
02cdacc4: ldr     x0, [x0, #0xfd0]                           T:DG.Tweening.DOTween
02cdacc8: bl      #0x2b70db0                                 fn_2b70db0
02cdaccc: adrp    x0, #0x6266000                             
02cdacd0: ldr     x0, [x0, #0x750]                           MS:DataManager::GetData
02cdacd4: bl      #0x2b70db0                                 fn_2b70db0
02cdacd8: adrp    x0, #0x6266000                             
02cdacdc: ldr     x0, [x0, #0x5e0]                           T:GameConfig
02cdace0: bl      #0x2b70db0                                 fn_2b70db0
02cdace4: adrp    x0, #0x6267000                             
02cdace8: ldr     x0, [x0, #0xba0]                           T:MoneyManager
02cdacec: bl      #0x2b70db0                                 fn_2b70db0
02cdacf0: adrp    x0, #0x6267000                             
02cdacf4: ldr     x0, [x0, #0xbb0]                           MS:MonoSingleton`1::get_Instance
02cdacf8: bl      #0x2b70db0                                 fn_2b70db0
02cdacfc: adrp    x0, #0x6266000                             
02cdad00: ldr     x0, [x0, #0x658]                           MS:MonoSingleton`1::get_Instance
02cdad04: bl      #0x2b70db0                                 fn_2b70db0
02cdad08: adrp    x0, #0x6267000                             
02cdad0c: ldr     x0, [x0, #0xbb8]                           M:MoneyManager/<>c__DisplayClass20_0::<UpdateMoney>b__0
02cdad10: bl      #0x2b70db0                                 fn_2b70db0
02cdad14: adrp    x0, #0x6267000                             
02cdad18: ldr     x0, [x0, #0xbc0]                           M:MoneyManager/<>c__DisplayClass20_0::<UpdateMoney>b__1
02cdad1c: bl      #0x2b70db0                                 fn_2b70db0
02cdad20: adrp    x0, #0x6267000                             
02cdad24: ldr     x0, [x0, #0xba8]                           T:MoneyManager/<>c__DisplayClass20_0
02cdad28: bl      #0x2b70db0                                 fn_2b70db0
02cdad2c: mov     w8, #1                                     
02cdad30: strb    w8, [x21, #0xd58]                          
02cdad34: ldr     x0, [x22]                                  S:'didu'
02cdad38: bl      #0x2b7104c                                 fn_2b7104c
02cdad3c: mov     x1, xzr                                    
02cdad40: mov     x21, x0                                    
02cdad44: bl      #0x4e53e9c                                 System.Object::.ctor
02cdad48: cbz     x21, #0x2cdaf24                            
02cdad4c: adrp    x22, #0x6264000                            
02cdad50: adrp    x23, #0x6267000                            
02cdad54: adrp    x25, #0x6264000                            
02cdad58: adrp    x26, #0x6267000                            
02cdad5c: adrp    x27, #0x6263000                            
02cdad60: adrp    x24, #0x6266000                            
02cdad64: ldr     x22, [x22, #0x6b0]                         T:type8523(k15)
02cdad68: ldr     x23, [x23, #0xbb8]                         M:MoneyManager/<>c__DisplayClass20_0::<UpdateMoney>b__0
02cdad6c: ldr     x25, [x25, #0x6b8]                         T:type8545(k15)
02cdad70: ldr     x26, [x26, #0xbc0]                         M:MoneyManager/<>c__DisplayClass20_0::<UpdateMoney>b__1
02cdad74: ldr     x27, [x27, #0xfd0]                         T:DG.Tweening.DOTween
02cdad78: ldr     x24, [x24, #0x658]                         MS:MonoSingleton`1::get_Instance
02cdad7c: mov     x0, x21                                    
02cdad80: mov     x1, x20                                    
02cdad84: str     x20, [x0, #0x18]!                          
02cdad88: bl      #0x2b70d54                                 fn_2b70d54
02cdad8c: ldr     w8, [x20, #0x40]                           ._money
02cdad90: ldr     x0, [x22]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02cdad94: add     w9, w8, w19                                
02cdad98: str     w8, [x21, #0x10]                           
02cdad9c: bic     w9, w9, w9, asr #31                        
02cdada0: str     w9, [x20, #0x40]                           ._money
02cdada4: bl      #0x2b7104c                                 fn_2b7104c
02cdada8: ldr     x2, [x23]                                  S:'didu'
02cdadac: mov     x1, x21                                    
02cdadb0: mov     x3, xzr                                    
02cdadb4: mov     x22, x0                                    
02cdadb8: bl      #0x445323c                                 fn_445323c
02cdadbc: ldr     x0, [x25]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02cdadc0: bl      #0x2b7104c                                 fn_2b7104c
02cdadc4: ldr     x2, [x26]                                  S:'didu'
02cdadc8: mov     x1, x21                                    
02cdadcc: mov     x3, xzr                                    
02cdadd0: mov     x23, x0                                    
02cdadd4: bl      #0x4454208                                 fn_4454208
02cdadd8: ldr     x0, [x27]                                  &2c5bbd4(=a9bd7bfdd503233f)
02cdaddc: ldr     w21, [x20, #0x40]                          ._money
02cdade0: ldr     w8, [x0, #0xe4]                            [62670e4]=0 f=0,0
02cdade4: cbnz    w8, #0x2cdadec                             
02cdade8: bl      #0x2b70f30                                 fn_2b70f30
02cdadec: fmov    s0, #1.00000000                            
02cdadf0: mov     x0, x22                                    
02cdadf4: mov     x1, x23                                    
02cdadf8: mov     w2, w21                                    
02cdadfc: mov     x3, xzr                                    
02cdae00: bl      #0x2d8b4e4                                 DG.Tweening.DOTween::To
02cdae04: ldr     x0, [x24]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cdae08: bl      #0x3769600                                 fn_3769600
02cdae0c: cbz     x0, #0x2cdaf24                             
02cdae10: adrp    x8, #0x6266000                             
02cdae14: ldr     x8, [x8, #0x750]                           MS:DataManager::GetData
02cdae18: ldr     x1, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cdae1c: bl      #0x3168dd0                                 fn_3168dd0
02cdae20: cbz     x0, #0x2cdaf24                             
02cdae24: adrp    x21, #0x6267000                            
02cdae28: mov     x2, xzr                                    
02cdae2c: ldr     x21, [x21, #0xba0]                         T:MoneyManager
02cdae30: ldr     w1, [x20, #0x40]                           ._money
02cdae34: bl      #0x2cabb10                                 DataUser::UpdateMoney
02cdae38: ldr     x8, [x21]                                  S:'didu'
02cdae3c: ldr     x8, [x8, #0xb8]                            S:'banner_native_refresh_time'
02cdae40: ldr     x8, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cdae44: cbz     x8, #0x2cdae58                             
02cdae48: ldr     x9, [x8, #0x18]                            S:'level_show_popuprate'
02cdae4c: ldr     x0, [x8, #0x40]                            S:'native_collap_ad_on_off'
02cdae50: ldr     x1, [x8, #0x28]                            S:'banner_ad_on_off'
02cdae54: blr     x9                                         
02cdae58: cmp     w19, #1                                    
02cdae5c: b.lt    #0x2cdaf0c                                 
02cdae60: adrp    x22, #0x6267000                            
02cdae64: adrp    x21, #0x6266000                            
02cdae68: ldr     x22, [x22, #0xbb0]                         MS:MonoSingleton`1::get_Instance
02cdae6c: ldr     x21, [x21, #0x5e0]                         T:GameConfig
02cdae70: ldr     x0, [x22]                                  S:'didu'
02cdae74: bl      #0x3769600                                 fn_3769600
02cdae78: ldr     x8, [x21]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cdae7c: mov     x20, x0                                    
02cdae80: ldr     w9, [x8, #0xe4]                            [62660e4]=0 f=0,0
02cdae84: cbnz    w9, #0x2cdae90                             
02cdae88: mov     x0, x8                                     
02cdae8c: bl      #0x2b70f30                                 fn_2b70f30
02cdae90: cbz     x20, #0x2cdaf24                            
02cdae94: ldr     x8, [x21]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cdae98: mov     x0, x20                                    
02cdae9c: mov     w2, w19                                    
02cdaea0: mov     x3, xzr                                    
02cdaea4: ldr     x8, [x8, #0xb8]                            S:'banner_native_refresh_time'
02cdaea8: ldr     w1, [x8, #0xa4]                            [62660a4]=0 f=0,0
02cdaeac: bl      #0x2d28eec                                 DailyTask.DailyTaskController::ProgressTask
02cdaeb0: ldr     x0, [x22]                                  S:'didu'
02cdaeb4: bl      #0x3769600                                 fn_3769600
02cdaeb8: cbz     x0, #0x2cdaf24                             
02cdaebc: ldr     x8, [x21]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cdaec0: mov     w2, w19                                    
02cdaec4: mov     x3, xzr                                    
02cdaec8: ldr     x8, [x8, #0xb8]                            S:'banner_native_refresh_time'
02cdaecc: ldr     w1, [x8, #0xa8]                            S:'data_config_type'
02cdaed0: bl      #0x2d28eec                                 DailyTask.DailyTaskController::ProgressTask
02cdaed4: ldr     x0, [x22]                                  S:'didu'
02cdaed8: bl      #0x3769600                                 fn_3769600
02cdaedc: cbz     x0, #0x2cdaf24                             
02cdaee0: ldr     x8, [x21]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cdaee4: mov     w2, w19                                    
02cdaee8: mov     x3, xzr                                    
02cdaeec: ldp     x20, x19, [sp, #0x40]                      
02cdaef0: ldr     x8, [x8, #0xb8]                            S:'banner_native_refresh_time'
02cdaef4: ldp     x22, x21, [sp, #0x30]                      
02cdaef8: ldp     x24, x23, [sp, #0x20]                      
02cdaefc: ldp     x26, x25, [sp, #0x10]                      
02cdaf00: ldr     w1, [x8, #0xb4]                            [62660b4]=0 f=0,0
02cdaf04: ldp     x30, x27, [sp], #0x50                      
02cdaf08: b       #0x2d28eec                                 DailyTask.DailyTaskController::ProgressTask
02cdaf0c: ldp     x20, x19, [sp, #0x40]                      
02cdaf10: ldp     x22, x21, [sp, #0x30]                      
02cdaf14: ldp     x24, x23, [sp, #0x20]                      
02cdaf18: ldp     x26, x25, [sp, #0x10]                      
02cdaf1c: ldp     x30, x27, [sp], #0x50                      
02cdaf20: ret                                                
02cdaf24: bl      #0x2b7105c                                 fn_2b7105c
## CollectMoney(int money, int coinObjAmount, System.Action onCompleted) -> void
---- MoneyManager::CollectMoney 0x2cdaf30
02cdaf30: str     x30, [sp, #-0x50]!                         
02cdaf34: stp     x26, x25, [sp, #0x10]                      
02cdaf38: stp     x24, x23, [sp, #0x20]                      
02cdaf3c: stp     x22, x21, [sp, #0x30]                      
02cdaf40: stp     x20, x19, [sp, #0x40]                      
02cdaf44: adrp    x21, #0x662f000                            
02cdaf48: adrp    x24, #0x6267000                            
02cdaf4c: mov     x22, x3                                    
02cdaf50: ldrb    w8, [x21, #0xd59]                          
02cdaf54: ldr     x24, [x24, #0xbc8]                         T:MoneyManager/<>c__DisplayClass21_0
02cdaf58: mov     w19, w2                                    
02cdaf5c: mov     w23, w1                                    
02cdaf60: mov     x20, x0                                    
02cdaf64: tbnz    w8, #0, #0x2cdafa0                         
02cdaf68: adrp    x0, #0x6264000                             
02cdaf6c: ldr     x0, [x0, #0xf90]                           T:System.Action
02cdaf70: bl      #0x2b70db0                                 fn_2b70db0
02cdaf74: adrp    x0, #0x6267000                             
02cdaf78: ldr     x0, [x0, #0xbd0]                           MS:MonoSingleton`1::get_Instance
02cdaf7c: bl      #0x2b70db0                                 fn_2b70db0
02cdaf80: adrp    x0, #0x6267000                             
02cdaf84: ldr     x0, [x0, #0xbd8]                           M:MoneyManager/<>c__DisplayClass21_0::<CollectMoney>b__0
02cdaf88: bl      #0x2b70db0                                 fn_2b70db0
02cdaf8c: adrp    x0, #0x6267000                             
02cdaf90: ldr     x0, [x0, #0xbc8]                           T:MoneyManager/<>c__DisplayClass21_0
02cdaf94: bl      #0x2b70db0                                 fn_2b70db0
02cdaf98: mov     w8, #1                                     
02cdaf9c: strb    w8, [x21, #0xd59]                          
02cdafa0: ldr     x0, [x24]                                  S:'didu'
02cdafa4: bl      #0x2b7104c                                 fn_2b7104c
02cdafa8: mov     x1, xzr                                    
02cdafac: mov     x21, x0                                    
02cdafb0: bl      #0x4e53e9c                                 System.Object::.ctor
02cdafb4: cbz     x21, #0x2cdb0d4                            
02cdafb8: adrp    x26, #0x6267000                            
02cdafbc: mov     x25, x21                                   
02cdafc0: mov     x1, x20                                    
02cdafc4: ldr     x26, [x26, #0xbd0]                         MS:MonoSingleton`1::get_Instance
02cdafc8: str     x20, [x25, #0x10]!                         
02cdafcc: mov     x0, x25                                    
02cdafd0: bl      #0x2b70d54                                 fn_2b70d54
02cdafd4: mov     x24, x20                                   
02cdafd8: str     w23, [x25, #8]                             
02cdafdc: ldr     x0, [x24, #0x50]!                          S:'['
02cdafe0: cbz     x0, #0x2cdb02c                             
02cdafe4: mov     w1, wzr                                    
02cdafe8: mov     x2, xzr                                    
02cdafec: bl      #0x2d8fe94                                 DG.Tweening.TweenExtensions::Kill
02cdaff0: mov     x23, x20                                   
02cdaff4: ldr     x8, [x23, #0x58]!                          
02cdaff8: cbz     x8, #0x2cdb00c                             
02cdaffc: ldr     x9, [x8, #0x18]                            
02cdb000: ldr     x0, [x8, #0x40]                            
02cdb004: ldr     x1, [x8, #0x28]                            
02cdb008: blr     x9                                         
02cdb00c: mov     x0, x23                                    
02cdb010: mov     x1, xzr                                    
02cdb014: str     xzr, [x23]                                 
02cdb018: bl      #0x2b70d54                                 fn_2b70d54
02cdb01c: mov     x0, x24                                    
02cdb020: mov     x1, xzr                                    
02cdb024: str     xzr, [x24]                                 
02cdb028: bl      #0x2b70d54                                 fn_2b70d54
02cdb02c: mov     x0, x20                                    
02cdb030: mov     x1, x22                                    
02cdb034: str     x22, [x0, #0x58]!                          ._onCompleted
02cdb038: bl      #0x2b70d54                                 fn_2b70d54
02cdb03c: mov     x0, x20                                    
02cdb040: mov     x1, xzr                                    
02cdb044: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02cdb048: ldr     x8, [x26]                                  S:'didu'
02cdb04c: mov     x22, x0                                    
02cdb050: mov     x0, x8                                     
02cdb054: bl      #0x3769600                                 fn_3769600
02cdb058: cbz     x0, #0x2cdb0d4                             
02cdb05c: mov     x1, xzr                                    
02cdb060: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02cdb064: cbz     x22, #0x2cdb0d4                            
02cdb068: adrp    x23, #0x6264000                            
02cdb06c: adrp    x24, #0x6267000                            
02cdb070: mov     x1, x0                                     
02cdb074: ldr     x23, [x23, #0xf90]                         T:System.Action
02cdb078: ldr     x24, [x24, #0xbd8]                         M:MoneyManager/<>c__DisplayClass21_0::<CollectMoney>b__0
02cdb07c: mov     x0, x22                                    
02cdb080: mov     x2, xzr                                    
02cdb084: bl      #0x5b472ec                                 UnityEngine.Transform::SetParent
02cdb088: ldr     x0, [x23]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02cdb08c: ldr     x20, [x20, #0x30]                          ._collectingCoin
02cdb090: bl      #0x2b7104c                                 fn_2b7104c
02cdb094: ldr     x2, [x24]                                  S:'didu'
02cdb098: mov     x1, x21                                    
02cdb09c: mov     x3, xzr                                    
02cdb0a0: mov     x22, x0                                    
02cdb0a4: bl      #0x4d8ddbc                                 System.Action::.ctor
02cdb0a8: cbz     x20, #0x2cdb0d4                            
02cdb0ac: mov     x0, x20                                    
02cdb0b0: mov     w1, w19                                    
02cdb0b4: mov     x2, x22                                    
02cdb0b8: ldp     x20, x19, [sp, #0x40]                      
02cdb0bc: mov     x3, xzr                                    
02cdb0c0: ldp     x22, x21, [sp, #0x30]                      
02cdb0c4: ldp     x24, x23, [sp, #0x20]                      
02cdb0c8: ldp     x26, x25, [sp, #0x10]                      
02cdb0cc: ldr     x30, [sp], #0x50                           
02cdb0d0: b       #0x2d12224                                 JobGame.CollectingCoin::CollectCoins
02cdb0d4: bl      #0x2b7105c                                 fn_2b7105c
## CollectMoney(int money, UnityEngine.Vector3 spawnPos, int coinObjAmount, System.Action onCompleted) -> void
---- MoneyManager::CollectMoney 0x2cdb0e0
02cdb0e0: str     d10, [sp, #-0x50]!                         
02cdb0e4: stp     d9, d8, [sp, #8]                           
02cdb0e8: str     x30, [sp, #0x18]                           
02cdb0ec: stp     x24, x23, [sp, #0x20]                      
02cdb0f0: stp     x22, x21, [sp, #0x30]                      
02cdb0f4: stp     x20, x19, [sp, #0x40]                      
02cdb0f8: fmov    s8, s2                                     
02cdb0fc: fmov    s9, s1                                     
02cdb100: adrp    x21, #0x662f000                            
02cdb104: fmov    s10, s0                                    
02cdb108: adrp    x24, #0x6267000                            
02cdb10c: ldrb    w8, [x21, #0xd5a]                          
02cdb110: ldr     x24, [x24, #0xbe0]                         T:MoneyManager/<>c__DisplayClass22_0
02cdb114: mov     x22, x3                                    
02cdb118: mov     w19, w2                                    
02cdb11c: mov     w23, w1                                    
02cdb120: mov     x20, x0                                    
02cdb124: tbnz    w8, #0, #0x2cdb160                         
02cdb128: adrp    x0, #0x6264000                             
02cdb12c: ldr     x0, [x0, #0xf90]                           T:System.Action
02cdb130: bl      #0x2b70db0                                 fn_2b70db0
02cdb134: adrp    x0, #0x6267000                             
02cdb138: ldr     x0, [x0, #0xbd0]                           MS:MonoSingleton`1::get_Instance
02cdb13c: bl      #0x2b70db0                                 fn_2b70db0
02cdb140: adrp    x0, #0x6267000                             
02cdb144: ldr     x0, [x0, #0xbe8]                           M:MoneyManager/<>c__DisplayClass22_0::<CollectMoney>b__0
02cdb148: bl      #0x2b70db0                                 fn_2b70db0
02cdb14c: adrp    x0, #0x6267000                             
02cdb150: ldr     x0, [x0, #0xbe0]                           T:MoneyManager/<>c__DisplayClass22_0
02cdb154: bl      #0x2b70db0                                 fn_2b70db0
02cdb158: mov     w8, #1                                     
02cdb15c: strb    w8, [x21, #0xd5a]                          
02cdb160: ldr     x0, [x24]                                  S:'didu'
02cdb164: bl      #0x2b7104c                                 fn_2b7104c
02cdb168: mov     x1, xzr                                    
02cdb16c: mov     x21, x0                                    
02cdb170: bl      #0x4e53e9c                                 System.Object::.ctor
02cdb174: cbz     x21, #0x2cdb260                            
02cdb178: adrp    x24, #0x6267000                            
02cdb17c: mov     x0, x21                                    
02cdb180: mov     x1, x20                                    
02cdb184: ldr     x24, [x24, #0xbd0]                         MS:MonoSingleton`1::get_Instance
02cdb188: str     x20, [x0, #0x10]!                          
02cdb18c: bl      #0x2b70d54                                 fn_2b70d54
02cdb190: mov     x0, x21                                    
02cdb194: mov     x1, x22                                    
02cdb198: str     x22, [x0, #0x20]!                          ._canvasGroup
02cdb19c: stur    w23, [x0, #-8]                             
02cdb1a0: bl      #0x2b70d54                                 fn_2b70d54
02cdb1a4: mov     x0, x20                                    
02cdb1a8: mov     x1, xzr                                    
02cdb1ac: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02cdb1b0: ldr     x8, [x24]                                  S:'didu'
02cdb1b4: mov     x22, x0                                    
02cdb1b8: mov     x0, x8                                     
02cdb1bc: bl      #0x3769600                                 fn_3769600
02cdb1c0: cbz     x0, #0x2cdb260                             
02cdb1c4: mov     x1, xzr                                    
02cdb1c8: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02cdb1cc: cbz     x22, #0x2cdb260                            
02cdb1d0: mov     x1, x0                                     
02cdb1d4: mov     x0, x22                                    
02cdb1d8: mov     x2, xzr                                    
02cdb1dc: bl      #0x5b472ec                                 UnityEngine.Transform::SetParent
02cdb1e0: ldr     x0, [x20, #0x30]                           ._collectingCoin
02cdb1e4: cbz     x0, #0x2cdb260                             
02cdb1e8: fmov    s0, s10                                    
02cdb1ec: fmov    s1, s9                                     
02cdb1f0: adrp    x20, #0x6264000                            
02cdb1f4: fmov    s2, s8                                     
02cdb1f8: adrp    x22, #0x6267000                            
02cdb1fc: ldr     x20, [x20, #0xf90]                         T:System.Action
02cdb200: ldr     x22, [x22, #0xbe8]                         M:MoneyManager/<>c__DisplayClass22_0::<CollectMoney>b__0
02cdb204: mov     x1, xzr                                    
02cdb208: bl      #0x2d121fc                                 JobGame.CollectingCoin::SetSpawnLocation
02cdb20c: ldr     x8, [x20]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02cdb210: mov     x20, x0                                    
02cdb214: mov     x0, x8                                     
02cdb218: bl      #0x2b7104c                                 fn_2b7104c
02cdb21c: ldr     x2, [x22]                                  S:'didu'
02cdb220: mov     x1, x21                                    
02cdb224: mov     x3, xzr                                    
02cdb228: mov     x22, x0                                    
02cdb22c: bl      #0x4d8ddbc                                 System.Action::.ctor
02cdb230: cbz     x20, #0x2cdb260                            
02cdb234: mov     x0, x20                                    
02cdb238: mov     w1, w19                                    
02cdb23c: mov     x2, x22                                    
02cdb240: ldp     x20, x19, [sp, #0x40]                      
02cdb244: ldr     x30, [sp, #0x18]                           
02cdb248: ldp     x22, x21, [sp, #0x30]                      
02cdb24c: mov     x3, xzr                                    
02cdb250: ldp     x24, x23, [sp, #0x20]                      
02cdb254: ldp     d9, d8, [sp, #8]                           
02cdb258: ldr     d10, [sp], #0x50                           
02cdb25c: b       #0x2d12224                                 JobGame.CollectingCoin::CollectCoins
02cdb260: bl      #0x2b7105c                                 fn_2b7105c
## ShowUp() -> void
---- MoneyManager::ShowUp 0x2cdb26c
02cdb26c: stp     x30, x21, [sp, #-0x20]!                    
02cdb270: stp     x20, x19, [sp, #0x10]                      
02cdb274: adrp    x21, #0x662f000                            
02cdb278: adrp    x20, #0x6267000                            
02cdb27c: mov     x19, x0                                    
02cdb280: ldrb    w8, [x21, #0xd5b]                          
02cdb284: ldr     x20, [x20, #0xbd0]                         MS:MonoSingleton`1::get_Instance
02cdb288: tbnz    w8, #0, #0x2cdb2a0                         
02cdb28c: adrp    x0, #0x6267000                             
02cdb290: ldr     x0, [x0, #0xbd0]                           MS:MonoSingleton`1::get_Instance
02cdb294: bl      #0x2b70db0                                 fn_2b70db0
02cdb298: mov     w8, #1                                     
02cdb29c: strb    w8, [x21, #0xd5b]                          
02cdb2a0: mov     x0, x19                                    
02cdb2a4: mov     x1, xzr                                    
02cdb2a8: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02cdb2ac: ldr     x8, [x20]                                  S:'didu'
02cdb2b0: mov     x19, x0                                    
02cdb2b4: mov     x0, x8                                     
02cdb2b8: bl      #0x3769600                                 fn_3769600
02cdb2bc: cbz     x0, #0x2cdb2e4                             
02cdb2c0: mov     x1, xzr                                    
02cdb2c4: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02cdb2c8: cbz     x19, #0x2cdb2e4                            
02cdb2cc: mov     x1, x0                                     
02cdb2d0: mov     x0, x19                                    
02cdb2d4: mov     x2, xzr                                    
02cdb2d8: ldp     x20, x19, [sp, #0x10]                      
02cdb2dc: ldp     x30, x21, [sp], #0x20                      
02cdb2e0: b       #0x5b472ec                                 UnityEngine.Transform::SetParent
02cdb2e4: bl      #0x2b7105c                                 fn_2b7105c
## BackToParent() -> void
---- MoneyManager::BackToParent 0x2cdb2e8
02cdb2e8: stp     x30, x19, [sp, #-0x10]!                    
02cdb2ec: mov     x1, xzr                                    
02cdb2f0: mov     x19, x0                                    
02cdb2f4: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02cdb2f8: cbz     x0, #0x2cdb30c                             
02cdb2fc: ldr     x1, [x19, #0x48]                           ._defaultParent
02cdb300: mov     x2, xzr                                    
02cdb304: ldp     x30, x19, [sp], #0x10                      
02cdb308: b       #0x5b472ec                                 UnityEngine.Transform::SetParent
02cdb30c: bl      #0x2b7105c                                 fn_2b7105c
## Add1Mil() -> void
---- MoneyManager::Add1Mil 0x2cdb310
02cdb310: mov     w1, #0x4240                                
02cdb314: movk    w1, #0xf, lsl #16                          
02cdb318: b       #0x2cdac78                                 MoneyManager::UpdateMoney
## .ctor() -> void
---- MoneyManager::.ctor 0x2cdb31c
02cdb31c: stp     x30, x21, [sp, #-0x20]!                    
02cdb320: stp     x20, x19, [sp, #0x10]                      
02cdb324: adrp    x20, #0x662f000                            
02cdb328: adrp    x21, #0x6267000                            
02cdb32c: mov     x19, x0                                    
02cdb330: ldrb    w8, [x20, #0xd5c]                          
02cdb334: ldr     x21, [x21, #0xbf0]                         MS:MonoSingleton`1::.ctor
02cdb338: tbnz    w8, #0, #0x2cdb350                         
02cdb33c: adrp    x0, #0x6267000                             
02cdb340: ldr     x0, [x0, #0xbf0]                           MS:MonoSingleton`1::.ctor
02cdb344: bl      #0x2b70db0                                 fn_2b70db0
02cdb348: mov     w8, #1                                     
02cdb34c: strb    w8, [x20, #0xd5c]                          
02cdb350: mov     x0, x19                                    
02cdb354: ldp     x20, x19, [sp, #0x10]                      
02cdb358: ldr     x1, [x21]                                  S:'didu'
02cdb35c: ldp     x30, x21, [sp], #0x20                      
02cdb360: b       #0x3769e18                                 
