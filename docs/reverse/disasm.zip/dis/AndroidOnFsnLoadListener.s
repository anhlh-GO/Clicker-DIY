#### CLASS AndroidOnFsnLoadListener/<>c__DisplayClass5_0 parent= object
#   field <>4__this                      AndroidOnFsnLoadListener                           off=0x10 attr=6 
#   field errorCode                      int                                                off=0x18 attr=6 
#   field errorMessage                   string                                             off=0x20 attr=6 
## .ctor() -> void
---- AndroidOnFsnLoadListener/<>c__DisplayClass5_0::.ctor 0x2c966fc
02c966fc: mov     x1, xzr                                    
02c96700: b       #0x4e53e9c                                 System.Object::.ctor
## <OnLoadingCompleted>b__0(object _) -> void
---- AndroidOnFsnLoadListener/<>c__DisplayClass5_0::<OnLoadingCompleted>b__0 0x2c96958
02c96958: ldr     x8, [x0, #0x10]                            .<>4__this
02c9695c: cbz     x8, #0x2c96988                             
02c96960: ldr     x9, [x8, #0x20]                            
02c96964: cbz     x9, #0x2c96984                             
02c96968: ldr     x8, [x9, #0x40]                            
02c9696c: ldr     x2, [x0, #0x20]                            .errorMessage
02c96970: ldr     w1, [x0, #0x18]                            .errorCode
02c96974: ldr     x3, [x9, #0x28]                            
02c96978: ldr     x4, [x9, #0x18]                            
02c9697c: mov     x0, x8                                     
02c96980: br      x4                                         
02c96984: ret                                                
02c96988: str     x30, [sp, #-0x10]!                         
02c9698c: bl      #0x2b7105c                                 fn_2b7105c
#### CLASS AndroidOnFsnLoadListener/<>c__DisplayClass7_0 parent= object
#   field <>4__this                      AndroidOnFsnLoadListener                           off=0x10 attr=6 
#   field adSource                       string                                             off=0x18 attr=6 
#   field adUnitId                       string                                             off=0x20 attr=6 
#   field valueMicros                    double                                             off=0x28 attr=6 
#   field currencyCode                   string                                             off=0x30 attr=6 
## .ctor() -> void
---- AndroidOnFsnLoadListener/<>c__DisplayClass7_0::.ctor 0x2c96934
02c96934: mov     x1, xzr                                    
02c96938: b       #0x4e53e9c                                 System.Object::.ctor
## <OnAdPaid>b__0(object _) -> void
---- AndroidOnFsnLoadListener/<>c__DisplayClass7_0::<OnAdPaid>b__0 0x2c96990
02c96990: ldr     x8, [x0, #0x10]                            .<>4__this
02c96994: cbz     x8, #0x2c969c4                             
02c96998: ldr     x9, [x8, #0x30]                            
02c9699c: cbz     x9, #0x2c969c0                             
02c969a0: ldp     x1, x2, [x0, #0x18]                        .adSource
02c969a4: ldr     x8, [x9, #0x40]                            
02c969a8: ldr     x3, [x0, #0x30]                            .currencyCode
02c969ac: ldr     d0, [x0, #0x28]                            .valueMicros
02c969b0: ldr     x5, [x9, #0x18]                            
02c969b4: mov     x0, x8                                     
02c969b8: ldr     x4, [x9, #0x28]                            
02c969bc: br      x5                                         
02c969c0: ret                                                
02c969c4: str     x30, [sp, #-0x10]!                         
02c969c8: bl      #0x2b7105c                                 fn_2b7105c
#### CLASS AndroidOnFsnLoadListener parent= UnityEngine.AndroidJavaProxy
#   field onLoadingCompleted             System.Action`2<int,string>                        off=0x20 attr=21 
#   field onLoadingStarted               System.Action                                      off=0x28 attr=21 
#   field onAdPaid                       System.Action`4<string,string,double,string>       off=0x30 attr=21 
#   field mainThreadContext              System.Threading.SynchronizationContext            off=0x38 attr=21 
## .ctor(System.Action`2<int,string> onLoadingCompleted, System.Action onLoadingStarted, System.Action`4<string,string,double,string> onAdPaid) -> void
---- AndroidOnFsnLoadListener::.ctor 0x2c933dc
02c933dc: str     x30, [sp, #-0x40]!                         
02c933e0: stp     x24, x23, [sp, #0x10]                      
02c933e4: stp     x22, x21, [sp, #0x20]                      
02c933e8: stp     x20, x19, [sp, #0x30]                      
02c933ec: adrp    x24, #0x662f000                            
02c933f0: adrp    x23, #0x6263000                            
02c933f4: mov     x20, x3                                    
02c933f8: ldrb    w8, [x24, #0xa00]                          
02c933fc: ldr     x23, [x23, #0xec8]                         T:UnityEngine.AndroidJavaProxy
02c93400: mov     x21, x2                                    
02c93404: mov     x22, x1                                    
02c93408: mov     x19, x0                                    
02c9340c: tbnz    w8, #0, #0x2c93430                         
02c93410: adrp    x0, #0x6263000                             
02c93414: ldr     x0, [x0, #0xec8]                           T:UnityEngine.AndroidJavaProxy
02c93418: bl      #0x2b70db0                                 fn_2b70db0
02c9341c: adrp    x0, #0x6265000                             
02c93420: ldr     x0, [x0, #0x720]                           S:'com.ads.fsnforunity.fsnlib.OnFsnLoadListener'
02c93424: bl      #0x2b70db0                                 fn_2b70db0
02c93428: mov     w8, #1                                     
02c9342c: strb    w8, [x24, #0xa00]                          
02c93430: ldr     x0, [x23]                                  &2c5bbd4(=a9bd7bfdd503233f)
02c93434: adrp    x23, #0x6265000                            
02c93438: ldr     w8, [x0, #0xe4]                            [62650e4]=0 f=0,0
02c9343c: ldr     x23, [x23, #0x720]                         S:'com.ads.fsnforunity.fsnlib.OnFsnLoadListener'
02c93440: cbnz    w8, #0x2c93448                             
02c93444: bl      #0x2b70f30                                 fn_2b70f30
02c93448: ldr     x1, [x23]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9344c: mov     x0, x19                                    
02c93450: mov     x2, xzr                                    
02c93454: bl      #0x5ad2a78                                 UnityEngine.AndroidJavaProxy::.ctor
02c93458: mov     x0, x19                                    
02c9345c: mov     x1, x22                                    
02c93460: str     x22, [x0, #0x20]!                          .onLoadingCompleted
02c93464: bl      #0x2b70d54                                 fn_2b70d54
02c93468: mov     x0, x19                                    
02c9346c: mov     x1, x21                                    
02c93470: str     x21, [x0, #0x28]!                          .onLoadingStarted
02c93474: bl      #0x2b70d54                                 fn_2b70d54
02c93478: mov     x0, x19                                    
02c9347c: mov     x1, x20                                    
02c93480: str     x20, [x0, #0x30]!                          .onAdPaid
02c93484: bl      #0x2b70d54                                 fn_2b70d54
02c93488: mov     x0, xzr                                    
02c9348c: bl      #0x4e739d4                                 System.Threading.SynchronizationContext::get_Current
02c93490: str     x0, [x19, #0x38]!                          .mainThreadContext
02c93494: mov     x1, x0                                     
02c93498: mov     x0, x19                                    
02c9349c: ldp     x20, x19, [sp, #0x30]                      
02c934a0: ldp     x22, x21, [sp, #0x20]                      
02c934a4: ldp     x24, x23, [sp, #0x10]                      
02c934a8: ldr     x30, [sp], #0x40                           
02c934ac: b       #0x2b70d54                                 
## OnLoadingCompleted(int errorCode, string errorMessage) -> void
---- AndroidOnFsnLoadListener::OnLoadingCompleted 0x2c965d0
02c965d0: stp     x30, x23, [sp, #-0x30]!                    
02c965d4: stp     x22, x21, [sp, #0x10]                      
02c965d8: stp     x20, x19, [sp, #0x20]                      
02c965dc: adrp    x21, #0x662f000                            
02c965e0: adrp    x23, #0x6265000                            
02c965e4: mov     x20, x2                                    
02c965e8: ldrb    w8, [x21, #0xa01]                          
02c965ec: ldr     x23, [x23, #0x7e0]                         T:AndroidOnFsnLoadListener/<>c__DisplayClass5_0
02c965f0: mov     w22, w1                                    
02c965f4: mov     x19, x0                                    
02c965f8: tbnz    w8, #0, #0x2c96628                         
02c965fc: adrp    x0, #0x6265000                             
02c96600: ldr     x0, [x0, #0x7e8]                           T:System.Threading.SendOrPostCallback
02c96604: bl      #0x2b70db0                                 fn_2b70db0
02c96608: adrp    x0, #0x6265000                             
02c9660c: ldr     x0, [x0, #0x7f0]                           M:AndroidOnFsnLoadListener/<>c__DisplayClass5_0::<OnLoadingCompleted>b__0
02c96610: bl      #0x2b70db0                                 fn_2b70db0
02c96614: adrp    x0, #0x6265000                             
02c96618: ldr     x0, [x0, #0x7e0]                           T:AndroidOnFsnLoadListener/<>c__DisplayClass5_0
02c9661c: bl      #0x2b70db0                                 fn_2b70db0
02c96620: mov     w8, #1                                     
02c96624: strb    w8, [x21, #0xa01]                          
02c96628: ldr     x0, [x23]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9662c: bl      #0x2b7104c                                 fn_2b7104c
02c96630: mov     x1, xzr                                    
02c96634: mov     x21, x0                                    
02c96638: bl      #0x4e53e9c                                 System.Object::.ctor
02c9663c: cbz     x21, #0x2c966f8                            
02c96640: mov     x0, x21                                    
02c96644: mov     x1, x19                                    
02c96648: str     x19, [x0, #0x10]!                          
02c9664c: bl      #0x2b70d54                                 fn_2b70d54
02c96650: mov     x0, x21                                    
02c96654: mov     x1, x20                                    
02c96658: str     x20, [x0, #0x20]!                          .onLoadingCompleted
02c9665c: stur    w22, [x0, #-8]                             
02c96660: bl      #0x2b70d54                                 fn_2b70d54
02c96664: ldr     x20, [x19, #0x38]                          .mainThreadContext
02c96668: cbz     x20, #0x2c966bc                            
02c9666c: adrp    x8, #0x6265000                             
02c96670: adrp    x19, #0x6265000                            
02c96674: ldr     x8, [x8, #0x7e8]                           T:System.Threading.SendOrPostCallback
02c96678: ldr     x19, [x19, #0x7f0]                         M:AndroidOnFsnLoadListener/<>c__DisplayClass5_0::<OnLoadingCompleted>b__0
02c9667c: ldr     x0, [x8]                                   M:AdsManager::<OnApplicationPause>b__26_0
02c96680: bl      #0x2b7104c                                 fn_2b7104c
02c96684: ldr     x2, [x19]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c96688: mov     x1, x21                                    
02c9668c: mov     x3, xzr                                    
02c96690: mov     x19, x0                                    
02c96694: bl      #0x4e73098                                 System.Threading.SendOrPostCallback::.ctor
02c96698: ldr     x8, [x20]                                  
02c9669c: mov     x0, x20                                    
02c966a0: mov     x1, x19                                    
02c966a4: ldp     x20, x19, [sp, #0x20]                      
02c966a8: mov     x2, xzr                                    
02c966ac: ldp     x4, x3, [x8, #0x188]                       
02c966b0: ldp     x22, x21, [sp, #0x10]                      
02c966b4: ldp     x30, x23, [sp], #0x30                      
02c966b8: br      x4                                         
02c966bc: ldr     x8, [x19, #0x20]                           S:'dev log AdsManager show app open ad' .onLoadingCompleted
02c966c0: cbz     x8, #0x2c966e8                             
02c966c4: ldr     x2, [x21, #0x20]                           &2b706f0(=d65f03c0f9400800) .onLoadingCompleted
02c966c8: ldr     w1, [x21, #0x18]                           [662f018]=6000014 f=2.40742e-35,0
02c966cc: ldr     x0, [x8, #0x40]                            S:'done_ad'
02c966d0: ldp     x20, x19, [sp, #0x20]                      
02c966d4: ldr     x3, [x8, #0x28]                            T:AdsManager/<ISetAOAInterval>d__33
02c966d8: ldr     x4, [x8, #0x18]                            T:AdsManager/<IEHideAdResume>d__30
02c966dc: ldp     x22, x21, [sp, #0x10]                      
02c966e0: ldp     x30, x23, [sp], #0x30                      
02c966e4: br      x4                                         
02c966e8: ldp     x20, x19, [sp, #0x20]                      
02c966ec: ldp     x22, x21, [sp, #0x10]                      
02c966f0: ldp     x30, x23, [sp], #0x30                      
02c966f4: ret                                                
02c966f8: bl      #0x2b7105c                                 fn_2b7105c
## OnLoadingStarted() -> void
---- AndroidOnFsnLoadListener::OnLoadingStarted 0x2c96704
02c96704: stp     x30, x21, [sp, #-0x20]!                    
02c96708: stp     x20, x19, [sp, #0x10]                      
02c9670c: adrp    x20, #0x662f000                            
02c96710: mov     x19, x0                                    
02c96714: ldrb    w8, [x20, #0xa02]                          
02c96718: tbnz    w8, #0, #0x2c9673c                         
02c9671c: adrp    x0, #0x6265000                             
02c96720: ldr     x0, [x0, #0x7f8]                           M:AndroidOnFsnLoadListener::<OnLoadingStarted>b__6_0
02c96724: bl      #0x2b70db0                                 fn_2b70db0
02c96728: adrp    x0, #0x6265000                             
02c9672c: ldr     x0, [x0, #0x7e8]                           T:System.Threading.SendOrPostCallback
02c96730: bl      #0x2b70db0                                 fn_2b70db0
02c96734: mov     w8, #1                                     
02c96738: strb    w8, [x20, #0xa02]                          
02c9673c: ldr     x20, [x19, #0x38]                          .mainThreadContext
02c96740: cbz     x20, #0x2c96790                            
02c96744: adrp    x8, #0x6265000                             
02c96748: adrp    x21, #0x6265000                            
02c9674c: ldr     x8, [x8, #0x7e8]                           T:System.Threading.SendOrPostCallback
02c96750: ldr     x21, [x21, #0x7f8]                         M:AndroidOnFsnLoadListener::<OnLoadingStarted>b__6_0
02c96754: ldr     x0, [x8]                                   M:AdsManager::<OnApplicationPause>b__26_0
02c96758: bl      #0x2b7104c                                 fn_2b7104c
02c9675c: ldr     x2, [x21]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c96760: mov     x1, x19                                    
02c96764: mov     x3, xzr                                    
02c96768: mov     x21, x0                                    
02c9676c: bl      #0x4e73098                                 System.Threading.SendOrPostCallback::.ctor
02c96770: ldr     x8, [x20]                                  &2b706c4(=eb01011ff9400808)
02c96774: mov     x0, x20                                    
02c96778: mov     x1, x21                                    
02c9677c: ldp     x20, x19, [sp, #0x10]                      
02c96780: mov     x2, xzr                                    
02c96784: ldp     x4, x3, [x8, #0x188]                       
02c96788: ldp     x30, x21, [sp], #0x20                      
02c9678c: br      x4                                         
02c96790: ldr     x8, [x19, #0x28]                           .onLoadingStarted
02c96794: cbz     x8, #0x2c967b0                             
02c96798: ldp     x20, x19, [sp, #0x10]                      
02c9679c: ldr     x0, [x8, #0x40]                            S:'done_ad'
02c967a0: ldr     x1, [x8, #0x28]                            T:AdsManager/<ISetAOAInterval>d__33
02c967a4: ldr     x2, [x8, #0x18]                            T:AdsManager/<IEHideAdResume>d__30
02c967a8: ldp     x30, x21, [sp], #0x20                      
02c967ac: br      x2                                         
02c967b0: ldp     x20, x19, [sp, #0x10]                      
02c967b4: ldp     x30, x21, [sp], #0x20                      
02c967b8: ret                                                
## OnAdPaid(string adSource, string adUnitId, double valueMicros, string currencyCode) -> void
---- AndroidOnFsnLoadListener::OnAdPaid 0x2c967bc
02c967bc: str     d8, [sp, #-0x40]!                          
02c967c0: str     x30, [sp, #8]                              
02c967c4: stp     x24, x23, [sp, #0x10]                      
02c967c8: stp     x22, x21, [sp, #0x20]                      
02c967cc: stp     x20, x19, [sp, #0x30]                      
02c967d0: fmov    d8, d0                                     
02c967d4: adrp    x21, #0x662f000                            
02c967d8: adrp    x24, #0x6265000                            
02c967dc: ldrb    w8, [x21, #0xa03]                          
02c967e0: ldr     x24, [x24, #0x800]                         T:AndroidOnFsnLoadListener/<>c__DisplayClass7_0
02c967e4: mov     x19, x3                                    
02c967e8: mov     x22, x2                                    
02c967ec: mov     x23, x1                                    
02c967f0: mov     x20, x0                                    
02c967f4: tbnz    w8, #0, #0x2c96824                         
02c967f8: adrp    x0, #0x6265000                             
02c967fc: ldr     x0, [x0, #0x7e8]                           T:System.Threading.SendOrPostCallback
02c96800: bl      #0x2b70db0                                 fn_2b70db0
02c96804: adrp    x0, #0x6265000                             
02c96808: ldr     x0, [x0, #0x808]                           M:AndroidOnFsnLoadListener/<>c__DisplayClass7_0::<OnAdPaid>b__0
02c9680c: bl      #0x2b70db0                                 fn_2b70db0
02c96810: adrp    x0, #0x6265000                             
02c96814: ldr     x0, [x0, #0x800]                           T:AndroidOnFsnLoadListener/<>c__DisplayClass7_0
02c96818: bl      #0x2b70db0                                 fn_2b70db0
02c9681c: mov     w8, #1                                     
02c96820: strb    w8, [x21, #0xa03]                          
02c96824: ldr     x0, [x24]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c96828: bl      #0x2b7104c                                 fn_2b7104c
02c9682c: mov     x1, xzr                                    
02c96830: mov     x21, x0                                    
02c96834: bl      #0x4e53e9c                                 System.Object::.ctor
02c96838: cbz     x21, #0x2c96930                            
02c9683c: mov     x0, x21                                    
02c96840: mov     x1, x20                                    
02c96844: str     x20, [x0, #0x10]!                          
02c96848: bl      #0x2b70d54                                 fn_2b70d54
02c9684c: mov     x0, x21                                    
02c96850: mov     x1, x23                                    
02c96854: str     x23, [x0, #0x18]!                          
02c96858: bl      #0x2b70d54                                 fn_2b70d54
02c9685c: mov     x0, x21                                    
02c96860: mov     x1, x22                                    
02c96864: str     x22, [x0, #0x20]!                          .onLoadingCompleted
02c96868: bl      #0x2b70d54                                 fn_2b70d54
02c9686c: mov     x0, x21                                    
02c96870: mov     x1, x19                                    
02c96874: str     x19, [x0, #0x30]!                          .onAdPaid
02c96878: stur    d8, [x0, #-8]                              
02c9687c: bl      #0x2b70d54                                 fn_2b70d54
02c96880: ldr     x19, [x20, #0x38]                          .mainThreadContext
02c96884: cbz     x19, #0x2c968e0                            
02c96888: adrp    x8, #0x6265000                             
02c9688c: adrp    x20, #0x6265000                            
02c96890: ldr     x8, [x8, #0x7e8]                           T:System.Threading.SendOrPostCallback
02c96894: ldr     x20, [x20, #0x808]                         M:AndroidOnFsnLoadListener/<>c__DisplayClass7_0::<OnAdPaid>b__0
02c96898: ldr     x0, [x8]                                   M:AdsManager::<OnApplicationPause>b__26_0
02c9689c: bl      #0x2b7104c                                 fn_2b7104c
02c968a0: ldr     x2, [x20]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c968a4: mov     x1, x21                                    
02c968a8: mov     x3, xzr                                    
02c968ac: mov     x20, x0                                    
02c968b0: bl      #0x4e73098                                 System.Threading.SendOrPostCallback::.ctor
02c968b4: ldr     x8, [x19]                                  
02c968b8: mov     x0, x19                                    
02c968bc: mov     x1, x20                                    
02c968c0: ldp     x20, x19, [sp, #0x30]                      
02c968c4: ldr     x30, [sp, #8]                              
02c968c8: ldp     x4, x3, [x8, #0x188]                       
02c968cc: mov     x2, xzr                                    
02c968d0: ldp     x22, x21, [sp, #0x20]                      
02c968d4: ldp     x24, x23, [sp, #0x10]                      
02c968d8: ldr     d8, [sp], #0x40                            
02c968dc: br      x4                                         
02c968e0: ldr     x8, [x20, #0x30]                           T:AdsManager/<>c__DisplayClass32_0 .onAdPaid
02c968e4: cbz     x8, #0x2c96918                             
02c968e8: ldr     x3, [x21, #0x30]                           &2b706f8(=d65f03c0b9401800) .onAdPaid
02c968ec: ldp     x1, x2, [x21, #0x18]                       
02c968f0: ldr     d0, [x21, #0x28]                           [662f028]=6000015 f=2.40742e-35,0 .onLoadingStarted
02c968f4: ldr     x0, [x8, #0x40]                            S:'done_ad'
02c968f8: ldr     x5, [x8, #0x18]                            T:AdsManager/<IEHideAdResume>d__30
02c968fc: ldr     x4, [x8, #0x28]                            T:AdsManager/<ISetAOAInterval>d__33
02c96900: ldr     x30, [sp, #8]                              
02c96904: ldp     x20, x19, [sp, #0x30]                      
02c96908: ldp     x22, x21, [sp, #0x20]                      
02c9690c: ldp     x24, x23, [sp, #0x10]                      
02c96910: ldr     d8, [sp], #0x40                            
02c96914: br      x5                                         
02c96918: ldp     x20, x19, [sp, #0x30]                      
02c9691c: ldr     x30, [sp, #8]                              
02c96920: ldp     x22, x21, [sp, #0x20]                      
02c96924: ldp     x24, x23, [sp, #0x10]                      
02c96928: ldr     d8, [sp], #0x40                            
02c9692c: ret                                                
02c96930: bl      #0x2b7105c                                 fn_2b7105c
## <OnLoadingStarted>b__6_0(object _) -> void
---- AndroidOnFsnLoadListener::<OnLoadingStarted>b__6_0 0x2c9693c
02c9693c: ldr     x8, [x0, #0x28]                            .onLoadingStarted
02c96940: cbz     x8, #0x2c96954                             
02c96944: ldr     x0, [x8, #0x40]                            
02c96948: ldr     x1, [x8, #0x28]                            
02c9694c: ldr     x2, [x8, #0x18]                            
02c96950: br      x2                                         
02c96954: ret                                                
