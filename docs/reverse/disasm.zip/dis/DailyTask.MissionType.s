#### CLASS DailyTask.MissionType parent= int
#   field value__                        int                                                off=0x10 attr=606 
#   field CollectCoin                    DailyTask.MissionType                              off=0x0 attr=8056 
#   field PlayTime                       DailyTask.MissionType                              off=0x0 attr=8056 
#   field LevelUp                        DailyTask.MissionType                              off=0x0 attr=8056 
#   field BuyItem                        DailyTask.MissionType                              off=0x0 attr=8056 
