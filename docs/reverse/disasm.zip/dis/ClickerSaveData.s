#### CLASS ClickerSaveData parent= object
#   field _maxKeycapAmount               int                                                off=0x10 attr=1 SerializeField
#   field _latestIndexCreated            int                                                off=0x14 attr=1 SerializeField
#   field _savedKeycap                   System.Collections.Generic.List`1<ClickerSaveDataItem> off=0x18 attr=1 SerializeField
## get_SavedKeycap() -> System.Collections.Generic.List`1<ClickerSaveDataItem>
---- ClickerSaveData::get_SavedKeycap 0x2ca8a24
02ca8a24: ldr     x0, [x0, #0x18]                            ._savedKeycap
02ca8a28: ret                                                
## set_SavedKeycap(System.Collections.Generic.List`1<ClickerSaveDataItem> value) -> void
---- ClickerSaveData::set_SavedKeycap 0x2ca8a2c
02ca8a2c: str     x1, [x0, #0x18]!                           ._savedKeycap
02ca8a30: b       #0x2b70d54                                 
## get_MaxKeycapAmount() -> int
---- ClickerSaveData::get_MaxKeycapAmount 0x2ca8a34
02ca8a34: ldr     w0, [x0, #0x10]                            ._maxKeycapAmount
02ca8a38: ret                                                
## set_MaxKeycapAmount(int value) -> void
---- ClickerSaveData::set_MaxKeycapAmount 0x2ca8a3c
02ca8a3c: str     w1, [x0, #0x10]                            ._maxKeycapAmount
02ca8a40: ret                                                
## get_LatestIndexCreated() -> int
---- ClickerSaveData::get_LatestIndexCreated 0x2ca8a44
02ca8a44: ldr     w0, [x0, #0x14]                            ._latestIndexCreated
02ca8a48: ret                                                
## set_LatestIndexCreated(int value) -> void
---- ClickerSaveData::set_LatestIndexCreated 0x2ca8a4c
02ca8a4c: str     w1, [x0, #0x14]                            ._latestIndexCreated
02ca8a50: ret                                                
## .ctor(int maxKeycapAmount, int latestIndexCreated, System.Collections.Generic.List`1<ClickerSaveDataItem> dataSave) -> void
---- ClickerSaveData::.ctor 0x2ca8a54
02ca8a54: str     x30, [sp, #-0x30]!                         
02ca8a58: stp     x22, x21, [sp, #0x10]                      
02ca8a5c: stp     x20, x19, [sp, #0x20]                      
02ca8a60: mov     w21, w1                                    
02ca8a64: mov     w8, #0xc                                   
02ca8a68: mov     x1, xzr                                    
02ca8a6c: mov     x19, x3                                    
02ca8a70: mov     w20, w2                                    
02ca8a74: mov     x22, x0                                    
02ca8a78: str     w8, [x0, #0x10]                            ._maxKeycapAmount
02ca8a7c: bl      #0x4e53e9c                                 System.Object::.ctor
02ca8a80: str     w21, [x22, #0x10]                          
02ca8a84: mov     x1, x19                                    
02ca8a88: str     x19, [x22, #0x18]!                         
02ca8a8c: mov     x0, x22                                    
02ca8a90: stur    w20, [x22, #-4]                            
02ca8a94: ldp     x20, x19, [sp, #0x20]                      
02ca8a98: ldp     x22, x21, [sp, #0x10]                      
02ca8a9c: ldr     x30, [sp], #0x30                           
02ca8aa0: b       #0x2b70d54                                 
## .ctor() -> void
---- ClickerSaveData::.ctor 0x2ca8aa4
02ca8aa4: str     x30, [sp, #-0x30]!                         
02ca8aa8: stp     x22, x21, [sp, #0x10]                      
02ca8aac: stp     x20, x19, [sp, #0x20]                      
02ca8ab0: adrp    x21, #0x662f000                            
02ca8ab4: adrp    x20, #0x6266000                            
02ca8ab8: mov     x19, x0                                    
02ca8abc: ldrb    w8, [x21, #0xb01]                          
02ca8ac0: ldr     x20, [x20, #0x5e0]                         T:GameConfig
02ca8ac4: tbnz    w8, #0, #0x2ca8af4                         
02ca8ac8: adrp    x0, #0x6266000                             
02ca8acc: ldr     x0, [x0, #0x5e0]                           T:GameConfig
02ca8ad0: bl      #0x2b70db0                                 fn_2b70db0
02ca8ad4: adrp    x0, #0x6266000                             
02ca8ad8: ldr     x0, [x0, #0x638]                           MS:System.Collections.Generic.List`1::.ctor
02ca8adc: bl      #0x2b70db0                                 fn_2b70db0
02ca8ae0: adrp    x0, #0x6266000                             
02ca8ae4: ldr     x0, [x0, #0x640]                           T:type14866(k15)
02ca8ae8: bl      #0x2b70db0                                 fn_2b70db0
02ca8aec: mov     w8, #1                                     
02ca8af0: strb    w8, [x21, #0xb01]                          
02ca8af4: adrp    x22, #0x6266000                            
02ca8af8: adrp    x21, #0x6266000                            
02ca8afc: mov     w8, #0xc                                   
02ca8b00: ldr     x22, [x22, #0x640]                         T:type14866(k15)
02ca8b04: ldr     x21, [x21, #0x638]                         MS:System.Collections.Generic.List`1::.ctor
02ca8b08: mov     x0, x19                                    
02ca8b0c: mov     x1, xzr                                    
02ca8b10: str     w8, [x19, #0x10]                           ._maxKeycapAmount
02ca8b14: bl      #0x4e53e9c                                 System.Object::.ctor
02ca8b18: ldr     x0, [x20]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca8b1c: ldr     w8, [x0, #0xe4]                            [62660e4]=0 f=0,0
02ca8b20: cbnz    w8, #0x2ca8b2c                             
02ca8b24: bl      #0x2b70f30                                 fn_2b70f30
02ca8b28: ldr     x0, [x20]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca8b2c: ldr     x8, [x0, #0xb8]                            S:'banner_native_refresh_time'
02ca8b30: ldr     x0, [x22]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca8b34: ldr     w8, [x8, #0xbc]                            
02ca8b38: stp     w8, wzr, [x19, #0x10]                      ._maxKeycapAmount
02ca8b3c: bl      #0x2b7104c                                 fn_2b7104c
02ca8b40: ldr     x1, [x21]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca8b44: mov     x20, x0                                    
02ca8b48: bl      #0x35a89a4                                 fn_35a89a4
02ca8b4c: str     x20, [x19, #0x18]!                         ._savedKeycap
02ca8b50: mov     x0, x19                                    
02ca8b54: mov     x1, x20                                    
02ca8b58: ldp     x20, x19, [sp, #0x20]                      
02ca8b5c: ldp     x22, x21, [sp, #0x10]                      
02ca8b60: ldr     x30, [sp], #0x30                           
02ca8b64: b       #0x2b70d54                                 
