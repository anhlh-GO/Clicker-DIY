#### CLASS Assets.SimpleLocalization.Scripts.LocalizedText parent= UnityEngine.MonoBehaviour
#   field LocalizationKey                string                                             off=0x20 attr=6 
## Start() -> void
---- Assets.SimpleLocalization.Scripts.LocalizedText::Start 0x2d7c8b8
02d7c8b8: stp     x30, x23, [sp, #-0x30]!                    
02d7c8bc: stp     x22, x21, [sp, #0x10]                      
02d7c8c0: stp     x20, x19, [sp, #0x20]                      
02d7c8c4: adrp    x23, #0x6630000                            
02d7c8c8: adrp    x22, #0x6264000                            
02d7c8cc: adrp    x20, #0x626c000                            
02d7c8d0: adrp    x21, #0x6266000                            
02d7c8d4: ldr     x22, [x22, #0xf90]                         T:System.Action
02d7c8d8: ldrb    w8, [x23, #0x41b]                          
02d7c8dc: ldr     x20, [x20, #0xc78]                         M:Assets.SimpleLocalization.Scripts.LocalizedText::Localize
02d7c8e0: ldr     x21, [x21, #0x9f0]                         T:Assets.SimpleLocalization.Scripts.LocalizationManager
02d7c8e4: mov     x19, x0                                    
02d7c8e8: tbnz    w8, #0, #0x2d7c918                         
02d7c8ec: adrp    x0, #0x6264000                             
02d7c8f0: ldr     x0, [x0, #0xf90]                           T:System.Action
02d7c8f4: bl      #0x2b70db0                                 fn_2b70db0
02d7c8f8: adrp    x0, #0x6266000                             
02d7c8fc: ldr     x0, [x0, #0x9f0]                           T:Assets.SimpleLocalization.Scripts.LocalizationManager
02d7c900: bl      #0x2b70db0                                 fn_2b70db0
02d7c904: adrp    x0, #0x626c000                             
02d7c908: ldr     x0, [x0, #0xc78]                           M:Assets.SimpleLocalization.Scripts.LocalizedText::Localize
02d7c90c: bl      #0x2b70db0                                 fn_2b70db0
02d7c910: mov     w8, #1                                     
02d7c914: strb    w8, [x23, #0x41b]                          
02d7c918: mov     x0, x19                                    
02d7c91c: bl      #0x2d7c960                                 Assets.SimpleLocalization.Scripts.LocalizedText::Localize
02d7c920: ldr     x0, [x22]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d7c924: bl      #0x2b7104c                                 fn_2b7104c
02d7c928: ldr     x2, [x20]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d7c92c: mov     x1, x19                                    
02d7c930: mov     x3, xzr                                    
02d7c934: mov     x20, x0                                    
02d7c938: bl      #0x4d8ddbc                                 System.Action::.ctor
02d7c93c: ldr     x0, [x21]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d7c940: ldr     w8, [x0, #0xe4]                            [626c0e4]=0 f=0,0
02d7c944: cbnz    w8, #0x2d7c94c                             
02d7c948: bl      #0x2b70f30                                 fn_2b70f30
02d7c94c: mov     x0, x20                                    
02d7c950: ldp     x20, x19, [sp, #0x20]                      
02d7c954: ldp     x22, x21, [sp, #0x10]                      
02d7c958: ldp     x30, x23, [sp], #0x30                      
02d7c95c: b       #0x2d7ad04                                 Assets.SimpleLocalization.Scripts.LocalizationManager::add_OnLocalizationChanged
## OnDestroy() -> void
---- Assets.SimpleLocalization.Scripts.LocalizedText::OnDestroy 0x2d7ca08
02d7ca08: stp     x30, x23, [sp, #-0x30]!                    
02d7ca0c: stp     x22, x21, [sp, #0x10]                      
02d7ca10: stp     x20, x19, [sp, #0x20]                      
02d7ca14: adrp    x22, #0x6630000                            
02d7ca18: adrp    x23, #0x6264000                            
02d7ca1c: adrp    x20, #0x626c000                            
02d7ca20: adrp    x21, #0x6266000                            
02d7ca24: ldr     x23, [x23, #0xf90]                         T:System.Action
02d7ca28: ldrb    w8, [x22, #0x41c]                          
02d7ca2c: ldr     x20, [x20, #0xc78]                         M:Assets.SimpleLocalization.Scripts.LocalizedText::Localize
02d7ca30: ldr     x21, [x21, #0x9f0]                         T:Assets.SimpleLocalization.Scripts.LocalizationManager
02d7ca34: mov     x19, x0                                    
02d7ca38: tbnz    w8, #0, #0x2d7ca68                         
02d7ca3c: adrp    x0, #0x6264000                             
02d7ca40: ldr     x0, [x0, #0xf90]                           T:System.Action
02d7ca44: bl      #0x2b70db0                                 fn_2b70db0
02d7ca48: adrp    x0, #0x6266000                             
02d7ca4c: ldr     x0, [x0, #0x9f0]                           T:Assets.SimpleLocalization.Scripts.LocalizationManager
02d7ca50: bl      #0x2b70db0                                 fn_2b70db0
02d7ca54: adrp    x0, #0x626c000                             
02d7ca58: ldr     x0, [x0, #0xc78]                           M:Assets.SimpleLocalization.Scripts.LocalizedText::Localize
02d7ca5c: bl      #0x2b70db0                                 fn_2b70db0
02d7ca60: mov     w8, #1                                     
02d7ca64: strb    w8, [x22, #0x41c]                          
02d7ca68: ldr     x0, [x23]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d7ca6c: bl      #0x2b7104c                                 fn_2b7104c
02d7ca70: ldr     x2, [x20]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d7ca74: mov     x1, x19                                    
02d7ca78: mov     x3, xzr                                    
02d7ca7c: mov     x20, x0                                    
02d7ca80: bl      #0x4d8ddbc                                 System.Action::.ctor
02d7ca84: ldr     x0, [x21]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d7ca88: ldr     w8, [x0, #0xe4]                            [626c0e4]=0 f=0,0
02d7ca8c: cbnz    w8, #0x2d7ca94                             
02d7ca90: bl      #0x2b70f30                                 fn_2b70f30
02d7ca94: mov     x0, x20                                    
02d7ca98: ldp     x20, x19, [sp, #0x20]                      
02d7ca9c: ldp     x22, x21, [sp, #0x10]                      
02d7caa0: ldp     x30, x23, [sp], #0x30                      
02d7caa4: b       #0x2d7b144                                 Assets.SimpleLocalization.Scripts.LocalizationManager::remove_OnLocalizationChanged
## Localize() -> void
---- Assets.SimpleLocalization.Scripts.LocalizedText::Localize 0x2d7c960
02d7c960: str     x30, [sp, #-0x30]!                         
02d7c964: stp     x22, x21, [sp, #0x10]                      
02d7c968: stp     x20, x19, [sp, #0x20]                      
02d7c96c: adrp    x21, #0x6630000                            
02d7c970: adrp    x22, #0x626c000                            
02d7c974: adrp    x20, #0x6266000                            
02d7c978: ldrb    w8, [x21, #0x41d]                          
02d7c97c: ldr     x22, [x22, #0xc80]                         MS:UnityEngine.Component::GetComponent
02d7c980: ldr     x20, [x20, #0x9f0]                         T:Assets.SimpleLocalization.Scripts.LocalizationManager
02d7c984: mov     x19, x0                                    
02d7c988: tbnz    w8, #0, #0x2d7c9ac                         
02d7c98c: adrp    x0, #0x626c000                             
02d7c990: ldr     x0, [x0, #0xc80]                           MS:UnityEngine.Component::GetComponent
02d7c994: bl      #0x2b70db0                                 fn_2b70db0
02d7c998: adrp    x0, #0x6266000                             
02d7c99c: ldr     x0, [x0, #0x9f0]                           T:Assets.SimpleLocalization.Scripts.LocalizationManager
02d7c9a0: bl      #0x2b70db0                                 fn_2b70db0
02d7c9a4: mov     w8, #1                                     
02d7c9a8: strb    w8, [x21, #0x41d]                          
02d7c9ac: ldr     x1, [x22]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d7c9b0: mov     x0, x19                                    
02d7c9b4: bl      #0x3140c84                                 fn_3140c84
02d7c9b8: ldr     x8, [x20]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d7c9bc: ldr     x20, [x19, #0x20]                          .LocalizationKey
02d7c9c0: mov     x19, x0                                    
02d7c9c4: ldr     w9, [x8, #0xe4]                            
02d7c9c8: cbnz    w9, #0x2d7c9d4                             
02d7c9cc: mov     x0, x8                                     
02d7c9d0: bl      #0x2b70f30                                 fn_2b70f30
02d7c9d4: mov     x0, x20                                    
02d7c9d8: bl      #0x2d76794                                 Assets.SimpleLocalization.Scripts.LocalizationManager::Localize
02d7c9dc: cbz     x19, #0x2d7ca04                            
02d7c9e0: ldr     x8, [x19]                                  
02d7c9e4: mov     x1, x0                                     
02d7c9e8: mov     x0, x19                                    
02d7c9ec: ldp     x20, x19, [sp, #0x20]                      
02d7c9f0: ldp     x22, x21, [sp, #0x10]                      
02d7c9f4: ldr     x2, [x8, #0x5f0]                           
02d7c9f8: ldr     x3, [x8, #0x5e8]                           
02d7c9fc: ldr     x30, [sp], #0x30                           
02d7ca00: br      x3                                         
02d7ca04: bl      #0x2b7105c                                 fn_2b7105c
## .ctor() -> void
---- Assets.SimpleLocalization.Scripts.LocalizedText::.ctor 0x2d7caa8
02d7caa8: mov     x1, xzr                                    
02d7caac: b       #0x5b397b0                                 UnityEngine.MonoBehaviour::.ctor
