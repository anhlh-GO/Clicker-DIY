#### CLASS Clicker.KeychainConfig/<>c__DisplayClass8_0 parent= object
#   field id                             int                                                off=0x10 attr=6 
## .ctor() -> void
---- Clicker.KeychainConfig/<>c__DisplayClass8_0::.ctor 0x2d5bbe8
02d5bbe8: mov     x1, xzr                                    
02d5bbec: b       #0x4e53e9c                                 System.Object::.ctor
## <GetData>b__0(Clicker.KeychainItemData data) -> bool
---- Clicker.KeychainConfig/<>c__DisplayClass8_0::<GetData>b__0 0x2d5bbf8
02d5bbf8: cbz     x1, #0x2d5bc10                             
02d5bbfc: ldr     w8, [x1, #0x10]                            
02d5bc00: ldr     w9, [x0, #0x10]                            .id
02d5bc04: cmp     w8, w9                                     
02d5bc08: cset    w0, eq                                     
02d5bc0c: ret                                                
02d5bc10: str     x30, [sp, #-0x10]!                         
02d5bc14: bl      #0x2b7105c                                 fn_2b7105c
## <GetData>b__1(Clicker.KeychainItemData data) -> bool
---- Clicker.KeychainConfig/<>c__DisplayClass8_0::<GetData>b__1 0x2d5bc18
02d5bc18: cbz     x1, #0x2d5bc30                             
02d5bc1c: ldr     w8, [x1, #0x10]                            
02d5bc20: ldr     w9, [x0, #0x10]                            .id
02d5bc24: cmp     w8, w9                                     
02d5bc28: cset    w0, eq                                     
02d5bc2c: ret                                                
02d5bc30: str     x30, [sp, #-0x10]!                         
02d5bc34: bl      #0x2b7105c                                 fn_2b7105c
#### CLASS Clicker.KeychainConfig parent= Clicker.GameConfig
#   field _dataList                      System.Collections.Generic.List`1<Clicker.KeychainItemData> off=0x18 attr=1 SerializeField
#   field _dataListAB                    System.Collections.Generic.List`1<Clicker.KeychainItemData> off=0x20 attr=1 SerializeField
#   field _icons                         System.Collections.Generic.List`1<UnityEngine.Sprite> off=0x28 attr=1 SerializeField
#   field _visuals                       System.Collections.Generic.List`1<UnityEngine.Sprite> off=0x30 attr=1 SerializeField
## get_DataList() -> System.Collections.Generic.List`1<Clicker.KeychainItemData>
---- Clicker.KeychainConfig::get_DataList 0x2d5b930
02d5b930: stp     x30, x21, [sp, #-0x20]!                    
02d5b934: stp     x20, x19, [sp, #0x10]                      
02d5b938: adrp    x21, #0x6630000                            
02d5b93c: adrp    x20, #0x6264000                            
02d5b940: mov     x19, x0                                    
02d5b944: ldrb    w8, [x21, #0x2c5]                          
02d5b948: ldr     x20, [x20, #0xfc0]                         T:RemoteConfigManager
02d5b94c: tbnz    w8, #0, #0x2d5b964                         
02d5b950: adrp    x0, #0x6264000                             
02d5b954: ldr     x0, [x0, #0xfc0]                           T:RemoteConfigManager
02d5b958: bl      #0x2b70db0                                 fn_2b70db0
02d5b95c: mov     w8, #1                                     
02d5b960: strb    w8, [x21, #0x2c5]                          
02d5b964: ldr     x0, [x20]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d5b968: ldr     w8, [x0, #0xe4]                            [62640e4]=0 f=0,0
02d5b96c: cbnz    w8, #0x2d5b974                             
02d5b970: bl      #0x2b70f30                                 fn_2b70f30
02d5b974: adrp    x21, #0x662f000                            
02d5b978: ldrb    w8, [x21, #0xbc1]                          
02d5b97c: cbnz    w8, #0x2d5b994                             
02d5b980: adrp    x0, #0x6264000                             
02d5b984: ldr     x0, [x0, #0xfc0]                           T:RemoteConfigManager
02d5b988: bl      #0x2b70db0                                 fn_2b70db0
02d5b98c: mov     w8, #1                                     
02d5b990: strb    w8, [x21, #0xbc1]                          
02d5b994: ldr     x0, [x20]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d5b998: ldr     w8, [x0, #0xe4]                            [62640e4]=0 f=0,0
02d5b99c: cbnz    w8, #0x2d5b9a8                             
02d5b9a0: bl      #0x2b70f30                                 fn_2b70f30
02d5b9a4: ldr     x0, [x20]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d5b9a8: ldr     x8, [x0, #0xb8]                            MS:DG.Tweening.Core.Extensions::SetSpecialStartupMode
02d5b9ac: mov     w9, #0x18                                  
02d5b9b0: ldr     w8, [x8, #0x10]                            
02d5b9b4: cmp     w8, #1                                     
02d5b9b8: mov     w8, #0x20                                  
02d5b9bc: csel    x8, x9, x8, eq                             
02d5b9c0: ldr     x0, [x19, x8]                              
02d5b9c4: ldp     x20, x19, [sp, #0x10]                      
02d5b9c8: ldp     x30, x21, [sp], #0x20                      
02d5b9cc: ret                                                
## get_Count() -> int
---- Clicker.KeychainConfig::get_Count 0x2d5b9d0
02d5b9d0: stp     x30, x21, [sp, #-0x20]!                    
02d5b9d4: stp     x20, x19, [sp, #0x10]                      
02d5b9d8: adrp    x21, #0x6630000                            
02d5b9dc: adrp    x20, #0x6264000                            
02d5b9e0: mov     x19, x0                                    
02d5b9e4: ldrb    w8, [x21, #0x2c6]                          
02d5b9e8: ldr     x20, [x20, #0xfc0]                         T:RemoteConfigManager
02d5b9ec: tbnz    w8, #0, #0x2d5ba10                         
02d5b9f0: adrp    x0, #0x626b000                             
02d5b9f4: ldr     x0, [x0, #0xc70]                           MS:System.Collections.Generic.List`1::get_Count
02d5b9f8: bl      #0x2b70db0                                 fn_2b70db0
02d5b9fc: adrp    x0, #0x6264000                             
02d5ba00: ldr     x0, [x0, #0xfc0]                           T:RemoteConfigManager
02d5ba04: bl      #0x2b70db0                                 fn_2b70db0
02d5ba08: mov     w8, #1                                     
02d5ba0c: strb    w8, [x21, #0x2c6]                          
02d5ba10: ldr     x0, [x20]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d5ba14: ldr     w8, [x0, #0xe4]                            [62640e4]=0 f=0,0
02d5ba18: cbnz    w8, #0x2d5ba20                             
02d5ba1c: bl      #0x2b70f30                                 fn_2b70f30
02d5ba20: adrp    x21, #0x662f000                            
02d5ba24: ldrb    w8, [x21, #0xbc1]                          
02d5ba28: cbnz    w8, #0x2d5ba40                             
02d5ba2c: adrp    x0, #0x6264000                             
02d5ba30: ldr     x0, [x0, #0xfc0]                           T:RemoteConfigManager
02d5ba34: bl      #0x2b70db0                                 fn_2b70db0
02d5ba38: mov     w8, #1                                     
02d5ba3c: strb    w8, [x21, #0xbc1]                          
02d5ba40: ldr     x0, [x20]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d5ba44: ldr     w8, [x0, #0xe4]                            [62640e4]=0 f=0,0
02d5ba48: cbnz    w8, #0x2d5ba54                             
02d5ba4c: bl      #0x2b70f30                                 fn_2b70f30
02d5ba50: ldr     x0, [x20]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d5ba54: ldr     x8, [x0, #0xb8]                            MS:DG.Tweening.Core.Extensions::SetSpecialStartupMode
02d5ba58: ldr     w8, [x8, #0x10]                            
02d5ba5c: cmp     w8, #1                                     
02d5ba60: b.ne    #0x2d5ba70                                 
02d5ba64: ldr     x8, [x19, #0x18]                           ._dataList
02d5ba68: cbnz    x8, #0x2d5ba78                             
02d5ba6c: bl      #0x2b7105c                                 fn_2b7105c
02d5ba70: ldr     x8, [x19, #0x20]                           ._dataListAB
02d5ba74: cbz     x8, #0x2d5ba6c                             
02d5ba78: ldp     x20, x19, [sp, #0x10]                      
02d5ba7c: ldr     w0, [x8, #0x18]                            
02d5ba80: ldp     x30, x21, [sp], #0x20                      
02d5ba84: ret                                                
## GetData(int id) -> Clicker.KeychainItemData
---- Clicker.KeychainConfig::GetData 0x2d5ba88
02d5ba88: str     x30, [sp, #-0x30]!                         
02d5ba8c: stp     x22, x21, [sp, #0x10]                      
02d5ba90: stp     x20, x19, [sp, #0x20]                      
02d5ba94: adrp    x20, #0x6630000                            
02d5ba98: adrp    x22, #0x626b000                            
02d5ba9c: mov     w21, w1                                    
02d5baa0: ldrb    w8, [x20, #0x2c7]                          
02d5baa4: ldr     x22, [x22, #0xc78]                         T:Clicker.KeychainConfig/<>c__DisplayClass8_0
02d5baa8: mov     x19, x0                                    
02d5baac: tbnz    w8, #0, #0x2d5bb00                         
02d5bab0: adrp    x0, #0x626b000                             
02d5bab4: ldr     x0, [x0, #0xc80]                           MS:System.Collections.Generic.List`1::Find
02d5bab8: bl      #0x2b70db0                                 fn_2b70db0
02d5babc: adrp    x0, #0x626b000                             
02d5bac0: ldr     x0, [x0, #0xc88]                           T:type57256(k15)
02d5bac4: bl      #0x2b70db0                                 fn_2b70db0
02d5bac8: adrp    x0, #0x6264000                             
02d5bacc: ldr     x0, [x0, #0xfc0]                           T:RemoteConfigManager
02d5bad0: bl      #0x2b70db0                                 fn_2b70db0
02d5bad4: adrp    x0, #0x626b000                             
02d5bad8: ldr     x0, [x0, #0xc90]                           M:Clicker.KeychainConfig/<>c__DisplayClass8_0::<GetData>b__0
02d5badc: bl      #0x2b70db0                                 fn_2b70db0
02d5bae0: adrp    x0, #0x626b000                             
02d5bae4: ldr     x0, [x0, #0xc98]                           M:Clicker.KeychainConfig/<>c__DisplayClass8_0::<GetData>b__1
02d5bae8: bl      #0x2b70db0                                 fn_2b70db0
02d5baec: adrp    x0, #0x626b000                             
02d5baf0: ldr     x0, [x0, #0xc78]                           T:Clicker.KeychainConfig/<>c__DisplayClass8_0
02d5baf4: bl      #0x2b70db0                                 fn_2b70db0
02d5baf8: mov     w8, #1                                     
02d5bafc: strb    w8, [x20, #0x2c7]                          
02d5bb00: ldr     x0, [x22]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d5bb04: bl      #0x2b7104c                                 fn_2b7104c
02d5bb08: mov     x1, xzr                                    
02d5bb0c: mov     x20, x0                                    
02d5bb10: bl      #0x4e53e9c                                 System.Object::.ctor
02d5bb14: cbz     x20, #0x2d5bbe4                            
02d5bb18: adrp    x22, #0x6264000                            
02d5bb1c: ldr     x22, [x22, #0xfc0]                         T:RemoteConfigManager
02d5bb20: str     w21, [x20, #0x10]                          
02d5bb24: ldr     x0, [x22]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d5bb28: ldr     w8, [x0, #0xe4]                            [626b0e4]=0 f=0,0
02d5bb2c: cbnz    w8, #0x2d5bb34                             
02d5bb30: bl      #0x2b70f30                                 fn_2b70f30
02d5bb34: adrp    x21, #0x662f000                            
02d5bb38: ldrb    w8, [x21, #0xbc1]                          
02d5bb3c: cbnz    w8, #0x2d5bb54                             
02d5bb40: adrp    x0, #0x6264000                             
02d5bb44: ldr     x0, [x0, #0xfc0]                           T:RemoteConfigManager
02d5bb48: bl      #0x2b70db0                                 fn_2b70db0
02d5bb4c: mov     w8, #1                                     
02d5bb50: strb    w8, [x21, #0xbc1]                          
02d5bb54: ldr     x0, [x22]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d5bb58: adrp    x21, #0x626b000                            
02d5bb5c: ldr     w8, [x0, #0xe4]                            [62640e4]=0 f=0,0
02d5bb60: ldr     x21, [x21, #0xc88]                         T:type57256(k15)
02d5bb64: cbnz    w8, #0x2d5bb70                             
02d5bb68: bl      #0x2b70f30                                 fn_2b70f30
02d5bb6c: ldr     x0, [x22]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d5bb70: ldr     x8, [x0, #0xb8]                            MS:DG.Tweening.Core.Extensions::SetSpecialStartupMode
02d5bb74: ldr     x0, [x21]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d5bb78: ldr     w8, [x8, #0x10]                            
02d5bb7c: cmp     w8, #1                                     
02d5bb80: b.ne    #0x2d5bb98                                 
02d5bb84: ldr     x19, [x19, #0x18]                          ._dataList
02d5bb88: bl      #0x2b7104c                                 fn_2b7104c
02d5bb8c: adrp    x8, #0x626b000                             
02d5bb90: ldr     x8, [x8, #0xc90]                           M:Clicker.KeychainConfig/<>c__DisplayClass8_0::<GetData>b__0
02d5bb94: b       #0x2d5bba8                                 
02d5bb98: ldr     x19, [x19, #0x20]                          ._dataListAB
02d5bb9c: bl      #0x2b7104c                                 fn_2b7104c
02d5bba0: adrp    x8, #0x626b000                             
02d5bba4: ldr     x8, [x8, #0xc98]                           M:Clicker.KeychainConfig/<>c__DisplayClass8_0::<GetData>b__1
02d5bba8: ldr     x2, [x8]                                   T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d5bbac: mov     x1, x20                                    
02d5bbb0: mov     x3, xzr                                    
02d5bbb4: mov     x21, x0                                    
02d5bbb8: bl      #0x399ba10                                 fn_399ba10
02d5bbbc: cbz     x19, #0x2d5bbe4                            
02d5bbc0: adrp    x8, #0x626b000                             
02d5bbc4: mov     x0, x19                                    
02d5bbc8: mov     x1, x21                                    
02d5bbcc: ldr     x8, [x8, #0xc80]                           MS:System.Collections.Generic.List`1::Find
02d5bbd0: ldp     x20, x19, [sp, #0x20]                      
02d5bbd4: ldp     x22, x21, [sp, #0x10]                      
02d5bbd8: ldr     x2, [x8]                                   T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d5bbdc: ldr     x30, [sp], #0x30                           
02d5bbe0: b       #0x35a9868                                 
02d5bbe4: bl      #0x2b7105c                                 fn_2b7105c
## .ctor() -> void
---- Clicker.KeychainConfig::.ctor 0x2d5bbf0
02d5bbf0: mov     x1, xzr                                    
02d5bbf4: b       #0x5b398f0                                 UnityEngine.ScriptableObject::.ctor
