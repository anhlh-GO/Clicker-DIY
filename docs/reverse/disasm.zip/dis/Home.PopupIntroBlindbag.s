#### CLASS Home.PopupIntroBlindbag/<OnShow>d__12 parent= System.ValueType
#   field <>1__state                     int                                                off=0x10 attr=6 
#   field <>t__builder                   System.Runtime.CompilerServices.AsyncVoidMethodBuilder off=0x18 attr=6 
#   field <>4__this                      Home.PopupIntroBlindbag                            off=0x38 attr=6 
#   field <>u__1                         Cysharp.Threading.Tasks.UniTask/Awaiter            off=0x40 attr=1 
## MoveNext() -> void
---- Home.PopupIntroBlindbag/<OnShow>d__12::MoveNext 0x2d1ff54
02d1ff54: sub     sp, sp, #0x70                              
02d1ff58: str     x30, [sp, #0x30]                           
02d1ff5c: stp     x24, x23, [sp, #0x40]                      
02d1ff60: stp     x22, x21, [sp, #0x50]                      
02d1ff64: stp     x20, x19, [sp, #0x60]                      
02d1ff68: adrp    x20, #0x6630000                            
02d1ff6c: mov     x19, x0                                    
02d1ff70: ldrb    w8, [x20, #0x44]                           
02d1ff74: tbnz    w8, #0, #0x2d20004                         
02d1ff78: adrp    x0, #0x6269000                             
02d1ff7c: ldr     x0, [x0, #0xde0]                           MS:System.Runtime.CompilerServices.AsyncVoidMethodBuilder::AwaitUnsafeOnCompleted
02d1ff80: bl      #0x2b70db0                                 fn_2b70db0
02d1ff84: adrp    x0, #0x6266000                             
02d1ff88: ldr     x0, [x0, #0x750]                           MS:DataManager::GetData
02d1ff8c: bl      #0x2b70db0                                 fn_2b70db0
02d1ff90: adrp    x0, #0x6265000                             
02d1ff94: ldr     x0, [x0, #0xb38]                           T:DevTrack
02d1ff98: bl      #0x2b70db0                                 fn_2b70db0
02d1ff9c: adrp    x0, #0x6266000                             
02d1ffa0: ldr     x0, [x0, #0x9f0]                           T:Assets.SimpleLocalization.Scripts.LocalizationManager
02d1ffa4: bl      #0x2b70db0                                 fn_2b70db0
02d1ffa8: adrp    x0, #0x6266000                             
02d1ffac: ldr     x0, [x0, #0xac0]                           MS:MonoSingleton`1::get_Instance
02d1ffb0: bl      #0x2b70db0                                 fn_2b70db0
02d1ffb4: adrp    x0, #0x6266000                             
02d1ffb8: ldr     x0, [x0, #0x658]                           MS:MonoSingleton`1::get_Instance
02d1ffbc: bl      #0x2b70db0                                 fn_2b70db0
02d1ffc0: adrp    x0, #0x6263000                             
02d1ffc4: ldr     x0, [x0, #0x918]                           T:UnityEngine.Object
02d1ffc8: bl      #0x2b70db0                                 fn_2b70db0
02d1ffcc: adrp    x0, #0x6269000                             
02d1ffd0: ldr     x0, [x0, #0xde8]                           M:Home.PopupIntroBlindbag::<OnShow>b__12_0
02d1ffd4: bl      #0x2b70db0                                 fn_2b70db0
02d1ffd8: adrp    x0, #0x6264000                             
02d1ffdc: ldr     x0, [x0, #0xe8]                            T:DG.Tweening.TweenCallback
02d1ffe0: bl      #0x2b70db0                                 fn_2b70db0
02d1ffe4: adrp    x0, #0x6266000                             
02d1ffe8: ldr     x0, [x0, #0xcc8]                           T:Cysharp.Threading.Tasks.UniTask
02d1ffec: bl      #0x2b70db0                                 fn_2b70db0
02d1fff0: adrp    x0, #0x6266000                             
02d1fff4: ldr     x0, [x0, #0xd68]                           S:'Welcome !'
02d1fff8: bl      #0x2b70db0                                 fn_2b70db0
02d1fffc: mov     w8, #1                                     
02d20000: strb    w8, [x20, #0x44]                           
02d20004: adrp    x24, #0x6266000                            
02d20008: adrp    x23, #0x662f000                            
02d2000c: ldr     x24, [x24, #0xcc8]                         T:Cysharp.Threading.Tasks.UniTask
02d20010: ldr     w8, [x19]                                  
02d20014: ldr     x20, [x19, #0x28]                          
02d20018: stp     xzr, xzr, [sp, #0x10]                      
02d2001c: str     wzr, [sp, #8]                              
02d20020: cbz     w8, #0x2d20044                             
02d20024: cmp     w8, #1                                     
02d20028: b.ne    #0x2d2005c                                 
02d2002c: ldr     q0, [x19, #0x30]                           
02d20030: mov     w8, #-1                                    
02d20034: stp     xzr, xzr, [x19, #0x30]                     
02d20038: str     w8, [x19]                                  
02d2003c: str     q0, [sp, #0x10]                            
02d20040: b       #0x2d204c0                                 
02d20044: ldr     q0, [x19, #0x30]                           
02d20048: mov     w8, #-1                                    
02d2004c: stp     xzr, xzr, [x19, #0x30]                     
02d20050: str     w8, [x19]                                  
02d20054: str     q0, [sp, #0x10]                            
02d20058: b       #0x2d20328                                 
02d2005c: adrp    x8, #0x6266000                             
02d20060: ldr     x8, [x8, #0x658]                           MS:MonoSingleton`1::get_Instance
02d20064: ldr     x0, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d20068: bl      #0x3769600                                 fn_3769600
02d2006c: cbz     x0, #0x2d20688                             
02d20070: adrp    x8, #0x6266000                             
02d20074: ldr     x8, [x8, #0x750]                           MS:DataManager::GetData
02d20078: ldr     x1, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d2007c: bl      #0x3168dd0                                 fn_3168dd0
02d20080: cbz     x0, #0x2d2068c                             
02d20084: ldr     x8, [x0, #0x20]                            S:'inter_ad_capping_time'
02d20088: cbz     x8, #0x2d20690                             
02d2008c: ldr     w8, [x8, #0x4c]                            [626604c]=0 f=0,0
02d20090: cbz     w8, #0x2d200bc                             
02d20094: cbz     x20, #0x2d206bc                            
02d20098: ldr     x0, [x20, #0x50]                           
02d2009c: cbz     x0, #0x2d206c0                             
02d200a0: mov     x1, xzr                                    
02d200a4: bl      #0x5b339ec                                 UnityEngine.Component::get_gameObject
02d200a8: cbz     x0, #0x2d206c4                             
02d200ac: mov     w1, #1                                     
02d200b0: mov     x2, xzr                                    
02d200b4: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d200b8: b       #0x2d200e0                                 
02d200bc: cbz     x20, #0x2d206c8                            
02d200c0: ldr     x0, [x20, #0x50]                           
02d200c4: cbz     x0, #0x2d206cc                             
02d200c8: mov     x1, xzr                                    
02d200cc: bl      #0x5b339ec                                 UnityEngine.Component::get_gameObject
02d200d0: cbz     x0, #0x2d206d0                             
02d200d4: mov     w1, wzr                                    
02d200d8: mov     x2, xzr                                    
02d200dc: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d200e0: adrp    x21, #0x6265000                            
02d200e4: ldr     x21, [x21, #0xb38]                         T:DevTrack
02d200e8: ldr     x0, [x21]                                  M:AdsManager::<OnApplicationPause>b__26_0
02d200ec: ldr     w8, [x0, #0xe4]                            [62660e4]=0 f=0,0
02d200f0: cbnz    w8, #0x2d200fc                             
02d200f4: bl      #0x2b70f30                                 fn_2b70f30
02d200f8: ldr     x0, [x21]                                  M:AdsManager::<OnApplicationPause>b__26_0
02d200fc: ldr     x8, [x0, #0xb8]                            S:'banner_native_refresh_time'
02d20100: ldr     x0, [x8, #0x350]                           S:"OnProductPurchased handler error for '{0}': {1}"
02d20104: mov     x1, xzr                                    
02d20108: bl      #0x2c9c4e4                                 DevTrack::GameModeEnter
02d2010c: ldr     x0, [x20, #0x70]                           
02d20110: cbz     x0, #0x2d20694                             
02d20114: mov     x1, xzr                                    
02d20118: bl      #0x2cddf7c                                 ProfilePanel::UpdateAvatar
02d2011c: cbz     x0, #0x2d20698                             
02d20120: mov     x1, xzr                                    
02d20124: bl      #0x2cddfec                                 ProfilePanel::UpdateLevel
02d20128: cbz     x0, #0x2d2069c                             
02d2012c: mov     x1, xzr                                    
02d20130: bl      #0x2cdda80                                 ProfilePanel::UpdateName
02d20134: cbz     x0, #0x2d206a0                             
02d20138: mov     x1, xzr                                    
02d2013c: bl      #0x2cdddfc                                 ProfilePanel::UpdateProgress
02d20140: cbz     x0, #0x2d206a4                             
02d20144: mov     x1, xzr                                    
02d20148: bl      #0x2cdddbc                                 ProfilePanel::OnShow
02d2014c: ldr     x0, [x20, #0x40]                           .<>u__1
02d20150: cbz     x0, #0x2d206a8                             
02d20154: mov     x1, xzr                                    
02d20158: bl      #0x5b339ec                                 UnityEngine.Component::get_gameObject
02d2015c: cbz     x0, #0x2d206ac                             
02d20160: mov     w1, wzr                                    
02d20164: mov     x2, xzr                                    
02d20168: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d2016c: ldr     x0, [x20, #0x40]                           .<>u__1
02d20170: cbz     x0, #0x2d206b0                             
02d20174: mov     w1, wzr                                    
02d20178: mov     x2, xzr                                    
02d2017c: bl      #0x5e662d4                                 UnityEngine.UI.Selectable::set_interactable
02d20180: mov     x0, x20                                    
02d20184: mov     x1, xzr                                    
02d20188: bl      #0x2cdd6b8                                 UIBase::OnShow
02d2018c: adrp    x8, #0x6263000                             
02d20190: ldr     x8, [x8, #0x918]                           T:UnityEngine.Object
02d20194: ldr     x21, [x20, #0x78]                          
02d20198: ldr     x0, [x8]                                   &2c5bbd4(=a9bd7bfdd503233f)
02d2019c: ldr     w8, [x0, #0xe4]                            [62660e4]=0 f=0,0
02d201a0: cbnz    w8, #0x2d201a8                             
02d201a4: bl      #0x2b70f30                                 fn_2b70f30
02d201a8: mov     x0, x21                                    
02d201ac: mov     x1, xzr                                    
02d201b0: mov     x2, xzr                                    
02d201b4: bl      #0x5b3666c                                 UnityEngine.Object::op_Inequality
02d201b8: tbz     w0, #0, #0x2d201cc                         
02d201bc: ldr     x0, [x20, #0x78]                           
02d201c0: cbz     x0, #0x2d201cc                             
02d201c4: mov     x1, xzr                                    
02d201c8: bl      #0x2d11ba0                                 Livestream.LivestreamPanel::OnShow
02d201cc: adrp    x8, #0x6266000                             
02d201d0: ldr     x8, [x8, #0x9f0]                           T:Assets.SimpleLocalization.Scripts.LocalizationManager
02d201d4: ldr     x21, [x20, #0x38]                          .<>4__this
02d201d8: ldr     x0, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d201dc: ldr     w8, [x0, #0xe4]                            [62660e4]=0 f=0,0
02d201e0: cbnz    w8, #0x2d201e8                             
02d201e4: bl      #0x2b70f30                                 fn_2b70f30
02d201e8: adrp    x8, #0x6266000                             
02d201ec: ldr     x8, [x8, #0xd68]                           S:'Welcome !'
02d201f0: ldr     x0, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d201f4: mov     x1, xzr                                    
02d201f8: bl      #0x2d76794                                 Assets.SimpleLocalization.Scripts.LocalizationManager::Localize
02d201fc: mov     x1, x0                                     
02d20200: cbz     x21, #0x2d206b4                            
02d20204: mov     x0, x21                                    
02d20208: mov     x2, xzr                                    
02d2020c: bl      #0x2cb6c58                                 CommentHandler::UserComment
02d20210: ldr     x8, [x20, #0x38]                           .<>4__this
02d20214: cbz     x8, #0x2d206b8                             
02d20218: mov     w9, #1                                     
02d2021c: ldr     x0, [x24]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d20220: strb    w9, [x8, #0x20]                            
02d20224: ldr     w8, [x0, #0xe4]                            [62660e4]=0 f=0,0
02d20228: cbnz    w8, #0x2d20230                             
02d2022c: bl      #0x2b70f30                                 fn_2b70f30
02d20230: fmov    s0, #1.00000000                            
02d20234: mov     w0, wzr                                    
02d20238: mov     w1, #8                                     
02d2023c: mov     x2, xzr                                    
02d20240: mov     w3, wzr                                    
02d20244: mov     x4, xzr                                    
02d20248: bl      #0x5447b08                                 Cysharp.Threading.Tasks.UniTask::WaitForSeconds
02d2024c: stp     x0, x1, [sp, #0x20]                        
02d20250: add     x0, sp, #0x20                              
02d20254: mov     x1, xzr                                    
02d20258: bl      #0x2b70d54                                 fn_2b70d54
02d2025c: adrp    x21, #0x662f000                            
02d20260: ldr     q0, [sp, #0x20]                            
02d20264: ldrb    w8, [x21, #0xbdc]                          
02d20268: str     q0, [sp, #0x10]                            
02d2026c: cbnz    w8, #0x2d20284                             
02d20270: adrp    x0, #0x6266000                             
02d20274: ldr     x0, [x0, #0xcc8]                           T:Cysharp.Threading.Tasks.UniTask
02d20278: bl      #0x2b70db0                                 fn_2b70db0
02d2027c: mov     w8, #1                                     
02d20280: strb    w8, [x21, #0xbdc]                          
02d20284: ldr     x0, [x24]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d20288: ldr     w8, [x0, #0xe4]                            [62660e4]=0 f=0,0
02d2028c: cbnz    w8, #0x2d20294                             
02d20290: bl      #0x2b70f30                                 fn_2b70f30
02d20294: adrp    x21, #0x662f000                            
02d20298: ldrb    w8, [x21, #0xbdd]                          
02d2029c: cbnz    w8, #0x2d202b4                             
02d202a0: adrp    x0, #0x6266000                             
02d202a4: ldr     x0, [x0, #0xcd0]                           T:Cysharp.Threading.Tasks.IUniTaskSource
02d202a8: bl      #0x2b70db0                                 fn_2b70db0
02d202ac: mov     w8, #1                                     
02d202b0: strb    w8, [x21, #0xbdd]                          
02d202b4: ldr     x21, [sp, #0x10]                           
02d202b8: cbz     x21, #0x2d20328                            
02d202bc: adrp    x10, #0x6266000                            
02d202c0: ldr     x8, [x21]                                  &2b706c4(=eb01011ff9400808)
02d202c4: ldr     x10, [x10, #0xcd0]                         T:Cysharp.Threading.Tasks.IUniTaskSource
02d202c8: ldrh    w22, [sp, #0x18]                           
02d202cc: ldrh    w9, [x8, #0x12e]                           
02d202d0: ldr     x1, [x10]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d202d4: cbz     x9, #0x2d202f8                             
02d202d8: ldr     x10, [x8, #0xb0]                           S:'native_banner_ad_on_off'
02d202dc: add     x10, x10, #8                               &6266008
02d202e0: ldur    x11, [x10, #-8]                            
02d202e4: cmp     x11, x1                                    
02d202e8: b.eq    #0x2d20308                                 
02d202ec: subs    x9, x9, #1                                 
02d202f0: add     x10, x10, #0x10                            &6266010
02d202f4: b.ne    #0x2d202e0                                 
02d202f8: mov     x0, x21                                    
02d202fc: mov     w2, wzr                                    
02d20300: bl      #0x2baa05c                                 fn_2baa05c
02d20304: b       #0x2d20314                                 
02d20308: ldrsw   x9, [x10]                                  
02d2030c: add     x8, x8, x9, lsl #4                         &6266000
02d20310: add     x0, x8, #0x138                             &6266138
02d20314: ldp     x8, x2, [x0]                               
02d20318: mov     x0, x21                                    
02d2031c: mov     w1, w22                                    
02d20320: blr     x8                                         
02d20324: cbz     w0, #0x2d20640                             
02d20328: ldrb    w8, [x23, #0xbde]                          
02d2032c: cbnz    w8, #0x2d20344                             
02d20330: adrp    x0, #0x6266000                             
02d20334: ldr     x0, [x0, #0xcd0]                           T:Cysharp.Threading.Tasks.IUniTaskSource
02d20338: bl      #0x2b70db0                                 fn_2b70db0
02d2033c: mov     w8, #1                                     
02d20340: strb    w8, [x23, #0xbde]                          
02d20344: ldr     x21, [sp, #0x10]                           
02d20348: cbz     x21, #0x2d203b8                            
02d2034c: adrp    x10, #0x6266000                            
02d20350: ldr     x8, [x21]                                  &2b706c4(=eb01011ff9400808)
02d20354: ldr     x10, [x10, #0xcd0]                         T:Cysharp.Threading.Tasks.IUniTaskSource
02d20358: ldrh    w22, [sp, #0x18]                           
02d2035c: ldrh    w9, [x8, #0x12e]                           
02d20360: ldr     x1, [x10]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d20364: cbz     x9, #0x2d20388                             
02d20368: ldr     x10, [x8, #0xb0]                           S:'native_banner_ad_on_off'
02d2036c: add     x10, x10, #8                               &6266008
02d20370: ldur    x11, [x10, #-8]                            
02d20374: cmp     x11, x1                                    
02d20378: b.eq    #0x2d20398                                 
02d2037c: subs    x9, x9, #1                                 
02d20380: add     x10, x10, #0x10                            &6266010
02d20384: b.ne    #0x2d20370                                 
02d20388: mov     x0, x21                                    
02d2038c: mov     w2, #2                                     
02d20390: bl      #0x2baa05c                                 fn_2baa05c
02d20394: b       #0x2d203a8                                 
02d20398: ldr     w9, [x10]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d2039c: add     w9, w9, #2                                 
02d203a0: add     x8, x8, w9, sxtw #4                        &6266000
02d203a4: add     x0, x8, #0x138                             &6266138
02d203a8: ldp     x8, x2, [x0]                               
02d203ac: mov     x0, x21                                    
02d203b0: mov     w1, w22                                    
02d203b4: blr     x8                                         
02d203b8: ldr     x0, [x24]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d203bc: ldr     w8, [x0, #0xe4]                            [62660e4]=0 f=0,0
02d203c0: cbnz    w8, #0x2d203c8                             
02d203c4: bl      #0x2b70f30                                 fn_2b70f30
02d203c8: fmov    s0, #1.00000000                            
02d203cc: mov     w0, wzr                                    
02d203d0: mov     w1, #8                                     
02d203d4: mov     x2, xzr                                    
02d203d8: mov     w3, wzr                                    
02d203dc: mov     x4, xzr                                    
02d203e0: bl      #0x5447b08                                 Cysharp.Threading.Tasks.UniTask::WaitForSeconds
02d203e4: stp     x0, x1, [sp, #0x20]                        
02d203e8: add     x0, sp, #0x20                              
02d203ec: mov     x1, xzr                                    
02d203f0: bl      #0x2b70d54                                 fn_2b70d54
02d203f4: adrp    x21, #0x662f000                            
02d203f8: ldr     q0, [sp, #0x20]                            
02d203fc: ldrb    w8, [x21, #0xbdc]                          
02d20400: str     q0, [sp, #0x10]                            
02d20404: cbnz    w8, #0x2d2041c                             
02d20408: adrp    x0, #0x6266000                             
02d2040c: ldr     x0, [x0, #0xcc8]                           T:Cysharp.Threading.Tasks.UniTask
02d20410: bl      #0x2b70db0                                 fn_2b70db0
02d20414: mov     w8, #1                                     
02d20418: strb    w8, [x21, #0xbdc]                          
02d2041c: ldr     x0, [x24]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d20420: ldr     w8, [x0, #0xe4]                            [62660e4]=0 f=0,0
02d20424: cbnz    w8, #0x2d2042c                             
02d20428: bl      #0x2b70f30                                 fn_2b70f30
02d2042c: adrp    x21, #0x662f000                            
02d20430: ldrb    w8, [x21, #0xbdd]                          
02d20434: cbnz    w8, #0x2d2044c                             
02d20438: adrp    x0, #0x6266000                             
02d2043c: ldr     x0, [x0, #0xcd0]                           T:Cysharp.Threading.Tasks.IUniTaskSource
02d20440: bl      #0x2b70db0                                 fn_2b70db0
02d20444: mov     w8, #1                                     
02d20448: strb    w8, [x21, #0xbdd]                          
02d2044c: ldr     x21, [sp, #0x10]                           
02d20450: cbz     x21, #0x2d204c0                            
02d20454: adrp    x10, #0x6266000                            
02d20458: ldr     x8, [x21]                                  &2b706c4(=eb01011ff9400808)
02d2045c: ldr     x10, [x10, #0xcd0]                         T:Cysharp.Threading.Tasks.IUniTaskSource
02d20460: ldrh    w22, [sp, #0x18]                           
02d20464: ldrh    w9, [x8, #0x12e]                           
02d20468: ldr     x1, [x10]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d2046c: cbz     x9, #0x2d20490                             
02d20470: ldr     x10, [x8, #0xb0]                           S:'native_banner_ad_on_off'
02d20474: add     x10, x10, #8                               &6266008
02d20478: ldur    x11, [x10, #-8]                            
02d2047c: cmp     x11, x1                                    
02d20480: b.eq    #0x2d204a0                                 
02d20484: subs    x9, x9, #1                                 
02d20488: add     x10, x10, #0x10                            &6266010
02d2048c: b.ne    #0x2d20478                                 
02d20490: mov     x0, x21                                    
02d20494: mov     w2, wzr                                    
02d20498: bl      #0x2baa05c                                 fn_2baa05c
02d2049c: b       #0x2d204ac                                 
02d204a0: ldrsw   x9, [x10]                                  
02d204a4: add     x8, x8, x9, lsl #4                         &6266000
02d204a8: add     x0, x8, #0x138                             &6266138
02d204ac: ldp     x8, x2, [x0]                               
02d204b0: mov     x0, x21                                    
02d204b4: mov     w1, w22                                    
02d204b8: blr     x8                                         
02d204bc: cbz     w0, #0x2d20604                             
02d204c0: ldrb    w8, [x23, #0xbde]                          
02d204c4: cbnz    w8, #0x2d204dc                             
02d204c8: adrp    x0, #0x6266000                             
02d204cc: ldr     x0, [x0, #0xcd0]                           T:Cysharp.Threading.Tasks.IUniTaskSource
02d204d0: bl      #0x2b70db0                                 fn_2b70db0
02d204d4: mov     w8, #1                                     
02d204d8: strb    w8, [x23, #0xbde]                          
02d204dc: ldr     x21, [sp, #0x10]                           
02d204e0: cbz     x21, #0x2d20550                            
02d204e4: adrp    x10, #0x6266000                            
02d204e8: ldr     x8, [x21]                                  &2b706c4(=eb01011ff9400808)
02d204ec: ldr     x10, [x10, #0xcd0]                         T:Cysharp.Threading.Tasks.IUniTaskSource
02d204f0: ldrh    w22, [sp, #0x18]                           
02d204f4: ldrh    w9, [x8, #0x12e]                           
02d204f8: ldr     x1, [x10]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d204fc: cbz     x9, #0x2d20520                             
02d20500: ldr     x10, [x8, #0xb0]                           S:'native_banner_ad_on_off'
02d20504: add     x10, x10, #8                               &6266008
02d20508: ldur    x11, [x10, #-8]                            
02d2050c: cmp     x11, x1                                    
02d20510: b.eq    #0x2d20530                                 
02d20514: subs    x9, x9, #1                                 
02d20518: add     x10, x10, #0x10                            &6266010
02d2051c: b.ne    #0x2d20508                                 
02d20520: mov     x0, x21                                    
02d20524: mov     w2, #2                                     
02d20528: bl      #0x2baa05c                                 fn_2baa05c
02d2052c: b       #0x2d20540                                 
02d20530: ldr     w9, [x10]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d20534: add     w9, w9, #2                                 
02d20538: add     x8, x8, w9, sxtw #4                        &6266000
02d2053c: add     x0, x8, #0x138                             &6266138
02d20540: ldp     x8, x2, [x0]                               
02d20544: mov     x0, x21                                    
02d20548: mov     w1, w22                                    
02d2054c: blr     x8                                         
02d20550: cbz     x20, #0x2d20678                            
02d20554: ldr     x0, [x20, #0x60]                           
02d20558: cbz     x0, #0x2d2067c                             
02d2055c: mov     x1, xzr                                    
02d20560: bl      #0x2cb4bfc                                 ViewerNameAsset::PickRandomContent
02d20564: ldr     x0, [x20, #0x68]                           
02d20568: cbz     x0, #0x2d20680                             
02d2056c: mov     x1, xzr                                    
02d20570: bl      #0x2cb4b80                                 ViewerAvatarAsset::PickRandom
02d20574: adrp    x8, #0x6266000                             
02d20578: mov     x21, x0                                    
02d2057c: ldr     x8, [x8, #0xac0]                           MS:MonoSingleton`1::get_Instance
02d20580: ldr     x0, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d20584: bl      #0x3769600                                 fn_3769600
02d20588: cbz     x0, #0x2d20684                             
02d2058c: str     x21, [x0, #0x68]!                          
02d20590: mov     x1, x21                                    
02d20594: bl      #0x2b70d54                                 fn_2b70d54
02d20598: adrp    x8, #0x6264000                             
02d2059c: ldr     x8, [x8, #0xe8]                            T:DG.Tweening.TweenCallback
02d205a0: ldr     x0, [x8]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d205a4: bl      #0x2b7104c                                 fn_2b7104c
02d205a8: adrp    x8, #0x6269000                             
02d205ac: mov     x21, x0                                    
02d205b0: ldr     x8, [x8, #0xde8]                           M:Home.PopupIntroBlindbag::<OnShow>b__12_0
02d205b4: ldr     x2, [x8]                                   T:Trading.TradingSession/<>c__DisplayClass56_0
02d205b8: mov     x1, x20                                    
02d205bc: mov     x3, xzr                                    
02d205c0: bl      #0x2d89dc4                                 DG.Tweening.TweenCallback::.ctor
02d205c4: fmov    s0, #0.50000000                            
02d205c8: mov     x0, x21                                    
02d205cc: mov     w1, #1                                     
02d205d0: mov     x2, xzr                                    
02d205d4: bl      #0x2d8f37c                                 DG.Tweening.DOVirtual::DelayedCall
02d205d8: mov     w8, #-2                                    
02d205dc: mov     x1, xzr                                    
02d205e0: str     w8, [x19], #8                              
02d205e4: mov     x0, x19                                    
02d205e8: bl      #0x4d43b50                                 System.Runtime.CompilerServices.AsyncVoidMethodBuilder::SetResult
02d205ec: ldp     x20, x19, [sp, #0x60]                      
02d205f0: ldr     x30, [sp, #0x30]                           
02d205f4: ldp     x22, x21, [sp, #0x50]                      
02d205f8: ldp     x24, x23, [sp, #0x40]                      
02d205fc: add     sp, sp, #0x70                              
02d20600: ret                                                
02d20604: ldr     q0, [sp, #0x10]                            
02d20608: mov     w8, #1                                     
02d2060c: str     w8, [x19]                                  
02d20610: str     q0, [x19, #0x30]                           
02d20614: add     x0, x19, #0x30                             
02d20618: mov     x1, xzr                                    
02d2061c: bl      #0x2b70d54                                 fn_2b70d54
02d20620: adrp    x8, #0x6269000                             
02d20624: ldr     x8, [x8, #0xde0]                           MS:System.Runtime.CompilerServices.AsyncVoidMethodBuilder::AwaitUnsafeOnCompleted
02d20628: ldr     x3, [x8]                                   T:Trading.TradingSession/<>c__DisplayClass56_0
02d2062c: add     x0, x19, #8                                
02d20630: add     x1, sp, #0x10                              
02d20634: mov     x2, x19                                    
02d20638: bl      #0x30c4324                                 fn_30c4324
02d2063c: b       #0x2d205ec                                 
02d20640: ldr     q0, [sp, #0x10]                            
02d20644: str     wzr, [x19]                                 
02d20648: str     q0, [x19, #0x30]                           
02d2064c: add     x0, x19, #0x30                             
02d20650: mov     x1, xzr                                    
02d20654: bl      #0x2b70d54                                 fn_2b70d54
02d20658: adrp    x8, #0x6269000                             
02d2065c: ldr     x8, [x8, #0xde0]                           MS:System.Runtime.CompilerServices.AsyncVoidMethodBuilder::AwaitUnsafeOnCompleted
02d20660: ldr     x3, [x8]                                   T:Trading.TradingSession/<>c__DisplayClass56_0
02d20664: add     x0, x19, #8                                
02d20668: add     x1, sp, #0x10                              
02d2066c: mov     x2, x19                                    
02d20670: bl      #0x30c4324                                 fn_30c4324
02d20674: b       #0x2d205ec                                 
02d20678: bl      #0x2b7105c                                 fn_2b7105c
02d2067c: bl      #0x2b7105c                                 fn_2b7105c
02d20680: bl      #0x2b7105c                                 fn_2b7105c
02d20684: bl      #0x2b7105c                                 fn_2b7105c
02d20688: bl      #0x2b7105c                                 fn_2b7105c
02d2068c: bl      #0x2b7105c                                 fn_2b7105c
02d20690: bl      #0x2b7105c                                 fn_2b7105c
02d20694: bl      #0x2b7105c                                 fn_2b7105c
02d20698: bl      #0x2b7105c                                 fn_2b7105c
02d2069c: bl      #0x2b7105c                                 fn_2b7105c
02d206a0: bl      #0x2b7105c                                 fn_2b7105c
02d206a4: bl      #0x2b7105c                                 fn_2b7105c
02d206a8: bl      #0x2b7105c                                 fn_2b7105c
02d206ac: bl      #0x2b7105c                                 fn_2b7105c
02d206b0: bl      #0x2b7105c                                 fn_2b7105c
02d206b4: bl      #0x2b7105c                                 fn_2b7105c
02d206b8: bl      #0x2b7105c                                 fn_2b7105c
02d206bc: bl      #0x2b7105c                                 fn_2b7105c
02d206c0: bl      #0x2b7105c                                 fn_2b7105c
02d206c4: bl      #0x2b7105c                                 fn_2b7105c
02d206c8: bl      #0x2b7105c                                 fn_2b7105c
02d206cc: bl      #0x2b7105c                                 fn_2b7105c
02d206d0: bl      #0x2b7105c                                 fn_2b7105c
02d206d4: b       #0x2d20788                                 
02d206d8: b       #0x2d20788                                 
02d206dc: b       #0x2d20788                                 
02d206e0: b       #0x2d20788                                 
02d206e4: b       #0x2d20788                                 
02d206e8: b       #0x2d20788                                 
02d206ec: b       #0x2d20788                                 
02d206f0: b       #0x2d20788                                 
02d206f4: b       #0x2d20788                                 
02d206f8: b       #0x2d20788                                 
02d206fc: b       #0x2d20788                                 
02d20700: b       #0x2d20788                                 
02d20704: b       #0x2d20788                                 
02d20708: b       #0x2d20788                                 
02d2070c: b       #0x2d20788                                 
02d20710: b       #0x2d20788                                 
02d20714: b       #0x2d20788                                 
02d20718: b       #0x2d20788                                 
02d2071c: b       #0x2d20788                                 
02d20720: b       #0x2d20788                                 
02d20724: b       #0x2d20788                                 
02d20728: b       #0x2d20788                                 
02d2072c: b       #0x2d20788                                 
02d20730: b       #0x2d20788                                 
02d20734: b       #0x2d20788                                 
02d20738: b       #0x2d20788                                 
02d2073c: b       #0x2d20788                                 
02d20740: b       #0x2d20788                                 
02d20744: b       #0x2d20788                                 
02d20748: b       #0x2d20788                                 
02d2074c: b       #0x2d20788                                 
02d20750: b       #0x2d20788                                 
02d20754: b       #0x2d20788                                 
02d20758: b       #0x2d20788                                 
02d2075c: b       #0x2d20788                                 
02d20760: b       #0x2d20788                                 
02d20764: b       #0x2d20788                                 
02d20768: b       #0x2d20788                                 
02d2076c: b       #0x2d20788                                 
02d20770: b       #0x2d20788                                 
02d20774: b       #0x2d20788                                 
02d20778: b       #0x2d20788                                 
02d2077c: b       #0x2d20788                                 
02d20780: b       #0x2d20788                                 
02d20784: b       #0x2d20788                                 
02d20788: mov     x20, x0                                    
02d2078c: cmp     w1, #1                                     
02d20790: b.ne    #0x2d20820                                 
02d20794: mov     x0, x20                                    
02d20798: bl      #0x5e90260                                 fn_5e90260
02d2079c: mov     x20, x0                                    
02d207a0: adrp    x0, #0x6263000                             
02d207a4: ldr     x0, [x0, #0xae0]                           T:System.Exception
02d207a8: bl      #0x2b70dc4                                 fn_2b70dc4
02d207ac: ldr     x8, [x20]                                  
02d207b0: ldr     x1, [x8]                                   T:Trading.TradingSession/<>c__DisplayClass56_0
02d207b4: bl      #0x2b71464                                 fn_2b71464
02d207b8: tbz     w0, #0, #0x2d207f8                         
02d207bc: ldrsw   x21, [sp, #8]                              
02d207c0: ldr     x20, [x20]                                 
02d207c4: mov     x8, sp                                     
02d207c8: str     x20, [x8, x21, lsl #3]                     
02d207cc: add     w8, w21, #1                                
02d207d0: str     w8, [sp, #8]                               
02d207d4: bl      #0x5e90270                                 fn_5e90270
02d207d8: mov     w8, #-2                                    
02d207dc: mov     x1, x20                                    
02d207e0: mov     x2, xzr                                    
02d207e4: str     w8, [x19], #8                              
02d207e8: mov     x0, x19                                    
02d207ec: bl      #0x4d43cc0                                 System.Runtime.CompilerServices.AsyncVoidMethodBuilder::SetException
02d207f0: str     w21, [sp, #8]                              
02d207f4: b       #0x2d205ec                                 
02d207f8: mov     w0, #8                                     
02d207fc: bl      #0x5e90290                                 fn_5e90290
02d20800: ldr     x8, [x20]                                  
02d20804: str     x8, [x0]                                   
02d20808: adrp    x1, #0x5e96000                             
02d2080c: add     x1, x1, #0x758                             &5e96758
02d20810: mov     x2, xzr                                    
02d20814: bl      #0x5e902a0                                 fn_5e902a0
02d20818: mov     x20, x0                                    
02d2081c: bl      #0x5e90270                                 fn_5e90270
02d20820: mov     x0, x20                                    
02d20824: bl      #0x2c6051c                                 fn_2c6051c
02d20828: bl      #0x27369b8                                 fn_27369b8
## SetStateMachine(System.Runtime.CompilerServices.IAsyncStateMachine stateMachine) -> void
---- Home.PopupIntroBlindbag/<OnShow>d__12::SetStateMachine 0x2d2082c
02d2082c: add     x0, x0, #8                                 
02d20830: mov     x2, xzr                                    
02d20834: b       #0x4d43a8c                                 System.Runtime.CompilerServices.AsyncVoidMethodBuilder::SetStateMachine
#### CLASS Home.PopupIntroBlindbag parent= PopupBase
#   field _commentHandler                CommentHandler                                     off=0x38 attr=1 SerializeField
#   field _playButton                    UnityEngine.UI.Button                              off=0x40 attr=1 SerializeField
#   field _collectionButton              UnityEngine.UI.Button                              off=0x48 attr=1 SerializeField
#   field _backButton                    UnityEngine.UI.Button                              off=0x50 attr=1 SerializeField
#   field _txtTipMoney                   TMPro.TextMeshProUGUI                              off=0x58 attr=1 SerializeField
#   field _viewerNameAsset               ViewerNameAsset                                    off=0x60 attr=1 SerializeField
#   field _viewerAvatarAsset             ViewerAvatarAsset                                  off=0x68 attr=1 SerializeField
#   field _profilePanel                  ProfilePanel                                       off=0x70 attr=1 SerializeField
#   field _livestreamPanel               Livestream.LivestreamPanel                         off=0x78 attr=1 SerializeField
#   field _coroutineSpawnComment         UnityEngine.Coroutine                              off=0x80 attr=1 
## OnInit(UIManager uiManager) -> void
---- Home.PopupIntroBlindbag::OnInit 0x2d1f4b8
02d1f4b8: str     x30, [sp, #-0x30]!                         
02d1f4bc: stp     x22, x21, [sp, #0x10]                      
02d1f4c0: stp     x20, x19, [sp, #0x20]                      
02d1f4c4: adrp    x21, #0x6630000                            
02d1f4c8: mov     x20, x1                                    
02d1f4cc: mov     x19, x0                                    
02d1f4d0: ldrb    w8, [x21, #0x3d]                           
02d1f4d4: tbnz    w8, #0, #0x2d1f528                         
02d1f4d8: adrp    x0, #0x6269000                             
02d1f4dc: ldr     x0, [x0, #0xda0]                           M:Home.PopupIntroBlindbag::OnButtonBackClicked
02d1f4e0: bl      #0x2b70db0                                 fn_2b70db0
02d1f4e4: adrp    x0, #0x6269000                             
02d1f4e8: ldr     x0, [x0, #0xda8]                           M:Home.PopupIntroBlindbag::OnButtonCollectionClicked
02d1f4ec: bl      #0x2b70db0                                 fn_2b70db0
02d1f4f0: adrp    x0, #0x6269000                             
02d1f4f4: ldr     x0, [x0, #0xdb0]                           M:Home.PopupIntroBlindbag::OnButtonPlayClicked
02d1f4f8: bl      #0x2b70db0                                 fn_2b70db0
02d1f4fc: adrp    x0, #0x6264000                             
02d1f500: ldr     x0, [x0, #0xfc0]                           T:RemoteConfigManager
02d1f504: bl      #0x2b70db0                                 fn_2b70db0
02d1f508: adrp    x0, #0x6265000                             
02d1f50c: ldr     x0, [x0, #0x3f0]                           T:UnityEngine.Events.UnityAction
02d1f510: bl      #0x2b70db0                                 fn_2b70db0
02d1f514: adrp    x0, #0x6269000                             
02d1f518: ldr     x0, [x0, #0xdb8]                           S:'+{0}'
02d1f51c: bl      #0x2b70db0                                 fn_2b70db0
02d1f520: mov     w8, #1                                     
02d1f524: strb    w8, [x21, #0x3d]                           
02d1f528: mov     x0, x19                                    
02d1f52c: mov     x1, x20                                    
02d1f530: mov     x2, xzr                                    
02d1f534: bl      #0x2cdd3c4                                 UIBase::OnInit
02d1f538: ldr     x8, [x19, #0x40]                           ._playButton
02d1f53c: cbz     x8, #0x2d1f6cc                             
02d1f540: adrp    x22, #0x6265000                            
02d1f544: adrp    x21, #0x6269000                            
02d1f548: ldr     x22, [x22, #0x3f0]                         T:UnityEngine.Events.UnityAction
02d1f54c: ldr     x21, [x21, #0xdb0]                         M:Home.PopupIntroBlindbag::OnButtonPlayClicked
02d1f550: ldr     x20, [x8, #0x100]                          
02d1f554: ldr     x0, [x22]                                  M:AdsManager::<OnApplicationPause>b__26_0
02d1f558: bl      #0x2b7104c                                 fn_2b7104c
02d1f55c: ldr     x2, [x21]                                  T:Trading.TradingSession/<>c__DisplayClass56_0
02d1f560: mov     x1, x19                                    
02d1f564: mov     x3, xzr                                    
02d1f568: mov     x21, x0                                    
02d1f56c: bl      #0x5b4cf98                                 UnityEngine.Events.UnityAction::.ctor
02d1f570: cbz     x20, #0x2d1f6cc                            
02d1f574: mov     x0, x20                                    
02d1f578: mov     x1, x21                                    
02d1f57c: mov     x2, xzr                                    
02d1f580: bl      #0x5b4d0ac                                 UnityEngine.Events.UnityEvent::AddListener
02d1f584: ldr     x8, [x19, #0x48]                           ._collectionButton
02d1f588: cbz     x8, #0x2d1f6cc                             
02d1f58c: adrp    x21, #0x6269000                            
02d1f590: ldr     x21, [x21, #0xda8]                         M:Home.PopupIntroBlindbag::OnButtonCollectionClicked
02d1f594: ldr     x0, [x22]                                  M:AdsManager::<OnApplicationPause>b__26_0
02d1f598: ldr     x20, [x8, #0x100]                          
02d1f59c: bl      #0x2b7104c                                 fn_2b7104c
02d1f5a0: ldr     x2, [x21]                                  T:Trading.TradingSession/<>c__DisplayClass56_0
02d1f5a4: mov     x1, x19                                    
02d1f5a8: mov     x3, xzr                                    
02d1f5ac: mov     x21, x0                                    
02d1f5b0: bl      #0x5b4cf98                                 UnityEngine.Events.UnityAction::.ctor
02d1f5b4: cbz     x20, #0x2d1f6cc                            
02d1f5b8: mov     x0, x20                                    
02d1f5bc: mov     x1, x21                                    
02d1f5c0: mov     x2, xzr                                    
02d1f5c4: bl      #0x5b4d0ac                                 UnityEngine.Events.UnityEvent::AddListener
02d1f5c8: ldr     x8, [x19, #0x50]                           ._backButton
02d1f5cc: cbz     x8, #0x2d1f6cc                             
02d1f5d0: adrp    x21, #0x6269000                            
02d1f5d4: ldr     x21, [x21, #0xda0]                         M:Home.PopupIntroBlindbag::OnButtonBackClicked
02d1f5d8: ldr     x0, [x22]                                  M:AdsManager::<OnApplicationPause>b__26_0
02d1f5dc: ldr     x20, [x8, #0x100]                          
02d1f5e0: bl      #0x2b7104c                                 fn_2b7104c
02d1f5e4: ldr     x2, [x21]                                  T:Trading.TradingSession/<>c__DisplayClass56_0
02d1f5e8: mov     x1, x19                                    
02d1f5ec: mov     x3, xzr                                    
02d1f5f0: mov     x21, x0                                    
02d1f5f4: bl      #0x5b4cf98                                 UnityEngine.Events.UnityAction::.ctor
02d1f5f8: cbz     x20, #0x2d1f6cc                            
02d1f5fc: mov     x0, x20                                    
02d1f600: mov     x1, x21                                    
02d1f604: mov     x2, xzr                                    
02d1f608: bl      #0x5b4d0ac                                 UnityEngine.Events.UnityEvent::AddListener
02d1f60c: ldr     x0, [x19, #0x78]                           ._livestreamPanel
02d1f610: cbz     x0, #0x2d1f6cc                             
02d1f614: adrp    x20, #0x6264000                            
02d1f618: mov     x1, xzr                                    
02d1f61c: ldr     x20, [x20, #0xfc0]                         T:RemoteConfigManager
02d1f620: bl      #0x2d11b9c                                 Livestream.LivestreamPanel::Initialized
02d1f624: ldr     x0, [x20]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d1f628: ldr     w8, [x0, #0xe4]                            [62690e4]=0 f=0,0
02d1f62c: cbnz    w8, #0x2d1f634                             
02d1f630: bl      #0x2b70f30                                 fn_2b70f30
02d1f634: adrp    x21, #0x662f000                            
02d1f638: ldrb    w8, [x21, #0xbc1]                          
02d1f63c: cbnz    w8, #0x2d1f654                             
02d1f640: adrp    x0, #0x6264000                             
02d1f644: ldr     x0, [x0, #0xfc0]                           T:RemoteConfigManager
02d1f648: bl      #0x2b70db0                                 fn_2b70db0
02d1f64c: mov     w8, #1                                     
02d1f650: strb    w8, [x21, #0xbc1]                          
02d1f654: ldr     x0, [x20]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d1f658: adrp    x20, #0x6269000                            
02d1f65c: ldr     w8, [x0, #0xe4]                            [62640e4]=0 f=0,0
02d1f660: ldr     x20, [x20, #0xdb8]                         S:'+{0}'
02d1f664: cbnz    w8, #0x2d1f66c                             
02d1f668: bl      #0x2b70f30                                 fn_2b70f30
02d1f66c: adrp    x8, #0x6263000                             
02d1f670: mov     w9, #0x64                                  
02d1f674: add     x1, sp, #0xc                               
02d1f678: ldr     x8, [x8, #0x970]                           &6645c70(=0)
02d1f67c: ldr     x19, [x19, #0x58]                          ._txtTipMoney
02d1f680: str     w9, [sp, #0xc]                             
02d1f684: ldr     x0, [x8, #0x48]                            &6263098(=0)
02d1f688: bl      #0x2b70f38                                 fn_2b70f38
02d1f68c: ldr     x8, [x20]                                  T:Trading.TradingSession/<>c__DisplayClass56_0
02d1f690: mov     x1, x0                                     
02d1f694: mov     x2, xzr                                    
02d1f698: mov     x0, x8                                     
02d1f69c: bl      #0x4c9d0ec                                 System.String::Format
02d1f6a0: cbz     x19, #0x2d1f6cc                            
02d1f6a4: ldr     x8, [x19]                                  
02d1f6a8: mov     x1, x0                                     
02d1f6ac: mov     x0, x19                                    
02d1f6b0: ldr     x9, [x8, #0x558]                           &2c5d934(=d65f03c0d503245f)
02d1f6b4: ldr     x2, [x8, #0x560]                           &2c5d58c(=14c8cc6cd503245f)
02d1f6b8: blr     x9                                         
02d1f6bc: ldp     x20, x19, [sp, #0x20]                      
02d1f6c0: ldp     x22, x21, [sp, #0x10]                      
02d1f6c4: ldr     x30, [sp], #0x30                           
02d1f6c8: ret                                                
02d1f6cc: bl      #0x2b7105c                                 fn_2b7105c
## OnHide() -> void
---- Home.PopupIntroBlindbag::OnHide 0x2d1f6d0
02d1f6d0: stp     x30, x19, [sp, #-0x10]!                    
02d1f6d4: mov     x1, xzr                                    
02d1f6d8: mov     x19, x0                                    
02d1f6dc: bl      #0x2cddc10                                 UIBase::OnHide
02d1f6e0: ldr     x0, [x19, #0x78]                           ._livestreamPanel
02d1f6e4: cbz     x0, #0x2d1f6f4                             
02d1f6e8: mov     x1, xzr                                    
02d1f6ec: ldp     x30, x19, [sp], #0x10                      
02d1f6f0: b       #0x2d11cdc                                 Livestream.LivestreamPanel::OnHide
02d1f6f4: bl      #0x2b7105c                                 fn_2b7105c
## OnShow() -> void
---- Home.PopupIntroBlindbag::OnShow 0x2d1f6f8
02d1f6f8: sub     sp, sp, #0x80                              
02d1f6fc: stp     x30, x21, [sp, #0x60]                      
02d1f700: stp     x20, x19, [sp, #0x70]                      
02d1f704: adrp    x21, #0x6630000                            
02d1f708: adrp    x20, #0x6269000                            
02d1f70c: mov     x19, x0                                    
02d1f710: ldrb    w8, [x21, #0x3e]                           
02d1f714: ldr     x20, [x20, #0xdc0]                         MS:System.Runtime.CompilerServices.AsyncVoidMethodBuilder::Start
02d1f718: tbnz    w8, #0, #0x2d1f730                         
02d1f71c: adrp    x0, #0x6269000                             
02d1f720: ldr     x0, [x0, #0xdc0]                           MS:System.Runtime.CompilerServices.AsyncVoidMethodBuilder::Start
02d1f724: bl      #0x2b70db0                                 fn_2b70db0
02d1f728: mov     w8, #1                                     
02d1f72c: strb    w8, [x21, #0x3e]                           
02d1f730: movi    v0.2d, #0000000000000000                   
02d1f734: mov     x8, sp                                     
02d1f738: mov     x0, xzr                                    
02d1f73c: stp     q0, q0, [sp, #0x20]                        
02d1f740: stp     q0, q0, [sp, #0x40]                        
02d1f744: bl      #0x4d43a24                                 System.Runtime.CompilerServices.AsyncVoidMethodBuilder::Create
02d1f748: ldp     q0, q1, [sp]                               
02d1f74c: add     x21, sp, #0x20                             
02d1f750: orr     x0, x21, #8                                
02d1f754: mov     x1, xzr                                    
02d1f758: stur    q0, [sp, #0x28]                            
02d1f75c: stur    q1, [sp, #0x38]                            
02d1f760: bl      #0x2b70d54                                 fn_2b70d54
02d1f764: add     x0, x21, #0x28                             &6630028
02d1f768: mov     x1, x19                                    
02d1f76c: str     x19, [sp, #0x48]                           
02d1f770: bl      #0x2b70d54                                 fn_2b70d54
02d1f774: ldr     x2, [x20]                                  T:Trading.TradingSession/<>c__DisplayClass56_0
02d1f778: mov     w8, #-1                                    
02d1f77c: orr     x0, x21, #8                                
02d1f780: add     x1, sp, #0x20                              
02d1f784: str     w8, [sp, #0x20]                            
02d1f788: bl      #0x30c8620                                 fn_30c8620
02d1f78c: ldp     x20, x19, [sp, #0x70]                      
02d1f790: ldp     x30, x21, [sp, #0x60]                      
02d1f794: add     sp, sp, #0x80                              
02d1f798: ret                                                
## OnButtonPlayClicked() -> void
---- Home.PopupIntroBlindbag::OnButtonPlayClicked 0x2d1f79c
02d1f79c: str     x30, [sp, #-0x30]!                         
02d1f7a0: stp     x22, x21, [sp, #0x10]                      
02d1f7a4: stp     x20, x19, [sp, #0x20]                      
02d1f7a8: adrp    x20, #0x6630000                            
02d1f7ac: mov     x19, x0                                    
02d1f7b0: ldrb    w8, [x20, #0x3f]                           
02d1f7b4: tbnz    w8, #0, #0x2d1f814                         
02d1f7b8: adrp    x0, #0x6266000                             
02d1f7bc: ldr     x0, [x0, #0x750]                           MS:DataManager::GetData
02d1f7c0: bl      #0x2b70db0                                 fn_2b70db0
02d1f7c4: adrp    x0, #0x6265000                             
02d1f7c8: ldr     x0, [x0, #0xb38]                           T:DevTrack
02d1f7cc: bl      #0x2b70db0                                 fn_2b70db0
02d1f7d0: adrp    x0, #0x6266000                             
02d1f7d4: ldr     x0, [x0, #0x5e0]                           T:GameConfig
02d1f7d8: bl      #0x2b70db0                                 fn_2b70db0
02d1f7dc: adrp    x0, #0x6267000                             
02d1f7e0: ldr     x0, [x0, #0xd50]                           MS:MonoSingleton`1::get_Instance
02d1f7e4: bl      #0x2b70db0                                 fn_2b70db0
02d1f7e8: adrp    x0, #0x6265000                             
02d1f7ec: ldr     x0, [x0, #0x10]                            MS:MonoSingleton`1::get_Instance
02d1f7f0: bl      #0x2b70db0                                 fn_2b70db0
02d1f7f4: adrp    x0, #0x6266000                             
02d1f7f8: ldr     x0, [x0, #0x658]                           MS:MonoSingleton`1::get_Instance
02d1f7fc: bl      #0x2b70db0                                 fn_2b70db0
02d1f800: adrp    x0, #0x6266000                             
02d1f804: ldr     x0, [x0, #0xb48]                           MS:MonoSingleton`1::get_Instance
02d1f808: bl      #0x2b70db0                                 fn_2b70db0
02d1f80c: mov     w8, #1                                     
02d1f810: strb    w8, [x20, #0x3f]                           
02d1f814: mov     x0, xzr                                    
02d1f818: bl      #0x2d6eec8                                 Framework.AudioManager::get_Instance
02d1f81c: cbz     x0, #0x2d1fa4c                             
02d1f820: movi    d1, #0000000000000000                      
02d1f824: movi    d2, #0000000000000000                      
02d1f828: adrp    x20, #0x6267000                            
02d1f82c: fmov    s0, #1.00000000                            
02d1f830: ldr     x20, [x20, #0xd50]                         MS:MonoSingleton`1::get_Instance
02d1f834: mov     w1, #1                                     
02d1f838: mov     w2, wzr                                    
02d1f83c: mov     w3, wzr                                    
02d1f840: mov     x4, xzr                                    
02d1f844: bl      #0x2d6f03c                                 Framework.AudioManager::PlaySound
02d1f848: ldr     x0, [x20]                                  S:'didu'
02d1f84c: bl      #0x3769600                                 fn_3769600
02d1f850: cbz     x0, #0x2d1fa4c                             
02d1f854: mov     w1, #4                                     
02d1f858: mov     x2, xzr                                    
02d1f85c: bl      #0x2cc6ee0                                 Framework.VibrationManager::Haptic
02d1f860: mov     x0, x19                                    
02d1f864: bl      #0x2d1fa50                                 Home.PopupIntroBlindbag::StartButtonPlayClickEffect
02d1f868: ldr     x0, [x19, #0x40]                           ._playButton
02d1f86c: cbz     x0, #0x2d1fa4c                             
02d1f870: mov     w1, wzr                                    
02d1f874: mov     x2, xzr                                    
02d1f878: bl      #0x5e662d4                                 UnityEngine.UI.Selectable::set_interactable
02d1f87c: ldr     x8, [x19, #0x38]                           ._commentHandler
02d1f880: cbz     x8, #0x2d1fa4c                             
02d1f884: adrp    x9, #0x6265000                             
02d1f888: adrp    x20, #0x6266000                            
02d1f88c: ldr     x9, [x9, #0x10]                            MS:MonoSingleton`1::get_Instance
02d1f890: ldr     x20, [x20, #0x5e0]                         T:GameConfig
02d1f894: strb    wzr, [x8, #0x20]                           
02d1f898: ldr     x0, [x9]                                   M:AdsManager::<OnApplicationPause>b__26_0
02d1f89c: bl      #0x3769600                                 fn_3769600
02d1f8a0: ldr     x8, [x20]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d1f8a4: mov     x19, x0                                    
02d1f8a8: ldr     w9, [x8, #0xe4]                            
02d1f8ac: cbnz    w9, #0x2d1f8b8                             
02d1f8b0: mov     x0, x8                                     
02d1f8b4: bl      #0x2b70f30                                 fn_2b70f30
02d1f8b8: cbz     x19, #0x2d1fa4c                            
02d1f8bc: ldr     x8, [x20]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d1f8c0: adrp    x20, #0x6266000                            
02d1f8c4: mov     x0, x19                                    
02d1f8c8: mov     w2, wzr                                    
02d1f8cc: mov     x3, xzr                                    
02d1f8d0: ldr     x8, [x8, #0xb8]                            
02d1f8d4: ldr     x20, [x20, #0x658]                         MS:MonoSingleton`1::get_Instance
02d1f8d8: ldr     x1, [x8, #0x18]                            
02d1f8dc: bl      #0x2ce9e58                                 SimpleSceneTransition::FlashIn
02d1f8e0: ldr     x0, [x20]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d1f8e4: bl      #0x3769600                                 fn_3769600
02d1f8e8: cbz     x0, #0x2d1fa4c                             
02d1f8ec: adrp    x8, #0x6266000                             
02d1f8f0: ldr     x8, [x8, #0x750]                           MS:DataManager::GetData
02d1f8f4: ldr     x1, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d1f8f8: bl      #0x3168dd0                                 fn_3168dd0
02d1f8fc: cbz     x0, #0x2d1fa4c                             
02d1f900: ldr     x8, [x0, #0x20]                            S:'inter_ad_capping_time'
02d1f904: mov     x19, x0                                    
02d1f908: cbz     x8, #0x2d1fa4c                             
02d1f90c: adrp    x21, #0x6266000                            
02d1f910: ldrb    w8, [x8, #0x45]                            
02d1f914: ldr     x21, [x21, #0xb48]                         MS:MonoSingleton`1::get_Instance
02d1f918: cbnz    w8, #0x2d1f938                             
02d1f91c: ldr     x0, [x21]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d1f920: bl      #0x3769600                                 fn_3769600
02d1f924: mov     x20, x0                                    
02d1f928: mov     x0, xzr                                    
02d1f92c: bl      #0x5b432fc                                 UnityEngine.Time::get_time
02d1f930: cbz     x20, #0x2d1fa4c                            
02d1f934: str     s0, [x20, #0x28]                           
02d1f938: adrp    x22, #0x6265000                            
02d1f93c: ldr     x22, [x22, #0xb38]                         T:DevTrack
02d1f940: ldr     x0, [x21]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d1f944: bl      #0x3769600                                 fn_3769600
02d1f948: ldr     x8, [x22]                                  M:AdsManager::<OnApplicationPause>b__26_0
02d1f94c: mov     x20, x0                                    
02d1f950: ldr     w9, [x8, #0xe4]                            [62660e4]=0 f=0,0
02d1f954: cbnz    w9, #0x2d1f960                             
02d1f958: mov     x0, x8                                     
02d1f95c: bl      #0x2b70f30                                 fn_2b70f30
02d1f960: cbz     x20, #0x2d1fa4c                            
02d1f964: ldr     x8, [x22]                                  M:AdsManager::<OnApplicationPause>b__26_0
02d1f968: ldr     x8, [x8, #0xb8]                            S:'banner_native_refresh_time'
02d1f96c: ldr     x1, [x8, #0x350]                           S:"OnProductPurchased handler error for '{0}': {1}"
02d1f970: str     x1, [x20, #0x30]!                          
02d1f974: mov     x0, x20                                    
02d1f978: bl      #0x2b70d54                                 fn_2b70d54
02d1f97c: ldr     x0, [x21]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d1f980: bl      #0x3769600                                 fn_3769600
02d1f984: ldr     x8, [x19, #0x20]                           
02d1f988: cbz     x8, #0x2d1fa4c                             
02d1f98c: cbz     x0, #0x2d1fa4c                             
02d1f990: ldr     w8, [x8, #0x50]                            S:'native_fullscreen_on_off'
02d1f994: add     w9, w8, #1                                 
02d1f998: ldr     x8, [x21]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d1f99c: str     w9, [x0, #0x3c]                            
02d1f9a0: mov     x0, x8                                     
02d1f9a4: bl      #0x3769600                                 fn_3769600
02d1f9a8: mov     x20, x0                                    
02d1f9ac: mov     x0, xzr                                    
02d1f9b0: bl      #0x5b432fc                                 UnityEngine.Time::get_time
02d1f9b4: cbz     x20, #0x2d1fa4c                            
02d1f9b8: ldr     x8, [x19, #0x20]                           
02d1f9bc: str     s0, [x20, #0x38]                           ._commentHandler
02d1f9c0: cbz     x8, #0x2d1fa4c                             
02d1f9c4: ldr     x9, [x22]                                  M:AdsManager::<OnApplicationPause>b__26_0
02d1f9c8: ldr     w8, [x8, #0x50]                            S:'native_fullscreen_on_off'
02d1f9cc: mov     x3, xzr                                    
02d1f9d0: ldr     x9, [x9, #0xb8]                            T:AdsManager/<>c__DisplayClass42_0
02d1f9d4: add     w1, w8, #1                                 
02d1f9d8: ldr     x0, [x9, #0x350]                           T:type7232(k15)
02d1f9dc: ldr     x2, [x9, #0x1e0]                           S:'_OnAdLoadedEvent'
02d1f9e0: bl      #0x2c9c5c4                                 DevTrack::GameModeStart
02d1f9e4: ldr     x0, [x21]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d1f9e8: bl      #0x3769600                                 fn_3769600
02d1f9ec: cbz     x0, #0x2d1fa4c                             
02d1f9f0: ldr     x19, [x0, #0x30]                           S:'popup_rate_on_off'
02d1f9f4: ldr     x0, [x21]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d1f9f8: bl      #0x3769600                                 fn_3769600
02d1f9fc: cbz     x0, #0x2d1fa4c                             
02d1fa00: ldr     x8, [x22]                                  M:AdsManager::<OnApplicationPause>b__26_0
02d1fa04: ldr     w1, [x0, #0x3c]                            [626603c]=0 f=0,0
02d1fa08: mov     x0, x19                                    
02d1fa0c: mov     x4, xzr                                    
02d1fa10: ldr     x8, [x8, #0xb8]                            S:'banner_native_refresh_time'
02d1fa14: ldr     x2, [x8, #0x218]                           MS:System.Collections.Generic.List`1::.ctor
02d1fa18: ldr     w3, [x8, #0x270]                           MS:System.Collections.Generic.List`1::GetEnumerator
02d1fa1c: bl      #0x2c9c714                                 DevTrack::GameModeStepEnter
02d1fa20: ldr     x0, [x21]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d1fa24: bl      #0x3769600                                 fn_3769600
02d1fa28: cbz     x0, #0x2d1fa4c                             
02d1fa2c: ldr     x8, [x22]                                  M:AdsManager::<OnApplicationPause>b__26_0
02d1fa30: ldp     x20, x19, [sp, #0x20]                      
02d1fa34: ldp     x22, x21, [sp, #0x10]                      
02d1fa38: ldr     x8, [x8, #0xb8]                            S:'banner_native_refresh_time'
02d1fa3c: ldr     x1, [x8, #0x218]                           MS:System.Collections.Generic.List`1::.ctor
02d1fa40: str     x1, [x0, #0x40]!                           ._playButton
02d1fa44: ldr     x30, [sp], #0x30                           
02d1fa48: b       #0x2b70d54                                 
02d1fa4c: bl      #0x2b7105c                                 fn_2b7105c
## OnButtonBackClicked() -> void
---- Home.PopupIntroBlindbag::OnButtonBackClicked 0x2d1faf4
02d1faf4: stp     x30, x21, [sp, #-0x20]!                    
02d1faf8: stp     x20, x19, [sp, #0x10]                      
02d1fafc: adrp    x20, #0x6630000                            
02d1fb00: mov     x19, x0                                    
02d1fb04: ldrb    w8, [x20, #0x40]                           ._playButton
02d1fb08: tbnz    w8, #0, #0x2d1fb44                         
02d1fb0c: adrp    x0, #0x6264000                             
02d1fb10: ldr     x0, [x0, #0xf90]                           T:System.Action
02d1fb14: bl      #0x2b70db0                                 fn_2b70db0
02d1fb18: adrp    x0, #0x6269000                             
02d1fb1c: ldr     x0, [x0, #0xdc8]                           M:Home.PopupIntroBlindbag::<OnButtonBackClicked>b__14_0
02d1fb20: bl      #0x2b70db0                                 fn_2b70db0
02d1fb24: adrp    x0, #0x6265000                             
02d1fb28: ldr     x0, [x0, #0x310]                           MS:WejoyService.Singleton`1::get_Instance
02d1fb2c: bl      #0x2b70db0                                 fn_2b70db0
02d1fb30: adrp    x0, #0x6269000                             
02d1fb34: ldr     x0, [x0, #0xdd0]                           S:'intro_blindbag_back'
02d1fb38: bl      #0x2b70db0                                 fn_2b70db0
02d1fb3c: mov     w8, #1                                     
02d1fb40: strb    w8, [x20, #0x40]                           ._playButton
02d1fb44: mov     x0, xzr                                    
02d1fb48: bl      #0x2d6eec8                                 Framework.AudioManager::get_Instance
02d1fb4c: cbz     x0, #0x2d1fbec                             
02d1fb50: movi    d1, #0000000000000000                      
02d1fb54: movi    d2, #0000000000000000                      
02d1fb58: mov     w1, #1                                     
02d1fb5c: fmov    s0, #1.00000000                            
02d1fb60: mov     w2, wzr                                    
02d1fb64: mov     w3, wzr                                    
02d1fb68: mov     x4, xzr                                    
02d1fb6c: bl      #0x2d6f03c                                 Framework.AudioManager::PlaySound
02d1fb70: ldr     x8, [x19, #0x38]                           ._commentHandler
02d1fb74: cbz     x8, #0x2d1fbec                             
02d1fb78: adrp    x9, #0x6265000                             
02d1fb7c: adrp    x20, #0x6264000                            
02d1fb80: adrp    x21, #0x6269000                            
02d1fb84: ldr     x9, [x9, #0x310]                           MS:WejoyService.Singleton`1::get_Instance
02d1fb88: ldr     x20, [x20, #0xf90]                         T:System.Action
02d1fb8c: ldr     x21, [x21, #0xdc8]                         M:Home.PopupIntroBlindbag::<OnButtonBackClicked>b__14_0
02d1fb90: strb    wzr, [x8, #0x20]                           
02d1fb94: ldr     x0, [x9]                                   M:AdsManager::<OnApplicationPause>b__26_0
02d1fb98: bl      #0x3be7218                                 fn_3be7218
02d1fb9c: ldr     x8, [x20]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d1fba0: mov     x20, x0                                    
02d1fba4: mov     x0, x8                                     
02d1fba8: bl      #0x2b7104c                                 fn_2b7104c
02d1fbac: ldr     x2, [x21]                                  T:Trading.TradingSession/<>c__DisplayClass56_0
02d1fbb0: mov     x1, x19                                    
02d1fbb4: mov     x3, xzr                                    
02d1fbb8: mov     x21, x0                                    
02d1fbbc: bl      #0x4d8ddbc                                 System.Action::.ctor
02d1fbc0: cbz     x20, #0x2d1fbec                            
02d1fbc4: adrp    x8, #0x6269000                             
02d1fbc8: mov     x0, x20                                    
02d1fbcc: mov     x2, x21                                    
02d1fbd0: ldr     x8, [x8, #0xdd0]                           S:'intro_blindbag_back'
02d1fbd4: ldp     x20, x19, [sp, #0x10]                      
02d1fbd8: mov     w3, #1                                     
02d1fbdc: mov     x4, xzr                                    
02d1fbe0: ldr     x1, [x8]                                   T:Trading.TradingSession/<>c__DisplayClass56_0
02d1fbe4: ldp     x30, x21, [sp], #0x20                      
02d1fbe8: b       #0x2c89698                                 AdsManager::ShowInter
02d1fbec: bl      #0x2b7105c                                 fn_2b7105c
## OnButtonCollectionClicked() -> void
---- Home.PopupIntroBlindbag::OnButtonCollectionClicked 0x2d1fbf0
02d1fbf0: str     x30, [sp, #-0x20]!                         
02d1fbf4: stp     x20, x19, [sp, #0x10]                      
02d1fbf8: adrp    x20, #0x6630000                            
02d1fbfc: mov     x19, x0                                    
02d1fc00: ldrb    w8, [x20, #0x41]                           
02d1fc04: tbnz    w8, #0, #0x2d1fc28                         
02d1fc08: adrp    x0, #0x6266000                             
02d1fc0c: ldr     x0, [x0, #0xac0]                           MS:MonoSingleton`1::get_Instance
02d1fc10: bl      #0x2b70db0                                 fn_2b70db0
02d1fc14: adrp    x0, #0x6269000                             
02d1fc18: ldr     x0, [x0, #0xdd8]                           MS:UIManager::ShowPopup
02d1fc1c: bl      #0x2b70db0                                 fn_2b70db0
02d1fc20: mov     w8, #1                                     
02d1fc24: strb    w8, [x20, #0x41]                           
02d1fc28: mov     x0, xzr                                    
02d1fc2c: bl      #0x2d6eec8                                 Framework.AudioManager::get_Instance
02d1fc30: cbz     x0, #0x2d1fca0                             
02d1fc34: movi    d1, #0000000000000000                      
02d1fc38: movi    d2, #0000000000000000                      
02d1fc3c: adrp    x20, #0x6266000                            
02d1fc40: fmov    s0, #1.00000000                            
02d1fc44: ldr     x20, [x20, #0xac0]                         MS:MonoSingleton`1::get_Instance
02d1fc48: mov     w1, #1                                     
02d1fc4c: mov     w2, wzr                                    
02d1fc50: mov     w3, wzr                                    
02d1fc54: mov     x4, xzr                                    
02d1fc58: bl      #0x2d6f03c                                 Framework.AudioManager::PlaySound
02d1fc5c: ldr     x0, [x20]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d1fc60: bl      #0x3769600                                 fn_3769600
02d1fc64: cbz     x0, #0x2d1fca0                             
02d1fc68: mov     w1, wzr                                    
02d1fc6c: mov     x2, xzr                                    
02d1fc70: bl      #0x2cacd8c                                 GameSession::SetActiveCharacter
02d1fc74: mov     x0, x19                                    
02d1fc78: mov     w1, wzr                                    
02d1fc7c: bl      #0x2d1f058                                 Home.PopupIntroBlindbag::ShowVisual
02d1fc80: ldr     x0, [x19, #0x30]                           
02d1fc84: cbz     x0, #0x2d1fca0                             
02d1fc88: adrp    x8, #0x6269000                             
02d1fc8c: ldr     x8, [x8, #0xdd8]                           MS:UIManager::ShowPopup
02d1fc90: ldp     x20, x19, [sp, #0x10]                      
02d1fc94: ldr     x1, [x8]                                   T:Trading.TradingSession/<>c__DisplayClass56_0
02d1fc98: ldr     x30, [sp], #0x20                           
02d1fc9c: b       #0x33fbfac                                 
02d1fca0: bl      #0x2b7105c                                 fn_2b7105c
## StartButtonPlayClickEffect() -> void
---- Home.PopupIntroBlindbag::StartButtonPlayClickEffect 0x2d1fa50
02d1fa50: str     x30, [sp, #-0x20]!                         
02d1fa54: stp     x20, x19, [sp, #0x10]                      
02d1fa58: mov     x19, x0                                    
02d1fa5c: bl      #0x2d1fca4                                 Home.PopupIntroBlindbag::StopButtonPlayAnim
02d1fa60: ldr     x0, [x19, #0x40]                           ._playButton
02d1fa64: cbz     x0, #0x2d1faf0                             
02d1fa68: mov     x1, xzr                                    
02d1fa6c: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02d1fa70: adrp    x20, #0x662f000                            
02d1fa74: mov     x19, x0                                    
02d1fa78: ldrb    w8, [x20, #0xa74]                          
02d1fa7c: cbnz    w8, #0x2d1fa94                             
02d1fa80: adrp    x0, #0x6264000                             
02d1fa84: ldr     x0, [x0, #0xd8]                            T:UnityEngine.Vector3
02d1fa88: bl      #0x2b70db0                                 fn_2b70db0
02d1fa8c: mov     w8, #1                                     
02d1fa90: strb    w8, [x20, #0xa74]                          
02d1fa94: adrp    x8, #0x6264000                             
02d1fa98: mov     w9, #0xcccd                                
02d1fa9c: mov     x0, x19                                    
02d1faa0: ldr     x8, [x8, #0xd8]                            T:UnityEngine.Vector3
02d1faa4: movk    w9, #0x3dcc, lsl #16                       
02d1faa8: fmov    s4, #1.00000000                            
02d1faac: dup     v0.2s, w9                                  
02d1fab0: adrp    x9, #0x1084000                             
02d1fab4: mov     w1, #0xa                                   
02d1fab8: ldr     x8, [x8]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d1fabc: ldp     x20, x19, [sp, #0x10]                      
02d1fac0: mov     x2, xzr                                    
02d1fac4: ldr     x8, [x8, #0xb8]                            MS:DG.Tweening.Core.Extensions::SetSpecialStartupMode
02d1fac8: ldur    d1, [x8, #0xc]                             
02d1facc: ldr     s2, [x8, #0x14]                            [6264014]=0 f=0,0
02d1fad0: adrp    x8, #0x1084000                             
02d1fad4: ldr     s3, [x8, #0xdd8]                           [1084dd8]=3f7333333e4ccccd f=0.2,0.95
02d1fad8: fmul    v0.2s, v1.2s, v0.2s                        
02d1fadc: ldr     s1, [x9, #0xeec]                           [1084eec]=457ff0003dcccccd f=0.1,4095
02d1fae0: fmul    s2, s2, s1                                 
02d1fae4: mov     s1, v0.s[1]                                
02d1fae8: ldr     x30, [sp], #0x20                           
02d1faec: b       #0x2d9982c                                 DG.Tweening.ShortcutExtensions::DOPunchScale
02d1faf0: bl      #0x2b7105c                                 fn_2b7105c
## StartButtonPlayAnim() -> void
---- Home.PopupIntroBlindbag::StartButtonPlayAnim 0x2d1fd34
02d1fd34: str     x30, [sp, #-0x30]!                         
02d1fd38: stp     x22, x21, [sp, #0x10]                      
02d1fd3c: stp     x20, x19, [sp, #0x20]                      
02d1fd40: adrp    x20, #0x6630000                            
02d1fd44: mov     x19, x0                                    
02d1fd48: ldrb    w8, [x20, #0x42]                           
02d1fd4c: tbnz    w8, #0, #0x2d1fd70                         
02d1fd50: adrp    x0, #0x6266000                             
02d1fd54: ldr     x0, [x0, #0x880]                           MS:DG.Tweening.TweenSettingsExtensions::SetEase
02d1fd58: bl      #0x2b70db0                                 fn_2b70db0
02d1fd5c: adrp    x0, #0x6268000                             
02d1fd60: ldr     x0, [x0, #0x10]                            MS:DG.Tweening.TweenSettingsExtensions::SetLoops
02d1fd64: bl      #0x2b70db0                                 fn_2b70db0
02d1fd68: mov     w8, #1                                     
02d1fd6c: strb    w8, [x20, #0x42]                           
02d1fd70: mov     x0, x19                                    
02d1fd74: bl      #0x2d1fca4                                 Home.PopupIntroBlindbag::StopButtonPlayAnim
02d1fd78: ldr     x0, [x19, #0x40]                           ._playButton
02d1fd7c: cbz     x0, #0x2d1fe30                             
02d1fd80: adrp    x21, #0x6266000                            
02d1fd84: adrp    x20, #0x6268000                            
02d1fd88: mov     x1, xzr                                    
02d1fd8c: ldr     x21, [x21, #0x880]                         MS:DG.Tweening.TweenSettingsExtensions::SetEase
02d1fd90: ldr     x20, [x20, #0x10]                          MS:DG.Tweening.TweenSettingsExtensions::SetLoops
02d1fd94: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02d1fd98: adrp    x22, #0x662f000                            
02d1fd9c: mov     x19, x0                                    
02d1fda0: ldrb    w8, [x22, #0xa74]                          
02d1fda4: cbnz    w8, #0x2d1fdbc                             
02d1fda8: adrp    x0, #0x6264000                             
02d1fdac: ldr     x0, [x0, #0xd8]                            T:UnityEngine.Vector3
02d1fdb0: bl      #0x2b70db0                                 fn_2b70db0
02d1fdb4: mov     w8, #1                                     
02d1fdb8: strb    w8, [x22, #0xa74]                          
02d1fdbc: adrp    x8, #0x6264000                             
02d1fdc0: mov     w9, #0xcccd                                
02d1fdc4: mov     x0, x19                                    
02d1fdc8: ldr     x8, [x8, #0xd8]                            T:UnityEngine.Vector3
02d1fdcc: movk    w9, #0x3f8c, lsl #16                       
02d1fdd0: mov     x1, xzr                                    
02d1fdd4: dup     v0.2s, w9                                  
02d1fdd8: adrp    x9, #0x1084000                             
02d1fddc: ldr     x8, [x8]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d1fde0: ldr     s2, [x9, #0xcfc]                           [1084cfc]=3e58658c3f8ccccd f=1.1,0.211325
02d1fde4: ldr     x8, [x8, #0xb8]                            MS:DG.Tweening.Core.Extensions::SetSpecialStartupMode
02d1fde8: ldur    d1, [x8, #0xc]                             
02d1fdec: fmul    v0.2s, v1.2s, v0.2s                        
02d1fdf0: ldr     s1, [x8, #0x14]                            [6264014]=0 f=0,0
02d1fdf4: adrp    x8, #0x1084000                             
02d1fdf8: ldr     s3, [x8, #0xda8]                           [1084da8]=da242603eb851ec f=0.36,1e-30
02d1fdfc: fmul    s2, s1, s2                                 
02d1fe00: mov     s1, v0.s[1]                                
02d1fe04: bl      #0x2d98af8                                 DG.Tweening.ShortcutExtensions::DOScale
02d1fe08: ldr     x2, [x21]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d1fe0c: mov     w1, #4                                     
02d1fe10: bl      #0x336fa0c                                 fn_336fa0c
02d1fe14: ldr     x3, [x20]                                  S:'{0}/2'
02d1fe18: ldp     x20, x19, [sp, #0x20]                      
02d1fe1c: ldp     x22, x21, [sp, #0x10]                      
02d1fe20: mov     w1, #-1                                    
02d1fe24: mov     w2, #1                                     
02d1fe28: ldr     x30, [sp], #0x30                           
02d1fe2c: b       #0x336fe74                                 
02d1fe30: bl      #0x2b7105c                                 fn_2b7105c
## OnDestroy() -> void
---- Home.PopupIntroBlindbag::OnDestroy 0x2d1fe34
02d1fe34: stp     x30, x19, [sp, #-0x10]!                    
02d1fe38: mov     x19, x0                                    
02d1fe3c: ldr     x0, [x0, #0x78]                            ._livestreamPanel
02d1fe40: cbz     x0, #0x2d1fe88                             
02d1fe44: mov     x1, xzr                                    
02d1fe48: bl      #0x2d11cdc                                 Livestream.LivestreamPanel::OnHide
02d1fe4c: ldr     x0, [x19, #0x40]                           ._playButton
02d1fe50: cbz     x0, #0x2d1fe88                             
02d1fe54: mov     x1, xzr                                    
02d1fe58: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02d1fe5c: mov     w1, wzr                                    
02d1fe60: mov     x2, xzr                                    
02d1fe64: bl      #0x2d9d5d0                                 DG.Tweening.ShortcutExtensions::DOKill
02d1fe68: ldr     x1, [x19, #0x80]                           ._coroutineSpawnComment
02d1fe6c: cbz     x1, #0x2d1fe80                             
02d1fe70: mov     x0, x19                                    
02d1fe74: mov     x2, xzr                                    
02d1fe78: ldp     x30, x19, [sp], #0x10                      
02d1fe7c: b       #0x5b38c4c                                 UnityEngine.MonoBehaviour::StopCoroutine
02d1fe80: ldp     x30, x19, [sp], #0x10                      
02d1fe84: ret                                                
02d1fe88: bl      #0x2b7105c                                 fn_2b7105c
## StopButtonPlayAnim() -> void
---- Home.PopupIntroBlindbag::StopButtonPlayAnim 0x2d1fca4
02d1fca4: str     x30, [sp, #-0x20]!                         
02d1fca8: stp     x20, x19, [sp, #0x10]                      
02d1fcac: mov     x19, x0                                    
02d1fcb0: ldr     x0, [x0, #0x40]                            ._playButton
02d1fcb4: cbz     x0, #0x2d1fd30                             
02d1fcb8: mov     x1, xzr                                    
02d1fcbc: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02d1fcc0: mov     w1, wzr                                    
02d1fcc4: mov     x2, xzr                                    
02d1fcc8: bl      #0x2d9d5d0                                 DG.Tweening.ShortcutExtensions::DOKill
02d1fccc: ldr     x0, [x19, #0x40]                           ._playButton
02d1fcd0: cbz     x0, #0x2d1fd30                             
02d1fcd4: mov     x1, xzr                                    
02d1fcd8: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02d1fcdc: adrp    x20, #0x662f000                            
02d1fce0: mov     x19, x0                                    
02d1fce4: ldrb    w8, [x20, #0xa74]                          
02d1fce8: cbnz    w8, #0x2d1fd00                             
02d1fcec: adrp    x0, #0x6264000                             
02d1fcf0: ldr     x0, [x0, #0xd8]                            T:UnityEngine.Vector3
02d1fcf4: bl      #0x2b70db0                                 fn_2b70db0
02d1fcf8: mov     w8, #1                                     
02d1fcfc: strb    w8, [x20, #0xa74]                          
02d1fd00: cbz     x19, #0x2d1fd30                            
02d1fd04: adrp    x8, #0x6264000                             
02d1fd08: mov     x0, x19                                    
02d1fd0c: mov     x1, xzr                                    
02d1fd10: ldr     x8, [x8, #0xd8]                            T:UnityEngine.Vector3
02d1fd14: ldp     x20, x19, [sp, #0x10]                      
02d1fd18: ldr     x8, [x8]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d1fd1c: ldr     x8, [x8, #0xb8]                            MS:DG.Tweening.Core.Extensions::SetSpecialStartupMode
02d1fd20: ldp     s0, s1, [x8, #0xc]                         
02d1fd24: ldr     s2, [x8, #0x14]                            [6264014]=0 f=0,0
02d1fd28: ldr     x30, [sp], #0x20                           
02d1fd2c: b       #0x5b470cc                                 UnityEngine.Transform::set_localScale
02d1fd30: bl      #0x2b7105c                                 fn_2b7105c
## ShowVisual(bool isShow) -> void
---- Home.PopupIntroBlindbag::ShowVisual 0x2d1f058
02d1f058: str     x30, [sp, #-0x20]!                         
02d1f05c: stp     x20, x19, [sp, #0x10]                      
02d1f060: mov     x19, x0                                    
02d1f064: ldr     x0, [x0, #0x28]                            
02d1f068: cbz     x0, #0x2d1f0b8                             
02d1f06c: movi    d0, #0000000000000000                      
02d1f070: fmov    s1, #1.00000000                            
02d1f074: tst     w1, #1                                     
02d1f078: mov     w20, w1                                    
02d1f07c: mov     x1, xzr                                    
02d1f080: fcsel   s0, s1, s0, ne                             
02d1f084: bl      #0x5e45108                                 UnityEngine.CanvasGroup::set_alpha
02d1f088: ldr     x0, [x19, #0x28]                           
02d1f08c: cbz     x0, #0x2d1f0b8                             
02d1f090: and     w20, w20, #1                               
02d1f094: mov     x2, xzr                                    
02d1f098: mov     w1, w20                                    
02d1f09c: bl      #0x5e45408                                 UnityEngine.CanvasGroup::set_blocksRaycasts
02d1f0a0: ldr     x8, [x19, #0x38]                           ._commentHandler
02d1f0a4: cbz     x8, #0x2d1f0b8                             
02d1f0a8: strb    w20, [x8, #0x20]                           
02d1f0ac: ldp     x20, x19, [sp, #0x10]                      
02d1f0b0: ldr     x30, [sp], #0x20                           
02d1f0b4: ret                                                
02d1f0b8: bl      #0x2b7105c                                 fn_2b7105c
## .ctor() -> void
---- Home.PopupIntroBlindbag::.ctor 0x2d1fe8c
02d1fe8c: mov     x1, xzr                                    
02d1fe90: b       #0x2cddba8                                 PopupBase::.ctor
## <OnShow>b__12_0() -> void
---- Home.PopupIntroBlindbag::<OnShow>b__12_0 0x2d1fe94
02d1fe94: stp     x30, x19, [sp, #-0x10]!                    
02d1fe98: mov     x19, x0                                    
02d1fe9c: ldr     x0, [x0, #0x40]                            ._playButton
02d1fea0: cbz     x0, #0x2d1fedc                             
02d1fea4: mov     w1, #1                                     
02d1fea8: mov     x2, xzr                                    
02d1feac: bl      #0x5e662d4                                 UnityEngine.UI.Selectable::set_interactable
02d1feb0: ldr     x0, [x19, #0x40]                           ._playButton
02d1feb4: cbz     x0, #0x2d1fedc                             
02d1feb8: mov     x1, xzr                                    
02d1febc: bl      #0x5b339ec                                 UnityEngine.Component::get_gameObject
02d1fec0: cbz     x0, #0x2d1fedc                             
02d1fec4: mov     w1, #1                                     
02d1fec8: mov     x2, xzr                                    
02d1fecc: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d1fed0: mov     x0, x19                                    
02d1fed4: ldp     x30, x19, [sp], #0x10                      
02d1fed8: b       #0x2d1fd34                                 Home.PopupIntroBlindbag::StartButtonPlayAnim
02d1fedc: bl      #0x2b7105c                                 fn_2b7105c
## <>n__0() -> void
---- Home.PopupIntroBlindbag::<>n__0 0x2d1fee0
02d1fee0: mov     x1, xzr                                    
02d1fee4: b       #0x2cdd6b8                                 UIBase::OnShow
## <OnButtonBackClicked>b__14_0() -> void
---- Home.PopupIntroBlindbag::<OnButtonBackClicked>b__14_0 0x2d1fee8
02d1fee8: str     x30, [sp, #-0x20]!                         
02d1feec: stp     x20, x19, [sp, #0x10]                      
02d1fef0: adrp    x20, #0x6630000                            
02d1fef4: mov     x19, x0                                    
02d1fef8: ldrb    w8, [x20, #0x43]                           
02d1fefc: tbnz    w8, #0, #0x2d1ff14                         
02d1ff00: adrp    x0, #0x6268000                             
02d1ff04: ldr     x0, [x0, #0x108]                           MS:UIManager::ShowScreen
02d1ff08: bl      #0x2b70db0                                 fn_2b70db0
02d1ff0c: mov     w8, #1                                     
02d1ff10: strb    w8, [x20, #0x43]                           
02d1ff14: ldr     x8, [x19]                                  
02d1ff18: mov     x0, x19                                    
02d1ff1c: ldp     x9, x1, [x8, #0x198]                       
02d1ff20: blr     x9                                         
02d1ff24: ldr     x0, [x19, #0x30]                           
02d1ff28: cbz     x0, #0x2d1ff50                             
02d1ff2c: adrp    x8, #0x6268000                             
02d1ff30: ldr     x8, [x8, #0x108]                           MS:UIManager::ShowScreen
02d1ff34: ldr     x1, [x8]                                   S:'{0}/2'
02d1ff38: bl      #0x33fc0e8                                 fn_33fc0e8
02d1ff3c: cbz     x0, #0x2d1ff50                             
02d1ff40: ldp     x20, x19, [sp, #0x10]                      
02d1ff44: mov     x1, xzr                                    
02d1ff48: ldr     x30, [sp], #0x20                           
02d1ff4c: b       #0x2cb2bd0                                 ScreenHome::MoveMoneyLeft
02d1ff50: bl      #0x2b7105c                                 fn_2b7105c
