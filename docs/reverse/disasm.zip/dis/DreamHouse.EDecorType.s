#### CLASS DreamHouse.EDecorType parent= int
#   field value__                        int                                                off=0x10 attr=606 
#   field Floor                          DreamHouse.EDecorType                              off=0x0 attr=8056 
#   field Wall                           DreamHouse.EDecorType                              off=0x0 attr=8056 
#   field Sofa                           DreamHouse.EDecorType                              off=0x0 attr=8056 
#   field Window                         DreamHouse.EDecorType                              off=0x0 attr=8056 
#   field Television                     DreamHouse.EDecorType                              off=0x0 attr=8056 
#   field Cabinet                        DreamHouse.EDecorType                              off=0x0 attr=8056 
#   field Table                          DreamHouse.EDecorType                              off=0x0 attr=8056 
#   field Chair                          DreamHouse.EDecorType                              off=0x0 attr=8056 
#   field Lamp                           DreamHouse.EDecorType                              off=0x0 attr=8056 
#   field Picture                        DreamHouse.EDecorType                              off=0x0 attr=8056 
#   field Carpet                         DreamHouse.EDecorType                              off=0x0 attr=8056 
#   field Plant                          DreamHouse.EDecorType                              off=0x0 attr=8056 
