#### CLASS Clicker.UnlockSlotPopup parent= Clicker.CollectionFullPopup
## .ctor() -> void
---- Clicker.UnlockSlotPopup::.ctor 0x2d74e20
02d74e20: mov     x1, xzr                                    
02d74e24: b       #0x2d677e4                                 Clicker.CollectionFullPopup::.ctor
