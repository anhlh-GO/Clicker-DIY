#### CLASS IAPProductSO parent= UnityEngine.ScriptableObject
#   field _productsList                  System.Collections.Generic.List`1<IAPProduct>      off=0x18 attr=1 SerializeField
## GetIAPProducts() -> System.Collections.Generic.List`1<IAPProduct>
---- IAPProductSO::GetIAPProducts 0x2ca7fbc
02ca7fbc: ldr     x0, [x0, #0x18]                            ._productsList
02ca7fc0: ret                                                
## .ctor() -> void
---- IAPProductSO::.ctor 0x2ca7fc4
02ca7fc4: str     x30, [sp, #-0x30]!                         
02ca7fc8: stp     x22, x21, [sp, #0x10]                      
02ca7fcc: stp     x20, x19, [sp, #0x20]                      
02ca7fd0: adrp    x21, #0x662f000                            
02ca7fd4: adrp    x22, #0x6266000                            
02ca7fd8: adrp    x20, #0x6266000                            
02ca7fdc: ldrb    w8, [x21, #0xaea]                          
02ca7fe0: ldr     x22, [x22, #0x530]                         T:type15009(k15)
02ca7fe4: ldr     x20, [x20, #0x538]                         MS:System.Collections.Generic.List`1::.ctor
02ca7fe8: mov     x19, x0                                    
02ca7fec: tbnz    w8, #0, #0x2ca8010                         
02ca7ff0: adrp    x0, #0x6266000                             
02ca7ff4: ldr     x0, [x0, #0x538]                           MS:System.Collections.Generic.List`1::.ctor
02ca7ff8: bl      #0x2b70db0                                 fn_2b70db0
02ca7ffc: adrp    x0, #0x6266000                             
02ca8000: ldr     x0, [x0, #0x530]                           T:type15009(k15)
02ca8004: bl      #0x2b70db0                                 fn_2b70db0
02ca8008: mov     w8, #1                                     
02ca800c: strb    w8, [x21, #0xaea]                          
02ca8010: ldr     x0, [x22]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca8014: bl      #0x2b7104c                                 fn_2b7104c
02ca8018: ldr     x1, [x20]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca801c: mov     x20, x0                                    
02ca8020: bl      #0x35a89a4                                 fn_35a89a4
02ca8024: mov     x0, x19                                    
02ca8028: mov     x1, x20                                    
02ca802c: str     x20, [x0, #0x18]!                          ._productsList
02ca8030: bl      #0x2b70d54                                 fn_2b70d54
02ca8034: mov     x0, x19                                    
02ca8038: ldp     x20, x19, [sp, #0x20]                      
02ca803c: ldp     x22, x21, [sp, #0x10]                      
02ca8040: mov     x1, xzr                                    
02ca8044: ldr     x30, [sp], #0x30                           
02ca8048: b       #0x5b398f0                                 UnityEngine.ScriptableObject::.ctor
