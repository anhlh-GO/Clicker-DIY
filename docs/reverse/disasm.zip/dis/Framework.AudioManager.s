#### CLASS Framework.AudioManager/<>c parent= object
#   field <>9                            Framework.AudioManager/<>c                         off=0x0 attr=36 
#   field <>9__13_0                      System.Func`2<Framework.MusicChannel,bool>         off=0x8 attr=16 
#   field <>9__30_0                      System.Func`2<Framework.MusicChannel,bool>         off=0x10 attr=16 
#   field <>9__33_0                      System.Action`1<Framework.MusicChannel>            off=0x18 attr=16 
#   field <>9__34_0                      System.Func`2<Framework.MusicChannel,bool>         off=0x20 attr=16 
#   field <>9__37_0                      System.Func`2<Framework.SoundChannel,bool>         off=0x28 attr=16 
#   field <>9__41_1                      System.Action`1<Framework.SoundChannel>            off=0x30 attr=16 
#   field <>9__42_1                      System.Action`1<Framework.SoundChannel>            off=0x38 attr=16 
#   field <>9__43_1                      System.Action`1<Framework.SoundChannel>            off=0x40 attr=16 
#   field <>9__44_0                      System.Action`1<Framework.SoundChannel>            off=0x48 attr=16 
## .cctor() -> void
---- Framework.AudioManager/<>c::.cctor 0x2d8684c
02d8684c: str     x30, [sp, #-0x20]!                         
02d86850: stp     x20, x19, [sp, #0x10]                      
02d86854: adrp    x19, #0x6630000                            
02d86858: adrp    x20, #0x626d000                            
02d8685c: ldrb    w8, [x19, #0x48f]                          
02d86860: ldr     x20, [x20, #0xa0]                          T:Framework.AudioManager/<>c
02d86864: tbnz    w8, #0, #0x2d8687c                         
02d86868: adrp    x0, #0x626d000                             
02d8686c: ldr     x0, [x0, #0xa0]                            T:Framework.AudioManager/<>c
02d86870: bl      #0x2b70db0                                 fn_2b70db0
02d86874: mov     w8, #1                                     
02d86878: strb    w8, [x19, #0x48f]                          
02d8687c: ldr     x0, [x20]                                  MS:System.Collections.Generic.List`1::.ctor
02d86880: bl      #0x2b7104c                                 fn_2b7104c
02d86884: mov     x1, xzr                                    
02d86888: mov     x19, x0                                    
02d8688c: bl      #0x4e53e9c                                 System.Object::.ctor
02d86890: ldr     x8, [x20]                                  MS:System.Collections.Generic.List`1::.ctor
02d86894: mov     x1, x19                                    
02d86898: ldr     x8, [x8, #0xb8]                            
02d8689c: str     x19, [x8]                                  
02d868a0: ldr     x8, [x20]                                  MS:System.Collections.Generic.List`1::.ctor
02d868a4: ldp     x20, x19, [sp, #0x10]                      
02d868a8: ldr     x0, [x8, #0xb8]                            
02d868ac: ldr     x30, [sp], #0x20                           
02d868b0: b       #0x2b70d54                                 
## .ctor() -> void
---- Framework.AudioManager/<>c::.ctor 0x2d868b4
02d868b4: mov     x1, xzr                                    
02d868b8: b       #0x4e53e9c                                 System.Object::.ctor
## <get_CurrentMusicKey>b__13_0(Framework.MusicChannel m) -> bool
---- Framework.AudioManager/<>c::<get_CurrentMusicKey>b__13_0 0x2d868bc
02d868bc: cbz     x1, #0x2d868c8                             
02d868c0: ldrb    w0, [x1, #0x20]                            
02d868c4: ret                                                
02d868c8: str     x30, [sp, #-0x10]!                         
02d868cc: bl      #0x2b7105c                                 fn_2b7105c
## <SetVolumeMusic>b__30_0(Framework.MusicChannel m) -> bool
---- Framework.AudioManager/<>c::<SetVolumeMusic>b__30_0 0x2d868d0
02d868d0: cbz     x1, #0x2d868dc                             
02d868d4: ldrb    w0, [x1, #0x20]                            
02d868d8: ret                                                
02d868dc: str     x30, [sp, #-0x10]!                         
02d868e0: bl      #0x2b7105c                                 fn_2b7105c
## <StopAllMusic>b__33_0(Framework.MusicChannel m) -> void
---- Framework.AudioManager/<>c::<StopAllMusic>b__33_0 0x2d868e4
02d868e4: cbz     x1, #0x2d868f0                             
02d868e8: mov     x0, x1                                     
02d868ec: b       #0x2d855b4                                 Framework.MusicChannel::Stop
02d868f0: ret                                                
## <GetFreeMusicChannel>b__34_0(Framework.MusicChannel c) -> bool
---- Framework.AudioManager/<>c::<GetFreeMusicChannel>b__34_0 0x2d868f4
02d868f4: cbz     x1, #0x2d86908                             
02d868f8: ldrb    w8, [x1, #0x20]                            
02d868fc: cmp     w8, #0                                     
02d86900: cset    w0, eq                                     
02d86904: ret                                                
02d86908: str     x30, [sp, #-0x10]!                         
02d8690c: bl      #0x2b7105c                                 fn_2b7105c
## <GetFreeSoundChannel>b__37_0(Framework.SoundChannel c) -> bool
---- Framework.AudioManager/<>c::<GetFreeSoundChannel>b__37_0 0x2d86910
02d86910: cbz     x1, #0x2d86924                             
02d86914: ldrb    w8, [x1, #0x20]                            
02d86918: cmp     w8, #0                                     
02d8691c: cset    w0, eq                                     
02d86920: ret                                                
02d86924: str     x30, [sp, #-0x10]!                         
02d86928: bl      #0x2b7105c                                 fn_2b7105c
## <StopSound>b__41_1(Framework.SoundChannel channel) -> void
---- Framework.AudioManager/<>c::<StopSound>b__41_1 0x2d8692c
02d8692c: cbz     x1, #0x2d86938                             
02d86930: mov     x0, x1                                     
02d86934: b       #0x2d86940                                 Framework.SoundChannel::Stop
02d86938: str     x30, [sp, #-0x10]!                         
02d8693c: bl      #0x2b7105c                                 fn_2b7105c
## <PauseSound>b__42_1(Framework.SoundChannel channel) -> void
---- Framework.AudioManager/<>c::<PauseSound>b__42_1 0x2d86970
02d86970: cbz     x1, #0x2d8697c                             
02d86974: mov     x0, x1                                     
02d86978: b       #0x2d86984                                 Framework.SoundChannel::Pause
02d8697c: str     x30, [sp, #-0x10]!                         
02d86980: bl      #0x2b7105c                                 fn_2b7105c
## <ResumeSound>b__43_1(Framework.SoundChannel channel) -> void
---- Framework.AudioManager/<>c::<ResumeSound>b__43_1 0x2d869b4
02d869b4: cbz     x1, #0x2d869c0                             
02d869b8: mov     x0, x1                                     
02d869bc: b       #0x2d869c8                                 Framework.SoundChannel::Resume
02d869c0: str     x30, [sp, #-0x10]!                         
02d869c4: bl      #0x2b7105c                                 fn_2b7105c
## <StopAllSound>b__44_0(Framework.SoundChannel channel) -> void
---- Framework.AudioManager/<>c::<StopAllSound>b__44_0 0x2d86a08
02d86a08: cbz     x1, #0x2d86a14                             
02d86a0c: mov     x0, x1                                     
02d86a10: b       #0x2d86940                                 Framework.SoundChannel::Stop
02d86a14: str     x30, [sp, #-0x10]!                         
02d86a18: bl      #0x2b7105c                                 fn_2b7105c
#### CLASS Framework.AudioManager/<>c__DisplayClass31_0 parent= object
#   field musicKey                       Framework.EMusic                                   off=0x10 attr=6 
## .ctor() -> void
---- Framework.AudioManager/<>c__DisplayClass31_0::.ctor 0x2d855ac
02d855ac: mov     x1, xzr                                    
02d855b0: b       #0x4e53e9c                                 System.Object::.ctor
## <StopMusic>b__0(Framework.MusicChannel m) -> bool
---- Framework.AudioManager/<>c__DisplayClass31_0::<StopMusic>b__0 0x2d86a1c
02d86a1c: cbz     x1, #0x2d86a34                             
02d86a20: ldr     w8, [x1, #0x30]                            
02d86a24: ldr     w9, [x0, #0x10]                            .musicKey
02d86a28: cmp     w8, w9                                     
02d86a2c: cset    w0, eq                                     
02d86a30: ret                                                
02d86a34: str     x30, [sp, #-0x10]!                         
02d86a38: bl      #0x2b7105c                                 fn_2b7105c
#### CLASS Framework.AudioManager/<>c__DisplayClass32_0 parent= object
#   field musicKey                       Framework.EMusic                                   off=0x10 attr=6 
## .ctor() -> void
---- Framework.AudioManager/<>c__DisplayClass32_0::.ctor 0x2d856b8
02d856b8: mov     x1, xzr                                    
02d856bc: b       #0x4e53e9c                                 System.Object::.ctor
## <IsMusicPlaying>b__0(Framework.MusicChannel c) -> bool
---- Framework.AudioManager/<>c__DisplayClass32_0::<IsMusicPlaying>b__0 0x2d86a3c
02d86a3c: cbz     x1, #0x2d86a68                             
02d86a40: ldr     w8, [x1, #0x30]                            
02d86a44: ldr     w9, [x0, #0x10]                            .musicKey
02d86a48: cmp     w8, w9                                     
02d86a4c: b.ne    #0x2d86a60                                 
02d86a50: ldrb    w8, [x1, #0x20]                            
02d86a54: cmp     w8, #0                                     
02d86a58: cset    w0, ne                                     
02d86a5c: ret                                                
02d86a60: mov     w0, wzr                                    
02d86a64: ret                                                
02d86a68: str     x30, [sp, #-0x10]!                         
02d86a6c: bl      #0x2b7105c                                 fn_2b7105c
#### CLASS Framework.AudioManager/<>c__DisplayClass35_0 parent= object
#   field musicKey                       Framework.EMusic                                   off=0x10 attr=6 
## .ctor() -> void
---- Framework.AudioManager/<>c__DisplayClass35_0::.ctor 0x2d856c0
02d856c0: mov     x1, xzr                                    
02d856c4: b       #0x4e53e9c                                 System.Object::.ctor
## <GetMusicAudioClip>b__0(UnityEngine.AudioClip clip) -> bool
---- Framework.AudioManager/<>c__DisplayClass35_0::<GetMusicAudioClip>b__0 0x2d86a70
02d86a70: sub     sp, sp, #0x40                              
02d86a74: stp     x30, x21, [sp, #0x20]                      
02d86a78: stp     x20, x19, [sp, #0x30]                      
02d86a7c: adrp    x21, #0x6630000                            
02d86a80: mov     x20, x1                                    
02d86a84: mov     x19, x0                                    
02d86a88: ldrb    w8, [x21, #0x490]                          
02d86a8c: tbnz    w8, #0, #0x2d86aa4                         
02d86a90: adrp    x0, #0x626d000                             
02d86a94: ldr     x0, [x0, #0xc8]                            T:Framework.EMusic
02d86a98: bl      #0x2b70db0                                 fn_2b70db0
02d86a9c: mov     w8, #1                                     
02d86aa0: strb    w8, [x21, #0x490]                          
02d86aa4: cbz     x20, #0x2d86b04                            
02d86aa8: adrp    x21, #0x626d000                            
02d86aac: mov     x0, x20                                    
02d86ab0: mov     x1, xzr                                    
02d86ab4: ldr     x21, [x21, #0xc8]                          T:Framework.EMusic
02d86ab8: bl      #0x5b3bba4                                 UnityEngine.Object::get_name
02d86abc: ldr     x8, [x21]                                  MS:System.Collections.Generic.List`1::.ctor
02d86ac0: ldr     w10, [x19, #0x10]                          .musicKey
02d86ac4: mov     x20, x0                                    
02d86ac8: mov     x9, #-1                                    
02d86acc: add     x0, sp, #8                                 
02d86ad0: mov     x1, xzr                                    
02d86ad4: stp     x8, x9, [sp, #8]                           
02d86ad8: str     w10, [sp, #0x18]                           
02d86adc: bl      #0x4e47e48                                 System.Enum::ToString
02d86ae0: mov     x1, x0                                     
02d86ae4: mov     x0, x20                                    
02d86ae8: mov     x2, xzr                                    
02d86aec: bl      #0x4ca52b8                                 System.String::op_Equality
02d86af0: ldp     x20, x19, [sp, #0x30]                      
02d86af4: and     w0, w0, #1                                 
02d86af8: ldp     x30, x21, [sp, #0x20]                      
02d86afc: add     sp, sp, #0x40                              
02d86b00: ret                                                
02d86b04: bl      #0x2b7105c                                 fn_2b7105c
#### CLASS Framework.AudioManager/<>c__DisplayClass38_0 parent= object
#   field soundKey                       Framework.ESound                                   off=0x10 attr=6 
## .ctor() -> void
---- Framework.AudioManager/<>c__DisplayClass38_0::.ctor 0x2d85a7c
02d85a7c: mov     x1, xzr                                    
02d85a80: b       #0x4e53e9c                                 System.Object::.ctor
## <IsSoundPlaying>b__0(Framework.SoundChannel c) -> bool
---- Framework.AudioManager/<>c__DisplayClass38_0::<IsSoundPlaying>b__0 0x2d86b08
02d86b08: cbz     x1, #0x2d86b34                             
02d86b0c: ldr     w8, [x1, #0x30]                            
02d86b10: ldr     w9, [x0, #0x10]                            .soundKey
02d86b14: cmp     w8, w9                                     
02d86b18: b.ne    #0x2d86b2c                                 
02d86b1c: ldrb    w8, [x1, #0x20]                            
02d86b20: cmp     w8, #0                                     
02d86b24: cset    w0, ne                                     
02d86b28: ret                                                
02d86b2c: mov     w0, wzr                                    
02d86b30: ret                                                
02d86b34: str     x30, [sp, #-0x10]!                         
02d86b38: bl      #0x2b7105c                                 fn_2b7105c
#### CLASS Framework.AudioManager/<>c__DisplayClass39_0 parent= object
#   field soundKey                       Framework.ESound                                   off=0x10 attr=6 
## .ctor() -> void
---- Framework.AudioManager/<>c__DisplayClass39_0::.ctor 0x2d85b58
02d85b58: mov     x1, xzr                                    
02d85b5c: b       #0x4e53e9c                                 System.Object::.ctor
## <IsSoundPaused>b__0(Framework.SoundChannel c) -> bool
---- Framework.AudioManager/<>c__DisplayClass39_0::<IsSoundPaused>b__0 0x2d86b3c
02d86b3c: cbz     x1, #0x2d86b60                             
02d86b40: ldr     w8, [x1, #0x30]                            
02d86b44: ldr     w9, [x0, #0x10]                            .soundKey
02d86b48: cmp     w8, w9                                     
02d86b4c: b.ne    #0x2d86b58                                 
02d86b50: mov     x0, x1                                     
02d86b54: b       #0x2d86b68                                 Framework.SoundChannel::IsPaused
02d86b58: mov     w0, wzr                                    
02d86b5c: ret                                                
02d86b60: str     x30, [sp, #-0x10]!                         
02d86b64: bl      #0x2b7105c                                 fn_2b7105c
#### CLASS Framework.AudioManager/<>c__DisplayClass40_0 parent= object
#   field soundKey                       Framework.ESound                                   off=0x10 attr=6 
## .ctor() -> void
---- Framework.AudioManager/<>c__DisplayClass40_0::.ctor 0x2d85b60
02d85b60: mov     x1, xzr                                    
02d85b64: b       #0x4e53e9c                                 System.Object::.ctor
## <GetSoundAudioClip>b__0(UnityEngine.AudioClip clip) -> bool
---- Framework.AudioManager/<>c__DisplayClass40_0::<GetSoundAudioClip>b__0 0x2d86be4
02d86be4: sub     sp, sp, #0x40                              
02d86be8: stp     x30, x21, [sp, #0x20]                      
02d86bec: stp     x20, x19, [sp, #0x30]                      
02d86bf0: adrp    x21, #0x6630000                            
02d86bf4: mov     x20, x1                                    
02d86bf8: mov     x19, x0                                    
02d86bfc: ldrb    w8, [x21, #0x491]                          
02d86c00: tbnz    w8, #0, #0x2d86c18                         
02d86c04: adrp    x0, #0x626d000                             
02d86c08: ldr     x0, [x0, #0x2e0]                           T:Framework.ESound
02d86c0c: bl      #0x2b70db0                                 fn_2b70db0
02d86c10: mov     w8, #1                                     
02d86c14: strb    w8, [x21, #0x491]                          
02d86c18: cbz     x20, #0x2d86c78                            
02d86c1c: adrp    x21, #0x626d000                            
02d86c20: mov     x0, x20                                    
02d86c24: mov     x1, xzr                                    
02d86c28: ldr     x21, [x21, #0x2e0]                         T:Framework.ESound
02d86c2c: bl      #0x5b3bba4                                 UnityEngine.Object::get_name
02d86c30: ldr     x8, [x21]                                  MS:System.Collections.Generic.List`1::.ctor
02d86c34: ldr     w10, [x19, #0x10]                          .soundKey
02d86c38: mov     x20, x0                                    
02d86c3c: mov     x9, #-1                                    
02d86c40: add     x0, sp, #8                                 
02d86c44: mov     x1, xzr                                    
02d86c48: stp     x8, x9, [sp, #8]                           
02d86c4c: str     w10, [sp, #0x18]                           
02d86c50: bl      #0x4e47e48                                 System.Enum::ToString
02d86c54: mov     x1, x0                                     
02d86c58: mov     x0, x20                                    
02d86c5c: mov     x2, xzr                                    
02d86c60: bl      #0x4ca52b8                                 System.String::op_Equality
02d86c64: ldp     x20, x19, [sp, #0x30]                      
02d86c68: and     w0, w0, #1                                 
02d86c6c: ldp     x30, x21, [sp, #0x20]                      
02d86c70: add     sp, sp, #0x40                              
02d86c74: ret                                                
02d86c78: bl      #0x2b7105c                                 fn_2b7105c
#### CLASS Framework.AudioManager/<>c__DisplayClass41_0 parent= object
#   field soundKey                       Framework.ESound                                   off=0x10 attr=6 
## .ctor() -> void
---- Framework.AudioManager/<>c__DisplayClass41_0::.ctor 0x2d85b68
02d85b68: mov     x1, xzr                                    
02d85b6c: b       #0x4e53e9c                                 System.Object::.ctor
## <StopSound>b__0(Framework.SoundChannel channel) -> bool
---- Framework.AudioManager/<>c__DisplayClass41_0::<StopSound>b__0 0x2d86c7c
02d86c7c: cbz     x1, #0x2d86c94                             
02d86c80: ldr     w8, [x1, #0x30]                            
02d86c84: ldr     w9, [x0, #0x10]                            .soundKey
02d86c88: cmp     w8, w9                                     
02d86c8c: cset    w0, eq                                     
02d86c90: ret                                                
02d86c94: str     x30, [sp, #-0x10]!                         
02d86c98: bl      #0x2b7105c                                 fn_2b7105c
#### CLASS Framework.AudioManager/<>c__DisplayClass42_0 parent= object
#   field soundKey                       Framework.ESound                                   off=0x10 attr=6 
## .ctor() -> void
---- Framework.AudioManager/<>c__DisplayClass42_0::.ctor 0x2d85d40
02d85d40: mov     x1, xzr                                    
02d85d44: b       #0x4e53e9c                                 System.Object::.ctor
## <PauseSound>b__0(Framework.SoundChannel channel) -> bool
---- Framework.AudioManager/<>c__DisplayClass42_0::<PauseSound>b__0 0x2d86c9c
02d86c9c: cbz     x1, #0x2d86cb4                             
02d86ca0: ldr     w8, [x1, #0x30]                            
02d86ca4: ldr     w9, [x0, #0x10]                            .soundKey
02d86ca8: cmp     w8, w9                                     
02d86cac: cset    w0, eq                                     
02d86cb0: ret                                                
02d86cb4: str     x30, [sp, #-0x10]!                         
02d86cb8: bl      #0x2b7105c                                 fn_2b7105c
#### CLASS Framework.AudioManager/<>c__DisplayClass43_0 parent= object
#   field soundKey                       Framework.ESound                                   off=0x10 attr=6 
## .ctor() -> void
---- Framework.AudioManager/<>c__DisplayClass43_0::.ctor 0x2d85f18
02d85f18: mov     x1, xzr                                    
02d85f1c: b       #0x4e53e9c                                 System.Object::.ctor
## <ResumeSound>b__0(Framework.SoundChannel channel) -> bool
---- Framework.AudioManager/<>c__DisplayClass43_0::<ResumeSound>b__0 0x2d86cbc
02d86cbc: cbz     x1, #0x2d86cd4                             
02d86cc0: ldr     w8, [x1, #0x30]                            
02d86cc4: ldr     w9, [x0, #0x10]                            .soundKey
02d86cc8: cmp     w8, w9                                     
02d86ccc: cset    w0, eq                                     
02d86cd0: ret                                                
02d86cd4: str     x30, [sp, #-0x10]!                         
02d86cd8: bl      #0x2b7105c                                 fn_2b7105c
#### CLASS Framework.AudioManager parent= UnityEngine.MonoBehaviour
#   field _musicClipList                 System.Collections.Generic.List`1<UnityEngine.AudioClip> off=0x20 attr=1 HeaderAttribute,SerializeField
#   field _soundClipList                 System.Collections.Generic.List`1<UnityEngine.AudioClip> off=0x28 attr=1 SerializeField
#   field _musicChannelPrefab            Framework.MusicChannel                             off=0x30 attr=1 HeaderAttribute,SerializeField
#   field _soundChannelPrefab            Framework.SoundChannel                             off=0x38 attr=1 SerializeField
#   field _musicChannels                 System.Collections.Generic.List`1<Framework.MusicChannel> off=0x40 attr=1 
#   field _soundChannels                 System.Collections.Generic.List`1<Framework.SoundChannel> off=0x48 attr=1 
#   field _bgmClipDic                    System.Collections.Generic.Dictionary`2<Framework.EMusic,UnityEngine.AudioClip> off=0x50 attr=1 
#   field _soundClipDic                  System.Collections.Generic.Dictionary`2<Framework.ESound,UnityEngine.AudioClip> off=0x58 attr=1 
#   field _isMuteMusic                   bool                                               off=0x60 attr=1 
#   field _isMuteSound                   bool                                               off=0x61 attr=1 
#   field _musicChannelPool              UnityEngine.Pool.ObjectPool`1<Framework.MusicChannel> off=0x68 attr=1 
#   field _soundChannelPool              UnityEngine.Pool.ObjectPool`1<Framework.SoundChannel> off=0x70 attr=1 
#   field _instance                      Framework.AudioManager                             off=0x0 attr=11 
#   field _homeBGMList                   System.Collections.Generic.List`1<Framework.EMusic> off=0x78 attr=1 
## get_CurrentMusicKey() -> Framework.EMusic
---- Framework.AudioManager::get_CurrentMusicKey 0x2d84854
02d84854: stp     x30, x23, [sp, #-0x30]!                    
02d84858: stp     x22, x21, [sp, #0x10]                      
02d8485c: stp     x20, x19, [sp, #0x20]                      
02d84860: adrp    x20, #0x6630000                            
02d84864: adrp    x22, #0x626d000                            
02d84868: mov     x19, x0                                    
02d8486c: ldrb    w8, [x20, #0x46d]                          
02d84870: ldr     x22, [x22, #0xa0]                          T:Framework.AudioManager/<>c
02d84874: tbnz    w8, #0, #0x2d848b0                         
02d84878: adrp    x0, #0x626d000                             
02d8487c: ldr     x0, [x0, #0xb0]                            MS:System.Linq.Enumerable::FirstOrDefault
02d84880: bl      #0x2b70db0                                 fn_2b70db0
02d84884: adrp    x0, #0x626d000                             
02d84888: ldr     x0, [x0, #0xb8]                            T:type55599(k15)
02d8488c: bl      #0x2b70db0                                 fn_2b70db0
02d84890: adrp    x0, #0x626d000                             
02d84894: ldr     x0, [x0, #0xd8]                            M:Framework.AudioManager/<>c::<get_CurrentMusicKey>b__13_0
02d84898: bl      #0x2b70db0                                 fn_2b70db0
02d8489c: adrp    x0, #0x626d000                             
02d848a0: ldr     x0, [x0, #0xa0]                            T:Framework.AudioManager/<>c
02d848a4: bl      #0x2b70db0                                 fn_2b70db0
02d848a8: mov     w8, #1                                     
02d848ac: strb    w8, [x20, #0x46d]                          
02d848b0: ldr     x0, [x22]                                  MS:System.Collections.Generic.List`1::.ctor
02d848b4: ldr     x19, [x19, #0x40]                          ._musicChannels
02d848b8: ldr     w8, [x0, #0xe4]                            [626d0e4]=0 f=0,0
02d848bc: cbnz    w8, #0x2d848c8                             
02d848c0: bl      #0x2b70f30                                 fn_2b70f30
02d848c4: ldr     x0, [x22]                                  MS:System.Collections.Generic.List`1::.ctor
02d848c8: ldr     x8, [x0, #0xb8]                            T:type55599(k15)
02d848cc: adrp    x23, #0x626d000                            
02d848d0: ldr     x20, [x8, #8]                              
02d848d4: ldr     x23, [x23, #0xb0]                          MS:System.Linq.Enumerable::FirstOrDefault
02d848d8: cbnz    x20, #0x2d84934                            
02d848dc: ldr     w9, [x0, #0xe4]                            [626d0e4]=0 f=0,0
02d848e0: cbnz    w9, #0x2d848f0                             
02d848e4: bl      #0x2b70f30                                 fn_2b70f30
02d848e8: ldr     x8, [x22]                                  MS:System.Collections.Generic.List`1::.ctor
02d848ec: ldr     x8, [x8, #0xb8]                            
02d848f0: adrp    x9, #0x626d000                             
02d848f4: ldr     x9, [x9, #0xb8]                            T:type55599(k15)
02d848f8: ldr     x21, [x8]                                  
02d848fc: ldr     x0, [x9]                                   MS:System.Collections.Generic.List`1::.ctor
02d84900: bl      #0x2b7104c                                 fn_2b7104c
02d84904: adrp    x8, #0x626d000                             
02d84908: mov     x1, x21                                    
02d8490c: mov     x3, xzr                                    
02d84910: ldr     x8, [x8, #0xd8]                            M:Framework.AudioManager/<>c::<get_CurrentMusicKey>b__13_0
02d84914: mov     x20, x0                                    
02d84918: ldr     x2, [x8]                                   MS:System.Collections.Generic.List`1::.ctor
02d8491c: bl      #0x4940cf8                                 fn_4940cf8
02d84920: ldr     x8, [x22]                                  MS:System.Collections.Generic.List`1::.ctor
02d84924: mov     x1, x20                                    
02d84928: ldr     x0, [x8, #0xb8]                            T:type55599(k15)
02d8492c: str     x20, [x0, #8]!                             
02d84930: bl      #0x2b70d54                                 fn_2b70d54
02d84934: ldr     x2, [x23]                                  MS:System.Collections.Generic.List`1::.ctor
02d84938: mov     x0, x19                                    
02d8493c: mov     x1, x20                                    
02d84940: bl      #0x318c658                                 fn_318c658
02d84944: cbz     x0, #0x2d8494c                             
02d84948: ldr     w0, [x0, #0x30]                            M:Redcode.Demo.DestroyChildsWhere/<>c::<Update>b__1_0 ._musicChannelPrefab
02d8494c: ldp     x20, x19, [sp, #0x20]                      
02d84950: ldp     x22, x21, [sp, #0x10]                      
02d84954: ldp     x30, x23, [sp], #0x30                      
02d84958: ret                                                
## get_IsMusicOn() -> bool
---- Framework.AudioManager::get_IsMusicOn 0x2d8495c
02d8495c: str     x30, [sp, #-0x20]!                         
02d84960: stp     x20, x19, [sp, #0x10]                      
02d84964: adrp    x19, #0x6630000                            
02d84968: adrp    x20, #0x6266000                            
02d8496c: ldrb    w8, [x19, #0x46e]                          
02d84970: ldr     x20, [x20, #0x658]                         MS:MonoSingleton`1::get_Instance
02d84974: tbnz    w8, #0, #0x2d84998                         
02d84978: adrp    x0, #0x6266000                             
02d8497c: ldr     x0, [x0, #0x750]                           MS:DataManager::GetData
02d84980: bl      #0x2b70db0                                 fn_2b70db0
02d84984: adrp    x0, #0x6266000                             
02d84988: ldr     x0, [x0, #0x658]                           MS:MonoSingleton`1::get_Instance
02d8498c: bl      #0x2b70db0                                 fn_2b70db0
02d84990: mov     w8, #1                                     
02d84994: strb    w8, [x19, #0x46e]                          
02d84998: ldr     x0, [x20]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d8499c: bl      #0x3769600                                 fn_3769600
02d849a0: cbz     x0, #0x2d849c8                             
02d849a4: adrp    x8, #0x6266000                             
02d849a8: ldr     x8, [x8, #0x750]                           MS:DataManager::GetData
02d849ac: ldr     x1, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d849b0: bl      #0x3168dd0                                 fn_3168dd0
02d849b4: cbz     x0, #0x2d849c8                             
02d849b8: ldp     x20, x19, [sp, #0x10]                      
02d849bc: mov     x1, xzr                                    
02d849c0: ldr     x30, [sp], #0x20                           
02d849c4: b       #0x2cab978                                 DataUser::HasMusic
02d849c8: bl      #0x2b7105c                                 fn_2b7105c
## get_IsSoundOn() -> bool
---- Framework.AudioManager::get_IsSoundOn 0x2d849cc
02d849cc: str     x30, [sp, #-0x20]!                         
02d849d0: stp     x20, x19, [sp, #0x10]                      
02d849d4: adrp    x19, #0x6630000                            
02d849d8: adrp    x20, #0x6266000                            
02d849dc: ldrb    w8, [x19, #0x46f]                          
02d849e0: ldr     x20, [x20, #0x658]                         MS:MonoSingleton`1::get_Instance
02d849e4: tbnz    w8, #0, #0x2d84a08                         
02d849e8: adrp    x0, #0x6266000                             
02d849ec: ldr     x0, [x0, #0x750]                           MS:DataManager::GetData
02d849f0: bl      #0x2b70db0                                 fn_2b70db0
02d849f4: adrp    x0, #0x6266000                             
02d849f8: ldr     x0, [x0, #0x658]                           MS:MonoSingleton`1::get_Instance
02d849fc: bl      #0x2b70db0                                 fn_2b70db0
02d84a00: mov     w8, #1                                     
02d84a04: strb    w8, [x19, #0x46f]                          
02d84a08: ldr     x0, [x20]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d84a0c: bl      #0x3769600                                 fn_3769600
02d84a10: cbz     x0, #0x2d84a38                             
02d84a14: adrp    x8, #0x6266000                             
02d84a18: ldr     x8, [x8, #0x750]                           MS:DataManager::GetData
02d84a1c: ldr     x1, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d84a20: bl      #0x3168dd0                                 fn_3168dd0
02d84a24: cbz     x0, #0x2d84a38                             
02d84a28: ldp     x20, x19, [sp, #0x10]                      
02d84a2c: mov     x1, xzr                                    
02d84a30: ldr     x30, [sp], #0x20                           
02d84a34: b       #0x2cab9b8                                 DataUser::HasSound
02d84a38: bl      #0x2b7105c                                 fn_2b7105c
## get_IsMuteMusic() -> bool
---- Framework.AudioManager::get_IsMuteMusic 0x2d84a3c
02d84a3c: ldrb    w0, [x0, #0x60]                            ._isMuteMusic
02d84a40: ret                                                
## set_IsMuteMusic(bool value) -> void
---- Framework.AudioManager::set_IsMuteMusic 0x2d84a44
02d84a44: sub     sp, sp, #0x50                              
02d84a48: stp     x30, x21, [sp, #0x30]                      
02d84a4c: stp     x20, x19, [sp, #0x40]                      
02d84a50: adrp    x21, #0x6630000                            
02d84a54: mov     x19, x0                                    
02d84a58: and     w20, w1, #1                                
02d84a5c: ldrb    w8, [x21, #0x470]                          
02d84a60: tbnz    w8, #0, #0x2d84a9c                         
02d84a64: adrp    x0, #0x626d000                             
02d84a68: ldr     x0, [x0, #0xe0]                            MS:System.Collections.Generic.List`1/Enumerator::Dispose
02d84a6c: bl      #0x2b70db0                                 fn_2b70db0
02d84a70: adrp    x0, #0x626d000                             
02d84a74: ldr     x0, [x0, #0xe8]                            MS:System.Collections.Generic.List`1/Enumerator::MoveNext
02d84a78: bl      #0x2b70db0                                 fn_2b70db0
02d84a7c: adrp    x0, #0x626d000                             
02d84a80: ldr     x0, [x0, #0xf0]                            MS:System.Collections.Generic.List`1/Enumerator::get_Current
02d84a84: bl      #0x2b70db0                                 fn_2b70db0
02d84a88: adrp    x0, #0x626d000                             
02d84a8c: ldr     x0, [x0, #0xf8]                            MS:System.Collections.Generic.List`1::GetEnumerator
02d84a90: bl      #0x2b70db0                                 fn_2b70db0
02d84a94: mov     w8, #1                                     
02d84a98: strb    w8, [x21, #0x470]                          
02d84a9c: ldrb    w8, [x19, #0x60]                           ._isMuteMusic
02d84aa0: stp     xzr, xzr, [sp, #0x18]                      
02d84aa4: str     xzr, [sp, #0x28]                           
02d84aa8: cmp     w8, w20                                    
02d84aac: b.eq    #0x2d84b24                                 
02d84ab0: ldr     x0, [x19, #0x40]                           ._musicChannels
02d84ab4: strb    w20, [x19, #0x60]                          ._isMuteMusic
02d84ab8: cbz     x0, #0x2d84b38                             
02d84abc: adrp    x8, #0x626d000                             
02d84ac0: add     x21, sp, #0x18                             
02d84ac4: ldr     x8, [x8, #0xf8]                            MS:System.Collections.Generic.List`1::GetEnumerator
02d84ac8: ldr     x1, [x8]                                   MS:System.Collections.Generic.List`1::.ctor
02d84acc: add     x8, sp, #0x18                              
02d84ad0: bl      #0x35a9d9c                                 fn_35a9d9c
02d84ad4: adrp    x20, #0x626d000                            
02d84ad8: ldr     x20, [x20, #0xe8]                          MS:System.Collections.Generic.List`1/Enumerator::MoveNext
02d84adc: stp     xzr, x21, [sp, #8]                         
02d84ae0: ldr     x1, [x20]                                  MS:System.Collections.Generic.List`1::.ctor
02d84ae4: add     x0, sp, #0x18                              
02d84ae8: bl      #0x4690474                                 fn_4690474
02d84aec: tbz     w0, #0, #0x2d84b10                         
02d84af0: ldr     x8, [sp, #0x28]                            
02d84af4: cbz     x8, #0x2d84b34                             
02d84af8: ldr     x0, [x8, #0x28]                            T:type17144(k15)
02d84afc: cbz     x0, #0x2d84b34                             
02d84b00: ldrb    w1, [x19, #0x60]                           ._isMuteMusic
02d84b04: mov     x2, xzr                                    
02d84b08: bl      #0x5adfddc                                 UnityEngine.AudioSource::set_mute
02d84b0c: b       #0x2d84ae0                                 
02d84b10: adrp    x8, #0x626d000                             
02d84b14: add     x0, sp, #0x18                              
02d84b18: ldr     x8, [x8, #0xe0]                            MS:System.Collections.Generic.List`1/Enumerator::Dispose
02d84b1c: ldr     x1, [x8]                                   MS:System.Collections.Generic.List`1::.ctor
02d84b20: bl      #0x4690470                                 fn_4690470
02d84b24: ldp     x20, x19, [sp, #0x40]                      
02d84b28: ldp     x30, x21, [sp, #0x30]                      
02d84b2c: add     sp, sp, #0x50                              
02d84b30: ret                                                
02d84b34: bl      #0x2b7105c                                 fn_2b7105c
02d84b38: bl      #0x2b7105c                                 fn_2b7105c
02d84b3c: b       #0x2d84b44                                 
02d84b40: b       #0x2d84b44                                 
02d84b44: mov     x19, x0                                    
02d84b48: cmp     w1, #1                                     
02d84b4c: b.ne    #0x2d84b88                                 
02d84b50: mov     x0, x19                                    
02d84b54: bl      #0x5e90260                                 fn_5e90260
02d84b58: ldr     x19, [x0]                                  MS:System.Collections.Generic.List`1::.ctor
02d84b5c: str     x19, [sp, #8]                              
02d84b60: bl      #0x5e90270                                 fn_5e90270
02d84b64: adrp    x8, #0x626d000                             
02d84b68: ldr     x8, [x8, #0xe0]                            MS:System.Collections.Generic.List`1/Enumerator::Dispose
02d84b6c: ldr     x0, [sp, #0x10]                            
02d84b70: ldr     x1, [x8]                                   MS:System.Collections.Generic.List`1::.ctor
02d84b74: bl      #0x4690470                                 fn_4690470
02d84b78: cbz     x19, #0x2d84b24                            
02d84b7c: mov     x0, x19                                    
02d84b80: bl      #0x2b71054                                 fn_2b71054
02d84b84: mov     x19, x0                                    
02d84b88: add     x0, sp, #8                                 
02d84b8c: bl      #0x2738980                                 fn_2738980
02d84b90: mov     x0, x19                                    
02d84b94: bl      #0x2c6051c                                 fn_2c6051c
02d84b98: bl      #0x27369b8                                 fn_27369b8
## get_IsMuteSound() -> bool
---- Framework.AudioManager::get_IsMuteSound 0x2d84bb8
02d84bb8: ldrb    w0, [x0, #0x61]                            ._isMuteSound
02d84bbc: ret                                                
## set_IsMuteSound(bool value) -> void
---- Framework.AudioManager::set_IsMuteSound 0x2d84bc0
02d84bc0: sub     sp, sp, #0x50                              
02d84bc4: stp     x30, x21, [sp, #0x30]                      
02d84bc8: stp     x20, x19, [sp, #0x40]                      
02d84bcc: adrp    x21, #0x6630000                            
02d84bd0: mov     x19, x0                                    
02d84bd4: and     w20, w1, #1                                
02d84bd8: ldrb    w8, [x21, #0x471]                          
02d84bdc: tbnz    w8, #0, #0x2d84c18                         
02d84be0: adrp    x0, #0x626d000                             
02d84be4: ldr     x0, [x0, #0x100]                           MS:System.Collections.Generic.List`1/Enumerator::Dispose
02d84be8: bl      #0x2b70db0                                 fn_2b70db0
02d84bec: adrp    x0, #0x626d000                             
02d84bf0: ldr     x0, [x0, #0x108]                           MS:System.Collections.Generic.List`1/Enumerator::MoveNext
02d84bf4: bl      #0x2b70db0                                 fn_2b70db0
02d84bf8: adrp    x0, #0x626d000                             
02d84bfc: ldr     x0, [x0, #0x110]                           MS:System.Collections.Generic.List`1/Enumerator::get_Current
02d84c00: bl      #0x2b70db0                                 fn_2b70db0
02d84c04: adrp    x0, #0x626d000                             
02d84c08: ldr     x0, [x0, #0x118]                           MS:System.Collections.Generic.List`1::GetEnumerator
02d84c0c: bl      #0x2b70db0                                 fn_2b70db0
02d84c10: mov     w8, #1                                     
02d84c14: strb    w8, [x21, #0x471]                          
02d84c18: ldrb    w8, [x19, #0x61]                           ._isMuteSound
02d84c1c: stp     xzr, xzr, [sp, #0x18]                      
02d84c20: str     xzr, [sp, #0x28]                           
02d84c24: cmp     w8, w20                                    
02d84c28: b.eq    #0x2d84ca0                                 
02d84c2c: ldr     x0, [x19, #0x48]                           ._soundChannels
02d84c30: strb    w20, [x19, #0x61]                          ._isMuteSound
02d84c34: cbz     x0, #0x2d84cb4                             
02d84c38: adrp    x8, #0x626d000                             
02d84c3c: add     x21, sp, #0x18                             
02d84c40: ldr     x8, [x8, #0x118]                           MS:System.Collections.Generic.List`1::GetEnumerator
02d84c44: ldr     x1, [x8]                                   MS:System.Collections.Generic.List`1::.ctor
02d84c48: add     x8, sp, #0x18                              
02d84c4c: bl      #0x35a9d9c                                 fn_35a9d9c
02d84c50: adrp    x20, #0x626d000                            
02d84c54: ldr     x20, [x20, #0x108]                         MS:System.Collections.Generic.List`1/Enumerator::MoveNext
02d84c58: stp     xzr, x21, [sp, #8]                         
02d84c5c: ldr     x1, [x20]                                  MS:System.Collections.Generic.List`1::.ctor
02d84c60: add     x0, sp, #0x18                              
02d84c64: bl      #0x4690474                                 fn_4690474
02d84c68: tbz     w0, #0, #0x2d84c8c                         
02d84c6c: ldr     x8, [sp, #0x28]                            
02d84c70: cbz     x8, #0x2d84cb0                             
02d84c74: ldr     x0, [x8, #0x28]                            T:type17144(k15)
02d84c78: cbz     x0, #0x2d84cb0                             
02d84c7c: ldrb    w1, [x19, #0x61]                           ._isMuteSound
02d84c80: mov     x2, xzr                                    
02d84c84: bl      #0x5adfddc                                 UnityEngine.AudioSource::set_mute
02d84c88: b       #0x2d84c5c                                 
02d84c8c: adrp    x8, #0x626d000                             
02d84c90: add     x0, sp, #0x18                              
02d84c94: ldr     x8, [x8, #0x100]                           MS:System.Collections.Generic.List`1/Enumerator::Dispose
02d84c98: ldr     x1, [x8]                                   MS:System.Collections.Generic.List`1::.ctor
02d84c9c: bl      #0x4690470                                 fn_4690470
02d84ca0: ldp     x20, x19, [sp, #0x40]                      
02d84ca4: ldp     x30, x21, [sp, #0x30]                      
02d84ca8: add     sp, sp, #0x50                              
02d84cac: ret                                                
02d84cb0: bl      #0x2b7105c                                 fn_2b7105c
02d84cb4: bl      #0x2b7105c                                 fn_2b7105c
02d84cb8: b       #0x2d84cc0                                 
02d84cbc: b       #0x2d84cc0                                 
02d84cc0: mov     x19, x0                                    
02d84cc4: cmp     w1, #1                                     
02d84cc8: b.ne    #0x2d84d04                                 
02d84ccc: mov     x0, x19                                    
02d84cd0: bl      #0x5e90260                                 fn_5e90260
02d84cd4: ldr     x19, [x0]                                  MS:System.Collections.Generic.List`1::.ctor
02d84cd8: str     x19, [sp, #8]                              
02d84cdc: bl      #0x5e90270                                 fn_5e90270
02d84ce0: adrp    x8, #0x626d000                             
02d84ce4: ldr     x8, [x8, #0x100]                           MS:System.Collections.Generic.List`1/Enumerator::Dispose
02d84ce8: ldr     x0, [sp, #0x10]                            
02d84cec: ldr     x1, [x8]                                   MS:System.Collections.Generic.List`1::.ctor
02d84cf0: bl      #0x4690470                                 fn_4690470
02d84cf4: cbz     x19, #0x2d84ca0                            
02d84cf8: mov     x0, x19                                    
02d84cfc: bl      #0x2b71054                                 fn_2b71054
02d84d00: mov     x19, x0                                    
02d84d04: add     x0, sp, #8                                 
02d84d08: bl      #0x27389b0                                 fn_27389b0
02d84d0c: mov     x0, x19                                    
02d84d10: bl      #0x2c6051c                                 fn_2c6051c
02d84d14: bl      #0x27369b8                                 fn_27369b8
## get_Instance() -> Framework.AudioManager
---- Framework.AudioManager::get_Instance 0x2d6eec8
02d6eec8: stp     x30, x21, [sp, #-0x20]!                    
02d6eecc: stp     x20, x19, [sp, #0x10]                      
02d6eed0: adrp    x19, #0x6630000                            
02d6eed4: adrp    x20, #0x626c000                            
02d6eed8: adrp    x21, #0x6263000                            
02d6eedc: ldrb    w8, [x19, #0x472]                          
02d6eee0: ldr     x20, [x20, #0x4d8]                         T:Framework.AudioManager
02d6eee4: ldr     x21, [x21, #0x918]                         T:UnityEngine.Object
02d6eee8: tbnz    w8, #0, #0x2d6ef3c                         
02d6eeec: adrp    x0, #0x626c000                             
02d6eef0: ldr     x0, [x0, #0x4d8]                           T:Framework.AudioManager
02d6eef4: bl      #0x2b70db0                                 fn_2b70db0
02d6eef8: adrp    x0, #0x626c000                             
02d6eefc: ldr     x0, [x0, #0x4e0]                           MS:UnityEngine.GameObject::AddComponent
02d6ef00: bl      #0x2b70db0                                 fn_2b70db0
02d6ef04: adrp    x0, #0x6263000                             
02d6ef08: ldr     x0, [x0, #0xf58]                           T:UnityEngine.GameObject
02d6ef0c: bl      #0x2b70db0                                 fn_2b70db0
02d6ef10: adrp    x0, #0x626c000                             
02d6ef14: ldr     x0, [x0, #0x4e8]                           MS:UnityEngine.Object::FindObjectOfType
02d6ef18: bl      #0x2b70db0                                 fn_2b70db0
02d6ef1c: adrp    x0, #0x6263000                             
02d6ef20: ldr     x0, [x0, #0x918]                           T:UnityEngine.Object
02d6ef24: bl      #0x2b70db0                                 fn_2b70db0
02d6ef28: adrp    x0, #0x626c000                             
02d6ef2c: ldr     x0, [x0, #0x4f0]                           S:'AudioManager'
02d6ef30: bl      #0x2b70db0                                 fn_2b70db0
02d6ef34: mov     w8, #1                                     
02d6ef38: strb    w8, [x19, #0x472]                          
02d6ef3c: ldr     x8, [x20]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d6ef40: ldr     x0, [x21]                                  &2c5bbd4(=a9bd7bfdd503233f)
02d6ef44: ldr     x8, [x8, #0xb8]                            
02d6ef48: ldr     w9, [x0, #0xe4]                            [626c0e4]=0 f=0,0
02d6ef4c: ldr     x19, [x8]                                  
02d6ef50: cbnz    w9, #0x2d6ef58                             
02d6ef54: bl      #0x2b70f30                                 fn_2b70f30
02d6ef58: mov     x0, x19                                    
02d6ef5c: mov     x1, xzr                                    
02d6ef60: mov     x2, xzr                                    
02d6ef64: bl      #0x5b37d84                                 UnityEngine.Object::op_Equality
02d6ef68: tbz     w0, #0, #0x2d6f020                         
02d6ef6c: ldr     x0, [x21]                                  &2c5bbd4(=a9bd7bfdd503233f)
02d6ef70: adrp    x19, #0x626c000                            
02d6ef74: ldr     w8, [x0, #0xe4]                            [626c0e4]=0 f=0,0
02d6ef78: ldr     x19, [x19, #0x4e8]                         MS:UnityEngine.Object::FindObjectOfType
02d6ef7c: cbnz    w8, #0x2d6ef84                             
02d6ef80: bl      #0x2b70f30                                 fn_2b70f30
02d6ef84: ldr     x0, [x19]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d6ef88: bl      #0x3275c74                                 fn_3275c74
02d6ef8c: ldr     x8, [x20]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d6ef90: mov     x1, x0                                     
02d6ef94: ldr     x8, [x8, #0xb8]                            
02d6ef98: str     x0, [x8]                                   
02d6ef9c: ldr     x8, [x20]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d6efa0: ldr     x0, [x8, #0xb8]                            
02d6efa4: bl      #0x2b70d54                                 fn_2b70d54
02d6efa8: ldr     x8, [x20]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d6efac: mov     x1, xzr                                    
02d6efb0: mov     x2, xzr                                    
02d6efb4: ldr     x8, [x8, #0xb8]                            
02d6efb8: ldr     x0, [x8]                                   
02d6efbc: bl      #0x5b37d84                                 UnityEngine.Object::op_Equality
02d6efc0: tbz     w0, #0, #0x2d6f020                         
02d6efc4: adrp    x8, #0x6263000                             
02d6efc8: ldr     x8, [x8, #0xf58]                           T:UnityEngine.GameObject
02d6efcc: ldr     x0, [x8]                                   &2c5bbd4(=a9bd7bfdd503233f)
02d6efd0: bl      #0x2b7104c                                 fn_2b7104c
02d6efd4: adrp    x8, #0x626c000                             
02d6efd8: mov     x2, xzr                                    
02d6efdc: mov     x19, x0                                    
02d6efe0: ldr     x8, [x8, #0x4f0]                           S:'AudioManager'
02d6efe4: ldr     x1, [x8]                                   M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d6efe8: bl      #0x5b3718c                                 UnityEngine.GameObject::.ctor
02d6efec: cbz     x19, #0x2d6f038                            
02d6eff0: adrp    x8, #0x626c000                             
02d6eff4: mov     x0, x19                                    
02d6eff8: ldr     x8, [x8, #0x4e0]                           MS:UnityEngine.GameObject::AddComponent
02d6effc: ldr     x1, [x8]                                   M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d6f000: bl      #0x31d1114                                 fn_31d1114
02d6f004: ldr     x8, [x20]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d6f008: mov     x1, x0                                     
02d6f00c: ldr     x8, [x8, #0xb8]                            MS:System.Collections.Generic.List`1::Add
02d6f010: str     x0, [x8]                                   
02d6f014: ldr     x8, [x20]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d6f018: ldr     x0, [x8, #0xb8]                            MS:System.Collections.Generic.List`1::Add
02d6f01c: bl      #0x2b70d54                                 fn_2b70d54
02d6f020: ldr     x8, [x20]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d6f024: ldp     x20, x19, [sp, #0x10]                      
02d6f028: ldr     x8, [x8, #0xb8]                            MS:System.Collections.Generic.List`1::Add
02d6f02c: ldr     x0, [x8]                                   M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d6f030: ldp     x30, x21, [sp], #0x20                      
02d6f034: ret                                                
02d6f038: bl      #0x2b7105c                                 fn_2b7105c
## Awake() -> void
---- Framework.AudioManager::Awake 0x2d84d34
02d84d34: stp     x30, x21, [sp, #-0x20]!                    
02d84d38: stp     x20, x19, [sp, #0x10]                      
02d84d3c: adrp    x21, #0x6630000                            
02d84d40: adrp    x20, #0x626c000                            
02d84d44: mov     x19, x0                                    
02d84d48: ldrb    w8, [x21, #0x473]                          
02d84d4c: ldr     x20, [x20, #0x4d8]                         T:Framework.AudioManager
02d84d50: tbnz    w8, #0, #0x2d84d68                         
02d84d54: adrp    x0, #0x626c000                             
02d84d58: ldr     x0, [x0, #0x4d8]                           T:Framework.AudioManager
02d84d5c: bl      #0x2b70db0                                 fn_2b70db0
02d84d60: mov     w8, #1                                     
02d84d64: strb    w8, [x21, #0x473]                          
02d84d68: ldr     x8, [x20]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d84d6c: mov     x1, x19                                    
02d84d70: ldr     x8, [x8, #0xb8]                            
02d84d74: str     x19, [x8]                                  
02d84d78: ldr     x8, [x20]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d84d7c: ldp     x20, x19, [sp, #0x10]                      
02d84d80: ldr     x0, [x8, #0xb8]                            
02d84d84: ldp     x30, x21, [sp], #0x20                      
02d84d88: b       #0x2b70d54                                 
## Start() -> void
---- Framework.AudioManager::Start 0x2d84d8c
02d84d8c: sub     sp, sp, #0x70                              
02d84d90: stp     x29, x30, [sp, #0x10]                      
02d84d94: stp     x28, x27, [sp, #0x20]                      
02d84d98: stp     x26, x25, [sp, #0x30]                      
02d84d9c: stp     x24, x23, [sp, #0x40]                      
02d84da0: stp     x22, x21, [sp, #0x50]                      
02d84da4: stp     x20, x19, [sp, #0x60]                      
02d84da8: adrp    x26, #0x626d000                            
02d84dac: adrp    x20, #0x626d000                            
02d84db0: adrp    x25, #0x626d000                            
02d84db4: adrp    x21, #0x626d000                            
02d84db8: adrp    x22, #0x626d000                            
02d84dbc: adrp    x23, #0x626d000                            
02d84dc0: adrp    x29, #0x626d000                            
02d84dc4: adrp    x24, #0x626d000                            
02d84dc8: adrp    x28, #0x626d000                            
02d84dcc: adrp    x27, #0x6630000                            
02d84dd0: ldr     x26, [x26, #0x120]                         T:type55320(k15)
02d84dd4: ldr     x20, [x20, #0x128]                         M:Framework.AudioManager::<Start>b__28_0
02d84dd8: ldr     x25, [x25, #0x130]                         T:type53145(k15)
02d84ddc: ldr     x21, [x21, #0x138]                         M:Framework.AudioManager::<Start>b__28_1
02d84de0: ldr     x22, [x22, #0x140]                         M:Framework.AudioManager::<Start>b__28_2
02d84de4: ldr     x23, [x23, #0x148]                         M:Framework.AudioManager::<Start>b__28_3
02d84de8: ldr     x29, [x29, #0x150]                         T:type57110(k15)
02d84dec: ldr     x24, [x24, #0x158]                         MS:UnityEngine.Pool.ObjectPool`1::.ctor
02d84df0: ldr     x28, [x28, #0x70]                          T:type53156(k15)
02d84df4: ldrb    w8, [x27, #0x474]                          
02d84df8: mov     x19, x0                                    
02d84dfc: tbnz    w8, #0, #0x2d84ec8                         
02d84e00: adrp    x0, #0x626d000                             
02d84e04: ldr     x0, [x0, #0x130]                           T:type53145(k15)
02d84e08: bl      #0x2b70db0                                 fn_2b70db0
02d84e0c: adrp    x0, #0x626d000                             
02d84e10: ldr     x0, [x0, #0x70]                            T:type53156(k15) ._soundChannelPool
02d84e14: bl      #0x2b70db0                                 fn_2b70db0
02d84e18: adrp    x0, #0x626d000                             
02d84e1c: ldr     x0, [x0, #0x128]                           M:Framework.AudioManager::<Start>b__28_0
02d84e20: bl      #0x2b70db0                                 fn_2b70db0
02d84e24: adrp    x0, #0x626d000                             
02d84e28: ldr     x0, [x0, #0x138]                           M:Framework.AudioManager::<Start>b__28_1
02d84e2c: bl      #0x2b70db0                                 fn_2b70db0
02d84e30: adrp    x0, #0x626d000                             
02d84e34: ldr     x0, [x0, #0x140]                           M:Framework.AudioManager::<Start>b__28_2
02d84e38: bl      #0x2b70db0                                 fn_2b70db0
02d84e3c: adrp    x0, #0x626d000                             
02d84e40: ldr     x0, [x0, #0x148]                           M:Framework.AudioManager::<Start>b__28_3
02d84e44: bl      #0x2b70db0                                 fn_2b70db0
02d84e48: adrp    x0, #0x626d000                             
02d84e4c: ldr     x0, [x0, #0x160]                           M:Framework.AudioManager::<Start>b__28_4
02d84e50: bl      #0x2b70db0                                 fn_2b70db0
02d84e54: adrp    x0, #0x626d000                             
02d84e58: ldr     x0, [x0, #0x168]                           M:Framework.AudioManager::<Start>b__28_5
02d84e5c: bl      #0x2b70db0                                 fn_2b70db0
02d84e60: adrp    x0, #0x626d000                             
02d84e64: ldr     x0, [x0, #0x170]                           M:Framework.AudioManager::<Start>b__28_6
02d84e68: bl      #0x2b70db0                                 fn_2b70db0
02d84e6c: adrp    x0, #0x626d000                             
02d84e70: ldr     x0, [x0, #0x178]                           M:Framework.AudioManager::<Start>b__28_7
02d84e74: bl      #0x2b70db0                                 fn_2b70db0
02d84e78: adrp    x0, #0x626d000                             
02d84e7c: ldr     x0, [x0, #0x120]                           T:type55320(k15)
02d84e80: bl      #0x2b70db0                                 fn_2b70db0
02d84e84: adrp    x0, #0x626d000                             
02d84e88: ldr     x0, [x0, #0x180]                           T:type55349(k15)
02d84e8c: bl      #0x2b70db0                                 fn_2b70db0
02d84e90: adrp    x0, #0x626d000                             
02d84e94: ldr     x0, [x0, #0x158]                           MS:UnityEngine.Pool.ObjectPool`1::.ctor
02d84e98: bl      #0x2b70db0                                 fn_2b70db0
02d84e9c: adrp    x0, #0x626d000                             
02d84ea0: ldr     x0, [x0, #0x188]                           MS:UnityEngine.Pool.ObjectPool`1::.ctor
02d84ea4: bl      #0x2b70db0                                 fn_2b70db0
02d84ea8: adrp    x0, #0x626d000                             
02d84eac: ldr     x0, [x0, #0x150]                           T:type57110(k15)
02d84eb0: bl      #0x2b70db0                                 fn_2b70db0
02d84eb4: adrp    x0, #0x626d000                             
02d84eb8: ldr     x0, [x0, #0x190]                           T:type57113(k15)
02d84ebc: bl      #0x2b70db0                                 fn_2b70db0
02d84ec0: mov     w8, #1                                     
02d84ec4: strb    w8, [x27, #0x474]                          
02d84ec8: ldr     x0, [x26]                                  MS:System.Collections.Generic.List`1::.ctor
02d84ecc: bl      #0x2b7104c                                 fn_2b7104c
02d84ed0: ldr     x2, [x20]                                  MS:System.Collections.Generic.List`1::.ctor
02d84ed4: mov     x1, x19                                    
02d84ed8: mov     x3, xzr                                    
02d84edc: mov     x20, x0                                    
02d84ee0: bl      #0x4933768                                 fn_4933768
02d84ee4: ldr     x0, [x25]                                  MS:System.Collections.Generic.List`1::.ctor
02d84ee8: bl      #0x2b7104c                                 fn_2b7104c
02d84eec: ldr     x2, [x21]                                  MS:System.Collections.Generic.List`1::.ctor
02d84ef0: mov     x1, x19                                    
02d84ef4: mov     x3, xzr                                    
02d84ef8: mov     x21, x0                                    
02d84efc: bl      #0x453418c                                 fn_453418c
02d84f00: ldr     x0, [x25]                                  MS:System.Collections.Generic.List`1::.ctor
02d84f04: bl      #0x2b7104c                                 fn_2b7104c
02d84f08: ldr     x2, [x22]                                  MS:System.Collections.Generic.List`1::.ctor
02d84f0c: mov     x1, x19                                    
02d84f10: mov     x3, xzr                                    
02d84f14: mov     x22, x0                                    
02d84f18: bl      #0x453418c                                 fn_453418c
02d84f1c: ldr     x0, [x25]                                  MS:System.Collections.Generic.List`1::.ctor
02d84f20: bl      #0x2b7104c                                 fn_2b7104c
02d84f24: ldr     x2, [x23]                                  MS:System.Collections.Generic.List`1::.ctor
02d84f28: mov     x1, x19                                    
02d84f2c: mov     x3, xzr                                    
02d84f30: mov     x23, x0                                    
02d84f34: bl      #0x453418c                                 fn_453418c
02d84f38: ldr     x0, [x29]                                  MS:System.Collections.Generic.List`1::.ctor
02d84f3c: bl      #0x2b7104c                                 fn_2b7104c
02d84f40: ldr     x8, [x24]                                  MS:System.Collections.Generic.List`1::.ctor
02d84f44: mov     x1, x20                                    
02d84f48: mov     x2, x21                                    
02d84f4c: mov     x3, x22                                    
02d84f50: mov     x4, x23                                    
02d84f54: mov     w5, #1                                     
02d84f58: mov     w6, #0xa                                   
02d84f5c: mov     w7, #0x14                                  
02d84f60: mov     x24, x0                                    
02d84f64: str     x8, [sp]                                   
02d84f68: bl      #0x396d014                                 fn_396d014
02d84f6c: mov     x0, x19                                    
02d84f70: mov     x1, x24                                    
02d84f74: str     x24, [x0, #0x68]!                          ._musicChannelPool
02d84f78: bl      #0x2b70d54                                 fn_2b70d54
02d84f7c: adrp    x8, #0x626d000                             
02d84f80: ldr     x8, [x8, #0x180]                           T:type55349(k15)
02d84f84: ldr     x0, [x8]                                   MS:System.Collections.Generic.List`1::.ctor
02d84f88: bl      #0x2b7104c                                 fn_2b7104c
02d84f8c: adrp    x8, #0x626d000                             
02d84f90: mov     x1, x19                                    
02d84f94: mov     x3, xzr                                    
02d84f98: ldr     x8, [x8, #0x160]                           M:Framework.AudioManager::<Start>b__28_4
02d84f9c: mov     x20, x0                                    
02d84fa0: ldr     x2, [x8]                                   MS:System.Collections.Generic.List`1::.ctor
02d84fa4: bl      #0x4933768                                 fn_4933768
02d84fa8: ldr     x0, [x28]                                  MS:System.Collections.Generic.List`1::.ctor
02d84fac: bl      #0x2b7104c                                 fn_2b7104c
02d84fb0: adrp    x8, #0x626d000                             
02d84fb4: mov     x1, x19                                    
02d84fb8: mov     x3, xzr                                    
02d84fbc: ldr     x8, [x8, #0x168]                           M:Framework.AudioManager::<Start>b__28_5
02d84fc0: mov     x21, x0                                    
02d84fc4: ldr     x2, [x8]                                   MS:System.Collections.Generic.List`1::.ctor
02d84fc8: bl      #0x453418c                                 fn_453418c
02d84fcc: ldr     x0, [x28]                                  MS:System.Collections.Generic.List`1::.ctor
02d84fd0: bl      #0x2b7104c                                 fn_2b7104c
02d84fd4: adrp    x8, #0x626d000                             
02d84fd8: mov     x1, x19                                    
02d84fdc: mov     x3, xzr                                    
02d84fe0: ldr     x8, [x8, #0x170]                           M:Framework.AudioManager::<Start>b__28_6
02d84fe4: mov     x22, x0                                    
02d84fe8: ldr     x2, [x8]                                   MS:System.Collections.Generic.List`1::.ctor
02d84fec: bl      #0x453418c                                 fn_453418c
02d84ff0: ldr     x0, [x28]                                  MS:System.Collections.Generic.List`1::.ctor
02d84ff4: bl      #0x2b7104c                                 fn_2b7104c
02d84ff8: adrp    x8, #0x626d000                             
02d84ffc: mov     x1, x19                                    
02d85000: mov     x3, xzr                                    
02d85004: ldr     x8, [x8, #0x178]                           M:Framework.AudioManager::<Start>b__28_7
02d85008: mov     x23, x0                                    
02d8500c: ldr     x2, [x8]                                   MS:System.Collections.Generic.List`1::.ctor
02d85010: bl      #0x453418c                                 fn_453418c
02d85014: adrp    x8, #0x626d000                             
02d85018: ldr     x8, [x8, #0x190]                           T:type57113(k15)
02d8501c: ldr     x0, [x8]                                   MS:System.Collections.Generic.List`1::.ctor
02d85020: bl      #0x2b7104c                                 fn_2b7104c
02d85024: adrp    x8, #0x626d000                             
02d85028: mov     x1, x20                                    
02d8502c: mov     x2, x21                                    
02d85030: ldr     x8, [x8, #0x188]                           MS:UnityEngine.Pool.ObjectPool`1::.ctor
02d85034: mov     x3, x22                                    
02d85038: mov     x4, x23                                    
02d8503c: mov     w5, #1                                     
02d85040: mov     w6, #0xa                                   
02d85044: mov     w7, #0x14                                  
02d85048: ldr     x8, [x8]                                   MS:System.Collections.Generic.List`1::.ctor
02d8504c: mov     x24, x0                                    
02d85050: str     x8, [sp]                                   
02d85054: bl      #0x396d014                                 fn_396d014
02d85058: str     x24, [x19, #0x70]!                         ._soundChannelPool
02d8505c: mov     x0, x19                                    
02d85060: mov     x1, x24                                    
02d85064: ldp     x20, x19, [sp, #0x60]                      
02d85068: ldp     x22, x21, [sp, #0x50]                      
02d8506c: ldp     x24, x23, [sp, #0x40]                      
02d85070: ldp     x26, x25, [sp, #0x30]                      
02d85074: ldp     x28, x27, [sp, #0x20]                      
02d85078: ldp     x29, x30, [sp, #0x10]                      
02d8507c: add     sp, sp, #0x70                              
02d85080: b       #0x2b70d54                                 
## PlayMusic(Framework.EMusic musicKey, float volume) -> Framework.MusicChannel
---- Framework.AudioManager::PlayMusic 0x2d846d8
02d846d8: sub     sp, sp, #0x60                              
02d846dc: str     d8, [sp, #0x20]                            
02d846e0: str     x30, [sp, #0x28]                           
02d846e4: stp     x24, x23, [sp, #0x30]                      
02d846e8: stp     x22, x21, [sp, #0x40]                      
02d846ec: stp     x20, x19, [sp, #0x50]                      
02d846f0: fmov    s8, s0                                     
02d846f4: adrp    x23, #0x6630000                            
02d846f8: adrp    x24, #0x626d000                            
02d846fc: adrp    x22, #0x626d000                            
02d84700: adrp    x21, #0x6263000                            
02d84704: ldr     x24, [x24, #0xc8]                          T:Framework.EMusic
02d84708: ldrb    w8, [x23, #0x475]                          
02d8470c: ldr     x22, [x22, #0xd0]                          S:'=====dev check play music '
02d84710: ldr     x21, [x21, #0x928]                         T:UnityEngine.Debug
02d84714: mov     w19, w1                                    
02d84718: mov     x20, x0                                    
02d8471c: tbnz    w8, #0, #0x2d84758                         
02d84720: adrp    x0, #0x6263000                             
02d84724: ldr     x0, [x0, #0x928]                           T:UnityEngine.Debug
02d84728: bl      #0x2b70db0                                 fn_2b70db0
02d8472c: adrp    x0, #0x626d000                             
02d84730: ldr     x0, [x0, #0xc8]                            T:Framework.EMusic
02d84734: bl      #0x2b70db0                                 fn_2b70db0
02d84738: adrp    x0, #0x6263000                             
02d8473c: ldr     x0, [x0, #0x918]                           T:UnityEngine.Object
02d84740: bl      #0x2b70db0                                 fn_2b70db0
02d84744: adrp    x0, #0x626d000                             
02d84748: ldr     x0, [x0, #0xd0]                            S:'=====dev check play music '
02d8474c: bl      #0x2b70db0                                 fn_2b70db0
02d84750: mov     w8, #1                                     
02d84754: strb    w8, [x23, #0x475]                          
02d84758: ldr     x8, [x24]                                  MS:System.Collections.Generic.List`1::.ctor
02d8475c: mov     x9, #-1                                    
02d84760: add     x0, sp, #8                                 
02d84764: mov     x1, xzr                                    
02d84768: str     w19, [sp, #0x18]                           
02d8476c: stp     x8, x9, [sp, #8]                           
02d84770: bl      #0x4e47e48                                 System.Enum::ToString
02d84774: ldr     x8, [x22]                                  MS:System.Collections.Generic.List`1::.ctor
02d84778: mov     x1, x0                                     
02d8477c: mov     x2, xzr                                    
02d84780: mov     x0, x8                                     
02d84784: bl      #0x4c9c514                                 System.String::Concat
02d84788: ldr     x8, [x21]                                  &2c5bbd4(=a9bd7bfdd503233f)
02d8478c: mov     x21, x0                                    
02d84790: ldr     w9, [x8, #0xe4]                            
02d84794: cbnz    w9, #0x2d847a0                             
02d84798: mov     x0, x8                                     
02d8479c: bl      #0x2b70f30                                 fn_2b70f30
02d847a0: mov     x0, x21                                    
02d847a4: mov     x1, xzr                                    
02d847a8: bl      #0x5af21f4                                 UnityEngine.Debug::Log
02d847ac: bl      #0x2d8495c                                 Framework.AudioManager::get_IsMusicOn
02d847b0: mov     w8, w0                                     
02d847b4: mov     x0, xzr                                    
02d847b8: tbz     w8, #0, #0x2d84834                         
02d847bc: adrp    x21, #0x6263000                            
02d847c0: mov     x0, x20                                    
02d847c4: ldr     x21, [x21, #0x918]                         T:UnityEngine.Object
02d847c8: bl      #0x2d85084                                 Framework.AudioManager::StopAllMusic
02d847cc: mov     x0, x20                                    
02d847d0: bl      #0x2d85188                                 Framework.AudioManager::GetFreeMusicChannel
02d847d4: ldr     x8, [x21]                                  &2c5bbd4(=a9bd7bfdd503233f)
02d847d8: mov     x21, x0                                    
02d847dc: ldr     w9, [x8, #0xe4]                            
02d847e0: cbnz    w9, #0x2d847ec                             
02d847e4: mov     x0, x8                                     
02d847e8: bl      #0x2b70f30                                 fn_2b70f30
02d847ec: mov     x0, x21                                    
02d847f0: mov     x1, xzr                                    
02d847f4: mov     x2, xzr                                    
02d847f8: bl      #0x5b37d84                                 UnityEngine.Object::op_Equality
02d847fc: mov     w8, w0                                     
02d84800: mov     x0, xzr                                    
02d84804: tbnz    w8, #0, #0x2d84834                         
02d84808: mov     x0, x20                                    
02d8480c: mov     w1, w19                                    
02d84810: bl      #0x2d8530c                                 Framework.AudioManager::GetMusicAudioClip
02d84814: cbz     x21, #0x2d84850                            
02d84818: movi    d1, #0000000000000000                      
02d8481c: fmov    s0, s8                                     
02d84820: mov     x2, x0                                     
02d84824: mov     x0, x21                                    
02d84828: mov     w1, w19                                    
02d8482c: bl      #0x2d853e0                                 Framework.MusicChannel::Play
02d84830: mov     x0, x21                                    
02d84834: ldp     x20, x19, [sp, #0x50]                      
02d84838: ldr     x30, [sp, #0x28]                           
02d8483c: ldp     x22, x21, [sp, #0x40]                      
02d84840: ldr     d8, [sp, #0x20]                            
02d84844: ldp     x24, x23, [sp, #0x30]                      
02d84848: add     sp, sp, #0x60                              
02d8484c: ret                                                
02d84850: bl      #0x2b7105c                                 fn_2b7105c
## SetVolumeMusic(float volume) -> void
---- Framework.AudioManager::SetVolumeMusic 0x2d8545c
02d8545c: str     d8, [sp, #-0x40]!                          
02d85460: stp     x30, x23, [sp, #0x10]                      
02d85464: stp     x22, x21, [sp, #0x20]                      
02d85468: stp     x20, x19, [sp, #0x30]                      
02d8546c: fmov    s8, s0                                     
02d85470: adrp    x20, #0x6630000                            
02d85474: adrp    x22, #0x626d000                            
02d85478: ldrb    w8, [x20, #0x476]                          
02d8547c: ldr     x22, [x22, #0xa0]                          T:Framework.AudioManager/<>c
02d85480: mov     x19, x0                                    
02d85484: tbnz    w8, #0, #0x2d854c0                         
02d85488: adrp    x0, #0x626d000                             
02d8548c: ldr     x0, [x0, #0xb0]                            MS:System.Linq.Enumerable::FirstOrDefault
02d85490: bl      #0x2b70db0                                 fn_2b70db0
02d85494: adrp    x0, #0x626d000                             
02d85498: ldr     x0, [x0, #0xb8]                            T:type55599(k15)
02d8549c: bl      #0x2b70db0                                 fn_2b70db0
02d854a0: adrp    x0, #0x626d000                             
02d854a4: ldr     x0, [x0, #0x1d8]                           M:Framework.AudioManager/<>c::<SetVolumeMusic>b__30_0
02d854a8: bl      #0x2b70db0                                 fn_2b70db0
02d854ac: adrp    x0, #0x626d000                             
02d854b0: ldr     x0, [x0, #0xa0]                            T:Framework.AudioManager/<>c
02d854b4: bl      #0x2b70db0                                 fn_2b70db0
02d854b8: mov     w8, #1                                     
02d854bc: strb    w8, [x20, #0x476]                          
02d854c0: ldr     x0, [x22]                                  MS:System.Collections.Generic.List`1::.ctor
02d854c4: ldr     x19, [x19, #0x40]                          ._musicChannels
02d854c8: ldr     w8, [x0, #0xe4]                            [626d0e4]=0 f=0,0
02d854cc: cbnz    w8, #0x2d854d8                             
02d854d0: bl      #0x2b70f30                                 fn_2b70f30
02d854d4: ldr     x0, [x22]                                  MS:System.Collections.Generic.List`1::.ctor
02d854d8: ldr     x8, [x0, #0xb8]                            T:type55599(k15)
02d854dc: adrp    x23, #0x626d000                            
02d854e0: ldr     x20, [x8, #0x10]                           
02d854e4: ldr     x23, [x23, #0xb0]                          MS:System.Linq.Enumerable::FirstOrDefault
02d854e8: cbnz    x20, #0x2d85544                            
02d854ec: ldr     w9, [x0, #0xe4]                            [626d0e4]=0 f=0,0
02d854f0: cbnz    w9, #0x2d85500                             
02d854f4: bl      #0x2b70f30                                 fn_2b70f30
02d854f8: ldr     x8, [x22]                                  MS:System.Collections.Generic.List`1::.ctor
02d854fc: ldr     x8, [x8, #0xb8]                            
02d85500: adrp    x9, #0x626d000                             
02d85504: ldr     x9, [x9, #0xb8]                            T:type55599(k15)
02d85508: ldr     x21, [x8]                                  
02d8550c: ldr     x0, [x9]                                   MS:System.Collections.Generic.List`1::.ctor
02d85510: bl      #0x2b7104c                                 fn_2b7104c
02d85514: adrp    x8, #0x626d000                             
02d85518: mov     x1, x21                                    
02d8551c: mov     x3, xzr                                    
02d85520: ldr     x8, [x8, #0x1d8]                           M:Framework.AudioManager/<>c::<SetVolumeMusic>b__30_0
02d85524: mov     x20, x0                                    
02d85528: ldr     x2, [x8]                                   MS:System.Collections.Generic.List`1::.ctor
02d8552c: bl      #0x4940cf8                                 fn_4940cf8
02d85530: ldr     x8, [x22]                                  MS:System.Collections.Generic.List`1::.ctor
02d85534: mov     x1, x20                                    
02d85538: ldr     x0, [x8, #0xb8]                            T:type55599(k15)
02d8553c: str     x20, [x0, #0x10]!                          
02d85540: bl      #0x2b70d54                                 fn_2b70d54
02d85544: ldr     x2, [x23]                                  MS:System.Collections.Generic.List`1::.ctor
02d85548: mov     x0, x19                                    
02d8554c: mov     x1, x20                                    
02d85550: bl      #0x318c658                                 fn_318c658
02d85554: cbz     x0, #0x2d8557c                             
02d85558: ldr     x0, [x0, #0x28]                            T:type17144(k15) ._soundClipList
02d8555c: cbz     x0, #0x2d85590                             
02d85560: ldp     x20, x19, [sp, #0x30]                      
02d85564: fmov    s0, s8                                     
02d85568: ldp     x22, x21, [sp, #0x20]                      
02d8556c: mov     x1, xzr                                    
02d85570: ldp     x30, x23, [sp, #0x10]                      
02d85574: ldr     d8, [sp], #0x40                            
02d85578: b       #0x5adf65c                                 UnityEngine.AudioSource::set_volume
02d8557c: ldp     x20, x19, [sp, #0x30]                      
02d85580: ldp     x22, x21, [sp, #0x20]                      
02d85584: ldp     x30, x23, [sp, #0x10]                      
02d85588: ldr     d8, [sp], #0x40                            
02d8558c: ret                                                
02d85590: bl      #0x2b7105c                                 fn_2b7105c
## StopMusic(Framework.EMusic musicKey) -> void
---- Framework.AudioManager::StopMusic 0x2d84554
02d84554: stp     x30, x23, [sp, #-0x30]!                    
02d84558: stp     x22, x21, [sp, #0x10]                      
02d8455c: stp     x20, x19, [sp, #0x20]                      
02d84560: adrp    x21, #0x6630000                            
02d84564: adrp    x22, #0x626d000                            
02d84568: mov     w19, w1                                    
02d8456c: ldrb    w8, [x21, #0x477]                          
02d84570: ldr     x22, [x22, #0xa8]                          T:Framework.AudioManager/<>c__DisplayClass31_0
02d84574: mov     x20, x0                                    
02d84578: tbnz    w8, #0, #0x2d845b4                         
02d8457c: adrp    x0, #0x626d000                             
02d84580: ldr     x0, [x0, #0xb0]                            MS:System.Linq.Enumerable::FirstOrDefault
02d84584: bl      #0x2b70db0                                 fn_2b70db0
02d84588: adrp    x0, #0x626d000                             
02d8458c: ldr     x0, [x0, #0xb8]                            T:type55599(k15)
02d84590: bl      #0x2b70db0                                 fn_2b70db0
02d84594: adrp    x0, #0x626d000                             
02d84598: ldr     x0, [x0, #0xc0]                            M:Framework.AudioManager/<>c__DisplayClass31_0::<StopMusic>b__0
02d8459c: bl      #0x2b70db0                                 fn_2b70db0
02d845a0: adrp    x0, #0x626d000                             
02d845a4: ldr     x0, [x0, #0xa8]                            T:Framework.AudioManager/<>c__DisplayClass31_0
02d845a8: bl      #0x2b70db0                                 fn_2b70db0
02d845ac: mov     w8, #1                                     
02d845b0: strb    w8, [x21, #0x477]                          
02d845b4: ldr     x0, [x22]                                  MS:System.Collections.Generic.List`1::.ctor
02d845b8: bl      #0x2b7104c                                 fn_2b7104c
02d845bc: mov     x1, xzr                                    
02d845c0: mov     x21, x0                                    
02d845c4: bl      #0x4e53e9c                                 System.Object::.ctor
02d845c8: cbz     x21, #0x2d8463c                            
02d845cc: adrp    x8, #0x626d000                             
02d845d0: adrp    x22, #0x626d000                            
02d845d4: adrp    x23, #0x626d000                            
02d845d8: ldr     x8, [x8, #0xb8]                            T:type55599(k15)
02d845dc: ldr     x22, [x22, #0xc0]                          M:Framework.AudioManager/<>c__DisplayClass31_0::<StopMusic>b__0
02d845e0: ldr     x23, [x23, #0xb0]                          MS:System.Linq.Enumerable::FirstOrDefault
02d845e4: ldr     x20, [x20, #0x40]                          ._musicChannels
02d845e8: str     w19, [x21, #0x10]                          
02d845ec: ldr     x0, [x8]                                   MS:System.Collections.Generic.List`1::.ctor
02d845f0: bl      #0x2b7104c                                 fn_2b7104c
02d845f4: ldr     x2, [x22]                                  MS:System.Collections.Generic.List`1::.ctor
02d845f8: mov     x1, x21                                    
02d845fc: mov     x3, xzr                                    
02d84600: mov     x19, x0                                    
02d84604: bl      #0x4940cf8                                 fn_4940cf8
02d84608: ldr     x2, [x23]                                  MS:System.Collections.Generic.List`1::.ctor
02d8460c: mov     x0, x20                                    
02d84610: mov     x1, x19                                    
02d84614: bl      #0x318c658                                 fn_318c658
02d84618: cbz     x0, #0x2d8462c                             
02d8461c: ldp     x20, x19, [sp, #0x20]                      
02d84620: ldp     x22, x21, [sp, #0x10]                      
02d84624: ldp     x30, x23, [sp], #0x30                      
02d84628: b       #0x2d855b4                                 Framework.MusicChannel::Stop
02d8462c: ldp     x20, x19, [sp, #0x20]                      
02d84630: ldp     x22, x21, [sp, #0x10]                      
02d84634: ldp     x30, x23, [sp], #0x30                      
02d84638: ret                                                
02d8463c: bl      #0x2b7105c                                 fn_2b7105c
## IsMusicPlaying(Framework.EMusic musicKey) -> bool
---- Framework.AudioManager::IsMusicPlaying 0x2d855e4
02d855e4: stp     x30, x23, [sp, #-0x30]!                    
02d855e8: stp     x22, x21, [sp, #0x10]                      
02d855ec: stp     x20, x19, [sp, #0x20]                      
02d855f0: adrp    x21, #0x6630000                            
02d855f4: adrp    x22, #0x626d000                            
02d855f8: mov     w19, w1                                    
02d855fc: ldrb    w8, [x21, #0x478]                          
02d85600: ldr     x22, [x22, #0x1e0]                         T:Framework.AudioManager/<>c__DisplayClass32_0
02d85604: mov     x20, x0                                    
02d85608: tbnz    w8, #0, #0x2d85644                         
02d8560c: adrp    x0, #0x626d000                             
02d85610: ldr     x0, [x0, #0x1e8]                           MS:System.Linq.Enumerable::Any
02d85614: bl      #0x2b70db0                                 fn_2b70db0
02d85618: adrp    x0, #0x626d000                             
02d8561c: ldr     x0, [x0, #0xb8]                            T:type55599(k15)
02d85620: bl      #0x2b70db0                                 fn_2b70db0
02d85624: adrp    x0, #0x626d000                             
02d85628: ldr     x0, [x0, #0x1f0]                           M:Framework.AudioManager/<>c__DisplayClass32_0::<IsMusicPlaying>b__0
02d8562c: bl      #0x2b70db0                                 fn_2b70db0
02d85630: adrp    x0, #0x626d000                             
02d85634: ldr     x0, [x0, #0x1e0]                           T:Framework.AudioManager/<>c__DisplayClass32_0
02d85638: bl      #0x2b70db0                                 fn_2b70db0
02d8563c: mov     w8, #1                                     
02d85640: strb    w8, [x21, #0x478]                          
02d85644: ldr     x0, [x22]                                  MS:System.Collections.Generic.List`1::.ctor
02d85648: bl      #0x2b7104c                                 fn_2b7104c
02d8564c: mov     x1, xzr                                    
02d85650: mov     x21, x0                                    
02d85654: bl      #0x4e53e9c                                 System.Object::.ctor
02d85658: cbz     x21, #0x2d856b4                            
02d8565c: adrp    x8, #0x626d000                             
02d85660: adrp    x22, #0x626d000                            
02d85664: adrp    x23, #0x626d000                            
02d85668: ldr     x8, [x8, #0xb8]                            T:type55599(k15)
02d8566c: ldr     x22, [x22, #0x1f0]                         M:Framework.AudioManager/<>c__DisplayClass32_0::<IsMusicPlaying>b__0
02d85670: ldr     x23, [x23, #0x1e8]                         MS:System.Linq.Enumerable::Any
02d85674: ldr     x20, [x20, #0x40]                          ._musicChannels
02d85678: str     w19, [x21, #0x10]                          
02d8567c: ldr     x0, [x8]                                   MS:System.Collections.Generic.List`1::.ctor
02d85680: bl      #0x2b7104c                                 fn_2b7104c
02d85684: ldr     x2, [x22]                                  MS:System.Collections.Generic.List`1::.ctor
02d85688: mov     x1, x21                                    
02d8568c: mov     x3, xzr                                    
02d85690: mov     x19, x0                                    
02d85694: bl      #0x4940cf8                                 fn_4940cf8
02d85698: mov     x0, x20                                    
02d8569c: mov     x1, x19                                    
02d856a0: ldr     x2, [x23]                                  MS:System.Collections.Generic.List`1::.ctor
02d856a4: ldp     x20, x19, [sp, #0x20]                      
02d856a8: ldp     x22, x21, [sp, #0x10]                      
02d856ac: ldp     x30, x23, [sp], #0x30                      
02d856b0: b       #0x317c1e4                                 
02d856b4: bl      #0x2b7105c                                 fn_2b7105c
## StopAllMusic() -> void
---- Framework.AudioManager::StopAllMusic 0x2d85084
02d85084: str     x30, [sp, #-0x30]!                         
02d85088: stp     x22, x21, [sp, #0x10]                      
02d8508c: stp     x20, x19, [sp, #0x20]                      
02d85090: adrp    x20, #0x6630000                            
02d85094: adrp    x22, #0x626d000                            
02d85098: mov     x19, x0                                    
02d8509c: ldrb    w8, [x20, #0x479]                          
02d850a0: ldr     x22, [x22, #0xa0]                          T:Framework.AudioManager/<>c
02d850a4: tbnz    w8, #0, #0x2d850e0                         
02d850a8: adrp    x0, #0x626d000                             
02d850ac: ldr     x0, [x0, #0x130]                           T:type53145(k15)
02d850b0: bl      #0x2b70db0                                 fn_2b70db0
02d850b4: adrp    x0, #0x626d000                             
02d850b8: ldr     x0, [x0, #0x198]                           MS:System.Collections.Generic.List`1::ForEach
02d850bc: bl      #0x2b70db0                                 fn_2b70db0
02d850c0: adrp    x0, #0x626d000                             
02d850c4: ldr     x0, [x0, #0x1a0]                           M:Framework.AudioManager/<>c::<StopAllMusic>b__33_0
02d850c8: bl      #0x2b70db0                                 fn_2b70db0
02d850cc: adrp    x0, #0x626d000                             
02d850d0: ldr     x0, [x0, #0xa0]                            T:Framework.AudioManager/<>c
02d850d4: bl      #0x2b70db0                                 fn_2b70db0
02d850d8: mov     w8, #1                                     
02d850dc: strb    w8, [x20, #0x479]                          
02d850e0: ldr     x0, [x22]                                  MS:System.Collections.Generic.List`1::.ctor
02d850e4: ldr     x19, [x19, #0x40]                          ._musicChannels
02d850e8: ldr     w8, [x0, #0xe4]                            [626d0e4]=0 f=0,0
02d850ec: cbnz    w8, #0x2d850f8                             
02d850f0: bl      #0x2b70f30                                 fn_2b70f30
02d850f4: ldr     x0, [x22]                                  MS:System.Collections.Generic.List`1::.ctor
02d850f8: ldr     x8, [x0, #0xb8]                            T:type55599(k15)
02d850fc: ldr     x20, [x8, #0x18]                           
02d85100: cbnz    x20, #0x2d8515c                            
02d85104: ldr     w9, [x0, #0xe4]                            [626d0e4]=0 f=0,0
02d85108: cbnz    w9, #0x2d85118                             
02d8510c: bl      #0x2b70f30                                 fn_2b70f30
02d85110: ldr     x8, [x22]                                  MS:System.Collections.Generic.List`1::.ctor
02d85114: ldr     x8, [x8, #0xb8]                            
02d85118: adrp    x9, #0x626d000                             
02d8511c: ldr     x9, [x9, #0x130]                           T:type53145(k15)
02d85120: ldr     x21, [x8]                                  
02d85124: ldr     x0, [x9]                                   MS:System.Collections.Generic.List`1::.ctor
02d85128: bl      #0x2b7104c                                 fn_2b7104c
02d8512c: adrp    x8, #0x626d000                             
02d85130: mov     x1, x21                                    
02d85134: mov     x3, xzr                                    
02d85138: ldr     x8, [x8, #0x1a0]                           M:Framework.AudioManager/<>c::<StopAllMusic>b__33_0
02d8513c: mov     x20, x0                                    
02d85140: ldr     x2, [x8]                                   MS:System.Collections.Generic.List`1::.ctor
02d85144: bl      #0x453418c                                 fn_453418c
02d85148: ldr     x8, [x22]                                  MS:System.Collections.Generic.List`1::.ctor
02d8514c: mov     x1, x20                                    
02d85150: ldr     x0, [x8, #0xb8]                            T:type55599(k15)
02d85154: str     x20, [x0, #0x18]!                          
02d85158: bl      #0x2b70d54                                 fn_2b70d54
02d8515c: cbz     x19, #0x2d85184                            
02d85160: adrp    x8, #0x626d000                             
02d85164: mov     x0, x19                                    
02d85168: mov     x1, x20                                    
02d8516c: ldr     x8, [x8, #0x198]                           MS:System.Collections.Generic.List`1::ForEach
02d85170: ldp     x20, x19, [sp, #0x20]                      
02d85174: ldp     x22, x21, [sp, #0x10]                      
02d85178: ldr     x2, [x8]                                   MS:System.Collections.Generic.List`1::.ctor
02d8517c: ldr     x30, [sp], #0x30                           
02d85180: b       #0x35a9ce4                                 
02d85184: bl      #0x2b7105c                                 fn_2b7105c
## GetFreeMusicChannel() -> Framework.MusicChannel
---- Framework.AudioManager::GetFreeMusicChannel 0x2d85188
02d85188: stp     x30, x25, [sp, #-0x40]!                    
02d8518c: stp     x24, x23, [sp, #0x10]                      
02d85190: stp     x22, x21, [sp, #0x20]                      
02d85194: stp     x20, x19, [sp, #0x30]                      
02d85198: adrp    x20, #0x6630000                            
02d8519c: adrp    x23, #0x626d000                            
02d851a0: mov     x19, x0                                    
02d851a4: ldrb    w8, [x20, #0x47a]                          
02d851a8: ldr     x23, [x23, #0xa0]                          T:Framework.AudioManager/<>c
02d851ac: tbnz    w8, #0, #0x2d85200                         
02d851b0: adrp    x0, #0x626d000                             
02d851b4: ldr     x0, [x0, #0xb0]                            MS:System.Linq.Enumerable::FirstOrDefault
02d851b8: bl      #0x2b70db0                                 fn_2b70db0
02d851bc: adrp    x0, #0x626d000                             
02d851c0: ldr     x0, [x0, #0xb8]                            T:type55599(k15)
02d851c4: bl      #0x2b70db0                                 fn_2b70db0
02d851c8: adrp    x0, #0x626d000                             
02d851cc: ldr     x0, [x0, #0x1a8]                           MS:UnityEngine.Pool.ObjectPool`1::Get
02d851d0: bl      #0x2b70db0                                 fn_2b70db0
02d851d4: adrp    x0, #0x6263000                             
02d851d8: ldr     x0, [x0, #0x918]                           T:UnityEngine.Object
02d851dc: bl      #0x2b70db0                                 fn_2b70db0
02d851e0: adrp    x0, #0x626d000                             
02d851e4: ldr     x0, [x0, #0x1b0]                           M:Framework.AudioManager/<>c::<GetFreeMusicChannel>b__34_0
02d851e8: bl      #0x2b70db0                                 fn_2b70db0
02d851ec: adrp    x0, #0x626d000                             
02d851f0: ldr     x0, [x0, #0xa0]                            T:Framework.AudioManager/<>c
02d851f4: bl      #0x2b70db0                                 fn_2b70db0
02d851f8: mov     w8, #1                                     
02d851fc: strb    w8, [x20, #0x47a]                          
02d85200: ldr     x0, [x23]                                  MS:System.Collections.Generic.List`1::.ctor
02d85204: ldr     x20, [x19, #0x40]                          ._musicChannels
02d85208: ldr     w8, [x0, #0xe4]                            [626d0e4]=0 f=0,0
02d8520c: cbnz    w8, #0x2d85218                             
02d85210: bl      #0x2b70f30                                 fn_2b70f30
02d85214: ldr     x0, [x23]                                  MS:System.Collections.Generic.List`1::.ctor
02d85218: ldr     x8, [x0, #0xb8]                            T:type55599(k15)
02d8521c: adrp    x25, #0x626d000                            
02d85220: adrp    x24, #0x6263000                            
02d85224: ldr     x25, [x25, #0xb0]                          MS:System.Linq.Enumerable::FirstOrDefault
02d85228: ldr     x21, [x8, #0x20]                           
02d8522c: ldr     x24, [x24, #0x918]                         T:UnityEngine.Object
02d85230: cbnz    x21, #0x2d8528c                            
02d85234: ldr     w9, [x0, #0xe4]                            [626d0e4]=0 f=0,0
02d85238: cbnz    w9, #0x2d85248                             
02d8523c: bl      #0x2b70f30                                 fn_2b70f30
02d85240: ldr     x8, [x23]                                  MS:System.Collections.Generic.List`1::.ctor
02d85244: ldr     x8, [x8, #0xb8]                            
02d85248: adrp    x9, #0x626d000                             
02d8524c: ldr     x9, [x9, #0xb8]                            T:type55599(k15)
02d85250: ldr     x22, [x8]                                  
02d85254: ldr     x0, [x9]                                   MS:System.Collections.Generic.List`1::.ctor
02d85258: bl      #0x2b7104c                                 fn_2b7104c
02d8525c: adrp    x8, #0x626d000                             
02d85260: mov     x1, x22                                    
02d85264: mov     x3, xzr                                    
02d85268: ldr     x8, [x8, #0x1b0]                           M:Framework.AudioManager/<>c::<GetFreeMusicChannel>b__34_0
02d8526c: mov     x21, x0                                    
02d85270: ldr     x2, [x8]                                   MS:System.Collections.Generic.List`1::.ctor
02d85274: bl      #0x4940cf8                                 fn_4940cf8
02d85278: ldr     x8, [x23]                                  MS:System.Collections.Generic.List`1::.ctor
02d8527c: mov     x1, x21                                    
02d85280: ldr     x0, [x8, #0xb8]                            T:type55599(k15)
02d85284: str     x21, [x0, #0x20]!                          ._musicClipList
02d85288: bl      #0x2b70d54                                 fn_2b70d54
02d8528c: ldr     x2, [x25]                                  MS:System.Collections.Generic.List`1::.ctor
02d85290: mov     x0, x20                                    
02d85294: mov     x1, x21                                    
02d85298: bl      #0x318c658                                 fn_318c658
02d8529c: ldr     x8, [x24]                                  &2c5bbd4(=a9bd7bfdd503233f)
02d852a0: mov     x20, x0                                    
02d852a4: ldr     w9, [x8, #0xe4]                            [626d0e4]=0 f=0,0
02d852a8: cbnz    w9, #0x2d852b4                             
02d852ac: mov     x0, x8                                     
02d852b0: bl      #0x2b70f30                                 fn_2b70f30
02d852b4: mov     x0, x20                                    
02d852b8: mov     x1, xzr                                    
02d852bc: mov     x2, xzr                                    
02d852c0: bl      #0x5b37d84                                 UnityEngine.Object::op_Equality
02d852c4: tbz     w0, #0, #0x2d852f0                         
02d852c8: ldr     x0, [x19, #0x68]                           ._musicChannelPool
02d852cc: cbz     x0, #0x2d85308                             
02d852d0: adrp    x8, #0x626d000                             
02d852d4: ldr     x8, [x8, #0x1a8]                           MS:UnityEngine.Pool.ObjectPool`1::Get
02d852d8: ldp     x20, x19, [sp, #0x30]                      
02d852dc: ldp     x22, x21, [sp, #0x20]                      
02d852e0: ldp     x24, x23, [sp, #0x10]                      
02d852e4: ldr     x1, [x8]                                   MS:System.Collections.Generic.List`1::.ctor
02d852e8: ldp     x30, x25, [sp], #0x40                      
02d852ec: b       #0x2d89a4c                                 
02d852f0: mov     x0, x20                                    
02d852f4: ldp     x20, x19, [sp, #0x30]                      
02d852f8: ldp     x22, x21, [sp, #0x20]                      
02d852fc: ldp     x24, x23, [sp, #0x10]                      
02d85300: ldp     x30, x25, [sp], #0x40                      
02d85304: ret                                                
02d85308: bl      #0x2b7105c                                 fn_2b7105c
## GetMusicAudioClip(Framework.EMusic musicKey) -> UnityEngine.AudioClip
---- Framework.AudioManager::GetMusicAudioClip 0x2d8530c
02d8530c: stp     x30, x23, [sp, #-0x30]!                    
02d85310: stp     x22, x21, [sp, #0x10]                      
02d85314: stp     x20, x19, [sp, #0x20]                      
02d85318: adrp    x21, #0x6630000                            
02d8531c: adrp    x22, #0x626d000                            
02d85320: mov     w19, w1                                    
02d85324: ldrb    w8, [x21, #0x47b]                          
02d85328: ldr     x22, [x22, #0x1b8]                         T:Framework.AudioManager/<>c__DisplayClass35_0
02d8532c: mov     x20, x0                                    
02d85330: tbnz    w8, #0, #0x2d8536c                         
02d85334: adrp    x0, #0x626d000                             
02d85338: ldr     x0, [x0, #0x1c0]                           MS:System.Linq.Enumerable::FirstOrDefault
02d8533c: bl      #0x2b70db0                                 fn_2b70db0
02d85340: adrp    x0, #0x626d000                             
02d85344: ldr     x0, [x0, #0x1c8]                           T:type55501(k15)
02d85348: bl      #0x2b70db0                                 fn_2b70db0
02d8534c: adrp    x0, #0x626d000                             
02d85350: ldr     x0, [x0, #0x1d0]                           M:Framework.AudioManager/<>c__DisplayClass35_0::<GetMusicAudioClip>b__0
02d85354: bl      #0x2b70db0                                 fn_2b70db0
02d85358: adrp    x0, #0x626d000                             
02d8535c: ldr     x0, [x0, #0x1b8]                           T:Framework.AudioManager/<>c__DisplayClass35_0
02d85360: bl      #0x2b70db0                                 fn_2b70db0
02d85364: mov     w8, #1                                     
02d85368: strb    w8, [x21, #0x47b]                          
02d8536c: ldr     x0, [x22]                                  MS:System.Collections.Generic.List`1::.ctor
02d85370: bl      #0x2b7104c                                 fn_2b7104c
02d85374: mov     x1, xzr                                    
02d85378: mov     x21, x0                                    
02d8537c: bl      #0x4e53e9c                                 System.Object::.ctor
02d85380: cbz     x21, #0x2d853dc                            
02d85384: adrp    x8, #0x626d000                             
02d85388: adrp    x22, #0x626d000                            
02d8538c: adrp    x23, #0x626d000                            
02d85390: ldr     x8, [x8, #0x1c8]                           T:type55501(k15)
02d85394: ldr     x22, [x22, #0x1d0]                         M:Framework.AudioManager/<>c__DisplayClass35_0::<GetMusicAudioClip>b__0
02d85398: ldr     x23, [x23, #0x1c0]                         MS:System.Linq.Enumerable::FirstOrDefault
02d8539c: ldr     x20, [x20, #0x20]                          ._musicClipList
02d853a0: str     w19, [x21, #0x10]                          
02d853a4: ldr     x0, [x8]                                   MS:System.Collections.Generic.List`1::.ctor
02d853a8: bl      #0x2b7104c                                 fn_2b7104c
02d853ac: ldr     x2, [x22]                                  MS:System.Collections.Generic.List`1::.ctor
02d853b0: mov     x1, x21                                    
02d853b4: mov     x3, xzr                                    
02d853b8: mov     x19, x0                                    
02d853bc: bl      #0x4940cf8                                 fn_4940cf8
02d853c0: mov     x0, x20                                    
02d853c4: mov     x1, x19                                    
02d853c8: ldr     x2, [x23]                                  MS:System.Collections.Generic.List`1::.ctor
02d853cc: ldp     x20, x19, [sp, #0x20]                      
02d853d0: ldp     x22, x21, [sp, #0x10]                      
02d853d4: ldp     x30, x23, [sp], #0x30                      
02d853d8: b       #0x318c658                                 
02d853dc: bl      #0x2b7105c                                 fn_2b7105c
## PlaySound(Framework.ESound soundKey, float volume, float delay, bool isLoop, bool isSetTimeStop, float timeStop) -> Framework.SoundChannel
---- Framework.AudioManager::PlaySound 0x2d6f03c
02d6f03c: str     d10, [sp, #-0x50]!                         
02d6f040: stp     d9, d8, [sp, #0x10]                        
02d6f044: stp     x30, x23, [sp, #0x20]                      
02d6f048: stp     x22, x21, [sp, #0x30]                      
02d6f04c: stp     x20, x19, [sp, #0x40]                      
02d6f050: fmov    s10, s2                                    
02d6f054: fmov    s8, s1                                     
02d6f058: adrp    x22, #0x6630000                            
02d6f05c: fmov    s9, s0                                     
02d6f060: ldrb    w8, [x22, #0x47c]                          
02d6f064: mov     w20, w3                                    
02d6f068: mov     w21, w2                                    
02d6f06c: mov     w19, w1                                    
02d6f070: mov     x23, x0                                    
02d6f074: tbnz    w8, #0, #0x2d6f08c                         
02d6f078: adrp    x0, #0x6263000                             
02d6f07c: ldr     x0, [x0, #0x918]                           T:UnityEngine.Object
02d6f080: bl      #0x2b70db0                                 fn_2b70db0
02d6f084: mov     w8, #1                                     
02d6f088: strb    w8, [x22, #0x47c]                          
02d6f08c: bl      #0x2d849cc                                 Framework.AudioManager::get_IsSoundOn
02d6f090: tbz     w0, #0, #0x2d6f110                         
02d6f094: adrp    x22, #0x6263000                            
02d6f098: mov     x0, x23                                    
02d6f09c: ldr     x22, [x22, #0x918]                         T:UnityEngine.Object
02d6f0a0: bl      #0x2d856c8                                 Framework.AudioManager::GetFreeSoundChannel
02d6f0a4: ldr     x8, [x22]                                  &2c5bbd4(=a9bd7bfdd503233f)
02d6f0a8: mov     x22, x0                                    
02d6f0ac: ldr     w9, [x8, #0xe4]                            
02d6f0b0: cbnz    w9, #0x2d6f0bc                             
02d6f0b4: mov     x0, x8                                     
02d6f0b8: bl      #0x2b70f30                                 fn_2b70f30
02d6f0bc: mov     x0, x22                                    
02d6f0c0: mov     x1, xzr                                    
02d6f0c4: mov     x2, xzr                                    
02d6f0c8: bl      #0x5b37d84                                 UnityEngine.Object::op_Equality
02d6f0cc: mov     w8, w0                                     
02d6f0d0: mov     x0, xzr                                    
02d6f0d4: tbnz    w8, #0, #0x2d6f134                         
02d6f0d8: mov     x0, x23                                    
02d6f0dc: mov     w1, w19                                    
02d6f0e0: bl      #0x2d8584c                                 Framework.AudioManager::GetSoundAudioClip
02d6f0e4: mov     x2, x0                                     
02d6f0e8: tbz     w21, #0, #0x2d6f118                        
02d6f0ec: cbz     x22, #0x2d6f14c                            
02d6f0f0: fmov    s0, s9                                     
02d6f0f4: fmov    s1, s8                                     
02d6f0f8: and     w3, w20, #1                                
02d6f0fc: fmov    s2, s10                                    
02d6f100: mov     x0, x22                                    
02d6f104: mov     w1, w19                                    
02d6f108: bl      #0x2d85920                                 Framework.SoundChannel::PlayLoop
02d6f10c: b       #0x2d6f130                                 
02d6f110: mov     x0, xzr                                    
02d6f114: b       #0x2d6f134                                 
02d6f118: cbz     x22, #0x2d6f14c                            
02d6f11c: fmov    s0, s9                                     
02d6f120: fmov    s1, s8                                     
02d6f124: mov     x0, x22                                    
02d6f128: mov     w1, w19                                    
02d6f12c: bl      #0x2d859e8                                 Framework.SoundChannel::Play
02d6f130: mov     x0, x22                                    
02d6f134: ldp     x20, x19, [sp, #0x40]                      
02d6f138: ldp     x22, x21, [sp, #0x30]                      
02d6f13c: ldp     x30, x23, [sp, #0x20]                      
02d6f140: ldp     d9, d8, [sp, #0x10]                        
02d6f144: ldr     d10, [sp], #0x50                           
02d6f148: ret                                                
02d6f14c: bl      #0x2b7105c                                 fn_2b7105c
## GetFreeSoundChannel() -> Framework.SoundChannel
---- Framework.AudioManager::GetFreeSoundChannel 0x2d856c8
02d856c8: stp     x30, x25, [sp, #-0x40]!                    
02d856cc: stp     x24, x23, [sp, #0x10]                      
02d856d0: stp     x22, x21, [sp, #0x20]                      
02d856d4: stp     x20, x19, [sp, #0x30]                      
02d856d8: adrp    x20, #0x6630000                            
02d856dc: adrp    x23, #0x626d000                            
02d856e0: mov     x19, x0                                    
02d856e4: ldrb    w8, [x20, #0x47d]                          
02d856e8: ldr     x23, [x23, #0xa0]                          T:Framework.AudioManager/<>c
02d856ec: tbnz    w8, #0, #0x2d85740                         
02d856f0: adrp    x0, #0x626d000                             
02d856f4: ldr     x0, [x0, #0x1f8]                           MS:System.Linq.Enumerable::FirstOrDefault
02d856f8: bl      #0x2b70db0                                 fn_2b70db0
02d856fc: adrp    x0, #0x626d000                             
02d85700: ldr     x0, [x0, #0x58]                            T:type55641(k15) ._soundClipDic
02d85704: bl      #0x2b70db0                                 fn_2b70db0
02d85708: adrp    x0, #0x626d000                             
02d8570c: ldr     x0, [x0, #0x200]                           MS:UnityEngine.Pool.ObjectPool`1::Get
02d85710: bl      #0x2b70db0                                 fn_2b70db0
02d85714: adrp    x0, #0x6263000                             
02d85718: ldr     x0, [x0, #0x918]                           T:UnityEngine.Object
02d8571c: bl      #0x2b70db0                                 fn_2b70db0
02d85720: adrp    x0, #0x626d000                             
02d85724: ldr     x0, [x0, #0x208]                           M:Framework.AudioManager/<>c::<GetFreeSoundChannel>b__37_0
02d85728: bl      #0x2b70db0                                 fn_2b70db0
02d8572c: adrp    x0, #0x626d000                             
02d85730: ldr     x0, [x0, #0xa0]                            T:Framework.AudioManager/<>c
02d85734: bl      #0x2b70db0                                 fn_2b70db0
02d85738: mov     w8, #1                                     
02d8573c: strb    w8, [x20, #0x47d]                          
02d85740: ldr     x0, [x23]                                  MS:System.Collections.Generic.List`1::.ctor
02d85744: ldr     x20, [x19, #0x48]                          ._soundChannels
02d85748: ldr     w8, [x0, #0xe4]                            [626d0e4]=0 f=0,0
02d8574c: cbnz    w8, #0x2d85758                             
02d85750: bl      #0x2b70f30                                 fn_2b70f30
02d85754: ldr     x0, [x23]                                  MS:System.Collections.Generic.List`1::.ctor
02d85758: ldr     x8, [x0, #0xb8]                            T:type55599(k15)
02d8575c: adrp    x25, #0x626d000                            
02d85760: adrp    x24, #0x6263000                            
02d85764: ldr     x25, [x25, #0x1f8]                         MS:System.Linq.Enumerable::FirstOrDefault
02d85768: ldr     x21, [x8, #0x28]                           
02d8576c: ldr     x24, [x24, #0x918]                         T:UnityEngine.Object
02d85770: cbnz    x21, #0x2d857cc                            
02d85774: ldr     w9, [x0, #0xe4]                            [626d0e4]=0 f=0,0
02d85778: cbnz    w9, #0x2d85788                             
02d8577c: bl      #0x2b70f30                                 fn_2b70f30
02d85780: ldr     x8, [x23]                                  MS:System.Collections.Generic.List`1::.ctor
02d85784: ldr     x8, [x8, #0xb8]                            
02d85788: adrp    x9, #0x626d000                             
02d8578c: ldr     x9, [x9, #0x58]                            T:type55641(k15)
02d85790: ldr     x22, [x8]                                  
02d85794: ldr     x0, [x9]                                   MS:System.Collections.Generic.List`1::.ctor
02d85798: bl      #0x2b7104c                                 fn_2b7104c
02d8579c: adrp    x8, #0x626d000                             
02d857a0: mov     x1, x22                                    
02d857a4: mov     x3, xzr                                    
02d857a8: ldr     x8, [x8, #0x208]                           M:Framework.AudioManager/<>c::<GetFreeSoundChannel>b__37_0
02d857ac: mov     x21, x0                                    
02d857b0: ldr     x2, [x8]                                   MS:System.Collections.Generic.List`1::.ctor
02d857b4: bl      #0x4940cf8                                 fn_4940cf8
02d857b8: ldr     x8, [x23]                                  MS:System.Collections.Generic.List`1::.ctor
02d857bc: mov     x1, x21                                    
02d857c0: ldr     x0, [x8, #0xb8]                            T:type55599(k15)
02d857c4: str     x21, [x0, #0x28]!                          ._soundClipList
02d857c8: bl      #0x2b70d54                                 fn_2b70d54
02d857cc: ldr     x2, [x25]                                  MS:System.Collections.Generic.List`1::.ctor
02d857d0: mov     x0, x20                                    
02d857d4: mov     x1, x21                                    
02d857d8: bl      #0x318c658                                 fn_318c658
02d857dc: ldr     x8, [x24]                                  &2c5bbd4(=a9bd7bfdd503233f)
02d857e0: mov     x20, x0                                    
02d857e4: ldr     w9, [x8, #0xe4]                            [626d0e4]=0 f=0,0
02d857e8: cbnz    w9, #0x2d857f4                             
02d857ec: mov     x0, x8                                     
02d857f0: bl      #0x2b70f30                                 fn_2b70f30
02d857f4: mov     x0, x20                                    
02d857f8: mov     x1, xzr                                    
02d857fc: mov     x2, xzr                                    
02d85800: bl      #0x5b37d84                                 UnityEngine.Object::op_Equality
02d85804: tbz     w0, #0, #0x2d85830                         
02d85808: ldr     x0, [x19, #0x70]                           ._soundChannelPool
02d8580c: cbz     x0, #0x2d85848                             
02d85810: adrp    x8, #0x626d000                             
02d85814: ldr     x8, [x8, #0x200]                           MS:UnityEngine.Pool.ObjectPool`1::Get
02d85818: ldp     x20, x19, [sp, #0x30]                      
02d8581c: ldp     x22, x21, [sp, #0x20]                      
02d85820: ldp     x24, x23, [sp, #0x10]                      
02d85824: ldr     x1, [x8]                                   MS:System.Collections.Generic.List`1::.ctor
02d85828: ldp     x30, x25, [sp], #0x40                      
02d8582c: b       #0x2d89a4c                                 
02d85830: mov     x0, x20                                    
02d85834: ldp     x20, x19, [sp, #0x30]                      
02d85838: ldp     x22, x21, [sp, #0x20]                      
02d8583c: ldp     x24, x23, [sp, #0x10]                      
02d85840: ldp     x30, x25, [sp], #0x40                      
02d85844: ret                                                
02d85848: bl      #0x2b7105c                                 fn_2b7105c
## IsSoundPlaying(Framework.ESound soundKey) -> bool
---- Framework.AudioManager::IsSoundPlaying 0x2d84190
02d84190: stp     x30, x23, [sp, #-0x30]!                    
02d84194: stp     x22, x21, [sp, #0x10]                      
02d84198: stp     x20, x19, [sp, #0x20]                      
02d8419c: adrp    x21, #0x6630000                            
02d841a0: adrp    x22, #0x626d000                            
02d841a4: mov     w19, w1                                    
02d841a8: ldrb    w8, [x21, #0x47e]                          
02d841ac: ldr     x22, [x22, #0x48]                          T:Framework.AudioManager/<>c__DisplayClass38_0
02d841b0: mov     x20, x0                                    
02d841b4: tbnz    w8, #0, #0x2d841f0                         
02d841b8: adrp    x0, #0x626d000                             
02d841bc: ldr     x0, [x0, #0x50]                            MS:System.Linq.Enumerable::Any ._bgmClipDic
02d841c0: bl      #0x2b70db0                                 fn_2b70db0
02d841c4: adrp    x0, #0x626d000                             
02d841c8: ldr     x0, [x0, #0x58]                            T:type55641(k15) ._soundClipDic
02d841cc: bl      #0x2b70db0                                 fn_2b70db0
02d841d0: adrp    x0, #0x626d000                             
02d841d4: ldr     x0, [x0, #0x60]                            M:Framework.AudioManager/<>c__DisplayClass38_0::<IsSoundPlaying>b__0 ._isMuteMusic
02d841d8: bl      #0x2b70db0                                 fn_2b70db0
02d841dc: adrp    x0, #0x626d000                             
02d841e0: ldr     x0, [x0, #0x48]                            T:Framework.AudioManager/<>c__DisplayClass38_0 ._soundChannels
02d841e4: bl      #0x2b70db0                                 fn_2b70db0
02d841e8: mov     w8, #1                                     
02d841ec: strb    w8, [x21, #0x47e]                          
02d841f0: ldr     x0, [x22]                                  MS:System.Collections.Generic.List`1::.ctor
02d841f4: bl      #0x2b7104c                                 fn_2b7104c
02d841f8: mov     x1, xzr                                    
02d841fc: mov     x21, x0                                    
02d84200: bl      #0x4e53e9c                                 System.Object::.ctor
02d84204: cbz     x21, #0x2d84260                            
02d84208: adrp    x8, #0x626d000                             
02d8420c: adrp    x22, #0x626d000                            
02d84210: adrp    x23, #0x626d000                            
02d84214: ldr     x8, [x8, #0x58]                            T:type55641(k15)
02d84218: ldr     x22, [x22, #0x60]                          M:Framework.AudioManager/<>c__DisplayClass38_0::<IsSoundPlaying>b__0
02d8421c: ldr     x23, [x23, #0x50]                          MS:System.Linq.Enumerable::Any
02d84220: ldr     x20, [x20, #0x48]                          ._soundChannels
02d84224: str     w19, [x21, #0x10]                          
02d84228: ldr     x0, [x8]                                   MS:System.Collections.Generic.List`1::.ctor
02d8422c: bl      #0x2b7104c                                 fn_2b7104c
02d84230: ldr     x2, [x22]                                  MS:System.Collections.Generic.List`1::.ctor
02d84234: mov     x1, x21                                    
02d84238: mov     x3, xzr                                    
02d8423c: mov     x19, x0                                    
02d84240: bl      #0x4940cf8                                 fn_4940cf8
02d84244: mov     x0, x20                                    
02d84248: mov     x1, x19                                    
02d8424c: ldr     x2, [x23]                                  MS:System.Collections.Generic.List`1::.ctor
02d84250: ldp     x20, x19, [sp, #0x20]                      
02d84254: ldp     x22, x21, [sp, #0x10]                      
02d84258: ldp     x30, x23, [sp], #0x30                      
02d8425c: b       #0x317c1e4                                 
02d84260: bl      #0x2b7105c                                 fn_2b7105c
## IsSoundPaused(Framework.ESound soundKey) -> bool
---- Framework.AudioManager::IsSoundPaused 0x2d85a84
02d85a84: stp     x30, x23, [sp, #-0x30]!                    
02d85a88: stp     x22, x21, [sp, #0x10]                      
02d85a8c: stp     x20, x19, [sp, #0x20]                      
02d85a90: adrp    x21, #0x6630000                            
02d85a94: adrp    x22, #0x626d000                            
02d85a98: mov     w19, w1                                    
02d85a9c: ldrb    w8, [x21, #0x47f]                          
02d85aa0: ldr     x22, [x22, #0x220]                         T:Framework.AudioManager/<>c__DisplayClass39_0
02d85aa4: mov     x20, x0                                    
02d85aa8: tbnz    w8, #0, #0x2d85ae4                         
02d85aac: adrp    x0, #0x626d000                             
02d85ab0: ldr     x0, [x0, #0x50]                            MS:System.Linq.Enumerable::Any ._bgmClipDic
02d85ab4: bl      #0x2b70db0                                 fn_2b70db0
02d85ab8: adrp    x0, #0x626d000                             
02d85abc: ldr     x0, [x0, #0x58]                            T:type55641(k15) ._soundClipDic
02d85ac0: bl      #0x2b70db0                                 fn_2b70db0
02d85ac4: adrp    x0, #0x626d000                             
02d85ac8: ldr     x0, [x0, #0x228]                           M:Framework.AudioManager/<>c__DisplayClass39_0::<IsSoundPaused>b__0
02d85acc: bl      #0x2b70db0                                 fn_2b70db0
02d85ad0: adrp    x0, #0x626d000                             
02d85ad4: ldr     x0, [x0, #0x220]                           T:Framework.AudioManager/<>c__DisplayClass39_0
02d85ad8: bl      #0x2b70db0                                 fn_2b70db0
02d85adc: mov     w8, #1                                     
02d85ae0: strb    w8, [x21, #0x47f]                          
02d85ae4: ldr     x0, [x22]                                  MS:System.Collections.Generic.List`1::.ctor
02d85ae8: bl      #0x2b7104c                                 fn_2b7104c
02d85aec: mov     x1, xzr                                    
02d85af0: mov     x21, x0                                    
02d85af4: bl      #0x4e53e9c                                 System.Object::.ctor
02d85af8: cbz     x21, #0x2d85b54                            
02d85afc: adrp    x8, #0x626d000                             
02d85b00: adrp    x22, #0x626d000                            
02d85b04: adrp    x23, #0x626d000                            
02d85b08: ldr     x8, [x8, #0x58]                            T:type55641(k15)
02d85b0c: ldr     x22, [x22, #0x228]                         M:Framework.AudioManager/<>c__DisplayClass39_0::<IsSoundPaused>b__0
02d85b10: ldr     x23, [x23, #0x50]                          MS:System.Linq.Enumerable::Any
02d85b14: ldr     x20, [x20, #0x48]                          ._soundChannels
02d85b18: str     w19, [x21, #0x10]                          
02d85b1c: ldr     x0, [x8]                                   MS:System.Collections.Generic.List`1::.ctor
02d85b20: bl      #0x2b7104c                                 fn_2b7104c
02d85b24: ldr     x2, [x22]                                  MS:System.Collections.Generic.List`1::.ctor
02d85b28: mov     x1, x21                                    
02d85b2c: mov     x3, xzr                                    
02d85b30: mov     x19, x0                                    
02d85b34: bl      #0x4940cf8                                 fn_4940cf8
02d85b38: mov     x0, x20                                    
02d85b3c: mov     x1, x19                                    
02d85b40: ldr     x2, [x23]                                  MS:System.Collections.Generic.List`1::.ctor
02d85b44: ldp     x20, x19, [sp, #0x20]                      
02d85b48: ldp     x22, x21, [sp, #0x10]                      
02d85b4c: ldp     x30, x23, [sp], #0x30                      
02d85b50: b       #0x317c1e4                                 
02d85b54: bl      #0x2b7105c                                 fn_2b7105c
## GetSoundAudioClip(Framework.ESound soundKey) -> UnityEngine.AudioClip
---- Framework.AudioManager::GetSoundAudioClip 0x2d8584c
02d8584c: stp     x30, x23, [sp, #-0x30]!                    
02d85850: stp     x22, x21, [sp, #0x10]                      
02d85854: stp     x20, x19, [sp, #0x20]                      
02d85858: adrp    x21, #0x6630000                            
02d8585c: adrp    x22, #0x626d000                            
02d85860: mov     w19, w1                                    
02d85864: ldrb    w8, [x21, #0x480]                          
02d85868: ldr     x22, [x22, #0x210]                         T:Framework.AudioManager/<>c__DisplayClass40_0
02d8586c: mov     x20, x0                                    
02d85870: tbnz    w8, #0, #0x2d858ac                         
02d85874: adrp    x0, #0x626d000                             
02d85878: ldr     x0, [x0, #0x1c0]                           MS:System.Linq.Enumerable::FirstOrDefault
02d8587c: bl      #0x2b70db0                                 fn_2b70db0
02d85880: adrp    x0, #0x626d000                             
02d85884: ldr     x0, [x0, #0x1c8]                           T:type55501(k15)
02d85888: bl      #0x2b70db0                                 fn_2b70db0
02d8588c: adrp    x0, #0x626d000                             
02d85890: ldr     x0, [x0, #0x218]                           M:Framework.AudioManager/<>c__DisplayClass40_0::<GetSoundAudioClip>b__0
02d85894: bl      #0x2b70db0                                 fn_2b70db0
02d85898: adrp    x0, #0x626d000                             
02d8589c: ldr     x0, [x0, #0x210]                           T:Framework.AudioManager/<>c__DisplayClass40_0
02d858a0: bl      #0x2b70db0                                 fn_2b70db0
02d858a4: mov     w8, #1                                     
02d858a8: strb    w8, [x21, #0x480]                          
02d858ac: ldr     x0, [x22]                                  MS:System.Collections.Generic.List`1::.ctor
02d858b0: bl      #0x2b7104c                                 fn_2b7104c
02d858b4: mov     x1, xzr                                    
02d858b8: mov     x21, x0                                    
02d858bc: bl      #0x4e53e9c                                 System.Object::.ctor
02d858c0: cbz     x21, #0x2d8591c                            
02d858c4: adrp    x8, #0x626d000                             
02d858c8: adrp    x22, #0x626d000                            
02d858cc: adrp    x23, #0x626d000                            
02d858d0: ldr     x8, [x8, #0x1c8]                           T:type55501(k15)
02d858d4: ldr     x22, [x22, #0x218]                         M:Framework.AudioManager/<>c__DisplayClass40_0::<GetSoundAudioClip>b__0
02d858d8: ldr     x23, [x23, #0x1c0]                         MS:System.Linq.Enumerable::FirstOrDefault
02d858dc: ldr     x20, [x20, #0x28]                          ._soundClipList
02d858e0: str     w19, [x21, #0x10]                          
02d858e4: ldr     x0, [x8]                                   MS:System.Collections.Generic.List`1::.ctor
02d858e8: bl      #0x2b7104c                                 fn_2b7104c
02d858ec: ldr     x2, [x22]                                  MS:System.Collections.Generic.List`1::.ctor
02d858f0: mov     x1, x21                                    
02d858f4: mov     x3, xzr                                    
02d858f8: mov     x19, x0                                    
02d858fc: bl      #0x4940cf8                                 fn_4940cf8
02d85900: mov     x0, x20                                    
02d85904: mov     x1, x19                                    
02d85908: ldr     x2, [x23]                                  MS:System.Collections.Generic.List`1::.ctor
02d8590c: ldp     x20, x19, [sp, #0x20]                      
02d85910: ldp     x22, x21, [sp, #0x10]                      
02d85914: ldp     x30, x23, [sp], #0x30                      
02d85918: b       #0x318c658                                 
02d8591c: bl      #0x2b7105c                                 fn_2b7105c
## StopSound(Framework.ESound soundKey) -> void
---- Framework.AudioManager::StopSound 0x2d84364
02d84364: stp     x30, x25, [sp, #-0x40]!                    
02d84368: stp     x24, x23, [sp, #0x10]                      
02d8436c: stp     x22, x21, [sp, #0x20]                      
02d84370: stp     x20, x19, [sp, #0x30]                      
02d84374: adrp    x21, #0x6630000                            
02d84378: adrp    x22, #0x626d000                            
02d8437c: mov     w19, w1                                    
02d84380: ldrb    w8, [x21, #0x481]                          
02d84384: ldr     x22, [x22, #0x68]                          T:Framework.AudioManager/<>c__DisplayClass41_0
02d84388: mov     x20, x0                                    
02d8438c: tbnz    w8, #0, #0x2d84404                         
02d84390: adrp    x0, #0x626d000                             
02d84394: ldr     x0, [x0, #0x70]                            T:type53156(k15) ._soundChannelPool
02d84398: bl      #0x2b70db0                                 fn_2b70db0
02d8439c: adrp    x0, #0x626d000                             
02d843a0: ldr     x0, [x0, #0x78]                            MS:System.Linq.Enumerable::ToList ._homeBGMList
02d843a4: bl      #0x2b70db0                                 fn_2b70db0
02d843a8: adrp    x0, #0x626d000                             
02d843ac: ldr     x0, [x0, #0x80]                            MS:System.Linq.Enumerable::Where
02d843b0: bl      #0x2b70db0                                 fn_2b70db0
02d843b4: adrp    x0, #0x626d000                             
02d843b8: ldr     x0, [x0, #0x58]                            T:type55641(k15) ._soundClipDic
02d843bc: bl      #0x2b70db0                                 fn_2b70db0
02d843c0: adrp    x0, #0x626d000                             
02d843c4: ldr     x0, [x0, #0x88]                            MS:System.Collections.Generic.List`1::ForEach
02d843c8: bl      #0x2b70db0                                 fn_2b70db0
02d843cc: adrp    x0, #0x626d000                             
02d843d0: ldr     x0, [x0, #0x90]                            M:Framework.AudioManager/<>c::<StopSound>b__41_1
02d843d4: bl      #0x2b70db0                                 fn_2b70db0
02d843d8: adrp    x0, #0x626d000                             
02d843dc: ldr     x0, [x0, #0x98]                            M:Framework.AudioManager/<>c__DisplayClass41_0::<StopSound>b__0
02d843e0: bl      #0x2b70db0                                 fn_2b70db0
02d843e4: adrp    x0, #0x626d000                             
02d843e8: ldr     x0, [x0, #0x68]                            T:Framework.AudioManager/<>c__DisplayClass41_0 ._musicChannelPool
02d843ec: bl      #0x2b70db0                                 fn_2b70db0
02d843f0: adrp    x0, #0x626d000                             
02d843f4: ldr     x0, [x0, #0xa0]                            T:Framework.AudioManager/<>c
02d843f8: bl      #0x2b70db0                                 fn_2b70db0
02d843fc: mov     w8, #1                                     
02d84400: strb    w8, [x21, #0x481]                          
02d84404: ldr     x0, [x22]                                  MS:System.Collections.Generic.List`1::.ctor
02d84408: bl      #0x2b7104c                                 fn_2b7104c
02d8440c: mov     x1, xzr                                    
02d84410: mov     x21, x0                                    
02d84414: bl      #0x4e53e9c                                 System.Object::.ctor
02d84418: cbz     x21, #0x2d84530                            
02d8441c: adrp    x8, #0x626d000                             
02d84420: adrp    x23, #0x626d000                            
02d84424: adrp    x24, #0x626d000                            
02d84428: ldr     x8, [x8, #0x58]                            T:type55641(k15)
02d8442c: adrp    x25, #0x626d000                            
02d84430: adrp    x22, #0x626d000                            
02d84434: ldr     x23, [x23, #0x98]                          M:Framework.AudioManager/<>c__DisplayClass41_0::<StopSound>b__0
02d84438: ldr     x24, [x24, #0x80]                          MS:System.Linq.Enumerable::Where
02d8443c: ldr     x25, [x25, #0x78]                          MS:System.Linq.Enumerable::ToList
02d84440: ldr     x22, [x22, #0xa0]                          T:Framework.AudioManager/<>c
02d84444: ldr     x0, [x8]                                   MS:System.Collections.Generic.List`1::.ctor
02d84448: ldr     x20, [x20, #0x48]                          ._soundChannels
02d8444c: str     w19, [x21, #0x10]                          
02d84450: bl      #0x2b7104c                                 fn_2b7104c
02d84454: ldr     x2, [x23]                                  MS:System.Collections.Generic.List`1::.ctor
02d84458: mov     x1, x21                                    
02d8445c: mov     x3, xzr                                    
02d84460: mov     x19, x0                                    
02d84464: bl      #0x4940cf8                                 fn_4940cf8
02d84468: ldr     x2, [x24]                                  MS:System.Collections.Generic.List`1::.ctor
02d8446c: mov     x0, x20                                    
02d84470: mov     x1, x19                                    
02d84474: bl      #0x319fec4                                 fn_319fec4
02d84478: ldr     x1, [x25]                                  MS:System.Collections.Generic.List`1::.ctor
02d8447c: bl      #0x319eb2c                                 fn_319eb2c
02d84480: ldr     x8, [x22]                                  MS:System.Collections.Generic.List`1::.ctor
02d84484: mov     x19, x0                                    
02d84488: ldr     w9, [x8, #0xe4]                            [626d0e4]=0 f=0,0
02d8448c: cbnz    w9, #0x2d8449c                             
02d84490: mov     x0, x8                                     
02d84494: bl      #0x2b70f30                                 fn_2b70f30
02d84498: ldr     x8, [x22]                                  MS:System.Collections.Generic.List`1::.ctor
02d8449c: ldr     x9, [x8, #0xb8]                            T:type55599(k15)
02d844a0: ldr     x20, [x9, #0x30]                           
02d844a4: cbnz    x20, #0x2d84504                            
02d844a8: ldr     w10, [x8, #0xe4]                           [626d0e4]=0 f=0,0
02d844ac: cbnz    w10, #0x2d844c0                            
02d844b0: mov     x0, x8                                     
02d844b4: bl      #0x2b70f30                                 fn_2b70f30
02d844b8: ldr     x8, [x22]                                  MS:System.Collections.Generic.List`1::.ctor
02d844bc: ldr     x9, [x8, #0xb8]                            T:type55599(k15)
02d844c0: adrp    x8, #0x626d000                             
02d844c4: ldr     x8, [x8, #0x70]                            T:type53156(k15)
02d844c8: ldr     x21, [x9]                                  
02d844cc: ldr     x0, [x8]                                   MS:System.Collections.Generic.List`1::.ctor
02d844d0: bl      #0x2b7104c                                 fn_2b7104c
02d844d4: adrp    x8, #0x626d000                             
02d844d8: mov     x1, x21                                    
02d844dc: mov     x3, xzr                                    
02d844e0: ldr     x8, [x8, #0x90]                            M:Framework.AudioManager/<>c::<StopSound>b__41_1
02d844e4: mov     x20, x0                                    
02d844e8: ldr     x2, [x8]                                   MS:System.Collections.Generic.List`1::.ctor
02d844ec: bl      #0x453418c                                 fn_453418c
02d844f0: ldr     x8, [x22]                                  MS:System.Collections.Generic.List`1::.ctor
02d844f4: mov     x1, x20                                    
02d844f8: ldr     x0, [x8, #0xb8]                            T:type55599(k15)
02d844fc: str     x20, [x0, #0x30]!                          ._musicChannelPrefab
02d84500: bl      #0x2b70d54                                 fn_2b70d54
02d84504: cbz     x19, #0x2d84530                            
02d84508: adrp    x8, #0x626d000                             
02d8450c: mov     x0, x19                                    
02d84510: mov     x1, x20                                    
02d84514: ldr     x8, [x8, #0x88]                            MS:System.Collections.Generic.List`1::ForEach
02d84518: ldp     x20, x19, [sp, #0x30]                      
02d8451c: ldp     x22, x21, [sp, #0x20]                      
02d84520: ldp     x24, x23, [sp, #0x10]                      
02d84524: ldr     x2, [x8]                                   MS:System.Collections.Generic.List`1::.ctor
02d84528: ldp     x30, x25, [sp], #0x40                      
02d8452c: b       #0x35a9ce4                                 
02d84530: bl      #0x2b7105c                                 fn_2b7105c
## PauseSound(Framework.ESound soundKey) -> void
---- Framework.AudioManager::PauseSound 0x2d85b70
02d85b70: stp     x30, x25, [sp, #-0x40]!                    
02d85b74: stp     x24, x23, [sp, #0x10]                      
02d85b78: stp     x22, x21, [sp, #0x20]                      
02d85b7c: stp     x20, x19, [sp, #0x30]                      
02d85b80: adrp    x21, #0x6630000                            
02d85b84: adrp    x22, #0x626d000                            
02d85b88: mov     w19, w1                                    
02d85b8c: ldrb    w8, [x21, #0x482]                          
02d85b90: ldr     x22, [x22, #0x230]                         T:Framework.AudioManager/<>c__DisplayClass42_0
02d85b94: mov     x20, x0                                    
02d85b98: tbnz    w8, #0, #0x2d85c10                         
02d85b9c: adrp    x0, #0x626d000                             
02d85ba0: ldr     x0, [x0, #0x70]                            T:type53156(k15) ._soundChannelPool
02d85ba4: bl      #0x2b70db0                                 fn_2b70db0
02d85ba8: adrp    x0, #0x626d000                             
02d85bac: ldr     x0, [x0, #0x78]                            MS:System.Linq.Enumerable::ToList ._homeBGMList
02d85bb0: bl      #0x2b70db0                                 fn_2b70db0
02d85bb4: adrp    x0, #0x626d000                             
02d85bb8: ldr     x0, [x0, #0x80]                            MS:System.Linq.Enumerable::Where
02d85bbc: bl      #0x2b70db0                                 fn_2b70db0
02d85bc0: adrp    x0, #0x626d000                             
02d85bc4: ldr     x0, [x0, #0x58]                            T:type55641(k15) ._soundClipDic
02d85bc8: bl      #0x2b70db0                                 fn_2b70db0
02d85bcc: adrp    x0, #0x626d000                             
02d85bd0: ldr     x0, [x0, #0x88]                            MS:System.Collections.Generic.List`1::ForEach
02d85bd4: bl      #0x2b70db0                                 fn_2b70db0
02d85bd8: adrp    x0, #0x626d000                             
02d85bdc: ldr     x0, [x0, #0x238]                           M:Framework.AudioManager/<>c::<PauseSound>b__42_1
02d85be0: bl      #0x2b70db0                                 fn_2b70db0
02d85be4: adrp    x0, #0x626d000                             
02d85be8: ldr     x0, [x0, #0x240]                           M:Framework.AudioManager/<>c__DisplayClass42_0::<PauseSound>b__0
02d85bec: bl      #0x2b70db0                                 fn_2b70db0
02d85bf0: adrp    x0, #0x626d000                             
02d85bf4: ldr     x0, [x0, #0x230]                           T:Framework.AudioManager/<>c__DisplayClass42_0
02d85bf8: bl      #0x2b70db0                                 fn_2b70db0
02d85bfc: adrp    x0, #0x626d000                             
02d85c00: ldr     x0, [x0, #0xa0]                            T:Framework.AudioManager/<>c
02d85c04: bl      #0x2b70db0                                 fn_2b70db0
02d85c08: mov     w8, #1                                     
02d85c0c: strb    w8, [x21, #0x482]                          
02d85c10: ldr     x0, [x22]                                  MS:System.Collections.Generic.List`1::.ctor
02d85c14: bl      #0x2b7104c                                 fn_2b7104c
02d85c18: mov     x1, xzr                                    
02d85c1c: mov     x21, x0                                    
02d85c20: bl      #0x4e53e9c                                 System.Object::.ctor
02d85c24: cbz     x21, #0x2d85d3c                            
02d85c28: adrp    x8, #0x626d000                             
02d85c2c: adrp    x23, #0x626d000                            
02d85c30: adrp    x24, #0x626d000                            
02d85c34: ldr     x8, [x8, #0x58]                            T:type55641(k15)
02d85c38: adrp    x25, #0x626d000                            
02d85c3c: adrp    x22, #0x626d000                            
02d85c40: ldr     x23, [x23, #0x240]                         M:Framework.AudioManager/<>c__DisplayClass42_0::<PauseSound>b__0
02d85c44: ldr     x24, [x24, #0x80]                          MS:System.Linq.Enumerable::Where
02d85c48: ldr     x25, [x25, #0x78]                          MS:System.Linq.Enumerable::ToList
02d85c4c: ldr     x22, [x22, #0xa0]                          T:Framework.AudioManager/<>c
02d85c50: ldr     x0, [x8]                                   MS:System.Collections.Generic.List`1::.ctor
02d85c54: ldr     x20, [x20, #0x48]                          ._soundChannels
02d85c58: str     w19, [x21, #0x10]                          
02d85c5c: bl      #0x2b7104c                                 fn_2b7104c
02d85c60: ldr     x2, [x23]                                  MS:System.Collections.Generic.List`1::.ctor
02d85c64: mov     x1, x21                                    
02d85c68: mov     x3, xzr                                    
02d85c6c: mov     x19, x0                                    
02d85c70: bl      #0x4940cf8                                 fn_4940cf8
02d85c74: ldr     x2, [x24]                                  MS:System.Collections.Generic.List`1::.ctor
02d85c78: mov     x0, x20                                    
02d85c7c: mov     x1, x19                                    
02d85c80: bl      #0x319fec4                                 fn_319fec4
02d85c84: ldr     x1, [x25]                                  MS:System.Collections.Generic.List`1::.ctor
02d85c88: bl      #0x319eb2c                                 fn_319eb2c
02d85c8c: ldr     x8, [x22]                                  MS:System.Collections.Generic.List`1::.ctor
02d85c90: mov     x19, x0                                    
02d85c94: ldr     w9, [x8, #0xe4]                            [626d0e4]=0 f=0,0
02d85c98: cbnz    w9, #0x2d85ca8                             
02d85c9c: mov     x0, x8                                     
02d85ca0: bl      #0x2b70f30                                 fn_2b70f30
02d85ca4: ldr     x8, [x22]                                  MS:System.Collections.Generic.List`1::.ctor
02d85ca8: ldr     x9, [x8, #0xb8]                            T:type55599(k15)
02d85cac: ldr     x20, [x9, #0x38]                           
02d85cb0: cbnz    x20, #0x2d85d10                            
02d85cb4: ldr     w10, [x8, #0xe4]                           [626d0e4]=0 f=0,0
02d85cb8: cbnz    w10, #0x2d85ccc                            
02d85cbc: mov     x0, x8                                     
02d85cc0: bl      #0x2b70f30                                 fn_2b70f30
02d85cc4: ldr     x8, [x22]                                  MS:System.Collections.Generic.List`1::.ctor
02d85cc8: ldr     x9, [x8, #0xb8]                            T:type55599(k15)
02d85ccc: adrp    x8, #0x626d000                             
02d85cd0: ldr     x8, [x8, #0x70]                            T:type53156(k15)
02d85cd4: ldr     x21, [x9]                                  
02d85cd8: ldr     x0, [x8]                                   MS:System.Collections.Generic.List`1::.ctor
02d85cdc: bl      #0x2b7104c                                 fn_2b7104c
02d85ce0: adrp    x8, #0x626d000                             
02d85ce4: mov     x1, x21                                    
02d85ce8: mov     x3, xzr                                    
02d85cec: ldr     x8, [x8, #0x238]                           M:Framework.AudioManager/<>c::<PauseSound>b__42_1
02d85cf0: mov     x20, x0                                    
02d85cf4: ldr     x2, [x8]                                   MS:System.Collections.Generic.List`1::.ctor
02d85cf8: bl      #0x453418c                                 fn_453418c
02d85cfc: ldr     x8, [x22]                                  MS:System.Collections.Generic.List`1::.ctor
02d85d00: mov     x1, x20                                    
02d85d04: ldr     x0, [x8, #0xb8]                            T:type55599(k15)
02d85d08: str     x20, [x0, #0x38]!                          ._soundChannelPrefab
02d85d0c: bl      #0x2b70d54                                 fn_2b70d54
02d85d10: cbz     x19, #0x2d85d3c                            
02d85d14: adrp    x8, #0x626d000                             
02d85d18: mov     x0, x19                                    
02d85d1c: mov     x1, x20                                    
02d85d20: ldr     x8, [x8, #0x88]                            MS:System.Collections.Generic.List`1::ForEach
02d85d24: ldp     x20, x19, [sp, #0x30]                      
02d85d28: ldp     x22, x21, [sp, #0x20]                      
02d85d2c: ldp     x24, x23, [sp, #0x10]                      
02d85d30: ldr     x2, [x8]                                   MS:System.Collections.Generic.List`1::.ctor
02d85d34: ldp     x30, x25, [sp], #0x40                      
02d85d38: b       #0x35a9ce4                                 
02d85d3c: bl      #0x2b7105c                                 fn_2b7105c
## ResumeSound(Framework.ESound soundKey) -> void
---- Framework.AudioManager::ResumeSound 0x2d85d48
02d85d48: stp     x30, x25, [sp, #-0x40]!                    
02d85d4c: stp     x24, x23, [sp, #0x10]                      
02d85d50: stp     x22, x21, [sp, #0x20]                      
02d85d54: stp     x20, x19, [sp, #0x30]                      
02d85d58: adrp    x21, #0x6630000                            
02d85d5c: adrp    x22, #0x626d000                            
02d85d60: mov     w19, w1                                    
02d85d64: ldrb    w8, [x21, #0x483]                          
02d85d68: ldr     x22, [x22, #0x248]                         T:Framework.AudioManager/<>c__DisplayClass43_0
02d85d6c: mov     x20, x0                                    
02d85d70: tbnz    w8, #0, #0x2d85de8                         
02d85d74: adrp    x0, #0x626d000                             
02d85d78: ldr     x0, [x0, #0x70]                            T:type53156(k15) ._soundChannelPool
02d85d7c: bl      #0x2b70db0                                 fn_2b70db0
02d85d80: adrp    x0, #0x626d000                             
02d85d84: ldr     x0, [x0, #0x78]                            MS:System.Linq.Enumerable::ToList ._homeBGMList
02d85d88: bl      #0x2b70db0                                 fn_2b70db0
02d85d8c: adrp    x0, #0x626d000                             
02d85d90: ldr     x0, [x0, #0x80]                            MS:System.Linq.Enumerable::Where
02d85d94: bl      #0x2b70db0                                 fn_2b70db0
02d85d98: adrp    x0, #0x626d000                             
02d85d9c: ldr     x0, [x0, #0x58]                            T:type55641(k15) ._soundClipDic
02d85da0: bl      #0x2b70db0                                 fn_2b70db0
02d85da4: adrp    x0, #0x626d000                             
02d85da8: ldr     x0, [x0, #0x88]                            MS:System.Collections.Generic.List`1::ForEach
02d85dac: bl      #0x2b70db0                                 fn_2b70db0
02d85db0: adrp    x0, #0x626d000                             
02d85db4: ldr     x0, [x0, #0x250]                           M:Framework.AudioManager/<>c::<ResumeSound>b__43_1
02d85db8: bl      #0x2b70db0                                 fn_2b70db0
02d85dbc: adrp    x0, #0x626d000                             
02d85dc0: ldr     x0, [x0, #0x258]                           M:Framework.AudioManager/<>c__DisplayClass43_0::<ResumeSound>b__0
02d85dc4: bl      #0x2b70db0                                 fn_2b70db0
02d85dc8: adrp    x0, #0x626d000                             
02d85dcc: ldr     x0, [x0, #0x248]                           T:Framework.AudioManager/<>c__DisplayClass43_0
02d85dd0: bl      #0x2b70db0                                 fn_2b70db0
02d85dd4: adrp    x0, #0x626d000                             
02d85dd8: ldr     x0, [x0, #0xa0]                            T:Framework.AudioManager/<>c
02d85ddc: bl      #0x2b70db0                                 fn_2b70db0
02d85de0: mov     w8, #1                                     
02d85de4: strb    w8, [x21, #0x483]                          
02d85de8: ldr     x0, [x22]                                  MS:System.Collections.Generic.List`1::.ctor
02d85dec: bl      #0x2b7104c                                 fn_2b7104c
02d85df0: mov     x1, xzr                                    
02d85df4: mov     x21, x0                                    
02d85df8: bl      #0x4e53e9c                                 System.Object::.ctor
02d85dfc: cbz     x21, #0x2d85f14                            
02d85e00: adrp    x8, #0x626d000                             
02d85e04: adrp    x23, #0x626d000                            
02d85e08: adrp    x24, #0x626d000                            
02d85e0c: ldr     x8, [x8, #0x58]                            T:type55641(k15)
02d85e10: adrp    x25, #0x626d000                            
02d85e14: adrp    x22, #0x626d000                            
02d85e18: ldr     x23, [x23, #0x258]                         M:Framework.AudioManager/<>c__DisplayClass43_0::<ResumeSound>b__0
02d85e1c: ldr     x24, [x24, #0x80]                          MS:System.Linq.Enumerable::Where
02d85e20: ldr     x25, [x25, #0x78]                          MS:System.Linq.Enumerable::ToList
02d85e24: ldr     x22, [x22, #0xa0]                          T:Framework.AudioManager/<>c
02d85e28: ldr     x0, [x8]                                   MS:System.Collections.Generic.List`1::.ctor
02d85e2c: ldr     x20, [x20, #0x48]                          ._soundChannels
02d85e30: str     w19, [x21, #0x10]                          
02d85e34: bl      #0x2b7104c                                 fn_2b7104c
02d85e38: ldr     x2, [x23]                                  MS:System.Collections.Generic.List`1::.ctor
02d85e3c: mov     x1, x21                                    
02d85e40: mov     x3, xzr                                    
02d85e44: mov     x19, x0                                    
02d85e48: bl      #0x4940cf8                                 fn_4940cf8
02d85e4c: ldr     x2, [x24]                                  MS:System.Collections.Generic.List`1::.ctor
02d85e50: mov     x0, x20                                    
02d85e54: mov     x1, x19                                    
02d85e58: bl      #0x319fec4                                 fn_319fec4
02d85e5c: ldr     x1, [x25]                                  MS:System.Collections.Generic.List`1::.ctor
02d85e60: bl      #0x319eb2c                                 fn_319eb2c
02d85e64: ldr     x8, [x22]                                  MS:System.Collections.Generic.List`1::.ctor
02d85e68: mov     x19, x0                                    
02d85e6c: ldr     w9, [x8, #0xe4]                            [626d0e4]=0 f=0,0
02d85e70: cbnz    w9, #0x2d85e80                             
02d85e74: mov     x0, x8                                     
02d85e78: bl      #0x2b70f30                                 fn_2b70f30
02d85e7c: ldr     x8, [x22]                                  MS:System.Collections.Generic.List`1::.ctor
02d85e80: ldr     x9, [x8, #0xb8]                            T:type55599(k15)
02d85e84: ldr     x20, [x9, #0x40]                           
02d85e88: cbnz    x20, #0x2d85ee8                            
02d85e8c: ldr     w10, [x8, #0xe4]                           [626d0e4]=0 f=0,0
02d85e90: cbnz    w10, #0x2d85ea4                            
02d85e94: mov     x0, x8                                     
02d85e98: bl      #0x2b70f30                                 fn_2b70f30
02d85e9c: ldr     x8, [x22]                                  MS:System.Collections.Generic.List`1::.ctor
02d85ea0: ldr     x9, [x8, #0xb8]                            T:type55599(k15)
02d85ea4: adrp    x8, #0x626d000                             
02d85ea8: ldr     x8, [x8, #0x70]                            T:type53156(k15)
02d85eac: ldr     x21, [x9]                                  
02d85eb0: ldr     x0, [x8]                                   MS:System.Collections.Generic.List`1::.ctor
02d85eb4: bl      #0x2b7104c                                 fn_2b7104c
02d85eb8: adrp    x8, #0x626d000                             
02d85ebc: mov     x1, x21                                    
02d85ec0: mov     x3, xzr                                    
02d85ec4: ldr     x8, [x8, #0x250]                           M:Framework.AudioManager/<>c::<ResumeSound>b__43_1
02d85ec8: mov     x20, x0                                    
02d85ecc: ldr     x2, [x8]                                   MS:System.Collections.Generic.List`1::.ctor
02d85ed0: bl      #0x453418c                                 fn_453418c
02d85ed4: ldr     x8, [x22]                                  MS:System.Collections.Generic.List`1::.ctor
02d85ed8: mov     x1, x20                                    
02d85edc: ldr     x0, [x8, #0xb8]                            T:type55599(k15)
02d85ee0: str     x20, [x0, #0x40]!                          ._musicChannels
02d85ee4: bl      #0x2b70d54                                 fn_2b70d54
02d85ee8: cbz     x19, #0x2d85f14                            
02d85eec: adrp    x8, #0x626d000                             
02d85ef0: mov     x0, x19                                    
02d85ef4: mov     x1, x20                                    
02d85ef8: ldr     x8, [x8, #0x88]                            MS:System.Collections.Generic.List`1::ForEach
02d85efc: ldp     x20, x19, [sp, #0x30]                      
02d85f00: ldp     x22, x21, [sp, #0x20]                      
02d85f04: ldp     x24, x23, [sp, #0x10]                      
02d85f08: ldr     x2, [x8]                                   MS:System.Collections.Generic.List`1::.ctor
02d85f0c: ldp     x30, x25, [sp], #0x40                      
02d85f10: b       #0x35a9ce4                                 
02d85f14: bl      #0x2b7105c                                 fn_2b7105c
## StopAllSound() -> void
---- Framework.AudioManager::StopAllSound 0x2d85f20
02d85f20: str     x30, [sp, #-0x30]!                         
02d85f24: stp     x22, x21, [sp, #0x10]                      
02d85f28: stp     x20, x19, [sp, #0x20]                      
02d85f2c: adrp    x20, #0x6630000                            
02d85f30: adrp    x22, #0x626d000                            
02d85f34: mov     x19, x0                                    
02d85f38: ldrb    w8, [x20, #0x484]                          
02d85f3c: ldr     x22, [x22, #0xa0]                          T:Framework.AudioManager/<>c
02d85f40: tbnz    w8, #0, #0x2d85f7c                         
02d85f44: adrp    x0, #0x626d000                             
02d85f48: ldr     x0, [x0, #0x70]                            T:type53156(k15) ._soundChannelPool
02d85f4c: bl      #0x2b70db0                                 fn_2b70db0
02d85f50: adrp    x0, #0x626d000                             
02d85f54: ldr     x0, [x0, #0x88]                            MS:System.Collections.Generic.List`1::ForEach
02d85f58: bl      #0x2b70db0                                 fn_2b70db0
02d85f5c: adrp    x0, #0x626d000                             
02d85f60: ldr     x0, [x0, #0x260]                           M:Framework.AudioManager/<>c::<StopAllSound>b__44_0
02d85f64: bl      #0x2b70db0                                 fn_2b70db0
02d85f68: adrp    x0, #0x626d000                             
02d85f6c: ldr     x0, [x0, #0xa0]                            T:Framework.AudioManager/<>c
02d85f70: bl      #0x2b70db0                                 fn_2b70db0
02d85f74: mov     w8, #1                                     
02d85f78: strb    w8, [x20, #0x484]                          
02d85f7c: ldr     x0, [x22]                                  MS:System.Collections.Generic.List`1::.ctor
02d85f80: ldr     x19, [x19, #0x48]                          ._soundChannels
02d85f84: ldr     w8, [x0, #0xe4]                            [626d0e4]=0 f=0,0
02d85f88: cbnz    w8, #0x2d85f94                             
02d85f8c: bl      #0x2b70f30                                 fn_2b70f30
02d85f90: ldr     x0, [x22]                                  MS:System.Collections.Generic.List`1::.ctor
02d85f94: ldr     x8, [x0, #0xb8]                            T:type55599(k15)
02d85f98: ldr     x20, [x8, #0x48]                           
02d85f9c: cbnz    x20, #0x2d85ff8                            
02d85fa0: ldr     w9, [x0, #0xe4]                            [626d0e4]=0 f=0,0
02d85fa4: cbnz    w9, #0x2d85fb4                             
02d85fa8: bl      #0x2b70f30                                 fn_2b70f30
02d85fac: ldr     x8, [x22]                                  MS:System.Collections.Generic.List`1::.ctor
02d85fb0: ldr     x8, [x8, #0xb8]                            
02d85fb4: adrp    x9, #0x626d000                             
02d85fb8: ldr     x9, [x9, #0x70]                            T:type53156(k15)
02d85fbc: ldr     x21, [x8]                                  
02d85fc0: ldr     x0, [x9]                                   MS:System.Collections.Generic.List`1::.ctor
02d85fc4: bl      #0x2b7104c                                 fn_2b7104c
02d85fc8: adrp    x8, #0x626d000                             
02d85fcc: mov     x1, x21                                    
02d85fd0: mov     x3, xzr                                    
02d85fd4: ldr     x8, [x8, #0x260]                           M:Framework.AudioManager/<>c::<StopAllSound>b__44_0
02d85fd8: mov     x20, x0                                    
02d85fdc: ldr     x2, [x8]                                   MS:System.Collections.Generic.List`1::.ctor
02d85fe0: bl      #0x453418c                                 fn_453418c
02d85fe4: ldr     x8, [x22]                                  MS:System.Collections.Generic.List`1::.ctor
02d85fe8: mov     x1, x20                                    
02d85fec: ldr     x0, [x8, #0xb8]                            T:type55599(k15)
02d85ff0: str     x20, [x0, #0x48]!                          ._soundChannels
02d85ff4: bl      #0x2b70d54                                 fn_2b70d54
02d85ff8: cbz     x19, #0x2d86020                            
02d85ffc: adrp    x8, #0x626d000                             
02d86000: mov     x0, x19                                    
02d86004: mov     x1, x20                                    
02d86008: ldr     x8, [x8, #0x88]                            MS:System.Collections.Generic.List`1::ForEach
02d8600c: ldp     x20, x19, [sp, #0x20]                      
02d86010: ldp     x22, x21, [sp, #0x10]                      
02d86014: ldr     x2, [x8]                                   MS:System.Collections.Generic.List`1::.ctor
02d86018: ldr     x30, [sp], #0x30                           
02d8601c: b       #0x35a9ce4                                 
02d86020: bl      #0x2b7105c                                 fn_2b7105c
## PlayMusicIfNotPlaying(float volume) -> void
---- Framework.AudioManager::PlayMusicIfNotPlaying 0x2d86024
02d86024: str     d8, [sp, #-0x20]!                          
02d86028: str     x30, [sp, #8]                              
02d8602c: stp     x20, x19, [sp, #0x10]                      
02d86030: fmov    s8, s0                                     
02d86034: mov     x19, x0                                    
02d86038: bl      #0x2d86084                                 Framework.AudioManager::GetRandomHomeBGM
02d8603c: mov     w20, w0                                    
02d86040: mov     x0, x19                                    
02d86044: bl      #0x2d84854                                 Framework.AudioManager::get_CurrentMusicKey
02d86048: cmp     w0, w20                                    
02d8604c: b.ne    #0x2d86060                                 
02d86050: ldp     x20, x19, [sp, #0x10]                      
02d86054: ldr     x30, [sp, #8]                              
02d86058: ldr     d8, [sp], #0x20                            
02d8605c: ret                                                
02d86060: mov     x0, x19                                    
02d86064: bl      #0x2d85084                                 Framework.AudioManager::StopAllMusic
02d86068: mov     x0, x19                                    
02d8606c: mov     w1, w20                                    
02d86070: ldr     x30, [sp, #8]                              
02d86074: ldp     x20, x19, [sp, #0x10]                      
02d86078: fmov    s0, s8                                     
02d8607c: ldr     d8, [sp], #0x20                            
02d86080: b       #0x2d846d8                                 Framework.AudioManager::PlayMusic
## GetRandomHomeBGM() -> Framework.EMusic
---- Framework.AudioManager::GetRandomHomeBGM 0x2d86084
02d86084: str     x30, [sp, #-0x20]!                         
02d86088: stp     x20, x19, [sp, #0x10]                      
02d8608c: adrp    x20, #0x6630000                            
02d86090: mov     x19, x0                                    
02d86094: ldrb    w8, [x20, #0x485]                          
02d86098: tbnz    w8, #0, #0x2d860bc                         
02d8609c: adrp    x0, #0x626d000                             
02d860a0: ldr     x0, [x0, #0x268]                           MS:System.Collections.Generic.List`1::get_Count
02d860a4: bl      #0x2b70db0                                 fn_2b70db0
02d860a8: adrp    x0, #0x626d000                             
02d860ac: ldr     x0, [x0, #0x270]                           MS:System.Collections.Generic.List`1::get_Item
02d860b0: bl      #0x2b70db0                                 fn_2b70db0
02d860b4: mov     w8, #1                                     
02d860b8: strb    w8, [x20, #0x485]                          
02d860bc: ldr     x19, [x19, #0x78]                          ._homeBGMList
02d860c0: cbz     x19, #0x2d860f4                            
02d860c4: adrp    x20, #0x626d000                            
02d860c8: mov     w0, wzr                                    
02d860cc: mov     x2, xzr                                    
02d860d0: ldr     x20, [x20, #0x270]                         MS:System.Collections.Generic.List`1::get_Item
02d860d4: ldr     w1, [x19, #0x18]                           
02d860d8: bl      #0x5b2e000                                 UnityEngine.Random::Range
02d860dc: ldr     x2, [x20]                                  MS:System.Collections.Generic.List`1::.ctor
02d860e0: mov     w1, w0                                     
02d860e4: mov     x0, x19                                    
02d860e8: ldp     x20, x19, [sp, #0x10]                      
02d860ec: ldr     x30, [sp], #0x20                           
02d860f0: b       #0x356c280                                 
02d860f4: bl      #0x2b7105c                                 fn_2b7105c
## .ctor() -> void
---- Framework.AudioManager::.ctor 0x2d860f8
02d860f8: str     x30, [sp, #-0x50]!                         
02d860fc: stp     x26, x25, [sp, #0x10]                      
02d86100: stp     x24, x23, [sp, #0x20]                      
02d86104: stp     x22, x21, [sp, #0x30]                      
02d86108: stp     x20, x19, [sp, #0x40]                      
02d8610c: adrp    x25, #0x626d000                            
02d86110: adrp    x20, #0x626d000                            
02d86114: adrp    x24, #0x626d000                            
02d86118: adrp    x26, #0x6630000                            
02d8611c: adrp    x23, #0x626d000                            
02d86120: adrp    x22, #0x626d000                            
02d86124: adrp    x21, #0x626d000                            
02d86128: ldr     x25, [x25, #0x278]                         T:type56763(k15)
02d8612c: ldr     x20, [x20, #0x280]                         MS:System.Collections.Generic.List`1::.ctor
02d86130: ldr     x24, [x24, #0x288]                         T:type56814(k15)
02d86134: ldr     x23, [x23, #0x290]                         MS:System.Collections.Generic.List`1::.ctor
02d86138: ldrb    w8, [x26, #0x486]                          
02d8613c: ldr     x22, [x22, #0x298]                         T:type56679(k15)
02d86140: ldr     x21, [x21, #0x2a0]                         MS:System.Collections.Generic.List`1::.ctor
02d86144: mov     x19, x0                                    
02d86148: tbnz    w8, #0, #0x2d861a8                         
02d8614c: adrp    x0, #0x626d000                             
02d86150: ldr     x0, [x0, #0x2a8]                           MS:System.Collections.Generic.List`1::Add
02d86154: bl      #0x2b70db0                                 fn_2b70db0
02d86158: adrp    x0, #0x626d000                             
02d8615c: ldr     x0, [x0, #0x280]                           MS:System.Collections.Generic.List`1::.ctor
02d86160: bl      #0x2b70db0                                 fn_2b70db0
02d86164: adrp    x0, #0x626d000                             
02d86168: ldr     x0, [x0, #0x2a0]                           MS:System.Collections.Generic.List`1::.ctor
02d8616c: bl      #0x2b70db0                                 fn_2b70db0
02d86170: adrp    x0, #0x626d000                             
02d86174: ldr     x0, [x0, #0x290]                           MS:System.Collections.Generic.List`1::.ctor
02d86178: bl      #0x2b70db0                                 fn_2b70db0
02d8617c: adrp    x0, #0x626d000                             
02d86180: ldr     x0, [x0, #0x278]                           T:type56763(k15)
02d86184: bl      #0x2b70db0                                 fn_2b70db0
02d86188: adrp    x0, #0x626d000                             
02d8618c: ldr     x0, [x0, #0x298]                           T:type56679(k15)
02d86190: bl      #0x2b70db0                                 fn_2b70db0
02d86194: adrp    x0, #0x626d000                             
02d86198: ldr     x0, [x0, #0x288]                           T:type56814(k15)
02d8619c: bl      #0x2b70db0                                 fn_2b70db0
02d861a0: mov     w8, #1                                     
02d861a4: strb    w8, [x26, #0x486]                          
02d861a8: ldr     x0, [x25]                                  MS:System.Collections.Generic.List`1::.ctor
02d861ac: bl      #0x2b7104c                                 fn_2b7104c
02d861b0: ldr     x1, [x20]                                  MS:System.Collections.Generic.List`1::.ctor
02d861b4: mov     x20, x0                                    
02d861b8: bl      #0x35a89a4                                 fn_35a89a4
02d861bc: mov     x0, x19                                    
02d861c0: mov     x1, x20                                    
02d861c4: str     x20, [x0, #0x40]!                          ._musicChannels
02d861c8: bl      #0x2b70d54                                 fn_2b70d54
02d861cc: ldr     x0, [x24]                                  MS:System.Collections.Generic.List`1::.ctor
02d861d0: bl      #0x2b7104c                                 fn_2b7104c
02d861d4: ldr     x1, [x23]                                  MS:System.Collections.Generic.List`1::.ctor
02d861d8: mov     x20, x0                                    
02d861dc: bl      #0x35a89a4                                 fn_35a89a4
02d861e0: mov     x0, x19                                    
02d861e4: mov     x1, x20                                    
02d861e8: str     x20, [x0, #0x48]!                          ._soundChannels
02d861ec: bl      #0x2b70d54                                 fn_2b70d54
02d861f0: ldr     x0, [x22]                                  MS:System.Collections.Generic.List`1::.ctor
02d861f4: bl      #0x2b7104c                                 fn_2b7104c
02d861f8: ldr     x1, [x21]                                  MS:System.Collections.Generic.List`1::.ctor
02d861fc: mov     x20, x0                                    
02d86200: bl      #0x356bce8                                 fn_356bce8
02d86204: cbz     x20, #0x2d86360                            
02d86208: adrp    x21, #0x626d000                            
02d8620c: ldr     x21, [x21, #0x2a8]                         MS:System.Collections.Generic.List`1::Add
02d86210: ldr     w10, [x20, #0x1c]                          [626d01c]=0 f=0,0
02d86214: ldr     x8, [x20, #0x10]                           T:type56591(k15)
02d86218: ldr     x9, [x21]                                  MS:System.Collections.Generic.List`1::.ctor
02d8621c: add     w10, w10, #1                               
02d86220: str     w10, [x20, #0x1c]                          
02d86224: cbz     x8, #0x2d86360                             
02d86228: ldrsw   x10, [x20, #0x18]                          
02d8622c: ldr     w11, [x8, #0x18]                           
02d86230: cmp     w10, w11                                   
02d86234: b.hs    #0x2d8625c                                 
02d86238: add     w11, w10, #1                               
02d8623c: add     x10, x8, x10, lsl #2                       
02d86240: str     w11, [x20, #0x18]                          
02d86244: mov     w11, #1                                    
02d86248: str     w11, [x10, #0x20]                          
02d8624c: ldr     w10, [x20, #0x1c]                          [626d01c]=0 f=0,0
02d86250: add     w10, w10, #1                               
02d86254: str     w10, [x20, #0x1c]                          
02d86258: b       #0x2d8628c                                 
02d8625c: ldr     x8, [x9, #0x20]                            
02d86260: mov     x0, x20                                    
02d86264: mov     w1, #1                                     
02d86268: ldr     x8, [x8, #0xc0]                            
02d8626c: ldr     x2, [x8, #0x70]                            
02d86270: bl      #0x356c578                                 fn_356c578
02d86274: ldr     w10, [x20, #0x1c]                          [626d01c]=0 f=0,0
02d86278: ldr     x8, [x20, #0x10]                           T:type56591(k15)
02d8627c: ldr     x9, [x21]                                  MS:System.Collections.Generic.List`1::.ctor
02d86280: add     w10, w10, #1                               
02d86284: str     w10, [x20, #0x1c]                          
02d86288: cbz     x8, #0x2d86360                             
02d8628c: ldrsw   x10, [x20, #0x18]                          
02d86290: ldr     w11, [x8, #0x18]                           
02d86294: cmp     w10, w11                                   
02d86298: b.hs    #0x2d862c0                                 
02d8629c: add     w11, w10, #1                               
02d862a0: add     x10, x8, x10, lsl #2                       
02d862a4: str     w11, [x20, #0x18]                          
02d862a8: mov     w11, #2                                    
02d862ac: str     w11, [x10, #0x20]                          
02d862b0: ldr     w10, [x20, #0x1c]                          [626d01c]=0 f=0,0
02d862b4: add     w10, w10, #1                               
02d862b8: str     w10, [x20, #0x1c]                          
02d862bc: b       #0x2d862f0                                 
02d862c0: ldr     x8, [x9, #0x20]                            
02d862c4: mov     x0, x20                                    
02d862c8: mov     w1, #2                                     
02d862cc: ldr     x8, [x8, #0xc0]                            
02d862d0: ldr     x2, [x8, #0x70]                            
02d862d4: bl      #0x356c578                                 fn_356c578
02d862d8: ldr     w10, [x20, #0x1c]                          [626d01c]=0 f=0,0
02d862dc: ldr     x8, [x20, #0x10]                           T:type56591(k15)
02d862e0: ldr     x9, [x21]                                  MS:System.Collections.Generic.List`1::.ctor
02d862e4: add     w10, w10, #1                               
02d862e8: str     w10, [x20, #0x1c]                          
02d862ec: cbz     x8, #0x2d86360                             
02d862f0: ldrsw   x10, [x20, #0x18]                          
02d862f4: ldr     w11, [x8, #0x18]                           
02d862f8: cmp     w10, w11                                   
02d862fc: b.hs    #0x2d86318                                 
02d86300: add     w9, w10, #1                                
02d86304: add     x8, x8, x10, lsl #2                        
02d86308: str     w9, [x20, #0x18]                           
02d8630c: mov     w9, #3                                     
02d86310: str     w9, [x8, #0x20]                            
02d86314: b       #0x2d86330                                 
02d86318: ldr     x8, [x9, #0x20]                            
02d8631c: mov     x0, x20                                    
02d86320: mov     w1, #3                                     
02d86324: ldr     x8, [x8, #0xc0]                            
02d86328: ldr     x2, [x8, #0x70]                            
02d8632c: bl      #0x356c578                                 fn_356c578
02d86330: mov     x0, x19                                    
02d86334: mov     x1, x20                                    
02d86338: str     x20, [x0, #0x78]!                          ._homeBGMList
02d8633c: bl      #0x2b70d54                                 fn_2b70d54
02d86340: mov     x0, x19                                    
02d86344: ldp     x20, x19, [sp, #0x40]                      
02d86348: ldp     x22, x21, [sp, #0x30]                      
02d8634c: mov     x1, xzr                                    
02d86350: ldp     x24, x23, [sp, #0x20]                      
02d86354: ldp     x26, x25, [sp, #0x10]                      
02d86358: ldr     x30, [sp], #0x50                           
02d8635c: b       #0x5b397b0                                 UnityEngine.MonoBehaviour::.ctor
02d86360: bl      #0x2b7105c                                 fn_2b7105c
## <Start>b__28_0() -> Framework.MusicChannel
---- Framework.AudioManager::<Start>b__28_0 0x2d86364
02d86364: str     x30, [sp, #-0x30]!                         
02d86368: stp     x22, x21, [sp, #0x10]                      
02d8636c: stp     x20, x19, [sp, #0x20]                      
02d86370: adrp    x19, #0x6630000                            
02d86374: adrp    x21, #0x6263000                            
02d86378: mov     x20, x0                                    
02d8637c: ldrb    w8, [x19, #0x487]                          
02d86380: ldr     x21, [x21, #0x918]                         T:UnityEngine.Object
02d86384: tbnz    w8, #0, #0x2d863a8                         
02d86388: adrp    x0, #0x626d000                             
02d8638c: ldr     x0, [x0, #0x2b0]                           MS:UnityEngine.Object::Instantiate
02d86390: bl      #0x2b70db0                                 fn_2b70db0
02d86394: adrp    x0, #0x6263000                             
02d86398: ldr     x0, [x0, #0x918]                           T:UnityEngine.Object
02d8639c: bl      #0x2b70db0                                 fn_2b70db0
02d863a0: mov     w8, #1                                     
02d863a4: strb    w8, [x19, #0x487]                          
02d863a8: adrp    x22, #0x626d000                            
02d863ac: mov     x0, x20                                    
02d863b0: mov     x1, xzr                                    
02d863b4: ldr     x22, [x22, #0x2b0]                         MS:UnityEngine.Object::Instantiate
02d863b8: ldr     x19, [x20, #0x30]                          ._musicChannelPrefab
02d863bc: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02d863c0: ldr     x8, [x21]                                  &2c5bbd4(=a9bd7bfdd503233f)
02d863c4: mov     x20, x0                                    
02d863c8: ldr     w9, [x8, #0xe4]                            
02d863cc: cbnz    w9, #0x2d863d8                             
02d863d0: mov     x0, x8                                     
02d863d4: bl      #0x2b70f30                                 fn_2b70f30
02d863d8: ldr     x2, [x22]                                  MS:System.Collections.Generic.List`1::.ctor
02d863dc: mov     x0, x19                                    
02d863e0: mov     x1, x20                                    
02d863e4: ldp     x20, x19, [sp, #0x20]                      
02d863e8: ldp     x22, x21, [sp, #0x10]                      
02d863ec: ldr     x30, [sp], #0x30                           
02d863f0: b       #0x3275fcc                                 
## <Start>b__28_1(Framework.MusicChannel channel) -> void
---- Framework.AudioManager::<Start>b__28_1 0x2d863f4
02d863f4: stp     x30, x21, [sp, #-0x20]!                    
02d863f8: stp     x20, x19, [sp, #0x10]                      
02d863fc: adrp    x21, #0x6630000                            
02d86400: mov     x19, x1                                    
02d86404: mov     x20, x0                                    
02d86408: ldrb    w8, [x21, #0x488]                          
02d8640c: tbnz    w8, #0, #0x2d86424                         
02d86410: adrp    x0, #0x626d000                             
02d86414: ldr     x0, [x0, #0x2b8]                           MS:System.Collections.Generic.List`1::Add
02d86418: bl      #0x2b70db0                                 fn_2b70db0
02d8641c: mov     w8, #1                                     
02d86420: strb    w8, [x21, #0x488]                          
02d86424: cbz     x19, #0x2d864bc                            
02d86428: mov     x0, x19                                    
02d8642c: mov     x1, xzr                                    
02d86430: bl      #0x5b339ec                                 UnityEngine.Component::get_gameObject
02d86434: cbz     x0, #0x2d864bc                             
02d86438: mov     w1, #1                                     
02d8643c: mov     x2, xzr                                    
02d86440: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d86444: ldr     x8, [x20, #0x40]                           ._musicChannels
02d86448: cbz     x8, #0x2d864bc                             
02d8644c: adrp    x10, #0x626d000                            
02d86450: ldr     x10, [x10, #0x2b8]                         MS:System.Collections.Generic.List`1::Add
02d86454: ldr     w11, [x8, #0x1c]                           
02d86458: ldr     x9, [x8, #0x10]                            
02d8645c: ldr     x10, [x10]                                 MS:System.Collections.Generic.List`1::.ctor
02d86460: add     w11, w11, #1                               
02d86464: str     w11, [x8, #0x1c]                           
02d86468: cbz     x9, #0x2d864bc                             
02d8646c: ldrsw   x11, [x8, #0x18]                           
02d86470: ldr     w12, [x9, #0x18]                           
02d86474: cmp     w11, w12                                   
02d86478: b.hs    #0x2d8649c                                 
02d8647c: add     x0, x9, x11, lsl #3                        
02d86480: mov     x1, x19                                    
02d86484: add     w9, w11, #1                                
02d86488: str     w9, [x8, #0x18]                            
02d8648c: str     x19, [x0, #0x20]!                          ._musicClipList
02d86490: ldp     x20, x19, [sp, #0x10]                      
02d86494: ldp     x30, x21, [sp], #0x20                      
02d86498: b       #0x2b70d54                                 
02d8649c: ldr     x9, [x10, #0x20]                           T:Redcode.Demo.DestroyChildsWhere/<>c
02d864a0: mov     x1, x19                                    
02d864a4: mov     x0, x8                                     
02d864a8: ldp     x20, x19, [sp, #0x10]                      
02d864ac: ldr     x9, [x9, #0xc0]                            
02d864b0: ldr     x2, [x9, #0x70]                            
02d864b4: ldp     x30, x21, [sp], #0x20                      
02d864b8: b       #0x35a920c                                 
02d864bc: bl      #0x2b7105c                                 fn_2b7105c
## <Start>b__28_2(Framework.MusicChannel channel) -> void
---- Framework.AudioManager::<Start>b__28_2 0x2d864c0
02d864c0: stp     x30, x21, [sp, #-0x20]!                    
02d864c4: stp     x20, x19, [sp, #0x10]                      
02d864c8: adrp    x21, #0x6630000                            
02d864cc: mov     x19, x1                                    
02d864d0: mov     x20, x0                                    
02d864d4: ldrb    w8, [x21, #0x489]                          
02d864d8: tbnz    w8, #0, #0x2d864f0                         
02d864dc: adrp    x0, #0x626d000                             
02d864e0: ldr     x0, [x0, #0x2c0]                           MS:System.Collections.Generic.List`1::Remove
02d864e4: bl      #0x2b70db0                                 fn_2b70db0
02d864e8: mov     w8, #1                                     
02d864ec: strb    w8, [x21, #0x489]                          
02d864f0: cbz     x19, #0x2d86534                            
02d864f4: mov     x0, x19                                    
02d864f8: mov     x1, xzr                                    
02d864fc: bl      #0x5b339ec                                 UnityEngine.Component::get_gameObject
02d86500: cbz     x0, #0x2d86534                             
02d86504: mov     w1, wzr                                    
02d86508: mov     x2, xzr                                    
02d8650c: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d86510: ldr     x0, [x20, #0x40]                           ._musicChannels
02d86514: cbz     x0, #0x2d86534                             
02d86518: adrp    x8, #0x626d000                             
02d8651c: mov     x1, x19                                    
02d86520: ldr     x8, [x8, #0x2c0]                           MS:System.Collections.Generic.List`1::Remove
02d86524: ldp     x20, x19, [sp, #0x10]                      
02d86528: ldr     x2, [x8]                                   MS:System.Collections.Generic.List`1::.ctor
02d8652c: ldp     x30, x21, [sp], #0x20                      
02d86530: b       #0x35aa7b4                                 
02d86534: bl      #0x2b7105c                                 fn_2b7105c
## <Start>b__28_3(Framework.MusicChannel channel) -> void
---- Framework.AudioManager::<Start>b__28_3 0x2d86538
02d86538: stp     x30, x21, [sp, #-0x20]!                    
02d8653c: stp     x20, x19, [sp, #0x10]                      
02d86540: adrp    x21, #0x6630000                            
02d86544: mov     x19, x1                                    
02d86548: mov     x20, x0                                    
02d8654c: ldrb    w8, [x21, #0x48a]                          
02d86550: tbnz    w8, #0, #0x2d86574                         
02d86554: adrp    x0, #0x626d000                             
02d86558: ldr     x0, [x0, #0x2c0]                           MS:System.Collections.Generic.List`1::Remove
02d8655c: bl      #0x2b70db0                                 fn_2b70db0
02d86560: adrp    x0, #0x6263000                             
02d86564: ldr     x0, [x0, #0x918]                           T:UnityEngine.Object
02d86568: bl      #0x2b70db0                                 fn_2b70db0
02d8656c: mov     w8, #1                                     
02d86570: strb    w8, [x21, #0x48a]                          
02d86574: ldr     x0, [x20, #0x40]                           ._musicChannels
02d86578: cbz     x0, #0x2d865d4                             
02d8657c: adrp    x8, #0x626d000                             
02d86580: mov     x1, x19                                    
02d86584: ldr     x8, [x8, #0x2c0]                           MS:System.Collections.Generic.List`1::Remove
02d86588: ldr     x2, [x8]                                   MS:System.Collections.Generic.List`1::.ctor
02d8658c: bl      #0x35aa7b4                                 fn_35aa7b4
02d86590: cbz     x19, #0x2d865d4                            
02d86594: adrp    x20, #0x6263000                            
02d86598: mov     x0, x19                                    
02d8659c: mov     x1, xzr                                    
02d865a0: ldr     x20, [x20, #0x918]                         T:UnityEngine.Object
02d865a4: bl      #0x5b339ec                                 UnityEngine.Component::get_gameObject
02d865a8: ldr     x8, [x20]                                  &2c5bbd4(=a9bd7bfdd503233f)
02d865ac: mov     x19, x0                                    
02d865b0: ldr     w9, [x8, #0xe4]                            [626d0e4]=0 f=0,0
02d865b4: cbnz    w9, #0x2d865c0                             
02d865b8: mov     x0, x8                                     
02d865bc: bl      #0x2b70f30                                 fn_2b70f30
02d865c0: mov     x0, x19                                    
02d865c4: ldp     x20, x19, [sp, #0x10]                      
02d865c8: mov     x1, xzr                                    
02d865cc: ldp     x30, x21, [sp], #0x20                      
02d865d0: b       #0x5b3ca38                                 UnityEngine.Object::Destroy
02d865d4: bl      #0x2b7105c                                 fn_2b7105c
## <Start>b__28_4() -> Framework.SoundChannel
---- Framework.AudioManager::<Start>b__28_4 0x2d865d8
02d865d8: str     x30, [sp, #-0x30]!                         
02d865dc: stp     x22, x21, [sp, #0x10]                      
02d865e0: stp     x20, x19, [sp, #0x20]                      
02d865e4: adrp    x19, #0x6630000                            
02d865e8: adrp    x21, #0x6263000                            
02d865ec: mov     x20, x0                                    
02d865f0: ldrb    w8, [x19, #0x48b]                          
02d865f4: ldr     x21, [x21, #0x918]                         T:UnityEngine.Object
02d865f8: tbnz    w8, #0, #0x2d8661c                         
02d865fc: adrp    x0, #0x626d000                             
02d86600: ldr     x0, [x0, #0x2c8]                           MS:UnityEngine.Object::Instantiate
02d86604: bl      #0x2b70db0                                 fn_2b70db0
02d86608: adrp    x0, #0x6263000                             
02d8660c: ldr     x0, [x0, #0x918]                           T:UnityEngine.Object
02d86610: bl      #0x2b70db0                                 fn_2b70db0
02d86614: mov     w8, #1                                     
02d86618: strb    w8, [x19, #0x48b]                          
02d8661c: adrp    x22, #0x626d000                            
02d86620: mov     x0, x20                                    
02d86624: mov     x1, xzr                                    
02d86628: ldr     x22, [x22, #0x2c8]                         MS:UnityEngine.Object::Instantiate
02d8662c: ldr     x19, [x20, #0x38]                          ._soundChannelPrefab
02d86630: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02d86634: ldr     x8, [x21]                                  &2c5bbd4(=a9bd7bfdd503233f)
02d86638: mov     x20, x0                                    
02d8663c: ldr     w9, [x8, #0xe4]                            
02d86640: cbnz    w9, #0x2d8664c                             
02d86644: mov     x0, x8                                     
02d86648: bl      #0x2b70f30                                 fn_2b70f30
02d8664c: ldr     x2, [x22]                                  MS:System.Collections.Generic.List`1::.ctor
02d86650: mov     x0, x19                                    
02d86654: mov     x1, x20                                    
02d86658: ldp     x20, x19, [sp, #0x20]                      
02d8665c: ldp     x22, x21, [sp, #0x10]                      
02d86660: ldr     x30, [sp], #0x30                           
02d86664: b       #0x3275fcc                                 
## <Start>b__28_5(Framework.SoundChannel channel) -> void
---- Framework.AudioManager::<Start>b__28_5 0x2d86668
02d86668: stp     x30, x21, [sp, #-0x20]!                    
02d8666c: stp     x20, x19, [sp, #0x10]                      
02d86670: adrp    x21, #0x6630000                            
02d86674: mov     x19, x1                                    
02d86678: mov     x20, x0                                    
02d8667c: ldrb    w8, [x21, #0x48c]                          
02d86680: tbnz    w8, #0, #0x2d86698                         
02d86684: adrp    x0, #0x626d000                             
02d86688: ldr     x0, [x0, #0x2d0]                           MS:System.Collections.Generic.List`1::Add
02d8668c: bl      #0x2b70db0                                 fn_2b70db0
02d86690: mov     w8, #1                                     
02d86694: strb    w8, [x21, #0x48c]                          
02d86698: cbz     x19, #0x2d86730                            
02d8669c: mov     x0, x19                                    
02d866a0: mov     x1, xzr                                    
02d866a4: bl      #0x5b339ec                                 UnityEngine.Component::get_gameObject
02d866a8: cbz     x0, #0x2d86730                             
02d866ac: mov     w1, #1                                     
02d866b0: mov     x2, xzr                                    
02d866b4: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d866b8: ldr     x8, [x20, #0x48]                           ._soundChannels
02d866bc: cbz     x8, #0x2d86730                             
02d866c0: adrp    x10, #0x626d000                            
02d866c4: ldr     x10, [x10, #0x2d0]                         MS:System.Collections.Generic.List`1::Add
02d866c8: ldr     w11, [x8, #0x1c]                           
02d866cc: ldr     x9, [x8, #0x10]                            
02d866d0: ldr     x10, [x10]                                 MS:System.Collections.Generic.List`1::.ctor
02d866d4: add     w11, w11, #1                               
02d866d8: str     w11, [x8, #0x1c]                           
02d866dc: cbz     x9, #0x2d86730                             
02d866e0: ldrsw   x11, [x8, #0x18]                           
02d866e4: ldr     w12, [x9, #0x18]                           
02d866e8: cmp     w11, w12                                   
02d866ec: b.hs    #0x2d86710                                 
02d866f0: add     x0, x9, x11, lsl #3                        
02d866f4: mov     x1, x19                                    
02d866f8: add     w9, w11, #1                                
02d866fc: str     w9, [x8, #0x18]                            
02d86700: str     x19, [x0, #0x20]!                          ._musicClipList
02d86704: ldp     x20, x19, [sp, #0x10]                      
02d86708: ldp     x30, x21, [sp], #0x20                      
02d8670c: b       #0x2b70d54                                 
02d86710: ldr     x9, [x10, #0x20]                           T:Redcode.Demo.DestroyChildsWhere/<>c
02d86714: mov     x1, x19                                    
02d86718: mov     x0, x8                                     
02d8671c: ldp     x20, x19, [sp, #0x10]                      
02d86720: ldr     x9, [x9, #0xc0]                            
02d86724: ldr     x2, [x9, #0x70]                            
02d86728: ldp     x30, x21, [sp], #0x20                      
02d8672c: b       #0x35a920c                                 
02d86730: bl      #0x2b7105c                                 fn_2b7105c
## <Start>b__28_6(Framework.SoundChannel channel) -> void
---- Framework.AudioManager::<Start>b__28_6 0x2d86734
02d86734: stp     x30, x21, [sp, #-0x20]!                    
02d86738: stp     x20, x19, [sp, #0x10]                      
02d8673c: adrp    x21, #0x6630000                            
02d86740: mov     x19, x1                                    
02d86744: mov     x20, x0                                    
02d86748: ldrb    w8, [x21, #0x48d]                          
02d8674c: tbnz    w8, #0, #0x2d86764                         
02d86750: adrp    x0, #0x626d000                             
02d86754: ldr     x0, [x0, #0x2d8]                           MS:System.Collections.Generic.List`1::Remove
02d86758: bl      #0x2b70db0                                 fn_2b70db0
02d8675c: mov     w8, #1                                     
02d86760: strb    w8, [x21, #0x48d]                          
02d86764: cbz     x19, #0x2d867a8                            
02d86768: mov     x0, x19                                    
02d8676c: mov     x1, xzr                                    
02d86770: bl      #0x5b339ec                                 UnityEngine.Component::get_gameObject
02d86774: cbz     x0, #0x2d867a8                             
02d86778: mov     w1, wzr                                    
02d8677c: mov     x2, xzr                                    
02d86780: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d86784: ldr     x0, [x20, #0x48]                           ._soundChannels
02d86788: cbz     x0, #0x2d867a8                             
02d8678c: adrp    x8, #0x626d000                             
02d86790: mov     x1, x19                                    
02d86794: ldr     x8, [x8, #0x2d8]                           MS:System.Collections.Generic.List`1::Remove
02d86798: ldp     x20, x19, [sp, #0x10]                      
02d8679c: ldr     x2, [x8]                                   MS:System.Collections.Generic.List`1::.ctor
02d867a0: ldp     x30, x21, [sp], #0x20                      
02d867a4: b       #0x35aa7b4                                 
02d867a8: bl      #0x2b7105c                                 fn_2b7105c
## <Start>b__28_7(Framework.SoundChannel channel) -> void
---- Framework.AudioManager::<Start>b__28_7 0x2d867ac
02d867ac: stp     x30, x21, [sp, #-0x20]!                    
02d867b0: stp     x20, x19, [sp, #0x10]                      
02d867b4: adrp    x21, #0x6630000                            
02d867b8: mov     x19, x1                                    
02d867bc: mov     x20, x0                                    
02d867c0: ldrb    w8, [x21, #0x48e]                          
02d867c4: tbnz    w8, #0, #0x2d867e8                         
02d867c8: adrp    x0, #0x626d000                             
02d867cc: ldr     x0, [x0, #0x2d8]                           MS:System.Collections.Generic.List`1::Remove
02d867d0: bl      #0x2b70db0                                 fn_2b70db0
02d867d4: adrp    x0, #0x6263000                             
02d867d8: ldr     x0, [x0, #0x918]                           T:UnityEngine.Object
02d867dc: bl      #0x2b70db0                                 fn_2b70db0
02d867e0: mov     w8, #1                                     
02d867e4: strb    w8, [x21, #0x48e]                          
02d867e8: ldr     x0, [x20, #0x48]                           ._soundChannels
02d867ec: cbz     x0, #0x2d86848                             
02d867f0: adrp    x8, #0x626d000                             
02d867f4: mov     x1, x19                                    
02d867f8: ldr     x8, [x8, #0x2d8]                           MS:System.Collections.Generic.List`1::Remove
02d867fc: ldr     x2, [x8]                                   MS:System.Collections.Generic.List`1::.ctor
02d86800: bl      #0x35aa7b4                                 fn_35aa7b4
02d86804: cbz     x19, #0x2d86848                            
02d86808: adrp    x20, #0x6263000                            
02d8680c: mov     x0, x19                                    
02d86810: mov     x1, xzr                                    
02d86814: ldr     x20, [x20, #0x918]                         T:UnityEngine.Object
02d86818: bl      #0x5b339ec                                 UnityEngine.Component::get_gameObject
02d8681c: ldr     x8, [x20]                                  &2c5bbd4(=a9bd7bfdd503233f)
02d86820: mov     x19, x0                                    
02d86824: ldr     w9, [x8, #0xe4]                            [626d0e4]=0 f=0,0
02d86828: cbnz    w9, #0x2d86834                             
02d8682c: mov     x0, x8                                     
02d86830: bl      #0x2b70f30                                 fn_2b70f30
02d86834: mov     x0, x19                                    
02d86838: ldp     x20, x19, [sp, #0x10]                      
02d8683c: mov     x1, xzr                                    
02d86840: ldp     x30, x21, [sp], #0x20                      
02d86844: b       #0x5b3ca38                                 UnityEngine.Object::Destroy
02d86848: bl      #0x2b7105c                                 fn_2b7105c
