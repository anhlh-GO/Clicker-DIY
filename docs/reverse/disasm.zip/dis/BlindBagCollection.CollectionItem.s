#### CLASS BlindBagCollection.CollectionItem parent= System.ValueType
#   field Type                           BlindBagCollection.CollectionItemType              off=0x10 attr=6 
#   field ItemSprite                     UnityEngine.Sprite                                 off=0x18 attr=6 
#   field ID_Cached                      int                                                off=0x20 attr=6 
#   field ID_CachedAB                    int                                                off=0x24 attr=6 
