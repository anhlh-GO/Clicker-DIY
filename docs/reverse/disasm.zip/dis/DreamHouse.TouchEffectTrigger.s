#### CLASS DreamHouse.TouchEffectTrigger parent= UnityEngine.MonoBehaviour
#   field _canvas                        UnityEngine.Canvas                                 off=0x20 attr=1 SerializeField
#   field _touchEffect                   UnityEngine.ParticleSystem                         off=0x28 attr=1 SerializeField
## Update() -> void
---- DreamHouse.TouchEffectTrigger::Update 0x2d19474
02d19474: sub     sp, sp, #0x40                              
02d19478: stp     d9, d8, [sp, #0x10]                        
02d1947c: stp     x30, x21, [sp, #0x20]                      
02d19480: stp     x20, x19, [sp, #0x30]                      
02d19484: adrp    x20, #0x662f000                            
02d19488: mov     x19, x0                                    
02d1948c: ldrb    w8, [x20, #0xff6]                          
02d19490: tbnz    w8, #0, #0x2d194c0                         
02d19494: adrp    x0, #0x6266000                             
02d19498: ldr     x0, [x0, #0x938]                           MS:UnityEngine.InputSystem.InputControl`1::ReadValue
02d1949c: bl      #0x2b70db0                                 fn_2b70db0
02d194a0: adrp    x0, #0x6264000                             
02d194a4: ldr     x0, [x0, #0x790]                           T:UnityEngine.RectTransformUtility
02d194a8: bl      #0x2b70db0                                 fn_2b70db0
02d194ac: adrp    x0, #0x6264000                             
02d194b0: ldr     x0, [x0, #0x8f8]                           T:UnityEngine.RectTransform
02d194b4: bl      #0x2b70db0                                 fn_2b70db0
02d194b8: mov     w8, #1                                     
02d194bc: strb    w8, [x20, #0xff6]                          
02d194c0: adrp    x20, #0x662f000                            
02d194c4: str     xzr, [sp, #8]                              
02d194c8: ldrb    w8, [x20, #0xbd9]                          
02d194cc: cbnz    w8, #0x2d194e4                             
02d194d0: adrp    x0, #0x6266000                             
02d194d4: ldr     x0, [x0, #0x950]                           T:UnityEngine.InputSystem.Pointer
02d194d8: bl      #0x2b70db0                                 fn_2b70db0
02d194dc: mov     w8, #1                                     
02d194e0: strb    w8, [x20, #0xbd9]                          
02d194e4: adrp    x8, #0x6266000                             
02d194e8: ldr     x8, [x8, #0x950]                           T:UnityEngine.InputSystem.Pointer
02d194ec: ldr     x8, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d194f0: ldr     x8, [x8, #0xb8]                            S:'banner_native_refresh_time'
02d194f4: ldr     x20, [x8]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d194f8: cbz     x20, #0x2d195f0                            
02d194fc: ldr     x0, [x20, #0x1a8]                          [662f1a8]=600006c f=2.40744e-35,0
02d19500: cbz     x0, #0x2d19604                             
02d19504: mov     x1, xzr                                    
02d19508: bl      #0x55532f0                                 UnityEngine.InputSystem.Controls.ButtonControl::get_wasPressedThisFrame
02d1950c: tbz     w0, #0, #0x2d195f0                         
02d19510: ldr     x0, [x19, #0x20]                           ._canvas
02d19514: cbz     x0, #0x2d19604                             
02d19518: mov     x1, xzr                                    
02d1951c: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02d19520: ldr     x8, [x20, #0x188]                          [662f188]=600006a f=2.40744e-35,0
02d19524: cbz     x8, #0x2d19604                             
02d19528: adrp    x9, #0x6266000                             
02d1952c: mov     x20, x0                                    
02d19530: mov     x0, x8                                     
02d19534: ldr     x9, [x9, #0x938]                           MS:UnityEngine.InputSystem.InputControl`1::ReadValue
02d19538: ldr     x1, [x9]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d1953c: bl      #0x4a187c4                                 fn_4a187c4
02d19540: ldr     x0, [x19, #0x20]                           ._canvas
02d19544: cbz     x0, #0x2d19604                             
02d19548: mov     x1, xzr                                    
02d1954c: fmov    s8, s0                                     
02d19550: fmov    s9, s1                                     
02d19554: bl      #0x5e49698                                 UnityEngine.Canvas::get_worldCamera
02d19558: adrp    x8, #0x6264000                             
02d1955c: mov     x21, x0                                    
02d19560: ldr     x8, [x8, #0x790]                           T:UnityEngine.RectTransformUtility
02d19564: ldr     x8, [x8]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d19568: ldr     w9, [x8, #0xe4]                            [62640e4]=0 f=0,0
02d1956c: cbz     w9, #0x2d19590                             
02d19570: cbz     x20, #0x2d1959c                            
02d19574: adrp    x8, #0x6264000                             
02d19578: ldr     x8, [x8, #0x8f8]                           T:UnityEngine.RectTransform
02d1957c: ldr     x9, [x20]                                  &2b706c4(=eb01011ff9400808)
02d19580: ldr     x8, [x8]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d19584: cmp     x9, x8                                     
02d19588: csel    x0, x20, xzr, eq                           
02d1958c: b       #0x2d195a0                                 
02d19590: mov     x0, x8                                     
02d19594: bl      #0x2b70f30                                 fn_2b70f30
02d19598: cbnz    x20, #0x2d19574                            
02d1959c: mov     x0, xzr                                    
02d195a0: fmov    s0, s8                                     
02d195a4: fmov    s1, s9                                     
02d195a8: add     x2, sp, #8                                 
02d195ac: mov     x1, x21                                    
02d195b0: mov     x3, xzr                                    
02d195b4: bl      #0x5e47a80                                 UnityEngine.RectTransformUtility::ScreenPointToLocalPointInRectangle
02d195b8: ldr     x0, [x19, #0x28]                           ._touchEffect
02d195bc: cbz     x0, #0x2d19604                             
02d195c0: mov     x1, xzr                                    
02d195c4: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02d195c8: cbz     x0, #0x2d19604                             
02d195cc: movi    d2, #0000000000000000                      
02d195d0: ldp     s0, s1, [sp, #8]                           
02d195d4: mov     x1, xzr                                    
02d195d8: bl      #0x5b45cec                                 UnityEngine.Transform::set_localPosition
02d195dc: ldr     x0, [x19, #0x28]                           ._touchEffect
02d195e0: cbz     x0, #0x2d19604                             
02d195e4: mov     w1, #1                                     
02d195e8: mov     x2, xzr                                    
02d195ec: bl      #0x5bba808                                 UnityEngine.ParticleSystem::Play
02d195f0: ldp     x20, x19, [sp, #0x30]                      
02d195f4: ldp     x30, x21, [sp, #0x20]                      
02d195f8: ldp     d9, d8, [sp, #0x10]                        
02d195fc: add     sp, sp, #0x40                              
02d19600: ret                                                
02d19604: bl      #0x2b7105c                                 fn_2b7105c
## .ctor() -> void
---- DreamHouse.TouchEffectTrigger::.ctor 0x2d19608
02d19608: mov     x1, xzr                                    
02d1960c: b       #0x5b397b0                                 UnityEngine.MonoBehaviour::.ctor
