#### CLASS Clicker.IngameClickerScreen/<>c__DisplayClass14_0 parent= object
#   field onBtnNextClick                 System.Action                                      off=0x10 attr=6 
## .ctor() -> void
---- Clicker.IngameClickerScreen/<>c__DisplayClass14_0::.ctor 0x2d6b6b8
02d6b6b8: mov     x1, xzr                                    
02d6b6bc: b       #0x4e53e9c                                 System.Object::.ctor
## <RegisterButtonNextEvent>b__0() -> void
---- Clicker.IngameClickerScreen/<>c__DisplayClass14_0::<RegisterButtonNextEvent>b__0 0x2d6bddc
02d6bddc: ldr     x8, [x0, #0x10]                            .onBtnNextClick
02d6bde0: cbz     x8, #0x2d6bdf4                             
02d6bde4: ldr     x0, [x8, #0x40]                            
02d6bde8: ldr     x1, [x8, #0x28]                            
02d6bdec: ldr     x2, [x8, #0x18]                            
02d6bdf0: br      x2                                         
02d6bdf4: ret                                                
#### CLASS Clicker.IngameClickerScreen parent= ScreenBase
#   field _btnNext                       UnityEngine.UI.Button                              off=0x38 attr=1 SerializeField
#   field _btnHome                       UnityEngine.UI.Button                              off=0x40 attr=1 SerializeField
#   field _livestreamPanel               Livestream.LivestreamPanel                         off=0x48 attr=1 SerializeField
#   field _selectBaseKeycapPanel         Clicker.SelectBaseKeycapPanel                      off=0x50 attr=1 HeaderAttribute,SerializeField
#   field _printer3DUIContent            Clicker.Printer3DUIContent                         off=0x58 attr=1 HeaderAttribute,SerializeField
#   field _selectSwitchPanel             Clicker.SelectSwitchPanel                          off=0x60 attr=1 HeaderAttribute,SerializeField
#   field _selectKeycapPanel             Clicker.SelectKeycapPanel                          off=0x68 attr=1 HeaderAttribute,SerializeField
#   field _popupSelectColor              Clicker.PopupSelectColor                           off=0x70 attr=1 SerializeField
#   field _decorKeycapPanel              Clicker.DecorKeycapPanel                           off=0x78 attr=1 HeaderAttribute,SerializeField
#   field _selectKeychainPanel           Clicker.SelectKeychainPanel                        off=0x80 attr=1 HeaderAttribute,SerializeField
#   field _tfHandTutorial                UnityEngine.Transform                              off=0x88 attr=1 HeaderAttribute,SerializeField
#   field _onBtnNextClick                UnityEngine.Events.UnityEvent                      off=0x90 attr=1 
## OnInit(UIManager uiManager) -> void
---- Clicker.IngameClickerScreen::OnInit 0x2d6b25c
02d6b25c: str     x30, [sp, #-0x30]!                         
02d6b260: stp     x22, x21, [sp, #0x10]                      
02d6b264: stp     x20, x19, [sp, #0x20]                      
02d6b268: adrp    x21, #0x6630000                            
02d6b26c: mov     x20, x1                                    
02d6b270: mov     x19, x0                                    
02d6b274: ldrb    w8, [x21, #0x363]                          
02d6b278: tbnz    w8, #0, #0x2d6b2c0                         
02d6b27c: adrp    x0, #0x626c000                             
02d6b280: ldr     x0, [x0, #0x400]                           M:Clicker.IngameClickerScreen::OnBtnHomeClick
02d6b284: bl      #0x2b70db0                                 fn_2b70db0
02d6b288: adrp    x0, #0x626c000                             
02d6b28c: ldr     x0, [x0, #0x408]                           M:Clicker.IngameClickerScreen::<OnInit>b__12_0
02d6b290: bl      #0x2b70db0                                 fn_2b70db0
02d6b294: adrp    x0, #0x6266000                             
02d6b298: ldr     x0, [x0, #0xac0]                           MS:MonoSingleton`1::get_Instance
02d6b29c: bl      #0x2b70db0                                 fn_2b70db0
02d6b2a0: adrp    x0, #0x6265000                             
02d6b2a4: ldr     x0, [x0, #0x10]                            MS:MonoSingleton`1::get_Instance
02d6b2a8: bl      #0x2b70db0                                 fn_2b70db0
02d6b2ac: adrp    x0, #0x6265000                             
02d6b2b0: ldr     x0, [x0, #0x3f0]                           T:UnityEngine.Events.UnityAction
02d6b2b4: bl      #0x2b70db0                                 fn_2b70db0
02d6b2b8: mov     w8, #1                                     
02d6b2bc: strb    w8, [x21, #0x363]                          
02d6b2c0: mov     x0, x19                                    
02d6b2c4: mov     x1, x20                                    
02d6b2c8: mov     x2, xzr                                    
02d6b2cc: bl      #0x2cdd3c4                                 UIBase::OnInit
02d6b2d0: ldr     x0, [x19, #0x50]                           ._selectBaseKeycapPanel
02d6b2d4: cbz     x0, #0x2d6b474                             
02d6b2d8: mov     x1, x19                                    
02d6b2dc: str     x19, [x0, #0x58]!                          ._printer3DUIContent
02d6b2e0: bl      #0x2b70d54                                 fn_2b70d54
02d6b2e4: ldr     x0, [x19, #0x58]                           ._printer3DUIContent
02d6b2e8: cbz     x0, #0x2d6b474                             
02d6b2ec: mov     x1, x19                                    
02d6b2f0: mov     x2, xzr                                    
02d6b2f4: bl      #0x2d709dc                                 Clicker.Printer3DUIContent::Init
02d6b2f8: ldr     x0, [x19, #0x60]                           ._selectSwitchPanel
02d6b2fc: cbz     x0, #0x2d6b474                             
02d6b300: mov     x1, x19                                    
02d6b304: str     x19, [x0, #0x58]!                          ._printer3DUIContent
02d6b308: bl      #0x2b70d54                                 fn_2b70d54
02d6b30c: ldr     x0, [x19, #0x68]                           ._selectKeycapPanel
02d6b310: cbz     x0, #0x2d6b474                             
02d6b314: mov     x1, x19                                    
02d6b318: str     x19, [x0, #0x58]!                          ._printer3DUIContent
02d6b31c: bl      #0x2b70d54                                 fn_2b70d54
02d6b320: ldr     x0, [x19, #0x70]                           ._popupSelectColor
02d6b324: cbz     x0, #0x2d6b474                             
02d6b328: mov     x1, x19                                    
02d6b32c: mov     x2, xzr                                    
02d6b330: bl      #0x2d704c8                                 Clicker.PopupSelectColor::Init
02d6b334: ldr     x0, [x19, #0x78]                           ._decorKeycapPanel
02d6b338: cbz     x0, #0x2d6b474                             
02d6b33c: mov     x1, x19                                    
02d6b340: str     x19, [x0, #0x80]!                          ._selectKeychainPanel
02d6b344: bl      #0x2b70d54                                 fn_2b70d54
02d6b348: ldr     x0, [x19, #0x80]                           ._selectKeychainPanel
02d6b34c: cbz     x0, #0x2d6b474                             
02d6b350: mov     x1, x19                                    
02d6b354: str     x19, [x0, #0x58]!                          ._printer3DUIContent
02d6b358: bl      #0x2b70d54                                 fn_2b70d54
02d6b35c: ldr     x8, [x19, #0x38]                           ._btnNext
02d6b360: cbz     x8, #0x2d6b474                             
02d6b364: ldr     x0, [x8, #0x100]                           
02d6b368: cbz     x0, #0x2d6b474                             
02d6b36c: mov     x1, xzr                                    
02d6b370: bl      #0x5b4ce48                                 UnityEngine.Events.UnityEventBase::RemoveAllListeners
02d6b374: ldr     x8, [x19, #0x38]                           ._btnNext
02d6b378: cbz     x8, #0x2d6b474                             
02d6b37c: adrp    x22, #0x6265000                            
02d6b380: adrp    x21, #0x626c000                            
02d6b384: ldr     x22, [x22, #0x3f0]                         T:UnityEngine.Events.UnityAction
02d6b388: ldr     x21, [x21, #0x408]                         M:Clicker.IngameClickerScreen::<OnInit>b__12_0
02d6b38c: ldr     x20, [x8, #0x100]                          
02d6b390: ldr     x0, [x22]                                  M:AdsManager::<OnApplicationPause>b__26_0
02d6b394: bl      #0x2b7104c                                 fn_2b7104c
02d6b398: ldr     x2, [x21]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d6b39c: mov     x1, x19                                    
02d6b3a0: mov     x3, xzr                                    
02d6b3a4: mov     x21, x0                                    
02d6b3a8: bl      #0x5b4cf98                                 UnityEngine.Events.UnityAction::.ctor
02d6b3ac: cbz     x20, #0x2d6b474                            
02d6b3b0: mov     x0, x20                                    
02d6b3b4: mov     x1, x21                                    
02d6b3b8: mov     x2, xzr                                    
02d6b3bc: bl      #0x5b4d0ac                                 UnityEngine.Events.UnityEvent::AddListener
02d6b3c0: ldr     x8, [x19, #0x40]                           ._btnHome
02d6b3c4: cbz     x8, #0x2d6b474                             
02d6b3c8: ldr     x0, [x8, #0x100]                           
02d6b3cc: cbz     x0, #0x2d6b474                             
02d6b3d0: mov     x1, xzr                                    
02d6b3d4: bl      #0x5b4ce48                                 UnityEngine.Events.UnityEventBase::RemoveAllListeners
02d6b3d8: ldr     x8, [x19, #0x40]                           ._btnHome
02d6b3dc: cbz     x8, #0x2d6b474                             
02d6b3e0: adrp    x21, #0x626c000                            
02d6b3e4: ldr     x21, [x21, #0x400]                         M:Clicker.IngameClickerScreen::OnBtnHomeClick
02d6b3e8: ldr     x0, [x22]                                  M:AdsManager::<OnApplicationPause>b__26_0
02d6b3ec: ldr     x20, [x8, #0x100]                          
02d6b3f0: bl      #0x2b7104c                                 fn_2b7104c
02d6b3f4: ldr     x2, [x21]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d6b3f8: mov     x1, x19                                    
02d6b3fc: mov     x3, xzr                                    
02d6b400: mov     x21, x0                                    
02d6b404: bl      #0x5b4cf98                                 UnityEngine.Events.UnityAction::.ctor
02d6b408: cbz     x20, #0x2d6b474                            
02d6b40c: mov     x0, x20                                    
02d6b410: mov     x1, x21                                    
02d6b414: mov     x2, xzr                                    
02d6b418: bl      #0x5b4d0ac                                 UnityEngine.Events.UnityEvent::AddListener
02d6b41c: ldr     x0, [x19, #0x48]                           ._livestreamPanel
02d6b420: cbz     x0, #0x2d6b474                             
02d6b424: adrp    x19, #0x6266000                            
02d6b428: mov     x1, xzr                                    
02d6b42c: ldr     x19, [x19, #0xac0]                         MS:MonoSingleton`1::get_Instance
02d6b430: bl      #0x2d11b9c                                 Livestream.LivestreamPanel::Initialized
02d6b434: ldr     x0, [x19]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d6b438: bl      #0x3769600                                 fn_3769600
02d6b43c: cbz     x0, #0x2d6b474                             
02d6b440: adrp    x19, #0x6265000                            
02d6b444: mov     w1, wzr                                    
02d6b448: mov     x2, xzr                                    
02d6b44c: ldr     x19, [x19, #0x10]                          MS:MonoSingleton`1::get_Instance
02d6b450: bl      #0x2cacd8c                                 GameSession::SetActiveCharacter
02d6b454: ldr     x0, [x19]                                  M:AdsManager::<OnApplicationPause>b__26_0
02d6b458: bl      #0x3769600                                 fn_3769600
02d6b45c: cbz     x0, #0x2d6b474                             
02d6b460: ldp     x20, x19, [sp, #0x20]                      
02d6b464: mov     x1, xzr                                    
02d6b468: ldp     x22, x21, [sp, #0x10]                      
02d6b46c: ldr     x30, [sp], #0x30                           
02d6b470: b       #0x2cdff7c                                 SimpleSceneTransition::FadeOut
02d6b474: bl      #0x2b7105c                                 fn_2b7105c
## OnShow() -> void
---- Clicker.IngameClickerScreen::OnShow 0x2d6b478
02d6b478: str     d8, [sp, #-0x50]!                          
02d6b47c: stp     x30, x25, [sp, #0x10]                      
02d6b480: stp     x24, x23, [sp, #0x20]                      
02d6b484: stp     x22, x21, [sp, #0x30]                      
02d6b488: stp     x20, x19, [sp, #0x40]                      
02d6b48c: adrp    x21, #0x6630000                            
02d6b490: adrp    x20, #0x6266000                            
02d6b494: mov     x19, x0                                    
02d6b498: ldrb    w8, [x21, #0x364]                          
02d6b49c: ldr     x20, [x20, #0x658]                         MS:MonoSingleton`1::get_Instance
02d6b4a0: tbnz    w8, #0, #0x2d6b4e8                         
02d6b4a4: adrp    x0, #0x6266000                             
02d6b4a8: ldr     x0, [x0, #0x750]                           MS:DataManager::GetData
02d6b4ac: bl      #0x2b70db0                                 fn_2b70db0
02d6b4b0: adrp    x0, #0x6265000                             
02d6b4b4: ldr     x0, [x0, #0xb38]                           T:DevTrack
02d6b4b8: bl      #0x2b70db0                                 fn_2b70db0
02d6b4bc: adrp    x0, #0x6266000                             
02d6b4c0: ldr     x0, [x0, #0x658]                           MS:MonoSingleton`1::get_Instance
02d6b4c4: bl      #0x2b70db0                                 fn_2b70db0
02d6b4c8: adrp    x0, #0x6266000                             
02d6b4cc: ldr     x0, [x0, #0xb48]                           MS:MonoSingleton`1::get_Instance
02d6b4d0: bl      #0x2b70db0                                 fn_2b70db0
02d6b4d4: adrp    x0, #0x6263000                             
02d6b4d8: ldr     x0, [x0, #0x918]                           T:UnityEngine.Object
02d6b4dc: bl      #0x2b70db0                                 fn_2b70db0
02d6b4e0: mov     w8, #1                                     
02d6b4e4: strb    w8, [x21, #0x364]                          
02d6b4e8: mov     x0, x19                                    
02d6b4ec: mov     x1, xzr                                    
02d6b4f0: bl      #0x2cdd6b8                                 UIBase::OnShow
02d6b4f4: ldr     x0, [x20]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d6b4f8: bl      #0x3769600                                 fn_3769600
02d6b4fc: cbz     x0, #0x2d6b6b4                             
02d6b500: adrp    x8, #0x6266000                             
02d6b504: ldr     x8, [x8, #0x750]                           MS:DataManager::GetData
02d6b508: ldr     x1, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d6b50c: bl      #0x3168dd0                                 fn_3168dd0
02d6b510: cbz     x0, #0x2d6b6b4                             
02d6b514: ldr     x8, [x0, #0x20]                            &2c5bd40(=14c8d27fd503245f)
02d6b518: cbz     x8, #0x2d6b6b4                             
02d6b51c: ldrb    w8, [x8, #0x3a]                            
02d6b520: cbz     w8, #0x2d6b544                             
02d6b524: ldr     x0, [x19, #0x40]                           ._btnHome
02d6b528: cbz     x0, #0x2d6b6b4                             
02d6b52c: mov     x1, xzr                                    
02d6b530: bl      #0x5b339ec                                 UnityEngine.Component::get_gameObject
02d6b534: cbz     x0, #0x2d6b6b4                             
02d6b538: mov     w1, wzr                                    
02d6b53c: mov     x2, xzr                                    
02d6b540: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d6b544: ldr     x0, [x19, #0x50]                           ._selectBaseKeycapPanel
02d6b548: cbz     x0, #0x2d6b6b4                             
02d6b54c: adrp    x24, #0x6266000                            
02d6b550: mov     x1, xzr                                    
02d6b554: ldr     x24, [x24, #0xb48]                         MS:MonoSingleton`1::get_Instance
02d6b558: bl      #0x2d71ca4                                 Clicker.SelectBaseKeycapPanel::ShowPanel
02d6b55c: ldr     x0, [x24]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d6b560: bl      #0x3769600                                 fn_3769600
02d6b564: cbz     x0, #0x2d6b6b4                             
02d6b568: ldr     x20, [x0, #0x30]                           &16c9019(=424f4c475f32314e)
02d6b56c: ldr     x0, [x24]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d6b570: bl      #0x3769600                                 fn_3769600
02d6b574: cbz     x0, #0x2d6b6b4                             
02d6b578: adrp    x25, #0x6265000                            
02d6b57c: mov     x8, x0                                     
02d6b580: ldr     x25, [x25, #0xb38]                         T:DevTrack
02d6b584: ldr     w21, [x8, #0x3c]                           [626603c]=0 f=0,0
02d6b588: ldr     x0, [x25]                                  M:AdsManager::<OnApplicationPause>b__26_0
02d6b58c: ldr     w9, [x0, #0xe4]                            [62630e4]=0 f=0,0
02d6b590: cbnz    w9, #0x2d6b59c                             
02d6b594: bl      #0x2b70f30                                 fn_2b70f30
02d6b598: ldr     x0, [x25]                                  M:AdsManager::<OnApplicationPause>b__26_0
02d6b59c: ldr     x8, [x0, #0xb8]                            &6263108(=0)
02d6b5a0: mov     x0, xzr                                    
02d6b5a4: ldr     x22, [x8, #0x218]                          MS:System.Collections.Generic.List`1::.ctor
02d6b5a8: ldr     w23, [x8, #0x270]                          MS:System.Collections.Generic.List`1::GetEnumerator
02d6b5ac: bl      #0x5b432fc                                 UnityEngine.Time::get_time
02d6b5b0: ldr     x0, [x24]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d6b5b4: fmov    s8, s0                                     
02d6b5b8: bl      #0x3769600                                 fn_3769600
02d6b5bc: cbz     x0, #0x2d6b6b4                             
02d6b5c0: ldr     s0, [x0, #0x38]                            &6260bd8(=0) ._btnNext
02d6b5c4: mov     x0, x20                                    
02d6b5c8: mov     w1, w21                                    
02d6b5cc: mov     x2, x22                                    
02d6b5d0: mov     w3, w23                                    
02d6b5d4: mov     x4, xzr                                    
02d6b5d8: fsub    s0, s8, s0                                 
02d6b5dc: bl      #0x2c9c898                                 DevTrack::GameModeStepComplete
02d6b5e0: ldr     x0, [x24]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d6b5e4: bl      #0x3769600                                 fn_3769600
02d6b5e8: cbz     x0, #0x2d6b6b4                             
02d6b5ec: ldr     x20, [x0, #0x30]                           &16c9019(=424f4c475f32314e)
02d6b5f0: ldr     x0, [x24]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d6b5f4: bl      #0x3769600                                 fn_3769600
02d6b5f8: cbz     x0, #0x2d6b6b4                             
02d6b5fc: ldr     x8, [x25]                                  M:AdsManager::<OnApplicationPause>b__26_0
02d6b600: ldr     w1, [x0, #0x3c]                            [626303c]=0 f=0,0
02d6b604: mov     x0, x20                                    
02d6b608: mov     x4, xzr                                    
02d6b60c: ldr     x8, [x8, #0xb8]                            S:'banner_native_refresh_time'
02d6b610: ldr     x2, [x8, #0x220]                           MS:System.Collections.Generic.List`1::get_Count
02d6b614: ldr     w3, [x8, #0x274]                           [6266274]=0 f=0,0
02d6b618: bl      #0x2c9c714                                 DevTrack::GameModeStepEnter
02d6b61c: ldr     x0, [x24]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d6b620: bl      #0x3769600                                 fn_3769600
02d6b624: cbz     x0, #0x2d6b6b4                             
02d6b628: ldr     x8, [x25]                                  M:AdsManager::<OnApplicationPause>b__26_0
02d6b62c: adrp    x20, #0x6263000                            
02d6b630: ldr     x8, [x8, #0xb8]                            S:'banner_native_refresh_time'
02d6b634: ldr     x1, [x8, #0x220]                           MS:System.Collections.Generic.List`1::get_Count
02d6b638: ldr     x20, [x20, #0x918]                         T:UnityEngine.Object
02d6b63c: str     x1, [x0, #0x40]!                           ._btnHome
02d6b640: bl      #0x2b70d54                                 fn_2b70d54
02d6b644: mov     x0, x19                                    
02d6b648: mov     w1, wzr                                    
02d6b64c: bl      #0x2d6519c                                 Clicker.IngameClickerScreen::ShowBtnNext
02d6b650: ldr     x0, [x20]                                  &2c5bbd4(=a9bd7bfdd503233f)
02d6b654: ldr     x20, [x19, #0x48]                          ._livestreamPanel
02d6b658: ldr     w8, [x0, #0xe4]                            [62630e4]=0 f=0,0
02d6b65c: cbnz    w8, #0x2d6b664                             
02d6b660: bl      #0x2b70f30                                 fn_2b70f30
02d6b664: mov     x0, x20                                    
02d6b668: mov     x1, xzr                                    
02d6b66c: mov     x2, xzr                                    
02d6b670: bl      #0x5b3666c                                 UnityEngine.Object::op_Inequality
02d6b674: tbz     w0, #0, #0x2d6b69c                         
02d6b678: ldr     x0, [x19, #0x48]                           ._livestreamPanel
02d6b67c: cbz     x0, #0x2d6b69c                             
02d6b680: ldp     x20, x19, [sp, #0x40]                      
02d6b684: mov     x1, xzr                                    
02d6b688: ldp     x22, x21, [sp, #0x30]                      
02d6b68c: ldp     x24, x23, [sp, #0x20]                      
02d6b690: ldp     x30, x25, [sp, #0x10]                      
02d6b694: ldr     d8, [sp], #0x50                            
02d6b698: b       #0x2d11ba0                                 Livestream.LivestreamPanel::OnShow
02d6b69c: ldp     x20, x19, [sp, #0x40]                      
02d6b6a0: ldp     x22, x21, [sp, #0x30]                      
02d6b6a4: ldp     x24, x23, [sp, #0x20]                      
02d6b6a8: ldp     x30, x25, [sp, #0x10]                      
02d6b6ac: ldr     d8, [sp], #0x50                            
02d6b6b0: ret                                                
02d6b6b4: bl      #0x2b7105c                                 fn_2b7105c
## RegisterButtonNextEvent(System.Action onBtnNextClick) -> void
---- Clicker.IngameClickerScreen::RegisterButtonNextEvent 0x2d69948
02d69948: str     x30, [sp, #-0x30]!                         
02d6994c: stp     x22, x21, [sp, #0x10]                      
02d69950: stp     x20, x19, [sp, #0x20]                      
02d69954: adrp    x21, #0x6630000                            
02d69958: adrp    x22, #0x626c000                            
02d6995c: mov     x20, x1                                    
02d69960: ldrb    w8, [x21, #0x365]                          
02d69964: ldr     x22, [x22, #0x368]                         T:Clicker.IngameClickerScreen/<>c__DisplayClass14_0
02d69968: mov     x19, x0                                    
02d6996c: tbnz    w8, #0, #0x2d6999c                         
02d69970: adrp    x0, #0x626c000                             
02d69974: ldr     x0, [x0, #0x370]                           M:Clicker.IngameClickerScreen/<>c__DisplayClass14_0::<RegisterButtonNextEvent>b__0
02d69978: bl      #0x2b70db0                                 fn_2b70db0
02d6997c: adrp    x0, #0x626c000                             
02d69980: ldr     x0, [x0, #0x368]                           T:Clicker.IngameClickerScreen/<>c__DisplayClass14_0
02d69984: bl      #0x2b70db0                                 fn_2b70db0
02d69988: adrp    x0, #0x6265000                             
02d6998c: ldr     x0, [x0, #0x3f0]                           T:UnityEngine.Events.UnityAction
02d69990: bl      #0x2b70db0                                 fn_2b70db0
02d69994: mov     w8, #1                                     
02d69998: strb    w8, [x21, #0x365]                          
02d6999c: ldr     x0, [x22]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d699a0: bl      #0x2b7104c                                 fn_2b7104c
02d699a4: mov     x1, xzr                                    
02d699a8: mov     x21, x0                                    
02d699ac: bl      #0x4e53e9c                                 System.Object::.ctor
02d699b0: cbz     x21, #0x2d69a24                            
02d699b4: mov     x0, x21                                    
02d699b8: mov     x1, x20                                    
02d699bc: str     x20, [x0, #0x10]!                          
02d699c0: bl      #0x2b70d54                                 fn_2b70d54
02d699c4: ldr     x0, [x19, #0x90]                           ._onBtnNextClick
02d699c8: cbz     x0, #0x2d69a24                             
02d699cc: adrp    x20, #0x6265000                            
02d699d0: adrp    x22, #0x626c000                            
02d699d4: mov     x1, xzr                                    
02d699d8: ldr     x20, [x20, #0x3f0]                         T:UnityEngine.Events.UnityAction
02d699dc: ldr     x22, [x22, #0x370]                         M:Clicker.IngameClickerScreen/<>c__DisplayClass14_0::<RegisterButtonNextEvent>b__0
02d699e0: bl      #0x5b4ce48                                 UnityEngine.Events.UnityEventBase::RemoveAllListeners
02d699e4: ldr     x0, [x20]                                  M:AdsManager::<OnApplicationPause>b__26_0
02d699e8: ldr     x19, [x19, #0x90]                          ._onBtnNextClick
02d699ec: bl      #0x2b7104c                                 fn_2b7104c
02d699f0: ldr     x2, [x22]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d699f4: mov     x1, x21                                    
02d699f8: mov     x3, xzr                                    
02d699fc: mov     x20, x0                                    
02d69a00: bl      #0x5b4cf98                                 UnityEngine.Events.UnityAction::.ctor
02d69a04: cbz     x19, #0x2d69a24                            
02d69a08: mov     x0, x19                                    
02d69a0c: mov     x1, x20                                    
02d69a10: mov     x2, xzr                                    
02d69a14: ldp     x20, x19, [sp, #0x20]                      
02d69a18: ldp     x22, x21, [sp, #0x10]                      
02d69a1c: ldr     x30, [sp], #0x30                           
02d69a20: b       #0x5b4d0ac                                 UnityEngine.Events.UnityEvent::AddListener
02d69a24: bl      #0x2b7105c                                 fn_2b7105c
## ShowBtnNext(bool isShow) -> void
---- Clicker.IngameClickerScreen::ShowBtnNext 0x2d6519c
02d6519c: stp     x30, x19, [sp, #-0x10]!                    
02d651a0: ldr     x0, [x0, #0x38]                            ._btnNext
02d651a4: cbz     x0, #0x2d651c8                             
02d651a8: mov     w19, w1                                    
02d651ac: mov     x1, xzr                                    
02d651b0: bl      #0x5b339ec                                 UnityEngine.Component::get_gameObject
02d651b4: cbz     x0, #0x2d651c8                             
02d651b8: and     w1, w19, #1                                
02d651bc: mov     x2, xzr                                    
02d651c0: ldp     x30, x19, [sp], #0x10                      
02d651c4: b       #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d651c8: bl      #0x2b7105c                                 fn_2b7105c
## SetBtnNextPosition(UnityEngine.Vector3 pos) -> void
---- Clicker.IngameClickerScreen::SetBtnNextPosition 0x2d69a28
02d69a28: str     d10, [sp, #-0x20]!                         
02d69a2c: stp     d9, d8, [sp, #8]                           
02d69a30: str     x30, [sp, #0x18]                           
02d69a34: ldr     x0, [x0, #0x38]                            ._btnNext
02d69a38: cbz     x0, #0x2d69a74                             
02d69a3c: mov     x1, xzr                                    
02d69a40: fmov    s8, s2                                     
02d69a44: fmov    s9, s1                                     
02d69a48: fmov    s10, s0                                    
02d69a4c: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02d69a50: cbz     x0, #0x2d69a74                             
02d69a54: fmov    s1, s9                                     
02d69a58: fmov    s2, s8                                     
02d69a5c: ldr     x30, [sp, #0x18]                           
02d69a60: ldp     d9, d8, [sp, #8]                           
02d69a64: fmov    s0, s10                                    
02d69a68: mov     x1, xzr                                    
02d69a6c: ldr     d10, [sp], #0x20                           
02d69a70: b       #0x5b46888                                 UnityEngine.Transform::set_position
02d69a74: bl      #0x2b7105c                                 fn_2b7105c
## GoToStepPrinter() -> void
---- Clicker.IngameClickerScreen::GoToStepPrinter 0x2d6b6c0
02d6b6c0: str     d8, [sp, #-0x40]!                          
02d6b6c4: str     x30, [sp, #8]                              
02d6b6c8: stp     x24, x23, [sp, #0x10]                      
02d6b6cc: stp     x22, x21, [sp, #0x20]                      
02d6b6d0: stp     x20, x19, [sp, #0x30]                      
02d6b6d4: adrp    x20, #0x6630000                            
02d6b6d8: adrp    x21, #0x6265000                            
02d6b6dc: mov     x19, x0                                    
02d6b6e0: ldrb    w8, [x20, #0x366]                          
02d6b6e4: ldr     x21, [x21, #0x310]                         MS:WejoyService.Singleton`1::get_Instance
02d6b6e8: tbnz    w8, #0, #0x2d6b718                         
02d6b6ec: adrp    x0, #0x6265000                             
02d6b6f0: ldr     x0, [x0, #0xb38]                           T:DevTrack
02d6b6f4: bl      #0x2b70db0                                 fn_2b70db0
02d6b6f8: adrp    x0, #0x6266000                             
02d6b6fc: ldr     x0, [x0, #0xb48]                           MS:MonoSingleton`1::get_Instance
02d6b700: bl      #0x2b70db0                                 fn_2b70db0
02d6b704: adrp    x0, #0x6265000                             
02d6b708: ldr     x0, [x0, #0x310]                           MS:WejoyService.Singleton`1::get_Instance
02d6b70c: bl      #0x2b70db0                                 fn_2b70db0
02d6b710: mov     w8, #1                                     
02d6b714: strb    w8, [x20, #0x366]                          
02d6b718: ldr     x0, [x21]                                  M:AdsManager::<OnApplicationPause>b__26_0
02d6b71c: bl      #0x3be7218                                 fn_3be7218
02d6b720: cbz     x0, #0x2d6b838                             
02d6b724: mov     x1, xzr                                    
02d6b728: bl      #0x2c8a7a4                                 AdsManager::ShowCollap
02d6b72c: ldr     x0, [x19, #0x58]                           ._printer3DUIContent
02d6b730: cbz     x0, #0x2d6b838                             
02d6b734: adrp    x23, #0x6266000                            
02d6b738: mov     x1, xzr                                    
02d6b73c: ldr     x23, [x23, #0xb48]                         MS:MonoSingleton`1::get_Instance
02d6b740: bl      #0x2d70ac0                                 Clicker.Printer3DUIContent::ShowContent
02d6b744: ldr     x0, [x23]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d6b748: bl      #0x3769600                                 fn_3769600
02d6b74c: cbz     x0, #0x2d6b838                             
02d6b750: ldr     x19, [x0, #0x30]                           T:AdsManager/<>c__DisplayClass32_0
02d6b754: ldr     x0, [x23]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d6b758: bl      #0x3769600                                 fn_3769600
02d6b75c: cbz     x0, #0x2d6b838                             
02d6b760: adrp    x24, #0x6265000                            
02d6b764: mov     x8, x0                                     
02d6b768: ldr     x24, [x24, #0xb38]                         T:DevTrack
02d6b76c: ldr     w20, [x8, #0x3c]                           
02d6b770: ldr     x0, [x24]                                  M:AdsManager::<OnApplicationPause>b__26_0
02d6b774: ldr     w9, [x0, #0xe4]                            [62650e4]=0 f=0,0
02d6b778: cbnz    w9, #0x2d6b784                             
02d6b77c: bl      #0x2b70f30                                 fn_2b70f30
02d6b780: ldr     x0, [x24]                                  M:AdsManager::<OnApplicationPause>b__26_0
02d6b784: ldr     x8, [x0, #0xb8]                            T:AdsManager/<>c__DisplayClass42_0
02d6b788: mov     x0, xzr                                    
02d6b78c: ldr     x21, [x8, #0x220]                          
02d6b790: ldr     w22, [x8, #0x274]                          
02d6b794: bl      #0x5b432fc                                 UnityEngine.Time::get_time
02d6b798: ldr     x0, [x23]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d6b79c: fmov    s8, s0                                     
02d6b7a0: bl      #0x3769600                                 fn_3769600
02d6b7a4: cbz     x0, #0x2d6b838                             
02d6b7a8: ldr     s0, [x0, #0x38]                            M:AdsManager/<>c__DisplayClass32_0::<ShowAppOpenLoading>g__OnComplete|0 ._btnNext
02d6b7ac: mov     x0, x19                                    
02d6b7b0: mov     w1, w20                                    
02d6b7b4: mov     x2, x21                                    
02d6b7b8: mov     w3, w22                                    
02d6b7bc: mov     x4, xzr                                    
02d6b7c0: fsub    s0, s8, s0                                 
02d6b7c4: bl      #0x2c9c898                                 DevTrack::GameModeStepComplete
02d6b7c8: ldr     x0, [x23]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d6b7cc: bl      #0x3769600                                 fn_3769600
02d6b7d0: cbz     x0, #0x2d6b838                             
02d6b7d4: ldr     x19, [x0, #0x30]                           T:AdsManager/<>c__DisplayClass32_0
02d6b7d8: ldr     x0, [x23]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d6b7dc: bl      #0x3769600                                 fn_3769600
02d6b7e0: cbz     x0, #0x2d6b838                             
02d6b7e4: ldr     x8, [x24]                                  M:AdsManager::<OnApplicationPause>b__26_0
02d6b7e8: ldr     w1, [x0, #0x3c]                            [626503c]=0 f=0,0
02d6b7ec: mov     x0, x19                                    
02d6b7f0: mov     x4, xzr                                    
02d6b7f4: ldr     x8, [x8, #0xb8]                            
02d6b7f8: ldr     x2, [x8, #0x228]                           
02d6b7fc: ldr     w3, [x8, #0x278]                           
02d6b800: bl      #0x2c9c714                                 DevTrack::GameModeStepEnter
02d6b804: ldr     x0, [x23]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d6b808: bl      #0x3769600                                 fn_3769600
02d6b80c: cbz     x0, #0x2d6b838                             
02d6b810: ldr     x8, [x24]                                  M:AdsManager::<OnApplicationPause>b__26_0
02d6b814: ldp     x20, x19, [sp, #0x30]                      
02d6b818: ldp     x22, x21, [sp, #0x20]                      
02d6b81c: ldr     x30, [sp, #8]                              
02d6b820: ldr     x8, [x8, #0xb8]                            
02d6b824: ldp     x24, x23, [sp, #0x10]                      
02d6b828: ldr     x1, [x8, #0x228]                           
02d6b82c: str     x1, [x0, #0x40]!                           ._btnHome
02d6b830: ldr     d8, [sp], #0x40                            
02d6b834: b       #0x2b70d54                                 
02d6b838: bl      #0x2b7105c                                 fn_2b7105c
## GoToStepSwitch() -> void
---- Clicker.IngameClickerScreen::GoToStepSwitch 0x2d6b83c
02d6b83c: str     d8, [sp, #-0x40]!                          
02d6b840: str     x30, [sp, #8]                              
02d6b844: stp     x24, x23, [sp, #0x10]                      
02d6b848: stp     x22, x21, [sp, #0x20]                      
02d6b84c: stp     x20, x19, [sp, #0x30]                      
02d6b850: adrp    x20, #0x6630000                            
02d6b854: mov     x19, x0                                    
02d6b858: ldrb    w8, [x20, #0x367]                          
02d6b85c: tbnz    w8, #0, #0x2d6b880                         
02d6b860: adrp    x0, #0x6265000                             
02d6b864: ldr     x0, [x0, #0xb38]                           T:DevTrack
02d6b868: bl      #0x2b70db0                                 fn_2b70db0
02d6b86c: adrp    x0, #0x6266000                             
02d6b870: ldr     x0, [x0, #0xb48]                           MS:MonoSingleton`1::get_Instance
02d6b874: bl      #0x2b70db0                                 fn_2b70db0
02d6b878: mov     w8, #1                                     
02d6b87c: strb    w8, [x20, #0x367]                          
02d6b880: ldr     x0, [x19, #0x60]                           ._selectSwitchPanel
02d6b884: cbz     x0, #0x2d6b98c                             
02d6b888: adrp    x23, #0x6266000                            
02d6b88c: mov     x1, xzr                                    
02d6b890: ldr     x23, [x23, #0xb48]                         MS:MonoSingleton`1::get_Instance
02d6b894: bl      #0x2d74080                                 Clicker.SelectSwitchPanel::ShowPanel
02d6b898: ldr     x0, [x23]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d6b89c: bl      #0x3769600                                 fn_3769600
02d6b8a0: cbz     x0, #0x2d6b98c                             
02d6b8a4: ldr     x19, [x0, #0x30]                           S:'popup_rate_on_off'
02d6b8a8: ldr     x0, [x23]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d6b8ac: bl      #0x3769600                                 fn_3769600
02d6b8b0: cbz     x0, #0x2d6b98c                             
02d6b8b4: adrp    x24, #0x6265000                            
02d6b8b8: mov     x8, x0                                     
02d6b8bc: ldr     x24, [x24, #0xb38]                         T:DevTrack
02d6b8c0: ldr     w20, [x8, #0x3c]                           
02d6b8c4: ldr     x0, [x24]                                  M:AdsManager::<OnApplicationPause>b__26_0
02d6b8c8: ldr     w9, [x0, #0xe4]                            [62660e4]=0 f=0,0
02d6b8cc: cbnz    w9, #0x2d6b8d8                             
02d6b8d0: bl      #0x2b70f30                                 fn_2b70f30
02d6b8d4: ldr     x0, [x24]                                  M:AdsManager::<OnApplicationPause>b__26_0
02d6b8d8: ldr     x8, [x0, #0xb8]                            S:'banner_native_refresh_time'
02d6b8dc: mov     x0, xzr                                    
02d6b8e0: ldr     x21, [x8, #0x228]                          
02d6b8e4: ldr     w22, [x8, #0x278]                          
02d6b8e8: bl      #0x5b432fc                                 UnityEngine.Time::get_time
02d6b8ec: ldr     x0, [x23]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d6b8f0: fmov    s8, s0                                     
02d6b8f4: bl      #0x3769600                                 fn_3769600
02d6b8f8: cbz     x0, #0x2d6b98c                             
02d6b8fc: ldr     s0, [x0, #0x38]                            S:'native_collap_id' ._btnNext
02d6b900: mov     x0, x19                                    
02d6b904: mov     w1, w20                                    
02d6b908: mov     x2, x21                                    
02d6b90c: mov     w3, w22                                    
02d6b910: mov     x4, xzr                                    
02d6b914: fsub    s0, s8, s0                                 
02d6b918: bl      #0x2c9c898                                 DevTrack::GameModeStepComplete
02d6b91c: ldr     x0, [x23]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d6b920: bl      #0x3769600                                 fn_3769600
02d6b924: cbz     x0, #0x2d6b98c                             
02d6b928: ldr     x19, [x0, #0x30]                           S:'popup_rate_on_off'
02d6b92c: ldr     x0, [x23]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d6b930: bl      #0x3769600                                 fn_3769600
02d6b934: cbz     x0, #0x2d6b98c                             
02d6b938: ldr     x8, [x24]                                  M:AdsManager::<OnApplicationPause>b__26_0
02d6b93c: ldr     w1, [x0, #0x3c]                            [626603c]=0 f=0,0
02d6b940: mov     x0, x19                                    
02d6b944: mov     x4, xzr                                    
02d6b948: ldr     x8, [x8, #0xb8]                            
02d6b94c: ldr     x2, [x8, #0x230]                           
02d6b950: ldr     w3, [x8, #0x27c]                           
02d6b954: bl      #0x2c9c714                                 DevTrack::GameModeStepEnter
02d6b958: ldr     x0, [x23]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d6b95c: bl      #0x3769600                                 fn_3769600
02d6b960: cbz     x0, #0x2d6b98c                             
02d6b964: ldr     x8, [x24]                                  M:AdsManager::<OnApplicationPause>b__26_0
02d6b968: ldp     x20, x19, [sp, #0x30]                      
02d6b96c: ldp     x22, x21, [sp, #0x20]                      
02d6b970: ldr     x30, [sp, #8]                              
02d6b974: ldr     x8, [x8, #0xb8]                            
02d6b978: ldp     x24, x23, [sp, #0x10]                      
02d6b97c: ldr     x1, [x8, #0x230]                           
02d6b980: str     x1, [x0, #0x40]!                           ._btnHome
02d6b984: ldr     d8, [sp], #0x40                            
02d6b988: b       #0x2b70d54                                 
02d6b98c: bl      #0x2b7105c                                 fn_2b7105c
## GoToStepKeycap() -> void
---- Clicker.IngameClickerScreen::GoToStepKeycap 0x2d6b990
02d6b990: str     d8, [sp, #-0x40]!                          
02d6b994: str     x30, [sp, #8]                              
02d6b998: stp     x24, x23, [sp, #0x10]                      
02d6b99c: stp     x22, x21, [sp, #0x20]                      
02d6b9a0: stp     x20, x19, [sp, #0x30]                      
02d6b9a4: adrp    x20, #0x6630000                            
02d6b9a8: mov     x19, x0                                    
02d6b9ac: ldrb    w8, [x20, #0x368]                          
02d6b9b0: tbnz    w8, #0, #0x2d6b9d4                         
02d6b9b4: adrp    x0, #0x6265000                             
02d6b9b8: ldr     x0, [x0, #0xb38]                           T:DevTrack
02d6b9bc: bl      #0x2b70db0                                 fn_2b70db0
02d6b9c0: adrp    x0, #0x6266000                             
02d6b9c4: ldr     x0, [x0, #0xb48]                           MS:MonoSingleton`1::get_Instance
02d6b9c8: bl      #0x2b70db0                                 fn_2b70db0
02d6b9cc: mov     w8, #1                                     
02d6b9d0: strb    w8, [x20, #0x368]                          
02d6b9d4: ldr     x0, [x19, #0x68]                           ._selectKeycapPanel
02d6b9d8: cbz     x0, #0x2d6bae0                             
02d6b9dc: adrp    x23, #0x6266000                            
02d6b9e0: mov     x1, xzr                                    
02d6b9e4: ldr     x23, [x23, #0xb48]                         MS:MonoSingleton`1::get_Instance
02d6b9e8: bl      #0x2d72818                                 Clicker.SelectKeycapPanel::ShowPanel
02d6b9ec: ldr     x0, [x23]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d6b9f0: bl      #0x3769600                                 fn_3769600
02d6b9f4: cbz     x0, #0x2d6bae0                             
02d6b9f8: ldr     x19, [x0, #0x30]                           S:'popup_rate_on_off'
02d6b9fc: ldr     x0, [x23]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d6ba00: bl      #0x3769600                                 fn_3769600
02d6ba04: cbz     x0, #0x2d6bae0                             
02d6ba08: adrp    x24, #0x6265000                            
02d6ba0c: mov     x8, x0                                     
02d6ba10: ldr     x24, [x24, #0xb38]                         T:DevTrack
02d6ba14: ldr     w20, [x8, #0x3c]                           
02d6ba18: ldr     x0, [x24]                                  M:AdsManager::<OnApplicationPause>b__26_0
02d6ba1c: ldr     w9, [x0, #0xe4]                            [62660e4]=0 f=0,0
02d6ba20: cbnz    w9, #0x2d6ba2c                             
02d6ba24: bl      #0x2b70f30                                 fn_2b70f30
02d6ba28: ldr     x0, [x24]                                  M:AdsManager::<OnApplicationPause>b__26_0
02d6ba2c: ldr     x8, [x0, #0xb8]                            S:'banner_native_refresh_time'
02d6ba30: mov     x0, xzr                                    
02d6ba34: ldr     x21, [x8, #0x230]                          
02d6ba38: ldr     w22, [x8, #0x27c]                          
02d6ba3c: bl      #0x5b432fc                                 UnityEngine.Time::get_time
02d6ba40: ldr     x0, [x23]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d6ba44: fmov    s8, s0                                     
02d6ba48: bl      #0x3769600                                 fn_3769600
02d6ba4c: cbz     x0, #0x2d6bae0                             
02d6ba50: ldr     s0, [x0, #0x38]                            S:'native_collap_id' ._btnNext
02d6ba54: mov     x0, x19                                    
02d6ba58: mov     w1, w20                                    
02d6ba5c: mov     x2, x21                                    
02d6ba60: mov     w3, w22                                    
02d6ba64: mov     x4, xzr                                    
02d6ba68: fsub    s0, s8, s0                                 
02d6ba6c: bl      #0x2c9c898                                 DevTrack::GameModeStepComplete
02d6ba70: ldr     x0, [x23]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d6ba74: bl      #0x3769600                                 fn_3769600
02d6ba78: cbz     x0, #0x2d6bae0                             
02d6ba7c: ldr     x19, [x0, #0x30]                           S:'popup_rate_on_off'
02d6ba80: ldr     x0, [x23]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d6ba84: bl      #0x3769600                                 fn_3769600
02d6ba88: cbz     x0, #0x2d6bae0                             
02d6ba8c: ldr     x8, [x24]                                  M:AdsManager::<OnApplicationPause>b__26_0
02d6ba90: ldr     w1, [x0, #0x3c]                            [626603c]=0 f=0,0
02d6ba94: mov     x0, x19                                    
02d6ba98: mov     x4, xzr                                    
02d6ba9c: ldr     x8, [x8, #0xb8]                            
02d6baa0: ldr     x2, [x8, #0x238]                           
02d6baa4: ldr     w3, [x8, #0x280]                           
02d6baa8: bl      #0x2c9c714                                 DevTrack::GameModeStepEnter
02d6baac: ldr     x0, [x23]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d6bab0: bl      #0x3769600                                 fn_3769600
02d6bab4: cbz     x0, #0x2d6bae0                             
02d6bab8: ldr     x8, [x24]                                  M:AdsManager::<OnApplicationPause>b__26_0
02d6babc: ldp     x20, x19, [sp, #0x30]                      
02d6bac0: ldp     x22, x21, [sp, #0x20]                      
02d6bac4: ldr     x30, [sp, #8]                              
02d6bac8: ldr     x8, [x8, #0xb8]                            
02d6bacc: ldp     x24, x23, [sp, #0x10]                      
02d6bad0: ldr     x1, [x8, #0x238]                           
02d6bad4: str     x1, [x0, #0x40]!                           ._btnHome
02d6bad8: ldr     d8, [sp], #0x40                            
02d6badc: b       #0x2b70d54                                 
02d6bae0: bl      #0x2b7105c                                 fn_2b7105c
## ShowSpeedUpPrinterButton(bool isShow) -> void
---- Clicker.IngameClickerScreen::ShowSpeedUpPrinterButton 0x2d64a80
02d64a80: ldr     x0, [x0, #0x58]                            ._printer3DUIContent
02d64a84: cbz     x0, #0x2d64a94                             
02d64a88: and     w1, w1, #1                                 
02d64a8c: mov     x2, xzr                                    
02d64a90: b       #0x2d70e3c                                 Clicker.Printer3DUIContent::ShowBtnSpeedUp
02d64a94: str     x30, [sp, #-0x10]!                         
02d64a98: bl      #0x2b7105c                                 fn_2b7105c
## ShowPopupColor(UnityEngine.Transform _tfKeycap) -> void
---- Clicker.IngameClickerScreen::ShowPopupColor 0x2d6bae4
02d6bae4: ldr     x0, [x0, #0x70]                            ._popupSelectColor
02d6bae8: cbz     x0, #0x2d6baf8                             
02d6baec: mov     w2, wzr                                    
02d6baf0: mov     x3, xzr                                    
02d6baf4: b       #0x2d70644                                 Clicker.PopupSelectColor::ShowAt
02d6baf8: str     x30, [sp, #-0x10]!                         
02d6bafc: bl      #0x2b7105c                                 fn_2b7105c
## HidePopupColor() -> void
---- Clicker.IngameClickerScreen::HidePopupColor 0x2d6bb00
02d6bb00: ldr     x0, [x0, #0x70]                            ._popupSelectColor
02d6bb04: cbz     x0, #0x2d6bb10                             
02d6bb08: mov     x1, xzr                                    
02d6bb0c: b       #0x2d708cc                                 Clicker.PopupSelectColor::Hide
02d6bb10: str     x30, [sp, #-0x10]!                         
02d6bb14: bl      #0x2b7105c                                 fn_2b7105c
## GoToStepDecorKeycap() -> void
---- Clicker.IngameClickerScreen::GoToStepDecorKeycap 0x2d6bb18
02d6bb18: str     d8, [sp, #-0x40]!                          
02d6bb1c: str     x30, [sp, #8]                              
02d6bb20: stp     x24, x23, [sp, #0x10]                      
02d6bb24: stp     x22, x21, [sp, #0x20]                      
02d6bb28: stp     x20, x19, [sp, #0x30]                      
02d6bb2c: adrp    x20, #0x6630000                            
02d6bb30: mov     x19, x0                                    
02d6bb34: ldrb    w8, [x20, #0x369]                          
02d6bb38: tbnz    w8, #0, #0x2d6bb5c                         
02d6bb3c: adrp    x0, #0x6265000                             
02d6bb40: ldr     x0, [x0, #0xb38]                           T:DevTrack
02d6bb44: bl      #0x2b70db0                                 fn_2b70db0
02d6bb48: adrp    x0, #0x6266000                             
02d6bb4c: ldr     x0, [x0, #0xb48]                           MS:MonoSingleton`1::get_Instance
02d6bb50: bl      #0x2b70db0                                 fn_2b70db0
02d6bb54: mov     w8, #1                                     
02d6bb58: strb    w8, [x20, #0x369]                          
02d6bb5c: ldr     x0, [x19, #0x70]                           ._popupSelectColor
02d6bb60: cbz     x0, #0x2d6bc74                             
02d6bb64: mov     x1, xzr                                    
02d6bb68: bl      #0x2d708cc                                 Clicker.PopupSelectColor::Hide
02d6bb6c: ldr     x0, [x19, #0x78]                           ._decorKeycapPanel
02d6bb70: cbz     x0, #0x2d6bc74                             
02d6bb74: adrp    x23, #0x6266000                            
02d6bb78: ldr     x23, [x23, #0xb48]                         MS:MonoSingleton`1::get_Instance
02d6bb7c: bl      #0x2d696bc                                 Clicker.DecorKeycapPanel::ShowPanel
02d6bb80: ldr     x0, [x23]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d6bb84: bl      #0x3769600                                 fn_3769600
02d6bb88: cbz     x0, #0x2d6bc74                             
02d6bb8c: ldr     x19, [x0, #0x30]                           S:'popup_rate_on_off'
02d6bb90: ldr     x0, [x23]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d6bb94: bl      #0x3769600                                 fn_3769600
02d6bb98: cbz     x0, #0x2d6bc74                             
02d6bb9c: adrp    x24, #0x6265000                            
02d6bba0: mov     x8, x0                                     
02d6bba4: ldr     x24, [x24, #0xb38]                         T:DevTrack
02d6bba8: ldr     w20, [x8, #0x3c]                           
02d6bbac: ldr     x0, [x24]                                  M:AdsManager::<OnApplicationPause>b__26_0
02d6bbb0: ldr     w9, [x0, #0xe4]                            [62660e4]=0 f=0,0
02d6bbb4: cbnz    w9, #0x2d6bbc0                             
02d6bbb8: bl      #0x2b70f30                                 fn_2b70f30
02d6bbbc: ldr     x0, [x24]                                  M:AdsManager::<OnApplicationPause>b__26_0
02d6bbc0: ldr     x8, [x0, #0xb8]                            S:'banner_native_refresh_time'
02d6bbc4: mov     x0, xzr                                    
02d6bbc8: ldr     x21, [x8, #0x238]                          
02d6bbcc: ldr     w22, [x8, #0x280]                          
02d6bbd0: bl      #0x5b432fc                                 UnityEngine.Time::get_time
02d6bbd4: ldr     x0, [x23]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d6bbd8: fmov    s8, s0                                     
02d6bbdc: bl      #0x3769600                                 fn_3769600
02d6bbe0: cbz     x0, #0x2d6bc74                             
02d6bbe4: ldr     s0, [x0, #0x38]                            S:'native_collap_id' ._btnNext
02d6bbe8: mov     x0, x19                                    
02d6bbec: mov     w1, w20                                    
02d6bbf0: mov     x2, x21                                    
02d6bbf4: mov     w3, w22                                    
02d6bbf8: mov     x4, xzr                                    
02d6bbfc: fsub    s0, s8, s0                                 
02d6bc00: bl      #0x2c9c898                                 DevTrack::GameModeStepComplete
02d6bc04: ldr     x0, [x23]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d6bc08: bl      #0x3769600                                 fn_3769600
02d6bc0c: cbz     x0, #0x2d6bc74                             
02d6bc10: ldr     x19, [x0, #0x30]                           S:'popup_rate_on_off'
02d6bc14: ldr     x0, [x23]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d6bc18: bl      #0x3769600                                 fn_3769600
02d6bc1c: cbz     x0, #0x2d6bc74                             
02d6bc20: ldr     x8, [x24]                                  M:AdsManager::<OnApplicationPause>b__26_0
02d6bc24: ldr     w1, [x0, #0x3c]                            [626603c]=0 f=0,0
02d6bc28: mov     x0, x19                                    
02d6bc2c: mov     x4, xzr                                    
02d6bc30: ldr     x8, [x8, #0xb8]                            
02d6bc34: ldr     x2, [x8, #0x240]                           
02d6bc38: ldr     w3, [x8, #0x284]                           
02d6bc3c: bl      #0x2c9c714                                 DevTrack::GameModeStepEnter
02d6bc40: ldr     x0, [x23]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d6bc44: bl      #0x3769600                                 fn_3769600
02d6bc48: cbz     x0, #0x2d6bc74                             
02d6bc4c: ldr     x8, [x24]                                  M:AdsManager::<OnApplicationPause>b__26_0
02d6bc50: ldp     x20, x19, [sp, #0x30]                      
02d6bc54: ldp     x22, x21, [sp, #0x20]                      
02d6bc58: ldr     x30, [sp, #8]                              
02d6bc5c: ldr     x8, [x8, #0xb8]                            
02d6bc60: ldp     x24, x23, [sp, #0x10]                      
02d6bc64: ldr     x1, [x8, #0x240]                           
02d6bc68: str     x1, [x0, #0x40]!                           ._btnHome
02d6bc6c: ldr     d8, [sp], #0x40                            
02d6bc70: b       #0x2b70d54                                 
02d6bc74: bl      #0x2b7105c                                 fn_2b7105c
## GoToStepSelectKeychain() -> void
---- Clicker.IngameClickerScreen::GoToStepSelectKeychain 0x2d6a4ac
02d6a4ac: str     d8, [sp, #-0x40]!                          
02d6a4b0: str     x30, [sp, #8]                              
02d6a4b4: stp     x24, x23, [sp, #0x10]                      
02d6a4b8: stp     x22, x21, [sp, #0x20]                      
02d6a4bc: stp     x20, x19, [sp, #0x30]                      
02d6a4c0: adrp    x20, #0x6630000                            
02d6a4c4: mov     x19, x0                                    
02d6a4c8: ldrb    w8, [x20, #0x36a]                          
02d6a4cc: tbnz    w8, #0, #0x2d6a4f0                         
02d6a4d0: adrp    x0, #0x6265000                             
02d6a4d4: ldr     x0, [x0, #0xb38]                           T:DevTrack
02d6a4d8: bl      #0x2b70db0                                 fn_2b70db0
02d6a4dc: adrp    x0, #0x6266000                             
02d6a4e0: ldr     x0, [x0, #0xb48]                           MS:MonoSingleton`1::get_Instance
02d6a4e4: bl      #0x2b70db0                                 fn_2b70db0
02d6a4e8: mov     w8, #1                                     
02d6a4ec: strb    w8, [x20, #0x36a]                          
02d6a4f0: ldr     x0, [x19, #0x80]                           ._selectKeychainPanel
02d6a4f4: cbz     x0, #0x2d6a5fc                             
02d6a4f8: adrp    x23, #0x6266000                            
02d6a4fc: mov     x1, xzr                                    
02d6a500: ldr     x23, [x23, #0xb48]                         MS:MonoSingleton`1::get_Instance
02d6a504: bl      #0x2d733d4                                 Clicker.SelectKeychainPanel::ShowPanel
02d6a508: ldr     x0, [x23]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d6a50c: bl      #0x3769600                                 fn_3769600
02d6a510: cbz     x0, #0x2d6a5fc                             
02d6a514: ldr     x19, [x0, #0x30]                           S:'popup_rate_on_off'
02d6a518: ldr     x0, [x23]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d6a51c: bl      #0x3769600                                 fn_3769600
02d6a520: cbz     x0, #0x2d6a5fc                             
02d6a524: adrp    x24, #0x6265000                            
02d6a528: mov     x8, x0                                     
02d6a52c: ldr     x24, [x24, #0xb38]                         T:DevTrack
02d6a530: ldr     w20, [x8, #0x3c]                           
02d6a534: ldr     x0, [x24]                                  M:AdsManager::<OnApplicationPause>b__26_0
02d6a538: ldr     w9, [x0, #0xe4]                            [62660e4]=0 f=0,0
02d6a53c: cbnz    w9, #0x2d6a548                             
02d6a540: bl      #0x2b70f30                                 fn_2b70f30
02d6a544: ldr     x0, [x24]                                  M:AdsManager::<OnApplicationPause>b__26_0
02d6a548: ldr     x8, [x0, #0xb8]                            S:'banner_native_refresh_time'
02d6a54c: mov     x0, xzr                                    
02d6a550: ldr     x21, [x8, #0x240]                          
02d6a554: ldr     w22, [x8, #0x284]                          
02d6a558: bl      #0x5b432fc                                 UnityEngine.Time::get_time
02d6a55c: ldr     x0, [x23]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d6a560: fmov    s8, s0                                     
02d6a564: bl      #0x3769600                                 fn_3769600
02d6a568: cbz     x0, #0x2d6a5fc                             
02d6a56c: ldr     s0, [x0, #0x38]                            S:'native_collap_id' ._btnNext
02d6a570: mov     x0, x19                                    
02d6a574: mov     w1, w20                                    
02d6a578: mov     x2, x21                                    
02d6a57c: mov     w3, w22                                    
02d6a580: mov     x4, xzr                                    
02d6a584: fsub    s0, s8, s0                                 
02d6a588: bl      #0x2c9c898                                 DevTrack::GameModeStepComplete
02d6a58c: ldr     x0, [x23]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d6a590: bl      #0x3769600                                 fn_3769600
02d6a594: cbz     x0, #0x2d6a5fc                             
02d6a598: ldr     x19, [x0, #0x30]                           S:'popup_rate_on_off'
02d6a59c: ldr     x0, [x23]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d6a5a0: bl      #0x3769600                                 fn_3769600
02d6a5a4: cbz     x0, #0x2d6a5fc                             
02d6a5a8: ldr     x8, [x24]                                  M:AdsManager::<OnApplicationPause>b__26_0
02d6a5ac: ldr     w1, [x0, #0x3c]                            [626603c]=0 f=0,0
02d6a5b0: mov     x0, x19                                    
02d6a5b4: mov     x4, xzr                                    
02d6a5b8: ldr     x8, [x8, #0xb8]                            
02d6a5bc: ldr     x2, [x8, #0x248]                           
02d6a5c0: ldr     w3, [x8, #0x288]                           
02d6a5c4: bl      #0x2c9c714                                 DevTrack::GameModeStepEnter
02d6a5c8: ldr     x0, [x23]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d6a5cc: bl      #0x3769600                                 fn_3769600
02d6a5d0: cbz     x0, #0x2d6a5fc                             
02d6a5d4: ldr     x8, [x24]                                  M:AdsManager::<OnApplicationPause>b__26_0
02d6a5d8: ldp     x20, x19, [sp, #0x30]                      
02d6a5dc: ldp     x22, x21, [sp, #0x20]                      
02d6a5e0: ldr     x30, [sp, #8]                              
02d6a5e4: ldr     x8, [x8, #0xb8]                            
02d6a5e8: ldp     x24, x23, [sp, #0x10]                      
02d6a5ec: ldr     x1, [x8, #0x248]                           
02d6a5f0: str     x1, [x0, #0x40]!                           ._btnHome
02d6a5f4: ldr     d8, [sp], #0x40                            
02d6a5f8: b       #0x2b70d54                                 
02d6a5fc: bl      #0x2b7105c                                 fn_2b7105c
## OnBtnHomeClick() -> void
---- Clicker.IngameClickerScreen::OnBtnHomeClick 0x2d6bc78
02d6bc78: str     x30, [sp, #-0x20]!                         
02d6bc7c: stp     x20, x19, [sp, #0x10]                      
02d6bc80: adrp    x20, #0x6630000                            
02d6bc84: mov     x19, x0                                    
02d6bc88: ldrb    w8, [x20, #0x36b]                          
02d6bc8c: tbnz    w8, #0, #0x2d6bca4                         
02d6bc90: adrp    x0, #0x626a000                             
02d6bc94: ldr     x0, [x0, #0xc08]                           MS:UIManager::ShowPopup
02d6bc98: bl      #0x2b70db0                                 fn_2b70db0
02d6bc9c: mov     w8, #1                                     
02d6bca0: strb    w8, [x20, #0x36b]                          
02d6bca4: mov     x0, xzr                                    
02d6bca8: bl      #0x2d6eec8                                 Framework.AudioManager::get_Instance
02d6bcac: cbz     x0, #0x2d6bcf0                             
02d6bcb0: movi    d1, #0000000000000000                      
02d6bcb4: movi    d2, #0000000000000000                      
02d6bcb8: mov     w1, #1                                     
02d6bcbc: fmov    s0, #1.00000000                            
02d6bcc0: mov     w2, wzr                                    
02d6bcc4: mov     w3, wzr                                    
02d6bcc8: mov     x4, xzr                                    
02d6bccc: bl      #0x2d6f03c                                 Framework.AudioManager::PlaySound
02d6bcd0: ldr     x0, [x19, #0x30]                           
02d6bcd4: cbz     x0, #0x2d6bcf0                             
02d6bcd8: adrp    x8, #0x626a000                             
02d6bcdc: ldr     x8, [x8, #0xc08]                           MS:UIManager::ShowPopup
02d6bce0: ldp     x20, x19, [sp, #0x10]                      
02d6bce4: ldr     x1, [x8]                                   T:type56879(k15)
02d6bce8: ldr     x30, [sp], #0x20                           
02d6bcec: b       #0x33fbfac                                 
02d6bcf0: bl      #0x2b7105c                                 fn_2b7105c
## OnHide() -> void
---- Clicker.IngameClickerScreen::OnHide 0x2d6bcf4
02d6bcf4: stp     x30, x19, [sp, #-0x10]!                    
02d6bcf8: mov     x1, xzr                                    
02d6bcfc: mov     x19, x0                                    
02d6bd00: bl      #0x2cddc10                                 UIBase::OnHide
02d6bd04: ldr     x0, [x19, #0x48]                           ._livestreamPanel
02d6bd08: cbz     x0, #0x2d6bd18                             
02d6bd0c: mov     x1, xzr                                    
02d6bd10: ldp     x30, x19, [sp], #0x10                      
02d6bd14: b       #0x2d11cdc                                 Livestream.LivestreamPanel::OnHide
02d6bd18: bl      #0x2b7105c                                 fn_2b7105c
## ShowTutorialAt(UnityEngine.Transform target) -> void
---- Clicker.IngameClickerScreen::ShowTutorialAt 0x2d6a2c0
02d6a2c0: str     x30, [sp, #-0x30]!                         
02d6a2c4: stp     x22, x21, [sp, #0x10]                      
02d6a2c8: stp     x20, x19, [sp, #0x20]                      
02d6a2cc: adrp    x21, #0x6630000                            
02d6a2d0: adrp    x22, #0x6266000                            
02d6a2d4: mov     x20, x1                                    
02d6a2d8: ldrb    w8, [x21, #0x36c]                          
02d6a2dc: ldr     x22, [x22, #0x658]                         MS:MonoSingleton`1::get_Instance
02d6a2e0: mov     x19, x0                                    
02d6a2e4: tbnz    w8, #0, #0x2d6a308                         
02d6a2e8: adrp    x0, #0x6266000                             
02d6a2ec: ldr     x0, [x0, #0x750]                           MS:DataManager::GetData
02d6a2f0: bl      #0x2b70db0                                 fn_2b70db0
02d6a2f4: adrp    x0, #0x6266000                             
02d6a2f8: ldr     x0, [x0, #0x658]                           MS:MonoSingleton`1::get_Instance
02d6a2fc: bl      #0x2b70db0                                 fn_2b70db0
02d6a300: mov     w8, #1                                     
02d6a304: strb    w8, [x21, #0x36c]                          
02d6a308: ldr     x0, [x22]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d6a30c: bl      #0x3769600                                 fn_3769600
02d6a310: cbz     x0, #0x2d6a398                             
02d6a314: adrp    x8, #0x6266000                             
02d6a318: ldr     x8, [x8, #0x750]                           MS:DataManager::GetData
02d6a31c: ldr     x1, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d6a320: bl      #0x3168dd0                                 fn_3168dd0
02d6a324: cbz     x0, #0x2d6a398                             
02d6a328: ldr     x8, [x0, #0x20]                            S:'inter_ad_capping_time'
02d6a32c: cbz     x8, #0x2d6a398                             
02d6a330: ldrb    w8, [x8, #0x3b]                            
02d6a334: cbz     w8, #0x2d6a388                             
02d6a338: cbz     x20, #0x2d6a398                            
02d6a33c: ldr     x21, [x19, #0x88]                          ._tfHandTutorial
02d6a340: mov     x0, x20                                    
02d6a344: mov     x1, xzr                                    
02d6a348: bl      #0x5b467ac                                 UnityEngine.Transform::get_position
02d6a34c: cbz     x21, #0x2d6a398                            
02d6a350: mov     x0, x21                                    
02d6a354: mov     x1, xzr                                    
02d6a358: bl      #0x5b46888                                 UnityEngine.Transform::set_position
02d6a35c: ldr     x0, [x19, #0x88]                           ._tfHandTutorial
02d6a360: cbz     x0, #0x2d6a398                             
02d6a364: mov     x1, xzr                                    
02d6a368: bl      #0x5b339ec                                 UnityEngine.Component::get_gameObject
02d6a36c: cbz     x0, #0x2d6a398                             
02d6a370: ldp     x20, x19, [sp, #0x20]                      
02d6a374: mov     w1, #1                                     
02d6a378: ldp     x22, x21, [sp, #0x10]                      
02d6a37c: mov     x2, xzr                                    
02d6a380: ldr     x30, [sp], #0x30                           
02d6a384: b       #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d6a388: ldp     x20, x19, [sp, #0x20]                      
02d6a38c: ldp     x22, x21, [sp, #0x10]                      
02d6a390: ldr     x30, [sp], #0x30                           
02d6a394: ret                                                
02d6a398: bl      #0x2b7105c                                 fn_2b7105c
## HideTutorial() -> void
---- Clicker.IngameClickerScreen::HideTutorial 0x2d6a9a4
02d6a9a4: str     x30, [sp, #-0x10]!                         
02d6a9a8: ldr     x0, [x0, #0x88]                            ._tfHandTutorial
02d6a9ac: cbz     x0, #0x2d6a9cc                             
02d6a9b0: mov     x1, xzr                                    
02d6a9b4: bl      #0x5b339ec                                 UnityEngine.Component::get_gameObject
02d6a9b8: cbz     x0, #0x2d6a9cc                             
02d6a9bc: mov     w1, wzr                                    
02d6a9c0: mov     x2, xzr                                    
02d6a9c4: ldr     x30, [sp], #0x10                           
02d6a9c8: b       #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d6a9cc: bl      #0x2b7105c                                 fn_2b7105c
## .ctor() -> void
---- Clicker.IngameClickerScreen::.ctor 0x2d6bd1c
02d6bd1c: stp     x30, x21, [sp, #-0x20]!                    
02d6bd20: stp     x20, x19, [sp, #0x10]                      
02d6bd24: adrp    x20, #0x6630000                            
02d6bd28: adrp    x21, #0x6267000                            
02d6bd2c: mov     x19, x0                                    
02d6bd30: ldrb    w8, [x20, #0x36d]                          
02d6bd34: ldr     x21, [x21, #0xff0]                         T:UnityEngine.Events.UnityEvent
02d6bd38: tbnz    w8, #0, #0x2d6bd50                         
02d6bd3c: adrp    x0, #0x6267000                             
02d6bd40: ldr     x0, [x0, #0xff0]                           T:UnityEngine.Events.UnityEvent
02d6bd44: bl      #0x2b70db0                                 fn_2b70db0
02d6bd48: mov     w8, #1                                     
02d6bd4c: strb    w8, [x20, #0x36d]                          
02d6bd50: ldr     x0, [x21]                                  S:'didu'
02d6bd54: bl      #0x2b7104c                                 fn_2b7104c
02d6bd58: mov     x1, xzr                                    
02d6bd5c: mov     x20, x0                                    
02d6bd60: bl      #0x5b4d048                                 UnityEngine.Events.UnityEvent::.ctor
02d6bd64: mov     x0, x19                                    
02d6bd68: mov     x1, x20                                    
02d6bd6c: str     x20, [x0, #0x90]!                          ._onBtnNextClick
02d6bd70: bl      #0x2b70d54                                 fn_2b70d54
02d6bd74: mov     x0, x19                                    
02d6bd78: ldp     x20, x19, [sp, #0x10]                      
02d6bd7c: mov     x1, xzr                                    
02d6bd80: ldp     x30, x21, [sp], #0x20                      
02d6bd84: b       #0x2cde678                                 ScreenBase::.ctor
## <OnInit>b__12_0() -> void
---- Clicker.IngameClickerScreen::<OnInit>b__12_0 0x2d6bd88
02d6bd88: stp     x30, x19, [sp, #-0x10]!                    
02d6bd8c: mov     x19, x0                                    
02d6bd90: mov     x0, xzr                                    
02d6bd94: bl      #0x2d6eec8                                 Framework.AudioManager::get_Instance
02d6bd98: cbz     x0, #0x2d6bdd8                             
02d6bd9c: movi    d1, #0000000000000000                      
02d6bda0: movi    d2, #0000000000000000                      
02d6bda4: mov     w1, #1                                     
02d6bda8: fmov    s0, #1.00000000                            
02d6bdac: mov     w2, wzr                                    
02d6bdb0: mov     w3, wzr                                    
02d6bdb4: mov     x4, xzr                                    
02d6bdb8: bl      #0x2d6f03c                                 Framework.AudioManager::PlaySound
02d6bdbc: ldr     x0, [x19, #0x90]                           ._onBtnNextClick
02d6bdc0: cbz     x0, #0x2d6bdd0                             
02d6bdc4: mov     x1, xzr                                    
02d6bdc8: ldp     x30, x19, [sp], #0x10                      
02d6bdcc: b       #0x5b4d278                                 UnityEngine.Events.UnityEvent::Invoke
02d6bdd0: ldp     x30, x19, [sp], #0x10                      
02d6bdd4: ret                                                
02d6bdd8: bl      #0x2b7105c                                 fn_2b7105c
