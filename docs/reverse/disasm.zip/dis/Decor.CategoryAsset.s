#### CLASS Decor.CategoryAsset/<>c__DisplayClass4_0 parent= object
#   field id                             int                                                off=0x10 attr=6 
## .ctor() -> void
---- Decor.CategoryAsset/<>c__DisplayClass4_0::.ctor 0x2d25114
02d25114: mov     x1, xzr                                    
02d25118: b       #0x4e53e9c                                 System.Object::.ctor
## <GetOptionDataByID>b__0(Decor.OptionData c) -> bool
---- Decor.CategoryAsset/<>c__DisplayClass4_0::<GetOptionDataByID>b__0 0x2d2529c
02d2529c: cbz     x1, #0x2d252b4                             
02d252a0: ldr     w8, [x1, #0x10]                            
02d252a4: ldr     w9, [x0, #0x10]                            .id
02d252a8: cmp     w8, w9                                     
02d252ac: cset    w0, eq                                     
02d252b0: ret                                                
02d252b4: str     x30, [sp, #-0x10]!                         
02d252b8: bl      #0x2b7105c                                 fn_2b7105c
#### CLASS Decor.CategoryAsset parent= UnityEngine.ScriptableObject
#   field Name                           string                                             off=0x18 attr=6 
#   field OnIcon                         UnityEngine.Sprite                                 off=0x20 attr=6 
#   field OffIcon                        UnityEngine.Sprite                                 off=0x28 attr=6 
#   field OptionDatas                    System.Collections.Generic.List`1<Decor.OptionData> off=0x30 attr=6 
## GetOptionDataByID(int id) -> Decor.OptionData
---- Decor.CategoryAsset::GetOptionDataByID 0x2d24a4c
02d24a4c: str     x30, [sp, #-0x30]!                         
02d24a50: stp     x22, x21, [sp, #0x10]                      
02d24a54: stp     x20, x19, [sp, #0x20]                      
02d24a58: adrp    x21, #0x6630000                            
02d24a5c: adrp    x22, #0x6269000                            
02d24a60: mov     w19, w1                                    
02d24a64: ldrb    w8, [x21, #0x6b]                           
02d24a68: ldr     x22, [x22, #0xf28]                         T:Decor.CategoryAsset/<>c__DisplayClass4_0
02d24a6c: mov     x20, x0                                    
02d24a70: tbnz    w8, #0, #0x2d24aac                         
02d24a74: adrp    x0, #0x6269000                             
02d24a78: ldr     x0, [x0, #0xf30]                           MS:System.Collections.Generic.List`1::Find
02d24a7c: bl      #0x2b70db0                                 fn_2b70db0
02d24a80: adrp    x0, #0x6269000                             
02d24a84: ldr     x0, [x0, #0xf38]                           T:type57264(k15)
02d24a88: bl      #0x2b70db0                                 fn_2b70db0
02d24a8c: adrp    x0, #0x6269000                             
02d24a90: ldr     x0, [x0, #0xf40]                           M:Decor.CategoryAsset/<>c__DisplayClass4_0::<GetOptionDataByID>b__0
02d24a94: bl      #0x2b70db0                                 fn_2b70db0
02d24a98: adrp    x0, #0x6269000                             
02d24a9c: ldr     x0, [x0, #0xf28]                           T:Decor.CategoryAsset/<>c__DisplayClass4_0
02d24aa0: bl      #0x2b70db0                                 fn_2b70db0
02d24aa4: mov     w8, #1                                     
02d24aa8: strb    w8, [x21, #0x6b]                           
02d24aac: ldr     x0, [x22]                                  T:Trading.TradingSession/<>c__DisplayClass56_0
02d24ab0: bl      #0x2b7104c                                 fn_2b7104c
02d24ab4: mov     x1, xzr                                    
02d24ab8: mov     x21, x0                                    
02d24abc: bl      #0x4e53e9c                                 System.Object::.ctor
02d24ac0: cbz     x21, #0x2d24b20                            
02d24ac4: adrp    x8, #0x6269000                             
02d24ac8: adrp    x22, #0x6269000                            
02d24acc: ldr     x8, [x8, #0xf38]                           T:type57264(k15)
02d24ad0: ldr     x22, [x22, #0xf40]                         M:Decor.CategoryAsset/<>c__DisplayClass4_0::<GetOptionDataByID>b__0
02d24ad4: ldr     x20, [x20, #0x30]                          .OptionDatas
02d24ad8: str     w19, [x21, #0x10]                          
02d24adc: ldr     x0, [x8]                                   T:Trading.TradingSession/<>c__DisplayClass56_0
02d24ae0: bl      #0x2b7104c                                 fn_2b7104c
02d24ae4: ldr     x2, [x22]                                  T:Trading.TradingSession/<>c__DisplayClass56_0
02d24ae8: mov     x1, x21                                    
02d24aec: mov     x3, xzr                                    
02d24af0: mov     x19, x0                                    
02d24af4: bl      #0x399ba10                                 fn_399ba10
02d24af8: cbz     x20, #0x2d24b20                            
02d24afc: adrp    x8, #0x6269000                             
02d24b00: mov     x0, x20                                    
02d24b04: mov     x1, x19                                    
02d24b08: ldr     x8, [x8, #0xf30]                           MS:System.Collections.Generic.List`1::Find
02d24b0c: ldp     x20, x19, [sp, #0x20]                      
02d24b10: ldp     x22, x21, [sp, #0x10]                      
02d24b14: ldr     x2, [x8]                                   T:Trading.TradingSession/<>c__DisplayClass56_0
02d24b18: ldr     x30, [sp], #0x30                           
02d24b1c: b       #0x35a9868                                 
02d24b20: bl      #0x2b7105c                                 fn_2b7105c
## GetOptionDataByIndex(int index) -> Decor.OptionData
---- Decor.CategoryAsset::GetOptionDataByIndex 0x2d2511c
02d2511c: stp     x30, x21, [sp, #-0x20]!                    
02d25120: stp     x20, x19, [sp, #0x10]                      
02d25124: adrp    x21, #0x6630000                            
02d25128: mov     w19, w1                                    
02d2512c: mov     x20, x0                                    
02d25130: ldrb    w8, [x21, #0x6c]                           
02d25134: tbnz    w8, #0, #0x2d2514c                         
02d25138: adrp    x0, #0x6269000                             
02d2513c: ldr     x0, [x0, #0xf78]                           MS:System.Collections.Generic.List`1::get_Item
02d25140: bl      #0x2b70db0                                 fn_2b70db0
02d25144: mov     w8, #1                                     
02d25148: strb    w8, [x21, #0x6c]                           
02d2514c: ldr     x0, [x20, #0x30]                           .OptionDatas
02d25150: cbz     x0, #0x2d25170                             
02d25154: adrp    x8, #0x6269000                             
02d25158: mov     w1, w19                                    
02d2515c: ldr     x8, [x8, #0xf78]                           MS:System.Collections.Generic.List`1::get_Item
02d25160: ldp     x20, x19, [sp, #0x10]                      
02d25164: ldr     x2, [x8]                                   T:Trading.TradingSession/<>c__DisplayClass56_0
02d25168: ldp     x30, x21, [sp], #0x20                      
02d2516c: b       #0x35a8f3c                                 
02d25170: bl      #0x2b7105c                                 fn_2b7105c
## GetOptionDataCount() -> int
---- Decor.CategoryAsset::GetOptionDataCount 0x2d25174
02d25174: str     x30, [sp, #-0x20]!                         
02d25178: stp     x20, x19, [sp, #0x10]                      
02d2517c: adrp    x20, #0x6630000                            
02d25180: mov     x19, x0                                    
02d25184: ldrb    w8, [x20, #0x6d]                           
02d25188: tbnz    w8, #0, #0x2d251a0                         
02d2518c: adrp    x0, #0x6269000                             
02d25190: ldr     x0, [x0, #0xf80]                           MS:System.Collections.Generic.List`1::get_Count
02d25194: bl      #0x2b70db0                                 fn_2b70db0
02d25198: mov     w8, #1                                     
02d2519c: strb    w8, [x20, #0x6d]                           
02d251a0: ldr     x8, [x19, #0x30]                           .OptionDatas
02d251a4: cbz     x8, #0x2d251b8                             
02d251a8: ldp     x20, x19, [sp, #0x10]                      
02d251ac: ldr     w0, [x8, #0x18]                            
02d251b0: ldr     x30, [sp], #0x20                           
02d251b4: ret                                                
02d251b8: bl      #0x2b7105c                                 fn_2b7105c
## GetOptionDataIndex(Decor.OptionData optionData) -> int
---- Decor.CategoryAsset::GetOptionDataIndex 0x2d251bc
02d251bc: stp     x30, x21, [sp, #-0x20]!                    
02d251c0: stp     x20, x19, [sp, #0x10]                      
02d251c4: adrp    x21, #0x6630000                            
02d251c8: mov     x19, x1                                    
02d251cc: mov     x20, x0                                    
02d251d0: ldrb    w8, [x21, #0x6e]                           
02d251d4: tbnz    w8, #0, #0x2d251ec                         
02d251d8: adrp    x0, #0x6269000                             
02d251dc: ldr     x0, [x0, #0xf88]                           MS:System.Collections.Generic.List`1::IndexOf
02d251e0: bl      #0x2b70db0                                 fn_2b70db0
02d251e4: mov     w8, #1                                     
02d251e8: strb    w8, [x21, #0x6e]                           
02d251ec: ldr     x0, [x20, #0x30]                           .OptionDatas
02d251f0: cbz     x0, #0x2d25210                             
02d251f4: adrp    x8, #0x6269000                             
02d251f8: mov     x1, x19                                    
02d251fc: ldr     x8, [x8, #0xf88]                           MS:System.Collections.Generic.List`1::IndexOf
02d25200: ldp     x20, x19, [sp, #0x10]                      
02d25204: ldr     x2, [x8]                                   T:Trading.TradingSession/<>c__DisplayClass56_0
02d25208: ldp     x30, x21, [sp], #0x20                      
02d2520c: b       #0x35a9f48                                 
02d25210: bl      #0x2b7105c                                 fn_2b7105c
## .ctor() -> void
---- Decor.CategoryAsset::.ctor 0x2d25214
02d25214: str     x30, [sp, #-0x30]!                         
02d25218: stp     x22, x21, [sp, #0x10]                      
02d2521c: stp     x20, x19, [sp, #0x20]                      
02d25220: adrp    x21, #0x6630000                            
02d25224: adrp    x22, #0x6269000                            
02d25228: adrp    x20, #0x6269000                            
02d2522c: ldrb    w8, [x21, #0x6f]                           
02d25230: ldr     x22, [x22, #0xf90]                         T:type56769(k15)
02d25234: ldr     x20, [x20, #0xf98]                         MS:System.Collections.Generic.List`1::.ctor
02d25238: mov     x19, x0                                    
02d2523c: tbnz    w8, #0, #0x2d25260                         
02d25240: adrp    x0, #0x6269000                             
02d25244: ldr     x0, [x0, #0xf98]                           MS:System.Collections.Generic.List`1::.ctor
02d25248: bl      #0x2b70db0                                 fn_2b70db0
02d2524c: adrp    x0, #0x6269000                             
02d25250: ldr     x0, [x0, #0xf90]                           T:type56769(k15)
02d25254: bl      #0x2b70db0                                 fn_2b70db0
02d25258: mov     w8, #1                                     
02d2525c: strb    w8, [x21, #0x6f]                           
02d25260: ldr     x0, [x22]                                  T:Trading.TradingSession/<>c__DisplayClass56_0
02d25264: bl      #0x2b7104c                                 fn_2b7104c
02d25268: ldr     x1, [x20]                                  T:Trading.TradingSession/<>c__DisplayClass56_0
02d2526c: mov     x20, x0                                    
02d25270: bl      #0x35a89a4                                 fn_35a89a4
02d25274: mov     x0, x19                                    
02d25278: mov     x1, x20                                    
02d2527c: str     x20, [x0, #0x30]!                          .OptionDatas
02d25280: bl      #0x2b70d54                                 fn_2b70d54
02d25284: mov     x0, x19                                    
02d25288: ldp     x20, x19, [sp, #0x20]                      
02d2528c: ldp     x22, x21, [sp, #0x10]                      
02d25290: mov     x1, xzr                                    
02d25294: ldr     x30, [sp], #0x30                           
02d25298: b       #0x5b398f0                                 UnityEngine.ScriptableObject::.ctor
