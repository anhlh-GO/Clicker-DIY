#### CLASS DailyMission.DailyItemConfig parent= UnityEngine.ScriptableObject
#   field _rewardedSprite                UnityEngine.Sprite                                 off=0x18 attr=6 
#   field _selectedSprite                UnityEngine.Sprite                                 off=0x20 attr=6 
#   field _unselectSprite                UnityEngine.Sprite                                 off=0x28 attr=6 
#   field _selectedTextColor             UnityEngine.Color                                  off=0x30 attr=6 
#   field _unselectTextColor             UnityEngine.Color                                  off=0x40 attr=6 
#   field _rewardTextColor               UnityEngine.Color                                  off=0x50 attr=6 
## .ctor() -> void
---- DailyMission.DailyItemConfig::.ctor 0x2d770fc
02d770fc: mov     x1, xzr                                    
02d77100: b       #0x5b398f0                                 UnityEngine.ScriptableObject::.ctor
