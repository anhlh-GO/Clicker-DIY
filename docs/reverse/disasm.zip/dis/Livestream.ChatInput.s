#### CLASS Livestream.ChatInput parent= UnityEngine.MonoBehaviour
#   field _inputField                    TMPro.TMP_InputField                               off=0x20 attr=1 SerializeField
#   field _commentHandler                CommentHandler                                     off=0x28 attr=1 SerializeField
## OnInit() -> void
---- Livestream.ChatInput::OnInit 0x2d11580
02d11580: stp     x30, x21, [sp, #-0x20]!                    
02d11584: stp     x20, x19, [sp, #0x10]                      
02d11588: adrp    x20, #0x662f000                            
02d1158c: mov     x19, x0                                    
02d11590: ldrb    w8, [x20, #0xfb5]                          
02d11594: tbnz    w8, #0, #0x2d115c4                         
02d11598: adrp    x0, #0x6269000                             
02d1159c: ldr     x0, [x0, #0x788]                           M:Livestream.ChatInput::<OnInit>b__2_0
02d115a0: bl      #0x2b70db0                                 fn_2b70db0
02d115a4: adrp    x0, #0x6269000                             
02d115a8: ldr     x0, [x0, #0x790]                           T:type58823(k15)
02d115ac: bl      #0x2b70db0                                 fn_2b70db0
02d115b0: adrp    x0, #0x6269000                             
02d115b4: ldr     x0, [x0, #0x798]                           MS:UnityEngine.Events.UnityEvent`1::AddListener
02d115b8: bl      #0x2b70db0                                 fn_2b70db0
02d115bc: mov     w8, #1                                     
02d115c0: strb    w8, [x20, #0xfb5]                          
02d115c4: ldr     x8, [x19, #0x20]                           ._inputField
02d115c8: cbz     x8, #0x2d11620                             
02d115cc: adrp    x9, #0x6269000                             
02d115d0: adrp    x21, #0x6269000                            
02d115d4: ldr     x9, [x9, #0x790]                           T:type58823(k15)
02d115d8: ldr     x21, [x21, #0x788]                         M:Livestream.ChatInput::<OnInit>b__2_0
02d115dc: ldr     x20, [x8, #0x1a0]                          
02d115e0: ldr     x0, [x9]                                   T:Trading.TradingSession/<>c__DisplayClass56_0
02d115e4: bl      #0x2b7104c                                 fn_2b7104c
02d115e8: ldr     x2, [x21]                                  T:Trading.TradingSession/<>c__DisplayClass56_0
02d115ec: mov     x1, x19                                    
02d115f0: mov     x3, xzr                                    
02d115f4: mov     x21, x0                                    
02d115f8: bl      #0x3edf9d4                                 fn_3edf9d4
02d115fc: cbz     x20, #0x2d11620                            
02d11600: adrp    x8, #0x6269000                             
02d11604: mov     x0, x20                                    
02d11608: mov     x1, x21                                    
02d1160c: ldr     x8, [x8, #0x798]                           MS:UnityEngine.Events.UnityEvent`1::AddListener
02d11610: ldp     x20, x19, [sp, #0x10]                      
02d11614: ldr     x2, [x8]                                   T:Trading.TradingSession/<>c__DisplayClass56_0
02d11618: ldp     x30, x21, [sp], #0x20                      
02d1161c: b       #0x3ee64cc                                 
02d11620: bl      #0x2b7105c                                 fn_2b7105c
## .ctor() -> void
---- Livestream.ChatInput::.ctor 0x2d11624
02d11624: mov     x1, xzr                                    
02d11628: b       #0x5b397b0                                 UnityEngine.MonoBehaviour::.ctor
## <OnInit>b__2_0(string x) -> void
---- Livestream.ChatInput::<OnInit>b__2_0 0x2d1162c
02d1162c: stp     x30, x21, [sp, #-0x20]!                    
02d11630: stp     x20, x19, [sp, #0x10]                      
02d11634: adrp    x21, #0x662f000                            
02d11638: mov     x20, x1                                    
02d1163c: mov     x19, x0                                    
02d11640: ldrb    w8, [x21, #0xfb6]                          
02d11644: tbnz    w8, #0, #0x2d1165c                         
02d11648: adrp    x0, #0x6263000                             
02d1164c: ldr     x0, [x0, #0xa90]                           S:''
02d11650: bl      #0x2b70db0                                 fn_2b70db0
02d11654: mov     w8, #1                                     
02d11658: strb    w8, [x21, #0xfb6]                          
02d1165c: ldr     x0, [x19, #0x28]                           ._commentHandler
02d11660: cbz     x0, #0x2d11694                             
02d11664: mov     x1, x20                                    
02d11668: mov     x2, xzr                                    
02d1166c: bl      #0x2cb6c58                                 CommentHandler::UserComment
02d11670: ldr     x0, [x19, #0x20]                           ._inputField
02d11674: cbz     x0, #0x2d11694                             
02d11678: adrp    x8, #0x6263000                             
02d1167c: mov     x2, xzr                                    
02d11680: ldr     x8, [x8, #0xa90]                           S:''
02d11684: ldp     x20, x19, [sp, #0x10]                      
02d11688: ldr     x1, [x8]                                   &2c5bbd4(=a9bd7bfdd503233f)
02d1168c: ldp     x30, x21, [sp], #0x20                      
02d11690: b       #0x5a6a094                                 TMPro.TMP_InputField::set_text
02d11694: bl      #0x2b7105c                                 fn_2b7105c
