#### CLASS DailyMission.RewardItemContent parent= object
#   field AssetName                      string                                             off=0x10 attr=6 
#   field ID                             int                                                off=0x18 attr=6 
#   field ID_AB                          int                                                off=0x1c attr=6 
## .ctor() -> void
---- DailyMission.RewardItemContent::.ctor 0x2d764b0
02d764b0: mov     x1, xzr                                    
02d764b4: b       #0x4e53e9c                                 System.Object::.ctor
