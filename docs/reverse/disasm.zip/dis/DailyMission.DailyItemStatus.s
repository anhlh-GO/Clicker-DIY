#### CLASS DailyMission.DailyItemStatus parent= int
#   field value__                        int                                                off=0x10 attr=606 
#   field Select                         DailyMission.DailyItemStatus                       off=0x0 attr=8056 
#   field Reward                         DailyMission.DailyItemStatus                       off=0x0 attr=8056 
#   field Unselect                       DailyMission.DailyItemStatus                       off=0x0 attr=8056 
