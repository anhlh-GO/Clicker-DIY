#### CLASS Assets.SimpleLocalization.Example parent= UnityEngine.MonoBehaviour
#   field FormattedText                  UnityEngine.UI.Text                                off=0x20 attr=6 
## Awake() -> void
---- Assets.SimpleLocalization.Example::Awake 0x2d79e34
02d79e34: sub     sp, sp, #0x50                              
02d79e38: str     x30, [sp, #0x10]                           
02d79e3c: stp     x24, x23, [sp, #0x20]                      
02d79e40: stp     x22, x21, [sp, #0x30]                      
02d79e44: stp     x20, x19, [sp, #0x40]                      
02d79e48: adrp    x20, #0x6630000                            
02d79e4c: adrp    x23, #0x6266000                            
02d79e50: mov     x19, x0                                    
02d79e54: ldrb    w8, [x20, #0x3fd]                          
02d79e58: ldr     x23, [x23, #0x9f0]                         T:Assets.SimpleLocalization.Scripts.LocalizationManager
02d79e5c: tbnz    w8, #0, #0x2d79ee0                         
02d79e60: adrp    x0, #0x6264000                             
02d79e64: ldr     x0, [x0, #0xf90]                           T:System.Action
02d79e68: bl      #0x2b70db0                                 fn_2b70db0
02d79e6c: adrp    x0, #0x6264000                             
02d79e70: ldr     x0, [x0, #0xa70]                           T:UnityEngine.Application
02d79e74: bl      #0x2b70db0                                 fn_2b70db0
02d79e78: adrp    x0, #0x626c000                             
02d79e7c: ldr     x0, [x0, #0xa40]                           M:Assets.SimpleLocalization.Example::<Awake>b__1_0
02d79e80: bl      #0x2b70db0                                 fn_2b70db0
02d79e84: adrp    x0, #0x6266000                             
02d79e88: ldr     x0, [x0, #0x9f0]                           T:Assets.SimpleLocalization.Scripts.LocalizationManager
02d79e8c: bl      #0x2b70db0                                 fn_2b70db0
02d79e90: adrp    x0, #0x6263000                             
02d79e94: ldr     x0, [x0, #0xa80]                           T:type24502(k1d)
02d79e98: bl      #0x2b70db0                                 fn_2b70db0
02d79e9c: adrp    x0, #0x6265000                             
02d79ea0: ldr     x0, [x0, #0xf98]                           T:System.TimeSpan
02d79ea4: bl      #0x2b70db0                                 fn_2b70db0
02d79ea8: adrp    x0, #0x626c000                             
02d79eac: ldr     x0, [x0, #0xa48]                           S:'Settings.Example.PlayTime'
02d79eb0: bl      #0x2b70db0                                 fn_2b70db0
02d79eb4: adrp    x0, #0x626c000                             
02d79eb8: ldr     x0, [x0, #0xa50]                           S:'Russian'
02d79ebc: bl      #0x2b70db0                                 fn_2b70db0
02d79ec0: adrp    x0, #0x626c000                             
02d79ec4: ldr     x0, [x0, #0xa58]                           S:'German'
02d79ec8: bl      #0x2b70db0                                 fn_2b70db0
02d79ecc: adrp    x0, #0x6266000                             
02d79ed0: ldr     x0, [x0, #0xbc0]                           S:'English'
02d79ed4: bl      #0x2b70db0                                 fn_2b70db0
02d79ed8: mov     w8, #1                                     
02d79edc: strb    w8, [x20, #0x3fd]                          
02d79ee0: ldr     x0, [x23]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d79ee4: adrp    x20, #0x6264000                            
02d79ee8: ldr     w8, [x0, #0xe4]                            [62660e4]=0 f=0,0
02d79eec: ldr     x20, [x20, #0xa70]                         T:UnityEngine.Application
02d79ef0: str     xzr, [sp, #0x18]                           
02d79ef4: cbnz    w8, #0x2d79efc                             
02d79ef8: bl      #0x2b70f30                                 fn_2b70f30
02d79efc: bl      #0x2d7a0b0                                 Assets.SimpleLocalization.Scripts.LocalizationManager::Read
02d79f00: ldr     x0, [x20]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d79f04: ldr     w8, [x0, #0xe4]                            [62660e4]=0 f=0,0
02d79f08: cbnz    w8, #0x2d79f10                             
02d79f0c: bl      #0x2b70f30                                 fn_2b70f30
02d79f10: adrp    x22, #0x6263000                            
02d79f14: adrp    x21, #0x6265000                            
02d79f18: mov     x0, xzr                                    
02d79f1c: ldr     x22, [x22, #0xa80]                         T:type24502(k1d)
02d79f20: ldr     x21, [x21, #0xf98]                         T:System.TimeSpan
02d79f24: bl      #0x5aeb2f0                                 UnityEngine.Application::get_systemLanguage
02d79f28: mov     w8, w0                                     
02d79f2c: ldr     x0, [x23]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d79f30: cmp     w8, #0x1e                                  
02d79f34: ldr     w9, [x0, #0xe4]                            [62660e4]=0 f=0,0
02d79f38: b.eq    #0x2d7a07c                                 
02d79f3c: cmp     w8, #0xf                                   
02d79f40: b.ne    #0x2d7a08c                                 
02d79f44: adrp    x20, #0x626c000                            
02d79f48: ldr     x20, [x20, #0xa58]                         S:'German'
02d79f4c: cbnz    w9, #0x2d79f54                             
02d79f50: bl      #0x2b70f30                                 fn_2b70f30
02d79f54: ldr     x0, [x20]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d79f58: bl      #0x2d7ac14                                 Assets.SimpleLocalization.Scripts.LocalizationManager::set_Language
02d79f5c: ldr     x0, [x22]                                  &2c5bbd4(=a9bd7bfdd503233f)
02d79f60: ldr     x20, [x19, #0x20]                          .FormattedText
02d79f64: mov     w1, #1                                     
02d79f68: bl      #0x2b70ea0                                 fn_2b70ea0
02d79f6c: ldr     x8, [x21]                                  M:AdsManager::<OnApplicationPause>b__26_0
02d79f70: mov     x21, x0                                    
02d79f74: ldr     w9, [x8, #0xe4]                            
02d79f78: cbnz    w9, #0x2d79f84                             
02d79f7c: mov     x0, x8                                     
02d79f80: bl      #0x2b70f30                                 fn_2b70f30
02d79f84: fmov    d0, #10.50000000                           
02d79f88: mov     x0, xzr                                    
02d79f8c: bl      #0x4e29790                                 System.TimeSpan::FromHours
02d79f90: str     x0, [sp, #0x18]                            
02d79f94: add     x0, sp, #0x18                              
02d79f98: mov     x1, xzr                                    
02d79f9c: bl      #0x4e293d4                                 System.TimeSpan::get_TotalHours
02d79fa0: adrp    x8, #0x6263000                             
02d79fa4: add     x1, sp, #8                                 
02d79fa8: ldr     x8, [x8, #0x970]                           &6645c70(=0)
02d79fac: str     d0, [sp, #8]                               
02d79fb0: ldr     x0, [x8, #0x80]                            &2c498bc(=aa1f03e0d503245f)
02d79fb4: bl      #0x2b70f38                                 fn_2b70f38
02d79fb8: cbz     x21, #0x2d7a09c                            
02d79fbc: mov     x22, x0                                    
02d79fc0: cbz     x0, #0x2d79fd8                             
02d79fc4: ldr     x8, [x21]                                  M:AdsManager::<OnApplicationPause>b__26_0
02d79fc8: mov     x0, x22                                    
02d79fcc: ldr     x1, [x8, #0x40]                            [6263040]=0 f=0,0
02d79fd0: bl      #0x2b70f34                                 fn_2b70f34
02d79fd4: cbz     x0, #0x2d7a0a4                             
02d79fd8: ldr     w8, [x21, #0x18]                           T:AdsManager/<IEHideAdResume>d__30
02d79fdc: cbz     w8, #0x2d7a0a0                             
02d79fe0: adrp    x24, #0x626c000                            
02d79fe4: mov     x0, x21                                    
02d79fe8: mov     x1, x22                                    
02d79fec: ldr     x24, [x24, #0xa48]                         S:'Settings.Example.PlayTime'
02d79ff0: str     x22, [x0, #0x20]!                          .FormattedText
02d79ff4: bl      #0x2b70d54                                 fn_2b70d54
02d79ff8: ldr     x0, [x23]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d79ffc: ldr     w8, [x0, #0xe4]                            [62660e4]=0 f=0,0
02d7a000: cbnz    w8, #0x2d7a008                             
02d7a004: bl      #0x2b70f30                                 fn_2b70f30
02d7a008: ldr     x0, [x24]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d7a00c: mov     x1, x21                                    
02d7a010: bl      #0x2d7ac98                                 Assets.SimpleLocalization.Scripts.LocalizationManager::Localize
02d7a014: cbz     x20, #0x2d7a09c                            
02d7a018: adrp    x21, #0x6264000                            
02d7a01c: adrp    x22, #0x626c000                            
02d7a020: mov     x1, x0                                     
02d7a024: ldr     x21, [x21, #0xf90]                         T:System.Action
02d7a028: ldr     x8, [x20]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d7a02c: ldr     x22, [x22, #0xa40]                         M:Assets.SimpleLocalization.Example::<Awake>b__1_0
02d7a030: mov     x0, x20                                    
02d7a034: ldr     x9, [x8, #0x5e8]                           &6260bd8(=0)
02d7a038: ldr     x2, [x8, #0x5f0]                           [62635f0]=0 f=0,0
02d7a03c: blr     x9                                         
02d7a040: ldr     x0, [x21]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d7a044: bl      #0x2b7104c                                 fn_2b7104c
02d7a048: ldr     x2, [x22]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d7a04c: mov     x1, x19                                    
02d7a050: mov     x3, xzr                                    
02d7a054: mov     x20, x0                                    
02d7a058: bl      #0x4d8ddbc                                 System.Action::.ctor
02d7a05c: mov     x0, x20                                    
02d7a060: bl      #0x2d7ad04                                 Assets.SimpleLocalization.Scripts.LocalizationManager::add_OnLocalizationChanged
02d7a064: ldp     x20, x19, [sp, #0x40]                      
02d7a068: ldr     x30, [sp, #0x10]                           
02d7a06c: ldp     x22, x21, [sp, #0x30]                      
02d7a070: ldp     x24, x23, [sp, #0x20]                      
02d7a074: add     sp, sp, #0x50                              
02d7a078: ret                                                
02d7a07c: adrp    x20, #0x626c000                            
02d7a080: ldr     x20, [x20, #0xa50]                         S:'Russian'
02d7a084: cbnz    w9, #0x2d79f54                             
02d7a088: b       #0x2d79f50                                 
02d7a08c: adrp    x20, #0x6266000                            
02d7a090: ldr     x20, [x20, #0xbc0]                         S:'English'
02d7a094: cbnz    w9, #0x2d79f54                             
02d7a098: b       #0x2d79f50                                 
02d7a09c: bl      #0x2b7105c                                 fn_2b7105c
02d7a0a0: bl      #0x2b71064                                 fn_2b71064
02d7a0a4: bl      #0x2b71080                                 fn_2b71080
02d7a0a8: mov     x1, xzr                                    
02d7a0ac: bl      #0x2b70f20                                 fn_2b70f20
## SetLocalization(string localization) -> void
---- Assets.SimpleLocalization.Example::SetLocalization 0x2d7addc
02d7addc: stp     x30, x21, [sp, #-0x20]!                    
02d7ade0: stp     x20, x19, [sp, #0x10]                      
02d7ade4: adrp    x20, #0x6630000                            
02d7ade8: adrp    x21, #0x6266000                            
02d7adec: mov     x19, x1                                    
02d7adf0: ldrb    w8, [x20, #0x3fe]                          
02d7adf4: ldr     x21, [x21, #0x9f0]                         T:Assets.SimpleLocalization.Scripts.LocalizationManager
02d7adf8: tbnz    w8, #0, #0x2d7ae10                         
02d7adfc: adrp    x0, #0x6266000                             
02d7ae00: ldr     x0, [x0, #0x9f0]                           T:Assets.SimpleLocalization.Scripts.LocalizationManager
02d7ae04: bl      #0x2b70db0                                 fn_2b70db0
02d7ae08: mov     w8, #1                                     
02d7ae0c: strb    w8, [x20, #0x3fe]                          
02d7ae10: ldr     x0, [x21]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d7ae14: ldr     w8, [x0, #0xe4]                            [62660e4]=0 f=0,0
02d7ae18: cbnz    w8, #0x2d7ae20                             
02d7ae1c: bl      #0x2b70f30                                 fn_2b70f30
02d7ae20: mov     x0, x19                                    
02d7ae24: ldp     x20, x19, [sp, #0x10]                      
02d7ae28: ldp     x30, x21, [sp], #0x20                      
02d7ae2c: b       #0x2d7ac14                                 Assets.SimpleLocalization.Scripts.LocalizationManager::set_Language
## Review() -> void
---- Assets.SimpleLocalization.Example::Review 0x2d7ae30
02d7ae30: str     x30, [sp, #-0x20]!                         
02d7ae34: stp     x20, x19, [sp, #0x10]                      
02d7ae38: adrp    x20, #0x6630000                            
02d7ae3c: adrp    x19, #0x6264000                            
02d7ae40: ldrb    w8, [x20, #0x3ff]                          
02d7ae44: ldr     x19, [x19, #0xa70]                         T:UnityEngine.Application
02d7ae48: tbnz    w8, #0, #0x2d7ae6c                         
02d7ae4c: adrp    x0, #0x6264000                             
02d7ae50: ldr     x0, [x0, #0xa70]                           T:UnityEngine.Application
02d7ae54: bl      #0x2b70db0                                 fn_2b70db0
02d7ae58: adrp    x0, #0x626c000                             
02d7ae5c: ldr     x0, [x0, #0xb00]                           S:'https://www.assetstore.unity3d.com/#!/content/120113'
02d7ae60: bl      #0x2b70db0                                 fn_2b70db0
02d7ae64: mov     w8, #1                                     
02d7ae68: strb    w8, [x20, #0x3ff]                          
02d7ae6c: ldr     x0, [x19]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d7ae70: adrp    x19, #0x626c000                            
02d7ae74: ldr     w8, [x0, #0xe4]                            [626c0e4]=0 f=0,0
02d7ae78: ldr     x19, [x19, #0xb00]                         S:'https://www.assetstore.unity3d.com/#!/content/120113'
02d7ae7c: cbnz    w8, #0x2d7ae84                             
02d7ae80: bl      #0x2b70f30                                 fn_2b70f30
02d7ae84: ldr     x0, [x19]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d7ae88: ldp     x20, x19, [sp, #0x10]                      
02d7ae8c: mov     x1, xzr                                    
02d7ae90: ldr     x30, [sp], #0x20                           
02d7ae94: b       #0x5aeaf10                                 UnityEngine.Application::OpenURL
## .ctor() -> void
---- Assets.SimpleLocalization.Example::.ctor 0x2d7ae98
02d7ae98: mov     x1, xzr                                    
02d7ae9c: b       #0x5b397b0                                 UnityEngine.MonoBehaviour::.ctor
## <Awake>b__1_0() -> void
---- Assets.SimpleLocalization.Example::<Awake>b__1_0 0x2d7aea0
02d7aea0: sub     sp, sp, #0x40                              
02d7aea4: stp     x30, x23, [sp, #0x10]                      
02d7aea8: stp     x22, x21, [sp, #0x20]                      
02d7aeac: stp     x20, x19, [sp, #0x30]                      
02d7aeb0: adrp    x22, #0x6630000                            
02d7aeb4: adrp    x21, #0x6263000                            
02d7aeb8: adrp    x20, #0x6265000                            
02d7aebc: ldrb    w8, [x22, #0x400]                          
02d7aec0: ldr     x21, [x21, #0xa80]                         T:type24502(k1d)
02d7aec4: ldr     x20, [x20, #0xf98]                         T:System.TimeSpan
02d7aec8: mov     x19, x0                                    
02d7aecc: tbnz    w8, #0, #0x2d7af08                         
02d7aed0: adrp    x0, #0x6266000                             
02d7aed4: ldr     x0, [x0, #0x9f0]                           T:Assets.SimpleLocalization.Scripts.LocalizationManager
02d7aed8: bl      #0x2b70db0                                 fn_2b70db0
02d7aedc: adrp    x0, #0x6263000                             
02d7aee0: ldr     x0, [x0, #0xa80]                           T:type24502(k1d)
02d7aee4: bl      #0x2b70db0                                 fn_2b70db0
02d7aee8: adrp    x0, #0x6265000                             
02d7aeec: ldr     x0, [x0, #0xf98]                           T:System.TimeSpan
02d7aef0: bl      #0x2b70db0                                 fn_2b70db0
02d7aef4: adrp    x0, #0x626c000                             
02d7aef8: ldr     x0, [x0, #0xa48]                           S:'Settings.Example.PlayTime'
02d7aefc: bl      #0x2b70db0                                 fn_2b70db0
02d7af00: mov     w8, #1                                     
02d7af04: strb    w8, [x22, #0x400]                          
02d7af08: ldr     x0, [x21]                                  &2c5bbd4(=a9bd7bfdd503233f)
02d7af0c: ldr     x19, [x19, #0x20]                          .FormattedText
02d7af10: mov     w1, #1                                     
02d7af14: str     xzr, [sp, #8]                              
02d7af18: bl      #0x2b70ea0                                 fn_2b70ea0
02d7af1c: ldr     x8, [x20]                                  M:AdsManager::<OnApplicationPause>b__26_0
02d7af20: mov     x20, x0                                    
02d7af24: ldr     w9, [x8, #0xe4]                            
02d7af28: cbnz    w9, #0x2d7af34                             
02d7af2c: mov     x0, x8                                     
02d7af30: bl      #0x2b70f30                                 fn_2b70f30
02d7af34: fmov    d0, #10.50000000                           
02d7af38: mov     x0, xzr                                    
02d7af3c: bl      #0x4e29790                                 System.TimeSpan::FromHours
02d7af40: str     x0, [sp, #8]                               
02d7af44: add     x0, sp, #8                                 
02d7af48: mov     x1, xzr                                    
02d7af4c: bl      #0x4e293d4                                 System.TimeSpan::get_TotalHours
02d7af50: adrp    x8, #0x6263000                             
02d7af54: mov     x1, sp                                     
02d7af58: ldr     x8, [x8, #0x970]                           &6645c70(=0)
02d7af5c: str     d0, [sp]                                   
02d7af60: ldr     x0, [x8, #0x80]                            &2c498bc(=aa1f03e0d503245f)
02d7af64: bl      #0x2b70f38                                 fn_2b70f38
02d7af68: cbz     x20, #0x2d7affc                            
02d7af6c: mov     x21, x0                                    
02d7af70: cbz     x0, #0x2d7af88                             
02d7af74: ldr     x8, [x20]                                  M:AdsManager::<OnApplicationPause>b__26_0
02d7af78: mov     x0, x21                                    
02d7af7c: ldr     x1, [x8, #0x40]                            [6263040]=0 f=0,0
02d7af80: bl      #0x2b70f34                                 fn_2b70f34
02d7af84: cbz     x0, #0x2d7b004                             
02d7af88: ldr     w8, [x20, #0x18]                           T:AdsManager/<IEHideAdResume>d__30
02d7af8c: cbz     w8, #0x2d7b000                             
02d7af90: adrp    x23, #0x6266000                            
02d7af94: adrp    x22, #0x626c000                            
02d7af98: mov     x0, x20                                    
02d7af9c: ldr     x23, [x23, #0x9f0]                         T:Assets.SimpleLocalization.Scripts.LocalizationManager
02d7afa0: ldr     x22, [x22, #0xa48]                         S:'Settings.Example.PlayTime'
02d7afa4: mov     x1, x21                                    
02d7afa8: str     x21, [x0, #0x20]!                          .FormattedText
02d7afac: bl      #0x2b70d54                                 fn_2b70d54
02d7afb0: ldr     x0, [x23]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d7afb4: ldr     w8, [x0, #0xe4]                            [626c0e4]=0 f=0,0
02d7afb8: cbnz    w8, #0x2d7afc0                             
02d7afbc: bl      #0x2b70f30                                 fn_2b70f30
02d7afc0: ldr     x0, [x22]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d7afc4: mov     x1, x20                                    
02d7afc8: bl      #0x2d7ac98                                 Assets.SimpleLocalization.Scripts.LocalizationManager::Localize
02d7afcc: cbz     x19, #0x2d7affc                            
02d7afd0: ldr     x8, [x19]                                  
02d7afd4: mov     x1, x0                                     
02d7afd8: mov     x0, x19                                    
02d7afdc: ldr     x9, [x8, #0x5e8]                           &6260bd8(=0)
02d7afe0: ldr     x2, [x8, #0x5f0]                           [62635f0]=0 f=0,0
02d7afe4: blr     x9                                         
02d7afe8: ldp     x20, x19, [sp, #0x30]                      
02d7afec: ldp     x22, x21, [sp, #0x20]                      
02d7aff0: ldp     x30, x23, [sp, #0x10]                      
02d7aff4: add     sp, sp, #0x40                              
02d7aff8: ret                                                
02d7affc: bl      #0x2b7105c                                 fn_2b7105c
02d7b000: bl      #0x2b71064                                 fn_2b71064
02d7b004: bl      #0x2b71080                                 fn_2b71080
02d7b008: mov     x1, xzr                                    
02d7b00c: bl      #0x2b70f20                                 fn_2b70f20
