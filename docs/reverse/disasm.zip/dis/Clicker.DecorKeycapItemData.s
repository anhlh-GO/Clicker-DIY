#### CLASS Clicker.DecorKeycapItemData parent= object
#   field Id                             int                                                off=0x10 attr=6 
#   field Icon                           UnityEngine.Sprite                                 off=0x18 attr=6 
#   field Type                           Clicker.DecorKeycapType                            off=0x20 attr=6 
#   field Rarity                         RarityType                                         off=0x24 attr=6 
#   field Sprite                         UnityEngine.Sprite                                 off=0x28 attr=6 
#   field UnlockMethod                   Clicker.UnlockMethod                               off=0x30 attr=6 
## .ctor() -> void
---- Clicker.DecorKeycapItemData::.ctor 0x2d5b7c8
02d5b7c8: mov     x1, xzr                                    
02d5b7cc: b       #0x4e53e9c                                 System.Object::.ctor
