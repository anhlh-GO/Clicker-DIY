#### CLASS IAPPayData parent= object
#   field Payload                        string                                             off=0x10 attr=6 
#   field Store                          string                                             off=0x18 attr=6 
#   field TransactionID                  string                                             off=0x20 attr=6 
## .ctor() -> void
---- IAPPayData::.ctor 0x2ca7f20
02ca7f20: mov     x1, xzr                                    
02ca7f24: b       #0x4e53e9c                                 System.Object::.ctor
