#### CLASS QuickContentChanger parent= UnityEngine.MonoBehaviour
#   field _isChange                      bool                                               off=0x20 attr=1 SerializeField
#   field _justImg                       bool                                               off=0x21 attr=1 HeaderAttribute,SerializeField
#   field _rootImg                       UnityEngine.UI.Image                               off=0x28 attr=1 ConditionalFieldAttribute,SerializeField
#   field _isSpriteRenderer              bool                                               off=0x30 attr=1 SerializeField
#   field _rootSrRenderer                UnityEngine.SpriteRenderer                         off=0x38 attr=1 ConditionalFieldAttribute,SerializeField
#   field _liveOpsSr                     UnityEngine.Sprite                                 off=0x40 attr=1 SpaceAttribute,HeaderAttribute,ConditionalFieldAttribute,SerializeField
#   field _defaultObj                    UnityEngine.GameObject                             off=0x48 attr=1 SpaceAttribute,ConditionalFieldAttribute,SerializeField
#   field _liveOpsObj                    UnityEngine.GameObject                             off=0x50 attr=1 ConditionalFieldAttribute,SerializeField
## Awake() -> void
---- QuickContentChanger::Awake 0x2cf2818
02cf2818: b       #0x2cf281c                                 QuickContentChanger::InitLiveops
## InitLiveops() -> void
---- QuickContentChanger::InitLiveops 0x2cf281c
02cf281c: ldrb    w8, [x0, #0x21]                            ._justImg
02cf2820: cbz     w8, #0x2cf2828                             
02cf2824: b       #0x2cf282c                                 QuickContentChanger::HandlerImg
02cf2828: b       #0x2cf284c                                 QuickContentChanger::HandlerObj
## HandlerImg() -> void
---- QuickContentChanger::HandlerImg 0x2cf282c
02cf282c: ldrb    w8, [x0, #0x20]                            ._isChange
02cf2830: cbz     w8, #0x2cf2844                             
02cf2834: ldrb    w8, [x0, #0x30]                            ._isSpriteRenderer
02cf2838: ldr     x1, [x0, #0x40]                            ._liveOpsSr
02cf283c: cbz     w8, #0x2cf2848                             
02cf2840: b       #0x2cf2930                                 QuickContentChanger::HandlerSpriteRenderer
02cf2844: ret                                                
02cf2848: b       #0x2cf29c8                                 QuickContentChanger::HandlerUI
## HandlerUI(UnityEngine.Sprite sprite) -> void
---- QuickContentChanger::HandlerUI 0x2cf29c8
02cf29c8: str     x30, [sp, #-0x30]!                         
02cf29cc: stp     x22, x21, [sp, #0x10]                      
02cf29d0: stp     x20, x19, [sp, #0x20]                      
02cf29d4: adrp    x22, #0x662f000                            
02cf29d8: adrp    x21, #0x6263000                            
02cf29dc: mov     x19, x1                                    
02cf29e0: ldrb    w8, [x22, #0xe6a]                          
02cf29e4: ldr     x21, [x21, #0x918]                         T:UnityEngine.Object
02cf29e8: mov     x20, x0                                    
02cf29ec: tbnz    w8, #0, #0x2cf2a04                         
02cf29f0: adrp    x0, #0x6263000                             
02cf29f4: ldr     x0, [x0, #0x918]                           T:UnityEngine.Object
02cf29f8: bl      #0x2b70db0                                 fn_2b70db0
02cf29fc: mov     w8, #1                                     
02cf2a00: strb    w8, [x22, #0xe6a]                          
02cf2a04: ldr     x0, [x21]                                  &2c5bbd4(=a9bd7bfdd503233f)
02cf2a08: ldr     x21, [x20, #0x28]                          ._rootImg
02cf2a0c: ldr     w8, [x0, #0xe4]                            [62630e4]=0 f=0,0
02cf2a10: cbnz    w8, #0x2cf2a18                             
02cf2a14: bl      #0x2b70f30                                 fn_2b70f30
02cf2a18: mov     x0, x21                                    
02cf2a1c: mov     x1, xzr                                    
02cf2a20: mov     x2, xzr                                    
02cf2a24: bl      #0x5b37d84                                 UnityEngine.Object::op_Equality
02cf2a28: tbz     w0, #0, #0x2cf2a3c                         
02cf2a2c: ldp     x20, x19, [sp, #0x20]                      
02cf2a30: ldp     x22, x21, [sp, #0x10]                      
02cf2a34: ldr     x30, [sp], #0x30                           
02cf2a38: ret                                                
02cf2a3c: ldr     x0, [x20, #0x28]                           ._rootImg
02cf2a40: cbz     x0, #0x2cf2a5c                             
02cf2a44: mov     x1, x19                                    
02cf2a48: ldp     x20, x19, [sp, #0x20]                      
02cf2a4c: ldp     x22, x21, [sp, #0x10]                      
02cf2a50: mov     x2, xzr                                    
02cf2a54: ldr     x30, [sp], #0x30                           
02cf2a58: b       #0x5c45aa0                                 UnityEngine.UI.Image::set_sprite
02cf2a5c: bl      #0x2b7105c                                 fn_2b7105c
## HandlerSpriteRenderer(UnityEngine.Sprite sprite) -> void
---- QuickContentChanger::HandlerSpriteRenderer 0x2cf2930
02cf2930: str     x30, [sp, #-0x30]!                         
02cf2934: stp     x22, x21, [sp, #0x10]                      
02cf2938: stp     x20, x19, [sp, #0x20]                      
02cf293c: adrp    x22, #0x662f000                            
02cf2940: adrp    x21, #0x6263000                            
02cf2944: mov     x19, x1                                    
02cf2948: ldrb    w8, [x22, #0xe6b]                          
02cf294c: ldr     x21, [x21, #0x918]                         T:UnityEngine.Object
02cf2950: mov     x20, x0                                    
02cf2954: tbnz    w8, #0, #0x2cf296c                         
02cf2958: adrp    x0, #0x6263000                             
02cf295c: ldr     x0, [x0, #0x918]                           T:UnityEngine.Object
02cf2960: bl      #0x2b70db0                                 fn_2b70db0
02cf2964: mov     w8, #1                                     
02cf2968: strb    w8, [x22, #0xe6b]                          
02cf296c: ldr     x0, [x21]                                  &2c5bbd4(=a9bd7bfdd503233f)
02cf2970: ldr     x21, [x20, #0x38]                          ._rootSrRenderer
02cf2974: ldr     w8, [x0, #0xe4]                            [62630e4]=0 f=0,0
02cf2978: cbnz    w8, #0x2cf2980                             
02cf297c: bl      #0x2b70f30                                 fn_2b70f30
02cf2980: mov     x0, x21                                    
02cf2984: mov     x1, xzr                                    
02cf2988: mov     x2, xzr                                    
02cf298c: bl      #0x5b37d84                                 UnityEngine.Object::op_Equality
02cf2990: tbz     w0, #0, #0x2cf29a4                         
02cf2994: ldp     x20, x19, [sp, #0x20]                      
02cf2998: ldp     x22, x21, [sp, #0x10]                      
02cf299c: ldr     x30, [sp], #0x30                           
02cf29a0: ret                                                
02cf29a4: ldr     x0, [x20, #0x38]                           ._rootSrRenderer
02cf29a8: cbz     x0, #0x2cf29c4                             
02cf29ac: mov     x1, x19                                    
02cf29b0: ldp     x20, x19, [sp, #0x20]                      
02cf29b4: ldp     x22, x21, [sp, #0x10]                      
02cf29b8: mov     x2, xzr                                    
02cf29bc: ldr     x30, [sp], #0x30                           
02cf29c0: b       #0x5ae6dcc                                 UnityEngine.SpriteRenderer::set_sprite
02cf29c4: bl      #0x2b7105c                                 fn_2b7105c
## HandlerObj() -> void
---- QuickContentChanger::HandlerObj 0x2cf284c
02cf284c: stp     x30, x21, [sp, #-0x20]!                    
02cf2850: stp     x20, x19, [sp, #0x10]                      
02cf2854: adrp    x20, #0x662f000                            
02cf2858: mov     x19, x0                                    
02cf285c: ldrb    w8, [x20, #0xe6c]                          
02cf2860: tbnz    w8, #0, #0x2cf2878                         
02cf2864: adrp    x0, #0x6263000                             
02cf2868: ldr     x0, [x0, #0x918]                           T:UnityEngine.Object
02cf286c: bl      #0x2b70db0                                 fn_2b70db0
02cf2870: mov     w8, #1                                     
02cf2874: strb    w8, [x20, #0xe6c]                          
02cf2878: ldrb    w8, [x19, #0x20]                           ._isChange
02cf287c: cbz     w8, #0x2cf28d8                             
02cf2880: adrp    x21, #0x6263000                            
02cf2884: ldr     x21, [x21, #0x918]                         T:UnityEngine.Object
02cf2888: ldr     x20, [x19, #0x48]                          ._defaultObj
02cf288c: ldr     x0, [x21]                                  &2c5bbd4(=a9bd7bfdd503233f)
02cf2890: ldr     w8, [x0, #0xe4]                            [62630e4]=0 f=0,0
02cf2894: cbnz    w8, #0x2cf289c                             
02cf2898: bl      #0x2b70f30                                 fn_2b70f30
02cf289c: mov     x0, x20                                    
02cf28a0: mov     x1, xzr                                    
02cf28a4: mov     x2, xzr                                    
02cf28a8: bl      #0x5b37d84                                 UnityEngine.Object::op_Equality
02cf28ac: tbnz    w0, #0, #0x2cf28d8                         
02cf28b0: ldr     x0, [x21]                                  &2c5bbd4(=a9bd7bfdd503233f)
02cf28b4: ldr     x20, [x19, #0x50]                          ._liveOpsObj
02cf28b8: ldr     w8, [x0, #0xe4]                            [62630e4]=0 f=0,0
02cf28bc: cbnz    w8, #0x2cf28c4                             
02cf28c0: bl      #0x2b70f30                                 fn_2b70f30
02cf28c4: mov     x0, x20                                    
02cf28c8: mov     x1, xzr                                    
02cf28cc: mov     x2, xzr                                    
02cf28d0: bl      #0x5b37d84                                 UnityEngine.Object::op_Equality
02cf28d4: tbz     w0, #0, #0x2cf28e4                         
02cf28d8: ldp     x20, x19, [sp, #0x10]                      
02cf28dc: ldp     x30, x21, [sp], #0x20                      
02cf28e0: ret                                                
02cf28e4: ldr     x0, [x19, #0x48]                           ._defaultObj
02cf28e8: cbz     x0, #0x2cf292c                             
02cf28ec: mov     x1, xzr                                    
02cf28f0: bl      #0x5b37654                                 UnityEngine.GameObject::get_gameObject
02cf28f4: cbz     x0, #0x2cf292c                             
02cf28f8: mov     w1, wzr                                    
02cf28fc: mov     x2, xzr                                    
02cf2900: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02cf2904: ldr     x0, [x19, #0x50]                           ._liveOpsObj
02cf2908: cbz     x0, #0x2cf292c                             
02cf290c: mov     x1, xzr                                    
02cf2910: bl      #0x5b37654                                 UnityEngine.GameObject::get_gameObject
02cf2914: cbz     x0, #0x2cf292c                             
02cf2918: ldp     x20, x19, [sp, #0x10]                      
02cf291c: mov     w1, #1                                     
02cf2920: mov     x2, xzr                                    
02cf2924: ldp     x30, x21, [sp], #0x20                      
02cf2928: b       #0x5b36b38                                 UnityEngine.GameObject::SetActive
02cf292c: bl      #0x2b7105c                                 fn_2b7105c
## .ctor() -> void
---- QuickContentChanger::.ctor 0x2cf2a60
02cf2a60: mov     x1, xzr                                    
02cf2a64: b       #0x5b397b0                                 UnityEngine.MonoBehaviour::.ctor
