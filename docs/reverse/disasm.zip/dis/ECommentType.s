#### CLASS ECommentType parent= int
#   field value__                        int                                                off=0x10 attr=606 
#   field None                           ECommentType                                       off=0x0 attr=8056 
#   field Donate                         ECommentType                                       off=0x0 attr=8056 
