#### CLASS BlindBagCollection.CollectionItemType parent= int
#   field value__                        int                                                off=0x10 attr=606 
#   field FullKeycap                     BlindBagCollection.CollectionItemType              off=0x0 attr=8056 
#   field Decor1                         BlindBagCollection.CollectionItemType              off=0x0 attr=8056 
#   field Decor2                         BlindBagCollection.CollectionItemType              off=0x0 attr=8056 
#   field Decor3                         BlindBagCollection.CollectionItemType              off=0x0 attr=8056 
#   field Decor4                         BlindBagCollection.CollectionItemType              off=0x0 attr=8056 
#   field Decor5                         BlindBagCollection.CollectionItemType              off=0x0 attr=8056 
#   field Decor6                         BlindBagCollection.CollectionItemType              off=0x0 attr=8056 
#   field Decor7                         BlindBagCollection.CollectionItemType              off=0x0 attr=8056 
#   field Decor8                         BlindBagCollection.CollectionItemType              off=0x0 attr=8056 
#   field Decor9                         BlindBagCollection.CollectionItemType              off=0x0 attr=8056 
#   field Decor10                        BlindBagCollection.CollectionItemType              off=0x0 attr=8056 
#   field Decor11                        BlindBagCollection.CollectionItemType              off=0x0 attr=8056 
#   field Decor12                        BlindBagCollection.CollectionItemType              off=0x0 attr=8056 
