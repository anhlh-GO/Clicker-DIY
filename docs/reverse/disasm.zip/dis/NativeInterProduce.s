#### CLASS NativeInterProduce parent= NativeProduceBase`1<NativeInterProduce>
## SetAdFormat() -> void
---- NativeInterProduce::SetAdFormat 0x2c9b5fc
02c9b5fc: mov     w8, #8                                     
02c9b600: str     w8, [x0, #0x34]                            
02c9b604: ret                                                
## Start() -> void
---- NativeInterProduce::Start 0x2c9b608
02c9b608: ldr     x8, [x0]                                   
02c9b60c: ldp     x2, x1, [x8, #0x188]                       
02c9b610: br      x2                                         
## .ctor() -> void
---- NativeInterProduce::.ctor 0x2c9b614
02c9b614: stp     x30, x21, [sp, #-0x20]!                    
02c9b618: stp     x20, x19, [sp, #0x10]                      
02c9b61c: adrp    x20, #0x662f000                            
02c9b620: adrp    x21, #0x6265000                            
02c9b624: mov     x19, x0                                    
02c9b628: ldrb    w8, [x20, #0xa3e]                          
02c9b62c: ldr     x21, [x21, #0xa88]                         MS:NativeProduceBase`1::.ctor
02c9b630: tbnz    w8, #0, #0x2c9b648                         
02c9b634: adrp    x0, #0x6265000                             
02c9b638: ldr     x0, [x0, #0xa88]                           MS:NativeProduceBase`1::.ctor
02c9b63c: bl      #0x2b70db0                                 fn_2b70db0
02c9b640: mov     w8, #1                                     
02c9b644: strb    w8, [x20, #0xa3e]                          
02c9b648: mov     x0, x19                                    
02c9b64c: ldp     x20, x19, [sp, #0x10]                      
02c9b650: ldr     x1, [x21]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9b654: ldp     x30, x21, [sp], #0x20                      
02c9b658: b       #0x38cf860                                 
