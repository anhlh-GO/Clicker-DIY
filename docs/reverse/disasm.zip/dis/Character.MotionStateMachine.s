#### CLASS Character.MotionStateMachine/<>c__DisplayClass26_0 parent= object
#   field <>4__this                      Character.MotionStateMachine                       off=0x10 attr=6 
#   field onCompleteCallback             System.Action                                      off=0x18 attr=6 
## .ctor() -> void
---- Character.MotionStateMachine/<>c__DisplayClass26_0::.ctor 0x2d76054
02d76054: mov     x1, xzr                                    
02d76058: b       #0x4e53e9c                                 System.Object::.ctor
## <ChangeState>b__0() -> void
---- Character.MotionStateMachine/<>c__DisplayClass26_0::<ChangeState>b__0 0x2d76064
02d76064: str     x30, [sp, #-0x20]!                         
02d76068: stp     x20, x19, [sp, #0x10]                      
02d7606c: adrp    x20, #0x6630000                            
02d76070: mov     x19, x0                                    
02d76074: ldrb    w8, [x20, #0x3d4]                          
02d76078: tbnz    w8, #0, #0x2d76090                         
02d7607c: adrp    x0, #0x626c000                             
02d76080: ldr     x0, [x0, #0x818]                           T:System.Threading.CancellationToken
02d76084: bl      #0x2b70db0                                 fn_2b70db0
02d76088: mov     w8, #1                                     
02d7608c: strb    w8, [x20, #0x3d4]                          
02d76090: ldr     x8, [x19, #0x10]                           .<>4__this
02d76094: str     xzr, [sp, #8]                              
02d76098: cbz     x8, #0x2d76100                             
02d7609c: ldr     x0, [x8, #0x88]                            
02d760a0: cbz     x0, #0x2d76100                             
02d760a4: adrp    x20, #0x626c000                            
02d760a8: mov     x1, xzr                                    
02d760ac: ldr     x20, [x20, #0x818]                         T:System.Threading.CancellationToken
02d760b0: bl      #0x4e75dd8                                 System.Threading.CancellationTokenSource::get_Token
02d760b4: ldr     x8, [x20]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d760b8: str     x0, [sp, #8]                               
02d760bc: ldr     w9, [x8, #0xe4]                            
02d760c0: cbnz    w9, #0x2d760cc                             
02d760c4: mov     x0, x8                                     
02d760c8: bl      #0x2b70f30                                 fn_2b70f30
02d760cc: add     x0, sp, #8                                 
02d760d0: mov     x1, xzr                                    
02d760d4: bl      #0x4e73474                                 System.Threading.CancellationToken::get_IsCancellationRequested
02d760d8: tbnz    w0, #0, #0x2d760f4                         
02d760dc: ldr     x8, [x19, #0x18]                           .onCompleteCallback
02d760e0: cbz     x8, #0x2d760f4                             
02d760e4: ldr     x9, [x8, #0x18]                            
02d760e8: ldr     x0, [x8, #0x40]                            
02d760ec: ldr     x1, [x8, #0x28]                            
02d760f0: blr     x9                                         
02d760f4: ldp     x20, x19, [sp, #0x10]                      
02d760f8: ldr     x30, [sp], #0x20                           
02d760fc: ret                                                
02d76100: bl      #0x2b7105c                                 fn_2b7105c
#### CLASS Character.MotionStateMachine parent= UnityEngine.MonoBehaviour
#   field _animator                      SpineAnimationHandler                              off=0x20 attr=1 SerializeField
#   field _characterMouth                UnityEngine.Transform                              off=0x28 attr=1 SerializeField
#   field _currentState                  Character.IState                                   off=0x30 attr=1 
#   field IdleState                      Character.SingleAnimationState                     off=0x38 attr=6 
#   field WaitState                      Character.SingleAnimationState                     off=0x40 attr=6 
#   field DrinkState                     Character.SingleAnimationState                     off=0x48 attr=6 
#   field SpicyState                     Character.SingleAnimationState                     off=0x50 attr=6 
#   field SurpriseState                  Character.SingleAnimationState                     off=0x58 attr=6 
#   field SourState                      Character.SingleAnimationState                     off=0x60 attr=6 
#   field CoolState                      Character.SingleAnimationState                     off=0x68 attr=6 
#   field HappyState                     Character.RandomAnimationState                     off=0x70 attr=6 
#   field EatFoodState                   Character.RandomAnimationState                     off=0x78 attr=6 
#   field CuteState                      Character.RandomAnimationState                     off=0x80 attr=6 
#   field _cancellationTokenSource       System.Threading.CancellationTokenSource           off=0x88 attr=1 
#   field _eatFoodAnims                  System.Collections.Generic.List`1<EAnimationSpineType> off=0x90 attr=1 
## get_CharacterMouth() -> UnityEngine.Transform
---- Character.MotionStateMachine::get_CharacterMouth 0x2d74e38
02d74e38: ldr     x0, [x0, #0x28]                            ._characterMouth
02d74e3c: ret                                                
## get_Animator() -> SpineAnimationHandler
---- Character.MotionStateMachine::get_Animator 0x2d74e40
02d74e40: ldr     x0, [x0, #0x20]                            ._animator
02d74e44: ret                                                
## Awake() -> void
---- Character.MotionStateMachine::Awake 0x2d74e48
02d74e48: b       #0x2d74e4c                                 Character.MotionStateMachine::InitAnimation
## InitAnimation() -> void
---- Character.MotionStateMachine::InitAnimation 0x2d74e4c
02d74e4c: stp     x30, x27, [sp, #-0x50]!                    
02d74e50: stp     x26, x25, [sp, #0x10]                      
02d74e54: stp     x24, x23, [sp, #0x20]                      
02d74e58: stp     x22, x21, [sp, #0x30]                      
02d74e5c: stp     x20, x19, [sp, #0x40]                      
02d74e60: adrp    x20, #0x6630000                            
02d74e64: adrp    x24, #0x626c000                            
02d74e68: adrp    x22, #0x626c000                            
02d74e6c: ldrb    w8, [x20, #0x3d0]                          
02d74e70: ldr     x24, [x24, #0x7a8]                         T:type14941(k15)
02d74e74: ldr     x22, [x22, #0x7b0]                         MS:System.Collections.Generic.List`1::.ctor
02d74e78: mov     x19, x0                                    
02d74e7c: tbnz    w8, #0, #0x2d74ef4                         
02d74e80: adrp    x0, #0x626c000                             
02d74e84: ldr     x0, [x0, #0x7b8]                           MS:Character.BaseState::Initialize
02d74e88: bl      #0x2b70db0                                 fn_2b70db0
02d74e8c: adrp    x0, #0x626c000                             
02d74e90: ldr     x0, [x0, #0x7c0]                           MS:Character.BaseState::Initialize
02d74e94: bl      #0x2b70db0                                 fn_2b70db0
02d74e98: adrp    x0, #0x626c000                             
02d74e9c: ldr     x0, [x0, #0x7c8]                           MS:Character.BaseState::SetAnimationType
02d74ea0: bl      #0x2b70db0                                 fn_2b70db0
02d74ea4: adrp    x0, #0x626c000                             
02d74ea8: ldr     x0, [x0, #0x7d0]                           MS:System.Collections.Generic.List`1::Add
02d74eac: bl      #0x2b70db0                                 fn_2b70db0
02d74eb0: adrp    x0, #0x626c000                             
02d74eb4: ldr     x0, [x0, #0x7b0]                           MS:System.Collections.Generic.List`1::.ctor
02d74eb8: bl      #0x2b70db0                                 fn_2b70db0
02d74ebc: adrp    x0, #0x626c000                             
02d74ec0: ldr     x0, [x0, #0x7a8]                           T:type14941(k15)
02d74ec4: bl      #0x2b70db0                                 fn_2b70db0
02d74ec8: adrp    x0, #0x626c000                             
02d74ecc: ldr     x0, [x0, #0x7d8]                           MS:Character.RandomAnimationState::SetAnimationTypes
02d74ed0: bl      #0x2b70db0                                 fn_2b70db0
02d74ed4: adrp    x0, #0x626c000                             
02d74ed8: ldr     x0, [x0, #0x7e0]                           T:Character.RandomAnimationState
02d74edc: bl      #0x2b70db0                                 fn_2b70db0
02d74ee0: adrp    x0, #0x626c000                             
02d74ee4: ldr     x0, [x0, #0x7e8]                           T:Character.SingleAnimationState
02d74ee8: bl      #0x2b70db0                                 fn_2b70db0
02d74eec: mov     w8, #1                                     
02d74ef0: strb    w8, [x20, #0x3d0]                          
02d74ef4: ldr     x0, [x24]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d74ef8: bl      #0x2b7104c                                 fn_2b7104c
02d74efc: ldr     x1, [x22]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d74f00: mov     x20, x0                                    
02d74f04: bl      #0x356bce8                                 fn_356bce8
02d74f08: cbz     x20, #0x2d75c08                            
02d74f0c: adrp    x23, #0x626c000                            
02d74f10: ldr     x23, [x23, #0x7d0]                         MS:System.Collections.Generic.List`1::Add
02d74f14: ldr     w10, [x20, #0x1c]                          
02d74f18: ldr     x8, [x20, #0x10]                           
02d74f1c: ldr     x9, [x23]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d74f20: add     w10, w10, #1                               
02d74f24: str     w10, [x20, #0x1c]                          
02d74f28: cbz     x8, #0x2d75c08                             
02d74f2c: ldrsw   x10, [x20, #0x18]                          
02d74f30: ldr     w11, [x8, #0x18]                           
02d74f34: cmp     w10, w11                                   
02d74f38: b.hs    #0x2d74f5c                                 
02d74f3c: add     w11, w10, #1                               
02d74f40: add     x10, x8, x10, lsl #2                       
02d74f44: str     w11, [x20, #0x18]                          
02d74f48: str     wzr, [x10, #0x20]                          
02d74f4c: ldr     w10, [x20, #0x1c]                          
02d74f50: add     w10, w10, #1                               
02d74f54: str     w10, [x20, #0x1c]                          
02d74f58: b       #0x2d74f8c                                 
02d74f5c: ldr     x8, [x9, #0x20]                            
02d74f60: mov     x0, x20                                    
02d74f64: mov     w1, wzr                                    
02d74f68: ldr     x8, [x8, #0xc0]                            
02d74f6c: ldr     x2, [x8, #0x70]                            
02d74f70: bl      #0x356c578                                 fn_356c578
02d74f74: ldr     w10, [x20, #0x1c]                          
02d74f78: ldr     x8, [x20, #0x10]                           
02d74f7c: ldr     x9, [x23]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d74f80: add     w10, w10, #1                               
02d74f84: str     w10, [x20, #0x1c]                          
02d74f88: cbz     x8, #0x2d75c08                             
02d74f8c: ldrsw   x10, [x20, #0x18]                          
02d74f90: ldr     w11, [x8, #0x18]                           
02d74f94: cmp     w10, w11                                   
02d74f98: b.hs    #0x2d74fc0                                 
02d74f9c: add     w11, w10, #1                               
02d74fa0: add     x10, x8, x10, lsl #2                       
02d74fa4: str     w11, [x20, #0x18]                          
02d74fa8: mov     w11, #0x15                                 
02d74fac: str     w11, [x10, #0x20]                          
02d74fb0: ldr     w10, [x20, #0x1c]                          
02d74fb4: add     w10, w10, #1                               
02d74fb8: str     w10, [x20, #0x1c]                          
02d74fbc: b       #0x2d74ff0                                 
02d74fc0: ldr     x8, [x9, #0x20]                            
02d74fc4: mov     x0, x20                                    
02d74fc8: mov     w1, #0x15                                  
02d74fcc: ldr     x8, [x8, #0xc0]                            
02d74fd0: ldr     x2, [x8, #0x70]                            
02d74fd4: bl      #0x356c578                                 fn_356c578
02d74fd8: ldr     w10, [x20, #0x1c]                          
02d74fdc: ldr     x8, [x20, #0x10]                           
02d74fe0: ldr     x9, [x23]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d74fe4: add     w10, w10, #1                               
02d74fe8: str     w10, [x20, #0x1c]                          
02d74fec: cbz     x8, #0x2d75c08                             
02d74ff0: ldrsw   x10, [x20, #0x18]                          
02d74ff4: ldr     w11, [x8, #0x18]                           
02d74ff8: cmp     w10, w11                                   
02d74ffc: b.hs    #0x2d75024                                 
02d75000: add     w11, w10, #1                               
02d75004: add     x10, x8, x10, lsl #2                       
02d75008: str     w11, [x20, #0x18]                          
02d7500c: mov     w11, #0xd                                  
02d75010: str     w11, [x10, #0x20]                          
02d75014: ldr     w10, [x20, #0x1c]                          
02d75018: add     w10, w10, #1                               
02d7501c: str     w10, [x20, #0x1c]                          
02d75020: b       #0x2d75054                                 
02d75024: ldr     x8, [x9, #0x20]                            
02d75028: mov     x0, x20                                    
02d7502c: mov     w1, #0xd                                   
02d75030: ldr     x8, [x8, #0xc0]                            
02d75034: ldr     x2, [x8, #0x70]                            
02d75038: bl      #0x356c578                                 fn_356c578
02d7503c: ldr     w10, [x20, #0x1c]                          
02d75040: ldr     x8, [x20, #0x10]                           
02d75044: ldr     x9, [x23]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d75048: add     w10, w10, #1                               
02d7504c: str     w10, [x20, #0x1c]                          
02d75050: cbz     x8, #0x2d75c08                             
02d75054: ldrsw   x10, [x20, #0x18]                          
02d75058: ldr     w11, [x8, #0x18]                           
02d7505c: cmp     w10, w11                                   
02d75060: b.hs    #0x2d75088                                 
02d75064: add     w11, w10, #1                               
02d75068: add     x10, x8, x10, lsl #2                       
02d7506c: str     w11, [x20, #0x18]                          
02d75070: mov     w11, #0xe                                  
02d75074: str     w11, [x10, #0x20]                          
02d75078: ldr     w10, [x20, #0x1c]                          
02d7507c: add     w10, w10, #1                               
02d75080: str     w10, [x20, #0x1c]                          
02d75084: b       #0x2d750b8                                 
02d75088: ldr     x8, [x9, #0x20]                            
02d7508c: mov     x0, x20                                    
02d75090: mov     w1, #0xe                                   
02d75094: ldr     x8, [x8, #0xc0]                            
02d75098: ldr     x2, [x8, #0x70]                            
02d7509c: bl      #0x356c578                                 fn_356c578
02d750a0: ldr     w10, [x20, #0x1c]                          
02d750a4: ldr     x8, [x20, #0x10]                           
02d750a8: ldr     x9, [x23]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d750ac: add     w10, w10, #1                               
02d750b0: str     w10, [x20, #0x1c]                          
02d750b4: cbz     x8, #0x2d75c08                             
02d750b8: ldrsw   x10, [x20, #0x18]                          
02d750bc: ldr     w11, [x8, #0x18]                           
02d750c0: cmp     w10, w11                                   
02d750c4: b.hs    #0x2d750ec                                 
02d750c8: add     w11, w10, #1                               
02d750cc: add     x10, x8, x10, lsl #2                       
02d750d0: str     w11, [x20, #0x18]                          
02d750d4: mov     w11, #0xf                                  
02d750d8: str     w11, [x10, #0x20]                          
02d750dc: ldr     w10, [x20, #0x1c]                          
02d750e0: add     w10, w10, #1                               
02d750e4: str     w10, [x20, #0x1c]                          
02d750e8: b       #0x2d7511c                                 
02d750ec: ldr     x8, [x9, #0x20]                            
02d750f0: mov     x0, x20                                    
02d750f4: mov     w1, #0xf                                   
02d750f8: ldr     x8, [x8, #0xc0]                            
02d750fc: ldr     x2, [x8, #0x70]                            
02d75100: bl      #0x356c578                                 fn_356c578
02d75104: ldr     w10, [x20, #0x1c]                          
02d75108: ldr     x8, [x20, #0x10]                           
02d7510c: ldr     x9, [x23]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d75110: add     w10, w10, #1                               
02d75114: str     w10, [x20, #0x1c]                          
02d75118: cbz     x8, #0x2d75c08                             
02d7511c: ldrsw   x10, [x20, #0x18]                          
02d75120: ldr     w11, [x8, #0x18]                           
02d75124: cmp     w10, w11                                   
02d75128: b.hs    #0x2d75150                                 
02d7512c: add     w11, w10, #1                               
02d75130: add     x10, x8, x10, lsl #2                       
02d75134: str     w11, [x20, #0x18]                          
02d75138: mov     w11, #0x10                                 
02d7513c: str     w11, [x10, #0x20]                          
02d75140: ldr     w10, [x20, #0x1c]                          
02d75144: add     w10, w10, #1                               
02d75148: str     w10, [x20, #0x1c]                          
02d7514c: b       #0x2d75180                                 
02d75150: ldr     x8, [x9, #0x20]                            
02d75154: mov     x0, x20                                    
02d75158: mov     w1, #0x10                                  
02d7515c: ldr     x8, [x8, #0xc0]                            
02d75160: ldr     x2, [x8, #0x70]                            
02d75164: bl      #0x356c578                                 fn_356c578
02d75168: ldr     w10, [x20, #0x1c]                          
02d7516c: ldr     x8, [x20, #0x10]                           
02d75170: ldr     x9, [x23]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d75174: add     w10, w10, #1                               
02d75178: str     w10, [x20, #0x1c]                          
02d7517c: cbz     x8, #0x2d75c08                             
02d75180: ldrsw   x10, [x20, #0x18]                          
02d75184: ldr     w11, [x8, #0x18]                           
02d75188: cmp     w10, w11                                   
02d7518c: b.hs    #0x2d751b4                                 
02d75190: add     w11, w10, #1                               
02d75194: add     x10, x8, x10, lsl #2                       
02d75198: str     w11, [x20, #0x18]                          
02d7519c: mov     w11, #0x11                                 
02d751a0: str     w11, [x10, #0x20]                          
02d751a4: ldr     w10, [x20, #0x1c]                          
02d751a8: add     w10, w10, #1                               
02d751ac: str     w10, [x20, #0x1c]                          
02d751b0: b       #0x2d751e4                                 
02d751b4: ldr     x8, [x9, #0x20]                            
02d751b8: mov     x0, x20                                    
02d751bc: mov     w1, #0x11                                  
02d751c0: ldr     x8, [x8, #0xc0]                            
02d751c4: ldr     x2, [x8, #0x70]                            
02d751c8: bl      #0x356c578                                 fn_356c578
02d751cc: ldr     w10, [x20, #0x1c]                          
02d751d0: ldr     x8, [x20, #0x10]                           
02d751d4: ldr     x9, [x23]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d751d8: add     w10, w10, #1                               
02d751dc: str     w10, [x20, #0x1c]                          
02d751e0: cbz     x8, #0x2d75c08                             
02d751e4: ldrsw   x10, [x20, #0x18]                          
02d751e8: ldr     w11, [x8, #0x18]                           
02d751ec: cmp     w10, w11                                   
02d751f0: b.hs    #0x2d75218                                 
02d751f4: add     w11, w10, #1                               
02d751f8: add     x10, x8, x10, lsl #2                       
02d751fc: str     w11, [x20, #0x18]                          
02d75200: mov     w11, #0x12                                 
02d75204: str     w11, [x10, #0x20]                          
02d75208: ldr     w10, [x20, #0x1c]                          
02d7520c: add     w10, w10, #1                               
02d75210: str     w10, [x20, #0x1c]                          
02d75214: b       #0x2d75248                                 
02d75218: ldr     x8, [x9, #0x20]                            
02d7521c: mov     x0, x20                                    
02d75220: mov     w1, #0x12                                  
02d75224: ldr     x8, [x8, #0xc0]                            
02d75228: ldr     x2, [x8, #0x70]                            
02d7522c: bl      #0x356c578                                 fn_356c578
02d75230: ldr     w10, [x20, #0x1c]                          
02d75234: ldr     x8, [x20, #0x10]                           
02d75238: ldr     x9, [x23]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d7523c: add     w10, w10, #1                               
02d75240: str     w10, [x20, #0x1c]                          
02d75244: cbz     x8, #0x2d75c08                             
02d75248: ldrsw   x10, [x20, #0x18]                          
02d7524c: ldr     w11, [x8, #0x18]                           
02d75250: cmp     w10, w11                                   
02d75254: b.hs    #0x2d7527c                                 
02d75258: add     w11, w10, #1                               
02d7525c: add     x10, x8, x10, lsl #2                       
02d75260: str     w11, [x20, #0x18]                          
02d75264: mov     w11, #0x13                                 
02d75268: str     w11, [x10, #0x20]                          
02d7526c: ldr     w10, [x20, #0x1c]                          
02d75270: add     w10, w10, #1                               
02d75274: str     w10, [x20, #0x1c]                          
02d75278: b       #0x2d752ac                                 
02d7527c: ldr     x8, [x9, #0x20]                            
02d75280: mov     x0, x20                                    
02d75284: mov     w1, #0x13                                  
02d75288: ldr     x8, [x8, #0xc0]                            
02d7528c: ldr     x2, [x8, #0x70]                            
02d75290: bl      #0x356c578                                 fn_356c578
02d75294: ldr     w10, [x20, #0x1c]                          
02d75298: ldr     x8, [x20, #0x10]                           
02d7529c: ldr     x9, [x23]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d752a0: add     w10, w10, #1                               
02d752a4: str     w10, [x20, #0x1c]                          
02d752a8: cbz     x8, #0x2d75c08                             
02d752ac: ldrsw   x10, [x20, #0x18]                          
02d752b0: ldr     w11, [x8, #0x18]                           
02d752b4: cmp     w10, w11                                   
02d752b8: b.hs    #0x2d752d4                                 
02d752bc: add     w9, w10, #1                                
02d752c0: add     x8, x8, x10, lsl #2                        
02d752c4: str     w9, [x20, #0x18]                           
02d752c8: mov     w9, #0x14                                  
02d752cc: str     w9, [x8, #0x20]                            
02d752d0: b       #0x2d752ec                                 
02d752d4: ldr     x8, [x9, #0x20]                            
02d752d8: mov     x0, x20                                    
02d752dc: mov     w1, #0x14                                  
02d752e0: ldr     x8, [x8, #0xc0]                            
02d752e4: ldr     x2, [x8, #0x70]                            
02d752e8: bl      #0x356c578                                 fn_356c578
02d752ec: ldr     x0, [x24]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d752f0: bl      #0x2b7104c                                 fn_2b7104c
02d752f4: ldr     x1, [x22]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d752f8: mov     x21, x0                                    
02d752fc: bl      #0x356bce8                                 fn_356bce8
02d75300: cbz     x21, #0x2d75c08                            
02d75304: ldr     w10, [x21, #0x1c]                          
02d75308: ldr     x8, [x21, #0x10]                           
02d7530c: ldr     x9, [x23]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d75310: add     w10, w10, #1                               
02d75314: str     w10, [x21, #0x1c]                          
02d75318: cbz     x8, #0x2d75c08                             
02d7531c: ldrsw   x10, [x21, #0x18]                          
02d75320: ldr     w11, [x8, #0x18]                           
02d75324: cmp     w10, w11                                   
02d75328: b.hs    #0x2d75350                                 
02d7532c: add     w11, w10, #1                               
02d75330: add     x10, x8, x10, lsl #2                       
02d75334: str     w11, [x21, #0x18]                          
02d75338: mov     w11, #0x17                                 
02d7533c: str     w11, [x10, #0x20]                          
02d75340: ldr     w10, [x21, #0x1c]                          
02d75344: add     w10, w10, #1                               
02d75348: str     w10, [x21, #0x1c]                          
02d7534c: b       #0x2d75380                                 
02d75350: ldr     x8, [x9, #0x20]                            
02d75354: mov     x0, x21                                    
02d75358: mov     w1, #0x17                                  
02d7535c: ldr     x8, [x8, #0xc0]                            
02d75360: ldr     x2, [x8, #0x70]                            
02d75364: bl      #0x356c578                                 fn_356c578
02d75368: ldr     w10, [x21, #0x1c]                          
02d7536c: ldr     x8, [x21, #0x10]                           
02d75370: ldr     x9, [x23]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d75374: add     w10, w10, #1                               
02d75378: str     w10, [x21, #0x1c]                          
02d7537c: cbz     x8, #0x2d75c08                             
02d75380: ldrsw   x10, [x21, #0x18]                          
02d75384: ldr     w11, [x8, #0x18]                           
02d75388: cmp     w10, w11                                   
02d7538c: b.hs    #0x2d753b4                                 
02d75390: add     w11, w10, #1                               
02d75394: add     x10, x8, x10, lsl #2                       
02d75398: str     w11, [x21, #0x18]                          
02d7539c: mov     w11, #0x18                                 
02d753a0: str     w11, [x10, #0x20]                          
02d753a4: ldr     w10, [x21, #0x1c]                          
02d753a8: add     w10, w10, #1                               
02d753ac: str     w10, [x21, #0x1c]                          
02d753b0: b       #0x2d753e4                                 
02d753b4: ldr     x8, [x9, #0x20]                            
02d753b8: mov     x0, x21                                    
02d753bc: mov     w1, #0x18                                  
02d753c0: ldr     x8, [x8, #0xc0]                            
02d753c4: ldr     x2, [x8, #0x70]                            
02d753c8: bl      #0x356c578                                 fn_356c578
02d753cc: ldr     w10, [x21, #0x1c]                          
02d753d0: ldr     x8, [x21, #0x10]                           
02d753d4: ldr     x9, [x23]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d753d8: add     w10, w10, #1                               
02d753dc: str     w10, [x21, #0x1c]                          
02d753e0: cbz     x8, #0x2d75c08                             
02d753e4: ldrsw   x10, [x21, #0x18]                          
02d753e8: ldr     w11, [x8, #0x18]                           
02d753ec: cmp     w10, w11                                   
02d753f0: b.hs    #0x2d75418                                 
02d753f4: add     w11, w10, #1                               
02d753f8: add     x10, x8, x10, lsl #2                       
02d753fc: str     w11, [x21, #0x18]                          
02d75400: mov     w11, #0x19                                 
02d75404: str     w11, [x10, #0x20]                          
02d75408: ldr     w10, [x21, #0x1c]                          
02d7540c: add     w10, w10, #1                               
02d75410: str     w10, [x21, #0x1c]                          
02d75414: b       #0x2d75448                                 
02d75418: ldr     x8, [x9, #0x20]                            
02d7541c: mov     x0, x21                                    
02d75420: mov     w1, #0x19                                  
02d75424: ldr     x8, [x8, #0xc0]                            
02d75428: ldr     x2, [x8, #0x70]                            
02d7542c: bl      #0x356c578                                 fn_356c578
02d75430: ldr     w10, [x21, #0x1c]                          
02d75434: ldr     x8, [x21, #0x10]                           
02d75438: ldr     x9, [x23]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d7543c: add     w10, w10, #1                               
02d75440: str     w10, [x21, #0x1c]                          
02d75444: cbz     x8, #0x2d75c08                             
02d75448: ldrsw   x10, [x21, #0x18]                          
02d7544c: ldr     w11, [x8, #0x18]                           
02d75450: cmp     w10, w11                                   
02d75454: b.hs    #0x2d75470                                 
02d75458: add     w9, w10, #1                                
02d7545c: add     x8, x8, x10, lsl #2                        
02d75460: str     w9, [x21, #0x18]                           
02d75464: mov     w9, #0x1a                                  
02d75468: str     w9, [x8, #0x20]                            
02d7546c: b       #0x2d75488                                 
02d75470: ldr     x8, [x9, #0x20]                            
02d75474: mov     x0, x21                                    
02d75478: mov     w1, #0x1a                                  
02d7547c: ldr     x8, [x8, #0xc0]                            
02d75480: ldr     x2, [x8, #0x70]                            
02d75484: bl      #0x356c578                                 fn_356c578
02d75488: ldr     x0, [x24]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d7548c: bl      #0x2b7104c                                 fn_2b7104c
02d75490: ldr     x1, [x22]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d75494: mov     x22, x0                                    
02d75498: bl      #0x356bce8                                 fn_356bce8
02d7549c: cbz     x22, #0x2d75c08                            
02d754a0: ldr     w10, [x22, #0x1c]                          [626c01c]=0 f=0,0
02d754a4: ldr     x8, [x22, #0x10]                           M:Clicker.GlowSprite2DItem::<DoGlow>b__10_4
02d754a8: ldr     x9, [x23]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d754ac: add     w10, w10, #1                               
02d754b0: str     w10, [x22, #0x1c]                          
02d754b4: cbz     x8, #0x2d75c08                             
02d754b8: ldrsw   x10, [x22, #0x18]                          
02d754bc: ldr     w11, [x8, #0x18]                           
02d754c0: cmp     w10, w11                                   
02d754c4: b.hs    #0x2d754ec                                 
02d754c8: add     w11, w10, #1                               
02d754cc: add     x10, x8, x10, lsl #2                       
02d754d0: str     w11, [x22, #0x18]                          
02d754d4: mov     w11, #1                                    
02d754d8: str     w11, [x10, #0x20]                          
02d754dc: ldr     w10, [x22, #0x1c]                          [626c01c]=0 f=0,0
02d754e0: add     w10, w10, #1                               
02d754e4: str     w10, [x22, #0x1c]                          
02d754e8: b       #0x2d7551c                                 
02d754ec: ldr     x8, [x9, #0x20]                            
02d754f0: mov     x0, x22                                    
02d754f4: mov     w1, #1                                     
02d754f8: ldr     x8, [x8, #0xc0]                            
02d754fc: ldr     x2, [x8, #0x70]                            
02d75500: bl      #0x356c578                                 fn_356c578
02d75504: ldr     w10, [x22, #0x1c]                          [626c01c]=0 f=0,0
02d75508: ldr     x8, [x22, #0x10]                           M:Clicker.GlowSprite2DItem::<DoGlow>b__10_4
02d7550c: ldr     x9, [x23]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d75510: add     w10, w10, #1                               
02d75514: str     w10, [x22, #0x1c]                          
02d75518: cbz     x8, #0x2d75c08                             
02d7551c: ldrsw   x10, [x22, #0x18]                          
02d75520: ldr     w11, [x8, #0x18]                           
02d75524: cmp     w10, w11                                   
02d75528: b.hs    #0x2d75550                                 
02d7552c: add     w11, w10, #1                               
02d75530: add     x10, x8, x10, lsl #2                       
02d75534: str     w11, [x22, #0x18]                          
02d75538: mov     w11, #2                                    
02d7553c: str     w11, [x10, #0x20]                          
02d75540: ldr     w10, [x22, #0x1c]                          [626c01c]=0 f=0,0
02d75544: add     w10, w10, #1                               
02d75548: str     w10, [x22, #0x1c]                          
02d7554c: b       #0x2d75580                                 
02d75550: ldr     x8, [x9, #0x20]                            
02d75554: mov     x0, x22                                    
02d75558: mov     w1, #2                                     
02d7555c: ldr     x8, [x8, #0xc0]                            
02d75560: ldr     x2, [x8, #0x70]                            
02d75564: bl      #0x356c578                                 fn_356c578
02d75568: ldr     w10, [x22, #0x1c]                          [626c01c]=0 f=0,0
02d7556c: ldr     x8, [x22, #0x10]                           M:Clicker.GlowSprite2DItem::<DoGlow>b__10_4
02d75570: ldr     x9, [x23]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d75574: add     w10, w10, #1                               
02d75578: str     w10, [x22, #0x1c]                          
02d7557c: cbz     x8, #0x2d75c08                             
02d75580: ldrsw   x10, [x22, #0x18]                          
02d75584: ldr     w11, [x8, #0x18]                           
02d75588: cmp     w10, w11                                   
02d7558c: b.hs    #0x2d755b4                                 
02d75590: add     w11, w10, #1                               
02d75594: add     x10, x8, x10, lsl #2                       
02d75598: str     w11, [x22, #0x18]                          
02d7559c: mov     w11, #0x1b                                 
02d755a0: str     w11, [x10, #0x20]                          
02d755a4: ldr     w10, [x22, #0x1c]                          [626c01c]=0 f=0,0
02d755a8: add     w10, w10, #1                               
02d755ac: str     w10, [x22, #0x1c]                          
02d755b0: b       #0x2d755e4                                 
02d755b4: ldr     x8, [x9, #0x20]                            
02d755b8: mov     x0, x22                                    
02d755bc: mov     w1, #0x1b                                  
02d755c0: ldr     x8, [x8, #0xc0]                            
02d755c4: ldr     x2, [x8, #0x70]                            
02d755c8: bl      #0x356c578                                 fn_356c578
02d755cc: ldr     w10, [x22, #0x1c]                          [626c01c]=0 f=0,0
02d755d0: ldr     x8, [x22, #0x10]                           M:Clicker.GlowSprite2DItem::<DoGlow>b__10_4
02d755d4: ldr     x9, [x23]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d755d8: add     w10, w10, #1                               
02d755dc: str     w10, [x22, #0x1c]                          
02d755e0: cbz     x8, #0x2d75c08                             
02d755e4: ldrsw   x10, [x22, #0x18]                          
02d755e8: ldr     w11, [x8, #0x18]                           
02d755ec: adrp    x25, #0x626c000                            
02d755f0: ldr     x25, [x25, #0x7e8]                         T:Character.SingleAnimationState
02d755f4: cmp     w10, w11                                   
02d755f8: b.hs    #0x2d75614                                 
02d755fc: add     w9, w10, #1                                
02d75600: add     x8, x8, x10, lsl #2                        
02d75604: str     w9, [x22, #0x18]                           
02d75608: mov     w9, #0x1c                                  
02d7560c: str     w9, [x8, #0x20]                            
02d75610: b       #0x2d7562c                                 
02d75614: ldr     x8, [x9, #0x20]                            
02d75618: mov     x0, x22                                    
02d7561c: mov     w1, #0x1c                                  
02d75620: ldr     x8, [x8, #0xc0]                            
02d75624: ldr     x2, [x8, #0x70]                            
02d75628: bl      #0x356c578                                 fn_356c578
02d7562c: ldr     x0, [x25]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d75630: bl      #0x2b7104c                                 fn_2b7104c
02d75634: mov     x1, xzr                                    
02d75638: mov     x23, x0                                    
02d7563c: bl      #0x4e53e9c                                 System.Object::.ctor
02d75640: cbz     x23, #0x2d75c08                            
02d75644: adrp    x26, #0x626c000                            
02d75648: ldr     x26, [x26, #0x7c0]                         MS:Character.BaseState::Initialize
02d7564c: ldr     x9, [x23]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d75650: ldr     x24, [x19, #0x20]                          ._animator
02d75654: ldr     x1, [x26]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d75658: ldrh    w8, [x1, #0x50]                            
02d7565c: add     x8, x9, x8, lsl #4                         
02d75660: ldr     x0, [x8, #0x140]                           
02d75664: bl      #0x2b70f2c                                 fn_2b70f2c
02d75668: ldr     x8, [x0, #8]                               M:Clicker.GlowSprite2DItem::<DoGlow>b__10_3
02d7566c: mov     x3, x0                                     
02d75670: mov     x0, x23                                    
02d75674: mov     x1, x19                                    
02d75678: mov     x2, x24                                    
02d7567c: blr     x8                                         
02d75680: cbz     x0, #0x2d75c08                             
02d75684: adrp    x27, #0x626c000                            
02d75688: mov     x23, x0                                    
02d7568c: ldr     x27, [x27, #0x7c8]                         MS:Character.BaseState::SetAnimationType
02d75690: ldr     x9, [x0]                                   M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d75694: ldr     x1, [x27]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d75698: ldrh    w8, [x1, #0x50]                            
02d7569c: add     x8, x9, x8, lsl #4                         
02d756a0: ldr     x0, [x8, #0x140]                           
02d756a4: bl      #0x2b70f2c                                 fn_2b70f2c
02d756a8: ldr     x8, [x0, #8]                               M:Clicker.GlowSprite2DItem::<DoGlow>b__10_3
02d756ac: mov     x2, x0                                     
02d756b0: mov     x0, x23                                    
02d756b4: mov     w1, #4                                     
02d756b8: blr     x8                                         
02d756bc: mov     x1, x0                                     
02d756c0: mov     x0, x19                                    
02d756c4: str     x1, [x0, #0x38]!                           .IdleState
02d756c8: bl      #0x2b70d54                                 fn_2b70d54
02d756cc: ldr     x0, [x25]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d756d0: bl      #0x2b7104c                                 fn_2b7104c
02d756d4: mov     x1, xzr                                    
02d756d8: mov     x23, x0                                    
02d756dc: bl      #0x4e53e9c                                 System.Object::.ctor
02d756e0: cbz     x23, #0x2d75c08                            
02d756e4: ldr     x1, [x26]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d756e8: ldr     x9, [x23]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d756ec: ldr     x24, [x19, #0x20]                          ._animator
02d756f0: ldrh    w8, [x1, #0x50]                            
02d756f4: add     x8, x9, x8, lsl #4                         
02d756f8: ldr     x0, [x8, #0x140]                           
02d756fc: bl      #0x2b70f2c                                 fn_2b70f2c
02d75700: ldr     x8, [x0, #8]                               M:Clicker.GlowSprite2DItem::<DoGlow>b__10_3
02d75704: mov     x3, x0                                     
02d75708: mov     x0, x23                                    
02d7570c: mov     x1, x19                                    
02d75710: mov     x2, x24                                    
02d75714: blr     x8                                         
02d75718: cbz     x0, #0x2d75c08                             
02d7571c: ldr     x1, [x27]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d75720: ldr     x9, [x0]                                   M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d75724: mov     x23, x0                                    
02d75728: ldrh    w8, [x1, #0x50]                            
02d7572c: add     x8, x9, x8, lsl #4                         
02d75730: ldr     x0, [x8, #0x140]                           
02d75734: bl      #0x2b70f2c                                 fn_2b70f2c
02d75738: ldr     x8, [x0, #8]                               M:Clicker.GlowSprite2DItem::<DoGlow>b__10_3
02d7573c: mov     x2, x0                                     
02d75740: mov     x0, x23                                    
02d75744: mov     w1, #6                                     
02d75748: blr     x8                                         
02d7574c: mov     x1, x0                                     
02d75750: mov     x0, x19                                    
02d75754: str     x1, [x0, #0x40]!                           .WaitState
02d75758: bl      #0x2b70d54                                 fn_2b70d54
02d7575c: ldr     x0, [x25]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d75760: bl      #0x2b7104c                                 fn_2b7104c
02d75764: mov     x1, xzr                                    
02d75768: mov     x23, x0                                    
02d7576c: bl      #0x4e53e9c                                 System.Object::.ctor
02d75770: cbz     x23, #0x2d75c08                            
02d75774: ldr     x1, [x26]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d75778: ldr     x9, [x23]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d7577c: ldr     x24, [x19, #0x20]                          ._animator
02d75780: ldrh    w8, [x1, #0x50]                            
02d75784: add     x8, x9, x8, lsl #4                         
02d75788: ldr     x0, [x8, #0x140]                           
02d7578c: bl      #0x2b70f2c                                 fn_2b70f2c
02d75790: ldr     x8, [x0, #8]                               M:Clicker.GlowSprite2DItem::<DoGlow>b__10_3
02d75794: mov     x3, x0                                     
02d75798: mov     x0, x23                                    
02d7579c: mov     x1, x19                                    
02d757a0: mov     x2, x24                                    
02d757a4: blr     x8                                         
02d757a8: cbz     x0, #0x2d75c08                             
02d757ac: ldr     x1, [x27]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d757b0: ldr     x9, [x0]                                   M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d757b4: mov     x23, x0                                    
02d757b8: ldrh    w8, [x1, #0x50]                            
02d757bc: add     x8, x9, x8, lsl #4                         
02d757c0: ldr     x0, [x8, #0x140]                           
02d757c4: bl      #0x2b70f2c                                 fn_2b70f2c
02d757c8: ldr     x8, [x0, #8]                               M:Clicker.GlowSprite2DItem::<DoGlow>b__10_3
02d757cc: mov     x2, x0                                     
02d757d0: mov     x0, x23                                    
02d757d4: mov     w1, #9                                     
02d757d8: blr     x8                                         
02d757dc: mov     x1, x0                                     
02d757e0: mov     x0, x19                                    
02d757e4: str     x1, [x0, #0x50]!                           .SpicyState
02d757e8: bl      #0x2b70d54                                 fn_2b70d54
02d757ec: ldr     x0, [x25]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d757f0: bl      #0x2b7104c                                 fn_2b7104c
02d757f4: mov     x1, xzr                                    
02d757f8: mov     x23, x0                                    
02d757fc: bl      #0x4e53e9c                                 System.Object::.ctor
02d75800: cbz     x23, #0x2d75c08                            
02d75804: ldr     x1, [x26]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d75808: ldr     x9, [x23]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d7580c: ldr     x24, [x19, #0x20]                          ._animator
02d75810: ldrh    w8, [x1, #0x50]                            
02d75814: add     x8, x9, x8, lsl #4                         
02d75818: ldr     x0, [x8, #0x140]                           
02d7581c: bl      #0x2b70f2c                                 fn_2b70f2c
02d75820: ldr     x8, [x0, #8]                               M:Clicker.GlowSprite2DItem::<DoGlow>b__10_3
02d75824: mov     x3, x0                                     
02d75828: mov     x0, x23                                    
02d7582c: mov     x1, x19                                    
02d75830: mov     x2, x24                                    
02d75834: blr     x8                                         
02d75838: cbz     x0, #0x2d75c08                             
02d7583c: ldr     x1, [x27]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d75840: ldr     x9, [x0]                                   M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d75844: mov     x23, x0                                    
02d75848: ldrh    w8, [x1, #0x50]                            
02d7584c: add     x8, x9, x8, lsl #4                         
02d75850: ldr     x0, [x8, #0x140]                           
02d75854: bl      #0x2b70f2c                                 fn_2b70f2c
02d75858: ldr     x8, [x0, #8]                               M:Clicker.GlowSprite2DItem::<DoGlow>b__10_3
02d7585c: mov     x2, x0                                     
02d75860: mov     x0, x23                                    
02d75864: mov     w1, #0xa                                   
02d75868: blr     x8                                         
02d7586c: mov     x1, x0                                     
02d75870: mov     x0, x19                                    
02d75874: str     x1, [x0, #0x58]!                           .SurpriseState
02d75878: bl      #0x2b70d54                                 fn_2b70d54
02d7587c: ldr     x0, [x25]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d75880: bl      #0x2b7104c                                 fn_2b7104c
02d75884: mov     x1, xzr                                    
02d75888: mov     x23, x0                                    
02d7588c: bl      #0x4e53e9c                                 System.Object::.ctor
02d75890: cbz     x23, #0x2d75c08                            
02d75894: ldr     x1, [x26]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d75898: ldr     x9, [x23]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d7589c: ldr     x24, [x19, #0x20]                          ._animator
02d758a0: ldrh    w8, [x1, #0x50]                            
02d758a4: add     x8, x9, x8, lsl #4                         
02d758a8: ldr     x0, [x8, #0x140]                           
02d758ac: bl      #0x2b70f2c                                 fn_2b70f2c
02d758b0: ldr     x8, [x0, #8]                               M:Clicker.GlowSprite2DItem::<DoGlow>b__10_3
02d758b4: mov     x3, x0                                     
02d758b8: mov     x0, x23                                    
02d758bc: mov     x1, x19                                    
02d758c0: mov     x2, x24                                    
02d758c4: blr     x8                                         
02d758c8: cbz     x0, #0x2d75c08                             
02d758cc: ldr     x1, [x27]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d758d0: ldr     x9, [x0]                                   M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d758d4: mov     x23, x0                                    
02d758d8: ldrh    w8, [x1, #0x50]                            
02d758dc: add     x8, x9, x8, lsl #4                         
02d758e0: ldr     x0, [x8, #0x140]                           
02d758e4: bl      #0x2b70f2c                                 fn_2b70f2c
02d758e8: ldr     x8, [x0, #8]                               M:Clicker.GlowSprite2DItem::<DoGlow>b__10_3
02d758ec: mov     x2, x0                                     
02d758f0: mov     x0, x23                                    
02d758f4: mov     w1, #7                                     
02d758f8: blr     x8                                         
02d758fc: mov     x1, x0                                     
02d75900: mov     x0, x19                                    
02d75904: str     x1, [x0, #0x60]!                           .SourState
02d75908: bl      #0x2b70d54                                 fn_2b70d54
02d7590c: ldr     x0, [x25]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d75910: bl      #0x2b7104c                                 fn_2b7104c
02d75914: mov     x1, xzr                                    
02d75918: mov     x23, x0                                    
02d7591c: bl      #0x4e53e9c                                 System.Object::.ctor
02d75920: cbz     x23, #0x2d75c08                            
02d75924: ldr     x1, [x26]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d75928: ldr     x9, [x23]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d7592c: ldr     x24, [x19, #0x20]                          ._animator
02d75930: ldrh    w8, [x1, #0x50]                            
02d75934: add     x8, x9, x8, lsl #4                         
02d75938: ldr     x0, [x8, #0x140]                           
02d7593c: bl      #0x2b70f2c                                 fn_2b70f2c
02d75940: ldr     x8, [x0, #8]                               M:Clicker.GlowSprite2DItem::<DoGlow>b__10_3
02d75944: mov     x3, x0                                     
02d75948: mov     x0, x23                                    
02d7594c: mov     x1, x19                                    
02d75950: mov     x2, x24                                    
02d75954: blr     x8                                         
02d75958: cbz     x0, #0x2d75c08                             
02d7595c: ldr     x1, [x27]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d75960: ldr     x9, [x0]                                   M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d75964: mov     x23, x0                                    
02d75968: ldrh    w8, [x1, #0x50]                            
02d7596c: add     x8, x9, x8, lsl #4                         
02d75970: ldr     x0, [x8, #0x140]                           
02d75974: bl      #0x2b70f2c                                 fn_2b70f2c
02d75978: ldr     x8, [x0, #8]                               M:Clicker.GlowSprite2DItem::<DoGlow>b__10_3
02d7597c: mov     x2, x0                                     
02d75980: mov     x0, x23                                    
02d75984: mov     w1, #0xc                                   
02d75988: blr     x8                                         
02d7598c: mov     x1, x0                                     
02d75990: mov     x0, x19                                    
02d75994: str     x1, [x0, #0x48]!                           .DrinkState
02d75998: bl      #0x2b70d54                                 fn_2b70d54
02d7599c: ldr     x0, [x25]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d759a0: bl      #0x2b7104c                                 fn_2b7104c
02d759a4: mov     x1, xzr                                    
02d759a8: mov     x23, x0                                    
02d759ac: bl      #0x4e53e9c                                 System.Object::.ctor
02d759b0: cbz     x23, #0x2d75c08                            
02d759b4: ldr     x1, [x26]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d759b8: ldr     x9, [x23]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d759bc: ldr     x24, [x19, #0x20]                          ._animator
02d759c0: ldrh    w8, [x1, #0x50]                            
02d759c4: add     x8, x9, x8, lsl #4                         
02d759c8: ldr     x0, [x8, #0x140]                           
02d759cc: bl      #0x2b70f2c                                 fn_2b70f2c
02d759d0: ldr     x8, [x0, #8]                               M:Clicker.GlowSprite2DItem::<DoGlow>b__10_3
02d759d4: mov     x3, x0                                     
02d759d8: mov     x0, x23                                    
02d759dc: mov     x1, x19                                    
02d759e0: mov     x2, x24                                    
02d759e4: blr     x8                                         
02d759e8: cbz     x0, #0x2d75c08                             
02d759ec: ldr     x1, [x27]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d759f0: ldr     x9, [x0]                                   M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d759f4: adrp    x25, #0x626c000                            
02d759f8: mov     x23, x0                                    
02d759fc: ldrh    w8, [x1, #0x50]                            
02d75a00: ldr     x25, [x25, #0x7e0]                         T:Character.RandomAnimationState
02d75a04: add     x8, x9, x8, lsl #4                         
02d75a08: ldr     x0, [x8, #0x140]                           
02d75a0c: bl      #0x2b70f2c                                 fn_2b70f2c
02d75a10: ldr     x8, [x0, #8]                               M:Clicker.GlowSprite2DItem::<DoGlow>b__10_3
02d75a14: mov     x2, x0                                     
02d75a18: mov     x0, x23                                    
02d75a1c: mov     w1, #0x16                                  
02d75a20: blr     x8                                         
02d75a24: mov     x1, x0                                     
02d75a28: mov     x0, x19                                    
02d75a2c: str     x1, [x0, #0x68]!                           .CoolState
02d75a30: bl      #0x2b70d54                                 fn_2b70d54
02d75a34: ldr     x0, [x25]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d75a38: bl      #0x2b7104c                                 fn_2b7104c
02d75a3c: mov     x1, xzr                                    
02d75a40: mov     x23, x0                                    
02d75a44: bl      #0x4e53e9c                                 System.Object::.ctor
02d75a48: cbz     x23, #0x2d75c08                            
02d75a4c: adrp    x26, #0x626c000                            
02d75a50: ldr     x26, [x26, #0x7b8]                         MS:Character.BaseState::Initialize
02d75a54: ldr     x9, [x23]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d75a58: ldr     x24, [x19, #0x20]                          ._animator
02d75a5c: ldr     x1, [x26]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d75a60: ldrh    w8, [x1, #0x50]                            
02d75a64: add     x8, x9, x8, lsl #4                         
02d75a68: ldr     x0, [x8, #0x140]                           
02d75a6c: bl      #0x2b70f2c                                 fn_2b70f2c
02d75a70: ldr     x8, [x0, #8]                               M:Clicker.GlowSprite2DItem::<DoGlow>b__10_3
02d75a74: mov     x3, x0                                     
02d75a78: mov     x0, x23                                    
02d75a7c: mov     x1, x19                                    
02d75a80: mov     x2, x24                                    
02d75a84: blr     x8                                         
02d75a88: cbz     x0, #0x2d75c08                             
02d75a8c: adrp    x24, #0x626c000                            
02d75a90: mov     x23, x0                                    
02d75a94: ldr     x24, [x24, #0x7d8]                         MS:Character.RandomAnimationState::SetAnimationTypes
02d75a98: ldr     x9, [x0]                                   M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d75a9c: ldr     x1, [x24]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d75aa0: ldrh    w8, [x1, #0x50]                            
02d75aa4: add     x8, x9, x8, lsl #4                         
02d75aa8: ldr     x0, [x8, #0x140]                           
02d75aac: bl      #0x2b70f2c                                 fn_2b70f2c
02d75ab0: ldr     x8, [x0, #8]                               M:Clicker.GlowSprite2DItem::<DoGlow>b__10_3
02d75ab4: mov     x2, x0                                     
02d75ab8: mov     x0, x23                                    
02d75abc: mov     x1, x20                                    
02d75ac0: blr     x8                                         
02d75ac4: mov     x1, x0                                     
02d75ac8: mov     x0, x19                                    
02d75acc: str     x1, [x0, #0x78]!                           .EatFoodState
02d75ad0: bl      #0x2b70d54                                 fn_2b70d54
02d75ad4: ldr     x0, [x25]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d75ad8: bl      #0x2b7104c                                 fn_2b7104c
02d75adc: mov     x1, xzr                                    
02d75ae0: mov     x20, x0                                    
02d75ae4: bl      #0x4e53e9c                                 System.Object::.ctor
02d75ae8: cbz     x20, #0x2d75c08                            
02d75aec: ldr     x1, [x26]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d75af0: ldr     x9, [x20]                                  
02d75af4: ldr     x23, [x19, #0x20]                          ._animator
02d75af8: ldrh    w8, [x1, #0x50]                            
02d75afc: add     x8, x9, x8, lsl #4                         
02d75b00: ldr     x0, [x8, #0x140]                           
02d75b04: bl      #0x2b70f2c                                 fn_2b70f2c
02d75b08: ldr     x8, [x0, #8]                               M:Clicker.GlowSprite2DItem::<DoGlow>b__10_3
02d75b0c: mov     x3, x0                                     
02d75b10: mov     x0, x20                                    
02d75b14: mov     x1, x19                                    
02d75b18: mov     x2, x23                                    
02d75b1c: blr     x8                                         
02d75b20: cbz     x0, #0x2d75c08                             
02d75b24: ldr     x1, [x24]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d75b28: ldr     x9, [x0]                                   M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d75b2c: mov     x20, x0                                    
02d75b30: ldrh    w8, [x1, #0x50]                            
02d75b34: add     x8, x9, x8, lsl #4                         
02d75b38: ldr     x0, [x8, #0x140]                           
02d75b3c: bl      #0x2b70f2c                                 fn_2b70f2c
02d75b40: ldr     x8, [x0, #8]                               M:Clicker.GlowSprite2DItem::<DoGlow>b__10_3
02d75b44: mov     x2, x0                                     
02d75b48: mov     x0, x20                                    
02d75b4c: mov     x1, x22                                    
02d75b50: blr     x8                                         
02d75b54: mov     x1, x0                                     
02d75b58: mov     x0, x19                                    
02d75b5c: str     x1, [x0, #0x70]!                           .HappyState
02d75b60: bl      #0x2b70d54                                 fn_2b70d54
02d75b64: ldr     x0, [x25]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d75b68: bl      #0x2b7104c                                 fn_2b7104c
02d75b6c: mov     x1, xzr                                    
02d75b70: mov     x20, x0                                    
02d75b74: bl      #0x4e53e9c                                 System.Object::.ctor
02d75b78: cbz     x20, #0x2d75c08                            
02d75b7c: ldr     x1, [x26]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d75b80: ldr     x9, [x20]                                  
02d75b84: ldr     x22, [x19, #0x20]                          ._animator
02d75b88: ldrh    w8, [x1, #0x50]                            
02d75b8c: add     x8, x9, x8, lsl #4                         
02d75b90: ldr     x0, [x8, #0x140]                           
02d75b94: bl      #0x2b70f2c                                 fn_2b70f2c
02d75b98: ldr     x8, [x0, #8]                               M:Clicker.GlowSprite2DItem::<DoGlow>b__10_3
02d75b9c: mov     x3, x0                                     
02d75ba0: mov     x0, x20                                    
02d75ba4: mov     x1, x19                                    
02d75ba8: mov     x2, x22                                    
02d75bac: blr     x8                                         
02d75bb0: cbz     x0, #0x2d75c08                             
02d75bb4: ldr     x1, [x24]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d75bb8: ldr     x9, [x0]                                   M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d75bbc: mov     x20, x0                                    
02d75bc0: ldrh    w8, [x1, #0x50]                            
02d75bc4: add     x8, x9, x8, lsl #4                         
02d75bc8: ldr     x0, [x8, #0x140]                           
02d75bcc: bl      #0x2b70f2c                                 fn_2b70f2c
02d75bd0: ldr     x8, [x0, #8]                               M:Clicker.GlowSprite2DItem::<DoGlow>b__10_3
02d75bd4: mov     x2, x0                                     
02d75bd8: mov     x0, x20                                    
02d75bdc: mov     x1, x21                                    
02d75be0: blr     x8                                         
02d75be4: str     x0, [x19, #0x80]!                          .CuteState
02d75be8: mov     x1, x0                                     
02d75bec: mov     x0, x19                                    
02d75bf0: ldp     x20, x19, [sp, #0x40]                      
02d75bf4: ldp     x22, x21, [sp, #0x30]                      
02d75bf8: ldp     x24, x23, [sp, #0x20]                      
02d75bfc: ldp     x26, x25, [sp, #0x10]                      
02d75c00: ldp     x30, x27, [sp], #0x50                      
02d75c04: b       #0x2b70d54                                 
02d75c08: bl      #0x2b7105c                                 fn_2b7105c
## GetRandomEatFoodAnim() -> EAnimationSpineType
---- Character.MotionStateMachine::GetRandomEatFoodAnim 0x2d75c1c
02d75c1c: stp     x30, x21, [sp, #-0x20]!                    
02d75c20: stp     x20, x19, [sp, #0x10]                      
02d75c24: adrp    x21, #0x6630000                            
02d75c28: adrp    x20, #0x626c000                            
02d75c2c: mov     x19, x0                                    
02d75c30: ldrb    w8, [x21, #0x3d1]                          
02d75c34: ldr     x20, [x20, #0x7f0]                         MS:FrameWorkUtility::PickRandom
02d75c38: tbnz    w8, #0, #0x2d75c50                         
02d75c3c: adrp    x0, #0x626c000                             
02d75c40: ldr     x0, [x0, #0x7f0]                           MS:FrameWorkUtility::PickRandom
02d75c44: bl      #0x2b70db0                                 fn_2b70db0
02d75c48: mov     w8, #1                                     
02d75c4c: strb    w8, [x21, #0x3d1]                          
02d75c50: ldr     x0, [x19, #0x90]                           ._eatFoodAnims
02d75c54: ldr     x1, [x20]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d75c58: ldp     x20, x19, [sp, #0x10]                      
02d75c5c: ldp     x30, x21, [sp], #0x20                      
02d75c60: b       #0x31cf7fc                                 
## IsPlayingSpecialAnim() -> bool
---- Character.MotionStateMachine::IsPlayingSpecialAnim 0x2d75c64
02d75c64: ldr     x8, [x0, #0x30]                            ._currentState
02d75c68: ldr     x9, [x0, #0x50]                            .SpicyState
02d75c6c: cmp     x8, x9                                     
02d75c70: b.eq    #0x2d75ccc                                 
02d75c74: ldr     x9, [x0, #0x58]                            .SurpriseState
02d75c78: cmp     x8, x9                                     
02d75c7c: b.eq    #0x2d75ccc                                 
02d75c80: ldr     x9, [x0, #0x60]                            .SourState
02d75c84: cmp     x8, x9                                     
02d75c88: b.eq    #0x2d75ccc                                 
02d75c8c: ldr     x9, [x0, #0x68]                            .CoolState
02d75c90: cmp     x8, x9                                     
02d75c94: b.eq    #0x2d75ccc                                 
02d75c98: ldr     x9, [x0, #0x48]                            .DrinkState
02d75c9c: cmp     x8, x9                                     
02d75ca0: b.eq    #0x2d75ccc                                 
02d75ca4: ldr     x9, [x0, #0x78]                            .EatFoodState
02d75ca8: cmp     x8, x9                                     
02d75cac: b.eq    #0x2d75ccc                                 
02d75cb0: ldr     x9, [x0, #0x70]                            .HappyState
02d75cb4: cmp     x8, x9                                     
02d75cb8: b.eq    #0x2d75ccc                                 
02d75cbc: ldr     x9, [x0, #0x80]                            .CuteState
02d75cc0: cmp     x8, x9                                     
02d75cc4: cset    w0, eq                                     
02d75cc8: ret                                                
02d75ccc: mov     w0, #1                                     
02d75cd0: ret                                                
## IsEating() -> bool
---- Character.MotionStateMachine::IsEating 0x2d75cd4
02d75cd4: ldr     x8, [x0, #0x30]                            ._currentState
02d75cd8: ldr     x9, [x0, #0x78]                            .EatFoodState
02d75cdc: cmp     x8, x9                                     
02d75ce0: cset    w0, eq                                     
02d75ce4: ret                                                
## ChangeState(Character.IState state, bool isLoop) -> void
---- Character.MotionStateMachine::ChangeState 0x2d75ce8
02d75ce8: stp     x30, x23, [sp, #-0x30]!                    
02d75cec: stp     x22, x21, [sp, #0x10]                      
02d75cf0: stp     x20, x19, [sp, #0x20]                      
02d75cf4: adrp    x22, #0x6630000                            
02d75cf8: mov     w19, w2                                    
02d75cfc: mov     x20, x1                                    
02d75d00: ldrb    w8, [x22, #0x3d2]                          
02d75d04: mov     x21, x0                                    
02d75d08: tbnz    w8, #0, #0x2d75d20                         
02d75d0c: adrp    x0, #0x626c000                             
02d75d10: ldr     x0, [x0, #0x7f8]                           T:Character.IState
02d75d14: bl      #0x2b70db0                                 fn_2b70db0
02d75d18: mov     w8, #1                                     
02d75d1c: strb    w8, [x22, #0x3d2]                          
02d75d20: adrp    x23, #0x626c000                            
02d75d24: ldr     x22, [x21, #0x30]!                         ._currentState
02d75d28: ldr     x23, [x23, #0x7f8]                         T:Character.IState
02d75d2c: cbz     x22, #0x2d75d8c                            
02d75d30: ldr     x8, [x22]                                  
02d75d34: ldr     x1, [x23]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d75d38: ldrh    w9, [x8, #0x12e]                           
02d75d3c: cbz     x9, #0x2d75d60                             
02d75d40: ldr     x10, [x8, #0xb0]                           
02d75d44: add     x10, x10, #8                               
02d75d48: ldur    x11, [x10, #-8]                            
02d75d4c: cmp     x11, x1                                    
02d75d50: b.eq    #0x2d75d70                                 
02d75d54: subs    x9, x9, #1                                 
02d75d58: add     x10, x10, #0x10                            
02d75d5c: b.ne    #0x2d75d48                                 
02d75d60: mov     x0, x22                                    
02d75d64: mov     w2, #2                                     
02d75d68: bl      #0x2baa05c                                 fn_2baa05c
02d75d6c: b       #0x2d75d80                                 
02d75d70: ldr     w9, [x10]                                  
02d75d74: add     w9, w9, #2                                 
02d75d78: add     x8, x8, w9, sxtw #4                        
02d75d7c: add     x0, x8, #0x138                             
02d75d80: ldp     x8, x1, [x0]                               
02d75d84: mov     x0, x22                                    
02d75d88: blr     x8                                         
02d75d8c: mov     x0, x21                                    
02d75d90: mov     x1, x20                                    
02d75d94: str     x20, [x21]                                 
02d75d98: bl      #0x2b70d54                                 fn_2b70d54
02d75d9c: ldr     x20, [x21]                                 
02d75da0: cbz     x20, #0x2d75e18                            
02d75da4: ldr     x8, [x20]                                  
02d75da8: ldr     x1, [x23]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d75dac: ldrh    w9, [x8, #0x12e]                           
02d75db0: cbz     x9, #0x2d75dd4                             
02d75db4: ldr     x10, [x8, #0xb0]                           
02d75db8: add     x10, x10, #8                               
02d75dbc: ldur    x11, [x10, #-8]                            
02d75dc0: cmp     x11, x1                                    
02d75dc4: b.eq    #0x2d75de4                                 
02d75dc8: subs    x9, x9, #1                                 
02d75dcc: add     x10, x10, #0x10                            
02d75dd0: b.ne    #0x2d75dbc                                 
02d75dd4: mov     x0, x20                                    
02d75dd8: mov     w2, #3                                     
02d75ddc: bl      #0x2baa05c                                 fn_2baa05c
02d75de0: b       #0x2d75df4                                 
02d75de4: ldr     w9, [x10]                                  
02d75de8: add     w9, w9, #3                                 
02d75dec: add     x8, x8, w9, sxtw #4                        
02d75df0: add     x0, x8, #0x138                             
02d75df4: ldp     x5, x4, [x0]                               
02d75df8: and     w1, w19, #1                                
02d75dfc: mov     x0, x20                                    
02d75e00: ldp     x20, x19, [sp, #0x20]                      
02d75e04: ldp     x22, x21, [sp, #0x10]                      
02d75e08: mov     x2, xzr                                    
02d75e0c: mov     x3, xzr                                    
02d75e10: ldp     x30, x23, [sp], #0x30                      
02d75e14: br      x5                                         
02d75e18: bl      #0x2b7105c                                 fn_2b7105c
## GetCurrentState() -> Character.IState
---- Character.MotionStateMachine::GetCurrentState 0x2d75e1c
02d75e1c: ldr     x0, [x0, #0x30]                            ._currentState
02d75e20: ret                                                
## ChangeState(Character.IState state, bool isLoop, System.Action onStartCallback, System.Action onCompleteCallback) -> void
---- Character.MotionStateMachine::ChangeState 0x2d75e24
02d75e24: str     x30, [sp, #-0x60]!                         
02d75e28: stp     x28, x27, [sp, #0x10]                      
02d75e2c: stp     x26, x25, [sp, #0x20]                      
02d75e30: stp     x24, x23, [sp, #0x30]                      
02d75e34: stp     x22, x21, [sp, #0x40]                      
02d75e38: stp     x20, x19, [sp, #0x50]                      
02d75e3c: adrp    x23, #0x6630000                            
02d75e40: adrp    x25, #0x626c000                            
02d75e44: mov     x24, x4                                    
02d75e48: ldrb    w8, [x23, #0x3d3]                          
02d75e4c: ldr     x25, [x25, #0x800]                         T:Character.MotionStateMachine/<>c__DisplayClass26_0
02d75e50: mov     x19, x3                                    
02d75e54: mov     w20, w2                                    
02d75e58: mov     x21, x1                                    
02d75e5c: mov     x22, x0                                    
02d75e60: tbnz    w8, #0, #0x2d75ea8                         
02d75e64: adrp    x0, #0x6264000                             
02d75e68: ldr     x0, [x0, #0xf90]                           T:System.Action
02d75e6c: bl      #0x2b70db0                                 fn_2b70db0
02d75e70: adrp    x0, #0x626c000                             
02d75e74: ldr     x0, [x0, #0x808]                           T:System.Threading.CancellationTokenSource
02d75e78: bl      #0x2b70db0                                 fn_2b70db0
02d75e7c: adrp    x0, #0x626c000                             
02d75e80: ldr     x0, [x0, #0x7f8]                           T:Character.IState
02d75e84: bl      #0x2b70db0                                 fn_2b70db0
02d75e88: adrp    x0, #0x626c000                             
02d75e8c: ldr     x0, [x0, #0x810]                           M:Character.MotionStateMachine/<>c__DisplayClass26_0::<ChangeState>b__0
02d75e90: bl      #0x2b70db0                                 fn_2b70db0
02d75e94: adrp    x0, #0x626c000                             
02d75e98: ldr     x0, [x0, #0x800]                           T:Character.MotionStateMachine/<>c__DisplayClass26_0
02d75e9c: bl      #0x2b70db0                                 fn_2b70db0
02d75ea0: mov     w8, #1                                     
02d75ea4: strb    w8, [x23, #0x3d3]                          
02d75ea8: ldr     x0, [x25]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d75eac: bl      #0x2b7104c                                 fn_2b7104c
02d75eb0: mov     x1, xzr                                    
02d75eb4: mov     x23, x0                                    
02d75eb8: bl      #0x4e53e9c                                 System.Object::.ctor
02d75ebc: cbz     x23, #0x2d76050                            
02d75ec0: adrp    x25, #0x626c000                            
02d75ec4: mov     x0, x23                                    
02d75ec8: mov     x1, x22                                    
02d75ecc: ldr     x25, [x25, #0x808]                         T:System.Threading.CancellationTokenSource
02d75ed0: str     x22, [x0, #0x10]!                          
02d75ed4: bl      #0x2b70d54                                 fn_2b70d54
02d75ed8: mov     x0, x23                                    
02d75edc: mov     x1, x24                                    
02d75ee0: str     x24, [x0, #0x18]!                          
02d75ee4: bl      #0x2b70d54                                 fn_2b70d54
02d75ee8: mov     x24, x22                                   
02d75eec: ldr     x0, [x24, #0x88]!                          
02d75ef0: cbz     x0, #0x2d75efc                             
02d75ef4: mov     x1, xzr                                    
02d75ef8: bl      #0x4e75eb0                                 System.Threading.CancellationTokenSource::Cancel
02d75efc: adrp    x26, #0x626c000                            
02d75f00: adrp    x28, #0x6264000                            
02d75f04: adrp    x27, #0x626c000                            
02d75f08: ldr     x26, [x26, #0x7f8]                         T:Character.IState
02d75f0c: ldr     x28, [x28, #0xf90]                         T:System.Action
02d75f10: ldr     x27, [x27, #0x810]                         M:Character.MotionStateMachine/<>c__DisplayClass26_0::<ChangeState>b__0
02d75f14: ldr     x0, [x25]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d75f18: bl      #0x2b7104c                                 fn_2b7104c
02d75f1c: mov     x1, xzr                                    
02d75f20: mov     x25, x0                                    
02d75f24: bl      #0x4e75e7c                                 System.Threading.CancellationTokenSource::.ctor
02d75f28: mov     x0, x24                                    
02d75f2c: mov     x1, x25                                    
02d75f30: str     x25, [x22, #0x88]                          
02d75f34: bl      #0x2b70d54                                 fn_2b70d54
02d75f38: ldr     x24, [x22, #0x30]!                         
02d75f3c: cbz     x24, #0x2d75f9c                            
02d75f40: ldr     x8, [x24]                                  
02d75f44: ldr     x1, [x26]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d75f48: ldrh    w9, [x8, #0x12e]                           
02d75f4c: cbz     x9, #0x2d75f70                             
02d75f50: ldr     x10, [x8, #0xb0]                           
02d75f54: add     x10, x10, #8                               
02d75f58: ldur    x11, [x10, #-8]                            
02d75f5c: cmp     x11, x1                                    
02d75f60: b.eq    #0x2d75f80                                 
02d75f64: subs    x9, x9, #1                                 
02d75f68: add     x10, x10, #0x10                            
02d75f6c: b.ne    #0x2d75f58                                 
02d75f70: mov     x0, x24                                    
02d75f74: mov     w2, #2                                     
02d75f78: bl      #0x2baa05c                                 fn_2baa05c
02d75f7c: b       #0x2d75f90                                 
02d75f80: ldr     w9, [x10]                                  
02d75f84: add     w9, w9, #2                                 
02d75f88: add     x8, x8, w9, sxtw #4                        
02d75f8c: add     x0, x8, #0x138                             
02d75f90: ldp     x8, x1, [x0]                               
02d75f94: mov     x0, x24                                    
02d75f98: blr     x8                                         
02d75f9c: mov     x0, x22                                    
02d75fa0: mov     x1, x21                                    
02d75fa4: str     x21, [x22]                                 
02d75fa8: bl      #0x2b70d54                                 fn_2b70d54
02d75fac: ldr     x0, [x28]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d75fb0: ldr     x21, [x22]                                 
02d75fb4: bl      #0x2b7104c                                 fn_2b7104c
02d75fb8: ldr     x2, [x27]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d75fbc: mov     x1, x23                                    
02d75fc0: mov     x3, xzr                                    
02d75fc4: mov     x22, x0                                    
02d75fc8: bl      #0x4d8ddbc                                 System.Action::.ctor
02d75fcc: cbz     x21, #0x2d76050                            
02d75fd0: ldr     x8, [x21]                                  
02d75fd4: ldr     x1, [x26]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d75fd8: ldrh    w9, [x8, #0x12e]                           
02d75fdc: cbz     x9, #0x2d76000                             
02d75fe0: ldr     x10, [x8, #0xb0]                           
02d75fe4: add     x10, x10, #8                               
02d75fe8: ldur    x11, [x10, #-8]                            
02d75fec: cmp     x11, x1                                    
02d75ff0: b.eq    #0x2d76010                                 
02d75ff4: subs    x9, x9, #1                                 
02d75ff8: add     x10, x10, #0x10                            
02d75ffc: b.ne    #0x2d75fe8                                 
02d76000: mov     x0, x21                                    
02d76004: mov     w2, #3                                     
02d76008: bl      #0x2baa05c                                 fn_2baa05c
02d7600c: b       #0x2d76020                                 
02d76010: ldr     w9, [x10]                                  
02d76014: add     w9, w9, #3                                 
02d76018: add     x8, x8, w9, sxtw #4                        
02d7601c: add     x0, x8, #0x138                             
02d76020: ldp     x5, x4, [x0]                               
02d76024: and     w1, w20, #1                                
02d76028: mov     x0, x21                                    
02d7602c: mov     x2, x19                                    
02d76030: mov     x3, x22                                    
02d76034: ldp     x20, x19, [sp, #0x50]                      
02d76038: ldp     x22, x21, [sp, #0x40]                      
02d7603c: ldp     x24, x23, [sp, #0x30]                      
02d76040: ldp     x26, x25, [sp, #0x20]                      
02d76044: ldp     x28, x27, [sp, #0x10]                      
02d76048: ldr     x30, [sp], #0x60                           
02d7604c: br      x5                                         
02d76050: bl      #0x2b7105c                                 fn_2b7105c
## .ctor() -> void
---- Character.MotionStateMachine::.ctor 0x2d7605c
02d7605c: mov     x1, xzr                                    
02d76060: b       #0x5b397b0                                 UnityEngine.MonoBehaviour::.ctor
