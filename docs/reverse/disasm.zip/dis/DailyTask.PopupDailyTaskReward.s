#### CLASS DailyTask.PopupDailyTaskReward parent= PopupBase
#   field _openButton                    UnityEngine.UI.Button                              off=0x38 attr=1 SerializeField
#   field _animator                      SkeletonGraphicHandler                             off=0x40 attr=1 SerializeField
#   field _spawnPoint                    UnityEngine.Transform                              off=0x48 attr=1 SerializeField
#   field _tapToOpenObject               UnityEngine.GameObject                             off=0x50 attr=1 SerializeField
#   field _dailyTaskController           DailyTask.DailyTaskController                      off=0x58 attr=1 
## OnDestroy() -> void
---- DailyTask.PopupDailyTaskReward::OnDestroy 0x2d2e604
02d2e604: stp     x30, x21, [sp, #-0x20]!                    
02d2e608: stp     x20, x19, [sp, #0x10]                      
02d2e60c: adrp    x20, #0x6630000                            
02d2e610: mov     x19, x0                                    
02d2e614: ldrb    w8, [x20, #0xde]                           
02d2e618: tbnz    w8, #0, #0x2d2e63c                         
02d2e61c: adrp    x0, #0x626a000                             
02d2e620: ldr     x0, [x0, #0x5a8]                           M:DailyTask.PopupDailyTaskReward::OnButtonOpenClicked
02d2e624: bl      #0x2b70db0                                 fn_2b70db0
02d2e628: adrp    x0, #0x6265000                             
02d2e62c: ldr     x0, [x0, #0x3f0]                           T:UnityEngine.Events.UnityAction
02d2e630: bl      #0x2b70db0                                 fn_2b70db0
02d2e634: mov     w8, #1                                     
02d2e638: strb    w8, [x20, #0xde]                           
02d2e63c: ldr     x8, [x19, #0x38]                           ._openButton
02d2e640: cbz     x8, #0x2d2e690                             
02d2e644: adrp    x9, #0x6265000                             
02d2e648: adrp    x21, #0x626a000                            
02d2e64c: ldr     x9, [x9, #0x3f0]                           T:UnityEngine.Events.UnityAction
02d2e650: ldr     x21, [x21, #0x5a8]                         M:DailyTask.PopupDailyTaskReward::OnButtonOpenClicked
02d2e654: ldr     x20, [x8, #0x100]                          
02d2e658: ldr     x0, [x9]                                   M:AdsManager::<OnApplicationPause>b__26_0
02d2e65c: bl      #0x2b7104c                                 fn_2b7104c
02d2e660: ldr     x2, [x21]                                  T:type56879(k15)
02d2e664: mov     x1, x19                                    
02d2e668: mov     x3, xzr                                    
02d2e66c: mov     x21, x0                                    
02d2e670: bl      #0x5b4cf98                                 UnityEngine.Events.UnityAction::.ctor
02d2e674: cbz     x20, #0x2d2e690                            
02d2e678: mov     x0, x20                                    
02d2e67c: ldp     x20, x19, [sp, #0x10]                      
02d2e680: mov     x1, x21                                    
02d2e684: mov     x2, xzr                                    
02d2e688: ldp     x30, x21, [sp], #0x20                      
02d2e68c: b       #0x5b4d13c                                 UnityEngine.Events.UnityEvent::RemoveListener
02d2e690: bl      #0x2b7105c                                 fn_2b7105c
## OnInit(UIManager uiManager) -> void
---- DailyTask.PopupDailyTaskReward::OnInit 0x2d2e694
02d2e694: str     x30, [sp, #-0x30]!                         
02d2e698: stp     x22, x21, [sp, #0x10]                      
02d2e69c: stp     x20, x19, [sp, #0x20]                      
02d2e6a0: adrp    x21, #0x6630000                            
02d2e6a4: mov     x20, x1                                    
02d2e6a8: mov     x19, x0                                    
02d2e6ac: ldrb    w8, [x21, #0xdf]                           
02d2e6b0: tbnz    w8, #0, #0x2d2e6e0                         
02d2e6b4: adrp    x0, #0x6267000                             
02d2e6b8: ldr     x0, [x0, #0xbb0]                           MS:MonoSingleton`1::get_Instance
02d2e6bc: bl      #0x2b70db0                                 fn_2b70db0
02d2e6c0: adrp    x0, #0x626a000                             
02d2e6c4: ldr     x0, [x0, #0x5a8]                           M:DailyTask.PopupDailyTaskReward::OnButtonOpenClicked
02d2e6c8: bl      #0x2b70db0                                 fn_2b70db0
02d2e6cc: adrp    x0, #0x6265000                             
02d2e6d0: ldr     x0, [x0, #0x3f0]                           T:UnityEngine.Events.UnityAction
02d2e6d4: bl      #0x2b70db0                                 fn_2b70db0
02d2e6d8: mov     w8, #1                                     
02d2e6dc: strb    w8, [x21, #0xdf]                           
02d2e6e0: mov     x0, x19                                    
02d2e6e4: mov     x1, x20                                    
02d2e6e8: mov     x2, xzr                                    
02d2e6ec: bl      #0x2cdd3c4                                 UIBase::OnInit
02d2e6f0: ldr     x8, [x19, #0x38]                           ._openButton
02d2e6f4: cbz     x8, #0x2d2e768                             
02d2e6f8: adrp    x9, #0x6265000                             
02d2e6fc: adrp    x21, #0x626a000                            
02d2e700: ldr     x9, [x9, #0x3f0]                           T:UnityEngine.Events.UnityAction
02d2e704: ldr     x21, [x21, #0x5a8]                         M:DailyTask.PopupDailyTaskReward::OnButtonOpenClicked
02d2e708: ldr     x20, [x8, #0x100]                          
02d2e70c: ldr     x0, [x9]                                   M:AdsManager::<OnApplicationPause>b__26_0
02d2e710: bl      #0x2b7104c                                 fn_2b7104c
02d2e714: ldr     x2, [x21]                                  T:type56879(k15)
02d2e718: mov     x1, x19                                    
02d2e71c: mov     x3, xzr                                    
02d2e720: mov     x21, x0                                    
02d2e724: bl      #0x5b4cf98                                 UnityEngine.Events.UnityAction::.ctor
02d2e728: cbz     x20, #0x2d2e768                            
02d2e72c: adrp    x22, #0x6267000                            
02d2e730: mov     x0, x20                                    
02d2e734: mov     x1, x21                                    
02d2e738: ldr     x22, [x22, #0xbb0]                         MS:MonoSingleton`1::get_Instance
02d2e73c: mov     x2, xzr                                    
02d2e740: bl      #0x5b4d0ac                                 UnityEngine.Events.UnityEvent::AddListener
02d2e744: ldr     x0, [x22]                                  S:'didu'
02d2e748: bl      #0x3769600                                 fn_3769600
02d2e74c: str     x0, [x19, #0x58]!                          ._dailyTaskController
02d2e750: mov     x1, x0                                     
02d2e754: mov     x0, x19                                    
02d2e758: ldp     x20, x19, [sp, #0x20]                      
02d2e75c: ldp     x22, x21, [sp, #0x10]                      
02d2e760: ldr     x30, [sp], #0x30                           
02d2e764: b       #0x2b70d54                                 
02d2e768: bl      #0x2b7105c                                 fn_2b7105c
## OnShow() -> void
---- DailyTask.PopupDailyTaskReward::OnShow 0x2d2e76c
02d2e76c: stp     x30, x19, [sp, #-0x10]!                    
02d2e770: mov     x1, xzr                                    
02d2e774: mov     x19, x0                                    
02d2e778: bl      #0x2cdd6b8                                 UIBase::OnShow
02d2e77c: ldr     x0, [x19, #0x38]                           ._openButton
02d2e780: cbz     x0, #0x2d2e7a8                             
02d2e784: mov     w1, #1                                     
02d2e788: mov     x2, xzr                                    
02d2e78c: bl      #0x5e662d4                                 UnityEngine.UI.Selectable::set_interactable
02d2e790: ldr     x0, [x19, #0x50]                           ._tapToOpenObject
02d2e794: cbz     x0, #0x2d2e7a8                             
02d2e798: mov     w1, #1                                     
02d2e79c: mov     x2, xzr                                    
02d2e7a0: ldp     x30, x19, [sp], #0x10                      
02d2e7a4: b       #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d2e7a8: bl      #0x2b7105c                                 fn_2b7105c
## OnHide() -> void
---- DailyTask.PopupDailyTaskReward::OnHide 0x2d2e7ac
02d2e7ac: stp     x30, x19, [sp, #-0x10]!                    
02d2e7b0: mov     x1, xzr                                    
02d2e7b4: mov     x19, x0                                    
02d2e7b8: bl      #0x2cddc10                                 UIBase::OnHide
02d2e7bc: ldr     x0, [x19, #0x40]                           ._animator
02d2e7c0: cbz     x0, #0x2d2e7d0                             
02d2e7c4: mov     x1, xzr                                    
02d2e7c8: ldp     x30, x19, [sp], #0x10                      
02d2e7cc: b       #0x2cf3510                                 SkeletonGraphicHandler::ClearTrackEntry
02d2e7d0: bl      #0x2b7105c                                 fn_2b7105c
## OnButtonOpenClicked() -> void
---- DailyTask.PopupDailyTaskReward::OnButtonOpenClicked 0x2d2e7d4
02d2e7d4: str     x30, [sp, #-0x30]!                         
02d2e7d8: stp     x22, x21, [sp, #0x10]                      
02d2e7dc: stp     x20, x19, [sp, #0x20]                      
02d2e7e0: adrp    x20, #0x6630000                            
02d2e7e4: mov     x19, x0                                    
02d2e7e8: ldrb    w8, [x20, #0xe0]                           
02d2e7ec: tbnz    w8, #0, #0x2d2e81c                         
02d2e7f0: adrp    x0, #0x626a000                             
02d2e7f4: ldr     x0, [x0, #0x5b0]                           M:DailyTask.PopupDailyTaskReward::<OnButtonOpenClicked>b__9_0
02d2e7f8: bl      #0x2b70db0                                 fn_2b70db0
02d2e7fc: adrp    x0, #0x6265000                             
02d2e800: ldr     x0, [x0, #0x3f0]                           T:UnityEngine.Events.UnityAction
02d2e804: bl      #0x2b70db0                                 fn_2b70db0
02d2e808: adrp    x0, #0x626a000                             
02d2e80c: ldr     x0, [x0, #0x5b8]                           S:'open_gift'
02d2e810: bl      #0x2b70db0                                 fn_2b70db0
02d2e814: mov     w8, #1                                     
02d2e818: strb    w8, [x20, #0xe0]                           
02d2e81c: ldr     x0, [x19, #0x38]                           ._openButton
02d2e820: cbz     x0, #0x2d2e8d4                             
02d2e824: mov     w1, wzr                                    
02d2e828: mov     x2, xzr                                    
02d2e82c: bl      #0x5e662d4                                 UnityEngine.UI.Selectable::set_interactable
02d2e830: ldr     x0, [x19, #0x50]                           ._tapToOpenObject
02d2e834: cbz     x0, #0x2d2e8d4                             
02d2e838: mov     w1, wzr                                    
02d2e83c: mov     x2, xzr                                    
02d2e840: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d2e844: mov     x0, xzr                                    
02d2e848: bl      #0x2d6eec8                                 Framework.AudioManager::get_Instance
02d2e84c: cbz     x0, #0x2d2e8d4                             
02d2e850: movi    d1, #0000000000000000                      
02d2e854: movi    d2, #0000000000000000                      
02d2e858: adrp    x21, #0x6265000                            
02d2e85c: fmov    s0, #1.00000000                            
02d2e860: adrp    x22, #0x626a000                            
02d2e864: ldr     x21, [x21, #0x3f0]                         T:UnityEngine.Events.UnityAction
02d2e868: ldr     x22, [x22, #0x5b0]                         M:DailyTask.PopupDailyTaskReward::<OnButtonOpenClicked>b__9_0
02d2e86c: mov     w1, #1                                     
02d2e870: mov     w2, wzr                                    
02d2e874: mov     w3, wzr                                    
02d2e878: mov     x4, xzr                                    
02d2e87c: bl      #0x2d6f03c                                 Framework.AudioManager::PlaySound
02d2e880: ldr     x0, [x21]                                  M:AdsManager::<OnApplicationPause>b__26_0
02d2e884: ldr     x20, [x19, #0x40]                          ._animator
02d2e888: bl      #0x2b7104c                                 fn_2b7104c
02d2e88c: ldr     x2, [x22]                                  T:type56879(k15)
02d2e890: mov     x1, x19                                    
02d2e894: mov     x3, xzr                                    
02d2e898: mov     x21, x0                                    
02d2e89c: bl      #0x5b4cf98                                 UnityEngine.Events.UnityAction::.ctor
02d2e8a0: cbz     x20, #0x2d2e8d4                            
02d2e8a4: adrp    x8, #0x626a000                             
02d2e8a8: mov     x0, x20                                    
02d2e8ac: mov     x4, x21                                    
02d2e8b0: ldr     x8, [x8, #0x5b8]                           S:'open_gift'
02d2e8b4: ldp     x20, x19, [sp, #0x20]                      
02d2e8b8: ldp     x22, x21, [sp, #0x10]                      
02d2e8bc: mov     w2, wzr                                    
02d2e8c0: ldr     x1, [x8]                                   T:type56879(k15)
02d2e8c4: mov     x3, xzr                                    
02d2e8c8: mov     x5, xzr                                    
02d2e8cc: ldr     x30, [sp], #0x30                           
02d2e8d0: b       #0x2cf30c4                                 SkeletonGraphicHandler::PlayAnimation
02d2e8d4: bl      #0x2b7105c                                 fn_2b7105c
## .ctor() -> void
---- DailyTask.PopupDailyTaskReward::.ctor 0x2d2e8d8
02d2e8d8: mov     x1, xzr                                    
02d2e8dc: b       #0x2cddba8                                 PopupBase::.ctor
## <OnButtonOpenClicked>b__9_0() -> void
---- DailyTask.PopupDailyTaskReward::<OnButtonOpenClicked>b__9_0 0x2d2e8e0
02d2e8e0: str     d10, [sp, #-0x50]!                         
02d2e8e4: stp     d9, d8, [sp, #0x10]                        
02d2e8e8: stp     x30, x23, [sp, #0x20]                      
02d2e8ec: stp     x22, x21, [sp, #0x30]                      
02d2e8f0: stp     x20, x19, [sp, #0x40]                      
02d2e8f4: adrp    x20, #0x6630000                            
02d2e8f8: mov     x19, x0                                    
02d2e8fc: ldrb    w8, [x20, #0xe1]                           
02d2e900: tbnz    w8, #0, #0x2d2e954                         
02d2e904: adrp    x0, #0x6264000                             
02d2e908: ldr     x0, [x0, #0xf90]                           T:System.Action
02d2e90c: bl      #0x2b70db0                                 fn_2b70db0
02d2e910: adrp    x0, #0x6263000                             
02d2e914: ldr     x0, [x0, #0x928]                           T:UnityEngine.Debug
02d2e918: bl      #0x2b70db0                                 fn_2b70db0
02d2e91c: adrp    x0, #0x6266000                             
02d2e920: ldr     x0, [x0, #0xaa0]                           MS:MonoSingleton`1::get_Instance
02d2e924: bl      #0x2b70db0                                 fn_2b70db0
02d2e928: adrp    x0, #0x626a000                             
02d2e92c: ldr     x0, [x0, #0x5c0]                           M:DailyTask.PopupDailyTaskReward::<OnButtonOpenClicked>b__9_1
02d2e930: bl      #0x2b70db0                                 fn_2b70db0
02d2e934: adrp    x0, #0x626a000                             
02d2e938: ldr     x0, [x0, #0x5c8]                           S:'🎉 Daily Task Reward: {0} coins'
02d2e93c: bl      #0x2b70db0                                 fn_2b70db0
02d2e940: adrp    x0, #0x626a000                             
02d2e944: ldr     x0, [x0, #0x5d0]                           S:'open_gift2'
02d2e948: bl      #0x2b70db0                                 fn_2b70db0
02d2e94c: mov     w8, #1                                     
02d2e950: strb    w8, [x20, #0xe1]                           
02d2e954: mov     x0, xzr                                    
02d2e958: bl      #0x2d6eec8                                 Framework.AudioManager::get_Instance
02d2e95c: cbz     x0, #0x2d2eac0                             
02d2e960: movi    d1, #0000000000000000                      
02d2e964: movi    d2, #0000000000000000                      
02d2e968: mov     w1, #3                                     
02d2e96c: fmov    s0, #1.00000000                            
02d2e970: mov     w2, wzr                                    
02d2e974: mov     w3, wzr                                    
02d2e978: mov     x4, xzr                                    
02d2e97c: bl      #0x2d6f03c                                 Framework.AudioManager::PlaySound
02d2e980: ldr     x0, [x19, #0x40]                           ._animator
02d2e984: cbz     x0, #0x2d2eac0                             
02d2e988: adrp    x8, #0x626a000                             
02d2e98c: mov     w2, #1                                     
02d2e990: mov     x3, xzr                                    
02d2e994: ldr     x8, [x8, #0x5d0]                           S:'open_gift2'
02d2e998: mov     x4, xzr                                    
02d2e99c: mov     x5, xzr                                    
02d2e9a0: ldr     x1, [x8]                                   T:type56879(k15)
02d2e9a4: bl      #0x2cf30c4                                 SkeletonGraphicHandler::PlayAnimation
02d2e9a8: ldr     x8, [x19, #0x58]                           ._dailyTaskController
02d2e9ac: cbz     x8, #0x2d2eac0                             
02d2e9b0: ldr     x0, [x8, #0x40]                            MS:System.Collections.Generic.List`1::IndexOf
02d2e9b4: cbz     x0, #0x2d2eac0                             
02d2e9b8: adrp    x21, #0x626a000                            
02d2e9bc: adrp    x23, #0x6263000                            
02d2e9c0: adrp    x22, #0x6266000                            
02d2e9c4: ldr     x21, [x21, #0x5c8]                         S:'🎉 Daily Task Reward: {0} coins'
02d2e9c8: ldr     x23, [x23, #0x928]                         T:UnityEngine.Debug
02d2e9cc: ldr     x22, [x22, #0xaa0]                         MS:MonoSingleton`1::get_Instance
02d2e9d0: bl      #0x2d2bc8c                                 DailyTask.DailyTaskSO::GetRandomRewardAmount
02d2e9d4: adrp    x8, #0x6263000                             
02d2e9d8: mov     w20, w0                                    
02d2e9dc: add     x1, sp, #0xc                               
02d2e9e0: ldr     x8, [x8, #0x970]                           &6645c70(=0)
02d2e9e4: str     w20, [sp, #0xc]                            
02d2e9e8: ldr     x0, [x8, #0x48]                            &6263098(=0)
02d2e9ec: bl      #0x2b70f38                                 fn_2b70f38
02d2e9f0: ldr     x8, [x21]                                  T:type56879(k15)
02d2e9f4: mov     x1, x0                                     
02d2e9f8: mov     x2, xzr                                    
02d2e9fc: mov     x0, x8                                     
02d2ea00: bl      #0x4c9d0ec                                 System.String::Format
02d2ea04: ldr     x8, [x23]                                  &2c5bbd4(=a9bd7bfdd503233f)
02d2ea08: mov     x21, x0                                    
02d2ea0c: ldr     w9, [x8, #0xe4]                            [62630e4]=0 f=0,0
02d2ea10: cbnz    w9, #0x2d2ea1c                             
02d2ea14: mov     x0, x8                                     
02d2ea18: bl      #0x2b70f30                                 fn_2b70f30
02d2ea1c: mov     x0, x21                                    
02d2ea20: mov     x1, xzr                                    
02d2ea24: bl      #0x5af21f4                                 UnityEngine.Debug::Log
02d2ea28: ldr     x0, [x22]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d2ea2c: bl      #0x3769600                                 fn_3769600
02d2ea30: ldr     x8, [x19, #0x48]                           ._spawnPoint
02d2ea34: cbz     x8, #0x2d2eac0                             
02d2ea38: adrp    x22, #0x6264000                            
02d2ea3c: adrp    x23, #0x626a000                            
02d2ea40: mov     x21, x0                                    
02d2ea44: ldr     x22, [x22, #0xf90]                         T:System.Action
02d2ea48: ldr     x23, [x23, #0x5c0]                         M:DailyTask.PopupDailyTaskReward::<OnButtonOpenClicked>b__9_1
02d2ea4c: mov     x0, x8                                     
02d2ea50: mov     x1, xzr                                    
02d2ea54: bl      #0x5b467ac                                 UnityEngine.Transform::get_position
02d2ea58: ldr     x0, [x22]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d2ea5c: fmov    s8, s0                                     
02d2ea60: fmov    s9, s1                                     
02d2ea64: fmov    s10, s2                                    
02d2ea68: bl      #0x2b7104c                                 fn_2b7104c
02d2ea6c: ldr     x2, [x23]                                  T:type56879(k15)
02d2ea70: mov     x1, x19                                    
02d2ea74: mov     x3, xzr                                    
02d2ea78: mov     x22, x0                                    
02d2ea7c: bl      #0x4d8ddbc                                 System.Action::.ctor
02d2ea80: cbz     x21, #0x2d2eac0                            
02d2ea84: fmov    s0, s8                                     
02d2ea88: fmov    s1, s9                                     
02d2ea8c: mov     x0, x21                                    
02d2ea90: fmov    s2, s10                                    
02d2ea94: mov     w1, w20                                    
02d2ea98: mov     w2, #0xa                                   
02d2ea9c: mov     x3, x22                                    
02d2eaa0: mov     x4, xzr                                    
02d2eaa4: bl      #0x2cdb0e0                                 MoneyManager::CollectMoney
02d2eaa8: ldp     x20, x19, [sp, #0x40]                      
02d2eaac: ldp     x22, x21, [sp, #0x30]                      
02d2eab0: ldp     x30, x23, [sp, #0x20]                      
02d2eab4: ldp     d9, d8, [sp, #0x10]                        
02d2eab8: ldr     d10, [sp], #0x50                           
02d2eabc: ret                                                
02d2eac0: bl      #0x2b7105c                                 fn_2b7105c
## <OnButtonOpenClicked>b__9_1() -> void
---- DailyTask.PopupDailyTaskReward::<OnButtonOpenClicked>b__9_1 0x2d2eac4
02d2eac4: ldr     x8, [x0]                                   
02d2eac8: ldp     x2, x1, [x8, #0x198]                       
02d2eacc: br      x2                                         
