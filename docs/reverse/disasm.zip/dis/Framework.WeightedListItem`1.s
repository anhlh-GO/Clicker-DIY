#### CLASS Framework.WeightedListItem`1 parent= System.ValueType
#   field _item                          T                                                  off=0x0 attr=23 
#   field _weight                        int                                                off=0x0 attr=23 
##  .ctor (no body)
