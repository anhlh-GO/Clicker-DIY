#### CLASS GiftBoxLuckyWheel/<>c parent= object
#   field <>9                            GiftBoxLuckyWheel/<>c                              off=0x0 attr=36 
#   field <>9__27_0                      DG.Tweening.TweenCallback                          off=0x8 attr=16 
#   field <>9__27_2                      DG.Tweening.TweenCallback                          off=0x10 attr=16 
## .cctor() -> void
---- GiftBoxLuckyWheel/<>c::.cctor 0x2ce1398
02ce1398: str     x30, [sp, #-0x20]!                         
02ce139c: stp     x20, x19, [sp, #0x10]                      
02ce13a0: adrp    x19, #0x662f000                            
02ce13a4: adrp    x20, #0x6267000                            
02ce13a8: ldrb    w8, [x19, #0xdb0]                          
02ce13ac: ldr     x20, [x20, #0xf68]                         T:GiftBoxLuckyWheel/<>c
02ce13b0: tbnz    w8, #0, #0x2ce13c8                         
02ce13b4: adrp    x0, #0x6267000                             
02ce13b8: ldr     x0, [x0, #0xf68]                           T:GiftBoxLuckyWheel/<>c
02ce13bc: bl      #0x2b70db0                                 fn_2b70db0
02ce13c0: mov     w8, #1                                     
02ce13c4: strb    w8, [x19, #0xdb0]                          
02ce13c8: ldr     x0, [x20]                                  S:'didu'
02ce13cc: bl      #0x2b7104c                                 fn_2b7104c
02ce13d0: mov     x1, xzr                                    
02ce13d4: mov     x19, x0                                    
02ce13d8: bl      #0x4e53e9c                                 System.Object::.ctor
02ce13dc: ldr     x8, [x20]                                  S:'didu'
02ce13e0: mov     x1, x19                                    
02ce13e4: ldr     x8, [x8, #0xb8]                            
02ce13e8: str     x19, [x8]                                  
02ce13ec: ldr     x8, [x20]                                  S:'didu'
02ce13f0: ldp     x20, x19, [sp, #0x10]                      
02ce13f4: ldr     x0, [x8, #0xb8]                            
02ce13f8: ldr     x30, [sp], #0x20                           
02ce13fc: b       #0x2b70d54                                 
## .ctor() -> void
---- GiftBoxLuckyWheel/<>c::.ctor 0x2ce1400
02ce1400: mov     x1, xzr                                    
02ce1404: b       #0x4e53e9c                                 System.Object::.ctor
## <AnimUnbox>b__27_0() -> void
---- GiftBoxLuckyWheel/<>c::<AnimUnbox>b__27_0 0x2ce1408
02ce1408: str     x30, [sp, #-0x10]!                         
02ce140c: mov     x0, xzr                                    
02ce1410: bl      #0x2d6eec8                                 Framework.AudioManager::get_Instance
02ce1414: cbz     x0, #0x2ce143c                             
02ce1418: movi    d1, #0000000000000000                      
02ce141c: movi    d2, #0000000000000000                      
02ce1420: mov     w1, #0x2e                                  
02ce1424: fmov    s0, #1.00000000                            
02ce1428: mov     w2, wzr                                    
02ce142c: mov     w3, wzr                                    
02ce1430: mov     x4, xzr                                    
02ce1434: ldr     x30, [sp], #0x10                           
02ce1438: b       #0x2d6f03c                                 Framework.AudioManager::PlaySound
02ce143c: bl      #0x2b7105c                                 fn_2b7105c
## <AnimUnbox>b__27_2() -> void
---- GiftBoxLuckyWheel/<>c::<AnimUnbox>b__27_2 0x2ce1440
02ce1440: str     x30, [sp, #-0x10]!                         
02ce1444: mov     x0, xzr                                    
02ce1448: bl      #0x2d6eec8                                 Framework.AudioManager::get_Instance
02ce144c: cbz     x0, #0x2ce1474                             
02ce1450: movi    d1, #0000000000000000                      
02ce1454: movi    d2, #0000000000000000                      
02ce1458: mov     w1, #0x32                                  
02ce145c: fmov    s0, #1.00000000                            
02ce1460: mov     w2, wzr                                    
02ce1464: mov     w3, wzr                                    
02ce1468: mov     x4, xzr                                    
02ce146c: ldr     x30, [sp], #0x10                           
02ce1470: b       #0x2d6f03c                                 Framework.AudioManager::PlaySound
02ce1474: bl      #0x2b7105c                                 fn_2b7105c
#### CLASS GiftBoxLuckyWheel/<>c__DisplayClass24_0 parent= object
#   field rarityData                     RarityVisualDataItem                               off=0x10 attr=6 
## .ctor() -> void
---- GiftBoxLuckyWheel/<>c__DisplayClass24_0::.ctor 0x2ce0864
02ce0864: mov     x1, xzr                                    
02ce0868: b       #0x4e53e9c                                 System.Object::.ctor
## <SetReward>b__0(UnityEngine.UI.Image x) -> void
---- GiftBoxLuckyWheel/<>c__DisplayClass24_0::<SetReward>b__0 0x2ce1478
02ce1478: str     x30, [sp, #-0x10]!                         
02ce147c: ldr     x8, [x0, #0x10]                            .rarityData
02ce1480: cbz     x8, #0x2ce14a0                             
02ce1484: cbz     x1, #0x2ce14a0                             
02ce1488: ldr     x8, [x8, #0x20]                            
02ce148c: mov     x0, x1                                     
02ce1490: mov     x2, xzr                                    
02ce1494: mov     x1, x8                                     
02ce1498: ldr     x30, [sp], #0x10                           
02ce149c: b       #0x5c45aa0                                 UnityEngine.UI.Image::set_sprite
02ce14a0: bl      #0x2b7105c                                 fn_2b7105c
#### CLASS GiftBoxLuckyWheel/<>c__DisplayClass25_0 parent= object
#   field rarityData                     RarityVisualDataItem                               off=0x10 attr=6 
## .ctor() -> void
---- GiftBoxLuckyWheel/<>c__DisplayClass25_0::.ctor 0x2ce0b60
02ce0b60: mov     x1, xzr                                    
02ce0b64: b       #0x4e53e9c                                 System.Object::.ctor
## <SetRewardCoin>b__0(UnityEngine.UI.Image x) -> void
---- GiftBoxLuckyWheel/<>c__DisplayClass25_0::<SetRewardCoin>b__0 0x2ce14a4
02ce14a4: str     x30, [sp, #-0x10]!                         
02ce14a8: ldr     x8, [x0, #0x10]                            .rarityData
02ce14ac: cbz     x8, #0x2ce14cc                             
02ce14b0: cbz     x1, #0x2ce14cc                             
02ce14b4: ldr     x8, [x8, #0x20]                            
02ce14b8: mov     x0, x1                                     
02ce14bc: mov     x2, xzr                                    
02ce14c0: mov     x1, x8                                     
02ce14c4: ldr     x30, [sp], #0x10                           
02ce14c8: b       #0x5c45aa0                                 UnityEngine.UI.Image::set_sprite
02ce14cc: bl      #0x2b7105c                                 fn_2b7105c
#### CLASS GiftBoxLuckyWheel/<>c__DisplayClass26_0 parent= object
#   field onCloseClick                   System.Action                                      off=0x10 attr=6 
#   field <>4__this                      GiftBoxLuckyWheel                                  off=0x18 attr=6 
#   field <>9__1                         System.Action                                      off=0x20 attr=6 
## .ctor() -> void
---- GiftBoxLuckyWheel/<>c__DisplayClass26_0::.ctor 0x2ce0c68
02ce0c68: mov     x1, xzr                                    
02ce0c6c: b       #0x4e53e9c                                 System.Object::.ctor
## <SetOnclickEvent>b__0() -> void
---- GiftBoxLuckyWheel/<>c__DisplayClass26_0::<SetOnclickEvent>b__0 0x2ce14d0
02ce14d0: stp     x30, x23, [sp, #-0x30]!                    
02ce14d4: stp     x22, x21, [sp, #0x10]                      
02ce14d8: stp     x20, x19, [sp, #0x20]                      
02ce14dc: adrp    x21, #0x662f000                            
02ce14e0: adrp    x22, #0x6265000                            
02ce14e4: adrp    x20, #0x6267000                            
02ce14e8: ldrb    w8, [x21, #0xdb1]                          
02ce14ec: ldr     x22, [x22, #0x310]                         MS:WejoyService.Singleton`1::get_Instance
02ce14f0: ldr     x20, [x20, #0xf78]                         S:'giftbox'
02ce14f4: mov     x19, x0                                    
02ce14f8: tbnz    w8, #0, #0x2ce1534                         
02ce14fc: adrp    x0, #0x6264000                             
02ce1500: ldr     x0, [x0, #0xf90]                           T:System.Action
02ce1504: bl      #0x2b70db0                                 fn_2b70db0
02ce1508: adrp    x0, #0x6265000                             
02ce150c: ldr     x0, [x0, #0x310]                           MS:WejoyService.Singleton`1::get_Instance
02ce1510: bl      #0x2b70db0                                 fn_2b70db0
02ce1514: adrp    x0, #0x6267000                             
02ce1518: ldr     x0, [x0, #0xf80]                           M:GiftBoxLuckyWheel/<>c__DisplayClass26_0::<SetOnclickEvent>b__1
02ce151c: bl      #0x2b70db0                                 fn_2b70db0
02ce1520: adrp    x0, #0x6267000                             
02ce1524: ldr     x0, [x0, #0xf78]                           S:'giftbox'
02ce1528: bl      #0x2b70db0                                 fn_2b70db0
02ce152c: mov     w8, #1                                     
02ce1530: strb    w8, [x21, #0xdb1]                          
02ce1534: ldr     x0, [x22]                                  M:AdsManager::<OnApplicationPause>b__26_0
02ce1538: bl      #0x3be7218                                 fn_3be7218
02ce153c: mov     x23, x19                                   
02ce1540: ldr     x20, [x20]                                 S:'didu'
02ce1544: mov     x21, x0                                    
02ce1548: ldr     x22, [x23, #0x20]!                         
02ce154c: cbnz    x22, #0x2ce158c                            
02ce1550: adrp    x8, #0x6264000                             
02ce1554: ldr     x8, [x8, #0xf90]                           T:System.Action
02ce1558: ldr     x0, [x8]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02ce155c: bl      #0x2b7104c                                 fn_2b7104c
02ce1560: adrp    x8, #0x6267000                             
02ce1564: mov     x1, x19                                    
02ce1568: mov     x3, xzr                                    
02ce156c: ldr     x8, [x8, #0xf80]                           M:GiftBoxLuckyWheel/<>c__DisplayClass26_0::<SetOnclickEvent>b__1
02ce1570: mov     x22, x0                                    
02ce1574: ldr     x2, [x8]                                   S:'didu'
02ce1578: bl      #0x4d8ddbc                                 System.Action::.ctor
02ce157c: mov     x0, x23                                    
02ce1580: mov     x1, x22                                    
02ce1584: str     x22, [x19, #0x20]                          .<>9__1
02ce1588: bl      #0x2b70d54                                 fn_2b70d54
02ce158c: cbz     x21, #0x2ce15b4                            
02ce1590: mov     x0, x21                                    
02ce1594: mov     x1, x20                                    
02ce1598: mov     x2, x22                                    
02ce159c: ldp     x20, x19, [sp, #0x20]                      
02ce15a0: mov     w3, wzr                                    
02ce15a4: ldp     x22, x21, [sp, #0x10]                      
02ce15a8: mov     x4, xzr                                    
02ce15ac: ldp     x30, x23, [sp], #0x30                      
02ce15b0: b       #0x2c89698                                 AdsManager::ShowInter
02ce15b4: bl      #0x2b7105c                                 fn_2b7105c
## <SetOnclickEvent>b__1() -> void
---- GiftBoxLuckyWheel/<>c__DisplayClass26_0::<SetOnclickEvent>b__1 0x2ce15b8
02ce15b8: stp     x30, x19, [sp, #-0x10]!                    
02ce15bc: ldr     x8, [x0, #0x10]                            .onCloseClick
02ce15c0: mov     x19, x0                                    
02ce15c4: cbz     x8, #0x2ce15d8                             
02ce15c8: ldr     x9, [x8, #0x18]                            
02ce15cc: ldr     x0, [x8, #0x40]                            
02ce15d0: ldr     x1, [x8, #0x28]                            
02ce15d4: blr     x9                                         
02ce15d8: ldr     x8, [x19, #0x18]                           .<>4__this
02ce15dc: cbz     x8, #0x2ce1620                             
02ce15e0: movi    d0, #0000000000000000                      
02ce15e4: movi    d1, #0000000000000000                      
02ce15e8: ldr     x0, [x8, #0x78]                            
02ce15ec: mov     x1, xzr                                    
02ce15f0: bl      #0x2c789b8                                 DG.Tweening.DOTweenModuleUI::DOFade
02ce15f4: ldr     x8, [x19, #0x18]                           .<>4__this
02ce15f8: cbz     x8, #0x2ce1620                             
02ce15fc: ldr     x0, [x8, #0xa0]                            
02ce1600: cbz     x0, #0x2ce1620                             
02ce1604: mov     x1, xzr                                    
02ce1608: bl      #0x5b339ec                                 UnityEngine.Component::get_gameObject
02ce160c: cbz     x0, #0x2ce1620                             
02ce1610: mov     w1, wzr                                    
02ce1614: mov     x2, xzr                                    
02ce1618: ldp     x30, x19, [sp], #0x10                      
02ce161c: b       #0x5b36b38                                 UnityEngine.GameObject::SetActive
02ce1620: bl      #0x2b7105c                                 fn_2b7105c
#### CLASS GiftBoxLuckyWheel parent= UnityEngine.MonoBehaviour
#   field _imgLid                        UnityEngine.UI.Image                               off=0x20 attr=1 SerializeField
#   field _imgBody                       UnityEngine.UI.Image                               off=0x28 attr=1 SerializeField
#   field _imgFront                      UnityEngine.UI.Image                               off=0x30 attr=1 SerializeField
#   field _imgReward                     UnityEngine.UI.Image                               off=0x38 attr=1 SerializeField
#   field _imgFlash                      UnityEngine.UI.Image                               off=0x40 attr=1 SerializeField
#   field _lidSprites                    System.Collections.Generic.List`1<UnityEngine.Sprite> off=0x48 attr=1 SerializeField
#   field _bodySprites                   System.Collections.Generic.List`1<UnityEngine.Sprite> off=0x50 attr=1 SerializeField
#   field _frontSprites                  System.Collections.Generic.List`1<UnityEngine.Sprite> off=0x58 attr=1 SerializeField
#   field _imgCircleGlow                 UnityEngine.UI.Image                               off=0x60 attr=1 SerializeField
#   field _imgStars                      System.Collections.Generic.List`1<UnityEngine.UI.Image> off=0x68 attr=1 SerializeField
#   field _imgRarityPanel                UnityEngine.UI.Image                               off=0x70 attr=1 SerializeField
#   field _bgBlack                       UnityEngine.UI.Image                               off=0x78 attr=1 SerializeField
#   field _coinSprite                    UnityEngine.Sprite                                 off=0x80 attr=1 SerializeField
#   field _rtGiftBox                     UnityEngine.RectTransform                          off=0x88 attr=1 SerializeField
#   field _tfStarHolder                  UnityEngine.Transform                              off=0x90 attr=1 SerializeField
#   field _tfGlow                        UnityEngine.Transform                              off=0x98 attr=1 SerializeField
#   field _tfFullContent                 UnityEngine.Transform                              off=0xa0 attr=1 SerializeField
#   field _rarityVisualConfig            RarityVisualConfig                                 off=0xa8 attr=1 SerializeField
#   field _btnCloseGiftBox               UnityEngine.UI.Button                              off=0xb0 attr=1 SerializeField
#   field _coin                          int                                                off=0xb8 attr=1 
#   field _animSequence                  DG.Tweening.Sequence                               off=0xc0 attr=1 
## get_BtnCloseGiftBox() -> UnityEngine.UI.Button
---- GiftBoxLuckyWheel::get_BtnCloseGiftBox 0x2ce0398
02ce0398: ldr     x0, [x0, #0xb0]                            ._btnCloseGiftBox
02ce039c: ret                                                
## SetGiftBox(int index) -> void
---- GiftBoxLuckyWheel::SetGiftBox 0x2ce03a0
02ce03a0: str     x30, [sp, #-0x30]!                         
02ce03a4: stp     x22, x21, [sp, #0x10]                      
02ce03a8: stp     x20, x19, [sp, #0x20]                      
02ce03ac: adrp    x21, #0x662f000                            
02ce03b0: mov     w20, w1                                    
02ce03b4: mov     x19, x0                                    
02ce03b8: ldrb    w8, [x21, #0xda9]                          
02ce03bc: tbnz    w8, #0, #0x2ce03e0                         
02ce03c0: adrp    x0, #0x6266000                             
02ce03c4: ldr     x0, [x0, #0xc30]                           MS:System.Collections.Generic.List`1::get_Count
02ce03c8: bl      #0x2b70db0                                 fn_2b70db0
02ce03cc: adrp    x0, #0x6266000                             
02ce03d0: ldr     x0, [x0, #0xc38]                           MS:System.Collections.Generic.List`1::get_Item
02ce03d4: bl      #0x2b70db0                                 fn_2b70db0
02ce03d8: mov     w8, #1                                     
02ce03dc: strb    w8, [x21, #0xda9]                          
02ce03e0: tbnz    w20, #0x1f, #0x2ce0614                     
02ce03e4: ldr     x0, [x19, #0x48]                           ._lidSprites
02ce03e8: cbz     x0, #0x2ce0624                             
02ce03ec: ldr     w8, [x0, #0x18]                            S:'level_show_popuprate'
02ce03f0: cmp     w8, w20                                    
02ce03f4: b.le    #0x2ce0614                                 
02ce03f8: ldr     x8, [x19, #0x50]                           ._bodySprites
02ce03fc: cbz     x8, #0x2ce0624                             
02ce0400: ldr     w8, [x8, #0x18]                            
02ce0404: cmp     w8, w20                                    
02ce0408: b.le    #0x2ce0614                                 
02ce040c: adrp    x22, #0x6266000                            
02ce0410: mov     w1, w20                                    
02ce0414: ldr     x22, [x22, #0xc38]                         MS:System.Collections.Generic.List`1::get_Item
02ce0418: ldr     x21, [x19, #0x20]                          ._imgLid
02ce041c: ldr     x2, [x22]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ce0420: bl      #0x35a8f3c                                 fn_35a8f3c
02ce0424: cbz     x21, #0x2ce0624                            
02ce0428: mov     x1, x0                                     
02ce042c: mov     x0, x21                                    
02ce0430: mov     x2, xzr                                    
02ce0434: bl      #0x5c45aa0                                 UnityEngine.UI.Image::set_sprite
02ce0438: ldr     x0, [x19, #0x50]                           ._bodySprites
02ce043c: cbz     x0, #0x2ce0624                             
02ce0440: ldr     x2, [x22]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ce0444: ldr     x21, [x19, #0x28]                          ._imgBody
02ce0448: mov     w1, w20                                    
02ce044c: bl      #0x35a8f3c                                 fn_35a8f3c
02ce0450: cbz     x21, #0x2ce0624                            
02ce0454: mov     x1, x0                                     
02ce0458: mov     x0, x21                                    
02ce045c: mov     x2, xzr                                    
02ce0460: bl      #0x5c45aa0                                 UnityEngine.UI.Image::set_sprite
02ce0464: ldr     x0, [x19, #0x58]                           ._frontSprites
02ce0468: cbz     x0, #0x2ce0624                             
02ce046c: ldr     x2, [x22]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ce0470: ldr     x21, [x19, #0x30]                          ._imgFront
02ce0474: mov     w1, w20                                    
02ce0478: bl      #0x35a8f3c                                 fn_35a8f3c
02ce047c: cbz     x21, #0x2ce0624                            
02ce0480: mov     x1, x0                                     
02ce0484: mov     x0, x21                                    
02ce0488: mov     x2, xzr                                    
02ce048c: bl      #0x5c45aa0                                 UnityEngine.UI.Image::set_sprite
02ce0490: movi    d1, #0000000000000000                      
02ce0494: mov     w8, #0x445c0000                            
02ce0498: ldr     x0, [x19, #0x88]                           ._rtGiftBox
02ce049c: fmov    s0, w8                                     
02ce04a0: mov     w1, wzr                                    
02ce04a4: mov     x2, xzr                                    
02ce04a8: bl      #0x2c79c1c                                 DG.Tweening.DOTweenModuleUI::DOAnchorPosY
02ce04ac: ldr     x0, [x19, #0x88]                           ._rtGiftBox
02ce04b0: cbz     x0, #0x2ce0624                             
02ce04b4: mov     x1, xzr                                    
02ce04b8: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02ce04bc: adrp    x21, #0x662f000                            
02ce04c0: mov     x20, x0                                    
02ce04c4: ldrb    w8, [x21, #0xa74]                          
02ce04c8: cbnz    w8, #0x2ce04e0                             
02ce04cc: adrp    x0, #0x6264000                             
02ce04d0: ldr     x0, [x0, #0xd8]                            T:UnityEngine.Vector3
02ce04d4: bl      #0x2b70db0                                 fn_2b70db0
02ce04d8: mov     w8, #1                                     
02ce04dc: strb    w8, [x21, #0xa74]                          
02ce04e0: cbz     x20, #0x2ce0624                            
02ce04e4: adrp    x21, #0x6264000                            
02ce04e8: mov     w9, #0xcccd                                
02ce04ec: mov     x0, x20                                    
02ce04f0: ldr     x21, [x21, #0xd8]                          T:UnityEngine.Vector3
02ce04f4: movk    w9, #0x3ecc, lsl #16                       
02ce04f8: mov     x1, xzr                                    
02ce04fc: dup     v0.2s, w9                                  
02ce0500: adrp    x9, #0x1084000                             
02ce0504: ldr     x8, [x21]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02ce0508: ldr     s2, [x9, #0xfb0]                           [1084fb0]=3f7d70a43ecccccd f=0.4,0.99
02ce050c: ldr     x8, [x8, #0xb8]                            
02ce0510: ldur    d1, [x8, #0xc]                             
02ce0514: fmul    v0.2s, v1.2s, v0.2s                        
02ce0518: ldr     s1, [x8, #0x14]                            
02ce051c: fmul    s2, s1, s2                                 
02ce0520: mov     s1, v0.s[1]                                
02ce0524: bl      #0x5b470cc                                 UnityEngine.Transform::set_localScale
02ce0528: movi    d0, #0000000000000000                      
02ce052c: movi    d1, #0000000000000000                      
02ce0530: ldr     x0, [x19, #0x78]                           ._bgBlack
02ce0534: mov     x1, xzr                                    
02ce0538: bl      #0x2c789b8                                 DG.Tweening.DOTweenModuleUI::DOFade
02ce053c: ldr     x0, [x19, #0x98]                           ._tfGlow
02ce0540: cbz     x0, #0x2ce0624                             
02ce0544: mov     x1, xzr                                    
02ce0548: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02ce054c: adrp    x22, #0x662f000                            
02ce0550: mov     x20, x0                                    
02ce0554: ldrb    w8, [x22, #0x91a]                          
02ce0558: cbnz    w8, #0x2ce0570                             
02ce055c: adrp    x0, #0x6264000                             
02ce0560: ldr     x0, [x0, #0xd8]                            T:UnityEngine.Vector3
02ce0564: bl      #0x2b70db0                                 fn_2b70db0
02ce0568: mov     w8, #1                                     
02ce056c: strb    w8, [x22, #0x91a]                          
02ce0570: cbz     x20, #0x2ce0624                            
02ce0574: ldr     x8, [x21]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02ce0578: mov     x0, x20                                    
02ce057c: mov     x1, xzr                                    
02ce0580: ldr     x8, [x8, #0xb8]                            
02ce0584: ldp     s1, s2, [x8, #4]                           
02ce0588: ldr     s0, [x8]                                   
02ce058c: bl      #0x5b470cc                                 UnityEngine.Transform::set_localScale
02ce0590: ldr     x0, [x19, #0x20]                           ._imgLid
02ce0594: cbz     x0, #0x2ce0624                             
02ce0598: mov     x1, xzr                                    
02ce059c: bl      #0x5c4e1ac                                 UnityEngine.UI.Graphic::get_rectTransform
02ce05a0: movi    d1, #0000000000000000                      
02ce05a4: mov     w8, #0x434c0000                            
02ce05a8: mov     w1, wzr                                    
02ce05ac: fmov    s0, w8                                     
02ce05b0: mov     x2, xzr                                    
02ce05b4: bl      #0x2c79c1c                                 DG.Tweening.DOTweenModuleUI::DOAnchorPosY
02ce05b8: movi    d0, #0000000000000000                      
02ce05bc: movi    d1, #0000000000000000                      
02ce05c0: ldr     x0, [x19, #0x40]                           ._imgFlash
02ce05c4: mov     x1, xzr                                    
02ce05c8: bl      #0x2c789b8                                 DG.Tweening.DOTweenModuleUI::DOFade
02ce05cc: movi    d1, #0000000000000000                      
02ce05d0: fmov    s0, #1.00000000                            
02ce05d4: ldr     x0, [x19, #0x28]                           ._imgBody
02ce05d8: mov     x1, xzr                                    
02ce05dc: bl      #0x2c789b8                                 DG.Tweening.DOTweenModuleUI::DOFade
02ce05e0: movi    d1, #0000000000000000                      
02ce05e4: fmov    s0, #1.00000000                            
02ce05e8: ldr     x0, [x19, #0x30]                           ._imgFront
02ce05ec: mov     x1, xzr                                    
02ce05f0: bl      #0x2c789b8                                 DG.Tweening.DOTweenModuleUI::DOFade
02ce05f4: ldr     x0, [x19, #0x20]                           ._imgLid
02ce05f8: ldp     x20, x19, [sp, #0x20]                      
02ce05fc: ldp     x22, x21, [sp, #0x10]                      
02ce0600: movi    d1, #0000000000000000                      
02ce0604: fmov    s0, #1.00000000                            
02ce0608: mov     x1, xzr                                    
02ce060c: ldr     x30, [sp], #0x30                           
02ce0610: b       #0x2c789b8                                 DG.Tweening.DOTweenModuleUI::DOFade
02ce0614: ldp     x20, x19, [sp, #0x20]                      
02ce0618: ldp     x22, x21, [sp, #0x10]                      
02ce061c: ldr     x30, [sp], #0x30                           
02ce0620: ret                                                
02ce0624: bl      #0x2b7105c                                 fn_2b7105c
## SetReward(UnityEngine.Sprite rewardSprite, RarityType rarity) -> void
---- GiftBoxLuckyWheel::SetReward 0x2ce0628
02ce0628: stp     x30, x23, [sp, #-0x30]!                    
02ce062c: stp     x22, x21, [sp, #0x10]                      
02ce0630: stp     x20, x19, [sp, #0x20]                      
02ce0634: adrp    x20, #0x662f000                            
02ce0638: adrp    x23, #0x6267000                            
02ce063c: mov     w21, w2                                    
02ce0640: ldrb    w8, [x20, #0xdaa]                          
02ce0644: ldr     x23, [x23, #0xee8]                         T:GiftBoxLuckyWheel/<>c__DisplayClass24_0
02ce0648: mov     x22, x1                                    
02ce064c: mov     x19, x0                                    
02ce0650: tbnz    w8, #0, #0x2ce068c                         
02ce0654: adrp    x0, #0x6267000                             
02ce0658: ldr     x0, [x0, #0xef0]                           T:type53136(k15)
02ce065c: bl      #0x2b70db0                                 fn_2b70db0
02ce0660: adrp    x0, #0x6267000                             
02ce0664: ldr     x0, [x0, #0xef8]                           MS:System.Collections.Generic.List`1::ForEach
02ce0668: bl      #0x2b70db0                                 fn_2b70db0
02ce066c: adrp    x0, #0x6267000                             
02ce0670: ldr     x0, [x0, #0xf00]                           M:GiftBoxLuckyWheel/<>c__DisplayClass24_0::<SetReward>b__0
02ce0674: bl      #0x2b70db0                                 fn_2b70db0
02ce0678: adrp    x0, #0x6267000                             
02ce067c: ldr     x0, [x0, #0xee8]                           T:GiftBoxLuckyWheel/<>c__DisplayClass24_0
02ce0680: bl      #0x2b70db0                                 fn_2b70db0
02ce0684: mov     w8, #1                                     
02ce0688: strb    w8, [x20, #0xdaa]                          
02ce068c: ldr     x0, [x23]                                  S:'didu'
02ce0690: bl      #0x2b7104c                                 fn_2b7104c
02ce0694: mov     x1, xzr                                    
02ce0698: mov     x20, x0                                    
02ce069c: bl      #0x4e53e9c                                 System.Object::.ctor
02ce06a0: ldr     x0, [x19, #0x38]                           ._imgReward
02ce06a4: str     wzr, [x19, #0xb8]                          ._coin
02ce06a8: cbz     x0, #0x2ce0860                             
02ce06ac: mov     x1, x22                                    
02ce06b0: mov     x2, xzr                                    
02ce06b4: bl      #0x5c45aa0                                 UnityEngine.UI.Image::set_sprite
02ce06b8: ldr     x0, [x19, #0x38]                           ._imgReward
02ce06bc: cbz     x0, #0x2ce0860                             
02ce06c0: mov     x1, xzr                                    
02ce06c4: bl      #0x5b339ec                                 UnityEngine.Component::get_gameObject
02ce06c8: cbz     x0, #0x2ce0860                             
02ce06cc: mov     w1, #1                                     
02ce06d0: mov     x2, xzr                                    
02ce06d4: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02ce06d8: ldr     x0, [x19, #0xa8]                           ._rarityVisualConfig
02ce06dc: cbz     x0, #0x2ce0860                             
02ce06e0: mov     w1, w21                                    
02ce06e4: bl      #0x2ce086c                                 RarityVisualConfig::GetDataByRarity
02ce06e8: cbz     x20, #0x2ce0860                            
02ce06ec: mov     x21, x20                                   
02ce06f0: mov     x1, x0                                     
02ce06f4: str     x0, [x21, #0x10]!                          
02ce06f8: mov     x0, x21                                    
02ce06fc: bl      #0x2b70d54                                 fn_2b70d54
02ce0700: ldr     x8, [x21]                                  
02ce0704: cbz     x8, #0x2ce0784                             
02ce0708: ldr     x0, [x19, #0x60]                           ._imgCircleGlow
02ce070c: cbz     x0, #0x2ce0860                             
02ce0710: ldr     x1, [x8, #0x18]                            
02ce0714: mov     x2, xzr                                    
02ce0718: bl      #0x5c45aa0                                 UnityEngine.UI.Image::set_sprite
02ce071c: ldr     x8, [x21]                                  
02ce0720: cbz     x8, #0x2ce0860                             
02ce0724: ldr     x0, [x19, #0x70]                           ._imgRarityPanel
02ce0728: cbz     x0, #0x2ce0860                             
02ce072c: adrp    x22, #0x6267000                            
02ce0730: adrp    x23, #0x6267000                            
02ce0734: mov     x2, xzr                                    
02ce0738: ldr     x22, [x22, #0xef0]                         T:type53136(k15)
02ce073c: ldr     x23, [x23, #0xf00]                         M:GiftBoxLuckyWheel/<>c__DisplayClass24_0::<SetReward>b__0
02ce0740: ldr     x1, [x8, #0x28]                            
02ce0744: bl      #0x5c45aa0                                 UnityEngine.UI.Image::set_sprite
02ce0748: ldr     x0, [x22]                                  S:'didu'
02ce074c: ldr     x21, [x19, #0x68]                          ._imgStars
02ce0750: bl      #0x2b7104c                                 fn_2b7104c
02ce0754: ldr     x2, [x23]                                  S:'didu'
02ce0758: mov     x1, x20                                    
02ce075c: mov     x3, xzr                                    
02ce0760: mov     x22, x0                                    
02ce0764: bl      #0x453418c                                 fn_453418c
02ce0768: cbz     x21, #0x2ce0860                            
02ce076c: adrp    x8, #0x6267000                             
02ce0770: mov     x0, x21                                    
02ce0774: mov     x1, x22                                    
02ce0778: ldr     x8, [x8, #0xef8]                           MS:System.Collections.Generic.List`1::ForEach
02ce077c: ldr     x2, [x8]                                   S:'didu'
02ce0780: bl      #0x35a9ce4                                 fn_35a9ce4
02ce0784: ldr     x0, [x19, #0x70]                           ._imgRarityPanel
02ce0788: cbz     x0, #0x2ce0860                             
02ce078c: mov     x1, xzr                                    
02ce0790: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02ce0794: adrp    x21, #0x662f000                            
02ce0798: mov     x20, x0                                    
02ce079c: ldrb    w8, [x21, #0x91a]                          
02ce07a0: cbnz    w8, #0x2ce07b8                             
02ce07a4: adrp    x0, #0x6264000                             
02ce07a8: ldr     x0, [x0, #0xd8]                            T:UnityEngine.Vector3
02ce07ac: bl      #0x2b70db0                                 fn_2b70db0
02ce07b0: mov     w8, #1                                     
02ce07b4: strb    w8, [x21, #0x91a]                          
02ce07b8: cbz     x20, #0x2ce0860                            
02ce07bc: adrp    x22, #0x6264000                            
02ce07c0: mov     x0, x20                                    
02ce07c4: mov     x1, xzr                                    
02ce07c8: ldr     x22, [x22, #0xd8]                          T:UnityEngine.Vector3
02ce07cc: ldr     x8, [x22]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02ce07d0: ldr     x8, [x8, #0xb8]                            M:Framework.SceneUtils/<CRUnloadSceneAsync>d__2::System.Collections.IEnumerator.Reset
02ce07d4: ldp     s1, s2, [x8, #4]                           
02ce07d8: ldr     s0, [x8]                                   S:'didu'
02ce07dc: bl      #0x5b470cc                                 UnityEngine.Transform::set_localScale
02ce07e0: ldr     x0, [x19, #0x70]                           ._imgRarityPanel
02ce07e4: cbz     x0, #0x2ce0860                             
02ce07e8: mov     x1, xzr                                    
02ce07ec: bl      #0x5c4e1ac                                 UnityEngine.UI.Graphic::get_rectTransform
02ce07f0: movi    d1, #0000000000000000                      
02ce07f4: fmov    s0, #20.00000000                           
02ce07f8: mov     w1, wzr                                    
02ce07fc: mov     x2, xzr                                    
02ce0800: bl      #0x2c79c1c                                 DG.Tweening.DOTweenModuleUI::DOAnchorPosY
02ce0804: ldr     x0, [x19, #0x90]                           ._tfStarHolder
02ce0808: cbz     x0, #0x2ce0860                             
02ce080c: mov     x1, xzr                                    
02ce0810: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02ce0814: ldrb    w8, [x21, #0x91a]                          
02ce0818: mov     x19, x0                                    
02ce081c: cbnz    w8, #0x2ce0834                             
02ce0820: adrp    x0, #0x6264000                             
02ce0824: ldr     x0, [x0, #0xd8]                            T:UnityEngine.Vector3
02ce0828: bl      #0x2b70db0                                 fn_2b70db0
02ce082c: mov     w8, #1                                     
02ce0830: strb    w8, [x21, #0x91a]                          
02ce0834: cbz     x19, #0x2ce0860                            
02ce0838: ldr     x8, [x22]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02ce083c: mov     x0, x19                                    
02ce0840: mov     x1, xzr                                    
02ce0844: ldp     x20, x19, [sp, #0x20]                      
02ce0848: ldr     x8, [x8, #0xb8]                            M:Framework.SceneUtils/<CRUnloadSceneAsync>d__2::System.Collections.IEnumerator.Reset
02ce084c: ldp     x22, x21, [sp, #0x10]                      
02ce0850: ldp     s0, s1, [x8]                               
02ce0854: ldr     s2, [x8, #8]                               S:'android.settings.WIFI_SETTINGS'
02ce0858: ldp     x30, x23, [sp], #0x30                      
02ce085c: b       #0x5b470cc                                 UnityEngine.Transform::set_localScale
02ce0860: bl      #0x2b7105c                                 fn_2b7105c
## SetRewardCoin(int coin) -> void
---- GiftBoxLuckyWheel::SetRewardCoin 0x2ce0944
02ce0944: stp     x30, x23, [sp, #-0x30]!                    
02ce0948: stp     x22, x21, [sp, #0x10]                      
02ce094c: stp     x20, x19, [sp, #0x20]                      
02ce0950: adrp    x20, #0x662f000                            
02ce0954: adrp    x22, #0x6267000                            
02ce0958: mov     w21, w1                                    
02ce095c: ldrb    w8, [x20, #0xdab]                          
02ce0960: ldr     x22, [x22, #0xf28]                         T:GiftBoxLuckyWheel/<>c__DisplayClass25_0
02ce0964: mov     x19, x0                                    
02ce0968: tbnz    w8, #0, #0x2ce09a4                         
02ce096c: adrp    x0, #0x6267000                             
02ce0970: ldr     x0, [x0, #0xef0]                           T:type53136(k15)
02ce0974: bl      #0x2b70db0                                 fn_2b70db0
02ce0978: adrp    x0, #0x6267000                             
02ce097c: ldr     x0, [x0, #0xef8]                           MS:System.Collections.Generic.List`1::ForEach
02ce0980: bl      #0x2b70db0                                 fn_2b70db0
02ce0984: adrp    x0, #0x6267000                             
02ce0988: ldr     x0, [x0, #0xf30]                           M:GiftBoxLuckyWheel/<>c__DisplayClass25_0::<SetRewardCoin>b__0
02ce098c: bl      #0x2b70db0                                 fn_2b70db0
02ce0990: adrp    x0, #0x6267000                             
02ce0994: ldr     x0, [x0, #0xf28]                           T:GiftBoxLuckyWheel/<>c__DisplayClass25_0
02ce0998: bl      #0x2b70db0                                 fn_2b70db0
02ce099c: mov     w8, #1                                     
02ce09a0: strb    w8, [x20, #0xdab]                          
02ce09a4: ldr     x0, [x22]                                  S:'didu'
02ce09a8: bl      #0x2b7104c                                 fn_2b7104c
02ce09ac: mov     x1, xzr                                    
02ce09b0: mov     x20, x0                                    
02ce09b4: bl      #0x4e53e9c                                 System.Object::.ctor
02ce09b8: ldr     x0, [x19, #0x38]                           ._imgReward
02ce09bc: str     w21, [x19, #0xb8]                          ._coin
02ce09c0: cbz     x0, #0x2ce0b5c                             
02ce09c4: mov     x1, xzr                                    
02ce09c8: bl      #0x5b339ec                                 UnityEngine.Component::get_gameObject
02ce09cc: cbz     x0, #0x2ce0b5c                             
02ce09d0: mov     w1, wzr                                    
02ce09d4: mov     x2, xzr                                    
02ce09d8: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02ce09dc: ldr     x0, [x19, #0xa8]                           ._rarityVisualConfig
02ce09e0: cbz     x0, #0x2ce0b5c                             
02ce09e4: mov     w1, #2                                     
02ce09e8: bl      #0x2ce086c                                 RarityVisualConfig::GetDataByRarity
02ce09ec: cbz     x20, #0x2ce0b5c                            
02ce09f0: mov     x21, x20                                   
02ce09f4: mov     x1, x0                                     
02ce09f8: str     x0, [x21, #0x10]!                          
02ce09fc: mov     x0, x21                                    
02ce0a00: bl      #0x2b70d54                                 fn_2b70d54
02ce0a04: ldr     x8, [x21]                                  
02ce0a08: cbz     x8, #0x2ce0a80                             
02ce0a0c: ldr     x0, [x19, #0x60]                           ._imgCircleGlow
02ce0a10: cbz     x0, #0x2ce0b5c                             
02ce0a14: ldr     x1, [x8, #0x18]                            
02ce0a18: mov     x2, xzr                                    
02ce0a1c: bl      #0x5c45aa0                                 UnityEngine.UI.Image::set_sprite
02ce0a20: ldr     x0, [x19, #0x70]                           ._imgRarityPanel
02ce0a24: cbz     x0, #0x2ce0b5c                             
02ce0a28: adrp    x22, #0x6267000                            
02ce0a2c: adrp    x23, #0x6267000                            
02ce0a30: mov     x2, xzr                                    
02ce0a34: ldr     x22, [x22, #0xef0]                         T:type53136(k15)
02ce0a38: ldr     x23, [x23, #0xf30]                         M:GiftBoxLuckyWheel/<>c__DisplayClass25_0::<SetRewardCoin>b__0
02ce0a3c: ldr     x1, [x19, #0x80]                           ._coinSprite
02ce0a40: bl      #0x5c45aa0                                 UnityEngine.UI.Image::set_sprite
02ce0a44: ldr     x0, [x22]                                  S:'didu'
02ce0a48: ldr     x21, [x19, #0x68]                          ._imgStars
02ce0a4c: bl      #0x2b7104c                                 fn_2b7104c
02ce0a50: ldr     x2, [x23]                                  S:'didu'
02ce0a54: mov     x1, x20                                    
02ce0a58: mov     x3, xzr                                    
02ce0a5c: mov     x22, x0                                    
02ce0a60: bl      #0x453418c                                 fn_453418c
02ce0a64: cbz     x21, #0x2ce0b5c                            
02ce0a68: adrp    x8, #0x6267000                             
02ce0a6c: mov     x0, x21                                    
02ce0a70: mov     x1, x22                                    
02ce0a74: ldr     x8, [x8, #0xef8]                           MS:System.Collections.Generic.List`1::ForEach
02ce0a78: ldr     x2, [x8]                                   S:'didu'
02ce0a7c: bl      #0x35a9ce4                                 fn_35a9ce4
02ce0a80: ldr     x0, [x19, #0x70]                           ._imgRarityPanel
02ce0a84: cbz     x0, #0x2ce0b5c                             
02ce0a88: mov     x1, xzr                                    
02ce0a8c: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02ce0a90: adrp    x21, #0x662f000                            
02ce0a94: mov     x20, x0                                    
02ce0a98: ldrb    w8, [x21, #0x91a]                          
02ce0a9c: cbnz    w8, #0x2ce0ab4                             
02ce0aa0: adrp    x0, #0x6264000                             
02ce0aa4: ldr     x0, [x0, #0xd8]                            T:UnityEngine.Vector3
02ce0aa8: bl      #0x2b70db0                                 fn_2b70db0
02ce0aac: mov     w8, #1                                     
02ce0ab0: strb    w8, [x21, #0x91a]                          
02ce0ab4: cbz     x20, #0x2ce0b5c                            
02ce0ab8: adrp    x22, #0x6264000                            
02ce0abc: mov     x0, x20                                    
02ce0ac0: mov     x1, xzr                                    
02ce0ac4: ldr     x22, [x22, #0xd8]                          T:UnityEngine.Vector3
02ce0ac8: ldr     x8, [x22]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02ce0acc: ldr     x8, [x8, #0xb8]                            M:Framework.SceneUtils/<CRUnloadSceneAsync>d__2::System.Collections.IEnumerator.Reset
02ce0ad0: ldp     s1, s2, [x8, #4]                           
02ce0ad4: ldr     s0, [x8]                                   S:'didu'
02ce0ad8: bl      #0x5b470cc                                 UnityEngine.Transform::set_localScale
02ce0adc: ldr     x0, [x19, #0x70]                           ._imgRarityPanel
02ce0ae0: cbz     x0, #0x2ce0b5c                             
02ce0ae4: mov     x1, xzr                                    
02ce0ae8: bl      #0x5c4e1ac                                 UnityEngine.UI.Graphic::get_rectTransform
02ce0aec: movi    d1, #0000000000000000                      
02ce0af0: fmov    s0, #20.00000000                           
02ce0af4: mov     w1, wzr                                    
02ce0af8: mov     x2, xzr                                    
02ce0afc: bl      #0x2c79c1c                                 DG.Tweening.DOTweenModuleUI::DOAnchorPosY
02ce0b00: ldr     x0, [x19, #0x90]                           ._tfStarHolder
02ce0b04: cbz     x0, #0x2ce0b5c                             
02ce0b08: mov     x1, xzr                                    
02ce0b0c: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02ce0b10: ldrb    w8, [x21, #0x91a]                          
02ce0b14: mov     x19, x0                                    
02ce0b18: cbnz    w8, #0x2ce0b30                             
02ce0b1c: adrp    x0, #0x6264000                             
02ce0b20: ldr     x0, [x0, #0xd8]                            T:UnityEngine.Vector3
02ce0b24: bl      #0x2b70db0                                 fn_2b70db0
02ce0b28: mov     w8, #1                                     
02ce0b2c: strb    w8, [x21, #0x91a]                          
02ce0b30: cbz     x19, #0x2ce0b5c                            
02ce0b34: ldr     x8, [x22]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02ce0b38: mov     x0, x19                                    
02ce0b3c: mov     x1, xzr                                    
02ce0b40: ldp     x20, x19, [sp, #0x20]                      
02ce0b44: ldr     x8, [x8, #0xb8]                            M:Framework.SceneUtils/<CRUnloadSceneAsync>d__2::System.Collections.IEnumerator.Reset
02ce0b48: ldp     x22, x21, [sp, #0x10]                      
02ce0b4c: ldp     s0, s1, [x8]                               
02ce0b50: ldr     s2, [x8, #8]                               S:'android.settings.WIFI_SETTINGS'
02ce0b54: ldp     x30, x23, [sp], #0x30                      
02ce0b58: b       #0x5b470cc                                 UnityEngine.Transform::set_localScale
02ce0b5c: bl      #0x2b7105c                                 fn_2b7105c
## SetOnclickEvent(System.Action onCloseClick) -> void
---- GiftBoxLuckyWheel::SetOnclickEvent 0x2ce0b68
02ce0b68: str     x30, [sp, #-0x30]!                         
02ce0b6c: stp     x22, x21, [sp, #0x10]                      
02ce0b70: stp     x20, x19, [sp, #0x20]                      
02ce0b74: adrp    x20, #0x662f000                            
02ce0b78: adrp    x22, #0x6267000                            
02ce0b7c: mov     x21, x1                                    
02ce0b80: ldrb    w8, [x20, #0xdac]                          
02ce0b84: ldr     x22, [x22, #0xf38]                         T:GiftBoxLuckyWheel/<>c__DisplayClass26_0
02ce0b88: mov     x19, x0                                    
02ce0b8c: tbnz    w8, #0, #0x2ce0bbc                         
02ce0b90: adrp    x0, #0x6267000                             
02ce0b94: ldr     x0, [x0, #0xf40]                           M:GiftBoxLuckyWheel/<>c__DisplayClass26_0::<SetOnclickEvent>b__0
02ce0b98: bl      #0x2b70db0                                 fn_2b70db0
02ce0b9c: adrp    x0, #0x6267000                             
02ce0ba0: ldr     x0, [x0, #0xf38]                           T:GiftBoxLuckyWheel/<>c__DisplayClass26_0
02ce0ba4: bl      #0x2b70db0                                 fn_2b70db0
02ce0ba8: adrp    x0, #0x6265000                             
02ce0bac: ldr     x0, [x0, #0x3f0]                           T:UnityEngine.Events.UnityAction
02ce0bb0: bl      #0x2b70db0                                 fn_2b70db0
02ce0bb4: mov     w8, #1                                     
02ce0bb8: strb    w8, [x20, #0xdac]                          
02ce0bbc: ldr     x0, [x22]                                  S:'didu'
02ce0bc0: bl      #0x2b7104c                                 fn_2b7104c
02ce0bc4: mov     x1, xzr                                    
02ce0bc8: mov     x20, x0                                    
02ce0bcc: bl      #0x4e53e9c                                 System.Object::.ctor
02ce0bd0: cbz     x20, #0x2ce0c64                            
02ce0bd4: mov     x0, x20                                    
02ce0bd8: mov     x1, x21                                    
02ce0bdc: str     x21, [x0, #0x10]!                          
02ce0be0: bl      #0x2b70d54                                 fn_2b70d54
02ce0be4: mov     x0, x20                                    
02ce0be8: mov     x1, x19                                    
02ce0bec: str     x19, [x0, #0x18]!                          
02ce0bf0: bl      #0x2b70d54                                 fn_2b70d54
02ce0bf4: ldr     x8, [x19, #0xb0]                           ._btnCloseGiftBox
02ce0bf8: cbz     x8, #0x2ce0c64                             
02ce0bfc: ldr     x0, [x8, #0x100]                           
02ce0c00: cbz     x0, #0x2ce0c64                             
02ce0c04: mov     x1, xzr                                    
02ce0c08: bl      #0x5b4ce48                                 UnityEngine.Events.UnityEventBase::RemoveAllListeners
02ce0c0c: ldr     x8, [x19, #0xb0]                           ._btnCloseGiftBox
02ce0c10: cbz     x8, #0x2ce0c64                             
02ce0c14: adrp    x9, #0x6265000                             
02ce0c18: adrp    x21, #0x6267000                            
02ce0c1c: ldr     x9, [x9, #0x3f0]                           T:UnityEngine.Events.UnityAction
02ce0c20: ldr     x21, [x21, #0xf40]                         M:GiftBoxLuckyWheel/<>c__DisplayClass26_0::<SetOnclickEvent>b__0
02ce0c24: ldr     x19, [x8, #0x100]                          
02ce0c28: ldr     x0, [x9]                                   M:AdsManager::<OnApplicationPause>b__26_0
02ce0c2c: bl      #0x2b7104c                                 fn_2b7104c
02ce0c30: ldr     x2, [x21]                                  S:'didu'
02ce0c34: mov     x1, x20                                    
02ce0c38: mov     x3, xzr                                    
02ce0c3c: mov     x21, x0                                    
02ce0c40: bl      #0x5b4cf98                                 UnityEngine.Events.UnityAction::.ctor
02ce0c44: cbz     x19, #0x2ce0c64                            
02ce0c48: mov     x0, x19                                    
02ce0c4c: mov     x1, x21                                    
02ce0c50: mov     x2, xzr                                    
02ce0c54: ldp     x20, x19, [sp, #0x20]                      
02ce0c58: ldp     x22, x21, [sp, #0x10]                      
02ce0c5c: ldr     x30, [sp], #0x30                           
02ce0c60: b       #0x5b4d0ac                                 UnityEngine.Events.UnityEvent::AddListener
02ce0c64: bl      #0x2b7105c                                 fn_2b7105c
## AnimUnbox() -> void
---- GiftBoxLuckyWheel::AnimUnbox 0x2ce0c70
02ce0c70: str     d8, [sp, #-0x50]!                          
02ce0c74: str     x30, [sp, #8]                              
02ce0c78: stp     x26, x25, [sp, #0x10]                      
02ce0c7c: stp     x24, x23, [sp, #0x20]                      
02ce0c80: stp     x22, x21, [sp, #0x30]                      
02ce0c84: stp     x20, x19, [sp, #0x40]                      
02ce0c88: adrp    x20, #0x662f000                            
02ce0c8c: adrp    x21, #0x6265000                            
02ce0c90: mov     x19, x0                                    
02ce0c94: ldrb    w8, [x20, #0xdad]                          
02ce0c98: ldr     x21, [x21, #0x310]                         MS:WejoyService.Singleton`1::get_Instance
02ce0c9c: tbnz    w8, #0, #0x2ce0d2c                         
02ce0ca0: adrp    x0, #0x6263000                             
02ce0ca4: ldr     x0, [x0, #0xfd0]                           T:DG.Tweening.DOTween
02ce0ca8: bl      #0x2b70db0                                 fn_2b70db0
02ce0cac: adrp    x0, #0x6267000                             
02ce0cb0: ldr     x0, [x0, #0xf48]                           M:GiftBoxLuckyWheel::<AnimUnbox>b__27_1
02ce0cb4: bl      #0x2b70db0                                 fn_2b70db0
02ce0cb8: adrp    x0, #0x6267000                             
02ce0cbc: ldr     x0, [x0, #0xf50]                           M:GiftBoxLuckyWheel::<AnimUnbox>b__27_3
02ce0cc0: bl      #0x2b70db0                                 fn_2b70db0
02ce0cc4: adrp    x0, #0x6265000                             
02ce0cc8: ldr     x0, [x0, #0x310]                           MS:WejoyService.Singleton`1::get_Instance
02ce0ccc: bl      #0x2b70db0                                 fn_2b70db0
02ce0cd0: adrp    x0, #0x6264000                             
02ce0cd4: ldr     x0, [x0, #0xe8]                            T:DG.Tweening.TweenCallback
02ce0cd8: bl      #0x2b70db0                                 fn_2b70db0
02ce0cdc: adrp    x0, #0x6266000                             
02ce0ce0: ldr     x0, [x0, #0xa10]                           MS:DG.Tweening.TweenSettingsExtensions::SetDelay
02ce0ce4: bl      #0x2b70db0                                 fn_2b70db0
02ce0ce8: adrp    x0, #0x6266000                             
02ce0cec: ldr     x0, [x0, #0xa18]                           MS:DG.Tweening.TweenSettingsExtensions::SetEase
02ce0cf0: bl      #0x2b70db0                                 fn_2b70db0
02ce0cf4: adrp    x0, #0x6266000                             
02ce0cf8: ldr     x0, [x0, #0x880]                           MS:DG.Tweening.TweenSettingsExtensions::SetEase
02ce0cfc: bl      #0x2b70db0                                 fn_2b70db0
02ce0d00: adrp    x0, #0x6267000                             
02ce0d04: ldr     x0, [x0, #0xf58]                           M:GiftBoxLuckyWheel/<>c::<AnimUnbox>b__27_0
02ce0d08: bl      #0x2b70db0                                 fn_2b70db0
02ce0d0c: adrp    x0, #0x6267000                             
02ce0d10: ldr     x0, [x0, #0xf60]                           M:GiftBoxLuckyWheel/<>c::<AnimUnbox>b__27_2
02ce0d14: bl      #0x2b70db0                                 fn_2b70db0
02ce0d18: adrp    x0, #0x6267000                             
02ce0d1c: ldr     x0, [x0, #0xf68]                           T:GiftBoxLuckyWheel/<>c
02ce0d20: bl      #0x2b70db0                                 fn_2b70db0
02ce0d24: mov     w8, #1                                     
02ce0d28: strb    w8, [x20, #0xdad]                          
02ce0d2c: ldr     x0, [x21]                                  M:AdsManager::<OnApplicationPause>b__26_0
02ce0d30: bl      #0x3be7218                                 fn_3be7218
02ce0d34: cbz     x0, #0x2ce1244                             
02ce0d38: mov     x1, xzr                                    
02ce0d3c: bl      #0x2c8a7a4                                 AdsManager::ShowCollap
02ce0d40: ldr     x0, [x19, #0xa0]                           ._tfFullContent
02ce0d44: cbz     x0, #0x2ce1244                             
02ce0d48: mov     x1, xzr                                    
02ce0d4c: bl      #0x5b339ec                                 UnityEngine.Component::get_gameObject
02ce0d50: cbz     x0, #0x2ce1244                             
02ce0d54: adrp    x20, #0x6263000                            
02ce0d58: mov     w1, #1                                     
02ce0d5c: mov     x2, xzr                                    
02ce0d60: ldr     x20, [x20, #0xfd0]                         T:DG.Tweening.DOTween
02ce0d64: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02ce0d68: ldr     x0, [x20]                                  &2c5bbd4(=a9bd7bfdd503233f)
02ce0d6c: ldr     w8, [x0, #0xe4]                            [62670e4]=0 f=0,0
02ce0d70: cbnz    w8, #0x2ce0d78                             
02ce0d74: bl      #0x2b70f30                                 fn_2b70f30
02ce0d78: mov     x0, xzr                                    
02ce0d7c: bl      #0x2d8cfe8                                 DG.Tweening.DOTween::Sequence
02ce0d80: mov     x20, x19                                   
02ce0d84: mov     x1, x0                                     
02ce0d88: str     x0, [x20, #0xc0]!                          ._animSequence
02ce0d8c: mov     x0, x20                                    
02ce0d90: bl      #0x2b70d54                                 fn_2b70d54
02ce0d94: ldur    x0, [x20, #-0x10]                          
02ce0d98: cbz     x0, #0x2ce1244                             
02ce0d9c: mov     x1, xzr                                    
02ce0da0: bl      #0x5b339ec                                 UnityEngine.Component::get_gameObject
02ce0da4: cbz     x0, #0x2ce1244                             
02ce0da8: adrp    x22, #0x6266000                            
02ce0dac: adrp    x24, #0x6266000                            
02ce0db0: mov     w1, wzr                                    
02ce0db4: ldr     x22, [x22, #0xa18]                         MS:DG.Tweening.TweenSettingsExtensions::SetEase
02ce0db8: ldr     x24, [x24, #0x880]                         MS:DG.Tweening.TweenSettingsExtensions::SetEase
02ce0dbc: mov     x2, xzr                                    
02ce0dc0: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02ce0dc4: mov     w8, #-0x3cfe0000                           
02ce0dc8: fmov    s1, #0.50000000                            
02ce0dcc: ldr     x0, [x19, #0x88]                           ._rtGiftBox
02ce0dd0: fmov    s0, w8                                     
02ce0dd4: ldr     x21, [x19, #0xc0]                          ._animSequence
02ce0dd8: mov     w1, wzr                                    
02ce0ddc: mov     x2, xzr                                    
02ce0de0: bl      #0x2c79c1c                                 DG.Tweening.DOTweenModuleUI::DOAnchorPosY
02ce0de4: ldr     x2, [x22]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ce0de8: mov     w1, #5                                     
02ce0dec: bl      #0x336fa0c                                 fn_336fa0c
02ce0df0: mov     x1, x0                                     
02ce0df4: mov     x0, x21                                    
02ce0df8: mov     x2, xzr                                    
02ce0dfc: bl      #0x2d9b0a8                                 DG.Tweening.TweenSettingsExtensions::Append
02ce0e00: fmov    s0, #1.00000000                            
02ce0e04: fmov    s1, #0.50000000                            
02ce0e08: ldr     x0, [x19, #0x88]                           ._rtGiftBox
02ce0e0c: ldr     x21, [x19, #0xc0]                          ._animSequence
02ce0e10: mov     x1, xzr                                    
02ce0e14: bl      #0x2d98c98                                 DG.Tweening.ShortcutExtensions::DOScale
02ce0e18: ldr     x2, [x24]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ce0e1c: mov     w1, #0x1c                                  
02ce0e20: bl      #0x336fa0c                                 fn_336fa0c
02ce0e24: mov     x1, x0                                     
02ce0e28: mov     x0, x21                                    
02ce0e2c: mov     x2, xzr                                    
02ce0e30: bl      #0x2d9b0a8                                 DG.Tweening.TweenSettingsExtensions::Append
02ce0e34: adrp    x8, #0x1084000                             
02ce0e38: fmov    s1, #0.50000000                            
02ce0e3c: ldr     x0, [x19, #0x78]                           ._bgBlack
02ce0e40: ldr     s0, [x8, #0xf34]                           [1084f34]=40490fdb3f6b851f f=0.92,3.14159
02ce0e44: ldr     x21, [x19, #0xc0]                          ._animSequence
02ce0e48: mov     x1, xzr                                    
02ce0e4c: bl      #0x2c789b8                                 DG.Tweening.DOTweenModuleUI::DOFade
02ce0e50: mov     x1, x0                                     
02ce0e54: mov     x0, x21                                    
02ce0e58: mov     x2, xzr                                    
02ce0e5c: bl      #0x2d9b0ec                                 DG.Tweening.TweenSettingsExtensions::Join
02ce0e60: ldr     x0, [x19, #0x70]                           ._imgRarityPanel
02ce0e64: cbz     x0, #0x2ce1244                             
02ce0e68: adrp    x26, #0x6267000                            
02ce0e6c: mov     x1, xzr                                    
02ce0e70: ldr     x26, [x26, #0xf68]                         T:GiftBoxLuckyWheel/<>c
02ce0e74: ldr     x21, [x19, #0xc0]                          ._animSequence
02ce0e78: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02ce0e7c: movi    d1, #0000000000000000                      
02ce0e80: adrp    x8, #0x1084000                             
02ce0e84: mov     x1, xzr                                    
02ce0e88: ldr     s0, [x8, #0xe00]                           [1084e00]=3c23d70a3f266666 f=0.65,0.01
02ce0e8c: bl      #0x2d98c98                                 DG.Tweening.ShortcutExtensions::DOScale
02ce0e90: mov     x1, x0                                     
02ce0e94: mov     x0, x21                                    
02ce0e98: mov     x2, xzr                                    
02ce0e9c: bl      #0x2d9b0ec                                 DG.Tweening.TweenSettingsExtensions::Join
02ce0ea0: adrp    x9, #0x1084000                             
02ce0ea4: adrp    x8, #0x1084000                             
02ce0ea8: ldr     x0, [x19, #0x88]                           ._rtGiftBox
02ce0eac: ldr     s8, [x9, #0xdd8]                           [1084dd8]=3f7333333e4ccccd f=0.2,0.95
02ce0eb0: ldr     s0, [x8, #0xbd4]                           [1084bd4]=440980003f666666 f=0.9,550
02ce0eb4: ldr     x21, [x19, #0xc0]                          ._animSequence
02ce0eb8: mov     x1, xzr                                    
02ce0ebc: fmov    s1, s8                                     
02ce0ec0: bl      #0x2d98fd4                                 DG.Tweening.ShortcutExtensions::DOScaleY
02ce0ec4: mov     x1, x0                                     
02ce0ec8: mov     x0, x21                                    
02ce0ecc: mov     x2, xzr                                    
02ce0ed0: bl      #0x2d9b0a8                                 DG.Tweening.TweenSettingsExtensions::Append
02ce0ed4: ldr     x0, [x26]                                  S:'didu'
02ce0ed8: ldr     x21, [x19, #0xc0]                          ._animSequence
02ce0edc: ldr     w8, [x0, #0xe4]                            [62670e4]=0 f=0,0
02ce0ee0: cbnz    w8, #0x2ce0eec                             
02ce0ee4: bl      #0x2b70f30                                 fn_2b70f30
02ce0ee8: ldr     x0, [x26]                                  S:'didu'
02ce0eec: ldr     x8, [x0, #0xb8]                            M:Framework.SceneUtils/<CRUnloadSceneAsync>d__2::System.Collections.IEnumerator.Reset ._coin
02ce0ef0: adrp    x25, #0x6264000                            
02ce0ef4: ldr     x22, [x8, #8]                              [1084008]=457974696e550029 f=1.64801e+28,3991.28
02ce0ef8: ldr     x25, [x25, #0xe8]                          T:DG.Tweening.TweenCallback
02ce0efc: cbnz    x22, #0x2ce0f50                            
02ce0f00: ldr     w9, [x0, #0xe4]                            [62670e4]=0 f=0,0
02ce0f04: cbnz    w9, #0x2ce0f14                             
02ce0f08: bl      #0x2b70f30                                 fn_2b70f30
02ce0f0c: ldr     x8, [x26]                                  S:'didu'
02ce0f10: ldr     x8, [x8, #0xb8]                            [10840b8]=2632726f74636556 f=7.20646e+31,6.19112e-16
02ce0f14: ldr     x0, [x25]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02ce0f18: ldr     x23, [x8]                                  [1084000]=287475706e49646c f=1.5582e+28,1.35702e-14
02ce0f1c: bl      #0x2b7104c                                 fn_2b7104c
02ce0f20: adrp    x8, #0x6267000                             
02ce0f24: mov     x1, x23                                    
02ce0f28: mov     x3, xzr                                    
02ce0f2c: ldr     x8, [x8, #0xf58]                           M:GiftBoxLuckyWheel/<>c::<AnimUnbox>b__27_0
02ce0f30: mov     x22, x0                                    
02ce0f34: ldr     x2, [x8]                                   S:'didu'
02ce0f38: bl      #0x2d89dc4                                 DG.Tweening.TweenCallback::.ctor
02ce0f3c: ldr     x8, [x26]                                  S:'didu'
02ce0f40: mov     x1, x22                                    
02ce0f44: ldr     x0, [x8, #0xb8]                            M:Framework.SceneUtils/<CRUnloadSceneAsync>d__2::System.Collections.IEnumerator.Reset
02ce0f48: str     x22, [x0, #8]!                             
02ce0f4c: bl      #0x2b70d54                                 fn_2b70d54
02ce0f50: mov     x0, x21                                    
02ce0f54: mov     x1, x22                                    
02ce0f58: mov     x2, xzr                                    
02ce0f5c: bl      #0x2da03d8                                 DG.Tweening.TweenSettingsExtensions::AppendCallback
02ce0f60: fmov    s1, s8                                     
02ce0f64: fmov    s0, #1.00000000                            
02ce0f68: ldr     x0, [x19, #0x88]                           ._rtGiftBox
02ce0f6c: ldr     x21, [x19, #0xc0]                          ._animSequence
02ce0f70: mov     x1, xzr                                    
02ce0f74: bl      #0x2d98fd4                                 DG.Tweening.ShortcutExtensions::DOScaleY
02ce0f78: ldr     x2, [x24]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ce0f7c: mov     w1, #0x1b                                  
02ce0f80: bl      #0x336fa0c                                 fn_336fa0c
02ce0f84: mov     x1, x0                                     
02ce0f88: mov     x0, x21                                    
02ce0f8c: mov     x2, xzr                                    
02ce0f90: bl      #0x2d9b0a8                                 DG.Tweening.TweenSettingsExtensions::Append
02ce0f94: fmov    s1, s8                                     
02ce0f98: fmov    s0, #1.00000000                            
02ce0f9c: ldr     x0, [x19, #0x40]                           ._imgFlash
02ce0fa0: ldr     x21, [x19, #0xc0]                          ._animSequence
02ce0fa4: mov     x1, xzr                                    
02ce0fa8: bl      #0x2c789b8                                 DG.Tweening.DOTweenModuleUI::DOFade
02ce0fac: mov     x1, x0                                     
02ce0fb0: mov     x0, x21                                    
02ce0fb4: mov     x2, xzr                                    
02ce0fb8: bl      #0x2d9b0ec                                 DG.Tweening.TweenSettingsExtensions::Join
02ce0fbc: ldr     x0, [x19, #0x20]                           ._imgLid
02ce0fc0: cbz     x0, #0x2ce1244                             
02ce0fc4: ldr     x21, [x19, #0xc0]                          ._animSequence
02ce0fc8: mov     x1, xzr                                    
02ce0fcc: bl      #0x5c4e1ac                                 UnityEngine.UI.Graphic::get_rectTransform
02ce0fd0: fmov    s1, s8                                     
02ce0fd4: adrp    x8, #0x1084000                             
02ce0fd8: mov     w1, wzr                                    
02ce0fdc: ldr     s0, [x8, #0xbd8]                           [1084bd8]=c419c00044098000 f=550,-615
02ce0fe0: mov     x2, xzr                                    
02ce0fe4: bl      #0x2c79c1c                                 DG.Tweening.DOTweenModuleUI::DOAnchorPosY
02ce0fe8: mov     x1, x0                                     
02ce0fec: mov     x0, x21                                    
02ce0ff0: mov     x2, xzr                                    
02ce0ff4: bl      #0x2d9b0ec                                 DG.Tweening.TweenSettingsExtensions::Join
02ce0ff8: ldr     x0, [x19, #0x70]                           ._imgRarityPanel
02ce0ffc: cbz     x0, #0x2ce1244                             
02ce1000: adrp    x22, #0x6267000                            
02ce1004: mov     x1, xzr                                    
02ce1008: ldr     x22, [x22, #0xf48]                         M:GiftBoxLuckyWheel::<AnimUnbox>b__27_1
02ce100c: ldr     x21, [x19, #0xc0]                          ._animSequence
02ce1010: bl      #0x5c4e1ac                                 UnityEngine.UI.Graphic::get_rectTransform
02ce1014: mov     w8, #0x43160000                            
02ce1018: fmov    s1, s8                                     
02ce101c: mov     w1, wzr                                    
02ce1020: fmov    s0, w8                                     
02ce1024: mov     x2, xzr                                    
02ce1028: bl      #0x2c79c1c                                 DG.Tweening.DOTweenModuleUI::DOAnchorPosY
02ce102c: mov     x1, x0                                     
02ce1030: mov     x0, x21                                    
02ce1034: mov     x2, xzr                                    
02ce1038: bl      #0x2d9b0ec                                 DG.Tweening.TweenSettingsExtensions::Join
02ce103c: ldr     x0, [x25]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02ce1040: ldr     x21, [x19, #0xc0]                          ._animSequence
02ce1044: bl      #0x2b7104c                                 fn_2b7104c
02ce1048: ldr     x2, [x22]                                  S:'didu'
02ce104c: mov     x1, x19                                    
02ce1050: mov     x3, xzr                                    
02ce1054: mov     x22, x0                                    
02ce1058: bl      #0x2d89dc4                                 DG.Tweening.TweenCallback::.ctor
02ce105c: mov     x0, x21                                    
02ce1060: mov     x1, x22                                    
02ce1064: mov     x2, xzr                                    
02ce1068: bl      #0x2da03d8                                 DG.Tweening.TweenSettingsExtensions::AppendCallback
02ce106c: ldr     x0, [x19, #0x70]                           ._imgRarityPanel
02ce1070: cbz     x0, #0x2ce1244                             
02ce1074: adrp    x22, #0x6266000                            
02ce1078: mov     x1, xzr                                    
02ce107c: ldr     x22, [x22, #0xa10]                         MS:DG.Tweening.TweenSettingsExtensions::SetDelay
02ce1080: ldr     x21, [x19, #0xc0]                          ._animSequence
02ce1084: bl      #0x5c4e1ac                                 UnityEngine.UI.Graphic::get_rectTransform
02ce1088: adrp    x8, #0x1084000                             
02ce108c: fmov    s1, #0.50000000                            
02ce1090: mov     w1, wzr                                    
02ce1094: ldr     s0, [x8, #0xb94]                           [1084b94]=40c90fdb43cf8000 f=415,6.28319
02ce1098: mov     x2, xzr                                    
02ce109c: bl      #0x2c79c1c                                 DG.Tweening.DOTweenModuleUI::DOAnchorPosY
02ce10a0: fmov    s0, #0.50000000                            
02ce10a4: ldr     x1, [x22]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ce10a8: bl      #0x336f7fc                                 fn_336f7fc
02ce10ac: mov     x1, x0                                     
02ce10b0: mov     x0, x21                                    
02ce10b4: mov     x2, xzr                                    
02ce10b8: bl      #0x2d9b0a8                                 DG.Tweening.TweenSettingsExtensions::Append
02ce10bc: ldr     x0, [x19, #0x70]                           ._imgRarityPanel
02ce10c0: cbz     x0, #0x2ce1244                             
02ce10c4: ldr     x21, [x20]                                 &2c5bbd4(=a9bd7bfdd503233f)
02ce10c8: mov     x1, xzr                                    
02ce10cc: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02ce10d0: fmov    s0, #1.00000000                            
02ce10d4: fmov    s1, #0.50000000                            
02ce10d8: mov     x1, xzr                                    
02ce10dc: bl      #0x2d98c98                                 DG.Tweening.ShortcutExtensions::DOScale
02ce10e0: mov     x1, x0                                     
02ce10e4: mov     x0, x21                                    
02ce10e8: mov     x2, xzr                                    
02ce10ec: bl      #0x2d9b0ec                                 DG.Tweening.TweenSettingsExtensions::Join
02ce10f0: ldr     x0, [x26]                                  S:'didu'
02ce10f4: ldr     x20, [x20]                                 &2c5bbd4(=a9bd7bfdd503233f)
02ce10f8: ldr     w8, [x0, #0xe4]                            [62670e4]=0 f=0,0
02ce10fc: cbnz    w8, #0x2ce1108                             
02ce1100: bl      #0x2b70f30                                 fn_2b70f30
02ce1104: ldr     x0, [x26]                                  S:'didu'
02ce1108: ldr     x8, [x0, #0xb8]                            M:Framework.SceneUtils/<CRUnloadSceneAsync>d__2::System.Collections.IEnumerator.Reset ._coin
02ce110c: ldr     x21, [x8, #0x10]                           [1084010]=55472e656e69676e f=1.80588e+28,1.36876e+13
02ce1110: cbnz    x21, #0x2ce1164                            
02ce1114: ldr     w9, [x0, #0xe4]                            [62670e4]=0 f=0,0
02ce1118: cbnz    w9, #0x2ce1128                             
02ce111c: bl      #0x2b70f30                                 fn_2b70f30
02ce1120: ldr     x8, [x26]                                  S:'didu'
02ce1124: ldr     x8, [x8, #0xb8]                            [10840b8]=2632726f74636556 f=7.20646e+31,6.19112e-16
02ce1128: ldr     x0, [x25]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02ce112c: ldr     x22, [x8]                                  [1084000]=287475706e49646c f=1.5582e+28,1.35702e-14
02ce1130: bl      #0x2b7104c                                 fn_2b7104c
02ce1134: adrp    x8, #0x6267000                             
02ce1138: mov     x1, x22                                    
02ce113c: mov     x3, xzr                                    
02ce1140: ldr     x8, [x8, #0xf60]                           M:GiftBoxLuckyWheel/<>c::<AnimUnbox>b__27_2
02ce1144: mov     x21, x0                                    
02ce1148: ldr     x2, [x8]                                   S:'didu'
02ce114c: bl      #0x2d89dc4                                 DG.Tweening.TweenCallback::.ctor
02ce1150: ldr     x8, [x26]                                  S:'didu'
02ce1154: mov     x1, x21                                    
02ce1158: ldr     x0, [x8, #0xb8]                            M:Framework.SceneUtils/<CRUnloadSceneAsync>d__2::System.Collections.IEnumerator.Reset
02ce115c: str     x21, [x0, #0x10]!                          
02ce1160: bl      #0x2b70d54                                 fn_2b70d54
02ce1164: mov     x0, x20                                    
02ce1168: mov     x1, x21                                    
02ce116c: mov     x2, xzr                                    
02ce1170: bl      #0x2da03d8                                 DG.Tweening.TweenSettingsExtensions::AppendCallback
02ce1174: ldr     x0, [x19, #0x98]                           ._tfGlow
02ce1178: cbz     x0, #0x2ce1244                             
02ce117c: ldr     x20, [x19, #0xc0]                          ._animSequence
02ce1180: mov     x1, xzr                                    
02ce1184: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02ce1188: fmov    s0, #1.00000000                            
02ce118c: fmov    s1, #0.50000000                            
02ce1190: mov     x1, xzr                                    
02ce1194: bl      #0x2d98c98                                 DG.Tweening.ShortcutExtensions::DOScale
02ce1198: ldr     x2, [x24]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ce119c: mov     w1, #0x1b                                  
02ce11a0: bl      #0x336fa0c                                 fn_336fa0c
02ce11a4: mov     x1, x0                                     
02ce11a8: mov     x0, x20                                    
02ce11ac: mov     x2, xzr                                    
02ce11b0: bl      #0x2d9b0a8                                 DG.Tweening.TweenSettingsExtensions::Append
02ce11b4: ldr     x0, [x19, #0x90]                           ._tfStarHolder
02ce11b8: cbz     x0, #0x2ce1244                             
02ce11bc: adrp    x21, #0x6267000                            
02ce11c0: mov     x1, xzr                                    
02ce11c4: ldr     x21, [x21, #0xf50]                         M:GiftBoxLuckyWheel::<AnimUnbox>b__27_3
02ce11c8: ldr     x20, [x19, #0xc0]                          ._animSequence
02ce11cc: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02ce11d0: fmov    s0, #1.00000000                            
02ce11d4: fmov    s1, #0.50000000                            
02ce11d8: mov     x1, xzr                                    
02ce11dc: bl      #0x2d98c98                                 DG.Tweening.ShortcutExtensions::DOScale
02ce11e0: ldr     x2, [x24]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ce11e4: mov     w1, #0x1b                                  
02ce11e8: bl      #0x336fa0c                                 fn_336fa0c
02ce11ec: mov     x1, x0                                     
02ce11f0: mov     x0, x20                                    
02ce11f4: mov     x2, xzr                                    
02ce11f8: bl      #0x2d9b0ec                                 DG.Tweening.TweenSettingsExtensions::Join
02ce11fc: ldr     x0, [x25]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02ce1200: ldr     x20, [x19, #0xc0]                          ._animSequence
02ce1204: bl      #0x2b7104c                                 fn_2b7104c
02ce1208: ldr     x2, [x21]                                  S:'didu'
02ce120c: mov     x1, x19                                    
02ce1210: mov     x3, xzr                                    
02ce1214: mov     x21, x0                                    
02ce1218: bl      #0x2d89dc4                                 DG.Tweening.TweenCallback::.ctor
02ce121c: mov     x0, x20                                    
02ce1220: mov     x1, x21                                    
02ce1224: ldr     x30, [sp, #8]                              
02ce1228: ldp     x20, x19, [sp, #0x40]                      
02ce122c: mov     x2, xzr                                    
02ce1230: ldp     x22, x21, [sp, #0x30]                      
02ce1234: ldp     x24, x23, [sp, #0x20]                      
02ce1238: ldp     x26, x25, [sp, #0x10]                      
02ce123c: ldr     d8, [sp], #0x50                            
02ce1240: b       #0x2da03d8                                 DG.Tweening.TweenSettingsExtensions::AppendCallback
02ce1244: bl      #0x2b7105c                                 fn_2b7105c
## .ctor() -> void
---- GiftBoxLuckyWheel::.ctor 0x2ce1248
02ce1248: mov     x1, xzr                                    
02ce124c: b       #0x5b397b0                                 UnityEngine.MonoBehaviour::.ctor
## <AnimUnbox>b__27_1() -> void
---- GiftBoxLuckyWheel::<AnimUnbox>b__27_1 0x2ce1250
02ce1250: str     d8, [sp, #-0x30]!                          
02ce1254: stp     x30, x21, [sp, #0x10]                      
02ce1258: stp     x20, x19, [sp, #0x20]                      
02ce125c: adrp    x21, #0x662f000                            
02ce1260: adrp    x20, #0x6267000                            
02ce1264: mov     x19, x0                                    
02ce1268: ldrb    w8, [x21, #0xdae]                          
02ce126c: ldr     x20, [x20, #0xf70]                         MS:DG.Tweening.TweenSettingsExtensions::SetDelay
02ce1270: tbnz    w8, #0, #0x2ce1288                         
02ce1274: adrp    x0, #0x6267000                             
02ce1278: ldr     x0, [x0, #0xf70]                           MS:DG.Tweening.TweenSettingsExtensions::SetDelay
02ce127c: bl      #0x2b70db0                                 fn_2b70db0
02ce1280: mov     w8, #1                                     
02ce1284: strb    w8, [x21, #0xdae]                          
02ce1288: adrp    x8, #0x1084000                             
02ce128c: movi    d0, #0000000000000000                      
02ce1290: ldr     x0, [x19, #0x28]                           ._imgBody
02ce1294: ldr     s8, [x8, #0xf10]                           [1084f10]=4110bc863e99999a f=0.3,9.04603
02ce1298: mov     x1, xzr                                    
02ce129c: fmov    s1, s8                                     
02ce12a0: bl      #0x2c789b8                                 DG.Tweening.DOTweenModuleUI::DOFade
02ce12a4: fmov    s0, s8                                     
02ce12a8: ldr     x1, [x20]                                  S:'didu'
02ce12ac: bl      #0x336f7fc                                 fn_336f7fc
02ce12b0: movi    d0, #0000000000000000                      
02ce12b4: fmov    s1, s8                                     
02ce12b8: ldr     x0, [x19, #0x30]                           ._imgFront
02ce12bc: mov     x1, xzr                                    
02ce12c0: bl      #0x2c789b8                                 DG.Tweening.DOTweenModuleUI::DOFade
02ce12c4: fmov    s0, s8                                     
02ce12c8: ldr     x1, [x20]                                  S:'didu'
02ce12cc: bl      #0x336f7fc                                 fn_336f7fc
02ce12d0: movi    d0, #0000000000000000                      
02ce12d4: fmov    s1, s8                                     
02ce12d8: ldr     x0, [x19, #0x20]                           ._imgLid
02ce12dc: mov     x1, xzr                                    
02ce12e0: bl      #0x2c789b8                                 DG.Tweening.DOTweenModuleUI::DOFade
02ce12e4: fmov    s0, s8                                     
02ce12e8: ldr     x1, [x20]                                  S:'didu'
02ce12ec: bl      #0x336f7fc                                 fn_336f7fc
02ce12f0: movi    d0, #0000000000000000                      
02ce12f4: fmov    s1, s8                                     
02ce12f8: ldr     x0, [x19, #0x40]                           ._imgFlash
02ce12fc: mov     x1, xzr                                    
02ce1300: bl      #0x2c789b8                                 DG.Tweening.DOTweenModuleUI::DOFade
02ce1304: ldr     x1, [x20]                                  S:'didu'
02ce1308: ldp     x20, x19, [sp, #0x20]                      
02ce130c: ldp     x30, x21, [sp, #0x10]                      
02ce1310: fmov    s0, s8                                     
02ce1314: ldr     d8, [sp], #0x30                            
02ce1318: b       #0x336f7fc                                 
## <AnimUnbox>b__27_3() -> void
---- GiftBoxLuckyWheel::<AnimUnbox>b__27_3 0x2ce131c
02ce131c: str     x30, [sp, #-0x20]!                         
02ce1320: stp     x20, x19, [sp, #0x10]                      
02ce1324: adrp    x20, #0x662f000                            
02ce1328: mov     x19, x0                                    
02ce132c: ldrb    w8, [x20, #0xdaf]                          
02ce1330: tbnz    w8, #0, #0x2ce1348                         
02ce1334: adrp    x0, #0x6266000                             
02ce1338: ldr     x0, [x0, #0xaa0]                           MS:MonoSingleton`1::get_Instance
02ce133c: bl      #0x2b70db0                                 fn_2b70db0
02ce1340: mov     w8, #1                                     
02ce1344: strb    w8, [x20, #0xdaf]                          
02ce1348: ldr     w8, [x19, #0xb8]                           ._coin
02ce134c: cbz     w8, #0x2ce136c                             
02ce1350: adrp    x8, #0x6266000                             
02ce1354: ldr     x8, [x8, #0xaa0]                           MS:MonoSingleton`1::get_Instance
02ce1358: ldr     x0, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ce135c: bl      #0x3769600                                 fn_3769600
02ce1360: cbz     x0, #0x2ce1394                             
02ce1364: ldr     w1, [x19, #0xb8]                           ._coin
02ce1368: bl      #0x2cdac78                                 MoneyManager::UpdateMoney
02ce136c: ldr     x0, [x19, #0xb0]                           ._btnCloseGiftBox
02ce1370: cbz     x0, #0x2ce1394                             
02ce1374: mov     x1, xzr                                    
02ce1378: bl      #0x5b339ec                                 UnityEngine.Component::get_gameObject
02ce137c: cbz     x0, #0x2ce1394                             
02ce1380: ldp     x20, x19, [sp, #0x10]                      
02ce1384: mov     w1, #1                                     
02ce1388: mov     x2, xzr                                    
02ce138c: ldr     x30, [sp], #0x20                           
02ce1390: b       #0x5b36b38                                 UnityEngine.GameObject::SetActive
02ce1394: bl      #0x2b7105c                                 fn_2b7105c
