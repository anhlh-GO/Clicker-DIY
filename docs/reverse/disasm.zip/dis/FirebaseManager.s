#### CLASS FirebaseManager/<>c__DisplayClass6_0 parent= object
#   field success                        bool                                               off=0x10 attr=6 
#   field isDone                         bool                                               off=0x11 attr=6 
#   field <>4__this                      FirebaseManager                                    off=0x18 attr=6 
## .ctor() -> void
---- FirebaseManager/<>c__DisplayClass6_0::.ctor 0x2ca07d4
02ca07d4: mov     x1, xzr                                    
02ca07d8: b       #0x4e53e9c                                 System.Object::.ctor
## <InitializeFirebase>b__0(System.Threading.Tasks.Task`1<Firebase.DependencyStatus> task) -> void
---- FirebaseManager/<>c__DisplayClass6_0::<InitializeFirebase>b__0 0x2ca07dc
02ca07dc: sub     sp, sp, #0x40                              
02ca07e0: str     x30, [sp, #0x10]                           
02ca07e4: stp     x22, x21, [sp, #0x20]                      
02ca07e8: stp     x20, x19, [sp, #0x30]                      
02ca07ec: adrp    x21, #0x662f000                            
02ca07f0: mov     x20, x1                                    
02ca07f4: mov     x19, x0                                    
02ca07f8: ldrb    w8, [x21, #0xa8d]                          
02ca07fc: tbnz    w8, #0, #0x2ca0850                         
02ca0800: adrp    x0, #0x6265000                             
02ca0804: ldr     x0, [x0, #0xf48]                           T:Firebase.DependencyStatus
02ca0808: bl      #0x2b70db0                                 fn_2b70db0
02ca080c: adrp    x0, #0x6265000                             
02ca0810: ldr     x0, [x0, #0xf50]                           T:Firebase.FirebaseApp
02ca0814: bl      #0x2b70db0                                 fn_2b70db0
02ca0818: adrp    x0, #0x6265000                             
02ca081c: ldr     x0, [x0, #0xf58]                           MS:System.Threading.Tasks.Task`1::get_Result
02ca0820: bl      #0x2b70db0                                 fn_2b70db0
02ca0824: adrp    x0, #0x6265000                             
02ca0828: ldr     x0, [x0, #0xf60]                           S:'Firebase dependencies not available: {0} (try {1})'
02ca082c: bl      #0x2b70db0                                 fn_2b70db0
02ca0830: adrp    x0, #0x6265000                             
02ca0834: ldr     x0, [x0, #0xf68]                           S:'Firebase Dependency check failed (try {0}): {1}'
02ca0838: bl      #0x2b70db0                                 fn_2b70db0
02ca083c: adrp    x0, #0x6265000                             
02ca0840: ldr     x0, [x0, #0xf70]                           S:'Firebase is ready!'
02ca0844: bl      #0x2b70db0                                 fn_2b70db0
02ca0848: mov     w8, #1                                     
02ca084c: strb    w8, [x21, #0xa8d]                          
02ca0850: cbz     x20, #0x2ca09f4                            
02ca0854: mov     x0, x20                                    
02ca0858: mov     x1, xzr                                    
02ca085c: bl      #0x4e88c28                                 System.Threading.Tasks.Task::get_Exception
02ca0860: cbz     x0, #0x2ca08f4                             
02ca0864: ldr     x8, [x19, #0x18]                           .<>4__this
02ca0868: cbz     x8, #0x2ca09f4                             
02ca086c: adrp    x9, #0x6263000                             
02ca0870: ldr     w8, [x8, #0x30]                            
02ca0874: add     x1, sp, #0x1c                              
02ca0878: ldr     x9, [x9, #0x970]                           &6645c70(=0)
02ca087c: add     w8, w8, #1                                 
02ca0880: ldr     x0, [x9, #0x48]                            &6263098(=0)
02ca0884: str     w8, [sp, #0x1c]                            
02ca0888: bl      #0x2b70f38                                 fn_2b70f38
02ca088c: mov     x21, x0                                    
02ca0890: mov     x0, x20                                    
02ca0894: mov     x1, xzr                                    
02ca0898: bl      #0x4e88c28                                 System.Threading.Tasks.Task::get_Exception
02ca089c: cbz     x0, #0x2ca09f4                             
02ca08a0: adrp    x8, #0x6265000                             
02ca08a4: ldr     x8, [x8, #0xf68]                           S:'Firebase Dependency check failed (try {0}): {1}'
02ca08a8: ldr     x0, [x0, #0x28]                            T:AdsManager/<ISetAOAInterval>d__33
02ca08ac: ldr     x22, [x8]                                  M:AdsManager::<OnApplicationPause>b__26_0
02ca08b0: cbz     x0, #0x2ca08c8                             
02ca08b4: ldr     x8, [x0]                                   M:AdsManager::<OnApplicationPause>b__26_0
02ca08b8: ldp     x9, x1, [x8, #0x188]                       
02ca08bc: blr     x9                                         
02ca08c0: mov     x2, x0                                     
02ca08c4: cbnz    x0, #0x2ca08e8                             
02ca08c8: mov     x0, x20                                    
02ca08cc: mov     x1, xzr                                    
02ca08d0: bl      #0x4e88c28                                 System.Threading.Tasks.Task::get_Exception
02ca08d4: cbz     x0, #0x2ca09f4                             
02ca08d8: ldr     x8, [x0]                                   M:AdsManager::<OnApplicationPause>b__26_0
02ca08dc: ldp     x9, x1, [x8, #0x188]                       
02ca08e0: blr     x9                                         
02ca08e4: mov     x2, x0                                     
02ca08e8: mov     x0, x22                                    
02ca08ec: mov     x1, x21                                    
02ca08f0: b       #0x2ca0978                                 
02ca08f4: adrp    x21, #0x6265000                            
02ca08f8: mov     x0, x20                                    
02ca08fc: ldr     x21, [x21, #0xf58]                         MS:System.Threading.Tasks.Task`1::get_Result
02ca0900: ldr     x1, [x21]                                  M:AdsManager::<OnApplicationPause>b__26_0
02ca0904: bl      #0x3d3c594                                 fn_3d3c594
02ca0908: cbz     w0, #0x2ca09a0                             
02ca090c: ldr     x1, [x21]                                  M:AdsManager::<OnApplicationPause>b__26_0
02ca0910: mov     x0, x20                                    
02ca0914: bl      #0x3d3c594                                 fn_3d3c594
02ca0918: adrp    x8, #0x6265000                             
02ca091c: add     x1, sp, #0x18                              
02ca0920: ldr     x8, [x8, #0xf48]                           T:Firebase.DependencyStatus
02ca0924: str     w0, [sp, #0x18]                            
02ca0928: ldr     x8, [x8]                                   M:AdsManager::<OnApplicationPause>b__26_0
02ca092c: mov     x0, x8                                     
02ca0930: bl      #0x2b70f38                                 fn_2b70f38
02ca0934: ldr     x8, [x19, #0x18]                           .<>4__this
02ca0938: cbz     x8, #0x2ca09f4                             
02ca093c: adrp    x9, #0x6263000                             
02ca0940: ldr     w8, [x8, #0x30]                            T:AdsManager/<>c__DisplayClass32_0
02ca0944: mov     x20, x0                                    
02ca0948: ldr     x9, [x9, #0x970]                           &6645c70(=0)
02ca094c: add     x1, sp, #0xc                               
02ca0950: add     w8, w8, #1                                 
02ca0954: ldr     x0, [x9, #0x48]                            &6263098(=0)
02ca0958: str     w8, [sp, #0xc]                             
02ca095c: bl      #0x2b70f38                                 fn_2b70f38
02ca0960: adrp    x8, #0x6265000                             
02ca0964: mov     x2, x0                                     
02ca0968: mov     x1, x20                                    
02ca096c: ldr     x8, [x8, #0xf60]                           S:'Firebase dependencies not available: {0} (try {1})'
02ca0970: ldr     x8, [x8]                                   M:AdsManager::<OnApplicationPause>b__26_0
02ca0974: mov     x0, x8                                     
02ca0978: mov     x3, xzr                                    
02ca097c: bl      #0x4ca7720                                 System.String::Format
02ca0980: bl      #0x2ca09f8                                 WLog::LogError
02ca0984: mov     w8, #1                                     
02ca0988: ldp     x22, x21, [sp, #0x20]                      
02ca098c: strb    w8, [x19, #0x11]                           .isDone
02ca0990: ldp     x20, x19, [sp, #0x30]                      
02ca0994: ldr     x30, [sp, #0x10]                           
02ca0998: add     sp, sp, #0x40                              
02ca099c: ret                                                
02ca09a0: adrp    x8, #0x6265000                             
02ca09a4: ldr     x8, [x8, #0xf70]                           S:'Firebase is ready!'
02ca09a8: ldr     x0, [x8]                                   M:AdsManager::<OnApplicationPause>b__26_0
02ca09ac: bl      #0x2ca09f8                                 WLog::LogError
02ca09b0: adrp    x8, #0x6265000                             
02ca09b4: ldr     x8, [x8, #0xf50]                           T:Firebase.FirebaseApp
02ca09b8: ldr     x0, [x8]                                   M:AdsManager::<OnApplicationPause>b__26_0
02ca09bc: ldr     w8, [x0, #0xe4]                            [62650e4]=0 f=0,0
02ca09c0: cbnz    w8, #0x2ca09c8                             
02ca09c4: bl      #0x2b70f30                                 fn_2b70f30
02ca09c8: mov     x0, xzr                                    
02ca09cc: bl      #0x2e20ef4                                 Firebase.FirebaseApp::get_DefaultInstance
02ca09d0: ldr     x8, [x19, #0x18]                           .<>4__this
02ca09d4: cbz     x8, #0x2ca09f4                             
02ca09d8: ldr     x0, [x8, #0x20]                            S:'dev log AdsManager show app open ad'
02ca09dc: mov     w9, #1                                     
02ca09e0: strb    w9, [x8, #0x34]                            
02ca09e4: strb    w9, [x19, #0x10]                           .success
02ca09e8: cbz     x0, #0x2ca09f4                             
02ca09ec: bl      #0x2ca0a84                                 RemoteConfigManager::FetchAndActivate
02ca09f0: b       #0x2ca0984                                 
02ca09f4: bl      #0x2b7105c                                 fn_2b7105c
## <InitializeFirebase>b__1() -> bool
---- FirebaseManager/<>c__DisplayClass6_0::<InitializeFirebase>b__1 0x2ca0bcc
02ca0bcc: ldrb    w0, [x0, #0x11]                            .isDone
02ca0bd0: ret                                                
#### CLASS FirebaseManager/<InitializeFirebase>d__6 parent= object
#   field <>1__state                     int                                                off=0x10 attr=1 
#   field <>2__current                   object                                             off=0x18 attr=1 
#   field <>4__this                      FirebaseManager                                    off=0x20 attr=6 
#   field <>8__1                         FirebaseManager/<>c__DisplayClass6_0               off=0x28 attr=1 
## .ctor(int <>1__state) -> void
---- FirebaseManager/<InitializeFirebase>d__6::.ctor 0x2ca0750
02ca0750: str     x30, [sp, #-0x20]!                         
02ca0754: stp     x20, x19, [sp, #0x10]                      
02ca0758: mov     w19, w1                                    
02ca075c: mov     x1, xzr                                    
02ca0760: mov     x20, x0                                    
02ca0764: bl      #0x4e53e9c                                 System.Object::.ctor
02ca0768: str     w19, [x20, #0x10]                          .<>1__state
02ca076c: ldp     x20, x19, [sp, #0x10]                      
02ca0770: ldr     x30, [sp], #0x20                           
02ca0774: ret                                                
## System.IDisposable.Dispose() -> void
---- FirebaseManager/<InitializeFirebase>d__6::System.IDisposable.Dispose 0x2ca0bd4
02ca0bd4: ret                                                
## MoveNext() -> bool
---- FirebaseManager/<InitializeFirebase>d__6::MoveNext 0x2ca0bd8
02ca0bd8: sub     sp, sp, #0x40                              
02ca0bdc: str     d8, [sp, #0x10]                            
02ca0be0: str     x30, [sp, #0x18]                           
02ca0be4: stp     x22, x21, [sp, #0x20]                      
02ca0be8: stp     x20, x19, [sp, #0x30]                      
02ca0bec: adrp    x20, #0x662f000                            
02ca0bf0: mov     x19, x0                                    
02ca0bf4: ldrb    w8, [x20, #0xa8e]                          
02ca0bf8: tbnz    w8, #0, #0x2ca0c7c                         
02ca0bfc: adrp    x0, #0x6265000                             
02ca0c00: ldr     x0, [x0, #0xfa8]                           T:type53113(k15)
02ca0c04: bl      #0x2b70db0                                 fn_2b70db0
02ca0c08: adrp    x0, #0x6265000                             
02ca0c0c: ldr     x0, [x0, #0xf50]                           T:Firebase.FirebaseApp
02ca0c10: bl      #0x2b70db0                                 fn_2b70db0
02ca0c14: adrp    x0, #0x6265000                             
02ca0c18: ldr     x0, [x0, #0xfb0]                           T:type9979(k15)
02ca0c1c: bl      #0x2b70db0                                 fn_2b70db0
02ca0c20: adrp    x0, #0x6265000                             
02ca0c24: ldr     x0, [x0, #0xfb8]                           MS:Firebase.Extensions.TaskExtension::ContinueWithOnMainThread
02ca0c28: bl      #0x2b70db0                                 fn_2b70db0
02ca0c2c: adrp    x0, #0x6265000                             
02ca0c30: ldr     x0, [x0, #0xfc0]                           M:FirebaseManager/<>c__DisplayClass6_0::<InitializeFirebase>b__0
02ca0c34: bl      #0x2b70db0                                 fn_2b70db0
02ca0c38: adrp    x0, #0x6265000                             
02ca0c3c: ldr     x0, [x0, #0xfc8]                           M:FirebaseManager/<>c__DisplayClass6_0::<InitializeFirebase>b__1
02ca0c40: bl      #0x2b70db0                                 fn_2b70db0
02ca0c44: adrp    x0, #0x6265000                             
02ca0c48: ldr     x0, [x0, #0xfd0]                           T:FirebaseManager/<>c__DisplayClass6_0
02ca0c4c: bl      #0x2b70db0                                 fn_2b70db0
02ca0c50: adrp    x0, #0x6264000                             
02ca0c54: ldr     x0, [x0, #0xf58]                           T:UnityEngine.WaitForSeconds
02ca0c58: bl      #0x2b70db0                                 fn_2b70db0
02ca0c5c: adrp    x0, #0x6265000                             
02ca0c60: ldr     x0, [x0, #0xfd8]                           T:UnityEngine.WaitUntil
02ca0c64: bl      #0x2b70db0                                 fn_2b70db0
02ca0c68: adrp    x0, #0x6265000                             
02ca0c6c: ldr     x0, [x0, #0xfe0]                           S:'Retrying Init Firebase in {0}s'
02ca0c70: bl      #0x2b70db0                                 fn_2b70db0
02ca0c74: mov     w8, #1                                     
02ca0c78: strb    w8, [x20, #0xa8e]                          
02ca0c7c: ldr     w8, [x19, #0x10]                           .<>1__state
02ca0c80: ldr     x20, [x19, #0x20]                          .<>4__this
02ca0c84: cmp     w8, #2                                     
02ca0c88: b.eq    #0x2ca0d58                                 
02ca0c8c: cmp     w8, #1                                     
02ca0c90: b.eq    #0x2ca0ca4                                 
02ca0c94: cbnz    w8, #0x2ca0eb0                             
02ca0c98: mov     w8, #-1                                    
02ca0c9c: str     w8, [x19, #0x10]                           .<>1__state
02ca0ca0: b       #0x2ca0d70                                 
02ca0ca4: ldr     x8, [x19, #0x28]                           .<>8__1
02ca0ca8: mov     w9, #-1                                    
02ca0cac: str     w9, [x19, #0x10]                           .<>1__state
02ca0cb0: cbz     x8, #0x2ca0ecc                             
02ca0cb4: ldrb    w8, [x8, #0x10]                            
02ca0cb8: cbnz    w8, #0x2ca0eb0                             
02ca0cbc: cbz     x20, #0x2ca0ecc                            
02ca0cc0: ldr     w8, [x20, #0x30]                           &2b706f8(=d65f03c0b9401800)
02ca0cc4: ldr     w9, [x20, #0x28]                           [662f028]=6000015 f=2.40742e-35,0 .<>8__1
02ca0cc8: add     w8, w8, #1                                 
02ca0ccc: cmp     w8, w9                                     
02ca0cd0: str     w8, [x20, #0x30]                           
02ca0cd4: b.ge    #0x2ca0d60                                 
02ca0cd8: adrp    x8, #0x6263000                             
02ca0cdc: add     x1, sp, #0xc                               
02ca0ce0: ldr     x8, [x8, #0x970]                           &6645c70(=0)
02ca0ce4: ldr     s0, [x20, #0x2c]                           [662f02c]=0 f=0,0
02ca0ce8: ldr     x0, [x8, #0x78]                            &2c498b4(=d65f03c0d503245f)
02ca0cec: str     s0, [sp, #0xc]                             
02ca0cf0: bl      #0x2b70f38                                 fn_2b70f38
02ca0cf4: adrp    x8, #0x6265000                             
02ca0cf8: mov     x1, x0                                     
02ca0cfc: mov     x2, xzr                                    
02ca0d00: ldr     x8, [x8, #0xfe0]                           S:'Retrying Init Firebase in {0}s'
02ca0d04: ldr     x8, [x8]                                   M:AdsManager::<OnApplicationPause>b__26_0
02ca0d08: mov     x0, x8                                     
02ca0d0c: bl      #0x4c9d0ec                                 System.String::Format
02ca0d10: bl      #0x2ca09f8                                 WLog::LogError
02ca0d14: adrp    x8, #0x6264000                             
02ca0d18: ldr     x8, [x8, #0xf58]                           T:UnityEngine.WaitForSeconds
02ca0d1c: ldr     s8, [x20, #0x2c]                           [662f02c]=0 f=0,0
02ca0d20: ldr     x0, [x8]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02ca0d24: bl      #0x2b7104c                                 fn_2b7104c
02ca0d28: fmov    s0, s8                                     
02ca0d2c: mov     x1, xzr                                    
02ca0d30: mov     x20, x0                                    
02ca0d34: bl      #0x5b3e5e8                                 UnityEngine.WaitForSeconds::.ctor
02ca0d38: str     x20, [x19, #0x18]!                         .<>2__current
02ca0d3c: mov     x0, x19                                    
02ca0d40: mov     x1, x20                                    
02ca0d44: bl      #0x2b70d54                                 fn_2b70d54
02ca0d48: mov     w8, #2                                     
02ca0d4c: mov     w0, #1                                     
02ca0d50: stur    w8, [x19, #-8]                             
02ca0d54: b       #0x2ca0eb4                                 
02ca0d58: mov     w8, #-1                                    
02ca0d5c: str     w8, [x19, #0x10]                           .<>1__state
02ca0d60: mov     x0, x19                                    
02ca0d64: mov     x1, xzr                                    
02ca0d68: str     xzr, [x0, #0x28]!                          .<>8__1
02ca0d6c: bl      #0x2b70d54                                 fn_2b70d54
02ca0d70: cbz     x20, #0x2ca0ecc                            
02ca0d74: ldr     w8, [x20, #0x30]                           &2b706f8(=d65f03c0b9401800)
02ca0d78: ldr     w9, [x20, #0x28]                           [662f028]=6000015 f=2.40742e-35,0 .<>8__1
02ca0d7c: cmp     w8, w9                                     
02ca0d80: b.ge    #0x2ca0eb0                                 
02ca0d84: adrp    x8, #0x6265000                             
02ca0d88: ldr     x8, [x8, #0xfd0]                           T:FirebaseManager/<>c__DisplayClass6_0
02ca0d8c: ldr     x0, [x8]                                   M:AdsManager::<OnApplicationPause>b__26_0
02ca0d90: bl      #0x2b7104c                                 fn_2b7104c
02ca0d94: mov     x1, xzr                                    
02ca0d98: mov     x22, x0                                    
02ca0d9c: bl      #0x4e53e9c                                 System.Object::.ctor
02ca0da0: mov     x21, x19                                   
02ca0da4: mov     x1, x22                                    
02ca0da8: str     x22, [x21, #0x28]!                         .<>8__1
02ca0dac: mov     x0, x21                                    
02ca0db0: bl      #0x2b70d54                                 fn_2b70d54
02ca0db4: ldr     x0, [x21]                                  
02ca0db8: cbz     x0, #0x2ca0ecc                             
02ca0dbc: mov     x1, x20                                    
02ca0dc0: str     x20, [x0, #0x18]!                          .<>2__current
02ca0dc4: bl      #0x2b70d54                                 fn_2b70d54
02ca0dc8: ldr     x8, [x21]                                  
02ca0dcc: cbz     x8, #0x2ca0ecc                             
02ca0dd0: adrp    x9, #0x6265000                             
02ca0dd4: ldr     x9, [x9, #0xf50]                           T:Firebase.FirebaseApp
02ca0dd8: strh    wzr, [x8, #0x10]                           
02ca0ddc: ldr     x0, [x9]                                   M:AdsManager::<OnApplicationPause>b__26_0
02ca0de0: ldr     w8, [x0, #0xe4]                            [62650e4]=0 f=0,0
02ca0de4: cbnz    w8, #0x2ca0dec                             
02ca0de8: bl      #0x2b70f30                                 fn_2b70f30
02ca0dec: mov     x0, xzr                                    
02ca0df0: bl      #0x2e24818                                 Firebase.FirebaseApp::CheckAndFixDependenciesAsync
02ca0df4: adrp    x8, #0x6265000                             
02ca0df8: mov     x21, x0                                    
02ca0dfc: ldr     x8, [x8, #0xfa8]                           T:type53113(k15)
02ca0e00: ldr     x20, [x19, #0x28]                          .<>8__1
02ca0e04: ldr     x8, [x8]                                   M:AdsManager::<OnApplicationPause>b__26_0
02ca0e08: mov     x0, x8                                     
02ca0e0c: bl      #0x2b7104c                                 fn_2b7104c
02ca0e10: adrp    x8, #0x6265000                             
02ca0e14: mov     x1, x20                                    
02ca0e18: mov     x3, xzr                                    
02ca0e1c: ldr     x8, [x8, #0xfc0]                           M:FirebaseManager/<>c__DisplayClass6_0::<InitializeFirebase>b__0
02ca0e20: mov     x22, x0                                    
02ca0e24: ldr     x2, [x8]                                   M:AdsManager::<OnApplicationPause>b__26_0
02ca0e28: bl      #0x453418c                                 fn_453418c
02ca0e2c: adrp    x8, #0x6265000                             
02ca0e30: mov     x0, x21                                    
02ca0e34: mov     x1, x22                                    
02ca0e38: ldr     x8, [x8, #0xfb8]                           MS:Firebase.Extensions.TaskExtension::ContinueWithOnMainThread
02ca0e3c: ldr     x2, [x8]                                   M:AdsManager::<OnApplicationPause>b__26_0
02ca0e40: bl      #0x33610cc                                 fn_33610cc
02ca0e44: adrp    x8, #0x6265000                             
02ca0e48: ldr     x8, [x8, #0xfb0]                           T:type9979(k15)
02ca0e4c: ldr     x20, [x19, #0x28]                          .<>8__1
02ca0e50: ldr     x0, [x8]                                   M:AdsManager::<OnApplicationPause>b__26_0
02ca0e54: bl      #0x2b7104c                                 fn_2b7104c
02ca0e58: adrp    x8, #0x6265000                             
02ca0e5c: mov     x1, x20                                    
02ca0e60: mov     x3, xzr                                    
02ca0e64: ldr     x8, [x8, #0xfc8]                           M:FirebaseManager/<>c__DisplayClass6_0::<InitializeFirebase>b__1
02ca0e68: mov     x21, x0                                    
02ca0e6c: ldr     x2, [x8]                                   M:AdsManager::<OnApplicationPause>b__26_0
02ca0e70: bl      #0x4932dc8                                 fn_4932dc8
02ca0e74: adrp    x8, #0x6265000                             
02ca0e78: ldr     x8, [x8, #0xfd8]                           T:UnityEngine.WaitUntil
02ca0e7c: ldr     x0, [x8]                                   M:AdsManager::<OnApplicationPause>b__26_0
02ca0e80: bl      #0x2b7104c                                 fn_2b7104c
02ca0e84: mov     x1, x21                                    
02ca0e88: mov     x2, xzr                                    
02ca0e8c: mov     x20, x0                                    
02ca0e90: bl      #0x5b3e7e4                                 UnityEngine.WaitUntil::.ctor
02ca0e94: str     x20, [x19, #0x18]!                         .<>2__current
02ca0e98: mov     x0, x19                                    
02ca0e9c: mov     x1, x20                                    
02ca0ea0: bl      #0x2b70d54                                 fn_2b70d54
02ca0ea4: mov     w0, #1                                     
02ca0ea8: stur    w0, [x19, #-8]                             
02ca0eac: b       #0x2ca0eb4                                 
02ca0eb0: mov     w0, wzr                                    
02ca0eb4: ldp     x20, x19, [sp, #0x30]                      
02ca0eb8: ldr     x30, [sp, #0x18]                           
02ca0ebc: ldp     x22, x21, [sp, #0x20]                      
02ca0ec0: ldr     d8, [sp, #0x10]                            
02ca0ec4: add     sp, sp, #0x40                              
02ca0ec8: ret                                                
02ca0ecc: bl      #0x2b7105c                                 fn_2b7105c
## System.Collections.Generic.IEnumerator<System.Object>.get_Current() -> object
---- FirebaseManager/<InitializeFirebase>d__6::System.Collections.Generic.IEnumerator<System.Object>.get_Current 0x2ca0ed0
02ca0ed0: ldr     x0, [x0, #0x18]                            .<>2__current
02ca0ed4: ret                                                
## System.Collections.IEnumerator.Reset() -> void
---- FirebaseManager/<InitializeFirebase>d__6::System.Collections.IEnumerator.Reset 0x2ca0ed8
02ca0ed8: stp     x30, x19, [sp, #-0x10]!                    
02ca0edc: adrp    x0, #0x6264000                             
02ca0ee0: ldr     x0, [x0, #0xf60]                           T:System.NotSupportedException
02ca0ee4: bl      #0x2b70dc4                                 fn_2b70dc4
02ca0ee8: bl      #0x2b7104c                                 fn_2b7104c
02ca0eec: mov     x1, xzr                                    
02ca0ef0: mov     x19, x0                                    
02ca0ef4: bl      #0x4e14238                                 System.NotSupportedException::.ctor
02ca0ef8: adrp    x0, #0x6265000                             
02ca0efc: ldr     x0, [x0, #0xfe8]                           M:FirebaseManager/<InitializeFirebase>d__6::System.Collections.IEnumerator.Reset
02ca0f00: bl      #0x2b70dc4                                 fn_2b70dc4
02ca0f04: mov     x1, x0                                     
02ca0f08: mov     x0, x19                                    
02ca0f0c: bl      #0x2b70f20                                 fn_2b70f20
## System.Collections.IEnumerator.get_Current() -> object
---- FirebaseManager/<InitializeFirebase>d__6::System.Collections.IEnumerator.get_Current 0x2ca0f10
02ca0f10: ldr     x0, [x0, #0x18]                            .<>2__current
02ca0f14: ret                                                
#### CLASS FirebaseManager parent= WejoyService.Singleton`1<FirebaseManager>
#   field _remoteConfigManager           RemoteConfigManager                                off=0x20 attr=1 SerializeField
#   field maxRetryCount                  int                                                off=0x28 attr=1 
#   field retryDelaySeconds              float                                              off=0x2c attr=1 
#   field currentRetry                   int                                                off=0x30 attr=1 
#   field isInitialized                  bool                                               off=0x34 attr=1 
## Start() -> void
---- FirebaseManager::Start 0x2ca06c4
02ca06c4: stp     x30, x19, [sp, #-0x10]!                    
02ca06c8: mov     x19, x0                                    
02ca06cc: bl      #0x2ca06e4                                 FirebaseManager::InitializeFirebase
02ca06d0: mov     x1, x0                                     
02ca06d4: mov     x0, x19                                    
02ca06d8: mov     x2, xzr                                    
02ca06dc: ldp     x30, x19, [sp], #0x10                      
02ca06e0: b       #0x5b389f0                                 UnityEngine.MonoBehaviour::StartCoroutine
## InitializeFirebase() -> System.Collections.IEnumerator
---- FirebaseManager::InitializeFirebase 0x2ca06e4
02ca06e4: stp     x30, x21, [sp, #-0x20]!                    
02ca06e8: stp     x20, x19, [sp, #0x10]                      
02ca06ec: adrp    x20, #0x662f000                            
02ca06f0: adrp    x21, #0x6265000                            
02ca06f4: mov     x19, x0                                    
02ca06f8: ldrb    w8, [x20, #0xa8b]                          
02ca06fc: ldr     x21, [x21, #0xf38]                         T:FirebaseManager/<InitializeFirebase>d__6
02ca0700: tbnz    w8, #0, #0x2ca0718                         
02ca0704: adrp    x0, #0x6265000                             
02ca0708: ldr     x0, [x0, #0xf38]                           T:FirebaseManager/<InitializeFirebase>d__6
02ca070c: bl      #0x2b70db0                                 fn_2b70db0
02ca0710: mov     w8, #1                                     
02ca0714: strb    w8, [x20, #0xa8b]                          
02ca0718: ldr     x0, [x21]                                  M:AdsManager::<OnApplicationPause>b__26_0
02ca071c: bl      #0x2b7104c                                 fn_2b7104c
02ca0720: mov     x1, xzr                                    
02ca0724: mov     x20, x0                                    
02ca0728: bl      #0x4e53e9c                                 System.Object::.ctor
02ca072c: mov     x0, x20                                    
02ca0730: mov     x1, x19                                    
02ca0734: str     wzr, [x20, #0x10]                          
02ca0738: str     x19, [x0, #0x20]!                          ._remoteConfigManager
02ca073c: bl      #0x2b70d54                                 fn_2b70d54
02ca0740: mov     x0, x20                                    
02ca0744: ldp     x20, x19, [sp, #0x10]                      
02ca0748: ldp     x30, x21, [sp], #0x20                      
02ca074c: ret                                                
## get_IsInitialized() -> bool
---- FirebaseManager::get_IsInitialized 0x2ca0778
02ca0778: ldrb    w0, [x0, #0x34]                            .isInitialized
02ca077c: ret                                                
## .ctor() -> void
---- FirebaseManager::.ctor 0x2ca0780
02ca0780: stp     x30, x21, [sp, #-0x20]!                    
02ca0784: stp     x20, x19, [sp, #0x10]                      
02ca0788: adrp    x21, #0x662f000                            
02ca078c: adrp    x20, #0x6265000                            
02ca0790: mov     x19, x0                                    
02ca0794: ldrb    w8, [x21, #0xa8c]                          
02ca0798: ldr     x20, [x20, #0xf40]                         MS:WejoyService.Singleton`1::.ctor
02ca079c: tbnz    w8, #0, #0x2ca07b4                         
02ca07a0: adrp    x0, #0x6265000                             
02ca07a4: ldr     x0, [x0, #0xf40]                           MS:WejoyService.Singleton`1::.ctor
02ca07a8: bl      #0x2b70db0                                 fn_2b70db0
02ca07ac: mov     w8, #1                                     
02ca07b0: strb    w8, [x21, #0xa8c]                          
02ca07b4: mov     x8, #5                                     
02ca07b8: ldr     x1, [x20]                                  M:AdsManager::<OnApplicationPause>b__26_0
02ca07bc: mov     x0, x19                                    
02ca07c0: movk    x8, #0x4040, lsl #48                       
02ca07c4: str     x8, [x19, #0x28]                           .maxRetryCount
02ca07c8: ldp     x20, x19, [sp, #0x10]                      
02ca07cc: ldp     x30, x21, [sp], #0x20                      
02ca07d0: b       #0x3be76dc                                 
