#### CLASS DailyMission.DailyContent parent= object
#   field Icon                           UnityEngine.Sprite                                 off=0x10 attr=6 
#   field IsCoin                         bool                                               off=0x18 attr=6 
#   field Coin                           int                                                off=0x1c attr=6 ConditionalFieldAttribute
#   field ItemConfig                     DailyMission.RewardItemConfig                      off=0x20 attr=6 ConditionalFieldAttribute
## .ctor() -> void
---- DailyMission.DailyContent::.ctor 0x2d764a0
02d764a0: mov     x1, xzr                                    
02d764a4: b       #0x4e53e9c                                 System.Object::.ctor
