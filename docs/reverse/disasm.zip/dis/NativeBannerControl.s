#### CLASS NativeBannerControl/<>c parent= object
#   field <>9                            NativeBannerControl/<>c                            off=0x0 attr=36 
#   field <>9__21_1                      System.Action                                      off=0x8 attr=16 
#   field <>9__21_2                      System.Action`4<string,string,double,string>       off=0x10 attr=16 
## .cctor() -> void
---- NativeBannerControl/<>c::.cctor 0x2c97ee0
02c97ee0: str     x30, [sp, #-0x20]!                         
02c97ee4: stp     x20, x19, [sp, #0x10]                      
02c97ee8: adrp    x19, #0x662f000                            
02c97eec: adrp    x20, #0x6265000                            
02c97ef0: ldrb    w8, [x19, #0xa1b]                          
02c97ef4: ldr     x20, [x20, #0x898]                         T:NativeBannerControl/<>c
02c97ef8: tbnz    w8, #0, #0x2c97f10                         
02c97efc: adrp    x0, #0x6265000                             
02c97f00: ldr     x0, [x0, #0x898]                           T:NativeBannerControl/<>c
02c97f04: bl      #0x2b70db0                                 fn_2b70db0
02c97f08: mov     w8, #1                                     
02c97f0c: strb    w8, [x19, #0xa1b]                          
02c97f10: ldr     x0, [x20]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c97f14: bl      #0x2b7104c                                 fn_2b7104c
02c97f18: mov     x1, xzr                                    
02c97f1c: mov     x19, x0                                    
02c97f20: bl      #0x4e53e9c                                 System.Object::.ctor
02c97f24: ldr     x8, [x20]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c97f28: mov     x1, x19                                    
02c97f2c: ldr     x8, [x8, #0xb8]                            
02c97f30: str     x19, [x8]                                  
02c97f34: ldr     x8, [x20]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c97f38: ldp     x20, x19, [sp, #0x10]                      
02c97f3c: ldr     x0, [x8, #0xb8]                            
02c97f40: ldr     x30, [sp], #0x20                           
02c97f44: b       #0x2b70d54                                 
## .ctor() -> void
---- NativeBannerControl/<>c::.ctor 0x2c97f48
02c97f48: mov     x1, xzr                                    
02c97f4c: b       #0x4e53e9c                                 System.Object::.ctor
## <RegisterListener>b__21_1() -> void
---- NativeBannerControl/<>c::<RegisterListener>b__21_1 0x2c97f50
02c97f50: ret                                                
## <RegisterListener>b__21_2(string adSource, string adUnitId, double valueMicros, string currencyCode) -> void
---- NativeBannerControl/<>c::<RegisterListener>b__21_2 0x2c97f54
02c97f54: sub     sp, sp, #0x80                              
02c97f58: str     d8, [sp, #0x10]                            
02c97f5c: stp     x29, x30, [sp, #0x20]                      
02c97f60: stp     x28, x27, [sp, #0x30]                      
02c97f64: stp     x26, x25, [sp, #0x40]                      
02c97f68: stp     x24, x23, [sp, #0x50]                      
02c97f6c: stp     x22, x21, [sp, #0x60]                      
02c97f70: stp     x20, x19, [sp, #0x70]                      
02c97f74: fmov    d8, d0                                     
02c97f78: adrp    x22, #0x662f000                            
02c97f7c: adrp    x21, #0x6265000                            
02c97f80: ldrb    w8, [x22, #0xa1c]                          
02c97f84: ldr     x21, [x21, #0x1f0]                         T:type24519(k1d)
02c97f88: mov     x20, x2                                    
02c97f8c: mov     x19, x1                                    
02c97f90: tbnz    w8, #0, #0x2c98068                         
02c97f94: adrp    x0, #0x6265000                             
02c97f98: ldr     x0, [x0, #0x2d0]                           T:AppsFlyerSDK.AFAdRevenueData
02c97f9c: bl      #0x2b70db0                                 fn_2b70db0
02c97fa0: adrp    x0, #0x6263000                             
02c97fa4: ldr     x0, [x0, #0x900]                           T:AppsFlyerSDK.AppsFlyer
02c97fa8: bl      #0x2b70db0                                 fn_2b70db0
02c97fac: adrp    x0, #0x6265000                             
02c97fb0: ldr     x0, [x0, #0x2d8]                           MS:System.Collections.Generic.Dictionary`2::Add
02c97fb4: bl      #0x2b70db0                                 fn_2b70db0
02c97fb8: adrp    x0, #0x6265000                             
02c97fbc: ldr     x0, [x0, #0x2e0]                           MS:System.Collections.Generic.Dictionary`2::.ctor
02c97fc0: bl      #0x2b70db0                                 fn_2b70db0
02c97fc4: adrp    x0, #0x6265000                             
02c97fc8: ldr     x0, [x0, #0x2e8]                           T:type8944(k15)
02c97fcc: bl      #0x2b70db0                                 fn_2b70db0
02c97fd0: adrp    x0, #0x6265000                             
02c97fd4: ldr     x0, [x0, #0x1f8]                           T:Firebase.Analytics.FirebaseAnalytics
02c97fd8: bl      #0x2b70db0                                 fn_2b70db0
02c97fdc: adrp    x0, #0x6265000                             
02c97fe0: ldr     x0, [x0, #0x1f0]                           T:type24519(k1d)
02c97fe4: bl      #0x2b70db0                                 fn_2b70db0
02c97fe8: adrp    x0, #0x6265000                             
02c97fec: ldr     x0, [x0, #0x200]                           T:Firebase.Analytics.Parameter
02c97ff0: bl      #0x2b70db0                                 fn_2b70db0
02c97ff4: adrp    x0, #0x6264000                             
02c97ff8: ldr     x0, [x0, #0xd90]                           S:'{0}'
02c97ffc: bl      #0x2b70db0                                 fn_2b70db0
02c98000: adrp    x0, #0x6265000                             
02c98004: ldr     x0, [x0, #0x280]                           S:'ad_unit_name'
02c98008: bl      #0x2b70db0                                 fn_2b70db0
02c9800c: adrp    x0, #0x6265000                             
02c98010: ldr     x0, [x0, #0x288]                           S:'ad_format'
02c98014: bl      #0x2b70db0                                 fn_2b70db0
02c98018: adrp    x0, #0x6265000                             
02c9801c: ldr     x0, [x0, #0x2a0]                           S:'value'
02c98020: bl      #0x2b70db0                                 fn_2b70db0
02c98024: adrp    x0, #0x6265000                             
02c98028: ldr     x0, [x0, #0x2a8]                           S:'ad_source'
02c9802c: bl      #0x2b70db0                                 fn_2b70db0
02c98030: adrp    x0, #0x6265000                             
02c98034: ldr     x0, [x0, #0x930]                           S:'NATIVE_BANNER'
02c98038: bl      #0x2b70db0                                 fn_2b70db0
02c9803c: adrp    x0, #0x6265000                             
02c98040: ldr     x0, [x0, #0x2b0]                           S:'currency'
02c98044: bl      #0x2b70db0                                 fn_2b70db0
02c98048: adrp    x0, #0x6265000                             
02c9804c: ldr     x0, [x0, #0x2b8]                           S:'USD'
02c98050: bl      #0x2b70db0                                 fn_2b70db0
02c98054: adrp    x0, #0x6265000                             
02c98058: ldr     x0, [x0, #0x2c0]                           S:'ad_impression'
02c9805c: bl      #0x2b70db0                                 fn_2b70db0
02c98060: mov     w8, #1                                     
02c98064: strb    w8, [x22, #0xa1c]                          
02c98068: ldr     x0, [x21]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9806c: str     wzr, [sp, #8]                              
02c98070: mov     w1, #5                                     
02c98074: bl      #0x2b70ea0                                 fn_2b70ea0
02c98078: adrp    x27, #0x6265000                            
02c9807c: mov     x21, x0                                    
02c98080: ldr     x27, [x27, #0x200]                         T:Firebase.Analytics.Parameter
02c98084: ldr     x0, [x27]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c98088: bl      #0x2b7104c                                 fn_2b7104c
02c9808c: adrp    x23, #0x6265000                            
02c98090: mov     x22, x0                                    
02c98094: ldr     x23, [x23, #0x2a8]                         S:'ad_source'
02c98098: ldr     x1, [x23]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9809c: mov     x2, x19                                    
02c980a0: mov     x3, xzr                                    
02c980a4: bl      #0x2e07b48                                 Firebase.Analytics.Parameter::.ctor
02c980a8: cbz     x21, #0x2c983b8                            
02c980ac: cbz     x22, #0x2c980c4                            
02c980b0: ldr     x8, [x21]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c980b4: ldr     x1, [x8, #0x40]                            
02c980b8: mov     x0, x22                                    
02c980bc: bl      #0x2b70f34                                 fn_2b70f34
02c980c0: cbz     x0, #0x2c983d4                             
02c980c4: ldr     w8, [x21, #0x18]                           T:AdsManager/<IEHideAdResume>d__30
02c980c8: cbz     w8, #0x2c983bc                             
02c980cc: mov     x0, x21                                    
02c980d0: str     x22, [x0, #0x20]!                          
02c980d4: mov     x1, x22                                    
02c980d8: bl      #0x2b70d54                                 fn_2b70d54
02c980dc: ldr     x0, [x27]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c980e0: bl      #0x2b7104c                                 fn_2b7104c
02c980e4: adrp    x24, #0x6265000                            
02c980e8: mov     x22, x0                                    
02c980ec: ldr     x24, [x24, #0x280]                         S:'ad_unit_name'
02c980f0: ldr     x1, [x24]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c980f4: mov     x2, x20                                    
02c980f8: mov     x3, xzr                                    
02c980fc: bl      #0x2e07b48                                 Firebase.Analytics.Parameter::.ctor
02c98100: cbz     x22, #0x2c98118                            
02c98104: ldr     x8, [x21]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c98108: ldr     x1, [x8, #0x40]                            
02c9810c: mov     x0, x22                                    
02c98110: bl      #0x2b70f34                                 fn_2b70f34
02c98114: cbz     x0, #0x2c983e0                             
02c98118: ldr     w8, [x21, #0x18]                           T:AdsManager/<IEHideAdResume>d__30
02c9811c: tst     w8, #0xfffffffe                            
02c98120: b.eq    #0x2c983c0                                 
02c98124: mov     x0, x21                                    
02c98128: str     x22, [x0, #0x28]!                          
02c9812c: mov     x1, x22                                    
02c98130: bl      #0x2b70d54                                 fn_2b70d54
02c98134: ldr     x0, [x27]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c98138: bl      #0x2b7104c                                 fn_2b7104c
02c9813c: adrp    x25, #0x6265000                            
02c98140: adrp    x26, #0x6265000                            
02c98144: mov     x22, x0                                    
02c98148: ldr     x25, [x25, #0x288]                         S:'ad_format'
02c9814c: ldr     x26, [x26, #0x930]                         S:'NATIVE_BANNER'
02c98150: ldr     x1, [x25]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c98154: ldr     x2, [x26]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c98158: mov     x3, xzr                                    
02c9815c: bl      #0x2e07b48                                 Firebase.Analytics.Parameter::.ctor
02c98160: cbz     x22, #0x2c98178                            
02c98164: ldr     x8, [x21]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c98168: ldr     x1, [x8, #0x40]                            
02c9816c: mov     x0, x22                                    
02c98170: bl      #0x2b70f34                                 fn_2b70f34
02c98174: cbz     x0, #0x2c983ec                             
02c98178: ldr     w8, [x21, #0x18]                           T:AdsManager/<IEHideAdResume>d__30
02c9817c: cmp     w8, #2                                     
02c98180: b.ls    #0x2c983c4                                 
02c98184: mov     x0, x21                                    
02c98188: str     x22, [x0, #0x30]!                          
02c9818c: mov     x1, x22                                    
02c98190: bl      #0x2b70d54                                 fn_2b70d54
02c98194: ldr     x0, [x27]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c98198: bl      #0x2b7104c                                 fn_2b7104c
02c9819c: adrp    x28, #0x6265000                            
02c981a0: mov     x22, x0                                    
02c981a4: ldr     x28, [x28, #0x2a0]                         S:'value'
02c981a8: ldr     x1, [x28]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c981ac: fmov    d0, d8                                     
02c981b0: mov     x2, xzr                                    
02c981b4: bl      #0x2e07bf4                                 Firebase.Analytics.Parameter::.ctor
02c981b8: cbz     x22, #0x2c981d0                            
02c981bc: ldr     x8, [x21]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c981c0: ldr     x1, [x8, #0x40]                            
02c981c4: mov     x0, x22                                    
02c981c8: bl      #0x2b70f34                                 fn_2b70f34
02c981cc: cbz     x0, #0x2c983f8                             
02c981d0: ldr     w8, [x21, #0x18]                           T:AdsManager/<IEHideAdResume>d__30
02c981d4: tst     w8, #0xfffffffc                            
02c981d8: b.eq    #0x2c983c8                                 
02c981dc: mov     x0, x21                                    
02c981e0: str     x22, [x0, #0x38]!                          
02c981e4: mov     x1, x22                                    
02c981e8: bl      #0x2b70d54                                 fn_2b70d54
02c981ec: ldr     x0, [x27]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c981f0: bl      #0x2b7104c                                 fn_2b7104c
02c981f4: adrp    x29, #0x6265000                            
02c981f8: adrp    x27, #0x6265000                            
02c981fc: mov     x22, x0                                    
02c98200: ldr     x29, [x29, #0x2b0]                         S:'currency'
02c98204: ldr     x27, [x27, #0x2b8]                         S:'USD'
02c98208: ldr     x1, [x29]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9820c: ldr     x2, [x27]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c98210: mov     x3, xzr                                    
02c98214: bl      #0x2e07b48                                 Firebase.Analytics.Parameter::.ctor
02c98218: cbz     x22, #0x2c98230                            
02c9821c: ldr     x8, [x21]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c98220: ldr     x1, [x8, #0x40]                            
02c98224: mov     x0, x22                                    
02c98228: bl      #0x2b70f34                                 fn_2b70f34
02c9822c: cbz     x0, #0x2c98404                             
02c98230: ldr     w8, [x21, #0x18]                           T:AdsManager/<IEHideAdResume>d__30
02c98234: cmp     w8, #4                                     
02c98238: b.ls    #0x2c983cc                                 
02c9823c: mov     x0, x21                                    
02c98240: str     x22, [x0, #0x40]!                          
02c98244: mov     x1, x22                                    
02c98248: bl      #0x2b70d54                                 fn_2b70d54
02c9824c: adrp    x8, #0x6265000                             
02c98250: ldr     x8, [x8, #0x1f8]                           T:Firebase.Analytics.FirebaseAnalytics
02c98254: ldr     x0, [x8]                                   M:AdsManager::<OnApplicationPause>b__26_0
02c98258: ldr     w8, [x0, #0xe4]                            [62650e4]=0 f=0,0
02c9825c: cbnz    w8, #0x2c98264                             
02c98260: bl      #0x2b70f30                                 fn_2b70f30
02c98264: adrp    x8, #0x6265000                             
02c98268: ldr     x8, [x8, #0x2c0]                           S:'ad_impression'
02c9826c: ldr     x0, [x8]                                   M:AdsManager::<OnApplicationPause>b__26_0
02c98270: mov     x1, x21                                    
02c98274: mov     x2, xzr                                    
02c98278: bl      #0x2e052d8                                 Firebase.Analytics.FirebaseAnalytics::LogEvent
02c9827c: adrp    x8, #0x6265000                             
02c98280: ldr     x8, [x8, #0x2e8]                           T:type8944(k15)
02c98284: ldr     x0, [x8]                                   M:AdsManager::<OnApplicationPause>b__26_0
02c98288: bl      #0x2b7104c                                 fn_2b7104c
02c9828c: adrp    x8, #0x6265000                             
02c98290: mov     x21, x0                                    
02c98294: ldr     x8, [x8, #0x2e0]                           MS:System.Collections.Generic.Dictionary`2::.ctor
02c98298: ldr     x1, [x8]                                   M:AdsManager::<OnApplicationPause>b__26_0
02c9829c: bl      #0x452b8a0                                 fn_452b8a0
02c982a0: cbz     x21, #0x2c983d0                            
02c982a4: adrp    x22, #0x6265000                            
02c982a8: ldr     x22, [x22, #0x2d8]                         MS:System.Collections.Generic.Dictionary`2::Add
02c982ac: ldr     x1, [x23]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c982b0: ldr     x3, [x22]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c982b4: mov     x0, x21                                    
02c982b8: mov     x2, x19                                    
02c982bc: bl      #0x452c61c                                 fn_452c61c
02c982c0: ldr     x1, [x24]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c982c4: ldr     x3, [x22]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c982c8: mov     x0, x21                                    
02c982cc: mov     x2, x20                                    
02c982d0: bl      #0x452c61c                                 fn_452c61c
02c982d4: ldr     x1, [x25]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c982d8: ldr     x2, [x26]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c982dc: ldr     x3, [x22]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c982e0: mov     x0, x21                                    
02c982e4: bl      #0x452c61c                                 fn_452c61c
02c982e8: adrp    x8, #0x6263000                             
02c982ec: ldr     x8, [x8, #0x970]                           &6645c70(=0)
02c982f0: str     d8, [sp, #0x18]                            
02c982f4: ldr     x0, [x8, #0x80]                            &2c498bc(=aa1f03e0d503245f)
02c982f8: add     x1, sp, #0x18                              
02c982fc: bl      #0x2b70f38                                 fn_2b70f38
02c98300: mov     x1, x0                                     
02c98304: adrp    x8, #0x6264000                             
02c98308: ldr     x8, [x8, #0xd90]                           S:'{0}'
02c9830c: ldr     x0, [x8]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c98310: mov     x2, xzr                                    
02c98314: bl      #0x4c9d0ec                                 System.String::Format
02c98318: ldr     x1, [x28]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9831c: ldr     x3, [x22]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c98320: mov     x2, x0                                     
02c98324: mov     x0, x21                                    
02c98328: bl      #0x452c61c                                 fn_452c61c
02c9832c: ldr     x1, [x29]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c98330: ldr     x2, [x27]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c98334: ldr     x3, [x22]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c98338: mov     x0, x21                                    
02c9833c: bl      #0x452c61c                                 fn_452c61c
02c98340: adrp    x8, #0x6265000                             
02c98344: ldr     x8, [x8, #0x2d0]                           T:AppsFlyerSDK.AFAdRevenueData
02c98348: ldr     x0, [x8]                                   M:AdsManager::<OnApplicationPause>b__26_0
02c9834c: bl      #0x2b7104c                                 fn_2b7104c
02c98350: mov     x20, x0                                    
02c98354: ldr     x3, [x27]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c98358: fmov    d0, d8                                     
02c9835c: mov     x1, x19                                    
02c98360: mov     w2, #1                                     
02c98364: mov     x4, xzr                                    
02c98368: bl      #0x2c66b2c                                 AppsFlyerSDK.AFAdRevenueData::.ctor
02c9836c: adrp    x8, #0x6263000                             
02c98370: ldr     x8, [x8, #0x900]                           T:AppsFlyerSDK.AppsFlyer
02c98374: ldr     x0, [x8]                                   &2c5bbd4(=a9bd7bfdd503233f)
02c98378: ldr     w8, [x0, #0xe4]                            [62650e4]=0 f=0,0
02c9837c: cbnz    w8, #0x2c98384                             
02c98380: bl      #0x2b70f30                                 fn_2b70f30
02c98384: mov     x0, x20                                    
02c98388: mov     x1, x21                                    
02c9838c: mov     x2, xzr                                    
02c98390: bl      #0x2c67cf8                                 AppsFlyerSDK.AppsFlyer::logAdRevenue
02c98394: ldp     x20, x19, [sp, #0x70]                      
02c98398: ldr     d8, [sp, #0x10]                            
02c9839c: ldp     x22, x21, [sp, #0x60]                      
02c983a0: ldp     x24, x23, [sp, #0x50]                      
02c983a4: ldp     x26, x25, [sp, #0x40]                      
02c983a8: ldp     x28, x27, [sp, #0x30]                      
02c983ac: ldp     x29, x30, [sp, #0x20]                      
02c983b0: add     sp, sp, #0x80                              
02c983b4: ret                                                
02c983b8: bl      #0x2b7105c                                 fn_2b7105c
02c983bc: bl      #0x2b71064                                 fn_2b71064
02c983c0: bl      #0x2b71064                                 fn_2b71064
02c983c4: bl      #0x2b71064                                 fn_2b71064
02c983c8: bl      #0x2b71064                                 fn_2b71064
02c983cc: bl      #0x2b71064                                 fn_2b71064
02c983d0: bl      #0x2b7105c                                 fn_2b7105c
02c983d4: bl      #0x2b71080                                 fn_2b71080
02c983d8: mov     x1, xzr                                    
02c983dc: bl      #0x2b70f20                                 fn_2b70f20
02c983e0: bl      #0x2b71080                                 fn_2b71080
02c983e4: mov     x1, xzr                                    
02c983e8: bl      #0x2b70f20                                 fn_2b70f20
02c983ec: bl      #0x2b71080                                 fn_2b71080
02c983f0: mov     x1, xzr                                    
02c983f4: bl      #0x2b70f20                                 fn_2b70f20
02c983f8: bl      #0x2b71080                                 fn_2b71080
02c983fc: mov     x1, xzr                                    
02c98400: bl      #0x2b70f20                                 fn_2b70f20
02c98404: bl      #0x2b71080                                 fn_2b71080
02c98408: mov     x1, xzr                                    
02c9840c: bl      #0x2b70f20                                 fn_2b70f20
02c98410: b       #0x2c9844c                                 
02c98414: b       #0x2c9844c                                 
02c98418: b       #0x2c9844c                                 
02c9841c: b       #0x2c9844c                                 
02c98420: b       #0x2c9844c                                 
02c98424: b       #0x2c9844c                                 
02c98428: b       #0x2c9844c                                 
02c9842c: b       #0x2c9844c                                 
02c98430: b       #0x2c9844c                                 
02c98434: b       #0x2c9844c                                 
02c98438: b       #0x2c9844c                                 
02c9843c: b       #0x2c9844c                                 
02c98440: b       #0x2c9844c                                 
02c98444: b       #0x2c9844c                                 
02c98448: b       #0x2c9844c                                 
02c9844c: mov     x19, x0                                    
02c98450: cmp     w1, #1                                     
02c98454: b.ne    #0x2c984cc                                 
02c98458: mov     x0, x19                                    
02c9845c: bl      #0x5e90260                                 fn_5e90260
02c98460: mov     x19, x0                                    
02c98464: adrp    x0, #0x6263000                             
02c98468: ldr     x0, [x0, #0xae0]                           T:System.Exception
02c9846c: bl      #0x2b70dc4                                 fn_2b70dc4
02c98470: ldr     x8, [x19]                                  
02c98474: ldr     x1, [x8]                                   &2c5bbd4(=a9bd7bfdd503233f)
02c98478: bl      #0x2b71464                                 fn_2b71464
02c9847c: tbz     w0, #0, #0x2c984a4                         
02c98480: ldrsw   x20, [sp, #8]                              
02c98484: ldr     x8, [x19]                                  
02c98488: mov     x9, sp                                     
02c9848c: str     x8, [x9, x20, lsl #3]                      
02c98490: add     w8, w20, #1                                
02c98494: str     w8, [sp, #8]                               
02c98498: bl      #0x5e90270                                 fn_5e90270
02c9849c: str     w20, [sp, #8]                              
02c984a0: b       #0x2c98394                                 
02c984a4: mov     w0, #8                                     
02c984a8: bl      #0x5e90290                                 fn_5e90290
02c984ac: ldr     x8, [x19]                                  
02c984b0: str     x8, [x0]                                   
02c984b4: adrp    x1, #0x5e96000                             
02c984b8: add     x1, x1, #0x758                             &5e96758
02c984bc: mov     x2, xzr                                    
02c984c0: bl      #0x5e902a0                                 fn_5e902a0
02c984c4: mov     x19, x0                                    
02c984c8: bl      #0x5e90270                                 fn_5e90270
02c984cc: mov     x0, x19                                    
02c984d0: bl      #0x2c6051c                                 fn_2c6051c
02c984d4: bl      #0x27369b8                                 fn_27369b8
#### CLASS NativeBannerControl/<>c__DisplayClass24_0 parent= object
#   field showToken                      int                                                off=0x10 attr=6 
#   field <>4__this                      NativeBannerControl                                off=0x18 attr=6 
## .ctor() -> void
---- NativeBannerControl/<>c__DisplayClass24_0::.ctor 0x2c97818
02c97818: mov     x1, xzr                                    
02c9781c: b       #0x4e53e9c                                 System.Object::.ctor
## <ShowFsnAd>b__0(string errMessage) -> void
---- NativeBannerControl/<>c__DisplayClass24_0::<ShowFsnAd>b__0 0x2c984d8
02c984d8: str     x30, [sp, #-0x10]!                         
02c984dc: ldr     w9, [x0, #0x10]                            .showToken
02c984e0: ldr     x8, [x0, #0x18]                            .<>4__this
02c984e4: tbnz    w9, #0x1f, #0x2c984fc                      
02c984e8: cbz     x8, #0x2c9850c                             
02c984ec: ldr     w10, [x8, #0x54]                           
02c984f0: cmp     w9, w10                                    
02c984f4: b.eq    #0x2c98500                                 
02c984f8: b       #0x2c98504                                 
02c984fc: cbz     x8, #0x2c9850c                             
02c98500: strb    wzr, [x8, #0x50]                           
02c98504: ldr     x30, [sp], #0x10                           
02c98508: ret                                                
02c9850c: bl      #0x2b7105c                                 fn_2b7105c
#### CLASS NativeBannerControl/<RefreshAdCoroutine>d__27 parent= object
#   field <>1__state                     int                                                off=0x10 attr=1 
#   field <>2__current                   object                                             off=0x18 attr=1 
#   field <>4__this                      NativeBannerControl                                off=0x20 attr=6 
#   field <replacementAd>5__2            FsnBannerAd                                        off=0x28 attr=1 
#   field <elapsed>5__3                  float                                              off=0x30 attr=1 
#   field <ready>5__4                    bool                                               off=0x34 attr=1 
## .ctor(int <>1__state) -> void
---- NativeBannerControl/<RefreshAdCoroutine>d__27::.ctor 0x2c97a30
02c97a30: str     x30, [sp, #-0x20]!                         
02c97a34: stp     x20, x19, [sp, #0x10]                      
02c97a38: mov     w19, w1                                    
02c97a3c: mov     x1, xzr                                    
02c97a40: mov     x20, x0                                    
02c97a44: bl      #0x4e53e9c                                 System.Object::.ctor
02c97a48: str     w19, [x20, #0x10]                          .<>1__state
02c97a4c: ldp     x20, x19, [sp, #0x10]                      
02c97a50: ldr     x30, [sp], #0x20                           
02c97a54: ret                                                
## System.IDisposable.Dispose() -> void
---- NativeBannerControl/<RefreshAdCoroutine>d__27::System.IDisposable.Dispose 0x2c98510
02c98510: ret                                                
## MoveNext() -> bool
---- NativeBannerControl/<RefreshAdCoroutine>d__27::MoveNext 0x2c98514
02c98514: str     d8, [sp, #-0x30]!                          
02c98518: stp     x30, x21, [sp, #0x10]                      
02c9851c: stp     x20, x19, [sp, #0x20]                      
02c98520: adrp    x20, #0x662f000                            
02c98524: mov     x19, x0                                    
02c98528: ldrb    w8, [x20, #0xa1d]                          
02c9852c: tbnz    w8, #0, #0x2c98544                         
02c98530: adrp    x0, #0x6264000                             
02c98534: ldr     x0, [x0, #0xf58]                           T:UnityEngine.WaitForSeconds
02c98538: bl      #0x2b70db0                                 fn_2b70db0
02c9853c: mov     w8, #1                                     
02c98540: strb    w8, [x20, #0xa1d]                          
02c98544: ldr     w8, [x19, #0x10]                           .<>1__state
02c98548: ldr     x20, [x19, #0x20]                          .<>4__this
02c9854c: cmp     w8, #2                                     
02c98550: b.eq    #0x2c985c4                                 
02c98554: cmp     w8, #1                                     
02c98558: b.eq    #0x2c98570                                 
02c9855c: cbnz    w8, #0x2c986e8                             
02c98560: mov     w8, #-1                                    
02c98564: str     w8, [x19, #0x10]                           .<>1__state
02c98568: cbnz    x20, #0x2c9868c                            
02c9856c: b       #0x2c986fc                                 
02c98570: mov     w8, #-1                                    
02c98574: str     w8, [x19, #0x10]                           .<>1__state
02c98578: cbz     x20, #0x2c986fc                            
02c9857c: bl      #0x2c97044                                 NativeBannerControl::get_IsEnabled
02c98580: tbz     w0, #0, #0x2c986e8                         
02c98584: ldr     x0, [x20, #0x20]                           &2b706f0(=d65f03c0f9400800) .<>4__this
02c98588: cbz     x0, #0x2c9868c                             
02c9858c: bl      #0x2c94644                                 FsnBannerAd::IsBannerAdReady
02c98590: tbz     w0, #0, #0x2c9868c                         
02c98594: mov     x0, x20                                    
02c98598: bl      #0x2c97a58                                 NativeBannerControl::CreateReplacementAd
02c9859c: mov     x21, x19                                   
02c985a0: mov     x1, x0                                     
02c985a4: str     x0, [x21, #0x28]!                          .<replacementAd>5__2
02c985a8: mov     x0, x21                                    
02c985ac: bl      #0x2b70d54                                 fn_2b70d54
02c985b0: ldr     x8, [x21]                                  
02c985b4: cbz     x8, #0x2c9868c                             
02c985b8: str     wzr, [x19, #0x30]                          .<elapsed>5__3
02c985bc: strb    wzr, [x19, #0x34]                          .<ready>5__4
02c985c0: b       #0x2c985dc                                 
02c985c4: fmov    s0, #10.00000000                           
02c985c8: ldr     s1, [x19, #0x30]                           .<elapsed>5__3
02c985cc: mov     w8, #-1                                    
02c985d0: str     w8, [x19, #0x10]                           .<>1__state
02c985d4: fcmp    s1, s0                                     
02c985d8: b.pl    #0x2c985f8                                 
02c985dc: ldr     x0, [x19, #0x28]                           .<replacementAd>5__2
02c985e0: cbz     x0, #0x2c986fc                             
02c985e4: bl      #0x2c94644                                 FsnBannerAd::IsBannerAdReady
02c985e8: tbz     w0, #0, #0x2c9862c                         
02c985ec: mov     w8, #1                                     
02c985f0: strb    w8, [x19, #0x34]                           .<ready>5__4
02c985f4: b       #0x2c98600                                 
02c985f8: ldrb    w8, [x19, #0x34]                           .<ready>5__4
02c985fc: cbz     w8, #0x2c9867c                             
02c98600: cbz     x20, #0x2c986fc                            
02c98604: mov     x21, x19                                   
02c98608: ldrb    w2, [x20, #0x50]                           
02c9860c: mov     x0, x20                                    
02c98610: ldr     x1, [x21, #0x28]!                          .<replacementAd>5__2
02c98614: bl      #0x2c97b44                                 NativeBannerControl::TrySwapBanner
02c98618: mov     x0, x21                                    
02c9861c: mov     x1, xzr                                    
02c98620: str     xzr, [x21]                                 
02c98624: bl      #0x2b70d54                                 fn_2b70d54
02c98628: b       #0x2c9868c                                 
02c9862c: fmov    s0, #0.25000000                            
02c98630: ldr     s1, [x19, #0x30]                           .<elapsed>5__3
02c98634: adrp    x8, #0x6264000                             
02c98638: ldr     x8, [x8, #0xf58]                           T:UnityEngine.WaitForSeconds
02c9863c: fadd    s0, s1, s0                                 
02c98640: ldr     x0, [x8]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c98644: str     s0, [x19, #0x30]                           .<elapsed>5__3
02c98648: bl      #0x2b7104c                                 fn_2b7104c
02c9864c: fmov    s0, #0.25000000                            
02c98650: mov     x1, xzr                                    
02c98654: mov     x20, x0                                    
02c98658: bl      #0x5b3e5e8                                 UnityEngine.WaitForSeconds::.ctor
02c9865c: str     x20, [x19, #0x18]!                         .<>2__current
02c98660: mov     x0, x19                                    
02c98664: mov     x1, x20                                    
02c98668: bl      #0x2b70d54                                 fn_2b70d54
02c9866c: mov     w8, #2                                     
02c98670: mov     w0, #1                                     
02c98674: stur    w8, [x19, #-8]                             
02c98678: b       #0x2c986ec                                 
02c9867c: ldr     x0, [x19, #0x28]                           .<replacementAd>5__2
02c98680: cbz     x0, #0x2c986fc                             
02c98684: bl      #0x2c9480c                                 FsnBannerAd::Release
02c98688: cbz     x20, #0x2c986fc                            
02c9868c: bl      #0x2c97044                                 NativeBannerControl::get_IsEnabled
02c98690: tbz     w0, #0, #0x2c986d8                         
02c98694: bl      #0x2c970cc                                 NativeBannerControl::get_RefreshInterval
02c98698: adrp    x8, #0x6264000                             
02c9869c: fmov    s8, s0                                     
02c986a0: ldr     x8, [x8, #0xf58]                           T:UnityEngine.WaitForSeconds
02c986a4: ldr     x0, [x8]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c986a8: bl      #0x2b7104c                                 fn_2b7104c
02c986ac: fmov    s0, s8                                     
02c986b0: mov     x1, xzr                                    
02c986b4: mov     x20, x0                                    
02c986b8: bl      #0x5b3e5e8                                 UnityEngine.WaitForSeconds::.ctor
02c986bc: str     x20, [x19, #0x18]!                         .<>2__current
02c986c0: mov     x0, x19                                    
02c986c4: mov     x1, x20                                    
02c986c8: bl      #0x2b70d54                                 fn_2b70d54
02c986cc: mov     w0, #1                                     
02c986d0: stur    w0, [x19, #-8]                             
02c986d4: b       #0x2c986ec                                 
02c986d8: str     xzr, [x20, #0x48]!                         
02c986dc: mov     x0, x20                                    
02c986e0: mov     x1, xzr                                    
02c986e4: bl      #0x2b70d54                                 fn_2b70d54
02c986e8: mov     w0, wzr                                    
02c986ec: ldp     x20, x19, [sp, #0x20]                      
02c986f0: ldp     x30, x21, [sp, #0x10]                      
02c986f4: ldr     d8, [sp], #0x30                            
02c986f8: ret                                                
02c986fc: bl      #0x2b7105c                                 fn_2b7105c
## System.Collections.Generic.IEnumerator<System.Object>.get_Current() -> object
---- NativeBannerControl/<RefreshAdCoroutine>d__27::System.Collections.Generic.IEnumerator<System.Object>.get_Current 0x2c98700
02c98700: ldr     x0, [x0, #0x18]                            .<>2__current
02c98704: ret                                                
## System.Collections.IEnumerator.Reset() -> void
---- NativeBannerControl/<RefreshAdCoroutine>d__27::System.Collections.IEnumerator.Reset 0x2c98708
02c98708: stp     x30, x19, [sp, #-0x10]!                    
02c9870c: adrp    x0, #0x6264000                             
02c98710: ldr     x0, [x0, #0xf60]                           T:System.NotSupportedException
02c98714: bl      #0x2b70dc4                                 fn_2b70dc4
02c98718: bl      #0x2b7104c                                 fn_2b7104c
02c9871c: mov     x1, xzr                                    
02c98720: mov     x19, x0                                    
02c98724: bl      #0x4e14238                                 System.NotSupportedException::.ctor
02c98728: adrp    x0, #0x6265000                             
02c9872c: ldr     x0, [x0, #0x938]                           M:NativeBannerControl/<RefreshAdCoroutine>d__27::System.Collections.IEnumerator.Reset
02c98730: bl      #0x2b70dc4                                 fn_2b70dc4
02c98734: mov     x1, x0                                     
02c98738: mov     x0, x19                                    
02c9873c: bl      #0x2b70f20                                 fn_2b70f20
## System.Collections.IEnumerator.get_Current() -> object
---- NativeBannerControl/<RefreshAdCoroutine>d__27::System.Collections.IEnumerator.get_Current 0x2c98740
02c98740: ldr     x0, [x0, #0x18]                            .<>2__current
02c98744: ret                                                
#### CLASS NativeBannerControl/<ReloadCoroutine>d__30 parent= object
#   field <>1__state                     int                                                off=0x10 attr=1 
#   field <>2__current                   object                                             off=0x18 attr=1 
#   field <>4__this                      NativeBannerControl                                off=0x20 attr=6 
## .ctor(int <>1__state) -> void
---- NativeBannerControl/<ReloadCoroutine>d__30::.ctor 0x2c97d2c
02c97d2c: str     x30, [sp, #-0x20]!                         
02c97d30: stp     x20, x19, [sp, #0x10]                      
02c97d34: mov     w19, w1                                    
02c97d38: mov     x1, xzr                                    
02c97d3c: mov     x20, x0                                    
02c97d40: bl      #0x4e53e9c                                 System.Object::.ctor
02c97d44: str     w19, [x20, #0x10]                          .<>1__state
02c97d48: ldp     x20, x19, [sp, #0x10]                      
02c97d4c: ldr     x30, [sp], #0x20                           
02c97d50: ret                                                
## System.IDisposable.Dispose() -> void
---- NativeBannerControl/<ReloadCoroutine>d__30::System.IDisposable.Dispose 0x2c98748
02c98748: ret                                                
## MoveNext() -> bool
---- NativeBannerControl/<ReloadCoroutine>d__30::MoveNext 0x2c9874c
02c9874c: sub     sp, sp, #0x50                              
02c98750: str     d8, [sp, #0x10]                            
02c98754: stp     x30, x23, [sp, #0x20]                      
02c98758: stp     x22, x21, [sp, #0x30]                      
02c9875c: stp     x20, x19, [sp, #0x40]                      
02c98760: adrp    x19, #0x662f000                            
02c98764: mov     x20, x0                                    
02c98768: ldrb    w8, [x19, #0xa1e]                          
02c9876c: tbnz    w8, #0, #0x2c987b4                         
02c98770: adrp    x0, #0x6263000                             
02c98774: ldr     x0, [x0, #0x928]                           T:UnityEngine.Debug
02c98778: bl      #0x2b70db0                                 fn_2b70db0
02c9877c: adrp    x0, #0x6264000                             
02c98780: ldr     x0, [x0, #0xf58]                           T:UnityEngine.WaitForSeconds
02c98784: bl      #0x2b70db0                                 fn_2b70db0
02c98788: adrp    x0, #0x6265000                             
02c9878c: ldr     x0, [x0, #0x940]                           S:'[NativeBannerControl] ReloadCoroutine - Max retry attempts ({0}) reach'
02c98790: bl      #0x2b70db0                                 fn_2b70db0
02c98794: adrp    x0, #0x6265000                             
02c98798: ldr     x0, [x0, #0x948]                           S:'[NativeBannerControl] ReloadCoroutine - Waiting {0:F1}s before retry a'
02c9879c: bl      #0x2b70db0                                 fn_2b70db0
02c987a0: adrp    x0, #0x6265000                             
02c987a4: ldr     x0, [x0, #0x950]                           S:'[NativeBannerControl] ReloadCoroutine - Retrying ad load'
02c987a8: bl      #0x2b70db0                                 fn_2b70db0
02c987ac: mov     w8, #1                                     
02c987b0: strb    w8, [x19, #0xa1e]                          
02c987b4: ldr     w8, [x20, #0x10]                           .<>1__state
02c987b8: ldr     x19, [x20, #0x20]                          .<>4__this
02c987bc: cmp     w8, #1                                     
02c987c0: b.eq    #0x2c988c8                                 
02c987c4: cbnz    w8, #0x2c989b8                             
02c987c8: mov     w8, #-1                                    
02c987cc: str     w8, [x20, #0x10]                           .<>1__state
02c987d0: cbz     x19, #0x2c989d4                            
02c987d4: ldp     w0, w8, [x19, #0x38]                       
02c987d8: cmp     w0, w8                                     
02c987dc: b.ge    #0x2c98948                                 
02c987e0: fmov    s0, #1.00000000                            
02c987e4: bl      #0x5e902b0                                 fn_5e902b0
02c987e8: fmov    s1, #6.00000000                            
02c987ec: adrp    x23, #0x6263000                            
02c987f0: add     x1, sp, #0x1c                              
02c987f4: ldr     x23, [x23, #0x970]                         &6645c70(=0)
02c987f8: fmul    s8, s0, s1                                 
02c987fc: ldr     x0, [x23, #0x78]                           &2c498b4(=d65f03c0d503245f)
02c98800: str     s8, [sp, #0x1c]                            
02c98804: bl      #0x2b70f38                                 fn_2b70f38
02c98808: ldr     w8, [x19, #0x38]                           [662f038]=6000016 f=2.40742e-35,0
02c9880c: mov     x21, x0                                    
02c98810: ldr     x0, [x23, #0x48]                           &6263098(=0)
02c98814: add     x1, sp, #0x18                              
02c98818: add     w8, w8, #1                                 
02c9881c: str     w8, [sp, #0x18]                            
02c98820: bl      #0x2b70f38                                 fn_2b70f38
02c98824: mov     x22, x0                                    
02c98828: ldr     w8, [x19, #0x3c]                           [662f03c]=0 f=0,0
02c9882c: ldr     x0, [x23, #0x48]                           &6263098(=0)
02c98830: add     x1, sp, #0xc                               
02c98834: str     w8, [sp, #0xc]                             
02c98838: bl      #0x2b70f38                                 fn_2b70f38
02c9883c: adrp    x8, #0x6265000                             
02c98840: mov     x3, x0                                     
02c98844: mov     x1, x21                                    
02c98848: ldr     x8, [x8, #0x948]                           S:'[NativeBannerControl] ReloadCoroutine - Waiting {0:F1}s before retry a'
02c9884c: mov     x2, x22                                    
02c98850: mov     x4, xzr                                    
02c98854: ldr     x8, [x8]                                   M:AdsManager::<OnApplicationPause>b__26_0
02c98858: mov     x0, x8                                     
02c9885c: bl      #0x4ca7764                                 System.String::Format
02c98860: adrp    x8, #0x6263000                             
02c98864: mov     x19, x0                                    
02c98868: ldr     x8, [x8, #0x928]                           T:UnityEngine.Debug
02c9886c: ldr     x8, [x8]                                   &2c5bbd4(=a9bd7bfdd503233f)
02c98870: ldr     w9, [x8, #0xe4]                            [62630e4]=0 f=0,0
02c98874: cbnz    w9, #0x2c98880                             
02c98878: mov     x0, x8                                     
02c9887c: bl      #0x2b70f30                                 fn_2b70f30
02c98880: mov     x0, x19                                    
02c98884: mov     x1, xzr                                    
02c98888: bl      #0x5af21f4                                 UnityEngine.Debug::Log
02c9888c: adrp    x8, #0x6264000                             
02c98890: ldr     x8, [x8, #0xf58]                           T:UnityEngine.WaitForSeconds
02c98894: ldr     x0, [x8]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c98898: bl      #0x2b7104c                                 fn_2b7104c
02c9889c: fmov    s0, s8                                     
02c988a0: mov     x1, xzr                                    
02c988a4: mov     x19, x0                                    
02c988a8: bl      #0x5b3e5e8                                 UnityEngine.WaitForSeconds::.ctor
02c988ac: str     x19, [x20, #0x18]!                         .<>2__current
02c988b0: mov     x0, x20                                    
02c988b4: mov     x1, x19                                    
02c988b8: bl      #0x2b70d54                                 fn_2b70d54
02c988bc: mov     w0, #1                                     
02c988c0: stur    w0, [x20, #-8]                             
02c988c4: b       #0x2c989bc                                 
02c988c8: mov     w8, #-1                                    
02c988cc: str     w8, [x20, #0x10]                           .<>1__state
02c988d0: cbz     x19, #0x2c989d4                            
02c988d4: mov     x20, x19                                   
02c988d8: mov     x1, xzr                                    
02c988dc: str     xzr, [x20, #0x40]!                         
02c988e0: mov     x0, x20                                    
02c988e4: bl      #0x2b70d54                                 fn_2b70d54
02c988e8: ldur    w8, [x20, #-8]                             
02c988ec: add     w8, w8, #1                                 
02c988f0: stur    w8, [x20, #-8]                             
02c988f4: bl      #0x2c97044                                 NativeBannerControl::get_IsEnabled
02c988f8: tbz     w0, #0, #0x2c989b8                         
02c988fc: ldr     x0, [x19, #0x20]                           &2b706f0(=d65f03c0f9400800) .<>4__this
02c98900: cbz     x0, #0x2c9890c                             
02c98904: bl      #0x2c94644                                 FsnBannerAd::IsBannerAdReady
02c98908: tbnz    w0, #0, #0x2c989b8                         
02c9890c: adrp    x8, #0x6263000                             
02c98910: ldr     x8, [x8, #0x928]                           T:UnityEngine.Debug
02c98914: ldr     x0, [x8]                                   &2c5bbd4(=a9bd7bfdd503233f)
02c98918: ldr     w8, [x0, #0xe4]                            [62650e4]=0 f=0,0
02c9891c: cbnz    w8, #0x2c98924                             
02c98920: bl      #0x2b70f30                                 fn_2b70f30
02c98924: adrp    x8, #0x6265000                             
02c98928: mov     x1, xzr                                    
02c9892c: ldr     x8, [x8, #0x950]                           S:'[NativeBannerControl] ReloadCoroutine - Retrying ad load'
02c98930: ldr     x0, [x8]                                   M:AdsManager::<OnApplicationPause>b__26_0
02c98934: bl      #0x5af21f4                                 UnityEngine.Debug::Log
02c98938: ldr     x1, [x19, #0x30]                           &2b706f8(=d65f03c0b9401800)
02c9893c: mov     x0, x19                                    
02c98940: bl      #0x2c971bc                                 NativeBannerControl::LoadFsnBannerAd
02c98944: b       #0x2c989b8                                 
02c98948: adrp    x9, #0x6263000                             
02c9894c: add     x1, sp, #0x1c                              
02c98950: ldr     x9, [x9, #0x970]                           &6645c70(=0)
02c98954: str     w8, [sp, #0x1c]                            
02c98958: ldr     x0, [x9, #0x48]                            &6263098(=0)
02c9895c: bl      #0x2b70f38                                 fn_2b70f38
02c98960: adrp    x8, #0x6265000                             
02c98964: mov     x1, x0                                     
02c98968: mov     x2, xzr                                    
02c9896c: ldr     x8, [x8, #0x940]                           S:'[NativeBannerControl] ReloadCoroutine - Max retry attempts ({0}) reach'
02c98970: ldr     x8, [x8]                                   M:AdsManager::<OnApplicationPause>b__26_0
02c98974: mov     x0, x8                                     
02c98978: bl      #0x4c9d0ec                                 System.String::Format
02c9897c: adrp    x8, #0x6263000                             
02c98980: mov     x20, x0                                    
02c98984: ldr     x8, [x8, #0x928]                           T:UnityEngine.Debug
02c98988: ldr     x8, [x8]                                   &2c5bbd4(=a9bd7bfdd503233f)
02c9898c: ldr     w9, [x8, #0xe4]                            [62630e4]=0 f=0,0
02c98990: cbnz    w9, #0x2c9899c                             
02c98994: mov     x0, x8                                     
02c98998: bl      #0x2b70f30                                 fn_2b70f30
02c9899c: mov     x0, x20                                    
02c989a0: mov     x1, xzr                                    
02c989a4: bl      #0x5af2840                                 UnityEngine.Debug::LogError
02c989a8: str     xzr, [x19, #0x40]!                         
02c989ac: mov     x0, x19                                    
02c989b0: mov     x1, xzr                                    
02c989b4: bl      #0x2b70d54                                 fn_2b70d54
02c989b8: mov     w0, wzr                                    
02c989bc: ldp     x20, x19, [sp, #0x40]                      
02c989c0: ldr     d8, [sp, #0x10]                            
02c989c4: ldp     x22, x21, [sp, #0x30]                      
02c989c8: ldp     x30, x23, [sp, #0x20]                      
02c989cc: add     sp, sp, #0x50                              
02c989d0: ret                                                
02c989d4: bl      #0x2b7105c                                 fn_2b7105c
## System.Collections.Generic.IEnumerator<System.Object>.get_Current() -> object
---- NativeBannerControl/<ReloadCoroutine>d__30::System.Collections.Generic.IEnumerator<System.Object>.get_Current 0x2c989d8
02c989d8: ldr     x0, [x0, #0x18]                            .<>2__current
02c989dc: ret                                                
## System.Collections.IEnumerator.Reset() -> void
---- NativeBannerControl/<ReloadCoroutine>d__30::System.Collections.IEnumerator.Reset 0x2c989e0
02c989e0: stp     x30, x19, [sp, #-0x10]!                    
02c989e4: adrp    x0, #0x6264000                             
02c989e8: ldr     x0, [x0, #0xf60]                           T:System.NotSupportedException
02c989ec: bl      #0x2b70dc4                                 fn_2b70dc4
02c989f0: bl      #0x2b7104c                                 fn_2b7104c
02c989f4: mov     x1, xzr                                    
02c989f8: mov     x19, x0                                    
02c989fc: bl      #0x4e14238                                 System.NotSupportedException::.ctor
02c98a00: adrp    x0, #0x6265000                             
02c98a04: ldr     x0, [x0, #0x958]                           M:NativeBannerControl/<ReloadCoroutine>d__30::System.Collections.IEnumerator.Reset
02c98a08: bl      #0x2b70dc4                                 fn_2b70dc4
02c98a0c: mov     x1, x0                                     
02c98a10: mov     x0, x19                                    
02c98a14: bl      #0x2b70f20                                 fn_2b70f20
## System.Collections.IEnumerator.get_Current() -> object
---- NativeBannerControl/<ReloadCoroutine>d__30::System.Collections.IEnumerator.get_Current 0x2c98a18
02c98a18: ldr     x0, [x0, #0x18]                            .<>2__current
02c98a1c: ret                                                
#### CLASS NativeBannerControl parent= UnityEngine.MonoBehaviour
#   field _primaryAd                     FsnBannerAd                                        off=0x20 attr=1 
#   field _logTag                        string                                             off=0x28 attr=1 
#   field _adID                          string                                             off=0x30 attr=1 
#   field _retryAttempt                  int                                                off=0x38 attr=1 
#   field _maxRetryAttempts              int                                                off=0x3c attr=21 
#   field _reloadCoroutine               UnityEngine.Coroutine                              off=0x40 attr=1 
#   field _refreshCoroutine              UnityEngine.Coroutine                              off=0x48 attr=1 
#   field _isShowingBanner               bool                                               off=0x50 attr=1 
#   field _showToken                     int                                                off=0x54 attr=1 
## get_IsEnabled() -> bool
---- NativeBannerControl::get_IsEnabled 0x2c97044
02c97044: str     x30, [sp, #-0x20]!                         
02c97048: stp     x20, x19, [sp, #0x10]                      
02c9704c: adrp    x20, #0x662f000                            
02c97050: adrp    x19, #0x6264000                            
02c97054: ldrb    w8, [x20, #0xa0b]                          
02c97058: ldr     x19, [x19, #0xfc0]                         T:RemoteConfigManager
02c9705c: tbnz    w8, #0, #0x2c97074                         
02c97060: adrp    x0, #0x6264000                             
02c97064: ldr     x0, [x0, #0xfc0]                           T:RemoteConfigManager
02c97068: bl      #0x2b70db0                                 fn_2b70db0
02c9706c: mov     w8, #1                                     
02c97070: strb    w8, [x20, #0xa0b]                          
02c97074: ldr     x0, [x19]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c97078: ldr     w8, [x0, #0xe4]                            [62640e4]=0 f=0,0
02c9707c: cbnz    w8, #0x2c97084                             
02c97080: bl      #0x2b70f30                                 fn_2b70f30
02c97084: adrp    x20, #0x662f000                            
02c97088: ldrb    w8, [x20, #0xa86]                          
02c9708c: cbnz    w8, #0x2c970a4                             
02c97090: adrp    x0, #0x6264000                             
02c97094: ldr     x0, [x0, #0xfc0]                           T:RemoteConfigManager
02c97098: bl      #0x2b70db0                                 fn_2b70db0
02c9709c: mov     w8, #1                                     
02c970a0: strb    w8, [x20, #0xa86]                          
02c970a4: ldr     x0, [x19]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c970a8: ldr     w8, [x0, #0xe4]                            [62640e4]=0 f=0,0
02c970ac: cbnz    w8, #0x2c970b8                             
02c970b0: bl      #0x2b70f30                                 fn_2b70f30
02c970b4: ldr     x0, [x19]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c970b8: ldr     x8, [x0, #0xb8]                            MS:DG.Tweening.Core.Extensions::SetSpecialStartupMode
02c970bc: ldp     x20, x19, [sp, #0x10]                      
02c970c0: ldrb    w0, [x8, #0x39]                            
02c970c4: ldr     x30, [sp], #0x20                           
02c970c8: ret                                                
## get_RefreshInterval() -> float
---- NativeBannerControl::get_RefreshInterval 0x2c970cc
02c970cc: str     x30, [sp, #-0x20]!                         
02c970d0: stp     x20, x19, [sp, #0x10]                      
02c970d4: adrp    x20, #0x662f000                            
02c970d8: adrp    x19, #0x6264000                            
02c970dc: ldrb    w8, [x20, #0xa0c]                          
02c970e0: ldr     x19, [x19, #0xfc0]                         T:RemoteConfigManager
02c970e4: tbnz    w8, #0, #0x2c970fc                         
02c970e8: adrp    x0, #0x6264000                             
02c970ec: ldr     x0, [x0, #0xfc0]                           T:RemoteConfigManager
02c970f0: bl      #0x2b70db0                                 fn_2b70db0
02c970f4: mov     w8, #1                                     
02c970f8: strb    w8, [x20, #0xa0c]                          
02c970fc: ldr     x0, [x19]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c97100: ldr     w8, [x0, #0xe4]                            [62640e4]=0 f=0,0
02c97104: cbnz    w8, #0x2c9710c                             
02c97108: bl      #0x2b70f30                                 fn_2b70f30
02c9710c: adrp    x20, #0x662f000                            
02c97110: ldrb    w8, [x20, #0xa87]                          
02c97114: cbnz    w8, #0x2c9712c                             
02c97118: adrp    x0, #0x6264000                             
02c9711c: ldr     x0, [x0, #0xfc0]                           T:RemoteConfigManager
02c97120: bl      #0x2b70db0                                 fn_2b70db0
02c97124: mov     w8, #1                                     
02c97128: strb    w8, [x20, #0xa87]                          
02c9712c: ldr     x0, [x19]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c97130: ldr     w8, [x0, #0xe4]                            [62640e4]=0 f=0,0
02c97134: cbnz    w8, #0x2c97140                             
02c97138: bl      #0x2b70f30                                 fn_2b70f30
02c9713c: ldr     x0, [x19]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c97140: ldr     x8, [x0, #0xb8]                            MS:DG.Tweening.Core.Extensions::SetSpecialStartupMode
02c97144: ldp     x20, x19, [sp, #0x10]                      
02c97148: ldr     s0, [x8, #0x3c]                            
02c9714c: scvtf   s0, s0                                     
02c97150: ldr     x30, [sp], #0x20                           
02c97154: ret                                                
## get_IsReady() -> bool
---- NativeBannerControl::get_IsReady 0x2c97158
02c97158: ldr     x0, [x0, #0x20]                            ._primaryAd
02c9715c: cbz     x0, #0x2c97164                             
02c97160: b       #0x2c94644                                 FsnBannerAd::IsBannerAdReady
02c97164: ret                                                
## get_HasUsableBanner() -> bool
---- NativeBannerControl::get_HasUsableBanner 0x2c97168
02c97168: ldr     x0, [x0, #0x20]                            ._primaryAd
02c9716c: cbz     x0, #0x2c97174                             
02c97170: b       #0x2c94644                                 FsnBannerAd::IsBannerAdReady
02c97174: ret                                                
## LoadAd(string adID, string logTag) -> void
---- NativeBannerControl::LoadAd 0x2c92498
02c92498: str     x30, [sp, #-0x50]!                         
02c9249c: stp     x26, x25, [sp, #0x10]                      
02c924a0: stp     x24, x23, [sp, #0x20]                      
02c924a4: stp     x22, x21, [sp, #0x30]                      
02c924a8: stp     x20, x19, [sp, #0x40]                      
02c924ac: adrp    x22, #0x662f000                            
02c924b0: adrp    x23, #0x6265000                            
02c924b4: mov     x20, x2                                    
02c924b8: ldrb    w8, [x22, #0xa0d]                          
02c924bc: ldr     x23, [x23, #0x310]                         MS:WejoyService.Singleton`1::get_Instance
02c924c0: mov     x21, x1                                    
02c924c4: mov     x19, x0                                    
02c924c8: tbnz    w8, #0, #0x2c92510                         
02c924cc: adrp    x0, #0x6263000                             
02c924d0: ldr     x0, [x0, #0x928]                           T:UnityEngine.Debug
02c924d4: bl      #0x2b70db0                                 fn_2b70db0
02c924d8: adrp    x0, #0x6265000                             
02c924dc: ldr     x0, [x0, #0x488]                           T:KeyTest
02c924e0: bl      #0x2b70db0                                 fn_2b70db0
02c924e4: adrp    x0, #0x6265000                             
02c924e8: ldr     x0, [x0, #0x310]                           MS:WejoyService.Singleton`1::get_Instance
02c924ec: bl      #0x2b70db0                                 fn_2b70db0
02c924f0: adrp    x0, #0x6265000                             
02c924f4: ldr     x0, [x0, #0x6b8]                           S:'[NativeBannerControl] LoadAd called - AdID: '
02c924f8: bl      #0x2b70db0                                 fn_2b70db0
02c924fc: adrp    x0, #0x6265000                             
02c92500: ldr     x0, [x0, #0x6c0]                           S:', LogTag: '
02c92504: bl      #0x2b70db0                                 fn_2b70db0
02c92508: mov     w8, #1                                     
02c9250c: strb    w8, [x22, #0xa0d]                          
02c92510: mov     x22, x19                                   
02c92514: mov     x1, x21                                    
02c92518: str     x21, [x22, #0x30]!                         
02c9251c: mov     x0, x22                                    
02c92520: bl      #0x2b70d54                                 fn_2b70d54
02c92524: ldr     x0, [x23]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c92528: bl      #0x3be7218                                 fn_3be7218
02c9252c: cbz     x0, #0x2c925fc                             
02c92530: adrp    x24, #0x6265000                            
02c92534: adrp    x25, #0x6265000                            
02c92538: adrp    x23, #0x6263000                            
02c9253c: ldr     x24, [x24, #0x6b8]                         S:'[NativeBannerControl] LoadAd called - AdID: '
02c92540: ldr     x25, [x25, #0x6c0]                         S:', LogTag: '
02c92544: ldrb    w8, [x0, #0x31]                            
02c92548: ldr     x23, [x23, #0x928]                         T:UnityEngine.Debug
02c9254c: cbz     w8, #0x2c92580                             
02c92550: adrp    x26, #0x6265000                            
02c92554: ldr     x26, [x26, #0x488]                         T:KeyTest
02c92558: ldr     x0, [x26]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9255c: ldr     w8, [x0, #0xe4]                            [62650e4]=0 f=0,0
02c92560: cbnz    w8, #0x2c9256c                             
02c92564: bl      #0x2b70f30                                 fn_2b70f30
02c92568: ldr     x0, [x26]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9256c: ldr     x8, [x0, #0xb8]                            T:AdsManager/<>c__DisplayClass42_0
02c92570: mov     x0, x22                                    
02c92574: ldr     x1, [x8, #0x20]                            
02c92578: str     x1, [x22]                                  
02c9257c: bl      #0x2b70d54                                 fn_2b70d54
02c92580: mov     x22, x19                                   
02c92584: mov     x1, x20                                    
02c92588: str     x20, [x22, #0x28]!                         
02c9258c: mov     x0, x22                                    
02c92590: bl      #0x2b70d54                                 fn_2b70d54
02c92594: ldr     x0, [x24]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c92598: ldr     x2, [x25]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9259c: mov     x1, x21                                    
02c925a0: mov     x3, x20                                    
02c925a4: mov     x4, xzr                                    
02c925a8: str     wzr, [x22, #0x10]                          
02c925ac: bl      #0x4ca7320                                 System.String::Concat
02c925b0: ldr     x8, [x23]                                  &2c5bbd4(=a9bd7bfdd503233f)
02c925b4: mov     x20, x0                                    
02c925b8: ldr     w9, [x8, #0xe4]                            
02c925bc: cbnz    w9, #0x2c925c8                             
02c925c0: mov     x0, x8                                     
02c925c4: bl      #0x2b70f30                                 fn_2b70f30
02c925c8: mov     x0, x20                                    
02c925cc: mov     x1, xzr                                    
02c925d0: bl      #0x5af21f4                                 UnityEngine.Debug::Log
02c925d4: mov     x0, x19                                    
02c925d8: bl      #0x2c97178                                 NativeBannerControl::StopRefreshLoop
02c925dc: ldr     x1, [x19, #0x30]                           ._adID
02c925e0: mov     x0, x19                                    
02c925e4: ldp     x20, x19, [sp, #0x40]                      
02c925e8: ldp     x22, x21, [sp, #0x30]                      
02c925ec: ldp     x24, x23, [sp, #0x20]                      
02c925f0: ldp     x26, x25, [sp, #0x10]                      
02c925f4: ldr     x30, [sp], #0x50                           
02c925f8: b       #0x2c971bc                                 NativeBannerControl::LoadFsnBannerAd
02c925fc: bl      #0x2b7105c                                 fn_2b7105c
## LoadFsnBannerAd(string adID) -> void
---- NativeBannerControl::LoadFsnBannerAd 0x2c971bc
02c971bc: stp     x30, x23, [sp, #-0x30]!                    
02c971c0: stp     x22, x21, [sp, #0x10]                      
02c971c4: stp     x20, x19, [sp, #0x20]                      
02c971c8: adrp    x21, #0x662f000                            
02c971cc: mov     x19, x1                                    
02c971d0: mov     x20, x0                                    
02c971d4: ldrb    w8, [x21, #0xa0e]                          
02c971d8: tbnz    w8, #0, #0x2c97220                         
02c971dc: adrp    x0, #0x6263000                             
02c971e0: ldr     x0, [x0, #0x928]                           T:UnityEngine.Debug
02c971e4: bl      #0x2b70db0                                 fn_2b70db0
02c971e8: adrp    x0, #0x6265000                             
02c971ec: ldr     x0, [x0, #0x850]                           T:FsnBannerAd
02c971f0: bl      #0x2b70db0                                 fn_2b70db0
02c971f4: adrp    x0, #0x6265000                             
02c971f8: ldr     x0, [x0, #0x858]                           S:'[NativeBannerControl] LoadFsnBannerAd - Ad disabled, skipping load'
02c971fc: bl      #0x2b70db0                                 fn_2b70db0
02c97200: adrp    x0, #0x6265000                             
02c97204: ldr     x0, [x0, #0x860]                           S:'[NativeBannerControl] LoadFsnBannerAd - Load request sent for AdID: '
02c97208: bl      #0x2b70db0                                 fn_2b70db0
02c9720c: adrp    x0, #0x6265000                             
02c97210: ldr     x0, [x0, #0x868]                           S:'[NativeBannerControl] LoadFsnBannerAd - Starting load for AdID: '
02c97214: bl      #0x2b70db0                                 fn_2b70db0
02c97218: mov     w8, #1                                     
02c9721c: strb    w8, [x21, #0xa0e]                          
02c97220: adrp    x23, #0x6263000                            
02c97224: ldr     x23, [x23, #0x928]                         T:UnityEngine.Debug
02c97228: bl      #0x2c97044                                 NativeBannerControl::get_IsEnabled
02c9722c: tbz     w0, #0, #0x2c97324                         
02c97230: adrp    x8, #0x6265000                             
02c97234: mov     x1, x19                                    
02c97238: mov     x2, xzr                                    
02c9723c: ldr     x8, [x8, #0x868]                           S:'[NativeBannerControl] LoadFsnBannerAd - Starting load for AdID: '
02c97240: ldr     x0, [x8]                                   M:AdsManager::<OnApplicationPause>b__26_0
02c97244: bl      #0x4c9c514                                 System.String::Concat
02c97248: ldr     x8, [x23]                                  &2c5bbd4(=a9bd7bfdd503233f)
02c9724c: mov     x21, x0                                    
02c97250: ldr     w9, [x8, #0xe4]                            [62650e4]=0 f=0,0
02c97254: cbnz    w9, #0x2c97260                             
02c97258: mov     x0, x8                                     
02c9725c: bl      #0x2b70f30                                 fn_2b70f30
02c97260: adrp    x22, #0x6265000                            
02c97264: mov     x0, x21                                    
02c97268: mov     x1, xzr                                    
02c9726c: ldr     x22, [x22, #0x850]                         T:FsnBannerAd
02c97270: bl      #0x5af21f4                                 UnityEngine.Debug::Log
02c97274: mov     x0, x20                                    
02c97278: bl      #0x2c9735c                                 NativeBannerControl::StopReloadCoroutine
02c9727c: mov     x21, x20                                   
02c97280: ldr     x0, [x21, #0x20]!                          &2b706f0(=d65f03c0f9400800) ._primaryAd
02c97284: cbz     x0, #0x2c9728c                             
02c97288: bl      #0x2c9480c                                 FsnBannerAd::Release
02c9728c: mov     x0, x21                                    
02c97290: mov     x1, xzr                                    
02c97294: str     xzr, [x21]                                 
02c97298: bl      #0x2b70d54                                 fn_2b70d54
02c9729c: ldr     x0, [x22]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c972a0: bl      #0x2b7104c                                 fn_2b7104c
02c972a4: mov     x22, x0                                    
02c972a8: bl      #0x2c93c68                                 FsnBannerAd::.ctor
02c972ac: mov     x0, x21                                    
02c972b0: mov     x1, x22                                    
02c972b4: str     x22, [x21]                                 
02c972b8: bl      #0x2b70d54                                 fn_2b70d54
02c972bc: ldr     x0, [x21]                                  &2b706c4(=eb01011ff9400808)
02c972c0: cbz     x0, #0x2c97358                             
02c972c4: mov     x1, x19                                    
02c972c8: mov     w2, #1                                     
02c972cc: mov     w3, #1                                     
02c972d0: mov     w4, wzr                                    
02c972d4: bl      #0x2c93da8                                 FsnBannerAd::InitNativeBanner
02c972d8: ldr     x1, [x20, #0x20]                           ._primaryAd
02c972dc: mov     x0, x20                                    
02c972e0: bl      #0x2c973a0                                 NativeBannerControl::RegisterListener
02c972e4: ldr     x0, [x20, #0x20]                           ._primaryAd
02c972e8: cbz     x0, #0x2c97358                             
02c972ec: bl      #0x2c94124                                 FsnBannerAd::LoadBannerAd
02c972f0: adrp    x8, #0x6265000                             
02c972f4: mov     x1, x19                                    
02c972f8: mov     x2, xzr                                    
02c972fc: ldr     x8, [x8, #0x860]                           S:'[NativeBannerControl] LoadFsnBannerAd - Load request sent for AdID: '
02c97300: ldr     x0, [x8]                                   M:AdsManager::<OnApplicationPause>b__26_0
02c97304: bl      #0x4c9c514                                 System.String::Concat
02c97308: ldr     x8, [x23]                                  &2c5bbd4(=a9bd7bfdd503233f)
02c9730c: mov     x19, x0                                    
02c97310: ldr     w9, [x8, #0xe4]                            [62650e4]=0 f=0,0
02c97314: cbnz    w9, #0x2c97340                             
02c97318: mov     x0, x8                                     
02c9731c: bl      #0x2b70f30                                 fn_2b70f30
02c97320: b       #0x2c97340                                 
02c97324: ldr     x0, [x23]                                  &2c5bbd4(=a9bd7bfdd503233f)
02c97328: adrp    x19, #0x6265000                            
02c9732c: ldr     w8, [x0, #0xe4]                            [62650e4]=0 f=0,0
02c97330: ldr     x19, [x19, #0x858]                         S:'[NativeBannerControl] LoadFsnBannerAd - Ad disabled, skipping load'
02c97334: cbnz    w8, #0x2c9733c                             
02c97338: bl      #0x2b70f30                                 fn_2b70f30
02c9733c: ldr     x19, [x19]                                 M:AdsManager::<OnApplicationPause>b__26_0
02c97340: mov     x0, x19                                    
02c97344: ldp     x20, x19, [sp, #0x20]                      
02c97348: ldp     x22, x21, [sp, #0x10]                      
02c9734c: mov     x1, xzr                                    
02c97350: ldp     x30, x23, [sp], #0x30                      
02c97354: b       #0x5af21f4                                 UnityEngine.Debug::Log
02c97358: bl      #0x2b7105c                                 fn_2b7105c
## StopReloadCoroutine() -> void
---- NativeBannerControl::StopReloadCoroutine 0x2c9735c
02c9735c: str     x30, [sp, #-0x20]!                         
02c97360: stp     x20, x19, [sp, #0x10]                      
02c97364: mov     x20, x0                                    
02c97368: ldr     x1, [x20, #0x40]!                          ._reloadCoroutine
02c9736c: cbz     x1, #0x2c97394                             
02c97370: mov     x2, xzr                                    
02c97374: mov     x19, x0                                    
02c97378: bl      #0x5b38c4c                                 UnityEngine.MonoBehaviour::StopCoroutine
02c9737c: mov     x0, x20                                    
02c97380: str     xzr, [x19, #0x40]                          ._reloadCoroutine
02c97384: mov     x1, xzr                                    
02c97388: ldp     x20, x19, [sp, #0x10]                      
02c9738c: ldr     x30, [sp], #0x20                           
02c97390: b       #0x2b70d54                                 
02c97394: ldp     x20, x19, [sp, #0x10]                      
02c97398: ldr     x30, [sp], #0x20                           
02c9739c: ret                                                
## StopRefreshLoop() -> void
---- NativeBannerControl::StopRefreshLoop 0x2c97178
02c97178: str     x30, [sp, #-0x20]!                         
02c9717c: stp     x20, x19, [sp, #0x10]                      
02c97180: mov     x20, x0                                    
02c97184: ldr     x1, [x20, #0x48]!                          ._refreshCoroutine
02c97188: cbz     x1, #0x2c971b0                             
02c9718c: mov     x2, xzr                                    
02c97190: mov     x19, x0                                    
02c97194: bl      #0x5b38c4c                                 UnityEngine.MonoBehaviour::StopCoroutine
02c97198: mov     x0, x20                                    
02c9719c: str     xzr, [x19, #0x48]                          ._refreshCoroutine
02c971a0: mov     x1, xzr                                    
02c971a4: ldp     x20, x19, [sp, #0x10]                      
02c971a8: ldr     x30, [sp], #0x20                           
02c971ac: b       #0x2b70d54                                 
02c971b0: ldp     x20, x19, [sp, #0x10]                      
02c971b4: ldr     x30, [sp], #0x20                           
02c971b8: ret                                                
## RegisterListener(FsnBannerAd ad) -> void
---- NativeBannerControl::RegisterListener 0x2c973a0
02c973a0: str     x30, [sp, #-0x40]!                         
02c973a4: stp     x24, x23, [sp, #0x10]                      
02c973a8: stp     x22, x21, [sp, #0x20]                      
02c973ac: stp     x20, x19, [sp, #0x30]                      
02c973b0: adrp    x20, #0x662f000                            
02c973b4: mov     x19, x1                                    
02c973b8: mov     x21, x0                                    
02c973bc: ldrb    w8, [x20, #0xa0f]                          
02c973c0: tbnz    w8, #0, #0x2c97438                         
02c973c4: adrp    x0, #0x6265000                             
02c973c8: ldr     x0, [x0, #0x870]                           T:type7171(k15)
02c973cc: bl      #0x2b70db0                                 fn_2b70db0
02c973d0: adrp    x0, #0x6265000                             
02c973d4: ldr     x0, [x0, #0x878]                           T:type7291(k15)
02c973d8: bl      #0x2b70db0                                 fn_2b70db0
02c973dc: adrp    x0, #0x6264000                             
02c973e0: ldr     x0, [x0, #0xf90]                           T:System.Action
02c973e4: bl      #0x2b70db0                                 fn_2b70db0
02c973e8: adrp    x0, #0x6263000                             
02c973ec: ldr     x0, [x0, #0x928]                           T:UnityEngine.Debug
02c973f0: bl      #0x2b70db0                                 fn_2b70db0
02c973f4: adrp    x0, #0x6265000                             
02c973f8: ldr     x0, [x0, #0x880]                           M:NativeBannerControl::<RegisterListener>b__21_0
02c973fc: bl      #0x2b70db0                                 fn_2b70db0
02c97400: adrp    x0, #0x6265000                             
02c97404: ldr     x0, [x0, #0x888]                           M:NativeBannerControl/<>c::<RegisterListener>b__21_1
02c97408: bl      #0x2b70db0                                 fn_2b70db0
02c9740c: adrp    x0, #0x6265000                             
02c97410: ldr     x0, [x0, #0x890]                           M:NativeBannerControl/<>c::<RegisterListener>b__21_2
02c97414: bl      #0x2b70db0                                 fn_2b70db0
02c97418: adrp    x0, #0x6265000                             
02c9741c: ldr     x0, [x0, #0x898]                           T:NativeBannerControl/<>c
02c97420: bl      #0x2b70db0                                 fn_2b70db0
02c97424: adrp    x0, #0x6265000                             
02c97428: ldr     x0, [x0, #0x8a0]                           S:'[NativeBannerControl] Registering listener for banner ad'
02c9742c: bl      #0x2b70db0                                 fn_2b70db0
02c97430: mov     w8, #1                                     
02c97434: strb    w8, [x20, #0xa0f]                          
02c97438: cbz     x19, #0x2c975b0                            
02c9743c: adrp    x8, #0x6263000                             
02c97440: adrp    x23, #0x6265000                            
02c97444: adrp    x22, #0x6265000                            
02c97448: ldr     x8, [x8, #0x928]                           T:UnityEngine.Debug
02c9744c: ldr     x23, [x23, #0x8a0]                         S:'[NativeBannerControl] Registering listener for banner ad'
02c97450: adrp    x20, #0x6265000                            
02c97454: adrp    x24, #0x6265000                            
02c97458: ldr     x0, [x8]                                   &2c5bbd4(=a9bd7bfdd503233f)
02c9745c: ldr     x22, [x22, #0x870]                         T:type7171(k15)
02c97460: ldr     x20, [x20, #0x880]                         M:NativeBannerControl::<RegisterListener>b__21_0
02c97464: ldr     w8, [x0, #0xe4]                            [62650e4]=0 f=0,0
02c97468: ldr     x24, [x24, #0x898]                         T:NativeBannerControl/<>c
02c9746c: cbnz    w8, #0x2c97474                             
02c97470: bl      #0x2b70f30                                 fn_2b70f30
02c97474: ldr     x0, [x23]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c97478: mov     x1, xzr                                    
02c9747c: bl      #0x5af21f4                                 UnityEngine.Debug::Log
02c97480: ldr     x0, [x22]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c97484: bl      #0x2b7104c                                 fn_2b7104c
02c97488: ldr     x2, [x20]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9748c: mov     x1, x21                                    
02c97490: mov     x3, xzr                                    
02c97494: mov     x20, x0                                    
02c97498: bl      #0x453c1e0                                 fn_453c1e0
02c9749c: ldr     x0, [x24]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c974a0: ldr     w8, [x0, #0xe4]                            [62650e4]=0 f=0,0
02c974a4: cbnz    w8, #0x2c974b0                             
02c974a8: bl      #0x2b70f30                                 fn_2b70f30
02c974ac: ldr     x0, [x24]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c974b0: ldr     x8, [x0, #0xb8]                            T:AdsManager/<>c__DisplayClass42_0
02c974b4: ldr     x21, [x8, #8]                              &2c498b4(=d65f03c0d503245f)
02c974b8: cbnz    x21, #0x2c97518                            
02c974bc: ldr     w9, [x0, #0xe4]                            [62650e4]=0 f=0,0
02c974c0: cbnz    w9, #0x2c974d0                             
02c974c4: bl      #0x2b70f30                                 fn_2b70f30
02c974c8: ldr     x8, [x24]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c974cc: ldr     x8, [x8, #0xb8]                            &6263108(=0)
02c974d0: adrp    x9, #0x6264000                             
02c974d4: ldr     x9, [x9, #0xf90]                           T:System.Action
02c974d8: ldr     x22, [x8]                                  &2c5bbd4(=a9bd7bfdd503233f)
02c974dc: ldr     x0, [x9]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c974e0: bl      #0x2b7104c                                 fn_2b7104c
02c974e4: adrp    x8, #0x6265000                             
02c974e8: mov     x1, x22                                    
02c974ec: mov     x3, xzr                                    
02c974f0: ldr     x8, [x8, #0x888]                           M:NativeBannerControl/<>c::<RegisterListener>b__21_1
02c974f4: mov     x21, x0                                    
02c974f8: ldr     x2, [x8]                                   M:AdsManager::<OnApplicationPause>b__26_0
02c974fc: bl      #0x4d8ddbc                                 System.Action::.ctor
02c97500: ldr     x8, [x24]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c97504: mov     x1, x21                                    
02c97508: ldr     x0, [x8, #0xb8]                            T:AdsManager/<>c__DisplayClass42_0
02c9750c: str     x21, [x0, #8]!                             
02c97510: bl      #0x2b70d54                                 fn_2b70d54
02c97514: ldr     x0, [x24]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c97518: ldr     w8, [x0, #0xe4]                            [62650e4]=0 f=0,0
02c9751c: cbnz    w8, #0x2c97528                             
02c97520: bl      #0x2b70f30                                 fn_2b70f30
02c97524: ldr     x0, [x24]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c97528: ldr     x8, [x0, #0xb8]                            T:AdsManager/<>c__DisplayClass42_0
02c9752c: ldr     x22, [x8, #0x10]                           MS:MonoSingleton`1::get_Instance
02c97530: cbnz    x22, #0x2c9758c                            
02c97534: ldr     w9, [x0, #0xe4]                            [62650e4]=0 f=0,0
02c97538: cbnz    w9, #0x2c97548                             
02c9753c: bl      #0x2b70f30                                 fn_2b70f30
02c97540: ldr     x8, [x24]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c97544: ldr     x8, [x8, #0xb8]                            T:AdsManager/<>c__DisplayClass42_0
02c97548: adrp    x9, #0x6265000                             
02c9754c: ldr     x9, [x9, #0x878]                           T:type7291(k15)
02c97550: ldr     x23, [x8]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c97554: ldr     x0, [x9]                                   M:AdsManager::<OnApplicationPause>b__26_0
02c97558: bl      #0x2b7104c                                 fn_2b7104c
02c9755c: adrp    x8, #0x6265000                             
02c97560: mov     x1, x23                                    
02c97564: mov     x3, xzr                                    
02c97568: ldr     x8, [x8, #0x890]                           M:NativeBannerControl/<>c::<RegisterListener>b__21_2
02c9756c: mov     x22, x0                                    
02c97570: ldr     x2, [x8]                                   M:AdsManager::<OnApplicationPause>b__26_0
02c97574: bl      #0x453ea7c                                 fn_453ea7c
02c97578: ldr     x8, [x24]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9757c: mov     x1, x22                                    
02c97580: ldr     x0, [x8, #0xb8]                            T:AdsManager/<>c__DisplayClass42_0
02c97584: str     x22, [x0, #0x10]!                          
02c97588: bl      #0x2b70d54                                 fn_2b70d54
02c9758c: mov     x0, x19                                    
02c97590: mov     x1, x20                                    
02c97594: mov     x2, x21                                    
02c97598: mov     x3, x22                                    
02c9759c: ldp     x20, x19, [sp, #0x30]                      
02c975a0: ldp     x22, x21, [sp, #0x20]                      
02c975a4: ldp     x24, x23, [sp, #0x10]                      
02c975a8: ldr     x30, [sp], #0x40                           
02c975ac: b       #0x2c93fb8                                 FsnBannerAd::SetBannerNativeListener
02c975b0: ldp     x20, x19, [sp, #0x30]                      
02c975b4: ldp     x22, x21, [sp, #0x20]                      
02c975b8: ldp     x24, x23, [sp, #0x10]                      
02c975bc: ldr     x30, [sp], #0x40                           
02c975c0: ret                                                
## ShowAd() -> void
---- NativeBannerControl::ShowAd 0x2c91ee0
02c91ee0: str     x30, [sp, #-0x20]!                         
02c91ee4: stp     x20, x19, [sp, #0x10]                      
02c91ee8: adrp    x20, #0x662f000                            
02c91eec: mov     x19, x0                                    
02c91ef0: ldrb    w8, [x20, #0xa10]                          
02c91ef4: tbnz    w8, #0, #0x2c91f3c                         
02c91ef8: adrp    x0, #0x6263000                             
02c91efc: ldr     x0, [x0, #0x928]                           T:UnityEngine.Debug
02c91f00: bl      #0x2b70db0                                 fn_2b70db0
02c91f04: adrp    x0, #0x6265000                             
02c91f08: ldr     x0, [x0, #0x678]                           S:'[NativeBannerControl] ShowAd - Showing banner'
02c91f0c: bl      #0x2b70db0                                 fn_2b70db0
02c91f10: adrp    x0, #0x6265000                             
02c91f14: ldr     x0, [x0, #0x680]                           S:'[NativeBannerControl] ShowAd - Ad not ready, cannot show'
02c91f18: bl      #0x2b70db0                                 fn_2b70db0
02c91f1c: adrp    x0, #0x6265000                             
02c91f20: ldr     x0, [x0, #0x688]                           S:'[NativeBannerControl] ShowAd - Ad disabled, skipping show'
02c91f24: bl      #0x2b70db0                                 fn_2b70db0
02c91f28: adrp    x0, #0x6265000                             
02c91f2c: ldr     x0, [x0, #0x690]                           S:'[NativeBannerControl] ShowAd - Banner already showing'
02c91f30: bl      #0x2b70db0                                 fn_2b70db0
02c91f34: mov     w8, #1                                     
02c91f38: strb    w8, [x20, #0xa10]                          
02c91f3c: adrp    x20, #0x6263000                            
02c91f40: ldr     x20, [x20, #0x928]                         T:UnityEngine.Debug
02c91f44: bl      #0x2c97044                                 NativeBannerControl::get_IsEnabled
02c91f48: tbz     w0, #0, #0x2c91f90                         
02c91f4c: ldr     x0, [x19, #0x20]                           ._primaryAd
02c91f50: cbz     x0, #0x2c91fc4                             
02c91f54: bl      #0x2c94644                                 FsnBannerAd::IsBannerAdReady
02c91f58: tbz     w0, #0, #0x2c91fc4                         
02c91f5c: ldr     x0, [x20]                                  &2c5bbd4(=a9bd7bfdd503233f)
02c91f60: ldrb    w9, [x19, #0x50]                           ._isShowingBanner
02c91f64: ldr     w8, [x0, #0xe4]                            [62650e4]=0 f=0,0
02c91f68: cbz     w9, #0x2c91ff0                             
02c91f6c: cbnz    w8, #0x2c91f74                             
02c91f70: bl      #0x2b70f30                                 fn_2b70f30
02c91f74: adrp    x8, #0x6265000                             
02c91f78: mov     x1, xzr                                    
02c91f7c: ldr     x8, [x8, #0x690]                           S:'[NativeBannerControl] ShowAd - Banner already showing'
02c91f80: ldp     x20, x19, [sp, #0x10]                      
02c91f84: ldr     x0, [x8]                                   M:AdsManager::<OnApplicationPause>b__26_0
02c91f88: ldr     x30, [sp], #0x20                           
02c91f8c: b       #0x5af21f4                                 UnityEngine.Debug::Log
02c91f90: ldr     x0, [x20]                                  &2c5bbd4(=a9bd7bfdd503233f)
02c91f94: adrp    x20, #0x6265000                            
02c91f98: ldr     w8, [x0, #0xe4]                            [62650e4]=0 f=0,0
02c91f9c: ldr     x20, [x20, #0x688]                         S:'[NativeBannerControl] ShowAd - Ad disabled, skipping show'
02c91fa0: cbnz    w8, #0x2c91fa8                             
02c91fa4: bl      #0x2b70f30                                 fn_2b70f30
02c91fa8: ldr     x0, [x20]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c91fac: mov     x1, xzr                                    
02c91fb0: bl      #0x5af21f4                                 UnityEngine.Debug::Log
02c91fb4: mov     x0, x19                                    
02c91fb8: ldp     x20, x19, [sp, #0x10]                      
02c91fbc: ldr     x30, [sp], #0x20                           
02c91fc0: b       #0x2c97178                                 NativeBannerControl::StopRefreshLoop
02c91fc4: ldr     x0, [x20]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c91fc8: ldr     w8, [x0, #0xe4]                            [62650e4]=0 f=0,0
02c91fcc: cbnz    w8, #0x2c91fd4                             
02c91fd0: bl      #0x2b70f30                                 fn_2b70f30
02c91fd4: adrp    x8, #0x6265000                             
02c91fd8: mov     x1, xzr                                    
02c91fdc: ldr     x8, [x8, #0x680]                           S:'[NativeBannerControl] ShowAd - Ad not ready, cannot show'
02c91fe0: ldp     x20, x19, [sp, #0x10]                      
02c91fe4: ldr     x0, [x8]                                   M:AdsManager::<OnApplicationPause>b__26_0
02c91fe8: ldr     x30, [sp], #0x20                           
02c91fec: b       #0x5af2c94                                 UnityEngine.Debug::LogWarning
02c91ff0: cbnz    w8, #0x2c91ff8                             
02c91ff4: bl      #0x2b70f30                                 fn_2b70f30
02c91ff8: adrp    x8, #0x6265000                             
02c91ffc: mov     x1, xzr                                    
02c92000: ldr     x8, [x8, #0x678]                           S:'[NativeBannerControl] ShowAd - Showing banner'
02c92004: ldr     x0, [x8]                                   M:AdsManager::<OnApplicationPause>b__26_0
02c92008: bl      #0x5af21f4                                 UnityEngine.Debug::Log
02c9200c: ldr     w8, [x19, #0x54]                           ._showToken
02c92010: ldr     x1, [x19, #0x20]                           ._primaryAd
02c92014: mov     w9, #1                                     
02c92018: mov     x0, x19                                    
02c9201c: strb    w9, [x19, #0x50]                           ._isShowingBanner
02c92020: add     w2, w8, #1                                 
02c92024: str     w2, [x19, #0x54]                           ._showToken
02c92028: bl      #0x2c975c4                                 NativeBannerControl::ShowFsnAd
02c9202c: mov     x0, x19                                    
02c92030: ldp     x20, x19, [sp, #0x10]                      
02c92034: ldr     x30, [sp], #0x20                           
02c92038: b       #0x2c976ac                                 NativeBannerControl::StartRefreshLoop
## HideAd() -> void
---- NativeBannerControl::HideAd 0x2c91b08
02c91b08: stp     x30, x21, [sp, #-0x20]!                    
02c91b0c: stp     x20, x19, [sp, #0x10]                      
02c91b10: adrp    x21, #0x662f000                            
02c91b14: adrp    x20, #0x6263000                            
02c91b18: mov     x19, x0                                    
02c91b1c: ldrb    w8, [x21, #0xa11]                          
02c91b20: ldr     x20, [x20, #0x928]                         T:UnityEngine.Debug
02c91b24: tbnz    w8, #0, #0x2c91b54                         
02c91b28: adrp    x0, #0x6263000                             
02c91b2c: ldr     x0, [x0, #0x928]                           T:UnityEngine.Debug
02c91b30: bl      #0x2b70db0                                 fn_2b70db0
02c91b34: adrp    x0, #0x6265000                             
02c91b38: ldr     x0, [x0, #0x610]                           S:'[NativeBannerControl] HideAd - Hiding banner'
02c91b3c: bl      #0x2b70db0                                 fn_2b70db0
02c91b40: adrp    x0, #0x6265000                             
02c91b44: ldr     x0, [x0, #0x618]                           S:'[NativeBannerControl] HideAd - Banner hidden'
02c91b48: bl      #0x2b70db0                                 fn_2b70db0
02c91b4c: mov     w8, #1                                     
02c91b50: strb    w8, [x21, #0xa11]                          
02c91b54: ldr     x0, [x20]                                  &2c5bbd4(=a9bd7bfdd503233f)
02c91b58: adrp    x21, #0x6265000                            
02c91b5c: ldr     w8, [x0, #0xe4]                            [62650e4]=0 f=0,0
02c91b60: ldr     x21, [x21, #0x610]                         S:'[NativeBannerControl] HideAd - Hiding banner'
02c91b64: cbnz    w8, #0x2c91b6c                             
02c91b68: bl      #0x2b70f30                                 fn_2b70f30
02c91b6c: ldr     x0, [x21]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c91b70: mov     x1, xzr                                    
02c91b74: bl      #0x5af21f4                                 UnityEngine.Debug::Log
02c91b78: ldr     w8, [x19, #0x54]                           ._showToken
02c91b7c: ldr     x0, [x19, #0x20]                           ._primaryAd
02c91b80: strb    wzr, [x19, #0x50]                          ._isShowingBanner
02c91b84: add     w8, w8, #1                                 
02c91b88: str     w8, [x19, #0x54]                           ._showToken
02c91b8c: cbz     x0, #0x2c91bc8                             
02c91b90: bl      #0x2c94644                                 FsnBannerAd::IsBannerAdReady
02c91b94: tbz     w0, #0, #0x2c91bc8                         
02c91b98: ldr     x0, [x19, #0x20]                           ._primaryAd
02c91b9c: cbz     x0, #0x2c91bd8                             
02c91ba0: bl      #0x2c94544                                 FsnBannerAd::HideBannerAd
02c91ba4: ldr     x0, [x20]                                  &2c5bbd4(=a9bd7bfdd503233f)
02c91ba8: ldr     w8, [x0, #0xe4]                            [62650e4]=0 f=0,0
02c91bac: cbnz    w8, #0x2c91bb4                             
02c91bb0: bl      #0x2b70f30                                 fn_2b70f30
02c91bb4: adrp    x8, #0x6265000                             
02c91bb8: mov     x1, xzr                                    
02c91bbc: ldr     x8, [x8, #0x618]                           S:'[NativeBannerControl] HideAd - Banner hidden'
02c91bc0: ldr     x0, [x8]                                   M:AdsManager::<OnApplicationPause>b__26_0
02c91bc4: bl      #0x5af21f4                                 UnityEngine.Debug::Log
02c91bc8: mov     x0, x19                                    
02c91bcc: ldp     x20, x19, [sp, #0x10]                      
02c91bd0: ldp     x30, x21, [sp], #0x20                      
02c91bd4: b       #0x2c97178                                 NativeBannerControl::StopRefreshLoop
02c91bd8: bl      #0x2b7105c                                 fn_2b7105c
## ShowFsnAd(FsnBannerAd ad, int showToken) -> void
---- NativeBannerControl::ShowFsnAd 0x2c975c4
02c975c4: stp     x30, x23, [sp, #-0x30]!                    
02c975c8: stp     x22, x21, [sp, #0x10]                      
02c975cc: stp     x20, x19, [sp, #0x20]                      
02c975d0: adrp    x22, #0x662f000                            
02c975d4: adrp    x23, #0x6265000                            
02c975d8: mov     w21, w2                                    
02c975dc: ldrb    w8, [x22, #0xa12]                          
02c975e0: ldr     x23, [x23, #0x8a8]                         T:NativeBannerControl/<>c__DisplayClass24_0
02c975e4: mov     x19, x1                                    
02c975e8: mov     x20, x0                                    
02c975ec: tbnz    w8, #0, #0x2c9761c                         
02c975f0: adrp    x0, #0x6265000                             
02c975f4: ldr     x0, [x0, #0x4e0]                           T:type7027(k15)
02c975f8: bl      #0x2b70db0                                 fn_2b70db0
02c975fc: adrp    x0, #0x6265000                             
02c97600: ldr     x0, [x0, #0x8b0]                           M:NativeBannerControl/<>c__DisplayClass24_0::<ShowFsnAd>b__0
02c97604: bl      #0x2b70db0                                 fn_2b70db0
02c97608: adrp    x0, #0x6265000                             
02c9760c: ldr     x0, [x0, #0x8a8]                           T:NativeBannerControl/<>c__DisplayClass24_0
02c97610: bl      #0x2b70db0                                 fn_2b70db0
02c97614: mov     w8, #1                                     
02c97618: strb    w8, [x22, #0xa12]                          
02c9761c: ldr     x0, [x23]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c97620: bl      #0x2b7104c                                 fn_2b7104c
02c97624: mov     x1, xzr                                    
02c97628: mov     x22, x0                                    
02c9762c: bl      #0x4e53e9c                                 System.Object::.ctor
02c97630: cbz     x22, #0x2c976a8                            
02c97634: mov     x0, x22                                    
02c97638: mov     x1, x20                                    
02c9763c: str     x20, [x0, #0x18]!                          
02c97640: stur    w21, [x0, #-8]                             
02c97644: bl      #0x2b70d54                                 fn_2b70d54
02c97648: cbz     x19, #0x2c97694                            
02c9764c: adrp    x8, #0x6265000                             
02c97650: adrp    x20, #0x6265000                            
02c97654: ldr     x8, [x8, #0x4e0]                           T:type7027(k15)
02c97658: ldr     x20, [x20, #0x8b0]                         M:NativeBannerControl/<>c__DisplayClass24_0::<ShowFsnAd>b__0
02c9765c: ldr     x0, [x8]                                   M:AdsManager::<OnApplicationPause>b__26_0
02c97660: bl      #0x2b7104c                                 fn_2b7104c
02c97664: ldr     x2, [x20]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c97668: mov     x1, x22                                    
02c9766c: mov     x3, xzr                                    
02c97670: mov     x20, x0                                    
02c97674: bl      #0x453418c                                 fn_453418c
02c97678: mov     x0, x19                                    
02c9767c: mov     x1, x20                                    
02c97680: mov     w2, wzr                                    
02c97684: ldp     x20, x19, [sp, #0x20]                      
02c97688: ldp     x22, x21, [sp, #0x10]                      
02c9768c: ldp     x30, x23, [sp], #0x30                      
02c97690: b       #0x2c942a8                                 FsnBannerAd::ShowBannerAd
02c97694: strb    wzr, [x20, #0x50]                          ._isShowingBanner
02c97698: ldp     x20, x19, [sp, #0x20]                      
02c9769c: ldp     x22, x21, [sp, #0x10]                      
02c976a0: ldp     x30, x23, [sp], #0x30                      
02c976a4: ret                                                
02c976a8: bl      #0x2b7105c                                 fn_2b7105c
## TryReloadAd() -> void
---- NativeBannerControl::TryReloadAd 0x2c97820
02c97820: sub     sp, sp, #0x30                              
02c97824: stp     x30, x21, [sp, #0x10]                      
02c97828: stp     x20, x19, [sp, #0x20]                      
02c9782c: adrp    x20, #0x662f000                            
02c97830: mov     x19, x0                                    
02c97834: ldrb    w8, [x20, #0xa13]                          
02c97838: tbnz    w8, #0, #0x2c97868                         
02c9783c: adrp    x0, #0x6263000                             
02c97840: ldr     x0, [x0, #0x928]                           T:UnityEngine.Debug
02c97844: bl      #0x2b70db0                                 fn_2b70db0
02c97848: adrp    x0, #0x6265000                             
02c9784c: ldr     x0, [x0, #0x8d0]                           S:'[NativeBannerControl] TryReloadAd - Ad disabled, skipping reload'
02c97850: bl      #0x2b70db0                                 fn_2b70db0
02c97854: adrp    x0, #0x6265000                             
02c97858: ldr     x0, [x0, #0x8d8]                           S:'[NativeBannerControl] TryReloadAd - Starting reload coroutine (Attempt'
02c9785c: bl      #0x2b70db0                                 fn_2b70db0
02c97860: mov     w8, #1                                     
02c97864: strb    w8, [x20, #0xa13]                          
02c97868: adrp    x21, #0x6263000                            
02c9786c: ldr     x21, [x21, #0x928]                         T:UnityEngine.Debug
02c97870: bl      #0x2c97044                                 NativeBannerControl::get_IsEnabled
02c97874: tbz     w0, #0, #0x2c97928                         
02c97878: ldr     x0, [x19, #0x20]                           ._primaryAd
02c9787c: cbz     x0, #0x2c97888                             
02c97880: bl      #0x2c94644                                 FsnBannerAd::IsBannerAdReady
02c97884: tbnz    w0, #0, #0x2c97918                         
02c97888: mov     x20, x19                                   
02c9788c: ldr     x8, [x20, #0x40]!                          &2b70700(=14cc750491004000) ._reloadCoroutine
02c97890: cbnz    x8, #0x2c97918                             
02c97894: adrp    x8, #0x6263000                             
02c97898: add     x1, sp, #0xc                               
02c9789c: ldr     x8, [x8, #0x970]                           &6645c70(=0)
02c978a0: ldr     w9, [x19, #0x38]                           ._retryAttempt
02c978a4: ldr     x0, [x8, #0x48]                            &6263098(=0)
02c978a8: str     w9, [sp, #0xc]                             
02c978ac: bl      #0x2b70f38                                 fn_2b70f38
02c978b0: adrp    x8, #0x6265000                             
02c978b4: mov     x1, x0                                     
02c978b8: mov     x2, xzr                                    
02c978bc: ldr     x8, [x8, #0x8d8]                           S:'[NativeBannerControl] TryReloadAd - Starting reload coroutine (Attempt'
02c978c0: ldr     x8, [x8]                                   M:AdsManager::<OnApplicationPause>b__26_0
02c978c4: mov     x0, x8                                     
02c978c8: bl      #0x4c9d0ec                                 System.String::Format
02c978cc: ldr     x8, [x21]                                  &2c5bbd4(=a9bd7bfdd503233f)
02c978d0: mov     x21, x0                                    
02c978d4: ldr     w9, [x8, #0xe4]                            [62650e4]=0 f=0,0
02c978d8: cbnz    w9, #0x2c978e4                             
02c978dc: mov     x0, x8                                     
02c978e0: bl      #0x2b70f30                                 fn_2b70f30
02c978e4: mov     x0, x21                                    
02c978e8: mov     x1, xzr                                    
02c978ec: bl      #0x5af21f4                                 UnityEngine.Debug::Log
02c978f0: mov     x0, x19                                    
02c978f4: bl      #0x2c97958                                 NativeBannerControl::ReloadCoroutine
02c978f8: mov     x1, x0                                     
02c978fc: mov     x0, x19                                    
02c97900: mov     x2, xzr                                    
02c97904: bl      #0x5b389f0                                 UnityEngine.MonoBehaviour::StartCoroutine
02c97908: mov     x1, x0                                     
02c9790c: str     x0, [x19, #0x40]                           ._reloadCoroutine
02c97910: mov     x0, x20                                    
02c97914: bl      #0x2b70d54                                 fn_2b70d54
02c97918: ldp     x20, x19, [sp, #0x20]                      
02c9791c: ldp     x30, x21, [sp, #0x10]                      
02c97920: add     sp, sp, #0x30                              
02c97924: ret                                                
02c97928: ldr     x0, [x21]                                  &2c5bbd4(=a9bd7bfdd503233f)
02c9792c: adrp    x19, #0x6265000                            
02c97930: ldr     w8, [x0, #0xe4]                            [62650e4]=0 f=0,0
02c97934: ldr     x19, [x19, #0x8d0]                         S:'[NativeBannerControl] TryReloadAd - Ad disabled, skipping reload'
02c97938: cbnz    w8, #0x2c97940                             
02c9793c: bl      #0x2b70f30                                 fn_2b70f30
02c97940: ldr     x0, [x19]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c97944: ldp     x20, x19, [sp, #0x20]                      
02c97948: ldp     x30, x21, [sp, #0x10]                      
02c9794c: mov     x1, xzr                                    
02c97950: add     sp, sp, #0x30                              
02c97954: b       #0x5af21f4                                 UnityEngine.Debug::Log
## StartRefreshLoop() -> void
---- NativeBannerControl::StartRefreshLoop 0x2c976ac
02c976ac: sub     sp, sp, #0x30                              
02c976b0: stp     x30, x21, [sp, #0x10]                      
02c976b4: stp     x20, x19, [sp, #0x20]                      
02c976b8: adrp    x20, #0x662f000                            
02c976bc: mov     x19, x0                                    
02c976c0: ldrb    w8, [x20, #0xa14]                          
02c976c4: tbnz    w8, #0, #0x2c97700                         
02c976c8: adrp    x0, #0x6263000                             
02c976cc: ldr     x0, [x0, #0x928]                           T:UnityEngine.Debug
02c976d0: bl      #0x2b70db0                                 fn_2b70db0
02c976d4: adrp    x0, #0x6265000                             
02c976d8: ldr     x0, [x0, #0x8b8]                           S:'[NativeBannerControl] StartRefreshLoop - Starting refresh loop (interv'
02c976dc: bl      #0x2b70db0                                 fn_2b70db0
02c976e0: adrp    x0, #0x6265000                             
02c976e4: ldr     x0, [x0, #0x8c0]                           S:'[NativeBannerControl] StartRefreshLoop - Refresh already running'
02c976e8: bl      #0x2b70db0                                 fn_2b70db0
02c976ec: adrp    x0, #0x6265000                             
02c976f0: ldr     x0, [x0, #0x8c8]                           S:'[NativeBannerControl] StartRefreshLoop - Ad disabled, not starting ref'
02c976f4: bl      #0x2b70db0                                 fn_2b70db0
02c976f8: mov     w8, #1                                     
02c976fc: strb    w8, [x20, #0xa14]                          
02c97700: adrp    x21, #0x6263000                            
02c97704: ldr     x21, [x21, #0x928]                         T:UnityEngine.Debug
02c97708: bl      #0x2c97044                                 NativeBannerControl::get_IsEnabled
02c9770c: tbz     w0, #0, #0x2c9774c                         
02c97710: mov     x20, x19                                   
02c97714: ldr     x8, [x20, #0x48]!                          [662f048]=6000017 f=2.40742e-35,0 ._refreshCoroutine
02c97718: cbz     x8, #0x2c97784                             
02c9771c: ldr     x0, [x21]                                  &2c5bbd4(=a9bd7bfdd503233f)
02c97720: ldr     w8, [x0, #0xe4]                            [62650e4]=0 f=0,0
02c97724: cbnz    w8, #0x2c9772c                             
02c97728: bl      #0x2b70f30                                 fn_2b70f30
02c9772c: adrp    x8, #0x6265000                             
02c97730: mov     x1, xzr                                    
02c97734: ldr     x8, [x8, #0x8c0]                           S:'[NativeBannerControl] StartRefreshLoop - Refresh already running'
02c97738: ldp     x20, x19, [sp, #0x20]                      
02c9773c: ldp     x30, x21, [sp, #0x10]                      
02c97740: ldr     x0, [x8]                                   M:AdsManager::<OnApplicationPause>b__26_0
02c97744: add     sp, sp, #0x30                              
02c97748: b       #0x5af21f4                                 UnityEngine.Debug::Log
02c9774c: ldr     x0, [x21]                                  &2c5bbd4(=a9bd7bfdd503233f)
02c97750: adrp    x20, #0x6265000                            
02c97754: ldr     w8, [x0, #0xe4]                            [62650e4]=0 f=0,0
02c97758: ldr     x20, [x20, #0x8c8]                         S:'[NativeBannerControl] StartRefreshLoop - Ad disabled, not starting ref'
02c9775c: cbnz    w8, #0x2c97764                             
02c97760: bl      #0x2b70f30                                 fn_2b70f30
02c97764: ldr     x0, [x20]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c97768: mov     x1, xzr                                    
02c9776c: bl      #0x5af21f4                                 UnityEngine.Debug::Log
02c97770: mov     x0, x19                                    
02c97774: ldp     x20, x19, [sp, #0x20]                      
02c97778: ldp     x30, x21, [sp, #0x10]                      
02c9777c: add     sp, sp, #0x30                              
02c97780: b       #0x2c97178                                 NativeBannerControl::StopRefreshLoop
02c97784: bl      #0x2c970cc                                 NativeBannerControl::get_RefreshInterval
02c97788: adrp    x8, #0x6263000                             
02c9778c: add     x1, sp, #0xc                               
02c97790: ldr     x8, [x8, #0x970]                           &6645c70(=0)
02c97794: str     s0, [sp, #0xc]                             
02c97798: ldr     x0, [x8, #0x78]                            &2c498b4(=d65f03c0d503245f)
02c9779c: bl      #0x2b70f38                                 fn_2b70f38
02c977a0: adrp    x8, #0x6265000                             
02c977a4: mov     x1, x0                                     
02c977a8: mov     x2, xzr                                    
02c977ac: ldr     x8, [x8, #0x8b8]                           S:'[NativeBannerControl] StartRefreshLoop - Starting refresh loop (interv'
02c977b0: ldr     x8, [x8]                                   M:AdsManager::<OnApplicationPause>b__26_0
02c977b4: mov     x0, x8                                     
02c977b8: bl      #0x4c9d0ec                                 System.String::Format
02c977bc: ldr     x8, [x21]                                  &2c5bbd4(=a9bd7bfdd503233f)
02c977c0: mov     x21, x0                                    
02c977c4: ldr     w9, [x8, #0xe4]                            [62650e4]=0 f=0,0
02c977c8: cbnz    w9, #0x2c977d4                             
02c977cc: mov     x0, x8                                     
02c977d0: bl      #0x2b70f30                                 fn_2b70f30
02c977d4: mov     x0, x21                                    
02c977d8: mov     x1, xzr                                    
02c977dc: bl      #0x5af21f4                                 UnityEngine.Debug::Log
02c977e0: mov     x0, x19                                    
02c977e4: bl      #0x2c979c4                                 NativeBannerControl::RefreshAdCoroutine
02c977e8: mov     x1, x0                                     
02c977ec: mov     x0, x19                                    
02c977f0: mov     x2, xzr                                    
02c977f4: bl      #0x5b389f0                                 UnityEngine.MonoBehaviour::StartCoroutine
02c977f8: mov     x1, x0                                     
02c977fc: str     x0, [x19, #0x48]                           ._refreshCoroutine
02c97800: mov     x0, x20                                    
02c97804: bl      #0x2b70d54                                 fn_2b70d54
02c97808: ldp     x20, x19, [sp, #0x20]                      
02c9780c: ldp     x30, x21, [sp, #0x10]                      
02c97810: add     sp, sp, #0x30                              
02c97814: ret                                                
## RefreshAdCoroutine() -> System.Collections.IEnumerator
---- NativeBannerControl::RefreshAdCoroutine 0x2c979c4
02c979c4: stp     x30, x21, [sp, #-0x20]!                    
02c979c8: stp     x20, x19, [sp, #0x10]                      
02c979cc: adrp    x20, #0x662f000                            
02c979d0: adrp    x21, #0x6265000                            
02c979d4: mov     x19, x0                                    
02c979d8: ldrb    w8, [x20, #0xa15]                          
02c979dc: ldr     x21, [x21, #0x8e8]                         T:NativeBannerControl/<RefreshAdCoroutine>d__27
02c979e0: tbnz    w8, #0, #0x2c979f8                         
02c979e4: adrp    x0, #0x6265000                             
02c979e8: ldr     x0, [x0, #0x8e8]                           T:NativeBannerControl/<RefreshAdCoroutine>d__27
02c979ec: bl      #0x2b70db0                                 fn_2b70db0
02c979f0: mov     w8, #1                                     
02c979f4: strb    w8, [x20, #0xa15]                          
02c979f8: ldr     x0, [x21]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c979fc: bl      #0x2b7104c                                 fn_2b7104c
02c97a00: mov     x1, xzr                                    
02c97a04: mov     x20, x0                                    
02c97a08: bl      #0x4e53e9c                                 System.Object::.ctor
02c97a0c: mov     x0, x20                                    
02c97a10: mov     x1, x19                                    
02c97a14: str     wzr, [x20, #0x10]                          
02c97a18: str     x19, [x0, #0x20]!                          ._primaryAd
02c97a1c: bl      #0x2b70d54                                 fn_2b70d54
02c97a20: mov     x0, x20                                    
02c97a24: ldp     x20, x19, [sp, #0x10]                      
02c97a28: ldp     x30, x21, [sp], #0x20                      
02c97a2c: ret                                                
## CreateReplacementAd() -> FsnBannerAd
---- NativeBannerControl::CreateReplacementAd 0x2c97a58
02c97a58: str     x30, [sp, #-0x30]!                         
02c97a5c: stp     x22, x21, [sp, #0x10]                      
02c97a60: stp     x20, x19, [sp, #0x20]                      
02c97a64: adrp    x21, #0x662f000                            
02c97a68: adrp    x22, #0x6265000                            
02c97a6c: adrp    x20, #0x6263000                            
02c97a70: ldrb    w8, [x21, #0xa16]                          
02c97a74: ldr     x22, [x22, #0x8f0]                         S:'[NativeBannerControl] CreateReplacementAd - Creating replacement ad fo'
02c97a78: ldr     x20, [x20, #0x928]                         T:UnityEngine.Debug
02c97a7c: mov     x19, x0                                    
02c97a80: tbnz    w8, #0, #0x2c97ab0                         
02c97a84: adrp    x0, #0x6263000                             
02c97a88: ldr     x0, [x0, #0x928]                           T:UnityEngine.Debug
02c97a8c: bl      #0x2b70db0                                 fn_2b70db0
02c97a90: adrp    x0, #0x6265000                             
02c97a94: ldr     x0, [x0, #0x850]                           T:FsnBannerAd
02c97a98: bl      #0x2b70db0                                 fn_2b70db0
02c97a9c: adrp    x0, #0x6265000                             
02c97aa0: ldr     x0, [x0, #0x8f0]                           S:'[NativeBannerControl] CreateReplacementAd - Creating replacement ad fo'
02c97aa4: bl      #0x2b70db0                                 fn_2b70db0
02c97aa8: mov     w8, #1                                     
02c97aac: strb    w8, [x21, #0xa16]                          
02c97ab0: adrp    x21, #0x6265000                            
02c97ab4: mov     x2, xzr                                    
02c97ab8: ldr     x21, [x21, #0x850]                         T:FsnBannerAd
02c97abc: ldr     x1, [x19, #0x30]                           ._adID
02c97ac0: ldr     x0, [x22]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c97ac4: bl      #0x4c9c514                                 System.String::Concat
02c97ac8: ldr     x8, [x20]                                  &2c5bbd4(=a9bd7bfdd503233f)
02c97acc: mov     x20, x0                                    
02c97ad0: ldr     w9, [x8, #0xe4]                            
02c97ad4: cbnz    w9, #0x2c97ae0                             
02c97ad8: mov     x0, x8                                     
02c97adc: bl      #0x2b70f30                                 fn_2b70f30
02c97ae0: mov     x0, x20                                    
02c97ae4: mov     x1, xzr                                    
02c97ae8: bl      #0x5af21f4                                 UnityEngine.Debug::Log
02c97aec: ldr     x0, [x21]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c97af0: bl      #0x2b7104c                                 fn_2b7104c
02c97af4: mov     x20, x0                                    
02c97af8: bl      #0x2c93c68                                 FsnBannerAd::.ctor
02c97afc: cbz     x20, #0x2c97b40                            
02c97b00: ldr     x1, [x19, #0x30]                           ._adID
02c97b04: mov     x0, x20                                    
02c97b08: mov     w2, #1                                     
02c97b0c: mov     w3, #1                                     
02c97b10: mov     w4, wzr                                    
02c97b14: bl      #0x2c93da8                                 FsnBannerAd::InitNativeBanner
02c97b18: mov     x0, x19                                    
02c97b1c: mov     x1, x20                                    
02c97b20: bl      #0x2c973a0                                 NativeBannerControl::RegisterListener
02c97b24: mov     x0, x20                                    
02c97b28: bl      #0x2c94124                                 FsnBannerAd::LoadBannerAd
02c97b2c: mov     x0, x20                                    
02c97b30: ldp     x20, x19, [sp, #0x20]                      
02c97b34: ldp     x22, x21, [sp, #0x10]                      
02c97b38: ldr     x30, [sp], #0x30                           
02c97b3c: ret                                                
02c97b40: bl      #0x2b7105c                                 fn_2b7105c
## TrySwapBanner(FsnBannerAd replacementAd, bool showImmediately) -> void
---- NativeBannerControl::TrySwapBanner 0x2c97b44
02c97b44: str     x30, [sp, #-0x40]!                         
02c97b48: stp     x24, x23, [sp, #0x10]                      
02c97b4c: stp     x22, x21, [sp, #0x20]                      
02c97b50: stp     x20, x19, [sp, #0x30]                      
02c97b54: adrp    x22, #0x662f000                            
02c97b58: mov     w20, w2                                    
02c97b5c: mov     x21, x1                                    
02c97b60: ldrb    w8, [x22, #0xa17]                          
02c97b64: mov     x19, x0                                    
02c97b68: tbnz    w8, #0, #0x2c97bb0                         
02c97b6c: adrp    x0, #0x6263000                             
02c97b70: ldr     x0, [x0, #0x928]                           T:UnityEngine.Debug
02c97b74: bl      #0x2b70db0                                 fn_2b70db0
02c97b78: adrp    x0, #0x6265000                             
02c97b7c: ldr     x0, [x0, #0x8f8]                           S:'[NativeBannerControl] TrySwapBanner - Hiding previous ad before swap'
02c97b80: bl      #0x2b70db0                                 fn_2b70db0
02c97b84: adrp    x0, #0x6265000                             
02c97b88: ldr     x0, [x0, #0x900]                           S:'[NativeBannerControl] TrySwapBanner - Replacement ad not ready'
02c97b8c: bl      #0x2b70db0                                 fn_2b70db0
02c97b90: adrp    x0, #0x6265000                             
02c97b94: ldr     x0, [x0, #0x908]                           S:'[NativeBannerControl] TrySwapBanner - Showing new ad immediately'
02c97b98: bl      #0x2b70db0                                 fn_2b70db0
02c97b9c: adrp    x0, #0x6265000                             
02c97ba0: ldr     x0, [x0, #0x910]                           S:'[NativeBannerControl] TrySwapBanner - Swapping banner (ShowImmediately'
02c97ba4: bl      #0x2b70db0                                 fn_2b70db0
02c97ba8: mov     w8, #1                                     
02c97bac: strb    w8, [x22, #0xa17]                          
02c97bb0: adrp    x24, #0x6263000                            
02c97bb4: ldr     x24, [x24, #0x928]                         T:UnityEngine.Debug
02c97bb8: cbz     x21, #0x2c97c80                            
02c97bbc: mov     x0, x21                                    
02c97bc0: bl      #0x2c94644                                 FsnBannerAd::IsBannerAdReady
02c97bc4: tbz     w0, #0, #0x2c97c80                         
02c97bc8: adrp    x8, #0x6263000                             
02c97bcc: and     w9, w20, #1                                
02c97bd0: add     x1, sp, #0xc                               
02c97bd4: ldr     x8, [x8, #0x970]                           &6645c70(=0)
02c97bd8: strb    w9, [sp, #0xc]                             
02c97bdc: ldr     x0, [x8, #0x28]                            [6263028]=0 f=0,0
02c97be0: bl      #0x2b70f38                                 fn_2b70f38
02c97be4: adrp    x8, #0x6265000                             
02c97be8: mov     x1, x0                                     
02c97bec: mov     x2, xzr                                    
02c97bf0: ldr     x8, [x8, #0x910]                           S:'[NativeBannerControl] TrySwapBanner - Swapping banner (ShowImmediately'
02c97bf4: ldr     x8, [x8]                                   M:AdsManager::<OnApplicationPause>b__26_0
02c97bf8: mov     x0, x8                                     
02c97bfc: bl      #0x4c9d0ec                                 System.String::Format
02c97c00: ldr     x8, [x24]                                  &2c5bbd4(=a9bd7bfdd503233f)
02c97c04: mov     x22, x0                                    
02c97c08: ldr     w9, [x8, #0xe4]                            [62650e4]=0 f=0,0
02c97c0c: cbnz    w9, #0x2c97c18                             
02c97c10: mov     x0, x8                                     
02c97c14: bl      #0x2b70f30                                 fn_2b70f30
02c97c18: mov     x0, x22                                    
02c97c1c: mov     x1, xzr                                    
02c97c20: bl      #0x5af21f4                                 UnityEngine.Debug::Log
02c97c24: mov     x23, x19                                   
02c97c28: ldr     x22, [x23, #0x20]!                         
02c97c2c: tbz     w20, #0, #0x2c97cb4                        
02c97c30: cbz     x22, #0x2c97cb4                            
02c97c34: mov     x0, x22                                    
02c97c38: bl      #0x2c94644                                 FsnBannerAd::IsBannerAdReady
02c97c3c: tbz     w0, #0, #0x2c97c6c                         
02c97c40: ldr     x0, [x24]                                  &2c5bbd4(=a9bd7bfdd503233f)
02c97c44: ldr     w8, [x0, #0xe4]                            [62650e4]=0 f=0,0
02c97c48: cbnz    w8, #0x2c97c50                             
02c97c4c: bl      #0x2b70f30                                 fn_2b70f30
02c97c50: adrp    x8, #0x6265000                             
02c97c54: mov     x1, xzr                                    
02c97c58: ldr     x8, [x8, #0x8f8]                           S:'[NativeBannerControl] TrySwapBanner - Hiding previous ad before swap'
02c97c5c: ldr     x0, [x8]                                   M:AdsManager::<OnApplicationPause>b__26_0
02c97c60: bl      #0x5af21f4                                 UnityEngine.Debug::Log
02c97c64: mov     x0, x22                                    
02c97c68: bl      #0x2c94544                                 FsnBannerAd::HideBannerAd
02c97c6c: mov     x0, x23                                    
02c97c70: mov     x1, x21                                    
02c97c74: str     x21, [x23]                                 
02c97c78: bl      #0x2b70d54                                 fn_2b70d54
02c97c7c: b       #0x2c97cc8                                 
02c97c80: ldr     x0, [x24]                                  &2c5bbd4(=a9bd7bfdd503233f)
02c97c84: adrp    x19, #0x6265000                            
02c97c88: ldr     w8, [x0, #0xe4]                            [62650e4]=0 f=0,0
02c97c8c: ldr     x19, [x19, #0x900]                         S:'[NativeBannerControl] TrySwapBanner - Replacement ad not ready'
02c97c90: cbnz    w8, #0x2c97c98                             
02c97c94: bl      #0x2b70f30                                 fn_2b70f30
02c97c98: ldr     x0, [x19]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c97c9c: ldp     x20, x19, [sp, #0x30]                      
02c97ca0: ldp     x22, x21, [sp, #0x20]                      
02c97ca4: mov     x1, xzr                                    
02c97ca8: ldp     x24, x23, [sp, #0x10]                      
02c97cac: ldr     x30, [sp], #0x40                           
02c97cb0: b       #0x5af2c94                                 UnityEngine.Debug::LogWarning
02c97cb4: mov     x0, x23                                    
02c97cb8: mov     x1, x21                                    
02c97cbc: str     x21, [x23]                                 
02c97cc0: bl      #0x2b70d54                                 fn_2b70d54
02c97cc4: cbz     x22, #0x2c97cd0                            
02c97cc8: mov     x0, x22                                    
02c97ccc: bl      #0x2c9480c                                 FsnBannerAd::Release
02c97cd0: tbz     w20, #0, #0x2c97d18                        
02c97cd4: ldr     x0, [x24]                                  &2c5bbd4(=a9bd7bfdd503233f)
02c97cd8: ldr     w8, [x0, #0xe4]                            [62650e4]=0 f=0,0
02c97cdc: cbnz    w8, #0x2c97ce4                             
02c97ce0: bl      #0x2b70f30                                 fn_2b70f30
02c97ce4: adrp    x8, #0x6265000                             
02c97ce8: mov     x1, xzr                                    
02c97cec: ldr     x8, [x8, #0x908]                           S:'[NativeBannerControl] TrySwapBanner - Showing new ad immediately'
02c97cf0: ldr     x0, [x8]                                   M:AdsManager::<OnApplicationPause>b__26_0
02c97cf4: bl      #0x5af21f4                                 UnityEngine.Debug::Log
02c97cf8: ldr     w8, [x19, #0x54]                           [6265054]=0 f=0,0 ._showToken
02c97cfc: ldr     x1, [x19, #0x20]                           S:'dev log AdsManager show app open ad' ._primaryAd
02c97d00: mov     w9, #1                                     
02c97d04: mov     x0, x19                                    
02c97d08: strb    w9, [x19, #0x50]                           ._isShowingBanner
02c97d0c: add     w2, w8, #1                                 
02c97d10: str     w2, [x19, #0x54]                           ._showToken
02c97d14: bl      #0x2c975c4                                 NativeBannerControl::ShowFsnAd
02c97d18: ldp     x20, x19, [sp, #0x30]                      
02c97d1c: ldp     x22, x21, [sp, #0x20]                      
02c97d20: ldp     x24, x23, [sp, #0x10]                      
02c97d24: ldr     x30, [sp], #0x40                           
02c97d28: ret                                                
## ReloadCoroutine() -> System.Collections.IEnumerator
---- NativeBannerControl::ReloadCoroutine 0x2c97958
02c97958: stp     x30, x21, [sp, #-0x20]!                    
02c9795c: stp     x20, x19, [sp, #0x10]                      
02c97960: adrp    x20, #0x662f000                            
02c97964: adrp    x21, #0x6265000                            
02c97968: mov     x19, x0                                    
02c9796c: ldrb    w8, [x20, #0xa18]                          
02c97970: ldr     x21, [x21, #0x8e0]                         T:NativeBannerControl/<ReloadCoroutine>d__30
02c97974: tbnz    w8, #0, #0x2c9798c                         
02c97978: adrp    x0, #0x6265000                             
02c9797c: ldr     x0, [x0, #0x8e0]                           T:NativeBannerControl/<ReloadCoroutine>d__30
02c97980: bl      #0x2b70db0                                 fn_2b70db0
02c97984: mov     w8, #1                                     
02c97988: strb    w8, [x20, #0xa18]                          
02c9798c: ldr     x0, [x21]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c97990: bl      #0x2b7104c                                 fn_2b7104c
02c97994: mov     x1, xzr                                    
02c97998: mov     x20, x0                                    
02c9799c: bl      #0x4e53e9c                                 System.Object::.ctor
02c979a0: mov     x0, x20                                    
02c979a4: mov     x1, x19                                    
02c979a8: str     wzr, [x20, #0x10]                          
02c979ac: str     x19, [x0, #0x20]!                          ._primaryAd
02c979b0: bl      #0x2b70d54                                 fn_2b70d54
02c979b4: mov     x0, x20                                    
02c979b8: ldp     x20, x19, [sp, #0x10]                      
02c979bc: ldp     x30, x21, [sp], #0x20                      
02c979c0: ret                                                
## .ctor() -> void
---- NativeBannerControl::.ctor 0x2c97d54
02c97d54: stp     x30, x21, [sp, #-0x20]!                    
02c97d58: stp     x20, x19, [sp, #0x10]                      
02c97d5c: adrp    x20, #0x662f000                            
02c97d60: adrp    x21, #0x6263000                            
02c97d64: mov     x19, x0                                    
02c97d68: ldrb    w8, [x20, #0xa19]                          
02c97d6c: ldr     x21, [x21, #0xa90]                         S:''
02c97d70: tbnz    w8, #0, #0x2c97d88                         
02c97d74: adrp    x0, #0x6263000                             
02c97d78: ldr     x0, [x0, #0xa90]                           S:''
02c97d7c: bl      #0x2b70db0                                 fn_2b70db0
02c97d80: mov     w8, #1                                     
02c97d84: strb    w8, [x20, #0xa19]                          
02c97d88: ldr     x1, [x21]                                  &2c5bbd4(=a9bd7bfdd503233f)
02c97d8c: mov     x0, x19                                    
02c97d90: str     x1, [x0, #0x30]!                           ._adID
02c97d94: bl      #0x2b70d54                                 fn_2b70d54
02c97d98: mov     w8, #0x32                                  
02c97d9c: mov     x0, x19                                    
02c97da0: mov     x1, xzr                                    
02c97da4: str     w8, [x19, #0x3c]                           ._maxRetryAttempts
02c97da8: ldp     x20, x19, [sp, #0x10]                      
02c97dac: ldp     x30, x21, [sp], #0x20                      
02c97db0: b       #0x5b397b0                                 UnityEngine.MonoBehaviour::.ctor
## <RegisterListener>b__21_0(int errCode, string errMessage) -> void
---- NativeBannerControl::<RegisterListener>b__21_0 0x2c97db4
02c97db4: str     x30, [sp, #-0x40]!                         
02c97db8: stp     x24, x23, [sp, #0x10]                      
02c97dbc: stp     x22, x21, [sp, #0x20]                      
02c97dc0: stp     x20, x19, [sp, #0x30]                      
02c97dc4: adrp    x24, #0x662f000                            
02c97dc8: adrp    x23, #0x6265000                            
02c97dcc: adrp    x22, #0x6263000                            
02c97dd0: ldrb    w8, [x24, #0xa1a]                          
02c97dd4: ldr     x23, [x23, #0x918]                         S:'[NativeBannerControl] onLoadingCompleted - ErrorCode: {0}, Message: {1'
02c97dd8: ldr     x22, [x22, #0x928]                         T:UnityEngine.Debug
02c97ddc: mov     x21, x2                                    
02c97de0: mov     w20, w1                                    
02c97de4: mov     x19, x0                                    
02c97de8: tbnz    w8, #0, #0x2c97e24                         
02c97dec: adrp    x0, #0x6263000                             
02c97df0: ldr     x0, [x0, #0x928]                           T:UnityEngine.Debug
02c97df4: bl      #0x2b70db0                                 fn_2b70db0
02c97df8: adrp    x0, #0x6265000                             
02c97dfc: ldr     x0, [x0, #0x918]                           S:'[NativeBannerControl] onLoadingCompleted - ErrorCode: {0}, Message: {1'
02c97e00: bl      #0x2b70db0                                 fn_2b70db0
02c97e04: adrp    x0, #0x6265000                             
02c97e08: ldr     x0, [x0, #0x920]                           S:'[NativeBannerControl] Ad loaded successfully, resetting retry count'
02c97e0c: bl      #0x2b70db0                                 fn_2b70db0
02c97e10: adrp    x0, #0x6265000                             
02c97e14: ldr     x0, [x0, #0x928]                           S:'[NativeBannerControl] Ad load failed, attempting retry...'
02c97e18: bl      #0x2b70db0                                 fn_2b70db0
02c97e1c: mov     w8, #1                                     
02c97e20: strb    w8, [x24, #0xa1a]                          
02c97e24: adrp    x8, #0x6263000                             
02c97e28: add     x1, sp, #0xc                               
02c97e2c: ldr     x8, [x8, #0x970]                           &6645c70(=0)
02c97e30: str     w20, [sp, #0xc]                            
02c97e34: ldr     x0, [x8, #0x48]                            &6263098(=0)
02c97e38: bl      #0x2b70f38                                 fn_2b70f38
02c97e3c: ldr     x8, [x23]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c97e40: mov     x1, x0                                     
02c97e44: mov     x2, x21                                    
02c97e48: mov     x3, xzr                                    
02c97e4c: mov     x0, x8                                     
02c97e50: bl      #0x4ca7720                                 System.String::Format
02c97e54: ldr     x8, [x22]                                  &2c5bbd4(=a9bd7bfdd503233f)
02c97e58: mov     x21, x0                                    
02c97e5c: ldr     w9, [x8, #0xe4]                            [62630e4]=0 f=0,0
02c97e60: cbnz    w9, #0x2c97e6c                             
02c97e64: mov     x0, x8                                     
02c97e68: bl      #0x2b70f30                                 fn_2b70f30
02c97e6c: mov     x0, x21                                    
02c97e70: mov     x1, xzr                                    
02c97e74: bl      #0x5af21f4                                 UnityEngine.Debug::Log
02c97e78: ldr     x0, [x22]                                  &2c5bbd4(=a9bd7bfdd503233f)
02c97e7c: ldr     w8, [x0, #0xe4]                            [62650e4]=0 f=0,0
02c97e80: cbz     w20, #0x2c97eac                            
02c97e84: adrp    x20, #0x6265000                            
02c97e88: ldr     x20, [x20, #0x928]                         S:'[NativeBannerControl] Ad load failed, attempting retry...'
02c97e8c: cbnz    w8, #0x2c97e94                             
02c97e90: bl      #0x2b70f30                                 fn_2b70f30
02c97e94: ldr     x0, [x20]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c97e98: mov     x1, xzr                                    
02c97e9c: bl      #0x5af2c94                                 UnityEngine.Debug::LogWarning
02c97ea0: mov     x0, x19                                    
02c97ea4: bl      #0x2c97820                                 NativeBannerControl::TryReloadAd
02c97ea8: b       #0x2c97ecc                                 
02c97eac: cbnz    w8, #0x2c97eb4                             
02c97eb0: bl      #0x2b70f30                                 fn_2b70f30
02c97eb4: adrp    x8, #0x6265000                             
02c97eb8: mov     x1, xzr                                    
02c97ebc: ldr     x8, [x8, #0x920]                           S:'[NativeBannerControl] Ad loaded successfully, resetting retry count'
02c97ec0: ldr     x0, [x8]                                   M:AdsManager::<OnApplicationPause>b__26_0
02c97ec4: bl      #0x5af21f4                                 UnityEngine.Debug::Log
02c97ec8: str     wzr, [x19, #0x38]                          ._retryAttempt
02c97ecc: ldp     x20, x19, [sp, #0x30]                      
02c97ed0: ldp     x22, x21, [sp, #0x20]                      
02c97ed4: ldp     x24, x23, [sp, #0x10]                      
02c97ed8: ldr     x30, [sp], #0x40                           
02c97edc: ret                                                
