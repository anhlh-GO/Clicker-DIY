#### CLASS Framework.RectExtension parent= object
## Intersects(UnityEngine.Rect thisRectangle, UnityEngine.Rect otherRectangle) -> bool
---- Framework.RectExtension::Intersects 0x2cb94a0
02cb94a0: stp     d15, d14, [sp, #-0x60]!                    
02cb94a4: stp     d13, d12, [sp, #0x10]                      
02cb94a8: stp     d11, d10, [sp, #0x20]                      
02cb94ac: stp     d9, d8, [sp, #0x30]                        
02cb94b0: str     x30, [sp, #0x40]                           
02cb94b4: stp     x20, x19, [sp, #0x50]                      
02cb94b8: fmov    s11, s7                                    
02cb94bc: fmov    s15, s6                                    
02cb94c0: adrp    x20, #0x662f000                            
02cb94c4: fmov    s8, s5                                     
02cb94c8: fmov    s12, s4                                    
02cb94cc: adrp    x19, #0x6264000                            
02cb94d0: fmov    s9, s3                                     
02cb94d4: fmov    s13, s2                                    
02cb94d8: ldrb    w8, [x20, #0xbe9]                          
02cb94dc: fmov    s10, s1                                    
02cb94e0: fmov    s14, s0                                    
02cb94e4: ldr     x19, [x19, #0x798]                         T:UnityEngine.Rect
02cb94e8: tbnz    w8, #0, #0x2cb9500                         
02cb94ec: adrp    x0, #0x6264000                             
02cb94f0: ldr     x0, [x0, #0x798]                           T:UnityEngine.Rect
02cb94f4: bl      #0x2b70db0                                 fn_2b70db0
02cb94f8: mov     w8, #1                                     
02cb94fc: strb    w8, [x20, #0xbe9]                          
02cb9500: ldr     x0, [x19]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02cb9504: ldr     w8, [x0, #0xe4]                            [62640e4]=0 f=0,0
02cb9508: cbnz    w8, #0x2cb9510                             
02cb950c: bl      #0x2b70f30                                 fn_2b70f30
02cb9510: fadd    s0, s15, s12                               
02cb9514: fcmp    s14, s0                                    
02cb9518: b.gt    #0x2cb9554                                 
02cb951c: ldr     x0, [x19]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02cb9520: ldr     w8, [x0, #0xe4]                            [62640e4]=0 f=0,0
02cb9524: cbnz    w8, #0x2cb952c                             
02cb9528: bl      #0x2b70f30                                 fn_2b70f30
02cb952c: fadd    s0, s13, s14                               
02cb9530: fcmp    s0, s12                                    
02cb9534: b.mi    #0x2cb9554                                 
02cb9538: ldr     x0, [x19]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02cb953c: ldr     w8, [x0, #0xe4]                            [62640e4]=0 f=0,0
02cb9540: cbnz    w8, #0x2cb9548                             
02cb9544: bl      #0x2b70f30                                 fn_2b70f30
02cb9548: fadd    s0, s11, s8                                
02cb954c: fcmp    s10, s0                                    
02cb9550: b.le    #0x2cb9574                                 
02cb9554: mov     w0, wzr                                    
02cb9558: ldp     x20, x19, [sp, #0x50]                      
02cb955c: ldr     x30, [sp, #0x40]                           
02cb9560: ldp     d9, d8, [sp, #0x30]                        
02cb9564: ldp     d11, d10, [sp, #0x20]                      
02cb9568: ldp     d13, d12, [sp, #0x10]                      
02cb956c: ldp     d15, d14, [sp], #0x60                      
02cb9570: ret                                                
02cb9574: ldr     x0, [x19]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02cb9578: ldr     w8, [x0, #0xe4]                            [62640e4]=0 f=0,0
02cb957c: cbnz    w8, #0x2cb9584                             
02cb9580: bl      #0x2b70f30                                 fn_2b70f30
02cb9584: fadd    s0, s9, s10                                
02cb9588: fcmp    s0, s8                                     
02cb958c: cset    w0, pl                                     
02cb9590: b       #0x2cb9558                                 
