#### CLASS Clicker.ScreenClickerLivestream parent= ScreenBase
#   field _btnHome                       UnityEngine.UI.Button                              off=0x38 attr=1 SerializeField
#   field _livestreamPanel               Livestream.LivestreamPanel                         off=0x40 attr=1 SerializeField
#   field _commentHandler                CommentHandler                                     off=0x48 attr=1 SerializeField
#   field _emojiFx                       UnityEngine.ParticleSystem                         off=0x50 attr=1 SerializeField
#   field _chatInput                     Livestream.ChatInput                               off=0x58 attr=1 SerializeField
#   field _goProcess                     UnityEngine.GameObject                             off=0x60 attr=1 SerializeField
#   field _imgProcess                    UnityEngine.UI.Image                               off=0x68 attr=1 SerializeField
#   field _liveTime                      float                                              off=0x70 attr=1 
#   field _countDownTween                DG.Tweening.Tween                                  off=0x78 attr=1 
## get_CommentHandler() -> CommentHandler
---- Clicker.ScreenClickerLivestream::get_CommentHandler 0x2d710e4
02d710e4: ldr     x0, [x0, #0x48]                            ._commentHandler
02d710e8: ret                                                
## OnInit(UIManager uiManager) -> void
---- Clicker.ScreenClickerLivestream::OnInit 0x2d710ec
02d710ec: stp     x30, x21, [sp, #-0x20]!                    
02d710f0: stp     x20, x19, [sp, #0x10]                      
02d710f4: adrp    x21, #0x6630000                            
02d710f8: mov     x20, x1                                    
02d710fc: mov     x19, x0                                    
02d71100: ldrb    w8, [x21, #0x3a8]                          
02d71104: tbnz    w8, #0, #0x2d71128                         
02d71108: adrp    x0, #0x626c000                             
02d7110c: ldr     x0, [x0, #0x598]                           M:Clicker.ScreenClickerLivestream::OnBtnHomeClick
02d71110: bl      #0x2b70db0                                 fn_2b70db0
02d71114: adrp    x0, #0x6265000                             
02d71118: ldr     x0, [x0, #0x3f0]                           T:UnityEngine.Events.UnityAction
02d7111c: bl      #0x2b70db0                                 fn_2b70db0
02d71120: mov     w8, #1                                     
02d71124: strb    w8, [x21, #0x3a8]                          
02d71128: mov     x0, x19                                    
02d7112c: mov     x1, x20                                    
02d71130: mov     x2, xzr                                    
02d71134: bl      #0x2cdd3c4                                 UIBase::OnInit
02d71138: ldr     x8, [x19, #0x38]                           ._btnHome
02d7113c: cbz     x8, #0x2d711c4                             
02d71140: ldr     x0, [x8, #0x100]                           
02d71144: cbz     x0, #0x2d711c4                             
02d71148: mov     x1, xzr                                    
02d7114c: bl      #0x5b4ce48                                 UnityEngine.Events.UnityEventBase::RemoveAllListeners
02d71150: ldr     x8, [x19, #0x38]                           ._btnHome
02d71154: cbz     x8, #0x2d711c4                             
02d71158: adrp    x9, #0x6265000                             
02d7115c: adrp    x21, #0x626c000                            
02d71160: ldr     x9, [x9, #0x3f0]                           T:UnityEngine.Events.UnityAction
02d71164: ldr     x21, [x21, #0x598]                         M:Clicker.ScreenClickerLivestream::OnBtnHomeClick
02d71168: ldr     x20, [x8, #0x100]                          
02d7116c: ldr     x0, [x9]                                   M:AdsManager::<OnApplicationPause>b__26_0
02d71170: bl      #0x2b7104c                                 fn_2b7104c
02d71174: ldr     x2, [x21]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d71178: mov     x1, x19                                    
02d7117c: mov     x3, xzr                                    
02d71180: mov     x21, x0                                    
02d71184: bl      #0x5b4cf98                                 UnityEngine.Events.UnityAction::.ctor
02d71188: cbz     x20, #0x2d711c4                            
02d7118c: mov     x0, x20                                    
02d71190: mov     x1, x21                                    
02d71194: mov     x2, xzr                                    
02d71198: bl      #0x5b4d0ac                                 UnityEngine.Events.UnityEvent::AddListener
02d7119c: ldr     x0, [x19, #0x58]                           ._chatInput
02d711a0: cbz     x0, #0x2d711c4                             
02d711a4: mov     x1, xzr                                    
02d711a8: bl      #0x2d11580                                 Livestream.ChatInput::OnInit
02d711ac: ldr     x0, [x19, #0x40]                           ._livestreamPanel
02d711b0: cbz     x0, #0x2d711c4                             
02d711b4: ldp     x20, x19, [sp, #0x10]                      
02d711b8: mov     x1, xzr                                    
02d711bc: ldp     x30, x21, [sp], #0x20                      
02d711c0: b       #0x2d11b9c                                 Livestream.LivestreamPanel::Initialized
02d711c4: bl      #0x2b7105c                                 fn_2b7105c
## OnBtnHomeClick() -> void
---- Clicker.ScreenClickerLivestream::OnBtnHomeClick 0x2d711c8
02d711c8: str     x30, [sp, #-0x30]!                         
02d711cc: stp     x22, x21, [sp, #0x10]                      
02d711d0: stp     x20, x19, [sp, #0x20]                      
02d711d4: adrp    x20, #0x6630000                            
02d711d8: mov     x19, x0                                    
02d711dc: ldrb    w8, [x20, #0x3a9]                          
02d711e0: tbnz    w8, #0, #0x2d7121c                         
02d711e4: adrp    x0, #0x6264000                             
02d711e8: ldr     x0, [x0, #0xf90]                           T:System.Action
02d711ec: bl      #0x2b70db0                                 fn_2b70db0
02d711f0: adrp    x0, #0x626c000                             
02d711f4: ldr     x0, [x0, #0x5a0]                           M:Clicker.ScreenClickerLivestream::<OnBtnHomeClick>b__12_0
02d711f8: bl      #0x2b70db0                                 fn_2b70db0
02d711fc: adrp    x0, #0x6265000                             
02d71200: ldr     x0, [x0, #0x310]                           MS:WejoyService.Singleton`1::get_Instance
02d71204: bl      #0x2b70db0                                 fn_2b70db0
02d71208: adrp    x0, #0x626c000                             
02d7120c: ldr     x0, [x0, #0x5a8]                           S:'ingame_home_click'
02d71210: bl      #0x2b70db0                                 fn_2b70db0
02d71214: mov     w8, #1                                     
02d71218: strb    w8, [x20, #0x3a9]                          
02d7121c: bl      #0x2d6eec8                                 Framework.AudioManager::get_Instance
02d71220: cbz     x0, #0x2d712b4                             
02d71224: movi    d1, #0000000000000000                      
02d71228: movi    d2, #0000000000000000                      
02d7122c: adrp    x20, #0x6265000                            
02d71230: fmov    s0, #1.00000000                            
02d71234: adrp    x21, #0x6264000                            
02d71238: adrp    x22, #0x626c000                            
02d7123c: ldr     x20, [x20, #0x310]                         MS:WejoyService.Singleton`1::get_Instance
02d71240: ldr     x21, [x21, #0xf90]                         T:System.Action
02d71244: ldr     x22, [x22, #0x5a0]                         M:Clicker.ScreenClickerLivestream::<OnBtnHomeClick>b__12_0
02d71248: mov     w1, #1                                     
02d7124c: mov     w2, wzr                                    
02d71250: mov     w3, wzr                                    
02d71254: bl      #0x2d6f03c                                 Framework.AudioManager::PlaySound
02d71258: ldr     x0, [x20]                                  M:AdsManager::<OnApplicationPause>b__26_0
02d7125c: bl      #0x3be7218                                 fn_3be7218
02d71260: ldr     x8, [x21]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d71264: mov     x20, x0                                    
02d71268: mov     x0, x8                                     
02d7126c: bl      #0x2b7104c                                 fn_2b7104c
02d71270: ldr     x2, [x22]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d71274: mov     x1, x19                                    
02d71278: mov     x3, xzr                                    
02d7127c: mov     x21, x0                                    
02d71280: bl      #0x4d8ddbc                                 System.Action::.ctor
02d71284: cbz     x20, #0x2d712b4                            
02d71288: adrp    x8, #0x626c000                             
02d7128c: mov     x0, x20                                    
02d71290: mov     x2, x21                                    
02d71294: ldr     x8, [x8, #0x5a8]                           S:'ingame_home_click'
02d71298: ldp     x20, x19, [sp, #0x20]                      
02d7129c: ldp     x22, x21, [sp, #0x10]                      
02d712a0: mov     w3, #1                                     
02d712a4: ldr     x1, [x8]                                   M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d712a8: mov     x4, xzr                                    
02d712ac: ldr     x30, [sp], #0x30                           
02d712b0: b       #0x2c89698                                 AdsManager::ShowInter
02d712b4: bl      #0x2b7105c                                 fn_2b7105c
## OnDestroy() -> void
---- Clicker.ScreenClickerLivestream::OnDestroy 0x2d712b8
02d712b8: ldr     x0, [x0, #0x78]                            ._countDownTween
02d712bc: cbz     x0, #0x2d712cc                             
02d712c0: mov     w1, wzr                                    
02d712c4: mov     x2, xzr                                    
02d712c8: b       #0x2d8fe94                                 DG.Tweening.TweenExtensions::Kill
02d712cc: ret                                                
## StartLive() -> void
---- Clicker.ScreenClickerLivestream::StartLive 0x2d712d0
02d712d0: str     d8, [sp, #-0x30]!                          
02d712d4: str     x30, [sp, #8]                              
02d712d8: stp     x22, x21, [sp, #0x10]                      
02d712dc: stp     x20, x19, [sp, #0x20]                      
02d712e0: adrp    x20, #0x6630000                            
02d712e4: mov     x19, x0                                    
02d712e8: ldrb    w8, [x20, #0x3aa]                          
02d712ec: tbnz    w8, #0, #0x2d71340                         
02d712f0: adrp    x0, #0x6267000                             
02d712f4: ldr     x0, [x0, #0xd50]                           MS:MonoSingleton`1::get_Instance
02d712f8: bl      #0x2b70db0                                 fn_2b70db0
02d712fc: adrp    x0, #0x626b000                             
02d71300: ldr     x0, [x0, #0xee0]                           MS:MonoSingleton`1::get_Instance
02d71304: bl      #0x2b70db0                                 fn_2b70db0
02d71308: adrp    x0, #0x6263000                             
02d7130c: ldr     x0, [x0, #0x918]                           T:UnityEngine.Object
02d71310: bl      #0x2b70db0                                 fn_2b70db0
02d71314: adrp    x0, #0x626c000                             
02d71318: ldr     x0, [x0, #0x5b0]                           M:Clicker.ScreenClickerLivestream::<StartLive>b__14_0
02d7131c: bl      #0x2b70db0                                 fn_2b70db0
02d71320: adrp    x0, #0x6264000                             
02d71324: ldr     x0, [x0, #0xe8]                            T:DG.Tweening.TweenCallback
02d71328: bl      #0x2b70db0                                 fn_2b70db0
02d7132c: adrp    x0, #0x6267000                             
02d71330: ldr     x0, [x0, #0x978]                           MS:DG.Tweening.TweenSettingsExtensions::SetEase
02d71334: bl      #0x2b70db0                                 fn_2b70db0
02d71338: mov     w8, #1                                     
02d7133c: strb    w8, [x20, #0x3aa]                          
02d71340: bl      #0x2d6eec8                                 Framework.AudioManager::get_Instance
02d71344: cbz     x0, #0x2d714d8                             
02d71348: movi    d1, #0000000000000000                      
02d7134c: movi    d2, #0000000000000000                      
02d71350: adrp    x20, #0x6267000                            
02d71354: fmov    s0, #1.00000000                            
02d71358: ldr     x20, [x20, #0xd50]                         MS:MonoSingleton`1::get_Instance
02d7135c: mov     w1, #1                                     
02d71360: mov     w2, wzr                                    
02d71364: mov     w3, wzr                                    
02d71368: bl      #0x2d6f03c                                 Framework.AudioManager::PlaySound
02d7136c: ldr     x0, [x20]                                  S:'didu'
02d71370: bl      #0x3769600                                 fn_3769600
02d71374: cbz     x0, #0x2d714d8                             
02d71378: adrp    x20, #0x6263000                            
02d7137c: mov     w1, #4                                     
02d71380: mov     x2, xzr                                    
02d71384: ldr     x20, [x20, #0x918]                         T:UnityEngine.Object
02d71388: bl      #0x2cc6ee0                                 Framework.VibrationManager::Haptic
02d7138c: ldr     x0, [x20]                                  &2c5bbd4(=a9bd7bfdd503233f)
02d71390: ldr     x20, [x19, #0x50]                          ._emojiFx
02d71394: ldr     w8, [x0, #0xe4]                            [62670e4]=0 f=0,0
02d71398: cbnz    w8, #0x2d713a0                             
02d7139c: bl      #0x2b70f30                                 fn_2b70f30
02d713a0: mov     x0, x20                                    
02d713a4: mov     x1, xzr                                    
02d713a8: mov     x2, xzr                                    
02d713ac: bl      #0x5b3666c                                 UnityEngine.Object::op_Inequality
02d713b0: tbz     w0, #0, #0x2d713c4                         
02d713b4: ldr     x0, [x19, #0x50]                           ._emojiFx
02d713b8: cbz     x0, #0x2d714d8                             
02d713bc: mov     x1, xzr                                    
02d713c0: bl      #0x5bba8cc                                 UnityEngine.ParticleSystem::Play
02d713c4: ldr     x0, [x19, #0x58]                           ._chatInput
02d713c8: cbz     x0, #0x2d714d8                             
02d713cc: mov     x1, xzr                                    
02d713d0: bl      #0x5b339ec                                 UnityEngine.Component::get_gameObject
02d713d4: cbz     x0, #0x2d714d8                             
02d713d8: adrp    x20, #0x626b000                            
02d713dc: mov     w1, #1                                     
02d713e0: mov     x2, xzr                                    
02d713e4: ldr     x20, [x20, #0xee0]                         MS:MonoSingleton`1::get_Instance
02d713e8: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d713ec: ldr     x0, [x20]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d713f0: bl      #0x3769600                                 fn_3769600
02d713f4: cbz     x0, #0x2d714d8                             
02d713f8: mov     w1, #1                                     
02d713fc: mov     x2, xzr                                    
02d71400: mov     w20, #1                                    
02d71404: bl      #0x2d63a4c                                 Clicker.KeycapMakerController::ShowTapHandTutorial
02d71408: ldr     x8, [x19, #0x48]                           ._commentHandler
02d7140c: cbz     x8, #0x2d714d8                             
02d71410: ldr     x0, [x19, #0x60]                           ._goProcess
02d71414: strb    w20, [x8, #0x20]                           
02d71418: cbz     x0, #0x2d714d8                             
02d7141c: mov     w1, #1                                     
02d71420: mov     x2, xzr                                    
02d71424: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d71428: ldr     x0, [x19, #0x68]                           ._imgProcess
02d7142c: mov     w1, wzr                                    
02d71430: mov     x2, xzr                                    
02d71434: bl      #0x2d9d5d0                                 DG.Tweening.ShortcutExtensions::DOKill
02d71438: ldr     x0, [x19, #0x68]                           ._imgProcess
02d7143c: cbz     x0, #0x2d714d8                             
02d71440: movi    d0, #0000000000000000                      
02d71444: adrp    x20, #0x6267000                            
02d71448: adrp    x21, #0x6264000                            
02d7144c: adrp    x22, #0x626c000                            
02d71450: ldr     x20, [x20, #0x978]                         MS:DG.Tweening.TweenSettingsExtensions::SetEase
02d71454: ldr     x21, [x21, #0xe8]                          T:DG.Tweening.TweenCallback
02d71458: ldr     x22, [x22, #0x5b0]                         M:Clicker.ScreenClickerLivestream::<StartLive>b__14_0
02d7145c: mov     x1, xzr                                    
02d71460: bl      #0x5c53138                                 UnityEngine.UI.Image::set_fillAmount
02d71464: fmov    s0, #1.00000000                            
02d71468: ldr     x0, [x19, #0x68]                           ._imgProcess
02d7146c: ldr     s1, [x19, #0x70]                           ._liveTime
02d71470: mov     x1, xzr                                    
02d71474: bl      #0x2c78b44                                 DG.Tweening.DOTweenModuleUI::DOFillAmount
02d71478: ldr     x2, [x20]                                  S:'didu'
02d7147c: mov     w1, #1                                     
02d71480: bl      #0x336fa0c                                 fn_336fa0c
02d71484: ldr     x0, [x21]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d71488: ldr     s8, [x19, #0x70]                           ._liveTime
02d7148c: bl      #0x2b7104c                                 fn_2b7104c
02d71490: ldr     x2, [x22]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d71494: mov     x1, x19                                    
02d71498: mov     x3, xzr                                    
02d7149c: mov     x20, x0                                    
02d714a0: bl      #0x2d89dc4                                 DG.Tweening.TweenCallback::.ctor
02d714a4: fmov    s0, s8                                     
02d714a8: mov     x0, x20                                    
02d714ac: mov     w1, #1                                     
02d714b0: mov     x2, xzr                                    
02d714b4: bl      #0x2d8f37c                                 DG.Tweening.DOVirtual::DelayedCall
02d714b8: str     x0, [x19, #0x78]!                          ._countDownTween
02d714bc: mov     x1, x0                                     
02d714c0: mov     x0, x19                                    
02d714c4: ldp     x20, x19, [sp, #0x20]                      
02d714c8: ldp     x22, x21, [sp, #0x10]                      
02d714cc: ldr     x30, [sp, #8]                              
02d714d0: ldr     d8, [sp], #0x30                            
02d714d4: b       #0x2b70d54                                 
02d714d8: bl      #0x2b7105c                                 fn_2b7105c
## OnShow() -> void
---- Clicker.ScreenClickerLivestream::OnShow 0x2d714dc
02d714dc: stp     x30, x21, [sp, #-0x20]!                    
02d714e0: stp     x20, x19, [sp, #0x10]                      
02d714e4: adrp    x21, #0x6630000                            
02d714e8: adrp    x20, #0x6263000                            
02d714ec: mov     x19, x0                                    
02d714f0: ldrb    w8, [x21, #0x3ab]                          
02d714f4: ldr     x20, [x20, #0x918]                         T:UnityEngine.Object
02d714f8: tbnz    w8, #0, #0x2d71528                         
02d714fc: adrp    x0, #0x6266000                             
02d71500: ldr     x0, [x0, #0x750]                           MS:DataManager::GetData
02d71504: bl      #0x2b70db0                                 fn_2b70db0
02d71508: adrp    x0, #0x6266000                             
02d7150c: ldr     x0, [x0, #0x658]                           MS:MonoSingleton`1::get_Instance
02d71510: bl      #0x2b70db0                                 fn_2b70db0
02d71514: adrp    x0, #0x6263000                             
02d71518: ldr     x0, [x0, #0x918]                           T:UnityEngine.Object
02d7151c: bl      #0x2b70db0                                 fn_2b70db0
02d71520: mov     w8, #1                                     
02d71524: strb    w8, [x21, #0x3ab]                          
02d71528: ldr     x0, [x20]                                  &2c5bbd4(=a9bd7bfdd503233f)
02d7152c: ldr     x20, [x19, #0x40]                          ._livestreamPanel
02d71530: ldr     w8, [x0, #0xe4]                            [62630e4]=0 f=0,0
02d71534: cbnz    w8, #0x2d7153c                             
02d71538: bl      #0x2b70f30                                 fn_2b70f30
02d7153c: adrp    x21, #0x6266000                            
02d71540: mov     x0, x20                                    
02d71544: mov     x1, xzr                                    
02d71548: ldr     x21, [x21, #0x658]                         MS:MonoSingleton`1::get_Instance
02d7154c: mov     x2, xzr                                    
02d71550: bl      #0x5b3666c                                 UnityEngine.Object::op_Inequality
02d71554: tbz     w0, #0, #0x2d71568                         
02d71558: ldr     x0, [x19, #0x40]                           ._livestreamPanel
02d7155c: cbz     x0, #0x2d71568                             
02d71560: mov     x1, xzr                                    
02d71564: bl      #0x2d11ba0                                 Livestream.LivestreamPanel::OnShow
02d71568: mov     x0, x19                                    
02d7156c: mov     x1, xzr                                    
02d71570: bl      #0x2cdd6b8                                 UIBase::OnShow
02d71574: ldr     x0, [x21]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d71578: bl      #0x3769600                                 fn_3769600
02d7157c: cbz     x0, #0x2d715d4                             
02d71580: adrp    x8, #0x6266000                             
02d71584: ldr     x8, [x8, #0x750]                           MS:DataManager::GetData
02d71588: ldr     x1, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d7158c: bl      #0x3168dd0                                 fn_3168dd0
02d71590: cbz     x0, #0x2d715d4                             
02d71594: ldr     x8, [x0, #0x20]                            &2c5bd40(=14c8d27fd503245f)
02d71598: cbz     x8, #0x2d715d4                             
02d7159c: ldrb    w8, [x8, #0x3a]                            
02d715a0: cbz     w8, #0x2d715c4                             
02d715a4: ldr     x0, [x19, #0x38]                           ._btnHome
02d715a8: cbz     x0, #0x2d715d4                             
02d715ac: mov     x1, xzr                                    
02d715b0: bl      #0x5b339ec                                 UnityEngine.Component::get_gameObject
02d715b4: cbz     x0, #0x2d715d4                             
02d715b8: mov     w1, wzr                                    
02d715bc: mov     x2, xzr                                    
02d715c0: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d715c4: mov     x0, x19                                    
02d715c8: ldp     x20, x19, [sp, #0x10]                      
02d715cc: ldp     x30, x21, [sp], #0x20                      
02d715d0: b       #0x2d712d0                                 Clicker.ScreenClickerLivestream::StartLive
02d715d4: bl      #0x2b7105c                                 fn_2b7105c
## OnHide() -> void
---- Clicker.ScreenClickerLivestream::OnHide 0x2d715d8
02d715d8: stp     x30, x19, [sp, #-0x10]!                    
02d715dc: mov     x1, xzr                                    
02d715e0: mov     x19, x0                                    
02d715e4: bl      #0x2cddc10                                 UIBase::OnHide
02d715e8: ldr     x0, [x19, #0x40]                           ._livestreamPanel
02d715ec: cbz     x0, #0x2d7162c                             
02d715f0: mov     x1, xzr                                    
02d715f4: bl      #0x2d11cdc                                 Livestream.LivestreamPanel::OnHide
02d715f8: ldr     x0, [x19, #0x50]                           ._emojiFx
02d715fc: cbz     x0, #0x2d7162c                             
02d71600: mov     x1, xzr                                    
02d71604: bl      #0x5bba9c0                                 UnityEngine.ParticleSystem::Stop
02d71608: ldr     x0, [x19, #0x50]                           ._emojiFx
02d7160c: cbz     x0, #0x2d7162c                             
02d71610: mov     x1, xzr                                    
02d71614: bl      #0x5bbaa90                                 UnityEngine.ParticleSystem::Clear
02d71618: ldr     x8, [x19, #0x48]                           ._commentHandler
02d7161c: cbz     x8, #0x2d7162c                             
02d71620: strb    wzr, [x8, #0x20]                           
02d71624: ldp     x30, x19, [sp], #0x10                      
02d71628: ret                                                
02d7162c: bl      #0x2b7105c                                 fn_2b7105c
## .ctor() -> void
---- Clicker.ScreenClickerLivestream::.ctor 0x2d71630
02d71630: mov     w8, #0x41200000                            
02d71634: mov     x1, xzr                                    
02d71638: str     w8, [x0, #0x70]                            ._liveTime
02d7163c: b       #0x2cde678                                 ScreenBase::.ctor
## <OnBtnHomeClick>b__12_0() -> void
---- Clicker.ScreenClickerLivestream::<OnBtnHomeClick>b__12_0 0x2d71640
02d71640: str     x30, [sp, #-0x20]!                         
02d71644: stp     x20, x19, [sp, #0x10]                      
02d71648: adrp    x20, #0x6630000                            
02d7164c: mov     x19, x0                                    
02d71650: ldrb    w8, [x20, #0x3ac]                          
02d71654: tbnz    w8, #0, #0x2d7166c                         
02d71658: adrp    x0, #0x626a000                             
02d7165c: ldr     x0, [x0, #0xc08]                           MS:UIManager::ShowPopup
02d71660: bl      #0x2b70db0                                 fn_2b70db0
02d71664: mov     w8, #1                                     
02d71668: strb    w8, [x20, #0x3ac]                          
02d7166c: ldr     x0, [x19, #0x30]                           
02d71670: cbz     x0, #0x2d7168c                             
02d71674: adrp    x8, #0x626a000                             
02d71678: ldr     x8, [x8, #0xc08]                           MS:UIManager::ShowPopup
02d7167c: ldp     x20, x19, [sp, #0x10]                      
02d71680: ldr     x1, [x8]                                   T:type56879(k15)
02d71684: ldr     x30, [sp], #0x20                           
02d71688: b       #0x33fbfac                                 
02d7168c: bl      #0x2b7105c                                 fn_2b7105c
## <StartLive>b__14_0() -> void
---- Clicker.ScreenClickerLivestream::<StartLive>b__14_0 0x2d71690
02d71690: str     x30, [sp, #-0x30]!                         
02d71694: stp     x22, x21, [sp, #0x10]                      
02d71698: stp     x20, x19, [sp, #0x20]                      
02d7169c: adrp    x20, #0x6630000                            
02d716a0: mov     x19, x0                                    
02d716a4: ldrb    w8, [x20, #0x3ad]                          
02d716a8: tbnz    w8, #0, #0x2d716d8                         
02d716ac: adrp    x0, #0x6264000                             
02d716b0: ldr     x0, [x0, #0xf90]                           T:System.Action
02d716b4: bl      #0x2b70db0                                 fn_2b70db0
02d716b8: adrp    x0, #0x626b000                             
02d716bc: ldr     x0, [x0, #0xee0]                           MS:MonoSingleton`1::get_Instance
02d716c0: bl      #0x2b70db0                                 fn_2b70db0
02d716c4: adrp    x0, #0x626c000                             
02d716c8: ldr     x0, [x0, #0x5b8]                           M:Clicker.ScreenClickerLivestream::<StartLive>b__14_1
02d716cc: bl      #0x2b70db0                                 fn_2b70db0
02d716d0: mov     w8, #1                                     
02d716d4: strb    w8, [x20, #0x3ad]                          
02d716d8: ldr     x0, [x19, #0x60]                           ._goProcess
02d716dc: cbz     x0, #0x2d71778                             
02d716e0: adrp    x20, #0x626b000                            
02d716e4: mov     w1, wzr                                    
02d716e8: mov     x2, xzr                                    
02d716ec: ldr     x20, [x20, #0xee0]                         MS:MonoSingleton`1::get_Instance
02d716f0: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d716f4: ldr     x0, [x20]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d716f8: bl      #0x3769600                                 fn_3769600
02d716fc: cbz     x0, #0x2d71778                             
02d71700: adrp    x21, #0x6264000                            
02d71704: adrp    x22, #0x626c000                            
02d71708: mov     w1, wzr                                    
02d7170c: ldr     x21, [x21, #0xf90]                         T:System.Action
02d71710: ldr     x22, [x22, #0x5b8]                         M:Clicker.ScreenClickerLivestream::<StartLive>b__14_1
02d71714: mov     x2, xzr                                    
02d71718: bl      #0x2d63a4c                                 Clicker.KeycapMakerController::ShowTapHandTutorial
02d7171c: ldr     x8, [x19]                                  
02d71720: mov     x0, x19                                    
02d71724: ldp     x9, x1, [x8, #0x198]                       
02d71728: blr     x9                                         
02d7172c: ldr     x0, [x20]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d71730: bl      #0x3769600                                 fn_3769600
02d71734: ldr     x8, [x21]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d71738: mov     x20, x0                                    
02d7173c: mov     x0, x8                                     
02d71740: bl      #0x2b7104c                                 fn_2b7104c
02d71744: ldr     x2, [x22]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d71748: mov     x1, x19                                    
02d7174c: mov     x3, xzr                                    
02d71750: mov     x21, x0                                    
02d71754: bl      #0x4d8ddbc                                 System.Action::.ctor
02d71758: cbz     x20, #0x2d71778                            
02d7175c: mov     x0, x20                                    
02d71760: mov     x1, x21                                    
02d71764: mov     x2, xzr                                    
02d71768: ldp     x20, x19, [sp, #0x20]                      
02d7176c: ldp     x22, x21, [sp, #0x10]                      
02d71770: ldr     x30, [sp], #0x30                           
02d71774: b       #0x2d6d514                                 Clicker.KeycapMakerController::MoveResultToComplete
02d71778: bl      #0x2b7105c                                 fn_2b7105c
## <StartLive>b__14_1() -> void
---- Clicker.ScreenClickerLivestream::<StartLive>b__14_1 0x2d7177c
02d7177c: stp     x30, x21, [sp, #-0x20]!                    
02d71780: stp     x20, x19, [sp, #0x10]                      
02d71784: adrp    x20, #0x6630000                            
02d71788: adrp    x21, #0x626b000                            
02d7178c: mov     x19, x0                                    
02d71790: ldrb    w8, [x20, #0x3ae]                          
02d71794: ldr     x21, [x21, #0xee0]                         MS:MonoSingleton`1::get_Instance
02d71798: tbnz    w8, #0, #0x2d717bc                         
02d7179c: adrp    x0, #0x626b000                             
02d717a0: ldr     x0, [x0, #0xee0]                           MS:MonoSingleton`1::get_Instance
02d717a4: bl      #0x2b70db0                                 fn_2b70db0
02d717a8: adrp    x0, #0x626c000                             
02d717ac: ldr     x0, [x0, #0x5c0]                           MS:UIManager::ShowPopup
02d717b0: bl      #0x2b70db0                                 fn_2b70db0
02d717b4: mov     w8, #1                                     
02d717b8: strb    w8, [x20, #0x3ae]                          
02d717bc: ldr     x0, [x21]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d717c0: bl      #0x3769600                                 fn_3769600
02d717c4: cbz     x0, #0x2d717f0                             
02d717c8: mov     x1, xzr                                    
02d717cc: bl      #0x2d6db10                                 Clicker.KeycapMakerController::ShowHandComplete
02d717d0: ldr     x0, [x19, #0x30]                           
02d717d4: cbz     x0, #0x2d717f0                             
02d717d8: adrp    x8, #0x626c000                             
02d717dc: ldr     x8, [x8, #0x5c0]                           MS:UIManager::ShowPopup
02d717e0: ldp     x20, x19, [sp, #0x10]                      
02d717e4: ldr     x1, [x8]                                   M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d717e8: ldp     x30, x21, [sp], #0x20                      
02d717ec: b       #0x33fbfac                                 
02d717f0: bl      #0x2b7105c                                 fn_2b7105c
