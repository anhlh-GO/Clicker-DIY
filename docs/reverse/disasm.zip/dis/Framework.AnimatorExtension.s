#### CLASS Framework.AnimatorExtension parent= object
## HasParameterOfType(UnityEngine.Animator animator, string paramName, UnityEngine.AnimatorControllerParameterType paramType) -> bool
---- Framework.AnimatorExtension::HasParameterOfType 0x2cb84e8
02cb84e8: stp     x30, x23, [sp, #-0x30]!                    
02cb84ec: stp     x22, x21, [sp, #0x10]                      
02cb84f0: stp     x20, x19, [sp, #0x20]                      
02cb84f4: mov     x20, x1                                    
02cb84f8: mov     x21, x0                                    
02cb84fc: mov     x0, x1                                     
02cb8500: mov     x1, xzr                                    
02cb8504: mov     w19, w2                                    
02cb8508: bl      #0x4ca6234                                 System.String::IsNullOrEmpty
02cb850c: tbnz    w0, #0, #0x2cb858c                         
02cb8510: cbz     x21, #0x2cb85a8                            
02cb8514: mov     x0, x21                                    
02cb8518: mov     x1, xzr                                    
02cb851c: bl      #0x5adbad8                                 UnityEngine.Animator::get_parameters
02cb8520: cbz     x0, #0x2cb85a8                             
02cb8524: ldr     w8, [x0, #0x18]                            
02cb8528: mov     x21, x0                                    
02cb852c: cmp     w8, #1                                     
02cb8530: b.lt    #0x2cb858c                                 
02cb8534: mov     w23, wzr                                   
02cb8538: cmp     w23, w8                                    
02cb853c: b.hs    #0x2cb85ac                                 
02cb8540: add     x8, x21, w23, sxtw #3                      
02cb8544: ldr     x22, [x8, #0x20]                           
02cb8548: cbz     x22, #0x2cb85a8                            
02cb854c: mov     x0, x22                                    
02cb8550: mov     x1, xzr                                    
02cb8554: bl      #0x5adbffc                                 UnityEngine.AnimatorControllerParameter::get_type
02cb8558: cmp     w0, w19                                    
02cb855c: b.ne    #0x2cb857c                                 
02cb8560: mov     x0, x22                                    
02cb8564: mov     x1, xzr                                    
02cb8568: bl      #0x5adbff4                                 UnityEngine.AnimatorControllerParameter::get_name
02cb856c: mov     x1, x20                                    
02cb8570: mov     x2, xzr                                    
02cb8574: bl      #0x4ca52b8                                 System.String::op_Equality
02cb8578: tbnz    w0, #0, #0x2cb85a0                         
02cb857c: ldr     w8, [x21, #0x18]                           
02cb8580: add     w23, w23, #1                               
02cb8584: cmp     w23, w8                                    
02cb8588: b.lt    #0x2cb8538                                 
02cb858c: mov     w0, wzr                                    
02cb8590: ldp     x20, x19, [sp, #0x20]                      
02cb8594: ldp     x22, x21, [sp, #0x10]                      
02cb8598: ldp     x30, x23, [sp], #0x30                      
02cb859c: ret                                                
02cb85a0: mov     w0, #1                                     
02cb85a4: b       #0x2cb8590                                 
02cb85a8: bl      #0x2b7105c                                 fn_2b7105c
02cb85ac: bl      #0x2b71064                                 fn_2b71064
## ContainsAnimation(UnityEngine.Animator animator, string animationName) -> bool
---- Framework.AnimatorExtension::ContainsAnimation 0x2cb85b0
02cb85b0: str     x30, [sp, #-0x30]!                         
02cb85b4: stp     x22, x21, [sp, #0x10]                      
02cb85b8: stp     x20, x19, [sp, #0x20]                      
02cb85bc: cbz     x0, #0x2cb8668                             
02cb85c0: mov     x20, x1                                    
02cb85c4: mov     x1, xzr                                    
02cb85c8: bl      #0x5adbb8c                                 UnityEngine.Animator::get_runtimeAnimatorController
02cb85cc: cbz     x20, #0x2cb8668                            
02cb85d0: mov     x19, x0                                    
02cb85d4: mov     x0, x20                                    
02cb85d8: mov     x1, xzr                                    
02cb85dc: bl      #0x4caafcc                                 System.String::ToLowerInvariant
02cb85e0: cbz     x19, #0x2cb8668                            
02cb85e4: mov     x20, x0                                    
02cb85e8: mov     x0, x19                                    
02cb85ec: mov     x1, xzr                                    
02cb85f0: bl      #0x5adc32c                                 UnityEngine.RuntimeAnimatorController::get_animationClips
02cb85f4: cbz     x0, #0x2cb8668                             
02cb85f8: mov     x21, xzr                                   
02cb85fc: ldr     w22, [x0, #0x18]                           
02cb8600: cmp     w21, w22                                   
02cb8604: b.ge    #0x2cb866c                                 
02cb8608: mov     x0, x19                                    
02cb860c: mov     x1, xzr                                    
02cb8610: bl      #0x5adc32c                                 UnityEngine.RuntimeAnimatorController::get_animationClips
02cb8614: cbz     x0, #0x2cb8668                             
02cb8618: ldr     w8, [x0, #0x18]                            
02cb861c: cmp     w21, w8                                    
02cb8620: b.hs    #0x2cb8684                                 
02cb8624: add     x8, x0, x21, lsl #3                        
02cb8628: ldr     x0, [x8, #0x20]                            
02cb862c: cbz     x0, #0x2cb8668                             
02cb8630: mov     x1, xzr                                    
02cb8634: bl      #0x5b3bba4                                 UnityEngine.Object::get_name
02cb8638: cbz     x0, #0x2cb8668                             
02cb863c: mov     x1, xzr                                    
02cb8640: bl      #0x4caafcc                                 System.String::ToLowerInvariant
02cb8644: mov     x1, x20                                    
02cb8648: mov     x2, xzr                                    
02cb864c: bl      #0x4ca52b8                                 System.String::op_Equality
02cb8650: tbnz    w0, #0, #0x2cb866c                         
02cb8654: mov     x0, x19                                    
02cb8658: mov     x1, xzr                                    
02cb865c: bl      #0x5adc32c                                 UnityEngine.RuntimeAnimatorController::get_animationClips
02cb8660: add     x21, x21, #1                               
02cb8664: cbnz    x0, #0x2cb85fc                             
02cb8668: bl      #0x2b7105c                                 fn_2b7105c
02cb866c: cmp     w21, w22                                   
02cb8670: ldp     x20, x19, [sp, #0x20]                      
02cb8674: ldp     x22, x21, [sp, #0x10]                      
02cb8678: cset    w0, lt                                     
02cb867c: ldr     x30, [sp], #0x30                           
02cb8680: ret                                                
02cb8684: bl      #0x2b71064                                 fn_2b71064
## ContainsAnimation(UnityEngine.Animator animator, UnityEngine.AnimationClip animationClip) -> bool
---- Framework.AnimatorExtension::ContainsAnimation 0x2cb8688
02cb8688: str     x30, [sp, #-0x40]!                         
02cb868c: stp     x24, x23, [sp, #0x10]                      
02cb8690: stp     x22, x21, [sp, #0x20]                      
02cb8694: stp     x20, x19, [sp, #0x30]                      
02cb8698: adrp    x21, #0x662f000                            
02cb869c: mov     x19, x1                                    
02cb86a0: mov     x20, x0                                    
02cb86a4: ldrb    w8, [x21, #0xbe2]                          
02cb86a8: tbnz    w8, #0, #0x2cb86c0                         
02cb86ac: adrp    x0, #0x6263000                             
02cb86b0: ldr     x0, [x0, #0x918]                           T:UnityEngine.Object
02cb86b4: bl      #0x2b70db0                                 fn_2b70db0
02cb86b8: mov     w8, #1                                     
02cb86bc: strb    w8, [x21, #0xbe2]                          
02cb86c0: cbz     x20, #0x2cb875c                            
02cb86c4: mov     x0, x20                                    
02cb86c8: mov     x1, xzr                                    
02cb86cc: bl      #0x5adbb8c                                 UnityEngine.Animator::get_runtimeAnimatorController
02cb86d0: cbz     x0, #0x2cb875c                             
02cb86d4: mov     x1, xzr                                    
02cb86d8: mov     x20, x0                                    
02cb86dc: bl      #0x5adc32c                                 UnityEngine.RuntimeAnimatorController::get_animationClips
02cb86e0: cbz     x0, #0x2cb875c                             
02cb86e4: adrp    x22, #0x6263000                            
02cb86e8: mov     x23, xzr                                   
02cb86ec: ldr     x22, [x22, #0x918]                         T:UnityEngine.Object
02cb86f0: ldrsw   x24, [x0, #0x18]                           
02cb86f4: cmp     x23, x24                                   
02cb86f8: b.ge    #0x2cb8760                                 
02cb86fc: mov     x0, x20                                    
02cb8700: mov     x1, xzr                                    
02cb8704: bl      #0x5adc32c                                 UnityEngine.RuntimeAnimatorController::get_animationClips
02cb8708: cbz     x0, #0x2cb875c                             
02cb870c: ldr     w8, [x0, #0x18]                            &2c5d934(=d65f03c0d503245f)
02cb8710: cmp     x23, x8                                    
02cb8714: b.hs    #0x2cb877c                                 
02cb8718: ldr     x8, [x22]                                  &2c5bbd4(=a9bd7bfdd503233f)
02cb871c: add     x9, x0, x23, lsl #3                        &6263000
02cb8720: ldr     w10, [x8, #0xe4]                           
02cb8724: ldr     x21, [x9, #0x20]                           
02cb8728: cbnz    w10, #0x2cb8734                            
02cb872c: mov     x0, x8                                     
02cb8730: bl      #0x2b70f30                                 fn_2b70f30
02cb8734: mov     x0, x21                                    
02cb8738: mov     x1, x19                                    
02cb873c: mov     x2, xzr                                    
02cb8740: bl      #0x5b37d84                                 UnityEngine.Object::op_Equality
02cb8744: tbnz    w0, #0, #0x2cb8760                         
02cb8748: mov     x0, x20                                    
02cb874c: mov     x1, xzr                                    
02cb8750: add     x23, x23, #1                               
02cb8754: bl      #0x5adc32c                                 UnityEngine.RuntimeAnimatorController::get_animationClips
02cb8758: cbnz    x0, #0x2cb86f0                             
02cb875c: bl      #0x2b7105c                                 fn_2b7105c
02cb8760: cmp     x23, x24                                   
02cb8764: ldp     x20, x19, [sp, #0x30]                      
02cb8768: ldp     x22, x21, [sp, #0x20]                      
02cb876c: cset    w0, lt                                     
02cb8770: ldp     x24, x23, [sp, #0x10]                      
02cb8774: ldr     x30, [sp], #0x40                           
02cb8778: ret                                                
02cb877c: bl      #0x2b71064                                 fn_2b71064
## TryGetAnimation(UnityEngine.Animator animator, string animationName, UnityEngine.AnimationClip animationClip) -> bool
---- Framework.AnimatorExtension::TryGetAnimation 0x2cb8780
02cb8780: str     x30, [sp, #-0x40]!                         
02cb8784: stp     x24, x23, [sp, #0x10]                      
02cb8788: stp     x22, x21, [sp, #0x20]                      
02cb878c: stp     x20, x19, [sp, #0x30]                      
02cb8790: mov     x21, x1                                    
02cb8794: mov     x20, x0                                    
02cb8798: mov     x0, x2                                     
02cb879c: mov     x1, xzr                                    
02cb87a0: mov     x19, x2                                    
02cb87a4: str     xzr, [x2]                                  
02cb87a8: bl      #0x2b70d54                                 fn_2b70d54
02cb87ac: cbz     x20, #0x2cb8858                            
02cb87b0: mov     x0, x20                                    
02cb87b4: mov     x1, xzr                                    
02cb87b8: bl      #0x5adbb8c                                 UnityEngine.Animator::get_runtimeAnimatorController
02cb87bc: cbz     x21, #0x2cb8858                            
02cb87c0: mov     x20, x0                                    
02cb87c4: mov     x0, x21                                    
02cb87c8: mov     x1, xzr                                    
02cb87cc: bl      #0x4caafcc                                 System.String::ToLowerInvariant
02cb87d0: cbz     x20, #0x2cb8858                            
02cb87d4: mov     x21, x0                                    
02cb87d8: mov     x0, x20                                    
02cb87dc: mov     x1, xzr                                    
02cb87e0: bl      #0x5adc32c                                 UnityEngine.RuntimeAnimatorController::get_animationClips
02cb87e4: cbz     x0, #0x2cb8858                             
02cb87e8: mov     w22, #4                                    
02cb87ec: ldr     w23, [x0, #0x18]                           
02cb87f0: sub     x24, x22, #4                               
02cb87f4: cmp     w24, w23                                   
02cb87f8: b.ge    #0x2cb8888                                 
02cb87fc: mov     x0, x20                                    
02cb8800: mov     x1, xzr                                    
02cb8804: bl      #0x5adc32c                                 UnityEngine.RuntimeAnimatorController::get_animationClips
02cb8808: cbz     x0, #0x2cb8858                             
02cb880c: ldr     w8, [x0, #0x18]                            
02cb8810: cmp     w24, w8                                    
02cb8814: b.hs    #0x2cb88a4                                 
02cb8818: ldr     x0, [x0, x22, lsl #3]                      
02cb881c: cbz     x0, #0x2cb8858                             
02cb8820: mov     x1, xzr                                    
02cb8824: bl      #0x5b3bba4                                 UnityEngine.Object::get_name
02cb8828: cbz     x0, #0x2cb8858                             
02cb882c: mov     x1, xzr                                    
02cb8830: bl      #0x4caafcc                                 System.String::ToLowerInvariant
02cb8834: mov     x1, x21                                    
02cb8838: mov     x2, xzr                                    
02cb883c: bl      #0x4ca52b8                                 System.String::op_Equality
02cb8840: tbnz    w0, #0, #0x2cb885c                         
02cb8844: mov     x0, x20                                    
02cb8848: mov     x1, xzr                                    
02cb884c: bl      #0x5adc32c                                 UnityEngine.RuntimeAnimatorController::get_animationClips
02cb8850: add     x22, x22, #1                               
02cb8854: cbnz    x0, #0x2cb87ec                             
02cb8858: bl      #0x2b7105c                                 fn_2b7105c
02cb885c: mov     x0, x20                                    
02cb8860: mov     x1, xzr                                    
02cb8864: bl      #0x5adc32c                                 UnityEngine.RuntimeAnimatorController::get_animationClips
02cb8868: cbz     x0, #0x2cb8858                             
02cb886c: ldr     w8, [x0, #0x18]                            
02cb8870: cmp     w24, w8                                    
02cb8874: b.hs    #0x2cb88a4                                 
02cb8878: ldr     x1, [x0, x22, lsl #3]                      
02cb887c: mov     x0, x19                                    
02cb8880: str     x1, [x19]                                  
02cb8884: bl      #0x2b70d54                                 fn_2b70d54
02cb8888: cmp     w24, w23                                   
02cb888c: ldp     x20, x19, [sp, #0x30]                      
02cb8890: ldp     x22, x21, [sp, #0x20]                      
02cb8894: cset    w0, lt                                     
02cb8898: ldp     x24, x23, [sp, #0x10]                      
02cb889c: ldr     x30, [sp], #0x40                           
02cb88a0: ret                                                
02cb88a4: bl      #0x2b71064                                 fn_2b71064
