#### CLASS Blindbag.InputHandler parent= UnityEngine.MonoBehaviour
#   field _draggable                     bool                                               off=0x20 attr=1 SerializeField
#   field _target                        UnityEngine.Transform                              off=0x28 attr=1 SerializeField
#   field _minX                          float                                              off=0x30 attr=1 SerializeField
#   field _maxX                          float                                              off=0x34 attr=1 SerializeField
#   field _dragSpeed                     float                                              off=0x38 attr=1 SerializeField
#   field _smoothness                    float                                              off=0x3c attr=1 SerializeField
#   field _elasticity                    float                                              off=0x40 attr=1 SerializeField
#   field _friction                      float                                              off=0x44 attr=1 SerializeField
#   field OnClickedAction                UnityEngine.Events.UnityAction                     off=0x48 attr=6 
#   field _leftButton                    UnityEngine.UI.Button                              off=0x50 attr=1 
#   field _rightButton                   UnityEngine.UI.Button                              off=0x58 attr=1 
#   field _isOverUi                      bool                                               off=0x60 attr=1 
#   field _isClicking                    bool                                               off=0x61 attr=1 
#   field _isDragging                    bool                                               off=0x62 attr=1 
#   field _velocity                      float                                              off=0x64 attr=1 
#   field _lastMousePositionX            float                                              off=0x68 attr=1 
## SetButtons(UnityEngine.UI.Button leftButton, UnityEngine.UI.Button rightButton) -> void
---- Blindbag.InputHandler::SetButtons 0x2d53358
02d53358: str     x30, [sp, #-0x20]!                         
02d5335c: stp     x20, x19, [sp, #0x10]                      
02d53360: mov     x19, x2                                    
02d53364: mov     x20, x0                                    
02d53368: str     x1, [x0, #0x50]!                           ._leftButton
02d5336c: bl      #0x2b70d54                                 fn_2b70d54
02d53370: str     x19, [x20, #0x58]!                         ._rightButton
02d53374: mov     x0, x20                                    
02d53378: mov     x1, x19                                    
02d5337c: ldp     x20, x19, [sp, #0x10]                      
02d53380: ldr     x30, [sp], #0x20                           
02d53384: b       #0x2b70d54                                 
## EnableToDrag(bool enable) -> void
---- Blindbag.InputHandler::EnableToDrag 0x2d53388
02d53388: strb    w1, [x0, #0x20]                            ._draggable
02d5338c: ret                                                
## MoveLeft() -> void
---- Blindbag.InputHandler::MoveLeft 0x2d53390
02d53390: stp     x30, x23, [sp, #-0x30]!                    
02d53394: stp     x22, x21, [sp, #0x10]                      
02d53398: stp     x20, x19, [sp, #0x20]                      
02d5339c: adrp    x20, #0x6630000                            
02d533a0: mov     x19, x0                                    
02d533a4: ldrb    w8, [x20, #0x267]                          
02d533a8: tbnz    w8, #0, #0x2d533d8                         
02d533ac: adrp    x0, #0x626b000                             
02d533b0: ldr     x0, [x0, #0x960]                           M:Blindbag.InputHandler::<MoveLeft>b__18_0
02d533b4: bl      #0x2b70db0                                 fn_2b70db0
02d533b8: adrp    x0, #0x6264000                             
02d533bc: ldr     x0, [x0, #0xe8]                            T:DG.Tweening.TweenCallback
02d533c0: bl      #0x2b70db0                                 fn_2b70db0
02d533c4: adrp    x0, #0x6266000                             
02d533c8: ldr     x0, [x0, #0x928]                           MS:DG.Tweening.TweenSettingsExtensions::OnComplete
02d533cc: bl      #0x2b70db0                                 fn_2b70db0
02d533d0: mov     w8, #1                                     
02d533d4: strb    w8, [x20, #0x267]                          
02d533d8: ldr     x0, [x19, #0x28]                           ._target
02d533dc: strb    wzr, [x19, #0x20]                          ._draggable
02d533e0: cbz     x0, #0x2d5348c                             
02d533e4: mov     x1, xzr                                    
02d533e8: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02d533ec: ldr     x8, [x19, #0x28]                           ._target
02d533f0: cbz     x8, #0x2d5348c                             
02d533f4: adrp    x21, #0x6264000                            
02d533f8: adrp    x22, #0x626b000                            
02d533fc: adrp    x23, #0x6266000                            
02d53400: mov     x20, x0                                    
02d53404: ldr     x21, [x21, #0xe8]                          T:DG.Tweening.TweenCallback
02d53408: ldr     x22, [x22, #0x960]                         M:Blindbag.InputHandler::<MoveLeft>b__18_0
02d5340c: ldr     x23, [x23, #0x928]                         MS:DG.Tweening.TweenSettingsExtensions::OnComplete
02d53410: mov     x0, x8                                     
02d53414: mov     x1, xzr                                    
02d53418: bl      #0x5b45c24                                 UnityEngine.Transform::get_localPosition
02d5341c: fmov    s1, #10.00000000                           
02d53420: mov     x0, x20                                    
02d53424: mov     w1, wzr                                    
02d53428: mov     x2, xzr                                    
02d5342c: fadd    s0, s0, s1                                 
02d53430: ldp     s2, s1, [x19, #0x30]                       ._minX
02d53434: fcmp    s0, s1                                     
02d53438: fcsel   s1, s1, s0, gt                             
02d5343c: fcmp    s0, s2                                     
02d53440: fcsel   s0, s2, s1, mi                             
02d53444: fmov    s1, #0.50000000                            
02d53448: bl      #0x2d97eac                                 DG.Tweening.ShortcutExtensions::DOLocalMoveX
02d5344c: ldr     x8, [x21]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d53450: mov     x20, x0                                    
02d53454: mov     x0, x8                                     
02d53458: bl      #0x2b7104c                                 fn_2b7104c
02d5345c: ldr     x2, [x22]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d53460: mov     x1, x19                                    
02d53464: mov     x3, xzr                                    
02d53468: mov     x21, x0                                    
02d5346c: bl      #0x2d89dc4                                 DG.Tweening.TweenCallback::.ctor
02d53470: mov     x0, x20                                    
02d53474: mov     x1, x21                                    
02d53478: ldr     x2, [x23]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d5347c: ldp     x20, x19, [sp, #0x20]                      
02d53480: ldp     x22, x21, [sp, #0x10]                      
02d53484: ldp     x30, x23, [sp], #0x30                      
02d53488: b       #0x336f26c                                 
02d5348c: bl      #0x2b7105c                                 fn_2b7105c
## MoveRight() -> void
---- Blindbag.InputHandler::MoveRight 0x2d53490
02d53490: stp     x30, x23, [sp, #-0x30]!                    
02d53494: stp     x22, x21, [sp, #0x10]                      
02d53498: stp     x20, x19, [sp, #0x20]                      
02d5349c: adrp    x20, #0x6630000                            
02d534a0: mov     x19, x0                                    
02d534a4: ldrb    w8, [x20, #0x268]                          
02d534a8: tbnz    w8, #0, #0x2d534d8                         
02d534ac: adrp    x0, #0x626b000                             
02d534b0: ldr     x0, [x0, #0x968]                           M:Blindbag.InputHandler::<MoveRight>b__19_0
02d534b4: bl      #0x2b70db0                                 fn_2b70db0
02d534b8: adrp    x0, #0x6264000                             
02d534bc: ldr     x0, [x0, #0xe8]                            T:DG.Tweening.TweenCallback
02d534c0: bl      #0x2b70db0                                 fn_2b70db0
02d534c4: adrp    x0, #0x6266000                             
02d534c8: ldr     x0, [x0, #0x928]                           MS:DG.Tweening.TweenSettingsExtensions::OnComplete
02d534cc: bl      #0x2b70db0                                 fn_2b70db0
02d534d0: mov     w8, #1                                     
02d534d4: strb    w8, [x20, #0x268]                          
02d534d8: ldr     x0, [x19, #0x28]                           ._target
02d534dc: strb    wzr, [x19, #0x20]                          ._draggable
02d534e0: cbz     x0, #0x2d5358c                             
02d534e4: mov     x1, xzr                                    
02d534e8: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02d534ec: ldr     x8, [x19, #0x28]                           ._target
02d534f0: cbz     x8, #0x2d5358c                             
02d534f4: adrp    x21, #0x6264000                            
02d534f8: adrp    x22, #0x626b000                            
02d534fc: adrp    x23, #0x6266000                            
02d53500: mov     x20, x0                                    
02d53504: ldr     x21, [x21, #0xe8]                          T:DG.Tweening.TweenCallback
02d53508: ldr     x22, [x22, #0x968]                         M:Blindbag.InputHandler::<MoveRight>b__19_0
02d5350c: ldr     x23, [x23, #0x928]                         MS:DG.Tweening.TweenSettingsExtensions::OnComplete
02d53510: mov     x0, x8                                     
02d53514: mov     x1, xzr                                    
02d53518: bl      #0x5b45c24                                 UnityEngine.Transform::get_localPosition
02d5351c: fmov    s1, #-10.00000000                          
02d53520: mov     x0, x20                                    
02d53524: mov     w1, wzr                                    
02d53528: mov     x2, xzr                                    
02d5352c: fadd    s0, s0, s1                                 
02d53530: ldp     s2, s1, [x19, #0x30]                       ._minX
02d53534: fcmp    s0, s1                                     
02d53538: fcsel   s1, s1, s0, gt                             
02d5353c: fcmp    s0, s2                                     
02d53540: fcsel   s0, s2, s1, mi                             
02d53544: fmov    s1, #0.50000000                            
02d53548: bl      #0x2d97eac                                 DG.Tweening.ShortcutExtensions::DOLocalMoveX
02d5354c: ldr     x8, [x21]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d53550: mov     x20, x0                                    
02d53554: mov     x0, x8                                     
02d53558: bl      #0x2b7104c                                 fn_2b7104c
02d5355c: ldr     x2, [x22]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d53560: mov     x1, x19                                    
02d53564: mov     x3, xzr                                    
02d53568: mov     x21, x0                                    
02d5356c: bl      #0x2d89dc4                                 DG.Tweening.TweenCallback::.ctor
02d53570: mov     x0, x20                                    
02d53574: mov     x1, x21                                    
02d53578: ldr     x2, [x23]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d5357c: ldp     x20, x19, [sp, #0x20]                      
02d53580: ldp     x22, x21, [sp, #0x10]                      
02d53584: ldp     x30, x23, [sp], #0x30                      
02d53588: b       #0x336f26c                                 
02d5358c: bl      #0x2b7105c                                 fn_2b7105c
## Update() -> void
---- Blindbag.InputHandler::Update 0x2d53590
02d53590: str     d10, [sp, #-0x40]!                         
02d53594: stp     d9, d8, [sp, #8]                           
02d53598: str     x30, [sp, #0x18]                           
02d5359c: stp     x22, x21, [sp, #0x20]                      
02d535a0: stp     x20, x19, [sp, #0x30]                      
02d535a4: adrp    x20, #0x6630000                            
02d535a8: mov     x19, x0                                    
02d535ac: ldrb    w8, [x20, #0x269]                          
02d535b0: tbnz    w8, #0, #0x2d535d4                         
02d535b4: adrp    x0, #0x6266000                             
02d535b8: ldr     x0, [x0, #0x938]                           MS:UnityEngine.InputSystem.InputControl`1::ReadValue
02d535bc: bl      #0x2b70db0                                 fn_2b70db0
02d535c0: adrp    x0, #0x6266000                             
02d535c4: ldr     x0, [x0, #0x948]                           T:Touch
02d535c8: bl      #0x2b70db0                                 fn_2b70db0
02d535cc: mov     w8, #1                                     
02d535d0: strb    w8, [x20, #0x269]                          
02d535d4: ldrb    w8, [x19, #0x20]                           ._draggable
02d535d8: cbz     w8, #0x2d53654                             
02d535dc: adrp    x20, #0x662f000                            
02d535e0: ldrb    w8, [x20, #0xbd9]                          
02d535e4: cbnz    w8, #0x2d535fc                             
02d535e8: adrp    x0, #0x6266000                             
02d535ec: ldr     x0, [x0, #0x950]                           T:UnityEngine.InputSystem.Pointer
02d535f0: bl      #0x2b70db0                                 fn_2b70db0
02d535f4: mov     w8, #1                                     
02d535f8: strb    w8, [x20, #0xbd9]                          
02d535fc: adrp    x8, #0x6266000                             
02d53600: ldr     x8, [x8, #0x950]                           T:UnityEngine.InputSystem.Pointer
02d53604: ldr     x8, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d53608: ldr     x8, [x8, #0xb8]                            S:'banner_native_refresh_time'
02d5360c: ldr     x21, [x8]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d53610: cbz     x21, #0x2d53654                            
02d53614: ldr     x0, [x21, #0x1a8]                          
02d53618: cbz     x0, #0x2d5392c                             
02d5361c: mov     x1, xzr                                    
02d53620: bl      #0x55532f0                                 UnityEngine.InputSystem.Controls.ButtonControl::get_wasPressedThisFrame
02d53624: tbz     w0, #0, #0x2d53690                         
02d53628: adrp    x8, #0x6266000                             
02d5362c: ldr     x8, [x8, #0x948]                           T:Touch
02d53630: ldr     x0, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d53634: ldr     w8, [x0, #0xe4]                            [62660e4]=0 f=0,0
02d53638: cbnz    w8, #0x2d53640                             
02d5363c: bl      #0x2b70f30                                 fn_2b70f30
02d53640: mov     x0, xzr                                    
02d53644: bl      #0x2cd6230                                 Touch::IsPointerOverUIObject
02d53648: and     w8, w0, #1                                 
02d5364c: strb    w8, [x19, #0x60]                           ._isOverUi
02d53650: tbz     w0, #0, #0x2d5366c                         
02d53654: ldp     x20, x19, [sp, #0x30]                      
02d53658: ldr     x30, [sp, #0x18]                           
02d5365c: ldp     x22, x21, [sp, #0x20]                      
02d53660: ldp     d9, d8, [sp, #8]                           
02d53664: ldr     d10, [sp], #0x40                           
02d53668: ret                                                
02d5366c: ldr     x0, [x21, #0x188]                          
02d53670: mov     w8, #1                                     
02d53674: strb    w8, [x19, #0x61]                           ._isClicking
02d53678: cbz     x0, #0x2d5392c                             
02d5367c: adrp    x8, #0x6266000                             
02d53680: ldr     x8, [x8, #0x938]                           MS:UnityEngine.InputSystem.InputControl`1::ReadValue
02d53684: ldr     x1, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d53688: bl      #0x4a187c4                                 fn_4a187c4
02d5368c: str     s0, [x19, #0x68]                           ._lastMousePositionX
02d53690: ldr     x0, [x21, #0x1a8]                          
02d53694: cbz     x0, #0x2d5392c                             
02d53698: mov     x1, xzr                                    
02d5369c: bl      #0x5553134                                 UnityEngine.InputSystem.Controls.ButtonControl::get_isPressed
02d536a0: tbz     w0, #0, #0x2d536b4                         
02d536a4: ldrb    w8, [x19, #0x61]                           ._isClicking
02d536a8: cbz     w8, #0x2d536b4                             
02d536ac: ldrb    w8, [x19, #0x60]                           ._isOverUi
02d536b0: cbz     w8, #0x2d53798                             
02d536b4: ldr     s0, [x19, #0x64]                           ._velocity
02d536b8: ldr     s1, [x19, #0x44]                           ._friction
02d536bc: ldr     x20, [x19, #0x28]                          ._target
02d536c0: fmul    s0, s0, s1                                 
02d536c4: str     s0, [x19, #0x64]                           ._velocity
02d536c8: cbz     x20, #0x2d5392c                            
02d536cc: mov     x0, x20                                    
02d536d0: mov     x1, xzr                                    
02d536d4: bl      #0x5b467ac                                 UnityEngine.Transform::get_position
02d536d8: fmov    s8, s0                                     
02d536dc: fmov    s9, s1                                     
02d536e0: adrp    x22, #0x662f000                            
02d536e4: fmov    s10, s2                                    
02d536e8: ldrb    w8, [x22, #0xca5]                          
02d536ec: cbnz    w8, #0x2d53704                             
02d536f0: adrp    x0, #0x6264000                             
02d536f4: ldr     x0, [x0, #0xd8]                            T:UnityEngine.Vector3
02d536f8: bl      #0x2b70db0                                 fn_2b70db0
02d536fc: mov     w8, #1                                     
02d53700: strb    w8, [x22, #0xca5]                          
02d53704: adrp    x8, #0x6264000                             
02d53708: mov     x0, x20                                    
02d5370c: mov     x1, xzr                                    
02d53710: ldr     x8, [x8, #0xd8]                            T:UnityEngine.Vector3
02d53714: ldr     s0, [x19, #0x64]                           ._velocity
02d53718: ldr     x8, [x8]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d5371c: ldr     x8, [x8, #0xb8]                            MS:DG.Tweening.Core.Extensions::SetSpecialStartupMode
02d53720: ldp     s1, s2, [x8, #0x3c]                        
02d53724: ldr     s3, [x8, #0x44]                            [6264044]=0 f=0,0
02d53728: fmul    s3, s3, s0                                 
02d5372c: fmul    s1, s1, s0                                 
02d53730: fmul    s2, s2, s0                                 
02d53734: fadd    s0, s8, s1                                 
02d53738: fadd    s1, s9, s2                                 
02d5373c: fadd    s2, s10, s3                                
02d53740: bl      #0x5b46888                                 UnityEngine.Transform::set_position
02d53744: ldr     x20, [x19, #0x28]                          ._target
02d53748: cbz     x20, #0x2d5392c                            
02d5374c: mov     x0, x20                                    
02d53750: mov     x1, xzr                                    
02d53754: bl      #0x5b45c24                                 UnityEngine.Transform::get_localPosition
02d53758: ldp     s2, s1, [x19, #0x30]                       ._minX
02d5375c: mov     x0, x20                                    
02d53760: mov     x1, xzr                                    
02d53764: fcmp    s0, s1                                     
02d53768: fcsel   s1, s1, s0, gt                             
02d5376c: fcmp    s0, s2                                     
02d53770: fcsel   s0, s2, s1, mi                             
02d53774: bl      #0x2cbaf2c                                 Framework.TranformExtension::SetLocalPosX
02d53778: ldr     s0, [x19, #0x64]                           ._velocity
02d5377c: adrp    x8, #0x1084000                             
02d53780: ldr     s1, [x8, #0xe04]                           [1084e04]=402ccccd3c23d70a f=0.01,2.7
02d53784: fabs    s0, s0                                     
02d53788: fcmp    s0, s1                                     
02d5378c: b.pl    #0x2d538cc                                 
02d53790: str     wzr, [x19, #0x64]                          ._velocity
02d53794: b       #0x2d538cc                                 
02d53798: ldr     x0, [x21, #0x188]                          
02d5379c: cbz     x0, #0x2d5392c                             
02d537a0: adrp    x20, #0x6266000                            
02d537a4: ldr     x20, [x20, #0x938]                         MS:UnityEngine.InputSystem.InputControl`1::ReadValue
02d537a8: ldr     s8, [x19, #0x68]                           ._lastMousePositionX
02d537ac: ldr     x1, [x20]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d537b0: bl      #0x4a187c4                                 fn_4a187c4
02d537b4: fabd    s0, s8, s0                                 
02d537b8: fmov    s1, #5.00000000                            
02d537bc: fcmp    s0, s1                                     
02d537c0: b.le    #0x2d537d4                                 
02d537c4: ldrb    w8, [x19, #0x62]                           ._isDragging
02d537c8: cbnz    w8, #0x2d537d4                             
02d537cc: mov     w8, #1                                     
02d537d0: strb    w8, [x19, #0x62]                           ._isDragging
02d537d4: ldr     x0, [x21, #0x188]                          
02d537d8: cbz     x0, #0x2d5392c                             
02d537dc: ldr     x1, [x20]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d537e0: bl      #0x4a187c4                                 fn_4a187c4
02d537e4: ldr     s1, [x19, #0x68]                           ._lastMousePositionX
02d537e8: ldr     s9, [x19, #0x38]                           ._dragSpeed
02d537ec: mov     x0, xzr                                    
02d537f0: fsub    s8, s0, s1                                 
02d537f4: bl      #0x5b433a4                                 UnityEngine.Time::get_deltaTime
02d537f8: fmul    s1, s8, s9                                 
02d537fc: ldr     x0, [x21, #0x188]                          
02d53800: fmul    s0, s1, s0                                 
02d53804: str     s0, [x19, #0x64]                           ._velocity
02d53808: cbz     x0, #0x2d5392c                             
02d5380c: ldr     x1, [x20]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d53810: bl      #0x4a187c4                                 fn_4a187c4
02d53814: ldr     x20, [x19, #0x28]                          ._target
02d53818: str     s0, [x19, #0x68]                           ._lastMousePositionX
02d5381c: cbz     x20, #0x2d5392c                            
02d53820: mov     x0, x20                                    
02d53824: mov     x1, xzr                                    
02d53828: bl      #0x5b467ac                                 UnityEngine.Transform::get_position
02d5382c: fmov    s8, s0                                     
02d53830: fmov    s9, s1                                     
02d53834: adrp    x22, #0x662f000                            
02d53838: fmov    s10, s2                                    
02d5383c: ldrb    w8, [x22, #0xca5]                          
02d53840: cbnz    w8, #0x2d53858                             
02d53844: adrp    x0, #0x6264000                             
02d53848: ldr     x0, [x0, #0xd8]                            T:UnityEngine.Vector3
02d5384c: bl      #0x2b70db0                                 fn_2b70db0
02d53850: mov     w8, #1                                     
02d53854: strb    w8, [x22, #0xca5]                          
02d53858: adrp    x8, #0x6264000                             
02d5385c: mov     x0, x20                                    
02d53860: mov     x1, xzr                                    
02d53864: ldr     x8, [x8, #0xd8]                            T:UnityEngine.Vector3
02d53868: ldr     s0, [x19, #0x64]                           ._velocity
02d5386c: ldr     x8, [x8]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d53870: ldr     x8, [x8, #0xb8]                            MS:DG.Tweening.Core.Extensions::SetSpecialStartupMode
02d53874: ldp     s1, s2, [x8, #0x3c]                        
02d53878: ldr     s3, [x8, #0x44]                            [6264044]=0 f=0,0
02d5387c: fmul    s3, s3, s0                                 
02d53880: fmul    s1, s1, s0                                 
02d53884: fmul    s2, s2, s0                                 
02d53888: fadd    s0, s8, s1                                 
02d5388c: fadd    s1, s9, s2                                 
02d53890: fadd    s2, s10, s3                                
02d53894: bl      #0x5b46888                                 UnityEngine.Transform::set_position
02d53898: ldr     x20, [x19, #0x28]                          ._target
02d5389c: cbz     x20, #0x2d5392c                            
02d538a0: mov     x0, x20                                    
02d538a4: mov     x1, xzr                                    
02d538a8: bl      #0x5b45c24                                 UnityEngine.Transform::get_localPosition
02d538ac: ldp     s2, s1, [x19, #0x30]                       ._minX
02d538b0: mov     x0, x20                                    
02d538b4: mov     x1, xzr                                    
02d538b8: fcmp    s0, s1                                     
02d538bc: fcsel   s1, s1, s0, gt                             
02d538c0: fcmp    s0, s2                                     
02d538c4: fcsel   s0, s2, s1, mi                             
02d538c8: bl      #0x2cbaf2c                                 Framework.TranformExtension::SetLocalPosX
02d538cc: ldr     x0, [x21, #0x1a8]                          
02d538d0: cbz     x0, #0x2d5392c                             
02d538d4: mov     x1, xzr                                    
02d538d8: bl      #0x5553460                                 UnityEngine.InputSystem.Controls.ButtonControl::get_wasReleasedThisFrame
02d538dc: tbz     w0, #0, #0x2d53910                         
02d538e0: ldrb    w8, [x19, #0x60]                           ._isOverUi
02d538e4: cbnz    w8, #0x2d53910                             
02d538e8: ldrb    w8, [x19, #0x62]                           ._isDragging
02d538ec: cbz     w8, #0x2d538f8                             
02d538f0: strb    wzr, [x19, #0x62]                          ._isDragging
02d538f4: b       #0x2d53910                                 
02d538f8: ldr     x8, [x19, #0x48]                           .OnClickedAction
02d538fc: cbz     x8, #0x2d53910                             
02d53900: ldr     x9, [x8, #0x18]                            M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass2_0::<DOSetFloat>b__1
02d53904: ldr     x0, [x8, #0x40]                            MS:DG.Tweening.TweenSettingsExtensions::SetTarget
02d53908: ldr     x1, [x8, #0x28]                            T:type8534(k15)
02d5390c: blr     x9                                         
02d53910: mov     x0, x19                                    
02d53914: ldp     x20, x19, [sp, #0x30]                      
02d53918: ldp     x22, x21, [sp, #0x20]                      
02d5391c: ldr     x30, [sp, #0x18]                           
02d53920: ldp     d9, d8, [sp, #8]                           
02d53924: ldr     d10, [sp], #0x40                           
02d53928: b       #0x2d5395c                                 Blindbag.InputHandler::CheckButtons
02d5392c: bl      #0x2b7105c                                 fn_2b7105c
## CheckButtons() -> void
---- Blindbag.InputHandler::CheckButtons 0x2d5395c
02d5395c: str     d10, [sp, #-0x40]!                         
02d53960: stp     d9, d8, [sp, #0x10]                        
02d53964: stp     x30, x21, [sp, #0x20]                      
02d53968: stp     x20, x19, [sp, #0x30]                      
02d5396c: adrp    x20, #0x6630000                            
02d53970: mov     x19, x0                                    
02d53974: ldrb    w8, [x20, #0x26a]                          
02d53978: tbnz    w8, #0, #0x2d53990                         
02d5397c: adrp    x0, #0x6263000                             
02d53980: ldr     x0, [x0, #0x918]                           T:UnityEngine.Object
02d53984: bl      #0x2b70db0                                 fn_2b70db0
02d53988: mov     w8, #1                                     
02d5398c: strb    w8, [x20, #0x26a]                          
02d53990: ldr     x0, [x19, #0x28]                           ._target
02d53994: cbz     x0, #0x2d53a54                             
02d53998: adrp    x21, #0x6263000                            
02d5399c: mov     x1, xzr                                    
02d539a0: ldr     x21, [x21, #0x918]                         T:UnityEngine.Object
02d539a4: bl      #0x5b45c24                                 UnityEngine.Transform::get_localPosition
02d539a8: ldr     x0, [x21]                                  &2c5bbd4(=a9bd7bfdd503233f)
02d539ac: fmov    s8, s0                                     
02d539b0: ldr     x20, [x19, #0x50]                          ._leftButton
02d539b4: ldp     s9, s10, [x19, #0x30]                      ._minX
02d539b8: ldr     w8, [x0, #0xe4]                            [62630e4]=0 f=0,0
02d539bc: cbnz    w8, #0x2d539c4                             
02d539c0: bl      #0x2b70f30                                 fn_2b70f30
02d539c4: mov     x0, x20                                    
02d539c8: mov     x1, xzr                                    
02d539cc: bl      #0x5b3bb1c                                 UnityEngine.Object::op_Implicit
02d539d0: tbz     w0, #0, #0x2d539f0                         
02d539d4: ldr     x0, [x19, #0x50]                           ._leftButton
02d539d8: cbz     x0, #0x2d53a54                             
02d539dc: fsub    s0, s8, s10                                
02d539e0: mov     x2, xzr                                    
02d539e4: fcmp    s0, #0.0                                   
02d539e8: cset    w1, mi                                     
02d539ec: bl      #0x5e662d4                                 UnityEngine.UI.Selectable::set_interactable
02d539f0: ldr     x0, [x21]                                  &2c5bbd4(=a9bd7bfdd503233f)
02d539f4: ldr     x20, [x19, #0x58]                          ._rightButton
02d539f8: ldr     w8, [x0, #0xe4]                            [62630e4]=0 f=0,0
02d539fc: cbnz    w8, #0x2d53a04                             
02d53a00: bl      #0x2b70f30                                 fn_2b70f30
02d53a04: mov     x0, x20                                    
02d53a08: mov     x1, xzr                                    
02d53a0c: bl      #0x5b3bb1c                                 UnityEngine.Object::op_Implicit
02d53a10: tbz     w0, #0, #0x2d53a40                         
02d53a14: ldr     x0, [x19, #0x58]                           ._rightButton
02d53a18: cbz     x0, #0x2d53a54                             
02d53a1c: fsub    s0, s8, s9                                 
02d53a20: ldp     x20, x19, [sp, #0x30]                      
02d53a24: ldp     x30, x21, [sp, #0x20]                      
02d53a28: mov     x2, xzr                                    
02d53a2c: ldp     d9, d8, [sp, #0x10]                        
02d53a30: fcmp    s0, #0.0                                   
02d53a34: cset    w1, gt                                     
02d53a38: ldr     d10, [sp], #0x40                           
02d53a3c: b       #0x5e662d4                                 UnityEngine.UI.Selectable::set_interactable
02d53a40: ldp     x20, x19, [sp, #0x30]                      
02d53a44: ldp     x30, x21, [sp, #0x20]                      
02d53a48: ldp     d9, d8, [sp, #0x10]                        
02d53a4c: ldr     d10, [sp], #0x40                           
02d53a50: ret                                                
02d53a54: bl      #0x2b7105c                                 fn_2b7105c
## EndDrag() -> void
---- Blindbag.InputHandler::EndDrag 0x2d53930
02d53930: ldrb    w8, [x0, #0x62]                            ._isDragging
02d53934: cbz     w8, #0x2d53940                             
02d53938: strb    wzr, [x0, #0x62]                           ._isDragging
02d5393c: ret                                                
02d53940: ldr     x8, [x0, #0x48]                            .OnClickedAction
02d53944: cbz     x8, #0x2d53958                             
02d53948: ldr     x0, [x8, #0x40]                            
02d5394c: ldr     x1, [x8, #0x28]                            
02d53950: ldr     x2, [x8, #0x18]                            
02d53954: br      x2                                         
02d53958: ret                                                
## OnDragEnd() -> void
---- Blindbag.InputHandler::OnDragEnd 0x2d53a58
02d53a58: strb    wzr, [x0, #0x62]                           ._isDragging
02d53a5c: ret                                                
## OnClick() -> void
---- Blindbag.InputHandler::OnClick 0x2d53a60
02d53a60: ldr     x8, [x0, #0x48]                            .OnClickedAction
02d53a64: cbz     x8, #0x2d53a78                             
02d53a68: ldr     x0, [x8, #0x40]                            
02d53a6c: ldr     x1, [x8, #0x28]                            
02d53a70: ldr     x2, [x8, #0x18]                            
02d53a74: br      x2                                         
02d53a78: ret                                                
## .ctor() -> void
---- Blindbag.InputHandler::.ctor 0x2d53a7c
02d53a7c: adrp    x8, #0x1086000                             
02d53a80: mov     x1, xzr                                    
02d53a84: ldr     q0, [x8, #0x100]                           [1086100]=3dcccccd3f800000 f=1,0.1
02d53a88: stur    q0, [x0, #0x38]                            ._dragSpeed
02d53a8c: b       #0x5b397b0                                 UnityEngine.MonoBehaviour::.ctor
## <MoveLeft>b__18_0() -> void
---- Blindbag.InputHandler::<MoveLeft>b__18_0 0x2d53a90
02d53a90: mov     w8, #1                                     
02d53a94: strb    w8, [x0, #0x20]                            ._draggable
02d53a98: ret                                                
## <MoveRight>b__19_0() -> void
---- Blindbag.InputHandler::<MoveRight>b__19_0 0x2d53a9c
02d53a9c: mov     w8, #1                                     
02d53aa0: strb    w8, [x0, #0x20]                            ._draggable
02d53aa4: ret                                                
