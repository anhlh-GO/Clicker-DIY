#### CLASS Jelly.ItemAnimator/<Shake>d__2 parent= System.ValueType
#   field <>1__state                     int                                                off=0x10 attr=6 
#   field <>t__builder                   System.Runtime.CompilerServices.AsyncVoidMethodBuilder off=0x18 attr=6 
#   field <>4__this                      Jelly.ItemAnimator                                 off=0x38 attr=6 
#   field <cachedScale>5__2              UnityEngine.Vector3                                off=0x40 attr=1 
#   field <>u__1                         Cysharp.Threading.Tasks.UniTask/Awaiter            off=0x50 attr=1 
## MoveNext() -> void
---- Jelly.ItemAnimator/<Shake>d__2::MoveNext 0x2d14ffc
02d14ffc: sub     sp, sp, #0x80                              
02d15000: str     d8, [sp, #0x30]                            
02d15004: stp     x30, x25, [sp, #0x40]                      
02d15008: stp     x24, x23, [sp, #0x50]                      
02d1500c: stp     x22, x21, [sp, #0x60]                      
02d15010: stp     x20, x19, [sp, #0x70]                      
02d15014: adrp    x20, #0x662f000                            
02d15018: mov     x19, x0                                    
02d1501c: ldrb    w8, [x20, #0xfcc]                          
02d15020: tbnz    w8, #0, #0x2d15044                         
02d15024: adrp    x0, #0x6269000                             
02d15028: ldr     x0, [x0, #0x878]                           MS:System.Runtime.CompilerServices.AsyncVoidMethodBuilder::AwaitUnsafeOnCompleted
02d1502c: bl      #0x2b70db0                                 fn_2b70db0
02d15030: adrp    x0, #0x6266000                             
02d15034: ldr     x0, [x0, #0xcc8]                           T:Cysharp.Threading.Tasks.UniTask
02d15038: bl      #0x2b70db0                                 fn_2b70db0
02d1503c: mov     w8, #1                                     
02d15040: strb    w8, [x20, #0xfcc]                          
02d15044: ldr     w8, [x19]                                  
02d15048: ldr     x20, [x19, #0x28]                          
02d1504c: adrp    x23, #0x1084000                            
02d15050: stp     xzr, xzr, [sp, #0x10]                      
02d15054: str     wzr, [sp, #8]                              
02d15058: cbz     w8, #0x2d1519c                             
02d1505c: cbz     x20, #0x2d15358                            
02d15060: mov     x0, x20                                    
02d15064: mov     x1, xzr                                    
02d15068: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02d1506c: cbz     x0, #0x2d1535c                             
02d15070: mov     x1, xzr                                    
02d15074: bl      #0x5b46ff0                                 UnityEngine.Transform::get_localScale
02d15078: stp     s0, s1, [x19, #0x30]                       
02d1507c: str     s2, [x19, #0x38]                           .<>4__this
02d15080: mov     x0, x20                                    
02d15084: mov     x1, xzr                                    
02d15088: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02d1508c: cbz     x0, #0x2d15360                             
02d15090: ldp     s1, s2, [x19, #0x34]                       
02d15094: ldr     s0, [x19, #0x30]                           
02d15098: mov     x1, xzr                                    
02d1509c: bl      #0x5b470cc                                 UnityEngine.Transform::set_localScale
02d150a0: mov     x0, x20                                    
02d150a4: mov     x1, xzr                                    
02d150a8: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02d150ac: mov     w1, wzr                                    
02d150b0: mov     x2, xzr                                    
02d150b4: bl      #0x2d9d5d0                                 DG.Tweening.ShortcutExtensions::DOKill
02d150b8: mov     x0, x20                                    
02d150bc: mov     x1, xzr                                    
02d150c0: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02d150c4: adrp    x8, #0x1084000                             
02d150c8: ldr     s0, [x19, #0x34]                           
02d150cc: ldr     s1, [x8, #0xcf4]                           [1084cf4]=431d80003f99999a f=1.2,157.5
02d150d0: fmul    s0, s0, s1                                 
02d150d4: ldr     s8, [x23, #0xda4]                          [1084da4]=3eb851ec3e19999a f=0.15,0.36
02d150d8: mov     x1, xzr                                    
02d150dc: fmov    s1, s8                                     
02d150e0: bl      #0x2d98fd4                                 DG.Tweening.ShortcutExtensions::DOScaleY
02d150e4: mov     x0, x20                                    
02d150e8: mov     x1, xzr                                    
02d150ec: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02d150f0: adrp    x8, #0x1084000                             
02d150f4: ldr     s0, [x19, #0x30]                           
02d150f8: ldr     s1, [x8, #0xcc4]                           [1084cc4]=3f8000543f4ccccd f=0.8,1.00001
02d150fc: fmul    s0, s0, s1                                 
02d15100: fmov    s1, s8                                     
02d15104: mov     x1, xzr                                    
02d15108: bl      #0x2d98e28                                 DG.Tweening.ShortcutExtensions::DOScaleX
02d1510c: adrp    x24, #0x6266000                            
02d15110: ldr     x24, [x24, #0xcc8]                         T:Cysharp.Threading.Tasks.UniTask
02d15114: ldr     x0, [x24]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d15118: ldr     w8, [x0, #0xe4]                            [62660e4]=0 f=0,0
02d1511c: cbnz    w8, #0x2d15124                             
02d15120: bl      #0x2b70f30                                 fn_2b70f30
02d15124: fmov    s0, s8                                     
02d15128: mov     w0, wzr                                    
02d1512c: mov     w1, #8                                     
02d15130: mov     x2, xzr                                    
02d15134: mov     w3, wzr                                    
02d15138: mov     x4, xzr                                    
02d1513c: bl      #0x5447b08                                 Cysharp.Threading.Tasks.UniTask::WaitForSeconds
02d15140: stp     x0, x1, [sp, #0x20]                        
02d15144: add     x0, sp, #0x20                              
02d15148: mov     x1, xzr                                    
02d1514c: bl      #0x2b70d54                                 fn_2b70d54
02d15150: adrp    x25, #0x662f000                            
02d15154: ldp     x21, x22, [sp, #0x20]                      
02d15158: ldrb    w8, [x25, #0xbdc]                          
02d1515c: stp     x21, x22, [sp, #0x10]                      
02d15160: cbnz    w8, #0x2d15178                             
02d15164: adrp    x0, #0x6266000                             
02d15168: ldr     x0, [x0, #0xcc8]                           T:Cysharp.Threading.Tasks.UniTask
02d1516c: bl      #0x2b70db0                                 fn_2b70db0
02d15170: mov     w8, #1                                     
02d15174: strb    w8, [x25, #0xbdc]                          
02d15178: ldr     x0, [x24]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d1517c: ldr     w8, [x0, #0xe4]                            [62660e4]=0 f=0,0
02d15180: cbnz    w8, #0x2d15188                             
02d15184: bl      #0x2b70f30                                 fn_2b70f30
02d15188: adrp    x24, #0x662f000                            
02d1518c: ldrb    w8, [x24, #0xbdd]                          
02d15190: cbz     w8, #0x2d151b4                             
02d15194: cbnz    x21, #0x2d151cc                            
02d15198: b       #0x2d15234                                 
02d1519c: ldr     q0, [x19, #0x40]                           .<cachedScale>5__2
02d151a0: mov     w8, #-1                                    
02d151a4: stp     xzr, xzr, [x19, #0x40]                     .<cachedScale>5__2
02d151a8: str     w8, [x19]                                  
02d151ac: str     q0, [sp, #0x10]                            
02d151b0: b       #0x2d15234                                 
02d151b4: adrp    x0, #0x6266000                             
02d151b8: ldr     x0, [x0, #0xcd0]                           T:Cysharp.Threading.Tasks.IUniTaskSource
02d151bc: bl      #0x2b70db0                                 fn_2b70db0
02d151c0: mov     w8, #1                                     
02d151c4: strb    w8, [x24, #0xbdd]                          
02d151c8: cbz     x21, #0x2d15234                            
02d151cc: adrp    x10, #0x6266000                            
02d151d0: ldr     x8, [x21]                                  
02d151d4: ldr     x10, [x10, #0xcd0]                         T:Cysharp.Threading.Tasks.IUniTaskSource
02d151d8: ldrh    w9, [x8, #0x12e]                           
02d151dc: ldr     x1, [x10]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d151e0: cbz     x9, #0x2d15204                             
02d151e4: ldr     x10, [x8, #0xb0]                           [10840b0]=2e656e69676e4579 f=1.1252e+24,5.21666e-11
02d151e8: add     x10, x10, #8                               &6266008
02d151ec: ldur    x11, [x10, #-8]                            
02d151f0: cmp     x11, x1                                    
02d151f4: b.eq    #0x2d15214                                 
02d151f8: subs    x9, x9, #1                                 
02d151fc: add     x10, x10, #0x10                            &6266010
02d15200: b.ne    #0x2d151ec                                 
02d15204: mov     x0, x21                                    
02d15208: mov     w2, wzr                                    
02d1520c: bl      #0x2baa05c                                 fn_2baa05c
02d15210: b       #0x2d15220                                 
02d15214: ldrsw   x9, [x10]                                  
02d15218: add     x8, x8, x9, lsl #4                         &1084000
02d1521c: add     x0, x8, #0x138                             &1084138
02d15220: ldp     x8, x2, [x0]                               
02d15224: mov     x0, x21                                    
02d15228: mov     w1, w22                                    
02d1522c: blr     x8                                         
02d15230: cbz     w0, #0x2d1531c                             
02d15234: adrp    x21, #0x662f000                            
02d15238: ldrb    w8, [x21, #0xbde]                          
02d1523c: cbnz    w8, #0x2d15254                             
02d15240: adrp    x0, #0x6266000                             
02d15244: ldr     x0, [x0, #0xcd0]                           T:Cysharp.Threading.Tasks.IUniTaskSource
02d15248: bl      #0x2b70db0                                 fn_2b70db0
02d1524c: mov     w8, #1                                     
02d15250: strb    w8, [x21, #0xbde]                          
02d15254: ldr     x21, [sp, #0x10]                           
02d15258: cbz     x21, #0x2d152c8                            
02d1525c: adrp    x10, #0x6266000                            
02d15260: ldr     x8, [x21]                                  &2b706c4(=eb01011ff9400808)
02d15264: ldr     x10, [x10, #0xcd0]                         T:Cysharp.Threading.Tasks.IUniTaskSource
02d15268: ldrh    w22, [sp, #0x18]                           
02d1526c: ldrh    w9, [x8, #0x12e]                           
02d15270: ldr     x1, [x10]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d15274: cbz     x9, #0x2d15298                             
02d15278: ldr     x10, [x8, #0xb0]                           [10840b0]=2e656e69676e4579 f=1.1252e+24,5.21666e-11
02d1527c: add     x10, x10, #8                               &6266008
02d15280: ldur    x11, [x10, #-8]                            
02d15284: cmp     x11, x1                                    
02d15288: b.eq    #0x2d152a8                                 
02d1528c: subs    x9, x9, #1                                 
02d15290: add     x10, x10, #0x10                            &6266010
02d15294: b.ne    #0x2d15280                                 
02d15298: mov     x0, x21                                    
02d1529c: mov     w2, #2                                     
02d152a0: bl      #0x2baa05c                                 fn_2baa05c
02d152a4: b       #0x2d152b8                                 
02d152a8: ldr     w9, [x10]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d152ac: add     w9, w9, #2                                 
02d152b0: add     x8, x8, w9, sxtw #4                        &1084000
02d152b4: add     x0, x8, #0x138                             &1084138
02d152b8: ldp     x8, x2, [x0]                               
02d152bc: mov     x0, x21                                    
02d152c0: mov     w1, w22                                    
02d152c4: blr     x8                                         
02d152c8: cbz     x20, #0x2d15354                            
02d152cc: mov     x0, x20                                    
02d152d0: mov     x1, xzr                                    
02d152d4: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02d152d8: ldp     s0, s1, [x19, #0x30]                       
02d152dc: ldr     s2, [x19, #0x38]                           .<>4__this
02d152e0: ldr     s3, [x23, #0xda4]                          [1084da4]=3eb851ec3e19999a f=0.15,0.36
02d152e4: mov     x1, xzr                                    
02d152e8: bl      #0x2d98af8                                 DG.Tweening.ShortcutExtensions::DOScale
02d152ec: mov     w8, #-2                                    
02d152f0: mov     x1, xzr                                    
02d152f4: str     w8, [x19], #8                              
02d152f8: mov     x0, x19                                    
02d152fc: bl      #0x4d43b50                                 System.Runtime.CompilerServices.AsyncVoidMethodBuilder::SetResult
02d15300: ldp     x20, x19, [sp, #0x70]                      
02d15304: ldr     d8, [sp, #0x30]                            
02d15308: ldp     x22, x21, [sp, #0x60]                      
02d1530c: ldp     x24, x23, [sp, #0x50]                      
02d15310: ldp     x30, x25, [sp, #0x40]                      
02d15314: add     sp, sp, #0x80                              
02d15318: ret                                                
02d1531c: ldr     q0, [sp, #0x10]                            
02d15320: str     wzr, [x19]                                 
02d15324: str     q0, [x19, #0x40]                           .<cachedScale>5__2
02d15328: add     x0, x19, #0x40                             
02d1532c: mov     x1, xzr                                    
02d15330: bl      #0x2b70d54                                 fn_2b70d54
02d15334: adrp    x8, #0x6269000                             
02d15338: ldr     x8, [x8, #0x878]                           MS:System.Runtime.CompilerServices.AsyncVoidMethodBuilder::AwaitUnsafeOnCompleted
02d1533c: ldr     x3, [x8]                                   T:Trading.TradingSession/<>c__DisplayClass56_0
02d15340: add     x0, x19, #8                                
02d15344: add     x1, sp, #0x10                              
02d15348: mov     x2, x19                                    
02d1534c: bl      #0x30c3700                                 fn_30c3700
02d15350: b       #0x2d15300                                 
02d15354: bl      #0x2b7105c                                 fn_2b7105c
02d15358: bl      #0x2b7105c                                 fn_2b7105c
02d1535c: bl      #0x2b7105c                                 fn_2b7105c
02d15360: bl      #0x2b7105c                                 fn_2b7105c
02d15364: b       #0x2d153b4                                 
02d15368: b       #0x2d153b4                                 
02d1536c: b       #0x2d153b4                                 
02d15370: b       #0x2d153b4                                 
02d15374: b       #0x2d153b4                                 
02d15378: b       #0x2d153b4                                 
02d1537c: b       #0x2d153b4                                 
02d15380: b       #0x2d153b4                                 
02d15384: b       #0x2d153b4                                 
02d15388: b       #0x2d153b4                                 
02d1538c: b       #0x2d153b4                                 
02d15390: b       #0x2d153b4                                 
02d15394: b       #0x2d153b4                                 
02d15398: b       #0x2d153b4                                 
02d1539c: b       #0x2d153b4                                 
02d153a0: b       #0x2d153b4                                 
02d153a4: b       #0x2d153b4                                 
02d153a8: b       #0x2d153b4                                 
02d153ac: b       #0x2d153b4                                 
02d153b0: b       #0x2d153b4                                 
02d153b4: mov     x20, x0                                    
02d153b8: cmp     w1, #1                                     
02d153bc: b.ne    #0x2d1544c                                 
02d153c0: mov     x0, x20                                    
02d153c4: bl      #0x5e90260                                 fn_5e90260
02d153c8: mov     x20, x0                                    
02d153cc: adrp    x0, #0x6263000                             
02d153d0: ldr     x0, [x0, #0xae0]                           T:System.Exception
02d153d4: bl      #0x2b70dc4                                 fn_2b70dc4
02d153d8: ldr     x8, [x20]                                  &2b706c4(=eb01011ff9400808)
02d153dc: ldr     x1, [x8]                                   T:Trading.TradingSession/<>c__DisplayClass56_0
02d153e0: bl      #0x2b71464                                 fn_2b71464
02d153e4: tbz     w0, #0, #0x2d15424                         
02d153e8: ldrsw   x21, [sp, #8]                              
02d153ec: ldr     x20, [x20]                                 &2b706c4(=eb01011ff9400808)
02d153f0: mov     x8, sp                                     
02d153f4: str     x20, [x8, x21, lsl #3]                     
02d153f8: add     w8, w21, #1                                
02d153fc: str     w8, [sp, #8]                               
02d15400: bl      #0x5e90270                                 fn_5e90270
02d15404: mov     w8, #-2                                    
02d15408: mov     x1, x20                                    
02d1540c: mov     x2, xzr                                    
02d15410: str     w8, [x19], #8                              
02d15414: mov     x0, x19                                    
02d15418: bl      #0x4d43cc0                                 System.Runtime.CompilerServices.AsyncVoidMethodBuilder::SetException
02d1541c: str     w21, [sp, #8]                              
02d15420: b       #0x2d15300                                 
02d15424: mov     w0, #8                                     
02d15428: bl      #0x5e90290                                 fn_5e90290
02d1542c: ldr     x8, [x20]                                  &2b706c4(=eb01011ff9400808)
02d15430: str     x8, [x0]                                   
02d15434: adrp    x1, #0x5e96000                             
02d15438: add     x1, x1, #0x758                             &5e96758
02d1543c: mov     x2, xzr                                    
02d15440: bl      #0x5e902a0                                 fn_5e902a0
02d15444: mov     x20, x0                                    
02d15448: bl      #0x5e90270                                 fn_5e90270
02d1544c: mov     x0, x20                                    
02d15450: bl      #0x2c6051c                                 fn_2c6051c
02d15454: bl      #0x27369b8                                 fn_27369b8
## SetStateMachine(System.Runtime.CompilerServices.IAsyncStateMachine stateMachine) -> void
---- Jelly.ItemAnimator/<Shake>d__2::SetStateMachine 0x2d15458
02d15458: add     x0, x0, #8                                 
02d1545c: mov     x2, xzr                                    
02d15460: b       #0x4d43a8c                                 System.Runtime.CompilerServices.AsyncVoidMethodBuilder::SetStateMachine
#### CLASS Jelly.ItemAnimator/<ShowUp>d__0 parent= System.ValueType
#   field <>1__state                     int                                                off=0x10 attr=6 
#   field <>t__builder                   System.Runtime.CompilerServices.AsyncVoidMethodBuilder off=0x18 attr=6 
#   field <>4__this                      Jelly.ItemAnimator                                 off=0x38 attr=6 
#   field <>u__1                         Cysharp.Threading.Tasks.UniTask/Awaiter            off=0x40 attr=1 
## MoveNext() -> void
---- Jelly.ItemAnimator/<ShowUp>d__0::MoveNext 0x2d15464
02d15464: sub     sp, sp, #0x90                              
02d15468: str     d8, [sp, #0x30]                            
02d1546c: stp     x30, x27, [sp, #0x40]                      
02d15470: stp     x26, x25, [sp, #0x50]                      
02d15474: stp     x24, x23, [sp, #0x60]                      
02d15478: stp     x22, x21, [sp, #0x70]                      
02d1547c: stp     x20, x19, [sp, #0x80]                      
02d15480: adrp    x20, #0x662f000                            
02d15484: mov     x19, x0                                    
02d15488: ldrb    w8, [x20, #0xfcd]                          
02d1548c: tbnz    w8, #0, #0x2d154b0                         
02d15490: adrp    x0, #0x6269000                             
02d15494: ldr     x0, [x0, #0x880]                           MS:System.Runtime.CompilerServices.AsyncVoidMethodBuilder::AwaitUnsafeOnCompleted
02d15498: bl      #0x2b70db0                                 fn_2b70db0
02d1549c: adrp    x0, #0x6266000                             
02d154a0: ldr     x0, [x0, #0xcc8]                           T:Cysharp.Threading.Tasks.UniTask
02d154a4: bl      #0x2b70db0                                 fn_2b70db0
02d154a8: mov     w8, #1                                     
02d154ac: strb    w8, [x20, #0xfcd]                          
02d154b0: stp     xzr, xzr, [sp, #0x10]                      
02d154b4: adrp    x24, #0x6264000                            
02d154b8: ldr     w8, [x19]                                  
02d154bc: ldr     x20, [x19, #0x28]                          
02d154c0: ldr     x24, [x24, #0xd8]                          T:UnityEngine.Vector3
02d154c4: adrp    x25, #0x662f000                            
02d154c8: adrp    x23, #0x1084000                            
02d154cc: str     wzr, [sp, #8]                              
02d154d0: cbz     w8, #0x2d15610                             
02d154d4: cbz     x20, #0x2d157fc                            
02d154d8: mov     x0, x20                                    
02d154dc: mov     x1, xzr                                    
02d154e0: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02d154e4: ldrb    w8, [x25, #0xa74]                          
02d154e8: mov     x21, x0                                    
02d154ec: cbnz    w8, #0x2d15504                             
02d154f0: adrp    x0, #0x6264000                             
02d154f4: ldr     x0, [x0, #0xd8]                            T:UnityEngine.Vector3
02d154f8: bl      #0x2b70db0                                 fn_2b70db0
02d154fc: mov     w8, #1                                     
02d15500: strb    w8, [x25, #0xa74]                          
02d15504: cbz     x21, #0x2d15800                            
02d15508: ldr     x8, [x24]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d1550c: ldr     x8, [x8, #0xb8]                            
02d15510: ldp     s1, s2, [x8, #0x10]                        
02d15514: ldr     s0, [x8, #0xc]                             
02d15518: mov     x0, x21                                    
02d1551c: mov     x1, xzr                                    
02d15520: bl      #0x5b470cc                                 UnityEngine.Transform::set_localScale
02d15524: mov     x0, x20                                    
02d15528: mov     x1, xzr                                    
02d1552c: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02d15530: mov     w1, wzr                                    
02d15534: mov     x2, xzr                                    
02d15538: bl      #0x2d9d5d0                                 DG.Tweening.ShortcutExtensions::DOKill
02d1553c: mov     x0, x20                                    
02d15540: mov     x1, xzr                                    
02d15544: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02d15548: ldr     s8, [x23, #0xda4]                          [1084da4]=3eb851ec3e19999a f=0.15,0.36
02d1554c: adrp    x8, #0x1084000                             
02d15550: mov     x1, xzr                                    
02d15554: ldr     s0, [x8, #0xbd4]                           [1084bd4]=440980003f666666 f=0.9,550
02d15558: fmov    s1, s8                                     
02d1555c: bl      #0x2d98fd4                                 DG.Tweening.ShortcutExtensions::DOScaleY
02d15560: mov     x0, x20                                    
02d15564: mov     x1, xzr                                    
02d15568: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02d1556c: fmov    s1, s8                                     
02d15570: adrp    x8, #0x1084000                             
02d15574: mov     x1, xzr                                    
02d15578: ldr     s0, [x8, #0xcfc]                           [1084cfc]=3e58658c3f8ccccd f=1.1,0.211325
02d1557c: bl      #0x2d98e28                                 DG.Tweening.ShortcutExtensions::DOScaleX
02d15580: adrp    x26, #0x6266000                            
02d15584: ldr     x26, [x26, #0xcc8]                         T:Cysharp.Threading.Tasks.UniTask
02d15588: ldr     x0, [x26]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d1558c: ldr     w8, [x0, #0xe4]                            [62640e4]=0 f=0,0
02d15590: cbnz    w8, #0x2d15598                             
02d15594: bl      #0x2b70f30                                 fn_2b70f30
02d15598: fmov    s0, s8                                     
02d1559c: mov     w0, wzr                                    
02d155a0: mov     w1, #8                                     
02d155a4: mov     x2, xzr                                    
02d155a8: mov     w3, wzr                                    
02d155ac: mov     x4, xzr                                    
02d155b0: bl      #0x5447b08                                 Cysharp.Threading.Tasks.UniTask::WaitForSeconds
02d155b4: stp     x0, x1, [sp, #0x20]                        
02d155b8: add     x0, sp, #0x20                              
02d155bc: mov     x1, xzr                                    
02d155c0: bl      #0x2b70d54                                 fn_2b70d54
02d155c4: adrp    x27, #0x662f000                            
02d155c8: ldp     x21, x22, [sp, #0x20]                      
02d155cc: ldrb    w8, [x27, #0xbdc]                          
02d155d0: stp     x21, x22, [sp, #0x10]                      
02d155d4: cbnz    w8, #0x2d155ec                             
02d155d8: adrp    x0, #0x6266000                             
02d155dc: ldr     x0, [x0, #0xcc8]                           T:Cysharp.Threading.Tasks.UniTask
02d155e0: bl      #0x2b70db0                                 fn_2b70db0
02d155e4: mov     w8, #1                                     
02d155e8: strb    w8, [x27, #0xbdc]                          
02d155ec: ldr     x0, [x26]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d155f0: ldr     w8, [x0, #0xe4]                            [62660e4]=0 f=0,0
02d155f4: cbnz    w8, #0x2d155fc                             
02d155f8: bl      #0x2b70f30                                 fn_2b70f30
02d155fc: adrp    x26, #0x662f000                            
02d15600: ldrb    w8, [x26, #0xbdd]                          
02d15604: cbz     w8, #0x2d15628                             
02d15608: cbnz    x21, #0x2d15640                            
02d1560c: b       #0x2d156a8                                 
02d15610: ldr     q0, [x19, #0x30]                           
02d15614: mov     w8, #-1                                    
02d15618: stp     xzr, xzr, [x19, #0x30]                     
02d1561c: str     w8, [x19]                                  
02d15620: str     q0, [sp, #0x10]                            
02d15624: b       #0x2d156a8                                 
02d15628: adrp    x0, #0x6266000                             
02d1562c: ldr     x0, [x0, #0xcd0]                           T:Cysharp.Threading.Tasks.IUniTaskSource
02d15630: bl      #0x2b70db0                                 fn_2b70db0
02d15634: mov     w8, #1                                     
02d15638: strb    w8, [x26, #0xbdd]                          
02d1563c: cbz     x21, #0x2d156a8                            
02d15640: adrp    x10, #0x6266000                            
02d15644: ldr     x8, [x21]                                  
02d15648: ldr     x10, [x10, #0xcd0]                         T:Cysharp.Threading.Tasks.IUniTaskSource
02d1564c: ldrh    w9, [x8, #0x12e]                           
02d15650: ldr     x1, [x10]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d15654: cbz     x9, #0x2d15678                             
02d15658: ldr     x10, [x8, #0xb0]                           [10840b0]=2e656e69676e4579 f=1.1252e+24,5.21666e-11
02d1565c: add     x10, x10, #8                               &6266008
02d15660: ldur    x11, [x10, #-8]                            
02d15664: cmp     x11, x1                                    
02d15668: b.eq    #0x2d15688                                 
02d1566c: subs    x9, x9, #1                                 
02d15670: add     x10, x10, #0x10                            &6266010
02d15674: b.ne    #0x2d15660                                 
02d15678: mov     x0, x21                                    
02d1567c: mov     w2, wzr                                    
02d15680: bl      #0x2baa05c                                 fn_2baa05c
02d15684: b       #0x2d15694                                 
02d15688: ldrsw   x9, [x10]                                  
02d1568c: add     x8, x8, x9, lsl #4                         &1084000
02d15690: add     x0, x8, #0x138                             &1084138
02d15694: ldp     x8, x2, [x0]                               
02d15698: mov     x0, x21                                    
02d1569c: mov     w1, w22                                    
02d156a0: blr     x8                                         
02d156a4: cbz     w0, #0x2d157c0                             
02d156a8: adrp    x21, #0x662f000                            
02d156ac: ldrb    w8, [x21, #0xbde]                          
02d156b0: cbnz    w8, #0x2d156c8                             
02d156b4: adrp    x0, #0x6266000                             
02d156b8: ldr     x0, [x0, #0xcd0]                           T:Cysharp.Threading.Tasks.IUniTaskSource
02d156bc: bl      #0x2b70db0                                 fn_2b70db0
02d156c0: mov     w8, #1                                     
02d156c4: strb    w8, [x21, #0xbde]                          
02d156c8: ldr     x21, [sp, #0x10]                           
02d156cc: cbz     x21, #0x2d1573c                            
02d156d0: adrp    x10, #0x6266000                            
02d156d4: ldr     x8, [x21]                                  &2b706c4(=eb01011ff9400808)
02d156d8: ldr     x10, [x10, #0xcd0]                         T:Cysharp.Threading.Tasks.IUniTaskSource
02d156dc: ldrh    w22, [sp, #0x18]                           
02d156e0: ldrh    w9, [x8, #0x12e]                           
02d156e4: ldr     x1, [x10]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d156e8: cbz     x9, #0x2d1570c                             
02d156ec: ldr     x10, [x8, #0xb0]                           [10840b0]=2e656e69676e4579 f=1.1252e+24,5.21666e-11
02d156f0: add     x10, x10, #8                               &6266008
02d156f4: ldur    x11, [x10, #-8]                            
02d156f8: cmp     x11, x1                                    
02d156fc: b.eq    #0x2d1571c                                 
02d15700: subs    x9, x9, #1                                 
02d15704: add     x10, x10, #0x10                            &6266010
02d15708: b.ne    #0x2d156f4                                 
02d1570c: mov     x0, x21                                    
02d15710: mov     w2, #2                                     
02d15714: bl      #0x2baa05c                                 fn_2baa05c
02d15718: b       #0x2d1572c                                 
02d1571c: ldr     w9, [x10]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d15720: add     w9, w9, #2                                 
02d15724: add     x8, x8, w9, sxtw #4                        &1084000
02d15728: add     x0, x8, #0x138                             &1084138
02d1572c: ldp     x8, x2, [x0]                               
02d15730: mov     x0, x21                                    
02d15734: mov     w1, w22                                    
02d15738: blr     x8                                         
02d1573c: cbz     x20, #0x2d157f8                            
02d15740: mov     x0, x20                                    
02d15744: mov     x1, xzr                                    
02d15748: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02d1574c: ldrb    w8, [x25, #0xa74]                          
02d15750: mov     x20, x0                                    
02d15754: cbnz    w8, #0x2d1576c                             
02d15758: adrp    x0, #0x6264000                             
02d1575c: ldr     x0, [x0, #0xd8]                            T:UnityEngine.Vector3
02d15760: bl      #0x2b70db0                                 fn_2b70db0
02d15764: mov     w8, #1                                     
02d15768: strb    w8, [x25, #0xa74]                          
02d1576c: ldr     x8, [x24]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d15770: ldr     x8, [x8, #0xb8]                            [10840b8]=2632726f74636556 f=7.20646e+31,6.19112e-16
02d15774: ldp     s0, s1, [x8, #0xc]                         
02d15778: ldr     s2, [x8, #0x14]                            [1084014]=6974554955472e65 f=1.36876e+13,1.84613e+25
02d1577c: ldr     s3, [x23, #0xda4]                          [1084da4]=3eb851ec3e19999a f=0.15,0.36
02d15780: mov     x0, x20                                    
02d15784: mov     x1, xzr                                    
02d15788: bl      #0x2d98af8                                 DG.Tweening.ShortcutExtensions::DOScale
02d1578c: mov     w8, #-2                                    
02d15790: mov     x1, xzr                                    
02d15794: str     w8, [x19], #8                              
02d15798: mov     x0, x19                                    
02d1579c: bl      #0x4d43b50                                 System.Runtime.CompilerServices.AsyncVoidMethodBuilder::SetResult
02d157a0: ldp     x20, x19, [sp, #0x80]                      
02d157a4: ldr     d8, [sp, #0x30]                            
02d157a8: ldp     x22, x21, [sp, #0x70]                      
02d157ac: ldp     x24, x23, [sp, #0x60]                      
02d157b0: ldp     x26, x25, [sp, #0x50]                      
02d157b4: ldp     x30, x27, [sp, #0x40]                      
02d157b8: add     sp, sp, #0x90                              
02d157bc: ret                                                
02d157c0: ldr     q0, [sp, #0x10]                            
02d157c4: str     wzr, [x19]                                 
02d157c8: str     q0, [x19, #0x30]                           
02d157cc: add     x0, x19, #0x30                             
02d157d0: mov     x1, xzr                                    
02d157d4: bl      #0x2b70d54                                 fn_2b70d54
02d157d8: adrp    x8, #0x6269000                             
02d157dc: ldr     x8, [x8, #0x880]                           MS:System.Runtime.CompilerServices.AsyncVoidMethodBuilder::AwaitUnsafeOnCompleted
02d157e0: ldr     x3, [x8]                                   T:Trading.TradingSession/<>c__DisplayClass56_0
02d157e4: add     x0, x19, #8                                
02d157e8: add     x1, sp, #0x10                              
02d157ec: mov     x2, x19                                    
02d157f0: bl      #0x30c3970                                 fn_30c3970
02d157f4: b       #0x2d157a0                                 
02d157f8: bl      #0x2b7105c                                 fn_2b7105c
02d157fc: bl      #0x2b7105c                                 fn_2b7105c
02d15800: bl      #0x2b7105c                                 fn_2b7105c
02d15804: b       #0x2d15854                                 
02d15808: b       #0x2d15854                                 
02d1580c: b       #0x2d15854                                 
02d15810: b       #0x2d15854                                 
02d15814: b       #0x2d15854                                 
02d15818: b       #0x2d15854                                 
02d1581c: b       #0x2d15854                                 
02d15820: b       #0x2d15854                                 
02d15824: b       #0x2d15854                                 
02d15828: b       #0x2d15854                                 
02d1582c: b       #0x2d15854                                 
02d15830: b       #0x2d15854                                 
02d15834: b       #0x2d15854                                 
02d15838: b       #0x2d15854                                 
02d1583c: b       #0x2d15854                                 
02d15840: b       #0x2d15854                                 
02d15844: b       #0x2d15854                                 
02d15848: b       #0x2d15854                                 
02d1584c: b       #0x2d15854                                 
02d15850: b       #0x2d15854                                 
02d15854: mov     x20, x0                                    
02d15858: cmp     w1, #1                                     
02d1585c: b.ne    #0x2d158ec                                 
02d15860: mov     x0, x20                                    
02d15864: bl      #0x5e90260                                 fn_5e90260
02d15868: mov     x20, x0                                    
02d1586c: adrp    x0, #0x6263000                             
02d15870: ldr     x0, [x0, #0xae0]                           T:System.Exception
02d15874: bl      #0x2b70dc4                                 fn_2b70dc4
02d15878: ldr     x8, [x20]                                  &2b706c4(=eb01011ff9400808)
02d1587c: ldr     x1, [x8]                                   T:Trading.TradingSession/<>c__DisplayClass56_0
02d15880: bl      #0x2b71464                                 fn_2b71464
02d15884: tbz     w0, #0, #0x2d158c4                         
02d15888: ldrsw   x21, [sp, #8]                              
02d1588c: ldr     x20, [x20]                                 &2b706c4(=eb01011ff9400808)
02d15890: mov     x8, sp                                     
02d15894: str     x20, [x8, x21, lsl #3]                     
02d15898: add     w8, w21, #1                                
02d1589c: str     w8, [sp, #8]                               
02d158a0: bl      #0x5e90270                                 fn_5e90270
02d158a4: mov     w8, #-2                                    
02d158a8: mov     x1, x20                                    
02d158ac: mov     x2, xzr                                    
02d158b0: str     w8, [x19], #8                              
02d158b4: mov     x0, x19                                    
02d158b8: bl      #0x4d43cc0                                 System.Runtime.CompilerServices.AsyncVoidMethodBuilder::SetException
02d158bc: str     w21, [sp, #8]                              
02d158c0: b       #0x2d157a0                                 
02d158c4: mov     w0, #8                                     
02d158c8: bl      #0x5e90290                                 fn_5e90290
02d158cc: ldr     x8, [x20]                                  &2b706c4(=eb01011ff9400808)
02d158d0: str     x8, [x0]                                   
02d158d4: adrp    x1, #0x5e96000                             
02d158d8: add     x1, x1, #0x758                             &5e96758
02d158dc: mov     x2, xzr                                    
02d158e0: bl      #0x5e902a0                                 fn_5e902a0
02d158e4: mov     x20, x0                                    
02d158e8: bl      #0x5e90270                                 fn_5e90270
02d158ec: mov     x0, x20                                    
02d158f0: bl      #0x2c6051c                                 fn_2c6051c
02d158f4: bl      #0x27369b8                                 fn_27369b8
## SetStateMachine(System.Runtime.CompilerServices.IAsyncStateMachine stateMachine) -> void
---- Jelly.ItemAnimator/<ShowUp>d__0::SetStateMachine 0x2d158f8
02d158f8: add     x0, x0, #8                                 
02d158fc: mov     x2, xzr                                    
02d15900: b       #0x4d43a8c                                 System.Runtime.CompilerServices.AsyncVoidMethodBuilder::SetStateMachine
#### CLASS Jelly.ItemAnimator parent= UnityEngine.MonoBehaviour
## ShowUp() -> void
---- Jelly.ItemAnimator::ShowUp 0x2d14ea4
02d14ea4: sub     sp, sp, #0x80                              
02d14ea8: stp     x30, x21, [sp, #0x60]                      
02d14eac: stp     x20, x19, [sp, #0x70]                      
02d14eb0: adrp    x21, #0x662f000                            
02d14eb4: adrp    x20, #0x6269000                            
02d14eb8: mov     x19, x0                                    
02d14ebc: ldrb    w8, [x21, #0xfca]                          
02d14ec0: ldr     x20, [x20, #0x868]                         MS:System.Runtime.CompilerServices.AsyncVoidMethodBuilder::Start
02d14ec4: tbnz    w8, #0, #0x2d14edc                         
02d14ec8: adrp    x0, #0x6269000                             
02d14ecc: ldr     x0, [x0, #0x868]                           MS:System.Runtime.CompilerServices.AsyncVoidMethodBuilder::Start
02d14ed0: bl      #0x2b70db0                                 fn_2b70db0
02d14ed4: mov     w8, #1                                     
02d14ed8: strb    w8, [x21, #0xfca]                          
02d14edc: movi    v0.2d, #0000000000000000                   
02d14ee0: mov     x8, sp                                     
02d14ee4: mov     x0, xzr                                    
02d14ee8: stp     q0, q0, [sp, #0x20]                        
02d14eec: stp     q0, q0, [sp, #0x40]                        
02d14ef0: bl      #0x4d43a24                                 System.Runtime.CompilerServices.AsyncVoidMethodBuilder::Create
02d14ef4: ldp     q0, q1, [sp]                               
02d14ef8: add     x21, sp, #0x20                             
02d14efc: orr     x0, x21, #8                                
02d14f00: mov     x1, xzr                                    
02d14f04: stur    q0, [sp, #0x28]                            
02d14f08: stur    q1, [sp, #0x38]                            
02d14f0c: bl      #0x2b70d54                                 fn_2b70d54
02d14f10: add     x0, x21, #0x28                             &662f028
02d14f14: mov     x1, x19                                    
02d14f18: str     x19, [sp, #0x48]                           
02d14f1c: bl      #0x2b70d54                                 fn_2b70d54
02d14f20: ldr     x2, [x20]                                  T:Trading.TradingSession/<>c__DisplayClass56_0
02d14f24: mov     w8, #-1                                    
02d14f28: orr     x0, x21, #8                                
02d14f2c: add     x1, sp, #0x20                              
02d14f30: str     w8, [sp, #0x20]                            
02d14f34: bl      #0x30c7c98                                 fn_30c7c98
02d14f38: ldp     x20, x19, [sp, #0x70]                      
02d14f3c: ldp     x30, x21, [sp, #0x60]                      
02d14f40: add     sp, sp, #0x80                              
02d14f44: ret                                                
## Hide() -> void
---- Jelly.ItemAnimator::Hide 0x2d14f48
02d14f48: ret                                                
## Shake() -> void
---- Jelly.ItemAnimator::Shake 0x2d14f4c
02d14f4c: sub     sp, sp, #0x90                              
02d14f50: stp     x30, x21, [sp, #0x70]                      
02d14f54: stp     x20, x19, [sp, #0x80]                      
02d14f58: adrp    x21, #0x662f000                            
02d14f5c: adrp    x20, #0x6269000                            
02d14f60: mov     x19, x0                                    
02d14f64: ldrb    w8, [x21, #0xfcb]                          
02d14f68: ldr     x20, [x20, #0x870]                         MS:System.Runtime.CompilerServices.AsyncVoidMethodBuilder::Start
02d14f6c: tbnz    w8, #0, #0x2d14f84                         
02d14f70: adrp    x0, #0x6269000                             
02d14f74: ldr     x0, [x0, #0x870]                           MS:System.Runtime.CompilerServices.AsyncVoidMethodBuilder::Start
02d14f78: bl      #0x2b70db0                                 fn_2b70db0
02d14f7c: mov     w8, #1                                     
02d14f80: strb    w8, [x21, #0xfcb]                          
02d14f84: movi    v0.2d, #0000000000000000                   
02d14f88: mov     x8, sp                                     
02d14f8c: mov     x0, xzr                                    
02d14f90: stp     q0, q0, [sp, #0x30]                        
02d14f94: stp     q0, q0, [sp, #0x50]                        
02d14f98: str     q0, [sp, #0x20]                            
02d14f9c: bl      #0x4d43a24                                 System.Runtime.CompilerServices.AsyncVoidMethodBuilder::Create
02d14fa0: ldp     q0, q1, [sp]                               
02d14fa4: add     x21, sp, #0x20                             
02d14fa8: orr     x0, x21, #8                                
02d14fac: mov     x1, xzr                                    
02d14fb0: stur    q0, [sp, #0x28]                            
02d14fb4: stur    q1, [sp, #0x38]                            
02d14fb8: bl      #0x2b70d54                                 fn_2b70d54
02d14fbc: add     x0, x21, #0x28                             &662f028
02d14fc0: mov     x1, x19                                    
02d14fc4: str     x19, [sp, #0x48]                           
02d14fc8: bl      #0x2b70d54                                 fn_2b70d54
02d14fcc: ldr     x2, [x20]                                  T:Trading.TradingSession/<>c__DisplayClass56_0
02d14fd0: mov     w8, #-1                                    
02d14fd4: orr     x0, x21, #8                                
02d14fd8: add     x1, sp, #0x20                              
02d14fdc: str     w8, [sp, #0x20]                            
02d14fe0: bl      #0x30c7ba4                                 fn_30c7ba4
02d14fe4: ldp     x20, x19, [sp, #0x80]                      
02d14fe8: ldp     x30, x21, [sp, #0x70]                      
02d14fec: add     sp, sp, #0x90                              
02d14ff0: ret                                                
## .ctor() -> void
---- Jelly.ItemAnimator::.ctor 0x2d14ff4
02d14ff4: mov     x1, xzr                                    
02d14ff8: b       #0x5b397b0                                 UnityEngine.MonoBehaviour::.ctor
