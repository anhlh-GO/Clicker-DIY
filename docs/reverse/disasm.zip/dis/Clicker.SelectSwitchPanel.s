#### CLASS Clicker.SelectSwitchPanel/<>c__DisplayClass13_0 parent= object
#   field dataUser                       DataUser                                           off=0x10 attr=6 
#   field <>4__this                      Clicker.SelectSwitchPanel                          off=0x18 attr=6 
## .ctor() -> void
---- Clicker.SelectSwitchPanel/<>c__DisplayClass13_0::.ctor 0x2d74310
02d74310: mov     x1, xzr                                    
02d74314: b       #0x4e53e9c                                 System.Object::.ctor
#### CLASS Clicker.SelectSwitchPanel/<>c__DisplayClass13_1 parent= object
#   field configData                     Clicker.SwitchItemData                             off=0x10 attr=6 
#   field CS$<>8__locals1                Clicker.SelectSwitchPanel/<>c__DisplayClass13_0    off=0x18 attr=6 
## .ctor() -> void
---- Clicker.SelectSwitchPanel/<>c__DisplayClass13_1::.ctor 0x2d74318
02d74318: mov     x1, xzr                                    
02d7431c: b       #0x4e53e9c                                 System.Object::.ctor
## <LoadData>b__0(int id) -> void
---- Clicker.SelectSwitchPanel/<>c__DisplayClass13_1::<LoadData>b__0 0x2d745b4
02d745b4: sub     sp, sp, #0x40                              
02d745b8: stp     x30, x23, [sp, #0x10]                      
02d745bc: stp     x22, x21, [sp, #0x20]                      
02d745c0: stp     x20, x19, [sp, #0x30]                      
02d745c4: adrp    x21, #0x6630000                            
02d745c8: mov     w19, w1                                    
02d745cc: mov     x20, x0                                    
02d745d0: ldrb    w8, [x21, #0x3cb]                          
02d745d4: tbnz    w8, #0, #0x2d745f8                         
02d745d8: adrp    x0, #0x626c000                             
02d745dc: ldr     x0, [x0, #0x258]                           MS:System.Enum::TryParse
02d745e0: bl      #0x2b70db0                                 fn_2b70db0
02d745e4: adrp    x0, #0x626b000                             
02d745e8: ldr     x0, [x0, #0xee0]                           MS:MonoSingleton`1::get_Instance
02d745ec: bl      #0x2b70db0                                 fn_2b70db0
02d745f0: mov     w8, #1                                     
02d745f4: strb    w8, [x21, #0x3cb]                          
02d745f8: ldr     x8, [x20, #0x18]                           .CS$<>8__locals1
02d745fc: str     wzr, [sp, #0xc]                            
02d74600: cbz     x8, #0x2d7472c                             
02d74604: ldr     x0, [x8, #0x10]                            
02d74608: cbz     x0, #0x2d7472c                             
02d7460c: adrp    x22, #0x626b000                            
02d74610: mov     w1, w19                                    
02d74614: mov     x2, xzr                                    
02d74618: ldr     x22, [x22, #0xee0]                         MS:MonoSingleton`1::get_Instance
02d7461c: bl      #0x2cabd84                                 DataUser::UnlockClickerSwitch
02d74620: ldr     x0, [x22]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d74624: bl      #0x3769600                                 fn_3769600
02d74628: cbz     x0, #0x2d7472c                             
02d7462c: mov     w1, w19                                    
02d74630: mov     x2, xzr                                    
02d74634: bl      #0x2d6c814                                 Clicker.KeycapMakerController::SpawnSwitch
02d74638: ldr     x8, [x20, #0x10]                           .configData
02d7463c: cbz     x8, #0x2d7472c                             
02d74640: adrp    x9, #0x6263000                             
02d74644: adrp    x23, #0x626c000                            
02d74648: ldr     x9, [x9, #0x970]                           &6645c70(=0)
02d7464c: ldr     x0, [x9, #0x98]                            [6263098]=0 f=0,0
02d74650: ldr     w9, [x0, #0xe4]                            [626b0e4]=0 f=0,0
02d74654: ldr     x23, [x23, #0x258]                         MS:System.Enum::TryParse
02d74658: ldr     x21, [x8, #0x20]                           
02d7465c: cbnz    w9, #0x2d74664                             
02d74660: bl      #0x2b70f30                                 fn_2b70f30
02d74664: ldr     x2, [x23]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d74668: add     x1, sp, #0xc                               
02d7466c: mov     x0, x21                                    
02d74670: bl      #0x31788a0                                 fn_31788a0
02d74674: tbz     w0, #0, #0x2d746b4                         
02d74678: bl      #0x2d6eec8                                 Framework.AudioManager::get_Instance
02d7467c: cbz     x0, #0x2d7472c                             
02d74680: movi    d1, #0000000000000000                      
02d74684: movi    d2, #0000000000000000                      
02d74688: ldr     w1, [sp, #0xc]                             
02d7468c: fmov    s0, #1.00000000                            
02d74690: mov     w2, wzr                                    
02d74694: mov     w3, wzr                                    
02d74698: bl      #0x2d6f03c                                 Framework.AudioManager::PlaySound
02d7469c: ldr     x0, [x22]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d746a0: bl      #0x3769600                                 fn_3769600
02d746a4: cbz     x0, #0x2d7472c                             
02d746a8: ldr     w1, [sp, #0xc]                             
02d746ac: mov     x2, xzr                                    
02d746b0: bl      #0x2d6cb1c                                 Clicker.KeycapMakerController::SetSwitchSound
02d746b4: ldr     x8, [x20, #0x18]                           .CS$<>8__locals1
02d746b8: cbz     x8, #0x2d7472c                             
02d746bc: ldr     x8, [x8, #0x18]                            
02d746c0: cbz     x8, #0x2d7472c                             
02d746c4: ldr     x0, [x8, #0x58]                            
02d746c8: cbz     x0, #0x2d7472c                             
02d746cc: mov     w1, #1                                     
02d746d0: mov     x2, xzr                                    
02d746d4: bl      #0x2d6519c                                 Clicker.IngameClickerScreen::ShowBtnNext
02d746d8: ldr     x8, [x20, #0x18]                           .CS$<>8__locals1
02d746dc: cbz     x8, #0x2d7472c                             
02d746e0: ldr     x0, [x8, #0x18]                            
02d746e4: cbz     x0, #0x2d7472c                             
02d746e8: mov     w1, w19                                    
02d746ec: bl      #0x2d74320                                 Clicker.SelectSwitchPanel::OnItemSelect
02d746f0: ldr     x8, [x20, #0x18]                           .CS$<>8__locals1
02d746f4: cbz     x8, #0x2d7472c                             
02d746f8: ldr     x8, [x8, #0x18]                            
02d746fc: cbz     x8, #0x2d7472c                             
02d74700: ldr     x0, [x8, #0x58]                            
02d74704: mov     w9, #1                                     
02d74708: strb    w9, [x8, #0x60]                            
02d7470c: cbz     x0, #0x2d7472c                             
02d74710: mov     x1, xzr                                    
02d74714: bl      #0x2d6a9a4                                 Clicker.IngameClickerScreen::HideTutorial
02d74718: ldp     x20, x19, [sp, #0x30]                      
02d7471c: ldp     x22, x21, [sp, #0x20]                      
02d74720: ldp     x30, x23, [sp, #0x10]                      
02d74724: add     sp, sp, #0x40                              
02d74728: ret                                                
02d7472c: bl      #0x2b7105c                                 fn_2b7105c
#### CLASS Clicker.SelectSwitchPanel/<>c__DisplayClass14_0 parent= object
#   field id                             int                                                off=0x10 attr=6 
## .ctor() -> void
---- Clicker.SelectSwitchPanel/<>c__DisplayClass14_0::.ctor 0x2d743f8
02d743f8: mov     x1, xzr                                    
02d743fc: b       #0x4e53e9c                                 System.Object::.ctor
## <OnItemSelect>b__0(Clicker.SwitchUIItem item) -> void
---- Clicker.SelectSwitchPanel/<>c__DisplayClass14_0::<OnItemSelect>b__0 0x2d74730
02d74730: str     x30, [sp, #-0x20]!                         
02d74734: stp     x20, x19, [sp, #0x10]                      
02d74738: cbz     x1, #0x2d74794                             
02d7473c: mov     x19, x1                                    
02d74740: mov     x20, x0                                    
02d74744: mov     x0, x1                                     
02d74748: mov     x1, xzr                                    
02d7474c: bl      #0x5b339ec                                 UnityEngine.Component::get_gameObject
02d74750: cbz     x0, #0x2d74794                             
02d74754: mov     x1, xzr                                    
02d74758: bl      #0x5b36bfc                                 UnityEngine.GameObject::get_activeSelf
02d7475c: tbz     w0, #0, #0x2d74788                         
02d74760: ldr     x10, [x19]                                 
02d74764: ldr     w8, [x19, #0x6c]                           
02d74768: mov     x0, x19                                    
02d7476c: ldr     w9, [x20, #0x10]                           .id
02d74770: ldp     x20, x19, [sp, #0x10]                      
02d74774: ldp     x3, x2, [x10, #0x188]                      
02d74778: cmp     w8, w9                                     
02d7477c: cset    w1, eq                                     
02d74780: ldr     x30, [sp], #0x20                           
02d74784: br      x3                                         
02d74788: ldp     x20, x19, [sp, #0x10]                      
02d7478c: ldr     x30, [sp], #0x20                           
02d74790: ret                                                
02d74794: bl      #0x2b7105c                                 fn_2b7105c
#### CLASS Clicker.SelectSwitchPanel parent= UnityEngine.MonoBehaviour
#   field _switchUIItem                  Clicker.SwitchUIItem                               off=0x20 attr=1 SerializeField
#   field _listItem                      System.Collections.Generic.List`1<Clicker.SwitchUIItem> off=0x28 attr=1 SerializeField
#   field _configSwitch                  Clicker.SwitchConfig                               off=0x30 attr=1 SerializeField
#   field _rtShowPos                     UnityEngine.RectTransform                          off=0x38 attr=1 SerializeField
#   field _rtHidePos                     UnityEngine.RectTransform                          off=0x40 attr=1 SerializeField
#   field _thisPanelRect                 UnityEngine.RectTransform                          off=0x48 attr=1 SerializeField
#   field _btnNextPos                    UnityEngine.Transform                              off=0x50 attr=1 SerializeField
#   field _ingameClickerScreen           Clicker.IngameClickerScreen                        off=0x58 attr=1 
#   field _tutorialShown                 bool                                               off=0x60 attr=1 
## Init(Clicker.IngameClickerScreen ingameClickerScreen) -> void
---- Clicker.SelectSwitchPanel::Init 0x2d73b74
02d73b74: str     x1, [x0, #0x58]!                           ._ingameClickerScreen
02d73b78: b       #0x2b70d54                                 
## Awake() -> void
---- Clicker.SelectSwitchPanel::Awake 0x2d73b7c
02d73b7c: str     x30, [sp, #-0x20]!                         
02d73b80: stp     x20, x19, [sp, #0x10]                      
02d73b84: mov     x19, x0                                    
02d73b88: ldr     x0, [x0, #0x40]                            ._rtHidePos
02d73b8c: cbz     x0, #0x2d73bdc                             
02d73b90: ldr     x20, [x19, #0x48]                          ._thisPanelRect
02d73b94: mov     x1, xzr                                    
02d73b98: bl      #0x5b45734                                 UnityEngine.RectTransform::get_anchoredPosition
02d73b9c: cbz     x20, #0x2d73bdc                            
02d73ba0: mov     x0, x20                                    
02d73ba4: mov     x1, xzr                                    
02d73ba8: bl      #0x5b45800                                 UnityEngine.RectTransform::set_anchoredPosition
02d73bac: ldr     x0, [x19, #0x48]                           ._thisPanelRect
02d73bb0: cbz     x0, #0x2d73bdc                             
02d73bb4: mov     x1, xzr                                    
02d73bb8: bl      #0x5b339ec                                 UnityEngine.Component::get_gameObject
02d73bbc: cbz     x0, #0x2d73bdc                             
02d73bc0: mov     w1, wzr                                    
02d73bc4: mov     x2, xzr                                    
02d73bc8: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d73bcc: mov     x0, x19                                    
02d73bd0: ldp     x20, x19, [sp, #0x10]                      
02d73bd4: ldr     x30, [sp], #0x20                           
02d73bd8: b       #0x2d73be0                                 Clicker.SelectSwitchPanel::LoadData
02d73bdc: bl      #0x2b7105c                                 fn_2b7105c
## ShowPanel() -> void
---- Clicker.SelectSwitchPanel::ShowPanel 0x2d74080
02d74080: str     x30, [sp, #-0x50]!                         
02d74084: stp     x26, x25, [sp, #0x10]                      
02d74088: stp     x24, x23, [sp, #0x20]                      
02d7408c: stp     x22, x21, [sp, #0x30]                      
02d74090: stp     x20, x19, [sp, #0x40]                      
02d74094: adrp    x20, #0x6630000                            
02d74098: mov     x19, x0                                    
02d7409c: ldrb    w8, [x20, #0x3c5]                          
02d740a0: tbnz    w8, #0, #0x2d740f4                         
02d740a4: adrp    x0, #0x6264000                             
02d740a8: ldr     x0, [x0, #0xf90]                           T:System.Action
02d740ac: bl      #0x2b70db0                                 fn_2b70db0
02d740b0: adrp    x0, #0x626c000                             
02d740b4: ldr     x0, [x0, #0x750]                           M:Clicker.SelectSwitchPanel::<ShowPanel>b__11_0
02d740b8: bl      #0x2b70db0                                 fn_2b70db0
02d740bc: adrp    x0, #0x626c000                             
02d740c0: ldr     x0, [x0, #0x758]                           M:Clicker.SelectSwitchPanel::<ShowPanel>b__11_1
02d740c4: bl      #0x2b70db0                                 fn_2b70db0
02d740c8: adrp    x0, #0x6264000                             
02d740cc: ldr     x0, [x0, #0xe8]                            T:DG.Tweening.TweenCallback
02d740d0: bl      #0x2b70db0                                 fn_2b70db0
02d740d4: adrp    x0, #0x6266000                             
02d740d8: ldr     x0, [x0, #0xa08]                           MS:DG.Tweening.TweenSettingsExtensions::OnComplete
02d740dc: bl      #0x2b70db0                                 fn_2b70db0
02d740e0: adrp    x0, #0x6266000                             
02d740e4: ldr     x0, [x0, #0xa18]                           MS:DG.Tweening.TweenSettingsExtensions::SetEase
02d740e8: bl      #0x2b70db0                                 fn_2b70db0
02d740ec: mov     w8, #1                                     
02d740f0: strb    w8, [x20, #0x3c5]                          
02d740f4: ldr     x0, [x19, #0x48]                           ._thisPanelRect
02d740f8: cbz     x0, #0x2d74218                             
02d740fc: mov     x1, xzr                                    
02d74100: bl      #0x5b339ec                                 UnityEngine.Component::get_gameObject
02d74104: cbz     x0, #0x2d74218                             
02d74108: mov     w1, #1                                     
02d7410c: mov     x2, xzr                                    
02d74110: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d74114: ldr     x0, [x19, #0x38]                           ._rtShowPos
02d74118: cbz     x0, #0x2d74218                             
02d7411c: adrp    x21, #0x6266000                            
02d74120: adrp    x23, #0x6264000                            
02d74124: adrp    x24, #0x626c000                            
02d74128: adrp    x25, #0x6266000                            
02d7412c: adrp    x26, #0x6264000                            
02d74130: adrp    x22, #0x626c000                            
02d74134: ldr     x21, [x21, #0xa18]                         MS:DG.Tweening.TweenSettingsExtensions::SetEase
02d74138: ldr     x23, [x23, #0xe8]                          T:DG.Tweening.TweenCallback
02d7413c: ldr     x24, [x24, #0x750]                         M:Clicker.SelectSwitchPanel::<ShowPanel>b__11_0
02d74140: ldr     x25, [x25, #0xa08]                         MS:DG.Tweening.TweenSettingsExtensions::OnComplete
02d74144: ldr     x26, [x26, #0xf90]                         T:System.Action
02d74148: ldr     x22, [x22, #0x758]                         M:Clicker.SelectSwitchPanel::<ShowPanel>b__11_1
02d7414c: ldr     x20, [x19, #0x48]                          ._thisPanelRect
02d74150: mov     x1, xzr                                    
02d74154: bl      #0x5b45734                                 UnityEngine.RectTransform::get_anchoredPosition
02d74158: fmov    s2, #0.50000000                            
02d7415c: mov     x0, x20                                    
02d74160: mov     w1, wzr                                    
02d74164: mov     x2, xzr                                    
02d74168: bl      #0x2c798bc                                 DG.Tweening.DOTweenModuleUI::DOAnchorPos
02d7416c: ldr     x2, [x21]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d74170: mov     w1, #3                                     
02d74174: bl      #0x336fa0c                                 fn_336fa0c
02d74178: ldr     x8, [x23]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d7417c: mov     x20, x0                                    
02d74180: mov     x0, x8                                     
02d74184: bl      #0x2b7104c                                 fn_2b7104c
02d74188: ldr     x2, [x24]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d7418c: mov     x1, x19                                    
02d74190: mov     x3, xzr                                    
02d74194: mov     x21, x0                                    
02d74198: bl      #0x2d89dc4                                 DG.Tweening.TweenCallback::.ctor
02d7419c: ldr     x2, [x25]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d741a0: mov     x0, x20                                    
02d741a4: mov     x1, x21                                    
02d741a8: bl      #0x336f26c                                 fn_336f26c
02d741ac: ldr     x0, [x26]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d741b0: ldr     x20, [x19, #0x58]                          ._ingameClickerScreen
02d741b4: bl      #0x2b7104c                                 fn_2b7104c
02d741b8: ldr     x2, [x22]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d741bc: mov     x1, x19                                    
02d741c0: mov     x3, xzr                                    
02d741c4: mov     x21, x0                                    
02d741c8: bl      #0x4d8ddbc                                 System.Action::.ctor
02d741cc: cbz     x20, #0x2d74218                            
02d741d0: mov     x0, x20                                    
02d741d4: mov     x1, x21                                    
02d741d8: mov     x2, xzr                                    
02d741dc: bl      #0x2d69948                                 Clicker.IngameClickerScreen::RegisterButtonNextEvent
02d741e0: ldr     x0, [x19, #0x50]                           ._btnNextPos
02d741e4: cbz     x0, #0x2d74218                             
02d741e8: ldr     x19, [x19, #0x58]                          ._ingameClickerScreen
02d741ec: mov     x1, xzr                                    
02d741f0: bl      #0x5b467ac                                 UnityEngine.Transform::get_position
02d741f4: cbz     x19, #0x2d74218                            
02d741f8: mov     x0, x19                                    
02d741fc: ldp     x20, x19, [sp, #0x40]                      
02d74200: ldp     x22, x21, [sp, #0x30]                      
02d74204: mov     x1, xzr                                    
02d74208: ldp     x24, x23, [sp, #0x20]                      
02d7420c: ldp     x26, x25, [sp, #0x10]                      
02d74210: ldr     x30, [sp], #0x50                           
02d74214: b       #0x2d69a28                                 Clicker.IngameClickerScreen::SetBtnNextPosition
02d74218: bl      #0x2b7105c                                 fn_2b7105c
## HidePanel() -> void
---- Clicker.SelectSwitchPanel::HidePanel 0x2d7421c
02d7421c: str     x30, [sp, #-0x40]!                         
02d74220: stp     x24, x23, [sp, #0x10]                      
02d74224: stp     x22, x21, [sp, #0x20]                      
02d74228: stp     x20, x19, [sp, #0x30]                      
02d7422c: adrp    x20, #0x6630000                            
02d74230: mov     x19, x0                                    
02d74234: ldrb    w8, [x20, #0x3c6]                          
02d74238: tbnz    w8, #0, #0x2d74274                         
02d7423c: adrp    x0, #0x626c000                             
02d74240: ldr     x0, [x0, #0x760]                           M:Clicker.SelectSwitchPanel::<HidePanel>b__12_0
02d74244: bl      #0x2b70db0                                 fn_2b70db0
02d74248: adrp    x0, #0x6264000                             
02d7424c: ldr     x0, [x0, #0xe8]                            T:DG.Tweening.TweenCallback
02d74250: bl      #0x2b70db0                                 fn_2b70db0
02d74254: adrp    x0, #0x6266000                             
02d74258: ldr     x0, [x0, #0xa08]                           MS:DG.Tweening.TweenSettingsExtensions::OnComplete
02d7425c: bl      #0x2b70db0                                 fn_2b70db0
02d74260: adrp    x0, #0x6266000                             
02d74264: ldr     x0, [x0, #0xa18]                           MS:DG.Tweening.TweenSettingsExtensions::SetEase
02d74268: bl      #0x2b70db0                                 fn_2b70db0
02d7426c: mov     w8, #1                                     
02d74270: strb    w8, [x20, #0x3c6]                          
02d74274: ldr     x0, [x19, #0x40]                           ._rtHidePos
02d74278: cbz     x0, #0x2d7430c                             
02d7427c: adrp    x21, #0x6266000                            
02d74280: adrp    x22, #0x6264000                            
02d74284: adrp    x23, #0x626c000                            
02d74288: adrp    x24, #0x6266000                            
02d7428c: ldr     x21, [x21, #0xa18]                         MS:DG.Tweening.TweenSettingsExtensions::SetEase
02d74290: ldr     x22, [x22, #0xe8]                          T:DG.Tweening.TweenCallback
02d74294: ldr     x23, [x23, #0x760]                         M:Clicker.SelectSwitchPanel::<HidePanel>b__12_0
02d74298: ldr     x24, [x24, #0xa08]                         MS:DG.Tweening.TweenSettingsExtensions::OnComplete
02d7429c: ldr     x20, [x19, #0x48]                          ._thisPanelRect
02d742a0: mov     x1, xzr                                    
02d742a4: bl      #0x5b45734                                 UnityEngine.RectTransform::get_anchoredPosition
02d742a8: fmov    s2, #0.50000000                            
02d742ac: mov     x0, x20                                    
02d742b0: mov     w1, wzr                                    
02d742b4: mov     x2, xzr                                    
02d742b8: bl      #0x2c798bc                                 DG.Tweening.DOTweenModuleUI::DOAnchorPos
02d742bc: ldr     x2, [x21]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d742c0: mov     w1, #2                                     
02d742c4: bl      #0x336fa0c                                 fn_336fa0c
02d742c8: ldr     x8, [x22]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d742cc: mov     x20, x0                                    
02d742d0: mov     x0, x8                                     
02d742d4: bl      #0x2b7104c                                 fn_2b7104c
02d742d8: ldr     x2, [x23]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d742dc: mov     x1, x19                                    
02d742e0: mov     x3, xzr                                    
02d742e4: mov     x21, x0                                    
02d742e8: bl      #0x2d89dc4                                 DG.Tweening.TweenCallback::.ctor
02d742ec: ldr     x2, [x24]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d742f0: mov     x0, x20                                    
02d742f4: mov     x1, x21                                    
02d742f8: ldp     x20, x19, [sp, #0x30]                      
02d742fc: ldp     x22, x21, [sp, #0x20]                      
02d74300: ldp     x24, x23, [sp, #0x10]                      
02d74304: ldr     x30, [sp], #0x40                           
02d74308: b       #0x336f26c                                 
02d7430c: bl      #0x2b7105c                                 fn_2b7105c
## LoadData() -> void
---- Clicker.SelectSwitchPanel::LoadData 0x2d73be0
02d73be0: stp     x29, x30, [sp, #-0x60]!                    
02d73be4: stp     x28, x27, [sp, #0x10]                      
02d73be8: stp     x26, x25, [sp, #0x20]                      
02d73bec: stp     x24, x23, [sp, #0x30]                      
02d73bf0: stp     x22, x21, [sp, #0x40]                      
02d73bf4: stp     x20, x19, [sp, #0x50]                      
02d73bf8: adrp    x20, #0x6630000                            
02d73bfc: adrp    x21, #0x626c000                            
02d73c00: mov     x19, x0                                    
02d73c04: ldrb    w8, [x20, #0x3c7]                          
02d73c08: ldr     x21, [x21, #0x718]                         T:Clicker.SelectSwitchPanel/<>c__DisplayClass13_0
02d73c0c: tbnz    w8, #0, #0x2d73c9c                         
02d73c10: adrp    x0, #0x6269000                             
02d73c14: ldr     x0, [x0, #0x5e8]                           T:type6940(k15)
02d73c18: bl      #0x2b70db0                                 fn_2b70db0
02d73c1c: adrp    x0, #0x6266000                             
02d73c20: ldr     x0, [x0, #0x750]                           MS:DataManager::GetData
02d73c24: bl      #0x2b70db0                                 fn_2b70db0
02d73c28: adrp    x0, #0x626c000                             
02d73c2c: ldr     x0, [x0, #0x720]                           MS:System.Collections.Generic.List`1::Add
02d73c30: bl      #0x2b70db0                                 fn_2b70db0
02d73c34: adrp    x0, #0x626c000                             
02d73c38: ldr     x0, [x0, #0x728]                           MS:System.Collections.Generic.List`1::get_Count
02d73c3c: bl      #0x2b70db0                                 fn_2b70db0
02d73c40: adrp    x0, #0x626c000                             
02d73c44: ldr     x0, [x0, #0x730]                           MS:System.Collections.Generic.List`1::get_Item
02d73c48: bl      #0x2b70db0                                 fn_2b70db0
02d73c4c: adrp    x0, #0x6266000                             
02d73c50: ldr     x0, [x0, #0x658]                           MS:MonoSingleton`1::get_Instance
02d73c54: bl      #0x2b70db0                                 fn_2b70db0
02d73c58: adrp    x0, #0x626c000                             
02d73c5c: ldr     x0, [x0, #0x738]                           MS:UnityEngine.Object::Instantiate
02d73c60: bl      #0x2b70db0                                 fn_2b70db0
02d73c64: adrp    x0, #0x6263000                             
02d73c68: ldr     x0, [x0, #0x918]                           T:UnityEngine.Object
02d73c6c: bl      #0x2b70db0                                 fn_2b70db0
02d73c70: adrp    x0, #0x626c000                             
02d73c74: ldr     x0, [x0, #0x718]                           T:Clicker.SelectSwitchPanel/<>c__DisplayClass13_0
02d73c78: bl      #0x2b70db0                                 fn_2b70db0
02d73c7c: adrp    x0, #0x626c000                             
02d73c80: ldr     x0, [x0, #0x740]                           M:Clicker.SelectSwitchPanel/<>c__DisplayClass13_1::<LoadData>b__0
02d73c84: bl      #0x2b70db0                                 fn_2b70db0
02d73c88: adrp    x0, #0x626c000                             
02d73c8c: ldr     x0, [x0, #0x748]                           T:Clicker.SelectSwitchPanel/<>c__DisplayClass13_1
02d73c90: bl      #0x2b70db0                                 fn_2b70db0
02d73c94: mov     w8, #1                                     
02d73c98: strb    w8, [x20, #0x3c7]                          
02d73c9c: ldr     x0, [x21]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d73ca0: bl      #0x2b7104c                                 fn_2b7104c
02d73ca4: mov     x1, xzr                                    
02d73ca8: mov     x20, x0                                    
02d73cac: bl      #0x4e53e9c                                 System.Object::.ctor
02d73cb0: cbz     x20, #0x2d74060                            
02d73cb4: mov     x0, x20                                    
02d73cb8: mov     x1, x19                                    
02d73cbc: str     x19, [x0, #0x18]!                          
02d73cc0: bl      #0x2b70d54                                 fn_2b70d54
02d73cc4: ldr     x8, [x19, #0x28]                           ._listItem
02d73cc8: cbz     x8, #0x2d74060                             
02d73ccc: adrp    x28, #0x626c000                            
02d73cd0: adrp    x27, #0x626c000                            
02d73cd4: adrp    x29, #0x626c000                            
02d73cd8: adrp    x26, #0x6263000                            
02d73cdc: adrp    x24, #0x626c000                            
02d73ce0: adrp    x25, #0x626c000                            
02d73ce4: ldr     x28, [x28, #0x748]                         T:Clicker.SelectSwitchPanel/<>c__DisplayClass13_1
02d73ce8: ldr     x27, [x27, #0x730]                         MS:System.Collections.Generic.List`1::get_Item
02d73cec: ldr     x29, [x29, #0x740]                         M:Clicker.SelectSwitchPanel/<>c__DisplayClass13_1::<LoadData>b__0
02d73cf0: ldr     x26, [x26, #0x918]                         T:UnityEngine.Object
02d73cf4: ldr     x24, [x24, #0x738]                         MS:UnityEngine.Object::Instantiate
02d73cf8: ldr     x25, [x25, #0x720]                         MS:System.Collections.Generic.List`1::Add
02d73cfc: ldr     x0, [x19, #0x30]                           ._configSwitch
02d73d00: cbz     x0, #0x2d74060                             
02d73d04: ldr     w21, [x8, #0x18]                           
02d73d08: mov     x1, xzr                                    
02d73d0c: bl      #0x2d5bce0                                 Clicker.SwitchConfig::get_Count
02d73d10: cmp     w21, w0                                    
02d73d14: b.ge    #0x2d73dcc                                 
02d73d18: ldr     x22, [x19, #0x20]                          ._switchUIItem
02d73d1c: cbz     x22, #0x2d74060                            
02d73d20: ldr     x21, [x19, #0x28]                          ._listItem
02d73d24: mov     x0, x22                                    
02d73d28: mov     x1, xzr                                    
02d73d2c: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02d73d30: cbz     x0, #0x2d74060                             
02d73d34: mov     x1, xzr                                    
02d73d38: bl      #0x5b466dc                                 UnityEngine.Transform::get_parent
02d73d3c: ldr     x8, [x26]                                  &2c5bbd4(=a9bd7bfdd503233f)
02d73d40: mov     x23, x0                                    
02d73d44: ldr     w9, [x8, #0xe4]                            
02d73d48: cbnz    w9, #0x2d73d54                             
02d73d4c: mov     x0, x8                                     
02d73d50: bl      #0x2b70f30                                 fn_2b70f30
02d73d54: ldr     x2, [x24]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d73d58: mov     x0, x22                                    
02d73d5c: mov     x1, x23                                    
02d73d60: bl      #0x3275fcc                                 fn_3275fcc
02d73d64: cbz     x21, #0x2d74060                            
02d73d68: ldr     w10, [x21, #0x1c]                          [626c01c]=0 f=0,0
02d73d6c: ldr     x8, [x21, #0x10]                           M:Clicker.GlowSprite2DItem::<DoGlow>b__10_4
02d73d70: ldr     x9, [x25]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d73d74: add     w10, w10, #1                               
02d73d78: str     w10, [x21, #0x1c]                          
02d73d7c: cbz     x8, #0x2d74060                             
02d73d80: ldrsw   x10, [x21, #0x18]                          
02d73d84: ldr     w11, [x8, #0x18]                           
02d73d88: mov     x1, x0                                     
02d73d8c: cmp     w10, w11                                   
02d73d90: b.hs    #0x2d73dac                                 
02d73d94: add     x0, x8, x10, lsl #3                        
02d73d98: add     w9, w10, #1                                
02d73d9c: str     w9, [x21, #0x18]                           
02d73da0: str     x1, [x0, #0x20]!                           ._switchUIItem
02d73da4: bl      #0x2b70d54                                 fn_2b70d54
02d73da8: b       #0x2d73dc0                                 
02d73dac: ldr     x8, [x9, #0x20]                            
02d73db0: mov     x0, x21                                    
02d73db4: ldr     x8, [x8, #0xc0]                            
02d73db8: ldr     x2, [x8, #0x70]                            
02d73dbc: bl      #0x35a920c                                 fn_35a920c
02d73dc0: ldr     x8, [x19, #0x28]                           ._listItem
02d73dc4: cbnz    x8, #0x2d73cfc                             
02d73dc8: b       #0x2d74060                                 
02d73dcc: adrp    x8, #0x6266000                             
02d73dd0: ldr     x8, [x8, #0x658]                           MS:MonoSingleton`1::get_Instance
02d73dd4: ldr     x0, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d73dd8: bl      #0x3769600                                 fn_3769600
02d73ddc: cbz     x0, #0x2d74060                             
02d73de0: adrp    x8, #0x6266000                             
02d73de4: ldr     x8, [x8, #0x750]                           MS:DataManager::GetData
02d73de8: ldr     x1, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d73dec: bl      #0x3168dd0                                 fn_3168dd0
02d73df0: mov     x1, x0                                     
02d73df4: mov     x0, x20                                    
02d73df8: str     x1, [x0, #0x10]!                           
02d73dfc: bl      #0x2b70d54                                 fn_2b70d54
02d73e00: ldr     x0, [x19, #0x30]                           ._configSwitch
02d73e04: cbz     x0, #0x2d74060                             
02d73e08: mov     w21, wzr                                   
02d73e0c: mov     x1, xzr                                    
02d73e10: bl      #0x2d5bce0                                 Clicker.SwitchConfig::get_Count
02d73e14: cmp     w21, w0                                    
02d73e18: b.ge    #0x2d74000                                 
02d73e1c: ldr     x0, [x28]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d73e20: bl      #0x2b7104c                                 fn_2b7104c
02d73e24: mov     x1, xzr                                    
02d73e28: mov     x22, x0                                    
02d73e2c: bl      #0x4e53e9c                                 System.Object::.ctor
02d73e30: cbz     x22, #0x2d74060                            
02d73e34: mov     x24, x22                                   
02d73e38: mov     x1, x20                                    
02d73e3c: str     x20, [x24, #0x18]!                         
02d73e40: mov     x0, x24                                    
02d73e44: bl      #0x2b70d54                                 fn_2b70d54
02d73e48: ldr     x0, [x19, #0x30]                           ._configSwitch
02d73e4c: cbz     x0, #0x2d74060                             
02d73e50: mov     w1, w21                                    
02d73e54: mov     x2, xzr                                    
02d73e58: bl      #0x2d5bd98                                 Clicker.SwitchConfig::GetData
02d73e5c: mov     x23, x22                                   
02d73e60: mov     x1, x0                                     
02d73e64: str     x0, [x23, #0x10]!                          
02d73e68: mov     x0, x23                                    
02d73e6c: bl      #0x2b70d54                                 fn_2b70d54
02d73e70: ldr     x8, [x23]                                  
02d73e74: ldr     x0, [x19, #0x28]                           ._listItem
02d73e78: cbz     x8, #0x2d73f00                             
02d73e7c: cbz     x0, #0x2d74060                             
02d73e80: ldr     x2, [x27]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d73e84: mov     w1, w21                                    
02d73e88: bl      #0x35a8f3c                                 fn_35a8f3c
02d73e8c: ldr     x8, [x23]                                  
02d73e90: cbz     x8, #0x2d74060                             
02d73e94: cbz     x0, #0x2d74060                             
02d73e98: ldr     x9, [x0]                                   M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d73e9c: ldr     x2, [x8, #0x18]                            S:'level_show_popuprate'
02d73ea0: ldr     w1, [x8, #0x10]                            S:'mrec_ad_on_off'
02d73ea4: ldp     x8, x3, [x9, #0x178]                       
02d73ea8: blr     x8                                         
02d73eac: ldr     x0, [x19, #0x28]                           ._listItem
02d73eb0: cbz     x0, #0x2d74060                             
02d73eb4: ldr     x2, [x27]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d73eb8: mov     w1, w21                                    
02d73ebc: bl      #0x35a8f3c                                 fn_35a8f3c
02d73ec0: ldr     x8, [x23]                                  
02d73ec4: cbz     x8, #0x2d74060                             
02d73ec8: ldr     x9, [x8, #0x38]                            S:'native_collap_id'
02d73ecc: cbz     x9, #0x2d74060                             
02d73ed0: ldr     x10, [x24]                                 M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d73ed4: cbz     x10, #0x2d74060                            
02d73ed8: mov     x25, x0                                    
02d73edc: ldr     x0, [x10, #0x10]                           
02d73ee0: cbz     x0, #0x2d74060                             
02d73ee4: ldp     w24, w26, [x9, #0x10]                      
02d73ee8: ldr     w1, [x8, #0x10]                            S:'mrec_ad_on_off'
02d73eec: mov     x2, xzr                                    
02d73ef0: bl      #0x2cabe7c                                 DataUser::HasUnlockedClickerSwitch
02d73ef4: tbz     w0, #0, #0x2d73f30                         
02d73ef8: mov     w3, #1                                     
02d73efc: b       #0x2d73f4c                                 
02d73f00: cbz     x0, #0x2d74060                             
02d73f04: ldr     x2, [x27]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d73f08: mov     w1, w21                                    
02d73f0c: bl      #0x35a8f3c                                 fn_35a8f3c
02d73f10: cbz     x0, #0x2d74060                             
02d73f14: mov     x1, xzr                                    
02d73f18: bl      #0x5b339ec                                 UnityEngine.Component::get_gameObject
02d73f1c: cbz     x0, #0x2d74060                             
02d73f20: mov     w1, wzr                                    
02d73f24: mov     x2, xzr                                    
02d73f28: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d73f2c: b       #0x2d73ff0                                 
02d73f30: ldr     x8, [x23]                                  
02d73f34: cbz     x8, #0x2d74060                             
02d73f38: ldr     x8, [x8, #0x38]                            S:'native_collap_id'
02d73f3c: cbz     x8, #0x2d74060                             
02d73f40: ldr     w8, [x8, #0x10]                            S:'mrec_ad_on_off'
02d73f44: cmp     w8, #0                                     
02d73f48: cset    w3, eq                                     
02d73f4c: cbz     x25, #0x2d74060                            
02d73f50: ldr     x8, [x25]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d73f54: mov     x0, x25                                    
02d73f58: mov     w1, w24                                    
02d73f5c: mov     w2, w26                                    
02d73f60: ldp     x9, x4, [x8, #0x1a8]                       
02d73f64: blr     x9                                         
02d73f68: ldr     x0, [x19, #0x28]                           ._listItem
02d73f6c: cbz     x0, #0x2d74060                             
02d73f70: ldr     x2, [x27]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d73f74: mov     w1, w21                                    
02d73f78: bl      #0x35a8f3c                                 fn_35a8f3c
02d73f7c: cbz     x0, #0x2d74060                             
02d73f80: mov     x1, xzr                                    
02d73f84: bl      #0x5b339ec                                 UnityEngine.Component::get_gameObject
02d73f88: cbz     x0, #0x2d74060                             
02d73f8c: mov     w1, #1                                     
02d73f90: mov     x2, xzr                                    
02d73f94: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d73f98: ldr     x0, [x19, #0x28]                           ._listItem
02d73f9c: cbz     x0, #0x2d74060                             
02d73fa0: ldr     x2, [x27]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d73fa4: mov     w1, w21                                    
02d73fa8: bl      #0x35a8f3c                                 fn_35a8f3c
02d73fac: adrp    x8, #0x6269000                             
02d73fb0: mov     x23, x0                                    
02d73fb4: ldr     x8, [x8, #0x5e8]                           T:type6940(k15)
02d73fb8: ldr     x8, [x8]                                   T:Trading.TradingSession/<>c__DisplayClass56_0
02d73fbc: mov     x0, x8                                     
02d73fc0: bl      #0x2b7104c                                 fn_2b7104c
02d73fc4: ldr     x2, [x29]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d73fc8: mov     x1, x22                                    
02d73fcc: mov     x3, xzr                                    
02d73fd0: mov     x24, x0                                    
02d73fd4: bl      #0x4532eb0                                 fn_4532eb0
02d73fd8: cbz     x23, #0x2d74060                            
02d73fdc: ldr     x8, [x23]                                  
02d73fe0: mov     x0, x23                                    
02d73fe4: mov     x1, x24                                    
02d73fe8: ldp     x9, x2, [x8, #0x198]                       
02d73fec: blr     x9                                         
02d73ff0: ldr     x0, [x19, #0x30]                           ._configSwitch
02d73ff4: add     w21, w21, #1                               
02d73ff8: cbnz    x0, #0x2d73e0c                             
02d73ffc: b       #0x2d74060                                 
02d74000: ldr     x0, [x19, #0x30]                           ._configSwitch
02d74004: cbz     x0, #0x2d74060                             
02d74008: mov     x1, xzr                                    
02d7400c: bl      #0x2d5bce0                                 Clicker.SwitchConfig::get_Count
02d74010: ldr     x8, [x19, #0x28]                           ._listItem
02d74014: cbz     x8, #0x2d74060                             
02d74018: mov     w20, w0                                    
02d7401c: ldr     w9, [x8, #0x18]                            M:Trading.TradingSession::<ValidateTrade>b__57_0
02d74020: cmp     w20, w9                                    
02d74024: b.ge    #0x2d74064                                 
02d74028: ldr     x2, [x27]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d7402c: mov     x0, x8                                     
02d74030: mov     w1, w20                                    
02d74034: bl      #0x35a8f3c                                 fn_35a8f3c
02d74038: cbz     x0, #0x2d74060                             
02d7403c: mov     x1, xzr                                    
02d74040: bl      #0x5b339ec                                 UnityEngine.Component::get_gameObject
02d74044: cbz     x0, #0x2d74060                             
02d74048: mov     w1, wzr                                    
02d7404c: mov     x2, xzr                                    
02d74050: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d74054: ldr     x8, [x19, #0x28]                           ._listItem
02d74058: add     w20, w20, #1                               
02d7405c: cbnz    x8, #0x2d7401c                             
02d74060: bl      #0x2b7105c                                 fn_2b7105c
02d74064: ldp     x20, x19, [sp, #0x50]                      
02d74068: ldp     x22, x21, [sp, #0x40]                      
02d7406c: ldp     x24, x23, [sp, #0x30]                      
02d74070: ldp     x26, x25, [sp, #0x20]                      
02d74074: ldp     x28, x27, [sp, #0x10]                      
02d74078: ldp     x29, x30, [sp], #0x60                      
02d7407c: ret                                                
## OnItemSelect(int id) -> void
---- Clicker.SelectSwitchPanel::OnItemSelect 0x2d74320
02d74320: str     x30, [sp, #-0x30]!                         
02d74324: stp     x22, x21, [sp, #0x10]                      
02d74328: stp     x20, x19, [sp, #0x20]                      
02d7432c: adrp    x21, #0x6630000                            
02d74330: adrp    x22, #0x626c000                            
02d74334: mov     w19, w1                                    
02d74338: ldrb    w8, [x21, #0x3c8]                          
02d7433c: ldr     x22, [x22, #0x768]                         T:Clicker.SelectSwitchPanel/<>c__DisplayClass14_0
02d74340: mov     x20, x0                                    
02d74344: tbnz    w8, #0, #0x2d74380                         
02d74348: adrp    x0, #0x626c000                             
02d7434c: ldr     x0, [x0, #0x770]                           T:type53161(k15)
02d74350: bl      #0x2b70db0                                 fn_2b70db0
02d74354: adrp    x0, #0x626c000                             
02d74358: ldr     x0, [x0, #0x778]                           MS:System.Collections.Generic.List`1::ForEach
02d7435c: bl      #0x2b70db0                                 fn_2b70db0
02d74360: adrp    x0, #0x626c000                             
02d74364: ldr     x0, [x0, #0x780]                           M:Clicker.SelectSwitchPanel/<>c__DisplayClass14_0::<OnItemSelect>b__0
02d74368: bl      #0x2b70db0                                 fn_2b70db0
02d7436c: adrp    x0, #0x626c000                             
02d74370: ldr     x0, [x0, #0x768]                           T:Clicker.SelectSwitchPanel/<>c__DisplayClass14_0
02d74374: bl      #0x2b70db0                                 fn_2b70db0
02d74378: mov     w8, #1                                     
02d7437c: strb    w8, [x21, #0x3c8]                          
02d74380: ldr     x0, [x22]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d74384: bl      #0x2b7104c                                 fn_2b7104c
02d74388: mov     x1, xzr                                    
02d7438c: mov     x21, x0                                    
02d74390: bl      #0x4e53e9c                                 System.Object::.ctor
02d74394: cbz     x21, #0x2d743f4                            
02d74398: adrp    x8, #0x626c000                             
02d7439c: adrp    x22, #0x626c000                            
02d743a0: ldr     x8, [x8, #0x770]                           T:type53161(k15)
02d743a4: ldr     x22, [x22, #0x780]                         M:Clicker.SelectSwitchPanel/<>c__DisplayClass14_0::<OnItemSelect>b__0
02d743a8: ldr     x20, [x20, #0x28]                          ._listItem
02d743ac: str     w19, [x21, #0x10]                          
02d743b0: ldr     x0, [x8]                                   M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d743b4: bl      #0x2b7104c                                 fn_2b7104c
02d743b8: ldr     x2, [x22]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d743bc: mov     x1, x21                                    
02d743c0: mov     x3, xzr                                    
02d743c4: mov     x19, x0                                    
02d743c8: bl      #0x453418c                                 fn_453418c
02d743cc: cbz     x20, #0x2d743f4                            
02d743d0: adrp    x8, #0x626c000                             
02d743d4: mov     x0, x20                                    
02d743d8: mov     x1, x19                                    
02d743dc: ldr     x8, [x8, #0x778]                           MS:System.Collections.Generic.List`1::ForEach
02d743e0: ldp     x20, x19, [sp, #0x20]                      
02d743e4: ldp     x22, x21, [sp, #0x10]                      
02d743e8: ldr     x2, [x8]                                   M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d743ec: ldr     x30, [sp], #0x30                           
02d743f0: b       #0x35a9ce4                                 
02d743f4: bl      #0x2b7105c                                 fn_2b7105c
## .ctor() -> void
---- Clicker.SelectSwitchPanel::.ctor 0x2d74400
02d74400: mov     x1, xzr                                    
02d74404: b       #0x5b397b0                                 UnityEngine.MonoBehaviour::.ctor
## <ShowPanel>b__11_0() -> void
---- Clicker.SelectSwitchPanel::<ShowPanel>b__11_0 0x2d74408
02d74408: str     x30, [sp, #-0x20]!                         
02d7440c: stp     x20, x19, [sp, #0x10]                      
02d74410: adrp    x20, #0x6630000                            
02d74414: mov     x19, x0                                    
02d74418: ldrb    w8, [x20, #0x3c9]                          
02d7441c: tbnz    w8, #0, #0x2d74434                         
02d74420: adrp    x0, #0x626c000                             
02d74424: ldr     x0, [x0, #0x730]                           MS:System.Collections.Generic.List`1::get_Item
02d74428: bl      #0x2b70db0                                 fn_2b70db0
02d7442c: mov     w8, #1                                     
02d74430: strb    w8, [x20, #0x3c9]                          
02d74434: ldrb    w8, [x19, #0x60]                           ._tutorialShown
02d74438: cbz     w8, #0x2d74448                             
02d7443c: ldp     x20, x19, [sp, #0x10]                      
02d74440: ldr     x30, [sp], #0x20                           
02d74444: ret                                                
02d74448: ldr     x0, [x19, #0x28]                           ._listItem
02d7444c: cbz     x0, #0x2d74490                             
02d74450: adrp    x8, #0x626c000                             
02d74454: mov     w1, wzr                                    
02d74458: ldr     x8, [x8, #0x730]                           MS:System.Collections.Generic.List`1::get_Item
02d7445c: ldr     x19, [x19, #0x58]                          ._ingameClickerScreen
02d74460: ldr     x2, [x8]                                   M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d74464: bl      #0x35a8f3c                                 fn_35a8f3c
02d74468: cbz     x0, #0x2d74490                             
02d7446c: mov     x1, xzr                                    
02d74470: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02d74474: cbz     x19, #0x2d74490                            
02d74478: mov     x1, x0                                     
02d7447c: mov     x0, x19                                    
02d74480: mov     x2, xzr                                    
02d74484: ldp     x20, x19, [sp, #0x10]                      
02d74488: ldr     x30, [sp], #0x20                           
02d7448c: b       #0x2d6a2c0                                 Clicker.IngameClickerScreen::ShowTutorialAt
02d74490: bl      #0x2b7105c                                 fn_2b7105c
## <ShowPanel>b__11_1() -> void
---- Clicker.SelectSwitchPanel::<ShowPanel>b__11_1 0x2d74494
02d74494: str     x30, [sp, #-0x20]!                         
02d74498: stp     x20, x19, [sp, #0x10]                      
02d7449c: adrp    x20, #0x6630000                            
02d744a0: mov     x19, x0                                    
02d744a4: ldrb    w8, [x20, #0x3ca]                          
02d744a8: tbnz    w8, #0, #0x2d744d8                         
02d744ac: adrp    x0, #0x6266000                             
02d744b0: ldr     x0, [x0, #0x750]                           MS:DataManager::GetData
02d744b4: bl      #0x2b70db0                                 fn_2b70db0
02d744b8: adrp    x0, #0x6265000                             
02d744bc: ldr     x0, [x0, #0xb38]                           T:DevTrack
02d744c0: bl      #0x2b70db0                                 fn_2b70db0
02d744c4: adrp    x0, #0x6266000                             
02d744c8: ldr     x0, [x0, #0x658]                           MS:MonoSingleton`1::get_Instance
02d744cc: bl      #0x2b70db0                                 fn_2b70db0
02d744d0: mov     w8, #1                                     
02d744d4: strb    w8, [x20, #0x3ca]                          
02d744d8: mov     x0, x19                                    
02d744dc: bl      #0x2d7421c                                 Clicker.SelectSwitchPanel::HidePanel
02d744e0: ldr     x0, [x19, #0x58]                           ._ingameClickerScreen
02d744e4: cbz     x0, #0x2d74584                             
02d744e8: mov     w1, wzr                                    
02d744ec: mov     x2, xzr                                    
02d744f0: bl      #0x2d6519c                                 Clicker.IngameClickerScreen::ShowBtnNext
02d744f4: ldr     x0, [x19, #0x58]                           ._ingameClickerScreen
02d744f8: cbz     x0, #0x2d74584                             
02d744fc: adrp    x19, #0x6266000                            
02d74500: mov     x1, xzr                                    
02d74504: ldr     x19, [x19, #0x658]                         MS:MonoSingleton`1::get_Instance
02d74508: bl      #0x2d6b990                                 Clicker.IngameClickerScreen::GoToStepKeycap
02d7450c: ldr     x0, [x19]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d74510: bl      #0x3769600                                 fn_3769600
02d74514: cbz     x0, #0x2d74584                             
02d74518: adrp    x8, #0x6266000                             
02d7451c: ldr     x8, [x8, #0x750]                           MS:DataManager::GetData
02d74520: ldr     x1, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d74524: bl      #0x3168dd0                                 fn_3168dd0
02d74528: cbz     x0, #0x2d74584                             
02d7452c: ldr     x8, [x0, #0x20]                            S:'inter_ad_capping_time' ._switchUIItem
02d74530: cbz     x8, #0x2d74584                             
02d74534: ldrb    w8, [x8, #0x3a]                            
02d74538: cbz     w8, #0x2d74578                             
02d7453c: adrp    x19, #0x6265000                            
02d74540: ldr     x19, [x19, #0xb38]                         T:DevTrack
02d74544: ldr     x0, [x19]                                  M:AdsManager::<OnApplicationPause>b__26_0
02d74548: ldr     w8, [x0, #0xe4]                            [62660e4]=0 f=0,0
02d7454c: cbnz    w8, #0x2d74558                             
02d74550: bl      #0x2b70f30                                 fn_2b70f30
02d74554: ldr     x0, [x19]                                  M:AdsManager::<OnApplicationPause>b__26_0
02d74558: ldr     x8, [x0, #0xb8]                            S:'banner_native_refresh_time'
02d7455c: ldp     x20, x19, [sp, #0x10]                      
02d74560: mov     x3, xzr                                    
02d74564: ldr     x0, [x8, #0x1f8]                           MS:System.Collections.Generic.List`1/Enumerator::get_Current
02d74568: ldr     x1, [x8, #0x230]                           T:UnityEngine.Purchasing.ProductDefinition
02d7456c: ldr     w2, [x8, #0x27c]                           [626627c]=0 f=0,0
02d74570: ldr     x30, [sp], #0x20                           
02d74574: b       #0x2c9c1e0                                 DevTrack::OnboardingStep
02d74578: ldp     x20, x19, [sp, #0x10]                      
02d7457c: ldr     x30, [sp], #0x20                           
02d74580: ret                                                
02d74584: bl      #0x2b7105c                                 fn_2b7105c
## <HidePanel>b__12_0() -> void
---- Clicker.SelectSwitchPanel::<HidePanel>b__12_0 0x2d74588
02d74588: str     x30, [sp, #-0x10]!                         
02d7458c: ldr     x0, [x0, #0x48]                            ._thisPanelRect
02d74590: cbz     x0, #0x2d745b0                             
02d74594: mov     x1, xzr                                    
02d74598: bl      #0x5b339ec                                 UnityEngine.Component::get_gameObject
02d7459c: cbz     x0, #0x2d745b0                             
02d745a0: mov     w1, wzr                                    
02d745a4: mov     x2, xzr                                    
02d745a8: ldr     x30, [sp], #0x10                           
02d745ac: b       #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d745b0: bl      #0x2b7105c                                 fn_2b7105c
