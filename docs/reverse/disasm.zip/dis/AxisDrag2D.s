#### CLASS AxisDrag2D/Axis parent= int
#   field value__                        int                                                off=0x10 attr=606 
#   field Horizontal                     AxisDrag2D/Axis                                    off=0x0 attr=8056 
#   field Vertical                       AxisDrag2D/Axis                                    off=0x0 attr=8056 
#### CLASS AxisDrag2D parent= UnityEngine.MonoBehaviour
#   field axis                           AxisDrag2D/Axis                                    off=0x20 attr=1 SerializeField
#   field cam                            UnityEngine.Camera                                 off=0x28 attr=1 SerializeField
#   field minValue                       float                                              off=0x30 attr=1 SerializeField
#   field maxValue                       float                                              off=0x34 attr=1 SerializeField
#   field isDragging                     bool                                               off=0x38 attr=1 
#   field grabOffset                     float                                              off=0x3c attr=1 
## Awake() -> void
---- AxisDrag2D::Awake 0x2caea58
02caea58: stp     x30, x21, [sp, #-0x20]!                    
02caea5c: stp     x20, x19, [sp, #0x10]                      
02caea60: adrp    x21, #0x662f000                            
02caea64: adrp    x20, #0x6263000                            
02caea68: mov     x19, x0                                    
02caea6c: ldrb    w8, [x21, #0xb50]                          
02caea70: ldr     x20, [x20, #0x918]                         T:UnityEngine.Object
02caea74: tbnz    w8, #0, #0x2caea8c                         
02caea78: adrp    x0, #0x6263000                             
02caea7c: ldr     x0, [x0, #0x918]                           T:UnityEngine.Object
02caea80: bl      #0x2b70db0                                 fn_2b70db0
02caea84: mov     w8, #1                                     
02caea88: strb    w8, [x21, #0xb50]                          
02caea8c: ldr     x0, [x20]                                  &2c5bbd4(=a9bd7bfdd503233f)
02caea90: ldr     x20, [x19, #0x28]!                         .cam
02caea94: ldr     w8, [x0, #0xe4]                            [62630e4]=0 f=0,0
02caea98: cbnz    w8, #0x2caeaa0                             
02caea9c: bl      #0x2b70f30                                 fn_2b70f30
02caeaa0: mov     x0, x20                                    
02caeaa4: mov     x1, xzr                                    
02caeaa8: mov     x2, xzr                                    
02caeaac: bl      #0x5b37d84                                 UnityEngine.Object::op_Equality
02caeab0: tbz     w0, #0, #0x2caead4                         
02caeab4: mov     x0, xzr                                    
02caeab8: bl      #0x5aefe28                                 UnityEngine.Camera::get_main
02caeabc: mov     x1, x0                                     
02caeac0: mov     x0, x19                                    
02caeac4: str     x1, [x19]                                  
02caeac8: ldp     x20, x19, [sp, #0x10]                      
02caeacc: ldp     x30, x21, [sp], #0x20                      
02caead0: b       #0x2b70d54                                 
02caead4: ldp     x20, x19, [sp, #0x10]                      
02caead8: ldp     x30, x21, [sp], #0x20                      
02caeadc: ret                                                
## ScrollToTop() -> void
---- AxisDrag2D::ScrollToTop 0x2caeae0
02caeae0: stp     d11, d10, [sp, #-0x40]!                    
02caeae4: stp     d9, d8, [sp, #0x10]                        
02caeae8: str     x30, [sp, #0x20]                           
02caeaec: stp     x20, x19, [sp, #0x30]                      
02caeaf0: mov     x1, xzr                                    
02caeaf4: mov     x19, x0                                    
02caeaf8: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02caeafc: cbz     x0, #0x2caeb54                             
02caeb00: mov     x1, xzr                                    
02caeb04: bl      #0x5b467ac                                 UnityEngine.Transform::get_position
02caeb08: ldr     w20, [x19, #0x20]                          .axis
02caeb0c: ldr     s11, [x19, #0x30]                          .minValue
02caeb10: mov     x0, x19                                    
02caeb14: mov     x1, xzr                                    
02caeb18: fmov    s9, s0                                     
02caeb1c: fmov    s10, s1                                    
02caeb20: fmov    s8, s2                                     
02caeb24: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02caeb28: cbz     x0, #0x2caeb54                             
02caeb2c: cmp     w20, #0                                    
02caeb30: fmov    s2, s8                                     
02caeb34: ldr     x30, [sp, #0x20]                           
02caeb38: fcsel   s0, s11, s9, eq                            
02caeb3c: ldp     x20, x19, [sp, #0x30]                      
02caeb40: ldp     d9, d8, [sp, #0x10]                        
02caeb44: fcsel   s1, s10, s11, eq                           
02caeb48: mov     x1, xzr                                    
02caeb4c: ldp     d11, d10, [sp], #0x40                      
02caeb50: b       #0x5b46888                                 UnityEngine.Transform::set_position
02caeb54: bl      #0x2b7105c                                 fn_2b7105c
## SetMaxValue(float value) -> void
---- AxisDrag2D::SetMaxValue 0x2caeb58
02caeb58: str     s0, [x0, #0x34]                            .maxValue
02caeb5c: ret                                                
## Update() -> void
---- AxisDrag2D::Update 0x2caeb60
02caeb60: str     d12, [sp, #-0x50]!                         
02caeb64: stp     d11, d10, [sp, #0x10]                      
02caeb68: stp     d9, d8, [sp, #0x20]                        
02caeb6c: stp     x30, x21, [sp, #0x30]                      
02caeb70: stp     x20, x19, [sp, #0x40]                      
02caeb74: adrp    x20, #0x662f000                            
02caeb78: mov     x19, x0                                    
02caeb7c: ldrb    w8, [x20, #0xb51]                          
02caeb80: tbnz    w8, #0, #0x2caebbc                         
02caeb84: adrp    x0, #0x6266000                             
02caeb88: ldr     x0, [x0, #0x938]                           MS:UnityEngine.InputSystem.InputControl`1::ReadValue
02caeb8c: bl      #0x2b70db0                                 fn_2b70db0
02caeb90: adrp    x0, #0x6263000                             
02caeb94: ldr     x0, [x0, #0x918]                           T:UnityEngine.Object
02caeb98: bl      #0x2b70db0                                 fn_2b70db0
02caeb9c: adrp    x0, #0x6266000                             
02caeba0: ldr     x0, [x0, #0x940]                           T:UnityEngine.Physics2D
02caeba4: bl      #0x2b70db0                                 fn_2b70db0
02caeba8: adrp    x0, #0x6266000                             
02caebac: ldr     x0, [x0, #0x948]                           T:Touch
02caebb0: bl      #0x2b70db0                                 fn_2b70db0
02caebb4: mov     w8, #1                                     
02caebb8: strb    w8, [x20, #0xb51]                          
02caebbc: adrp    x20, #0x662f000                            
02caebc0: ldrb    w8, [x20, #0xbd9]                          
02caebc4: cbnz    w8, #0x2caebdc                             
02caebc8: adrp    x0, #0x6266000                             
02caebcc: ldr     x0, [x0, #0x950]                           T:UnityEngine.InputSystem.Pointer
02caebd0: bl      #0x2b70db0                                 fn_2b70db0
02caebd4: mov     w8, #1                                     
02caebd8: strb    w8, [x20, #0xbd9]                          
02caebdc: adrp    x8, #0x6266000                             
02caebe0: ldr     x8, [x8, #0x950]                           T:UnityEngine.InputSystem.Pointer
02caebe4: ldr     x8, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02caebe8: ldr     x8, [x8, #0xb8]                            S:'banner_native_refresh_time'
02caebec: ldr     x20, [x8]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02caebf0: cbz     x20, #0x2caedbc                            
02caebf4: ldr     x0, [x20, #0x188]                          [662f188]=600006a f=2.40744e-35,0
02caebf8: cbz     x0, #0x2caee20                             
02caebfc: adrp    x8, #0x6266000                             
02caec00: ldr     x8, [x8, #0x938]                           MS:UnityEngine.InputSystem.InputControl`1::ReadValue
02caec04: ldr     x1, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02caec08: bl      #0x4a187c4                                 fn_4a187c4
02caec0c: ldr     x0, [x19, #0x28]                           .cam
02caec10: cbz     x0, #0x2caee20                             
02caec14: movi    d2, #0000000000000000                      
02caec18: mov     x1, xzr                                    
02caec1c: bl      #0x5aefbb0                                 UnityEngine.Camera::ScreenToWorldPoint
02caec20: ldr     x0, [x20, #0x1a8]                          [662f1a8]=600006c f=2.40744e-35,0
02caec24: cbz     x0, #0x2caee20                             
02caec28: mov     x1, xzr                                    
02caec2c: fmov    s8, s0                                     
02caec30: fmov    s9, s1                                     
02caec34: bl      #0x55532f0                                 UnityEngine.InputSystem.Controls.ButtonControl::get_wasPressedThisFrame
02caec38: tbz     w0, #0, #0x2caec60                         
02caec3c: adrp    x8, #0x6266000                             
02caec40: ldr     x8, [x8, #0x948]                           T:Touch
02caec44: ldr     x0, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02caec48: ldr     w8, [x0, #0xe4]                            [62660e4]=0 f=0,0
02caec4c: cbnz    w8, #0x2caec54                             
02caec50: bl      #0x2b70f30                                 fn_2b70f30
02caec54: mov     x0, xzr                                    
02caec58: bl      #0x2cd6230                                 Touch::IsPointerOverUIObject
02caec5c: tbz     w0, #0, #0x2caec7c                         
02caec60: ldr     x0, [x20, #0x1a8]                          [662f1a8]=600006c f=2.40744e-35,0
02caec64: cbz     x0, #0x2caee20                             
02caec68: mov     x1, xzr                                    
02caec6c: bl      #0x5553460                                 UnityEngine.InputSystem.Controls.ButtonControl::get_wasReleasedThisFrame
02caec70: tbz     w0, #0, #0x2caed68                         
02caec74: strb    wzr, [x19, #0x38]                          .isDragging
02caec78: b       #0x2caed68                                 
02caec7c: adrp    x8, #0x6266000                             
02caec80: ldr     x8, [x8, #0x940]                           T:UnityEngine.Physics2D
02caec84: ldr     x0, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02caec88: ldr     w8, [x0, #0xe4]                            [62660e4]=0 f=0,0
02caec8c: cbnz    w8, #0x2caec94                             
02caec90: bl      #0x2b70f30                                 fn_2b70f30
02caec94: fmov    s0, s8                                     
02caec98: fmov    s1, s9                                     
02caec9c: mov     x0, xzr                                    
02caeca0: bl      #0x5bbdad4                                 UnityEngine.Physics2D::OverlapPoint
02caeca4: adrp    x21, #0x6263000                            
02caeca8: mov     x20, x0                                    
02caecac: ldr     x21, [x21, #0x918]                         T:UnityEngine.Object
02caecb0: ldr     x8, [x21]                                  &2c5bbd4(=a9bd7bfdd503233f)
02caecb4: ldr     w9, [x8, #0xe4]                            [62660e4]=0 f=0,0
02caecb8: cbnz    w9, #0x2caecc4                             
02caecbc: mov     x0, x8                                     
02caecc0: bl      #0x2b70f30                                 fn_2b70f30
02caecc4: mov     x0, x20                                    
02caecc8: mov     x1, xzr                                    
02caeccc: mov     x2, xzr                                    
02caecd0: bl      #0x5b3666c                                 UnityEngine.Object::op_Inequality
02caecd4: tbz     w0, #0, #0x2caed68                         
02caecd8: cbz     x20, #0x2caee20                            
02caecdc: mov     x0, x20                                    
02caece0: mov     x1, xzr                                    
02caece4: bl      #0x5b339ec                                 UnityEngine.Component::get_gameObject
02caece8: mov     x20, x0                                    
02caecec: mov     x0, x19                                    
02caecf0: mov     x1, xzr                                    
02caecf4: bl      #0x5b339ec                                 UnityEngine.Component::get_gameObject
02caecf8: ldr     x8, [x21]                                  &2c5bbd4(=a9bd7bfdd503233f)
02caecfc: mov     x21, x0                                    
02caed00: ldr     w9, [x8, #0xe4]                            [62660e4]=0 f=0,0
02caed04: cbnz    w9, #0x2caed10                             
02caed08: mov     x0, x8                                     
02caed0c: bl      #0x2b70f30                                 fn_2b70f30
02caed10: mov     x0, x20                                    
02caed14: mov     x1, x21                                    
02caed18: mov     x2, xzr                                    
02caed1c: bl      #0x5b37d84                                 UnityEngine.Object::op_Equality
02caed20: tbz     w0, #0, #0x2caed68                         
02caed24: mov     w8, #1                                     
02caed28: ldr     w20, [x19, #0x20]                          .axis
02caed2c: mov     x0, x19                                    
02caed30: mov     x1, xzr                                    
02caed34: strb    w8, [x19, #0x38]                           .isDragging
02caed38: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02caed3c: cbz     w20, #0x2caed54                            
02caed40: cbz     x0, #0x2caee20                             
02caed44: mov     x1, xzr                                    
02caed48: bl      #0x5b467ac                                 UnityEngine.Transform::get_position
02caed4c: fsub    s0, s1, s9                                 
02caed50: b       #0x2caed64                                 
02caed54: cbz     x0, #0x2caee20                             
02caed58: mov     x1, xzr                                    
02caed5c: bl      #0x5b467ac                                 UnityEngine.Transform::get_position
02caed60: fsub    s0, s0, s8                                 
02caed64: str     s0, [x19, #0x3c]                           .grabOffset
02caed68: ldrb    w8, [x19, #0x38]                           .isDragging
02caed6c: cbz     w8, #0x2caedbc                             
02caed70: mov     x0, x19                                    
02caed74: mov     x1, xzr                                    
02caed78: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02caed7c: cbz     x0, #0x2caee20                             
02caed80: mov     x1, xzr                                    
02caed84: bl      #0x5b467ac                                 UnityEngine.Transform::get_position
02caed88: fmov    s12, s0                                    
02caed8c: fmov    s11, s1                                    
02caed90: ldr     w8, [x19, #0x20]                           .axis
02caed94: fmov    s10, s2                                    
02caed98: ldp     s0, s1, [x19, #0x30]                       .minValue
02caed9c: ldr     s3, [x19, #0x3c]                           .grabOffset
02caeda0: cbz     w8, #0x2caedd4                             
02caeda4: fadd    s2, s9, s3                                 
02caeda8: fcmp    s2, s1                                     
02caedac: fcsel   s1, s1, s2, gt                             
02caedb0: fcmp    s2, s0                                     
02caedb4: fcsel   s11, s0, s1, mi                            
02caedb8: b       #0x2caede8                                 
02caedbc: ldp     x20, x19, [sp, #0x40]                      
02caedc0: ldp     x30, x21, [sp, #0x30]                      
02caedc4: ldp     d9, d8, [sp, #0x20]                        
02caedc8: ldp     d11, d10, [sp, #0x10]                      
02caedcc: ldr     d12, [sp], #0x50                           
02caedd0: ret                                                
02caedd4: fadd    s2, s8, s3                                 
02caedd8: fcmp    s2, s1                                     
02caeddc: fcsel   s1, s1, s2, gt                             
02caede0: fcmp    s2, s0                                     
02caede4: fcsel   s12, s0, s1, mi                            
02caede8: mov     x0, x19                                    
02caedec: mov     x1, xzr                                    
02caedf0: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02caedf4: cbz     x0, #0x2caee20                             
02caedf8: fmov    s1, s11                                    
02caedfc: fmov    s2, s10                                    
02caee00: mov     x1, xzr                                    
02caee04: ldp     x20, x19, [sp, #0x40]                      
02caee08: fmov    s0, s12                                    
02caee0c: ldp     x30, x21, [sp, #0x30]                      
02caee10: ldp     d9, d8, [sp, #0x20]                        
02caee14: ldp     d11, d10, [sp, #0x10]                      
02caee18: ldr     d12, [sp], #0x50                           
02caee1c: b       #0x5b46888                                 UnityEngine.Transform::set_position
02caee20: bl      #0x2b7105c                                 fn_2b7105c
## .ctor() -> void
---- AxisDrag2D::.ctor 0x2caee24
02caee24: adrp    x8, #0x1040000                             
02caee28: mov     x1, xzr                                    
02caee2c: mov     w9, #1                                     
02caee30: ldr     d0, [x8, #0x718]                           [1040718]=40a00000c0a00000 f=-5,5
02caee34: str     w9, [x0, #0x20]                            .axis
02caee38: str     d0, [x0, #0x30]                            .minValue
02caee3c: b       #0x5b397b0                                 UnityEngine.MonoBehaviour::.ctor
