#### CLASS LevelConfigSO parent= GameConfig
#   field Levels                         System.Collections.Generic.List`1<Level>           off=0x10 attr=6 
## GetLevel(int levelIndex) -> Level
---- LevelConfigSO::GetLevel 0x2ca8570
02ca8570: stp     x30, x21, [sp, #-0x20]!                    
02ca8574: stp     x20, x19, [sp, #0x10]                      
02ca8578: adrp    x21, #0x662f000                            
02ca857c: mov     w19, w1                                    
02ca8580: mov     x20, x0                                    
02ca8584: ldrb    w8, [x21, #0xafb]                          
02ca8588: tbnz    w8, #0, #0x2ca85ac                         
02ca858c: adrp    x0, #0x6266000                             
02ca8590: ldr     x0, [x0, #0x5c0]                           MS:System.Collections.Generic.List`1::get_Count
02ca8594: bl      #0x2b70db0                                 fn_2b70db0
02ca8598: adrp    x0, #0x6266000                             
02ca859c: ldr     x0, [x0, #0x5c8]                           MS:System.Collections.Generic.List`1::get_Item
02ca85a0: bl      #0x2b70db0                                 fn_2b70db0
02ca85a4: mov     w8, #1                                     
02ca85a8: strb    w8, [x21, #0xafb]                          
02ca85ac: ldr     x0, [x20, #0x10]                           .Levels
02ca85b0: cbz     x0, #0x2ca85dc                             
02ca85b4: ldr     w8, [x0, #0x18]                            S:'level_show_popuprate'
02ca85b8: sub     w9, w19, #1                                
02ca85bc: adrp    x11, #0x6266000                            
02ca85c0: ldr     x11, [x11, #0x5c8]                         MS:System.Collections.Generic.List`1::get_Item
02ca85c4: ldp     x20, x19, [sp, #0x10]                      
02ca85c8: sdiv    w10, w9, w8                                
02ca85cc: ldr     x2, [x11]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca85d0: msub    w1, w10, w8, w9                            
02ca85d4: ldp     x30, x21, [sp], #0x20                      
02ca85d8: b       #0x35a8f3c                                 
02ca85dc: bl      #0x2b7105c                                 fn_2b7105c
## .ctor() -> void
---- LevelConfigSO::.ctor 0x2ca85e0
02ca85e0: stp     x30, x23, [sp, #-0x30]!                    
02ca85e4: stp     x22, x21, [sp, #0x10]                      
02ca85e8: stp     x20, x19, [sp, #0x20]                      
02ca85ec: adrp    x22, #0x662f000                            
02ca85f0: adrp    x23, #0x6266000                            
02ca85f4: adrp    x20, #0x6266000                            
02ca85f8: adrp    x21, #0x6266000                            
02ca85fc: ldr     x23, [x23, #0x5d0]                         T:type56748(k15)
02ca8600: ldrb    w8, [x22, #0xafc]                          
02ca8604: ldr     x20, [x20, #0x5d8]                         MS:System.Collections.Generic.List`1::.ctor
02ca8608: ldr     x21, [x21, #0x5e0]                         T:GameConfig
02ca860c: mov     x19, x0                                    
02ca8610: tbnz    w8, #0, #0x2ca8640                         
02ca8614: adrp    x0, #0x6266000                             
02ca8618: ldr     x0, [x0, #0x5e0]                           T:GameConfig
02ca861c: bl      #0x2b70db0                                 fn_2b70db0
02ca8620: adrp    x0, #0x6266000                             
02ca8624: ldr     x0, [x0, #0x5d8]                           MS:System.Collections.Generic.List`1::.ctor
02ca8628: bl      #0x2b70db0                                 fn_2b70db0
02ca862c: adrp    x0, #0x6266000                             
02ca8630: ldr     x0, [x0, #0x5d0]                           T:type56748(k15)
02ca8634: bl      #0x2b70db0                                 fn_2b70db0
02ca8638: mov     w8, #1                                     
02ca863c: strb    w8, [x22, #0xafc]                          
02ca8640: ldr     x0, [x23]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca8644: bl      #0x2b7104c                                 fn_2b7104c
02ca8648: ldr     x1, [x20]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca864c: mov     x20, x0                                    
02ca8650: bl      #0x35a89a4                                 fn_35a89a4
02ca8654: mov     x0, x19                                    
02ca8658: mov     x1, x20                                    
02ca865c: str     x20, [x0, #0x10]!                          .Levels
02ca8660: bl      #0x2b70d54                                 fn_2b70d54
02ca8664: ldr     x0, [x21]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca8668: ldr     w8, [x0, #0xe4]                            [62660e4]=0 f=0,0
02ca866c: cbnz    w8, #0x2ca8674                             
02ca8670: bl      #0x2b70f30                                 fn_2b70f30
02ca8674: mov     x0, x19                                    
02ca8678: ldp     x20, x19, [sp, #0x20]                      
02ca867c: ldp     x22, x21, [sp, #0x10]                      
02ca8680: mov     x1, xzr                                    
02ca8684: ldp     x30, x23, [sp], #0x30                      
02ca8688: b       #0x4e53e9c                                 System.Object::.ctor
