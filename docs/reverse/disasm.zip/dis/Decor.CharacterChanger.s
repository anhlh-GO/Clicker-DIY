#### CLASS Decor.CharacterChanger parent= UnityEngine.MonoBehaviour
#   field _currentId                     int                                                off=0x20 attr=1 
#   field _boxTrigger                    Home.BoxTrigger                                    off=0x28 attr=1 SerializeField
#   field _motionStateMachine            Character.MotionStateMachine                       off=0x30 attr=1 SerializeField,ReadOnlyAttribute
#   field _isClicked                     bool                                               off=0x38 attr=1 SerializeField,ReadOnlyAttribute
## ChangeItem(int categoryIndex, int optionID) -> void
---- Decor.CharacterChanger::ChangeItem 0x2d24be0
02d24be0: sub     sp, sp, #0x40                              
02d24be4: stp     x30, x23, [sp, #0x10]                      
02d24be8: stp     x22, x21, [sp, #0x20]                      
02d24bec: stp     x20, x19, [sp, #0x30]                      
02d24bf0: adrp    x20, #0x6630000                            
02d24bf4: adrp    x22, #0x6269000                            
02d24bf8: adrp    x23, #0x6269000                            
02d24bfc: ldr     x22, [x22, #0xf48]                         S:'ChangeItem called with categoryIndex: '
02d24c00: ldrb    w8, [x20, #0x66]                           
02d24c04: ldr     x23, [x23, #0xf50]                         S:', optionID: '
02d24c08: str     w1, [sp, #0xc]                             
02d24c0c: adrp    x21, #0x6263000                            
02d24c10: mov     x19, x0                                    
02d24c14: ldr     x21, [x21, #0x928]                         T:UnityEngine.Debug
02d24c18: str     w2, [sp, #8]                               
02d24c1c: tbnz    w8, #0, #0x2d24c70                         
02d24c20: adrp    x0, #0x6263000                             
02d24c24: ldr     x0, [x0, #0x928]                           T:UnityEngine.Debug
02d24c28: bl      #0x2b70db0                                 fn_2b70db0
02d24c2c: adrp    x0, #0x6267000                             
02d24c30: ldr     x0, [x0, #0xbd0]                           MS:MonoSingleton`1::get_Instance
02d24c34: bl      #0x2b70db0                                 fn_2b70db0
02d24c38: adrp    x0, #0x6266000                             
02d24c3c: ldr     x0, [x0, #0xac0]                           MS:MonoSingleton`1::get_Instance
02d24c40: bl      #0x2b70db0                                 fn_2b70db0
02d24c44: adrp    x0, #0x6267000                             
02d24c48: ldr     x0, [x0, #0xd58]                           MS:UIManager::GetScreen
02d24c4c: bl      #0x2b70db0                                 fn_2b70db0
02d24c50: adrp    x0, #0x6269000                             
02d24c54: ldr     x0, [x0, #0xf48]                           S:'ChangeItem called with categoryIndex: '
02d24c58: bl      #0x2b70db0                                 fn_2b70db0
02d24c5c: adrp    x0, #0x6269000                             
02d24c60: ldr     x0, [x0, #0xf50]                           S:', optionID: '
02d24c64: bl      #0x2b70db0                                 fn_2b70db0
02d24c68: mov     w8, #1                                     
02d24c6c: strb    w8, [x20, #0x66]                           
02d24c70: add     x0, sp, #0xc                               
02d24c74: mov     x1, xzr                                    
02d24c78: bl      #0x4e0ea3c                                 System.Int32::ToString
02d24c7c: mov     x20, x0                                    
02d24c80: add     x0, sp, #8                                 
02d24c84: mov     x1, xzr                                    
02d24c88: bl      #0x4e0ea3c                                 System.Int32::ToString
02d24c8c: ldr     x8, [x22]                                  T:Trading.TradingSession/<>c__DisplayClass56_0
02d24c90: ldr     x2, [x23]                                  T:Trading.TradingSession/<>c__DisplayClass56_0
02d24c94: mov     x3, x0                                     
02d24c98: mov     x1, x20                                    
02d24c9c: mov     x4, xzr                                    
02d24ca0: mov     x0, x8                                     
02d24ca4: bl      #0x4ca7320                                 System.String::Concat
02d24ca8: ldr     x8, [x21]                                  &2c5bbd4(=a9bd7bfdd503233f)
02d24cac: mov     x20, x0                                    
02d24cb0: ldr     w9, [x8, #0xe4]                            
02d24cb4: cbnz    w9, #0x2d24cc0                             
02d24cb8: mov     x0, x8                                     
02d24cbc: bl      #0x2b70f30                                 fn_2b70f30
02d24cc0: mov     x0, x20                                    
02d24cc4: mov     x1, xzr                                    
02d24cc8: bl      #0x5af21f4                                 UnityEngine.Debug::Log
02d24ccc: ldr     w9, [x19, #0x20]                           ._currentId
02d24cd0: ldr     w8, [sp, #8]                               
02d24cd4: cmp     w9, w8                                     
02d24cd8: b.eq    #0x2d24d3c                                 
02d24cdc: adrp    x9, #0x6266000                             
02d24ce0: ldr     x9, [x9, #0xac0]                           MS:MonoSingleton`1::get_Instance
02d24ce4: str     w8, [x19, #0x20]                           ._currentId
02d24ce8: ldr     x0, [x9]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d24cec: bl      #0x3769600                                 fn_3769600
02d24cf0: cbz     x0, #0x2d24d50                             
02d24cf4: mov     x1, xzr                                    
02d24cf8: bl      #0x2cacaa0                                 GameSession::GenCharacter
02d24cfc: adrp    x8, #0x6267000                             
02d24d00: ldr     x8, [x8, #0xbd0]                           MS:MonoSingleton`1::get_Instance
02d24d04: ldr     x0, [x8]                                   S:'didu'
02d24d08: bl      #0x3769600                                 fn_3769600
02d24d0c: cbz     x0, #0x2d24d50                             
02d24d10: adrp    x8, #0x6267000                             
02d24d14: ldr     x8, [x8, #0xd58]                           MS:UIManager::GetScreen
02d24d18: ldr     x1, [x8]                                   S:'didu'
02d24d1c: bl      #0x33fbbd0                                 fn_33fbbd0
02d24d20: cbz     x0, #0x2d24d50                             
02d24d24: ldr     x0, [x0, #0xc0]                            MS:System.Linq.Enumerable::Select
02d24d28: cbz     x0, #0x2d24d50                             
02d24d2c: mov     x1, xzr                                    
02d24d30: bl      #0x2cddf7c                                 ProfilePanel::UpdateAvatar
02d24d34: mov     x0, x19                                    
02d24d38: bl      #0x2d24d54                                 Decor.CharacterChanger::RegetComponents
02d24d3c: ldp     x20, x19, [sp, #0x30]                      
02d24d40: ldp     x22, x21, [sp, #0x20]                      
02d24d44: ldp     x30, x23, [sp, #0x10]                      
02d24d48: add     sp, sp, #0x40                              
02d24d4c: ret                                                
02d24d50: bl      #0x2b7105c                                 fn_2b7105c
## OnEnable() -> void
---- Decor.CharacterChanger::OnEnable 0x2d24dac
02d24dac: stp     x30, x23, [sp, #-0x30]!                    
02d24db0: stp     x22, x21, [sp, #0x10]                      
02d24db4: stp     x20, x19, [sp, #0x20]                      
02d24db8: adrp    x19, #0x6630000                            
02d24dbc: mov     x20, x0                                    
02d24dc0: ldrb    w8, [x19, #0x67]                           
02d24dc4: tbnz    w8, #0, #0x2d24de8                         
02d24dc8: adrp    x0, #0x6269000                             
02d24dcc: ldr     x0, [x0, #0xf60]                           M:Decor.CharacterChanger::OnPressed
02d24dd0: bl      #0x2b70db0                                 fn_2b70db0
02d24dd4: adrp    x0, #0x6269000                             
02d24dd8: ldr     x0, [x0, #0xf00]                           T:type58822(k15)
02d24ddc: bl      #0x2b70db0                                 fn_2b70db0
02d24de0: mov     w8, #1                                     
02d24de4: strb    w8, [x19, #0x67]                           
02d24de8: ldr     x19, [x20, #0x28]                          ._boxTrigger
02d24dec: cbz     x19, #0x2d24e8c                            
02d24df0: adrp    x23, #0x6269000                            
02d24df4: adrp    x22, #0x6269000                            
02d24df8: ldr     x23, [x23, #0xf00]                         T:type58822(k15)
02d24dfc: ldr     x22, [x22, #0xf60]                         M:Decor.CharacterChanger::OnPressed
02d24e00: ldr     x21, [x19, #0x28]!                         ._boxTrigger
02d24e04: ldr     x0, [x23]                                  T:Trading.TradingSession/<>c__DisplayClass56_0
02d24e08: bl      #0x2b7104c                                 fn_2b7104c
02d24e0c: ldr     x2, [x22]                                  T:Trading.TradingSession/<>c__DisplayClass56_0
02d24e10: mov     x1, x20                                    
02d24e14: mov     x3, xzr                                    
02d24e18: mov     x22, x0                                    
02d24e1c: bl      #0x3edf920                                 fn_3edf920
02d24e20: mov     x0, x21                                    
02d24e24: mov     x1, x22                                    
02d24e28: mov     x2, xzr                                    
02d24e2c: bl      #0x4e570ac                                 System.Delegate::Combine
02d24e30: cbz     x0, #0x2d24e70                             
02d24e34: ldr     x21, [x23]                                 T:Trading.TradingSession/<>c__DisplayClass56_0
02d24e38: mov     x20, x0                                    
02d24e3c: mov     x1, x21                                    
02d24e40: bl      #0x2b70f34                                 fn_2b70f34
02d24e44: cbz     x0, #0x2d24e64                             
02d24e48: ldr     x21, [x23]                                 T:Trading.TradingSession/<>c__DisplayClass56_0
02d24e4c: str     x0, [x19]                                  
02d24e50: mov     x0, x20                                    
02d24e54: mov     x1, x21                                    
02d24e58: bl      #0x2b70f34                                 fn_2b70f34
02d24e5c: mov     x1, x0                                     
02d24e60: cbnz    x0, #0x2d24e78                             
02d24e64: mov     x0, x20                                    
02d24e68: mov     x1, x21                                    
02d24e6c: bl      #0x2b713dc                                 fn_2b713dc
02d24e70: mov     x1, xzr                                    
02d24e74: str     xzr, [x19]                                 
02d24e78: mov     x0, x19                                    
02d24e7c: ldp     x20, x19, [sp, #0x20]                      
02d24e80: ldp     x22, x21, [sp, #0x10]                      
02d24e84: ldp     x30, x23, [sp], #0x30                      
02d24e88: b       #0x2b70d54                                 
02d24e8c: bl      #0x2b7105c                                 fn_2b7105c
## OnDisable() -> void
---- Decor.CharacterChanger::OnDisable 0x2d24e90
02d24e90: stp     x30, x23, [sp, #-0x30]!                    
02d24e94: stp     x22, x21, [sp, #0x10]                      
02d24e98: stp     x20, x19, [sp, #0x20]                      
02d24e9c: adrp    x19, #0x6630000                            
02d24ea0: mov     x20, x0                                    
02d24ea4: ldrb    w8, [x19, #0x68]                           
02d24ea8: tbnz    w8, #0, #0x2d24ecc                         
02d24eac: adrp    x0, #0x6269000                             
02d24eb0: ldr     x0, [x0, #0xf60]                           M:Decor.CharacterChanger::OnPressed
02d24eb4: bl      #0x2b70db0                                 fn_2b70db0
02d24eb8: adrp    x0, #0x6269000                             
02d24ebc: ldr     x0, [x0, #0xf00]                           T:type58822(k15)
02d24ec0: bl      #0x2b70db0                                 fn_2b70db0
02d24ec4: mov     w8, #1                                     
02d24ec8: strb    w8, [x19, #0x68]                           
02d24ecc: ldr     x19, [x20, #0x28]                          ._boxTrigger
02d24ed0: cbz     x19, #0x2d24f70                            
02d24ed4: adrp    x23, #0x6269000                            
02d24ed8: adrp    x22, #0x6269000                            
02d24edc: ldr     x23, [x23, #0xf00]                         T:type58822(k15)
02d24ee0: ldr     x22, [x22, #0xf60]                         M:Decor.CharacterChanger::OnPressed
02d24ee4: ldr     x21, [x19, #0x28]!                         ._boxTrigger
02d24ee8: ldr     x0, [x23]                                  T:Trading.TradingSession/<>c__DisplayClass56_0
02d24eec: bl      #0x2b7104c                                 fn_2b7104c
02d24ef0: ldr     x2, [x22]                                  T:Trading.TradingSession/<>c__DisplayClass56_0
02d24ef4: mov     x1, x20                                    
02d24ef8: mov     x3, xzr                                    
02d24efc: mov     x22, x0                                    
02d24f00: bl      #0x3edf920                                 fn_3edf920
02d24f04: mov     x0, x21                                    
02d24f08: mov     x1, x22                                    
02d24f0c: mov     x2, xzr                                    
02d24f10: bl      #0x4e57298                                 System.Delegate::Remove
02d24f14: cbz     x0, #0x2d24f54                             
02d24f18: ldr     x21, [x23]                                 T:Trading.TradingSession/<>c__DisplayClass56_0
02d24f1c: mov     x20, x0                                    
02d24f20: mov     x1, x21                                    
02d24f24: bl      #0x2b70f34                                 fn_2b70f34
02d24f28: cbz     x0, #0x2d24f48                             
02d24f2c: ldr     x21, [x23]                                 T:Trading.TradingSession/<>c__DisplayClass56_0
02d24f30: str     x0, [x19]                                  
02d24f34: mov     x0, x20                                    
02d24f38: mov     x1, x21                                    
02d24f3c: bl      #0x2b70f34                                 fn_2b70f34
02d24f40: mov     x1, x0                                     
02d24f44: cbnz    x0, #0x2d24f5c                             
02d24f48: mov     x0, x20                                    
02d24f4c: mov     x1, x21                                    
02d24f50: bl      #0x2b713dc                                 fn_2b713dc
02d24f54: mov     x1, xzr                                    
02d24f58: str     xzr, [x19]                                 
02d24f5c: mov     x0, x19                                    
02d24f60: ldp     x20, x19, [sp, #0x20]                      
02d24f64: ldp     x22, x21, [sp, #0x10]                      
02d24f68: ldp     x30, x23, [sp], #0x30                      
02d24f6c: b       #0x2b70d54                                 
02d24f70: bl      #0x2b7105c                                 fn_2b7105c
## OnPressed(Home.EntityName name) -> void
---- Decor.CharacterChanger::OnPressed 0x2d24f74
02d24f74: stp     x30, x23, [sp, #-0x30]!                    
02d24f78: stp     x22, x21, [sp, #0x10]                      
02d24f7c: stp     x20, x19, [sp, #0x20]                      
02d24f80: adrp    x20, #0x6630000                            
02d24f84: adrp    x21, #0x6263000                            
02d24f88: mov     x19, x0                                    
02d24f8c: ldrb    w8, [x20, #0x69]                           
02d24f90: ldr     x21, [x21, #0x918]                         T:UnityEngine.Object
02d24f94: tbnz    w8, #0, #0x2d24fd0                         
02d24f98: adrp    x0, #0x6264000                             
02d24f9c: ldr     x0, [x0, #0xf90]                           T:System.Action
02d24fa0: bl      #0x2b70db0                                 fn_2b70db0
02d24fa4: adrp    x0, #0x6269000                             
02d24fa8: ldr     x0, [x0, #0xf68]                           M:Decor.CharacterChanger::<OnPressed>g__OnCompleted|7_1
02d24fac: bl      #0x2b70db0                                 fn_2b70db0
02d24fb0: adrp    x0, #0x6269000                             
02d24fb4: ldr     x0, [x0, #0xf70]                           M:Decor.CharacterChanger::<OnPressed>g__OnStart|7_0
02d24fb8: bl      #0x2b70db0                                 fn_2b70db0
02d24fbc: adrp    x0, #0x6263000                             
02d24fc0: ldr     x0, [x0, #0x918]                           T:UnityEngine.Object
02d24fc4: bl      #0x2b70db0                                 fn_2b70db0
02d24fc8: mov     w8, #1                                     
02d24fcc: strb    w8, [x20, #0x69]                           
02d24fd0: mov     x0, x19                                    
02d24fd4: bl      #0x2d24d54                                 Decor.CharacterChanger::RegetComponents
02d24fd8: ldr     x0, [x21]                                  &2c5bbd4(=a9bd7bfdd503233f)
02d24fdc: ldr     x20, [x19, #0x30]                          ._motionStateMachine
02d24fe0: ldr     w8, [x0, #0xe4]                            [62630e4]=0 f=0,0
02d24fe4: cbnz    w8, #0x2d24fec                             
02d24fe8: bl      #0x2b70f30                                 fn_2b70f30
02d24fec: mov     x0, x20                                    
02d24ff0: mov     x1, xzr                                    
02d24ff4: mov     x2, xzr                                    
02d24ff8: bl      #0x5b37d84                                 UnityEngine.Object::op_Equality
02d24ffc: tbnz    w0, #0, #0x2d25030                         
02d25000: ldr     x0, [x21]                                  &2c5bbd4(=a9bd7bfdd503233f)
02d25004: ldr     x20, [x19, #0x28]                          ._boxTrigger
02d25008: ldr     w8, [x0, #0xe4]                            [62630e4]=0 f=0,0
02d2500c: cbnz    w8, #0x2d25014                             
02d25010: bl      #0x2b70f30                                 fn_2b70f30
02d25014: mov     x0, x20                                    
02d25018: mov     x1, xzr                                    
02d2501c: mov     x2, xzr                                    
02d25020: bl      #0x5b37d84                                 UnityEngine.Object::op_Equality
02d25024: tbnz    w0, #0, #0x2d25030                         
02d25028: ldrb    w8, [x19, #0x38]                           ._isClicked
02d2502c: cbz     w8, #0x2d25040                             
02d25030: ldp     x20, x19, [sp, #0x20]                      
02d25034: ldp     x22, x21, [sp, #0x10]                      
02d25038: ldp     x30, x23, [sp], #0x30                      
02d2503c: ret                                                
02d25040: ldr     x20, [x19, #0x30]                          ._motionStateMachine
02d25044: mov     w8, #1                                     
02d25048: strb    w8, [x19, #0x38]                           ._isClicked
02d2504c: cbz     x20, #0x2d250cc                            
02d25050: adrp    x23, #0x6264000                            
02d25054: ldr     x23, [x23, #0xf90]                         T:System.Action
02d25058: ldr     x21, [x20, #0x80]                          
02d2505c: ldr     x0, [x23]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d25060: bl      #0x2b7104c                                 fn_2b7104c
02d25064: adrp    x8, #0x6269000                             
02d25068: mov     x1, xzr                                    
02d2506c: mov     x3, xzr                                    
02d25070: ldr     x8, [x8, #0xf70]                           M:Decor.CharacterChanger::<OnPressed>g__OnStart|7_0
02d25074: mov     x22, x0                                    
02d25078: ldr     x2, [x8]                                   T:Trading.TradingSession/<>c__DisplayClass56_0
02d2507c: bl      #0x4d8ddbc                                 System.Action::.ctor
02d25080: ldr     x0, [x23]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d25084: bl      #0x2b7104c                                 fn_2b7104c
02d25088: adrp    x8, #0x6269000                             
02d2508c: mov     x1, x19                                    
02d25090: mov     x3, xzr                                    
02d25094: ldr     x8, [x8, #0xf68]                           M:Decor.CharacterChanger::<OnPressed>g__OnCompleted|7_1
02d25098: mov     x23, x0                                    
02d2509c: ldr     x2, [x8]                                   T:Trading.TradingSession/<>c__DisplayClass56_0
02d250a0: bl      #0x4d8ddbc                                 System.Action::.ctor
02d250a4: mov     x0, x20                                    
02d250a8: mov     x1, x21                                    
02d250ac: mov     x3, x22                                    
02d250b0: ldp     x20, x19, [sp, #0x20]                      
02d250b4: mov     w2, wzr                                    
02d250b8: ldp     x22, x21, [sp, #0x10]                      
02d250bc: mov     x4, x23                                    
02d250c0: mov     x5, xzr                                    
02d250c4: ldp     x30, x23, [sp], #0x30                      
02d250c8: b       #0x2d75e24                                 Character.MotionStateMachine::ChangeState
02d250cc: bl      #0x2b7105c                                 fn_2b7105c
## RegetComponents() -> void
---- Decor.CharacterChanger::RegetComponents 0x2d24d54
02d24d54: stp     x30, x21, [sp, #-0x20]!                    
02d24d58: stp     x20, x19, [sp, #0x10]                      
02d24d5c: adrp    x20, #0x6630000                            
02d24d60: adrp    x21, #0x6269000                            
02d24d64: mov     x19, x0                                    
02d24d68: ldrb    w8, [x20, #0x6a]                           
02d24d6c: ldr     x21, [x21, #0xf58]                         MS:UnityEngine.Component::GetComponentInChildren
02d24d70: tbnz    w8, #0, #0x2d24d88                         
02d24d74: adrp    x0, #0x6269000                             
02d24d78: ldr     x0, [x0, #0xf58]                           MS:UnityEngine.Component::GetComponentInChildren
02d24d7c: bl      #0x2b70db0                                 fn_2b70db0
02d24d80: mov     w8, #1                                     
02d24d84: strb    w8, [x20, #0x6a]                           
02d24d88: ldr     x1, [x21]                                  T:Trading.TradingSession/<>c__DisplayClass56_0
02d24d8c: mov     x0, x19                                    
02d24d90: bl      #0x3140e60                                 fn_3140e60
02d24d94: str     x0, [x19, #0x30]!                          ._motionStateMachine
02d24d98: mov     x1, x0                                     
02d24d9c: mov     x0, x19                                    
02d24da0: ldp     x20, x19, [sp, #0x10]                      
02d24da4: ldp     x30, x21, [sp], #0x20                      
02d24da8: b       #0x2b70d54                                 
## .ctor() -> void
---- Decor.CharacterChanger::.ctor 0x2d250d0
02d250d0: mov     x1, xzr                                    
02d250d4: b       #0x5b397b0                                 UnityEngine.MonoBehaviour::.ctor
## <OnPressed>g__OnStart|7_0() -> void
---- Decor.CharacterChanger::<OnPressed>g__OnStart|7_0 0x2d250d8
02d250d8: ret                                                
## <OnPressed>g__OnCompleted|7_1() -> void
---- Decor.CharacterChanger::<OnPressed>g__OnCompleted|7_1 0x2d250dc
02d250dc: stp     x30, x19, [sp, #-0x10]!                    
02d250e0: mov     x19, x0                                    
02d250e4: ldr     x0, [x0, #0x30]                            ._motionStateMachine
02d250e8: cbz     x0, #0x2d25108                             
02d250ec: ldr     x1, [x0, #0x38]                            ._isClicked
02d250f0: mov     w2, #1                                     
02d250f4: mov     x3, xzr                                    
02d250f8: bl      #0x2d75ce8                                 Character.MotionStateMachine::ChangeState
02d250fc: strb    wzr, [x19, #0x38]                          ._isClicked
02d25100: ldp     x30, x19, [sp], #0x10                      
02d25104: ret                                                
02d25108: bl      #0x2b7105c                                 fn_2b7105c
