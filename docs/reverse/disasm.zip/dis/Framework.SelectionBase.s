#### CLASS Framework.SelectionBase parent= UnityEngine.MonoBehaviour
## .ctor() -> void
---- Framework.SelectionBase::.ctor 0x2cc6b74
02cc6b74: mov     x1, xzr                                    
02cc6b78: b       #0x5b397b0                                 UnityEngine.MonoBehaviour::.ctor
