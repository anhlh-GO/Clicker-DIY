#### CLASS Clicker.SwitchObject parent= UnityEngine.MonoBehaviour
#   field _srSwitch                      UnityEngine.SpriteRenderer                         off=0x20 attr=1 SerializeField
## SetVisual(UnityEngine.Sprite visual) -> void
---- Clicker.SwitchObject::SetVisual 0x2d61700
02d61700: ldr     x0, [x0, #0x20]                            ._srSwitch
02d61704: cbz     x0, #0x2d61710                             
02d61708: mov     x2, xzr                                    
02d6170c: b       #0x5ae6dcc                                 UnityEngine.SpriteRenderer::set_sprite
02d61710: str     x30, [sp, #-0x10]!                         
02d61714: bl      #0x2b7105c                                 fn_2b7105c
## .ctor() -> void
---- Clicker.SwitchObject::.ctor 0x2d65c80
02d65c80: mov     x1, xzr                                    
02d65c84: b       #0x5b397b0                                 UnityEngine.MonoBehaviour::.ctor
