#### CLASS LevelController parent= UnityEngine.MonoBehaviour
#   field level                          Level                                              off=0x20 attr=6 
#   field CurrentMapConfigSo             LevelConfigSO                                      off=0x28 attr=6 
## OnLevelLoad(int levelId) -> void
---- LevelController::OnLevelLoad 0x2cd6738
02cd6738: str     d14, [sp, #-0x60]!                         
02cd673c: stp     d13, d12, [sp, #8]                         
02cd6740: stp     d11, d10, [sp, #0x18]                      
02cd6744: stp     d9, d8, [sp, #0x28]                        
02cd6748: str     x30, [sp, #0x38]                           
02cd674c: stp     x22, x21, [sp, #0x40]                      
02cd6750: stp     x20, x19, [sp, #0x50]                      
02cd6754: adrp    x22, #0x662f000                            
02cd6758: adrp    x20, #0x6266000                            
02cd675c: mov     w21, w1                                    
02cd6760: ldrb    w8, [x22, #0xd2c]                          
02cd6764: ldr     x20, [x20, #0xd20]                         MS:MonoSingleton`1::get_Instance
02cd6768: mov     x19, x0                                    
02cd676c: tbnz    w8, #0, #0x2cd679c                         
02cd6770: adrp    x0, #0x6267000                             
02cd6774: ldr     x0, [x0, #0x940]                           MS:UnityEngine.Component::GetComponent
02cd6778: bl      #0x2b70db0                                 fn_2b70db0
02cd677c: adrp    x0, #0x6266000                             
02cd6780: ldr     x0, [x0, #0xd20]                           MS:MonoSingleton`1::get_Instance
02cd6784: bl      #0x2b70db0                                 fn_2b70db0
02cd6788: adrp    x0, #0x6263000                             
02cd678c: ldr     x0, [x0, #0x918]                           T:UnityEngine.Object
02cd6790: bl      #0x2b70db0                                 fn_2b70db0
02cd6794: mov     w8, #1                                     
02cd6798: strb    w8, [x22, #0xd2c]                          
02cd679c: mov     x0, x19                                    
02cd67a0: bl      #0x2cd6904                                 LevelController::DestroyCurrentLevel
02cd67a4: ldr     x0, [x20]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cd67a8: bl      #0x3769600                                 fn_3769600
02cd67ac: ldr     x8, [x19, #0x28]                           .CurrentMapConfigSo
02cd67b0: cbz     x8, #0x2cd6900                             
02cd67b4: mov     x20, x0                                    
02cd67b8: mov     x0, x8                                     
02cd67bc: mov     w1, w21                                    
02cd67c0: mov     x2, xzr                                    
02cd67c4: bl      #0x2ca8570                                 LevelConfigSO::GetLevel
02cd67c8: cbz     x0, #0x2cd6900                             
02cd67cc: mov     x1, xzr                                    
02cd67d0: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02cd67d4: adrp    x22, #0x662f000                            
02cd67d8: mov     x21, x0                                    
02cd67dc: ldrb    w8, [x22, #0x91a]                          
02cd67e0: cbnz    w8, #0x2cd67f8                             
02cd67e4: adrp    x0, #0x6264000                             
02cd67e8: ldr     x0, [x0, #0xd8]                            T:UnityEngine.Vector3
02cd67ec: bl      #0x2b70db0                                 fn_2b70db0
02cd67f0: mov     w8, #1                                     
02cd67f4: strb    w8, [x22, #0x91a]                          
02cd67f8: adrp    x8, #0x6264000                             
02cd67fc: adrp    x22, #0x662f000                            
02cd6800: ldr     x8, [x8, #0xd8]                            T:UnityEngine.Vector3
02cd6804: ldrb    w9, [x22, #0xbdf]                          
02cd6808: ldr     x8, [x8]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02cd680c: ldr     x8, [x8, #0xb8]                            MS:DG.Tweening.Core.Extensions::SetSpecialStartupMode
02cd6810: ldp     s8, s9, [x8]                               
02cd6814: ldr     s10, [x8, #8]                              T:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass2_0
02cd6818: cbnz    w9, #0x2cd6830                             
02cd681c: adrp    x0, #0x6266000                             
02cd6820: ldr     x0, [x0, #0xd30]                           T:UnityEngine.Quaternion
02cd6824: bl      #0x2b70db0                                 fn_2b70db0
02cd6828: mov     w8, #1                                     
02cd682c: strb    w8, [x22, #0xbdf]                          
02cd6830: adrp    x8, #0x6266000                             
02cd6834: mov     x0, x19                                    
02cd6838: mov     x1, xzr                                    
02cd683c: ldr     x8, [x8, #0xd30]                           T:UnityEngine.Quaternion
02cd6840: ldr     x8, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cd6844: ldr     x8, [x8, #0xb8]                            S:'banner_native_refresh_time'
02cd6848: ldp     s11, s12, [x8]                             
02cd684c: ldp     s13, s14, [x8, #8]                         
02cd6850: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02cd6854: cbz     x20, #0x2cd6900                            
02cd6858: fmov    s0, s8                                     
02cd685c: fmov    s1, s9                                     
02cd6860: mov     x2, x0                                     
02cd6864: fmov    s2, s10                                    
02cd6868: fmov    s3, s11                                    
02cd686c: mov     x0, x20                                    
02cd6870: fmov    s4, s12                                    
02cd6874: fmov    s5, s13                                    
02cd6878: mov     x1, x21                                    
02cd687c: fmov    s6, s14                                    
02cd6880: bl      #0x2cd69bc                                 PoolManager::SpawnObject
02cd6884: cbz     x0, #0x2cd6900                             
02cd6888: adrp    x8, #0x6267000                             
02cd688c: adrp    x20, #0x6263000                            
02cd6890: ldr     x8, [x8, #0x940]                           MS:UnityEngine.Component::GetComponent
02cd6894: ldr     x20, [x20, #0x918]                         T:UnityEngine.Object
02cd6898: ldr     x1, [x8]                                   S:'didu'
02cd689c: bl      #0x3140c84                                 fn_3140c84
02cd68a0: mov     x1, x0                                     
02cd68a4: str     x0, [x19, #0x20]!                          .level
02cd68a8: mov     x0, x19                                    
02cd68ac: bl      #0x2b70d54                                 fn_2b70d54
02cd68b0: ldr     x0, [x20]                                  &2c5bbd4(=a9bd7bfdd503233f)
02cd68b4: ldr     x20, [x19]                                 
02cd68b8: ldr     w8, [x0, #0xe4]                            [62660e4]=0 f=0,0
02cd68bc: cbnz    w8, #0x2cd68c4                             
02cd68c0: bl      #0x2b70f30                                 fn_2b70f30
02cd68c4: mov     x0, x20                                    
02cd68c8: mov     x1, xzr                                    
02cd68cc: mov     x2, xzr                                    
02cd68d0: bl      #0x5b3666c                                 UnityEngine.Object::op_Inequality
02cd68d4: tbz     w0, #0, #0x2cd68e0                         
02cd68d8: ldr     x8, [x19]                                  
02cd68dc: cbz     x8, #0x2cd6900                             
02cd68e0: ldp     x20, x19, [sp, #0x50]                      
02cd68e4: ldr     x30, [sp, #0x38]                           
02cd68e8: ldp     x22, x21, [sp, #0x40]                      
02cd68ec: ldp     d9, d8, [sp, #0x28]                        
02cd68f0: ldp     d11, d10, [sp, #0x18]                      
02cd68f4: ldp     d13, d12, [sp, #8]                         
02cd68f8: ldr     d14, [sp], #0x60                           
02cd68fc: ret                                                
02cd6900: bl      #0x2b7105c                                 fn_2b7105c
## DestroyCurrentLevel() -> void
---- LevelController::DestroyCurrentLevel 0x2cd6904
02cd6904: stp     x30, x21, [sp, #-0x20]!                    
02cd6908: stp     x20, x19, [sp, #0x10]                      
02cd690c: adrp    x20, #0x662f000                            
02cd6910: adrp    x21, #0x6263000                            
02cd6914: mov     x19, x0                                    
02cd6918: ldrb    w8, [x20, #0xd2d]                          
02cd691c: ldr     x21, [x21, #0x918]                         T:UnityEngine.Object
02cd6920: tbnz    w8, #0, #0x2cd6938                         
02cd6924: adrp    x0, #0x6263000                             
02cd6928: ldr     x0, [x0, #0x918]                           T:UnityEngine.Object
02cd692c: bl      #0x2b70db0                                 fn_2b70db0
02cd6930: mov     w8, #1                                     
02cd6934: strb    w8, [x20, #0xd2d]                          
02cd6938: ldr     x0, [x21]                                  &2c5bbd4(=a9bd7bfdd503233f)
02cd693c: ldr     x20, [x19, #0x20]!                         .level
02cd6940: ldr     w8, [x0, #0xe4]                            [62630e4]=0 f=0,0
02cd6944: cbnz    w8, #0x2cd694c                             
02cd6948: bl      #0x2b70f30                                 fn_2b70f30
02cd694c: mov     x0, x20                                    
02cd6950: mov     x1, xzr                                    
02cd6954: mov     x2, xzr                                    
02cd6958: bl      #0x5b3666c                                 UnityEngine.Object::op_Inequality
02cd695c: tbz     w0, #0, #0x2cd69ac                         
02cd6960: ldr     x0, [x19]                                  
02cd6964: cbz     x0, #0x2cd69b8                             
02cd6968: mov     x1, xzr                                    
02cd696c: bl      #0x5b339ec                                 UnityEngine.Component::get_gameObject
02cd6970: ldr     x8, [x21]                                  &2c5bbd4(=a9bd7bfdd503233f)
02cd6974: mov     x20, x0                                    
02cd6978: ldr     w9, [x8, #0xe4]                            
02cd697c: cbnz    w9, #0x2cd6988                             
02cd6980: mov     x0, x8                                     
02cd6984: bl      #0x2b70f30                                 fn_2b70f30
02cd6988: mov     x0, x20                                    
02cd698c: mov     x1, xzr                                    
02cd6990: bl      #0x5b3ca38                                 UnityEngine.Object::Destroy
02cd6994: mov     x0, x19                                    
02cd6998: str     xzr, [x19]                                 
02cd699c: mov     x1, xzr                                    
02cd69a0: ldp     x20, x19, [sp, #0x10]                      
02cd69a4: ldp     x30, x21, [sp], #0x20                      
02cd69a8: b       #0x2b70d54                                 
02cd69ac: ldp     x20, x19, [sp, #0x10]                      
02cd69b0: ldp     x30, x21, [sp], #0x20                      
02cd69b4: ret                                                
02cd69b8: bl      #0x2b7105c                                 fn_2b7105c
## OnLevelStart() -> void
---- LevelController::OnLevelStart 0x2cd6b04
02cd6b04: ret                                                
## .ctor() -> void
---- LevelController::.ctor 0x2cd6b08
02cd6b08: mov     x1, xzr                                    
02cd6b0c: b       #0x5b397b0                                 UnityEngine.MonoBehaviour::.ctor
