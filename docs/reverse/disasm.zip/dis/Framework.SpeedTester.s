#### CLASS Framework.SpeedTester/SpeedTestItem parent= System.ValueType
#   field testID                         string                                             off=0x10 attr=6 
#   field timer                          System.Diagnostics.Stopwatch                       off=0x18 attr=6 
## .ctor(string testID) -> void
---- Framework.SpeedTester/SpeedTestItem::.ctor 0x2cc2280
02cc2280: str     x30, [sp, #-0x30]!                         
02cc2284: stp     x22, x21, [sp, #0x10]                      
02cc2288: stp     x20, x19, [sp, #0x20]                      
02cc228c: adrp    x22, #0x662f000                            
02cc2290: adrp    x21, #0x6267000                            
02cc2294: mov     x20, x1                                    
02cc2298: ldrb    w8, [x22, #0xc29]                          
02cc229c: ldr     x21, [x21, #0xe8]                          T:System.Diagnostics.Stopwatch
02cc22a0: mov     x19, x0                                    
02cc22a4: tbnz    w8, #0, #0x2cc22bc                         
02cc22a8: adrp    x0, #0x6267000                             
02cc22ac: ldr     x0, [x0, #0xe8]                            T:System.Diagnostics.Stopwatch
02cc22b0: bl      #0x2b70db0                                 fn_2b70db0
02cc22b4: mov     w8, #1                                     
02cc22b8: strb    w8, [x22, #0xc29]                          
02cc22bc: mov     x0, x19                                    
02cc22c0: mov     x1, x20                                    
02cc22c4: str     x20, [x19]                                 
02cc22c8: bl      #0x2b70d54                                 fn_2b70d54
02cc22cc: ldr     x0, [x21]                                  S:'didu'
02cc22d0: ldr     w8, [x0, #0xe4]                            [62670e4]=0 f=0,0
02cc22d4: cbnz    w8, #0x2cc22dc                             
02cc22d8: bl      #0x2b70f30                                 fn_2b70f30
02cc22dc: mov     x0, xzr                                    
02cc22e0: bl      #0x53a2a6c                                 System.Diagnostics.Stopwatch::StartNew
02cc22e4: str     x0, [x19, #8]!                             
02cc22e8: mov     x1, x0                                     
02cc22ec: mov     x0, x19                                    
02cc22f0: ldp     x20, x19, [sp, #0x20]                      
02cc22f4: ldp     x22, x21, [sp, #0x10]                      
02cc22f8: ldr     x30, [sp], #0x30                           
02cc22fc: b       #0x2b70d54                                 
#### CLASS Framework.SpeedTester parent= object
#   field _speedTestDict                 System.Collections.Generic.Dictionary`2<string,Framework.SpeedTester/SpeedTestItem> off=0x0 attr=31 
## StartTest(string testID) -> void
---- Framework.SpeedTester::StartTest 0x2cc215c
02cc215c: sub     sp, sp, #0x30                              
02cc2160: stp     x30, x21, [sp, #0x10]                      
02cc2164: stp     x20, x19, [sp, #0x20]                      
02cc2168: adrp    x21, #0x662f000                            
02cc216c: adrp    x20, #0x6267000                            
02cc2170: mov     x19, x0                                    
02cc2174: ldrb    w8, [x21, #0xc24]                          
02cc2178: ldr     x20, [x20, #0xc8]                          T:Framework.SpeedTester
02cc217c: tbnz    w8, #0, #0x2cc21b8                         
02cc2180: adrp    x0, #0x6267000                             
02cc2184: ldr     x0, [x0, #0xd0]                            MS:System.Collections.Generic.Dictionary`2::Add
02cc2188: bl      #0x2b70db0                                 fn_2b70db0
02cc218c: adrp    x0, #0x6267000                             
02cc2190: ldr     x0, [x0, #0xd8]                            MS:System.Collections.Generic.Dictionary`2::ContainsKey
02cc2194: bl      #0x2b70db0                                 fn_2b70db0
02cc2198: adrp    x0, #0x6267000                             
02cc219c: ldr     x0, [x0, #0xe0]                            MS:System.Collections.Generic.Dictionary`2::Remove
02cc21a0: bl      #0x2b70db0                                 fn_2b70db0
02cc21a4: adrp    x0, #0x6267000                             
02cc21a8: ldr     x0, [x0, #0xc8]                            T:Framework.SpeedTester
02cc21ac: bl      #0x2b70db0                                 fn_2b70db0
02cc21b0: mov     w8, #1                                     
02cc21b4: strb    w8, [x21, #0xc24]                          
02cc21b8: ldr     x0, [x20]                                  S:'didu'
02cc21bc: stp     xzr, xzr, [sp]                             
02cc21c0: ldr     w8, [x0, #0xe4]                            [62670e4]=0 f=0,0
02cc21c4: cbnz    w8, #0x2cc21d0                             
02cc21c8: bl      #0x2b70f30                                 fn_2b70f30
02cc21cc: ldr     x0, [x20]                                  S:'didu'
02cc21d0: ldr     x8, [x0, #0xb8]                            M:Framework.SceneUtils/<CRUnloadSceneAsync>d__2::System.Collections.IEnumerator.Reset
02cc21d4: ldr     x0, [x8]                                   
02cc21d8: cbz     x0, #0x2cc227c                             
02cc21dc: adrp    x8, #0x6267000                             
02cc21e0: mov     x1, x19                                    
02cc21e4: ldr     x8, [x8, #0xd8]                            MS:System.Collections.Generic.Dictionary`2::ContainsKey
02cc21e8: ldr     x2, [x8]                                   S:'didu'
02cc21ec: bl      #0x4568b28                                 fn_4568b28
02cc21f0: tbz     w0, #0, #0x2cc2228                         
02cc21f4: ldr     x0, [x20]                                  S:'didu'
02cc21f8: ldr     w8, [x0, #0xe4]                            [62670e4]=0 f=0,0
02cc21fc: cbnz    w8, #0x2cc2208                             
02cc2200: bl      #0x2b70f30                                 fn_2b70f30
02cc2204: ldr     x0, [x20]                                  S:'didu'
02cc2208: ldr     x8, [x0, #0xb8]                            M:Framework.SceneUtils/<CRUnloadSceneAsync>d__2::System.Collections.IEnumerator.Reset
02cc220c: ldr     x0, [x8]                                   S:'didu'
02cc2210: cbz     x0, #0x2cc227c                             
02cc2214: adrp    x8, #0x6267000                             
02cc2218: mov     x1, x19                                    
02cc221c: ldr     x8, [x8, #0xe0]                            MS:System.Collections.Generic.Dictionary`2::Remove
02cc2220: ldr     x2, [x8]                                   S:'didu'
02cc2224: bl      #0x4569df4                                 fn_4569df4
02cc2228: mov     x0, sp                                     
02cc222c: mov     x1, x19                                    
02cc2230: bl      #0x2cc2280                                 Framework.SpeedTester/SpeedTestItem::.ctor
02cc2234: ldr     x0, [x20]                                  S:'didu'
02cc2238: ldr     w8, [x0, #0xe4]                            [62670e4]=0 f=0,0
02cc223c: cbnz    w8, #0x2cc2248                             
02cc2240: bl      #0x2b70f30                                 fn_2b70f30
02cc2244: ldr     x0, [x20]                                  S:'didu'
02cc2248: ldr     x8, [x0, #0xb8]                            M:Framework.SceneUtils/<CRUnloadSceneAsync>d__2::System.Collections.IEnumerator.Reset
02cc224c: ldr     x0, [x8]                                   S:'didu'
02cc2250: cbz     x0, #0x2cc227c                             
02cc2254: adrp    x8, #0x6267000                             
02cc2258: mov     x1, x19                                    
02cc225c: ldr     x8, [x8, #0xd0]                            MS:System.Collections.Generic.Dictionary`2::Add
02cc2260: ldp     x2, x3, [sp]                               
02cc2264: ldr     x4, [x8]                                   S:'didu'
02cc2268: bl      #0x4568924                                 fn_4568924
02cc226c: ldp     x20, x19, [sp, #0x20]                      
02cc2270: ldp     x30, x21, [sp, #0x10]                      
02cc2274: add     sp, sp, #0x30                              
02cc2278: ret                                                
02cc227c: bl      #0x2b7105c                                 fn_2b7105c
## EndTest(string testID) -> void
---- Framework.SpeedTester::EndTest 0x2cc2300
02cc2300: stp     x30, x21, [sp, #-0x20]!                    
02cc2304: stp     x20, x19, [sp, #0x10]                      
02cc2308: adrp    x21, #0x662f000                            
02cc230c: adrp    x20, #0x6267000                            
02cc2310: mov     x19, x0                                    
02cc2314: ldrb    w8, [x21, #0xc25]                          
02cc2318: ldr     x20, [x20, #0xc8]                          T:Framework.SpeedTester
02cc231c: tbnz    w8, #0, #0x2cc2358                         
02cc2320: adrp    x0, #0x6267000                             
02cc2324: ldr     x0, [x0, #0xd8]                            MS:System.Collections.Generic.Dictionary`2::ContainsKey
02cc2328: bl      #0x2b70db0                                 fn_2b70db0
02cc232c: adrp    x0, #0x6267000                             
02cc2330: ldr     x0, [x0, #0xe0]                            MS:System.Collections.Generic.Dictionary`2::Remove
02cc2334: bl      #0x2b70db0                                 fn_2b70db0
02cc2338: adrp    x0, #0x6267000                             
02cc233c: ldr     x0, [x0, #0xf0]                            MS:System.Collections.Generic.Dictionary`2::get_Item
02cc2340: bl      #0x2b70db0                                 fn_2b70db0
02cc2344: adrp    x0, #0x6267000                             
02cc2348: ldr     x0, [x0, #0xc8]                            T:Framework.SpeedTester
02cc234c: bl      #0x2b70db0                                 fn_2b70db0
02cc2350: mov     w8, #1                                     
02cc2354: strb    w8, [x21, #0xc25]                          
02cc2358: ldr     x0, [x20]                                  S:'didu'
02cc235c: ldr     w8, [x0, #0xe4]                            [62670e4]=0 f=0,0
02cc2360: cbnz    w8, #0x2cc236c                             
02cc2364: bl      #0x2b70f30                                 fn_2b70f30
02cc2368: ldr     x0, [x20]                                  S:'didu'
02cc236c: ldr     x8, [x0, #0xb8]                            M:Framework.SceneUtils/<CRUnloadSceneAsync>d__2::System.Collections.IEnumerator.Reset
02cc2370: ldr     x0, [x8]                                   
02cc2374: cbz     x0, #0x2cc2438                             
02cc2378: adrp    x8, #0x6267000                             
02cc237c: mov     x1, x19                                    
02cc2380: ldr     x8, [x8, #0xd8]                            MS:System.Collections.Generic.Dictionary`2::ContainsKey
02cc2384: ldr     x2, [x8]                                   S:'didu'
02cc2388: bl      #0x4568b28                                 fn_4568b28
02cc238c: tbz     w0, #0, #0x2cc242c                         
02cc2390: ldr     x0, [x20]                                  S:'didu'
02cc2394: ldr     w8, [x0, #0xe4]                            [62670e4]=0 f=0,0
02cc2398: cbnz    w8, #0x2cc23a4                             
02cc239c: bl      #0x2b70f30                                 fn_2b70f30
02cc23a0: ldr     x0, [x20]                                  S:'didu'
02cc23a4: ldr     x8, [x0, #0xb8]                            M:Framework.SceneUtils/<CRUnloadSceneAsync>d__2::System.Collections.IEnumerator.Reset
02cc23a8: ldr     x0, [x8]                                   S:'didu'
02cc23ac: cbz     x0, #0x2cc2438                             
02cc23b0: adrp    x21, #0x6267000                            
02cc23b4: mov     x1, x19                                    
02cc23b8: ldr     x21, [x21, #0xf0]                          MS:System.Collections.Generic.Dictionary`2::get_Item
02cc23bc: ldr     x2, [x21]                                  S:'didu'
02cc23c0: bl      #0x45688a0                                 fn_45688a0
02cc23c4: cbz     x1, #0x2cc2438                             
02cc23c8: mov     x0, x1                                     
02cc23cc: mov     x1, xzr                                    
02cc23d0: bl      #0x53a2df4                                 System.Diagnostics.Stopwatch::Stop
02cc23d4: ldr     x8, [x20]                                  S:'didu'
02cc23d8: ldr     x8, [x8, #0xb8]                            M:Framework.SceneUtils/<CRUnloadSceneAsync>d__2::System.Collections.IEnumerator.Reset
02cc23dc: ldr     x0, [x8]                                   S:'didu'
02cc23e0: cbz     x0, #0x2cc2438                             
02cc23e4: ldr     x2, [x21]                                  S:'didu'
02cc23e8: mov     x1, x19                                    
02cc23ec: bl      #0x45688a0                                 fn_45688a0
02cc23f0: cbz     x1, #0x2cc2438                             
02cc23f4: mov     x0, x1                                     
02cc23f8: mov     x1, xzr                                    
02cc23fc: bl      #0x53a2ca8                                 System.Diagnostics.Stopwatch::get_ElapsedMilliseconds
02cc2400: ldr     x8, [x20]                                  S:'didu'
02cc2404: ldr     x8, [x8, #0xb8]                            M:Framework.SceneUtils/<CRUnloadSceneAsync>d__2::System.Collections.IEnumerator.Reset
02cc2408: ldr     x0, [x8]                                   S:'didu'
02cc240c: cbz     x0, #0x2cc2438                             
02cc2410: adrp    x8, #0x6267000                             
02cc2414: mov     x1, x19                                    
02cc2418: ldr     x8, [x8, #0xe0]                            MS:System.Collections.Generic.Dictionary`2::Remove
02cc241c: ldp     x20, x19, [sp, #0x10]                      
02cc2420: ldr     x2, [x8]                                   S:'didu'
02cc2424: ldp     x30, x21, [sp], #0x20                      
02cc2428: b       #0x4569df4                                 
02cc242c: ldp     x20, x19, [sp, #0x10]                      
02cc2430: ldp     x30, x21, [sp], #0x20                      
02cc2434: ret                                                
02cc2438: bl      #0x2b7105c                                 fn_2b7105c
## .cctor() -> void
---- Framework.SpeedTester::.cctor 0x2cc243c
02cc243c: str     x30, [sp, #-0x30]!                         
02cc2440: stp     x22, x21, [sp, #0x10]                      
02cc2444: stp     x20, x19, [sp, #0x20]                      
02cc2448: adrp    x21, #0x662f000                            
02cc244c: adrp    x22, #0x6267000                            
02cc2450: adrp    x19, #0x6267000                            
02cc2454: adrp    x20, #0x6267000                            
02cc2458: ldr     x22, [x22, #0xf8]                          T:type54497(k15)
02cc245c: ldrb    w8, [x21, #0xc26]                          
02cc2460: ldr     x19, [x19, #0x100]                         MS:System.Collections.Generic.Dictionary`2::.ctor
02cc2464: ldr     x20, [x20, #0xc8]                          T:Framework.SpeedTester
02cc2468: tbnz    w8, #0, #0x2cc2498                         
02cc246c: adrp    x0, #0x6267000                             
02cc2470: ldr     x0, [x0, #0x100]                           MS:System.Collections.Generic.Dictionary`2::.ctor
02cc2474: bl      #0x2b70db0                                 fn_2b70db0
02cc2478: adrp    x0, #0x6267000                             
02cc247c: ldr     x0, [x0, #0xf8]                            T:type54497(k15)
02cc2480: bl      #0x2b70db0                                 fn_2b70db0
02cc2484: adrp    x0, #0x6267000                             
02cc2488: ldr     x0, [x0, #0xc8]                            T:Framework.SpeedTester
02cc248c: bl      #0x2b70db0                                 fn_2b70db0
02cc2490: mov     w8, #1                                     
02cc2494: strb    w8, [x21, #0xc26]                          
02cc2498: ldr     x0, [x22]                                  S:'didu'
02cc249c: bl      #0x2b7104c                                 fn_2b7104c
02cc24a0: ldr     x1, [x19]                                  S:'didu'
02cc24a4: mov     x19, x0                                    
02cc24a8: bl      #0x4567ba8                                 fn_4567ba8
02cc24ac: ldr     x8, [x20]                                  S:'didu'
02cc24b0: mov     x1, x19                                    
02cc24b4: ldp     x22, x21, [sp, #0x10]                      
02cc24b8: ldr     x8, [x8, #0xb8]                            
02cc24bc: str     x19, [x8]                                  
02cc24c0: ldr     x8, [x20]                                  S:'didu'
02cc24c4: ldp     x20, x19, [sp, #0x20]                      
02cc24c8: ldr     x0, [x8, #0xb8]                            
02cc24cc: ldr     x30, [sp], #0x30                           
02cc24d0: b       #0x2b70d54                                 
