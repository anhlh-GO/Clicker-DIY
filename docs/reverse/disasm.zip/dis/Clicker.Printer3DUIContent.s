#### CLASS Clicker.Printer3DUIContent parent= UnityEngine.MonoBehaviour
#   field _panel                         UnityEngine.GameObject                             off=0x20 attr=1 SerializeField
#   field _iconCoin                      UnityEngine.GameObject                             off=0x28 attr=1 SerializeField
#   field _btnSpeedUp                    UnityEngine.UI.Button                              off=0x30 attr=1 SerializeField
#   field _btnNextPos                    UnityEngine.Transform                              off=0x38 attr=1 SerializeField
#   field _commentHandler                CommentHandler                                     off=0x40 attr=1 SerializeField
#   field _emojiFx                       UnityEngine.ParticleSystem                         off=0x48 attr=1 SerializeField
#   field _chatInput                     Livestream.ChatInput                               off=0x50 attr=1 SerializeField
#   field _ingameClickerScreen           Clicker.IngameClickerScreen                        off=0x58 attr=1 
#   field _speedUpCost                   int                                                off=0x0 attr=8051 
## Init(Clicker.IngameClickerScreen ingameClickerScreen) -> void
---- Clicker.Printer3DUIContent::Init 0x2d709dc
02d709dc: stp     x30, x21, [sp, #-0x20]!                    
02d709e0: stp     x20, x19, [sp, #0x10]                      
02d709e4: adrp    x21, #0x6630000                            
02d709e8: mov     x20, x1                                    
02d709ec: mov     x19, x0                                    
02d709f0: ldrb    w8, [x21, #0x3a3]                          
02d709f4: tbnz    w8, #0, #0x2d70a18                         
02d709f8: adrp    x0, #0x626c000                             
02d709fc: ldr     x0, [x0, #0x578]                           M:Clicker.Printer3DUIContent::OnBtnSpeedUpClick
02d70a00: bl      #0x2b70db0                                 fn_2b70db0
02d70a04: adrp    x0, #0x6265000                             
02d70a08: ldr     x0, [x0, #0x3f0]                           T:UnityEngine.Events.UnityAction
02d70a0c: bl      #0x2b70db0                                 fn_2b70db0
02d70a10: mov     w8, #1                                     
02d70a14: strb    w8, [x21, #0x3a3]                          
02d70a18: mov     x21, x19                                   
02d70a1c: mov     x1, x20                                    
02d70a20: str     x20, [x21, #0x58]!                         ._ingameClickerScreen
02d70a24: mov     x0, x21                                    
02d70a28: bl      #0x2b70d54                                 fn_2b70d54
02d70a2c: ldur    x0, [x21, #-0x38]                          
02d70a30: cbz     x0, #0x2d70abc                             
02d70a34: mov     w1, wzr                                    
02d70a38: mov     x2, xzr                                    
02d70a3c: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d70a40: ldr     x8, [x19, #0x30]                           ._btnSpeedUp
02d70a44: cbz     x8, #0x2d70abc                             
02d70a48: ldr     x0, [x8, #0x100]                           
02d70a4c: cbz     x0, #0x2d70abc                             
02d70a50: mov     x1, xzr                                    
02d70a54: bl      #0x5b4ce48                                 UnityEngine.Events.UnityEventBase::RemoveAllListeners
02d70a58: ldr     x8, [x19, #0x30]                           ._btnSpeedUp
02d70a5c: cbz     x8, #0x2d70abc                             
02d70a60: adrp    x9, #0x6265000                             
02d70a64: adrp    x21, #0x626c000                            
02d70a68: ldr     x9, [x9, #0x3f0]                           T:UnityEngine.Events.UnityAction
02d70a6c: ldr     x21, [x21, #0x578]                         M:Clicker.Printer3DUIContent::OnBtnSpeedUpClick
02d70a70: ldr     x20, [x8, #0x100]                          
02d70a74: ldr     x0, [x9]                                   M:AdsManager::<OnApplicationPause>b__26_0
02d70a78: bl      #0x2b7104c                                 fn_2b7104c
02d70a7c: ldr     x2, [x21]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d70a80: mov     x1, x19                                    
02d70a84: mov     x3, xzr                                    
02d70a88: mov     x21, x0                                    
02d70a8c: bl      #0x5b4cf98                                 UnityEngine.Events.UnityAction::.ctor
02d70a90: cbz     x20, #0x2d70abc                            
02d70a94: mov     x0, x20                                    
02d70a98: mov     x1, x21                                    
02d70a9c: mov     x2, xzr                                    
02d70aa0: bl      #0x5b4d0ac                                 UnityEngine.Events.UnityEvent::AddListener
02d70aa4: ldr     x0, [x19, #0x50]                           ._chatInput
02d70aa8: cbz     x0, #0x2d70abc                             
02d70aac: ldp     x20, x19, [sp, #0x10]                      
02d70ab0: mov     x1, xzr                                    
02d70ab4: ldp     x30, x21, [sp], #0x20                      
02d70ab8: b       #0x2d11580                                 Livestream.ChatInput::OnInit
02d70abc: bl      #0x2b7105c                                 fn_2b7105c
## ShowContent() -> void
---- Clicker.Printer3DUIContent::ShowContent 0x2d70ac0
02d70ac0: str     x30, [sp, #-0x30]!                         
02d70ac4: stp     x22, x21, [sp, #0x10]                      
02d70ac8: stp     x20, x19, [sp, #0x20]                      
02d70acc: adrp    x20, #0x6630000                            
02d70ad0: mov     x19, x0                                    
02d70ad4: ldrb    w8, [x20, #0x3a4]                          
02d70ad8: tbnz    w8, #0, #0x2d70b20                         
02d70adc: adrp    x0, #0x6264000                             
02d70ae0: ldr     x0, [x0, #0xf90]                           T:System.Action
02d70ae4: bl      #0x2b70db0                                 fn_2b70db0
02d70ae8: adrp    x0, #0x6266000                             
02d70aec: ldr     x0, [x0, #0x750]                           MS:DataManager::GetData
02d70af0: bl      #0x2b70db0                                 fn_2b70db0
02d70af4: adrp    x0, #0x6266000                             
02d70af8: ldr     x0, [x0, #0x658]                           MS:MonoSingleton`1::get_Instance
02d70afc: bl      #0x2b70db0                                 fn_2b70db0
02d70b00: adrp    x0, #0x6263000                             
02d70b04: ldr     x0, [x0, #0x918]                           T:UnityEngine.Object
02d70b08: bl      #0x2b70db0                                 fn_2b70db0
02d70b0c: adrp    x0, #0x626c000                             
02d70b10: ldr     x0, [x0, #0x580]                           M:Clicker.Printer3DUIContent::<ShowContent>b__10_0
02d70b14: bl      #0x2b70db0                                 fn_2b70db0
02d70b18: mov     w8, #1                                     
02d70b1c: strb    w8, [x20, #0x3a4]                          
02d70b20: ldr     x0, [x19, #0x20]                           ._panel
02d70b24: cbz     x0, #0x2d70c94                             
02d70b28: mov     w1, #1                                     
02d70b2c: mov     x2, xzr                                    
02d70b30: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d70b34: ldr     x0, [x19, #0x30]                           ._btnSpeedUp
02d70b38: cbz     x0, #0x2d70c94                             
02d70b3c: mov     x1, xzr                                    
02d70b40: bl      #0x5b339ec                                 UnityEngine.Component::get_gameObject
02d70b44: cbz     x0, #0x2d70c94                             
02d70b48: adrp    x21, #0x6264000                            
02d70b4c: adrp    x22, #0x626c000                            
02d70b50: mov     w1, wzr                                    
02d70b54: ldr     x21, [x21, #0xf90]                         T:System.Action
02d70b58: ldr     x22, [x22, #0x580]                         M:Clicker.Printer3DUIContent::<ShowContent>b__10_0
02d70b5c: mov     x2, xzr                                    
02d70b60: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d70b64: ldr     x0, [x21]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d70b68: ldr     x20, [x19, #0x58]                          ._ingameClickerScreen
02d70b6c: bl      #0x2b7104c                                 fn_2b7104c
02d70b70: ldr     x2, [x22]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d70b74: mov     x1, x19                                    
02d70b78: mov     x3, xzr                                    
02d70b7c: mov     x21, x0                                    
02d70b80: bl      #0x4d8ddbc                                 System.Action::.ctor
02d70b84: cbz     x20, #0x2d70c94                            
02d70b88: mov     x0, x20                                    
02d70b8c: mov     x1, x21                                    
02d70b90: mov     x2, xzr                                    
02d70b94: bl      #0x2d69948                                 Clicker.IngameClickerScreen::RegisterButtonNextEvent
02d70b98: ldr     x0, [x19, #0x38]                           ._btnNextPos
02d70b9c: cbz     x0, #0x2d70c94                             
02d70ba0: ldr     x20, [x19, #0x58]                          ._ingameClickerScreen
02d70ba4: mov     x1, xzr                                    
02d70ba8: bl      #0x5b467ac                                 UnityEngine.Transform::get_position
02d70bac: cbz     x20, #0x2d70c94                            
02d70bb0: adrp    x21, #0x6263000                            
02d70bb4: mov     x0, x20                                    
02d70bb8: mov     x1, xzr                                    
02d70bbc: ldr     x21, [x21, #0x918]                         T:UnityEngine.Object
02d70bc0: bl      #0x2d69a28                                 Clicker.IngameClickerScreen::SetBtnNextPosition
02d70bc4: ldr     x0, [x21]                                  &2c5bbd4(=a9bd7bfdd503233f)
02d70bc8: ldr     x20, [x19, #0x48]                          ._emojiFx
02d70bcc: ldr     w8, [x0, #0xe4]                            [626c0e4]=0 f=0,0
02d70bd0: cbnz    w8, #0x2d70bd8                             
02d70bd4: bl      #0x2b70f30                                 fn_2b70f30
02d70bd8: mov     x0, x20                                    
02d70bdc: mov     x1, xzr                                    
02d70be0: mov     x2, xzr                                    
02d70be4: bl      #0x5b3666c                                 UnityEngine.Object::op_Inequality
02d70be8: tbz     w0, #0, #0x2d70bfc                         
02d70bec: ldr     x0, [x19, #0x48]                           ._emojiFx
02d70bf0: cbz     x0, #0x2d70c94                             
02d70bf4: mov     x1, xzr                                    
02d70bf8: bl      #0x5bba8cc                                 UnityEngine.ParticleSystem::Play
02d70bfc: ldr     x0, [x19, #0x50]                           ._chatInput
02d70c00: cbz     x0, #0x2d70c94                             
02d70c04: mov     x1, xzr                                    
02d70c08: bl      #0x5b339ec                                 UnityEngine.Component::get_gameObject
02d70c0c: cbz     x0, #0x2d70c94                             
02d70c10: mov     w1, #1                                     
02d70c14: mov     x2, xzr                                    
02d70c18: mov     w20, #1                                    
02d70c1c: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d70c20: ldr     x8, [x19, #0x40]                           ._commentHandler
02d70c24: cbz     x8, #0x2d70c94                             
02d70c28: adrp    x9, #0x6266000                             
02d70c2c: ldr     x9, [x9, #0x658]                           MS:MonoSingleton`1::get_Instance
02d70c30: strb    w20, [x8, #0x20]                           
02d70c34: ldr     x0, [x9]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d70c38: bl      #0x3769600                                 fn_3769600
02d70c3c: cbz     x0, #0x2d70c94                             
02d70c40: adrp    x8, #0x6266000                             
02d70c44: ldr     x8, [x8, #0x750]                           MS:DataManager::GetData
02d70c48: ldr     x1, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d70c4c: bl      #0x3168dd0                                 fn_3168dd0
02d70c50: cbz     x0, #0x2d70c94                             
02d70c54: ldr     x8, [x0, #0x20]                            M:Clicker.GlowSprite2DItem::<DoGlow>b__10_6 ._panel
02d70c58: cbz     x8, #0x2d70c94                             
02d70c5c: ldrb    w8, [x8, #0x3a]                            
02d70c60: cbz     w8, #0x2d70c84                             
02d70c64: ldr     x0, [x19, #0x28]                           ._iconCoin
02d70c68: cbz     x0, #0x2d70c94                             
02d70c6c: ldp     x20, x19, [sp, #0x20]                      
02d70c70: mov     w1, wzr                                    
02d70c74: ldp     x22, x21, [sp, #0x10]                      
02d70c78: mov     x2, xzr                                    
02d70c7c: ldr     x30, [sp], #0x30                           
02d70c80: b       #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d70c84: ldp     x20, x19, [sp, #0x20]                      
02d70c88: ldp     x22, x21, [sp, #0x10]                      
02d70c8c: ldr     x30, [sp], #0x30                           
02d70c90: ret                                                
02d70c94: bl      #0x2b7105c                                 fn_2b7105c
## OnBtnSpeedUpClick() -> void
---- Clicker.Printer3DUIContent::OnBtnSpeedUpClick 0x2d70c98
02d70c98: stp     x30, x21, [sp, #-0x20]!                    
02d70c9c: stp     x20, x19, [sp, #0x10]                      
02d70ca0: adrp    x20, #0x6630000                            
02d70ca4: adrp    x21, #0x6266000                            
02d70ca8: mov     x19, x0                                    
02d70cac: ldrb    w8, [x20, #0x3a5]                          
02d70cb0: ldr     x21, [x21, #0x658]                         MS:MonoSingleton`1::get_Instance
02d70cb4: tbnz    w8, #0, #0x2d70d08                         
02d70cb8: adrp    x0, #0x6266000                             
02d70cbc: ldr     x0, [x0, #0x750]                           MS:DataManager::GetData
02d70cc0: bl      #0x2b70db0                                 fn_2b70db0
02d70cc4: adrp    x0, #0x6267000                             
02d70cc8: ldr     x0, [x0, #0xbd0]                           MS:MonoSingleton`1::get_Instance
02d70ccc: bl      #0x2b70db0                                 fn_2b70db0
02d70cd0: adrp    x0, #0x626b000                             
02d70cd4: ldr     x0, [x0, #0xee0]                           MS:MonoSingleton`1::get_Instance
02d70cd8: bl      #0x2b70db0                                 fn_2b70db0
02d70cdc: adrp    x0, #0x6266000                             
02d70ce0: ldr     x0, [x0, #0xaa0]                           MS:MonoSingleton`1::get_Instance
02d70ce4: bl      #0x2b70db0                                 fn_2b70db0
02d70ce8: adrp    x0, #0x6266000                             
02d70cec: ldr     x0, [x0, #0x658]                           MS:MonoSingleton`1::get_Instance
02d70cf0: bl      #0x2b70db0                                 fn_2b70db0
02d70cf4: adrp    x0, #0x6269000                             
02d70cf8: ldr     x0, [x0, #0xb40]                           MS:UIManager::ShowPopup
02d70cfc: bl      #0x2b70db0                                 fn_2b70db0
02d70d00: mov     w8, #1                                     
02d70d04: strb    w8, [x20, #0x3a5]                          
02d70d08: ldr     x0, [x21]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d70d0c: bl      #0x3769600                                 fn_3769600
02d70d10: cbz     x0, #0x2d70e38                             
02d70d14: adrp    x8, #0x6266000                             
02d70d18: ldr     x8, [x8, #0x750]                           MS:DataManager::GetData
02d70d1c: ldr     x1, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d70d20: bl      #0x3168dd0                                 fn_3168dd0
02d70d24: cbz     x0, #0x2d70e38                             
02d70d28: ldr     x8, [x0, #0x20]                            M:Trading.TradingSession::<ValidateTrade>b__57_1 ._panel
02d70d2c: cbz     x8, #0x2d70e38                             
02d70d30: adrp    x20, #0x626b000                            
02d70d34: ldrb    w8, [x8, #0x3a]                            
02d70d38: ldr     x20, [x20, #0xee0]                         MS:MonoSingleton`1::get_Instance
02d70d3c: cbz     w8, #0x2d70d7c                             
02d70d40: ldr     x0, [x20]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d70d44: bl      #0x3769600                                 fn_3769600
02d70d48: cbz     x0, #0x2d70e38                             
02d70d4c: mov     x1, xzr                                    
02d70d50: bl      #0x2d6c7a8                                 Clicker.KeycapMakerController::SpeedUpPrinter
02d70d54: ldr     x0, [x19, #0x30]                           ._btnSpeedUp
02d70d58: cbz     x0, #0x2d70e38                             
02d70d5c: mov     x1, xzr                                    
02d70d60: bl      #0x5b339ec                                 UnityEngine.Component::get_gameObject
02d70d64: cbz     x0, #0x2d70e38                             
02d70d68: ldp     x20, x19, [sp, #0x10]                      
02d70d6c: mov     w1, wzr                                    
02d70d70: mov     x2, xzr                                    
02d70d74: ldp     x30, x21, [sp], #0x20                      
02d70d78: b       #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d70d7c: mov     x1, xzr                                    
02d70d80: bl      #0x2cabaf8                                 DataUser::GetMoney
02d70d84: cmp     w0, #0x63                                  
02d70d88: b.le    #0x2d70e0c                                 
02d70d8c: ldr     x0, [x20]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d70d90: bl      #0x3769600                                 fn_3769600
02d70d94: cbz     x0, #0x2d70e38                             
02d70d98: mov     x1, xzr                                    
02d70d9c: bl      #0x2d6c7a8                                 Clicker.KeycapMakerController::SpeedUpPrinter
02d70da0: ldr     x0, [x19, #0x30]                           ._btnSpeedUp
02d70da4: cbz     x0, #0x2d70e38                             
02d70da8: mov     x1, xzr                                    
02d70dac: bl      #0x5b339ec                                 UnityEngine.Component::get_gameObject
02d70db0: cbz     x0, #0x2d70e38                             
02d70db4: mov     w1, wzr                                    
02d70db8: mov     x2, xzr                                    
02d70dbc: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d70dc0: bl      #0x2d6eec8                                 Framework.AudioManager::get_Instance
02d70dc4: cbz     x0, #0x2d70e38                             
02d70dc8: movi    d1, #0000000000000000                      
02d70dcc: movi    d2, #0000000000000000                      
02d70dd0: mov     w1, #0x2f                                  
02d70dd4: fmov    s0, #1.00000000                            
02d70dd8: mov     w2, wzr                                    
02d70ddc: mov     w3, wzr                                    
02d70de0: bl      #0x2d6f03c                                 Framework.AudioManager::PlaySound
02d70de4: adrp    x8, #0x6266000                             
02d70de8: ldr     x8, [x8, #0xaa0]                           MS:MonoSingleton`1::get_Instance
02d70dec: ldr     x0, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d70df0: bl      #0x3769600                                 fn_3769600
02d70df4: cbz     x0, #0x2d70e38                             
02d70df8: ldp     x20, x19, [sp, #0x10]                      
02d70dfc: mov     w1, #-0x64                                 
02d70e00: mov     x2, xzr                                    
02d70e04: ldp     x30, x21, [sp], #0x20                      
02d70e08: b       #0x2cdac78                                 MoneyManager::UpdateMoney
02d70e0c: adrp    x8, #0x6267000                             
02d70e10: ldr     x8, [x8, #0xbd0]                           MS:MonoSingleton`1::get_Instance
02d70e14: ldr     x0, [x8]                                   S:'didu'
02d70e18: bl      #0x3769600                                 fn_3769600
02d70e1c: cbz     x0, #0x2d70e38                             
02d70e20: adrp    x8, #0x6269000                             
02d70e24: ldr     x8, [x8, #0xb40]                           MS:UIManager::ShowPopup
02d70e28: ldp     x20, x19, [sp, #0x10]                      
02d70e2c: ldr     x1, [x8]                                   T:Trading.TradingSession/<>c__DisplayClass56_0
02d70e30: ldp     x30, x21, [sp], #0x20                      
02d70e34: b       #0x33fbfac                                 
02d70e38: bl      #0x2b7105c                                 fn_2b7105c
## ShowBtnSpeedUp(bool isShow) -> void
---- Clicker.Printer3DUIContent::ShowBtnSpeedUp 0x2d70e3c
02d70e3c: stp     x30, x19, [sp, #-0x10]!                    
02d70e40: ldr     x0, [x0, #0x30]                            ._btnSpeedUp
02d70e44: cbz     x0, #0x2d70e68                             
02d70e48: mov     w19, w1                                    
02d70e4c: mov     x1, xzr                                    
02d70e50: bl      #0x5b339ec                                 UnityEngine.Component::get_gameObject
02d70e54: cbz     x0, #0x2d70e68                             
02d70e58: and     w1, w19, #1                                
02d70e5c: mov     x2, xzr                                    
02d70e60: ldp     x30, x19, [sp], #0x10                      
02d70e64: b       #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d70e68: bl      #0x2b7105c                                 fn_2b7105c
## HideContent() -> void
---- Clicker.Printer3DUIContent::HideContent 0x2d70e6c
02d70e6c: stp     x30, x19, [sp, #-0x10]!                    
02d70e70: mov     x19, x0                                    
02d70e74: ldr     x0, [x0, #0x20]                            ._panel
02d70e78: cbz     x0, #0x2d70ebc                             
02d70e7c: mov     w1, wzr                                    
02d70e80: mov     x2, xzr                                    
02d70e84: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d70e88: ldr     x0, [x19, #0x48]                           ._emojiFx
02d70e8c: cbz     x0, #0x2d70ebc                             
02d70e90: mov     x1, xzr                                    
02d70e94: bl      #0x5bba9c0                                 UnityEngine.ParticleSystem::Stop
02d70e98: ldr     x0, [x19, #0x48]                           ._emojiFx
02d70e9c: cbz     x0, #0x2d70ebc                             
02d70ea0: mov     x1, xzr                                    
02d70ea4: bl      #0x5bbaa90                                 UnityEngine.ParticleSystem::Clear
02d70ea8: ldr     x8, [x19, #0x40]                           ._commentHandler
02d70eac: cbz     x8, #0x2d70ebc                             
02d70eb0: strb    wzr, [x8, #0x20]                           
02d70eb4: ldp     x30, x19, [sp], #0x10                      
02d70eb8: ret                                                
02d70ebc: bl      #0x2b7105c                                 fn_2b7105c
## .ctor() -> void
---- Clicker.Printer3DUIContent::.ctor 0x2d70ec0
02d70ec0: mov     x1, xzr                                    
02d70ec4: b       #0x5b397b0                                 UnityEngine.MonoBehaviour::.ctor
## <ShowContent>b__10_0() -> void
---- Clicker.Printer3DUIContent::<ShowContent>b__10_0 0x2d70ec8
02d70ec8: str     x30, [sp, #-0x30]!                         
02d70ecc: stp     x22, x21, [sp, #0x10]                      
02d70ed0: stp     x20, x19, [sp, #0x20]                      
02d70ed4: adrp    x21, #0x6630000                            
02d70ed8: adrp    x20, #0x6266000                            
02d70edc: mov     x19, x0                                    
02d70ee0: ldrb    w8, [x21, #0x3a6]                          
02d70ee4: ldr     x20, [x20, #0x658]                         MS:MonoSingleton`1::get_Instance
02d70ee8: tbnz    w8, #0, #0x2d70f48                         
02d70eec: adrp    x0, #0x6264000                             
02d70ef0: ldr     x0, [x0, #0xf90]                           T:System.Action
02d70ef4: bl      #0x2b70db0                                 fn_2b70db0
02d70ef8: adrp    x0, #0x6266000                             
02d70efc: ldr     x0, [x0, #0x750]                           MS:DataManager::GetData
02d70f00: bl      #0x2b70db0                                 fn_2b70db0
02d70f04: adrp    x0, #0x6265000                             
02d70f08: ldr     x0, [x0, #0xb38]                           T:DevTrack
02d70f0c: bl      #0x2b70db0                                 fn_2b70db0
02d70f10: adrp    x0, #0x6266000                             
02d70f14: ldr     x0, [x0, #0x658]                           MS:MonoSingleton`1::get_Instance
02d70f18: bl      #0x2b70db0                                 fn_2b70db0
02d70f1c: adrp    x0, #0x626c000                             
02d70f20: ldr     x0, [x0, #0x588]                           M:Clicker.Printer3DUIContent::<ShowContent>g__ContinueToSwitch|10_1
02d70f24: bl      #0x2b70db0                                 fn_2b70db0
02d70f28: adrp    x0, #0x6265000                             
02d70f2c: ldr     x0, [x0, #0x310]                           MS:WejoyService.Singleton`1::get_Instance
02d70f30: bl      #0x2b70db0                                 fn_2b70db0
02d70f34: adrp    x0, #0x626c000                             
02d70f38: ldr     x0, [x0, #0x590]                           S:'printer_done'
02d70f3c: bl      #0x2b70db0                                 fn_2b70db0
02d70f40: mov     w8, #1                                     
02d70f44: strb    w8, [x21, #0x3a6]                          
02d70f48: ldr     x0, [x20]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d70f4c: bl      #0x3769600                                 fn_3769600
02d70f50: cbz     x0, #0x2d71060                             
02d70f54: adrp    x21, #0x6266000                            
02d70f58: ldr     x21, [x21, #0x750]                         MS:DataManager::GetData
02d70f5c: ldr     x1, [x21]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d70f60: bl      #0x3168dd0                                 fn_3168dd0
02d70f64: cbz     x0, #0x2d71060                             
02d70f68: ldr     x8, [x0, #0x20]                            M:Clicker.GlowSprite2DItem::<DoGlow>b__10_6 ._panel
02d70f6c: cbz     x8, #0x2d71060                             
02d70f70: ldrb    w8, [x8, #0x3a]                            
02d70f74: cbz     w8, #0x2d70fac                             
02d70f78: adrp    x22, #0x6265000                            
02d70f7c: ldr     x22, [x22, #0xb38]                         T:DevTrack
02d70f80: ldr     x0, [x22]                                  M:AdsManager::<OnApplicationPause>b__26_0
02d70f84: ldr     w8, [x0, #0xe4]                            [626c0e4]=0 f=0,0
02d70f88: cbnz    w8, #0x2d70f94                             
02d70f8c: bl      #0x2b70f30                                 fn_2b70f30
02d70f90: ldr     x0, [x22]                                  M:AdsManager::<OnApplicationPause>b__26_0
02d70f94: ldr     x8, [x0, #0xb8]                            MS:System.Collections.Generic.List`1::Add
02d70f98: mov     x3, xzr                                    
02d70f9c: ldr     x0, [x8, #0x1f8]                           
02d70fa0: ldr     x1, [x8, #0x228]                           
02d70fa4: ldr     w2, [x8, #0x278]                           
02d70fa8: bl      #0x2c9c1e0                                 DevTrack::OnboardingStep
02d70fac: ldr     x0, [x20]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d70fb0: bl      #0x3769600                                 fn_3769600
02d70fb4: cbz     x0, #0x2d71060                             
02d70fb8: ldr     x1, [x21]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d70fbc: bl      #0x3168dd0                                 fn_3168dd0
02d70fc0: cbz     x0, #0x2d71060                             
02d70fc4: ldr     x8, [x0, #0x20]                            M:Clicker.GlowSprite2DItem::<DoGlow>b__10_6 ._panel
02d70fc8: cbz     x8, #0x2d71060                             
02d70fcc: ldr     w8, [x8, #0x3c]                            
02d70fd0: cmp     w8, #3                                     
02d70fd4: b.ge    #0x2d70fec                                 
02d70fd8: mov     x0, x19                                    
02d70fdc: ldp     x20, x19, [sp, #0x20]                      
02d70fe0: ldp     x22, x21, [sp, #0x10]                      
02d70fe4: ldr     x30, [sp], #0x30                           
02d70fe8: b       #0x2d71064                                 Clicker.Printer3DUIContent::<ShowContent>g__ContinueToSwitch|10_1
02d70fec: adrp    x8, #0x6265000                             
02d70ff0: ldr     x8, [x8, #0x310]                           MS:WejoyService.Singleton`1::get_Instance
02d70ff4: ldr     x0, [x8]                                   M:AdsManager::<OnApplicationPause>b__26_0
02d70ff8: bl      #0x3be7218                                 fn_3be7218
02d70ffc: adrp    x8, #0x6264000                             
02d71000: mov     x20, x0                                    
02d71004: ldr     x8, [x8, #0xf90]                           T:System.Action
02d71008: ldr     x8, [x8]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d7100c: mov     x0, x8                                     
02d71010: bl      #0x2b7104c                                 fn_2b7104c
02d71014: adrp    x8, #0x626c000                             
02d71018: mov     x1, x19                                    
02d7101c: mov     x3, xzr                                    
02d71020: ldr     x8, [x8, #0x588]                           M:Clicker.Printer3DUIContent::<ShowContent>g__ContinueToSwitch|10_1
02d71024: mov     x21, x0                                    
02d71028: ldr     x2, [x8]                                   M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d7102c: bl      #0x4d8ddbc                                 System.Action::.ctor
02d71030: cbz     x20, #0x2d71060                            
02d71034: adrp    x8, #0x626c000                             
02d71038: mov     x0, x20                                    
02d7103c: mov     x2, x21                                    
02d71040: ldr     x8, [x8, #0x590]                           S:'printer_done'
02d71044: ldp     x20, x19, [sp, #0x20]                      
02d71048: ldp     x22, x21, [sp, #0x10]                      
02d7104c: mov     w3, #1                                     
02d71050: ldr     x1, [x8]                                   M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d71054: mov     x4, xzr                                    
02d71058: ldr     x30, [sp], #0x30                           
02d7105c: b       #0x2c89698                                 AdsManager::ShowInter
02d71060: bl      #0x2b7105c                                 fn_2b7105c
## <ShowContent>g__ContinueToSwitch|10_1() -> void
---- Clicker.Printer3DUIContent::<ShowContent>g__ContinueToSwitch|10_1 0x2d71064
02d71064: str     x30, [sp, #-0x20]!                         
02d71068: stp     x20, x19, [sp, #0x10]                      
02d7106c: adrp    x20, #0x6630000                            
02d71070: mov     x19, x0                                    
02d71074: ldrb    w8, [x20, #0x3a7]                          
02d71078: tbnz    w8, #0, #0x2d71090                         
02d7107c: adrp    x0, #0x626b000                             
02d71080: ldr     x0, [x0, #0xee0]                           MS:MonoSingleton`1::get_Instance
02d71084: bl      #0x2b70db0                                 fn_2b70db0
02d71088: mov     w8, #1                                     
02d7108c: strb    w8, [x20, #0x3a7]                          
02d71090: ldr     x0, [x19, #0x58]                           ._ingameClickerScreen
02d71094: cbz     x0, #0x2d710e0                             
02d71098: adrp    x20, #0x626b000                            
02d7109c: mov     w1, wzr                                    
02d710a0: mov     x2, xzr                                    
02d710a4: ldr     x20, [x20, #0xee0]                         MS:MonoSingleton`1::get_Instance
02d710a8: bl      #0x2d6519c                                 Clicker.IngameClickerScreen::ShowBtnNext
02d710ac: mov     x0, x19                                    
02d710b0: bl      #0x2d70e6c                                 Clicker.Printer3DUIContent::HideContent
02d710b4: ldr     x0, [x20]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d710b8: bl      #0x3769600                                 fn_3769600
02d710bc: cbz     x0, #0x2d710e0                             
02d710c0: mov     x1, xzr                                    
02d710c4: bl      #0x2d6c7c8                                 Clicker.KeycapMakerController::HidePrinterShowTray
02d710c8: ldr     x0, [x19, #0x58]                           ._ingameClickerScreen
02d710cc: cbz     x0, #0x2d710e0                             
02d710d0: ldp     x20, x19, [sp, #0x10]                      
02d710d4: mov     x1, xzr                                    
02d710d8: ldr     x30, [sp], #0x20                           
02d710dc: b       #0x2d6b83c                                 Clicker.IngameClickerScreen::GoToStepSwitch
02d710e0: bl      #0x2b7105c                                 fn_2b7105c
