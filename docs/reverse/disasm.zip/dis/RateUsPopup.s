#### CLASS RateUsPopup/<>c__DisplayClass12_0 parent= object
#   field starIndex                      int                                                off=0x10 attr=6 
#   field <>4__this                      RateUsPopup                                        off=0x18 attr=6 
## .ctor() -> void
---- RateUsPopup/<>c__DisplayClass12_0::.ctor 0x2ce7d9c
02ce7d9c: mov     x1, xzr                                    
02ce7da0: b       #0x4e53e9c                                 System.Object::.ctor
## <Start>b__1() -> void
---- RateUsPopup/<>c__DisplayClass12_0::<Start>b__1 0x2ce8538
02ce8538: stp     x30, x19, [sp, #-0x10]!                    
02ce853c: ldr     x19, [x0, #0x18]                           .<>4__this
02ce8540: cbz     x19, #0x2ce8568                            
02ce8544: ldr     w8, [x0, #0x10]                            .starIndex
02ce8548: mov     x0, x19                                    
02ce854c: str     w8, [x19, #0x78]                           
02ce8550: bl      #0x2ce8150                                 RateUsPopup::I_Choose
02ce8554: mov     x1, x0                                     
02ce8558: mov     x0, x19                                    
02ce855c: mov     x2, xzr                                    
02ce8560: ldp     x30, x19, [sp], #0x10                      
02ce8564: b       #0x5b389f0                                 UnityEngine.MonoBehaviour::StartCoroutine
02ce8568: bl      #0x2b7105c                                 fn_2b7105c
#### CLASS RateUsPopup/<>c__DisplayClass20_0 parent= object
#   field onClose                        System.Action                                      off=0x10 attr=6 
## .ctor() -> void
---- RateUsPopup/<>c__DisplayClass20_0::.ctor 0x2ce83cc
02ce83cc: mov     x1, xzr                                    
02ce83d0: b       #0x4e53e9c                                 System.Object::.ctor
## <ShowWithCloseEvent>b__0() -> void
---- RateUsPopup/<>c__DisplayClass20_0::<ShowWithCloseEvent>b__0 0x2ce856c
02ce856c: ldr     x8, [x0, #0x10]                            .onClose
02ce8570: cbz     x8, #0x2ce8584                             
02ce8574: ldr     x0, [x8, #0x40]                            
02ce8578: ldr     x1, [x8, #0x28]                            
02ce857c: ldr     x2, [x8, #0x18]                            
02ce8580: br      x2                                         
02ce8584: ret                                                
#### CLASS RateUsPopup/<I_Choose>d__17 parent= object
#   field <>1__state                     int                                                off=0x10 attr=1 
#   field <>2__current                   object                                             off=0x18 attr=1 
#   field <>4__this                      RateUsPopup                                        off=0x20 attr=6 
#   field <i>5__2                        int                                                off=0x28 attr=1 
## .ctor(int <>1__state) -> void
---- RateUsPopup/<I_Choose>d__17::.ctor 0x2ce81bc
02ce81bc: str     x30, [sp, #-0x20]!                         
02ce81c0: stp     x20, x19, [sp, #0x10]                      
02ce81c4: mov     w19, w1                                    
02ce81c8: mov     x1, xzr                                    
02ce81cc: mov     x20, x0                                    
02ce81d0: bl      #0x4e53e9c                                 System.Object::.ctor
02ce81d4: str     w19, [x20, #0x10]                          .<>1__state
02ce81d8: ldp     x20, x19, [sp, #0x10]                      
02ce81dc: ldr     x30, [sp], #0x20                           
02ce81e0: ret                                                
## System.IDisposable.Dispose() -> void
---- RateUsPopup/<I_Choose>d__17::System.IDisposable.Dispose 0x2ce8588
02ce8588: ret                                                
## MoveNext() -> bool
---- RateUsPopup/<I_Choose>d__17::MoveNext 0x2ce858c
02ce858c: str     x30, [sp, #-0x20]!                         
02ce8590: stp     x20, x19, [sp, #0x10]                      
02ce8594: adrp    x20, #0x662f000                            
02ce8598: mov     x19, x0                                    
02ce859c: ldrb    w8, [x20, #0xdff]                          
02ce85a0: tbnz    w8, #0, #0x2ce85b8                         
02ce85a4: adrp    x0, #0x6264000                             
02ce85a8: ldr     x0, [x0, #0xf58]                           T:UnityEngine.WaitForSeconds
02ce85ac: bl      #0x2b70db0                                 fn_2b70db0
02ce85b0: mov     w8, #1                                     
02ce85b4: strb    w8, [x20, #0xdff]                          
02ce85b8: ldr     w9, [x19, #0x10]                           .<>1__state
02ce85bc: ldr     x8, [x19, #0x20]                           .<>4__this
02ce85c0: cmp     w9, #1                                     
02ce85c4: b.eq    #0x2ce85dc                                 
02ce85c8: cbnz    w9, #0x2ce8644                             
02ce85cc: mov     w10, #-1                                   
02ce85d0: str     wzr, [x19, #0x28]                          .<i>5__2
02ce85d4: str     w10, [x19, #0x10]                          .<>1__state
02ce85d8: b       #0x2ce85f0                                 
02ce85dc: ldr     w9, [x19, #0x28]                           .<i>5__2
02ce85e0: mov     w10, #-1                                   
02ce85e4: str     w10, [x19, #0x10]                          .<>1__state
02ce85e8: add     w9, w9, #1                                 
02ce85ec: str     w9, [x19, #0x28]                           .<i>5__2
02ce85f0: cbz     x8, #0x2ce86b8                             
02ce85f4: ldr     x10, [x8, #0x40]                           
02ce85f8: cbz     x10, #0x2ce86b8                            
02ce85fc: ldr     w11, [x10, #0x18]                          
02ce8600: cmp     w9, w11                                    
02ce8604: b.ge    #0x2ce8630                                 
02ce8608: ldr     w12, [x8, #0x78]                           
02ce860c: cmp     w9, w12                                    
02ce8610: b.le    #0x2ce864c                                 
02ce8614: cmp     w9, w11                                    
02ce8618: b.hs    #0x2ce86bc                                 
02ce861c: add     x9, x10, w9, sxtw #3                       
02ce8620: ldr     x0, [x9, #0x20]                            
02ce8624: cbz     x0, #0x2ce86b8                             
02ce8628: add     x8, x8, #0x50                              
02ce862c: b       #0x2ce8664                                 
02ce8630: ldr     x0, [x8, #0x58]                            
02ce8634: cbz     x0, #0x2ce86b8                             
02ce8638: mov     w1, #1                                     
02ce863c: mov     x2, xzr                                    
02ce8640: bl      #0x5e662d4                                 UnityEngine.UI.Selectable::set_interactable
02ce8644: mov     w0, wzr                                    
02ce8648: b       #0x2ce86ac                                 
02ce864c: cmp     w9, w11                                    
02ce8650: b.hs    #0x2ce86bc                                 
02ce8654: add     x9, x10, w9, sxtw #3                       
02ce8658: ldr     x0, [x9, #0x20]                            
02ce865c: cbz     x0, #0x2ce86b8                             
02ce8660: add     x8, x8, #0x48                              
02ce8664: ldr     x1, [x8]                                   
02ce8668: mov     x2, xzr                                    
02ce866c: bl      #0x5c45aa0                                 UnityEngine.UI.Image::set_sprite
02ce8670: adrp    x8, #0x6264000                             
02ce8674: ldr     x8, [x8, #0xf58]                           T:UnityEngine.WaitForSeconds
02ce8678: ldr     x0, [x8]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02ce867c: bl      #0x2b7104c                                 fn_2b7104c
02ce8680: adrp    x8, #0x1084000                             
02ce8684: mov     x1, xzr                                    
02ce8688: mov     x20, x0                                    
02ce868c: ldr     s0, [x8, #0xeec]                           [1084eec]=457ff0003dcccccd f=0.1,4095
02ce8690: bl      #0x5b3e5e8                                 UnityEngine.WaitForSeconds::.ctor
02ce8694: str     x20, [x19, #0x18]!                         .<>2__current
02ce8698: mov     x0, x19                                    
02ce869c: mov     x1, x20                                    
02ce86a0: bl      #0x2b70d54                                 fn_2b70d54
02ce86a4: mov     w0, #1                                     
02ce86a8: stur    w0, [x19, #-8]                             
02ce86ac: ldp     x20, x19, [sp, #0x10]                      
02ce86b0: ldr     x30, [sp], #0x20                           
02ce86b4: ret                                                
02ce86b8: bl      #0x2b7105c                                 fn_2b7105c
02ce86bc: bl      #0x2b71064                                 fn_2b71064
## System.Collections.Generic.IEnumerator<System.Object>.get_Current() -> object
---- RateUsPopup/<I_Choose>d__17::System.Collections.Generic.IEnumerator<System.Object>.get_Current 0x2ce86c0
02ce86c0: ldr     x0, [x0, #0x18]                            .<>2__current
02ce86c4: ret                                                
## System.Collections.IEnumerator.Reset() -> void
---- RateUsPopup/<I_Choose>d__17::System.Collections.IEnumerator.Reset 0x2ce86c8
02ce86c8: stp     x30, x19, [sp, #-0x10]!                    
02ce86cc: adrp    x0, #0x6264000                             
02ce86d0: ldr     x0, [x0, #0xf60]                           T:System.NotSupportedException
02ce86d4: bl      #0x2b70dc4                                 fn_2b70dc4
02ce86d8: bl      #0x2b7104c                                 fn_2b7104c
02ce86dc: mov     x1, xzr                                    
02ce86e0: mov     x19, x0                                    
02ce86e4: bl      #0x4e14238                                 System.NotSupportedException::.ctor
02ce86e8: adrp    x0, #0x6268000                             
02ce86ec: ldr     x0, [x0, #0x2c0]                           M:RateUsPopup/<I_Choose>d__17::System.Collections.IEnumerator.Reset
02ce86f0: bl      #0x2b70dc4                                 fn_2b70dc4
02ce86f4: mov     x1, x0                                     
02ce86f8: mov     x0, x19                                    
02ce86fc: bl      #0x2b70f20                                 fn_2b70f20
## System.Collections.IEnumerator.get_Current() -> object
---- RateUsPopup/<I_Choose>d__17::System.Collections.IEnumerator.get_Current 0x2ce8700
02ce8700: ldr     x0, [x0, #0x18]                            .<>2__current
02ce8704: ret                                                
#### CLASS RateUsPopup/<I_Rate>d__19 parent= object
#   field <>1__state                     int                                                off=0x10 attr=1 
#   field <>2__current                   object                                             off=0x18 attr=1 
#   field rateCount                      int                                                off=0x20 attr=6 
#   field <>4__this                      RateUsPopup                                        off=0x28 attr=6 
## .ctor(int <>1__state) -> void
---- RateUsPopup/<I_Rate>d__19::.ctor 0x2ce8284
02ce8284: str     x30, [sp, #-0x20]!                         
02ce8288: stp     x20, x19, [sp, #0x10]                      
02ce828c: mov     w19, w1                                    
02ce8290: mov     x1, xzr                                    
02ce8294: mov     x20, x0                                    
02ce8298: bl      #0x4e53e9c                                 System.Object::.ctor
02ce829c: str     w19, [x20, #0x10]                          .<>1__state
02ce82a0: ldp     x20, x19, [sp, #0x10]                      
02ce82a4: ldr     x30, [sp], #0x20                           
02ce82a8: ret                                                
## System.IDisposable.Dispose() -> void
---- RateUsPopup/<I_Rate>d__19::System.IDisposable.Dispose 0x2ce8708
02ce8708: ret                                                
## MoveNext() -> bool
---- RateUsPopup/<I_Rate>d__19::MoveNext 0x2ce870c
02ce870c: str     d8, [sp, #-0x20]!                          
02ce8710: str     x30, [sp, #8]                              
02ce8714: stp     x20, x19, [sp, #0x10]                      
02ce8718: adrp    x20, #0x662f000                            
02ce871c: mov     x19, x0                                    
02ce8720: ldrb    w8, [x20, #0xe00]                          
02ce8724: tbnz    w8, #0, #0x2ce873c                         
02ce8728: adrp    x0, #0x6264000                             
02ce872c: ldr     x0, [x0, #0xf58]                           T:UnityEngine.WaitForSeconds
02ce8730: bl      #0x2b70db0                                 fn_2b70db0
02ce8734: mov     w8, #1                                     
02ce8738: strb    w8, [x20, #0xe00]                          
02ce873c: ldr     w8, [x19, #0x10]                           .<>1__state
02ce8740: cmp     w8, #2                                     
02ce8744: b.eq    #0x2ce8810                                 
02ce8748: cmp     w8, #1                                     
02ce874c: b.eq    #0x2ce87c4                                 
02ce8750: cbnz    w8, #0x2ce8850                             
02ce8754: ldr     w8, [x19, #0x20]                           .rateCount
02ce8758: adrp    x9, #0x1084000                             
02ce875c: ldr     s1, [x9, #0xeec]                           [1084eec]=457ff0003dcccccd f=0.1,4095
02ce8760: mov     w9, #-1                                    
02ce8764: scvtf   s0, w8                                     
02ce8768: cmp     w8, #4                                     
02ce876c: str     w9, [x19, #0x10]                           .<>1__state
02ce8770: fmul    s0, s0, s1                                 
02ce8774: fmov    s1, #0.50000000                            
02ce8778: fadd    s8, s0, s1                                 
02ce877c: b.lt    #0x2ce8788                                 
02ce8780: mov     x0, xzr                                    
02ce8784: bl      #0x2ca38bc                                 RateApp::CallRateApp
02ce8788: adrp    x8, #0x6264000                             
02ce878c: ldr     x8, [x8, #0xf58]                           T:UnityEngine.WaitForSeconds
02ce8790: ldr     x0, [x8]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02ce8794: bl      #0x2b7104c                                 fn_2b7104c
02ce8798: fmov    s0, s8                                     
02ce879c: mov     x1, xzr                                    
02ce87a0: mov     x20, x0                                    
02ce87a4: bl      #0x5b3e5e8                                 UnityEngine.WaitForSeconds::.ctor
02ce87a8: str     x20, [x19, #0x18]!                         .<>2__current
02ce87ac: mov     x0, x19                                    
02ce87b0: mov     x1, x20                                    
02ce87b4: bl      #0x2b70d54                                 fn_2b70d54
02ce87b8: mov     w0, #1                                     
02ce87bc: stur    w0, [x19, #-8]                             
02ce87c0: b       #0x2ce8854                                 
02ce87c4: adrp    x8, #0x6264000                             
02ce87c8: mov     w9, #-1                                    
02ce87cc: ldr     x8, [x8, #0xf58]                           T:UnityEngine.WaitForSeconds
02ce87d0: str     w9, [x19, #0x10]                           .<>1__state
02ce87d4: ldr     x0, [x8]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02ce87d8: bl      #0x2b7104c                                 fn_2b7104c
02ce87dc: adrp    x8, #0x1084000                             
02ce87e0: mov     x1, xzr                                    
02ce87e4: mov     x20, x0                                    
02ce87e8: ldr     s0, [x8, #0xda4]                           [1084da4]=3eb851ec3e19999a f=0.15,0.36
02ce87ec: bl      #0x5b3e5e8                                 UnityEngine.WaitForSeconds::.ctor
02ce87f0: mov     x0, x19                                    
02ce87f4: mov     x1, x20                                    
02ce87f8: str     x20, [x0, #0x18]!                          .<>2__current
02ce87fc: bl      #0x2b70d54                                 fn_2b70d54
02ce8800: mov     w8, #2                                     
02ce8804: mov     w0, #1                                     
02ce8808: str     w8, [x19, #0x10]                           .<>1__state
02ce880c: b       #0x2ce8854                                 
02ce8810: ldr     x20, [x19, #0x28]                          .<>4__this
02ce8814: mov     w8, #-1                                    
02ce8818: str     w8, [x19, #0x10]                           .<>1__state
02ce881c: cbz     x20, #0x2ce8864                            
02ce8820: ldr     x8, [x20]                                  &2b706c4(=eb01011ff9400808)
02ce8824: mov     x0, x20                                    
02ce8828: ldp     x9, x1, [x8, #0x198]                       
02ce882c: blr     x9                                         
02ce8830: ldr     x0, [x20, #0x80]                           &2b7073c(=d65f03c0b9401800)
02ce8834: cbz     x0, #0x2ce8854                             
02ce8838: mov     x1, xzr                                    
02ce883c: bl      #0x5b4d278                                 UnityEngine.Events.UnityEvent::Invoke
02ce8840: ldr     x0, [x20, #0x80]                           &2b7073c(=d65f03c0b9401800)
02ce8844: cbz     x0, #0x2ce8864                             
02ce8848: mov     x1, xzr                                    
02ce884c: bl      #0x5b4ce48                                 UnityEngine.Events.UnityEventBase::RemoveAllListeners
02ce8850: mov     w0, wzr                                    
02ce8854: ldp     x20, x19, [sp, #0x10]                      
02ce8858: ldr     x30, [sp, #8]                              
02ce885c: ldr     d8, [sp], #0x20                            
02ce8860: ret                                                
02ce8864: bl      #0x2b7105c                                 fn_2b7105c
## System.Collections.Generic.IEnumerator<System.Object>.get_Current() -> object
---- RateUsPopup/<I_Rate>d__19::System.Collections.Generic.IEnumerator<System.Object>.get_Current 0x2ce8868
02ce8868: ldr     x0, [x0, #0x18]                            .<>2__current
02ce886c: ret                                                
## System.Collections.IEnumerator.Reset() -> void
---- RateUsPopup/<I_Rate>d__19::System.Collections.IEnumerator.Reset 0x2ce8870
02ce8870: stp     x30, x19, [sp, #-0x10]!                    
02ce8874: adrp    x0, #0x6264000                             
02ce8878: ldr     x0, [x0, #0xf60]                           T:System.NotSupportedException
02ce887c: bl      #0x2b70dc4                                 fn_2b70dc4
02ce8880: bl      #0x2b7104c                                 fn_2b7104c
02ce8884: mov     x1, xzr                                    
02ce8888: mov     x19, x0                                    
02ce888c: bl      #0x4e14238                                 System.NotSupportedException::.ctor
02ce8890: adrp    x0, #0x6268000                             
02ce8894: ldr     x0, [x0, #0x2c8]                           M:RateUsPopup/<I_Rate>d__19::System.Collections.IEnumerator.Reset
02ce8898: bl      #0x2b70dc4                                 fn_2b70dc4
02ce889c: mov     x1, x0                                     
02ce88a0: mov     x0, x19                                    
02ce88a4: bl      #0x2b70f20                                 fn_2b70f20
## System.Collections.IEnumerator.get_Current() -> object
---- RateUsPopup/<I_Rate>d__19::System.Collections.IEnumerator.get_Current 0x2ce88a8
02ce88a8: ldr     x0, [x0, #0x18]                            .<>2__current
02ce88ac: ret                                                
#### CLASS RateUsPopup parent= PopupBase
#   field btnArray                       UnityEngine.UI.Button[]                            off=0x38 attr=1 SerializeField
#   field imgArray                       UnityEngine.UI.Image[]                             off=0x40 attr=1 SerializeField
#   field goldStar                       UnityEngine.Sprite                                 off=0x48 attr=1 SerializeField
#   field silverStar                     UnityEngine.Sprite                                 off=0x50 attr=1 SerializeField
#   field btnRate                        UnityEngine.UI.Button                              off=0x58 attr=6 
#   field _panel                         UnityEngine.RectTransform                          off=0x60 attr=1 SerializeField
#   field androidId                      string                                             off=0x68 attr=1 SerializeField
#   field iosId                          string                                             off=0x70 attr=1 SerializeField
#   field rateCount                      int                                                off=0x78 attr=1 
#   field OnCloseAction                  UnityEngine.Events.UnityEvent                      off=0x80 attr=6 
## get_LevelShowRate() -> int
---- RateUsPopup::get_LevelShowRate 0x2ce7b54
02ce7b54: str     x30, [sp, #-0x20]!                         
02ce7b58: stp     x20, x19, [sp, #0x10]                      
02ce7b5c: adrp    x20, #0x662f000                            
02ce7b60: adrp    x19, #0x6264000                            
02ce7b64: ldrb    w8, [x20, #0xdf6]                          
02ce7b68: ldr     x19, [x19, #0xfc0]                         T:RemoteConfigManager
02ce7b6c: tbnz    w8, #0, #0x2ce7b84                         
02ce7b70: adrp    x0, #0x6264000                             
02ce7b74: ldr     x0, [x0, #0xfc0]                           T:RemoteConfigManager
02ce7b78: bl      #0x2b70db0                                 fn_2b70db0
02ce7b7c: mov     w8, #1                                     
02ce7b80: strb    w8, [x20, #0xdf6]                          
02ce7b84: ldr     x0, [x19]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02ce7b88: ldr     w8, [x0, #0xe4]                            [62640e4]=0 f=0,0
02ce7b8c: cbnz    w8, #0x2ce7b94                             
02ce7b90: bl      #0x2b70f30                                 fn_2b70f30
02ce7b94: adrp    x20, #0x662f000                            
02ce7b98: ldrb    w8, [x20, #0xbc0]                          
02ce7b9c: cbnz    w8, #0x2ce7bb4                             
02ce7ba0: adrp    x0, #0x6264000                             
02ce7ba4: ldr     x0, [x0, #0xfc0]                           T:RemoteConfigManager
02ce7ba8: bl      #0x2b70db0                                 fn_2b70db0
02ce7bac: mov     w8, #1                                     
02ce7bb0: strb    w8, [x20, #0xbc0]                          
02ce7bb4: ldr     x0, [x19]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02ce7bb8: ldr     w8, [x0, #0xe4]                            [62640e4]=0 f=0,0
02ce7bbc: cbnz    w8, #0x2ce7bc8                             
02ce7bc0: bl      #0x2b70f30                                 fn_2b70f30
02ce7bc4: ldr     x0, [x19]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02ce7bc8: ldr     x8, [x0, #0xb8]                            MS:DG.Tweening.Core.Extensions::SetSpecialStartupMode
02ce7bcc: ldp     x20, x19, [sp, #0x10]                      
02ce7bd0: ldr     w0, [x8, #0xc]                             
02ce7bd4: ldr     x30, [sp], #0x20                           
02ce7bd8: ret                                                
## Start() -> void
---- RateUsPopup::Start 0x2ce7bdc
02ce7bdc: str     x30, [sp, #-0x60]!                         
02ce7be0: stp     x28, x27, [sp, #0x10]                      
02ce7be4: stp     x26, x25, [sp, #0x20]                      
02ce7be8: stp     x24, x23, [sp, #0x30]                      
02ce7bec: stp     x22, x21, [sp, #0x40]                      
02ce7bf0: stp     x20, x19, [sp, #0x50]                      
02ce7bf4: adrp    x20, #0x662f000                            
02ce7bf8: mov     x19, x0                                    
02ce7bfc: ldrb    w8, [x20, #0xdf7]                          
02ce7c00: tbnz    w8, #0, #0x2ce7c48                         
02ce7c04: adrp    x0, #0x6264000                             
02ce7c08: ldr     x0, [x0, #0xa70]                           T:UnityEngine.Application
02ce7c0c: bl      #0x2b70db0                                 fn_2b70db0
02ce7c10: adrp    x0, #0x6268000                             
02ce7c14: ldr     x0, [x0, #0x280]                           M:RateUsPopup::<Start>b__12_0
02ce7c18: bl      #0x2b70db0                                 fn_2b70db0
02ce7c1c: adrp    x0, #0x6268000                             
02ce7c20: ldr     x0, [x0, #0x288]                           M:RateUsPopup/<>c__DisplayClass12_0::<Start>b__1
02ce7c24: bl      #0x2b70db0                                 fn_2b70db0
02ce7c28: adrp    x0, #0x6268000                             
02ce7c2c: ldr     x0, [x0, #0x290]                           T:RateUsPopup/<>c__DisplayClass12_0
02ce7c30: bl      #0x2b70db0                                 fn_2b70db0
02ce7c34: adrp    x0, #0x6265000                             
02ce7c38: ldr     x0, [x0, #0x3f0]                           T:UnityEngine.Events.UnityAction
02ce7c3c: bl      #0x2b70db0                                 fn_2b70db0
02ce7c40: mov     w8, #1                                     
02ce7c44: strb    w8, [x20, #0xdf7]                          
02ce7c48: ldr     x8, [x19, #0x38]                           .btnArray
02ce7c4c: cbz     x8, #0x2ce7d18                             
02ce7c50: adrp    x26, #0x6268000                            
02ce7c54: adrp    x25, #0x6265000                            
02ce7c58: adrp    x27, #0x6268000                            
02ce7c5c: adrp    x24, #0x6268000                            
02ce7c60: adrp    x23, #0x6264000                            
02ce7c64: ldr     x26, [x26, #0x290]                         T:RateUsPopup/<>c__DisplayClass12_0
02ce7c68: ldr     x25, [x25, #0x3f0]                         T:UnityEngine.Events.UnityAction
02ce7c6c: ldr     x27, [x27, #0x288]                         M:RateUsPopup/<>c__DisplayClass12_0::<Start>b__1
02ce7c70: ldr     x24, [x24, #0x280]                         M:RateUsPopup::<Start>b__12_0
02ce7c74: ldr     x23, [x23, #0xa70]                         T:UnityEngine.Application
02ce7c78: mov     x28, xzr                                   
02ce7c7c: ldr     w8, [x8, #0x18]                            
02ce7c80: cmp     w28, w8                                    
02ce7c84: b.ge    #0x2ce7d1c                                 
02ce7c88: ldr     x0, [x26]                                  S:'{0}/2'
02ce7c8c: bl      #0x2b7104c                                 fn_2b7104c
02ce7c90: mov     x1, xzr                                    
02ce7c94: mov     x20, x0                                    
02ce7c98: bl      #0x4e53e9c                                 System.Object::.ctor
02ce7c9c: cbz     x20, #0x2ce7d18                            
02ce7ca0: mov     x21, x20                                   
02ce7ca4: mov     x1, x19                                    
02ce7ca8: str     x19, [x21, #0x18]!                         
02ce7cac: mov     x0, x21                                    
02ce7cb0: bl      #0x2b70d54                                 fn_2b70d54
02ce7cb4: ldr     x8, [x19, #0x38]                           .btnArray
02ce7cb8: stur    w28, [x21, #-8]                            
02ce7cbc: cbz     x8, #0x2ce7d18                             
02ce7cc0: ldr     w9, [x8, #0x18]                            
02ce7cc4: cmp     w28, w9                                    
02ce7cc8: b.hs    #0x2ce7d98                                 
02ce7ccc: add     x8, x8, x28, lsl #3                        
02ce7cd0: ldr     x8, [x8, #0x20]                            
02ce7cd4: cbz     x8, #0x2ce7d18                             
02ce7cd8: ldr     x0, [x25]                                  M:AdsManager::<OnApplicationPause>b__26_0
02ce7cdc: ldr     x21, [x8, #0x100]                          
02ce7ce0: bl      #0x2b7104c                                 fn_2b7104c
02ce7ce4: ldr     x2, [x27]                                  S:'{0}/2'
02ce7ce8: mov     x1, x20                                    
02ce7cec: mov     x3, xzr                                    
02ce7cf0: mov     x22, x0                                    
02ce7cf4: bl      #0x5b4cf98                                 UnityEngine.Events.UnityAction::.ctor
02ce7cf8: cbz     x21, #0x2ce7d18                            
02ce7cfc: mov     x0, x21                                    
02ce7d00: mov     x1, x22                                    
02ce7d04: mov     x2, xzr                                    
02ce7d08: bl      #0x5b4d0ac                                 UnityEngine.Events.UnityEvent::AddListener
02ce7d0c: ldr     x8, [x19, #0x38]                           .btnArray
02ce7d10: add     x28, x28, #1                               
02ce7d14: cbnz    x8, #0x2ce7c7c                             
02ce7d18: bl      #0x2b7105c                                 fn_2b7105c
02ce7d1c: ldr     x8, [x19, #0x58]                           .btnRate
02ce7d20: cbz     x8, #0x2ce7d18                             
02ce7d24: ldr     x0, [x25]                                  M:AdsManager::<OnApplicationPause>b__26_0
02ce7d28: ldr     x20, [x8, #0x100]                          
02ce7d2c: bl      #0x2b7104c                                 fn_2b7104c
02ce7d30: ldr     x2, [x24]                                  S:'{0}/2'
02ce7d34: mov     x1, x19                                    
02ce7d38: mov     x3, xzr                                    
02ce7d3c: mov     x21, x0                                    
02ce7d40: bl      #0x5b4cf98                                 UnityEngine.Events.UnityAction::.ctor
02ce7d44: cbz     x20, #0x2ce7d18                            
02ce7d48: mov     x0, x20                                    
02ce7d4c: mov     x1, x21                                    
02ce7d50: mov     x2, xzr                                    
02ce7d54: bl      #0x5b4d0ac                                 UnityEngine.Events.UnityEvent::AddListener
02ce7d58: ldr     x0, [x23]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02ce7d5c: ldr     w8, [x0, #0xe4]                            [62650e4]=0 f=0,0
02ce7d60: cbnz    w8, #0x2ce7d68                             
02ce7d64: bl      #0x2b70f30                                 fn_2b70f30
02ce7d68: mov     x0, xzr                                    
02ce7d6c: bl      #0x5aeac78                                 UnityEngine.Application::get_identifier
02ce7d70: str     x0, [x19, #0x68]!                          .androidId
02ce7d74: mov     x1, x0                                     
02ce7d78: mov     x0, x19                                    
02ce7d7c: ldp     x20, x19, [sp, #0x50]                      
02ce7d80: ldp     x22, x21, [sp, #0x40]                      
02ce7d84: ldp     x24, x23, [sp, #0x30]                      
02ce7d88: ldp     x26, x25, [sp, #0x20]                      
02ce7d8c: ldp     x28, x27, [sp, #0x10]                      
02ce7d90: ldr     x30, [sp], #0x60                           
02ce7d94: b       #0x2b70d54                                 
02ce7d98: bl      #0x2b71064                                 fn_2b71064
## OnInit(UIManager uiManager) -> void
---- RateUsPopup::OnInit 0x2ce7da4
02ce7da4: b       #0x2cdd3c4                                 UIBase::OnInit
## OnShow() -> void
---- RateUsPopup::OnShow 0x2ce7da8
02ce7da8: str     d8, [sp, #-0x30]!                          
02ce7dac: str     x30, [sp, #8]                              
02ce7db0: stp     x22, x21, [sp, #0x10]                      
02ce7db4: stp     x20, x19, [sp, #0x20]                      
02ce7db8: adrp    x21, #0x662f000                            
02ce7dbc: adrp    x20, #0x6264000                            
02ce7dc0: mov     x19, x0                                    
02ce7dc4: ldrb    w8, [x21, #0xdf8]                          
02ce7dc8: ldr     x20, [x20, #0xfc0]                         T:RemoteConfigManager
02ce7dcc: tbnz    w8, #0, #0x2ce7e08                         
02ce7dd0: adrp    x0, #0x6266000                             
02ce7dd4: ldr     x0, [x0, #0x750]                           MS:DataManager::GetData
02ce7dd8: bl      #0x2b70db0                                 fn_2b70db0
02ce7ddc: adrp    x0, #0x6266000                             
02ce7de0: ldr     x0, [x0, #0x658]                           MS:MonoSingleton`1::get_Instance
02ce7de4: bl      #0x2b70db0                                 fn_2b70db0
02ce7de8: adrp    x0, #0x6264000                             
02ce7dec: ldr     x0, [x0, #0xfc0]                           T:RemoteConfigManager
02ce7df0: bl      #0x2b70db0                                 fn_2b70db0
02ce7df4: adrp    x0, #0x6267000                             
02ce7df8: ldr     x0, [x0, #0xd38]                           MS:DG.Tweening.TweenSettingsExtensions::SetEase
02ce7dfc: bl      #0x2b70db0                                 fn_2b70db0
02ce7e00: mov     w8, #1                                     
02ce7e04: strb    w8, [x21, #0xdf8]                          
02ce7e08: ldr     x0, [x20]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02ce7e0c: ldr     w8, [x0, #0xe4]                            [62670e4]=0 f=0,0
02ce7e10: cbnz    w8, #0x2ce7e18                             
02ce7e14: bl      #0x2b70f30                                 fn_2b70f30
02ce7e18: adrp    x21, #0x662f000                            
02ce7e1c: ldrb    w8, [x21, #0xbc2]                          
02ce7e20: cbnz    w8, #0x2ce7e38                             
02ce7e24: adrp    x0, #0x6264000                             
02ce7e28: ldr     x0, [x0, #0xfc0]                           T:RemoteConfigManager
02ce7e2c: bl      #0x2b70db0                                 fn_2b70db0
02ce7e30: mov     w8, #1                                     
02ce7e34: strb    w8, [x21, #0xbc2]                          
02ce7e38: ldr     x0, [x20]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02ce7e3c: ldr     w8, [x0, #0xe4]                            [62640e4]=0 f=0,0
02ce7e40: cbnz    w8, #0x2ce7e4c                             
02ce7e44: bl      #0x2b70f30                                 fn_2b70f30
02ce7e48: ldr     x0, [x20]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02ce7e4c: ldr     x8, [x0, #0xb8]                            MS:DG.Tweening.Core.Extensions::SetSpecialStartupMode
02ce7e50: ldrb    w8, [x8, #0x15]                            
02ce7e54: cbz     w8, #0x2ce7ea8                             
02ce7e58: adrp    x8, #0x6266000                             
02ce7e5c: ldr     x8, [x8, #0x658]                           MS:MonoSingleton`1::get_Instance
02ce7e60: ldr     x0, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ce7e64: bl      #0x3769600                                 fn_3769600
02ce7e68: cbz     x0, #0x2ce7fd0                             
02ce7e6c: adrp    x8, #0x6266000                             
02ce7e70: ldr     x8, [x8, #0x750]                           MS:DataManager::GetData
02ce7e74: ldr     x1, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ce7e78: bl      #0x3168dd0                                 fn_3168dd0
02ce7e7c: cbz     x0, #0x2ce7fd0                             
02ce7e80: mov     x1, xzr                                    
02ce7e84: mov     x20, x0                                    
02ce7e88: bl      #0x2caba38                                 DataUser::HasRateUs
02ce7e8c: tbnz    w0, #0, #0x2ce7ea8                         
02ce7e90: ldr     x8, [x20, #0x20]                           T:DG.Tweening.DOTweenModulePhysics/<>c__DisplayClass0_0
02ce7e94: cbz     x8, #0x2ce7fd0                             
02ce7e98: ldr     w21, [x8, #0x4c]                           [626604c]=0 f=0,0
02ce7e9c: bl      #0x2ce7b54                                 RateUsPopup::get_LevelShowRate
02ce7ea0: cmp     w21, w0                                    
02ce7ea4: b.ge    #0x2ce7ebc                                 
02ce7ea8: ldp     x20, x19, [sp, #0x20]                      
02ce7eac: ldr     x30, [sp, #8]                              
02ce7eb0: ldp     x22, x21, [sp, #0x10]                      
02ce7eb4: ldr     d8, [sp], #0x30                            
02ce7eb8: ret                                                
02ce7ebc: mov     x0, x20                                    
02ce7ec0: mov     w1, #1                                     
02ce7ec4: mov     x2, xzr                                    
02ce7ec8: mov     w21, #1                                    
02ce7ecc: bl      #0x2caba50                                 DataUser::SetRateUs
02ce7ed0: movi    d0, #0000000000000000                      
02ce7ed4: ldr     x0, [x19, #0x28]                           
02ce7ed8: mov     w1, #1                                     
02ce7edc: mov     x2, xzr                                    
02ce7ee0: bl      #0x2cf1928                                 FrameWorkUtility::SetActive
02ce7ee4: ldr     x0, [x19, #0x60]                           ._panel
02ce7ee8: mov     w1, wzr                                    
02ce7eec: mov     x2, xzr                                    
02ce7ef0: strb    w21, [x19, #0x20]                          
02ce7ef4: bl      #0x2d9d5d0                                 DG.Tweening.ShortcutExtensions::DOKill
02ce7ef8: adrp    x8, #0x1084000                             
02ce7efc: adrp    x9, #0x1084000                             
02ce7f00: fmov    s4, #1.00000000                            
02ce7f04: ldr     s0, [x8, #0xeec]                           [1084eec]=457ff0003dcccccd f=0.1,4095
02ce7f08: ldr     s8, [x9, #0xda8]                           [1084da8]=da242603eb851ec f=0.36,1e-30
02ce7f0c: ldr     x0, [x19, #0x60]                           ._panel
02ce7f10: mov     w1, #0xa                                   
02ce7f14: mov     x2, xzr                                    
02ce7f18: fmov    s1, s0                                     
02ce7f1c: fmov    s2, s0                                     
02ce7f20: fmov    s3, s8                                     
02ce7f24: bl      #0x2d9982c                                 DG.Tweening.ShortcutExtensions::DOPunchScale
02ce7f28: adrp    x22, #0x662f000                            
02ce7f2c: ldr     x20, [x19, #0x60]                          ._panel
02ce7f30: ldrb    w8, [x22, #0x91a]                          
02ce7f34: cbnz    w8, #0x2ce7f48                             
02ce7f38: adrp    x0, #0x6264000                             
02ce7f3c: ldr     x0, [x0, #0xd8]                            T:UnityEngine.Vector3
02ce7f40: bl      #0x2b70db0                                 fn_2b70db0
02ce7f44: strb    w21, [x22, #0x91a]                         
02ce7f48: adrp    x8, #0x6264000                             
02ce7f4c: fmov    s3, s8                                     
02ce7f50: mov     x0, x20                                    
02ce7f54: ldr     x8, [x8, #0xd8]                            T:UnityEngine.Vector3
02ce7f58: mov     w1, wzr                                    
02ce7f5c: mov     x2, xzr                                    
02ce7f60: ldr     x8, [x8]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02ce7f64: ldr     x8, [x8, #0xb8]                            MS:DG.Tweening.Core.Extensions::SetSpecialStartupMode
02ce7f68: ldp     s0, s1, [x8]                               
02ce7f6c: ldr     s2, [x8, #8]                               T:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass2_0
02ce7f70: bl      #0x2d98760                                 DG.Tweening.ShortcutExtensions::DOLocalRotate
02ce7f74: adrp    x8, #0x6267000                             
02ce7f78: mov     w1, #0x1b                                  
02ce7f7c: ldr     x8, [x8, #0xd38]                           MS:DG.Tweening.TweenSettingsExtensions::SetEase
02ce7f80: ldr     x2, [x8]                                   S:'didu'
02ce7f84: bl      #0x336fa0c                                 fn_336fa0c
02ce7f88: ldr     x8, [x19, #0x40]                           .imgArray
02ce7f8c: str     wzr, [x19, #0x78]                          .rateCount
02ce7f90: cbz     x8, #0x2ce7fd0                             
02ce7f94: mov     x20, xzr                                   
02ce7f98: ldr     w9, [x8, #0x18]                            S:'android.content.Intent'
02ce7f9c: cmp     w20, w9                                    
02ce7fa0: b.ge    #0x2ce7fd4                                 
02ce7fa4: cmp     w20, w9                                    
02ce7fa8: b.hs    #0x2ce7ff8                                 
02ce7fac: add     x8, x8, x20, lsl #3                        &6267000
02ce7fb0: ldr     x0, [x8, #0x20]                            T:System.IO.FileInfo
02ce7fb4: cbz     x0, #0x2ce7fd0                             
02ce7fb8: ldr     x1, [x19, #0x50]                           .silverStar
02ce7fbc: mov     x2, xzr                                    
02ce7fc0: bl      #0x5c45aa0                                 UnityEngine.UI.Image::set_sprite
02ce7fc4: ldr     x8, [x19, #0x40]                           .imgArray
02ce7fc8: add     x20, x20, #1                               &6264001
02ce7fcc: cbnz    x8, #0x2ce7f98                             
02ce7fd0: bl      #0x2b7105c                                 fn_2b7105c
02ce7fd4: ldr     x0, [x19, #0x58]                           .btnRate
02ce7fd8: cbz     x0, #0x2ce7fd0                             
02ce7fdc: ldp     x20, x19, [sp, #0x20]                      
02ce7fe0: mov     w1, wzr                                    
02ce7fe4: ldp     x22, x21, [sp, #0x10]                      
02ce7fe8: mov     x2, xzr                                    
02ce7fec: ldr     x30, [sp, #8]                              
02ce7ff0: ldr     d8, [sp], #0x30                            
02ce7ff4: b       #0x5e662d4                                 UnityEngine.UI.Selectable::set_interactable
02ce7ff8: bl      #0x2b71064                                 fn_2b71064
## OnHide() -> void
---- RateUsPopup::OnHide 0x2ce7ffc
02ce7ffc: str     d8, [sp, #-0x40]!                          
02ce8000: str     x30, [sp, #8]                              
02ce8004: stp     x24, x23, [sp, #0x10]                      
02ce8008: stp     x22, x21, [sp, #0x20]                      
02ce800c: stp     x20, x19, [sp, #0x30]                      
02ce8010: adrp    x23, #0x6267000                            
02ce8014: adrp    x24, #0x662f000                            
02ce8018: adrp    x20, #0x6264000                            
02ce801c: adrp    x21, #0x6268000                            
02ce8020: adrp    x22, #0x6267000                            
02ce8024: ldr     x23, [x23, #0xd38]                         MS:DG.Tweening.TweenSettingsExtensions::SetEase
02ce8028: ldr     x20, [x20, #0xe8]                          T:DG.Tweening.TweenCallback
02ce802c: ldrb    w8, [x24, #0xdf9]                          
02ce8030: ldr     x21, [x21, #0x298]                         M:RateUsPopup::<OnHide>b__15_0
02ce8034: ldr     x22, [x22, #0xd30]                         MS:DG.Tweening.TweenSettingsExtensions::OnComplete
02ce8038: mov     x19, x0                                    
02ce803c: tbnz    w8, #0, #0x2ce8078                         
02ce8040: adrp    x0, #0x6268000                             
02ce8044: ldr     x0, [x0, #0x298]                           M:RateUsPopup::<OnHide>b__15_0
02ce8048: bl      #0x2b70db0                                 fn_2b70db0
02ce804c: adrp    x0, #0x6264000                             
02ce8050: ldr     x0, [x0, #0xe8]                            T:DG.Tweening.TweenCallback
02ce8054: bl      #0x2b70db0                                 fn_2b70db0
02ce8058: adrp    x0, #0x6267000                             
02ce805c: ldr     x0, [x0, #0xd30]                           MS:DG.Tweening.TweenSettingsExtensions::OnComplete
02ce8060: bl      #0x2b70db0                                 fn_2b70db0
02ce8064: adrp    x0, #0x6267000                             
02ce8068: ldr     x0, [x0, #0xd38]                           MS:DG.Tweening.TweenSettingsExtensions::SetEase
02ce806c: bl      #0x2b70db0                                 fn_2b70db0
02ce8070: mov     w8, #1                                     
02ce8074: strb    w8, [x24, #0xdf9]                          
02ce8078: ldr     x0, [x19, #0x60]                           ._panel
02ce807c: mov     w1, wzr                                    
02ce8080: mov     x2, xzr                                    
02ce8084: bl      #0x2d9d5d0                                 DG.Tweening.ShortcutExtensions::DOKill
02ce8088: adrp    x8, #0x1084000                             
02ce808c: adrp    x9, #0x1084000                             
02ce8090: fmov    s4, #1.00000000                            
02ce8094: ldr     s0, [x8, #0xeec]                           [1084eec]=457ff0003dcccccd f=0.1,4095
02ce8098: ldr     s8, [x9, #0xda8]                           [1084da8]=da242603eb851ec f=0.36,1e-30
02ce809c: ldr     x0, [x19, #0x60]                           ._panel
02ce80a0: mov     w1, #0xa                                   
02ce80a4: mov     x2, xzr                                    
02ce80a8: fmov    s1, s0                                     
02ce80ac: fmov    s2, s0                                     
02ce80b0: fmov    s3, s8                                     
02ce80b4: bl      #0x2d9982c                                 DG.Tweening.ShortcutExtensions::DOPunchScale
02ce80b8: movi    d0, #0000000000000000                      
02ce80bc: movi    d1, #0000000000000000                      
02ce80c0: ldr     x0, [x19, #0x60]                           ._panel
02ce80c4: fmov    s3, s8                                     
02ce80c8: fmov    s2, #10.00000000                           
02ce80cc: mov     w1, wzr                                    
02ce80d0: mov     x2, xzr                                    
02ce80d4: bl      #0x2d98760                                 DG.Tweening.ShortcutExtensions::DOLocalRotate
02ce80d8: ldr     x2, [x23]                                  S:'didu'
02ce80dc: mov     w1, #0x1a                                  
02ce80e0: bl      #0x336fa0c                                 fn_336fa0c
02ce80e4: ldr     x8, [x20]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02ce80e8: mov     x20, x0                                    
02ce80ec: mov     x0, x8                                     
02ce80f0: bl      #0x2b7104c                                 fn_2b7104c
02ce80f4: ldr     x2, [x21]                                  S:'{0}/2'
02ce80f8: mov     x1, x19                                    
02ce80fc: mov     x3, xzr                                    
02ce8100: mov     x21, x0                                    
02ce8104: bl      #0x2d89dc4                                 DG.Tweening.TweenCallback::.ctor
02ce8108: ldr     x2, [x22]                                  S:'didu'
02ce810c: mov     x0, x20                                    
02ce8110: mov     x1, x21                                    
02ce8114: ldp     x20, x19, [sp, #0x30]                      
02ce8118: ldr     x30, [sp, #8]                              
02ce811c: ldp     x22, x21, [sp, #0x20]                      
02ce8120: ldp     x24, x23, [sp, #0x10]                      
02ce8124: ldr     d8, [sp], #0x40                            
02ce8128: b       #0x336f26c                                 
## OnChooseStar(int star) -> void
---- RateUsPopup::OnChooseStar 0x2ce812c
02ce812c: stp     x30, x19, [sp, #-0x10]!                    
02ce8130: mov     x19, x0                                    
02ce8134: str     w1, [x0, #0x78]                            .rateCount
02ce8138: bl      #0x2ce8150                                 RateUsPopup::I_Choose
02ce813c: mov     x1, x0                                     
02ce8140: mov     x0, x19                                    
02ce8144: mov     x2, xzr                                    
02ce8148: ldp     x30, x19, [sp], #0x10                      
02ce814c: b       #0x5b389f0                                 UnityEngine.MonoBehaviour::StartCoroutine
## I_Choose() -> System.Collections.IEnumerator
---- RateUsPopup::I_Choose 0x2ce8150
02ce8150: stp     x30, x21, [sp, #-0x20]!                    
02ce8154: stp     x20, x19, [sp, #0x10]                      
02ce8158: adrp    x20, #0x662f000                            
02ce815c: adrp    x21, #0x6268000                            
02ce8160: mov     x19, x0                                    
02ce8164: ldrb    w8, [x20, #0xdfa]                          
02ce8168: ldr     x21, [x21, #0x2a0]                         T:RateUsPopup/<I_Choose>d__17
02ce816c: tbnz    w8, #0, #0x2ce8184                         
02ce8170: adrp    x0, #0x6268000                             
02ce8174: ldr     x0, [x0, #0x2a0]                           T:RateUsPopup/<I_Choose>d__17
02ce8178: bl      #0x2b70db0                                 fn_2b70db0
02ce817c: mov     w8, #1                                     
02ce8180: strb    w8, [x20, #0xdfa]                          
02ce8184: ldr     x0, [x21]                                  S:'{0}/2'
02ce8188: bl      #0x2b7104c                                 fn_2b7104c
02ce818c: mov     x1, xzr                                    
02ce8190: mov     x20, x0                                    
02ce8194: bl      #0x4e53e9c                                 System.Object::.ctor
02ce8198: mov     x0, x20                                    
02ce819c: mov     x1, x19                                    
02ce81a0: str     wzr, [x20, #0x10]                          
02ce81a4: str     x19, [x0, #0x20]!                          
02ce81a8: bl      #0x2b70d54                                 fn_2b70d54
02ce81ac: mov     x0, x20                                    
02ce81b0: ldp     x20, x19, [sp, #0x10]                      
02ce81b4: ldp     x30, x21, [sp], #0x20                      
02ce81b8: ret                                                
## RateForUs(int rateCount) -> void
---- RateUsPopup::RateForUs 0x2ce81e4
02ce81e4: stp     x30, x19, [sp, #-0x10]!                    
02ce81e8: mov     x19, x0                                    
02ce81ec: str     w1, [x0, #0x78]                            .rateCount
02ce81f0: bl      #0x2ce8208                                 RateUsPopup::I_Rate
02ce81f4: mov     x1, x0                                     
02ce81f8: mov     x0, x19                                    
02ce81fc: mov     x2, xzr                                    
02ce8200: ldp     x30, x19, [sp], #0x10                      
02ce8204: b       #0x5b389f0                                 UnityEngine.MonoBehaviour::StartCoroutine
## I_Rate(int rateCount) -> System.Collections.IEnumerator
---- RateUsPopup::I_Rate 0x2ce8208
02ce8208: str     x30, [sp, #-0x30]!                         
02ce820c: stp     x22, x21, [sp, #0x10]                      
02ce8210: stp     x20, x19, [sp, #0x20]                      
02ce8214: adrp    x21, #0x662f000                            
02ce8218: adrp    x22, #0x6268000                            
02ce821c: mov     w19, w1                                    
02ce8220: ldrb    w8, [x21, #0xdfb]                          
02ce8224: ldr     x22, [x22, #0x2a8]                         T:RateUsPopup/<I_Rate>d__19
02ce8228: mov     x20, x0                                    
02ce822c: tbnz    w8, #0, #0x2ce8244                         
02ce8230: adrp    x0, #0x6268000                             
02ce8234: ldr     x0, [x0, #0x2a8]                           T:RateUsPopup/<I_Rate>d__19
02ce8238: bl      #0x2b70db0                                 fn_2b70db0
02ce823c: mov     w8, #1                                     
02ce8240: strb    w8, [x21, #0xdfb]                          
02ce8244: ldr     x0, [x22]                                  S:'{0}/2'
02ce8248: bl      #0x2b7104c                                 fn_2b7104c
02ce824c: mov     x1, xzr                                    
02ce8250: mov     x21, x0                                    
02ce8254: bl      #0x4e53e9c                                 System.Object::.ctor
02ce8258: mov     x0, x21                                    
02ce825c: mov     x1, x20                                    
02ce8260: str     wzr, [x21, #0x10]                          
02ce8264: str     x20, [x0, #0x28]!                          
02ce8268: bl      #0x2b70d54                                 fn_2b70d54
02ce826c: mov     x0, x21                                    
02ce8270: str     w19, [x21, #0x20]                          
02ce8274: ldp     x20, x19, [sp, #0x20]                      
02ce8278: ldp     x22, x21, [sp, #0x10]                      
02ce827c: ldr     x30, [sp], #0x30                           
02ce8280: ret                                                
## ShowWithCloseEvent(System.Action onClose) -> void
---- RateUsPopup::ShowWithCloseEvent 0x2ce82ac
02ce82ac: str     x30, [sp, #-0x30]!                         
02ce82b0: stp     x22, x21, [sp, #0x10]                      
02ce82b4: stp     x20, x19, [sp, #0x20]                      
02ce82b8: adrp    x20, #0x662f000                            
02ce82bc: adrp    x22, #0x6268000                            
02ce82c0: mov     x21, x1                                    
02ce82c4: ldrb    w8, [x20, #0xdfc]                          
02ce82c8: ldr     x22, [x22, #0x2b0]                         T:RateUsPopup/<>c__DisplayClass20_0
02ce82cc: mov     x19, x0                                    
02ce82d0: tbnz    w8, #0, #0x2ce830c                         
02ce82d4: adrp    x0, #0x6268000                             
02ce82d8: ldr     x0, [x0, #0x2b8]                           M:RateUsPopup/<>c__DisplayClass20_0::<ShowWithCloseEvent>b__0
02ce82dc: bl      #0x2b70db0                                 fn_2b70db0
02ce82e0: adrp    x0, #0x6268000                             
02ce82e4: ldr     x0, [x0, #0x2b0]                           T:RateUsPopup/<>c__DisplayClass20_0
02ce82e8: bl      #0x2b70db0                                 fn_2b70db0
02ce82ec: adrp    x0, #0x6265000                             
02ce82f0: ldr     x0, [x0, #0x3f0]                           T:UnityEngine.Events.UnityAction
02ce82f4: bl      #0x2b70db0                                 fn_2b70db0
02ce82f8: adrp    x0, #0x6267000                             
02ce82fc: ldr     x0, [x0, #0xff0]                           T:UnityEngine.Events.UnityEvent
02ce8300: bl      #0x2b70db0                                 fn_2b70db0
02ce8304: mov     w8, #1                                     
02ce8308: strb    w8, [x20, #0xdfc]                          
02ce830c: ldr     x0, [x22]                                  S:'{0}/2'
02ce8310: bl      #0x2b7104c                                 fn_2b7104c
02ce8314: mov     x1, xzr                                    
02ce8318: mov     x20, x0                                    
02ce831c: bl      #0x4e53e9c                                 System.Object::.ctor
02ce8320: cbz     x20, #0x2ce83c8                            
02ce8324: mov     x0, x20                                    
02ce8328: mov     x1, x21                                    
02ce832c: str     x21, [x0, #0x10]!                          
02ce8330: bl      #0x2b70d54                                 fn_2b70d54
02ce8334: ldr     x0, [x19, #0x80]!                          .OnCloseAction
02ce8338: cbnz    x0, #0x2ce8370                             
02ce833c: adrp    x8, #0x6267000                             
02ce8340: ldr     x8, [x8, #0xff0]                           T:UnityEngine.Events.UnityEvent
02ce8344: ldr     x0, [x8]                                   S:'didu'
02ce8348: bl      #0x2b7104c                                 fn_2b7104c
02ce834c: mov     x1, xzr                                    
02ce8350: mov     x21, x0                                    
02ce8354: bl      #0x5b4d048                                 UnityEngine.Events.UnityEvent::.ctor
02ce8358: mov     x0, x19                                    
02ce835c: mov     x1, x21                                    
02ce8360: str     x21, [x19]                                 
02ce8364: bl      #0x2b70d54                                 fn_2b70d54
02ce8368: ldr     x0, [x19]                                  
02ce836c: cbz     x0, #0x2ce83c8                             
02ce8370: adrp    x21, #0x6265000                            
02ce8374: adrp    x22, #0x6268000                            
02ce8378: mov     x1, xzr                                    
02ce837c: ldr     x21, [x21, #0x3f0]                         T:UnityEngine.Events.UnityAction
02ce8380: ldr     x22, [x22, #0x2b8]                         M:RateUsPopup/<>c__DisplayClass20_0::<ShowWithCloseEvent>b__0
02ce8384: bl      #0x5b4ce48                                 UnityEngine.Events.UnityEventBase::RemoveAllListeners
02ce8388: ldr     x0, [x21]                                  M:AdsManager::<OnApplicationPause>b__26_0
02ce838c: ldr     x19, [x19]                                 
02ce8390: bl      #0x2b7104c                                 fn_2b7104c
02ce8394: ldr     x2, [x22]                                  S:'{0}/2'
02ce8398: mov     x1, x20                                    
02ce839c: mov     x3, xzr                                    
02ce83a0: mov     x21, x0                                    
02ce83a4: bl      #0x5b4cf98                                 UnityEngine.Events.UnityAction::.ctor
02ce83a8: cbz     x19, #0x2ce83c8                            
02ce83ac: mov     x0, x19                                    
02ce83b0: mov     x1, x21                                    
02ce83b4: mov     x2, xzr                                    
02ce83b8: ldp     x20, x19, [sp, #0x20]                      
02ce83bc: ldp     x22, x21, [sp, #0x10]                      
02ce83c0: ldr     x30, [sp], #0x30                           
02ce83c4: b       #0x5b4d0ac                                 UnityEngine.Events.UnityEvent::AddListener
02ce83c8: bl      #0x2b7105c                                 fn_2b7105c
## .ctor() -> void
---- RateUsPopup::.ctor 0x2ce83d4
02ce83d4: str     x30, [sp, #-0x30]!                         
02ce83d8: stp     x22, x21, [sp, #0x10]                      
02ce83dc: stp     x20, x19, [sp, #0x20]                      
02ce83e0: adrp    x21, #0x662f000                            
02ce83e4: adrp    x22, #0x6268000                            
02ce83e8: adrp    x20, #0x6268000                            
02ce83ec: ldrb    w8, [x21, #0xdfd]                          
02ce83f0: ldr     x22, [x22, #0x260]                         T:type60867(k1d)
02ce83f4: ldr     x20, [x20, #0x268]                         T:type60921(k1d)
02ce83f8: mov     x19, x0                                    
02ce83fc: tbnz    w8, #0, #0x2ce8420                         
02ce8400: adrp    x0, #0x6268000                             
02ce8404: ldr     x0, [x0, #0x260]                           T:type60867(k1d)
02ce8408: bl      #0x2b70db0                                 fn_2b70db0
02ce840c: adrp    x0, #0x6268000                             
02ce8410: ldr     x0, [x0, #0x268]                           T:type60921(k1d)
02ce8414: bl      #0x2b70db0                                 fn_2b70db0
02ce8418: mov     w8, #1                                     
02ce841c: strb    w8, [x21, #0xdfd]                          
02ce8420: ldr     x0, [x22]                                  S:'{0}/2'
02ce8424: mov     w1, wzr                                    
02ce8428: bl      #0x2b70ea0                                 fn_2b70ea0
02ce842c: mov     x1, x0                                     
02ce8430: mov     x0, x19                                    
02ce8434: str     x1, [x0, #0x38]!                           .btnArray
02ce8438: bl      #0x2b70d54                                 fn_2b70d54
02ce843c: ldr     x0, [x20]                                  S:'{0}/2'
02ce8440: mov     w1, wzr                                    
02ce8444: bl      #0x2b70ea0                                 fn_2b70ea0
02ce8448: mov     x1, x0                                     
02ce844c: mov     x0, x19                                    
02ce8450: str     x1, [x0, #0x40]!                           .imgArray
02ce8454: bl      #0x2b70d54                                 fn_2b70d54
02ce8458: mov     x0, x19                                    
02ce845c: ldp     x20, x19, [sp, #0x20]                      
02ce8460: ldp     x22, x21, [sp, #0x10]                      
02ce8464: mov     x1, xzr                                    
02ce8468: ldr     x30, [sp], #0x30                           
02ce846c: b       #0x5b397b0                                 UnityEngine.MonoBehaviour::.ctor
## <Start>b__12_0() -> void
---- RateUsPopup::<Start>b__12_0 0x2ce8470
02ce8470: str     x30, [sp, #-0x20]!                         
02ce8474: stp     x20, x19, [sp, #0x10]                      
02ce8478: adrp    x20, #0x662f000                            
02ce847c: mov     x19, x0                                    
02ce8480: ldrb    w8, [x20, #0xdfe]                          
02ce8484: tbnz    w8, #0, #0x2ce849c                         
02ce8488: adrp    x0, #0x6267000                             
02ce848c: ldr     x0, [x0, #0xd50]                           MS:MonoSingleton`1::get_Instance
02ce8490: bl      #0x2b70db0                                 fn_2b70db0
02ce8494: mov     w8, #1                                     
02ce8498: strb    w8, [x20, #0xdfe]                          
02ce849c: mov     x0, xzr                                    
02ce84a0: bl      #0x2d6eec8                                 Framework.AudioManager::get_Instance
02ce84a4: cbz     x0, #0x2ce850c                             
02ce84a8: movi    d1, #0000000000000000                      
02ce84ac: movi    d2, #0000000000000000                      
02ce84b0: adrp    x20, #0x6267000                            
02ce84b4: fmov    s0, #1.00000000                            
02ce84b8: ldr     x20, [x20, #0xd50]                         MS:MonoSingleton`1::get_Instance
02ce84bc: mov     w1, #1                                     
02ce84c0: mov     w2, wzr                                    
02ce84c4: mov     w3, wzr                                    
02ce84c8: mov     x4, xzr                                    
02ce84cc: bl      #0x2d6f03c                                 Framework.AudioManager::PlaySound
02ce84d0: ldr     x0, [x20]                                  S:'didu'
02ce84d4: bl      #0x3769600                                 fn_3769600
02ce84d8: cbz     x0, #0x2ce850c                             
02ce84dc: mov     w1, #4                                     
02ce84e0: mov     x2, xzr                                    
02ce84e4: bl      #0x2cc6ee0                                 Framework.VibrationManager::Haptic
02ce84e8: ldr     w1, [x19, #0x78]                           .rateCount
02ce84ec: mov     x0, x19                                    
02ce84f0: bl      #0x2ce8208                                 RateUsPopup::I_Rate
02ce84f4: mov     x1, x0                                     
02ce84f8: mov     x0, x19                                    
02ce84fc: mov     x2, xzr                                    
02ce8500: ldp     x20, x19, [sp, #0x10]                      
02ce8504: ldr     x30, [sp], #0x20                           
02ce8508: b       #0x5b389f0                                 UnityEngine.MonoBehaviour::StartCoroutine
02ce850c: bl      #0x2b7105c                                 fn_2b7105c
## <OnHide>b__15_0() -> void
---- RateUsPopup::<OnHide>b__15_0 0x2ce8510
02ce8510: stp     x30, x19, [sp, #-0x10]!                    
02ce8514: movi    d0, #0000000000000000                      
02ce8518: mov     x19, x0                                    
02ce851c: ldr     x0, [x0, #0x28]                            
02ce8520: mov     w1, wzr                                    
02ce8524: mov     x2, xzr                                    
02ce8528: bl      #0x2cf1928                                 FrameWorkUtility::SetActive
02ce852c: strb    wzr, [x19, #0x20]                          
02ce8530: ldp     x30, x19, [sp], #0x10                      
02ce8534: ret                                                
