#### CLASS IAPRewardBundle parent= object
#   field ProductId                      IAPKey                                             off=0x10 attr=6 
#   field RewardList                     System.Collections.Generic.List`1<IAPRewardItem>   off=0x18 attr=6 
## .ctor() -> void
---- IAPRewardBundle::.ctor 0x2ca49a8
02ca49a8: mov     x1, xzr                                    
02ca49ac: b       #0x4e53e9c                                 System.Object::.ctor
