#### CLASS Blindbag.NotiCanvas/<>c__DisplayClass5_0 parent= object
#   field <>4__this                      Blindbag.NotiCanvas                                off=0x10 attr=6 
#   field onCompleted                    System.Action                                      off=0x18 attr=6 
## .ctor() -> void
---- Blindbag.NotiCanvas/<>c__DisplayClass5_0::.ctor 0x2d57d24
02d57d24: mov     x1, xzr                                    
02d57d28: b       #0x4e53e9c                                 System.Object::.ctor
## <Show>b__0() -> void
---- Blindbag.NotiCanvas/<>c__DisplayClass5_0::<Show>b__0 0x2d57d84
02d57d84: stp     x30, x19, [sp, #-0x10]!                    
02d57d88: ldr     x8, [x0, #0x10]                            .<>4__this
02d57d8c: cbz     x8, #0x2d57df4                             
02d57d90: mov     x19, x0                                    
02d57d94: ldr     x0, [x8, #0x20]                            
02d57d98: cbz     x0, #0x2d57df4                             
02d57d9c: movi    d0, #0000000000000000                      
02d57da0: mov     x1, xzr                                    
02d57da4: bl      #0x5e45108                                 UnityEngine.CanvasGroup::set_alpha
02d57da8: ldr     x8, [x19, #0x10]                           .<>4__this
02d57dac: cbz     x8, #0x2d57df4                             
02d57db0: ldr     x0, [x8, #0x28]                            
02d57db4: cbz     x0, #0x2d57df4                             
02d57db8: ldp     s0, s1, [x8, #0x30]                        
02d57dbc: mov     x1, xzr                                    
02d57dc0: bl      #0x5b45800                                 UnityEngine.RectTransform::set_anchoredPosition
02d57dc4: ldr     x9, [x19, #0x10]                           .<>4__this
02d57dc8: cbz     x9, #0x2d57df4                             
02d57dcc: ldr     x8, [x19, #0x18]                           .onCompleted
02d57dd0: strb    wzr, [x9, #0x38]                           
02d57dd4: cbz     x8, #0x2d57dec                             
02d57dd8: ldr     x0, [x8, #0x40]                            
02d57ddc: ldr     x1, [x8, #0x28]                            
02d57de0: ldr     x2, [x8, #0x18]                            
02d57de4: ldp     x30, x19, [sp], #0x10                      
02d57de8: br      x2                                         
02d57dec: ldp     x30, x19, [sp], #0x10                      
02d57df0: ret                                                
02d57df4: bl      #0x2b7105c                                 fn_2b7105c
#### CLASS Blindbag.NotiCanvas parent= UnityEngine.MonoBehaviour
#   field _canvasGroup                   UnityEngine.CanvasGroup                            off=0x20 attr=1 SerializeField
#   field _rectTransform                 UnityEngine.RectTransform                          off=0x28 attr=1 SerializeField
#   field _cachedAnchorPosition          UnityEngine.Vector2                                off=0x30 attr=1 
#   field _isShowing                     bool                                               off=0x38 attr=1 
## Awake() -> void
---- Blindbag.NotiCanvas::Awake 0x2d57b7c
02d57b7c: stp     x30, x19, [sp, #-0x10]!                    
02d57b80: mov     x19, x0                                    
02d57b84: ldr     x0, [x0, #0x28]                            ._rectTransform
02d57b88: cbz     x0, #0x2d57ba0                             
02d57b8c: mov     x1, xzr                                    
02d57b90: bl      #0x5b45734                                 UnityEngine.RectTransform::get_anchoredPosition
02d57b94: stp     s0, s1, [x19, #0x30]                       ._cachedAnchorPosition
02d57b98: ldp     x30, x19, [sp], #0x10                      
02d57b9c: ret                                                
02d57ba0: bl      #0x2b7105c                                 fn_2b7105c
## Show(float duration, System.Action onCompleted) -> void
---- Blindbag.NotiCanvas::Show 0x2d57ba4
02d57ba4: str     d8, [sp, #-0x30]!                          
02d57ba8: str     x30, [sp, #8]                              
02d57bac: stp     x22, x21, [sp, #0x10]                      
02d57bb0: stp     x20, x19, [sp, #0x20]                      
02d57bb4: fmov    s8, s0                                     
02d57bb8: adrp    x20, #0x6630000                            
02d57bbc: adrp    x22, #0x626b000                            
02d57bc0: ldrb    w8, [x20, #0x298]                          
02d57bc4: ldr     x22, [x22, #0xa78]                         T:Blindbag.NotiCanvas/<>c__DisplayClass5_0
02d57bc8: mov     x21, x1                                    
02d57bcc: mov     x19, x0                                    
02d57bd0: tbnz    w8, #0, #0x2d57c0c                         
02d57bd4: adrp    x0, #0x6264000                             
02d57bd8: ldr     x0, [x0, #0xe8]                            T:DG.Tweening.TweenCallback
02d57bdc: bl      #0x2b70db0                                 fn_2b70db0
02d57be0: adrp    x0, #0x6266000                             
02d57be4: ldr     x0, [x0, #0xa08]                           MS:DG.Tweening.TweenSettingsExtensions::OnComplete
02d57be8: bl      #0x2b70db0                                 fn_2b70db0
02d57bec: adrp    x0, #0x626b000                             
02d57bf0: ldr     x0, [x0, #0xa80]                           M:Blindbag.NotiCanvas/<>c__DisplayClass5_0::<Show>b__0
02d57bf4: bl      #0x2b70db0                                 fn_2b70db0
02d57bf8: adrp    x0, #0x626b000                             
02d57bfc: ldr     x0, [x0, #0xa78]                           T:Blindbag.NotiCanvas/<>c__DisplayClass5_0
02d57c00: bl      #0x2b70db0                                 fn_2b70db0
02d57c04: mov     w8, #1                                     
02d57c08: strb    w8, [x20, #0x298]                          
02d57c0c: ldr     x0, [x22]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d57c10: bl      #0x2b7104c                                 fn_2b7104c
02d57c14: mov     x1, xzr                                    
02d57c18: mov     x20, x0                                    
02d57c1c: bl      #0x4e53e9c                                 System.Object::.ctor
02d57c20: cbz     x20, #0x2d57d20                            
02d57c24: mov     x0, x20                                    
02d57c28: mov     x1, x19                                    
02d57c2c: str     x19, [x0, #0x10]!                          
02d57c30: bl      #0x2b70d54                                 fn_2b70d54
02d57c34: mov     x0, x20                                    
02d57c38: mov     x1, x21                                    
02d57c3c: str     x21, [x0, #0x18]!                          
02d57c40: bl      #0x2b70d54                                 fn_2b70d54
02d57c44: ldrb    w8, [x19, #0x38]                           ._isShowing
02d57c48: cbz     w8, #0x2d57c60                             
02d57c4c: ldp     x20, x19, [sp, #0x20]                      
02d57c50: ldr     x30, [sp, #8]                              
02d57c54: ldp     x22, x21, [sp, #0x10]                      
02d57c58: ldr     d8, [sp], #0x30                            
02d57c5c: ret                                                
02d57c60: ldr     x0, [x19, #0x20]                           ._canvasGroup
02d57c64: mov     w8, #1                                     
02d57c68: mov     w1, wzr                                    
02d57c6c: mov     x2, xzr                                    
02d57c70: strb    w8, [x19, #0x38]                           ._isShowing
02d57c74: bl      #0x2d9d5d0                                 DG.Tweening.ShortcutExtensions::DOKill
02d57c78: ldr     x0, [x19, #0x20]                           ._canvasGroup
02d57c7c: cbz     x0, #0x2d57d20                             
02d57c80: fmov    s0, #1.00000000                            
02d57c84: mov     x1, xzr                                    
02d57c88: bl      #0x5e45108                                 UnityEngine.CanvasGroup::set_alpha
02d57c8c: movi    d0, #0000000000000000                      
02d57c90: fmov    s1, s8                                     
02d57c94: ldr     x0, [x19, #0x20]                           ._canvasGroup
02d57c98: mov     x1, xzr                                    
02d57c9c: bl      #0x2c78338                                 DG.Tweening.DOTweenModuleUI::DOFade
02d57ca0: mov     w8, #0x43160000                            
02d57ca4: ldr     s0, [x19, #0x34]                           
02d57ca8: ldr     x0, [x19, #0x28]                           ._rectTransform
02d57cac: fmov    s1, w8                                     
02d57cb0: mov     w1, wzr                                    
02d57cb4: mov     x2, xzr                                    
02d57cb8: fadd    s0, s0, s1                                 
02d57cbc: fmov    s1, s8                                     
02d57cc0: bl      #0x2c79c1c                                 DG.Tweening.DOTweenModuleUI::DOAnchorPosY
02d57cc4: adrp    x8, #0x6264000                             
02d57cc8: mov     x19, x0                                    
02d57ccc: ldr     x8, [x8, #0xe8]                            T:DG.Tweening.TweenCallback
02d57cd0: ldr     x8, [x8]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d57cd4: mov     x0, x8                                     
02d57cd8: bl      #0x2b7104c                                 fn_2b7104c
02d57cdc: adrp    x8, #0x626b000                             
02d57ce0: mov     x1, x20                                    
02d57ce4: mov     x3, xzr                                    
02d57ce8: ldr     x8, [x8, #0xa80]                           M:Blindbag.NotiCanvas/<>c__DisplayClass5_0::<Show>b__0
02d57cec: mov     x21, x0                                    
02d57cf0: ldr     x2, [x8]                                   T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d57cf4: bl      #0x2d89dc4                                 DG.Tweening.TweenCallback::.ctor
02d57cf8: adrp    x8, #0x6266000                             
02d57cfc: mov     x0, x19                                    
02d57d00: mov     x1, x21                                    
02d57d04: ldr     x8, [x8, #0xa08]                           MS:DG.Tweening.TweenSettingsExtensions::OnComplete
02d57d08: ldp     x20, x19, [sp, #0x20]                      
02d57d0c: ldp     x22, x21, [sp, #0x10]                      
02d57d10: ldr     x30, [sp, #8]                              
02d57d14: ldr     x2, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d57d18: ldr     d8, [sp], #0x30                            
02d57d1c: b       #0x336f26c                                 
02d57d20: bl      #0x2b7105c                                 fn_2b7105c
## ResetItem() -> void
---- Blindbag.NotiCanvas::ResetItem 0x2d57d2c
02d57d2c: stp     x30, x19, [sp, #-0x10]!                    
02d57d30: mov     x19, x0                                    
02d57d34: ldr     x0, [x0, #0x28]                            ._rectTransform
02d57d38: mov     w1, wzr                                    
02d57d3c: mov     x2, xzr                                    
02d57d40: bl      #0x2d9d5d0                                 DG.Tweening.ShortcutExtensions::DOKill
02d57d44: ldr     x0, [x19, #0x20]                           ._canvasGroup
02d57d48: cbz     x0, #0x2d57d78                             
02d57d4c: movi    d0, #0000000000000000                      
02d57d50: mov     x1, xzr                                    
02d57d54: bl      #0x5e45108                                 UnityEngine.CanvasGroup::set_alpha
02d57d58: ldr     x0, [x19, #0x28]                           ._rectTransform
02d57d5c: cbz     x0, #0x2d57d78                             
02d57d60: ldp     s0, s1, [x19, #0x30]                       ._cachedAnchorPosition
02d57d64: mov     x1, xzr                                    
02d57d68: bl      #0x5b45800                                 UnityEngine.RectTransform::set_anchoredPosition
02d57d6c: strb    wzr, [x19, #0x38]                          ._isShowing
02d57d70: ldp     x30, x19, [sp], #0x10                      
02d57d74: ret                                                
02d57d78: bl      #0x2b7105c                                 fn_2b7105c
## .ctor() -> void
---- Blindbag.NotiCanvas::.ctor 0x2d57d7c
02d57d7c: mov     x1, xzr                                    
02d57d80: b       #0x5b397b0                                 UnityEngine.MonoBehaviour::.ctor
