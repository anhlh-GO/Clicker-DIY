#### CLASS Decor.PetChanger parent= UnityEngine.MonoBehaviour
#   field _petChanger                    Home.PetChanger                                    off=0x20 attr=1 SerializeField
#   field _currentID                     int                                                off=0x28 attr=1 
#   field _petHomeAsset                  Home.PetHomeAsset                                  off=0x30 attr=1 SerializeField
## Awake() -> void
---- Decor.PetChanger::Awake 0x2d26c6c
02d26c6c: mov     w8, #-1                                    
02d26c70: str     w8, [x0, #0x28]                            ._currentID
02d26c74: ret                                                
## ChangeItem(int categoryIndex, int optionID) -> void
---- Decor.PetChanger::ChangeItem 0x2d26c78
02d26c78: str     x30, [sp, #-0x30]!                         
02d26c7c: stp     x22, x21, [sp, #0x10]                      
02d26c80: stp     x20, x19, [sp, #0x20]                      
02d26c84: adrp    x22, #0x6630000                            
02d26c88: mov     w21, w2                                    
02d26c8c: mov     w20, w1                                    
02d26c90: ldrb    w8, [x22, #0x88]                           
02d26c94: mov     x19, x0                                    
02d26c98: tbnz    w8, #0, #0x2d26cc8                         
02d26c9c: adrp    x0, #0x6266000                             
02d26ca0: ldr     x0, [x0, #0x870]                           MS:DataManager::GetAsset
02d26ca4: bl      #0x2b70db0                                 fn_2b70db0
02d26ca8: adrp    x0, #0x626a000                             
02d26cac: ldr     x0, [x0, #0x118]                           MS:System.Collections.Generic.List`1::get_Count
02d26cb0: bl      #0x2b70db0                                 fn_2b70db0
02d26cb4: adrp    x0, #0x6266000                             
02d26cb8: ldr     x0, [x0, #0x658]                           MS:MonoSingleton`1::get_Instance
02d26cbc: bl      #0x2b70db0                                 fn_2b70db0
02d26cc0: mov     w8, #1                                     
02d26cc4: strb    w8, [x22, #0x88]                           
02d26cc8: ldr     w8, [x19, #0x28]                           ._currentID
02d26ccc: cmp     w8, w21                                    
02d26cd0: b.ne    #0x2d26ce4                                 
02d26cd4: ldp     x20, x19, [sp, #0x20]                      
02d26cd8: ldp     x22, x21, [sp, #0x10]                      
02d26cdc: ldr     x30, [sp], #0x30                           
02d26ce0: ret                                                
02d26ce4: ldr     x8, [x19, #0x30]                           ._petHomeAsset
02d26ce8: str     w21, [x19, #0x28]                          ._currentID
02d26cec: cbz     x8, #0x2d26d7c                             
02d26cf0: ldr     x8, [x8, #0x20]                            
02d26cf4: cbz     x8, #0x2d26d7c                             
02d26cf8: adrp    x9, #0x6266000                             
02d26cfc: ldr     w8, [x8, #0x18]                            
02d26d00: ldr     x9, [x9, #0x658]                           MS:MonoSingleton`1::get_Instance
02d26d04: cmp     w8, w21                                    
02d26d08: ldr     x0, [x9]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d26d0c: csel    w21, w21, wzr, gt                          
02d26d10: bl      #0x3769600                                 fn_3769600
02d26d14: cbz     x0, #0x2d26d7c                             
02d26d18: adrp    x8, #0x6266000                             
02d26d1c: ldr     x8, [x8, #0x870]                           MS:DataManager::GetAsset
02d26d20: ldr     x1, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d26d24: bl      #0x3168af0                                 fn_3168af0
02d26d28: cbz     x0, #0x2d26d7c                             
02d26d2c: mov     w1, w20                                    
02d26d30: bl      #0x2d249f4                                 Decor.DecorAsset::GetCategoryAssetByIndex
02d26d34: cbz     x0, #0x2d26d7c                             
02d26d38: mov     w1, w21                                    
02d26d3c: bl      #0x2d24a4c                                 Decor.CategoryAsset::GetOptionDataByID
02d26d40: ldr     x0, [x19, #0x30]                           ._petHomeAsset
02d26d44: cbz     x0, #0x2d26d7c                             
02d26d48: mov     w1, w21                                    
02d26d4c: bl      #0x2d1ddc4                                 Home.PetHomeAsset::GetData
02d26d50: ldr     x8, [x19, #0x20]                           ._petChanger
02d26d54: cbz     x8, #0x2d26d7c                             
02d26d58: mov     x1, x0                                     
02d26d5c: mov     x0, x8                                     
02d26d60: bl      #0x2d24184                                 Home.PetChanger::SetPet
02d26d64: ldr     x0, [x19, #0x20]                           ._petChanger
02d26d68: cbz     x0, #0x2d26d7c                             
02d26d6c: ldp     x20, x19, [sp, #0x20]                      
02d26d70: ldp     x22, x21, [sp, #0x10]                      
02d26d74: ldr     x30, [sp], #0x30                           
02d26d78: b       #0x2d24000                                 Home.PetChanger::AnimIdle
02d26d7c: bl      #0x2b7105c                                 fn_2b7105c
## .ctor() -> void
---- Decor.PetChanger::.ctor 0x2d26d80
02d26d80: mov     x1, xzr                                    
02d26d84: b       #0x5b397b0                                 UnityEngine.MonoBehaviour::.ctor
