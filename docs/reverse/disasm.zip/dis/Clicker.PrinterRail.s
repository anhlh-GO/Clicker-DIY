#### CLASS Clicker.PrinterRail/<>c parent= object
#   field <>9                            Clicker.PrinterRail/<>c                            off=0x0 attr=36 
#   field <>9__23_0                      System.Action                                      off=0x8 attr=16 
#   field <>9__25_0                      System.Action                                      off=0x10 attr=16 
## .cctor() -> void
---- Clicker.PrinterRail/<>c::.cctor 0x2d65b64
02d65b64: str     x30, [sp, #-0x20]!                         
02d65b68: stp     x20, x19, [sp, #0x10]                      
02d65b6c: adrp    x19, #0x6630000                            
02d65b70: adrp    x20, #0x626c000                            
02d65b74: ldrb    w8, [x19, #0x32d]                          
02d65b78: ldr     x20, [x20, #0x118]                         T:Clicker.PrinterRail/<>c
02d65b7c: tbnz    w8, #0, #0x2d65b94                         
02d65b80: adrp    x0, #0x626c000                             
02d65b84: ldr     x0, [x0, #0x118]                           T:Clicker.PrinterRail/<>c
02d65b88: bl      #0x2b70db0                                 fn_2b70db0
02d65b8c: mov     w8, #1                                     
02d65b90: strb    w8, [x19, #0x32d]                          
02d65b94: ldr     x0, [x20]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d65b98: bl      #0x2b7104c                                 fn_2b7104c
02d65b9c: mov     x1, xzr                                    
02d65ba0: mov     x19, x0                                    
02d65ba4: bl      #0x4e53e9c                                 System.Object::.ctor
02d65ba8: ldr     x8, [x20]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d65bac: mov     x1, x19                                    
02d65bb0: ldr     x8, [x8, #0xb8]                            
02d65bb4: str     x19, [x8]                                  
02d65bb8: ldr     x8, [x20]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d65bbc: ldp     x20, x19, [sp, #0x10]                      
02d65bc0: ldr     x0, [x8, #0xb8]                            
02d65bc4: ldr     x30, [sp], #0x20                           
02d65bc8: b       #0x2b70d54                                 
## .ctor() -> void
---- Clicker.PrinterRail/<>c::.ctor 0x2d65bcc
02d65bcc: mov     x1, xzr                                    
02d65bd0: b       #0x4e53e9c                                 System.Object::.ctor
## <TestMoveRail>b__23_0() -> void
---- Clicker.PrinterRail/<>c::<TestMoveRail>b__23_0 0x2d65bd4
02d65bd4: ret                                                
## <ResetAndSpeedUp>b__25_0() -> void
---- Clicker.PrinterRail/<>c::<ResetAndSpeedUp>b__25_0 0x2d65bd8
02d65bd8: ret                                                
#### CLASS Clicker.PrinterRail/<>c__DisplayClass26_0 parent= object
#   field onDone                         System.Action                                      off=0x10 attr=6 
## .ctor() -> void
---- Clicker.PrinterRail/<>c__DisplayClass26_0::.ctor 0x2d65470
02d65470: mov     x1, xzr                                    
02d65474: b       #0x4e53e9c                                 System.Object::.ctor
## <StartMoveRail>b__0() -> void
---- Clicker.PrinterRail/<>c__DisplayClass26_0::<StartMoveRail>b__0 0x2d65bdc
02d65bdc: ldr     x8, [x0, #0x10]                            .onDone
02d65be0: cbz     x8, #0x2d65bf4                             
02d65be4: ldr     x0, [x8, #0x40]                            
02d65be8: ldr     x1, [x8, #0x28]                            
02d65bec: ldr     x2, [x8, #0x18]                            
02d65bf0: br      x2                                         
02d65bf4: ret                                                
#### CLASS Clicker.PrinterRail/<>c__DisplayClass30_0 parent= object
#   field <>4__this                      Clicker.PrinterRail                                off=0x10 attr=6 
#   field onDone                         System.Action                                      off=0x18 attr=6 
## .ctor() -> void
---- Clicker.PrinterRail/<>c__DisplayClass30_0::.ctor 0x2d65998
02d65998: mov     x1, xzr                                    
02d6599c: b       #0x4e53e9c                                 System.Object::.ctor
## <MoveRailUpOneStep>b__0() -> void
---- Clicker.PrinterRail/<>c__DisplayClass30_0::<MoveRailUpOneStep>b__0 0x2d65bf8
02d65bf8: stp     x30, x19, [sp, #-0x10]!                    
02d65bfc: ldr     x8, [x0, #0x10]                            .<>4__this
02d65c00: cbz     x8, #0x2d65c58                             
02d65c04: mov     x19, x0                                    
02d65c08: ldr     x0, [x8, #0x28]                            
02d65c0c: cbz     x0, #0x2d65c58                             
02d65c10: mov     x1, xzr                                    
02d65c14: bl      #0x5b467ac                                 UnityEngine.Transform::get_position
02d65c18: ldr     x8, [x19, #0x10]                           .<>4__this
02d65c1c: cbz     x8, #0x2d65c58                             
02d65c20: ldr     s0, [x8, #0x5c]                            
02d65c24: fcmp    s1, s0                                     
02d65c28: b.lt    #0x2d65c34                                 
02d65c2c: mov     w9, #1                                     
02d65c30: strb    w9, [x8, #0x65]                            
02d65c34: ldr     x8, [x19, #0x18]                           .onDone
02d65c38: cbz     x8, #0x2d65c50                             
02d65c3c: ldr     x0, [x8, #0x40]                            
02d65c40: ldr     x1, [x8, #0x28]                            
02d65c44: ldr     x2, [x8, #0x18]                            
02d65c48: ldp     x30, x19, [sp], #0x10                      
02d65c4c: br      x2                                         
02d65c50: ldp     x30, x19, [sp], #0x10                      
02d65c54: ret                                                
02d65c58: bl      #0x2b7105c                                 fn_2b7105c
## <MoveRailUpOneStep>b__1() -> void
---- Clicker.PrinterRail/<>c__DisplayClass30_0::<MoveRailUpOneStep>b__1 0x2d65c5c
02d65c5c: stp     x30, x19, [sp, #-0x10]!                    
02d65c60: ldr     x19, [x0, #0x10]                           .<>4__this
02d65c64: cbz     x19, #0x2d65c7c                            
02d65c68: mov     x0, x19                                    
02d65c6c: bl      #0x2d64c54                                 Clicker.PrinterRail::get_Progress
02d65c70: str     s0, [x19, #0x60]                           
02d65c74: ldp     x30, x19, [sp], #0x10                      
02d65c78: ret                                                
02d65c7c: bl      #0x2b7105c                                 fn_2b7105c
#### CLASS Clicker.PrinterRail parent= UnityEngine.MonoBehaviour
#   field _tfHorizontalRail              UnityEngine.Transform                              off=0x20 attr=1 SerializeField
#   field _tfVerticalRail                UnityEngine.Transform                              off=0x28 attr=1 SerializeField
#   field _tfOffsetY                     UnityEngine.Transform                              off=0x30 attr=1 SerializeField
#   field _tfMaskHolder                  UnityEngine.Transform                              off=0x38 attr=1 HeaderAttribute,SerializeField
#   field _tfMaskLeft                    UnityEngine.Transform                              off=0x40 attr=1 SerializeField
#   field _tfMaskRight                   UnityEngine.Transform                              off=0x48 attr=1 SerializeField
#   field _minX                          float                                              off=0x50 attr=1 SerializeField
#   field _maxX                          float                                              off=0x54 attr=1 SerializeField
#   field _minY                          float                                              off=0x58 attr=1 SerializeField
#   field _maxY                          float                                              off=0x5c attr=1 SerializeField
#   field _progress                      float                                              off=0x60 attr=1 SerializeField,ReadOnlyAttribute
#   field _horizontalSpeed               float                                              off=0x0 attr=8051 
#   field _verticalSpeed                 float                                              off=0x0 attr=8051 
#   field _verticalStep                  float                                              off=0x0 attr=8051 
#   field _speedUpMultipler              float                                              off=0x0 attr=8051 
#   field _isSpeedUp                     bool                                               off=0x64 attr=1 
#   field _hasSignalStop                 bool                                               off=0x65 attr=1 
#   field _onRailMoveDoneEvent           UnityEngine.Events.UnityEvent                      off=0x68 attr=1 
## get_Progress() -> float
---- Clicker.PrinterRail::get_Progress 0x2d64c54
02d64c54: stp     d9, d8, [sp, #-0x20]!                      
02d64c58: str     x30, [sp, #0x10]                           
02d64c5c: mov     x8, x0                                     
02d64c60: ldr     x0, [x0, #0x28]                            ._tfVerticalRail
02d64c64: cbz     x0, #0x2d64cc0                             
02d64c68: ldp     s8, s9, [x8, #0x58]                        
02d64c6c: mov     x1, xzr                                    
02d64c70: bl      #0x5b467ac                                 UnityEngine.Transform::get_position
02d64c74: fcmp    s8, s9                                     
02d64c78: b.eq    #0x2d64cb0                                 
02d64c7c: fsub    s0, s1, s8                                 
02d64c80: fsub    s1, s9, s8                                 
02d64c84: mov     w8, #0x42c80000                            
02d64c88: fmov    s2, w8                                     
02d64c8c: fdiv    s0, s0, s1                                 
02d64c90: fmov    s1, #1.00000000                            
02d64c94: fcmp    s0, s1                                     
02d64c98: fcsel   s1, s1, s0, gt                             
02d64c9c: fcmp    s0, #0.0                                   
02d64ca0: fmul    s1, s1, s2                                 
02d64ca4: movi    d2, #0000000000000000                      
02d64ca8: fcsel   s0, s2, s1, mi                             
02d64cac: b       #0x2d64cb4                                 
02d64cb0: movi    d0, #0000000000000000                      
02d64cb4: ldr     x30, [sp, #0x10]                           
02d64cb8: ldp     d9, d8, [sp], #0x20                        
02d64cbc: ret                                                
02d64cc0: bl      #0x2b7105c                                 fn_2b7105c
## SetLimit(float minY, float maxY) -> void
---- Clicker.PrinterRail::SetLimit 0x2d64ff8
02d64ff8: stp     d9, d8, [sp, #-0x20]!                      
02d64ffc: stp     x30, x19, [sp, #0x10]                      
02d65000: mov     x19, x0                                    
02d65004: ldr     x0, [x0, #0x30]                            ._tfOffsetY
02d65008: cbz     x0, #0x2d65048                             
02d6500c: mov     x1, xzr                                    
02d65010: fmov    s8, s1                                     
02d65014: fmov    s9, s0                                     
02d65018: bl      #0x5b45c24                                 UnityEngine.Transform::get_localPosition
02d6501c: fsub    s0, s9, s1                                 
02d65020: ldr     x0, [x19, #0x30]                           ._tfOffsetY
02d65024: str     s0, [x19, #0x58]                           ._minY
02d65028: cbz     x0, #0x2d65048                             
02d6502c: mov     x1, xzr                                    
02d65030: bl      #0x5b45c24                                 UnityEngine.Transform::get_localPosition
02d65034: fsub    s0, s8, s1                                 
02d65038: str     s0, [x19, #0x5c]                           ._maxY
02d6503c: ldp     x30, x19, [sp, #0x10]                      
02d65040: ldp     d9, d8, [sp], #0x20                        
02d65044: ret                                                
02d65048: bl      #0x2b7105c                                 fn_2b7105c
## ResetRails() -> void
---- Clicker.PrinterRail::ResetRails 0x2d64a1c
02d64a1c: stp     x30, x19, [sp, #-0x10]!                    
02d64a20: mov     x19, x0                                    
02d64a24: ldr     x0, [x0, #0x20]                            ._tfHorizontalRail
02d64a28: mov     w1, wzr                                    
02d64a2c: mov     x2, xzr                                    
02d64a30: bl      #0x2d9d5d0                                 DG.Tweening.ShortcutExtensions::DOKill
02d64a34: movi    d1, #0000000000000000                      
02d64a38: ldr     x0, [x19, #0x20]                           ._tfHorizontalRail
02d64a3c: ldr     s0, [x19, #0x54]                           ._maxX
02d64a40: mov     w1, wzr                                    
02d64a44: mov     x2, xzr                                    
02d64a48: bl      #0x2d977b8                                 DG.Tweening.ShortcutExtensions::DOMoveX
02d64a4c: ldr     x0, [x19, #0x28]                           ._tfVerticalRail
02d64a50: mov     w1, wzr                                    
02d64a54: mov     x2, xzr                                    
02d64a58: bl      #0x2d9d5d0                                 DG.Tweening.ShortcutExtensions::DOKill
02d64a5c: movi    d1, #0000000000000000                      
02d64a60: ldr     x0, [x19, #0x28]                           ._tfVerticalRail
02d64a64: ldr     s0, [x19, #0x58]                           ._minY
02d64a68: mov     w1, wzr                                    
02d64a6c: mov     x2, xzr                                    
02d64a70: bl      #0x2d97988                                 DG.Tweening.ShortcutExtensions::DOMoveY
02d64a74: strb    wzr, [x19, #0x64]                          ._isSpeedUp
02d64a78: ldp     x30, x19, [sp], #0x10                      
02d64a7c: ret                                                
## StopMoveRail() -> void
---- Clicker.PrinterRail::StopMoveRail 0x2d65260
02d65260: stp     x30, x19, [sp, #-0x10]!                    
02d65264: mov     x19, x0                                    
02d65268: ldr     x0, [x0, #0x20]                            ._tfHorizontalRail
02d6526c: mov     w1, wzr                                    
02d65270: mov     x2, xzr                                    
02d65274: bl      #0x2d9d5d0                                 DG.Tweening.ShortcutExtensions::DOKill
02d65278: ldr     x0, [x19, #0x28]                           ._tfVerticalRail
02d6527c: mov     w1, wzr                                    
02d65280: mov     x2, xzr                                    
02d65284: ldp     x30, x19, [sp], #0x10                      
02d65288: b       #0x2d9d5d0                                 DG.Tweening.ShortcutExtensions::DOKill
## TestMoveRail() -> void
---- Clicker.PrinterRail::TestMoveRail 0x2d6528c
02d6528c: str     x30, [sp, #-0x30]!                         
02d65290: stp     x22, x21, [sp, #0x10]                      
02d65294: stp     x20, x19, [sp, #0x20]                      
02d65298: adrp    x20, #0x6630000                            
02d6529c: adrp    x22, #0x626c000                            
02d652a0: mov     x19, x0                                    
02d652a4: ldrb    w8, [x20, #0x324]                          
02d652a8: ldr     x22, [x22, #0x118]                         T:Clicker.PrinterRail/<>c
02d652ac: tbnz    w8, #0, #0x2d652dc                         
02d652b0: adrp    x0, #0x6264000                             
02d652b4: ldr     x0, [x0, #0xf90]                           T:System.Action
02d652b8: bl      #0x2b70db0                                 fn_2b70db0
02d652bc: adrp    x0, #0x626c000                             
02d652c0: ldr     x0, [x0, #0x120]                           M:Clicker.PrinterRail/<>c::<TestMoveRail>b__23_0
02d652c4: bl      #0x2b70db0                                 fn_2b70db0
02d652c8: adrp    x0, #0x626c000                             
02d652cc: ldr     x0, [x0, #0x118]                           T:Clicker.PrinterRail/<>c
02d652d0: bl      #0x2b70db0                                 fn_2b70db0
02d652d4: mov     w8, #1                                     
02d652d8: strb    w8, [x20, #0x324]                          
02d652dc: mov     x0, x19                                    
02d652e0: bl      #0x2d64a1c                                 Clicker.PrinterRail::ResetRails
02d652e4: ldr     x0, [x22]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d652e8: ldr     w8, [x0, #0xe4]                            [626c0e4]=0 f=0,0
02d652ec: cbnz    w8, #0x2d652f8                             
02d652f0: bl      #0x2b70f30                                 fn_2b70f30
02d652f4: ldr     x0, [x22]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d652f8: ldr     x8, [x0, #0xb8]                            MS:System.Collections.Generic.List`1::Add
02d652fc: ldr     x20, [x8, #8]                              
02d65300: cbnz    x20, #0x2d6535c                            
02d65304: ldr     w9, [x0, #0xe4]                            [626c0e4]=0 f=0,0
02d65308: cbnz    w9, #0x2d65318                             
02d6530c: bl      #0x2b70f30                                 fn_2b70f30
02d65310: ldr     x8, [x22]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d65314: ldr     x8, [x8, #0xb8]                            
02d65318: adrp    x9, #0x6264000                             
02d6531c: ldr     x9, [x9, #0xf90]                           T:System.Action
02d65320: ldr     x21, [x8]                                  
02d65324: ldr     x0, [x9]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d65328: bl      #0x2b7104c                                 fn_2b7104c
02d6532c: adrp    x8, #0x626c000                             
02d65330: mov     x1, x21                                    
02d65334: mov     x3, xzr                                    
02d65338: ldr     x8, [x8, #0x120]                           M:Clicker.PrinterRail/<>c::<TestMoveRail>b__23_0
02d6533c: mov     x20, x0                                    
02d65340: ldr     x2, [x8]                                   M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d65344: bl      #0x4d8ddbc                                 System.Action::.ctor
02d65348: ldr     x8, [x22]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d6534c: mov     x1, x20                                    
02d65350: ldr     x0, [x8, #0xb8]                            MS:System.Collections.Generic.List`1::Add
02d65354: str     x20, [x0, #8]!                             
02d65358: bl      #0x2b70d54                                 fn_2b70d54
02d6535c: cbz     x19, #0x2d65378                            
02d65360: mov     x0, x19                                    
02d65364: mov     x1, x20                                    
02d65368: ldp     x20, x19, [sp, #0x20]                      
02d6536c: ldp     x22, x21, [sp, #0x10]                      
02d65370: ldr     x30, [sp], #0x30                           
02d65374: b       #0x2d64a9c                                 Clicker.PrinterRail::StartMoveRail
02d65378: bl      #0x2b7105c                                 fn_2b7105c
## UpdateSpeed() -> void
---- Clicker.PrinterRail::UpdateSpeed 0x2d6537c
02d6537c: b       #0x2d64b84                                 Clicker.PrinterRail::SpeedUp
## ResetAndSpeedUp() -> void
---- Clicker.PrinterRail::ResetAndSpeedUp 0x2d65380
02d65380: str     x30, [sp, #-0x30]!                         
02d65384: stp     x22, x21, [sp, #0x10]                      
02d65388: stp     x20, x19, [sp, #0x20]                      
02d6538c: adrp    x20, #0x6630000                            
02d65390: adrp    x22, #0x626c000                            
02d65394: mov     x19, x0                                    
02d65398: ldrb    w8, [x20, #0x325]                          
02d6539c: ldr     x22, [x22, #0x118]                         T:Clicker.PrinterRail/<>c
02d653a0: tbnz    w8, #0, #0x2d653d0                         
02d653a4: adrp    x0, #0x6264000                             
02d653a8: ldr     x0, [x0, #0xf90]                           T:System.Action
02d653ac: bl      #0x2b70db0                                 fn_2b70db0
02d653b0: adrp    x0, #0x626c000                             
02d653b4: ldr     x0, [x0, #0x128]                           M:Clicker.PrinterRail/<>c::<ResetAndSpeedUp>b__25_0
02d653b8: bl      #0x2b70db0                                 fn_2b70db0
02d653bc: adrp    x0, #0x626c000                             
02d653c0: ldr     x0, [x0, #0x118]                           T:Clicker.PrinterRail/<>c
02d653c4: bl      #0x2b70db0                                 fn_2b70db0
02d653c8: mov     w8, #1                                     
02d653cc: strb    w8, [x20, #0x325]                          
02d653d0: mov     x0, x19                                    
02d653d4: bl      #0x2d64a1c                                 Clicker.PrinterRail::ResetRails
02d653d8: ldr     x0, [x22]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d653dc: mov     w9, #1                                     
02d653e0: strb    w9, [x19, #0x64]                           ._isSpeedUp
02d653e4: ldr     w8, [x0, #0xe4]                            [626c0e4]=0 f=0,0
02d653e8: cbnz    w8, #0x2d653f4                             
02d653ec: bl      #0x2b70f30                                 fn_2b70f30
02d653f0: ldr     x0, [x22]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d653f4: ldr     x8, [x0, #0xb8]                            MS:System.Collections.Generic.List`1::Add
02d653f8: ldr     x20, [x8, #0x10]                           
02d653fc: cbnz    x20, #0x2d65458                            
02d65400: ldr     w9, [x0, #0xe4]                            [626c0e4]=0 f=0,0
02d65404: cbnz    w9, #0x2d65414                             
02d65408: bl      #0x2b70f30                                 fn_2b70f30
02d6540c: ldr     x8, [x22]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d65410: ldr     x8, [x8, #0xb8]                            
02d65414: adrp    x9, #0x6264000                             
02d65418: ldr     x9, [x9, #0xf90]                           T:System.Action
02d6541c: ldr     x21, [x8]                                  
02d65420: ldr     x0, [x9]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d65424: bl      #0x2b7104c                                 fn_2b7104c
02d65428: adrp    x8, #0x626c000                             
02d6542c: mov     x1, x21                                    
02d65430: mov     x3, xzr                                    
02d65434: ldr     x8, [x8, #0x128]                           M:Clicker.PrinterRail/<>c::<ResetAndSpeedUp>b__25_0
02d65438: mov     x20, x0                                    
02d6543c: ldr     x2, [x8]                                   M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d65440: bl      #0x4d8ddbc                                 System.Action::.ctor
02d65444: ldr     x8, [x22]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d65448: mov     x1, x20                                    
02d6544c: ldr     x0, [x8, #0xb8]                            MS:System.Collections.Generic.List`1::Add
02d65450: str     x20, [x0, #0x10]!                          
02d65454: bl      #0x2b70d54                                 fn_2b70d54
02d65458: mov     x0, x19                                    
02d6545c: mov     x1, x20                                    
02d65460: ldp     x20, x19, [sp, #0x20]                      
02d65464: ldp     x22, x21, [sp, #0x10]                      
02d65468: ldr     x30, [sp], #0x30                           
02d6546c: b       #0x2d64a9c                                 Clicker.PrinterRail::StartMoveRail
## StartMoveRail(System.Action onDone) -> void
---- Clicker.PrinterRail::StartMoveRail 0x2d64a9c
02d64a9c: str     x30, [sp, #-0x30]!                         
02d64aa0: stp     x22, x21, [sp, #0x10]                      
02d64aa4: stp     x20, x19, [sp, #0x20]                      
02d64aa8: adrp    x21, #0x6630000                            
02d64aac: adrp    x22, #0x626c000                            
02d64ab0: mov     x20, x1                                    
02d64ab4: ldrb    w8, [x21, #0x326]                          
02d64ab8: ldr     x22, [x22, #0x100]                         T:Clicker.PrinterRail/<>c__DisplayClass26_0
02d64abc: mov     x19, x0                                    
02d64ac0: tbnz    w8, #0, #0x2d64af0                         
02d64ac4: adrp    x0, #0x626c000                             
02d64ac8: ldr     x0, [x0, #0x108]                           M:Clicker.PrinterRail/<>c__DisplayClass26_0::<StartMoveRail>b__0
02d64acc: bl      #0x2b70db0                                 fn_2b70db0
02d64ad0: adrp    x0, #0x626c000                             
02d64ad4: ldr     x0, [x0, #0x100]                           T:Clicker.PrinterRail/<>c__DisplayClass26_0
02d64ad8: bl      #0x2b70db0                                 fn_2b70db0
02d64adc: adrp    x0, #0x6265000                             
02d64ae0: ldr     x0, [x0, #0x3f0]                           T:UnityEngine.Events.UnityAction
02d64ae4: bl      #0x2b70db0                                 fn_2b70db0
02d64ae8: mov     w8, #1                                     
02d64aec: strb    w8, [x21, #0x326]                          
02d64af0: ldr     x0, [x22]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d64af4: bl      #0x2b7104c                                 fn_2b7104c
02d64af8: mov     x1, xzr                                    
02d64afc: mov     x21, x0                                    
02d64b00: bl      #0x4e53e9c                                 System.Object::.ctor
02d64b04: cbz     x21, #0x2d64b80                            
02d64b08: mov     x0, x21                                    
02d64b0c: mov     x1, x20                                    
02d64b10: str     x20, [x0, #0x10]!                          
02d64b14: bl      #0x2b70d54                                 fn_2b70d54
02d64b18: mov     x0, x19                                    
02d64b1c: bl      #0x2d65478                                 Clicker.PrinterRail::MoveRailLeft
02d64b20: ldr     x0, [x19, #0x68]                           ._onRailMoveDoneEvent
02d64b24: cbz     x0, #0x2d64b80                             
02d64b28: adrp    x20, #0x6265000                            
02d64b2c: adrp    x22, #0x626c000                            
02d64b30: mov     x1, xzr                                    
02d64b34: ldr     x20, [x20, #0x3f0]                         T:UnityEngine.Events.UnityAction
02d64b38: ldr     x22, [x22, #0x108]                         M:Clicker.PrinterRail/<>c__DisplayClass26_0::<StartMoveRail>b__0
02d64b3c: bl      #0x5b4ce48                                 UnityEngine.Events.UnityEventBase::RemoveAllListeners
02d64b40: ldr     x0, [x20]                                  M:AdsManager::<OnApplicationPause>b__26_0
02d64b44: ldr     x19, [x19, #0x68]                          ._onRailMoveDoneEvent
02d64b48: bl      #0x2b7104c                                 fn_2b7104c
02d64b4c: ldr     x2, [x22]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d64b50: mov     x1, x21                                    
02d64b54: mov     x3, xzr                                    
02d64b58: mov     x20, x0                                    
02d64b5c: bl      #0x5b4cf98                                 UnityEngine.Events.UnityAction::.ctor
02d64b60: cbz     x19, #0x2d64b80                            
02d64b64: mov     x0, x19                                    
02d64b68: mov     x1, x20                                    
02d64b6c: mov     x2, xzr                                    
02d64b70: ldp     x20, x19, [sp, #0x20]                      
02d64b74: ldp     x22, x21, [sp, #0x10]                      
02d64b78: ldr     x30, [sp], #0x30                           
02d64b7c: b       #0x5b4d0ac                                 UnityEngine.Events.UnityEvent::AddListener
02d64b80: bl      #0x2b7105c                                 fn_2b7105c
## SpeedUp() -> void
---- Clicker.PrinterRail::SpeedUp 0x2d64b84
02d64b84: stp     x30, x19, [sp, #-0x10]!                    
02d64b88: mov     x19, x0                                    
02d64b8c: ldr     x0, [x0, #0x20]                            ._tfHorizontalRail
02d64b90: mov     w1, wzr                                    
02d64b94: mov     x2, xzr                                    
02d64b98: bl      #0x2d9d5d0                                 DG.Tweening.ShortcutExtensions::DOKill
02d64b9c: ldr     x0, [x19, #0x28]                           ._tfVerticalRail
02d64ba0: mov     w1, wzr                                    
02d64ba4: mov     x2, xzr                                    
02d64ba8: bl      #0x2d9d5d0                                 DG.Tweening.ShortcutExtensions::DOKill
02d64bac: ldr     x0, [x19, #0x48]                           ._tfMaskRight
02d64bb0: mov     w1, wzr                                    
02d64bb4: mov     x2, xzr                                    
02d64bb8: bl      #0x2d9d5d0                                 DG.Tweening.ShortcutExtensions::DOKill
02d64bbc: ldr     x0, [x19, #0x40]                           ._tfMaskLeft
02d64bc0: mov     w1, wzr                                    
02d64bc4: mov     x2, xzr                                    
02d64bc8: bl      #0x2d9d5d0                                 DG.Tweening.ShortcutExtensions::DOKill
02d64bcc: mov     w8, #1                                     
02d64bd0: mov     x0, x19                                    
02d64bd4: strb    w8, [x19, #0x64]                           ._isSpeedUp
02d64bd8: ldp     x30, x19, [sp], #0x10                      
02d64bdc: b       #0x2d65478                                 Clicker.PrinterRail::MoveRailLeft
## MoveRailLeft() -> void
---- Clicker.PrinterRail::MoveRailLeft 0x2d65478
02d65478: stp     d9, d8, [sp, #-0x50]!                      
02d6547c: stp     x30, x25, [sp, #0x10]                      
02d65480: stp     x24, x23, [sp, #0x20]                      
02d65484: stp     x22, x21, [sp, #0x30]                      
02d65488: stp     x20, x19, [sp, #0x40]                      
02d6548c: adrp    x20, #0x6630000                            
02d65490: mov     x19, x0                                    
02d65494: ldrb    w8, [x20, #0x327]                          
02d65498: tbnz    w8, #0, #0x2d654e0                         
02d6549c: adrp    x0, #0x626c000                             
02d654a0: ldr     x0, [x0, #0x130]                           M:Clicker.PrinterRail::<MoveRailLeft>b__28_0
02d654a4: bl      #0x2b70db0                                 fn_2b70db0
02d654a8: adrp    x0, #0x6264000                             
02d654ac: ldr     x0, [x0, #0xe8]                            T:DG.Tweening.TweenCallback
02d654b0: bl      #0x2b70db0                                 fn_2b70db0
02d654b4: adrp    x0, #0x6266000                             
02d654b8: ldr     x0, [x0, #0x928]                           MS:DG.Tweening.TweenSettingsExtensions::OnComplete
02d654bc: bl      #0x2b70db0                                 fn_2b70db0
02d654c0: adrp    x0, #0x6266000                             
02d654c4: ldr     x0, [x0, #0x880]                           MS:DG.Tweening.TweenSettingsExtensions::SetEase
02d654c8: bl      #0x2b70db0                                 fn_2b70db0
02d654cc: adrp    x0, #0x626a000                             
02d654d0: ldr     x0, [x0, #0xd08]                           MS:DG.Tweening.TweenSettingsExtensions::SetSpeedBased
02d654d4: bl      #0x2b70db0                                 fn_2b70db0
02d654d8: mov     w8, #1                                     
02d654dc: strb    w8, [x20, #0x327]                          
02d654e0: ldr     x0, [x19, #0x38]                           ._tfMaskHolder
02d654e4: cbz     x0, #0x2d6560c                             
02d654e8: adrp    x25, #0x626a000                            
02d654ec: adrp    x24, #0x6266000                            
02d654f0: adrp    x23, #0x6264000                            
02d654f4: adrp    x21, #0x626c000                            
02d654f8: adrp    x22, #0x6266000                            
02d654fc: ldr     x25, [x25, #0xd08]                         MS:DG.Tweening.TweenSettingsExtensions::SetSpeedBased
02d65500: ldr     x24, [x24, #0x880]                         MS:DG.Tweening.TweenSettingsExtensions::SetEase
02d65504: ldr     x23, [x23, #0xe8]                          T:DG.Tweening.TweenCallback
02d65508: ldr     x21, [x21, #0x130]                         M:Clicker.PrinterRail::<MoveRailLeft>b__28_0
02d6550c: ldr     x22, [x22, #0x928]                         MS:DG.Tweening.TweenSettingsExtensions::OnComplete
02d65510: ldr     x20, [x19, #0x40]                          ._tfMaskLeft
02d65514: mov     x1, xzr                                    
02d65518: bl      #0x5b467ac                                 UnityEngine.Transform::get_position
02d6551c: fmov    s0, s1                                     
02d65520: movi    d1, #0000000000000000                      
02d65524: mov     x0, x20                                    
02d65528: mov     w1, wzr                                    
02d6552c: mov     x2, xzr                                    
02d65530: bl      #0x2d97988                                 DG.Tweening.ShortcutExtensions::DOMoveY
02d65534: movi    d1, #0000000000000000                      
02d65538: ldr     x0, [x19, #0x40]                           ._tfMaskLeft
02d6553c: ldr     s0, [x19, #0x54]                           ._maxX
02d65540: mov     w1, wzr                                    
02d65544: mov     x2, xzr                                    
02d65548: bl      #0x2d977b8                                 DG.Tweening.ShortcutExtensions::DOMoveX
02d6554c: ldrb    w8, [x19, #0x64]                           ._isSpeedUp
02d65550: fmov    s8, #20.00000000                           
02d65554: fmov    s9, #2.00000000                            
02d65558: ldr     x0, [x19, #0x40]                           ._tfMaskLeft
02d6555c: ldr     s0, [x19, #0x50]                           ._minX
02d65560: mov     w1, wzr                                    
02d65564: cmp     w8, #0                                     
02d65568: mov     x2, xzr                                    
02d6556c: fcsel   s1, s9, s8, eq                             
02d65570: bl      #0x2d977b8                                 DG.Tweening.ShortcutExtensions::DOMoveX
02d65574: ldr     x2, [x25]                                  T:type56879(k15)
02d65578: mov     w1, #1                                     
02d6557c: bl      #0x336ff88                                 fn_336ff88
02d65580: ldr     x2, [x24]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d65584: mov     w1, #1                                     
02d65588: bl      #0x336fa0c                                 fn_336fa0c
02d6558c: ldrb    w8, [x19, #0x64]                           ._isSpeedUp
02d65590: ldr     x0, [x19, #0x20]                           ._tfHorizontalRail
02d65594: mov     w1, wzr                                    
02d65598: ldr     s0, [x19, #0x50]                           ._minX
02d6559c: mov     x2, xzr                                    
02d655a0: cmp     w8, #0                                     
02d655a4: fcsel   s1, s9, s8, eq                             
02d655a8: bl      #0x2d977b8                                 DG.Tweening.ShortcutExtensions::DOMoveX
02d655ac: ldr     x2, [x25]                                  T:type56879(k15)
02d655b0: mov     w1, #1                                     
02d655b4: bl      #0x336ff88                                 fn_336ff88
02d655b8: ldr     x2, [x24]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d655bc: mov     w1, #1                                     
02d655c0: bl      #0x336fa0c                                 fn_336fa0c
02d655c4: ldr     x8, [x23]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d655c8: mov     x20, x0                                    
02d655cc: mov     x0, x8                                     
02d655d0: bl      #0x2b7104c                                 fn_2b7104c
02d655d4: ldr     x2, [x21]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d655d8: mov     x1, x19                                    
02d655dc: mov     x3, xzr                                    
02d655e0: mov     x21, x0                                    
02d655e4: bl      #0x2d89dc4                                 DG.Tweening.TweenCallback::.ctor
02d655e8: ldr     x2, [x22]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d655ec: mov     x0, x20                                    
02d655f0: mov     x1, x21                                    
02d655f4: ldp     x20, x19, [sp, #0x40]                      
02d655f8: ldp     x22, x21, [sp, #0x30]                      
02d655fc: ldp     x24, x23, [sp, #0x20]                      
02d65600: ldp     x30, x25, [sp, #0x10]                      
02d65604: ldp     d9, d8, [sp], #0x50                        
02d65608: b       #0x336f26c                                 
02d6560c: bl      #0x2b7105c                                 fn_2b7105c
## MoveRailRight() -> void
---- Clicker.PrinterRail::MoveRailRight 0x2d65610
02d65610: stp     d9, d8, [sp, #-0x50]!                      
02d65614: stp     x30, x25, [sp, #0x10]                      
02d65618: stp     x24, x23, [sp, #0x20]                      
02d6561c: stp     x22, x21, [sp, #0x30]                      
02d65620: stp     x20, x19, [sp, #0x40]                      
02d65624: adrp    x20, #0x6630000                            
02d65628: mov     x19, x0                                    
02d6562c: ldrb    w8, [x20, #0x328]                          
02d65630: tbnz    w8, #0, #0x2d65678                         
02d65634: adrp    x0, #0x626c000                             
02d65638: ldr     x0, [x0, #0x138]                           M:Clicker.PrinterRail::<MoveRailRight>b__29_0
02d6563c: bl      #0x2b70db0                                 fn_2b70db0
02d65640: adrp    x0, #0x6264000                             
02d65644: ldr     x0, [x0, #0xe8]                            T:DG.Tweening.TweenCallback
02d65648: bl      #0x2b70db0                                 fn_2b70db0
02d6564c: adrp    x0, #0x6266000                             
02d65650: ldr     x0, [x0, #0x928]                           MS:DG.Tweening.TweenSettingsExtensions::OnComplete
02d65654: bl      #0x2b70db0                                 fn_2b70db0
02d65658: adrp    x0, #0x6266000                             
02d6565c: ldr     x0, [x0, #0x880]                           MS:DG.Tweening.TweenSettingsExtensions::SetEase
02d65660: bl      #0x2b70db0                                 fn_2b70db0
02d65664: adrp    x0, #0x626a000                             
02d65668: ldr     x0, [x0, #0xd08]                           MS:DG.Tweening.TweenSettingsExtensions::SetSpeedBased
02d6566c: bl      #0x2b70db0                                 fn_2b70db0
02d65670: mov     w8, #1                                     
02d65674: strb    w8, [x20, #0x328]                          
02d65678: ldr     x0, [x19, #0x38]                           ._tfMaskHolder
02d6567c: cbz     x0, #0x2d657a4                             
02d65680: adrp    x25, #0x626a000                            
02d65684: adrp    x24, #0x6266000                            
02d65688: adrp    x23, #0x6264000                            
02d6568c: adrp    x21, #0x626c000                            
02d65690: adrp    x22, #0x6266000                            
02d65694: ldr     x25, [x25, #0xd08]                         MS:DG.Tweening.TweenSettingsExtensions::SetSpeedBased
02d65698: ldr     x24, [x24, #0x880]                         MS:DG.Tweening.TweenSettingsExtensions::SetEase
02d6569c: ldr     x23, [x23, #0xe8]                          T:DG.Tweening.TweenCallback
02d656a0: ldr     x21, [x21, #0x138]                         M:Clicker.PrinterRail::<MoveRailRight>b__29_0
02d656a4: ldr     x22, [x22, #0x928]                         MS:DG.Tweening.TweenSettingsExtensions::OnComplete
02d656a8: ldr     x20, [x19, #0x48]                          ._tfMaskRight
02d656ac: mov     x1, xzr                                    
02d656b0: bl      #0x5b467ac                                 UnityEngine.Transform::get_position
02d656b4: fmov    s0, s1                                     
02d656b8: movi    d1, #0000000000000000                      
02d656bc: mov     x0, x20                                    
02d656c0: mov     w1, wzr                                    
02d656c4: mov     x2, xzr                                    
02d656c8: bl      #0x2d97988                                 DG.Tweening.ShortcutExtensions::DOMoveY
02d656cc: movi    d1, #0000000000000000                      
02d656d0: ldr     x0, [x19, #0x48]                           ._tfMaskRight
02d656d4: ldr     s0, [x19, #0x50]                           ._minX
02d656d8: mov     w1, wzr                                    
02d656dc: mov     x2, xzr                                    
02d656e0: bl      #0x2d977b8                                 DG.Tweening.ShortcutExtensions::DOMoveX
02d656e4: ldrb    w8, [x19, #0x64]                           ._isSpeedUp
02d656e8: fmov    s8, #20.00000000                           
02d656ec: fmov    s9, #2.00000000                            
02d656f0: ldr     x0, [x19, #0x48]                           ._tfMaskRight
02d656f4: ldr     s0, [x19, #0x54]                           ._maxX
02d656f8: mov     w1, wzr                                    
02d656fc: cmp     w8, #0                                     
02d65700: mov     x2, xzr                                    
02d65704: fcsel   s1, s9, s8, eq                             
02d65708: bl      #0x2d977b8                                 DG.Tweening.ShortcutExtensions::DOMoveX
02d6570c: ldr     x2, [x25]                                  T:type56879(k15)
02d65710: mov     w1, #1                                     
02d65714: bl      #0x336ff88                                 fn_336ff88
02d65718: ldr     x2, [x24]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d6571c: mov     w1, #1                                     
02d65720: bl      #0x336fa0c                                 fn_336fa0c
02d65724: ldrb    w8, [x19, #0x64]                           ._isSpeedUp
02d65728: ldr     x0, [x19, #0x20]                           ._tfHorizontalRail
02d6572c: mov     w1, wzr                                    
02d65730: ldr     s0, [x19, #0x54]                           ._maxX
02d65734: mov     x2, xzr                                    
02d65738: cmp     w8, #0                                     
02d6573c: fcsel   s1, s9, s8, eq                             
02d65740: bl      #0x2d977b8                                 DG.Tweening.ShortcutExtensions::DOMoveX
02d65744: ldr     x2, [x25]                                  T:type56879(k15)
02d65748: mov     w1, #1                                     
02d6574c: bl      #0x336ff88                                 fn_336ff88
02d65750: ldr     x2, [x24]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d65754: mov     w1, #1                                     
02d65758: bl      #0x336fa0c                                 fn_336fa0c
02d6575c: ldr     x8, [x23]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d65760: mov     x20, x0                                    
02d65764: mov     x0, x8                                     
02d65768: bl      #0x2b7104c                                 fn_2b7104c
02d6576c: ldr     x2, [x21]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d65770: mov     x1, x19                                    
02d65774: mov     x3, xzr                                    
02d65778: mov     x21, x0                                    
02d6577c: bl      #0x2d89dc4                                 DG.Tweening.TweenCallback::.ctor
02d65780: ldr     x2, [x22]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d65784: mov     x0, x20                                    
02d65788: mov     x1, x21                                    
02d6578c: ldp     x20, x19, [sp, #0x40]                      
02d65790: ldp     x22, x21, [sp, #0x30]                      
02d65794: ldp     x24, x23, [sp, #0x20]                      
02d65798: ldp     x30, x25, [sp, #0x10]                      
02d6579c: ldp     d9, d8, [sp], #0x50                        
02d657a0: b       #0x336f26c                                 
02d657a4: bl      #0x2b7105c                                 fn_2b7105c
## MoveRailUpOneStep(System.Action onDone) -> void
---- Clicker.PrinterRail::MoveRailUpOneStep 0x2d657a8
02d657a8: str     x30, [sp, #-0x60]!                         
02d657ac: stp     x28, x27, [sp, #0x10]                      
02d657b0: stp     x26, x25, [sp, #0x20]                      
02d657b4: stp     x24, x23, [sp, #0x30]                      
02d657b8: stp     x22, x21, [sp, #0x40]                      
02d657bc: stp     x20, x19, [sp, #0x50]                      
02d657c0: adrp    x19, #0x6630000                            
02d657c4: adrp    x22, #0x626c000                            
02d657c8: mov     x21, x1                                    
02d657cc: ldrb    w8, [x19, #0x329]                          
02d657d0: ldr     x22, [x22, #0x140]                         T:Clicker.PrinterRail/<>c__DisplayClass30_0
02d657d4: mov     x20, x0                                    
02d657d8: tbnz    w8, #0, #0x2d65844                         
02d657dc: adrp    x0, #0x6264000                             
02d657e0: ldr     x0, [x0, #0xe8]                            T:DG.Tweening.TweenCallback
02d657e4: bl      #0x2b70db0                                 fn_2b70db0
02d657e8: adrp    x0, #0x6266000                             
02d657ec: ldr     x0, [x0, #0x928]                           MS:DG.Tweening.TweenSettingsExtensions::OnComplete
02d657f0: bl      #0x2b70db0                                 fn_2b70db0
02d657f4: adrp    x0, #0x626c000                             
02d657f8: ldr     x0, [x0, #0x148]                           MS:DG.Tweening.TweenSettingsExtensions::OnUpdate
02d657fc: bl      #0x2b70db0                                 fn_2b70db0
02d65800: adrp    x0, #0x6266000                             
02d65804: ldr     x0, [x0, #0x880]                           MS:DG.Tweening.TweenSettingsExtensions::SetEase
02d65808: bl      #0x2b70db0                                 fn_2b70db0
02d6580c: adrp    x0, #0x626a000                             
02d65810: ldr     x0, [x0, #0xd08]                           MS:DG.Tweening.TweenSettingsExtensions::SetSpeedBased
02d65814: bl      #0x2b70db0                                 fn_2b70db0
02d65818: adrp    x0, #0x626c000                             
02d6581c: ldr     x0, [x0, #0x150]                           M:Clicker.PrinterRail/<>c__DisplayClass30_0::<MoveRailUpOneStep>b__0
02d65820: bl      #0x2b70db0                                 fn_2b70db0
02d65824: adrp    x0, #0x626c000                             
02d65828: ldr     x0, [x0, #0x158]                           M:Clicker.PrinterRail/<>c__DisplayClass30_0::<MoveRailUpOneStep>b__1
02d6582c: bl      #0x2b70db0                                 fn_2b70db0
02d65830: adrp    x0, #0x626c000                             
02d65834: ldr     x0, [x0, #0x140]                           T:Clicker.PrinterRail/<>c__DisplayClass30_0
02d65838: bl      #0x2b70db0                                 fn_2b70db0
02d6583c: mov     w8, #1                                     
02d65840: strb    w8, [x19, #0x329]                          
02d65844: ldr     x0, [x22]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d65848: bl      #0x2b7104c                                 fn_2b7104c
02d6584c: mov     x1, xzr                                    
02d65850: mov     x19, x0                                    
02d65854: bl      #0x4e53e9c                                 System.Object::.ctor
02d65858: cbz     x19, #0x2d65994                            
02d6585c: mov     x0, x19                                    
02d65860: mov     x1, x20                                    
02d65864: str     x20, [x0, #0x10]!                          
02d65868: bl      #0x2b70d54                                 fn_2b70d54
02d6586c: mov     x0, x19                                    
02d65870: mov     x1, x21                                    
02d65874: str     x21, [x0, #0x18]!                          
02d65878: bl      #0x2b70d54                                 fn_2b70d54
02d6587c: ldr     x21, [x20, #0x28]                          ._tfVerticalRail
02d65880: cbz     x21, #0x2d65994                            
02d65884: adrp    x26, #0x626a000                            
02d65888: adrp    x27, #0x6266000                            
02d6588c: adrp    x24, #0x6264000                            
02d65890: adrp    x28, #0x626c000                            
02d65894: adrp    x25, #0x6266000                            
02d65898: adrp    x23, #0x626c000                            
02d6589c: adrp    x22, #0x626c000                            
02d658a0: ldr     x26, [x26, #0xd08]                         MS:DG.Tweening.TweenSettingsExtensions::SetSpeedBased
02d658a4: ldr     x27, [x27, #0x880]                         MS:DG.Tweening.TweenSettingsExtensions::SetEase
02d658a8: ldr     x24, [x24, #0xe8]                          T:DG.Tweening.TweenCallback
02d658ac: ldr     x28, [x28, #0x150]                         M:Clicker.PrinterRail/<>c__DisplayClass30_0::<MoveRailUpOneStep>b__0
02d658b0: ldr     x25, [x25, #0x928]                         MS:DG.Tweening.TweenSettingsExtensions::OnComplete
02d658b4: ldr     x23, [x23, #0x158]                         M:Clicker.PrinterRail/<>c__DisplayClass30_0::<MoveRailUpOneStep>b__1
02d658b8: ldr     x22, [x22, #0x148]                         MS:DG.Tweening.TweenSettingsExtensions::OnUpdate
02d658bc: mov     x0, x21                                    
02d658c0: mov     x1, xzr                                    
02d658c4: bl      #0x5b467ac                                 UnityEngine.Transform::get_position
02d658c8: ldrb    w8, [x20, #0x64]                           ._isSpeedUp
02d658cc: fmov    s0, #10.00000000                           
02d658d0: fmov    s2, #1.00000000                            
02d658d4: adrp    x9, #0x1084000                             
02d658d8: mov     x0, x21                                    
02d658dc: mov     w1, wzr                                    
02d658e0: cmp     w8, #0                                     
02d658e4: ldr     s3, [x9, #0xdd8]                           [1084dd8]=3f7333333e4ccccd f=0.2,0.95
02d658e8: mov     x2, xzr                                    
02d658ec: fcsel   s2, s2, s0, eq                             
02d658f0: fadd    s0, s1, s3                                 
02d658f4: fmov    s1, s2                                     
02d658f8: bl      #0x2d97988                                 DG.Tweening.ShortcutExtensions::DOMoveY
02d658fc: ldr     x2, [x26]                                  T:type56879(k15)
02d65900: mov     w1, #1                                     
02d65904: bl      #0x336ff88                                 fn_336ff88
02d65908: ldr     x2, [x27]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d6590c: mov     w1, #1                                     
02d65910: bl      #0x336fa0c                                 fn_336fa0c
02d65914: ldr     x8, [x24]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d65918: mov     x20, x0                                    
02d6591c: mov     x0, x8                                     
02d65920: bl      #0x2b7104c                                 fn_2b7104c
02d65924: ldr     x2, [x28]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d65928: mov     x1, x19                                    
02d6592c: mov     x3, xzr                                    
02d65930: mov     x21, x0                                    
02d65934: bl      #0x2d89dc4                                 DG.Tweening.TweenCallback::.ctor
02d65938: ldr     x2, [x25]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d6593c: mov     x0, x20                                    
02d65940: mov     x1, x21                                    
02d65944: bl      #0x336f26c                                 fn_336f26c
02d65948: ldr     x8, [x24]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d6594c: mov     x20, x0                                    
02d65950: mov     x0, x8                                     
02d65954: bl      #0x2b7104c                                 fn_2b7104c
02d65958: ldr     x2, [x23]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d6595c: mov     x1, x19                                    
02d65960: mov     x3, xzr                                    
02d65964: mov     x21, x0                                    
02d65968: bl      #0x2d89dc4                                 DG.Tweening.TweenCallback::.ctor
02d6596c: ldr     x2, [x22]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d65970: mov     x0, x20                                    
02d65974: mov     x1, x21                                    
02d65978: ldp     x20, x19, [sp, #0x50]                      
02d6597c: ldp     x22, x21, [sp, #0x40]                      
02d65980: ldp     x24, x23, [sp, #0x30]                      
02d65984: ldp     x26, x25, [sp, #0x20]                      
02d65988: ldp     x28, x27, [sp, #0x10]                      
02d6598c: ldr     x30, [sp], #0x60                           
02d65990: b       #0x336f3a0                                 
02d65994: bl      #0x2b7105c                                 fn_2b7105c
## .ctor() -> void
---- Clicker.PrinterRail::.ctor 0x2d659a0
02d659a0: stp     x30, x21, [sp, #-0x20]!                    
02d659a4: stp     x20, x19, [sp, #0x10]                      
02d659a8: adrp    x20, #0x6630000                            
02d659ac: adrp    x21, #0x6267000                            
02d659b0: mov     x19, x0                                    
02d659b4: ldrb    w8, [x20, #0x32a]                          
02d659b8: ldr     x21, [x21, #0xff0]                         T:UnityEngine.Events.UnityEvent
02d659bc: tbnz    w8, #0, #0x2d659d4                         
02d659c0: adrp    x0, #0x6267000                             
02d659c4: ldr     x0, [x0, #0xff0]                           T:UnityEngine.Events.UnityEvent
02d659c8: bl      #0x2b70db0                                 fn_2b70db0
02d659cc: mov     w8, #1                                     
02d659d0: strb    w8, [x20, #0x32a]                          
02d659d4: ldr     x0, [x21]                                  S:'didu'
02d659d8: bl      #0x2b7104c                                 fn_2b7104c
02d659dc: mov     x1, xzr                                    
02d659e0: mov     x20, x0                                    
02d659e4: bl      #0x5b4d048                                 UnityEngine.Events.UnityEvent::.ctor
02d659e8: mov     x0, x19                                    
02d659ec: mov     x1, x20                                    
02d659f0: str     x20, [x0, #0x68]!                          ._onRailMoveDoneEvent
02d659f4: bl      #0x2b70d54                                 fn_2b70d54
02d659f8: mov     x0, x19                                    
02d659fc: ldp     x20, x19, [sp, #0x10]                      
02d65a00: mov     x1, xzr                                    
02d65a04: ldp     x30, x21, [sp], #0x20                      
02d65a08: b       #0x5b397b0                                 UnityEngine.MonoBehaviour::.ctor
## <MoveRailLeft>b__28_0() -> void
---- Clicker.PrinterRail::<MoveRailLeft>b__28_0 0x2d65a0c
02d65a0c: str     x30, [sp, #-0x30]!                         
02d65a10: stp     x22, x21, [sp, #0x10]                      
02d65a14: stp     x20, x19, [sp, #0x20]                      
02d65a18: adrp    x21, #0x6630000                            
02d65a1c: adrp    x22, #0x6264000                            
02d65a20: adrp    x20, #0x626c000                            
02d65a24: ldrb    w8, [x21, #0x32b]                          
02d65a28: ldr     x22, [x22, #0xf90]                         T:System.Action
02d65a2c: ldr     x20, [x20, #0x160]                         M:Clicker.PrinterRail::<MoveRailLeft>b__28_1
02d65a30: mov     x19, x0                                    
02d65a34: tbnz    w8, #0, #0x2d65a58                         
02d65a38: adrp    x0, #0x6264000                             
02d65a3c: ldr     x0, [x0, #0xf90]                           T:System.Action
02d65a40: bl      #0x2b70db0                                 fn_2b70db0
02d65a44: adrp    x0, #0x626c000                             
02d65a48: ldr     x0, [x0, #0x160]                           M:Clicker.PrinterRail::<MoveRailLeft>b__28_1
02d65a4c: bl      #0x2b70db0                                 fn_2b70db0
02d65a50: mov     w8, #1                                     
02d65a54: strb    w8, [x21, #0x32b]                          
02d65a58: ldr     x0, [x22]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d65a5c: bl      #0x2b7104c                                 fn_2b7104c
02d65a60: ldr     x2, [x20]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d65a64: mov     x1, x19                                    
02d65a68: mov     x3, xzr                                    
02d65a6c: mov     x20, x0                                    
02d65a70: bl      #0x4d8ddbc                                 System.Action::.ctor
02d65a74: mov     x0, x19                                    
02d65a78: mov     x1, x20                                    
02d65a7c: ldp     x20, x19, [sp, #0x20]                      
02d65a80: ldp     x22, x21, [sp, #0x10]                      
02d65a84: ldr     x30, [sp], #0x30                           
02d65a88: b       #0x2d657a8                                 Clicker.PrinterRail::MoveRailUpOneStep
## <MoveRailLeft>b__28_1() -> void
---- Clicker.PrinterRail::<MoveRailLeft>b__28_1 0x2d65a8c
02d65a8c: ldrb    w8, [x0, #0x65]                            ._hasSignalStop
02d65a90: cbz     w8, #0x2d65aac                             
02d65a94: ldr     x8, [x0, #0x68]                            ._onRailMoveDoneEvent
02d65a98: strb    wzr, [x0, #0x65]                           ._hasSignalStop
02d65a9c: cbz     x8, #0x2d65ab0                             
02d65aa0: mov     x0, x8                                     
02d65aa4: mov     x1, xzr                                    
02d65aa8: b       #0x5b4d278                                 UnityEngine.Events.UnityEvent::Invoke
02d65aac: b       #0x2d65610                                 Clicker.PrinterRail::MoveRailRight
02d65ab0: str     x30, [sp, #-0x10]!                         
02d65ab4: bl      #0x2b7105c                                 fn_2b7105c
## <MoveRailRight>b__29_0() -> void
---- Clicker.PrinterRail::<MoveRailRight>b__29_0 0x2d65ab8
02d65ab8: str     x30, [sp, #-0x30]!                         
02d65abc: stp     x22, x21, [sp, #0x10]                      
02d65ac0: stp     x20, x19, [sp, #0x20]                      
02d65ac4: adrp    x21, #0x6630000                            
02d65ac8: adrp    x22, #0x6264000                            
02d65acc: adrp    x20, #0x626c000                            
02d65ad0: ldrb    w8, [x21, #0x32c]                          
02d65ad4: ldr     x22, [x22, #0xf90]                         T:System.Action
02d65ad8: ldr     x20, [x20, #0x168]                         M:Clicker.PrinterRail::<MoveRailRight>b__29_1
02d65adc: mov     x19, x0                                    
02d65ae0: tbnz    w8, #0, #0x2d65b04                         
02d65ae4: adrp    x0, #0x6264000                             
02d65ae8: ldr     x0, [x0, #0xf90]                           T:System.Action
02d65aec: bl      #0x2b70db0                                 fn_2b70db0
02d65af0: adrp    x0, #0x626c000                             
02d65af4: ldr     x0, [x0, #0x168]                           M:Clicker.PrinterRail::<MoveRailRight>b__29_1
02d65af8: bl      #0x2b70db0                                 fn_2b70db0
02d65afc: mov     w8, #1                                     
02d65b00: strb    w8, [x21, #0x32c]                          
02d65b04: ldr     x0, [x22]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d65b08: bl      #0x2b7104c                                 fn_2b7104c
02d65b0c: ldr     x2, [x20]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d65b10: mov     x1, x19                                    
02d65b14: mov     x3, xzr                                    
02d65b18: mov     x20, x0                                    
02d65b1c: bl      #0x4d8ddbc                                 System.Action::.ctor
02d65b20: mov     x0, x19                                    
02d65b24: mov     x1, x20                                    
02d65b28: ldp     x20, x19, [sp, #0x20]                      
02d65b2c: ldp     x22, x21, [sp, #0x10]                      
02d65b30: ldr     x30, [sp], #0x30                           
02d65b34: b       #0x2d657a8                                 Clicker.PrinterRail::MoveRailUpOneStep
## <MoveRailRight>b__29_1() -> void
---- Clicker.PrinterRail::<MoveRailRight>b__29_1 0x2d65b38
02d65b38: ldrb    w8, [x0, #0x65]                            ._hasSignalStop
02d65b3c: cbz     w8, #0x2d65b58                             
02d65b40: ldr     x8, [x0, #0x68]                            ._onRailMoveDoneEvent
02d65b44: strb    wzr, [x0, #0x65]                           ._hasSignalStop
02d65b48: cbz     x8, #0x2d65b5c                             
02d65b4c: mov     x0, x8                                     
02d65b50: mov     x1, xzr                                    
02d65b54: b       #0x5b4d278                                 UnityEngine.Events.UnityEvent::Invoke
02d65b58: b       #0x2d65478                                 Clicker.PrinterRail::MoveRailLeft
02d65b5c: str     x30, [sp, #-0x10]!                         
02d65b60: bl      #0x2b7105c                                 fn_2b7105c
