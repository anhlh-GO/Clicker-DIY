#### CLASS SceneNames parent= int
#   field value__                        int                                                off=0x10 attr=606 
#   field Loading                        SceneNames                                         off=0x0 attr=8056 
#   field Home                           SceneNames                                         off=0x0 attr=8056 
#   field ModeClicker                    SceneNames                                         off=0x0 attr=8056 
