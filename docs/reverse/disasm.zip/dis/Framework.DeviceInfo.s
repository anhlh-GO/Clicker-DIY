#### CLASS Framework.DeviceInfo parent= object
#   field _deviceUDID                    string                                             off=0x0 attr=11 
## get_IsTallPhone() -> bool
---- Framework.DeviceInfo::get_IsTallPhone 0x2cbe858
02cbe858: stp     x30, x19, [sp, #-0x10]!                    
02cbe85c: mov     x0, xzr                                    
02cbe860: bl      #0x5afb724                                 UnityEngine.Screen::get_height
02cbe864: mov     w19, w0                                    
02cbe868: mov     x0, xzr                                    
02cbe86c: bl      #0x5afb6fc                                 UnityEngine.Screen::get_width
02cbe870: cmp     w19, w0                                    
02cbe874: b.le    #0x2cbe890                                 
02cbe878: mov     x0, xzr                                    
02cbe87c: bl      #0x5afb724                                 UnityEngine.Screen::get_height
02cbe880: mov     w19, w0                                    
02cbe884: mov     x0, xzr                                    
02cbe888: bl      #0x5afb6fc                                 UnityEngine.Screen::get_width
02cbe88c: b       #0x2cbe8a4                                 
02cbe890: mov     x0, xzr                                    
02cbe894: bl      #0x5afb6fc                                 UnityEngine.Screen::get_width
02cbe898: mov     w19, w0                                    
02cbe89c: mov     x0, xzr                                    
02cbe8a0: bl      #0x5afb724                                 UnityEngine.Screen::get_height
02cbe8a4: scvtf   s0, w19                                    
02cbe8a8: scvtf   s1, w0                                     
02cbe8ac: fdiv    s0, s0, s1                                 
02cbe8b0: fmov    s1, #2.00000000                            
02cbe8b4: fcmp    s0, s1                                     
02cbe8b8: cset    w0, ge                                     
02cbe8bc: ldp     x30, x19, [sp], #0x10                      
02cbe8c0: ret                                                
## get_IsIpad() -> bool
---- Framework.DeviceInfo::get_IsIpad 0x2cbe8c4
02cbe8c4: stp     x30, x19, [sp, #-0x10]!                    
02cbe8c8: mov     x0, xzr                                    
02cbe8cc: bl      #0x5afb724                                 UnityEngine.Screen::get_height
02cbe8d0: mov     w19, w0                                    
02cbe8d4: mov     x0, xzr                                    
02cbe8d8: bl      #0x5afb6fc                                 UnityEngine.Screen::get_width
02cbe8dc: cmp     w19, w0                                    
02cbe8e0: b.le    #0x2cbe8fc                                 
02cbe8e4: mov     x0, xzr                                    
02cbe8e8: bl      #0x5afb724                                 UnityEngine.Screen::get_height
02cbe8ec: mov     w19, w0                                    
02cbe8f0: mov     x0, xzr                                    
02cbe8f4: bl      #0x5afb6fc                                 UnityEngine.Screen::get_width
02cbe8f8: b       #0x2cbe910                                 
02cbe8fc: mov     x0, xzr                                    
02cbe900: bl      #0x5afb6fc                                 UnityEngine.Screen::get_width
02cbe904: mov     w19, w0                                    
02cbe908: mov     x0, xzr                                    
02cbe90c: bl      #0x5afb724                                 UnityEngine.Screen::get_height
02cbe910: scvtf   s0, w19                                    
02cbe914: scvtf   s1, w0                                     
02cbe918: adrp    x8, #0x1084000                             
02cbe91c: fdiv    s0, s0, s1                                 
02cbe920: ldr     s1, [x8, #0xfdc]                           [1084fdc]=3727c5ac3fe33333 f=1.775,1e-05
02cbe924: fcmp    s0, s1                                     
02cbe928: cset    w0, ls                                     
02cbe92c: ldp     x30, x19, [sp], #0x10                      
02cbe930: ret                                                
## get_IsAndroid() -> bool
---- Framework.DeviceInfo::get_IsAndroid 0x2cbe934
02cbe934: mov     w0, #1                                     
02cbe938: ret                                                
## get_IsIOS() -> bool
---- Framework.DeviceInfo::get_IsIOS 0x2cbe93c
02cbe93c: mov     w0, wzr                                    
02cbe940: ret                                                
## get_IsWebGL() -> bool
---- Framework.DeviceInfo::get_IsWebGL 0x2cbe944
02cbe944: mov     w0, wzr                                    
02cbe948: ret                                                
## get_IsDevelopment() -> bool
---- Framework.DeviceInfo::get_IsDevelopment 0x2cbe94c
02cbe94c: mov     w0, wzr                                    
02cbe950: ret                                                
## get_IsNoAds() -> bool
---- Framework.DeviceInfo::get_IsNoAds 0x2cbe954
02cbe954: mov     w0, wzr                                    
02cbe958: ret                                                
## get_IsTestIAP() -> bool
---- Framework.DeviceInfo::get_IsTestIAP 0x2cbe95c
02cbe95c: mov     w0, wzr                                    
02cbe960: ret                                                
## get_IsNoTracking() -> bool
---- Framework.DeviceInfo::get_IsNoTracking 0x2cbe964
02cbe964: mov     w0, wzr                                    
02cbe968: ret                                                
## HasInternet() -> bool
---- Framework.DeviceInfo::HasInternet 0x2cbe96c
02cbe96c: str     x30, [sp, #-0x20]!                         
02cbe970: stp     x20, x19, [sp, #0x10]                      
02cbe974: adrp    x19, #0x662f000                            
02cbe978: adrp    x20, #0x6264000                            
02cbe97c: ldrb    w8, [x19, #0xc04]                          
02cbe980: ldr     x20, [x20, #0xa70]                         T:UnityEngine.Application
02cbe984: tbnz    w8, #0, #0x2cbe99c                         
02cbe988: adrp    x0, #0x6264000                             
02cbe98c: ldr     x0, [x0, #0xa70]                           T:UnityEngine.Application
02cbe990: bl      #0x2b70db0                                 fn_2b70db0
02cbe994: mov     w8, #1                                     
02cbe998: strb    w8, [x19, #0xc04]                          
02cbe99c: ldr     x0, [x20]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02cbe9a0: ldr     w8, [x0, #0xe4]                            [62640e4]=0 f=0,0
02cbe9a4: cbnz    w8, #0x2cbe9ac                             
02cbe9a8: bl      #0x2b70f30                                 fn_2b70f30
02cbe9ac: mov     x0, xzr                                    
02cbe9b0: bl      #0x5aeb318                                 UnityEngine.Application::get_internetReachability
02cbe9b4: ldp     x20, x19, [sp, #0x10]                      
02cbe9b8: cmp     w0, #0                                     
02cbe9bc: cset    w0, ne                                     
02cbe9c0: ldr     x30, [sp], #0x20                           
02cbe9c4: ret                                                
## GetLocalIPAddress() -> System.Collections.Generic.List`1<string>
---- Framework.DeviceInfo::GetLocalIPAddress 0x2cbe9c8
02cbe9c8: stp     x30, x23, [sp, #-0x30]!                    
02cbe9cc: stp     x22, x21, [sp, #0x10]                      
02cbe9d0: stp     x20, x19, [sp, #0x20]                      
02cbe9d4: adrp    x20, #0x662f000                            
02cbe9d8: adrp    x21, #0x6266000                            
02cbe9dc: adrp    x19, #0x6266000                            
02cbe9e0: ldrb    w8, [x20, #0xc05]                          
02cbe9e4: ldr     x21, [x21, #0xe48]                         T:type15376(k15)
02cbe9e8: ldr     x19, [x19, #0xe50]                         MS:System.Collections.Generic.List`1::.ctor
02cbe9ec: tbnz    w8, #0, #0x2cbea1c                         
02cbe9f0: adrp    x0, #0x6266000                             
02cbe9f4: ldr     x0, [x0, #0xe58]                           MS:System.Collections.Generic.List`1::Add
02cbe9f8: bl      #0x2b70db0                                 fn_2b70db0
02cbe9fc: adrp    x0, #0x6266000                             
02cbea00: ldr     x0, [x0, #0xe50]                           MS:System.Collections.Generic.List`1::.ctor
02cbea04: bl      #0x2b70db0                                 fn_2b70db0
02cbea08: adrp    x0, #0x6266000                             
02cbea0c: ldr     x0, [x0, #0xe48]                           T:type15376(k15)
02cbea10: bl      #0x2b70db0                                 fn_2b70db0
02cbea14: mov     w8, #1                                     
02cbea18: strb    w8, [x20, #0xc05]                          
02cbea1c: ldr     x0, [x21]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cbea20: bl      #0x2b7104c                                 fn_2b7104c
02cbea24: ldr     x1, [x19]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cbea28: mov     x19, x0                                    
02cbea2c: bl      #0x35a89a4                                 fn_35a89a4
02cbea30: mov     x0, xzr                                    
02cbea34: bl      #0x5428dd8                                 System.Net.Dns::GetHostName
02cbea38: mov     x1, xzr                                    
02cbea3c: bl      #0x542893c                                 System.Net.Dns::GetHostEntry
02cbea40: cbz     x0, #0x2cbeb1c                             
02cbea44: ldr     x21, [x0, #0x20]                           S:'inter_ad_capping_time'
02cbea48: cbz     x21, #0x2cbeb1c                            
02cbea4c: ldr     w8, [x21, #0x18]                           S:'level_show_popuprate'
02cbea50: cmp     w8, #1                                     
02cbea54: b.lt    #0x2cbeb08                                 
02cbea58: adrp    x22, #0x6266000                            
02cbea5c: mov     w23, wzr                                   
02cbea60: ldr     x22, [x22, #0xe58]                         MS:System.Collections.Generic.List`1::Add
02cbea64: cmp     w23, w8                                    
02cbea68: b.hs    #0x2cbeb20                                 
02cbea6c: add     x8, x21, w23, sxtw #3                      &6266000
02cbea70: ldr     x20, [x8, #0x20]                           
02cbea74: cbz     x20, #0x2cbeb1c                            
02cbea78: mov     x0, x20                                    
02cbea7c: mov     x1, xzr                                    
02cbea80: bl      #0x53fadcc                                 System.Net.IPAddress::get_AddressFamily
02cbea84: cmp     w0, #2                                     
02cbea88: b.ne    #0x2cbeaf8                                 
02cbea8c: ldr     x8, [x20]                                  &2b706c4(=eb01011ff9400808)
02cbea90: mov     x0, x20                                    
02cbea94: ldp     x9, x1, [x8, #0x168]                       
02cbea98: blr     x9                                         
02cbea9c: cbz     x19, #0x2cbeb1c                            
02cbeaa0: ldr     w10, [x19, #0x1c]                          [626601c]=0 f=0,0
02cbeaa4: ldr     x8, [x19, #0x10]                           S:'mrec_ad_on_off'
02cbeaa8: ldr     x9, [x22]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cbeaac: add     w10, w10, #1                               
02cbeab0: str     w10, [x19, #0x1c]                          
02cbeab4: cbz     x8, #0x2cbeb1c                             
02cbeab8: ldrsw   x10, [x19, #0x18]                          
02cbeabc: ldr     w11, [x8, #0x18]                           
02cbeac0: mov     x1, x0                                     
02cbeac4: cmp     w10, w11                                   
02cbeac8: b.hs    #0x2cbeae4                                 
02cbeacc: add     x0, x8, x10, lsl #3                        
02cbead0: add     w9, w10, #1                                
02cbead4: str     w9, [x19, #0x18]                           
02cbead8: str     x1, [x0, #0x20]!                           
02cbeadc: bl      #0x2b70d54                                 fn_2b70d54
02cbeae0: b       #0x2cbeaf8                                 
02cbeae4: ldr     x8, [x9, #0x20]                            
02cbeae8: mov     x0, x19                                    
02cbeaec: ldr     x8, [x8, #0xc0]                            
02cbeaf0: ldr     x2, [x8, #0x70]                            
02cbeaf4: bl      #0x35a920c                                 fn_35a920c
02cbeaf8: ldr     w8, [x21, #0x18]                           S:'level_show_popuprate'
02cbeafc: add     w23, w23, #1                               
02cbeb00: cmp     w23, w8                                    
02cbeb04: b.lt    #0x2cbea64                                 
02cbeb08: mov     x0, x19                                    
02cbeb0c: ldp     x20, x19, [sp, #0x20]                      
02cbeb10: ldp     x22, x21, [sp, #0x10]                      
02cbeb14: ldp     x30, x23, [sp], #0x30                      
02cbeb18: ret                                                
02cbeb1c: bl      #0x2b7105c                                 fn_2b7105c
02cbeb20: bl      #0x2b71064                                 fn_2b71064
## GetUDID() -> string
---- Framework.DeviceInfo::GetUDID 0x2cbeb24
02cbeb24: stp     x30, x21, [sp, #-0x20]!                    
02cbeb28: stp     x20, x19, [sp, #0x10]                      
02cbeb2c: adrp    x19, #0x662f000                            
02cbeb30: adrp    x20, #0x6266000                            
02cbeb34: ldrb    w8, [x19, #0xc06]                          
02cbeb38: ldr     x20, [x20, #0xff8]                         T:Framework.DeviceInfo
02cbeb3c: tbnz    w8, #0, #0x2cbeb60                         
02cbeb40: adrp    x0, #0x6266000                             
02cbeb44: ldr     x0, [x0, #0xff8]                           T:Framework.DeviceInfo
02cbeb48: bl      #0x2b70db0                                 fn_2b70db0
02cbeb4c: adrp    x0, #0x6267000                             
02cbeb50: ldr     x0, [x0]                                   S:'didu'
02cbeb54: bl      #0x2b70db0                                 fn_2b70db0
02cbeb58: mov     w8, #1                                     
02cbeb5c: strb    w8, [x19, #0xc06]                          
02cbeb60: ldr     x0, [x20]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cbeb64: ldr     w8, [x0, #0xe4]                            [62670e4]=0 f=0,0
02cbeb68: cbnz    w8, #0x2cbeb74                             
02cbeb6c: bl      #0x2b70f30                                 fn_2b70f30
02cbeb70: ldr     x0, [x20]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cbeb74: ldr     x8, [x0, #0xb8]                            M:Framework.SceneUtils/<CRUnloadSceneAsync>d__2::System.Collections.IEnumerator.Reset
02cbeb78: ldr     x8, [x8]                                   
02cbeb7c: cbz     x8, #0x2cbec7c                             
02cbeb80: ldr     w8, [x8, #0x10]                            
02cbeb84: cmp     w8, #0                                     
02cbeb88: b.gt    #0x2cbec54                                 
02cbeb8c: adrp    x8, #0x6263000                             
02cbeb90: adrp    x21, #0x6267000                            
02cbeb94: mov     x2, xzr                                    
02cbeb98: ldr     x8, [x8, #0x970]                           &6645c70(=0)
02cbeb9c: ldr     x8, [x8, #0x90]                            &2c5beb4(=14c8d222d503245f)
02cbeba0: ldr     x8, [x8, #0xb8]                            &6263108(=0)
02cbeba4: ldr     x21, [x21]                                 S:'didu'
02cbeba8: ldr     x1, [x8]                                   &2c5bbd4(=a9bd7bfdd503233f)
02cbebac: ldr     x0, [x21]                                  S:'didu'
02cbebb0: bl      #0x5b2d3f0                                 UnityEngine.PlayerPrefs::GetString
02cbebb4: ldr     x8, [x20]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cbebb8: mov     x19, x0                                    
02cbebbc: ldr     w9, [x8, #0xe4]                            [62630e4]=0 f=0,0
02cbebc0: cbnz    w9, #0x2cbebd0                             
02cbebc4: mov     x0, x8                                     
02cbebc8: bl      #0x2b70f30                                 fn_2b70f30
02cbebcc: ldr     x8, [x20]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cbebd0: ldr     x8, [x8, #0xb8]                            &6263108(=0)
02cbebd4: mov     x1, x19                                    
02cbebd8: str     x19, [x8]                                  
02cbebdc: ldr     x8, [x20]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cbebe0: ldr     x0, [x8, #0xb8]                            &6263108(=0)
02cbebe4: bl      #0x2b70d54                                 fn_2b70d54
02cbebe8: ldr     x8, [x20]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cbebec: mov     x1, xzr                                    
02cbebf0: ldr     x8, [x8, #0xb8]                            &6263108(=0)
02cbebf4: ldr     x0, [x8]                                   &2c5bbd4(=a9bd7bfdd503233f)
02cbebf8: bl      #0x4ca6234                                 System.String::IsNullOrEmpty
02cbebfc: tbz     w0, #0, #0x2cbec54                         
02cbec00: mov     x0, xzr                                    
02cbec04: bl      #0x5b409bc                                 UnityEngine.SystemInfo::get_deviceUniqueIdentifier
02cbec08: ldr     x8, [x20]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cbec0c: mov     x19, x0                                    
02cbec10: ldr     w9, [x8, #0xe4]                            [62630e4]=0 f=0,0
02cbec14: cbnz    w9, #0x2cbec24                             
02cbec18: mov     x0, x8                                     
02cbec1c: bl      #0x2b70f30                                 fn_2b70f30
02cbec20: ldr     x8, [x20]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cbec24: ldr     x8, [x8, #0xb8]                            &6263108(=0)
02cbec28: mov     x1, x19                                    
02cbec2c: str     x19, [x8]                                  
02cbec30: ldr     x8, [x20]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cbec34: ldr     x0, [x8, #0xb8]                            &6263108(=0)
02cbec38: bl      #0x2b70d54                                 fn_2b70d54
02cbec3c: ldr     x8, [x20]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cbec40: ldr     x0, [x21]                                  S:'didu'
02cbec44: mov     x2, xzr                                    
02cbec48: ldr     x8, [x8, #0xb8]                            &6263108(=0)
02cbec4c: ldr     x1, [x8]                                   &2c5bbd4(=a9bd7bfdd503233f)
02cbec50: bl      #0x5b2d398                                 UnityEngine.PlayerPrefs::SetString
02cbec54: ldr     x0, [x20]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cbec58: ldr     w8, [x0, #0xe4]                            [62670e4]=0 f=0,0
02cbec5c: cbnz    w8, #0x2cbec68                             
02cbec60: bl      #0x2b70f30                                 fn_2b70f30
02cbec64: ldr     x0, [x20]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cbec68: ldr     x8, [x0, #0xb8]                            M:Framework.SceneUtils/<CRUnloadSceneAsync>d__2::System.Collections.IEnumerator.Reset
02cbec6c: ldp     x20, x19, [sp, #0x10]                      
02cbec70: ldr     x0, [x8]                                   &2c5bbd4(=a9bd7bfdd503233f)
02cbec74: ldp     x30, x21, [sp], #0x20                      
02cbec78: ret                                                
02cbec7c: bl      #0x2b7105c                                 fn_2b7105c
## OpenDeviceWifiSetting() -> void
---- Framework.DeviceInfo::OpenDeviceWifiSetting 0x2cbec80
02cbec80: sub     sp, sp, #0x80                              
02cbec84: str     x30, [sp, #0x50]                           
02cbec88: stp     x22, x21, [sp, #0x60]                      
02cbec8c: stp     x20, x19, [sp, #0x70]                      
02cbec90: adrp    x20, #0x662f000                            
02cbec94: adrp    x19, #0x6263000                            
02cbec98: ldrb    w8, [x20, #0xc07]                          
02cbec9c: ldr     x19, [x19, #0xc40]                         T:UnityEngine.AndroidJavaClass
02cbeca0: tbnz    w8, #0, #0x2cbed24                         
02cbeca4: adrp    x0, #0x6263000                             
02cbeca8: ldr     x0, [x0, #0xc40]                           T:UnityEngine.AndroidJavaClass
02cbecac: bl      #0x2b70db0                                 fn_2b70db0
02cbecb0: adrp    x0, #0x6263000                             
02cbecb4: ldr     x0, [x0, #0xc50]                           MS:UnityEngine.AndroidJavaObject::GetStatic
02cbecb8: bl      #0x2b70db0                                 fn_2b70db0
02cbecbc: adrp    x0, #0x6263000                             
02cbecc0: ldr     x0, [x0, #0xbd8]                           T:UnityEngine.AndroidJavaObject
02cbecc4: bl      #0x2b70db0                                 fn_2b70db0
02cbecc8: adrp    x0, #0x6263000                             
02cbeccc: ldr     x0, [x0, #0x980]                           T:System.IDisposable
02cbecd0: bl      #0x2b70db0                                 fn_2b70db0
02cbecd4: adrp    x0, #0x6263000                             
02cbecd8: ldr     x0, [x0, #0xa80]                           T:type24502(k1d)
02cbecdc: bl      #0x2b70db0                                 fn_2b70db0
02cbece0: adrp    x0, #0x6267000                             
02cbece4: ldr     x0, [x0, #8]                               S:'android.settings.WIFI_SETTINGS'
02cbece8: bl      #0x2b70db0                                 fn_2b70db0
02cbecec: adrp    x0, #0x6265000                             
02cbecf0: ldr     x0, [x0, #0x730]                           S:'com.unity3d.player.UnityPlayer'
02cbecf4: bl      #0x2b70db0                                 fn_2b70db0
02cbecf8: adrp    x0, #0x6267000                             
02cbecfc: ldr     x0, [x0, #0x10]                            S:'startActivity'
02cbed00: bl      #0x2b70db0                                 fn_2b70db0
02cbed04: adrp    x0, #0x6267000                             
02cbed08: ldr     x0, [x0, #0x18]                            S:'android.content.Intent'
02cbed0c: bl      #0x2b70db0                                 fn_2b70db0
02cbed10: adrp    x0, #0x6265000                             
02cbed14: ldr     x0, [x0, #0x738]                           S:'currentActivity'
02cbed18: bl      #0x2b70db0                                 fn_2b70db0
02cbed1c: mov     w8, #1                                     
02cbed20: strb    w8, [x20, #0xc07]                          
02cbed24: ldr     x0, [x19]                                  &2c5bbd4(=a9bd7bfdd503233f)
02cbed28: str     xzr, [sp, #0x58]                           
02cbed2c: stp     xzr, xzr, [sp, #0x40]                      
02cbed30: str     wzr, [sp, #0x38]                           
02cbed34: bl      #0x2b7104c                                 fn_2b7104c
02cbed38: adrp    x8, #0x6265000                             
02cbed3c: mov     x19, x0                                    
02cbed40: ldr     x8, [x8, #0x730]                           S:'com.unity3d.player.UnityPlayer'
02cbed44: ldr     x1, [x8]                                   M:AdsManager::<OnApplicationPause>b__26_0
02cbed48: mov     x2, xzr                                    
02cbed4c: bl      #0x5ad2f6c                                 UnityEngine.AndroidJavaClass::.ctor
02cbed50: adrp    x22, #0x6263000                            
02cbed54: add     x8, sp, #0x58                              
02cbed58: ldr     x22, [x22, #0x980]                         T:System.IDisposable
02cbed5c: str     x19, [sp, #0x58]                           
02cbed60: stp     xzr, x8, [sp, #0x20]                       
02cbed64: cbz     x19, #0x2cbefe8                            
02cbed68: adrp    x8, #0x6265000                             
02cbed6c: adrp    x9, #0x6263000                             
02cbed70: ldr     x8, [x8, #0x738]                           S:'currentActivity'
02cbed74: ldr     x9, [x9, #0xc50]                           MS:UnityEngine.AndroidJavaObject::GetStatic
02cbed78: ldr     x1, [x8]                                   M:AdsManager::<OnApplicationPause>b__26_0
02cbed7c: ldr     x2, [x9]                                   &2c5bbd4(=a9bd7bfdd503233f)
02cbed80: mov     x0, x19                                    
02cbed84: bl      #0x3121808                                 fn_3121808
02cbed88: adrp    x21, #0x6263000                            
02cbed8c: add     x8, sp, #0x48                              
02cbed90: ldr     x21, [x21, #0xa80]                         T:type24502(k1d)
02cbed94: str     x0, [sp, #0x48]                            
02cbed98: stp     xzr, x8, [sp, #0x10]                       
02cbed9c: ldr     x0, [x21]                                  &2c5bbd4(=a9bd7bfdd503233f)
02cbeda0: mov     w1, #1                                     
02cbeda4: bl      #0x2b70ea0                                 fn_2b70ea0
02cbeda8: mov     x19, x0                                    
02cbedac: cbz     x0, #0x2cbefec                             
02cbedb0: adrp    x20, #0x6267000                            
02cbedb4: ldr     x20, [x20, #8]                             S:'android.settings.WIFI_SETTINGS'
02cbedb8: ldr     x0, [x20]                                  S:'didu'
02cbedbc: cbz     x0, #0x2cbedd0                             
02cbedc0: ldr     x8, [x19]                                  &2c5bbd4(=a9bd7bfdd503233f)
02cbedc4: ldr     x1, [x8, #0x40]                            S:'done_ad'
02cbedc8: bl      #0x2b70f34                                 fn_2b70f34
02cbedcc: cbz     x0, #0x2cbf008                             
02cbedd0: ldr     w8, [x19, #0x18]                           &2c5d934(=d65f03c0d503245f)
02cbedd4: cbz     w8, #0x2cbeff0                             
02cbedd8: ldr     x1, [x20]                                  S:'didu'
02cbeddc: mov     x0, x19                                    
02cbede0: str     x1, [x0, #0x20]!                           
02cbede4: bl      #0x2b70d54                                 fn_2b70d54
02cbede8: adrp    x8, #0x6263000                             
02cbedec: ldr     x8, [x8, #0xbd8]                           T:UnityEngine.AndroidJavaObject
02cbedf0: ldr     x0, [x8]                                   &2c5bbd4(=a9bd7bfdd503233f)
02cbedf4: bl      #0x2b7104c                                 fn_2b7104c
02cbedf8: adrp    x8, #0x6267000                             
02cbedfc: mov     x20, x0                                    
02cbee00: ldr     x8, [x8, #0x18]                            S:'android.content.Intent'
02cbee04: ldr     x1, [x8]                                   S:'didu'
02cbee08: mov     x2, x19                                    
02cbee0c: mov     x3, xzr                                    
02cbee10: bl      #0x5ad5b2c                                 UnityEngine.AndroidJavaObject::.ctor
02cbee14: ldr     x19, [sp, #0x48]                           
02cbee18: ldr     x0, [x21]                                  &2c5bbd4(=a9bd7bfdd503233f)
02cbee1c: add     x8, sp, #0x40                              
02cbee20: str     x20, [sp, #0x40]                           
02cbee24: stp     xzr, x8, [sp]                              
02cbee28: mov     w1, #1                                     
02cbee2c: bl      #0x2b70ea0                                 fn_2b70ea0
02cbee30: mov     x20, x0                                    
02cbee34: cbz     x0, #0x2cbefe4                             
02cbee38: ldr     x21, [sp, #0x40]                           
02cbee3c: cbz     x21, #0x2cbee54                            
02cbee40: ldr     x8, [x20]                                  S:'didu'
02cbee44: ldr     x1, [x8, #0x40]                            S:'<color=#'
02cbee48: mov     x0, x21                                    
02cbee4c: bl      #0x2b70f34                                 fn_2b70f34
02cbee50: cbz     x0, #0x2cbf014                             
02cbee54: ldr     w8, [x20, #0x18]                           S:'android.content.Intent'
02cbee58: cbz     w8, #0x2cbeffc                             
02cbee5c: mov     x0, x20                                    
02cbee60: str     x21, [x0, #0x20]!                          
02cbee64: mov     x1, x21                                    
02cbee68: bl      #0x2b70d54                                 fn_2b70d54
02cbee6c: cbz     x19, #0x2cbefe4                            
02cbee70: adrp    x8, #0x6267000                             
02cbee74: ldr     x8, [x8, #0x10]                            S:'startActivity'
02cbee78: ldr     x1, [x8]                                   S:'didu'
02cbee7c: mov     x0, x19                                    
02cbee80: mov     x2, x20                                    
02cbee84: mov     x3, xzr                                    
02cbee88: bl      #0x5ad5e34                                 UnityEngine.AndroidJavaObject::Call
02cbee8c: mov     x19, xzr                                   
02cbee90: add     x8, sp, #0x40                              
02cbee94: ldr     x20, [x8]                                  S:'didu'
02cbee98: cbz     x20, #0x2cbeef4                            
02cbee9c: ldr     x8, [x20]                                  S:'didu'
02cbeea0: ldr     x1, [x22]                                  &2c5bbd4(=a9bd7bfdd503233f)
02cbeea4: ldrh    w9, [x8, #0x12e]                           
02cbeea8: cbz     x9, #0x2cbeecc                             
02cbeeac: ldr     x10, [x8, #0xb0]                           M:Framework.SceneUtils/<CRLoadSceneAsync>d__1::System.Collections.IEnumerator.Reset
02cbeeb0: add     x10, x10, #8                               
02cbeeb4: ldur    x11, [x10, #-8]                            
02cbeeb8: cmp     x11, x1                                    
02cbeebc: b.eq    #0x2cbeedc                                 
02cbeec0: subs    x9, x9, #1                                 
02cbeec4: add     x10, x10, #0x10                            
02cbeec8: b.ne    #0x2cbeeb4                                 
02cbeecc: mov     x0, x20                                    
02cbeed0: mov     w2, wzr                                    
02cbeed4: bl      #0x2baa05c                                 fn_2baa05c
02cbeed8: b       #0x2cbeee8                                 
02cbeedc: ldrsw   x9, [x10]                                  
02cbeee0: add     x8, x8, x9, lsl #4                         &6267000
02cbeee4: add     x0, x8, #0x138                             &6267138
02cbeee8: ldp     x8, x1, [x0]                               
02cbeeec: mov     x0, x20                                    
02cbeef0: blr     x8                                         
02cbeef4: cbnz    x19, #0x2cbf000                            
02cbeef8: ldr     x8, [sp, #0x18]                            
02cbeefc: ldr     x19, [x8]                                  S:'didu'
02cbef00: cbz     x19, #0x2cbef5c                            
02cbef04: ldr     x8, [x19]                                  &2c5bbd4(=a9bd7bfdd503233f)
02cbef08: ldr     x1, [x22]                                  &2c5bbd4(=a9bd7bfdd503233f)
02cbef0c: ldrh    w9, [x8, #0x12e]                           
02cbef10: cbz     x9, #0x2cbef34                             
02cbef14: ldr     x10, [x8, #0xb0]                           M:Framework.SceneUtils/<CRLoadSceneAsync>d__1::System.Collections.IEnumerator.Reset
02cbef18: add     x10, x10, #8                               
02cbef1c: ldur    x11, [x10, #-8]                            
02cbef20: cmp     x11, x1                                    
02cbef24: b.eq    #0x2cbef44                                 
02cbef28: subs    x9, x9, #1                                 
02cbef2c: add     x10, x10, #0x10                            
02cbef30: b.ne    #0x2cbef1c                                 
02cbef34: mov     x0, x19                                    
02cbef38: mov     w2, wzr                                    
02cbef3c: bl      #0x2baa05c                                 fn_2baa05c
02cbef40: b       #0x2cbef50                                 
02cbef44: ldrsw   x9, [x10]                                  
02cbef48: add     x8, x8, x9, lsl #4                         &6267000
02cbef4c: add     x0, x8, #0x138                             &6267138
02cbef50: ldp     x8, x1, [x0]                               
02cbef54: mov     x0, x19                                    
02cbef58: blr     x8                                         
02cbef5c: ldr     x0, [sp, #0x10]                            
02cbef60: cbnz    x0, #0x2cbeff8                             
02cbef64: ldr     x8, [sp, #0x28]                            
02cbef68: ldr     x19, [x8]                                  S:'didu'
02cbef6c: cbz     x19, #0x2cbefc8                            
02cbef70: ldr     x8, [x19]                                  &2c5bbd4(=a9bd7bfdd503233f)
02cbef74: ldr     x1, [x22]                                  &2c5bbd4(=a9bd7bfdd503233f)
02cbef78: ldrh    w9, [x8, #0x12e]                           
02cbef7c: cbz     x9, #0x2cbefa0                             
02cbef80: ldr     x10, [x8, #0xb0]                           M:Framework.SceneUtils/<CRLoadSceneAsync>d__1::System.Collections.IEnumerator.Reset
02cbef84: add     x10, x10, #8                               
02cbef88: ldur    x11, [x10, #-8]                            
02cbef8c: cmp     x11, x1                                    
02cbef90: b.eq    #0x2cbefb0                                 
02cbef94: subs    x9, x9, #1                                 
02cbef98: add     x10, x10, #0x10                            
02cbef9c: b.ne    #0x2cbef88                                 
02cbefa0: mov     x0, x19                                    
02cbefa4: mov     w2, wzr                                    
02cbefa8: bl      #0x2baa05c                                 fn_2baa05c
02cbefac: b       #0x2cbefbc                                 
02cbefb0: ldrsw   x9, [x10]                                  
02cbefb4: add     x8, x8, x9, lsl #4                         &6267000
02cbefb8: add     x0, x8, #0x138                             &6267138
02cbefbc: ldp     x8, x1, [x0]                               
02cbefc0: mov     x0, x19                                    
02cbefc4: blr     x8                                         
02cbefc8: ldr     x0, [sp, #0x20]                            
02cbefcc: cbnz    x0, #0x2cbeff4                             
02cbefd0: ldp     x20, x19, [sp, #0x70]                      
02cbefd4: ldr     x30, [sp, #0x50]                           
02cbefd8: ldp     x22, x21, [sp, #0x60]                      
02cbefdc: add     sp, sp, #0x80                              
02cbefe0: ret                                                
02cbefe4: bl      #0x2b7105c                                 fn_2b7105c
02cbefe8: bl      #0x2b7105c                                 fn_2b7105c
02cbefec: bl      #0x2b7105c                                 fn_2b7105c
02cbeff0: bl      #0x2b71064                                 fn_2b71064
02cbeff4: bl      #0x2b71054                                 fn_2b71054
02cbeff8: bl      #0x2b71054                                 fn_2b71054
02cbeffc: bl      #0x2b71064                                 fn_2b71064
02cbf000: mov     x0, x19                                    
02cbf004: bl      #0x2b71054                                 fn_2b71054
02cbf008: bl      #0x2b71080                                 fn_2b71080
02cbf00c: mov     x1, xzr                                    
02cbf010: bl      #0x2b70f20                                 fn_2b70f20
02cbf014: bl      #0x2b71080                                 fn_2b71080
02cbf018: mov     x1, xzr                                    
02cbf01c: bl      #0x2b70f20                                 fn_2b70f20
02cbf020: b       #0x2cbf060                                 
02cbf024: b       #0x2cbf054                                 
02cbf028: b       #0x2cbf03c                                 
02cbf02c: b       #0x2cbf03c                                 
02cbf030: b       #0x2cbf054                                 
02cbf034: b       #0x2cbf048                                 
02cbf038: b       #0x2cbf054                                 
02cbf03c: mov     x20, x1                                    
02cbf040: mov     x19, x0                                    
02cbf044: b       #0x2cbf0cc                                 
02cbf048: mov     x20, x1                                    
02cbf04c: mov     x19, x0                                    
02cbf050: b       #0x2cbf0fc                                 
02cbf054: mov     x20, x1                                    
02cbf058: mov     x19, x0                                    
02cbf05c: b       #0x2cbf09c                                 
02cbf060: mov     x20, x1                                    
02cbf064: mov     x19, x0                                    
02cbf068: cmp     w20, #1                                    
02cbf06c: b.ne    #0x2cbf094                                 
02cbf070: mov     x0, x19                                    
02cbf074: bl      #0x5e90260                                 fn_5e90260
02cbf078: ldr     x19, [x0]                                  M:AdsManager::<OnApplicationPause>b__26_0
02cbf07c: str     x19, [sp]                                  
02cbf080: bl      #0x5e90270                                 fn_5e90270
02cbf084: ldr     x8, [sp, #8]                               
02cbf088: b       #0x2cbee94                                 
02cbf08c: mov     x20, x1                                    
02cbf090: mov     x19, x0                                    
02cbf094: mov     x0, sp                                     
02cbf098: bl      #0x27369c4                                 fn_27369c4
02cbf09c: cmp     w20, #1                                    
02cbf0a0: b.ne    #0x2cbf0c4                                 
02cbf0a4: mov     x0, x19                                    
02cbf0a8: bl      #0x5e90260                                 fn_5e90260
02cbf0ac: ldr     x8, [x0]                                   M:AdsManager::<OnApplicationPause>b__26_0
02cbf0b0: str     x8, [sp, #0x10]                            
02cbf0b4: bl      #0x5e90270                                 fn_5e90270
02cbf0b8: b       #0x2cbeef8                                 
02cbf0bc: mov     x20, x1                                    
02cbf0c0: mov     x19, x0                                    
02cbf0c4: add     x0, sp, #0x10                              
02cbf0c8: bl      #0x27369c4                                 fn_27369c4
02cbf0cc: cmp     w20, #1                                    
02cbf0d0: b.ne    #0x2cbf0f4                                 
02cbf0d4: mov     x0, x19                                    
02cbf0d8: bl      #0x5e90260                                 fn_5e90260
02cbf0dc: ldr     x8, [x0]                                   M:AdsManager::<OnApplicationPause>b__26_0
02cbf0e0: str     x8, [sp, #0x20]                            
02cbf0e4: bl      #0x5e90270                                 fn_5e90270
02cbf0e8: b       #0x2cbef64                                 
02cbf0ec: mov     x20, x1                                    
02cbf0f0: mov     x19, x0                                    
02cbf0f4: add     x0, sp, #0x20                              
02cbf0f8: bl      #0x27369c4                                 fn_27369c4
02cbf0fc: cmp     w20, #1                                    
02cbf100: b.ne    #0x2cbf19c                                 
02cbf104: mov     x0, x19                                    
02cbf108: bl      #0x5e90260                                 fn_5e90260
02cbf10c: mov     x19, x0                                    
02cbf110: adrp    x0, #0x6263000                             
02cbf114: ldr     x0, [x0, #0xae0]                           T:System.Exception
02cbf118: bl      #0x2b70dc4                                 fn_2b70dc4
02cbf11c: ldr     x8, [x19]                                  &2c5bbd4(=a9bd7bfdd503233f)
02cbf120: ldr     x1, [x8]                                   S:'didu'
02cbf124: bl      #0x2b71464                                 fn_2b71464
02cbf128: tbz     w0, #0, #0x2cbf174                         
02cbf12c: ldrsw   x20, [sp, #0x38]                           
02cbf130: ldr     x19, [x19]                                 &2c5bbd4(=a9bd7bfdd503233f)
02cbf134: add     x8, sp, #0x30                              
02cbf138: str     x19, [x8, x20, lsl #3]                     
02cbf13c: add     w8, w20, #1                                
02cbf140: str     w8, [sp, #0x38]                            
02cbf144: bl      #0x5e90270                                 fn_5e90270
02cbf148: adrp    x0, #0x6263000                             
02cbf14c: ldr     x0, [x0, #0x928]                           T:UnityEngine.Debug
02cbf150: bl      #0x2b70dc4                                 fn_2b70dc4
02cbf154: ldr     w8, [x0, #0xe4]                            [62630e4]=0 f=0,0
02cbf158: cbnz    w8, #0x2cbf160                             
02cbf15c: bl      #0x2b70f30                                 fn_2b70f30
02cbf160: mov     x0, x19                                    
02cbf164: mov     x1, xzr                                    
02cbf168: bl      #0x5aec808                                 UnityEngine.Debug::LogException
02cbf16c: str     w20, [sp, #0x38]                           
02cbf170: b       #0x2cbefd0                                 
02cbf174: mov     w0, #8                                     
02cbf178: bl      #0x5e90290                                 fn_5e90290
02cbf17c: ldr     x8, [x19]                                  &2c5bbd4(=a9bd7bfdd503233f)
02cbf180: str     x8, [x0]                                   
02cbf184: adrp    x1, #0x5e96000                             
02cbf188: add     x1, x1, #0x758                             &5e96758
02cbf18c: mov     x2, xzr                                    
02cbf190: bl      #0x5e902a0                                 fn_5e902a0
02cbf194: mov     x19, x0                                    
02cbf198: bl      #0x5e90270                                 fn_5e90270
02cbf19c: mov     x0, x19                                    
02cbf1a0: bl      #0x2c6051c                                 fn_2c6051c
02cbf1a4: bl      #0x27369b8                                 fn_27369b8
## .cctor() -> void
---- Framework.DeviceInfo::.cctor 0x2cbf1a8
02cbf1a8: stp     x30, x21, [sp, #-0x20]!                    
02cbf1ac: stp     x20, x19, [sp, #0x10]                      
02cbf1b0: adrp    x21, #0x662f000                            
02cbf1b4: adrp    x20, #0x6263000                            
02cbf1b8: adrp    x19, #0x6266000                            
02cbf1bc: ldrb    w8, [x21, #0xc08]                          
02cbf1c0: ldr     x20, [x20, #0xa90]                         S:''
02cbf1c4: ldr     x19, [x19, #0xff8]                         T:Framework.DeviceInfo
02cbf1c8: tbnz    w8, #0, #0x2cbf1ec                         
02cbf1cc: adrp    x0, #0x6266000                             
02cbf1d0: ldr     x0, [x0, #0xff8]                           T:Framework.DeviceInfo
02cbf1d4: bl      #0x2b70db0                                 fn_2b70db0
02cbf1d8: adrp    x0, #0x6263000                             
02cbf1dc: ldr     x0, [x0, #0xa90]                           S:''
02cbf1e0: bl      #0x2b70db0                                 fn_2b70db0
02cbf1e4: mov     w8, #1                                     
02cbf1e8: strb    w8, [x21, #0xc08]                          
02cbf1ec: ldr     x8, [x19]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cbf1f0: ldr     x1, [x20]                                  &2c5bbd4(=a9bd7bfdd503233f)
02cbf1f4: ldr     x8, [x8, #0xb8]                            
02cbf1f8: str     x1, [x8]                                   
02cbf1fc: ldr     x8, [x19]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cbf200: ldp     x20, x19, [sp, #0x10]                      
02cbf204: ldr     x0, [x8, #0xb8]                            
02cbf208: ldp     x30, x21, [sp], #0x20                      
02cbf20c: b       #0x2b70d54                                 
