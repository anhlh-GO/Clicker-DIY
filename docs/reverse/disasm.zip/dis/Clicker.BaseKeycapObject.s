#### CLASS Clicker.BaseKeycapObject/<>c parent= object
#   field <>9                            Clicker.BaseKeycapObject/<>c                       off=0x0 attr=36 
#   field <>9__23_0                      System.Predicate`1<bool>                           off=0x8 attr=16 
#   field <>9__23_1                      System.Predicate`1<bool>                           off=0x10 attr=16 
#   field <>9__30_0                      System.Action`1<Clicker.KeycapClick>               off=0x18 attr=16 
#   field <>9__31_0                      System.Action`1<Clicker.KeycapObject>              off=0x20 attr=16 
#   field <>9__38_0                      System.Action`1<Clicker.SwitchObject>              off=0x28 attr=16 
#   field <>9__38_1                      System.Action`1<Clicker.KeycapObject>              off=0x30 attr=16 
#   field <>9__44_0                      DG.Tweening.TweenCallback                          off=0x38 attr=16 
#   field <>9__49_0                      DG.Tweening.TweenCallback                          off=0x40 attr=16 
#   field <>9__60_0                      System.Action`1<Clicker.KeycapClick>               off=0x48 attr=16 
## .cctor() -> void
---- Clicker.BaseKeycapObject/<>c::.cctor 0x2d61180
02d61180: str     x30, [sp, #-0x20]!                         
02d61184: stp     x20, x19, [sp, #0x10]                      
02d61188: adrp    x19, #0x6630000                            
02d6118c: adrp    x20, #0x626b000                            
02d61190: ldrb    w8, [x19, #0x2fd]                          
02d61194: ldr     x20, [x20, #0xdf8]                         T:Clicker.BaseKeycapObject/<>c
02d61198: tbnz    w8, #0, #0x2d611b0                         
02d6119c: adrp    x0, #0x626b000                             
02d611a0: ldr     x0, [x0, #0xdf8]                           T:Clicker.BaseKeycapObject/<>c
02d611a4: bl      #0x2b70db0                                 fn_2b70db0
02d611a8: mov     w8, #1                                     
02d611ac: strb    w8, [x19, #0x2fd]                          
02d611b0: ldr     x0, [x20]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d611b4: bl      #0x2b7104c                                 fn_2b7104c
02d611b8: mov     x1, xzr                                    
02d611bc: mov     x19, x0                                    
02d611c0: bl      #0x4e53e9c                                 System.Object::.ctor
02d611c4: ldr     x8, [x20]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d611c8: mov     x1, x19                                    
02d611cc: ldr     x8, [x8, #0xb8]                            
02d611d0: str     x19, [x8]                                  
02d611d4: ldr     x8, [x20]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d611d8: ldp     x20, x19, [sp, #0x10]                      
02d611dc: ldr     x0, [x8, #0xb8]                            
02d611e0: ldr     x30, [sp], #0x20                           
02d611e4: b       #0x2b70d54                                 
## .ctor() -> void
---- Clicker.BaseKeycapObject/<>c::.ctor 0x2d611e8
02d611e8: mov     x1, xzr                                    
02d611ec: b       #0x4e53e9c                                 System.Object::.ctor
## <get_IsAssembleDone>b__23_0(bool placed) -> bool
---- Clicker.BaseKeycapObject/<>c::<get_IsAssembleDone>b__23_0 0x2d611f0
02d611f0: and     w0, w1, #1                                 
02d611f4: ret                                                
## <get_IsAssembleDone>b__23_1(bool placed) -> bool
---- Clicker.BaseKeycapObject/<>c::<get_IsAssembleDone>b__23_1 0x2d611f8
02d611f8: and     w0, w1, #1                                 
02d611fc: ret                                                
## <RemoveSetupEvent>b__30_0(Clicker.KeycapClick keycapClick) -> void
---- Clicker.BaseKeycapObject/<>c::<RemoveSetupEvent>b__30_0 0x2d61200
02d61200: str     x30, [sp, #-0x10]!                         
02d61204: cbz     x1, #0x2d6121c                             
02d61208: ldr     x0, [x1, #0x38]                            
02d6120c: cbz     x0, #0x2d6121c                             
02d61210: mov     x1, xzr                                    
02d61214: ldr     x30, [sp], #0x10                           
02d61218: b       #0x5b4ce48                                 UnityEngine.Events.UnityEventBase::RemoveAllListeners
02d6121c: bl      #0x2b7105c                                 fn_2b7105c
## <HideKeycaps>b__31_0(Clicker.KeycapObject keycapObj) -> void
---- Clicker.BaseKeycapObject/<>c::<HideKeycaps>b__31_0 0x2d61238
02d61238: str     x30, [sp, #-0x20]!                         
02d6123c: stp     x20, x19, [sp, #0x10]                      
02d61240: cbz     x1, #0x2d612c0                             
02d61244: mov     x19, x1                                    
02d61248: mov     x0, x1                                     
02d6124c: mov     x1, xzr                                    
02d61250: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02d61254: mov     w1, wzr                                    
02d61258: mov     x2, xzr                                    
02d6125c: bl      #0x2d9d5d0                                 DG.Tweening.ShortcutExtensions::DOKill
02d61260: mov     x0, x19                                    
02d61264: mov     x1, xzr                                    
02d61268: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02d6126c: adrp    x20, #0x662f000                            
02d61270: mov     x19, x0                                    
02d61274: ldrb    w8, [x20, #0x91a]                          
02d61278: cbnz    w8, #0x2d61290                             
02d6127c: adrp    x0, #0x6264000                             
02d61280: ldr     x0, [x0, #0xd8]                            T:UnityEngine.Vector3
02d61284: bl      #0x2b70db0                                 fn_2b70db0
02d61288: mov     w8, #1                                     
02d6128c: strb    w8, [x20, #0x91a]                          
02d61290: cbz     x19, #0x2d612c0                            
02d61294: adrp    x8, #0x6264000                             
02d61298: mov     x0, x19                                    
02d6129c: mov     x1, xzr                                    
02d612a0: ldr     x8, [x8, #0xd8]                            T:UnityEngine.Vector3
02d612a4: ldp     x20, x19, [sp, #0x10]                      
02d612a8: ldr     x8, [x8]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d612ac: ldr     x8, [x8, #0xb8]                            MS:DG.Tweening.Core.Extensions::SetSpecialStartupMode
02d612b0: ldp     s0, s1, [x8]                               
02d612b4: ldr     s2, [x8, #8]                               T:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass2_0
02d612b8: ldr     x30, [sp], #0x20                           
02d612bc: b       #0x5b470cc                                 UnityEngine.Transform::set_localScale
02d612c0: bl      #0x2b7105c                                 fn_2b7105c
## <ShowAllNoAnim>b__38_0(Clicker.SwitchObject switchObj) -> void
---- Clicker.BaseKeycapObject/<>c::<ShowAllNoAnim>b__38_0 0x2d612c4
02d612c4: str     x30, [sp, #-0x20]!                         
02d612c8: stp     x20, x19, [sp, #0x10]                      
02d612cc: cbz     x1, #0x2d61330                             
02d612d0: mov     x0, x1                                     
02d612d4: mov     x1, xzr                                    
02d612d8: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02d612dc: adrp    x20, #0x662f000                            
02d612e0: mov     x19, x0                                    
02d612e4: ldrb    w8, [x20, #0xa74]                          
02d612e8: cbnz    w8, #0x2d61300                             
02d612ec: adrp    x0, #0x6264000                             
02d612f0: ldr     x0, [x0, #0xd8]                            T:UnityEngine.Vector3
02d612f4: bl      #0x2b70db0                                 fn_2b70db0
02d612f8: mov     w8, #1                                     
02d612fc: strb    w8, [x20, #0xa74]                          
02d61300: cbz     x19, #0x2d61330                            
02d61304: adrp    x8, #0x6264000                             
02d61308: mov     x0, x19                                    
02d6130c: mov     x1, xzr                                    
02d61310: ldr     x8, [x8, #0xd8]                            T:UnityEngine.Vector3
02d61314: ldp     x20, x19, [sp, #0x10]                      
02d61318: ldr     x8, [x8]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d6131c: ldr     x8, [x8, #0xb8]                            MS:DG.Tweening.Core.Extensions::SetSpecialStartupMode
02d61320: ldp     s0, s1, [x8, #0xc]                         
02d61324: ldr     s2, [x8, #0x14]                            [6264014]=0 f=0,0
02d61328: ldr     x30, [sp], #0x20                           
02d6132c: b       #0x5b470cc                                 UnityEngine.Transform::set_localScale
02d61330: bl      #0x2b7105c                                 fn_2b7105c
## <ShowAllNoAnim>b__38_1(Clicker.KeycapObject keycapObj) -> void
---- Clicker.BaseKeycapObject/<>c::<ShowAllNoAnim>b__38_1 0x2d61334
02d61334: str     x30, [sp, #-0x20]!                         
02d61338: stp     x20, x19, [sp, #0x10]                      
02d6133c: cbz     x1, #0x2d613a0                             
02d61340: mov     x0, x1                                     
02d61344: mov     x1, xzr                                    
02d61348: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02d6134c: adrp    x20, #0x662f000                            
02d61350: mov     x19, x0                                    
02d61354: ldrb    w8, [x20, #0xa74]                          
02d61358: cbnz    w8, #0x2d61370                             
02d6135c: adrp    x0, #0x6264000                             
02d61360: ldr     x0, [x0, #0xd8]                            T:UnityEngine.Vector3
02d61364: bl      #0x2b70db0                                 fn_2b70db0
02d61368: mov     w8, #1                                     
02d6136c: strb    w8, [x20, #0xa74]                          
02d61370: cbz     x19, #0x2d613a0                            
02d61374: adrp    x8, #0x6264000                             
02d61378: mov     x0, x19                                    
02d6137c: mov     x1, xzr                                    
02d61380: ldr     x8, [x8, #0xd8]                            T:UnityEngine.Vector3
02d61384: ldp     x20, x19, [sp, #0x10]                      
02d61388: ldr     x8, [x8]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d6138c: ldr     x8, [x8, #0xb8]                            MS:DG.Tweening.Core.Extensions::SetSpecialStartupMode
02d61390: ldp     s0, s1, [x8, #0xc]                         
02d61394: ldr     s2, [x8, #0x14]                            [6264014]=0 f=0,0
02d61398: ldr     x30, [sp], #0x20                           
02d6139c: b       #0x5b470cc                                 UnityEngine.Transform::set_localScale
02d613a0: bl      #0x2b7105c                                 fn_2b7105c
## <ActiveKeychain>b__44_0() -> void
---- Clicker.BaseKeycapObject/<>c::<ActiveKeychain>b__44_0 0x2d613a4
02d613a4: ret                                                
## <DropSwitchReal>b__49_0() -> void
---- Clicker.BaseKeycapObject/<>c::<DropSwitchReal>b__49_0 0x2d613a8
02d613a8: ret                                                
## <UpdateGlowSprite>b__60_0(Clicker.KeycapClick keycapClick) -> void
---- Clicker.BaseKeycapObject/<>c::<UpdateGlowSprite>b__60_0 0x2d613ac
02d613ac: cbz     x1, #0x2d613b8                             
02d613b0: mov     x0, x1                                     
02d613b4: b       #0x2d613c0                                 Clicker.KeycapClick::UpdateGlow
02d613b8: str     x30, [sp, #-0x10]!                         
02d613bc: bl      #0x2b7105c                                 fn_2b7105c
#### CLASS Clicker.BaseKeycapObject/<>c__DisplayClass29_0 parent= object
#   field isSetup                        bool                                               off=0x10 attr=6 
## .ctor() -> void
---- Clicker.BaseKeycapObject/<>c__DisplayClass29_0::.ctor 0x2d5e640
02d5e640: mov     x1, xzr                                    
02d5e644: b       #0x4e53e9c                                 System.Object::.ctor
## <TurnModeSetup>b__0(Clicker.KeycapClick keycapClick) -> void
---- Clicker.BaseKeycapObject/<>c__DisplayClass29_0::<TurnModeSetup>b__0 0x2d6165c
02d6165c: cbz     x1, #0x2d61670                             
02d61660: ldrb    w8, [x0, #0x10]                            .isSetup
02d61664: mov     x0, x1                                     
02d61668: mov     w1, w8                                     
02d6166c: b       #0x2d61678                                 Clicker.KeycapClick::TurnModeSetup
02d61670: str     x30, [sp, #-0x10]!                         
02d61674: bl      #0x2b7105c                                 fn_2b7105c
#### CLASS Clicker.BaseKeycapObject/<>c__DisplayClass32_0 parent= object
#   field sprite                         UnityEngine.Sprite                                 off=0x10 attr=6 
## .ctor() -> void
---- Clicker.BaseKeycapObject/<>c__DisplayClass32_0::.ctor 0x2d5e934
02d5e934: mov     x1, xzr                                    
02d5e938: b       #0x4e53e9c                                 System.Object::.ctor
## <SetSwitch>b__0(Clicker.SwitchObject switchObj) -> void
---- Clicker.BaseKeycapObject/<>c__DisplayClass32_0::<SetSwitch>b__0 0x2d616d8
02d616d8: str     x30, [sp, #-0x10]!                         
02d616dc: cbz     x1, #0x2d616fc                             
02d616e0: ldr     x8, [x1, #0x20]                            
02d616e4: cbz     x8, #0x2d616fc                             
02d616e8: ldr     x1, [x0, #0x10]                            .sprite
02d616ec: mov     x0, x8                                     
02d616f0: mov     x2, xzr                                    
02d616f4: ldr     x30, [sp], #0x10                           
02d616f8: b       #0x5ae6dcc                                 UnityEngine.SpriteRenderer::set_sprite
02d616fc: bl      #0x2b7105c                                 fn_2b7105c
#### CLASS Clicker.BaseKeycapObject/<>c__DisplayClass33_0 parent= object
#   field eSound                         Framework.ESound                                   off=0x10 attr=6 
## .ctor() -> void
---- Clicker.BaseKeycapObject/<>c__DisplayClass33_0::.ctor 0x2d5ea14
02d5ea14: mov     x1, xzr                                    
02d5ea18: b       #0x4e53e9c                                 System.Object::.ctor
## <SetSwitchSound>b__0(Clicker.KeycapClick keycapClick) -> void
---- Clicker.BaseKeycapObject/<>c__DisplayClass33_0::<SetSwitchSound>b__0 0x2d61718
02d61718: cbz     x1, #0x2d61728                             
02d6171c: ldr     w8, [x0, #0x10]                            .eSound
02d61720: str     w8, [x1, #0x40]                            
02d61724: ret                                                
02d61728: str     x30, [sp, #-0x10]!                         
02d6172c: bl      #0x2b7105c                                 fn_2b7105c
#### CLASS Clicker.BaseKeycapObject parent= UnityEngine.MonoBehaviour
#   field _srBaseKeycap                  UnityEngine.SpriteRenderer                         off=0x20 attr=1 HeaderAttribute,SerializeField
#   field _srBaseKeycapFront             UnityEngine.SpriteRenderer                         off=0x28 attr=1 SerializeField
#   field _switchSoundName               string                                             off=0x30 attr=1 HeaderAttribute,SerializeField
#   field _switchPositions               System.Collections.Generic.List`1<UnityEngine.Transform> off=0x38 attr=1 SerializeField
#   field _switchObjects                 System.Collections.Generic.List`1<Clicker.SwitchObject> off=0x40 attr=1 SerializeField
#   field _switchPlaced                  System.Collections.Generic.List`1<bool>            off=0x48 attr=1 SerializeField
#   field _switchGlowColor               UnityEngine.Color                                  off=0x50 attr=1 SerializeField
#   field _keycapPositions               System.Collections.Generic.List`1<UnityEngine.Transform> off=0x60 attr=1 HeaderAttribute,SerializeField
#   field _keycapObjects                 System.Collections.Generic.List`1<Clicker.KeycapObject> off=0x68 attr=1 SerializeField
#   field _keycapPlaced                  System.Collections.Generic.List`1<bool>            off=0x70 attr=1 SerializeField
#   field _srKeychain                    UnityEngine.SpriteRenderer                         off=0x78 attr=1 HeaderAttribute,SerializeField
#   field _keychainPlaced                bool                                               off=0x80 attr=1 SerializeField
#   field _keycapClicks                  System.Collections.Generic.List`1<Clicker.KeycapClick> off=0x88 attr=1 HeaderAttribute,SerializeField
#   field _currentSetupKeycapIndex       int                                                off=0x90 attr=1 SerializeField,ReadOnlyAttribute
#   field _handFollowClick               Clicker.HandFollowClick                            off=0x98 attr=1 HeaderAttribute,SerializeField
#   field _closestIndex                  int                                                off=0xa0 attr=1 
#   field _closestDistance               float                                              off=0xa4 attr=1 
## get_SwitchPlaced() -> System.Collections.Generic.List`1<bool>
---- Clicker.BaseKeycapObject::get_SwitchPlaced 0x2d5df28
02d5df28: ldr     x0, [x0, #0x48]                            ._switchPlaced
02d5df2c: ret                                                
## get_KeycapPlaced() -> System.Collections.Generic.List`1<bool>
---- Clicker.BaseKeycapObject::get_KeycapPlaced 0x2d5df30
02d5df30: ldr     x0, [x0, #0x70]                            ._keycapPlaced
02d5df34: ret                                                
## get_KeychainPlaced() -> bool
---- Clicker.BaseKeycapObject::get_KeychainPlaced 0x2d5df38
02d5df38: ldrb    w0, [x0, #0x80]                            ._keychainPlaced
02d5df3c: ret                                                
## get_CurrentSetupKeycapIndex() -> int
---- Clicker.BaseKeycapObject::get_CurrentSetupKeycapIndex 0x2d5df40
02d5df40: ldr     w0, [x0, #0x90]                            ._currentSetupKeycapIndex
02d5df44: ret                                                
## get_IsAssembleDone() -> bool
---- Clicker.BaseKeycapObject::get_IsAssembleDone 0x2d5df48
02d5df48: str     x30, [sp, #-0x40]!                         
02d5df4c: stp     x24, x23, [sp, #0x10]                      
02d5df50: stp     x22, x21, [sp, #0x20]                      
02d5df54: stp     x20, x19, [sp, #0x30]                      
02d5df58: adrp    x20, #0x6630000                            
02d5df5c: adrp    x23, #0x626b000                            
02d5df60: mov     x19, x0                                    
02d5df64: ldrb    w8, [x20, #0x2e0]                          
02d5df68: ldr     x23, [x23, #0xdf8]                         T:Clicker.BaseKeycapObject/<>c
02d5df6c: tbnz    w8, #0, #0x2d5dfb4                         
02d5df70: adrp    x0, #0x626b000                             
02d5df74: ldr     x0, [x0, #0xe00]                           MS:System.Collections.Generic.List`1::TrueForAll
02d5df78: bl      #0x2b70db0                                 fn_2b70db0
02d5df7c: adrp    x0, #0x626b000                             
02d5df80: ldr     x0, [x0, #0xe08]                           T:type57224(k15)
02d5df84: bl      #0x2b70db0                                 fn_2b70db0
02d5df88: adrp    x0, #0x626b000                             
02d5df8c: ldr     x0, [x0, #0xe10]                           M:Clicker.BaseKeycapObject/<>c::<get_IsAssembleDone>b__23_0
02d5df90: bl      #0x2b70db0                                 fn_2b70db0
02d5df94: adrp    x0, #0x626b000                             
02d5df98: ldr     x0, [x0, #0xe18]                           M:Clicker.BaseKeycapObject/<>c::<get_IsAssembleDone>b__23_1
02d5df9c: bl      #0x2b70db0                                 fn_2b70db0
02d5dfa0: adrp    x0, #0x626b000                             
02d5dfa4: ldr     x0, [x0, #0xdf8]                           T:Clicker.BaseKeycapObject/<>c
02d5dfa8: bl      #0x2b70db0                                 fn_2b70db0
02d5dfac: mov     w8, #1                                     
02d5dfb0: strb    w8, [x20, #0x2e0]                          
02d5dfb4: ldr     x0, [x23]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d5dfb8: ldr     x20, [x19, #0x48]                          ._switchPlaced
02d5dfbc: ldr     w8, [x0, #0xe4]                            [626b0e4]=0 f=0,0
02d5dfc0: cbnz    w8, #0x2d5dfcc                             
02d5dfc4: bl      #0x2b70f30                                 fn_2b70f30
02d5dfc8: ldr     x0, [x23]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d5dfcc: ldr     x8, [x0, #0xb8]                            S:'scoop_no_thank'
02d5dfd0: ldr     x21, [x8, #8]                              
02d5dfd4: cbnz    x21, #0x2d5e030                            
02d5dfd8: ldr     w9, [x0, #0xe4]                            [626b0e4]=0 f=0,0
02d5dfdc: cbnz    w9, #0x2d5dfec                             
02d5dfe0: bl      #0x2b70f30                                 fn_2b70f30
02d5dfe4: ldr     x8, [x23]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d5dfe8: ldr     x8, [x8, #0xb8]                            
02d5dfec: adrp    x9, #0x626b000                             
02d5dff0: ldr     x9, [x9, #0xe08]                           T:type57224(k15)
02d5dff4: ldr     x22, [x8]                                  
02d5dff8: ldr     x0, [x9]                                   T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d5dffc: bl      #0x2b7104c                                 fn_2b7104c
02d5e000: adrp    x8, #0x626b000                             
02d5e004: mov     x1, x22                                    
02d5e008: mov     x3, xzr                                    
02d5e00c: ldr     x8, [x8, #0xe10]                           M:Clicker.BaseKeycapObject/<>c::<get_IsAssembleDone>b__23_0
02d5e010: mov     x21, x0                                    
02d5e014: ldr     x2, [x8]                                   T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d5e018: bl      #0x3998c00                                 fn_3998c00
02d5e01c: ldr     x8, [x23]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d5e020: mov     x1, x21                                    
02d5e024: ldr     x0, [x8, #0xb8]                            S:'scoop_no_thank'
02d5e028: str     x21, [x0, #8]!                             
02d5e02c: bl      #0x2b70d54                                 fn_2b70d54
02d5e030: cbz     x20, #0x2d5e10c                            
02d5e034: adrp    x24, #0x626b000                            
02d5e038: mov     x0, x20                                    
02d5e03c: mov     x1, x21                                    
02d5e040: ldr     x24, [x24, #0xe00]                         MS:System.Collections.Generic.List`1::TrueForAll
02d5e044: ldr     x2, [x24]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d5e048: bl      #0x4bb13b4                                 fn_4bb13b4
02d5e04c: tbz     w0, #0, #0x2d5e0f4                         
02d5e050: ldr     x0, [x23]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d5e054: ldr     x20, [x19, #0x70]                          ._keycapPlaced
02d5e058: ldr     w8, [x0, #0xe4]                            [626b0e4]=0 f=0,0
02d5e05c: cbnz    w8, #0x2d5e068                             
02d5e060: bl      #0x2b70f30                                 fn_2b70f30
02d5e064: ldr     x0, [x23]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d5e068: ldr     x8, [x0, #0xb8]                            S:'scoop_no_thank'
02d5e06c: ldr     x21, [x8, #0x10]                           MS:System.Collections.Generic.List`1::Find
02d5e070: cbnz    x21, #0x2d5e0cc                            
02d5e074: ldr     w9, [x0, #0xe4]                            [626b0e4]=0 f=0,0
02d5e078: cbnz    w9, #0x2d5e088                             
02d5e07c: bl      #0x2b70f30                                 fn_2b70f30
02d5e080: ldr     x8, [x23]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d5e084: ldr     x8, [x8, #0xb8]                            S:'scoop_no_thank'
02d5e088: adrp    x9, #0x626b000                             
02d5e08c: ldr     x9, [x9, #0xe08]                           T:type57224(k15)
02d5e090: ldr     x22, [x8]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d5e094: ldr     x0, [x9]                                   T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d5e098: bl      #0x2b7104c                                 fn_2b7104c
02d5e09c: adrp    x8, #0x626b000                             
02d5e0a0: mov     x1, x22                                    
02d5e0a4: mov     x3, xzr                                    
02d5e0a8: ldr     x8, [x8, #0xe18]                           M:Clicker.BaseKeycapObject/<>c::<get_IsAssembleDone>b__23_1
02d5e0ac: mov     x21, x0                                    
02d5e0b0: ldr     x2, [x8]                                   T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d5e0b4: bl      #0x3998c00                                 fn_3998c00
02d5e0b8: ldr     x8, [x23]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d5e0bc: mov     x1, x21                                    
02d5e0c0: ldr     x0, [x8, #0xb8]                            S:'scoop_no_thank'
02d5e0c4: str     x21, [x0, #0x10]!                          
02d5e0c8: bl      #0x2b70d54                                 fn_2b70d54
02d5e0cc: cbz     x20, #0x2d5e10c                            
02d5e0d0: ldr     x2, [x24]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d5e0d4: mov     x0, x20                                    
02d5e0d8: mov     x1, x21                                    
02d5e0dc: bl      #0x4bb13b4                                 fn_4bb13b4
02d5e0e0: tbz     w0, #0, #0x2d5e0f4                         
02d5e0e4: ldrb    w8, [x19, #0x80]                           ._keychainPlaced
02d5e0e8: cmp     w8, #0                                     
02d5e0ec: cset    w0, ne                                     
02d5e0f0: b       #0x2d5e0f8                                 
02d5e0f4: mov     w0, wzr                                    
02d5e0f8: ldp     x20, x19, [sp, #0x30]                      
02d5e0fc: ldp     x22, x21, [sp, #0x20]                      
02d5e100: ldp     x24, x23, [sp, #0x10]                      
02d5e104: ldr     x30, [sp], #0x40                           
02d5e108: ret                                                
02d5e10c: bl      #0x2b7105c                                 fn_2b7105c
## get_HandFollowClick() -> Clicker.HandFollowClick
---- Clicker.BaseKeycapObject::get_HandFollowClick 0x2d5e110
02d5e110: ldr     x0, [x0, #0x98]                            ._handFollowClick
02d5e114: ret                                                
## Awake() -> void
---- Clicker.BaseKeycapObject::Awake 0x2d5e118
02d5e118: stp     x30, x25, [sp, #-0x40]!                    
02d5e11c: stp     x24, x23, [sp, #0x10]                      
02d5e120: stp     x22, x21, [sp, #0x20]                      
02d5e124: stp     x20, x19, [sp, #0x30]                      
02d5e128: adrp    x20, #0x6630000                            
02d5e12c: mov     x19, x0                                    
02d5e130: ldrb    w8, [x20, #0x2e1]                          
02d5e134: tbnz    w8, #0, #0x2d5e1c4                         
02d5e138: adrp    x0, #0x626b000                             
02d5e13c: ldr     x0, [x0, #0xe20]                           T:type53140(k15)
02d5e140: bl      #0x2b70db0                                 fn_2b70db0
02d5e144: adrp    x0, #0x6269000                             
02d5e148: ldr     x0, [x0, #0x5e8]                           T:type6940(k15)
02d5e14c: bl      #0x2b70db0                                 fn_2b70db0
02d5e150: adrp    x0, #0x626b000                             
02d5e154: ldr     x0, [x0, #0xe28]                           T:type53160(k15)
02d5e158: bl      #0x2b70db0                                 fn_2b70db0
02d5e15c: adrp    x0, #0x626b000                             
02d5e160: ldr     x0, [x0, #0xe30]                           M:Clicker.BaseKeycapObject::OnSetupKeycap
02d5e164: bl      #0x2b70db0                                 fn_2b70db0
02d5e168: adrp    x0, #0x626b000                             
02d5e16c: ldr     x0, [x0, #0xe38]                           M:Clicker.BaseKeycapObject::<Awake>b__27_0
02d5e170: bl      #0x2b70db0                                 fn_2b70db0
02d5e174: adrp    x0, #0x626b000                             
02d5e178: ldr     x0, [x0, #0xe40]                           M:Clicker.BaseKeycapObject::<Awake>b__27_1
02d5e17c: bl      #0x2b70db0                                 fn_2b70db0
02d5e180: adrp    x0, #0x626b000                             
02d5e184: ldr     x0, [x0, #0xe48]                           MS:System.Collections.Generic.List`1::Clear
02d5e188: bl      #0x2b70db0                                 fn_2b70db0
02d5e18c: adrp    x0, #0x626b000                             
02d5e190: ldr     x0, [x0, #0xe50]                           MS:System.Collections.Generic.List`1::ForEach
02d5e194: bl      #0x2b70db0                                 fn_2b70db0
02d5e198: adrp    x0, #0x626b000                             
02d5e19c: ldr     x0, [x0, #0xe58]                           MS:System.Collections.Generic.List`1::ForEach
02d5e1a0: bl      #0x2b70db0                                 fn_2b70db0
02d5e1a4: adrp    x0, #0x626b000                             
02d5e1a8: ldr     x0, [x0, #0xe60]                           MS:System.Collections.Generic.List`1::get_Count
02d5e1ac: bl      #0x2b70db0                                 fn_2b70db0
02d5e1b0: adrp    x0, #0x626b000                             
02d5e1b4: ldr     x0, [x0, #0xe68]                           MS:System.Collections.Generic.List`1::get_Item
02d5e1b8: bl      #0x2b70db0                                 fn_2b70db0
02d5e1bc: mov     w8, #1                                     
02d5e1c0: strb    w8, [x20, #0x2e1]                          
02d5e1c4: ldr     x0, [x19, #0x20]                           ._srBaseKeycap
02d5e1c8: cbz     x0, #0x2d5e3c8                             
02d5e1cc: mov     x1, xzr                                    
02d5e1d0: bl      #0x5b339ec                                 UnityEngine.Component::get_gameObject
02d5e1d4: cbz     x0, #0x2d5e3c8                             
02d5e1d8: mov     w1, wzr                                    
02d5e1dc: mov     x2, xzr                                    
02d5e1e0: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d5e1e4: ldr     x0, [x19, #0x28]                           ._srBaseKeycapFront
02d5e1e8: cbz     x0, #0x2d5e3c8                             
02d5e1ec: mov     x1, xzr                                    
02d5e1f0: bl      #0x5b339ec                                 UnityEngine.Component::get_gameObject
02d5e1f4: cbz     x0, #0x2d5e3c8                             
02d5e1f8: mov     w1, wzr                                    
02d5e1fc: mov     x2, xzr                                    
02d5e200: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d5e204: ldr     x9, [x19, #0x48]                           ._switchPlaced
02d5e208: cbz     x9, #0x2d5e3c8                             
02d5e20c: ldr     w10, [x9, #0x1c]                           
02d5e210: ldr     x8, [x19, #0x70]                           ._keycapPlaced
02d5e214: add     w10, w10, #1                               
02d5e218: stp     wzr, w10, [x9, #0x18]                      
02d5e21c: cbz     x8, #0x2d5e3c8                             
02d5e220: adrp    x10, #0x626b000                            
02d5e224: ldr     w9, [x8, #0x1c]                            
02d5e228: adrp    x21, #0x626b000                            
02d5e22c: ldr     x10, [x10, #0xe28]                         T:type53160(k15)
02d5e230: ldr     x21, [x21, #0xe38]                         M:Clicker.BaseKeycapObject::<Awake>b__27_0
02d5e234: ldr     x20, [x19, #0x40]                          ._switchObjects
02d5e238: add     w9, w9, #1                                 
02d5e23c: ldr     x0, [x10]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d5e240: stp     wzr, w9, [x8, #0x18]                       
02d5e244: bl      #0x2b7104c                                 fn_2b7104c
02d5e248: ldr     x2, [x21]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d5e24c: mov     x1, x19                                    
02d5e250: mov     x3, xzr                                    
02d5e254: mov     x21, x0                                    
02d5e258: bl      #0x453418c                                 fn_453418c
02d5e25c: cbz     x20, #0x2d5e3c8                            
02d5e260: adrp    x8, #0x626b000                             
02d5e264: adrp    x22, #0x626b000                            
02d5e268: adrp    x23, #0x626b000                            
02d5e26c: ldr     x8, [x8, #0xe50]                           MS:System.Collections.Generic.List`1::ForEach
02d5e270: ldr     x22, [x22, #0xe20]                         T:type53140(k15)
02d5e274: ldr     x23, [x23, #0xe40]                         M:Clicker.BaseKeycapObject::<Awake>b__27_1
02d5e278: mov     x0, x20                                    
02d5e27c: mov     x1, x21                                    
02d5e280: ldr     x2, [x8]                                   T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d5e284: bl      #0x35a9ce4                                 fn_35a9ce4
02d5e288: ldr     x0, [x22]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d5e28c: ldr     x20, [x19, #0x68]                          ._keycapObjects
02d5e290: bl      #0x2b7104c                                 fn_2b7104c
02d5e294: ldr     x2, [x23]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d5e298: mov     x1, x19                                    
02d5e29c: mov     x3, xzr                                    
02d5e2a0: mov     x21, x0                                    
02d5e2a4: bl      #0x453418c                                 fn_453418c
02d5e2a8: cbz     x20, #0x2d5e3c8                            
02d5e2ac: adrp    x8, #0x626b000                             
02d5e2b0: mov     x0, x20                                    
02d5e2b4: mov     x1, x21                                    
02d5e2b8: ldr     x8, [x8, #0xe58]                           MS:System.Collections.Generic.List`1::ForEach
02d5e2bc: ldr     x2, [x8]                                   T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d5e2c0: bl      #0x35a9ce4                                 fn_35a9ce4
02d5e2c4: ldr     x0, [x19, #0x78]                           ._srKeychain
02d5e2c8: strb    wzr, [x19, #0x80]                          ._keychainPlaced
02d5e2cc: cbz     x0, #0x2d5e3c8                             
02d5e2d0: mov     x1, xzr                                    
02d5e2d4: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02d5e2d8: adrp    x21, #0x662f000                            
02d5e2dc: mov     x20, x0                                    
02d5e2e0: ldrb    w8, [x21, #0x91a]                          
02d5e2e4: cbnz    w8, #0x2d5e2fc                             
02d5e2e8: adrp    x0, #0x6264000                             
02d5e2ec: ldr     x0, [x0, #0xd8]                            T:UnityEngine.Vector3
02d5e2f0: bl      #0x2b70db0                                 fn_2b70db0
02d5e2f4: mov     w8, #1                                     
02d5e2f8: strb    w8, [x21, #0x91a]                          
02d5e2fc: cbz     x20, #0x2d5e3c8                            
02d5e300: adrp    x8, #0x6264000                             
02d5e304: mov     x0, x20                                    
02d5e308: mov     x1, xzr                                    
02d5e30c: ldr     x8, [x8, #0xd8]                            T:UnityEngine.Vector3
02d5e310: ldr     x8, [x8]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d5e314: ldr     x8, [x8, #0xb8]                            MS:DG.Tweening.Core.Extensions::SetSpecialStartupMode
02d5e318: ldp     s1, s2, [x8, #4]                           
02d5e31c: ldr     s0, [x8]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d5e320: bl      #0x5b470cc                                 UnityEngine.Transform::set_localScale
02d5e324: ldr     x0, [x19, #0x88]                           ._keycapClicks
02d5e328: cbz     x0, #0x2d5e3c8                             
02d5e32c: adrp    x23, #0x626b000                            
02d5e330: adrp    x24, #0x6269000                            
02d5e334: adrp    x25, #0x626b000                            
02d5e338: ldr     x23, [x23, #0xe68]                         MS:System.Collections.Generic.List`1::get_Item
02d5e33c: ldr     x24, [x24, #0x5e8]                         T:type6940(k15)
02d5e340: ldr     x25, [x25, #0xe30]                         M:Clicker.BaseKeycapObject::OnSetupKeycap
02d5e344: mov     w20, wzr                                   
02d5e348: ldr     w8, [x0, #0x18]                            M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass2_0::<DOSetFloat>b__1
02d5e34c: cmp     w20, w8                                    
02d5e350: b.ge    #0x2d5e3cc                                 
02d5e354: ldr     x2, [x23]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d5e358: mov     w1, w20                                    
02d5e35c: bl      #0x35a8f3c                                 fn_35a8f3c
02d5e360: cbz     x0, #0x2d5e3c8                             
02d5e364: mov     x1, x19                                    
02d5e368: str     x19, [x0, #0x48]!                          ._switchPlaced
02d5e36c: bl      #0x2b70d54                                 fn_2b70d54
02d5e370: ldr     x0, [x19, #0x88]                           ._keycapClicks
02d5e374: cbz     x0, #0x2d5e3c8                             
02d5e378: ldr     x2, [x23]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d5e37c: mov     w1, w20                                    
02d5e380: bl      #0x35a8f3c                                 fn_35a8f3c
02d5e384: ldr     x8, [x24]                                  T:Trading.TradingSession/<>c__DisplayClass56_0
02d5e388: mov     x21, x0                                    
02d5e38c: mov     x0, x8                                     
02d5e390: bl      #0x2b7104c                                 fn_2b7104c
02d5e394: ldr     x2, [x25]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d5e398: mov     x1, x19                                    
02d5e39c: mov     x3, xzr                                    
02d5e3a0: mov     x22, x0                                    
02d5e3a4: bl      #0x4532eb0                                 fn_4532eb0
02d5e3a8: cbz     x21, #0x2d5e3c8                            
02d5e3ac: mov     x0, x21                                    
02d5e3b0: mov     x1, x22                                    
02d5e3b4: mov     w2, w20                                    
02d5e3b8: bl      #0x2d5e3ec                                 Clicker.KeycapClick::SetButtonSetupEvent
02d5e3bc: ldr     x0, [x19, #0x88]                           ._keycapClicks
02d5e3c0: add     w20, w20, #1                               
02d5e3c4: cbnz    x0, #0x2d5e348                             
02d5e3c8: bl      #0x2b7105c                                 fn_2b7105c
02d5e3cc: ldr     x0, [x19, #0x98]                           ._handFollowClick
02d5e3d0: cbz     x0, #0x2d5e3c8                             
02d5e3d4: ldp     x20, x19, [sp, #0x30]                      
02d5e3d8: mov     w1, wzr                                    
02d5e3dc: ldp     x22, x21, [sp, #0x20]                      
02d5e3e0: ldp     x24, x23, [sp, #0x10]                      
02d5e3e4: ldp     x30, x25, [sp], #0x40                      
02d5e3e8: b       #0x2d5e4d8                                 Clicker.HandFollowClick::ShowHand
## ShowKeycapsOnly() -> void
---- Clicker.BaseKeycapObject::ShowKeycapsOnly 0x2d5e500
02d5e500: stp     d9, d8, [sp, #-0x40]!                      
02d5e504: stp     x30, x23, [sp, #0x10]                      
02d5e508: stp     x22, x21, [sp, #0x20]                      
02d5e50c: stp     x20, x19, [sp, #0x30]                      
02d5e510: adrp    x20, #0x6630000                            
02d5e514: mov     x19, x0                                    
02d5e518: ldrb    w8, [x20, #0x2e2]                          
02d5e51c: tbnz    w8, #0, #0x2d5e558                         
02d5e520: adrp    x0, #0x626b000                             
02d5e524: ldr     x0, [x0, #0xe80]                           MS:System.Collections.Generic.List`1::get_Count
02d5e528: bl      #0x2b70db0                                 fn_2b70db0
02d5e52c: adrp    x0, #0x626b000                             
02d5e530: ldr     x0, [x0, #0xe88]                           MS:System.Collections.Generic.List`1::get_Item
02d5e534: bl      #0x2b70db0                                 fn_2b70db0
02d5e538: adrp    x0, #0x6266000                             
02d5e53c: ldr     x0, [x0, #0xe08]                           MS:DG.Tweening.TweenSettingsExtensions::SetDelay
02d5e540: bl      #0x2b70db0                                 fn_2b70db0
02d5e544: adrp    x0, #0x6266000                             
02d5e548: ldr     x0, [x0, #0x880]                           MS:DG.Tweening.TweenSettingsExtensions::SetEase
02d5e54c: bl      #0x2b70db0                                 fn_2b70db0
02d5e550: mov     w8, #1                                     
02d5e554: strb    w8, [x20, #0x2e2]                          
02d5e558: ldr     x0, [x19, #0x20]                           ._srBaseKeycap
02d5e55c: cbz     x0, #0x2d5e628                             
02d5e560: mov     x1, xzr                                    
02d5e564: bl      #0x5b339ec                                 UnityEngine.Component::get_gameObject
02d5e568: cbz     x0, #0x2d5e628                             
02d5e56c: mov     w1, wzr                                    
02d5e570: mov     x2, xzr                                    
02d5e574: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d5e578: ldr     x0, [x19, #0x28]                           ._srBaseKeycapFront
02d5e57c: cbz     x0, #0x2d5e628                             
02d5e580: mov     x1, xzr                                    
02d5e584: bl      #0x5b339ec                                 UnityEngine.Component::get_gameObject
02d5e588: cbz     x0, #0x2d5e628                             
02d5e58c: mov     w1, wzr                                    
02d5e590: mov     x2, xzr                                    
02d5e594: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d5e598: ldr     x0, [x19, #0x68]                           ._keycapObjects
02d5e59c: cbz     x0, #0x2d5e628                             
02d5e5a0: adrp    x21, #0x626b000                            
02d5e5a4: adrp    x22, #0x6266000                            
02d5e5a8: adrp    x23, #0x6266000                            
02d5e5ac: adrp    x8, #0x1084000                             
02d5e5b0: adrp    x9, #0x1084000                             
02d5e5b4: ldr     x21, [x21, #0xe88]                         MS:System.Collections.Generic.List`1::get_Item
02d5e5b8: ldr     x22, [x22, #0xe08]                         MS:DG.Tweening.TweenSettingsExtensions::SetDelay
02d5e5bc: ldr     x23, [x23, #0x880]                         MS:DG.Tweening.TweenSettingsExtensions::SetEase
02d5e5c0: ldr     s8, [x8, #0xf10]                           [1084f10]=4110bc863e99999a f=0.3,9.04603
02d5e5c4: ldr     s9, [x9, #0xeec]                           [1084eec]=457ff0003dcccccd f=0.1,4095
02d5e5c8: mov     w20, wzr                                   
02d5e5cc: ldr     w8, [x0, #0x18]                            S:'level_show_popuprate'
02d5e5d0: cmp     w20, w8                                    
02d5e5d4: b.ge    #0x2d5e62c                                 
02d5e5d8: ldr     x2, [x21]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d5e5dc: mov     w1, w20                                    
02d5e5e0: bl      #0x35a8f3c                                 fn_35a8f3c
02d5e5e4: cbz     x0, #0x2d5e628                             
02d5e5e8: mov     x1, xzr                                    
02d5e5ec: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02d5e5f0: fmov    s1, s8                                     
02d5e5f4: fmov    s0, #1.00000000                            
02d5e5f8: mov     x1, xzr                                    
02d5e5fc: bl      #0x2d98c98                                 DG.Tweening.ShortcutExtensions::DOScale
02d5e600: scvtf   s0, w20                                    
02d5e604: ldr     x1, [x22]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d5e608: fmul    s0, s0, s9                                 
02d5e60c: bl      #0x336f7fc                                 fn_336f7fc
02d5e610: ldr     x2, [x23]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d5e614: mov     w1, #0x1b                                  
02d5e618: bl      #0x336fa0c                                 fn_336fa0c
02d5e61c: ldr     x0, [x19, #0x68]                           ._keycapObjects
02d5e620: add     w20, w20, #1                               
02d5e624: cbnz    x0, #0x2d5e5cc                             
02d5e628: bl      #0x2b7105c                                 fn_2b7105c
02d5e62c: ldp     x20, x19, [sp, #0x30]                      
02d5e630: ldp     x22, x21, [sp, #0x20]                      
02d5e634: ldp     x30, x23, [sp, #0x10]                      
02d5e638: ldp     d9, d8, [sp], #0x40                        
02d5e63c: ret                                                
## TurnModeSetup(bool isSetup) -> void
---- Clicker.BaseKeycapObject::TurnModeSetup 0x2d5cae8
02d5cae8: str     x30, [sp, #-0x30]!                         
02d5caec: stp     x22, x21, [sp, #0x10]                      
02d5caf0: stp     x20, x19, [sp, #0x20]                      
02d5caf4: adrp    x21, #0x6630000                            
02d5caf8: adrp    x22, #0x626b000                            
02d5cafc: mov     w19, w1                                    
02d5cb00: ldrb    w8, [x21, #0x2e3]                          
02d5cb04: ldr     x22, [x22, #0xd28]                         T:Clicker.BaseKeycapObject/<>c__DisplayClass29_0
02d5cb08: mov     x20, x0                                    
02d5cb0c: tbnz    w8, #0, #0x2d5cb48                         
02d5cb10: adrp    x0, #0x626b000                             
02d5cb14: ldr     x0, [x0, #0xd30]                           T:type53139(k15)
02d5cb18: bl      #0x2b70db0                                 fn_2b70db0
02d5cb1c: adrp    x0, #0x626b000                             
02d5cb20: ldr     x0, [x0, #0xd38]                           MS:System.Collections.Generic.List`1::ForEach
02d5cb24: bl      #0x2b70db0                                 fn_2b70db0
02d5cb28: adrp    x0, #0x626b000                             
02d5cb2c: ldr     x0, [x0, #0xd40]                           M:Clicker.BaseKeycapObject/<>c__DisplayClass29_0::<TurnModeSetup>b__0
02d5cb30: bl      #0x2b70db0                                 fn_2b70db0
02d5cb34: adrp    x0, #0x626b000                             
02d5cb38: ldr     x0, [x0, #0xd28]                           T:Clicker.BaseKeycapObject/<>c__DisplayClass29_0
02d5cb3c: bl      #0x2b70db0                                 fn_2b70db0
02d5cb40: mov     w8, #1                                     
02d5cb44: strb    w8, [x21, #0x2e3]                          
02d5cb48: ldr     x0, [x22]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d5cb4c: bl      #0x2b7104c                                 fn_2b7104c
02d5cb50: mov     x1, xzr                                    
02d5cb54: mov     x21, x0                                    
02d5cb58: bl      #0x4e53e9c                                 System.Object::.ctor
02d5cb5c: cbz     x21, #0x2d5cbc0                            
02d5cb60: adrp    x8, #0x626b000                             
02d5cb64: adrp    x22, #0x626b000                            
02d5cb68: and     w9, w19, #1                                
02d5cb6c: ldr     x8, [x8, #0xd30]                           T:type53139(k15)
02d5cb70: ldr     x22, [x22, #0xd40]                         M:Clicker.BaseKeycapObject/<>c__DisplayClass29_0::<TurnModeSetup>b__0
02d5cb74: ldr     x19, [x20, #0x88]                          ._keycapClicks
02d5cb78: strb    w9, [x21, #0x10]                           
02d5cb7c: ldr     x0, [x8]                                   T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d5cb80: bl      #0x2b7104c                                 fn_2b7104c
02d5cb84: ldr     x2, [x22]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d5cb88: mov     x1, x21                                    
02d5cb8c: mov     x3, xzr                                    
02d5cb90: mov     x20, x0                                    
02d5cb94: bl      #0x453418c                                 fn_453418c
02d5cb98: cbz     x19, #0x2d5cbc0                            
02d5cb9c: adrp    x8, #0x626b000                             
02d5cba0: mov     x0, x19                                    
02d5cba4: mov     x1, x20                                    
02d5cba8: ldr     x8, [x8, #0xd38]                           MS:System.Collections.Generic.List`1::ForEach
02d5cbac: ldp     x20, x19, [sp, #0x20]                      
02d5cbb0: ldp     x22, x21, [sp, #0x10]                      
02d5cbb4: ldr     x2, [x8]                                   T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d5cbb8: ldr     x30, [sp], #0x30                           
02d5cbbc: b       #0x35a9ce4                                 
02d5cbc0: bl      #0x2b7105c                                 fn_2b7105c
## RemoveSetupEvent() -> void
---- Clicker.BaseKeycapObject::RemoveSetupEvent 0x2d5e648
02d5e648: str     x30, [sp, #-0x30]!                         
02d5e64c: stp     x22, x21, [sp, #0x10]                      
02d5e650: stp     x20, x19, [sp, #0x20]                      
02d5e654: adrp    x20, #0x6630000                            
02d5e658: adrp    x22, #0x626b000                            
02d5e65c: mov     x19, x0                                    
02d5e660: ldrb    w8, [x20, #0x2e4]                          
02d5e664: ldr     x22, [x22, #0xdf8]                         T:Clicker.BaseKeycapObject/<>c
02d5e668: tbnz    w8, #0, #0x2d5e6a4                         
02d5e66c: adrp    x0, #0x626b000                             
02d5e670: ldr     x0, [x0, #0xd30]                           T:type53139(k15)
02d5e674: bl      #0x2b70db0                                 fn_2b70db0
02d5e678: adrp    x0, #0x626b000                             
02d5e67c: ldr     x0, [x0, #0xd38]                           MS:System.Collections.Generic.List`1::ForEach
02d5e680: bl      #0x2b70db0                                 fn_2b70db0
02d5e684: adrp    x0, #0x626b000                             
02d5e688: ldr     x0, [x0, #0xe90]                           M:Clicker.BaseKeycapObject/<>c::<RemoveSetupEvent>b__30_0
02d5e68c: bl      #0x2b70db0                                 fn_2b70db0
02d5e690: adrp    x0, #0x626b000                             
02d5e694: ldr     x0, [x0, #0xdf8]                           T:Clicker.BaseKeycapObject/<>c
02d5e698: bl      #0x2b70db0                                 fn_2b70db0
02d5e69c: mov     w8, #1                                     
02d5e6a0: strb    w8, [x20, #0x2e4]                          
02d5e6a4: ldr     x0, [x22]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d5e6a8: ldr     x19, [x19, #0x88]                          ._keycapClicks
02d5e6ac: ldr     w8, [x0, #0xe4]                            [626b0e4]=0 f=0,0
02d5e6b0: cbnz    w8, #0x2d5e6bc                             
02d5e6b4: bl      #0x2b70f30                                 fn_2b70f30
02d5e6b8: ldr     x0, [x22]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d5e6bc: ldr     x8, [x0, #0xb8]                            S:'scoop_no_thank'
02d5e6c0: ldr     x20, [x8, #0x18]                           
02d5e6c4: cbnz    x20, #0x2d5e720                            
02d5e6c8: ldr     w9, [x0, #0xe4]                            [626b0e4]=0 f=0,0
02d5e6cc: cbnz    w9, #0x2d5e6dc                             
02d5e6d0: bl      #0x2b70f30                                 fn_2b70f30
02d5e6d4: ldr     x8, [x22]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d5e6d8: ldr     x8, [x8, #0xb8]                            
02d5e6dc: adrp    x9, #0x626b000                             
02d5e6e0: ldr     x9, [x9, #0xd30]                           T:type53139(k15)
02d5e6e4: ldr     x21, [x8]                                  
02d5e6e8: ldr     x0, [x9]                                   T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d5e6ec: bl      #0x2b7104c                                 fn_2b7104c
02d5e6f0: adrp    x8, #0x626b000                             
02d5e6f4: mov     x1, x21                                    
02d5e6f8: mov     x3, xzr                                    
02d5e6fc: ldr     x8, [x8, #0xe90]                           M:Clicker.BaseKeycapObject/<>c::<RemoveSetupEvent>b__30_0
02d5e700: mov     x20, x0                                    
02d5e704: ldr     x2, [x8]                                   T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d5e708: bl      #0x453418c                                 fn_453418c
02d5e70c: ldr     x8, [x22]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d5e710: mov     x1, x20                                    
02d5e714: ldr     x0, [x8, #0xb8]                            S:'scoop_no_thank'
02d5e718: str     x20, [x0, #0x18]!                          
02d5e71c: bl      #0x2b70d54                                 fn_2b70d54
02d5e720: cbz     x19, #0x2d5e748                            
02d5e724: adrp    x8, #0x626b000                             
02d5e728: mov     x0, x19                                    
02d5e72c: mov     x1, x20                                    
02d5e730: ldr     x8, [x8, #0xd38]                           MS:System.Collections.Generic.List`1::ForEach
02d5e734: ldp     x20, x19, [sp, #0x20]                      
02d5e738: ldp     x22, x21, [sp, #0x10]                      
02d5e73c: ldr     x2, [x8]                                   T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d5e740: ldr     x30, [sp], #0x30                           
02d5e744: b       #0x35a9ce4                                 
02d5e748: bl      #0x2b7105c                                 fn_2b7105c
## HideKeycaps() -> void
---- Clicker.BaseKeycapObject::HideKeycaps 0x2d5e74c
02d5e74c: str     x30, [sp, #-0x30]!                         
02d5e750: stp     x22, x21, [sp, #0x10]                      
02d5e754: stp     x20, x19, [sp, #0x20]                      
02d5e758: adrp    x20, #0x6630000                            
02d5e75c: adrp    x22, #0x626b000                            
02d5e760: mov     x19, x0                                    
02d5e764: ldrb    w8, [x20, #0x2e5]                          
02d5e768: ldr     x22, [x22, #0xdf8]                         T:Clicker.BaseKeycapObject/<>c
02d5e76c: tbnz    w8, #0, #0x2d5e7a8                         
02d5e770: adrp    x0, #0x626b000                             
02d5e774: ldr     x0, [x0, #0xe20]                           T:type53140(k15)
02d5e778: bl      #0x2b70db0                                 fn_2b70db0
02d5e77c: adrp    x0, #0x626b000                             
02d5e780: ldr     x0, [x0, #0xe58]                           MS:System.Collections.Generic.List`1::ForEach
02d5e784: bl      #0x2b70db0                                 fn_2b70db0
02d5e788: adrp    x0, #0x626b000                             
02d5e78c: ldr     x0, [x0, #0xe98]                           M:Clicker.BaseKeycapObject/<>c::<HideKeycaps>b__31_0
02d5e790: bl      #0x2b70db0                                 fn_2b70db0
02d5e794: adrp    x0, #0x626b000                             
02d5e798: ldr     x0, [x0, #0xdf8]                           T:Clicker.BaseKeycapObject/<>c
02d5e79c: bl      #0x2b70db0                                 fn_2b70db0
02d5e7a0: mov     w8, #1                                     
02d5e7a4: strb    w8, [x20, #0x2e5]                          
02d5e7a8: ldr     x0, [x22]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d5e7ac: ldr     x19, [x19, #0x68]                          ._keycapObjects
02d5e7b0: ldr     w8, [x0, #0xe4]                            [626b0e4]=0 f=0,0
02d5e7b4: cbnz    w8, #0x2d5e7c0                             
02d5e7b8: bl      #0x2b70f30                                 fn_2b70f30
02d5e7bc: ldr     x0, [x22]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d5e7c0: ldr     x8, [x0, #0xb8]                            S:'scoop_no_thank'
02d5e7c4: ldr     x20, [x8, #0x20]                           
02d5e7c8: cbnz    x20, #0x2d5e824                            
02d5e7cc: ldr     w9, [x0, #0xe4]                            [626b0e4]=0 f=0,0
02d5e7d0: cbnz    w9, #0x2d5e7e0                             
02d5e7d4: bl      #0x2b70f30                                 fn_2b70f30
02d5e7d8: ldr     x8, [x22]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d5e7dc: ldr     x8, [x8, #0xb8]                            
02d5e7e0: adrp    x9, #0x626b000                             
02d5e7e4: ldr     x9, [x9, #0xe20]                           T:type53140(k15)
02d5e7e8: ldr     x21, [x8]                                  
02d5e7ec: ldr     x0, [x9]                                   T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d5e7f0: bl      #0x2b7104c                                 fn_2b7104c
02d5e7f4: adrp    x8, #0x626b000                             
02d5e7f8: mov     x1, x21                                    
02d5e7fc: mov     x3, xzr                                    
02d5e800: ldr     x8, [x8, #0xe98]                           M:Clicker.BaseKeycapObject/<>c::<HideKeycaps>b__31_0
02d5e804: mov     x20, x0                                    
02d5e808: ldr     x2, [x8]                                   T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d5e80c: bl      #0x453418c                                 fn_453418c
02d5e810: ldr     x8, [x22]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d5e814: mov     x1, x20                                    
02d5e818: ldr     x0, [x8, #0xb8]                            S:'scoop_no_thank'
02d5e81c: str     x20, [x0, #0x20]!                          ._srBaseKeycap
02d5e820: bl      #0x2b70d54                                 fn_2b70d54
02d5e824: cbz     x19, #0x2d5e84c                            
02d5e828: adrp    x8, #0x626b000                             
02d5e82c: mov     x0, x19                                    
02d5e830: mov     x1, x20                                    
02d5e834: ldr     x8, [x8, #0xe58]                           MS:System.Collections.Generic.List`1::ForEach
02d5e838: ldp     x20, x19, [sp, #0x20]                      
02d5e83c: ldp     x22, x21, [sp, #0x10]                      
02d5e840: ldr     x2, [x8]                                   T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d5e844: ldr     x30, [sp], #0x30                           
02d5e848: b       #0x35a9ce4                                 
02d5e84c: bl      #0x2b7105c                                 fn_2b7105c
## SetSwitch(UnityEngine.Sprite sprite) -> void
---- Clicker.BaseKeycapObject::SetSwitch 0x2d5e850
02d5e850: stp     x30, x23, [sp, #-0x30]!                    
02d5e854: stp     x22, x21, [sp, #0x10]                      
02d5e858: stp     x20, x19, [sp, #0x20]                      
02d5e85c: adrp    x21, #0x6630000                            
02d5e860: adrp    x22, #0x626b000                            
02d5e864: mov     x19, x1                                    
02d5e868: ldrb    w8, [x21, #0x2e6]                          
02d5e86c: ldr     x22, [x22, #0xea0]                         T:Clicker.BaseKeycapObject/<>c__DisplayClass32_0
02d5e870: mov     x20, x0                                    
02d5e874: tbnz    w8, #0, #0x2d5e8b0                         
02d5e878: adrp    x0, #0x626b000                             
02d5e87c: ldr     x0, [x0, #0xe28]                           T:type53160(k15)
02d5e880: bl      #0x2b70db0                                 fn_2b70db0
02d5e884: adrp    x0, #0x626b000                             
02d5e888: ldr     x0, [x0, #0xe50]                           MS:System.Collections.Generic.List`1::ForEach
02d5e88c: bl      #0x2b70db0                                 fn_2b70db0
02d5e890: adrp    x0, #0x626b000                             
02d5e894: ldr     x0, [x0, #0xea8]                           M:Clicker.BaseKeycapObject/<>c__DisplayClass32_0::<SetSwitch>b__0
02d5e898: bl      #0x2b70db0                                 fn_2b70db0
02d5e89c: adrp    x0, #0x626b000                             
02d5e8a0: ldr     x0, [x0, #0xea0]                           T:Clicker.BaseKeycapObject/<>c__DisplayClass32_0
02d5e8a4: bl      #0x2b70db0                                 fn_2b70db0
02d5e8a8: mov     w8, #1                                     
02d5e8ac: strb    w8, [x21, #0x2e6]                          
02d5e8b0: ldr     x0, [x22]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d5e8b4: bl      #0x2b7104c                                 fn_2b7104c
02d5e8b8: mov     x1, xzr                                    
02d5e8bc: mov     x21, x0                                    
02d5e8c0: bl      #0x4e53e9c                                 System.Object::.ctor
02d5e8c4: cbz     x21, #0x2d5e930                            
02d5e8c8: adrp    x22, #0x626b000                            
02d5e8cc: adrp    x23, #0x626b000                            
02d5e8d0: mov     x0, x21                                    
02d5e8d4: ldr     x22, [x22, #0xe28]                         T:type53160(k15)
02d5e8d8: ldr     x23, [x23, #0xea8]                         M:Clicker.BaseKeycapObject/<>c__DisplayClass32_0::<SetSwitch>b__0
02d5e8dc: mov     x1, x19                                    
02d5e8e0: str     x19, [x0, #0x10]!                          
02d5e8e4: bl      #0x2b70d54                                 fn_2b70d54
02d5e8e8: ldr     x0, [x22]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d5e8ec: ldr     x19, [x20, #0x40]                          ._switchObjects
02d5e8f0: bl      #0x2b7104c                                 fn_2b7104c
02d5e8f4: ldr     x2, [x23]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d5e8f8: mov     x1, x21                                    
02d5e8fc: mov     x3, xzr                                    
02d5e900: mov     x20, x0                                    
02d5e904: bl      #0x453418c                                 fn_453418c
02d5e908: cbz     x19, #0x2d5e930                            
02d5e90c: adrp    x8, #0x626b000                             
02d5e910: mov     x0, x19                                    
02d5e914: mov     x1, x20                                    
02d5e918: ldr     x8, [x8, #0xe50]                           MS:System.Collections.Generic.List`1::ForEach
02d5e91c: ldp     x20, x19, [sp, #0x20]                      
02d5e920: ldp     x22, x21, [sp, #0x10]                      
02d5e924: ldr     x2, [x8]                                   T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d5e928: ldp     x30, x23, [sp], #0x30                      
02d5e92c: b       #0x35a9ce4                                 
02d5e930: bl      #0x2b7105c                                 fn_2b7105c
## SetSwitchSound(Framework.ESound eSound) -> void
---- Clicker.BaseKeycapObject::SetSwitchSound 0x2d5e93c
02d5e93c: str     x30, [sp, #-0x30]!                         
02d5e940: stp     x22, x21, [sp, #0x10]                      
02d5e944: stp     x20, x19, [sp, #0x20]                      
02d5e948: adrp    x21, #0x6630000                            
02d5e94c: adrp    x22, #0x626b000                            
02d5e950: mov     w19, w1                                    
02d5e954: ldrb    w8, [x21, #0x2e7]                          
02d5e958: ldr     x22, [x22, #0xeb0]                         T:Clicker.BaseKeycapObject/<>c__DisplayClass33_0
02d5e95c: mov     x20, x0                                    
02d5e960: tbnz    w8, #0, #0x2d5e99c                         
02d5e964: adrp    x0, #0x626b000                             
02d5e968: ldr     x0, [x0, #0xd30]                           T:type53139(k15)
02d5e96c: bl      #0x2b70db0                                 fn_2b70db0
02d5e970: adrp    x0, #0x626b000                             
02d5e974: ldr     x0, [x0, #0xd38]                           MS:System.Collections.Generic.List`1::ForEach
02d5e978: bl      #0x2b70db0                                 fn_2b70db0
02d5e97c: adrp    x0, #0x626b000                             
02d5e980: ldr     x0, [x0, #0xeb8]                           M:Clicker.BaseKeycapObject/<>c__DisplayClass33_0::<SetSwitchSound>b__0
02d5e984: bl      #0x2b70db0                                 fn_2b70db0
02d5e988: adrp    x0, #0x626b000                             
02d5e98c: ldr     x0, [x0, #0xeb0]                           T:Clicker.BaseKeycapObject/<>c__DisplayClass33_0
02d5e990: bl      #0x2b70db0                                 fn_2b70db0
02d5e994: mov     w8, #1                                     
02d5e998: strb    w8, [x21, #0x2e7]                          
02d5e99c: ldr     x0, [x22]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d5e9a0: bl      #0x2b7104c                                 fn_2b7104c
02d5e9a4: mov     x1, xzr                                    
02d5e9a8: mov     x21, x0                                    
02d5e9ac: bl      #0x4e53e9c                                 System.Object::.ctor
02d5e9b0: cbz     x21, #0x2d5ea10                            
02d5e9b4: adrp    x8, #0x626b000                             
02d5e9b8: adrp    x22, #0x626b000                            
02d5e9bc: ldr     x8, [x8, #0xd30]                           T:type53139(k15)
02d5e9c0: ldr     x22, [x22, #0xeb8]                         M:Clicker.BaseKeycapObject/<>c__DisplayClass33_0::<SetSwitchSound>b__0
02d5e9c4: ldr     x20, [x20, #0x88]                          ._keycapClicks
02d5e9c8: str     w19, [x21, #0x10]                          
02d5e9cc: ldr     x0, [x8]                                   T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d5e9d0: bl      #0x2b7104c                                 fn_2b7104c
02d5e9d4: ldr     x2, [x22]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d5e9d8: mov     x1, x21                                    
02d5e9dc: mov     x3, xzr                                    
02d5e9e0: mov     x19, x0                                    
02d5e9e4: bl      #0x453418c                                 fn_453418c
02d5e9e8: cbz     x20, #0x2d5ea10                            
02d5e9ec: adrp    x8, #0x626b000                             
02d5e9f0: mov     x0, x20                                    
02d5e9f4: mov     x1, x19                                    
02d5e9f8: ldr     x8, [x8, #0xd38]                           MS:System.Collections.Generic.List`1::ForEach
02d5e9fc: ldp     x20, x19, [sp, #0x20]                      
02d5ea00: ldp     x22, x21, [sp, #0x10]                      
02d5ea04: ldr     x2, [x8]                                   T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d5ea08: ldr     x30, [sp], #0x30                           
02d5ea0c: b       #0x35a9ce4                                 
02d5ea10: bl      #0x2b7105c                                 fn_2b7105c
## SetKeycap(UnityEngine.Sprite sprite, Clicker.DecorKeycapType decorType) -> void
---- Clicker.BaseKeycapObject::SetKeycap 0x2d5ea1c
02d5ea1c: stp     x30, x23, [sp, #-0x30]!                    
02d5ea20: stp     x22, x21, [sp, #0x10]                      
02d5ea24: stp     x20, x19, [sp, #0x20]                      
02d5ea28: adrp    x22, #0x6630000                            
02d5ea2c: mov     w19, w2                                    
02d5ea30: mov     x20, x1                                    
02d5ea34: ldrb    w8, [x22, #0x2e8]                          
02d5ea38: mov     x21, x0                                    
02d5ea3c: tbnz    w8, #0, #0x2d5ea60                         
02d5ea40: adrp    x0, #0x626b000                             
02d5ea44: ldr     x0, [x0, #0xe80]                           MS:System.Collections.Generic.List`1::get_Count
02d5ea48: bl      #0x2b70db0                                 fn_2b70db0
02d5ea4c: adrp    x0, #0x626b000                             
02d5ea50: ldr     x0, [x0, #0xe88]                           MS:System.Collections.Generic.List`1::get_Item
02d5ea54: bl      #0x2b70db0                                 fn_2b70db0
02d5ea58: mov     w8, #1                                     
02d5ea5c: strb    w8, [x22, #0x2e8]                          
02d5ea60: ldr     x0, [x21, #0x68]                           ._keycapObjects
02d5ea64: cbz     x0, #0x2d5eaac                             
02d5ea68: adrp    x23, #0x626b000                            
02d5ea6c: mov     w22, wzr                                   
02d5ea70: ldr     x23, [x23, #0xe88]                         MS:System.Collections.Generic.List`1::get_Item
02d5ea74: ldr     w8, [x0, #0x18]                            T:type57265(k15)
02d5ea78: cmp     w22, w8                                    
02d5ea7c: b.ge    #0x2d5eab0                                 
02d5ea80: ldr     x2, [x23]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d5ea84: mov     w1, w22                                    
02d5ea88: bl      #0x35a8f3c                                 fn_35a8f3c
02d5ea8c: cbz     x0, #0x2d5eaac                             
02d5ea90: mov     x1, x20                                    
02d5ea94: mov     w2, w19                                    
02d5ea98: mov     w3, #-1                                    
02d5ea9c: bl      #0x2d5eac0                                 Clicker.KeycapObject::SetDecor
02d5eaa0: ldr     x0, [x21, #0x68]                           ._keycapObjects
02d5eaa4: add     w22, w22, #1                               
02d5eaa8: cbnz    x0, #0x2d5ea74                             
02d5eaac: bl      #0x2b7105c                                 fn_2b7105c
02d5eab0: ldp     x20, x19, [sp, #0x20]                      
02d5eab4: ldp     x22, x21, [sp, #0x10]                      
02d5eab8: ldp     x30, x23, [sp], #0x30                      
02d5eabc: ret                                                
## SetKeycapIndex(int index, UnityEngine.Sprite sprite, Clicker.DecorKeycapType decorType, int decorId) -> void
---- Clicker.BaseKeycapObject::SetKeycapIndex 0x2d5ed04
02d5ed04: str     x30, [sp, #-0x40]!                         
02d5ed08: stp     x24, x23, [sp, #0x10]                      
02d5ed0c: stp     x22, x21, [sp, #0x20]                      
02d5ed10: stp     x20, x19, [sp, #0x30]                      
02d5ed14: adrp    x24, #0x6630000                            
02d5ed18: mov     w19, w4                                    
02d5ed1c: mov     w20, w3                                    
02d5ed20: ldrb    w8, [x24, #0x2e9]                          
02d5ed24: mov     x21, x2                                    
02d5ed28: mov     w22, w1                                    
02d5ed2c: mov     x23, x0                                    
02d5ed30: tbnz    w8, #0, #0x2d5ed48                         
02d5ed34: adrp    x0, #0x626b000                             
02d5ed38: ldr     x0, [x0, #0xe88]                           MS:System.Collections.Generic.List`1::get_Item
02d5ed3c: bl      #0x2b70db0                                 fn_2b70db0
02d5ed40: mov     w8, #1                                     
02d5ed44: strb    w8, [x24, #0x2e9]                          
02d5ed48: ldr     x0, [x23, #0x68]                           
02d5ed4c: cbz     x0, #0x2d5ed88                             
02d5ed50: adrp    x8, #0x626b000                             
02d5ed54: mov     w1, w22                                    
02d5ed58: ldr     x8, [x8, #0xe88]                           MS:System.Collections.Generic.List`1::get_Item
02d5ed5c: ldr     x2, [x8]                                   T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d5ed60: bl      #0x35a8f3c                                 fn_35a8f3c
02d5ed64: cbz     x0, #0x2d5ed88                             
02d5ed68: mov     x1, x21                                    
02d5ed6c: mov     w2, w20                                    
02d5ed70: mov     w3, w19                                    
02d5ed74: ldp     x20, x19, [sp, #0x30]                      
02d5ed78: ldp     x22, x21, [sp, #0x20]                      
02d5ed7c: ldp     x24, x23, [sp, #0x10]                      
02d5ed80: ldr     x30, [sp], #0x40                           
02d5ed84: b       #0x2d5eac0                                 Clicker.KeycapObject::SetDecor
02d5ed88: bl      #0x2b7105c                                 fn_2b7105c
## SetKeychain(UnityEngine.Sprite sprite) -> void
---- Clicker.BaseKeycapObject::SetKeychain 0x2d5ed8c
02d5ed8c: ldr     x0, [x0, #0x78]                            ._srKeychain
02d5ed90: cbz     x0, #0x2d5ed9c                             
02d5ed94: mov     x2, xzr                                    
02d5ed98: b       #0x5ae6dcc                                 UnityEngine.SpriteRenderer::set_sprite
02d5ed9c: str     x30, [sp, #-0x10]!                         
02d5eda0: bl      #0x2b7105c                                 fn_2b7105c
## ShowAll() -> void
---- Clicker.BaseKeycapObject::ShowAll 0x2d5eda4
02d5eda4: str     d8, [sp, #-0x40]!                          
02d5eda8: str     x30, [sp, #8]                              
02d5edac: stp     x24, x23, [sp, #0x10]                      
02d5edb0: stp     x22, x21, [sp, #0x20]                      
02d5edb4: stp     x20, x19, [sp, #0x30]                      
02d5edb8: adrp    x20, #0x6630000                            
02d5edbc: mov     x19, x0                                    
02d5edc0: ldrb    w8, [x20, #0x2ea]                          
02d5edc4: tbnz    w8, #0, #0x2d5ee18                         
02d5edc8: adrp    x0, #0x626b000                             
02d5edcc: ldr     x0, [x0, #0xe80]                           MS:System.Collections.Generic.List`1::get_Count
02d5edd0: bl      #0x2b70db0                                 fn_2b70db0
02d5edd4: adrp    x0, #0x626b000                             
02d5edd8: ldr     x0, [x0, #0xec0]                           MS:System.Collections.Generic.List`1::get_Count
02d5eddc: bl      #0x2b70db0                                 fn_2b70db0
02d5ede0: adrp    x0, #0x626b000                             
02d5ede4: ldr     x0, [x0, #0xec8]                           MS:System.Collections.Generic.List`1::get_Item
02d5ede8: bl      #0x2b70db0                                 fn_2b70db0
02d5edec: adrp    x0, #0x626b000                             
02d5edf0: ldr     x0, [x0, #0xe88]                           MS:System.Collections.Generic.List`1::get_Item
02d5edf4: bl      #0x2b70db0                                 fn_2b70db0
02d5edf8: adrp    x0, #0x6266000                             
02d5edfc: ldr     x0, [x0, #0xe08]                           MS:DG.Tweening.TweenSettingsExtensions::SetDelay
02d5ee00: bl      #0x2b70db0                                 fn_2b70db0
02d5ee04: adrp    x0, #0x6266000                             
02d5ee08: ldr     x0, [x0, #0x880]                           MS:DG.Tweening.TweenSettingsExtensions::SetEase
02d5ee0c: bl      #0x2b70db0                                 fn_2b70db0
02d5ee10: mov     w8, #1                                     
02d5ee14: strb    w8, [x20, #0x2ea]                          
02d5ee18: ldr     x0, [x19, #0x20]                           ._srBaseKeycap
02d5ee1c: cbz     x0, #0x2d5ef6c                             
02d5ee20: mov     x1, xzr                                    
02d5ee24: bl      #0x5b339ec                                 UnityEngine.Component::get_gameObject
02d5ee28: cbz     x0, #0x2d5ef6c                             
02d5ee2c: mov     w1, #1                                     
02d5ee30: mov     x2, xzr                                    
02d5ee34: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d5ee38: ldr     x0, [x19, #0x28]                           ._srBaseKeycapFront
02d5ee3c: cbz     x0, #0x2d5ef6c                             
02d5ee40: mov     x1, xzr                                    
02d5ee44: bl      #0x5b339ec                                 UnityEngine.Component::get_gameObject
02d5ee48: cbz     x0, #0x2d5ef6c                             
02d5ee4c: mov     w1, #1                                     
02d5ee50: mov     x2, xzr                                    
02d5ee54: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d5ee58: ldr     x0, [x19, #0x40]                           ._switchObjects
02d5ee5c: cbz     x0, #0x2d5ef6c                             
02d5ee60: adrp    x24, #0x626b000                            
02d5ee64: adrp    x22, #0x6266000                            
02d5ee68: adrp    x21, #0x6266000                            
02d5ee6c: adrp    x8, #0x1084000                             
02d5ee70: adrp    x23, #0x626b000                            
02d5ee74: ldr     x24, [x24, #0xec8]                         MS:System.Collections.Generic.List`1::get_Item
02d5ee78: ldr     x22, [x22, #0x880]                         MS:DG.Tweening.TweenSettingsExtensions::SetEase
02d5ee7c: ldr     x21, [x21, #0xe08]                         MS:DG.Tweening.TweenSettingsExtensions::SetDelay
02d5ee80: ldr     x23, [x23, #0xe88]                         MS:System.Collections.Generic.List`1::get_Item
02d5ee84: ldr     s8, [x8, #0xeec]                           [1084eec]=457ff0003dcccccd f=0.1,4095
02d5ee88: mov     w20, wzr                                   
02d5ee8c: ldr     w8, [x0, #0x18]                            S:'level_show_popuprate'
02d5ee90: cmp     w20, w8                                    
02d5ee94: b.ge    #0x2d5eeec                                 
02d5ee98: ldr     x2, [x24]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d5ee9c: mov     w1, w20                                    
02d5eea0: bl      #0x35a8f3c                                 fn_35a8f3c
02d5eea4: cbz     x0, #0x2d5ef6c                             
02d5eea8: mov     x1, xzr                                    
02d5eeac: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02d5eeb0: fmov    s0, #1.00000000                            
02d5eeb4: fmov    s1, #0.50000000                            
02d5eeb8: mov     x1, xzr                                    
02d5eebc: bl      #0x2d98c98                                 DG.Tweening.ShortcutExtensions::DOScale
02d5eec0: ldr     x2, [x22]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d5eec4: mov     w1, #0x1b                                  
02d5eec8: bl      #0x336fa0c                                 fn_336fa0c
02d5eecc: scvtf   s0, w20                                    
02d5eed0: ldr     x1, [x21]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d5eed4: fmul    s0, s0, s8                                 
02d5eed8: bl      #0x336f7fc                                 fn_336f7fc
02d5eedc: ldr     x0, [x19, #0x40]                           ._switchObjects
02d5eee0: add     w20, w20, #1                               
02d5eee4: cbnz    x0, #0x2d5ee8c                             
02d5eee8: b       #0x2d5ef6c                                 
02d5eeec: ldr     x0, [x19, #0x68]                           ._keycapObjects
02d5eef0: cbz     x0, #0x2d5ef6c                             
02d5eef4: mov     w20, wzr                                   
02d5eef8: ldr     w8, [x0, #0x18]                            S:'level_show_popuprate'
02d5eefc: cmp     w20, w8                                    
02d5ef00: b.ge    #0x2d5ef70                                 
02d5ef04: ldr     x2, [x23]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d5ef08: mov     w1, w20                                    
02d5ef0c: bl      #0x35a8f3c                                 fn_35a8f3c
02d5ef10: cbz     x0, #0x2d5ef6c                             
02d5ef14: mov     x1, xzr                                    
02d5ef18: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02d5ef1c: fmov    s0, #1.00000000                            
02d5ef20: fmov    s1, #0.50000000                            
02d5ef24: mov     x1, xzr                                    
02d5ef28: bl      #0x2d98c98                                 DG.Tweening.ShortcutExtensions::DOScale
02d5ef2c: ldr     x2, [x22]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d5ef30: mov     w1, #0x1b                                  
02d5ef34: bl      #0x336fa0c                                 fn_336fa0c
02d5ef38: ldr     x8, [x19, #0x40]                           ._switchObjects
02d5ef3c: cbz     x8, #0x2d5ef6c                             
02d5ef40: ldr     s0, [x8, #0x18]                            [1084018]=7974696c69745549 f=1.84613e+25,7.93162e+34
02d5ef44: scvtf   s1, w20                                    
02d5ef48: ldr     x1, [x21]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d5ef4c: scvtf   s0, s0                                     
02d5ef50: fmul    s1, s1, s8                                 
02d5ef54: fmul    s0, s0, s8                                 
02d5ef58: fadd    s0, s1, s0                                 
02d5ef5c: bl      #0x336f7fc                                 fn_336f7fc
02d5ef60: ldr     x0, [x19, #0x68]                           ._keycapObjects
02d5ef64: add     w20, w20, #1                               
02d5ef68: cbnz    x0, #0x2d5eef8                             
02d5ef6c: bl      #0x2b7105c                                 fn_2b7105c
02d5ef70: ldr     x0, [x19, #0x78]                           ._srKeychain
02d5ef74: cbz     x0, #0x2d5ef6c                             
02d5ef78: mov     x1, xzr                                    
02d5ef7c: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02d5ef80: fmov    s0, #1.00000000                            
02d5ef84: fmov    s1, #0.50000000                            
02d5ef88: mov     x1, xzr                                    
02d5ef8c: bl      #0x2d98c98                                 DG.Tweening.ShortcutExtensions::DOScale
02d5ef90: ldr     x2, [x22]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d5ef94: mov     w1, #0x1b                                  
02d5ef98: bl      #0x336fa0c                                 fn_336fa0c
02d5ef9c: ldr     x8, [x19, #0x40]                           ._switchObjects
02d5efa0: cbz     x8, #0x2d5ef6c                             
02d5efa4: ldr     x9, [x19, #0x68]                           ._keycapObjects
02d5efa8: cbz     x9, #0x2d5ef6c                             
02d5efac: ldr     s0, [x8, #0x18]                            [1084018]=7974696c69745549 f=1.84613e+25,7.93162e+34
02d5efb0: ldr     s1, [x9, #0x18]                            
02d5efb4: ldr     x1, [x21]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d5efb8: ldp     x20, x19, [sp, #0x30]                      
02d5efbc: ldr     x30, [sp, #8]                              
02d5efc0: scvtf   s0, s0                                     
02d5efc4: scvtf   s1, s1                                     
02d5efc8: ldp     x22, x21, [sp, #0x20]                      
02d5efcc: ldp     x24, x23, [sp, #0x10]                      
02d5efd0: fmul    s0, s0, s8                                 
02d5efd4: fmul    s1, s1, s8                                 
02d5efd8: fadd    s0, s0, s1                                 
02d5efdc: ldr     d8, [sp], #0x40                            
02d5efe0: b       #0x336f7fc                                 
## ShowAllNoAnim() -> void
---- Clicker.BaseKeycapObject::ShowAllNoAnim 0x2d5efe4
02d5efe4: stp     x30, x23, [sp, #-0x30]!                    
02d5efe8: stp     x22, x21, [sp, #0x10]                      
02d5efec: stp     x20, x19, [sp, #0x20]                      
02d5eff0: adrp    x20, #0x6630000                            
02d5eff4: mov     x19, x0                                    
02d5eff8: ldrb    w8, [x20, #0x2eb]                          
02d5effc: tbnz    w8, #0, #0x2d5f068                         
02d5f000: adrp    x0, #0x626b000                             
02d5f004: ldr     x0, [x0, #0xe20]                           T:type53140(k15)
02d5f008: bl      #0x2b70db0                                 fn_2b70db0
02d5f00c: adrp    x0, #0x626b000                             
02d5f010: ldr     x0, [x0, #0xe28]                           T:type53160(k15)
02d5f014: bl      #0x2b70db0                                 fn_2b70db0
02d5f018: adrp    x0, #0x626b000                             
02d5f01c: ldr     x0, [x0, #0xe50]                           MS:System.Collections.Generic.List`1::ForEach
02d5f020: bl      #0x2b70db0                                 fn_2b70db0
02d5f024: adrp    x0, #0x626b000                             
02d5f028: ldr     x0, [x0, #0xe58]                           MS:System.Collections.Generic.List`1::ForEach
02d5f02c: bl      #0x2b70db0                                 fn_2b70db0
02d5f030: adrp    x0, #0x626b000                             
02d5f034: ldr     x0, [x0, #0xe60]                           MS:System.Collections.Generic.List`1::get_Count
02d5f038: bl      #0x2b70db0                                 fn_2b70db0
02d5f03c: adrp    x0, #0x626b000                             
02d5f040: ldr     x0, [x0, #0xed0]                           M:Clicker.BaseKeycapObject/<>c::<ShowAllNoAnim>b__38_0
02d5f044: bl      #0x2b70db0                                 fn_2b70db0
02d5f048: adrp    x0, #0x626b000                             
02d5f04c: ldr     x0, [x0, #0xed8]                           M:Clicker.BaseKeycapObject/<>c::<ShowAllNoAnim>b__38_1
02d5f050: bl      #0x2b70db0                                 fn_2b70db0
02d5f054: adrp    x0, #0x626b000                             
02d5f058: ldr     x0, [x0, #0xdf8]                           T:Clicker.BaseKeycapObject/<>c
02d5f05c: bl      #0x2b70db0                                 fn_2b70db0
02d5f060: mov     w8, #1                                     
02d5f064: strb    w8, [x20, #0x2eb]                          
02d5f068: ldr     x0, [x19, #0x20]                           ._srBaseKeycap
02d5f06c: cbz     x0, #0x2d5f274                             
02d5f070: mov     x1, xzr                                    
02d5f074: bl      #0x5b339ec                                 UnityEngine.Component::get_gameObject
02d5f078: cbz     x0, #0x2d5f274                             
02d5f07c: mov     w1, #1                                     
02d5f080: mov     x2, xzr                                    
02d5f084: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d5f088: ldr     x0, [x19, #0x28]                           ._srBaseKeycapFront
02d5f08c: cbz     x0, #0x2d5f274                             
02d5f090: mov     x1, xzr                                    
02d5f094: bl      #0x5b339ec                                 UnityEngine.Component::get_gameObject
02d5f098: cbz     x0, #0x2d5f274                             
02d5f09c: adrp    x23, #0x626b000                            
02d5f0a0: mov     w1, #1                                     
02d5f0a4: mov     x2, xzr                                    
02d5f0a8: ldr     x23, [x23, #0xdf8]                         T:Clicker.BaseKeycapObject/<>c
02d5f0ac: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d5f0b0: ldr     x0, [x23]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d5f0b4: ldr     x20, [x19, #0x40]                          ._switchObjects
02d5f0b8: ldr     w8, [x0, #0xe4]                            [626b0e4]=0 f=0,0
02d5f0bc: cbnz    w8, #0x2d5f0c8                             
02d5f0c0: bl      #0x2b70f30                                 fn_2b70f30
02d5f0c4: ldr     x0, [x23]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d5f0c8: ldr     x8, [x0, #0xb8]                            S:'scoop_no_thank'
02d5f0cc: ldr     x21, [x8, #0x28]                           
02d5f0d0: cbnz    x21, #0x2d5f12c                            
02d5f0d4: ldr     w9, [x0, #0xe4]                            [626b0e4]=0 f=0,0
02d5f0d8: cbnz    w9, #0x2d5f0e8                             
02d5f0dc: bl      #0x2b70f30                                 fn_2b70f30
02d5f0e0: ldr     x8, [x23]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d5f0e4: ldr     x8, [x8, #0xb8]                            
02d5f0e8: adrp    x9, #0x626b000                             
02d5f0ec: ldr     x9, [x9, #0xe28]                           T:type53160(k15)
02d5f0f0: ldr     x22, [x8]                                  
02d5f0f4: ldr     x0, [x9]                                   T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d5f0f8: bl      #0x2b7104c                                 fn_2b7104c
02d5f0fc: adrp    x8, #0x626b000                             
02d5f100: mov     x1, x22                                    
02d5f104: mov     x3, xzr                                    
02d5f108: ldr     x8, [x8, #0xed0]                           M:Clicker.BaseKeycapObject/<>c::<ShowAllNoAnim>b__38_0
02d5f10c: mov     x21, x0                                    
02d5f110: ldr     x2, [x8]                                   T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d5f114: bl      #0x453418c                                 fn_453418c
02d5f118: ldr     x8, [x23]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d5f11c: mov     x1, x21                                    
02d5f120: ldr     x0, [x8, #0xb8]                            S:'scoop_no_thank'
02d5f124: str     x21, [x0, #0x28]!                          ._srBaseKeycapFront
02d5f128: bl      #0x2b70d54                                 fn_2b70d54
02d5f12c: cbz     x20, #0x2d5f274                            
02d5f130: adrp    x8, #0x626b000                             
02d5f134: mov     x0, x20                                    
02d5f138: mov     x1, x21                                    
02d5f13c: ldr     x8, [x8, #0xe50]                           MS:System.Collections.Generic.List`1::ForEach
02d5f140: ldr     x2, [x8]                                   T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d5f144: bl      #0x35a9ce4                                 fn_35a9ce4
02d5f148: ldr     x0, [x23]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d5f14c: ldr     x20, [x19, #0x68]                          ._keycapObjects
02d5f150: ldr     w8, [x0, #0xe4]                            [626b0e4]=0 f=0,0
02d5f154: cbnz    w8, #0x2d5f160                             
02d5f158: bl      #0x2b70f30                                 fn_2b70f30
02d5f15c: ldr     x0, [x23]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d5f160: ldr     x8, [x0, #0xb8]                            S:'scoop_no_thank'
02d5f164: ldr     x21, [x8, #0x30]                           MS:System.Collections.Generic.List`1::IndexOf
02d5f168: cbnz    x21, #0x2d5f1c4                            
02d5f16c: ldr     w9, [x0, #0xe4]                            [626b0e4]=0 f=0,0
02d5f170: cbnz    w9, #0x2d5f180                             
02d5f174: bl      #0x2b70f30                                 fn_2b70f30
02d5f178: ldr     x8, [x23]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d5f17c: ldr     x8, [x8, #0xb8]                            S:'scoop_no_thank'
02d5f180: adrp    x9, #0x626b000                             
02d5f184: ldr     x9, [x9, #0xe20]                           T:type53140(k15)
02d5f188: ldr     x22, [x8]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d5f18c: ldr     x0, [x9]                                   T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d5f190: bl      #0x2b7104c                                 fn_2b7104c
02d5f194: adrp    x8, #0x626b000                             
02d5f198: mov     x1, x22                                    
02d5f19c: mov     x3, xzr                                    
02d5f1a0: ldr     x8, [x8, #0xed8]                           M:Clicker.BaseKeycapObject/<>c::<ShowAllNoAnim>b__38_1
02d5f1a4: mov     x21, x0                                    
02d5f1a8: ldr     x2, [x8]                                   T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d5f1ac: bl      #0x453418c                                 fn_453418c
02d5f1b0: ldr     x8, [x23]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d5f1b4: mov     x1, x21                                    
02d5f1b8: ldr     x0, [x8, #0xb8]                            S:'scoop_no_thank'
02d5f1bc: str     x21, [x0, #0x30]!                          ._switchSoundName
02d5f1c0: bl      #0x2b70d54                                 fn_2b70d54
02d5f1c4: cbz     x20, #0x2d5f274                            
02d5f1c8: adrp    x8, #0x626b000                             
02d5f1cc: mov     x0, x20                                    
02d5f1d0: mov     x1, x21                                    
02d5f1d4: ldr     x8, [x8, #0xe58]                           MS:System.Collections.Generic.List`1::ForEach
02d5f1d8: ldr     x2, [x8]                                   T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d5f1dc: bl      #0x35a9ce4                                 fn_35a9ce4
02d5f1e0: ldr     x0, [x19, #0x78]                           ._srKeychain
02d5f1e4: mov     w8, #1                                     
02d5f1e8: strb    w8, [x19, #0x80]                           ._keychainPlaced
02d5f1ec: cbz     x0, #0x2d5f274                             
02d5f1f0: mov     x1, xzr                                    
02d5f1f4: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02d5f1f8: adrp    x21, #0x662f000                            
02d5f1fc: mov     x20, x0                                    
02d5f200: ldrb    w8, [x21, #0xa74]                          
02d5f204: cbnz    w8, #0x2d5f21c                             
02d5f208: adrp    x0, #0x6264000                             
02d5f20c: ldr     x0, [x0, #0xd8]                            T:UnityEngine.Vector3
02d5f210: bl      #0x2b70db0                                 fn_2b70db0
02d5f214: mov     w8, #1                                     
02d5f218: strb    w8, [x21, #0xa74]                          
02d5f21c: cbz     x20, #0x2d5f274                            
02d5f220: adrp    x8, #0x6264000                             
02d5f224: mov     x0, x20                                    
02d5f228: mov     x1, xzr                                    
02d5f22c: ldr     x8, [x8, #0xd8]                            T:UnityEngine.Vector3
02d5f230: ldr     x8, [x8]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d5f234: ldr     x8, [x8, #0xb8]                            MS:DG.Tweening.Core.Extensions::SetSpecialStartupMode
02d5f238: ldp     s1, s2, [x8, #0x10]                        
02d5f23c: ldr     s0, [x8, #0xc]                             [626400c]=0 f=0,0
02d5f240: bl      #0x5b470cc                                 UnityEngine.Transform::set_localScale
02d5f244: ldr     x8, [x19, #0x88]                           ._keycapClicks
02d5f248: cbz     x8, #0x2d5f274                             
02d5f24c: mov     x0, x19                                    
02d5f250: mov     w1, #1                                     
02d5f254: bl      #0x2d5cae8                                 Clicker.BaseKeycapObject::TurnModeSetup
02d5f258: ldr     x0, [x19, #0x98]                           ._handFollowClick
02d5f25c: cbz     x0, #0x2d5f274                             
02d5f260: ldp     x20, x19, [sp, #0x20]                      
02d5f264: mov     w1, wzr                                    
02d5f268: ldp     x22, x21, [sp, #0x10]                      
02d5f26c: ldp     x30, x23, [sp], #0x30                      
02d5f270: b       #0x2d5e4d8                                 Clicker.HandFollowClick::ShowHand
02d5f274: bl      #0x2b7105c                                 fn_2b7105c
## OnSetupKeycap(int keycapIndex) -> void
---- Clicker.BaseKeycapObject::OnSetupKeycap 0x2d5f278
02d5f278: str     x30, [sp, #-0x30]!                         
02d5f27c: stp     x22, x21, [sp, #0x10]                      
02d5f280: stp     x20, x19, [sp, #0x20]                      
02d5f284: adrp    x22, #0x6630000                            
02d5f288: adrp    x21, #0x626b000                            
02d5f28c: mov     w19, w1                                    
02d5f290: ldrb    w8, [x22, #0x2ec]                          
02d5f294: ldr     x21, [x21, #0xee0]                         MS:MonoSingleton`1::get_Instance
02d5f298: mov     x20, x0                                    
02d5f29c: tbnz    w8, #0, #0x2d5f2c0                         
02d5f2a0: adrp    x0, #0x626b000                             
02d5f2a4: ldr     x0, [x0, #0xe88]                           MS:System.Collections.Generic.List`1::get_Item
02d5f2a8: bl      #0x2b70db0                                 fn_2b70db0
02d5f2ac: adrp    x0, #0x626b000                             
02d5f2b0: ldr     x0, [x0, #0xee0]                           MS:MonoSingleton`1::get_Instance
02d5f2b4: bl      #0x2b70db0                                 fn_2b70db0
02d5f2b8: mov     w8, #1                                     
02d5f2bc: strb    w8, [x22, #0x2ec]                          
02d5f2c0: ldr     x0, [x21]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d5f2c4: str     w19, [x20, #0x90]                          ._currentSetupKeycapIndex
02d5f2c8: bl      #0x3769600                                 fn_3769600
02d5f2cc: ldr     x8, [x20, #0x68]                           ._keycapObjects
02d5f2d0: cbz     x8, #0x2d5f318                             
02d5f2d4: adrp    x9, #0x626b000                             
02d5f2d8: mov     x20, x0                                    
02d5f2dc: mov     x0, x8                                     
02d5f2e0: ldr     x9, [x9, #0xe88]                           MS:System.Collections.Generic.List`1::get_Item
02d5f2e4: mov     w1, w19                                    
02d5f2e8: ldr     x2, [x9]                                   T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d5f2ec: bl      #0x35a8f3c                                 fn_35a8f3c
02d5f2f0: cbz     x0, #0x2d5f318                             
02d5f2f4: mov     x1, xzr                                    
02d5f2f8: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02d5f2fc: cbz     x20, #0x2d5f318                            
02d5f300: mov     x1, x0                                     
02d5f304: mov     x0, x20                                    
02d5f308: ldp     x20, x19, [sp, #0x20]                      
02d5f30c: ldp     x22, x21, [sp, #0x10]                      
02d5f310: ldr     x30, [sp], #0x30                           
02d5f314: b       #0x2d5f31c                                 Clicker.KeycapMakerController::ShowHighlightSetupAt
02d5f318: bl      #0x2b7105c                                 fn_2b7105c
## JumpToNextKeycap() -> void
---- Clicker.BaseKeycapObject::JumpToNextKeycap 0x2d5f3ec
02d5f3ec: str     x30, [sp, #-0x20]!                         
02d5f3f0: stp     x20, x19, [sp, #0x10]                      
02d5f3f4: adrp    x20, #0x6630000                            
02d5f3f8: mov     x19, x0                                    
02d5f3fc: ldrb    w8, [x20, #0x2ed]                          
02d5f400: tbnz    w8, #0, #0x2d5f418                         
02d5f404: adrp    x0, #0x626b000                             
02d5f408: ldr     x0, [x0, #0xe80]                           MS:System.Collections.Generic.List`1::get_Count
02d5f40c: bl      #0x2b70db0                                 fn_2b70db0
02d5f410: mov     w8, #1                                     
02d5f414: strb    w8, [x20, #0x2ed]                          
02d5f418: ldr     x8, [x19, #0x68]                           ._keycapObjects
02d5f41c: cbz     x8, #0x2d5f450                             
02d5f420: ldr     w9, [x19, #0x90]                           ._currentSetupKeycapIndex
02d5f424: ldr     w8, [x8, #0x18]                            
02d5f428: add     w1, w9, #1                                 
02d5f42c: cmp     w1, w8                                     
02d5f430: b.ge    #0x2d5f444                                 
02d5f434: mov     x0, x19                                    
02d5f438: ldp     x20, x19, [sp, #0x10]                      
02d5f43c: ldr     x30, [sp], #0x20                           
02d5f440: b       #0x2d5f278                                 Clicker.BaseKeycapObject::OnSetupKeycap
02d5f444: ldp     x20, x19, [sp, #0x10]                      
02d5f448: ldr     x30, [sp], #0x20                           
02d5f44c: ret                                                
02d5f450: bl      #0x2b7105c                                 fn_2b7105c
## ShowFirstHighlight() -> void
---- Clicker.BaseKeycapObject::ShowFirstHighlight 0x2d5f454
02d5f454: mov     w1, wzr                                    
02d5f458: b       #0x2d5f278                                 Clicker.BaseKeycapObject::OnSetupKeycap
## ShowBaseOnly() -> void
---- Clicker.BaseKeycapObject::ShowBaseOnly 0x2d5f45c
02d5f45c: stp     x30, x19, [sp, #-0x10]!                    
02d5f460: mov     x19, x0                                    
02d5f464: ldr     x0, [x0, #0x20]                            ._srBaseKeycap
02d5f468: cbz     x0, #0x2d5f4a8                             
02d5f46c: mov     x1, xzr                                    
02d5f470: bl      #0x5b339ec                                 UnityEngine.Component::get_gameObject
02d5f474: cbz     x0, #0x2d5f4a8                             
02d5f478: mov     w1, #1                                     
02d5f47c: mov     x2, xzr                                    
02d5f480: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d5f484: ldr     x0, [x19, #0x28]                           ._srBaseKeycapFront
02d5f488: cbz     x0, #0x2d5f4a8                             
02d5f48c: mov     x1, xzr                                    
02d5f490: bl      #0x5b339ec                                 UnityEngine.Component::get_gameObject
02d5f494: cbz     x0, #0x2d5f4a8                             
02d5f498: mov     w1, #1                                     
02d5f49c: mov     x2, xzr                                    
02d5f4a0: ldp     x30, x19, [sp], #0x10                      
02d5f4a4: b       #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d5f4a8: bl      #0x2b7105c                                 fn_2b7105c
## CheckDropKeychain(UnityEngine.Transform draggingObject, float checkRange) -> bool
---- Clicker.BaseKeycapObject::CheckDropKeychain 0x2d5f4ac
02d5f4ac: str     d14, [sp, #-0x50]!                         
02d5f4b0: stp     d13, d12, [sp, #0x10]                      
02d5f4b4: stp     d11, d10, [sp, #0x20]                      
02d5f4b8: stp     d9, d8, [sp, #0x30]                        
02d5f4bc: stp     x30, x19, [sp, #0x40]                      
02d5f4c0: ldrb    w8, [x0, #0x80]                            ._keychainPlaced
02d5f4c4: cbnz    w8, #0x2d5f578                             
02d5f4c8: cbz     x1, #0x2d5f59c                             
02d5f4cc: mov     x19, x0                                    
02d5f4d0: mov     x0, x1                                     
02d5f4d4: mov     x1, xzr                                    
02d5f4d8: fmov    s8, s0                                     
02d5f4dc: bl      #0x5b467ac                                 UnityEngine.Transform::get_position
02d5f4e0: ldr     x0, [x19, #0x78]                           ._srKeychain
02d5f4e4: cbz     x0, #0x2d5f59c                             
02d5f4e8: mov     x1, xzr                                    
02d5f4ec: fmov    s9, s0                                     
02d5f4f0: fmov    s10, s1                                    
02d5f4f4: fmov    s11, s2                                    
02d5f4f8: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02d5f4fc: cbz     x0, #0x2d5f59c                             
02d5f500: mov     x1, xzr                                    
02d5f504: bl      #0x5b467ac                                 UnityEngine.Transform::get_position
02d5f508: fmov    s12, s0                                    
02d5f50c: fmov    s13, s1                                    
02d5f510: adrp    x19, #0x6630000                            
02d5f514: fmov    s14, s2                                    
02d5f518: ldrb    w8, [x19, #0x1d5]                          
02d5f51c: cbnz    w8, #0x2d5f534                             
02d5f520: adrp    x0, #0x6265000                             
02d5f524: ldr     x0, [x0, #0xb48]                           T:System.Math
02d5f528: bl      #0x2b70db0                                 fn_2b70db0
02d5f52c: mov     w8, #1                                     
02d5f530: strb    w8, [x19, #0x1d5]                          
02d5f534: adrp    x8, #0x6265000                             
02d5f538: ldr     x8, [x8, #0xb48]                           T:System.Math
02d5f53c: ldr     x0, [x8]                                   M:AdsManager::<OnApplicationPause>b__26_0
02d5f540: ldr     w8, [x0, #0xe4]                            [62650e4]=0 f=0,0
02d5f544: cbnz    w8, #0x2d5f54c                             
02d5f548: bl      #0x2b70f30                                 fn_2b70f30
02d5f54c: fsub    s0, s10, s13                               
02d5f550: fsub    s1, s9, s12                                
02d5f554: fsub    s2, s11, s14                               
02d5f558: fmul    s1, s1, s1                                 
02d5f55c: fmul    s0, s0, s0                                 
02d5f560: fadd    s0, s1, s0                                 
02d5f564: fmul    s1, s2, s2                                 
02d5f568: fadd    s0, s1, s0                                 
02d5f56c: fsqrt   s0, s0                                     
02d5f570: fcmp    s0, s8                                     
02d5f574: b.ls    #0x2d5f594                                 
02d5f578: mov     w0, wzr                                    
02d5f57c: ldp     x30, x19, [sp, #0x40]                      
02d5f580: ldp     d9, d8, [sp, #0x30]                        
02d5f584: ldp     d11, d10, [sp, #0x20]                      
02d5f588: ldp     d13, d12, [sp, #0x10]                      
02d5f58c: ldr     d14, [sp], #0x50                           
02d5f590: ret                                                
02d5f594: mov     w0, #1                                     
02d5f598: b       #0x2d5f57c                                 
02d5f59c: bl      #0x2b7105c                                 fn_2b7105c
## ActiveKeychain() -> void
---- Clicker.BaseKeycapObject::ActiveKeychain 0x2d5f5a0
02d5f5a0: stp     x30, x23, [sp, #-0x30]!                    
02d5f5a4: stp     x22, x21, [sp, #0x10]                      
02d5f5a8: stp     x20, x19, [sp, #0x20]                      
02d5f5ac: adrp    x20, #0x6630000                            
02d5f5b0: mov     x19, x0                                    
02d5f5b4: ldrb    w8, [x20, #0x2ee]                          
02d5f5b8: tbnz    w8, #0, #0x2d5f600                         
02d5f5bc: adrp    x0, #0x6264000                             
02d5f5c0: ldr     x0, [x0, #0xe8]                            T:DG.Tweening.TweenCallback
02d5f5c4: bl      #0x2b70db0                                 fn_2b70db0
02d5f5c8: adrp    x0, #0x6266000                             
02d5f5cc: ldr     x0, [x0, #0x928]                           MS:DG.Tweening.TweenSettingsExtensions::OnComplete
02d5f5d0: bl      #0x2b70db0                                 fn_2b70db0
02d5f5d4: adrp    x0, #0x6266000                             
02d5f5d8: ldr     x0, [x0, #0x880]                           MS:DG.Tweening.TweenSettingsExtensions::SetEase
02d5f5dc: bl      #0x2b70db0                                 fn_2b70db0
02d5f5e0: adrp    x0, #0x626b000                             
02d5f5e4: ldr     x0, [x0, #0xee8]                           M:Clicker.BaseKeycapObject/<>c::<ActiveKeychain>b__44_0
02d5f5e8: bl      #0x2b70db0                                 fn_2b70db0
02d5f5ec: adrp    x0, #0x626b000                             
02d5f5f0: ldr     x0, [x0, #0xdf8]                           T:Clicker.BaseKeycapObject/<>c
02d5f5f4: bl      #0x2b70db0                                 fn_2b70db0
02d5f5f8: mov     w8, #1                                     
02d5f5fc: strb    w8, [x20, #0x2ee]                          
02d5f600: mov     w8, #1                                     
02d5f604: mov     x0, x19                                    
02d5f608: strb    w8, [x19, #0x80]                           ._keychainPlaced
02d5f60c: bl      #0x2d5f6fc                                 Clicker.BaseKeycapObject::CheckDoneAssemble
02d5f610: ldr     x0, [x19, #0x78]                           ._srKeychain
02d5f614: cbz     x0, #0x2d5f6f8                             
02d5f618: adrp    x19, #0x6266000                            
02d5f61c: adrp    x22, #0x626b000                            
02d5f620: mov     x1, xzr                                    
02d5f624: ldr     x19, [x19, #0x880]                         MS:DG.Tweening.TweenSettingsExtensions::SetEase
02d5f628: ldr     x22, [x22, #0xdf8]                         T:Clicker.BaseKeycapObject/<>c
02d5f62c: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02d5f630: adrp    x8, #0x1084000                             
02d5f634: fmov    s0, #1.00000000                            
02d5f638: mov     x1, xzr                                    
02d5f63c: ldr     s1, [x8, #0xdd8]                           [1084dd8]=3f7333333e4ccccd f=0.2,0.95
02d5f640: bl      #0x2d98c98                                 DG.Tweening.ShortcutExtensions::DOScale
02d5f644: ldr     x2, [x19]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d5f648: mov     w1, #0x1b                                  
02d5f64c: bl      #0x336fa0c                                 fn_336fa0c
02d5f650: ldr     x8, [x22]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d5f654: mov     x19, x0                                    
02d5f658: ldr     w9, [x8, #0xe4]                            [10840e4]=2c2644327265746c f=4.54482e+30,2.36279e-12
02d5f65c: cbnz    w9, #0x2d5f66c                             
02d5f660: mov     x0, x8                                     
02d5f664: bl      #0x2b70f30                                 fn_2b70f30
02d5f668: ldr     x8, [x22]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d5f66c: ldr     x9, [x8, #0xb8]                            [10840b8]=2632726f74636556 f=7.20646e+31,6.19112e-16
02d5f670: adrp    x23, #0x6266000                            
02d5f674: ldr     x20, [x9, #0x38]                           
02d5f678: ldr     x23, [x23, #0x928]                         MS:DG.Tweening.TweenSettingsExtensions::OnComplete
02d5f67c: cbnz    x20, #0x2d5f6dc                            
02d5f680: ldr     w10, [x8, #0xe4]                           [10840e4]=2c2644327265746c f=4.54482e+30,2.36279e-12
02d5f684: cbnz    w10, #0x2d5f698                            
02d5f688: mov     x0, x8                                     
02d5f68c: bl      #0x2b70f30                                 fn_2b70f30
02d5f690: ldr     x8, [x22]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d5f694: ldr     x9, [x8, #0xb8]                            [10840b8]=2632726f74636556 f=7.20646e+31,6.19112e-16
02d5f698: adrp    x8, #0x6264000                             
02d5f69c: ldr     x8, [x8, #0xe8]                            T:DG.Tweening.TweenCallback
02d5f6a0: ldr     x21, [x9]                                  
02d5f6a4: ldr     x0, [x8]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d5f6a8: bl      #0x2b7104c                                 fn_2b7104c
02d5f6ac: adrp    x8, #0x626b000                             
02d5f6b0: mov     x1, x21                                    
02d5f6b4: mov     x3, xzr                                    
02d5f6b8: ldr     x8, [x8, #0xee8]                           M:Clicker.BaseKeycapObject/<>c::<ActiveKeychain>b__44_0
02d5f6bc: mov     x20, x0                                    
02d5f6c0: ldr     x2, [x8]                                   T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d5f6c4: bl      #0x2d89dc4                                 DG.Tweening.TweenCallback::.ctor
02d5f6c8: ldr     x8, [x22]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d5f6cc: mov     x1, x20                                    
02d5f6d0: ldr     x0, [x8, #0xb8]                            S:'scoop_no_thank'
02d5f6d4: str     x20, [x0, #0x38]!                          ._switchPositions
02d5f6d8: bl      #0x2b70d54                                 fn_2b70d54
02d5f6dc: mov     x0, x19                                    
02d5f6e0: mov     x1, x20                                    
02d5f6e4: ldr     x2, [x23]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d5f6e8: ldp     x20, x19, [sp, #0x20]                      
02d5f6ec: ldp     x22, x21, [sp, #0x10]                      
02d5f6f0: ldp     x30, x23, [sp], #0x30                      
02d5f6f4: b       #0x336f26c                                 
02d5f6f8: bl      #0x2b7105c                                 fn_2b7105c
## JustShowKeychain() -> void
---- Clicker.BaseKeycapObject::JustShowKeychain 0x2d5f764
02d5f764: str     x30, [sp, #-0x10]!                         
02d5f768: mov     x8, x0                                     
02d5f76c: ldr     x0, [x0, #0x78]                            ._srKeychain
02d5f770: mov     w9, #1                                     
02d5f774: strb    w9, [x8, #0x80]                            
02d5f778: cbz     x0, #0x2d5f798                             
02d5f77c: mov     x1, xzr                                    
02d5f780: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02d5f784: movi    d1, #0000000000000000                      
02d5f788: fmov    s0, #1.00000000                            
02d5f78c: mov     x1, xzr                                    
02d5f790: ldr     x30, [sp], #0x10                           
02d5f794: b       #0x2d98c98                                 DG.Tweening.ShortcutExtensions::DOScale
02d5f798: bl      #0x2b7105c                                 fn_2b7105c
## CheckDropSwitch(UnityEngine.Transform draggingObject, float checkRange) -> int
---- Clicker.BaseKeycapObject::CheckDropSwitch 0x2d5f79c
02d5f79c: str     d14, [sp, #-0x80]!                         
02d5f7a0: stp     d13, d12, [sp, #8]                         
02d5f7a4: stp     d11, d10, [sp, #0x18]                      
02d5f7a8: stp     d9, d8, [sp, #0x28]                        
02d5f7ac: str     x30, [sp, #0x38]                           
02d5f7b0: stp     x26, x25, [sp, #0x40]                      
02d5f7b4: stp     x24, x23, [sp, #0x50]                      
02d5f7b8: stp     x22, x21, [sp, #0x60]                      
02d5f7bc: stp     x20, x19, [sp, #0x70]                      
02d5f7c0: fmov    s8, s0                                     
02d5f7c4: adrp    x21, #0x6630000                            
02d5f7c8: mov     x19, x1                                    
02d5f7cc: ldrb    w8, [x21, #0x2ef]                          
02d5f7d0: mov     x20, x0                                    
02d5f7d4: tbnz    w8, #0, #0x2d5f804                         
02d5f7d8: adrp    x0, #0x6268000                             
02d5f7dc: ldr     x0, [x0, #0x4c8]                           MS:System.Collections.Generic.List`1::get_Count
02d5f7e0: bl      #0x2b70db0                                 fn_2b70db0
02d5f7e4: adrp    x0, #0x6266000                             
02d5f7e8: ldr     x0, [x0, #0xdd8]                           MS:System.Collections.Generic.List`1::get_Item
02d5f7ec: bl      #0x2b70db0                                 fn_2b70db0
02d5f7f0: adrp    x0, #0x6268000                             
02d5f7f4: ldr     x0, [x0, #0x4d0]                           MS:System.Collections.Generic.List`1::get_Item
02d5f7f8: bl      #0x2b70db0                                 fn_2b70db0
02d5f7fc: mov     w8, #1                                     
02d5f800: strb    w8, [x21, #0x2ef]                          
02d5f804: ldr     x8, [x20, #0x38]                           ._switchPositions
02d5f808: mov     w9, #-1                                    
02d5f80c: str     s8, [x20, #0xa4]                           ._closestDistance
02d5f810: str     w9, [x20, #0xa0]                           ._closestIndex
02d5f814: cbz     x8, #0x2d5f918                             
02d5f818: adrp    x23, #0x6266000                            
02d5f81c: adrp    x24, #0x6268000                            
02d5f820: adrp    x22, #0x6265000                            
02d5f824: ldr     x23, [x23, #0xdd8]                         MS:System.Collections.Generic.List`1::get_Item
02d5f828: ldr     x24, [x24, #0x4d0]                         MS:System.Collections.Generic.List`1::get_Item
02d5f82c: ldr     x22, [x22, #0xb48]                         T:System.Math
02d5f830: mov     w21, wzr                                   
02d5f834: adrp    x25, #0x6630000                            
02d5f838: mov     w26, #1                                    
02d5f83c: ldr     w8, [x8, #0x18]                            
02d5f840: cmp     w21, w8                                    
02d5f844: b.ge    #0x2d5f91c                                 
02d5f848: ldr     x0, [x20, #0x48]                           ._switchPlaced
02d5f84c: cbz     x0, #0x2d5f918                             
02d5f850: ldr     x2, [x23]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d5f854: mov     w1, w21                                    
02d5f858: bl      #0x4baf438                                 fn_4baf438
02d5f85c: tbnz    w0, #0, #0x2d5f90c                         
02d5f860: cbz     x19, #0x2d5f918                            
02d5f864: mov     x0, x19                                    
02d5f868: mov     x1, xzr                                    
02d5f86c: bl      #0x5b467ac                                 UnityEngine.Transform::get_position
02d5f870: ldr     x0, [x20, #0x38]                           ._switchPositions
02d5f874: cbz     x0, #0x2d5f918                             
02d5f878: ldr     x2, [x24]                                  S:'{0}/2'
02d5f87c: mov     w1, w21                                    
02d5f880: fmov    s9, s0                                     
02d5f884: fmov    s10, s1                                    
02d5f888: fmov    s11, s2                                    
02d5f88c: bl      #0x35a8f3c                                 fn_35a8f3c
02d5f890: cbz     x0, #0x2d5f918                             
02d5f894: mov     x1, xzr                                    
02d5f898: bl      #0x5b467ac                                 UnityEngine.Transform::get_position
02d5f89c: fmov    s12, s0                                    
02d5f8a0: fmov    s13, s1                                    
02d5f8a4: ldrb    w8, [x25, #0x1d5]                          
02d5f8a8: fmov    s14, s2                                    
02d5f8ac: cbnz    w8, #0x2d5f8bc                             
02d5f8b0: mov     x0, x22                                    
02d5f8b4: bl      #0x2b70db0                                 fn_2b70db0
02d5f8b8: strb    w26, [x25, #0x1d5]                         
02d5f8bc: ldr     x0, [x22]                                  M:AdsManager::<OnApplicationPause>b__26_0
02d5f8c0: ldr     w8, [x0, #0xe4]                            [62680e4]=0 f=0,0
02d5f8c4: cbnz    w8, #0x2d5f8cc                             
02d5f8c8: bl      #0x2b70f30                                 fn_2b70f30
02d5f8cc: fsub    s0, s10, s13                               
02d5f8d0: fsub    s1, s9, s12                                
02d5f8d4: fsub    s2, s11, s14                               
02d5f8d8: fmul    s1, s1, s1                                 
02d5f8dc: fmul    s0, s0, s0                                 
02d5f8e0: fadd    s0, s1, s0                                 
02d5f8e4: fmul    s1, s2, s2                                 
02d5f8e8: fadd    s0, s1, s0                                 
02d5f8ec: fsqrt   s0, s0                                     
02d5f8f0: fcmp    s0, s8                                     
02d5f8f4: b.hi    #0x2d5f90c                                 
02d5f8f8: ldr     s1, [x20, #0xa4]                           ._closestDistance
02d5f8fc: fcmp    s0, s1                                     
02d5f900: b.hi    #0x2d5f90c                                 
02d5f904: str     s0, [x20, #0xa4]                           ._closestDistance
02d5f908: str     w21, [x20, #0xa0]                          ._closestIndex
02d5f90c: ldr     x8, [x20, #0x38]                           ._switchPositions
02d5f910: add     w21, w21, #1                               
02d5f914: cbnz    x8, #0x2d5f83c                             
02d5f918: bl      #0x2b7105c                                 fn_2b7105c
02d5f91c: ldr     w0, [x20, #0xa0]                           ._closestIndex
02d5f920: ldp     x20, x19, [sp, #0x70]                      
02d5f924: ldp     x22, x21, [sp, #0x60]                      
02d5f928: ldr     x30, [sp, #0x38]                           
02d5f92c: ldp     x24, x23, [sp, #0x50]                      
02d5f930: ldp     x26, x25, [sp, #0x40]                      
02d5f934: ldp     d9, d8, [sp, #0x28]                        
02d5f938: ldp     d11, d10, [sp, #0x18]                      
02d5f93c: ldp     d13, d12, [sp, #8]                         
02d5f940: ldr     d14, [sp], #0x80                           
02d5f944: ret                                                
## DropSwitchReal(int switchIndex) -> void
---- Clicker.BaseKeycapObject::DropSwitchReal 0x2d5f948
02d5f948: stp     x30, x23, [sp, #-0x30]!                    
02d5f94c: stp     x22, x21, [sp, #0x10]                      
02d5f950: stp     x20, x19, [sp, #0x20]                      
02d5f954: adrp    x21, #0x6630000                            
02d5f958: mov     w19, w1                                    
02d5f95c: mov     x20, x0                                    
02d5f960: ldrb    w8, [x21, #0x2f0]                          
02d5f964: tbnz    w8, #0, #0x2d5f9c4                         
02d5f968: adrp    x0, #0x626b000                             
02d5f96c: ldr     x0, [x0, #0xec8]                           MS:System.Collections.Generic.List`1::get_Item
02d5f970: bl      #0x2b70db0                                 fn_2b70db0
02d5f974: adrp    x0, #0x626b000                             
02d5f978: ldr     x0, [x0, #0xae8]                           MS:System.Collections.Generic.List`1::set_Item
02d5f97c: bl      #0x2b70db0                                 fn_2b70db0
02d5f980: adrp    x0, #0x6264000                             
02d5f984: ldr     x0, [x0, #0xe8]                            T:DG.Tweening.TweenCallback
02d5f988: bl      #0x2b70db0                                 fn_2b70db0
02d5f98c: adrp    x0, #0x6266000                             
02d5f990: ldr     x0, [x0, #0x928]                           MS:DG.Tweening.TweenSettingsExtensions::OnComplete
02d5f994: bl      #0x2b70db0                                 fn_2b70db0
02d5f998: adrp    x0, #0x6266000                             
02d5f99c: ldr     x0, [x0, #0x880]                           MS:DG.Tweening.TweenSettingsExtensions::SetEase
02d5f9a0: bl      #0x2b70db0                                 fn_2b70db0
02d5f9a4: adrp    x0, #0x626b000                             
02d5f9a8: ldr     x0, [x0, #0xef0]                           M:Clicker.BaseKeycapObject/<>c::<DropSwitchReal>b__49_0
02d5f9ac: bl      #0x2b70db0                                 fn_2b70db0
02d5f9b0: adrp    x0, #0x626b000                             
02d5f9b4: ldr     x0, [x0, #0xdf8]                           T:Clicker.BaseKeycapObject/<>c
02d5f9b8: bl      #0x2b70db0                                 fn_2b70db0
02d5f9bc: mov     w8, #1                                     
02d5f9c0: strb    w8, [x21, #0x2f0]                          
02d5f9c4: ldr     x0, [x20, #0x48]                           ._switchPlaced
02d5f9c8: cbz     x0, #0x2d5faec                             
02d5f9cc: adrp    x8, #0x626b000                             
02d5f9d0: mov     w1, w19                                    
02d5f9d4: mov     w2, #1                                     
02d5f9d8: ldr     x8, [x8, #0xae8]                           MS:System.Collections.Generic.List`1::set_Item
02d5f9dc: ldr     x3, [x8]                                   T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d5f9e0: bl      #0x4baf48c                                 fn_4baf48c
02d5f9e4: mov     x0, x20                                    
02d5f9e8: bl      #0x2d5f6fc                                 Clicker.BaseKeycapObject::CheckDoneAssemble
02d5f9ec: ldr     x0, [x20, #0x40]                           ._switchObjects
02d5f9f0: cbz     x0, #0x2d5faec                             
02d5f9f4: adrp    x8, #0x626b000                             
02d5f9f8: mov     w1, w19                                    
02d5f9fc: ldr     x8, [x8, #0xec8]                           MS:System.Collections.Generic.List`1::get_Item
02d5fa00: ldr     x2, [x8]                                   T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d5fa04: bl      #0x35a8f3c                                 fn_35a8f3c
02d5fa08: cbz     x0, #0x2d5faec                             
02d5fa0c: adrp    x19, #0x6266000                            
02d5fa10: adrp    x22, #0x626b000                            
02d5fa14: mov     x1, xzr                                    
02d5fa18: ldr     x19, [x19, #0x880]                         MS:DG.Tweening.TweenSettingsExtensions::SetEase
02d5fa1c: ldr     x22, [x22, #0xdf8]                         T:Clicker.BaseKeycapObject/<>c
02d5fa20: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02d5fa24: adrp    x8, #0x1084000                             
02d5fa28: fmov    s0, #1.00000000                            
02d5fa2c: mov     x1, xzr                                    
02d5fa30: ldr     s1, [x8, #0xdd8]                           [1084dd8]=3f7333333e4ccccd f=0.2,0.95
02d5fa34: bl      #0x2d98c98                                 DG.Tweening.ShortcutExtensions::DOScale
02d5fa38: ldr     x2, [x19]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d5fa3c: mov     w1, #0x1b                                  
02d5fa40: bl      #0x336fa0c                                 fn_336fa0c
02d5fa44: ldr     x8, [x22]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d5fa48: mov     x19, x0                                    
02d5fa4c: ldr     w9, [x8, #0xe4]                            [10840e4]=2c2644327265746c f=4.54482e+30,2.36279e-12
02d5fa50: cbnz    w9, #0x2d5fa60                             
02d5fa54: mov     x0, x8                                     
02d5fa58: bl      #0x2b70f30                                 fn_2b70f30
02d5fa5c: ldr     x8, [x22]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d5fa60: ldr     x9, [x8, #0xb8]                            [10840b8]=2632726f74636556 f=7.20646e+31,6.19112e-16
02d5fa64: adrp    x23, #0x6266000                            
02d5fa68: ldr     x20, [x9, #0x40]                           
02d5fa6c: ldr     x23, [x23, #0x928]                         MS:DG.Tweening.TweenSettingsExtensions::OnComplete
02d5fa70: cbnz    x20, #0x2d5fad0                            
02d5fa74: ldr     w10, [x8, #0xe4]                           [10840e4]=2c2644327265746c f=4.54482e+30,2.36279e-12
02d5fa78: cbnz    w10, #0x2d5fa8c                            
02d5fa7c: mov     x0, x8                                     
02d5fa80: bl      #0x2b70f30                                 fn_2b70f30
02d5fa84: ldr     x8, [x22]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d5fa88: ldr     x9, [x8, #0xb8]                            [10840b8]=2632726f74636556 f=7.20646e+31,6.19112e-16
02d5fa8c: adrp    x8, #0x6264000                             
02d5fa90: ldr     x8, [x8, #0xe8]                            T:DG.Tweening.TweenCallback
02d5fa94: ldr     x21, [x9]                                  
02d5fa98: ldr     x0, [x8]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d5fa9c: bl      #0x2b7104c                                 fn_2b7104c
02d5faa0: adrp    x8, #0x626b000                             
02d5faa4: mov     x1, x21                                    
02d5faa8: mov     x3, xzr                                    
02d5faac: ldr     x8, [x8, #0xef0]                           M:Clicker.BaseKeycapObject/<>c::<DropSwitchReal>b__49_0
02d5fab0: mov     x20, x0                                    
02d5fab4: ldr     x2, [x8]                                   T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d5fab8: bl      #0x2d89dc4                                 DG.Tweening.TweenCallback::.ctor
02d5fabc: ldr     x8, [x22]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d5fac0: mov     x1, x20                                    
02d5fac4: ldr     x0, [x8, #0xb8]                            S:'scoop_no_thank'
02d5fac8: str     x20, [x0, #0x40]!                          ._switchObjects
02d5facc: bl      #0x2b70d54                                 fn_2b70d54
02d5fad0: mov     x0, x19                                    
02d5fad4: mov     x1, x20                                    
02d5fad8: ldr     x2, [x23]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d5fadc: ldp     x20, x19, [sp, #0x20]                      
02d5fae0: ldp     x22, x21, [sp, #0x10]                      
02d5fae4: ldp     x30, x23, [sp], #0x30                      
02d5fae8: b       #0x336f26c                                 
02d5faec: bl      #0x2b7105c                                 fn_2b7105c
## CheckDropKeycap(UnityEngine.Transform draggingObject, float checkRange) -> int
---- Clicker.BaseKeycapObject::CheckDropKeycap 0x2d5faf0
02d5faf0: str     d14, [sp, #-0x80]!                         
02d5faf4: stp     d13, d12, [sp, #8]                         
02d5faf8: stp     d11, d10, [sp, #0x18]                      
02d5fafc: stp     d9, d8, [sp, #0x28]                        
02d5fb00: str     x30, [sp, #0x38]                           
02d5fb04: stp     x26, x25, [sp, #0x40]                      
02d5fb08: stp     x24, x23, [sp, #0x50]                      
02d5fb0c: stp     x22, x21, [sp, #0x60]                      
02d5fb10: stp     x20, x19, [sp, #0x70]                      
02d5fb14: fmov    s8, s0                                     
02d5fb18: adrp    x21, #0x6630000                            
02d5fb1c: mov     x19, x1                                    
02d5fb20: ldrb    w8, [x21, #0x2f1]                          
02d5fb24: mov     x20, x0                                    
02d5fb28: tbnz    w8, #0, #0x2d5fb58                         
02d5fb2c: adrp    x0, #0x6268000                             
02d5fb30: ldr     x0, [x0, #0x4c8]                           MS:System.Collections.Generic.List`1::get_Count
02d5fb34: bl      #0x2b70db0                                 fn_2b70db0
02d5fb38: adrp    x0, #0x6266000                             
02d5fb3c: ldr     x0, [x0, #0xdd8]                           MS:System.Collections.Generic.List`1::get_Item
02d5fb40: bl      #0x2b70db0                                 fn_2b70db0
02d5fb44: adrp    x0, #0x6268000                             
02d5fb48: ldr     x0, [x0, #0x4d0]                           MS:System.Collections.Generic.List`1::get_Item
02d5fb4c: bl      #0x2b70db0                                 fn_2b70db0
02d5fb50: mov     w8, #1                                     
02d5fb54: strb    w8, [x21, #0x2f1]                          
02d5fb58: ldr     x8, [x20, #0x60]                           ._keycapPositions
02d5fb5c: mov     w9, #-1                                    
02d5fb60: str     s8, [x20, #0xa4]                           ._closestDistance
02d5fb64: str     w9, [x20, #0xa0]                           ._closestIndex
02d5fb68: cbz     x8, #0x2d5fc84                             
02d5fb6c: adrp    x23, #0x6266000                            
02d5fb70: adrp    x24, #0x6268000                            
02d5fb74: adrp    x22, #0x6265000                            
02d5fb78: ldr     x23, [x23, #0xdd8]                         MS:System.Collections.Generic.List`1::get_Item
02d5fb7c: ldr     x24, [x24, #0x4d0]                         MS:System.Collections.Generic.List`1::get_Item
02d5fb80: ldr     x22, [x22, #0xb48]                         T:System.Math
02d5fb84: mov     w21, wzr                                   
02d5fb88: adrp    x25, #0x6630000                            
02d5fb8c: mov     w26, #1                                    
02d5fb90: ldr     w8, [x8, #0x18]                            
02d5fb94: cmp     w21, w8                                    
02d5fb98: b.ge    #0x2d5fc88                                 
02d5fb9c: ldr     x0, [x20, #0x70]                           ._keycapPlaced
02d5fba0: cbz     x0, #0x2d5fc84                             
02d5fba4: ldr     x2, [x23]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d5fba8: mov     w1, w21                                    
02d5fbac: bl      #0x4baf438                                 fn_4baf438
02d5fbb0: tbnz    w0, #0, #0x2d5fc78                         
02d5fbb4: ldr     x0, [x20, #0x48]                           ._switchPlaced
02d5fbb8: cbz     x0, #0x2d5fc84                             
02d5fbbc: ldr     x2, [x23]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d5fbc0: mov     w1, w21                                    
02d5fbc4: bl      #0x4baf438                                 fn_4baf438
02d5fbc8: tbz     w0, #0, #0x2d5fc78                         
02d5fbcc: cbz     x19, #0x2d5fc84                            
02d5fbd0: mov     x0, x19                                    
02d5fbd4: mov     x1, xzr                                    
02d5fbd8: bl      #0x5b467ac                                 UnityEngine.Transform::get_position
02d5fbdc: ldr     x0, [x20, #0x60]                           ._keycapPositions
02d5fbe0: cbz     x0, #0x2d5fc84                             
02d5fbe4: ldr     x2, [x24]                                  S:'{0}/2'
02d5fbe8: mov     w1, w21                                    
02d5fbec: fmov    s9, s0                                     
02d5fbf0: fmov    s10, s1                                    
02d5fbf4: fmov    s11, s2                                    
02d5fbf8: bl      #0x35a8f3c                                 fn_35a8f3c
02d5fbfc: cbz     x0, #0x2d5fc84                             
02d5fc00: mov     x1, xzr                                    
02d5fc04: bl      #0x5b467ac                                 UnityEngine.Transform::get_position
02d5fc08: fmov    s12, s0                                    
02d5fc0c: fmov    s13, s1                                    
02d5fc10: ldrb    w8, [x25, #0x1d5]                          
02d5fc14: fmov    s14, s2                                    
02d5fc18: cbnz    w8, #0x2d5fc28                             
02d5fc1c: mov     x0, x22                                    
02d5fc20: bl      #0x2b70db0                                 fn_2b70db0
02d5fc24: strb    w26, [x25, #0x1d5]                         
02d5fc28: ldr     x0, [x22]                                  M:AdsManager::<OnApplicationPause>b__26_0
02d5fc2c: ldr     w8, [x0, #0xe4]                            [62680e4]=0 f=0,0
02d5fc30: cbnz    w8, #0x2d5fc38                             
02d5fc34: bl      #0x2b70f30                                 fn_2b70f30
02d5fc38: fsub    s0, s10, s13                               
02d5fc3c: fsub    s1, s9, s12                                
02d5fc40: fsub    s2, s11, s14                               
02d5fc44: fmul    s1, s1, s1                                 
02d5fc48: fmul    s0, s0, s0                                 
02d5fc4c: fadd    s0, s1, s0                                 
02d5fc50: fmul    s1, s2, s2                                 
02d5fc54: fadd    s0, s1, s0                                 
02d5fc58: fsqrt   s0, s0                                     
02d5fc5c: fcmp    s0, s8                                     
02d5fc60: b.hi    #0x2d5fc78                                 
02d5fc64: ldr     s1, [x20, #0xa4]                           ._closestDistance
02d5fc68: fcmp    s0, s1                                     
02d5fc6c: b.hi    #0x2d5fc78                                 
02d5fc70: str     w21, [x20, #0xa0]                          ._closestIndex
02d5fc74: str     s0, [x20, #0xa4]                           ._closestDistance
02d5fc78: ldr     x8, [x20, #0x60]                           ._keycapPositions
02d5fc7c: add     w21, w21, #1                               
02d5fc80: cbnz    x8, #0x2d5fb90                             
02d5fc84: bl      #0x2b7105c                                 fn_2b7105c
02d5fc88: ldr     w0, [x20, #0xa0]                           ._closestIndex
02d5fc8c: ldp     x20, x19, [sp, #0x70]                      
02d5fc90: ldp     x22, x21, [sp, #0x60]                      
02d5fc94: ldr     x30, [sp, #0x38]                           
02d5fc98: ldp     x24, x23, [sp, #0x50]                      
02d5fc9c: ldp     x26, x25, [sp, #0x40]                      
02d5fca0: ldp     d9, d8, [sp, #0x28]                        
02d5fca4: ldp     d11, d10, [sp, #0x18]                      
02d5fca8: ldp     d13, d12, [sp, #8]                         
02d5fcac: ldr     d14, [sp], #0x80                           
02d5fcb0: ret                                                
## GetPosKeycap(int keycapSlotIndex) -> UnityEngine.Transform
---- Clicker.BaseKeycapObject::GetPosKeycap 0x2d5fcb4
02d5fcb4: stp     x30, x21, [sp, #-0x20]!                    
02d5fcb8: stp     x20, x19, [sp, #0x10]                      
02d5fcbc: adrp    x21, #0x6630000                            
02d5fcc0: mov     w19, w1                                    
02d5fcc4: mov     x20, x0                                    
02d5fcc8: ldrb    w8, [x21, #0x2f2]                          
02d5fccc: tbnz    w8, #0, #0x2d5fce4                         
02d5fcd0: adrp    x0, #0x626b000                             
02d5fcd4: ldr     x0, [x0, #0xe88]                           MS:System.Collections.Generic.List`1::get_Item
02d5fcd8: bl      #0x2b70db0                                 fn_2b70db0
02d5fcdc: mov     w8, #1                                     
02d5fce0: strb    w8, [x21, #0x2f2]                          
02d5fce4: tbnz    w19, #0x1f, #0x2d5fd18                     
02d5fce8: ldr     x0, [x20, #0x68]                           ._keycapObjects
02d5fcec: cbz     x0, #0x2d5fd28                             
02d5fcf0: adrp    x8, #0x626b000                             
02d5fcf4: mov     w1, w19                                    
02d5fcf8: ldr     x8, [x8, #0xe88]                           MS:System.Collections.Generic.List`1::get_Item
02d5fcfc: ldr     x2, [x8]                                   T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d5fd00: bl      #0x35a8f3c                                 fn_35a8f3c
02d5fd04: cbz     x0, #0x2d5fd28                             
02d5fd08: ldp     x20, x19, [sp, #0x10]                      
02d5fd0c: mov     x1, xzr                                    
02d5fd10: ldp     x30, x21, [sp], #0x20                      
02d5fd14: b       #0x5b3391c                                 UnityEngine.Component::get_transform
02d5fd18: ldp     x20, x19, [sp, #0x10]                      
02d5fd1c: mov     x0, xzr                                    
02d5fd20: ldp     x30, x21, [sp], #0x20                      
02d5fd24: ret                                                
02d5fd28: bl      #0x2b7105c                                 fn_2b7105c
## DropKeycapReal(int keycapSlotIndex, Clicker.KeycapObject visualData) -> void
---- Clicker.BaseKeycapObject::DropKeycapReal 0x2d5fd2c
02d5fd2c: stp     x30, x23, [sp, #-0x30]!                    
02d5fd30: stp     x22, x21, [sp, #0x10]                      
02d5fd34: stp     x20, x19, [sp, #0x20]                      
02d5fd38: adrp    x22, #0x6630000                            
02d5fd3c: mov     x21, x2                                    
02d5fd40: mov     w20, w1                                    
02d5fd44: ldrb    w8, [x22, #0x2f3]                          
02d5fd48: mov     x19, x0                                    
02d5fd4c: tbnz    w8, #0, #0x2d5fda0                         
02d5fd50: adrp    x0, #0x626b000                             
02d5fd54: ldr     x0, [x0, #0xef8]                           M:Clicker.BaseKeycapObject::<DropKeycapReal>b__52_0
02d5fd58: bl      #0x2b70db0                                 fn_2b70db0
02d5fd5c: adrp    x0, #0x626b000                             
02d5fd60: ldr     x0, [x0, #0xe88]                           MS:System.Collections.Generic.List`1::get_Item
02d5fd64: bl      #0x2b70db0                                 fn_2b70db0
02d5fd68: adrp    x0, #0x626b000                             
02d5fd6c: ldr     x0, [x0, #0xae8]                           MS:System.Collections.Generic.List`1::set_Item
02d5fd70: bl      #0x2b70db0                                 fn_2b70db0
02d5fd74: adrp    x0, #0x6264000                             
02d5fd78: ldr     x0, [x0, #0xe8]                            T:DG.Tweening.TweenCallback
02d5fd7c: bl      #0x2b70db0                                 fn_2b70db0
02d5fd80: adrp    x0, #0x6266000                             
02d5fd84: ldr     x0, [x0, #0x928]                           MS:DG.Tweening.TweenSettingsExtensions::OnComplete
02d5fd88: bl      #0x2b70db0                                 fn_2b70db0
02d5fd8c: adrp    x0, #0x6266000                             
02d5fd90: ldr     x0, [x0, #0x880]                           MS:DG.Tweening.TweenSettingsExtensions::SetEase
02d5fd94: bl      #0x2b70db0                                 fn_2b70db0
02d5fd98: mov     w8, #1                                     
02d5fd9c: strb    w8, [x22, #0x2f3]                          
02d5fda0: ldr     x0, [x19, #0x70]                           ._keycapPlaced
02d5fda4: cbz     x0, #0x2d5fe90                             
02d5fda8: adrp    x8, #0x626b000                             
02d5fdac: mov     w1, w20                                    
02d5fdb0: mov     w2, #1                                     
02d5fdb4: ldr     x8, [x8, #0xae8]                           MS:System.Collections.Generic.List`1::set_Item
02d5fdb8: ldr     x3, [x8]                                   T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d5fdbc: bl      #0x4baf48c                                 fn_4baf48c
02d5fdc0: mov     x0, x19                                    
02d5fdc4: bl      #0x2d5f6fc                                 Clicker.BaseKeycapObject::CheckDoneAssemble
02d5fdc8: ldr     x0, [x19, #0x68]                           ._keycapObjects
02d5fdcc: cbz     x0, #0x2d5fe90                             
02d5fdd0: adrp    x22, #0x626b000                            
02d5fdd4: mov     w1, w20                                    
02d5fdd8: ldr     x22, [x22, #0xe88]                         MS:System.Collections.Generic.List`1::get_Item
02d5fddc: ldr     x2, [x22]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d5fde0: bl      #0x35a8f3c                                 fn_35a8f3c
02d5fde4: cbz     x0, #0x2d5fe90                             
02d5fde8: mov     x1, x21                                    
02d5fdec: bl      #0x2d5fe94                                 Clicker.KeycapObject::CloneKeycap
02d5fdf0: ldr     x0, [x19, #0x68]                           ._keycapObjects
02d5fdf4: cbz     x0, #0x2d5fe90                             
02d5fdf8: ldr     x2, [x22]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d5fdfc: mov     w1, w20                                    
02d5fe00: bl      #0x35a8f3c                                 fn_35a8f3c
02d5fe04: cbz     x0, #0x2d5fe90                             
02d5fe08: adrp    x20, #0x6266000                            
02d5fe0c: adrp    x21, #0x6264000                            
02d5fe10: adrp    x22, #0x626b000                            
02d5fe14: adrp    x23, #0x6266000                            
02d5fe18: ldr     x20, [x20, #0x880]                         MS:DG.Tweening.TweenSettingsExtensions::SetEase
02d5fe1c: ldr     x21, [x21, #0xe8]                          T:DG.Tweening.TweenCallback
02d5fe20: ldr     x22, [x22, #0xef8]                         M:Clicker.BaseKeycapObject::<DropKeycapReal>b__52_0
02d5fe24: ldr     x23, [x23, #0x928]                         MS:DG.Tweening.TweenSettingsExtensions::OnComplete
02d5fe28: mov     x1, xzr                                    
02d5fe2c: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02d5fe30: adrp    x8, #0x1084000                             
02d5fe34: fmov    s0, #1.00000000                            
02d5fe38: mov     x1, xzr                                    
02d5fe3c: ldr     s1, [x8, #0xdd8]                           [1084dd8]=3f7333333e4ccccd f=0.2,0.95
02d5fe40: bl      #0x2d98c98                                 DG.Tweening.ShortcutExtensions::DOScale
02d5fe44: ldr     x2, [x20]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d5fe48: mov     w1, #0x1b                                  
02d5fe4c: bl      #0x336fa0c                                 fn_336fa0c
02d5fe50: ldr     x8, [x21]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d5fe54: mov     x20, x0                                    
02d5fe58: mov     x0, x8                                     
02d5fe5c: bl      #0x2b7104c                                 fn_2b7104c
02d5fe60: ldr     x2, [x22]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d5fe64: mov     x1, x19                                    
02d5fe68: mov     x3, xzr                                    
02d5fe6c: mov     x21, x0                                    
02d5fe70: bl      #0x2d89dc4                                 DG.Tweening.TweenCallback::.ctor
02d5fe74: mov     x0, x20                                    
02d5fe78: mov     x1, x21                                    
02d5fe7c: ldr     x2, [x23]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d5fe80: ldp     x20, x19, [sp, #0x20]                      
02d5fe84: ldp     x22, x21, [sp, #0x10]                      
02d5fe88: ldp     x30, x23, [sp], #0x30                      
02d5fe8c: b       #0x336f26c                                 
02d5fe90: bl      #0x2b7105c                                 fn_2b7105c
## PullBackKeycap(int keycapSlotIndex) -> void
---- Clicker.BaseKeycapObject::PullBackKeycap 0x2d60014
02d60014: stp     x30, x21, [sp, #-0x20]!                    
02d60018: stp     x20, x19, [sp, #0x10]                      
02d6001c: adrp    x21, #0x6630000                            
02d60020: mov     w19, w1                                    
02d60024: mov     x20, x0                                    
02d60028: ldrb    w8, [x21, #0x2f4]                          
02d6002c: tbnz    w8, #0, #0x2d60050                         
02d60030: adrp    x0, #0x626b000                             
02d60034: ldr     x0, [x0, #0xe88]                           MS:System.Collections.Generic.List`1::get_Item
02d60038: bl      #0x2b70db0                                 fn_2b70db0
02d6003c: adrp    x0, #0x626b000                             
02d60040: ldr     x0, [x0, #0xae8]                           MS:System.Collections.Generic.List`1::set_Item
02d60044: bl      #0x2b70db0                                 fn_2b70db0
02d60048: mov     w8, #1                                     
02d6004c: strb    w8, [x21, #0x2f4]                          
02d60050: tbnz    w19, #0x1f, #0x2d600e0                     
02d60054: mov     x0, xzr                                    
02d60058: bl      #0x2d6eec8                                 Framework.AudioManager::get_Instance
02d6005c: cbz     x0, #0x2d600ec                             
02d60060: movi    d1, #0000000000000000                      
02d60064: movi    d2, #0000000000000000                      
02d60068: mov     w1, #0x35                                  
02d6006c: fmov    s0, #1.00000000                            
02d60070: mov     w2, wzr                                    
02d60074: mov     w3, wzr                                    
02d60078: mov     x4, xzr                                    
02d6007c: bl      #0x2d6f03c                                 Framework.AudioManager::PlaySound
02d60080: ldr     x0, [x20, #0x70]                           ._keycapPlaced
02d60084: cbz     x0, #0x2d600ec                             
02d60088: adrp    x8, #0x626b000                             
02d6008c: mov     w1, w19                                    
02d60090: mov     w2, wzr                                    
02d60094: ldr     x8, [x8, #0xae8]                           MS:System.Collections.Generic.List`1::set_Item
02d60098: ldr     x3, [x8]                                   T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d6009c: bl      #0x4baf48c                                 fn_4baf48c
02d600a0: ldr     x0, [x20, #0x68]                           ._keycapObjects
02d600a4: cbz     x0, #0x2d600ec                             
02d600a8: adrp    x8, #0x626b000                             
02d600ac: mov     w1, w19                                    
02d600b0: ldr     x8, [x8, #0xe88]                           MS:System.Collections.Generic.List`1::get_Item
02d600b4: ldr     x2, [x8]                                   T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d600b8: bl      #0x35a8f3c                                 fn_35a8f3c
02d600bc: cbz     x0, #0x2d600ec                             
02d600c0: mov     x1, xzr                                    
02d600c4: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02d600c8: ldp     x20, x19, [sp, #0x10]                      
02d600cc: movi    d0, #0000000000000000                      
02d600d0: movi    d1, #0000000000000000                      
02d600d4: mov     x1, xzr                                    
02d600d8: ldp     x30, x21, [sp], #0x20                      
02d600dc: b       #0x2d98c98                                 DG.Tweening.ShortcutExtensions::DOScale
02d600e0: ldp     x20, x19, [sp, #0x10]                      
02d600e4: ldp     x30, x21, [sp], #0x20                      
02d600e8: ret                                                
02d600ec: bl      #0x2b7105c                                 fn_2b7105c
## CheckDoneAssemble() -> void
---- Clicker.BaseKeycapObject::CheckDoneAssemble 0x2d5f6fc
02d5f6fc: str     x30, [sp, #-0x20]!                         
02d5f700: stp     x20, x19, [sp, #0x10]                      
02d5f704: adrp    x20, #0x6630000                            
02d5f708: mov     x19, x0                                    
02d5f70c: ldrb    w8, [x20, #0x2f5]                          
02d5f710: tbnz    w8, #0, #0x2d5f728                         
02d5f714: adrp    x0, #0x626b000                             
02d5f718: ldr     x0, [x0, #0xee0]                           MS:MonoSingleton`1::get_Instance
02d5f71c: bl      #0x2b70db0                                 fn_2b70db0
02d5f720: mov     w8, #1                                     
02d5f724: strb    w8, [x20, #0x2f5]                          
02d5f728: mov     x0, x19                                    
02d5f72c: bl      #0x2d5df48                                 Clicker.BaseKeycapObject::get_IsAssembleDone
02d5f730: tbz     w0, #0, #0x2d5f754                         
02d5f734: adrp    x8, #0x626b000                             
02d5f738: ldr     x8, [x8, #0xee0]                           MS:MonoSingleton`1::get_Instance
02d5f73c: ldr     x0, [x8]                                   T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d5f740: bl      #0x3769600                                 fn_3769600
02d5f744: cbz     x0, #0x2d5f760                             
02d5f748: ldp     x20, x19, [sp, #0x10]                      
02d5f74c: ldr     x30, [sp], #0x20                           
02d5f750: b       #0x2d600f0                                 Clicker.KeycapMakerController::ShowResult
02d5f754: ldp     x20, x19, [sp, #0x10]                      
02d5f758: ldr     x30, [sp], #0x20                           
02d5f75c: ret                                                
02d5f760: bl      #0x2b7105c                                 fn_2b7105c
## GetDecorData() -> System.Collections.Generic.List`1<int>
---- Clicker.BaseKeycapObject::GetDecorData 0x2d60470
02d60470: stp     x30, x23, [sp, #-0x30]!                    
02d60474: stp     x22, x21, [sp, #0x10]                      
02d60478: stp     x20, x19, [sp, #0x20]                      
02d6047c: adrp    x21, #0x6630000                            
02d60480: adrp    x22, #0x6266000                            
02d60484: adrp    x20, #0x6266000                            
02d60488: ldrb    w8, [x21, #0x2f6]                          
02d6048c: ldr     x22, [x22, #0x648]                         T:type15061(k15)
02d60490: ldr     x20, [x20, #0x650]                         MS:System.Collections.Generic.List`1::.ctor
02d60494: mov     x19, x0                                    
02d60498: tbnz    w8, #0, #0x2d604e0                         
02d6049c: adrp    x0, #0x6266000                             
02d604a0: ldr     x0, [x0, #0x818]                           MS:System.Collections.Generic.List`1::Add
02d604a4: bl      #0x2b70db0                                 fn_2b70db0
02d604a8: adrp    x0, #0x6266000                             
02d604ac: ldr     x0, [x0, #0x650]                           MS:System.Collections.Generic.List`1::.ctor
02d604b0: bl      #0x2b70db0                                 fn_2b70db0
02d604b4: adrp    x0, #0x626b000                             
02d604b8: ldr     x0, [x0, #0xe80]                           MS:System.Collections.Generic.List`1::get_Count
02d604bc: bl      #0x2b70db0                                 fn_2b70db0
02d604c0: adrp    x0, #0x626b000                             
02d604c4: ldr     x0, [x0, #0xe88]                           MS:System.Collections.Generic.List`1::get_Item
02d604c8: bl      #0x2b70db0                                 fn_2b70db0
02d604cc: adrp    x0, #0x6266000                             
02d604d0: ldr     x0, [x0, #0x648]                           T:type15061(k15)
02d604d4: bl      #0x2b70db0                                 fn_2b70db0
02d604d8: mov     w8, #1                                     
02d604dc: strb    w8, [x21, #0x2f6]                          
02d604e0: ldr     x0, [x22]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d604e4: bl      #0x2b7104c                                 fn_2b7104c
02d604e8: ldr     x1, [x20]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d604ec: mov     x20, x0                                    
02d604f0: bl      #0x3569388                                 fn_3569388
02d604f4: ldr     x0, [x19, #0x68]                           ._keycapObjects
02d604f8: cbz     x0, #0x2d60590                             
02d604fc: adrp    x22, #0x626b000                            
02d60500: adrp    x23, #0x6266000                            
02d60504: mov     w21, wzr                                   
02d60508: ldr     x22, [x22, #0xe88]                         MS:System.Collections.Generic.List`1::get_Item
02d6050c: ldr     x23, [x23, #0x818]                         MS:System.Collections.Generic.List`1::Add
02d60510: ldr     w8, [x0, #0x18]                            S:'level_show_popuprate'
02d60514: cmp     w21, w8                                    
02d60518: b.ge    #0x2d60594                                 
02d6051c: ldr     x2, [x22]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d60520: mov     w1, w21                                    
02d60524: bl      #0x35a8f3c                                 fn_35a8f3c
02d60528: cbz     x0, #0x2d60590                             
02d6052c: cbz     x20, #0x2d60590                            
02d60530: ldr     w10, [x20, #0x1c]                          [626601c]=0 f=0,0
02d60534: ldr     x8, [x20, #0x10]                           S:'mrec_ad_on_off'
02d60538: ldr     w1, [x0, #0x38]                            S:'native_collap_id' ._switchPositions
02d6053c: ldr     x9, [x23]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d60540: add     w10, w10, #1                               
02d60544: str     w10, [x20, #0x1c]                          
02d60548: cbz     x8, #0x2d60590                             
02d6054c: ldrsw   x10, [x20, #0x18]                          
02d60550: ldr     w11, [x8, #0x18]                           
02d60554: cmp     w10, w11                                   
02d60558: b.hs    #0x2d60570                                 
02d6055c: add     x8, x8, x10, lsl #2                        
02d60560: add     w9, w10, #1                                
02d60564: str     w9, [x20, #0x18]                           
02d60568: str     w1, [x8, #0x20]                            
02d6056c: b       #0x2d60584                                 
02d60570: ldr     x8, [x9, #0x20]                            
02d60574: mov     x0, x20                                    
02d60578: ldr     x8, [x8, #0xc0]                            
02d6057c: ldr     x2, [x8, #0x70]                            
02d60580: bl      #0x3569c18                                 fn_3569c18
02d60584: ldr     x0, [x19, #0x68]                           ._keycapObjects
02d60588: add     w21, w21, #1                               
02d6058c: cbnz    x0, #0x2d60510                             
02d60590: bl      #0x2b7105c                                 fn_2b7105c
02d60594: mov     x0, x20                                    
02d60598: ldp     x20, x19, [sp, #0x20]                      
02d6059c: ldp     x22, x21, [sp, #0x10]                      
02d605a0: ldp     x30, x23, [sp], #0x30                      
02d605a4: ret                                                
## ClickRandomKeycap() -> void
---- Clicker.BaseKeycapObject::ClickRandomKeycap 0x2d605a8
02d605a8: str     x30, [sp, #-0x20]!                         
02d605ac: stp     x20, x19, [sp, #0x10]                      
02d605b0: adrp    x20, #0x6630000                            
02d605b4: mov     x19, x0                                    
02d605b8: ldrb    w8, [x20, #0x2f7]                          
02d605bc: tbnz    w8, #0, #0x2d605e0                         
02d605c0: adrp    x0, #0x626b000                             
02d605c4: ldr     x0, [x0, #0xe60]                           MS:System.Collections.Generic.List`1::get_Count
02d605c8: bl      #0x2b70db0                                 fn_2b70db0
02d605cc: adrp    x0, #0x626b000                             
02d605d0: ldr     x0, [x0, #0xe68]                           MS:System.Collections.Generic.List`1::get_Item
02d605d4: bl      #0x2b70db0                                 fn_2b70db0
02d605d8: mov     w8, #1                                     
02d605dc: strb    w8, [x20, #0x2f7]                          
02d605e0: ldr     x19, [x19, #0x88]                          ._keycapClicks
02d605e4: cbz     x19, #0x2d60620                            
02d605e8: adrp    x20, #0x626b000                            
02d605ec: mov     w0, wzr                                    
02d605f0: mov     x2, xzr                                    
02d605f4: ldr     x20, [x20, #0xe68]                         MS:System.Collections.Generic.List`1::get_Item
02d605f8: ldr     w1, [x19, #0x18]                           
02d605fc: bl      #0x5b2e000                                 UnityEngine.Random::Range
02d60600: ldr     x2, [x20]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d60604: mov     w1, w0                                     
02d60608: mov     x0, x19                                    
02d6060c: bl      #0x35a8f3c                                 fn_35a8f3c
02d60610: cbz     x0, #0x2d60620                             
02d60614: ldp     x20, x19, [sp, #0x10]                      
02d60618: ldr     x30, [sp], #0x20                           
02d6061c: b       #0x2d60624                                 Clicker.KeycapClick::HandleClick
02d60620: bl      #0x2b7105c                                 fn_2b7105c
## RotateKeychain(bool isRotate) -> void
---- Clicker.BaseKeycapObject::RotateKeychain 0x2d60978
02d60978: stp     x30, x21, [sp, #-0x20]!                    
02d6097c: stp     x20, x19, [sp, #0x10]                      
02d60980: adrp    x21, #0x6630000                            
02d60984: mov     w20, w1                                    
02d60988: mov     x19, x0                                    
02d6098c: ldrb    w8, [x21, #0x2f8]                          
02d60990: tbnz    w8, #0, #0x2d609b4                         
02d60994: adrp    x0, #0x6267000                             
02d60998: ldr     x0, [x0, #0xd38]                           MS:DG.Tweening.TweenSettingsExtensions::SetEase
02d6099c: bl      #0x2b70db0                                 fn_2b70db0
02d609a0: adrp    x0, #0x6268000                             
02d609a4: ldr     x0, [x0, #0x4e8]                           MS:DG.Tweening.TweenSettingsExtensions::SetLoops
02d609a8: bl      #0x2b70db0                                 fn_2b70db0
02d609ac: mov     w8, #1                                     
02d609b0: strb    w8, [x21, #0x2f8]                          
02d609b4: ldr     x0, [x19, #0x78]                           ._srKeychain
02d609b8: tbz     w20, #0, #0x2d60af8                        
02d609bc: cbz     x0, #0x2d60b94                             
02d609c0: mov     x1, xzr                                    
02d609c4: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02d609c8: cbz     x0, #0x2d60b94                             
02d609cc: mov     x1, xzr                                    
02d609d0: bl      #0x5b466dc                                 UnityEngine.Transform::get_parent
02d609d4: mov     w1, wzr                                    
02d609d8: mov     x2, xzr                                    
02d609dc: bl      #0x2d9d5d0                                 DG.Tweening.ShortcutExtensions::DOKill
02d609e0: ldr     x0, [x19, #0x78]                           ._srKeychain
02d609e4: cbz     x0, #0x2d60b94                             
02d609e8: mov     x1, xzr                                    
02d609ec: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02d609f0: cbz     x0, #0x2d60b94                             
02d609f4: mov     x1, xzr                                    
02d609f8: bl      #0x5b466dc                                 UnityEngine.Transform::get_parent
02d609fc: adrp    x21, #0x662f000                            
02d60a00: mov     x20, x0                                    
02d60a04: ldrb    w8, [x21, #0x91a]                          
02d60a08: cbnz    w8, #0x2d60a20                             
02d60a0c: adrp    x0, #0x6264000                             
02d60a10: ldr     x0, [x0, #0xd8]                            T:UnityEngine.Vector3
02d60a14: bl      #0x2b70db0                                 fn_2b70db0
02d60a18: mov     w8, #1                                     
02d60a1c: strb    w8, [x21, #0x91a]                          
02d60a20: adrp    x21, #0x6264000                            
02d60a24: movi    d3, #0000000000000000                      
02d60a28: mov     x0, x20                                    
02d60a2c: ldr     x21, [x21, #0xd8]                          T:UnityEngine.Vector3
02d60a30: mov     w1, wzr                                    
02d60a34: mov     x2, xzr                                    
02d60a38: ldr     x8, [x21]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d60a3c: ldr     x8, [x8, #0xb8]                            
02d60a40: ldp     s0, s1, [x8]                               
02d60a44: ldr     s2, [x8, #8]                               
02d60a48: bl      #0x2d98760                                 DG.Tweening.ShortcutExtensions::DOLocalRotate
02d60a4c: ldr     x0, [x19, #0x78]                           ._srKeychain
02d60a50: cbz     x0, #0x2d60b94                             
02d60a54: mov     x1, xzr                                    
02d60a58: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02d60a5c: cbz     x0, #0x2d60b94                             
02d60a60: mov     x1, xzr                                    
02d60a64: bl      #0x5b466dc                                 UnityEngine.Transform::get_parent
02d60a68: adrp    x20, #0x662f000                            
02d60a6c: mov     x19, x0                                    
02d60a70: ldrb    w8, [x20, #0x91c]                          
02d60a74: cbnz    w8, #0x2d60a8c                             
02d60a78: adrp    x0, #0x6264000                             
02d60a7c: ldr     x0, [x0, #0xd8]                            T:UnityEngine.Vector3
02d60a80: bl      #0x2b70db0                                 fn_2b70db0
02d60a84: mov     w8, #1                                     
02d60a88: strb    w8, [x20, #0x91c]                          
02d60a8c: ldr     x8, [x21]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d60a90: movi    v0.2s, #0xc1, lsl #24                      
02d60a94: fmov    s3, #2.00000000                            
02d60a98: mov     x0, x19                                    
02d60a9c: mov     w1, wzr                                    
02d60aa0: mov     x2, xzr                                    
02d60aa4: ldr     x8, [x8, #0xb8]                            
02d60aa8: ldr     d1, [x8, #0x48]                            
02d60aac: ldr     s2, [x8, #0x50]                            
02d60ab0: fmul    v0.2s, v1.2s, v0.2s                        
02d60ab4: fmov    s1, #-8.00000000                           
02d60ab8: fmul    s2, s2, s1                                 
02d60abc: mov     s1, v0.s[1]                                
02d60ac0: bl      #0x2d98760                                 DG.Tweening.ShortcutExtensions::DOLocalRotate
02d60ac4: adrp    x8, #0x6267000                             
02d60ac8: mov     w1, #4                                     
02d60acc: ldr     x8, [x8, #0xd38]                           MS:DG.Tweening.TweenSettingsExtensions::SetEase
02d60ad0: ldr     x2, [x8]                                   S:'didu'
02d60ad4: bl      #0x336fa0c                                 fn_336fa0c
02d60ad8: adrp    x8, #0x6268000                             
02d60adc: mov     w1, #-1                                    
02d60ae0: mov     w2, #1                                     
02d60ae4: ldr     x8, [x8, #0x4e8]                           MS:DG.Tweening.TweenSettingsExtensions::SetLoops
02d60ae8: ldp     x20, x19, [sp, #0x10]                      
02d60aec: ldr     x3, [x8]                                   S:'{0}/2'
02d60af0: ldp     x30, x21, [sp], #0x20                      
02d60af4: b       #0x336fe74                                 
02d60af8: cbz     x0, #0x2d60b94                             
02d60afc: mov     x1, xzr                                    
02d60b00: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02d60b04: cbz     x0, #0x2d60b94                             
02d60b08: mov     x1, xzr                                    
02d60b0c: bl      #0x5b466dc                                 UnityEngine.Transform::get_parent
02d60b10: mov     w1, wzr                                    
02d60b14: mov     x2, xzr                                    
02d60b18: bl      #0x2d9d5d0                                 DG.Tweening.ShortcutExtensions::DOKill
02d60b1c: ldr     x0, [x19, #0x78]                           ._srKeychain
02d60b20: cbz     x0, #0x2d60b94                             
02d60b24: mov     x1, xzr                                    
02d60b28: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02d60b2c: cbz     x0, #0x2d60b94                             
02d60b30: mov     x1, xzr                                    
02d60b34: bl      #0x5b466dc                                 UnityEngine.Transform::get_parent
02d60b38: adrp    x20, #0x662f000                            
02d60b3c: mov     x19, x0                                    
02d60b40: ldrb    w8, [x20, #0x91a]                          
02d60b44: cbnz    w8, #0x2d60b5c                             
02d60b48: adrp    x0, #0x6264000                             
02d60b4c: ldr     x0, [x0, #0xd8]                            T:UnityEngine.Vector3
02d60b50: bl      #0x2b70db0                                 fn_2b70db0
02d60b54: mov     w8, #1                                     
02d60b58: strb    w8, [x20, #0x91a]                          
02d60b5c: adrp    x8, #0x6264000                             
02d60b60: adrp    x9, #0x1084000                             
02d60b64: mov     x0, x19                                    
02d60b68: ldr     x8, [x8, #0xd8]                            T:UnityEngine.Vector3
02d60b6c: ldp     x20, x19, [sp, #0x10]                      
02d60b70: ldr     s3, [x9, #0xf10]                           [1084f10]=4110bc863e99999a f=0.3,9.04603
02d60b74: mov     w1, wzr                                    
02d60b78: mov     x2, xzr                                    
02d60b7c: ldr     x8, [x8]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d60b80: ldr     x8, [x8, #0xb8]                            MS:DG.Tweening.Core.Extensions::SetSpecialStartupMode
02d60b84: ldp     s0, s1, [x8]                               
02d60b88: ldr     s2, [x8, #8]                               T:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass2_0
02d60b8c: ldp     x30, x21, [sp], #0x20                      
02d60b90: b       #0x2d98760                                 DG.Tweening.ShortcutExtensions::DOLocalRotate
02d60b94: bl      #0x2b7105c                                 fn_2b7105c
## SetGlowColor(UnityEngine.Color color) -> void
---- Clicker.BaseKeycapObject::SetGlowColor 0x2d60b98
02d60b98: stp     s0, s1, [x0, #0x50]                        ._switchGlowColor
02d60b9c: stp     s2, s3, [x0, #0x58]                        
02d60ba0: ret                                                
## ApplyGlowColor() -> void
---- Clicker.BaseKeycapObject::ApplyGlowColor 0x2d60ba4
02d60ba4: str     x30, [sp, #-0x30]!                         
02d60ba8: stp     x22, x21, [sp, #0x10]                      
02d60bac: stp     x20, x19, [sp, #0x20]                      
02d60bb0: adrp    x20, #0x6630000                            
02d60bb4: adrp    x22, #0x626b000                            
02d60bb8: adrp    x21, #0x626b000                            
02d60bbc: ldrb    w8, [x20, #0x2f9]                          
02d60bc0: ldr     x22, [x22, #0xd30]                         T:type53139(k15)
02d60bc4: ldr     x21, [x21, #0xf30]                         M:Clicker.BaseKeycapObject::<ApplyGlowColor>b__59_0
02d60bc8: mov     x19, x0                                    
02d60bcc: tbnz    w8, #0, #0x2d60bfc                         
02d60bd0: adrp    x0, #0x626b000                             
02d60bd4: ldr     x0, [x0, #0xd30]                           T:type53139(k15)
02d60bd8: bl      #0x2b70db0                                 fn_2b70db0
02d60bdc: adrp    x0, #0x626b000                             
02d60be0: ldr     x0, [x0, #0xf30]                           M:Clicker.BaseKeycapObject::<ApplyGlowColor>b__59_0
02d60be4: bl      #0x2b70db0                                 fn_2b70db0
02d60be8: adrp    x0, #0x626b000                             
02d60bec: ldr     x0, [x0, #0xd38]                           MS:System.Collections.Generic.List`1::ForEach
02d60bf0: bl      #0x2b70db0                                 fn_2b70db0
02d60bf4: mov     w8, #1                                     
02d60bf8: strb    w8, [x20, #0x2f9]                          
02d60bfc: ldr     x0, [x22]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d60c00: ldr     x20, [x19, #0x88]                          ._keycapClicks
02d60c04: bl      #0x2b7104c                                 fn_2b7104c
02d60c08: ldr     x2, [x21]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d60c0c: mov     x1, x19                                    
02d60c10: mov     x3, xzr                                    
02d60c14: mov     x21, x0                                    
02d60c18: bl      #0x453418c                                 fn_453418c
02d60c1c: cbz     x20, #0x2d60c44                            
02d60c20: adrp    x8, #0x626b000                             
02d60c24: mov     x0, x20                                    
02d60c28: mov     x1, x21                                    
02d60c2c: ldr     x8, [x8, #0xd38]                           MS:System.Collections.Generic.List`1::ForEach
02d60c30: ldp     x20, x19, [sp, #0x20]                      
02d60c34: ldp     x22, x21, [sp, #0x10]                      
02d60c38: ldr     x2, [x8]                                   T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d60c3c: ldr     x30, [sp], #0x30                           
02d60c40: b       #0x35a9ce4                                 
02d60c44: bl      #0x2b7105c                                 fn_2b7105c
## UpdateGlowSprite() -> void
---- Clicker.BaseKeycapObject::UpdateGlowSprite 0x2d60c48
02d60c48: str     x30, [sp, #-0x30]!                         
02d60c4c: stp     x22, x21, [sp, #0x10]                      
02d60c50: stp     x20, x19, [sp, #0x20]                      
02d60c54: adrp    x20, #0x6630000                            
02d60c58: adrp    x22, #0x626b000                            
02d60c5c: mov     x19, x0                                    
02d60c60: ldrb    w8, [x20, #0x2fa]                          
02d60c64: ldr     x22, [x22, #0xdf8]                         T:Clicker.BaseKeycapObject/<>c
02d60c68: tbnz    w8, #0, #0x2d60ca4                         
02d60c6c: adrp    x0, #0x626b000                             
02d60c70: ldr     x0, [x0, #0xd30]                           T:type53139(k15)
02d60c74: bl      #0x2b70db0                                 fn_2b70db0
02d60c78: adrp    x0, #0x626b000                             
02d60c7c: ldr     x0, [x0, #0xd38]                           MS:System.Collections.Generic.List`1::ForEach
02d60c80: bl      #0x2b70db0                                 fn_2b70db0
02d60c84: adrp    x0, #0x626b000                             
02d60c88: ldr     x0, [x0, #0xf38]                           M:Clicker.BaseKeycapObject/<>c::<UpdateGlowSprite>b__60_0
02d60c8c: bl      #0x2b70db0                                 fn_2b70db0
02d60c90: adrp    x0, #0x626b000                             
02d60c94: ldr     x0, [x0, #0xdf8]                           T:Clicker.BaseKeycapObject/<>c
02d60c98: bl      #0x2b70db0                                 fn_2b70db0
02d60c9c: mov     w8, #1                                     
02d60ca0: strb    w8, [x20, #0x2fa]                          
02d60ca4: ldr     x0, [x22]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d60ca8: ldr     x19, [x19, #0x88]                          ._keycapClicks
02d60cac: ldr     w8, [x0, #0xe4]                            [626b0e4]=0 f=0,0
02d60cb0: cbnz    w8, #0x2d60cbc                             
02d60cb4: bl      #0x2b70f30                                 fn_2b70f30
02d60cb8: ldr     x0, [x22]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d60cbc: ldr     x8, [x0, #0xb8]                            S:'scoop_no_thank'
02d60cc0: ldr     x20, [x8, #0x48]                           
02d60cc4: cbnz    x20, #0x2d60d20                            
02d60cc8: ldr     w9, [x0, #0xe4]                            [626b0e4]=0 f=0,0
02d60ccc: cbnz    w9, #0x2d60cdc                             
02d60cd0: bl      #0x2b70f30                                 fn_2b70f30
02d60cd4: ldr     x8, [x22]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d60cd8: ldr     x8, [x8, #0xb8]                            
02d60cdc: adrp    x9, #0x626b000                             
02d60ce0: ldr     x9, [x9, #0xd30]                           T:type53139(k15)
02d60ce4: ldr     x21, [x8]                                  
02d60ce8: ldr     x0, [x9]                                   T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d60cec: bl      #0x2b7104c                                 fn_2b7104c
02d60cf0: adrp    x8, #0x626b000                             
02d60cf4: mov     x1, x21                                    
02d60cf8: mov     x3, xzr                                    
02d60cfc: ldr     x8, [x8, #0xf38]                           M:Clicker.BaseKeycapObject/<>c::<UpdateGlowSprite>b__60_0
02d60d00: mov     x20, x0                                    
02d60d04: ldr     x2, [x8]                                   T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d60d08: bl      #0x453418c                                 fn_453418c
02d60d0c: ldr     x8, [x22]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d60d10: mov     x1, x20                                    
02d60d14: ldr     x0, [x8, #0xb8]                            S:'scoop_no_thank'
02d60d18: str     x20, [x0, #0x48]!                          ._switchPlaced
02d60d1c: bl      #0x2b70d54                                 fn_2b70d54
02d60d20: cbz     x19, #0x2d60d48                            
02d60d24: adrp    x8, #0x626b000                             
02d60d28: mov     x0, x19                                    
02d60d2c: mov     x1, x20                                    
02d60d30: ldr     x8, [x8, #0xd38]                           MS:System.Collections.Generic.List`1::ForEach
02d60d34: ldp     x20, x19, [sp, #0x20]                      
02d60d38: ldp     x22, x21, [sp, #0x10]                      
02d60d3c: ldr     x2, [x8]                                   T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d60d40: ldr     x30, [sp], #0x30                           
02d60d44: b       #0x35a9ce4                                 
02d60d48: bl      #0x2b7105c                                 fn_2b7105c
## .ctor() -> void
---- Clicker.BaseKeycapObject::.ctor 0x2d60d4c
02d60d4c: fmov    v0.4s, #1.00000000                         
02d60d50: mov     x1, xzr                                    
02d60d54: mov     w8, #-1                                    
02d60d58: str     w8, [x0, #0x90]                            ._currentSetupKeycapIndex
02d60d5c: str     w8, [x0, #0xa0]                            ._closestIndex
02d60d60: str     q0, [x0, #0x50]                            ._switchGlowColor
02d60d64: b       #0x5b397b0                                 UnityEngine.MonoBehaviour::.ctor
## <Awake>b__27_0(Clicker.SwitchObject switchObj) -> void
---- Clicker.BaseKeycapObject::<Awake>b__27_0 0x2d60d68
02d60d68: stp     x30, x21, [sp, #-0x20]!                    
02d60d6c: stp     x20, x19, [sp, #0x10]                      
02d60d70: adrp    x21, #0x6630000                            
02d60d74: mov     x19, x1                                    
02d60d78: mov     x20, x0                                    
02d60d7c: ldrb    w8, [x21, #0x2fb]                          
02d60d80: tbnz    w8, #0, #0x2d60d98                         
02d60d84: adrp    x0, #0x626b000                             
02d60d88: ldr     x0, [x0, #0xad8]                           MS:System.Collections.Generic.List`1::Add
02d60d8c: bl      #0x2b70db0                                 fn_2b70db0
02d60d90: mov     w8, #1                                     
02d60d94: strb    w8, [x21, #0x2fb]                          
02d60d98: ldr     x0, [x20, #0x48]                           ._switchPlaced
02d60d9c: cbz     x0, #0x2d60e5c                             
02d60da0: adrp    x9, #0x626b000                             
02d60da4: ldr     x9, [x9, #0xad8]                           MS:System.Collections.Generic.List`1::Add
02d60da8: ldr     w10, [x0, #0x1c]                           [626b01c]=0 f=0,0
02d60dac: ldr     x8, [x0, #0x10]                            MS:System.Collections.Generic.List`1::Find
02d60db0: ldr     x9, [x9]                                   T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d60db4: add     w10, w10, #1                               
02d60db8: str     w10, [x0, #0x1c]                           
02d60dbc: cbz     x8, #0x2d60e5c                             
02d60dc0: ldrsw   x10, [x0, #0x18]                           
02d60dc4: ldr     w11, [x8, #0x18]                           
02d60dc8: cmp     w10, w11                                   
02d60dcc: b.hs    #0x2d60de4                                 
02d60dd0: add     w9, w10, #1                                
02d60dd4: add     x8, x8, x10                                
02d60dd8: str     w9, [x0, #0x18]                            
02d60ddc: strb    wzr, [x8, #0x20]                           
02d60de0: b       #0x2d60df8                                 
02d60de4: ldr     x8, [x9, #0x20]                            M:ScoopGame.CategoryAsset/<>c__DisplayClass4_0::<GetOptionDataByID>b__0
02d60de8: mov     w1, wzr                                    
02d60dec: ldr     x8, [x8, #0xc0]                            
02d60df0: ldr     x2, [x8, #0x70]                            
02d60df4: bl      #0x4baf73c                                 fn_4baf73c
02d60df8: cbz     x19, #0x2d60e5c                            
02d60dfc: mov     x0, x19                                    
02d60e00: mov     x1, xzr                                    
02d60e04: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02d60e08: adrp    x20, #0x662f000                            
02d60e0c: mov     x19, x0                                    
02d60e10: ldrb    w8, [x20, #0x91a]                          
02d60e14: cbnz    w8, #0x2d60e2c                             
02d60e18: adrp    x0, #0x6264000                             
02d60e1c: ldr     x0, [x0, #0xd8]                            T:UnityEngine.Vector3
02d60e20: bl      #0x2b70db0                                 fn_2b70db0
02d60e24: mov     w8, #1                                     
02d60e28: strb    w8, [x20, #0x91a]                          
02d60e2c: cbz     x19, #0x2d60e5c                            
02d60e30: adrp    x8, #0x6264000                             
02d60e34: mov     x0, x19                                    
02d60e38: mov     x1, xzr                                    
02d60e3c: ldr     x8, [x8, #0xd8]                            T:UnityEngine.Vector3
02d60e40: ldp     x20, x19, [sp, #0x10]                      
02d60e44: ldr     x8, [x8]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d60e48: ldr     x8, [x8, #0xb8]                            MS:DG.Tweening.Core.Extensions::SetSpecialStartupMode
02d60e4c: ldp     s0, s1, [x8]                               
02d60e50: ldr     s2, [x8, #8]                               T:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass2_0
02d60e54: ldp     x30, x21, [sp], #0x20                      
02d60e58: b       #0x5b470cc                                 UnityEngine.Transform::set_localScale
02d60e5c: bl      #0x2b7105c                                 fn_2b7105c
## <Awake>b__27_1(Clicker.KeycapObject keycapObj) -> void
---- Clicker.BaseKeycapObject::<Awake>b__27_1 0x2d60e60
02d60e60: stp     x30, x21, [sp, #-0x20]!                    
02d60e64: stp     x20, x19, [sp, #0x10]                      
02d60e68: adrp    x21, #0x6630000                            
02d60e6c: mov     x19, x1                                    
02d60e70: mov     x20, x0                                    
02d60e74: ldrb    w8, [x21, #0x2fc]                          
02d60e78: tbnz    w8, #0, #0x2d60e90                         
02d60e7c: adrp    x0, #0x626b000                             
02d60e80: ldr     x0, [x0, #0xad8]                           MS:System.Collections.Generic.List`1::Add
02d60e84: bl      #0x2b70db0                                 fn_2b70db0
02d60e88: mov     w8, #1                                     
02d60e8c: strb    w8, [x21, #0x2fc]                          
02d60e90: ldr     x0, [x20, #0x70]                           ._keycapPlaced
02d60e94: cbz     x0, #0x2d60f54                             
02d60e98: adrp    x9, #0x626b000                             
02d60e9c: ldr     x9, [x9, #0xad8]                           MS:System.Collections.Generic.List`1::Add
02d60ea0: ldr     w10, [x0, #0x1c]                           [626b01c]=0 f=0,0
02d60ea4: ldr     x8, [x0, #0x10]                            MS:System.Collections.Generic.List`1::Find
02d60ea8: ldr     x9, [x9]                                   T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d60eac: add     w10, w10, #1                               
02d60eb0: str     w10, [x0, #0x1c]                           
02d60eb4: cbz     x8, #0x2d60f54                             
02d60eb8: ldrsw   x10, [x0, #0x18]                           
02d60ebc: ldr     w11, [x8, #0x18]                           
02d60ec0: cmp     w10, w11                                   
02d60ec4: b.hs    #0x2d60edc                                 
02d60ec8: add     w9, w10, #1                                
02d60ecc: add     x8, x8, x10                                
02d60ed0: str     w9, [x0, #0x18]                            
02d60ed4: strb    wzr, [x8, #0x20]                           
02d60ed8: b       #0x2d60ef0                                 
02d60edc: ldr     x8, [x9, #0x20]                            M:ScoopGame.CategoryAsset/<>c__DisplayClass4_0::<GetOptionDataByID>b__0
02d60ee0: mov     w1, wzr                                    
02d60ee4: ldr     x8, [x8, #0xc0]                            
02d60ee8: ldr     x2, [x8, #0x70]                            
02d60eec: bl      #0x4baf73c                                 fn_4baf73c
02d60ef0: cbz     x19, #0x2d60f54                            
02d60ef4: mov     x0, x19                                    
02d60ef8: mov     x1, xzr                                    
02d60efc: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02d60f00: adrp    x20, #0x662f000                            
02d60f04: mov     x19, x0                                    
02d60f08: ldrb    w8, [x20, #0x91a]                          
02d60f0c: cbnz    w8, #0x2d60f24                             
02d60f10: adrp    x0, #0x6264000                             
02d60f14: ldr     x0, [x0, #0xd8]                            T:UnityEngine.Vector3
02d60f18: bl      #0x2b70db0                                 fn_2b70db0
02d60f1c: mov     w8, #1                                     
02d60f20: strb    w8, [x20, #0x91a]                          
02d60f24: cbz     x19, #0x2d60f54                            
02d60f28: adrp    x8, #0x6264000                             
02d60f2c: mov     x0, x19                                    
02d60f30: mov     x1, xzr                                    
02d60f34: ldr     x8, [x8, #0xd8]                            T:UnityEngine.Vector3
02d60f38: ldp     x20, x19, [sp, #0x10]                      
02d60f3c: ldr     x8, [x8]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d60f40: ldr     x8, [x8, #0xb8]                            MS:DG.Tweening.Core.Extensions::SetSpecialStartupMode
02d60f44: ldp     s0, s1, [x8]                               
02d60f48: ldr     s2, [x8, #8]                               T:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass2_0
02d60f4c: ldp     x30, x21, [sp], #0x20                      
02d60f50: b       #0x5b470cc                                 UnityEngine.Transform::set_localScale
02d60f54: bl      #0x2b7105c                                 fn_2b7105c
## <DropKeycapReal>b__52_0() -> void
---- Clicker.BaseKeycapObject::<DropKeycapReal>b__52_0 0x2d60f58
02d60f58: b       #0x2d60c48                                 Clicker.BaseKeycapObject::UpdateGlowSprite
## <ApplyGlowColor>b__59_0(Clicker.KeycapClick keycapClick) -> void
---- Clicker.BaseKeycapObject::<ApplyGlowColor>b__59_0 0x2d60f5c
02d60f5c: cbz     x1, #0x2d60f70                             
02d60f60: ldp     s0, s1, [x0, #0x50]                        ._switchGlowColor
02d60f64: ldp     s2, s3, [x0, #0x58]                        
02d60f68: mov     x0, x1                                     
02d60f6c: b       #0x2d60f78                                 Clicker.KeycapClick::CreateGlowEffect
02d60f70: str     x30, [sp, #-0x10]!                         
02d60f74: bl      #0x2b7105c                                 fn_2b7105c
