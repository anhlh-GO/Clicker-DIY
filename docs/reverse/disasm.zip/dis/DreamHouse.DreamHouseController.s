#### CLASS DreamHouse.DreamHouseController parent= MonoSingleton`1<DreamHouse.DreamHouseController>
#   field _uiManager                     IUIManager                                         off=0x20 attr=6 HideInInspector
#   field _dreamHouseAsset               DreamHouse.DreamHouseAsset                         off=0x28 attr=1 
#   field _dataDreamHouse                DreamHouse.DataDreamHouse                          off=0x30 attr=1 
#   field _currentRoomIndex              int                                                off=0x38 attr=1 
#   field <CurrentRoom>k__BackingField   DreamHouse.RoomController                          off=0x40 attr=1 CompilerGeneratedAttribute
#   field <DecorItemPanel>k__BackingField DreamHouse.DecorItemPanel                          off=0x48 attr=1 CompilerGeneratedAttribute
#   field <IsCompletedAllRoom>k__BackingField bool                                               off=0x50 attr=1 CompilerGeneratedAttribute
## get_CurrentRoom() -> DreamHouse.RoomController
---- DreamHouse.DreamHouseController::get_CurrentRoom 0x2d179a4
02d179a4: ldr     x0, [x0, #0x40]                            .<CurrentRoom>k__BackingField
02d179a8: ret                                                
## set_CurrentRoom(DreamHouse.RoomController value) -> void
---- DreamHouse.DreamHouseController::set_CurrentRoom 0x2d179ac
02d179ac: str     x1, [x0, #0x40]!                           .<CurrentRoom>k__BackingField
02d179b0: b       #0x2b70d54                                 
## get_DecorItemPanel() -> DreamHouse.DecorItemPanel
---- DreamHouse.DreamHouseController::get_DecorItemPanel 0x2d179b4
02d179b4: ldr     x0, [x0, #0x48]                            .<DecorItemPanel>k__BackingField
02d179b8: ret                                                
## set_DecorItemPanel(DreamHouse.DecorItemPanel value) -> void
---- DreamHouse.DreamHouseController::set_DecorItemPanel 0x2d179bc
02d179bc: str     x1, [x0, #0x48]!                           .<DecorItemPanel>k__BackingField
02d179c0: b       #0x2b70d54                                 
## get_DreamHouseAsset() -> DreamHouse.DreamHouseAsset
---- DreamHouse.DreamHouseController::get_DreamHouseAsset 0x2d179c4
02d179c4: ldr     x0, [x0, #0x28]                            ._dreamHouseAsset
02d179c8: ret                                                
## get_DataDreamHouse() -> DreamHouse.DataDreamHouse
---- DreamHouse.DreamHouseController::get_DataDreamHouse 0x2d179cc
02d179cc: ldr     x0, [x0, #0x30]                            ._dataDreamHouse
02d179d0: ret                                                
## get_IsCompletedAllRoom() -> bool
---- DreamHouse.DreamHouseController::get_IsCompletedAllRoom 0x2d179d4
02d179d4: ldrb    w0, [x0, #0x50]                            .<IsCompletedAllRoom>k__BackingField
02d179d8: ret                                                
## set_IsCompletedAllRoom(bool value) -> void
---- DreamHouse.DreamHouseController::set_IsCompletedAllRoom 0x2d179dc
02d179dc: strb    w1, [x0, #0x50]                            .<IsCompletedAllRoom>k__BackingField
02d179e0: ret                                                
## Start() -> void
---- DreamHouse.DreamHouseController::Start 0x2d179e4
02d179e4: stp     x30, x21, [sp, #-0x20]!                    
02d179e8: stp     x20, x19, [sp, #0x10]                      
02d179ec: adrp    x20, #0x662f000                            
02d179f0: adrp    x21, #0x6265000                            
02d179f4: mov     x19, x0                                    
02d179f8: ldrb    w8, [x20, #0xfe5]                          
02d179fc: ldr     x21, [x21, #0x10]                          MS:MonoSingleton`1::get_Instance
02d17a00: tbnz    w8, #0, #0x2d17a90                         
02d17a04: adrp    x0, #0x6269000                             
02d17a08: ldr     x0, [x0, #0x9e0]                           MS:DataManager::GetAsset
02d17a0c: bl      #0x2b70db0                                 fn_2b70db0
02d17a10: adrp    x0, #0x6269000                             
02d17a14: ldr     x0, [x0, #0x9e8]                           MS:DataManager::GetData
02d17a18: bl      #0x2b70db0                                 fn_2b70db0
02d17a1c: adrp    x0, #0x6269000                             
02d17a20: ldr     x0, [x0, #0x9f0]                           M:DreamHouse.DreamHouseController::<Start>b__20_0
02d17a24: bl      #0x2b70db0                                 fn_2b70db0
02d17a28: adrp    x0, #0x6269000                             
02d17a2c: ldr     x0, [x0, #0x9f8]                           MS:IUIManager::ShowScreen
02d17a30: bl      #0x2b70db0                                 fn_2b70db0
02d17a34: adrp    x0, #0x6269000                             
02d17a38: ldr     x0, [x0, #0xa00]                           MS:MonoSingleton`1::get_Instance
02d17a3c: bl      #0x2b70db0                                 fn_2b70db0
02d17a40: adrp    x0, #0x6269000                             
02d17a44: ldr     x0, [x0, #0xa08]                           MS:MonoSingleton`1::get_Instance
02d17a48: bl      #0x2b70db0                                 fn_2b70db0
02d17a4c: adrp    x0, #0x6267000                             
02d17a50: ldr     x0, [x0, #0xbd0]                           MS:MonoSingleton`1::get_Instance
02d17a54: bl      #0x2b70db0                                 fn_2b70db0
02d17a58: adrp    x0, #0x6265000                             
02d17a5c: ldr     x0, [x0, #0x10]                            MS:MonoSingleton`1::get_Instance
02d17a60: bl      #0x2b70db0                                 fn_2b70db0
02d17a64: adrp    x0, #0x6266000                             
02d17a68: ldr     x0, [x0, #0x658]                           MS:MonoSingleton`1::get_Instance
02d17a6c: bl      #0x2b70db0                                 fn_2b70db0
02d17a70: adrp    x0, #0x6264000                             
02d17a74: ldr     x0, [x0, #0xe8]                            T:DG.Tweening.TweenCallback
02d17a78: bl      #0x2b70db0                                 fn_2b70db0
02d17a7c: adrp    x0, #0x6269000                             
02d17a80: ldr     x0, [x0, #0xa10]                           S:'dream_house_play'
02d17a84: bl      #0x2b70db0                                 fn_2b70db0
02d17a88: mov     w8, #1                                     
02d17a8c: strb    w8, [x20, #0xfe5]                          
02d17a90: ldr     x0, [x21]                                  M:AdsManager::<OnApplicationPause>b__26_0
02d17a94: bl      #0x3769600                                 fn_3769600
02d17a98: cbz     x0, #0x2d17cb8                             
02d17a9c: adrp    x20, #0x6269000                            
02d17aa0: mov     x1, xzr                                    
02d17aa4: ldr     x20, [x20, #0xa00]                         MS:MonoSingleton`1::get_Instance
02d17aa8: bl      #0x2cdff7c                                 SimpleSceneTransition::FadeOut
02d17aac: ldr     x0, [x20]                                  T:Trading.TradingSession/<>c__DisplayClass56_0
02d17ab0: bl      #0x3769600                                 fn_3769600
02d17ab4: cbz     x0, #0x2d17cb8                             
02d17ab8: fmov    s0, #13.50000000                           
02d17abc: adrp    x20, #0x6266000                            
02d17ac0: mov     w1, #1                                     
02d17ac4: ldr     x20, [x20, #0x658]                         MS:MonoSingleton`1::get_Instance
02d17ac8: mov     x2, xzr                                    
02d17acc: bl      #0x2cda144                                 CameraController::SetSizeHasClamp
02d17ad0: ldr     x0, [x20]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d17ad4: bl      #0x3769600                                 fn_3769600
02d17ad8: cbz     x0, #0x2d17cb8                             
02d17adc: adrp    x8, #0x6269000                             
02d17ae0: ldr     x8, [x8, #0x9e0]                           MS:DataManager::GetAsset
02d17ae4: ldr     x1, [x8]                                   T:Trading.TradingSession/<>c__DisplayClass56_0
02d17ae8: bl      #0x3168af0                                 fn_3168af0
02d17aec: mov     x1, x0                                     
02d17af0: mov     x0, x19                                    
02d17af4: str     x1, [x0, #0x28]!                           ._dreamHouseAsset
02d17af8: bl      #0x2b70d54                                 fn_2b70d54
02d17afc: ldr     x0, [x20]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d17b00: bl      #0x3769600                                 fn_3769600
02d17b04: cbz     x0, #0x2d17cb8                             
02d17b08: adrp    x8, #0x6269000                             
02d17b0c: adrp    x20, #0x6267000                            
02d17b10: ldr     x8, [x8, #0x9e8]                           MS:DataManager::GetData
02d17b14: ldr     x20, [x20, #0xbd0]                         MS:MonoSingleton`1::get_Instance
02d17b18: ldr     x1, [x8]                                   T:Trading.TradingSession/<>c__DisplayClass56_0
02d17b1c: bl      #0x3168dd0                                 fn_3168dd0
02d17b20: mov     x1, x0                                     
02d17b24: mov     x0, x19                                    
02d17b28: str     x1, [x0, #0x30]!                           ._dataDreamHouse
02d17b2c: bl      #0x2b70d54                                 fn_2b70d54
02d17b30: ldr     x0, [x20]                                  S:'didu'
02d17b34: bl      #0x3769600                                 fn_3769600
02d17b38: mov     x20, x19                                   
02d17b3c: mov     x1, x0                                     
02d17b40: str     x0, [x20, #0x20]!                          ._uiManager
02d17b44: mov     x0, x20                                    
02d17b48: bl      #0x2b70d54                                 fn_2b70d54
02d17b4c: ldr     x20, [x20]                                 S:'didu'
02d17b50: cbz     x20, #0x2d17cb8                            
02d17b54: adrp    x9, #0x6269000                             
02d17b58: ldr     x9, [x9, #0x9f8]                           MS:IUIManager::ShowScreen
02d17b5c: ldr     x8, [x20]                                  S:'didu'
02d17b60: ldr     x21, [x9]                                  T:Trading.TradingSession/<>c__DisplayClass56_0
02d17b64: ldrh    w9, [x8, #0x12e]                           
02d17b68: ldr     x1, [x21, #0x20]                           S:'dev log AdsManager show app open ad' ._uiManager
02d17b6c: ldrh    w2, [x21, #0x50]                           .<IsCompletedAllRoom>k__BackingField
02d17b70: cbz     x9, #0x2d17b94                             
02d17b74: ldr     x10, [x8, #0xb0]                           M:Trading.TradingSession/<>c__DisplayClass65_0::<BuildResult>b__0
02d17b78: add     x10, x10, #8                               
02d17b7c: ldur    x11, [x10, #-8]                            
02d17b80: cmp     x11, x1                                    
02d17b84: b.eq    #0x2d17ba0                                 
02d17b88: subs    x9, x9, #1                                 
02d17b8c: add     x10, x10, #0x10                            
02d17b90: b.ne    #0x2d17b7c                                 
02d17b94: mov     x0, x20                                    
02d17b98: bl      #0x2baa05c                                 fn_2baa05c
02d17b9c: b       #0x2d17bb0                                 
02d17ba0: ldr     w9, [x10]                                  
02d17ba4: add     w9, w9, w2                                 
02d17ba8: add     x8, x8, w9, sxtw #4                        &6269000
02d17bac: add     x0, x8, #0x138                             &6269138
02d17bb0: ldr     x0, [x0, #8]                               MS:System.Collections.Generic.List`1::RemoveAll
02d17bb4: mov     x1, x21                                    
02d17bb8: bl      #0x2b70f2c                                 fn_2b70f2c
02d17bbc: ldr     x8, [x0, #8]                               MS:System.Collections.Generic.List`1::RemoveAll
02d17bc0: mov     x1, x0                                     
02d17bc4: mov     x0, x20                                    
02d17bc8: blr     x8                                         
02d17bcc: cbz     x0, #0x2d17cb8                             
02d17bd0: ldr     x1, [x0, #0x58]                            M:Trading.TradingSession/<>c::<UsedNpcIds>b__64_0
02d17bd4: mov     x20, x19                                   
02d17bd8: str     x1, [x20, #0x48]!                          .<DecorItemPanel>k__BackingField
02d17bdc: mov     x0, x20                                    
02d17be0: bl      #0x2b70d54                                 fn_2b70d54
02d17be4: ldur    x8, [x20, #-0x18]                          
02d17be8: cbz     x8, #0x2d17cb8                             
02d17bec: ldr     x8, [x8, #0x20]                            M:Trading.TradingSession::<ValidateTrade>b__57_1
02d17bf0: cbz     x8, #0x2d17cb8                             
02d17bf4: ldr     w1, [x8, #0x14]                            [6269014]=0 f=0,0
02d17bf8: adrp    x20, #0x6269000                            
02d17bfc: mov     x0, x19                                    
02d17c00: ldr     x20, [x20, #0xa10]                         S:'dream_house_play'
02d17c04: strb    wzr, [x19, #0x50]                          .<IsCompletedAllRoom>k__BackingField
02d17c08: str     w1, [x19, #0x38]                           ._currentRoomIndex
02d17c0c: bl      #0x2d17cbc                                 DreamHouse.DreamHouseController::StartRoom
02d17c10: ldr     x0, [x20]                                  T:Trading.TradingSession/<>c__DisplayClass56_0
02d17c14: mov     w1, wzr                                    
02d17c18: mov     x2, xzr                                    
02d17c1c: bl      #0x5b2d1dc                                 UnityEngine.PlayerPrefs::GetInt
02d17c20: ldr     x0, [x20]                                  T:Trading.TradingSession/<>c__DisplayClass56_0
02d17c24: mov     w1, wzr                                    
02d17c28: mov     x2, xzr                                    
02d17c2c: bl      #0x5b2d1dc                                 UnityEngine.PlayerPrefs::GetInt
02d17c30: cbz     w0, #0x2d17c40                             
02d17c34: ldp     x20, x19, [sp, #0x10]                      
02d17c38: ldp     x30, x21, [sp], #0x20                      
02d17c3c: ret                                                
02d17c40: ldr     x0, [x20]                                  T:Trading.TradingSession/<>c__DisplayClass56_0
02d17c44: mov     w1, #1                                     
02d17c48: mov     x2, xzr                                    
02d17c4c: bl      #0x5b2d184                                 UnityEngine.PlayerPrefs::SetInt
02d17c50: adrp    x8, #0x6269000                             
02d17c54: ldr     x8, [x8, #0xa08]                           MS:MonoSingleton`1::get_Instance
02d17c58: ldr     x0, [x8]                                   T:Trading.TradingSession/<>c__DisplayClass56_0
02d17c5c: bl      #0x3769600                                 fn_3769600
02d17c60: cbz     x0, #0x2d17cb8                             
02d17c64: mov     x1, xzr                                    
02d17c68: bl      #0x2cae748                                 DreamHouseFirstGameTutorial::ShowIntro
02d17c6c: adrp    x8, #0x6264000                             
02d17c70: ldr     x8, [x8, #0xe8]                            T:DG.Tweening.TweenCallback
02d17c74: ldr     x0, [x8]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d17c78: bl      #0x2b7104c                                 fn_2b7104c
02d17c7c: adrp    x8, #0x6269000                             
02d17c80: mov     x1, x19                                    
02d17c84: mov     x3, xzr                                    
02d17c88: ldr     x8, [x8, #0x9f0]                           M:DreamHouse.DreamHouseController::<Start>b__20_0
02d17c8c: mov     x20, x0                                    
02d17c90: ldr     x2, [x8]                                   T:Trading.TradingSession/<>c__DisplayClass56_0
02d17c94: bl      #0x2d89dc4                                 DG.Tweening.TweenCallback::.ctor
02d17c98: adrp    x8, #0x1084000                             
02d17c9c: mov     x0, x20                                    
02d17ca0: mov     w1, #1                                     
02d17ca4: ldp     x20, x19, [sp, #0x10]                      
02d17ca8: ldr     s0, [x8, #0xeec]                           [1084eec]=457ff0003dcccccd f=0.1,4095
02d17cac: mov     x2, xzr                                    
02d17cb0: ldp     x30, x21, [sp], #0x20                      
02d17cb4: b       #0x2d8f37c                                 DG.Tweening.DOVirtual::DelayedCall
02d17cb8: bl      #0x2b7105c                                 fn_2b7105c
## StartRoom(int roomIndex) -> void
---- DreamHouse.DreamHouseController::StartRoom 0x2d17cbc
02d17cbc: stp     d11, d10, [sp, #-0x60]!                    
02d17cc0: stp     d9, d8, [sp, #0x10]                        
02d17cc4: str     x30, [sp, #0x20]                           
02d17cc8: stp     x24, x23, [sp, #0x30]                      
02d17ccc: stp     x22, x21, [sp, #0x40]                      
02d17cd0: stp     x20, x19, [sp, #0x50]                      
02d17cd4: adrp    x20, #0x662f000                            
02d17cd8: mov     w21, w1                                    
02d17cdc: mov     x19, x0                                    
02d17ce0: ldrb    w8, [x20, #0xfe6]                          
02d17ce4: str     w1, [sp, #0x2c]                            
02d17ce8: tbnz    w8, #0, #0x2d17d48                         
02d17cec: adrp    x0, #0x6263000                             
02d17cf0: ldr     x0, [x0, #0x928]                           T:UnityEngine.Debug
02d17cf4: bl      #0x2b70db0                                 fn_2b70db0
02d17cf8: adrp    x0, #0x6269000                             
02d17cfc: ldr     x0, [x0, #0xa18]                           MS:UnityEngine.GameObject::GetComponent
02d17d00: bl      #0x2b70db0                                 fn_2b70db0
02d17d04: adrp    x0, #0x6269000                             
02d17d08: ldr     x0, [x0, #0x888]                           MS:System.Collections.Generic.List`1::get_Count
02d17d0c: bl      #0x2b70db0                                 fn_2b70db0
02d17d10: adrp    x0, #0x6269000                             
02d17d14: ldr     x0, [x0, #0x890]                           MS:System.Collections.Generic.List`1::get_Item
02d17d18: bl      #0x2b70db0                                 fn_2b70db0
02d17d1c: adrp    x0, #0x6268000                             
02d17d20: ldr     x0, [x0, #0x730]                           MS:UnityEngine.Object::Instantiate
02d17d24: bl      #0x2b70db0                                 fn_2b70db0
02d17d28: adrp    x0, #0x6263000                             
02d17d2c: ldr     x0, [x0, #0x918]                           T:UnityEngine.Object
02d17d30: bl      #0x2b70db0                                 fn_2b70db0
02d17d34: adrp    x0, #0x6269000                             
02d17d38: ldr     x0, [x0, #0xa20]                           S:'Invalid room index: '
02d17d3c: bl      #0x2b70db0                                 fn_2b70db0
02d17d40: mov     w8, #1                                     
02d17d44: strb    w8, [x20, #0xfe6]                          
02d17d48: tbnz    w21, #0x1f, #0x2d17ef8                     
02d17d4c: ldr     x8, [x19, #0x28]                           ._dreamHouseAsset
02d17d50: cbz     x8, #0x2d17f68                             
02d17d54: ldr     x8, [x8, #0x18]                            
02d17d58: cbz     x8, #0x2d17f68                             
02d17d5c: ldr     w8, [x8, #0x18]                            
02d17d60: cmp     w8, w21                                    
02d17d64: b.le    #0x2d17ef8                                 
02d17d68: adrp    x23, #0x6263000                            
02d17d6c: mov     x20, x19                                   
02d17d70: ldr     x23, [x23, #0x918]                         T:UnityEngine.Object
02d17d74: ldr     x22, [x20, #0x40]!                         &2b70700(=14cc750491004000) .<CurrentRoom>k__BackingField
02d17d78: stur    w21, [x20, #-8]                            
02d17d7c: ldr     x0, [x23]                                  &2c5bbd4(=a9bd7bfdd503233f)
02d17d80: ldr     w8, [x0, #0xe4]                            [62690e4]=0 f=0,0
02d17d84: cbnz    w8, #0x2d17d8c                             
02d17d88: bl      #0x2b70f30                                 fn_2b70f30
02d17d8c: mov     x0, x22                                    
02d17d90: mov     x1, xzr                                    
02d17d94: mov     x2, xzr                                    
02d17d98: bl      #0x5b3666c                                 UnityEngine.Object::op_Inequality
02d17d9c: tbz     w0, #0, #0x2d17de4                         
02d17da0: ldr     x0, [x20]                                  &2b706c4(=eb01011ff9400808)
02d17da4: cbz     x0, #0x2d17f68                             
02d17da8: mov     x1, xzr                                    
02d17dac: bl      #0x5b339ec                                 UnityEngine.Component::get_gameObject
02d17db0: ldr     x8, [x23]                                  &2c5bbd4(=a9bd7bfdd503233f)
02d17db4: mov     x21, x0                                    
02d17db8: ldr     w9, [x8, #0xe4]                            
02d17dbc: cbnz    w9, #0x2d17dc8                             
02d17dc0: mov     x0, x8                                     
02d17dc4: bl      #0x2b70f30                                 fn_2b70f30
02d17dc8: mov     x0, x21                                    
02d17dcc: mov     x1, xzr                                    
02d17dd0: bl      #0x5b3ca38                                 UnityEngine.Object::Destroy
02d17dd4: mov     x0, x20                                    
02d17dd8: mov     x1, xzr                                    
02d17ddc: str     xzr, [x20]                                 
02d17de0: bl      #0x2b70d54                                 fn_2b70d54
02d17de4: ldr     x8, [x19, #0x28]                           ._dreamHouseAsset
02d17de8: cbz     x8, #0x2d17f68                             
02d17dec: ldr     x0, [x8, #0x18]                            
02d17df0: cbz     x0, #0x2d17f68                             
02d17df4: adrp    x22, #0x6269000                            
02d17df8: ldr     x22, [x22, #0x890]                         MS:System.Collections.Generic.List`1::get_Item
02d17dfc: ldr     w1, [x19, #0x38]                           ._currentRoomIndex
02d17e00: ldr     x2, [x22]                                  T:Trading.TradingSession/<>c__DisplayClass56_0
02d17e04: bl      #0x35a8f3c                                 fn_35a8f3c
02d17e08: cbz     x0, #0x2d17f68                             
02d17e0c: adrp    x24, #0x662f000                            
02d17e10: ldr     x21, [x0, #0x28]                           T:Trading.TradingCounterRequest ._dreamHouseAsset
02d17e14: ldrb    w8, [x24, #0xbdf]                          
02d17e18: cbnz    w8, #0x2d17e30                             
02d17e1c: adrp    x0, #0x6266000                             
02d17e20: ldr     x0, [x0, #0xd30]                           T:UnityEngine.Quaternion
02d17e24: bl      #0x2b70db0                                 fn_2b70db0
02d17e28: mov     w8, #1                                     
02d17e2c: strb    w8, [x24, #0xbdf]                          
02d17e30: adrp    x8, #0x6266000                             
02d17e34: ldr     x8, [x8, #0xd30]                           T:UnityEngine.Quaternion
02d17e38: ldr     x0, [x23]                                  &2c5bbd4(=a9bd7bfdd503233f)
02d17e3c: ldr     x8, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d17e40: ldr     w9, [x0, #0xe4]                            [62660e4]=0 f=0,0
02d17e44: ldr     x8, [x8, #0xb8]                            S:'banner_native_refresh_time'
02d17e48: ldp     s8, s9, [x8]                               
02d17e4c: ldp     s10, s11, [x8, #8]                         
02d17e50: cbnz    w9, #0x2d17e58                             
02d17e54: bl      #0x2b70f30                                 fn_2b70f30
02d17e58: adrp    x8, #0x6268000                             
02d17e5c: movi    d0, #0000000000000000                      
02d17e60: movi    d2, #0000000000000000                      
02d17e64: ldr     x8, [x8, #0x730]                           MS:UnityEngine.Object::Instantiate
02d17e68: fmov    s3, s8                                     
02d17e6c: fmov    s4, s9                                     
02d17e70: fmov    s5, s10                                    
02d17e74: fmov    s6, s11                                    
02d17e78: mov     x0, x21                                    
02d17e7c: fmov    s1, #1.00000000                            
02d17e80: ldr     x1, [x8]                                   S:'{0}/2'
02d17e84: bl      #0x3276100                                 fn_3276100
02d17e88: cbz     x0, #0x2d17f68                             
02d17e8c: adrp    x8, #0x6269000                             
02d17e90: ldr     x8, [x8, #0xa18]                           MS:UnityEngine.GameObject::GetComponent
02d17e94: ldr     x1, [x8]                                   T:Trading.TradingSession/<>c__DisplayClass56_0
02d17e98: bl      #0x31d11a4                                 fn_31d11a4
02d17e9c: mov     x1, x0                                     
02d17ea0: str     x0, [x19, #0x40]                           .<CurrentRoom>k__BackingField
02d17ea4: mov     x0, x20                                    
02d17ea8: bl      #0x2b70d54                                 fn_2b70d54
02d17eac: ldr     x8, [x19, #0x28]                           ._dreamHouseAsset
02d17eb0: cbz     x8, #0x2d17f68                             
02d17eb4: ldr     x0, [x8, #0x18]                            M:Trading.TradingSession::<ValidateTrade>b__57_0
02d17eb8: cbz     x0, #0x2d17f68                             
02d17ebc: ldr     w1, [x19, #0x38]                           ._currentRoomIndex
02d17ec0: ldr     x2, [x22]                                  T:Trading.TradingSession/<>c__DisplayClass56_0
02d17ec4: ldr     x20, [x19, #0x40]                          .<CurrentRoom>k__BackingField
02d17ec8: bl      #0x35a8f3c                                 fn_35a8f3c
02d17ecc: cbz     x20, #0x2d17f68                            
02d17ed0: mov     x1, x0                                     
02d17ed4: mov     x0, x20                                    
02d17ed8: mov     x2, x19                                    
02d17edc: ldp     x20, x19, [sp, #0x50]                      
02d17ee0: ldr     x30, [sp, #0x20]                           
02d17ee4: ldp     x22, x21, [sp, #0x40]                      
02d17ee8: ldp     x24, x23, [sp, #0x30]                      
02d17eec: ldp     d9, d8, [sp, #0x10]                        
02d17ef0: ldp     d11, d10, [sp], #0x60                      
02d17ef4: b       #0x2d17f6c                                 DreamHouse.RoomController::Initialize
02d17ef8: adrp    x19, #0x6269000                            
02d17efc: adrp    x20, #0x6263000                            
02d17f00: add     x0, sp, #0x2c                              
02d17f04: ldr     x19, [x19, #0xa20]                         S:'Invalid room index: '
02d17f08: ldr     x20, [x20, #0x928]                         T:UnityEngine.Debug
02d17f0c: mov     x1, xzr                                    
02d17f10: bl      #0x4e0ea3c                                 System.Int32::ToString
02d17f14: ldr     x8, [x19]                                  T:Trading.TradingSession/<>c__DisplayClass56_0
02d17f18: mov     x1, x0                                     
02d17f1c: mov     x2, xzr                                    
02d17f20: mov     x0, x8                                     
02d17f24: bl      #0x4c9c514                                 System.String::Concat
02d17f28: ldr     x8, [x20]                                  &2c5bbd4(=a9bd7bfdd503233f)
02d17f2c: mov     x19, x0                                    
02d17f30: ldr     w9, [x8, #0xe4]                            [62690e4]=0 f=0,0
02d17f34: cbnz    w9, #0x2d17f40                             
02d17f38: mov     x0, x8                                     
02d17f3c: bl      #0x2b70f30                                 fn_2b70f30
02d17f40: mov     x0, x19                                    
02d17f44: mov     x1, xzr                                    
02d17f48: bl      #0x5af2840                                 UnityEngine.Debug::LogError
02d17f4c: ldp     x20, x19, [sp, #0x50]                      
02d17f50: ldr     x30, [sp, #0x20]                           
02d17f54: ldp     x22, x21, [sp, #0x40]                      
02d17f58: ldp     x24, x23, [sp, #0x30]                      
02d17f5c: ldp     d9, d8, [sp, #0x10]                        
02d17f60: ldp     d11, d10, [sp], #0x60                      
02d17f64: ret                                                
02d17f68: bl      #0x2b7105c                                 fn_2b7105c
## CompletedRoom() -> void
---- DreamHouse.DreamHouseController::CompletedRoom 0x2d18298
02d18298: stp     x30, x21, [sp, #-0x20]!                    
02d1829c: stp     x20, x19, [sp, #0x10]                      
02d182a0: adrp    x20, #0x662f000                            
02d182a4: mov     x19, x0                                    
02d182a8: ldrb    w8, [x20, #0xfe7]                          
02d182ac: tbnz    w8, #0, #0x2d182c4                         
02d182b0: adrp    x0, #0x6263000                             
02d182b4: ldr     x0, [x0, #0x918]                           T:UnityEngine.Object
02d182b8: bl      #0x2b70db0                                 fn_2b70db0
02d182bc: mov     w8, #1                                     
02d182c0: strb    w8, [x20, #0xfe7]                          
02d182c4: mov     x20, x19                                   
02d182c8: ldr     x0, [x20, #0x40]!                          &2b70700(=14cc750491004000) .<CurrentRoom>k__BackingField
02d182cc: cbz     x0, #0x2d18328                             
02d182d0: adrp    x21, #0x6263000                            
02d182d4: mov     x1, xzr                                    
02d182d8: ldr     x21, [x21, #0x918]                         T:UnityEngine.Object
02d182dc: bl      #0x5b339ec                                 UnityEngine.Component::get_gameObject
02d182e0: ldr     x8, [x21]                                  &2c5bbd4(=a9bd7bfdd503233f)
02d182e4: mov     x21, x0                                    
02d182e8: ldr     w9, [x8, #0xe4]                            
02d182ec: cbnz    w9, #0x2d182f8                             
02d182f0: mov     x0, x8                                     
02d182f4: bl      #0x2b70f30                                 fn_2b70f30
02d182f8: mov     x0, x21                                    
02d182fc: mov     x1, xzr                                    
02d18300: bl      #0x5b3ca38                                 UnityEngine.Object::Destroy
02d18304: mov     x0, x20                                    
02d18308: mov     x1, xzr                                    
02d1830c: str     xzr, [x19, #0x40]                          .<CurrentRoom>k__BackingField
02d18310: bl      #0x2b70d54                                 fn_2b70d54
02d18314: ldr     w1, [x19, #0x38]                           ._currentRoomIndex
02d18318: mov     x0, x19                                    
02d1831c: ldp     x20, x19, [sp, #0x10]                      
02d18320: ldp     x30, x21, [sp], #0x20                      
02d18324: b       #0x2d17cbc                                 DreamHouse.DreamHouseController::StartRoom
02d18328: bl      #0x2b7105c                                 fn_2b7105c
## UnlockNextRoom() -> void
---- DreamHouse.DreamHouseController::UnlockNextRoom 0x2d1832c
02d1832c: str     x30, [sp, #-0x20]!                         
02d18330: stp     x20, x19, [sp, #0x10]                      
02d18334: adrp    x20, #0x662f000                            
02d18338: mov     x19, x0                                    
02d1833c: ldrb    w8, [x20, #0xfe8]                          
02d18340: tbnz    w8, #0, #0x2d18370                         
02d18344: adrp    x0, #0x6263000                             
02d18348: ldr     x0, [x0, #0x928]                           T:UnityEngine.Debug
02d1834c: bl      #0x2b70db0                                 fn_2b70db0
02d18350: adrp    x0, #0x6269000                             
02d18354: ldr     x0, [x0, #0x888]                           MS:System.Collections.Generic.List`1::get_Count
02d18358: bl      #0x2b70db0                                 fn_2b70db0
02d1835c: adrp    x0, #0x6269000                             
02d18360: ldr     x0, [x0, #0xa50]                           S:'No more rooms to unlock.'
02d18364: bl      #0x2b70db0                                 fn_2b70db0
02d18368: mov     w8, #1                                     
02d1836c: strb    w8, [x20, #0xfe8]                          
02d18370: ldr     w9, [x19, #0x38]                           ._currentRoomIndex
02d18374: ldr     x8, [x19, #0x28]                           ._dreamHouseAsset
02d18378: add     w1, w9, #1                                 
02d1837c: str     w1, [x19, #0x38]                           ._currentRoomIndex
02d18380: cbz     x8, #0x2d18404                             
02d18384: ldr     x8, [x8, #0x18]                            
02d18388: cbz     x8, #0x2d18404                             
02d1838c: ldr     w8, [x8, #0x18]                            
02d18390: cmp     w1, w8                                     
02d18394: b.ge    #0x2d183a8                                 
02d18398: ldr     x0, [x19, #0x30]                           ._dataDreamHouse
02d1839c: cbz     x0, #0x2d18404                             
02d183a0: bl      #0x2d16978                                 DreamHouse.DataDreamHouse::UnlockRoom
02d183a4: b       #0x2d183e0                                 
02d183a8: adrp    x8, #0x6263000                             
02d183ac: ldr     x8, [x8, #0x928]                           T:UnityEngine.Debug
02d183b0: ldr     x0, [x8]                                   &2c5bbd4(=a9bd7bfdd503233f)
02d183b4: ldr     w8, [x0, #0xe4]                            [62690e4]=0 f=0,0
02d183b8: cbnz    w8, #0x2d183c0                             
02d183bc: bl      #0x2b70f30                                 fn_2b70f30
02d183c0: adrp    x8, #0x6269000                             
02d183c4: mov     x1, xzr                                    
02d183c8: ldr     x8, [x8, #0xa50]                           S:'No more rooms to unlock.'
02d183cc: ldr     x0, [x8]                                   T:Trading.TradingSession/<>c__DisplayClass56_0
02d183d0: bl      #0x5af21f4                                 UnityEngine.Debug::Log
02d183d4: mov     w8, #1                                     
02d183d8: str     wzr, [x19, #0x38]                          ._currentRoomIndex
02d183dc: strb    w8, [x19, #0x50]                           .<IsCompletedAllRoom>k__BackingField
02d183e0: ldr     x0, [x19, #0x30]                           ._dataDreamHouse
02d183e4: cbz     x0, #0x2d18404                             
02d183e8: ldr     w1, [x19, #0x38]                           ._currentRoomIndex
02d183ec: bl      #0x2d166d0                                 DreamHouse.DataDreamHouse::SetCurrentRoomIndex
02d183f0: ldr     x0, [x19, #0x30]                           ._dataDreamHouse
02d183f4: cbz     x0, #0x2d18404                             
02d183f8: ldp     x20, x19, [sp, #0x10]                      
02d183fc: ldr     x30, [sp], #0x20                           
02d18400: b       #0x2d170d8                                 DreamHouse.DataDreamHouse::LoadCurrentRoomSteps
02d18404: bl      #0x2b7105c                                 fn_2b7105c
## SaveCurrentRoomStep(int optionIndex) -> void
---- DreamHouse.DreamHouseController::SaveCurrentRoomStep 0x2d18408
02d18408: str     x30, [sp, #-0x10]!                         
02d1840c: ldr     x8, [x0, #0x40]                            .<CurrentRoom>k__BackingField
02d18410: cbz     x8, #0x2d1842c                             
02d18414: ldr     x0, [x0, #0x30]                            ._dataDreamHouse
02d18418: cbz     x0, #0x2d1842c                             
02d1841c: mov     w2, w1                                     
02d18420: ldr     w1, [x8, #0x48]                            
02d18424: ldr     x30, [sp], #0x10                           
02d18428: b       #0x2d16c8c                                 DreamHouse.DataDreamHouse::AddCurrentRoomStep
02d1842c: bl      #0x2b7105c                                 fn_2b7105c
## .ctor() -> void
---- DreamHouse.DreamHouseController::.ctor 0x2d18430
02d18430: stp     x30, x21, [sp, #-0x20]!                    
02d18434: stp     x20, x19, [sp, #0x10]                      
02d18438: adrp    x20, #0x662f000                            
02d1843c: adrp    x21, #0x6269000                            
02d18440: mov     x19, x0                                    
02d18444: ldrb    w8, [x20, #0xfe9]                          
02d18448: ldr     x21, [x21, #0xa58]                         MS:MonoSingleton`1::.ctor
02d1844c: tbnz    w8, #0, #0x2d18464                         
02d18450: adrp    x0, #0x6269000                             
02d18454: ldr     x0, [x0, #0xa58]                           MS:MonoSingleton`1::.ctor
02d18458: bl      #0x2b70db0                                 fn_2b70db0
02d1845c: mov     w8, #1                                     
02d18460: strb    w8, [x20, #0xfe9]                          
02d18464: mov     x0, x19                                    
02d18468: ldp     x20, x19, [sp, #0x10]                      
02d1846c: ldr     x1, [x21]                                  T:Trading.TradingSession/<>c__DisplayClass56_0
02d18470: ldp     x30, x21, [sp], #0x20                      
02d18474: b       #0x3769e18                                 
## <Start>b__20_0() -> void
---- DreamHouse.DreamHouseController::<Start>b__20_0 0x2d18478
02d18478: stp     x30, x21, [sp, #-0x20]!                    
02d1847c: stp     x20, x19, [sp, #0x10]                      
02d18480: adrp    x21, #0x662f000                            
02d18484: adrp    x20, #0x6263000                            
02d18488: mov     x19, x0                                    
02d1848c: ldrb    w8, [x21, #0xfea]                          
02d18490: ldr     x20, [x20, #0x918]                         T:UnityEngine.Object
02d18494: tbnz    w8, #0, #0x2d184b8                         
02d18498: adrp    x0, #0x6269000                             
02d1849c: ldr     x0, [x0, #0xa08]                           MS:MonoSingleton`1::get_Instance
02d184a0: bl      #0x2b70db0                                 fn_2b70db0
02d184a4: adrp    x0, #0x6263000                             
02d184a8: ldr     x0, [x0, #0x918]                           T:UnityEngine.Object
02d184ac: bl      #0x2b70db0                                 fn_2b70db0
02d184b0: mov     w8, #1                                     
02d184b4: strb    w8, [x21, #0xfea]                          
02d184b8: ldr     x0, [x20]                                  &2c5bbd4(=a9bd7bfdd503233f)
02d184bc: ldr     x20, [x19, #0x40]                          .<CurrentRoom>k__BackingField
02d184c0: ldr     w8, [x0, #0xe4]                            [62630e4]=0 f=0,0
02d184c4: cbnz    w8, #0x2d184cc                             
02d184c8: bl      #0x2b70f30                                 fn_2b70f30
02d184cc: mov     x0, x20                                    
02d184d0: mov     x1, xzr                                    
02d184d4: mov     x2, xzr                                    
02d184d8: bl      #0x5b3666c                                 UnityEngine.Object::op_Inequality
02d184dc: tbz     w0, #0, #0x2d18530                         
02d184e0: adrp    x8, #0x6269000                             
02d184e4: ldr     x8, [x8, #0xa08]                           MS:MonoSingleton`1::get_Instance
02d184e8: ldr     x0, [x8]                                   T:Trading.TradingSession/<>c__DisplayClass56_0
02d184ec: bl      #0x3769600                                 fn_3769600
02d184f0: ldr     x8, [x19, #0x40]                           .<CurrentRoom>k__BackingField
02d184f4: cbz     x8, #0x2d1853c                             
02d184f8: ldr     x8, [x8, #0x50]                            T:type10817(k15)
02d184fc: cbz     x8, #0x2d1853c                             
02d18500: mov     x19, x0                                    
02d18504: ldr     x0, [x8, #0x20]                            M:Trading.TradingSession::<ValidateTrade>b__57_1
02d18508: cbz     x0, #0x2d1853c                             
02d1850c: mov     x1, xzr                                    
02d18510: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02d18514: cbz     x19, #0x2d1853c                            
02d18518: mov     x1, x0                                     
02d1851c: mov     x0, x19                                    
02d18520: mov     x2, xzr                                    
02d18524: ldp     x20, x19, [sp, #0x10]                      
02d18528: ldp     x30, x21, [sp], #0x20                      
02d1852c: b       #0x2cae7e8                                 DreamHouseFirstGameTutorial::ShowHighlightAt
02d18530: ldp     x20, x19, [sp, #0x10]                      
02d18534: ldp     x30, x21, [sp], #0x20                      
02d18538: ret                                                
02d1853c: bl      #0x2b7105c                                 fn_2b7105c
