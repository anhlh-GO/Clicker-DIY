#### CLASS Clicker.GameConfig parent= UnityEngine.ScriptableObject
## .ctor() -> void
---- Clicker.GameConfig::.ctor 0x2d5b470
02d5b470: mov     x1, xzr                                    
02d5b474: b       #0x5b398f0                                 UnityEngine.ScriptableObject::.ctor
