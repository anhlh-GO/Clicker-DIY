#### CLASS DDOL parent= UnityEngine.MonoBehaviour
## Awake() -> void
---- DDOL::Awake 0x2cda7ec
02cda7ec: stp     x30, x21, [sp, #-0x20]!                    
02cda7f0: stp     x20, x19, [sp, #0x10]                      
02cda7f4: adrp    x21, #0x662f000                            
02cda7f8: adrp    x20, #0x6263000                            
02cda7fc: mov     x19, x0                                    
02cda800: ldrb    w8, [x21, #0xd52]                          
02cda804: ldr     x20, [x20, #0x918]                         T:UnityEngine.Object
02cda808: tbnz    w8, #0, #0x2cda820                         
02cda80c: adrp    x0, #0x6263000                             
02cda810: ldr     x0, [x0, #0x918]                           T:UnityEngine.Object
02cda814: bl      #0x2b70db0                                 fn_2b70db0
02cda818: mov     w8, #1                                     
02cda81c: strb    w8, [x21, #0xd52]                          
02cda820: mov     x0, x19                                    
02cda824: mov     x1, xzr                                    
02cda828: bl      #0x5b339ec                                 UnityEngine.Component::get_gameObject
02cda82c: ldr     x8, [x20]                                  &2c5bbd4(=a9bd7bfdd503233f)
02cda830: mov     x19, x0                                    
02cda834: ldr     w9, [x8, #0xe4]                            
02cda838: cbnz    w9, #0x2cda844                             
02cda83c: mov     x0, x8                                     
02cda840: bl      #0x2b70f30                                 fn_2b70f30
02cda844: mov     x0, x19                                    
02cda848: ldp     x20, x19, [sp, #0x10]                      
02cda84c: mov     x1, xzr                                    
02cda850: ldp     x30, x21, [sp], #0x20                      
02cda854: b       #0x5b3ccec                                 UnityEngine.Object::DontDestroyOnLoad
## .ctor() -> void
---- DDOL::.ctor 0x2cda858
02cda858: mov     x1, xzr                                    
02cda85c: b       #0x5b397b0                                 UnityEngine.MonoBehaviour::.ctor
