#### CLASS Decor.BackgroundChanger parent= UnityEngine.MonoBehaviour
#   field _spriteRenderer                UnityEngine.SpriteRenderer                         off=0x20 attr=1 SerializeField
## ChangeItem(int categoryIndex, int optionID) -> void
---- Decor.BackgroundChanger::ChangeItem 0x2d24b2c
02d24b2c: stp     x30, x23, [sp, #-0x30]!                    
02d24b30: stp     x22, x21, [sp, #0x10]                      
02d24b34: stp     x20, x19, [sp, #0x20]                      
02d24b38: adrp    x22, #0x6630000                            
02d24b3c: adrp    x23, #0x6266000                            
02d24b40: mov     w20, w2                                    
02d24b44: ldrb    w8, [x22, #0x65]                           
02d24b48: ldr     x23, [x23, #0x658]                         MS:MonoSingleton`1::get_Instance
02d24b4c: mov     w21, w1                                    
02d24b50: mov     x19, x0                                    
02d24b54: tbnz    w8, #0, #0x2d24b78                         
02d24b58: adrp    x0, #0x6266000                             
02d24b5c: ldr     x0, [x0, #0x870]                           MS:DataManager::GetAsset
02d24b60: bl      #0x2b70db0                                 fn_2b70db0
02d24b64: adrp    x0, #0x6266000                             
02d24b68: ldr     x0, [x0, #0x658]                           MS:MonoSingleton`1::get_Instance
02d24b6c: bl      #0x2b70db0                                 fn_2b70db0
02d24b70: mov     w8, #1                                     
02d24b74: strb    w8, [x22, #0x65]                           
02d24b78: ldr     x0, [x23]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d24b7c: bl      #0x3769600                                 fn_3769600
02d24b80: cbz     x0, #0x2d24bd4                             
02d24b84: adrp    x8, #0x6266000                             
02d24b88: ldr     x8, [x8, #0x870]                           MS:DataManager::GetAsset
02d24b8c: ldr     x1, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d24b90: bl      #0x3168af0                                 fn_3168af0
02d24b94: cbz     x0, #0x2d24bd4                             
02d24b98: mov     w1, w21                                    
02d24b9c: bl      #0x2d249f4                                 Decor.DecorAsset::GetCategoryAssetByIndex
02d24ba0: cbz     x0, #0x2d24bd4                             
02d24ba4: mov     w1, w20                                    
02d24ba8: bl      #0x2d24a4c                                 Decor.CategoryAsset::GetOptionDataByID
02d24bac: cbz     x0, #0x2d24bd4                             
02d24bb0: ldr     x8, [x19, #0x20]                           ._spriteRenderer
02d24bb4: cbz     x8, #0x2d24bd4                             
02d24bb8: ldp     x20, x19, [sp, #0x20]                      
02d24bbc: mov     x2, xzr                                    
02d24bc0: ldp     x22, x21, [sp, #0x10]                      
02d24bc4: ldr     x1, [x0, #0x40]                            S:'native_collap_ad_on_off'
02d24bc8: mov     x0, x8                                     
02d24bcc: ldp     x30, x23, [sp], #0x30                      
02d24bd0: b       #0x5ae6dcc                                 UnityEngine.SpriteRenderer::set_sprite
02d24bd4: bl      #0x2b7105c                                 fn_2b7105c
## .ctor() -> void
---- Decor.BackgroundChanger::.ctor 0x2d24bd8
02d24bd8: mov     x1, xzr                                    
02d24bdc: b       #0x5b397b0                                 UnityEngine.MonoBehaviour::.ctor
