#### CLASS Framework.SwipeZone/ESwipeDirection parent= int
#   field value__                        int                                                off=0x10 attr=606 
#   field None                           Framework.SwipeZone/ESwipeDirection                off=0x0 attr=8056 
#   field Up                             Framework.SwipeZone/ESwipeDirection                off=0x0 attr=8056 
#   field Down                           Framework.SwipeZone/ESwipeDirection                off=0x0 attr=8056 
#   field Left                           Framework.SwipeZone/ESwipeDirection                off=0x0 attr=8056 
#   field Right                          Framework.SwipeZone/ESwipeDirection                off=0x0 attr=8056 
#### CLASS Framework.SwipeZone parent= UnityEngine.MonoBehaviour
#   field _minimalSwipeLength            float                                              off=0x20 attr=1 HeaderAttribute,SerializeField
#   field _maximumPressLength            float                                              off=0x24 attr=1 SerializeField
#   field OnZonePressed                  UnityEngine.Events.UnityEvent                      off=0x28 attr=1 HeaderAttribute,SerializeField
#   field OnZoneSwiped                   UnityEngine.Events.UnityEvent`1<Framework.SwipeZone/ESwipeDirection> off=0x30 attr=1 SerializeField
#   field _firstTouchPosition            UnityEngine.Vector2                                off=0x38 attr=1 
#   field _length                        float                                              off=0x40 attr=1 
#   field _destination                   UnityEngine.Vector2                                off=0x44 attr=1 
#   field _swipeDirection                Framework.SwipeZone/ESwipeDirection                off=0x4c attr=1 
#   field _angle                         float                                              off=0x50 attr=1 
#   field _deltaSwipe                    UnityEngine.Vector2                                off=0x54 attr=1 
#   field _lastPointerUpAt               float                                              off=0x5c attr=1 
## OnPointerDown(UnityEngine.EventSystems.PointerEventData data) -> void
---- Framework.SwipeZone::OnPointerDown 0x2cc543c
02cc543c: stp     x30, x19, [sp, #-0x10]!                    
02cc5440: mov     x19, x0                                    
02cc5444: mov     x0, xzr                                    
02cc5448: bl      #0x5bb7d60                                 UnityEngine.Input::get_mousePosition
02cc544c: stp     s0, s1, [x19, #0x38]                       ._firstTouchPosition
02cc5450: ldp     x30, x19, [sp], #0x10                      
02cc5454: ret                                                
## OnPointerUp(UnityEngine.EventSystems.PointerEventData data) -> void
---- Framework.SwipeZone::OnPointerUp 0x2cc5458
02cc5458: stp     d9, d8, [sp, #-0x30]!                      
02cc545c: str     x30, [sp, #0x10]                           
02cc5460: stp     x20, x19, [sp, #0x20]                      
02cc5464: mov     x19, x0                                    
02cc5468: mov     x0, xzr                                    
02cc546c: bl      #0x5b32d2c                                 UnityEngine.Time::get_frameCount
02cc5470: scvtf   s0, w0                                     
02cc5474: ldr     s1, [x19, #0x5c]                           ._lastPointerUpAt
02cc5478: fcmp    s1, s0                                     
02cc547c: b.eq    #0x2cc5608                                 
02cc5480: mov     x0, xzr                                    
02cc5484: bl      #0x5bb7d60                                 UnityEngine.Input::get_mousePosition
02cc5488: ldp     s2, s3, [x19, #0x38]                       ._firstTouchPosition
02cc548c: adrp    x20, #0x662f000                            
02cc5490: ldrb    w8, [x20, #0xca9]                          
02cc5494: stp     s0, s1, [x19, #0x44]                       ._destination
02cc5498: fsub    s8, s0, s2                                 
02cc549c: fsub    s9, s1, s3                                 
02cc54a0: stp     s8, s9, [x19, #0x54]                       ._deltaSwipe
02cc54a4: cbnz    w8, #0x2cc54c0                             
02cc54a8: adrp    x0, #0x6265000                             
02cc54ac: ldr     x0, [x0, #0xb48]                           T:System.Math
02cc54b0: bl      #0x2b70db0                                 fn_2b70db0
02cc54b4: ldp     s8, s9, [x19, #0x54]                       ._deltaSwipe
02cc54b8: mov     w8, #1                                     
02cc54bc: strb    w8, [x20, #0xca9]                          
02cc54c0: adrp    x8, #0x6265000                             
02cc54c4: ldr     x8, [x8, #0xb48]                           T:System.Math
02cc54c8: ldr     x0, [x8]                                   M:AdsManager::<OnApplicationPause>b__26_0
02cc54cc: ldr     w8, [x0, #0xe4]                            [62650e4]=0 f=0,0
02cc54d0: cbnz    w8, #0x2cc54d8                             
02cc54d4: bl      #0x2b70f30                                 fn_2b70f30
02cc54d8: fmul    s0, s8, s8                                 
02cc54dc: fmul    s1, s9, s9                                 
02cc54e0: fadd    s0, s0, s1                                 
02cc54e4: ldr     s1, [x19, #0x20]                           ._minimalSwipeLength
02cc54e8: fsqrt   s0, s0                                     
02cc54ec: fcmp    s0, s1                                     
02cc54f0: str     s0, [x19, #0x40]                           ._length
02cc54f4: b.le    #0x2cc55dc                                 
02cc54f8: adrp    x20, #0x662f000                            
02cc54fc: ldp     s8, s9, [x19, #0x54]                       ._deltaSwipe
02cc5500: ldrb    w8, [x20, #0xcac]                          
02cc5504: cbnz    w8, #0x2cc551c                             
02cc5508: adrp    x0, #0x6266000                             
02cc550c: ldr     x0, [x0, #0x970]                           T:UnityEngine.Vector2
02cc5510: bl      #0x2b70db0                                 fn_2b70db0
02cc5514: mov     w8, #1                                     
02cc5518: strb    w8, [x20, #0xcac]                          
02cc551c: adrp    x8, #0x6266000                             
02cc5520: fmov    s0, s8                                     
02cc5524: fmov    s1, s9                                     
02cc5528: ldr     x8, [x8, #0x970]                           T:UnityEngine.Vector2
02cc552c: ldr     x8, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cc5530: ldr     x8, [x8, #0xb8]                            S:'banner_native_refresh_time'
02cc5534: ldp     s2, s3, [x8, #0x28]                        
02cc5538: bl      #0x2cc1158                                 Framework.MathUtils::AngleBetween2D
02cc553c: mov     w8, #0x42340000                            
02cc5540: str     s0, [x19, #0x50]                           ._angle
02cc5544: fmov    s1, w8                                     
02cc5548: mov     w8, #4                                     
02cc554c: fcmp    s0, s1                                     
02cc5550: b.mi    #0x2cc55cc                                 
02cc5554: adrp    x9, #0x1084000                             
02cc5558: ldr     s1, [x9, #0xd78]                           [1084d78]=c51c4000439d8000 f=315,-2500
02cc555c: fcmp    s0, s1                                     
02cc5560: b.ge    #0x2cc55cc                                 
02cc5564: mov     w8, #0x42340000                            
02cc5568: fmov    s2, w8                                     
02cc556c: fcmp    s0, s2                                     
02cc5570: b.lt    #0x2cc558c                                 
02cc5574: mov     w8, #0x43070000                            
02cc5578: fmov    s2, w8                                     
02cc557c: fcmp    s0, s2                                     
02cc5580: b.pl    #0x2cc558c                                 
02cc5584: mov     w8, #1                                     
02cc5588: b       #0x2cc55cc                                 
02cc558c: mov     w8, #0x43070000                            
02cc5590: fmov    s2, w8                                     
02cc5594: fcmp    s0, s2                                     
02cc5598: b.lt    #0x2cc55b4                                 
02cc559c: mov     w8, #0x43610000                            
02cc55a0: fmov    s2, w8                                     
02cc55a4: fcmp    s0, s2                                     
02cc55a8: b.pl    #0x2cc55b4                                 
02cc55ac: mov     w8, #3                                     
02cc55b0: b       #0x2cc55cc                                 
02cc55b4: mov     w8, #0x43610000                            
02cc55b8: fcmp    s0, s1                                     
02cc55bc: fmov    s1, w8                                     
02cc55c0: mov     w8, #2                                     
02cc55c4: fccmp   s0, s1, #8, mi                             
02cc55c8: csel    w8, w8, wzr, ge                            
02cc55cc: mov     x0, x19                                    
02cc55d0: str     w8, [x19, #0x4c]                           ._swipeDirection
02cc55d4: bl      #0x2cc56a8                                 Framework.SwipeZone::Swipe
02cc55d8: ldr     s0, [x19, #0x40]                           ._length
02cc55dc: ldr     s1, [x19, #0x24]                           ._maximumPressLength
02cc55e0: fcmp    s0, s1                                     
02cc55e4: b.pl    #0x2cc55f8                                 
02cc55e8: ldr     x0, [x19, #0x28]                           .OnZonePressed
02cc55ec: cbz     x0, #0x2cc55f8                             
02cc55f0: mov     x1, xzr                                    
02cc55f4: bl      #0x5b4d278                                 UnityEngine.Events.UnityEvent::Invoke
02cc55f8: mov     x0, xzr                                    
02cc55fc: bl      #0x5b32d2c                                 UnityEngine.Time::get_frameCount
02cc5600: scvtf   s0, w0                                     
02cc5604: str     s0, [x19, #0x5c]                           ._lastPointerUpAt
02cc5608: ldp     x20, x19, [sp, #0x20]                      
02cc560c: ldr     x30, [sp, #0x10]                           
02cc5610: ldp     d9, d8, [sp], #0x30                        
02cc5614: ret                                                
## AngleToSwipeDirection(float angle) -> Framework.SwipeZone/ESwipeDirection
---- Framework.SwipeZone::AngleToSwipeDirection 0x2cc5618
02cc5618: mov     w8, #0x42340000                            
02cc561c: mov     w0, #4                                     
02cc5620: fmov    s1, w8                                     
02cc5624: fcmp    s0, s1                                     
02cc5628: b.mi    #0x2cc56a4                                 
02cc562c: adrp    x8, #0x1084000                             
02cc5630: ldr     s1, [x8, #0xd78]                           [1084d78]=c51c4000439d8000 f=315,-2500
02cc5634: fcmp    s0, s1                                     
02cc5638: b.ge    #0x2cc56a4                                 
02cc563c: mov     w8, #0x42340000                            
02cc5640: fmov    s2, w8                                     
02cc5644: fcmp    s0, s2                                     
02cc5648: b.lt    #0x2cc5664                                 
02cc564c: mov     w8, #0x43070000                            
02cc5650: fmov    s2, w8                                     
02cc5654: fcmp    s0, s2                                     
02cc5658: b.pl    #0x2cc5664                                 
02cc565c: mov     w0, #1                                     
02cc5660: ret                                                
02cc5664: mov     w8, #0x43070000                            
02cc5668: fmov    s2, w8                                     
02cc566c: fcmp    s0, s2                                     
02cc5670: b.lt    #0x2cc568c                                 
02cc5674: mov     w8, #0x43610000                            
02cc5678: fmov    s2, w8                                     
02cc567c: fcmp    s0, s2                                     
02cc5680: b.pl    #0x2cc568c                                 
02cc5684: mov     w0, #3                                     
02cc5688: ret                                                
02cc568c: mov     w8, #0x43610000                            
02cc5690: fcmp    s0, s1                                     
02cc5694: fmov    s1, w8                                     
02cc5698: mov     w8, #2                                     
02cc569c: fccmp   s0, s1, #8, mi                             
02cc56a0: csel    w0, w8, wzr, ge                            
02cc56a4: ret                                                
## Swipe() -> void
---- Framework.SwipeZone::Swipe 0x2cc56a8
02cc56a8: str     x30, [sp, #-0x20]!                         
02cc56ac: stp     x20, x19, [sp, #0x10]                      
02cc56b0: adrp    x20, #0x662f000                            
02cc56b4: mov     x19, x0                                    
02cc56b8: ldrb    w8, [x20, #0xc47]                          
02cc56bc: tbnz    w8, #0, #0x2cc56d4                         
02cc56c0: adrp    x0, #0x6267000                             
02cc56c4: ldr     x0, [x0, #0x208]                           MS:UnityEngine.Events.UnityEvent`1::Invoke
02cc56c8: bl      #0x2b70db0                                 fn_2b70db0
02cc56cc: mov     w8, #1                                     
02cc56d0: strb    w8, [x20, #0xc47]                          
02cc56d4: ldr     x0, [x19, #0x30]                           .OnZoneSwiped
02cc56d8: cbz     x0, #0x2cc56f8                             
02cc56dc: adrp    x8, #0x6267000                             
02cc56e0: ldr     x8, [x8, #0x208]                           MS:UnityEngine.Events.UnityEvent`1::Invoke
02cc56e4: ldr     w1, [x19, #0x4c]                           ._swipeDirection
02cc56e8: ldp     x20, x19, [sp, #0x10]                      
02cc56ec: ldr     x2, [x8]                                   S:'didu'
02cc56f0: ldr     x30, [sp], #0x20                           
02cc56f4: b       #0x3ee6208                                 
02cc56f8: ldp     x20, x19, [sp, #0x10]                      
02cc56fc: ldr     x30, [sp], #0x20                           
02cc5700: ret                                                
## Press() -> void
---- Framework.SwipeZone::Press 0x2cc5704
02cc5704: ldr     x0, [x0, #0x28]                            .OnZonePressed
02cc5708: cbz     x0, #0x2cc5714                             
02cc570c: mov     x1, xzr                                    
02cc5710: b       #0x5b4d278                                 UnityEngine.Events.UnityEvent::Invoke
02cc5714: ret                                                
## .ctor() -> void
---- Framework.SwipeZone::.ctor 0x2cc5718
02cc5718: adrp    x8, #0x1040000                             
02cc571c: mov     x1, xzr                                    
02cc5720: ldr     d0, [x8, #0xaf0]                           [1040af0]=4120000042480000 f=50,10
02cc5724: str     d0, [x0, #0x20]                            ._minimalSwipeLength
02cc5728: b       #0x5b397b0                                 UnityEngine.MonoBehaviour::.ctor
