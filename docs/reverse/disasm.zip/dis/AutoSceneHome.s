#### CLASS AutoSceneHome parent= UnityEngine.MonoBehaviour
## Start() -> void
---- AutoSceneHome::Start 0x2cde458
02cde458: ret                                                
## .ctor() -> void
---- AutoSceneHome::.ctor 0x2cde45c
02cde45c: mov     x1, xzr                                    
02cde460: b       #0x5b397b0                                 UnityEngine.MonoBehaviour::.ctor
