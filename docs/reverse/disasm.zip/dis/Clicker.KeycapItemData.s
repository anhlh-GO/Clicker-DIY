#### CLASS Clicker.KeycapItemData parent= object
#   field Id                             int                                                off=0x10 attr=6 
#   field Icon                           UnityEngine.Sprite                                 off=0x18 attr=6 
#   field KeycapColors                   System.Collections.Generic.List`1<UnityEngine.Sprite> off=0x20 attr=6 
#   field UnlockMethod                   Clicker.UnlockMethod                               off=0x28 attr=6 
## .ctor() -> void
---- Clicker.KeycapItemData::.ctor 0x2d5b928
02d5b928: mov     x1, xzr                                    
02d5b92c: b       #0x4e53e9c                                 System.Object::.ctor
