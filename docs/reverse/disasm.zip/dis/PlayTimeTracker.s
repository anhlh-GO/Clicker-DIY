#### CLASS PlayTimeTracker parent= MonoSingleton`1<PlayTimeTracker>
#   field SAVE_INTERVAL                  float                                              off=0x0 attr=8051 
#   field DATE_FORMAT                    string                                             off=0x0 attr=8051 
#   field _accumulatedSeconds            float                                              off=0x20 attr=1 SerializeField
#   field _saveTimer                     float                                              off=0x24 attr=1 SerializeField
#   field _loginTimeRewardConfig         LoginTimeReward.LoginTimeRewardConfig              off=0x28 attr=1 SerializeField
#   field _dataPlayTime                  LoginTimeReward.DataPlayTime                       off=0x30 attr=1 
#   field _isInitialized                 bool                                               off=0x38 attr=1 
## get_TodayMinutes() -> int
---- PlayTimeTracker::get_TodayMinutes 0x2cad290
02cad290: str     d8, [sp, #-0x20]!                          
02cad294: stp     x30, x19, [sp, #0x10]                      
02cad298: adrp    x19, #0x662f000                            
02cad29c: ldr     s8, [x0, #0x20]                            ._accumulatedSeconds
02cad2a0: ldrb    w8, [x19, #0xbd8]                          
02cad2a4: cbnz    w8, #0x2cad2bc                             
02cad2a8: adrp    x0, #0x6265000                             
02cad2ac: ldr     x0, [x0, #0xb48]                           T:System.Math
02cad2b0: bl      #0x2b70db0                                 fn_2b70db0
02cad2b4: mov     w8, #1                                     
02cad2b8: strb    w8, [x19, #0xbd8]                          
02cad2bc: adrp    x8, #0x6265000                             
02cad2c0: ldr     x8, [x8, #0xb48]                           T:System.Math
02cad2c4: ldr     x0, [x8]                                   M:AdsManager::<OnApplicationPause>b__26_0
02cad2c8: ldr     w8, [x0, #0xe4]                            [62650e4]=0 f=0,0
02cad2cc: cbnz    w8, #0x2cad2d4                             
02cad2d0: bl      #0x2b70f30                                 fn_2b70f30
02cad2d4: mov     w8, #0x42700000                            
02cad2d8: ldp     x30, x19, [sp, #0x10]                      
02cad2dc: fmov    s0, w8                                     
02cad2e0: mov     w8, #0x7f800000                            
02cad2e4: fdiv    s0, s8, s0                                 
02cad2e8: frintm  s1, s0                                     
02cad2ec: fcvtms  w9, s0                                     
02cad2f0: fmov    s0, w8                                     
02cad2f4: mov     w8, #-0xffffffff80000000                   
02cad2f8: fcmp    s1, s0                                     
02cad2fc: csel    w0, w8, w9, eq                             
02cad300: ldr     d8, [sp], #0x20                            
02cad304: ret                                                
## get_TodaySeconds() -> float
---- PlayTimeTracker::get_TodaySeconds 0x2cad308
02cad308: ldr     s0, [x0, #0x20]                            ._accumulatedSeconds
02cad30c: ret                                                
## Initiate() -> void
---- PlayTimeTracker::Initiate 0x2cad310
02cad310: stp     x30, x23, [sp, #-0x30]!                    
02cad314: stp     x22, x21, [sp, #0x10]                      
02cad318: stp     x20, x19, [sp, #0x20]                      
02cad31c: adrp    x22, #0x662f000                            
02cad320: adrp    x23, #0x6266000                            
02cad324: adrp    x21, #0x6264000                            
02cad328: adrp    x20, #0x6266000                            
02cad32c: ldr     x23, [x23, #0x8b0]                         MS:MonoSingleton`1::Initiate
02cad330: ldrb    w8, [x22, #0xb3c]                          
02cad334: ldr     x21, [x21, #0xe8]                          T:DG.Tweening.TweenCallback
02cad338: ldr     x20, [x20, #0x8b8]                         M:PlayTimeTracker::<Initiate>b__11_0
02cad33c: mov     x19, x0                                    
02cad340: tbnz    w8, #0, #0x2cad370                         
02cad344: adrp    x0, #0x6266000                             
02cad348: ldr     x0, [x0, #0x8b0]                           MS:MonoSingleton`1::Initiate
02cad34c: bl      #0x2b70db0                                 fn_2b70db0
02cad350: adrp    x0, #0x6266000                             
02cad354: ldr     x0, [x0, #0x8b8]                           M:PlayTimeTracker::<Initiate>b__11_0
02cad358: bl      #0x2b70db0                                 fn_2b70db0
02cad35c: adrp    x0, #0x6264000                             
02cad360: ldr     x0, [x0, #0xe8]                            T:DG.Tweening.TweenCallback
02cad364: bl      #0x2b70db0                                 fn_2b70db0
02cad368: mov     w8, #1                                     
02cad36c: strb    w8, [x22, #0xb3c]                          
02cad370: ldr     x1, [x23]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cad374: mov     x0, x19                                    
02cad378: bl      #0x3769de4                                 fn_3769de4
02cad37c: ldr     x0, [x21]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02cad380: bl      #0x2b7104c                                 fn_2b7104c
02cad384: ldr     x2, [x20]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cad388: mov     x1, x19                                    
02cad38c: mov     x3, xzr                                    
02cad390: mov     x20, x0                                    
02cad394: bl      #0x2d89dc4                                 DG.Tweening.TweenCallback::.ctor
02cad398: mov     x0, x20                                    
02cad39c: ldp     x20, x19, [sp, #0x20]                      
02cad3a0: ldp     x22, x21, [sp, #0x10]                      
02cad3a4: fmov    s0, #2.00000000                            
02cad3a8: mov     w1, #1                                     
02cad3ac: mov     x2, xzr                                    
02cad3b0: ldp     x30, x23, [sp], #0x30                      
02cad3b4: b       #0x2d8f37c                                 DG.Tweening.DOVirtual::DelayedCall
## Update() -> void
---- PlayTimeTracker::Update 0x2cad3b8
02cad3b8: str     d8, [sp, #-0x20]!                          
02cad3bc: stp     x30, x19, [sp, #0x10]                      
02cad3c0: ldrb    w8, [x0, #0x38]                            ._isInitialized
02cad3c4: cbz     w8, #0x2cad418                             
02cad3c8: mov     x19, x0                                    
02cad3cc: bl      #0x2cad438                                 PlayTimeTracker::HasDateChanged
02cad3d0: tbz     w0, #0, #0x2cad3e4                         
02cad3d4: mov     x0, x19                                    
02cad3d8: ldp     x30, x19, [sp, #0x10]                      
02cad3dc: ldr     d8, [sp], #0x20                            
02cad3e0: b       #0x2cad65c                                 PlayTimeTracker::ResetForNewDay
02cad3e4: ldr     s8, [x19, #0x20]                           ._accumulatedSeconds
02cad3e8: mov     x0, xzr                                    
02cad3ec: bl      #0x5b433a4                                 UnityEngine.Time::get_deltaTime
02cad3f0: fadd    s0, s8, s0                                 
02cad3f4: ldr     s8, [x19, #0x24]                           ._saveTimer
02cad3f8: mov     x0, xzr                                    
02cad3fc: str     s0, [x19, #0x20]                           ._accumulatedSeconds
02cad400: bl      #0x5b433a4                                 UnityEngine.Time::get_deltaTime
02cad404: fadd    s0, s8, s0                                 
02cad408: fmov    s1, #10.00000000                           
02cad40c: fcmp    s0, s1                                     
02cad410: str     s0, [x19, #0x24]                           ._saveTimer
02cad414: b.ge    #0x2cad424                                 
02cad418: ldp     x30, x19, [sp, #0x10]                      
02cad41c: ldr     d8, [sp], #0x20                            
02cad420: ret                                                
02cad424: mov     x0, x19                                    
02cad428: str     wzr, [x19, #0x24]                          ._saveTimer
02cad42c: ldp     x30, x19, [sp, #0x10]                      
02cad430: ldr     d8, [sp], #0x20                            
02cad434: b       #0x2cad718                                 PlayTimeTracker::Save
## OnApplicationPause(bool paused) -> void
---- PlayTimeTracker::OnApplicationPause 0x2cad750
02cad750: stp     x30, x19, [sp, #-0x10]!                    
02cad754: ldrb    w8, [x0, #0x38]                            ._isInitialized
02cad758: cbz     w8, #0x2cad778                             
02cad75c: tbnz    w1, #0, #0x2cad778                         
02cad760: mov     x19, x0                                    
02cad764: bl      #0x2cad438                                 PlayTimeTracker::HasDateChanged
02cad768: tbz     w0, #0, #0x2cad778                         
02cad76c: mov     x0, x19                                    
02cad770: ldp     x30, x19, [sp], #0x10                      
02cad774: b       #0x2cad65c                                 PlayTimeTracker::ResetForNewDay
02cad778: ldp     x30, x19, [sp], #0x10                      
02cad77c: ret                                                
## OnDestroy() -> void
---- PlayTimeTracker::OnDestroy 0x2cad780
02cad780: str     x30, [sp, #-0x30]!                         
02cad784: stp     x22, x21, [sp, #0x10]                      
02cad788: stp     x20, x19, [sp, #0x20]                      
02cad78c: adrp    x21, #0x662f000                            
02cad790: adrp    x22, #0x6264000                            
02cad794: adrp    x20, #0x6266000                            
02cad798: ldrb    w8, [x21, #0xb3d]                          
02cad79c: ldr     x22, [x22, #0xf90]                         T:System.Action
02cad7a0: ldr     x20, [x20, #0x8c0]                         M:PlayTimeTracker::SyncDataSave
02cad7a4: mov     x19, x0                                    
02cad7a8: tbnz    w8, #0, #0x2cad7cc                         
02cad7ac: adrp    x0, #0x6264000                             
02cad7b0: ldr     x0, [x0, #0xf90]                           T:System.Action
02cad7b4: bl      #0x2b70db0                                 fn_2b70db0
02cad7b8: adrp    x0, #0x6266000                             
02cad7bc: ldr     x0, [x0, #0x8c0]                           M:PlayTimeTracker::SyncDataSave
02cad7c0: bl      #0x2b70db0                                 fn_2b70db0
02cad7c4: mov     w8, #1                                     
02cad7c8: strb    w8, [x21, #0xb3d]                          
02cad7cc: ldr     x0, [x22]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02cad7d0: bl      #0x2b7104c                                 fn_2b7104c
02cad7d4: ldr     x2, [x20]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cad7d8: mov     x1, x19                                    
02cad7dc: mov     x3, xzr                                    
02cad7e0: mov     x20, x0                                    
02cad7e4: bl      #0x4d8ddbc                                 System.Action::.ctor
02cad7e8: mov     x0, x20                                    
02cad7ec: ldp     x20, x19, [sp, #0x20]                      
02cad7f0: ldp     x22, x21, [sp, #0x10]                      
02cad7f4: ldr     x30, [sp], #0x30                           
02cad7f8: b       #0x2caa3bc                                 DataManager::remove_OnBeforeSaveAll
## SyncDataSave() -> void
---- PlayTimeTracker::SyncDataSave 0x2cad7fc
02cad7fc: str     x30, [sp, #-0x20]!                         
02cad800: stp     x20, x19, [sp, #0x10]                      
02cad804: adrp    x20, #0x662f000                            
02cad808: mov     x19, x0                                    
02cad80c: ldrb    w8, [x20, #0xb3e]                          
02cad810: tbnz    w8, #0, #0x2cad828                         
02cad814: adrp    x0, #0x6263000                             
02cad818: ldr     x0, [x0, #0x918]                           T:UnityEngine.Object
02cad81c: bl      #0x2b70db0                                 fn_2b70db0
02cad820: mov     w8, #1                                     
02cad824: strb    w8, [x20, #0xb3e]                          
02cad828: ldrb    w8, [x19, #0x38]                           ._isInitialized
02cad82c: cbz     w8, #0x2cad878                             
02cad830: adrp    x8, #0x6263000                             
02cad834: ldr     x8, [x8, #0x918]                           T:UnityEngine.Object
02cad838: ldr     x20, [x19, #0x30]                          ._dataPlayTime
02cad83c: ldr     x0, [x8]                                   &2c5bbd4(=a9bd7bfdd503233f)
02cad840: ldr     w8, [x0, #0xe4]                            [62630e4]=0 f=0,0
02cad844: cbnz    w8, #0x2cad84c                             
02cad848: bl      #0x2b70f30                                 fn_2b70f30
02cad84c: mov     x0, x20                                    
02cad850: mov     x1, xzr                                    
02cad854: mov     x2, xzr                                    
02cad858: bl      #0x5b37d84                                 UnityEngine.Object::op_Equality
02cad85c: tbnz    w0, #0, #0x2cad878                         
02cad860: ldr     x8, [x19, #0x30]                           ._dataPlayTime
02cad864: cbz     x8, #0x2cad884                             
02cad868: ldr     x8, [x8, #0x20]                            &2c5bd40(=14c8d27fd503245f)
02cad86c: cbz     x8, #0x2cad884                             
02cad870: ldr     s0, [x19, #0x20]                           ._accumulatedSeconds
02cad874: str     s0, [x8, #0x18]                            
02cad878: ldp     x20, x19, [sp, #0x10]                      
02cad87c: ldr     x30, [sp], #0x20                           
02cad880: ret                                                
02cad884: bl      #0x2b7105c                                 fn_2b7105c
## TodayKey() -> string
---- PlayTimeTracker::TodayKey 0x2cad888
02cad888: str     x30, [sp, #-0x20]!                         
02cad88c: stp     x20, x19, [sp, #0x10]                      
02cad890: adrp    x20, #0x662f000                            
02cad894: adrp    x19, #0x6266000                            
02cad898: ldrb    w8, [x20, #0xb3f]                          
02cad89c: ldr     x19, [x19, #0x128]                         T:System.DateTime
02cad8a0: tbnz    w8, #0, #0x2cad8d0                         
02cad8a4: adrp    x0, #0x6264000                             
02cad8a8: ldr     x0, [x0, #0x6a8]                           T:System.Globalization.CultureInfo
02cad8ac: bl      #0x2b70db0                                 fn_2b70db0
02cad8b0: adrp    x0, #0x6266000                             
02cad8b4: ldr     x0, [x0, #0x128]                           T:System.DateTime
02cad8b8: bl      #0x2b70db0                                 fn_2b70db0
02cad8bc: adrp    x0, #0x6266000                             
02cad8c0: ldr     x0, [x0, #0x158]                           S:'yyyy-MM-dd'
02cad8c4: bl      #0x2b70db0                                 fn_2b70db0
02cad8c8: mov     w8, #1                                     
02cad8cc: strb    w8, [x20, #0xb3f]                          
02cad8d0: ldr     x0, [x19]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cad8d4: adrp    x20, #0x6264000                            
02cad8d8: ldr     w8, [x0, #0xe4]                            [62660e4]=0 f=0,0
02cad8dc: ldr     x20, [x20, #0x6a8]                         T:System.Globalization.CultureInfo
02cad8e0: str     xzr, [sp, #8]                              
02cad8e4: cbnz    w8, #0x2cad8ec                             
02cad8e8: bl      #0x2b70f30                                 fn_2b70f30
02cad8ec: adrp    x19, #0x6266000                            
02cad8f0: mov     x0, xzr                                    
02cad8f4: ldr     x19, [x19, #0x158]                         S:'yyyy-MM-dd'
02cad8f8: bl      #0x4df25c8                                 System.DateTime::get_Now
02cad8fc: str     x0, [sp, #8]                               
02cad900: add     x0, sp, #8                                 
02cad904: mov     x1, xzr                                    
02cad908: bl      #0x4df1f38                                 System.DateTime::get_Date
02cad90c: ldr     x8, [x20]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02cad910: str     x0, [sp, #8]                               
02cad914: ldr     w9, [x8, #0xe4]                            
02cad918: cbnz    w9, #0x2cad924                             
02cad91c: mov     x0, x8                                     
02cad920: bl      #0x2b70f30                                 fn_2b70f30
02cad924: mov     x0, xzr                                    
02cad928: bl      #0x4d9ea74                                 System.Globalization.CultureInfo::get_InvariantCulture
02cad92c: ldr     x1, [x19]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cad930: mov     x2, x0                                     
02cad934: add     x0, sp, #8                                 
02cad938: mov     x3, xzr                                    
02cad93c: bl      #0x4df3688                                 System.DateTime::ToString
02cad940: ldp     x20, x19, [sp, #0x10]                      
02cad944: ldr     x30, [sp], #0x20                           
02cad948: ret                                                
## GetNormalizedLastLoginDateString() -> string
---- PlayTimeTracker::GetNormalizedLastLoginDateString 0x2cad94c
02cad94c: sub     sp, sp, #0x60                              
02cad950: str     x30, [sp, #0x20]                           
02cad954: stp     x24, x23, [sp, #0x30]                      
02cad958: stp     x22, x21, [sp, #0x40]                      
02cad95c: stp     x20, x19, [sp, #0x50]                      
02cad960: adrp    x20, #0x662f000                            
02cad964: mov     x19, x0                                    
02cad968: ldrb    w8, [x20, #0xb40]                          
02cad96c: tbnz    w8, #0, #0x2cad99c                         
02cad970: adrp    x0, #0x6264000                             
02cad974: ldr     x0, [x0, #0x6a8]                           T:System.Globalization.CultureInfo
02cad978: bl      #0x2b70db0                                 fn_2b70db0
02cad97c: adrp    x0, #0x6266000                             
02cad980: ldr     x0, [x0, #0x128]                           T:System.DateTime
02cad984: bl      #0x2b70db0                                 fn_2b70db0
02cad988: adrp    x0, #0x6266000                             
02cad98c: ldr     x0, [x0, #0x158]                           S:'yyyy-MM-dd'
02cad990: bl      #0x2b70db0                                 fn_2b70db0
02cad994: mov     w8, #1                                     
02cad998: strb    w8, [x20, #0xb40]                          
02cad99c: ldr     x8, [x19, #0x30]                           ._dataPlayTime
02cad9a0: str     xzr, [sp, #0x28]                           
02cad9a4: str     xzr, [sp, #0x18]                           
02cad9a8: str     wzr, [sp, #0x10]                           
02cad9ac: cbz     x8, #0x2cada8c                             
02cad9b0: ldr     x20, [x8, #0x20]                           
02cad9b4: cbz     x20, #0x2cada90                            
02cad9b8: ldr     x0, [x20, #0x10]!                          &2b706e8(=14cc74f191004000)
02cad9bc: mov     x1, xzr                                    
02cad9c0: bl      #0x4ca6234                                 System.String::IsNullOrEmpty
02cad9c4: tbz     w0, #0, #0x2cad9e0                         
02cad9c8: bl      #0x2cad888                                 PlayTimeTracker::TodayKey
02cad9cc: mov     x1, x0                                     
02cad9d0: str     x1, [x20]                                  
02cad9d4: mov     x0, x20                                    
02cad9d8: bl      #0x2b70d54                                 fn_2b70d54
02cad9dc: b       #0x2cadb9c                                 
02cad9e0: adrp    x8, #0x6264000                             
02cad9e4: ldr     x8, [x8, #0x6a8]                           T:System.Globalization.CultureInfo
02cad9e8: ldr     x21, [x20]                                 &2b706c4(=eb01011ff9400808)
02cad9ec: ldr     x0, [x8]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02cad9f0: ldr     w8, [x0, #0xe4]                            [62660e4]=0 f=0,0
02cad9f4: cbnz    w8, #0x2cad9fc                             
02cad9f8: bl      #0x2b70f30                                 fn_2b70f30
02cad9fc: mov     x0, xzr                                    
02cada00: bl      #0x4d9ea74                                 System.Globalization.CultureInfo::get_InvariantCulture
02cada04: adrp    x24, #0x6266000                            
02cada08: mov     x22, x0                                    
02cada0c: ldr     x24, [x24, #0x128]                         T:System.DateTime
02cada10: ldr     x0, [x24]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cada14: ldr     w8, [x0, #0xe4]                            [62660e4]=0 f=0,0
02cada18: cbnz    w8, #0x2cada20                             
02cada1c: bl      #0x2b70f30                                 fn_2b70f30
02cada20: adrp    x23, #0x6266000                            
02cada24: ldr     x23, [x23, #0x158]                         S:'yyyy-MM-dd'
02cada28: ldr     x1, [x23]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cada2c: add     x4, sp, #0x28                              
02cada30: mov     x0, x21                                    
02cada34: mov     x2, x22                                    
02cada38: mov     w3, wzr                                    
02cada3c: mov     x5, xzr                                    
02cada40: bl      #0x4df3b04                                 System.DateTime::TryParseExact
02cada44: tbz     w0, #0, #0x2cadb64                         
02cada48: ldr     x0, [x24]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cada4c: ldr     w8, [x0, #0xe4]                            [62660e4]=0 f=0,0
02cada50: cbnz    w8, #0x2cada58                             
02cada54: bl      #0x2b70f30                                 fn_2b70f30
02cada58: add     x0, sp, #0x28                              
02cada5c: mov     x1, xzr                                    
02cada60: bl      #0x4df1f38                                 System.DateTime::get_Date
02cada64: ldr     x1, [x23]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cada68: str     x0, [sp, #0x18]                            
02cada6c: add     x0, sp, #0x18                              
02cada70: mov     x2, xzr                                    
02cada74: bl      #0x4df35b0                                 System.DateTime::ToString
02cada78: mov     x1, x0                                     
02cada7c: str     x1, [x20]                                  
02cada80: mov     x0, x20                                    
02cada84: bl      #0x2b70d54                                 fn_2b70d54
02cada88: b       #0x2cadb9c                                 
02cada8c: bl      #0x2b7105c                                 fn_2b7105c
02cada90: bl      #0x2b7105c                                 fn_2b7105c
02cada94: b       #0x2cadab8                                 
02cada98: b       #0x2cadab8                                 
02cada9c: b       #0x2cadab8                                 
02cadaa0: b       #0x2cadab8                                 
02cadaa4: b       #0x2cadab8                                 
02cadaa8: b       #0x2cadab8                                 
02cadaac: b       #0x2cadab8                                 
02cadab0: b       #0x2cadab8                                 
02cadab4: b       #0x2cadab8                                 
02cadab8: mov     x20, x0                                    
02cadabc: cmp     w1, #1                                     
02cadac0: b.ne    #0x2cadbe4                                 
02cadac4: mov     x0, x20                                    
02cadac8: bl      #0x5e90260                                 fn_5e90260
02cadacc: mov     x20, x0                                    
02cadad0: adrp    x0, #0x6263000                             
02cadad4: ldr     x0, [x0, #0xae0]                           T:System.Exception
02cadad8: bl      #0x2b70dc4                                 fn_2b70dc4
02cadadc: ldr     x8, [x20]                                  &2b706c4(=eb01011ff9400808)
02cadae0: ldr     x1, [x8]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02cadae4: bl      #0x2b71464                                 fn_2b71464
02cadae8: tbz     w0, #0, #0x2cadbbc                         
02cadaec: ldrsw   x21, [sp, #0x10]                           
02cadaf0: ldr     x20, [x20]                                 &2b706c4(=eb01011ff9400808)
02cadaf4: add     x8, sp, #8                                 
02cadaf8: str     x20, [x8, x21, lsl #3]                     
02cadafc: add     w8, w21, #1                                
02cadb00: str     w8, [sp, #0x10]                            
02cadb04: bl      #0x5e90270                                 fn_5e90270
02cadb08: cbz     x20, #0x2cadbb8                            
02cadb0c: ldr     x8, [x20]                                  &2b706c4(=eb01011ff9400808)
02cadb10: mov     x0, x20                                    
02cadb14: ldp     x9, x1, [x8, #0x188]                       
02cadb18: blr     x9                                         
02cadb1c: mov     x20, x0                                    
02cadb20: adrp    x0, #0x6266000                             
02cadb24: ldr     x0, [x0, #0x8c8]                           S:'Error parsing LastLoginDateString: '
02cadb28: bl      #0x2b70dc4                                 fn_2b70dc4
02cadb2c: mov     x1, x20                                    
02cadb30: mov     x2, xzr                                    
02cadb34: bl      #0x4c9c514                                 System.String::Concat
02cadb38: mov     x20, x0                                    
02cadb3c: adrp    x0, #0x6263000                             
02cadb40: ldr     x0, [x0, #0x928]                           T:UnityEngine.Debug
02cadb44: bl      #0x2b70dc4                                 fn_2b70dc4
02cadb48: ldr     w8, [x0, #0xe4]                            [62630e4]=0 f=0,0
02cadb4c: cbnz    w8, #0x2cadb54                             
02cadb50: bl      #0x2b70f30                                 fn_2b70f30
02cadb54: mov     x0, x20                                    
02cadb58: mov     x1, xzr                                    
02cadb5c: bl      #0x5af2840                                 UnityEngine.Debug::LogError
02cadb60: str     w21, [sp, #0x10]                           
02cadb64: ldr     x8, [x19, #0x30]                           ._dataPlayTime
02cadb68: cbz     x8, #0x2cadbb8                             
02cadb6c: ldr     x20, [x8, #0x20]                           T:DG.Tweening.DOTweenModulePhysics/<>c__DisplayClass0_0
02cadb70: bl      #0x2cad888                                 PlayTimeTracker::TodayKey
02cadb74: cbz     x20, #0x2cadbb8                            
02cadb78: mov     x1, x0                                     
02cadb7c: str     x0, [x20, #0x10]!                          
02cadb80: mov     x0, x20                                    
02cadb84: bl      #0x2b70d54                                 fn_2b70d54
02cadb88: ldr     x8, [x19, #0x30]                           ._dataPlayTime
02cadb8c: cbz     x8, #0x2cadbb8                             
02cadb90: ldr     x8, [x8, #0x20]                            T:DG.Tweening.DOTweenModulePhysics/<>c__DisplayClass0_0
02cadb94: cbz     x8, #0x2cadbb8                             
02cadb98: add     x20, x8, #0x10                             &6264010
02cadb9c: ldr     x0, [x20]                                  &2b706c4(=eb01011ff9400808)
02cadba0: ldp     x20, x19, [sp, #0x50]                      
02cadba4: ldp     x22, x21, [sp, #0x40]                      
02cadba8: ldr     x30, [sp, #0x20]                           
02cadbac: ldp     x24, x23, [sp, #0x30]                      
02cadbb0: add     sp, sp, #0x60                              
02cadbb4: ret                                                
02cadbb8: bl      #0x2b7105c                                 fn_2b7105c
02cadbbc: mov     w0, #8                                     
02cadbc0: bl      #0x5e90290                                 fn_5e90290
02cadbc4: ldr     x8, [x20]                                  &2b706c4(=eb01011ff9400808)
02cadbc8: str     x8, [x0]                                   
02cadbcc: adrp    x1, #0x5e96000                             
02cadbd0: add     x1, x1, #0x758                             &5e96758
02cadbd4: mov     x2, xzr                                    
02cadbd8: bl      #0x5e902a0                                 fn_5e902a0
02cadbdc: mov     x20, x0                                    
02cadbe0: bl      #0x5e90270                                 fn_5e90270
02cadbe4: mov     x0, x20                                    
02cadbe8: bl      #0x2c6051c                                 fn_2c6051c
02cadbec: bl      #0x27369b8                                 fn_27369b8
## HasDateChanged() -> bool
---- PlayTimeTracker::HasDateChanged 0x2cad438
02cad438: sub     sp, sp, #0x50                              
02cad43c: stp     x30, x23, [sp, #0x20]                      
02cad440: stp     x22, x21, [sp, #0x30]                      
02cad444: stp     x20, x19, [sp, #0x40]                      
02cad448: adrp    x20, #0x662f000                            
02cad44c: mov     x19, x0                                    
02cad450: ldrb    w8, [x20, #0xb41]                          
02cad454: tbnz    w8, #0, #0x2cad484                         
02cad458: adrp    x0, #0x6264000                             
02cad45c: ldr     x0, [x0, #0x6a8]                           T:System.Globalization.CultureInfo
02cad460: bl      #0x2b70db0                                 fn_2b70db0
02cad464: adrp    x0, #0x6266000                             
02cad468: ldr     x0, [x0, #0x128]                           T:System.DateTime
02cad46c: bl      #0x2b70db0                                 fn_2b70db0
02cad470: adrp    x0, #0x6266000                             
02cad474: ldr     x0, [x0, #0x158]                           S:'yyyy-MM-dd'
02cad478: bl      #0x2b70db0                                 fn_2b70db0
02cad47c: mov     w8, #1                                     
02cad480: strb    w8, [x20, #0xb41]                          
02cad484: ldr     x8, [x19, #0x30]                           ._dataPlayTime
02cad488: stp     xzr, xzr, [sp, #0x10]                      
02cad48c: str     wzr, [sp, #8]                              
02cad490: cbz     x8, #0x2cad610                             
02cad494: ldr     x8, [x8, #0x20]                            
02cad498: cbz     x8, #0x2cad610                             
02cad49c: ldr     x19, [x8, #0x10]                           
02cad4a0: mov     x0, x19                                    
02cad4a4: mov     x1, xzr                                    
02cad4a8: bl      #0x4ca6234                                 System.String::IsNullOrEmpty
02cad4ac: tbz     w0, #0, #0x2cad4b8                         
02cad4b0: mov     w8, wzr                                    
02cad4b4: b       #0x2cad610                                 
02cad4b8: adrp    x21, #0x6264000                            
02cad4bc: ldr     x21, [x21, #0x6a8]                         T:System.Globalization.CultureInfo
02cad4c0: ldr     x0, [x21]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02cad4c4: ldr     w8, [x0, #0xe4]                            [62660e4]=0 f=0,0
02cad4c8: cbnz    w8, #0x2cad4d0                             
02cad4cc: bl      #0x2b70f30                                 fn_2b70f30
02cad4d0: mov     x0, xzr                                    
02cad4d4: bl      #0x4d9ea74                                 System.Globalization.CultureInfo::get_InvariantCulture
02cad4d8: adrp    x23, #0x6266000                            
02cad4dc: mov     x20, x0                                    
02cad4e0: ldr     x23, [x23, #0x128]                         T:System.DateTime
02cad4e4: ldr     x0, [x23]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cad4e8: ldr     w8, [x0, #0xe4]                            [62660e4]=0 f=0,0
02cad4ec: cbnz    w8, #0x2cad4f4                             
02cad4f0: bl      #0x2b70f30                                 fn_2b70f30
02cad4f4: adrp    x22, #0x6266000                            
02cad4f8: ldr     x22, [x22, #0x158]                         S:'yyyy-MM-dd'
02cad4fc: ldr     x1, [x22]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cad500: add     x4, sp, #0x18                              
02cad504: mov     x0, x19                                    
02cad508: mov     x2, x20                                    
02cad50c: mov     w3, wzr                                    
02cad510: mov     x5, xzr                                    
02cad514: bl      #0x4df3b04                                 System.DateTime::TryParseExact
02cad518: tbz     w0, #0, #0x2cad60c                         
02cad51c: ldr     x0, [x23]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cad520: ldr     w8, [x0, #0xe4]                            [62660e4]=0 f=0,0
02cad524: cbnz    w8, #0x2cad52c                             
02cad528: bl      #0x2b70f30                                 fn_2b70f30
02cad52c: add     x0, sp, #0x18                              
02cad530: mov     x1, xzr                                    
02cad534: bl      #0x4df1f38                                 System.DateTime::get_Date
02cad538: mov     x8, x0                                     
02cad53c: ldr     x0, [x21]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02cad540: str     x8, [sp, #0x10]                            
02cad544: ldr     w9, [x0, #0xe4]                            [62660e4]=0 f=0,0
02cad548: cbnz    w9, #0x2cad550                             
02cad54c: bl      #0x2b70f30                                 fn_2b70f30
02cad550: mov     x0, xzr                                    
02cad554: bl      #0x4d9ea74                                 System.Globalization.CultureInfo::get_InvariantCulture
02cad558: ldr     x1, [x22]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cad55c: mov     x2, x0                                     
02cad560: add     x0, sp, #0x10                              
02cad564: mov     x3, xzr                                    
02cad568: bl      #0x4df3688                                 System.DateTime::ToString
02cad56c: mov     x19, x0                                    
02cad570: bl      #0x2cad888                                 PlayTimeTracker::TodayKey
02cad574: mov     x1, x0                                     
02cad578: mov     x0, x19                                    
02cad57c: mov     w2, #4                                     
02cad580: mov     x3, xzr                                    
02cad584: bl      #0x4ca5010                                 System.String::Equals
02cad588: eor     w8, w0, #1                                 
02cad58c: b       #0x2cad610                                 
02cad590: b       #0x2cad5b8                                 
02cad594: b       #0x2cad5b8                                 
02cad598: b       #0x2cad5b8                                 
02cad59c: b       #0x2cad5b8                                 
02cad5a0: b       #0x2cad5b8                                 
02cad5a4: b       #0x2cad5b8                                 
02cad5a8: b       #0x2cad5b8                                 
02cad5ac: b       #0x2cad5b8                                 
02cad5b0: b       #0x2cad5b8                                 
02cad5b4: b       #0x2cad5b8                                 
02cad5b8: mov     x19, x0                                    
02cad5bc: cmp     w1, #1                                     
02cad5c0: b.ne    #0x2cad650                                 
02cad5c4: mov     x0, x19                                    
02cad5c8: bl      #0x5e90260                                 fn_5e90260
02cad5cc: adrp    x8, #0x6263000                             
02cad5d0: mov     x19, x0                                    
02cad5d4: ldr     x8, [x8, #0x970]                           &6645c70(=0)
02cad5d8: ldr     x9, [x0]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cad5dc: ldr     x0, [x8, #0x10]                            &2c498bc(=aa1f03e0d503245f)
02cad5e0: ldr     x1, [x9]                                   
02cad5e4: bl      #0x2b71464                                 fn_2b71464
02cad5e8: tbz     w0, #0, #0x2cad628                         
02cad5ec: ldrsw   x20, [sp, #8]                              
02cad5f0: ldr     x8, [x19]                                  
02cad5f4: mov     x9, sp                                     
02cad5f8: str     x8, [x9, x20, lsl #3]                      
02cad5fc: add     w8, w20, #1                                
02cad600: str     w8, [sp, #8]                               
02cad604: bl      #0x5e90270                                 fn_5e90270
02cad608: str     w20, [sp, #8]                              
02cad60c: mov     w8, #1                                     
02cad610: ldp     x20, x19, [sp, #0x40]                      
02cad614: and     w0, w8, #1                                 
02cad618: ldp     x22, x21, [sp, #0x30]                      
02cad61c: ldp     x30, x23, [sp, #0x20]                      
02cad620: add     sp, sp, #0x50                              
02cad624: ret                                                
02cad628: mov     w0, #8                                     
02cad62c: bl      #0x5e90290                                 fn_5e90290
02cad630: ldr     x8, [x19]                                  
02cad634: str     x8, [x0]                                   
02cad638: adrp    x1, #0x5e96000                             
02cad63c: add     x1, x1, #0x758                             &5e96758
02cad640: mov     x2, xzr                                    
02cad644: bl      #0x5e902a0                                 fn_5e902a0
02cad648: mov     x19, x0                                    
02cad64c: bl      #0x5e90270                                 fn_5e90270
02cad650: mov     x0, x19                                    
02cad654: bl      #0x2c6051c                                 fn_2c6051c
02cad658: bl      #0x27369b8                                 fn_27369b8
## LoadOrReset() -> void
---- PlayTimeTracker::LoadOrReset 0x2cadbf0
02cadbf0: stp     x30, x23, [sp, #-0x30]!                    
02cadbf4: stp     x22, x21, [sp, #0x10]                      
02cadbf8: stp     x20, x19, [sp, #0x20]                      
02cadbfc: adrp    x20, #0x662f000                            
02cadc00: adrp    x21, #0x6266000                            
02cadc04: mov     x19, x0                                    
02cadc08: ldrb    w8, [x20, #0xb42]                          
02cadc0c: ldr     x21, [x21, #0x658]                         MS:MonoSingleton`1::get_Instance
02cadc10: tbnz    w8, #0, #0x2cadc58                         
02cadc14: adrp    x0, #0x6264000                             
02cadc18: ldr     x0, [x0, #0xf90]                           T:System.Action
02cadc1c: bl      #0x2b70db0                                 fn_2b70db0
02cadc20: adrp    x0, #0x6266000                             
02cadc24: ldr     x0, [x0, #0x8d0]                           MS:DataManager::GetData
02cadc28: bl      #0x2b70db0                                 fn_2b70db0
02cadc2c: adrp    x0, #0x6266000                             
02cadc30: ldr     x0, [x0, #0x658]                           MS:MonoSingleton`1::get_Instance
02cadc34: bl      #0x2b70db0                                 fn_2b70db0
02cadc38: adrp    x0, #0x6263000                             
02cadc3c: ldr     x0, [x0, #0x918]                           T:UnityEngine.Object
02cadc40: bl      #0x2b70db0                                 fn_2b70db0
02cadc44: adrp    x0, #0x6266000                             
02cadc48: ldr     x0, [x0, #0x8c0]                           M:PlayTimeTracker::SyncDataSave
02cadc4c: bl      #0x2b70db0                                 fn_2b70db0
02cadc50: mov     w8, #1                                     
02cadc54: strb    w8, [x20, #0xb42]                          
02cadc58: ldr     x0, [x21]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cadc5c: bl      #0x3769600                                 fn_3769600
02cadc60: cbz     x0, #0x2cadd78                             
02cadc64: adrp    x8, #0x6266000                             
02cadc68: adrp    x21, #0x6263000                            
02cadc6c: ldr     x8, [x8, #0x8d0]                           MS:DataManager::GetData
02cadc70: ldr     x21, [x21, #0x918]                         T:UnityEngine.Object
02cadc74: ldr     x1, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cadc78: bl      #0x3168dd0                                 fn_3168dd0
02cadc7c: mov     x20, x19                                   
02cadc80: mov     x1, x0                                     
02cadc84: str     x0, [x20, #0x30]!                          ._dataPlayTime
02cadc88: mov     x0, x20                                    
02cadc8c: bl      #0x2b70d54                                 fn_2b70d54
02cadc90: ldr     x0, [x21]                                  &2c5bbd4(=a9bd7bfdd503233f)
02cadc94: ldr     x21, [x20]                                 &2b706c4(=eb01011ff9400808)
02cadc98: ldr     w8, [x0, #0xe4]                            [62660e4]=0 f=0,0
02cadc9c: cbnz    w8, #0x2cadca4                             
02cadca0: bl      #0x2b70f30                                 fn_2b70f30
02cadca4: mov     x0, x21                                    
02cadca8: mov     x1, xzr                                    
02cadcac: mov     x2, xzr                                    
02cadcb0: bl      #0x5b37d84                                 UnityEngine.Object::op_Equality
02cadcb4: tbnz    w0, #0, #0x2cadd68                         
02cadcb8: adrp    x22, #0x6264000                            
02cadcbc: ldr     x22, [x22, #0xf90]                         T:System.Action
02cadcc0: ldr     x0, [x22]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02cadcc4: bl      #0x2b7104c                                 fn_2b7104c
02cadcc8: adrp    x23, #0x6266000                            
02cadccc: mov     x1, x19                                    
02cadcd0: mov     x3, xzr                                    
02cadcd4: ldr     x23, [x23, #0x8c0]                         M:PlayTimeTracker::SyncDataSave
02cadcd8: mov     x21, x0                                    
02cadcdc: ldr     x2, [x23]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cadce0: bl      #0x4d8ddbc                                 System.Action::.ctor
02cadce4: mov     x0, x21                                    
02cadce8: bl      #0x2caa3bc                                 DataManager::remove_OnBeforeSaveAll
02cadcec: ldr     x0, [x22]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02cadcf0: bl      #0x2b7104c                                 fn_2b7104c
02cadcf4: ldr     x2, [x23]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cadcf8: mov     x1, x19                                    
02cadcfc: mov     x3, xzr                                    
02cadd00: mov     x21, x0                                    
02cadd04: bl      #0x4d8ddbc                                 System.Action::.ctor
02cadd08: mov     x0, x21                                    
02cadd0c: bl      #0x2caa304                                 DataManager::add_OnBeforeSaveAll
02cadd10: mov     x0, x19                                    
02cadd14: bl      #0x2cad438                                 PlayTimeTracker::HasDateChanged
02cadd18: tbz     w0, #0, #0x2cadd28                         
02cadd1c: mov     x0, x19                                    
02cadd20: bl      #0x2cad65c                                 PlayTimeTracker::ResetForNewDay
02cadd24: b       #0x2cadd60                                 
02cadd28: ldr     x8, [x20]                                  &2b706c4(=eb01011ff9400808)
02cadd2c: cbz     x8, #0x2cadd78                             
02cadd30: ldr     x20, [x8, #0x20]                           S:'inter_ad_capping_time'
02cadd34: cbz     x20, #0x2cadd78                            
02cadd38: ldr     s0, [x20, #0x18]                           [662f018]=6000014 f=2.40742e-35,0
02cadd3c: mov     x0, x19                                    
02cadd40: str     s0, [x19, #0x20]                           ._accumulatedSeconds
02cadd44: bl      #0x2cad94c                                 PlayTimeTracker::GetNormalizedLastLoginDateString
02cadd48: mov     x1, x0                                     
02cadd4c: str     x0, [x20, #0x10]!                          
02cadd50: mov     x0, x20                                    
02cadd54: bl      #0x2b70d54                                 fn_2b70d54
02cadd58: mov     x0, x19                                    
02cadd5c: bl      #0x2cadd7c                                 PlayTimeTracker::SetupDataPlayTime
02cadd60: mov     w8, #1                                     
02cadd64: strb    w8, [x19, #0x38]                           ._isInitialized
02cadd68: ldp     x20, x19, [sp, #0x20]                      
02cadd6c: ldp     x22, x21, [sp, #0x10]                      
02cadd70: ldp     x30, x23, [sp], #0x30                      
02cadd74: ret                                                
02cadd78: bl      #0x2b7105c                                 fn_2b7105c
## ResetForNewDay() -> void
---- PlayTimeTracker::ResetForNewDay 0x2cad65c
02cad65c: stp     x30, x21, [sp, #-0x20]!                    
02cad660: stp     x20, x19, [sp, #0x10]                      
02cad664: adrp    x21, #0x662f000                            
02cad668: adrp    x20, #0x6263000                            
02cad66c: mov     x19, x0                                    
02cad670: ldrb    w8, [x21, #0xb43]                          
02cad674: ldr     x20, [x20, #0x918]                         T:UnityEngine.Object
02cad678: tbnz    w8, #0, #0x2cad690                         
02cad67c: adrp    x0, #0x6263000                             
02cad680: ldr     x0, [x0, #0x918]                           T:UnityEngine.Object
02cad684: bl      #0x2b70db0                                 fn_2b70db0
02cad688: mov     w8, #1                                     
02cad68c: strb    w8, [x21, #0xb43]                          
02cad690: ldr     x0, [x20]                                  &2c5bbd4(=a9bd7bfdd503233f)
02cad694: ldr     x20, [x19, #0x30]                          ._dataPlayTime
02cad698: ldr     w8, [x0, #0xe4]                            [62630e4]=0 f=0,0
02cad69c: cbnz    w8, #0x2cad6a4                             
02cad6a0: bl      #0x2b70f30                                 fn_2b70f30
02cad6a4: mov     x0, x20                                    
02cad6a8: mov     x1, xzr                                    
02cad6ac: mov     x2, xzr                                    
02cad6b0: bl      #0x5b37d84                                 UnityEngine.Object::op_Equality
02cad6b4: tbz     w0, #0, #0x2cad6c4                         
02cad6b8: ldp     x20, x19, [sp, #0x10]                      
02cad6bc: ldp     x30, x21, [sp], #0x20                      
02cad6c0: ret                                                
02cad6c4: ldr     x0, [x19, #0x30]                           ._dataPlayTime
02cad6c8: str     xzr, [x19, #0x20]                          ._accumulatedSeconds
02cad6cc: cbz     x0, #0x2cad714                             
02cad6d0: mov     x1, xzr                                    
02cad6d4: bl      #0x2d58cec                                 LoginTimeReward.DataPlayTime::ResetForNewDay
02cad6d8: ldr     x8, [x19, #0x30]                           ._dataPlayTime
02cad6dc: cbz     x8, #0x2cad714                             
02cad6e0: ldr     x20, [x8, #0x20]                           
02cad6e4: bl      #0x2cad888                                 PlayTimeTracker::TodayKey
02cad6e8: cbz     x20, #0x2cad714                            
02cad6ec: mov     x1, x0                                     
02cad6f0: str     x0, [x20, #0x10]!                          
02cad6f4: mov     x0, x20                                    
02cad6f8: bl      #0x2b70d54                                 fn_2b70d54
02cad6fc: mov     x0, x19                                    
02cad700: bl      #0x2cadd7c                                 PlayTimeTracker::SetupDataPlayTime
02cad704: mov     x0, x19                                    
02cad708: ldp     x20, x19, [sp, #0x10]                      
02cad70c: ldp     x30, x21, [sp], #0x20                      
02cad710: b       #0x2cad718                                 PlayTimeTracker::Save
02cad714: bl      #0x2b7105c                                 fn_2b7105c
## SetupDataPlayTime() -> void
---- PlayTimeTracker::SetupDataPlayTime 0x2cadd7c
02cadd7c: stp     x30, x21, [sp, #-0x20]!                    
02cadd80: stp     x20, x19, [sp, #0x10]                      
02cadd84: adrp    x20, #0x662f000                            
02cadd88: adrp    x21, #0x6266000                            
02cadd8c: mov     x19, x0                                    
02cadd90: ldrb    w8, [x20, #0xb44]                          
02cadd94: ldr     x21, [x21, #0x658]                         MS:MonoSingleton`1::get_Instance
02cadd98: tbnz    w8, #0, #0x2caddc8                         
02cadd9c: adrp    x0, #0x6266000                             
02cadda0: ldr     x0, [x0, #0x8d0]                           MS:DataManager::GetData
02cadda4: bl      #0x2b70db0                                 fn_2b70db0
02cadda8: adrp    x0, #0x6266000                             
02caddac: ldr     x0, [x0, #0x8d8]                           MS:System.Collections.Generic.List`1::get_Count
02caddb0: bl      #0x2b70db0                                 fn_2b70db0
02caddb4: adrp    x0, #0x6266000                             
02caddb8: ldr     x0, [x0, #0x658]                           MS:MonoSingleton`1::get_Instance
02caddbc: bl      #0x2b70db0                                 fn_2b70db0
02caddc0: mov     w8, #1                                     
02caddc4: strb    w8, [x20, #0xb44]                          
02caddc8: ldr     x0, [x21]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02caddcc: bl      #0x3769600                                 fn_3769600
02caddd0: cbz     x0, #0x2cade3c                             
02caddd4: adrp    x8, #0x6266000                             
02caddd8: ldr     x8, [x8, #0x8d0]                           MS:DataManager::GetData
02cadddc: ldr     x1, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cadde0: bl      #0x3168dd0                                 fn_3168dd0
02cadde4: ldr     x8, [x19, #0x28]                           ._loginTimeRewardConfig
02cadde8: cbz     x8, #0x2cade3c                             
02caddec: ldr     x21, [x8, #0x18]                           S:'level_show_popuprate'
02caddf0: cbz     x21, #0x2cade3c                            
02caddf4: ldr     w8, [x21, #0x18]                           S:'level_show_popuprate'
02caddf8: cmp     w8, #1                                     
02caddfc: b.lt    #0x2cade30                                 
02cade00: mov     x19, x0                                    
02cade04: mov     w20, wzr                                   
02cade08: cbz     x19, #0x2cade3c                            
02cade0c: mov     x0, x19                                    
02cade10: mov     w1, w20                                    
02cade14: mov     w2, wzr                                    
02cade18: mov     x3, xzr                                    
02cade1c: bl      #0x2d58dc8                                 LoginTimeReward.DataPlayTime::UpdateLoginData
02cade20: ldr     w8, [x21, #0x18]                           S:'level_show_popuprate'
02cade24: add     w20, w20, #1                               
02cade28: cmp     w20, w8                                    
02cade2c: b.lt    #0x2cade08                                 
02cade30: ldp     x20, x19, [sp, #0x10]                      
02cade34: ldp     x30, x21, [sp], #0x20                      
02cade38: ret                                                
02cade3c: bl      #0x2b7105c                                 fn_2b7105c
## Save() -> void
---- PlayTimeTracker::Save 0x2cad718
02cad718: str     x30, [sp, #-0x10]!                         
02cad71c: mov     x8, x0                                     
02cad720: ldr     x0, [x0, #0x30]                            ._dataPlayTime
02cad724: cbz     x0, #0x2cad74c                             
02cad728: ldr     x9, [x0, #0x20]                            ._accumulatedSeconds
02cad72c: cbz     x9, #0x2cad74c                             
02cad730: ldr     s0, [x8, #0x20]                            
02cad734: str     s0, [x9, #0x18]                            
02cad738: ldr     x8, [x0]                                   
02cad73c: ldr     x1, [x8, #0x260]                           
02cad740: ldr     x2, [x8, #0x258]                           
02cad744: ldr     x30, [sp], #0x10                           
02cad748: br      x2                                         
02cad74c: bl      #0x2b7105c                                 fn_2b7105c
## GetMinuteRoundDown() -> int
---- PlayTimeTracker::GetMinuteRoundDown 0x2cade40
02cade40: str     d8, [sp, #-0x20]!                          
02cade44: stp     x30, x19, [sp, #0x10]                      
02cade48: adrp    x19, #0x662f000                            
02cade4c: ldr     s8, [x0, #0x20]                            ._accumulatedSeconds
02cade50: ldrb    w8, [x19, #0xbd8]                          
02cade54: cbnz    w8, #0x2cade6c                             
02cade58: adrp    x0, #0x6265000                             
02cade5c: ldr     x0, [x0, #0xb48]                           T:System.Math
02cade60: bl      #0x2b70db0                                 fn_2b70db0
02cade64: mov     w8, #1                                     
02cade68: strb    w8, [x19, #0xbd8]                          
02cade6c: adrp    x8, #0x6265000                             
02cade70: ldr     x8, [x8, #0xb48]                           T:System.Math
02cade74: ldr     x0, [x8]                                   M:AdsManager::<OnApplicationPause>b__26_0
02cade78: ldr     w8, [x0, #0xe4]                            [62650e4]=0 f=0,0
02cade7c: cbnz    w8, #0x2cade84                             
02cade80: bl      #0x2b70f30                                 fn_2b70f30
02cade84: mov     w8, #0x42700000                            
02cade88: ldp     x30, x19, [sp, #0x10]                      
02cade8c: fmov    s0, w8                                     
02cade90: mov     w8, #0x7f800000                            
02cade94: fdiv    s0, s8, s0                                 
02cade98: frintm  s1, s0                                     
02cade9c: fcvtms  w9, s0                                     
02cadea0: fmov    s0, w8                                     
02cadea4: mov     w8, #-0xffffffff80000000                   
02cadea8: fcmp    s1, s0                                     
02cadeac: csel    w0, w8, w9, eq                             
02cadeb0: ldr     d8, [sp], #0x20                            
02cadeb4: ret                                                
## GetSecondRoundDown() -> int
---- PlayTimeTracker::GetSecondRoundDown 0x2cadeb8
02cadeb8: str     d8, [sp, #-0x20]!                          
02cadebc: stp     x30, x19, [sp, #0x10]                      
02cadec0: adrp    x19, #0x662f000                            
02cadec4: ldr     s8, [x0, #0x20]                            ._accumulatedSeconds
02cadec8: ldrb    w8, [x19, #0xbd8]                          
02cadecc: cbnz    w8, #0x2cadee4                             
02caded0: adrp    x0, #0x6265000                             
02caded4: ldr     x0, [x0, #0xb48]                           T:System.Math
02caded8: bl      #0x2b70db0                                 fn_2b70db0
02cadedc: mov     w8, #1                                     
02cadee0: strb    w8, [x19, #0xbd8]                          
02cadee4: adrp    x8, #0x6265000                             
02cadee8: ldr     x8, [x8, #0xb48]                           T:System.Math
02cadeec: ldr     x0, [x8]                                   M:AdsManager::<OnApplicationPause>b__26_0
02cadef0: ldr     w8, [x0, #0xe4]                            [62650e4]=0 f=0,0
02cadef4: cbnz    w8, #0x2cadefc                             
02cadef8: bl      #0x2b70f30                                 fn_2b70f30
02cadefc: frintm  s0, s8                                     
02cadf00: mov     w8, #0x7f800000                            
02cadf04: fcvtms  w9, s8                                     
02cadf08: fmov    s1, w8                                     
02cadf0c: ldp     x30, x19, [sp, #0x10]                      
02cadf10: mov     w8, #-0xffffffff80000000                   
02cadf14: fcmp    s0, s1                                     
02cadf18: csel    w0, w8, w9, eq                             
02cadf1c: ldr     d8, [sp], #0x20                            
02cadf20: ret                                                
## .ctor() -> void
---- PlayTimeTracker::.ctor 0x2cadf24
02cadf24: stp     x30, x21, [sp, #-0x20]!                    
02cadf28: stp     x20, x19, [sp, #0x10]                      
02cadf2c: adrp    x20, #0x662f000                            
02cadf30: adrp    x21, #0x6266000                            
02cadf34: mov     x19, x0                                    
02cadf38: ldrb    w8, [x20, #0xb45]                          
02cadf3c: ldr     x21, [x21, #0x8e0]                         MS:MonoSingleton`1::.ctor
02cadf40: tbnz    w8, #0, #0x2cadf58                         
02cadf44: adrp    x0, #0x6266000                             
02cadf48: ldr     x0, [x0, #0x8e0]                           MS:MonoSingleton`1::.ctor
02cadf4c: bl      #0x2b70db0                                 fn_2b70db0
02cadf50: mov     w8, #1                                     
02cadf54: strb    w8, [x20, #0xb45]                          
02cadf58: mov     x0, x19                                    
02cadf5c: ldp     x20, x19, [sp, #0x10]                      
02cadf60: ldr     x1, [x21]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cadf64: ldp     x30, x21, [sp], #0x20                      
02cadf68: b       #0x3769e18                                 
## <Initiate>b__11_0() -> void
---- PlayTimeTracker::<Initiate>b__11_0 0x2cadf6c
02cadf6c: b       #0x2cadbf0                                 PlayTimeTracker::LoadOrReset
