#### CLASS HomeUnlockItemData parent= object
#   field Day                            int                                                off=0x10 attr=6 
#   field Type                           HomeUnlockType                                     off=0x14 attr=6 
#   field ForceEvent                     bool                                               off=0x18 attr=6 
#   field CharmId                        int                                                off=0x1c attr=6 
## .ctor() -> void
---- HomeUnlockItemData::.ctor 0x2cafdcc
02cafdcc: mov     x1, xzr                                    
02cafdd0: b       #0x4e53e9c                                 System.Object::.ctor
