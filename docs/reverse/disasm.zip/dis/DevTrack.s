#### CLASS DevTrack parent= UnityEngine.MonoBehaviour
#   field onboarding_begin               string                                             off=0x0 attr=16 
#   field onboarding_step                string                                             off=0x8 attr=16 
#   field onboarding_complete            string                                             off=0x10 attr=16 
#   field game_mode_enter                string                                             off=0x18 attr=16 
#   field game_mode_start                string                                             off=0x20 attr=16 
#   field game_mode_step_enter           string                                             off=0x28 attr=16 
#   field game_mode_step_complete        string                                             off=0x30 attr=16 
#   field game_mode_exit                 string                                             off=0x38 attr=16 
#   field game_mode_complete             string                                             off=0x40 attr=16 
#   field diy_item_select                string                                             off=0x48 attr=16 
#   field diy_item_choose                string                                             off=0x50 attr=16 
#   field diy_decoration_summary         string                                             off=0x58 attr=16 
#   field feature_open                   string                                             off=0x60 attr=16 
#   field feature_action                 string                                             off=0x68 attr=16 
#   field collection_item_view           string                                             off=0x70 attr=16 
#   field game_mode_select               string                                             off=0x78 attr=16 
#   field currency_earn                  string                                             off=0x80 attr=16 
#   field currency_spend                 string                                             off=0x88 attr=16 
#   field reward_double_ads_tap          string                                             off=0x90 attr=16 
#   field reward_double_ads_result       string                                             off=0x98 attr=16 
#   field reward_claim                   string                                             off=0xa0 attr=16 
#   field setting_changed                string                                             off=0xa8 attr=16 
#   field fps_report                     string                                             off=0xb0 attr=16 
#   field tutorial_id                    string                                             off=0xb8 attr=16 
#   field step_id                        string                                             off=0xc0 attr=16 
#   field step_index                     string                                             off=0xc8 attr=16 
#   field duration_sec                   string                                             off=0xd0 attr=16 
#   field game_mode                      string                                             off=0xd8 attr=16 
#   field flow_index                     string                                             off=0xe0 attr=16 
#   field step_duration_sec              string                                             off=0xe8 attr=16 
#   field last_step_id                   string                                             off=0xf0 attr=16 
#   field exit_type                      string                                             off=0xf8 attr=16 
#   field elapsed_time                   string                                             off=0x100 attr=16 
#   field total_duration_sec             string                                             off=0x108 attr=16 
#   field item_type                      string                                             off=0x110 attr=16 
#   field item_id                        string                                             off=0x118 attr=16 
#   field item_rarity                    string                                             off=0x120 attr=16 
#   field current_item_count             string                                             off=0x128 attr=16 
#   field total_keycap_count             string                                             off=0x130 attr=16 
#   field total_charm_count              string                                             off=0x138 attr=16 
#   field feature_name                   string                                             off=0x140 attr=16 
#   field action_name                    string                                             off=0x148 attr=16 
#   field item_status                    string                                             off=0x150 attr=16 
#   field currency_type                  string                                             off=0x158 attr=16 
#   field amount                         string                                             off=0x160 attr=16 
#   field source                         string                                             off=0x168 attr=16 
#   field balance_after                  string                                             off=0x170 attr=16 
#   field sink                           string                                             off=0x178 attr=16 
#   field placement_id                   string                                             off=0x180 attr=16 
#   field result                         string                                             off=0x188 attr=16 
#   field reward_type                    string                                             off=0x190 attr=16 
#   field setting_name                   string                                             off=0x198 attr=16 
#   field previous_value                 string                                             off=0x1a0 attr=16 
#   field new_value                      string                                             off=0x1a8 attr=16 
#   field fps_avg                        string                                             off=0x1b0 attr=16 
#   field fps_min                        string                                             off=0x1b8 attr=16 
#   field fps_max                        string                                             off=0x1c0 attr=16 
#   field frame_time_avg                 string                                             off=0x1c8 attr=16 
#   field playtime                       string                                             off=0x1d0 attr=16 
#   field screen_name                    string                                             off=0x1d8 attr=16 
#   field primary                        string                                             off=0x1e0 attr=16 
#   field secondary                      string                                             off=0x1e8 attr=16 
#   field entry_point                    string                                             off=0x1f0 attr=16 
#   field main_diy_tutorial              string                                             off=0x1f8 attr=16 
#   field blindbag_tutorial              string                                             off=0x200 attr=16 
#   field scoop_tutorial                 string                                             off=0x208 attr=16 
#   field dreamhouse_tutorial            string                                             off=0x210 attr=16 
#   field st_start                       string                                             off=0x218 attr=16 
#   field st_case                        string                                             off=0x220 attr=16 
#   field st_print                       string                                             off=0x228 attr=16 
#   field st_switch                      string                                             off=0x230 attr=16 
#   field st_keycap                      string                                             off=0x238 attr=16 
#   field st_decor                       string                                             off=0x240 attr=16 
#   field st_keychain                    string                                             off=0x248 attr=16 
#   field st_assemble                    string                                             off=0x250 attr=16 
#   field st_done                        string                                             off=0x258 attr=16 
#   field st_home                        string                                             off=0x260 attr=16 
#   field st_collection                  string                                             off=0x268 attr=16 
#   field st_start_id                    int                                                off=0x270 attr=16 
#   field st_case_id                     int                                                off=0x274 attr=16 
#   field st_print_id                    int                                                off=0x278 attr=16 
#   field st_switch_id                   int                                                off=0x27c attr=16 
#   field st_keycap_id                   int                                                off=0x280 attr=16 
#   field st_decor_id                    int                                                off=0x284 attr=16 
#   field st_keychain_id                 int                                                off=0x288 attr=16 
#   field st_assemble_id                 int                                                off=0x28c attr=16 
#   field st_done_id                     int                                                off=0x290 attr=16 
#   field st_home_id                     int                                                off=0x294 attr=16 
#   field st_collection_id               int                                                off=0x298 attr=16 
#   field st_open_door                   string                                             off=0x2a0 attr=16 
#   field st_get_bag                     string                                             off=0x2a8 attr=16 
#   field st_checkout                    string                                             off=0x2b0 attr=16 
#   field st_open_bag                    string                                             off=0x2b8 attr=16 
#   field st_put_to_collection           string                                             off=0x2c0 attr=16 
#   field st_blindbag_home               string                                             off=0x2c8 attr=16 
#   field st_open_door_id                int                                                off=0x2d0 attr=16 
#   field st_get_bag_id                  int                                                off=0x2d4 attr=16 
#   field st_checkout_id                 int                                                off=0x2d8 attr=16 
#   field st_open_bag_id                 int                                                off=0x2dc attr=16 
#   field st_put_to_collection_id        int                                                off=0x2e0 attr=16 
#   field st_blindbag_home_id            int                                                off=0x2e4 attr=16 
#   field st_scoop                       string                                             off=0x2e8 attr=16 
#   field st_unbox                       string                                             off=0x2f0 attr=16 
#   field st_select_box                  string                                             off=0x2f8 attr=16 
#   field st_wrapping                    string                                             off=0x300 attr=16 
#   field st_card                        string                                             off=0x308 attr=16 
#   field st_wrap_done                   string                                             off=0x310 attr=16 
#   field st_delivery                    string                                             off=0x318 attr=16 
#   field st_scoop_home                  string                                             off=0x320 attr=16 
#   field st_scoop_id                    int                                                off=0x328 attr=16 
#   field st_unbox_id                    int                                                off=0x32c attr=16 
#   field st_select_box_id               int                                                off=0x330 attr=16 
#   field st_wrapping_id                 int                                                off=0x334 attr=16 
#   field st_card_id                     int                                                off=0x338 attr=16 
#   field st_wrap_done_id                int                                                off=0x33c attr=16 
#   field st_delivery_id                 int                                                off=0x340 attr=16 
#   field st_scoop_home_id               int                                                off=0x344 attr=16 
#   field gm_main_diy                    string                                             off=0x348 attr=16 
#   field gm_blind_bag                   string                                             off=0x350 attr=16 
#   field gm_lucky_scoop                 string                                             off=0x358 attr=16 
#   field gm_3d_figure                   string                                             off=0x360 attr=16 
#   field gm_trading                     string                                             off=0x368 attr=16 
#   field it_switch                      string                                             off=0x370 attr=16 
#   field it_keycap                      string                                             off=0x378 attr=16 
#   field it_charm                       string                                             off=0x380 attr=16 
#   field it_keychain                    string                                             off=0x388 attr=16 
#   field st_success                     string                                             off=0x390 attr=16 
#   field st_unavailable                 string                                             off=0x398 attr=16 
#   field st_failed                      string                                             off=0x3a0 attr=16 
#   field st_not_completed               string                                             off=0x3a8 attr=16 
#   field home_button                    string                                             off=0x3b0 attr=16 
#   field trading_enter                  string                                             off=0x3b8 attr=16 
#   field trading_item_select            string                                             off=0x3c0 attr=16 
#   field trading_add_more               string                                             off=0x3c8 attr=16 
#   field trading_counter_request        string                                             off=0x3d0 attr=16 
#   field trading_complete               string                                             off=0x3d8 attr=16 
#   field trading_deny                   string                                             off=0x3e0 attr=16 
#   field trading_steal_ad               string                                             off=0x3e8 attr=16 
#   field entry_source                   string                                             off=0x3f0 attr=16 
#   field side                           string                                             off=0x3f8 attr=16 
#   field item_value                     string                                             off=0x400 attr=16 
#   field request_index                  string                                             off=0x408 attr=16 
#   field npc_response                   string                                             off=0x410 attr=16 
#   field offer_value_before             string                                             off=0x418 attr=16 
#   field offer_value_after              string                                             off=0x420 attr=16 
#   field counter_request_index          string                                             off=0x428 attr=16 
#   field accepted                       string                                             off=0x430 attr=16 
#   field your_value                     string                                             off=0x438 attr=16 
#   field npc_value                      string                                             off=0x440 attr=16 
#   field trade_percent                  string                                             off=0x448 attr=16 
#   field item_count_given               string                                             off=0x450 attr=16 
#   field item_count_received            string                                             off=0x458 attr=16 
#   field ad_result                      string                                             off=0x460 attr=16 
## OnboardingBegin(string tutorialId) -> void
---- DevTrack::OnboardingBegin 0x2c9c100
02c9c100: stp     x30, x23, [sp, #-0x30]!                    
02c9c104: stp     x22, x21, [sp, #0x10]                      
02c9c108: stp     x20, x19, [sp, #0x20]                      
02c9c10c: adrp    x22, #0x662f000                            
02c9c110: adrp    x23, #0x6263000                            
02c9c114: adrp    x20, #0x6263000                            
02c9c118: adrp    x21, #0x6265000                            
02c9c11c: ldr     x23, [x23, #0x938]                         T:type8922(k15)
02c9c120: ldrb    w8, [x22, #0xa55]                          
02c9c124: ldr     x20, [x20, #0x9a0]                         MS:System.Collections.Generic.Dictionary`2::.ctor
02c9c128: ldr     x21, [x21, #0xb38]                         T:DevTrack
02c9c12c: mov     x19, x0                                    
02c9c130: tbnz    w8, #0, #0x2c9c16c                         
02c9c134: adrp    x0, #0x6265000                             
02c9c138: ldr     x0, [x0, #0xb38]                           T:DevTrack
02c9c13c: bl      #0x2b70db0                                 fn_2b70db0
02c9c140: adrp    x0, #0x6265000                             
02c9c144: ldr     x0, [x0, #0xb40]                           MS:System.Collections.Generic.Dictionary`2::Add
02c9c148: bl      #0x2b70db0                                 fn_2b70db0
02c9c14c: adrp    x0, #0x6263000                             
02c9c150: ldr     x0, [x0, #0x9a0]                           MS:System.Collections.Generic.Dictionary`2::.ctor
02c9c154: bl      #0x2b70db0                                 fn_2b70db0
02c9c158: adrp    x0, #0x6263000                             
02c9c15c: ldr     x0, [x0, #0x938]                           T:type8922(k15)
02c9c160: bl      #0x2b70db0                                 fn_2b70db0
02c9c164: mov     w8, #1                                     
02c9c168: strb    w8, [x22, #0xa55]                          
02c9c16c: ldr     x0, [x23]                                  &2c5bbd4(=a9bd7bfdd503233f)
02c9c170: bl      #0x2b7104c                                 fn_2b7104c
02c9c174: ldr     x1, [x20]                                  &2c5bbd4(=a9bd7bfdd503233f)
02c9c178: mov     x20, x0                                    
02c9c17c: bl      #0x452b8a0                                 fn_452b8a0
02c9c180: ldr     x0, [x21]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9c184: ldr     w8, [x0, #0xe4]                            [62630e4]=0 f=0,0
02c9c188: cbnz    w8, #0x2c9c190                             
02c9c18c: bl      #0x2b70f30                                 fn_2b70f30
02c9c190: cbz     x20, #0x2c9c1dc                            
02c9c194: ldr     x8, [x21]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9c198: adrp    x9, #0x6265000                             
02c9c19c: mov     x0, x20                                    
02c9c1a0: ldr     x9, [x9, #0xb40]                           MS:System.Collections.Generic.Dictionary`2::Add
02c9c1a4: mov     x2, x19                                    
02c9c1a8: ldr     x8, [x8, #0xb8]                            
02c9c1ac: ldr     x3, [x9]                                   M:AdsManager::<OnApplicationPause>b__26_0
02c9c1b0: ldr     x1, [x8, #0xb8]                            
02c9c1b4: bl      #0x452c61c                                 fn_452c61c
02c9c1b8: ldr     x8, [x21]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9c1bc: mov     x1, x20                                    
02c9c1c0: mov     x2, xzr                                    
02c9c1c4: ldp     x20, x19, [sp, #0x20]                      
02c9c1c8: ldr     x8, [x8, #0xb8]                            
02c9c1cc: ldp     x22, x21, [sp, #0x10]                      
02c9c1d0: ldr     x0, [x8]                                   
02c9c1d4: ldp     x30, x23, [sp], #0x30                      
02c9c1d8: b       #0x2d77fe8                                 WejoyService.Tracking.TrackingManager::LogEvent
02c9c1dc: bl      #0x2b7105c                                 fn_2b7105c
## OnboardingStep(string tutorialId, string stepId, int stepIndex) -> void
---- DevTrack::OnboardingStep 0x2c9c1e0
02c9c1e0: sub     sp, sp, #0x50                              
02c9c1e4: stp     x30, x25, [sp, #0x10]                      
02c9c1e8: stp     x24, x23, [sp, #0x20]                      
02c9c1ec: stp     x22, x21, [sp, #0x30]                      
02c9c1f0: stp     x20, x19, [sp, #0x40]                      
02c9c1f4: adrp    x24, #0x662f000                            
02c9c1f8: adrp    x25, #0x6263000                            
02c9c1fc: adrp    x21, #0x6263000                            
02c9c200: adrp    x23, #0x6265000                            
02c9c204: ldr     x25, [x25, #0x938]                         T:type8922(k15)
02c9c208: ldrb    w8, [x24, #0xa56]                          
02c9c20c: ldr     x21, [x21, #0x9a0]                         MS:System.Collections.Generic.Dictionary`2::.ctor
02c9c210: ldr     x23, [x23, #0xb38]                         T:DevTrack
02c9c214: mov     w19, w2                                    
02c9c218: mov     x20, x1                                    
02c9c21c: mov     x22, x0                                    
02c9c220: tbnz    w8, #0, #0x2c9c25c                         
02c9c224: adrp    x0, #0x6265000                             
02c9c228: ldr     x0, [x0, #0xb38]                           T:DevTrack
02c9c22c: bl      #0x2b70db0                                 fn_2b70db0
02c9c230: adrp    x0, #0x6265000                             
02c9c234: ldr     x0, [x0, #0xb40]                           MS:System.Collections.Generic.Dictionary`2::Add
02c9c238: bl      #0x2b70db0                                 fn_2b70db0
02c9c23c: adrp    x0, #0x6263000                             
02c9c240: ldr     x0, [x0, #0x9a0]                           MS:System.Collections.Generic.Dictionary`2::.ctor
02c9c244: bl      #0x2b70db0                                 fn_2b70db0
02c9c248: adrp    x0, #0x6263000                             
02c9c24c: ldr     x0, [x0, #0x938]                           T:type8922(k15)
02c9c250: bl      #0x2b70db0                                 fn_2b70db0
02c9c254: mov     w8, #1                                     
02c9c258: strb    w8, [x24, #0xa56]                          
02c9c25c: ldr     x0, [x25]                                  &2c5bbd4(=a9bd7bfdd503233f)
02c9c260: bl      #0x2b7104c                                 fn_2b7104c
02c9c264: ldr     x1, [x21]                                  &2c5bbd4(=a9bd7bfdd503233f)
02c9c268: mov     x21, x0                                    
02c9c26c: bl      #0x452b8a0                                 fn_452b8a0
02c9c270: ldr     x0, [x23]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9c274: ldr     w8, [x0, #0xe4]                            [62630e4]=0 f=0,0
02c9c278: cbnz    w8, #0x2c9c280                             
02c9c27c: bl      #0x2b70f30                                 fn_2b70f30
02c9c280: cbz     x21, #0x2c9c32c                            
02c9c284: ldr     x8, [x23]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9c288: adrp    x24, #0x6265000                            
02c9c28c: mov     x0, x21                                    
02c9c290: ldr     x24, [x24, #0xb40]                         MS:System.Collections.Generic.Dictionary`2::Add
02c9c294: mov     x2, x22                                    
02c9c298: ldr     x8, [x8, #0xb8]                            
02c9c29c: ldr     x3, [x24]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9c2a0: ldr     x1, [x8, #0xb8]                            
02c9c2a4: bl      #0x452c61c                                 fn_452c61c
02c9c2a8: ldr     x8, [x23]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9c2ac: ldr     x3, [x24]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9c2b0: mov     x0, x21                                    
02c9c2b4: mov     x2, x20                                    
02c9c2b8: ldr     x8, [x8, #0xb8]                            
02c9c2bc: ldr     x1, [x8, #0xc0]                            
02c9c2c0: bl      #0x452c61c                                 fn_452c61c
02c9c2c4: ldr     x8, [x23]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9c2c8: adrp    x9, #0x6263000                             
02c9c2cc: add     x1, sp, #0xc                               
02c9c2d0: ldr     x8, [x8, #0xb8]                            
02c9c2d4: ldr     x9, [x9, #0x970]                           &6645c70(=0)
02c9c2d8: str     w19, [sp, #0xc]                            
02c9c2dc: ldr     x0, [x9, #0x48]                            &6263098(=0)
02c9c2e0: ldr     x20, [x8, #0xc8]                           
02c9c2e4: bl      #0x2b70f38                                 fn_2b70f38
02c9c2e8: ldr     x3, [x24]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9c2ec: mov     x2, x0                                     
02c9c2f0: mov     x0, x21                                    
02c9c2f4: mov     x1, x20                                    
02c9c2f8: bl      #0x452c61c                                 fn_452c61c
02c9c2fc: ldr     x8, [x23]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9c300: mov     x1, x21                                    
02c9c304: mov     x2, xzr                                    
02c9c308: ldr     x8, [x8, #0xb8]                            
02c9c30c: ldr     x0, [x8, #8]                               
02c9c310: bl      #0x2d77fe8                                 WejoyService.Tracking.TrackingManager::LogEvent
02c9c314: ldp     x20, x19, [sp, #0x40]                      
02c9c318: ldp     x22, x21, [sp, #0x30]                      
02c9c31c: ldp     x24, x23, [sp, #0x20]                      
02c9c320: ldp     x30, x25, [sp, #0x10]                      
02c9c324: add     sp, sp, #0x50                              
02c9c328: ret                                                
02c9c32c: bl      #0x2b7105c                                 fn_2b7105c
## OnboardingComplete(string tutorialId, float durationSec) -> void
---- DevTrack::OnboardingComplete 0x2c9c330
02c9c330: sub     sp, sp, #0x50                              
02c9c334: str     d8, [sp, #0x10]                            
02c9c338: stp     x30, x23, [sp, #0x20]                      
02c9c33c: stp     x22, x21, [sp, #0x30]                      
02c9c340: stp     x20, x19, [sp, #0x40]                      
02c9c344: fmov    s8, s0                                     
02c9c348: adrp    x22, #0x662f000                            
02c9c34c: adrp    x23, #0x6263000                            
02c9c350: adrp    x19, #0x6263000                            
02c9c354: adrp    x21, #0x6265000                            
02c9c358: ldr     x23, [x23, #0x938]                         T:type8922(k15)
02c9c35c: ldrb    w8, [x22, #0xa57]                          
02c9c360: ldr     x19, [x19, #0x9a0]                         MS:System.Collections.Generic.Dictionary`2::.ctor
02c9c364: ldr     x21, [x21, #0xb38]                         T:DevTrack
02c9c368: mov     x20, x0                                    
02c9c36c: tbnz    w8, #0, #0x2c9c3a8                         
02c9c370: adrp    x0, #0x6265000                             
02c9c374: ldr     x0, [x0, #0xb38]                           T:DevTrack
02c9c378: bl      #0x2b70db0                                 fn_2b70db0
02c9c37c: adrp    x0, #0x6265000                             
02c9c380: ldr     x0, [x0, #0xb40]                           MS:System.Collections.Generic.Dictionary`2::Add
02c9c384: bl      #0x2b70db0                                 fn_2b70db0
02c9c388: adrp    x0, #0x6263000                             
02c9c38c: ldr     x0, [x0, #0x9a0]                           MS:System.Collections.Generic.Dictionary`2::.ctor
02c9c390: bl      #0x2b70db0                                 fn_2b70db0
02c9c394: adrp    x0, #0x6263000                             
02c9c398: ldr     x0, [x0, #0x938]                           T:type8922(k15)
02c9c39c: bl      #0x2b70db0                                 fn_2b70db0
02c9c3a0: mov     w8, #1                                     
02c9c3a4: strb    w8, [x22, #0xa57]                          
02c9c3a8: ldr     x0, [x23]                                  &2c5bbd4(=a9bd7bfdd503233f)
02c9c3ac: bl      #0x2b7104c                                 fn_2b7104c
02c9c3b0: ldr     x1, [x19]                                  &2c5bbd4(=a9bd7bfdd503233f)
02c9c3b4: mov     x19, x0                                    
02c9c3b8: bl      #0x452b8a0                                 fn_452b8a0
02c9c3bc: ldr     x0, [x21]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9c3c0: ldr     w8, [x0, #0xe4]                            [62630e4]=0 f=0,0
02c9c3c4: cbnz    w8, #0x2c9c3cc                             
02c9c3c8: bl      #0x2b70f30                                 fn_2b70f30
02c9c3cc: cbz     x19, #0x2c9c4e0                            
02c9c3d0: ldr     x8, [x21]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9c3d4: adrp    x22, #0x6265000                            
02c9c3d8: mov     x0, x19                                    
02c9c3dc: ldr     x22, [x22, #0xb40]                         MS:System.Collections.Generic.Dictionary`2::Add
02c9c3e0: mov     x2, x20                                    
02c9c3e4: ldr     x8, [x8, #0xb8]                            
02c9c3e8: ldr     x3, [x22]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9c3ec: ldr     x1, [x8, #0xb8]                            
02c9c3f0: bl      #0x452c61c                                 fn_452c61c
02c9c3f4: fmov    s0, #10.00000000                           
02c9c3f8: ldr     x8, [x21]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9c3fc: add     x0, sp, #0x18                              
02c9c400: ldr     x8, [x8, #0xb8]                            
02c9c404: fmul    s8, s8, s0                                 
02c9c408: ldr     x20, [x8, #0xd0]                           
02c9c40c: fcvt    d0, s8                                     
02c9c410: bl      #0x5e902c0                                 fn_5e902c0
02c9c414: fcmp    s8, #0.0                                   
02c9c418: b.ge    #0x2c9c434                                 
02c9c41c: fmov    d1, #-0.50000000                           
02c9c420: fcmp    d0, d1                                     
02c9c424: b.ne    #0x2c9c460                                 
02c9c428: ldr     d0, [sp, #0x18]                            
02c9c42c: fmov    s2, #-1.00000000                           
02c9c430: b       #0x2c9c448                                 
02c9c434: fmov    d1, #0.50000000                            
02c9c438: fcmp    d0, d1                                     
02c9c43c: b.ne    #0x2c9c470                                 
02c9c440: ldr     d0, [sp, #0x18]                            
02c9c444: fmov    s2, #1.00000000                            
02c9c448: fcvt    s1, d0                                     
02c9c44c: fcvtzs  x8, d0                                     
02c9c450: fadd    s0, s1, s2                                 
02c9c454: tst     x8, #1                                     
02c9c458: fcsel   s0, s1, s0, eq                             
02c9c45c: b       #0x2c9c47c                                 
02c9c460: fmov    s0, #-0.50000000                           
02c9c464: fadd    s0, s8, s0                                 
02c9c468: frintp  s0, s0                                     
02c9c46c: b       #0x2c9c47c                                 
02c9c470: fmov    s0, #0.50000000                            
02c9c474: fadd    s0, s8, s0                                 
02c9c478: frintm  s0, s0                                     
02c9c47c: fmov    s1, #10.00000000                           
02c9c480: adrp    x8, #0x6263000                             
02c9c484: add     x1, sp, #0xc                               
02c9c488: ldr     x8, [x8, #0x970]                           &6645c70(=0)
02c9c48c: fdiv    s0, s0, s1                                 
02c9c490: ldr     x0, [x8, #0x78]                            &2c498b4(=d65f03c0d503245f)
02c9c494: str     s0, [sp, #0xc]                             
02c9c498: bl      #0x2b70f38                                 fn_2b70f38
02c9c49c: ldr     x3, [x22]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9c4a0: mov     x2, x0                                     
02c9c4a4: mov     x0, x19                                    
02c9c4a8: mov     x1, x20                                    
02c9c4ac: bl      #0x452c61c                                 fn_452c61c
02c9c4b0: ldr     x8, [x21]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9c4b4: mov     x1, x19                                    
02c9c4b8: mov     x2, xzr                                    
02c9c4bc: ldr     x8, [x8, #0xb8]                            &6263108(=0)
02c9c4c0: ldr     x0, [x8, #0x10]                            &2c498bc(=aa1f03e0d503245f)
02c9c4c4: bl      #0x2d77fe8                                 WejoyService.Tracking.TrackingManager::LogEvent
02c9c4c8: ldp     x20, x19, [sp, #0x40]                      
02c9c4cc: ldr     d8, [sp, #0x10]                            
02c9c4d0: ldp     x22, x21, [sp, #0x30]                      
02c9c4d4: ldp     x30, x23, [sp, #0x20]                      
02c9c4d8: add     sp, sp, #0x50                              
02c9c4dc: ret                                                
02c9c4e0: bl      #0x2b7105c                                 fn_2b7105c
## GameModeEnter(string gameMode) -> void
---- DevTrack::GameModeEnter 0x2c9c4e4
02c9c4e4: stp     x30, x23, [sp, #-0x30]!                    
02c9c4e8: stp     x22, x21, [sp, #0x10]                      
02c9c4ec: stp     x20, x19, [sp, #0x20]                      
02c9c4f0: adrp    x22, #0x662f000                            
02c9c4f4: adrp    x23, #0x6263000                            
02c9c4f8: adrp    x20, #0x6263000                            
02c9c4fc: adrp    x21, #0x6265000                            
02c9c500: ldr     x23, [x23, #0x938]                         T:type8922(k15)
02c9c504: ldrb    w8, [x22, #0xa58]                          
02c9c508: ldr     x20, [x20, #0x9a0]                         MS:System.Collections.Generic.Dictionary`2::.ctor
02c9c50c: ldr     x21, [x21, #0xb38]                         T:DevTrack
02c9c510: mov     x19, x0                                    
02c9c514: tbnz    w8, #0, #0x2c9c550                         
02c9c518: adrp    x0, #0x6265000                             
02c9c51c: ldr     x0, [x0, #0xb38]                           T:DevTrack
02c9c520: bl      #0x2b70db0                                 fn_2b70db0
02c9c524: adrp    x0, #0x6265000                             
02c9c528: ldr     x0, [x0, #0xb40]                           MS:System.Collections.Generic.Dictionary`2::Add
02c9c52c: bl      #0x2b70db0                                 fn_2b70db0
02c9c530: adrp    x0, #0x6263000                             
02c9c534: ldr     x0, [x0, #0x9a0]                           MS:System.Collections.Generic.Dictionary`2::.ctor
02c9c538: bl      #0x2b70db0                                 fn_2b70db0
02c9c53c: adrp    x0, #0x6263000                             
02c9c540: ldr     x0, [x0, #0x938]                           T:type8922(k15)
02c9c544: bl      #0x2b70db0                                 fn_2b70db0
02c9c548: mov     w8, #1                                     
02c9c54c: strb    w8, [x22, #0xa58]                          
02c9c550: ldr     x0, [x23]                                  &2c5bbd4(=a9bd7bfdd503233f)
02c9c554: bl      #0x2b7104c                                 fn_2b7104c
02c9c558: ldr     x1, [x20]                                  &2c5bbd4(=a9bd7bfdd503233f)
02c9c55c: mov     x20, x0                                    
02c9c560: bl      #0x452b8a0                                 fn_452b8a0
02c9c564: ldr     x0, [x21]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9c568: ldr     w8, [x0, #0xe4]                            [62630e4]=0 f=0,0
02c9c56c: cbnz    w8, #0x2c9c574                             
02c9c570: bl      #0x2b70f30                                 fn_2b70f30
02c9c574: cbz     x20, #0x2c9c5c0                            
02c9c578: ldr     x8, [x21]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9c57c: adrp    x9, #0x6265000                             
02c9c580: mov     x0, x20                                    
02c9c584: ldr     x9, [x9, #0xb40]                           MS:System.Collections.Generic.Dictionary`2::Add
02c9c588: mov     x2, x19                                    
02c9c58c: ldr     x8, [x8, #0xb8]                            
02c9c590: ldr     x3, [x9]                                   M:AdsManager::<OnApplicationPause>b__26_0
02c9c594: ldr     x1, [x8, #0xd8]                            
02c9c598: bl      #0x452c61c                                 fn_452c61c
02c9c59c: ldr     x8, [x21]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9c5a0: mov     x1, x20                                    
02c9c5a4: mov     x2, xzr                                    
02c9c5a8: ldp     x20, x19, [sp, #0x20]                      
02c9c5ac: ldr     x8, [x8, #0xb8]                            
02c9c5b0: ldp     x22, x21, [sp, #0x10]                      
02c9c5b4: ldr     x0, [x8, #0x18]                            
02c9c5b8: ldp     x30, x23, [sp], #0x30                      
02c9c5bc: b       #0x2d77fe8                                 WejoyService.Tracking.TrackingManager::LogEvent
02c9c5c0: bl      #0x2b7105c                                 fn_2b7105c
## GameModeStart(string gameMode, int flowIndex, string entryPoint) -> void
---- DevTrack::GameModeStart 0x2c9c5c4
02c9c5c4: sub     sp, sp, #0x50                              
02c9c5c8: stp     x30, x25, [sp, #0x10]                      
02c9c5cc: stp     x24, x23, [sp, #0x20]                      
02c9c5d0: stp     x22, x21, [sp, #0x30]                      
02c9c5d4: stp     x20, x19, [sp, #0x40]                      
02c9c5d8: adrp    x24, #0x662f000                            
02c9c5dc: adrp    x25, #0x6263000                            
02c9c5e0: adrp    x21, #0x6263000                            
02c9c5e4: adrp    x23, #0x6265000                            
02c9c5e8: ldr     x25, [x25, #0x938]                         T:type8922(k15)
02c9c5ec: ldrb    w8, [x24, #0xa59]                          
02c9c5f0: ldr     x21, [x21, #0x9a0]                         MS:System.Collections.Generic.Dictionary`2::.ctor
02c9c5f4: ldr     x23, [x23, #0xb38]                         T:DevTrack
02c9c5f8: mov     x19, x2                                    
02c9c5fc: mov     w20, w1                                    
02c9c600: mov     x22, x0                                    
02c9c604: tbnz    w8, #0, #0x2c9c640                         
02c9c608: adrp    x0, #0x6265000                             
02c9c60c: ldr     x0, [x0, #0xb38]                           T:DevTrack
02c9c610: bl      #0x2b70db0                                 fn_2b70db0
02c9c614: adrp    x0, #0x6265000                             
02c9c618: ldr     x0, [x0, #0xb40]                           MS:System.Collections.Generic.Dictionary`2::Add
02c9c61c: bl      #0x2b70db0                                 fn_2b70db0
02c9c620: adrp    x0, #0x6263000                             
02c9c624: ldr     x0, [x0, #0x9a0]                           MS:System.Collections.Generic.Dictionary`2::.ctor
02c9c628: bl      #0x2b70db0                                 fn_2b70db0
02c9c62c: adrp    x0, #0x6263000                             
02c9c630: ldr     x0, [x0, #0x938]                           T:type8922(k15)
02c9c634: bl      #0x2b70db0                                 fn_2b70db0
02c9c638: mov     w8, #1                                     
02c9c63c: strb    w8, [x24, #0xa59]                          
02c9c640: ldr     x0, [x25]                                  &2c5bbd4(=a9bd7bfdd503233f)
02c9c644: bl      #0x2b7104c                                 fn_2b7104c
02c9c648: ldr     x1, [x21]                                  &2c5bbd4(=a9bd7bfdd503233f)
02c9c64c: mov     x21, x0                                    
02c9c650: bl      #0x452b8a0                                 fn_452b8a0
02c9c654: ldr     x0, [x23]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9c658: ldr     w8, [x0, #0xe4]                            [62630e4]=0 f=0,0
02c9c65c: cbnz    w8, #0x2c9c664                             
02c9c660: bl      #0x2b70f30                                 fn_2b70f30
02c9c664: cbz     x21, #0x2c9c710                            
02c9c668: ldr     x8, [x23]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9c66c: adrp    x24, #0x6265000                            
02c9c670: mov     x0, x21                                    
02c9c674: ldr     x24, [x24, #0xb40]                         MS:System.Collections.Generic.Dictionary`2::Add
02c9c678: mov     x2, x22                                    
02c9c67c: ldr     x8, [x8, #0xb8]                            
02c9c680: ldr     x3, [x24]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9c684: ldr     x1, [x8, #0xd8]                            
02c9c688: bl      #0x452c61c                                 fn_452c61c
02c9c68c: ldr     x8, [x23]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9c690: adrp    x9, #0x6263000                             
02c9c694: add     x1, sp, #0xc                               
02c9c698: ldr     x8, [x8, #0xb8]                            
02c9c69c: ldr     x9, [x9, #0x970]                           &6645c70(=0)
02c9c6a0: str     w20, [sp, #0xc]                            
02c9c6a4: ldr     x0, [x9, #0x48]                            &6263098(=0)
02c9c6a8: ldr     x22, [x8, #0xe0]                           
02c9c6ac: bl      #0x2b70f38                                 fn_2b70f38
02c9c6b0: ldr     x3, [x24]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9c6b4: mov     x2, x0                                     
02c9c6b8: mov     x0, x21                                    
02c9c6bc: mov     x1, x22                                    
02c9c6c0: bl      #0x452c61c                                 fn_452c61c
02c9c6c4: ldr     x8, [x23]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9c6c8: ldr     x3, [x24]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9c6cc: mov     x0, x21                                    
02c9c6d0: mov     x2, x19                                    
02c9c6d4: ldr     x8, [x8, #0xb8]                            
02c9c6d8: ldr     x1, [x8, #0x1f0]                           
02c9c6dc: bl      #0x452c61c                                 fn_452c61c
02c9c6e0: ldr     x8, [x23]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9c6e4: mov     x1, x21                                    
02c9c6e8: mov     x2, xzr                                    
02c9c6ec: ldr     x8, [x8, #0xb8]                            
02c9c6f0: ldr     x0, [x8, #0x20]                            
02c9c6f4: bl      #0x2d77fe8                                 WejoyService.Tracking.TrackingManager::LogEvent
02c9c6f8: ldp     x20, x19, [sp, #0x40]                      
02c9c6fc: ldp     x22, x21, [sp, #0x30]                      
02c9c700: ldp     x24, x23, [sp, #0x20]                      
02c9c704: ldp     x30, x25, [sp, #0x10]                      
02c9c708: add     sp, sp, #0x50                              
02c9c70c: ret                                                
02c9c710: bl      #0x2b7105c                                 fn_2b7105c
## GameModeStepEnter(string gameMode, int flowIndex, string stepId, int stepIndex) -> void
---- DevTrack::GameModeStepEnter 0x2c9c714
02c9c714: str     x30, [sp, #-0x50]!                         
02c9c718: stp     x26, x25, [sp, #0x10]                      
02c9c71c: stp     x24, x23, [sp, #0x20]                      
02c9c720: stp     x22, x21, [sp, #0x30]                      
02c9c724: stp     x20, x19, [sp, #0x40]                      
02c9c728: adrp    x25, #0x662f000                            
02c9c72c: adrp    x26, #0x6263000                            
02c9c730: adrp    x21, #0x6263000                            
02c9c734: adrp    x24, #0x6265000                            
02c9c738: ldr     x26, [x26, #0x938]                         T:type8922(k15)
02c9c73c: ldrb    w8, [x25, #0xa5a]                          
02c9c740: ldr     x21, [x21, #0x9a0]                         MS:System.Collections.Generic.Dictionary`2::.ctor
02c9c744: ldr     x24, [x24, #0xb38]                         T:DevTrack
02c9c748: mov     w19, w3                                    
02c9c74c: mov     x20, x2                                    
02c9c750: mov     w22, w1                                    
02c9c754: mov     x23, x0                                    
02c9c758: tbnz    w8, #0, #0x2c9c794                         
02c9c75c: adrp    x0, #0x6265000                             
02c9c760: ldr     x0, [x0, #0xb38]                           T:DevTrack
02c9c764: bl      #0x2b70db0                                 fn_2b70db0
02c9c768: adrp    x0, #0x6265000                             
02c9c76c: ldr     x0, [x0, #0xb40]                           MS:System.Collections.Generic.Dictionary`2::Add
02c9c770: bl      #0x2b70db0                                 fn_2b70db0
02c9c774: adrp    x0, #0x6263000                             
02c9c778: ldr     x0, [x0, #0x9a0]                           MS:System.Collections.Generic.Dictionary`2::.ctor
02c9c77c: bl      #0x2b70db0                                 fn_2b70db0
02c9c780: adrp    x0, #0x6263000                             
02c9c784: ldr     x0, [x0, #0x938]                           T:type8922(k15)
02c9c788: bl      #0x2b70db0                                 fn_2b70db0
02c9c78c: mov     w8, #1                                     
02c9c790: strb    w8, [x25, #0xa5a]                          
02c9c794: ldr     x0, [x26]                                  &2c5bbd4(=a9bd7bfdd503233f)
02c9c798: bl      #0x2b7104c                                 fn_2b7104c
02c9c79c: ldr     x1, [x21]                                  &2c5bbd4(=a9bd7bfdd503233f)
02c9c7a0: mov     x21, x0                                    
02c9c7a4: bl      #0x452b8a0                                 fn_452b8a0
02c9c7a8: ldr     x0, [x24]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9c7ac: ldr     w8, [x0, #0xe4]                            [62630e4]=0 f=0,0
02c9c7b0: cbnz    w8, #0x2c9c7b8                             
02c9c7b4: bl      #0x2b70f30                                 fn_2b70f30
02c9c7b8: cbz     x21, #0x2c9c894                            
02c9c7bc: ldr     x8, [x24]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9c7c0: adrp    x25, #0x6265000                            
02c9c7c4: mov     x0, x21                                    
02c9c7c8: ldr     x25, [x25, #0xb40]                         MS:System.Collections.Generic.Dictionary`2::Add
02c9c7cc: mov     x2, x23                                    
02c9c7d0: ldr     x8, [x8, #0xb8]                            
02c9c7d4: ldr     x3, [x25]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9c7d8: ldr     x1, [x8, #0xd8]                            
02c9c7dc: bl      #0x452c61c                                 fn_452c61c
02c9c7e0: ldr     x8, [x24]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9c7e4: adrp    x26, #0x6263000                            
02c9c7e8: add     x1, sp, #0xc                               
02c9c7ec: ldr     x8, [x8, #0xb8]                            
02c9c7f0: ldr     x26, [x26, #0x970]                         &6645c70(=0)
02c9c7f4: str     w22, [sp, #0xc]                            
02c9c7f8: ldr     x0, [x26, #0x48]                           &6263098(=0)
02c9c7fc: ldr     x23, [x8, #0xe0]                           
02c9c800: bl      #0x2b70f38                                 fn_2b70f38
02c9c804: ldr     x3, [x25]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9c808: mov     x2, x0                                     
02c9c80c: mov     x0, x21                                    
02c9c810: mov     x1, x23                                    
02c9c814: bl      #0x452c61c                                 fn_452c61c
02c9c818: ldr     x8, [x24]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9c81c: ldr     x3, [x25]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9c820: mov     x0, x21                                    
02c9c824: mov     x2, x20                                    
02c9c828: ldr     x8, [x8, #0xb8]                            
02c9c82c: ldr     x1, [x8, #0xc0]                            
02c9c830: bl      #0x452c61c                                 fn_452c61c
02c9c834: ldr     x8, [x24]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9c838: ldr     x0, [x26, #0x48]                           &6263098(=0)
02c9c83c: add     x1, sp, #8                                 
02c9c840: str     w19, [sp, #8]                              
02c9c844: ldr     x8, [x8, #0xb8]                            
02c9c848: ldr     x20, [x8, #0xc8]                           
02c9c84c: bl      #0x2b70f38                                 fn_2b70f38
02c9c850: ldr     x3, [x25]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9c854: mov     x2, x0                                     
02c9c858: mov     x0, x21                                    
02c9c85c: mov     x1, x20                                    
02c9c860: bl      #0x452c61c                                 fn_452c61c
02c9c864: ldr     x8, [x24]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9c868: mov     x1, x21                                    
02c9c86c: mov     x2, xzr                                    
02c9c870: ldr     x8, [x8, #0xb8]                            
02c9c874: ldr     x0, [x8, #0x28]                            
02c9c878: bl      #0x2d77fe8                                 WejoyService.Tracking.TrackingManager::LogEvent
02c9c87c: ldp     x20, x19, [sp, #0x40]                      
02c9c880: ldp     x22, x21, [sp, #0x30]                      
02c9c884: ldp     x24, x23, [sp, #0x20]                      
02c9c888: ldp     x26, x25, [sp, #0x10]                      
02c9c88c: ldr     x30, [sp], #0x50                           
02c9c890: ret                                                
02c9c894: bl      #0x2b7105c                                 fn_2b7105c
## GameModeStepComplete(string gameMode, int flowIndex, string stepId, int stepIndex, float stepDurationSec) -> void
---- DevTrack::GameModeStepComplete 0x2c9c898
02c9c898: sub     sp, sp, #0x60                              
02c9c89c: str     d8, [sp, #0x10]                            
02c9c8a0: str     x30, [sp, #0x18]                           
02c9c8a4: stp     x26, x25, [sp, #0x20]                      
02c9c8a8: stp     x24, x23, [sp, #0x30]                      
02c9c8ac: stp     x22, x21, [sp, #0x40]                      
02c9c8b0: stp     x20, x19, [sp, #0x50]                      
02c9c8b4: fmov    s8, s0                                     
02c9c8b8: adrp    x25, #0x662f000                            
02c9c8bc: adrp    x26, #0x6263000                            
02c9c8c0: adrp    x19, #0x6263000                            
02c9c8c4: adrp    x24, #0x6265000                            
02c9c8c8: ldr     x26, [x26, #0x938]                         T:type8922(k15)
02c9c8cc: ldrb    w8, [x25, #0xa5b]                          
02c9c8d0: ldr     x19, [x19, #0x9a0]                         MS:System.Collections.Generic.Dictionary`2::.ctor
02c9c8d4: ldr     x24, [x24, #0xb38]                         T:DevTrack
02c9c8d8: mov     w20, w3                                    
02c9c8dc: mov     x21, x2                                    
02c9c8e0: mov     w22, w1                                    
02c9c8e4: mov     x23, x0                                    
02c9c8e8: tbnz    w8, #0, #0x2c9c924                         
02c9c8ec: adrp    x0, #0x6265000                             
02c9c8f0: ldr     x0, [x0, #0xb38]                           T:DevTrack
02c9c8f4: bl      #0x2b70db0                                 fn_2b70db0
02c9c8f8: adrp    x0, #0x6265000                             
02c9c8fc: ldr     x0, [x0, #0xb40]                           MS:System.Collections.Generic.Dictionary`2::Add
02c9c900: bl      #0x2b70db0                                 fn_2b70db0
02c9c904: adrp    x0, #0x6263000                             
02c9c908: ldr     x0, [x0, #0x9a0]                           MS:System.Collections.Generic.Dictionary`2::.ctor
02c9c90c: bl      #0x2b70db0                                 fn_2b70db0
02c9c910: adrp    x0, #0x6263000                             
02c9c914: ldr     x0, [x0, #0x938]                           T:type8922(k15)
02c9c918: bl      #0x2b70db0                                 fn_2b70db0
02c9c91c: mov     w8, #1                                     
02c9c920: strb    w8, [x25, #0xa5b]                          
02c9c924: ldr     x0, [x26]                                  &2c5bbd4(=a9bd7bfdd503233f)
02c9c928: bl      #0x2b7104c                                 fn_2b7104c
02c9c92c: ldr     x1, [x19]                                  &2c5bbd4(=a9bd7bfdd503233f)
02c9c930: mov     x19, x0                                    
02c9c934: bl      #0x452b8a0                                 fn_452b8a0
02c9c938: ldr     x0, [x24]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9c93c: ldr     w8, [x0, #0xe4]                            [62630e4]=0 f=0,0
02c9c940: cbnz    w8, #0x2c9c948                             
02c9c944: bl      #0x2b70f30                                 fn_2b70f30
02c9c948: cbz     x19, #0x2c9cae0                            
02c9c94c: ldr     x8, [x24]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9c950: adrp    x25, #0x6265000                            
02c9c954: mov     x0, x19                                    
02c9c958: ldr     x25, [x25, #0xb40]                         MS:System.Collections.Generic.Dictionary`2::Add
02c9c95c: mov     x2, x23                                    
02c9c960: ldr     x8, [x8, #0xb8]                            
02c9c964: ldr     x3, [x25]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9c968: ldr     x1, [x8, #0xd8]                            
02c9c96c: bl      #0x452c61c                                 fn_452c61c
02c9c970: ldr     x8, [x24]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9c974: adrp    x26, #0x6263000                            
02c9c978: add     x1, sp, #4                                 
02c9c97c: ldr     x8, [x8, #0xb8]                            
02c9c980: ldr     x26, [x26, #0x970]                         &6645c70(=0)
02c9c984: str     w22, [sp, #4]                              
02c9c988: ldr     x0, [x26, #0x48]                           &6263098(=0)
02c9c98c: ldr     x23, [x8, #0xe0]                           
02c9c990: bl      #0x2b70f38                                 fn_2b70f38
02c9c994: ldr     x3, [x25]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9c998: mov     x2, x0                                     
02c9c99c: mov     x0, x19                                    
02c9c9a0: mov     x1, x23                                    
02c9c9a4: bl      #0x452c61c                                 fn_452c61c
02c9c9a8: ldr     x8, [x24]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9c9ac: ldr     x3, [x25]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9c9b0: mov     x0, x19                                    
02c9c9b4: mov     x2, x21                                    
02c9c9b8: ldr     x8, [x8, #0xb8]                            
02c9c9bc: ldr     x1, [x8, #0xc0]                            
02c9c9c0: bl      #0x452c61c                                 fn_452c61c
02c9c9c4: ldr     x8, [x24]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9c9c8: ldr     x0, [x26, #0x48]                           &6263098(=0)
02c9c9cc: mov     x1, sp                                     
02c9c9d0: str     w20, [sp]                                  
02c9c9d4: ldr     x8, [x8, #0xb8]                            
02c9c9d8: ldr     x21, [x8, #0xc8]                           
02c9c9dc: bl      #0x2b70f38                                 fn_2b70f38
02c9c9e0: ldr     x3, [x25]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9c9e4: mov     x2, x0                                     
02c9c9e8: mov     x0, x19                                    
02c9c9ec: mov     x1, x21                                    
02c9c9f0: bl      #0x452c61c                                 fn_452c61c
02c9c9f4: fmov    s0, #10.00000000                           
02c9c9f8: ldr     x8, [x24]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9c9fc: add     x0, sp, #8                                 
02c9ca00: ldr     x8, [x8, #0xb8]                            
02c9ca04: fmul    s8, s8, s0                                 
02c9ca08: ldr     x20, [x8, #0xe8]                           
02c9ca0c: fcvt    d0, s8                                     
02c9ca10: bl      #0x5e902c0                                 fn_5e902c0
02c9ca14: fcmp    s8, #0.0                                   
02c9ca18: b.ge    #0x2c9ca34                                 
02c9ca1c: fmov    d1, #-0.50000000                           
02c9ca20: fcmp    d0, d1                                     
02c9ca24: b.ne    #0x2c9ca60                                 
02c9ca28: ldr     d0, [sp, #8]                               
02c9ca2c: fmov    s2, #-1.00000000                           
02c9ca30: b       #0x2c9ca48                                 
02c9ca34: fmov    d1, #0.50000000                            
02c9ca38: fcmp    d0, d1                                     
02c9ca3c: b.ne    #0x2c9ca70                                 
02c9ca40: ldr     d0, [sp, #8]                               
02c9ca44: fmov    s2, #1.00000000                            
02c9ca48: fcvt    s1, d0                                     
02c9ca4c: fcvtzs  x8, d0                                     
02c9ca50: fadd    s0, s1, s2                                 
02c9ca54: tst     x8, #1                                     
02c9ca58: fcsel   s0, s1, s0, eq                             
02c9ca5c: b       #0x2c9ca7c                                 
02c9ca60: fmov    s0, #-0.50000000                           
02c9ca64: fadd    s0, s8, s0                                 
02c9ca68: frintp  s0, s0                                     
02c9ca6c: b       #0x2c9ca7c                                 
02c9ca70: fmov    s0, #0.50000000                            
02c9ca74: fadd    s0, s8, s0                                 
02c9ca78: frintm  s0, s0                                     
02c9ca7c: fmov    s1, #10.00000000                           
02c9ca80: ldr     x0, [x26, #0x78]                           &2c498b4(=d65f03c0d503245f)
02c9ca84: add     x1, sp, #8                                 
02c9ca88: fdiv    s0, s0, s1                                 
02c9ca8c: str     s0, [sp, #8]                               
02c9ca90: bl      #0x2b70f38                                 fn_2b70f38
02c9ca94: ldr     x3, [x25]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9ca98: mov     x2, x0                                     
02c9ca9c: mov     x0, x19                                    
02c9caa0: mov     x1, x20                                    
02c9caa4: bl      #0x452c61c                                 fn_452c61c
02c9caa8: ldr     x8, [x24]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9caac: mov     x1, x19                                    
02c9cab0: mov     x2, xzr                                    
02c9cab4: ldr     x8, [x8, #0xb8]                            
02c9cab8: ldr     x0, [x8, #0x30]                            
02c9cabc: bl      #0x2d77fe8                                 WejoyService.Tracking.TrackingManager::LogEvent
02c9cac0: ldp     x20, x19, [sp, #0x50]                      
02c9cac4: ldr     x30, [sp, #0x18]                           
02c9cac8: ldp     x22, x21, [sp, #0x40]                      
02c9cacc: ldr     d8, [sp, #0x10]                            
02c9cad0: ldp     x24, x23, [sp, #0x30]                      
02c9cad4: ldp     x26, x25, [sp, #0x20]                      
02c9cad8: add     sp, sp, #0x60                              
02c9cadc: ret                                                
02c9cae0: bl      #0x2b7105c                                 fn_2b7105c
## GameModeExit(string gameMode, int flowIndex, string lastStepId, string exitType, float elapsedTime) -> void
---- DevTrack::GameModeExit 0x2c9cae4
02c9cae4: sub     sp, sp, #0x60                              
02c9cae8: str     d8, [sp, #0x10]                            
02c9caec: str     x30, [sp, #0x18]                           
02c9caf0: stp     x26, x25, [sp, #0x20]                      
02c9caf4: stp     x24, x23, [sp, #0x30]                      
02c9caf8: stp     x22, x21, [sp, #0x40]                      
02c9cafc: stp     x20, x19, [sp, #0x50]                      
02c9cb00: fmov    s8, s0                                     
02c9cb04: adrp    x25, #0x662f000                            
02c9cb08: adrp    x26, #0x6263000                            
02c9cb0c: adrp    x19, #0x6263000                            
02c9cb10: adrp    x24, #0x6265000                            
02c9cb14: ldr     x26, [x26, #0x938]                         T:type8922(k15)
02c9cb18: ldrb    w8, [x25, #0xa5c]                          
02c9cb1c: ldr     x19, [x19, #0x9a0]                         MS:System.Collections.Generic.Dictionary`2::.ctor
02c9cb20: ldr     x24, [x24, #0xb38]                         T:DevTrack
02c9cb24: mov     x20, x3                                    
02c9cb28: mov     x21, x2                                    
02c9cb2c: mov     w22, w1                                    
02c9cb30: mov     x23, x0                                    
02c9cb34: tbnz    w8, #0, #0x2c9cb70                         
02c9cb38: adrp    x0, #0x6265000                             
02c9cb3c: ldr     x0, [x0, #0xb38]                           T:DevTrack
02c9cb40: bl      #0x2b70db0                                 fn_2b70db0
02c9cb44: adrp    x0, #0x6265000                             
02c9cb48: ldr     x0, [x0, #0xb40]                           MS:System.Collections.Generic.Dictionary`2::Add
02c9cb4c: bl      #0x2b70db0                                 fn_2b70db0
02c9cb50: adrp    x0, #0x6263000                             
02c9cb54: ldr     x0, [x0, #0x9a0]                           MS:System.Collections.Generic.Dictionary`2::.ctor
02c9cb58: bl      #0x2b70db0                                 fn_2b70db0
02c9cb5c: adrp    x0, #0x6263000                             
02c9cb60: ldr     x0, [x0, #0x938]                           T:type8922(k15)
02c9cb64: bl      #0x2b70db0                                 fn_2b70db0
02c9cb68: mov     w8, #1                                     
02c9cb6c: strb    w8, [x25, #0xa5c]                          
02c9cb70: ldr     x0, [x26]                                  &2c5bbd4(=a9bd7bfdd503233f)
02c9cb74: bl      #0x2b7104c                                 fn_2b7104c
02c9cb78: ldr     x1, [x19]                                  &2c5bbd4(=a9bd7bfdd503233f)
02c9cb7c: mov     x19, x0                                    
02c9cb80: bl      #0x452b8a0                                 fn_452b8a0
02c9cb84: ldr     x0, [x24]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9cb88: ldr     w8, [x0, #0xe4]                            [62630e4]=0 f=0,0
02c9cb8c: cbnz    w8, #0x2c9cb94                             
02c9cb90: bl      #0x2b70f30                                 fn_2b70f30
02c9cb94: cbz     x19, #0x2c9cd18                            
02c9cb98: ldr     x8, [x24]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9cb9c: adrp    x25, #0x6265000                            
02c9cba0: mov     x0, x19                                    
02c9cba4: ldr     x25, [x25, #0xb40]                         MS:System.Collections.Generic.Dictionary`2::Add
02c9cba8: mov     x2, x23                                    
02c9cbac: ldr     x8, [x8, #0xb8]                            
02c9cbb0: ldr     x3, [x25]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9cbb4: ldr     x1, [x8, #0xd8]                            
02c9cbb8: bl      #0x452c61c                                 fn_452c61c
02c9cbbc: ldr     x8, [x24]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9cbc0: adrp    x26, #0x6263000                            
02c9cbc4: add     x1, sp, #4                                 
02c9cbc8: ldr     x8, [x8, #0xb8]                            
02c9cbcc: ldr     x26, [x26, #0x970]                         &6645c70(=0)
02c9cbd0: str     w22, [sp, #4]                              
02c9cbd4: ldr     x0, [x26, #0x48]                           &6263098(=0)
02c9cbd8: ldr     x23, [x8, #0xe0]                           
02c9cbdc: bl      #0x2b70f38                                 fn_2b70f38
02c9cbe0: ldr     x3, [x25]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9cbe4: mov     x2, x0                                     
02c9cbe8: mov     x0, x19                                    
02c9cbec: mov     x1, x23                                    
02c9cbf0: bl      #0x452c61c                                 fn_452c61c
02c9cbf4: ldr     x8, [x24]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9cbf8: ldr     x3, [x25]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9cbfc: mov     x0, x19                                    
02c9cc00: mov     x2, x21                                    
02c9cc04: ldr     x8, [x8, #0xb8]                            
02c9cc08: ldr     x1, [x8, #0xf0]                            
02c9cc0c: bl      #0x452c61c                                 fn_452c61c
02c9cc10: ldr     x8, [x24]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9cc14: ldr     x3, [x25]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9cc18: mov     x0, x19                                    
02c9cc1c: mov     x2, x20                                    
02c9cc20: ldr     x8, [x8, #0xb8]                            
02c9cc24: ldr     x1, [x8, #0xf8]                            
02c9cc28: bl      #0x452c61c                                 fn_452c61c
02c9cc2c: fmov    s0, #10.00000000                           
02c9cc30: ldr     x8, [x24]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9cc34: add     x0, sp, #8                                 
02c9cc38: ldr     x8, [x8, #0xb8]                            
02c9cc3c: fmul    s8, s8, s0                                 
02c9cc40: ldr     x20, [x8, #0x100]                          
02c9cc44: fcvt    d0, s8                                     
02c9cc48: bl      #0x5e902c0                                 fn_5e902c0
02c9cc4c: fcmp    s8, #0.0                                   
02c9cc50: b.ge    #0x2c9cc6c                                 
02c9cc54: fmov    d1, #-0.50000000                           
02c9cc58: fcmp    d0, d1                                     
02c9cc5c: b.ne    #0x2c9cc98                                 
02c9cc60: ldr     d0, [sp, #8]                               
02c9cc64: fmov    s2, #-1.00000000                           
02c9cc68: b       #0x2c9cc80                                 
02c9cc6c: fmov    d1, #0.50000000                            
02c9cc70: fcmp    d0, d1                                     
02c9cc74: b.ne    #0x2c9cca8                                 
02c9cc78: ldr     d0, [sp, #8]                               
02c9cc7c: fmov    s2, #1.00000000                            
02c9cc80: fcvt    s1, d0                                     
02c9cc84: fcvtzs  x8, d0                                     
02c9cc88: fadd    s0, s1, s2                                 
02c9cc8c: tst     x8, #1                                     
02c9cc90: fcsel   s0, s1, s0, eq                             
02c9cc94: b       #0x2c9ccb4                                 
02c9cc98: fmov    s0, #-0.50000000                           
02c9cc9c: fadd    s0, s8, s0                                 
02c9cca0: frintp  s0, s0                                     
02c9cca4: b       #0x2c9ccb4                                 
02c9cca8: fmov    s0, #0.50000000                            
02c9ccac: fadd    s0, s8, s0                                 
02c9ccb0: frintm  s0, s0                                     
02c9ccb4: fmov    s1, #10.00000000                           
02c9ccb8: ldr     x0, [x26, #0x78]                           &2c498b4(=d65f03c0d503245f)
02c9ccbc: add     x1, sp, #8                                 
02c9ccc0: fdiv    s0, s0, s1                                 
02c9ccc4: str     s0, [sp, #8]                               
02c9ccc8: bl      #0x2b70f38                                 fn_2b70f38
02c9cccc: ldr     x3, [x25]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9ccd0: mov     x2, x0                                     
02c9ccd4: mov     x0, x19                                    
02c9ccd8: mov     x1, x20                                    
02c9ccdc: bl      #0x452c61c                                 fn_452c61c
02c9cce0: ldr     x8, [x24]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9cce4: mov     x1, x19                                    
02c9cce8: mov     x2, xzr                                    
02c9ccec: ldr     x8, [x8, #0xb8]                            
02c9ccf0: ldr     x0, [x8, #0x38]                            
02c9ccf4: bl      #0x2d77fe8                                 WejoyService.Tracking.TrackingManager::LogEvent
02c9ccf8: ldp     x20, x19, [sp, #0x50]                      
02c9ccfc: ldr     x30, [sp, #0x18]                           
02c9cd00: ldp     x22, x21, [sp, #0x40]                      
02c9cd04: ldr     d8, [sp, #0x10]                            
02c9cd08: ldp     x24, x23, [sp, #0x30]                      
02c9cd0c: ldp     x26, x25, [sp, #0x20]                      
02c9cd10: add     sp, sp, #0x60                              
02c9cd14: ret                                                
02c9cd18: bl      #0x2b7105c                                 fn_2b7105c
## GameModeComplete(string gameMode, int flowIndex, float totalDurationSec) -> void
---- DevTrack::GameModeComplete 0x2c9cd1c
02c9cd1c: sub     sp, sp, #0x50                              
02c9cd20: str     d8, [sp, #0x10]                            
02c9cd24: str     x30, [sp, #0x18]                           
02c9cd28: stp     x24, x23, [sp, #0x20]                      
02c9cd2c: stp     x22, x21, [sp, #0x30]                      
02c9cd30: stp     x20, x19, [sp, #0x40]                      
02c9cd34: fmov    s8, s0                                     
02c9cd38: adrp    x23, #0x662f000                            
02c9cd3c: adrp    x24, #0x6263000                            
02c9cd40: adrp    x19, #0x6263000                            
02c9cd44: adrp    x22, #0x6265000                            
02c9cd48: ldr     x24, [x24, #0x938]                         T:type8922(k15)
02c9cd4c: ldrb    w8, [x23, #0xa5d]                          
02c9cd50: ldr     x19, [x19, #0x9a0]                         MS:System.Collections.Generic.Dictionary`2::.ctor
02c9cd54: ldr     x22, [x22, #0xb38]                         T:DevTrack
02c9cd58: mov     w20, w1                                    
02c9cd5c: mov     x21, x0                                    
02c9cd60: tbnz    w8, #0, #0x2c9cd9c                         
02c9cd64: adrp    x0, #0x6265000                             
02c9cd68: ldr     x0, [x0, #0xb38]                           T:DevTrack
02c9cd6c: bl      #0x2b70db0                                 fn_2b70db0
02c9cd70: adrp    x0, #0x6265000                             
02c9cd74: ldr     x0, [x0, #0xb40]                           MS:System.Collections.Generic.Dictionary`2::Add
02c9cd78: bl      #0x2b70db0                                 fn_2b70db0
02c9cd7c: adrp    x0, #0x6263000                             
02c9cd80: ldr     x0, [x0, #0x9a0]                           MS:System.Collections.Generic.Dictionary`2::.ctor
02c9cd84: bl      #0x2b70db0                                 fn_2b70db0
02c9cd88: adrp    x0, #0x6263000                             
02c9cd8c: ldr     x0, [x0, #0x938]                           T:type8922(k15)
02c9cd90: bl      #0x2b70db0                                 fn_2b70db0
02c9cd94: mov     w8, #1                                     
02c9cd98: strb    w8, [x23, #0xa5d]                          
02c9cd9c: ldr     x0, [x24]                                  &2c5bbd4(=a9bd7bfdd503233f)
02c9cda0: bl      #0x2b7104c                                 fn_2b7104c
02c9cda4: ldr     x1, [x19]                                  &2c5bbd4(=a9bd7bfdd503233f)
02c9cda8: mov     x19, x0                                    
02c9cdac: bl      #0x452b8a0                                 fn_452b8a0
02c9cdb0: ldr     x0, [x22]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9cdb4: ldr     w8, [x0, #0xe4]                            [62630e4]=0 f=0,0
02c9cdb8: cbnz    w8, #0x2c9cdc0                             
02c9cdbc: bl      #0x2b70f30                                 fn_2b70f30
02c9cdc0: cbz     x19, #0x2c9cf08                            
02c9cdc4: ldr     x8, [x22]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9cdc8: adrp    x23, #0x6265000                            
02c9cdcc: mov     x0, x19                                    
02c9cdd0: ldr     x23, [x23, #0xb40]                         MS:System.Collections.Generic.Dictionary`2::Add
02c9cdd4: mov     x2, x21                                    
02c9cdd8: ldr     x8, [x8, #0xb8]                            
02c9cddc: ldr     x3, [x23]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9cde0: ldr     x1, [x8, #0xd8]                            
02c9cde4: bl      #0x452c61c                                 fn_452c61c
02c9cde8: ldr     x8, [x22]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9cdec: adrp    x24, #0x6263000                            
02c9cdf0: add     x1, sp, #4                                 
02c9cdf4: ldr     x8, [x8, #0xb8]                            
02c9cdf8: ldr     x24, [x24, #0x970]                         &6645c70(=0)
02c9cdfc: str     w20, [sp, #4]                              
02c9ce00: ldr     x0, [x24, #0x48]                           &6263098(=0)
02c9ce04: ldr     x21, [x8, #0xe0]                           
02c9ce08: bl      #0x2b70f38                                 fn_2b70f38
02c9ce0c: ldr     x3, [x23]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9ce10: mov     x2, x0                                     
02c9ce14: mov     x0, x19                                    
02c9ce18: mov     x1, x21                                    
02c9ce1c: bl      #0x452c61c                                 fn_452c61c
02c9ce20: fmov    s0, #10.00000000                           
02c9ce24: ldr     x8, [x22]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9ce28: add     x0, sp, #8                                 
02c9ce2c: ldr     x8, [x8, #0xb8]                            
02c9ce30: fmul    s8, s8, s0                                 
02c9ce34: ldr     x20, [x8, #0x108]                          
02c9ce38: fcvt    d0, s8                                     
02c9ce3c: bl      #0x5e902c0                                 fn_5e902c0
02c9ce40: fcmp    s8, #0.0                                   
02c9ce44: b.ge    #0x2c9ce60                                 
02c9ce48: fmov    d1, #-0.50000000                           
02c9ce4c: fcmp    d0, d1                                     
02c9ce50: b.ne    #0x2c9ce8c                                 
02c9ce54: ldr     d0, [sp, #8]                               
02c9ce58: fmov    s2, #-1.00000000                           
02c9ce5c: b       #0x2c9ce74                                 
02c9ce60: fmov    d1, #0.50000000                            
02c9ce64: fcmp    d0, d1                                     
02c9ce68: b.ne    #0x2c9ce9c                                 
02c9ce6c: ldr     d0, [sp, #8]                               
02c9ce70: fmov    s2, #1.00000000                            
02c9ce74: fcvt    s1, d0                                     
02c9ce78: fcvtzs  x8, d0                                     
02c9ce7c: fadd    s0, s1, s2                                 
02c9ce80: tst     x8, #1                                     
02c9ce84: fcsel   s0, s1, s0, eq                             
02c9ce88: b       #0x2c9cea8                                 
02c9ce8c: fmov    s0, #-0.50000000                           
02c9ce90: fadd    s0, s8, s0                                 
02c9ce94: frintp  s0, s0                                     
02c9ce98: b       #0x2c9cea8                                 
02c9ce9c: fmov    s0, #0.50000000                            
02c9cea0: fadd    s0, s8, s0                                 
02c9cea4: frintm  s0, s0                                     
02c9cea8: fmov    s1, #10.00000000                           
02c9ceac: ldr     x0, [x24, #0x78]                           &2c498b4(=d65f03c0d503245f)
02c9ceb0: add     x1, sp, #8                                 
02c9ceb4: fdiv    s0, s0, s1                                 
02c9ceb8: str     s0, [sp, #8]                               
02c9cebc: bl      #0x2b70f38                                 fn_2b70f38
02c9cec0: ldr     x3, [x23]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9cec4: mov     x2, x0                                     
02c9cec8: mov     x0, x19                                    
02c9cecc: mov     x1, x20                                    
02c9ced0: bl      #0x452c61c                                 fn_452c61c
02c9ced4: ldr     x8, [x22]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9ced8: mov     x1, x19                                    
02c9cedc: mov     x2, xzr                                    
02c9cee0: ldr     x8, [x8, #0xb8]                            
02c9cee4: ldr     x0, [x8, #0x40]                            
02c9cee8: bl      #0x2d77fe8                                 WejoyService.Tracking.TrackingManager::LogEvent
02c9ceec: ldp     x20, x19, [sp, #0x40]                      
02c9cef0: ldr     x30, [sp, #0x18]                           
02c9cef4: ldp     x22, x21, [sp, #0x30]                      
02c9cef8: ldr     d8, [sp, #0x10]                            
02c9cefc: ldp     x24, x23, [sp, #0x20]                      
02c9cf00: add     sp, sp, #0x50                              
02c9cf04: ret                                                
02c9cf08: bl      #0x2b7105c                                 fn_2b7105c
## DiyItemSelect(string gameMode, string flowId, string stepId, string itemType, string itemId, string itemRarity) -> void
---- DevTrack::DiyItemSelect 0x2c9cf0c
02c9cf0c: str     x30, [sp, #-0x60]!                         
02c9cf10: stp     x28, x27, [sp, #0x10]                      
02c9cf14: stp     x26, x25, [sp, #0x20]                      
02c9cf18: stp     x24, x23, [sp, #0x30]                      
02c9cf1c: stp     x22, x21, [sp, #0x40]                      
02c9cf20: stp     x20, x19, [sp, #0x50]                      
02c9cf24: adrp    x27, #0x662f000                            
02c9cf28: adrp    x28, #0x6263000                            
02c9cf2c: adrp    x23, #0x6263000                            
02c9cf30: adrp    x26, #0x6265000                            
02c9cf34: ldr     x28, [x28, #0x938]                         T:type8922(k15)
02c9cf38: ldrb    w8, [x27, #0xa5e]                          
02c9cf3c: ldr     x23, [x23, #0x9a0]                         MS:System.Collections.Generic.Dictionary`2::.ctor
02c9cf40: ldr     x26, [x26, #0xb38]                         T:DevTrack
02c9cf44: mov     x19, x5                                    
02c9cf48: mov     x20, x4                                    
02c9cf4c: mov     x21, x3                                    
02c9cf50: mov     x22, x2                                    
02c9cf54: mov     x24, x1                                    
02c9cf58: mov     x25, x0                                    
02c9cf5c: tbnz    w8, #0, #0x2c9cf98                         
02c9cf60: adrp    x0, #0x6265000                             
02c9cf64: ldr     x0, [x0, #0xb38]                           T:DevTrack
02c9cf68: bl      #0x2b70db0                                 fn_2b70db0
02c9cf6c: adrp    x0, #0x6265000                             
02c9cf70: ldr     x0, [x0, #0xb40]                           MS:System.Collections.Generic.Dictionary`2::Add
02c9cf74: bl      #0x2b70db0                                 fn_2b70db0
02c9cf78: adrp    x0, #0x6263000                             
02c9cf7c: ldr     x0, [x0, #0x9a0]                           MS:System.Collections.Generic.Dictionary`2::.ctor
02c9cf80: bl      #0x2b70db0                                 fn_2b70db0
02c9cf84: adrp    x0, #0x6263000                             
02c9cf88: ldr     x0, [x0, #0x938]                           T:type8922(k15)
02c9cf8c: bl      #0x2b70db0                                 fn_2b70db0
02c9cf90: mov     w8, #1                                     
02c9cf94: strb    w8, [x27, #0xa5e]                          
02c9cf98: ldr     x0, [x28]                                  &2c5bbd4(=a9bd7bfdd503233f)
02c9cf9c: bl      #0x2b7104c                                 fn_2b7104c
02c9cfa0: ldr     x1, [x23]                                  &2c5bbd4(=a9bd7bfdd503233f)
02c9cfa4: mov     x23, x0                                    
02c9cfa8: bl      #0x452b8a0                                 fn_452b8a0
02c9cfac: ldr     x0, [x26]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9cfb0: ldr     w8, [x0, #0xe4]                            [62630e4]=0 f=0,0
02c9cfb4: cbnz    w8, #0x2c9cfbc                             
02c9cfb8: bl      #0x2b70f30                                 fn_2b70f30
02c9cfbc: cbz     x23, #0x2c9d0a0                            
02c9cfc0: ldr     x8, [x26]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9cfc4: adrp    x27, #0x6265000                            
02c9cfc8: mov     x0, x23                                    
02c9cfcc: ldr     x27, [x27, #0xb40]                         MS:System.Collections.Generic.Dictionary`2::Add
02c9cfd0: mov     x2, x25                                    
02c9cfd4: ldr     x8, [x8, #0xb8]                            
02c9cfd8: ldr     x3, [x27]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9cfdc: ldr     x1, [x8, #0xd8]                            
02c9cfe0: bl      #0x452c61c                                 fn_452c61c
02c9cfe4: ldr     x8, [x26]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9cfe8: ldr     x3, [x27]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9cfec: mov     x0, x23                                    
02c9cff0: mov     x2, x24                                    
02c9cff4: ldr     x8, [x8, #0xb8]                            
02c9cff8: ldr     x1, [x8, #0xe0]                            
02c9cffc: bl      #0x452c61c                                 fn_452c61c
02c9d000: ldr     x8, [x26]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9d004: ldr     x3, [x27]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9d008: mov     x0, x23                                    
02c9d00c: mov     x2, x22                                    
02c9d010: ldr     x8, [x8, #0xb8]                            
02c9d014: ldr     x1, [x8, #0xc0]                            
02c9d018: bl      #0x452c61c                                 fn_452c61c
02c9d01c: ldr     x8, [x26]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9d020: ldr     x3, [x27]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9d024: mov     x0, x23                                    
02c9d028: mov     x2, x21                                    
02c9d02c: ldr     x8, [x8, #0xb8]                            
02c9d030: ldr     x1, [x8, #0x110]                           
02c9d034: bl      #0x452c61c                                 fn_452c61c
02c9d038: ldr     x8, [x26]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9d03c: ldr     x3, [x27]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9d040: mov     x0, x23                                    
02c9d044: mov     x2, x20                                    
02c9d048: ldr     x8, [x8, #0xb8]                            
02c9d04c: ldr     x1, [x8, #0x118]                           
02c9d050: bl      #0x452c61c                                 fn_452c61c
02c9d054: ldr     x8, [x26]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9d058: ldr     x3, [x27]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9d05c: mov     x0, x23                                    
02c9d060: mov     x2, x19                                    
02c9d064: ldr     x8, [x8, #0xb8]                            
02c9d068: ldr     x1, [x8, #0x120]                           
02c9d06c: bl      #0x452c61c                                 fn_452c61c
02c9d070: ldr     x8, [x26]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9d074: mov     x1, x23                                    
02c9d078: mov     x2, xzr                                    
02c9d07c: ldp     x20, x19, [sp, #0x50]                      
02c9d080: ldr     x8, [x8, #0xb8]                            
02c9d084: ldp     x22, x21, [sp, #0x40]                      
02c9d088: ldp     x24, x23, [sp, #0x30]                      
02c9d08c: ldp     x26, x25, [sp, #0x20]                      
02c9d090: ldr     x0, [x8, #0x48]                            
02c9d094: ldp     x28, x27, [sp, #0x10]                      
02c9d098: ldr     x30, [sp], #0x60                           
02c9d09c: b       #0x2d77fe8                                 WejoyService.Tracking.TrackingManager::LogEvent
02c9d0a0: bl      #0x2b7105c                                 fn_2b7105c
## DiyItemChoose(string gameMode, string flowId, string stepId, string itemType, string itemId, int currentItemCount) -> void
---- DevTrack::DiyItemChoose 0x2c9d0a4
02c9d0a4: str     x30, [sp, #-0x60]!                         
02c9d0a8: stp     x28, x27, [sp, #0x10]                      
02c9d0ac: stp     x26, x25, [sp, #0x20]                      
02c9d0b0: stp     x24, x23, [sp, #0x30]                      
02c9d0b4: stp     x22, x21, [sp, #0x40]                      
02c9d0b8: stp     x20, x19, [sp, #0x50]                      
02c9d0bc: adrp    x27, #0x662f000                            
02c9d0c0: adrp    x28, #0x6263000                            
02c9d0c4: adrp    x21, #0x6263000                            
02c9d0c8: adrp    x26, #0x6265000                            
02c9d0cc: ldr     x28, [x28, #0x938]                         T:type8922(k15)
02c9d0d0: ldrb    w8, [x27, #0xa5f]                          
02c9d0d4: ldr     x21, [x21, #0x9a0]                         MS:System.Collections.Generic.Dictionary`2::.ctor
02c9d0d8: ldr     x26, [x26, #0xb38]                         T:DevTrack
02c9d0dc: mov     w19, w5                                    
02c9d0e0: mov     x20, x4                                    
02c9d0e4: mov     x22, x3                                    
02c9d0e8: mov     x23, x2                                    
02c9d0ec: mov     x24, x1                                    
02c9d0f0: mov     x25, x0                                    
02c9d0f4: tbnz    w8, #0, #0x2c9d130                         
02c9d0f8: adrp    x0, #0x6265000                             
02c9d0fc: ldr     x0, [x0, #0xb38]                           T:DevTrack
02c9d100: bl      #0x2b70db0                                 fn_2b70db0
02c9d104: adrp    x0, #0x6265000                             
02c9d108: ldr     x0, [x0, #0xb40]                           MS:System.Collections.Generic.Dictionary`2::Add
02c9d10c: bl      #0x2b70db0                                 fn_2b70db0
02c9d110: adrp    x0, #0x6263000                             
02c9d114: ldr     x0, [x0, #0x9a0]                           MS:System.Collections.Generic.Dictionary`2::.ctor
02c9d118: bl      #0x2b70db0                                 fn_2b70db0
02c9d11c: adrp    x0, #0x6263000                             
02c9d120: ldr     x0, [x0, #0x938]                           T:type8922(k15)
02c9d124: bl      #0x2b70db0                                 fn_2b70db0
02c9d128: mov     w8, #1                                     
02c9d12c: strb    w8, [x27, #0xa5f]                          
02c9d130: ldr     x0, [x28]                                  &2c5bbd4(=a9bd7bfdd503233f)
02c9d134: bl      #0x2b7104c                                 fn_2b7104c
02c9d138: ldr     x1, [x21]                                  &2c5bbd4(=a9bd7bfdd503233f)
02c9d13c: mov     x21, x0                                    
02c9d140: bl      #0x452b8a0                                 fn_452b8a0
02c9d144: ldr     x0, [x26]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9d148: ldr     w8, [x0, #0xe4]                            [62630e4]=0 f=0,0
02c9d14c: cbnz    w8, #0x2c9d154                             
02c9d150: bl      #0x2b70f30                                 fn_2b70f30
02c9d154: cbz     x21, #0x2c9d258                            
02c9d158: ldr     x8, [x26]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9d15c: adrp    x27, #0x6265000                            
02c9d160: mov     x0, x21                                    
02c9d164: ldr     x27, [x27, #0xb40]                         MS:System.Collections.Generic.Dictionary`2::Add
02c9d168: mov     x2, x25                                    
02c9d16c: ldr     x8, [x8, #0xb8]                            
02c9d170: ldr     x3, [x27]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9d174: ldr     x1, [x8, #0xd8]                            
02c9d178: bl      #0x452c61c                                 fn_452c61c
02c9d17c: ldr     x8, [x26]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9d180: ldr     x3, [x27]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9d184: mov     x0, x21                                    
02c9d188: mov     x2, x24                                    
02c9d18c: ldr     x8, [x8, #0xb8]                            
02c9d190: ldr     x1, [x8, #0xe0]                            
02c9d194: bl      #0x452c61c                                 fn_452c61c
02c9d198: ldr     x8, [x26]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9d19c: ldr     x3, [x27]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9d1a0: mov     x0, x21                                    
02c9d1a4: mov     x2, x23                                    
02c9d1a8: ldr     x8, [x8, #0xb8]                            
02c9d1ac: ldr     x1, [x8, #0xc0]                            
02c9d1b0: bl      #0x452c61c                                 fn_452c61c
02c9d1b4: ldr     x8, [x26]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9d1b8: ldr     x3, [x27]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9d1bc: mov     x0, x21                                    
02c9d1c0: mov     x2, x22                                    
02c9d1c4: ldr     x8, [x8, #0xb8]                            
02c9d1c8: ldr     x1, [x8, #0x110]                           
02c9d1cc: bl      #0x452c61c                                 fn_452c61c
02c9d1d0: ldr     x8, [x26]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9d1d4: ldr     x3, [x27]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9d1d8: mov     x0, x21                                    
02c9d1dc: mov     x2, x20                                    
02c9d1e0: ldr     x8, [x8, #0xb8]                            
02c9d1e4: ldr     x1, [x8, #0x118]                           
02c9d1e8: bl      #0x452c61c                                 fn_452c61c
02c9d1ec: ldr     x8, [x26]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9d1f0: adrp    x9, #0x6263000                             
02c9d1f4: add     x1, sp, #0xc                               
02c9d1f8: ldr     x8, [x8, #0xb8]                            
02c9d1fc: ldr     x9, [x9, #0x970]                           &6645c70(=0)
02c9d200: str     w19, [sp, #0xc]                            
02c9d204: ldr     x0, [x9, #0x48]                            &6263098(=0)
02c9d208: ldr     x20, [x8, #0x128]                          
02c9d20c: bl      #0x2b70f38                                 fn_2b70f38
02c9d210: ldr     x3, [x27]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9d214: mov     x2, x0                                     
02c9d218: mov     x0, x21                                    
02c9d21c: mov     x1, x20                                    
02c9d220: bl      #0x452c61c                                 fn_452c61c
02c9d224: ldr     x8, [x26]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9d228: mov     x1, x21                                    
02c9d22c: mov     x2, xzr                                    
02c9d230: ldr     x8, [x8, #0xb8]                            
02c9d234: ldr     x0, [x8, #0x50]                            
02c9d238: bl      #0x2d77fe8                                 WejoyService.Tracking.TrackingManager::LogEvent
02c9d23c: ldp     x20, x19, [sp, #0x50]                      
02c9d240: ldp     x22, x21, [sp, #0x40]                      
02c9d244: ldp     x24, x23, [sp, #0x30]                      
02c9d248: ldp     x26, x25, [sp, #0x20]                      
02c9d24c: ldp     x28, x27, [sp, #0x10]                      
02c9d250: ldr     x30, [sp], #0x60                           
02c9d254: ret                                                
02c9d258: bl      #0x2b7105c                                 fn_2b7105c
## DiyDecorationSummary(int totalKeycapCount, int totalCharmCount) -> void
---- DevTrack::DiyDecorationSummary 0x2c9d25c
02c9d25c: sub     sp, sp, #0x50                              
02c9d260: stp     x30, x25, [sp, #0x10]                      
02c9d264: stp     x24, x23, [sp, #0x20]                      
02c9d268: stp     x22, x21, [sp, #0x30]                      
02c9d26c: stp     x20, x19, [sp, #0x40]                      
02c9d270: adrp    x22, #0x662f000                            
02c9d274: adrp    x24, #0x6263000                            
02c9d278: adrp    x20, #0x6263000                            
02c9d27c: adrp    x23, #0x6265000                            
02c9d280: ldr     x24, [x24, #0x938]                         T:type8922(k15)
02c9d284: ldrb    w8, [x22, #0xa60]                          
02c9d288: ldr     x20, [x20, #0x9a0]                         MS:System.Collections.Generic.Dictionary`2::.ctor
02c9d28c: ldr     x23, [x23, #0xb38]                         T:DevTrack
02c9d290: mov     w19, w1                                    
02c9d294: mov     w21, w0                                    
02c9d298: tbnz    w8, #0, #0x2c9d2d4                         
02c9d29c: adrp    x0, #0x6265000                             
02c9d2a0: ldr     x0, [x0, #0xb38]                           T:DevTrack
02c9d2a4: bl      #0x2b70db0                                 fn_2b70db0
02c9d2a8: adrp    x0, #0x6265000                             
02c9d2ac: ldr     x0, [x0, #0xb40]                           MS:System.Collections.Generic.Dictionary`2::Add
02c9d2b0: bl      #0x2b70db0                                 fn_2b70db0
02c9d2b4: adrp    x0, #0x6263000                             
02c9d2b8: ldr     x0, [x0, #0x9a0]                           MS:System.Collections.Generic.Dictionary`2::.ctor
02c9d2bc: bl      #0x2b70db0                                 fn_2b70db0
02c9d2c0: adrp    x0, #0x6263000                             
02c9d2c4: ldr     x0, [x0, #0x938]                           T:type8922(k15)
02c9d2c8: bl      #0x2b70db0                                 fn_2b70db0
02c9d2cc: mov     w8, #1                                     
02c9d2d0: strb    w8, [x22, #0xa60]                          
02c9d2d4: ldr     x0, [x24]                                  &2c5bbd4(=a9bd7bfdd503233f)
02c9d2d8: bl      #0x2b7104c                                 fn_2b7104c
02c9d2dc: ldr     x1, [x20]                                  &2c5bbd4(=a9bd7bfdd503233f)
02c9d2e0: mov     x20, x0                                    
02c9d2e4: bl      #0x452b8a0                                 fn_452b8a0
02c9d2e8: ldr     x0, [x23]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9d2ec: ldr     w8, [x0, #0xe4]                            [62630e4]=0 f=0,0
02c9d2f0: cbnz    w8, #0x2c9d2fc                             
02c9d2f4: bl      #0x2b70f30                                 fn_2b70f30
02c9d2f8: ldr     x0, [x23]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9d2fc: adrp    x24, #0x6263000                            
02c9d300: ldr     x8, [x0, #0xb8]                            &6263108(=0) .tutorial_id
02c9d304: add     x1, sp, #0xc                               
02c9d308: ldr     x24, [x24, #0x970]                         &6645c70(=0)
02c9d30c: str     w21, [sp, #0xc]                            
02c9d310: ldr     x22, [x8, #0x130]                          
02c9d314: ldr     x0, [x24, #0x48]                           &6263098(=0)
02c9d318: bl      #0x2b70f38                                 fn_2b70f38
02c9d31c: cbz     x20, #0x2c9d39c                            
02c9d320: adrp    x25, #0x6265000                            
02c9d324: mov     x2, x0                                     
02c9d328: mov     x0, x20                                    
02c9d32c: ldr     x25, [x25, #0xb40]                         MS:System.Collections.Generic.Dictionary`2::Add
02c9d330: mov     x1, x22                                    
02c9d334: ldr     x3, [x25]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9d338: bl      #0x452c61c                                 fn_452c61c
02c9d33c: ldr     x8, [x23]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9d340: ldr     x0, [x24, #0x48]                           &6263098(=0)
02c9d344: add     x1, sp, #8                                 
02c9d348: str     w19, [sp, #8]                              
02c9d34c: ldr     x8, [x8, #0xb8]                            
02c9d350: ldr     x21, [x8, #0x138]                          
02c9d354: bl      #0x2b70f38                                 fn_2b70f38
02c9d358: ldr     x3, [x25]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9d35c: mov     x2, x0                                     
02c9d360: mov     x0, x20                                    
02c9d364: mov     x1, x21                                    
02c9d368: bl      #0x452c61c                                 fn_452c61c
02c9d36c: ldr     x8, [x23]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9d370: mov     x1, x20                                    
02c9d374: mov     x2, xzr                                    
02c9d378: ldr     x8, [x8, #0xb8]                            
02c9d37c: ldr     x0, [x8, #0x58]                            
02c9d380: bl      #0x2d77fe8                                 WejoyService.Tracking.TrackingManager::LogEvent
02c9d384: ldp     x20, x19, [sp, #0x40]                      
02c9d388: ldp     x22, x21, [sp, #0x30]                      
02c9d38c: ldp     x24, x23, [sp, #0x20]                      
02c9d390: ldp     x30, x25, [sp, #0x10]                      
02c9d394: add     sp, sp, #0x50                              
02c9d398: ret                                                
02c9d39c: bl      #0x2b7105c                                 fn_2b7105c
## FeatureOpen(string featureName) -> void
---- DevTrack::FeatureOpen 0x2c9d3a0
02c9d3a0: stp     x30, x23, [sp, #-0x30]!                    
02c9d3a4: stp     x22, x21, [sp, #0x10]                      
02c9d3a8: stp     x20, x19, [sp, #0x20]                      
02c9d3ac: adrp    x22, #0x662f000                            
02c9d3b0: adrp    x23, #0x6263000                            
02c9d3b4: adrp    x20, #0x6263000                            
02c9d3b8: adrp    x21, #0x6265000                            
02c9d3bc: ldr     x23, [x23, #0x938]                         T:type8922(k15)
02c9d3c0: ldrb    w8, [x22, #0xa61]                          
02c9d3c4: ldr     x20, [x20, #0x9a0]                         MS:System.Collections.Generic.Dictionary`2::.ctor
02c9d3c8: ldr     x21, [x21, #0xb38]                         T:DevTrack
02c9d3cc: mov     x19, x0                                    
02c9d3d0: tbnz    w8, #0, #0x2c9d40c                         
02c9d3d4: adrp    x0, #0x6265000                             
02c9d3d8: ldr     x0, [x0, #0xb38]                           T:DevTrack
02c9d3dc: bl      #0x2b70db0                                 fn_2b70db0
02c9d3e0: adrp    x0, #0x6265000                             
02c9d3e4: ldr     x0, [x0, #0xb40]                           MS:System.Collections.Generic.Dictionary`2::Add
02c9d3e8: bl      #0x2b70db0                                 fn_2b70db0
02c9d3ec: adrp    x0, #0x6263000                             
02c9d3f0: ldr     x0, [x0, #0x9a0]                           MS:System.Collections.Generic.Dictionary`2::.ctor
02c9d3f4: bl      #0x2b70db0                                 fn_2b70db0
02c9d3f8: adrp    x0, #0x6263000                             
02c9d3fc: ldr     x0, [x0, #0x938]                           T:type8922(k15)
02c9d400: bl      #0x2b70db0                                 fn_2b70db0
02c9d404: mov     w8, #1                                     
02c9d408: strb    w8, [x22, #0xa61]                          
02c9d40c: ldr     x0, [x23]                                  &2c5bbd4(=a9bd7bfdd503233f)
02c9d410: bl      #0x2b7104c                                 fn_2b7104c
02c9d414: ldr     x1, [x20]                                  &2c5bbd4(=a9bd7bfdd503233f)
02c9d418: mov     x20, x0                                    
02c9d41c: bl      #0x452b8a0                                 fn_452b8a0
02c9d420: ldr     x0, [x21]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9d424: ldr     w8, [x0, #0xe4]                            [62630e4]=0 f=0,0
02c9d428: cbnz    w8, #0x2c9d430                             
02c9d42c: bl      #0x2b70f30                                 fn_2b70f30
02c9d430: cbz     x20, #0x2c9d47c                            
02c9d434: ldr     x8, [x21]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9d438: adrp    x9, #0x6265000                             
02c9d43c: mov     x0, x20                                    
02c9d440: ldr     x9, [x9, #0xb40]                           MS:System.Collections.Generic.Dictionary`2::Add
02c9d444: mov     x2, x19                                    
02c9d448: ldr     x8, [x8, #0xb8]                            
02c9d44c: ldr     x3, [x9]                                   M:AdsManager::<OnApplicationPause>b__26_0
02c9d450: ldr     x1, [x8, #0x140]                           
02c9d454: bl      #0x452c61c                                 fn_452c61c
02c9d458: ldr     x8, [x21]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9d45c: mov     x1, x20                                    
02c9d460: mov     x2, xzr                                    
02c9d464: ldp     x20, x19, [sp, #0x20]                      
02c9d468: ldr     x8, [x8, #0xb8]                            
02c9d46c: ldp     x22, x21, [sp, #0x10]                      
02c9d470: ldr     x0, [x8, #0x60]                            
02c9d474: ldp     x30, x23, [sp], #0x30                      
02c9d478: b       #0x2d77fe8                                 WejoyService.Tracking.TrackingManager::LogEvent
02c9d47c: bl      #0x2b7105c                                 fn_2b7105c
## FeatureAction(string featureName, string actionName) -> void
---- DevTrack::FeatureAction 0x2c9d480
02c9d480: str     x30, [sp, #-0x40]!                         
02c9d484: stp     x24, x23, [sp, #0x10]                      
02c9d488: stp     x22, x21, [sp, #0x20]                      
02c9d48c: stp     x20, x19, [sp, #0x30]                      
02c9d490: adrp    x23, #0x662f000                            
02c9d494: adrp    x24, #0x6263000                            
02c9d498: adrp    x21, #0x6263000                            
02c9d49c: adrp    x22, #0x6265000                            
02c9d4a0: ldr     x24, [x24, #0x938]                         T:type8922(k15)
02c9d4a4: ldrb    w8, [x23, #0xa62]                          
02c9d4a8: ldr     x21, [x21, #0x9a0]                         MS:System.Collections.Generic.Dictionary`2::.ctor
02c9d4ac: ldr     x22, [x22, #0xb38]                         T:DevTrack
02c9d4b0: mov     x19, x1                                    
02c9d4b4: mov     x20, x0                                    
02c9d4b8: tbnz    w8, #0, #0x2c9d4f4                         
02c9d4bc: adrp    x0, #0x6265000                             
02c9d4c0: ldr     x0, [x0, #0xb38]                           T:DevTrack
02c9d4c4: bl      #0x2b70db0                                 fn_2b70db0
02c9d4c8: adrp    x0, #0x6265000                             
02c9d4cc: ldr     x0, [x0, #0xb40]                           MS:System.Collections.Generic.Dictionary`2::Add
02c9d4d0: bl      #0x2b70db0                                 fn_2b70db0
02c9d4d4: adrp    x0, #0x6263000                             
02c9d4d8: ldr     x0, [x0, #0x9a0]                           MS:System.Collections.Generic.Dictionary`2::.ctor
02c9d4dc: bl      #0x2b70db0                                 fn_2b70db0
02c9d4e0: adrp    x0, #0x6263000                             
02c9d4e4: ldr     x0, [x0, #0x938]                           T:type8922(k15)
02c9d4e8: bl      #0x2b70db0                                 fn_2b70db0
02c9d4ec: mov     w8, #1                                     
02c9d4f0: strb    w8, [x23, #0xa62]                          
02c9d4f4: ldr     x0, [x24]                                  &2c5bbd4(=a9bd7bfdd503233f)
02c9d4f8: bl      #0x2b7104c                                 fn_2b7104c
02c9d4fc: ldr     x1, [x21]                                  &2c5bbd4(=a9bd7bfdd503233f)
02c9d500: mov     x21, x0                                    
02c9d504: bl      #0x452b8a0                                 fn_452b8a0
02c9d508: ldr     x0, [x22]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9d50c: ldr     w8, [x0, #0xe4]                            [62630e4]=0 f=0,0
02c9d510: cbnz    w8, #0x2c9d518                             
02c9d514: bl      #0x2b70f30                                 fn_2b70f30
02c9d518: cbz     x21, #0x2c9d584                            
02c9d51c: ldr     x8, [x22]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9d520: adrp    x23, #0x6265000                            
02c9d524: mov     x0, x21                                    
02c9d528: ldr     x23, [x23, #0xb40]                         MS:System.Collections.Generic.Dictionary`2::Add
02c9d52c: mov     x2, x20                                    
02c9d530: ldr     x8, [x8, #0xb8]                            
02c9d534: ldr     x3, [x23]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9d538: ldr     x1, [x8, #0x140]                           
02c9d53c: bl      #0x452c61c                                 fn_452c61c
02c9d540: ldr     x8, [x22]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9d544: ldr     x3, [x23]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9d548: mov     x0, x21                                    
02c9d54c: mov     x2, x19                                    
02c9d550: ldr     x8, [x8, #0xb8]                            
02c9d554: ldr     x1, [x8, #0x148]                           
02c9d558: bl      #0x452c61c                                 fn_452c61c
02c9d55c: ldr     x8, [x22]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9d560: mov     x1, x21                                    
02c9d564: mov     x2, xzr                                    
02c9d568: ldp     x20, x19, [sp, #0x30]                      
02c9d56c: ldr     x8, [x8, #0xb8]                            
02c9d570: ldp     x22, x21, [sp, #0x20]                      
02c9d574: ldp     x24, x23, [sp, #0x10]                      
02c9d578: ldr     x0, [x8, #0x68]                            
02c9d57c: ldr     x30, [sp], #0x40                           
02c9d580: b       #0x2d77fe8                                 WejoyService.Tracking.TrackingManager::LogEvent
02c9d584: bl      #0x2b7105c                                 fn_2b7105c
## CollectionItemView(string itemId, string itemStatus) -> void
---- DevTrack::CollectionItemView 0x2c9d588
02c9d588: str     x30, [sp, #-0x40]!                         
02c9d58c: stp     x24, x23, [sp, #0x10]                      
02c9d590: stp     x22, x21, [sp, #0x20]                      
02c9d594: stp     x20, x19, [sp, #0x30]                      
02c9d598: adrp    x23, #0x662f000                            
02c9d59c: adrp    x24, #0x6263000                            
02c9d5a0: adrp    x21, #0x6263000                            
02c9d5a4: adrp    x22, #0x6265000                            
02c9d5a8: ldr     x24, [x24, #0x938]                         T:type8922(k15)
02c9d5ac: ldrb    w8, [x23, #0xa63]                          
02c9d5b0: ldr     x21, [x21, #0x9a0]                         MS:System.Collections.Generic.Dictionary`2::.ctor
02c9d5b4: ldr     x22, [x22, #0xb38]                         T:DevTrack
02c9d5b8: mov     x19, x1                                    
02c9d5bc: mov     x20, x0                                    
02c9d5c0: tbnz    w8, #0, #0x2c9d5fc                         
02c9d5c4: adrp    x0, #0x6265000                             
02c9d5c8: ldr     x0, [x0, #0xb38]                           T:DevTrack
02c9d5cc: bl      #0x2b70db0                                 fn_2b70db0
02c9d5d0: adrp    x0, #0x6265000                             
02c9d5d4: ldr     x0, [x0, #0xb40]                           MS:System.Collections.Generic.Dictionary`2::Add
02c9d5d8: bl      #0x2b70db0                                 fn_2b70db0
02c9d5dc: adrp    x0, #0x6263000                             
02c9d5e0: ldr     x0, [x0, #0x9a0]                           MS:System.Collections.Generic.Dictionary`2::.ctor
02c9d5e4: bl      #0x2b70db0                                 fn_2b70db0
02c9d5e8: adrp    x0, #0x6263000                             
02c9d5ec: ldr     x0, [x0, #0x938]                           T:type8922(k15)
02c9d5f0: bl      #0x2b70db0                                 fn_2b70db0
02c9d5f4: mov     w8, #1                                     
02c9d5f8: strb    w8, [x23, #0xa63]                          
02c9d5fc: ldr     x0, [x24]                                  &2c5bbd4(=a9bd7bfdd503233f)
02c9d600: bl      #0x2b7104c                                 fn_2b7104c
02c9d604: ldr     x1, [x21]                                  &2c5bbd4(=a9bd7bfdd503233f)
02c9d608: mov     x21, x0                                    
02c9d60c: bl      #0x452b8a0                                 fn_452b8a0
02c9d610: ldr     x0, [x22]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9d614: ldr     w8, [x0, #0xe4]                            [62630e4]=0 f=0,0
02c9d618: cbnz    w8, #0x2c9d620                             
02c9d61c: bl      #0x2b70f30                                 fn_2b70f30
02c9d620: cbz     x21, #0x2c9d68c                            
02c9d624: ldr     x8, [x22]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9d628: adrp    x23, #0x6265000                            
02c9d62c: mov     x0, x21                                    
02c9d630: ldr     x23, [x23, #0xb40]                         MS:System.Collections.Generic.Dictionary`2::Add
02c9d634: mov     x2, x20                                    
02c9d638: ldr     x8, [x8, #0xb8]                            
02c9d63c: ldr     x3, [x23]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9d640: ldr     x1, [x8, #0x118]                           
02c9d644: bl      #0x452c61c                                 fn_452c61c
02c9d648: ldr     x8, [x22]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9d64c: ldr     x3, [x23]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9d650: mov     x0, x21                                    
02c9d654: mov     x2, x19                                    
02c9d658: ldr     x8, [x8, #0xb8]                            
02c9d65c: ldr     x1, [x8, #0x150]                           
02c9d660: bl      #0x452c61c                                 fn_452c61c
02c9d664: ldr     x8, [x22]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9d668: mov     x1, x21                                    
02c9d66c: mov     x2, xzr                                    
02c9d670: ldp     x20, x19, [sp, #0x30]                      
02c9d674: ldr     x8, [x8, #0xb8]                            
02c9d678: ldp     x22, x21, [sp, #0x20]                      
02c9d67c: ldp     x24, x23, [sp, #0x10]                      
02c9d680: ldr     x0, [x8, #0x70]                            
02c9d684: ldr     x30, [sp], #0x40                           
02c9d688: b       #0x2d77fe8                                 WejoyService.Tracking.TrackingManager::LogEvent
02c9d68c: bl      #0x2b7105c                                 fn_2b7105c
## GameModeSelect(string gameMode) -> void
---- DevTrack::GameModeSelect 0x2c9d690
02c9d690: stp     x30, x23, [sp, #-0x30]!                    
02c9d694: stp     x22, x21, [sp, #0x10]                      
02c9d698: stp     x20, x19, [sp, #0x20]                      
02c9d69c: adrp    x22, #0x662f000                            
02c9d6a0: adrp    x23, #0x6263000                            
02c9d6a4: adrp    x20, #0x6263000                            
02c9d6a8: adrp    x21, #0x6265000                            
02c9d6ac: ldr     x23, [x23, #0x938]                         T:type8922(k15)
02c9d6b0: ldrb    w8, [x22, #0xa64]                          
02c9d6b4: ldr     x20, [x20, #0x9a0]                         MS:System.Collections.Generic.Dictionary`2::.ctor
02c9d6b8: ldr     x21, [x21, #0xb38]                         T:DevTrack
02c9d6bc: mov     x19, x0                                    
02c9d6c0: tbnz    w8, #0, #0x2c9d6fc                         
02c9d6c4: adrp    x0, #0x6265000                             
02c9d6c8: ldr     x0, [x0, #0xb38]                           T:DevTrack
02c9d6cc: bl      #0x2b70db0                                 fn_2b70db0
02c9d6d0: adrp    x0, #0x6265000                             
02c9d6d4: ldr     x0, [x0, #0xb40]                           MS:System.Collections.Generic.Dictionary`2::Add
02c9d6d8: bl      #0x2b70db0                                 fn_2b70db0
02c9d6dc: adrp    x0, #0x6263000                             
02c9d6e0: ldr     x0, [x0, #0x9a0]                           MS:System.Collections.Generic.Dictionary`2::.ctor
02c9d6e4: bl      #0x2b70db0                                 fn_2b70db0
02c9d6e8: adrp    x0, #0x6263000                             
02c9d6ec: ldr     x0, [x0, #0x938]                           T:type8922(k15)
02c9d6f0: bl      #0x2b70db0                                 fn_2b70db0
02c9d6f4: mov     w8, #1                                     
02c9d6f8: strb    w8, [x22, #0xa64]                          
02c9d6fc: ldr     x0, [x23]                                  &2c5bbd4(=a9bd7bfdd503233f)
02c9d700: bl      #0x2b7104c                                 fn_2b7104c
02c9d704: ldr     x1, [x20]                                  &2c5bbd4(=a9bd7bfdd503233f)
02c9d708: mov     x20, x0                                    
02c9d70c: bl      #0x452b8a0                                 fn_452b8a0
02c9d710: ldr     x0, [x21]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9d714: ldr     w8, [x0, #0xe4]                            [62630e4]=0 f=0,0
02c9d718: cbnz    w8, #0x2c9d720                             
02c9d71c: bl      #0x2b70f30                                 fn_2b70f30
02c9d720: cbz     x20, #0x2c9d76c                            
02c9d724: ldr     x8, [x21]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9d728: adrp    x9, #0x6265000                             
02c9d72c: mov     x0, x20                                    
02c9d730: ldr     x9, [x9, #0xb40]                           MS:System.Collections.Generic.Dictionary`2::Add
02c9d734: mov     x2, x19                                    
02c9d738: ldr     x8, [x8, #0xb8]                            
02c9d73c: ldr     x3, [x9]                                   M:AdsManager::<OnApplicationPause>b__26_0
02c9d740: ldr     x1, [x8, #0xd8]                            
02c9d744: bl      #0x452c61c                                 fn_452c61c
02c9d748: ldr     x8, [x21]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9d74c: mov     x1, x20                                    
02c9d750: mov     x2, xzr                                    
02c9d754: ldp     x20, x19, [sp, #0x20]                      
02c9d758: ldr     x8, [x8, #0xb8]                            
02c9d75c: ldp     x22, x21, [sp, #0x10]                      
02c9d760: ldr     x0, [x8, #0x78]                            
02c9d764: ldp     x30, x23, [sp], #0x30                      
02c9d768: b       #0x2d77fe8                                 WejoyService.Tracking.TrackingManager::LogEvent
02c9d76c: bl      #0x2b7105c                                 fn_2b7105c
## CurrencyEarn(string currencyType, int crAmount, string crSource, int balanceAfter) -> void
---- DevTrack::CurrencyEarn 0x2c9d770
02c9d770: str     x30, [sp, #-0x50]!                         
02c9d774: stp     x26, x25, [sp, #0x10]                      
02c9d778: stp     x24, x23, [sp, #0x20]                      
02c9d77c: stp     x22, x21, [sp, #0x30]                      
02c9d780: stp     x20, x19, [sp, #0x40]                      
02c9d784: adrp    x25, #0x662f000                            
02c9d788: adrp    x26, #0x6263000                            
02c9d78c: adrp    x21, #0x6263000                            
02c9d790: adrp    x24, #0x6265000                            
02c9d794: ldr     x26, [x26, #0x938]                         T:type8922(k15)
02c9d798: ldrb    w8, [x25, #0xa65]                          
02c9d79c: ldr     x21, [x21, #0x9a0]                         MS:System.Collections.Generic.Dictionary`2::.ctor
02c9d7a0: ldr     x24, [x24, #0xb38]                         T:DevTrack
02c9d7a4: mov     w19, w3                                    
02c9d7a8: mov     x20, x2                                    
02c9d7ac: mov     w22, w1                                    
02c9d7b0: mov     x23, x0                                    
02c9d7b4: tbnz    w8, #0, #0x2c9d7f0                         
02c9d7b8: adrp    x0, #0x6265000                             
02c9d7bc: ldr     x0, [x0, #0xb38]                           T:DevTrack
02c9d7c0: bl      #0x2b70db0                                 fn_2b70db0
02c9d7c4: adrp    x0, #0x6265000                             
02c9d7c8: ldr     x0, [x0, #0xb40]                           MS:System.Collections.Generic.Dictionary`2::Add
02c9d7cc: bl      #0x2b70db0                                 fn_2b70db0
02c9d7d0: adrp    x0, #0x6263000                             
02c9d7d4: ldr     x0, [x0, #0x9a0]                           MS:System.Collections.Generic.Dictionary`2::.ctor
02c9d7d8: bl      #0x2b70db0                                 fn_2b70db0
02c9d7dc: adrp    x0, #0x6263000                             
02c9d7e0: ldr     x0, [x0, #0x938]                           T:type8922(k15)
02c9d7e4: bl      #0x2b70db0                                 fn_2b70db0
02c9d7e8: mov     w8, #1                                     
02c9d7ec: strb    w8, [x25, #0xa65]                          
02c9d7f0: ldr     x0, [x26]                                  &2c5bbd4(=a9bd7bfdd503233f)
02c9d7f4: bl      #0x2b7104c                                 fn_2b7104c
02c9d7f8: ldr     x1, [x21]                                  &2c5bbd4(=a9bd7bfdd503233f)
02c9d7fc: mov     x21, x0                                    
02c9d800: bl      #0x452b8a0                                 fn_452b8a0
02c9d804: ldr     x0, [x24]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9d808: ldr     w8, [x0, #0xe4]                            [62630e4]=0 f=0,0
02c9d80c: cbnz    w8, #0x2c9d814                             
02c9d810: bl      #0x2b70f30                                 fn_2b70f30
02c9d814: cbz     x21, #0x2c9d8f0                            
02c9d818: ldr     x8, [x24]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9d81c: adrp    x25, #0x6265000                            
02c9d820: mov     x0, x21                                    
02c9d824: ldr     x25, [x25, #0xb40]                         MS:System.Collections.Generic.Dictionary`2::Add
02c9d828: mov     x2, x23                                    
02c9d82c: ldr     x8, [x8, #0xb8]                            
02c9d830: ldr     x3, [x25]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9d834: ldr     x1, [x8, #0x158]                           
02c9d838: bl      #0x452c61c                                 fn_452c61c
02c9d83c: ldr     x8, [x24]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9d840: adrp    x26, #0x6263000                            
02c9d844: add     x1, sp, #0xc                               
02c9d848: ldr     x8, [x8, #0xb8]                            
02c9d84c: ldr     x26, [x26, #0x970]                         &6645c70(=0)
02c9d850: str     w22, [sp, #0xc]                            
02c9d854: ldr     x0, [x26, #0x48]                           &6263098(=0)
02c9d858: ldr     x23, [x8, #0x160]                          
02c9d85c: bl      #0x2b70f38                                 fn_2b70f38
02c9d860: ldr     x3, [x25]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9d864: mov     x2, x0                                     
02c9d868: mov     x0, x21                                    
02c9d86c: mov     x1, x23                                    
02c9d870: bl      #0x452c61c                                 fn_452c61c
02c9d874: ldr     x8, [x24]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9d878: ldr     x3, [x25]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9d87c: mov     x0, x21                                    
02c9d880: mov     x2, x20                                    
02c9d884: ldr     x8, [x8, #0xb8]                            
02c9d888: ldr     x1, [x8, #0x168]                           
02c9d88c: bl      #0x452c61c                                 fn_452c61c
02c9d890: ldr     x8, [x24]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9d894: ldr     x0, [x26, #0x48]                           &6263098(=0)
02c9d898: add     x1, sp, #8                                 
02c9d89c: str     w19, [sp, #8]                              
02c9d8a0: ldr     x8, [x8, #0xb8]                            
02c9d8a4: ldr     x20, [x8, #0x170]                          
02c9d8a8: bl      #0x2b70f38                                 fn_2b70f38
02c9d8ac: ldr     x3, [x25]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9d8b0: mov     x2, x0                                     
02c9d8b4: mov     x0, x21                                    
02c9d8b8: mov     x1, x20                                    
02c9d8bc: bl      #0x452c61c                                 fn_452c61c
02c9d8c0: ldr     x8, [x24]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9d8c4: mov     x1, x21                                    
02c9d8c8: mov     x2, xzr                                    
02c9d8cc: ldr     x8, [x8, #0xb8]                            
02c9d8d0: ldr     x0, [x8, #0x80]                            
02c9d8d4: bl      #0x2d77fe8                                 WejoyService.Tracking.TrackingManager::LogEvent
02c9d8d8: ldp     x20, x19, [sp, #0x40]                      
02c9d8dc: ldp     x22, x21, [sp, #0x30]                      
02c9d8e0: ldp     x24, x23, [sp, #0x20]                      
02c9d8e4: ldp     x26, x25, [sp, #0x10]                      
02c9d8e8: ldr     x30, [sp], #0x50                           
02c9d8ec: ret                                                
02c9d8f0: bl      #0x2b7105c                                 fn_2b7105c
## CurrencySpend(string currencyType, int crAmount, string crSink, int balanceAfter) -> void
---- DevTrack::CurrencySpend 0x2c9d8f4
02c9d8f4: str     x30, [sp, #-0x50]!                         
02c9d8f8: stp     x26, x25, [sp, #0x10]                      
02c9d8fc: stp     x24, x23, [sp, #0x20]                      
02c9d900: stp     x22, x21, [sp, #0x30]                      
02c9d904: stp     x20, x19, [sp, #0x40]                      
02c9d908: adrp    x25, #0x662f000                            
02c9d90c: adrp    x26, #0x6263000                            
02c9d910: adrp    x21, #0x6263000                            
02c9d914: adrp    x24, #0x6265000                            
02c9d918: ldr     x26, [x26, #0x938]                         T:type8922(k15)
02c9d91c: ldrb    w8, [x25, #0xa66]                          
02c9d920: ldr     x21, [x21, #0x9a0]                         MS:System.Collections.Generic.Dictionary`2::.ctor
02c9d924: ldr     x24, [x24, #0xb38]                         T:DevTrack
02c9d928: mov     w19, w3                                    
02c9d92c: mov     x20, x2                                    
02c9d930: mov     w22, w1                                    
02c9d934: mov     x23, x0                                    
02c9d938: tbnz    w8, #0, #0x2c9d974                         
02c9d93c: adrp    x0, #0x6265000                             
02c9d940: ldr     x0, [x0, #0xb38]                           T:DevTrack
02c9d944: bl      #0x2b70db0                                 fn_2b70db0
02c9d948: adrp    x0, #0x6265000                             
02c9d94c: ldr     x0, [x0, #0xb40]                           MS:System.Collections.Generic.Dictionary`2::Add
02c9d950: bl      #0x2b70db0                                 fn_2b70db0
02c9d954: adrp    x0, #0x6263000                             
02c9d958: ldr     x0, [x0, #0x9a0]                           MS:System.Collections.Generic.Dictionary`2::.ctor
02c9d95c: bl      #0x2b70db0                                 fn_2b70db0
02c9d960: adrp    x0, #0x6263000                             
02c9d964: ldr     x0, [x0, #0x938]                           T:type8922(k15)
02c9d968: bl      #0x2b70db0                                 fn_2b70db0
02c9d96c: mov     w8, #1                                     
02c9d970: strb    w8, [x25, #0xa66]                          
02c9d974: ldr     x0, [x26]                                  &2c5bbd4(=a9bd7bfdd503233f)
02c9d978: bl      #0x2b7104c                                 fn_2b7104c
02c9d97c: ldr     x1, [x21]                                  &2c5bbd4(=a9bd7bfdd503233f)
02c9d980: mov     x21, x0                                    
02c9d984: bl      #0x452b8a0                                 fn_452b8a0
02c9d988: ldr     x0, [x24]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9d98c: ldr     w8, [x0, #0xe4]                            [62630e4]=0 f=0,0
02c9d990: cbnz    w8, #0x2c9d998                             
02c9d994: bl      #0x2b70f30                                 fn_2b70f30
02c9d998: cbz     x21, #0x2c9da74                            
02c9d99c: ldr     x8, [x24]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9d9a0: adrp    x25, #0x6265000                            
02c9d9a4: mov     x0, x21                                    
02c9d9a8: ldr     x25, [x25, #0xb40]                         MS:System.Collections.Generic.Dictionary`2::Add
02c9d9ac: mov     x2, x23                                    
02c9d9b0: ldr     x8, [x8, #0xb8]                            
02c9d9b4: ldr     x3, [x25]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9d9b8: ldr     x1, [x8, #0x158]                           
02c9d9bc: bl      #0x452c61c                                 fn_452c61c
02c9d9c0: ldr     x8, [x24]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9d9c4: adrp    x26, #0x6263000                            
02c9d9c8: add     x1, sp, #0xc                               
02c9d9cc: ldr     x8, [x8, #0xb8]                            
02c9d9d0: ldr     x26, [x26, #0x970]                         &6645c70(=0)
02c9d9d4: str     w22, [sp, #0xc]                            
02c9d9d8: ldr     x0, [x26, #0x48]                           &6263098(=0)
02c9d9dc: ldr     x23, [x8, #0x160]                          
02c9d9e0: bl      #0x2b70f38                                 fn_2b70f38
02c9d9e4: ldr     x3, [x25]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9d9e8: mov     x2, x0                                     
02c9d9ec: mov     x0, x21                                    
02c9d9f0: mov     x1, x23                                    
02c9d9f4: bl      #0x452c61c                                 fn_452c61c
02c9d9f8: ldr     x8, [x24]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9d9fc: ldr     x3, [x25]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9da00: mov     x0, x21                                    
02c9da04: mov     x2, x20                                    
02c9da08: ldr     x8, [x8, #0xb8]                            
02c9da0c: ldr     x1, [x8, #0x178]                           
02c9da10: bl      #0x452c61c                                 fn_452c61c
02c9da14: ldr     x8, [x24]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9da18: ldr     x0, [x26, #0x48]                           &6263098(=0)
02c9da1c: add     x1, sp, #8                                 
02c9da20: str     w19, [sp, #8]                              
02c9da24: ldr     x8, [x8, #0xb8]                            
02c9da28: ldr     x20, [x8, #0x170]                          
02c9da2c: bl      #0x2b70f38                                 fn_2b70f38
02c9da30: ldr     x3, [x25]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9da34: mov     x2, x0                                     
02c9da38: mov     x0, x21                                    
02c9da3c: mov     x1, x20                                    
02c9da40: bl      #0x452c61c                                 fn_452c61c
02c9da44: ldr     x8, [x24]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9da48: mov     x1, x21                                    
02c9da4c: mov     x2, xzr                                    
02c9da50: ldr     x8, [x8, #0xb8]                            
02c9da54: ldr     x0, [x8, #0x88]                            
02c9da58: bl      #0x2d77fe8                                 WejoyService.Tracking.TrackingManager::LogEvent
02c9da5c: ldp     x20, x19, [sp, #0x40]                      
02c9da60: ldp     x22, x21, [sp, #0x30]                      
02c9da64: ldp     x24, x23, [sp, #0x20]                      
02c9da68: ldp     x26, x25, [sp, #0x10]                      
02c9da6c: ldr     x30, [sp], #0x50                           
02c9da70: ret                                                
02c9da74: bl      #0x2b7105c                                 fn_2b7105c
## RewardDoubleAdsTap(string placementId) -> void
---- DevTrack::RewardDoubleAdsTap 0x2c9da78
02c9da78: stp     x30, x23, [sp, #-0x30]!                    
02c9da7c: stp     x22, x21, [sp, #0x10]                      
02c9da80: stp     x20, x19, [sp, #0x20]                      
02c9da84: adrp    x22, #0x662f000                            
02c9da88: adrp    x23, #0x6263000                            
02c9da8c: adrp    x20, #0x6263000                            
02c9da90: adrp    x21, #0x6265000                            
02c9da94: ldr     x23, [x23, #0x938]                         T:type8922(k15)
02c9da98: ldrb    w8, [x22, #0xa67]                          
02c9da9c: ldr     x20, [x20, #0x9a0]                         MS:System.Collections.Generic.Dictionary`2::.ctor
02c9daa0: ldr     x21, [x21, #0xb38]                         T:DevTrack
02c9daa4: mov     x19, x0                                    
02c9daa8: tbnz    w8, #0, #0x2c9dae4                         
02c9daac: adrp    x0, #0x6265000                             
02c9dab0: ldr     x0, [x0, #0xb38]                           T:DevTrack
02c9dab4: bl      #0x2b70db0                                 fn_2b70db0
02c9dab8: adrp    x0, #0x6265000                             
02c9dabc: ldr     x0, [x0, #0xb40]                           MS:System.Collections.Generic.Dictionary`2::Add
02c9dac0: bl      #0x2b70db0                                 fn_2b70db0
02c9dac4: adrp    x0, #0x6263000                             
02c9dac8: ldr     x0, [x0, #0x9a0]                           MS:System.Collections.Generic.Dictionary`2::.ctor
02c9dacc: bl      #0x2b70db0                                 fn_2b70db0
02c9dad0: adrp    x0, #0x6263000                             
02c9dad4: ldr     x0, [x0, #0x938]                           T:type8922(k15)
02c9dad8: bl      #0x2b70db0                                 fn_2b70db0
02c9dadc: mov     w8, #1                                     
02c9dae0: strb    w8, [x22, #0xa67]                          
02c9dae4: ldr     x0, [x23]                                  &2c5bbd4(=a9bd7bfdd503233f)
02c9dae8: bl      #0x2b7104c                                 fn_2b7104c
02c9daec: ldr     x1, [x20]                                  &2c5bbd4(=a9bd7bfdd503233f)
02c9daf0: mov     x20, x0                                    
02c9daf4: bl      #0x452b8a0                                 fn_452b8a0
02c9daf8: ldr     x0, [x21]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9dafc: ldr     w8, [x0, #0xe4]                            [62630e4]=0 f=0,0
02c9db00: cbnz    w8, #0x2c9db08                             
02c9db04: bl      #0x2b70f30                                 fn_2b70f30
02c9db08: cbz     x20, #0x2c9db54                            
02c9db0c: ldr     x8, [x21]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9db10: adrp    x9, #0x6265000                             
02c9db14: mov     x0, x20                                    
02c9db18: ldr     x9, [x9, #0xb40]                           MS:System.Collections.Generic.Dictionary`2::Add
02c9db1c: mov     x2, x19                                    
02c9db20: ldr     x8, [x8, #0xb8]                            
02c9db24: ldr     x3, [x9]                                   M:AdsManager::<OnApplicationPause>b__26_0
02c9db28: ldr     x1, [x8, #0x180]                           
02c9db2c: bl      #0x452c61c                                 fn_452c61c
02c9db30: ldr     x8, [x21]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9db34: mov     x1, x20                                    
02c9db38: mov     x2, xzr                                    
02c9db3c: ldp     x20, x19, [sp, #0x20]                      
02c9db40: ldr     x8, [x8, #0xb8]                            
02c9db44: ldp     x22, x21, [sp, #0x10]                      
02c9db48: ldr     x0, [x8, #0x90]                            
02c9db4c: ldp     x30, x23, [sp], #0x30                      
02c9db50: b       #0x2d77fe8                                 WejoyService.Tracking.TrackingManager::LogEvent
02c9db54: bl      #0x2b7105c                                 fn_2b7105c
## RewardDoubleAdsResult(string placementId, string result) -> void
---- DevTrack::RewardDoubleAdsResult 0x2c9db58
02c9db58: str     x30, [sp, #-0x40]!                         
02c9db5c: stp     x24, x23, [sp, #0x10]                      
02c9db60: stp     x22, x21, [sp, #0x20]                      
02c9db64: stp     x20, x19, [sp, #0x30]                      
02c9db68: adrp    x23, #0x662f000                            
02c9db6c: adrp    x24, #0x6263000                            
02c9db70: adrp    x21, #0x6263000                            
02c9db74: adrp    x22, #0x6265000                            
02c9db78: ldr     x24, [x24, #0x938]                         T:type8922(k15)
02c9db7c: ldrb    w8, [x23, #0xa68]                          
02c9db80: ldr     x21, [x21, #0x9a0]                         MS:System.Collections.Generic.Dictionary`2::.ctor
02c9db84: ldr     x22, [x22, #0xb38]                         T:DevTrack
02c9db88: mov     x19, x1                                    
02c9db8c: mov     x20, x0                                    
02c9db90: tbnz    w8, #0, #0x2c9dbcc                         
02c9db94: adrp    x0, #0x6265000                             
02c9db98: ldr     x0, [x0, #0xb38]                           T:DevTrack
02c9db9c: bl      #0x2b70db0                                 fn_2b70db0
02c9dba0: adrp    x0, #0x6265000                             
02c9dba4: ldr     x0, [x0, #0xb40]                           MS:System.Collections.Generic.Dictionary`2::Add
02c9dba8: bl      #0x2b70db0                                 fn_2b70db0
02c9dbac: adrp    x0, #0x6263000                             
02c9dbb0: ldr     x0, [x0, #0x9a0]                           MS:System.Collections.Generic.Dictionary`2::.ctor
02c9dbb4: bl      #0x2b70db0                                 fn_2b70db0
02c9dbb8: adrp    x0, #0x6263000                             
02c9dbbc: ldr     x0, [x0, #0x938]                           T:type8922(k15)
02c9dbc0: bl      #0x2b70db0                                 fn_2b70db0
02c9dbc4: mov     w8, #1                                     
02c9dbc8: strb    w8, [x23, #0xa68]                          
02c9dbcc: ldr     x0, [x24]                                  &2c5bbd4(=a9bd7bfdd503233f)
02c9dbd0: bl      #0x2b7104c                                 fn_2b7104c
02c9dbd4: ldr     x1, [x21]                                  &2c5bbd4(=a9bd7bfdd503233f)
02c9dbd8: mov     x21, x0                                    
02c9dbdc: bl      #0x452b8a0                                 fn_452b8a0
02c9dbe0: ldr     x0, [x22]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9dbe4: ldr     w8, [x0, #0xe4]                            [62630e4]=0 f=0,0
02c9dbe8: cbnz    w8, #0x2c9dbf0                             
02c9dbec: bl      #0x2b70f30                                 fn_2b70f30
02c9dbf0: cbz     x21, #0x2c9dc54                            
02c9dbf4: ldr     x8, [x22]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9dbf8: adrp    x23, #0x6265000                            
02c9dbfc: mov     x0, x21                                    
02c9dc00: ldr     x23, [x23, #0xb40]                         MS:System.Collections.Generic.Dictionary`2::Add
02c9dc04: mov     x2, x20                                    
02c9dc08: ldr     x8, [x8, #0xb8]                            
02c9dc0c: ldr     x3, [x23]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9dc10: ldr     x1, [x8, #0x180]                           
02c9dc14: bl      #0x452c61c                                 fn_452c61c
02c9dc18: ldr     x3, [x23]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9dc1c: mov     x0, x21                                    
02c9dc20: mov     x1, x19                                    
02c9dc24: mov     x2, x19                                    
02c9dc28: bl      #0x452c61c                                 fn_452c61c
02c9dc2c: ldr     x8, [x22]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9dc30: mov     x1, x21                                    
02c9dc34: mov     x2, xzr                                    
02c9dc38: ldp     x20, x19, [sp, #0x30]                      
02c9dc3c: ldr     x8, [x8, #0xb8]                            
02c9dc40: ldp     x22, x21, [sp, #0x20]                      
02c9dc44: ldp     x24, x23, [sp, #0x10]                      
02c9dc48: ldr     x0, [x8, #0x98]                            
02c9dc4c: ldr     x30, [sp], #0x40                           
02c9dc50: b       #0x2d77fe8                                 WejoyService.Tracking.TrackingManager::LogEvent
02c9dc54: bl      #0x2b7105c                                 fn_2b7105c
## RewardClaim(string rewardType, int crAmount, string crSource) -> void
---- DevTrack::RewardClaim 0x2c9dc58
02c9dc58: sub     sp, sp, #0x50                              
02c9dc5c: stp     x30, x25, [sp, #0x10]                      
02c9dc60: stp     x24, x23, [sp, #0x20]                      
02c9dc64: stp     x22, x21, [sp, #0x30]                      
02c9dc68: stp     x20, x19, [sp, #0x40]                      
02c9dc6c: adrp    x24, #0x662f000                            
02c9dc70: adrp    x25, #0x6263000                            
02c9dc74: adrp    x21, #0x6263000                            
02c9dc78: adrp    x23, #0x6265000                            
02c9dc7c: ldr     x25, [x25, #0x938]                         T:type8922(k15)
02c9dc80: ldrb    w8, [x24, #0xa69]                          
02c9dc84: ldr     x21, [x21, #0x9a0]                         MS:System.Collections.Generic.Dictionary`2::.ctor
02c9dc88: ldr     x23, [x23, #0xb38]                         T:DevTrack
02c9dc8c: mov     x19, x2                                    
02c9dc90: mov     w20, w1                                    
02c9dc94: mov     x22, x0                                    
02c9dc98: tbnz    w8, #0, #0x2c9dcd4                         
02c9dc9c: adrp    x0, #0x6265000                             
02c9dca0: ldr     x0, [x0, #0xb38]                           T:DevTrack
02c9dca4: bl      #0x2b70db0                                 fn_2b70db0
02c9dca8: adrp    x0, #0x6265000                             
02c9dcac: ldr     x0, [x0, #0xb40]                           MS:System.Collections.Generic.Dictionary`2::Add
02c9dcb0: bl      #0x2b70db0                                 fn_2b70db0
02c9dcb4: adrp    x0, #0x6263000                             
02c9dcb8: ldr     x0, [x0, #0x9a0]                           MS:System.Collections.Generic.Dictionary`2::.ctor
02c9dcbc: bl      #0x2b70db0                                 fn_2b70db0
02c9dcc0: adrp    x0, #0x6263000                             
02c9dcc4: ldr     x0, [x0, #0x938]                           T:type8922(k15)
02c9dcc8: bl      #0x2b70db0                                 fn_2b70db0
02c9dccc: mov     w8, #1                                     
02c9dcd0: strb    w8, [x24, #0xa69]                          
02c9dcd4: ldr     x0, [x25]                                  &2c5bbd4(=a9bd7bfdd503233f)
02c9dcd8: bl      #0x2b7104c                                 fn_2b7104c
02c9dcdc: ldr     x1, [x21]                                  &2c5bbd4(=a9bd7bfdd503233f)
02c9dce0: mov     x21, x0                                    
02c9dce4: bl      #0x452b8a0                                 fn_452b8a0
02c9dce8: ldr     x0, [x23]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9dcec: ldr     w8, [x0, #0xe4]                            [62630e4]=0 f=0,0
02c9dcf0: cbnz    w8, #0x2c9dcf8                             
02c9dcf4: bl      #0x2b70f30                                 fn_2b70f30
02c9dcf8: cbz     x21, #0x2c9dda4                            
02c9dcfc: ldr     x8, [x23]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9dd00: adrp    x24, #0x6265000                            
02c9dd04: mov     x0, x21                                    
02c9dd08: ldr     x24, [x24, #0xb40]                         MS:System.Collections.Generic.Dictionary`2::Add
02c9dd0c: mov     x2, x22                                    
02c9dd10: ldr     x8, [x8, #0xb8]                            
02c9dd14: ldr     x3, [x24]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9dd18: ldr     x1, [x8, #0x190]                           
02c9dd1c: bl      #0x452c61c                                 fn_452c61c
02c9dd20: ldr     x8, [x23]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9dd24: adrp    x9, #0x6263000                             
02c9dd28: add     x1, sp, #0xc                               
02c9dd2c: ldr     x8, [x8, #0xb8]                            
02c9dd30: ldr     x9, [x9, #0x970]                           &6645c70(=0)
02c9dd34: str     w20, [sp, #0xc]                            
02c9dd38: ldr     x0, [x9, #0x48]                            &6263098(=0)
02c9dd3c: ldr     x22, [x8, #0x160]                          
02c9dd40: bl      #0x2b70f38                                 fn_2b70f38
02c9dd44: ldr     x3, [x24]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9dd48: mov     x2, x0                                     
02c9dd4c: mov     x0, x21                                    
02c9dd50: mov     x1, x22                                    
02c9dd54: bl      #0x452c61c                                 fn_452c61c
02c9dd58: ldr     x8, [x23]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9dd5c: ldr     x3, [x24]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9dd60: mov     x0, x21                                    
02c9dd64: mov     x2, x19                                    
02c9dd68: ldr     x8, [x8, #0xb8]                            
02c9dd6c: ldr     x1, [x8, #0x168]                           
02c9dd70: bl      #0x452c61c                                 fn_452c61c
02c9dd74: ldr     x8, [x23]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9dd78: mov     x1, x21                                    
02c9dd7c: mov     x2, xzr                                    
02c9dd80: ldr     x8, [x8, #0xb8]                            
02c9dd84: ldr     x0, [x8, #0xa0]                            
02c9dd88: bl      #0x2d77fe8                                 WejoyService.Tracking.TrackingManager::LogEvent
02c9dd8c: ldp     x20, x19, [sp, #0x40]                      
02c9dd90: ldp     x22, x21, [sp, #0x30]                      
02c9dd94: ldp     x24, x23, [sp, #0x20]                      
02c9dd98: ldp     x30, x25, [sp, #0x10]                      
02c9dd9c: add     sp, sp, #0x50                              
02c9dda0: ret                                                
02c9dda4: bl      #0x2b7105c                                 fn_2b7105c
## SettingChanged(string settingName, string previousValue, string newValue) -> void
---- DevTrack::SettingChanged 0x2c9dda8
02c9dda8: stp     x30, x25, [sp, #-0x40]!                    
02c9ddac: stp     x24, x23, [sp, #0x10]                      
02c9ddb0: stp     x22, x21, [sp, #0x20]                      
02c9ddb4: stp     x20, x19, [sp, #0x30]                      
02c9ddb8: adrp    x24, #0x662f000                            
02c9ddbc: adrp    x25, #0x6263000                            
02c9ddc0: adrp    x22, #0x6263000                            
02c9ddc4: adrp    x23, #0x6265000                            
02c9ddc8: ldr     x25, [x25, #0x938]                         T:type8922(k15)
02c9ddcc: ldrb    w8, [x24, #0xa6a]                          
02c9ddd0: ldr     x22, [x22, #0x9a0]                         MS:System.Collections.Generic.Dictionary`2::.ctor
02c9ddd4: ldr     x23, [x23, #0xb38]                         T:DevTrack
02c9ddd8: mov     x19, x2                                    
02c9dddc: mov     x20, x1                                    
02c9dde0: mov     x21, x0                                    
02c9dde4: tbnz    w8, #0, #0x2c9de20                         
02c9dde8: adrp    x0, #0x6265000                             
02c9ddec: ldr     x0, [x0, #0xb38]                           T:DevTrack
02c9ddf0: bl      #0x2b70db0                                 fn_2b70db0
02c9ddf4: adrp    x0, #0x6265000                             
02c9ddf8: ldr     x0, [x0, #0xb40]                           MS:System.Collections.Generic.Dictionary`2::Add
02c9ddfc: bl      #0x2b70db0                                 fn_2b70db0
02c9de00: adrp    x0, #0x6263000                             
02c9de04: ldr     x0, [x0, #0x9a0]                           MS:System.Collections.Generic.Dictionary`2::.ctor
02c9de08: bl      #0x2b70db0                                 fn_2b70db0
02c9de0c: adrp    x0, #0x6263000                             
02c9de10: ldr     x0, [x0, #0x938]                           T:type8922(k15)
02c9de14: bl      #0x2b70db0                                 fn_2b70db0
02c9de18: mov     w8, #1                                     
02c9de1c: strb    w8, [x24, #0xa6a]                          
02c9de20: ldr     x0, [x25]                                  &2c5bbd4(=a9bd7bfdd503233f)
02c9de24: bl      #0x2b7104c                                 fn_2b7104c
02c9de28: ldr     x1, [x22]                                  &2c5bbd4(=a9bd7bfdd503233f)
02c9de2c: mov     x22, x0                                    
02c9de30: bl      #0x452b8a0                                 fn_452b8a0
02c9de34: ldr     x0, [x23]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9de38: ldr     w8, [x0, #0xe4]                            [62630e4]=0 f=0,0
02c9de3c: cbnz    w8, #0x2c9de44                             
02c9de40: bl      #0x2b70f30                                 fn_2b70f30
02c9de44: cbz     x22, #0x2c9decc                            
02c9de48: ldr     x8, [x23]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9de4c: adrp    x24, #0x6265000                            
02c9de50: mov     x0, x22                                    
02c9de54: ldr     x24, [x24, #0xb40]                         MS:System.Collections.Generic.Dictionary`2::Add
02c9de58: mov     x2, x21                                    
02c9de5c: ldr     x8, [x8, #0xb8]                            
02c9de60: ldr     x3, [x24]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9de64: ldr     x1, [x8, #0x198]                           
02c9de68: bl      #0x452c61c                                 fn_452c61c
02c9de6c: ldr     x8, [x23]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9de70: ldr     x3, [x24]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9de74: mov     x0, x22                                    
02c9de78: mov     x2, x20                                    
02c9de7c: ldr     x8, [x8, #0xb8]                            
02c9de80: ldr     x1, [x8, #0x1a0]                           
02c9de84: bl      #0x452c61c                                 fn_452c61c
02c9de88: ldr     x8, [x23]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9de8c: ldr     x3, [x24]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9de90: mov     x0, x22                                    
02c9de94: mov     x2, x19                                    
02c9de98: ldr     x8, [x8, #0xb8]                            
02c9de9c: ldr     x1, [x8, #0x1a8]                           
02c9dea0: bl      #0x452c61c                                 fn_452c61c
02c9dea4: ldr     x8, [x23]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9dea8: mov     x1, x22                                    
02c9deac: mov     x2, xzr                                    
02c9deb0: ldp     x20, x19, [sp, #0x30]                      
02c9deb4: ldr     x8, [x8, #0xb8]                            
02c9deb8: ldp     x22, x21, [sp, #0x20]                      
02c9debc: ldp     x24, x23, [sp, #0x10]                      
02c9dec0: ldr     x0, [x8, #0xa8]                            
02c9dec4: ldp     x30, x25, [sp], #0x40                      
02c9dec8: b       #0x2d77fe8                                 WejoyService.Tracking.TrackingManager::LogEvent
02c9decc: bl      #0x2b7105c                                 fn_2b7105c
## FpsReport(float fpsAvg, float fpsMin, float fpsMax, float frameTimeAvg, int playTime, string gameMode, string screenName, int stepId) -> void
---- DevTrack::FpsReport 0x2c9ded0
02c9ded0: sub     sp, sp, #0x90                              
02c9ded4: stp     d11, d10, [sp, #0x20]                      
02c9ded8: stp     d9, d8, [sp, #0x30]                        
02c9dedc: stp     x30, x27, [sp, #0x40]                      
02c9dee0: stp     x26, x25, [sp, #0x50]                      
02c9dee4: stp     x24, x23, [sp, #0x60]                      
02c9dee8: stp     x22, x21, [sp, #0x70]                      
02c9deec: stp     x20, x19, [sp, #0x80]                      
02c9def0: fmov    s8, s3                                     
02c9def4: fmov    s9, s2                                     
02c9def8: adrp    x24, #0x662f000                            
02c9defc: fmov    s10, s1                                    
02c9df00: fmov    s11, s0                                    
02c9df04: adrp    x26, #0x6263000                            
02c9df08: adrp    x22, #0x6263000                            
02c9df0c: adrp    x25, #0x6265000                            
02c9df10: ldr     x26, [x26, #0x938]                         T:type8922(k15)
02c9df14: ldrb    w8, [x24, #0xa6b]                          
02c9df18: ldr     x22, [x22, #0x9a0]                         MS:System.Collections.Generic.Dictionary`2::.ctor
02c9df1c: ldr     x25, [x25, #0xb38]                         T:DevTrack
02c9df20: mov     w19, w3                                    
02c9df24: mov     x20, x2                                    
02c9df28: mov     x21, x1                                    
02c9df2c: mov     w23, w0                                    
02c9df30: tbnz    w8, #0, #0x2c9df6c                         
02c9df34: adrp    x0, #0x6265000                             
02c9df38: ldr     x0, [x0, #0xb38]                           T:DevTrack
02c9df3c: bl      #0x2b70db0                                 fn_2b70db0
02c9df40: adrp    x0, #0x6265000                             
02c9df44: ldr     x0, [x0, #0xb40]                           MS:System.Collections.Generic.Dictionary`2::Add
02c9df48: bl      #0x2b70db0                                 fn_2b70db0
02c9df4c: adrp    x0, #0x6263000                             
02c9df50: ldr     x0, [x0, #0x9a0]                           MS:System.Collections.Generic.Dictionary`2::.ctor
02c9df54: bl      #0x2b70db0                                 fn_2b70db0
02c9df58: adrp    x0, #0x6263000                             
02c9df5c: ldr     x0, [x0, #0x938]                           T:type8922(k15)
02c9df60: bl      #0x2b70db0                                 fn_2b70db0
02c9df64: mov     w8, #1                                     
02c9df68: strb    w8, [x24, #0xa6b]                          
02c9df6c: ldr     x0, [x26]                                  &2c5bbd4(=a9bd7bfdd503233f)
02c9df70: bl      #0x2b7104c                                 fn_2b7104c
02c9df74: ldr     x1, [x22]                                  &2c5bbd4(=a9bd7bfdd503233f)
02c9df78: mov     x22, x0                                    
02c9df7c: bl      #0x452b8a0                                 fn_452b8a0
02c9df80: ldr     x0, [x25]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9df84: ldr     w8, [x0, #0xe4]                            [62630e4]=0 f=0,0
02c9df88: cbnz    w8, #0x2c9df94                             
02c9df8c: bl      #0x2b70f30                                 fn_2b70f30
02c9df90: ldr     x0, [x25]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9df94: fmov    s0, #10.00000000                           
02c9df98: ldr     x8, [x0, #0xb8]                            &6263108(=0) .tutorial_id
02c9df9c: add     x0, sp, #0x18                              
02c9dfa0: ldr     x24, [x8, #0x1b0]                          
02c9dfa4: fmul    s11, s11, s0                               
02c9dfa8: fcvt    d0, s11                                    
02c9dfac: bl      #0x5e902c0                                 fn_5e902c0
02c9dfb0: fcmp    s11, #0.0                                  
02c9dfb4: b.ge    #0x2c9dfd0                                 
02c9dfb8: fmov    d1, #-0.50000000                           
02c9dfbc: fcmp    d0, d1                                     
02c9dfc0: b.ne    #0x2c9dffc                                 
02c9dfc4: ldr     d0, [sp, #0x18]                            
02c9dfc8: fmov    s2, #-1.00000000                           
02c9dfcc: b       #0x2c9dfe4                                 
02c9dfd0: fmov    d1, #0.50000000                            
02c9dfd4: fcmp    d0, d1                                     
02c9dfd8: b.ne    #0x2c9e00c                                 
02c9dfdc: ldr     d0, [sp, #0x18]                            
02c9dfe0: fmov    s2, #1.00000000                            
02c9dfe4: fcvt    s1, d0                                     
02c9dfe8: fcvtzs  x8, d0                                     
02c9dfec: fadd    s0, s1, s2                                 
02c9dff0: tst     x8, #1                                     
02c9dff4: fcsel   s0, s1, s0, eq                             
02c9dff8: b       #0x2c9e018                                 
02c9dffc: fmov    s0, #-0.50000000                           
02c9e000: fadd    s0, s11, s0                                
02c9e004: frintp  s0, s0                                     
02c9e008: b       #0x2c9e018                                 
02c9e00c: fmov    s0, #0.50000000                            
02c9e010: fadd    s0, s11, s0                                
02c9e014: frintm  s0, s0                                     
02c9e018: fmov    s11, #10.00000000                          
02c9e01c: adrp    x26, #0x6263000                            
02c9e020: add     x1, sp, #0x14                              
02c9e024: ldr     x26, [x26, #0x970]                         &6645c70(=0)
02c9e028: fdiv    s0, s0, s11                                
02c9e02c: ldr     x0, [x26, #0x78]                           &2c498b4(=d65f03c0d503245f)
02c9e030: str     s0, [sp, #0x14]                            
02c9e034: bl      #0x2b70f38                                 fn_2b70f38
02c9e038: cbz     x22, #0x2c9e33c                            
02c9e03c: adrp    x27, #0x6265000                            
02c9e040: mov     x2, x0                                     
02c9e044: mov     x0, x22                                    
02c9e048: ldr     x27, [x27, #0xb40]                         MS:System.Collections.Generic.Dictionary`2::Add
02c9e04c: mov     x1, x24                                    
02c9e050: ldr     x3, [x27]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9e054: bl      #0x452c61c                                 fn_452c61c
02c9e058: fmul    s10, s10, s11                              
02c9e05c: ldr     x8, [x25]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9e060: add     x0, sp, #0x18                              
02c9e064: ldr     x8, [x8, #0xb8]                            
02c9e068: fcvt    d0, s10                                    
02c9e06c: ldr     x24, [x8, #0x1b8]                          
02c9e070: bl      #0x5e902c0                                 fn_5e902c0
02c9e074: fcmp    s10, #0.0                                  
02c9e078: b.ge    #0x2c9e094                                 
02c9e07c: fmov    d1, #-0.50000000                           
02c9e080: fcmp    d0, d1                                     
02c9e084: b.ne    #0x2c9e0c0                                 
02c9e088: ldr     d0, [sp, #0x18]                            
02c9e08c: fmov    s2, #-1.00000000                           
02c9e090: b       #0x2c9e0a8                                 
02c9e094: fmov    d1, #0.50000000                            
02c9e098: fcmp    d0, d1                                     
02c9e09c: b.ne    #0x2c9e0d0                                 
02c9e0a0: ldr     d0, [sp, #0x18]                            
02c9e0a4: fmov    s2, #1.00000000                            
02c9e0a8: fcvt    s1, d0                                     
02c9e0ac: fcvtzs  x8, d0                                     
02c9e0b0: fadd    s0, s1, s2                                 
02c9e0b4: tst     x8, #1                                     
02c9e0b8: fcsel   s0, s1, s0, eq                             
02c9e0bc: b       #0x2c9e0dc                                 
02c9e0c0: fmov    s0, #-0.50000000                           
02c9e0c4: fadd    s0, s10, s0                                
02c9e0c8: frintp  s0, s0                                     
02c9e0cc: b       #0x2c9e0dc                                 
02c9e0d0: fmov    s0, #0.50000000                            
02c9e0d4: fadd    s0, s10, s0                                
02c9e0d8: frintm  s0, s0                                     
02c9e0dc: fmov    s10, #10.00000000                          
02c9e0e0: ldr     x0, [x26, #0x78]                           &2c498b4(=d65f03c0d503245f)
02c9e0e4: add     x1, sp, #0x10                              
02c9e0e8: fdiv    s0, s0, s10                                
02c9e0ec: str     s0, [sp, #0x10]                            
02c9e0f0: bl      #0x2b70f38                                 fn_2b70f38
02c9e0f4: ldr     x3, [x27]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9e0f8: mov     x2, x0                                     
02c9e0fc: mov     x0, x22                                    
02c9e100: mov     x1, x24                                    
02c9e104: bl      #0x452c61c                                 fn_452c61c
02c9e108: fmul    s9, s9, s10                                
02c9e10c: ldr     x8, [x25]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9e110: add     x0, sp, #0x18                              
02c9e114: ldr     x8, [x8, #0xb8]                            
02c9e118: fcvt    d0, s9                                     
02c9e11c: ldr     x24, [x8, #0x1c0]                          
02c9e120: bl      #0x5e902c0                                 fn_5e902c0
02c9e124: fcmp    s9, #0.0                                   
02c9e128: b.ge    #0x2c9e144                                 
02c9e12c: fmov    d1, #-0.50000000                           
02c9e130: fcmp    d0, d1                                     
02c9e134: b.ne    #0x2c9e170                                 
02c9e138: ldr     d0, [sp, #0x18]                            
02c9e13c: fmov    s2, #-1.00000000                           
02c9e140: b       #0x2c9e158                                 
02c9e144: fmov    d1, #0.50000000                            
02c9e148: fcmp    d0, d1                                     
02c9e14c: b.ne    #0x2c9e180                                 
02c9e150: ldr     d0, [sp, #0x18]                            
02c9e154: fmov    s2, #1.00000000                            
02c9e158: fcvt    s1, d0                                     
02c9e15c: fcvtzs  x8, d0                                     
02c9e160: fadd    s0, s1, s2                                 
02c9e164: tst     x8, #1                                     
02c9e168: fcsel   s0, s1, s0, eq                             
02c9e16c: b       #0x2c9e18c                                 
02c9e170: fmov    s0, #-0.50000000                           
02c9e174: fadd    s0, s9, s0                                 
02c9e178: frintp  s0, s0                                     
02c9e17c: b       #0x2c9e18c                                 
02c9e180: fmov    s0, #0.50000000                            
02c9e184: fadd    s0, s9, s0                                 
02c9e188: frintm  s0, s0                                     
02c9e18c: fmov    s9, #10.00000000                           
02c9e190: ldr     x0, [x26, #0x78]                           &2c498b4(=d65f03c0d503245f)
02c9e194: add     x1, sp, #0xc                               
02c9e198: fdiv    s0, s0, s9                                 
02c9e19c: str     s0, [sp, #0xc]                             
02c9e1a0: bl      #0x2b70f38                                 fn_2b70f38
02c9e1a4: ldr     x3, [x27]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9e1a8: mov     x2, x0                                     
02c9e1ac: mov     x0, x22                                    
02c9e1b0: mov     x1, x24                                    
02c9e1b4: bl      #0x452c61c                                 fn_452c61c
02c9e1b8: fmul    s8, s8, s9                                 
02c9e1bc: ldr     x8, [x25]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9e1c0: add     x0, sp, #0x18                              
02c9e1c4: ldr     x8, [x8, #0xb8]                            
02c9e1c8: fcvt    d0, s8                                     
02c9e1cc: ldr     x24, [x8, #0x1c8]                          
02c9e1d0: bl      #0x5e902c0                                 fn_5e902c0
02c9e1d4: fcmp    s8, #0.0                                   
02c9e1d8: b.ge    #0x2c9e1f4                                 
02c9e1dc: fmov    d1, #-0.50000000                           
02c9e1e0: fcmp    d0, d1                                     
02c9e1e4: b.ne    #0x2c9e220                                 
02c9e1e8: ldr     d0, [sp, #0x18]                            
02c9e1ec: fmov    s2, #-1.00000000                           
02c9e1f0: b       #0x2c9e208                                 
02c9e1f4: fmov    d1, #0.50000000                            
02c9e1f8: fcmp    d0, d1                                     
02c9e1fc: b.ne    #0x2c9e230                                 
02c9e200: ldr     d0, [sp, #0x18]                            
02c9e204: fmov    s2, #1.00000000                            
02c9e208: fcvt    s1, d0                                     
02c9e20c: fcvtzs  x8, d0                                     
02c9e210: fadd    s0, s1, s2                                 
02c9e214: tst     x8, #1                                     
02c9e218: fcsel   s0, s1, s0, eq                             
02c9e21c: b       #0x2c9e23c                                 
02c9e220: fmov    s0, #-0.50000000                           
02c9e224: fadd    s0, s8, s0                                 
02c9e228: frintp  s0, s0                                     
02c9e22c: b       #0x2c9e23c                                 
02c9e230: fmov    s0, #0.50000000                            
02c9e234: fadd    s0, s8, s0                                 
02c9e238: frintm  s0, s0                                     
02c9e23c: fmov    s1, #10.00000000                           
02c9e240: ldr     x0, [x26, #0x78]                           &2c498b4(=d65f03c0d503245f)
02c9e244: add     x1, sp, #0x18                              
02c9e248: fdiv    s0, s0, s1                                 
02c9e24c: str     s0, [sp, #0x18]                            
02c9e250: bl      #0x2b70f38                                 fn_2b70f38
02c9e254: ldr     x3, [x27]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9e258: mov     x2, x0                                     
02c9e25c: mov     x0, x22                                    
02c9e260: mov     x1, x24                                    
02c9e264: bl      #0x452c61c                                 fn_452c61c
02c9e268: ldr     x8, [x25]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9e26c: ldr     x0, [x26, #0x48]                           &6263098(=0)
02c9e270: add     x1, sp, #8                                 
02c9e274: str     w23, [sp, #8]                              
02c9e278: ldr     x8, [x8, #0xb8]                            
02c9e27c: ldr     x24, [x8, #0x1d0]                          
02c9e280: bl      #0x2b70f38                                 fn_2b70f38
02c9e284: ldr     x3, [x27]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9e288: mov     x2, x0                                     
02c9e28c: mov     x0, x22                                    
02c9e290: mov     x1, x24                                    
02c9e294: bl      #0x452c61c                                 fn_452c61c
02c9e298: ldr     x8, [x25]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9e29c: ldr     x3, [x27]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9e2a0: mov     x0, x22                                    
02c9e2a4: mov     x2, x21                                    
02c9e2a8: ldr     x8, [x8, #0xb8]                            
02c9e2ac: ldr     x1, [x8, #0xd8]                            
02c9e2b0: bl      #0x452c61c                                 fn_452c61c
02c9e2b4: ldr     x8, [x25]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9e2b8: ldr     x3, [x27]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9e2bc: mov     x0, x22                                    
02c9e2c0: mov     x2, x20                                    
02c9e2c4: ldr     x8, [x8, #0xb8]                            
02c9e2c8: ldr     x1, [x8, #0x1d8]                           
02c9e2cc: bl      #0x452c61c                                 fn_452c61c
02c9e2d0: ldr     x8, [x25]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9e2d4: ldr     x0, [x26, #0x48]                           &6263098(=0)
02c9e2d8: add     x1, sp, #4                                 
02c9e2dc: str     w19, [sp, #4]                              
02c9e2e0: ldr     x8, [x8, #0xb8]                            
02c9e2e4: ldr     x20, [x8, #0xc0]                           
02c9e2e8: bl      #0x2b70f38                                 fn_2b70f38
02c9e2ec: ldr     x3, [x27]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9e2f0: mov     x2, x0                                     
02c9e2f4: mov     x0, x22                                    
02c9e2f8: mov     x1, x20                                    
02c9e2fc: bl      #0x452c61c                                 fn_452c61c
02c9e300: ldr     x8, [x25]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9e304: mov     x1, x22                                    
02c9e308: mov     x2, xzr                                    
02c9e30c: ldr     x8, [x8, #0xb8]                            
02c9e310: ldr     x0, [x8, #0xb0]                            
02c9e314: bl      #0x2d77fe8                                 WejoyService.Tracking.TrackingManager::LogEvent
02c9e318: ldp     x20, x19, [sp, #0x80]                      
02c9e31c: ldp     x22, x21, [sp, #0x70]                      
02c9e320: ldp     x24, x23, [sp, #0x60]                      
02c9e324: ldp     x26, x25, [sp, #0x50]                      
02c9e328: ldp     x30, x27, [sp, #0x40]                      
02c9e32c: ldp     d9, d8, [sp, #0x30]                        
02c9e330: ldp     d11, d10, [sp, #0x20]                      
02c9e334: add     sp, sp, #0x90                              
02c9e338: ret                                                
02c9e33c: bl      #0x2b7105c                                 fn_2b7105c
## TradingEnter(string entrySource) -> void
---- DevTrack::TradingEnter 0x2c9e340
02c9e340: stp     x30, x23, [sp, #-0x30]!                    
02c9e344: stp     x22, x21, [sp, #0x10]                      
02c9e348: stp     x20, x19, [sp, #0x20]                      
02c9e34c: adrp    x20, #0x662f000                            
02c9e350: adrp    x22, #0x6265000                            
02c9e354: mov     x19, x0                                    
02c9e358: ldrb    w8, [x20, #0xa6c]                          
02c9e35c: ldr     x22, [x22, #0xb38]                         T:DevTrack
02c9e360: tbnz    w8, #0, #0x2c9e39c                         
02c9e364: adrp    x0, #0x6265000                             
02c9e368: ldr     x0, [x0, #0xb38]                           T:DevTrack
02c9e36c: bl      #0x2b70db0                                 fn_2b70db0
02c9e370: adrp    x0, #0x6265000                             
02c9e374: ldr     x0, [x0, #0xb40]                           MS:System.Collections.Generic.Dictionary`2::Add
02c9e378: bl      #0x2b70db0                                 fn_2b70db0
02c9e37c: adrp    x0, #0x6263000                             
02c9e380: ldr     x0, [x0, #0x9a0]                           MS:System.Collections.Generic.Dictionary`2::.ctor
02c9e384: bl      #0x2b70db0                                 fn_2b70db0
02c9e388: adrp    x0, #0x6263000                             
02c9e38c: ldr     x0, [x0, #0x938]                           T:type8922(k15)
02c9e390: bl      #0x2b70db0                                 fn_2b70db0
02c9e394: mov     w8, #1                                     
02c9e398: strb    w8, [x20, #0xa6c]                          
02c9e39c: ldr     x0, [x22]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9e3a0: adrp    x23, #0x6263000                            
02c9e3a4: adrp    x21, #0x6263000                            
02c9e3a8: ldr     x23, [x23, #0x938]                         T:type8922(k15)
02c9e3ac: ldr     w8, [x0, #0xe4]                            [62630e4]=0 f=0,0
02c9e3b0: ldr     x21, [x21, #0x9a0]                         MS:System.Collections.Generic.Dictionary`2::.ctor
02c9e3b4: cbnz    w8, #0x2c9e3c0                             
02c9e3b8: bl      #0x2b70f30                                 fn_2b70f30
02c9e3bc: ldr     x0, [x22]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9e3c0: ldr     x8, [x0, #0xb8]                            &6263108(=0) .tutorial_id
02c9e3c4: ldr     x0, [x23]                                  &2c5bbd4(=a9bd7bfdd503233f)
02c9e3c8: ldr     x20, [x8, #0x3b8]                          
02c9e3cc: bl      #0x2b7104c                                 fn_2b7104c
02c9e3d0: ldr     x1, [x21]                                  &2c5bbd4(=a9bd7bfdd503233f)
02c9e3d4: mov     x21, x0                                    
02c9e3d8: bl      #0x452b8a0                                 fn_452b8a0
02c9e3dc: cbz     x21, #0x2c9e420                            
02c9e3e0: ldr     x8, [x22]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9e3e4: adrp    x9, #0x6265000                             
02c9e3e8: mov     x0, x21                                    
02c9e3ec: ldr     x9, [x9, #0xb40]                           MS:System.Collections.Generic.Dictionary`2::Add
02c9e3f0: mov     x2, x19                                    
02c9e3f4: ldr     x8, [x8, #0xb8]                            
02c9e3f8: ldr     x3, [x9]                                   M:AdsManager::<OnApplicationPause>b__26_0
02c9e3fc: ldr     x1, [x8, #0x3f0]                           
02c9e400: bl      #0x452c61c                                 fn_452c61c
02c9e404: mov     x0, x20                                    
02c9e408: mov     x1, x21                                    
02c9e40c: mov     x2, xzr                                    
02c9e410: ldp     x20, x19, [sp, #0x20]                      
02c9e414: ldp     x22, x21, [sp, #0x10]                      
02c9e418: ldp     x30, x23, [sp], #0x30                      
02c9e41c: b       #0x2d77fe8                                 WejoyService.Tracking.TrackingManager::LogEvent
02c9e420: bl      #0x2b7105c                                 fn_2b7105c
## TradingItemSelect(string sideName, int itemId, int itemValue) -> void
---- DevTrack::TradingItemSelect 0x2c9e424
02c9e424: str     x30, [sp, #-0x50]!                         
02c9e428: stp     x26, x25, [sp, #0x10]                      
02c9e42c: stp     x24, x23, [sp, #0x20]                      
02c9e430: stp     x22, x21, [sp, #0x30]                      
02c9e434: stp     x20, x19, [sp, #0x40]                      
02c9e438: adrp    x21, #0x662f000                            
02c9e43c: adrp    x24, #0x6265000                            
02c9e440: mov     w19, w2                                    
02c9e444: ldrb    w8, [x21, #0xa6d]                          
02c9e448: ldr     x24, [x24, #0xb38]                         T:DevTrack
02c9e44c: mov     w20, w1                                    
02c9e450: mov     x22, x0                                    
02c9e454: tbnz    w8, #0, #0x2c9e490                         
02c9e458: adrp    x0, #0x6265000                             
02c9e45c: ldr     x0, [x0, #0xb38]                           T:DevTrack
02c9e460: bl      #0x2b70db0                                 fn_2b70db0
02c9e464: adrp    x0, #0x6265000                             
02c9e468: ldr     x0, [x0, #0xb40]                           MS:System.Collections.Generic.Dictionary`2::Add
02c9e46c: bl      #0x2b70db0                                 fn_2b70db0
02c9e470: adrp    x0, #0x6263000                             
02c9e474: ldr     x0, [x0, #0x9a0]                           MS:System.Collections.Generic.Dictionary`2::.ctor
02c9e478: bl      #0x2b70db0                                 fn_2b70db0
02c9e47c: adrp    x0, #0x6263000                             
02c9e480: ldr     x0, [x0, #0x938]                           T:type8922(k15)
02c9e484: bl      #0x2b70db0                                 fn_2b70db0
02c9e488: mov     w8, #1                                     
02c9e48c: strb    w8, [x21, #0xa6d]                          
02c9e490: ldr     x0, [x24]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9e494: adrp    x25, #0x6263000                            
02c9e498: adrp    x23, #0x6263000                            
02c9e49c: ldr     x25, [x25, #0x938]                         T:type8922(k15)
02c9e4a0: ldr     w8, [x0, #0xe4]                            [62630e4]=0 f=0,0
02c9e4a4: ldr     x23, [x23, #0x9a0]                         MS:System.Collections.Generic.Dictionary`2::.ctor
02c9e4a8: cbnz    w8, #0x2c9e4b4                             
02c9e4ac: bl      #0x2b70f30                                 fn_2b70f30
02c9e4b0: ldr     x0, [x24]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9e4b4: ldr     x8, [x0, #0xb8]                            &6263108(=0) .tutorial_id
02c9e4b8: ldr     x0, [x25]                                  &2c5bbd4(=a9bd7bfdd503233f)
02c9e4bc: ldr     x21, [x8, #0x3c0]                          
02c9e4c0: bl      #0x2b7104c                                 fn_2b7104c
02c9e4c4: ldr     x1, [x23]                                  &2c5bbd4(=a9bd7bfdd503233f)
02c9e4c8: mov     x23, x0                                    
02c9e4cc: bl      #0x452b8a0                                 fn_452b8a0
02c9e4d0: cbz     x23, #0x2c9e588                            
02c9e4d4: ldr     x8, [x24]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9e4d8: adrp    x25, #0x6265000                            
02c9e4dc: mov     x0, x23                                    
02c9e4e0: ldr     x25, [x25, #0xb40]                         MS:System.Collections.Generic.Dictionary`2::Add
02c9e4e4: mov     x2, x22                                    
02c9e4e8: ldr     x8, [x8, #0xb8]                            
02c9e4ec: ldr     x3, [x25]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9e4f0: ldr     x1, [x8, #0x3f8]                           
02c9e4f4: bl      #0x452c61c                                 fn_452c61c
02c9e4f8: ldr     x8, [x24]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9e4fc: adrp    x26, #0x6263000                            
02c9e500: add     x1, sp, #0xc                               
02c9e504: ldr     x8, [x8, #0xb8]                            
02c9e508: ldr     x26, [x26, #0x970]                         &6645c70(=0)
02c9e50c: str     w20, [sp, #0xc]                            
02c9e510: ldr     x0, [x26, #0x48]                           &6263098(=0)
02c9e514: ldr     x22, [x8, #0x118]                          
02c9e518: bl      #0x2b70f38                                 fn_2b70f38
02c9e51c: ldr     x3, [x25]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9e520: mov     x2, x0                                     
02c9e524: mov     x0, x23                                    
02c9e528: mov     x1, x22                                    
02c9e52c: bl      #0x452c61c                                 fn_452c61c
02c9e530: ldr     x8, [x24]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9e534: ldr     x0, [x26, #0x48]                           &6263098(=0)
02c9e538: add     x1, sp, #8                                 
02c9e53c: str     w19, [sp, #8]                              
02c9e540: ldr     x8, [x8, #0xb8]                            
02c9e544: ldr     x20, [x8, #0x400]                          
02c9e548: bl      #0x2b70f38                                 fn_2b70f38
02c9e54c: ldr     x3, [x25]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9e550: mov     x2, x0                                     
02c9e554: mov     x0, x23                                    
02c9e558: mov     x1, x20                                    
02c9e55c: bl      #0x452c61c                                 fn_452c61c
02c9e560: mov     x0, x21                                    
02c9e564: mov     x1, x23                                    
02c9e568: mov     x2, xzr                                    
02c9e56c: bl      #0x2d77fe8                                 WejoyService.Tracking.TrackingManager::LogEvent
02c9e570: ldp     x20, x19, [sp, #0x40]                      
02c9e574: ldp     x22, x21, [sp, #0x30]                      
02c9e578: ldp     x24, x23, [sp, #0x20]                      
02c9e57c: ldp     x26, x25, [sp, #0x10]                      
02c9e580: ldr     x30, [sp], #0x50                           
02c9e584: ret                                                
02c9e588: bl      #0x2b7105c                                 fn_2b7105c
## TradingAddMore(int requestIndex, string npcResponse, int offerValueBefore, int offerValueAfter) -> void
---- DevTrack::TradingAddMore 0x2c9e58c
02c9e58c: sub     sp, sp, #0x60                              
02c9e590: stp     x30, x27, [sp, #0x10]                      
02c9e594: stp     x26, x25, [sp, #0x20]                      
02c9e598: stp     x24, x23, [sp, #0x30]                      
02c9e59c: stp     x22, x21, [sp, #0x40]                      
02c9e5a0: stp     x20, x19, [sp, #0x50]                      
02c9e5a4: adrp    x22, #0x662f000                            
02c9e5a8: adrp    x26, #0x6265000                            
02c9e5ac: mov     w19, w3                                    
02c9e5b0: ldrb    w8, [x22, #0xa6e]                          
02c9e5b4: ldr     x26, [x26, #0xb38]                         T:DevTrack
02c9e5b8: mov     w20, w2                                    
02c9e5bc: mov     x21, x1                                    
02c9e5c0: mov     w24, w0                                    
02c9e5c4: tbnz    w8, #0, #0x2c9e600                         
02c9e5c8: adrp    x0, #0x6265000                             
02c9e5cc: ldr     x0, [x0, #0xb38]                           T:DevTrack
02c9e5d0: bl      #0x2b70db0                                 fn_2b70db0
02c9e5d4: adrp    x0, #0x6265000                             
02c9e5d8: ldr     x0, [x0, #0xb40]                           MS:System.Collections.Generic.Dictionary`2::Add
02c9e5dc: bl      #0x2b70db0                                 fn_2b70db0
02c9e5e0: adrp    x0, #0x6263000                             
02c9e5e4: ldr     x0, [x0, #0x9a0]                           MS:System.Collections.Generic.Dictionary`2::.ctor
02c9e5e8: bl      #0x2b70db0                                 fn_2b70db0
02c9e5ec: adrp    x0, #0x6263000                             
02c9e5f0: ldr     x0, [x0, #0x938]                           T:type8922(k15)
02c9e5f4: bl      #0x2b70db0                                 fn_2b70db0
02c9e5f8: mov     w8, #1                                     
02c9e5fc: strb    w8, [x22, #0xa6e]                          
02c9e600: ldr     x0, [x26]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9e604: adrp    x25, #0x6263000                            
02c9e608: adrp    x23, #0x6263000                            
02c9e60c: ldr     x25, [x25, #0x938]                         T:type8922(k15)
02c9e610: ldr     w8, [x0, #0xe4]                            [62630e4]=0 f=0,0
02c9e614: ldr     x23, [x23, #0x9a0]                         MS:System.Collections.Generic.Dictionary`2::.ctor
02c9e618: cbnz    w8, #0x2c9e624                             
02c9e61c: bl      #0x2b70f30                                 fn_2b70f30
02c9e620: ldr     x0, [x26]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9e624: ldr     x8, [x0, #0xb8]                            &6263108(=0) .tutorial_id
02c9e628: ldr     x0, [x25]                                  &2c5bbd4(=a9bd7bfdd503233f)
02c9e62c: ldr     x22, [x8, #0x3c8]                          
02c9e630: bl      #0x2b7104c                                 fn_2b7104c
02c9e634: ldr     x1, [x23]                                  &2c5bbd4(=a9bd7bfdd503233f)
02c9e638: mov     x23, x0                                    
02c9e63c: bl      #0x452b8a0                                 fn_452b8a0
02c9e640: ldr     x8, [x26]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9e644: adrp    x27, #0x6263000                            
02c9e648: add     x1, sp, #0xc                               
02c9e64c: ldr     x8, [x8, #0xb8]                            
02c9e650: ldr     x27, [x27, #0x970]                         &6645c70(=0)
02c9e654: str     w24, [sp, #0xc]                            
02c9e658: ldr     x0, [x27, #0x48]                           &6263098(=0)
02c9e65c: ldr     x25, [x8, #0x408]                          
02c9e660: bl      #0x2b70f38                                 fn_2b70f38
02c9e664: cbz     x23, #0x2c9e72c                            
02c9e668: adrp    x24, #0x6265000                            
02c9e66c: mov     x2, x0                                     
02c9e670: mov     x0, x23                                    
02c9e674: ldr     x24, [x24, #0xb40]                         MS:System.Collections.Generic.Dictionary`2::Add
02c9e678: mov     x1, x25                                    
02c9e67c: ldr     x3, [x24]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9e680: bl      #0x452c61c                                 fn_452c61c
02c9e684: ldr     x8, [x26]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9e688: ldr     x3, [x24]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9e68c: mov     x0, x23                                    
02c9e690: mov     x2, x21                                    
02c9e694: ldr     x8, [x8, #0xb8]                            
02c9e698: ldr     x1, [x8, #0x410]                           
02c9e69c: bl      #0x452c61c                                 fn_452c61c
02c9e6a0: ldr     x8, [x26]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9e6a4: ldr     x0, [x27, #0x48]                           &6263098(=0)
02c9e6a8: add     x1, sp, #8                                 
02c9e6ac: str     w20, [sp, #8]                              
02c9e6b0: ldr     x8, [x8, #0xb8]                            
02c9e6b4: ldr     x21, [x8, #0x418]                          
02c9e6b8: bl      #0x2b70f38                                 fn_2b70f38
02c9e6bc: ldr     x3, [x24]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9e6c0: mov     x2, x0                                     
02c9e6c4: mov     x0, x23                                    
02c9e6c8: mov     x1, x21                                    
02c9e6cc: bl      #0x452c61c                                 fn_452c61c
02c9e6d0: ldr     x8, [x26]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9e6d4: ldr     x0, [x27, #0x48]                           &6263098(=0)
02c9e6d8: add     x1, sp, #4                                 
02c9e6dc: str     w19, [sp, #4]                              
02c9e6e0: ldr     x8, [x8, #0xb8]                            
02c9e6e4: ldr     x20, [x8, #0x420]                          
02c9e6e8: bl      #0x2b70f38                                 fn_2b70f38
02c9e6ec: ldr     x3, [x24]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9e6f0: mov     x2, x0                                     
02c9e6f4: mov     x0, x23                                    
02c9e6f8: mov     x1, x20                                    
02c9e6fc: bl      #0x452c61c                                 fn_452c61c
02c9e700: mov     x0, x22                                    
02c9e704: mov     x1, x23                                    
02c9e708: mov     x2, xzr                                    
02c9e70c: bl      #0x2d77fe8                                 WejoyService.Tracking.TrackingManager::LogEvent
02c9e710: ldp     x20, x19, [sp, #0x50]                      
02c9e714: ldp     x22, x21, [sp, #0x40]                      
02c9e718: ldp     x24, x23, [sp, #0x30]                      
02c9e71c: ldp     x26, x25, [sp, #0x20]                      
02c9e720: ldp     x30, x27, [sp, #0x10]                      
02c9e724: add     sp, sp, #0x60                              
02c9e728: ret                                                
02c9e72c: bl      #0x2b7105c                                 fn_2b7105c
## TradingCounterRequest(int counterRequestIndex, bool isAccepted) -> void
---- DevTrack::TradingCounterRequest 0x2c9e730
02c9e730: str     x30, [sp, #-0x50]!                         
02c9e734: stp     x26, x25, [sp, #0x10]                      
02c9e738: stp     x24, x23, [sp, #0x20]                      
02c9e73c: stp     x22, x21, [sp, #0x30]                      
02c9e740: stp     x20, x19, [sp, #0x40]                      
02c9e744: adrp    x20, #0x662f000                            
02c9e748: adrp    x24, #0x6265000                            
02c9e74c: mov     w19, w1                                    
02c9e750: ldrb    w8, [x20, #0xa6f]                          
02c9e754: ldr     x24, [x24, #0xb38]                         T:DevTrack
02c9e758: mov     w21, w0                                    
02c9e75c: tbnz    w8, #0, #0x2c9e798                         
02c9e760: adrp    x0, #0x6265000                             
02c9e764: ldr     x0, [x0, #0xb38]                           T:DevTrack
02c9e768: bl      #0x2b70db0                                 fn_2b70db0
02c9e76c: adrp    x0, #0x6265000                             
02c9e770: ldr     x0, [x0, #0xb40]                           MS:System.Collections.Generic.Dictionary`2::Add
02c9e774: bl      #0x2b70db0                                 fn_2b70db0
02c9e778: adrp    x0, #0x6263000                             
02c9e77c: ldr     x0, [x0, #0x9a0]                           MS:System.Collections.Generic.Dictionary`2::.ctor
02c9e780: bl      #0x2b70db0                                 fn_2b70db0
02c9e784: adrp    x0, #0x6263000                             
02c9e788: ldr     x0, [x0, #0x938]                           T:type8922(k15)
02c9e78c: bl      #0x2b70db0                                 fn_2b70db0
02c9e790: mov     w8, #1                                     
02c9e794: strb    w8, [x20, #0xa6f]                          
02c9e798: ldr     x0, [x24]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9e79c: adrp    x23, #0x6263000                            
02c9e7a0: adrp    x22, #0x6263000                            
02c9e7a4: ldr     x23, [x23, #0x938]                         T:type8922(k15)
02c9e7a8: ldr     w8, [x0, #0xe4]                            [62630e4]=0 f=0,0
02c9e7ac: ldr     x22, [x22, #0x9a0]                         MS:System.Collections.Generic.Dictionary`2::.ctor
02c9e7b0: cbnz    w8, #0x2c9e7bc                             
02c9e7b4: bl      #0x2b70f30                                 fn_2b70f30
02c9e7b8: ldr     x0, [x24]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9e7bc: ldr     x8, [x0, #0xb8]                            &6263108(=0) .tutorial_id
02c9e7c0: ldr     x0, [x23]                                  &2c5bbd4(=a9bd7bfdd503233f)
02c9e7c4: ldr     x20, [x8, #0x3d0]                          
02c9e7c8: bl      #0x2b7104c                                 fn_2b7104c
02c9e7cc: ldr     x1, [x22]                                  &2c5bbd4(=a9bd7bfdd503233f)
02c9e7d0: mov     x22, x0                                    
02c9e7d4: bl      #0x452b8a0                                 fn_452b8a0
02c9e7d8: ldr     x8, [x24]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9e7dc: adrp    x25, #0x6263000                            
02c9e7e0: add     x1, sp, #0xc                               
02c9e7e4: ldr     x8, [x8, #0xb8]                            
02c9e7e8: ldr     x25, [x25, #0x970]                         &6645c70(=0)
02c9e7ec: str     w21, [sp, #0xc]                            
02c9e7f0: ldr     x0, [x25, #0x48]                           &6263098(=0)
02c9e7f4: ldr     x23, [x8, #0x428]                          
02c9e7f8: bl      #0x2b70f38                                 fn_2b70f38
02c9e7fc: cbz     x22, #0x2c9e878                            
02c9e800: adrp    x26, #0x6265000                            
02c9e804: mov     x2, x0                                     
02c9e808: mov     x0, x22                                    
02c9e80c: ldr     x26, [x26, #0xb40]                         MS:System.Collections.Generic.Dictionary`2::Add
02c9e810: mov     x1, x23                                    
02c9e814: ldr     x3, [x26]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9e818: bl      #0x452c61c                                 fn_452c61c
02c9e81c: ldr     x8, [x24]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9e820: ldr     x0, [x25, #0x48]                           &6263098(=0)
02c9e824: add     x1, sp, #8                                 
02c9e828: ldr     x8, [x8, #0xb8]                            
02c9e82c: ldr     x21, [x8, #0x430]                          
02c9e830: and     w8, w19, #1                                
02c9e834: str     w8, [sp, #8]                               
02c9e838: bl      #0x2b70f38                                 fn_2b70f38
02c9e83c: ldr     x3, [x26]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9e840: mov     x2, x0                                     
02c9e844: mov     x0, x22                                    
02c9e848: mov     x1, x21                                    
02c9e84c: bl      #0x452c61c                                 fn_452c61c
02c9e850: mov     x0, x20                                    
02c9e854: mov     x1, x22                                    
02c9e858: mov     x2, xzr                                    
02c9e85c: bl      #0x2d77fe8                                 WejoyService.Tracking.TrackingManager::LogEvent
02c9e860: ldp     x20, x19, [sp, #0x40]                      
02c9e864: ldp     x22, x21, [sp, #0x30]                      
02c9e868: ldp     x24, x23, [sp, #0x20]                      
02c9e86c: ldp     x26, x25, [sp, #0x10]                      
02c9e870: ldr     x30, [sp], #0x50                           
02c9e874: ret                                                
02c9e878: bl      #0x2b7105c                                 fn_2b7105c
## TradingComplete(int yourValue, int npcValue, float tradePercent, int itemCountGiven, int itemCountReceived) -> void
---- DevTrack::TradingComplete 0x2c9e87c
02c9e87c: sub     sp, sp, #0x80                              
02c9e880: stp     d9, d8, [sp, #0x10]                        
02c9e884: str     x30, [sp, #0x20]                           
02c9e888: stp     x28, x27, [sp, #0x30]                      
02c9e88c: stp     x26, x25, [sp, #0x40]                      
02c9e890: stp     x24, x23, [sp, #0x50]                      
02c9e894: stp     x22, x21, [sp, #0x60]                      
02c9e898: stp     x20, x19, [sp, #0x70]                      
02c9e89c: fmov    s8, s0                                     
02c9e8a0: adrp    x21, #0x662f000                            
02c9e8a4: adrp    x26, #0x6265000                            
02c9e8a8: ldrb    w8, [x21, #0xa70]                          
02c9e8ac: ldr     x26, [x26, #0xb38]                         T:DevTrack
02c9e8b0: mov     w19, w3                                    
02c9e8b4: mov     w20, w2                                    
02c9e8b8: mov     w23, w1                                    
02c9e8bc: mov     w24, w0                                    
02c9e8c0: tbnz    w8, #0, #0x2c9e8fc                         
02c9e8c4: adrp    x0, #0x6265000                             
02c9e8c8: ldr     x0, [x0, #0xb38]                           T:DevTrack
02c9e8cc: bl      #0x2b70db0                                 fn_2b70db0
02c9e8d0: adrp    x0, #0x6265000                             
02c9e8d4: ldr     x0, [x0, #0xb40]                           MS:System.Collections.Generic.Dictionary`2::Add
02c9e8d8: bl      #0x2b70db0                                 fn_2b70db0
02c9e8dc: adrp    x0, #0x6263000                             
02c9e8e0: ldr     x0, [x0, #0x9a0]                           MS:System.Collections.Generic.Dictionary`2::.ctor
02c9e8e4: bl      #0x2b70db0                                 fn_2b70db0
02c9e8e8: adrp    x0, #0x6263000                             
02c9e8ec: ldr     x0, [x0, #0x938]                           T:type8922(k15)
02c9e8f0: bl      #0x2b70db0                                 fn_2b70db0
02c9e8f4: mov     w8, #1                                     
02c9e8f8: strb    w8, [x21, #0xa70]                          
02c9e8fc: ldr     x0, [x26]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9e900: adrp    x25, #0x6263000                            
02c9e904: adrp    x22, #0x6263000                            
02c9e908: ldr     x25, [x25, #0x938]                         T:type8922(k15)
02c9e90c: ldr     w8, [x0, #0xe4]                            [62630e4]=0 f=0,0
02c9e910: ldr     x22, [x22, #0x9a0]                         MS:System.Collections.Generic.Dictionary`2::.ctor
02c9e914: cbnz    w8, #0x2c9e920                             
02c9e918: bl      #0x2b70f30                                 fn_2b70f30
02c9e91c: ldr     x0, [x26]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9e920: ldr     x8, [x0, #0xb8]                            &6263108(=0) .tutorial_id
02c9e924: ldr     x0, [x25]                                  &2c5bbd4(=a9bd7bfdd503233f)
02c9e928: ldr     x21, [x8, #0x3d8]                          
02c9e92c: bl      #0x2b7104c                                 fn_2b7104c
02c9e930: ldr     x1, [x22]                                  &2c5bbd4(=a9bd7bfdd503233f)
02c9e934: mov     x22, x0                                    
02c9e938: bl      #0x452b8a0                                 fn_452b8a0
02c9e93c: ldr     x8, [x26]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9e940: adrp    x27, #0x6263000                            
02c9e944: add     x1, sp, #0xc                               
02c9e948: ldr     x8, [x8, #0xb8]                            
02c9e94c: ldr     x27, [x27, #0x970]                         &6645c70(=0)
02c9e950: str     w24, [sp, #0xc]                            
02c9e954: ldr     x0, [x27, #0x48]                           &6263098(=0)
02c9e958: ldr     x25, [x8, #0x438]                          
02c9e95c: bl      #0x2b70f38                                 fn_2b70f38
02c9e960: cbz     x22, #0x2c9eb30                            
02c9e964: adrp    x28, #0x6265000                            
02c9e968: mov     x2, x0                                     
02c9e96c: mov     x0, x22                                    
02c9e970: ldr     x28, [x28, #0xb40]                         MS:System.Collections.Generic.Dictionary`2::Add
02c9e974: mov     x1, x25                                    
02c9e978: ldr     x3, [x28]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9e97c: bl      #0x452c61c                                 fn_452c61c
02c9e980: ldr     x8, [x26]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9e984: ldr     x0, [x27, #0x48]                           &6263098(=0)
02c9e988: add     x1, sp, #8                                 
02c9e98c: str     w23, [sp, #8]                              
02c9e990: ldr     x8, [x8, #0xb8]                            
02c9e994: ldr     x24, [x8, #0x440]                          
02c9e998: bl      #0x2b70f38                                 fn_2b70f38
02c9e99c: ldr     x3, [x28]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9e9a0: mov     x2, x0                                     
02c9e9a4: mov     x0, x22                                    
02c9e9a8: mov     x1, x24                                    
02c9e9ac: bl      #0x452c61c                                 fn_452c61c
02c9e9b0: ldr     x8, [x26]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9e9b4: adrp    x24, #0x662f000                            
02c9e9b8: ldrb    w9, [x24, #0xa8a]                          
02c9e9bc: ldr     x8, [x8, #0xb8]                            
02c9e9c0: ldr     x23, [x8, #0x448]                          
02c9e9c4: cbnz    w9, #0x2c9e9dc                             
02c9e9c8: adrp    x0, #0x6265000                             
02c9e9cc: ldr     x0, [x0, #0xb48]                           T:System.Math
02c9e9d0: bl      #0x2b70db0                                 fn_2b70db0
02c9e9d4: mov     w8, #1                                     
02c9e9d8: strb    w8, [x24, #0xa8a]                          
02c9e9dc: adrp    x8, #0x6265000                             
02c9e9e0: ldr     x8, [x8, #0xb48]                           T:System.Math
02c9e9e4: ldr     x0, [x8]                                   M:AdsManager::<OnApplicationPause>b__26_0
02c9e9e8: ldr     w8, [x0, #0xe4]                            [62650e4]=0 f=0,0
02c9e9ec: cbnz    w8, #0x2c9e9f4                             
02c9e9f0: bl      #0x2b70f30                                 fn_2b70f30
02c9e9f4: fcvt    d9, s8                                     
02c9e9f8: add     x0, sp, #0x28                              
02c9e9fc: fmov    d0, d9                                     
02c9ea00: bl      #0x5e902c0                                 fn_5e902c0
02c9ea04: fcmp    s8, #0.0                                   
02c9ea08: b.ge    #0x2c9ea24                                 
02c9ea0c: fmov    d1, #-0.50000000                           
02c9ea10: fcmp    d0, d1                                     
02c9ea14: b.ne    #0x2c9ea4c                                 
02c9ea18: ldr     d0, [sp, #0x28]                            
02c9ea1c: fmov    d1, #-1.00000000                           
02c9ea20: b       #0x2c9ea38                                 
02c9ea24: fmov    d1, #0.50000000                            
02c9ea28: fcmp    d0, d1                                     
02c9ea2c: b.ne    #0x2c9ea58                                 
02c9ea30: fmov    d1, #1.00000000                            
02c9ea34: ldr     d0, [sp, #0x28]                            
02c9ea38: fcvtzs  x8, d0                                     
02c9ea3c: fadd    d1, d0, d1                                 
02c9ea40: tst     x8, #1                                     
02c9ea44: fcsel   d0, d0, d1, eq                             
02c9ea48: b       #0x2c9ea60                                 
02c9ea4c: fadd    d0, d9, d1                                 
02c9ea50: frintp  d0, d0                                     
02c9ea54: b       #0x2c9ea60                                 
02c9ea58: fadd    d0, d9, d1                                 
02c9ea5c: frintm  d0, d0                                     
02c9ea60: mov     x8, #0x7ff0000000000000                    
02c9ea64: fcvtzs  w9, d0                                     
02c9ea68: ldr     x0, [x27, #0x48]                           &6263098(=0)
02c9ea6c: fmov    d1, x8                                     
02c9ea70: mov     w8, #-0xffffffff80000000                   
02c9ea74: add     x1, sp, #0x28                              
02c9ea78: fcmp    d0, d1                                     
02c9ea7c: csel    w8, w8, w9, eq                             
02c9ea80: str     w8, [sp, #0x28]                            
02c9ea84: bl      #0x2b70f38                                 fn_2b70f38
02c9ea88: ldr     x3, [x28]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9ea8c: mov     x2, x0                                     
02c9ea90: mov     x0, x22                                    
02c9ea94: mov     x1, x23                                    
02c9ea98: bl      #0x452c61c                                 fn_452c61c
02c9ea9c: ldr     x8, [x26]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9eaa0: ldr     x0, [x27, #0x48]                           &6263098(=0)
02c9eaa4: add     x1, sp, #4                                 
02c9eaa8: str     w20, [sp, #4]                              
02c9eaac: ldr     x8, [x8, #0xb8]                            T:AdsManager/<>c__DisplayClass42_0
02c9eab0: ldr     x23, [x8, #0x450]                          MS:WejoyService.Singleton`1::.ctor
02c9eab4: bl      #0x2b70f38                                 fn_2b70f38
02c9eab8: ldr     x3, [x28]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9eabc: mov     x2, x0                                     
02c9eac0: mov     x0, x22                                    
02c9eac4: mov     x1, x23                                    
02c9eac8: bl      #0x452c61c                                 fn_452c61c
02c9eacc: ldr     x8, [x26]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9ead0: ldr     x0, [x27, #0x48]                           &6263098(=0)
02c9ead4: mov     x1, sp                                     
02c9ead8: str     w19, [sp]                                  
02c9eadc: ldr     x8, [x8, #0xb8]                            T:AdsManager/<>c__DisplayClass42_0
02c9eae0: ldr     x20, [x8, #0x458]                          S:'{0}s'
02c9eae4: bl      #0x2b70f38                                 fn_2b70f38
02c9eae8: ldr     x3, [x28]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9eaec: mov     x2, x0                                     
02c9eaf0: mov     x0, x22                                    
02c9eaf4: mov     x1, x20                                    
02c9eaf8: bl      #0x452c61c                                 fn_452c61c
02c9eafc: mov     x0, x21                                    
02c9eb00: mov     x1, x22                                    
02c9eb04: mov     x2, xzr                                    
02c9eb08: bl      #0x2d77fe8                                 WejoyService.Tracking.TrackingManager::LogEvent
02c9eb0c: ldp     x20, x19, [sp, #0x70]                      
02c9eb10: ldr     x30, [sp, #0x20]                           
02c9eb14: ldp     x22, x21, [sp, #0x60]                      
02c9eb18: ldp     x24, x23, [sp, #0x50]                      
02c9eb1c: ldp     x26, x25, [sp, #0x40]                      
02c9eb20: ldp     x28, x27, [sp, #0x30]                      
02c9eb24: ldp     d9, d8, [sp, #0x10]                        
02c9eb28: add     sp, sp, #0x80                              
02c9eb2c: ret                                                
02c9eb30: bl      #0x2b7105c                                 fn_2b7105c
## TradingDeny(int yourValue, int npcValue, float tradePercent) -> void
---- DevTrack::TradingDeny 0x2c9eb34
02c9eb34: sub     sp, sp, #0x70                              
02c9eb38: stp     d9, d8, [sp, #0x10]                        
02c9eb3c: str     x30, [sp, #0x20]                           
02c9eb40: stp     x26, x25, [sp, #0x30]                      
02c9eb44: stp     x24, x23, [sp, #0x40]                      
02c9eb48: stp     x22, x21, [sp, #0x50]                      
02c9eb4c: stp     x20, x19, [sp, #0x60]                      
02c9eb50: fmov    s8, s0                                     
02c9eb54: adrp    x19, #0x662f000                            
02c9eb58: adrp    x26, #0x6265000                            
02c9eb5c: ldrb    w8, [x19, #0xa71]                          
02c9eb60: ldr     x26, [x26, #0xb38]                         T:DevTrack
02c9eb64: mov     w21, w1                                    
02c9eb68: mov     w22, w0                                    
02c9eb6c: tbnz    w8, #0, #0x2c9eba8                         
02c9eb70: adrp    x0, #0x6265000                             
02c9eb74: ldr     x0, [x0, #0xb38]                           T:DevTrack
02c9eb78: bl      #0x2b70db0                                 fn_2b70db0
02c9eb7c: adrp    x0, #0x6265000                             
02c9eb80: ldr     x0, [x0, #0xb40]                           MS:System.Collections.Generic.Dictionary`2::Add
02c9eb84: bl      #0x2b70db0                                 fn_2b70db0
02c9eb88: adrp    x0, #0x6263000                             
02c9eb8c: ldr     x0, [x0, #0x9a0]                           MS:System.Collections.Generic.Dictionary`2::.ctor
02c9eb90: bl      #0x2b70db0                                 fn_2b70db0
02c9eb94: adrp    x0, #0x6263000                             
02c9eb98: ldr     x0, [x0, #0x938]                           T:type8922(k15)
02c9eb9c: bl      #0x2b70db0                                 fn_2b70db0
02c9eba0: mov     w8, #1                                     
02c9eba4: strb    w8, [x19, #0xa71]                          
02c9eba8: ldr     x0, [x26]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9ebac: adrp    x23, #0x6263000                            
02c9ebb0: adrp    x20, #0x6263000                            
02c9ebb4: ldr     x23, [x23, #0x938]                         T:type8922(k15)
02c9ebb8: ldr     w8, [x0, #0xe4]                            [62630e4]=0 f=0,0
02c9ebbc: ldr     x20, [x20, #0x9a0]                         MS:System.Collections.Generic.Dictionary`2::.ctor
02c9ebc0: cbnz    w8, #0x2c9ebcc                             
02c9ebc4: bl      #0x2b70f30                                 fn_2b70f30
02c9ebc8: ldr     x0, [x26]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9ebcc: ldr     x8, [x0, #0xb8]                            &6263108(=0) .tutorial_id
02c9ebd0: ldr     x0, [x23]                                  &2c5bbd4(=a9bd7bfdd503233f)
02c9ebd4: ldr     x19, [x8, #0x3e0]                          
02c9ebd8: bl      #0x2b7104c                                 fn_2b7104c
02c9ebdc: ldr     x1, [x20]                                  &2c5bbd4(=a9bd7bfdd503233f)
02c9ebe0: mov     x20, x0                                    
02c9ebe4: bl      #0x452b8a0                                 fn_452b8a0
02c9ebe8: ldr     x8, [x26]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9ebec: adrp    x24, #0x6263000                            
02c9ebf0: add     x1, sp, #0xc                               
02c9ebf4: ldr     x8, [x8, #0xb8]                            
02c9ebf8: ldr     x24, [x24, #0x970]                         &6645c70(=0)
02c9ebfc: str     w22, [sp, #0xc]                            
02c9ec00: ldr     x0, [x24, #0x48]                           &6263098(=0)
02c9ec04: ldr     x23, [x8, #0x438]                          
02c9ec08: bl      #0x2b70f38                                 fn_2b70f38
02c9ec0c: cbz     x20, #0x2c9ed78                            
02c9ec10: adrp    x25, #0x6265000                            
02c9ec14: mov     x2, x0                                     
02c9ec18: mov     x0, x20                                    
02c9ec1c: ldr     x25, [x25, #0xb40]                         MS:System.Collections.Generic.Dictionary`2::Add
02c9ec20: mov     x1, x23                                    
02c9ec24: ldr     x3, [x25]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9ec28: bl      #0x452c61c                                 fn_452c61c
02c9ec2c: ldr     x8, [x26]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9ec30: ldr     x0, [x24, #0x48]                           &6263098(=0)
02c9ec34: add     x1, sp, #8                                 
02c9ec38: str     w21, [sp, #8]                              
02c9ec3c: ldr     x8, [x8, #0xb8]                            
02c9ec40: ldr     x22, [x8, #0x440]                          
02c9ec44: bl      #0x2b70f38                                 fn_2b70f38
02c9ec48: ldr     x3, [x25]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9ec4c: mov     x2, x0                                     
02c9ec50: mov     x0, x20                                    
02c9ec54: mov     x1, x22                                    
02c9ec58: bl      #0x452c61c                                 fn_452c61c
02c9ec5c: ldr     x8, [x26]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9ec60: adrp    x22, #0x662f000                            
02c9ec64: ldrb    w9, [x22, #0xa8a]                          
02c9ec68: ldr     x8, [x8, #0xb8]                            
02c9ec6c: ldr     x21, [x8, #0x448]                          
02c9ec70: cbnz    w9, #0x2c9ec88                             
02c9ec74: adrp    x0, #0x6265000                             
02c9ec78: ldr     x0, [x0, #0xb48]                           T:System.Math
02c9ec7c: bl      #0x2b70db0                                 fn_2b70db0
02c9ec80: mov     w8, #1                                     
02c9ec84: strb    w8, [x22, #0xa8a]                          
02c9ec88: adrp    x8, #0x6265000                             
02c9ec8c: ldr     x8, [x8, #0xb48]                           T:System.Math
02c9ec90: ldr     x0, [x8]                                   M:AdsManager::<OnApplicationPause>b__26_0
02c9ec94: ldr     w8, [x0, #0xe4]                            [62650e4]=0 f=0,0
02c9ec98: cbnz    w8, #0x2c9eca0                             
02c9ec9c: bl      #0x2b70f30                                 fn_2b70f30
02c9eca0: fcvt    d9, s8                                     
02c9eca4: add     x0, sp, #0x28                              
02c9eca8: fmov    d0, d9                                     
02c9ecac: bl      #0x5e902c0                                 fn_5e902c0
02c9ecb0: fcmp    s8, #0.0                                   
02c9ecb4: b.ge    #0x2c9ecd0                                 
02c9ecb8: fmov    d1, #-0.50000000                           
02c9ecbc: fcmp    d0, d1                                     
02c9ecc0: b.ne    #0x2c9ecf8                                 
02c9ecc4: ldr     d0, [sp, #0x28]                            
02c9ecc8: fmov    d1, #-1.00000000                           
02c9eccc: b       #0x2c9ece4                                 
02c9ecd0: fmov    d1, #0.50000000                            
02c9ecd4: fcmp    d0, d1                                     
02c9ecd8: b.ne    #0x2c9ed04                                 
02c9ecdc: fmov    d1, #1.00000000                            
02c9ece0: ldr     d0, [sp, #0x28]                            
02c9ece4: fcvtzs  x8, d0                                     
02c9ece8: fadd    d1, d0, d1                                 
02c9ecec: tst     x8, #1                                     
02c9ecf0: fcsel   d0, d0, d1, eq                             
02c9ecf4: b       #0x2c9ed0c                                 
02c9ecf8: fadd    d0, d9, d1                                 
02c9ecfc: frintp  d0, d0                                     
02c9ed00: b       #0x2c9ed0c                                 
02c9ed04: fadd    d0, d9, d1                                 
02c9ed08: frintm  d0, d0                                     
02c9ed0c: mov     x8, #0x7ff0000000000000                    
02c9ed10: fcvtzs  w9, d0                                     
02c9ed14: ldr     x0, [x24, #0x48]                           &6263098(=0)
02c9ed18: fmov    d1, x8                                     
02c9ed1c: mov     w8, #-0xffffffff80000000                   
02c9ed20: add     x1, sp, #0x28                              
02c9ed24: fcmp    d0, d1                                     
02c9ed28: csel    w8, w8, w9, eq                             
02c9ed2c: str     w8, [sp, #0x28]                            
02c9ed30: bl      #0x2b70f38                                 fn_2b70f38
02c9ed34: ldr     x3, [x25]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9ed38: mov     x2, x0                                     
02c9ed3c: mov     x0, x20                                    
02c9ed40: mov     x1, x21                                    
02c9ed44: bl      #0x452c61c                                 fn_452c61c
02c9ed48: mov     x0, x19                                    
02c9ed4c: mov     x1, x20                                    
02c9ed50: mov     x2, xzr                                    
02c9ed54: bl      #0x2d77fe8                                 WejoyService.Tracking.TrackingManager::LogEvent
02c9ed58: ldp     x20, x19, [sp, #0x60]                      
02c9ed5c: ldr     x30, [sp, #0x20]                           
02c9ed60: ldp     x22, x21, [sp, #0x50]                      
02c9ed64: ldp     x24, x23, [sp, #0x40]                      
02c9ed68: ldp     x26, x25, [sp, #0x30]                      
02c9ed6c: ldp     d9, d8, [sp, #0x10]                        
02c9ed70: add     sp, sp, #0x70                              
02c9ed74: ret                                                
02c9ed78: bl      #0x2b7105c                                 fn_2b7105c
## TradingStealAd(string adResult, int itemCountReceived) -> void
---- DevTrack::TradingStealAd 0x2c9ed7c
02c9ed7c: str     x30, [sp, #-0x40]!                         
02c9ed80: stp     x24, x23, [sp, #0x10]                      
02c9ed84: stp     x22, x21, [sp, #0x20]                      
02c9ed88: stp     x20, x19, [sp, #0x30]                      
02c9ed8c: adrp    x21, #0x662f000                            
02c9ed90: adrp    x23, #0x6265000                            
02c9ed94: mov     w19, w1                                    
02c9ed98: ldrb    w8, [x21, #0xa72]                          
02c9ed9c: ldr     x23, [x23, #0xb38]                         T:DevTrack
02c9eda0: mov     x20, x0                                    
02c9eda4: tbnz    w8, #0, #0x2c9ede0                         
02c9eda8: adrp    x0, #0x6265000                             
02c9edac: ldr     x0, [x0, #0xb38]                           T:DevTrack
02c9edb0: bl      #0x2b70db0                                 fn_2b70db0
02c9edb4: adrp    x0, #0x6265000                             
02c9edb8: ldr     x0, [x0, #0xb40]                           MS:System.Collections.Generic.Dictionary`2::Add
02c9edbc: bl      #0x2b70db0                                 fn_2b70db0
02c9edc0: adrp    x0, #0x6263000                             
02c9edc4: ldr     x0, [x0, #0x9a0]                           MS:System.Collections.Generic.Dictionary`2::.ctor
02c9edc8: bl      #0x2b70db0                                 fn_2b70db0
02c9edcc: adrp    x0, #0x6263000                             
02c9edd0: ldr     x0, [x0, #0x938]                           T:type8922(k15)
02c9edd4: bl      #0x2b70db0                                 fn_2b70db0
02c9edd8: mov     w8, #1                                     
02c9eddc: strb    w8, [x21, #0xa72]                          
02c9ede0: ldr     x0, [x23]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9ede4: adrp    x24, #0x6263000                            
02c9ede8: adrp    x22, #0x6263000                            
02c9edec: ldr     x24, [x24, #0x938]                         T:type8922(k15)
02c9edf0: ldr     w8, [x0, #0xe4]                            [62630e4]=0 f=0,0
02c9edf4: ldr     x22, [x22, #0x9a0]                         MS:System.Collections.Generic.Dictionary`2::.ctor
02c9edf8: cbnz    w8, #0x2c9ee04                             
02c9edfc: bl      #0x2b70f30                                 fn_2b70f30
02c9ee00: ldr     x0, [x23]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9ee04: ldr     x8, [x0, #0xb8]                            &6263108(=0) .tutorial_id
02c9ee08: ldr     x0, [x24]                                  &2c5bbd4(=a9bd7bfdd503233f)
02c9ee0c: ldr     x21, [x8, #0x3e8]                          
02c9ee10: bl      #0x2b7104c                                 fn_2b7104c
02c9ee14: ldr     x1, [x22]                                  &2c5bbd4(=a9bd7bfdd503233f)
02c9ee18: mov     x22, x0                                    
02c9ee1c: bl      #0x452b8a0                                 fn_452b8a0
02c9ee20: cbz     x22, #0x2c9eea4                            
02c9ee24: ldr     x8, [x23]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9ee28: adrp    x24, #0x6265000                            
02c9ee2c: mov     x0, x22                                    
02c9ee30: ldr     x24, [x24, #0xb40]                         MS:System.Collections.Generic.Dictionary`2::Add
02c9ee34: mov     x2, x20                                    
02c9ee38: ldr     x8, [x8, #0xb8]                            
02c9ee3c: ldr     x3, [x24]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9ee40: ldr     x1, [x8, #0x460]                           
02c9ee44: bl      #0x452c61c                                 fn_452c61c
02c9ee48: ldr     x8, [x23]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9ee4c: adrp    x9, #0x6263000                             
02c9ee50: add     x1, sp, #0xc                               
02c9ee54: ldr     x8, [x8, #0xb8]                            
02c9ee58: ldr     x9, [x9, #0x970]                           &6645c70(=0)
02c9ee5c: str     w19, [sp, #0xc]                            
02c9ee60: ldr     x0, [x9, #0x48]                            &6263098(=0)
02c9ee64: ldr     x20, [x8, #0x458]                          
02c9ee68: bl      #0x2b70f38                                 fn_2b70f38
02c9ee6c: ldr     x3, [x24]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9ee70: mov     x2, x0                                     
02c9ee74: mov     x0, x22                                    
02c9ee78: mov     x1, x20                                    
02c9ee7c: bl      #0x452c61c                                 fn_452c61c
02c9ee80: mov     x0, x21                                    
02c9ee84: mov     x1, x22                                    
02c9ee88: mov     x2, xzr                                    
02c9ee8c: bl      #0x2d77fe8                                 WejoyService.Tracking.TrackingManager::LogEvent
02c9ee90: ldp     x20, x19, [sp, #0x30]                      
02c9ee94: ldp     x22, x21, [sp, #0x20]                      
02c9ee98: ldp     x24, x23, [sp, #0x10]                      
02c9ee9c: ldr     x30, [sp], #0x40                           
02c9eea0: ret                                                
02c9eea4: bl      #0x2b7105c                                 fn_2b7105c
## .ctor() -> void
---- DevTrack::.ctor 0x2c9eea8
02c9eea8: mov     x1, xzr                                    
02c9eeac: b       #0x5b397b0                                 UnityEngine.MonoBehaviour::.ctor
## .cctor() -> void
---- DevTrack::.cctor 0x2c9eeb0
02c9eeb0: sub     sp, sp, #0x70                              
02c9eeb4: stp     x29, x30, [sp, #0x10]                      
02c9eeb8: stp     x28, x27, [sp, #0x20]                      
02c9eebc: stp     x26, x25, [sp, #0x30]                      
02c9eec0: stp     x24, x23, [sp, #0x40]                      
02c9eec4: stp     x22, x21, [sp, #0x50]                      
02c9eec8: stp     x20, x19, [sp, #0x60]                      
02c9eecc: adrp    x21, #0x6265000                            
02c9eed0: adrp    x19, #0x6265000                            
02c9eed4: adrp    x20, #0x6265000                            
02c9eed8: adrp    x26, #0x6265000                            
02c9eedc: adrp    x24, #0x6265000                            
02c9eee0: adrp    x29, #0x6265000                            
02c9eee4: adrp    x28, #0x6265000                            
02c9eee8: adrp    x23, #0x6265000                            
02c9eeec: adrp    x22, #0x6265000                            
02c9eef0: adrp    x27, #0x6265000                            
02c9eef4: adrp    x25, #0x662f000                            
02c9eef8: ldr     x21, [x21, #0xb50]                         S:'onboarding_begin'
02c9eefc: ldr     x19, [x19, #0xb38]                         T:DevTrack
02c9ef00: ldr     x20, [x20, #0xb58]                         S:'onboarding_step'
02c9ef04: ldr     x26, [x26, #0xb60]                         S:'onboarding_complete'
02c9ef08: ldr     x24, [x24, #0xb68]                         S:'game_mode_enter'
02c9ef0c: ldr     x29, [x29, #0xb70]                         S:'game_mode_start'
02c9ef10: ldr     x28, [x28, #0xb78]                         S:'game_mode_step_enter'
02c9ef14: ldr     x23, [x23, #0xb80]                         S:'game_mode_step_complete'
02c9ef18: ldr     x22, [x22, #0xb88]                         S:'game_mode_exit'
02c9ef1c: ldr     x27, [x27, #0xb90]                         S:'home'
02c9ef20: ldrb    w8, [x25, #0xa73]                          
02c9ef24: tbnz    w8, #0, #0x2c9f500                         
02c9ef28: adrp    x0, #0x6265000                             
02c9ef2c: ldr     x0, [x0, #0xb38]                           T:DevTrack
02c9ef30: bl      #0x2b70db0                                 fn_2b70db0
02c9ef34: adrp    x0, #0x6265000                             
02c9ef38: ldr     x0, [x0, #0xb98]                           S:'trading_steal_ad'
02c9ef3c: bl      #0x2b70db0                                 fn_2b70db0
02c9ef40: adrp    x0, #0x6265000                             
02c9ef44: ldr     x0, [x0, #0xba0]                           S:'step_duration_sec'
02c9ef48: bl      #0x2b70db0                                 fn_2b70db0
02c9ef4c: adrp    x0, #0x6265000                             
02c9ef50: ldr     x0, [x0, #0xba8]                           S:'counter_request_index'
02c9ef54: bl      #0x2b70db0                                 fn_2b70db0
02c9ef58: adrp    x0, #0x6265000                             
02c9ef5c: ldr     x0, [x0, #0xbb0]                           S:'scoop_tutorial'
02c9ef60: bl      #0x2b70db0                                 fn_2b70db0
02c9ef64: adrp    x0, #0x6265000                             
02c9ef68: ldr     x0, [x0, #0xbb8]                           S:'trading_complete'
02c9ef6c: bl      #0x2b70db0                                 fn_2b70db0
02c9ef70: adrp    x0, #0x6265000                             
02c9ef74: ldr     x0, [x0, #0xbc0]                           S:'reward_type'
02c9ef78: bl      #0x2b70db0                                 fn_2b70db0
02c9ef7c: adrp    x0, #0x6265000                             
02c9ef80: ldr     x0, [x0, #0xb90]                           S:'home'
02c9ef84: bl      #0x2b70db0                                 fn_2b70db0
02c9ef88: adrp    x0, #0x6265000                             
02c9ef8c: ldr     x0, [x0, #0xbc8]                           S:'primary'
02c9ef90: bl      #0x2b70db0                                 fn_2b70db0
02c9ef94: adrp    x0, #0x6265000                             
02c9ef98: ldr     x0, [x0, #0xbd0]                           S:'reward_double_ads_result'
02c9ef9c: bl      #0x2b70db0                                 fn_2b70db0
02c9efa0: adrp    x0, #0x6265000                             
02c9efa4: ldr     x0, [x0, #0xbd8]                           S:'select_box'
02c9efa8: bl      #0x2b70db0                                 fn_2b70db0
02c9efac: adrp    x0, #0x6265000                             
02c9efb0: ldr     x0, [x0, #0xbe0]                           S:'entry_point'
02c9efb4: bl      #0x2b70db0                                 fn_2b70db0
02c9efb8: adrp    x0, #0x6265000                             
02c9efbc: ldr     x0, [x0, #0xbe8]                           S:'item_count_given'
02c9efc0: bl      #0x2b70db0                                 fn_2b70db0
02c9efc4: adrp    x0, #0x6265000                             
02c9efc8: ldr     x0, [x0, #0xbf0]                           S:'unbox'
02c9efcc: bl      #0x2b70db0                                 fn_2b70db0
02c9efd0: adrp    x0, #0x6265000                             
02c9efd4: ldr     x0, [x0, #0xbf8]                           S:'item_id'
02c9efd8: bl      #0x2b70db0                                 fn_2b70db0
02c9efdc: adrp    x0, #0x6265000                             
02c9efe0: ldr     x0, [x0, #0xc00]                           S:'total_keycap_count'
02c9efe4: bl      #0x2b70db0                                 fn_2b70db0
02c9efe8: adrp    x0, #0x6265000                             
02c9efec: ldr     x0, [x0, #0xc08]                           S:'result'
02c9eff0: bl      #0x2b70db0                                 fn_2b70db0
02c9eff4: adrp    x0, #0x6265000                             
02c9eff8: ldr     x0, [x0, #0xc10]                           S:'delivery'
02c9effc: bl      #0x2b70db0                                 fn_2b70db0
02c9f000: adrp    x0, #0x6265000                             
02c9f004: ldr     x0, [x0, #0xc18]                           S:'duration_sec'
02c9f008: bl      #0x2b70db0                                 fn_2b70db0
02c9f00c: adrp    x0, #0x6265000                             
02c9f010: ldr     x0, [x0, #0xc20]                           S:'unavailable'
02c9f014: bl      #0x2b70db0                                 fn_2b70db0
02c9f018: adrp    x0, #0x6265000                             
02c9f01c: ldr     x0, [x0, #0xc28]                           S:'item_type'
02c9f020: bl      #0x2b70db0                                 fn_2b70db0
02c9f024: adrp    x0, #0x6265000                             
02c9f028: ldr     x0, [x0, #0xb58]                           S:'onboarding_step'
02c9f02c: bl      #0x2b70db0                                 fn_2b70db0
02c9f030: adrp    x0, #0x6265000                             
02c9f034: ldr     x0, [x0, #0xc30]                           S:'start'
02c9f038: bl      #0x2b70db0                                 fn_2b70db0
02c9f03c: adrp    x0, #0x6265000                             
02c9f040: ldr     x0, [x0, #0xc38]                           S:'item_status'
02c9f044: bl      #0x2b70db0                                 fn_2b70db0
02c9f048: adrp    x0, #0x6265000                             
02c9f04c: ldr     x0, [x0, #0xc40]                           S:'game_mode_complete'
02c9f050: bl      #0x2b70db0                                 fn_2b70db0
02c9f054: adrp    x0, #0x6265000                             
02c9f058: ldr     x0, [x0, #0xc48]                           S:'game_mode_select'
02c9f05c: bl      #0x2b70db0                                 fn_2b70db0
02c9f060: adrp    x0, #0x6265000                             
02c9f064: ldr     x0, [x0, #0xc50]                           S:'trade_percent'
02c9f068: bl      #0x2b70db0                                 fn_2b70db0
02c9f06c: adrp    x0, #0x6265000                             
02c9f070: ldr     x0, [x0, #0xc58]                           S:'collection'
02c9f074: bl      #0x2b70db0                                 fn_2b70db0
02c9f078: adrp    x0, #0x6265000                             
02c9f07c: ldr     x0, [x0, #0xc60]                           S:'previous_value'
02c9f080: bl      #0x2b70db0                                 fn_2b70db0
02c9f084: adrp    x0, #0x6265000                             
02c9f088: ldr     x0, [x0, #0xc68]                           S:'setting_changed'
02c9f08c: bl      #0x2b70db0                                 fn_2b70db0
02c9f090: adrp    x0, #0x6265000                             
02c9f094: ldr     x0, [x0, #0xb68]                           S:'game_mode_enter'
02c9f098: bl      #0x2b70db0                                 fn_2b70db0
02c9f09c: adrp    x0, #0x6265000                             
02c9f0a0: ldr     x0, [x0, #0xc70]                           S:'elapsed_time'
02c9f0a4: bl      #0x2b70db0                                 fn_2b70db0
02c9f0a8: adrp    x0, #0x6265000                             
02c9f0ac: ldr     x0, [x0, #0xc78]                           S:'request_index'
02c9f0b0: bl      #0x2b70db0                                 fn_2b70db0
02c9f0b4: adrp    x0, #0x6265000                             
02c9f0b8: ldr     x0, [x0, #0xc80]                           S:'open_door'
02c9f0bc: bl      #0x2b70db0                                 fn_2b70db0
02c9f0c0: adrp    x0, #0x6265000                             
02c9f0c4: ldr     x0, [x0, #0xc88]                           S:'fps_min'
02c9f0c8: bl      #0x2b70db0                                 fn_2b70db0
02c9f0cc: adrp    x0, #0x6265000                             
02c9f0d0: ldr     x0, [x0, #0xc90]                           S:'success'
02c9f0d4: bl      #0x2b70db0                                 fn_2b70db0
02c9f0d8: adrp    x0, #0x6265000                             
02c9f0dc: ldr     x0, [x0, #0xc98]                           S:'fps_avg'
02c9f0e0: bl      #0x2b70db0                                 fn_2b70db0
02c9f0e4: adrp    x0, #0x6265000                             
02c9f0e8: ldr     x0, [x0, #0xca0]                           S:'trading_enter'
02c9f0ec: bl      #0x2b70db0                                 fn_2b70db0
02c9f0f0: adrp    x0, #0x6265000                             
02c9f0f4: ldr     x0, [x0, #0xca8]                           S:'main_diy'
02c9f0f8: bl      #0x2b70db0                                 fn_2b70db0
02c9f0fc: adrp    x0, #0x6265000                             
02c9f100: ldr     x0, [x0, #0xcb0]                           S:'trading_counter_request'
02c9f104: bl      #0x2b70db0                                 fn_2b70db0
02c9f108: adrp    x0, #0x6265000                             
02c9f10c: ldr     x0, [x0, #0xcb8]                           S:'currency_spend'
02c9f110: bl      #0x2b70db0                                 fn_2b70db0
02c9f114: adrp    x0, #0x6265000                             
02c9f118: ldr     x0, [x0, #0xcc0]                           S:'dreamhouse_tutorial'
02c9f11c: bl      #0x2b70db0                                 fn_2b70db0
02c9f120: adrp    x0, #0x6265000                             
02c9f124: ldr     x0, [x0, #0xcc8]                           S:'accepted'
02c9f128: bl      #0x2b70db0                                 fn_2b70db0
02c9f12c: adrp    x0, #0x6265000                             
02c9f130: ldr     x0, [x0, #0xcd0]                           S:'new_value'
02c9f134: bl      #0x2b70db0                                 fn_2b70db0
02c9f138: adrp    x0, #0x6265000                             
02c9f13c: ldr     x0, [x0, #0xcd8]                           S:'wrap_done'
02c9f140: bl      #0x2b70db0                                 fn_2b70db0
02c9f144: adrp    x0, #0x6265000                             
02c9f148: ldr     x0, [x0, #0xce0]                           S:'source'
02c9f14c: bl      #0x2b70db0                                 fn_2b70db0
02c9f150: adrp    x0, #0x6265000                             
02c9f154: ldr     x0, [x0, #0xce8]                           S:'switch'
02c9f158: bl      #0x2b70db0                                 fn_2b70db0
02c9f15c: adrp    x0, #0x6265000                             
02c9f160: ldr     x0, [x0, #0xcf0]                           S:'feature_name'
02c9f164: bl      #0x2b70db0                                 fn_2b70db0
02c9f168: adrp    x0, #0x6265000                             
02c9f16c: ldr     x0, [x0, #0xcf8]                           S:'currency_type'
02c9f170: bl      #0x2b70db0                                 fn_2b70db0
02c9f174: adrp    x0, #0x6265000                             
02c9f178: ldr     x0, [x0, #0xd00]                           S:'side'
02c9f17c: bl      #0x2b70db0                                 fn_2b70db0
02c9f180: adrp    x0, #0x6265000                             
02c9f184: ldr     x0, [x0, #0xd08]                           S:'your_value'
02c9f188: bl      #0x2b70db0                                 fn_2b70db0
02c9f18c: adrp    x0, #0x6265000                             
02c9f190: ldr     x0, [x0, #0xd10]                           S:'item_rarity'
02c9f194: bl      #0x2b70db0                                 fn_2b70db0
02c9f198: adrp    x0, #0x6265000                             
02c9f19c: ldr     x0, [x0, #0xd18]                           S:'currency_earn'
02c9f1a0: bl      #0x2b70db0                                 fn_2b70db0
02c9f1a4: adrp    x0, #0x6265000                             
02c9f1a8: ldr     x0, [x0, #0xd20]                           S:'npc_response'
02c9f1ac: bl      #0x2b70db0                                 fn_2b70db0
02c9f1b0: adrp    x0, #0x6265000                             
02c9f1b4: ldr     x0, [x0, #0xd28]                           S:'blindbag_tutorial'
02c9f1b8: bl      #0x2b70db0                                 fn_2b70db0
02c9f1bc: adrp    x0, #0x6265000                             
02c9f1c0: ldr     x0, [x0, #0xd30]                           S:'feature_action'
02c9f1c4: bl      #0x2b70db0                                 fn_2b70db0
02c9f1c8: adrp    x0, #0x6265000                             
02c9f1cc: ldr     x0, [x0, #0xd38]                           S:'trading_item_select'
02c9f1d0: bl      #0x2b70db0                                 fn_2b70db0
02c9f1d4: adrp    x0, #0x6265000                             
02c9f1d8: ldr     x0, [x0, #0xd40]                           S:'amount'
02c9f1dc: bl      #0x2b70db0                                 fn_2b70db0
02c9f1e0: adrp    x0, #0x6265000                             
02c9f1e4: ldr     x0, [x0, #0xd48]                           S:'home_button'
02c9f1e8: bl      #0x2b70db0                                 fn_2b70db0
02c9f1ec: adrp    x0, #0x6265000                             
02c9f1f0: ldr     x0, [x0, #0xd50]                           S:'trading_add_more'
02c9f1f4: bl      #0x2b70db0                                 fn_2b70db0
02c9f1f8: adrp    x0, #0x6265000                             
02c9f1fc: ldr     x0, [x0, #0xd58]                           S:'reward_double_ads_tap'
02c9f200: bl      #0x2b70db0                                 fn_2b70db0
02c9f204: adrp    x0, #0x6265000                             
02c9f208: ldr     x0, [x0, #0xd60]                           S:'trading'
02c9f20c: bl      #0x2b70db0                                 fn_2b70db0
02c9f210: adrp    x0, #0x6265000                             
02c9f214: ldr     x0, [x0, #0xd68]                           S:'reward_claim'
02c9f218: bl      #0x2b70db0                                 fn_2b70db0
02c9f21c: adrp    x0, #0x6265000                             
02c9f220: ldr     x0, [x0, #0xd70]                           S:'card'
02c9f224: bl      #0x2b70db0                                 fn_2b70db0
02c9f228: adrp    x0, #0x6265000                             
02c9f22c: ldr     x0, [x0, #0xd78]                           S:'action_name'
02c9f230: bl      #0x2b70db0                                 fn_2b70db0
02c9f234: adrp    x0, #0x6265000                             
02c9f238: ldr     x0, [x0, #0xd80]                           S:'assemble'
02c9f23c: bl      #0x2b70db0                                 fn_2b70db0
02c9f240: adrp    x0, #0x6265000                             
02c9f244: ldr     x0, [x0, #0xd88]                           S:'wrapping'
02c9f248: bl      #0x2b70db0                                 fn_2b70db0
02c9f24c: adrp    x0, #0x6265000                             
02c9f250: ldr     x0, [x0, #0xb78]                           S:'game_mode_step_enter'
02c9f254: bl      #0x2b70db0                                 fn_2b70db0
02c9f258: adrp    x0, #0x6265000                             
02c9f25c: ldr     x0, [x0, #0xd90]                           S:'balance_after'
02c9f260: bl      #0x2b70db0                                 fn_2b70db0
02c9f264: adrp    x0, #0x6265000                             
02c9f268: ldr     x0, [x0, #0xd98]                           S:'ad_result'
02c9f26c: bl      #0x2b70db0                                 fn_2b70db0
02c9f270: adrp    x0, #0x6265000                             
02c9f274: ldr     x0, [x0, #0xb60]                           S:'onboarding_complete'
02c9f278: bl      #0x2b70db0                                 fn_2b70db0
02c9f27c: adrp    x0, #0x6265000                             
02c9f280: ldr     x0, [x0, #0xda0]                           S:'charm'
02c9f284: bl      #0x2b70db0                                 fn_2b70db0
02c9f288: adrp    x0, #0x6265000                             
02c9f28c: ldr     x0, [x0, #0xda8]                           S:'current_item_count'
02c9f290: bl      #0x2b70db0                                 fn_2b70db0
02c9f294: adrp    x0, #0x6265000                             
02c9f298: ldr     x0, [x0, #0xb88]                           S:'game_mode_exit'
02c9f29c: bl      #0x2b70db0                                 fn_2b70db0
02c9f2a0: adrp    x0, #0x6265000                             
02c9f2a4: ldr     x0, [x0, #0xdb0]                           S:'sink'
02c9f2a8: bl      #0x2b70db0                                 fn_2b70db0
02c9f2ac: adrp    x0, #0x6265000                             
02c9f2b0: ldr     x0, [x0, #0xdb8]                           S:'exit_type'
02c9f2b4: bl      #0x2b70db0                                 fn_2b70db0
02c9f2b8: adrp    x0, #0x6265000                             
02c9f2bc: ldr     x0, [x0, #0xdc0]                           S:'diy_item_select'
02c9f2c0: bl      #0x2b70db0                                 fn_2b70db0
02c9f2c4: adrp    x0, #0x6265000                             
02c9f2c8: ldr     x0, [x0, #0xdc8]                           S:'total_duration_sec'
02c9f2cc: bl      #0x2b70db0                                 fn_2b70db0
02c9f2d0: adrp    x0, #0x6265000                             
02c9f2d4: ldr     x0, [x0, #0xdd0]                           S:'fps_max'
02c9f2d8: bl      #0x2b70db0                                 fn_2b70db0
02c9f2dc: adrp    x0, #0x6265000                             
02c9f2e0: ldr     x0, [x0, #0xdd8]                           S:'step_index'
02c9f2e4: bl      #0x2b70db0                                 fn_2b70db0
02c9f2e8: adrp    x0, #0x6265000                             
02c9f2ec: ldr     x0, [x0, #0xde0]                           S:'checkout'
02c9f2f0: bl      #0x2b70db0                                 fn_2b70db0
02c9f2f4: adrp    x0, #0x6265000                             
02c9f2f8: ldr     x0, [x0, #0xde8]                           S:'open_bag'
02c9f2fc: bl      #0x2b70db0                                 fn_2b70db0
02c9f300: adrp    x0, #0x6265000                             
02c9f304: ldr     x0, [x0, #0xdf0]                           S:'npc_value'
02c9f308: bl      #0x2b70db0                                 fn_2b70db0
02c9f30c: adrp    x0, #0x6265000                             
02c9f310: ldr     x0, [x0, #0xdf8]                           S:'entry_source'
02c9f314: bl      #0x2b70db0                                 fn_2b70db0
02c9f318: adrp    x0, #0x6265000                             
02c9f31c: ldr     x0, [x0, #0xe00]                           S:'failed'
02c9f320: bl      #0x2b70db0                                 fn_2b70db0
02c9f324: adrp    x0, #0x6265000                             
02c9f328: ldr     x0, [x0, #0xe08]                           S:'main_diy_tutorial'
02c9f32c: bl      #0x2b70db0                                 fn_2b70db0
02c9f330: adrp    x0, #0x6265000                             
02c9f334: ldr     x0, [x0, #0xb50]                           S:'onboarding_begin'
02c9f338: bl      #0x2b70db0                                 fn_2b70db0
02c9f33c: adrp    x0, #0x6265000                             
02c9f340: ldr     x0, [x0, #0xe10]                           S:'total_charm_count'
02c9f344: bl      #0x2b70db0                                 fn_2b70db0
02c9f348: adrp    x0, #0x6265000                             
02c9f34c: ldr     x0, [x0, #0xe18]                           S:'blind_bag'
02c9f350: bl      #0x2b70db0                                 fn_2b70db0
02c9f354: adrp    x0, #0x6265000                             
02c9f358: ldr     x0, [x0, #0xe20]                           S:'tutorial_id'
02c9f35c: bl      #0x2b70db0                                 fn_2b70db0
02c9f360: adrp    x0, #0x6265000                             
02c9f364: ldr     x0, [x0, #0xe28]                           S:'step_id'
02c9f368: bl      #0x2b70db0                                 fn_2b70db0
02c9f36c: adrp    x0, #0x6265000                             
02c9f370: ldr     x0, [x0, #0xe30]                           S:'frame_time_avg'
02c9f374: bl      #0x2b70db0                                 fn_2b70db0
02c9f378: adrp    x0, #0x6265000                             
02c9f37c: ldr     x0, [x0, #0xe38]                           S:'lucky_scoop'
02c9f380: bl      #0x2b70db0                                 fn_2b70db0
02c9f384: adrp    x0, #0x6265000                             
02c9f388: ldr     x0, [x0, #0xe40]                           S:'print'
02c9f38c: bl      #0x2b70db0                                 fn_2b70db0
02c9f390: adrp    x0, #0x6265000                             
02c9f394: ldr     x0, [x0, #0xe48]                           S:'feature_open'
02c9f398: bl      #0x2b70db0                                 fn_2b70db0
02c9f39c: adrp    x0, #0x6265000                             
02c9f3a0: ldr     x0, [x0, #0xe50]                           S:'flow_index'
02c9f3a4: bl      #0x2b70db0                                 fn_2b70db0
02c9f3a8: adrp    x0, #0x6265000                             
02c9f3ac: ldr     x0, [x0, #0xe58]                           S:'diy_decoration_summary'
02c9f3b0: bl      #0x2b70db0                                 fn_2b70db0
02c9f3b4: adrp    x0, #0x6265000                             
02c9f3b8: ldr     x0, [x0, #0xe60]                           S:'trading_deny'
02c9f3bc: bl      #0x2b70db0                                 fn_2b70db0
02c9f3c0: adrp    x0, #0x6265000                             
02c9f3c4: ldr     x0, [x0, #0xe68]                           S:'playtime'
02c9f3c8: bl      #0x2b70db0                                 fn_2b70db0
02c9f3cc: adrp    x0, #0x6265000                             
02c9f3d0: ldr     x0, [x0, #0xe70]                           S:'get_bag'
02c9f3d4: bl      #0x2b70db0                                 fn_2b70db0
02c9f3d8: adrp    x0, #0x6265000                             
02c9f3dc: ldr     x0, [x0, #0xe78]                           S:'fps_report'
02c9f3e0: bl      #0x2b70db0                                 fn_2b70db0
02c9f3e4: adrp    x0, #0x6265000                             
02c9f3e8: ldr     x0, [x0, #0xb70]                           S:'game_mode_start'
02c9f3ec: bl      #0x2b70db0                                 fn_2b70db0
02c9f3f0: adrp    x0, #0x6265000                             
02c9f3f4: ldr     x0, [x0, #0xb80]                           S:'game_mode_step_complete'
02c9f3f8: bl      #0x2b70db0                                 fn_2b70db0
02c9f3fc: adrp    x0, #0x6265000                             
02c9f400: ldr     x0, [x0, #0xe80]                           S:'setting_name'
02c9f404: bl      #0x2b70db0                                 fn_2b70db0
02c9f408: adrp    x0, #0x6265000                             
02c9f40c: ldr     x0, [x0, #0xe88]                           S:'keychain'
02c9f410: bl      #0x2b70db0                                 fn_2b70db0
02c9f414: adrp    x0, #0x6265000                             
02c9f418: ldr     x0, [x0, #0xe90]                           S:'not_completed'
02c9f41c: bl      #0x2b70db0                                 fn_2b70db0
02c9f420: adrp    x0, #0x6265000                             
02c9f424: ldr     x0, [x0, #0xe98]                           S:'case'
02c9f428: bl      #0x2b70db0                                 fn_2b70db0
02c9f42c: adrp    x0, #0x6265000                             
02c9f430: ldr     x0, [x0, #0xea0]                           S:'scoop'
02c9f434: bl      #0x2b70db0                                 fn_2b70db0
02c9f438: adrp    x0, #0x6265000                             
02c9f43c: ldr     x0, [x0, #0xea8]                           S:'last_step_id'
02c9f440: bl      #0x2b70db0                                 fn_2b70db0
02c9f444: adrp    x0, #0x6265000                             
02c9f448: ldr     x0, [x0, #0xeb0]                           S:'secondary'
02c9f44c: bl      #0x2b70db0                                 fn_2b70db0
02c9f450: adrp    x0, #0x6265000                             
02c9f454: ldr     x0, [x0, #0xeb8]                           S:'offer_value_before'
02c9f458: bl      #0x2b70db0                                 fn_2b70db0
02c9f45c: adrp    x0, #0x6265000                             
02c9f460: ldr     x0, [x0, #0xec0]                           S:'diy_item_choose'
02c9f464: bl      #0x2b70db0                                 fn_2b70db0
02c9f468: adrp    x0, #0x6265000                             
02c9f46c: ldr     x0, [x0, #0xec8]                           S:'3d_figure'
02c9f470: bl      #0x2b70db0                                 fn_2b70db0
02c9f474: adrp    x0, #0x6265000                             
02c9f478: ldr     x0, [x0, #0xed0]                           S:'game_mode'
02c9f47c: bl      #0x2b70db0                                 fn_2b70db0
02c9f480: adrp    x0, #0x6265000                             
02c9f484: ldr     x0, [x0, #0xed8]                           S:'done'
02c9f488: bl      #0x2b70db0                                 fn_2b70db0
02c9f48c: adrp    x0, #0x6265000                             
02c9f490: ldr     x0, [x0, #0xee0]                           S:'collection_item_view'
02c9f494: bl      #0x2b70db0                                 fn_2b70db0
02c9f498: adrp    x0, #0x6265000                             
02c9f49c: ldr     x0, [x0, #0xee8]                           S:'keycap'
02c9f4a0: bl      #0x2b70db0                                 fn_2b70db0
02c9f4a4: adrp    x0, #0x6265000                             
02c9f4a8: ldr     x0, [x0, #0xef0]                           S:'put_to_collection'
02c9f4ac: bl      #0x2b70db0                                 fn_2b70db0
02c9f4b0: adrp    x0, #0x6265000                             
02c9f4b4: ldr     x0, [x0, #0xef8]                           S:'item_count_received'
02c9f4b8: bl      #0x2b70db0                                 fn_2b70db0
02c9f4bc: adrp    x0, #0x6265000                             
02c9f4c0: ldr     x0, [x0, #0xf00]                           S:'decor'
02c9f4c4: bl      #0x2b70db0                                 fn_2b70db0
02c9f4c8: adrp    x0, #0x6265000                             
02c9f4cc: ldr     x0, [x0, #0xf08]                           S:'screen_name'
02c9f4d0: bl      #0x2b70db0                                 fn_2b70db0
02c9f4d4: adrp    x0, #0x6265000                             
02c9f4d8: ldr     x0, [x0, #0xf10]                           S:'item_value'
02c9f4dc: bl      #0x2b70db0                                 fn_2b70db0
02c9f4e0: adrp    x0, #0x6265000                             
02c9f4e4: ldr     x0, [x0, #0xf18]                           S:'placement_id'
02c9f4e8: bl      #0x2b70db0                                 fn_2b70db0
02c9f4ec: adrp    x0, #0x6265000                             
02c9f4f0: ldr     x0, [x0, #0xf20]                           S:'offer_value_after'
02c9f4f4: bl      #0x2b70db0                                 fn_2b70db0
02c9f4f8: mov     w8, #1                                     
02c9f4fc: strb    w8, [x25, #0xa73]                          
02c9f500: ldr     x8, [x19]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9f504: ldr     x1, [x21]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9f508: ldr     x8, [x8, #0xb8]                            
02c9f50c: str     x1, [x8]                                   
02c9f510: ldr     x8, [x19]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9f514: ldr     x0, [x8, #0xb8]                            
02c9f518: bl      #0x2b70d54                                 fn_2b70d54
02c9f51c: ldr     x8, [x19]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9f520: ldr     x1, [x20]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9f524: ldr     x0, [x8, #0xb8]                            
02c9f528: str     x1, [x0, #8]!                              
02c9f52c: bl      #0x2b70d54                                 fn_2b70d54
02c9f530: ldr     x8, [x19]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9f534: ldr     x1, [x26]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9f538: ldr     x0, [x8, #0xb8]                            
02c9f53c: str     x1, [x0, #0x10]!                           .onboarding_complete
02c9f540: bl      #0x2b70d54                                 fn_2b70d54
02c9f544: ldr     x8, [x19]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9f548: ldr     x1, [x24]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9f54c: ldr     x0, [x8, #0xb8]                            
02c9f550: str     x1, [x0, #0x18]!                           .game_mode_enter
02c9f554: bl      #0x2b70d54                                 fn_2b70d54
02c9f558: ldr     x8, [x19]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9f55c: ldr     x1, [x29]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9f560: ldr     x0, [x8, #0xb8]                            
02c9f564: str     x1, [x0, #0x20]!                           .game_mode_start
02c9f568: bl      #0x2b70d54                                 fn_2b70d54
02c9f56c: ldr     x8, [x19]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9f570: ldr     x1, [x28]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9f574: ldr     x0, [x8, #0xb8]                            
02c9f578: str     x1, [x0, #0x28]!                           .game_mode_step_enter
02c9f57c: bl      #0x2b70d54                                 fn_2b70d54
02c9f580: ldr     x8, [x19]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9f584: ldr     x1, [x23]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9f588: ldr     x0, [x8, #0xb8]                            
02c9f58c: str     x1, [x0, #0x30]!                           .game_mode_step_complete
02c9f590: bl      #0x2b70d54                                 fn_2b70d54
02c9f594: ldr     x8, [x19]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9f598: ldr     x1, [x22]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9f59c: ldr     x0, [x8, #0xb8]                            
02c9f5a0: str     x1, [x0, #0x38]!                           .game_mode_exit
02c9f5a4: bl      #0x2b70d54                                 fn_2b70d54
02c9f5a8: adrp    x9, #0x6265000                             
02c9f5ac: ldr     x8, [x19]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9f5b0: ldr     x9, [x9, #0xc40]                           S:'game_mode_complete'
02c9f5b4: ldr     x0, [x8, #0xb8]                            
02c9f5b8: ldr     x1, [x9]                                   M:AdsManager::<OnApplicationPause>b__26_0
02c9f5bc: str     x1, [x0, #0x40]!                           .game_mode_complete
02c9f5c0: bl      #0x2b70d54                                 fn_2b70d54
02c9f5c4: adrp    x9, #0x6265000                             
02c9f5c8: ldr     x8, [x19]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9f5cc: ldr     x9, [x9, #0xdc0]                           S:'diy_item_select'
02c9f5d0: ldr     x0, [x8, #0xb8]                            
02c9f5d4: ldr     x1, [x9]                                   M:AdsManager::<OnApplicationPause>b__26_0
02c9f5d8: str     x1, [x0, #0x48]!                           .diy_item_select
02c9f5dc: bl      #0x2b70d54                                 fn_2b70d54
02c9f5e0: adrp    x9, #0x6265000                             
02c9f5e4: ldr     x8, [x19]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9f5e8: ldr     x9, [x9, #0xec0]                           S:'diy_item_choose'
02c9f5ec: ldr     x0, [x8, #0xb8]                            
02c9f5f0: ldr     x1, [x9]                                   M:AdsManager::<OnApplicationPause>b__26_0
02c9f5f4: str     x1, [x0, #0x50]!                           .diy_item_choose
02c9f5f8: bl      #0x2b70d54                                 fn_2b70d54
02c9f5fc: adrp    x9, #0x6265000                             
02c9f600: ldr     x8, [x19]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9f604: ldr     x9, [x9, #0xe58]                           S:'diy_decoration_summary'
02c9f608: ldr     x0, [x8, #0xb8]                            
02c9f60c: ldr     x1, [x9]                                   M:AdsManager::<OnApplicationPause>b__26_0
02c9f610: str     x1, [x0, #0x58]!                           .diy_decoration_summary
02c9f614: bl      #0x2b70d54                                 fn_2b70d54
02c9f618: adrp    x9, #0x6265000                             
02c9f61c: ldr     x8, [x19]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9f620: ldr     x9, [x9, #0xe48]                           S:'feature_open'
02c9f624: ldr     x0, [x8, #0xb8]                            
02c9f628: ldr     x1, [x9]                                   M:AdsManager::<OnApplicationPause>b__26_0
02c9f62c: str     x1, [x0, #0x60]!                           .feature_open
02c9f630: bl      #0x2b70d54                                 fn_2b70d54
02c9f634: adrp    x9, #0x6265000                             
02c9f638: ldr     x8, [x19]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9f63c: ldr     x9, [x9, #0xd30]                           S:'feature_action'
02c9f640: ldr     x0, [x8, #0xb8]                            
02c9f644: ldr     x1, [x9]                                   M:AdsManager::<OnApplicationPause>b__26_0
02c9f648: str     x1, [x0, #0x68]!                           .feature_action
02c9f64c: bl      #0x2b70d54                                 fn_2b70d54
02c9f650: adrp    x9, #0x6265000                             
02c9f654: ldr     x8, [x19]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9f658: ldr     x9, [x9, #0xee0]                           S:'collection_item_view'
02c9f65c: ldr     x0, [x8, #0xb8]                            
02c9f660: ldr     x1, [x9]                                   M:AdsManager::<OnApplicationPause>b__26_0
02c9f664: str     x1, [x0, #0x70]!                           .collection_item_view
02c9f668: bl      #0x2b70d54                                 fn_2b70d54
02c9f66c: adrp    x9, #0x6265000                             
02c9f670: ldr     x8, [x19]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9f674: ldr     x9, [x9, #0xc48]                           S:'game_mode_select'
02c9f678: ldr     x0, [x8, #0xb8]                            
02c9f67c: ldr     x1, [x9]                                   M:AdsManager::<OnApplicationPause>b__26_0
02c9f680: str     x1, [x0, #0x78]!                           .game_mode_select
02c9f684: bl      #0x2b70d54                                 fn_2b70d54
02c9f688: adrp    x9, #0x6265000                             
02c9f68c: ldr     x8, [x19]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9f690: ldr     x9, [x9, #0xd18]                           S:'currency_earn'
02c9f694: ldr     x0, [x8, #0xb8]                            
02c9f698: ldr     x1, [x9]                                   M:AdsManager::<OnApplicationPause>b__26_0
02c9f69c: str     x1, [x0, #0x80]!                           .currency_earn
02c9f6a0: bl      #0x2b70d54                                 fn_2b70d54
02c9f6a4: adrp    x9, #0x6265000                             
02c9f6a8: ldr     x8, [x19]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9f6ac: ldr     x9, [x9, #0xcb8]                           S:'currency_spend'
02c9f6b0: ldr     x0, [x8, #0xb8]                            
02c9f6b4: ldr     x1, [x9]                                   M:AdsManager::<OnApplicationPause>b__26_0
02c9f6b8: str     x1, [x0, #0x88]!                           .currency_spend
02c9f6bc: bl      #0x2b70d54                                 fn_2b70d54
02c9f6c0: adrp    x9, #0x6265000                             
02c9f6c4: ldr     x8, [x19]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9f6c8: ldr     x9, [x9, #0xd58]                           S:'reward_double_ads_tap'
02c9f6cc: ldr     x0, [x8, #0xb8]                            
02c9f6d0: ldr     x1, [x9]                                   M:AdsManager::<OnApplicationPause>b__26_0
02c9f6d4: str     x1, [x0, #0x90]!                           .reward_double_ads_tap
02c9f6d8: bl      #0x2b70d54                                 fn_2b70d54
02c9f6dc: adrp    x9, #0x6265000                             
02c9f6e0: ldr     x8, [x19]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9f6e4: ldr     x9, [x9, #0xbd0]                           S:'reward_double_ads_result'
02c9f6e8: ldr     x0, [x8, #0xb8]                            
02c9f6ec: ldr     x1, [x9]                                   M:AdsManager::<OnApplicationPause>b__26_0
02c9f6f0: str     x1, [x0, #0x98]!                           .reward_double_ads_result
02c9f6f4: bl      #0x2b70d54                                 fn_2b70d54
02c9f6f8: adrp    x9, #0x6265000                             
02c9f6fc: ldr     x8, [x19]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9f700: ldr     x9, [x9, #0xd68]                           S:'reward_claim'
02c9f704: ldr     x0, [x8, #0xb8]                            
02c9f708: ldr     x1, [x9]                                   M:AdsManager::<OnApplicationPause>b__26_0
02c9f70c: str     x1, [x0, #0xa0]!                           .reward_claim
02c9f710: bl      #0x2b70d54                                 fn_2b70d54
02c9f714: adrp    x9, #0x6265000                             
02c9f718: ldr     x8, [x19]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9f71c: ldr     x9, [x9, #0xc68]                           S:'setting_changed'
02c9f720: ldr     x0, [x8, #0xb8]                            
02c9f724: ldr     x1, [x9]                                   M:AdsManager::<OnApplicationPause>b__26_0
02c9f728: str     x1, [x0, #0xa8]!                           .setting_changed
02c9f72c: bl      #0x2b70d54                                 fn_2b70d54
02c9f730: adrp    x9, #0x6265000                             
02c9f734: ldr     x8, [x19]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9f738: ldr     x9, [x9, #0xe78]                           S:'fps_report'
02c9f73c: ldr     x0, [x8, #0xb8]                            
02c9f740: ldr     x1, [x9]                                   M:AdsManager::<OnApplicationPause>b__26_0
02c9f744: str     x1, [x0, #0xb0]!                           .fps_report
02c9f748: bl      #0x2b70d54                                 fn_2b70d54
02c9f74c: adrp    x9, #0x6265000                             
02c9f750: ldr     x8, [x19]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9f754: ldr     x9, [x9, #0xe20]                           S:'tutorial_id'
02c9f758: ldr     x0, [x8, #0xb8]                            
02c9f75c: ldr     x1, [x9]                                   M:AdsManager::<OnApplicationPause>b__26_0
02c9f760: str     x1, [x0, #0xb8]!                           .tutorial_id
02c9f764: bl      #0x2b70d54                                 fn_2b70d54
02c9f768: adrp    x9, #0x6265000                             
02c9f76c: ldr     x8, [x19]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9f770: ldr     x9, [x9, #0xe28]                           S:'step_id'
02c9f774: ldr     x0, [x8, #0xb8]                            
02c9f778: ldr     x1, [x9]                                   M:AdsManager::<OnApplicationPause>b__26_0
02c9f77c: str     x1, [x0, #0xc0]!                           .step_id
02c9f780: bl      #0x2b70d54                                 fn_2b70d54
02c9f784: adrp    x9, #0x6265000                             
02c9f788: ldr     x8, [x19]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9f78c: ldr     x9, [x9, #0xdd8]                           S:'step_index'
02c9f790: ldr     x0, [x8, #0xb8]                            
02c9f794: ldr     x1, [x9]                                   M:AdsManager::<OnApplicationPause>b__26_0
02c9f798: str     x1, [x0, #0xc8]!                           .step_index
02c9f79c: bl      #0x2b70d54                                 fn_2b70d54
02c9f7a0: adrp    x9, #0x6265000                             
02c9f7a4: ldr     x8, [x19]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9f7a8: ldr     x9, [x9, #0xc18]                           S:'duration_sec'
02c9f7ac: ldr     x0, [x8, #0xb8]                            
02c9f7b0: ldr     x1, [x9]                                   M:AdsManager::<OnApplicationPause>b__26_0
02c9f7b4: str     x1, [x0, #0xd0]!                           .duration_sec
02c9f7b8: bl      #0x2b70d54                                 fn_2b70d54
02c9f7bc: adrp    x9, #0x6265000                             
02c9f7c0: ldr     x8, [x19]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9f7c4: ldr     x9, [x9, #0xed0]                           S:'game_mode'
02c9f7c8: ldr     x0, [x8, #0xb8]                            
02c9f7cc: ldr     x1, [x9]                                   M:AdsManager::<OnApplicationPause>b__26_0
02c9f7d0: str     x1, [x0, #0xd8]!                           .game_mode
02c9f7d4: bl      #0x2b70d54                                 fn_2b70d54
02c9f7d8: adrp    x9, #0x6265000                             
02c9f7dc: ldr     x8, [x19]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9f7e0: ldr     x9, [x9, #0xe50]                           S:'flow_index'
02c9f7e4: ldr     x0, [x8, #0xb8]                            
02c9f7e8: ldr     x1, [x9]                                   M:AdsManager::<OnApplicationPause>b__26_0
02c9f7ec: str     x1, [x0, #0xe0]!                           .flow_index
02c9f7f0: bl      #0x2b70d54                                 fn_2b70d54
02c9f7f4: adrp    x9, #0x6265000                             
02c9f7f8: ldr     x8, [x19]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9f7fc: ldr     x9, [x9, #0xba0]                           S:'step_duration_sec'
02c9f800: ldr     x0, [x8, #0xb8]                            
02c9f804: ldr     x1, [x9]                                   M:AdsManager::<OnApplicationPause>b__26_0
02c9f808: str     x1, [x0, #0xe8]!                           .step_duration_sec
02c9f80c: bl      #0x2b70d54                                 fn_2b70d54
02c9f810: adrp    x9, #0x6265000                             
02c9f814: ldr     x8, [x19]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9f818: ldr     x9, [x9, #0xea8]                           S:'last_step_id'
02c9f81c: ldr     x0, [x8, #0xb8]                            
02c9f820: ldr     x1, [x9]                                   M:AdsManager::<OnApplicationPause>b__26_0
02c9f824: str     x1, [x0, #0xf0]!                           .last_step_id
02c9f828: bl      #0x2b70d54                                 fn_2b70d54
02c9f82c: adrp    x9, #0x6265000                             
02c9f830: ldr     x8, [x19]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9f834: ldr     x9, [x9, #0xdb8]                           S:'exit_type'
02c9f838: ldr     x0, [x8, #0xb8]                            
02c9f83c: ldr     x1, [x9]                                   M:AdsManager::<OnApplicationPause>b__26_0
02c9f840: str     x1, [x0, #0xf8]!                           .exit_type
02c9f844: bl      #0x2b70d54                                 fn_2b70d54
02c9f848: ldr     x8, [x19]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9f84c: adrp    x9, #0x6265000                             
02c9f850: ldr     x9, [x9, #0xc70]                           S:'elapsed_time'
02c9f854: ldr     x8, [x8, #0xb8]                            
02c9f858: ldr     x1, [x9]                                   M:AdsManager::<OnApplicationPause>b__26_0
02c9f85c: add     x0, x8, #0x100                             
02c9f860: str     x1, [x8, #0x100]                           
02c9f864: bl      #0x2b70d54                                 fn_2b70d54
02c9f868: ldr     x8, [x19]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9f86c: adrp    x9, #0x6265000                             
02c9f870: ldr     x9, [x9, #0xdc8]                           S:'total_duration_sec'
02c9f874: ldr     x8, [x8, #0xb8]                            
02c9f878: ldr     x1, [x9]                                   M:AdsManager::<OnApplicationPause>b__26_0
02c9f87c: add     x0, x8, #0x108                             
02c9f880: str     x1, [x8, #0x108]                           
02c9f884: bl      #0x2b70d54                                 fn_2b70d54
02c9f888: ldr     x8, [x19]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9f88c: adrp    x9, #0x6265000                             
02c9f890: ldr     x9, [x9, #0xc28]                           S:'item_type'
02c9f894: ldr     x8, [x8, #0xb8]                            
02c9f898: ldr     x1, [x9]                                   M:AdsManager::<OnApplicationPause>b__26_0
02c9f89c: add     x0, x8, #0x110                             
02c9f8a0: str     x1, [x8, #0x110]                           
02c9f8a4: bl      #0x2b70d54                                 fn_2b70d54
02c9f8a8: ldr     x8, [x19]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9f8ac: adrp    x9, #0x6265000                             
02c9f8b0: ldr     x9, [x9, #0xbf8]                           S:'item_id'
02c9f8b4: ldr     x8, [x8, #0xb8]                            
02c9f8b8: ldr     x1, [x9]                                   M:AdsManager::<OnApplicationPause>b__26_0
02c9f8bc: add     x0, x8, #0x118                             
02c9f8c0: str     x1, [x8, #0x118]                           
02c9f8c4: bl      #0x2b70d54                                 fn_2b70d54
02c9f8c8: ldr     x8, [x19]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9f8cc: adrp    x9, #0x6265000                             
02c9f8d0: ldr     x9, [x9, #0xd10]                           S:'item_rarity'
02c9f8d4: ldr     x8, [x8, #0xb8]                            
02c9f8d8: ldr     x1, [x9]                                   M:AdsManager::<OnApplicationPause>b__26_0
02c9f8dc: add     x0, x8, #0x120                             
02c9f8e0: str     x1, [x8, #0x120]                           
02c9f8e4: bl      #0x2b70d54                                 fn_2b70d54
02c9f8e8: ldr     x8, [x19]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9f8ec: adrp    x9, #0x6265000                             
02c9f8f0: ldr     x9, [x9, #0xda8]                           S:'current_item_count'
02c9f8f4: ldr     x8, [x8, #0xb8]                            
02c9f8f8: ldr     x1, [x9]                                   M:AdsManager::<OnApplicationPause>b__26_0
02c9f8fc: add     x0, x8, #0x128                             
02c9f900: str     x1, [x8, #0x128]                           
02c9f904: bl      #0x2b70d54                                 fn_2b70d54
02c9f908: ldr     x8, [x19]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9f90c: adrp    x9, #0x6265000                             
02c9f910: ldr     x9, [x9, #0xc00]                           S:'total_keycap_count'
02c9f914: ldr     x8, [x8, #0xb8]                            
02c9f918: ldr     x1, [x9]                                   M:AdsManager::<OnApplicationPause>b__26_0
02c9f91c: add     x0, x8, #0x130                             
02c9f920: str     x1, [x8, #0x130]                           
02c9f924: bl      #0x2b70d54                                 fn_2b70d54
02c9f928: ldr     x8, [x19]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9f92c: adrp    x9, #0x6265000                             
02c9f930: ldr     x9, [x9, #0xe10]                           S:'total_charm_count'
02c9f934: ldr     x8, [x8, #0xb8]                            
02c9f938: ldr     x1, [x9]                                   M:AdsManager::<OnApplicationPause>b__26_0
02c9f93c: add     x0, x8, #0x138                             
02c9f940: str     x1, [x8, #0x138]                           
02c9f944: bl      #0x2b70d54                                 fn_2b70d54
02c9f948: ldr     x8, [x19]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9f94c: adrp    x9, #0x6265000                             
02c9f950: ldr     x9, [x9, #0xcf0]                           S:'feature_name'
02c9f954: ldr     x8, [x8, #0xb8]                            
02c9f958: ldr     x1, [x9]                                   M:AdsManager::<OnApplicationPause>b__26_0
02c9f95c: add     x0, x8, #0x140                             
02c9f960: str     x1, [x8, #0x140]                           
02c9f964: bl      #0x2b70d54                                 fn_2b70d54
02c9f968: ldr     x8, [x19]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9f96c: adrp    x9, #0x6265000                             
02c9f970: ldr     x9, [x9, #0xd78]                           S:'action_name'
02c9f974: ldr     x8, [x8, #0xb8]                            
02c9f978: ldr     x1, [x9]                                   M:AdsManager::<OnApplicationPause>b__26_0
02c9f97c: add     x0, x8, #0x148                             
02c9f980: str     x1, [x8, #0x148]                           
02c9f984: bl      #0x2b70d54                                 fn_2b70d54
02c9f988: ldr     x8, [x19]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9f98c: adrp    x9, #0x6265000                             
02c9f990: ldr     x9, [x9, #0xc38]                           S:'item_status'
02c9f994: ldr     x8, [x8, #0xb8]                            
02c9f998: ldr     x1, [x9]                                   M:AdsManager::<OnApplicationPause>b__26_0
02c9f99c: add     x0, x8, #0x150                             
02c9f9a0: str     x1, [x8, #0x150]                           
02c9f9a4: bl      #0x2b70d54                                 fn_2b70d54
02c9f9a8: ldr     x8, [x19]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9f9ac: adrp    x9, #0x6265000                             
02c9f9b0: ldr     x9, [x9, #0xcf8]                           S:'currency_type'
02c9f9b4: ldr     x8, [x8, #0xb8]                            
02c9f9b8: ldr     x1, [x9]                                   M:AdsManager::<OnApplicationPause>b__26_0
02c9f9bc: add     x0, x8, #0x158                             
02c9f9c0: str     x1, [x8, #0x158]                           
02c9f9c4: bl      #0x2b70d54                                 fn_2b70d54
02c9f9c8: ldr     x8, [x19]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9f9cc: adrp    x9, #0x6265000                             
02c9f9d0: ldr     x9, [x9, #0xd40]                           S:'amount'
02c9f9d4: ldr     x8, [x8, #0xb8]                            
02c9f9d8: ldr     x1, [x9]                                   M:AdsManager::<OnApplicationPause>b__26_0
02c9f9dc: add     x0, x8, #0x160                             
02c9f9e0: str     x1, [x8, #0x160]                           
02c9f9e4: bl      #0x2b70d54                                 fn_2b70d54
02c9f9e8: ldr     x8, [x19]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9f9ec: adrp    x9, #0x6265000                             
02c9f9f0: ldr     x9, [x9, #0xce0]                           S:'source'
02c9f9f4: ldr     x8, [x8, #0xb8]                            
02c9f9f8: ldr     x1, [x9]                                   M:AdsManager::<OnApplicationPause>b__26_0
02c9f9fc: add     x0, x8, #0x168                             
02c9fa00: str     x1, [x8, #0x168]                           
02c9fa04: bl      #0x2b70d54                                 fn_2b70d54
02c9fa08: ldr     x8, [x19]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9fa0c: adrp    x9, #0x6265000                             
02c9fa10: ldr     x9, [x9, #0xd90]                           S:'balance_after'
02c9fa14: ldr     x8, [x8, #0xb8]                            
02c9fa18: ldr     x1, [x9]                                   M:AdsManager::<OnApplicationPause>b__26_0
02c9fa1c: add     x0, x8, #0x170                             
02c9fa20: str     x1, [x8, #0x170]                           
02c9fa24: bl      #0x2b70d54                                 fn_2b70d54
02c9fa28: ldr     x8, [x19]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9fa2c: adrp    x9, #0x6265000                             
02c9fa30: ldr     x9, [x9, #0xdb0]                           S:'sink'
02c9fa34: ldr     x8, [x8, #0xb8]                            
02c9fa38: ldr     x1, [x9]                                   M:AdsManager::<OnApplicationPause>b__26_0
02c9fa3c: add     x0, x8, #0x178                             
02c9fa40: str     x1, [x8, #0x178]                           
02c9fa44: bl      #0x2b70d54                                 fn_2b70d54
02c9fa48: ldr     x8, [x19]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9fa4c: adrp    x9, #0x6265000                             
02c9fa50: ldr     x9, [x9, #0xf18]                           S:'placement_id'
02c9fa54: ldr     x8, [x8, #0xb8]                            
02c9fa58: ldr     x1, [x9]                                   M:AdsManager::<OnApplicationPause>b__26_0
02c9fa5c: add     x0, x8, #0x180                             
02c9fa60: str     x1, [x8, #0x180]                           
02c9fa64: bl      #0x2b70d54                                 fn_2b70d54
02c9fa68: ldr     x8, [x19]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9fa6c: adrp    x9, #0x6265000                             
02c9fa70: ldr     x9, [x9, #0xc08]                           S:'result'
02c9fa74: ldr     x8, [x8, #0xb8]                            
02c9fa78: ldr     x1, [x9]                                   M:AdsManager::<OnApplicationPause>b__26_0
02c9fa7c: add     x0, x8, #0x188                             
02c9fa80: str     x1, [x8, #0x188]                           
02c9fa84: bl      #0x2b70d54                                 fn_2b70d54
02c9fa88: ldr     x8, [x19]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9fa8c: adrp    x9, #0x6265000                             
02c9fa90: ldr     x9, [x9, #0xbc0]                           S:'reward_type'
02c9fa94: ldr     x8, [x8, #0xb8]                            
02c9fa98: ldr     x1, [x9]                                   M:AdsManager::<OnApplicationPause>b__26_0
02c9fa9c: add     x0, x8, #0x190                             
02c9faa0: str     x1, [x8, #0x190]                           
02c9faa4: bl      #0x2b70d54                                 fn_2b70d54
02c9faa8: ldr     x8, [x19]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9faac: adrp    x9, #0x6265000                             
02c9fab0: ldr     x9, [x9, #0xe80]                           S:'setting_name'
02c9fab4: ldr     x8, [x8, #0xb8]                            
02c9fab8: ldr     x1, [x9]                                   M:AdsManager::<OnApplicationPause>b__26_0
02c9fabc: add     x0, x8, #0x198                             
02c9fac0: str     x1, [x8, #0x198]                           
02c9fac4: bl      #0x2b70d54                                 fn_2b70d54
02c9fac8: ldr     x8, [x19]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9facc: adrp    x9, #0x6265000                             
02c9fad0: ldr     x9, [x9, #0xc60]                           S:'previous_value'
02c9fad4: ldr     x8, [x8, #0xb8]                            
02c9fad8: ldr     x1, [x9]                                   M:AdsManager::<OnApplicationPause>b__26_0
02c9fadc: add     x0, x8, #0x1a0                             
02c9fae0: str     x1, [x8, #0x1a0]                           
02c9fae4: bl      #0x2b70d54                                 fn_2b70d54
02c9fae8: ldr     x8, [x19]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9faec: adrp    x9, #0x6265000                             
02c9faf0: ldr     x9, [x9, #0xcd0]                           S:'new_value'
02c9faf4: ldr     x8, [x8, #0xb8]                            
02c9faf8: ldr     x1, [x9]                                   M:AdsManager::<OnApplicationPause>b__26_0
02c9fafc: add     x0, x8, #0x1a8                             
02c9fb00: str     x1, [x8, #0x1a8]                           
02c9fb04: bl      #0x2b70d54                                 fn_2b70d54
02c9fb08: ldr     x8, [x19]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9fb0c: adrp    x9, #0x6265000                             
02c9fb10: ldr     x9, [x9, #0xc98]                           S:'fps_avg'
02c9fb14: ldr     x8, [x8, #0xb8]                            
02c9fb18: ldr     x1, [x9]                                   M:AdsManager::<OnApplicationPause>b__26_0
02c9fb1c: add     x0, x8, #0x1b0                             
02c9fb20: str     x1, [x8, #0x1b0]                           
02c9fb24: bl      #0x2b70d54                                 fn_2b70d54
02c9fb28: ldr     x8, [x19]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9fb2c: adrp    x9, #0x6265000                             
02c9fb30: ldr     x9, [x9, #0xc88]                           S:'fps_min'
02c9fb34: ldr     x8, [x8, #0xb8]                            
02c9fb38: ldr     x1, [x9]                                   M:AdsManager::<OnApplicationPause>b__26_0
02c9fb3c: add     x0, x8, #0x1b8                             
02c9fb40: str     x1, [x8, #0x1b8]                           
02c9fb44: bl      #0x2b70d54                                 fn_2b70d54
02c9fb48: ldr     x8, [x19]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9fb4c: adrp    x9, #0x6265000                             
02c9fb50: ldr     x9, [x9, #0xdd0]                           S:'fps_max'
02c9fb54: ldr     x8, [x8, #0xb8]                            
02c9fb58: ldr     x1, [x9]                                   M:AdsManager::<OnApplicationPause>b__26_0
02c9fb5c: add     x0, x8, #0x1c0                             
02c9fb60: str     x1, [x8, #0x1c0]                           
02c9fb64: bl      #0x2b70d54                                 fn_2b70d54
02c9fb68: ldr     x8, [x19]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9fb6c: adrp    x9, #0x6265000                             
02c9fb70: ldr     x9, [x9, #0xe30]                           S:'frame_time_avg'
02c9fb74: ldr     x8, [x8, #0xb8]                            
02c9fb78: ldr     x1, [x9]                                   M:AdsManager::<OnApplicationPause>b__26_0
02c9fb7c: add     x0, x8, #0x1c8                             
02c9fb80: str     x1, [x8, #0x1c8]                           
02c9fb84: bl      #0x2b70d54                                 fn_2b70d54
02c9fb88: ldr     x8, [x19]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9fb8c: adrp    x9, #0x6265000                             
02c9fb90: ldr     x9, [x9, #0xe68]                           S:'playtime'
02c9fb94: ldr     x8, [x8, #0xb8]                            
02c9fb98: ldr     x1, [x9]                                   M:AdsManager::<OnApplicationPause>b__26_0
02c9fb9c: add     x0, x8, #0x1d0                             
02c9fba0: str     x1, [x8, #0x1d0]                           
02c9fba4: bl      #0x2b70d54                                 fn_2b70d54
02c9fba8: ldr     x8, [x19]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9fbac: adrp    x9, #0x6265000                             
02c9fbb0: ldr     x9, [x9, #0xf08]                           S:'screen_name'
02c9fbb4: ldr     x8, [x8, #0xb8]                            
02c9fbb8: ldr     x1, [x9]                                   M:AdsManager::<OnApplicationPause>b__26_0
02c9fbbc: add     x0, x8, #0x1d8                             
02c9fbc0: str     x1, [x8, #0x1d8]                           
02c9fbc4: bl      #0x2b70d54                                 fn_2b70d54
02c9fbc8: ldr     x8, [x19]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9fbcc: adrp    x9, #0x6265000                             
02c9fbd0: ldr     x9, [x9, #0xbc8]                           S:'primary'
02c9fbd4: ldr     x8, [x8, #0xb8]                            
02c9fbd8: ldr     x1, [x9]                                   M:AdsManager::<OnApplicationPause>b__26_0
02c9fbdc: add     x0, x8, #0x1e0                             
02c9fbe0: str     x1, [x8, #0x1e0]                           
02c9fbe4: bl      #0x2b70d54                                 fn_2b70d54
02c9fbe8: ldr     x8, [x19]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9fbec: adrp    x9, #0x6265000                             
02c9fbf0: ldr     x9, [x9, #0xeb0]                           S:'secondary'
02c9fbf4: ldr     x8, [x8, #0xb8]                            
02c9fbf8: ldr     x1, [x9]                                   M:AdsManager::<OnApplicationPause>b__26_0
02c9fbfc: add     x0, x8, #0x1e8                             
02c9fc00: str     x1, [x8, #0x1e8]                           
02c9fc04: bl      #0x2b70d54                                 fn_2b70d54
02c9fc08: ldr     x8, [x19]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9fc0c: adrp    x9, #0x6265000                             
02c9fc10: ldr     x9, [x9, #0xbe0]                           S:'entry_point'
02c9fc14: ldr     x8, [x8, #0xb8]                            
02c9fc18: ldr     x1, [x9]                                   M:AdsManager::<OnApplicationPause>b__26_0
02c9fc1c: add     x0, x8, #0x1f0                             
02c9fc20: str     x1, [x8, #0x1f0]                           
02c9fc24: bl      #0x2b70d54                                 fn_2b70d54
02c9fc28: ldr     x8, [x19]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9fc2c: adrp    x9, #0x6265000                             
02c9fc30: ldr     x9, [x9, #0xe08]                           S:'main_diy_tutorial'
02c9fc34: ldr     x8, [x8, #0xb8]                            
02c9fc38: ldr     x1, [x9]                                   M:AdsManager::<OnApplicationPause>b__26_0
02c9fc3c: add     x0, x8, #0x1f8                             
02c9fc40: str     x1, [x8, #0x1f8]                           
02c9fc44: bl      #0x2b70d54                                 fn_2b70d54
02c9fc48: ldr     x8, [x19]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9fc4c: adrp    x9, #0x6265000                             
02c9fc50: ldr     x9, [x9, #0xd28]                           S:'blindbag_tutorial'
02c9fc54: ldr     x8, [x8, #0xb8]                            
02c9fc58: ldr     x1, [x9]                                   M:AdsManager::<OnApplicationPause>b__26_0
02c9fc5c: add     x0, x8, #0x200                             
02c9fc60: str     x1, [x8, #0x200]                           
02c9fc64: bl      #0x2b70d54                                 fn_2b70d54
02c9fc68: ldr     x8, [x19]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9fc6c: adrp    x9, #0x6265000                             
02c9fc70: ldr     x9, [x9, #0xbb0]                           S:'scoop_tutorial'
02c9fc74: ldr     x8, [x8, #0xb8]                            
02c9fc78: ldr     x1, [x9]                                   M:AdsManager::<OnApplicationPause>b__26_0
02c9fc7c: add     x0, x8, #0x208                             
02c9fc80: str     x1, [x8, #0x208]                           
02c9fc84: bl      #0x2b70d54                                 fn_2b70d54
02c9fc88: ldr     x8, [x19]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9fc8c: adrp    x9, #0x6265000                             
02c9fc90: ldr     x9, [x9, #0xcc0]                           S:'dreamhouse_tutorial'
02c9fc94: ldr     x8, [x8, #0xb8]                            
02c9fc98: ldr     x1, [x9]                                   M:AdsManager::<OnApplicationPause>b__26_0
02c9fc9c: add     x0, x8, #0x210                             
02c9fca0: str     x1, [x8, #0x210]                           
02c9fca4: bl      #0x2b70d54                                 fn_2b70d54
02c9fca8: ldr     x8, [x19]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9fcac: adrp    x9, #0x6265000                             
02c9fcb0: ldr     x9, [x9, #0xc30]                           S:'start'
02c9fcb4: ldr     x8, [x8, #0xb8]                            
02c9fcb8: ldr     x1, [x9]                                   M:AdsManager::<OnApplicationPause>b__26_0
02c9fcbc: add     x0, x8, #0x218                             
02c9fcc0: str     x1, [x8, #0x218]                           
02c9fcc4: bl      #0x2b70d54                                 fn_2b70d54
02c9fcc8: ldr     x8, [x19]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9fccc: adrp    x9, #0x6265000                             
02c9fcd0: ldr     x9, [x9, #0xe98]                           S:'case'
02c9fcd4: ldr     x8, [x8, #0xb8]                            
02c9fcd8: ldr     x1, [x9]                                   M:AdsManager::<OnApplicationPause>b__26_0
02c9fcdc: add     x0, x8, #0x220                             
02c9fce0: str     x1, [x8, #0x220]                           
02c9fce4: bl      #0x2b70d54                                 fn_2b70d54
02c9fce8: ldr     x8, [x19]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9fcec: adrp    x9, #0x6265000                             
02c9fcf0: ldr     x9, [x9, #0xe40]                           S:'print'
02c9fcf4: ldr     x8, [x8, #0xb8]                            
02c9fcf8: ldr     x1, [x9]                                   M:AdsManager::<OnApplicationPause>b__26_0
02c9fcfc: add     x0, x8, #0x228                             
02c9fd00: str     x1, [x8, #0x228]                           
02c9fd04: bl      #0x2b70d54                                 fn_2b70d54
02c9fd08: ldr     x8, [x19]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9fd0c: adrp    x22, #0x6265000                            
02c9fd10: ldr     x22, [x22, #0xce8]                         S:'switch'
02c9fd14: ldr     x8, [x8, #0xb8]                            
02c9fd18: ldr     x1, [x22]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9fd1c: add     x0, x8, #0x230                             
02c9fd20: str     x1, [x8, #0x230]                           
02c9fd24: bl      #0x2b70d54                                 fn_2b70d54
02c9fd28: ldr     x8, [x19]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9fd2c: adrp    x21, #0x6265000                            
02c9fd30: ldr     x21, [x21, #0xee8]                         S:'keycap'
02c9fd34: ldr     x8, [x8, #0xb8]                            
02c9fd38: ldr     x1, [x21]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9fd3c: add     x0, x8, #0x238                             
02c9fd40: str     x1, [x8, #0x238]                           
02c9fd44: bl      #0x2b70d54                                 fn_2b70d54
02c9fd48: ldr     x8, [x19]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9fd4c: adrp    x9, #0x6265000                             
02c9fd50: ldr     x9, [x9, #0xf00]                           S:'decor'
02c9fd54: ldr     x8, [x8, #0xb8]                            
02c9fd58: ldr     x1, [x9]                                   M:AdsManager::<OnApplicationPause>b__26_0
02c9fd5c: add     x0, x8, #0x240                             
02c9fd60: str     x1, [x8, #0x240]                           
02c9fd64: bl      #0x2b70d54                                 fn_2b70d54
02c9fd68: ldr     x8, [x19]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9fd6c: adrp    x20, #0x6265000                            
02c9fd70: ldr     x20, [x20, #0xe88]                         S:'keychain'
02c9fd74: ldr     x8, [x8, #0xb8]                            
02c9fd78: ldr     x1, [x20]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9fd7c: add     x0, x8, #0x248                             
02c9fd80: str     x1, [x8, #0x248]                           
02c9fd84: bl      #0x2b70d54                                 fn_2b70d54
02c9fd88: ldr     x8, [x19]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9fd8c: adrp    x9, #0x6265000                             
02c9fd90: ldr     x9, [x9, #0xd80]                           S:'assemble'
02c9fd94: ldr     x8, [x8, #0xb8]                            
02c9fd98: ldr     x1, [x9]                                   M:AdsManager::<OnApplicationPause>b__26_0
02c9fd9c: add     x0, x8, #0x250                             
02c9fda0: str     x1, [x8, #0x250]                           
02c9fda4: bl      #0x2b70d54                                 fn_2b70d54
02c9fda8: ldr     x8, [x19]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9fdac: adrp    x9, #0x6265000                             
02c9fdb0: ldr     x9, [x9, #0xed8]                           S:'done'
02c9fdb4: ldr     x8, [x8, #0xb8]                            
02c9fdb8: ldr     x1, [x9]                                   M:AdsManager::<OnApplicationPause>b__26_0
02c9fdbc: add     x0, x8, #0x258                             
02c9fdc0: str     x1, [x8, #0x258]                           
02c9fdc4: bl      #0x2b70d54                                 fn_2b70d54
02c9fdc8: ldr     x8, [x19]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9fdcc: ldr     x1, [x27]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9fdd0: ldr     x8, [x8, #0xb8]                            
02c9fdd4: add     x0, x8, #0x260                             
02c9fdd8: str     x1, [x8, #0x260]                           
02c9fddc: bl      #0x2b70d54                                 fn_2b70d54
02c9fde0: ldr     x8, [x19]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9fde4: adrp    x9, #0x6265000                             
02c9fde8: ldr     x9, [x9, #0xc58]                           S:'collection'
02c9fdec: ldr     x8, [x8, #0xb8]                            
02c9fdf0: ldr     x1, [x9]                                   M:AdsManager::<OnApplicationPause>b__26_0
02c9fdf4: add     x0, x8, #0x268                             
02c9fdf8: str     x1, [x8, #0x268]                           
02c9fdfc: bl      #0x2b70d54                                 fn_2b70d54
02c9fe00: ldr     x8, [x19]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9fe04: adrp    x9, #0x1088000                             
02c9fe08: adrp    x10, #0x1087000                            
02c9fe0c: ldr     q0, [x9, #0x790]                           [1088790]=200000001 f=1.4013e-45,2.8026e-45
02c9fe10: ldr     q1, [x10, #0x300]                          [1087300]=600000005 f=7.00649e-45,8.40779e-45
02c9fe14: adrp    x10, #0x6265000                            
02c9fe18: ldr     x8, [x8, #0xb8]                            
02c9fe1c: adrp    x9, #0x1040000                             
02c9fe20: ldr     d2, [x9, #0x9a0]                           [10409a0]=a00000009 f=1.26117e-44,1.4013e-44
02c9fe24: mov     w9, #0xb                                   
02c9fe28: stp     q0, q1, [x8, #0x270]                       
02c9fe2c: add     x0, x8, #0x2a0                             
02c9fe30: ldr     x10, [x10, #0xc80]                         S:'open_door'
02c9fe34: str     d2, [x8, #0x290]                           
02c9fe38: str     w9, [x8, #0x298]                           
02c9fe3c: ldr     x1, [x10]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9fe40: str     x1, [x8, #0x2a0]                           
02c9fe44: bl      #0x2b70d54                                 fn_2b70d54
02c9fe48: ldr     x8, [x19]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9fe4c: adrp    x9, #0x6265000                             
02c9fe50: ldr     x9, [x9, #0xe70]                           S:'get_bag'
02c9fe54: ldr     x8, [x8, #0xb8]                            
02c9fe58: ldr     x1, [x9]                                   M:AdsManager::<OnApplicationPause>b__26_0
02c9fe5c: add     x0, x8, #0x2a8                             
02c9fe60: str     x1, [x8, #0x2a8]                           
02c9fe64: bl      #0x2b70d54                                 fn_2b70d54
02c9fe68: ldr     x8, [x19]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9fe6c: adrp    x9, #0x6265000                             
02c9fe70: ldr     x9, [x9, #0xde0]                           S:'checkout'
02c9fe74: ldr     x8, [x8, #0xb8]                            
02c9fe78: ldr     x1, [x9]                                   M:AdsManager::<OnApplicationPause>b__26_0
02c9fe7c: add     x0, x8, #0x2b0                             
02c9fe80: str     x1, [x8, #0x2b0]                           
02c9fe84: bl      #0x2b70d54                                 fn_2b70d54
02c9fe88: ldr     x8, [x19]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9fe8c: adrp    x9, #0x6265000                             
02c9fe90: ldr     x9, [x9, #0xde8]                           S:'open_bag'
02c9fe94: ldr     x8, [x8, #0xb8]                            
02c9fe98: ldr     x1, [x9]                                   M:AdsManager::<OnApplicationPause>b__26_0
02c9fe9c: add     x0, x8, #0x2b8                             
02c9fea0: str     x1, [x8, #0x2b8]                           
02c9fea4: bl      #0x2b70d54                                 fn_2b70d54
02c9fea8: ldr     x8, [x19]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9feac: adrp    x9, #0x6265000                             
02c9feb0: ldr     x9, [x9, #0xef0]                           S:'put_to_collection'
02c9feb4: ldr     x8, [x8, #0xb8]                            
02c9feb8: ldr     x1, [x9]                                   M:AdsManager::<OnApplicationPause>b__26_0
02c9febc: add     x0, x8, #0x2c0                             
02c9fec0: str     x1, [x8, #0x2c0]                           
02c9fec4: bl      #0x2b70d54                                 fn_2b70d54
02c9fec8: ldr     x8, [x19]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9fecc: ldr     x1, [x27]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9fed0: ldr     x8, [x8, #0xb8]                            
02c9fed4: add     x0, x8, #0x2c8                             
02c9fed8: str     x1, [x8, #0x2c8]                           
02c9fedc: bl      #0x2b70d54                                 fn_2b70d54
02c9fee0: adrp    x9, #0x1087000                             
02c9fee4: ldr     x8, [x19]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9fee8: adrp    x10, #0x1040000                            
02c9feec: ldr     q1, [x9, #0xea0]                           [1087ea0]=300000002 f=2.8026e-45,4.2039e-45
02c9fef0: adrp    x9, #0x6265000                             
02c9fef4: ldr     d0, [x10, #0xdf0]                          [1040df0]=700000006 f=8.40779e-45,9.80909e-45
02c9fef8: ldr     x8, [x8, #0xb8]                            
02c9fefc: str     q1, [sp]                                   
02c9ff00: ldr     x9, [x9, #0xea0]                           S:'scoop'
02c9ff04: add     x0, x8, #0x2e8                             
02c9ff08: str     q1, [x8, #0x2d0]                           
02c9ff0c: str     d0, [x8, #0x2e0]                           
02c9ff10: ldr     x1, [x9]                                   M:AdsManager::<OnApplicationPause>b__26_0
02c9ff14: str     x1, [x8, #0x2e8]                           
02c9ff18: bl      #0x2b70d54                                 fn_2b70d54
02c9ff1c: ldr     x8, [x19]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9ff20: adrp    x9, #0x6265000                             
02c9ff24: ldr     x9, [x9, #0xbf0]                           S:'unbox'
02c9ff28: ldr     x8, [x8, #0xb8]                            
02c9ff2c: ldr     x1, [x9]                                   M:AdsManager::<OnApplicationPause>b__26_0
02c9ff30: add     x0, x8, #0x2f0                             
02c9ff34: str     x1, [x8, #0x2f0]                           
02c9ff38: bl      #0x2b70d54                                 fn_2b70d54
02c9ff3c: ldr     x8, [x19]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9ff40: adrp    x9, #0x6265000                             
02c9ff44: ldr     x9, [x9, #0xbd8]                           S:'select_box'
02c9ff48: ldr     x8, [x8, #0xb8]                            
02c9ff4c: ldr     x1, [x9]                                   M:AdsManager::<OnApplicationPause>b__26_0
02c9ff50: add     x0, x8, #0x2f8                             
02c9ff54: str     x1, [x8, #0x2f8]                           
02c9ff58: bl      #0x2b70d54                                 fn_2b70d54
02c9ff5c: ldr     x8, [x19]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9ff60: adrp    x9, #0x6265000                             
02c9ff64: ldr     x9, [x9, #0xd88]                           S:'wrapping'
02c9ff68: ldr     x8, [x8, #0xb8]                            
02c9ff6c: ldr     x1, [x9]                                   M:AdsManager::<OnApplicationPause>b__26_0
02c9ff70: add     x0, x8, #0x300                             
02c9ff74: str     x1, [x8, #0x300]                           
02c9ff78: bl      #0x2b70d54                                 fn_2b70d54
02c9ff7c: ldr     x8, [x19]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9ff80: adrp    x9, #0x6265000                             
02c9ff84: ldr     x9, [x9, #0xd70]                           S:'card'
02c9ff88: ldr     x8, [x8, #0xb8]                            
02c9ff8c: ldr     x1, [x9]                                   M:AdsManager::<OnApplicationPause>b__26_0
02c9ff90: add     x0, x8, #0x308                             
02c9ff94: str     x1, [x8, #0x308]                           
02c9ff98: bl      #0x2b70d54                                 fn_2b70d54
02c9ff9c: ldr     x8, [x19]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9ffa0: adrp    x9, #0x6265000                             
02c9ffa4: ldr     x9, [x9, #0xcd8]                           S:'wrap_done'
02c9ffa8: ldr     x8, [x8, #0xb8]                            
02c9ffac: ldr     x1, [x9]                                   M:AdsManager::<OnApplicationPause>b__26_0
02c9ffb0: add     x0, x8, #0x310                             
02c9ffb4: str     x1, [x8, #0x310]                           
02c9ffb8: bl      #0x2b70d54                                 fn_2b70d54
02c9ffbc: ldr     x8, [x19]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9ffc0: adrp    x9, #0x6265000                             
02c9ffc4: ldr     x9, [x9, #0xc10]                           S:'delivery'
02c9ffc8: ldr     x8, [x8, #0xb8]                            
02c9ffcc: ldr     x1, [x9]                                   M:AdsManager::<OnApplicationPause>b__26_0
02c9ffd0: add     x0, x8, #0x318                             
02c9ffd4: str     x1, [x8, #0x318]                           
02c9ffd8: bl      #0x2b70d54                                 fn_2b70d54
02c9ffdc: ldr     x8, [x19]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9ffe0: ldr     x1, [x27]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9ffe4: ldr     x8, [x8, #0xb8]                            
02c9ffe8: add     x0, x8, #0x320                             
02c9ffec: str     x1, [x8, #0x320]                           
02c9fff0: bl      #0x2b70d54                                 fn_2b70d54
02c9fff4: ldr     x8, [x19]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9fff8: adrp    x10, #0x6265000                            
02c9fffc: adrp    x9, #0x1088000                             
02ca0000: ldr     q0, [x9, #0x7a0]                           [10887a0]=700000006 f=8.40779e-45,9.80909e-45
02ca0004: ldr     x8, [x8, #0xb8]                            
02ca0008: ldr     x10, [x10, #0xca8]                         S:'main_diy'
02ca000c: ldr     q1, [sp]                                   
02ca0010: ldr     x1, [x10]                                  M:AdsManager::<OnApplicationPause>b__26_0
02ca0014: add     x9, x8, #0x328                             
02ca0018: add     x0, x8, #0x348                             
02ca001c: stp     q1, q0, [x9]                               
02ca0020: str     x1, [x8, #0x348]                           
02ca0024: bl      #0x2b70d54                                 fn_2b70d54
02ca0028: ldr     x8, [x19]                                  M:AdsManager::<OnApplicationPause>b__26_0
02ca002c: adrp    x9, #0x6265000                             
02ca0030: ldr     x9, [x9, #0xe18]                           S:'blind_bag'
02ca0034: ldr     x8, [x8, #0xb8]                            
02ca0038: ldr     x1, [x9]                                   M:AdsManager::<OnApplicationPause>b__26_0
02ca003c: add     x0, x8, #0x350                             
02ca0040: str     x1, [x8, #0x350]                           
02ca0044: bl      #0x2b70d54                                 fn_2b70d54
02ca0048: ldr     x8, [x19]                                  M:AdsManager::<OnApplicationPause>b__26_0
02ca004c: adrp    x9, #0x6265000                             
02ca0050: ldr     x9, [x9, #0xe38]                           S:'lucky_scoop'
02ca0054: ldr     x8, [x8, #0xb8]                            
02ca0058: ldr     x1, [x9]                                   M:AdsManager::<OnApplicationPause>b__26_0
02ca005c: add     x0, x8, #0x358                             
02ca0060: str     x1, [x8, #0x358]                           
02ca0064: bl      #0x2b70d54                                 fn_2b70d54
02ca0068: ldr     x8, [x19]                                  M:AdsManager::<OnApplicationPause>b__26_0
02ca006c: adrp    x9, #0x6265000                             
02ca0070: ldr     x9, [x9, #0xec8]                           S:'3d_figure'
02ca0074: ldr     x8, [x8, #0xb8]                            
02ca0078: ldr     x1, [x9]                                   M:AdsManager::<OnApplicationPause>b__26_0
02ca007c: add     x0, x8, #0x360                             
02ca0080: str     x1, [x8, #0x360]                           
02ca0084: bl      #0x2b70d54                                 fn_2b70d54
02ca0088: ldr     x8, [x19]                                  M:AdsManager::<OnApplicationPause>b__26_0
02ca008c: adrp    x9, #0x6265000                             
02ca0090: ldr     x9, [x9, #0xd60]                           S:'trading'
02ca0094: ldr     x8, [x8, #0xb8]                            
02ca0098: ldr     x1, [x9]                                   M:AdsManager::<OnApplicationPause>b__26_0
02ca009c: add     x0, x8, #0x368                             
02ca00a0: str     x1, [x8, #0x368]                           
02ca00a4: bl      #0x2b70d54                                 fn_2b70d54
02ca00a8: ldr     x8, [x19]                                  M:AdsManager::<OnApplicationPause>b__26_0
02ca00ac: ldr     x1, [x22]                                  M:AdsManager::<OnApplicationPause>b__26_0
02ca00b0: ldr     x8, [x8, #0xb8]                            
02ca00b4: add     x0, x8, #0x370                             
02ca00b8: str     x1, [x8, #0x370]                           
02ca00bc: bl      #0x2b70d54                                 fn_2b70d54
02ca00c0: ldr     x8, [x19]                                  M:AdsManager::<OnApplicationPause>b__26_0
02ca00c4: ldr     x1, [x21]                                  M:AdsManager::<OnApplicationPause>b__26_0
02ca00c8: ldr     x8, [x8, #0xb8]                            
02ca00cc: add     x0, x8, #0x378                             
02ca00d0: str     x1, [x8, #0x378]                           
02ca00d4: bl      #0x2b70d54                                 fn_2b70d54
02ca00d8: ldr     x8, [x19]                                  M:AdsManager::<OnApplicationPause>b__26_0
02ca00dc: adrp    x9, #0x6265000                             
02ca00e0: ldr     x9, [x9, #0xda0]                           S:'charm'
02ca00e4: ldr     x8, [x8, #0xb8]                            
02ca00e8: ldr     x1, [x9]                                   M:AdsManager::<OnApplicationPause>b__26_0
02ca00ec: add     x0, x8, #0x380                             
02ca00f0: str     x1, [x8, #0x380]                           
02ca00f4: bl      #0x2b70d54                                 fn_2b70d54
02ca00f8: ldr     x8, [x19]                                  M:AdsManager::<OnApplicationPause>b__26_0
02ca00fc: ldr     x1, [x20]                                  M:AdsManager::<OnApplicationPause>b__26_0
02ca0100: ldr     x8, [x8, #0xb8]                            
02ca0104: add     x0, x8, #0x388                             
02ca0108: str     x1, [x8, #0x388]                           
02ca010c: bl      #0x2b70d54                                 fn_2b70d54
02ca0110: ldr     x8, [x19]                                  M:AdsManager::<OnApplicationPause>b__26_0
02ca0114: adrp    x9, #0x6265000                             
02ca0118: ldr     x9, [x9, #0xc90]                           S:'success'
02ca011c: ldr     x8, [x8, #0xb8]                            
02ca0120: ldr     x1, [x9]                                   M:AdsManager::<OnApplicationPause>b__26_0
02ca0124: add     x0, x8, #0x390                             
02ca0128: str     x1, [x8, #0x390]                           
02ca012c: bl      #0x2b70d54                                 fn_2b70d54
02ca0130: ldr     x8, [x19]                                  M:AdsManager::<OnApplicationPause>b__26_0
02ca0134: adrp    x9, #0x6265000                             
02ca0138: ldr     x9, [x9, #0xc20]                           S:'unavailable'
02ca013c: ldr     x8, [x8, #0xb8]                            
02ca0140: ldr     x1, [x9]                                   M:AdsManager::<OnApplicationPause>b__26_0
02ca0144: add     x0, x8, #0x398                             
02ca0148: str     x1, [x8, #0x398]                           
02ca014c: bl      #0x2b70d54                                 fn_2b70d54
02ca0150: ldr     x8, [x19]                                  M:AdsManager::<OnApplicationPause>b__26_0
02ca0154: adrp    x9, #0x6265000                             
02ca0158: ldr     x9, [x9, #0xe00]                           S:'failed'
02ca015c: ldr     x8, [x8, #0xb8]                            
02ca0160: ldr     x1, [x9]                                   M:AdsManager::<OnApplicationPause>b__26_0
02ca0164: add     x0, x8, #0x3a0                             
02ca0168: str     x1, [x8, #0x3a0]                           
02ca016c: bl      #0x2b70d54                                 fn_2b70d54
02ca0170: ldr     x8, [x19]                                  M:AdsManager::<OnApplicationPause>b__26_0
02ca0174: adrp    x9, #0x6265000                             
02ca0178: ldr     x9, [x9, #0xe90]                           S:'not_completed'
02ca017c: ldr     x8, [x8, #0xb8]                            
02ca0180: ldr     x1, [x9]                                   M:AdsManager::<OnApplicationPause>b__26_0
02ca0184: add     x0, x8, #0x3a8                             
02ca0188: str     x1, [x8, #0x3a8]                           
02ca018c: bl      #0x2b70d54                                 fn_2b70d54
02ca0190: ldr     x8, [x19]                                  M:AdsManager::<OnApplicationPause>b__26_0
02ca0194: adrp    x9, #0x6265000                             
02ca0198: ldr     x9, [x9, #0xd48]                           S:'home_button'
02ca019c: ldr     x8, [x8, #0xb8]                            
02ca01a0: ldr     x1, [x9]                                   M:AdsManager::<OnApplicationPause>b__26_0
02ca01a4: add     x0, x8, #0x3b0                             
02ca01a8: str     x1, [x8, #0x3b0]                           
02ca01ac: bl      #0x2b70d54                                 fn_2b70d54
02ca01b0: ldr     x8, [x19]                                  M:AdsManager::<OnApplicationPause>b__26_0
02ca01b4: adrp    x9, #0x6265000                             
02ca01b8: ldr     x9, [x9, #0xca0]                           S:'trading_enter'
02ca01bc: ldr     x8, [x8, #0xb8]                            
02ca01c0: ldr     x1, [x9]                                   M:AdsManager::<OnApplicationPause>b__26_0
02ca01c4: add     x0, x8, #0x3b8                             
02ca01c8: str     x1, [x8, #0x3b8]                           
02ca01cc: bl      #0x2b70d54                                 fn_2b70d54
02ca01d0: ldr     x8, [x19]                                  M:AdsManager::<OnApplicationPause>b__26_0
02ca01d4: adrp    x9, #0x6265000                             
02ca01d8: ldr     x9, [x9, #0xd38]                           S:'trading_item_select'
02ca01dc: ldr     x8, [x8, #0xb8]                            
02ca01e0: ldr     x1, [x9]                                   M:AdsManager::<OnApplicationPause>b__26_0
02ca01e4: add     x0, x8, #0x3c0                             
02ca01e8: str     x1, [x8, #0x3c0]                           
02ca01ec: bl      #0x2b70d54                                 fn_2b70d54
02ca01f0: ldr     x8, [x19]                                  M:AdsManager::<OnApplicationPause>b__26_0
02ca01f4: adrp    x9, #0x6265000                             
02ca01f8: ldr     x9, [x9, #0xd50]                           S:'trading_add_more'
02ca01fc: ldr     x8, [x8, #0xb8]                            
02ca0200: ldr     x1, [x9]                                   M:AdsManager::<OnApplicationPause>b__26_0
02ca0204: add     x0, x8, #0x3c8                             
02ca0208: str     x1, [x8, #0x3c8]                           
02ca020c: bl      #0x2b70d54                                 fn_2b70d54
02ca0210: ldr     x8, [x19]                                  M:AdsManager::<OnApplicationPause>b__26_0
02ca0214: adrp    x9, #0x6265000                             
02ca0218: ldr     x9, [x9, #0xcb0]                           S:'trading_counter_request'
02ca021c: ldr     x8, [x8, #0xb8]                            
02ca0220: ldr     x1, [x9]                                   M:AdsManager::<OnApplicationPause>b__26_0
02ca0224: add     x0, x8, #0x3d0                             
02ca0228: str     x1, [x8, #0x3d0]                           
02ca022c: bl      #0x2b70d54                                 fn_2b70d54
02ca0230: ldr     x8, [x19]                                  M:AdsManager::<OnApplicationPause>b__26_0
02ca0234: adrp    x9, #0x6265000                             
02ca0238: ldr     x9, [x9, #0xbb8]                           S:'trading_complete'
02ca023c: ldr     x8, [x8, #0xb8]                            
02ca0240: ldr     x1, [x9]                                   M:AdsManager::<OnApplicationPause>b__26_0
02ca0244: add     x0, x8, #0x3d8                             
02ca0248: str     x1, [x8, #0x3d8]                           
02ca024c: bl      #0x2b70d54                                 fn_2b70d54
02ca0250: ldr     x8, [x19]                                  M:AdsManager::<OnApplicationPause>b__26_0
02ca0254: adrp    x9, #0x6265000                             
02ca0258: ldr     x9, [x9, #0xe60]                           S:'trading_deny'
02ca025c: ldr     x8, [x8, #0xb8]                            
02ca0260: ldr     x1, [x9]                                   M:AdsManager::<OnApplicationPause>b__26_0
02ca0264: add     x0, x8, #0x3e0                             
02ca0268: str     x1, [x8, #0x3e0]                           
02ca026c: bl      #0x2b70d54                                 fn_2b70d54
02ca0270: ldr     x8, [x19]                                  M:AdsManager::<OnApplicationPause>b__26_0
02ca0274: adrp    x9, #0x6265000                             
02ca0278: ldr     x9, [x9, #0xb98]                           S:'trading_steal_ad'
02ca027c: ldr     x8, [x8, #0xb8]                            
02ca0280: ldr     x1, [x9]                                   M:AdsManager::<OnApplicationPause>b__26_0
02ca0284: add     x0, x8, #0x3e8                             
02ca0288: str     x1, [x8, #0x3e8]                           
02ca028c: bl      #0x2b70d54                                 fn_2b70d54
02ca0290: ldr     x8, [x19]                                  M:AdsManager::<OnApplicationPause>b__26_0
02ca0294: adrp    x9, #0x6265000                             
02ca0298: ldr     x9, [x9, #0xdf8]                           S:'entry_source'
02ca029c: ldr     x8, [x8, #0xb8]                            
02ca02a0: ldr     x1, [x9]                                   M:AdsManager::<OnApplicationPause>b__26_0
02ca02a4: add     x0, x8, #0x3f0                             
02ca02a8: str     x1, [x8, #0x3f0]                           
02ca02ac: bl      #0x2b70d54                                 fn_2b70d54
02ca02b0: ldr     x8, [x19]                                  M:AdsManager::<OnApplicationPause>b__26_0
02ca02b4: adrp    x9, #0x6265000                             
02ca02b8: ldr     x9, [x9, #0xd00]                           S:'side'
02ca02bc: ldr     x8, [x8, #0xb8]                            
02ca02c0: ldr     x1, [x9]                                   M:AdsManager::<OnApplicationPause>b__26_0
02ca02c4: add     x0, x8, #0x3f8                             
02ca02c8: str     x1, [x8, #0x3f8]                           
02ca02cc: bl      #0x2b70d54                                 fn_2b70d54
02ca02d0: ldr     x8, [x19]                                  M:AdsManager::<OnApplicationPause>b__26_0
02ca02d4: adrp    x9, #0x6265000                             
02ca02d8: ldr     x9, [x9, #0xf10]                           S:'item_value'
02ca02dc: ldr     x8, [x8, #0xb8]                            
02ca02e0: ldr     x1, [x9]                                   M:AdsManager::<OnApplicationPause>b__26_0
02ca02e4: add     x0, x8, #0x400                             
02ca02e8: str     x1, [x8, #0x400]                           
02ca02ec: bl      #0x2b70d54                                 fn_2b70d54
02ca02f0: ldr     x8, [x19]                                  M:AdsManager::<OnApplicationPause>b__26_0
02ca02f4: adrp    x9, #0x6265000                             
02ca02f8: ldr     x9, [x9, #0xc78]                           S:'request_index'
02ca02fc: ldr     x8, [x8, #0xb8]                            
02ca0300: ldr     x1, [x9]                                   M:AdsManager::<OnApplicationPause>b__26_0
02ca0304: add     x0, x8, #0x408                             
02ca0308: str     x1, [x8, #0x408]                           
02ca030c: bl      #0x2b70d54                                 fn_2b70d54
02ca0310: ldr     x8, [x19]                                  M:AdsManager::<OnApplicationPause>b__26_0
02ca0314: adrp    x9, #0x6265000                             
02ca0318: ldr     x9, [x9, #0xd20]                           S:'npc_response'
02ca031c: ldr     x8, [x8, #0xb8]                            
02ca0320: ldr     x1, [x9]                                   M:AdsManager::<OnApplicationPause>b__26_0
02ca0324: add     x0, x8, #0x410                             
02ca0328: str     x1, [x8, #0x410]                           
02ca032c: bl      #0x2b70d54                                 fn_2b70d54
02ca0330: ldr     x8, [x19]                                  M:AdsManager::<OnApplicationPause>b__26_0
02ca0334: adrp    x9, #0x6265000                             
02ca0338: ldr     x9, [x9, #0xeb8]                           S:'offer_value_before'
02ca033c: ldr     x8, [x8, #0xb8]                            
02ca0340: ldr     x1, [x9]                                   M:AdsManager::<OnApplicationPause>b__26_0
02ca0344: add     x0, x8, #0x418                             
02ca0348: str     x1, [x8, #0x418]                           
02ca034c: bl      #0x2b70d54                                 fn_2b70d54
02ca0350: ldr     x8, [x19]                                  M:AdsManager::<OnApplicationPause>b__26_0
02ca0354: adrp    x9, #0x6265000                             
02ca0358: ldr     x9, [x9, #0xf20]                           S:'offer_value_after'
02ca035c: ldr     x8, [x8, #0xb8]                            
02ca0360: ldr     x1, [x9]                                   M:AdsManager::<OnApplicationPause>b__26_0
02ca0364: add     x0, x8, #0x420                             
02ca0368: str     x1, [x8, #0x420]                           
02ca036c: bl      #0x2b70d54                                 fn_2b70d54
02ca0370: ldr     x8, [x19]                                  M:AdsManager::<OnApplicationPause>b__26_0
02ca0374: adrp    x9, #0x6265000                             
02ca0378: ldr     x9, [x9, #0xba8]                           S:'counter_request_index'
02ca037c: ldr     x8, [x8, #0xb8]                            
02ca0380: ldr     x1, [x9]                                   M:AdsManager::<OnApplicationPause>b__26_0
02ca0384: add     x0, x8, #0x428                             
02ca0388: str     x1, [x8, #0x428]                           
02ca038c: bl      #0x2b70d54                                 fn_2b70d54
02ca0390: ldr     x8, [x19]                                  M:AdsManager::<OnApplicationPause>b__26_0
02ca0394: adrp    x9, #0x6265000                             
02ca0398: ldr     x9, [x9, #0xcc8]                           S:'accepted'
02ca039c: ldr     x8, [x8, #0xb8]                            
02ca03a0: ldr     x1, [x9]                                   M:AdsManager::<OnApplicationPause>b__26_0
02ca03a4: add     x0, x8, #0x430                             
02ca03a8: str     x1, [x8, #0x430]                           
02ca03ac: bl      #0x2b70d54                                 fn_2b70d54
02ca03b0: ldr     x8, [x19]                                  M:AdsManager::<OnApplicationPause>b__26_0
02ca03b4: adrp    x9, #0x6265000                             
02ca03b8: ldr     x9, [x9, #0xd08]                           S:'your_value'
02ca03bc: ldr     x8, [x8, #0xb8]                            
02ca03c0: ldr     x1, [x9]                                   M:AdsManager::<OnApplicationPause>b__26_0
02ca03c4: add     x0, x8, #0x438                             
02ca03c8: str     x1, [x8, #0x438]                           
02ca03cc: bl      #0x2b70d54                                 fn_2b70d54
02ca03d0: ldr     x8, [x19]                                  M:AdsManager::<OnApplicationPause>b__26_0
02ca03d4: adrp    x9, #0x6265000                             
02ca03d8: ldr     x9, [x9, #0xdf0]                           S:'npc_value'
02ca03dc: ldr     x8, [x8, #0xb8]                            
02ca03e0: ldr     x1, [x9]                                   M:AdsManager::<OnApplicationPause>b__26_0
02ca03e4: add     x0, x8, #0x440                             
02ca03e8: str     x1, [x8, #0x440]                           
02ca03ec: bl      #0x2b70d54                                 fn_2b70d54
02ca03f0: ldr     x8, [x19]                                  M:AdsManager::<OnApplicationPause>b__26_0
02ca03f4: adrp    x9, #0x6265000                             
02ca03f8: ldr     x9, [x9, #0xc50]                           S:'trade_percent'
02ca03fc: ldr     x8, [x8, #0xb8]                            
02ca0400: ldr     x1, [x9]                                   M:AdsManager::<OnApplicationPause>b__26_0
02ca0404: add     x0, x8, #0x448                             
02ca0408: str     x1, [x8, #0x448]                           
02ca040c: bl      #0x2b70d54                                 fn_2b70d54
02ca0410: ldr     x8, [x19]                                  M:AdsManager::<OnApplicationPause>b__26_0
02ca0414: adrp    x9, #0x6265000                             
02ca0418: ldr     x9, [x9, #0xbe8]                           S:'item_count_given'
02ca041c: ldr     x8, [x8, #0xb8]                            
02ca0420: ldr     x1, [x9]                                   M:AdsManager::<OnApplicationPause>b__26_0
02ca0424: add     x0, x8, #0x450                             
02ca0428: str     x1, [x8, #0x450]                           
02ca042c: bl      #0x2b70d54                                 fn_2b70d54
02ca0430: ldr     x8, [x19]                                  M:AdsManager::<OnApplicationPause>b__26_0
02ca0434: adrp    x9, #0x6265000                             
02ca0438: ldr     x9, [x9, #0xef8]                           S:'item_count_received'
02ca043c: ldr     x8, [x8, #0xb8]                            
02ca0440: ldr     x1, [x9]                                   M:AdsManager::<OnApplicationPause>b__26_0
02ca0444: add     x0, x8, #0x458                             
02ca0448: str     x1, [x8, #0x458]                           
02ca044c: bl      #0x2b70d54                                 fn_2b70d54
02ca0450: adrp    x9, #0x6265000                             
02ca0454: ldr     x8, [x19]                                  M:AdsManager::<OnApplicationPause>b__26_0
02ca0458: ldr     x9, [x9, #0xd98]                           S:'ad_result'
02ca045c: ldp     x20, x19, [sp, #0x60]                      
02ca0460: ldr     x8, [x8, #0xb8]                            
02ca0464: ldp     x22, x21, [sp, #0x50]                      
02ca0468: ldr     x1, [x9]                                   M:AdsManager::<OnApplicationPause>b__26_0
02ca046c: ldp     x24, x23, [sp, #0x40]                      
02ca0470: add     x0, x8, #0x460                             
02ca0474: ldp     x26, x25, [sp, #0x30]                      
02ca0478: str     x1, [x8, #0x460]                           
02ca047c: ldp     x28, x27, [sp, #0x20]                      
02ca0480: ldp     x29, x30, [sp, #0x10]                      
02ca0484: add     sp, sp, #0x70                              
02ca0488: b       #0x2b70d54                                 
02ca048c: stp     x30, x23, [sp, #-0x30]!                    
02ca0490: stp     x22, x21, [sp, #0x10]                      
02ca0494: stp     x20, x19, [sp, #0x20]                      
02ca0498: adrp    x22, #0x662f000                            
02ca049c: mov     x20, x2                                    
02ca04a0: mov     x21, x1                                    
02ca04a4: ldrb    w8, [x22, #0xa76]                          
02ca04a8: mov     x19, x0                                    
02ca04ac: cbnz    w8, #0x2ca04e8                             
02ca04b0: adrp    x0, #0x6399000                             
02ca04b4: add     x0, x0, #0x5c0                             &63995c0
02ca04b8: bl      #0x2b70db0                                 fn_2b70db0
02ca04bc: adrp    x0, #0x6397000                             
02ca04c0: add     x0, x0, #0x378                             &6397378
02ca04c4: bl      #0x2b70db0                                 fn_2b70db0
02ca04c8: adrp    x0, #0x63e8000                             
02ca04cc: add     x0, x0, #0xd30                             &63e8d30
02ca04d0: bl      #0x2b70db0                                 fn_2b70db0
02ca04d4: adrp    x0, #0x63f1000                             
02ca04d8: add     x0, x0, #0x68                              &63f1068
02ca04dc: bl      #0x2b70db0                                 fn_2b70db0
02ca04e0: mov     w8, #1                                     
02ca04e4: strb    w8, [x22, #0xa76]                          
02ca04e8: mov     x0, x21                                    
02ca04ec: mov     x1, xzr                                    
02ca04f0: bl      #0x4ca6234                                 System.String::IsNullOrEmpty
02ca04f4: adrp    x8, #0x6265000                             
02ca04f8: tst     w0, #1                                     
02ca04fc: ldr     x8, [x8, #0xf30]                           S:'F2'
02ca0500: ldr     x8, [x8]                                   M:AdsManager::<OnApplicationPause>b__26_0
02ca0504: csel    x21, x8, x21, ne                           
02ca0508: cbnz    x20, #0x2ca0544                            
02ca050c: adrp    x8, #0x6399000                             
02ca0510: add     x8, x8, #0x5c0                             &63995c0
02ca0514: ldr     x0, [x8]                                   [6399000]=2000d897 f=1.09137e-19,0
02ca0518: ldr     w8, [x0, #0xe4]                            [63f10e4]=a000278900000000 f=0,-1.08551e-19
02ca051c: cbnz    w8, #0x2ca0524                             
02ca0520: bl      #0x2b70f30                                 fn_2b70f30
02ca0524: mov     x0, xzr                                    
02ca0528: bl      #0x4d9ea74                                 System.Globalization.CultureInfo::get_InvariantCulture
02ca052c: cbz     x0, #0x2ca06c0                             
02ca0530: ldr     x8, [x0]                                   [63f1000]=a000274f f=-1.0855e-19,0
02ca0534: ldr     x9, [x8, #0x218]                           [6399218]=2000dad3 f=1.09144e-19,0
02ca0538: ldr     x1, [x8, #0x220]                           [6399220]=2000dadd f=1.09144e-19,0
02ca053c: blr     x9                                         
02ca0540: mov     x20, x0                                    
02ca0544: adrp    x8, #0x6263000                             
02ca0548: mov     w1, #4                                     
02ca054c: ldr     x8, [x8, #0xa80]                           T:type24502(k1d)
02ca0550: ldr     x0, [x8]                                   &2c5bbd4(=a9bd7bfdd503233f)
02ca0554: bl      #0x2b70ea0                                 fn_2b70ea0
02ca0558: mov     x22, x0                                    
02ca055c: mov     x0, x19                                    
02ca0560: mov     x1, x21                                    
02ca0564: mov     x2, x20                                    
02ca0568: mov     x3, xzr                                    
02ca056c: bl      #0x4e24868                                 System.Single::ToString
02ca0570: cbz     x22, #0x2ca06c0                            
02ca0574: mov     x23, x0                                    
02ca0578: cbz     x0, #0x2ca0590                             
02ca057c: ldr     x8, [x22]                                  &2b706c4(=eb01011ff9400808)
02ca0580: mov     x0, x23                                    
02ca0584: ldr     x1, [x8, #0x40]                            [6263040]=0 f=0,0
02ca0588: bl      #0x2b70f34                                 fn_2b70f34
02ca058c: cbz     x0, #0x2ca06b4                             
02ca0590: ldr     w8, [x22, #0x18]                           [662f018]=6000014 f=2.40742e-35,0
02ca0594: cbz     w8, #0x2ca06b0                             
02ca0598: mov     x0, x22                                    
02ca059c: mov     x1, x23                                    
02ca05a0: str     x23, [x0, #0x20]!                          .game_mode_start
02ca05a4: bl      #0x2b70d54                                 fn_2b70d54
02ca05a8: add     x0, x19, #4                                &6265004
02ca05ac: mov     x1, x21                                    
02ca05b0: mov     x2, x20                                    
02ca05b4: mov     x3, xzr                                    
02ca05b8: bl      #0x4e24868                                 System.Single::ToString
02ca05bc: mov     x23, x0                                    
02ca05c0: cbz     x0, #0x2ca05d8                             
02ca05c4: ldr     x8, [x22]                                  &2b706c4(=eb01011ff9400808)
02ca05c8: mov     x0, x23                                    
02ca05cc: ldr     x1, [x8, #0x40]                            [6263040]=0 f=0,0
02ca05d0: bl      #0x2b70f34                                 fn_2b70f34
02ca05d4: cbz     x0, #0x2ca06b4                             
02ca05d8: ldr     w8, [x22, #0x18]                           [662f018]=6000014 f=2.40742e-35,0
02ca05dc: tst     w8, #0xfffffffe                            
02ca05e0: b.eq    #0x2ca06b0                                 
02ca05e4: mov     x0, x22                                    
02ca05e8: mov     x1, x23                                    
02ca05ec: str     x23, [x0, #0x28]!                          .game_mode_step_enter
02ca05f0: bl      #0x2b70d54                                 fn_2b70d54
02ca05f4: add     x0, x19, #8                                &6265008
02ca05f8: mov     x1, x21                                    
02ca05fc: mov     x2, x20                                    
02ca0600: mov     x3, xzr                                    
02ca0604: bl      #0x4e24868                                 System.Single::ToString
02ca0608: mov     x23, x0                                    
02ca060c: cbz     x0, #0x2ca0624                             
02ca0610: ldr     x8, [x22]                                  &2b706c4(=eb01011ff9400808)
02ca0614: mov     x0, x23                                    
02ca0618: ldr     x1, [x8, #0x40]                            [6263040]=0 f=0,0
02ca061c: bl      #0x2b70f34                                 fn_2b70f34
02ca0620: cbz     x0, #0x2ca06b4                             
02ca0624: ldr     w8, [x22, #0x18]                           [662f018]=6000014 f=2.40742e-35,0
02ca0628: cmp     w8, #2                                     
02ca062c: b.ls    #0x2ca06b0                                 
02ca0630: mov     x0, x22                                    
02ca0634: mov     x1, x23                                    
02ca0638: str     x23, [x0, #0x30]!                          .game_mode_step_complete
02ca063c: bl      #0x2b70d54                                 fn_2b70d54
02ca0640: add     x0, x19, #0xc                              &626500c
02ca0644: mov     x1, x21                                    
02ca0648: mov     x2, x20                                    
02ca064c: mov     x3, xzr                                    
02ca0650: bl      #0x4e24868                                 System.Single::ToString
02ca0654: mov     x19, x0                                    
02ca0658: cbz     x0, #0x2ca0670                             
02ca065c: ldr     x8, [x22]                                  &2b706c4(=eb01011ff9400808)
02ca0660: mov     x0, x19                                    
02ca0664: ldr     x1, [x8, #0x40]                            [6263040]=0 f=0,0
02ca0668: bl      #0x2b70f34                                 fn_2b70f34
02ca066c: cbz     x0, #0x2ca06b4                             
02ca0670: ldr     w8, [x22, #0x18]                           [662f018]=6000014 f=2.40742e-35,0
02ca0674: tst     w8, #0xfffffffc                            
02ca0678: b.eq    #0x2ca06b0                                 
02ca067c: mov     x0, x22                                    
02ca0680: mov     x1, x19                                    
02ca0684: str     x19, [x0, #0x38]!                          .game_mode_exit
02ca0688: bl      #0x2b70d54                                 fn_2b70d54
02ca068c: adrp    x8, #0x6265000                             
02ca0690: mov     x1, x22                                    
02ca0694: mov     x2, xzr                                    
02ca0698: ldr     x8, [x8, #0xf28]                           S:'(x:{0}, y:{1}, width:{2}, height:{3})'
02ca069c: ldp     x20, x19, [sp, #0x20]                      
02ca06a0: ldp     x22, x21, [sp, #0x10]                      
02ca06a4: ldr     x0, [x8]                                   M:AdsManager::<OnApplicationPause>b__26_0
02ca06a8: ldp     x30, x23, [sp], #0x30                      
02ca06ac: b       #0x4ca77a8                                 System.String::Format
02ca06b0: bl      #0x2b71064                                 fn_2b71064
02ca06b4: bl      #0x2b71080                                 fn_2b71080
02ca06b8: mov     x1, xzr                                    
02ca06bc: bl      #0x2b70f20                                 fn_2b70f20
02ca06c0: bl      #0x2b7105c                                 fn_2b7105c
