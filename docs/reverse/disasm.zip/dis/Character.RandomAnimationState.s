#### CLASS Character.RandomAnimationState parent= Character.BaseState
#   field _animationSpineTypes           System.Collections.Generic.List`1<EAnimationSpineType> off=0x28 attr=1 
##  SetAnimationTypes (no body)
## GetAnimationSpineType() -> EAnimationSpineType
---- Character.RandomAnimationState::GetAnimationSpineType 0x2d76104
02d76104: stp     x30, x21, [sp, #-0x20]!                    
02d76108: stp     x20, x19, [sp, #0x10]                      
02d7610c: adrp    x21, #0x6630000                            
02d76110: adrp    x20, #0x626c000                            
02d76114: mov     x19, x0                                    
02d76118: ldrb    w8, [x21, #0x3d5]                          
02d7611c: ldr     x20, [x20, #0x7f0]                         MS:FrameWorkUtility::PickRandom
02d76120: tbnz    w8, #0, #0x2d76138                         
02d76124: adrp    x0, #0x626c000                             
02d76128: ldr     x0, [x0, #0x7f0]                           MS:FrameWorkUtility::PickRandom
02d7612c: bl      #0x2b70db0                                 fn_2b70db0
02d76130: mov     w8, #1                                     
02d76134: strb    w8, [x21, #0x3d5]                          
02d76138: ldr     x0, [x19, #0x28]                           ._animationSpineTypes
02d7613c: ldr     x1, [x20]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d76140: ldp     x20, x19, [sp, #0x10]                      
02d76144: ldp     x30, x21, [sp], #0x20                      
02d76148: b       #0x31cf7fc                                 
## Update() -> void
---- Character.RandomAnimationState::Update 0x2d7614c
02d7614c: ret                                                
## Exit() -> void
---- Character.RandomAnimationState::Exit 0x2d76150
02d76150: ldr     x0, [x0, #0x18]                            
02d76154: cbz     x0, #0x2d76160                             
02d76158: mov     x1, xzr                                    
02d7615c: b       #0x2cb3c24                                 SpineAnimationHandler::PauseAnimation
02d76160: str     x30, [sp, #-0x10]!                         
02d76164: bl      #0x2b7105c                                 fn_2b7105c
## Enter(bool isLoop, System.Action OnStart, System.Action OnEnd) -> void
---- Character.RandomAnimationState::Enter 0x2d76168
02d76168: str     x30, [sp, #-0x40]!                         
02d7616c: stp     x24, x23, [sp, #0x10]                      
02d76170: stp     x22, x21, [sp, #0x20]                      
02d76174: stp     x20, x19, [sp, #0x30]                      
02d76178: adrp    x22, #0x6630000                            
02d7617c: adrp    x24, #0x626c000                            
02d76180: mov     x19, x3                                    
02d76184: ldrb    w8, [x22, #0x3d6]                          
02d76188: ldr     x24, [x24, #0x7f0]                         MS:FrameWorkUtility::PickRandom
02d7618c: mov     x20, x2                                    
02d76190: mov     w21, w1                                    
02d76194: mov     x23, x0                                    
02d76198: tbnz    w8, #0, #0x2d761b0                         
02d7619c: adrp    x0, #0x626c000                             
02d761a0: ldr     x0, [x0, #0x7f0]                           MS:FrameWorkUtility::PickRandom
02d761a4: bl      #0x2b70db0                                 fn_2b70db0
02d761a8: mov     w8, #1                                     
02d761ac: strb    w8, [x22, #0x3d6]                          
02d761b0: ldr     x0, [x23, #0x28]                           
02d761b4: ldr     x1, [x24]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d761b8: ldr     x22, [x23, #0x18]                          
02d761bc: bl      #0x31cf7fc                                 fn_31cf7fc
02d761c0: cbz     x22, #0x2d761f0                            
02d761c4: mov     w1, w0                                     
02d761c8: and     w2, w21, #1                                
02d761cc: mov     x0, x22                                    
02d761d0: mov     x3, x20                                    
02d761d4: mov     x4, x19                                    
02d761d8: mov     x5, xzr                                    
02d761dc: ldp     x20, x19, [sp, #0x30]                      
02d761e0: ldp     x22, x21, [sp, #0x20]                      
02d761e4: ldp     x24, x23, [sp, #0x10]                      
02d761e8: ldr     x30, [sp], #0x40                           
02d761ec: b       #0x2cb3fec                                 SpineAnimationHandler::PlayAnimation
02d761f0: bl      #0x2b7105c                                 fn_2b7105c
## .ctor() -> void
---- Character.RandomAnimationState::.ctor 0x2d75c14
02d75c14: mov     x1, xzr                                    
02d75c18: b       #0x4e53e9c                                 System.Object::.ctor
