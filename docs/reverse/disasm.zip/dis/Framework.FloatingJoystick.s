#### CLASS Framework.FloatingJoystick parent= Framework.Joystick
## Start() -> void
---- Framework.FloatingJoystick::Start 0x2cc3a04
02cc3a04: stp     x30, x19, [sp, #-0x10]!                    
02cc3a08: mov     x19, x0                                    
02cc3a0c: bl      #0x2cc3a38                                 Framework.Joystick::Start
02cc3a10: ldr     x0, [x19, #0x20]                           
02cc3a14: cbz     x0, #0x2cc3a34                             
02cc3a18: mov     x1, xzr                                    
02cc3a1c: bl      #0x5b339ec                                 UnityEngine.Component::get_gameObject
02cc3a20: cbz     x0, #0x2cc3a34                             
02cc3a24: mov     w1, wzr                                    
02cc3a28: mov     x2, xzr                                    
02cc3a2c: ldp     x30, x19, [sp], #0x10                      
02cc3a30: b       #0x5b36b38                                 UnityEngine.GameObject::SetActive
02cc3a34: bl      #0x2b7105c                                 fn_2b7105c
## OnPointerDown(UnityEngine.EventSystems.PointerEventData eventData) -> void
---- Framework.FloatingJoystick::OnPointerDown 0x2cc3cac
02cc3cac: stp     x30, x21, [sp, #-0x20]!                    
02cc3cb0: stp     x20, x19, [sp, #0x10]                      
02cc3cb4: cbz     x1, #0x2cc3d14                             
02cc3cb8: ldr     s0, [x1, #0x144]                           
02cc3cbc: ldr     s1, [x1, #0x148]                           
02cc3cc0: mov     x19, x1                                    
02cc3cc4: ldr     x21, [x0, #0x20]                           
02cc3cc8: mov     x20, x0                                    
02cc3ccc: bl      #0x2cc3d18                                 Framework.Joystick::ScreenPointToAnchoredPosition
02cc3cd0: cbz     x21, #0x2cc3d14                            
02cc3cd4: mov     x0, x21                                    
02cc3cd8: mov     x1, xzr                                    
02cc3cdc: bl      #0x5b45800                                 UnityEngine.RectTransform::set_anchoredPosition
02cc3ce0: ldr     x0, [x20, #0x20]                           
02cc3ce4: cbz     x0, #0x2cc3d14                             
02cc3ce8: mov     x1, xzr                                    
02cc3cec: bl      #0x5b339ec                                 UnityEngine.Component::get_gameObject
02cc3cf0: cbz     x0, #0x2cc3d14                             
02cc3cf4: mov     w1, #1                                     
02cc3cf8: mov     x2, xzr                                    
02cc3cfc: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02cc3d00: mov     x0, x20                                    
02cc3d04: mov     x1, x19                                    
02cc3d08: ldp     x20, x19, [sp, #0x10]                      
02cc3d0c: ldp     x30, x21, [sp], #0x20                      
02cc3d10: b       #0x2cc4908                                 Framework.Joystick::OnDrag
02cc3d14: bl      #0x2b7105c                                 fn_2b7105c
## OnPointerUp(UnityEngine.EventSystems.PointerEventData eventData) -> void
---- Framework.FloatingJoystick::OnPointerUp 0x2cc3eb4
02cc3eb4: stp     x30, x19, [sp, #-0x10]!                    
02cc3eb8: mov     x19, x0                                    
02cc3ebc: ldr     x0, [x0, #0x20]                            
02cc3ec0: cbz     x0, #0x2cc3ee8                             
02cc3ec4: mov     x1, xzr                                    
02cc3ec8: bl      #0x5b339ec                                 UnityEngine.Component::get_gameObject
02cc3ecc: cbz     x0, #0x2cc3ee8                             
02cc3ed0: mov     w1, wzr                                    
02cc3ed4: mov     x2, xzr                                    
02cc3ed8: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02cc3edc: mov     x0, x19                                    
02cc3ee0: ldp     x30, x19, [sp], #0x10                      
02cc3ee4: b       #0x2cc3eec                                 Framework.Joystick::OnPointerUp
02cc3ee8: bl      #0x2b7105c                                 fn_2b7105c
## .ctor() -> void
---- Framework.FloatingJoystick::.ctor 0x2cc3f54
02cc3f54: b       #0x2cc3f58                                 Framework.Joystick::.ctor
