#### CLASS Clicker.KeychainUIItem parent= Clicker.ClickerUIItem
## OnSelected(bool isSelected) -> void
---- Clicker.KeychainUIItem::OnSelected 0x2d6e6e8
02d6e6e8: mov     x2, xzr                                    
02d6e6ec: b       #0x2d664a8                                 Clicker.ClickerUIItem::OnSelected
## .ctor() -> void
---- Clicker.KeychainUIItem::.ctor 0x2d6e6f0
02d6e6f0: mov     x1, xzr                                    
02d6e6f4: b       #0x2d664b4                                 Clicker.ClickerUIItem::.ctor
