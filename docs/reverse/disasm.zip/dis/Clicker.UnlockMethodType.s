#### CLASS Clicker.UnlockMethodType parent= int
#   field value__                        int                                                off=0x10 attr=606 
#   field Unlocked                       Clicker.UnlockMethodType                           off=0x0 attr=8056 
#   field Ads                            Clicker.UnlockMethodType                           off=0x0 attr=8056 
#   field Coin                           Clicker.UnlockMethodType                           off=0x0 attr=8056 
#   field BlindBag                       Clicker.UnlockMethodType                           off=0x0 attr=8056 
