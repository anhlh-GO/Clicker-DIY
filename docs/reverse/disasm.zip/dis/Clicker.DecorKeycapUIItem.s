#### CLASS Clicker.DecorKeycapUIItem parent= Clicker.ClickerUIItem
#   field _type                          Clicker.DecorKeycapType                            off=0x78 attr=1 SerializeField
## get_Type() -> Clicker.DecorKeycapType
---- Clicker.DecorKeycapUIItem::get_Type 0x2d6aa38
02d6aa38: ldr     w0, [x0, #0x78]                            ._type
02d6aa3c: ret                                                
## SetType(Clicker.DecorKeycapType type) -> void
---- Clicker.DecorKeycapUIItem::SetType 0x2d6aa40
02d6aa40: str     w1, [x0, #0x78]                            ._type
02d6aa44: ret                                                
## OnSelected(bool isSelected) -> void
---- Clicker.DecorKeycapUIItem::OnSelected 0x2d6aa48
02d6aa48: ret                                                
## .ctor() -> void
---- Clicker.DecorKeycapUIItem::.ctor 0x2d6aa4c
02d6aa4c: mov     x1, xzr                                    
02d6aa50: b       #0x5b397b0                                 UnityEngine.MonoBehaviour::.ctor
