#### CLASS Framework.ButtonMethodAttribute/EDrawOrder parent= int
#   field value__                        int                                                off=0x10 attr=606 
#   field BeforeInspector                Framework.ButtonMethodAttribute/EDrawOrder         off=0x0 attr=8056 
#   field AfterInspector                 Framework.ButtonMethodAttribute/EDrawOrder         off=0x0 attr=8056 
#### CLASS Framework.ButtonMethodAttribute parent= UnityEngine.PropertyAttribute
#   field drawOrder                      Framework.ButtonMethodAttribute/EDrawOrder         off=0x14 attr=26 
## .ctor(Framework.ButtonMethodAttribute/EDrawOrder drawOrder) -> void
---- Framework.ButtonMethodAttribute::.ctor 0x2cb814c
02cb814c: str     x30, [sp, #-0x20]!                         
02cb8150: stp     x20, x19, [sp, #0x10]                      
02cb8154: mov     w19, w1                                    
02cb8158: mov     x1, xzr                                    
02cb815c: mov     x20, x0                                    
02cb8160: bl      #0x5b2d93c                                 UnityEngine.PropertyAttribute::.ctor
02cb8164: str     w19, [x20, #0x14]                          .drawOrder
02cb8168: ldp     x20, x19, [sp, #0x10]                      
02cb816c: ldr     x30, [sp], #0x20                           
02cb8170: ret                                                
