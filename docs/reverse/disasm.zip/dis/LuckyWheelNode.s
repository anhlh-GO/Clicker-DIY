#### CLASS LuckyWheelNode/<>c__DisplayClass10_0 parent= object
#   field onCompleted                    System.Action                                      off=0x10 attr=6 
## .ctor() -> void
---- LuckyWheelNode/<>c__DisplayClass10_0::.ctor 0x2ce1728
02ce1728: mov     x1, xzr                                    
02ce172c: b       #0x4e53e9c                                 System.Object::.ctor
## <PlayAnimationReward>b__0() -> void
---- LuckyWheelNode/<>c__DisplayClass10_0::<PlayAnimationReward>b__0 0x2ce1738
02ce1738: ldr     x8, [x0, #0x10]                            .onCompleted
02ce173c: cbz     x8, #0x2ce1750                             
02ce1740: ldr     x0, [x8, #0x40]                            
02ce1744: ldr     x1, [x8, #0x28]                            
02ce1748: ldr     x2, [x8, #0x18]                            
02ce174c: br      x2                                         
02ce1750: ret                                                
#### CLASS LuckyWheelNode parent= UnityEngine.MonoBehaviour
#   field _id                            string                                             off=0x20 attr=1 SerializeField
#   field _rotationValue                 float                                              off=0x28 attr=1 SerializeField
#   field _rectTransform                 UnityEngine.RectTransform                          off=0x30 attr=1 SerializeField
## get_Id() -> string
---- LuckyWheelNode::get_Id 0x2ce1624
02ce1624: ldr     x0, [x0, #0x20]                            ._id
02ce1628: ret                                                
## get_RectTransform() -> UnityEngine.RectTransform
---- LuckyWheelNode::get_RectTransform 0x2ce162c
02ce162c: ldr     x0, [x0, #0x30]                            ._rectTransform
02ce1630: ret                                                
## get_RotationValue() -> float
---- LuckyWheelNode::get_RotationValue 0x2ce1634
02ce1634: ldr     s0, [x0, #0x28]                            ._rotationValue
02ce1638: ret                                                
## LoadConfig(LuckyWheelRewardConfig config) -> void
---- LuckyWheelNode::LoadConfig 0x2ce163c
02ce163c: cbz     x1, #0x2ce164c                             
02ce1640: ldr     x1, [x1, #0x10]                            
02ce1644: str     x1, [x0, #0x20]!                           ._id
02ce1648: b       #0x2b70d54                                 
02ce164c: str     x30, [sp, #-0x10]!                         
02ce1650: bl      #0x2b7105c                                 fn_2b7105c
## PlayAnimationReward(float duration, System.Action onCompleted) -> void
---- LuckyWheelNode::PlayAnimationReward 0x2ce1654
02ce1654: str     d8, [sp, #-0x30]!                          
02ce1658: str     x30, [sp, #8]                              
02ce165c: stp     x22, x21, [sp, #0x10]                      
02ce1660: stp     x20, x19, [sp, #0x20]                      
02ce1664: fmov    s8, s0                                     
02ce1668: adrp    x20, #0x662f000                            
02ce166c: adrp    x21, #0x6267000                            
02ce1670: ldrb    w8, [x20, #0xdb2]                          
02ce1674: ldr     x21, [x21, #0xf88]                         T:LuckyWheelNode/<>c__DisplayClass10_0
02ce1678: mov     x19, x1                                    
02ce167c: tbnz    w8, #0, #0x2ce16ac                         
02ce1680: adrp    x0, #0x6264000                             
02ce1684: ldr     x0, [x0, #0xe8]                            T:DG.Tweening.TweenCallback
02ce1688: bl      #0x2b70db0                                 fn_2b70db0
02ce168c: adrp    x0, #0x6267000                             
02ce1690: ldr     x0, [x0, #0xf90]                           M:LuckyWheelNode/<>c__DisplayClass10_0::<PlayAnimationReward>b__0
02ce1694: bl      #0x2b70db0                                 fn_2b70db0
02ce1698: adrp    x0, #0x6267000                             
02ce169c: ldr     x0, [x0, #0xf88]                           T:LuckyWheelNode/<>c__DisplayClass10_0
02ce16a0: bl      #0x2b70db0                                 fn_2b70db0
02ce16a4: mov     w8, #1                                     
02ce16a8: strb    w8, [x20, #0xdb2]                          
02ce16ac: ldr     x0, [x21]                                  S:'didu'
02ce16b0: bl      #0x2b7104c                                 fn_2b7104c
02ce16b4: mov     x1, xzr                                    
02ce16b8: mov     x20, x0                                    
02ce16bc: bl      #0x4e53e9c                                 System.Object::.ctor
02ce16c0: cbz     x20, #0x2ce1724                            
02ce16c4: adrp    x21, #0x6264000                            
02ce16c8: adrp    x22, #0x6267000                            
02ce16cc: mov     x0, x20                                    
02ce16d0: ldr     x21, [x21, #0xe8]                          T:DG.Tweening.TweenCallback
02ce16d4: ldr     x22, [x22, #0xf90]                         M:LuckyWheelNode/<>c__DisplayClass10_0::<PlayAnimationReward>b__0
02ce16d8: mov     x1, x19                                    
02ce16dc: str     x19, [x0, #0x10]!                          
02ce16e0: bl      #0x2b70d54                                 fn_2b70d54
02ce16e4: ldr     x0, [x21]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02ce16e8: bl      #0x2b7104c                                 fn_2b7104c
02ce16ec: ldr     x2, [x22]                                  S:'didu'
02ce16f0: mov     x1, x20                                    
02ce16f4: mov     x3, xzr                                    
02ce16f8: mov     x19, x0                                    
02ce16fc: bl      #0x2d89dc4                                 DG.Tweening.TweenCallback::.ctor
02ce1700: mov     x0, x19                                    
02ce1704: ldp     x20, x19, [sp, #0x20]                      
02ce1708: ldp     x22, x21, [sp, #0x10]                      
02ce170c: fmov    s0, s8                                     
02ce1710: ldr     x30, [sp, #8]                              
02ce1714: mov     w1, #1                                     
02ce1718: mov     x2, xzr                                    
02ce171c: ldr     d8, [sp], #0x30                            
02ce1720: b       #0x2d8f37c                                 DG.Tweening.DOVirtual::DelayedCall
02ce1724: bl      #0x2b7105c                                 fn_2b7105c
## .ctor() -> void
---- LuckyWheelNode::.ctor 0x2ce1730
02ce1730: mov     x1, xzr                                    
02ce1734: b       #0x5b397b0                                 UnityEngine.MonoBehaviour::.ctor
