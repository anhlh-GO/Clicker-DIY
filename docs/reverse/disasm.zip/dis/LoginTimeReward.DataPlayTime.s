#### CLASS LoginTimeReward.DataPlayTime/DataSaveLoginTime parent= object
#   field LastLoginDateString            string                                             off=0x10 attr=6 
#   field AccumulatedSeconds             float                                              off=0x18 attr=6 
#   field RewardClaimed                  System.Collections.Generic.List`1<bool>            off=0x20 attr=6 
## .ctor() -> void
---- LoginTimeReward.DataPlayTime/DataSaveLoginTime::.ctor 0x2d58c64
02d58c64: str     x30, [sp, #-0x30]!                         
02d58c68: stp     x22, x21, [sp, #0x10]                      
02d58c6c: stp     x20, x19, [sp, #0x20]                      
02d58c70: adrp    x21, #0x6630000                            
02d58c74: adrp    x22, #0x626b000                            
02d58c78: adrp    x20, #0x626b000                            
02d58c7c: ldrb    w8, [x21, #0x2a8]                          
02d58c80: ldr     x22, [x22, #0xad0]                         T:type14819(k15)
02d58c84: ldr     x20, [x20, #0xac8]                         MS:System.Collections.Generic.List`1::.ctor
02d58c88: mov     x19, x0                                    
02d58c8c: tbnz    w8, #0, #0x2d58cb0                         
02d58c90: adrp    x0, #0x626b000                             
02d58c94: ldr     x0, [x0, #0xac8]                           MS:System.Collections.Generic.List`1::.ctor
02d58c98: bl      #0x2b70db0                                 fn_2b70db0
02d58c9c: adrp    x0, #0x626b000                             
02d58ca0: ldr     x0, [x0, #0xad0]                           T:type14819(k15)
02d58ca4: bl      #0x2b70db0                                 fn_2b70db0
02d58ca8: mov     w8, #1                                     
02d58cac: strb    w8, [x21, #0x2a8]                          
02d58cb0: ldr     x0, [x22]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d58cb4: bl      #0x2b7104c                                 fn_2b7104c
02d58cb8: ldr     x1, [x20]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d58cbc: mov     x20, x0                                    
02d58cc0: bl      #0x4baeea0                                 fn_4baeea0
02d58cc4: mov     x0, x19                                    
02d58cc8: mov     x1, x20                                    
02d58ccc: str     x20, [x0, #0x20]!                          .RewardClaimed
02d58cd0: bl      #0x2b70d54                                 fn_2b70d54
02d58cd4: mov     x0, x19                                    
02d58cd8: ldp     x20, x19, [sp, #0x20]                      
02d58cdc: ldp     x22, x21, [sp, #0x10]                      
02d58ce0: mov     x1, xzr                                    
02d58ce4: ldr     x30, [sp], #0x30                           
02d58ce8: b       #0x4e53e9c                                 System.Object::.ctor
#### CLASS LoginTimeReward.DataPlayTime parent= GameData
#   field _dataSave                      LoginTimeReward.DataPlayTime/DataSaveLoginTime     off=0x20 attr=1 SerializeField
## get_DataSave() -> LoginTimeReward.DataPlayTime/DataSaveLoginTime
---- LoginTimeReward.DataPlayTime::get_DataSave 0x2d58a48
02d58a48: ldr     x0, [x0, #0x20]                            ._dataSave
02d58a4c: ret                                                
## set_DataSave(LoginTimeReward.DataPlayTime/DataSaveLoginTime value) -> void
---- LoginTimeReward.DataPlayTime::set_DataSave 0x2d58a50
02d58a50: str     x1, [x0, #0x20]!                           ._dataSave
02d58a54: b       #0x2b70d54                                 
## SaveData() -> void
---- LoginTimeReward.DataPlayTime::SaveData 0x2d58a58
02d58a58: stp     x30, x21, [sp, #-0x20]!                    
02d58a5c: stp     x20, x19, [sp, #0x10]                      
02d58a60: adrp    x20, #0x6630000                            
02d58a64: adrp    x21, #0x6266000                            
02d58a68: mov     x19, x0                                    
02d58a6c: ldrb    w8, [x20, #0x2a3]                          
02d58a70: ldr     x21, [x21, #0x658]                         MS:MonoSingleton`1::get_Instance
02d58a74: tbnz    w8, #0, #0x2d58a98                         
02d58a78: adrp    x0, #0x626b000                             
02d58a7c: ldr     x0, [x0, #0xab0]                           MS:DataManager::SaveData
02d58a80: bl      #0x2b70db0                                 fn_2b70db0
02d58a84: adrp    x0, #0x6266000                             
02d58a88: ldr     x0, [x0, #0x658]                           MS:MonoSingleton`1::get_Instance
02d58a8c: bl      #0x2b70db0                                 fn_2b70db0
02d58a90: mov     w8, #1                                     
02d58a94: strb    w8, [x20, #0x2a3]                          
02d58a98: ldr     x0, [x21]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d58a9c: bl      #0x3769600                                 fn_3769600
02d58aa0: ldr     x8, [x19]                                  
02d58aa4: mov     x20, x0                                    
02d58aa8: mov     x0, x19                                    
02d58aac: ldr     x9, [x8, #0x2a8]                           
02d58ab0: ldr     x1, [x8, #0x2b0]                           
02d58ab4: blr     x9                                         
02d58ab8: cbz     x20, #0x2d58ae0                            
02d58abc: adrp    x8, #0x626b000                             
02d58ac0: mov     x1, x0                                     
02d58ac4: mov     x0, x20                                    
02d58ac8: ldr     x8, [x8, #0xab0]                           MS:DataManager::SaveData
02d58acc: ldr     x2, [x19, #0x20]                           ._dataSave
02d58ad0: ldp     x20, x19, [sp, #0x10]                      
02d58ad4: ldr     x3, [x8]                                   T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d58ad8: ldp     x30, x21, [sp], #0x20                      
02d58adc: b       #0x3169790                                 
02d58ae0: bl      #0x2b7105c                                 fn_2b7105c
## LoadData() -> void
---- LoginTimeReward.DataPlayTime::LoadData 0x2d58ae4
02d58ae4: stp     x30, x21, [sp, #-0x20]!                    
02d58ae8: stp     x20, x19, [sp, #0x10]                      
02d58aec: adrp    x20, #0x6630000                            
02d58af0: adrp    x21, #0x6266000                            
02d58af4: mov     x19, x0                                    
02d58af8: ldrb    w8, [x20, #0x2a4]                          
02d58afc: ldr     x21, [x21, #0x658]                         MS:MonoSingleton`1::get_Instance
02d58b00: tbnz    w8, #0, #0x2d58b24                         
02d58b04: adrp    x0, #0x626b000                             
02d58b08: ldr     x0, [x0, #0xab8]                           MS:DataManager::LoadData
02d58b0c: bl      #0x2b70db0                                 fn_2b70db0
02d58b10: adrp    x0, #0x6266000                             
02d58b14: ldr     x0, [x0, #0x658]                           MS:MonoSingleton`1::get_Instance
02d58b18: bl      #0x2b70db0                                 fn_2b70db0
02d58b1c: mov     w8, #1                                     
02d58b20: strb    w8, [x20, #0x2a4]                          
02d58b24: ldr     x0, [x21]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d58b28: bl      #0x3769600                                 fn_3769600
02d58b2c: ldr     x8, [x19]                                  
02d58b30: mov     x20, x0                                    
02d58b34: mov     x0, x19                                    
02d58b38: ldr     x9, [x8, #0x2a8]                           
02d58b3c: ldr     x1, [x8, #0x2b0]                           
02d58b40: blr     x9                                         
02d58b44: cbz     x20, #0x2d58b78                            
02d58b48: adrp    x8, #0x626b000                             
02d58b4c: mov     x1, x0                                     
02d58b50: mov     x0, x20                                    
02d58b54: ldr     x8, [x8, #0xab8]                           MS:DataManager::LoadData
02d58b58: ldr     x2, [x8]                                   T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d58b5c: bl      #0x31690b0                                 fn_31690b0
02d58b60: str     x0, [x19, #0x20]!                          ._dataSave
02d58b64: mov     x1, x0                                     
02d58b68: mov     x0, x19                                    
02d58b6c: ldp     x20, x19, [sp, #0x10]                      
02d58b70: ldp     x30, x21, [sp], #0x20                      
02d58b74: b       #0x2b70d54                                 
02d58b78: bl      #0x2b7105c                                 fn_2b7105c
## NewData() -> void
---- LoginTimeReward.DataPlayTime::NewData 0x2d58b7c
02d58b7c: str     x30, [sp, #-0x30]!                         
02d58b80: stp     x22, x21, [sp, #0x10]                      
02d58b84: stp     x20, x19, [sp, #0x20]                      
02d58b88: adrp    x21, #0x6630000                            
02d58b8c: adrp    x20, #0x626b000                            
02d58b90: mov     x19, x0                                    
02d58b94: ldrb    w8, [x21, #0x2a5]                          
02d58b98: ldr     x20, [x20, #0xac0]                         T:LoginTimeReward.DataPlayTime/DataSaveLoginTime
02d58b9c: tbnz    w8, #0, #0x2d58bcc                         
02d58ba0: adrp    x0, #0x626b000                             
02d58ba4: ldr     x0, [x0, #0xac0]                           T:LoginTimeReward.DataPlayTime/DataSaveLoginTime
02d58ba8: bl      #0x2b70db0                                 fn_2b70db0
02d58bac: adrp    x0, #0x626b000                             
02d58bb0: ldr     x0, [x0, #0xac8]                           MS:System.Collections.Generic.List`1::.ctor
02d58bb4: bl      #0x2b70db0                                 fn_2b70db0
02d58bb8: adrp    x0, #0x626b000                             
02d58bbc: ldr     x0, [x0, #0xad0]                           T:type14819(k15)
02d58bc0: bl      #0x2b70db0                                 fn_2b70db0
02d58bc4: mov     w8, #1                                     
02d58bc8: strb    w8, [x21, #0x2a5]                          
02d58bcc: mov     x0, x19                                    
02d58bd0: mov     x1, xzr                                    
02d58bd4: bl      #0x2cac6e0                                 GameData::NewData
02d58bd8: ldr     x0, [x20]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d58bdc: bl      #0x2b7104c                                 fn_2b7104c
02d58be0: mov     x20, x0                                    
02d58be4: bl      #0x2d58c64                                 LoginTimeReward.DataPlayTime/DataSaveLoginTime::.ctor
02d58be8: cbz     x20, #0x2d58c60                            
02d58bec: adrp    x8, #0x6263000                             
02d58bf0: adrp    x21, #0x626b000                            
02d58bf4: adrp    x22, #0x626b000                            
02d58bf8: ldr     x8, [x8, #0x970]                           &6645c70(=0)
02d58bfc: mov     x0, x20                                    
02d58c00: ldr     x8, [x8, #0x90]                            &2c5beb4(=14c8d222d503245f)
02d58c04: ldr     x8, [x8, #0xb8]                            &6263108(=0)
02d58c08: ldr     x21, [x21, #0xad0]                         T:type14819(k15)
02d58c0c: ldr     x1, [x8]                                   &2c5bbd4(=a9bd7bfdd503233f)
02d58c10: ldr     x22, [x22, #0xac8]                         MS:System.Collections.Generic.List`1::.ctor
02d58c14: str     x1, [x0, #0x10]!                           
02d58c18: bl      #0x2b70d54                                 fn_2b70d54
02d58c1c: ldr     x0, [x21]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d58c20: str     wzr, [x20, #0x18]                          
02d58c24: bl      #0x2b7104c                                 fn_2b7104c
02d58c28: ldr     x1, [x22]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d58c2c: mov     x21, x0                                    
02d58c30: bl      #0x4baeea0                                 fn_4baeea0
02d58c34: mov     x0, x20                                    
02d58c38: mov     x1, x21                                    
02d58c3c: str     x21, [x0, #0x20]!                          ._dataSave
02d58c40: bl      #0x2b70d54                                 fn_2b70d54
02d58c44: str     x20, [x19, #0x20]!                         ._dataSave
02d58c48: mov     x0, x19                                    
02d58c4c: mov     x1, x20                                    
02d58c50: ldp     x20, x19, [sp, #0x20]                      
02d58c54: ldp     x22, x21, [sp, #0x10]                      
02d58c58: ldr     x30, [sp], #0x30                           
02d58c5c: b       #0x2b70d54                                 
02d58c60: bl      #0x2b7105c                                 fn_2b7105c
## ResetForNewDay() -> void
---- LoginTimeReward.DataPlayTime::ResetForNewDay 0x2d58cec
02d58cec: str     x30, [sp, #-0x30]!                         
02d58cf0: stp     x22, x21, [sp, #0x10]                      
02d58cf4: stp     x20, x19, [sp, #0x20]                      
02d58cf8: adrp    x20, #0x6630000                            
02d58cfc: adrp    x21, #0x626b000                            
02d58d00: mov     x19, x0                                    
02d58d04: ldrb    w8, [x20, #0x2a6]                          
02d58d08: ldr     x21, [x21, #0xac0]                         T:LoginTimeReward.DataPlayTime/DataSaveLoginTime
02d58d0c: tbnz    w8, #0, #0x2d58d3c                         
02d58d10: adrp    x0, #0x626b000                             
02d58d14: ldr     x0, [x0, #0xac0]                           T:LoginTimeReward.DataPlayTime/DataSaveLoginTime
02d58d18: bl      #0x2b70db0                                 fn_2b70db0
02d58d1c: adrp    x0, #0x626b000                             
02d58d20: ldr     x0, [x0, #0xac8]                           MS:System.Collections.Generic.List`1::.ctor
02d58d24: bl      #0x2b70db0                                 fn_2b70db0
02d58d28: adrp    x0, #0x626b000                             
02d58d2c: ldr     x0, [x0, #0xad0]                           T:type14819(k15)
02d58d30: bl      #0x2b70db0                                 fn_2b70db0
02d58d34: mov     w8, #1                                     
02d58d38: strb    w8, [x20, #0x2a6]                          
02d58d3c: ldr     x0, [x21]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d58d40: bl      #0x2b7104c                                 fn_2b7104c
02d58d44: mov     x20, x0                                    
02d58d48: bl      #0x2d58c64                                 LoginTimeReward.DataPlayTime/DataSaveLoginTime::.ctor
02d58d4c: cbz     x20, #0x2d58dc4                            
02d58d50: adrp    x8, #0x6263000                             
02d58d54: adrp    x21, #0x626b000                            
02d58d58: adrp    x22, #0x626b000                            
02d58d5c: ldr     x8, [x8, #0x970]                           &6645c70(=0)
02d58d60: mov     x0, x20                                    
02d58d64: ldr     x8, [x8, #0x90]                            &2c5beb4(=14c8d222d503245f)
02d58d68: ldr     x8, [x8, #0xb8]                            &6263108(=0)
02d58d6c: ldr     x21, [x21, #0xad0]                         T:type14819(k15)
02d58d70: ldr     x1, [x8]                                   &2c5bbd4(=a9bd7bfdd503233f)
02d58d74: ldr     x22, [x22, #0xac8]                         MS:System.Collections.Generic.List`1::.ctor
02d58d78: str     x1, [x0, #0x10]!                           
02d58d7c: bl      #0x2b70d54                                 fn_2b70d54
02d58d80: ldr     x0, [x21]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d58d84: str     wzr, [x20, #0x18]                          
02d58d88: bl      #0x2b7104c                                 fn_2b7104c
02d58d8c: ldr     x1, [x22]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d58d90: mov     x21, x0                                    
02d58d94: bl      #0x4baeea0                                 fn_4baeea0
02d58d98: mov     x0, x20                                    
02d58d9c: mov     x1, x21                                    
02d58da0: str     x21, [x0, #0x20]!                          ._dataSave
02d58da4: bl      #0x2b70d54                                 fn_2b70d54
02d58da8: str     x20, [x19, #0x20]!                         ._dataSave
02d58dac: mov     x0, x19                                    
02d58db0: mov     x1, x20                                    
02d58db4: ldp     x20, x19, [sp, #0x20]                      
02d58db8: ldp     x22, x21, [sp, #0x10]                      
02d58dbc: ldr     x30, [sp], #0x30                           
02d58dc0: b       #0x2b70d54                                 
02d58dc4: bl      #0x2b7105c                                 fn_2b7105c
## UpdateLoginData(int id, bool claimed) -> void
---- LoginTimeReward.DataPlayTime::UpdateLoginData 0x2d58dc8
02d58dc8: str     x30, [sp, #-0x30]!                         
02d58dcc: stp     x22, x21, [sp, #0x10]                      
02d58dd0: stp     x20, x19, [sp, #0x20]                      
02d58dd4: adrp    x22, #0x6630000                            
02d58dd8: mov     w20, w2                                    
02d58ddc: mov     w19, w1                                    
02d58de0: ldrb    w8, [x22, #0x2a7]                          
02d58de4: mov     x21, x0                                    
02d58de8: tbnz    w8, #0, #0x2d58e18                         
02d58dec: adrp    x0, #0x626b000                             
02d58df0: ldr     x0, [x0, #0xad8]                           MS:System.Collections.Generic.List`1::Add
02d58df4: bl      #0x2b70db0                                 fn_2b70db0
02d58df8: adrp    x0, #0x626b000                             
02d58dfc: ldr     x0, [x0, #0xae0]                           MS:System.Collections.Generic.List`1::get_Count
02d58e00: bl      #0x2b70db0                                 fn_2b70db0
02d58e04: adrp    x0, #0x626b000                             
02d58e08: ldr     x0, [x0, #0xae8]                           MS:System.Collections.Generic.List`1::set_Item
02d58e0c: bl      #0x2b70db0                                 fn_2b70db0
02d58e10: mov     w8, #1                                     
02d58e14: strb    w8, [x22, #0x2a7]                          
02d58e18: ldr     x8, [x21, #0x20]                           ._dataSave
02d58e1c: cbz     x8, #0x2d58eac                             
02d58e20: ldr     x9, [x8, #0x20]                            
02d58e24: cbz     x9, #0x2d58eac                             
02d58e28: ldr     w9, [x9, #0x18]                            
02d58e2c: add     w10, w19, #1                               
02d58e30: cmp     w9, w10                                    
02d58e34: b.ge    #0x2d58eb0                                 
02d58e38: adrp    x22, #0x626b000                            
02d58e3c: ldr     x22, [x22, #0xad8]                         MS:System.Collections.Generic.List`1::Add
02d58e40: ldr     x0, [x8, #0x20]                            
02d58e44: cbz     x0, #0x2d58eac                             
02d58e48: ldrsw   x9, [x0, #0x18]                            
02d58e4c: cmp     w9, w19                                    
02d58e50: b.gt    #0x2d58ec0                                 
02d58e54: ldr     w12, [x0, #0x1c]                           [626b01c]=0 f=0,0
02d58e58: ldr     x10, [x0, #0x10]                           MS:System.Collections.Generic.List`1::Find
02d58e5c: ldr     x11, [x22]                                 T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d58e60: add     w12, w12, #1                               
02d58e64: str     w12, [x0, #0x1c]                           
02d58e68: cbz     x10, #0x2d58eac                            
02d58e6c: ldr     w12, [x10, #0x18]                          
02d58e70: cmp     w9, w12                                    
02d58e74: b.hs    #0x2d58e90                                 
02d58e78: add     w11, w9, #1                                
02d58e7c: add     x9, x10, x9                                
02d58e80: str     w11, [x0, #0x18]                           
02d58e84: strb    wzr, [x9, #0x20]                           
02d58e88: cbnz    x8, #0x2d58e40                             
02d58e8c: b       #0x2d58eac                                 
02d58e90: ldr     x8, [x11, #0x20]                           
02d58e94: mov     w1, wzr                                    
02d58e98: ldr     x8, [x8, #0xc0]                            
02d58e9c: ldr     x2, [x8, #0x70]                            
02d58ea0: bl      #0x4baf73c                                 fn_4baf73c
02d58ea4: ldr     x8, [x21, #0x20]                           ._dataSave
02d58ea8: cbnz    x8, #0x2d58e40                             
02d58eac: bl      #0x2b7105c                                 fn_2b7105c
02d58eb0: ldp     x20, x19, [sp, #0x20]                      
02d58eb4: ldp     x22, x21, [sp, #0x10]                      
02d58eb8: ldr     x30, [sp], #0x30                           
02d58ebc: ret                                                
02d58ec0: adrp    x8, #0x626b000                             
02d58ec4: and     w2, w20, #1                                
02d58ec8: mov     w1, w19                                    
02d58ecc: ldr     x8, [x8, #0xae8]                           MS:System.Collections.Generic.List`1::set_Item
02d58ed0: ldp     x20, x19, [sp, #0x20]                      
02d58ed4: ldp     x22, x21, [sp, #0x10]                      
02d58ed8: ldr     x3, [x8]                                   T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d58edc: ldr     x30, [sp], #0x30                           
02d58ee0: b       #0x4baf48c                                 
## .ctor() -> void
---- LoginTimeReward.DataPlayTime::.ctor 0x2d58ee4
02d58ee4: mov     x1, xzr                                    
02d58ee8: b       #0x2ca9988                                 GameData::.ctor
