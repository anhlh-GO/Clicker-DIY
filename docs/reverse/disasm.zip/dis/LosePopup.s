#### CLASS LosePopup parent= PopupBase
## .ctor() -> void
---- LosePopup::.ctor 0x2ce0390
02ce0390: mov     x1, xzr                                    
02ce0394: b       #0x5b397b0                                 UnityEngine.MonoBehaviour::.ctor
