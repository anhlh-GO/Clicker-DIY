#### CLASS NativeInterTimeCount/<ICountDownTMP>d__11 parent= object
#   field <>1__state                     int                                                off=0x10 attr=1 
#   field <>2__current                   object                                             off=0x18 attr=1 
#   field time                           int                                                off=0x20 attr=6 
#   field <>4__this                      NativeInterTimeCount                               off=0x28 attr=6 
#   field duration                       int                                                off=0x30 attr=6 
#   field actionComplete                 System.Action                                      off=0x38 attr=6 
#   field <count>5__2                    int                                                off=0x40 attr=1 
## .ctor(int <>1__state) -> void
---- NativeInterTimeCount/<ICountDownTMP>d__11::.ctor 0x2c9b930
02c9b930: str     x30, [sp, #-0x20]!                         
02c9b934: stp     x20, x19, [sp, #0x10]                      
02c9b938: mov     w19, w1                                    
02c9b93c: mov     x1, xzr                                    
02c9b940: mov     x20, x0                                    
02c9b944: bl      #0x4e53e9c                                 System.Object::.ctor
02c9b948: str     w19, [x20, #0x10]                          .<>1__state
02c9b94c: ldp     x20, x19, [sp, #0x10]                      
02c9b950: ldr     x30, [sp], #0x20                           
02c9b954: ret                                                
## System.IDisposable.Dispose() -> void
---- NativeInterTimeCount/<ICountDownTMP>d__11::System.IDisposable.Dispose 0x2c9b9b0
02c9b9b0: ret                                                
## MoveNext() -> bool
---- NativeInterTimeCount/<ICountDownTMP>d__11::MoveNext 0x2c9b9b4
02c9b9b4: sub     sp, sp, #0x30                              
02c9b9b8: stp     x30, x21, [sp, #0x10]                      
02c9b9bc: stp     x20, x19, [sp, #0x20]                      
02c9b9c0: adrp    x20, #0x662f000                            
02c9b9c4: mov     x19, x0                                    
02c9b9c8: ldrb    w8, [x20, #0xa45]                          
02c9b9cc: tbnz    w8, #0, #0x2c9b9f0                         
02c9b9d0: adrp    x0, #0x6265000                             
02c9b9d4: ldr     x0, [x0, #0xaa8]                           T:UnityEngine.WaitForSecondsRealtime
02c9b9d8: bl      #0x2b70db0                                 fn_2b70db0
02c9b9dc: adrp    x0, #0x6265000                             
02c9b9e0: ldr     x0, [x0, #0x458]                           S:'{0}s'
02c9b9e4: bl      #0x2b70db0                                 fn_2b70db0
02c9b9e8: mov     w8, #1                                     
02c9b9ec: strb    w8, [x20, #0xa45]                          
02c9b9f0: ldr     w9, [x19, #0x10]                           .<>1__state
02c9b9f4: ldr     x8, [x19, #0x28]                           .<>4__this
02c9b9f8: cmp     w9, #1                                     
02c9b9fc: b.eq    #0x2c9ba14                                 
02c9ba00: cbnz    w9, #0x2c9bae8                             
02c9ba04: mov     w10, #-1                                   
02c9ba08: ldr     w9, [x19, #0x20]                           .time
02c9ba0c: str     w10, [x19, #0x10]                          .<>1__state
02c9ba10: b       #0x2c9ba24                                 
02c9ba14: ldr     w9, [x19, #0x40]                           .<count>5__2
02c9ba18: mov     w10, #-1                                   
02c9ba1c: str     w10, [x19, #0x10]                          .<>1__state
02c9ba20: sub     w9, w9, #1                                 
02c9ba24: str     w9, [x19, #0x40]                           .<count>5__2
02c9ba28: tbnz    w9, #0x1f, #0x2c9bad0                      
02c9ba2c: cbz     x8, #0x2c9bafc                             
02c9ba30: adrp    x10, #0x6263000                            
02c9ba34: add     x1, sp, #0xc                               
02c9ba38: ldr     x10, [x10, #0x970]                         &6645c70(=0)
02c9ba3c: ldr     x20, [x8, #0x20]                           
02c9ba40: str     w9, [sp, #0xc]                             
02c9ba44: ldr     x0, [x10, #0x48]                           &6263098(=0)
02c9ba48: bl      #0x2b70f38                                 fn_2b70f38
02c9ba4c: adrp    x8, #0x6265000                             
02c9ba50: mov     x1, x0                                     
02c9ba54: mov     x2, xzr                                    
02c9ba58: ldr     x8, [x8, #0x458]                           S:'{0}s'
02c9ba5c: ldr     x8, [x8]                                   M:AdsManager::<OnApplicationPause>b__26_0
02c9ba60: mov     x0, x8                                     
02c9ba64: bl      #0x4c9d0ec                                 System.String::Format
02c9ba68: cbz     x20, #0x2c9bafc                            
02c9ba6c: ldr     x8, [x20]                                  &2b706c4(=eb01011ff9400808)
02c9ba70: mov     x1, x0                                     
02c9ba74: mov     x0, x20                                    
02c9ba78: ldr     x9, [x8, #0x558]                           T:GoogleMobileAdsManager
02c9ba7c: ldr     x2, [x8, #0x560]                           T:GoogleMobileAds.Mediation.UnityAds.Api.UnityAds
02c9ba80: blr     x9                                         
02c9ba84: adrp    x8, #0x6265000                             
02c9ba88: ldr     x8, [x8, #0xaa8]                           T:UnityEngine.WaitForSecondsRealtime
02c9ba8c: ldr     w20, [x19, #0x30]                          .duration
02c9ba90: ldr     w21, [x19, #0x20]                          .time
02c9ba94: ldr     x0, [x8]                                   M:AdsManager::<OnApplicationPause>b__26_0
02c9ba98: bl      #0x2b7104c                                 fn_2b7104c
02c9ba9c: add     w8, w21, #1                                
02c9baa0: mov     x1, xzr                                    
02c9baa4: sdiv    w8, w20, w8                                
02c9baa8: mov     x20, x0                                    
02c9baac: scvtf   s0, w8                                     
02c9bab0: bl      #0x5b3e6e4                                 UnityEngine.WaitForSecondsRealtime::.ctor
02c9bab4: str     x20, [x19, #0x18]!                         .<>2__current
02c9bab8: mov     x0, x19                                    
02c9babc: mov     x1, x20                                    
02c9bac0: bl      #0x2b70d54                                 fn_2b70d54
02c9bac4: mov     w0, #1                                     
02c9bac8: stur    w0, [x19, #-8]                             
02c9bacc: b       #0x2c9baec                                 
02c9bad0: ldr     x8, [x19, #0x38]                           .actionComplete
02c9bad4: cbz     x8, #0x2c9bae8                             
02c9bad8: ldr     x9, [x8, #0x18]                            T:AdsManager/<IEHideAdResume>d__30
02c9badc: ldr     x0, [x8, #0x40]                            S:'done_ad'
02c9bae0: ldr     x1, [x8, #0x28]                            T:AdsManager/<ISetAOAInterval>d__33
02c9bae4: blr     x9                                         
02c9bae8: mov     w0, wzr                                    
02c9baec: ldp     x20, x19, [sp, #0x20]                      
02c9baf0: ldp     x30, x21, [sp, #0x10]                      
02c9baf4: add     sp, sp, #0x30                              
02c9baf8: ret                                                
02c9bafc: bl      #0x2b7105c                                 fn_2b7105c
## System.Collections.Generic.IEnumerator<System.Object>.get_Current() -> object
---- NativeInterTimeCount/<ICountDownTMP>d__11::System.Collections.Generic.IEnumerator<System.Object>.get_Current 0x2c9bb00
02c9bb00: ldr     x0, [x0, #0x18]                            .<>2__current
02c9bb04: ret                                                
## System.Collections.IEnumerator.Reset() -> void
---- NativeInterTimeCount/<ICountDownTMP>d__11::System.Collections.IEnumerator.Reset 0x2c9bb08
02c9bb08: stp     x30, x19, [sp, #-0x10]!                    
02c9bb0c: adrp    x0, #0x6264000                             
02c9bb10: ldr     x0, [x0, #0xf60]                           T:System.NotSupportedException
02c9bb14: bl      #0x2b70dc4                                 fn_2b70dc4
02c9bb18: bl      #0x2b7104c                                 fn_2b7104c
02c9bb1c: mov     x1, xzr                                    
02c9bb20: mov     x19, x0                                    
02c9bb24: bl      #0x4e14238                                 System.NotSupportedException::.ctor
02c9bb28: adrp    x0, #0x6265000                             
02c9bb2c: ldr     x0, [x0, #0xab0]                           M:NativeInterTimeCount/<ICountDownTMP>d__11::System.Collections.IEnumerator.Reset
02c9bb30: bl      #0x2b70dc4                                 fn_2b70dc4
02c9bb34: mov     x1, x0                                     
02c9bb38: mov     x0, x19                                    
02c9bb3c: bl      #0x2b70f20                                 fn_2b70f20
## System.Collections.IEnumerator.get_Current() -> object
---- NativeInterTimeCount/<ICountDownTMP>d__11::System.Collections.IEnumerator.get_Current 0x2c9bb40
02c9bb40: ldr     x0, [x0, #0x18]                            .<>2__current
02c9bb44: ret                                                
#### CLASS NativeInterTimeCount parent= UnityEngine.MonoBehaviour
#   field _tmpTime                       TMPro.TMP_Text                                     off=0x20 attr=1 SerializeField
#   field _buttonClose                   UnityEngine.UI.Button                              off=0x28 attr=1 SerializeField
#   field _objView                       UnityEngine.GameObject                             off=0x30 attr=1 SerializeField
#   field _countCoroutine                UnityEngine.Coroutine                              off=0x38 attr=1 
#   field OnClose                        System.Action                                      off=0x40 attr=1 CompilerGeneratedAttribute
## add_OnClose(System.Action value) -> void
---- NativeInterTimeCount::add_OnClose 0x2c9b3d0
02c9b3d0: str     x30, [sp, #-0x30]!                         
02c9b3d4: stp     x22, x21, [sp, #0x10]                      
02c9b3d8: stp     x20, x19, [sp, #0x20]                      
02c9b3dc: adrp    x21, #0x662f000                            
02c9b3e0: mov     x19, x1                                    
02c9b3e4: mov     x20, x0                                    
02c9b3e8: ldrb    w8, [x21, #0xa3f]                          
02c9b3ec: tbnz    w8, #0, #0x2c9b404                         
02c9b3f0: adrp    x0, #0x6264000                             
02c9b3f4: ldr     x0, [x0, #0xf90]                           T:System.Action
02c9b3f8: bl      #0x2b70db0                                 fn_2b70db0
02c9b3fc: mov     w8, #1                                     
02c9b400: strb    w8, [x21, #0xa3f]                          
02c9b404: adrp    x22, #0x6264000                            
02c9b408: ldr     x22, [x22, #0xf90]                         T:System.Action
02c9b40c: ldr     x21, [x20, #0x40]!                         .OnClose
02c9b410: mov     x0, x21                                    
02c9b414: mov     x1, x19                                    
02c9b418: mov     x2, xzr                                    
02c9b41c: bl      #0x4e570ac                                 System.Delegate::Combine
02c9b420: mov     x8, x0                                     
02c9b424: cbz     x0, #0x2c9b438                             
02c9b428: ldr     x1, [x22]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c9b42c: ldr     x9, [x8]                                   
02c9b430: cmp     x9, x1                                     
02c9b434: b.ne    #0x2c9b464                                 
02c9b438: mov     x0, x20                                    
02c9b43c: mov     x1, x8                                     
02c9b440: mov     x2, x21                                    
02c9b444: bl      #0x2ba9880                                 fn_2ba9880
02c9b448: cmp     x0, x21                                    
02c9b44c: mov     x21, x0                                    
02c9b450: b.ne    #0x2c9b410                                 
02c9b454: ldp     x20, x19, [sp, #0x20]                      
02c9b458: ldp     x22, x21, [sp, #0x10]                      
02c9b45c: ldr     x30, [sp], #0x30                           
02c9b460: ret                                                
02c9b464: mov     x0, x8                                     
02c9b468: bl      #0x2b713dc                                 fn_2b713dc
## remove_OnClose(System.Action value) -> void
---- NativeInterTimeCount::remove_OnClose 0x2c9b65c
02c9b65c: str     x30, [sp, #-0x30]!                         
02c9b660: stp     x22, x21, [sp, #0x10]                      
02c9b664: stp     x20, x19, [sp, #0x20]                      
02c9b668: adrp    x21, #0x662f000                            
02c9b66c: mov     x19, x1                                    
02c9b670: mov     x20, x0                                    
02c9b674: ldrb    w8, [x21, #0xa40]                          
02c9b678: tbnz    w8, #0, #0x2c9b690                         
02c9b67c: adrp    x0, #0x6264000                             
02c9b680: ldr     x0, [x0, #0xf90]                           T:System.Action
02c9b684: bl      #0x2b70db0                                 fn_2b70db0
02c9b688: mov     w8, #1                                     
02c9b68c: strb    w8, [x21, #0xa40]                          
02c9b690: adrp    x22, #0x6264000                            
02c9b694: ldr     x22, [x22, #0xf90]                         T:System.Action
02c9b698: ldr     x21, [x20, #0x40]!                         .OnClose
02c9b69c: mov     x0, x21                                    
02c9b6a0: mov     x1, x19                                    
02c9b6a4: mov     x2, xzr                                    
02c9b6a8: bl      #0x4e57298                                 System.Delegate::Remove
02c9b6ac: mov     x8, x0                                     
02c9b6b0: cbz     x0, #0x2c9b6c4                             
02c9b6b4: ldr     x1, [x22]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c9b6b8: ldr     x9, [x8]                                   
02c9b6bc: cmp     x9, x1                                     
02c9b6c0: b.ne    #0x2c9b6f0                                 
02c9b6c4: mov     x0, x20                                    
02c9b6c8: mov     x1, x8                                     
02c9b6cc: mov     x2, x21                                    
02c9b6d0: bl      #0x2ba9880                                 fn_2ba9880
02c9b6d4: cmp     x0, x21                                    
02c9b6d8: mov     x21, x0                                    
02c9b6dc: b.ne    #0x2c9b69c                                 
02c9b6e0: ldp     x20, x19, [sp, #0x20]                      
02c9b6e4: ldp     x22, x21, [sp, #0x10]                      
02c9b6e8: ldr     x30, [sp], #0x30                           
02c9b6ec: ret                                                
02c9b6f0: mov     x0, x8                                     
02c9b6f4: bl      #0x2b713dc                                 fn_2b713dc
## Start() -> void
---- NativeInterTimeCount::Start 0x2c9b6f8
02c9b6f8: stp     x30, x21, [sp, #-0x20]!                    
02c9b6fc: stp     x20, x19, [sp, #0x10]                      
02c9b700: adrp    x20, #0x662f000                            
02c9b704: mov     x19, x0                                    
02c9b708: ldrb    w8, [x20, #0xa41]                          
02c9b70c: tbnz    w8, #0, #0x2c9b730                         
02c9b710: adrp    x0, #0x6265000                             
02c9b714: ldr     x0, [x0, #0xa90]                           M:NativeInterTimeCount::OnCloseClick
02c9b718: bl      #0x2b70db0                                 fn_2b70db0
02c9b71c: adrp    x0, #0x6265000                             
02c9b720: ldr     x0, [x0, #0x3f0]                           T:UnityEngine.Events.UnityAction
02c9b724: bl      #0x2b70db0                                 fn_2b70db0
02c9b728: mov     w8, #1                                     
02c9b72c: strb    w8, [x20, #0xa41]                          
02c9b730: ldr     x8, [x19, #0x28]                           ._buttonClose
02c9b734: cbz     x8, #0x2c9b79c                             
02c9b738: ldr     x0, [x8, #0x100]                           
02c9b73c: cbz     x0, #0x2c9b79c                             
02c9b740: mov     x1, xzr                                    
02c9b744: bl      #0x5b4ce48                                 UnityEngine.Events.UnityEventBase::RemoveAllListeners
02c9b748: ldr     x8, [x19, #0x28]                           ._buttonClose
02c9b74c: cbz     x8, #0x2c9b79c                             
02c9b750: adrp    x9, #0x6265000                             
02c9b754: adrp    x21, #0x6265000                            
02c9b758: ldr     x9, [x9, #0x3f0]                           T:UnityEngine.Events.UnityAction
02c9b75c: ldr     x21, [x21, #0xa90]                         M:NativeInterTimeCount::OnCloseClick
02c9b760: ldr     x20, [x8, #0x100]                          
02c9b764: ldr     x0, [x9]                                   M:AdsManager::<OnApplicationPause>b__26_0
02c9b768: bl      #0x2b7104c                                 fn_2b7104c
02c9b76c: ldr     x2, [x21]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9b770: mov     x1, x19                                    
02c9b774: mov     x3, xzr                                    
02c9b778: mov     x21, x0                                    
02c9b77c: bl      #0x5b4cf98                                 UnityEngine.Events.UnityAction::.ctor
02c9b780: cbz     x20, #0x2c9b79c                            
02c9b784: mov     x0, x20                                    
02c9b788: ldp     x20, x19, [sp, #0x10]                      
02c9b78c: mov     x1, x21                                    
02c9b790: mov     x2, xzr                                    
02c9b794: ldp     x30, x21, [sp], #0x20                      
02c9b798: b       #0x5b4d0ac                                 UnityEngine.Events.UnityEvent::AddListener
02c9b79c: bl      #0x2b7105c                                 fn_2b7105c
## ShowTime() -> void
---- NativeInterTimeCount::ShowTime 0x2c9b320
02c9b320: stp     x30, x21, [sp, #-0x20]!                    
02c9b324: stp     x20, x19, [sp, #0x10]                      
02c9b328: adrp    x20, #0x662f000                            
02c9b32c: mov     x19, x0                                    
02c9b330: ldrb    w8, [x20, #0xa42]                          
02c9b334: tbnz    w8, #0, #0x2c9b358                         
02c9b338: adrp    x0, #0x6264000                             
02c9b33c: ldr     x0, [x0, #0xf90]                           T:System.Action
02c9b340: bl      #0x2b70db0                                 fn_2b70db0
02c9b344: adrp    x0, #0x6265000                             
02c9b348: ldr     x0, [x0, #0xa70]                           M:NativeInterTimeCount::<ShowTime>b__8_0
02c9b34c: bl      #0x2b70db0                                 fn_2b70db0
02c9b350: mov     w8, #1                                     
02c9b354: strb    w8, [x20, #0xa42]                          
02c9b358: ldr     x0, [x19, #0x30]                           ._objView
02c9b35c: cbz     x0, #0x2c9b3cc                             
02c9b360: mov     w1, #1                                     
02c9b364: mov     x2, xzr                                    
02c9b368: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02c9b36c: ldr     x0, [x19, #0x28]                           ._buttonClose
02c9b370: cbz     x0, #0x2c9b3cc                             
02c9b374: mov     x1, xzr                                    
02c9b378: bl      #0x5b339ec                                 UnityEngine.Component::get_gameObject
02c9b37c: cbz     x0, #0x2c9b3cc                             
02c9b380: adrp    x20, #0x6264000                            
02c9b384: adrp    x21, #0x6265000                            
02c9b388: mov     w1, wzr                                    
02c9b38c: ldr     x20, [x20, #0xf90]                         T:System.Action
02c9b390: ldr     x21, [x21, #0xa70]                         M:NativeInterTimeCount::<ShowTime>b__8_0
02c9b394: mov     x2, xzr                                    
02c9b398: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02c9b39c: ldr     x0, [x20]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c9b3a0: bl      #0x2b7104c                                 fn_2b7104c
02c9b3a4: ldr     x2, [x21]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9b3a8: mov     x1, x19                                    
02c9b3ac: mov     x3, xzr                                    
02c9b3b0: mov     x20, x0                                    
02c9b3b4: bl      #0x4d8ddbc                                 System.Action::.ctor
02c9b3b8: mov     x0, x19                                    
02c9b3bc: mov     x1, x20                                    
02c9b3c0: ldp     x20, x19, [sp, #0x10]                      
02c9b3c4: ldp     x30, x21, [sp], #0x20                      
02c9b3c8: b       #0x2c9b7a0                                 NativeInterTimeCount::CountTimeAndAction
02c9b3cc: bl      #0x2b7105c                                 fn_2b7105c
## OnCloseClick() -> void
---- NativeInterTimeCount::OnCloseClick 0x2c9b84c
02c9b84c: stp     x30, x19, [sp, #-0x10]!                    
02c9b850: mov     x19, x0                                    
02c9b854: ldr     x0, [x0, #0x30]                            ._objView
02c9b858: cbz     x0, #0x2c9b88c                             
02c9b85c: mov     w1, wzr                                    
02c9b860: mov     x2, xzr                                    
02c9b864: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02c9b868: ldr     x8, [x19, #0x40]                           .OnClose
02c9b86c: cbz     x8, #0x2c9b884                             
02c9b870: ldr     x0, [x8, #0x40]                            
02c9b874: ldr     x1, [x8, #0x28]                            
02c9b878: ldr     x2, [x8, #0x18]                            
02c9b87c: ldp     x30, x19, [sp], #0x10                      
02c9b880: br      x2                                         
02c9b884: ldp     x30, x19, [sp], #0x10                      
02c9b888: ret                                                
02c9b88c: bl      #0x2b7105c                                 fn_2b7105c
## CountTimeAndAction(System.Action action) -> void
---- NativeInterTimeCount::CountTimeAndAction 0x2c9b7a0
02c9b7a0: stp     x30, x21, [sp, #-0x20]!                    
02c9b7a4: stp     x20, x19, [sp, #0x10]                      
02c9b7a8: adrp    x21, #0x662f000                            
02c9b7ac: mov     x20, x1                                    
02c9b7b0: mov     x19, x0                                    
02c9b7b4: ldrb    w8, [x21, #0xa43]                          
02c9b7b8: tbnz    w8, #0, #0x2c9b7d0                         
02c9b7bc: adrp    x0, #0x6265000                             
02c9b7c0: ldr     x0, [x0, #0xa98]                           S:'3'
02c9b7c4: bl      #0x2b70db0                                 fn_2b70db0
02c9b7c8: mov     w8, #1                                     
02c9b7cc: strb    w8, [x21, #0xa43]                          
02c9b7d0: ldr     x0, [x19, #0x20]                           ._tmpTime
02c9b7d4: cbz     x0, #0x2c9b848                             
02c9b7d8: adrp    x8, #0x6265000                             
02c9b7dc: ldr     x8, [x8, #0xa98]                           S:'3'
02c9b7e0: ldr     x9, [x0]                                   M:AdsManager::<OnApplicationPause>b__26_0
02c9b7e4: ldr     x1, [x8]                                   M:AdsManager::<OnApplicationPause>b__26_0
02c9b7e8: ldr     x8, [x9, #0x558]                           
02c9b7ec: ldr     x2, [x9, #0x560]                           
02c9b7f0: blr     x8                                         
02c9b7f4: mov     x21, x19                                   
02c9b7f8: ldr     x1, [x21, #0x38]!                          [662f038]=6000016 f=2.40742e-35,0 ._countCoroutine
02c9b7fc: cbz     x1, #0x2c9b80c                             
02c9b800: mov     x0, x19                                    
02c9b804: mov     x2, xzr                                    
02c9b808: bl      #0x5b38c4c                                 UnityEngine.MonoBehaviour::StopCoroutine
02c9b80c: mov     x0, x19                                    
02c9b810: mov     w1, #3                                     
02c9b814: mov     w2, #4                                     
02c9b818: mov     x3, x20                                    
02c9b81c: bl      #0x2c9b890                                 NativeInterTimeCount::ICountDownTMP
02c9b820: mov     x1, x0                                     
02c9b824: mov     x0, x19                                    
02c9b828: mov     x2, xzr                                    
02c9b82c: bl      #0x5b389f0                                 UnityEngine.MonoBehaviour::StartCoroutine
02c9b830: mov     x1, x0                                     
02c9b834: mov     x0, x21                                    
02c9b838: str     x1, [x19, #0x38]                           ._countCoroutine
02c9b83c: ldp     x20, x19, [sp, #0x10]                      
02c9b840: ldp     x30, x21, [sp], #0x20                      
02c9b844: b       #0x2b70d54                                 
02c9b848: bl      #0x2b7105c                                 fn_2b7105c
## ICountDownTMP(int time, int duration, System.Action actionComplete) -> System.Collections.IEnumerator
---- NativeInterTimeCount::ICountDownTMP 0x2c9b890
02c9b890: str     x30, [sp, #-0x40]!                         
02c9b894: stp     x24, x23, [sp, #0x10]                      
02c9b898: stp     x22, x21, [sp, #0x20]                      
02c9b89c: stp     x20, x19, [sp, #0x30]                      
02c9b8a0: adrp    x23, #0x662f000                            
02c9b8a4: adrp    x24, #0x6265000                            
02c9b8a8: mov     x19, x3                                    
02c9b8ac: ldrb    w8, [x23, #0xa44]                          
02c9b8b0: ldr     x24, [x24, #0xaa0]                         T:NativeInterTimeCount/<ICountDownTMP>d__11
02c9b8b4: mov     w20, w2                                    
02c9b8b8: mov     w21, w1                                    
02c9b8bc: mov     x22, x0                                    
02c9b8c0: tbnz    w8, #0, #0x2c9b8d8                         
02c9b8c4: adrp    x0, #0x6265000                             
02c9b8c8: ldr     x0, [x0, #0xaa0]                           T:NativeInterTimeCount/<ICountDownTMP>d__11
02c9b8cc: bl      #0x2b70db0                                 fn_2b70db0
02c9b8d0: mov     w8, #1                                     
02c9b8d4: strb    w8, [x23, #0xa44]                          
02c9b8d8: ldr     x0, [x24]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9b8dc: bl      #0x2b7104c                                 fn_2b7104c
02c9b8e0: mov     x1, xzr                                    
02c9b8e4: mov     x23, x0                                    
02c9b8e8: bl      #0x4e53e9c                                 System.Object::.ctor
02c9b8ec: mov     x0, x23                                    
02c9b8f0: mov     x1, x22                                    
02c9b8f4: str     wzr, [x23, #0x10]                          
02c9b8f8: str     x22, [x0, #0x28]!                          ._buttonClose
02c9b8fc: bl      #0x2b70d54                                 fn_2b70d54
02c9b900: mov     x0, x23                                    
02c9b904: mov     x1, x19                                    
02c9b908: str     w21, [x23, #0x20]                          
02c9b90c: str     w20, [x23, #0x30]                          
02c9b910: str     x19, [x0, #0x38]!                          ._countCoroutine
02c9b914: bl      #0x2b70d54                                 fn_2b70d54
02c9b918: mov     x0, x23                                    
02c9b91c: ldp     x20, x19, [sp, #0x30]                      
02c9b920: ldp     x22, x21, [sp, #0x20]                      
02c9b924: ldp     x24, x23, [sp, #0x10]                      
02c9b928: ldr     x30, [sp], #0x40                           
02c9b92c: ret                                                
## .ctor() -> void
---- NativeInterTimeCount::.ctor 0x2c9b958
02c9b958: mov     x1, xzr                                    
02c9b95c: b       #0x5b397b0                                 UnityEngine.MonoBehaviour::.ctor
## <ShowTime>b__8_0() -> void
---- NativeInterTimeCount::<ShowTime>b__8_0 0x2c9b960
02c9b960: stp     x30, x19, [sp, #-0x10]!                    
02c9b964: mov     x19, x0                                    
02c9b968: ldr     x0, [x0, #0x28]                            ._buttonClose
02c9b96c: cbz     x0, #0x2c9b9ac                             
02c9b970: mov     x1, xzr                                    
02c9b974: bl      #0x5b339ec                                 UnityEngine.Component::get_gameObject
02c9b978: cbz     x0, #0x2c9b9ac                             
02c9b97c: mov     w1, #1                                     
02c9b980: mov     x2, xzr                                    
02c9b984: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02c9b988: ldr     x0, [x19, #0x20]                           ._tmpTime
02c9b98c: cbz     x0, #0x2c9b9ac                             
02c9b990: mov     x1, xzr                                    
02c9b994: bl      #0x5b339ec                                 UnityEngine.Component::get_gameObject
02c9b998: cbz     x0, #0x2c9b9ac                             
02c9b99c: mov     w1, wzr                                    
02c9b9a0: mov     x2, xzr                                    
02c9b9a4: ldp     x30, x19, [sp], #0x10                      
02c9b9a8: b       #0x5b36b38                                 UnityEngine.GameObject::SetActive
02c9b9ac: bl      #0x2b7105c                                 fn_2b7105c
