#### CLASS RewardApplovinControl/<LoadRewardedAfterDelay>d__6 parent= object
#   field <>1__state                     int                                                off=0x10 attr=1 
#   field <>2__current                   object                                             off=0x18 attr=1 
#   field delay                          float                                              off=0x20 attr=6 
#   field <>4__this                      RewardApplovinControl                              off=0x28 attr=6 
## .ctor(int <>1__state) -> void
---- RewardApplovinControl/<LoadRewardedAfterDelay>d__6::.ctor 0x2c8eee4
02c8eee4: str     x30, [sp, #-0x20]!                         
02c8eee8: stp     x20, x19, [sp, #0x10]                      
02c8eeec: mov     w19, w1                                    
02c8eef0: mov     x1, xzr                                    
02c8eef4: mov     x20, x0                                    
02c8eef8: bl      #0x4e53e9c                                 System.Object::.ctor
02c8eefc: str     w19, [x20, #0x10]                          .<>1__state
02c8ef00: ldp     x20, x19, [sp, #0x10]                      
02c8ef04: ldr     x30, [sp], #0x20                           
02c8ef08: ret                                                
## System.IDisposable.Dispose() -> void
---- RewardApplovinControl/<LoadRewardedAfterDelay>d__6::System.IDisposable.Dispose 0x2c8efd4
02c8efd4: ret                                                
## MoveNext() -> bool
---- RewardApplovinControl/<LoadRewardedAfterDelay>d__6::MoveNext 0x2c8efd8
02c8efd8: str     d8, [sp, #-0x30]!                          
02c8efdc: stp     x30, x21, [sp, #0x10]                      
02c8efe0: stp     x20, x19, [sp, #0x20]                      
02c8efe4: adrp    x20, #0x662f000                            
02c8efe8: mov     x19, x0                                    
02c8efec: ldrb    w8, [x20, #0x9b3]                          
02c8eff0: tbnz    w8, #0, #0x2c8f008                         
02c8eff4: adrp    x0, #0x6264000                             
02c8eff8: ldr     x0, [x0, #0xf58]                           T:UnityEngine.WaitForSeconds
02c8effc: bl      #0x2b70db0                                 fn_2b70db0
02c8f000: mov     w8, #1                                     
02c8f004: strb    w8, [x20, #0x9b3]                          
02c8f008: ldr     w21, [x19, #0x10]                          .<>1__state
02c8f00c: cbz     w21, #0x2c8f030                            
02c8f010: cmp     w21, #1                                    
02c8f014: b.ne    #0x2c8f074                                 
02c8f018: ldr     x8, [x19, #0x28]                           .<>4__this
02c8f01c: mov     w9, #-1                                    
02c8f020: str     w9, [x19, #0x10]                           .<>1__state
02c8f024: cbz     x8, #0x2c8f08c                             
02c8f028: bl      #0x2c8ede0                                 RewardApplovinControl::LoadRewarded
02c8f02c: b       #0x2c8f074                                 
02c8f030: adrp    x8, #0x6264000                             
02c8f034: mov     w9, #-1                                    
02c8f038: ldr     x8, [x8, #0xf58]                           T:UnityEngine.WaitForSeconds
02c8f03c: ldr     s8, [x19, #0x20]                           .delay
02c8f040: str     w9, [x19, #0x10]                           .<>1__state
02c8f044: ldr     x0, [x8]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c8f048: bl      #0x2b7104c                                 fn_2b7104c
02c8f04c: fmov    s0, s8                                     
02c8f050: mov     x1, xzr                                    
02c8f054: mov     x20, x0                                    
02c8f058: bl      #0x5b3e5e8                                 UnityEngine.WaitForSeconds::.ctor
02c8f05c: mov     x0, x19                                    
02c8f060: mov     x1, x20                                    
02c8f064: str     x20, [x0, #0x18]!                          .<>2__current
02c8f068: bl      #0x2b70d54                                 fn_2b70d54
02c8f06c: mov     w8, #1                                     
02c8f070: str     w8, [x19, #0x10]                           .<>1__state
02c8f074: cmp     w21, #0                                    
02c8f078: ldp     x20, x19, [sp, #0x20]                      
02c8f07c: ldp     x30, x21, [sp, #0x10]                      
02c8f080: cset    w0, eq                                     
02c8f084: ldr     d8, [sp], #0x30                            
02c8f088: ret                                                
02c8f08c: bl      #0x2b7105c                                 fn_2b7105c
## System.Collections.Generic.IEnumerator<System.Object>.get_Current() -> object
---- RewardApplovinControl/<LoadRewardedAfterDelay>d__6::System.Collections.Generic.IEnumerator<System.Object>.get_Current 0x2c8f090
02c8f090: ldr     x0, [x0, #0x18]                            .<>2__current
02c8f094: ret                                                
## System.Collections.IEnumerator.Reset() -> void
---- RewardApplovinControl/<LoadRewardedAfterDelay>d__6::System.Collections.IEnumerator.Reset 0x2c8f098
02c8f098: stp     x30, x19, [sp, #-0x10]!                    
02c8f09c: adrp    x0, #0x6264000                             
02c8f0a0: ldr     x0, [x0, #0xf60]                           T:System.NotSupportedException
02c8f0a4: bl      #0x2b70dc4                                 fn_2b70dc4
02c8f0a8: bl      #0x2b7104c                                 fn_2b7104c
02c8f0ac: mov     x1, xzr                                    
02c8f0b0: mov     x19, x0                                    
02c8f0b4: bl      #0x4e14238                                 System.NotSupportedException::.ctor
02c8f0b8: adrp    x0, #0x6265000                             
02c8f0bc: ldr     x0, [x0, #0x440]                           M:RewardApplovinControl/<LoadRewardedAfterDelay>d__6::System.Collections.IEnumerator.Reset
02c8f0c0: bl      #0x2b70dc4                                 fn_2b70dc4
02c8f0c4: mov     x1, x0                                     
02c8f0c8: mov     x0, x19                                    
02c8f0cc: bl      #0x2b70f20                                 fn_2b70f20
## System.Collections.IEnumerator.get_Current() -> object
---- RewardApplovinControl/<LoadRewardedAfterDelay>d__6::System.Collections.IEnumerator.get_Current 0x2c8f0d0
02c8f0d0: ldr     x0, [x0, #0x18]                            .<>2__current
02c8f0d4: ret                                                
#### CLASS RewardApplovinControl parent= ApplovinEventBase
#   field rewardCompleted                System.Action                                      off=0x30 attr=1 
## Start() -> void
---- RewardApplovinControl::Start 0x2c8edd4
02c8edd4: mov     w8, #1                                     
02c8edd8: str     w8, [x0, #0x28]                            
02c8eddc: ret                                                
## InitAd() -> void
---- RewardApplovinControl::InitAd 0x2c8d25c
02c8d25c: stp     x30, x25, [sp, #-0x40]!                    
02c8d260: stp     x24, x23, [sp, #0x10]                      
02c8d264: stp     x22, x21, [sp, #0x20]                      
02c8d268: stp     x20, x19, [sp, #0x30]                      
02c8d26c: adrp    x20, #0x662f000                            
02c8d270: adrp    x21, #0x6265000                            
02c8d274: mov     x19, x0                                    
02c8d278: ldrb    w8, [x20, #0x9ad]                          
02c8d27c: ldr     x21, [x21, #0x350]                         T:type7232(k15)
02c8d280: tbnz    w8, #0, #0x2c8d2c8                         
02c8d284: adrp    x0, #0x6265000                             
02c8d288: ldr     x0, [x0, #0x350]                           T:type7232(k15)
02c8d28c: bl      #0x2b70db0                                 fn_2b70db0
02c8d290: adrp    x0, #0x6265000                             
02c8d294: ldr     x0, [x0, #0x358]                           T:type7234(k15)
02c8d298: bl      #0x2b70db0                                 fn_2b70db0
02c8d29c: adrp    x0, #0x6265000                             
02c8d2a0: ldr     x0, [x0, #0x360]                           T:type7277(k15)
02c8d2a4: bl      #0x2b70db0                                 fn_2b70db0
02c8d2a8: adrp    x0, #0x6265000                             
02c8d2ac: ldr     x0, [x0, #0x368]                           T:type7279(k15)
02c8d2b0: bl      #0x2b70db0                                 fn_2b70db0
02c8d2b4: adrp    x0, #0x6265000                             
02c8d2b8: ldr     x0, [x0, #0x370]                           M:RewardApplovinControl::RewardedOnAdReceivedRewardEvent
02c8d2bc: bl      #0x2b70db0                                 fn_2b70db0
02c8d2c0: mov     w8, #1                                     
02c8d2c4: strb    w8, [x20, #0x9ad]                          
02c8d2c8: ldr     x0, [x21]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c8d2cc: bl      #0x2b7104c                                 fn_2b7104c
02c8d2d0: cbz     x19, #0x2c8d45c                            
02c8d2d4: adrp    x25, #0x6265000                            
02c8d2d8: adrp    x24, #0x6265000                            
02c8d2dc: adrp    x23, #0x6265000                            
02c8d2e0: ldr     x25, [x25, #0x358]                         T:type7234(k15)
02c8d2e4: ldr     x24, [x24, #0x360]                         T:type7277(k15)
02c8d2e8: ldr     x8, [x19]                                  
02c8d2ec: adrp    x22, #0x6265000                            
02c8d2f0: ldr     x23, [x23, #0x368]                         T:type7279(k15)
02c8d2f4: mov     x1, x19                                    
02c8d2f8: ldr     x22, [x22, #0x370]                         M:RewardApplovinControl::RewardedOnAdReceivedRewardEvent
02c8d2fc: ldr     x2, [x8, #0x180]                           
02c8d300: mov     x3, xzr                                    
02c8d304: mov     x20, x0                                    
02c8d308: bl      #0x453ce6c                                 fn_453ce6c
02c8d30c: mov     x0, x20                                    
02c8d310: mov     x1, xzr                                    
02c8d314: bl      #0x4c5d7a4                                 MaxSdkCallbacks/Rewarded::add_OnAdLoadedEvent
02c8d318: ldr     x0, [x25]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c8d31c: bl      #0x2b7104c                                 fn_2b7104c
02c8d320: ldr     x8, [x19]                                  
02c8d324: mov     x1, x19                                    
02c8d328: mov     x3, xzr                                    
02c8d32c: mov     x20, x0                                    
02c8d330: ldr     x2, [x8, #0x190]                           
02c8d334: bl      #0x453ce6c                                 fn_453ce6c
02c8d338: mov     x0, x20                                    
02c8d33c: mov     x1, xzr                                    
02c8d340: bl      #0x4c5d9bc                                 MaxSdkCallbacks/Rewarded::add_OnAdLoadFailedEvent
02c8d344: ldr     x0, [x21]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c8d348: bl      #0x2b7104c                                 fn_2b7104c
02c8d34c: ldr     x8, [x19]                                  
02c8d350: mov     x1, x19                                    
02c8d354: mov     x3, xzr                                    
02c8d358: mov     x20, x0                                    
02c8d35c: ldr     x2, [x8, #0x1a0]                           
02c8d360: bl      #0x453ce6c                                 fn_453ce6c
02c8d364: mov     x0, x20                                    
02c8d368: mov     x1, xzr                                    
02c8d36c: bl      #0x4c5dbb4                                 MaxSdkCallbacks/Rewarded::add_OnAdDisplayedEvent
02c8d370: ldr     x0, [x24]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c8d374: bl      #0x2b7104c                                 fn_2b7104c
02c8d378: ldr     x8, [x19]                                  
02c8d37c: mov     x1, x19                                    
02c8d380: mov     x3, xzr                                    
02c8d384: mov     x20, x0                                    
02c8d388: ldr     x2, [x8, #0x1d0]                           
02c8d38c: bl      #0x453e174                                 fn_453e174
02c8d390: mov     x0, x20                                    
02c8d394: mov     x1, xzr                                    
02c8d398: bl      #0x4c5ddac                                 MaxSdkCallbacks/Rewarded::add_OnAdDisplayFailedEvent
02c8d39c: ldr     x0, [x21]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c8d3a0: bl      #0x2b7104c                                 fn_2b7104c
02c8d3a4: ldr     x8, [x19]                                  
02c8d3a8: mov     x1, x19                                    
02c8d3ac: mov     x3, xzr                                    
02c8d3b0: mov     x20, x0                                    
02c8d3b4: ldr     x2, [x8, #0x1b0]                           
02c8d3b8: bl      #0x453ce6c                                 fn_453ce6c
02c8d3bc: mov     x0, x20                                    
02c8d3c0: mov     x1, xzr                                    
02c8d3c4: bl      #0x4c5dfa4                                 MaxSdkCallbacks/Rewarded::add_OnAdClickedEvent
02c8d3c8: ldr     x0, [x21]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c8d3cc: bl      #0x2b7104c                                 fn_2b7104c
02c8d3d0: ldr     x8, [x19]                                  
02c8d3d4: mov     x1, x19                                    
02c8d3d8: mov     x3, xzr                                    
02c8d3dc: mov     x20, x0                                    
02c8d3e0: ldr     x2, [x8, #0x1c0]                           
02c8d3e4: bl      #0x453ce6c                                 fn_453ce6c
02c8d3e8: mov     x0, x20                                    
02c8d3ec: mov     x1, xzr                                    
02c8d3f0: bl      #0x4c5e97c                                 MaxSdkCallbacks/Rewarded::add_OnAdHiddenEvent
02c8d3f4: ldr     x0, [x21]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c8d3f8: bl      #0x2b7104c                                 fn_2b7104c
02c8d3fc: ldr     x8, [x19]                                  
02c8d400: mov     x1, x19                                    
02c8d404: mov     x3, xzr                                    
02c8d408: mov     x20, x0                                    
02c8d40c: ldr     x2, [x8, #0x1e0]                           
02c8d410: bl      #0x453ce6c                                 fn_453ce6c
02c8d414: mov     x0, x20                                    
02c8d418: mov     x1, xzr                                    
02c8d41c: bl      #0x4c5e19c                                 MaxSdkCallbacks/Rewarded::add_OnAdRevenuePaidEvent
02c8d420: ldr     x0, [x23]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c8d424: bl      #0x2b7104c                                 fn_2b7104c
02c8d428: ldr     x2, [x22]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c8d42c: mov     x1, x19                                    
02c8d430: mov     x3, xzr                                    
02c8d434: mov     x20, x0                                    
02c8d438: bl      #0x453e294                                 fn_453e294
02c8d43c: mov     x0, x20                                    
02c8d440: mov     x1, xzr                                    
02c8d444: bl      #0x4c5e784                                 MaxSdkCallbacks/Rewarded::add_OnAdReceivedRewardEvent
02c8d448: ldp     x20, x19, [sp, #0x30]                      
02c8d44c: ldp     x22, x21, [sp, #0x20]                      
02c8d450: ldp     x24, x23, [sp, #0x10]                      
02c8d454: ldp     x30, x25, [sp], #0x40                      
02c8d458: b       #0x2c8ede0                                 RewardApplovinControl::LoadRewarded
02c8d45c: bl      #0x2b7105c                                 fn_2b7105c
## IsAdReady() -> bool
---- RewardApplovinControl::IsAdReady 0x2c8c92c
02c8c92c: str     x30, [sp, #-0x20]!                         
02c8c930: stp     x20, x19, [sp, #0x10]                      
02c8c934: adrp    x20, #0x662f000                            
02c8c938: adrp    x19, #0x6265000                            
02c8c93c: ldrb    w8, [x20, #0x9ae]                          
02c8c940: ldr     x19, [x19, #0x2f8]                         T:MaxSdkAndroid
02c8c944: tbnz    w8, #0, #0x2c8c95c                         
02c8c948: adrp    x0, #0x6265000                             
02c8c94c: ldr     x0, [x0, #0x2f8]                           T:MaxSdkAndroid
02c8c950: bl      #0x2b70db0                                 fn_2b70db0
02c8c954: mov     w8, #1                                     
02c8c958: strb    w8, [x20, #0x9ae]                          
02c8c95c: mov     w0, #1                                     
02c8c960: bl      #0x2c8de38                                 KeyAds::Get
02c8c964: ldr     x8, [x19]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c8c968: mov     x19, x0                                    
02c8c96c: ldr     w9, [x8, #0xe4]                            
02c8c970: cbnz    w9, #0x2c8c97c                             
02c8c974: mov     x0, x8                                     
02c8c978: bl      #0x2b70f30                                 fn_2b70f30
02c8c97c: mov     x0, x19                                    
02c8c980: ldp     x20, x19, [sp, #0x10]                      
02c8c984: mov     x1, xzr                                    
02c8c988: ldr     x30, [sp], #0x20                           
02c8c98c: b       #0x4c54c64                                 MaxSdkAndroid::IsRewardedAdReady
## LoadRewarded() -> void
---- RewardApplovinControl::LoadRewarded 0x2c8ede0
02c8ede0: str     x30, [sp, #-0x20]!                         
02c8ede4: stp     x20, x19, [sp, #0x10]                      
02c8ede8: adrp    x20, #0x662f000                            
02c8edec: adrp    x19, #0x6265000                            
02c8edf0: ldrb    w8, [x20, #0x9af]                          
02c8edf4: ldr     x19, [x19, #0x2f8]                         T:MaxSdkAndroid
02c8edf8: tbnz    w8, #0, #0x2c8ee10                         
02c8edfc: adrp    x0, #0x6265000                             
02c8ee00: ldr     x0, [x0, #0x2f8]                           T:MaxSdkAndroid
02c8ee04: bl      #0x2b70db0                                 fn_2b70db0
02c8ee08: mov     w8, #1                                     
02c8ee0c: strb    w8, [x20, #0x9af]                          
02c8ee10: mov     w0, #1                                     
02c8ee14: bl      #0x2c8de38                                 KeyAds::Get
02c8ee18: ldr     x8, [x19]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c8ee1c: mov     x19, x0                                    
02c8ee20: ldr     w9, [x8, #0xe4]                            
02c8ee24: cbnz    w9, #0x2c8ee30                             
02c8ee28: mov     x0, x8                                     
02c8ee2c: bl      #0x2b70f30                                 fn_2b70f30
02c8ee30: mov     x0, x19                                    
02c8ee34: ldp     x20, x19, [sp, #0x10]                      
02c8ee38: mov     x1, xzr                                    
02c8ee3c: ldr     x30, [sp], #0x20                           
02c8ee40: b       #0x4c54b4c                                 MaxSdkAndroid::LoadRewardedAd
## TryLoadRewarded() -> void
---- RewardApplovinControl::TryLoadRewarded 0x2c8ee44
02c8ee44: stp     x30, x19, [sp, #-0x10]!                    
02c8ee48: fmov    s0, #3.00000000                            
02c8ee4c: mov     x19, x0                                    
02c8ee50: bl      #0x2c8ee68                                 RewardApplovinControl::LoadRewardedAfterDelay
02c8ee54: mov     x1, x0                                     
02c8ee58: mov     x0, x19                                    
02c8ee5c: mov     x2, xzr                                    
02c8ee60: ldp     x30, x19, [sp], #0x10                      
02c8ee64: b       #0x5b389f0                                 UnityEngine.MonoBehaviour::StartCoroutine
## LoadRewardedAfterDelay(float delay) -> System.Collections.IEnumerator
---- RewardApplovinControl::LoadRewardedAfterDelay 0x2c8ee68
02c8ee68: str     d8, [sp, #-0x30]!                          
02c8ee6c: stp     x30, x21, [sp, #0x10]                      
02c8ee70: stp     x20, x19, [sp, #0x20]                      
02c8ee74: fmov    s8, s0                                     
02c8ee78: adrp    x20, #0x662f000                            
02c8ee7c: adrp    x21, #0x6265000                            
02c8ee80: ldrb    w8, [x20, #0x9b0]                          
02c8ee84: ldr     x21, [x21, #0x430]                         T:RewardApplovinControl/<LoadRewardedAfterDelay>d__6
02c8ee88: mov     x19, x0                                    
02c8ee8c: tbnz    w8, #0, #0x2c8eea4                         
02c8ee90: adrp    x0, #0x6265000                             
02c8ee94: ldr     x0, [x0, #0x430]                           T:RewardApplovinControl/<LoadRewardedAfterDelay>d__6
02c8ee98: bl      #0x2b70db0                                 fn_2b70db0
02c8ee9c: mov     w8, #1                                     
02c8eea0: strb    w8, [x20, #0x9b0]                          
02c8eea4: ldr     x0, [x21]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c8eea8: bl      #0x2b7104c                                 fn_2b7104c
02c8eeac: mov     x1, xzr                                    
02c8eeb0: mov     x20, x0                                    
02c8eeb4: bl      #0x4e53e9c                                 System.Object::.ctor
02c8eeb8: mov     x0, x20                                    
02c8eebc: mov     x1, x19                                    
02c8eec0: str     wzr, [x20, #0x10]                          
02c8eec4: str     x19, [x0, #0x28]!                          
02c8eec8: bl      #0x2b70d54                                 fn_2b70d54
02c8eecc: mov     x0, x20                                    
02c8eed0: str     s8, [x20, #0x20]                           
02c8eed4: ldp     x20, x19, [sp, #0x20]                      
02c8eed8: ldp     x30, x21, [sp, #0x10]                      
02c8eedc: ldr     d8, [sp], #0x30                            
02c8eee0: ret                                                
## ShowAd(string placment, System.Action reward) -> void
---- RewardApplovinControl::ShowAd 0x2c8cc84
02c8cc84: stp     x30, x23, [sp, #-0x30]!                    
02c8cc88: stp     x22, x21, [sp, #0x10]                      
02c8cc8c: stp     x20, x19, [sp, #0x20]                      
02c8cc90: adrp    x23, #0x662f000                            
02c8cc94: adrp    x22, #0x6265000                            
02c8cc98: mov     x19, x2                                    
02c8cc9c: ldrb    w8, [x23, #0x9b1]                          
02c8cca0: ldr     x22, [x22, #0x2f8]                         T:MaxSdkAndroid
02c8cca4: mov     x21, x1                                    
02c8cca8: mov     x20, x0                                    
02c8ccac: tbnz    w8, #0, #0x2c8ccd0                         
02c8ccb0: adrp    x0, #0x6265000                             
02c8ccb4: ldr     x0, [x0, #0x2f8]                           T:MaxSdkAndroid
02c8ccb8: bl      #0x2b70db0                                 fn_2b70db0
02c8ccbc: adrp    x0, #0x6265000                             
02c8ccc0: ldr     x0, [x0, #0x318]                           S:'Ads not ready yet!'
02c8ccc4: bl      #0x2b70db0                                 fn_2b70db0
02c8ccc8: mov     w8, #1                                     
02c8cccc: strb    w8, [x23, #0x9b1]                          
02c8ccd0: mov     x0, x20                                    
02c8ccd4: mov     x1, x21                                    
02c8ccd8: str     x21, [x0, #0x20]!                          
02c8ccdc: bl      #0x2b70d54                                 fn_2b70d54
02c8cce0: mov     w0, #1                                     
02c8cce4: bl      #0x2c8de38                                 KeyAds::Get
02c8cce8: ldr     x8, [x22]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c8ccec: mov     x21, x0                                    
02c8ccf0: ldr     w9, [x8, #0xe4]                            
02c8ccf4: cbnz    w9, #0x2c8cd00                             
02c8ccf8: mov     x0, x8                                     
02c8ccfc: bl      #0x2b70f30                                 fn_2b70f30
02c8cd00: mov     x0, x21                                    
02c8cd04: mov     x1, xzr                                    
02c8cd08: bl      #0x4c54c64                                 MaxSdkAndroid::IsRewardedAdReady
02c8cd0c: tbz     w0, #0, #0x2c8cd60                         
02c8cd10: str     x19, [x20, #0x30]!                         .rewardCompleted
02c8cd14: mov     x0, x20                                    
02c8cd18: mov     x1, x19                                    
02c8cd1c: bl      #0x2b70d54                                 fn_2b70d54
02c8cd20: mov     w0, #1                                     
02c8cd24: bl      #0x2c8de38                                 KeyAds::Get
02c8cd28: ldr     x8, [x22]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c8cd2c: mov     x19, x0                                    
02c8cd30: ldr     w9, [x8, #0xe4]                            
02c8cd34: cbnz    w9, #0x2c8cd40                             
02c8cd38: mov     x0, x8                                     
02c8cd3c: bl      #0x2b70f30                                 fn_2b70f30
02c8cd40: mov     x0, x19                                    
02c8cd44: ldp     x20, x19, [sp, #0x20]                      
02c8cd48: ldp     x22, x21, [sp, #0x10]                      
02c8cd4c: mov     x1, xzr                                    
02c8cd50: mov     x2, xzr                                    
02c8cd54: mov     x3, xzr                                    
02c8cd58: ldp     x30, x23, [sp], #0x30                      
02c8cd5c: b       #0x4c54d90                                 MaxSdkAndroid::ShowRewardedAd
02c8cd60: adrp    x8, #0x6265000                             
02c8cd64: mov     x1, xzr                                    
02c8cd68: ldr     x8, [x8, #0x318]                           S:'Ads not ready yet!'
02c8cd6c: ldp     x20, x19, [sp, #0x20]                      
02c8cd70: ldp     x22, x21, [sp, #0x10]                      
02c8cd74: ldr     x0, [x8]                                   M:AdsManager::<OnApplicationPause>b__26_0
02c8cd78: ldp     x30, x23, [sp], #0x30                      
02c8cd7c: b       #0x2ca4354                                 ShowToastMessageAndroid::ShowMessage
## OnAdHiddenEvent(string adUnitID, MaxSdkBase/AdInfo adInfo) -> void
---- RewardApplovinControl::OnAdHiddenEvent 0x2c8ef0c
02c8ef0c: str     x30, [sp, #-0x10]!                         
02c8ef10: bl      #0x2c8bea0                                 ApplovinEventBase::OnAdHiddenEvent
02c8ef14: ldr     x30, [sp], #0x10                           
02c8ef18: b       #0x2c8ede0                                 RewardApplovinControl::LoadRewarded
## OnAdDisplayFailedEvent(string adUnitId, MaxSdkBase/ErrorInfo errorInfo, MaxSdkBase/AdInfo adInfo) -> void
---- RewardApplovinControl::OnAdDisplayFailedEvent 0x2c8ef1c
02c8ef1c: stp     x30, x23, [sp, #-0x30]!                    
02c8ef20: stp     x22, x21, [sp, #0x10]                      
02c8ef24: stp     x20, x19, [sp, #0x20]                      
02c8ef28: adrp    x23, #0x662f000                            
02c8ef2c: adrp    x22, #0x6265000                            
02c8ef30: mov     x19, x3                                    
02c8ef34: ldrb    w8, [x23, #0x9b2]                          
02c8ef38: ldr     x22, [x22, #0x438]                         S:'REWARD SHOW FAILED'
02c8ef3c: mov     x20, x2                                    
02c8ef40: mov     x21, x0                                    
02c8ef44: tbnz    w8, #0, #0x2c8ef5c                         
02c8ef48: adrp    x0, #0x6265000                             
02c8ef4c: ldr     x0, [x0, #0x438]                           S:'REWARD SHOW FAILED'
02c8ef50: bl      #0x2b70db0                                 fn_2b70db0
02c8ef54: mov     w8, #1                                     
02c8ef58: strb    w8, [x23, #0x9b2]                          
02c8ef5c: mov     x0, x21                                    
02c8ef60: mov     x2, x20                                    
02c8ef64: mov     x3, x19                                    
02c8ef68: bl      #0x2c8bfac                                 ApplovinEventBase::OnAdDisplayFailedEvent
02c8ef6c: ldr     x0, [x22]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c8ef70: mov     x1, xzr                                    
02c8ef74: bl      #0x2ca09f8                                 WLog::LogError
02c8ef78: ldp     x20, x19, [sp, #0x20]                      
02c8ef7c: ldp     x22, x21, [sp, #0x10]                      
02c8ef80: ldp     x30, x23, [sp], #0x30                      
02c8ef84: b       #0x2c8ede0                                 RewardApplovinControl::LoadRewarded
## OnAdLoadFailedEvent(string adUnitId, MaxSdkBase/ErrorInfo errorInfo) -> void
---- RewardApplovinControl::OnAdLoadFailedEvent 0x2c8ef88
02c8ef88: stp     x30, x19, [sp, #-0x10]!                    
02c8ef8c: mov     x19, x0                                    
02c8ef90: bl      #0x2c8bb74                                 ApplovinEventBase::OnAdLoadFailedEvent
02c8ef94: fmov    s0, #3.00000000                            
02c8ef98: mov     x0, x19                                    
02c8ef9c: bl      #0x2c8ee68                                 RewardApplovinControl::LoadRewardedAfterDelay
02c8efa0: mov     x1, x0                                     
02c8efa4: mov     x0, x19                                    
02c8efa8: mov     x2, xzr                                    
02c8efac: ldp     x30, x19, [sp], #0x10                      
02c8efb0: b       #0x5b389f0                                 UnityEngine.MonoBehaviour::StartCoroutine
## RewardedOnAdReceivedRewardEvent(string arg1, MaxSdkBase/Reward reward, MaxSdkBase/AdInfo info) -> void
---- RewardApplovinControl::RewardedOnAdReceivedRewardEvent 0x2c8efb4
02c8efb4: ldr     x8, [x0, #0x30]                            .rewardCompleted
02c8efb8: cbz     x8, #0x2c8efcc                             
02c8efbc: ldr     x0, [x8, #0x40]                            
02c8efc0: ldr     x1, [x8, #0x28]                            
02c8efc4: ldr     x2, [x8, #0x18]                            
02c8efc8: br      x2                                         
02c8efcc: ret                                                
## .ctor() -> void
---- RewardApplovinControl::.ctor 0x2c8efd0
02c8efd0: b       #0x2c8c870                                 ApplovinEventBase::.ctor
