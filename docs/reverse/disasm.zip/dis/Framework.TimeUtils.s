#### CLASS Framework.TimeUtils parent= object
## SecondsToTimeString(double seconds) -> string
---- Framework.TimeUtils::SecondsToTimeString 0x2cc28bc
02cc28bc: sub     sp, sp, #0x50                              
02cc28c0: str     d8, [sp, #0x20]                            
02cc28c4: str     x30, [sp, #0x28]                           
02cc28c8: stp     x22, x21, [sp, #0x30]                      
02cc28cc: stp     x20, x19, [sp, #0x40]                      
02cc28d0: fmov    d8, d0                                     
02cc28d4: adrp    x20, #0x662f000                            
02cc28d8: adrp    x19, #0x6265000                            
02cc28dc: ldrb    w8, [x20, #0xc2b]                          
02cc28e0: ldr     x19, [x19, #0xf98]                         T:System.TimeSpan
02cc28e4: tbnz    w8, #0, #0x2cc2908                         
02cc28e8: adrp    x0, #0x6265000                             
02cc28ec: ldr     x0, [x0, #0xf98]                           T:System.TimeSpan
02cc28f0: bl      #0x2b70db0                                 fn_2b70db0
02cc28f4: adrp    x0, #0x6267000                             
02cc28f8: ldr     x0, [x0, #0x150]                           S:'{0:00}:{1:00}:{2:00}'
02cc28fc: bl      #0x2b70db0                                 fn_2b70db0
02cc2900: mov     w8, #1                                     
02cc2904: strb    w8, [x20, #0xc2b]                          
02cc2908: ldr     x0, [x19]                                  M:AdsManager::<OnApplicationPause>b__26_0
02cc290c: adrp    x21, #0x6267000                            
02cc2910: ldr     w8, [x0, #0xe4]                            [62670e4]=0 f=0,0
02cc2914: ldr     x21, [x21, #0x150]                         S:'{0:00}:{1:00}:{2:00}'
02cc2918: str     xzr, [sp, #0x18]                           
02cc291c: cbnz    w8, #0x2cc2924                             
02cc2920: bl      #0x2b70f30                                 fn_2b70f30
02cc2924: fmov    d0, d8                                     
02cc2928: mov     x0, xzr                                    
02cc292c: bl      #0x4e29964                                 System.TimeSpan::FromSeconds
02cc2930: str     x0, [sp, #0x18]                            
02cc2934: add     x0, sp, #0x18                              
02cc2938: mov     x1, xzr                                    
02cc293c: bl      #0x4e293d4                                 System.TimeSpan::get_TotalHours
02cc2940: fcvtzs  w9, d0                                     
02cc2944: mov     w8, #0xaaab                                
02cc2948: mov     x11, #0x7ff0000000000000                   
02cc294c: movk    w8, #0x2aaa, lsl #16                       
02cc2950: fmov    d1, x11                                    
02cc2954: adrp    x22, #0x6263000                            
02cc2958: ldr     x22, [x22, #0x970]                         &6645c70(=0)
02cc295c: add     x1, sp, #0x14                              
02cc2960: smull   x8, w9, w8                                 
02cc2964: fcmp    d0, d1                                     
02cc2968: ldr     x0, [x22, #0x48]                           &6263098(=0)
02cc296c: lsr     x10, x8, #0x3f                             
02cc2970: asr     x8, x8, #0x22                              
02cc2974: add     w8, w8, w10                                
02cc2978: mov     w10, #0x18                                 
02cc297c: msub    w8, w8, w10, w9                            
02cc2980: mov     w9, #-8                                    
02cc2984: csel    w8, w9, w8, eq                             
02cc2988: str     w8, [sp, #0x14]                            
02cc298c: bl      #0x2b70f38                                 fn_2b70f38
02cc2990: mov     x19, x0                                    
02cc2994: add     x0, sp, #0x18                              
02cc2998: mov     x1, xzr                                    
02cc299c: bl      #0x4e29328                                 System.TimeSpan::get_Minutes
02cc29a0: ldr     x8, [x22, #0x48]                           &6263098(=0)
02cc29a4: str     w0, [sp, #0x10]                            
02cc29a8: add     x1, sp, #0x10                              
02cc29ac: mov     x0, x8                                     
02cc29b0: bl      #0x2b70f38                                 fn_2b70f38
02cc29b4: mov     x20, x0                                    
02cc29b8: add     x0, sp, #0x18                              
02cc29bc: mov     x1, xzr                                    
02cc29c0: bl      #0x4e29370                                 System.TimeSpan::get_Seconds
02cc29c4: ldr     x8, [x22, #0x48]                           &6263098(=0)
02cc29c8: str     w0, [sp, #0xc]                             
02cc29cc: add     x1, sp, #0xc                               
02cc29d0: mov     x0, x8                                     
02cc29d4: bl      #0x2b70f38                                 fn_2b70f38
02cc29d8: ldr     x8, [x21]                                  S:'didu'
02cc29dc: mov     x3, x0                                     
02cc29e0: mov     x1, x19                                    
02cc29e4: mov     x2, x20                                    
02cc29e8: mov     x4, xzr                                    
02cc29ec: mov     x0, x8                                     
02cc29f0: bl      #0x4ca7764                                 System.String::Format
02cc29f4: ldp     x20, x19, [sp, #0x40]                      
02cc29f8: ldr     x30, [sp, #0x28]                           
02cc29fc: ldp     x22, x21, [sp, #0x30]                      
02cc2a00: ldr     d8, [sp, #0x20]                            
02cc2a04: add     sp, sp, #0x50                              
02cc2a08: ret                                                
## GetCurrentTime(bool utc) -> System.DateTime
---- Framework.TimeUtils::GetCurrentTime 0x2cc2a0c
02cc2a0c: stp     x30, x21, [sp, #-0x20]!                    
02cc2a10: stp     x20, x19, [sp, #0x10]                      
02cc2a14: adrp    x20, #0x662f000                            
02cc2a18: adrp    x21, #0x6266000                            
02cc2a1c: mov     w19, w0                                    
02cc2a20: ldrb    w8, [x20, #0xc2c]                          
02cc2a24: ldr     x21, [x21, #0x128]                         T:System.DateTime
02cc2a28: tbnz    w8, #0, #0x2cc2a40                         
02cc2a2c: adrp    x0, #0x6266000                             
02cc2a30: ldr     x0, [x0, #0x128]                           T:System.DateTime
02cc2a34: bl      #0x2b70db0                                 fn_2b70db0
02cc2a38: mov     w8, #1                                     
02cc2a3c: strb    w8, [x20, #0xc2c]                          
02cc2a40: ldr     x0, [x21]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cc2a44: ldr     w8, [x0, #0xe4]                            [62660e4]=0 f=0,0
02cc2a48: tbz     w19, #0, #0x2cc2a64                        
02cc2a4c: cbnz    w8, #0x2cc2a54                             
02cc2a50: bl      #0x2b70f30                                 fn_2b70f30
02cc2a54: ldp     x20, x19, [sp, #0x10]                      
02cc2a58: mov     x0, xzr                                    
02cc2a5c: ldp     x30, x21, [sp], #0x20                      
02cc2a60: b       #0x4df26f0                                 System.DateTime::get_UtcNow
02cc2a64: cbnz    w8, #0x2cc2a6c                             
02cc2a68: bl      #0x2b70f30                                 fn_2b70f30
02cc2a6c: ldp     x20, x19, [sp, #0x10]                      
02cc2a70: mov     x0, xzr                                    
02cc2a74: ldp     x30, x21, [sp], #0x20                      
02cc2a78: b       #0x4df25c8                                 System.DateTime::get_Now
## GetCurrentTimeSpan(bool utc) -> System.TimeSpan
---- Framework.TimeUtils::GetCurrentTimeSpan 0x2cc2a7c
02cc2a7c: sub     sp, sp, #0x30                              
02cc2a80: stp     x30, x21, [sp, #0x10]                      
02cc2a84: stp     x20, x19, [sp, #0x20]                      
02cc2a88: adrp    x21, #0x662f000                            
02cc2a8c: adrp    x20, #0x6266000                            
02cc2a90: mov     w19, w0                                    
02cc2a94: ldrb    w8, [x21, #0xc2d]                          
02cc2a98: ldr     x20, [x20, #0x128]                         T:System.DateTime
02cc2a9c: tbnz    w8, #0, #0x2cc2ab4                         
02cc2aa0: adrp    x0, #0x6266000                             
02cc2aa4: ldr     x0, [x0, #0x128]                           T:System.DateTime
02cc2aa8: bl      #0x2b70db0                                 fn_2b70db0
02cc2aac: mov     w8, #1                                     
02cc2ab0: strb    w8, [x21, #0xc2d]                          
02cc2ab4: and     w0, w19, #1                                
02cc2ab8: str     xzr, [sp, #8]                              
02cc2abc: bl      #0x2cc2a0c                                 Framework.TimeUtils::GetCurrentTime
02cc2ac0: ldr     x8, [x20]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cc2ac4: str     x0, [sp, #8]                               
02cc2ac8: ldr     w9, [x8, #0xe4]                            
02cc2acc: cbnz    w9, #0x2cc2adc                             
02cc2ad0: mov     x0, x8                                     
02cc2ad4: bl      #0x2b70f30                                 fn_2b70f30
02cc2ad8: ldr     x8, [x20]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cc2adc: ldr     x8, [x8, #0xb8]                            
02cc2ae0: add     x0, sp, #8                                 
02cc2ae4: mov     x2, xzr                                    
02cc2ae8: ldr     x1, [x8, #0x10]                            
02cc2aec: bl      #0x4df31e4                                 System.DateTime::Subtract
02cc2af0: ldp     x20, x19, [sp, #0x20]                      
02cc2af4: ldp     x30, x21, [sp, #0x10]                      
02cc2af8: add     sp, sp, #0x30                              
02cc2afc: ret                                                
## FromEpochTime(long sec) -> System.DateTime
---- Framework.TimeUtils::FromEpochTime 0x2cc2b00
02cc2b00: sub     sp, sp, #0x40                              
02cc2b04: stp     x30, x21, [sp, #0x20]                      
02cc2b08: stp     x20, x19, [sp, #0x30]                      
02cc2b0c: adrp    x21, #0x662f000                            
02cc2b10: adrp    x20, #0x6266000                            
02cc2b14: mov     x19, x0                                    
02cc2b18: ldrb    w8, [x21, #0xc2e]                          
02cc2b1c: ldr     x20, [x20, #0x128]                         T:System.DateTime
02cc2b20: tbnz    w8, #0, #0x2cc2b38                         
02cc2b24: adrp    x0, #0x6266000                             
02cc2b28: ldr     x0, [x0, #0x128]                           T:System.DateTime
02cc2b2c: bl      #0x2b70db0                                 fn_2b70db0
02cc2b30: mov     w8, #1                                     
02cc2b34: strb    w8, [x21, #0xc2e]                          
02cc2b38: mov     w4, wzr                                    
02cc2b3c: mov     w5, wzr                                    
02cc2b40: mov     w6, wzr                                    
02cc2b44: mov     w7, wzr                                    
02cc2b48: mov     w8, #1                                     
02cc2b4c: add     x0, sp, #0x10                              
02cc2b50: mov     w1, #0x7b2                                 
02cc2b54: mov     w2, #1                                     
02cc2b58: mov     w3, #1                                     
02cc2b5c: stp     xzr, xzr, [sp, #0x10]                      
02cc2b60: str     xzr, [sp, #8]                              
02cc2b64: str     w8, [sp]                                   
02cc2b68: bl      #0x4df0580                                 System.DateTime::.ctor
02cc2b6c: ldr     x0, [x20]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cc2b70: ldr     x8, [sp, #0x10]                            
02cc2b74: ldr     w9, [x0, #0xe4]                            [62660e4]=0 f=0,0
02cc2b78: str     x8, [sp, #0x18]                            
02cc2b7c: cbnz    w9, #0x2cc2b84                             
02cc2b80: bl      #0x2b70f30                                 fn_2b70f30
02cc2b84: scvtf   d0, x19                                    
02cc2b88: add     x0, sp, #0x18                              
02cc2b8c: mov     x1, xzr                                    
02cc2b90: bl      #0x4df15f0                                 System.DateTime::AddSeconds
02cc2b94: ldp     x20, x19, [sp, #0x30]                      
02cc2b98: ldp     x30, x21, [sp, #0x20]                      
02cc2b9c: add     sp, sp, #0x40                              
02cc2ba0: ret                                                
## ToEpochTime(System.DateTime time) -> long
---- Framework.TimeUtils::ToEpochTime 0x2cc2ba4
02cc2ba4: sub     sp, sp, #0x40                              
02cc2ba8: stp     x30, x21, [sp, #0x20]                      
02cc2bac: stp     x20, x19, [sp, #0x30]                      
02cc2bb0: adrp    x20, #0x662f000                            
02cc2bb4: adrp    x21, #0x6266000                            
02cc2bb8: mov     x19, x0                                    
02cc2bbc: ldrb    w8, [x20, #0xc2f]                          
02cc2bc0: ldr     x21, [x21, #0x128]                         T:System.DateTime
02cc2bc4: tbnz    w8, #0, #0x2cc2be8                         
02cc2bc8: adrp    x0, #0x6266000                             
02cc2bcc: ldr     x0, [x0, #0x128]                           T:System.DateTime
02cc2bd0: bl      #0x2b70db0                                 fn_2b70db0
02cc2bd4: adrp    x0, #0x6265000                             
02cc2bd8: ldr     x0, [x0, #0xf98]                           T:System.TimeSpan
02cc2bdc: bl      #0x2b70db0                                 fn_2b70db0
02cc2be0: mov     w8, #1                                     
02cc2be4: strb    w8, [x20, #0xc2f]                          
02cc2be8: adrp    x20, #0x6265000                            
02cc2bec: mov     w4, wzr                                    
02cc2bf0: mov     w5, wzr                                    
02cc2bf4: ldr     x20, [x20, #0xf98]                         T:System.TimeSpan
02cc2bf8: mov     w6, wzr                                    
02cc2bfc: mov     w7, wzr                                    
02cc2c00: mov     w8, #1                                     
02cc2c04: add     x0, sp, #0x10                              
02cc2c08: mov     w1, #0x7b2                                 
02cc2c0c: mov     w2, #1                                     
02cc2c10: mov     w3, #1                                     
02cc2c14: stp     xzr, xzr, [sp, #0x10]                      
02cc2c18: str     xzr, [sp, #8]                              
02cc2c1c: str     w8, [sp]                                   
02cc2c20: bl      #0x4df0580                                 System.DateTime::.ctor
02cc2c24: ldr     x0, [x21]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cc2c28: ldr     w8, [x0, #0xe4]                            [62650e4]=0 f=0,0
02cc2c2c: cbnz    w8, #0x2cc2c34                             
02cc2c30: bl      #0x2b70f30                                 fn_2b70f30
02cc2c34: ldr     x1, [sp, #0x10]                            
02cc2c38: mov     x0, x19                                    
02cc2c3c: mov     x2, xzr                                    
02cc2c40: bl      #0x4df3fb4                                 System.DateTime::op_Subtraction
02cc2c44: ldr     x8, [x20]                                  M:AdsManager::<OnApplicationPause>b__26_0
02cc2c48: str     x0, [sp, #0x18]                            
02cc2c4c: ldr     w9, [x8, #0xe4]                            
02cc2c50: cbnz    w9, #0x2cc2c5c                             
02cc2c54: mov     x0, x8                                     
02cc2c58: bl      #0x2b70f30                                 fn_2b70f30
02cc2c5c: add     x0, sp, #0x18                              
02cc2c60: mov     x1, xzr                                    
02cc2c64: bl      #0x4e2943c                                 System.TimeSpan::get_TotalSeconds
02cc2c68: mov     x8, #0x7ff0000000000000                    
02cc2c6c: fcvtzs  x9, d0                                     
02cc2c70: fmov    d1, x8                                     
02cc2c74: ldp     x20, x19, [sp, #0x30]                      
02cc2c78: ldp     x30, x21, [sp, #0x20]                      
02cc2c7c: mov     x8, #-0x8000000000000000                   
02cc2c80: fcmp    d0, d1                                     
02cc2c84: csel    x0, x8, x9, eq                             
02cc2c88: add     sp, sp, #0x40                              
02cc2c8c: ret                                                
## .ctor() -> void
---- Framework.TimeUtils::.ctor 0x2cc2c90
02cc2c90: mov     x1, xzr                                    
02cc2c94: b       #0x4e53e9c                                 System.Object::.ctor
