#### CLASS CharmGame.CountDownStartStream/<>c__DisplayClass4_0 parent= object
#   field <>4__this                      CharmGame.CountDownStartStream                     off=0x10 attr=6 
#   field onDone                         System.Action                                      off=0x18 attr=6 
## .ctor() -> void
---- CharmGame.CountDownStartStream/<>c__DisplayClass4_0::.ctor 0x2d1d854
02d1d854: mov     x1, xzr                                    
02d1d858: b       #0x4e53e9c                                 System.Object::.ctor
## <StartCountDown>b__0() -> void
---- CharmGame.CountDownStartStream/<>c__DisplayClass4_0::<StartCountDown>b__0 0x2d1d864
02d1d864: str     x30, [sp, #-0x20]!                         
02d1d868: stp     x20, x19, [sp, #0x10]                      
02d1d86c: adrp    x20, #0x6630000                            
02d1d870: mov     x19, x0                                    
02d1d874: ldrb    w8, [x20, #0x27]                           
02d1d878: tbnz    w8, #0, #0x2d1d890                         
02d1d87c: adrp    x0, #0x6265000                             
02d1d880: ldr     x0, [x0, #0xa98]                           S:'3'
02d1d884: bl      #0x2b70db0                                 fn_2b70db0
02d1d888: mov     w8, #1                                     
02d1d88c: strb    w8, [x20, #0x27]                           
02d1d890: ldr     x8, [x19, #0x10]                           .<>4__this
02d1d894: cbz     x8, #0x2d1d8c4                             
02d1d898: ldr     x0, [x8, #0x20]                            
02d1d89c: cbz     x0, #0x2d1d8c4                             
02d1d8a0: adrp    x8, #0x6265000                             
02d1d8a4: ldr     x8, [x8, #0xa98]                           S:'3'
02d1d8a8: ldr     x9, [x0]                                   M:AdsManager::<OnApplicationPause>b__26_0
02d1d8ac: ldp     x20, x19, [sp, #0x10]                      
02d1d8b0: ldr     x1, [x8]                                   M:AdsManager::<OnApplicationPause>b__26_0
02d1d8b4: ldr     x2, [x9, #0x560]                           
02d1d8b8: ldr     x3, [x9, #0x558]                           
02d1d8bc: ldr     x30, [sp], #0x20                           
02d1d8c0: br      x3                                         
02d1d8c4: bl      #0x2b7105c                                 fn_2b7105c
## <StartCountDown>b__1() -> void
---- CharmGame.CountDownStartStream/<>c__DisplayClass4_0::<StartCountDown>b__1 0x2d1d8c8
02d1d8c8: str     x30, [sp, #-0x20]!                         
02d1d8cc: stp     x20, x19, [sp, #0x10]                      
02d1d8d0: adrp    x20, #0x6630000                            
02d1d8d4: mov     x19, x0                                    
02d1d8d8: ldrb    w8, [x20, #0x28]                           
02d1d8dc: tbnz    w8, #0, #0x2d1d8f4                         
02d1d8e0: adrp    x0, #0x6269000                             
02d1d8e4: ldr     x0, [x0, #0xcd0]                           S:'2'
02d1d8e8: bl      #0x2b70db0                                 fn_2b70db0
02d1d8ec: mov     w8, #1                                     
02d1d8f0: strb    w8, [x20, #0x28]                           
02d1d8f4: ldr     x8, [x19, #0x10]                           .<>4__this
02d1d8f8: cbz     x8, #0x2d1d928                             
02d1d8fc: ldr     x0, [x8, #0x20]                            
02d1d900: cbz     x0, #0x2d1d928                             
02d1d904: adrp    x8, #0x6269000                             
02d1d908: ldr     x8, [x8, #0xcd0]                           S:'2'
02d1d90c: ldr     x9, [x0]                                   T:Trading.TradingSession/<>c__DisplayClass56_0
02d1d910: ldp     x20, x19, [sp, #0x10]                      
02d1d914: ldr     x1, [x8]                                   T:Trading.TradingSession/<>c__DisplayClass56_0
02d1d918: ldr     x2, [x9, #0x560]                           
02d1d91c: ldr     x3, [x9, #0x558]                           
02d1d920: ldr     x30, [sp], #0x20                           
02d1d924: br      x3                                         
02d1d928: bl      #0x2b7105c                                 fn_2b7105c
## <StartCountDown>b__2() -> void
---- CharmGame.CountDownStartStream/<>c__DisplayClass4_0::<StartCountDown>b__2 0x2d1d92c
02d1d92c: str     x30, [sp, #-0x20]!                         
02d1d930: stp     x20, x19, [sp, #0x10]                      
02d1d934: adrp    x20, #0x6630000                            
02d1d938: mov     x19, x0                                    
02d1d93c: ldrb    w8, [x20, #0x29]                           
02d1d940: tbnz    w8, #0, #0x2d1d958                         
02d1d944: adrp    x0, #0x6268000                             
02d1d948: ldr     x0, [x0, #0x148]                           S:'1'
02d1d94c: bl      #0x2b70db0                                 fn_2b70db0
02d1d950: mov     w8, #1                                     
02d1d954: strb    w8, [x20, #0x29]                           
02d1d958: ldr     x8, [x19, #0x10]                           .<>4__this
02d1d95c: cbz     x8, #0x2d1d98c                             
02d1d960: ldr     x0, [x8, #0x20]                            
02d1d964: cbz     x0, #0x2d1d98c                             
02d1d968: adrp    x8, #0x6268000                             
02d1d96c: ldr     x8, [x8, #0x148]                           S:'1'
02d1d970: ldr     x9, [x0]                                   S:'{0}/2'
02d1d974: ldp     x20, x19, [sp, #0x10]                      
02d1d978: ldr     x1, [x8]                                   S:'{0}/2'
02d1d97c: ldr     x2, [x9, #0x560]                           
02d1d980: ldr     x3, [x9, #0x558]                           
02d1d984: ldr     x30, [sp], #0x20                           
02d1d988: br      x3                                         
02d1d98c: bl      #0x2b7105c                                 fn_2b7105c
## <StartCountDown>b__3() -> void
---- CharmGame.CountDownStartStream/<>c__DisplayClass4_0::<StartCountDown>b__3 0x2d1d990
02d1d990: stp     x30, x19, [sp, #-0x10]!                    
02d1d994: ldr     x8, [x0, #0x18]                            .onDone
02d1d998: mov     x19, x0                                    
02d1d99c: cbz     x8, #0x2d1d9b0                             
02d1d9a0: ldr     x9, [x8, #0x18]                            
02d1d9a4: ldr     x0, [x8, #0x40]                            
02d1d9a8: ldr     x1, [x8, #0x28]                            
02d1d9ac: blr     x9                                         
02d1d9b0: ldr     x8, [x19, #0x10]                           .<>4__this
02d1d9b4: cbz     x8, #0x2d1d9dc                             
02d1d9b8: ldr     x0, [x8, #0x20]                            
02d1d9bc: cbz     x0, #0x2d1d9dc                             
02d1d9c0: mov     x1, xzr                                    
02d1d9c4: bl      #0x5b339ec                                 UnityEngine.Component::get_gameObject
02d1d9c8: cbz     x0, #0x2d1d9dc                             
02d1d9cc: mov     w1, wzr                                    
02d1d9d0: mov     x2, xzr                                    
02d1d9d4: ldp     x30, x19, [sp], #0x10                      
02d1d9d8: b       #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d1d9dc: bl      #0x2b7105c                                 fn_2b7105c
#### CLASS CharmGame.CountDownStartStream parent= UnityEngine.MonoBehaviour
#   field _txtCountdown                  TMPro.TextMeshProUGUI                              off=0x20 attr=1 SerializeField
#   field _sequence                      DG.Tweening.Sequence                               off=0x28 attr=1 
## Awake() -> void
---- CharmGame.CountDownStartStream::Awake 0x2d1d260
02d1d260: str     x30, [sp, #-0x10]!                         
02d1d264: ldr     x0, [x0, #0x20]                            ._txtCountdown
02d1d268: cbz     x0, #0x2d1d288                             
02d1d26c: mov     x1, xzr                                    
02d1d270: bl      #0x5b339ec                                 UnityEngine.Component::get_gameObject
02d1d274: cbz     x0, #0x2d1d288                             
02d1d278: mov     w1, wzr                                    
02d1d27c: mov     x2, xzr                                    
02d1d280: ldr     x30, [sp], #0x10                           
02d1d284: b       #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d1d288: bl      #0x2b7105c                                 fn_2b7105c
## OnDestroy() -> void
---- CharmGame.CountDownStartStream::OnDestroy 0x2d1d28c
02d1d28c: ldr     x0, [x0, #0x28]                            ._sequence
02d1d290: cbz     x0, #0x2d1d2a0                             
02d1d294: mov     w1, wzr                                    
02d1d298: mov     x2, xzr                                    
02d1d29c: b       #0x2d8fe94                                 DG.Tweening.TweenExtensions::Kill
02d1d2a0: ret                                                
## StartCountDown(System.Action onDone) -> void
---- CharmGame.CountDownStartStream::StartCountDown 0x2d1d2a4
02d1d2a4: str     d10, [sp, #-0x60]!                         
02d1d2a8: stp     d9, d8, [sp, #0x10]                        
02d1d2ac: stp     x30, x25, [sp, #0x20]                      
02d1d2b0: stp     x24, x23, [sp, #0x30]                      
02d1d2b4: stp     x22, x21, [sp, #0x40]                      
02d1d2b8: stp     x20, x19, [sp, #0x50]                      
02d1d2bc: adrp    x20, #0x6630000                            
02d1d2c0: adrp    x22, #0x6269000                            
02d1d2c4: mov     x21, x1                                    
02d1d2c8: ldrb    w8, [x20, #0x26]                           
02d1d2cc: ldr     x22, [x22, #0xca8]                         T:CharmGame.CountDownStartStream/<>c__DisplayClass4_0
02d1d2d0: mov     x19, x0                                    
02d1d2d4: tbnz    w8, #0, #0x2d1d34c                         
02d1d2d8: adrp    x0, #0x6263000                             
02d1d2dc: ldr     x0, [x0, #0xfd0]                           T:DG.Tweening.DOTween
02d1d2e0: bl      #0x2b70db0                                 fn_2b70db0
02d1d2e4: adrp    x0, #0x6264000                             
02d1d2e8: ldr     x0, [x0, #0xe8]                            T:DG.Tweening.TweenCallback
02d1d2ec: bl      #0x2b70db0                                 fn_2b70db0
02d1d2f0: adrp    x0, #0x6264000                             
02d1d2f4: ldr     x0, [x0, #0x308]                           MS:DG.Tweening.TweenSettingsExtensions::SetEase
02d1d2f8: bl      #0x2b70db0                                 fn_2b70db0
02d1d2fc: adrp    x0, #0x6266000                             
02d1d300: ldr     x0, [x0, #0x880]                           MS:DG.Tweening.TweenSettingsExtensions::SetEase
02d1d304: bl      #0x2b70db0                                 fn_2b70db0
02d1d308: adrp    x0, #0x6269000                             
02d1d30c: ldr     x0, [x0, #0xcb0]                           M:CharmGame.CountDownStartStream/<>c__DisplayClass4_0::<StartCountDown>b__0
02d1d310: bl      #0x2b70db0                                 fn_2b70db0
02d1d314: adrp    x0, #0x6269000                             
02d1d318: ldr     x0, [x0, #0xcb8]                           M:CharmGame.CountDownStartStream/<>c__DisplayClass4_0::<StartCountDown>b__1
02d1d31c: bl      #0x2b70db0                                 fn_2b70db0
02d1d320: adrp    x0, #0x6269000                             
02d1d324: ldr     x0, [x0, #0xcc0]                           M:CharmGame.CountDownStartStream/<>c__DisplayClass4_0::<StartCountDown>b__2
02d1d328: bl      #0x2b70db0                                 fn_2b70db0
02d1d32c: adrp    x0, #0x6269000                             
02d1d330: ldr     x0, [x0, #0xcc8]                           M:CharmGame.CountDownStartStream/<>c__DisplayClass4_0::<StartCountDown>b__3
02d1d334: bl      #0x2b70db0                                 fn_2b70db0
02d1d338: adrp    x0, #0x6269000                             
02d1d33c: ldr     x0, [x0, #0xca8]                           T:CharmGame.CountDownStartStream/<>c__DisplayClass4_0
02d1d340: bl      #0x2b70db0                                 fn_2b70db0
02d1d344: mov     w8, #1                                     
02d1d348: strb    w8, [x20, #0x26]                           
02d1d34c: ldr     x0, [x22]                                  T:Trading.TradingSession/<>c__DisplayClass56_0
02d1d350: bl      #0x2b7104c                                 fn_2b7104c
02d1d354: mov     x1, xzr                                    
02d1d358: mov     x20, x0                                    
02d1d35c: bl      #0x4e53e9c                                 System.Object::.ctor
02d1d360: cbz     x20, #0x2d1d850                            
02d1d364: mov     x0, x20                                    
02d1d368: mov     x1, x19                                    
02d1d36c: str     x19, [x0, #0x10]!                          
02d1d370: bl      #0x2b70d54                                 fn_2b70d54
02d1d374: mov     x0, x20                                    
02d1d378: mov     x1, x21                                    
02d1d37c: str     x21, [x0, #0x18]!                          
02d1d380: bl      #0x2b70d54                                 fn_2b70d54
02d1d384: mov     x21, x19                                   
02d1d388: ldr     x0, [x21, #0x28]!                          ._sequence
02d1d38c: cbz     x0, #0x2d1d39c                             
02d1d390: mov     w1, wzr                                    
02d1d394: mov     x2, xzr                                    
02d1d398: bl      #0x2d8fe94                                 DG.Tweening.TweenExtensions::Kill
02d1d39c: ldr     x0, [x19, #0x20]                           ._txtCountdown
02d1d3a0: cbz     x0, #0x2d1d850                             
02d1d3a4: mov     x1, xzr                                    
02d1d3a8: bl      #0x5a7845c                                 TMPro.TMP_Text::get_transform
02d1d3ac: mov     w1, wzr                                    
02d1d3b0: mov     x2, xzr                                    
02d1d3b4: bl      #0x2d9d5d0                                 DG.Tweening.ShortcutExtensions::DOKill
02d1d3b8: ldr     x0, [x19, #0x20]                           ._txtCountdown
02d1d3bc: mov     w1, wzr                                    
02d1d3c0: mov     x2, xzr                                    
02d1d3c4: bl      #0x2d9d5d0                                 DG.Tweening.ShortcutExtensions::DOKill
02d1d3c8: ldr     x0, [x19, #0x20]                           ._txtCountdown
02d1d3cc: cbz     x0, #0x2d1d850                             
02d1d3d0: mov     x1, xzr                                    
02d1d3d4: bl      #0x5a7845c                                 TMPro.TMP_Text::get_transform
02d1d3d8: adrp    x23, #0x662f000                            
02d1d3dc: mov     x22, x0                                    
02d1d3e0: ldrb    w8, [x23, #0xa74]                          
02d1d3e4: cbnz    w8, #0x2d1d3fc                             
02d1d3e8: adrp    x0, #0x6264000                             
02d1d3ec: ldr     x0, [x0, #0xd8]                            T:UnityEngine.Vector3
02d1d3f0: bl      #0x2b70db0                                 fn_2b70db0
02d1d3f4: mov     w8, #1                                     
02d1d3f8: strb    w8, [x23, #0xa74]                          
02d1d3fc: cbz     x22, #0x2d1d850                            
02d1d400: adrp    x8, #0x6264000                             
02d1d404: mov     x0, x22                                    
02d1d408: mov     x1, xzr                                    
02d1d40c: ldr     x8, [x8, #0xd8]                            T:UnityEngine.Vector3
02d1d410: ldr     x8, [x8]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d1d414: ldr     x8, [x8, #0xb8]                            MS:DG.Tweening.Core.Extensions::SetSpecialStartupMode
02d1d418: ldp     s1, s2, [x8, #0x10]                        
02d1d41c: ldr     s0, [x8, #0xc]                             [626400c]=0 f=0,0
02d1d420: bl      #0x5b470cc                                 UnityEngine.Transform::set_localScale
02d1d424: movi    d0, #0000000000000000                      
02d1d428: movi    d1, #0000000000000000                      
02d1d42c: ldr     x0, [x19, #0x20]                           ._txtCountdown
02d1d430: mov     x1, xzr                                    
02d1d434: bl      #0x2c78678                                 DG.Tweening.DOTweenModuleUI::DOFade
02d1d438: ldr     x0, [x19, #0x20]                           ._txtCountdown
02d1d43c: cbz     x0, #0x2d1d850                             
02d1d440: mov     x1, xzr                                    
02d1d444: bl      #0x5b339ec                                 UnityEngine.Component::get_gameObject
02d1d448: cbz     x0, #0x2d1d850                             
02d1d44c: adrp    x24, #0x6263000                            
02d1d450: adrp    x23, #0x6264000                            
02d1d454: adrp    x22, #0x6269000                            
02d1d458: ldr     x24, [x24, #0xfd0]                         T:DG.Tweening.DOTween
02d1d45c: ldr     x23, [x23, #0xe8]                          T:DG.Tweening.TweenCallback
02d1d460: ldr     x22, [x22, #0xcb0]                         M:CharmGame.CountDownStartStream/<>c__DisplayClass4_0::<StartCountDown>b__0
02d1d464: mov     w1, #1                                     
02d1d468: mov     x2, xzr                                    
02d1d46c: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d1d470: ldr     x0, [x24]                                  &2c5bbd4(=a9bd7bfdd503233f)
02d1d474: ldr     w8, [x0, #0xe4]                            [62640e4]=0 f=0,0
02d1d478: cbnz    w8, #0x2d1d480                             
02d1d47c: bl      #0x2b70f30                                 fn_2b70f30
02d1d480: mov     x0, xzr                                    
02d1d484: bl      #0x2d8cfe8                                 DG.Tweening.DOTween::Sequence
02d1d488: mov     x1, x0                                     
02d1d48c: str     x0, [x19, #0x28]                           ._sequence
02d1d490: mov     x0, x21                                    
02d1d494: bl      #0x2b70d54                                 fn_2b70d54
02d1d498: ldr     x0, [x23]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d1d49c: ldr     x21, [x19, #0x28]                          ._sequence
02d1d4a0: bl      #0x2b7104c                                 fn_2b7104c
02d1d4a4: ldr     x2, [x22]                                  T:Trading.TradingSession/<>c__DisplayClass56_0
02d1d4a8: mov     x1, x20                                    
02d1d4ac: mov     x3, xzr                                    
02d1d4b0: mov     x22, x0                                    
02d1d4b4: bl      #0x2d89dc4                                 DG.Tweening.TweenCallback::.ctor
02d1d4b8: mov     x0, x21                                    
02d1d4bc: mov     x1, x22                                    
02d1d4c0: mov     x2, xzr                                    
02d1d4c4: bl      #0x2da03d8                                 DG.Tweening.TweenSettingsExtensions::AppendCallback
02d1d4c8: ldr     x0, [x19, #0x20]                           ._txtCountdown
02d1d4cc: cbz     x0, #0x2d1d850                             
02d1d4d0: adrp    x25, #0x6266000                            
02d1d4d4: adrp    x24, #0x6264000                            
02d1d4d8: mov     x1, xzr                                    
02d1d4dc: ldr     x25, [x25, #0x880]                         MS:DG.Tweening.TweenSettingsExtensions::SetEase
02d1d4e0: ldr     x24, [x24, #0x308]                         MS:DG.Tweening.TweenSettingsExtensions::SetEase
02d1d4e4: ldr     x21, [x19, #0x28]                          ._sequence
02d1d4e8: bl      #0x5a7845c                                 TMPro.TMP_Text::get_transform
02d1d4ec: adrp    x8, #0x1084000                             
02d1d4f0: adrp    x9, #0x1084000                             
02d1d4f4: mov     x1, xzr                                    
02d1d4f8: ldr     s10, [x8, #0xcf4]                          [1084cf4]=431d80003f99999a f=1.2,157.5
02d1d4fc: ldr     s8, [x9, #0xdfc]                           [1084dfc]=3f2666663d4ccccd f=0.05,0.65
02d1d500: fmov    s0, s10                                    
02d1d504: fmov    s1, s8                                     
02d1d508: bl      #0x2d98c98                                 DG.Tweening.ShortcutExtensions::DOScale
02d1d50c: ldr     x2, [x25]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d1d510: mov     w1, #1                                     
02d1d514: bl      #0x336fa0c                                 fn_336fa0c
02d1d518: mov     x1, x0                                     
02d1d51c: mov     x0, x21                                    
02d1d520: mov     x2, xzr                                    
02d1d524: bl      #0x2d9b0a8                                 DG.Tweening.TweenSettingsExtensions::Append
02d1d528: fmov    s1, s8                                     
02d1d52c: ldp     x0, x21, [x19, #0x20]                      ._txtCountdown
02d1d530: fmov    s0, #1.00000000                            
02d1d534: mov     x1, xzr                                    
02d1d538: bl      #0x2c78678                                 DG.Tweening.DOTweenModuleUI::DOFade
02d1d53c: ldr     x2, [x24]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d1d540: mov     w1, #1                                     
02d1d544: bl      #0x336fa0c                                 fn_336fa0c
02d1d548: mov     x1, x0                                     
02d1d54c: mov     x0, x21                                    
02d1d550: mov     x2, xzr                                    
02d1d554: bl      #0x2d9b0ec                                 DG.Tweening.TweenSettingsExtensions::Join
02d1d558: ldr     x0, [x19, #0x20]                           ._txtCountdown
02d1d55c: cbz     x0, #0x2d1d850                             
02d1d560: adrp    x22, #0x6269000                            
02d1d564: mov     x1, xzr                                    
02d1d568: ldr     x22, [x22, #0xcb8]                         M:CharmGame.CountDownStartStream/<>c__DisplayClass4_0::<StartCountDown>b__1
02d1d56c: ldr     x21, [x19, #0x28]                          ._sequence
02d1d570: bl      #0x5a7845c                                 TMPro.TMP_Text::get_transform
02d1d574: adrp    x8, #0x1084000                             
02d1d578: fmov    s0, #1.00000000                            
02d1d57c: mov     x1, xzr                                    
02d1d580: ldr     s9, [x8, #0xddc]                           [1084ddc]=c77fe0003f733333 f=0.95,-65504
02d1d584: fmov    s1, s9                                     
02d1d588: bl      #0x2d98c98                                 DG.Tweening.ShortcutExtensions::DOScale
02d1d58c: ldr     x2, [x25]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d1d590: mov     w1, #1                                     
02d1d594: bl      #0x336fa0c                                 fn_336fa0c
02d1d598: mov     x1, x0                                     
02d1d59c: mov     x0, x21                                    
02d1d5a0: mov     x2, xzr                                    
02d1d5a4: bl      #0x2d9b0a8                                 DG.Tweening.TweenSettingsExtensions::Append
02d1d5a8: movi    d0, #0000000000000000                      
02d1d5ac: fmov    s1, s9                                     
02d1d5b0: mov     x1, xzr                                    
02d1d5b4: ldp     x0, x21, [x19, #0x20]                      ._txtCountdown
02d1d5b8: bl      #0x2c78678                                 DG.Tweening.DOTweenModuleUI::DOFade
02d1d5bc: ldr     x2, [x24]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d1d5c0: mov     w1, #1                                     
02d1d5c4: bl      #0x336fa0c                                 fn_336fa0c
02d1d5c8: mov     x1, x0                                     
02d1d5cc: mov     x0, x21                                    
02d1d5d0: mov     x2, xzr                                    
02d1d5d4: bl      #0x2d9b0ec                                 DG.Tweening.TweenSettingsExtensions::Join
02d1d5d8: ldr     x0, [x23]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d1d5dc: ldr     x21, [x19, #0x28]                          ._sequence
02d1d5e0: bl      #0x2b7104c                                 fn_2b7104c
02d1d5e4: ldr     x2, [x22]                                  T:Trading.TradingSession/<>c__DisplayClass56_0
02d1d5e8: mov     x1, x20                                    
02d1d5ec: mov     x3, xzr                                    
02d1d5f0: mov     x22, x0                                    
02d1d5f4: bl      #0x2d89dc4                                 DG.Tweening.TweenCallback::.ctor
02d1d5f8: mov     x0, x21                                    
02d1d5fc: mov     x1, x22                                    
02d1d600: mov     x2, xzr                                    
02d1d604: bl      #0x2da03d8                                 DG.Tweening.TweenSettingsExtensions::AppendCallback
02d1d608: ldr     x0, [x19, #0x20]                           ._txtCountdown
02d1d60c: cbz     x0, #0x2d1d850                             
02d1d610: ldr     x21, [x19, #0x28]                          ._sequence
02d1d614: mov     x1, xzr                                    
02d1d618: bl      #0x5a7845c                                 TMPro.TMP_Text::get_transform
02d1d61c: fmov    s0, s10                                    
02d1d620: fmov    s1, s8                                     
02d1d624: mov     x1, xzr                                    
02d1d628: bl      #0x2d98c98                                 DG.Tweening.ShortcutExtensions::DOScale
02d1d62c: ldr     x2, [x25]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d1d630: mov     w1, #1                                     
02d1d634: bl      #0x336fa0c                                 fn_336fa0c
02d1d638: mov     x1, x0                                     
02d1d63c: mov     x0, x21                                    
02d1d640: mov     x2, xzr                                    
02d1d644: bl      #0x2d9b0a8                                 DG.Tweening.TweenSettingsExtensions::Append
02d1d648: fmov    s1, s8                                     
02d1d64c: ldp     x0, x21, [x19, #0x20]                      ._txtCountdown
02d1d650: fmov    s0, #1.00000000                            
02d1d654: mov     x1, xzr                                    
02d1d658: bl      #0x2c78678                                 DG.Tweening.DOTweenModuleUI::DOFade
02d1d65c: ldr     x2, [x24]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d1d660: mov     w1, #1                                     
02d1d664: bl      #0x336fa0c                                 fn_336fa0c
02d1d668: mov     x1, x0                                     
02d1d66c: mov     x0, x21                                    
02d1d670: mov     x2, xzr                                    
02d1d674: bl      #0x2d9b0ec                                 DG.Tweening.TweenSettingsExtensions::Join
02d1d678: ldr     x0, [x19, #0x20]                           ._txtCountdown
02d1d67c: cbz     x0, #0x2d1d850                             
02d1d680: adrp    x22, #0x6269000                            
02d1d684: mov     x1, xzr                                    
02d1d688: ldr     x22, [x22, #0xcc0]                         M:CharmGame.CountDownStartStream/<>c__DisplayClass4_0::<StartCountDown>b__2
02d1d68c: ldr     x21, [x19, #0x28]                          ._sequence
02d1d690: bl      #0x5a7845c                                 TMPro.TMP_Text::get_transform
02d1d694: fmov    s1, s9                                     
02d1d698: fmov    s0, #1.00000000                            
02d1d69c: mov     x1, xzr                                    
02d1d6a0: bl      #0x2d98c98                                 DG.Tweening.ShortcutExtensions::DOScale
02d1d6a4: ldr     x2, [x25]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d1d6a8: mov     w1, #1                                     
02d1d6ac: bl      #0x336fa0c                                 fn_336fa0c
02d1d6b0: mov     x1, x0                                     
02d1d6b4: mov     x0, x21                                    
02d1d6b8: mov     x2, xzr                                    
02d1d6bc: bl      #0x2d9b0a8                                 DG.Tweening.TweenSettingsExtensions::Append
02d1d6c0: movi    d0, #0000000000000000                      
02d1d6c4: fmov    s1, s9                                     
02d1d6c8: mov     x1, xzr                                    
02d1d6cc: ldp     x0, x21, [x19, #0x20]                      ._txtCountdown
02d1d6d0: bl      #0x2c78678                                 DG.Tweening.DOTweenModuleUI::DOFade
02d1d6d4: ldr     x2, [x24]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d1d6d8: mov     w1, #1                                     
02d1d6dc: bl      #0x336fa0c                                 fn_336fa0c
02d1d6e0: mov     x1, x0                                     
02d1d6e4: mov     x0, x21                                    
02d1d6e8: mov     x2, xzr                                    
02d1d6ec: bl      #0x2d9b0ec                                 DG.Tweening.TweenSettingsExtensions::Join
02d1d6f0: ldr     x0, [x23]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d1d6f4: ldr     x21, [x19, #0x28]                          ._sequence
02d1d6f8: bl      #0x2b7104c                                 fn_2b7104c
02d1d6fc: ldr     x2, [x22]                                  T:Trading.TradingSession/<>c__DisplayClass56_0
02d1d700: mov     x1, x20                                    
02d1d704: mov     x3, xzr                                    
02d1d708: mov     x22, x0                                    
02d1d70c: bl      #0x2d89dc4                                 DG.Tweening.TweenCallback::.ctor
02d1d710: mov     x0, x21                                    
02d1d714: mov     x1, x22                                    
02d1d718: mov     x2, xzr                                    
02d1d71c: bl      #0x2da03d8                                 DG.Tweening.TweenSettingsExtensions::AppendCallback
02d1d720: ldr     x0, [x19, #0x20]                           ._txtCountdown
02d1d724: cbz     x0, #0x2d1d850                             
02d1d728: ldr     x21, [x19, #0x28]                          ._sequence
02d1d72c: mov     x1, xzr                                    
02d1d730: bl      #0x5a7845c                                 TMPro.TMP_Text::get_transform
02d1d734: fmov    s0, s10                                    
02d1d738: fmov    s1, s8                                     
02d1d73c: mov     x1, xzr                                    
02d1d740: bl      #0x2d98c98                                 DG.Tweening.ShortcutExtensions::DOScale
02d1d744: ldr     x2, [x25]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d1d748: mov     w1, #1                                     
02d1d74c: bl      #0x336fa0c                                 fn_336fa0c
02d1d750: mov     x1, x0                                     
02d1d754: mov     x0, x21                                    
02d1d758: mov     x2, xzr                                    
02d1d75c: bl      #0x2d9b0a8                                 DG.Tweening.TweenSettingsExtensions::Append
02d1d760: fmov    s1, s8                                     
02d1d764: ldp     x0, x21, [x19, #0x20]                      ._txtCountdown
02d1d768: fmov    s0, #1.00000000                            
02d1d76c: mov     x1, xzr                                    
02d1d770: bl      #0x2c78678                                 DG.Tweening.DOTweenModuleUI::DOFade
02d1d774: ldr     x2, [x24]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d1d778: mov     w1, #1                                     
02d1d77c: bl      #0x336fa0c                                 fn_336fa0c
02d1d780: mov     x1, x0                                     
02d1d784: mov     x0, x21                                    
02d1d788: mov     x2, xzr                                    
02d1d78c: bl      #0x2d9b0ec                                 DG.Tweening.TweenSettingsExtensions::Join
02d1d790: ldr     x0, [x19, #0x20]                           ._txtCountdown
02d1d794: cbz     x0, #0x2d1d850                             
02d1d798: adrp    x22, #0x6269000                            
02d1d79c: mov     x1, xzr                                    
02d1d7a0: ldr     x22, [x22, #0xcc8]                         M:CharmGame.CountDownStartStream/<>c__DisplayClass4_0::<StartCountDown>b__3
02d1d7a4: ldr     x21, [x19, #0x28]                          ._sequence
02d1d7a8: bl      #0x5a7845c                                 TMPro.TMP_Text::get_transform
02d1d7ac: fmov    s1, s9                                     
02d1d7b0: fmov    s0, #1.00000000                            
02d1d7b4: mov     x1, xzr                                    
02d1d7b8: bl      #0x2d98c98                                 DG.Tweening.ShortcutExtensions::DOScale
02d1d7bc: ldr     x2, [x25]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d1d7c0: mov     w1, #1                                     
02d1d7c4: bl      #0x336fa0c                                 fn_336fa0c
02d1d7c8: mov     x1, x0                                     
02d1d7cc: mov     x0, x21                                    
02d1d7d0: mov     x2, xzr                                    
02d1d7d4: bl      #0x2d9b0a8                                 DG.Tweening.TweenSettingsExtensions::Append
02d1d7d8: movi    d0, #0000000000000000                      
02d1d7dc: fmov    s1, s9                                     
02d1d7e0: mov     x1, xzr                                    
02d1d7e4: ldp     x0, x21, [x19, #0x20]                      ._txtCountdown
02d1d7e8: bl      #0x2c78678                                 DG.Tweening.DOTweenModuleUI::DOFade
02d1d7ec: ldr     x2, [x24]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d1d7f0: mov     w1, #1                                     
02d1d7f4: bl      #0x336fa0c                                 fn_336fa0c
02d1d7f8: mov     x1, x0                                     
02d1d7fc: mov     x0, x21                                    
02d1d800: mov     x2, xzr                                    
02d1d804: bl      #0x2d9b0ec                                 DG.Tweening.TweenSettingsExtensions::Join
02d1d808: ldr     x0, [x23]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d1d80c: ldr     x19, [x19, #0x28]                          ._sequence
02d1d810: bl      #0x2b7104c                                 fn_2b7104c
02d1d814: ldr     x2, [x22]                                  T:Trading.TradingSession/<>c__DisplayClass56_0
02d1d818: mov     x1, x20                                    
02d1d81c: mov     x3, xzr                                    
02d1d820: mov     x21, x0                                    
02d1d824: bl      #0x2d89dc4                                 DG.Tweening.TweenCallback::.ctor
02d1d828: mov     x0, x19                                    
02d1d82c: mov     x1, x21                                    
02d1d830: mov     x2, xzr                                    
02d1d834: ldp     x20, x19, [sp, #0x50]                      
02d1d838: ldp     x22, x21, [sp, #0x40]                      
02d1d83c: ldp     x24, x23, [sp, #0x30]                      
02d1d840: ldp     x30, x25, [sp, #0x20]                      
02d1d844: ldp     d9, d8, [sp, #0x10]                        
02d1d848: ldr     d10, [sp], #0x60                           
02d1d84c: b       #0x2da03d8                                 DG.Tweening.TweenSettingsExtensions::AppendCallback
02d1d850: bl      #0x2b7105c                                 fn_2b7105c
## .ctor() -> void
---- CharmGame.CountDownStartStream::.ctor 0x2d1d85c
02d1d85c: mov     x1, xzr                                    
02d1d860: b       #0x5b397b0                                 UnityEngine.MonoBehaviour::.ctor
