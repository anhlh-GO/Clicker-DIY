#### CLASS KeysData/<>c__DisplayClass1_0 parent= object
#   field type                           AdFormat                                           off=0x10 attr=6 
## .ctor() -> void
---- KeysData/<>c__DisplayClass1_0::.ctor 0x2c9be04
02c9be04: mov     x1, xzr                                    
02c9be08: b       #0x4e53e9c                                 System.Object::.ctor
## <GetAdKey>b__0(KeyAd k) -> bool
---- KeysData/<>c__DisplayClass1_0::<GetAdKey>b__0 0x2c9be14
02c9be14: cbz     x1, #0x2c9be2c                             
02c9be18: ldr     w8, [x1, #0x10]                            
02c9be1c: ldr     w9, [x0, #0x10]                            .type
02c9be20: cmp     w8, w9                                     
02c9be24: cset    w0, eq                                     
02c9be28: ret                                                
02c9be2c: str     x30, [sp, #-0x10]!                         
02c9be30: bl      #0x2b7105c                                 fn_2b7105c
#### CLASS KeysData parent= UnityEngine.ScriptableObject
#   field dataKey                        System.Collections.Generic.List`1<KeyAd>           off=0x18 attr=1 SerializeField
## GetAdKey(AdFormat type) -> string
---- KeysData::GetAdKey 0x2c9bc10
02c9bc10: str     x30, [sp, #-0x30]!                         
02c9bc14: stp     x22, x21, [sp, #0x10]                      
02c9bc18: stp     x20, x19, [sp, #0x20]                      
02c9bc1c: adrp    x19, #0x662f000                            
02c9bc20: adrp    x22, #0x6265000                            
02c9bc24: mov     w20, w1                                    
02c9bc28: ldrb    w8, [x19, #0xa49]                          
02c9bc2c: ldr     x22, [x22, #0xac0]                         T:KeysData/<>c__DisplayClass1_0
02c9bc30: mov     x21, x0                                    
02c9bc34: tbnz    w8, #0, #0x2c9bc94                         
02c9bc38: adrp    x0, #0x6265000                             
02c9bc3c: ldr     x0, [x0, #0x210]                           T:AdFormat
02c9bc40: bl      #0x2b70db0                                 fn_2b70db0
02c9bc44: adrp    x0, #0x6265000                             
02c9bc48: ldr     x0, [x0, #0xac8]                           MS:System.Collections.Generic.List`1::Find
02c9bc4c: bl      #0x2b70db0                                 fn_2b70db0
02c9bc50: adrp    x0, #0x6265000                             
02c9bc54: ldr     x0, [x0, #0xad0]                           T:type57254(k15)
02c9bc58: bl      #0x2b70db0                                 fn_2b70db0
02c9bc5c: adrp    x0, #0x6265000                             
02c9bc60: ldr     x0, [x0, #0xad8]                           M:KeysData/<>c__DisplayClass1_0::<GetAdKey>b__0
02c9bc64: bl      #0x2b70db0                                 fn_2b70db0
02c9bc68: adrp    x0, #0x6265000                             
02c9bc6c: ldr     x0, [x0, #0xac0]                           T:KeysData/<>c__DisplayClass1_0
02c9bc70: bl      #0x2b70db0                                 fn_2b70db0
02c9bc74: adrp    x0, #0x6264000                             
02c9bc78: ldr     x0, [x0, #0xd90]                           S:'{0}'
02c9bc7c: bl      #0x2b70db0                                 fn_2b70db0
02c9bc80: adrp    x0, #0x6265000                             
02c9bc84: ldr     x0, [x0, #0xae0]                           S:'[KEY] {0} check key or format'
02c9bc88: bl      #0x2b70db0                                 fn_2b70db0
02c9bc8c: mov     w8, #1                                     
02c9bc90: strb    w8, [x19, #0xa49]                          
02c9bc94: ldr     x0, [x22]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9bc98: bl      #0x2b7104c                                 fn_2b7104c
02c9bc9c: mov     x1, xzr                                    
02c9bca0: mov     x19, x0                                    
02c9bca4: bl      #0x4e53e9c                                 System.Object::.ctor
02c9bca8: cbz     x19, #0x2c9bd98                            
02c9bcac: adrp    x8, #0x6265000                             
02c9bcb0: adrp    x22, #0x6265000                            
02c9bcb4: ldr     x8, [x8, #0xad0]                           T:type57254(k15)
02c9bcb8: ldr     x22, [x22, #0xad8]                         M:KeysData/<>c__DisplayClass1_0::<GetAdKey>b__0
02c9bcbc: ldr     x21, [x21, #0x18]                          .dataKey
02c9bcc0: str     w20, [x19, #0x10]                          
02c9bcc4: ldr     x0, [x8]                                   M:AdsManager::<OnApplicationPause>b__26_0
02c9bcc8: bl      #0x2b7104c                                 fn_2b7104c
02c9bccc: ldr     x2, [x22]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9bcd0: mov     x1, x19                                    
02c9bcd4: mov     x3, xzr                                    
02c9bcd8: mov     x20, x0                                    
02c9bcdc: bl      #0x399ba10                                 fn_399ba10
02c9bce0: cbz     x21, #0x2c9bd98                            
02c9bce4: adrp    x8, #0x6265000                             
02c9bce8: adrp    x22, #0x6264000                            
02c9bcec: mov     x0, x21                                    
02c9bcf0: ldr     x8, [x8, #0xac8]                           MS:System.Collections.Generic.List`1::Find
02c9bcf4: ldr     x22, [x22, #0xd90]                         S:'{0}'
02c9bcf8: mov     x1, x20                                    
02c9bcfc: ldr     x2, [x8]                                   M:AdsManager::<OnApplicationPause>b__26_0
02c9bd00: bl      #0x35a9868                                 fn_35a9868
02c9bd04: ldr     x8, [x22]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c9bd08: mov     x20, x0                                    
02c9bd0c: mov     x2, xzr                                    
02c9bd10: mov     x1, x20                                    
02c9bd14: mov     x0, x8                                     
02c9bd18: bl      #0x4c9d0ec                                 System.String::Format
02c9bd1c: mov     x1, xzr                                    
02c9bd20: bl      #0x4ca6234                                 System.String::IsNullOrEmpty
02c9bd24: tbz     w0, #0, #0x2c9bd68                         
02c9bd28: adrp    x8, #0x6265000                             
02c9bd2c: add     x1, sp, #0xc                               
02c9bd30: ldr     x8, [x8, #0x210]                           T:AdFormat
02c9bd34: ldr     w9, [x19, #0x10]                           &2b706e8(=14cc74f191004000)
02c9bd38: ldr     x0, [x8]                                   M:AdsManager::<OnApplicationPause>b__26_0
02c9bd3c: str     w9, [sp, #0xc]                             
02c9bd40: bl      #0x2b70f38                                 fn_2b70f38
02c9bd44: adrp    x8, #0x6265000                             
02c9bd48: mov     x1, x0                                     
02c9bd4c: mov     x2, xzr                                    
02c9bd50: ldr     x8, [x8, #0xae0]                           S:'[KEY] {0} check key or format'
02c9bd54: ldr     x8, [x8]                                   M:AdsManager::<OnApplicationPause>b__26_0
02c9bd58: mov     x0, x8                                     
02c9bd5c: bl      #0x4c9d0ec                                 System.String::Format
02c9bd60: mov     x1, xzr                                    
02c9bd64: bl      #0x2ca09f8                                 WLog::LogError
02c9bd68: cbz     x20, #0x2c9bd74                            
02c9bd6c: add     x8, x20, #0x18                             
02c9bd70: b       #0x2c9bd84                                 
02c9bd74: adrp    x8, #0x6263000                             
02c9bd78: ldr     x8, [x8, #0x970]                           &6645c70(=0)
02c9bd7c: ldr     x8, [x8, #0x90]                            &2c5beb4(=14c8d222d503245f)
02c9bd80: ldr     x8, [x8, #0xb8]                            &6263108(=0)
02c9bd84: ldp     x20, x19, [sp, #0x20]                      
02c9bd88: ldr     x0, [x8]                                   &2c5bbd4(=a9bd7bfdd503233f)
02c9bd8c: ldp     x22, x21, [sp, #0x10]                      
02c9bd90: ldr     x30, [sp], #0x30                           
02c9bd94: ret                                                
02c9bd98: bl      #0x2b7105c                                 fn_2b7105c
## .ctor() -> void
---- KeysData::.ctor 0x2c9be0c
02c9be0c: mov     x1, xzr                                    
02c9be10: b       #0x5b398f0                                 UnityEngine.ScriptableObject::.ctor
