#### CLASS DreamHouse.DecorItemPanel/<>c__DisplayClass15_0 parent= object
#   field <>4__this                      DreamHouse.DecorItemPanel                          off=0x10 attr=6 
#   field selectedItem                   DreamHouse.DecorItemUI                             off=0x18 attr=6 
## .ctor() -> void
---- DreamHouse.DecorItemPanel/<>c__DisplayClass15_0::.ctor 0x2d1aa50
02d1aa50: mov     x1, xzr                                    
02d1aa54: b       #0x4e53e9c                                 System.Object::.ctor
## <OnAdsButtonClicked>b__0() -> void
---- DreamHouse.DecorItemPanel/<>c__DisplayClass15_0::<OnAdsButtonClicked>b__0 0x2d1aa60
02d1aa60: stp     x30, x21, [sp, #-0x20]!                    
02d1aa64: stp     x20, x19, [sp, #0x10]                      
02d1aa68: adrp    x20, #0x6630000                            
02d1aa6c: adrp    x21, #0x6266000                            
02d1aa70: mov     x19, x0                                    
02d1aa74: ldrb    w8, [x20, #5]                              
02d1aa78: ldr     x21, [x21, #0x658]                         MS:MonoSingleton`1::get_Instance
02d1aa7c: tbnz    w8, #0, #0x2d1aaac                         
02d1aa80: adrp    x0, #0x6266000                             
02d1aa84: ldr     x0, [x0, #0x750]                           MS:DataManager::GetData
02d1aa88: bl      #0x2b70db0                                 fn_2b70db0
02d1aa8c: adrp    x0, #0x6269000                             
02d1aa90: ldr     x0, [x0, #0xb38]                           MS:System.Collections.Generic.List`1::IndexOf
02d1aa94: bl      #0x2b70db0                                 fn_2b70db0
02d1aa98: adrp    x0, #0x6266000                             
02d1aa9c: ldr     x0, [x0, #0x658]                           MS:MonoSingleton`1::get_Instance
02d1aaa0: bl      #0x2b70db0                                 fn_2b70db0
02d1aaa4: mov     w8, #1                                     
02d1aaa8: strb    w8, [x20, #5]                              
02d1aaac: ldr     x0, [x21]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d1aab0: bl      #0x3769600                                 fn_3769600
02d1aab4: cbz     x0, #0x2d1abc4                             
02d1aab8: adrp    x8, #0x6266000                             
02d1aabc: ldr     x8, [x8, #0x750]                           MS:DataManager::GetData
02d1aac0: ldr     x1, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d1aac4: bl      #0x3168dd0                                 fn_3168dd0
02d1aac8: cbz     x0, #0x2d1abc4                             
02d1aacc: ldr     x8, [x0, #0x20]                            S:'inter_ad_capping_time'
02d1aad0: cbz     x8, #0x2d1abc4                             
02d1aad4: ldrb    w9, [x8, #0x43]                            
02d1aad8: cbnz    w9, #0x2d1aaf4                             
02d1aadc: mov     w9, #1                                     
02d1aae0: strb    w9, [x8, #0x43]                            
02d1aae4: ldr     x8, [x0]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d1aae8: ldr     x9, [x8, #0x258]                           MS:System.Collections.Generic.List`1/Enumerator::Dispose
02d1aaec: ldr     x1, [x8, #0x260]                           MS:System.Collections.Generic.List`1/Enumerator::MoveNext
02d1aaf0: blr     x9                                         
02d1aaf4: ldr     x0, [x19, #0x10]                           .<>4__this
02d1aaf8: cbz     x0, #0x2d1abc4                             
02d1aafc: mov     w1, wzr                                    
02d1ab00: bl      #0x2d1a13c                                 DreamHouse.DecorItemPanel::SetInteractableItems
02d1ab04: ldr     x0, [x19, #0x10]                           .<>4__this
02d1ab08: cbz     x0, #0x2d1abc4                             
02d1ab0c: ldr     x1, [x19, #0x18]                           .selectedItem
02d1ab10: bl      #0x2d1a3e4                                 DreamHouse.DecorItemPanel::CreateDecorItemObject
02d1ab14: ldr     x0, [x19, #0x18]                           .selectedItem
02d1ab18: cbz     x0, #0x2d1abc4                             
02d1ab1c: bl      #0x2d1a868                                 DreamHouse.DecorItemUI::Unlocked
02d1ab20: ldr     x0, [x19, #0x10]                           .<>4__this
02d1ab24: cbz     x0, #0x2d1abc4                             
02d1ab28: ldr     x1, [x19, #0x18]                           .selectedItem
02d1ab2c: bl      #0x2d1a2e4                                 DreamHouse.DecorItemPanel::SetSelectedItem
02d1ab30: ldr     x20, [x19, #0x10]                          .<>4__this
02d1ab34: cbz     x20, #0x2d1abc4                            
02d1ab38: movi    d0, #0000000000000000                      
02d1ab3c: ldr     x0, [x20, #0x20]                           
02d1ab40: mov     w1, wzr                                    
02d1ab44: mov     x2, xzr                                    
02d1ab48: bl      #0x2cf1928                                 FrameWorkUtility::SetActive
02d1ab4c: str     xzr, [x20, #0x48]!                         
02d1ab50: mov     x0, x20                                    
02d1ab54: mov     x1, xzr                                    
02d1ab58: bl      #0x2b70d54                                 fn_2b70d54
02d1ab5c: ldr     x8, [x19, #0x10]                           .<>4__this
02d1ab60: cbz     x8, #0x2d1abc4                             
02d1ab64: ldr     x0, [x8, #0x30]                            S:'popup_rate_on_off'
02d1ab68: cbz     x0, #0x2d1abc4                             
02d1ab6c: adrp    x8, #0x6269000                             
02d1ab70: ldr     x8, [x8, #0xb38]                           MS:System.Collections.Generic.List`1::IndexOf
02d1ab74: ldr     x1, [x19, #0x18]                           .selectedItem
02d1ab78: ldr     x2, [x8]                                   T:Trading.TradingSession/<>c__DisplayClass56_0
02d1ab7c: bl      #0x35a9f48                                 fn_35a9f48
02d1ab80: ldr     x8, [x19, #0x10]                           .<>4__this
02d1ab84: cbz     x8, #0x2d1abc4                             
02d1ab88: mov     w1, w0                                     
02d1ab8c: ldr     x0, [x8, #0x40]                            MS:System.Linq.Enumerable::Select
02d1ab90: cbz     x0, #0x2d1abc4                             
02d1ab94: mov     x2, xzr                                    
02d1ab98: bl      #0x2d18408                                 DreamHouse.DreamHouseController::SaveCurrentRoomStep
02d1ab9c: ldr     x8, [x19, #0x10]                           .<>4__this
02d1aba0: cbz     x8, #0x2d1abc4                             
02d1aba4: ldr     x8, [x8, #0x40]                            MS:System.Linq.Enumerable::Select
02d1aba8: cbz     x8, #0x2d1abc4                             
02d1abac: ldr     x0, [x8, #0x40]                            MS:System.Linq.Enumerable::Select
02d1abb0: cbz     x0, #0x2d1abc4                             
02d1abb4: ldp     x20, x19, [sp, #0x10]                      
02d1abb8: mov     x1, xzr                                    
02d1abbc: ldp     x30, x21, [sp], #0x20                      
02d1abc0: b       #0x2d18b44                                 DreamHouse.RoomController::NextStep
02d1abc4: bl      #0x2b7105c                                 fn_2b7105c
#### CLASS DreamHouse.DecorItemPanel/<ShowAnim>d__9 parent= System.ValueType
#   field <>1__state                     int                                                off=0x10 attr=6 
#   field <>t__builder                   Cysharp.Threading.Tasks.CompilerServices.AsyncUniTaskVoidMethodBuilder off=0x18 attr=6 
#   field <>4__this                      DreamHouse.DecorItemPanel                          off=0x20 attr=6 
#   field <>7__wrap1                     System.Collections.Generic.List`1/Enumerator<DreamHouse.DecorItemUI> off=0x28 attr=1 
#   field <>u__1                         Cysharp.Threading.Tasks.UniTask/Awaiter            off=0x40 attr=1 
## MoveNext() -> void
---- DreamHouse.DecorItemPanel/<ShowAnim>d__9::MoveNext 0x2d1abc8
02d1abc8: sub     sp, sp, #0xc0                              
02d1abcc: stp     x30, x0, [sp, #0x80]                       
02d1abd0: stp     x24, x23, [sp, #0x90]                      
02d1abd4: stp     x22, x21, [sp, #0xa0]                      
02d1abd8: stp     x20, x19, [sp, #0xb0]                      
02d1abdc: adrp    x20, #0x6630000                            
02d1abe0: mov     x19, x0                                    
02d1abe4: ldrb    w8, [x20, #6]                              
02d1abe8: tbnz    w8, #0, #0x2d1ac48                         
02d1abec: adrp    x0, #0x6269000                             
02d1abf0: ldr     x0, [x0, #0xb60]                           MS:Cysharp.Threading.Tasks.CompilerServices.AsyncUniTaskVoidMethodBuilder::AwaitUnsafeOnCompleted
02d1abf4: bl      #0x2b70db0                                 fn_2b70db0
02d1abf8: adrp    x0, #0x6269000                             
02d1abfc: ldr     x0, [x0, #0xae8]                           MS:System.Collections.Generic.List`1/Enumerator::Dispose
02d1ac00: bl      #0x2b70db0                                 fn_2b70db0
02d1ac04: adrp    x0, #0x6269000                             
02d1ac08: ldr     x0, [x0, #0xaf0]                           MS:System.Collections.Generic.List`1/Enumerator::MoveNext
02d1ac0c: bl      #0x2b70db0                                 fn_2b70db0
02d1ac10: adrp    x0, #0x6269000                             
02d1ac14: ldr     x0, [x0, #0xaf8]                           MS:System.Collections.Generic.List`1/Enumerator::get_Current
02d1ac18: bl      #0x2b70db0                                 fn_2b70db0
02d1ac1c: adrp    x0, #0x6269000                             
02d1ac20: ldr     x0, [x0, #0xb00]                           MS:System.Collections.Generic.List`1::GetEnumerator
02d1ac24: bl      #0x2b70db0                                 fn_2b70db0
02d1ac28: adrp    x0, #0x6269000                             
02d1ac2c: ldr     x0, [x0, #0xa80]                           MS:MonoSingleton`1::get_Instance
02d1ac30: bl      #0x2b70db0                                 fn_2b70db0
02d1ac34: adrp    x0, #0x6266000                             
02d1ac38: ldr     x0, [x0, #0xcc8]                           T:Cysharp.Threading.Tasks.UniTask
02d1ac3c: bl      #0x2b70db0                                 fn_2b70db0
02d1ac40: mov     w8, #1                                     
02d1ac44: strb    w8, [x20, #6]                              
02d1ac48: str     wzr, [sp, #0x7c]                           
02d1ac4c: adrp    x22, #0x6269000                            
02d1ac50: adrp    x23, #0x6266000                            
02d1ac54: ldr     x22, [x22, #0xaf0]                         MS:System.Collections.Generic.List`1/Enumerator::MoveNext
02d1ac58: str     xzr, [sp, #0x68]                           
02d1ac5c: adrp    x24, #0x6266000                            
02d1ac60: ldr     x23, [x23, #0xcc8]                         T:Cysharp.Threading.Tasks.UniTask
02d1ac64: str     xzr, [sp, #0x60]                           
02d1ac68: ldr     w8, [x19]                                  
02d1ac6c: str     wzr, [sp, #0x58]                           
02d1ac70: ldr     x19, [x19, #0x10]                          .<>1__state
02d1ac74: ldr     x24, [x24, #0xcd0]                         T:Cysharp.Threading.Tasks.IUniTaskSource
02d1ac78: str     w8, [sp, #0x7c]                            
02d1ac7c: cbz     w8, #0x2d1ace4                             
02d1ac80: cbz     x19, #0x2d1ad14                            
02d1ac84: ldr     x0, [x19, #0x30]                           
02d1ac88: cbz     x0, #0x2d1ad18                             
02d1ac8c: adrp    x8, #0x6269000                             
02d1ac90: ldr     x8, [x8, #0xb00]                           MS:System.Collections.Generic.List`1::GetEnumerator
02d1ac94: ldr     x1, [x8]                                   T:Trading.TradingSession/<>c__DisplayClass56_0
02d1ac98: add     x8, sp, #0x10                              
02d1ac9c: bl      #0x35a9d9c                                 fn_35a9d9c
02d1aca0: ldr     q0, [sp, #0x10]                            
02d1aca4: ldr     x8, [sp, #0x20]                            
02d1aca8: ldr     x9, [sp, #0x88]                            
02d1acac: str     q0, [sp, #0x30]                            
02d1acb0: str     x8, [sp, #0x40]                            
02d1acb4: stur    q0, [x9, #0x18]                            
02d1acb8: str     x8, [x9, #0x28]                            
02d1acbc: add     x0, x9, #0x18                              
02d1acc0: mov     x1, xzr                                    
02d1acc4: bl      #0x2b70d54                                 fn_2b70d54
02d1acc8: ldr     w8, [sp, #0x7c]                            
02d1accc: add     x9, sp, #0x7c                              
02d1acd0: stp     xzr, x9, [sp, #0x30]                       
02d1acd4: add     x9, sp, #0x88                              
02d1acd8: str     x9, [sp, #0x40]                            
02d1acdc: cbnz    w8, #0x2d1adb8                             
02d1ace0: b       #0x2d1acf4                                 
02d1ace4: add     x8, sp, #0x7c                              
02d1ace8: add     x9, sp, #0x88                              
02d1acec: stp     xzr, x8, [sp, #0x30]                       
02d1acf0: str     x9, [sp, #0x40]                            
02d1acf4: ldr     x8, [sp, #0x88]                            
02d1acf8: mov     w9, #-1                                    
02d1acfc: str     w9, [sp, #0x7c]                            
02d1ad00: ldr     q0, [x8, #0x30]                            MS:System.Collections.Generic.Dictionary`2::set_Item
02d1ad04: stp     xzr, xzr, [x8, #0x30]                      
02d1ad08: str     q0, [sp, #0x60]                            
02d1ad0c: str     w9, [x8]                                   
02d1ad10: b       #0x2d1ad2c                                 
02d1ad14: bl      #0x2b7105c                                 fn_2b7105c
02d1ad18: bl      #0x2b7105c                                 fn_2b7105c
02d1ad1c: b       #0x2d1b058                                 
02d1ad20: b       #0x2d1b058                                 
02d1ad24: b       #0x2d1b058                                 
02d1ad28: b       #0x2d1b058                                 
02d1ad2c: adrp    x20, #0x662f000                            
02d1ad30: ldrb    w8, [x20, #0xbde]                          
02d1ad34: cbnz    w8, #0x2d1ad4c                             
02d1ad38: adrp    x0, #0x6266000                             
02d1ad3c: ldr     x0, [x0, #0xcd0]                           T:Cysharp.Threading.Tasks.IUniTaskSource
02d1ad40: bl      #0x2b70db0                                 fn_2b70db0
02d1ad44: mov     w8, #1                                     
02d1ad48: strb    w8, [x20, #0xbde]                          
02d1ad4c: ldr     x20, [sp, #0x60]                           
02d1ad50: cbz     x20, #0x2d1adb8                            
02d1ad54: ldr     x8, [x20]                                  &2b706c4(=eb01011ff9400808)
02d1ad58: ldrh    w21, [sp, #0x68]                           
02d1ad5c: ldr     x1, [x24]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d1ad60: ldrh    w9, [x8, #0x12e]                           
02d1ad64: cbz     x9, #0x2d1ad88                             
02d1ad68: ldr     x10, [x8, #0xb0]                           M:Trading.TradingSession/<>c__DisplayClass65_0::<BuildResult>b__0
02d1ad6c: add     x10, x10, #8                               
02d1ad70: ldur    x11, [x10, #-8]                            
02d1ad74: cmp     x11, x1                                    
02d1ad78: b.eq    #0x2d1ad98                                 
02d1ad7c: subs    x9, x9, #1                                 
02d1ad80: add     x10, x10, #0x10                            
02d1ad84: b.ne    #0x2d1ad70                                 
02d1ad88: mov     x0, x20                                    
02d1ad8c: mov     w2, #2                                     
02d1ad90: bl      #0x2baa05c                                 fn_2baa05c
02d1ad94: b       #0x2d1ada8                                 
02d1ad98: ldr     w9, [x10]                                  
02d1ad9c: add     w9, w9, #2                                 
02d1ada0: add     x8, x8, w9, sxtw #4                        &6269000
02d1ada4: add     x0, x8, #0x138                             &6269138
02d1ada8: ldp     x8, x2, [x0]                               
02d1adac: mov     x0, x20                                    
02d1adb0: mov     w1, w21                                    
02d1adb4: blr     x8                                         
02d1adb8: ldr     x1, [x22]                                  T:Trading.TradingSession/<>c__DisplayClass56_0
02d1adbc: ldr     x8, [sp, #0x88]                            
02d1adc0: add     x0, x8, #0x18                              &6269018
02d1adc4: bl      #0x4690474                                 fn_4690474
02d1adc8: tbz     w0, #0, #0x2d1af3c                         
02d1adcc: ldr     x8, [sp, #0x88]                            
02d1add0: ldr     x0, [x8, #0x28]                            T:Trading.TradingCounterRequest
02d1add4: cbz     x0, #0x2d1b010                             
02d1add8: bl      #0x2d1b158                                 DreamHouse.DecorItemUI::OnShow
02d1addc: cbz     x19, #0x2d1b00c                            
02d1ade0: mov     x0, x19                                    
02d1ade4: mov     x1, xzr                                    
02d1ade8: bl      #0x5b37c84                                 UnityEngine.MonoBehaviour::get_destroyCancellationToken
02d1adec: mov     x20, x0                                    
02d1adf0: ldr     x0, [x23]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d1adf4: ldr     w8, [x0, #0xe4]                            [62660e4]=0 f=0,0
02d1adf8: cbnz    w8, #0x2d1ae00                             
02d1adfc: bl      #0x2b70f30                                 fn_2b70f30
02d1ae00: adrp    x8, #0x1084000                             
02d1ae04: mov     w0, wzr                                    
02d1ae08: mov     w1, #8                                     
02d1ae0c: ldr     s0, [x8, #0xda4]                           [1084da4]=3eb851ec3e19999a f=0.15,0.36
02d1ae10: mov     x2, x20                                    
02d1ae14: mov     w3, wzr                                    
02d1ae18: mov     x4, xzr                                    
02d1ae1c: bl      #0x5447b08                                 Cysharp.Threading.Tasks.UniTask::WaitForSeconds
02d1ae20: stp     x0, x1, [sp, #0x10]                        
02d1ae24: add     x0, sp, #0x10                              
02d1ae28: mov     x1, xzr                                    
02d1ae2c: bl      #0x2b70d54                                 fn_2b70d54
02d1ae30: adrp    x20, #0x662f000                            
02d1ae34: ldr     q0, [sp, #0x10]                            
02d1ae38: ldrb    w8, [x20, #0xbdc]                          
02d1ae3c: str     q0, [sp, #0x60]                            
02d1ae40: cbnz    w8, #0x2d1ae58                             
02d1ae44: adrp    x0, #0x6266000                             
02d1ae48: ldr     x0, [x0, #0xcc8]                           T:Cysharp.Threading.Tasks.UniTask
02d1ae4c: bl      #0x2b70db0                                 fn_2b70db0
02d1ae50: mov     w8, #1                                     
02d1ae54: strb    w8, [x20, #0xbdc]                          
02d1ae58: ldr     x0, [x23]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d1ae5c: ldr     w8, [x0, #0xe4]                            [62660e4]=0 f=0,0
02d1ae60: cbnz    w8, #0x2d1ae68                             
02d1ae64: bl      #0x2b70f30                                 fn_2b70f30
02d1ae68: adrp    x20, #0x662f000                            
02d1ae6c: ldrb    w8, [x20, #0xbdd]                          
02d1ae70: cbnz    w8, #0x2d1ae88                             
02d1ae74: adrp    x0, #0x6266000                             
02d1ae78: ldr     x0, [x0, #0xcd0]                           T:Cysharp.Threading.Tasks.IUniTaskSource
02d1ae7c: bl      #0x2b70db0                                 fn_2b70db0
02d1ae80: mov     w8, #1                                     
02d1ae84: strb    w8, [x20, #0xbdd]                          
02d1ae88: ldr     x20, [sp, #0x60]                           
02d1ae8c: cbz     x20, #0x2d1ad2c                            
02d1ae90: ldr     x8, [x20]                                  &2b706c4(=eb01011ff9400808)
02d1ae94: ldrh    w21, [sp, #0x68]                           
02d1ae98: ldr     x1, [x24]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d1ae9c: ldrh    w9, [x8, #0x12e]                           
02d1aea0: cbz     x9, #0x2d1aec4                             
02d1aea4: ldr     x10, [x8, #0xb0]                           [10840b0]=2e656e69676e4579 f=1.1252e+24,5.21666e-11
02d1aea8: add     x10, x10, #8                               
02d1aeac: ldur    x11, [x10, #-8]                            
02d1aeb0: cmp     x11, x1                                    
02d1aeb4: b.eq    #0x2d1aed4                                 
02d1aeb8: subs    x9, x9, #1                                 
02d1aebc: add     x10, x10, #0x10                            
02d1aec0: b.ne    #0x2d1aeac                                 
02d1aec4: mov     x0, x20                                    
02d1aec8: mov     w2, wzr                                    
02d1aecc: bl      #0x2baa05c                                 fn_2baa05c
02d1aed0: b       #0x2d1aee0                                 
02d1aed4: ldrsw   x9, [x10]                                  
02d1aed8: add     x8, x8, x9, lsl #4                         &1084000
02d1aedc: add     x0, x8, #0x138                             &1084138
02d1aee0: ldp     x8, x2, [x0]                               
02d1aee4: mov     x0, x20                                    
02d1aee8: mov     w1, w21                                    
02d1aeec: blr     x8                                         
02d1aef0: cbnz    w0, #0x2d1ad2c                             
02d1aef4: ldr     x8, [sp, #0x88]                            
02d1aef8: str     wzr, [sp, #0x7c]                           
02d1aefc: str     wzr, [x8]                                  
02d1af00: ldr     q0, [sp, #0x60]                            
02d1af04: str     q0, [x8, #0x30]                            
02d1af08: add     x0, x8, #0x30                              &1084030
02d1af0c: mov     x1, xzr                                    
02d1af10: bl      #0x2b70d54                                 fn_2b70d54
02d1af14: adrp    x8, #0x6269000                             
02d1af18: ldr     x8, [x8, #0xb60]                           MS:Cysharp.Threading.Tasks.CompilerServices.AsyncUniTaskVoidMethodBuilder::AwaitUnsafeOnCompleted
02d1af1c: ldr     x2, [sp, #0x88]                            
02d1af20: ldr     x3, [x8]                                   T:Trading.TradingSession/<>c__DisplayClass56_0
02d1af24: add     x0, x2, #8                                 
02d1af28: add     x1, sp, #0x60                              
02d1af2c: bl      #0x2d2f6f8                                 fn_2d2f6f8
02d1af30: mov     x20, xzr                                   
02d1af34: mov     w21, #7                                    
02d1af38: b       #0x2d1af44                                 
02d1af3c: mov     x20, xzr                                   
02d1af40: mov     w21, #8                                    
02d1af44: add     x8, sp, #0x7c                              
02d1af48: ldr     w8, [x8]                                   T:Trading.TradingSession/<>c__DisplayClass56_0
02d1af4c: tbz     w8, #0x1f, #0x2d1af6c                      
02d1af50: adrp    x9, #0x6269000                             
02d1af54: ldr     x8, [sp, #0x40]                            
02d1af58: ldr     x9, [x9, #0xae8]                           MS:System.Collections.Generic.List`1/Enumerator::Dispose
02d1af5c: ldr     x8, [x8]                                   T:Trading.TradingSession/<>c__DisplayClass56_0
02d1af60: ldr     x1, [x9]                                   T:Trading.TradingSession/<>c__DisplayClass56_0
02d1af64: add     x0, x8, #0x18                              &6269018
02d1af68: bl      #0x4690470                                 fn_4690470
02d1af6c: cbnz    x20, #0x2d1b014                            
02d1af70: orr     w8, w21, #8                                
02d1af74: cmp     w8, #8                                     
02d1af78: b.ne    #0x2d1aff4                                 
02d1af7c: ldr     x8, [sp, #0x88]                            
02d1af80: stp     xzr, xzr, [x8, #0x20]                      
02d1af84: str     xzr, [x8, #0x18]                           
02d1af88: cbz     x19, #0x2d1b01c                            
02d1af8c: ldr     x8, [x19, #0x40]                           .<>u__1
02d1af90: cbz     x8, #0x2d1b020                             
02d1af94: ldr     x0, [x8, #0x30]                            MS:System.Collections.Generic.Dictionary`2::set_Item
02d1af98: cbz     x0, #0x2d1b024                             
02d1af9c: mov     x1, xzr                                    
02d1afa0: bl      #0x2d166b8                                 DreamHouse.DataDreamHouse::IsFirstTime
02d1afa4: tbz     w0, #0, #0x2d1afe0                         
02d1afa8: ldr     x8, [x19, #0x40]                           .<>u__1
02d1afac: cbz     x8, #0x2d1b028                             
02d1afb0: ldr     x8, [x8, #0x40]                            MS:System.Linq.Enumerable::Select
02d1afb4: cbz     x8, #0x2d1b02c                             
02d1afb8: ldr     w8, [x8, #0x48]                            MS:System.Collections.Generic.HashSet`1::.ctor
02d1afbc: cbnz    w8, #0x2d1afe0                             
02d1afc0: adrp    x8, #0x6269000                             
02d1afc4: ldr     x8, [x8, #0xa80]                           MS:MonoSingleton`1::get_Instance
02d1afc8: ldr     x0, [x8]                                   T:Trading.TradingSession/<>c__DisplayClass56_0
02d1afcc: bl      #0x3769600                                 fn_3769600
02d1afd0: cbz     x0, #0x2d1b030                             
02d1afd4: mov     w1, #1                                     
02d1afd8: mov     w2, #1                                     
02d1afdc: bl      #0x2d19814                                 DreamHouse.TutorialHandler::SetActiveHandTutorial
02d1afe0: ldr     x0, [sp, #0x88]                            
02d1afe4: mov     w8, #-2                                    
02d1afe8: mov     x1, xzr                                    
02d1afec: str     w8, [x0], #8                               
02d1aff0: bl      #0x2d2f600                                 fn_2d2f600
02d1aff4: ldp     x20, x19, [sp, #0xb0]                      
02d1aff8: ldr     x30, [sp, #0x80]                           
02d1affc: ldp     x22, x21, [sp, #0xa0]                      
02d1b000: ldp     x24, x23, [sp, #0x90]                      
02d1b004: add     sp, sp, #0xc0                              
02d1b008: ret                                                
02d1b00c: bl      #0x2b7105c                                 fn_2b7105c
02d1b010: bl      #0x2b7105c                                 fn_2b7105c
02d1b014: mov     x0, x20                                    
02d1b018: bl      #0x2b71054                                 fn_2b71054
02d1b01c: bl      #0x2b7105c                                 fn_2b7105c
02d1b020: bl      #0x2b7105c                                 fn_2b7105c
02d1b024: bl      #0x2b7105c                                 fn_2b7105c
02d1b028: bl      #0x2b7105c                                 fn_2b7105c
02d1b02c: bl      #0x2b7105c                                 fn_2b7105c
02d1b030: bl      #0x2b7105c                                 fn_2b7105c
02d1b034: b       #0x2d1b058                                 
02d1b038: b       #0x2d1b058                                 
02d1b03c: b       #0x2d1b058                                 
02d1b040: b       #0x2d1b084                                 
02d1b044: b       #0x2d1b084                                 
02d1b048: b       #0x2d1b058                                 
02d1b04c: b       #0x2d1b058                                 
02d1b050: b       #0x2d1b058                                 
02d1b054: b       #0x2d1b058                                 
02d1b058: mov     x19, x1                                    
02d1b05c: str     x0, [sp, #8]                               
02d1b060: b       #0x2d1b0b8                                 
02d1b064: b       #0x2d1b084                                 
02d1b068: b       #0x2d1b084                                 
02d1b06c: b       #0x2d1b084                                 
02d1b070: b       #0x2d1b084                                 
02d1b074: b       #0x2d1b084                                 
02d1b078: b       #0x2d1b084                                 
02d1b07c: b       #0x2d1b084                                 
02d1b080: b       #0x2d1b084                                 
02d1b084: cmp     w1, #1                                     
02d1b088: b.ne    #0x2d1b0a8                                 
02d1b08c: bl      #0x5e90260                                 fn_5e90260
02d1b090: ldr     x20, [x0]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d1b094: str     x20, [sp, #0x30]                           
02d1b098: bl      #0x5e90270                                 fn_5e90270
02d1b09c: ldr     x8, [sp, #0x38]                            
02d1b0a0: mov     w21, wzr                                   
02d1b0a4: b       #0x2d1af48                                 
02d1b0a8: mov     x19, x1                                    
02d1b0ac: str     x0, [sp, #8]                               
02d1b0b0: add     x0, sp, #0x30                              
02d1b0b4: bl      #0x2738014                                 fn_2738014
02d1b0b8: cmp     w19, #1                                    
02d1b0bc: b.ne    #0x2d1b14c                                 
02d1b0c0: ldr     x0, [sp, #8]                               
02d1b0c4: bl      #0x5e90260                                 fn_5e90260
02d1b0c8: mov     x19, x0                                    
02d1b0cc: adrp    x0, #0x6263000                             
02d1b0d0: ldr     x0, [x0, #0xae0]                           T:System.Exception
02d1b0d4: bl      #0x2b70dc4                                 fn_2b70dc4
02d1b0d8: ldr     x8, [x19]                                  
02d1b0dc: ldr     x1, [x8]                                   T:Trading.TradingSession/<>c__DisplayClass56_0
02d1b0e0: bl      #0x2b71464                                 fn_2b71464
02d1b0e4: tbz     w0, #0, #0x2d1b124                         
02d1b0e8: ldrsw   x20, [sp, #0x58]                           
02d1b0ec: ldr     x19, [x19]                                 
02d1b0f0: add     x8, sp, #0x50                              
02d1b0f4: str     x19, [x8, x20, lsl #3]                     
02d1b0f8: add     w8, w20, #1                                
02d1b0fc: str     w8, [sp, #0x58]                            
02d1b100: bl      #0x5e90270                                 fn_5e90270
02d1b104: ldr     x0, [sp, #0x88]                            
02d1b108: mov     w8, #-2                                    
02d1b10c: mov     x1, x19                                    
02d1b110: mov     x2, xzr                                    
02d1b114: str     w8, [x0], #8                               
02d1b118: bl      #0x2d2f4e0                                 fn_2d2f4e0
02d1b11c: str     w20, [sp, #0x58]                           
02d1b120: b       #0x2d1aff4                                 
02d1b124: mov     w0, #8                                     
02d1b128: bl      #0x5e90290                                 fn_5e90290
02d1b12c: ldr     x8, [x19]                                  
02d1b130: str     x8, [x0]                                   
02d1b134: adrp    x1, #0x5e96000                             
02d1b138: add     x1, x1, #0x758                             &5e96758
02d1b13c: mov     x2, xzr                                    
02d1b140: bl      #0x5e902a0                                 fn_5e902a0
02d1b144: str     x0, [sp, #8]                               
02d1b148: bl      #0x5e90270                                 fn_5e90270
02d1b14c: ldr     x0, [sp, #8]                               
02d1b150: bl      #0x2c6051c                                 fn_2c6051c
02d1b154: bl      #0x27369b8                                 fn_27369b8
## SetStateMachine(System.Runtime.CompilerServices.IAsyncStateMachine stateMachine) -> void
---- DreamHouse.DecorItemPanel/<ShowAnim>d__9::SetStateMachine 0x2d1b1bc
02d1b1bc: add     x0, x0, #8                                 
02d1b1c0: mov     x2, xzr                                    
02d1b1c4: b       #0x54605f8                                 Cysharp.Threading.Tasks.CompilerServices.AsyncUniTaskVoidMethodBuilder::SetStateMachine
#### CLASS DreamHouse.DecorItemPanel parent= UnityEngine.MonoBehaviour
#   field _canvasGroup                   UnityEngine.CanvasGroup                            off=0x20 attr=1 SerializeField
#   field _decorItemEffect               UnityEngine.ParticleSystem                         off=0x28 attr=1 SerializeField
#   field _items                         System.Collections.Generic.List`1<DreamHouse.DecorItemUI> off=0x30 attr=1 SerializeField
#   field _decorItemAsset                DreamHouse.DecorItemAsset                          off=0x38 attr=1 
#   field _dreamHouseController          DreamHouse.DreamHouseController                    off=0x40 attr=1 
#   field _selectedItem                  DreamHouse.DecorItemUI                             off=0x48 attr=1 
## OnInit() -> void
---- DreamHouse.DecorItemPanel::OnInit 0x2d199cc
02d199cc: sub     sp, sp, #0x90                              
02d199d0: stp     x29, x30, [sp, #0x30]                      
02d199d4: stp     x28, x27, [sp, #0x40]                      
02d199d8: stp     x26, x25, [sp, #0x50]                      
02d199dc: stp     x24, x23, [sp, #0x60]                      
02d199e0: stp     x22, x21, [sp, #0x70]                      
02d199e4: stp     x20, x19, [sp, #0x80]                      
02d199e8: adrp    x21, #0x662f000                            
02d199ec: adrp    x20, #0x6269000                            
02d199f0: mov     x19, x0                                    
02d199f4: ldrb    w8, [x21, #0xffc]                          
02d199f8: ldr     x20, [x20, #0xac0]                         MS:MonoSingleton`1::get_Instance
02d199fc: tbnz    w8, #0, #0x2d19a74                         
02d19a00: adrp    x0, #0x6269000                             
02d19a04: ldr     x0, [x0, #0xac8]                           T:type6869(k15)
02d19a08: bl      #0x2b70db0                                 fn_2b70db0
02d19a0c: adrp    x0, #0x6269000                             
02d19a10: ldr     x0, [x0, #0xad0]                           M:DreamHouse.DecorItemPanel::OnAdsButtonClicked
02d19a14: bl      #0x2b70db0                                 fn_2b70db0
02d19a18: adrp    x0, #0x6269000                             
02d19a1c: ldr     x0, [x0, #0xad8]                           M:DreamHouse.DecorItemPanel::OnCoinButtonClicked
02d19a20: bl      #0x2b70db0                                 fn_2b70db0
02d19a24: adrp    x0, #0x6269000                             
02d19a28: ldr     x0, [x0, #0xae0]                           M:DreamHouse.DecorItemPanel::OnSelectButtonClicked
02d19a2c: bl      #0x2b70db0                                 fn_2b70db0
02d19a30: adrp    x0, #0x6269000                             
02d19a34: ldr     x0, [x0, #0xae8]                           MS:System.Collections.Generic.List`1/Enumerator::Dispose
02d19a38: bl      #0x2b70db0                                 fn_2b70db0
02d19a3c: adrp    x0, #0x6269000                             
02d19a40: ldr     x0, [x0, #0xaf0]                           MS:System.Collections.Generic.List`1/Enumerator::MoveNext
02d19a44: bl      #0x2b70db0                                 fn_2b70db0
02d19a48: adrp    x0, #0x6269000                             
02d19a4c: ldr     x0, [x0, #0xaf8]                           MS:System.Collections.Generic.List`1/Enumerator::get_Current
02d19a50: bl      #0x2b70db0                                 fn_2b70db0
02d19a54: adrp    x0, #0x6269000                             
02d19a58: ldr     x0, [x0, #0xb00]                           MS:System.Collections.Generic.List`1::GetEnumerator
02d19a5c: bl      #0x2b70db0                                 fn_2b70db0
02d19a60: adrp    x0, #0x6269000                             
02d19a64: ldr     x0, [x0, #0xac0]                           MS:MonoSingleton`1::get_Instance
02d19a68: bl      #0x2b70db0                                 fn_2b70db0
02d19a6c: mov     w8, #1                                     
02d19a70: strb    w8, [x21, #0xffc]                          
02d19a74: ldr     x0, [x20]                                  T:Trading.TradingSession/<>c__DisplayClass56_0
02d19a78: stp     xzr, xzr, [sp, #0x18]                      
02d19a7c: str     xzr, [sp, #0x28]                           
02d19a80: bl      #0x3769600                                 fn_3769600
02d19a84: mov     x1, x0                                     
02d19a88: mov     x0, x19                                    
02d19a8c: str     x1, [x0, #0x40]!                           ._dreamHouseController
02d19a90: bl      #0x2b70d54                                 fn_2b70d54
02d19a94: movi    d0, #0000000000000000                      
02d19a98: ldr     x0, [x19, #0x20]                           ._canvasGroup
02d19a9c: mov     w1, wzr                                    
02d19aa0: mov     x2, xzr                                    
02d19aa4: bl      #0x2cf1928                                 FrameWorkUtility::SetActive
02d19aa8: mov     x20, x19                                   
02d19aac: mov     x1, xzr                                    
02d19ab0: str     xzr, [x20, #0x48]!                         ._selectedItem
02d19ab4: mov     x0, x20                                    
02d19ab8: bl      #0x2b70d54                                 fn_2b70d54
02d19abc: ldur    x0, [x20, #-0x18]                          
02d19ac0: cbz     x0, #0x2d19bc4                             
02d19ac4: adrp    x8, #0x6269000                             
02d19ac8: adrp    x25, #0x6269000                            
02d19acc: adrp    x26, #0x6269000                            
02d19ad0: ldr     x8, [x8, #0xb00]                           MS:System.Collections.Generic.List`1::GetEnumerator
02d19ad4: adrp    x27, #0x6269000                            
02d19ad8: adrp    x28, #0x6269000                            
02d19adc: adrp    x29, #0x6269000                            
02d19ae0: adrp    x24, #0x6269000                            
02d19ae4: ldr     x25, [x25, #0xaf0]                         MS:System.Collections.Generic.List`1/Enumerator::MoveNext
02d19ae8: ldr     x26, [x26, #0xac8]                         T:type6869(k15)
02d19aec: ldr     x27, [x27, #0xae0]                         M:DreamHouse.DecorItemPanel::OnSelectButtonClicked
02d19af0: ldr     x28, [x28, #0xad8]                         M:DreamHouse.DecorItemPanel::OnCoinButtonClicked
02d19af4: ldr     x29, [x29, #0xad0]                         M:DreamHouse.DecorItemPanel::OnAdsButtonClicked
02d19af8: ldr     x24, [x24, #0xae8]                         MS:System.Collections.Generic.List`1/Enumerator::Dispose
02d19afc: ldr     x1, [x8]                                   T:Trading.TradingSession/<>c__DisplayClass56_0
02d19b00: add     x8, sp, #0x18                              
02d19b04: add     x20, sp, #0x18                             
02d19b08: bl      #0x35a9d9c                                 fn_35a9d9c
02d19b0c: stp     xzr, x20, [sp, #8]                         
02d19b10: ldr     x1, [x25]                                  T:Trading.TradingSession/<>c__DisplayClass56_0
02d19b14: add     x0, sp, #0x18                              
02d19b18: bl      #0x4690474                                 fn_4690474
02d19b1c: tbz     w0, #0, #0x2d19b94                         
02d19b20: ldr     x20, [sp, #0x28]                           
02d19b24: ldr     x0, [x26]                                  T:Trading.TradingSession/<>c__DisplayClass56_0
02d19b28: bl      #0x2b7104c                                 fn_2b7104c
02d19b2c: mov     x21, x0                                    
02d19b30: ldr     x2, [x27]                                  T:Trading.TradingSession/<>c__DisplayClass56_0
02d19b34: mov     x1, x19                                    
02d19b38: mov     x3, xzr                                    
02d19b3c: bl      #0x453418c                                 fn_453418c
02d19b40: ldr     x0, [x26]                                  T:Trading.TradingSession/<>c__DisplayClass56_0
02d19b44: bl      #0x2b7104c                                 fn_2b7104c
02d19b48: mov     x22, x0                                    
02d19b4c: ldr     x2, [x28]                                  T:Trading.TradingSession/<>c__DisplayClass56_0
02d19b50: mov     x1, x19                                    
02d19b54: mov     x3, xzr                                    
02d19b58: bl      #0x453418c                                 fn_453418c
02d19b5c: ldr     x0, [x26]                                  T:Trading.TradingSession/<>c__DisplayClass56_0
02d19b60: bl      #0x2b7104c                                 fn_2b7104c
02d19b64: mov     x23, x0                                    
02d19b68: ldr     x2, [x29]                                  T:Trading.TradingSession/<>c__DisplayClass56_0
02d19b6c: mov     x1, x19                                    
02d19b70: mov     x3, xzr                                    
02d19b74: bl      #0x453418c                                 fn_453418c
02d19b78: cbz     x20, #0x2d19bc0                            
02d19b7c: mov     x0, x20                                    
02d19b80: mov     x1, x21                                    
02d19b84: mov     x2, x22                                    
02d19b88: mov     x3, x23                                    
02d19b8c: bl      #0x2d19c5c                                 DreamHouse.DecorItemUI::AddListeners
02d19b90: b       #0x2d19b10                                 
02d19b94: ldr     x1, [x24]                                  T:Trading.TradingSession/<>c__DisplayClass56_0
02d19b98: add     x0, sp, #0x18                              
02d19b9c: bl      #0x4690470                                 fn_4690470
02d19ba0: ldp     x20, x19, [sp, #0x80]                      
02d19ba4: ldp     x22, x21, [sp, #0x70]                      
02d19ba8: ldp     x24, x23, [sp, #0x60]                      
02d19bac: ldp     x26, x25, [sp, #0x50]                      
02d19bb0: ldp     x28, x27, [sp, #0x40]                      
02d19bb4: ldp     x29, x30, [sp, #0x30]                      
02d19bb8: add     sp, sp, #0x90                              
02d19bbc: ret                                                
02d19bc0: bl      #0x2b7105c                                 fn_2b7105c
02d19bc4: bl      #0x2b7105c                                 fn_2b7105c
02d19bc8: b       #0x2d19bdc                                 
02d19bcc: b       #0x2d19bdc                                 
02d19bd0: b       #0x2d19bdc                                 
02d19bd4: b       #0x2d19bdc                                 
02d19bd8: b       #0x2d19bdc                                 
02d19bdc: mov     x19, x0                                    
02d19be0: cmp     w1, #1                                     
02d19be4: b.ne    #0x2d19c18                                 
02d19be8: mov     x0, x19                                    
02d19bec: bl      #0x5e90260                                 fn_5e90260
02d19bf0: ldr     x19, [x0]                                  T:Trading.TradingSession/<>c__DisplayClass56_0
02d19bf4: str     x19, [sp, #8]                              
02d19bf8: bl      #0x5e90270                                 fn_5e90270
02d19bfc: ldr     x0, [sp, #0x10]                            
02d19c00: ldr     x1, [x24]                                  T:Trading.TradingSession/<>c__DisplayClass56_0
02d19c04: bl      #0x4690470                                 fn_4690470
02d19c08: cbz     x19, #0x2d19ba0                            
02d19c0c: mov     x0, x19                                    
02d19c10: bl      #0x2b71054                                 fn_2b71054
02d19c14: mov     x19, x0                                    
02d19c18: add     x0, sp, #8                                 
02d19c1c: bl      #0x2737fe4                                 fn_2737fe4
02d19c20: mov     x0, x19                                    
02d19c24: bl      #0x2c6051c                                 fn_2c6051c
02d19c28: bl      #0x27369b8                                 fn_27369b8
## OnShow(DreamHouse.DecorItemAsset decorItemAsset) -> void
---- DreamHouse.DecorItemPanel::OnShow 0x2d19370
02d19370: sub     sp, sp, #0x40                              
02d19374: stp     x30, x23, [sp, #0x10]                      
02d19378: stp     x22, x21, [sp, #0x20]                      
02d1937c: stp     x20, x19, [sp, #0x30]                      
02d19380: adrp    x21, #0x662f000                            
02d19384: mov     x20, x1                                    
02d19388: mov     x19, x0                                    
02d1938c: ldrb    w8, [x21, #0xffd]                          
02d19390: tbnz    w8, #0, #0x2d193b4                         
02d19394: adrp    x0, #0x6269000                             
02d19398: ldr     x0, [x0, #0xa90]                           MS:System.Collections.Generic.List`1::get_Count
02d1939c: bl      #0x2b70db0                                 fn_2b70db0
02d193a0: adrp    x0, #0x6269000                             
02d193a4: ldr     x0, [x0, #0xa98]                           MS:System.Collections.Generic.List`1::get_Item
02d193a8: bl      #0x2b70db0                                 fn_2b70db0
02d193ac: mov     w8, #1                                     
02d193b0: strb    w8, [x21, #0xffd]                          
02d193b4: mov     x21, x19                                   
02d193b8: mov     x1, x20                                    
02d193bc: strb    wzr, [sp, #0xc]                            
02d193c0: str     x20, [x21, #0x38]!                         ._decorItemAsset
02d193c4: mov     x0, x21                                    
02d193c8: bl      #0x2b70d54                                 fn_2b70d54
02d193cc: ldur    x0, [x21, #-8]                             
02d193d0: cbz     x0, #0x2d19430                             
02d193d4: adrp    x23, #0x6269000                            
02d193d8: mov     w21, wzr                                   
02d193dc: ldr     x23, [x23, #0xa98]                         MS:System.Collections.Generic.List`1::get_Item
02d193e0: ldr     w8, [x0, #0x18]                            M:Trading.TradingSession::<ValidateTrade>b__57_0
02d193e4: cmp     w21, w8                                    
02d193e8: b.ge    #0x2d19434                                 
02d193ec: ldr     x2, [x23]                                  T:Trading.TradingSession/<>c__DisplayClass56_0
02d193f0: mov     w1, w21                                    
02d193f4: bl      #0x35a8f3c                                 fn_35a8f3c
02d193f8: cbz     x20, #0x2d19430                            
02d193fc: mov     x22, x0                                    
02d19400: mov     x0, x20                                    
02d19404: mov     w1, w21                                    
02d19408: mov     x2, xzr                                    
02d1940c: bl      #0x2d15c80                                 DreamHouse.DecorItemAsset::GetDecorItemConfigByIndex
02d19410: cbz     x22, #0x2d19430                            
02d19414: mov     x1, x0                                     
02d19418: mov     x0, x22                                    
02d1941c: mov     x2, x19                                    
02d19420: bl      #0x2d19e6c                                 DreamHouse.DecorItemUI::OnInit
02d19424: ldr     x0, [x19, #0x30]                           ._items
02d19428: add     w21, w21, #1                               
02d1942c: cbnz    x0, #0x2d193e0                             
02d19430: bl      #0x2b7105c                                 fn_2b7105c
02d19434: movi    d0, #0000000000000000                      
02d19438: ldr     x0, [x19, #0x20]                           ._canvasGroup
02d1943c: mov     w1, #1                                     
02d19440: mov     x2, xzr                                    
02d19444: bl      #0x2cf1928                                 FrameWorkUtility::SetActive
02d19448: mov     x0, x19                                    
02d1944c: bl      #0x2d1a0ac                                 DreamHouse.DecorItemPanel::ShowAnim
02d19450: strb    w0, [sp, #0xc]                             
02d19454: add     x0, sp, #0xc                               
02d19458: mov     x1, xzr                                    
02d1945c: bl      #0x5460194                                 Cysharp.Threading.Tasks.UniTaskVoid::Forget
02d19460: ldp     x20, x19, [sp, #0x30]                      
02d19464: ldp     x22, x21, [sp, #0x20]                      
02d19468: ldp     x30, x23, [sp, #0x10]                      
02d1946c: add     sp, sp, #0x40                              
02d19470: ret                                                
## OnHide() -> void
---- DreamHouse.DecorItemPanel::OnHide 0x2d19c2c
02d19c2c: stp     x30, x19, [sp, #-0x10]!                    
02d19c30: movi    d0, #0000000000000000                      
02d19c34: mov     x19, x0                                    
02d19c38: ldr     x0, [x0, #0x20]                            ._canvasGroup
02d19c3c: mov     w1, wzr                                    
02d19c40: mov     x2, xzr                                    
02d19c44: bl      #0x2cf1928                                 FrameWorkUtility::SetActive
02d19c48: str     xzr, [x19, #0x48]!                         ._selectedItem
02d19c4c: mov     x0, x19                                    
02d19c50: mov     x1, xzr                                    
02d19c54: ldp     x30, x19, [sp], #0x10                      
02d19c58: b       #0x2b70d54                                 
## ShowAnim() -> Cysharp.Threading.Tasks.UniTaskVoid
---- DreamHouse.DecorItemPanel::ShowAnim 0x2d1a0ac
02d1a0ac: sub     sp, sp, #0x60                              
02d1a0b0: stp     x30, x21, [sp, #0x40]                      
02d1a0b4: stp     x20, x19, [sp, #0x50]                      
02d1a0b8: adrp    x21, #0x662f000                            
02d1a0bc: adrp    x20, #0x6269000                            
02d1a0c0: mov     x19, x0                                    
02d1a0c4: ldrb    w8, [x21, #0xffe]                          
02d1a0c8: ldr     x20, [x20, #0xb30]                         MS:Cysharp.Threading.Tasks.CompilerServices.AsyncUniTaskVoidMethodBuilder::Start
02d1a0cc: tbnz    w8, #0, #0x2d1a0e4                         
02d1a0d0: adrp    x0, #0x6269000                             
02d1a0d4: ldr     x0, [x0, #0xb30]                           MS:Cysharp.Threading.Tasks.CompilerServices.AsyncUniTaskVoidMethodBuilder::Start
02d1a0d8: bl      #0x2b70db0                                 fn_2b70db0
02d1a0dc: mov     w8, #1                                     
02d1a0e0: strb    w8, [x21, #0xffe]                          
02d1a0e4: movi    v0.2d, #0000000000000000                   
02d1a0e8: mov     x21, sp                                    
02d1a0ec: mov     x1, xzr                                    
02d1a0f0: orr     x0, x21, #8                                
02d1a0f4: stp     q0, q0, [sp]                               
02d1a0f8: stp     q0, q0, [sp, #0x20]                        
02d1a0fc: bl      #0x2b70d54                                 fn_2b70d54
02d1a100: add     x0, x21, #0x10                             &662f010
02d1a104: mov     x1, x19                                    
02d1a108: str     x19, [sp, #0x10]                           
02d1a10c: bl      #0x2b70d54                                 fn_2b70d54
02d1a110: ldr     x2, [x20]                                  T:Trading.TradingSession/<>c__DisplayClass56_0
02d1a114: mov     w8, #-1                                    
02d1a118: orr     x0, x21, #8                                
02d1a11c: mov     x1, sp                                     
02d1a120: str     w8, [sp]                                   
02d1a124: bl      #0x30b658c                                 fn_30b658c
02d1a128: ldp     x20, x19, [sp, #0x50]                      
02d1a12c: mov     w0, wzr                                    
02d1a130: ldp     x30, x21, [sp, #0x40]                      
02d1a134: add     sp, sp, #0x60                              
02d1a138: ret                                                
## SetInteractableItems(bool isInteractable) -> void
---- DreamHouse.DecorItemPanel::SetInteractableItems 0x2d1a13c
02d1a13c: sub     sp, sp, #0x60                              
02d1a140: str     x30, [sp, #0x30]                           
02d1a144: stp     x22, x21, [sp, #0x40]                      
02d1a148: stp     x20, x19, [sp, #0x50]                      
02d1a14c: adrp    x21, #0x662f000                            
02d1a150: mov     w19, w1                                    
02d1a154: mov     x20, x0                                    
02d1a158: ldrb    w8, [x21, #0xfff]                          
02d1a15c: tbnz    w8, #0, #0x2d1a198                         
02d1a160: adrp    x0, #0x6269000                             
02d1a164: ldr     x0, [x0, #0xae8]                           MS:System.Collections.Generic.List`1/Enumerator::Dispose
02d1a168: bl      #0x2b70db0                                 fn_2b70db0
02d1a16c: adrp    x0, #0x6269000                             
02d1a170: ldr     x0, [x0, #0xaf0]                           MS:System.Collections.Generic.List`1/Enumerator::MoveNext
02d1a174: bl      #0x2b70db0                                 fn_2b70db0
02d1a178: adrp    x0, #0x6269000                             
02d1a17c: ldr     x0, [x0, #0xaf8]                           MS:System.Collections.Generic.List`1/Enumerator::get_Current
02d1a180: bl      #0x2b70db0                                 fn_2b70db0
02d1a184: adrp    x0, #0x6269000                             
02d1a188: ldr     x0, [x0, #0xb00]                           MS:System.Collections.Generic.List`1::GetEnumerator
02d1a18c: bl      #0x2b70db0                                 fn_2b70db0
02d1a190: mov     w8, #1                                     
02d1a194: strb    w8, [x21, #0xfff]                          
02d1a198: ldr     x0, [x20, #0x30]                           ._items
02d1a19c: stp     xzr, xzr, [sp, #0x18]                      
02d1a1a0: str     xzr, [sp, #0x28]                           
02d1a1a4: cbz     x0, #0x2d1a21c                             
02d1a1a8: adrp    x8, #0x6269000                             
02d1a1ac: adrp    x21, #0x6269000                            
02d1a1b0: adrp    x20, #0x6269000                            
02d1a1b4: ldr     x8, [x8, #0xb00]                           MS:System.Collections.Generic.List`1::GetEnumerator
02d1a1b8: ldr     x21, [x21, #0xaf0]                         MS:System.Collections.Generic.List`1/Enumerator::MoveNext
02d1a1bc: ldr     x20, [x20, #0xae8]                         MS:System.Collections.Generic.List`1/Enumerator::Dispose
02d1a1c0: add     x22, sp, #0x18                             
02d1a1c4: ldr     x1, [x8]                                   T:Trading.TradingSession/<>c__DisplayClass56_0
02d1a1c8: add     x8, sp, #0x18                              
02d1a1cc: bl      #0x35a9d9c                                 fn_35a9d9c
02d1a1d0: stp     xzr, x22, [sp, #8]                         
02d1a1d4: ldr     x1, [x21]                                  T:Trading.TradingSession/<>c__DisplayClass56_0
02d1a1d8: add     x0, sp, #0x18                              
02d1a1dc: bl      #0x4690474                                 fn_4690474
02d1a1e0: tbz     w0, #0, #0x2d1a1f8                         
02d1a1e4: ldr     x0, [sp, #0x28]                            
02d1a1e8: cbz     x0, #0x2d1a218                             
02d1a1ec: and     w1, w19, #1                                
02d1a1f0: bl      #0x2d1a278                                 DreamHouse.DecorItemUI::SetInteractable
02d1a1f4: b       #0x2d1a1d4                                 
02d1a1f8: ldr     x1, [x20]                                  T:Trading.TradingSession/<>c__DisplayClass56_0
02d1a1fc: add     x0, sp, #0x18                              
02d1a200: bl      #0x4690470                                 fn_4690470
02d1a204: ldp     x20, x19, [sp, #0x50]                      
02d1a208: ldr     x30, [sp, #0x30]                           
02d1a20c: ldp     x22, x21, [sp, #0x40]                      
02d1a210: add     sp, sp, #0x60                              
02d1a214: ret                                                
02d1a218: bl      #0x2b7105c                                 fn_2b7105c
02d1a21c: bl      #0x2b7105c                                 fn_2b7105c
02d1a220: b       #0x2d1a228                                 
02d1a224: b       #0x2d1a228                                 
02d1a228: mov     x19, x0                                    
02d1a22c: cmp     w1, #1                                     
02d1a230: b.ne    #0x2d1a264                                 
02d1a234: mov     x0, x19                                    
02d1a238: bl      #0x5e90260                                 fn_5e90260
02d1a23c: ldr     x19, [x0]                                  T:Trading.TradingSession/<>c__DisplayClass56_0
02d1a240: str     x19, [sp, #8]                              
02d1a244: bl      #0x5e90270                                 fn_5e90270
02d1a248: ldr     x0, [sp, #0x10]                            
02d1a24c: ldr     x1, [x20]                                  T:Trading.TradingSession/<>c__DisplayClass56_0
02d1a250: bl      #0x4690470                                 fn_4690470
02d1a254: cbz     x19, #0x2d1a204                            
02d1a258: mov     x0, x19                                    
02d1a25c: bl      #0x2b71054                                 fn_2b71054
02d1a260: mov     x19, x0                                    
02d1a264: add     x0, sp, #8                                 
02d1a268: bl      #0x2737fe4                                 fn_2737fe4
02d1a26c: mov     x0, x19                                    
02d1a270: bl      #0x2c6051c                                 fn_2c6051c
02d1a274: bl      #0x27369b8                                 fn_27369b8
## SetSelectedItem(DreamHouse.DecorItemUI selectedItem) -> void
---- DreamHouse.DecorItemPanel::SetSelectedItem 0x2d1a2e4
02d1a2e4: str     x30, [sp, #-0x30]!                         
02d1a2e8: stp     x22, x21, [sp, #0x10]                      
02d1a2ec: stp     x20, x19, [sp, #0x20]                      
02d1a2f0: adrp    x21, #0x6630000                            
02d1a2f4: adrp    x22, #0x6263000                            
02d1a2f8: mov     x19, x1                                    
02d1a2fc: ldrb    w8, [x21]                                  
02d1a300: ldr     x22, [x22, #0x918]                         T:UnityEngine.Object
02d1a304: mov     x20, x0                                    
02d1a308: tbnz    w8, #0, #0x2d1a320                         
02d1a30c: adrp    x0, #0x6263000                             
02d1a310: ldr     x0, [x0, #0x918]                           T:UnityEngine.Object
02d1a314: bl      #0x2b70db0                                 fn_2b70db0
02d1a318: mov     w8, #1                                     
02d1a31c: strb    w8, [x21]                                  
02d1a320: ldr     x0, [x22]                                  &2c5bbd4(=a9bd7bfdd503233f)
02d1a324: ldr     x21, [x20, #0x48]!                         ._selectedItem
02d1a328: ldr     w8, [x0, #0xe4]                            [62630e4]=0 f=0,0
02d1a32c: cbnz    w8, #0x2d1a334                             
02d1a330: bl      #0x2b70f30                                 fn_2b70f30
02d1a334: mov     x0, x21                                    
02d1a338: mov     x1, xzr                                    
02d1a33c: mov     x2, xzr                                    
02d1a340: bl      #0x5b3666c                                 UnityEngine.Object::op_Inequality
02d1a344: tbz     w0, #0, #0x2d1a38c                         
02d1a348: ldr     x0, [x22]                                  &2c5bbd4(=a9bd7bfdd503233f)
02d1a34c: ldr     x21, [x20]                                 
02d1a350: ldr     w8, [x0, #0xe4]                            [62630e4]=0 f=0,0
02d1a354: cbnz    w8, #0x2d1a35c                             
02d1a358: bl      #0x2b70f30                                 fn_2b70f30
02d1a35c: mov     x0, x21                                    
02d1a360: mov     x1, x19                                    
02d1a364: mov     x2, xzr                                    
02d1a368: bl      #0x5b3666c                                 UnityEngine.Object::op_Inequality
02d1a36c: tbz     w0, #0, #0x2d1a38c                         
02d1a370: ldr     x8, [x20]                                  
02d1a374: cbz     x8, #0x2d1a3c4                             
02d1a378: ldr     x0, [x8, #0x50]                            
02d1a37c: cbz     x0, #0x2d1a3c4                             
02d1a380: mov     w1, wzr                                    
02d1a384: mov     x2, xzr                                    
02d1a388: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d1a38c: mov     x0, x20                                    
02d1a390: mov     x1, x19                                    
02d1a394: str     x19, [x20]                                 
02d1a398: bl      #0x2b70d54                                 fn_2b70d54
02d1a39c: ldr     x8, [x20]                                  
02d1a3a0: cbz     x8, #0x2d1a3c4                             
02d1a3a4: ldr     x0, [x8, #0x50]                            
02d1a3a8: cbz     x0, #0x2d1a3c4                             
02d1a3ac: ldp     x20, x19, [sp, #0x20]                      
02d1a3b0: mov     w1, #1                                     
02d1a3b4: ldp     x22, x21, [sp, #0x10]                      
02d1a3b8: mov     x2, xzr                                    
02d1a3bc: ldr     x30, [sp], #0x30                           
02d1a3c0: b       #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d1a3c4: bl      #0x2b7105c                                 fn_2b7105c
## CreateDecorItemObject(DreamHouse.DecorItemUI selectedItem) -> void
---- DreamHouse.DecorItemPanel::CreateDecorItemObject 0x2d1a3e4
02d1a3e4: stp     x30, x21, [sp, #-0x20]!                    
02d1a3e8: stp     x20, x19, [sp, #0x10]                      
02d1a3ec: adrp    x21, #0x6630000                            
02d1a3f0: mov     x20, x1                                    
02d1a3f4: mov     x19, x0                                    
02d1a3f8: ldrb    w8, [x21, #1]                              
02d1a3fc: tbnz    w8, #0, #0x2d1a420                         
02d1a400: adrp    x0, #0x6269000                             
02d1a404: ldr     x0, [x0, #0xb38]                           MS:System.Collections.Generic.List`1::IndexOf
02d1a408: bl      #0x2b70db0                                 fn_2b70db0
02d1a40c: adrp    x0, #0x6269000                             
02d1a410: ldr     x0, [x0, #0xa80]                           MS:MonoSingleton`1::get_Instance
02d1a414: bl      #0x2b70db0                                 fn_2b70db0
02d1a418: mov     w8, #1                                     
02d1a41c: strb    w8, [x21, #1]                              
02d1a420: ldr     x0, [x19, #0x30]                           ._items
02d1a424: cbz     x0, #0x2d1a518                             
02d1a428: adrp    x8, #0x6269000                             
02d1a42c: mov     x1, x20                                    
02d1a430: ldr     x8, [x8, #0xb38]                           MS:System.Collections.Generic.List`1::IndexOf
02d1a434: ldr     x2, [x8]                                   T:Trading.TradingSession/<>c__DisplayClass56_0
02d1a438: bl      #0x35a9f48                                 fn_35a9f48
02d1a43c: ldr     x8, [x19, #0x40]                           ._dreamHouseController
02d1a440: cbz     x8, #0x2d1a518                             
02d1a444: ldr     x8, [x8, #0x40]                            MS:System.Linq.Enumerable::Select
02d1a448: cbz     x8, #0x2d1a518                             
02d1a44c: mov     w1, w0                                     
02d1a450: ldr     x0, [x8, #0x50]                            T:type10817(k15)
02d1a454: cbz     x0, #0x2d1a518                             
02d1a458: mov     x2, xzr                                    
02d1a45c: bl      #0x2d1764c                                 DreamHouse.DecorItem::CreateDecorItemObject
02d1a460: ldr     x0, [x19, #0x28]                           ._decorItemEffect
02d1a464: cbz     x0, #0x2d1a518                             
02d1a468: mov     x1, xzr                                    
02d1a46c: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02d1a470: ldr     x8, [x19, #0x40]                           ._dreamHouseController
02d1a474: cbz     x8, #0x2d1a518                             
02d1a478: ldr     x8, [x8, #0x40]                            MS:System.Linq.Enumerable::Select
02d1a47c: cbz     x8, #0x2d1a518                             
02d1a480: mov     x20, x0                                    
02d1a484: ldr     x0, [x8, #0x50]                            T:type10817(k15)
02d1a488: cbz     x0, #0x2d1a518                             
02d1a48c: mov     x1, xzr                                    
02d1a490: bl      #0x2d1794c                                 DreamHouse.DecorItem::GetMarkPointPos
02d1a494: cbz     x20, #0x2d1a518                            
02d1a498: mov     x0, x20                                    
02d1a49c: mov     x1, xzr                                    
02d1a4a0: bl      #0x5b46888                                 UnityEngine.Transform::set_position
02d1a4a4: ldr     x0, [x19, #0x28]                           ._decorItemEffect
02d1a4a8: cbz     x0, #0x2d1a518                             
02d1a4ac: adrp    x19, #0x6269000                            
02d1a4b0: mov     x1, xzr                                    
02d1a4b4: ldr     x19, [x19, #0xa80]                         MS:MonoSingleton`1::get_Instance
02d1a4b8: bl      #0x5bba8cc                                 UnityEngine.ParticleSystem::Play
02d1a4bc: ldr     x0, [x19]                                  T:Trading.TradingSession/<>c__DisplayClass56_0
02d1a4c0: bl      #0x3769600                                 fn_3769600
02d1a4c4: cbz     x0, #0x2d1a518                             
02d1a4c8: mov     w1, #1                                     
02d1a4cc: mov     w2, wzr                                    
02d1a4d0: bl      #0x2d19814                                 DreamHouse.TutorialHandler::SetActiveHandTutorial
02d1a4d4: ldr     x0, [x19]                                  T:Trading.TradingSession/<>c__DisplayClass56_0
02d1a4d8: bl      #0x3769600                                 fn_3769600
02d1a4dc: cbz     x0, #0x2d1a518                             
02d1a4e0: bl      #0x2d19968                                 DreamHouse.TutorialHandler::DoneTutorial
02d1a4e4: mov     x0, xzr                                    
02d1a4e8: bl      #0x2d6eec8                                 Framework.AudioManager::get_Instance
02d1a4ec: cbz     x0, #0x2d1a518                             
02d1a4f0: ldp     x20, x19, [sp, #0x10]                      
02d1a4f4: movi    d1, #0000000000000000                      
02d1a4f8: movi    d2, #0000000000000000                      
02d1a4fc: fmov    s0, #1.00000000                            
02d1a500: mov     w1, #0x1f                                  
02d1a504: mov     w2, wzr                                    
02d1a508: mov     w3, wzr                                    
02d1a50c: mov     x4, xzr                                    
02d1a510: ldp     x30, x21, [sp], #0x20                      
02d1a514: b       #0x2d6f03c                                 Framework.AudioManager::PlaySound
02d1a518: bl      #0x2b7105c                                 fn_2b7105c
## OnSelectButtonClicked(DreamHouse.DecorItemUI selectedItem) -> void
---- DreamHouse.DecorItemPanel::OnSelectButtonClicked 0x2d1a51c
02d1a51c: str     x30, [sp, #-0x30]!                         
02d1a520: stp     x22, x21, [sp, #0x10]                      
02d1a524: stp     x20, x19, [sp, #0x20]                      
02d1a528: adrp    x21, #0x6630000                            
02d1a52c: adrp    x22, #0x6266000                            
02d1a530: mov     x19, x1                                    
02d1a534: ldrb    w8, [x21, #2]                              
02d1a538: ldr     x22, [x22, #0x658]                         MS:MonoSingleton`1::get_Instance
02d1a53c: mov     x20, x0                                    
02d1a540: tbnz    w8, #0, #0x2d1a564                         
02d1a544: adrp    x0, #0x6266000                             
02d1a548: ldr     x0, [x0, #0x750]                           MS:DataManager::GetData
02d1a54c: bl      #0x2b70db0                                 fn_2b70db0
02d1a550: adrp    x0, #0x6266000                             
02d1a554: ldr     x0, [x0, #0x658]                           MS:MonoSingleton`1::get_Instance
02d1a558: bl      #0x2b70db0                                 fn_2b70db0
02d1a55c: mov     w8, #1                                     
02d1a560: strb    w8, [x21, #2]                              
02d1a564: ldr     x0, [x22]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d1a568: bl      #0x3769600                                 fn_3769600
02d1a56c: cbz     x0, #0x2d1a618                             
02d1a570: adrp    x8, #0x6266000                             
02d1a574: ldr     x8, [x8, #0x750]                           MS:DataManager::GetData
02d1a578: ldr     x1, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d1a57c: bl      #0x3168dd0                                 fn_3168dd0
02d1a580: cbz     x0, #0x2d1a618                             
02d1a584: ldr     x8, [x0, #0x20]                            S:'inter_ad_capping_time' ._canvasGroup
02d1a588: cbz     x8, #0x2d1a618                             
02d1a58c: ldrb    w9, [x8, #0x43]                            
02d1a590: cbnz    w9, #0x2d1a5ac                             
02d1a594: mov     w9, #1                                     
02d1a598: strb    w9, [x8, #0x43]                            
02d1a59c: ldr     x8, [x0]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d1a5a0: ldr     x9, [x8, #0x258]                           MS:System.Collections.Generic.List`1/Enumerator::Dispose
02d1a5a4: ldr     x1, [x8, #0x260]                           MS:System.Collections.Generic.List`1/Enumerator::MoveNext
02d1a5a8: blr     x9                                         
02d1a5ac: cbz     x19, #0x2d1a618                            
02d1a5b0: ldrb    w8, [x19, #0x80]                           
02d1a5b4: cbz     w8, #0x2d1a5c8                             
02d1a5b8: ldp     x20, x19, [sp, #0x20]                      
02d1a5bc: ldp     x22, x21, [sp, #0x10]                      
02d1a5c0: ldr     x30, [sp], #0x30                           
02d1a5c4: ret                                                
02d1a5c8: mov     x0, xzr                                    
02d1a5cc: bl      #0x2d6eec8                                 Framework.AudioManager::get_Instance
02d1a5d0: cbz     x0, #0x2d1a618                             
02d1a5d4: movi    d1, #0000000000000000                      
02d1a5d8: movi    d2, #0000000000000000                      
02d1a5dc: mov     w1, #1                                     
02d1a5e0: fmov    s0, #1.00000000                            
02d1a5e4: mov     w2, wzr                                    
02d1a5e8: mov     w3, wzr                                    
02d1a5ec: mov     x4, xzr                                    
02d1a5f0: bl      #0x2d6f03c                                 Framework.AudioManager::PlaySound
02d1a5f4: mov     x0, x20                                    
02d1a5f8: mov     x1, x19                                    
02d1a5fc: bl      #0x2d1a3e4                                 DreamHouse.DecorItemPanel::CreateDecorItemObject
02d1a600: mov     x0, x20                                    
02d1a604: mov     x1, x19                                    
02d1a608: ldp     x20, x19, [sp, #0x20]                      
02d1a60c: ldp     x22, x21, [sp, #0x10]                      
02d1a610: ldr     x30, [sp], #0x30                           
02d1a614: b       #0x2d1a2e4                                 DreamHouse.DecorItemPanel::SetSelectedItem
02d1a618: bl      #0x2b7105c                                 fn_2b7105c
## OnCoinButtonClicked(DreamHouse.DecorItemUI selectedItem) -> void
---- DreamHouse.DecorItemPanel::OnCoinButtonClicked 0x2d1a61c
02d1a61c: stp     x30, x23, [sp, #-0x30]!                    
02d1a620: stp     x22, x21, [sp, #0x10]                      
02d1a624: stp     x20, x19, [sp, #0x20]                      
02d1a628: adrp    x21, #0x6630000                            
02d1a62c: mov     x20, x1                                    
02d1a630: mov     x19, x0                                    
02d1a634: ldrb    w8, [x21, #3]                              
02d1a638: tbnz    w8, #0, #0x2d1a68c                         
02d1a63c: adrp    x0, #0x6266000                             
02d1a640: ldr     x0, [x0, #0x750]                           MS:DataManager::GetData
02d1a644: bl      #0x2b70db0                                 fn_2b70db0
02d1a648: adrp    x0, #0x6269000                             
02d1a64c: ldr     x0, [x0, #0xb38]                           MS:System.Collections.Generic.List`1::IndexOf
02d1a650: bl      #0x2b70db0                                 fn_2b70db0
02d1a654: adrp    x0, #0x6267000                             
02d1a658: ldr     x0, [x0, #0xbd0]                           MS:MonoSingleton`1::get_Instance
02d1a65c: bl      #0x2b70db0                                 fn_2b70db0
02d1a660: adrp    x0, #0x6266000                             
02d1a664: ldr     x0, [x0, #0xaa0]                           MS:MonoSingleton`1::get_Instance
02d1a668: bl      #0x2b70db0                                 fn_2b70db0
02d1a66c: adrp    x0, #0x6266000                             
02d1a670: ldr     x0, [x0, #0x658]                           MS:MonoSingleton`1::get_Instance
02d1a674: bl      #0x2b70db0                                 fn_2b70db0
02d1a678: adrp    x0, #0x6269000                             
02d1a67c: ldr     x0, [x0, #0xb40]                           MS:UIManager::ShowPopup
02d1a680: bl      #0x2b70db0                                 fn_2b70db0
02d1a684: mov     w8, #1                                     
02d1a688: strb    w8, [x21, #3]                              
02d1a68c: mov     x0, xzr                                    
02d1a690: bl      #0x2d6eec8                                 Framework.AudioManager::get_Instance
02d1a694: cbz     x0, #0x2d1a864                             
02d1a698: movi    d1, #0000000000000000                      
02d1a69c: movi    d2, #0000000000000000                      
02d1a6a0: adrp    x21, #0x6266000                            
02d1a6a4: fmov    s0, #1.00000000                            
02d1a6a8: ldr     x21, [x21, #0x658]                         MS:MonoSingleton`1::get_Instance
02d1a6ac: mov     w1, #1                                     
02d1a6b0: mov     w2, wzr                                    
02d1a6b4: mov     w3, wzr                                    
02d1a6b8: mov     x4, xzr                                    
02d1a6bc: bl      #0x2d6f03c                                 Framework.AudioManager::PlaySound
02d1a6c0: ldr     x0, [x21]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d1a6c4: bl      #0x3769600                                 fn_3769600
02d1a6c8: cbz     x0, #0x2d1a864                             
02d1a6cc: adrp    x22, #0x6266000                            
02d1a6d0: ldr     x22, [x22, #0x750]                         MS:DataManager::GetData
02d1a6d4: ldr     x1, [x22]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d1a6d8: bl      #0x3168dd0                                 fn_3168dd0
02d1a6dc: cbz     x0, #0x2d1a864                             
02d1a6e0: ldr     x8, [x0, #0x20]                            M:Trading.TradingSession::<ValidateTrade>b__57_1 ._canvasGroup
02d1a6e4: cbz     x8, #0x2d1a864                             
02d1a6e8: ldrb    w9, [x8, #0x43]                            
02d1a6ec: cbnz    w9, #0x2d1a708                             
02d1a6f0: mov     w9, #1                                     
02d1a6f4: strb    w9, [x8, #0x43]                            
02d1a6f8: ldr     x8, [x0]                                   T:Trading.TradingSession/<>c__DisplayClass56_0
02d1a6fc: ldr     x9, [x8, #0x258]                           
02d1a700: ldr     x1, [x8, #0x260]                           
02d1a704: blr     x9                                         
02d1a708: cbz     x20, #0x2d1a864                            
02d1a70c: ldr     x0, [x21]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d1a710: ldr     w23, [x20, #0x84]                          
02d1a714: bl      #0x3769600                                 fn_3769600
02d1a718: cbz     x0, #0x2d1a864                             
02d1a71c: ldr     x1, [x22]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d1a720: bl      #0x3168dd0                                 fn_3168dd0
02d1a724: cbz     x0, #0x2d1a864                             
02d1a728: mov     x1, xzr                                    
02d1a72c: bl      #0x2cabaf8                                 DataUser::GetMoney
02d1a730: cmp     w23, w0                                    
02d1a734: b.le    #0x2d1a768                                 
02d1a738: adrp    x8, #0x6267000                             
02d1a73c: ldr     x8, [x8, #0xbd0]                           MS:MonoSingleton`1::get_Instance
02d1a740: ldr     x0, [x8]                                   S:'didu'
02d1a744: bl      #0x3769600                                 fn_3769600
02d1a748: cbz     x0, #0x2d1a864                             
02d1a74c: adrp    x8, #0x6269000                             
02d1a750: ldr     x8, [x8, #0xb40]                           MS:UIManager::ShowPopup
02d1a754: ldp     x20, x19, [sp, #0x20]                      
02d1a758: ldp     x22, x21, [sp, #0x10]                      
02d1a75c: ldr     x1, [x8]                                   T:Trading.TradingSession/<>c__DisplayClass56_0
02d1a760: ldp     x30, x23, [sp], #0x30                      
02d1a764: b       #0x33fbfac                                 
02d1a768: adrp    x8, #0x6266000                             
02d1a76c: ldr     x8, [x8, #0xaa0]                           MS:MonoSingleton`1::get_Instance
02d1a770: ldr     x0, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d1a774: bl      #0x3769600                                 fn_3769600
02d1a778: cbz     x0, #0x2d1a864                             
02d1a77c: ldr     w8, [x20, #0x84]                           
02d1a780: mov     x2, xzr                                    
02d1a784: neg     w1, w8                                     
02d1a788: bl      #0x2cdac78                                 MoneyManager::UpdateMoney
02d1a78c: mov     x0, xzr                                    
02d1a790: bl      #0x2d6eec8                                 Framework.AudioManager::get_Instance
02d1a794: cbz     x0, #0x2d1a864                             
02d1a798: movi    d1, #0000000000000000                      
02d1a79c: movi    d2, #0000000000000000                      
02d1a7a0: mov     w1, #0x2f                                  
02d1a7a4: fmov    s0, #1.00000000                            
02d1a7a8: mov     w2, wzr                                    
02d1a7ac: mov     w3, wzr                                    
02d1a7b0: mov     x4, xzr                                    
02d1a7b4: bl      #0x2d6f03c                                 Framework.AudioManager::PlaySound
02d1a7b8: mov     x0, x19                                    
02d1a7bc: mov     w1, wzr                                    
02d1a7c0: bl      #0x2d1a13c                                 DreamHouse.DecorItemPanel::SetInteractableItems
02d1a7c4: mov     x0, x19                                    
02d1a7c8: mov     x1, x20                                    
02d1a7cc: bl      #0x2d1a3e4                                 DreamHouse.DecorItemPanel::CreateDecorItemObject
02d1a7d0: mov     x0, x20                                    
02d1a7d4: bl      #0x2d1a868                                 DreamHouse.DecorItemUI::Unlocked
02d1a7d8: mov     x0, x19                                    
02d1a7dc: mov     x1, x20                                    
02d1a7e0: bl      #0x2d1a2e4                                 DreamHouse.DecorItemPanel::SetSelectedItem
02d1a7e4: movi    d0, #0000000000000000                      
02d1a7e8: ldr     x0, [x19, #0x20]                           ._canvasGroup
02d1a7ec: mov     w1, wzr                                    
02d1a7f0: mov     x2, xzr                                    
02d1a7f4: bl      #0x2cf1928                                 FrameWorkUtility::SetActive
02d1a7f8: mov     x21, x19                                   
02d1a7fc: mov     x1, xzr                                    
02d1a800: str     xzr, [x21, #0x48]!                         ._selectedItem
02d1a804: mov     x0, x21                                    
02d1a808: bl      #0x2b70d54                                 fn_2b70d54
02d1a80c: ldur    x0, [x21, #-0x18]                          
02d1a810: cbz     x0, #0x2d1a864                             
02d1a814: adrp    x8, #0x6269000                             
02d1a818: mov     x1, x20                                    
02d1a81c: ldr     x8, [x8, #0xb38]                           MS:System.Collections.Generic.List`1::IndexOf
02d1a820: ldr     x2, [x8]                                   T:Trading.TradingSession/<>c__DisplayClass56_0
02d1a824: bl      #0x35a9f48                                 fn_35a9f48
02d1a828: ldr     x8, [x19, #0x40]                           ._dreamHouseController
02d1a82c: cbz     x8, #0x2d1a864                             
02d1a830: mov     w1, w0                                     
02d1a834: mov     x0, x8                                     
02d1a838: mov     x2, xzr                                    
02d1a83c: bl      #0x2d18408                                 DreamHouse.DreamHouseController::SaveCurrentRoomStep
02d1a840: ldr     x8, [x19, #0x40]                           ._dreamHouseController
02d1a844: cbz     x8, #0x2d1a864                             
02d1a848: ldr     x0, [x8, #0x40]                            MS:System.Linq.Enumerable::Select
02d1a84c: cbz     x0, #0x2d1a864                             
02d1a850: ldp     x20, x19, [sp, #0x20]                      
02d1a854: mov     x1, xzr                                    
02d1a858: ldp     x22, x21, [sp, #0x10]                      
02d1a85c: ldp     x30, x23, [sp], #0x30                      
02d1a860: b       #0x2d18b44                                 DreamHouse.RoomController::NextStep
02d1a864: bl      #0x2b7105c                                 fn_2b7105c
## OnAdsButtonClicked(DreamHouse.DecorItemUI selectedItem) -> void
---- DreamHouse.DecorItemPanel::OnAdsButtonClicked 0x2d1a8e0
02d1a8e0: str     x30, [sp, #-0x30]!                         
02d1a8e4: stp     x22, x21, [sp, #0x10]                      
02d1a8e8: stp     x20, x19, [sp, #0x20]                      
02d1a8ec: adrp    x19, #0x6630000                            
02d1a8f0: adrp    x22, #0x6269000                            
02d1a8f4: mov     x20, x1                                    
02d1a8f8: ldrb    w8, [x19, #4]                              
02d1a8fc: ldr     x22, [x22, #0xb48]                         T:DreamHouse.DecorItemPanel/<>c__DisplayClass15_0
02d1a900: mov     x21, x0                                    
02d1a904: tbnz    w8, #0, #0x2d1a94c                         
02d1a908: adrp    x0, #0x6264000                             
02d1a90c: ldr     x0, [x0, #0xf90]                           T:System.Action
02d1a910: bl      #0x2b70db0                                 fn_2b70db0
02d1a914: adrp    x0, #0x6265000                             
02d1a918: ldr     x0, [x0, #0x310]                           MS:WejoyService.Singleton`1::get_Instance
02d1a91c: bl      #0x2b70db0                                 fn_2b70db0
02d1a920: adrp    x0, #0x6269000                             
02d1a924: ldr     x0, [x0, #0xb50]                           M:DreamHouse.DecorItemPanel/<>c__DisplayClass15_0::<OnAdsButtonClicked>b__0
02d1a928: bl      #0x2b70db0                                 fn_2b70db0
02d1a92c: adrp    x0, #0x6269000                             
02d1a930: ldr     x0, [x0, #0xb48]                           T:DreamHouse.DecorItemPanel/<>c__DisplayClass15_0
02d1a934: bl      #0x2b70db0                                 fn_2b70db0
02d1a938: adrp    x0, #0x6269000                             
02d1a93c: ldr     x0, [x0, #0xb58]                           S:'unlock_decor'
02d1a940: bl      #0x2b70db0                                 fn_2b70db0
02d1a944: mov     w8, #1                                     
02d1a948: strb    w8, [x19, #4]                              
02d1a94c: ldr     x0, [x22]                                  T:Trading.TradingSession/<>c__DisplayClass56_0
02d1a950: bl      #0x2b7104c                                 fn_2b7104c
02d1a954: mov     x1, xzr                                    
02d1a958: mov     x19, x0                                    
02d1a95c: bl      #0x4e53e9c                                 System.Object::.ctor
02d1a960: cbz     x19, #0x2d1aa4c                            
02d1a964: mov     x0, x19                                    
02d1a968: mov     x1, x21                                    
02d1a96c: str     x21, [x0, #0x10]!                          
02d1a970: bl      #0x2b70d54                                 fn_2b70d54
02d1a974: mov     x0, x19                                    
02d1a978: mov     x1, x20                                    
02d1a97c: str     x20, [x0, #0x18]!                          
02d1a980: bl      #0x2b70d54                                 fn_2b70d54
02d1a984: mov     x0, xzr                                    
02d1a988: bl      #0x2d6eec8                                 Framework.AudioManager::get_Instance
02d1a98c: cbz     x0, #0x2d1aa4c                             
02d1a990: movi    d1, #0000000000000000                      
02d1a994: movi    d2, #0000000000000000                      
02d1a998: mov     w1, #1                                     
02d1a99c: fmov    s0, #1.00000000                            
02d1a9a0: mov     w2, wzr                                    
02d1a9a4: mov     w3, wzr                                    
02d1a9a8: mov     x4, xzr                                    
02d1a9ac: bl      #0x2d6f03c                                 Framework.AudioManager::PlaySound
02d1a9b0: mov     x0, xzr                                    
02d1a9b4: bl      #0x2d6eec8                                 Framework.AudioManager::get_Instance
02d1a9b8: cbz     x0, #0x2d1aa4c                             
02d1a9bc: movi    d1, #0000000000000000                      
02d1a9c0: movi    d2, #0000000000000000                      
02d1a9c4: adrp    x20, #0x6265000                            
02d1a9c8: fmov    s0, #1.00000000                            
02d1a9cc: adrp    x21, #0x6264000                            
02d1a9d0: adrp    x22, #0x6269000                            
02d1a9d4: ldr     x20, [x20, #0x310]                         MS:WejoyService.Singleton`1::get_Instance
02d1a9d8: ldr     x21, [x21, #0xf90]                         T:System.Action
02d1a9dc: ldr     x22, [x22, #0xb50]                         M:DreamHouse.DecorItemPanel/<>c__DisplayClass15_0::<OnAdsButtonClicked>b__0
02d1a9e0: mov     w1, #0x2f                                  
02d1a9e4: mov     w2, wzr                                    
02d1a9e8: mov     w3, wzr                                    
02d1a9ec: mov     x4, xzr                                    
02d1a9f0: bl      #0x2d6f03c                                 Framework.AudioManager::PlaySound
02d1a9f4: ldr     x0, [x20]                                  M:AdsManager::<OnApplicationPause>b__26_0
02d1a9f8: bl      #0x3be7218                                 fn_3be7218
02d1a9fc: ldr     x8, [x21]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d1aa00: mov     x20, x0                                    
02d1aa04: mov     x0, x8                                     
02d1aa08: bl      #0x2b7104c                                 fn_2b7104c
02d1aa0c: ldr     x2, [x22]                                  T:Trading.TradingSession/<>c__DisplayClass56_0
02d1aa10: mov     x1, x19                                    
02d1aa14: mov     x3, xzr                                    
02d1aa18: mov     x21, x0                                    
02d1aa1c: bl      #0x4d8ddbc                                 System.Action::.ctor
02d1aa20: cbz     x20, #0x2d1aa4c                            
02d1aa24: adrp    x8, #0x6269000                             
02d1aa28: mov     x0, x20                                    
02d1aa2c: mov     x2, x21                                    
02d1aa30: ldr     x8, [x8, #0xb58]                           S:'unlock_decor'
02d1aa34: ldp     x20, x19, [sp, #0x20]                      
02d1aa38: ldp     x22, x21, [sp, #0x10]                      
02d1aa3c: mov     x3, xzr                                    
02d1aa40: ldr     x1, [x8]                                   T:Trading.TradingSession/<>c__DisplayClass56_0
02d1aa44: ldr     x30, [sp], #0x30                           
02d1aa48: b       #0x2c8a2c0                                 AdsManager::ShowRewarded
02d1aa4c: bl      #0x2b7105c                                 fn_2b7105c
## .ctor() -> void
---- DreamHouse.DecorItemPanel::.ctor 0x2d1aa58
02d1aa58: mov     x1, xzr                                    
02d1aa5c: b       #0x5b397b0                                 UnityEngine.MonoBehaviour::.ctor
