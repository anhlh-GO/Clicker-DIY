#### CLASS BlindBagCollection.CollectionNaviagationButton parent= UnityEngine.MonoBehaviour
#   field _onClick                       System.Action                                      off=0x20 attr=1 
#   field _canPress                      bool                                               off=0x28 attr=1 
## SetCanPress(bool canPress) -> void
---- BlindBagCollection.CollectionNaviagationButton::SetCanPress 0x2d3af44
02d3af44: strb    w1, [x0, #0x28]                            ._canPress
02d3af48: ret                                                
## AddListener(System.Action onClick) -> void
---- BlindBagCollection.CollectionNaviagationButton::AddListener 0x2d3af4c
02d3af4c: str     x1, [x0, #0x20]!                           ._onClick
02d3af50: b       #0x2b70d54                                 
## OnPointerDown(UnityEngine.EventSystems.PointerEventData eventData) -> void
---- BlindBagCollection.CollectionNaviagationButton::OnPointerDown 0x2d3af54
02d3af54: ldrb    w8, [x0, #0x28]                            ._canPress
02d3af58: cbz     w8, #0x2d3af74                             
02d3af5c: ldr     x8, [x0, #0x20]                            ._onClick
02d3af60: cbz     x8, #0x2d3af74                             
02d3af64: ldr     x0, [x8, #0x40]                            
02d3af68: ldr     x1, [x8, #0x28]                            
02d3af6c: ldr     x2, [x8, #0x18]                            
02d3af70: br      x2                                         
02d3af74: ret                                                
## .ctor() -> void
---- BlindBagCollection.CollectionNaviagationButton::.ctor 0x2d3af78
02d3af78: mov     w8, #1                                     
02d3af7c: mov     x1, xzr                                    
02d3af80: strb    w8, [x0, #0x28]                            ._canPress
02d3af84: b       #0x5b397b0                                 UnityEngine.MonoBehaviour::.ctor
