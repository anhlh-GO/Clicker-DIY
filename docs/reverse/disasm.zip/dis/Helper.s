#### CLASS Helper parent= object
## GetWorldMousePosition2D() -> UnityEngine.Vector2
---- Helper::GetWorldMousePosition2D 0x2cf25ec
02cf25ec: stp     x30, x19, [sp, #-0x10]!                    
02cf25f0: mov     x0, xzr                                    
02cf25f4: bl      #0x5aefe28                                 UnityEngine.Camera::get_main
02cf25f8: mov     x19, x0                                    
02cf25fc: mov     x0, xzr                                    
02cf2600: bl      #0x5bb7d60                                 UnityEngine.Input::get_mousePosition
02cf2604: cbz     x19, #0x2cf2618                            
02cf2608: mov     x0, x19                                    
02cf260c: mov     x1, xzr                                    
02cf2610: ldp     x30, x19, [sp], #0x10                      
02cf2614: b       #0x5aefbb0                                 UnityEngine.Camera::ScreenToWorldPoint
02cf2618: bl      #0x2b7105c                                 fn_2b7105c
## IsPointerOverUIElement() -> bool
---- Helper::IsPointerOverUIElement 0x2cf261c
02cf261c: str     x30, [sp, #-0x10]!                         
02cf2620: bl      #0x2cf262c                                 Helper::GetEventSystemRaycastResults
02cf2624: ldr     x30, [sp], #0x10                           
02cf2628: b       #0x2cf2728                                 Helper::IsPointerOverUIElement
## IsPointerOverUIElement(System.Collections.Generic.List`1<UnityEngine.EventSystems.RaycastResult> eventSystemRaysastResults) -> bool
---- Helper::IsPointerOverUIElement 0x2cf2728
02cf2728: sub     sp, sp, #0xb0                              
02cf272c: str     x30, [sp, #0x70]                           
02cf2730: stp     x24, x23, [sp, #0x80]                      
02cf2734: stp     x22, x21, [sp, #0x90]                      
02cf2738: stp     x20, x19, [sp, #0xa0]                      
02cf273c: adrp    x20, #0x662f000                            
02cf2740: mov     x19, x0                                    
02cf2744: ldrb    w8, [x20, #0xe68]                          
02cf2748: tbnz    w8, #0, #0x2cf2778                         
02cf274c: adrp    x0, #0x6267000                             
02cf2750: ldr     x0, [x0, #0x908]                           MS:System.Collections.Generic.List`1::get_Count
02cf2754: bl      #0x2b70db0                                 fn_2b70db0
02cf2758: adrp    x0, #0x6267000                             
02cf275c: ldr     x0, [x0, #0x910]                           MS:System.Collections.Generic.List`1::get_Item
02cf2760: bl      #0x2b70db0                                 fn_2b70db0
02cf2764: adrp    x0, #0x6267000                             
02cf2768: ldr     x0, [x0, #0x920]                           S:'UI'
02cf276c: bl      #0x2b70db0                                 fn_2b70db0
02cf2770: mov     w8, #1                                     
02cf2774: strb    w8, [x20, #0xe68]                          
02cf2778: cbz     x19, #0x2cf2814                            
02cf277c: ldr     w8, [x19, #0x18]                           
02cf2780: cmp     w8, #0                                     
02cf2784: cset    w22, gt                                    
02cf2788: cmp     w8, #1                                     
02cf278c: b.lt    #0x2cf27f8                                 
02cf2790: adrp    x23, #0x6267000                            
02cf2794: adrp    x24, #0x6267000                            
02cf2798: mov     w20, wzr                                   
02cf279c: ldr     x23, [x23, #0x910]                         MS:System.Collections.Generic.List`1::get_Item
02cf27a0: ldr     x24, [x24, #0x920]                         S:'UI'
02cf27a4: ldr     x2, [x23]                                  S:'didu'
02cf27a8: mov     x8, sp                                     
02cf27ac: mov     x0, x19                                    
02cf27b0: mov     w1, w20                                    
02cf27b4: bl      #0x35ce588                                 fn_35ce588
02cf27b8: ldr     x0, [sp]                                   
02cf27bc: cbz     x0, #0x2cf2814                             
02cf27c0: mov     x1, xzr                                    
02cf27c4: bl      #0x5b369c0                                 UnityEngine.GameObject::get_layer
02cf27c8: ldr     x8, [x24]                                  S:'didu'
02cf27cc: mov     w21, w0                                    
02cf27d0: mov     x1, xzr                                    
02cf27d4: mov     x0, x8                                     
02cf27d8: bl      #0x5b37788                                 UnityEngine.LayerMask::NameToLayer
02cf27dc: cmp     w21, w0                                    
02cf27e0: b.eq    #0x2cf27f8                                 
02cf27e4: ldr     w8, [x19, #0x18]                           
02cf27e8: add     w20, w20, #1                               
02cf27ec: cmp     w20, w8                                    
02cf27f0: cset    w22, lt                                    
02cf27f4: b.lt    #0x2cf27a4                                 
02cf27f8: and     w0, w22, #1                                
02cf27fc: ldp     x20, x19, [sp, #0xa0]                      
02cf2800: ldp     x22, x21, [sp, #0x90]                      
02cf2804: ldr     x30, [sp, #0x70]                           
02cf2808: ldp     x24, x23, [sp, #0x80]                      
02cf280c: add     sp, sp, #0xb0                              
02cf2810: ret                                                
02cf2814: bl      #0x2b7105c                                 fn_2b7105c
## GetEventSystemRaycastResults() -> System.Collections.Generic.List`1<UnityEngine.EventSystems.RaycastResult>
---- Helper::GetEventSystemRaycastResults 0x2cf262c
02cf262c: str     x30, [sp, #-0x20]!                         
02cf2630: stp     x20, x19, [sp, #0x10]                      
02cf2634: adrp    x20, #0x662f000                            
02cf2638: adrp    x19, #0x6267000                            
02cf263c: ldrb    w8, [x20, #0xe69]                          
02cf2640: ldr     x19, [x19, #0x8f8]                         T:UnityEngine.EventSystems.EventSystem
02cf2644: tbnz    w8, #0, #0x2cf2680                         
02cf2648: adrp    x0, #0x6267000                             
02cf264c: ldr     x0, [x0, #0x8f8]                           T:UnityEngine.EventSystems.EventSystem
02cf2650: bl      #0x2b70db0                                 fn_2b70db0
02cf2654: adrp    x0, #0x6267000                             
02cf2658: ldr     x0, [x0, #0x930]                           MS:System.Collections.Generic.List`1::.ctor
02cf265c: bl      #0x2b70db0                                 fn_2b70db0
02cf2660: adrp    x0, #0x6267000                             
02cf2664: ldr     x0, [x0, #0x928]                           T:type15256(k15)
02cf2668: bl      #0x2b70db0                                 fn_2b70db0
02cf266c: adrp    x0, #0x6267000                             
02cf2670: ldr     x0, [x0, #0x918]                           T:UnityEngine.EventSystems.PointerEventData
02cf2674: bl      #0x2b70db0                                 fn_2b70db0
02cf2678: mov     w8, #1                                     
02cf267c: strb    w8, [x20, #0xe69]                          
02cf2680: ldr     x0, [x19]                                  S:'didu'
02cf2684: adrp    x19, #0x6267000                            
02cf2688: ldr     w8, [x0, #0xe4]                            [62670e4]=0 f=0,0
02cf268c: ldr     x19, [x19, #0x918]                         T:UnityEngine.EventSystems.PointerEventData
02cf2690: cbnz    w8, #0x2cf2698                             
02cf2694: bl      #0x2b70f30                                 fn_2b70f30
02cf2698: mov     x0, xzr                                    
02cf269c: bl      #0x5e765b8                                 UnityEngine.EventSystems.EventSystem::get_current
02cf26a0: ldr     x8, [x19]                                  S:'didu'
02cf26a4: mov     x20, x0                                    
02cf26a8: mov     x0, x8                                     
02cf26ac: bl      #0x2b7104c                                 fn_2b7104c
02cf26b0: mov     x1, x20                                    
02cf26b4: mov     x2, xzr                                    
02cf26b8: mov     x19, x0                                    
02cf26bc: bl      #0x5e76e8c                                 UnityEngine.EventSystems.PointerEventData::.ctor
02cf26c0: mov     x0, xzr                                    
02cf26c4: bl      #0x5bb7d60                                 UnityEngine.Input::get_mousePosition
02cf26c8: cbz     x19, #0x2cf2724                            
02cf26cc: adrp    x8, #0x6267000                             
02cf26d0: adrp    x20, #0x6267000                            
02cf26d4: ldr     x8, [x8, #0x928]                           T:type15256(k15)
02cf26d8: ldr     x20, [x20, #0x930]                         MS:System.Collections.Generic.List`1::.ctor
02cf26dc: str     s0, [x19, #0x144]                          
02cf26e0: str     s1, [x19, #0x148]                          
02cf26e4: ldr     x0, [x8]                                   S:'didu'
02cf26e8: bl      #0x2b7104c                                 fn_2b7104c
02cf26ec: ldr     x1, [x20]                                  S:'didu'
02cf26f0: mov     x20, x0                                    
02cf26f4: bl      #0x35cdff0                                 fn_35cdff0
02cf26f8: mov     x0, xzr                                    
02cf26fc: bl      #0x5e765b8                                 UnityEngine.EventSystems.EventSystem::get_current
02cf2700: cbz     x0, #0x2cf2724                             
02cf2704: mov     x1, x19                                    
02cf2708: mov     x2, x20                                    
02cf270c: mov     x3, xzr                                    
02cf2710: bl      #0x5e78730                                 UnityEngine.EventSystems.EventSystem::RaycastAll
02cf2714: mov     x0, x20                                    
02cf2718: ldp     x20, x19, [sp, #0x10]                      
02cf271c: ldr     x30, [sp], #0x20                           
02cf2720: ret                                                
02cf2724: bl      #0x2b7105c                                 fn_2b7105c
