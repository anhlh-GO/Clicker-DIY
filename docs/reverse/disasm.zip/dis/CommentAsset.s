#### CLASS CommentAsset parent= UnityEngine.ScriptableObject
#   field rawText                        string                                             off=0x18 attr=6 TextAreaAttribute
#   field ChatContents                   System.Collections.Generic.List`1<string>          off=0x20 attr=6 
## PickRandomLiveComment() -> string
---- CommentAsset::PickRandomLiveComment 0x2cb4cd0
02cb4cd0: str     x30, [sp, #-0x30]!                         
02cb4cd4: stp     x22, x21, [sp, #0x10]                      
02cb4cd8: stp     x20, x19, [sp, #0x20]                      
02cb4cdc: adrp    x22, #0x662f000                            
02cb4ce0: adrp    x21, #0x6266000                            
02cb4ce4: adrp    x20, #0x6266000                            
02cb4ce8: ldrb    w8, [x22, #0xba2]                          
02cb4cec: ldr     x21, [x21, #0xc40]                         MS:FrameWorkUtility::PickRandom
02cb4cf0: ldr     x20, [x20, #0x9f0]                         T:Assets.SimpleLocalization.Scripts.LocalizationManager
02cb4cf4: mov     x19, x0                                    
02cb4cf8: tbnz    w8, #0, #0x2cb4d1c                         
02cb4cfc: adrp    x0, #0x6266000                             
02cb4d00: ldr     x0, [x0, #0xc40]                           MS:FrameWorkUtility::PickRandom
02cb4d04: bl      #0x2b70db0                                 fn_2b70db0
02cb4d08: adrp    x0, #0x6266000                             
02cb4d0c: ldr     x0, [x0, #0x9f0]                           T:Assets.SimpleLocalization.Scripts.LocalizationManager
02cb4d10: bl      #0x2b70db0                                 fn_2b70db0
02cb4d14: mov     w8, #1                                     
02cb4d18: strb    w8, [x22, #0xba2]                          
02cb4d1c: ldr     x0, [x19, #0x20]                           .ChatContents
02cb4d20: ldr     x1, [x21]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cb4d24: bl      #0x31cf844                                 fn_31cf844
02cb4d28: ldr     x8, [x20]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cb4d2c: mov     x19, x0                                    
02cb4d30: ldr     w9, [x8, #0xe4]                            
02cb4d34: cbnz    w9, #0x2cb4d40                             
02cb4d38: mov     x0, x8                                     
02cb4d3c: bl      #0x2b70f30                                 fn_2b70f30
02cb4d40: mov     x0, x19                                    
02cb4d44: ldp     x20, x19, [sp, #0x20]                      
02cb4d48: ldp     x22, x21, [sp, #0x10]                      
02cb4d4c: mov     x1, xzr                                    
02cb4d50: ldr     x30, [sp], #0x30                           
02cb4d54: b       #0x2d76794                                 Assets.SimpleLocalization.Scripts.LocalizationManager::Localize
## GetRandomCommentLiveID() -> long
---- CommentAsset::GetRandomCommentLiveID 0x2cb4d58
02cb4d58: mov     x0, xzr                                    
02cb4d5c: ret                                                
## GetStartLiveMessage() -> void
---- CommentAsset::GetStartLiveMessage 0x2cb4d60
02cb4d60: str     x30, [sp, #-0x30]!                         
02cb4d64: stp     x22, x21, [sp, #0x10]                      
02cb4d68: stp     x20, x19, [sp, #0x20]                      
02cb4d6c: adrp    x20, #0x662f000                            
02cb4d70: adrp    x21, #0x6263000                            
02cb4d74: mov     x19, x0                                    
02cb4d78: ldrb    w8, [x20, #0xba3]                          
02cb4d7c: ldr     x21, [x21, #0xf20]                         T:type24661(k1d)
02cb4d80: tbnz    w8, #0, #0x2cb4de0                         
02cb4d84: adrp    x0, #0x6266000                             
02cb4d88: ldr     x0, [x0, #0xc50]                           MS:System.Linq.Enumerable::ToList
02cb4d8c: bl      #0x2b70db0                                 fn_2b70db0
02cb4d90: adrp    x0, #0x6266000                             
02cb4d94: ldr     x0, [x0, #0xc48]                           MS:System.Collections.Generic.List`1::AddRange
02cb4d98: bl      #0x2b70db0                                 fn_2b70db0
02cb4d9c: adrp    x0, #0x6266000                             
02cb4da0: ldr     x0, [x0, #0xc58]                           MS:System.Collections.Generic.List`1::Clear
02cb4da4: bl      #0x2b70db0                                 fn_2b70db0
02cb4da8: adrp    x0, #0x6263000                             
02cb4dac: ldr     x0, [x0, #0xf20]                           T:type24661(k1d)
02cb4db0: bl      #0x2b70db0                                 fn_2b70db0
02cb4db4: adrp    x0, #0x6264000                             
02cb4db8: ldr     x0, [x0, #0xe18]                           S:'\n'
02cb4dbc: bl      #0x2b70db0                                 fn_2b70db0
02cb4dc0: adrp    x0, #0x6266000                             
02cb4dc4: ldr     x0, [x0, #0xc60]                           S:'\r\n'
02cb4dc8: bl      #0x2b70db0                                 fn_2b70db0
02cb4dcc: adrp    x0, #0x6266000                             
02cb4dd0: ldr     x0, [x0, #0xc68]                           S:'\r'
02cb4dd4: bl      #0x2b70db0                                 fn_2b70db0
02cb4dd8: mov     w8, #1                                     
02cb4ddc: strb    w8, [x20, #0xba3]                          
02cb4de0: ldr     x0, [x21]                                  &2c5bbd4(=a9bd7bfdd503233f)
02cb4de4: ldr     x20, [x19, #0x18]                          .rawText
02cb4de8: mov     w1, #3                                     
02cb4dec: bl      #0x2b70ea0                                 fn_2b70ea0
02cb4df0: cbz     x0, #0x2cb4eec                             
02cb4df4: ldr     w8, [x0, #0x18]                            S:'level_show_popuprate' .rawText
02cb4df8: mov     x21, x0                                    
02cb4dfc: cbz     w8, #0x2cb4ef0                             
02cb4e00: adrp    x8, #0x6266000                             
02cb4e04: mov     x22, x21                                   
02cb4e08: ldr     x8, [x8, #0xc60]                           S:'\r\n'
02cb4e0c: ldr     x1, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cb4e10: str     x1, [x22, #0x20]!                          
02cb4e14: mov     x0, x22                                    
02cb4e18: bl      #0x2b70d54                                 fn_2b70d54
02cb4e1c: ldur    w8, [x22, #-8]                             
02cb4e20: tst     w8, #0xfffffffe                            
02cb4e24: b.eq    #0x2cb4ef0                                 
02cb4e28: adrp    x8, #0x6264000                             
02cb4e2c: mov     x22, x21                                   
02cb4e30: ldr     x8, [x8, #0xe18]                           S:'\n'
02cb4e34: ldr     x1, [x8]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02cb4e38: str     x1, [x22, #0x28]!                          
02cb4e3c: mov     x0, x22                                    
02cb4e40: bl      #0x2b70d54                                 fn_2b70d54
02cb4e44: ldur    w8, [x22, #-0x10]                          
02cb4e48: cmp     w8, #2                                     
02cb4e4c: b.ls    #0x2cb4ef0                                 
02cb4e50: adrp    x8, #0x6266000                             
02cb4e54: mov     x0, x21                                    
02cb4e58: ldr     x8, [x8, #0xc68]                           S:'\r'
02cb4e5c: ldr     x1, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cb4e60: str     x1, [x0, #0x30]!                           
02cb4e64: bl      #0x2b70d54                                 fn_2b70d54
02cb4e68: cbz     x20, #0x2cb4eec                            
02cb4e6c: adrp    x22, #0x6266000                            
02cb4e70: mov     x0, x20                                    
02cb4e74: mov     x1, x21                                    
02cb4e78: ldr     x22, [x22, #0xc50]                         MS:System.Linq.Enumerable::ToList
02cb4e7c: mov     w2, #1                                     
02cb4e80: mov     x3, xzr                                    
02cb4e84: bl      #0x4caa694                                 System.String::Split
02cb4e88: ldr     x1, [x22]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cb4e8c: bl      #0x319eb2c                                 fn_319eb2c
02cb4e90: ldr     x8, [x19, #0x20]                           .ChatContents
02cb4e94: cbz     x8, #0x2cb4eec                             
02cb4e98: ldp     w2, w9, [x8, #0x18]                        
02cb4e9c: mov     x20, x0                                    
02cb4ea0: add     w9, w9, #1                                 
02cb4ea4: cmp     w2, #1                                     
02cb4ea8: stp     wzr, w9, [x8, #0x18]                       
02cb4eac: b.lt    #0x2cb4ec8                                 
02cb4eb0: ldr     x0, [x8, #0x10]                            S:'mrec_ad_on_off'
02cb4eb4: mov     w1, wzr                                    
02cb4eb8: mov     x3, xzr                                    
02cb4ebc: bl      #0x4e3494c                                 System.Array::Clear
02cb4ec0: ldr     x8, [x19, #0x20]                           .ChatContents
02cb4ec4: cbz     x8, #0x2cb4eec                             
02cb4ec8: adrp    x9, #0x6266000                             
02cb4ecc: mov     x1, x20                                    
02cb4ed0: mov     x0, x8                                     
02cb4ed4: ldr     x9, [x9, #0xc48]                           MS:System.Collections.Generic.List`1::AddRange
02cb4ed8: ldp     x20, x19, [sp, #0x20]                      
02cb4edc: ldp     x22, x21, [sp, #0x10]                      
02cb4ee0: ldr     x2, [x9]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cb4ee4: ldr     x30, [sp], #0x30                           
02cb4ee8: b       #0x35a941c                                 
02cb4eec: bl      #0x2b7105c                                 fn_2b7105c
02cb4ef0: bl      #0x2b71064                                 fn_2b71064
## .ctor() -> void
---- CommentAsset::.ctor 0x2cb4ef4
02cb4ef4: mov     x1, xzr                                    
02cb4ef8: b       #0x5b398f0                                 UnityEngine.ScriptableObject::.ctor
