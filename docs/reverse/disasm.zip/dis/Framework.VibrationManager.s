#### CLASS Framework.VibrationManager/EHapticType parent= int
#   field value__                        int                                                off=0x10 attr=606 
#   field Selection                      Framework.VibrationManager/EHapticType             off=0x0 attr=8056 
#   field Success                        Framework.VibrationManager/EHapticType             off=0x0 attr=8056 
#   field Warning                        Framework.VibrationManager/EHapticType             off=0x0 attr=8056 
#   field Failure                        Framework.VibrationManager/EHapticType             off=0x0 attr=8056 
#   field LightImpact                    Framework.VibrationManager/EHapticType             off=0x0 attr=8056 
#   field MediumImpact                   Framework.VibrationManager/EHapticType             off=0x0 attr=8056 
#   field HeavyImpact                    Framework.VibrationManager/EHapticType             off=0x0 attr=8056 
#   field RigidImpact                    Framework.VibrationManager/EHapticType             off=0x0 attr=8056 
#   field SoftImpact                     Framework.VibrationManager/EHapticType             off=0x0 attr=8056 
#   field None                           Framework.VibrationManager/EHapticType             off=0x0 attr=8056 
#### CLASS Framework.VibrationManager parent= MonoSingleton`1<Framework.VibrationManager>
#   field OnStatusChanged                System.Action`1<bool>                              off=0x0 attr=11 CompilerGeneratedAttribute
#   field IsPlayerPrefsSave              bool                                               off=0x20 attr=6 
## add_OnStatusChanged(System.Action`1<bool> value) -> void
---- Framework.VibrationManager::add_OnStatusChanged 0x2cc6b7c
02cc6b7c: str     x30, [sp, #-0x40]!                         
02cc6b80: stp     x24, x23, [sp, #0x10]                      
02cc6b84: stp     x22, x21, [sp, #0x20]                      
02cc6b88: stp     x20, x19, [sp, #0x30]                      
02cc6b8c: adrp    x20, #0x662f000                            
02cc6b90: adrp    x23, #0x6267000                            
02cc6b94: mov     x19, x0                                    
02cc6b98: ldrb    w8, [x20, #0xc5a]                          
02cc6b9c: ldr     x23, [x23, #0x2e8]                         T:Framework.VibrationManager
02cc6ba0: tbnz    w8, #0, #0x2cc6bc4                         
02cc6ba4: adrp    x0, #0x6267000                             
02cc6ba8: ldr     x0, [x0, #0x168]                           T:type6835(k15)
02cc6bac: bl      #0x2b70db0                                 fn_2b70db0
02cc6bb0: adrp    x0, #0x6267000                             
02cc6bb4: ldr     x0, [x0, #0x2e8]                           T:Framework.VibrationManager
02cc6bb8: bl      #0x2b70db0                                 fn_2b70db0
02cc6bbc: mov     w8, #1                                     
02cc6bc0: strb    w8, [x20, #0xc5a]                          
02cc6bc4: ldr     x8, [x23]                                  S:'didu'
02cc6bc8: adrp    x24, #0x6267000                            
02cc6bcc: ldr     x8, [x8, #0xb8]                            
02cc6bd0: ldr     x24, [x24, #0x168]                         T:type6835(k15)
02cc6bd4: ldr     x20, [x8]                                  
02cc6bd8: mov     x0, x20                                    
02cc6bdc: mov     x1, x19                                    
02cc6be0: mov     x2, xzr                                    
02cc6be4: bl      #0x4e570ac                                 System.Delegate::Combine
02cc6be8: cbz     x0, #0x2cc6c08                             
02cc6bec: ldr     x22, [x24]                                 S:'didu'
02cc6bf0: mov     x21, x0                                    
02cc6bf4: mov     x1, x22                                    
02cc6bf8: bl      #0x2b70f34                                 fn_2b70f34
02cc6bfc: mov     x1, x0                                     
02cc6c00: cbnz    x0, #0x2cc6c0c                             
02cc6c04: b       #0x2cc6c3c                                 
02cc6c08: mov     x1, xzr                                    
02cc6c0c: ldr     x8, [x23]                                  S:'didu'
02cc6c10: mov     x2, x20                                    
02cc6c14: ldr     x0, [x8, #0xb8]                            
02cc6c18: bl      #0x2ba9880                                 fn_2ba9880
02cc6c1c: cmp     x0, x20                                    
02cc6c20: mov     x20, x0                                    
02cc6c24: b.ne    #0x2cc6bd8                                 
02cc6c28: ldp     x20, x19, [sp, #0x30]                      
02cc6c2c: ldp     x22, x21, [sp, #0x20]                      
02cc6c30: ldp     x24, x23, [sp, #0x10]                      
02cc6c34: ldr     x30, [sp], #0x40                           
02cc6c38: ret                                                
02cc6c3c: mov     x0, x21                                    
02cc6c40: mov     x1, x22                                    
02cc6c44: bl      #0x2b713dc                                 fn_2b713dc
## remove_OnStatusChanged(System.Action`1<bool> value) -> void
---- Framework.VibrationManager::remove_OnStatusChanged 0x2cc6c48
02cc6c48: str     x30, [sp, #-0x40]!                         
02cc6c4c: stp     x24, x23, [sp, #0x10]                      
02cc6c50: stp     x22, x21, [sp, #0x20]                      
02cc6c54: stp     x20, x19, [sp, #0x30]                      
02cc6c58: adrp    x20, #0x662f000                            
02cc6c5c: adrp    x23, #0x6267000                            
02cc6c60: mov     x19, x0                                    
02cc6c64: ldrb    w8, [x20, #0xc5b]                          
02cc6c68: ldr     x23, [x23, #0x2e8]                         T:Framework.VibrationManager
02cc6c6c: tbnz    w8, #0, #0x2cc6c90                         
02cc6c70: adrp    x0, #0x6267000                             
02cc6c74: ldr     x0, [x0, #0x168]                           T:type6835(k15)
02cc6c78: bl      #0x2b70db0                                 fn_2b70db0
02cc6c7c: adrp    x0, #0x6267000                             
02cc6c80: ldr     x0, [x0, #0x2e8]                           T:Framework.VibrationManager
02cc6c84: bl      #0x2b70db0                                 fn_2b70db0
02cc6c88: mov     w8, #1                                     
02cc6c8c: strb    w8, [x20, #0xc5b]                          
02cc6c90: ldr     x8, [x23]                                  S:'didu'
02cc6c94: adrp    x24, #0x6267000                            
02cc6c98: ldr     x8, [x8, #0xb8]                            
02cc6c9c: ldr     x24, [x24, #0x168]                         T:type6835(k15)
02cc6ca0: ldr     x20, [x8]                                  
02cc6ca4: mov     x0, x20                                    
02cc6ca8: mov     x1, x19                                    
02cc6cac: mov     x2, xzr                                    
02cc6cb0: bl      #0x4e57298                                 System.Delegate::Remove
02cc6cb4: cbz     x0, #0x2cc6cd4                             
02cc6cb8: ldr     x22, [x24]                                 S:'didu'
02cc6cbc: mov     x21, x0                                    
02cc6cc0: mov     x1, x22                                    
02cc6cc4: bl      #0x2b70f34                                 fn_2b70f34
02cc6cc8: mov     x1, x0                                     
02cc6ccc: cbnz    x0, #0x2cc6cd8                             
02cc6cd0: b       #0x2cc6d08                                 
02cc6cd4: mov     x1, xzr                                    
02cc6cd8: ldr     x8, [x23]                                  S:'didu'
02cc6cdc: mov     x2, x20                                    
02cc6ce0: ldr     x0, [x8, #0xb8]                            
02cc6ce4: bl      #0x2ba9880                                 fn_2ba9880
02cc6ce8: cmp     x0, x20                                    
02cc6cec: mov     x20, x0                                    
02cc6cf0: b.ne    #0x2cc6ca4                                 
02cc6cf4: ldp     x20, x19, [sp, #0x30]                      
02cc6cf8: ldp     x22, x21, [sp, #0x20]                      
02cc6cfc: ldp     x24, x23, [sp, #0x10]                      
02cc6d00: ldr     x30, [sp], #0x40                           
02cc6d04: ret                                                
02cc6d08: mov     x0, x21                                    
02cc6d0c: mov     x1, x22                                    
02cc6d10: bl      #0x2b713dc                                 fn_2b713dc
## get_SaveKey() -> string
---- Framework.VibrationManager::get_SaveKey 0x2cc6d14
02cc6d14: str     x30, [sp, #-0x20]!                         
02cc6d18: stp     x20, x19, [sp, #0x10]                      
02cc6d1c: adrp    x19, #0x662f000                            
02cc6d20: adrp    x20, #0x6267000                            
02cc6d24: ldrb    w8, [x19, #0xc5c]                          
02cc6d28: ldr     x20, [x20, #0x2f0]                         S:'VibrationManager'
02cc6d2c: tbnz    w8, #0, #0x2cc6d44                         
02cc6d30: adrp    x0, #0x6267000                             
02cc6d34: ldr     x0, [x0, #0x2f0]                           S:'VibrationManager'
02cc6d38: bl      #0x2b70db0                                 fn_2b70db0
02cc6d3c: mov     w8, #1                                     
02cc6d40: strb    w8, [x19, #0xc5c]                          
02cc6d44: ldr     x0, [x20]                                  S:'didu'
02cc6d48: ldp     x20, x19, [sp, #0x10]                      
02cc6d4c: ldr     x30, [sp], #0x20                           
02cc6d50: ret                                                
## get_IsVibrationOn() -> bool
---- Framework.VibrationManager::get_IsVibrationOn 0x2cc6d54
02cc6d54: str     x30, [sp, #-0x20]!                         
02cc6d58: stp     x20, x19, [sp, #0x10]                      
02cc6d5c: adrp    x20, #0x662f000                            
02cc6d60: mov     x19, x0                                    
02cc6d64: ldrb    w8, [x20, #0xc5d]                          
02cc6d68: tbnz    w8, #0, #0x2cc6d8c                         
02cc6d6c: adrp    x0, #0x6266000                             
02cc6d70: ldr     x0, [x0, #0x750]                           MS:DataManager::GetData
02cc6d74: bl      #0x2b70db0                                 fn_2b70db0
02cc6d78: adrp    x0, #0x6266000                             
02cc6d7c: ldr     x0, [x0, #0x658]                           MS:MonoSingleton`1::get_Instance
02cc6d80: bl      #0x2b70db0                                 fn_2b70db0
02cc6d84: mov     w8, #1                                     
02cc6d88: strb    w8, [x20, #0xc5d]                          
02cc6d8c: ldrb    w8, [x19, #0x20]                           .IsPlayerPrefsSave
02cc6d90: cbz     w8, #0x2cc6de0                             
02cc6d94: adrp    x19, #0x662f000                            
02cc6d98: adrp    x20, #0x6267000                            
02cc6d9c: ldrb    w8, [x19, #0xc5c]                          
02cc6da0: ldr     x20, [x20, #0x2f0]                         S:'VibrationManager'
02cc6da4: tbnz    w8, #0, #0x2cc6dbc                         
02cc6da8: adrp    x0, #0x6267000                             
02cc6dac: ldr     x0, [x0, #0x2f0]                           S:'VibrationManager'
02cc6db0: bl      #0x2b70db0                                 fn_2b70db0
02cc6db4: mov     w8, #1                                     
02cc6db8: strb    w8, [x19, #0xc5c]                          
02cc6dbc: ldr     x0, [x20]                                  S:'didu'
02cc6dc0: mov     w1, #1                                     
02cc6dc4: mov     x2, xzr                                    
02cc6dc8: bl      #0x5b2d1dc                                 UnityEngine.PlayerPrefs::GetInt
02cc6dcc: ldp     x20, x19, [sp, #0x10]                      
02cc6dd0: cmp     w0, #1                                     
02cc6dd4: cset    w0, eq                                     
02cc6dd8: ldr     x30, [sp], #0x20                           
02cc6ddc: ret                                                
02cc6de0: adrp    x8, #0x6266000                             
02cc6de4: ldr     x8, [x8, #0x658]                           MS:MonoSingleton`1::get_Instance
02cc6de8: ldr     x0, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cc6dec: bl      #0x3769600                                 fn_3769600
02cc6df0: cbz     x0, #0x2cc6e18                             
02cc6df4: adrp    x8, #0x6266000                             
02cc6df8: ldr     x8, [x8, #0x750]                           MS:DataManager::GetData
02cc6dfc: ldr     x1, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cc6e00: bl      #0x3168dd0                                 fn_3168dd0
02cc6e04: cbz     x0, #0x2cc6e18                             
02cc6e08: ldp     x20, x19, [sp, #0x10]                      
02cc6e0c: mov     x1, xzr                                    
02cc6e10: ldr     x30, [sp], #0x20                           
02cc6e14: b       #0x2cab9f8                                 DataUser::HasVibration
02cc6e18: bl      #0x2b7105c                                 fn_2b7105c
## set_IsVibrationOn(bool value) -> void
---- Framework.VibrationManager::set_IsVibrationOn 0x2cc6e1c
02cc6e1c: stp     x30, x21, [sp, #-0x20]!                    
02cc6e20: stp     x20, x19, [sp, #0x10]                      
02cc6e24: adrp    x21, #0x662f000                            
02cc6e28: mov     w19, w1                                    
02cc6e2c: mov     x20, x0                                    
02cc6e30: ldrb    w8, [x21, #0xc5e]                          
02cc6e34: tbnz    w8, #0, #0x2cc6e58                         
02cc6e38: adrp    x0, #0x6266000                             
02cc6e3c: ldr     x0, [x0, #0x750]                           MS:DataManager::GetData
02cc6e40: bl      #0x2b70db0                                 fn_2b70db0
02cc6e44: adrp    x0, #0x6266000                             
02cc6e48: ldr     x0, [x0, #0x658]                           MS:MonoSingleton`1::get_Instance
02cc6e4c: bl      #0x2b70db0                                 fn_2b70db0
02cc6e50: mov     w8, #1                                     
02cc6e54: strb    w8, [x21, #0xc5e]                          
02cc6e58: ldrb    w8, [x20, #0x20]                           .IsPlayerPrefsSave
02cc6e5c: cbz     w8, #0x2cc6ea0                             
02cc6e60: adrp    x20, #0x662f000                            
02cc6e64: adrp    x21, #0x6267000                            
02cc6e68: ldrb    w8, [x20, #0xc5c]                          
02cc6e6c: ldr     x21, [x21, #0x2f0]                         S:'VibrationManager'
02cc6e70: tbnz    w8, #0, #0x2cc6e88                         
02cc6e74: adrp    x0, #0x6267000                             
02cc6e78: ldr     x0, [x0, #0x2f0]                           S:'VibrationManager'
02cc6e7c: bl      #0x2b70db0                                 fn_2b70db0
02cc6e80: mov     w8, #1                                     
02cc6e84: strb    w8, [x20, #0xc5c]                          
02cc6e88: and     w1, w19, #1                                
02cc6e8c: ldp     x20, x19, [sp, #0x10]                      
02cc6e90: ldr     x0, [x21]                                  S:'didu'
02cc6e94: mov     x2, xzr                                    
02cc6e98: ldp     x30, x21, [sp], #0x20                      
02cc6e9c: b       #0x5b2d184                                 UnityEngine.PlayerPrefs::SetInt
02cc6ea0: adrp    x8, #0x6266000                             
02cc6ea4: ldr     x8, [x8, #0x658]                           MS:MonoSingleton`1::get_Instance
02cc6ea8: ldr     x0, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cc6eac: bl      #0x3769600                                 fn_3769600
02cc6eb0: cbz     x0, #0x2cc6edc                             
02cc6eb4: adrp    x8, #0x6266000                             
02cc6eb8: ldr     x8, [x8, #0x750]                           MS:DataManager::GetData
02cc6ebc: ldr     x1, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cc6ec0: bl      #0x3168dd0                                 fn_3168dd0
02cc6ec4: cbz     x0, #0x2cc6edc                             
02cc6ec8: and     w1, w19, #1                                
02cc6ecc: ldp     x20, x19, [sp, #0x10]                      
02cc6ed0: mov     x2, xzr                                    
02cc6ed4: ldp     x30, x21, [sp], #0x20                      
02cc6ed8: b       #0x2caba10                                 DataUser::SetVibration
02cc6edc: bl      #0x2b7105c                                 fn_2b7105c
## Haptic(Framework.VibrationManager/EHapticType type) -> void
---- Framework.VibrationManager::Haptic 0x2cc6ee0
02cc6ee0: b       #0x2cc6d54                                 Framework.VibrationManager::get_IsVibrationOn
## .ctor() -> void
---- Framework.VibrationManager::.ctor 0x2cc6ee4
02cc6ee4: stp     x30, x21, [sp, #-0x20]!                    
02cc6ee8: stp     x20, x19, [sp, #0x10]                      
02cc6eec: adrp    x20, #0x662f000                            
02cc6ef0: adrp    x21, #0x6267000                            
02cc6ef4: mov     x19, x0                                    
02cc6ef8: ldrb    w8, [x20, #0xc5f]                          
02cc6efc: ldr     x21, [x21, #0x2f8]                         MS:MonoSingleton`1::.ctor
02cc6f00: tbnz    w8, #0, #0x2cc6f18                         
02cc6f04: adrp    x0, #0x6267000                             
02cc6f08: ldr     x0, [x0, #0x2f8]                           MS:MonoSingleton`1::.ctor
02cc6f0c: bl      #0x2b70db0                                 fn_2b70db0
02cc6f10: mov     w8, #1                                     
02cc6f14: strb    w8, [x20, #0xc5f]                          
02cc6f18: mov     x0, x19                                    
02cc6f1c: ldp     x20, x19, [sp, #0x10]                      
02cc6f20: ldr     x1, [x21]                                  S:'didu'
02cc6f24: ldp     x30, x21, [sp], #0x20                      
02cc6f28: b       #0x3769e18                                 
