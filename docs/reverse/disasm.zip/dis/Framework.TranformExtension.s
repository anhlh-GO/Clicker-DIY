#### CLASS Framework.TranformExtension parent= object
## GetChildCount(UnityEngine.Transform trans, bool includeInactive) -> int
---- Framework.TranformExtension::GetChildCount 0x2cba4b8
02cba4b8: stp     x30, x21, [sp, #-0x20]!                    
02cba4bc: stp     x20, x19, [sp, #0x10]                      
02cba4c0: mov     x19, x0                                    
02cba4c4: tbz     w1, #0, #0x2cba4e0                         
02cba4c8: cbz     x19, #0x2cba560                            
02cba4cc: mov     x0, x19                                    
02cba4d0: ldp     x20, x19, [sp, #0x10]                      
02cba4d4: mov     x1, xzr                                    
02cba4d8: ldp     x30, x21, [sp], #0x20                      
02cba4dc: b       #0x5b482c4                                 UnityEngine.Transform::get_childCount
02cba4e0: cbz     x19, #0x2cba560                            
02cba4e4: mov     x0, x19                                    
02cba4e8: mov     x1, xzr                                    
02cba4ec: bl      #0x5b482c4                                 UnityEngine.Transform::get_childCount
02cba4f0: cmp     w0, #1                                     
02cba4f4: b.lt    #0x2cba54c                                 
02cba4f8: mov     w21, wzr                                   
02cba4fc: mov     w20, wzr                                   
02cba500: mov     x0, x19                                    
02cba504: mov     w1, w21                                    
02cba508: mov     x2, xzr                                    
02cba50c: bl      #0x5b48d44                                 UnityEngine.Transform::GetChild
02cba510: cbz     x0, #0x2cba560                             
02cba514: mov     x1, xzr                                    
02cba518: bl      #0x5b339ec                                 UnityEngine.Component::get_gameObject
02cba51c: cbz     x0, #0x2cba560                             
02cba520: mov     x1, xzr                                    
02cba524: bl      #0x5b36bfc                                 UnityEngine.GameObject::get_activeSelf
02cba528: and     w8, w0, #1                                 
02cba52c: mov     x0, x19                                    
02cba530: mov     x1, xzr                                    
02cba534: add     w21, w21, #1                               
02cba538: add     w20, w20, w8                               
02cba53c: bl      #0x5b482c4                                 UnityEngine.Transform::get_childCount
02cba540: cmp     w21, w0                                    
02cba544: b.lt    #0x2cba500                                 
02cba548: b       #0x2cba550                                 
02cba54c: mov     w20, wzr                                   
02cba550: mov     w0, w20                                    
02cba554: ldp     x20, x19, [sp, #0x10]                      
02cba558: ldp     x30, x21, [sp], #0x20                      
02cba55c: ret                                                
02cba560: bl      #0x2b7105c                                 fn_2b7105c
## FindDeepChildBFS(UnityEngine.Transform parent, string childName, Framework.EStringMatchType matchType) -> UnityEngine.Transform
---- Framework.TranformExtension::FindDeepChildBFS 0x2cba564
02cba564: sub     sp, sp, #0x90                              
02cba568: stp     x29, x30, [sp, #0x30]                      
02cba56c: stp     x28, x27, [sp, #0x40]                      
02cba570: stp     x26, x25, [sp, #0x50]                      
02cba574: stp     x24, x23, [sp, #0x60]                      
02cba578: stp     x22, x21, [sp, #0x70]                      
02cba57c: stp     x20, x19, [sp, #0x80]                      
02cba580: adrp    x22, #0x662f000                            
02cba584: mov     w19, w2                                    
02cba588: mov     x20, x1                                    
02cba58c: ldrb    w8, [x22, #0xbee]                          
02cba590: str     x0, [sp]                                   
02cba594: tbnz    w8, #0, #0x2cba60c                         
02cba598: adrp    x0, #0x6263000                             
02cba59c: ldr     x0, [x0, #0x980]                           T:System.IDisposable
02cba5a0: bl      #0x2b70db0                                 fn_2b70db0
02cba5a4: adrp    x0, #0x6263000                             
02cba5a8: ldr     x0, [x0, #0xa58]                           T:System.Collections.IEnumerator
02cba5ac: bl      #0x2b70db0                                 fn_2b70db0
02cba5b0: adrp    x0, #0x6263000                             
02cba5b4: ldr     x0, [x0, #0x918]                           T:UnityEngine.Object
02cba5b8: bl      #0x2b70db0                                 fn_2b70db0
02cba5bc: adrp    x0, #0x6266000                             
02cba5c0: ldr     x0, [x0, #0xed8]                           MS:System.Collections.Generic.Queue`1::Dequeue
02cba5c4: bl      #0x2b70db0                                 fn_2b70db0
02cba5c8: adrp    x0, #0x6266000                             
02cba5cc: ldr     x0, [x0, #0xee0]                           MS:System.Collections.Generic.Queue`1::Enqueue
02cba5d0: bl      #0x2b70db0                                 fn_2b70db0
02cba5d4: adrp    x0, #0x6266000                             
02cba5d8: ldr     x0, [x0, #0xee8]                           MS:System.Collections.Generic.Queue`1::.ctor
02cba5dc: bl      #0x2b70db0                                 fn_2b70db0
02cba5e0: adrp    x0, #0x6266000                             
02cba5e4: ldr     x0, [x0, #0xef0]                           MS:System.Collections.Generic.Queue`1::get_Count
02cba5e8: bl      #0x2b70db0                                 fn_2b70db0
02cba5ec: adrp    x0, #0x6266000                             
02cba5f0: ldr     x0, [x0, #0xef8]                           T:type57436(k15)
02cba5f4: bl      #0x2b70db0                                 fn_2b70db0
02cba5f8: adrp    x0, #0x6264000                             
02cba5fc: ldr     x0, [x0, #0x920]                           T:UnityEngine.Transform
02cba600: bl      #0x2b70db0                                 fn_2b70db0
02cba604: mov     w8, #1                                     
02cba608: strb    w8, [x22, #0xbee]                          
02cba60c: stp     xzr, xzr, [sp, #0x20]                      
02cba610: cbz     x20, #0x2cba908                            
02cba614: adrp    x8, #0x6266000                             
02cba618: adrp    x21, #0x6266000                            
02cba61c: ldr     x8, [x8, #0xef8]                           T:type57436(k15)
02cba620: ldr     x21, [x21, #0xee8]                         MS:System.Collections.Generic.Queue`1::.ctor
02cba624: ldr     x0, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cba628: bl      #0x2b7104c                                 fn_2b7104c
02cba62c: ldr     x1, [x21]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cba630: mov     x22, x0                                    
02cba634: bl      #0x3a3083c                                 fn_3a3083c
02cba638: cbz     x22, #0x2cba930                            
02cba63c: adrp    x25, #0x6266000                            
02cba640: mov     x0, x22                                    
02cba644: ldr     x25, [x25, #0xee0]                         MS:System.Collections.Generic.Queue`1::Enqueue
02cba648: ldr     x1, [sp]                                   
02cba64c: ldr     x2, [x25]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cba650: bl      #0x3a30d54                                 fn_3a30d54
02cba654: ldr     w8, [x22, #0x20]                           &2b706f0(=d65f03c0f9400800)
02cba658: cmp     w8, #1                                     
02cba65c: b.lt    #0x2cba908                                 
02cba660: adrp    x28, #0x6263000                            
02cba664: adrp    x29, #0x6263000                            
02cba668: adrp    x27, #0x6264000                            
02cba66c: ldr     x28, [x28, #0x980]                         T:System.IDisposable
02cba670: ldr     x29, [x29, #0xa58]                         T:System.Collections.IEnumerator
02cba674: ldr     x27, [x27, #0x920]                         T:UnityEngine.Transform
02cba678: adrp    x8, #0x6266000                             
02cba67c: mov     x0, x22                                    
02cba680: ldr     x8, [x8, #0xed8]                           MS:System.Collections.Generic.Queue`1::Dequeue
02cba684: ldr     x1, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cba688: bl      #0x3a30ee4                                 fn_3a30ee4
02cba68c: cbz     x0, #0x2cba930                             
02cba690: mov     x1, xzr                                    
02cba694: mov     x23, x0                                    
02cba698: bl      #0x5b3bba4                                 UnityEngine.Object::get_name
02cba69c: mov     x1, x20                                    
02cba6a0: mov     w2, w19                                    
02cba6a4: bl      #0x2cba130                                 Framework.StringExtension::IsMatchWith
02cba6a8: tbz     w0, #0, #0x2cba6d8                         
02cba6ac: adrp    x8, #0x6263000                             
02cba6b0: ldr     x8, [x8, #0x918]                           T:UnityEngine.Object
02cba6b4: ldr     x0, [x8]                                   &2c5bbd4(=a9bd7bfdd503233f)
02cba6b8: ldr     w8, [x0, #0xe4]                            [62640e4]=0 f=0,0
02cba6bc: cbnz    w8, #0x2cba6c4                             
02cba6c0: bl      #0x2b70f30                                 fn_2b70f30
02cba6c4: ldr     x1, [sp]                                   
02cba6c8: mov     x0, x23                                    
02cba6cc: mov     x2, xzr                                    
02cba6d0: bl      #0x5b3666c                                 UnityEngine.Object::op_Inequality
02cba6d4: tbnz    w0, #0, #0x2cba90c                         
02cba6d8: mov     x0, x23                                    
02cba6dc: mov     x1, xzr                                    
02cba6e0: bl      #0x5b48c9c                                 UnityEngine.Transform::GetEnumerator
02cba6e4: add     x8, sp, #0x28                              
02cba6e8: mov     x23, x0                                    
02cba6ec: str     x0, [sp, #0x28]                            
02cba6f0: stp     xzr, x8, [sp, #8]                          
02cba6f4: add     x8, sp, #0x20                              
02cba6f8: str     x8, [sp, #0x18]                            
02cba6fc: cbz     x0, #0x2cba80c                             
02cba700: ldr     x8, [x23]                                  
02cba704: ldr     x1, [x29]                                  &2c5bbd4(=a9bd7bfdd503233f)
02cba708: ldrh    w9, [x8, #0x12e]                           
02cba70c: cbz     x9, #0x2cba730                             
02cba710: ldr     x10, [x8, #0xb0]                           [62630b0]=0 f=0,0
02cba714: add     x10, x10, #8                               
02cba718: ldur    x11, [x10, #-8]                            
02cba71c: cmp     x11, x1                                    
02cba720: b.eq    #0x2cba740                                 
02cba724: subs    x9, x9, #1                                 
02cba728: add     x10, x10, #0x10                            
02cba72c: b.ne    #0x2cba718                                 
02cba730: mov     x0, x23                                    
02cba734: mov     w2, wzr                                    
02cba738: bl      #0x2baa05c                                 fn_2baa05c
02cba73c: b       #0x2cba74c                                 
02cba740: ldrsw   x9, [x10]                                  
02cba744: add     x8, x8, x9, lsl #4                         &6263000
02cba748: add     x0, x8, #0x138                             &6263138
02cba74c: ldp     x8, x1, [x0]                               
02cba750: mov     x0, x23                                    
02cba754: blr     x8                                         
02cba758: tbz     w0, #0, #0x2cba814                         
02cba75c: ldr     x23, [sp, #0x28]                           
02cba760: cbz     x23, #0x2cba8c0                            
02cba764: ldr     x8, [x23]                                  
02cba768: ldr     x1, [x29]                                  &2c5bbd4(=a9bd7bfdd503233f)
02cba76c: ldrh    w9, [x8, #0x12e]                           
02cba770: cbz     x9, #0x2cba794                             
02cba774: ldr     x10, [x8, #0xb0]                           [62630b0]=0 f=0,0
02cba778: add     x10, x10, #8                               
02cba77c: ldur    x11, [x10, #-8]                            
02cba780: cmp     x11, x1                                    
02cba784: b.eq    #0x2cba7a4                                 
02cba788: subs    x9, x9, #1                                 
02cba78c: add     x10, x10, #0x10                            
02cba790: b.ne    #0x2cba77c                                 
02cba794: mov     x0, x23                                    
02cba798: mov     w2, #1                                     
02cba79c: bl      #0x2baa05c                                 fn_2baa05c
02cba7a0: b       #0x2cba7b4                                 
02cba7a4: ldr     w9, [x10]                                  
02cba7a8: add     w9, w9, #1                                 
02cba7ac: add     x8, x8, w9, sxtw #4                        &6263000
02cba7b0: add     x0, x8, #0x138                             &6263138
02cba7b4: ldp     x8, x1, [x0]                               
02cba7b8: mov     x0, x23                                    
02cba7bc: blr     x8                                         
02cba7c0: mov     x8, x0                                     
02cba7c4: cbz     x0, #0x2cba7f4                             
02cba7c8: ldr     x1, [x27]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02cba7cc: ldr     x9, [x8]                                   &2c5bbd4(=a9bd7bfdd503233f)
02cba7d0: ldrb    w11, [x9, #0x130]                          
02cba7d4: ldrb    w10, [x1, #0x130]                          
02cba7d8: cmp     w11, w10                                   
02cba7dc: b.lo    #0x2cba8b4                                 
02cba7e0: ldr     x9, [x9, #0xc8]                            
02cba7e4: add     x9, x9, x10, lsl #3                        
02cba7e8: ldur    x9, [x9, #-8]                              
02cba7ec: cmp     x9, x1                                     
02cba7f0: b.ne    #0x2cba8b4                                 
02cba7f4: ldr     x2, [x25]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cba7f8: mov     x0, x22                                    
02cba7fc: mov     x1, x8                                     
02cba800: bl      #0x3a30d54                                 fn_3a30d54
02cba804: ldr     x23, [sp, #0x28]                           
02cba808: cbnz    x23, #0x2cba700                            
02cba80c: bl      #0x2b7105c                                 fn_2b7105c
02cba810: b       #0x2cba93c                                 
02cba814: mov     x23, xzr                                   
02cba818: mov     w26, #3                                    
02cba81c: add     x8, sp, #0x28                              
02cba820: add     x21, sp, #0x20                             
02cba824: ldr     x0, [x8]                                   &2c5bbd4(=a9bd7bfdd503233f)
02cba828: ldr     x1, [x28]                                  &2c5bbd4(=a9bd7bfdd503233f)
02cba82c: bl      #0x2b70f34                                 fn_2b70f34
02cba830: str     x0, [x21]                                  
02cba834: cbz     x0, #0x2cba894                             
02cba838: ldr     x8, [x0]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02cba83c: ldr     x1, [x28]                                  &2c5bbd4(=a9bd7bfdd503233f)
02cba840: mov     x24, x0                                    
02cba844: ldrh    w9, [x8, #0x12e]                           
02cba848: cbz     x9, #0x2cba86c                             
02cba84c: ldr     x10, [x8, #0xb0]                           [62630b0]=0 f=0,0
02cba850: add     x10, x10, #8                               
02cba854: ldur    x11, [x10, #-8]                            
02cba858: cmp     x11, x1                                    
02cba85c: b.eq    #0x2cba87c                                 
02cba860: subs    x9, x9, #1                                 
02cba864: add     x10, x10, #0x10                            
02cba868: b.ne    #0x2cba854                                 
02cba86c: mov     x0, x24                                    
02cba870: mov     w2, wzr                                    
02cba874: bl      #0x2baa05c                                 fn_2baa05c
02cba878: b       #0x2cba888                                 
02cba87c: ldrsw   x9, [x10]                                  
02cba880: add     x8, x8, x9, lsl #4                         &6263000
02cba884: add     x0, x8, #0x138                             &6263138
02cba888: ldp     x8, x1, [x0]                               
02cba88c: mov     x0, x24                                    
02cba890: blr     x8                                         
02cba894: cbnz    x23, #0x2cba934                            
02cba898: cmp     w26, #3                                    
02cba89c: b.eq    #0x2cba8a4                                 
02cba8a0: cbnz    w26, #0x2cba90c                            
02cba8a4: ldr     w8, [x22, #0x20]                           &2b706f0(=d65f03c0f9400800)
02cba8a8: cmp     w8, #0                                     
02cba8ac: b.gt    #0x2cba678                                 
02cba8b0: b       #0x2cba908                                 
02cba8b4: mov     x0, x8                                     
02cba8b8: bl      #0x2b713dc                                 fn_2b713dc
02cba8bc: b       #0x2cba93c                                 
02cba8c0: bl      #0x2b7105c                                 fn_2b7105c
02cba8c4: b       #0x2cba93c                                 
02cba8c8: b       #0x2cba8dc                                 
02cba8cc: b       #0x2cba8dc                                 
02cba8d0: b       #0x2cba8dc                                 
02cba8d4: b       #0x2cba8dc                                 
02cba8d8: b       #0x2cba8dc                                 
02cba8dc: mov     x23, x0                                    
02cba8e0: cmp     w1, #1                                     
02cba8e4: b.ne    #0x2cba940                                 
02cba8e8: mov     x0, x23                                    
02cba8ec: bl      #0x5e90260                                 fn_5e90260
02cba8f0: ldr     x23, [x0]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02cba8f4: str     x23, [sp, #8]                              
02cba8f8: bl      #0x5e90270                                 fn_5e90270
02cba8fc: ldp     x8, x21, [sp, #0x10]                       
02cba900: mov     w26, wzr                                   
02cba904: b       #0x2cba824                                 
02cba908: mov     x23, xzr                                   
02cba90c: mov     x0, x23                                    
02cba910: ldp     x20, x19, [sp, #0x80]                      
02cba914: ldp     x22, x21, [sp, #0x70]                      
02cba918: ldp     x24, x23, [sp, #0x60]                      
02cba91c: ldp     x26, x25, [sp, #0x50]                      
02cba920: ldp     x28, x27, [sp, #0x40]                      
02cba924: ldp     x29, x30, [sp, #0x30]                      
02cba928: add     sp, sp, #0x90                              
02cba92c: ret                                                
02cba930: bl      #0x2b7105c                                 fn_2b7105c
02cba934: mov     x0, x23                                    
02cba938: bl      #0x2b71054                                 fn_2b71054
02cba93c: mov     x23, x0                                    
02cba940: add     x0, sp, #8                                 
02cba944: bl      #0x2736a80                                 fn_2736a80
02cba948: mov     x0, x23                                    
02cba94c: bl      #0x2c6051c                                 fn_2c6051c
02cba950: bl      #0x27369b8                                 fn_27369b8
## FindDeepChildDFS(UnityEngine.Transform parent, string childName, Framework.EStringMatchType matchType) -> UnityEngine.Transform
---- Framework.TranformExtension::FindDeepChildDFS 0x2cba954
02cba954: sub     sp, sp, #0x70                              
02cba958: stp     x30, x25, [sp, #0x30]                      
02cba95c: stp     x24, x23, [sp, #0x40]                      
02cba960: stp     x22, x21, [sp, #0x50]                      
02cba964: stp     x20, x19, [sp, #0x60]                      
02cba968: adrp    x22, #0x662f000                            
02cba96c: mov     w19, w2                                    
02cba970: mov     x20, x1                                    
02cba974: ldrb    w8, [x22, #0xbef]                          
02cba978: mov     x21, x0                                    
02cba97c: tbnz    w8, #0, #0x2cba9b8                         
02cba980: adrp    x0, #0x6263000                             
02cba984: ldr     x0, [x0, #0x980]                           T:System.IDisposable
02cba988: bl      #0x2b70db0                                 fn_2b70db0
02cba98c: adrp    x0, #0x6263000                             
02cba990: ldr     x0, [x0, #0xa58]                           T:System.Collections.IEnumerator
02cba994: bl      #0x2b70db0                                 fn_2b70db0
02cba998: adrp    x0, #0x6263000                             
02cba99c: ldr     x0, [x0, #0x918]                           T:UnityEngine.Object
02cba9a0: bl      #0x2b70db0                                 fn_2b70db0
02cba9a4: adrp    x0, #0x6264000                             
02cba9a8: ldr     x0, [x0, #0x920]                           T:UnityEngine.Transform
02cba9ac: bl      #0x2b70db0                                 fn_2b70db0
02cba9b0: mov     w8, #1                                     
02cba9b4: strb    w8, [x22, #0xbef]                          
02cba9b8: stp     xzr, xzr, [sp, #0x20]                      
02cba9bc: cbz     x20, #0x2cbab5c                            
02cba9c0: cbz     x21, #0x2cbac18                            
02cba9c4: adrp    x23, #0x6263000                            
02cba9c8: adrp    x24, #0x6264000                            
02cba9cc: adrp    x25, #0x6263000                            
02cba9d0: adrp    x22, #0x6263000                            
02cba9d4: ldr     x23, [x23, #0xa58]                         T:System.Collections.IEnumerator
02cba9d8: ldr     x24, [x24, #0x920]                         T:UnityEngine.Transform
02cba9dc: ldr     x25, [x25, #0x918]                         T:UnityEngine.Object
02cba9e0: ldr     x22, [x22, #0x980]                         T:System.IDisposable
02cba9e4: mov     x0, x21                                    
02cba9e8: mov     x1, xzr                                    
02cba9ec: bl      #0x5b48c9c                                 UnityEngine.Transform::GetEnumerator
02cba9f0: add     x8, sp, #0x28                              
02cba9f4: str     x0, [sp, #0x28]                            
02cba9f8: stp     xzr, x8, [sp, #8]                          
02cba9fc: add     x8, sp, #0x20                              
02cbaa00: str     x8, [sp, #0x18]                            
02cbaa04: ldr     x21, [sp, #0x28]                           
02cbaa08: cbz     x21, #0x2cbac0c                            
02cbaa0c: ldr     x8, [x21]                                  
02cbaa10: ldr     x1, [x23]                                  &2c5bbd4(=a9bd7bfdd503233f)
02cbaa14: ldrh    w9, [x8, #0x12e]                           
02cbaa18: cbz     x9, #0x2cbaa3c                             
02cbaa1c: ldr     x10, [x8, #0xb0]                           
02cbaa20: add     x10, x10, #8                               
02cbaa24: ldur    x11, [x10, #-8]                            
02cbaa28: cmp     x11, x1                                    
02cbaa2c: b.eq    #0x2cbaa4c                                 
02cbaa30: subs    x9, x9, #1                                 
02cbaa34: add     x10, x10, #0x10                            
02cbaa38: b.ne    #0x2cbaa24                                 
02cbaa3c: mov     x0, x21                                    
02cbaa40: mov     w2, wzr                                    
02cbaa44: bl      #0x2baa05c                                 fn_2baa05c
02cbaa48: b       #0x2cbaa58                                 
02cbaa4c: ldrsw   x9, [x10]                                  
02cbaa50: add     x8, x8, x9, lsl #4                         
02cbaa54: add     x0, x8, #0x138                             
02cbaa58: ldp     x8, x1, [x0]                               
02cbaa5c: mov     x0, x21                                    
02cbaa60: blr     x8                                         
02cbaa64: tbz     w0, #0, #0x2cbab64                         
02cbaa68: ldr     x21, [sp, #0x28]                           
02cbaa6c: cbz     x21, #0x2cbac10                            
02cbaa70: ldr     x8, [x21]                                  
02cbaa74: ldr     x1, [x23]                                  &2c5bbd4(=a9bd7bfdd503233f)
02cbaa78: ldrh    w9, [x8, #0x12e]                           
02cbaa7c: cbz     x9, #0x2cbaaa0                             
02cbaa80: ldr     x10, [x8, #0xb0]                           
02cbaa84: add     x10, x10, #8                               
02cbaa88: ldur    x11, [x10, #-8]                            
02cbaa8c: cmp     x11, x1                                    
02cbaa90: b.eq    #0x2cbaab0                                 
02cbaa94: subs    x9, x9, #1                                 
02cbaa98: add     x10, x10, #0x10                            
02cbaa9c: b.ne    #0x2cbaa88                                 
02cbaaa0: mov     x0, x21                                    
02cbaaa4: mov     w2, #1                                     
02cbaaa8: bl      #0x2baa05c                                 fn_2baa05c
02cbaaac: b       #0x2cbaac0                                 
02cbaab0: ldr     w9, [x10]                                  
02cbaab4: add     w9, w9, #1                                 
02cbaab8: add     x8, x8, w9, sxtw #4                        
02cbaabc: add     x0, x8, #0x138                             
02cbaac0: ldp     x8, x1, [x0]                               
02cbaac4: mov     x0, x21                                    
02cbaac8: blr     x8                                         
02cbaacc: mov     x21, x0                                    
02cbaad0: cbz     x0, #0x2cbac14                             
02cbaad4: ldr     x1, [x24]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02cbaad8: ldr     x8, [x21]                                  
02cbaadc: ldrb    w10, [x8, #0x130]                          
02cbaae0: ldrb    w9, [x1, #0x130]                           
02cbaae4: cmp     w10, w9                                    
02cbaae8: b.lo    #0x2cbac04                                 
02cbaaec: ldr     x8, [x8, #0xc8]                            
02cbaaf0: add     x8, x8, x9, lsl #3                         
02cbaaf4: ldur    x8, [x8, #-8]                              
02cbaaf8: cmp     x8, x1                                     
02cbaafc: b.ne    #0x2cbac04                                 
02cbab00: mov     x0, x21                                    
02cbab04: mov     x1, xzr                                    
02cbab08: bl      #0x5b3bba4                                 UnityEngine.Object::get_name
02cbab0c: mov     x1, x20                                    
02cbab10: mov     w2, w19                                    
02cbab14: bl      #0x2cba130                                 Framework.StringExtension::IsMatchWith
02cbab18: tbnz    w0, #0, #0x2cbab54                         
02cbab1c: mov     x0, x21                                    
02cbab20: mov     x1, x20                                    
02cbab24: mov     w2, wzr                                    
02cbab28: bl      #0x2cba954                                 Framework.TranformExtension::FindDeepChildDFS
02cbab2c: mov     x21, x0                                    
02cbab30: ldr     x0, [x25]                                  &2c5bbd4(=a9bd7bfdd503233f)
02cbab34: ldr     w8, [x0, #0xe4]                            [62640e4]=0 f=0,0
02cbab38: cbnz    w8, #0x2cbab40                             
02cbab3c: bl      #0x2b70f30                                 fn_2b70f30
02cbab40: mov     x0, x21                                    
02cbab44: mov     x1, xzr                                    
02cbab48: mov     x2, xzr                                    
02cbab4c: bl      #0x5b3666c                                 UnityEngine.Object::op_Inequality
02cbab50: tbz     w0, #0, #0x2cbaa04                         
02cbab54: mov     x19, xzr                                   
02cbab58: b       #0x2cbab6c                                 
02cbab5c: mov     x21, xzr                                   
02cbab60: b       #0x2cbabe8                                 
02cbab64: mov     x19, xzr                                   
02cbab68: mov     x21, xzr                                   
02cbab6c: add     x8, sp, #0x28                              
02cbab70: add     x23, sp, #0x20                             
02cbab74: ldr     x0, [x8]                                   
02cbab78: ldr     x1, [x22]                                  &2c5bbd4(=a9bd7bfdd503233f)
02cbab7c: bl      #0x2b70f34                                 fn_2b70f34
02cbab80: str     x0, [x23]                                  
02cbab84: cbz     x0, #0x2cbabe4                             
02cbab88: ldr     x8, [x0]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02cbab8c: ldr     x1, [x22]                                  &2c5bbd4(=a9bd7bfdd503233f)
02cbab90: mov     x20, x0                                    
02cbab94: ldrh    w9, [x8, #0x12e]                           
02cbab98: cbz     x9, #0x2cbabbc                             
02cbab9c: ldr     x10, [x8, #0xb0]                           
02cbaba0: add     x10, x10, #8                               
02cbaba4: ldur    x11, [x10, #-8]                            
02cbaba8: cmp     x11, x1                                    
02cbabac: b.eq    #0x2cbabcc                                 
02cbabb0: subs    x9, x9, #1                                 
02cbabb4: add     x10, x10, #0x10                            
02cbabb8: b.ne    #0x2cbaba4                                 
02cbabbc: mov     x0, x20                                    
02cbabc0: mov     w2, wzr                                    
02cbabc4: bl      #0x2baa05c                                 fn_2baa05c
02cbabc8: b       #0x2cbabd8                                 
02cbabcc: ldrsw   x9, [x10]                                  
02cbabd0: add     x8, x8, x9, lsl #4                         
02cbabd4: add     x0, x8, #0x138                             
02cbabd8: ldp     x8, x1, [x0]                               
02cbabdc: mov     x0, x20                                    
02cbabe0: blr     x8                                         
02cbabe4: cbnz    x19, #0x2cbac1c                            
02cbabe8: mov     x0, x21                                    
02cbabec: ldp     x20, x19, [sp, #0x60]                      
02cbabf0: ldp     x22, x21, [sp, #0x50]                      
02cbabf4: ldp     x24, x23, [sp, #0x40]                      
02cbabf8: ldp     x30, x25, [sp, #0x30]                      
02cbabfc: add     sp, sp, #0x70                              
02cbac00: ret                                                
02cbac04: mov     x0, x21                                    
02cbac08: bl      #0x2b713dc                                 fn_2b713dc
02cbac0c: bl      #0x2b7105c                                 fn_2b7105c
02cbac10: bl      #0x2b7105c                                 fn_2b7105c
02cbac14: bl      #0x2b7105c                                 fn_2b7105c
02cbac18: bl      #0x2b7105c                                 fn_2b7105c
02cbac1c: mov     x0, x19                                    
02cbac20: bl      #0x2b71054                                 fn_2b71054
02cbac24: b       #0x2cbac4c                                 
02cbac28: b       #0x2cbac4c                                 
02cbac2c: b       #0x2cbac4c                                 
02cbac30: b       #0x2cbac4c                                 
02cbac34: b       #0x2cbac4c                                 
02cbac38: b       #0x2cbac4c                                 
02cbac3c: b       #0x2cbac4c                                 
02cbac40: b       #0x2cbac4c                                 
02cbac44: b       #0x2cbac4c                                 
02cbac48: b       #0x2cbac4c                                 
02cbac4c: mov     x19, x0                                    
02cbac50: cmp     w1, #1                                     
02cbac54: b.ne    #0x2cbac7c                                 
02cbac58: mov     x0, x19                                    
02cbac5c: bl      #0x5e90260                                 fn_5e90260
02cbac60: ldr     x19, [x0]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02cbac64: str     x19, [sp, #8]                              
02cbac68: bl      #0x5e90270                                 fn_5e90270
02cbac6c: ldp     x8, x23, [sp, #0x10]                       
02cbac70: mov     x21, xzr                                   
02cbac74: b       #0x2cbab74                                 
02cbac78: mov     x19, x0                                    
02cbac7c: add     x0, sp, #8                                 
02cbac80: bl      #0x2736a80                                 fn_2736a80
02cbac84: mov     x0, x19                                    
02cbac88: bl      #0x2c6051c                                 fn_2c6051c
02cbac8c: bl      #0x27369b8                                 fn_27369b8
## DestroyAllChildren(UnityEngine.Transform transform, System.Type exceptChildType, string exceptChildName, Framework.EStringMatchType matchType) -> void
---- Framework.TranformExtension::DestroyAllChildren 0x2cbac90
02cbac90: sub     sp, sp, #0x60                              
02cbac94: stp     x30, x27, [sp, #0x10]                      
02cbac98: stp     x26, x25, [sp, #0x20]                      
02cbac9c: stp     x24, x23, [sp, #0x30]                      
02cbaca0: stp     x22, x21, [sp, #0x40]                      
02cbaca4: stp     x20, x19, [sp, #0x50]                      
02cbaca8: adrp    x23, #0x662f000                            
02cbacac: mov     w19, w3                                    
02cbacb0: mov     x20, x2                                    
02cbacb4: ldrb    w8, [x23, #0xbf0]                          
02cbacb8: mov     x21, x1                                    
02cbacbc: mov     x22, x0                                    
02cbacc0: tbnz    w8, #0, #0x2cbace4                         
02cbacc4: adrp    x0, #0x6264000                             
02cbacc8: ldr     x0, [x0, #0xa70]                           T:UnityEngine.Application
02cbaccc: bl      #0x2b70db0                                 fn_2b70db0
02cbacd0: adrp    x0, #0x6263000                             
02cbacd4: ldr     x0, [x0, #0x918]                           T:UnityEngine.Object
02cbacd8: bl      #0x2b70db0                                 fn_2b70db0
02cbacdc: mov     w8, #1                                     
02cbace0: strb    w8, [x23, #0xbf0]                          
02cbace4: str     xzr, [sp, #8]                              
02cbace8: cbz     x22, #0x2cbae44                            
02cbacec: mov     x0, x22                                    
02cbacf0: mov     x1, xzr                                    
02cbacf4: bl      #0x5b482c4                                 UnityEngine.Transform::get_childCount
02cbacf8: cmp     w0, #1                                     
02cbacfc: b.mi    #0x2cbae28                                 
02cbad00: adrp    x25, #0x6264000                            
02cbad04: adrp    x26, #0x6263000                            
02cbad08: adrp    x27, #0x6263000                            
02cbad0c: ldr     x25, [x25, #0xa70]                         T:UnityEngine.Application
02cbad10: ldr     x26, [x26, #0x918]                         T:UnityEngine.Object
02cbad14: ldr     x27, [x27, #0x970]                         &6645c70(=0)
02cbad18: mov     w23, w0                                    
02cbad1c: sub     w23, w23, #1                               
02cbad20: mov     x0, x22                                    
02cbad24: mov     x2, xzr                                    
02cbad28: mov     w1, w23                                    
02cbad2c: bl      #0x5b48d44                                 UnityEngine.Transform::GetChild
02cbad30: mov     x24, x0                                    
02cbad34: cbz     x20, #0x2cbad58                            
02cbad38: cbz     x24, #0x2cbae44                            
02cbad3c: mov     x0, x24                                    
02cbad40: mov     x1, xzr                                    
02cbad44: bl      #0x5b3bba4                                 UnityEngine.Object::get_name
02cbad48: mov     x1, x20                                    
02cbad4c: mov     w2, w19                                    
02cbad50: bl      #0x2cba130                                 Framework.StringExtension::IsMatchWith
02cbad54: tbnz    w0, #0, #0x2cbae20                         
02cbad58: ldr     x0, [x27, #0xe0]                           &2c5bf4c(=a9be7bfdd503233f)
02cbad5c: ldr     w8, [x0, #0xe4]                            [62630e4]=0 f=0,0
02cbad60: cbnz    w8, #0x2cbad68                             
02cbad64: bl      #0x2b70f30                                 fn_2b70f30
02cbad68: mov     x0, x21                                    
02cbad6c: mov     x1, xzr                                    
02cbad70: mov     x2, xzr                                    
02cbad74: bl      #0x4e2b088                                 System.Type::op_Inequality
02cbad78: tbz     w0, #0, #0x2cbad98                         
02cbad7c: cbz     x24, #0x2cbae44                            
02cbad80: add     x2, sp, #8                                 
02cbad84: mov     x0, x24                                    
02cbad88: mov     x1, x21                                    
02cbad8c: mov     x3, xzr                                    
02cbad90: bl      #0x5b33c64                                 UnityEngine.Component::TryGetComponent
02cbad94: tbnz    w0, #0, #0x2cbae20                         
02cbad98: ldr     x0, [x25]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02cbad9c: ldr     w8, [x0, #0xe4]                            [62630e4]=0 f=0,0
02cbada0: cbnz    w8, #0x2cbada8                             
02cbada4: bl      #0x2b70f30                                 fn_2b70f30
02cbada8: mov     x0, xzr                                    
02cbadac: bl      #0x5aea438                                 UnityEngine.Application::get_isPlaying
02cbadb0: tbz     w0, #0, #0x2cbadec                         
02cbadb4: cbz     x24, #0x2cbae44                            
02cbadb8: mov     x0, x24                                    
02cbadbc: mov     x1, xzr                                    
02cbadc0: bl      #0x5b339ec                                 UnityEngine.Component::get_gameObject
02cbadc4: ldr     x8, [x26]                                  &2c5bbd4(=a9bd7bfdd503233f)
02cbadc8: mov     x24, x0                                    
02cbadcc: ldr     w9, [x8, #0xe4]                            
02cbadd0: cbnz    w9, #0x2cbaddc                             
02cbadd4: mov     x0, x8                                     
02cbadd8: bl      #0x2b70f30                                 fn_2b70f30
02cbaddc: mov     x0, x24                                    
02cbade0: mov     x1, xzr                                    
02cbade4: bl      #0x5b3ca38                                 UnityEngine.Object::Destroy
02cbade8: b       #0x2cbae20                                 
02cbadec: cbz     x24, #0x2cbae44                            
02cbadf0: mov     x0, x24                                    
02cbadf4: mov     x1, xzr                                    
02cbadf8: bl      #0x5b339ec                                 UnityEngine.Component::get_gameObject
02cbadfc: ldr     x8, [x26]                                  &2c5bbd4(=a9bd7bfdd503233f)
02cbae00: mov     x24, x0                                    
02cbae04: ldr     w9, [x8, #0xe4]                            
02cbae08: cbnz    w9, #0x2cbae14                             
02cbae0c: mov     x0, x8                                     
02cbae10: bl      #0x2b70f30                                 fn_2b70f30
02cbae14: mov     x0, x24                                    
02cbae18: mov     x1, xzr                                    
02cbae1c: bl      #0x5b3cb84                                 UnityEngine.Object::DestroyImmediate
02cbae20: cmp     w23, #0                                    
02cbae24: b.gt    #0x2cbad1c                                 
02cbae28: ldp     x20, x19, [sp, #0x50]                      
02cbae2c: ldp     x22, x21, [sp, #0x40]                      
02cbae30: ldp     x24, x23, [sp, #0x30]                      
02cbae34: ldp     x26, x25, [sp, #0x20]                      
02cbae38: ldp     x30, x27, [sp, #0x10]                      
02cbae3c: add     sp, sp, #0x60                              
02cbae40: ret                                                
02cbae44: bl      #0x2b7105c                                 fn_2b7105c
## SetPosX(UnityEngine.Transform tf, float x) -> void
---- Framework.TranformExtension::SetPosX 0x2cbae48
02cbae48: stp     d9, d8, [sp, #-0x20]!                      
02cbae4c: stp     x30, x19, [sp, #0x10]                      
02cbae50: cbz     x0, #0x2cbae90                             
02cbae54: mov     x1, xzr                                    
02cbae58: mov     x19, x0                                    
02cbae5c: fmov    s8, s0                                     
02cbae60: bl      #0x5b467ac                                 UnityEngine.Transform::get_position
02cbae64: mov     x0, x19                                    
02cbae68: mov     x1, xzr                                    
02cbae6c: fmov    s9, s1                                     
02cbae70: bl      #0x5b467ac                                 UnityEngine.Transform::get_position
02cbae74: mov     x0, x19                                    
02cbae78: ldp     x30, x19, [sp, #0x10]                      
02cbae7c: fmov    s0, s8                                     
02cbae80: fmov    s1, s9                                     
02cbae84: mov     x1, xzr                                    
02cbae88: ldp     d9, d8, [sp], #0x20                        
02cbae8c: b       #0x5b46888                                 UnityEngine.Transform::set_position
02cbae90: bl      #0x2b7105c                                 fn_2b7105c
## SetPosY(UnityEngine.Transform tf, float y) -> void
---- Framework.TranformExtension::SetPosY 0x2cbae94
02cbae94: stp     d9, d8, [sp, #-0x20]!                      
02cbae98: stp     x30, x19, [sp, #0x10]                      
02cbae9c: cbz     x0, #0x2cbaedc                             
02cbaea0: mov     x1, xzr                                    
02cbaea4: mov     x19, x0                                    
02cbaea8: fmov    s8, s0                                     
02cbaeac: bl      #0x5b467ac                                 UnityEngine.Transform::get_position
02cbaeb0: mov     x0, x19                                    
02cbaeb4: mov     x1, xzr                                    
02cbaeb8: fmov    s9, s0                                     
02cbaebc: bl      #0x5b467ac                                 UnityEngine.Transform::get_position
02cbaec0: mov     x0, x19                                    
02cbaec4: ldp     x30, x19, [sp, #0x10]                      
02cbaec8: fmov    s0, s9                                     
02cbaecc: fmov    s1, s8                                     
02cbaed0: mov     x1, xzr                                    
02cbaed4: ldp     d9, d8, [sp], #0x20                        
02cbaed8: b       #0x5b46888                                 UnityEngine.Transform::set_position
02cbaedc: bl      #0x2b7105c                                 fn_2b7105c
## SetPosZ(UnityEngine.Transform tf, float z) -> void
---- Framework.TranformExtension::SetPosZ 0x2cbaee0
02cbaee0: stp     d9, d8, [sp, #-0x20]!                      
02cbaee4: stp     x30, x19, [sp, #0x10]                      
02cbaee8: cbz     x0, #0x2cbaf28                             
02cbaeec: mov     x1, xzr                                    
02cbaef0: mov     x19, x0                                    
02cbaef4: fmov    s8, s0                                     
02cbaef8: bl      #0x5b467ac                                 UnityEngine.Transform::get_position
02cbaefc: mov     x0, x19                                    
02cbaf00: mov     x1, xzr                                    
02cbaf04: fmov    s9, s0                                     
02cbaf08: bl      #0x5b467ac                                 UnityEngine.Transform::get_position
02cbaf0c: mov     x0, x19                                    
02cbaf10: ldp     x30, x19, [sp, #0x10]                      
02cbaf14: fmov    s0, s9                                     
02cbaf18: fmov    s2, s8                                     
02cbaf1c: mov     x1, xzr                                    
02cbaf20: ldp     d9, d8, [sp], #0x20                        
02cbaf24: b       #0x5b46888                                 UnityEngine.Transform::set_position
02cbaf28: bl      #0x2b7105c                                 fn_2b7105c
## SetLocalPosX(UnityEngine.Transform tf, float x) -> void
---- Framework.TranformExtension::SetLocalPosX 0x2cbaf2c
02cbaf2c: stp     d9, d8, [sp, #-0x20]!                      
02cbaf30: stp     x30, x19, [sp, #0x10]                      
02cbaf34: cbz     x0, #0x2cbaf74                             
02cbaf38: mov     x1, xzr                                    
02cbaf3c: mov     x19, x0                                    
02cbaf40: fmov    s8, s0                                     
02cbaf44: bl      #0x5b45c24                                 UnityEngine.Transform::get_localPosition
02cbaf48: mov     x0, x19                                    
02cbaf4c: mov     x1, xzr                                    
02cbaf50: fmov    s9, s1                                     
02cbaf54: bl      #0x5b45c24                                 UnityEngine.Transform::get_localPosition
02cbaf58: mov     x0, x19                                    
02cbaf5c: ldp     x30, x19, [sp, #0x10]                      
02cbaf60: fmov    s0, s8                                     
02cbaf64: fmov    s1, s9                                     
02cbaf68: mov     x1, xzr                                    
02cbaf6c: ldp     d9, d8, [sp], #0x20                        
02cbaf70: b       #0x5b45cec                                 UnityEngine.Transform::set_localPosition
02cbaf74: bl      #0x2b7105c                                 fn_2b7105c
## SetLocalPosY(UnityEngine.Transform tf, float y) -> void
---- Framework.TranformExtension::SetLocalPosY 0x2cbaf78
02cbaf78: stp     d9, d8, [sp, #-0x20]!                      
02cbaf7c: stp     x30, x19, [sp, #0x10]                      
02cbaf80: cbz     x0, #0x2cbafc0                             
02cbaf84: mov     x1, xzr                                    
02cbaf88: mov     x19, x0                                    
02cbaf8c: fmov    s8, s0                                     
02cbaf90: bl      #0x5b45c24                                 UnityEngine.Transform::get_localPosition
02cbaf94: mov     x0, x19                                    
02cbaf98: mov     x1, xzr                                    
02cbaf9c: fmov    s9, s0                                     
02cbafa0: bl      #0x5b45c24                                 UnityEngine.Transform::get_localPosition
02cbafa4: mov     x0, x19                                    
02cbafa8: ldp     x30, x19, [sp, #0x10]                      
02cbafac: fmov    s0, s9                                     
02cbafb0: fmov    s1, s8                                     
02cbafb4: mov     x1, xzr                                    
02cbafb8: ldp     d9, d8, [sp], #0x20                        
02cbafbc: b       #0x5b45cec                                 UnityEngine.Transform::set_localPosition
02cbafc0: bl      #0x2b7105c                                 fn_2b7105c
## SetLocalPosZ(UnityEngine.Transform self, float z) -> void
---- Framework.TranformExtension::SetLocalPosZ 0x2cbafc4
02cbafc4: stp     d9, d8, [sp, #-0x20]!                      
02cbafc8: stp     x30, x19, [sp, #0x10]                      
02cbafcc: cbz     x0, #0x2cbb00c                             
02cbafd0: mov     x1, xzr                                    
02cbafd4: mov     x19, x0                                    
02cbafd8: fmov    s8, s0                                     
02cbafdc: bl      #0x5b45c24                                 UnityEngine.Transform::get_localPosition
02cbafe0: mov     x0, x19                                    
02cbafe4: mov     x1, xzr                                    
02cbafe8: fmov    s9, s0                                     
02cbafec: bl      #0x5b45c24                                 UnityEngine.Transform::get_localPosition
02cbaff0: mov     x0, x19                                    
02cbaff4: ldp     x30, x19, [sp, #0x10]                      
02cbaff8: fmov    s0, s9                                     
02cbaffc: fmov    s2, s8                                     
02cbb000: mov     x1, xzr                                    
02cbb004: ldp     d9, d8, [sp], #0x20                        
02cbb008: b       #0x5b45cec                                 UnityEngine.Transform::set_localPosition
02cbb00c: bl      #0x2b7105c                                 fn_2b7105c
## SetEulerAngleX(UnityEngine.Transform self, float x) -> void
---- Framework.TranformExtension::SetEulerAngleX 0x2cbb010
02cbb010: stp     d9, d8, [sp, #-0x20]!                      
02cbb014: stp     x30, x19, [sp, #0x10]                      
02cbb018: cbz     x0, #0x2cbb058                             
02cbb01c: mov     x1, xzr                                    
02cbb020: mov     x19, x0                                    
02cbb024: fmov    s8, s0                                     
02cbb028: bl      #0x5b469e4                                 UnityEngine.Transform::get_eulerAngles
02cbb02c: mov     x0, x19                                    
02cbb030: mov     x1, xzr                                    
02cbb034: fmov    s9, s1                                     
02cbb038: bl      #0x5b469e4                                 UnityEngine.Transform::get_eulerAngles
02cbb03c: mov     x0, x19                                    
02cbb040: ldp     x30, x19, [sp, #0x10]                      
02cbb044: fmov    s0, s8                                     
02cbb048: fmov    s1, s9                                     
02cbb04c: mov     x1, xzr                                    
02cbb050: ldp     d9, d8, [sp], #0x20                        
02cbb054: b       #0x5b46ac4                                 UnityEngine.Transform::set_eulerAngles
02cbb058: bl      #0x2b7105c                                 fn_2b7105c
## SetEulerAngleY(UnityEngine.Transform self, float y) -> void
---- Framework.TranformExtension::SetEulerAngleY 0x2cbb05c
02cbb05c: stp     d9, d8, [sp, #-0x20]!                      
02cbb060: stp     x30, x19, [sp, #0x10]                      
02cbb064: cbz     x0, #0x2cbb0a4                             
02cbb068: mov     x1, xzr                                    
02cbb06c: mov     x19, x0                                    
02cbb070: fmov    s8, s0                                     
02cbb074: bl      #0x5b469e4                                 UnityEngine.Transform::get_eulerAngles
02cbb078: mov     x0, x19                                    
02cbb07c: mov     x1, xzr                                    
02cbb080: fmov    s9, s0                                     
02cbb084: bl      #0x5b469e4                                 UnityEngine.Transform::get_eulerAngles
02cbb088: mov     x0, x19                                    
02cbb08c: ldp     x30, x19, [sp, #0x10]                      
02cbb090: fmov    s0, s9                                     
02cbb094: fmov    s1, s8                                     
02cbb098: mov     x1, xzr                                    
02cbb09c: ldp     d9, d8, [sp], #0x20                        
02cbb0a0: b       #0x5b46ac4                                 UnityEngine.Transform::set_eulerAngles
02cbb0a4: bl      #0x2b7105c                                 fn_2b7105c
## SetEulerAngleZ(UnityEngine.Transform self, float z) -> void
---- Framework.TranformExtension::SetEulerAngleZ 0x2cbb0a8
02cbb0a8: stp     d9, d8, [sp, #-0x20]!                      
02cbb0ac: stp     x30, x19, [sp, #0x10]                      
02cbb0b0: cbz     x0, #0x2cbb0f0                             
02cbb0b4: mov     x1, xzr                                    
02cbb0b8: mov     x19, x0                                    
02cbb0bc: fmov    s8, s0                                     
02cbb0c0: bl      #0x5b469e4                                 UnityEngine.Transform::get_eulerAngles
02cbb0c4: mov     x0, x19                                    
02cbb0c8: mov     x1, xzr                                    
02cbb0cc: fmov    s9, s0                                     
02cbb0d0: bl      #0x5b469e4                                 UnityEngine.Transform::get_eulerAngles
02cbb0d4: mov     x0, x19                                    
02cbb0d8: ldp     x30, x19, [sp, #0x10]                      
02cbb0dc: fmov    s0, s9                                     
02cbb0e0: fmov    s2, s8                                     
02cbb0e4: mov     x1, xzr                                    
02cbb0e8: ldp     d9, d8, [sp], #0x20                        
02cbb0ec: b       #0x5b46ac4                                 UnityEngine.Transform::set_eulerAngles
02cbb0f0: bl      #0x2b7105c                                 fn_2b7105c
## SetLocalEulerAngleX(UnityEngine.Transform self, float x) -> void
---- Framework.TranformExtension::SetLocalEulerAngleX 0x2cbb0f4
02cbb0f4: stp     d9, d8, [sp, #-0x20]!                      
02cbb0f8: stp     x30, x19, [sp, #0x10]                      
02cbb0fc: cbz     x0, #0x2cbb13c                             
02cbb100: mov     x1, xzr                                    
02cbb104: mov     x19, x0                                    
02cbb108: fmov    s8, s0                                     
02cbb10c: bl      #0x5b46ba8                                 UnityEngine.Transform::get_localEulerAngles
02cbb110: mov     x0, x19                                    
02cbb114: mov     x1, xzr                                    
02cbb118: fmov    s9, s1                                     
02cbb11c: bl      #0x5b46ba8                                 UnityEngine.Transform::get_localEulerAngles
02cbb120: mov     x0, x19                                    
02cbb124: ldp     x30, x19, [sp, #0x10]                      
02cbb128: fmov    s0, s8                                     
02cbb12c: fmov    s1, s9                                     
02cbb130: mov     x1, xzr                                    
02cbb134: ldp     d9, d8, [sp], #0x20                        
02cbb138: b       #0x5b46c88                                 UnityEngine.Transform::set_localEulerAngles
02cbb13c: bl      #0x2b7105c                                 fn_2b7105c
## SetLocalEulerAngleY(UnityEngine.Transform self, float y) -> void
---- Framework.TranformExtension::SetLocalEulerAngleY 0x2cbb140
02cbb140: stp     d9, d8, [sp, #-0x20]!                      
02cbb144: stp     x30, x19, [sp, #0x10]                      
02cbb148: cbz     x0, #0x2cbb188                             
02cbb14c: mov     x1, xzr                                    
02cbb150: mov     x19, x0                                    
02cbb154: fmov    s8, s0                                     
02cbb158: bl      #0x5b46ba8                                 UnityEngine.Transform::get_localEulerAngles
02cbb15c: mov     x0, x19                                    
02cbb160: mov     x1, xzr                                    
02cbb164: fmov    s9, s0                                     
02cbb168: bl      #0x5b46ba8                                 UnityEngine.Transform::get_localEulerAngles
02cbb16c: mov     x0, x19                                    
02cbb170: ldp     x30, x19, [sp, #0x10]                      
02cbb174: fmov    s0, s9                                     
02cbb178: fmov    s1, s8                                     
02cbb17c: mov     x1, xzr                                    
02cbb180: ldp     d9, d8, [sp], #0x20                        
02cbb184: b       #0x5b46c88                                 UnityEngine.Transform::set_localEulerAngles
02cbb188: bl      #0x2b7105c                                 fn_2b7105c
## SetLocalEulerAngleZ(UnityEngine.Transform self, float z) -> void
---- Framework.TranformExtension::SetLocalEulerAngleZ 0x2cbb18c
02cbb18c: stp     d9, d8, [sp, #-0x20]!                      
02cbb190: stp     x30, x19, [sp, #0x10]                      
02cbb194: cbz     x0, #0x2cbb1d4                             
02cbb198: mov     x1, xzr                                    
02cbb19c: mov     x19, x0                                    
02cbb1a0: fmov    s8, s0                                     
02cbb1a4: bl      #0x5b46ba8                                 UnityEngine.Transform::get_localEulerAngles
02cbb1a8: mov     x0, x19                                    
02cbb1ac: mov     x1, xzr                                    
02cbb1b0: fmov    s9, s0                                     
02cbb1b4: bl      #0x5b46ba8                                 UnityEngine.Transform::get_localEulerAngles
02cbb1b8: mov     x0, x19                                    
02cbb1bc: ldp     x30, x19, [sp, #0x10]                      
02cbb1c0: fmov    s0, s9                                     
02cbb1c4: fmov    s2, s8                                     
02cbb1c8: mov     x1, xzr                                    
02cbb1cc: ldp     d9, d8, [sp], #0x20                        
02cbb1d0: b       #0x5b46c88                                 UnityEngine.Transform::set_localEulerAngles
02cbb1d4: bl      #0x2b7105c                                 fn_2b7105c
## SetLocalScaleX(UnityEngine.Transform self, float value) -> void
---- Framework.TranformExtension::SetLocalScaleX 0x2cbb1d8
02cbb1d8: stp     d9, d8, [sp, #-0x20]!                      
02cbb1dc: stp     x30, x19, [sp, #0x10]                      
02cbb1e0: cbz     x0, #0x2cbb220                             
02cbb1e4: mov     x1, xzr                                    
02cbb1e8: mov     x19, x0                                    
02cbb1ec: fmov    s8, s0                                     
02cbb1f0: bl      #0x5b46ff0                                 UnityEngine.Transform::get_localScale
02cbb1f4: mov     x0, x19                                    
02cbb1f8: mov     x1, xzr                                    
02cbb1fc: fmov    s9, s1                                     
02cbb200: bl      #0x5b46ff0                                 UnityEngine.Transform::get_localScale
02cbb204: mov     x0, x19                                    
02cbb208: ldp     x30, x19, [sp, #0x10]                      
02cbb20c: fmov    s0, s8                                     
02cbb210: fmov    s1, s9                                     
02cbb214: mov     x1, xzr                                    
02cbb218: ldp     d9, d8, [sp], #0x20                        
02cbb21c: b       #0x5b470cc                                 UnityEngine.Transform::set_localScale
02cbb220: bl      #0x2b7105c                                 fn_2b7105c
## SetLocalScaleY(UnityEngine.Transform self, float value) -> void
---- Framework.TranformExtension::SetLocalScaleY 0x2cbb224
02cbb224: stp     d9, d8, [sp, #-0x20]!                      
02cbb228: stp     x30, x19, [sp, #0x10]                      
02cbb22c: cbz     x0, #0x2cbb26c                             
02cbb230: mov     x1, xzr                                    
02cbb234: mov     x19, x0                                    
02cbb238: fmov    s8, s0                                     
02cbb23c: bl      #0x5b46ff0                                 UnityEngine.Transform::get_localScale
02cbb240: mov     x0, x19                                    
02cbb244: mov     x1, xzr                                    
02cbb248: fmov    s9, s0                                     
02cbb24c: bl      #0x5b46ff0                                 UnityEngine.Transform::get_localScale
02cbb250: mov     x0, x19                                    
02cbb254: ldp     x30, x19, [sp, #0x10]                      
02cbb258: fmov    s0, s9                                     
02cbb25c: fmov    s1, s8                                     
02cbb260: mov     x1, xzr                                    
02cbb264: ldp     d9, d8, [sp], #0x20                        
02cbb268: b       #0x5b470cc                                 UnityEngine.Transform::set_localScale
02cbb26c: bl      #0x2b7105c                                 fn_2b7105c
## SetLocalScaleZ(UnityEngine.Transform self, float value) -> void
---- Framework.TranformExtension::SetLocalScaleZ 0x2cbb270
02cbb270: stp     d9, d8, [sp, #-0x20]!                      
02cbb274: stp     x30, x19, [sp, #0x10]                      
02cbb278: cbz     x0, #0x2cbb2b8                             
02cbb27c: mov     x1, xzr                                    
02cbb280: mov     x19, x0                                    
02cbb284: fmov    s8, s0                                     
02cbb288: bl      #0x5b46ff0                                 UnityEngine.Transform::get_localScale
02cbb28c: mov     x0, x19                                    
02cbb290: mov     x1, xzr                                    
02cbb294: fmov    s9, s0                                     
02cbb298: bl      #0x5b46ff0                                 UnityEngine.Transform::get_localScale
02cbb29c: mov     x0, x19                                    
02cbb2a0: ldp     x30, x19, [sp, #0x10]                      
02cbb2a4: fmov    s0, s9                                     
02cbb2a8: fmov    s2, s8                                     
02cbb2ac: mov     x1, xzr                                    
02cbb2b0: ldp     d9, d8, [sp], #0x20                        
02cbb2b4: b       #0x5b470cc                                 UnityEngine.Transform::set_localScale
02cbb2b8: bl      #0x2b7105c                                 fn_2b7105c
## AddPosX(UnityEngine.Transform self, float x) -> void
---- Framework.TranformExtension::AddPosX 0x2cbb2bc
02cbb2bc: str     d8, [sp, #-0x20]!                          
02cbb2c0: stp     x30, x19, [sp, #0x10]                      
02cbb2c4: cbz     x0, #0x2cbb2ec                             
02cbb2c8: mov     x1, xzr                                    
02cbb2cc: mov     x19, x0                                    
02cbb2d0: fmov    s8, s0                                     
02cbb2d4: bl      #0x5b467ac                                 UnityEngine.Transform::get_position
02cbb2d8: mov     x0, x19                                    
02cbb2dc: ldp     x30, x19, [sp, #0x10]                      
02cbb2e0: fadd    s0, s0, s8                                 
02cbb2e4: ldr     d8, [sp], #0x20                            
02cbb2e8: b       #0x2cbae48                                 Framework.TranformExtension::SetPosX
02cbb2ec: bl      #0x2b7105c                                 fn_2b7105c
## AddPosY(UnityEngine.Transform self, float y) -> void
---- Framework.TranformExtension::AddPosY 0x2cbb2f0
02cbb2f0: str     d8, [sp, #-0x20]!                          
02cbb2f4: stp     x30, x19, [sp, #0x10]                      
02cbb2f8: cbz     x0, #0x2cbb320                             
02cbb2fc: mov     x1, xzr                                    
02cbb300: mov     x19, x0                                    
02cbb304: fmov    s8, s0                                     
02cbb308: bl      #0x5b467ac                                 UnityEngine.Transform::get_position
02cbb30c: mov     x0, x19                                    
02cbb310: ldp     x30, x19, [sp, #0x10]                      
02cbb314: fadd    s0, s1, s8                                 
02cbb318: ldr     d8, [sp], #0x20                            
02cbb31c: b       #0x2cbae94                                 Framework.TranformExtension::SetPosY
02cbb320: bl      #0x2b7105c                                 fn_2b7105c
## AddPosZ(UnityEngine.Transform self, float z) -> void
---- Framework.TranformExtension::AddPosZ 0x2cbb324
02cbb324: str     d8, [sp, #-0x20]!                          
02cbb328: stp     x30, x19, [sp, #0x10]                      
02cbb32c: cbz     x0, #0x2cbb354                             
02cbb330: mov     x1, xzr                                    
02cbb334: mov     x19, x0                                    
02cbb338: fmov    s8, s0                                     
02cbb33c: bl      #0x5b467ac                                 UnityEngine.Transform::get_position
02cbb340: mov     x0, x19                                    
02cbb344: ldp     x30, x19, [sp, #0x10]                      
02cbb348: fadd    s0, s2, s8                                 
02cbb34c: ldr     d8, [sp], #0x20                            
02cbb350: b       #0x2cbaee0                                 Framework.TranformExtension::SetPosZ
02cbb354: bl      #0x2b7105c                                 fn_2b7105c
## AddLocalPosX(UnityEngine.Transform self, float x) -> void
---- Framework.TranformExtension::AddLocalPosX 0x2cbb358
02cbb358: str     d8, [sp, #-0x20]!                          
02cbb35c: stp     x30, x19, [sp, #0x10]                      
02cbb360: cbz     x0, #0x2cbb388                             
02cbb364: mov     x1, xzr                                    
02cbb368: mov     x19, x0                                    
02cbb36c: fmov    s8, s0                                     
02cbb370: bl      #0x5b45c24                                 UnityEngine.Transform::get_localPosition
02cbb374: mov     x0, x19                                    
02cbb378: ldp     x30, x19, [sp, #0x10]                      
02cbb37c: fadd    s0, s0, s8                                 
02cbb380: ldr     d8, [sp], #0x20                            
02cbb384: b       #0x2cbaf2c                                 Framework.TranformExtension::SetLocalPosX
02cbb388: bl      #0x2b7105c                                 fn_2b7105c
## AddLocalPosY(UnityEngine.Transform self, float y) -> void
---- Framework.TranformExtension::AddLocalPosY 0x2cbb38c
02cbb38c: str     d8, [sp, #-0x20]!                          
02cbb390: stp     x30, x19, [sp, #0x10]                      
02cbb394: cbz     x0, #0x2cbb3bc                             
02cbb398: mov     x1, xzr                                    
02cbb39c: mov     x19, x0                                    
02cbb3a0: fmov    s8, s0                                     
02cbb3a4: bl      #0x5b45c24                                 UnityEngine.Transform::get_localPosition
02cbb3a8: mov     x0, x19                                    
02cbb3ac: ldp     x30, x19, [sp, #0x10]                      
02cbb3b0: fadd    s0, s1, s8                                 
02cbb3b4: ldr     d8, [sp], #0x20                            
02cbb3b8: b       #0x2cbaf78                                 Framework.TranformExtension::SetLocalPosY
02cbb3bc: bl      #0x2b7105c                                 fn_2b7105c
## AddLocalPosZ(UnityEngine.Transform self, float z) -> void
---- Framework.TranformExtension::AddLocalPosZ 0x2cbb3c0
02cbb3c0: str     d8, [sp, #-0x20]!                          
02cbb3c4: stp     x30, x19, [sp, #0x10]                      
02cbb3c8: cbz     x0, #0x2cbb3f0                             
02cbb3cc: mov     x1, xzr                                    
02cbb3d0: mov     x19, x0                                    
02cbb3d4: fmov    s8, s0                                     
02cbb3d8: bl      #0x5b45c24                                 UnityEngine.Transform::get_localPosition
02cbb3dc: mov     x0, x19                                    
02cbb3e0: ldp     x30, x19, [sp, #0x10]                      
02cbb3e4: fadd    s0, s2, s8                                 
02cbb3e8: ldr     d8, [sp], #0x20                            
02cbb3ec: b       #0x2cbafc4                                 Framework.TranformExtension::SetLocalPosZ
02cbb3f0: bl      #0x2b7105c                                 fn_2b7105c
## AddEulerAngleX(UnityEngine.Transform self, float x) -> void
---- Framework.TranformExtension::AddEulerAngleX 0x2cbb3f4
02cbb3f4: str     d8, [sp, #-0x20]!                          
02cbb3f8: stp     x30, x19, [sp, #0x10]                      
02cbb3fc: cbz     x0, #0x2cbb424                             
02cbb400: mov     x1, xzr                                    
02cbb404: mov     x19, x0                                    
02cbb408: fmov    s8, s0                                     
02cbb40c: bl      #0x5b469e4                                 UnityEngine.Transform::get_eulerAngles
02cbb410: mov     x0, x19                                    
02cbb414: ldp     x30, x19, [sp, #0x10]                      
02cbb418: fadd    s0, s0, s8                                 
02cbb41c: ldr     d8, [sp], #0x20                            
02cbb420: b       #0x2cbb010                                 Framework.TranformExtension::SetEulerAngleX
02cbb424: bl      #0x2b7105c                                 fn_2b7105c
## AddEulerAngleY(UnityEngine.Transform self, float y) -> void
---- Framework.TranformExtension::AddEulerAngleY 0x2cbb428
02cbb428: str     d8, [sp, #-0x20]!                          
02cbb42c: stp     x30, x19, [sp, #0x10]                      
02cbb430: cbz     x0, #0x2cbb458                             
02cbb434: mov     x1, xzr                                    
02cbb438: mov     x19, x0                                    
02cbb43c: fmov    s8, s0                                     
02cbb440: bl      #0x5b469e4                                 UnityEngine.Transform::get_eulerAngles
02cbb444: mov     x0, x19                                    
02cbb448: ldp     x30, x19, [sp, #0x10]                      
02cbb44c: fadd    s0, s1, s8                                 
02cbb450: ldr     d8, [sp], #0x20                            
02cbb454: b       #0x2cbb05c                                 Framework.TranformExtension::SetEulerAngleY
02cbb458: bl      #0x2b7105c                                 fn_2b7105c
## AddEulerAngleZ(UnityEngine.Transform self, float z) -> void
---- Framework.TranformExtension::AddEulerAngleZ 0x2cbb45c
02cbb45c: str     d8, [sp, #-0x20]!                          
02cbb460: stp     x30, x19, [sp, #0x10]                      
02cbb464: cbz     x0, #0x2cbb48c                             
02cbb468: mov     x1, xzr                                    
02cbb46c: mov     x19, x0                                    
02cbb470: fmov    s8, s0                                     
02cbb474: bl      #0x5b469e4                                 UnityEngine.Transform::get_eulerAngles
02cbb478: mov     x0, x19                                    
02cbb47c: ldp     x30, x19, [sp, #0x10]                      
02cbb480: fadd    s0, s2, s8                                 
02cbb484: ldr     d8, [sp], #0x20                            
02cbb488: b       #0x2cbb0a8                                 Framework.TranformExtension::SetEulerAngleZ
02cbb48c: bl      #0x2b7105c                                 fn_2b7105c
## AddLocalEulerAngleX(UnityEngine.Transform self, float x) -> void
---- Framework.TranformExtension::AddLocalEulerAngleX 0x2cbb490
02cbb490: str     d8, [sp, #-0x20]!                          
02cbb494: stp     x30, x19, [sp, #0x10]                      
02cbb498: cbz     x0, #0x2cbb4c0                             
02cbb49c: mov     x1, xzr                                    
02cbb4a0: mov     x19, x0                                    
02cbb4a4: fmov    s8, s0                                     
02cbb4a8: bl      #0x5b46ba8                                 UnityEngine.Transform::get_localEulerAngles
02cbb4ac: mov     x0, x19                                    
02cbb4b0: ldp     x30, x19, [sp, #0x10]                      
02cbb4b4: fadd    s0, s0, s8                                 
02cbb4b8: ldr     d8, [sp], #0x20                            
02cbb4bc: b       #0x2cbb0f4                                 Framework.TranformExtension::SetLocalEulerAngleX
02cbb4c0: bl      #0x2b7105c                                 fn_2b7105c
## AddLocalEulerAngleY(UnityEngine.Transform self, float y) -> void
---- Framework.TranformExtension::AddLocalEulerAngleY 0x2cbb4c4
02cbb4c4: str     d8, [sp, #-0x20]!                          
02cbb4c8: stp     x30, x19, [sp, #0x10]                      
02cbb4cc: cbz     x0, #0x2cbb4f4                             
02cbb4d0: mov     x1, xzr                                    
02cbb4d4: mov     x19, x0                                    
02cbb4d8: fmov    s8, s0                                     
02cbb4dc: bl      #0x5b46ba8                                 UnityEngine.Transform::get_localEulerAngles
02cbb4e0: mov     x0, x19                                    
02cbb4e4: ldp     x30, x19, [sp, #0x10]                      
02cbb4e8: fadd    s0, s1, s8                                 
02cbb4ec: ldr     d8, [sp], #0x20                            
02cbb4f0: b       #0x2cbb140                                 Framework.TranformExtension::SetLocalEulerAngleY
02cbb4f4: bl      #0x2b7105c                                 fn_2b7105c
## AddLocalEulerAngleZ(UnityEngine.Transform self, float z) -> void
---- Framework.TranformExtension::AddLocalEulerAngleZ 0x2cbb4f8
02cbb4f8: str     d8, [sp, #-0x20]!                          
02cbb4fc: stp     x30, x19, [sp, #0x10]                      
02cbb500: cbz     x0, #0x2cbb528                             
02cbb504: mov     x1, xzr                                    
02cbb508: mov     x19, x0                                    
02cbb50c: fmov    s8, s0                                     
02cbb510: bl      #0x5b46ba8                                 UnityEngine.Transform::get_localEulerAngles
02cbb514: mov     x0, x19                                    
02cbb518: ldp     x30, x19, [sp, #0x10]                      
02cbb51c: fadd    s0, s2, s8                                 
02cbb520: ldr     d8, [sp], #0x20                            
02cbb524: b       #0x2cbb18c                                 Framework.TranformExtension::SetLocalEulerAngleZ
02cbb528: bl      #0x2b7105c                                 fn_2b7105c
## AddLocalScaleX(UnityEngine.Transform self, float value) -> void
---- Framework.TranformExtension::AddLocalScaleX 0x2cbb52c
02cbb52c: str     d8, [sp, #-0x20]!                          
02cbb530: stp     x30, x19, [sp, #0x10]                      
02cbb534: cbz     x0, #0x2cbb55c                             
02cbb538: mov     x1, xzr                                    
02cbb53c: mov     x19, x0                                    
02cbb540: fmov    s8, s0                                     
02cbb544: bl      #0x5b46ff0                                 UnityEngine.Transform::get_localScale
02cbb548: mov     x0, x19                                    
02cbb54c: ldp     x30, x19, [sp, #0x10]                      
02cbb550: fadd    s0, s0, s8                                 
02cbb554: ldr     d8, [sp], #0x20                            
02cbb558: b       #0x2cbb1d8                                 Framework.TranformExtension::SetLocalScaleX
02cbb55c: bl      #0x2b7105c                                 fn_2b7105c
## AddLocalScaleY(UnityEngine.Transform self, float value) -> void
---- Framework.TranformExtension::AddLocalScaleY 0x2cbb560
02cbb560: str     d8, [sp, #-0x20]!                          
02cbb564: stp     x30, x19, [sp, #0x10]                      
02cbb568: cbz     x0, #0x2cbb590                             
02cbb56c: mov     x1, xzr                                    
02cbb570: mov     x19, x0                                    
02cbb574: fmov    s8, s0                                     
02cbb578: bl      #0x5b46ff0                                 UnityEngine.Transform::get_localScale
02cbb57c: mov     x0, x19                                    
02cbb580: ldp     x30, x19, [sp, #0x10]                      
02cbb584: fadd    s0, s1, s8                                 
02cbb588: ldr     d8, [sp], #0x20                            
02cbb58c: b       #0x2cbb224                                 Framework.TranformExtension::SetLocalScaleY
02cbb590: bl      #0x2b7105c                                 fn_2b7105c
## AddLocalScaleZ(UnityEngine.Transform self, float value) -> void
---- Framework.TranformExtension::AddLocalScaleZ 0x2cbb594
02cbb594: str     d8, [sp, #-0x20]!                          
02cbb598: stp     x30, x19, [sp, #0x10]                      
02cbb59c: cbz     x0, #0x2cbb5c4                             
02cbb5a0: mov     x1, xzr                                    
02cbb5a4: mov     x19, x0                                    
02cbb5a8: fmov    s8, s0                                     
02cbb5ac: bl      #0x5b46ff0                                 UnityEngine.Transform::get_localScale
02cbb5b0: mov     x0, x19                                    
02cbb5b4: ldp     x30, x19, [sp, #0x10]                      
02cbb5b8: fadd    s0, s2, s8                                 
02cbb5bc: ldr     d8, [sp], #0x20                            
02cbb5c0: b       #0x2cbb270                                 Framework.TranformExtension::SetLocalScaleZ
02cbb5c4: bl      #0x2b7105c                                 fn_2b7105c
