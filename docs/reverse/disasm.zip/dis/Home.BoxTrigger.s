#### CLASS Home.BoxTrigger parent= UnityEngine.MonoBehaviour
#   field Name                           Home.EntityName                                    off=0x20 attr=1 SerializeField
#   field OnPressed                      UnityEngine.Events.UnityAction`1<Home.EntityName>  off=0x28 attr=6 
#   field _box                           UnityEngine.BoxCollider2D                          off=0x30 attr=1 
## OnEnable() -> void
---- Home.BoxTrigger::OnEnable 0x2d23bd4
02d23bd4: stp     x30, x21, [sp, #-0x20]!                    
02d23bd8: stp     x20, x19, [sp, #0x10]                      
02d23bdc: adrp    x20, #0x6630000                            
02d23be0: adrp    x21, #0x6269000                            
02d23be4: mov     x19, x0                                    
02d23be8: ldrb    w8, [x20, #0x59]                           
02d23bec: ldr     x21, [x21, #0xed8]                         MS:UnityEngine.Component::GetComponent
02d23bf0: tbnz    w8, #0, #0x2d23c08                         
02d23bf4: adrp    x0, #0x6269000                             
02d23bf8: ldr     x0, [x0, #0xed8]                           MS:UnityEngine.Component::GetComponent
02d23bfc: bl      #0x2b70db0                                 fn_2b70db0
02d23c00: mov     w8, #1                                     
02d23c04: strb    w8, [x20, #0x59]                           
02d23c08: ldr     x1, [x21]                                  T:Trading.TradingSession/<>c__DisplayClass56_0
02d23c0c: mov     x0, x19                                    
02d23c10: bl      #0x3140c84                                 fn_3140c84
02d23c14: str     x0, [x19, #0x30]!                          ._box
02d23c18: mov     x1, x0                                     
02d23c1c: mov     x0, x19                                    
02d23c20: ldp     x20, x19, [sp, #0x10]                      
02d23c24: ldp     x30, x21, [sp], #0x20                      
02d23c28: b       #0x2b70d54                                 
## EnableBoxCollider(bool enable) -> void
---- Home.BoxTrigger::EnableBoxCollider 0x2d23c2c
02d23c2c: ldr     x0, [x0, #0x30]                            ._box
02d23c30: cbz     x0, #0x2d23c40                             
02d23c34: and     w1, w1, #1                                 
02d23c38: mov     x2, xzr                                    
02d23c3c: b       #0x5b33110                                 UnityEngine.Behaviour::set_enabled
02d23c40: str     x30, [sp, #-0x10]!                         
02d23c44: bl      #0x2b7105c                                 fn_2b7105c
## OnMouseButtonDown() -> void
---- Home.BoxTrigger::OnMouseButtonDown 0x2d1ec38
02d1ec38: ldr     x8, [x0, #0x28]                            .OnPressed
02d1ec3c: cbz     x8, #0x2d1ec54                             
02d1ec40: ldr     w1, [x0, #0x20]                            .Name
02d1ec44: ldr     x0, [x8, #0x40]                            
02d1ec48: ldr     x2, [x8, #0x28]                            
02d1ec4c: ldr     x3, [x8, #0x18]                            
02d1ec50: br      x3                                         
02d1ec54: ret                                                
## .ctor() -> void
---- Home.BoxTrigger::.ctor 0x2d23c48
02d23c48: mov     x1, xzr                                    
02d23c4c: b       #0x5b397b0                                 UnityEngine.MonoBehaviour::.ctor
