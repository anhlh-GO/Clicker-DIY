#### CLASS ChannelType parent= int
#   field value__                        int                                                off=0x10 attr=606 
#   field TEST1_5                        ChannelType                                        off=0x0 attr=8056 
#   field TEST2_6                        ChannelType                                        off=0x0 attr=8056 
#   field TEST3_7                        ChannelType                                        off=0x0 attr=8056 
