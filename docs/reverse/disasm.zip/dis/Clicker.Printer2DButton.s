#### CLASS Clicker.Printer2DButton parent= UnityEngine.MonoBehaviour
#   field _startButton                   UnityEngine.UI.Button                              off=0x20 attr=1 SerializeField
#   field _speedUpButton                 UnityEngine.UI.Button                              off=0x28 attr=1 SerializeField
#   field _printerMachine                Clicker.PrinterMachine                             off=0x30 attr=1 
## Init(Clicker.PrinterMachine printerMachine) -> void
---- Clicker.Printer2DButton::Init 0x2d643dc
02d643dc: str     x30, [sp, #-0x30]!                         
02d643e0: stp     x22, x21, [sp, #0x10]                      
02d643e4: stp     x20, x19, [sp, #0x20]                      
02d643e8: adrp    x21, #0x6630000                            
02d643ec: mov     x20, x1                                    
02d643f0: mov     x19, x0                                    
02d643f4: ldrb    w8, [x21, #0x31b]                          
02d643f8: tbnz    w8, #0, #0x2d64428                         
02d643fc: adrp    x0, #0x626c000                             
02d64400: ldr     x0, [x0, #0xd0]                            M:Clicker.Printer2DButton::<Init>b__3_0
02d64404: bl      #0x2b70db0                                 fn_2b70db0
02d64408: adrp    x0, #0x626c000                             
02d6440c: ldr     x0, [x0, #0xd8]                            M:Clicker.Printer2DButton::<Init>b__3_1
02d64410: bl      #0x2b70db0                                 fn_2b70db0
02d64414: adrp    x0, #0x6265000                             
02d64418: ldr     x0, [x0, #0x3f0]                           T:UnityEngine.Events.UnityAction
02d6441c: bl      #0x2b70db0                                 fn_2b70db0
02d64420: mov     w8, #1                                     
02d64424: strb    w8, [x21, #0x31b]                          
02d64428: mov     x21, x19                                   
02d6442c: mov     x1, x20                                    
02d64430: str     x20, [x21, #0x30]!                         ._printerMachine
02d64434: mov     x0, x21                                    
02d64438: bl      #0x2b70d54                                 fn_2b70d54
02d6443c: ldur    x8, [x21, #-0x10]                          
02d64440: cbz     x8, #0x2d644d8                             
02d64444: adrp    x22, #0x6265000                            
02d64448: adrp    x21, #0x626c000                            
02d6444c: ldr     x22, [x22, #0x3f0]                         T:UnityEngine.Events.UnityAction
02d64450: ldr     x21, [x21, #0xd0]                          M:Clicker.Printer2DButton::<Init>b__3_0
02d64454: ldr     x20, [x8, #0x100]                          
02d64458: ldr     x0, [x22]                                  M:AdsManager::<OnApplicationPause>b__26_0
02d6445c: bl      #0x2b7104c                                 fn_2b7104c
02d64460: ldr     x2, [x21]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d64464: mov     x1, x19                                    
02d64468: mov     x3, xzr                                    
02d6446c: mov     x21, x0                                    
02d64470: bl      #0x5b4cf98                                 UnityEngine.Events.UnityAction::.ctor
02d64474: cbz     x20, #0x2d644d8                            
02d64478: mov     x0, x20                                    
02d6447c: mov     x1, x21                                    
02d64480: mov     x2, xzr                                    
02d64484: bl      #0x5b4d0ac                                 UnityEngine.Events.UnityEvent::AddListener
02d64488: ldr     x8, [x19, #0x28]                           ._speedUpButton
02d6448c: cbz     x8, #0x2d644d8                             
02d64490: adrp    x21, #0x626c000                            
02d64494: ldr     x21, [x21, #0xd8]                          M:Clicker.Printer2DButton::<Init>b__3_1
02d64498: ldr     x0, [x22]                                  M:AdsManager::<OnApplicationPause>b__26_0
02d6449c: ldr     x20, [x8, #0x100]                          
02d644a0: bl      #0x2b7104c                                 fn_2b7104c
02d644a4: ldr     x2, [x21]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d644a8: mov     x1, x19                                    
02d644ac: mov     x3, xzr                                    
02d644b0: mov     x21, x0                                    
02d644b4: bl      #0x5b4cf98                                 UnityEngine.Events.UnityAction::.ctor
02d644b8: cbz     x20, #0x2d644d8                            
02d644bc: mov     x0, x20                                    
02d644c0: mov     x1, x21                                    
02d644c4: mov     x2, xzr                                    
02d644c8: ldp     x20, x19, [sp, #0x20]                      
02d644cc: ldp     x22, x21, [sp, #0x10]                      
02d644d0: ldr     x30, [sp], #0x30                           
02d644d4: b       #0x5b4d0ac                                 UnityEngine.Events.UnityEvent::AddListener
02d644d8: bl      #0x2b7105c                                 fn_2b7105c
## SetInteractable(bool isInteractable) -> void
---- Clicker.Printer2DButton::SetInteractable 0x2d644dc
02d644dc: ldr     x0, [x0, #0x20]                            ._startButton
02d644e0: cbz     x0, #0x2d644f0                             
02d644e4: and     w1, w1, #1                                 
02d644e8: mov     x2, xzr                                    
02d644ec: b       #0x5e662d4                                 UnityEngine.UI.Selectable::set_interactable
02d644f0: str     x30, [sp, #-0x10]!                         
02d644f4: bl      #0x2b7105c                                 fn_2b7105c
## .ctor() -> void
---- Clicker.Printer2DButton::.ctor 0x2d644f8
02d644f8: mov     x1, xzr                                    
02d644fc: b       #0x5b397b0                                 UnityEngine.MonoBehaviour::.ctor
## <Init>b__3_0() -> void
---- Clicker.Printer2DButton::<Init>b__3_0 0x2d64500
02d64500: ldr     x0, [x0, #0x30]                            ._printerMachine
02d64504: cbz     x0, #0x2d6450c                             
02d64508: b       #0x2d64514                                 Clicker.PrinterMachine::OnPrinterButtonClick
02d6450c: str     x30, [sp, #-0x10]!                         
02d64510: bl      #0x2b7105c                                 fn_2b7105c
## <Init>b__3_1() -> void
---- Clicker.Printer2DButton::<Init>b__3_1 0x2d646c0
02d646c0: str     x30, [sp, #-0x10]!                         
02d646c4: ldr     x8, [x0, #0x30]                            ._printerMachine
02d646c8: cbz     x8, #0x2d646dc                             
02d646cc: ldr     x0, [x8, #0x28]                            
02d646d0: cbz     x0, #0x2d646dc                             
02d646d4: ldr     x30, [sp], #0x10                           
02d646d8: b       #0x2d64b84                                 Clicker.PrinterRail::SpeedUp
02d646dc: bl      #0x2b7105c                                 fn_2b7105c
