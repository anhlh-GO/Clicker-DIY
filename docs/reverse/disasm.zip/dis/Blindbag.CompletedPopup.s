#### CLASS Blindbag.CompletedPopup/<HandleAfterRewardMoney>d__13 parent= System.ValueType
#   field <>1__state                     int                                                off=0x10 attr=6 
#   field <>t__builder                   System.Runtime.CompilerServices.AsyncVoidMethodBuilder off=0x18 attr=6 
#   field <>u__1                         Cysharp.Threading.Tasks.UniTask/Awaiter            off=0x38 attr=1 
## MoveNext() -> void
---- Blindbag.CompletedPopup/<HandleAfterRewardMoney>d__13::MoveNext 0x2d5720c
02d5720c: sub     sp, sp, #0x60                              
02d57210: stp     x30, x23, [sp, #0x30]                      
02d57214: stp     x22, x21, [sp, #0x40]                      
02d57218: stp     x20, x19, [sp, #0x50]                      
02d5721c: adrp    x20, #0x6630000                            
02d57220: mov     x19, x0                                    
02d57224: ldrb    w8, [x20, #0x292]                          
02d57228: tbnz    w8, #0, #0x2d57270                         
02d5722c: adrp    x0, #0x626b000                             
02d57230: ldr     x0, [x0, #0xa60]                           MS:System.Runtime.CompilerServices.AsyncVoidMethodBuilder::AwaitUnsafeOnCompleted
02d57234: bl      #0x2b70db0                                 fn_2b70db0
02d57238: adrp    x0, #0x6266000                             
02d5723c: ldr     x0, [x0, #0x5e0]                           T:GameConfig
02d57240: bl      #0x2b70db0                                 fn_2b70db0
02d57244: adrp    x0, #0x6266000                             
02d57248: ldr     x0, [x0, #0xac0]                           MS:MonoSingleton`1::get_Instance
02d5724c: bl      #0x2b70db0                                 fn_2b70db0
02d57250: adrp    x0, #0x6265000                             
02d57254: ldr     x0, [x0, #0x10]                            MS:MonoSingleton`1::get_Instance .<>1__state
02d57258: bl      #0x2b70db0                                 fn_2b70db0
02d5725c: adrp    x0, #0x6266000                             
02d57260: ldr     x0, [x0, #0xcc8]                           T:Cysharp.Threading.Tasks.UniTask
02d57264: bl      #0x2b70db0                                 fn_2b70db0
02d57268: mov     w8, #1                                     
02d5726c: strb    w8, [x20, #0x292]                          
02d57270: ldr     w8, [x19]                                  
02d57274: stp     xzr, xzr, [sp, #0x10]                      
02d57278: str     wzr, [sp, #8]                              
02d5727c: cbz     w8, #0x2d57310                             
02d57280: adrp    x22, #0x6266000                            
02d57284: ldr     x22, [x22, #0xcc8]                         T:Cysharp.Threading.Tasks.UniTask
02d57288: ldr     x0, [x22]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d5728c: ldr     w8, [x0, #0xe4]                            [62660e4]=0 f=0,0
02d57290: cbnz    w8, #0x2d57298                             
02d57294: bl      #0x2b70f30                                 fn_2b70f30
02d57298: fmov    s0, #4.00000000                            
02d5729c: mov     w0, wzr                                    
02d572a0: mov     w1, #8                                     
02d572a4: mov     x2, xzr                                    
02d572a8: mov     w3, wzr                                    
02d572ac: mov     x4, xzr                                    
02d572b0: bl      #0x5447b08                                 Cysharp.Threading.Tasks.UniTask::WaitForSeconds
02d572b4: stp     x0, x1, [sp, #0x20]                        
02d572b8: add     x0, sp, #0x20                              
02d572bc: mov     x1, xzr                                    
02d572c0: bl      #0x2b70d54                                 fn_2b70d54
02d572c4: adrp    x23, #0x662f000                            
02d572c8: ldp     x20, x21, [sp, #0x20]                      
02d572cc: ldrb    w8, [x23, #0xbdc]                          
02d572d0: stp     x20, x21, [sp, #0x10]                      
02d572d4: cbnz    w8, #0x2d572ec                             
02d572d8: adrp    x0, #0x6266000                             
02d572dc: ldr     x0, [x0, #0xcc8]                           T:Cysharp.Threading.Tasks.UniTask
02d572e0: bl      #0x2b70db0                                 fn_2b70db0
02d572e4: mov     w8, #1                                     
02d572e8: strb    w8, [x23, #0xbdc]                          
02d572ec: ldr     x0, [x22]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d572f0: ldr     w8, [x0, #0xe4]                            [62660e4]=0 f=0,0
02d572f4: cbnz    w8, #0x2d572fc                             
02d572f8: bl      #0x2b70f30                                 fn_2b70f30
02d572fc: adrp    x22, #0x662f000                            
02d57300: ldrb    w8, [x22, #0xbdd]                          
02d57304: cbz     w8, #0x2d57328                             
02d57308: cbnz    x20, #0x2d57340                            
02d5730c: b       #0x2d573a8                                 
02d57310: ldur    q0, [x19, #0x28]                           
02d57314: mov     w8, #-1                                    
02d57318: stp     xzr, xzr, [x19, #0x28]                     
02d5731c: str     w8, [x19]                                  
02d57320: str     q0, [sp, #0x10]                            
02d57324: b       #0x2d573a8                                 
02d57328: adrp    x0, #0x6266000                             
02d5732c: ldr     x0, [x0, #0xcd0]                           T:Cysharp.Threading.Tasks.IUniTaskSource
02d57330: bl      #0x2b70db0                                 fn_2b70db0
02d57334: mov     w8, #1                                     
02d57338: strb    w8, [x22, #0xbdd]                          
02d5733c: cbz     x20, #0x2d573a8                            
02d57340: adrp    x10, #0x6266000                            
02d57344: ldr     x8, [x20]                                  
02d57348: ldr     x10, [x10, #0xcd0]                         T:Cysharp.Threading.Tasks.IUniTaskSource
02d5734c: ldrh    w9, [x8, #0x12e]                           
02d57350: ldr     x1, [x10]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d57354: cbz     x9, #0x2d57378                             
02d57358: ldr     x10, [x8, #0xb0]                           
02d5735c: add     x10, x10, #8                               &6266008
02d57360: ldur    x11, [x10, #-8]                            
02d57364: cmp     x11, x1                                    
02d57368: b.eq    #0x2d57388                                 
02d5736c: subs    x9, x9, #1                                 
02d57370: add     x10, x10, #0x10                            &6266010
02d57374: b.ne    #0x2d57360                                 
02d57378: mov     x0, x20                                    
02d5737c: mov     w2, wzr                                    
02d57380: bl      #0x2baa05c                                 fn_2baa05c
02d57384: b       #0x2d57394                                 
02d57388: ldrsw   x9, [x10]                                  
02d5738c: add     x8, x8, x9, lsl #4                         
02d57390: add     x0, x8, #0x138                             
02d57394: ldp     x8, x2, [x0]                               
02d57398: mov     x0, x20                                    
02d5739c: mov     w1, w21                                    
02d573a0: blr     x8                                         
02d573a4: cbz     w0, #0x2d574d0                             
02d573a8: adrp    x20, #0x662f000                            
02d573ac: ldrb    w8, [x20, #0xbde]                          
02d573b0: cbnz    w8, #0x2d573c8                             
02d573b4: adrp    x0, #0x6266000                             
02d573b8: ldr     x0, [x0, #0xcd0]                           T:Cysharp.Threading.Tasks.IUniTaskSource
02d573bc: bl      #0x2b70db0                                 fn_2b70db0
02d573c0: mov     w8, #1                                     
02d573c4: strb    w8, [x20, #0xbde]                          
02d573c8: ldr     x20, [sp, #0x10]                           
02d573cc: cbz     x20, #0x2d5743c                            
02d573d0: adrp    x10, #0x6266000                            
02d573d4: ldr     x8, [x20]                                  &2b706c4(=eb01011ff9400808)
02d573d8: ldr     x10, [x10, #0xcd0]                         T:Cysharp.Threading.Tasks.IUniTaskSource
02d573dc: ldrh    w21, [sp, #0x18]                           
02d573e0: ldrh    w9, [x8, #0x12e]                           
02d573e4: ldr     x1, [x10]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d573e8: cbz     x9, #0x2d5740c                             
02d573ec: ldr     x10, [x8, #0xb0]                           
02d573f0: add     x10, x10, #8                               &6266008
02d573f4: ldur    x11, [x10, #-8]                            
02d573f8: cmp     x11, x1                                    
02d573fc: b.eq    #0x2d5741c                                 
02d57400: subs    x9, x9, #1                                 
02d57404: add     x10, x10, #0x10                            &6266010
02d57408: b.ne    #0x2d573f4                                 
02d5740c: mov     x0, x20                                    
02d57410: mov     w2, #2                                     
02d57414: bl      #0x2baa05c                                 fn_2baa05c
02d57418: b       #0x2d5742c                                 
02d5741c: ldr     w9, [x10]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d57420: add     w9, w9, #2                                 
02d57424: add     x8, x8, w9, sxtw #4                        
02d57428: add     x0, x8, #0x138                             
02d5742c: ldp     x8, x2, [x0]                               
02d57430: mov     x0, x20                                    
02d57434: mov     w1, w21                                    
02d57438: blr     x8                                         
02d5743c: adrp    x8, #0x6266000                             
02d57440: ldr     x8, [x8, #0xac0]                           MS:MonoSingleton`1::get_Instance
02d57444: ldr     x0, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d57448: bl      #0x3769600                                 fn_3769600
02d5744c: cbz     x0, #0x2d57508                             
02d57450: adrp    x8, #0x6265000                             
02d57454: mov     w9, #1                                     
02d57458: ldr     x8, [x8, #0x10]                            MS:MonoSingleton`1::get_Instance
02d5745c: strb    w9, [x0, #0x40]                            
02d57460: ldr     x8, [x8]                                   M:AdsManager::<OnApplicationPause>b__26_0
02d57464: mov     x0, x8                                     
02d57468: bl      #0x3769600                                 fn_3769600
02d5746c: adrp    x21, #0x6266000                            
02d57470: mov     x20, x0                                    
02d57474: ldr     x21, [x21, #0x5e0]                         T:GameConfig
02d57478: ldr     x0, [x21]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d5747c: ldr     w8, [x0, #0xe4]                            [62660e4]=0 f=0,0
02d57480: cbnz    w8, #0x2d57488                             
02d57484: bl      #0x2b70f30                                 fn_2b70f30
02d57488: cbz     x20, #0x2d5750c                            
02d5748c: ldr     x8, [x21]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d57490: ldr     x8, [x8, #0xb8]                            T:AdsManager/<>c__DisplayClass42_0
02d57494: ldr     x1, [x8, #8]                               M:AdsManager::<OnApplicationPause>b__26_1
02d57498: mov     x0, x20                                    
02d5749c: mov     w2, #1                                     
02d574a0: mov     x3, xzr                                    
02d574a4: bl      #0x2ce9e58                                 SimpleSceneTransition::FlashIn
02d574a8: mov     w8, #-2                                    
02d574ac: mov     x1, xzr                                    
02d574b0: str     w8, [x19], #8                              
02d574b4: mov     x0, x19                                    
02d574b8: bl      #0x4d43b50                                 System.Runtime.CompilerServices.AsyncVoidMethodBuilder::SetResult
02d574bc: ldp     x20, x19, [sp, #0x50]                      
02d574c0: ldp     x22, x21, [sp, #0x40]                      
02d574c4: ldp     x30, x23, [sp, #0x30]                      
02d574c8: add     sp, sp, #0x60                              
02d574cc: ret                                                
02d574d0: ldr     q0, [sp, #0x10]                            
02d574d4: str     wzr, [x19]                                 
02d574d8: stur    q0, [x19, #0x28]                           
02d574dc: add     x0, x19, #0x28                             
02d574e0: mov     x1, xzr                                    
02d574e4: bl      #0x2b70d54                                 fn_2b70d54
02d574e8: adrp    x8, #0x626b000                             
02d574ec: ldr     x8, [x8, #0xa60]                           MS:System.Runtime.CompilerServices.AsyncVoidMethodBuilder::AwaitUnsafeOnCompleted
02d574f0: ldr     x3, [x8]                                   T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d574f4: add     x0, x19, #8                                
02d574f8: add     x1, sp, #0x10                              
02d574fc: mov     x2, x19                                    
02d57500: bl      #0x30c3208                                 fn_30c3208
02d57504: b       #0x2d574bc                                 
02d57508: bl      #0x2b7105c                                 fn_2b7105c
02d5750c: bl      #0x2b7105c                                 fn_2b7105c
02d57510: b       #0x2d57534                                 
02d57514: b       #0x2d57534                                 
02d57518: b       #0x2d57534                                 
02d5751c: b       #0x2d57534                                 
02d57520: b       #0x2d57534                                 
02d57524: b       #0x2d57534                                 
02d57528: b       #0x2d57534                                 
02d5752c: b       #0x2d57534                                 
02d57530: b       #0x2d57534                                 
02d57534: mov     x20, x0                                    
02d57538: cmp     w1, #1                                     
02d5753c: b.ne    #0x2d575cc                                 
02d57540: mov     x0, x20                                    
02d57544: bl      #0x5e90260                                 fn_5e90260
02d57548: mov     x20, x0                                    
02d5754c: adrp    x0, #0x6263000                             
02d57550: ldr     x0, [x0, #0xae0]                           T:System.Exception
02d57554: bl      #0x2b70dc4                                 fn_2b70dc4
02d57558: ldr     x8, [x20]                                  &2b706c4(=eb01011ff9400808)
02d5755c: ldr     x1, [x8]                                   T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d57560: bl      #0x2b71464                                 fn_2b71464
02d57564: tbz     w0, #0, #0x2d575a4                         
02d57568: ldrsw   x21, [sp, #8]                              
02d5756c: ldr     x20, [x20]                                 &2b706c4(=eb01011ff9400808)
02d57570: mov     x8, sp                                     
02d57574: str     x20, [x8, x21, lsl #3]                     
02d57578: add     w8, w21, #1                                
02d5757c: str     w8, [sp, #8]                               
02d57580: bl      #0x5e90270                                 fn_5e90270
02d57584: mov     w8, #-2                                    
02d57588: mov     x1, x20                                    
02d5758c: mov     x2, xzr                                    
02d57590: str     w8, [x19], #8                              
02d57594: mov     x0, x19                                    
02d57598: bl      #0x4d43cc0                                 System.Runtime.CompilerServices.AsyncVoidMethodBuilder::SetException
02d5759c: str     w21, [sp, #8]                              
02d575a0: b       #0x2d574bc                                 
02d575a4: mov     w0, #8                                     
02d575a8: bl      #0x5e90290                                 fn_5e90290
02d575ac: ldr     x8, [x20]                                  &2b706c4(=eb01011ff9400808)
02d575b0: str     x8, [x0]                                   
02d575b4: adrp    x1, #0x5e96000                             
02d575b8: add     x1, x1, #0x758                             &5e96758
02d575bc: mov     x2, xzr                                    
02d575c0: bl      #0x5e902a0                                 fn_5e902a0
02d575c4: mov     x20, x0                                    
02d575c8: bl      #0x5e90270                                 fn_5e90270
02d575cc: mov     x0, x20                                    
02d575d0: bl      #0x2c6051c                                 fn_2c6051c
02d575d4: bl      #0x27369b8                                 fn_27369b8
## SetStateMachine(System.Runtime.CompilerServices.IAsyncStateMachine stateMachine) -> void
---- Blindbag.CompletedPopup/<HandleAfterRewardMoney>d__13::SetStateMachine 0x2d575d8
02d575d8: add     x0, x0, #8                                 
02d575dc: mov     x2, xzr                                    
02d575e0: b       #0x4d43a8c                                 System.Runtime.CompilerServices.AsyncVoidMethodBuilder::SetStateMachine
#### CLASS Blindbag.CompletedPopup parent= PopupBase
#   field _adsButton                     UnityEngine.UI.Button                              off=0x38 attr=1 SerializeField
#   field _rewardButton                  UnityEngine.UI.Button                              off=0x40 attr=1 SerializeField
#   field _adsMoneyText                  TMPro.TextMeshProUGUI                              off=0x48 attr=1 SerializeField
#   field _incomeMoneyText               TMPro.TextMeshProUGUI                              off=0x50 attr=1 SerializeField
#   field _tipMoneyText                  TMPro.TextMeshProUGUI                              off=0x58 attr=1 SerializeField
#   field _rewardImage                   UnityEngine.UI.RawImage                            off=0x60 attr=1 SerializeField
#   field _moneyPanel                    UnityEngine.RectTransform                          off=0x68 attr=1 SerializeField
#   field _income                        int                                                off=0x70 attr=1 
#   field _tip                           int                                                off=0x74 attr=1 
## OnInit(UIManager uiManager) -> void
---- Blindbag.CompletedPopup::OnInit 0x2d56ad0
02d56ad0: str     x30, [sp, #-0x30]!                         
02d56ad4: stp     x22, x21, [sp, #0x10]                      
02d56ad8: stp     x20, x19, [sp, #0x20]                      
02d56adc: adrp    x21, #0x6630000                            
02d56ae0: mov     x20, x1                                    
02d56ae4: mov     x19, x0                                    
02d56ae8: ldrb    w8, [x21, #0x28a]                          
02d56aec: tbnz    w8, #0, #0x2d56b1c                         
02d56af0: adrp    x0, #0x626b000                             
02d56af4: ldr     x0, [x0, #0xa48]                           M:Blindbag.CompletedPopup::OnAdsButtonClicked
02d56af8: bl      #0x2b70db0                                 fn_2b70db0
02d56afc: adrp    x0, #0x626b000                             
02d56b00: ldr     x0, [x0, #0xa50]                           M:Blindbag.CompletedPopup::OnRewardButtonClicked
02d56b04: bl      #0x2b70db0                                 fn_2b70db0
02d56b08: adrp    x0, #0x6265000                             
02d56b0c: ldr     x0, [x0, #0x3f0]                           T:UnityEngine.Events.UnityAction
02d56b10: bl      #0x2b70db0                                 fn_2b70db0
02d56b14: mov     w8, #1                                     
02d56b18: strb    w8, [x21, #0x28a]                          
02d56b1c: mov     x0, x19                                    
02d56b20: mov     x1, x20                                    
02d56b24: mov     x2, xzr                                    
02d56b28: bl      #0x2cdd3c4                                 UIBase::OnInit
02d56b2c: ldr     x8, [x19, #0x38]                           ._adsButton
02d56b30: cbz     x8, #0x2d56bc8                             
02d56b34: adrp    x22, #0x6265000                            
02d56b38: adrp    x21, #0x626b000                            
02d56b3c: ldr     x22, [x22, #0x3f0]                         T:UnityEngine.Events.UnityAction
02d56b40: ldr     x21, [x21, #0xa48]                         M:Blindbag.CompletedPopup::OnAdsButtonClicked
02d56b44: ldr     x20, [x8, #0x100]                          
02d56b48: ldr     x0, [x22]                                  M:AdsManager::<OnApplicationPause>b__26_0
02d56b4c: bl      #0x2b7104c                                 fn_2b7104c
02d56b50: ldr     x2, [x21]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d56b54: mov     x1, x19                                    
02d56b58: mov     x3, xzr                                    
02d56b5c: mov     x21, x0                                    
02d56b60: bl      #0x5b4cf98                                 UnityEngine.Events.UnityAction::.ctor
02d56b64: cbz     x20, #0x2d56bc8                            
02d56b68: mov     x0, x20                                    
02d56b6c: mov     x1, x21                                    
02d56b70: mov     x2, xzr                                    
02d56b74: bl      #0x5b4d0ac                                 UnityEngine.Events.UnityEvent::AddListener
02d56b78: ldr     x8, [x19, #0x40]                           ._rewardButton
02d56b7c: cbz     x8, #0x2d56bc8                             
02d56b80: adrp    x21, #0x626b000                            
02d56b84: ldr     x21, [x21, #0xa50]                         M:Blindbag.CompletedPopup::OnRewardButtonClicked
02d56b88: ldr     x0, [x22]                                  M:AdsManager::<OnApplicationPause>b__26_0
02d56b8c: ldr     x20, [x8, #0x100]                          
02d56b90: bl      #0x2b7104c                                 fn_2b7104c
02d56b94: ldr     x2, [x21]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d56b98: mov     x1, x19                                    
02d56b9c: mov     x3, xzr                                    
02d56ba0: mov     x21, x0                                    
02d56ba4: bl      #0x5b4cf98                                 UnityEngine.Events.UnityAction::.ctor
02d56ba8: cbz     x20, #0x2d56bc8                            
02d56bac: mov     x0, x20                                    
02d56bb0: mov     x1, x21                                    
02d56bb4: mov     x2, xzr                                    
02d56bb8: ldp     x20, x19, [sp, #0x20]                      
02d56bbc: ldp     x22, x21, [sp, #0x10]                      
02d56bc0: ldr     x30, [sp], #0x30                           
02d56bc4: b       #0x5b4d0ac                                 UnityEngine.Events.UnityEvent::AddListener
02d56bc8: bl      #0x2b7105c                                 fn_2b7105c
## SetMoneyResult(int income, int tip) -> void
---- Blindbag.CompletedPopup::SetMoneyResult 0x2d56bcc
02d56bcc: stp     x30, x21, [sp, #-0x20]!                    
02d56bd0: stp     x20, x19, [sp, #0x10]                      
02d56bd4: mov     x19, x0                                    
02d56bd8: str     w1, [x0, #0x70]!                           ._income
02d56bdc: mov     x20, x0                                    
02d56be0: ldur    x21, [x0, #-0x20]                          
02d56be4: mov     x1, xzr                                    
02d56be8: str     w2, [x20, #4]!                             
02d56bec: bl      #0x4e0ea3c                                 System.Int32::ToString
02d56bf0: cbz     x21, #0x2d56c40                            
02d56bf4: ldr     x8, [x21]                                  
02d56bf8: mov     x1, x0                                     
02d56bfc: mov     x0, x21                                    
02d56c00: ldr     x9, [x8, #0x558]                           
02d56c04: ldr     x2, [x8, #0x560]                           
02d56c08: blr     x9                                         
02d56c0c: ldr     x19, [x19, #0x58]                          ._tipMoneyText
02d56c10: mov     x0, x20                                    
02d56c14: mov     x1, xzr                                    
02d56c18: bl      #0x4e0ea3c                                 System.Int32::ToString
02d56c1c: cbz     x19, #0x2d56c40                            
02d56c20: ldr     x8, [x19]                                  
02d56c24: mov     x1, x0                                     
02d56c28: mov     x0, x19                                    
02d56c2c: ldp     x20, x19, [sp, #0x10]                      
02d56c30: ldr     x2, [x8, #0x560]                           
02d56c34: ldr     x3, [x8, #0x558]                           
02d56c38: ldp     x30, x21, [sp], #0x20                      
02d56c3c: br      x3                                         
02d56c40: bl      #0x2b7105c                                 fn_2b7105c
## OnShow() -> void
---- Blindbag.CompletedPopup::OnShow 0x2d56c44
02d56c44: str     x30, [sp, #-0x20]!                         
02d56c48: stp     x20, x19, [sp, #0x10]                      
02d56c4c: adrp    x20, #0x6630000                            
02d56c50: mov     x19, x0                                    
02d56c54: ldrb    w8, [x20, #0x28b]                          
02d56c58: tbnz    w8, #0, #0x2d56c70                         
02d56c5c: adrp    x0, #0x6266000                             
02d56c60: ldr     x0, [x0, #0xaa0]                           MS:MonoSingleton`1::get_Instance
02d56c64: bl      #0x2b70db0                                 fn_2b70db0
02d56c68: mov     w8, #1                                     
02d56c6c: strb    w8, [x20, #0x28b]                          
02d56c70: mov     x0, x19                                    
02d56c74: mov     x1, xzr                                    
02d56c78: bl      #0x2cdd6b8                                 UIBase::OnShow
02d56c7c: mov     x0, xzr                                    
02d56c80: bl      #0x2d6eec8                                 Framework.AudioManager::get_Instance
02d56c84: cbz     x0, #0x2d56ce0                             
02d56c88: movi    d1, #0000000000000000                      
02d56c8c: movi    d2, #0000000000000000                      
02d56c90: adrp    x20, #0x6266000                            
02d56c94: fmov    s0, #1.00000000                            
02d56c98: ldr     x20, [x20, #0xaa0]                         MS:MonoSingleton`1::get_Instance
02d56c9c: mov     w1, #9                                     
02d56ca0: mov     w2, wzr                                    
02d56ca4: mov     w3, wzr                                    
02d56ca8: mov     x4, xzr                                    
02d56cac: bl      #0x2d6f03c                                 Framework.AudioManager::PlaySound
02d56cb0: mov     x0, x19                                    
02d56cb4: mov     w1, #1                                     
02d56cb8: bl      #0x2d56ce4                                 Blindbag.CompletedPopup::SetInteractButtons
02d56cbc: mov     x0, x19                                    
02d56cc0: bl      #0x2d56d28                                 Blindbag.CompletedPopup::StartAdsButtonAnim
02d56cc4: ldr     x0, [x20]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d56cc8: bl      #0x3769600                                 fn_3769600
02d56ccc: cbz     x0, #0x2d56ce0                             
02d56cd0: ldp     x20, x19, [sp, #0x10]                      
02d56cd4: mov     x1, xzr                                    
02d56cd8: ldr     x30, [sp], #0x20                           
02d56cdc: b       #0x2cdb26c                                 MoneyManager::ShowUp
02d56ce0: bl      #0x2b7105c                                 fn_2b7105c
## OnRewardMoney(int money, bool showInter) -> void
---- Blindbag.CompletedPopup::OnRewardMoney 0x2d56e68
02d56e68: str     x30, [sp, #-0x30]!                         
02d56e6c: stp     x22, x21, [sp, #0x10]                      
02d56e70: stp     x20, x19, [sp, #0x20]                      
02d56e74: adrp    x22, #0x6630000                            
02d56e78: adrp    x21, #0x6266000                            
02d56e7c: mov     w19, w1                                    
02d56e80: ldrb    w8, [x22, #0x28c]                          
02d56e84: ldr     x21, [x21, #0xaa0]                         MS:MonoSingleton`1::get_Instance
02d56e88: mov     x20, x0                                    
02d56e8c: tbnz    w8, #0, #0x2d56ea4                         
02d56e90: adrp    x0, #0x6266000                             
02d56e94: ldr     x0, [x0, #0xaa0]                           MS:MonoSingleton`1::get_Instance
02d56e98: bl      #0x2b70db0                                 fn_2b70db0
02d56e9c: mov     w8, #1                                     
02d56ea0: strb    w8, [x22, #0x28c]                          
02d56ea4: mov     x0, x20                                    
02d56ea8: bl      #0x2d56ee4                                 Blindbag.CompletedPopup::StopAdsButtonAnim
02d56eac: ldr     x0, [x21]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d56eb0: bl      #0x3769600                                 fn_3769600
02d56eb4: cbz     x0, #0x2d56ee0                             
02d56eb8: mov     w1, w19                                    
02d56ebc: mov     w2, #0xa                                   
02d56ec0: mov     x3, xzr                                    
02d56ec4: mov     x4, xzr                                    
02d56ec8: bl      #0x2cdaf30                                 MoneyManager::CollectMoney
02d56ecc: ldp     x20, x19, [sp, #0x20]                      
02d56ed0: mov     w1, wzr                                    
02d56ed4: ldp     x22, x21, [sp, #0x10]                      
02d56ed8: ldr     x30, [sp], #0x30                           
02d56edc: b       #0x2d56ff8                                 Blindbag.CompletedPopup::HandleAfterRewardMoney
02d56ee0: bl      #0x2b7105c                                 fn_2b7105c
## HandleAfterRewardMoney(bool showInter) -> void
---- Blindbag.CompletedPopup::HandleAfterRewardMoney 0x2d56ff8
02d56ff8: sub     sp, sp, #0x80                              
02d56ffc: str     x30, [sp, #0x60]                           
02d57000: stp     x20, x19, [sp, #0x70]                      
02d57004: adrp    x20, #0x6630000                            
02d57008: adrp    x19, #0x626b000                            
02d5700c: ldrb    w8, [x20, #0x28d]                          
02d57010: b       #0x5e8fd64                                 
02d57014: tbnz    w8, #0, #0x2d5702c                         
02d57018: adrp    x0, #0x626b000                             
02d5701c: ldr     x0, [x0, #0xa58]                           MS:System.Runtime.CompilerServices.AsyncVoidMethodBuilder::Start
02d57020: bl      #0x2b70db0                                 fn_2b70db0
02d57024: mov     w8, #1                                     
02d57028: strb    w8, [x20, #0x28d]                          
02d5702c: movi    v0.2d, #0000000000000000                   
02d57030: mov     x8, sp                                     
02d57034: mov     x0, xzr                                    
02d57038: str     xzr, [sp, #0x50]                           
02d5703c: stp     q0, q0, [sp, #0x30]                        
02d57040: str     q0, [sp, #0x20]                            
02d57044: bl      #0x4d43a24                                 System.Runtime.CompilerServices.AsyncVoidMethodBuilder::Create
02d57048: ldp     q0, q1, [sp]                               
02d5704c: add     x20, sp, #0x20                             
02d57050: orr     x0, x20, #8                                
02d57054: mov     x1, xzr                                    
02d57058: stur    q0, [sp, #0x28]                            
02d5705c: stur    q1, [sp, #0x38]                            
02d57060: bl      #0x2b70d54                                 fn_2b70d54
02d57064: ldr     x2, [x19]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d57068: mov     w8, #-1                                    
02d5706c: orr     x0, x20, #8                                
02d57070: add     x1, sp, #0x20                              
02d57074: str     w8, [sp, #0x20]                            
02d57078: bl      #0x30c6894                                 fn_30c6894
02d5707c: ldp     x20, x19, [sp, #0x70]                      
02d57080: ldr     x30, [sp, #0x60]                           
02d57084: add     sp, sp, #0x80                              
02d57088: ret                                                
## SetInteractButtons(bool isInteract) -> void
---- Blindbag.CompletedPopup::SetInteractButtons 0x2d56ce4
02d56ce4: str     x30, [sp, #-0x20]!                         
02d56ce8: stp     x20, x19, [sp, #0x10]                      
02d56cec: mov     x20, x0                                    
02d56cf0: ldr     x0, [x0, #0x38]                            ._adsButton
02d56cf4: cbz     x0, #0x2d56d24                             
02d56cf8: mov     w19, w1                                    
02d56cfc: and     w1, w1, #1                                 
02d56d00: mov     x2, xzr                                    
02d56d04: bl      #0x5e662d4                                 UnityEngine.UI.Selectable::set_interactable
02d56d08: ldr     x0, [x20, #0x40]                           ._rewardButton
02d56d0c: cbz     x0, #0x2d56d24                             
02d56d10: and     w1, w19, #1                                
02d56d14: ldp     x20, x19, [sp, #0x10]                      
02d56d18: mov     x2, xzr                                    
02d56d1c: ldr     x30, [sp], #0x20                           
02d56d20: b       #0x5e662d4                                 UnityEngine.UI.Selectable::set_interactable
02d56d24: bl      #0x2b7105c                                 fn_2b7105c
## StartAdsButtonAnim() -> void
---- Blindbag.CompletedPopup::StartAdsButtonAnim 0x2d56d28
02d56d28: str     x30, [sp, #-0x30]!                         
02d56d2c: stp     x22, x21, [sp, #0x10]                      
02d56d30: stp     x20, x19, [sp, #0x20]                      
02d56d34: adrp    x20, #0x6630000                            
02d56d38: mov     x19, x0                                    
02d56d3c: ldrb    w8, [x20, #0x28e]                          
02d56d40: tbnz    w8, #0, #0x2d56d58                         
02d56d44: adrp    x0, #0x6268000                             
02d56d48: ldr     x0, [x0, #0x10]                            MS:DG.Tweening.TweenSettingsExtensions::SetLoops
02d56d4c: bl      #0x2b70db0                                 fn_2b70db0
02d56d50: mov     w8, #1                                     
02d56d54: strb    w8, [x20, #0x28e]                          
02d56d58: ldr     x0, [x19, #0x38]                           ._adsButton
02d56d5c: cbz     x0, #0x2d56e64                             
02d56d60: mov     x1, xzr                                    
02d56d64: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02d56d68: mov     w1, wzr                                    
02d56d6c: mov     x2, xzr                                    
02d56d70: bl      #0x2d9d5d0                                 DG.Tweening.ShortcutExtensions::DOKill
02d56d74: ldr     x0, [x19, #0x38]                           ._adsButton
02d56d78: cbz     x0, #0x2d56e64                             
02d56d7c: mov     x1, xzr                                    
02d56d80: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02d56d84: adrp    x21, #0x662f000                            
02d56d88: mov     x20, x0                                    
02d56d8c: ldrb    w8, [x21, #0xa74]                          
02d56d90: cbnz    w8, #0x2d56da8                             
02d56d94: adrp    x0, #0x6264000                             
02d56d98: ldr     x0, [x0, #0xd8]                            T:UnityEngine.Vector3
02d56d9c: bl      #0x2b70db0                                 fn_2b70db0
02d56da0: mov     w8, #1                                     
02d56da4: strb    w8, [x21, #0xa74]                          
02d56da8: cbz     x20, #0x2d56e64                            
02d56dac: adrp    x22, #0x6264000                            
02d56db0: mov     x0, x20                                    
02d56db4: mov     x1, xzr                                    
02d56db8: ldr     x22, [x22, #0xd8]                          T:UnityEngine.Vector3
02d56dbc: ldr     x8, [x22]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d56dc0: ldr     x8, [x8, #0xb8]                            
02d56dc4: ldp     s1, s2, [x8, #0x10]                        
02d56dc8: ldr     s0, [x8, #0xc]                             
02d56dcc: bl      #0x5b470cc                                 UnityEngine.Transform::set_localScale
02d56dd0: ldr     x0, [x19, #0x38]                           ._adsButton
02d56dd4: cbz     x0, #0x2d56e64                             
02d56dd8: adrp    x20, #0x6268000                            
02d56ddc: mov     x1, xzr                                    
02d56de0: ldr     x20, [x20, #0x10]                          MS:DG.Tweening.TweenSettingsExtensions::SetLoops
02d56de4: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02d56de8: ldrb    w8, [x21, #0xa74]                          
02d56dec: mov     x19, x0                                    
02d56df0: cbnz    w8, #0x2d56e08                             
02d56df4: adrp    x0, #0x6264000                             
02d56df8: ldr     x0, [x0, #0xd8]                            T:UnityEngine.Vector3
02d56dfc: bl      #0x2b70db0                                 fn_2b70db0
02d56e00: mov     w8, #1                                     
02d56e04: strb    w8, [x21, #0xa74]                          
02d56e08: ldr     x8, [x22]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d56e0c: mov     w9, #0xcccd                                
02d56e10: fmov    s3, #0.50000000                            
02d56e14: movk    w9, #0x3f8c, lsl #16                       
02d56e18: mov     x0, x19                                    
02d56e1c: mov     x1, xzr                                    
02d56e20: ldr     x8, [x8, #0xb8]                            
02d56e24: dup     v0.2s, w9                                  
02d56e28: adrp    x9, #0x1084000                             
02d56e2c: ldr     s2, [x9, #0xcfc]                           [1084cfc]=3e58658c3f8ccccd f=1.1,0.211325
02d56e30: ldur    d1, [x8, #0xc]                             
02d56e34: fmul    v0.2s, v1.2s, v0.2s                        
02d56e38: ldr     s1, [x8, #0x14]                            
02d56e3c: fmul    s2, s1, s2                                 
02d56e40: mov     s1, v0.s[1]                                
02d56e44: bl      #0x2d98af8                                 DG.Tweening.ShortcutExtensions::DOScale
02d56e48: ldr     x3, [x20]                                  S:'{0}/2'
02d56e4c: ldp     x20, x19, [sp, #0x20]                      
02d56e50: ldp     x22, x21, [sp, #0x10]                      
02d56e54: mov     w1, #-1                                    
02d56e58: mov     w2, #1                                     
02d56e5c: ldr     x30, [sp], #0x30                           
02d56e60: b       #0x336fe74                                 
02d56e64: bl      #0x2b7105c                                 fn_2b7105c
## StopAdsButtonAnim() -> void
---- Blindbag.CompletedPopup::StopAdsButtonAnim 0x2d56ee4
02d56ee4: stp     x30, x21, [sp, #-0x20]!                    
02d56ee8: stp     x20, x19, [sp, #0x10]                      
02d56eec: adrp    x20, #0x6630000                            
02d56ef0: adrp    x21, #0x6263000                            
02d56ef4: mov     x19, x0                                    
02d56ef8: ldrb    w8, [x20, #0x28f]                          
02d56efc: ldr     x21, [x21, #0x918]                         T:UnityEngine.Object
02d56f00: tbnz    w8, #0, #0x2d56f18                         
02d56f04: adrp    x0, #0x6263000                             
02d56f08: ldr     x0, [x0, #0x918]                           T:UnityEngine.Object
02d56f0c: bl      #0x2b70db0                                 fn_2b70db0
02d56f10: mov     w8, #1                                     
02d56f14: strb    w8, [x20, #0x28f]                          
02d56f18: ldr     x0, [x21]                                  &2c5bbd4(=a9bd7bfdd503233f)
02d56f1c: ldr     x20, [x19, #0x38]                          ._adsButton
02d56f20: ldr     w8, [x0, #0xe4]                            [62630e4]=0 f=0,0
02d56f24: cbnz    w8, #0x2d56f2c                             
02d56f28: bl      #0x2b70f30                                 fn_2b70f30
02d56f2c: mov     x0, x20                                    
02d56f30: mov     x1, xzr                                    
02d56f34: mov     x2, xzr                                    
02d56f38: bl      #0x5b3666c                                 UnityEngine.Object::op_Inequality
02d56f3c: tbz     w0, #0, #0x2d56f5c                         
02d56f40: ldr     x0, [x19, #0x38]                           ._adsButton
02d56f44: cbz     x0, #0x2d56ff4                             
02d56f48: mov     x1, xzr                                    
02d56f4c: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02d56f50: mov     w1, wzr                                    
02d56f54: mov     x2, xzr                                    
02d56f58: bl      #0x2d9d5d0                                 DG.Tweening.ShortcutExtensions::DOKill
02d56f5c: ldr     x0, [x21]                                  &2c5bbd4(=a9bd7bfdd503233f)
02d56f60: ldr     x20, [x19, #0x38]                          ._adsButton
02d56f64: ldr     w8, [x0, #0xe4]                            [62630e4]=0 f=0,0
02d56f68: cbnz    w8, #0x2d56f70                             
02d56f6c: bl      #0x2b70f30                                 fn_2b70f30
02d56f70: mov     x0, x20                                    
02d56f74: mov     x1, xzr                                    
02d56f78: mov     x2, xzr                                    
02d56f7c: bl      #0x5b3666c                                 UnityEngine.Object::op_Inequality
02d56f80: tbz     w0, #0, #0x2d56fe8                         
02d56f84: ldr     x0, [x19, #0x38]                           ._adsButton
02d56f88: cbz     x0, #0x2d56ff4                             
02d56f8c: mov     x1, xzr                                    
02d56f90: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02d56f94: adrp    x20, #0x662f000                            
02d56f98: mov     x19, x0                                    
02d56f9c: ldrb    w8, [x20, #0xa74]                          
02d56fa0: cbnz    w8, #0x2d56fb8                             
02d56fa4: adrp    x0, #0x6264000                             
02d56fa8: ldr     x0, [x0, #0xd8]                            T:UnityEngine.Vector3
02d56fac: bl      #0x2b70db0                                 fn_2b70db0
02d56fb0: mov     w8, #1                                     
02d56fb4: strb    w8, [x20, #0xa74]                          
02d56fb8: cbz     x19, #0x2d56ff4                            
02d56fbc: adrp    x8, #0x6264000                             
02d56fc0: mov     x0, x19                                    
02d56fc4: mov     x1, xzr                                    
02d56fc8: ldr     x8, [x8, #0xd8]                            T:UnityEngine.Vector3
02d56fcc: ldp     x20, x19, [sp, #0x10]                      
02d56fd0: ldr     x8, [x8]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d56fd4: ldr     x8, [x8, #0xb8]                            MS:DG.Tweening.Core.Extensions::SetSpecialStartupMode
02d56fd8: ldp     s0, s1, [x8, #0xc]                         
02d56fdc: ldr     s2, [x8, #0x14]                            [6264014]=0 f=0,0
02d56fe0: ldp     x30, x21, [sp], #0x20                      
02d56fe4: b       #0x5b470cc                                 UnityEngine.Transform::set_localScale
02d56fe8: ldp     x20, x19, [sp, #0x10]                      
02d56fec: ldp     x30, x21, [sp], #0x20                      
02d56ff0: ret                                                
02d56ff4: bl      #0x2b7105c                                 fn_2b7105c
## OnDestroy() -> void
---- Blindbag.CompletedPopup::OnDestroy 0x2d5708c
02d5708c: str     x30, [sp, #-0x10]!                         
02d57090: ldr     x0, [x0, #0x38]                            ._adsButton
02d57094: cbz     x0, #0x2d570b0                             
02d57098: mov     x1, xzr                                    
02d5709c: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02d570a0: mov     w1, wzr                                    
02d570a4: mov     x2, xzr                                    
02d570a8: ldr     x30, [sp], #0x10                           
02d570ac: b       #0x2d9d5d0                                 DG.Tweening.ShortcutExtensions::DOKill
02d570b0: bl      #0x2b7105c                                 fn_2b7105c
## OnAdsButtonClicked() -> void
---- Blindbag.CompletedPopup::OnAdsButtonClicked 0x2d570b4
02d570b4: str     x30, [sp, #-0x20]!                         
02d570b8: stp     x20, x19, [sp, #0x10]                      
02d570bc: adrp    x20, #0x6630000                            
02d570c0: mov     x19, x0                                    
02d570c4: ldrb    w8, [x20, #0x290]                          
02d570c8: tbnz    w8, #0, #0x2d570e0                         
02d570cc: adrp    x0, #0x6267000                             
02d570d0: ldr     x0, [x0, #0xd50]                           MS:MonoSingleton`1::get_Instance
02d570d4: bl      #0x2b70db0                                 fn_2b70db0
02d570d8: mov     w8, #1                                     
02d570dc: strb    w8, [x20, #0x290]                          
02d570e0: mov     x0, xzr                                    
02d570e4: bl      #0x2d6eec8                                 Framework.AudioManager::get_Instance
02d570e8: cbz     x0, #0x2d57154                             
02d570ec: movi    d1, #0000000000000000                      
02d570f0: movi    d2, #0000000000000000                      
02d570f4: adrp    x20, #0x6267000                            
02d570f8: fmov    s0, #1.00000000                            
02d570fc: ldr     x20, [x20, #0xd50]                         MS:MonoSingleton`1::get_Instance
02d57100: mov     w1, #1                                     
02d57104: mov     w2, wzr                                    
02d57108: mov     w3, wzr                                    
02d5710c: mov     x4, xzr                                    
02d57110: bl      #0x2d6f03c                                 Framework.AudioManager::PlaySound
02d57114: ldr     x0, [x20]                                  S:'didu'
02d57118: bl      #0x3769600                                 fn_3769600
02d5711c: cbz     x0, #0x2d57154                             
02d57120: mov     w1, #4                                     
02d57124: mov     x2, xzr                                    
02d57128: bl      #0x2cc6ee0                                 Framework.VibrationManager::Haptic
02d5712c: mov     x0, x19                                    
02d57130: mov     w1, wzr                                    
02d57134: bl      #0x2d56ce4                                 Blindbag.CompletedPopup::SetInteractButtons
02d57138: ldp     w8, w9, [x19, #0x70]                       ._income
02d5713c: mov     x0, x19                                    
02d57140: ldp     x20, x19, [sp, #0x10]                      
02d57144: mov     w2, wzr                                    
02d57148: add     w1, w8, w9, lsl #1                         
02d5714c: ldr     x30, [sp], #0x20                           
02d57150: b       #0x2d56e68                                 Blindbag.CompletedPopup::OnRewardMoney
02d57154: bl      #0x2b7105c                                 fn_2b7105c
## OnRewardButtonClicked() -> void
---- Blindbag.CompletedPopup::OnRewardButtonClicked 0x2d57158
02d57158: str     x30, [sp, #-0x20]!                         
02d5715c: stp     x20, x19, [sp, #0x10]                      
02d57160: adrp    x20, #0x6630000                            
02d57164: mov     x19, x0                                    
02d57168: ldrb    w8, [x20, #0x291]                          
02d5716c: tbnz    w8, #0, #0x2d57184                         
02d57170: adrp    x0, #0x6267000                             
02d57174: ldr     x0, [x0, #0xd50]                           MS:MonoSingleton`1::get_Instance
02d57178: bl      #0x2b70db0                                 fn_2b70db0
02d5717c: mov     w8, #1                                     
02d57180: strb    w8, [x20, #0x291]                          
02d57184: mov     x0, xzr                                    
02d57188: bl      #0x2d6eec8                                 Framework.AudioManager::get_Instance
02d5718c: cbz     x0, #0x2d571f8                             
02d57190: movi    d1, #0000000000000000                      
02d57194: movi    d2, #0000000000000000                      
02d57198: adrp    x20, #0x6267000                            
02d5719c: fmov    s0, #1.00000000                            
02d571a0: ldr     x20, [x20, #0xd50]                         MS:MonoSingleton`1::get_Instance
02d571a4: mov     w1, #1                                     
02d571a8: mov     w2, wzr                                    
02d571ac: mov     w3, wzr                                    
02d571b0: mov     x4, xzr                                    
02d571b4: bl      #0x2d6f03c                                 Framework.AudioManager::PlaySound
02d571b8: ldr     x0, [x20]                                  S:'didu'
02d571bc: bl      #0x3769600                                 fn_3769600
02d571c0: cbz     x0, #0x2d571f8                             
02d571c4: mov     w1, #4                                     
02d571c8: mov     x2, xzr                                    
02d571cc: bl      #0x2cc6ee0                                 Framework.VibrationManager::Haptic
02d571d0: mov     x0, x19                                    
02d571d4: mov     w1, wzr                                    
02d571d8: bl      #0x2d56ce4                                 Blindbag.CompletedPopup::SetInteractButtons
02d571dc: ldp     w8, w9, [x19, #0x70]                       ._income
02d571e0: mov     x0, x19                                    
02d571e4: ldp     x20, x19, [sp, #0x10]                      
02d571e8: mov     w2, #1                                     
02d571ec: add     w1, w9, w8                                 
02d571f0: ldr     x30, [sp], #0x20                           
02d571f4: b       #0x2d56e68                                 Blindbag.CompletedPopup::OnRewardMoney
02d571f8: bl      #0x2b7105c                                 fn_2b7105c
## OnHide() -> void
---- Blindbag.CompletedPopup::OnHide 0x2d571fc
02d571fc: mov     x1, xzr                                    
02d57200: b       #0x2cddc10                                 UIBase::OnHide
## .ctor() -> void
---- Blindbag.CompletedPopup::.ctor 0x2d57204
02d57204: mov     x1, xzr                                    
02d57208: b       #0x2cddba8                                 PopupBase::.ctor
