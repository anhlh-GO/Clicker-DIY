#### CLASS Character.BaseState parent= object
#   field Motion                         Character.MotionStateMachine                       off=0x10 attr=4 
#   field Animator                       SpineAnimationHandler                              off=0x18 attr=4 
#   field SingleAnimationType            EAnimationSpineType                                off=0x20 attr=4 
## GetAnimationSpineType() -> EAnimationSpineType
---- Character.BaseState::GetAnimationSpineType 0x2d74e28
02d74e28: ldr     w0, [x0, #0x20]                            .SingleAnimationType
02d74e2c: ret                                                
##  Initialize (no body)
##  SetAnimationType (no body)
##  SetAnimationTypes (no body)
## .ctor() -> void
---- Character.BaseState::.ctor 0x2d74e30
02d74e30: mov     x1, xzr                                    
02d74e34: b       #0x4e53e9c                                 System.Object::.ctor
