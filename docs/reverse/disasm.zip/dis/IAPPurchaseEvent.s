#### CLASS IAPPurchaseEvent parent= object
#   field <Result>k__BackingField        IAPPurchaseResult                                  off=0x10 attr=21 CompilerGeneratedAttribute
#   field <ProductId>k__BackingField     string                                             off=0x18 attr=21 CompilerGeneratedAttribute
#   field <Quantity>k__BackingField      int                                                off=0x20 attr=21 CompilerGeneratedAttribute
#   field <FailureReason>k__BackingField string                                             off=0x28 attr=21 CompilerGeneratedAttribute
## get_Result() -> IAPPurchaseResult
---- IAPPurchaseEvent::get_Result 0x2ca7f38
02ca7f38: ldr     w0, [x0, #0x10]                            .<Result>k__BackingField
02ca7f3c: ret                                                
## get_ProductId() -> string
---- IAPPurchaseEvent::get_ProductId 0x2ca7f40
02ca7f40: ldr     x0, [x0, #0x18]                            .<ProductId>k__BackingField
02ca7f44: ret                                                
## get_Quantity() -> int
---- IAPPurchaseEvent::get_Quantity 0x2ca7f48
02ca7f48: ldr     w0, [x0, #0x20]                            .<Quantity>k__BackingField
02ca7f4c: ret                                                
## get_FailureReason() -> string
---- IAPPurchaseEvent::get_FailureReason 0x2ca7f50
02ca7f50: ldr     x0, [x0, #0x28]                            .<FailureReason>k__BackingField
02ca7f54: ret                                                
## .ctor(IAPPurchaseResult result, string productId, int quantity, string failureReason) -> void
---- IAPPurchaseEvent::.ctor 0x2ca7f58
02ca7f58: stp     x30, x23, [sp, #-0x30]!                    
02ca7f5c: stp     x22, x21, [sp, #0x10]                      
02ca7f60: stp     x20, x19, [sp, #0x20]                      
02ca7f64: mov     w22, w1                                    
02ca7f68: mov     x1, xzr                                    
02ca7f6c: mov     x19, x4                                    
02ca7f70: mov     w20, w3                                    
02ca7f74: mov     x21, x2                                    
02ca7f78: mov     x23, x0                                    
02ca7f7c: bl      #0x4e53e9c                                 System.Object::.ctor
02ca7f80: mov     x0, x23                                    
02ca7f84: mov     x1, x21                                    
02ca7f88: str     w22, [x23, #0x10]                          
02ca7f8c: str     x21, [x0, #0x18]!                          .<ProductId>k__BackingField
02ca7f90: bl      #0x2b70d54                                 fn_2b70d54
02ca7f94: str     x19, [x23, #0x28]!                         
02ca7f98: mov     x1, x19                                    
02ca7f9c: stur    w20, [x23, #-8]                            
02ca7fa0: ldp     x20, x19, [sp, #0x20]                      
02ca7fa4: ldp     x22, x21, [sp, #0x10]                      
02ca7fa8: mov     x0, x23                                    
02ca7fac: ldp     x30, x23, [sp], #0x30                      
02ca7fb0: b       #0x2b70d54                                 
