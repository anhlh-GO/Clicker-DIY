#### CLASS Framework.SceneUtils/<CRLoadSceneAsync>d__0 parent= object
#   field <>1__state                     int                                                off=0x10 attr=1 
#   field <>2__current                   object                                             off=0x18 attr=1 
#   field sceneBuildIndex                int                                                off=0x20 attr=6 
#   field isAdditive                     bool                                               off=0x24 attr=6 
#   field setActive                      bool                                               off=0x25 attr=6 
#   field onLoadSceneCompleted           System.Action                                      off=0x28 attr=6 
## .ctor(int <>1__state) -> void
---- Framework.SceneUtils/<CRLoadSceneAsync>d__0::.ctor 0x2cc1904
02cc1904: str     x30, [sp, #-0x20]!                         
02cc1908: stp     x20, x19, [sp, #0x10]                      
02cc190c: mov     w19, w1                                    
02cc1910: mov     x1, xzr                                    
02cc1914: mov     x20, x0                                    
02cc1918: bl      #0x4e53e9c                                 System.Object::.ctor
02cc191c: str     w19, [x20, #0x10]                          .<>1__state
02cc1920: ldp     x20, x19, [sp, #0x10]                      
02cc1924: ldr     x30, [sp], #0x20                           
02cc1928: ret                                                
## System.IDisposable.Dispose() -> void
---- Framework.SceneUtils/<CRLoadSceneAsync>d__0::System.IDisposable.Dispose 0x2cc1b50
02cc1b50: ret                                                
## MoveNext() -> bool
---- Framework.SceneUtils/<CRLoadSceneAsync>d__0::MoveNext 0x2cc1b54
02cc1b54: str     x30, [sp, #-0x30]!                         
02cc1b58: stp     x22, x21, [sp, #0x10]                      
02cc1b5c: stp     x20, x19, [sp, #0x20]                      
02cc1b60: adrp    x20, #0x662f000                            
02cc1b64: mov     x19, x0                                    
02cc1b68: ldrb    w8, [x20, #0xc20]                          
02cc1b6c: tbnz    w8, #0, #0x2cc1b84                         
02cc1b70: adrp    x0, #0x6264000                             
02cc1b74: ldr     x0, [x0, #0xb58]                           T:UnityEngine.SceneManagement.SceneManager
02cc1b78: bl      #0x2b70db0                                 fn_2b70db0
02cc1b7c: mov     w8, #1                                     
02cc1b80: strb    w8, [x20, #0xc20]                          
02cc1b84: ldr     w22, [x19, #0x10]                          .<>1__state
02cc1b88: cbz     w22, #0x2cc1bf4                            
02cc1b8c: cmp     w22, #1                                    
02cc1b90: b.ne    #0x2cc1c44                                 
02cc1b94: ldrb    w8, [x19, #0x25]                           .setActive
02cc1b98: mov     w9, #-1                                    
02cc1b9c: str     w9, [x19, #0x10]                           .<>1__state
02cc1ba0: cbz     w8, #0x2cc1bd8                             
02cc1ba4: adrp    x8, #0x6264000                             
02cc1ba8: ldr     x8, [x8, #0xb58]                           T:UnityEngine.SceneManagement.SceneManager
02cc1bac: ldr     w20, [x19, #0x20]                          .sceneBuildIndex
02cc1bb0: ldr     x0, [x8]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02cc1bb4: ldr     w8, [x0, #0xe4]                            [62640e4]=0 f=0,0
02cc1bb8: cbnz    w8, #0x2cc1bc0                             
02cc1bbc: bl      #0x2b70f30                                 fn_2b70f30
02cc1bc0: mov     w0, w20                                    
02cc1bc4: mov     x1, xzr                                    
02cc1bc8: bl      #0x5b4ee28                                 UnityEngine.SceneManagement.SceneManager::GetSceneByBuildIndex
02cc1bcc: mov     w0, w0                                     
02cc1bd0: mov     x1, xzr                                    
02cc1bd4: bl      #0x5b4ebbc                                 UnityEngine.SceneManagement.SceneManager::SetActiveScene
02cc1bd8: ldr     x8, [x19, #0x28]                           .onLoadSceneCompleted
02cc1bdc: cbz     x8, #0x2cc1c44                             
02cc1be0: ldr     x9, [x8, #0x18]                            M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass2_0::<DOSetFloat>b__1
02cc1be4: ldr     x0, [x8, #0x40]                            MS:DG.Tweening.TweenSettingsExtensions::SetTarget
02cc1be8: ldr     x1, [x8, #0x28]                            T:type8534(k15)
02cc1bec: blr     x9                                         
02cc1bf0: b       #0x2cc1c44                                 
02cc1bf4: adrp    x8, #0x6264000                             
02cc1bf8: mov     w9, #-1                                    
02cc1bfc: ldr     x8, [x8, #0xb58]                           T:UnityEngine.SceneManagement.SceneManager
02cc1c00: ldr     w20, [x19, #0x20]                          .sceneBuildIndex
02cc1c04: ldrb    w21, [x19, #0x24]                          .isAdditive
02cc1c08: str     w9, [x19, #0x10]                           .<>1__state
02cc1c0c: ldr     x0, [x8]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02cc1c10: ldr     w8, [x0, #0xe4]                            [62640e4]=0 f=0,0
02cc1c14: cbnz    w8, #0x2cc1c1c                             
02cc1c18: bl      #0x2b70f30                                 fn_2b70f30
02cc1c1c: mov     w0, w20                                    
02cc1c20: mov     w1, w21                                    
02cc1c24: mov     x2, xzr                                    
02cc1c28: bl      #0x5b4f748                                 UnityEngine.SceneManagement.SceneManager::LoadSceneAsync
02cc1c2c: mov     x1, x0                                     
02cc1c30: str     x0, [x19, #0x18]!                          .<>2__current
02cc1c34: mov     x0, x19                                    
02cc1c38: bl      #0x2b70d54                                 fn_2b70d54
02cc1c3c: mov     w8, #1                                     
02cc1c40: stur    w8, [x19, #-8]                             
02cc1c44: cmp     w22, #0                                    
02cc1c48: ldp     x20, x19, [sp, #0x20]                      
02cc1c4c: ldp     x22, x21, [sp, #0x10]                      
02cc1c50: cset    w0, eq                                     
02cc1c54: ldr     x30, [sp], #0x30                           
02cc1c58: ret                                                
## System.Collections.Generic.IEnumerator<System.Object>.get_Current() -> object
---- Framework.SceneUtils/<CRLoadSceneAsync>d__0::System.Collections.Generic.IEnumerator<System.Object>.get_Current 0x2cc1c5c
02cc1c5c: ldr     x0, [x0, #0x18]                            .<>2__current
02cc1c60: ret                                                
## System.Collections.IEnumerator.Reset() -> void
---- Framework.SceneUtils/<CRLoadSceneAsync>d__0::System.Collections.IEnumerator.Reset 0x2cc1c64
02cc1c64: stp     x30, x19, [sp, #-0x10]!                    
02cc1c68: adrp    x0, #0x6264000                             
02cc1c6c: ldr     x0, [x0, #0xf60]                           T:System.NotSupportedException
02cc1c70: bl      #0x2b70dc4                                 fn_2b70dc4
02cc1c74: bl      #0x2b7104c                                 fn_2b7104c
02cc1c78: mov     x1, xzr                                    
02cc1c7c: mov     x19, x0                                    
02cc1c80: bl      #0x4e14238                                 System.NotSupportedException::.ctor
02cc1c84: adrp    x0, #0x6267000                             
02cc1c88: ldr     x0, [x0, #0xa0]                            M:Framework.SceneUtils/<CRLoadSceneAsync>d__0::System.Collections.IEnumerator.Reset
02cc1c8c: bl      #0x2b70dc4                                 fn_2b70dc4
02cc1c90: mov     x1, x0                                     
02cc1c94: mov     x0, x19                                    
02cc1c98: bl      #0x2b70f20                                 fn_2b70f20
## System.Collections.IEnumerator.get_Current() -> object
---- Framework.SceneUtils/<CRLoadSceneAsync>d__0::System.Collections.IEnumerator.get_Current 0x2cc1c9c
02cc1c9c: ldr     x0, [x0, #0x18]                            .<>2__current
02cc1ca0: ret                                                
#### CLASS Framework.SceneUtils/<CRLoadSceneAsync>d__1 parent= object
#   field <>1__state                     int                                                off=0x10 attr=1 
#   field <>2__current                   object                                             off=0x18 attr=1 
#   field sceneName                      string                                             off=0x20 attr=6 
#   field isAdditive                     bool                                               off=0x28 attr=6 
#   field setActive                      bool                                               off=0x29 attr=6 
#   field onLoadSceneCompleted           System.Action                                      off=0x30 attr=6 
## .ctor(int <>1__state) -> void
---- Framework.SceneUtils/<CRLoadSceneAsync>d__1::.ctor 0x2cc19d4
02cc19d4: str     x30, [sp, #-0x20]!                         
02cc19d8: stp     x20, x19, [sp, #0x10]                      
02cc19dc: mov     w19, w1                                    
02cc19e0: mov     x1, xzr                                    
02cc19e4: mov     x20, x0                                    
02cc19e8: bl      #0x4e53e9c                                 System.Object::.ctor
02cc19ec: str     w19, [x20, #0x10]                          .<>1__state
02cc19f0: ldp     x20, x19, [sp, #0x10]                      
02cc19f4: ldr     x30, [sp], #0x20                           
02cc19f8: ret                                                
## System.IDisposable.Dispose() -> void
---- Framework.SceneUtils/<CRLoadSceneAsync>d__1::System.IDisposable.Dispose 0x2cc1ca4
02cc1ca4: ret                                                
## MoveNext() -> bool
---- Framework.SceneUtils/<CRLoadSceneAsync>d__1::MoveNext 0x2cc1ca8
02cc1ca8: stp     x30, x21, [sp, #-0x20]!                    
02cc1cac: stp     x20, x19, [sp, #0x10]                      
02cc1cb0: adrp    x20, #0x662f000                            
02cc1cb4: mov     x19, x0                                    
02cc1cb8: ldrb    w8, [x20, #0xc21]                          
02cc1cbc: tbnz    w8, #0, #0x2cc1cec                         
02cc1cc0: adrp    x0, #0x6263000                             
02cc1cc4: ldr     x0, [x0, #0x928]                           T:UnityEngine.Debug
02cc1cc8: bl      #0x2b70db0                                 fn_2b70db0
02cc1ccc: adrp    x0, #0x6264000                             
02cc1cd0: ldr     x0, [x0, #0xb58]                           T:UnityEngine.SceneManagement.SceneManager
02cc1cd4: bl      #0x2b70db0                                 fn_2b70db0
02cc1cd8: adrp    x0, #0x6267000                             
02cc1cdc: ldr     x0, [x0, #0xa8]                            S:'Invalid sceneName: '
02cc1ce0: bl      #0x2b70db0                                 fn_2b70db0
02cc1ce4: mov     w8, #1                                     
02cc1ce8: strb    w8, [x20, #0xc21]                          
02cc1cec: ldr     w8, [x19, #0x10]                           .<>1__state
02cc1cf0: cmp     w8, #1                                     
02cc1cf4: b.eq    #0x2cc1d60                                 
02cc1cf8: cbnz    w8, #0x2cc1dbc                             
02cc1cfc: ldr     x0, [x19, #0x20]                           .sceneName
02cc1d00: mov     w8, #-1                                    
02cc1d04: mov     x1, xzr                                    
02cc1d08: str     w8, [x19, #0x10]                           .<>1__state
02cc1d0c: bl      #0x4ca6234                                 System.String::IsNullOrEmpty
02cc1d10: ldr     x20, [x19, #0x20]                          .sceneName
02cc1d14: tbz     w0, #0, #0x2cc1dcc                         
02cc1d18: adrp    x8, #0x6267000                             
02cc1d1c: mov     x1, x20                                    
02cc1d20: mov     x2, xzr                                    
02cc1d24: ldr     x8, [x8, #0xa8]                            S:'Invalid sceneName: '
02cc1d28: ldr     x0, [x8]                                   S:'didu'
02cc1d2c: bl      #0x4c9c514                                 System.String::Concat
02cc1d30: adrp    x8, #0x6263000                             
02cc1d34: mov     x19, x0                                    
02cc1d38: ldr     x8, [x8, #0x928]                           T:UnityEngine.Debug
02cc1d3c: ldr     x8, [x8]                                   &2c5bbd4(=a9bd7bfdd503233f)
02cc1d40: ldr     w9, [x8, #0xe4]                            [62630e4]=0 f=0,0
02cc1d44: cbnz    w9, #0x2cc1d50                             
02cc1d48: mov     x0, x8                                     
02cc1d4c: bl      #0x2b70f30                                 fn_2b70f30
02cc1d50: mov     x0, x19                                    
02cc1d54: mov     x1, xzr                                    
02cc1d58: bl      #0x5af2840                                 UnityEngine.Debug::LogError
02cc1d5c: b       #0x2cc1dbc                                 
02cc1d60: ldrb    w8, [x19, #0x29]                           .setActive
02cc1d64: mov     w9, #-1                                    
02cc1d68: str     w9, [x19, #0x10]                           .<>1__state
02cc1d6c: cbz     w8, #0x2cc1da4                             
02cc1d70: adrp    x8, #0x6264000                             
02cc1d74: ldr     x8, [x8, #0xb58]                           T:UnityEngine.SceneManagement.SceneManager
02cc1d78: ldr     x20, [x19, #0x20]                          .sceneName
02cc1d7c: ldr     x0, [x8]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02cc1d80: ldr     w8, [x0, #0xe4]                            [62670e4]=0 f=0,0
02cc1d84: cbnz    w8, #0x2cc1d8c                             
02cc1d88: bl      #0x2b70f30                                 fn_2b70f30
02cc1d8c: mov     x0, x20                                    
02cc1d90: mov     x1, xzr                                    
02cc1d94: bl      #0x5b4ec74                                 UnityEngine.SceneManagement.SceneManager::GetSceneByName
02cc1d98: mov     w0, w0                                     
02cc1d9c: mov     x1, xzr                                    
02cc1da0: bl      #0x5b4ebbc                                 UnityEngine.SceneManagement.SceneManager::SetActiveScene
02cc1da4: ldr     x8, [x19, #0x30]                           .onLoadSceneCompleted
02cc1da8: cbz     x8, #0x2cc1dbc                             
02cc1dac: ldr     x9, [x8, #0x18]                            M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass2_0::<DOSetFloat>b__1
02cc1db0: ldr     x0, [x8, #0x40]                            MS:DG.Tweening.TweenSettingsExtensions::SetTarget
02cc1db4: ldr     x1, [x8, #0x28]                            T:type8534(k15)
02cc1db8: blr     x9                                         
02cc1dbc: mov     w0, wzr                                    
02cc1dc0: ldp     x20, x19, [sp, #0x10]                      
02cc1dc4: ldp     x30, x21, [sp], #0x20                      
02cc1dc8: ret                                                
02cc1dcc: adrp    x8, #0x6264000                             
02cc1dd0: ldr     x8, [x8, #0xb58]                           T:UnityEngine.SceneManagement.SceneManager
02cc1dd4: ldrb    w21, [x19, #0x28]                          .isAdditive
02cc1dd8: ldr     x0, [x8]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02cc1ddc: ldr     w8, [x0, #0xe4]                            [62670e4]=0 f=0,0
02cc1de0: cbnz    w8, #0x2cc1de8                             
02cc1de4: bl      #0x2b70f30                                 fn_2b70f30
02cc1de8: mov     x0, x20                                    
02cc1dec: mov     w1, w21                                    
02cc1df0: mov     x2, xzr                                    
02cc1df4: bl      #0x5b4f818                                 UnityEngine.SceneManagement.SceneManager::LoadSceneAsync
02cc1df8: mov     x1, x0                                     
02cc1dfc: str     x0, [x19, #0x18]!                          .<>2__current
02cc1e00: mov     x0, x19                                    
02cc1e04: bl      #0x2b70d54                                 fn_2b70d54
02cc1e08: mov     w0, #1                                     
02cc1e0c: stur    w0, [x19, #-8]                             
02cc1e10: b       #0x2cc1dc0                                 
## System.Collections.Generic.IEnumerator<System.Object>.get_Current() -> object
---- Framework.SceneUtils/<CRLoadSceneAsync>d__1::System.Collections.Generic.IEnumerator<System.Object>.get_Current 0x2cc1e14
02cc1e14: ldr     x0, [x0, #0x18]                            .<>2__current
02cc1e18: ret                                                
## System.Collections.IEnumerator.Reset() -> void
---- Framework.SceneUtils/<CRLoadSceneAsync>d__1::System.Collections.IEnumerator.Reset 0x2cc1e1c
02cc1e1c: stp     x30, x19, [sp, #-0x10]!                    
02cc1e20: adrp    x0, #0x6264000                             
02cc1e24: ldr     x0, [x0, #0xf60]                           T:System.NotSupportedException
02cc1e28: bl      #0x2b70dc4                                 fn_2b70dc4
02cc1e2c: bl      #0x2b7104c                                 fn_2b7104c
02cc1e30: mov     x1, xzr                                    
02cc1e34: mov     x19, x0                                    
02cc1e38: bl      #0x4e14238                                 System.NotSupportedException::.ctor
02cc1e3c: adrp    x0, #0x6267000                             
02cc1e40: ldr     x0, [x0, #0xb0]                            M:Framework.SceneUtils/<CRLoadSceneAsync>d__1::System.Collections.IEnumerator.Reset
02cc1e44: bl      #0x2b70dc4                                 fn_2b70dc4
02cc1e48: mov     x1, x0                                     
02cc1e4c: mov     x0, x19                                    
02cc1e50: bl      #0x2b70f20                                 fn_2b70f20
## System.Collections.IEnumerator.get_Current() -> object
---- Framework.SceneUtils/<CRLoadSceneAsync>d__1::System.Collections.IEnumerator.get_Current 0x2cc1e54
02cc1e54: ldr     x0, [x0, #0x18]                            .<>2__current
02cc1e58: ret                                                
#### CLASS Framework.SceneUtils/<CRUnloadSceneAsync>d__2 parent= object
#   field <>1__state                     int                                                off=0x10 attr=1 
#   field <>2__current                   object                                             off=0x18 attr=1 
#   field sceneBuildIndex                int                                                off=0x20 attr=6 
#   field onUnloadSceneCompleted         System.Action                                      off=0x28 attr=6 
## .ctor(int <>1__state) -> void
---- Framework.SceneUtils/<CRUnloadSceneAsync>d__2::.ctor 0x2cc1a78
02cc1a78: str     x30, [sp, #-0x20]!                         
02cc1a7c: stp     x20, x19, [sp, #0x10]                      
02cc1a80: mov     w19, w1                                    
02cc1a84: mov     x1, xzr                                    
02cc1a88: mov     x20, x0                                    
02cc1a8c: bl      #0x4e53e9c                                 System.Object::.ctor
02cc1a90: str     w19, [x20, #0x10]                          .<>1__state
02cc1a94: ldp     x20, x19, [sp, #0x10]                      
02cc1a98: ldr     x30, [sp], #0x20                           
02cc1a9c: ret                                                
## System.IDisposable.Dispose() -> void
---- Framework.SceneUtils/<CRUnloadSceneAsync>d__2::System.IDisposable.Dispose 0x2cc1e5c
02cc1e5c: ret                                                
## MoveNext() -> bool
---- Framework.SceneUtils/<CRUnloadSceneAsync>d__2::MoveNext 0x2cc1e60
02cc1e60: sub     sp, sp, #0x30                              
02cc1e64: stp     x30, x21, [sp, #0x10]                      
02cc1e68: stp     x20, x19, [sp, #0x20]                      
02cc1e6c: adrp    x20, #0x662f000                            
02cc1e70: mov     x19, x0                                    
02cc1e74: ldrb    w8, [x20, #0xc22]                          
02cc1e78: tbnz    w8, #0, #0x2cc1e90                         
02cc1e7c: adrp    x0, #0x6264000                             
02cc1e80: ldr     x0, [x0, #0xb58]                           T:UnityEngine.SceneManagement.SceneManager
02cc1e84: bl      #0x2b70db0                                 fn_2b70db0
02cc1e88: mov     w8, #1                                     
02cc1e8c: strb    w8, [x20, #0xc22]                          
02cc1e90: ldr     w8, [x19, #0x10]                           .<>1__state
02cc1e94: str     wzr, [sp, #0xc]                            
02cc1e98: cmp     w8, #1                                     
02cc1e9c: b.eq    #0x2cc1f28                                 
02cc1ea0: mov     w0, wzr                                    
02cc1ea4: cbnz    w8, #0x2cc1f4c                             
02cc1ea8: adrp    x21, #0x6264000                            
02cc1eac: mov     w9, #-1                                    
02cc1eb0: ldr     x21, [x21, #0xb58]                         T:UnityEngine.SceneManagement.SceneManager
02cc1eb4: ldr     w20, [x19, #0x20]                          .sceneBuildIndex
02cc1eb8: str     w9, [x19, #0x10]                           .<>1__state
02cc1ebc: ldr     x0, [x21]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02cc1ec0: ldr     w8, [x0, #0xe4]                            [62640e4]=0 f=0,0
02cc1ec4: cbnz    w8, #0x2cc1ecc                             
02cc1ec8: bl      #0x2b70f30                                 fn_2b70f30
02cc1ecc: mov     w0, w20                                    
02cc1ed0: mov     x1, xzr                                    
02cc1ed4: bl      #0x5b4ee28                                 UnityEngine.SceneManagement.SceneManager::GetSceneByBuildIndex
02cc1ed8: str     w0, [sp, #0xc]                             
02cc1edc: add     x0, sp, #0xc                               
02cc1ee0: mov     x1, xzr                                    
02cc1ee4: bl      #0x5b4ddc0                                 UnityEngine.SceneManagement.Scene::IsValid
02cc1ee8: tbz     w0, #0, #0x2cc1f30                         
02cc1eec: ldr     x0, [x21]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02cc1ef0: ldr     w20, [x19, #0x20]                          .sceneBuildIndex
02cc1ef4: ldr     w8, [x0, #0xe4]                            [62640e4]=0 f=0,0
02cc1ef8: cbnz    w8, #0x2cc1f00                             
02cc1efc: bl      #0x2b70f30                                 fn_2b70f30
02cc1f00: mov     w0, w20                                    
02cc1f04: mov     x1, xzr                                    
02cc1f08: bl      #0x5b4f940                                 UnityEngine.SceneManagement.SceneManager::UnloadSceneAsync
02cc1f0c: mov     x1, x0                                     
02cc1f10: str     x0, [x19, #0x18]!                          .<>2__current
02cc1f14: mov     x0, x19                                    
02cc1f18: bl      #0x2b70d54                                 fn_2b70d54
02cc1f1c: mov     w0, #1                                     
02cc1f20: stur    w0, [x19, #-8]                             
02cc1f24: b       #0x2cc1f4c                                 
02cc1f28: mov     w8, #-1                                    
02cc1f2c: str     w8, [x19, #0x10]                           .<>1__state
02cc1f30: ldr     x8, [x19, #0x28]                           .onUnloadSceneCompleted
02cc1f34: cbz     x8, #0x2cc1f48                             
02cc1f38: ldr     x9, [x8, #0x18]                            
02cc1f3c: ldr     x0, [x8, #0x40]                            
02cc1f40: ldr     x1, [x8, #0x28]                            
02cc1f44: blr     x9                                         
02cc1f48: mov     w0, wzr                                    
02cc1f4c: ldp     x20, x19, [sp, #0x20]                      
02cc1f50: ldp     x30, x21, [sp, #0x10]                      
02cc1f54: add     sp, sp, #0x30                              
02cc1f58: ret                                                
## System.Collections.Generic.IEnumerator<System.Object>.get_Current() -> object
---- Framework.SceneUtils/<CRUnloadSceneAsync>d__2::System.Collections.Generic.IEnumerator<System.Object>.get_Current 0x2cc1f5c
02cc1f5c: ldr     x0, [x0, #0x18]                            .<>2__current
02cc1f60: ret                                                
## System.Collections.IEnumerator.Reset() -> void
---- Framework.SceneUtils/<CRUnloadSceneAsync>d__2::System.Collections.IEnumerator.Reset 0x2cc1f64
02cc1f64: stp     x30, x19, [sp, #-0x10]!                    
02cc1f68: adrp    x0, #0x6264000                             
02cc1f6c: ldr     x0, [x0, #0xf60]                           T:System.NotSupportedException
02cc1f70: bl      #0x2b70dc4                                 fn_2b70dc4
02cc1f74: bl      #0x2b7104c                                 fn_2b7104c
02cc1f78: mov     x1, xzr                                    
02cc1f7c: mov     x19, x0                                    
02cc1f80: bl      #0x4e14238                                 System.NotSupportedException::.ctor
02cc1f84: adrp    x0, #0x6267000                             
02cc1f88: ldr     x0, [x0, #0xb8]                            M:Framework.SceneUtils/<CRUnloadSceneAsync>d__2::System.Collections.IEnumerator.Reset
02cc1f8c: bl      #0x2b70dc4                                 fn_2b70dc4
02cc1f90: mov     x1, x0                                     
02cc1f94: mov     x0, x19                                    
02cc1f98: bl      #0x2b70f20                                 fn_2b70f20
## System.Collections.IEnumerator.get_Current() -> object
---- Framework.SceneUtils/<CRUnloadSceneAsync>d__2::System.Collections.IEnumerator.get_Current 0x2cc1f9c
02cc1f9c: ldr     x0, [x0, #0x18]                            .<>2__current
02cc1fa0: ret                                                
#### CLASS Framework.SceneUtils/<CRUnloadSceneAsync>d__3 parent= object
#   field <>1__state                     int                                                off=0x10 attr=1 
#   field <>2__current                   object                                             off=0x18 attr=1 
#   field sceneName                      string                                             off=0x20 attr=6 
#   field onUnloadSceneCompleted         System.Action                                      off=0x28 attr=6 
## .ctor(int <>1__state) -> void
---- Framework.SceneUtils/<CRUnloadSceneAsync>d__3::.ctor 0x2cc1b28
02cc1b28: str     x30, [sp, #-0x20]!                         
02cc1b2c: stp     x20, x19, [sp, #0x10]                      
02cc1b30: mov     w19, w1                                    
02cc1b34: mov     x1, xzr                                    
02cc1b38: mov     x20, x0                                    
02cc1b3c: bl      #0x4e53e9c                                 System.Object::.ctor
02cc1b40: str     w19, [x20, #0x10]                          .<>1__state
02cc1b44: ldp     x20, x19, [sp, #0x10]                      
02cc1b48: ldr     x30, [sp], #0x20                           
02cc1b4c: ret                                                
## System.IDisposable.Dispose() -> void
---- Framework.SceneUtils/<CRUnloadSceneAsync>d__3::System.IDisposable.Dispose 0x2cc1fa4
02cc1fa4: ret                                                
## MoveNext() -> bool
---- Framework.SceneUtils/<CRUnloadSceneAsync>d__3::MoveNext 0x2cc1fa8
02cc1fa8: sub     sp, sp, #0x30                              
02cc1fac: stp     x30, x21, [sp, #0x10]                      
02cc1fb0: stp     x20, x19, [sp, #0x20]                      
02cc1fb4: adrp    x20, #0x662f000                            
02cc1fb8: mov     x19, x0                                    
02cc1fbc: ldrb    w8, [x20, #0xc23]                          
02cc1fc0: tbnz    w8, #0, #0x2cc1ff0                         
02cc1fc4: adrp    x0, #0x6263000                             
02cc1fc8: ldr     x0, [x0, #0x928]                           T:UnityEngine.Debug
02cc1fcc: bl      #0x2b70db0                                 fn_2b70db0
02cc1fd0: adrp    x0, #0x6264000                             
02cc1fd4: ldr     x0, [x0, #0xb58]                           T:UnityEngine.SceneManagement.SceneManager
02cc1fd8: bl      #0x2b70db0                                 fn_2b70db0
02cc1fdc: adrp    x0, #0x6267000                             
02cc1fe0: ldr     x0, [x0, #0xa8]                            S:'Invalid sceneName: '
02cc1fe4: bl      #0x2b70db0                                 fn_2b70db0
02cc1fe8: mov     w8, #1                                     
02cc1fec: strb    w8, [x20, #0xc23]                          
02cc1ff0: ldr     w8, [x19, #0x10]                           .<>1__state
02cc1ff4: str     wzr, [sp, #0xc]                            
02cc1ff8: cmp     w8, #1                                     
02cc1ffc: b.eq    #0x2cc206c                                 
02cc2000: mov     w0, wzr                                    
02cc2004: cbnz    w8, #0x2cc2090                             
02cc2008: ldr     x0, [x19, #0x20]                           .sceneName
02cc200c: mov     w8, #-1                                    
02cc2010: mov     x1, xzr                                    
02cc2014: str     w8, [x19, #0x10]                           .<>1__state
02cc2018: bl      #0x4ca6234                                 System.String::IsNullOrEmpty
02cc201c: ldr     x20, [x19, #0x20]                          .sceneName
02cc2020: tbz     w0, #0, #0x2cc20a0                         
02cc2024: adrp    x8, #0x6267000                             
02cc2028: mov     x1, x20                                    
02cc202c: mov     x2, xzr                                    
02cc2030: ldr     x8, [x8, #0xa8]                            S:'Invalid sceneName: '
02cc2034: ldr     x0, [x8]                                   S:'didu'
02cc2038: bl      #0x4c9c514                                 System.String::Concat
02cc203c: adrp    x8, #0x6263000                             
02cc2040: mov     x19, x0                                    
02cc2044: ldr     x8, [x8, #0x928]                           T:UnityEngine.Debug
02cc2048: ldr     x8, [x8]                                   &2c5bbd4(=a9bd7bfdd503233f)
02cc204c: ldr     w9, [x8, #0xe4]                            [62630e4]=0 f=0,0
02cc2050: cbnz    w9, #0x2cc205c                             
02cc2054: mov     x0, x8                                     
02cc2058: bl      #0x2b70f30                                 fn_2b70f30
02cc205c: mov     x0, x19                                    
02cc2060: mov     x1, xzr                                    
02cc2064: bl      #0x5af2840                                 UnityEngine.Debug::LogError
02cc2068: b       #0x2cc208c                                 
02cc206c: mov     w8, #-1                                    
02cc2070: str     w8, [x19, #0x10]                           .<>1__state
02cc2074: ldr     x8, [x19, #0x28]                           .onUnloadSceneCompleted
02cc2078: cbz     x8, #0x2cc208c                             
02cc207c: ldr     x9, [x8, #0x18]                            &2c5d934(=d65f03c0d503245f)
02cc2080: ldr     x0, [x8, #0x40]                            [6263040]=0 f=0,0
02cc2084: ldr     x1, [x8, #0x28]                            [6263028]=0 f=0,0
02cc2088: blr     x9                                         
02cc208c: mov     w0, wzr                                    
02cc2090: ldp     x20, x19, [sp, #0x20]                      
02cc2094: ldp     x30, x21, [sp, #0x10]                      
02cc2098: add     sp, sp, #0x30                              
02cc209c: ret                                                
02cc20a0: adrp    x21, #0x6264000                            
02cc20a4: ldr     x21, [x21, #0xb58]                         T:UnityEngine.SceneManagement.SceneManager
02cc20a8: ldr     x0, [x21]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02cc20ac: ldr     w8, [x0, #0xe4]                            [62670e4]=0 f=0,0
02cc20b0: cbnz    w8, #0x2cc20b8                             
02cc20b4: bl      #0x2b70f30                                 fn_2b70f30
02cc20b8: mov     x0, x20                                    
02cc20bc: mov     x1, xzr                                    
02cc20c0: bl      #0x5b4ec74                                 UnityEngine.SceneManagement.SceneManager::GetSceneByName
02cc20c4: str     w0, [sp, #0xc]                             
02cc20c8: add     x0, sp, #0xc                               
02cc20cc: mov     x1, xzr                                    
02cc20d0: bl      #0x5b4ddc0                                 UnityEngine.SceneManagement.Scene::IsValid
02cc20d4: tbz     w0, #0, #0x2cc2074                         
02cc20d8: ldr     x0, [x21]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02cc20dc: ldr     x20, [x19, #0x20]                          .sceneName
02cc20e0: ldr     w8, [x0, #0xe4]                            [62670e4]=0 f=0,0
02cc20e4: cbnz    w8, #0x2cc20ec                             
02cc20e8: bl      #0x2b70f30                                 fn_2b70f30
02cc20ec: mov     x0, x20                                    
02cc20f0: mov     x1, xzr                                    
02cc20f4: bl      #0x5b4f9c8                                 UnityEngine.SceneManagement.SceneManager::UnloadSceneAsync
02cc20f8: mov     x1, x0                                     
02cc20fc: str     x0, [x19, #0x18]!                          .<>2__current
02cc2100: mov     x0, x19                                    
02cc2104: bl      #0x2b70d54                                 fn_2b70d54
02cc2108: mov     w0, #1                                     
02cc210c: stur    w0, [x19, #-8]                             
02cc2110: b       #0x2cc2090                                 
## System.Collections.Generic.IEnumerator<System.Object>.get_Current() -> object
---- Framework.SceneUtils/<CRUnloadSceneAsync>d__3::System.Collections.Generic.IEnumerator<System.Object>.get_Current 0x2cc2114
02cc2114: ldr     x0, [x0, #0x18]                            .<>2__current
02cc2118: ret                                                
## System.Collections.IEnumerator.Reset() -> void
---- Framework.SceneUtils/<CRUnloadSceneAsync>d__3::System.Collections.IEnumerator.Reset 0x2cc211c
02cc211c: stp     x30, x19, [sp, #-0x10]!                    
02cc2120: adrp    x0, #0x6264000                             
02cc2124: ldr     x0, [x0, #0xf60]                           T:System.NotSupportedException
02cc2128: bl      #0x2b70dc4                                 fn_2b70dc4
02cc212c: bl      #0x2b7104c                                 fn_2b7104c
02cc2130: mov     x1, xzr                                    
02cc2134: mov     x19, x0                                    
02cc2138: bl      #0x4e14238                                 System.NotSupportedException::.ctor
02cc213c: adrp    x0, #0x6267000                             
02cc2140: ldr     x0, [x0, #0xc0]                            M:Framework.SceneUtils/<CRUnloadSceneAsync>d__3::System.Collections.IEnumerator.Reset
02cc2144: bl      #0x2b70dc4                                 fn_2b70dc4
02cc2148: mov     x1, x0                                     
02cc214c: mov     x0, x19                                    
02cc2150: bl      #0x2b70f20                                 fn_2b70f20
## System.Collections.IEnumerator.get_Current() -> object
---- Framework.SceneUtils/<CRUnloadSceneAsync>d__3::System.Collections.IEnumerator.get_Current 0x2cc2154
02cc2154: ldr     x0, [x0, #0x18]                            .<>2__current
02cc2158: ret                                                
#### CLASS Framework.SceneUtils parent= object
## CRLoadSceneAsync(int sceneBuildIndex, bool isAdditive, bool setActive, System.Action onLoadSceneCompleted) -> System.Collections.IEnumerator
---- Framework.SceneUtils::CRLoadSceneAsync 0x2cc1868
02cc1868: str     x30, [sp, #-0x40]!                         
02cc186c: stp     x24, x23, [sp, #0x10]                      
02cc1870: stp     x22, x21, [sp, #0x20]                      
02cc1874: stp     x20, x19, [sp, #0x30]                      
02cc1878: adrp    x24, #0x662f000                            
02cc187c: adrp    x23, #0x6267000                            
02cc1880: mov     x19, x3                                    
02cc1884: ldrb    w8, [x24, #0xc1c]                          
02cc1888: ldr     x23, [x23, #0x80]                          T:Framework.SceneUtils/<CRLoadSceneAsync>d__0
02cc188c: mov     w22, w2                                    
02cc1890: mov     w21, w1                                    
02cc1894: mov     w20, w0                                    
02cc1898: tbnz    w8, #0, #0x2cc18b0                         
02cc189c: adrp    x0, #0x6267000                             
02cc18a0: ldr     x0, [x0, #0x80]                            T:Framework.SceneUtils/<CRLoadSceneAsync>d__0
02cc18a4: bl      #0x2b70db0                                 fn_2b70db0
02cc18a8: mov     w8, #1                                     
02cc18ac: strb    w8, [x24, #0xc1c]                          
02cc18b0: ldr     x0, [x23]                                  S:'didu'
02cc18b4: and     w22, w22, #1                               
02cc18b8: and     w23, w21, #1                               
02cc18bc: bl      #0x2b7104c                                 fn_2b7104c
02cc18c0: mov     x1, xzr                                    
02cc18c4: mov     x21, x0                                    
02cc18c8: bl      #0x4e53e9c                                 System.Object::.ctor
02cc18cc: mov     x0, x21                                    
02cc18d0: mov     x1, x19                                    
02cc18d4: str     wzr, [x21, #0x10]                          
02cc18d8: str     w20, [x21, #0x20]                          
02cc18dc: strb    w23, [x21, #0x24]                          
02cc18e0: strb    w22, [x21, #0x25]                          
02cc18e4: str     x19, [x0, #0x28]!                          
02cc18e8: bl      #0x2b70d54                                 fn_2b70d54
02cc18ec: mov     x0, x21                                    
02cc18f0: ldp     x20, x19, [sp, #0x30]                      
02cc18f4: ldp     x22, x21, [sp, #0x20]                      
02cc18f8: ldp     x24, x23, [sp, #0x10]                      
02cc18fc: ldr     x30, [sp], #0x40                           
02cc1900: ret                                                
## CRLoadSceneAsync(string sceneName, bool isAdditive, bool setActive, System.Action onLoadSceneCompleted) -> System.Collections.IEnumerator
---- Framework.SceneUtils::CRLoadSceneAsync 0x2cc192c
02cc192c: str     x30, [sp, #-0x40]!                         
02cc1930: stp     x24, x23, [sp, #0x10]                      
02cc1934: stp     x22, x21, [sp, #0x20]                      
02cc1938: stp     x20, x19, [sp, #0x30]                      
02cc193c: adrp    x24, #0x662f000                            
02cc1940: adrp    x23, #0x6267000                            
02cc1944: mov     x19, x3                                    
02cc1948: ldrb    w8, [x24, #0xc1d]                          
02cc194c: ldr     x23, [x23, #0x88]                          T:Framework.SceneUtils/<CRLoadSceneAsync>d__1
02cc1950: mov     w22, w2                                    
02cc1954: mov     w21, w1                                    
02cc1958: mov     x20, x0                                    
02cc195c: tbnz    w8, #0, #0x2cc1974                         
02cc1960: adrp    x0, #0x6267000                             
02cc1964: ldr     x0, [x0, #0x88]                            T:Framework.SceneUtils/<CRLoadSceneAsync>d__1
02cc1968: bl      #0x2b70db0                                 fn_2b70db0
02cc196c: mov     w8, #1                                     
02cc1970: strb    w8, [x24, #0xc1d]                          
02cc1974: ldr     x0, [x23]                                  S:'didu'
02cc1978: and     w22, w22, #1                               
02cc197c: and     w23, w21, #1                               
02cc1980: bl      #0x2b7104c                                 fn_2b7104c
02cc1984: mov     x1, xzr                                    
02cc1988: mov     x21, x0                                    
02cc198c: bl      #0x4e53e9c                                 System.Object::.ctor
02cc1990: mov     x0, x21                                    
02cc1994: mov     x1, x20                                    
02cc1998: str     wzr, [x21, #0x10]                          
02cc199c: str     x20, [x0, #0x20]!                          
02cc19a0: bl      #0x2b70d54                                 fn_2b70d54
02cc19a4: mov     x0, x21                                    
02cc19a8: mov     x1, x19                                    
02cc19ac: strb    w23, [x21, #0x28]                          
02cc19b0: strb    w22, [x21, #0x29]                          
02cc19b4: str     x19, [x0, #0x30]!                          
02cc19b8: bl      #0x2b70d54                                 fn_2b70d54
02cc19bc: mov     x0, x21                                    
02cc19c0: ldp     x20, x19, [sp, #0x30]                      
02cc19c4: ldp     x22, x21, [sp, #0x20]                      
02cc19c8: ldp     x24, x23, [sp, #0x10]                      
02cc19cc: ldr     x30, [sp], #0x40                           
02cc19d0: ret                                                
## CRUnloadSceneAsync(int sceneBuildIndex, System.Action onUnloadSceneCompleted) -> System.Collections.IEnumerator
---- Framework.SceneUtils::CRUnloadSceneAsync 0x2cc19fc
02cc19fc: str     x30, [sp, #-0x30]!                         
02cc1a00: stp     x22, x21, [sp, #0x10]                      
02cc1a04: stp     x20, x19, [sp, #0x20]                      
02cc1a08: adrp    x21, #0x662f000                            
02cc1a0c: adrp    x22, #0x6267000                            
02cc1a10: mov     x19, x1                                    
02cc1a14: ldrb    w8, [x21, #0xc1e]                          
02cc1a18: ldr     x22, [x22, #0x90]                          T:Framework.SceneUtils/<CRUnloadSceneAsync>d__2
02cc1a1c: mov     w20, w0                                    
02cc1a20: tbnz    w8, #0, #0x2cc1a38                         
02cc1a24: adrp    x0, #0x6267000                             
02cc1a28: ldr     x0, [x0, #0x90]                            T:Framework.SceneUtils/<CRUnloadSceneAsync>d__2
02cc1a2c: bl      #0x2b70db0                                 fn_2b70db0
02cc1a30: mov     w8, #1                                     
02cc1a34: strb    w8, [x21, #0xc1e]                          
02cc1a38: ldr     x0, [x22]                                  S:'didu'
02cc1a3c: bl      #0x2b7104c                                 fn_2b7104c
02cc1a40: mov     x1, xzr                                    
02cc1a44: mov     x21, x0                                    
02cc1a48: bl      #0x4e53e9c                                 System.Object::.ctor
02cc1a4c: mov     x0, x21                                    
02cc1a50: mov     x1, x19                                    
02cc1a54: str     wzr, [x21, #0x10]                          
02cc1a58: str     w20, [x21, #0x20]                          
02cc1a5c: str     x19, [x0, #0x28]!                          
02cc1a60: bl      #0x2b70d54                                 fn_2b70d54
02cc1a64: mov     x0, x21                                    
02cc1a68: ldp     x20, x19, [sp, #0x20]                      
02cc1a6c: ldp     x22, x21, [sp, #0x10]                      
02cc1a70: ldr     x30, [sp], #0x30                           
02cc1a74: ret                                                
## CRUnloadSceneAsync(string sceneName, System.Action onUnloadSceneCompleted) -> System.Collections.IEnumerator
---- Framework.SceneUtils::CRUnloadSceneAsync 0x2cc1aa0
02cc1aa0: str     x30, [sp, #-0x30]!                         
02cc1aa4: stp     x22, x21, [sp, #0x10]                      
02cc1aa8: stp     x20, x19, [sp, #0x20]                      
02cc1aac: adrp    x21, #0x662f000                            
02cc1ab0: adrp    x22, #0x6267000                            
02cc1ab4: mov     x19, x1                                    
02cc1ab8: ldrb    w8, [x21, #0xc1f]                          
02cc1abc: ldr     x22, [x22, #0x98]                          T:Framework.SceneUtils/<CRUnloadSceneAsync>d__3
02cc1ac0: mov     x20, x0                                    
02cc1ac4: tbnz    w8, #0, #0x2cc1adc                         
02cc1ac8: adrp    x0, #0x6267000                             
02cc1acc: ldr     x0, [x0, #0x98]                            T:Framework.SceneUtils/<CRUnloadSceneAsync>d__3
02cc1ad0: bl      #0x2b70db0                                 fn_2b70db0
02cc1ad4: mov     w8, #1                                     
02cc1ad8: strb    w8, [x21, #0xc1f]                          
02cc1adc: ldr     x0, [x22]                                  S:'didu'
02cc1ae0: bl      #0x2b7104c                                 fn_2b7104c
02cc1ae4: mov     x1, xzr                                    
02cc1ae8: mov     x21, x0                                    
02cc1aec: bl      #0x4e53e9c                                 System.Object::.ctor
02cc1af0: mov     x0, x21                                    
02cc1af4: mov     x1, x20                                    
02cc1af8: str     wzr, [x21, #0x10]                          
02cc1afc: str     x20, [x0, #0x20]!                          
02cc1b00: bl      #0x2b70d54                                 fn_2b70d54
02cc1b04: mov     x0, x21                                    
02cc1b08: mov     x1, x19                                    
02cc1b0c: str     x19, [x0, #0x28]!                          
02cc1b10: bl      #0x2b70d54                                 fn_2b70d54
02cc1b14: mov     x0, x21                                    
02cc1b18: ldp     x20, x19, [sp, #0x20]                      
02cc1b1c: ldp     x22, x21, [sp, #0x10]                      
02cc1b20: ldr     x30, [sp], #0x30                           
02cc1b24: ret                                                
