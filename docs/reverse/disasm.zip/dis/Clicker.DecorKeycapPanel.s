#### CLASS Clicker.DecorKeycapPanel/<>c parent= object
#   field <>9                            Clicker.DecorKeycapPanel/<>c                       off=0x0 attr=36 
#   field <>9__16_2                      System.Action`1<Clicker.CategoryButton>            off=0x8 attr=16 
#   field <>9__19_0                      System.Action`1<Clicker.CategoryButton>            off=0x10 attr=16 
#   field <>9__20_0                      System.Action`1<Clicker.CategoryButton>            off=0x18 attr=16 
#   field <>9__22_0                      System.Action`1<Clicker.DecorKeycapUIItem>         off=0x20 attr=16 
#   field <>9__23_0                      System.Action`1<Clicker.DecorKeycapUIItem>         off=0x28 attr=16 
#   field <>9__24_0                      System.Action`1<Clicker.DecorKeycapUIItem>         off=0x30 attr=16 
## .cctor() -> void
---- Clicker.DecorKeycapPanel/<>c::.cctor 0x2d6a6e8
02d6a6e8: str     x30, [sp, #-0x20]!                         
02d6a6ec: stp     x20, x19, [sp, #0x10]                      
02d6a6f0: adrp    x19, #0x6630000                            
02d6a6f4: adrp    x20, #0x626c000                            
02d6a6f8: ldrb    w8, [x19, #0x358]                          
02d6a6fc: ldr     x20, [x20, #0x360]                         T:Clicker.DecorKeycapPanel/<>c
02d6a700: tbnz    w8, #0, #0x2d6a718                         
02d6a704: adrp    x0, #0x626c000                             
02d6a708: ldr     x0, [x0, #0x360]                           T:Clicker.DecorKeycapPanel/<>c
02d6a70c: bl      #0x2b70db0                                 fn_2b70db0
02d6a710: mov     w8, #1                                     
02d6a714: strb    w8, [x19, #0x358]                          
02d6a718: ldr     x0, [x20]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d6a71c: bl      #0x2b7104c                                 fn_2b7104c
02d6a720: mov     x1, xzr                                    
02d6a724: mov     x19, x0                                    
02d6a728: bl      #0x4e53e9c                                 System.Object::.ctor
02d6a72c: ldr     x8, [x20]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d6a730: mov     x1, x19                                    
02d6a734: ldr     x8, [x8, #0xb8]                            
02d6a738: str     x19, [x8]                                  
02d6a73c: ldr     x8, [x20]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d6a740: ldp     x20, x19, [sp, #0x10]                      
02d6a744: ldr     x0, [x8, #0xb8]                            
02d6a748: ldr     x30, [sp], #0x20                           
02d6a74c: b       #0x2b70d54                                 
## .ctor() -> void
---- Clicker.DecorKeycapPanel/<>c::.ctor 0x2d6a750
02d6a750: mov     x1, xzr                                    
02d6a754: b       #0x4e53e9c                                 System.Object::.ctor
## <ShowPanel>b__16_2(Clicker.CategoryButton btn) -> void
---- Clicker.DecorKeycapPanel/<>c::<ShowPanel>b__16_2 0x2d6a758
02d6a758: cbz     x1, #0x2d6a768                             
02d6a75c: mov     x0, x1                                     
02d6a760: mov     w1, wzr                                    
02d6a764: b       #0x2d664c4                                 Clicker.CategoryButton::SetSelected
02d6a768: str     x30, [sp, #-0x10]!                         
02d6a76c: bl      #0x2b7105c                                 fn_2b7105c
## <OnDecorOnTopCategoryClick>b__19_0(Clicker.CategoryButton btn) -> void
---- Clicker.DecorKeycapPanel/<>c::<OnDecorOnTopCategoryClick>b__19_0 0x2d6a770
02d6a770: cbz     x1, #0x2d6a780                             
02d6a774: mov     x0, x1                                     
02d6a778: mov     w1, wzr                                    
02d6a77c: b       #0x2d664c4                                 Clicker.CategoryButton::SetSelected
02d6a780: str     x30, [sp, #-0x10]!                         
02d6a784: bl      #0x2b7105c                                 fn_2b7105c
## <OnDecorReplaceCategoryClick>b__20_0(Clicker.CategoryButton btn) -> void
---- Clicker.DecorKeycapPanel/<>c::<OnDecorReplaceCategoryClick>b__20_0 0x2d6a788
02d6a788: cbz     x1, #0x2d6a798                             
02d6a78c: mov     x0, x1                                     
02d6a790: mov     w1, wzr                                    
02d6a794: b       #0x2d664c4                                 Clicker.CategoryButton::SetSelected
02d6a798: str     x30, [sp, #-0x10]!                         
02d6a79c: bl      #0x2b7105c                                 fn_2b7105c
## <ShowListDecorOnTop>b__22_0(Clicker.DecorKeycapUIItem x) -> void
---- Clicker.DecorKeycapPanel/<>c::<ShowListDecorOnTop>b__22_0 0x2d6a7a0
02d6a7a0: stp     x30, x19, [sp, #-0x10]!                    
02d6a7a4: cbz     x1, #0x2d6a7d4                             
02d6a7a8: mov     x19, x1                                    
02d6a7ac: mov     x0, x1                                     
02d6a7b0: mov     x1, xzr                                    
02d6a7b4: bl      #0x5b339ec                                 UnityEngine.Component::get_gameObject
02d6a7b8: cbz     x0, #0x2d6a7d4                             
02d6a7bc: ldr     w8, [x19, #0x78]                           
02d6a7c0: mov     x2, xzr                                    
02d6a7c4: cmp     w8, #1                                     
02d6a7c8: cset    w1, eq                                     
02d6a7cc: ldp     x30, x19, [sp], #0x10                      
02d6a7d0: b       #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d6a7d4: bl      #0x2b7105c                                 fn_2b7105c
## <ShowListDecorReplace>b__23_0(Clicker.DecorKeycapUIItem x) -> void
---- Clicker.DecorKeycapPanel/<>c::<ShowListDecorReplace>b__23_0 0x2d6a7d8
02d6a7d8: stp     x30, x19, [sp, #-0x10]!                    
02d6a7dc: cbz     x1, #0x2d6a810                             
02d6a7e0: mov     x19, x1                                    
02d6a7e4: mov     x0, x1                                     
02d6a7e8: mov     x1, xzr                                    
02d6a7ec: bl      #0x5b339ec                                 UnityEngine.Component::get_gameObject
02d6a7f0: cbz     x0, #0x2d6a810                             
02d6a7f4: ldr     w8, [x19, #0x78]                           
02d6a7f8: mov     x2, xzr                                    
02d6a7fc: cmp     w8, #2                                     
02d6a800: ccmp    w8, #4, #4, ne                             
02d6a804: cset    w1, eq                                     
02d6a808: ldp     x30, x19, [sp], #0x10                      
02d6a80c: b       #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d6a810: bl      #0x2b7105c                                 fn_2b7105c
## <DeselectAll>b__24_0(Clicker.DecorKeycapUIItem item) -> void
---- Clicker.DecorKeycapPanel/<>c::<DeselectAll>b__24_0 0x2d6a814
02d6a814: stp     x30, x19, [sp, #-0x10]!                    
02d6a818: cbz     x1, #0x2d6a85c                             
02d6a81c: mov     x19, x1                                    
02d6a820: mov     x0, x1                                     
02d6a824: mov     x1, xzr                                    
02d6a828: bl      #0x5b339ec                                 UnityEngine.Component::get_gameObject
02d6a82c: cbz     x0, #0x2d6a85c                             
02d6a830: mov     x1, xzr                                    
02d6a834: bl      #0x5b36bfc                                 UnityEngine.GameObject::get_activeSelf
02d6a838: tbz     w0, #0, #0x2d6a854                         
02d6a83c: ldr     x8, [x19]                                  
02d6a840: mov     x0, x19                                    
02d6a844: mov     w1, wzr                                    
02d6a848: ldp     x3, x2, [x8, #0x188]                       
02d6a84c: ldp     x30, x19, [sp], #0x10                      
02d6a850: br      x3                                         
02d6a854: ldp     x30, x19, [sp], #0x10                      
02d6a858: ret                                                
02d6a85c: bl      #0x2b7105c                                 fn_2b7105c
#### CLASS Clicker.DecorKeycapPanel/<>c__DisplayClass17_0 parent= object
#   field dataUser                       DataUser                                           off=0x10 attr=6 
#   field <>4__this                      Clicker.DecorKeycapPanel                           off=0x18 attr=6 
## .ctor() -> void
---- Clicker.DecorKeycapPanel/<>c__DisplayClass17_0::.ctor 0x2d69b7c
02d69b7c: mov     x1, xzr                                    
02d69b80: b       #0x4e53e9c                                 System.Object::.ctor
#### CLASS Clicker.DecorKeycapPanel/<>c__DisplayClass17_1 parent= object
#   field configData                     Clicker.DecorKeycapItemData                        off=0x10 attr=6 
#   field CS$<>8__locals1                Clicker.DecorKeycapPanel/<>c__DisplayClass17_0     off=0x18 attr=6 
## .ctor() -> void
---- Clicker.DecorKeycapPanel/<>c__DisplayClass17_1::.ctor 0x2d69b84
02d69b84: mov     x1, xzr                                    
02d69b88: b       #0x4e53e9c                                 System.Object::.ctor
## <LoadData>b__0(int id) -> void
---- Clicker.DecorKeycapPanel/<>c__DisplayClass17_1::<LoadData>b__0 0x2d6a860
02d6a860: stp     x30, x21, [sp, #-0x20]!                    
02d6a864: stp     x20, x19, [sp, #0x10]                      
02d6a868: adrp    x21, #0x6630000                            
02d6a86c: mov     w20, w1                                    
02d6a870: mov     x19, x0                                    
02d6a874: ldrb    w8, [x21, #0x359]                          
02d6a878: tbnz    w8, #0, #0x2d6a890                         
02d6a87c: adrp    x0, #0x626b000                             
02d6a880: ldr     x0, [x0, #0xee0]                           MS:MonoSingleton`1::get_Instance
02d6a884: bl      #0x2b70db0                                 fn_2b70db0
02d6a888: mov     w8, #1                                     
02d6a88c: strb    w8, [x21, #0x359]                          
02d6a890: ldr     x8, [x19, #0x18]                           .CS$<>8__locals1
02d6a894: cbz     x8, #0x2d6a968                             
02d6a898: ldr     x0, [x8, #0x10]                            
02d6a89c: cbz     x0, #0x2d6a968                             
02d6a8a0: adrp    x21, #0x626b000                            
02d6a8a4: mov     w1, w20                                    
02d6a8a8: mov     x2, xzr                                    
02d6a8ac: ldr     x21, [x21, #0xee0]                         MS:MonoSingleton`1::get_Instance
02d6a8b0: bl      #0x2cabc2c                                 DataUser::UnlockClickerDecor
02d6a8b4: ldr     x0, [x21]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d6a8b8: bl      #0x3769600                                 fn_3769600
02d6a8bc: ldr     x8, [x19, #0x10]                           .configData
02d6a8c0: cbz     x8, #0x2d6a968                             
02d6a8c4: cbz     x0, #0x2d6a968                             
02d6a8c8: ldr     w3, [x8, #0x20]                            
02d6a8cc: ldr     x2, [x8, #0x28]                            
02d6a8d0: ldr     w1, [x8, #0x10]                            
02d6a8d4: bl      #0x2d6a96c                                 Clicker.KeycapMakerController::SetKeycapDecor
02d6a8d8: ldr     x8, [x19, #0x18]                           .CS$<>8__locals1
02d6a8dc: cbz     x8, #0x2d6a968                             
02d6a8e0: ldr     x8, [x8, #0x18]                            
02d6a8e4: cbz     x8, #0x2d6a968                             
02d6a8e8: ldr     x0, [x8, #0x80]                            
02d6a8ec: cbz     x0, #0x2d6a968                             
02d6a8f0: mov     w1, #1                                     
02d6a8f4: bl      #0x2d6519c                                 Clicker.IngameClickerScreen::ShowBtnNext
02d6a8f8: ldr     x8, [x19, #0x18]                           .CS$<>8__locals1
02d6a8fc: cbz     x8, #0x2d6a968                             
02d6a900: ldr     x0, [x8, #0x18]                            
02d6a904: cbz     x0, #0x2d6a968                             
02d6a908: mov     w1, w20                                    
02d6a90c: bl      #0x2d69b8c                                 Clicker.DecorKeycapPanel::OnItemSelect
02d6a910: ldr     x8, [x19, #0x18]                           .CS$<>8__locals1
02d6a914: cbz     x8, #0x2d6a968                             
02d6a918: ldr     x0, [x8, #0x18]                            
02d6a91c: cbz     x0, #0x2d6a968                             
02d6a920: bl      #0x2d6a038                                 Clicker.DecorKeycapPanel::DeselectAll
02d6a924: ldr     x0, [x21]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d6a928: bl      #0x3769600                                 fn_3769600
02d6a92c: cbz     x0, #0x2d6a968                             
02d6a930: ldr     x0, [x0, #0xa0]                            S:'scoop_get_reward'
02d6a934: cbz     x0, #0x2d6a968                             
02d6a938: bl      #0x2d5f3ec                                 Clicker.BaseKeycapObject::JumpToNextKeycap
02d6a93c: ldr     x8, [x19, #0x18]                           .CS$<>8__locals1
02d6a940: cbz     x8, #0x2d6a968                             
02d6a944: ldr     x8, [x8, #0x18]                            
02d6a948: cbz     x8, #0x2d6a968                             
02d6a94c: ldr     x0, [x8, #0x80]                            
02d6a950: mov     w9, #1                                     
02d6a954: strb    w9, [x8, #0x88]                            
02d6a958: cbz     x0, #0x2d6a968                             
02d6a95c: ldp     x20, x19, [sp, #0x10]                      
02d6a960: ldp     x30, x21, [sp], #0x20                      
02d6a964: b       #0x2d6a9a4                                 Clicker.IngameClickerScreen::HideTutorial
02d6a968: bl      #0x2b7105c                                 fn_2b7105c
#### CLASS Clicker.DecorKeycapPanel/<>c__DisplayClass18_0 parent= object
#   field id                             int                                                off=0x10 attr=6 
## .ctor() -> void
---- Clicker.DecorKeycapPanel/<>c__DisplayClass18_0::.ctor 0x2d69c64
02d69c64: mov     x1, xzr                                    
02d69c68: b       #0x4e53e9c                                 System.Object::.ctor
## <OnItemSelect>b__0(Clicker.DecorKeycapUIItem item) -> void
---- Clicker.DecorKeycapPanel/<>c__DisplayClass18_0::<OnItemSelect>b__0 0x2d6a9d0
02d6a9d0: str     x30, [sp, #-0x20]!                         
02d6a9d4: stp     x20, x19, [sp, #0x10]                      
02d6a9d8: cbz     x1, #0x2d6aa34                             
02d6a9dc: mov     x19, x1                                    
02d6a9e0: mov     x20, x0                                    
02d6a9e4: mov     x0, x1                                     
02d6a9e8: mov     x1, xzr                                    
02d6a9ec: bl      #0x5b339ec                                 UnityEngine.Component::get_gameObject
02d6a9f0: cbz     x0, #0x2d6aa34                             
02d6a9f4: mov     x1, xzr                                    
02d6a9f8: bl      #0x5b36bfc                                 UnityEngine.GameObject::get_activeSelf
02d6a9fc: tbz     w0, #0, #0x2d6aa28                         
02d6aa00: ldr     x10, [x19]                                 
02d6aa04: ldr     w8, [x19, #0x6c]                           
02d6aa08: mov     x0, x19                                    
02d6aa0c: ldr     w9, [x20, #0x10]                           .id
02d6aa10: ldp     x20, x19, [sp, #0x10]                      
02d6aa14: ldp     x3, x2, [x10, #0x188]                      
02d6aa18: cmp     w8, w9                                     
02d6aa1c: cset    w1, eq                                     
02d6aa20: ldr     x30, [sp], #0x20                           
02d6aa24: br      x3                                         
02d6aa28: ldp     x20, x19, [sp, #0x10]                      
02d6aa2c: ldr     x30, [sp], #0x20                           
02d6aa30: ret                                                
02d6aa34: bl      #0x2b7105c                                 fn_2b7105c
#### CLASS Clicker.DecorKeycapPanel parent= UnityEngine.MonoBehaviour
#   field _decorKeycapUIItem             Clicker.DecorKeycapUIItem                          off=0x20 attr=1 SerializeField
#   field _listItem                      System.Collections.Generic.List`1<Clicker.DecorKeycapUIItem> off=0x28 attr=1 SerializeField
#   field _configDecor                   Clicker.DecorKeycapConfig                          off=0x30 attr=1 SerializeField
#   field _rtShowPos                     UnityEngine.RectTransform                          off=0x38 attr=1 SerializeField
#   field _rtHidePos                     UnityEngine.RectTransform                          off=0x40 attr=1 SerializeField
#   field _thisPanelRect                 UnityEngine.RectTransform                          off=0x48 attr=1 SerializeField
#   field _btnNextPos                    UnityEngine.Transform                              off=0x50 attr=1 SerializeField
#   field _scrollRect                    UnityEngine.UI.ScrollRect                          off=0x58 attr=1 SerializeField
#   field _listCategoryBtn               System.Collections.Generic.List`1<Clicker.CategoryButton> off=0x60 attr=1 HeaderAttribute,SerializeField
#   field _btnCharm                      Clicker.CategoryButton                             off=0x68 attr=1 SerializeField
#   field _btnReplace                    Clicker.CategoryButton                             off=0x70 attr=1 SerializeField
#   field _btnPaint                      Clicker.CategoryButton                             off=0x78 attr=1 SerializeField
#   field _ingameClickerScreen           Clicker.IngameClickerScreen                        off=0x80 attr=1 
#   field _tutorialShown                 bool                                               off=0x88 attr=1 
## Init(Clicker.IngameClickerScreen ingameClickerScreen) -> void
---- Clicker.DecorKeycapPanel::Init 0x2d68ffc
02d68ffc: str     x1, [x0, #0x80]!                           ._ingameClickerScreen
02d69000: b       #0x2b70d54                                 
## Awake() -> void
---- Clicker.DecorKeycapPanel::Awake 0x2d69004
02d69004: str     x30, [sp, #-0x30]!                         
02d69008: stp     x22, x21, [sp, #0x10]                      
02d6900c: stp     x20, x19, [sp, #0x20]                      
02d69010: adrp    x20, #0x6630000                            
02d69014: mov     x19, x0                                    
02d69018: ldrb    w8, [x20, #0x34c]                          
02d6901c: tbnz    w8, #0, #0x2d69058                         
02d69020: adrp    x0, #0x626c000                             
02d69024: ldr     x0, [x0, #0x2e8]                           M:Clicker.DecorKeycapPanel::OnDecorOnTopCategoryClick
02d69028: bl      #0x2b70db0                                 fn_2b70db0
02d6902c: adrp    x0, #0x626c000                             
02d69030: ldr     x0, [x0, #0x2f0]                           M:Clicker.DecorKeycapPanel::OnDecorPaintCategoryClick
02d69034: bl      #0x2b70db0                                 fn_2b70db0
02d69038: adrp    x0, #0x626c000                             
02d6903c: ldr     x0, [x0, #0x2f8]                           M:Clicker.DecorKeycapPanel::OnDecorReplaceCategoryClick
02d69040: bl      #0x2b70db0                                 fn_2b70db0
02d69044: adrp    x0, #0x6265000                             
02d69048: ldr     x0, [x0, #0x3f0]                           T:UnityEngine.Events.UnityAction
02d6904c: bl      #0x2b70db0                                 fn_2b70db0
02d69050: mov     w8, #1                                     
02d69054: strb    w8, [x20, #0x34c]                          
02d69058: ldr     x0, [x19, #0x40]                           ._rtHidePos
02d6905c: cbz     x0, #0x2d691fc                             
02d69060: ldr     x20, [x19, #0x48]                          ._thisPanelRect
02d69064: mov     x1, xzr                                    
02d69068: bl      #0x5b45734                                 UnityEngine.RectTransform::get_anchoredPosition
02d6906c: cbz     x20, #0x2d691fc                            
02d69070: mov     x0, x20                                    
02d69074: mov     x1, xzr                                    
02d69078: bl      #0x5b45800                                 UnityEngine.RectTransform::set_anchoredPosition
02d6907c: ldr     x0, [x19, #0x48]                           ._thisPanelRect
02d69080: cbz     x0, #0x2d691fc                             
02d69084: mov     x1, xzr                                    
02d69088: bl      #0x5b339ec                                 UnityEngine.Component::get_gameObject
02d6908c: cbz     x0, #0x2d691fc                             
02d69090: mov     w1, wzr                                    
02d69094: mov     x2, xzr                                    
02d69098: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d6909c: ldr     x8, [x19, #0x68]                           ._btnCharm
02d690a0: cbz     x8, #0x2d691fc                             
02d690a4: ldr     x8, [x8, #0x30]                            
02d690a8: cbz     x8, #0x2d691fc                             
02d690ac: ldr     x0, [x8, #0x100]                           
02d690b0: cbz     x0, #0x2d691fc                             
02d690b4: mov     x1, xzr                                    
02d690b8: bl      #0x5b4ce48                                 UnityEngine.Events.UnityEventBase::RemoveAllListeners
02d690bc: ldr     x8, [x19, #0x68]                           ._btnCharm
02d690c0: cbz     x8, #0x2d691fc                             
02d690c4: ldr     x8, [x8, #0x30]                            
02d690c8: cbz     x8, #0x2d691fc                             
02d690cc: adrp    x22, #0x6265000                            
02d690d0: adrp    x21, #0x626c000                            
02d690d4: ldr     x22, [x22, #0x3f0]                         T:UnityEngine.Events.UnityAction
02d690d8: ldr     x21, [x21, #0x2e8]                         M:Clicker.DecorKeycapPanel::OnDecorOnTopCategoryClick
02d690dc: ldr     x20, [x8, #0x100]                          
02d690e0: ldr     x0, [x22]                                  M:AdsManager::<OnApplicationPause>b__26_0
02d690e4: bl      #0x2b7104c                                 fn_2b7104c
02d690e8: ldr     x2, [x21]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d690ec: mov     x1, x19                                    
02d690f0: mov     x3, xzr                                    
02d690f4: mov     x21, x0                                    
02d690f8: bl      #0x5b4cf98                                 UnityEngine.Events.UnityAction::.ctor
02d690fc: cbz     x20, #0x2d691fc                            
02d69100: mov     x0, x20                                    
02d69104: mov     x1, x21                                    
02d69108: mov     x2, xzr                                    
02d6910c: bl      #0x5b4d0ac                                 UnityEngine.Events.UnityEvent::AddListener
02d69110: ldr     x8, [x19, #0x70]                           ._btnReplace
02d69114: cbz     x8, #0x2d691fc                             
02d69118: ldr     x8, [x8, #0x30]                            
02d6911c: cbz     x8, #0x2d691fc                             
02d69120: ldr     x0, [x8, #0x100]                           
02d69124: cbz     x0, #0x2d691fc                             
02d69128: mov     x1, xzr                                    
02d6912c: bl      #0x5b4ce48                                 UnityEngine.Events.UnityEventBase::RemoveAllListeners
02d69130: ldr     x8, [x19, #0x70]                           ._btnReplace
02d69134: cbz     x8, #0x2d691fc                             
02d69138: ldr     x8, [x8, #0x30]                            
02d6913c: cbz     x8, #0x2d691fc                             
02d69140: adrp    x21, #0x626c000                            
02d69144: ldr     x21, [x21, #0x2f8]                         M:Clicker.DecorKeycapPanel::OnDecorReplaceCategoryClick
02d69148: ldr     x0, [x22]                                  M:AdsManager::<OnApplicationPause>b__26_0
02d6914c: ldr     x20, [x8, #0x100]                          
02d69150: bl      #0x2b7104c                                 fn_2b7104c
02d69154: ldr     x2, [x21]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d69158: mov     x1, x19                                    
02d6915c: mov     x3, xzr                                    
02d69160: mov     x21, x0                                    
02d69164: bl      #0x5b4cf98                                 UnityEngine.Events.UnityAction::.ctor
02d69168: cbz     x20, #0x2d691fc                            
02d6916c: mov     x0, x20                                    
02d69170: mov     x1, x21                                    
02d69174: mov     x2, xzr                                    
02d69178: bl      #0x5b4d0ac                                 UnityEngine.Events.UnityEvent::AddListener
02d6917c: ldr     x8, [x19, #0x78]                           ._btnPaint
02d69180: cbz     x8, #0x2d691fc                             
02d69184: ldr     x8, [x8, #0x30]                            
02d69188: cbz     x8, #0x2d691fc                             
02d6918c: ldr     x0, [x8, #0x100]                           
02d69190: cbz     x0, #0x2d691fc                             
02d69194: mov     x1, xzr                                    
02d69198: bl      #0x5b4ce48                                 UnityEngine.Events.UnityEventBase::RemoveAllListeners
02d6919c: ldr     x8, [x19, #0x78]                           ._btnPaint
02d691a0: cbz     x8, #0x2d691fc                             
02d691a4: ldr     x8, [x8, #0x30]                            
02d691a8: cbz     x8, #0x2d691fc                             
02d691ac: adrp    x21, #0x626c000                            
02d691b0: ldr     x21, [x21, #0x2f0]                         M:Clicker.DecorKeycapPanel::OnDecorPaintCategoryClick
02d691b4: ldr     x0, [x22]                                  M:AdsManager::<OnApplicationPause>b__26_0
02d691b8: ldr     x20, [x8, #0x100]                          
02d691bc: bl      #0x2b7104c                                 fn_2b7104c
02d691c0: ldr     x2, [x21]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d691c4: mov     x1, x19                                    
02d691c8: mov     x3, xzr                                    
02d691cc: mov     x21, x0                                    
02d691d0: bl      #0x5b4cf98                                 UnityEngine.Events.UnityAction::.ctor
02d691d4: cbz     x20, #0x2d691fc                            
02d691d8: mov     x0, x20                                    
02d691dc: mov     x1, x21                                    
02d691e0: mov     x2, xzr                                    
02d691e4: bl      #0x5b4d0ac                                 UnityEngine.Events.UnityEvent::AddListener
02d691e8: mov     x0, x19                                    
02d691ec: ldp     x20, x19, [sp, #0x20]                      
02d691f0: ldp     x22, x21, [sp, #0x10]                      
02d691f4: ldr     x30, [sp], #0x30                           
02d691f8: b       #0x2d69200                                 Clicker.DecorKeycapPanel::LoadData
02d691fc: bl      #0x2b7105c                                 fn_2b7105c
## ShowPanel() -> void
---- Clicker.DecorKeycapPanel::ShowPanel 0x2d696bc
02d696bc: str     x30, [sp, #-0x50]!                         
02d696c0: stp     x26, x25, [sp, #0x10]                      
02d696c4: stp     x24, x23, [sp, #0x20]                      
02d696c8: stp     x22, x21, [sp, #0x30]                      
02d696cc: stp     x20, x19, [sp, #0x40]                      
02d696d0: adrp    x20, #0x6630000                            
02d696d4: mov     x19, x0                                    
02d696d8: ldrb    w8, [x20, #0x34d]                          
02d696dc: tbnz    w8, #0, #0x2d69760                         
02d696e0: adrp    x0, #0x626c000                             
02d696e4: ldr     x0, [x0, #0x338]                           T:type53119(k15)
02d696e8: bl      #0x2b70db0                                 fn_2b70db0
02d696ec: adrp    x0, #0x6264000                             
02d696f0: ldr     x0, [x0, #0xf90]                           T:System.Action
02d696f4: bl      #0x2b70db0                                 fn_2b70db0
02d696f8: adrp    x0, #0x626c000                             
02d696fc: ldr     x0, [x0, #0x340]                           M:Clicker.DecorKeycapPanel::<ShowPanel>b__16_0
02d69700: bl      #0x2b70db0                                 fn_2b70db0
02d69704: adrp    x0, #0x626c000                             
02d69708: ldr     x0, [x0, #0x348]                           M:Clicker.DecorKeycapPanel::<ShowPanel>b__16_1
02d6970c: bl      #0x2b70db0                                 fn_2b70db0
02d69710: adrp    x0, #0x626c000                             
02d69714: ldr     x0, [x0, #0x350]                           MS:System.Collections.Generic.List`1::ForEach
02d69718: bl      #0x2b70db0                                 fn_2b70db0
02d6971c: adrp    x0, #0x6264000                             
02d69720: ldr     x0, [x0, #0xe8]                            T:DG.Tweening.TweenCallback
02d69724: bl      #0x2b70db0                                 fn_2b70db0
02d69728: adrp    x0, #0x6266000                             
02d6972c: ldr     x0, [x0, #0xa08]                           MS:DG.Tweening.TweenSettingsExtensions::OnComplete
02d69730: bl      #0x2b70db0                                 fn_2b70db0
02d69734: adrp    x0, #0x6266000                             
02d69738: ldr     x0, [x0, #0xa18]                           MS:DG.Tweening.TweenSettingsExtensions::SetEase
02d6973c: bl      #0x2b70db0                                 fn_2b70db0
02d69740: adrp    x0, #0x626c000                             
02d69744: ldr     x0, [x0, #0x358]                           M:Clicker.DecorKeycapPanel/<>c::<ShowPanel>b__16_2
02d69748: bl      #0x2b70db0                                 fn_2b70db0
02d6974c: adrp    x0, #0x626c000                             
02d69750: ldr     x0, [x0, #0x360]                           T:Clicker.DecorKeycapPanel/<>c
02d69754: bl      #0x2b70db0                                 fn_2b70db0
02d69758: mov     w8, #1                                     
02d6975c: strb    w8, [x20, #0x34d]                          
02d69760: ldr     x0, [x19, #0x48]                           ._thisPanelRect
02d69764: cbz     x0, #0x2d69944                             
02d69768: mov     x1, xzr                                    
02d6976c: bl      #0x5b339ec                                 UnityEngine.Component::get_gameObject
02d69770: cbz     x0, #0x2d69944                             
02d69774: mov     w1, #1                                     
02d69778: mov     x2, xzr                                    
02d6977c: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d69780: ldr     x0, [x19, #0x38]                           ._rtShowPos
02d69784: cbz     x0, #0x2d69944                             
02d69788: adrp    x21, #0x6266000                            
02d6978c: adrp    x23, #0x6264000                            
02d69790: adrp    x24, #0x626c000                            
02d69794: adrp    x25, #0x6266000                            
02d69798: adrp    x26, #0x6264000                            
02d6979c: adrp    x22, #0x626c000                            
02d697a0: ldr     x21, [x21, #0xa18]                         MS:DG.Tweening.TweenSettingsExtensions::SetEase
02d697a4: ldr     x23, [x23, #0xe8]                          T:DG.Tweening.TweenCallback
02d697a8: ldr     x24, [x24, #0x340]                         M:Clicker.DecorKeycapPanel::<ShowPanel>b__16_0
02d697ac: ldr     x25, [x25, #0xa08]                         MS:DG.Tweening.TweenSettingsExtensions::OnComplete
02d697b0: ldr     x26, [x26, #0xf90]                         T:System.Action
02d697b4: ldr     x22, [x22, #0x348]                         M:Clicker.DecorKeycapPanel::<ShowPanel>b__16_1
02d697b8: ldr     x20, [x19, #0x48]                          ._thisPanelRect
02d697bc: mov     x1, xzr                                    
02d697c0: bl      #0x5b45734                                 UnityEngine.RectTransform::get_anchoredPosition
02d697c4: fmov    s2, #0.50000000                            
02d697c8: mov     x0, x20                                    
02d697cc: mov     w1, wzr                                    
02d697d0: mov     x2, xzr                                    
02d697d4: bl      #0x2c798bc                                 DG.Tweening.DOTweenModuleUI::DOAnchorPos
02d697d8: ldr     x2, [x21]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d697dc: mov     w1, #3                                     
02d697e0: bl      #0x336fa0c                                 fn_336fa0c
02d697e4: ldr     x8, [x23]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d697e8: mov     x20, x0                                    
02d697ec: mov     x0, x8                                     
02d697f0: bl      #0x2b7104c                                 fn_2b7104c
02d697f4: ldr     x2, [x24]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d697f8: mov     x1, x19                                    
02d697fc: mov     x3, xzr                                    
02d69800: mov     x21, x0                                    
02d69804: bl      #0x2d89dc4                                 DG.Tweening.TweenCallback::.ctor
02d69808: ldr     x2, [x25]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d6980c: mov     x0, x20                                    
02d69810: mov     x1, x21                                    
02d69814: bl      #0x336f26c                                 fn_336f26c
02d69818: ldr     x0, [x26]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d6981c: ldr     x20, [x19, #0x80]                          ._ingameClickerScreen
02d69820: bl      #0x2b7104c                                 fn_2b7104c
02d69824: ldr     x2, [x22]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d69828: mov     x1, x19                                    
02d6982c: mov     x3, xzr                                    
02d69830: mov     x21, x0                                    
02d69834: bl      #0x4d8ddbc                                 System.Action::.ctor
02d69838: cbz     x20, #0x2d69944                            
02d6983c: mov     x0, x20                                    
02d69840: mov     x1, x21                                    
02d69844: bl      #0x2d69948                                 Clicker.IngameClickerScreen::RegisterButtonNextEvent
02d69848: ldr     x0, [x19, #0x50]                           ._btnNextPos
02d6984c: cbz     x0, #0x2d69944                             
02d69850: ldr     x20, [x19, #0x80]                          ._ingameClickerScreen
02d69854: mov     x1, xzr                                    
02d69858: bl      #0x5b467ac                                 UnityEngine.Transform::get_position
02d6985c: cbz     x20, #0x2d69944                            
02d69860: mov     x0, x20                                    
02d69864: bl      #0x2d69a28                                 Clicker.IngameClickerScreen::SetBtnNextPosition
02d69868: ldr     x0, [x19, #0x80]                           ._ingameClickerScreen
02d6986c: cbz     x0, #0x2d69944                             
02d69870: adrp    x23, #0x626c000                            
02d69874: mov     w1, #1                                     
02d69878: ldr     x23, [x23, #0x360]                         T:Clicker.DecorKeycapPanel/<>c
02d6987c: bl      #0x2d6519c                                 Clicker.IngameClickerScreen::ShowBtnNext
02d69880: ldr     x0, [x23]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d69884: ldr     x20, [x19, #0x60]                          ._listCategoryBtn
02d69888: ldr     w8, [x0, #0xe4]                            [626c0e4]=0 f=0,0
02d6988c: cbnz    w8, #0x2d69898                             
02d69890: bl      #0x2b70f30                                 fn_2b70f30
02d69894: ldr     x0, [x23]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d69898: ldr     x8, [x0, #0xb8]                            MS:System.Collections.Generic.List`1::Add
02d6989c: ldr     x21, [x8, #8]                              
02d698a0: cbnz    x21, #0x2d698fc                            
02d698a4: ldr     w9, [x0, #0xe4]                            [626c0e4]=0 f=0,0
02d698a8: cbnz    w9, #0x2d698b8                             
02d698ac: bl      #0x2b70f30                                 fn_2b70f30
02d698b0: ldr     x8, [x23]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d698b4: ldr     x8, [x8, #0xb8]                            
02d698b8: adrp    x9, #0x626c000                             
02d698bc: ldr     x9, [x9, #0x338]                           T:type53119(k15)
02d698c0: ldr     x22, [x8]                                  
02d698c4: ldr     x0, [x9]                                   M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d698c8: bl      #0x2b7104c                                 fn_2b7104c
02d698cc: adrp    x8, #0x626c000                             
02d698d0: mov     x1, x22                                    
02d698d4: mov     x3, xzr                                    
02d698d8: ldr     x8, [x8, #0x358]                           M:Clicker.DecorKeycapPanel/<>c::<ShowPanel>b__16_2
02d698dc: mov     x21, x0                                    
02d698e0: ldr     x2, [x8]                                   M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d698e4: bl      #0x453418c                                 fn_453418c
02d698e8: ldr     x8, [x23]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d698ec: mov     x1, x21                                    
02d698f0: ldr     x0, [x8, #0xb8]                            MS:System.Collections.Generic.List`1::Add
02d698f4: str     x21, [x0, #8]!                             
02d698f8: bl      #0x2b70d54                                 fn_2b70d54
02d698fc: cbz     x20, #0x2d69944                            
02d69900: adrp    x8, #0x626c000                             
02d69904: mov     x0, x20                                    
02d69908: mov     x1, x21                                    
02d6990c: ldr     x8, [x8, #0x350]                           MS:System.Collections.Generic.List`1::ForEach
02d69910: ldr     x2, [x8]                                   M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d69914: bl      #0x35a9ce4                                 fn_35a9ce4
02d69918: ldr     x0, [x19, #0x68]                           ._btnCharm
02d6991c: cbz     x0, #0x2d69944                             
02d69920: mov     w1, #1                                     
02d69924: bl      #0x2d664c4                                 Clicker.CategoryButton::SetSelected
02d69928: mov     x0, x19                                    
02d6992c: ldp     x20, x19, [sp, #0x40]                      
02d69930: ldp     x22, x21, [sp, #0x30]                      
02d69934: ldp     x24, x23, [sp, #0x20]                      
02d69938: ldp     x26, x25, [sp, #0x10]                      
02d6993c: ldr     x30, [sp], #0x50                           
02d69940: b       #0x2d69a78                                 Clicker.DecorKeycapPanel::ShowListDecorOnTop
02d69944: bl      #0x2b7105c                                 fn_2b7105c
## LoadData() -> void
---- Clicker.DecorKeycapPanel::LoadData 0x2d69200
02d69200: stp     x29, x30, [sp, #-0x60]!                    
02d69204: stp     x28, x27, [sp, #0x10]                      
02d69208: stp     x26, x25, [sp, #0x20]                      
02d6920c: stp     x24, x23, [sp, #0x30]                      
02d69210: stp     x22, x21, [sp, #0x40]                      
02d69214: stp     x20, x19, [sp, #0x50]                      
02d69218: adrp    x20, #0x6630000                            
02d6921c: adrp    x21, #0x626c000                            
02d69220: mov     x19, x0                                    
02d69224: ldrb    w8, [x20, #0x34e]                          
02d69228: ldr     x21, [x21, #0x300]                         T:Clicker.DecorKeycapPanel/<>c__DisplayClass17_0
02d6922c: tbnz    w8, #0, #0x2d692bc                         
02d69230: adrp    x0, #0x6269000                             
02d69234: ldr     x0, [x0, #0x5e8]                           T:type6940(k15)
02d69238: bl      #0x2b70db0                                 fn_2b70db0
02d6923c: adrp    x0, #0x6266000                             
02d69240: ldr     x0, [x0, #0x750]                           MS:DataManager::GetData
02d69244: bl      #0x2b70db0                                 fn_2b70db0
02d69248: adrp    x0, #0x626c000                             
02d6924c: ldr     x0, [x0, #0x308]                           MS:System.Collections.Generic.List`1::Add
02d69250: bl      #0x2b70db0                                 fn_2b70db0
02d69254: adrp    x0, #0x626c000                             
02d69258: ldr     x0, [x0, #0x310]                           MS:System.Collections.Generic.List`1::get_Count
02d6925c: bl      #0x2b70db0                                 fn_2b70db0
02d69260: adrp    x0, #0x626c000                             
02d69264: ldr     x0, [x0, #0x318]                           MS:System.Collections.Generic.List`1::get_Item
02d69268: bl      #0x2b70db0                                 fn_2b70db0
02d6926c: adrp    x0, #0x6266000                             
02d69270: ldr     x0, [x0, #0x658]                           MS:MonoSingleton`1::get_Instance
02d69274: bl      #0x2b70db0                                 fn_2b70db0
02d69278: adrp    x0, #0x626c000                             
02d6927c: ldr     x0, [x0, #0x320]                           MS:UnityEngine.Object::Instantiate
02d69280: bl      #0x2b70db0                                 fn_2b70db0
02d69284: adrp    x0, #0x6263000                             
02d69288: ldr     x0, [x0, #0x918]                           T:UnityEngine.Object
02d6928c: bl      #0x2b70db0                                 fn_2b70db0
02d69290: adrp    x0, #0x626c000                             
02d69294: ldr     x0, [x0, #0x300]                           T:Clicker.DecorKeycapPanel/<>c__DisplayClass17_0
02d69298: bl      #0x2b70db0                                 fn_2b70db0
02d6929c: adrp    x0, #0x626c000                             
02d692a0: ldr     x0, [x0, #0x328]                           M:Clicker.DecorKeycapPanel/<>c__DisplayClass17_1::<LoadData>b__0
02d692a4: bl      #0x2b70db0                                 fn_2b70db0
02d692a8: adrp    x0, #0x626c000                             
02d692ac: ldr     x0, [x0, #0x330]                           T:Clicker.DecorKeycapPanel/<>c__DisplayClass17_1
02d692b0: bl      #0x2b70db0                                 fn_2b70db0
02d692b4: mov     w8, #1                                     
02d692b8: strb    w8, [x20, #0x34e]                          
02d692bc: ldr     x0, [x21]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d692c0: bl      #0x2b7104c                                 fn_2b7104c
02d692c4: mov     x1, xzr                                    
02d692c8: mov     x20, x0                                    
02d692cc: bl      #0x4e53e9c                                 System.Object::.ctor
02d692d0: cbz     x20, #0x2d6969c                            
02d692d4: mov     x0, x20                                    
02d692d8: mov     x1, x19                                    
02d692dc: str     x19, [x0, #0x18]!                          
02d692e0: bl      #0x2b70d54                                 fn_2b70d54
02d692e4: ldr     x8, [x19, #0x28]                           ._listItem
02d692e8: cbz     x8, #0x2d6969c                             
02d692ec: adrp    x28, #0x626c000                            
02d692f0: adrp    x27, #0x626c000                            
02d692f4: adrp    x29, #0x626c000                            
02d692f8: adrp    x26, #0x6263000                            
02d692fc: adrp    x24, #0x626c000                            
02d69300: adrp    x25, #0x626c000                            
02d69304: ldr     x28, [x28, #0x330]                         T:Clicker.DecorKeycapPanel/<>c__DisplayClass17_1
02d69308: ldr     x27, [x27, #0x318]                         MS:System.Collections.Generic.List`1::get_Item
02d6930c: ldr     x29, [x29, #0x328]                         M:Clicker.DecorKeycapPanel/<>c__DisplayClass17_1::<LoadData>b__0
02d69310: ldr     x26, [x26, #0x918]                         T:UnityEngine.Object
02d69314: ldr     x24, [x24, #0x320]                         MS:UnityEngine.Object::Instantiate
02d69318: ldr     x25, [x25, #0x308]                         MS:System.Collections.Generic.List`1::Add
02d6931c: ldr     x0, [x19, #0x30]                           ._configDecor
02d69320: cbz     x0, #0x2d6969c                             
02d69324: ldr     w21, [x8, #0x18]                           
02d69328: bl      #0x2d5b560                                 Clicker.DecorKeycapConfig::get_Count
02d6932c: cmp     w21, w0                                    
02d69330: b.ge    #0x2d693e8                                 
02d69334: ldr     x22, [x19, #0x20]                          ._decorKeycapUIItem
02d69338: cbz     x22, #0x2d6969c                            
02d6933c: ldr     x21, [x19, #0x28]                          ._listItem
02d69340: mov     x0, x22                                    
02d69344: mov     x1, xzr                                    
02d69348: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02d6934c: cbz     x0, #0x2d6969c                             
02d69350: mov     x1, xzr                                    
02d69354: bl      #0x5b466dc                                 UnityEngine.Transform::get_parent
02d69358: ldr     x8, [x26]                                  &2c5bbd4(=a9bd7bfdd503233f)
02d6935c: mov     x23, x0                                    
02d69360: ldr     w9, [x8, #0xe4]                            
02d69364: cbnz    w9, #0x2d69370                             
02d69368: mov     x0, x8                                     
02d6936c: bl      #0x2b70f30                                 fn_2b70f30
02d69370: ldr     x2, [x24]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d69374: mov     x0, x22                                    
02d69378: mov     x1, x23                                    
02d6937c: bl      #0x3275fcc                                 fn_3275fcc
02d69380: cbz     x21, #0x2d6969c                            
02d69384: ldr     w10, [x21, #0x1c]                          [626c01c]=0 f=0,0
02d69388: ldr     x8, [x21, #0x10]                           M:Clicker.GlowSprite2DItem::<DoGlow>b__10_4
02d6938c: ldr     x9, [x25]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d69390: add     w10, w10, #1                               
02d69394: str     w10, [x21, #0x1c]                          
02d69398: cbz     x8, #0x2d6969c                             
02d6939c: ldrsw   x10, [x21, #0x18]                          
02d693a0: ldr     w11, [x8, #0x18]                           
02d693a4: mov     x1, x0                                     
02d693a8: cmp     w10, w11                                   
02d693ac: b.hs    #0x2d693c8                                 
02d693b0: add     x0, x8, x10, lsl #3                        
02d693b4: add     w9, w10, #1                                
02d693b8: str     w9, [x21, #0x18]                           
02d693bc: str     x1, [x0, #0x20]!                           ._decorKeycapUIItem
02d693c0: bl      #0x2b70d54                                 fn_2b70d54
02d693c4: b       #0x2d693dc                                 
02d693c8: ldr     x8, [x9, #0x20]                            
02d693cc: mov     x0, x21                                    
02d693d0: ldr     x8, [x8, #0xc0]                            
02d693d4: ldr     x2, [x8, #0x70]                            
02d693d8: bl      #0x35a920c                                 fn_35a920c
02d693dc: ldr     x8, [x19, #0x28]                           ._listItem
02d693e0: cbnz    x8, #0x2d6931c                             
02d693e4: b       #0x2d6969c                                 
02d693e8: adrp    x8, #0x6266000                             
02d693ec: ldr     x8, [x8, #0x658]                           MS:MonoSingleton`1::get_Instance
02d693f0: ldr     x0, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d693f4: bl      #0x3769600                                 fn_3769600
02d693f8: cbz     x0, #0x2d6969c                             
02d693fc: adrp    x8, #0x6266000                             
02d69400: ldr     x8, [x8, #0x750]                           MS:DataManager::GetData
02d69404: ldr     x1, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d69408: bl      #0x3168dd0                                 fn_3168dd0
02d6940c: mov     x1, x0                                     
02d69410: mov     x0, x20                                    
02d69414: str     x1, [x0, #0x10]!                           
02d69418: bl      #0x2b70d54                                 fn_2b70d54
02d6941c: ldr     x0, [x19, #0x30]                           ._configDecor
02d69420: cbz     x0, #0x2d6969c                             
02d69424: mov     w21, wzr                                   
02d69428: bl      #0x2d5b560                                 Clicker.DecorKeycapConfig::get_Count
02d6942c: cmp     w21, w0                                    
02d69430: b.ge    #0x2d69640                                 
02d69434: ldr     x0, [x28]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d69438: bl      #0x2b7104c                                 fn_2b7104c
02d6943c: mov     x1, xzr                                    
02d69440: mov     x22, x0                                    
02d69444: bl      #0x4e53e9c                                 System.Object::.ctor
02d69448: cbz     x22, #0x2d6969c                            
02d6944c: mov     x24, x22                                   
02d69450: mov     x1, x20                                    
02d69454: str     x20, [x24, #0x18]!                         
02d69458: mov     x0, x24                                    
02d6945c: bl      #0x2b70d54                                 fn_2b70d54
02d69460: ldr     x0, [x19, #0x30]                           ._configDecor
02d69464: cbz     x0, #0x2d6969c                             
02d69468: mov     w1, w21                                    
02d6946c: bl      #0x2d5b618                                 Clicker.DecorKeycapConfig::GetData
02d69470: mov     x23, x22                                   
02d69474: mov     x1, x0                                     
02d69478: str     x0, [x23, #0x10]!                          
02d6947c: mov     x0, x23                                    
02d69480: bl      #0x2b70d54                                 fn_2b70d54
02d69484: ldr     x8, [x23]                                  
02d69488: ldr     x0, [x19, #0x28]                           ._listItem
02d6948c: cbz     x8, #0x2d69540                             
02d69490: cbz     x0, #0x2d6969c                             
02d69494: ldr     x2, [x27]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d69498: mov     w1, w21                                    
02d6949c: bl      #0x35a8f3c                                 fn_35a8f3c
02d694a0: ldr     x8, [x23]                                  
02d694a4: cbz     x8, #0x2d6969c                             
02d694a8: cbz     x0, #0x2d6969c                             
02d694ac: ldr     x9, [x0]                                   M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d694b0: ldr     x2, [x8, #0x18]                            S:'level_show_popuprate'
02d694b4: ldr     w1, [x8, #0x10]                            S:'mrec_ad_on_off'
02d694b8: ldp     x8, x3, [x9, #0x178]                       
02d694bc: blr     x8                                         
02d694c0: ldr     x0, [x19, #0x28]                           ._listItem
02d694c4: cbz     x0, #0x2d6969c                             
02d694c8: ldr     x2, [x27]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d694cc: mov     w1, w21                                    
02d694d0: bl      #0x35a8f3c                                 fn_35a8f3c
02d694d4: ldr     x8, [x23]                                  
02d694d8: cbz     x8, #0x2d6969c                             
02d694dc: cbz     x0, #0x2d6969c                             
02d694e0: ldr     w9, [x8, #0x20]                            S:'inter_ad_capping_time'
02d694e4: ldr     x8, [x19, #0x28]                           ._listItem
02d694e8: str     w9, [x0, #0x78]                            ._btnPaint
02d694ec: cbz     x8, #0x2d6969c                             
02d694f0: ldr     x2, [x27]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d694f4: mov     x0, x8                                     
02d694f8: mov     w1, w21                                    
02d694fc: bl      #0x35a8f3c                                 fn_35a8f3c
02d69500: ldr     x8, [x23]                                  
02d69504: cbz     x8, #0x2d6969c                             
02d69508: ldr     x9, [x8, #0x30]                            S:'popup_rate_on_off'
02d6950c: cbz     x9, #0x2d6969c                             
02d69510: ldr     x10, [x24]                                 M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d69514: cbz     x10, #0x2d6969c                            
02d69518: mov     x25, x0                                    
02d6951c: ldr     x0, [x10, #0x10]                           
02d69520: cbz     x0, #0x2d6969c                             
02d69524: ldp     w24, w26, [x9, #0x10]                      
02d69528: ldr     w1, [x8, #0x10]                            S:'mrec_ad_on_off'
02d6952c: mov     x2, xzr                                    
02d69530: bl      #0x2cabd24                                 DataUser::HasUnlockedKeycapDecor
02d69534: tbz     w0, #0, #0x2d69570                         
02d69538: mov     w3, #1                                     
02d6953c: b       #0x2d6958c                                 
02d69540: cbz     x0, #0x2d6969c                             
02d69544: ldr     x2, [x27]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d69548: mov     w1, w21                                    
02d6954c: bl      #0x35a8f3c                                 fn_35a8f3c
02d69550: cbz     x0, #0x2d6969c                             
02d69554: mov     x1, xzr                                    
02d69558: bl      #0x5b339ec                                 UnityEngine.Component::get_gameObject
02d6955c: cbz     x0, #0x2d6969c                             
02d69560: mov     w1, wzr                                    
02d69564: mov     x2, xzr                                    
02d69568: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d6956c: b       #0x2d69630                                 
02d69570: ldr     x8, [x23]                                  
02d69574: cbz     x8, #0x2d6969c                             
02d69578: ldr     x8, [x8, #0x30]                            S:'popup_rate_on_off'
02d6957c: cbz     x8, #0x2d6969c                             
02d69580: ldr     w8, [x8, #0x10]                            S:'mrec_ad_on_off'
02d69584: cmp     w8, #0                                     
02d69588: cset    w3, eq                                     
02d6958c: cbz     x25, #0x2d6969c                            
02d69590: ldr     x8, [x25]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d69594: mov     x0, x25                                    
02d69598: mov     w1, w24                                    
02d6959c: mov     w2, w26                                    
02d695a0: ldp     x9, x4, [x8, #0x1a8]                       
02d695a4: blr     x9                                         
02d695a8: ldr     x0, [x19, #0x28]                           ._listItem
02d695ac: cbz     x0, #0x2d6969c                             
02d695b0: ldr     x2, [x27]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d695b4: mov     w1, w21                                    
02d695b8: bl      #0x35a8f3c                                 fn_35a8f3c
02d695bc: cbz     x0, #0x2d6969c                             
02d695c0: mov     x1, xzr                                    
02d695c4: bl      #0x5b339ec                                 UnityEngine.Component::get_gameObject
02d695c8: cbz     x0, #0x2d6969c                             
02d695cc: mov     w1, #1                                     
02d695d0: mov     x2, xzr                                    
02d695d4: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d695d8: ldr     x0, [x19, #0x28]                           ._listItem
02d695dc: cbz     x0, #0x2d6969c                             
02d695e0: ldr     x2, [x27]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d695e4: mov     w1, w21                                    
02d695e8: bl      #0x35a8f3c                                 fn_35a8f3c
02d695ec: adrp    x8, #0x6269000                             
02d695f0: mov     x23, x0                                    
02d695f4: ldr     x8, [x8, #0x5e8]                           T:type6940(k15)
02d695f8: ldr     x8, [x8]                                   T:Trading.TradingSession/<>c__DisplayClass56_0
02d695fc: mov     x0, x8                                     
02d69600: bl      #0x2b7104c                                 fn_2b7104c
02d69604: ldr     x2, [x29]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d69608: mov     x1, x22                                    
02d6960c: mov     x3, xzr                                    
02d69610: mov     x24, x0                                    
02d69614: bl      #0x4532eb0                                 fn_4532eb0
02d69618: cbz     x23, #0x2d6969c                            
02d6961c: ldr     x8, [x23]                                  
02d69620: mov     x0, x23                                    
02d69624: mov     x1, x24                                    
02d69628: ldp     x9, x2, [x8, #0x198]                       
02d6962c: blr     x9                                         
02d69630: ldr     x0, [x19, #0x30]                           ._configDecor
02d69634: add     w21, w21, #1                               
02d69638: cbnz    x0, #0x2d69428                             
02d6963c: b       #0x2d6969c                                 
02d69640: ldr     x0, [x19, #0x30]                           ._configDecor
02d69644: cbz     x0, #0x2d6969c                             
02d69648: bl      #0x2d5b560                                 Clicker.DecorKeycapConfig::get_Count
02d6964c: ldr     x8, [x19, #0x28]                           ._listItem
02d69650: cbz     x8, #0x2d6969c                             
02d69654: mov     w20, w0                                    
02d69658: ldr     w9, [x8, #0x18]                            M:Trading.TradingSession::<ValidateTrade>b__57_0
02d6965c: cmp     w20, w9                                    
02d69660: b.ge    #0x2d696a0                                 
02d69664: ldr     x2, [x27]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d69668: mov     x0, x8                                     
02d6966c: mov     w1, w20                                    
02d69670: bl      #0x35a8f3c                                 fn_35a8f3c
02d69674: cbz     x0, #0x2d6969c                             
02d69678: mov     x1, xzr                                    
02d6967c: bl      #0x5b339ec                                 UnityEngine.Component::get_gameObject
02d69680: cbz     x0, #0x2d6969c                             
02d69684: mov     w1, wzr                                    
02d69688: mov     x2, xzr                                    
02d6968c: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d69690: ldr     x8, [x19, #0x28]                           ._listItem
02d69694: add     w20, w20, #1                               
02d69698: cbnz    x8, #0x2d69658                             
02d6969c: bl      #0x2b7105c                                 fn_2b7105c
02d696a0: ldp     x20, x19, [sp, #0x50]                      
02d696a4: ldp     x22, x21, [sp, #0x40]                      
02d696a8: ldp     x24, x23, [sp, #0x30]                      
02d696ac: ldp     x26, x25, [sp, #0x20]                      
02d696b0: ldp     x28, x27, [sp, #0x10]                      
02d696b4: ldp     x29, x30, [sp], #0x60                      
02d696b8: ret                                                
## OnItemSelect(int id) -> void
---- Clicker.DecorKeycapPanel::OnItemSelect 0x2d69b8c
02d69b8c: str     x30, [sp, #-0x30]!                         
02d69b90: stp     x22, x21, [sp, #0x10]                      
02d69b94: stp     x20, x19, [sp, #0x20]                      
02d69b98: adrp    x21, #0x6630000                            
02d69b9c: adrp    x22, #0x626c000                            
02d69ba0: mov     w19, w1                                    
02d69ba4: ldrb    w8, [x21, #0x34f]                          
02d69ba8: ldr     x22, [x22, #0x390]                         T:Clicker.DecorKeycapPanel/<>c__DisplayClass18_0
02d69bac: mov     x20, x0                                    
02d69bb0: tbnz    w8, #0, #0x2d69bec                         
02d69bb4: adrp    x0, #0x626c000                             
02d69bb8: ldr     x0, [x0, #0x378]                           T:type53128(k15)
02d69bbc: bl      #0x2b70db0                                 fn_2b70db0
02d69bc0: adrp    x0, #0x626c000                             
02d69bc4: ldr     x0, [x0, #0x380]                           MS:System.Collections.Generic.List`1::ForEach
02d69bc8: bl      #0x2b70db0                                 fn_2b70db0
02d69bcc: adrp    x0, #0x626c000                             
02d69bd0: ldr     x0, [x0, #0x398]                           M:Clicker.DecorKeycapPanel/<>c__DisplayClass18_0::<OnItemSelect>b__0
02d69bd4: bl      #0x2b70db0                                 fn_2b70db0
02d69bd8: adrp    x0, #0x626c000                             
02d69bdc: ldr     x0, [x0, #0x390]                           T:Clicker.DecorKeycapPanel/<>c__DisplayClass18_0
02d69be0: bl      #0x2b70db0                                 fn_2b70db0
02d69be4: mov     w8, #1                                     
02d69be8: strb    w8, [x21, #0x34f]                          
02d69bec: ldr     x0, [x22]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d69bf0: bl      #0x2b7104c                                 fn_2b7104c
02d69bf4: mov     x1, xzr                                    
02d69bf8: mov     x21, x0                                    
02d69bfc: bl      #0x4e53e9c                                 System.Object::.ctor
02d69c00: cbz     x21, #0x2d69c60                            
02d69c04: adrp    x8, #0x626c000                             
02d69c08: adrp    x22, #0x626c000                            
02d69c0c: ldr     x8, [x8, #0x378]                           T:type53128(k15)
02d69c10: ldr     x22, [x22, #0x398]                         M:Clicker.DecorKeycapPanel/<>c__DisplayClass18_0::<OnItemSelect>b__0
02d69c14: ldr     x20, [x20, #0x28]                          ._listItem
02d69c18: str     w19, [x21, #0x10]                          
02d69c1c: ldr     x0, [x8]                                   M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d69c20: bl      #0x2b7104c                                 fn_2b7104c
02d69c24: ldr     x2, [x22]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d69c28: mov     x1, x21                                    
02d69c2c: mov     x3, xzr                                    
02d69c30: mov     x19, x0                                    
02d69c34: bl      #0x453418c                                 fn_453418c
02d69c38: cbz     x20, #0x2d69c60                            
02d69c3c: adrp    x8, #0x626c000                             
02d69c40: mov     x0, x20                                    
02d69c44: mov     x1, x19                                    
02d69c48: ldr     x8, [x8, #0x380]                           MS:System.Collections.Generic.List`1::ForEach
02d69c4c: ldp     x20, x19, [sp, #0x20]                      
02d69c50: ldp     x22, x21, [sp, #0x10]                      
02d69c54: ldr     x2, [x8]                                   M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d69c58: ldr     x30, [sp], #0x30                           
02d69c5c: b       #0x35a9ce4                                 
02d69c60: bl      #0x2b7105c                                 fn_2b7105c
## OnDecorOnTopCategoryClick() -> void
---- Clicker.DecorKeycapPanel::OnDecorOnTopCategoryClick 0x2d69c6c
02d69c6c: stp     x30, x23, [sp, #-0x30]!                    
02d69c70: stp     x22, x21, [sp, #0x10]                      
02d69c74: stp     x20, x19, [sp, #0x20]                      
02d69c78: adrp    x20, #0x6630000                            
02d69c7c: adrp    x23, #0x626c000                            
02d69c80: mov     x19, x0                                    
02d69c84: ldrb    w8, [x20, #0x350]                          
02d69c88: ldr     x23, [x23, #0x360]                         T:Clicker.DecorKeycapPanel/<>c
02d69c8c: tbnz    w8, #0, #0x2d69cd4                         
02d69c90: adrp    x0, #0x626c000                             
02d69c94: ldr     x0, [x0, #0x338]                           T:type53119(k15)
02d69c98: bl      #0x2b70db0                                 fn_2b70db0
02d69c9c: adrp    x0, #0x626c000                             
02d69ca0: ldr     x0, [x0, #0x350]                           MS:System.Collections.Generic.List`1::ForEach
02d69ca4: bl      #0x2b70db0                                 fn_2b70db0
02d69ca8: adrp    x0, #0x6264000                             
02d69cac: ldr     x0, [x0, #0x108]                           MS:DG.Tweening.TweenSettingsExtensions::SetEase
02d69cb0: bl      #0x2b70db0                                 fn_2b70db0
02d69cb4: adrp    x0, #0x626c000                             
02d69cb8: ldr     x0, [x0, #0x3a0]                           M:Clicker.DecorKeycapPanel/<>c::<OnDecorOnTopCategoryClick>b__19_0
02d69cbc: bl      #0x2b70db0                                 fn_2b70db0
02d69cc0: adrp    x0, #0x626c000                             
02d69cc4: ldr     x0, [x0, #0x360]                           T:Clicker.DecorKeycapPanel/<>c
02d69cc8: bl      #0x2b70db0                                 fn_2b70db0
02d69ccc: mov     w8, #1                                     
02d69cd0: strb    w8, [x20, #0x350]                          
02d69cd4: mov     x0, xzr                                    
02d69cd8: bl      #0x2d6ff04                                 Framework.AudioHelper::PlayClickSound
02d69cdc: ldr     x0, [x23]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d69ce0: ldr     x20, [x19, #0x60]                          ._listCategoryBtn
02d69ce4: ldr     w8, [x0, #0xe4]                            [626c0e4]=0 f=0,0
02d69ce8: cbnz    w8, #0x2d69cf4                             
02d69cec: bl      #0x2b70f30                                 fn_2b70f30
02d69cf0: ldr     x0, [x23]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d69cf4: ldr     x8, [x0, #0xb8]                            MS:System.Collections.Generic.List`1::Add
02d69cf8: ldr     x21, [x8, #0x10]                           
02d69cfc: cbnz    x21, #0x2d69d58                            
02d69d00: ldr     w9, [x0, #0xe4]                            [626c0e4]=0 f=0,0
02d69d04: cbnz    w9, #0x2d69d14                             
02d69d08: bl      #0x2b70f30                                 fn_2b70f30
02d69d0c: ldr     x8, [x23]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d69d10: ldr     x8, [x8, #0xb8]                            
02d69d14: adrp    x9, #0x626c000                             
02d69d18: ldr     x9, [x9, #0x338]                           T:type53119(k15)
02d69d1c: ldr     x22, [x8]                                  
02d69d20: ldr     x0, [x9]                                   M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d69d24: bl      #0x2b7104c                                 fn_2b7104c
02d69d28: adrp    x8, #0x626c000                             
02d69d2c: mov     x1, x22                                    
02d69d30: mov     x3, xzr                                    
02d69d34: ldr     x8, [x8, #0x3a0]                           M:Clicker.DecorKeycapPanel/<>c::<OnDecorOnTopCategoryClick>b__19_0
02d69d38: mov     x21, x0                                    
02d69d3c: ldr     x2, [x8]                                   M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d69d40: bl      #0x453418c                                 fn_453418c
02d69d44: ldr     x8, [x23]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d69d48: mov     x1, x21                                    
02d69d4c: ldr     x0, [x8, #0xb8]                            MS:System.Collections.Generic.List`1::Add
02d69d50: str     x21, [x0, #0x10]!                          
02d69d54: bl      #0x2b70d54                                 fn_2b70d54
02d69d58: cbz     x20, #0x2d69dc8                            
02d69d5c: adrp    x8, #0x626c000                             
02d69d60: mov     x0, x20                                    
02d69d64: mov     x1, x21                                    
02d69d68: ldr     x8, [x8, #0x350]                           MS:System.Collections.Generic.List`1::ForEach
02d69d6c: ldr     x2, [x8]                                   M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d69d70: bl      #0x35a9ce4                                 fn_35a9ce4
02d69d74: ldr     x0, [x19, #0x68]                           ._btnCharm
02d69d78: cbz     x0, #0x2d69dc8                             
02d69d7c: adrp    x20, #0x6264000                            
02d69d80: mov     w1, #1                                     
02d69d84: ldr     x20, [x20, #0x108]                         MS:DG.Tweening.TweenSettingsExtensions::SetEase
02d69d88: bl      #0x2d664c4                                 Clicker.CategoryButton::SetSelected
02d69d8c: mov     x0, x19                                    
02d69d90: bl      #0x2d69a78                                 Clicker.DecorKeycapPanel::ShowListDecorOnTop
02d69d94: adrp    x8, #0x1084000                             
02d69d98: fmov    s0, #1.00000000                            
02d69d9c: ldr     x0, [x19, #0x58]                           ._scrollRect
02d69da0: ldr     s1, [x8, #0xdd8]                           [1084dd8]=3f7333333e4ccccd f=0.2,0.95
02d69da4: mov     w1, wzr                                    
02d69da8: mov     x2, xzr                                    
02d69dac: bl      #0x2c7bb5c                                 DG.Tweening.DOTweenModuleUI::DOVerticalNormalizedPos
02d69db0: ldr     x2, [x20]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d69db4: ldp     x20, x19, [sp, #0x20]                      
02d69db8: ldp     x22, x21, [sp, #0x10]                      
02d69dbc: mov     w1, #3                                     
02d69dc0: ldp     x30, x23, [sp], #0x30                      
02d69dc4: b       #0x336fa0c                                 
02d69dc8: bl      #0x2b7105c                                 fn_2b7105c
## OnDecorReplaceCategoryClick() -> void
---- Clicker.DecorKeycapPanel::OnDecorReplaceCategoryClick 0x2d69dcc
02d69dcc: stp     x30, x23, [sp, #-0x30]!                    
02d69dd0: stp     x22, x21, [sp, #0x10]                      
02d69dd4: stp     x20, x19, [sp, #0x20]                      
02d69dd8: adrp    x20, #0x6630000                            
02d69ddc: adrp    x23, #0x626c000                            
02d69de0: mov     x19, x0                                    
02d69de4: ldrb    w8, [x20, #0x351]                          
02d69de8: ldr     x23, [x23, #0x360]                         T:Clicker.DecorKeycapPanel/<>c
02d69dec: tbnz    w8, #0, #0x2d69e34                         
02d69df0: adrp    x0, #0x626c000                             
02d69df4: ldr     x0, [x0, #0x338]                           T:type53119(k15)
02d69df8: bl      #0x2b70db0                                 fn_2b70db0
02d69dfc: adrp    x0, #0x626c000                             
02d69e00: ldr     x0, [x0, #0x350]                           MS:System.Collections.Generic.List`1::ForEach
02d69e04: bl      #0x2b70db0                                 fn_2b70db0
02d69e08: adrp    x0, #0x6264000                             
02d69e0c: ldr     x0, [x0, #0x108]                           MS:DG.Tweening.TweenSettingsExtensions::SetEase
02d69e10: bl      #0x2b70db0                                 fn_2b70db0
02d69e14: adrp    x0, #0x626c000                             
02d69e18: ldr     x0, [x0, #0x3a8]                           M:Clicker.DecorKeycapPanel/<>c::<OnDecorReplaceCategoryClick>b__20_0
02d69e1c: bl      #0x2b70db0                                 fn_2b70db0
02d69e20: adrp    x0, #0x626c000                             
02d69e24: ldr     x0, [x0, #0x360]                           T:Clicker.DecorKeycapPanel/<>c
02d69e28: bl      #0x2b70db0                                 fn_2b70db0
02d69e2c: mov     w8, #1                                     
02d69e30: strb    w8, [x20, #0x351]                          
02d69e34: mov     x0, xzr                                    
02d69e38: bl      #0x2d6ff04                                 Framework.AudioHelper::PlayClickSound
02d69e3c: ldr     x0, [x23]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d69e40: ldr     x20, [x19, #0x60]                          ._listCategoryBtn
02d69e44: ldr     w8, [x0, #0xe4]                            [626c0e4]=0 f=0,0
02d69e48: cbnz    w8, #0x2d69e54                             
02d69e4c: bl      #0x2b70f30                                 fn_2b70f30
02d69e50: ldr     x0, [x23]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d69e54: ldr     x8, [x0, #0xb8]                            MS:System.Collections.Generic.List`1::Add
02d69e58: ldr     x21, [x8, #0x18]                           
02d69e5c: cbnz    x21, #0x2d69eb8                            
02d69e60: ldr     w9, [x0, #0xe4]                            [626c0e4]=0 f=0,0
02d69e64: cbnz    w9, #0x2d69e74                             
02d69e68: bl      #0x2b70f30                                 fn_2b70f30
02d69e6c: ldr     x8, [x23]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d69e70: ldr     x8, [x8, #0xb8]                            
02d69e74: adrp    x9, #0x626c000                             
02d69e78: ldr     x9, [x9, #0x338]                           T:type53119(k15)
02d69e7c: ldr     x22, [x8]                                  
02d69e80: ldr     x0, [x9]                                   M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d69e84: bl      #0x2b7104c                                 fn_2b7104c
02d69e88: adrp    x8, #0x626c000                             
02d69e8c: mov     x1, x22                                    
02d69e90: mov     x3, xzr                                    
02d69e94: ldr     x8, [x8, #0x3a8]                           M:Clicker.DecorKeycapPanel/<>c::<OnDecorReplaceCategoryClick>b__20_0
02d69e98: mov     x21, x0                                    
02d69e9c: ldr     x2, [x8]                                   M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d69ea0: bl      #0x453418c                                 fn_453418c
02d69ea4: ldr     x8, [x23]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d69ea8: mov     x1, x21                                    
02d69eac: ldr     x0, [x8, #0xb8]                            MS:System.Collections.Generic.List`1::Add
02d69eb0: str     x21, [x0, #0x18]!                          
02d69eb4: bl      #0x2b70d54                                 fn_2b70d54
02d69eb8: cbz     x20, #0x2d69f28                            
02d69ebc: adrp    x8, #0x626c000                             
02d69ec0: mov     x0, x20                                    
02d69ec4: mov     x1, x21                                    
02d69ec8: ldr     x8, [x8, #0x350]                           MS:System.Collections.Generic.List`1::ForEach
02d69ecc: ldr     x2, [x8]                                   M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d69ed0: bl      #0x35a9ce4                                 fn_35a9ce4
02d69ed4: ldr     x0, [x19, #0x70]                           ._btnReplace
02d69ed8: cbz     x0, #0x2d69f28                             
02d69edc: adrp    x20, #0x6264000                            
02d69ee0: mov     w1, #1                                     
02d69ee4: ldr     x20, [x20, #0x108]                         MS:DG.Tweening.TweenSettingsExtensions::SetEase
02d69ee8: bl      #0x2d664c4                                 Clicker.CategoryButton::SetSelected
02d69eec: mov     x0, x19                                    
02d69ef0: bl      #0x2d69f2c                                 Clicker.DecorKeycapPanel::ShowListDecorReplace
02d69ef4: adrp    x8, #0x1084000                             
02d69ef8: fmov    s0, #1.00000000                            
02d69efc: ldr     x0, [x19, #0x58]                           ._scrollRect
02d69f00: ldr     s1, [x8, #0xdd8]                           [1084dd8]=3f7333333e4ccccd f=0.2,0.95
02d69f04: mov     w1, wzr                                    
02d69f08: mov     x2, xzr                                    
02d69f0c: bl      #0x2c7bb5c                                 DG.Tweening.DOTweenModuleUI::DOVerticalNormalizedPos
02d69f10: ldr     x2, [x20]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d69f14: ldp     x20, x19, [sp, #0x20]                      
02d69f18: ldp     x22, x21, [sp, #0x10]                      
02d69f1c: mov     w1, #3                                     
02d69f20: ldp     x30, x23, [sp], #0x30                      
02d69f24: b       #0x336fa0c                                 
02d69f28: bl      #0x2b7105c                                 fn_2b7105c
## OnDecorPaintCategoryClick() -> void
---- Clicker.DecorKeycapPanel::OnDecorPaintCategoryClick 0x2d6a030
02d6a030: mov     x0, xzr                                    
02d6a034: b       #0x2d6ff04                                 Framework.AudioHelper::PlayClickSound
## ShowListDecorOnTop() -> void
---- Clicker.DecorKeycapPanel::ShowListDecorOnTop 0x2d69a78
02d69a78: str     x30, [sp, #-0x30]!                         
02d69a7c: stp     x22, x21, [sp, #0x10]                      
02d69a80: stp     x20, x19, [sp, #0x20]                      
02d69a84: adrp    x20, #0x6630000                            
02d69a88: adrp    x22, #0x626c000                            
02d69a8c: mov     x19, x0                                    
02d69a90: ldrb    w8, [x20, #0x352]                          
02d69a94: ldr     x22, [x22, #0x360]                         T:Clicker.DecorKeycapPanel/<>c
02d69a98: tbnz    w8, #0, #0x2d69ad4                         
02d69a9c: adrp    x0, #0x626c000                             
02d69aa0: ldr     x0, [x0, #0x378]                           T:type53128(k15)
02d69aa4: bl      #0x2b70db0                                 fn_2b70db0
02d69aa8: adrp    x0, #0x626c000                             
02d69aac: ldr     x0, [x0, #0x380]                           MS:System.Collections.Generic.List`1::ForEach
02d69ab0: bl      #0x2b70db0                                 fn_2b70db0
02d69ab4: adrp    x0, #0x626c000                             
02d69ab8: ldr     x0, [x0, #0x388]                           M:Clicker.DecorKeycapPanel/<>c::<ShowListDecorOnTop>b__22_0
02d69abc: bl      #0x2b70db0                                 fn_2b70db0
02d69ac0: adrp    x0, #0x626c000                             
02d69ac4: ldr     x0, [x0, #0x360]                           T:Clicker.DecorKeycapPanel/<>c
02d69ac8: bl      #0x2b70db0                                 fn_2b70db0
02d69acc: mov     w8, #1                                     
02d69ad0: strb    w8, [x20, #0x352]                          
02d69ad4: ldr     x0, [x22]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d69ad8: ldr     x19, [x19, #0x28]                          ._listItem
02d69adc: ldr     w8, [x0, #0xe4]                            [626c0e4]=0 f=0,0
02d69ae0: cbnz    w8, #0x2d69aec                             
02d69ae4: bl      #0x2b70f30                                 fn_2b70f30
02d69ae8: ldr     x0, [x22]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d69aec: ldr     x8, [x0, #0xb8]                            MS:System.Collections.Generic.List`1::Add
02d69af0: ldr     x20, [x8, #0x20]                           
02d69af4: cbnz    x20, #0x2d69b50                            
02d69af8: ldr     w9, [x0, #0xe4]                            [626c0e4]=0 f=0,0
02d69afc: cbnz    w9, #0x2d69b0c                             
02d69b00: bl      #0x2b70f30                                 fn_2b70f30
02d69b04: ldr     x8, [x22]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d69b08: ldr     x8, [x8, #0xb8]                            
02d69b0c: adrp    x9, #0x626c000                             
02d69b10: ldr     x9, [x9, #0x378]                           T:type53128(k15)
02d69b14: ldr     x21, [x8]                                  
02d69b18: ldr     x0, [x9]                                   M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d69b1c: bl      #0x2b7104c                                 fn_2b7104c
02d69b20: adrp    x8, #0x626c000                             
02d69b24: mov     x1, x21                                    
02d69b28: mov     x3, xzr                                    
02d69b2c: ldr     x8, [x8, #0x388]                           M:Clicker.DecorKeycapPanel/<>c::<ShowListDecorOnTop>b__22_0
02d69b30: mov     x20, x0                                    
02d69b34: ldr     x2, [x8]                                   M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d69b38: bl      #0x453418c                                 fn_453418c
02d69b3c: ldr     x8, [x22]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d69b40: mov     x1, x20                                    
02d69b44: ldr     x0, [x8, #0xb8]                            MS:System.Collections.Generic.List`1::Add
02d69b48: str     x20, [x0, #0x20]!                          ._decorKeycapUIItem
02d69b4c: bl      #0x2b70d54                                 fn_2b70d54
02d69b50: cbz     x19, #0x2d69b78                            
02d69b54: adrp    x8, #0x626c000                             
02d69b58: mov     x0, x19                                    
02d69b5c: mov     x1, x20                                    
02d69b60: ldr     x8, [x8, #0x380]                           MS:System.Collections.Generic.List`1::ForEach
02d69b64: ldp     x20, x19, [sp, #0x20]                      
02d69b68: ldp     x22, x21, [sp, #0x10]                      
02d69b6c: ldr     x2, [x8]                                   M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d69b70: ldr     x30, [sp], #0x30                           
02d69b74: b       #0x35a9ce4                                 
02d69b78: bl      #0x2b7105c                                 fn_2b7105c
## ShowListDecorReplace() -> void
---- Clicker.DecorKeycapPanel::ShowListDecorReplace 0x2d69f2c
02d69f2c: str     x30, [sp, #-0x30]!                         
02d69f30: stp     x22, x21, [sp, #0x10]                      
02d69f34: stp     x20, x19, [sp, #0x20]                      
02d69f38: adrp    x20, #0x6630000                            
02d69f3c: adrp    x22, #0x626c000                            
02d69f40: mov     x19, x0                                    
02d69f44: ldrb    w8, [x20, #0x353]                          
02d69f48: ldr     x22, [x22, #0x360]                         T:Clicker.DecorKeycapPanel/<>c
02d69f4c: tbnz    w8, #0, #0x2d69f88                         
02d69f50: adrp    x0, #0x626c000                             
02d69f54: ldr     x0, [x0, #0x378]                           T:type53128(k15)
02d69f58: bl      #0x2b70db0                                 fn_2b70db0
02d69f5c: adrp    x0, #0x626c000                             
02d69f60: ldr     x0, [x0, #0x380]                           MS:System.Collections.Generic.List`1::ForEach
02d69f64: bl      #0x2b70db0                                 fn_2b70db0
02d69f68: adrp    x0, #0x626c000                             
02d69f6c: ldr     x0, [x0, #0x3b0]                           M:Clicker.DecorKeycapPanel/<>c::<ShowListDecorReplace>b__23_0
02d69f70: bl      #0x2b70db0                                 fn_2b70db0
02d69f74: adrp    x0, #0x626c000                             
02d69f78: ldr     x0, [x0, #0x360]                           T:Clicker.DecorKeycapPanel/<>c
02d69f7c: bl      #0x2b70db0                                 fn_2b70db0
02d69f80: mov     w8, #1                                     
02d69f84: strb    w8, [x20, #0x353]                          
02d69f88: ldr     x0, [x22]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d69f8c: ldr     x19, [x19, #0x28]                          ._listItem
02d69f90: ldr     w8, [x0, #0xe4]                            [626c0e4]=0 f=0,0
02d69f94: cbnz    w8, #0x2d69fa0                             
02d69f98: bl      #0x2b70f30                                 fn_2b70f30
02d69f9c: ldr     x0, [x22]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d69fa0: ldr     x8, [x0, #0xb8]                            MS:System.Collections.Generic.List`1::Add
02d69fa4: ldr     x20, [x8, #0x28]                           
02d69fa8: cbnz    x20, #0x2d6a004                            
02d69fac: ldr     w9, [x0, #0xe4]                            [626c0e4]=0 f=0,0
02d69fb0: cbnz    w9, #0x2d69fc0                             
02d69fb4: bl      #0x2b70f30                                 fn_2b70f30
02d69fb8: ldr     x8, [x22]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d69fbc: ldr     x8, [x8, #0xb8]                            
02d69fc0: adrp    x9, #0x626c000                             
02d69fc4: ldr     x9, [x9, #0x378]                           T:type53128(k15)
02d69fc8: ldr     x21, [x8]                                  
02d69fcc: ldr     x0, [x9]                                   M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d69fd0: bl      #0x2b7104c                                 fn_2b7104c
02d69fd4: adrp    x8, #0x626c000                             
02d69fd8: mov     x1, x21                                    
02d69fdc: mov     x3, xzr                                    
02d69fe0: ldr     x8, [x8, #0x3b0]                           M:Clicker.DecorKeycapPanel/<>c::<ShowListDecorReplace>b__23_0
02d69fe4: mov     x20, x0                                    
02d69fe8: ldr     x2, [x8]                                   M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d69fec: bl      #0x453418c                                 fn_453418c
02d69ff0: ldr     x8, [x22]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d69ff4: mov     x1, x20                                    
02d69ff8: ldr     x0, [x8, #0xb8]                            MS:System.Collections.Generic.List`1::Add
02d69ffc: str     x20, [x0, #0x28]!                          ._listItem
02d6a000: bl      #0x2b70d54                                 fn_2b70d54
02d6a004: cbz     x19, #0x2d6a02c                            
02d6a008: adrp    x8, #0x626c000                             
02d6a00c: mov     x0, x19                                    
02d6a010: mov     x1, x20                                    
02d6a014: ldr     x8, [x8, #0x380]                           MS:System.Collections.Generic.List`1::ForEach
02d6a018: ldp     x20, x19, [sp, #0x20]                      
02d6a01c: ldp     x22, x21, [sp, #0x10]                      
02d6a020: ldr     x2, [x8]                                   M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d6a024: ldr     x30, [sp], #0x30                           
02d6a028: b       #0x35a9ce4                                 
02d6a02c: bl      #0x2b7105c                                 fn_2b7105c
## DeselectAll() -> void
---- Clicker.DecorKeycapPanel::DeselectAll 0x2d6a038
02d6a038: str     x30, [sp, #-0x30]!                         
02d6a03c: stp     x22, x21, [sp, #0x10]                      
02d6a040: stp     x20, x19, [sp, #0x20]                      
02d6a044: adrp    x20, #0x6630000                            
02d6a048: adrp    x22, #0x626c000                            
02d6a04c: mov     x19, x0                                    
02d6a050: ldrb    w8, [x20, #0x354]                          
02d6a054: ldr     x22, [x22, #0x360]                         T:Clicker.DecorKeycapPanel/<>c
02d6a058: tbnz    w8, #0, #0x2d6a094                         
02d6a05c: adrp    x0, #0x626c000                             
02d6a060: ldr     x0, [x0, #0x378]                           T:type53128(k15)
02d6a064: bl      #0x2b70db0                                 fn_2b70db0
02d6a068: adrp    x0, #0x626c000                             
02d6a06c: ldr     x0, [x0, #0x380]                           MS:System.Collections.Generic.List`1::ForEach
02d6a070: bl      #0x2b70db0                                 fn_2b70db0
02d6a074: adrp    x0, #0x626c000                             
02d6a078: ldr     x0, [x0, #0x3b8]                           M:Clicker.DecorKeycapPanel/<>c::<DeselectAll>b__24_0
02d6a07c: bl      #0x2b70db0                                 fn_2b70db0
02d6a080: adrp    x0, #0x626c000                             
02d6a084: ldr     x0, [x0, #0x360]                           T:Clicker.DecorKeycapPanel/<>c
02d6a088: bl      #0x2b70db0                                 fn_2b70db0
02d6a08c: mov     w8, #1                                     
02d6a090: strb    w8, [x20, #0x354]                          
02d6a094: ldr     x0, [x22]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d6a098: ldr     x19, [x19, #0x28]                          ._listItem
02d6a09c: ldr     w8, [x0, #0xe4]                            [626c0e4]=0 f=0,0
02d6a0a0: cbnz    w8, #0x2d6a0ac                             
02d6a0a4: bl      #0x2b70f30                                 fn_2b70f30
02d6a0a8: ldr     x0, [x22]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d6a0ac: ldr     x8, [x0, #0xb8]                            MS:System.Collections.Generic.List`1::Add
02d6a0b0: ldr     x20, [x8, #0x30]                           
02d6a0b4: cbnz    x20, #0x2d6a110                            
02d6a0b8: ldr     w9, [x0, #0xe4]                            [626c0e4]=0 f=0,0
02d6a0bc: cbnz    w9, #0x2d6a0cc                             
02d6a0c0: bl      #0x2b70f30                                 fn_2b70f30
02d6a0c4: ldr     x8, [x22]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d6a0c8: ldr     x8, [x8, #0xb8]                            
02d6a0cc: adrp    x9, #0x626c000                             
02d6a0d0: ldr     x9, [x9, #0x378]                           T:type53128(k15)
02d6a0d4: ldr     x21, [x8]                                  
02d6a0d8: ldr     x0, [x9]                                   M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d6a0dc: bl      #0x2b7104c                                 fn_2b7104c
02d6a0e0: adrp    x8, #0x626c000                             
02d6a0e4: mov     x1, x21                                    
02d6a0e8: mov     x3, xzr                                    
02d6a0ec: ldr     x8, [x8, #0x3b8]                           M:Clicker.DecorKeycapPanel/<>c::<DeselectAll>b__24_0
02d6a0f0: mov     x20, x0                                    
02d6a0f4: ldr     x2, [x8]                                   M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d6a0f8: bl      #0x453418c                                 fn_453418c
02d6a0fc: ldr     x8, [x22]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d6a100: mov     x1, x20                                    
02d6a104: ldr     x0, [x8, #0xb8]                            MS:System.Collections.Generic.List`1::Add
02d6a108: str     x20, [x0, #0x30]!                          ._configDecor
02d6a10c: bl      #0x2b70d54                                 fn_2b70d54
02d6a110: cbz     x19, #0x2d6a138                            
02d6a114: adrp    x8, #0x626c000                             
02d6a118: mov     x0, x19                                    
02d6a11c: mov     x1, x20                                    
02d6a120: ldr     x8, [x8, #0x380]                           MS:System.Collections.Generic.List`1::ForEach
02d6a124: ldp     x20, x19, [sp, #0x20]                      
02d6a128: ldp     x22, x21, [sp, #0x10]                      
02d6a12c: ldr     x2, [x8]                                   M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d6a130: ldr     x30, [sp], #0x30                           
02d6a134: b       #0x35a9ce4                                 
02d6a138: bl      #0x2b7105c                                 fn_2b7105c
## HidePanel() -> void
---- Clicker.DecorKeycapPanel::HidePanel 0x2d6a13c
02d6a13c: str     x30, [sp, #-0x40]!                         
02d6a140: stp     x24, x23, [sp, #0x10]                      
02d6a144: stp     x22, x21, [sp, #0x20]                      
02d6a148: stp     x20, x19, [sp, #0x30]                      
02d6a14c: adrp    x20, #0x6630000                            
02d6a150: mov     x19, x0                                    
02d6a154: ldrb    w8, [x20, #0x355]                          
02d6a158: tbnz    w8, #0, #0x2d6a194                         
02d6a15c: adrp    x0, #0x626c000                             
02d6a160: ldr     x0, [x0, #0x3c0]                           M:Clicker.DecorKeycapPanel::<HidePanel>b__25_0
02d6a164: bl      #0x2b70db0                                 fn_2b70db0
02d6a168: adrp    x0, #0x6264000                             
02d6a16c: ldr     x0, [x0, #0xe8]                            T:DG.Tweening.TweenCallback
02d6a170: bl      #0x2b70db0                                 fn_2b70db0
02d6a174: adrp    x0, #0x6266000                             
02d6a178: ldr     x0, [x0, #0xa08]                           MS:DG.Tweening.TweenSettingsExtensions::OnComplete
02d6a17c: bl      #0x2b70db0                                 fn_2b70db0
02d6a180: adrp    x0, #0x6266000                             
02d6a184: ldr     x0, [x0, #0xa18]                           MS:DG.Tweening.TweenSettingsExtensions::SetEase
02d6a188: bl      #0x2b70db0                                 fn_2b70db0
02d6a18c: mov     w8, #1                                     
02d6a190: strb    w8, [x20, #0x355]                          
02d6a194: ldr     x0, [x19, #0x40]                           ._rtHidePos
02d6a198: cbz     x0, #0x2d6a22c                             
02d6a19c: adrp    x21, #0x6266000                            
02d6a1a0: adrp    x22, #0x6264000                            
02d6a1a4: adrp    x23, #0x626c000                            
02d6a1a8: adrp    x24, #0x6266000                            
02d6a1ac: ldr     x21, [x21, #0xa18]                         MS:DG.Tweening.TweenSettingsExtensions::SetEase
02d6a1b0: ldr     x22, [x22, #0xe8]                          T:DG.Tweening.TweenCallback
02d6a1b4: ldr     x23, [x23, #0x3c0]                         M:Clicker.DecorKeycapPanel::<HidePanel>b__25_0
02d6a1b8: ldr     x24, [x24, #0xa08]                         MS:DG.Tweening.TweenSettingsExtensions::OnComplete
02d6a1bc: ldr     x20, [x19, #0x48]                          ._thisPanelRect
02d6a1c0: mov     x1, xzr                                    
02d6a1c4: bl      #0x5b45734                                 UnityEngine.RectTransform::get_anchoredPosition
02d6a1c8: fmov    s2, #0.50000000                            
02d6a1cc: mov     x0, x20                                    
02d6a1d0: mov     w1, wzr                                    
02d6a1d4: mov     x2, xzr                                    
02d6a1d8: bl      #0x2c798bc                                 DG.Tweening.DOTweenModuleUI::DOAnchorPos
02d6a1dc: ldr     x2, [x21]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d6a1e0: mov     w1, #2                                     
02d6a1e4: bl      #0x336fa0c                                 fn_336fa0c
02d6a1e8: ldr     x8, [x22]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d6a1ec: mov     x20, x0                                    
02d6a1f0: mov     x0, x8                                     
02d6a1f4: bl      #0x2b7104c                                 fn_2b7104c
02d6a1f8: ldr     x2, [x23]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d6a1fc: mov     x1, x19                                    
02d6a200: mov     x3, xzr                                    
02d6a204: mov     x21, x0                                    
02d6a208: bl      #0x2d89dc4                                 DG.Tweening.TweenCallback::.ctor
02d6a20c: ldr     x2, [x24]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d6a210: mov     x0, x20                                    
02d6a214: mov     x1, x21                                    
02d6a218: ldp     x20, x19, [sp, #0x30]                      
02d6a21c: ldp     x22, x21, [sp, #0x20]                      
02d6a220: ldp     x24, x23, [sp, #0x10]                      
02d6a224: ldr     x30, [sp], #0x40                           
02d6a228: b       #0x336f26c                                 
02d6a22c: bl      #0x2b7105c                                 fn_2b7105c
## .ctor() -> void
---- Clicker.DecorKeycapPanel::.ctor 0x2d6a230
02d6a230: mov     x1, xzr                                    
02d6a234: b       #0x5b397b0                                 UnityEngine.MonoBehaviour::.ctor
## <ShowPanel>b__16_0() -> void
---- Clicker.DecorKeycapPanel::<ShowPanel>b__16_0 0x2d6a238
02d6a238: str     x30, [sp, #-0x20]!                         
02d6a23c: stp     x20, x19, [sp, #0x10]                      
02d6a240: adrp    x20, #0x6630000                            
02d6a244: mov     x19, x0                                    
02d6a248: ldrb    w8, [x20, #0x356]                          
02d6a24c: tbnz    w8, #0, #0x2d6a264                         
02d6a250: adrp    x0, #0x626c000                             
02d6a254: ldr     x0, [x0, #0x318]                           MS:System.Collections.Generic.List`1::get_Item
02d6a258: bl      #0x2b70db0                                 fn_2b70db0
02d6a25c: mov     w8, #1                                     
02d6a260: strb    w8, [x20, #0x356]                          
02d6a264: ldrb    w8, [x19, #0x88]                           ._tutorialShown
02d6a268: cbz     w8, #0x2d6a278                             
02d6a26c: ldp     x20, x19, [sp, #0x10]                      
02d6a270: ldr     x30, [sp], #0x20                           
02d6a274: ret                                                
02d6a278: ldr     x0, [x19, #0x28]                           ._listItem
02d6a27c: cbz     x0, #0x2d6a2bc                             
02d6a280: adrp    x8, #0x626c000                             
02d6a284: mov     w1, wzr                                    
02d6a288: ldr     x8, [x8, #0x318]                           MS:System.Collections.Generic.List`1::get_Item
02d6a28c: ldr     x19, [x19, #0x80]                          ._ingameClickerScreen
02d6a290: ldr     x2, [x8]                                   M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d6a294: bl      #0x35a8f3c                                 fn_35a8f3c
02d6a298: cbz     x0, #0x2d6a2bc                             
02d6a29c: mov     x1, xzr                                    
02d6a2a0: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02d6a2a4: cbz     x19, #0x2d6a2bc                            
02d6a2a8: mov     x1, x0                                     
02d6a2ac: mov     x0, x19                                    
02d6a2b0: ldp     x20, x19, [sp, #0x10]                      
02d6a2b4: ldr     x30, [sp], #0x20                           
02d6a2b8: b       #0x2d6a2c0                                 Clicker.IngameClickerScreen::ShowTutorialAt
02d6a2bc: bl      #0x2b7105c                                 fn_2b7105c
## <ShowPanel>b__16_1() -> void
---- Clicker.DecorKeycapPanel::<ShowPanel>b__16_1 0x2d6a39c
02d6a39c: str     x30, [sp, #-0x20]!                         
02d6a3a0: stp     x20, x19, [sp, #0x10]                      
02d6a3a4: adrp    x20, #0x6630000                            
02d6a3a8: mov     x19, x0                                    
02d6a3ac: ldrb    w8, [x20, #0x357]                          
02d6a3b0: tbnz    w8, #0, #0x2d6a3ec                         
02d6a3b4: adrp    x0, #0x6266000                             
02d6a3b8: ldr     x0, [x0, #0x750]                           MS:DataManager::GetData
02d6a3bc: bl      #0x2b70db0                                 fn_2b70db0
02d6a3c0: adrp    x0, #0x6265000                             
02d6a3c4: ldr     x0, [x0, #0xb38]                           T:DevTrack
02d6a3c8: bl      #0x2b70db0                                 fn_2b70db0
02d6a3cc: adrp    x0, #0x626b000                             
02d6a3d0: ldr     x0, [x0, #0xee0]                           MS:MonoSingleton`1::get_Instance
02d6a3d4: bl      #0x2b70db0                                 fn_2b70db0
02d6a3d8: adrp    x0, #0x6266000                             
02d6a3dc: ldr     x0, [x0, #0x658]                           MS:MonoSingleton`1::get_Instance
02d6a3e0: bl      #0x2b70db0                                 fn_2b70db0
02d6a3e4: mov     w8, #1                                     
02d6a3e8: strb    w8, [x20, #0x357]                          
02d6a3ec: ldr     x0, [x19, #0x80]                           ._ingameClickerScreen
02d6a3f0: cbz     x0, #0x2d6a4a8                             
02d6a3f4: mov     w1, wzr                                    
02d6a3f8: bl      #0x2d6519c                                 Clicker.IngameClickerScreen::ShowBtnNext
02d6a3fc: ldr     x0, [x19, #0x80]                           ._ingameClickerScreen
02d6a400: cbz     x0, #0x2d6a4a8                             
02d6a404: adrp    x20, #0x626b000                            
02d6a408: ldr     x20, [x20, #0xee0]                         MS:MonoSingleton`1::get_Instance
02d6a40c: bl      #0x2d6a4ac                                 Clicker.IngameClickerScreen::GoToStepSelectKeychain
02d6a410: ldr     x0, [x20]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d6a414: bl      #0x3769600                                 fn_3769600
02d6a418: cbz     x0, #0x2d6a4a8                             
02d6a41c: adrp    x20, #0x6266000                            
02d6a420: ldr     x20, [x20, #0x658]                         MS:MonoSingleton`1::get_Instance
02d6a424: bl      #0x2d6a600                                 Clicker.KeycapMakerController::ShowSelectKeychain
02d6a428: mov     x0, x19                                    
02d6a42c: bl      #0x2d6a13c                                 Clicker.DecorKeycapPanel::HidePanel
02d6a430: ldr     x0, [x20]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d6a434: bl      #0x3769600                                 fn_3769600
02d6a438: cbz     x0, #0x2d6a4a8                             
02d6a43c: adrp    x8, #0x6266000                             
02d6a440: ldr     x8, [x8, #0x750]                           MS:DataManager::GetData
02d6a444: ldr     x1, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d6a448: bl      #0x3168dd0                                 fn_3168dd0
02d6a44c: cbz     x0, #0x2d6a4a8                             
02d6a450: ldr     x8, [x0, #0x20]                            S:'inter_ad_capping_time' ._decorKeycapUIItem
02d6a454: cbz     x8, #0x2d6a4a8                             
02d6a458: ldrb    w8, [x8, #0x3a]                            
02d6a45c: cbz     w8, #0x2d6a49c                             
02d6a460: adrp    x19, #0x6265000                            
02d6a464: ldr     x19, [x19, #0xb38]                         T:DevTrack
02d6a468: ldr     x0, [x19]                                  M:AdsManager::<OnApplicationPause>b__26_0
02d6a46c: ldr     w8, [x0, #0xe4]                            [62660e4]=0 f=0,0
02d6a470: cbnz    w8, #0x2d6a47c                             
02d6a474: bl      #0x2b70f30                                 fn_2b70f30
02d6a478: ldr     x0, [x19]                                  M:AdsManager::<OnApplicationPause>b__26_0
02d6a47c: ldr     x8, [x0, #0xb8]                            S:'banner_native_refresh_time'
02d6a480: ldp     x20, x19, [sp, #0x10]                      
02d6a484: mov     x3, xzr                                    
02d6a488: ldr     x0, [x8, #0x1f8]                           MS:System.Collections.Generic.List`1/Enumerator::get_Current
02d6a48c: ldr     x1, [x8, #0x240]                           S:'Registering {0} product(s) with the store.'
02d6a490: ldr     w2, [x8, #0x284]                           [6266284]=0 f=0,0
02d6a494: ldr     x30, [sp], #0x20                           
02d6a498: b       #0x2c9c1e0                                 DevTrack::OnboardingStep
02d6a49c: ldp     x20, x19, [sp, #0x10]                      
02d6a4a0: ldr     x30, [sp], #0x20                           
02d6a4a4: ret                                                
02d6a4a8: bl      #0x2b7105c                                 fn_2b7105c
## <HidePanel>b__25_0() -> void
---- Clicker.DecorKeycapPanel::<HidePanel>b__25_0 0x2d6a6bc
02d6a6bc: str     x30, [sp, #-0x10]!                         
02d6a6c0: ldr     x0, [x0, #0x48]                            ._thisPanelRect
02d6a6c4: cbz     x0, #0x2d6a6e4                             
02d6a6c8: mov     x1, xzr                                    
02d6a6cc: bl      #0x5b339ec                                 UnityEngine.Component::get_gameObject
02d6a6d0: cbz     x0, #0x2d6a6e4                             
02d6a6d4: mov     w1, wzr                                    
02d6a6d8: mov     x2, xzr                                    
02d6a6dc: ldr     x30, [sp], #0x10                           
02d6a6e0: b       #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d6a6e4: bl      #0x2b7105c                                 fn_2b7105c
