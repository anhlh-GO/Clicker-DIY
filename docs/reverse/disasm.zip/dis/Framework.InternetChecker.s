#### CLASS Framework.InternetChecker/<CRInternetCheck>d__8 parent= object
#   field <>1__state                     int                                                off=0x10 attr=1 
#   field <>2__current                   object                                             off=0x18 attr=1 
#   field <>4__this                      Framework.InternetChecker                          off=0x20 attr=6 
#   field <wait>5__2                     UnityEngine.WaitForSecondsRealtime                 off=0x28 attr=1 
## .ctor(int <>1__state) -> void
---- Framework.InternetChecker/<CRInternetCheck>d__8::.ctor 0x2cc3764
02cc3764: str     x30, [sp, #-0x20]!                         
02cc3768: stp     x20, x19, [sp, #0x10]                      
02cc376c: mov     w19, w1                                    
02cc3770: mov     x1, xzr                                    
02cc3774: mov     x20, x0                                    
02cc3778: bl      #0x4e53e9c                                 System.Object::.ctor
02cc377c: str     w19, [x20, #0x10]                          .<>1__state
02cc3780: ldp     x20, x19, [sp, #0x10]                      
02cc3784: ldr     x30, [sp], #0x20                           
02cc3788: ret                                                
## System.IDisposable.Dispose() -> void
---- Framework.InternetChecker/<CRInternetCheck>d__8::System.IDisposable.Dispose 0x2cc37d4
02cc37d4: ret                                                
## MoveNext() -> bool
---- Framework.InternetChecker/<CRInternetCheck>d__8::MoveNext 0x2cc37d8
02cc37d8: stp     x30, x21, [sp, #-0x20]!                    
02cc37dc: stp     x20, x19, [sp, #0x10]                      
02cc37e0: adrp    x20, #0x662f000                            
02cc37e4: mov     x19, x0                                    
02cc37e8: ldrb    w8, [x20, #0xc36]                          
02cc37ec: tbnz    w8, #0, #0x2cc3810                         
02cc37f0: adrp    x0, #0x6266000                             
02cc37f4: ldr     x0, [x0, #0xff8]                           T:Framework.DeviceInfo
02cc37f8: bl      #0x2b70db0                                 fn_2b70db0
02cc37fc: adrp    x0, #0x6265000                             
02cc3800: ldr     x0, [x0, #0xaa8]                           T:UnityEngine.WaitForSecondsRealtime
02cc3804: bl      #0x2b70db0                                 fn_2b70db0
02cc3808: mov     w8, #1                                     
02cc380c: strb    w8, [x20, #0xc36]                          
02cc3810: ldr     w8, [x19, #0x10]                           .<>1__state
02cc3814: ldr     x20, [x19, #0x20]                          .<>4__this
02cc3818: cmp     w8, #1                                     
02cc381c: b.eq    #0x2cc3860                                 
02cc3820: cbnz    w8, #0x2cc38b0                             
02cc3824: adrp    x8, #0x6265000                             
02cc3828: mov     w9, #-1                                    
02cc382c: ldr     x8, [x8, #0xaa8]                           T:UnityEngine.WaitForSecondsRealtime
02cc3830: str     w9, [x19, #0x10]                           .<>1__state
02cc3834: ldr     x0, [x8]                                   M:AdsManager::<OnApplicationPause>b__26_0
02cc3838: bl      #0x2b7104c                                 fn_2b7104c
02cc383c: fmov    s0, #1.00000000                            
02cc3840: mov     x1, xzr                                    
02cc3844: mov     x21, x0                                    
02cc3848: bl      #0x5b3e6e4                                 UnityEngine.WaitForSecondsRealtime::.ctor
02cc384c: mov     x0, x19                                    
02cc3850: mov     x1, x21                                    
02cc3854: str     x21, [x0, #0x28]!                          .<wait>5__2
02cc3858: bl      #0x2b70d54                                 fn_2b70d54
02cc385c: b       #0x2cc3868                                 
02cc3860: mov     w8, #-1                                    
02cc3864: str     w8, [x19, #0x10]                           .<>1__state
02cc3868: adrp    x8, #0x6266000                             
02cc386c: ldr     x8, [x8, #0xff8]                           T:Framework.DeviceInfo
02cc3870: ldr     x0, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cc3874: ldr     w8, [x0, #0xe4]                            [62650e4]=0 f=0,0
02cc3878: cbnz    w8, #0x2cc3880                             
02cc387c: bl      #0x2b70f30                                 fn_2b70f30
02cc3880: bl      #0x2cbe96c                                 Framework.DeviceInfo::HasInternet
02cc3884: cbz     x20, #0x2cc38c0                            
02cc3888: and     w1, w0, #1                                 
02cc388c: mov     x0, x20                                    
02cc3890: bl      #0x2cc3648                                 Framework.InternetChecker::set_InternetStatus
02cc3894: ldr     x1, [x19, #0x28]                           .<wait>5__2
02cc3898: str     x1, [x19, #0x18]!                          .<>2__current
02cc389c: mov     x0, x19                                    
02cc38a0: bl      #0x2b70d54                                 fn_2b70d54
02cc38a4: mov     w0, #1                                     
02cc38a8: stur    w0, [x19, #-8]                             
02cc38ac: b       #0x2cc38b4                                 
02cc38b0: mov     w0, wzr                                    
02cc38b4: ldp     x20, x19, [sp, #0x10]                      
02cc38b8: ldp     x30, x21, [sp], #0x20                      
02cc38bc: ret                                                
02cc38c0: bl      #0x2b7105c                                 fn_2b7105c
## System.Collections.Generic.IEnumerator<System.Object>.get_Current() -> object
---- Framework.InternetChecker/<CRInternetCheck>d__8::System.Collections.Generic.IEnumerator<System.Object>.get_Current 0x2cc38c4
02cc38c4: ldr     x0, [x0, #0x18]                            .<>2__current
02cc38c8: ret                                                
## System.Collections.IEnumerator.Reset() -> void
---- Framework.InternetChecker/<CRInternetCheck>d__8::System.Collections.IEnumerator.Reset 0x2cc38cc
02cc38cc: stp     x30, x19, [sp, #-0x10]!                    
02cc38d0: adrp    x0, #0x6264000                             
02cc38d4: ldr     x0, [x0, #0xf60]                           T:System.NotSupportedException
02cc38d8: bl      #0x2b70dc4                                 fn_2b70dc4
02cc38dc: bl      #0x2b7104c                                 fn_2b7104c
02cc38e0: mov     x1, xzr                                    
02cc38e4: mov     x19, x0                                    
02cc38e8: bl      #0x4e14238                                 System.NotSupportedException::.ctor
02cc38ec: adrp    x0, #0x6267000                             
02cc38f0: ldr     x0, [x0, #0x180]                           M:Framework.InternetChecker/<CRInternetCheck>d__8::System.Collections.IEnumerator.Reset
02cc38f4: bl      #0x2b70dc4                                 fn_2b70dc4
02cc38f8: mov     x1, x0                                     
02cc38fc: mov     x0, x19                                    
02cc3900: bl      #0x2b70f20                                 fn_2b70f20
## System.Collections.IEnumerator.get_Current() -> object
---- Framework.InternetChecker/<CRInternetCheck>d__8::System.Collections.IEnumerator.get_Current 0x2cc3904
02cc3904: ldr     x0, [x0, #0x18]                            .<>2__current
02cc3908: ret                                                
#### CLASS Framework.InternetChecker parent= MonoSingleton`1<Framework.InternetChecker>
#   field OnStatusChanged                System.Action`1<bool>                              off=0x0 attr=11 CompilerGeneratedAttribute
#   field _internetStatus                bool                                               off=0x20 attr=1 
## add_OnStatusChanged(System.Action`1<bool> value) -> void
---- Framework.InternetChecker::add_OnStatusChanged 0x2cc34a8
02cc34a8: str     x30, [sp, #-0x40]!                         
02cc34ac: stp     x24, x23, [sp, #0x10]                      
02cc34b0: stp     x22, x21, [sp, #0x20]                      
02cc34b4: stp     x20, x19, [sp, #0x30]                      
02cc34b8: adrp    x20, #0x662f000                            
02cc34bc: adrp    x23, #0x6267000                            
02cc34c0: mov     x19, x0                                    
02cc34c4: ldrb    w8, [x20, #0xc31]                          
02cc34c8: ldr     x23, [x23, #0x160]                         T:Framework.InternetChecker
02cc34cc: tbnz    w8, #0, #0x2cc34f0                         
02cc34d0: adrp    x0, #0x6267000                             
02cc34d4: ldr     x0, [x0, #0x168]                           T:type6835(k15)
02cc34d8: bl      #0x2b70db0                                 fn_2b70db0
02cc34dc: adrp    x0, #0x6267000                             
02cc34e0: ldr     x0, [x0, #0x160]                           T:Framework.InternetChecker
02cc34e4: bl      #0x2b70db0                                 fn_2b70db0
02cc34e8: mov     w8, #1                                     
02cc34ec: strb    w8, [x20, #0xc31]                          
02cc34f0: ldr     x8, [x23]                                  S:'didu'
02cc34f4: adrp    x24, #0x6267000                            
02cc34f8: ldr     x8, [x8, #0xb8]                            
02cc34fc: ldr     x24, [x24, #0x168]                         T:type6835(k15)
02cc3500: ldr     x20, [x8]                                  
02cc3504: mov     x0, x20                                    
02cc3508: mov     x1, x19                                    
02cc350c: mov     x2, xzr                                    
02cc3510: bl      #0x4e570ac                                 System.Delegate::Combine
02cc3514: cbz     x0, #0x2cc3534                             
02cc3518: ldr     x22, [x24]                                 S:'didu'
02cc351c: mov     x21, x0                                    
02cc3520: mov     x1, x22                                    
02cc3524: bl      #0x2b70f34                                 fn_2b70f34
02cc3528: mov     x1, x0                                     
02cc352c: cbnz    x0, #0x2cc3538                             
02cc3530: b       #0x2cc3568                                 
02cc3534: mov     x1, xzr                                    
02cc3538: ldr     x8, [x23]                                  S:'didu'
02cc353c: mov     x2, x20                                    
02cc3540: ldr     x0, [x8, #0xb8]                            
02cc3544: bl      #0x2ba9880                                 fn_2ba9880
02cc3548: cmp     x0, x20                                    
02cc354c: mov     x20, x0                                    
02cc3550: b.ne    #0x2cc3504                                 
02cc3554: ldp     x20, x19, [sp, #0x30]                      
02cc3558: ldp     x22, x21, [sp, #0x20]                      
02cc355c: ldp     x24, x23, [sp, #0x10]                      
02cc3560: ldr     x30, [sp], #0x40                           
02cc3564: ret                                                
02cc3568: mov     x0, x21                                    
02cc356c: mov     x1, x22                                    
02cc3570: bl      #0x2b713dc                                 fn_2b713dc
## remove_OnStatusChanged(System.Action`1<bool> value) -> void
---- Framework.InternetChecker::remove_OnStatusChanged 0x2cc3574
02cc3574: str     x30, [sp, #-0x40]!                         
02cc3578: stp     x24, x23, [sp, #0x10]                      
02cc357c: stp     x22, x21, [sp, #0x20]                      
02cc3580: stp     x20, x19, [sp, #0x30]                      
02cc3584: adrp    x20, #0x662f000                            
02cc3588: adrp    x23, #0x6267000                            
02cc358c: mov     x19, x0                                    
02cc3590: ldrb    w8, [x20, #0xc32]                          
02cc3594: ldr     x23, [x23, #0x160]                         T:Framework.InternetChecker
02cc3598: tbnz    w8, #0, #0x2cc35bc                         
02cc359c: adrp    x0, #0x6267000                             
02cc35a0: ldr     x0, [x0, #0x168]                           T:type6835(k15)
02cc35a4: bl      #0x2b70db0                                 fn_2b70db0
02cc35a8: adrp    x0, #0x6267000                             
02cc35ac: ldr     x0, [x0, #0x160]                           T:Framework.InternetChecker
02cc35b0: bl      #0x2b70db0                                 fn_2b70db0
02cc35b4: mov     w8, #1                                     
02cc35b8: strb    w8, [x20, #0xc32]                          
02cc35bc: ldr     x8, [x23]                                  S:'didu'
02cc35c0: adrp    x24, #0x6267000                            
02cc35c4: ldr     x8, [x8, #0xb8]                            
02cc35c8: ldr     x24, [x24, #0x168]                         T:type6835(k15)
02cc35cc: ldr     x20, [x8]                                  
02cc35d0: mov     x0, x20                                    
02cc35d4: mov     x1, x19                                    
02cc35d8: mov     x2, xzr                                    
02cc35dc: bl      #0x4e57298                                 System.Delegate::Remove
02cc35e0: cbz     x0, #0x2cc3600                             
02cc35e4: ldr     x22, [x24]                                 S:'didu'
02cc35e8: mov     x21, x0                                    
02cc35ec: mov     x1, x22                                    
02cc35f0: bl      #0x2b70f34                                 fn_2b70f34
02cc35f4: mov     x1, x0                                     
02cc35f8: cbnz    x0, #0x2cc3604                             
02cc35fc: b       #0x2cc3634                                 
02cc3600: mov     x1, xzr                                    
02cc3604: ldr     x8, [x23]                                  S:'didu'
02cc3608: mov     x2, x20                                    
02cc360c: ldr     x0, [x8, #0xb8]                            
02cc3610: bl      #0x2ba9880                                 fn_2ba9880
02cc3614: cmp     x0, x20                                    
02cc3618: mov     x20, x0                                    
02cc361c: b.ne    #0x2cc35d0                                 
02cc3620: ldp     x20, x19, [sp, #0x30]                      
02cc3624: ldp     x22, x21, [sp, #0x20]                      
02cc3628: ldp     x24, x23, [sp, #0x10]                      
02cc362c: ldr     x30, [sp], #0x40                           
02cc3630: ret                                                
02cc3634: mov     x0, x21                                    
02cc3638: mov     x1, x22                                    
02cc363c: bl      #0x2b713dc                                 fn_2b713dc
## get_InternetStatus() -> bool
---- Framework.InternetChecker::get_InternetStatus 0x2cc3640
02cc3640: ldrb    w0, [x0, #0x20]                            ._internetStatus
02cc3644: ret                                                
## set_InternetStatus(bool value) -> void
---- Framework.InternetChecker::set_InternetStatus 0x2cc3648
02cc3648: str     x30, [sp, #-0x30]!                         
02cc364c: stp     x22, x21, [sp, #0x10]                      
02cc3650: stp     x20, x19, [sp, #0x20]                      
02cc3654: adrp    x22, #0x662f000                            
02cc3658: mov     w19, w1                                    
02cc365c: mov     x20, x0                                    
02cc3660: ldrb    w8, [x22, #0xc33]                          
02cc3664: and     w21, w1, #1                                
02cc3668: tbnz    w8, #0, #0x2cc3680                         
02cc366c: adrp    x0, #0x6267000                             
02cc3670: ldr     x0, [x0, #0x160]                           T:Framework.InternetChecker
02cc3674: bl      #0x2b70db0                                 fn_2b70db0
02cc3678: mov     w8, #1                                     
02cc367c: strb    w8, [x22, #0xc33]                          
02cc3680: ldrb    w8, [x20, #0x20]                           ._internetStatus
02cc3684: cmp     w8, w21                                    
02cc3688: b.eq    #0x2cc36c8                                 
02cc368c: adrp    x8, #0x6267000                             
02cc3690: ldr     x8, [x8, #0x160]                           T:Framework.InternetChecker
02cc3694: strb    w21, [x20, #0x20]                          ._internetStatus
02cc3698: ldr     x8, [x8]                                   S:'didu'
02cc369c: ldr     x8, [x8, #0xb8]                            M:Framework.SceneUtils/<CRUnloadSceneAsync>d__2::System.Collections.IEnumerator.Reset
02cc36a0: ldr     x8, [x8]                                   S:'didu'
02cc36a4: cbz     x8, #0x2cc36c8                             
02cc36a8: and     w1, w19, #1                                
02cc36ac: ldp     x20, x19, [sp, #0x20]                      
02cc36b0: ldp     x22, x21, [sp, #0x10]                      
02cc36b4: ldr     x0, [x8, #0x40]                            S:'<color=#'
02cc36b8: ldr     x2, [x8, #0x28]                            S:'[^A-Za-z0-9_. ]+'
02cc36bc: ldr     x3, [x8, #0x18]                            S:'android.content.Intent'
02cc36c0: ldr     x30, [sp], #0x30                           
02cc36c4: br      x3                                         
02cc36c8: ldp     x20, x19, [sp, #0x20]                      
02cc36cc: ldp     x22, x21, [sp, #0x10]                      
02cc36d0: ldr     x30, [sp], #0x30                           
02cc36d4: ret                                                
## Start() -> void
---- Framework.InternetChecker::Start 0x2cc36d8
02cc36d8: stp     x30, x19, [sp, #-0x10]!                    
02cc36dc: mov     x19, x0                                    
02cc36e0: bl      #0x2cc36f8                                 Framework.InternetChecker::CRInternetCheck
02cc36e4: mov     x1, x0                                     
02cc36e8: mov     x0, x19                                    
02cc36ec: mov     x2, xzr                                    
02cc36f0: ldp     x30, x19, [sp], #0x10                      
02cc36f4: b       #0x5b389f0                                 UnityEngine.MonoBehaviour::StartCoroutine
## CRInternetCheck() -> System.Collections.IEnumerator
---- Framework.InternetChecker::CRInternetCheck 0x2cc36f8
02cc36f8: stp     x30, x21, [sp, #-0x20]!                    
02cc36fc: stp     x20, x19, [sp, #0x10]                      
02cc3700: adrp    x20, #0x662f000                            
02cc3704: adrp    x21, #0x6267000                            
02cc3708: mov     x19, x0                                    
02cc370c: ldrb    w8, [x20, #0xc34]                          
02cc3710: ldr     x21, [x21, #0x170]                         T:Framework.InternetChecker/<CRInternetCheck>d__8
02cc3714: tbnz    w8, #0, #0x2cc372c                         
02cc3718: adrp    x0, #0x6267000                             
02cc371c: ldr     x0, [x0, #0x170]                           T:Framework.InternetChecker/<CRInternetCheck>d__8
02cc3720: bl      #0x2b70db0                                 fn_2b70db0
02cc3724: mov     w8, #1                                     
02cc3728: strb    w8, [x20, #0xc34]                          
02cc372c: ldr     x0, [x21]                                  S:'didu'
02cc3730: bl      #0x2b7104c                                 fn_2b7104c
02cc3734: mov     x1, xzr                                    
02cc3738: mov     x20, x0                                    
02cc373c: bl      #0x4e53e9c                                 System.Object::.ctor
02cc3740: mov     x0, x20                                    
02cc3744: mov     x1, x19                                    
02cc3748: str     wzr, [x20, #0x10]                          
02cc374c: str     x19, [x0, #0x20]!                          ._internetStatus
02cc3750: bl      #0x2b70d54                                 fn_2b70d54
02cc3754: mov     x0, x20                                    
02cc3758: ldp     x20, x19, [sp, #0x10]                      
02cc375c: ldp     x30, x21, [sp], #0x20                      
02cc3760: ret                                                
## .ctor() -> void
---- Framework.InternetChecker::.ctor 0x2cc378c
02cc378c: stp     x30, x21, [sp, #-0x20]!                    
02cc3790: stp     x20, x19, [sp, #0x10]                      
02cc3794: adrp    x20, #0x662f000                            
02cc3798: adrp    x21, #0x6267000                            
02cc379c: mov     x19, x0                                    
02cc37a0: ldrb    w8, [x20, #0xc35]                          
02cc37a4: ldr     x21, [x21, #0x178]                         MS:MonoSingleton`1::.ctor
02cc37a8: tbnz    w8, #0, #0x2cc37c0                         
02cc37ac: adrp    x0, #0x6267000                             
02cc37b0: ldr     x0, [x0, #0x178]                           MS:MonoSingleton`1::.ctor
02cc37b4: bl      #0x2b70db0                                 fn_2b70db0
02cc37b8: mov     w8, #1                                     
02cc37bc: strb    w8, [x20, #0xc35]                          
02cc37c0: mov     x0, x19                                    
02cc37c4: ldp     x20, x19, [sp, #0x10]                      
02cc37c8: ldr     x1, [x21]                                  S:'didu'
02cc37cc: ldp     x30, x21, [sp], #0x20                      
02cc37d0: b       #0x3769e18                                 
