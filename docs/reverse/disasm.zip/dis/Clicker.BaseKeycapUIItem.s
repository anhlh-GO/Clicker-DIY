#### CLASS Clicker.BaseKeycapUIItem parent= Clicker.ClickerUIItem
## OnSelected(bool isSelected) -> void
---- Clicker.BaseKeycapUIItem::OnSelected 0x2d664a4
02d664a4: ret                                                
## .ctor() -> void
---- Clicker.BaseKeycapUIItem::.ctor 0x2d664ac
02d664ac: mov     x1, xzr                                    
02d664b0: b       #0x5b397b0                                 UnityEngine.MonoBehaviour::.ctor
