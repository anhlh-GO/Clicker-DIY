#### CLASS Games.Common.EUnlockType parent= int
#   field value__                        int                                                off=0x10 attr=606 
#   field Unlocked                       Games.Common.EUnlockType                           off=0x0 attr=8056 
#   field Ads                            Games.Common.EUnlockType                           off=0x0 attr=8056 
#   field Coin                           Games.Common.EUnlockType                           off=0x0 attr=8056 
#   field Day                            Games.Common.EUnlockType                           off=0x0 attr=8056 
#   field Level                          Games.Common.EUnlockType                           off=0x0 attr=8056 
#   field InAppPurchase                  Games.Common.EUnlockType                           off=0x0 attr=8056 
