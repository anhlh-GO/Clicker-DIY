#### CLASS Clicker.KeycapObject parent= UnityEngine.MonoBehaviour
#   field _srKeycap                      UnityEngine.SpriteRenderer                         off=0x20 attr=1 SerializeField
#   field _srOnTop                       UnityEngine.SpriteRenderer                         off=0x28 attr=1 SerializeField
#   field _srReplace                     UnityEngine.SpriteRenderer                         off=0x30 attr=1 SerializeField
#   field _decorId                       int                                                off=0x38 attr=1 SerializeField,ReadOnlyAttribute
#   field _decorKeycapType               Clicker.DecorKeycapType                            off=0x3c attr=1 
#   field _baseKeycapSprite              UnityEngine.Sprite                                 off=0x40 attr=1 
## get_SrKeycap() -> UnityEngine.SpriteRenderer
---- Clicker.KeycapObject::get_SrKeycap 0x2d63d58
02d63d58: ldr     x0, [x0, #0x20]                            ._srKeycap
02d63d5c: ret                                                
## get_SrOnTop() -> UnityEngine.SpriteRenderer
---- Clicker.KeycapObject::get_SrOnTop 0x2d63d60
02d63d60: ldr     x0, [x0, #0x28]                            ._srOnTop
02d63d64: ret                                                
## get_Replace() -> UnityEngine.SpriteRenderer
---- Clicker.KeycapObject::get_Replace 0x2d63d68
02d63d68: ldr     x0, [x0, #0x30]                            ._srReplace
02d63d6c: ret                                                
## get_DecorId() -> int
---- Clicker.KeycapObject::get_DecorId 0x2d63d70
02d63d70: ldr     w0, [x0, #0x38]                            ._decorId
02d63d74: ret                                                
## get_DecorKeycapType() -> Clicker.DecorKeycapType
---- Clicker.KeycapObject::get_DecorKeycapType 0x2d63d78
02d63d78: ldr     w0, [x0, #0x3c]                            ._decorKeycapType
02d63d7c: ret                                                
## SetDecor(UnityEngine.Sprite sprite, Clicker.DecorKeycapType decorKeycapType, int decorId) -> void
---- Clicker.KeycapObject::SetDecor 0x2d5eac0
02d5eac0: str     x30, [sp, #-0x20]!                         
02d5eac4: stp     x20, x19, [sp, #0x10]                      
02d5eac8: mov     x20, x1                                    
02d5eacc: mov     x19, x0                                    
02d5ead0: cmp     w2, #1                                     
02d5ead4: stp     w3, w2, [x0, #0x38]                        ._decorId
02d5ead8: b.le    #0x2d5eb64                                 
02d5eadc: cmp     w2, #2                                     
02d5eae0: b.eq    #0x2d5ebe4                                 
02d5eae4: cmp     w2, #3                                     
02d5eae8: b.eq    #0x2d5ec58                                 
02d5eaec: cmp     w2, #4                                     
02d5eaf0: b.ne    #0x2d5ecf4                                 
02d5eaf4: ldr     x0, [x19, #0x20]                           ._srKeycap
02d5eaf8: cbz     x0, #0x2d5ed00                             
02d5eafc: mov     x1, x20                                    
02d5eb00: mov     x2, xzr                                    
02d5eb04: bl      #0x5ae6dcc                                 UnityEngine.SpriteRenderer::set_sprite
02d5eb08: ldr     x0, [x19, #0x28]                           ._srOnTop
02d5eb0c: cbz     x0, #0x2d5ed00                             
02d5eb10: mov     x1, xzr                                    
02d5eb14: bl      #0x5b339ec                                 UnityEngine.Component::get_gameObject
02d5eb18: cbz     x0, #0x2d5ed00                             
02d5eb1c: mov     w1, wzr                                    
02d5eb20: mov     x2, xzr                                    
02d5eb24: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d5eb28: ldr     x0, [x19, #0x30]                           ._srReplace
02d5eb2c: cbz     x0, #0x2d5ed00                             
02d5eb30: mov     x1, xzr                                    
02d5eb34: bl      #0x5b339ec                                 UnityEngine.Component::get_gameObject
02d5eb38: cbz     x0, #0x2d5ed00                             
02d5eb3c: mov     w1, wzr                                    
02d5eb40: mov     x2, xzr                                    
02d5eb44: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d5eb48: ldr     x0, [x19, #0x20]                           ._srKeycap
02d5eb4c: cbz     x0, #0x2d5ed00                             
02d5eb50: mov     x1, xzr                                    
02d5eb54: bl      #0x5b339ec                                 UnityEngine.Component::get_gameObject
02d5eb58: cbz     x0, #0x2d5ed00                             
02d5eb5c: mov     w1, #1                                     
02d5eb60: b       #0x2d5ec50                                 
02d5eb64: cbz     w2, #0x2d5ec68                             
02d5eb68: cmp     w2, #1                                     
02d5eb6c: b.ne    #0x2d5ecf4                                 
02d5eb70: ldr     x0, [x19, #0x20]                           ._srKeycap
02d5eb74: cbz     x0, #0x2d5ed00                             
02d5eb78: ldr     x1, [x19, #0x40]                           ._baseKeycapSprite
02d5eb7c: mov     x2, xzr                                    
02d5eb80: bl      #0x5ae6dcc                                 UnityEngine.SpriteRenderer::set_sprite
02d5eb84: ldr     x0, [x19, #0x28]                           ._srOnTop
02d5eb88: cbz     x0, #0x2d5ed00                             
02d5eb8c: mov     x1, x20                                    
02d5eb90: mov     x2, xzr                                    
02d5eb94: bl      #0x5ae6dcc                                 UnityEngine.SpriteRenderer::set_sprite
02d5eb98: ldr     x0, [x19, #0x28]                           ._srOnTop
02d5eb9c: cbz     x0, #0x2d5ed00                             
02d5eba0: mov     x1, xzr                                    
02d5eba4: bl      #0x5b339ec                                 UnityEngine.Component::get_gameObject
02d5eba8: cbz     x0, #0x2d5ed00                             
02d5ebac: mov     w1, #1                                     
02d5ebb0: mov     x2, xzr                                    
02d5ebb4: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d5ebb8: ldr     x0, [x19, #0x20]                           ._srKeycap
02d5ebbc: cbz     x0, #0x2d5ed00                             
02d5ebc0: mov     x1, xzr                                    
02d5ebc4: bl      #0x5b339ec                                 UnityEngine.Component::get_gameObject
02d5ebc8: cbz     x0, #0x2d5ed00                             
02d5ebcc: mov     w1, #1                                     
02d5ebd0: mov     x2, xzr                                    
02d5ebd4: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d5ebd8: ldr     x0, [x19, #0x30]                           ._srReplace
02d5ebdc: cbnz    x0, #0x2d5ec40                             
02d5ebe0: b       #0x2d5ed00                                 
02d5ebe4: ldr     x0, [x19, #0x30]                           ._srReplace
02d5ebe8: cbz     x0, #0x2d5ed00                             
02d5ebec: mov     x1, x20                                    
02d5ebf0: mov     x2, xzr                                    
02d5ebf4: bl      #0x5ae6dcc                                 UnityEngine.SpriteRenderer::set_sprite
02d5ebf8: ldr     x0, [x19, #0x28]                           ._srOnTop
02d5ebfc: cbz     x0, #0x2d5ed00                             
02d5ec00: mov     x1, xzr                                    
02d5ec04: bl      #0x5b339ec                                 UnityEngine.Component::get_gameObject
02d5ec08: cbz     x0, #0x2d5ed00                             
02d5ec0c: mov     w1, wzr                                    
02d5ec10: mov     x2, xzr                                    
02d5ec14: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d5ec18: ldr     x0, [x19, #0x30]                           ._srReplace
02d5ec1c: cbz     x0, #0x2d5ed00                             
02d5ec20: mov     x1, xzr                                    
02d5ec24: bl      #0x5b339ec                                 UnityEngine.Component::get_gameObject
02d5ec28: cbz     x0, #0x2d5ed00                             
02d5ec2c: mov     w1, #1                                     
02d5ec30: mov     x2, xzr                                    
02d5ec34: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d5ec38: ldr     x0, [x19, #0x20]                           ._srKeycap
02d5ec3c: cbz     x0, #0x2d5ed00                             
02d5ec40: mov     x1, xzr                                    
02d5ec44: bl      #0x5b339ec                                 UnityEngine.Component::get_gameObject
02d5ec48: cbz     x0, #0x2d5ed00                             
02d5ec4c: mov     w1, wzr                                    
02d5ec50: mov     x2, xzr                                    
02d5ec54: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d5ec58: mov     x0, x19                                    
02d5ec5c: ldp     x20, x19, [sp, #0x10]                      
02d5ec60: ldr     x30, [sp], #0x20                           
02d5ec64: b       #0x2d63d80                                 Clicker.KeycapObject::SmallScale
02d5ec68: ldr     x0, [x19, #0x20]                           ._srKeycap
02d5ec6c: cbz     x0, #0x2d5ed00                             
02d5ec70: mov     x1, x20                                    
02d5ec74: mov     x2, xzr                                    
02d5ec78: bl      #0x5ae6dcc                                 UnityEngine.SpriteRenderer::set_sprite
02d5ec7c: ldr     x0, [x19, #0x28]                           ._srOnTop
02d5ec80: cbz     x0, #0x2d5ed00                             
02d5ec84: mov     x1, xzr                                    
02d5ec88: bl      #0x5b339ec                                 UnityEngine.Component::get_gameObject
02d5ec8c: cbz     x0, #0x2d5ed00                             
02d5ec90: mov     w1, wzr                                    
02d5ec94: mov     x2, xzr                                    
02d5ec98: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d5ec9c: ldr     x0, [x19, #0x30]                           ._srReplace
02d5eca0: cbz     x0, #0x2d5ed00                             
02d5eca4: mov     x1, xzr                                    
02d5eca8: bl      #0x5b339ec                                 UnityEngine.Component::get_gameObject
02d5ecac: cbz     x0, #0x2d5ed00                             
02d5ecb0: mov     w1, wzr                                    
02d5ecb4: mov     x2, xzr                                    
02d5ecb8: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d5ecbc: ldr     x0, [x19, #0x20]                           ._srKeycap
02d5ecc0: cbz     x0, #0x2d5ed00                             
02d5ecc4: mov     x1, xzr                                    
02d5ecc8: bl      #0x5b339ec                                 UnityEngine.Component::get_gameObject
02d5eccc: cbz     x0, #0x2d5ed00                             
02d5ecd0: mov     w1, #1                                     
02d5ecd4: mov     x2, xzr                                    
02d5ecd8: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d5ecdc: str     x20, [x19, #0x40]!                         ._baseKeycapSprite
02d5ece0: mov     x0, x19                                    
02d5ece4: mov     x1, x20                                    
02d5ece8: ldp     x20, x19, [sp, #0x10]                      
02d5ecec: ldr     x30, [sp], #0x20                           
02d5ecf0: b       #0x2b70d54                                 
02d5ecf4: ldp     x20, x19, [sp, #0x10]                      
02d5ecf8: ldr     x30, [sp], #0x20                           
02d5ecfc: ret                                                
02d5ed00: bl      #0x2b7105c                                 fn_2b7105c
## CloneKeycap(Clicker.KeycapObject root) -> void
---- Clicker.KeycapObject::CloneKeycap 0x2d5fe94
02d5fe94: stp     x30, x21, [sp, #-0x20]!                    
02d5fe98: stp     x20, x19, [sp, #0x10]                      
02d5fe9c: cbz     x1, #0x2d60010                             
02d5fea0: mov     x20, x0                                    
02d5fea4: ldr     w8, [x1, #0x38]                            
02d5fea8: ldr     x0, [x1, #0x20]                            
02d5feac: mov     x19, x1                                    
02d5feb0: str     w8, [x20, #0x38]                           ._decorId
02d5feb4: cbz     x0, #0x2d60010                             
02d5feb8: ldr     x21, [x20, #0x20]                          ._srKeycap
02d5febc: mov     x1, xzr                                    
02d5fec0: bl      #0x5ae6cfc                                 UnityEngine.SpriteRenderer::get_sprite
02d5fec4: cbz     x21, #0x2d60010                            
02d5fec8: mov     x1, x0                                     
02d5fecc: mov     x0, x21                                    
02d5fed0: mov     x2, xzr                                    
02d5fed4: bl      #0x5ae6dcc                                 UnityEngine.SpriteRenderer::set_sprite
02d5fed8: ldr     x0, [x19, #0x28]                           ._srOnTop
02d5fedc: cbz     x0, #0x2d60010                             
02d5fee0: ldr     x21, [x20, #0x28]                          ._srOnTop
02d5fee4: mov     x1, xzr                                    
02d5fee8: bl      #0x5ae6cfc                                 UnityEngine.SpriteRenderer::get_sprite
02d5feec: cbz     x21, #0x2d60010                            
02d5fef0: mov     x1, x0                                     
02d5fef4: mov     x0, x21                                    
02d5fef8: mov     x2, xzr                                    
02d5fefc: bl      #0x5ae6dcc                                 UnityEngine.SpriteRenderer::set_sprite
02d5ff00: ldr     x0, [x19, #0x30]                           ._srReplace
02d5ff04: cbz     x0, #0x2d60010                             
02d5ff08: ldr     x21, [x20, #0x30]                          ._srReplace
02d5ff0c: mov     x1, xzr                                    
02d5ff10: bl      #0x5ae6cfc                                 UnityEngine.SpriteRenderer::get_sprite
02d5ff14: cbz     x21, #0x2d60010                            
02d5ff18: mov     x1, x0                                     
02d5ff1c: mov     x0, x21                                    
02d5ff20: mov     x2, xzr                                    
02d5ff24: bl      #0x5ae6dcc                                 UnityEngine.SpriteRenderer::set_sprite
02d5ff28: ldr     w8, [x19, #0x3c]                           ._decorKeycapType
02d5ff2c: ldr     x0, [x20, #0x20]                           ._srKeycap
02d5ff30: str     w8, [x20, #0x3c]                           ._decorKeycapType
02d5ff34: cbz     x0, #0x2d60010                             
02d5ff38: mov     x1, xzr                                    
02d5ff3c: bl      #0x5b339ec                                 UnityEngine.Component::get_gameObject
02d5ff40: ldr     x8, [x19, #0x20]                           ._srKeycap
02d5ff44: cbz     x8, #0x2d60010                             
02d5ff48: mov     x21, x0                                    
02d5ff4c: mov     x0, x8                                     
02d5ff50: mov     x1, xzr                                    
02d5ff54: bl      #0x5b339ec                                 UnityEngine.Component::get_gameObject
02d5ff58: cbz     x0, #0x2d60010                             
02d5ff5c: mov     x1, xzr                                    
02d5ff60: bl      #0x5b36bfc                                 UnityEngine.GameObject::get_activeSelf
02d5ff64: cbz     x21, #0x2d60010                            
02d5ff68: and     w1, w0, #1                                 
02d5ff6c: mov     x0, x21                                    
02d5ff70: mov     x2, xzr                                    
02d5ff74: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d5ff78: ldr     x0, [x20, #0x28]                           ._srOnTop
02d5ff7c: cbz     x0, #0x2d60010                             
02d5ff80: mov     x1, xzr                                    
02d5ff84: bl      #0x5b339ec                                 UnityEngine.Component::get_gameObject
02d5ff88: ldr     x8, [x19, #0x28]                           ._srOnTop
02d5ff8c: cbz     x8, #0x2d60010                             
02d5ff90: mov     x21, x0                                    
02d5ff94: mov     x0, x8                                     
02d5ff98: mov     x1, xzr                                    
02d5ff9c: bl      #0x5b339ec                                 UnityEngine.Component::get_gameObject
02d5ffa0: cbz     x0, #0x2d60010                             
02d5ffa4: mov     x1, xzr                                    
02d5ffa8: bl      #0x5b36bfc                                 UnityEngine.GameObject::get_activeSelf
02d5ffac: cbz     x21, #0x2d60010                            
02d5ffb0: and     w1, w0, #1                                 
02d5ffb4: mov     x0, x21                                    
02d5ffb8: mov     x2, xzr                                    
02d5ffbc: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d5ffc0: ldr     x0, [x20, #0x30]                           ._srReplace
02d5ffc4: cbz     x0, #0x2d60010                             
02d5ffc8: mov     x1, xzr                                    
02d5ffcc: bl      #0x5b339ec                                 UnityEngine.Component::get_gameObject
02d5ffd0: ldr     x8, [x19, #0x30]                           ._srReplace
02d5ffd4: cbz     x8, #0x2d60010                             
02d5ffd8: mov     x19, x0                                    
02d5ffdc: mov     x0, x8                                     
02d5ffe0: mov     x1, xzr                                    
02d5ffe4: bl      #0x5b339ec                                 UnityEngine.Component::get_gameObject
02d5ffe8: cbz     x0, #0x2d60010                             
02d5ffec: mov     x1, xzr                                    
02d5fff0: bl      #0x5b36bfc                                 UnityEngine.GameObject::get_activeSelf
02d5fff4: cbz     x19, #0x2d60010                            
02d5fff8: and     w1, w0, #1                                 
02d5fffc: mov     x0, x19                                    
02d60000: mov     x2, xzr                                    
02d60004: ldp     x20, x19, [sp, #0x10]                      
02d60008: ldp     x30, x21, [sp], #0x20                      
02d6000c: b       #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d60010: bl      #0x2b7105c                                 fn_2b7105c
## SmallScale() -> void
---- Clicker.KeycapObject::SmallScale 0x2d63d80
02d63d80: stp     x30, x23, [sp, #-0x30]!                    
02d63d84: stp     x22, x21, [sp, #0x10]                      
02d63d88: stp     x20, x19, [sp, #0x20]                      
02d63d8c: adrp    x23, #0x6630000                            
02d63d90: adrp    x20, #0x6264000                            
02d63d94: adrp    x21, #0x626c000                            
02d63d98: adrp    x22, #0x6266000                            
02d63d9c: ldr     x20, [x20, #0xe8]                          T:DG.Tweening.TweenCallback
02d63da0: ldrb    w8, [x23, #0x311]                          
02d63da4: ldr     x21, [x21, #0x78]                          M:Clicker.KeycapObject::<SmallScale>b__18_0
02d63da8: ldr     x22, [x22, #0x928]                         MS:DG.Tweening.TweenSettingsExtensions::OnComplete
02d63dac: mov     x19, x0                                    
02d63db0: tbnz    w8, #0, #0x2d63de0                         
02d63db4: adrp    x0, #0x626c000                             
02d63db8: ldr     x0, [x0, #0x78]                            M:Clicker.KeycapObject::<SmallScale>b__18_0
02d63dbc: bl      #0x2b70db0                                 fn_2b70db0
02d63dc0: adrp    x0, #0x6264000                             
02d63dc4: ldr     x0, [x0, #0xe8]                            T:DG.Tweening.TweenCallback
02d63dc8: bl      #0x2b70db0                                 fn_2b70db0
02d63dcc: adrp    x0, #0x6266000                             
02d63dd0: ldr     x0, [x0, #0x928]                           MS:DG.Tweening.TweenSettingsExtensions::OnComplete
02d63dd4: bl      #0x2b70db0                                 fn_2b70db0
02d63dd8: mov     w8, #1                                     
02d63ddc: strb    w8, [x23, #0x311]                          
02d63de0: mov     x0, x19                                    
02d63de4: mov     x1, xzr                                    
02d63de8: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02d63dec: adrp    x8, #0x1084000                             
02d63df0: adrp    x9, #0x1084000                             
02d63df4: mov     x1, xzr                                    
02d63df8: ldr     s0, [x8, #0xcfc]                           [1084cfc]=3e58658c3f8ccccd f=1.1,0.211325
02d63dfc: ldr     s1, [x9, #0xeec]                           [1084eec]=457ff0003dcccccd f=0.1,4095
02d63e00: bl      #0x2d98c98                                 DG.Tweening.ShortcutExtensions::DOScale
02d63e04: ldr     x8, [x20]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d63e08: mov     x20, x0                                    
02d63e0c: mov     x0, x8                                     
02d63e10: bl      #0x2b7104c                                 fn_2b7104c
02d63e14: ldr     x2, [x21]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d63e18: mov     x1, x19                                    
02d63e1c: mov     x3, xzr                                    
02d63e20: mov     x21, x0                                    
02d63e24: bl      #0x2d89dc4                                 DG.Tweening.TweenCallback::.ctor
02d63e28: ldr     x2, [x22]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d63e2c: mov     x0, x20                                    
02d63e30: mov     x1, x21                                    
02d63e34: ldp     x20, x19, [sp, #0x20]                      
02d63e38: ldp     x22, x21, [sp, #0x10]                      
02d63e3c: ldp     x30, x23, [sp], #0x30                      
02d63e40: b       #0x336f26c                                 
## .ctor() -> void
---- Clicker.KeycapObject::.ctor 0x2d63e44
02d63e44: mov     x1, xzr                                    
02d63e48: b       #0x5b397b0                                 UnityEngine.MonoBehaviour::.ctor
## <SmallScale>b__18_0() -> void
---- Clicker.KeycapObject::<SmallScale>b__18_0 0x2d63e4c
02d63e4c: str     x30, [sp, #-0x10]!                         
02d63e50: mov     x1, xzr                                    
02d63e54: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02d63e58: adrp    x8, #0x1084000                             
02d63e5c: fmov    s0, #1.00000000                            
02d63e60: mov     x1, xzr                                    
02d63e64: ldr     s1, [x8, #0xf10]                           [1084f10]=4110bc863e99999a f=0.3,9.04603
02d63e68: ldr     x30, [sp], #0x10                           
02d63e6c: b       #0x2d98c98                                 DG.Tweening.ShortcutExtensions::DOScale
