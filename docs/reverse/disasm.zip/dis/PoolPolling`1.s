#### CLASS PoolPolling`1 parent= object
#   field prefab                         T                                                  off=0x0 attr=21 
#   field pool                           System.Collections.Generic.Queue`1<T>              off=0x0 attr=21 
#   field inuse                          System.Collections.Generic.LinkedList`1<T>         off=0x0 attr=21 
#   field nodePool                       System.Collections.Generic.Queue`1<System.Collections.Generic.LinkedListNode`1<T>> off=0x0 attr=21 
#   field lastCheckFrame                 int                                                off=0x0 attr=1 
##  .ctor (no body)
##  CheckInUse (no body)
##  Get (no body)
##  IsActive (no body)
