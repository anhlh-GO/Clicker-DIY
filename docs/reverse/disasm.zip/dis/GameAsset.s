#### CLASS GameAsset parent= UnityEngine.ScriptableObject
## .ctor() -> void
---- GameAsset::.ctor 0x2cae4f0
02cae4f0: mov     x1, xzr                                    
02cae4f4: b       #0x5b398f0                                 UnityEngine.ScriptableObject::.ctor
