#### CLASS Framework.AdaptiveResolution/AdaptiveInfo parent= object
#   field name                           string                                             off=0x10 attr=6 
#   field minAspect                      float                                              off=0x18 attr=6 
#   field manualSetSize                  bool                                               off=0x1c attr=6 
#   field manualOrthoSize                float                                              off=0x20 attr=6 ConditionalFieldAttribute
#   field manualPerspectiveSize          float                                              off=0x24 attr=6 ConditionalFieldAttribute
## .ctor() -> void
---- Framework.AdaptiveResolution/AdaptiveInfo::.ctor 0x2cc5fb4
02cc5fb4: adrp    x8, #0x1041000                             
02cc5fb8: mov     x1, xzr                                    
02cc5fbc: ldr     d0, [x8, #0x380]                           [1041380]=4270000041200000 f=10,60
02cc5fc0: str     d0, [x0, #0x20]                            .manualOrthoSize
02cc5fc4: b       #0x4e53e9c                                 System.Object::.ctor
#### CLASS Framework.AdaptiveResolution/<>c parent= object
#   field <>9                            Framework.AdaptiveResolution/<>c                   off=0x0 attr=36 
#   field <>9__27_0                      System.Func`2<Framework.AdaptiveResolution/AdaptiveInfo,float> off=0x8 attr=16 
## .cctor() -> void
---- Framework.AdaptiveResolution/<>c::.cctor 0x2cc5fc8
02cc5fc8: str     x30, [sp, #-0x20]!                         
02cc5fcc: stp     x20, x19, [sp, #0x10]                      
02cc5fd0: adrp    x19, #0x662f000                            
02cc5fd4: adrp    x20, #0x6267000                            
02cc5fd8: ldrb    w8, [x19, #0xc4e]                          
02cc5fdc: ldr     x20, [x20, #0x220]                         T:Framework.AdaptiveResolution/<>c
02cc5fe0: tbnz    w8, #0, #0x2cc5ff8                         
02cc5fe4: adrp    x0, #0x6267000                             
02cc5fe8: ldr     x0, [x0, #0x220]                           T:Framework.AdaptiveResolution/<>c
02cc5fec: bl      #0x2b70db0                                 fn_2b70db0
02cc5ff0: mov     w8, #1                                     
02cc5ff4: strb    w8, [x19, #0xc4e]                          
02cc5ff8: ldr     x0, [x20]                                  S:'didu'
02cc5ffc: bl      #0x2b7104c                                 fn_2b7104c
02cc6000: mov     x1, xzr                                    
02cc6004: mov     x19, x0                                    
02cc6008: bl      #0x4e53e9c                                 System.Object::.ctor
02cc600c: ldr     x8, [x20]                                  S:'didu'
02cc6010: mov     x1, x19                                    
02cc6014: ldr     x8, [x8, #0xb8]                            
02cc6018: str     x19, [x8]                                  
02cc601c: ldr     x8, [x20]                                  S:'didu'
02cc6020: ldp     x20, x19, [sp, #0x10]                      
02cc6024: ldr     x0, [x8, #0xb8]                            
02cc6028: ldr     x30, [sp], #0x20                           
02cc602c: b       #0x2b70d54                                 
## .ctor() -> void
---- Framework.AdaptiveResolution/<>c::.ctor 0x2cc6030
02cc6030: mov     x1, xzr                                    
02cc6034: b       #0x4e53e9c                                 System.Object::.ctor
## <Awake>b__27_0(Framework.AdaptiveResolution/AdaptiveInfo info) -> float
---- Framework.AdaptiveResolution/<>c::<Awake>b__27_0 0x2cc6038
02cc6038: cbz     x1, #0x2cc6044                             
02cc603c: ldr     s0, [x1, #0x18]                            
02cc6040: ret                                                
02cc6044: str     x30, [sp, #-0x10]!                         
02cc6048: bl      #0x2b7105c                                 fn_2b7105c
#### CLASS Framework.AdaptiveResolution parent= UnityEngine.MonoBehaviour
#   field OnAdapt                        System.Action`2<float,float>                       off=0x0 attr=11 CompilerGeneratedAttribute
#   field _baseAspect                    float                                              off=0x20 attr=1 HeaderAttribute,SerializeField
#   field _baseOrthoSize                 float                                              off=0x24 attr=1 SerializeField
#   field _basePerspectiveSize           float                                              off=0x28 attr=1 SerializeField
#   field _isInvert                      bool                                               off=0x2c attr=1 SerializeField
#   field _adaptiveInfos                 System.Collections.Generic.List`1<Framework.AdaptiveResolution/AdaptiveInfo> off=0x30 attr=1 HeaderAttribute,SerializeField
#   field OnAdaptOrthoSize               UnityEngine.Events.UnityEvent`1<float>             off=0x38 attr=6 HeaderAttribute
#   field OnAdaptPerspectiveSize         UnityEngine.Events.UnityEvent`1<float>             off=0x40 attr=6 
#   field <CurAspect>k__BackingField     float                                              off=0x48 attr=1 CompilerGeneratedAttribute
#   field <AspectScale>k__BackingField   float                                              off=0x4c attr=1 CompilerGeneratedAttribute
#   field <CurOrthoSize>k__BackingField  float                                              off=0x50 attr=1 CompilerGeneratedAttribute
#   field <CurPerspectiveSize>k__BackingField float                                              off=0x54 attr=1 CompilerGeneratedAttribute
## add_OnAdapt(System.Action`2<float,float> value) -> void
---- Framework.AdaptiveResolution::add_OnAdapt 0x2cc572c
02cc572c: str     x30, [sp, #-0x40]!                         
02cc5730: stp     x24, x23, [sp, #0x10]                      
02cc5734: stp     x22, x21, [sp, #0x20]                      
02cc5738: stp     x20, x19, [sp, #0x30]                      
02cc573c: adrp    x20, #0x662f000                            
02cc5740: adrp    x23, #0x6267000                            
02cc5744: mov     x19, x0                                    
02cc5748: ldrb    w8, [x20, #0xc48]                          
02cc574c: ldr     x23, [x23, #0x210]                         T:Framework.AdaptiveResolution
02cc5750: tbnz    w8, #0, #0x2cc5774                         
02cc5754: adrp    x0, #0x6267000                             
02cc5758: ldr     x0, [x0, #0x218]                           T:type7208(k15)
02cc575c: bl      #0x2b70db0                                 fn_2b70db0
02cc5760: adrp    x0, #0x6267000                             
02cc5764: ldr     x0, [x0, #0x210]                           T:Framework.AdaptiveResolution
02cc5768: bl      #0x2b70db0                                 fn_2b70db0
02cc576c: mov     w8, #1                                     
02cc5770: strb    w8, [x20, #0xc48]                          
02cc5774: ldr     x8, [x23]                                  S:'didu'
02cc5778: adrp    x24, #0x6267000                            
02cc577c: ldr     x8, [x8, #0xb8]                            
02cc5780: ldr     x24, [x24, #0x218]                         T:type7208(k15)
02cc5784: ldr     x20, [x8]                                  
02cc5788: mov     x0, x20                                    
02cc578c: mov     x1, x19                                    
02cc5790: mov     x2, xzr                                    
02cc5794: bl      #0x4e570ac                                 System.Delegate::Combine
02cc5798: cbz     x0, #0x2cc57b8                             
02cc579c: ldr     x22, [x24]                                 S:'didu'
02cc57a0: mov     x21, x0                                    
02cc57a4: mov     x1, x22                                    
02cc57a8: bl      #0x2b70f34                                 fn_2b70f34
02cc57ac: mov     x1, x0                                     
02cc57b0: cbnz    x0, #0x2cc57bc                             
02cc57b4: b       #0x2cc57ec                                 
02cc57b8: mov     x1, xzr                                    
02cc57bc: ldr     x8, [x23]                                  S:'didu'
02cc57c0: mov     x2, x20                                    
02cc57c4: ldr     x0, [x8, #0xb8]                            
02cc57c8: bl      #0x2ba9880                                 fn_2ba9880
02cc57cc: cmp     x0, x20                                    
02cc57d0: mov     x20, x0                                    
02cc57d4: b.ne    #0x2cc5788                                 
02cc57d8: ldp     x20, x19, [sp, #0x30]                      
02cc57dc: ldp     x22, x21, [sp, #0x20]                      
02cc57e0: ldp     x24, x23, [sp, #0x10]                      
02cc57e4: ldr     x30, [sp], #0x40                           
02cc57e8: ret                                                
02cc57ec: mov     x0, x21                                    
02cc57f0: mov     x1, x22                                    
02cc57f4: bl      #0x2b713dc                                 fn_2b713dc
## remove_OnAdapt(System.Action`2<float,float> value) -> void
---- Framework.AdaptiveResolution::remove_OnAdapt 0x2cc57f8
02cc57f8: str     x30, [sp, #-0x40]!                         
02cc57fc: stp     x24, x23, [sp, #0x10]                      
02cc5800: stp     x22, x21, [sp, #0x20]                      
02cc5804: stp     x20, x19, [sp, #0x30]                      
02cc5808: adrp    x20, #0x662f000                            
02cc580c: adrp    x23, #0x6267000                            
02cc5810: mov     x19, x0                                    
02cc5814: ldrb    w8, [x20, #0xc49]                          
02cc5818: ldr     x23, [x23, #0x210]                         T:Framework.AdaptiveResolution
02cc581c: tbnz    w8, #0, #0x2cc5840                         
02cc5820: adrp    x0, #0x6267000                             
02cc5824: ldr     x0, [x0, #0x218]                           T:type7208(k15)
02cc5828: bl      #0x2b70db0                                 fn_2b70db0
02cc582c: adrp    x0, #0x6267000                             
02cc5830: ldr     x0, [x0, #0x210]                           T:Framework.AdaptiveResolution
02cc5834: bl      #0x2b70db0                                 fn_2b70db0
02cc5838: mov     w8, #1                                     
02cc583c: strb    w8, [x20, #0xc49]                          
02cc5840: ldr     x8, [x23]                                  S:'didu'
02cc5844: adrp    x24, #0x6267000                            
02cc5848: ldr     x8, [x8, #0xb8]                            
02cc584c: ldr     x24, [x24, #0x218]                         T:type7208(k15)
02cc5850: ldr     x20, [x8]                                  
02cc5854: mov     x0, x20                                    
02cc5858: mov     x1, x19                                    
02cc585c: mov     x2, xzr                                    
02cc5860: bl      #0x4e57298                                 System.Delegate::Remove
02cc5864: cbz     x0, #0x2cc5884                             
02cc5868: ldr     x22, [x24]                                 S:'didu'
02cc586c: mov     x21, x0                                    
02cc5870: mov     x1, x22                                    
02cc5874: bl      #0x2b70f34                                 fn_2b70f34
02cc5878: mov     x1, x0                                     
02cc587c: cbnz    x0, #0x2cc5888                             
02cc5880: b       #0x2cc58b8                                 
02cc5884: mov     x1, xzr                                    
02cc5888: ldr     x8, [x23]                                  S:'didu'
02cc588c: mov     x2, x20                                    
02cc5890: ldr     x0, [x8, #0xb8]                            
02cc5894: bl      #0x2ba9880                                 fn_2ba9880
02cc5898: cmp     x0, x20                                    
02cc589c: mov     x20, x0                                    
02cc58a0: b.ne    #0x2cc5854                                 
02cc58a4: ldp     x20, x19, [sp, #0x30]                      
02cc58a8: ldp     x22, x21, [sp, #0x20]                      
02cc58ac: ldp     x24, x23, [sp, #0x10]                      
02cc58b0: ldr     x30, [sp], #0x40                           
02cc58b4: ret                                                
02cc58b8: mov     x0, x21                                    
02cc58bc: mov     x1, x22                                    
02cc58c0: bl      #0x2b713dc                                 fn_2b713dc
## get_CurAspect() -> float
---- Framework.AdaptiveResolution::get_CurAspect 0x2cc58c4
02cc58c4: ldr     s0, [x0, #0x48]                            .<CurAspect>k__BackingField
02cc58c8: ret                                                
## set_CurAspect(float value) -> void
---- Framework.AdaptiveResolution::set_CurAspect 0x2cc58cc
02cc58cc: str     s0, [x0, #0x48]                            .<CurAspect>k__BackingField
02cc58d0: ret                                                
## get_AspectScale() -> float
---- Framework.AdaptiveResolution::get_AspectScale 0x2cc58d4
02cc58d4: ldr     s0, [x0, #0x4c]                            .<AspectScale>k__BackingField
02cc58d8: ret                                                
## set_AspectScale(float value) -> void
---- Framework.AdaptiveResolution::set_AspectScale 0x2cc58dc
02cc58dc: str     s0, [x0, #0x4c]                            .<AspectScale>k__BackingField
02cc58e0: ret                                                
## get_CurOrthoSize() -> float
---- Framework.AdaptiveResolution::get_CurOrthoSize 0x2cc58e4
02cc58e4: ldr     s0, [x0, #0x50]                            .<CurOrthoSize>k__BackingField
02cc58e8: ret                                                
## set_CurOrthoSize(float value) -> void
---- Framework.AdaptiveResolution::set_CurOrthoSize 0x2cc58ec
02cc58ec: str     s0, [x0, #0x50]                            .<CurOrthoSize>k__BackingField
02cc58f0: ret                                                
## get_CurPerspectiveSize() -> float
---- Framework.AdaptiveResolution::get_CurPerspectiveSize 0x2cc58f4
02cc58f4: ldr     s0, [x0, #0x54]                            .<CurPerspectiveSize>k__BackingField
02cc58f8: ret                                                
## set_CurPerspectiveSize(float value) -> void
---- Framework.AdaptiveResolution::set_CurPerspectiveSize 0x2cc58fc
02cc58fc: str     s0, [x0, #0x54]                            .<CurPerspectiveSize>k__BackingField
02cc5900: ret                                                
## Awake() -> void
---- Framework.AdaptiveResolution::Awake 0x2cc5904
02cc5904: str     x30, [sp, #-0x50]!                         
02cc5908: stp     x26, x25, [sp, #0x10]                      
02cc590c: stp     x24, x23, [sp, #0x20]                      
02cc5910: stp     x22, x21, [sp, #0x30]                      
02cc5914: stp     x20, x19, [sp, #0x40]                      
02cc5918: adrp    x20, #0x662f000                            
02cc591c: adrp    x24, #0x6267000                            
02cc5920: mov     x19, x0                                    
02cc5924: ldrb    w8, [x20, #0xc4a]                          
02cc5928: ldr     x24, [x24, #0x220]                         T:Framework.AdaptiveResolution/<>c
02cc592c: tbnz    w8, #0, #0x2cc5974                         
02cc5930: adrp    x0, #0x6267000                             
02cc5934: ldr     x0, [x0, #0x228]                           MS:System.Linq.Enumerable::OrderByDescending
02cc5938: bl      #0x2b70db0                                 fn_2b70db0
02cc593c: adrp    x0, #0x6267000                             
02cc5940: ldr     x0, [x0, #0x230]                           MS:System.Linq.Enumerable::ToList
02cc5944: bl      #0x2b70db0                                 fn_2b70db0
02cc5948: adrp    x0, #0x6267000                             
02cc594c: ldr     x0, [x0, #0x238]                           T:type55699(k15)
02cc5950: bl      #0x2b70db0                                 fn_2b70db0
02cc5954: adrp    x0, #0x6267000                             
02cc5958: ldr     x0, [x0, #0x240]                           M:Framework.AdaptiveResolution/<>c::<Awake>b__27_0
02cc595c: bl      #0x2b70db0                                 fn_2b70db0
02cc5960: adrp    x0, #0x6267000                             
02cc5964: ldr     x0, [x0, #0x220]                           T:Framework.AdaptiveResolution/<>c
02cc5968: bl      #0x2b70db0                                 fn_2b70db0
02cc596c: mov     w8, #1                                     
02cc5970: strb    w8, [x20, #0xc4a]                          
02cc5974: ldr     x0, [x24]                                  S:'didu'
02cc5978: mov     x20, x19                                   
02cc597c: ldr     x21, [x20, #0x30]!                         &2b706f8(=d65f03c0b9401800) ._adaptiveInfos
02cc5980: ldr     w8, [x0, #0xe4]                            [62670e4]=0 f=0,0
02cc5984: cbnz    w8, #0x2cc5990                             
02cc5988: bl      #0x2b70f30                                 fn_2b70f30
02cc598c: ldr     x0, [x24]                                  S:'didu'
02cc5990: ldr     x8, [x0, #0xb8]                            M:Framework.SceneUtils/<CRUnloadSceneAsync>d__2::System.Collections.IEnumerator.Reset
02cc5994: adrp    x26, #0x6267000                            
02cc5998: adrp    x25, #0x6267000                            
02cc599c: ldr     x26, [x26, #0x228]                         MS:System.Linq.Enumerable::OrderByDescending
02cc59a0: ldr     x22, [x8, #8]                              
02cc59a4: ldr     x25, [x25, #0x230]                         MS:System.Linq.Enumerable::ToList
02cc59a8: cbnz    x22, #0x2cc5a04                            
02cc59ac: ldr     w9, [x0, #0xe4]                            [62670e4]=0 f=0,0
02cc59b0: cbnz    w9, #0x2cc59c0                             
02cc59b4: bl      #0x2b70f30                                 fn_2b70f30
02cc59b8: ldr     x8, [x24]                                  S:'didu'
02cc59bc: ldr     x8, [x8, #0xb8]                            
02cc59c0: adrp    x9, #0x6267000                             
02cc59c4: ldr     x9, [x9, #0x238]                           T:type55699(k15)
02cc59c8: ldr     x23, [x8]                                  
02cc59cc: ldr     x0, [x9]                                   S:'didu'
02cc59d0: bl      #0x2b7104c                                 fn_2b7104c
02cc59d4: adrp    x8, #0x6267000                             
02cc59d8: mov     x1, x23                                    
02cc59dc: mov     x3, xzr                                    
02cc59e0: ldr     x8, [x8, #0x240]                           M:Framework.AdaptiveResolution/<>c::<Awake>b__27_0
02cc59e4: mov     x22, x0                                    
02cc59e8: ldr     x2, [x8]                                   S:'didu'
02cc59ec: bl      #0x4941b64                                 fn_4941b64
02cc59f0: ldr     x8, [x24]                                  S:'didu'
02cc59f4: mov     x1, x22                                    
02cc59f8: ldr     x0, [x8, #0xb8]                            M:Framework.SceneUtils/<CRUnloadSceneAsync>d__2::System.Collections.IEnumerator.Reset
02cc59fc: str     x22, [x0, #8]!                             
02cc5a00: bl      #0x2b70d54                                 fn_2b70d54
02cc5a04: ldr     x2, [x26]                                  S:'didu'
02cc5a08: mov     x0, x21                                    
02cc5a0c: mov     x1, x22                                    
02cc5a10: bl      #0x318f6f0                                 fn_318f6f0
02cc5a14: ldr     x1, [x25]                                  S:'didu'
02cc5a18: bl      #0x319eb2c                                 fn_319eb2c
02cc5a1c: mov     x1, x0                                     
02cc5a20: str     x0, [x19, #0x30]                           ._adaptiveInfos
02cc5a24: mov     x0, x20                                    
02cc5a28: bl      #0x2b70d54                                 fn_2b70d54
02cc5a2c: mov     x0, x19                                    
02cc5a30: ldp     x20, x19, [sp, #0x40]                      
02cc5a34: ldp     x22, x21, [sp, #0x30]                      
02cc5a38: ldp     x24, x23, [sp, #0x20]                      
02cc5a3c: ldp     x26, x25, [sp, #0x10]                      
02cc5a40: ldr     x30, [sp], #0x50                           
02cc5a44: b       #0x2cc5a48                                 Framework.AdaptiveResolution::Adapt
## Adapt() -> void
---- Framework.AdaptiveResolution::Adapt 0x2cc5a48
02cc5a48: str     x30, [sp, #-0x20]!                         
02cc5a4c: stp     x20, x19, [sp, #0x10]                      
02cc5a50: adrp    x20, #0x662f000                            
02cc5a54: mov     x19, x0                                    
02cc5a58: ldrb    w8, [x20, #0xc4b]                          
02cc5a5c: tbnz    w8, #0, #0x2cc5a80                         
02cc5a60: adrp    x0, #0x6267000                             
02cc5a64: ldr     x0, [x0, #0x210]                           T:Framework.AdaptiveResolution
02cc5a68: bl      #0x2b70db0                                 fn_2b70db0
02cc5a6c: adrp    x0, #0x6267000                             
02cc5a70: ldr     x0, [x0, #0x248]                           MS:UnityEngine.Events.UnityEvent`1::Invoke
02cc5a74: bl      #0x2b70db0                                 fn_2b70db0
02cc5a78: mov     w8, #1                                     
02cc5a7c: strb    w8, [x20, #0xc4b]                          
02cc5a80: mov     x0, xzr                                    
02cc5a84: bl      #0x5afb6fc                                 UnityEngine.Screen::get_width
02cc5a88: mov     w20, w0                                    
02cc5a8c: mov     x0, xzr                                    
02cc5a90: bl      #0x5afb724                                 UnityEngine.Screen::get_height
02cc5a94: cmp     w20, w0                                    
02cc5a98: b.le    #0x2cc5ab4                                 
02cc5a9c: mov     x0, xzr                                    
02cc5aa0: bl      #0x5afb6fc                                 UnityEngine.Screen::get_width
02cc5aa4: mov     w20, w0                                    
02cc5aa8: mov     x0, xzr                                    
02cc5aac: bl      #0x5afb724                                 UnityEngine.Screen::get_height
02cc5ab0: b       #0x2cc5ac8                                 
02cc5ab4: mov     x0, xzr                                    
02cc5ab8: bl      #0x5afb724                                 UnityEngine.Screen::get_height
02cc5abc: mov     w20, w0                                    
02cc5ac0: mov     x0, xzr                                    
02cc5ac4: bl      #0x5afb6fc                                 UnityEngine.Screen::get_width
02cc5ac8: scvtf   s0, w20                                    
02cc5acc: scvtf   s1, w0                                     
02cc5ad0: fdiv    s0, s0, s1                                 
02cc5ad4: ldr     s1, [x19, #0x48]                           .<CurAspect>k__BackingField
02cc5ad8: fcmp    s0, s1                                     
02cc5adc: b.ne    #0x2cc5aec                                 
02cc5ae0: ldp     x20, x19, [sp, #0x10]                      
02cc5ae4: ldr     x30, [sp], #0x20                           
02cc5ae8: ret                                                
02cc5aec: ldr     s1, [x19, #0x20]                           ._baseAspect
02cc5af0: ldrb    w8, [x19, #0x2c]                           ._isInvert
02cc5af4: fdiv    s1, s0, s1                                 
02cc5af8: stp     s0, s1, [x19, #0x48]                       .<CurAspect>k__BackingField
02cc5afc: cbz     w8, #0x2cc5b0c                             
02cc5b00: fmov    s2, #1.00000000                            
02cc5b04: fdiv    s1, s2, s1                                 
02cc5b08: str     s1, [x19, #0x4c]                           .<AspectScale>k__BackingField
02cc5b0c: mov     x0, x19                                    
02cc5b10: bl      #0x2cc5ba4                                 Framework.AdaptiveResolution::GetAdaptiveInfo
02cc5b14: cbz     x0, #0x2cc5ae0                             
02cc5b18: ldrb    w8, [x0, #0x1c]                            
02cc5b1c: cbz     w8, #0x2cc5b28                             
02cc5b20: ldr     d0, [x0, #0x20]                            T:System.IO.FileInfo ._baseAspect
02cc5b24: b       #0x2cc5b34                                 
02cc5b28: ldr     s0, [x19, #0x4c]                           .<AspectScale>k__BackingField
02cc5b2c: ldur    d1, [x19, #0x24]                           ._baseOrthoSize
02cc5b30: fmul    v0.2s, v1.2s, v0.s[0]                      
02cc5b34: adrp    x8, #0x6267000                             
02cc5b38: ldr     x8, [x8, #0x210]                           T:Framework.AdaptiveResolution
02cc5b3c: str     d0, [x19, #0x50]                           .<CurOrthoSize>k__BackingField
02cc5b40: ldr     x8, [x8]                                   S:'didu'
02cc5b44: ldr     x8, [x8, #0xb8]                            M:Framework.SceneUtils/<CRUnloadSceneAsync>d__2::System.Collections.IEnumerator.Reset
02cc5b48: ldr     x8, [x8]                                   S:'didu'
02cc5b4c: cbz     x8, #0x2cc5b64                             
02cc5b50: mov     s1, v0.s[1]                                
02cc5b54: ldr     x9, [x8, #0x18]                            S:'android.content.Intent'
02cc5b58: ldr     x0, [x8, #0x40]                            S:'<color=#'
02cc5b5c: ldr     x1, [x8, #0x28]                            S:'[^A-Za-z0-9_. ]+'
02cc5b60: blr     x9                                         
02cc5b64: ldr     x0, [x19, #0x38]                           .OnAdaptOrthoSize
02cc5b68: cbz     x0, #0x2cc5b80                             
02cc5b6c: adrp    x8, #0x6267000                             
02cc5b70: ldr     x8, [x8, #0x248]                           MS:UnityEngine.Events.UnityEvent`1::Invoke
02cc5b74: ldr     s0, [x19, #0x50]                           .<CurOrthoSize>k__BackingField
02cc5b78: ldr     x1, [x8]                                   S:'didu'
02cc5b7c: bl      #0x3ee6c6c                                 fn_3ee6c6c
02cc5b80: ldr     x0, [x19, #0x40]                           .OnAdaptPerspectiveSize
02cc5b84: cbz     x0, #0x2cc5ae0                             
02cc5b88: adrp    x8, #0x6267000                             
02cc5b8c: ldr     x8, [x8, #0x248]                           MS:UnityEngine.Events.UnityEvent`1::Invoke
02cc5b90: ldr     s0, [x19, #0x54]                           .<CurPerspectiveSize>k__BackingField
02cc5b94: ldp     x20, x19, [sp, #0x10]                      
02cc5b98: ldr     x1, [x8]                                   S:'didu'
02cc5b9c: ldr     x30, [sp], #0x20                           
02cc5ba0: b       #0x3ee6c6c                                 
## GetAdaptiveInfo(float curAspect) -> Framework.AdaptiveResolution/AdaptiveInfo
---- Framework.AdaptiveResolution::GetAdaptiveInfo 0x2cc5ba4
02cc5ba4: sub     sp, sp, #0x60                              
02cc5ba8: str     d8, [sp, #0x30]                            
02cc5bac: stp     x30, x21, [sp, #0x40]                      
02cc5bb0: stp     x20, x19, [sp, #0x50]                      
02cc5bb4: fmov    s8, s0                                     
02cc5bb8: adrp    x20, #0x662f000                            
02cc5bbc: mov     x19, x0                                    
02cc5bc0: ldrb    w8, [x20, #0xc4c]                          
02cc5bc4: tbnz    w8, #0, #0x2cc5c00                         
02cc5bc8: adrp    x0, #0x6267000                             
02cc5bcc: ldr     x0, [x0, #0x250]                           MS:System.Collections.Generic.List`1/Enumerator::Dispose
02cc5bd0: bl      #0x2b70db0                                 fn_2b70db0
02cc5bd4: adrp    x0, #0x6267000                             
02cc5bd8: ldr     x0, [x0, #0x258]                           MS:System.Collections.Generic.List`1/Enumerator::MoveNext
02cc5bdc: bl      #0x2b70db0                                 fn_2b70db0
02cc5be0: adrp    x0, #0x6267000                             
02cc5be4: ldr     x0, [x0, #0x260]                           MS:System.Collections.Generic.List`1/Enumerator::get_Current
02cc5be8: bl      #0x2b70db0                                 fn_2b70db0
02cc5bec: adrp    x0, #0x6267000                             
02cc5bf0: ldr     x0, [x0, #0x268]                           MS:System.Collections.Generic.List`1::GetEnumerator
02cc5bf4: bl      #0x2b70db0                                 fn_2b70db0
02cc5bf8: mov     w8, #1                                     
02cc5bfc: strb    w8, [x20, #0xc4c]                          
02cc5c00: ldr     x0, [x19, #0x30]                           ._adaptiveInfos
02cc5c04: stp     xzr, xzr, [sp, #0x18]                      
02cc5c08: str     xzr, [sp, #0x28]                           
02cc5c0c: cbz     x0, #0x2cc5c90                             
02cc5c10: adrp    x8, #0x6267000                             
02cc5c14: adrp    x21, #0x6267000                            
02cc5c18: adrp    x20, #0x6267000                            
02cc5c1c: ldr     x8, [x8, #0x268]                           MS:System.Collections.Generic.List`1::GetEnumerator
02cc5c20: ldr     x21, [x21, #0x258]                         MS:System.Collections.Generic.List`1/Enumerator::MoveNext
02cc5c24: ldr     x20, [x20, #0x250]                         MS:System.Collections.Generic.List`1/Enumerator::Dispose
02cc5c28: add     x19, sp, #0x18                             
02cc5c2c: ldr     x1, [x8]                                   S:'didu'
02cc5c30: add     x8, sp, #0x18                              
02cc5c34: bl      #0x35a9d9c                                 fn_35a9d9c
02cc5c38: stp     xzr, x19, [sp, #8]                         
02cc5c3c: ldr     x1, [x21]                                  S:'didu'
02cc5c40: add     x0, sp, #0x18                              
02cc5c44: bl      #0x4690474                                 fn_4690474
02cc5c48: tbz     w0, #0, #0x2cc5c64                         
02cc5c4c: ldr     x19, [sp, #0x28]                           
02cc5c50: cbz     x19, #0x2cc5c8c                            
02cc5c54: ldr     s0, [x19, #0x18]                           
02cc5c58: fcmp    s0, s8                                     
02cc5c5c: b.pl    #0x2cc5c3c                                 
02cc5c60: b       #0x2cc5c68                                 
02cc5c64: mov     x19, xzr                                   
02cc5c68: ldr     x1, [x20]                                  S:'didu'
02cc5c6c: add     x0, sp, #0x18                              
02cc5c70: bl      #0x4690470                                 fn_4690470
02cc5c74: mov     x0, x19                                    
02cc5c78: ldp     x20, x19, [sp, #0x50]                      
02cc5c7c: ldp     x30, x21, [sp, #0x40]                      
02cc5c80: ldr     d8, [sp, #0x30]                            
02cc5c84: add     sp, sp, #0x60                              
02cc5c88: ret                                                
02cc5c8c: bl      #0x2b7105c                                 fn_2b7105c
02cc5c90: bl      #0x2b7105c                                 fn_2b7105c
02cc5c94: b       #0x2cc5c98                                 
02cc5c98: mov     x19, x0                                    
02cc5c9c: cmp     w1, #1                                     
02cc5ca0: b.ne    #0x2cc5cd4                                 
02cc5ca4: mov     x0, x19                                    
02cc5ca8: bl      #0x5e90260                                 fn_5e90260
02cc5cac: ldr     x19, [x0]                                  S:'didu'
02cc5cb0: str     x19, [sp, #8]                              
02cc5cb4: bl      #0x5e90270                                 fn_5e90270
02cc5cb8: ldr     x0, [sp, #0x10]                            
02cc5cbc: ldr     x1, [x20]                                  S:'didu'
02cc5cc0: bl      #0x4690470                                 fn_4690470
02cc5cc4: cbz     x19, #0x2cc5c74                            
02cc5cc8: mov     x0, x19                                    
02cc5ccc: bl      #0x2b71054                                 fn_2b71054
02cc5cd0: mov     x19, x0                                    
02cc5cd4: add     x0, sp, #8                                 
02cc5cd8: bl      #0x273712c                                 fn_273712c
02cc5cdc: mov     x0, x19                                    
02cc5ce0: bl      #0x2c6051c                                 fn_2c6051c
02cc5ce4: bl      #0x27369b8                                 fn_27369b8
## .ctor() -> void
---- Framework.AdaptiveResolution::.ctor 0x2cc5ce8
02cc5ce8: str     d8, [sp, #-0x40]!                          
02cc5cec: str     x30, [sp, #8]                              
02cc5cf0: stp     x24, x23, [sp, #0x10]                      
02cc5cf4: stp     x22, x21, [sp, #0x20]                      
02cc5cf8: stp     x20, x19, [sp, #0x30]                      
02cc5cfc: adrp    x21, #0x6267000                            
02cc5d00: adrp    x24, #0x662f000                            
02cc5d04: adrp    x20, #0x6267000                            
02cc5d08: adrp    x22, #0x6267000                            
02cc5d0c: adrp    x23, #0x6267000                            
02cc5d10: ldr     x21, [x21, #0x270]                         T:type56870(k15)
02cc5d14: ldr     x20, [x20, #0x278]                         MS:System.Collections.Generic.List`1::.ctor
02cc5d18: ldrb    w8, [x24, #0xc4d]                          
02cc5d1c: ldr     x22, [x22, #0x280]                         T:Framework.AdaptiveResolution/AdaptiveInfo
02cc5d20: ldr     x23, [x23, #0x288]                         S:'IphoneX'
02cc5d24: mov     x19, x0                                    
02cc5d28: tbnz    w8, #0, #0x2cc5d88                         
02cc5d2c: adrp    x0, #0x6267000                             
02cc5d30: ldr     x0, [x0, #0x280]                           T:Framework.AdaptiveResolution/AdaptiveInfo
02cc5d34: bl      #0x2b70db0                                 fn_2b70db0
02cc5d38: adrp    x0, #0x6267000                             
02cc5d3c: ldr     x0, [x0, #0x290]                           MS:System.Collections.Generic.List`1::Add
02cc5d40: bl      #0x2b70db0                                 fn_2b70db0
02cc5d44: adrp    x0, #0x6267000                             
02cc5d48: ldr     x0, [x0, #0x278]                           MS:System.Collections.Generic.List`1::.ctor
02cc5d4c: bl      #0x2b70db0                                 fn_2b70db0
02cc5d50: adrp    x0, #0x6267000                             
02cc5d54: ldr     x0, [x0, #0x270]                           T:type56870(k15)
02cc5d58: bl      #0x2b70db0                                 fn_2b70db0
02cc5d5c: adrp    x0, #0x6267000                             
02cc5d60: ldr     x0, [x0, #0x298]                           S:'Iphone8'
02cc5d64: bl      #0x2b70db0                                 fn_2b70db0
02cc5d68: adrp    x0, #0x6267000                             
02cc5d6c: ldr     x0, [x0, #0x2a0]                           S:'Ipad'
02cc5d70: bl      #0x2b70db0                                 fn_2b70db0
02cc5d74: adrp    x0, #0x6267000                             
02cc5d78: ldr     x0, [x0, #0x288]                           S:'IphoneX'
02cc5d7c: bl      #0x2b70db0                                 fn_2b70db0
02cc5d80: mov     w8, #1                                     
02cc5d84: strb    w8, [x24, #0xc4d]                          
02cc5d88: adrp    x8, #0x1040000                             
02cc5d8c: ldr     x0, [x21]                                  S:'didu'
02cc5d90: ldr     d0, [x8, #0x400]                           [1040400]=412000003fe38e39 f=1.77778,10
02cc5d94: mov     w8, #0x42700000                            
02cc5d98: str     w8, [x19, #0x28]                           ._basePerspectiveSize
02cc5d9c: str     d0, [x19, #0x20]                           ._baseAspect
02cc5da0: bl      #0x2b7104c                                 fn_2b7104c
02cc5da4: ldr     x1, [x20]                                  S:'didu'
02cc5da8: mov     x20, x0                                    
02cc5dac: bl      #0x35a89a4                                 fn_35a89a4
02cc5db0: ldr     x0, [x22]                                  S:'didu'
02cc5db4: bl      #0x2b7104c                                 fn_2b7104c
02cc5db8: adrp    x8, #0x1041000                             
02cc5dbc: mov     x1, xzr                                    
02cc5dc0: mov     x21, x0                                    
02cc5dc4: ldr     d8, [x8, #0x380]                           [1041380]=4270000041200000 f=10,60
02cc5dc8: str     d8, [x0, #0x20]                            ._baseAspect
02cc5dcc: bl      #0x4e53e9c                                 System.Object::.ctor
02cc5dd0: ldr     x1, [x23]                                  S:'didu'
02cc5dd4: mov     x0, x21                                    
02cc5dd8: str     x1, [x0, #0x10]!                           
02cc5ddc: bl      #0x2b70d54                                 fn_2b70d54
02cc5de0: mov     w8, #0x40000000                            
02cc5de4: str     w8, [x21, #0x18]                           
02cc5de8: cbz     x20, #0x2cc5fb0                            
02cc5dec: adrp    x23, #0x6267000                            
02cc5df0: ldr     x23, [x23, #0x290]                         MS:System.Collections.Generic.List`1::Add
02cc5df4: ldr     w10, [x20, #0x1c]                          [626701c]=0 f=0,0
02cc5df8: ldr     x8, [x20, #0x10]                           S:'startActivity'
02cc5dfc: ldr     x9, [x23]                                  S:'didu'
02cc5e00: add     w10, w10, #1                               
02cc5e04: str     w10, [x20, #0x1c]                          
02cc5e08: cbz     x8, #0x2cc5fb0                             
02cc5e0c: ldrsw   x10, [x20, #0x18]                          
02cc5e10: ldr     w11, [x8, #0x18]                           [1041018]=64000001f4 f=7.00649e-43,1.4013e-43
02cc5e14: adrp    x24, #0x6267000                            
02cc5e18: ldr     x24, [x24, #0x298]                         S:'Iphone8'
02cc5e1c: cmp     w10, w11                                   
02cc5e20: b.hs    #0x2cc5e40                                 
02cc5e24: add     x0, x8, x10, lsl #3                        &1041000
02cc5e28: add     w9, w10, #1                                
02cc5e2c: mov     x1, x21                                    
02cc5e30: str     w9, [x20, #0x18]                           
02cc5e34: str     x21, [x0, #0x20]!                          ._baseAspect
02cc5e38: bl      #0x2b70d54                                 fn_2b70d54
02cc5e3c: b       #0x2cc5e58                                 
02cc5e40: ldr     x8, [x9, #0x20]                            
02cc5e44: mov     x0, x20                                    
02cc5e48: mov     x1, x21                                    
02cc5e4c: ldr     x8, [x8, #0xc0]                            [10410c0]=3c00000003 f=4.2039e-45,8.40779e-44
02cc5e50: ldr     x2, [x8, #0x70]                            [1041070]=f000000002 f=2.8026e-45,3.36312e-43
02cc5e54: bl      #0x35a920c                                 fn_35a920c
02cc5e58: ldr     x0, [x22]                                  S:'didu'
02cc5e5c: bl      #0x2b7104c                                 fn_2b7104c
02cc5e60: mov     x1, xzr                                    
02cc5e64: mov     x21, x0                                    
02cc5e68: str     d8, [x0, #0x20]                            ._baseAspect
02cc5e6c: bl      #0x4e53e9c                                 System.Object::.ctor
02cc5e70: ldr     x1, [x24]                                  S:'didu'
02cc5e74: mov     x0, x21                                    
02cc5e78: str     x1, [x0, #0x10]!                           
02cc5e7c: bl      #0x2b70d54                                 fn_2b70d54
02cc5e80: mov     w9, #0x999a                                
02cc5e84: ldr     w10, [x20, #0x1c]                          [626701c]=0 f=0,0
02cc5e88: ldr     x8, [x20, #0x10]                           S:'startActivity'
02cc5e8c: movk    w9, #0x3fd9, lsl #16                       
02cc5e90: str     w9, [x21, #0x18]                           
02cc5e94: ldr     x9, [x23]                                  S:'didu'
02cc5e98: add     w10, w10, #1                               
02cc5e9c: str     w10, [x20, #0x1c]                          
02cc5ea0: cbz     x8, #0x2cc5fb0                             
02cc5ea4: ldrsw   x10, [x20, #0x18]                          
02cc5ea8: ldr     w11, [x8, #0x18]                           [1041018]=64000001f4 f=7.00649e-43,1.4013e-43
02cc5eac: adrp    x24, #0x6267000                            
02cc5eb0: ldr     x24, [x24, #0x2a0]                         S:'Ipad'
02cc5eb4: cmp     w10, w11                                   
02cc5eb8: b.hs    #0x2cc5ed8                                 
02cc5ebc: add     x0, x8, x10, lsl #3                        &1041000
02cc5ec0: add     w9, w10, #1                                
02cc5ec4: mov     x1, x21                                    
02cc5ec8: str     w9, [x20, #0x18]                           
02cc5ecc: str     x21, [x0, #0x20]!                          ._baseAspect
02cc5ed0: bl      #0x2b70d54                                 fn_2b70d54
02cc5ed4: b       #0x2cc5ef0                                 
02cc5ed8: ldr     x8, [x9, #0x20]                            
02cc5edc: mov     x0, x20                                    
02cc5ee0: mov     x1, x21                                    
02cc5ee4: ldr     x8, [x8, #0xc0]                            [10410c0]=3c00000003 f=4.2039e-45,8.40779e-44
02cc5ee8: ldr     x2, [x8, #0x70]                            [1041070]=f000000002 f=2.8026e-45,3.36312e-43
02cc5eec: bl      #0x35a920c                                 fn_35a920c
02cc5ef0: ldr     x0, [x22]                                  S:'didu'
02cc5ef4: bl      #0x2b7104c                                 fn_2b7104c
02cc5ef8: mov     x1, xzr                                    
02cc5efc: mov     x21, x0                                    
02cc5f00: str     d8, [x0, #0x20]                            ._baseAspect
02cc5f04: bl      #0x4e53e9c                                 System.Object::.ctor
02cc5f08: ldr     x1, [x24]                                  S:'didu'
02cc5f0c: mov     x0, x21                                    
02cc5f10: str     x1, [x0, #0x10]!                           
02cc5f14: bl      #0x2b70d54                                 fn_2b70d54
02cc5f18: mov     w9, #0x6666                                
02cc5f1c: ldr     w10, [x20, #0x1c]                          [626701c]=0 f=0,0
02cc5f20: ldr     x8, [x20, #0x10]                           S:'startActivity'
02cc5f24: movk    w9, #0x3fa6, lsl #16                       
02cc5f28: str     w9, [x21, #0x18]                           
02cc5f2c: ldr     x9, [x23]                                  S:'didu'
02cc5f30: add     w10, w10, #1                               
02cc5f34: str     w10, [x20, #0x1c]                          
02cc5f38: cbz     x8, #0x2cc5fb0                             
02cc5f3c: ldrsw   x10, [x20, #0x18]                          
02cc5f40: ldr     w11, [x8, #0x18]                           [1041018]=64000001f4 f=7.00649e-43,1.4013e-43
02cc5f44: cmp     w10, w11                                   
02cc5f48: b.hs    #0x2cc5f68                                 
02cc5f4c: add     x0, x8, x10, lsl #3                        &1041000
02cc5f50: add     w9, w10, #1                                
02cc5f54: mov     x1, x21                                    
02cc5f58: str     w9, [x20, #0x18]                           
02cc5f5c: str     x21, [x0, #0x20]!                          ._baseAspect
02cc5f60: bl      #0x2b70d54                                 fn_2b70d54
02cc5f64: b       #0x2cc5f80                                 
02cc5f68: ldr     x8, [x9, #0x20]                            
02cc5f6c: mov     x0, x20                                    
02cc5f70: mov     x1, x21                                    
02cc5f74: ldr     x8, [x8, #0xc0]                            [10410c0]=3c00000003 f=4.2039e-45,8.40779e-44
02cc5f78: ldr     x2, [x8, #0x70]                            [1041070]=f000000002 f=2.8026e-45,3.36312e-43
02cc5f7c: bl      #0x35a920c                                 fn_35a920c
02cc5f80: mov     x0, x19                                    
02cc5f84: mov     x1, x20                                    
02cc5f88: str     x20, [x0, #0x30]!                          ._adaptiveInfos
02cc5f8c: bl      #0x2b70d54                                 fn_2b70d54
02cc5f90: mov     x0, x19                                    
02cc5f94: ldp     x20, x19, [sp, #0x30]                      
02cc5f98: ldp     x22, x21, [sp, #0x20]                      
02cc5f9c: mov     x1, xzr                                    
02cc5fa0: ldp     x24, x23, [sp, #0x10]                      
02cc5fa4: ldr     x30, [sp, #8]                              
02cc5fa8: ldr     d8, [sp], #0x40                            
02cc5fac: b       #0x5b397b0                                 UnityEngine.MonoBehaviour::.ctor
02cc5fb0: bl      #0x2b7105c                                 fn_2b7105c
