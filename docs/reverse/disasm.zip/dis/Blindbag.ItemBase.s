#### CLASS Blindbag.ItemBase/<>c__DisplayClass12_0 parent= object
#   field <>4__this                      Blindbag.ItemBase                                  off=0x10 attr=6 
#   field item                           UnityEngine.Transform                              off=0x18 attr=6 
## .ctor() -> void
---- Blindbag.ItemBase/<>c__DisplayClass12_0::.ctor 0x2d53f40
02d53f40: mov     x1, xzr                                    
02d53f44: b       #0x4e53e9c                                 System.Object::.ctor
## <Shake>b__0() -> void
---- Blindbag.ItemBase/<>c__DisplayClass12_0::<Shake>b__0 0x2d5401c
02d5401c: str     x30, [sp, #-0x20]!                         
02d54020: stp     x20, x19, [sp, #0x10]                      
02d54024: ldr     x8, [x0, #0x10]                            .<>4__this
02d54028: cbz     x8, #0x2d54084                             
02d5402c: adrp    x20, #0x662f000                            
02d54030: ldr     x19, [x0, #0x18]                           .item
02d54034: strb    wzr, [x8, #0x40]                           
02d54038: ldrb    w9, [x20, #0x91a]                          
02d5403c: cbnz    w9, #0x2d54054                             
02d54040: adrp    x0, #0x6264000                             
02d54044: ldr     x0, [x0, #0xd8]                            T:UnityEngine.Vector3
02d54048: bl      #0x2b70db0                                 fn_2b70db0
02d5404c: mov     w8, #1                                     
02d54050: strb    w8, [x20, #0x91a]                          
02d54054: cbz     x19, #0x2d54084                            
02d54058: adrp    x8, #0x6264000                             
02d5405c: mov     x0, x19                                    
02d54060: mov     x1, xzr                                    
02d54064: ldr     x8, [x8, #0xd8]                            T:UnityEngine.Vector3
02d54068: ldp     x20, x19, [sp, #0x10]                      
02d5406c: ldr     x8, [x8]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d54070: ldr     x8, [x8, #0xb8]                            MS:DG.Tweening.Core.Extensions::SetSpecialStartupMode
02d54074: ldp     s0, s1, [x8]                               
02d54078: ldr     s2, [x8, #8]                               T:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass2_0
02d5407c: ldr     x30, [sp], #0x20                           
02d54080: b       #0x5b46ac4                                 UnityEngine.Transform::set_eulerAngles
02d54084: bl      #0x2b7105c                                 fn_2b7105c
#### CLASS Blindbag.ItemBase/<OnMouseButtonDown>d__13 parent= System.ValueType
#   field <>1__state                     int                                                off=0x10 attr=6 
#   field <>t__builder                   System.Runtime.CompilerServices.AsyncVoidMethodBuilder off=0x18 attr=6 
#   field <>4__this                      Blindbag.ItemBase                                  off=0x38 attr=6 
#   field <selectedItem>5__2             Spine.Unity.SkeletonAnimation                      off=0x40 attr=1 
#   field <data>5__3                     Blindbag.PointData                                 off=0x48 attr=1 
#   field <>u__1                         Cysharp.Threading.Tasks.UniTask/Awaiter            off=0x50 attr=1 
## MoveNext() -> void
---- Blindbag.ItemBase/<OnMouseButtonDown>d__13::MoveNext 0x2d54088
02d54088: sub     sp, sp, #0x90                              
02d5408c: str     d8, [sp, #0x30]                            
02d54090: stp     x30, x27, [sp, #0x40]                      
02d54094: stp     x26, x25, [sp, #0x50]                      
02d54098: stp     x24, x23, [sp, #0x60]                      
02d5409c: stp     x22, x21, [sp, #0x70]                      
02d540a0: stp     x20, x19, [sp, #0x80]                      
02d540a4: adrp    x20, #0x6630000                            
02d540a8: mov     x19, x0                                    
02d540ac: ldrb    w8, [x20, #0x26e]                          
02d540b0: tbnz    w8, #0, #0x2d54158                         
02d540b4: adrp    x0, #0x626b000                             
02d540b8: ldr     x0, [x0, #0x998]                           MS:System.Runtime.CompilerServices.AsyncVoidMethodBuilder::AwaitUnsafeOnCompleted
02d540bc: bl      #0x2b70db0                                 fn_2b70db0
02d540c0: adrp    x0, #0x6266000                             
02d540c4: ldr     x0, [x0, #0x750]                           MS:DataManager::GetData
02d540c8: bl      #0x2b70db0                                 fn_2b70db0
02d540cc: adrp    x0, #0x626b000                             
02d540d0: ldr     x0, [x0, #0x9a0]                           MS:Blindbag.ItemBase::CreateItem
02d540d4: bl      #0x2b70db0                                 fn_2b70db0
02d540d8: adrp    x0, #0x626b000                             
02d540dc: ldr     x0, [x0, #0x978]                           MS:System.Collections.Generic.List`1::get_Item
02d540e0: bl      #0x2b70db0                                 fn_2b70db0
02d540e4: adrp    x0, #0x6266000                             
02d540e8: ldr     x0, [x0, #0x9f0]                           T:Assets.SimpleLocalization.Scripts.LocalizationManager
02d540ec: bl      #0x2b70db0                                 fn_2b70db0
02d540f0: adrp    x0, #0x626a000                             
02d540f4: ldr     x0, [x0, #0x730]                           MS:MonoSingleton`1::get_Instance
02d540f8: bl      #0x2b70db0                                 fn_2b70db0
02d540fc: adrp    x0, #0x6267000                             
02d54100: ldr     x0, [x0, #0xbd0]                           MS:MonoSingleton`1::get_Instance
02d54104: bl      #0x2b70db0                                 fn_2b70db0
02d54108: adrp    x0, #0x6266000                             
02d5410c: ldr     x0, [x0, #0x658]                           MS:MonoSingleton`1::get_Instance
02d54110: bl      #0x2b70db0                                 fn_2b70db0
02d54114: adrp    x0, #0x6267000                             
02d54118: ldr     x0, [x0, #0xd38]                           MS:DG.Tweening.TweenSettingsExtensions::SetEase
02d5411c: bl      #0x2b70db0                                 fn_2b70db0
02d54120: adrp    x0, #0x6266000                             
02d54124: ldr     x0, [x0, #0x880]                           MS:DG.Tweening.TweenSettingsExtensions::SetEase
02d54128: bl      #0x2b70db0                                 fn_2b70db0
02d5412c: adrp    x0, #0x6269000                             
02d54130: ldr     x0, [x0, #0xb40]                           MS:UIManager::ShowPopup
02d54134: bl      #0x2b70db0                                 fn_2b70db0
02d54138: adrp    x0, #0x6266000                             
02d5413c: ldr     x0, [x0, #0xcc8]                           T:Cysharp.Threading.Tasks.UniTask
02d54140: bl      #0x2b70db0                                 fn_2b70db0
02d54144: adrp    x0, #0x6267000                             
02d54148: ldr     x0, [x0, #0xea8]                           T:Framework.Vibration
02d5414c: bl      #0x2b70db0                                 fn_2b70db0
02d54150: mov     w8, #1                                     
02d54154: strb    w8, [x20, #0x26e]                          
02d54158: ldr     w8, [x19]                                  
02d5415c: ldr     x20, [x19, #0x28]                          
02d54160: adrp    x25, #0x662f000                            
02d54164: stp     xzr, xzr, [sp, #0x10]                      
02d54168: str     wzr, [sp, #8]                              
02d5416c: cbz     w8, #0x2d54190                             
02d54170: cmp     w8, #1                                     
02d54174: b.ne    #0x2d54214                                 
02d54178: ldr     q0, [x19, #0x40]                           .<selectedItem>5__2
02d5417c: mov     w8, #-1                                    
02d54180: stp     xzr, xzr, [x19, #0x40]                     .<selectedItem>5__2
02d54184: str     w8, [x19]                                  
02d54188: str     q0, [sp, #0x10]                            
02d5418c: b       #0x2d54a34                                 
02d54190: ldr     q0, [x19, #0x40]                           .<selectedItem>5__2
02d54194: mov     w8, #-1                                    
02d54198: stp     xzr, xzr, [x19, #0x40]                     .<selectedItem>5__2
02d5419c: str     w8, [x19]                                  
02d541a0: str     q0, [sp, #0x10]                            
02d541a4: ldrb    w8, [x25, #0xbde]                          
02d541a8: cbnz    w8, #0x2d541c0                             
02d541ac: adrp    x0, #0x6266000                             
02d541b0: ldr     x0, [x0, #0xcd0]                           T:Cysharp.Threading.Tasks.IUniTaskSource
02d541b4: bl      #0x2b70db0                                 fn_2b70db0
02d541b8: mov     w8, #1                                     
02d541bc: strb    w8, [x25, #0xbde]                          
02d541c0: ldr     x21, [sp, #0x10]                           
02d541c4: cbz     x21, #0x2d547b4                            
02d541c8: adrp    x10, #0x6266000                            
02d541cc: ldr     x8, [x21]                                  
02d541d0: ldr     x10, [x10, #0xcd0]                         T:Cysharp.Threading.Tasks.IUniTaskSource
02d541d4: ldrh    w22, [sp, #0x18]                           
02d541d8: ldrh    w9, [x8, #0x12e]                           
02d541dc: ldr     x1, [x10]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d541e0: cbz     x9, #0x2d54204                             
02d541e4: ldr     x10, [x8, #0xb0]                           
02d541e8: add     x10, x10, #8                               &6266008
02d541ec: ldur    x11, [x10, #-8]                            
02d541f0: cmp     x11, x1                                    
02d541f4: b.eq    #0x2d54794                                 
02d541f8: subs    x9, x9, #1                                 
02d541fc: add     x10, x10, #0x10                            &6266010
02d54200: b.ne    #0x2d541ec                                 
02d54204: mov     x0, x21                                    
02d54208: mov     w2, #2                                     
02d5420c: bl      #0x2baa05c                                 fn_2baa05c
02d54210: b       #0x2d547a4                                 
02d54214: mov     x0, xzr                                    
02d54218: bl      #0x2d6eec8                                 Framework.AudioManager::get_Instance
02d5421c: cbz     x0, #0x2d54bdc                             
02d54220: movi    d1, #0000000000000000                      
02d54224: movi    d2, #0000000000000000                      
02d54228: mov     w1, #0x11                                  
02d5422c: fmov    s0, #1.00000000                            
02d54230: mov     w2, wzr                                    
02d54234: mov     w3, wzr                                    
02d54238: mov     x4, xzr                                    
02d5423c: bl      #0x2d6f03c                                 Framework.AudioManager::PlaySound
02d54240: cbz     x20, #0x2d54be0                            
02d54244: mov     x0, x20                                    
02d54248: bl      #0x2d53ab0                                 Blindbag.ItemBase::GetNearestItemToClick
02d5424c: mov     x1, x0                                     
02d54250: cbnz    x1, #0x2d54274                             
02d54254: ldr     x0, [x20, #0x38]                           .<>4__this
02d54258: cbz     x0, #0x2d54c08                             
02d5425c: adrp    x8, #0x626b000                             
02d54260: ldr     x8, [x8, #0x978]                           MS:System.Collections.Generic.List`1::get_Item
02d54264: ldr     x2, [x8]                                   T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d54268: mov     w1, wzr                                    
02d5426c: bl      #0x35a8f3c                                 fn_35a8f3c
02d54270: mov     x1, x0                                     
02d54274: mov     x22, x19                                   
02d54278: str     x1, [x22, #0x30]!                          
02d5427c: mov     x0, x22                                    
02d54280: bl      #0x2b70d54                                 fn_2b70d54
02d54284: ldr     x8, [x20, #0x50]                           .<>u__1
02d54288: cbz     x8, #0x2d54be4                             
02d5428c: ldr     x0, [x8, #0x38]                            MS:UnityEngine.Component::GetComponent
02d54290: cbz     x0, #0x2d54be8                             
02d54294: bl      #0x2d4f21c                                 Blindbag.Basket::IsFull
02d54298: tbz     w0, #0, #0x2d542c8                         
02d5429c: ldr     x0, [x22]                                  
02d542a0: cbz     x0, #0x2d54bec                             
02d542a4: mov     x1, xzr                                    
02d542a8: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02d542ac: mov     x1, x0                                     
02d542b0: mov     x0, x20                                    
02d542b4: bl      #0x2d53d2c                                 Blindbag.ItemBase::Shake
02d542b8: ldr     x0, [x20, #0x50]                           .<>u__1
02d542bc: cbz     x0, #0x2d54bf8                             
02d542c0: bl      #0x2d50f7c                                 Blindbag.BlindbagGameController::FullBasketTrigger
02d542c4: b       #0x2d54acc                                 
02d542c8: ldr     x8, [x20, #0x50]                           .<>u__1
02d542cc: cbz     x8, #0x2d54bf0                             
02d542d0: ldr     x0, [x8, #0x38]                            MS:UnityEngine.Component::GetComponent
02d542d4: cbz     x0, #0x2d54bf4                             
02d542d8: bl      #0x2d4f9f8                                 Blindbag.Basket::GetReviewPrice
02d542dc: ldr     x8, [x20, #0x58]                           
02d542e0: cbz     x8, #0x2d54bfc                             
02d542e4: adrp    x9, #0x6266000                             
02d542e8: mov     w21, w0                                    
02d542ec: ldr     x9, [x9, #0x658]                           MS:MonoSingleton`1::get_Instance
02d542f0: ldr     w23, [x8, #0x18]                           T:type57265(k15)
02d542f4: ldr     x0, [x9]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d542f8: bl      #0x3769600                                 fn_3769600
02d542fc: cbz     x0, #0x2d54c00                             
02d54300: adrp    x8, #0x6266000                             
02d54304: ldr     x8, [x8, #0x750]                           MS:DataManager::GetData
02d54308: ldr     x1, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d5430c: bl      #0x3168dd0                                 fn_3168dd0
02d54310: cbz     x0, #0x2d54c04                             
02d54314: mov     x1, xzr                                    
02d54318: bl      #0x2cabaf8                                 DataUser::GetMoney
02d5431c: add     w8, w23, w21                               
02d54320: cmp     w8, w0                                     
02d54324: b.le    #0x2d54398                                 
02d54328: ldr     x0, [x22]                                  
02d5432c: cbz     x0, #0x2d54c0c                             
02d54330: mov     x1, xzr                                    
02d54334: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02d54338: mov     x1, x0                                     
02d5433c: mov     x0, x20                                    
02d54340: bl      #0x2d53d2c                                 Blindbag.ItemBase::Shake
02d54344: adrp    x8, #0x6267000                             
02d54348: ldr     x8, [x8, #0xea8]                           T:Framework.Vibration
02d5434c: ldr     x0, [x8]                                   S:'didu'
02d54350: ldr     w8, [x0, #0xe4]                            [62660e4]=0 f=0,0
02d54354: cbnz    w8, #0x2d5435c                             
02d54358: bl      #0x2b70f30                                 fn_2b70f30
02d5435c: mov     w0, #0x64                                  
02d54360: mov     w1, #-1                                    
02d54364: mov     w2, wzr                                    
02d54368: mov     x3, xzr                                    
02d5436c: bl      #0x2d6e144                                 Framework.Vibration::Vibrate
02d54370: adrp    x8, #0x6267000                             
02d54374: ldr     x8, [x8, #0xbd0]                           MS:MonoSingleton`1::get_Instance
02d54378: ldr     x0, [x8]                                   S:'didu'
02d5437c: bl      #0x3769600                                 fn_3769600
02d54380: cbz     x0, #0x2d54c1c                             
02d54384: adrp    x8, #0x6269000                             
02d54388: ldr     x8, [x8, #0xb40]                           MS:UIManager::ShowPopup
02d5438c: ldr     x1, [x8]                                   T:Trading.TradingSession/<>c__DisplayClass56_0
02d54390: bl      #0x33fbfac                                 fn_33fbfac
02d54394: b       #0x2d54acc                                 
02d54398: adrp    x8, #0x626a000                             
02d5439c: ldr     x8, [x8, #0x730]                           MS:MonoSingleton`1::get_Instance
02d543a0: ldr     x0, [x8]                                   T:type56879(k15)
02d543a4: bl      #0x3769600                                 fn_3769600
02d543a8: cbz     x0, #0x2d54c10                             
02d543ac: mov     w1, wzr                                    
02d543b0: bl      #0x2d52038                                 Blindbag.TutorialBlindBag::ShowTutorialClickBagOnShelf
02d543b4: ldr     x8, [x20, #0x50]                           .<>u__1
02d543b8: mov     w9, #1                                     
02d543bc: strb    w9, [x20, #0x40]                           .<selectedItem>5__2
02d543c0: cbz     x8, #0x2d54c14                             
02d543c4: ldr     x0, [x8, #0x38]                            MS:System.Collections.Generic.List`1::get_Item
02d543c8: cbz     x0, #0x2d54c18                             
02d543cc: bl      #0x2d4f318                                 Blindbag.Basket::GetPointData
02d543d0: mov     x1, x0                                     
02d543d4: mov     x21, x19                                   
02d543d8: str     x1, [x21, #0x38]!                          .<>4__this
02d543dc: mov     x0, x21                                    
02d543e0: bl      #0x2b70d54                                 fn_2b70d54
02d543e4: ldr     x8, [x20, #0x50]                           .<>u__1
02d543e8: cbz     x8, #0x2d54c20                             
02d543ec: ldr     x0, [x8, #0x48]                            T:Decor.DecorAsset/<>c__DisplayClass4_0
02d543f0: cbz     x0, #0x2d54c24                             
02d543f4: mov     x1, xzr                                    
02d543f8: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02d543fc: ldr     x8, [x21]                                  
02d54400: cbz     x8, #0x2d54c28                             
02d54404: adrp    x9, #0x626b000                             
02d54408: mov     x23, x0                                    
02d5440c: ldr     x9, [x9, #0x9a0]                           MS:Blindbag.ItemBase::CreateItem
02d54410: ldr     x10, [x20]                                 
02d54414: ldr     x24, [x8, #0x10]                           T:Decor.DataDecor/CategoryData
02d54418: ldr     x1, [x9]                                   T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d5441c: ldrh    w9, [x1, #0x50]                            
02d54420: add     x9, x10, x9, lsl #4                        &6266000
02d54424: ldr     x0, [x9, #0x140]                           M:ScoopGame.CharmBlindBoxAsset/<>c::<GetOrder>b__5_0
02d54428: bl      #0x2b70f2c                                 fn_2b70f2c
02d5442c: ldr     x8, [x0, #8]                               MS:Firebase.Extensions.TaskExtension::ContinueWithOnMainThread
02d54430: mov     x3, x0                                     
02d54434: mov     x0, x20                                    
02d54438: mov     x1, x23                                    
02d5443c: mov     x2, x24                                    
02d54440: blr     x8                                         
02d54444: mov     x23, x0                                    
02d54448: cbz     x0, #0x2d54c2c                             
02d5444c: mov     x0, x23                                    
02d54450: mov     x1, xzr                                    
02d54454: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02d54458: ldr     x8, [x21]                                  
02d5445c: cbz     x8, #0x2d54c30                             
02d54460: cbz     x0, #0x2d54c34                             
02d54464: ldr     x1, [x8, #0x10]                            T:Decor.DataDecor/CategoryData
02d54468: mov     x2, xzr                                    
02d5446c: bl      #0x5b471a4                                 UnityEngine.Transform::set_parent
02d54470: mov     x0, x23                                    
02d54474: mov     x1, xzr                                    
02d54478: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02d5447c: adrp    x26, #0x662f000                            
02d54480: mov     x24, x0                                    
02d54484: ldrb    w8, [x26, #0xa74]                          
02d54488: cbnz    w8, #0x2d544a0                             
02d5448c: adrp    x0, #0x6264000                             
02d54490: ldr     x0, [x0, #0xd8]                            T:UnityEngine.Vector3
02d54494: bl      #0x2b70db0                                 fn_2b70db0
02d54498: mov     w8, #1                                     
02d5449c: strb    w8, [x26, #0xa74]                          
02d544a0: cbz     x24, #0x2d54c38                            
02d544a4: adrp    x26, #0x6264000                            
02d544a8: mov     w9, #0x999a                                
02d544ac: ldr     x26, [x26, #0xd8]                          T:UnityEngine.Vector3
02d544b0: movk    w9, #0x3f99, lsl #16                       
02d544b4: dup     v0.2s, w9                                  
02d544b8: adrp    x9, #0x1084000                             
02d544bc: ldr     x8, [x26]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d544c0: ldr     s2, [x9, #0xcf4]                           [1084cf4]=431d80003f99999a f=1.2,157.5
02d544c4: ldr     x8, [x8, #0xb8]                            MS:UnityEngine.Object::FindObjectsOfType
02d544c8: ldur    d1, [x8, #0xc]                             
02d544cc: fmul    v0.2s, v1.2s, v0.2s                        
02d544d0: ldr     s1, [x8, #0x14]                            [626a014]=0 f=0,0
02d544d4: fmul    s2, s1, s2                                 
02d544d8: mov     s1, v0.s[1]                                
02d544dc: mov     x0, x24                                    
02d544e0: mov     x1, xzr                                    
02d544e4: bl      #0x5b470cc                                 UnityEngine.Transform::set_localScale
02d544e8: ldr     x1, [x22]                                  
02d544ec: mov     x0, x23                                    
02d544f0: bl      #0x2d50420                                 Blindbag.BlindBagAnimation::SetSkinBag
02d544f4: ldr     x8, [x20, #0x58]                           
02d544f8: cbz     x8, #0x2d54c3c                             
02d544fc: adrp    x9, #0x6266000                             
02d54500: ldr     x9, [x9, #0x9f0]                           T:Assets.SimpleLocalization.Scripts.LocalizationManager
02d54504: ldr     x24, [x8, #0x20]                           M:Decor.DataDecor/<>c__DisplayClass8_0::<NewData>b__0
02d54508: ldr     x0, [x9]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d5450c: ldr     w9, [x0, #0xe4]                            [62640e4]=0 f=0,0
02d54510: cbnz    w9, #0x2d54518                             
02d54514: bl      #0x2b70f30                                 fn_2b70f30
02d54518: mov     x0, x24                                    
02d5451c: mov     x1, xzr                                    
02d54520: bl      #0x2d76794                                 Assets.SimpleLocalization.Scripts.LocalizationManager::Localize
02d54524: mov     x1, x0                                     
02d54528: ldr     x8, [x20, #0x58]                           
02d5452c: cbz     x8, #0x2d54c40                             
02d54530: ldr     w24, [x8, #0x18]                           MS:System.Collections.Generic.List`1::Add
02d54534: ldr     w27, [x20, #0x20]                          
02d54538: mov     x0, x23                                    
02d5453c: str     x1, [x0, #0x48]!                           .<data>5__3
02d54540: bl      #0x2b70d54                                 fn_2b70d54
02d54544: str     w24, [x23, #0x50]                          
02d54548: str     w27, [x23, #0x40]                          
02d5454c: ldr     x0, [x22]                                  
02d54550: cbz     x0, #0x2d54c44                             
02d54554: mov     x1, xzr                                    
02d54558: bl      #0x5b339ec                                 UnityEngine.Component::get_gameObject
02d5455c: cbz     x0, #0x2d54c48                             
02d54560: mov     w1, wzr                                    
02d54564: mov     x2, xzr                                    
02d54568: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d5456c: ldr     x0, [x21]                                  
02d54570: cbz     x0, #0x2d54c4c                             
02d54574: str     x23, [x0, #0x20]!                          
02d54578: mov     x1, x23                                    
02d5457c: bl      #0x2b70d54                                 fn_2b70d54
02d54580: mov     x0, x23                                    
02d54584: mov     x1, xzr                                    
02d54588: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02d5458c: mov     x24, x0                                    
02d54590: ldr     x0, [x22]                                  
02d54594: cbz     x0, #0x2d54c50                             
02d54598: mov     x1, xzr                                    
02d5459c: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02d545a0: cbz     x0, #0x2d54c54                             
02d545a4: mov     x1, xzr                                    
02d545a8: bl      #0x5b467ac                                 UnityEngine.Transform::get_position
02d545ac: cbz     x24, #0x2d54c58                            
02d545b0: mov     x0, x24                                    
02d545b4: mov     x1, xzr                                    
02d545b8: bl      #0x5b46888                                 UnityEngine.Transform::set_position
02d545bc: mov     x0, x23                                    
02d545c0: mov     x1, xzr                                    
02d545c4: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02d545c8: adrp    x24, #0x662f000                            
02d545cc: mov     x22, x0                                    
02d545d0: ldrb    w8, [x24, #0x91a]                          
02d545d4: cbnz    w8, #0x2d545ec                             
02d545d8: adrp    x0, #0x6264000                             
02d545dc: ldr     x0, [x0, #0xd8]                            T:UnityEngine.Vector3
02d545e0: bl      #0x2b70db0                                 fn_2b70db0
02d545e4: mov     w8, #1                                     
02d545e8: strb    w8, [x24, #0x91a]                          
02d545ec: ldr     x8, [x26]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d545f0: ldr     x8, [x8, #0xb8]                            MS:UnityEngine.Object::FindObjectsOfType
02d545f4: ldp     s0, s1, [x8]                               
02d545f8: ldr     s2, [x8, #8]                               MS:System.Collections.Generic.List`1::.ctor
02d545fc: fmov    s3, #1.00000000                            
02d54600: mov     x0, x22                                    
02d54604: mov     w1, wzr                                    
02d54608: mov     x2, xzr                                    
02d5460c: bl      #0x2d97cf0                                 DG.Tweening.ShortcutExtensions::DOLocalMove
02d54610: adrp    x8, #0x6266000                             
02d54614: ldr     x8, [x8, #0x880]                           MS:DG.Tweening.TweenSettingsExtensions::SetEase
02d54618: ldr     x2, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d5461c: mov     w1, #0x1a                                  
02d54620: bl      #0x336fa0c                                 fn_336fa0c
02d54624: mov     x0, x23                                    
02d54628: mov     x1, xzr                                    
02d5462c: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02d54630: ldrb    w8, [x24, #0x91a]                          
02d54634: mov     x22, x0                                    
02d54638: cbnz    w8, #0x2d54650                             
02d5463c: adrp    x0, #0x6264000                             
02d54640: ldr     x0, [x0, #0xd8]                            T:UnityEngine.Vector3
02d54644: bl      #0x2b70db0                                 fn_2b70db0
02d54648: mov     w8, #1                                     
02d5464c: strb    w8, [x24, #0x91a]                          
02d54650: ldr     x8, [x26]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d54654: ldr     x8, [x8, #0xb8]                            S:'banner_native_refresh_time'
02d54658: ldp     s0, s1, [x8]                               
02d5465c: ldr     s2, [x8, #8]                               MS:Firebase.Extensions.TaskExtension::ContinueWithOnMainThread
02d54660: fmov    s3, #1.00000000                            
02d54664: mov     x0, x22                                    
02d54668: mov     w1, wzr                                    
02d5466c: mov     x2, xzr                                    
02d54670: bl      #0x2d98760                                 DG.Tweening.ShortcutExtensions::DOLocalRotate
02d54674: adrp    x8, #0x6267000                             
02d54678: ldr     x8, [x8, #0xd38]                           MS:DG.Tweening.TweenSettingsExtensions::SetEase
02d5467c: ldr     x2, [x8]                                   S:'didu'
02d54680: mov     w1, #1                                     
02d54684: bl      #0x336fa0c                                 fn_336fa0c
02d54688: ldr     x8, [x21]                                  
02d5468c: cbz     x8, #0x2d54c5c                             
02d54690: mov     w9, #1                                     
02d54694: str     w9, [x8, #0x18]                            
02d54698: ldr     x0, [x20, #0x50]                           .<>u__1
02d5469c: cbz     x0, #0x2d54c60                             
02d546a0: bl      #0x2d4fdb4                                 Blindbag.BlindbagGameController::UpdateBasket
02d546a4: adrp    x21, #0x6266000                            
02d546a8: ldr     x21, [x21, #0xcc8]                         T:Cysharp.Threading.Tasks.UniTask
02d546ac: ldr     x0, [x21]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d546b0: ldr     w8, [x0, #0xe4]                            [62640e4]=0 f=0,0
02d546b4: cbnz    w8, #0x2d546bc                             
02d546b8: bl      #0x2b70f30                                 fn_2b70f30
02d546bc: fmov    s0, #1.00000000                            
02d546c0: mov     w0, wzr                                    
02d546c4: mov     w1, #8                                     
02d546c8: mov     x2, xzr                                    
02d546cc: mov     w3, wzr                                    
02d546d0: mov     x4, xzr                                    
02d546d4: bl      #0x5447b08                                 Cysharp.Threading.Tasks.UniTask::WaitForSeconds
02d546d8: stp     x0, x1, [sp, #0x20]                        
02d546dc: add     x0, sp, #0x20                              
02d546e0: mov     x1, xzr                                    
02d546e4: bl      #0x2b70d54                                 fn_2b70d54
02d546e8: adrp    x22, #0x662f000                            
02d546ec: ldr     q0, [sp, #0x20]                            
02d546f0: ldrb    w8, [x22, #0xbdc]                          
02d546f4: str     q0, [sp, #0x10]                            
02d546f8: cbnz    w8, #0x2d54710                             
02d546fc: adrp    x0, #0x6266000                             
02d54700: ldr     x0, [x0, #0xcc8]                           T:Cysharp.Threading.Tasks.UniTask
02d54704: bl      #0x2b70db0                                 fn_2b70db0
02d54708: mov     w8, #1                                     
02d5470c: strb    w8, [x22, #0xbdc]                          
02d54710: ldr     x0, [x21]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d54714: ldr     w8, [x0, #0xe4]                            [62660e4]=0 f=0,0
02d54718: cbnz    w8, #0x2d54720                             
02d5471c: bl      #0x2b70f30                                 fn_2b70f30
02d54720: adrp    x21, #0x662f000                            
02d54724: ldrb    w8, [x21, #0xbdd]                          
02d54728: cbnz    w8, #0x2d54740                             
02d5472c: adrp    x0, #0x6266000                             
02d54730: ldr     x0, [x0, #0xcd0]                           T:Cysharp.Threading.Tasks.IUniTaskSource
02d54734: bl      #0x2b70db0                                 fn_2b70db0
02d54738: mov     w8, #1                                     
02d5473c: strb    w8, [x21, #0xbdd]                          
02d54740: ldr     x21, [sp, #0x10]                           
02d54744: cbz     x21, #0x2d541a4                            
02d54748: adrp    x10, #0x6266000                            
02d5474c: ldr     x8, [x21]                                  &2b706c4(=eb01011ff9400808)
02d54750: ldr     x10, [x10, #0xcd0]                         T:Cysharp.Threading.Tasks.IUniTaskSource
02d54754: ldrh    w22, [sp, #0x18]                           
02d54758: ldrh    w9, [x8, #0x12e]                           
02d5475c: ldr     x1, [x10]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d54760: cbz     x9, #0x2d54784                             
02d54764: ldr     x10, [x8, #0xb0]                           M:Framework.SceneUtils/<CRLoadSceneAsync>d__1::System.Collections.IEnumerator.Reset
02d54768: add     x10, x10, #8                               &6266008
02d5476c: ldur    x11, [x10, #-8]                            
02d54770: cmp     x11, x1                                    
02d54774: b.eq    #0x2d54b5c                                 
02d54778: subs    x9, x9, #1                                 
02d5477c: add     x10, x10, #0x10                            &6266010
02d54780: b.ne    #0x2d5476c                                 
02d54784: mov     x0, x21                                    
02d54788: mov     w2, wzr                                    
02d5478c: bl      #0x2baa05c                                 fn_2baa05c
02d54790: b       #0x2d54b68                                 
02d54794: ldr     w9, [x10]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d54798: add     w9, w9, #2                                 
02d5479c: add     x8, x8, w9, sxtw #4                        &6267000
02d547a0: add     x0, x8, #0x138                             &6267138
02d547a4: ldp     x8, x2, [x0]                               
02d547a8: mov     x0, x21                                    
02d547ac: mov     w1, w22                                    
02d547b0: blr     x8                                         
02d547b4: ldr     x8, [x19, #0x38]                           .<>4__this
02d547b8: cbz     x8, #0x2d54bb8                             
02d547bc: mov     w9, #2                                     
02d547c0: str     w9, [x8, #0x18]                            
02d547c4: mov     x0, xzr                                    
02d547c8: bl      #0x2d6eec8                                 Framework.AudioManager::get_Instance
02d547cc: cbz     x0, #0x2d54bbc                             
02d547d0: movi    d1, #0000000000000000                      
02d547d4: movi    d2, #0000000000000000                      
02d547d8: mov     w1, #0x10                                  
02d547dc: fmov    s0, #1.00000000                            
02d547e0: mov     w2, wzr                                    
02d547e4: mov     w3, wzr                                    
02d547e8: mov     x4, xzr                                    
02d547ec: bl      #0x2d6f03c                                 Framework.AudioManager::PlaySound
02d547f0: adrp    x8, #0x6267000                             
02d547f4: ldr     x8, [x8, #0xea8]                           T:Framework.Vibration
02d547f8: ldr     x0, [x8]                                   S:'didu'
02d547fc: ldr     w8, [x0, #0xe4]                            [62660e4]=0 f=0,0
02d54800: cbnz    w8, #0x2d54808                             
02d54804: bl      #0x2b70f30                                 fn_2b70f30
02d54808: mov     w0, #0x3c                                  
02d5480c: mov     w1, #-1                                    
02d54810: mov     w2, wzr                                    
02d54814: mov     x3, xzr                                    
02d54818: bl      #0x2d6e144                                 Framework.Vibration::Vibrate
02d5481c: cbz     x20, #0x2d54bc0                            
02d54820: ldr     x0, [x20, #0x50]                           .<>u__1
02d54824: cbz     x0, #0x2d54bc4                             
02d54828: bl      #0x2d4fdb4                                 Blindbag.BlindbagGameController::UpdateBasket
02d5482c: ldr     x0, [x19, #0x30]                           
02d54830: cbz     x0, #0x2d54bc8                             
02d54834: mov     x1, xzr                                    
02d54838: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02d5483c: adrp    x22, #0x662f000                            
02d54840: mov     x21, x0                                    
02d54844: ldrb    w8, [x22, #0x91a]                          
02d54848: cbnz    w8, #0x2d54860                             
02d5484c: adrp    x0, #0x6264000                             
02d54850: ldr     x0, [x0, #0xd8]                            T:UnityEngine.Vector3
02d54854: bl      #0x2b70db0                                 fn_2b70db0
02d54858: mov     w8, #1                                     
02d5485c: strb    w8, [x22, #0x91a]                          
02d54860: cbz     x21, #0x2d54bcc                            
02d54864: adrp    x22, #0x6264000                            
02d54868: ldr     x22, [x22, #0xd8]                          T:UnityEngine.Vector3
02d5486c: ldr     x8, [x22]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d54870: ldr     x8, [x8, #0xb8]                            M:Framework.SceneUtils/<CRUnloadSceneAsync>d__2::System.Collections.IEnumerator.Reset
02d54874: ldp     s1, s2, [x8, #4]                           
02d54878: ldr     s0, [x8]                                   S:'didu'
02d5487c: mov     x0, x21                                    
02d54880: mov     x1, xzr                                    
02d54884: bl      #0x5b470cc                                 UnityEngine.Transform::set_localScale
02d54888: ldr     x0, [x19, #0x30]                           
02d5488c: cbz     x0, #0x2d54bd0                             
02d54890: mov     x1, xzr                                    
02d54894: bl      #0x5b339ec                                 UnityEngine.Component::get_gameObject
02d54898: cbz     x0, #0x2d54bd4                             
02d5489c: mov     w1, #1                                     
02d548a0: mov     x2, xzr                                    
02d548a4: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d548a8: ldr     x0, [x19, #0x30]                           
02d548ac: cbz     x0, #0x2d54bd8                             
02d548b0: mov     x1, xzr                                    
02d548b4: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02d548b8: adrp    x23, #0x662f000                            
02d548bc: mov     x21, x0                                    
02d548c0: ldrb    w8, [x23, #0xa74]                          
02d548c4: cbnz    w8, #0x2d548dc                             
02d548c8: adrp    x0, #0x6264000                             
02d548cc: ldr     x0, [x0, #0xd8]                            T:UnityEngine.Vector3
02d548d0: bl      #0x2b70db0                                 fn_2b70db0
02d548d4: mov     w8, #1                                     
02d548d8: strb    w8, [x23, #0xa74]                          
02d548dc: ldr     x8, [x22]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d548e0: mov     w9, #0xcccd                                
02d548e4: movk    w9, #0x3ecc, lsl #16                       
02d548e8: ldr     x8, [x8, #0xb8]                            M:Framework.SceneUtils/<CRUnloadSceneAsync>d__2::System.Collections.IEnumerator.Reset
02d548ec: dup     v0.2s, w9                                  
02d548f0: adrp    x9, #0x1084000                             
02d548f4: ldr     s2, [x9, #0xfb0]                           [1084fb0]=3f7d70a43ecccccd f=0.4,0.99
02d548f8: ldur    d1, [x8, #0xc]                             
02d548fc: fmul    v0.2s, v1.2s, v0.2s                        
02d54900: ldr     s1, [x8, #0x14]                            [6267014]=0 f=0,0
02d54904: fmul    s2, s1, s2                                 
02d54908: mov     s1, v0.s[1]                                
02d5490c: adrp    x8, #0x1084000                             
02d54910: mov     x0, x21                                    
02d54914: mov     x1, xzr                                    
02d54918: ldr     s8, [x8, #0xe60]                           [1084e60]=bc8efa353eb33333 f=0.35,-0.0174533
02d5491c: fmov    s3, s8                                     
02d54920: bl      #0x2d98af8                                 DG.Tweening.ShortcutExtensions::DOScale
02d54924: adrp    x21, #0x6266000                            
02d54928: ldr     x21, [x21, #0xcc8]                         T:Cysharp.Threading.Tasks.UniTask
02d5492c: ldr     x0, [x21]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d54930: ldr     w8, [x0, #0xe4]                            [62640e4]=0 f=0,0
02d54934: cbnz    w8, #0x2d5493c                             
02d54938: bl      #0x2b70f30                                 fn_2b70f30
02d5493c: fmov    s0, s8                                     
02d54940: mov     w0, wzr                                    
02d54944: mov     w1, #8                                     
02d54948: mov     x2, xzr                                    
02d5494c: mov     w3, wzr                                    
02d54950: mov     x4, xzr                                    
02d54954: bl      #0x5447b08                                 Cysharp.Threading.Tasks.UniTask::WaitForSeconds
02d54958: stp     x0, x1, [sp, #0x20]                        
02d5495c: add     x0, sp, #0x20                              
02d54960: mov     x1, xzr                                    
02d54964: bl      #0x2b70d54                                 fn_2b70d54
02d54968: adrp    x22, #0x662f000                            
02d5496c: ldr     q0, [sp, #0x20]                            
02d54970: ldrb    w8, [x22, #0xbdc]                          
02d54974: str     q0, [sp, #0x10]                            
02d54978: cbnz    w8, #0x2d54990                             
02d5497c: adrp    x0, #0x6266000                             
02d54980: ldr     x0, [x0, #0xcc8]                           T:Cysharp.Threading.Tasks.UniTask
02d54984: bl      #0x2b70db0                                 fn_2b70db0
02d54988: mov     w8, #1                                     
02d5498c: strb    w8, [x22, #0xbdc]                          
02d54990: ldr     x0, [x21]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d54994: ldr     w8, [x0, #0xe4]                            [62660e4]=0 f=0,0
02d54998: cbnz    w8, #0x2d549a0                             
02d5499c: bl      #0x2b70f30                                 fn_2b70f30
02d549a0: adrp    x21, #0x662f000                            
02d549a4: ldrb    w8, [x21, #0xbdd]                          
02d549a8: cbnz    w8, #0x2d549c0                             
02d549ac: adrp    x0, #0x6266000                             
02d549b0: ldr     x0, [x0, #0xcd0]                           T:Cysharp.Threading.Tasks.IUniTaskSource
02d549b4: bl      #0x2b70db0                                 fn_2b70db0
02d549b8: mov     w8, #1                                     
02d549bc: strb    w8, [x21, #0xbdd]                          
02d549c0: ldr     x21, [sp, #0x10]                           
02d549c4: cbz     x21, #0x2d54a34                            
02d549c8: adrp    x10, #0x6266000                            
02d549cc: ldr     x8, [x21]                                  &2b706c4(=eb01011ff9400808)
02d549d0: ldr     x10, [x10, #0xcd0]                         T:Cysharp.Threading.Tasks.IUniTaskSource
02d549d4: ldrh    w22, [sp, #0x18]                           
02d549d8: ldrh    w9, [x8, #0x12e]                           
02d549dc: ldr     x1, [x10]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d549e0: cbz     x9, #0x2d54a04                             
02d549e4: ldr     x10, [x8, #0xb0]                           [10840b0]=2e656e69676e4579 f=1.1252e+24,5.21666e-11
02d549e8: add     x10, x10, #8                               &6266008
02d549ec: ldur    x11, [x10, #-8]                            
02d549f0: cmp     x11, x1                                    
02d549f4: b.eq    #0x2d54a14                                 
02d549f8: subs    x9, x9, #1                                 
02d549fc: add     x10, x10, #0x10                            &6266010
02d54a00: b.ne    #0x2d549ec                                 
02d54a04: mov     x0, x21                                    
02d54a08: mov     w2, wzr                                    
02d54a0c: bl      #0x2baa05c                                 fn_2baa05c
02d54a10: b       #0x2d54a20                                 
02d54a14: ldrsw   x9, [x10]                                  
02d54a18: add     x8, x8, x9, lsl #4                         &1084000
02d54a1c: add     x0, x8, #0x138                             &1084138
02d54a20: ldp     x8, x2, [x0]                               
02d54a24: mov     x0, x21                                    
02d54a28: mov     w1, w22                                    
02d54a2c: blr     x8                                         
02d54a30: cbz     w0, #0x2d54b20                             
02d54a34: ldrb    w8, [x25, #0xbde]                          
02d54a38: cbnz    w8, #0x2d54a50                             
02d54a3c: adrp    x0, #0x6266000                             
02d54a40: ldr     x0, [x0, #0xcd0]                           T:Cysharp.Threading.Tasks.IUniTaskSource
02d54a44: bl      #0x2b70db0                                 fn_2b70db0
02d54a48: mov     w8, #1                                     
02d54a4c: strb    w8, [x25, #0xbde]                          
02d54a50: ldr     x21, [sp, #0x10]                           
02d54a54: cbz     x21, #0x2d54ac4                            
02d54a58: adrp    x10, #0x6266000                            
02d54a5c: ldr     x8, [x21]                                  &2b706c4(=eb01011ff9400808)
02d54a60: ldr     x10, [x10, #0xcd0]                         T:Cysharp.Threading.Tasks.IUniTaskSource
02d54a64: ldrh    w22, [sp, #0x18]                           
02d54a68: ldrh    w9, [x8, #0x12e]                           
02d54a6c: ldr     x1, [x10]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d54a70: cbz     x9, #0x2d54a94                             
02d54a74: ldr     x10, [x8, #0xb0]                           [10840b0]=2e656e69676e4579 f=1.1252e+24,5.21666e-11
02d54a78: add     x10, x10, #8                               &6266008
02d54a7c: ldur    x11, [x10, #-8]                            
02d54a80: cmp     x11, x1                                    
02d54a84: b.eq    #0x2d54aa4                                 
02d54a88: subs    x9, x9, #1                                 
02d54a8c: add     x10, x10, #0x10                            &6266010
02d54a90: b.ne    #0x2d54a7c                                 
02d54a94: mov     x0, x21                                    
02d54a98: mov     w2, #2                                     
02d54a9c: bl      #0x2baa05c                                 fn_2baa05c
02d54aa0: b       #0x2d54ab4                                 
02d54aa4: ldr     w9, [x10]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d54aa8: add     w9, w9, #2                                 
02d54aac: add     x8, x8, w9, sxtw #4                        &1084000
02d54ab0: add     x0, x8, #0x138                             &1084138
02d54ab4: ldp     x8, x2, [x0]                               
02d54ab8: mov     x0, x21                                    
02d54abc: mov     w1, w22                                    
02d54ac0: blr     x8                                         
02d54ac4: cbz     x20, #0x2d54bb4                            
02d54ac8: strb    wzr, [x20, #0x40]                          .<selectedItem>5__2
02d54acc: mov     w8, #-2                                    
02d54ad0: mov     x0, x19                                    
02d54ad4: mov     x1, xzr                                    
02d54ad8: str     w8, [x19]                                  
02d54adc: str     xzr, [x0, #0x30]!                          
02d54ae0: bl      #0x2b70d54                                 fn_2b70d54
02d54ae4: str     xzr, [x19, #0x38]!                         .<>4__this
02d54ae8: mov     x0, x19                                    
02d54aec: mov     x1, xzr                                    
02d54af0: bl      #0x2b70d54                                 fn_2b70d54
02d54af4: sub     x0, x19, #0x30                             
02d54af8: mov     x1, xzr                                    
02d54afc: bl      #0x4d43b50                                 System.Runtime.CompilerServices.AsyncVoidMethodBuilder::SetResult
02d54b00: ldp     x20, x19, [sp, #0x80]                      
02d54b04: ldr     d8, [sp, #0x30]                            
02d54b08: ldp     x22, x21, [sp, #0x70]                      
02d54b0c: ldp     x24, x23, [sp, #0x60]                      
02d54b10: ldp     x26, x25, [sp, #0x50]                      
02d54b14: ldp     x30, x27, [sp, #0x40]                      
02d54b18: add     sp, sp, #0x90                              
02d54b1c: ret                                                
02d54b20: ldr     q0, [sp, #0x10]                            
02d54b24: mov     w8, #1                                     
02d54b28: str     w8, [x19]                                  
02d54b2c: str     q0, [x19, #0x40]                           .<selectedItem>5__2
02d54b30: add     x0, x19, #0x40                             
02d54b34: mov     x1, xzr                                    
02d54b38: bl      #0x2b70d54                                 fn_2b70d54
02d54b3c: adrp    x8, #0x626b000                             
02d54b40: ldr     x8, [x8, #0x998]                           MS:System.Runtime.CompilerServices.AsyncVoidMethodBuilder::AwaitUnsafeOnCompleted
02d54b44: ldr     x3, [x8]                                   T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d54b48: add     x0, x19, #8                                
02d54b4c: add     x1, sp, #0x10                              
02d54b50: mov     x2, x19                                    
02d54b54: bl      #0x30c3bdc                                 fn_30c3bdc
02d54b58: b       #0x2d54b00                                 
02d54b5c: ldrsw   x9, [x10]                                  
02d54b60: add     x8, x8, x9, lsl #4                         &626b000
02d54b64: add     x0, x8, #0x138                             &626b138
02d54b68: ldp     x8, x2, [x0]                               
02d54b6c: mov     x0, x21                                    
02d54b70: mov     w1, w22                                    
02d54b74: blr     x8                                         
02d54b78: cbnz    w0, #0x2d541a4                             
02d54b7c: ldr     q0, [sp, #0x10]                            
02d54b80: str     wzr, [x19]                                 
02d54b84: str     q0, [x19, #0x40]                           .<selectedItem>5__2
02d54b88: add     x0, x19, #0x40                             
02d54b8c: mov     x1, xzr                                    
02d54b90: bl      #0x2b70d54                                 fn_2b70d54
02d54b94: adrp    x8, #0x626b000                             
02d54b98: ldr     x8, [x8, #0x998]                           MS:System.Runtime.CompilerServices.AsyncVoidMethodBuilder::AwaitUnsafeOnCompleted
02d54b9c: ldr     x3, [x8]                                   T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d54ba0: add     x0, x19, #8                                
02d54ba4: add     x1, sp, #0x10                              
02d54ba8: mov     x2, x19                                    
02d54bac: bl      #0x30c3bdc                                 fn_30c3bdc
02d54bb0: b       #0x2d54b00                                 
02d54bb4: bl      #0x2b7105c                                 fn_2b7105c
02d54bb8: bl      #0x2b7105c                                 fn_2b7105c
02d54bbc: bl      #0x2b7105c                                 fn_2b7105c
02d54bc0: bl      #0x2b7105c                                 fn_2b7105c
02d54bc4: bl      #0x2b7105c                                 fn_2b7105c
02d54bc8: bl      #0x2b7105c                                 fn_2b7105c
02d54bcc: bl      #0x2b7105c                                 fn_2b7105c
02d54bd0: bl      #0x2b7105c                                 fn_2b7105c
02d54bd4: bl      #0x2b7105c                                 fn_2b7105c
02d54bd8: bl      #0x2b7105c                                 fn_2b7105c
02d54bdc: bl      #0x2b7105c                                 fn_2b7105c
02d54be0: bl      #0x2b7105c                                 fn_2b7105c
02d54be4: bl      #0x2b7105c                                 fn_2b7105c
02d54be8: bl      #0x2b7105c                                 fn_2b7105c
02d54bec: bl      #0x2b7105c                                 fn_2b7105c
02d54bf0: bl      #0x2b7105c                                 fn_2b7105c
02d54bf4: bl      #0x2b7105c                                 fn_2b7105c
02d54bf8: bl      #0x2b7105c                                 fn_2b7105c
02d54bfc: bl      #0x2b7105c                                 fn_2b7105c
02d54c00: bl      #0x2b7105c                                 fn_2b7105c
02d54c04: bl      #0x2b7105c                                 fn_2b7105c
02d54c08: bl      #0x2b7105c                                 fn_2b7105c
02d54c0c: bl      #0x2b7105c                                 fn_2b7105c
02d54c10: bl      #0x2b7105c                                 fn_2b7105c
02d54c14: bl      #0x2b7105c                                 fn_2b7105c
02d54c18: bl      #0x2b7105c                                 fn_2b7105c
02d54c1c: bl      #0x2b7105c                                 fn_2b7105c
02d54c20: bl      #0x2b7105c                                 fn_2b7105c
02d54c24: bl      #0x2b7105c                                 fn_2b7105c
02d54c28: bl      #0x2b7105c                                 fn_2b7105c
02d54c2c: bl      #0x2b7105c                                 fn_2b7105c
02d54c30: bl      #0x2b7105c                                 fn_2b7105c
02d54c34: bl      #0x2b7105c                                 fn_2b7105c
02d54c38: bl      #0x2b7105c                                 fn_2b7105c
02d54c3c: bl      #0x2b7105c                                 fn_2b7105c
02d54c40: bl      #0x2b7105c                                 fn_2b7105c
02d54c44: bl      #0x2b7105c                                 fn_2b7105c
02d54c48: bl      #0x2b7105c                                 fn_2b7105c
02d54c4c: bl      #0x2b7105c                                 fn_2b7105c
02d54c50: bl      #0x2b7105c                                 fn_2b7105c
02d54c54: bl      #0x2b7105c                                 fn_2b7105c
02d54c58: bl      #0x2b7105c                                 fn_2b7105c
02d54c5c: bl      #0x2b7105c                                 fn_2b7105c
02d54c60: bl      #0x2b7105c                                 fn_2b7105c
02d54c64: b       #0x2d54dd0                                 
02d54c68: b       #0x2d54dd0                                 
02d54c6c: b       #0x2d54dd0                                 
02d54c70: b       #0x2d54dd0                                 
02d54c74: b       #0x2d54dd0                                 
02d54c78: b       #0x2d54dd0                                 
02d54c7c: b       #0x2d54dd0                                 
02d54c80: b       #0x2d54dd0                                 
02d54c84: b       #0x2d54dd0                                 
02d54c88: b       #0x2d54dd0                                 
02d54c8c: b       #0x2d54dd0                                 
02d54c90: b       #0x2d54dd0                                 
02d54c94: b       #0x2d54dd0                                 
02d54c98: b       #0x2d54dd0                                 
02d54c9c: b       #0x2d54dd0                                 
02d54ca0: b       #0x2d54dd0                                 
02d54ca4: b       #0x2d54dd0                                 
02d54ca8: b       #0x2d54dd0                                 
02d54cac: b       #0x2d54dd0                                 
02d54cb0: b       #0x2d54dd0                                 
02d54cb4: b       #0x2d54dd0                                 
02d54cb8: b       #0x2d54dd0                                 
02d54cbc: b       #0x2d54dd0                                 
02d54cc0: b       #0x2d54dd0                                 
02d54cc4: b       #0x2d54dd0                                 
02d54cc8: b       #0x2d54dd0                                 
02d54ccc: b       #0x2d54dd0                                 
02d54cd0: b       #0x2d54dd0                                 
02d54cd4: b       #0x2d54dd0                                 
02d54cd8: b       #0x2d54dd0                                 
02d54cdc: b       #0x2d54dd0                                 
02d54ce0: b       #0x2d54dd0                                 
02d54ce4: b       #0x2d54dd0                                 
02d54ce8: b       #0x2d54dd0                                 
02d54cec: b       #0x2d54dd0                                 
02d54cf0: b       #0x2d54dd0                                 
02d54cf4: b       #0x2d54dd0                                 
02d54cf8: b       #0x2d54dd0                                 
02d54cfc: b       #0x2d54dd0                                 
02d54d00: b       #0x2d54dd0                                 
02d54d04: b       #0x2d54dd0                                 
02d54d08: b       #0x2d54dd0                                 
02d54d0c: b       #0x2d54dd0                                 
02d54d10: b       #0x2d54dd0                                 
02d54d14: b       #0x2d54dd0                                 
02d54d18: b       #0x2d54dd0                                 
02d54d1c: b       #0x2d54dd0                                 
02d54d20: b       #0x2d54dd0                                 
02d54d24: b       #0x2d54dd0                                 
02d54d28: b       #0x2d54dd0                                 
02d54d2c: b       #0x2d54dd0                                 
02d54d30: b       #0x2d54dd0                                 
02d54d34: b       #0x2d54dd0                                 
02d54d38: b       #0x2d54dd0                                 
02d54d3c: b       #0x2d54dd0                                 
02d54d40: b       #0x2d54dd0                                 
02d54d44: b       #0x2d54dd0                                 
02d54d48: b       #0x2d54dd0                                 
02d54d4c: b       #0x2d54dd0                                 
02d54d50: b       #0x2d54dd0                                 
02d54d54: b       #0x2d54dd0                                 
02d54d58: b       #0x2d54dd0                                 
02d54d5c: b       #0x2d54dd0                                 
02d54d60: b       #0x2d54dd0                                 
02d54d64: b       #0x2d54dd0                                 
02d54d68: b       #0x2d54dd0                                 
02d54d6c: b       #0x2d54dd0                                 
02d54d70: b       #0x2d54dd0                                 
02d54d74: b       #0x2d54dd0                                 
02d54d78: b       #0x2d54dd0                                 
02d54d7c: b       #0x2d54dd0                                 
02d54d80: b       #0x2d54dd0                                 
02d54d84: b       #0x2d54dd0                                 
02d54d88: b       #0x2d54dd0                                 
02d54d8c: b       #0x2d54dd0                                 
02d54d90: b       #0x2d54dd0                                 
02d54d94: b       #0x2d54dd0                                 
02d54d98: b       #0x2d54dd0                                 
02d54d9c: b       #0x2d54dd0                                 
02d54da0: b       #0x2d54dd0                                 
02d54da4: b       #0x2d54dd0                                 
02d54da8: b       #0x2d54dd0                                 
02d54dac: b       #0x2d54dd0                                 
02d54db0: b       #0x2d54dd0                                 
02d54db4: b       #0x2d54dd0                                 
02d54db8: b       #0x2d54dd0                                 
02d54dbc: b       #0x2d54dd0                                 
02d54dc0: b       #0x2d54dd0                                 
02d54dc4: b       #0x2d54dd0                                 
02d54dc8: b       #0x2d54dd0                                 
02d54dcc: b       #0x2d54dd0                                 
02d54dd0: mov     x20, x0                                    
02d54dd4: cmp     w1, #1                                     
02d54dd8: b.ne    #0x2d54e88                                 
02d54ddc: mov     x0, x20                                    
02d54de0: bl      #0x5e90260                                 fn_5e90260
02d54de4: mov     x20, x0                                    
02d54de8: adrp    x0, #0x6263000                             
02d54dec: ldr     x0, [x0, #0xae0]                           T:System.Exception
02d54df0: bl      #0x2b70dc4                                 fn_2b70dc4
02d54df4: ldr     x8, [x20]                                  
02d54df8: ldr     x1, [x8]                                   T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d54dfc: bl      #0x2b71464                                 fn_2b71464
02d54e00: tbz     w0, #0, #0x2d54e60                         
02d54e04: ldrsw   x21, [sp, #8]                              
02d54e08: ldr     x20, [x20]                                 
02d54e0c: mov     x8, sp                                     
02d54e10: str     x20, [x8, x21, lsl #3]                     
02d54e14: add     w8, w21, #1                                
02d54e18: str     w8, [sp, #8]                               
02d54e1c: bl      #0x5e90270                                 fn_5e90270
02d54e20: mov     w8, #-2                                    
02d54e24: mov     x0, x19                                    
02d54e28: mov     x1, xzr                                    
02d54e2c: str     w8, [x19]                                  
02d54e30: str     xzr, [x0, #0x30]!                          
02d54e34: bl      #0x2b70d54                                 fn_2b70d54
02d54e38: str     xzr, [x19, #0x38]!                         .<>4__this
02d54e3c: mov     x0, x19                                    
02d54e40: mov     x1, xzr                                    
02d54e44: bl      #0x2b70d54                                 fn_2b70d54
02d54e48: sub     x0, x19, #0x30                             
02d54e4c: mov     x1, x20                                    
02d54e50: mov     x2, xzr                                    
02d54e54: bl      #0x4d43cc0                                 System.Runtime.CompilerServices.AsyncVoidMethodBuilder::SetException
02d54e58: str     w21, [sp, #8]                              
02d54e5c: b       #0x2d54b00                                 
02d54e60: mov     w0, #8                                     
02d54e64: bl      #0x5e90290                                 fn_5e90290
02d54e68: ldr     x8, [x20]                                  
02d54e6c: str     x8, [x0]                                   
02d54e70: adrp    x1, #0x5e96000                             
02d54e74: add     x1, x1, #0x758                             &5e96758
02d54e78: mov     x2, xzr                                    
02d54e7c: bl      #0x5e902a0                                 fn_5e902a0
02d54e80: mov     x20, x0                                    
02d54e84: bl      #0x5e90270                                 fn_5e90270
02d54e88: mov     x0, x20                                    
02d54e8c: bl      #0x2c6051c                                 fn_2c6051c
02d54e90: bl      #0x27369b8                                 fn_27369b8
## SetStateMachine(System.Runtime.CompilerServices.IAsyncStateMachine stateMachine) -> void
---- Blindbag.ItemBase/<OnMouseButtonDown>d__13::SetStateMachine 0x2d54e94
02d54e94: add     x0, x0, #8                                 
02d54e98: mov     x2, xzr                                    
02d54e9c: b       #0x4d43a8c                                 System.Runtime.CompilerServices.AsyncVoidMethodBuilder::SetStateMachine
#### CLASS Blindbag.ItemBase parent= UnityEngine.MonoBehaviour
#   field _id                            int                                                off=0x20 attr=1 SerializeField
#   field _priceText                     TMPro.TextMeshProUGUI                              off=0x28 attr=1 SerializeField
#   field _collider                      UnityEngine.BoxCollider2D                          off=0x30 attr=1 SerializeField
#   field _orderItems                    System.Collections.Generic.List`1<Spine.Unity.SkeletonAnimation> off=0x38 attr=1 SerializeField
#   field _isCountdown                   bool                                               off=0x40 attr=1 SerializeField
#   field _offSetTouch                   UnityEngine.Vector3                                off=0x44 attr=1 SerializeField
#   field Controller                     Blindbag.BlindbagGameController                    off=0x50 attr=4 
#   field _data                          ScoopGame.BlindBagMarketDataItem                   off=0x58 attr=1 
## get_Id() -> int
---- Blindbag.ItemBase::get_Id 0x2d53aa8
02d53aa8: ldr     w0, [x0, #0x20]                            ._id
02d53aac: ret                                                
## GetNearestItemToClick() -> Spine.Unity.SkeletonAnimation
---- Blindbag.ItemBase::GetNearestItemToClick 0x2d53ab0
02d53ab0: stp     d13, d12, [sp, #-0x60]!                    
02d53ab4: stp     d11, d10, [sp, #0x10]                      
02d53ab8: stp     d9, d8, [sp, #0x20]                        
02d53abc: stp     x30, x23, [sp, #0x30]                      
02d53ac0: stp     x22, x21, [sp, #0x40]                      
02d53ac4: stp     x20, x19, [sp, #0x50]                      
02d53ac8: adrp    x20, #0x6630000                            
02d53acc: mov     x19, x0                                    
02d53ad0: ldrb    w8, [x20, #0x26b]                          
02d53ad4: tbnz    w8, #0, #0x2d53b10                         
02d53ad8: adrp    x0, #0x6266000                             
02d53adc: ldr     x0, [x0, #0x938]                           MS:UnityEngine.InputSystem.InputControl`1::ReadValue
02d53ae0: bl      #0x2b70db0                                 fn_2b70db0
02d53ae4: adrp    x0, #0x626b000                             
02d53ae8: ldr     x0, [x0, #0x970]                           MS:System.Collections.Generic.List`1::get_Count
02d53aec: bl      #0x2b70db0                                 fn_2b70db0
02d53af0: adrp    x0, #0x626b000                             
02d53af4: ldr     x0, [x0, #0x978]                           MS:System.Collections.Generic.List`1::get_Item
02d53af8: bl      #0x2b70db0                                 fn_2b70db0
02d53afc: adrp    x0, #0x6263000                             
02d53b00: ldr     x0, [x0, #0x918]                           T:UnityEngine.Object
02d53b04: bl      #0x2b70db0                                 fn_2b70db0
02d53b08: mov     w8, #1                                     
02d53b0c: strb    w8, [x20, #0x26b]                          
02d53b10: ldr     x8, [x19, #0x38]                           ._orderItems
02d53b14: cbz     x8, #0x2d53cd4                             
02d53b18: ldr     w8, [x8, #0x18]                            
02d53b1c: cbz     w8, #0x2d53cd4                             
02d53b20: mov     x0, xzr                                    
02d53b24: bl      #0x5aefe28                                 UnityEngine.Camera::get_main
02d53b28: adrp    x8, #0x6263000                             
02d53b2c: mov     x20, x0                                    
02d53b30: ldr     x8, [x8, #0x918]                           T:UnityEngine.Object
02d53b34: ldr     x8, [x8]                                   &2c5bbd4(=a9bd7bfdd503233f)
02d53b38: ldr     w9, [x8, #0xe4]                            [62630e4]=0 f=0,0
02d53b3c: cbnz    w9, #0x2d53b48                             
02d53b40: mov     x0, x8                                     
02d53b44: bl      #0x2b70f30                                 fn_2b70f30
02d53b48: mov     x0, x20                                    
02d53b4c: mov     x1, xzr                                    
02d53b50: mov     x2, xzr                                    
02d53b54: bl      #0x5b37d84                                 UnityEngine.Object::op_Equality
02d53b58: tbnz    w0, #0, #0x2d53cf8                         
02d53b5c: adrp    x21, #0x662f000                            
02d53b60: ldrb    w8, [x21, #0xbd9]                          
02d53b64: cbnz    w8, #0x2d53b7c                             
02d53b68: adrp    x0, #0x6266000                             
02d53b6c: ldr     x0, [x0, #0x950]                           T:UnityEngine.InputSystem.Pointer
02d53b70: bl      #0x2b70db0                                 fn_2b70db0
02d53b74: mov     w8, #1                                     
02d53b78: strb    w8, [x21, #0xbd9]                          
02d53b7c: adrp    x8, #0x6266000                             
02d53b80: ldr     x8, [x8, #0x950]                           T:UnityEngine.InputSystem.Pointer
02d53b84: ldr     x8, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d53b88: ldr     x8, [x8, #0xb8]                            S:'banner_native_refresh_time'
02d53b8c: ldr     x8, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d53b90: cbz     x8, #0x2d53cf8                             
02d53b94: ldr     x0, [x8, #0x188]                           S:'makeText'
02d53b98: cbz     x0, #0x2d53cd0                             
02d53b9c: adrp    x8, #0x6266000                             
02d53ba0: ldr     x8, [x8, #0x938]                           MS:UnityEngine.InputSystem.InputControl`1::ReadValue
02d53ba4: ldr     x1, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d53ba8: bl      #0x4a187c4                                 fn_4a187c4
02d53bac: cbz     x20, #0x2d53cd0                            
02d53bb0: movi    d2, #0000000000000000                      
02d53bb4: mov     x0, x20                                    
02d53bb8: mov     x1, xzr                                    
02d53bbc: bl      #0x5aefbb0                                 UnityEngine.Camera::ScreenToWorldPoint
02d53bc0: ldr     x0, [x19, #0x38]                           ._orderItems
02d53bc4: cbz     x0, #0x2d53cd0                             
02d53bc8: adrp    x23, #0x626b000                            
02d53bcc: mov     w1, wzr                                    
02d53bd0: fmov    s8, s0                                     
02d53bd4: ldr     x23, [x23, #0x978]                         MS:System.Collections.Generic.List`1::get_Item
02d53bd8: ldp     s11, s12, [x19, #0x44]                     ._offSetTouch
02d53bdc: ldr     s13, [x19, #0x4c]                          
02d53be0: fmov    s9, s1                                     
02d53be4: fmov    s10, s2                                    
02d53be8: ldr     x2, [x23]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d53bec: bl      #0x35a8f3c                                 fn_35a8f3c
02d53bf0: cbz     x0, #0x2d53cd0                             
02d53bf4: mov     x1, xzr                                    
02d53bf8: mov     x20, x0                                    
02d53bfc: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02d53c00: cbz     x0, #0x2d53cd0                             
02d53c04: mov     x1, xzr                                    
02d53c08: bl      #0x5b467ac                                 UnityEngine.Transform::get_position
02d53c0c: ldr     x0, [x19, #0x38]                           ._orderItems
02d53c10: cbz     x0, #0x2d53cd0                             
02d53c14: fadd    s8, s8, s11                                
02d53c18: fadd    s9, s9, s12                                
02d53c1c: mov     w21, #1                                    
02d53c20: fadd    s10, s10, s13                              
02d53c24: fsub    s0, s0, s8                                 
02d53c28: fsub    s1, s1, s9                                 
02d53c2c: fsub    s2, s2, s10                                
02d53c30: fmul    s0, s0, s0                                 
02d53c34: fmul    s1, s1, s1                                 
02d53c38: fmul    s2, s2, s2                                 
02d53c3c: fadd    s0, s0, s1                                 
02d53c40: fadd    s11, s2, s0                                
02d53c44: ldr     w8, [x0, #0x18]                            S:'level_show_popuprate'
02d53c48: cmp     w21, w8                                    
02d53c4c: b.ge    #0x2d53cd8                                 
02d53c50: ldr     x2, [x23]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d53c54: mov     w1, w21                                    
02d53c58: bl      #0x35a8f3c                                 fn_35a8f3c
02d53c5c: cbz     x0, #0x2d53cd0                             
02d53c60: mov     x1, xzr                                    
02d53c64: mov     x22, x0                                    
02d53c68: bl      #0x5b339ec                                 UnityEngine.Component::get_gameObject
02d53c6c: cbz     x0, #0x2d53cd0                             
02d53c70: mov     x1, xzr                                    
02d53c74: bl      #0x5b36bfc                                 UnityEngine.GameObject::get_activeSelf
02d53c78: tbz     w0, #0, #0x2d53cc4                         
02d53c7c: mov     x0, x22                                    
02d53c80: mov     x1, xzr                                    
02d53c84: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02d53c88: cbz     x0, #0x2d53cd0                             
02d53c8c: mov     x1, xzr                                    
02d53c90: bl      #0x5b467ac                                 UnityEngine.Transform::get_position
02d53c94: fsub    s0, s0, s8                                 
02d53c98: fsub    s1, s1, s9                                 
02d53c9c: fsub    s2, s2, s10                                
02d53ca0: fmul    s0, s0, s0                                 
02d53ca4: fmul    s1, s1, s1                                 
02d53ca8: fadd    s0, s0, s1                                 
02d53cac: fmul    s1, s2, s2                                 
02d53cb0: fadd    s0, s1, s0                                 
02d53cb4: fcmp    s0, s11                                    
02d53cb8: b.ge    #0x2d53cc4                                 
02d53cbc: fmov    s11, s0                                    
02d53cc0: mov     x20, x22                                   
02d53cc4: ldr     x0, [x19, #0x38]                           ._orderItems
02d53cc8: add     w21, w21, #1                               
02d53ccc: cbnz    x0, #0x2d53c44                             
02d53cd0: bl      #0x2b7105c                                 fn_2b7105c
02d53cd4: mov     x20, xzr                                   
02d53cd8: mov     x0, x20                                    
02d53cdc: ldp     x20, x19, [sp, #0x50]                      
02d53ce0: ldp     x22, x21, [sp, #0x40]                      
02d53ce4: ldp     x30, x23, [sp, #0x30]                      
02d53ce8: ldp     d9, d8, [sp, #0x20]                        
02d53cec: ldp     d11, d10, [sp, #0x10]                      
02d53cf0: ldp     d13, d12, [sp], #0x60                      
02d53cf4: ret                                                
02d53cf8: ldr     x0, [x19, #0x38]                           ._orderItems
02d53cfc: cbz     x0, #0x2d53cd0                             
02d53d00: adrp    x8, #0x626b000                             
02d53d04: mov     w1, wzr                                    
02d53d08: ldr     x8, [x8, #0x978]                           MS:System.Collections.Generic.List`1::get_Item
02d53d0c: ldp     x20, x19, [sp, #0x50]                      
02d53d10: ldp     x22, x21, [sp, #0x40]                      
02d53d14: ldp     x30, x23, [sp, #0x30]                      
02d53d18: ldr     x2, [x8]                                   T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d53d1c: ldp     d9, d8, [sp, #0x20]                        
02d53d20: ldp     d11, d10, [sp, #0x10]                      
02d53d24: ldp     d13, d12, [sp], #0x60                      
02d53d28: b       #0x35a8f3c                                 
## OnInit(Blindbag.BlindbagGameController controller) -> void
---- Blindbag.ItemBase::OnInit 0x2d520b0
02d520b0: str     x30, [sp, #-0x20]!                         
02d520b4: stp     x20, x19, [sp, #0x10]                      
02d520b8: mov     x20, x0                                    
02d520bc: mov     x19, x0                                    
02d520c0: str     x1, [x20, #0x50]!                          .Controller
02d520c4: mov     x0, x20                                    
02d520c8: bl      #0x2b70d54                                 fn_2b70d54
02d520cc: ldr     x8, [x20]                                  
02d520d0: cbz     x8, #0x2d52134                             
02d520d4: ldr     x0, [x8, #0x68]                            
02d520d8: cbz     x0, #0x2d52134                             
02d520dc: ldr     w1, [x19, #0x20]                           ._id
02d520e0: mov     x2, xzr                                    
02d520e4: bl      #0x2d3be4c                                 ScoopGame.BlindbagMarketAsset::GetData
02d520e8: mov     x1, x0                                     
02d520ec: str     x0, [x19, #0x58]!                          ._data
02d520f0: mov     x0, x19                                    
02d520f4: bl      #0x2b70d54                                 fn_2b70d54
02d520f8: ldr     x8, [x19]                                  
02d520fc: cbz     x8, #0x2d52134                             
02d52100: ldur    x19, [x19, #-0x30]                         
02d52104: add     x0, x8, #0x18                              
02d52108: mov     x1, xzr                                    
02d5210c: bl      #0x4e0ea3c                                 System.Int32::ToString
02d52110: cbz     x19, #0x2d52134                            
02d52114: ldr     x8, [x19]                                  
02d52118: mov     x1, x0                                     
02d5211c: mov     x0, x19                                    
02d52120: ldp     x20, x19, [sp, #0x10]                      
02d52124: ldr     x2, [x8, #0x560]                           
02d52128: ldr     x3, [x8, #0x558]                           
02d5212c: ldr     x30, [sp], #0x20                           
02d52130: br      x3                                         
02d52134: bl      #0x2b7105c                                 fn_2b7105c
## Shake(UnityEngine.Transform item) -> void
---- Blindbag.ItemBase::Shake 0x2d53d2c
02d53d2c: stp     x29, x30, [sp, #-0x60]!                    
02d53d30: stp     x28, x27, [sp, #0x10]                      
02d53d34: stp     x26, x25, [sp, #0x20]                      
02d53d38: stp     x24, x23, [sp, #0x30]                      
02d53d3c: stp     x22, x21, [sp, #0x40]                      
02d53d40: stp     x20, x19, [sp, #0x50]                      
02d53d44: adrp    x19, #0x6630000                            
02d53d48: adrp    x22, #0x626b000                            
02d53d4c: mov     x21, x1                                    
02d53d50: ldrb    w8, [x19, #0x26c]                          
02d53d54: ldr     x22, [x22, #0x980]                         T:Blindbag.ItemBase/<>c__DisplayClass12_0
02d53d58: mov     x20, x0                                    
02d53d5c: tbnz    w8, #0, #0x2d53db0                         
02d53d60: adrp    x0, #0x6264000                             
02d53d64: ldr     x0, [x0, #0xe8]                            T:DG.Tweening.TweenCallback
02d53d68: bl      #0x2b70db0                                 fn_2b70db0
02d53d6c: adrp    x0, #0x6267000                             
02d53d70: ldr     x0, [x0, #0xd30]                           MS:DG.Tweening.TweenSettingsExtensions::OnComplete
02d53d74: bl      #0x2b70db0                                 fn_2b70db0
02d53d78: adrp    x0, #0x6267000                             
02d53d7c: ldr     x0, [x0, #0xd38]                           MS:DG.Tweening.TweenSettingsExtensions::SetEase
02d53d80: bl      #0x2b70db0                                 fn_2b70db0
02d53d84: adrp    x0, #0x6268000                             
02d53d88: ldr     x0, [x0, #0x4e8]                           MS:DG.Tweening.TweenSettingsExtensions::SetLoops
02d53d8c: bl      #0x2b70db0                                 fn_2b70db0
02d53d90: adrp    x0, #0x626b000                             
02d53d94: ldr     x0, [x0, #0x988]                           M:Blindbag.ItemBase/<>c__DisplayClass12_0::<Shake>b__0
02d53d98: bl      #0x2b70db0                                 fn_2b70db0
02d53d9c: adrp    x0, #0x626b000                             
02d53da0: ldr     x0, [x0, #0x980]                           T:Blindbag.ItemBase/<>c__DisplayClass12_0
02d53da4: bl      #0x2b70db0                                 fn_2b70db0
02d53da8: mov     w8, #1                                     
02d53dac: strb    w8, [x19, #0x26c]                          
02d53db0: ldr     x0, [x22]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d53db4: bl      #0x2b7104c                                 fn_2b7104c
02d53db8: mov     x1, xzr                                    
02d53dbc: mov     x19, x0                                    
02d53dc0: bl      #0x4e53e9c                                 System.Object::.ctor
02d53dc4: cbz     x19, #0x2d53f3c                            
02d53dc8: mov     x0, x19                                    
02d53dcc: mov     x1, x20                                    
02d53dd0: str     x20, [x0, #0x10]!                          
02d53dd4: bl      #0x2b70d54                                 fn_2b70d54
02d53dd8: mov     x22, x19                                   
02d53ddc: mov     x1, x21                                    
02d53de0: str     x21, [x22, #0x18]!                         
02d53de4: mov     x0, x22                                    
02d53de8: bl      #0x2b70d54                                 fn_2b70d54
02d53dec: adrp    x27, #0x662f000                            
02d53df0: ldr     x21, [x22]                                 T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d53df4: mov     w23, #1                                    
02d53df8: ldrb    w8, [x27, #0x91c]                          
02d53dfc: strb    w23, [x20, #0x40]                          ._isCountdown
02d53e00: cbnz    w8, #0x2d53e14                             
02d53e04: adrp    x0, #0x6264000                             
02d53e08: ldr     x0, [x0, #0xd8]                            T:UnityEngine.Vector3
02d53e0c: bl      #0x2b70db0                                 fn_2b70db0
02d53e10: strb    w23, [x27, #0x91c]                         
02d53e14: cbz     x21, #0x2d53f3c                            
02d53e18: adrp    x29, #0x6264000                            
02d53e1c: fmov    v0.2s, #-5.00000000                        
02d53e20: adrp    x28, #0x6267000                            
02d53e24: ldr     x29, [x29, #0xd8]                          T:UnityEngine.Vector3
02d53e28: adrp    x26, #0x6268000                            
02d53e2c: adrp    x25, #0x6264000                            
02d53e30: adrp    x24, #0x626b000                            
02d53e34: adrp    x23, #0x6267000                            
02d53e38: mov     x0, x21                                    
02d53e3c: ldr     x8, [x29]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d53e40: mov     x1, xzr                                    
02d53e44: ldr     x8, [x8, #0xb8]                            
02d53e48: ldr     d1, [x8, #0x48]                            
02d53e4c: ldr     x28, [x28, #0xd38]                         MS:DG.Tweening.TweenSettingsExtensions::SetEase
02d53e50: ldr     x26, [x26, #0x4e8]                         MS:DG.Tweening.TweenSettingsExtensions::SetLoops
02d53e54: ldr     s2, [x8, #0x50]                            
02d53e58: ldr     x25, [x25, #0xe8]                          T:DG.Tweening.TweenCallback
02d53e5c: ldr     x24, [x24, #0x988]                         M:Blindbag.ItemBase/<>c__DisplayClass12_0::<Shake>b__0
02d53e60: fmul    v0.2s, v1.2s, v0.2s                        
02d53e64: fmov    s1, #-5.00000000                           
02d53e68: ldr     x23, [x23, #0xd30]                         MS:DG.Tweening.TweenSettingsExtensions::OnComplete
02d53e6c: fmul    s2, s2, s1                                 
02d53e70: mov     s1, v0.s[1]                                
02d53e74: bl      #0x5b46ac4                                 UnityEngine.Transform::set_eulerAngles
02d53e78: ldrb    w8, [x27, #0x91c]                          
02d53e7c: ldr     x20, [x22]                                 T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d53e80: cbnz    w8, #0x2d53e98                             
02d53e84: adrp    x0, #0x6264000                             
02d53e88: ldr     x0, [x0, #0xd8]                            T:UnityEngine.Vector3
02d53e8c: bl      #0x2b70db0                                 fn_2b70db0
02d53e90: mov     w8, #1                                     
02d53e94: strb    w8, [x27, #0x91c]                          
02d53e98: ldr     x8, [x29]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d53e9c: fmov    v0.2s, #5.00000000                         
02d53ea0: mov     x0, x20                                    
02d53ea4: mov     w1, wzr                                    
02d53ea8: mov     x2, xzr                                    
02d53eac: ldr     x8, [x8, #0xb8]                            
02d53eb0: ldr     d1, [x8, #0x48]                            
02d53eb4: ldr     s2, [x8, #0x50]                            
02d53eb8: adrp    x8, #0x1084000                             
02d53ebc: ldr     s3, [x8, #0xda4]                           [1084da4]=3eb851ec3e19999a f=0.15,0.36
02d53ec0: fmul    v0.2s, v1.2s, v0.2s                        
02d53ec4: fmov    s1, #5.00000000                            
02d53ec8: fmul    s2, s2, s1                                 
02d53ecc: mov     s1, v0.s[1]                                
02d53ed0: bl      #0x2d983c8                                 DG.Tweening.ShortcutExtensions::DORotate
02d53ed4: ldr     x2, [x28]                                  S:'didu'
02d53ed8: mov     w1, #1                                     
02d53edc: bl      #0x336fa0c                                 fn_336fa0c
02d53ee0: ldr     x3, [x26]                                  S:'{0}/2'
02d53ee4: mov     w1, #4                                     
02d53ee8: mov     w2, #1                                     
02d53eec: bl      #0x336fe74                                 fn_336fe74
02d53ef0: ldr     x8, [x25]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d53ef4: mov     x20, x0                                    
02d53ef8: mov     x0, x8                                     
02d53efc: bl      #0x2b7104c                                 fn_2b7104c
02d53f00: ldr     x2, [x24]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d53f04: mov     x1, x19                                    
02d53f08: mov     x3, xzr                                    
02d53f0c: mov     x21, x0                                    
02d53f10: bl      #0x2d89dc4                                 DG.Tweening.TweenCallback::.ctor
02d53f14: ldr     x2, [x23]                                  S:'didu'
02d53f18: mov     x0, x20                                    
02d53f1c: mov     x1, x21                                    
02d53f20: ldp     x20, x19, [sp, #0x50]                      
02d53f24: ldp     x22, x21, [sp, #0x40]                      
02d53f28: ldp     x24, x23, [sp, #0x30]                      
02d53f2c: ldp     x26, x25, [sp, #0x20]                      
02d53f30: ldp     x28, x27, [sp, #0x10]                      
02d53f34: ldp     x29, x30, [sp], #0x60                      
02d53f38: b       #0x336f26c                                 
02d53f3c: bl      #0x2b7105c                                 fn_2b7105c
## OnMouseButtonDown() -> void
---- Blindbag.ItemBase::OnMouseButtonDown 0x2d53f48
02d53f48: sub     sp, sp, #0x90                              
02d53f4c: stp     x30, x21, [sp, #0x70]                      
02d53f50: stp     x20, x19, [sp, #0x80]                      
02d53f54: adrp    x21, #0x6630000                            
02d53f58: adrp    x20, #0x626b000                            
02d53f5c: mov     x19, x0                                    
02d53f60: ldrb    w8, [x21, #0x26d]                          
02d53f64: ldr     x20, [x20, #0x990]                         MS:System.Runtime.CompilerServices.AsyncVoidMethodBuilder::Start
02d53f68: tbnz    w8, #0, #0x2d53f80                         
02d53f6c: adrp    x0, #0x626b000                             
02d53f70: ldr     x0, [x0, #0x990]                           MS:System.Runtime.CompilerServices.AsyncVoidMethodBuilder::Start
02d53f74: bl      #0x2b70db0                                 fn_2b70db0
02d53f78: mov     w8, #1                                     
02d53f7c: strb    w8, [x21, #0x26d]                          
02d53f80: movi    v0.2d, #0000000000000000                   
02d53f84: mov     x8, sp                                     
02d53f88: mov     x0, xzr                                    
02d53f8c: stp     q0, q0, [sp, #0x30]                        
02d53f90: stp     q0, q0, [sp, #0x50]                        
02d53f94: str     q0, [sp, #0x20]                            
02d53f98: bl      #0x4d43a24                                 System.Runtime.CompilerServices.AsyncVoidMethodBuilder::Create
02d53f9c: ldp     q0, q1, [sp]                               
02d53fa0: add     x21, sp, #0x20                             
02d53fa4: orr     x0, x21, #8                                
02d53fa8: mov     x1, xzr                                    
02d53fac: stur    q0, [sp, #0x28]                            
02d53fb0: stur    q1, [sp, #0x38]                            
02d53fb4: bl      #0x2b70d54                                 fn_2b70d54
02d53fb8: add     x0, x21, #0x28                             &6630028
02d53fbc: mov     x1, x19                                    
02d53fc0: str     x19, [sp, #0x48]                           
02d53fc4: bl      #0x2b70d54                                 fn_2b70d54
02d53fc8: ldr     x2, [x20]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d53fcc: mov     w8, #-1                                    
02d53fd0: orr     x0, x21, #8                                
02d53fd4: add     x1, sp, #0x20                              
02d53fd8: str     w8, [sp, #0x20]                            
02d53fdc: bl      #0x30c7d8c                                 fn_30c7d8c
02d53fe0: ldp     x20, x19, [sp, #0x80]                      
02d53fe4: ldp     x30, x21, [sp, #0x70]                      
02d53fe8: add     sp, sp, #0x90                              
02d53fec: ret                                                
##  CreateItem (no body)
## SetEnableBoxCollider(bool value) -> void
---- Blindbag.ItemBase::SetEnableBoxCollider 0x2d53ff0
02d53ff0: ldr     x0, [x0, #0x30]                            ._collider
02d53ff4: cbz     x0, #0x2d54004                             
02d53ff8: and     w1, w1, #1                                 
02d53ffc: mov     x2, xzr                                    
02d54000: b       #0x5b33110                                 UnityEngine.Behaviour::set_enabled
02d54004: str     x30, [sp, #-0x10]!                         
02d54008: bl      #0x2b7105c                                 fn_2b7105c
## OnMouseButtonDrag() -> void
---- Blindbag.ItemBase::OnMouseButtonDrag 0x2d5400c
02d5400c: ret                                                
## OnMouseButtonUp() -> void
---- Blindbag.ItemBase::OnMouseButtonUp 0x2d54010
02d54010: ret                                                
## .ctor() -> void
---- Blindbag.ItemBase::.ctor 0x2d54014
02d54014: mov     x1, xzr                                    
02d54018: b       #0x5b397b0                                 UnityEngine.MonoBehaviour::.ctor
