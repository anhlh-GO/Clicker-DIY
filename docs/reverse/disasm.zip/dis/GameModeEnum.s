#### CLASS GameModeEnum parent= int
#   field value__                        int                                                off=0x10 attr=606 
#   field None                           GameModeEnum                                       off=0x0 attr=8056 
#   field Clicker                        GameModeEnum                                       off=0x0 attr=8056 
#   field BlindBag                       GameModeEnum                                       off=0x0 attr=8056 
#   field Scoop                          GameModeEnum                                       off=0x0 attr=8056 
