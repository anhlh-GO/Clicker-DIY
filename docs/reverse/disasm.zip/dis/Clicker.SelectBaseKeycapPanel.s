#### CLASS Clicker.SelectBaseKeycapPanel/<>c__DisplayClass13_0 parent= object
#   field dataUser                       DataUser                                           off=0x10 attr=6 
#   field <>4__this                      Clicker.SelectBaseKeycapPanel                      off=0x18 attr=6 
#   field <>9__0                         System.Action`1<int>                               off=0x20 attr=6 
## .ctor() -> void
---- Clicker.SelectBaseKeycapPanel/<>c__DisplayClass13_0::.ctor 0x2d71f34
02d71f34: mov     x1, xzr                                    
02d71f38: b       #0x4e53e9c                                 System.Object::.ctor
## <LoadData>b__0(int id) -> void
---- Clicker.SelectBaseKeycapPanel/<>c__DisplayClass13_0::<LoadData>b__0 0x2d7220c
02d7220c: stp     x30, x21, [sp, #-0x20]!                    
02d72210: stp     x20, x19, [sp, #0x10]                      
02d72214: adrp    x21, #0x6630000                            
02d72218: mov     w19, w1                                    
02d7221c: mov     x20, x0                                    
02d72220: ldrb    w8, [x21, #0x3b5]                          
02d72224: tbnz    w8, #0, #0x2d7223c                         
02d72228: adrp    x0, #0x626b000                             
02d7222c: ldr     x0, [x0, #0xee0]                           MS:MonoSingleton`1::get_Instance
02d72230: bl      #0x2b70db0                                 fn_2b70db0
02d72234: mov     w8, #1                                     
02d72238: strb    w8, [x21, #0x3b5]                          
02d7223c: ldr     x0, [x20, #0x10]                           .dataUser
02d72240: cbz     x0, #0x2d722c4                             
02d72244: adrp    x21, #0x626b000                            
02d72248: mov     w1, w19                                    
02d7224c: mov     x2, xzr                                    
02d72250: ldr     x21, [x21, #0xee0]                         MS:MonoSingleton`1::get_Instance
02d72254: bl      #0x2cabedc                                 DataUser::UnlockClickerBase
02d72258: ldr     x0, [x21]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d7225c: bl      #0x3769600                                 fn_3769600
02d72260: cbz     x0, #0x2d722c4                             
02d72264: mov     w1, w19                                    
02d72268: mov     x2, xzr                                    
02d7226c: bl      #0x2d6c4ec                                 Clicker.KeycapMakerController::SetBaseKeycapId
02d72270: ldr     x8, [x20, #0x18]                           .<>4__this
02d72274: cbz     x8, #0x2d722c4                             
02d72278: ldr     x0, [x8, #0x58]                            
02d7227c: cbz     x0, #0x2d722c4                             
02d72280: mov     w1, #1                                     
02d72284: mov     x2, xzr                                    
02d72288: bl      #0x2d6519c                                 Clicker.IngameClickerScreen::ShowBtnNext
02d7228c: ldr     x0, [x20, #0x18]                           .<>4__this
02d72290: cbz     x0, #0x2d722c4                             
02d72294: mov     w1, w19                                    
02d72298: bl      #0x2d71f3c                                 Clicker.SelectBaseKeycapPanel::OnItemSelect
02d7229c: ldr     x8, [x20, #0x18]                           .<>4__this
02d722a0: cbz     x8, #0x2d722c4                             
02d722a4: ldr     x0, [x8, #0x58]                            
02d722a8: mov     w9, #1                                     
02d722ac: strb    w9, [x8, #0x60]                            
02d722b0: cbz     x0, #0x2d722c4                             
02d722b4: ldp     x20, x19, [sp, #0x10]                      
02d722b8: mov     x1, xzr                                    
02d722bc: ldp     x30, x21, [sp], #0x20                      
02d722c0: b       #0x2d6a9a4                                 Clicker.IngameClickerScreen::HideTutorial
02d722c4: bl      #0x2b7105c                                 fn_2b7105c
#### CLASS Clicker.SelectBaseKeycapPanel/<>c__DisplayClass14_0 parent= object
#   field id                             int                                                off=0x10 attr=6 
## .ctor() -> void
---- Clicker.SelectBaseKeycapPanel/<>c__DisplayClass14_0::.ctor 0x2d72014
02d72014: mov     x1, xzr                                    
02d72018: b       #0x4e53e9c                                 System.Object::.ctor
## <OnItemSelect>b__0(Clicker.BaseKeycapUIItem item) -> void
---- Clicker.SelectBaseKeycapPanel/<>c__DisplayClass14_0::<OnItemSelect>b__0 0x2d722c8
02d722c8: str     x30, [sp, #-0x20]!                         
02d722cc: stp     x20, x19, [sp, #0x10]                      
02d722d0: cbz     x1, #0x2d7232c                             
02d722d4: mov     x19, x1                                    
02d722d8: mov     x20, x0                                    
02d722dc: mov     x0, x1                                     
02d722e0: mov     x1, xzr                                    
02d722e4: bl      #0x5b339ec                                 UnityEngine.Component::get_gameObject
02d722e8: cbz     x0, #0x2d7232c                             
02d722ec: mov     x1, xzr                                    
02d722f0: bl      #0x5b36bfc                                 UnityEngine.GameObject::get_activeSelf
02d722f4: tbz     w0, #0, #0x2d72320                         
02d722f8: ldr     x10, [x19]                                 
02d722fc: ldr     w8, [x19, #0x6c]                           
02d72300: mov     x0, x19                                    
02d72304: ldr     w9, [x20, #0x10]                           .id
02d72308: ldp     x20, x19, [sp, #0x10]                      
02d7230c: ldp     x3, x2, [x10, #0x188]                      
02d72310: cmp     w8, w9                                     
02d72314: cset    w1, eq                                     
02d72318: ldr     x30, [sp], #0x20                           
02d7231c: br      x3                                         
02d72320: ldp     x20, x19, [sp, #0x10]                      
02d72324: ldr     x30, [sp], #0x20                           
02d72328: ret                                                
02d7232c: bl      #0x2b7105c                                 fn_2b7105c
#### CLASS Clicker.SelectBaseKeycapPanel parent= UnityEngine.MonoBehaviour
#   field _baseKeycapUIItem              Clicker.BaseKeycapUIItem                           off=0x20 attr=1 SerializeField
#   field _listItem                      System.Collections.Generic.List`1<Clicker.BaseKeycapUIItem> off=0x28 attr=1 SerializeField
#   field _configBaseKeycap              Clicker.BaseKeycapConfig                           off=0x30 attr=1 SerializeField
#   field _rtShowPos                     UnityEngine.RectTransform                          off=0x38 attr=1 SerializeField
#   field _rtHidePos                     UnityEngine.RectTransform                          off=0x40 attr=1 SerializeField
#   field _thisPanelRect                 UnityEngine.RectTransform                          off=0x48 attr=1 SerializeField
#   field _btnNextPos                    UnityEngine.Transform                              off=0x50 attr=1 SerializeField
#   field _ingameClickerScreen           Clicker.IngameClickerScreen                        off=0x58 attr=1 
#   field _tutorialShown                 bool                                               off=0x60 attr=1 
## Init(Clicker.IngameClickerScreen ingameClickerScreen) -> void
---- Clicker.SelectBaseKeycapPanel::Init 0x2d717f4
02d717f4: str     x1, [x0, #0x58]!                           ._ingameClickerScreen
02d717f8: b       #0x2b70d54                                 
## Awake() -> void
---- Clicker.SelectBaseKeycapPanel::Awake 0x2d717fc
02d717fc: str     x30, [sp, #-0x20]!                         
02d71800: stp     x20, x19, [sp, #0x10]                      
02d71804: mov     x19, x0                                    
02d71808: ldr     x0, [x0, #0x40]                            ._rtHidePos
02d7180c: cbz     x0, #0x2d7185c                             
02d71810: ldr     x20, [x19, #0x48]                          ._thisPanelRect
02d71814: mov     x1, xzr                                    
02d71818: bl      #0x5b45734                                 UnityEngine.RectTransform::get_anchoredPosition
02d7181c: cbz     x20, #0x2d7185c                            
02d71820: mov     x0, x20                                    
02d71824: mov     x1, xzr                                    
02d71828: bl      #0x5b45800                                 UnityEngine.RectTransform::set_anchoredPosition
02d7182c: ldr     x0, [x19, #0x48]                           ._thisPanelRect
02d71830: cbz     x0, #0x2d7185c                             
02d71834: mov     x1, xzr                                    
02d71838: bl      #0x5b339ec                                 UnityEngine.Component::get_gameObject
02d7183c: cbz     x0, #0x2d7185c                             
02d71840: mov     w1, wzr                                    
02d71844: mov     x2, xzr                                    
02d71848: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d7184c: mov     x0, x19                                    
02d71850: ldp     x20, x19, [sp, #0x10]                      
02d71854: ldr     x30, [sp], #0x20                           
02d71858: b       #0x2d71860                                 Clicker.SelectBaseKeycapPanel::LoadData
02d7185c: bl      #0x2b7105c                                 fn_2b7105c
## ShowPanel() -> void
---- Clicker.SelectBaseKeycapPanel::ShowPanel 0x2d71ca4
02d71ca4: str     x30, [sp, #-0x50]!                         
02d71ca8: stp     x26, x25, [sp, #0x10]                      
02d71cac: stp     x24, x23, [sp, #0x20]                      
02d71cb0: stp     x22, x21, [sp, #0x30]                      
02d71cb4: stp     x20, x19, [sp, #0x40]                      
02d71cb8: adrp    x20, #0x6630000                            
02d71cbc: mov     x19, x0                                    
02d71cc0: ldrb    w8, [x20, #0x3af]                          
02d71cc4: tbnz    w8, #0, #0x2d71d18                         
02d71cc8: adrp    x0, #0x6264000                             
02d71ccc: ldr     x0, [x0, #0xf90]                           T:System.Action
02d71cd0: bl      #0x2b70db0                                 fn_2b70db0
02d71cd4: adrp    x0, #0x626c000                             
02d71cd8: ldr     x0, [x0, #0x5f8]                           M:Clicker.SelectBaseKeycapPanel::<ShowPanel>b__11_0
02d71cdc: bl      #0x2b70db0                                 fn_2b70db0
02d71ce0: adrp    x0, #0x626c000                             
02d71ce4: ldr     x0, [x0, #0x600]                           M:Clicker.SelectBaseKeycapPanel::<ShowPanel>b__11_1
02d71ce8: bl      #0x2b70db0                                 fn_2b70db0
02d71cec: adrp    x0, #0x6264000                             
02d71cf0: ldr     x0, [x0, #0xe8]                            T:DG.Tweening.TweenCallback
02d71cf4: bl      #0x2b70db0                                 fn_2b70db0
02d71cf8: adrp    x0, #0x6266000                             
02d71cfc: ldr     x0, [x0, #0xa08]                           MS:DG.Tweening.TweenSettingsExtensions::OnComplete
02d71d00: bl      #0x2b70db0                                 fn_2b70db0
02d71d04: adrp    x0, #0x6266000                             
02d71d08: ldr     x0, [x0, #0xa18]                           MS:DG.Tweening.TweenSettingsExtensions::SetEase
02d71d0c: bl      #0x2b70db0                                 fn_2b70db0
02d71d10: mov     w8, #1                                     
02d71d14: strb    w8, [x20, #0x3af]                          
02d71d18: ldr     x0, [x19, #0x48]                           ._thisPanelRect
02d71d1c: cbz     x0, #0x2d71e3c                             
02d71d20: mov     x1, xzr                                    
02d71d24: bl      #0x5b339ec                                 UnityEngine.Component::get_gameObject
02d71d28: cbz     x0, #0x2d71e3c                             
02d71d2c: mov     w1, #1                                     
02d71d30: mov     x2, xzr                                    
02d71d34: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d71d38: ldr     x0, [x19, #0x38]                           ._rtShowPos
02d71d3c: cbz     x0, #0x2d71e3c                             
02d71d40: adrp    x21, #0x6266000                            
02d71d44: adrp    x23, #0x6264000                            
02d71d48: adrp    x24, #0x626c000                            
02d71d4c: adrp    x25, #0x6266000                            
02d71d50: adrp    x26, #0x6264000                            
02d71d54: adrp    x22, #0x626c000                            
02d71d58: ldr     x21, [x21, #0xa18]                         MS:DG.Tweening.TweenSettingsExtensions::SetEase
02d71d5c: ldr     x23, [x23, #0xe8]                          T:DG.Tweening.TweenCallback
02d71d60: ldr     x24, [x24, #0x5f8]                         M:Clicker.SelectBaseKeycapPanel::<ShowPanel>b__11_0
02d71d64: ldr     x25, [x25, #0xa08]                         MS:DG.Tweening.TweenSettingsExtensions::OnComplete
02d71d68: ldr     x26, [x26, #0xf90]                         T:System.Action
02d71d6c: ldr     x22, [x22, #0x600]                         M:Clicker.SelectBaseKeycapPanel::<ShowPanel>b__11_1
02d71d70: ldr     x20, [x19, #0x48]                          ._thisPanelRect
02d71d74: mov     x1, xzr                                    
02d71d78: bl      #0x5b45734                                 UnityEngine.RectTransform::get_anchoredPosition
02d71d7c: fmov    s2, #0.50000000                            
02d71d80: mov     x0, x20                                    
02d71d84: mov     w1, wzr                                    
02d71d88: mov     x2, xzr                                    
02d71d8c: bl      #0x2c798bc                                 DG.Tweening.DOTweenModuleUI::DOAnchorPos
02d71d90: ldr     x2, [x21]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d71d94: mov     w1, #3                                     
02d71d98: bl      #0x336fa0c                                 fn_336fa0c
02d71d9c: ldr     x8, [x23]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d71da0: mov     x20, x0                                    
02d71da4: mov     x0, x8                                     
02d71da8: bl      #0x2b7104c                                 fn_2b7104c
02d71dac: ldr     x2, [x24]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d71db0: mov     x1, x19                                    
02d71db4: mov     x3, xzr                                    
02d71db8: mov     x21, x0                                    
02d71dbc: bl      #0x2d89dc4                                 DG.Tweening.TweenCallback::.ctor
02d71dc0: ldr     x2, [x25]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d71dc4: mov     x0, x20                                    
02d71dc8: mov     x1, x21                                    
02d71dcc: bl      #0x336f26c                                 fn_336f26c
02d71dd0: ldr     x0, [x26]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d71dd4: ldr     x20, [x19, #0x58]                          ._ingameClickerScreen
02d71dd8: bl      #0x2b7104c                                 fn_2b7104c
02d71ddc: ldr     x2, [x22]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d71de0: mov     x1, x19                                    
02d71de4: mov     x3, xzr                                    
02d71de8: mov     x21, x0                                    
02d71dec: bl      #0x4d8ddbc                                 System.Action::.ctor
02d71df0: cbz     x20, #0x2d71e3c                            
02d71df4: mov     x0, x20                                    
02d71df8: mov     x1, x21                                    
02d71dfc: mov     x2, xzr                                    
02d71e00: bl      #0x2d69948                                 Clicker.IngameClickerScreen::RegisterButtonNextEvent
02d71e04: ldr     x0, [x19, #0x50]                           ._btnNextPos
02d71e08: cbz     x0, #0x2d71e3c                             
02d71e0c: ldr     x19, [x19, #0x58]                          ._ingameClickerScreen
02d71e10: mov     x1, xzr                                    
02d71e14: bl      #0x5b467ac                                 UnityEngine.Transform::get_position
02d71e18: cbz     x19, #0x2d71e3c                            
02d71e1c: mov     x0, x19                                    
02d71e20: ldp     x20, x19, [sp, #0x40]                      
02d71e24: ldp     x22, x21, [sp, #0x30]                      
02d71e28: mov     x1, xzr                                    
02d71e2c: ldp     x24, x23, [sp, #0x20]                      
02d71e30: ldp     x26, x25, [sp, #0x10]                      
02d71e34: ldr     x30, [sp], #0x50                           
02d71e38: b       #0x2d69a28                                 Clicker.IngameClickerScreen::SetBtnNextPosition
02d71e3c: bl      #0x2b7105c                                 fn_2b7105c
## HidePanel() -> void
---- Clicker.SelectBaseKeycapPanel::HidePanel 0x2d71e40
02d71e40: str     x30, [sp, #-0x40]!                         
02d71e44: stp     x24, x23, [sp, #0x10]                      
02d71e48: stp     x22, x21, [sp, #0x20]                      
02d71e4c: stp     x20, x19, [sp, #0x30]                      
02d71e50: adrp    x20, #0x6630000                            
02d71e54: mov     x19, x0                                    
02d71e58: ldrb    w8, [x20, #0x3b0]                          
02d71e5c: tbnz    w8, #0, #0x2d71e98                         
02d71e60: adrp    x0, #0x626c000                             
02d71e64: ldr     x0, [x0, #0x608]                           M:Clicker.SelectBaseKeycapPanel::<HidePanel>b__12_0
02d71e68: bl      #0x2b70db0                                 fn_2b70db0
02d71e6c: adrp    x0, #0x6264000                             
02d71e70: ldr     x0, [x0, #0xe8]                            T:DG.Tweening.TweenCallback
02d71e74: bl      #0x2b70db0                                 fn_2b70db0
02d71e78: adrp    x0, #0x6266000                             
02d71e7c: ldr     x0, [x0, #0xa08]                           MS:DG.Tweening.TweenSettingsExtensions::OnComplete
02d71e80: bl      #0x2b70db0                                 fn_2b70db0
02d71e84: adrp    x0, #0x6266000                             
02d71e88: ldr     x0, [x0, #0xa18]                           MS:DG.Tweening.TweenSettingsExtensions::SetEase
02d71e8c: bl      #0x2b70db0                                 fn_2b70db0
02d71e90: mov     w8, #1                                     
02d71e94: strb    w8, [x20, #0x3b0]                          
02d71e98: ldr     x0, [x19, #0x40]                           ._rtHidePos
02d71e9c: cbz     x0, #0x2d71f30                             
02d71ea0: adrp    x21, #0x6266000                            
02d71ea4: adrp    x22, #0x6264000                            
02d71ea8: adrp    x23, #0x626c000                            
02d71eac: adrp    x24, #0x6266000                            
02d71eb0: ldr     x21, [x21, #0xa18]                         MS:DG.Tweening.TweenSettingsExtensions::SetEase
02d71eb4: ldr     x22, [x22, #0xe8]                          T:DG.Tweening.TweenCallback
02d71eb8: ldr     x23, [x23, #0x608]                         M:Clicker.SelectBaseKeycapPanel::<HidePanel>b__12_0
02d71ebc: ldr     x24, [x24, #0xa08]                         MS:DG.Tweening.TweenSettingsExtensions::OnComplete
02d71ec0: ldr     x20, [x19, #0x48]                          ._thisPanelRect
02d71ec4: mov     x1, xzr                                    
02d71ec8: bl      #0x5b45734                                 UnityEngine.RectTransform::get_anchoredPosition
02d71ecc: fmov    s2, #0.50000000                            
02d71ed0: mov     x0, x20                                    
02d71ed4: mov     w1, wzr                                    
02d71ed8: mov     x2, xzr                                    
02d71edc: bl      #0x2c798bc                                 DG.Tweening.DOTweenModuleUI::DOAnchorPos
02d71ee0: ldr     x2, [x21]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d71ee4: mov     w1, #2                                     
02d71ee8: bl      #0x336fa0c                                 fn_336fa0c
02d71eec: ldr     x8, [x22]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d71ef0: mov     x20, x0                                    
02d71ef4: mov     x0, x8                                     
02d71ef8: bl      #0x2b7104c                                 fn_2b7104c
02d71efc: ldr     x2, [x23]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d71f00: mov     x1, x19                                    
02d71f04: mov     x3, xzr                                    
02d71f08: mov     x21, x0                                    
02d71f0c: bl      #0x2d89dc4                                 DG.Tweening.TweenCallback::.ctor
02d71f10: ldr     x2, [x24]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d71f14: mov     x0, x20                                    
02d71f18: mov     x1, x21                                    
02d71f1c: ldp     x20, x19, [sp, #0x30]                      
02d71f20: ldp     x22, x21, [sp, #0x20]                      
02d71f24: ldp     x24, x23, [sp, #0x10]                      
02d71f28: ldr     x30, [sp], #0x40                           
02d71f2c: b       #0x336f26c                                 
02d71f30: bl      #0x2b7105c                                 fn_2b7105c
## LoadData() -> void
---- Clicker.SelectBaseKeycapPanel::LoadData 0x2d71860
02d71860: stp     x29, x30, [sp, #-0x60]!                    
02d71864: stp     x28, x27, [sp, #0x10]                      
02d71868: stp     x26, x25, [sp, #0x20]                      
02d7186c: stp     x24, x23, [sp, #0x30]                      
02d71870: stp     x22, x21, [sp, #0x40]                      
02d71874: stp     x20, x19, [sp, #0x50]                      
02d71878: adrp    x20, #0x6630000                            
02d7187c: adrp    x21, #0x626c000                            
02d71880: mov     x19, x0                                    
02d71884: ldrb    w8, [x20, #0x3b1]                          
02d71888: ldr     x21, [x21, #0x5c8]                         T:Clicker.SelectBaseKeycapPanel/<>c__DisplayClass13_0
02d7188c: tbnz    w8, #0, #0x2d71910                         
02d71890: adrp    x0, #0x6269000                             
02d71894: ldr     x0, [x0, #0x5e8]                           T:type6940(k15)
02d71898: bl      #0x2b70db0                                 fn_2b70db0
02d7189c: adrp    x0, #0x6266000                             
02d718a0: ldr     x0, [x0, #0x750]                           MS:DataManager::GetData
02d718a4: bl      #0x2b70db0                                 fn_2b70db0
02d718a8: adrp    x0, #0x626c000                             
02d718ac: ldr     x0, [x0, #0x5d0]                           MS:System.Collections.Generic.List`1::Add
02d718b0: bl      #0x2b70db0                                 fn_2b70db0
02d718b4: adrp    x0, #0x626c000                             
02d718b8: ldr     x0, [x0, #0x5d8]                           MS:System.Collections.Generic.List`1::get_Count
02d718bc: bl      #0x2b70db0                                 fn_2b70db0
02d718c0: adrp    x0, #0x626c000                             
02d718c4: ldr     x0, [x0, #0x5e0]                           MS:System.Collections.Generic.List`1::get_Item
02d718c8: bl      #0x2b70db0                                 fn_2b70db0
02d718cc: adrp    x0, #0x6266000                             
02d718d0: ldr     x0, [x0, #0x658]                           MS:MonoSingleton`1::get_Instance
02d718d4: bl      #0x2b70db0                                 fn_2b70db0
02d718d8: adrp    x0, #0x626c000                             
02d718dc: ldr     x0, [x0, #0x5e8]                           MS:UnityEngine.Object::Instantiate
02d718e0: bl      #0x2b70db0                                 fn_2b70db0
02d718e4: adrp    x0, #0x6263000                             
02d718e8: ldr     x0, [x0, #0x918]                           T:UnityEngine.Object
02d718ec: bl      #0x2b70db0                                 fn_2b70db0
02d718f0: adrp    x0, #0x626c000                             
02d718f4: ldr     x0, [x0, #0x5f0]                           M:Clicker.SelectBaseKeycapPanel/<>c__DisplayClass13_0::<LoadData>b__0
02d718f8: bl      #0x2b70db0                                 fn_2b70db0
02d718fc: adrp    x0, #0x626c000                             
02d71900: ldr     x0, [x0, #0x5c8]                           T:Clicker.SelectBaseKeycapPanel/<>c__DisplayClass13_0
02d71904: bl      #0x2b70db0                                 fn_2b70db0
02d71908: mov     w8, #1                                     
02d7190c: strb    w8, [x20, #0x3b1]                          
02d71910: ldr     x0, [x21]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d71914: bl      #0x2b7104c                                 fn_2b7104c
02d71918: mov     x1, xzr                                    
02d7191c: mov     x20, x0                                    
02d71920: bl      #0x4e53e9c                                 System.Object::.ctor
02d71924: cbz     x20, #0x2d71c84                            
02d71928: mov     x0, x20                                    
02d7192c: mov     x1, x19                                    
02d71930: str     x19, [x0, #0x18]!                          
02d71934: bl      #0x2b70d54                                 fn_2b70d54
02d71938: ldr     x8, [x19, #0x28]                           ._listItem
02d7193c: cbz     x8, #0x2d71c84                             
02d71940: adrp    x27, #0x626c000                            
02d71944: adrp    x28, #0x6269000                            
02d71948: adrp    x29, #0x626c000                            
02d7194c: adrp    x26, #0x6263000                            
02d71950: adrp    x24, #0x626c000                            
02d71954: adrp    x25, #0x626c000                            
02d71958: ldr     x27, [x27, #0x5e0]                         MS:System.Collections.Generic.List`1::get_Item
02d7195c: ldr     x28, [x28, #0x5e8]                         T:type6940(k15)
02d71960: ldr     x29, [x29, #0x5f0]                         M:Clicker.SelectBaseKeycapPanel/<>c__DisplayClass13_0::<LoadData>b__0
02d71964: ldr     x26, [x26, #0x918]                         T:UnityEngine.Object
02d71968: ldr     x24, [x24, #0x5e8]                         MS:UnityEngine.Object::Instantiate
02d7196c: ldr     x25, [x25, #0x5d0]                         MS:System.Collections.Generic.List`1::Add
02d71970: ldr     x0, [x19, #0x30]                           ._configBaseKeycap
02d71974: cbz     x0, #0x2d71c84                             
02d71978: ldr     w21, [x8, #0x18]                           
02d7197c: mov     x1, xzr                                    
02d71980: bl      #0x2d5b248                                 Clicker.BaseKeycapConfig::get_Count
02d71984: cmp     w21, w0                                    
02d71988: b.ge    #0x2d71a40                                 
02d7198c: ldr     x22, [x19, #0x20]                          ._baseKeycapUIItem
02d71990: cbz     x22, #0x2d71c84                            
02d71994: ldr     x21, [x19, #0x28]                          ._listItem
02d71998: mov     x0, x22                                    
02d7199c: mov     x1, xzr                                    
02d719a0: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02d719a4: cbz     x0, #0x2d71c84                             
02d719a8: mov     x1, xzr                                    
02d719ac: bl      #0x5b466dc                                 UnityEngine.Transform::get_parent
02d719b0: ldr     x8, [x26]                                  &2c5bbd4(=a9bd7bfdd503233f)
02d719b4: mov     x23, x0                                    
02d719b8: ldr     w9, [x8, #0xe4]                            
02d719bc: cbnz    w9, #0x2d719c8                             
02d719c0: mov     x0, x8                                     
02d719c4: bl      #0x2b70f30                                 fn_2b70f30
02d719c8: ldr     x2, [x24]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d719cc: mov     x0, x22                                    
02d719d0: mov     x1, x23                                    
02d719d4: bl      #0x3275fcc                                 fn_3275fcc
02d719d8: cbz     x21, #0x2d71c84                            
02d719dc: ldr     w10, [x21, #0x1c]                          [626c01c]=0 f=0,0
02d719e0: ldr     x8, [x21, #0x10]                           M:Clicker.GlowSprite2DItem::<DoGlow>b__10_4
02d719e4: ldr     x9, [x25]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d719e8: add     w10, w10, #1                               
02d719ec: str     w10, [x21, #0x1c]                          
02d719f0: cbz     x8, #0x2d71c84                             
02d719f4: ldrsw   x10, [x21, #0x18]                          
02d719f8: ldr     w11, [x8, #0x18]                           
02d719fc: mov     x1, x0                                     
02d71a00: cmp     w10, w11                                   
02d71a04: b.hs    #0x2d71a20                                 
02d71a08: add     x0, x8, x10, lsl #3                        
02d71a0c: add     w9, w10, #1                                
02d71a10: str     w9, [x21, #0x18]                           
02d71a14: str     x1, [x0, #0x20]!                           ._baseKeycapUIItem
02d71a18: bl      #0x2b70d54                                 fn_2b70d54
02d71a1c: b       #0x2d71a34                                 
02d71a20: ldr     x8, [x9, #0x20]                            
02d71a24: mov     x0, x21                                    
02d71a28: ldr     x8, [x8, #0xc0]                            
02d71a2c: ldr     x2, [x8, #0x70]                            
02d71a30: bl      #0x35a920c                                 fn_35a920c
02d71a34: ldr     x8, [x19, #0x28]                           ._listItem
02d71a38: cbnz    x8, #0x2d71970                             
02d71a3c: b       #0x2d71c84                                 
02d71a40: adrp    x8, #0x6266000                             
02d71a44: ldr     x8, [x8, #0x658]                           MS:MonoSingleton`1::get_Instance
02d71a48: ldr     x0, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d71a4c: bl      #0x3769600                                 fn_3769600
02d71a50: cbz     x0, #0x2d71c84                             
02d71a54: adrp    x8, #0x6266000                             
02d71a58: ldr     x8, [x8, #0x750]                           MS:DataManager::GetData
02d71a5c: ldr     x1, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d71a60: bl      #0x3168dd0                                 fn_3168dd0
02d71a64: mov     x21, x20                                   
02d71a68: mov     x1, x0                                     
02d71a6c: str     x0, [x21, #0x10]!                          
02d71a70: mov     x0, x21                                    
02d71a74: bl      #0x2b70d54                                 fn_2b70d54
02d71a78: ldr     x0, [x19, #0x30]                           ._configBaseKeycap
02d71a7c: cbz     x0, #0x2d71c84                             
02d71a80: mov     w22, wzr                                   
02d71a84: mov     x1, xzr                                    
02d71a88: bl      #0x2d5b248                                 Clicker.BaseKeycapConfig::get_Count
02d71a8c: mov     w8, w0                                     
02d71a90: ldr     x0, [x19, #0x30]                           ._configBaseKeycap
02d71a94: cmp     w22, w8                                    
02d71a98: b.ge    #0x2d71c28                                 
02d71a9c: cbz     x0, #0x2d71c84                             
02d71aa0: mov     w1, w22                                    
02d71aa4: mov     x2, xzr                                    
02d71aa8: bl      #0x2d5b300                                 Clicker.BaseKeycapConfig::GetData
02d71aac: mov     x23, x0                                    
02d71ab0: ldr     x0, [x19, #0x28]                           ._listItem
02d71ab4: cbz     x23, #0x2d71b24                            
02d71ab8: cbz     x0, #0x2d71c84                             
02d71abc: ldr     x2, [x27]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d71ac0: mov     w1, w22                                    
02d71ac4: bl      #0x35a8f3c                                 fn_35a8f3c
02d71ac8: cbz     x0, #0x2d71c84                             
02d71acc: ldr     x8, [x0]                                   M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d71ad0: ldr     x2, [x23, #0x18]                           
02d71ad4: ldr     w1, [x23, #0x10]                           
02d71ad8: ldp     x9, x3, [x8, #0x178]                       
02d71adc: blr     x9                                         
02d71ae0: ldr     x0, [x19, #0x28]                           ._listItem
02d71ae4: cbz     x0, #0x2d71c84                             
02d71ae8: ldr     x2, [x27]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d71aec: mov     w1, w22                                    
02d71af0: bl      #0x35a8f3c                                 fn_35a8f3c
02d71af4: ldr     x8, [x23, #0x48]                           
02d71af8: cbz     x8, #0x2d71c84                             
02d71afc: mov     x24, x0                                    
02d71b00: ldr     x0, [x21]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d71b04: cbz     x0, #0x2d71c84                             
02d71b08: ldp     w25, w26, [x8, #0x10]                      
02d71b0c: ldr     w1, [x23, #0x10]                           
02d71b10: mov     x2, xzr                                    
02d71b14: bl      #0x2cabfd4                                 DataUser::HasUnlockedClickerBase
02d71b18: tbz     w0, #0, #0x2d71b54                         
02d71b1c: mov     w3, #1                                     
02d71b20: b       #0x2d71b68                                 
02d71b24: cbz     x0, #0x2d71c84                             
02d71b28: ldr     x2, [x27]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d71b2c: mov     w1, w22                                    
02d71b30: bl      #0x35a8f3c                                 fn_35a8f3c
02d71b34: cbz     x0, #0x2d71c84                             
02d71b38: mov     x1, xzr                                    
02d71b3c: bl      #0x5b339ec                                 UnityEngine.Component::get_gameObject
02d71b40: cbz     x0, #0x2d71c84                             
02d71b44: mov     w1, wzr                                    
02d71b48: mov     x2, xzr                                    
02d71b4c: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d71b50: b       #0x2d71c18                                 
02d71b54: ldr     x8, [x23, #0x48]                           
02d71b58: cbz     x8, #0x2d71c84                             
02d71b5c: ldr     w8, [x8, #0x10]                            S:'mrec_ad_on_off'
02d71b60: cmp     w8, #0                                     
02d71b64: cset    w3, eq                                     
02d71b68: cbz     x24, #0x2d71c84                            
02d71b6c: ldr     x8, [x24]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d71b70: mov     x0, x24                                    
02d71b74: mov     w1, w25                                    
02d71b78: mov     w2, w26                                    
02d71b7c: ldp     x9, x4, [x8, #0x1a8]                       
02d71b80: blr     x9                                         
02d71b84: ldr     x0, [x19, #0x28]                           ._listItem
02d71b88: cbz     x0, #0x2d71c84                             
02d71b8c: ldr     x2, [x27]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d71b90: mov     w1, w22                                    
02d71b94: bl      #0x35a8f3c                                 fn_35a8f3c
02d71b98: cbz     x0, #0x2d71c84                             
02d71b9c: mov     x1, xzr                                    
02d71ba0: bl      #0x5b339ec                                 UnityEngine.Component::get_gameObject
02d71ba4: cbz     x0, #0x2d71c84                             
02d71ba8: mov     w1, #1                                     
02d71bac: mov     x2, xzr                                    
02d71bb0: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d71bb4: ldr     x0, [x19, #0x28]                           ._listItem
02d71bb8: cbz     x0, #0x2d71c84                             
02d71bbc: ldr     x2, [x27]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d71bc0: mov     w1, w22                                    
02d71bc4: bl      #0x35a8f3c                                 fn_35a8f3c
02d71bc8: ldur    x24, [x20, #0x20]                          ._baseKeycapUIItem
02d71bcc: mov     x23, x0                                    
02d71bd0: cbnz    x24, #0x2d71c00                            
02d71bd4: ldr     x0, [x28]                                  T:Trading.TradingSession/<>c__DisplayClass56_0
02d71bd8: bl      #0x2b7104c                                 fn_2b7104c
02d71bdc: ldr     x2, [x29]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d71be0: mov     x1, x20                                    
02d71be4: mov     x3, xzr                                    
02d71be8: mov     x24, x0                                    
02d71bec: bl      #0x4532eb0                                 fn_4532eb0
02d71bf0: add     x0, x20, #0x20                             &6630020
02d71bf4: mov     x1, x24                                    
02d71bf8: str     x24, [x20, #0x20]                          ._baseKeycapUIItem
02d71bfc: bl      #0x2b70d54                                 fn_2b70d54
02d71c00: cbz     x23, #0x2d71c84                            
02d71c04: ldr     x8, [x23]                                  
02d71c08: mov     x0, x23                                    
02d71c0c: mov     x1, x24                                    
02d71c10: ldp     x9, x2, [x8, #0x198]                       
02d71c14: blr     x9                                         
02d71c18: ldr     x0, [x19, #0x30]                           ._configBaseKeycap
02d71c1c: add     w22, w22, #1                               
02d71c20: cbnz    x0, #0x2d71a84                             
02d71c24: b       #0x2d71c84                                 
02d71c28: cbz     x0, #0x2d71c84                             
02d71c2c: mov     x1, xzr                                    
02d71c30: bl      #0x2d5b248                                 Clicker.BaseKeycapConfig::get_Count
02d71c34: ldr     x8, [x19, #0x28]                           ._listItem
02d71c38: cbz     x8, #0x2d71c84                             
02d71c3c: mov     w20, w0                                    
02d71c40: ldr     w9, [x8, #0x18]                            S:'level_show_popuprate'
02d71c44: cmp     w20, w9                                    
02d71c48: b.ge    #0x2d71c88                                 
02d71c4c: ldr     x2, [x27]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d71c50: mov     x0, x8                                     
02d71c54: mov     w1, w20                                    
02d71c58: bl      #0x35a8f3c                                 fn_35a8f3c
02d71c5c: cbz     x0, #0x2d71c84                             
02d71c60: mov     x1, xzr                                    
02d71c64: bl      #0x5b339ec                                 UnityEngine.Component::get_gameObject
02d71c68: cbz     x0, #0x2d71c84                             
02d71c6c: mov     w1, wzr                                    
02d71c70: mov     x2, xzr                                    
02d71c74: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d71c78: ldr     x8, [x19, #0x28]                           ._listItem
02d71c7c: add     w20, w20, #1                               
02d71c80: cbnz    x8, #0x2d71c40                             
02d71c84: bl      #0x2b7105c                                 fn_2b7105c
02d71c88: ldp     x20, x19, [sp, #0x50]                      
02d71c8c: ldp     x22, x21, [sp, #0x40]                      
02d71c90: ldp     x24, x23, [sp, #0x30]                      
02d71c94: ldp     x26, x25, [sp, #0x20]                      
02d71c98: ldp     x28, x27, [sp, #0x10]                      
02d71c9c: ldp     x29, x30, [sp], #0x60                      
02d71ca0: ret                                                
## OnItemSelect(int id) -> void
---- Clicker.SelectBaseKeycapPanel::OnItemSelect 0x2d71f3c
02d71f3c: str     x30, [sp, #-0x30]!                         
02d71f40: stp     x22, x21, [sp, #0x10]                      
02d71f44: stp     x20, x19, [sp, #0x20]                      
02d71f48: adrp    x21, #0x6630000                            
02d71f4c: adrp    x22, #0x626c000                            
02d71f50: mov     w19, w1                                    
02d71f54: ldrb    w8, [x21, #0x3b2]                          
02d71f58: ldr     x22, [x22, #0x610]                         T:Clicker.SelectBaseKeycapPanel/<>c__DisplayClass14_0
02d71f5c: mov     x20, x0                                    
02d71f60: tbnz    w8, #0, #0x2d71f9c                         
02d71f64: adrp    x0, #0x626c000                             
02d71f68: ldr     x0, [x0, #0x618]                           T:type53117(k15)
02d71f6c: bl      #0x2b70db0                                 fn_2b70db0
02d71f70: adrp    x0, #0x626c000                             
02d71f74: ldr     x0, [x0, #0x620]                           MS:System.Collections.Generic.List`1::ForEach
02d71f78: bl      #0x2b70db0                                 fn_2b70db0
02d71f7c: adrp    x0, #0x626c000                             
02d71f80: ldr     x0, [x0, #0x628]                           M:Clicker.SelectBaseKeycapPanel/<>c__DisplayClass14_0::<OnItemSelect>b__0
02d71f84: bl      #0x2b70db0                                 fn_2b70db0
02d71f88: adrp    x0, #0x626c000                             
02d71f8c: ldr     x0, [x0, #0x610]                           T:Clicker.SelectBaseKeycapPanel/<>c__DisplayClass14_0
02d71f90: bl      #0x2b70db0                                 fn_2b70db0
02d71f94: mov     w8, #1                                     
02d71f98: strb    w8, [x21, #0x3b2]                          
02d71f9c: ldr     x0, [x22]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d71fa0: bl      #0x2b7104c                                 fn_2b7104c
02d71fa4: mov     x1, xzr                                    
02d71fa8: mov     x21, x0                                    
02d71fac: bl      #0x4e53e9c                                 System.Object::.ctor
02d71fb0: cbz     x21, #0x2d72010                            
02d71fb4: adrp    x8, #0x626c000                             
02d71fb8: adrp    x22, #0x626c000                            
02d71fbc: ldr     x8, [x8, #0x618]                           T:type53117(k15)
02d71fc0: ldr     x22, [x22, #0x628]                         M:Clicker.SelectBaseKeycapPanel/<>c__DisplayClass14_0::<OnItemSelect>b__0
02d71fc4: ldr     x20, [x20, #0x28]                          ._listItem
02d71fc8: str     w19, [x21, #0x10]                          
02d71fcc: ldr     x0, [x8]                                   M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d71fd0: bl      #0x2b7104c                                 fn_2b7104c
02d71fd4: ldr     x2, [x22]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d71fd8: mov     x1, x21                                    
02d71fdc: mov     x3, xzr                                    
02d71fe0: mov     x19, x0                                    
02d71fe4: bl      #0x453418c                                 fn_453418c
02d71fe8: cbz     x20, #0x2d72010                            
02d71fec: adrp    x8, #0x626c000                             
02d71ff0: mov     x0, x20                                    
02d71ff4: mov     x1, x19                                    
02d71ff8: ldr     x8, [x8, #0x620]                           MS:System.Collections.Generic.List`1::ForEach
02d71ffc: ldp     x20, x19, [sp, #0x20]                      
02d72000: ldp     x22, x21, [sp, #0x10]                      
02d72004: ldr     x2, [x8]                                   M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d72008: ldr     x30, [sp], #0x30                           
02d7200c: b       #0x35a9ce4                                 
02d72010: bl      #0x2b7105c                                 fn_2b7105c
## .ctor() -> void
---- Clicker.SelectBaseKeycapPanel::.ctor 0x2d7201c
02d7201c: mov     x1, xzr                                    
02d72020: b       #0x5b397b0                                 UnityEngine.MonoBehaviour::.ctor
## <ShowPanel>b__11_0() -> void
---- Clicker.SelectBaseKeycapPanel::<ShowPanel>b__11_0 0x2d72024
02d72024: str     x30, [sp, #-0x20]!                         
02d72028: stp     x20, x19, [sp, #0x10]                      
02d7202c: adrp    x20, #0x6630000                            
02d72030: mov     x19, x0                                    
02d72034: ldrb    w8, [x20, #0x3b3]                          
02d72038: tbnz    w8, #0, #0x2d72050                         
02d7203c: adrp    x0, #0x626c000                             
02d72040: ldr     x0, [x0, #0x5e0]                           MS:System.Collections.Generic.List`1::get_Item
02d72044: bl      #0x2b70db0                                 fn_2b70db0
02d72048: mov     w8, #1                                     
02d7204c: strb    w8, [x20, #0x3b3]                          
02d72050: ldrb    w8, [x19, #0x60]                           ._tutorialShown
02d72054: cbz     w8, #0x2d72064                             
02d72058: ldp     x20, x19, [sp, #0x10]                      
02d7205c: ldr     x30, [sp], #0x20                           
02d72060: ret                                                
02d72064: ldr     x0, [x19, #0x28]                           ._listItem
02d72068: cbz     x0, #0x2d720ac                             
02d7206c: adrp    x8, #0x626c000                             
02d72070: mov     w1, wzr                                    
02d72074: ldr     x8, [x8, #0x5e0]                           MS:System.Collections.Generic.List`1::get_Item
02d72078: ldr     x19, [x19, #0x58]                          ._ingameClickerScreen
02d7207c: ldr     x2, [x8]                                   M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d72080: bl      #0x35a8f3c                                 fn_35a8f3c
02d72084: cbz     x0, #0x2d720ac                             
02d72088: mov     x1, xzr                                    
02d7208c: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02d72090: cbz     x19, #0x2d720ac                            
02d72094: mov     x1, x0                                     
02d72098: mov     x0, x19                                    
02d7209c: mov     x2, xzr                                    
02d720a0: ldp     x20, x19, [sp, #0x10]                      
02d720a4: ldr     x30, [sp], #0x20                           
02d720a8: b       #0x2d6a2c0                                 Clicker.IngameClickerScreen::ShowTutorialAt
02d720ac: bl      #0x2b7105c                                 fn_2b7105c
## <ShowPanel>b__11_1() -> void
---- Clicker.SelectBaseKeycapPanel::<ShowPanel>b__11_1 0x2d720b0
02d720b0: str     x30, [sp, #-0x20]!                         
02d720b4: stp     x20, x19, [sp, #0x10]                      
02d720b8: adrp    x20, #0x6630000                            
02d720bc: mov     x19, x0                                    
02d720c0: ldrb    w8, [x20, #0x3b4]                          
02d720c4: tbnz    w8, #0, #0x2d72100                         
02d720c8: adrp    x0, #0x6266000                             
02d720cc: ldr     x0, [x0, #0x750]                           MS:DataManager::GetData
02d720d0: bl      #0x2b70db0                                 fn_2b70db0
02d720d4: adrp    x0, #0x6265000                             
02d720d8: ldr     x0, [x0, #0xb38]                           T:DevTrack
02d720dc: bl      #0x2b70db0                                 fn_2b70db0
02d720e0: adrp    x0, #0x626b000                             
02d720e4: ldr     x0, [x0, #0xee0]                           MS:MonoSingleton`1::get_Instance
02d720e8: bl      #0x2b70db0                                 fn_2b70db0
02d720ec: adrp    x0, #0x6266000                             
02d720f0: ldr     x0, [x0, #0x658]                           MS:MonoSingleton`1::get_Instance
02d720f4: bl      #0x2b70db0                                 fn_2b70db0
02d720f8: mov     w8, #1                                     
02d720fc: strb    w8, [x20, #0x3b4]                          
02d72100: mov     x0, x19                                    
02d72104: bl      #0x2d71e40                                 Clicker.SelectBaseKeycapPanel::HidePanel
02d72108: ldr     x0, [x19, #0x58]                           ._ingameClickerScreen
02d7210c: cbz     x0, #0x2d721dc                             
02d72110: adrp    x20, #0x626b000                            
02d72114: mov     w1, wzr                                    
02d72118: mov     x2, xzr                                    
02d7211c: ldr     x20, [x20, #0xee0]                         MS:MonoSingleton`1::get_Instance
02d72120: bl      #0x2d6519c                                 Clicker.IngameClickerScreen::ShowBtnNext
02d72124: ldr     x0, [x20]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d72128: bl      #0x3769600                                 fn_3769600
02d7212c: cbz     x0, #0x2d721dc                             
02d72130: mov     x1, xzr                                    
02d72134: bl      #0x2d6c6cc                                 Clicker.KeycapMakerController::HidePreviewShowPrinter
02d72138: ldr     x0, [x20]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d7213c: bl      #0x3769600                                 fn_3769600
02d72140: cbz     x0, #0x2d721dc                             
02d72144: mov     x1, xzr                                    
02d72148: bl      #0x2d6cfe0                                 Clicker.KeycapMakerController::SpawnAssembleKeycap
02d7214c: ldr     x0, [x19, #0x58]                           ._ingameClickerScreen
02d72150: cbz     x0, #0x2d721dc                             
02d72154: adrp    x19, #0x6266000                            
02d72158: mov     x1, xzr                                    
02d7215c: ldr     x19, [x19, #0x658]                         MS:MonoSingleton`1::get_Instance
02d72160: bl      #0x2d6b6c0                                 Clicker.IngameClickerScreen::GoToStepPrinter
02d72164: ldr     x0, [x19]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d72168: bl      #0x3769600                                 fn_3769600
02d7216c: cbz     x0, #0x2d721dc                             
02d72170: adrp    x8, #0x6266000                             
02d72174: ldr     x8, [x8, #0x750]                           MS:DataManager::GetData
02d72178: ldr     x1, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d7217c: bl      #0x3168dd0                                 fn_3168dd0
02d72180: cbz     x0, #0x2d721dc                             
02d72184: ldr     x8, [x0, #0x20]                            S:'inter_ad_capping_time' ._baseKeycapUIItem
02d72188: cbz     x8, #0x2d721dc                             
02d7218c: ldrb    w8, [x8, #0x3a]                            
02d72190: cbz     w8, #0x2d721d0                             
02d72194: adrp    x19, #0x6265000                            
02d72198: ldr     x19, [x19, #0xb38]                         T:DevTrack
02d7219c: ldr     x0, [x19]                                  M:AdsManager::<OnApplicationPause>b__26_0
02d721a0: ldr     w8, [x0, #0xe4]                            [62660e4]=0 f=0,0
02d721a4: cbnz    w8, #0x2d721b0                             
02d721a8: bl      #0x2b70f30                                 fn_2b70f30
02d721ac: ldr     x0, [x19]                                  M:AdsManager::<OnApplicationPause>b__26_0
02d721b0: ldr     x8, [x0, #0xb8]                            S:'banner_native_refresh_time'
02d721b4: ldp     x20, x19, [sp, #0x10]                      
02d721b8: mov     x3, xzr                                    
02d721bc: ldr     x0, [x8, #0x1f8]                           MS:System.Collections.Generic.List`1/Enumerator::get_Current
02d721c0: ldr     x1, [x8, #0x220]                           MS:System.Collections.Generic.List`1::get_Count
02d721c4: ldr     w2, [x8, #0x274]                           [6266274]=0 f=0,0
02d721c8: ldr     x30, [sp], #0x20                           
02d721cc: b       #0x2c9c1e0                                 DevTrack::OnboardingStep
02d721d0: ldp     x20, x19, [sp, #0x10]                      
02d721d4: ldr     x30, [sp], #0x20                           
02d721d8: ret                                                
02d721dc: bl      #0x2b7105c                                 fn_2b7105c
## <HidePanel>b__12_0() -> void
---- Clicker.SelectBaseKeycapPanel::<HidePanel>b__12_0 0x2d721e0
02d721e0: str     x30, [sp, #-0x10]!                         
02d721e4: ldr     x0, [x0, #0x48]                            ._thisPanelRect
02d721e8: cbz     x0, #0x2d72208                             
02d721ec: mov     x1, xzr                                    
02d721f0: bl      #0x5b339ec                                 UnityEngine.Component::get_gameObject
02d721f4: cbz     x0, #0x2d72208                             
02d721f8: mov     w1, wzr                                    
02d721fc: mov     x2, xzr                                    
02d72200: ldr     x30, [sp], #0x10                           
02d72204: b       #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d72208: bl      #0x2b7105c                                 fn_2b7105c
