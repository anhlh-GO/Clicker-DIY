#### CLASS FlashManager parent= MonoSingleton`1<FlashManager>
## .ctor() -> void
---- FlashManager::.ctor 0x2cd66e0
02cd66e0: stp     x30, x21, [sp, #-0x20]!                    
02cd66e4: stp     x20, x19, [sp, #0x10]                      
02cd66e8: adrp    x20, #0x662f000                            
02cd66ec: adrp    x21, #0x6267000                            
02cd66f0: mov     x19, x0                                    
02cd66f4: ldrb    w8, [x20, #0xd2b]                          
02cd66f8: ldr     x21, [x21, #0x938]                         MS:MonoSingleton`1::.ctor
02cd66fc: tbnz    w8, #0, #0x2cd6714                         
02cd6700: adrp    x0, #0x6267000                             
02cd6704: ldr     x0, [x0, #0x938]                           MS:MonoSingleton`1::.ctor
02cd6708: bl      #0x2b70db0                                 fn_2b70db0
02cd670c: mov     w8, #1                                     
02cd6710: strb    w8, [x20, #0xd2b]                          
02cd6714: mov     x0, x19                                    
02cd6718: ldp     x20, x19, [sp, #0x10]                      
02cd671c: ldr     x1, [x21]                                  S:'didu'
02cd6720: ldp     x30, x21, [sp], #0x20                      
02cd6724: b       #0x3769e18                                 
