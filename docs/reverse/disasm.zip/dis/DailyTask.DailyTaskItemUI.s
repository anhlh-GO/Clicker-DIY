#### CLASS DailyTask.DailyTaskItemUI parent= UnityEngine.MonoBehaviour
#   field _icon                          UnityEngine.UI.Image                               off=0x20 attr=1 SerializeField
#   field _progressImage                 UnityEngine.UI.Image                               off=0x28 attr=1 SerializeField
#   field _progressText                  TMPro.TextMeshProUGUI                              off=0x30 attr=1 SerializeField
#   field _descriptionText               TMPro.TextMeshProUGUI                              off=0x38 attr=1 SerializeField
#   field _rewardText                    TMPro.TextMeshProUGUI                              off=0x40 attr=1 SerializeField
#   field _localizeDescriptionText       LocalizeText                                       off=0x48 attr=1 SerializeField
#   field _goButton                      UnityEngine.UI.Button                              off=0x50 attr=1 SerializeField
#   field _skipButton                    UnityEngine.UI.Button                              off=0x58 attr=1 SerializeField
#   field _claimButton                   UnityEngine.UI.Button                              off=0x60 attr=1 SerializeField
#   field _doneIcon                      UnityEngine.GameObject                             off=0x68 attr=1 SerializeField
#   field _doneBG                        UnityEngine.GameObject                             off=0x70 attr=1 SerializeField
#   field _rewardPos                     UnityEngine.Transform                              off=0x78 attr=1 SerializeField
#   field _mission                       DailyTask.Mission                                  off=0x80 attr=1 
#   field _dailyTaskController           DailyTask.DailyTaskController                      off=0x88 attr=1 
#   field _popupDailyTask                DailyTask.PopupDailyTask                           off=0x90 attr=1 
#   field _jellyHome                     ScreenHome                                         off=0x98 attr=1 
## get_TaskId() -> int
---- DailyTask.DailyTaskItemUI::get_TaskId 0x2d2c540
02d2c540: ldr     x8, [x0, #0x80]                            ._mission
02d2c544: cbz     x8, #0x2d2c550                             
02d2c548: ldr     w0, [x8, #0x10]                            
02d2c54c: ret                                                
02d2c550: str     x30, [sp, #-0x10]!                         
02d2c554: bl      #0x2b7105c                                 fn_2b7105c
## get_RewardPos() -> UnityEngine.Transform
---- DailyTask.DailyTaskItemUI::get_RewardPos 0x2d2c558
02d2c558: ldr     x0, [x0, #0x78]                            ._rewardPos
02d2c55c: ret                                                
## OnDestroy() -> void
---- DailyTask.DailyTaskItemUI::OnDestroy 0x2d2c560
02d2c560: str     x30, [sp, #-0x30]!                         
02d2c564: stp     x22, x21, [sp, #0x10]                      
02d2c568: stp     x20, x19, [sp, #0x20]                      
02d2c56c: adrp    x20, #0x6630000                            
02d2c570: mov     x19, x0                                    
02d2c574: ldrb    w8, [x20, #0xcd]                           
02d2c578: tbnz    w8, #0, #0x2d2c5b4                         
02d2c57c: adrp    x0, #0x626a000                             
02d2c580: ldr     x0, [x0, #0x488]                           M:DailyTask.DailyTaskItemUI::OnClaimButtonClicked
02d2c584: bl      #0x2b70db0                                 fn_2b70db0
02d2c588: adrp    x0, #0x626a000                             
02d2c58c: ldr     x0, [x0, #0x490]                           M:DailyTask.DailyTaskItemUI::OnGoButtonClicked
02d2c590: bl      #0x2b70db0                                 fn_2b70db0
02d2c594: adrp    x0, #0x626a000                             
02d2c598: ldr     x0, [x0, #0x498]                           M:DailyTask.DailyTaskItemUI::OnSkipButtonClicked
02d2c59c: bl      #0x2b70db0                                 fn_2b70db0
02d2c5a0: adrp    x0, #0x6265000                             
02d2c5a4: ldr     x0, [x0, #0x3f0]                           T:UnityEngine.Events.UnityAction
02d2c5a8: bl      #0x2b70db0                                 fn_2b70db0
02d2c5ac: mov     w8, #1                                     
02d2c5b0: strb    w8, [x20, #0xcd]                           
02d2c5b4: ldr     x8, [x19, #0x50]                           ._goButton
02d2c5b8: cbz     x8, #0x2d2c694                             
02d2c5bc: adrp    x22, #0x6265000                            
02d2c5c0: adrp    x21, #0x626a000                            
02d2c5c4: ldr     x22, [x22, #0x3f0]                         T:UnityEngine.Events.UnityAction
02d2c5c8: ldr     x21, [x21, #0x490]                         M:DailyTask.DailyTaskItemUI::OnGoButtonClicked
02d2c5cc: ldr     x20, [x8, #0x100]                          
02d2c5d0: ldr     x0, [x22]                                  M:AdsManager::<OnApplicationPause>b__26_0
02d2c5d4: bl      #0x2b7104c                                 fn_2b7104c
02d2c5d8: ldr     x2, [x21]                                  T:type56879(k15)
02d2c5dc: mov     x1, x19                                    
02d2c5e0: mov     x3, xzr                                    
02d2c5e4: mov     x21, x0                                    
02d2c5e8: bl      #0x5b4cf98                                 UnityEngine.Events.UnityAction::.ctor
02d2c5ec: cbz     x20, #0x2d2c694                            
02d2c5f0: mov     x0, x20                                    
02d2c5f4: mov     x1, x21                                    
02d2c5f8: mov     x2, xzr                                    
02d2c5fc: bl      #0x5b4d13c                                 UnityEngine.Events.UnityEvent::RemoveListener
02d2c600: ldr     x8, [x19, #0x58]                           ._skipButton
02d2c604: cbz     x8, #0x2d2c694                             
02d2c608: adrp    x21, #0x626a000                            
02d2c60c: ldr     x21, [x21, #0x498]                         M:DailyTask.DailyTaskItemUI::OnSkipButtonClicked
02d2c610: ldr     x0, [x22]                                  M:AdsManager::<OnApplicationPause>b__26_0
02d2c614: ldr     x20, [x8, #0x100]                          
02d2c618: bl      #0x2b7104c                                 fn_2b7104c
02d2c61c: ldr     x2, [x21]                                  T:type56879(k15)
02d2c620: mov     x1, x19                                    
02d2c624: mov     x3, xzr                                    
02d2c628: mov     x21, x0                                    
02d2c62c: bl      #0x5b4cf98                                 UnityEngine.Events.UnityAction::.ctor
02d2c630: cbz     x20, #0x2d2c694                            
02d2c634: mov     x0, x20                                    
02d2c638: mov     x1, x21                                    
02d2c63c: mov     x2, xzr                                    
02d2c640: bl      #0x5b4d13c                                 UnityEngine.Events.UnityEvent::RemoveListener
02d2c644: ldr     x8, [x19, #0x60]                           ._claimButton
02d2c648: cbz     x8, #0x2d2c694                             
02d2c64c: adrp    x21, #0x626a000                            
02d2c650: ldr     x21, [x21, #0x488]                         M:DailyTask.DailyTaskItemUI::OnClaimButtonClicked
02d2c654: ldr     x0, [x22]                                  M:AdsManager::<OnApplicationPause>b__26_0
02d2c658: ldr     x20, [x8, #0x100]                          
02d2c65c: bl      #0x2b7104c                                 fn_2b7104c
02d2c660: ldr     x2, [x21]                                  T:type56879(k15)
02d2c664: mov     x1, x19                                    
02d2c668: mov     x3, xzr                                    
02d2c66c: mov     x21, x0                                    
02d2c670: bl      #0x5b4cf98                                 UnityEngine.Events.UnityAction::.ctor
02d2c674: cbz     x20, #0x2d2c694                            
02d2c678: mov     x0, x20                                    
02d2c67c: mov     x1, x21                                    
02d2c680: mov     x2, xzr                                    
02d2c684: ldp     x20, x19, [sp, #0x20]                      
02d2c688: ldp     x22, x21, [sp, #0x10]                      
02d2c68c: ldr     x30, [sp], #0x30                           
02d2c690: b       #0x5b4d13c                                 UnityEngine.Events.UnityEvent::RemoveListener
02d2c694: bl      #0x2b7105c                                 fn_2b7105c
## OnInit(DailyTask.Mission mission, DailyTask.PopupDailyTask popupDailyTask) -> DailyTask.DailyTaskItemUI
---- DailyTask.DailyTaskItemUI::OnInit 0x2d2c698
02d2c698: str     x30, [sp, #-0x40]!                         
02d2c69c: stp     x24, x23, [sp, #0x10]                      
02d2c6a0: stp     x22, x21, [sp, #0x20]                      
02d2c6a4: stp     x20, x19, [sp, #0x30]                      
02d2c6a8: adrp    x23, #0x6630000                            
02d2c6ac: adrp    x24, #0x6267000                            
02d2c6b0: adrp    x22, #0x6267000                            
02d2c6b4: ldrb    w8, [x23, #0xce]                           
02d2c6b8: ldr     x24, [x24, #0xbb0]                         MS:MonoSingleton`1::get_Instance
02d2c6bc: ldr     x22, [x22, #0xbd0]                         MS:MonoSingleton`1::get_Instance
02d2c6c0: mov     x21, x2                                    
02d2c6c4: mov     x20, x1                                    
02d2c6c8: mov     x19, x0                                    
02d2c6cc: tbnz    w8, #0, #0x2d2c738                         
02d2c6d0: adrp    x0, #0x626a000                             
02d2c6d4: ldr     x0, [x0, #0x488]                           M:DailyTask.DailyTaskItemUI::OnClaimButtonClicked
02d2c6d8: bl      #0x2b70db0                                 fn_2b70db0
02d2c6dc: adrp    x0, #0x626a000                             
02d2c6e0: ldr     x0, [x0, #0x490]                           M:DailyTask.DailyTaskItemUI::OnGoButtonClicked
02d2c6e4: bl      #0x2b70db0                                 fn_2b70db0
02d2c6e8: adrp    x0, #0x626a000                             
02d2c6ec: ldr     x0, [x0, #0x498]                           M:DailyTask.DailyTaskItemUI::OnSkipButtonClicked
02d2c6f0: bl      #0x2b70db0                                 fn_2b70db0
02d2c6f4: adrp    x0, #0x6267000                             
02d2c6f8: ldr     x0, [x0, #0xbd0]                           MS:MonoSingleton`1::get_Instance
02d2c6fc: bl      #0x2b70db0                                 fn_2b70db0
02d2c700: adrp    x0, #0x6267000                             
02d2c704: ldr     x0, [x0, #0xbb0]                           MS:MonoSingleton`1::get_Instance
02d2c708: bl      #0x2b70db0                                 fn_2b70db0
02d2c70c: adrp    x0, #0x6267000                             
02d2c710: ldr     x0, [x0, #0xd58]                           MS:UIManager::GetScreen
02d2c714: bl      #0x2b70db0                                 fn_2b70db0
02d2c718: adrp    x0, #0x6265000                             
02d2c71c: ldr     x0, [x0, #0x3f0]                           T:UnityEngine.Events.UnityAction
02d2c720: bl      #0x2b70db0                                 fn_2b70db0
02d2c724: adrp    x0, #0x626a000                             
02d2c728: ldr     x0, [x0, #0x4a0]                           S:'x{0}'
02d2c72c: bl      #0x2b70db0                                 fn_2b70db0
02d2c730: mov     w8, #1                                     
02d2c734: strb    w8, [x23, #0xce]                           
02d2c738: ldr     x0, [x24]                                  S:'didu'
02d2c73c: bl      #0x3769600                                 fn_3769600
02d2c740: mov     x1, x0                                     
02d2c744: mov     x0, x19                                    
02d2c748: str     x1, [x0, #0x88]!                           ._dailyTaskController
02d2c74c: bl      #0x2b70d54                                 fn_2b70d54
02d2c750: mov     x0, x19                                    
02d2c754: mov     x1, x20                                    
02d2c758: str     x20, [x0, #0x80]!                          ._mission
02d2c75c: bl      #0x2b70d54                                 fn_2b70d54
02d2c760: mov     x0, x19                                    
02d2c764: mov     x1, x21                                    
02d2c768: str     x21, [x0, #0x90]!                          ._popupDailyTask
02d2c76c: bl      #0x2b70d54                                 fn_2b70d54
02d2c770: ldr     x0, [x22]                                  S:'didu'
02d2c774: bl      #0x3769600                                 fn_3769600
02d2c778: cbz     x0, #0x2d2c958                             
02d2c77c: adrp    x8, #0x6267000                             
02d2c780: ldr     x8, [x8, #0xd58]                           MS:UIManager::GetScreen
02d2c784: ldr     x1, [x8]                                   S:'didu'
02d2c788: bl      #0x33fbbd0                                 fn_33fbbd0
02d2c78c: mov     x21, x19                                   
02d2c790: mov     x1, x0                                     
02d2c794: str     x0, [x21, #0x98]!                          ._jellyHome
02d2c798: mov     x0, x21                                    
02d2c79c: bl      #0x2b70d54                                 fn_2b70d54
02d2c7a0: cbz     x20, #0x2d2c958                            
02d2c7a4: ldur    x0, [x21, #-0x78]                          
02d2c7a8: cbz     x0, #0x2d2c958                             
02d2c7ac: ldr     x1, [x20, #0x28]                           ._progressImage
02d2c7b0: mov     x2, xzr                                    
02d2c7b4: bl      #0x5c45aa0                                 UnityEngine.UI.Image::set_sprite
02d2c7b8: ldr     x0, [x19, #0x38]                           ._descriptionText
02d2c7bc: cbz     x0, #0x2d2c958                             
02d2c7c0: ldr     x1, [x20, #0x18]                           
02d2c7c4: mov     x2, xzr                                    
02d2c7c8: bl      #0x5a7b18c                                 TMPro.TMP_Text::SetText
02d2c7cc: ldr     x0, [x19, #0x38]                           ._descriptionText
02d2c7d0: cbz     x0, #0x2d2c958                             
02d2c7d4: ldr     x8, [x0]                                   T:type56879(k15)
02d2c7d8: ldr     x20, [x19, #0x48]                          ._localizeDescriptionText
02d2c7dc: ldr     x9, [x8, #0x548]                           S:'content'
02d2c7e0: ldr     x1, [x8, #0x550]                           S:'setMargins'
02d2c7e4: blr     x9                                         
02d2c7e8: cbz     x20, #0x2d2c958                            
02d2c7ec: mov     x1, x0                                     
02d2c7f0: mov     x0, x20                                    
02d2c7f4: mov     x2, xzr                                    
02d2c7f8: bl      #0x2cd9bd4                                 LocalizeText::ForceUpdateText
02d2c7fc: ldr     x8, [x19, #0x80]                           ._mission
02d2c800: cbz     x8, #0x2d2c958                             
02d2c804: ldr     x0, [x19, #0x88]                           ._dailyTaskController
02d2c808: cbz     x0, #0x2d2c958                             
02d2c80c: adrp    x21, #0x626a000                            
02d2c810: ldr     x21, [x21, #0x4a0]                         S:'x{0}'
02d2c814: ldr     w1, [x8, #0x10]                            S:'startActivity'
02d2c818: ldr     x20, [x19, #0x40]                          ._rewardText
02d2c81c: bl      #0x2d2b920                                 DailyTask.DailyTaskController::GetRewardForTask
02d2c820: adrp    x8, #0x6263000                             
02d2c824: add     x1, sp, #0xc                               
02d2c828: ldr     x8, [x8, #0x970]                           &6645c70(=0)
02d2c82c: str     w0, [sp, #0xc]                             
02d2c830: ldr     x8, [x8, #0x48]                            &6263098(=0)
02d2c834: mov     x0, x8                                     
02d2c838: bl      #0x2b70f38                                 fn_2b70f38
02d2c83c: ldr     x8, [x21]                                  T:type56879(k15)
02d2c840: mov     x1, x0                                     
02d2c844: mov     x2, xzr                                    
02d2c848: mov     x0, x8                                     
02d2c84c: bl      #0x4c9d0ec                                 System.String::Format
02d2c850: cbz     x20, #0x2d2c958                            
02d2c854: mov     x1, x0                                     
02d2c858: mov     x0, x20                                    
02d2c85c: mov     x2, xzr                                    
02d2c860: bl      #0x5a7b18c                                 TMPro.TMP_Text::SetText
02d2c864: ldr     x8, [x19, #0x50]                           ._goButton
02d2c868: cbz     x8, #0x2d2c958                             
02d2c86c: adrp    x22, #0x6265000                            
02d2c870: adrp    x21, #0x626a000                            
02d2c874: ldr     x22, [x22, #0x3f0]                         T:UnityEngine.Events.UnityAction
02d2c878: ldr     x21, [x21, #0x490]                         M:DailyTask.DailyTaskItemUI::OnGoButtonClicked
02d2c87c: ldr     x20, [x8, #0x100]                          &2c5c0d8(=14c8d199d503245f)
02d2c880: ldr     x0, [x22]                                  M:AdsManager::<OnApplicationPause>b__26_0
02d2c884: bl      #0x2b7104c                                 fn_2b7104c
02d2c888: ldr     x2, [x21]                                  T:type56879(k15)
02d2c88c: mov     x1, x19                                    
02d2c890: mov     x3, xzr                                    
02d2c894: mov     x21, x0                                    
02d2c898: bl      #0x5b4cf98                                 UnityEngine.Events.UnityAction::.ctor
02d2c89c: cbz     x20, #0x2d2c958                            
02d2c8a0: mov     x0, x20                                    
02d2c8a4: mov     x1, x21                                    
02d2c8a8: mov     x2, xzr                                    
02d2c8ac: bl      #0x5b4d0ac                                 UnityEngine.Events.UnityEvent::AddListener
02d2c8b0: ldr     x8, [x19, #0x58]                           ._skipButton
02d2c8b4: cbz     x8, #0x2d2c958                             
02d2c8b8: adrp    x21, #0x626a000                            
02d2c8bc: ldr     x21, [x21, #0x498]                         M:DailyTask.DailyTaskItemUI::OnSkipButtonClicked
02d2c8c0: ldr     x0, [x22]                                  M:AdsManager::<OnApplicationPause>b__26_0
02d2c8c4: ldr     x20, [x8, #0x100]                          &2c5c0d8(=14c8d199d503245f)
02d2c8c8: bl      #0x2b7104c                                 fn_2b7104c
02d2c8cc: ldr     x2, [x21]                                  T:type56879(k15)
02d2c8d0: mov     x1, x19                                    
02d2c8d4: mov     x3, xzr                                    
02d2c8d8: mov     x21, x0                                    
02d2c8dc: bl      #0x5b4cf98                                 UnityEngine.Events.UnityAction::.ctor
02d2c8e0: cbz     x20, #0x2d2c958                            
02d2c8e4: mov     x0, x20                                    
02d2c8e8: mov     x1, x21                                    
02d2c8ec: mov     x2, xzr                                    
02d2c8f0: bl      #0x5b4d0ac                                 UnityEngine.Events.UnityEvent::AddListener
02d2c8f4: ldr     x8, [x19, #0x60]                           ._claimButton
02d2c8f8: cbz     x8, #0x2d2c958                             
02d2c8fc: adrp    x21, #0x626a000                            
02d2c900: ldr     x21, [x21, #0x488]                         M:DailyTask.DailyTaskItemUI::OnClaimButtonClicked
02d2c904: ldr     x0, [x22]                                  M:AdsManager::<OnApplicationPause>b__26_0
02d2c908: ldr     x20, [x8, #0x100]                          &2c5c0d8(=14c8d199d503245f)
02d2c90c: bl      #0x2b7104c                                 fn_2b7104c
02d2c910: ldr     x2, [x21]                                  T:type56879(k15)
02d2c914: mov     x1, x19                                    
02d2c918: mov     x3, xzr                                    
02d2c91c: mov     x21, x0                                    
02d2c920: bl      #0x5b4cf98                                 UnityEngine.Events.UnityAction::.ctor
02d2c924: cbz     x20, #0x2d2c958                            
02d2c928: mov     x0, x20                                    
02d2c92c: mov     x1, x21                                    
02d2c930: mov     x2, xzr                                    
02d2c934: bl      #0x5b4d0ac                                 UnityEngine.Events.UnityEvent::AddListener
02d2c938: mov     x0, x19                                    
02d2c93c: bl      #0x2d2c95c                                 DailyTask.DailyTaskItemUI::UpdateProperties
02d2c940: mov     x0, x19                                    
02d2c944: ldp     x20, x19, [sp, #0x30]                      
02d2c948: ldp     x22, x21, [sp, #0x20]                      
02d2c94c: ldp     x24, x23, [sp, #0x10]                      
02d2c950: ldr     x30, [sp], #0x40                           
02d2c954: ret                                                
02d2c958: bl      #0x2b7105c                                 fn_2b7105c
## UpdateProperties() -> void
---- DailyTask.DailyTaskItemUI::UpdateProperties 0x2d2c95c
02d2c95c: sub     sp, sp, #0x40                              
02d2c960: stp     x30, x23, [sp, #0x10]                      
02d2c964: stp     x22, x21, [sp, #0x20]                      
02d2c968: stp     x20, x19, [sp, #0x30]                      
02d2c96c: adrp    x20, #0x6630000                            
02d2c970: mov     x19, x0                                    
02d2c974: ldrb    w8, [x20, #0xcf]                           
02d2c978: tbnz    w8, #0, #0x2d2c990                         
02d2c97c: adrp    x0, #0x6267000                             
02d2c980: ldr     x0, [x0, #0xd70]                           S:'{0}/{1}'
02d2c984: bl      #0x2b70db0                                 fn_2b70db0
02d2c988: mov     w8, #1                                     
02d2c98c: strb    w8, [x20, #0xcf]                           
02d2c990: ldr     x9, [x19, #0x88]                           ._dailyTaskController
02d2c994: cbz     x9, #0x2d2cb4c                             
02d2c998: ldr     x8, [x19, #0x80]                           ._mission
02d2c99c: cbz     x8, #0x2d2cb4c                             
02d2c9a0: ldr     x0, [x9, #0x38]                            
02d2c9a4: cbz     x0, #0x2d2cb4c                             
02d2c9a8: ldr     w1, [x8, #0x10]                            
02d2c9ac: bl      #0x2d2b26c                                 DailyTask.DataDailyTask::IsTaskCompleted
02d2c9b0: tbz     w0, #0, #0x2d2ca58                         
02d2c9b4: ldr     x0, [x19, #0x28]                           ._progressImage
02d2c9b8: cbz     x0, #0x2d2cb4c                             
02d2c9bc: fmov    s0, #1.00000000                            
02d2c9c0: mov     x1, xzr                                    
02d2c9c4: bl      #0x5c53138                                 UnityEngine.UI.Image::set_fillAmount
02d2c9c8: ldr     x8, [x19, #0x80]                           ._mission
02d2c9cc: cbz     x8, #0x2d2cb4c                             
02d2c9d0: adrp    x22, #0x6263000                            
02d2c9d4: add     x1, sp, #0xc                               
02d2c9d8: ldr     x22, [x22, #0x970]                         &6645c70(=0)
02d2c9dc: ldr     w8, [x8, #0x30]                            
02d2c9e0: ldr     x20, [x19, #0x30]                          ._progressText
02d2c9e4: ldr     x0, [x22, #0x48]                           &6263098(=0)
02d2c9e8: str     w8, [sp, #0xc]                             
02d2c9ec: bl      #0x2b70f38                                 fn_2b70f38
02d2c9f0: ldr     x8, [x19, #0x80]                           ._mission
02d2c9f4: cbz     x8, #0x2d2cb4c                             
02d2c9f8: mov     x21, x0                                    
02d2c9fc: ldr     w8, [x8, #0x30]                            
02d2ca00: ldr     x0, [x22, #0x48]                           &6263098(=0)
02d2ca04: add     x1, sp, #8                                 
02d2ca08: str     w8, [sp, #8]                               
02d2ca0c: bl      #0x2b70f38                                 fn_2b70f38
02d2ca10: adrp    x8, #0x6267000                             
02d2ca14: mov     x2, x0                                     
02d2ca18: mov     x1, x21                                    
02d2ca1c: ldr     x8, [x8, #0xd70]                           S:'{0}/{1}'
02d2ca20: mov     x3, xzr                                    
02d2ca24: ldr     x8, [x8]                                   S:'didu'
02d2ca28: mov     x0, x8                                     
02d2ca2c: bl      #0x4ca7720                                 System.String::Format
02d2ca30: cbz     x20, #0x2d2cb4c                            
02d2ca34: ldr     x8, [x20]                                  
02d2ca38: mov     x1, x0                                     
02d2ca3c: mov     x0, x20                                    
02d2ca40: ldr     x9, [x8, #0x558]                           S:'addView'
02d2ca44: ldr     x2, [x8, #0x560]                           S:'getResources'
02d2ca48: blr     x9                                         
02d2ca4c: mov     x0, x19                                    
02d2ca50: bl      #0x2d2cb50                                 DailyTask.DailyTaskItemUI::SetCompleted
02d2ca54: b       #0x2d2cb38                                 
02d2ca58: ldr     x9, [x19, #0x88]                           ._dailyTaskController
02d2ca5c: cbz     x9, #0x2d2cb4c                             
02d2ca60: ldr     x8, [x19, #0x80]                           ._mission
02d2ca64: cbz     x8, #0x2d2cb4c                             
02d2ca68: ldr     x0, [x9, #0x38]                            
02d2ca6c: cbz     x0, #0x2d2cb4c                             
02d2ca70: ldr     w1, [x8, #0x10]                            S:'startActivity'
02d2ca74: bl      #0x2d2b5a8                                 DailyTask.DataDailyTask::GetProgressOfTask
02d2ca78: ldr     x8, [x19, #0x80]                           ._mission
02d2ca7c: cbz     x8, #0x2d2cb4c                             
02d2ca80: mov     w20, w0                                    
02d2ca84: ldr     x0, [x19, #0x28]                           ._progressImage
02d2ca88: cbz     x0, #0x2d2cb4c                             
02d2ca8c: ldr     s0, [x8, #0x30]                            MS:System.Nullable`1::get_HasValue
02d2ca90: scvtf   s1, w20                                    
02d2ca94: mov     x1, xzr                                    
02d2ca98: scvtf   s0, s0                                     
02d2ca9c: fdiv    s0, s1, s0                                 
02d2caa0: bl      #0x5c53138                                 UnityEngine.UI.Image::set_fillAmount
02d2caa4: adrp    x23, #0x6263000                            
02d2caa8: add     x1, sp, #0xc                               
02d2caac: ldr     x23, [x23, #0x970]                         &6645c70(=0)
02d2cab0: ldr     x21, [x19, #0x30]                          ._progressText
02d2cab4: str     w20, [sp, #0xc]                            
02d2cab8: ldr     x0, [x23, #0x48]                           &6263098(=0)
02d2cabc: bl      #0x2b70f38                                 fn_2b70f38
02d2cac0: ldr     x8, [x19, #0x80]                           ._mission
02d2cac4: cbz     x8, #0x2d2cb4c                             
02d2cac8: mov     x22, x0                                    
02d2cacc: ldr     w8, [x8, #0x30]                            MS:System.Nullable`1::get_HasValue
02d2cad0: ldr     x0, [x23, #0x48]                           &6263098(=0)
02d2cad4: add     x1, sp, #8                                 
02d2cad8: str     w8, [sp, #8]                               
02d2cadc: bl      #0x2b70f38                                 fn_2b70f38
02d2cae0: adrp    x8, #0x6267000                             
02d2cae4: mov     x2, x0                                     
02d2cae8: mov     x1, x22                                    
02d2caec: ldr     x8, [x8, #0xd70]                           S:'{0}/{1}'
02d2caf0: mov     x3, xzr                                    
02d2caf4: ldr     x8, [x8]                                   S:'didu'
02d2caf8: mov     x0, x8                                     
02d2cafc: bl      #0x4ca7720                                 System.String::Format
02d2cb00: cbz     x21, #0x2d2cb4c                            
02d2cb04: ldr     x8, [x21]                                  
02d2cb08: mov     x1, x0                                     
02d2cb0c: mov     x0, x21                                    
02d2cb10: ldr     x9, [x8, #0x558]                           S:'addView'
02d2cb14: ldr     x2, [x8, #0x560]                           S:'getResources'
02d2cb18: blr     x9                                         
02d2cb1c: ldr     x8, [x19, #0x80]                           ._mission
02d2cb20: cbz     x8, #0x2d2cb4c                             
02d2cb24: ldr     w8, [x8, #0x30]                            MS:System.Nullable`1::get_HasValue
02d2cb28: cmp     w20, w8                                    
02d2cb2c: b.lt    #0x2d2cb38                                 
02d2cb30: mov     x0, x19                                    
02d2cb34: bl      #0x2d2cbe8                                 DailyTask.DailyTaskItemUI::SetForClaim
02d2cb38: ldp     x20, x19, [sp, #0x30]                      
02d2cb3c: ldp     x22, x21, [sp, #0x20]                      
02d2cb40: ldp     x30, x23, [sp, #0x10]                      
02d2cb44: add     sp, sp, #0x40                              
02d2cb48: ret                                                
02d2cb4c: bl      #0x2b7105c                                 fn_2b7105c
## SetCompleted() -> void
---- DailyTask.DailyTaskItemUI::SetCompleted 0x2d2cb50
02d2cb50: stp     x30, x19, [sp, #-0x10]!                    
02d2cb54: mov     x19, x0                                    
02d2cb58: ldr     x0, [x0, #0x50]                            ._goButton
02d2cb5c: cbz     x0, #0x2d2cbe4                             
02d2cb60: mov     x1, xzr                                    
02d2cb64: bl      #0x5b339ec                                 UnityEngine.Component::get_gameObject
02d2cb68: cbz     x0, #0x2d2cbe4                             
02d2cb6c: mov     w1, wzr                                    
02d2cb70: mov     x2, xzr                                    
02d2cb74: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d2cb78: ldr     x0, [x19, #0x58]                           ._skipButton
02d2cb7c: cbz     x0, #0x2d2cbe4                             
02d2cb80: mov     x1, xzr                                    
02d2cb84: bl      #0x5b339ec                                 UnityEngine.Component::get_gameObject
02d2cb88: cbz     x0, #0x2d2cbe4                             
02d2cb8c: mov     w1, wzr                                    
02d2cb90: mov     x2, xzr                                    
02d2cb94: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d2cb98: ldr     x0, [x19, #0x60]                           ._claimButton
02d2cb9c: cbz     x0, #0x2d2cbe4                             
02d2cba0: mov     x1, xzr                                    
02d2cba4: bl      #0x5b339ec                                 UnityEngine.Component::get_gameObject
02d2cba8: cbz     x0, #0x2d2cbe4                             
02d2cbac: mov     w1, wzr                                    
02d2cbb0: mov     x2, xzr                                    
02d2cbb4: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d2cbb8: ldr     x0, [x19, #0x68]                           ._doneIcon
02d2cbbc: cbz     x0, #0x2d2cbe4                             
02d2cbc0: mov     w1, #1                                     
02d2cbc4: mov     x2, xzr                                    
02d2cbc8: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d2cbcc: ldr     x0, [x19, #0x70]                           ._doneBG
02d2cbd0: cbz     x0, #0x2d2cbe4                             
02d2cbd4: mov     w1, #1                                     
02d2cbd8: mov     x2, xzr                                    
02d2cbdc: ldp     x30, x19, [sp], #0x10                      
02d2cbe0: b       #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d2cbe4: bl      #0x2b7105c                                 fn_2b7105c
## SetForClaim() -> void
---- DailyTask.DailyTaskItemUI::SetForClaim 0x2d2cbe8
02d2cbe8: stp     x30, x19, [sp, #-0x10]!                    
02d2cbec: mov     x19, x0                                    
02d2cbf0: ldr     x0, [x0, #0x50]                            ._goButton
02d2cbf4: cbz     x0, #0x2d2cc7c                             
02d2cbf8: mov     x1, xzr                                    
02d2cbfc: bl      #0x5b339ec                                 UnityEngine.Component::get_gameObject
02d2cc00: cbz     x0, #0x2d2cc7c                             
02d2cc04: mov     w1, wzr                                    
02d2cc08: mov     x2, xzr                                    
02d2cc0c: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d2cc10: ldr     x0, [x19, #0x58]                           ._skipButton
02d2cc14: cbz     x0, #0x2d2cc7c                             
02d2cc18: mov     x1, xzr                                    
02d2cc1c: bl      #0x5b339ec                                 UnityEngine.Component::get_gameObject
02d2cc20: cbz     x0, #0x2d2cc7c                             
02d2cc24: mov     w1, wzr                                    
02d2cc28: mov     x2, xzr                                    
02d2cc2c: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d2cc30: ldr     x0, [x19, #0x60]                           ._claimButton
02d2cc34: cbz     x0, #0x2d2cc7c                             
02d2cc38: mov     x1, xzr                                    
02d2cc3c: bl      #0x5b339ec                                 UnityEngine.Component::get_gameObject
02d2cc40: cbz     x0, #0x2d2cc7c                             
02d2cc44: mov     w1, #1                                     
02d2cc48: mov     x2, xzr                                    
02d2cc4c: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d2cc50: ldr     x0, [x19, #0x68]                           ._doneIcon
02d2cc54: cbz     x0, #0x2d2cc7c                             
02d2cc58: mov     w1, wzr                                    
02d2cc5c: mov     x2, xzr                                    
02d2cc60: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d2cc64: ldr     x0, [x19, #0x70]                           ._doneBG
02d2cc68: cbz     x0, #0x2d2cc7c                             
02d2cc6c: mov     w1, wzr                                    
02d2cc70: mov     x2, xzr                                    
02d2cc74: ldp     x30, x19, [sp], #0x10                      
02d2cc78: b       #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d2cc7c: bl      #0x2b7105c                                 fn_2b7105c
## HandleGoToMission() -> void
---- DailyTask.DailyTaskItemUI::HandleGoToMission 0x2d2cc80
02d2cc80: str     x30, [sp, #-0x20]!                         
02d2cc84: stp     x20, x19, [sp, #0x10]                      
02d2cc88: adrp    x20, #0x6630000                            
02d2cc8c: mov     x19, x0                                    
02d2cc90: ldrb    w8, [x20, #0xd0]                           
02d2cc94: tbnz    w8, #0, #0x2d2ccb8                         
02d2cc98: adrp    x0, #0x6263000                             
02d2cc9c: ldr     x0, [x0, #0x928]                           T:UnityEngine.Debug
02d2cca0: bl      #0x2b70db0                                 fn_2b70db0
02d2cca4: adrp    x0, #0x626a000                             
02d2cca8: ldr     x0, [x0, #0x4a8]                           S:'Unknown mission type.'
02d2ccac: bl      #0x2b70db0                                 fn_2b70db0
02d2ccb0: mov     w8, #1                                     
02d2ccb4: strb    w8, [x20, #0xd0]                           
02d2ccb8: ldr     x8, [x19, #0x80]                           ._mission
02d2ccbc: cbz     x8, #0x2d2cd50                             
02d2ccc0: ldr     w8, [x8, #0x20]                            
02d2ccc4: sub     w9, w8, #4                                 
02d2ccc8: cmn     w9, #4                                     
02d2cccc: b.hi    #0x2d2ccf0                                 
02d2ccd0: cmp     w8, #4                                     
02d2ccd4: b.ne    #0x2d2cd1c                                 
02d2ccd8: ldr     x0, [x19, #0x98]                           ._jellyHome
02d2ccdc: cbz     x0, #0x2d2cd50                             
02d2cce0: ldp     x20, x19, [sp, #0x10]                      
02d2cce4: mov     x1, xzr                                    
02d2cce8: ldr     x30, [sp], #0x20                           
02d2ccec: b       #0x2cb31e4                                 ScreenHome::ShowDecor
02d2ccf0: ldr     x0, [x19, #0x90]                           ._popupDailyTask
02d2ccf4: cbz     x0, #0x2d2cd50                             
02d2ccf8: ldr     x8, [x0]                                   T:type56879(k15)
02d2ccfc: ldp     x9, x1, [x8, #0x198]                       
02d2cd00: blr     x9                                         
02d2cd04: ldr     x0, [x19, #0x98]                           ._jellyHome
02d2cd08: cbz     x0, #0x2d2cd50                             
02d2cd0c: ldp     x20, x19, [sp, #0x10]                      
02d2cd10: mov     x1, xzr                                    
02d2cd14: ldr     x30, [sp], #0x20                           
02d2cd18: b       #0x2cb30a0                                 ScreenHome::OnLiveButtonClicked
02d2cd1c: adrp    x8, #0x6263000                             
02d2cd20: ldr     x8, [x8, #0x928]                           T:UnityEngine.Debug
02d2cd24: ldr     x0, [x8]                                   &2c5bbd4(=a9bd7bfdd503233f)
02d2cd28: ldr     w8, [x0, #0xe4]                            [626a0e4]=0 f=0,0
02d2cd2c: cbnz    w8, #0x2d2cd34                             
02d2cd30: bl      #0x2b70f30                                 fn_2b70f30
02d2cd34: adrp    x8, #0x626a000                             
02d2cd38: mov     x1, xzr                                    
02d2cd3c: ldr     x8, [x8, #0x4a8]                           S:'Unknown mission type.'
02d2cd40: ldp     x20, x19, [sp, #0x10]                      
02d2cd44: ldr     x0, [x8]                                   T:type56879(k15)
02d2cd48: ldr     x30, [sp], #0x20                           
02d2cd4c: b       #0x5af2c94                                 UnityEngine.Debug::LogWarning
02d2cd50: bl      #0x2b7105c                                 fn_2b7105c
## OnGoButtonClicked() -> void
---- DailyTask.DailyTaskItemUI::OnGoButtonClicked 0x2d2cd54
02d2cd54: stp     x30, x19, [sp, #-0x10]!                    
02d2cd58: mov     x19, x0                                    
02d2cd5c: mov     x0, xzr                                    
02d2cd60: bl      #0x2d6eec8                                 Framework.AudioManager::get_Instance
02d2cd64: cbz     x0, #0x2d2cdbc                             
02d2cd68: movi    d1, #0000000000000000                      
02d2cd6c: movi    d2, #0000000000000000                      
02d2cd70: mov     w1, #1                                     
02d2cd74: fmov    s0, #1.00000000                            
02d2cd78: mov     w2, wzr                                    
02d2cd7c: mov     w3, wzr                                    
02d2cd80: mov     x4, xzr                                    
02d2cd84: bl      #0x2d6f03c                                 Framework.AudioManager::PlaySound
02d2cd88: ldr     x0, [x19, #0x90]                           ._popupDailyTask
02d2cd8c: cbz     x0, #0x2d2cdbc                             
02d2cd90: mov     x1, xzr                                    
02d2cd94: str     xzr, [x0, #0x98]!                          ._jellyHome
02d2cd98: bl      #0x2b70d54                                 fn_2b70d54
02d2cd9c: ldr     x0, [x19, #0x90]                           ._popupDailyTask
02d2cda0: cbz     x0, #0x2d2cdbc                             
02d2cda4: ldr     x8, [x0]                                   
02d2cda8: ldp     x9, x1, [x8, #0x198]                       
02d2cdac: blr     x9                                         
02d2cdb0: mov     x0, x19                                    
02d2cdb4: ldp     x30, x19, [sp], #0x10                      
02d2cdb8: b       #0x2d2cc80                                 DailyTask.DailyTaskItemUI::HandleGoToMission
02d2cdbc: bl      #0x2b7105c                                 fn_2b7105c
## OnSkipButtonClicked() -> void
---- DailyTask.DailyTaskItemUI::OnSkipButtonClicked 0x2d2cdc0
02d2cdc0: str     x30, [sp, #-0x30]!                         
02d2cdc4: stp     x22, x21, [sp, #0x10]                      
02d2cdc8: stp     x20, x19, [sp, #0x20]                      
02d2cdcc: adrp    x20, #0x6630000                            
02d2cdd0: mov     x19, x0                                    
02d2cdd4: ldrb    w8, [x20, #0xd1]                           
02d2cdd8: tbnz    w8, #0, #0x2d2ce14                         
02d2cddc: adrp    x0, #0x6264000                             
02d2cde0: ldr     x0, [x0, #0xf90]                           T:System.Action
02d2cde4: bl      #0x2b70db0                                 fn_2b70db0
02d2cde8: adrp    x0, #0x626a000                             
02d2cdec: ldr     x0, [x0, #0x4b0]                           M:DailyTask.DailyTaskItemUI::<OnSkipButtonClicked>b__27_0
02d2cdf0: bl      #0x2b70db0                                 fn_2b70db0
02d2cdf4: adrp    x0, #0x6265000                             
02d2cdf8: ldr     x0, [x0, #0x310]                           MS:WejoyService.Singleton`1::get_Instance
02d2cdfc: bl      #0x2b70db0                                 fn_2b70db0
02d2ce00: adrp    x0, #0x626a000                             
02d2ce04: ldr     x0, [x0, #0x4b8]                           S:'skip_task'
02d2ce08: bl      #0x2b70db0                                 fn_2b70db0
02d2ce0c: mov     w8, #1                                     
02d2ce10: strb    w8, [x20, #0xd1]                           
02d2ce14: mov     x0, xzr                                    
02d2ce18: bl      #0x2d6eec8                                 Framework.AudioManager::get_Instance
02d2ce1c: cbz     x0, #0x2d2ceb0                             
02d2ce20: movi    d1, #0000000000000000                      
02d2ce24: movi    d2, #0000000000000000                      
02d2ce28: adrp    x20, #0x6265000                            
02d2ce2c: fmov    s0, #1.00000000                            
02d2ce30: adrp    x21, #0x6264000                            
02d2ce34: adrp    x22, #0x626a000                            
02d2ce38: ldr     x20, [x20, #0x310]                         MS:WejoyService.Singleton`1::get_Instance
02d2ce3c: ldr     x21, [x21, #0xf90]                         T:System.Action
02d2ce40: ldr     x22, [x22, #0x4b0]                         M:DailyTask.DailyTaskItemUI::<OnSkipButtonClicked>b__27_0
02d2ce44: mov     w1, #1                                     
02d2ce48: mov     w2, wzr                                    
02d2ce4c: mov     w3, wzr                                    
02d2ce50: mov     x4, xzr                                    
02d2ce54: bl      #0x2d6f03c                                 Framework.AudioManager::PlaySound
02d2ce58: ldr     x0, [x20]                                  M:AdsManager::<OnApplicationPause>b__26_0
02d2ce5c: bl      #0x3be7218                                 fn_3be7218
02d2ce60: ldr     x8, [x21]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d2ce64: mov     x20, x0                                    
02d2ce68: mov     x0, x8                                     
02d2ce6c: bl      #0x2b7104c                                 fn_2b7104c
02d2ce70: ldr     x2, [x22]                                  T:type56879(k15)
02d2ce74: mov     x1, x19                                    
02d2ce78: mov     x3, xzr                                    
02d2ce7c: mov     x21, x0                                    
02d2ce80: bl      #0x4d8ddbc                                 System.Action::.ctor
02d2ce84: cbz     x20, #0x2d2ceb0                            
02d2ce88: adrp    x8, #0x626a000                             
02d2ce8c: mov     x0, x20                                    
02d2ce90: mov     x2, x21                                    
02d2ce94: ldr     x8, [x8, #0x4b8]                           S:'skip_task'
02d2ce98: ldp     x20, x19, [sp, #0x20]                      
02d2ce9c: ldp     x22, x21, [sp, #0x10]                      
02d2cea0: mov     x3, xzr                                    
02d2cea4: ldr     x1, [x8]                                   T:type56879(k15)
02d2cea8: ldr     x30, [sp], #0x30                           
02d2ceac: b       #0x2c8a2c0                                 AdsManager::ShowRewarded
02d2ceb0: bl      #0x2b7105c                                 fn_2b7105c
## OnClaimButtonClicked() -> void
---- DailyTask.DailyTaskItemUI::OnClaimButtonClicked 0x2d2ceb4
02d2ceb4: stp     x30, x19, [sp, #-0x10]!                    
02d2ceb8: mov     x19, x0                                    
02d2cebc: mov     x0, xzr                                    
02d2cec0: bl      #0x2d6eec8                                 Framework.AudioManager::get_Instance
02d2cec4: cbz     x0, #0x2d2cf04                             
02d2cec8: movi    d1, #0000000000000000                      
02d2cecc: movi    d2, #0000000000000000                      
02d2ced0: mov     w1, #1                                     
02d2ced4: fmov    s0, #1.00000000                            
02d2ced8: mov     w2, wzr                                    
02d2cedc: mov     w3, wzr                                    
02d2cee0: mov     x4, xzr                                    
02d2cee4: bl      #0x2d6f03c                                 Framework.AudioManager::PlaySound
02d2cee8: ldr     x8, [x19, #0x80]                           ._mission
02d2ceec: cbz     x8, #0x2d2cf04                             
02d2cef0: ldr     x0, [x19, #0x88]                           ._dailyTaskController
02d2cef4: cbz     x0, #0x2d2cf04                             
02d2cef8: ldr     w1, [x8, #0x10]                            
02d2cefc: ldp     x30, x19, [sp], #0x10                      
02d2cf00: b       #0x2d2aef0                                 DailyTask.DailyTaskController::CompleteTask
02d2cf04: bl      #0x2b7105c                                 fn_2b7105c
## .ctor() -> void
---- DailyTask.DailyTaskItemUI::.ctor 0x2d2cf08
02d2cf08: mov     x1, xzr                                    
02d2cf0c: b       #0x5b397b0                                 UnityEngine.MonoBehaviour::.ctor
## <OnSkipButtonClicked>b__27_0() -> void
---- DailyTask.DailyTaskItemUI::<OnSkipButtonClicked>b__27_0 0x2d2cf10
02d2cf10: str     x30, [sp, #-0x10]!                         
02d2cf14: ldr     x8, [x0, #0x80]                            ._mission
02d2cf18: cbz     x8, #0x2d2cf30                             
02d2cf1c: ldr     x0, [x0, #0x88]                            ._dailyTaskController
02d2cf20: cbz     x0, #0x2d2cf30                             
02d2cf24: ldr     w1, [x8, #0x10]                            
02d2cf28: ldr     x30, [sp], #0x10                           
02d2cf2c: b       #0x2d2aef0                                 DailyTask.DailyTaskController::CompleteTask
02d2cf30: bl      #0x2b7105c                                 fn_2b7105c
