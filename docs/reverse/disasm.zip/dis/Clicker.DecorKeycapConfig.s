#### CLASS Clicker.DecorKeycapConfig/<>c__DisplayClass15_0 parent= object
#   field id                             int                                                off=0x10 attr=6 
## .ctor() -> void
---- Clicker.DecorKeycapConfig/<>c__DisplayClass15_0::.ctor 0x2d5b778
02d5b778: mov     x1, xzr                                    
02d5b77c: b       #0x4e53e9c                                 System.Object::.ctor
## <GetData>b__0(Clicker.DecorKeycapItemData data) -> bool
---- Clicker.DecorKeycapConfig/<>c__DisplayClass15_0::<GetData>b__0 0x2d5b788
02d5b788: cbz     x1, #0x2d5b7a0                             
02d5b78c: ldr     w8, [x1, #0x10]                            
02d5b790: ldr     w9, [x0, #0x10]                            .id
02d5b794: cmp     w8, w9                                     
02d5b798: cset    w0, eq                                     
02d5b79c: ret                                                
02d5b7a0: str     x30, [sp, #-0x10]!                         
02d5b7a4: bl      #0x2b7105c                                 fn_2b7105c
## <GetData>b__1(Clicker.DecorKeycapItemData data) -> bool
---- Clicker.DecorKeycapConfig/<>c__DisplayClass15_0::<GetData>b__1 0x2d5b7a8
02d5b7a8: cbz     x1, #0x2d5b7c0                             
02d5b7ac: ldr     w8, [x1, #0x10]                            
02d5b7b0: ldr     w9, [x0, #0x10]                            .id
02d5b7b4: cmp     w8, w9                                     
02d5b7b8: cset    w0, eq                                     
02d5b7bc: ret                                                
02d5b7c0: str     x30, [sp, #-0x10]!                         
02d5b7c4: bl      #0x2b7105c                                 fn_2b7105c
#### CLASS Clicker.DecorKeycapConfig parent= Clicker.GameConfig
#   field _dataList                      System.Collections.Generic.List`1<Clicker.DecorKeycapItemData> off=0x18 attr=1 SerializeField
#   field _dataListAB                    System.Collections.Generic.List`1<Clicker.DecorKeycapItemData> off=0x20 attr=1 SerializeField
#   field _onTopDataList                 System.Collections.Generic.List`1<Clicker.DecorKeycapItemData> off=0x28 attr=1 SerializeField
#   field _replaceDataList               System.Collections.Generic.List`1<Clicker.DecorKeycapItemData> off=0x30 attr=1 SerializeField
#   field _replaceButOnBaseDataList      System.Collections.Generic.List`1<Clicker.DecorKeycapItemData> off=0x38 attr=1 SerializeField
#   field _onTopDecorIcons               System.Collections.Generic.List`1<UnityEngine.Sprite> off=0x40 attr=1 HeaderAttribute,SerializeField
#   field _onTopDecorSprites             System.Collections.Generic.List`1<UnityEngine.Sprite> off=0x48 attr=1 SerializeField
#   field _replaceDecorIcons             System.Collections.Generic.List`1<UnityEngine.Sprite> off=0x50 attr=1 SerializeField
#   field _replaceDecorSprites           System.Collections.Generic.List`1<UnityEngine.Sprite> off=0x58 attr=1 SerializeField
#   field _replaceButOnBaseDecorIcons    System.Collections.Generic.List`1<UnityEngine.Sprite> off=0x60 attr=1 SerializeField
#   field _replaceButOnBaseDecorSprites  System.Collections.Generic.List`1<UnityEngine.Sprite> off=0x68 attr=1 SerializeField
## get_DataList() -> System.Collections.Generic.List`1<Clicker.DecorKeycapItemData>
---- Clicker.DecorKeycapConfig::get_DataList 0x2d5b4c0
02d5b4c0: stp     x30, x21, [sp, #-0x20]!                    
02d5b4c4: stp     x20, x19, [sp, #0x10]                      
02d5b4c8: adrp    x21, #0x6630000                            
02d5b4cc: adrp    x20, #0x6264000                            
02d5b4d0: mov     x19, x0                                    
02d5b4d4: ldrb    w8, [x21, #0x2be]                          
02d5b4d8: ldr     x20, [x20, #0xfc0]                         T:RemoteConfigManager
02d5b4dc: tbnz    w8, #0, #0x2d5b4f4                         
02d5b4e0: adrp    x0, #0x6264000                             
02d5b4e4: ldr     x0, [x0, #0xfc0]                           T:RemoteConfigManager
02d5b4e8: bl      #0x2b70db0                                 fn_2b70db0
02d5b4ec: mov     w8, #1                                     
02d5b4f0: strb    w8, [x21, #0x2be]                          
02d5b4f4: ldr     x0, [x20]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d5b4f8: ldr     w8, [x0, #0xe4]                            [62640e4]=0 f=0,0
02d5b4fc: cbnz    w8, #0x2d5b504                             
02d5b500: bl      #0x2b70f30                                 fn_2b70f30
02d5b504: adrp    x21, #0x662f000                            
02d5b508: ldrb    w8, [x21, #0xbc1]                          
02d5b50c: cbnz    w8, #0x2d5b524                             
02d5b510: adrp    x0, #0x6264000                             
02d5b514: ldr     x0, [x0, #0xfc0]                           T:RemoteConfigManager
02d5b518: bl      #0x2b70db0                                 fn_2b70db0
02d5b51c: mov     w8, #1                                     
02d5b520: strb    w8, [x21, #0xbc1]                          
02d5b524: ldr     x0, [x20]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d5b528: ldr     w8, [x0, #0xe4]                            [62640e4]=0 f=0,0
02d5b52c: cbnz    w8, #0x2d5b538                             
02d5b530: bl      #0x2b70f30                                 fn_2b70f30
02d5b534: ldr     x0, [x20]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d5b538: ldr     x8, [x0, #0xb8]                            MS:DG.Tweening.Core.Extensions::SetSpecialStartupMode
02d5b53c: mov     w9, #0x18                                  
02d5b540: ldr     w8, [x8, #0x10]                            
02d5b544: cmp     w8, #1                                     
02d5b548: mov     w8, #0x20                                  
02d5b54c: csel    x8, x9, x8, eq                             
02d5b550: ldr     x0, [x19, x8]                              
02d5b554: ldp     x20, x19, [sp, #0x10]                      
02d5b558: ldp     x30, x21, [sp], #0x20                      
02d5b55c: ret                                                
## get_Count() -> int
---- Clicker.DecorKeycapConfig::get_Count 0x2d5b560
02d5b560: stp     x30, x21, [sp, #-0x20]!                    
02d5b564: stp     x20, x19, [sp, #0x10]                      
02d5b568: adrp    x21, #0x6630000                            
02d5b56c: adrp    x20, #0x6264000                            
02d5b570: mov     x19, x0                                    
02d5b574: ldrb    w8, [x21, #0x2bf]                          
02d5b578: ldr     x20, [x20, #0xfc0]                         T:RemoteConfigManager
02d5b57c: tbnz    w8, #0, #0x2d5b5a0                         
02d5b580: adrp    x0, #0x626b000                             
02d5b584: ldr     x0, [x0, #0xb90]                           MS:System.Collections.Generic.List`1::get_Count
02d5b588: bl      #0x2b70db0                                 fn_2b70db0
02d5b58c: adrp    x0, #0x6264000                             
02d5b590: ldr     x0, [x0, #0xfc0]                           T:RemoteConfigManager
02d5b594: bl      #0x2b70db0                                 fn_2b70db0
02d5b598: mov     w8, #1                                     
02d5b59c: strb    w8, [x21, #0x2bf]                          
02d5b5a0: ldr     x0, [x20]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d5b5a4: ldr     w8, [x0, #0xe4]                            [62640e4]=0 f=0,0
02d5b5a8: cbnz    w8, #0x2d5b5b0                             
02d5b5ac: bl      #0x2b70f30                                 fn_2b70f30
02d5b5b0: adrp    x21, #0x662f000                            
02d5b5b4: ldrb    w8, [x21, #0xbc1]                          
02d5b5b8: cbnz    w8, #0x2d5b5d0                             
02d5b5bc: adrp    x0, #0x6264000                             
02d5b5c0: ldr     x0, [x0, #0xfc0]                           T:RemoteConfigManager
02d5b5c4: bl      #0x2b70db0                                 fn_2b70db0
02d5b5c8: mov     w8, #1                                     
02d5b5cc: strb    w8, [x21, #0xbc1]                          
02d5b5d0: ldr     x0, [x20]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d5b5d4: ldr     w8, [x0, #0xe4]                            [62640e4]=0 f=0,0
02d5b5d8: cbnz    w8, #0x2d5b5e4                             
02d5b5dc: bl      #0x2b70f30                                 fn_2b70f30
02d5b5e0: ldr     x0, [x20]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d5b5e4: ldr     x8, [x0, #0xb8]                            MS:DG.Tweening.Core.Extensions::SetSpecialStartupMode
02d5b5e8: ldr     w8, [x8, #0x10]                            
02d5b5ec: cmp     w8, #1                                     
02d5b5f0: b.ne    #0x2d5b600                                 
02d5b5f4: ldr     x8, [x19, #0x18]                           ._dataList
02d5b5f8: cbnz    x8, #0x2d5b608                             
02d5b5fc: bl      #0x2b7105c                                 fn_2b7105c
02d5b600: ldr     x8, [x19, #0x20]                           ._dataListAB
02d5b604: cbz     x8, #0x2d5b5fc                             
02d5b608: ldp     x20, x19, [sp, #0x10]                      
02d5b60c: ldr     w0, [x8, #0x18]                            
02d5b610: ldp     x30, x21, [sp], #0x20                      
02d5b614: ret                                                
## GetData(int id) -> Clicker.DecorKeycapItemData
---- Clicker.DecorKeycapConfig::GetData 0x2d5b618
02d5b618: str     x30, [sp, #-0x30]!                         
02d5b61c: stp     x22, x21, [sp, #0x10]                      
02d5b620: stp     x20, x19, [sp, #0x20]                      
02d5b624: adrp    x20, #0x6630000                            
02d5b628: adrp    x22, #0x626b000                            
02d5b62c: mov     w21, w1                                    
02d5b630: ldrb    w8, [x20, #0x2c0]                          
02d5b634: ldr     x22, [x22, #0xc30]                         T:Clicker.DecorKeycapConfig/<>c__DisplayClass15_0
02d5b638: mov     x19, x0                                    
02d5b63c: tbnz    w8, #0, #0x2d5b690                         
02d5b640: adrp    x0, #0x626a000                             
02d5b644: ldr     x0, [x0, #0x988]                           MS:System.Collections.Generic.List`1::Find
02d5b648: bl      #0x2b70db0                                 fn_2b70db0
02d5b64c: adrp    x0, #0x626a000                             
02d5b650: ldr     x0, [x0, #0x990]                           T:type57241(k15)
02d5b654: bl      #0x2b70db0                                 fn_2b70db0
02d5b658: adrp    x0, #0x6264000                             
02d5b65c: ldr     x0, [x0, #0xfc0]                           T:RemoteConfigManager
02d5b660: bl      #0x2b70db0                                 fn_2b70db0
02d5b664: adrp    x0, #0x626b000                             
02d5b668: ldr     x0, [x0, #0xc38]                           M:Clicker.DecorKeycapConfig/<>c__DisplayClass15_0::<GetData>b__0
02d5b66c: bl      #0x2b70db0                                 fn_2b70db0
02d5b670: adrp    x0, #0x626b000                             
02d5b674: ldr     x0, [x0, #0xc40]                           M:Clicker.DecorKeycapConfig/<>c__DisplayClass15_0::<GetData>b__1
02d5b678: bl      #0x2b70db0                                 fn_2b70db0
02d5b67c: adrp    x0, #0x626b000                             
02d5b680: ldr     x0, [x0, #0xc30]                           T:Clicker.DecorKeycapConfig/<>c__DisplayClass15_0
02d5b684: bl      #0x2b70db0                                 fn_2b70db0
02d5b688: mov     w8, #1                                     
02d5b68c: strb    w8, [x20, #0x2c0]                          
02d5b690: ldr     x0, [x22]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d5b694: bl      #0x2b7104c                                 fn_2b7104c
02d5b698: mov     x1, xzr                                    
02d5b69c: mov     x20, x0                                    
02d5b6a0: bl      #0x4e53e9c                                 System.Object::.ctor
02d5b6a4: cbz     x20, #0x2d5b774                            
02d5b6a8: adrp    x22, #0x6264000                            
02d5b6ac: ldr     x22, [x22, #0xfc0]                         T:RemoteConfigManager
02d5b6b0: str     w21, [x20, #0x10]                          
02d5b6b4: ldr     x0, [x22]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d5b6b8: ldr     w8, [x0, #0xe4]                            [626b0e4]=0 f=0,0
02d5b6bc: cbnz    w8, #0x2d5b6c4                             
02d5b6c0: bl      #0x2b70f30                                 fn_2b70f30
02d5b6c4: adrp    x21, #0x662f000                            
02d5b6c8: ldrb    w8, [x21, #0xbc1]                          
02d5b6cc: cbnz    w8, #0x2d5b6e4                             
02d5b6d0: adrp    x0, #0x6264000                             
02d5b6d4: ldr     x0, [x0, #0xfc0]                           T:RemoteConfigManager
02d5b6d8: bl      #0x2b70db0                                 fn_2b70db0
02d5b6dc: mov     w8, #1                                     
02d5b6e0: strb    w8, [x21, #0xbc1]                          
02d5b6e4: ldr     x0, [x22]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d5b6e8: adrp    x21, #0x626a000                            
02d5b6ec: ldr     w8, [x0, #0xe4]                            [62640e4]=0 f=0,0
02d5b6f0: ldr     x21, [x21, #0x990]                         T:type57241(k15)
02d5b6f4: cbnz    w8, #0x2d5b700                             
02d5b6f8: bl      #0x2b70f30                                 fn_2b70f30
02d5b6fc: ldr     x0, [x22]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d5b700: ldr     x8, [x0, #0xb8]                            MS:DG.Tweening.Core.Extensions::SetSpecialStartupMode
02d5b704: ldr     x0, [x21]                                  T:type56879(k15)
02d5b708: ldr     w8, [x8, #0x10]                            
02d5b70c: cmp     w8, #1                                     
02d5b710: b.ne    #0x2d5b728                                 
02d5b714: ldr     x19, [x19, #0x18]                          ._dataList
02d5b718: bl      #0x2b7104c                                 fn_2b7104c
02d5b71c: adrp    x8, #0x626b000                             
02d5b720: ldr     x8, [x8, #0xc38]                           M:Clicker.DecorKeycapConfig/<>c__DisplayClass15_0::<GetData>b__0
02d5b724: b       #0x2d5b738                                 
02d5b728: ldr     x19, [x19, #0x20]                          ._dataListAB
02d5b72c: bl      #0x2b7104c                                 fn_2b7104c
02d5b730: adrp    x8, #0x626b000                             
02d5b734: ldr     x8, [x8, #0xc40]                           M:Clicker.DecorKeycapConfig/<>c__DisplayClass15_0::<GetData>b__1
02d5b738: ldr     x2, [x8]                                   T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d5b73c: mov     x1, x20                                    
02d5b740: mov     x3, xzr                                    
02d5b744: mov     x21, x0                                    
02d5b748: bl      #0x399ba10                                 fn_399ba10
02d5b74c: cbz     x19, #0x2d5b774                            
02d5b750: adrp    x8, #0x626a000                             
02d5b754: mov     x0, x19                                    
02d5b758: mov     x1, x21                                    
02d5b75c: ldr     x8, [x8, #0x988]                           MS:System.Collections.Generic.List`1::Find
02d5b760: ldp     x20, x19, [sp, #0x20]                      
02d5b764: ldp     x22, x21, [sp, #0x10]                      
02d5b768: ldr     x2, [x8]                                   T:type56879(k15)
02d5b76c: ldr     x30, [sp], #0x30                           
02d5b770: b       #0x35a9868                                 
02d5b774: bl      #0x2b7105c                                 fn_2b7105c
## GetRandomDataLockedCommon() -> Clicker.DecorKeycapItemData
---- Clicker.DecorKeycapConfig::GetRandomDataLockedCommon 0x2d5a494
02d5a494: stp     x30, x23, [sp, #-0x30]!                    
02d5a498: stp     x22, x21, [sp, #0x10]                      
02d5a49c: stp     x20, x19, [sp, #0x20]                      
02d5a4a0: adrp    x20, #0x6630000                            
02d5a4a4: mov     x19, x0                                    
02d5a4a8: ldrb    w8, [x20, #0x2c1]                          
02d5a4ac: tbnz    w8, #0, #0x2d5a4dc                         
02d5a4b0: adrp    x0, #0x626b000                             
02d5a4b4: ldr     x0, [x0, #0xb90]                           MS:System.Collections.Generic.List`1::get_Count
02d5a4b8: bl      #0x2b70db0                                 fn_2b70db0
02d5a4bc: adrp    x0, #0x626b000                             
02d5a4c0: ldr     x0, [x0, #0xb98]                           MS:System.Collections.Generic.List`1::get_Item
02d5a4c4: bl      #0x2b70db0                                 fn_2b70db0
02d5a4c8: adrp    x0, #0x6264000                             
02d5a4cc: ldr     x0, [x0, #0xfc0]                           T:RemoteConfigManager
02d5a4d0: bl      #0x2b70db0                                 fn_2b70db0
02d5a4d4: mov     w8, #1                                     
02d5a4d8: strb    w8, [x20, #0x2c1]                          
02d5a4dc: ldr     x20, [x19, #0x18]                          ._dataList
02d5a4e0: cbz     x20, #0x2d5a660                            
02d5a4e4: adrp    x21, #0x626b000                            
02d5a4e8: adrp    x22, #0x6264000                            
02d5a4ec: mov     w0, wzr                                    
02d5a4f0: ldr     x21, [x21, #0xb98]                         MS:System.Collections.Generic.List`1::get_Item
02d5a4f4: ldr     x22, [x22, #0xfc0]                         T:RemoteConfigManager
02d5a4f8: ldr     w1, [x20, #0x18]                           ._dataList
02d5a4fc: mov     x2, xzr                                    
02d5a500: bl      #0x5b2e000                                 UnityEngine.Random::Range
02d5a504: ldr     x2, [x21]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d5a508: mov     w1, w0                                     
02d5a50c: mov     x0, x20                                    
02d5a510: bl      #0x35a8f3c                                 fn_35a8f3c
02d5a514: ldr     x8, [x22]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d5a518: mov     x20, x0                                    
02d5a51c: ldr     w9, [x8, #0xe4]                            
02d5a520: cbnz    w9, #0x2d5a52c                             
02d5a524: mov     x0, x8                                     
02d5a528: bl      #0x2b70f30                                 fn_2b70f30
02d5a52c: adrp    x23, #0x662f000                            
02d5a530: ldrb    w8, [x23, #0xbc1]                          
02d5a534: cbnz    w8, #0x2d5a54c                             
02d5a538: adrp    x0, #0x6264000                             
02d5a53c: ldr     x0, [x0, #0xfc0]                           T:RemoteConfigManager
02d5a540: bl      #0x2b70db0                                 fn_2b70db0
02d5a544: mov     w8, #1                                     
02d5a548: strb    w8, [x23, #0xbc1]                          
02d5a54c: ldr     x0, [x22]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d5a550: ldr     w8, [x0, #0xe4]                            [62640e4]=0 f=0,0
02d5a554: cbnz    w8, #0x2d5a560                             
02d5a558: bl      #0x2b70f30                                 fn_2b70f30
02d5a55c: ldr     x0, [x22]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d5a560: ldr     x8, [x0, #0xb8]                            MS:DG.Tweening.Core.Extensions::SetSpecialStartupMode
02d5a564: ldr     w8, [x8, #0x10]                            
02d5a568: cmp     w8, #1                                     
02d5a56c: b.ne    #0x2d5a5d4                                 
02d5a570: cbz     x20, #0x2d5a660                            
02d5a574: mov     w22, #0xb                                  
02d5a578: ldr     x8, [x20, #0x30]                           ._replaceDataList
02d5a57c: cbz     x8, #0x2d5a660                             
02d5a580: ldr     w8, [x8, #0x10]                            
02d5a584: cbz     w8, #0x2d5a598                             
02d5a588: cmp     w8, #3                                     
02d5a58c: b.eq    #0x2d5a598                                 
02d5a590: ldr     w8, [x20, #0x24]                           
02d5a594: cbz     w8, #0x2d5a684                             
02d5a598: ldr     x20, [x19, #0x18]                          ._dataList
02d5a59c: subs    w22, w22, #1                               
02d5a5a0: b.eq    #0x2d5a664                                 
02d5a5a4: cbz     x20, #0x2d5a660                            
02d5a5a8: ldr     w1, [x20, #0x18]                           ._dataList
02d5a5ac: mov     w0, wzr                                    
02d5a5b0: mov     x2, xzr                                    
02d5a5b4: bl      #0x5b2e000                                 UnityEngine.Random::Range
02d5a5b8: ldr     x2, [x21]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d5a5bc: mov     w1, w0                                     
02d5a5c0: mov     x0, x20                                    
02d5a5c4: bl      #0x35a8f3c                                 fn_35a8f3c
02d5a5c8: mov     x20, x0                                    
02d5a5cc: cbnz    x0, #0x2d5a578                             
02d5a5d0: b       #0x2d5a660                                 
02d5a5d4: ldr     x20, [x19, #0x20]                          ._dataListAB
02d5a5d8: cbz     x20, #0x2d5a660                            
02d5a5dc: ldr     w1, [x20, #0x18]                           ._dataList
02d5a5e0: mov     w0, wzr                                    
02d5a5e4: mov     x2, xzr                                    
02d5a5e8: bl      #0x5b2e000                                 UnityEngine.Random::Range
02d5a5ec: ldr     x2, [x21]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d5a5f0: mov     w1, w0                                     
02d5a5f4: mov     x0, x20                                    
02d5a5f8: bl      #0x35a8f3c                                 fn_35a8f3c
02d5a5fc: cbz     x0, #0x2d5a660                             
02d5a600: mov     x20, x0                                    
02d5a604: mov     w22, #0xb                                  
02d5a608: ldr     x8, [x20, #0x30]                           ._replaceDataList
02d5a60c: cbz     x8, #0x2d5a660                             
02d5a610: ldr     w8, [x8, #0x10]                            
02d5a614: cbz     w8, #0x2d5a628                             
02d5a618: cmp     w8, #3                                     
02d5a61c: b.eq    #0x2d5a628                                 
02d5a620: ldr     w8, [x20, #0x24]                           
02d5a624: cbz     w8, #0x2d5a684                             
02d5a628: ldr     x20, [x19, #0x20]                          ._dataListAB
02d5a62c: subs    w22, w22, #1                               
02d5a630: b.eq    #0x2d5a664                                 
02d5a634: cbz     x20, #0x2d5a660                            
02d5a638: ldr     w1, [x20, #0x18]                           ._dataList
02d5a63c: mov     w0, wzr                                    
02d5a640: mov     x2, xzr                                    
02d5a644: bl      #0x5b2e000                                 UnityEngine.Random::Range
02d5a648: ldr     x2, [x21]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d5a64c: mov     w1, w0                                     
02d5a650: mov     x0, x20                                    
02d5a654: bl      #0x35a8f3c                                 fn_35a8f3c
02d5a658: mov     x20, x0                                    
02d5a65c: cbnz    x0, #0x2d5a608                             
02d5a660: bl      #0x2b7105c                                 fn_2b7105c
02d5a664: cbz     x20, #0x2d5a660                            
02d5a668: ldr     x2, [x21]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d5a66c: mov     x0, x20                                    
02d5a670: mov     w1, wzr                                    
02d5a674: ldp     x20, x19, [sp, #0x20]                      
02d5a678: ldp     x22, x21, [sp, #0x10]                      
02d5a67c: ldp     x30, x23, [sp], #0x30                      
02d5a680: b       #0x35a8f3c                                 
02d5a684: mov     x0, x20                                    
02d5a688: ldp     x20, x19, [sp, #0x20]                      
02d5a68c: ldp     x22, x21, [sp, #0x10]                      
02d5a690: ldp     x30, x23, [sp], #0x30                      
02d5a694: ret                                                
## GetRandomDataLockedRare() -> Clicker.DecorKeycapItemData
---- Clicker.DecorKeycapConfig::GetRandomDataLockedRare 0x2d5a698
02d5a698: stp     x30, x23, [sp, #-0x30]!                    
02d5a69c: stp     x22, x21, [sp, #0x10]                      
02d5a6a0: stp     x20, x19, [sp, #0x20]                      
02d5a6a4: adrp    x20, #0x6630000                            
02d5a6a8: mov     x19, x0                                    
02d5a6ac: ldrb    w8, [x20, #0x2c2]                          
02d5a6b0: tbnz    w8, #0, #0x2d5a6e0                         
02d5a6b4: adrp    x0, #0x626b000                             
02d5a6b8: ldr     x0, [x0, #0xb90]                           MS:System.Collections.Generic.List`1::get_Count
02d5a6bc: bl      #0x2b70db0                                 fn_2b70db0
02d5a6c0: adrp    x0, #0x626b000                             
02d5a6c4: ldr     x0, [x0, #0xb98]                           MS:System.Collections.Generic.List`1::get_Item
02d5a6c8: bl      #0x2b70db0                                 fn_2b70db0
02d5a6cc: adrp    x0, #0x6264000                             
02d5a6d0: ldr     x0, [x0, #0xfc0]                           T:RemoteConfigManager
02d5a6d4: bl      #0x2b70db0                                 fn_2b70db0
02d5a6d8: mov     w8, #1                                     
02d5a6dc: strb    w8, [x20, #0x2c2]                          
02d5a6e0: ldr     x20, [x19, #0x18]                          ._dataList
02d5a6e4: cbz     x20, #0x2d5a86c                            
02d5a6e8: adrp    x21, #0x626b000                            
02d5a6ec: adrp    x22, #0x6264000                            
02d5a6f0: mov     w0, wzr                                    
02d5a6f4: ldr     x21, [x21, #0xb98]                         MS:System.Collections.Generic.List`1::get_Item
02d5a6f8: ldr     x22, [x22, #0xfc0]                         T:RemoteConfigManager
02d5a6fc: ldr     w1, [x20, #0x18]                           ._dataList
02d5a700: mov     x2, xzr                                    
02d5a704: bl      #0x5b2e000                                 UnityEngine.Random::Range
02d5a708: ldr     x2, [x21]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d5a70c: mov     w1, w0                                     
02d5a710: mov     x0, x20                                    
02d5a714: bl      #0x35a8f3c                                 fn_35a8f3c
02d5a718: ldr     x8, [x22]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d5a71c: mov     x20, x0                                    
02d5a720: ldr     w9, [x8, #0xe4]                            
02d5a724: cbnz    w9, #0x2d5a730                             
02d5a728: mov     x0, x8                                     
02d5a72c: bl      #0x2b70f30                                 fn_2b70f30
02d5a730: adrp    x23, #0x662f000                            
02d5a734: ldrb    w8, [x23, #0xbc1]                          
02d5a738: cbnz    w8, #0x2d5a750                             
02d5a73c: adrp    x0, #0x6264000                             
02d5a740: ldr     x0, [x0, #0xfc0]                           T:RemoteConfigManager
02d5a744: bl      #0x2b70db0                                 fn_2b70db0
02d5a748: mov     w8, #1                                     
02d5a74c: strb    w8, [x23, #0xbc1]                          
02d5a750: ldr     x0, [x22]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d5a754: ldr     w8, [x0, #0xe4]                            [62640e4]=0 f=0,0
02d5a758: cbnz    w8, #0x2d5a764                             
02d5a75c: bl      #0x2b70f30                                 fn_2b70f30
02d5a760: ldr     x0, [x22]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d5a764: ldr     x8, [x0, #0xb8]                            MS:DG.Tweening.Core.Extensions::SetSpecialStartupMode
02d5a768: ldr     w8, [x8, #0x10]                            
02d5a76c: cmp     w8, #1                                     
02d5a770: b.ne    #0x2d5a7dc                                 
02d5a774: cbz     x20, #0x2d5a86c                            
02d5a778: mov     w22, #0xb                                  
02d5a77c: ldr     x8, [x20, #0x30]                           ._replaceDataList
02d5a780: cbz     x8, #0x2d5a86c                             
02d5a784: ldr     w8, [x8, #0x10]                            
02d5a788: cbz     w8, #0x2d5a7a0                             
02d5a78c: cmp     w8, #3                                     
02d5a790: b.eq    #0x2d5a7a0                                 
02d5a794: ldr     w8, [x20, #0x24]                           
02d5a798: cmp     w8, #1                                     
02d5a79c: b.eq    #0x2d5a890                                 
02d5a7a0: ldr     x20, [x19, #0x18]                          ._dataList
02d5a7a4: subs    w22, w22, #1                               
02d5a7a8: b.eq    #0x2d5a870                                 
02d5a7ac: cbz     x20, #0x2d5a86c                            
02d5a7b0: ldr     w1, [x20, #0x18]                           ._dataList
02d5a7b4: mov     w0, wzr                                    
02d5a7b8: mov     x2, xzr                                    
02d5a7bc: bl      #0x5b2e000                                 UnityEngine.Random::Range
02d5a7c0: ldr     x2, [x21]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d5a7c4: mov     w1, w0                                     
02d5a7c8: mov     x0, x20                                    
02d5a7cc: bl      #0x35a8f3c                                 fn_35a8f3c
02d5a7d0: mov     x20, x0                                    
02d5a7d4: cbnz    x0, #0x2d5a77c                             
02d5a7d8: b       #0x2d5a86c                                 
02d5a7dc: ldr     x20, [x19, #0x20]                          ._dataListAB
02d5a7e0: cbz     x20, #0x2d5a86c                            
02d5a7e4: ldr     w1, [x20, #0x18]                           ._dataList
02d5a7e8: mov     w0, wzr                                    
02d5a7ec: mov     x2, xzr                                    
02d5a7f0: bl      #0x5b2e000                                 UnityEngine.Random::Range
02d5a7f4: ldr     x2, [x21]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d5a7f8: mov     w1, w0                                     
02d5a7fc: mov     x0, x20                                    
02d5a800: bl      #0x35a8f3c                                 fn_35a8f3c
02d5a804: cbz     x0, #0x2d5a86c                             
02d5a808: mov     x20, x0                                    
02d5a80c: mov     w22, #0xb                                  
02d5a810: ldr     x8, [x20, #0x30]                           ._replaceDataList
02d5a814: cbz     x8, #0x2d5a86c                             
02d5a818: ldr     w8, [x8, #0x10]                            
02d5a81c: cbz     w8, #0x2d5a834                             
02d5a820: cmp     w8, #3                                     
02d5a824: b.eq    #0x2d5a834                                 
02d5a828: ldr     w8, [x20, #0x24]                           
02d5a82c: cmp     w8, #1                                     
02d5a830: b.eq    #0x2d5a890                                 
02d5a834: ldr     x20, [x19, #0x20]                          ._dataListAB
02d5a838: subs    w22, w22, #1                               
02d5a83c: b.eq    #0x2d5a870                                 
02d5a840: cbz     x20, #0x2d5a86c                            
02d5a844: ldr     w1, [x20, #0x18]                           ._dataList
02d5a848: mov     w0, wzr                                    
02d5a84c: mov     x2, xzr                                    
02d5a850: bl      #0x5b2e000                                 UnityEngine.Random::Range
02d5a854: ldr     x2, [x21]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d5a858: mov     w1, w0                                     
02d5a85c: mov     x0, x20                                    
02d5a860: bl      #0x35a8f3c                                 fn_35a8f3c
02d5a864: mov     x20, x0                                    
02d5a868: cbnz    x0, #0x2d5a810                             
02d5a86c: bl      #0x2b7105c                                 fn_2b7105c
02d5a870: cbz     x20, #0x2d5a86c                            
02d5a874: ldr     x2, [x21]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d5a878: mov     x0, x20                                    
02d5a87c: mov     w1, wzr                                    
02d5a880: ldp     x20, x19, [sp, #0x20]                      
02d5a884: ldp     x22, x21, [sp, #0x10]                      
02d5a888: ldp     x30, x23, [sp], #0x30                      
02d5a88c: b       #0x35a8f3c                                 
02d5a890: mov     x0, x20                                    
02d5a894: ldp     x20, x19, [sp, #0x20]                      
02d5a898: ldp     x22, x21, [sp, #0x10]                      
02d5a89c: ldp     x30, x23, [sp], #0x30                      
02d5a8a0: ret                                                
## .ctor() -> void
---- Clicker.DecorKeycapConfig::.ctor 0x2d5b780
02d5b780: mov     x1, xzr                                    
02d5b784: b       #0x5b398f0                                 UnityEngine.ScriptableObject::.ctor
