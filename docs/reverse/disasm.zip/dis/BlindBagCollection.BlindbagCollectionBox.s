#### CLASS BlindBagCollection.BlindbagCollectionBox/<>c parent= object
#   field <>9                            BlindBagCollection.BlindbagCollectionBox/<>c       off=0x0 attr=36 
#   field <>9__23_0                      System.Action                                      off=0x8 attr=16 
#   field <>9__25_0                      System.Action                                      off=0x10 attr=16 
#   field <>9__33_0                      System.Action                                      off=0x18 attr=16 
#   field <>9__34_0                      DG.Tweening.Core.DOGetter`1<float>                 off=0x20 attr=16 
## .cctor() -> void
---- BlindBagCollection.BlindbagCollectionBox/<>c::.cctor 0x2d32204
02d32204: str     x30, [sp, #-0x20]!                         
02d32208: stp     x20, x19, [sp, #0x10]                      
02d3220c: adrp    x19, #0x6630000                            
02d32210: adrp    x20, #0x626a000                            
02d32214: ldrb    w8, [x19, #0x102]                          
02d32218: ldr     x20, [x20, #0x708]                         T:BlindBagCollection.BlindbagCollectionBox/<>c
02d3221c: tbnz    w8, #0, #0x2d32234                         
02d32220: adrp    x0, #0x626a000                             
02d32224: ldr     x0, [x0, #0x708]                           T:BlindBagCollection.BlindbagCollectionBox/<>c
02d32228: bl      #0x2b70db0                                 fn_2b70db0
02d3222c: mov     w8, #1                                     
02d32230: strb    w8, [x19, #0x102]                          
02d32234: ldr     x0, [x20]                                  T:type56879(k15)
02d32238: bl      #0x2b7104c                                 fn_2b7104c
02d3223c: mov     x1, xzr                                    
02d32240: mov     x19, x0                                    
02d32244: bl      #0x4e53e9c                                 System.Object::.ctor
02d32248: ldr     x8, [x20]                                  T:type56879(k15)
02d3224c: mov     x1, x19                                    
02d32250: ldr     x8, [x8, #0xb8]                            
02d32254: str     x19, [x8]                                  
02d32258: ldr     x8, [x20]                                  T:type56879(k15)
02d3225c: ldp     x20, x19, [sp, #0x10]                      
02d32260: ldr     x0, [x8, #0xb8]                            
02d32264: ldr     x30, [sp], #0x20                           
02d32268: b       #0x2b70d54                                 
## .ctor() -> void
---- BlindBagCollection.BlindbagCollectionBox/<>c::.ctor 0x2d3226c
02d3226c: mov     x1, xzr                                    
02d32270: b       #0x4e53e9c                                 System.Object::.ctor
## <TestAnim>b__23_0() -> void
---- BlindBagCollection.BlindbagCollectionBox/<>c::<TestAnim>b__23_0 0x2d32274
02d32274: ret                                                
## <OnPointerDown>b__25_0() -> void
---- BlindBagCollection.BlindbagCollectionBox/<>c::<OnPointerDown>b__25_0 0x2d32278
02d32278: ret                                                
## <AnimFade>b__33_0() -> void
---- BlindBagCollection.BlindbagCollectionBox/<>c::<AnimFade>b__33_0 0x2d3227c
02d3227c: ret                                                
## <FadeOutSpine>b__34_0() -> float
---- BlindBagCollection.BlindbagCollectionBox/<>c::<FadeOutSpine>b__34_0 0x2d32280
02d32280: fmov    s0, #1.00000000                            
02d32284: ret                                                
#### CLASS BlindBagCollection.BlindbagCollectionBox/<>c__DisplayClass29_0 parent= object
#   field rarityType                     RarityType                                         off=0x10 attr=6 
## .ctor() -> void
---- BlindBagCollection.BlindbagCollectionBox/<>c__DisplayClass29_0::.ctor 0x2d3198c
02d3198c: mov     x1, xzr                                    
02d31990: b       #0x4e53e9c                                 System.Object::.ctor
## <SetData>b__0(BlindBagCollection.PaperCardData p) -> bool
---- BlindBagCollection.BlindbagCollectionBox/<>c__DisplayClass29_0::<SetData>b__0 0x2d32288
02d32288: cbz     x1, #0x2d322a0                             
02d3228c: ldr     w8, [x1, #0x10]                            
02d32290: ldr     w9, [x0, #0x10]                            .rarityType
02d32294: cmp     w8, w9                                     
02d32298: cset    w0, eq                                     
02d3229c: ret                                                
02d322a0: str     x30, [sp, #-0x10]!                         
02d322a4: bl      #0x2b7105c                                 fn_2b7105c
#### CLASS BlindBagCollection.BlindbagCollectionBox/<>c__DisplayClass32_0 parent= object
#   field <>4__this                      BlindBagCollection.BlindbagCollectionBox           off=0x10 attr=6 
#   field onComplete                     System.Action                                      off=0x18 attr=6 
#   field <>9__3                         System.Action                                      off=0x20 attr=6 
#   field <>9__2                         DG.Tweening.TweenCallback                          off=0x28 attr=6 
#   field <>9__1                         DG.Tweening.TweenCallback                          off=0x30 attr=6 
## .ctor() -> void
---- BlindBagCollection.BlindbagCollectionBox/<>c__DisplayClass32_0::.ctor 0x2d31994
02d31994: mov     x1, xzr                                    
02d31998: b       #0x4e53e9c                                 System.Object::.ctor
## <AnimOpen>b__0() -> void
---- BlindBagCollection.BlindbagCollectionBox/<>c__DisplayClass32_0::<AnimOpen>b__0 0x2d322a8
02d322a8: stp     x30, x21, [sp, #-0x20]!                    
02d322ac: stp     x20, x19, [sp, #0x10]                      
02d322b0: adrp    x20, #0x6630000                            
02d322b4: mov     x19, x0                                    
02d322b8: ldrb    w8, [x20, #0x103]                          
02d322bc: tbnz    w8, #0, #0x2d322f8                         
02d322c0: adrp    x0, #0x6264000                             
02d322c4: ldr     x0, [x0, #0xe8]                            T:DG.Tweening.TweenCallback
02d322c8: bl      #0x2b70db0                                 fn_2b70db0
02d322cc: adrp    x0, #0x626a000                             
02d322d0: ldr     x0, [x0, #0x7c8]                           M:BlindBagCollection.BlindbagCollectionBox/<>c__DisplayClass32_0::<AnimOpen>b__1
02d322d4: bl      #0x2b70db0                                 fn_2b70db0
02d322d8: adrp    x0, #0x6267000                             
02d322dc: ldr     x0, [x0, #0xea8]                           T:Framework.Vibration
02d322e0: bl      #0x2b70db0                                 fn_2b70db0
02d322e4: adrp    x0, #0x626a000                             
02d322e8: ldr     x0, [x0, #0x7d0]                           S:'bag_open'
02d322ec: bl      #0x2b70db0                                 fn_2b70db0
02d322f0: mov     w8, #1                                     
02d322f4: strb    w8, [x20, #0x103]                          
02d322f8: mov     x0, xzr                                    
02d322fc: bl      #0x2d6eec8                                 Framework.AudioManager::get_Instance
02d32300: cbz     x0, #0x2d32418                             
02d32304: movi    d1, #0000000000000000                      
02d32308: movi    d2, #0000000000000000                      
02d3230c: mov     w1, #0x10                                  
02d32310: fmov    s0, #1.00000000                            
02d32314: mov     w2, wzr                                    
02d32318: mov     w3, wzr                                    
02d3231c: mov     x4, xzr                                    
02d32320: bl      #0x2d6f03c                                 Framework.AudioManager::PlaySound
02d32324: mov     x0, xzr                                    
02d32328: bl      #0x2d6eec8                                 Framework.AudioManager::get_Instance
02d3232c: cbz     x0, #0x2d32418                             
02d32330: movi    d1, #0000000000000000                      
02d32334: movi    d2, #0000000000000000                      
02d32338: adrp    x20, #0x6267000                            
02d3233c: fmov    s0, #1.00000000                            
02d32340: ldr     x20, [x20, #0xea8]                         T:Framework.Vibration
02d32344: mov     w1, #0x12                                  
02d32348: mov     w2, wzr                                    
02d3234c: mov     w3, wzr                                    
02d32350: mov     x4, xzr                                    
02d32354: bl      #0x2d6f03c                                 Framework.AudioManager::PlaySound
02d32358: ldr     x0, [x20]                                  S:'didu'
02d3235c: ldr     w8, [x0, #0xe4]                            [626a0e4]=0 f=0,0
02d32360: cbnz    w8, #0x2d32368                             
02d32364: bl      #0x2b70f30                                 fn_2b70f30
02d32368: mov     w0, #0x3c                                  
02d3236c: mov     w1, #-1                                    
02d32370: mov     w2, wzr                                    
02d32374: mov     x3, xzr                                    
02d32378: bl      #0x2d6e144                                 Framework.Vibration::Vibrate
02d3237c: ldr     x8, [x19, #0x10]                           .<>4__this
02d32380: cbz     x8, #0x2d32418                             
02d32384: ldr     x0, [x8, #0x78]                            
02d32388: cbz     x0, #0x2d32418                             
02d3238c: mov     x1, xzr                                    
02d32390: bl      #0x4ff6f18                                 Spine.Unity.SkeletonAnimation::get_AnimationState
02d32394: cbz     x0, #0x2d32418                             
02d32398: adrp    x8, #0x626a000                             
02d3239c: mov     w1, wzr                                    
02d323a0: mov     w3, wzr                                    
02d323a4: ldr     x8, [x8, #0x7d0]                           S:'bag_open'
02d323a8: mov     x4, xzr                                    
02d323ac: ldr     x2, [x8]                                   T:type56879(k15)
02d323b0: bl      #0x4f97234                                 Spine.AnimationState::SetAnimation
02d323b4: mov     x20, x19                                   
02d323b8: ldr     x21, [x20, #0x30]!                         MS:System.Nullable`1::get_HasValue .<>9__1
02d323bc: cbnz    x21, #0x2d323fc                            
02d323c0: adrp    x8, #0x6264000                             
02d323c4: ldr     x8, [x8, #0xe8]                            T:DG.Tweening.TweenCallback
02d323c8: ldr     x0, [x8]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d323cc: bl      #0x2b7104c                                 fn_2b7104c
02d323d0: adrp    x8, #0x626a000                             
02d323d4: mov     x1, x19                                    
02d323d8: mov     x3, xzr                                    
02d323dc: ldr     x8, [x8, #0x7c8]                           M:BlindBagCollection.BlindbagCollectionBox/<>c__DisplayClass32_0::<AnimOpen>b__1
02d323e0: mov     x21, x0                                    
02d323e4: ldr     x2, [x8]                                   T:type56879(k15)
02d323e8: bl      #0x2d89dc4                                 DG.Tweening.TweenCallback::.ctor
02d323ec: mov     x0, x20                                    
02d323f0: mov     x1, x21                                    
02d323f4: str     x21, [x19, #0x30]                          .<>9__1
02d323f8: bl      #0x2b70d54                                 fn_2b70d54
02d323fc: ldp     x20, x19, [sp, #0x10]                      
02d32400: fmov    s0, #1.00000000                            
02d32404: mov     x0, x21                                    
02d32408: mov     w1, #1                                     
02d3240c: mov     x2, xzr                                    
02d32410: ldp     x30, x21, [sp], #0x20                      
02d32414: b       #0x2d8f37c                                 DG.Tweening.DOVirtual::DelayedCall
02d32418: bl      #0x2b7105c                                 fn_2b7105c
## <AnimOpen>b__1() -> void
---- BlindBagCollection.BlindbagCollectionBox/<>c__DisplayClass32_0::<AnimOpen>b__1 0x2d3241c
02d3241c: sub     sp, sp, #0x60                              
02d32420: stp     d9, d8, [sp, #0x20]                        
02d32424: stp     x30, x23, [sp, #0x30]                      
02d32428: stp     x22, x21, [sp, #0x40]                      
02d3242c: stp     x20, x19, [sp, #0x50]                      
02d32430: adrp    x20, #0x6630000                            
02d32434: mov     x19, x0                                    
02d32438: ldrb    w8, [x20, #0x104]                          
02d3243c: tbnz    w8, #0, #0x2d3249c                         
02d32440: adrp    x0, #0x6267000                             
02d32444: ldr     x0, [x0, #0xbd0]                           MS:MonoSingleton`1::get_Instance
02d32448: bl      #0x2b70db0                                 fn_2b70db0
02d3244c: adrp    x0, #0x626a000                             
02d32450: ldr     x0, [x0, #0x760]                           T:type24618(k1d)
02d32454: bl      #0x2b70db0                                 fn_2b70db0
02d32458: adrp    x0, #0x6264000                             
02d3245c: ldr     x0, [x0, #0xe8]                            T:DG.Tweening.TweenCallback
02d32460: bl      #0x2b70db0                                 fn_2b70db0
02d32464: adrp    x0, #0x6266000                             
02d32468: ldr     x0, [x0, #0x928]                           MS:DG.Tweening.TweenSettingsExtensions::OnComplete
02d3246c: bl      #0x2b70db0                                 fn_2b70db0
02d32470: adrp    x0, #0x6266000                             
02d32474: ldr     x0, [x0, #0x880]                           MS:DG.Tweening.TweenSettingsExtensions::SetEase
02d32478: bl      #0x2b70db0                                 fn_2b70db0
02d3247c: adrp    x0, #0x626a000                             
02d32480: ldr     x0, [x0, #0x7d8]                           M:BlindBagCollection.BlindbagCollectionBox/<>c__DisplayClass32_0::<AnimOpen>b__2
02d32484: bl      #0x2b70db0                                 fn_2b70db0
02d32488: adrp    x0, #0x626a000                             
02d3248c: ldr     x0, [x0, #0x7e0]                           MS:UIManager::ShowPopup
02d32490: bl      #0x2b70db0                                 fn_2b70db0
02d32494: mov     w8, #1                                     
02d32498: strb    w8, [x20, #0x104]                          
02d3249c: ldr     x8, [x19, #0x10]                           .<>4__this
02d324a0: cbz     x8, #0x2d32730                             
02d324a4: ldr     x0, [x8, #0x68]                            
02d324a8: cbz     x0, #0x2d32730                             
02d324ac: ldr     x1, [x8, #0x98]                            
02d324b0: mov     x2, xzr                                    
02d324b4: bl      #0x5ae6dcc                                 UnityEngine.SpriteRenderer::set_sprite
02d324b8: ldr     x8, [x19, #0x10]                           .<>4__this
02d324bc: cbz     x8, #0x2d32730                             
02d324c0: ldr     x0, [x8, #0x60]                            
02d324c4: mov     w1, wzr                                    
02d324c8: mov     x2, xzr                                    
02d324cc: bl      #0x2d9d5d0                                 DG.Tweening.ShortcutExtensions::DOKill
02d324d0: ldr     x8, [x19, #0x10]                           .<>4__this
02d324d4: cbz     x8, #0x2d32730                             
02d324d8: ldr     x0, [x8, #0x60]                            
02d324dc: adrp    x8, #0x1084000                             
02d324e0: adrp    x9, #0x1084000                             
02d324e4: ldr     s0, [x8, #0xddc]                           [1084ddc]=c77fe0003f733333 f=0.95,-65504
02d324e8: ldr     s1, [x9, #0xeec]                           [1084eec]=457ff0003dcccccd f=0.1,4095
02d324ec: mov     x1, xzr                                    
02d324f0: bl      #0x2c77d0c                                 DG.Tweening.DOTweenModuleSprite::DOFade
02d324f4: ldr     x8, [x19, #0x10]                           .<>4__this
02d324f8: cbz     x8, #0x2d32730                             
02d324fc: ldr     x0, [x8, #0x70]                            [1084070]=7463656a6e495f6c f=1.55805e+28,7.20647e+31
02d32500: mov     w1, wzr                                    
02d32504: mov     x2, xzr                                    
02d32508: bl      #0x2d9d5d0                                 DG.Tweening.ShortcutExtensions::DOKill
02d3250c: ldr     x8, [x19, #0x10]                           .<>4__this
02d32510: cbz     x8, #0x2d32730                             
02d32514: adrp    x20, #0x6266000                            
02d32518: fmov    s0, #1.00000000                            
02d3251c: fmov    s1, #1.00000000                            
02d32520: ldr     x20, [x20, #0x880]                         MS:DG.Tweening.TweenSettingsExtensions::SetEase
02d32524: ldr     x0, [x8, #0x70]                            [1084070]=7463656a6e495f6c f=1.55805e+28,7.20647e+31
02d32528: mov     x1, xzr                                    
02d3252c: bl      #0x2d98c98                                 DG.Tweening.ShortcutExtensions::DOScale
02d32530: ldr     x2, [x20]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d32534: mov     w1, #0x1b                                  
02d32538: bl      #0x336fa0c                                 fn_336fa0c
02d3253c: ldr     x8, [x19, #0x10]                           .<>4__this
02d32540: cbz     x8, #0x2d32730                             
02d32544: ldr     x0, [x8, #0x28]                            [1084028]=6e6f436472616f62 f=4.4652e+30,1.85121e+28
02d32548: cbz     x0, #0x2d32730                             
02d3254c: mov     x1, xzr                                    
02d32550: bl      #0x5b46ff0                                 UnityEngine.Transform::get_localScale
02d32554: fmov    s1, #0.50000000                            
02d32558: fcmp    s0, s1                                     
02d3255c: b.hi    #0x2d32624                                 
02d32560: ldr     x8, [x19, #0x10]                           .<>4__this
02d32564: cbz     x8, #0x2d32730                             
02d32568: ldr     x0, [x8, #0x20]                            [1084020]=79654b7465533a3a f=6.23433e+22,7.44104e+34
02d3256c: cbz     x0, #0x2d32730                             
02d32570: add     x8, sp, #8                                 
02d32574: mov     x1, xzr                                    
02d32578: bl      #0x5b02028                                 UnityEngine.Renderer::get_bounds
02d3257c: adrp    x8, #0x626a000                             
02d32580: mov     w1, #3                                     
02d32584: ldr     x8, [x8, #0x760]                           T:type24618(k1d)
02d32588: ldp     s9, s8, [sp, #0x14]                        
02d3258c: ldr     x0, [x8]                                   T:type56879(k15)
02d32590: bl      #0x2b70ea0                                 fn_2b70ea0
02d32594: cbz     x0, #0x2d32730                             
02d32598: ldr     x8, [x0, #0x18]                            MS:System.Collections.Generic.List`1::Add .onComplete
02d3259c: cbz     w8, #0x2d32734                             
02d325a0: mov     w9, #0x3f800000                            
02d325a4: cmp     w8, #1                                     
02d325a8: str     w9, [x0, #0x20]                            .<>9__3
02d325ac: b.eq    #0x2d32734                                 
02d325b0: fadd    s1, s9, s9                                 
02d325b4: adrp    x9, #0x1084000                             
02d325b8: cmp     w8, #2                                     
02d325bc: ldr     s0, [x9, #0xe88]                           [1084e88]=400aaaab3fcccccd f=1.6,2.16667
02d325c0: fdiv    s1, s0, s1                                 
02d325c4: str     s1, [x0, #0x24]                            
02d325c8: b.ls    #0x2d32734                                 
02d325cc: fadd    s1, s8, s8                                 
02d325d0: fdiv    s1, s0, s1                                 
02d325d4: fmov    s0, #1.00000000                            
02d325d8: str     s1, [x0, #0x28]                            .<>9__2
02d325dc: b.lt    #0x2d32600                                 
02d325e0: and     x8, x8, #0xffffffff                        
02d325e4: add     x9, x0, #0x24                              &626a024
02d325e8: sub     x8, x8, #1                                 
02d325ec: ldr     s1, [x9], #4                               [1084000]=287475706e49646c f=1.5582e+28,1.35702e-14
02d325f0: fcmp    s1, s0                                     
02d325f4: fcsel   s0, s1, s0, mi                             
02d325f8: subs    x8, x8, #1                                 
02d325fc: b.ne    #0x2d325ec                                 
02d32600: ldr     x8, [x19, #0x10]                           .<>4__this
02d32604: cbz     x8, #0x2d32730                             
02d32608: fmov    s1, #0.50000000                            
02d3260c: ldr     x0, [x8, #0x28]                            T:Decor.DataDecor/<>c__DisplayClass8_0
02d32610: mov     x1, xzr                                    
02d32614: bl      #0x2d98c98                                 DG.Tweening.ShortcutExtensions::DOScale
02d32618: ldr     x2, [x20]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d3261c: mov     w1, #1                                     
02d32620: bl      #0x336fa0c                                 fn_336fa0c
02d32624: ldr     x8, [x19, #0x18]                           .onComplete
02d32628: cbz     x8, #0x2d3263c                             
02d3262c: ldr     x9, [x8, #0x18]                            MS:System.Collections.Generic.List`1::Add
02d32630: ldr     x0, [x8, #0x40]                            MS:System.Collections.Generic.List`1::IndexOf
02d32634: ldr     x1, [x8, #0x28]                            T:Decor.DataDecor/<>c__DisplayClass8_0
02d32638: blr     x9                                         
02d3263c: ldr     x0, [x19, #0x10]                           .<>4__this
02d32640: cbz     x0, #0x2d32730                             
02d32644: adrp    x21, #0x6267000                            
02d32648: ldr     x21, [x21, #0xbd0]                         MS:MonoSingleton`1::get_Instance
02d3264c: bl      #0x2d3199c                                 BlindBagCollection.BlindbagCollectionBox::AnimFade
02d32650: ldr     x0, [x21]                                  S:'didu'
02d32654: bl      #0x3769600                                 fn_3769600
02d32658: cbz     x0, #0x2d32730                             
02d3265c: adrp    x8, #0x626a000                             
02d32660: ldr     x8, [x8, #0x7e0]                           MS:UIManager::ShowPopup
02d32664: ldr     x1, [x8]                                   T:type56879(k15)
02d32668: bl      #0x33fbfac                                 fn_33fbfac
02d3266c: ldr     x8, [x19, #0x10]                           .<>4__this
02d32670: cbz     x8, #0x2d32730                             
02d32674: cbz     x0, #0x2d32730                             
02d32678: ldrb    w1, [x8, #0x90]                            
02d3267c: mov     x2, xzr                                    
02d32680: bl      #0x2d586fc                                 Blindbag.PopupWowBlindbag::ShowGetOneMore
02d32684: ldr     x8, [x19, #0x10]                           .<>4__this
02d32688: cbz     x8, #0x2d32730                             
02d3268c: adrp    x23, #0x6266000                            
02d32690: fmov    s0, #3.00000000                            
02d32694: mov     w1, wzr                                    
02d32698: ldr     x23, [x23, #0x928]                         MS:DG.Tweening.TweenSettingsExtensions::OnComplete
02d3269c: ldr     x0, [x8, #0x38]                            MS:System.Collections.Generic.List`1::get_Item
02d326a0: adrp    x8, #0x1084000                             
02d326a4: ldr     s1, [x8, #0xf10]                           [1084f10]=4110bc863e99999a f=0.3,9.04603
02d326a8: mov     x2, xzr                                    
02d326ac: bl      #0x2d98060                                 DG.Tweening.ShortcutExtensions::DOLocalMoveY
02d326b0: ldr     x2, [x20]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d326b4: mov     w1, #1                                     
02d326b8: bl      #0x336fa0c                                 fn_336fa0c
02d326bc: mov     x21, x19                                   
02d326c0: mov     x20, x0                                    
02d326c4: ldr     x22, [x21, #0x28]!                         S:'[^A-Za-z0-9_. ]+' .<>9__2
02d326c8: cbnz    x22, #0x2d32708                            
02d326cc: adrp    x8, #0x6264000                             
02d326d0: ldr     x8, [x8, #0xe8]                            T:DG.Tweening.TweenCallback
02d326d4: ldr     x0, [x8]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d326d8: bl      #0x2b7104c                                 fn_2b7104c
02d326dc: adrp    x8, #0x626a000                             
02d326e0: mov     x1, x19                                    
02d326e4: mov     x3, xzr                                    
02d326e8: ldr     x8, [x8, #0x7d8]                           M:BlindBagCollection.BlindbagCollectionBox/<>c__DisplayClass32_0::<AnimOpen>b__2
02d326ec: mov     x22, x0                                    
02d326f0: ldr     x2, [x8]                                   T:type56879(k15)
02d326f4: bl      #0x2d89dc4                                 DG.Tweening.TweenCallback::.ctor
02d326f8: mov     x0, x21                                    
02d326fc: mov     x1, x22                                    
02d32700: str     x22, [x19, #0x28]                          .<>9__2
02d32704: bl      #0x2b70d54                                 fn_2b70d54
02d32708: ldr     x2, [x23]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d3270c: mov     x0, x20                                    
02d32710: mov     x1, x22                                    
02d32714: bl      #0x336f26c                                 fn_336f26c
02d32718: ldp     x20, x19, [sp, #0x50]                      
02d3271c: ldp     x22, x21, [sp, #0x40]                      
02d32720: ldp     x30, x23, [sp, #0x30]                      
02d32724: ldp     d9, d8, [sp, #0x20]                        
02d32728: add     sp, sp, #0x60                              
02d3272c: ret                                                
02d32730: bl      #0x2b7105c                                 fn_2b7105c
02d32734: bl      #0x2b71064                                 fn_2b71064
## <AnimOpen>b__2() -> void
---- BlindBagCollection.BlindbagCollectionBox/<>c__DisplayClass32_0::<AnimOpen>b__2 0x2d32738
02d32738: str     x30, [sp, #-0x30]!                         
02d3273c: stp     x22, x21, [sp, #0x10]                      
02d32740: stp     x20, x19, [sp, #0x20]                      
02d32744: adrp    x20, #0x6630000                            
02d32748: mov     x19, x0                                    
02d3274c: ldrb    w8, [x20, #0x105]                          
02d32750: tbnz    w8, #0, #0x2d32774                         
02d32754: adrp    x0, #0x6264000                             
02d32758: ldr     x0, [x0, #0xf90]                           T:System.Action
02d3275c: bl      #0x2b70db0                                 fn_2b70db0
02d32760: adrp    x0, #0x626a000                             
02d32764: ldr     x0, [x0, #0x7e8]                           M:BlindBagCollection.BlindbagCollectionBox/<>c__DisplayClass32_0::<AnimOpen>b__3
02d32768: bl      #0x2b70db0                                 fn_2b70db0
02d3276c: mov     w8, #1                                     
02d32770: strb    w8, [x20, #0x105]                          
02d32774: ldr     x20, [x19, #0x10]                          .<>4__this
02d32778: cbz     x20, #0x2d32818                            
02d3277c: ldrb    w8, [x20, #0x90]                           
02d32780: cbz     w8, #0x2d327b4                             
02d32784: mov     x0, xzr                                    
02d32788: bl      #0x2d6eec8                                 Framework.AudioManager::get_Instance
02d3278c: cbz     x0, #0x2d32818                             
02d32790: movi    d1, #0000000000000000                      
02d32794: movi    d2, #0000000000000000                      
02d32798: mov     w1, #0x13                                  
02d3279c: fmov    s0, #1.00000000                            
02d327a0: mov     w2, wzr                                    
02d327a4: mov     w3, wzr                                    
02d327a8: mov     x4, xzr                                    
02d327ac: bl      #0x2d6f03c                                 Framework.AudioManager::PlaySound
02d327b0: ldr     x20, [x19, #0x10]                          .<>4__this
02d327b4: mov     x21, x19                                   
02d327b8: ldr     x22, [x21, #0x20]!                         .<>9__3
02d327bc: cbnz    x22, #0x2d327fc                            
02d327c0: adrp    x8, #0x6264000                             
02d327c4: ldr     x8, [x8, #0xf90]                           T:System.Action
02d327c8: ldr     x0, [x8]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d327cc: bl      #0x2b7104c                                 fn_2b7104c
02d327d0: adrp    x8, #0x626a000                             
02d327d4: mov     x1, x19                                    
02d327d8: mov     x3, xzr                                    
02d327dc: ldr     x8, [x8, #0x7e8]                           M:BlindBagCollection.BlindbagCollectionBox/<>c__DisplayClass32_0::<AnimOpen>b__3
02d327e0: mov     x22, x0                                    
02d327e4: ldr     x2, [x8]                                   T:type56879(k15)
02d327e8: bl      #0x4d8ddbc                                 System.Action::.ctor
02d327ec: mov     x0, x21                                    
02d327f0: mov     x1, x22                                    
02d327f4: str     x22, [x19, #0x20]                          .<>9__3
02d327f8: bl      #0x2b70d54                                 fn_2b70d54
02d327fc: cbz     x20, #0x2d32818                            
02d32800: mov     x0, x20                                    
02d32804: mov     x1, x22                                    
02d32808: ldp     x20, x19, [sp, #0x20]                      
02d3280c: ldp     x22, x21, [sp, #0x10]                      
02d32810: ldr     x30, [sp], #0x30                           
02d32814: b       #0x2d31cec                                 BlindBagCollection.BlindbagCollectionBox::ShowAtCenter
02d32818: bl      #0x2b7105c                                 fn_2b7105c
## <AnimOpen>b__3() -> void
---- BlindBagCollection.BlindbagCollectionBox/<>c__DisplayClass32_0::<AnimOpen>b__3 0x2d3281c
02d3281c: ldr     x8, [x0, #0x10]                            .<>4__this
02d32820: cbz     x8, #0x2d32830                             
02d32824: mov     w9, #1                                     
02d32828: strb    w9, [x8, #0x91]                            
02d3282c: ret                                                
02d32830: str     x30, [sp, #-0x10]!                         
02d32834: bl      #0x2b7105c                                 fn_2b7105c
#### CLASS BlindBagCollection.BlindbagCollectionBox/<>c__DisplayClass34_0 parent= object
#   field skeleton                       Spine.Skeleton                                     off=0x10 attr=6 
#   field originalColor                  UnityEngine.Color                                  off=0x18 attr=6 
#   field onCompleted                    System.Action                                      off=0x28 attr=6 
## .ctor() -> void
---- BlindBagCollection.BlindbagCollectionBox/<>c__DisplayClass34_0::.ctor 0x2d31ce4
02d31ce4: mov     x1, xzr                                    
02d31ce8: b       #0x4e53e9c                                 System.Object::.ctor
## <FadeOutSpine>b__1(float alpha) -> void
---- BlindBagCollection.BlindbagCollectionBox/<>c__DisplayClass34_0::<FadeOutSpine>b__1 0x2d32838
02d32838: ldp     s2, s1, [x0, #0x20]                        
02d3283c: mov     x1, xzr                                    
02d32840: ldr     x8, [x0, #0x10]                            .skeleton
02d32844: fmul    s3, s1, s0                                 
02d32848: ldp     s0, s1, [x0, #0x18]                        .originalColor
02d3284c: mov     x0, x8                                     
02d32850: b       #0x5014060                                 Spine.Unity.SkeletonExtensions::SetColor
## <FadeOutSpine>b__2() -> void
---- BlindBagCollection.BlindbagCollectionBox/<>c__DisplayClass34_0::<FadeOutSpine>b__2 0x2d32854
02d32854: ldr     x8, [x0, #0x28]                            .onCompleted
02d32858: cbz     x8, #0x2d3286c                             
02d3285c: ldr     x0, [x8, #0x40]                            
02d32860: ldr     x1, [x8, #0x28]                            
02d32864: ldr     x2, [x8, #0x18]                            
02d32868: br      x2                                         
02d3286c: ret                                                
#### CLASS BlindBagCollection.BlindbagCollectionBox/<>c__DisplayClass35_0 parent= object
#   field <>4__this                      BlindBagCollection.BlindbagCollectionBox           off=0x10 attr=6 
#   field onDone                         System.Action                                      off=0x18 attr=6 
#   field <>9__2                         DG.Tweening.TweenCallback                          off=0x20 attr=6 
## .ctor() -> void
---- BlindBagCollection.BlindbagCollectionBox/<>c__DisplayClass35_0::.ctor 0x2d31f60
02d31f60: mov     x1, xzr                                    
02d31f64: b       #0x4e53e9c                                 System.Object::.ctor
## <ShowAtCenter>b__0() -> void
---- BlindBagCollection.BlindbagCollectionBox/<>c__DisplayClass35_0::<ShowAtCenter>b__0 0x2d32870
02d32870: stp     x30, x21, [sp, #-0x20]!                    
02d32874: stp     x20, x19, [sp, #0x10]                      
02d32878: adrp    x20, #0x6630000                            
02d3287c: mov     x19, x0                                    
02d32880: ldrb    w8, [x20, #0x106]                          
02d32884: tbnz    w8, #0, #0x2d328a8                         
02d32888: adrp    x0, #0x6264000                             
02d3288c: ldr     x0, [x0, #0xe8]                            T:DG.Tweening.TweenCallback
02d32890: bl      #0x2b70db0                                 fn_2b70db0
02d32894: adrp    x0, #0x626a000                             
02d32898: ldr     x0, [x0, #0x7f0]                           M:BlindBagCollection.BlindbagCollectionBox/<>c__DisplayClass35_0::<ShowAtCenter>b__2
02d3289c: bl      #0x2b70db0                                 fn_2b70db0
02d328a0: mov     w8, #1                                     
02d328a4: strb    w8, [x20, #0x106]                          
02d328a8: mov     x20, x19                                   
02d328ac: ldr     x21, [x20, #0x20]!                         .<>9__2
02d328b0: cbnz    x21, #0x2d328f0                            
02d328b4: adrp    x8, #0x6264000                             
02d328b8: ldr     x8, [x8, #0xe8]                            T:DG.Tweening.TweenCallback
02d328bc: ldr     x0, [x8]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d328c0: bl      #0x2b7104c                                 fn_2b7104c
02d328c4: adrp    x8, #0x626a000                             
02d328c8: mov     x1, x19                                    
02d328cc: mov     x3, xzr                                    
02d328d0: ldr     x8, [x8, #0x7f0]                           M:BlindBagCollection.BlindbagCollectionBox/<>c__DisplayClass35_0::<ShowAtCenter>b__2
02d328d4: mov     x21, x0                                    
02d328d8: ldr     x2, [x8]                                   T:type56879(k15)
02d328dc: bl      #0x2d89dc4                                 DG.Tweening.TweenCallback::.ctor
02d328e0: mov     x0, x20                                    
02d328e4: mov     x1, x21                                    
02d328e8: str     x21, [x19, #0x20]                          .<>9__2
02d328ec: bl      #0x2b70d54                                 fn_2b70d54
02d328f0: ldp     x20, x19, [sp, #0x10]                      
02d328f4: fmov    s0, #1.50000000                            
02d328f8: mov     x0, x21                                    
02d328fc: mov     w1, #1                                     
02d32900: mov     x2, xzr                                    
02d32904: ldp     x30, x21, [sp], #0x20                      
02d32908: b       #0x2d8f37c                                 DG.Tweening.DOVirtual::DelayedCall
## <ShowAtCenter>b__2() -> void
---- BlindBagCollection.BlindbagCollectionBox/<>c__DisplayClass35_0::<ShowAtCenter>b__2 0x2d3290c
02d3290c: str     x30, [sp, #-0x20]!                         
02d32910: stp     x20, x19, [sp, #0x10]                      
02d32914: adrp    x20, #0x6630000                            
02d32918: mov     x19, x0                                    
02d3291c: ldrb    w8, [x20, #0x107]                          
02d32920: tbnz    w8, #0, #0x2d32944                         
02d32924: adrp    x0, #0x6267000                             
02d32928: ldr     x0, [x0, #0xbd0]                           MS:MonoSingleton`1::get_Instance
02d3292c: bl      #0x2b70db0                                 fn_2b70db0
02d32930: adrp    x0, #0x626a000                             
02d32934: ldr     x0, [x0, #0x7f8]                           MS:UIManager::HidePopup
02d32938: bl      #0x2b70db0                                 fn_2b70db0
02d3293c: mov     w8, #1                                     
02d32940: strb    w8, [x20, #0x107]                          
02d32944: ldr     x0, [x19, #0x10]                           .<>4__this
02d32948: cbz     x0, #0x2d329c0                             
02d3294c: bl      #0x2d31f7c                                 BlindBagCollection.BlindbagCollectionBox::HideEffect
02d32950: ldr     x0, [x19, #0x10]                           .<>4__this
02d32954: cbz     x0, #0x2d329c0                             
02d32958: bl      #0x2d3204c                                 BlindBagCollection.BlindbagCollectionBox::FlyToTray
02d3295c: ldr     x8, [x19, #0x18]                           .onDone
02d32960: cbz     x8, #0x2d32974                             
02d32964: ldr     x9, [x8, #0x18]                            
02d32968: ldr     x0, [x8, #0x40]                            
02d3296c: ldr     x1, [x8, #0x28]                            
02d32970: blr     x9                                         
02d32974: ldr     x8, [x19, #0x10]                           .<>4__this
02d32978: cbz     x8, #0x2d329c0                             
02d3297c: adrp    x19, #0x6267000                            
02d32980: movi    d0, #0000000000000000                      
02d32984: mov     x1, xzr                                    
02d32988: ldr     x19, [x19, #0xbd0]                         MS:MonoSingleton`1::get_Instance
02d3298c: ldr     x0, [x8, #0x38]                            
02d32990: adrp    x8, #0x1084000                             
02d32994: ldr     s1, [x8, #0xf10]                           [1084f10]=4110bc863e99999a f=0.3,9.04603
02d32998: bl      #0x2d98c98                                 DG.Tweening.ShortcutExtensions::DOScale
02d3299c: ldr     x0, [x19]                                  S:'didu'
02d329a0: bl      #0x3769600                                 fn_3769600
02d329a4: cbz     x0, #0x2d329c0                             
02d329a8: adrp    x8, #0x626a000                             
02d329ac: ldr     x8, [x8, #0x7f8]                           MS:UIManager::HidePopup
02d329b0: ldp     x20, x19, [sp, #0x10]                      
02d329b4: ldr     x1, [x8]                                   T:type56879(k15)
02d329b8: ldr     x30, [sp], #0x20                           
02d329bc: b       #0x33fbd34                                 
02d329c0: bl      #0x2b7105c                                 fn_2b7105c
## <ShowAtCenter>b__1() -> void
---- BlindBagCollection.BlindbagCollectionBox/<>c__DisplayClass35_0::<ShowAtCenter>b__1 0x2d329c4
02d329c4: str     x30, [sp, #-0x20]!                         
02d329c8: stp     x20, x19, [sp, #0x10]                      
02d329cc: adrp    x20, #0x6630000                            
02d329d0: mov     x19, x0                                    
02d329d4: ldrb    w8, [x20, #0x108]                          
02d329d8: tbnz    w8, #0, #0x2d329fc                         
02d329dc: adrp    x0, #0x6267000                             
02d329e0: ldr     x0, [x0, #0xbd0]                           MS:MonoSingleton`1::get_Instance
02d329e4: bl      #0x2b70db0                                 fn_2b70db0
02d329e8: adrp    x0, #0x626a000                             
02d329ec: ldr     x0, [x0, #0x7f8]                           MS:UIManager::HidePopup
02d329f0: bl      #0x2b70db0                                 fn_2b70db0
02d329f4: mov     w8, #1                                     
02d329f8: strb    w8, [x20, #0x108]                          
02d329fc: ldr     x0, [x19, #0x10]                           .<>4__this
02d32a00: cbz     x0, #0x2d32a78                             
02d32a04: bl      #0x2d31f7c                                 BlindBagCollection.BlindbagCollectionBox::HideEffect
02d32a08: ldr     x0, [x19, #0x10]                           .<>4__this
02d32a0c: cbz     x0, #0x2d32a78                             
02d32a10: bl      #0x2d3204c                                 BlindBagCollection.BlindbagCollectionBox::FlyToTray
02d32a14: ldr     x8, [x19, #0x18]                           .onDone
02d32a18: cbz     x8, #0x2d32a2c                             
02d32a1c: ldr     x9, [x8, #0x18]                            
02d32a20: ldr     x0, [x8, #0x40]                            
02d32a24: ldr     x1, [x8, #0x28]                            
02d32a28: blr     x9                                         
02d32a2c: ldr     x8, [x19, #0x10]                           .<>4__this
02d32a30: cbz     x8, #0x2d32a78                             
02d32a34: adrp    x19, #0x6267000                            
02d32a38: movi    d0, #0000000000000000                      
02d32a3c: mov     x1, xzr                                    
02d32a40: ldr     x19, [x19, #0xbd0]                         MS:MonoSingleton`1::get_Instance
02d32a44: ldr     x0, [x8, #0x38]                            
02d32a48: adrp    x8, #0x1084000                             
02d32a4c: ldr     s1, [x8, #0xf10]                           [1084f10]=4110bc863e99999a f=0.3,9.04603
02d32a50: bl      #0x2d98c98                                 DG.Tweening.ShortcutExtensions::DOScale
02d32a54: ldr     x0, [x19]                                  S:'didu'
02d32a58: bl      #0x3769600                                 fn_3769600
02d32a5c: cbz     x0, #0x2d32a78                             
02d32a60: adrp    x8, #0x626a000                             
02d32a64: ldr     x8, [x8, #0x7f8]                           MS:UIManager::HidePopup
02d32a68: ldp     x20, x19, [sp, #0x10]                      
02d32a6c: ldr     x1, [x8]                                   T:type56879(k15)
02d32a70: ldr     x30, [sp], #0x20                           
02d32a74: b       #0x33fbd34                                 
02d32a78: bl      #0x2b7105c                                 fn_2b7105c
#### CLASS BlindBagCollection.BlindbagCollectionBox parent= UnityEngine.MonoBehaviour
#   field _srKeycap                      UnityEngine.SpriteRenderer                         off=0x20 attr=1 SerializeField
#   field _tfKeycap                      UnityEngine.Transform                              off=0x28 attr=1 SerializeField
#   field _srPaper                       UnityEngine.SpriteRenderer                         off=0x30 attr=1 SerializeField
#   field _tfPaperPack                   UnityEngine.Transform                              off=0x38 attr=1 SerializeField
#   field _paperCardData                 System.Collections.Generic.List`1<BlindBagCollection.PaperCardData> off=0x40 attr=1 SerializeField
#   field _goLuck                        UnityEngine.GameObject                             off=0x48 attr=1 SerializeField
#   field _collider                      UnityEngine.Collider2D                             off=0x50 attr=1 SerializeField
#   field _sortingGroup                  UnityEngine.Rendering.SortingGroup                 off=0x58 attr=1 SerializeField
#   field _srResult                      UnityEngine.SpriteRenderer                         off=0x60 attr=1 SerializeField
#   field _srGlow                        UnityEngine.SpriteRenderer                         off=0x68 attr=1 SerializeField
#   field _tfGlowEffect                  UnityEngine.Transform                              off=0x70 attr=1 SerializeField
#   field _spineBag                      Spine.Unity.SkeletonAnimation                      off=0x78 attr=1 SerializeField
#   field _blindBoxPlate                 BlindBagCollection.BlindBoxPlate                   off=0x80 attr=1 SerializeField
#   field _screenInGame                  BlindBagCollection.BlindbagGameScreen              off=0x88 attr=1 
#   field _isLuck                        bool                                               off=0x90 attr=1 
#   field _opened                        bool                                               off=0x91 attr=1 
#   field _glowSprite                    UnityEngine.Sprite                                 off=0x98 attr=1 
#   field maxWidth                       float                                              off=0x0 attr=8051 
#   field maxHeight                      float                                              off=0x0 attr=8051 
#   field _timeDoneBGTween               float                                              off=0xa0 attr=1 
#   field _timeDoneGlowTween             float                                              off=0xa4 attr=1 
## get_IsLuck() -> bool
---- BlindBagCollection.BlindbagCollectionBox::get_IsLuck 0x2d31004
02d31004: ldrb    w0, [x0, #0x90]                            ._isLuck
02d31008: ret                                                
## get_Opened() -> bool
---- BlindBagCollection.BlindbagCollectionBox::get_Opened 0x2d3100c
02d3100c: ldrb    w0, [x0, #0x91]                            ._opened
02d31010: ret                                                
## get_GlowSprite() -> UnityEngine.Sprite
---- BlindBagCollection.BlindbagCollectionBox::get_GlowSprite 0x2d31014
02d31014: ldr     x0, [x0, #0x98]                            ._glowSprite
02d31018: ret                                                
## TestAnim() -> void
---- BlindBagCollection.BlindbagCollectionBox::TestAnim 0x2d3101c
02d3101c: str     x30, [sp, #-0x30]!                         
02d31020: stp     x22, x21, [sp, #0x10]                      
02d31024: stp     x20, x19, [sp, #0x20]                      
02d31028: adrp    x20, #0x6630000                            
02d3102c: adrp    x22, #0x626a000                            
02d31030: mov     x19, x0                                    
02d31034: ldrb    w8, [x20, #0xf9]                           
02d31038: ldr     x22, [x22, #0x708]                         T:BlindBagCollection.BlindbagCollectionBox/<>c
02d3103c: tbnz    w8, #0, #0x2d3106c                         
02d31040: adrp    x0, #0x6264000                             
02d31044: ldr     x0, [x0, #0xf90]                           T:System.Action
02d31048: bl      #0x2b70db0                                 fn_2b70db0
02d3104c: adrp    x0, #0x626a000                             
02d31050: ldr     x0, [x0, #0x710]                           M:BlindBagCollection.BlindbagCollectionBox/<>c::<TestAnim>b__23_0
02d31054: bl      #0x2b70db0                                 fn_2b70db0
02d31058: adrp    x0, #0x626a000                             
02d3105c: ldr     x0, [x0, #0x708]                           T:BlindBagCollection.BlindbagCollectionBox/<>c
02d31060: bl      #0x2b70db0                                 fn_2b70db0
02d31064: mov     w8, #1                                     
02d31068: strb    w8, [x20, #0xf9]                           
02d3106c: ldr     x0, [x22]                                  T:type56879(k15)
02d31070: ldr     w8, [x0, #0xe4]                            [626a0e4]=0 f=0,0
02d31074: cbnz    w8, #0x2d31080                             
02d31078: bl      #0x2b70f30                                 fn_2b70f30
02d3107c: ldr     x0, [x22]                                  T:type56879(k15)
02d31080: ldr     x8, [x0, #0xb8]                            MS:UnityEngine.Object::FindObjectsOfType
02d31084: ldr     x20, [x8, #8]                              
02d31088: cbnz    x20, #0x2d310e4                            
02d3108c: ldr     w9, [x0, #0xe4]                            [626a0e4]=0 f=0,0
02d31090: cbnz    w9, #0x2d310a0                             
02d31094: bl      #0x2b70f30                                 fn_2b70f30
02d31098: ldr     x8, [x22]                                  T:type56879(k15)
02d3109c: ldr     x8, [x8, #0xb8]                            
02d310a0: adrp    x9, #0x6264000                             
02d310a4: ldr     x9, [x9, #0xf90]                           T:System.Action
02d310a8: ldr     x21, [x8]                                  
02d310ac: ldr     x0, [x9]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d310b0: bl      #0x2b7104c                                 fn_2b7104c
02d310b4: adrp    x8, #0x626a000                             
02d310b8: mov     x1, x21                                    
02d310bc: mov     x3, xzr                                    
02d310c0: ldr     x8, [x8, #0x710]                           M:BlindBagCollection.BlindbagCollectionBox/<>c::<TestAnim>b__23_0
02d310c4: mov     x20, x0                                    
02d310c8: ldr     x2, [x8]                                   T:type56879(k15)
02d310cc: bl      #0x4d8ddbc                                 System.Action::.ctor
02d310d0: ldr     x8, [x22]                                  T:type56879(k15)
02d310d4: mov     x1, x20                                    
02d310d8: ldr     x0, [x8, #0xb8]                            MS:UnityEngine.Object::FindObjectsOfType
02d310dc: str     x20, [x0, #8]!                             
02d310e0: bl      #0x2b70d54                                 fn_2b70d54
02d310e4: cbz     x19, #0x2d31100                            
02d310e8: mov     x0, x19                                    
02d310ec: mov     x1, x20                                    
02d310f0: ldp     x20, x19, [sp, #0x20]                      
02d310f4: ldp     x22, x21, [sp, #0x10]                      
02d310f8: ldr     x30, [sp], #0x30                           
02d310fc: b       #0x2d31104                                 BlindBagCollection.BlindbagCollectionBox::AnimOpen
02d31100: bl      #0x2b7105c                                 fn_2b7105c
## Start() -> void
---- BlindBagCollection.BlindbagCollectionBox::Start 0x2d3130c
02d3130c: stp     x30, x21, [sp, #-0x20]!                    
02d31310: stp     x20, x19, [sp, #0x10]                      
02d31314: adrp    x20, #0x6630000                            
02d31318: adrp    x21, #0x6267000                            
02d3131c: mov     x19, x0                                    
02d31320: ldrb    w8, [x20, #0xfa]                           
02d31324: ldr     x21, [x21, #0xbd0]                         MS:MonoSingleton`1::get_Instance
02d31328: tbnz    w8, #0, #0x2d3134c                         
02d3132c: adrp    x0, #0x6267000                             
02d31330: ldr     x0, [x0, #0xbd0]                           MS:MonoSingleton`1::get_Instance
02d31334: bl      #0x2b70db0                                 fn_2b70db0
02d31338: adrp    x0, #0x626a000                             
02d3133c: ldr     x0, [x0, #0x728]                           MS:UIManager::GetScreen
02d31340: bl      #0x2b70db0                                 fn_2b70db0
02d31344: mov     w8, #1                                     
02d31348: strb    w8, [x20, #0xfa]                           
02d3134c: ldr     x0, [x21]                                  S:'didu'
02d31350: bl      #0x3769600                                 fn_3769600
02d31354: cbz     x0, #0x2d31380                             
02d31358: adrp    x8, #0x626a000                             
02d3135c: ldr     x8, [x8, #0x728]                           MS:UIManager::GetScreen
02d31360: ldr     x1, [x8]                                   T:type56879(k15)
02d31364: bl      #0x33fbbd0                                 fn_33fbbd0
02d31368: str     x0, [x19, #0x88]!                          ._screenInGame
02d3136c: mov     x1, x0                                     
02d31370: mov     x0, x19                                    
02d31374: ldp     x20, x19, [sp, #0x10]                      
02d31378: ldp     x30, x21, [sp], #0x20                      
02d3137c: b       #0x2b70d54                                 
02d31380: bl      #0x2b7105c                                 fn_2b7105c
## OnPointerDown(UnityEngine.EventSystems.PointerEventData eventData) -> void
---- BlindBagCollection.BlindbagCollectionBox::OnPointerDown 0x2d31384
02d31384: str     x30, [sp, #-0x30]!                         
02d31388: stp     x22, x21, [sp, #0x10]                      
02d3138c: stp     x20, x19, [sp, #0x20]                      
02d31390: adrp    x20, #0x6630000                            
02d31394: adrp    x21, #0x6266000                            
02d31398: mov     x19, x0                                    
02d3139c: ldrb    w8, [x20, #0xfb]                           
02d313a0: ldr     x21, [x21, #0x948]                         T:Touch
02d313a4: tbnz    w8, #0, #0x2d313ec                         
02d313a8: adrp    x0, #0x6264000                             
02d313ac: ldr     x0, [x0, #0xf90]                           T:System.Action
02d313b0: bl      #0x2b70db0                                 fn_2b70db0
02d313b4: adrp    x0, #0x626a000                             
02d313b8: ldr     x0, [x0, #0x730]                           MS:MonoSingleton`1::get_Instance
02d313bc: bl      #0x2b70db0                                 fn_2b70db0
02d313c0: adrp    x0, #0x6266000                             
02d313c4: ldr     x0, [x0, #0x948]                           T:Touch
02d313c8: bl      #0x2b70db0                                 fn_2b70db0
02d313cc: adrp    x0, #0x626a000                             
02d313d0: ldr     x0, [x0, #0x738]                           M:BlindBagCollection.BlindbagCollectionBox/<>c::<OnPointerDown>b__25_0
02d313d4: bl      #0x2b70db0                                 fn_2b70db0
02d313d8: adrp    x0, #0x626a000                             
02d313dc: ldr     x0, [x0, #0x708]                           T:BlindBagCollection.BlindbagCollectionBox/<>c
02d313e0: bl      #0x2b70db0                                 fn_2b70db0
02d313e4: mov     w8, #1                                     
02d313e8: strb    w8, [x20, #0xfb]                           
02d313ec: ldr     x0, [x21]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d313f0: ldr     w8, [x0, #0xe4]                            [626a0e4]=0 f=0,0
02d313f4: cbnz    w8, #0x2d313fc                             
02d313f8: bl      #0x2b70f30                                 fn_2b70f30
02d313fc: mov     x0, xzr                                    
02d31400: bl      #0x2cd6230                                 Touch::IsPointerOverUIObject
02d31404: tbz     w0, #0, #0x2d31418                         
02d31408: ldp     x20, x19, [sp, #0x20]                      
02d3140c: ldp     x22, x21, [sp, #0x10]                      
02d31410: ldr     x30, [sp], #0x30                           
02d31414: ret                                                
02d31418: adrp    x20, #0x626a000                            
02d3141c: mov     x0, x19                                    
02d31420: ldr     x20, [x20, #0x730]                         MS:MonoSingleton`1::get_Instance
02d31424: bl      #0x2d314e4                                 BlindBagCollection.BlindbagCollectionBox::DisableClick
02d31428: ldr     x0, [x20]                                  T:type56879(k15)
02d3142c: bl      #0x3769600                                 fn_3769600
02d31430: cbz     x0, #0x2d314e0                             
02d31434: mov     x1, xzr                                    
02d31438: mov     w2, wzr                                    
02d3143c: mov     x3, xzr                                    
02d31440: bl      #0x2d5699c                                 Blindbag.TutorialBlindBag::ShowTutorialUnbox
02d31444: adrp    x22, #0x626a000                            
02d31448: ldr     x22, [x22, #0x708]                         T:BlindBagCollection.BlindbagCollectionBox/<>c
02d3144c: ldr     x0, [x22]                                  T:type56879(k15)
02d31450: ldr     w8, [x0, #0xe4]                            [626a0e4]=0 f=0,0
02d31454: cbnz    w8, #0x2d31460                             
02d31458: bl      #0x2b70f30                                 fn_2b70f30
02d3145c: ldr     x0, [x22]                                  T:type56879(k15)
02d31460: ldr     x8, [x0, #0xb8]                            MS:UnityEngine.Object::FindObjectsOfType
02d31464: ldr     x20, [x8, #0x10]                           
02d31468: cbnz    x20, #0x2d314c4                            
02d3146c: ldr     w9, [x0, #0xe4]                            [626a0e4]=0 f=0,0
02d31470: cbnz    w9, #0x2d31480                             
02d31474: bl      #0x2b70f30                                 fn_2b70f30
02d31478: ldr     x8, [x22]                                  T:type56879(k15)
02d3147c: ldr     x8, [x8, #0xb8]                            
02d31480: adrp    x9, #0x6264000                             
02d31484: ldr     x9, [x9, #0xf90]                           T:System.Action
02d31488: ldr     x21, [x8]                                  
02d3148c: ldr     x0, [x9]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d31490: bl      #0x2b7104c                                 fn_2b7104c
02d31494: adrp    x8, #0x626a000                             
02d31498: mov     x1, x21                                    
02d3149c: mov     x3, xzr                                    
02d314a0: ldr     x8, [x8, #0x738]                           M:BlindBagCollection.BlindbagCollectionBox/<>c::<OnPointerDown>b__25_0
02d314a4: mov     x20, x0                                    
02d314a8: ldr     x2, [x8]                                   T:type56879(k15)
02d314ac: bl      #0x4d8ddbc                                 System.Action::.ctor
02d314b0: ldr     x8, [x22]                                  T:type56879(k15)
02d314b4: mov     x1, x20                                    
02d314b8: ldr     x0, [x8, #0xb8]                            MS:UnityEngine.Object::FindObjectsOfType
02d314bc: str     x20, [x0, #0x10]!                          
02d314c0: bl      #0x2b70d54                                 fn_2b70d54
02d314c4: cbz     x19, #0x2d314e0                            
02d314c8: mov     x0, x19                                    
02d314cc: mov     x1, x20                                    
02d314d0: ldp     x20, x19, [sp, #0x20]                      
02d314d4: ldp     x22, x21, [sp, #0x10]                      
02d314d8: ldr     x30, [sp], #0x30                           
02d314dc: b       #0x2d31104                                 BlindBagCollection.BlindbagCollectionBox::AnimOpen
02d314e0: bl      #0x2b7105c                                 fn_2b7105c
## SetSkinBag(string skinName) -> void
---- BlindBagCollection.BlindbagCollectionBox::SetSkinBag 0x2d31500
02d31500: str     x30, [sp, #-0x20]!                         
02d31504: stp     x20, x19, [sp, #0x10]                      
02d31508: mov     x19, x0                                    
02d3150c: ldr     x0, [x0, #0x78]                            ._spineBag
02d31510: cbz     x0, #0x2d31590                             
02d31514: mov     x20, x1                                    
02d31518: mov     x1, xzr                                    
02d3151c: bl      #0x5002600                                 Spine.Unity.SkeletonRenderer::get_Skeleton
02d31520: cbz     x0, #0x2d31590                             
02d31524: mov     x1, x20                                    
02d31528: mov     x2, xzr                                    
02d3152c: bl      #0x4fa9b14                                 Spine.Skeleton::SetSkin
02d31530: ldr     x0, [x19, #0x78]                           ._spineBag
02d31534: cbz     x0, #0x2d31590                             
02d31538: mov     x1, xzr                                    
02d3153c: bl      #0x5002600                                 Spine.Unity.SkeletonRenderer::get_Skeleton
02d31540: cbz     x0, #0x2d31590                             
02d31544: mov     x1, xzr                                    
02d31548: bl      #0x4fa9890                                 Spine.Skeleton::SetSlotsToSetupPose
02d3154c: ldr     x0, [x19, #0x78]                           ._spineBag
02d31550: cbz     x0, #0x2d31590                             
02d31554: mov     x1, xzr                                    
02d31558: bl      #0x4ff6f18                                 Spine.Unity.SkeletonAnimation::get_AnimationState
02d3155c: ldr     x8, [x19, #0x78]                           ._spineBag
02d31560: cbz     x8, #0x2d31590                             
02d31564: mov     x19, x0                                    
02d31568: mov     x0, x8                                     
02d3156c: mov     x1, xzr                                    
02d31570: bl      #0x5002600                                 Spine.Unity.SkeletonRenderer::get_Skeleton
02d31574: cbz     x19, #0x2d31590                            
02d31578: mov     x1, x0                                     
02d3157c: mov     x0, x19                                    
02d31580: mov     x2, xzr                                    
02d31584: ldp     x20, x19, [sp, #0x10]                      
02d31588: ldr     x30, [sp], #0x20                           
02d3158c: b       #0x4f95698                                 Spine.AnimationState::Apply
02d31590: bl      #0x2b7105c                                 fn_2b7105c
## SetData(UnityEngine.Sprite sprite, bool isLuck, RarityType rarityType) -> void
---- BlindBagCollection.BlindbagCollectionBox::SetData 0x2d31594
02d31594: sub     sp, sp, #0xa0                              
02d31598: str     d10, [sp, #0x30]                           
02d3159c: stp     d9, d8, [sp, #0x38]                        
02d315a0: str     x30, [sp, #0x48]                           
02d315a4: stp     x28, x27, [sp, #0x50]                      
02d315a8: stp     x26, x25, [sp, #0x60]                      
02d315ac: stp     x24, x23, [sp, #0x70]                      
02d315b0: stp     x22, x21, [sp, #0x80]                      
02d315b4: stp     x20, x19, [sp, #0x90]                      
02d315b8: adrp    x21, #0x6630000                            
02d315bc: adrp    x24, #0x626a000                            
02d315c0: mov     w23, w3                                    
02d315c4: ldrb    w8, [x21, #0xfc]                           
02d315c8: ldr     x24, [x24, #0x740]                         T:BlindBagCollection.BlindbagCollectionBox/<>c__DisplayClass29_0
02d315cc: mov     w20, w2                                    
02d315d0: mov     x22, x1                                    
02d315d4: mov     x19, x0                                    
02d315d8: tbnz    w8, #0, #0x2d31650                         
02d315dc: adrp    x0, #0x6263000                             
02d315e0: ldr     x0, [x0, #0x928]                           T:UnityEngine.Debug
02d315e4: bl      #0x2b70db0                                 fn_2b70db0
02d315e8: adrp    x0, #0x626a000                             
02d315ec: ldr     x0, [x0, #0x748]                           MS:System.Collections.Generic.List`1::Find
02d315f0: bl      #0x2b70db0                                 fn_2b70db0
02d315f4: adrp    x0, #0x626a000                             
02d315f8: ldr     x0, [x0, #0x750]                           MS:System.Collections.Generic.List`1::get_Item
02d315fc: bl      #0x2b70db0                                 fn_2b70db0
02d31600: adrp    x0, #0x626a000                             
02d31604: ldr     x0, [x0, #0x758]                           T:type57268(k15)
02d31608: bl      #0x2b70db0                                 fn_2b70db0
02d3160c: adrp    x0, #0x626a000                             
02d31610: ldr     x0, [x0, #0x760]                           T:type24618(k1d)
02d31614: bl      #0x2b70db0                                 fn_2b70db0
02d31618: adrp    x0, #0x626a000                             
02d3161c: ldr     x0, [x0, #0x768]                           M:BlindBagCollection.BlindbagCollectionBox/<>c__DisplayClass29_0::<SetData>b__0
02d31620: bl      #0x2b70db0                                 fn_2b70db0
02d31624: adrp    x0, #0x626a000                             
02d31628: ldr     x0, [x0, #0x740]                           T:BlindBagCollection.BlindbagCollectionBox/<>c__DisplayClass29_0
02d3162c: bl      #0x2b70db0                                 fn_2b70db0
02d31630: adrp    x0, #0x626a000                             
02d31634: ldr     x0, [x0, #0x770]                           S:'sprite name {0} have size {1}:{2}'
02d31638: bl      #0x2b70db0                                 fn_2b70db0
02d3163c: adrp    x0, #0x626a000                             
02d31640: ldr     x0, [x0, #0x778]                           S:'sprite name {0} after edited have size {1}:{2}'
02d31644: bl      #0x2b70db0                                 fn_2b70db0
02d31648: mov     w8, #1                                     
02d3164c: strb    w8, [x21, #0xfc]                           
02d31650: ldr     x0, [x24]                                  T:type56879(k15)
02d31654: bl      #0x2b7104c                                 fn_2b7104c
02d31658: mov     x1, xzr                                    
02d3165c: mov     x21, x0                                    
02d31660: bl      #0x4e53e9c                                 System.Object::.ctor
02d31664: cbz     x21, #0x2d31984                            
02d31668: str     w23, [x21, #0x10]                          
02d3166c: ldr     x0, [x19, #0x20]                           ._srKeycap
02d31670: cbz     x0, #0x2d31984                             
02d31674: mov     x1, x22                                    
02d31678: mov     x2, xzr                                    
02d3167c: bl      #0x5ae6dcc                                 UnityEngine.SpriteRenderer::set_sprite
02d31680: adrp    x24, #0x662f000                            
02d31684: ldr     x23, [x19, #0x28]                          ._tfKeycap
02d31688: ldrb    w8, [x24, #0xa74]                          
02d3168c: cbnz    w8, #0x2d316a4                             
02d31690: adrp    x0, #0x6264000                             
02d31694: ldr     x0, [x0, #0xd8]                            T:UnityEngine.Vector3
02d31698: bl      #0x2b70db0                                 fn_2b70db0
02d3169c: mov     w8, #1                                     
02d316a0: strb    w8, [x24, #0xa74]                          
02d316a4: cbz     x23, #0x2d31984                            
02d316a8: adrp    x8, #0x6264000                             
02d316ac: mov     x0, x23                                    
02d316b0: mov     x1, xzr                                    
02d316b4: ldr     x8, [x8, #0xd8]                            T:UnityEngine.Vector3
02d316b8: ldr     x8, [x8]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d316bc: ldr     x8, [x8, #0xb8]                            MS:DG.Tweening.Core.Extensions::SetSpecialStartupMode
02d316c0: ldp     s1, s2, [x8, #0x10]                        
02d316c4: ldr     s0, [x8, #0xc]                             [626400c]=0 f=0,0
02d316c8: bl      #0x5b470cc                                 UnityEngine.Transform::set_localScale
02d316cc: ldr     x0, [x19, #0x20]                           ._srKeycap
02d316d0: cbz     x0, #0x2d31984                             
02d316d4: add     x8, sp, #0x18                              
02d316d8: mov     x1, xzr                                    
02d316dc: bl      #0x5b02028                                 UnityEngine.Renderer::get_bounds
02d316e0: cbz     x22, #0x2d31984                            
02d316e4: ldp     s0, s1, [sp, #0x24]                        
02d316e8: adrp    x27, #0x626a000                            
02d316ec: adrp    x28, #0x6263000                            
02d316f0: adrp    x26, #0x626a000                            
02d316f4: ldr     x27, [x27, #0x770]                         S:'sprite name {0} have size {1}:{2}'
02d316f8: ldr     x28, [x28, #0x928]                         T:UnityEngine.Debug
02d316fc: ldr     x26, [x26, #0x760]                         T:type24618(k1d)
02d31700: mov     x0, x22                                    
02d31704: mov     x1, xzr                                    
02d31708: fadd    s9, s0, s0                                 
02d3170c: fadd    s8, s1, s1                                 
02d31710: bl      #0x5b3bba4                                 UnityEngine.Object::get_name
02d31714: adrp    x25, #0x6263000                            
02d31718: mov     x23, x0                                    
02d3171c: add     x1, sp, #0x18                              
02d31720: ldr     x25, [x25, #0x970]                         &6645c70(=0)
02d31724: str     s9, [sp, #0x18]                            
02d31728: ldr     x0, [x25, #0x78]                           &2c498b4(=d65f03c0d503245f)
02d3172c: bl      #0x2b70f38                                 fn_2b70f38
02d31730: mov     x24, x0                                    
02d31734: ldr     x0, [x25, #0x78]                           &2c498b4(=d65f03c0d503245f)
02d31738: add     x1, sp, #0x14                              
02d3173c: str     s8, [sp, #0x14]                            
02d31740: bl      #0x2b70f38                                 fn_2b70f38
02d31744: ldr     x8, [x27]                                  T:type56879(k15)
02d31748: mov     x3, x0                                     
02d3174c: mov     x1, x23                                    
02d31750: mov     x2, x24                                    
02d31754: mov     x4, xzr                                    
02d31758: mov     x0, x8                                     
02d3175c: bl      #0x4ca7764                                 System.String::Format
02d31760: ldr     x8, [x28]                                  &2c5bbd4(=a9bd7bfdd503233f)
02d31764: mov     x23, x0                                    
02d31768: ldr     w9, [x8, #0xe4]                            [62640e4]=0 f=0,0
02d3176c: cbnz    w9, #0x2d31778                             
02d31770: mov     x0, x8                                     
02d31774: bl      #0x2b70f30                                 fn_2b70f30
02d31778: mov     x0, x23                                    
02d3177c: mov     x1, xzr                                    
02d31780: bl      #0x5af21f4                                 UnityEngine.Debug::Log
02d31784: ldr     x0, [x26]                                  T:type56879(k15)
02d31788: mov     w1, #3                                     
02d3178c: bl      #0x2b70ea0                                 fn_2b70ea0
02d31790: cbz     x0, #0x2d31984                             
02d31794: ldr     x8, [x0, #0x18]                            M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass2_0::<DOSetFloat>b__1
02d31798: cbz     w8, #0x2d31988                             
02d3179c: mov     w9, #0x3f800000                            
02d317a0: cmp     w8, #1                                     
02d317a4: str     w9, [x0, #0x20]                            ._srKeycap
02d317a8: b.eq    #0x2d31988                                 
02d317ac: fmov    s0, #2.00000000                            
02d317b0: cmp     w8, #2                                     
02d317b4: fdiv    s1, s0, s9                                 
02d317b8: str     s1, [x0, #0x24]                            
02d317bc: b.ls    #0x2d31988                                 
02d317c0: fdiv    s0, s0, s8                                 
02d317c4: fmov    s10, #1.00000000                           
02d317c8: adrp    x24, #0x626a000                            
02d317cc: ldr     x24, [x24, #0x778]                         S:'sprite name {0} after edited have size {1}:{2}'
02d317d0: str     s0, [x0, #0x28]                            ._tfKeycap
02d317d4: b.lt    #0x2d317f8                                 
02d317d8: and     x8, x8, #0xffffffff                        
02d317dc: add     x9, x0, #0x24                              &6264024
02d317e0: sub     x8, x8, #1                                 
02d317e4: ldr     s0, [x9], #4                               
02d317e8: fcmp    s0, s10                                    
02d317ec: fcsel   s10, s0, s10, mi                           
02d317f0: subs    x8, x8, #1                                 
02d317f4: b.ne    #0x2d317e4                                 
02d317f8: mov     x0, x22                                    
02d317fc: mov     x1, xzr                                    
02d31800: bl      #0x5b3bba4                                 UnityEngine.Object::get_name
02d31804: mov     x22, x0                                    
02d31808: ldr     x0, [x25, #0x78]                           &2c498b4(=d65f03c0d503245f)
02d3180c: add     x1, sp, #0x10                              
02d31810: str     s9, [sp, #0x10]                            
02d31814: bl      #0x2b70f38                                 fn_2b70f38
02d31818: mov     x23, x0                                    
02d3181c: ldr     x0, [x25, #0x78]                           &2c498b4(=d65f03c0d503245f)
02d31820: add     x1, sp, #0xc                               
02d31824: str     s8, [sp, #0xc]                             
02d31828: bl      #0x2b70f38                                 fn_2b70f38
02d3182c: ldr     x8, [x24]                                  T:type56879(k15)
02d31830: mov     x3, x0                                     
02d31834: mov     x1, x22                                    
02d31838: mov     x2, x23                                    
02d3183c: mov     x4, xzr                                    
02d31840: mov     x0, x8                                     
02d31844: bl      #0x4ca7764                                 System.String::Format
02d31848: mov     x1, xzr                                    
02d3184c: bl      #0x5af21f4                                 UnityEngine.Debug::Log
02d31850: ldr     x22, [x19, #0x28]                          ._tfKeycap
02d31854: cbz     x22, #0x2d31984                            
02d31858: mov     x0, x22                                    
02d3185c: mov     x1, xzr                                    
02d31860: and     w23, w20, #1                               
02d31864: bl      #0x5b46ff0                                 UnityEngine.Transform::get_localScale
02d31868: fmul    s0, s10, s0                                
02d3186c: fmul    s1, s10, s1                                
02d31870: mov     x0, x22                                    
02d31874: fmul    s2, s10, s2                                
02d31878: mov     x1, xzr                                    
02d3187c: bl      #0x5b470cc                                 UnityEngine.Transform::set_localScale
02d31880: ldr     x0, [x19, #0x48]                           ._goLuck
02d31884: strb    w23, [x19, #0x90]                          ._isLuck
02d31888: cbz     x0, #0x2d31984                             
02d3188c: adrp    x22, #0x626a000                            
02d31890: adrp    x23, #0x626a000                            
02d31894: and     w1, w20, #1                                
02d31898: ldr     x22, [x22, #0x758]                         T:type57268(k15)
02d3189c: ldr     x23, [x23, #0x768]                         M:BlindBagCollection.BlindbagCollectionBox/<>c__DisplayClass29_0::<SetData>b__0
02d318a0: mov     x2, xzr                                    
02d318a4: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d318a8: ldr     x0, [x22]                                  T:type56879(k15)
02d318ac: ldr     x20, [x19, #0x40]                          ._paperCardData
02d318b0: bl      #0x2b7104c                                 fn_2b7104c
02d318b4: ldr     x2, [x23]                                  T:type56879(k15)
02d318b8: mov     x1, x21                                    
02d318bc: mov     x3, xzr                                    
02d318c0: mov     x22, x0                                    
02d318c4: bl      #0x399ba10                                 fn_399ba10
02d318c8: cbz     x20, #0x2d31984                            
02d318cc: adrp    x8, #0x626a000                             
02d318d0: mov     x0, x20                                    
02d318d4: mov     x1, x22                                    
02d318d8: ldr     x8, [x8, #0x748]                           MS:System.Collections.Generic.List`1::Find
02d318dc: ldr     x2, [x8]                                   T:type56879(k15)
02d318e0: bl      #0x35a9868                                 fn_35a9868
02d318e4: mov     x20, x0                                    
02d318e8: ldr     x0, [x19, #0x30]                           ._srPaper
02d318ec: cbz     x20, #0x2d3191c                            
02d318f0: movi    d1, #0000000000000000                      
02d318f4: fmov    s0, #1.00000000                            
02d318f8: mov     x1, xzr                                    
02d318fc: bl      #0x2c77d0c                                 DG.Tweening.DOTweenModuleSprite::DOFade
02d31900: ldr     x0, [x19, #0x30]                           ._srPaper
02d31904: cbz     x0, #0x2d31984                             
02d31908: ldr     x1, [x20, #0x18]                           
02d3190c: mov     x2, xzr                                    
02d31910: bl      #0x5ae6dcc                                 UnityEngine.SpriteRenderer::set_sprite
02d31914: ldr     x1, [x20, #0x20]                           ._srKeycap
02d31918: b       #0x2d31950                                 
02d3191c: movi    d0, #0000000000000000                      
02d31920: movi    d1, #0000000000000000                      
02d31924: mov     x1, xzr                                    
02d31928: bl      #0x2c77d0c                                 DG.Tweening.DOTweenModuleSprite::DOFade
02d3192c: ldr     x0, [x19, #0x40]                           ._paperCardData
02d31930: cbz     x0, #0x2d31984                             
02d31934: adrp    x8, #0x626a000                             
02d31938: mov     w1, wzr                                    
02d3193c: ldr     x8, [x8, #0x750]                           MS:System.Collections.Generic.List`1::get_Item
02d31940: ldr     x2, [x8]                                   T:type56879(k15)
02d31944: bl      #0x35a8f3c                                 fn_35a8f3c
02d31948: cbz     x0, #0x2d31984                             
02d3194c: ldr     x1, [x0, #0x20]                            T:DG.Tweening.DOTweenModulePhysics/<>c__DisplayClass0_0 ._srKeycap
02d31950: str     x1, [x19, #0x98]!                          ._glowSprite
02d31954: mov     x0, x19                                    
02d31958: bl      #0x2b70d54                                 fn_2b70d54
02d3195c: ldp     x20, x19, [sp, #0x90]                      
02d31960: ldr     x30, [sp, #0x48]                           
02d31964: ldp     x22, x21, [sp, #0x80]                      
02d31968: ldr     d10, [sp, #0x30]                           
02d3196c: ldp     x24, x23, [sp, #0x70]                      
02d31970: ldp     x26, x25, [sp, #0x60]                      
02d31974: ldp     x28, x27, [sp, #0x50]                      
02d31978: ldp     d9, d8, [sp, #0x38]                        
02d3197c: add     sp, sp, #0xa0                              
02d31980: ret                                                
02d31984: bl      #0x2b7105c                                 fn_2b7105c
02d31988: bl      #0x2b71064                                 fn_2b71064
## AnimOpen(System.Action onComplete) -> void
---- BlindBagCollection.BlindbagCollectionBox::AnimOpen 0x2d31104
02d31104: str     d8, [sp, #-0x40]!                          
02d31108: str     x30, [sp, #8]                              
02d3110c: stp     x24, x23, [sp, #0x10]                      
02d31110: stp     x22, x21, [sp, #0x20]                      
02d31114: stp     x20, x19, [sp, #0x30]                      
02d31118: adrp    x19, #0x6630000                            
02d3111c: adrp    x22, #0x626a000                            
02d31120: mov     x21, x1                                    
02d31124: ldrb    w8, [x19, #0xfd]                           
02d31128: ldr     x22, [x22, #0x718]                         T:BlindBagCollection.BlindbagCollectionBox/<>c__DisplayClass32_0
02d3112c: mov     x20, x0                                    
02d31130: tbnz    w8, #0, #0x2d3116c                         
02d31134: adrp    x0, #0x6264000                             
02d31138: ldr     x0, [x0, #0xe8]                            T:DG.Tweening.TweenCallback
02d3113c: bl      #0x2b70db0                                 fn_2b70db0
02d31140: adrp    x0, #0x6267000                             
02d31144: ldr     x0, [x0, #0xd30]                           MS:DG.Tweening.TweenSettingsExtensions::OnComplete
02d31148: bl      #0x2b70db0                                 fn_2b70db0
02d3114c: adrp    x0, #0x626a000                             
02d31150: ldr     x0, [x0, #0x720]                           M:BlindBagCollection.BlindbagCollectionBox/<>c__DisplayClass32_0::<AnimOpen>b__0
02d31154: bl      #0x2b70db0                                 fn_2b70db0
02d31158: adrp    x0, #0x626a000                             
02d3115c: ldr     x0, [x0, #0x718]                           T:BlindBagCollection.BlindbagCollectionBox/<>c__DisplayClass32_0
02d31160: bl      #0x2b70db0                                 fn_2b70db0
02d31164: mov     w8, #1                                     
02d31168: strb    w8, [x19, #0xfd]                           
02d3116c: ldr     x0, [x22]                                  T:type56879(k15)
02d31170: bl      #0x2b7104c                                 fn_2b7104c
02d31174: mov     x1, xzr                                    
02d31178: mov     x19, x0                                    
02d3117c: bl      #0x4e53e9c                                 System.Object::.ctor
02d31180: cbz     x19, #0x2d31308                            
02d31184: mov     x0, x19                                    
02d31188: mov     x1, x20                                    
02d3118c: str     x20, [x0, #0x10]!                          
02d31190: bl      #0x2b70d54                                 fn_2b70d54
02d31194: mov     x0, x19                                    
02d31198: mov     x1, x21                                    
02d3119c: str     x21, [x0, #0x18]!                          
02d311a0: bl      #0x2b70d54                                 fn_2b70d54
02d311a4: ldr     x0, [x20, #0x58]                           ._sortingGroup
02d311a8: cbz     x0, #0x2d31308                             
02d311ac: adrp    x23, #0x6264000                            
02d311b0: adrp    x21, #0x626a000                            
02d311b4: adrp    x22, #0x6267000                            
02d311b8: ldr     x23, [x23, #0xe8]                          T:DG.Tweening.TweenCallback
02d311bc: ldr     x21, [x21, #0x720]                         M:BlindBagCollection.BlindbagCollectionBox/<>c__DisplayClass32_0::<AnimOpen>b__0
02d311c0: ldr     x22, [x22, #0xd30]                         MS:DG.Tweening.TweenSettingsExtensions::OnComplete
02d311c4: mov     w1, #6                                     
02d311c8: mov     x2, xzr                                    
02d311cc: bl      #0x5b54884                                 UnityEngine.Rendering.SortingGroup::set_sortingOrder
02d311d0: mov     x0, xzr                                    
02d311d4: bl      #0x5b432fc                                 UnityEngine.Time::get_time
02d311d8: fmov    s8, #2.00000000                            
02d311dc: mov     x0, xzr                                    
02d311e0: fadd    s0, s0, s8                                 
02d311e4: str     s0, [x20, #0xa0]                           ._timeDoneBGTween
02d311e8: bl      #0x5b432fc                                 UnityEngine.Time::get_time
02d311ec: fadd    s0, s0, s8                                 
02d311f0: ldr     x0, [x20, #0x60]                           ._srResult
02d311f4: mov     w1, wzr                                    
02d311f8: mov     x2, xzr                                    
02d311fc: str     s0, [x20, #0xa4]                           ._timeDoneGlowTween
02d31200: bl      #0x2d9d5d0                                 DG.Tweening.ShortcutExtensions::DOKill
02d31204: adrp    x8, #0x1084000                             
02d31208: adrp    x9, #0x1084000                             
02d3120c: ldr     x0, [x20, #0x60]                           ._srResult
02d31210: ldr     s0, [x8, #0xddc]                           [1084ddc]=c77fe0003f733333 f=0.95,-65504
02d31214: ldr     s1, [x9, #0xf10]                           [1084f10]=4110bc863e99999a f=0.3,9.04603
02d31218: mov     x1, xzr                                    
02d3121c: bl      #0x2c77d0c                                 DG.Tweening.DOTweenModuleSprite::DOFade
02d31220: mov     x0, x20                                    
02d31224: mov     x1, xzr                                    
02d31228: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02d3122c: movi    d0, #0000000000000000                      
02d31230: fmov    s1, #-1.50000000                           
02d31234: mov     w1, wzr                                    
02d31238: fmov    s2, #-5.00000000                           
02d3123c: fmov    s3, #0.50000000                            
02d31240: mov     x2, xzr                                    
02d31244: bl      #0x2d975e4                                 DG.Tweening.ShortcutExtensions::DOMove
02d31248: mov     x0, x20                                    
02d3124c: mov     x1, xzr                                    
02d31250: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02d31254: fmov    s0, #1.50000000                            
02d31258: fmov    s1, #0.50000000                            
02d3125c: mov     x1, xzr                                    
02d31260: bl      #0x2d98c98                                 DG.Tweening.ShortcutExtensions::DOScale
02d31264: mov     x0, x20                                    
02d31268: mov     x1, xzr                                    
02d3126c: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02d31270: adrp    x24, #0x662f000                            
02d31274: mov     x20, x0                                    
02d31278: ldrb    w8, [x24, #0x91a]                          
02d3127c: cbnz    w8, #0x2d31294                             
02d31280: adrp    x0, #0x6264000                             
02d31284: ldr     x0, [x0, #0xd8]                            T:UnityEngine.Vector3
02d31288: bl      #0x2b70db0                                 fn_2b70db0
02d3128c: mov     w8, #1                                     
02d31290: strb    w8, [x24, #0x91a]                          
02d31294: adrp    x8, #0x6264000                             
02d31298: fmov    s3, #0.50000000                            
02d3129c: mov     x0, x20                                    
02d312a0: ldr     x8, [x8, #0xd8]                            T:UnityEngine.Vector3
02d312a4: mov     w1, wzr                                    
02d312a8: mov     x2, xzr                                    
02d312ac: ldr     x8, [x8]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d312b0: ldr     x8, [x8, #0xb8]                            MS:DG.Tweening.Core.Extensions::SetSpecialStartupMode
02d312b4: ldp     s0, s1, [x8]                               
02d312b8: ldr     s2, [x8, #8]                               T:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass2_0
02d312bc: bl      #0x2d983c8                                 DG.Tweening.ShortcutExtensions::DORotate
02d312c0: ldr     x8, [x23]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d312c4: mov     x20, x0                                    
02d312c8: mov     x0, x8                                     
02d312cc: bl      #0x2b7104c                                 fn_2b7104c
02d312d0: ldr     x2, [x21]                                  T:type56879(k15)
02d312d4: mov     x1, x19                                    
02d312d8: mov     x3, xzr                                    
02d312dc: mov     x21, x0                                    
02d312e0: bl      #0x2d89dc4                                 DG.Tweening.TweenCallback::.ctor
02d312e4: ldr     x2, [x22]                                  S:'didu'
02d312e8: mov     x0, x20                                    
02d312ec: mov     x1, x21                                    
02d312f0: ldp     x20, x19, [sp, #0x30]                      
02d312f4: ldr     x30, [sp, #8]                              
02d312f8: ldp     x22, x21, [sp, #0x20]                      
02d312fc: ldp     x24, x23, [sp, #0x10]                      
02d31300: ldr     d8, [sp], #0x40                            
02d31304: b       #0x336f26c                                 
02d31308: bl      #0x2b7105c                                 fn_2b7105c
## AnimFade() -> void
---- BlindBagCollection.BlindbagCollectionBox::AnimFade 0x2d3199c
02d3199c: str     x30, [sp, #-0x30]!                         
02d319a0: stp     x22, x21, [sp, #0x10]                      
02d319a4: stp     x20, x19, [sp, #0x20]                      
02d319a8: adrp    x20, #0x6630000                            
02d319ac: adrp    x22, #0x626a000                            
02d319b0: mov     x19, x0                                    
02d319b4: ldrb    w8, [x20, #0xfe]                           
02d319b8: ldr     x22, [x22, #0x708]                         T:BlindBagCollection.BlindbagCollectionBox/<>c
02d319bc: tbnz    w8, #0, #0x2d319ec                         
02d319c0: adrp    x0, #0x6264000                             
02d319c4: ldr     x0, [x0, #0xf90]                           T:System.Action
02d319c8: bl      #0x2b70db0                                 fn_2b70db0
02d319cc: adrp    x0, #0x626a000                             
02d319d0: ldr     x0, [x0, #0x780]                           M:BlindBagCollection.BlindbagCollectionBox/<>c::<AnimFade>b__33_0
02d319d4: bl      #0x2b70db0                                 fn_2b70db0
02d319d8: adrp    x0, #0x626a000                             
02d319dc: ldr     x0, [x0, #0x708]                           T:BlindBagCollection.BlindbagCollectionBox/<>c
02d319e0: bl      #0x2b70db0                                 fn_2b70db0
02d319e4: mov     w8, #1                                     
02d319e8: strb    w8, [x20, #0xfe]                           
02d319ec: ldr     x0, [x22]                                  T:type56879(k15)
02d319f0: ldr     w8, [x0, #0xe4]                            [626a0e4]=0 f=0,0
02d319f4: cbnz    w8, #0x2d31a00                             
02d319f8: bl      #0x2b70f30                                 fn_2b70f30
02d319fc: ldr     x0, [x22]                                  T:type56879(k15)
02d31a00: ldr     x8, [x0, #0xb8]                            MS:UnityEngine.Object::FindObjectsOfType
02d31a04: ldr     x20, [x8, #0x18]                           
02d31a08: cbnz    x20, #0x2d31a64                            
02d31a0c: ldr     w9, [x0, #0xe4]                            [626a0e4]=0 f=0,0
02d31a10: cbnz    w9, #0x2d31a20                             
02d31a14: bl      #0x2b70f30                                 fn_2b70f30
02d31a18: ldr     x8, [x22]                                  T:type56879(k15)
02d31a1c: ldr     x8, [x8, #0xb8]                            
02d31a20: adrp    x9, #0x6264000                             
02d31a24: ldr     x9, [x9, #0xf90]                           T:System.Action
02d31a28: ldr     x21, [x8]                                  
02d31a2c: ldr     x0, [x9]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d31a30: bl      #0x2b7104c                                 fn_2b7104c
02d31a34: adrp    x8, #0x626a000                             
02d31a38: mov     x1, x21                                    
02d31a3c: mov     x3, xzr                                    
02d31a40: ldr     x8, [x8, #0x780]                           M:BlindBagCollection.BlindbagCollectionBox/<>c::<AnimFade>b__33_0
02d31a44: mov     x20, x0                                    
02d31a48: ldr     x2, [x8]                                   T:type56879(k15)
02d31a4c: bl      #0x4d8ddbc                                 System.Action::.ctor
02d31a50: ldr     x8, [x22]                                  T:type56879(k15)
02d31a54: mov     x1, x20                                    
02d31a58: ldr     x0, [x8, #0xb8]                            MS:UnityEngine.Object::FindObjectsOfType
02d31a5c: str     x20, [x0, #0x18]!                          
02d31a60: bl      #0x2b70d54                                 fn_2b70d54
02d31a64: cbz     x19, #0x2d31a84                            
02d31a68: mov     x0, x19                                    
02d31a6c: mov     x1, x20                                    
02d31a70: fmov    s0, #0.25000000                            
02d31a74: ldp     x20, x19, [sp, #0x20]                      
02d31a78: ldp     x22, x21, [sp, #0x10]                      
02d31a7c: ldr     x30, [sp], #0x30                           
02d31a80: b       #0x2d31a88                                 BlindBagCollection.BlindbagCollectionBox::FadeOutSpine
02d31a84: bl      #0x2b7105c                                 fn_2b7105c
## FadeOutSpine(float duration, System.Action onCompleted) -> void
---- BlindBagCollection.BlindbagCollectionBox::FadeOutSpine 0x2d31a88
02d31a88: str     d8, [sp, #-0x60]!                          
02d31a8c: stp     x30, x27, [sp, #0x10]                      
02d31a90: stp     x26, x25, [sp, #0x20]                      
02d31a94: stp     x24, x23, [sp, #0x30]                      
02d31a98: stp     x22, x21, [sp, #0x40]                      
02d31a9c: stp     x20, x19, [sp, #0x50]                      
02d31aa0: fmov    s8, s0                                     
02d31aa4: adrp    x19, #0x6630000                            
02d31aa8: adrp    x22, #0x626a000                            
02d31aac: ldrb    w8, [x19, #0xff]                           
02d31ab0: ldr     x22, [x22, #0x788]                         T:BlindBagCollection.BlindbagCollectionBox/<>c__DisplayClass34_0
02d31ab4: mov     x20, x1                                    
02d31ab8: mov     x21, x0                                    
02d31abc: tbnz    w8, #0, #0x2d31b40                         
02d31ac0: adrp    x0, #0x6263000                             
02d31ac4: ldr     x0, [x0, #0xfc0]                           T:type8528(k15)
02d31ac8: bl      #0x2b70db0                                 fn_2b70db0
02d31acc: adrp    x0, #0x6263000                             
02d31ad0: ldr     x0, [x0, #0xfc8]                           T:type8550(k15)
02d31ad4: bl      #0x2b70db0                                 fn_2b70db0
02d31ad8: adrp    x0, #0x6263000                             
02d31adc: ldr     x0, [x0, #0xfd0]                           T:DG.Tweening.DOTween
02d31ae0: bl      #0x2b70db0                                 fn_2b70db0
02d31ae4: adrp    x0, #0x6264000                             
02d31ae8: ldr     x0, [x0, #0xe8]                            T:DG.Tweening.TweenCallback
02d31aec: bl      #0x2b70db0                                 fn_2b70db0
02d31af0: adrp    x0, #0x6266000                             
02d31af4: ldr     x0, [x0, #0xc90]                           MS:DG.Tweening.TweenSettingsExtensions::OnComplete
02d31af8: bl      #0x2b70db0                                 fn_2b70db0
02d31afc: adrp    x0, #0x626a000                             
02d31b00: ldr     x0, [x0, #0x790]                           M:BlindBagCollection.BlindbagCollectionBox/<>c::<FadeOutSpine>b__34_0
02d31b04: bl      #0x2b70db0                                 fn_2b70db0
02d31b08: adrp    x0, #0x626a000                             
02d31b0c: ldr     x0, [x0, #0x798]                           M:BlindBagCollection.BlindbagCollectionBox/<>c__DisplayClass34_0::<FadeOutSpine>b__1
02d31b10: bl      #0x2b70db0                                 fn_2b70db0
02d31b14: adrp    x0, #0x626a000                             
02d31b18: ldr     x0, [x0, #0x7a0]                           M:BlindBagCollection.BlindbagCollectionBox/<>c__DisplayClass34_0::<FadeOutSpine>b__2
02d31b1c: bl      #0x2b70db0                                 fn_2b70db0
02d31b20: adrp    x0, #0x626a000                             
02d31b24: ldr     x0, [x0, #0x788]                           T:BlindBagCollection.BlindbagCollectionBox/<>c__DisplayClass34_0
02d31b28: bl      #0x2b70db0                                 fn_2b70db0
02d31b2c: adrp    x0, #0x626a000                             
02d31b30: ldr     x0, [x0, #0x708]                           T:BlindBagCollection.BlindbagCollectionBox/<>c
02d31b34: bl      #0x2b70db0                                 fn_2b70db0
02d31b38: mov     w8, #1                                     
02d31b3c: strb    w8, [x19, #0xff]                           
02d31b40: ldr     x0, [x22]                                  T:type56879(k15)
02d31b44: bl      #0x2b7104c                                 fn_2b7104c
02d31b48: mov     x1, xzr                                    
02d31b4c: mov     x19, x0                                    
02d31b50: bl      #0x4e53e9c                                 System.Object::.ctor
02d31b54: cbz     x19, #0x2d31ce0                            
02d31b58: mov     x0, x19                                    
02d31b5c: mov     x1, x20                                    
02d31b60: str     x20, [x0, #0x28]!                          ._tfKeycap
02d31b64: bl      #0x2b70d54                                 fn_2b70d54
02d31b68: ldr     x0, [x21, #0x78]                           ._spineBag
02d31b6c: cbz     x0, #0x2d31ce0                             
02d31b70: adrp    x22, #0x626a000                            
02d31b74: mov     x1, xzr                                    
02d31b78: ldr     x22, [x22, #0x708]                         T:BlindBagCollection.BlindbagCollectionBox/<>c
02d31b7c: bl      #0x5002600                                 Spine.Unity.SkeletonRenderer::get_Skeleton
02d31b80: mov     x20, x19                                   
02d31b84: mov     x1, x0                                     
02d31b88: str     x0, [x20, #0x10]!                          
02d31b8c: mov     x0, x20                                    
02d31b90: bl      #0x2b70d54                                 fn_2b70d54
02d31b94: ldr     x0, [x20]                                  
02d31b98: mov     x1, xzr                                    
02d31b9c: bl      #0x5013fe4                                 Spine.Unity.SkeletonExtensions::GetColor
02d31ba0: ldr     x0, [x22]                                  T:type56879(k15)
02d31ba4: stp     s0, s1, [x20, #8]                          
02d31ba8: stp     s2, s3, [x20, #0x10]                       
02d31bac: ldr     w8, [x0, #0xe4]                            [626a0e4]=0 f=0,0
02d31bb0: cbnz    w8, #0x2d31bbc                             
02d31bb4: bl      #0x2b70f30                                 fn_2b70f30
02d31bb8: ldr     x0, [x22]                                  T:type56879(k15)
02d31bbc: ldr     x8, [x0, #0xb8]                            MS:UnityEngine.Object::FindObjectsOfType
02d31bc0: adrp    x25, #0x6263000                            
02d31bc4: adrp    x24, #0x626a000                            
02d31bc8: adrp    x23, #0x6263000                            
02d31bcc: ldr     x25, [x25, #0xfc8]                         T:type8550(k15)
02d31bd0: ldr     x24, [x24, #0x798]                         M:BlindBagCollection.BlindbagCollectionBox/<>c__DisplayClass34_0::<FadeOutSpine>b__1
02d31bd4: ldr     x20, [x8, #0x20]                           
02d31bd8: ldr     x23, [x23, #0xfd0]                         T:DG.Tweening.DOTween
02d31bdc: cbnz    x20, #0x2d31c38                            
02d31be0: ldr     w9, [x0, #0xe4]                            [626a0e4]=0 f=0,0
02d31be4: cbnz    w9, #0x2d31bf4                             
02d31be8: bl      #0x2b70f30                                 fn_2b70f30
02d31bec: ldr     x8, [x22]                                  T:type56879(k15)
02d31bf0: ldr     x8, [x8, #0xb8]                            
02d31bf4: adrp    x9, #0x6263000                             
02d31bf8: ldr     x9, [x9, #0xfc0]                           T:type8528(k15)
02d31bfc: ldr     x21, [x8]                                  
02d31c00: ldr     x0, [x9]                                   &2c5bbd4(=a9bd7bfdd503233f)
02d31c04: bl      #0x2b7104c                                 fn_2b7104c
02d31c08: adrp    x8, #0x626a000                             
02d31c0c: mov     x1, x21                                    
02d31c10: mov     x3, xzr                                    
02d31c14: ldr     x8, [x8, #0x790]                           M:BlindBagCollection.BlindbagCollectionBox/<>c::<FadeOutSpine>b__34_0
02d31c18: mov     x20, x0                                    
02d31c1c: ldr     x2, [x8]                                   T:type56879(k15)
02d31c20: bl      #0x44536ec                                 fn_44536ec
02d31c24: ldr     x8, [x22]                                  T:type56879(k15)
02d31c28: mov     x1, x20                                    
02d31c2c: ldr     x0, [x8, #0xb8]                            MS:UnityEngine.Object::FindObjectsOfType
02d31c30: str     x20, [x0, #0x20]!                          ._srKeycap
02d31c34: bl      #0x2b70d54                                 fn_2b70d54
02d31c38: adrp    x27, #0x6264000                            
02d31c3c: adrp    x26, #0x626a000                            
02d31c40: adrp    x22, #0x6266000                            
02d31c44: ldr     x27, [x27, #0xe8]                          T:DG.Tweening.TweenCallback
02d31c48: ldr     x26, [x26, #0x7a0]                         M:BlindBagCollection.BlindbagCollectionBox/<>c__DisplayClass34_0::<FadeOutSpine>b__2
02d31c4c: ldr     x22, [x22, #0xc90]                         MS:DG.Tweening.TweenSettingsExtensions::OnComplete
02d31c50: ldr     x0, [x25]                                  &2c5bbd4(=a9bd7bfdd503233f)
02d31c54: bl      #0x2b7104c                                 fn_2b7104c
02d31c58: ldr     x2, [x24]                                  T:type56879(k15)
02d31c5c: mov     x1, x19                                    
02d31c60: mov     x3, xzr                                    
02d31c64: mov     x21, x0                                    
02d31c68: bl      #0x4454818                                 fn_4454818
02d31c6c: ldr     x0, [x23]                                  &2c5bbd4(=a9bd7bfdd503233f)
02d31c70: ldr     w8, [x0, #0xe4]                            [626a0e4]=0 f=0,0
02d31c74: cbnz    w8, #0x2d31c7c                             
02d31c78: bl      #0x2b70f30                                 fn_2b70f30
02d31c7c: movi    d0, #0000000000000000                      
02d31c80: fmov    s1, s8                                     
02d31c84: mov     x0, x20                                    
02d31c88: mov     x1, x21                                    
02d31c8c: mov     x2, xzr                                    
02d31c90: bl      #0x2d8b3b4                                 DG.Tweening.DOTween::To
02d31c94: ldr     x8, [x27]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d31c98: mov     x20, x0                                    
02d31c9c: mov     x0, x8                                     
02d31ca0: bl      #0x2b7104c                                 fn_2b7104c
02d31ca4: ldr     x2, [x26]                                  T:type56879(k15)
02d31ca8: mov     x1, x19                                    
02d31cac: mov     x3, xzr                                    
02d31cb0: mov     x21, x0                                    
02d31cb4: bl      #0x2d89dc4                                 DG.Tweening.TweenCallback::.ctor
02d31cb8: ldr     x2, [x22]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d31cbc: mov     x0, x20                                    
02d31cc0: mov     x1, x21                                    
02d31cc4: ldp     x20, x19, [sp, #0x50]                      
02d31cc8: ldp     x22, x21, [sp, #0x40]                      
02d31ccc: ldp     x24, x23, [sp, #0x30]                      
02d31cd0: ldp     x26, x25, [sp, #0x20]                      
02d31cd4: ldp     x30, x27, [sp, #0x10]                      
02d31cd8: ldr     d8, [sp], #0x60                            
02d31cdc: b       #0x336f26c                                 
02d31ce0: bl      #0x2b7105c                                 fn_2b7105c
## ShowAtCenter(System.Action onDone) -> void
---- BlindBagCollection.BlindbagCollectionBox::ShowAtCenter 0x2d31cec
02d31cec: stp     x30, x25, [sp, #-0x40]!                    
02d31cf0: stp     x24, x23, [sp, #0x10]                      
02d31cf4: stp     x22, x21, [sp, #0x20]                      
02d31cf8: stp     x20, x19, [sp, #0x30]                      
02d31cfc: adrp    x19, #0x6630000                            
02d31d00: adrp    x22, #0x626a000                            
02d31d04: mov     x21, x1                                    
02d31d08: ldrb    w8, [x19, #0x100]                          
02d31d0c: ldr     x22, [x22, #0x7a8]                         T:BlindBagCollection.BlindbagCollectionBox/<>c__DisplayClass35_0
02d31d10: mov     x20, x0                                    
02d31d14: tbnz    w8, #0, #0x2d31d5c                         
02d31d18: adrp    x0, #0x6264000                             
02d31d1c: ldr     x0, [x0, #0xe8]                            T:DG.Tweening.TweenCallback
02d31d20: bl      #0x2b70db0                                 fn_2b70db0
02d31d24: adrp    x0, #0x6267000                             
02d31d28: ldr     x0, [x0, #0xd30]                           MS:DG.Tweening.TweenSettingsExtensions::OnComplete
02d31d2c: bl      #0x2b70db0                                 fn_2b70db0
02d31d30: adrp    x0, #0x626a000                             
02d31d34: ldr     x0, [x0, #0x7b0]                           M:BlindBagCollection.BlindbagCollectionBox/<>c__DisplayClass35_0::<ShowAtCenter>b__0
02d31d38: bl      #0x2b70db0                                 fn_2b70db0
02d31d3c: adrp    x0, #0x626a000                             
02d31d40: ldr     x0, [x0, #0x7b8]                           M:BlindBagCollection.BlindbagCollectionBox/<>c__DisplayClass35_0::<ShowAtCenter>b__1
02d31d44: bl      #0x2b70db0                                 fn_2b70db0
02d31d48: adrp    x0, #0x626a000                             
02d31d4c: ldr     x0, [x0, #0x7a8]                           T:BlindBagCollection.BlindbagCollectionBox/<>c__DisplayClass35_0
02d31d50: bl      #0x2b70db0                                 fn_2b70db0
02d31d54: mov     w8, #1                                     
02d31d58: strb    w8, [x19, #0x100]                          
02d31d5c: ldr     x0, [x22]                                  T:type56879(k15)
02d31d60: bl      #0x2b7104c                                 fn_2b7104c
02d31d64: mov     x1, xzr                                    
02d31d68: mov     x19, x0                                    
02d31d6c: bl      #0x4e53e9c                                 System.Object::.ctor
02d31d70: cbz     x19, #0x2d31f5c                            
02d31d74: adrp    x22, #0x6264000                            
02d31d78: mov     x0, x19                                    
02d31d7c: mov     x1, x20                                    
02d31d80: ldr     x22, [x22, #0xe8]                          T:DG.Tweening.TweenCallback
02d31d84: str     x20, [x0, #0x10]!                          
02d31d88: bl      #0x2b70d54                                 fn_2b70d54
02d31d8c: mov     x0, x19                                    
02d31d90: mov     x1, x21                                    
02d31d94: str     x21, [x0, #0x18]!                          
02d31d98: bl      #0x2b70d54                                 fn_2b70d54
02d31d9c: ldrb    w8, [x20, #0x90]                           ._isLuck
02d31da0: cbz     w8, #0x2d31f14                             
02d31da4: ldr     x8, [x20, #0x88]                           ._screenInGame
02d31da8: cbz     x8, #0x2d31f5c                             
02d31dac: ldr     x0, [x8, #0x48]                            
02d31db0: cbz     x0, #0x2d31f5c                             
02d31db4: bl      #0x2d33488                                 BlindBagCollection.BlindbagCollectionController::AddMoreBlindBox
02d31db8: fmov    s0, #-1.00000000                           
02d31dbc: fmov    s1, #0.50000000                            
02d31dc0: ldr     x0, [x20, #0x38]                           ._tfPaperPack
02d31dc4: mov     w1, wzr                                    
02d31dc8: mov     x2, xzr                                    
02d31dcc: bl      #0x2d97eac                                 DG.Tweening.ShortcutExtensions::DOLocalMoveX
02d31dd0: ldr     x0, [x20, #0x48]                           ._goLuck
02d31dd4: cbz     x0, #0x2d31f5c                             
02d31dd8: mov     x1, xzr                                    
02d31ddc: bl      #0x5b368f0                                 UnityEngine.GameObject::get_transform
02d31de0: fmov    s0, #3.00000000                            
02d31de4: fmov    s1, #0.50000000                            
02d31de8: mov     w1, wzr                                    
02d31dec: mov     x2, xzr                                    
02d31df0: bl      #0x2d97eac                                 DG.Tweening.ShortcutExtensions::DOLocalMoveX
02d31df4: adrp    x23, #0x662f000                            
02d31df8: ldr     x21, [x20, #0x38]                          ._tfPaperPack
02d31dfc: ldrb    w8, [x23, #0x91c]                          
02d31e00: cbnz    w8, #0x2d31e18                             
02d31e04: adrp    x0, #0x6264000                             
02d31e08: ldr     x0, [x0, #0xd8]                            T:UnityEngine.Vector3
02d31e0c: bl      #0x2b70db0                                 fn_2b70db0
02d31e10: mov     w8, #1                                     
02d31e14: strb    w8, [x23, #0x91c]                          
02d31e18: adrp    x25, #0x6264000                            
02d31e1c: fmov    v0.2s, #6.00000000                         
02d31e20: fmov    s3, #0.50000000                            
02d31e24: ldr     x25, [x25, #0xd8]                          T:UnityEngine.Vector3
02d31e28: mov     x0, x21                                    
02d31e2c: mov     w1, wzr                                    
02d31e30: mov     x2, xzr                                    
02d31e34: ldr     x8, [x25]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d31e38: ldr     x8, [x8, #0xb8]                            
02d31e3c: ldr     d1, [x8, #0x48]                            
02d31e40: ldr     s2, [x8, #0x50]                            
02d31e44: fmul    v0.2s, v1.2s, v0.2s                        
02d31e48: fmov    s1, #6.00000000                            
02d31e4c: fmul    s2, s2, s1                                 
02d31e50: mov     s1, v0.s[1]                                
02d31e54: bl      #0x2d983c8                                 DG.Tweening.ShortcutExtensions::DORotate
02d31e58: ldr     x0, [x20, #0x48]                           ._goLuck
02d31e5c: cbz     x0, #0x2d31f5c                             
02d31e60: adrp    x21, #0x626a000                            
02d31e64: adrp    x24, #0x6267000                            
02d31e68: mov     x1, xzr                                    
02d31e6c: ldr     x21, [x21, #0x7b0]                         M:BlindBagCollection.BlindbagCollectionBox/<>c__DisplayClass35_0::<ShowAtCenter>b__0
02d31e70: ldr     x24, [x24, #0xd30]                         MS:DG.Tweening.TweenSettingsExtensions::OnComplete
02d31e74: bl      #0x5b368f0                                 UnityEngine.GameObject::get_transform
02d31e78: ldrb    w8, [x23, #0x91c]                          
02d31e7c: mov     x20, x0                                    
02d31e80: cbnz    w8, #0x2d31e98                             
02d31e84: adrp    x0, #0x6264000                             
02d31e88: ldr     x0, [x0, #0xd8]                            T:UnityEngine.Vector3
02d31e8c: bl      #0x2b70db0                                 fn_2b70db0
02d31e90: mov     w8, #1                                     
02d31e94: strb    w8, [x23, #0x91c]                          
02d31e98: ldr     x8, [x25]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d31e9c: fmov    v0.2s, #-12.00000000                       
02d31ea0: fmov    s3, #0.50000000                            
02d31ea4: mov     x0, x20                                    
02d31ea8: mov     w1, wzr                                    
02d31eac: mov     x2, xzr                                    
02d31eb0: ldr     x8, [x8, #0xb8]                            
02d31eb4: ldr     d1, [x8, #0x48]                            
02d31eb8: ldr     s2, [x8, #0x50]                            
02d31ebc: fmul    v0.2s, v1.2s, v0.2s                        
02d31ec0: fmov    s1, #-12.00000000                          
02d31ec4: fmul    s2, s2, s1                                 
02d31ec8: mov     s1, v0.s[1]                                
02d31ecc: bl      #0x2d983c8                                 DG.Tweening.ShortcutExtensions::DORotate
02d31ed0: ldr     x8, [x22]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d31ed4: mov     x20, x0                                    
02d31ed8: mov     x0, x8                                     
02d31edc: bl      #0x2b7104c                                 fn_2b7104c
02d31ee0: ldr     x2, [x21]                                  T:type56879(k15)
02d31ee4: mov     x1, x19                                    
02d31ee8: mov     x3, xzr                                    
02d31eec: mov     x21, x0                                    
02d31ef0: bl      #0x2d89dc4                                 DG.Tweening.TweenCallback::.ctor
02d31ef4: ldr     x2, [x24]                                  S:'didu'
02d31ef8: mov     x0, x20                                    
02d31efc: mov     x1, x21                                    
02d31f00: ldp     x20, x19, [sp, #0x30]                      
02d31f04: ldp     x22, x21, [sp, #0x20]                      
02d31f08: ldp     x24, x23, [sp, #0x10]                      
02d31f0c: ldp     x30, x25, [sp], #0x40                      
02d31f10: b       #0x336f26c                                 
02d31f14: ldr     x0, [x22]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d31f18: bl      #0x2b7104c                                 fn_2b7104c
02d31f1c: adrp    x8, #0x626a000                             
02d31f20: mov     x1, x19                                    
02d31f24: mov     x3, xzr                                    
02d31f28: ldr     x8, [x8, #0x7b8]                           M:BlindBagCollection.BlindbagCollectionBox/<>c__DisplayClass35_0::<ShowAtCenter>b__1
02d31f2c: mov     x20, x0                                    
02d31f30: ldr     x2, [x8]                                   T:type56879(k15)
02d31f34: bl      #0x2d89dc4                                 DG.Tweening.TweenCallback::.ctor
02d31f38: mov     x0, x20                                    
02d31f3c: ldp     x20, x19, [sp, #0x30]                      
02d31f40: ldp     x22, x21, [sp, #0x20]                      
02d31f44: fmov    s0, #1.50000000                            
02d31f48: ldp     x24, x23, [sp, #0x10]                      
02d31f4c: mov     w1, #1                                     
02d31f50: mov     x2, xzr                                    
02d31f54: ldp     x30, x25, [sp], #0x40                      
02d31f58: b       #0x2d8f37c                                 DG.Tweening.DOVirtual::DelayedCall
02d31f5c: bl      #0x2b7105c                                 fn_2b7105c
## HideEffect() -> void
---- BlindBagCollection.BlindbagCollectionBox::HideEffect 0x2d31f7c
02d31f7c: str     d8, [sp, #-0x20]!                          
02d31f80: str     x30, [sp, #8]                              
02d31f84: stp     x20, x19, [sp, #0x10]                      
02d31f88: adrp    x20, #0x6630000                            
02d31f8c: mov     x19, x0                                    
02d31f90: ldrb    w8, [x20, #0x101]                          
02d31f94: tbnz    w8, #0, #0x2d31fb8                         
02d31f98: adrp    x0, #0x6264000                             
02d31f9c: ldr     x0, [x0, #0x308]                           MS:DG.Tweening.TweenSettingsExtensions::SetEase
02d31fa0: bl      #0x2b70db0                                 fn_2b70db0
02d31fa4: adrp    x0, #0x6266000                             
02d31fa8: ldr     x0, [x0, #0x880]                           MS:DG.Tweening.TweenSettingsExtensions::SetEase
02d31fac: bl      #0x2b70db0                                 fn_2b70db0
02d31fb0: mov     w8, #1                                     
02d31fb4: strb    w8, [x20, #0x101]                          
02d31fb8: ldr     s8, [x19, #0xa4]                           ._timeDoneGlowTween
02d31fbc: mov     x0, xzr                                    
02d31fc0: bl      #0x5b432fc                                 UnityEngine.Time::get_time
02d31fc4: fcmp    s8, s0                                     
02d31fc8: b.pl    #0x2d31ff4                                 
02d31fcc: movi    d0, #0000000000000000                      
02d31fd0: adrp    x20, #0x6266000                            
02d31fd4: fmov    s1, #0.50000000                            
02d31fd8: ldr     x20, [x20, #0x880]                         MS:DG.Tweening.TweenSettingsExtensions::SetEase
02d31fdc: ldr     x0, [x19, #0x70]                           ._tfGlowEffect
02d31fe0: mov     x1, xzr                                    
02d31fe4: bl      #0x2d98c98                                 DG.Tweening.ShortcutExtensions::DOScale
02d31fe8: ldr     x2, [x20]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d31fec: mov     w1, #0x1a                                  
02d31ff0: bl      #0x336fa0c                                 fn_336fa0c
02d31ff4: ldr     s8, [x19, #0xa0]                           ._timeDoneBGTween
02d31ff8: mov     x0, xzr                                    
02d31ffc: bl      #0x5b432fc                                 UnityEngine.Time::get_time
02d32000: fcmp    s8, s0                                     
02d32004: b.pl    #0x2d3203c                                 
02d32008: movi    d0, #0000000000000000                      
02d3200c: adrp    x20, #0x6264000                            
02d32010: fmov    s1, #0.50000000                            
02d32014: ldr     x20, [x20, #0x308]                         MS:DG.Tweening.TweenSettingsExtensions::SetEase
02d32018: ldr     x0, [x19, #0x60]                           ._srResult
02d3201c: mov     x1, xzr                                    
02d32020: bl      #0x2c77d0c                                 DG.Tweening.DOTweenModuleSprite::DOFade
02d32024: ldr     x2, [x20]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d32028: ldp     x20, x19, [sp, #0x10]                      
02d3202c: ldr     x30, [sp, #8]                              
02d32030: mov     w1, #1                                     
02d32034: ldr     d8, [sp], #0x20                            
02d32038: b       #0x336fa0c                                 
02d3203c: ldp     x20, x19, [sp, #0x10]                      
02d32040: ldr     x30, [sp, #8]                              
02d32044: ldr     d8, [sp], #0x20                            
02d32048: ret                                                
## FlyToTray() -> void
---- BlindBagCollection.BlindbagCollectionBox::FlyToTray 0x2d3204c
02d3204c: stp     x30, x19, [sp, #-0x10]!                    
02d32050: mov     x19, x0                                    
02d32054: ldr     x0, [x0, #0x80]                            ._blindBoxPlate
02d32058: cbz     x0, #0x2d32078                             
02d3205c: ldr     x1, [x19, #0x28]                           ._tfKeycap
02d32060: bl      #0x2d3207c                                 BlindBagCollection.BlindBoxPlate::GetNewItem
02d32064: ldr     x0, [x19, #0x88]                           ._screenInGame
02d32068: cbz     x0, #0x2d32078                             
02d3206c: mov     w1, wzr                                    
02d32070: ldp     x30, x19, [sp], #0x10                      
02d32074: b       #0x2d32148                                 BlindBagCollection.BlindbagGameScreen::HandleCharmFlyToPlate
02d32078: bl      #0x2b7105c                                 fn_2b7105c
## EnableClick() -> void
---- BlindBagCollection.BlindbagCollectionBox::EnableClick 0x2d321e0
02d321e0: ldr     x0, [x0, #0x50]                            ._collider
02d321e4: cbz     x0, #0x2d321f4                             
02d321e8: mov     w1, #1                                     
02d321ec: mov     x2, xzr                                    
02d321f0: b       #0x5b33110                                 UnityEngine.Behaviour::set_enabled
02d321f4: str     x30, [sp, #-0x10]!                         
02d321f8: bl      #0x2b7105c                                 fn_2b7105c
## DisableClick() -> void
---- BlindBagCollection.BlindbagCollectionBox::DisableClick 0x2d314e4
02d314e4: ldr     x0, [x0, #0x50]                            ._collider
02d314e8: cbz     x0, #0x2d314f8                             
02d314ec: mov     w1, wzr                                    
02d314f0: mov     x2, xzr                                    
02d314f4: b       #0x5b33110                                 UnityEngine.Behaviour::set_enabled
02d314f8: str     x30, [sp, #-0x10]!                         
02d314fc: bl      #0x2b7105c                                 fn_2b7105c
## .ctor() -> void
---- BlindBagCollection.BlindbagCollectionBox::.ctor 0x2d321fc
02d321fc: mov     x1, xzr                                    
02d32200: b       #0x5b397b0                                 UnityEngine.MonoBehaviour::.ctor
