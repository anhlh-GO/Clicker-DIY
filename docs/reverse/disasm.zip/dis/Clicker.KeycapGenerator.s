#### CLASS Clicker.KeycapGenerator parent= UnityEngine.MonoBehaviour
#   field _baseKeycapConfig              Clicker.BaseKeycapConfig                           off=0x20 attr=1 SerializeField
#   field _switchConfig                  Clicker.SwitchConfig                               off=0x28 attr=1 SerializeField
#   field _keycapConfig                  Clicker.KeycapConfig                               off=0x30 attr=1 SerializeField
#   field _keychainConfig                Clicker.KeychainConfig                             off=0x38 attr=1 SerializeField
#   field _decorKeycapConfig             Clicker.DecorKeycapConfig                          off=0x40 attr=1 SerializeField
#   field _keycapScale                   float                                              off=0x48 attr=1 SerializeField
#   field _baseKeycapObjectHolder        Clicker.BaseKeycapObject                           off=0x50 attr=1 SerializeField
#   field _cachedData                    ClickerSaveDataItem                                off=0x58 attr=1 
## get_KeycapHolding() -> Clicker.BaseKeycapObject
---- Clicker.KeycapGenerator::get_KeycapHolding 0x2d6bdf8
02d6bdf8: ldr     x0, [x0, #0x50]                            ._baseKeycapObjectHolder
02d6bdfc: ret                                                
## get_Index() -> int
---- Clicker.KeycapGenerator::get_Index 0x2d5cad0
02d5cad0: ldr     x8, [x0, #0x58]                            ._cachedData
02d5cad4: cbz     x8, #0x2d5cae0                             
02d5cad8: ldr     w0, [x8, #0x10]                            
02d5cadc: ret                                                
02d5cae0: str     x30, [sp, #-0x10]!                         
02d5cae4: bl      #0x2b7105c                                 fn_2b7105c
## CanGenerateThisItem(ClickerSaveDataItem data) -> bool
---- Clicker.KeycapGenerator::CanGenerateThisItem 0x2d67c58
02d67c58: sub     sp, sp, #0x30                              
02d67c5c: stp     x30, x21, [sp, #0x10]                      
02d67c60: stp     x20, x19, [sp, #0x20]                      
02d67c64: adrp    x21, #0x6630000                            
02d67c68: mov     x19, x1                                    
02d67c6c: mov     x20, x0                                    
02d67c70: ldrb    w8, [x21, #0x36e]                          
02d67c74: tbnz    w8, #0, #0x2d67ca4                         
02d67c78: adrp    x0, #0x6263000                             
02d67c7c: ldr     x0, [x0, #0x928]                           T:UnityEngine.Debug
02d67c80: bl      #0x2b70db0                                 fn_2b70db0
02d67c84: adrp    x0, #0x6268000                             
02d67c88: ldr     x0, [x0, #0xea8]                           MS:System.Collections.Generic.List`1::get_Count
02d67c8c: bl      #0x2b70db0                                 fn_2b70db0
02d67c90: adrp    x0, #0x626c000                             
02d67c94: ldr     x0, [x0, #0x250]                           S:'[KeycapGenerator] dev log base keycap data id {0} not found!'
02d67c98: bl      #0x2b70db0                                 fn_2b70db0
02d67c9c: mov     w8, #1                                     
02d67ca0: strb    w8, [x21, #0x36e]                          
02d67ca4: cbz     x19, #0x2d67d50                            
02d67ca8: ldr     x0, [x20, #0x20]                           ._baseKeycapConfig
02d67cac: cbz     x0, #0x2d67d50                             
02d67cb0: ldr     w1, [x19, #0x14]                           
02d67cb4: bl      #0x2d5b300                                 Clicker.BaseKeycapConfig::GetData
02d67cb8: cbz     x0, #0x2d67cd8                             
02d67cbc: ldr     x8, [x19, #0x28]                           ._switchConfig
02d67cc0: cbz     x8, #0x2d67d50                             
02d67cc4: ldr     w8, [x8, #0x18]                            
02d67cc8: ldr     w9, [x0, #0x20]                            M:Clicker.GlowSprite2DItem::<DoGlow>b__10_6 ._baseKeycapConfig
02d67ccc: cmp     w8, w9                                     
02d67cd0: cset    w0, eq                                     
02d67cd4: b       #0x2d67d40                                 
02d67cd8: adrp    x8, #0x6263000                             
02d67cdc: add     x1, sp, #0xc                               
02d67ce0: ldr     x8, [x8, #0x970]                           &6645c70(=0)
02d67ce4: ldr     w9, [x19, #0x14]                           
02d67ce8: ldr     x0, [x8, #0x48]                            &6263098(=0)
02d67cec: str     w9, [sp, #0xc]                             
02d67cf0: bl      #0x2b70f38                                 fn_2b70f38
02d67cf4: adrp    x8, #0x626c000                             
02d67cf8: mov     x1, x0                                     
02d67cfc: mov     x2, xzr                                    
02d67d00: ldr     x8, [x8, #0x250]                           S:'[KeycapGenerator] dev log base keycap data id {0} not found!'
02d67d04: ldr     x8, [x8]                                   M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d67d08: mov     x0, x8                                     
02d67d0c: bl      #0x4c9d0ec                                 System.String::Format
02d67d10: adrp    x8, #0x6263000                             
02d67d14: mov     x19, x0                                    
02d67d18: ldr     x8, [x8, #0x928]                           T:UnityEngine.Debug
02d67d1c: ldr     x8, [x8]                                   &2c5bbd4(=a9bd7bfdd503233f)
02d67d20: ldr     w9, [x8, #0xe4]                            [62630e4]=0 f=0,0
02d67d24: cbnz    w9, #0x2d67d30                             
02d67d28: mov     x0, x8                                     
02d67d2c: bl      #0x2b70f30                                 fn_2b70f30
02d67d30: mov     x0, x19                                    
02d67d34: mov     x1, xzr                                    
02d67d38: bl      #0x5af21f4                                 UnityEngine.Debug::Log
02d67d3c: mov     w0, wzr                                    
02d67d40: ldp     x20, x19, [sp, #0x20]                      
02d67d44: ldp     x30, x21, [sp, #0x10]                      
02d67d48: add     sp, sp, #0x30                              
02d67d4c: ret                                                
02d67d50: bl      #0x2b7105c                                 fn_2b7105c
## GenerateKeycap(ClickerSaveDataItem data) -> Clicker.BaseKeycapObject
---- Clicker.KeycapGenerator::GenerateKeycap 0x2d67e00
02d67e00: sub     sp, sp, #0x60                              
02d67e04: stp     x30, x27, [sp, #0x10]                      
02d67e08: stp     x26, x25, [sp, #0x20]                      
02d67e0c: stp     x24, x23, [sp, #0x30]                      
02d67e10: stp     x22, x21, [sp, #0x40]                      
02d67e14: stp     x20, x19, [sp, #0x50]                      
02d67e18: adrp    x21, #0x6630000                            
02d67e1c: mov     x20, x1                                    
02d67e20: mov     x19, x0                                    
02d67e24: ldrb    w8, [x21, #0x36f]                          
02d67e28: tbnz    w8, #0, #0x2d67ec4                         
02d67e2c: adrp    x0, #0x6263000                             
02d67e30: ldr     x0, [x0, #0x928]                           T:UnityEngine.Debug
02d67e34: bl      #0x2b70db0                                 fn_2b70db0
02d67e38: adrp    x0, #0x626c000                             
02d67e3c: ldr     x0, [x0, #0x258]                           MS:System.Enum::TryParse
02d67e40: bl      #0x2b70db0                                 fn_2b70db0
02d67e44: adrp    x0, #0x6268000                             
02d67e48: ldr     x0, [x0, #0xea8]                           MS:System.Collections.Generic.List`1::get_Count
02d67e4c: bl      #0x2b70db0                                 fn_2b70db0
02d67e50: adrp    x0, #0x6266000                             
02d67e54: ldr     x0, [x0, #0xc38]                           MS:System.Collections.Generic.List`1::get_Item
02d67e58: bl      #0x2b70db0                                 fn_2b70db0
02d67e5c: adrp    x0, #0x626a000                             
02d67e60: ldr     x0, [x0, #0x310]                           MS:System.Collections.Generic.List`1::get_Item
02d67e64: bl      #0x2b70db0                                 fn_2b70db0
02d67e68: adrp    x0, #0x626c000                             
02d67e6c: ldr     x0, [x0, #0x260]                           MS:UnityEngine.Object::Instantiate
02d67e70: bl      #0x2b70db0                                 fn_2b70db0
02d67e74: adrp    x0, #0x6263000                             
02d67e78: ldr     x0, [x0, #0x918]                           T:UnityEngine.Object
02d67e7c: bl      #0x2b70db0                                 fn_2b70db0
02d67e80: adrp    x0, #0x626c000                             
02d67e84: ldr     x0, [x0, #0x268]                           S:'[KeycapGenerator] dev log switch data id {0} not found!'
02d67e88: bl      #0x2b70db0                                 fn_2b70db0
02d67e8c: adrp    x0, #0x626c000                             
02d67e90: ldr     x0, [x0, #0x270]                           S:'[KeycapGenerator] dev log decor data id {0} not found!'
02d67e94: bl      #0x2b70db0                                 fn_2b70db0
02d67e98: adrp    x0, #0x626c000                             
02d67e9c: ldr     x0, [x0, #0x250]                           S:'[KeycapGenerator] dev log base keycap data id {0} not found!'
02d67ea0: bl      #0x2b70db0                                 fn_2b70db0
02d67ea4: adrp    x0, #0x626c000                             
02d67ea8: ldr     x0, [x0, #0x278]                           S:'[KeycapGenerator] dev log keychain data id {0} not found!'
02d67eac: bl      #0x2b70db0                                 fn_2b70db0
02d67eb0: adrp    x0, #0x626c000                             
02d67eb4: ldr     x0, [x0, #0x280]                           S:'[KeycapGenerator] dev log keycap data id {0} not found!'
02d67eb8: bl      #0x2b70db0                                 fn_2b70db0
02d67ebc: mov     w8, #1                                     
02d67ec0: strb    w8, [x21, #0x36f]                          
02d67ec4: mov     x21, x19                                   
02d67ec8: mov     x1, x20                                    
02d67ecc: str     wzr, [sp, #0xc]                            
02d67ed0: str     x20, [x21, #0x58]!                         ._cachedData
02d67ed4: mov     x0, x21                                    
02d67ed8: bl      #0x2b70d54                                 fn_2b70d54
02d67edc: cbz     x20, #0x2d68194                            
02d67ee0: ldur    x0, [x21, #-0x38]                          
02d67ee4: cbz     x0, #0x2d68194                             
02d67ee8: ldr     w1, [x20, #0x14]                           
02d67eec: bl      #0x2d5b300                                 Clicker.BaseKeycapConfig::GetData
02d67ef0: cbz     x0, #0x2d68198                             
02d67ef4: adrp    x24, #0x6263000                            
02d67ef8: mov     x22, x0                                    
02d67efc: mov     x21, x19                                   
02d67f00: ldr     x24, [x24, #0x918]                         T:UnityEngine.Object
02d67f04: ldr     x23, [x21, #0x50]!                         ._baseKeycapObjectHolder
02d67f08: ldr     x0, [x24]                                  &2c5bbd4(=a9bd7bfdd503233f)
02d67f0c: ldr     w8, [x0, #0xe4]                            [626c0e4]=0 f=0,0
02d67f10: cbnz    w8, #0x2d67f18                             
02d67f14: bl      #0x2b70f30                                 fn_2b70f30
02d67f18: mov     x0, x23                                    
02d67f1c: mov     x1, xzr                                    
02d67f20: mov     x2, xzr                                    
02d67f24: bl      #0x5b3666c                                 UnityEngine.Object::op_Inequality
02d67f28: tbz     w0, #0, #0x2d67f60                         
02d67f2c: ldr     x0, [x21]                                  
02d67f30: cbz     x0, #0x2d68194                             
02d67f34: mov     x1, xzr                                    
02d67f38: bl      #0x5b339ec                                 UnityEngine.Component::get_gameObject
02d67f3c: ldr     x8, [x24]                                  &2c5bbd4(=a9bd7bfdd503233f)
02d67f40: mov     x23, x0                                    
02d67f44: ldr     w9, [x8, #0xe4]                            
02d67f48: cbnz    w9, #0x2d67f54                             
02d67f4c: mov     x0, x8                                     
02d67f50: bl      #0x2b70f30                                 fn_2b70f30
02d67f54: mov     x0, x23                                    
02d67f58: mov     x1, xzr                                    
02d67f5c: bl      #0x5b3ca38                                 UnityEngine.Object::Destroy
02d67f60: adrp    x25, #0x626c000                            
02d67f64: mov     x0, x19                                    
02d67f68: mov     x1, xzr                                    
02d67f6c: ldr     x25, [x25, #0x260]                         MS:UnityEngine.Object::Instantiate
02d67f70: ldr     x22, [x22, #0x40]                          
02d67f74: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02d67f78: ldr     x8, [x24]                                  &2c5bbd4(=a9bd7bfdd503233f)
02d67f7c: mov     x23, x0                                    
02d67f80: ldr     w9, [x8, #0xe4]                            
02d67f84: cbnz    w9, #0x2d67f90                             
02d67f88: mov     x0, x8                                     
02d67f8c: bl      #0x2b70f30                                 fn_2b70f30
02d67f90: ldr     x2, [x25]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d67f94: mov     x0, x22                                    
02d67f98: mov     x1, x23                                    
02d67f9c: bl      #0x3275fcc                                 fn_3275fcc
02d67fa0: mov     x1, x0                                     
02d67fa4: str     x0, [x21]                                  
02d67fa8: mov     x0, x21                                    
02d67fac: bl      #0x2b70d54                                 fn_2b70d54
02d67fb0: ldr     x0, [x21]                                  
02d67fb4: cbz     x0, #0x2d68194                             
02d67fb8: bl      #0x2d5f45c                                 Clicker.BaseKeycapObject::ShowBaseOnly
02d67fbc: ldr     x0, [x19, #0x28]                           ._switchConfig
02d67fc0: cbz     x0, #0x2d68194                             
02d67fc4: ldr     w1, [x20, #0x18]                           
02d67fc8: bl      #0x2d5bd98                                 Clicker.SwitchConfig::GetData
02d67fcc: cbz     x0, #0x2d681c0                             
02d67fd0: mov     x22, x0                                    
02d67fd4: ldr     x0, [x21]                                  
02d67fd8: cbz     x0, #0x2d68194                             
02d67fdc: ldr     x1, [x22, #0x18]                           
02d67fe0: bl      #0x2d5e850                                 Clicker.BaseKeycapObject::SetSwitch
02d67fe4: adrp    x24, #0x6263000                            
02d67fe8: ldr     x24, [x24, #0x970]                         &6645c70(=0)
02d67fec: ldr     x22, [x22, #0x20]                          
02d67ff0: ldr     x0, [x24, #0x98]                           [6263098]=0 f=0,0
02d67ff4: ldr     w8, [x0, #0xe4]                            [626c0e4]=0 f=0,0
02d67ff8: cbnz    w8, #0x2d68000                             
02d67ffc: bl      #0x2b70f30                                 fn_2b70f30
02d68000: adrp    x8, #0x626c000                             
02d68004: add     x1, sp, #0xc                               
02d68008: mov     x0, x22                                    
02d6800c: ldr     x8, [x8, #0x258]                           MS:System.Enum::TryParse
02d68010: ldr     x2, [x8]                                   M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d68014: bl      #0x31788a0                                 fn_31788a0
02d68018: tbz     w0, #0, #0x2d6802c                         
02d6801c: ldr     x0, [x21]                                  
02d68020: cbz     x0, #0x2d68194                             
02d68024: ldr     w1, [sp, #0xc]                             
02d68028: bl      #0x2d5e93c                                 Clicker.BaseKeycapObject::SetSwitchSound
02d6802c: ldr     x0, [x19, #0x30]                           ._keycapConfig
02d68030: cbz     x0, #0x2d68194                             
02d68034: ldr     w1, [x20, #0x1c]                           
02d68038: bl      #0x2d5b820                                 Clicker.KeycapConfig::GetData
02d6803c: cbz     x0, #0x2d68268                             
02d68040: ldr     x0, [x0, #0x20]                            M:Clicker.GlowSprite2DItem::<DoGlow>b__10_6 ._baseKeycapConfig
02d68044: cbz     x0, #0x2d68194                             
02d68048: adrp    x8, #0x6266000                             
02d6804c: ldr     x8, [x8, #0xc38]                           MS:System.Collections.Generic.List`1::get_Item
02d68050: ldr     w1, [x20, #0x20]                           ._baseKeycapConfig
02d68054: ldr     x22, [x21]                                 
02d68058: ldr     x2, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d6805c: bl      #0x35a8f3c                                 fn_35a8f3c
02d68060: cbz     x22, #0x2d68194                            
02d68064: mov     x1, x0                                     
02d68068: mov     x0, x22                                    
02d6806c: mov     w2, wzr                                    
02d68070: bl      #0x2d5ea1c                                 Clicker.BaseKeycapObject::SetKeycap
02d68074: ldr     x0, [x21]                                  
02d68078: cbz     x0, #0x2d68194                             
02d6807c: mov     w1, #1                                     
02d68080: bl      #0x2d5cae8                                 Clicker.BaseKeycapObject::TurnModeSetup
02d68084: ldr     x0, [x19, #0x38]                           ._keychainConfig
02d68088: cbz     x0, #0x2d68194                             
02d6808c: ldr     w1, [x20, #0x24]                           
02d68090: bl      #0x2d5ba88                                 Clicker.KeychainConfig::GetData
02d68094: cbz     x0, #0x2d68288                             
02d68098: ldr     x8, [x21]                                  
02d6809c: cbz     x8, #0x2d68194                             
02d680a0: ldr     x8, [x8, #0x78]                            S:'Latest Fetch call still pending.'
02d680a4: cbz     x8, #0x2d68194                             
02d680a8: ldr     x1, [x0, #0x20]                            M:Clicker.GlowSprite2DItem::<DoGlow>b__10_6 ._baseKeycapConfig
02d680ac: mov     x0, x8                                     
02d680b0: mov     x2, xzr                                    
02d680b4: bl      #0x5ae6dcc                                 UnityEngine.SpriteRenderer::set_sprite
02d680b8: ldr     x0, [x21]                                  
02d680bc: cbz     x0, #0x2d68194                             
02d680c0: bl      #0x2d5f764                                 Clicker.BaseKeycapObject::JustShowKeychain
02d680c4: ldr     x0, [x20, #0x28]                           ._switchConfig
02d680c8: cbz     x0, #0x2d68194                             
02d680cc: adrp    x25, #0x626a000                            
02d680d0: adrp    x26, #0x626c000                            
02d680d4: adrp    x27, #0x6263000                            
02d680d8: ldr     x25, [x25, #0x310]                         MS:System.Collections.Generic.List`1::get_Item
02d680dc: ldr     x26, [x26, #0x270]                         S:'[KeycapGenerator] dev log decor data id {0} not found!'
02d680e0: ldr     x27, [x27, #0x928]                         T:UnityEngine.Debug
02d680e4: mov     w22, wzr                                   
02d680e8: ldr     w8, [x0, #0x18]                            M:Clicker.GlowSprite2DItem::<DoGlow>b__10_5
02d680ec: cmp     w22, w8                                    
02d680f0: b.ge    #0x2d681e8                                 
02d680f4: ldr     x2, [x25]                                  T:type56879(k15)
02d680f8: mov     w1, w22                                    
02d680fc: bl      #0x3569920                                 fn_3569920
02d68100: ldr     x8, [x19, #0x40]                           ._decorKeycapConfig
02d68104: cbz     x8, #0x2d68194                             
02d68108: mov     w23, w0                                    
02d6810c: mov     x0, x8                                     
02d68110: mov     w1, w23                                    
02d68114: bl      #0x2d5b618                                 Clicker.DecorKeycapConfig::GetData
02d68118: cbz     x0, #0x2d68140                             
02d6811c: ldr     x8, [x21]                                  
02d68120: cbz     x8, #0x2d68194                             
02d68124: ldr     w3, [x0, #0x20]                            M:Clicker.GlowSprite2DItem::<DoGlow>b__10_6 ._baseKeycapConfig
02d68128: ldr     x2, [x0, #0x28]                            MS:UnityEngine.Component::GetComponentInParent ._switchConfig
02d6812c: mov     x0, x8                                     
02d68130: mov     w1, w22                                    
02d68134: mov     w4, w23                                    
02d68138: bl      #0x2d5ed04                                 Clicker.BaseKeycapObject::SetKeycapIndex
02d6813c: b       #0x2d68188                                 
02d68140: ldr     x0, [x24, #0x48]                           &6263098(=0)
02d68144: add     x1, sp, #8                                 
02d68148: str     w23, [sp, #8]                              
02d6814c: bl      #0x2b70f38                                 fn_2b70f38
02d68150: ldr     x8, [x26]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d68154: mov     x1, x0                                     
02d68158: mov     x2, xzr                                    
02d6815c: mov     x0, x8                                     
02d68160: bl      #0x4c9d0ec                                 System.String::Format
02d68164: ldr     x8, [x27]                                  &2c5bbd4(=a9bd7bfdd503233f)
02d68168: mov     x23, x0                                    
02d6816c: ldr     w9, [x8, #0xe4]                            [62660e4]=0 f=0,0
02d68170: cbnz    w9, #0x2d6817c                             
02d68174: mov     x0, x8                                     
02d68178: bl      #0x2b70f30                                 fn_2b70f30
02d6817c: mov     x0, x23                                    
02d68180: mov     x1, xzr                                    
02d68184: bl      #0x5af21f4                                 UnityEngine.Debug::Log
02d68188: ldr     x0, [x20, #0x28]                           ._switchConfig
02d6818c: add     w22, w22, #1                               
02d68190: cbnz    x0, #0x2d680e8                             
02d68194: bl      #0x2b7105c                                 fn_2b7105c
02d68198: adrp    x8, #0x6263000                             
02d6819c: add     x1, sp, #8                                 
02d681a0: ldr     x8, [x8, #0x970]                           &6645c70(=0)
02d681a4: ldr     w9, [x20, #0x14]                           
02d681a8: ldr     x0, [x8, #0x48]                            &6263098(=0)
02d681ac: str     w9, [sp, #8]                               
02d681b0: bl      #0x2b70f38                                 fn_2b70f38
02d681b4: adrp    x8, #0x626c000                             
02d681b8: ldr     x8, [x8, #0x250]                           S:'[KeycapGenerator] dev log base keycap data id {0} not found!'
02d681bc: b       #0x2d682a4                                 
02d681c0: adrp    x8, #0x6263000                             
02d681c4: add     x1, sp, #8                                 
02d681c8: ldr     x8, [x8, #0x970]                           &6645c70(=0)
02d681cc: ldr     w9, [x20, #0x18]                           
02d681d0: ldr     x0, [x8, #0x48]                            &6263098(=0)
02d681d4: str     w9, [sp, #8]                               
02d681d8: bl      #0x2b70f38                                 fn_2b70f38
02d681dc: adrp    x8, #0x626c000                             
02d681e0: ldr     x8, [x8, #0x268]                           S:'[KeycapGenerator] dev log switch data id {0} not found!'
02d681e4: b       #0x2d682a4                                 
02d681e8: ldr     x0, [x21]                                  
02d681ec: cbz     x0, #0x2d68194                             
02d681f0: bl      #0x2d5e648                                 Clicker.BaseKeycapObject::RemoveSetupEvent
02d681f4: ldr     x0, [x21]                                  
02d681f8: cbz     x0, #0x2d68194                             
02d681fc: mov     x1, xzr                                    
02d68200: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02d68204: adrp    x21, #0x662f000                            
02d68208: mov     x20, x0                                    
02d6820c: ldrb    w8, [x21, #0xa74]                          
02d68210: cbnz    w8, #0x2d68228                             
02d68214: adrp    x0, #0x6264000                             
02d68218: ldr     x0, [x0, #0xd8]                            T:UnityEngine.Vector3
02d6821c: bl      #0x2b70db0                                 fn_2b70db0
02d68220: mov     w8, #1                                     
02d68224: strb    w8, [x21, #0xa74]                          
02d68228: cbz     x20, #0x2d68194                            
02d6822c: adrp    x8, #0x6264000                             
02d68230: mov     x0, x20                                    
02d68234: mov     x1, xzr                                    
02d68238: ldr     x8, [x8, #0xd8]                            T:UnityEngine.Vector3
02d6823c: ldr     s0, [x19, #0x48]                           ._keycapScale
02d68240: ldr     x8, [x8]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d68244: ldr     x8, [x8, #0xb8]                            MS:DG.Tweening.Core.Extensions::SetSpecialStartupMode
02d68248: ldp     s3, s1, [x8, #0x10]                        
02d6824c: ldr     s4, [x8, #0xc]                             [626400c]=0 f=0,0
02d68250: fmul    s2, s1, s0                                 
02d68254: fmul    s1, s0, s3                                 
02d68258: fmul    s0, s0, s4                                 
02d6825c: bl      #0x5b470cc                                 UnityEngine.Transform::set_localScale
02d68260: ldr     x0, [x19, #0x50]                           ._baseKeycapObjectHolder
02d68264: b       #0x2d682e8                                 
02d68268: ldr     w8, [x20, #0x1c]                           
02d6826c: ldr     x0, [x24, #0x48]                           &6263098(=0)
02d68270: add     x1, sp, #8                                 
02d68274: str     w8, [sp, #8]                               
02d68278: bl      #0x2b70f38                                 fn_2b70f38
02d6827c: adrp    x8, #0x626c000                             
02d68280: ldr     x8, [x8, #0x280]                           S:'[KeycapGenerator] dev log keycap data id {0} not found!'
02d68284: b       #0x2d682a4                                 
02d68288: ldr     w8, [x20, #0x24]                           
02d6828c: ldr     x0, [x24, #0x48]                           &6263098(=0)
02d68290: add     x1, sp, #8                                 
02d68294: str     w8, [sp, #8]                               
02d68298: bl      #0x2b70f38                                 fn_2b70f38
02d6829c: adrp    x8, #0x626c000                             
02d682a0: ldr     x8, [x8, #0x278]                           S:'[KeycapGenerator] dev log keychain data id {0} not found!'
02d682a4: ldr     x8, [x8]                                   M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d682a8: mov     x1, x0                                     
02d682ac: mov     x2, xzr                                    
02d682b0: mov     x0, x8                                     
02d682b4: bl      #0x4c9d0ec                                 System.String::Format
02d682b8: adrp    x8, #0x6263000                             
02d682bc: mov     x19, x0                                    
02d682c0: ldr     x8, [x8, #0x928]                           T:UnityEngine.Debug
02d682c4: ldr     x8, [x8]                                   &2c5bbd4(=a9bd7bfdd503233f)
02d682c8: ldr     w9, [x8, #0xe4]                            [62630e4]=0 f=0,0
02d682cc: cbnz    w9, #0x2d682d8                             
02d682d0: mov     x0, x8                                     
02d682d4: bl      #0x2b70f30                                 fn_2b70f30
02d682d8: mov     x0, x19                                    
02d682dc: mov     x1, xzr                                    
02d682e0: bl      #0x5af21f4                                 UnityEngine.Debug::Log
02d682e4: mov     x0, xzr                                    
02d682e8: ldp     x20, x19, [sp, #0x50]                      
02d682ec: ldp     x22, x21, [sp, #0x40]                      
02d682f0: ldp     x24, x23, [sp, #0x30]                      
02d682f4: ldp     x26, x25, [sp, #0x20]                      
02d682f8: ldp     x30, x27, [sp, #0x10]                      
02d682fc: add     sp, sp, #0x60                              
02d68300: ret                                                
## OnEnable() -> void
---- Clicker.KeycapGenerator::OnEnable 0x2d6be00
02d6be00: str     x30, [sp, #-0x30]!                         
02d6be04: stp     x22, x21, [sp, #0x10]                      
02d6be08: stp     x20, x19, [sp, #0x20]                      
02d6be0c: adrp    x21, #0x6630000                            
02d6be10: adrp    x22, #0x6264000                            
02d6be14: adrp    x20, #0x626c000                            
02d6be18: ldrb    w8, [x21, #0x370]                          
02d6be1c: ldr     x22, [x22, #0xe8]                          T:DG.Tweening.TweenCallback
02d6be20: ldr     x20, [x20, #0x410]                         M:Clicker.KeycapGenerator::<OnEnable>b__14_0
02d6be24: mov     x19, x0                                    
02d6be28: tbnz    w8, #0, #0x2d6be4c                         
02d6be2c: adrp    x0, #0x626c000                             
02d6be30: ldr     x0, [x0, #0x410]                           M:Clicker.KeycapGenerator::<OnEnable>b__14_0
02d6be34: bl      #0x2b70db0                                 fn_2b70db0
02d6be38: adrp    x0, #0x6264000                             
02d6be3c: ldr     x0, [x0, #0xe8]                            T:DG.Tweening.TweenCallback
02d6be40: bl      #0x2b70db0                                 fn_2b70db0
02d6be44: mov     w8, #1                                     
02d6be48: strb    w8, [x21, #0x370]                          
02d6be4c: ldr     x0, [x22]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d6be50: bl      #0x2b7104c                                 fn_2b7104c
02d6be54: ldr     x2, [x20]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d6be58: mov     x1, x19                                    
02d6be5c: mov     x3, xzr                                    
02d6be60: mov     x20, x0                                    
02d6be64: bl      #0x2d89dc4                                 DG.Tweening.TweenCallback::.ctor
02d6be68: adrp    x8, #0x1084000                             
02d6be6c: mov     x0, x20                                    
02d6be70: mov     w1, #1                                     
02d6be74: ldp     x20, x19, [sp, #0x20]                      
02d6be78: ldr     s0, [x8, #0xeec]                           [1084eec]=457ff0003dcccccd f=0.1,4095
02d6be7c: ldp     x22, x21, [sp, #0x10]                      
02d6be80: mov     x2, xzr                                    
02d6be84: ldr     x30, [sp], #0x30                           
02d6be88: b       #0x2d8f37c                                 DG.Tweening.DOVirtual::DelayedCall
## SetLayerRecursively(UnityEngine.GameObject obj, int layer) -> void
---- Clicker.KeycapGenerator::SetLayerRecursively 0x2d6be8c
02d6be8c: str     x30, [sp, #-0x30]!                         
02d6be90: stp     x22, x21, [sp, #0x10]                      
02d6be94: stp     x20, x19, [sp, #0x20]                      
02d6be98: adrp    x21, #0x6630000                            
02d6be9c: mov     w19, w1                                    
02d6bea0: mov     x20, x0                                    
02d6bea4: ldrb    w8, [x21, #0x371]                          
02d6bea8: tbnz    w8, #0, #0x2d6bec0                         
02d6beac: adrp    x0, #0x626c000                             
02d6beb0: ldr     x0, [x0, #0x418]                           MS:UnityEngine.GameObject::GetComponentsInChildren
02d6beb4: bl      #0x2b70db0                                 fn_2b70db0
02d6beb8: mov     w8, #1                                     
02d6bebc: strb    w8, [x21, #0x371]                          
02d6bec0: cbz     x20, #0x2d6bf40                            
02d6bec4: adrp    x8, #0x626c000                             
02d6bec8: mov     x0, x20                                    
02d6becc: mov     w1, #1                                     
02d6bed0: ldr     x8, [x8, #0x418]                           MS:UnityEngine.GameObject::GetComponentsInChildren
02d6bed4: ldr     x2, [x8]                                   M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d6bed8: bl      #0x31d1c34                                 fn_31d1c34
02d6bedc: cbz     x0, #0x2d6bf40                             
02d6bee0: ldr     w8, [x0, #0x18]                            M:Clicker.GlowSprite2DItem::<DoGlow>b__10_5
02d6bee4: mov     x20, x0                                    
02d6bee8: cmp     w8, #1                                     
02d6beec: b.lt    #0x2d6bf30                                 
02d6bef0: mov     x21, xzr                                   
02d6bef4: add     x22, x20, #0x20                            
02d6bef8: cmp     w21, w8                                    
02d6befc: b.hs    #0x2d6bf44                                 
02d6bf00: ldr     x0, [x22, x21, lsl #3]                     
02d6bf04: cbz     x0, #0x2d6bf40                             
02d6bf08: mov     x1, xzr                                    
02d6bf0c: bl      #0x5b339ec                                 UnityEngine.Component::get_gameObject
02d6bf10: cbz     x0, #0x2d6bf40                             
02d6bf14: mov     w1, w19                                    
02d6bf18: mov     x2, xzr                                    
02d6bf1c: bl      #0x5b36a74                                 UnityEngine.GameObject::set_layer
02d6bf20: ldr     w8, [x20, #0x18]                           
02d6bf24: add     x21, x21, #1                               &6630001
02d6bf28: cmp     w21, w8                                    
02d6bf2c: b.lt    #0x2d6bef8                                 
02d6bf30: ldp     x20, x19, [sp, #0x20]                      
02d6bf34: ldp     x22, x21, [sp, #0x10]                      
02d6bf38: ldr     x30, [sp], #0x30                           
02d6bf3c: ret                                                
02d6bf40: bl      #0x2b7105c                                 fn_2b7105c
02d6bf44: bl      #0x2b71064                                 fn_2b71064
## .ctor() -> void
---- Clicker.KeycapGenerator::.ctor 0x2d6bf48
02d6bf48: mov     w8, #0x3333                                
02d6bf4c: mov     x1, xzr                                    
02d6bf50: movk    w8, #0x3eb3, lsl #16                       
02d6bf54: str     w8, [x0, #0x48]                            ._keycapScale
02d6bf58: b       #0x5b397b0                                 UnityEngine.MonoBehaviour::.ctor
## <OnEnable>b__14_0() -> void
---- Clicker.KeycapGenerator::<OnEnable>b__14_0 0x2d6bf5c
02d6bf5c: sub     sp, sp, #0x30                              
02d6bf60: stp     x30, x21, [sp, #0x10]                      
02d6bf64: stp     x20, x19, [sp, #0x20]                      
02d6bf68: adrp    x20, #0x6630000                            
02d6bf6c: mov     x19, x0                                    
02d6bf70: ldrb    w8, [x20, #0x372]                          
02d6bf74: tbnz    w8, #0, #0x2d6bf98                         
02d6bf78: adrp    x0, #0x626c000                             
02d6bf7c: ldr     x0, [x0, #0x258]                           MS:System.Enum::TryParse
02d6bf80: bl      #0x2b70db0                                 fn_2b70db0
02d6bf84: adrp    x0, #0x626c000                             
02d6bf88: ldr     x0, [x0, #0x420]                           S:'Inspect'
02d6bf8c: bl      #0x2b70db0                                 fn_2b70db0
02d6bf90: mov     w8, #1                                     
02d6bf94: strb    w8, [x20, #0x372]                          
02d6bf98: ldr     x8, [x19, #0x58]                           ._cachedData
02d6bf9c: str     wzr, [sp, #0xc]                            
02d6bfa0: cbz     x8, #0x2d6c0a0                             
02d6bfa4: ldr     x0, [x19, #0x28]                           ._switchConfig
02d6bfa8: cbz     x0, #0x2d6c0a0                             
02d6bfac: ldr     w1, [x8, #0x18]                            
02d6bfb0: bl      #0x2d5bd98                                 Clicker.SwitchConfig::GetData
02d6bfb4: cbz     x0, #0x2d6c090                             
02d6bfb8: mov     x20, x0                                    
02d6bfbc: ldr     x0, [x19, #0x50]                           ._baseKeycapObjectHolder
02d6bfc0: cbz     x0, #0x2d6c0a0                             
02d6bfc4: ldr     x1, [x20, #0x18]                           
02d6bfc8: bl      #0x2d5e850                                 Clicker.BaseKeycapObject::SetSwitch
02d6bfcc: ldr     x8, [x19, #0x50]                           ._baseKeycapObjectHolder
02d6bfd0: cbz     x8, #0x2d6c0a0                             
02d6bfd4: ldur    q0, [x20, #0x28]                           ._switchConfig
02d6bfd8: str     q0, [x8, #0x50]                            
02d6bfdc: ldr     x0, [x19, #0x50]                           ._baseKeycapObjectHolder
02d6bfe0: cbz     x0, #0x2d6c0a0                             
02d6bfe4: adrp    x21, #0x626c000                            
02d6bfe8: ldr     x21, [x21, #0x258]                         MS:System.Enum::TryParse
02d6bfec: bl      #0x2d60ba4                                 Clicker.BaseKeycapObject::ApplyGlowColor
02d6bff0: adrp    x8, #0x6263000                             
02d6bff4: ldr     x8, [x8, #0x970]                           &6645c70(=0)
02d6bff8: ldr     x20, [x20, #0x20]                          ._baseKeycapConfig
02d6bffc: ldr     x0, [x8, #0x98]                            [6263098]=0 f=0,0
02d6c000: ldr     w8, [x0, #0xe4]                            [626c0e4]=0 f=0,0
02d6c004: cbnz    w8, #0x2d6c00c                             
02d6c008: bl      #0x2b70f30                                 fn_2b70f30
02d6c00c: ldr     x2, [x21]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d6c010: add     x1, sp, #0xc                               
02d6c014: mov     x0, x20                                    
02d6c018: bl      #0x31788a0                                 fn_31788a0
02d6c01c: tbz     w0, #0, #0x2d6c030                         
02d6c020: ldr     x0, [x19, #0x50]                           ._baseKeycapObjectHolder
02d6c024: cbz     x0, #0x2d6c0a0                             
02d6c028: ldr     w1, [sp, #0xc]                             
02d6c02c: bl      #0x2d5e93c                                 Clicker.BaseKeycapObject::SetSwitchSound
02d6c030: ldr     x0, [x19, #0x50]                           ._baseKeycapObjectHolder
02d6c034: cbz     x0, #0x2d6c0a0                             
02d6c038: mov     w1, #1                                     
02d6c03c: bl      #0x2d5cae8                                 Clicker.BaseKeycapObject::TurnModeSetup
02d6c040: ldr     x0, [x19, #0x50]                           ._baseKeycapObjectHolder
02d6c044: cbz     x0, #0x2d6c0a0                             
02d6c048: bl      #0x2d5efe4                                 Clicker.BaseKeycapObject::ShowAllNoAnim
02d6c04c: ldr     x0, [x19, #0x50]                           ._baseKeycapObjectHolder
02d6c050: cbz     x0, #0x2d6c0a0                             
02d6c054: bl      #0x2d5e648                                 Clicker.BaseKeycapObject::RemoveSetupEvent
02d6c058: ldr     x0, [x19, #0x50]                           ._baseKeycapObjectHolder
02d6c05c: cbz     x0, #0x2d6c0a0                             
02d6c060: adrp    x19, #0x626c000                            
02d6c064: mov     x1, xzr                                    
02d6c068: ldr     x19, [x19, #0x420]                         S:'Inspect'
02d6c06c: bl      #0x5b339ec                                 UnityEngine.Component::get_gameObject
02d6c070: ldr     x8, [x19]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d6c074: mov     x19, x0                                    
02d6c078: mov     x1, xzr                                    
02d6c07c: mov     x0, x8                                     
02d6c080: bl      #0x5b37788                                 UnityEngine.LayerMask::NameToLayer
02d6c084: mov     w1, w0                                     
02d6c088: mov     x0, x19                                    
02d6c08c: bl      #0x2d6be8c                                 Clicker.KeycapGenerator::SetLayerRecursively
02d6c090: ldp     x20, x19, [sp, #0x20]                      
02d6c094: ldp     x30, x21, [sp, #0x10]                      
02d6c098: add     sp, sp, #0x30                              
02d6c09c: ret                                                
02d6c0a0: bl      #0x2b7105c                                 fn_2b7105c
