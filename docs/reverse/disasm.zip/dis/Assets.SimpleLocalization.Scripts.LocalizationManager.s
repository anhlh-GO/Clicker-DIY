#### CLASS Assets.SimpleLocalization.Scripts.LocalizationManager/<>c parent= object
#   field <>9                            Assets.SimpleLocalization.Scripts.LocalizationManager/<>c off=0x0 attr=36 
#   field <>9__9_0                       System.Func`2<string,string>                       off=0x8 attr=16 
#   field <>9__13_0                      System.Func`2<string,bool>                         off=0x10 attr=16 
#   field <>9__14_0                      System.Func`2<string,string>                       off=0x18 attr=16 
#   field <>9__14_1                      System.Func`2<string,string>                       off=0x20 attr=16 
## .cctor() -> void
---- Assets.SimpleLocalization.Scripts.LocalizationManager/<>c::.cctor 0x2d7bf44
02d7bf44: str     x30, [sp, #-0x20]!                         
02d7bf48: stp     x20, x19, [sp, #0x10]                      
02d7bf4c: adrp    x19, #0x6630000                            
02d7bf50: adrp    x20, #0x626c000                            
02d7bf54: ldrb    w8, [x19, #0x40e]                          
02d7bf58: ldr     x20, [x20, #0xac0]                         T:Assets.SimpleLocalization.Scripts.LocalizationManager/<>c
02d7bf5c: tbnz    w8, #0, #0x2d7bf74                         
02d7bf60: adrp    x0, #0x626c000                             
02d7bf64: ldr     x0, [x0, #0xac0]                           T:Assets.SimpleLocalization.Scripts.LocalizationManager/<>c
02d7bf68: bl      #0x2b70db0                                 fn_2b70db0
02d7bf6c: mov     w8, #1                                     
02d7bf70: strb    w8, [x19, #0x40e]                          
02d7bf74: ldr     x0, [x20]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d7bf78: bl      #0x2b7104c                                 fn_2b7104c
02d7bf7c: mov     x1, xzr                                    
02d7bf80: mov     x19, x0                                    
02d7bf84: bl      #0x4e53e9c                                 System.Object::.ctor
02d7bf88: ldr     x8, [x20]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d7bf8c: mov     x1, x19                                    
02d7bf90: ldr     x8, [x8, #0xb8]                            
02d7bf94: str     x19, [x8]                                  
02d7bf98: ldr     x8, [x20]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d7bf9c: ldp     x20, x19, [sp, #0x10]                      
02d7bfa0: ldr     x0, [x8, #0xb8]                            
02d7bfa4: ldr     x30, [sp], #0x20                           
02d7bfa8: b       #0x2b70d54                                 
## .ctor() -> void
---- Assets.SimpleLocalization.Scripts.LocalizationManager/<>c::.ctor 0x2d7bfac
02d7bfac: mov     x1, xzr                                    
02d7bfb0: b       #0x4e53e9c                                 System.Object::.ctor
## <Read>b__9_0(string i) -> string
---- Assets.SimpleLocalization.Scripts.LocalizationManager/<>c::<Read>b__9_0 0x2d7bfb4
02d7bfb4: cbz     x1, #0x2d7bfc4                             
02d7bfb8: mov     x0, x1                                     
02d7bfbc: mov     x1, xzr                                    
02d7bfc0: b       #0x4cab1c4                                 System.String::Trim
02d7bfc4: str     x30, [sp, #-0x10]!                         
02d7bfc8: bl      #0x2b7105c                                 fn_2b7105c
## <GetLines>b__13_0(string i) -> bool
---- Assets.SimpleLocalization.Scripts.LocalizationManager/<>c::<GetLines>b__13_0 0x2d7bfcc
02d7bfcc: stp     x30, x21, [sp, #-0x20]!                    
02d7bfd0: stp     x20, x19, [sp, #0x10]                      
02d7bfd4: adrp    x20, #0x6630000                            
02d7bfd8: adrp    x21, #0x6263000                            
02d7bfdc: mov     x19, x1                                    
02d7bfe0: ldrb    w8, [x20, #0x40f]                          
02d7bfe4: ldr     x21, [x21, #0xa90]                         S:''
02d7bfe8: tbnz    w8, #0, #0x2d7c000                         
02d7bfec: adrp    x0, #0x6263000                             
02d7bff0: ldr     x0, [x0, #0xa90]                           S:''
02d7bff4: bl      #0x2b70db0                                 fn_2b70db0
02d7bff8: mov     w8, #1                                     
02d7bffc: strb    w8, [x20, #0x40f]                          
02d7c000: mov     x0, x19                                    
02d7c004: ldp     x20, x19, [sp, #0x10]                      
02d7c008: ldr     x1, [x21]                                  &2c5bbd4(=a9bd7bfdd503233f)
02d7c00c: mov     x2, xzr                                    
02d7c010: ldp     x30, x21, [sp], #0x20                      
02d7c014: b       #0x4ca52bc                                 System.String::op_Inequality
## <GetColumns>b__14_0(string j) -> string
---- Assets.SimpleLocalization.Scripts.LocalizationManager/<>c::<GetColumns>b__14_0 0x2d7c018
02d7c018: cbz     x1, #0x2d7c028                             
02d7c01c: mov     x0, x1                                     
02d7c020: mov     x1, xzr                                    
02d7c024: b       #0x4cab1c4                                 System.String::Trim
02d7c028: str     x30, [sp, #-0x10]!                         
02d7c02c: bl      #0x2b7105c                                 fn_2b7105c
## <GetColumns>b__14_1(string j) -> string
---- Assets.SimpleLocalization.Scripts.LocalizationManager/<>c::<GetColumns>b__14_1 0x2d7c030
02d7c030: str     x30, [sp, #-0x20]!                         
02d7c034: stp     x20, x19, [sp, #0x10]                      
02d7c038: adrp    x20, #0x6630000                            
02d7c03c: mov     x19, x1                                    
02d7c040: ldrb    w8, [x20, #0x410]                          
02d7c044: tbnz    w8, #0, #0x2d7c098                         
02d7c048: adrp    x0, #0x6264000                             
02d7c04c: ldr     x0, [x0, #0xe18]                           S:'\n'
02d7c050: bl      #0x2b70db0                                 fn_2b70db0
02d7c054: adrp    x0, #0x626c000                             
02d7c058: ldr     x0, [x0, #0xba8]                           S:'[_quote_]'
02d7c05c: bl      #0x2b70db0                                 fn_2b70db0
02d7c060: adrp    x0, #0x6266000                             
02d7c064: ldr     x0, [x0, #0xc28]                           S:','
02d7c068: bl      #0x2b70db0                                 fn_2b70db0
02d7c06c: adrp    x0, #0x626c000                             
02d7c070: ldr     x0, [x0, #0xbc0]                           S:'"'
02d7c074: bl      #0x2b70db0                                 fn_2b70db0
02d7c078: adrp    x0, #0x626c000                             
02d7c07c: ldr     x0, [x0, #0xbc8]                           S:'[_comma_]'
02d7c080: bl      #0x2b70db0                                 fn_2b70db0
02d7c084: adrp    x0, #0x626c000                             
02d7c088: ldr     x0, [x0, #0xbd0]                           S:'[_newline_]'
02d7c08c: bl      #0x2b70db0                                 fn_2b70db0
02d7c090: mov     w8, #1                                     
02d7c094: strb    w8, [x20, #0x410]                          
02d7c098: cbz     x19, #0x2d7c110                            
02d7c09c: adrp    x8, #0x626c000                             
02d7c0a0: adrp    x9, #0x626c000                             
02d7c0a4: mov     x0, x19                                    
02d7c0a8: ldr     x8, [x8, #0xba8]                           S:'[_quote_]'
02d7c0ac: ldr     x9, [x9, #0xbc0]                           S:'"'
02d7c0b0: mov     x3, xzr                                    
02d7c0b4: ldr     x1, [x8]                                   M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d7c0b8: ldr     x2, [x9]                                   M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d7c0bc: bl      #0x4ca8ca8                                 System.String::Replace
02d7c0c0: cbz     x0, #0x2d7c110                             
02d7c0c4: adrp    x8, #0x626c000                             
02d7c0c8: adrp    x9, #0x6266000                             
02d7c0cc: mov     x3, xzr                                    
02d7c0d0: ldr     x8, [x8, #0xbc8]                           S:'[_comma_]'
02d7c0d4: ldr     x9, [x9, #0xc28]                           S:','
02d7c0d8: ldr     x1, [x8]                                   M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d7c0dc: ldr     x2, [x9]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d7c0e0: bl      #0x4ca8ca8                                 System.String::Replace
02d7c0e4: cbz     x0, #0x2d7c110                             
02d7c0e8: adrp    x8, #0x626c000                             
02d7c0ec: adrp    x9, #0x6264000                             
02d7c0f0: mov     x3, xzr                                    
02d7c0f4: ldr     x8, [x8, #0xbd0]                           S:'[_newline_]'
02d7c0f8: ldr     x9, [x9, #0xe18]                           S:'\n'
02d7c0fc: ldp     x20, x19, [sp, #0x10]                      
02d7c100: ldr     x1, [x8]                                   M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d7c104: ldr     x2, [x9]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d7c108: ldr     x30, [sp], #0x20                           
02d7c10c: b       #0x4ca8ca8                                 System.String::Replace
02d7c110: bl      #0x2b7105c                                 fn_2b7105c
## <.cctor>b__15_0() -> void
---- Assets.SimpleLocalization.Scripts.LocalizationManager/<>c::<.cctor>b__15_0 0x2d7c114
02d7c114: ret                                                
#### CLASS Assets.SimpleLocalization.Scripts.LocalizationManager parent= object
#   field OnLocalizationChanged          System.Action                                      off=0x0 attr=11 CompilerGeneratedAttribute
#   field Dictionary                     System.Collections.Generic.Dictionary`2<string,System.Collections.Generic.Dictionary`2<string,string>> off=0x8 attr=16 
#   field _language                      string                                             off=0x10 attr=11 
## add_OnLocalizationChanged(System.Action value) -> void
---- Assets.SimpleLocalization.Scripts.LocalizationManager::add_OnLocalizationChanged 0x2d7ad04
02d7ad04: stp     x30, x23, [sp, #-0x30]!                    
02d7ad08: stp     x22, x21, [sp, #0x10]                      
02d7ad0c: stp     x20, x19, [sp, #0x20]                      
02d7ad10: adrp    x20, #0x6630000                            
02d7ad14: adrp    x22, #0x6266000                            
02d7ad18: mov     x19, x0                                    
02d7ad1c: ldrb    w8, [x20, #0x402]                          
02d7ad20: ldr     x22, [x22, #0x9f0]                         T:Assets.SimpleLocalization.Scripts.LocalizationManager
02d7ad24: tbnz    w8, #0, #0x2d7ad48                         
02d7ad28: adrp    x0, #0x6264000                             
02d7ad2c: ldr     x0, [x0, #0xf90]                           T:System.Action
02d7ad30: bl      #0x2b70db0                                 fn_2b70db0
02d7ad34: adrp    x0, #0x6266000                             
02d7ad38: ldr     x0, [x0, #0x9f0]                           T:Assets.SimpleLocalization.Scripts.LocalizationManager
02d7ad3c: bl      #0x2b70db0                                 fn_2b70db0
02d7ad40: mov     w8, #1                                     
02d7ad44: strb    w8, [x20, #0x402]                          
02d7ad48: ldr     x0, [x22]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d7ad4c: ldr     w8, [x0, #0xe4]                            [62660e4]=0 f=0,0
02d7ad50: cbnz    w8, #0x2d7ad5c                             
02d7ad54: bl      #0x2b70f30                                 fn_2b70f30
02d7ad58: ldr     x0, [x22]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d7ad5c: ldr     x8, [x0, #0xb8]                            S:'banner_native_refresh_time'
02d7ad60: adrp    x23, #0x6264000                            
02d7ad64: ldr     x23, [x23, #0xf90]                         T:System.Action
02d7ad68: ldr     x20, [x8]                                  
02d7ad6c: mov     x0, x20                                    
02d7ad70: mov     x1, x19                                    
02d7ad74: mov     x2, xzr                                    
02d7ad78: bl      #0x4e570ac                                 System.Delegate::Combine
02d7ad7c: mov     x21, x0                                    
02d7ad80: cbz     x0, #0x2d7ad94                             
02d7ad84: ldr     x1, [x23]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d7ad88: ldr     x8, [x21]                                  
02d7ad8c: cmp     x8, x1                                     
02d7ad90: b.ne    #0x2d7add4                                 
02d7ad94: ldr     x0, [x22]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d7ad98: ldr     w8, [x0, #0xe4]                            [62660e4]=0 f=0,0
02d7ad9c: cbnz    w8, #0x2d7ada8                             
02d7ada0: bl      #0x2b70f30                                 fn_2b70f30
02d7ada4: ldr     x0, [x22]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d7ada8: ldr     x0, [x0, #0xb8]                            S:'banner_native_refresh_time'
02d7adac: mov     x1, x21                                    
02d7adb0: mov     x2, x20                                    
02d7adb4: bl      #0x2ba9880                                 fn_2ba9880
02d7adb8: cmp     x0, x20                                    
02d7adbc: mov     x20, x0                                    
02d7adc0: b.ne    #0x2d7ad6c                                 
02d7adc4: ldp     x20, x19, [sp, #0x20]                      
02d7adc8: ldp     x22, x21, [sp, #0x10]                      
02d7adcc: ldp     x30, x23, [sp], #0x30                      
02d7add0: ret                                                
02d7add4: mov     x0, x21                                    
02d7add8: bl      #0x2b713dc                                 fn_2b713dc
## remove_OnLocalizationChanged(System.Action value) -> void
---- Assets.SimpleLocalization.Scripts.LocalizationManager::remove_OnLocalizationChanged 0x2d7b144
02d7b144: stp     x30, x23, [sp, #-0x30]!                    
02d7b148: stp     x22, x21, [sp, #0x10]                      
02d7b14c: stp     x20, x19, [sp, #0x20]                      
02d7b150: adrp    x20, #0x6630000                            
02d7b154: adrp    x22, #0x6266000                            
02d7b158: mov     x19, x0                                    
02d7b15c: ldrb    w8, [x20, #0x403]                          
02d7b160: ldr     x22, [x22, #0x9f0]                         T:Assets.SimpleLocalization.Scripts.LocalizationManager
02d7b164: tbnz    w8, #0, #0x2d7b188                         
02d7b168: adrp    x0, #0x6264000                             
02d7b16c: ldr     x0, [x0, #0xf90]                           T:System.Action
02d7b170: bl      #0x2b70db0                                 fn_2b70db0
02d7b174: adrp    x0, #0x6266000                             
02d7b178: ldr     x0, [x0, #0x9f0]                           T:Assets.SimpleLocalization.Scripts.LocalizationManager
02d7b17c: bl      #0x2b70db0                                 fn_2b70db0
02d7b180: mov     w8, #1                                     
02d7b184: strb    w8, [x20, #0x403]                          
02d7b188: ldr     x0, [x22]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d7b18c: ldr     w8, [x0, #0xe4]                            [62660e4]=0 f=0,0
02d7b190: cbnz    w8, #0x2d7b19c                             
02d7b194: bl      #0x2b70f30                                 fn_2b70f30
02d7b198: ldr     x0, [x22]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d7b19c: ldr     x8, [x0, #0xb8]                            S:'banner_native_refresh_time'
02d7b1a0: adrp    x23, #0x6264000                            
02d7b1a4: ldr     x23, [x23, #0xf90]                         T:System.Action
02d7b1a8: ldr     x20, [x8]                                  
02d7b1ac: mov     x0, x20                                    
02d7b1b0: mov     x1, x19                                    
02d7b1b4: mov     x2, xzr                                    
02d7b1b8: bl      #0x4e57298                                 System.Delegate::Remove
02d7b1bc: mov     x21, x0                                    
02d7b1c0: cbz     x0, #0x2d7b1d4                             
02d7b1c4: ldr     x1, [x23]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d7b1c8: ldr     x8, [x21]                                  
02d7b1cc: cmp     x8, x1                                     
02d7b1d0: b.ne    #0x2d7b214                                 
02d7b1d4: ldr     x0, [x22]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d7b1d8: ldr     w8, [x0, #0xe4]                            [62660e4]=0 f=0,0
02d7b1dc: cbnz    w8, #0x2d7b1e8                             
02d7b1e0: bl      #0x2b70f30                                 fn_2b70f30
02d7b1e4: ldr     x0, [x22]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d7b1e8: ldr     x0, [x0, #0xb8]                            S:'banner_native_refresh_time'
02d7b1ec: mov     x1, x21                                    
02d7b1f0: mov     x2, x20                                    
02d7b1f4: bl      #0x2ba9880                                 fn_2ba9880
02d7b1f8: cmp     x0, x20                                    
02d7b1fc: mov     x20, x0                                    
02d7b200: b.ne    #0x2d7b1ac                                 
02d7b204: ldp     x20, x19, [sp, #0x20]                      
02d7b208: ldp     x22, x21, [sp, #0x10]                      
02d7b20c: ldp     x30, x23, [sp], #0x30                      
02d7b210: ret                                                
02d7b214: mov     x0, x21                                    
02d7b218: bl      #0x2b713dc                                 fn_2b713dc
## get_Language() -> string
---- Assets.SimpleLocalization.Scripts.LocalizationManager::get_Language 0x2d7b21c
02d7b21c: str     x30, [sp, #-0x20]!                         
02d7b220: stp     x20, x19, [sp, #0x10]                      
02d7b224: adrp    x20, #0x6630000                            
02d7b228: adrp    x19, #0x6266000                            
02d7b22c: ldrb    w8, [x20, #0x404]                          
02d7b230: ldr     x19, [x19, #0x9f0]                         T:Assets.SimpleLocalization.Scripts.LocalizationManager
02d7b234: tbnz    w8, #0, #0x2d7b24c                         
02d7b238: adrp    x0, #0x6266000                             
02d7b23c: ldr     x0, [x0, #0x9f0]                           T:Assets.SimpleLocalization.Scripts.LocalizationManager
02d7b240: bl      #0x2b70db0                                 fn_2b70db0
02d7b244: mov     w8, #1                                     
02d7b248: strb    w8, [x20, #0x404]                          
02d7b24c: ldr     x0, [x19]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d7b250: ldr     w8, [x0, #0xe4]                            [62660e4]=0 f=0,0
02d7b254: cbnz    w8, #0x2d7b260                             
02d7b258: bl      #0x2b70f30                                 fn_2b70f30
02d7b25c: ldr     x0, [x19]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d7b260: ldr     x8, [x0, #0xb8]                            S:'banner_native_refresh_time'
02d7b264: ldp     x20, x19, [sp, #0x10]                      
02d7b268: ldr     x0, [x8, #0x10]                            
02d7b26c: ldr     x30, [sp], #0x20                           
02d7b270: ret                                                
## set_Language(string value) -> void
---- Assets.SimpleLocalization.Scripts.LocalizationManager::set_Language 0x2d7ac14
02d7ac14: stp     x30, x21, [sp, #-0x20]!                    
02d7ac18: stp     x20, x19, [sp, #0x10]                      
02d7ac1c: adrp    x21, #0x6630000                            
02d7ac20: adrp    x20, #0x6266000                            
02d7ac24: mov     x19, x0                                    
02d7ac28: ldrb    w8, [x21, #0x405]                          
02d7ac2c: ldr     x20, [x20, #0x9f0]                         T:Assets.SimpleLocalization.Scripts.LocalizationManager
02d7ac30: tbnz    w8, #0, #0x2d7ac48                         
02d7ac34: adrp    x0, #0x6266000                             
02d7ac38: ldr     x0, [x0, #0x9f0]                           T:Assets.SimpleLocalization.Scripts.LocalizationManager
02d7ac3c: bl      #0x2b70db0                                 fn_2b70db0
02d7ac40: mov     w8, #1                                     
02d7ac44: strb    w8, [x21, #0x405]                          
02d7ac48: ldr     x0, [x20]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d7ac4c: ldr     w8, [x0, #0xe4]                            [62660e4]=0 f=0,0
02d7ac50: cbnz    w8, #0x2d7ac5c                             
02d7ac54: bl      #0x2b70f30                                 fn_2b70f30
02d7ac58: ldr     x0, [x20]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d7ac5c: ldr     x0, [x0, #0xb8]                            S:'banner_native_refresh_time'
02d7ac60: mov     x1, x19                                    
02d7ac64: str     x19, [x0, #0x10]!                          ._language
02d7ac68: bl      #0x2b70d54                                 fn_2b70d54
02d7ac6c: ldr     x8, [x20]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d7ac70: ldr     x8, [x8, #0xb8]                            
02d7ac74: ldr     x8, [x8]                                   
02d7ac78: cbz     x8, #0x2d7ac94                             
02d7ac7c: ldp     x20, x19, [sp, #0x10]                      
02d7ac80: ldr     x0, [x8, #0x40]                            
02d7ac84: ldr     x1, [x8, #0x28]                            
02d7ac88: ldr     x2, [x8, #0x18]                            
02d7ac8c: ldp     x30, x21, [sp], #0x20                      
02d7ac90: br      x2                                         
02d7ac94: bl      #0x2b7105c                                 fn_2b7105c
## AutoLanguage() -> void
---- Assets.SimpleLocalization.Scripts.LocalizationManager::AutoLanguage 0x2d7b274
02d7b274: str     x30, [sp, #-0x20]!                         
02d7b278: stp     x20, x19, [sp, #0x10]                      
02d7b27c: adrp    x20, #0x6630000                            
02d7b280: adrp    x19, #0x6266000                            
02d7b284: ldrb    w8, [x20, #0x406]                          
02d7b288: ldr     x19, [x19, #0x9f0]                         T:Assets.SimpleLocalization.Scripts.LocalizationManager
02d7b28c: tbnz    w8, #0, #0x2d7b2b0                         
02d7b290: adrp    x0, #0x6266000                             
02d7b294: ldr     x0, [x0, #0x9f0]                           T:Assets.SimpleLocalization.Scripts.LocalizationManager
02d7b298: bl      #0x2b70db0                                 fn_2b70db0
02d7b29c: adrp    x0, #0x6266000                             
02d7b2a0: ldr     x0, [x0, #0xbc0]                           S:'English'
02d7b2a4: bl      #0x2b70db0                                 fn_2b70db0
02d7b2a8: mov     w8, #1                                     
02d7b2ac: strb    w8, [x20, #0x406]                          
02d7b2b0: ldr     x0, [x19]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d7b2b4: adrp    x19, #0x6266000                            
02d7b2b8: ldr     w8, [x0, #0xe4]                            [62660e4]=0 f=0,0
02d7b2bc: ldr     x19, [x19, #0xbc0]                         S:'English'
02d7b2c0: cbnz    w8, #0x2d7b2c8                             
02d7b2c4: bl      #0x2b70f30                                 fn_2b70f30
02d7b2c8: ldr     x0, [x19]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d7b2cc: ldp     x20, x19, [sp, #0x10]                      
02d7b2d0: ldr     x30, [sp], #0x20                           
02d7b2d4: b       #0x2d7ac14                                 Assets.SimpleLocalization.Scripts.LocalizationManager::set_Language
## Read() -> void
---- Assets.SimpleLocalization.Scripts.LocalizationManager::Read 0x2d7a0b0
02d7a0b0: sub     sp, sp, #0xa0                              
02d7a0b4: stp     x29, x30, [sp, #0x40]                      
02d7a0b8: stp     x28, x27, [sp, #0x50]                      
02d7a0bc: stp     x26, x25, [sp, #0x60]                      
02d7a0c0: stp     x24, x23, [sp, #0x70]                      
02d7a0c4: stp     x22, x21, [sp, #0x80]                      
02d7a0c8: stp     x20, x19, [sp, #0x90]                      
02d7a0cc: adrp    x19, #0x6630000                            
02d7a0d0: adrp    x27, #0x6266000                            
02d7a0d4: ldrb    w8, [x19, #0x407]                          
02d7a0d8: ldr     x27, [x27, #0x9f0]                         T:Assets.SimpleLocalization.Scripts.LocalizationManager
02d7a0dc: tbnz    w8, #0, #0x2d7a2a4                         
02d7a0e0: adrp    x0, #0x6263000                             
02d7a0e4: ldr     x0, [x0, #0x928]                           T:UnityEngine.Debug
02d7a0e8: bl      #0x2b70db0                                 fn_2b70db0
02d7a0ec: adrp    x0, #0x626c000                             
02d7a0f0: ldr     x0, [x0, #0xa60]                           MS:System.Collections.Generic.Dictionary`2::Add
02d7a0f4: bl      #0x2b70db0                                 fn_2b70db0
02d7a0f8: adrp    x0, #0x6265000                             
02d7a0fc: ldr     x0, [x0, #0x2d8]                           MS:System.Collections.Generic.Dictionary`2::Add
02d7a100: bl      #0x2b70db0                                 fn_2b70db0
02d7a104: adrp    x0, #0x626c000                             
02d7a108: ldr     x0, [x0, #0x848]                           MS:System.Collections.Generic.Dictionary`2::ContainsKey
02d7a10c: bl      #0x2b70db0                                 fn_2b70db0
02d7a110: adrp    x0, #0x626c000                             
02d7a114: ldr     x0, [x0, #0x850]                           MS:System.Collections.Generic.Dictionary`2::ContainsKey
02d7a118: bl      #0x2b70db0                                 fn_2b70db0
02d7a11c: adrp    x0, #0x6265000                             
02d7a120: ldr     x0, [x0, #0x2e0]                           MS:System.Collections.Generic.Dictionary`2::.ctor
02d7a124: bl      #0x2b70db0                                 fn_2b70db0
02d7a128: adrp    x0, #0x626c000                             
02d7a12c: ldr     x0, [x0, #0x858]                           MS:System.Collections.Generic.Dictionary`2::get_Count
02d7a130: bl      #0x2b70db0                                 fn_2b70db0
02d7a134: adrp    x0, #0x626c000                             
02d7a138: ldr     x0, [x0, #0x860]                           MS:System.Collections.Generic.Dictionary`2::get_Item
02d7a13c: bl      #0x2b70db0                                 fn_2b70db0
02d7a140: adrp    x0, #0x6265000                             
02d7a144: ldr     x0, [x0, #0x2e8]                           T:type8944(k15)
02d7a148: bl      #0x2b70db0                                 fn_2b70db0
02d7a14c: adrp    x0, #0x626c000                             
02d7a150: ldr     x0, [x0, #0xa68]                           MS:System.Linq.Enumerable::Count
02d7a154: bl      #0x2b70db0                                 fn_2b70db0
02d7a158: adrp    x0, #0x626c000                             
02d7a15c: ldr     x0, [x0, #0xa70]                           MS:System.Linq.Enumerable::Distinct
02d7a160: bl      #0x2b70db0                                 fn_2b70db0
02d7a164: adrp    x0, #0x626c000                             
02d7a168: ldr     x0, [x0, #0xa78]                           MS:System.Linq.Enumerable::Select
02d7a16c: bl      #0x2b70db0                                 fn_2b70db0
02d7a170: adrp    x0, #0x6266000                             
02d7a174: ldr     x0, [x0, #0xc50]                           MS:System.Linq.Enumerable::ToList
02d7a178: bl      #0x2b70db0                                 fn_2b70db0
02d7a17c: adrp    x0, #0x626c000                             
02d7a180: ldr     x0, [x0, #0xa80]                           MS:System.Collections.Generic.List`1/Enumerator::Dispose
02d7a184: bl      #0x2b70db0                                 fn_2b70db0
02d7a188: adrp    x0, #0x626c000                             
02d7a18c: ldr     x0, [x0, #0xa88]                           MS:System.Collections.Generic.List`1/Enumerator::MoveNext
02d7a190: bl      #0x2b70db0                                 fn_2b70db0
02d7a194: adrp    x0, #0x626c000                             
02d7a198: ldr     x0, [x0, #0xa90]                           MS:System.Collections.Generic.List`1/Enumerator::get_Current
02d7a19c: bl      #0x2b70db0                                 fn_2b70db0
02d7a1a0: adrp    x0, #0x626c000                             
02d7a1a4: ldr     x0, [x0, #0xa98]                           T:type10549(k15)
02d7a1a8: bl      #0x2b70db0                                 fn_2b70db0
02d7a1ac: adrp    x0, #0x6266000                             
02d7a1b0: ldr     x0, [x0, #0xe58]                           MS:System.Collections.Generic.List`1::Add
02d7a1b4: bl      #0x2b70db0                                 fn_2b70db0
02d7a1b8: adrp    x0, #0x626c000                             
02d7a1bc: ldr     x0, [x0, #0xaa0]                           MS:System.Collections.Generic.List`1::Contains
02d7a1c0: bl      #0x2b70db0                                 fn_2b70db0
02d7a1c4: adrp    x0, #0x626c000                             
02d7a1c8: ldr     x0, [x0, #0xaa8]                           MS:System.Collections.Generic.List`1::GetEnumerator
02d7a1cc: bl      #0x2b70db0                                 fn_2b70db0
02d7a1d0: adrp    x0, #0x6266000                             
02d7a1d4: ldr     x0, [x0, #0xe50]                           MS:System.Collections.Generic.List`1::.ctor
02d7a1d8: bl      #0x2b70db0                                 fn_2b70db0
02d7a1dc: adrp    x0, #0x626a000                             
02d7a1e0: ldr     x0, [x0, #0x668]                           MS:System.Collections.Generic.List`1::get_Count
02d7a1e4: bl      #0x2b70db0                                 fn_2b70db0
02d7a1e8: adrp    x0, #0x626a000                             
02d7a1ec: ldr     x0, [x0, #0x670]                           MS:System.Collections.Generic.List`1::get_Item
02d7a1f0: bl      #0x2b70db0                                 fn_2b70db0
02d7a1f4: adrp    x0, #0x6266000                             
02d7a1f8: ldr     x0, [x0, #0xe48]                           T:type15376(k15)
02d7a1fc: bl      #0x2b70db0                                 fn_2b70db0
02d7a200: adrp    x0, #0x6266000                             
02d7a204: ldr     x0, [x0, #0x9f0]                           T:Assets.SimpleLocalization.Scripts.LocalizationManager
02d7a208: bl      #0x2b70db0                                 fn_2b70db0
02d7a20c: adrp    x0, #0x626c000                             
02d7a210: ldr     x0, [x0, #0xab0]                           T:Assets.SimpleLocalization.Scripts.LocalizationSettings
02d7a214: bl      #0x2b70db0                                 fn_2b70db0
02d7a218: adrp    x0, #0x6263000                             
02d7a21c: ldr     x0, [x0, #0xf20]                           T:type24661(k1d)
02d7a220: bl      #0x2b70db0                                 fn_2b70db0
02d7a224: adrp    x0, #0x626c000                             
02d7a228: ldr     x0, [x0, #0xab8]                           M:Assets.SimpleLocalization.Scripts.LocalizationManager/<>c::<Read>b__9_0
02d7a22c: bl      #0x2b70db0                                 fn_2b70db0
02d7a230: adrp    x0, #0x626c000                             
02d7a234: ldr     x0, [x0, #0xac0]                           T:Assets.SimpleLocalization.Scripts.LocalizationManager/<>c
02d7a238: bl      #0x2b70db0                                 fn_2b70db0
02d7a23c: adrp    x0, #0x626c000                             
02d7a240: ldr     x0, [x0, #0xac8]                           S:'Duplicated key `'
02d7a244: bl      #0x2b70db0                                 fn_2b70db0
02d7a248: adrp    x0, #0x626c000                             
02d7a24c: ldr     x0, [x0, #0xad0]                           S:'`. This key is not loaded.'
02d7a250: bl      #0x2b70db0                                 fn_2b70db0
02d7a254: adrp    x0, #0x626c000                             
02d7a258: ldr     x0, [x0, #0xad8]                           S:'`. This sheet is not loaded.'
02d7a25c: bl      #0x2b70db0                                 fn_2b70db0
02d7a260: adrp    x0, #0x626c000                             
02d7a264: ldr     x0, [x0, #0xae0]                           S:'Duplicated languages found in `'
02d7a268: bl      #0x2b70db0                                 fn_2b70db0
02d7a26c: adrp    x0, #0x626c000                             
02d7a270: ldr     x0, [x0, #0xae8]                           S:'` found in `'
02d7a274: bl      #0x2b70db0                                 fn_2b70db0
02d7a278: adrp    x0, #0x6263000                             
02d7a27c: ldr     x0, [x0, #0xa90]                           S:''
02d7a280: bl      #0x2b70db0                                 fn_2b70db0
02d7a284: adrp    x0, #0x626c000                             
02d7a288: ldr     x0, [x0, #0xaf0]                           S:'`.'
02d7a28c: bl      #0x2b70db0                                 fn_2b70db0
02d7a290: adrp    x0, #0x626c000                             
02d7a294: ldr     x0, [x0, #0xaf8]                           S:'` in `'
02d7a298: bl      #0x2b70db0                                 fn_2b70db0
02d7a29c: mov     w8, #1                                     
02d7a2a0: strb    w8, [x19, #0x407]                          
02d7a2a4: ldr     x0, [x27]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d7a2a8: stp     xzr, xzr, [sp, #0x20]                      
02d7a2ac: str     xzr, [sp, #0x30]                           
02d7a2b0: ldr     w8, [x0, #0xe4]                            [626c0e4]=0 f=0,0
02d7a2b4: cbnz    w8, #0x2d7a2c0                             
02d7a2b8: bl      #0x2b70f30                                 fn_2b70f30
02d7a2bc: ldr     x0, [x27]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d7a2c0: ldr     x8, [x0, #0xb8]                            MS:System.Collections.Generic.List`1::Add
02d7a2c4: ldr     x0, [x8, #8]                               
02d7a2c8: cbz     x0, #0x2d7aaa8                             
02d7a2cc: adrp    x8, #0x626c000                             
02d7a2d0: ldr     x8, [x8, #0x858]                           MS:System.Collections.Generic.Dictionary`2::get_Count
02d7a2d4: ldr     x1, [x8]                                   M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d7a2d8: bl      #0x452c2d4                                 fn_452c2d4
02d7a2dc: cmp     w0, #0                                     
02d7a2e0: b.gt    #0x2d7aa20                                 
02d7a2e4: adrp    x8, #0x6266000                             
02d7a2e8: ldr     x8, [x8, #0xe48]                           T:type15376(k15)
02d7a2ec: ldr     x0, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d7a2f0: bl      #0x2b7104c                                 fn_2b7104c
02d7a2f4: adrp    x8, #0x6266000                             
02d7a2f8: mov     x19, x0                                    
02d7a2fc: ldr     x8, [x8, #0xe50]                           MS:System.Collections.Generic.List`1::.ctor
02d7a300: ldr     x1, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d7a304: bl      #0x35a89a4                                 fn_35a89a4
02d7a308: adrp    x8, #0x626c000                             
02d7a30c: ldr     x8, [x8, #0xab0]                           T:Assets.SimpleLocalization.Scripts.LocalizationSettings
02d7a310: ldr     x0, [x8]                                   M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d7a314: ldr     w8, [x0, #0xe4]                            [626c0e4]=0 f=0,0
02d7a318: cbnz    w8, #0x2d7a320                             
02d7a31c: bl      #0x2b70f30                                 fn_2b70f30
02d7a320: bl      #0x2d7b2d8                                 Assets.SimpleLocalization.Scripts.LocalizationSettings::get_Instance
02d7a324: cbz     x0, #0x2d7aaa8                             
02d7a328: ldr     x0, [x0, #0x20]                            M:Clicker.GlowSprite2DItem::<DoGlow>b__10_6
02d7a32c: str     x19, [sp]                                  
02d7a330: cbz     x0, #0x2d7aaa8                             
02d7a334: adrp    x8, #0x626c000                             
02d7a338: ldr     x8, [x8, #0xaa8]                           MS:System.Collections.Generic.List`1::GetEnumerator
02d7a33c: ldr     x1, [x8]                                   M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d7a340: add     x8, sp, #8                                 
02d7a344: bl      #0x35a9d9c                                 fn_35a9d9c
02d7a348: adrp    x29, #0x626a000                            
02d7a34c: adrp    x28, #0x626c000                            
02d7a350: ldr     x29, [x29, #0x670]                         MS:System.Collections.Generic.List`1::get_Item
02d7a354: ldr     x28, [x28, #0x860]                         MS:System.Collections.Generic.Dictionary`2::get_Item
02d7a358: ldr     x8, [sp, #0x18]                            
02d7a35c: ldur    q0, [sp, #8]                               
02d7a360: str     x8, [sp, #0x30]                            
02d7a364: add     x8, sp, #0x20                              
02d7a368: stp     xzr, x8, [sp, #8]                          
02d7a36c: str     q0, [sp, #0x20]                            
02d7a370: adrp    x8, #0x626c000                             
02d7a374: ldr     x8, [x8, #0xa88]                           MS:System.Collections.Generic.List`1/Enumerator::MoveNext
02d7a378: ldr     x1, [x8]                                   M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d7a37c: add     x0, sp, #0x20                              
02d7a380: bl      #0x4690474                                 fn_4690474
02d7a384: tbz     w0, #0, #0x2d7a9f8                         
02d7a388: ldr     x19, [sp, #0x30]                           
02d7a38c: cbz     x19, #0x2d7aa94                            
02d7a390: ldr     x0, [x19, #0x20]                           
02d7a394: cbz     x0, #0x2d7aa98                             
02d7a398: mov     x1, xzr                                    
02d7a39c: bl      #0x5b3ae10                                 UnityEngine.TextAsset::get_text
02d7a3a0: mov     x20, x0                                    
02d7a3a4: ldr     x0, [x27]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d7a3a8: ldr     w8, [x0, #0xe4]                            [626c0e4]=0 f=0,0
02d7a3ac: cbnz    w8, #0x2d7a3b4                             
02d7a3b0: bl      #0x2b70f30                                 fn_2b70f30
02d7a3b4: mov     x0, x20                                    
02d7a3b8: bl      #0x2d7b3b4                                 Assets.SimpleLocalization.Scripts.LocalizationManager::GetLines
02d7a3bc: mov     x20, x0                                    
02d7a3c0: cbz     x0, #0x2d7aa9c                             
02d7a3c4: ldr     x2, [x29]                                  T:type56879(k15)
02d7a3c8: mov     x0, x20                                    
02d7a3cc: mov     w1, wzr                                    
02d7a3d0: bl      #0x35a8f3c                                 fn_35a8f3c
02d7a3d4: cbz     x0, #0x2d7aaa0                             
02d7a3d8: mov     w1, #0x2c                                  
02d7a3dc: mov     w2, wzr                                    
02d7a3e0: mov     x3, xzr                                    
02d7a3e4: bl      #0x4ca92f8                                 System.String::Split
02d7a3e8: adrp    x8, #0x626c000                             
02d7a3ec: mov     x21, x0                                    
02d7a3f0: ldr     x8, [x8, #0xac0]                           T:Assets.SimpleLocalization.Scripts.LocalizationManager/<>c
02d7a3f4: ldr     x0, [x8]                                   M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d7a3f8: ldr     w8, [x0, #0xe4]                            [626c0e4]=0 f=0,0
02d7a3fc: cbnz    w8, #0x2d7a410                             
02d7a400: bl      #0x2b70f30                                 fn_2b70f30
02d7a404: adrp    x8, #0x626c000                             
02d7a408: ldr     x8, [x8, #0xac0]                           T:Assets.SimpleLocalization.Scripts.LocalizationManager/<>c
02d7a40c: ldr     x0, [x8]                                   M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d7a410: ldr     x8, [x0, #0xb8]                            MS:System.Collections.Generic.List`1::Add
02d7a414: ldr     x22, [x8, #8]                              M:Clicker.GlowSprite2DItem::<DoGlow>b__10_3
02d7a418: cbnz    x22, #0x2d7a484                            
02d7a41c: ldr     w9, [x0, #0xe4]                            [626c0e4]=0 f=0,0
02d7a420: cbnz    w9, #0x2d7a438                             
02d7a424: bl      #0x2b70f30                                 fn_2b70f30
02d7a428: adrp    x8, #0x626c000                             
02d7a42c: ldr     x8, [x8, #0xac0]                           T:Assets.SimpleLocalization.Scripts.LocalizationManager/<>c
02d7a430: ldr     x8, [x8]                                   M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d7a434: ldr     x8, [x8, #0xb8]                            MS:System.Collections.Generic.List`1::Add
02d7a438: ldr     x23, [x8]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d7a43c: adrp    x8, #0x626c000                             
02d7a440: ldr     x8, [x8, #0xa98]                           T:type10549(k15)
02d7a444: ldr     x0, [x8]                                   M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d7a448: bl      #0x2b7104c                                 fn_2b7104c
02d7a44c: adrp    x8, #0x626c000                             
02d7a450: mov     x22, x0                                    
02d7a454: ldr     x8, [x8, #0xab8]                           M:Assets.SimpleLocalization.Scripts.LocalizationManager/<>c::<Read>b__9_0
02d7a458: ldr     x2, [x8]                                   M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d7a45c: mov     x1, x23                                    
02d7a460: mov     x3, xzr                                    
02d7a464: bl      #0x49416f4                                 fn_49416f4
02d7a468: adrp    x8, #0x626c000                             
02d7a46c: ldr     x8, [x8, #0xac0]                           T:Assets.SimpleLocalization.Scripts.LocalizationManager/<>c
02d7a470: ldr     x8, [x8]                                   M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d7a474: ldr     x0, [x8, #0xb8]                            MS:System.Collections.Generic.List`1::Add
02d7a478: str     x22, [x0, #8]!                             
02d7a47c: mov     x1, x22                                    
02d7a480: bl      #0x2b70d54                                 fn_2b70d54
02d7a484: adrp    x8, #0x626c000                             
02d7a488: ldr     x8, [x8, #0xa78]                           MS:System.Linq.Enumerable::Select
02d7a48c: ldr     x2, [x8]                                   M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d7a490: mov     x0, x21                                    
02d7a494: mov     x1, x22                                    
02d7a498: bl      #0x3193858                                 fn_3193858
02d7a49c: adrp    x8, #0x6266000                             
02d7a4a0: ldr     x8, [x8, #0xc50]                           MS:System.Linq.Enumerable::ToList
02d7a4a4: ldr     x1, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d7a4a8: bl      #0x319eb2c                                 fn_319eb2c
02d7a4ac: mov     x21, x0                                    
02d7a4b0: cbz     x0, #0x2d7aaa4                             
02d7a4b4: adrp    x8, #0x626c000                             
02d7a4b8: ldr     w22, [x21, #0x18]                          
02d7a4bc: ldr     x8, [x8, #0xa70]                           MS:System.Linq.Enumerable::Distinct
02d7a4c0: ldr     x1, [x8]                                   M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d7a4c4: mov     x0, x21                                    
02d7a4c8: bl      #0x318806c                                 fn_318806c
02d7a4cc: adrp    x8, #0x626c000                             
02d7a4d0: ldr     x8, [x8, #0xa68]                           MS:System.Linq.Enumerable::Count
02d7a4d4: ldr     x1, [x8]                                   M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d7a4d8: bl      #0x31854d4                                 fn_31854d4
02d7a4dc: cmp     w22, w0                                    
02d7a4e0: b.ne    #0x2d7a9a8                                 
02d7a4e4: ldr     w8, [x21, #0x18]                           
02d7a4e8: cmp     w8, #2                                     
02d7a4ec: b.lt    #0x2d7a5c4                                 
02d7a4f0: mov     w22, #1                                    
02d7a4f4: ldr     x0, [x27]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d7a4f8: ldr     w8, [x0, #0xe4]                            [626c0e4]=0 f=0,0
02d7a4fc: cbnz    w8, #0x2d7a508                             
02d7a500: bl      #0x2b70f30                                 fn_2b70f30
02d7a504: ldr     x0, [x27]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d7a508: ldr     x8, [x0, #0xb8]                            MS:System.Collections.Generic.List`1::Add
02d7a50c: ldr     x2, [x29]                                  T:type56879(k15)
02d7a510: ldr     x23, [x8, #8]                              M:Clicker.GlowSprite2DItem::<DoGlow>b__10_3
02d7a514: mov     x0, x21                                    
02d7a518: mov     w1, w22                                    
02d7a51c: bl      #0x35a8f3c                                 fn_35a8f3c
02d7a520: mov     x1, x0                                     
02d7a524: cbz     x23, #0x2d7aa68                            
02d7a528: adrp    x8, #0x626c000                             
02d7a52c: ldr     x8, [x8, #0x850]                           MS:System.Collections.Generic.Dictionary`2::ContainsKey
02d7a530: ldr     x2, [x8]                                   M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d7a534: mov     x0, x23                                    
02d7a538: bl      #0x452c810                                 fn_452c810
02d7a53c: tbnz    w0, #0, #0x2d7a5b4                         
02d7a540: ldr     x0, [x27]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d7a544: ldr     w8, [x0, #0xe4]                            [626c0e4]=0 f=0,0
02d7a548: cbnz    w8, #0x2d7a554                             
02d7a54c: bl      #0x2b70f30                                 fn_2b70f30
02d7a550: ldr     x0, [x27]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d7a554: ldr     x8, [x0, #0xb8]                            MS:System.Collections.Generic.List`1::Add
02d7a558: ldr     x2, [x29]                                  T:type56879(k15)
02d7a55c: ldr     x23, [x8, #8]                              M:Clicker.GlowSprite2DItem::<DoGlow>b__10_3
02d7a560: mov     x0, x21                                    
02d7a564: mov     w1, w22                                    
02d7a568: bl      #0x35a8f3c                                 fn_35a8f3c
02d7a56c: adrp    x8, #0x6265000                             
02d7a570: mov     x24, x0                                    
02d7a574: ldr     x8, [x8, #0x2e8]                           T:type8944(k15)
02d7a578: ldr     x0, [x8]                                   M:AdsManager::<OnApplicationPause>b__26_0
02d7a57c: bl      #0x2b7104c                                 fn_2b7104c
02d7a580: adrp    x8, #0x6265000                             
02d7a584: mov     x25, x0                                    
02d7a588: ldr     x8, [x8, #0x2e0]                           MS:System.Collections.Generic.Dictionary`2::.ctor
02d7a58c: ldr     x1, [x8]                                   M:AdsManager::<OnApplicationPause>b__26_0
02d7a590: bl      #0x452b8a0                                 fn_452b8a0
02d7a594: cbz     x23, #0x2d7aa70                            
02d7a598: adrp    x8, #0x626c000                             
02d7a59c: ldr     x8, [x8, #0xa60]                           MS:System.Collections.Generic.Dictionary`2::Add
02d7a5a0: ldr     x3, [x8]                                   M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d7a5a4: mov     x0, x23                                    
02d7a5a8: mov     x1, x24                                    
02d7a5ac: mov     x2, x25                                    
02d7a5b0: bl      #0x452c61c                                 fn_452c61c
02d7a5b4: ldr     w8, [x21, #0x18]                           
02d7a5b8: add     w22, w22, #1                               
02d7a5bc: cmp     w22, w8                                    
02d7a5c0: b.lt    #0x2d7a4f4                                 
02d7a5c4: ldr     w8, [x20, #0x18]                           
02d7a5c8: cmp     w8, #2                                     
02d7a5cc: b.lt    #0x2d7a370                                 
02d7a5d0: mov     w22, #1                                    
02d7a5d4: ldr     x2, [x29]                                  T:type56879(k15)
02d7a5d8: mov     x0, x20                                    
02d7a5dc: mov     w1, w22                                    
02d7a5e0: bl      #0x35a8f3c                                 fn_35a8f3c
02d7a5e4: mov     x23, x0                                    
02d7a5e8: ldr     x0, [x27]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d7a5ec: ldr     w8, [x0, #0xe4]                            [626c0e4]=0 f=0,0
02d7a5f0: cbnz    w8, #0x2d7a5f8                             
02d7a5f4: bl      #0x2b70f30                                 fn_2b70f30
02d7a5f8: mov     x0, x23                                    
02d7a5fc: bl      #0x2d7baa0                                 Assets.SimpleLocalization.Scripts.LocalizationManager::GetColumns
02d7a600: mov     x24, x0                                    
02d7a604: cbz     x0, #0x2d7aa6c                             
02d7a608: ldr     x2, [x29]                                  T:type56879(k15)
02d7a60c: mov     x0, x24                                    
02d7a610: mov     w1, wzr                                    
02d7a614: bl      #0x35a8f3c                                 fn_35a8f3c
02d7a618: adrp    x8, #0x6263000                             
02d7a61c: mov     x23, x0                                    
02d7a620: ldr     x8, [x8, #0xa90]                           S:''
02d7a624: ldr     x1, [x8]                                   &2c5bbd4(=a9bd7bfdd503233f)
02d7a628: mov     x2, xzr                                    
02d7a62c: bl      #0x4ca52b8                                 System.String::op_Equality
02d7a630: tbnz    w0, #0, #0x2d7a994                         
02d7a634: ldr     x25, [sp]                                  
02d7a638: cbz     x25, #0x2d7aa74                            
02d7a63c: adrp    x8, #0x626c000                             
02d7a640: ldr     x8, [x8, #0xaa0]                           MS:System.Collections.Generic.List`1::Contains
02d7a644: ldr     x2, [x8]                                   M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d7a648: mov     x0, x25                                    
02d7a64c: mov     x1, x23                                    
02d7a650: bl      #0x35a95a8                                 fn_35a95a8
02d7a654: tbz     w0, #0, #0x2d7a74c                         
02d7a658: adrp    x8, #0x6263000                             
02d7a65c: ldr     x8, [x8, #0xf20]                           T:type24661(k1d)
02d7a660: ldr     x0, [x8]                                   &2c5bbd4(=a9bd7bfdd503233f)
02d7a664: mov     w1, #5                                     
02d7a668: bl      #0x2b70ea0                                 fn_2b70ea0
02d7a66c: mov     x24, x0                                    
02d7a670: cbz     x0, #0x2d7aa7c                             
02d7a674: ldr     w8, [x24, #0x18]                           
02d7a678: cbz     w8, #0x2d7aa88                             
02d7a67c: adrp    x8, #0x626c000                             
02d7a680: mov     x0, x24                                    
02d7a684: ldr     x8, [x8, #0xac8]                           S:'Duplicated key `'
02d7a688: ldr     x1, [x8]                                   M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d7a68c: str     x1, [x0, #0x20]!                           
02d7a690: bl      #0x2b70d54                                 fn_2b70d54
02d7a694: ldr     w8, [x24, #0x18]                           
02d7a698: tst     w8, #0xfffffffe                            
02d7a69c: b.eq    #0x2d7aa84                                 
02d7a6a0: mov     x0, x24                                    
02d7a6a4: str     x23, [x0, #0x28]!                          
02d7a6a8: mov     x1, x23                                    
02d7a6ac: bl      #0x2b70d54                                 fn_2b70d54
02d7a6b0: ldr     w8, [x24, #0x18]                           
02d7a6b4: cmp     w8, #2                                     
02d7a6b8: b.ls    #0x2d7aa8c                                 
02d7a6bc: adrp    x8, #0x626c000                             
02d7a6c0: mov     x0, x24                                    
02d7a6c4: ldr     x8, [x8, #0xae8]                           S:'` found in `'
02d7a6c8: ldr     x1, [x8]                                   M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d7a6cc: str     x1, [x0, #0x30]!                           
02d7a6d0: bl      #0x2b70d54                                 fn_2b70d54
02d7a6d4: ldr     w8, [x24, #0x18]                           
02d7a6d8: tst     w8, #0xfffffffc                            
02d7a6dc: b.eq    #0x2d7aa90                                 
02d7a6e0: ldr     x1, [x19, #0x10]                           ._language
02d7a6e4: mov     x0, x24                                    
02d7a6e8: str     x1, [x0, #0x38]!                           
02d7a6ec: bl      #0x2b70d54                                 fn_2b70d54
02d7a6f0: ldr     w8, [x24, #0x18]                           
02d7a6f4: cmp     w8, #4                                     
02d7a6f8: b.ls    #0x2d7aa78                                 
02d7a6fc: adrp    x8, #0x626c000                             
02d7a700: mov     x0, x24                                    
02d7a704: ldr     x8, [x8, #0xad0]                           S:'`. This key is not loaded.'
02d7a708: ldr     x1, [x8]                                   M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d7a70c: str     x1, [x0, #0x40]!                           
02d7a710: bl      #0x2b70d54                                 fn_2b70d54
02d7a714: mov     x0, x24                                    
02d7a718: mov     x1, xzr                                    
02d7a71c: bl      #0x4ca7428                                 System.String::Concat
02d7a720: adrp    x8, #0x6263000                             
02d7a724: mov     x23, x0                                    
02d7a728: ldr     x8, [x8, #0x928]                           T:UnityEngine.Debug
02d7a72c: ldr     x0, [x8]                                   &2c5bbd4(=a9bd7bfdd503233f)
02d7a730: ldr     w8, [x0, #0xe4]                            [626c0e4]=0 f=0,0
02d7a734: cbnz    w8, #0x2d7a73c                             
02d7a738: bl      #0x2b70f30                                 fn_2b70f30
02d7a73c: mov     x0, x23                                    
02d7a740: mov     x1, xzr                                    
02d7a744: bl      #0x5af2840                                 UnityEngine.Debug::LogError
02d7a748: b       #0x2d7a994                                 
02d7a74c: adrp    x9, #0x6266000                             
02d7a750: ldr     w10, [x25, #0x1c]                          
02d7a754: ldr     x8, [x25, #0x10]                           
02d7a758: ldr     x9, [x9, #0xe58]                           MS:System.Collections.Generic.List`1::Add
02d7a75c: add     w10, w10, #1                               
02d7a760: ldr     x9, [x9]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d7a764: str     w10, [x25, #0x1c]                          
02d7a768: cbz     x8, #0x2d7aa80                             
02d7a76c: ldrsw   x10, [x25, #0x18]                          
02d7a770: ldr     w11, [x8, #0x18]                           &2c5d934(=d65f03c0d503245f)
02d7a774: cmp     w10, w11                                   
02d7a778: b.hs    #0x2d7a798                                 
02d7a77c: add     x0, x8, x10, lsl #3                        &6263000
02d7a780: add     w9, w10, #1                                
02d7a784: str     w9, [x25, #0x18]                           
02d7a788: str     x23, [x0, #0x20]!                          
02d7a78c: mov     x1, x23                                    
02d7a790: bl      #0x2b70d54                                 fn_2b70d54
02d7a794: b       #0x2d7a7b0                                 
02d7a798: ldr     x8, [x9, #0x20]                            S:'inter_ad_capping_time'
02d7a79c: ldr     x8, [x8, #0xc0]                            &2c5bebc(=f9400800d503245f)
02d7a7a0: ldr     x2, [x8, #0x70]                            &2c5bd48(=a9bd7bfdd503233f)
02d7a7a4: mov     x0, x25                                    
02d7a7a8: mov     x1, x23                                    
02d7a7ac: bl      #0x35a920c                                 fn_35a920c
02d7a7b0: ldr     w8, [x21, #0x18]                           
02d7a7b4: cmp     w8, #2                                     
02d7a7b8: b.lt    #0x2d7a994                                 
02d7a7bc: mov     w25, #1                                    
02d7a7c0: ldr     x0, [x27]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d7a7c4: ldr     w8, [x0, #0xe4]                            [626c0e4]=0 f=0,0
02d7a7c8: cbnz    w8, #0x2d7a7d4                             
02d7a7cc: bl      #0x2b70f30                                 fn_2b70f30
02d7a7d0: ldr     x0, [x27]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d7a7d4: ldr     x8, [x0, #0xb8]                            MS:System.Collections.Generic.List`1::Add
02d7a7d8: ldr     x2, [x29]                                  T:type56879(k15)
02d7a7dc: ldr     x26, [x8, #8]                              &2c498b4(=d65f03c0d503245f)
02d7a7e0: mov     x0, x21                                    
02d7a7e4: mov     w1, w25                                    
02d7a7e8: bl      #0x35a8f3c                                 fn_35a8f3c
02d7a7ec: mov     x1, x0                                     
02d7a7f0: cbz     x26, #0x2d7aa40                            
02d7a7f4: ldr     x2, [x28]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d7a7f8: mov     x0, x26                                    
02d7a7fc: bl      #0x452c59c                                 fn_452c59c
02d7a800: cbz     x0, #0x2d7aa44                             
02d7a804: adrp    x8, #0x626c000                             
02d7a808: ldr     x8, [x8, #0x848]                           MS:System.Collections.Generic.Dictionary`2::ContainsKey
02d7a80c: ldr     x2, [x8]                                   M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d7a810: mov     x1, x23                                    
02d7a814: bl      #0x452c810                                 fn_452c810
02d7a818: tbz     w0, #0, #0x2d7a910                         
02d7a81c: adrp    x8, #0x6263000                             
02d7a820: ldr     x8, [x8, #0xf20]                           T:type24661(k1d)
02d7a824: ldr     x0, [x8]                                   &2c5bbd4(=a9bd7bfdd503233f)
02d7a828: mov     w1, #5                                     
02d7a82c: bl      #0x2b70ea0                                 fn_2b70ea0
02d7a830: mov     x26, x0                                    
02d7a834: cbz     x0, #0x2d7aa4c                             
02d7a838: ldr     w8, [x26, #0x18]                           
02d7a83c: cbz     w8, #0x2d7aa58                             
02d7a840: adrp    x8, #0x626c000                             
02d7a844: mov     x0, x26                                    
02d7a848: ldr     x8, [x8, #0xac8]                           S:'Duplicated key `'
02d7a84c: ldr     x1, [x8]                                   M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d7a850: str     x1, [x0, #0x20]!                           
02d7a854: bl      #0x2b70d54                                 fn_2b70d54
02d7a858: ldr     w8, [x26, #0x18]                           
02d7a85c: tst     w8, #0xfffffffe                            
02d7a860: b.eq    #0x2d7aa50                                 
02d7a864: mov     x0, x26                                    
02d7a868: str     x23, [x0, #0x28]!                          
02d7a86c: mov     x1, x23                                    
02d7a870: bl      #0x2b70d54                                 fn_2b70d54
02d7a874: ldr     w8, [x26, #0x18]                           
02d7a878: cmp     w8, #2                                     
02d7a87c: b.ls    #0x2d7aa54                                 
02d7a880: adrp    x8, #0x626c000                             
02d7a884: mov     x0, x26                                    
02d7a888: ldr     x8, [x8, #0xaf8]                           S:'` in `'
02d7a88c: ldr     x1, [x8]                                   M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d7a890: str     x1, [x0, #0x30]!                           
02d7a894: bl      #0x2b70d54                                 fn_2b70d54
02d7a898: ldr     w8, [x26, #0x18]                           
02d7a89c: tst     w8, #0xfffffffc                            
02d7a8a0: b.eq    #0x2d7aa5c                                 
02d7a8a4: ldr     x1, [x19, #0x10]                           ._language
02d7a8a8: mov     x0, x26                                    
02d7a8ac: str     x1, [x0, #0x38]!                           
02d7a8b0: bl      #0x2b70d54                                 fn_2b70d54
02d7a8b4: ldr     w8, [x26, #0x18]                           
02d7a8b8: cmp     w8, #4                                     
02d7a8bc: b.ls    #0x2d7aa60                                 
02d7a8c0: adrp    x8, #0x626c000                             
02d7a8c4: mov     x0, x26                                    
02d7a8c8: ldr     x8, [x8, #0xaf0]                           S:'`.'
02d7a8cc: ldr     x1, [x8]                                   M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d7a8d0: str     x1, [x0, #0x40]!                           
02d7a8d4: bl      #0x2b70d54                                 fn_2b70d54
02d7a8d8: mov     x0, x26                                    
02d7a8dc: mov     x1, xzr                                    
02d7a8e0: bl      #0x4ca7428                                 System.String::Concat
02d7a8e4: adrp    x8, #0x6263000                             
02d7a8e8: mov     x26, x0                                    
02d7a8ec: ldr     x8, [x8, #0x928]                           T:UnityEngine.Debug
02d7a8f0: ldr     x0, [x8]                                   &2c5bbd4(=a9bd7bfdd503233f)
02d7a8f4: ldr     w8, [x0, #0xe4]                            [626c0e4]=0 f=0,0
02d7a8f8: cbnz    w8, #0x2d7a900                             
02d7a8fc: bl      #0x2b70f30                                 fn_2b70f30
02d7a900: mov     x0, x26                                    
02d7a904: mov     x1, xzr                                    
02d7a908: bl      #0x5af2840                                 UnityEngine.Debug::LogError
02d7a90c: b       #0x2d7a984                                 
02d7a910: ldr     x0, [x27]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d7a914: ldr     w8, [x0, #0xe4]                            [626c0e4]=0 f=0,0
02d7a918: cbnz    w8, #0x2d7a924                             
02d7a91c: bl      #0x2b70f30                                 fn_2b70f30
02d7a920: ldr     x0, [x27]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d7a924: ldr     x8, [x0, #0xb8]                            MS:System.Collections.Generic.List`1::Add
02d7a928: ldr     x2, [x29]                                  T:type56879(k15)
02d7a92c: ldr     x26, [x8, #8]                              &2c498b4(=d65f03c0d503245f)
02d7a930: mov     x0, x21                                    
02d7a934: mov     w1, w25                                    
02d7a938: bl      #0x35a8f3c                                 fn_35a8f3c
02d7a93c: mov     x1, x0                                     
02d7a940: cbz     x26, #0x2d7aa48                            
02d7a944: ldr     x2, [x28]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d7a948: mov     x0, x26                                    
02d7a94c: bl      #0x452c59c                                 fn_452c59c
02d7a950: mov     x26, x0                                    
02d7a954: ldr     x2, [x29]                                  T:type56879(k15)
02d7a958: mov     x0, x24                                    
02d7a95c: mov     w1, w25                                    
02d7a960: bl      #0x35a8f3c                                 fn_35a8f3c
02d7a964: cbz     x26, #0x2d7aa64                            
02d7a968: adrp    x8, #0x6265000                             
02d7a96c: mov     x2, x0                                     
02d7a970: ldr     x8, [x8, #0x2d8]                           MS:System.Collections.Generic.Dictionary`2::Add
02d7a974: ldr     x3, [x8]                                   M:AdsManager::<OnApplicationPause>b__26_0
02d7a978: mov     x0, x26                                    
02d7a97c: mov     x1, x23                                    
02d7a980: bl      #0x452c61c                                 fn_452c61c
02d7a984: ldr     w8, [x21, #0x18]                           
02d7a988: add     w25, w25, #1                               
02d7a98c: cmp     w25, w8                                    
02d7a990: b.lt    #0x2d7a7c0                                 
02d7a994: ldr     w8, [x20, #0x18]                           
02d7a998: add     w22, w22, #1                               
02d7a99c: cmp     w22, w8                                    
02d7a9a0: b.lt    #0x2d7a5d4                                 
02d7a9a4: b       #0x2d7a370                                 
02d7a9a8: adrp    x8, #0x626c000                             
02d7a9ac: ldr     x1, [x19, #0x10]                           ._language
02d7a9b0: ldr     x8, [x8, #0xae0]                           S:'Duplicated languages found in `'
02d7a9b4: ldr     x0, [x8]                                   M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d7a9b8: adrp    x8, #0x626c000                             
02d7a9bc: ldr     x8, [x8, #0xad8]                           S:'`. This sheet is not loaded.'
02d7a9c0: ldr     x2, [x8]                                   M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d7a9c4: mov     x3, xzr                                    
02d7a9c8: bl      #0x4ca6dbc                                 System.String::Concat
02d7a9cc: adrp    x8, #0x6263000                             
02d7a9d0: mov     x20, x0                                    
02d7a9d4: ldr     x8, [x8, #0x928]                           T:UnityEngine.Debug
02d7a9d8: ldr     x0, [x8]                                   &2c5bbd4(=a9bd7bfdd503233f)
02d7a9dc: ldr     w8, [x0, #0xe4]                            [626c0e4]=0 f=0,0
02d7a9e0: cbnz    w8, #0x2d7a9e8                             
02d7a9e4: bl      #0x2b70f30                                 fn_2b70f30
02d7a9e8: mov     x0, x20                                    
02d7a9ec: mov     x1, xzr                                    
02d7a9f0: bl      #0x5af2840                                 UnityEngine.Debug::LogError
02d7a9f4: b       #0x2d7a370                                 
02d7a9f8: adrp    x8, #0x626c000                             
02d7a9fc: add     x0, sp, #0x20                              
02d7aa00: ldr     x8, [x8, #0xa80]                           MS:System.Collections.Generic.List`1/Enumerator::Dispose
02d7aa04: ldr     x1, [x8]                                   M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d7aa08: bl      #0x4690470                                 fn_4690470
02d7aa0c: ldr     x0, [x27]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d7aa10: ldr     w8, [x0, #0xe4]                            [626c0e4]=0 f=0,0
02d7aa14: cbnz    w8, #0x2d7aa1c                             
02d7aa18: bl      #0x2b70f30                                 fn_2b70f30
02d7aa1c: bl      #0x2d7b274                                 Assets.SimpleLocalization.Scripts.LocalizationManager::AutoLanguage
02d7aa20: ldp     x20, x19, [sp, #0x90]                      
02d7aa24: ldp     x22, x21, [sp, #0x80]                      
02d7aa28: ldp     x24, x23, [sp, #0x70]                      
02d7aa2c: ldp     x26, x25, [sp, #0x60]                      
02d7aa30: ldp     x28, x27, [sp, #0x50]                      
02d7aa34: ldp     x29, x30, [sp, #0x40]                      
02d7aa38: add     sp, sp, #0xa0                              
02d7aa3c: ret                                                
02d7aa40: bl      #0x2b7105c                                 fn_2b7105c
02d7aa44: bl      #0x2b7105c                                 fn_2b7105c
02d7aa48: bl      #0x2b7105c                                 fn_2b7105c
02d7aa4c: bl      #0x2b7105c                                 fn_2b7105c
02d7aa50: bl      #0x2b71064                                 fn_2b71064
02d7aa54: bl      #0x2b71064                                 fn_2b71064
02d7aa58: bl      #0x2b71064                                 fn_2b71064
02d7aa5c: bl      #0x2b71064                                 fn_2b71064
02d7aa60: bl      #0x2b71064                                 fn_2b71064
02d7aa64: bl      #0x2b7105c                                 fn_2b7105c
02d7aa68: bl      #0x2b7105c                                 fn_2b7105c
02d7aa6c: bl      #0x2b7105c                                 fn_2b7105c
02d7aa70: bl      #0x2b7105c                                 fn_2b7105c
02d7aa74: bl      #0x2b7105c                                 fn_2b7105c
02d7aa78: bl      #0x2b71064                                 fn_2b71064
02d7aa7c: bl      #0x2b7105c                                 fn_2b7105c
02d7aa80: bl      #0x2b7105c                                 fn_2b7105c
02d7aa84: bl      #0x2b71064                                 fn_2b71064
02d7aa88: bl      #0x2b71064                                 fn_2b71064
02d7aa8c: bl      #0x2b71064                                 fn_2b71064
02d7aa90: bl      #0x2b71064                                 fn_2b71064
02d7aa94: bl      #0x2b7105c                                 fn_2b7105c
02d7aa98: bl      #0x2b7105c                                 fn_2b7105c
02d7aa9c: bl      #0x2b7105c                                 fn_2b7105c
02d7aaa0: bl      #0x2b7105c                                 fn_2b7105c
02d7aaa4: bl      #0x2b7105c                                 fn_2b7105c
02d7aaa8: bl      #0x2b7105c                                 fn_2b7105c
02d7aaac: b       #0x2d7abbc                                 
02d7aab0: b       #0x2d7abbc                                 
02d7aab4: b       #0x2d7abbc                                 
02d7aab8: b       #0x2d7abbc                                 
02d7aabc: b       #0x2d7abbc                                 
02d7aac0: b       #0x2d7abbc                                 
02d7aac4: b       #0x2d7abbc                                 
02d7aac8: b       #0x2d7abbc                                 
02d7aacc: b       #0x2d7abbc                                 
02d7aad0: b       #0x2d7abbc                                 
02d7aad4: b       #0x2d7abbc                                 
02d7aad8: b       #0x2d7abbc                                 
02d7aadc: b       #0x2d7abbc                                 
02d7aae0: b       #0x2d7abbc                                 
02d7aae4: b       #0x2d7abbc                                 
02d7aae8: b       #0x2d7abbc                                 
02d7aaec: b       #0x2d7abbc                                 
02d7aaf0: b       #0x2d7abbc                                 
02d7aaf4: b       #0x2d7abbc                                 
02d7aaf8: b       #0x2d7abbc                                 
02d7aafc: b       #0x2d7abbc                                 
02d7ab00: b       #0x2d7abbc                                 
02d7ab04: b       #0x2d7abbc                                 
02d7ab08: b       #0x2d7abbc                                 
02d7ab0c: b       #0x2d7abbc                                 
02d7ab10: b       #0x2d7abbc                                 
02d7ab14: b       #0x2d7abbc                                 
02d7ab18: b       #0x2d7abbc                                 
02d7ab1c: b       #0x2d7abbc                                 
02d7ab20: b       #0x2d7abbc                                 
02d7ab24: b       #0x2d7abbc                                 
02d7ab28: b       #0x2d7abbc                                 
02d7ab2c: b       #0x2d7abbc                                 
02d7ab30: b       #0x2d7abbc                                 
02d7ab34: b       #0x2d7abbc                                 
02d7ab38: b       #0x2d7abbc                                 
02d7ab3c: b       #0x2d7abbc                                 
02d7ab40: b       #0x2d7abbc                                 
02d7ab44: b       #0x2d7abbc                                 
02d7ab48: b       #0x2d7abbc                                 
02d7ab4c: b       #0x2d7abbc                                 
02d7ab50: b       #0x2d7abbc                                 
02d7ab54: b       #0x2d7abbc                                 
02d7ab58: b       #0x2d7abbc                                 
02d7ab5c: b       #0x2d7abbc                                 
02d7ab60: b       #0x2d7abbc                                 
02d7ab64: b       #0x2d7abbc                                 
02d7ab68: b       #0x2d7abbc                                 
02d7ab6c: b       #0x2d7abbc                                 
02d7ab70: b       #0x2d7abbc                                 
02d7ab74: b       #0x2d7abbc                                 
02d7ab78: b       #0x2d7abbc                                 
02d7ab7c: b       #0x2d7abbc                                 
02d7ab80: b       #0x2d7abbc                                 
02d7ab84: b       #0x2d7abbc                                 
02d7ab88: b       #0x2d7abbc                                 
02d7ab8c: b       #0x2d7abbc                                 
02d7ab90: b       #0x2d7abbc                                 
02d7ab94: b       #0x2d7abbc                                 
02d7ab98: b       #0x2d7abbc                                 
02d7ab9c: b       #0x2d7abbc                                 
02d7aba0: b       #0x2d7abbc                                 
02d7aba4: b       #0x2d7abbc                                 
02d7aba8: b       #0x2d7abbc                                 
02d7abac: b       #0x2d7abbc                                 
02d7abb0: b       #0x2d7abbc                                 
02d7abb4: b       #0x2d7abbc                                 
02d7abb8: b       #0x2d7abbc                                 
02d7abbc: mov     x19, x0                                    
02d7abc0: cmp     w1, #1                                     
02d7abc4: b.ne    #0x2d7ac00                                 
02d7abc8: mov     x0, x19                                    
02d7abcc: bl      #0x5e90260                                 fn_5e90260
02d7abd0: ldr     x19, [x0]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d7abd4: str     x19, [sp, #8]                              
02d7abd8: bl      #0x5e90270                                 fn_5e90270
02d7abdc: adrp    x8, #0x626c000                             
02d7abe0: ldr     x8, [x8, #0xa80]                           MS:System.Collections.Generic.List`1/Enumerator::Dispose
02d7abe4: ldr     x0, [sp, #0x10]                            
02d7abe8: ldr     x1, [x8]                                   M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d7abec: bl      #0x4690470                                 fn_4690470
02d7abf0: cbz     x19, #0x2d7aa0c                            
02d7abf4: mov     x0, x19                                    
02d7abf8: bl      #0x2b71054                                 fn_2b71054
02d7abfc: mov     x19, x0                                    
02d7ac00: add     x0, sp, #8                                 
02d7ac04: bl      #0x27388e8                                 fn_27388e8
02d7ac08: mov     x0, x19                                    
02d7ac0c: bl      #0x2c6051c                                 fn_2c6051c
02d7ac10: bl      #0x27369b8                                 fn_27369b8
## HasKey(string localizationKey) -> bool
---- Assets.SimpleLocalization.Scripts.LocalizationManager::HasKey 0x2d7bc84
02d7bc84: str     x30, [sp, #-0x30]!                         
02d7bc88: stp     x22, x21, [sp, #0x10]                      
02d7bc8c: stp     x20, x19, [sp, #0x20]                      
02d7bc90: adrp    x21, #0x6630000                            
02d7bc94: adrp    x20, #0x6266000                            
02d7bc98: mov     x19, x0                                    
02d7bc9c: ldrb    w8, [x21, #0x408]                          
02d7bca0: ldr     x20, [x20, #0x9f0]                         T:Assets.SimpleLocalization.Scripts.LocalizationManager
02d7bca4: tbnz    w8, #0, #0x2d7bce0                         
02d7bca8: adrp    x0, #0x626c000                             
02d7bcac: ldr     x0, [x0, #0x848]                           MS:System.Collections.Generic.Dictionary`2::ContainsKey
02d7bcb0: bl      #0x2b70db0                                 fn_2b70db0
02d7bcb4: adrp    x0, #0x626c000                             
02d7bcb8: ldr     x0, [x0, #0x850]                           MS:System.Collections.Generic.Dictionary`2::ContainsKey
02d7bcbc: bl      #0x2b70db0                                 fn_2b70db0
02d7bcc0: adrp    x0, #0x626c000                             
02d7bcc4: ldr     x0, [x0, #0x860]                           MS:System.Collections.Generic.Dictionary`2::get_Item
02d7bcc8: bl      #0x2b70db0                                 fn_2b70db0
02d7bccc: adrp    x0, #0x6266000                             
02d7bcd0: ldr     x0, [x0, #0x9f0]                           T:Assets.SimpleLocalization.Scripts.LocalizationManager
02d7bcd4: bl      #0x2b70db0                                 fn_2b70db0
02d7bcd8: mov     w8, #1                                     
02d7bcdc: strb    w8, [x21, #0x408]                          
02d7bce0: ldr     x0, [x20]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d7bce4: ldr     w8, [x0, #0xe4]                            [62660e4]=0 f=0,0
02d7bce8: cbnz    w8, #0x2d7bcf4                             
02d7bcec: bl      #0x2b70f30                                 fn_2b70f30
02d7bcf0: ldr     x0, [x20]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d7bcf4: ldr     x8, [x0, #0xb8]                            S:'banner_native_refresh_time'
02d7bcf8: adrp    x22, #0x662f000                            
02d7bcfc: ldrb    w9, [x22, #0xbdb]                          
02d7bd00: ldr     x21, [x8, #8]                              
02d7bd04: cbnz    w9, #0x2d7bd1c                             
02d7bd08: mov     x0, x20                                    
02d7bd0c: bl      #0x2b70db0                                 fn_2b70db0
02d7bd10: ldr     x0, [x20]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d7bd14: mov     w8, #1                                     
02d7bd18: strb    w8, [x22, #0xbdb]                          
02d7bd1c: ldr     w8, [x0, #0xe4]                            [62660e4]=0 f=0,0
02d7bd20: cbnz    w8, #0x2d7bd2c                             
02d7bd24: bl      #0x2b70f30                                 fn_2b70f30
02d7bd28: ldr     x0, [x20]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d7bd2c: cbz     x21, #0x2d7bdf0                            
02d7bd30: adrp    x8, #0x626c000                             
02d7bd34: ldr     x8, [x8, #0x850]                           MS:System.Collections.Generic.Dictionary`2::ContainsKey
02d7bd38: ldr     x9, [x0, #0xb8]                            S:'banner_native_refresh_time'
02d7bd3c: mov     x0, x21                                    
02d7bd40: ldr     x1, [x9, #0x10]                            
02d7bd44: ldr     x2, [x8]                                   M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d7bd48: bl      #0x452c810                                 fn_452c810
02d7bd4c: tbz     w0, #0, #0x2d7bddc                         
02d7bd50: ldr     x0, [x20]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d7bd54: ldr     w8, [x0, #0xe4]                            [62660e4]=0 f=0,0
02d7bd58: cbnz    w8, #0x2d7bd64                             
02d7bd5c: bl      #0x2b70f30                                 fn_2b70f30
02d7bd60: ldr     x0, [x20]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d7bd64: ldr     x8, [x0, #0xb8]                            S:'banner_native_refresh_time'
02d7bd68: ldrb    w9, [x22, #0xbdb]                          
02d7bd6c: ldr     x21, [x8, #8]                              M:Clicker.GlowSprite2DItem::<DoGlow>b__10_3
02d7bd70: cbnz    w9, #0x2d7bd88                             
02d7bd74: mov     x0, x20                                    
02d7bd78: bl      #0x2b70db0                                 fn_2b70db0
02d7bd7c: ldr     x0, [x20]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d7bd80: mov     w8, #1                                     
02d7bd84: strb    w8, [x22, #0xbdb]                          
02d7bd88: ldr     w8, [x0, #0xe4]                            [62660e4]=0 f=0,0
02d7bd8c: cbnz    w8, #0x2d7bd98                             
02d7bd90: bl      #0x2b70f30                                 fn_2b70f30
02d7bd94: ldr     x0, [x20]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d7bd98: cbz     x21, #0x2d7bdf0                            
02d7bd9c: adrp    x9, #0x626c000                             
02d7bda0: ldr     x8, [x0, #0xb8]                            S:'banner_native_refresh_time'
02d7bda4: mov     x0, x21                                    
02d7bda8: ldr     x9, [x9, #0x860]                           MS:System.Collections.Generic.Dictionary`2::get_Item
02d7bdac: ldr     x1, [x8, #0x10]                            M:Clicker.GlowSprite2DItem::<DoGlow>b__10_4
02d7bdb0: ldr     x2, [x9]                                   M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d7bdb4: bl      #0x452c59c                                 fn_452c59c
02d7bdb8: cbz     x0, #0x2d7bdf0                             
02d7bdbc: adrp    x8, #0x626c000                             
02d7bdc0: mov     x1, x19                                    
02d7bdc4: ldr     x8, [x8, #0x848]                           MS:System.Collections.Generic.Dictionary`2::ContainsKey
02d7bdc8: ldp     x20, x19, [sp, #0x20]                      
02d7bdcc: ldp     x22, x21, [sp, #0x10]                      
02d7bdd0: ldr     x2, [x8]                                   M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d7bdd4: ldr     x30, [sp], #0x30                           
02d7bdd8: b       #0x452c810                                 
02d7bddc: ldp     x20, x19, [sp, #0x20]                      
02d7bde0: mov     w0, wzr                                    
02d7bde4: ldp     x22, x21, [sp, #0x10]                      
02d7bde8: ldr     x30, [sp], #0x30                           
02d7bdec: ret                                                
02d7bdf0: bl      #0x2b7105c                                 fn_2b7105c
## Localize(string localizationKey) -> string
---- Assets.SimpleLocalization.Scripts.LocalizationManager::Localize 0x2d76794
02d76794: str     x30, [sp, #-0x50]!                         
02d76798: stp     x26, x25, [sp, #0x10]                      
02d7679c: stp     x24, x23, [sp, #0x20]                      
02d767a0: stp     x22, x21, [sp, #0x30]                      
02d767a4: stp     x20, x19, [sp, #0x40]                      
02d767a8: adrp    x21, #0x6630000                            
02d767ac: adrp    x20, #0x6266000                            
02d767b0: mov     x19, x0                                    
02d767b4: ldrb    w8, [x21, #0x409]                          
02d767b8: ldr     x20, [x20, #0x9f0]                         T:Assets.SimpleLocalization.Scripts.LocalizationManager
02d767bc: tbnz    w8, #0, #0x2d76864                         
02d767c0: adrp    x0, #0x6263000                             
02d767c4: ldr     x0, [x0, #0x928]                           T:UnityEngine.Debug
02d767c8: bl      #0x2b70db0                                 fn_2b70db0
02d767cc: adrp    x0, #0x626c000                             
02d767d0: ldr     x0, [x0, #0x848]                           MS:System.Collections.Generic.Dictionary`2::ContainsKey
02d767d4: bl      #0x2b70db0                                 fn_2b70db0
02d767d8: adrp    x0, #0x626c000                             
02d767dc: ldr     x0, [x0, #0x850]                           MS:System.Collections.Generic.Dictionary`2::ContainsKey
02d767e0: bl      #0x2b70db0                                 fn_2b70db0
02d767e4: adrp    x0, #0x626c000                             
02d767e8: ldr     x0, [x0, #0x858]                           MS:System.Collections.Generic.Dictionary`2::get_Count
02d767ec: bl      #0x2b70db0                                 fn_2b70db0
02d767f0: adrp    x0, #0x626c000                             
02d767f4: ldr     x0, [x0, #0x860]                           MS:System.Collections.Generic.Dictionary`2::get_Item
02d767f8: bl      #0x2b70db0                                 fn_2b70db0
02d767fc: adrp    x0, #0x6265000                             
02d76800: ldr     x0, [x0, #0x9b8]                           MS:System.Collections.Generic.Dictionary`2::get_Item
02d76804: bl      #0x2b70db0                                 fn_2b70db0
02d76808: adrp    x0, #0x6266000                             
02d7680c: ldr     x0, [x0, #0x9f0]                           T:Assets.SimpleLocalization.Scripts.LocalizationManager
02d76810: bl      #0x2b70db0                                 fn_2b70db0
02d76814: adrp    x0, #0x6263000                             
02d76818: ldr     x0, [x0, #0xf20]                           T:type24661(k1d)
02d7681c: bl      #0x2b70db0                                 fn_2b70db0
02d76820: adrp    x0, #0x626c000                             
02d76824: ldr     x0, [x0, #0x868]                           S:').'
02d76828: bl      #0x2b70db0                                 fn_2b70db0
02d7682c: adrp    x0, #0x626c000                             
02d76830: ldr     x0, [x0, #0x870]                           S:'Translation not found: '
02d76834: bl      #0x2b70db0                                 fn_2b70db0
02d76838: adrp    x0, #0x626c000                             
02d7683c: ldr     x0, [x0, #0x878]                           S:' ('
02d76840: bl      #0x2b70db0                                 fn_2b70db0
02d76844: adrp    x0, #0x6263000                             
02d76848: ldr     x0, [x0, #0xa90]                           S:''
02d7684c: bl      #0x2b70db0                                 fn_2b70db0
02d76850: adrp    x0, #0x6266000                             
02d76854: ldr     x0, [x0, #0xbc0]                           S:'English'
02d76858: bl      #0x2b70db0                                 fn_2b70db0
02d7685c: mov     w8, #1                                     
02d76860: strb    w8, [x21, #0x409]                          
02d76864: ldr     x0, [x20]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d76868: ldr     w8, [x0, #0xe4]                            [62660e4]=0 f=0,0
02d7686c: cbnz    w8, #0x2d76878                             
02d76870: bl      #0x2b70f30                                 fn_2b70f30
02d76874: ldr     x0, [x20]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d76878: ldr     x8, [x0, #0xb8]                            S:'banner_native_refresh_time'
02d7687c: ldr     x0, [x8, #8]                               
02d76880: cbz     x0, #0x2d76c78                             
02d76884: adrp    x8, #0x626c000                             
02d76888: ldr     x8, [x8, #0x858]                           MS:System.Collections.Generic.Dictionary`2::get_Count
02d7688c: ldr     x1, [x8]                                   M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d76890: bl      #0x452c2d4                                 fn_452c2d4
02d76894: cbnz    w0, #0x2d768ac                             
02d76898: ldr     x0, [x20]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d7689c: ldr     w8, [x0, #0xe4]                            [62660e4]=0 f=0,0
02d768a0: cbnz    w8, #0x2d768a8                             
02d768a4: bl      #0x2b70f30                                 fn_2b70f30
02d768a8: bl      #0x2d7a0b0                                 Assets.SimpleLocalization.Scripts.LocalizationManager::Read
02d768ac: ldr     x0, [x20]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d768b0: ldr     w8, [x0, #0xe4]                            [62660e4]=0 f=0,0
02d768b4: cbnz    w8, #0x2d768c0                             
02d768b8: bl      #0x2b70f30                                 fn_2b70f30
02d768bc: ldr     x0, [x20]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d768c0: ldr     x8, [x0, #0xb8]                            S:'banner_native_refresh_time'
02d768c4: adrp    x25, #0x662f000                            
02d768c8: ldrb    w9, [x25, #0xbdb]                          
02d768cc: ldr     x21, [x8, #8]                              M:Clicker.GlowSprite2DItem::<DoGlow>b__10_3
02d768d0: cbnz    w9, #0x2d768e8                             
02d768d4: mov     x0, x20                                    
02d768d8: bl      #0x2b70db0                                 fn_2b70db0
02d768dc: ldr     x0, [x20]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d768e0: mov     w8, #1                                     
02d768e4: strb    w8, [x25, #0xbdb]                          
02d768e8: ldr     w8, [x0, #0xe4]                            [62660e4]=0 f=0,0
02d768ec: cbnz    w8, #0x2d768f8                             
02d768f0: bl      #0x2b70f30                                 fn_2b70f30
02d768f4: ldr     x0, [x20]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d768f8: cbz     x21, #0x2d76c78                            
02d768fc: adrp    x8, #0x626c000                             
02d76900: ldr     x8, [x8, #0x850]                           MS:System.Collections.Generic.Dictionary`2::ContainsKey
02d76904: ldr     x9, [x0, #0xb8]                            S:'banner_native_refresh_time'
02d76908: mov     x0, x21                                    
02d7690c: ldr     x1, [x9, #0x10]                            
02d76910: ldr     x2, [x8]                                   M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d76914: bl      #0x452c810                                 fn_452c810
02d76918: tbz     w0, #0, #0x2d76c80                         
02d7691c: ldr     x0, [x20]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d76920: ldr     w8, [x0, #0xe4]                            [62660e4]=0 f=0,0
02d76924: cbnz    w8, #0x2d76930                             
02d76928: bl      #0x2b70f30                                 fn_2b70f30
02d7692c: ldr     x0, [x20]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d76930: ldr     x8, [x0, #0xb8]                            S:'banner_native_refresh_time'
02d76934: ldrb    w9, [x25, #0xbdb]                          
02d76938: ldr     x21, [x8, #8]                              M:Clicker.GlowSprite2DItem::<DoGlow>b__10_3
02d7693c: cbnz    w9, #0x2d76954                             
02d76940: mov     x0, x20                                    
02d76944: bl      #0x2b70db0                                 fn_2b70db0
02d76948: ldr     x0, [x20]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d7694c: mov     w8, #1                                     
02d76950: strb    w8, [x25, #0xbdb]                          
02d76954: ldr     w8, [x0, #0xe4]                            [62660e4]=0 f=0,0
02d76958: cbnz    w8, #0x2d76964                             
02d7695c: bl      #0x2b70f30                                 fn_2b70f30
02d76960: ldr     x0, [x20]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d76964: cbz     x21, #0x2d76c78                            
02d76968: adrp    x24, #0x626c000                            
02d7696c: ldr     x24, [x24, #0x860]                         MS:System.Collections.Generic.Dictionary`2::get_Item
02d76970: ldr     x8, [x0, #0xb8]                            S:'banner_native_refresh_time'
02d76974: mov     x0, x21                                    
02d76978: ldr     x1, [x8, #0x10]                            M:Clicker.GlowSprite2DItem::<DoGlow>b__10_4
02d7697c: ldr     x2, [x24]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d76980: bl      #0x452c59c                                 fn_452c59c
02d76984: cbz     x0, #0x2d76c78                             
02d76988: adrp    x26, #0x626c000                            
02d7698c: adrp    x23, #0x6265000                            
02d76990: mov     x1, x19                                    
02d76994: ldr     x26, [x26, #0x848]                         MS:System.Collections.Generic.Dictionary`2::ContainsKey
02d76998: ldr     x23, [x23, #0x9b8]                         MS:System.Collections.Generic.Dictionary`2::get_Item
02d7699c: ldr     x2, [x26]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d769a0: bl      #0x452c810                                 fn_452c810
02d769a4: tbz     w0, #0, #0x2d76a30                         
02d769a8: ldr     x0, [x20]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d769ac: ldr     w8, [x0, #0xe4]                            [62660e4]=0 f=0,0
02d769b0: cbnz    w8, #0x2d769bc                             
02d769b4: bl      #0x2b70f30                                 fn_2b70f30
02d769b8: ldr     x0, [x20]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d769bc: ldr     x8, [x0, #0xb8]                            S:'banner_native_refresh_time'
02d769c0: ldrb    w9, [x25, #0xbdb]                          
02d769c4: ldr     x21, [x8, #8]                              M:Clicker.GlowSprite2DItem::<DoGlow>b__10_3
02d769c8: cbnz    w9, #0x2d769e0                             
02d769cc: mov     x0, x20                                    
02d769d0: bl      #0x2b70db0                                 fn_2b70db0
02d769d4: ldr     x0, [x20]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d769d8: mov     w8, #1                                     
02d769dc: strb    w8, [x25, #0xbdb]                          
02d769e0: ldr     w8, [x0, #0xe4]                            [62660e4]=0 f=0,0
02d769e4: cbnz    w8, #0x2d769f0                             
02d769e8: bl      #0x2b70f30                                 fn_2b70f30
02d769ec: ldr     x0, [x20]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d769f0: cbz     x21, #0x2d76c78                            
02d769f4: ldr     x8, [x0, #0xb8]                            S:'banner_native_refresh_time'
02d769f8: ldr     x2, [x24]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d769fc: mov     x0, x21                                    
02d76a00: ldr     x1, [x8, #0x10]                            M:Clicker.GlowSprite2DItem::<DoGlow>b__10_4
02d76a04: bl      #0x452c59c                                 fn_452c59c
02d76a08: cbz     x0, #0x2d76c78                             
02d76a0c: ldr     x2, [x23]                                  M:AdsManager::<OnApplicationPause>b__26_0
02d76a10: mov     x1, x19                                    
02d76a14: bl      #0x452c59c                                 fn_452c59c
02d76a18: adrp    x8, #0x6263000                             
02d76a1c: mov     x2, xzr                                    
02d76a20: ldr     x8, [x8, #0xa90]                           S:''
02d76a24: ldr     x1, [x8]                                   &2c5bbd4(=a9bd7bfdd503233f)
02d76a28: bl      #0x4ca52b8                                 System.String::op_Equality
02d76a2c: tbz     w0, #0, #0x2d76bf4                         
02d76a30: adrp    x8, #0x6263000                             
02d76a34: mov     w1, #5                                     
02d76a38: ldr     x8, [x8, #0xf20]                           T:type24661(k1d)
02d76a3c: ldr     x0, [x8]                                   &2c5bbd4(=a9bd7bfdd503233f)
02d76a40: bl      #0x2b70ea0                                 fn_2b70ea0
02d76a44: cbz     x0, #0x2d76c78                             
02d76a48: ldr     w8, [x0, #0x18]                            S:'level_show_popuprate'
02d76a4c: mov     x21, x0                                    
02d76a50: cbz     w8, #0x2d76c7c                             
02d76a54: adrp    x8, #0x626c000                             
02d76a58: mov     x22, x21                                   
02d76a5c: ldr     x8, [x8, #0x870]                           S:'Translation not found: '
02d76a60: ldr     x1, [x8]                                   M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d76a64: str     x1, [x22, #0x20]!                          
02d76a68: mov     x0, x22                                    
02d76a6c: bl      #0x2b70d54                                 fn_2b70d54
02d76a70: ldur    w8, [x22, #-8]                             
02d76a74: tst     w8, #0xfffffffe                            
02d76a78: b.eq    #0x2d76c7c                                 
02d76a7c: mov     x22, x21                                   
02d76a80: mov     x1, x19                                    
02d76a84: str     x19, [x22, #0x28]!                         
02d76a88: mov     x0, x22                                    
02d76a8c: bl      #0x2b70d54                                 fn_2b70d54
02d76a90: ldur    w8, [x22, #-0x10]                          
02d76a94: cmp     w8, #2                                     
02d76a98: b.ls    #0x2d76c7c                                 
02d76a9c: adrp    x8, #0x626c000                             
02d76aa0: mov     x0, x21                                    
02d76aa4: ldr     x8, [x8, #0x878]                           S:' ('
02d76aa8: ldr     x1, [x8]                                   M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d76aac: str     x1, [x0, #0x30]!                           
02d76ab0: bl      #0x2b70d54                                 fn_2b70d54
02d76ab4: ldr     x0, [x20]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d76ab8: ldr     w8, [x0, #0xe4]                            [62660e4]=0 f=0,0
02d76abc: cbnz    w8, #0x2d76ac4                             
02d76ac0: bl      #0x2b70f30                                 fn_2b70f30
02d76ac4: ldrb    w8, [x25, #0xbdb]                          
02d76ac8: cbnz    w8, #0x2d76ae0                             
02d76acc: adrp    x0, #0x6266000                             
02d76ad0: ldr     x0, [x0, #0x9f0]                           T:Assets.SimpleLocalization.Scripts.LocalizationManager
02d76ad4: bl      #0x2b70db0                                 fn_2b70db0
02d76ad8: mov     w8, #1                                     
02d76adc: strb    w8, [x25, #0xbdb]                          
02d76ae0: ldr     x0, [x20]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d76ae4: ldr     w8, [x0, #0xe4]                            [62660e4]=0 f=0,0
02d76ae8: cbnz    w8, #0x2d76af4                             
02d76aec: bl      #0x2b70f30                                 fn_2b70f30
02d76af0: ldr     x0, [x20]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d76af4: ldr     w8, [x21, #0x18]                           
02d76af8: tst     w8, #0xfffffffc                            
02d76afc: b.eq    #0x2d76c7c                                 
02d76b00: ldr     x8, [x0, #0xb8]                            S:'banner_native_refresh_time'
02d76b04: mov     x22, x21                                   
02d76b08: ldr     x1, [x8, #0x10]                            M:Clicker.GlowSprite2DItem::<DoGlow>b__10_4
02d76b0c: str     x1, [x22, #0x38]!                          
02d76b10: mov     x0, x22                                    
02d76b14: bl      #0x2b70d54                                 fn_2b70d54
02d76b18: ldur    w8, [x22, #-0x20]                          
02d76b1c: cmp     w8, #4                                     
02d76b20: b.ls    #0x2d76c7c                                 
02d76b24: adrp    x8, #0x626c000                             
02d76b28: adrp    x22, #0x6263000                            
02d76b2c: mov     x0, x21                                    
02d76b30: ldr     x8, [x8, #0x868]                           S:').'
02d76b34: ldr     x1, [x8]                                   M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d76b38: ldr     x22, [x22, #0x928]                         T:UnityEngine.Debug
02d76b3c: str     x1, [x0, #0x40]!                           
02d76b40: bl      #0x2b70d54                                 fn_2b70d54
02d76b44: mov     x0, x21                                    
02d76b48: mov     x1, xzr                                    
02d76b4c: bl      #0x4ca7428                                 System.String::Concat
02d76b50: ldr     x8, [x22]                                  &2c5bbd4(=a9bd7bfdd503233f)
02d76b54: mov     x21, x0                                    
02d76b58: ldr     w9, [x8, #0xe4]                            [626c0e4]=0 f=0,0
02d76b5c: cbnz    w9, #0x2d76b68                             
02d76b60: mov     x0, x8                                     
02d76b64: bl      #0x2b70f30                                 fn_2b70f30
02d76b68: mov     x0, x21                                    
02d76b6c: mov     x1, xzr                                    
02d76b70: bl      #0x5af2c94                                 UnityEngine.Debug::LogWarning
02d76b74: ldr     x8, [x20]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d76b78: ldr     x8, [x8, #0xb8]                            MS:System.Collections.Generic.List`1::Add
02d76b7c: ldr     x0, [x8, #8]                               M:Clicker.GlowSprite2DItem::<DoGlow>b__10_3
02d76b80: cbz     x0, #0x2d76c78                             
02d76b84: adrp    x21, #0x6266000                            
02d76b88: ldr     x21, [x21, #0xbc0]                         S:'English'
02d76b8c: ldr     x2, [x24]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d76b90: ldr     x1, [x21]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d76b94: bl      #0x452c59c                                 fn_452c59c
02d76b98: cbz     x0, #0x2d76c78                             
02d76b9c: ldr     x2, [x26]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d76ba0: mov     x1, x19                                    
02d76ba4: bl      #0x452c810                                 fn_452c810
02d76ba8: tbz     w0, #0, #0x2d76bd8                         
02d76bac: ldr     x0, [x20]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d76bb0: ldr     w8, [x0, #0xe4]                            [62660e4]=0 f=0,0
02d76bb4: cbnz    w8, #0x2d76bc0                             
02d76bb8: bl      #0x2b70f30                                 fn_2b70f30
02d76bbc: ldr     x0, [x20]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d76bc0: ldr     x8, [x0, #0xb8]                            S:'banner_native_refresh_time'
02d76bc4: ldr     x0, [x8, #8]                               M:Clicker.GlowSprite2DItem::<DoGlow>b__10_3
02d76bc8: cbz     x0, #0x2d76c78                             
02d76bcc: ldr     x1, [x21]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d76bd0: ldr     x2, [x24]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d76bd4: b       #0x2d76c50                                 
02d76bd8: mov     x0, x19                                    
02d76bdc: ldp     x20, x19, [sp, #0x40]                      
02d76be0: ldp     x22, x21, [sp, #0x30]                      
02d76be4: ldp     x24, x23, [sp, #0x20]                      
02d76be8: ldp     x26, x25, [sp, #0x10]                      
02d76bec: ldr     x30, [sp], #0x50                           
02d76bf0: ret                                                
02d76bf4: ldr     x0, [x20]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d76bf8: ldr     w8, [x0, #0xe4]                            [62660e4]=0 f=0,0
02d76bfc: cbnz    w8, #0x2d76c08                             
02d76c00: bl      #0x2b70f30                                 fn_2b70f30
02d76c04: ldr     x0, [x20]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d76c08: ldr     x8, [x0, #0xb8]                            S:'banner_native_refresh_time'
02d76c0c: ldrb    w9, [x25, #0xbdb]                          
02d76c10: ldr     x21, [x8, #8]                              M:Clicker.GlowSprite2DItem::<DoGlow>b__10_3
02d76c14: cbnz    w9, #0x2d76c2c                             
02d76c18: mov     x0, x20                                    
02d76c1c: bl      #0x2b70db0                                 fn_2b70db0
02d76c20: ldr     x0, [x20]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d76c24: mov     w8, #1                                     
02d76c28: strb    w8, [x25, #0xbdb]                          
02d76c2c: ldr     w8, [x0, #0xe4]                            [62660e4]=0 f=0,0
02d76c30: cbnz    w8, #0x2d76c3c                             
02d76c34: bl      #0x2b70f30                                 fn_2b70f30
02d76c38: ldr     x0, [x20]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d76c3c: cbz     x21, #0x2d76c78                            
02d76c40: ldr     x8, [x0, #0xb8]                            S:'banner_native_refresh_time'
02d76c44: ldr     x2, [x24]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d76c48: mov     x0, x21                                    
02d76c4c: ldr     x1, [x8, #0x10]                            M:Clicker.GlowSprite2DItem::<DoGlow>b__10_4
02d76c50: bl      #0x452c59c                                 fn_452c59c
02d76c54: cbz     x0, #0x2d76c78                             
02d76c58: ldr     x2, [x23]                                  M:AdsManager::<OnApplicationPause>b__26_0
02d76c5c: mov     x1, x19                                    
02d76c60: ldp     x20, x19, [sp, #0x40]                      
02d76c64: ldp     x22, x21, [sp, #0x30]                      
02d76c68: ldp     x24, x23, [sp, #0x20]                      
02d76c6c: ldp     x26, x25, [sp, #0x10]                      
02d76c70: ldr     x30, [sp], #0x50                           
02d76c74: b       #0x452c59c                                 
02d76c78: bl      #0x2b7105c                                 fn_2b7105c
02d76c7c: bl      #0x2b71064                                 fn_2b71064
02d76c80: adrp    x0, #0x6266000                             
02d76c84: ldr     x0, [x0, #0x9f0]                           T:Assets.SimpleLocalization.Scripts.LocalizationManager
02d76c88: bl      #0x2b70dc4                                 fn_2b70dc4
02d76c8c: bl      #0x2738878                                 fn_2738878
02d76c90: mov     x0, xzr                                    
02d76c94: bl      #0x2d899fc                                 fn_2d899fc
02d76c98: mov     x19, x0                                    
02d76c9c: adrp    x0, #0x626c000                             
02d76ca0: ldr     x0, [x0, #0x880]                           S:'Language not found: '
02d76ca4: bl      #0x2b70dc4                                 fn_2b70dc4
02d76ca8: mov     x1, x19                                    
02d76cac: mov     x2, xzr                                    
02d76cb0: bl      #0x4c9c514                                 System.String::Concat
02d76cb4: mov     x19, x0                                    
02d76cb8: adrp    x0, #0x6268000                             
02d76cbc: ldr     x0, [x0, #0x778]                           T:System.Collections.Generic.KeyNotFoundException
02d76cc0: bl      #0x2b70dc4                                 fn_2b70dc4
02d76cc4: bl      #0x2b7104c                                 fn_2b7104c
02d76cc8: mov     x1, x19                                    
02d76ccc: mov     x2, xzr                                    
02d76cd0: mov     x20, x0                                    
02d76cd4: bl      #0x4dc6028                                 System.Collections.Generic.KeyNotFoundException::.ctor
02d76cd8: adrp    x0, #0x626c000                             
02d76cdc: ldr     x0, [x0, #0x888]                           M:Assets.SimpleLocalization.Scripts.LocalizationManager::Localize
02d76ce0: bl      #0x2b70dc4                                 fn_2b70dc4
02d76ce4: mov     x1, x0                                     
02d76ce8: mov     x0, x20                                    
02d76cec: bl      #0x2b70f20                                 fn_2b70f20
## Localize(string localizationKey, object[] args) -> string
---- Assets.SimpleLocalization.Scripts.LocalizationManager::Localize 0x2d7ac98
02d7ac98: str     x30, [sp, #-0x30]!                         
02d7ac9c: stp     x22, x21, [sp, #0x10]                      
02d7aca0: stp     x20, x19, [sp, #0x20]                      
02d7aca4: adrp    x21, #0x6630000                            
02d7aca8: adrp    x22, #0x6266000                            
02d7acac: mov     x19, x1                                    
02d7acb0: ldrb    w8, [x21, #0x40a]                          
02d7acb4: ldr     x22, [x22, #0x9f0]                         T:Assets.SimpleLocalization.Scripts.LocalizationManager
02d7acb8: mov     x20, x0                                    
02d7acbc: tbnz    w8, #0, #0x2d7acd4                         
02d7acc0: adrp    x0, #0x6266000                             
02d7acc4: ldr     x0, [x0, #0x9f0]                           T:Assets.SimpleLocalization.Scripts.LocalizationManager
02d7acc8: bl      #0x2b70db0                                 fn_2b70db0
02d7accc: mov     w8, #1                                     
02d7acd0: strb    w8, [x21, #0x40a]                          
02d7acd4: ldr     x0, [x22]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d7acd8: ldr     w8, [x0, #0xe4]                            [62660e4]=0 f=0,0
02d7acdc: cbnz    w8, #0x2d7ace4                             
02d7ace0: bl      #0x2b70f30                                 fn_2b70f30
02d7ace4: mov     x0, x20                                    
02d7ace8: bl      #0x2d76794                                 Assets.SimpleLocalization.Scripts.LocalizationManager::Localize
02d7acec: mov     x1, x19                                    
02d7acf0: ldp     x20, x19, [sp, #0x20]                      
02d7acf4: ldp     x22, x21, [sp, #0x10]                      
02d7acf8: mov     x2, xzr                                    
02d7acfc: ldr     x30, [sp], #0x30                           
02d7ad00: b       #0x4ca77a8                                 System.String::Format
## GetLines(string text) -> System.Collections.Generic.List`1<string>
---- Assets.SimpleLocalization.Scripts.LocalizationManager::GetLines 0x2d7b3b4
02d7b3b4: sub     sp, sp, #0x90                              
02d7b3b8: stp     x29, x30, [sp, #0x30]                      
02d7b3bc: stp     x28, x27, [sp, #0x40]                      
02d7b3c0: stp     x26, x25, [sp, #0x50]                      
02d7b3c4: stp     x24, x23, [sp, #0x60]                      
02d7b3c8: stp     x22, x21, [sp, #0x70]                      
02d7b3cc: stp     x20, x19, [sp, #0x80]                      
02d7b3d0: adrp    x20, #0x6630000                            
02d7b3d4: mov     x19, x0                                    
02d7b3d8: ldrb    w8, [x20, #0x40b]                          
02d7b3dc: tbnz    w8, #0, #0x2d7b550                         
02d7b3e0: adrp    x0, #0x6266000                             
02d7b3e4: ldr     x0, [x0, #0xc50]                           MS:System.Linq.Enumerable::ToList
02d7b3e8: bl      #0x2b70db0                                 fn_2b70db0
02d7b3ec: adrp    x0, #0x626c000                             
02d7b3f0: ldr     x0, [x0, #0xb40]                           MS:System.Linq.Enumerable::Where
02d7b3f4: bl      #0x2b70db0                                 fn_2b70db0
02d7b3f8: adrp    x0, #0x626c000                             
02d7b3fc: ldr     x0, [x0, #0xb48]                           T:type10541(k15)
02d7b400: bl      #0x2b70db0                                 fn_2b70db0
02d7b404: adrp    x0, #0x6263000                             
02d7b408: ldr     x0, [x0, #0x980]                           T:System.IDisposable
02d7b40c: bl      #0x2b70db0                                 fn_2b70db0
02d7b410: adrp    x0, #0x6263000                             
02d7b414: ldr     x0, [x0, #0xa58]                           T:System.Collections.IEnumerator
02d7b418: bl      #0x2b70db0                                 fn_2b70db0
02d7b41c: adrp    x0, #0x626c000                             
02d7b420: ldr     x0, [x0, #0xb50]                           T:System.Text.RegularExpressions.Match
02d7b424: bl      #0x2b70db0                                 fn_2b70db0
02d7b428: adrp    x0, #0x6266000                             
02d7b42c: ldr     x0, [x0, #0xea0]                           T:System.Text.RegularExpressions.Regex
02d7b430: bl      #0x2b70db0                                 fn_2b70db0
02d7b434: adrp    x0, #0x626c000                             
02d7b438: ldr     x0, [x0, #0xb58]                           M:Assets.SimpleLocalization.Scripts.LocalizationManager/<>c::<GetLines>b__13_0
02d7b43c: bl      #0x2b70db0                                 fn_2b70db0
02d7b440: adrp    x0, #0x626c000                             
02d7b444: ldr     x0, [x0, #0xac0]                           T:Assets.SimpleLocalization.Scripts.LocalizationManager/<>c
02d7b448: bl      #0x2b70db0                                 fn_2b70db0
02d7b44c: adrp    x0, #0x6264000                             
02d7b450: ldr     x0, [x0, #0xe18]                           S:'\n'
02d7b454: bl      #0x2b70db0                                 fn_2b70db0
02d7b458: adrp    x0, #0x626c000                             
02d7b45c: ldr     x0, [x0, #0xb60]                           S:' （'
02d7b460: bl      #0x2b70db0                                 fn_2b70db0
02d7b464: adrp    x0, #0x626c000                             
02d7b468: ldr     x0, [x0, #0xb68]                           S:'！'
02d7b46c: bl      #0x2b70db0                                 fn_2b70db0
02d7b470: adrp    x0, #0x626c000                             
02d7b474: ldr     x0, [x0, #0xb70]                           S:'"[\\s\\S]+?"'
02d7b478: bl      #0x2b70db0                                 fn_2b70db0
02d7b47c: adrp    x0, #0x626c000                             
02d7b480: ldr     x0, [x0, #0xb78]                           S:'！ '
02d7b484: bl      #0x2b70db0                                 fn_2b70db0
02d7b488: adrp    x0, #0x6266000                             
02d7b48c: ldr     x0, [x0, #0xc60]                           S:'\r\n'
02d7b490: bl      #0x2b70db0                                 fn_2b70db0
02d7b494: adrp    x0, #0x626c000                             
02d7b498: ldr     x0, [x0, #0xb80]                           S:'、 '
02d7b49c: bl      #0x2b70db0                                 fn_2b70db0
02d7b4a0: adrp    x0, #0x626c000                             
02d7b4a4: ldr     x0, [x0, #0xb88]                           S:'） '
02d7b4a8: bl      #0x2b70db0                                 fn_2b70db0
02d7b4ac: adrp    x0, #0x626c000                             
02d7b4b0: ldr     x0, [x0, #0xb90]                           S:'：'
02d7b4b4: bl      #0x2b70db0                                 fn_2b70db0
02d7b4b8: adrp    x0, #0x626c000                             
02d7b4bc: ldr     x0, [x0, #0xb98]                           S:'）'
02d7b4c0: bl      #0x2b70db0                                 fn_2b70db0
02d7b4c4: adrp    x0, #0x626c000                             
02d7b4c8: ldr     x0, [x0, #0xba0]                           S:'。 '
02d7b4cc: bl      #0x2b70db0                                 fn_2b70db0
02d7b4d0: adrp    x0, #0x626c000                             
02d7b4d4: ldr     x0, [x0, #0xba8]                           S:'[_quote_]'
02d7b4d8: bl      #0x2b70db0                                 fn_2b70db0
02d7b4dc: adrp    x0, #0x626c000                             
02d7b4e0: ldr     x0, [x0, #0xbb0]                           S:'： '
02d7b4e4: bl      #0x2b70db0                                 fn_2b70db0
02d7b4e8: adrp    x0, #0x626c000                             
02d7b4ec: ldr     x0, [x0, #0xbb8]                           S:'。'
02d7b4f0: bl      #0x2b70db0                                 fn_2b70db0
02d7b4f4: adrp    x0, #0x6266000                             
02d7b4f8: ldr     x0, [x0, #0xc28]                           S:','
02d7b4fc: bl      #0x2b70db0                                 fn_2b70db0
02d7b500: adrp    x0, #0x626c000                             
02d7b504: ldr     x0, [x0, #0xbc0]                           S:'"'
02d7b508: bl      #0x2b70db0                                 fn_2b70db0
02d7b50c: adrp    x0, #0x626c000                             
02d7b510: ldr     x0, [x0, #0xbc8]                           S:'[_comma_]'
02d7b514: bl      #0x2b70db0                                 fn_2b70db0
02d7b518: adrp    x0, #0x626c000                             
02d7b51c: ldr     x0, [x0, #0xbd0]                           S:'[_newline_]'
02d7b520: bl      #0x2b70db0                                 fn_2b70db0
02d7b524: adrp    x0, #0x626c000                             
02d7b528: ldr     x0, [x0, #0xbd8]                           S:'（'
02d7b52c: bl      #0x2b70db0                                 fn_2b70db0
02d7b530: adrp    x0, #0x626c000                             
02d7b534: ldr     x0, [x0, #0xbe0]                           S:'、'
02d7b538: bl      #0x2b70db0                                 fn_2b70db0
02d7b53c: adrp    x0, #0x626c000                             
02d7b540: ldr     x0, [x0, #0xbe8]                           S:'""'
02d7b544: bl      #0x2b70db0                                 fn_2b70db0
02d7b548: mov     w8, #1                                     
02d7b54c: strb    w8, [x20, #0x40b]                          
02d7b550: stp     xzr, xzr, [sp, #0x20]                      
02d7b554: cbz     x19, #0x2d7ba1c                            
02d7b558: adrp    x8, #0x6266000                             
02d7b55c: adrp    x23, #0x6264000                            
02d7b560: mov     x0, x19                                    
02d7b564: ldr     x8, [x8, #0xc60]                           S:'\r\n'
02d7b568: ldr     x23, [x23, #0xe18]                         S:'\n'
02d7b56c: mov     x3, xzr                                    
02d7b570: ldr     x1, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d7b574: ldr     x2, [x23]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d7b578: bl      #0x4ca8ca8                                 System.String::Replace
02d7b57c: cbz     x0, #0x2d7ba1c                             
02d7b580: adrp    x8, #0x626c000                             
02d7b584: adrp    x9, #0x626c000                             
02d7b588: adrp    x20, #0x6266000                            
02d7b58c: ldr     x8, [x8, #0xbe8]                           S:'""'
02d7b590: ldr     x9, [x9, #0xba8]                           S:'[_quote_]'
02d7b594: adrp    x19, #0x626c000                            
02d7b598: ldr     x20, [x20, #0xea0]                         T:System.Text.RegularExpressions.Regex
02d7b59c: ldr     x19, [x19, #0xb70]                         S:'"[\\s\\S]+?"'
02d7b5a0: mov     x3, xzr                                    
02d7b5a4: ldr     x1, [x8]                                   M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d7b5a8: ldr     x2, [x9]                                   M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d7b5ac: bl      #0x4ca8ca8                                 System.String::Replace
02d7b5b0: ldr     x8, [x20]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d7b5b4: mov     x20, x0                                    
02d7b5b8: ldr     w9, [x8, #0xe4]                            [626c0e4]=0 f=0,0
02d7b5bc: cbnz    w9, #0x2d7b5c8                             
02d7b5c0: mov     x0, x8                                     
02d7b5c4: bl      #0x2b70f30                                 fn_2b70f30
02d7b5c8: ldr     x1, [x19]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d7b5cc: mov     x0, x20                                    
02d7b5d0: mov     x2, xzr                                    
02d7b5d4: bl      #0x53863d8                                 System.Text.RegularExpressions.Regex::Matches
02d7b5d8: cbz     x0, #0x2d7ba1c                             
02d7b5dc: adrp    x25, #0x6263000                            
02d7b5e0: adrp    x26, #0x626c000                            
02d7b5e4: adrp    x27, #0x626c000                            
02d7b5e8: adrp    x22, #0x6266000                            
02d7b5ec: adrp    x28, #0x626c000                            
02d7b5f0: adrp    x24, #0x626c000                            
02d7b5f4: adrp    x29, #0x6263000                            
02d7b5f8: ldr     x25, [x25, #0xa58]                         T:System.Collections.IEnumerator
02d7b5fc: ldr     x26, [x26, #0xb50]                         T:System.Text.RegularExpressions.Match
02d7b600: ldr     x27, [x27, #0xbc0]                         S:'"'
02d7b604: ldr     x22, [x22, #0xc28]                         S:','
02d7b608: ldr     x28, [x28, #0xbc8]                         S:'[_comma_]'
02d7b60c: ldr     x24, [x24, #0xbd0]                         S:'[_newline_]'
02d7b610: ldr     x29, [x29, #0x980]                         T:System.IDisposable
02d7b614: mov     x1, xzr                                    
02d7b618: bl      #0x53844e0                                 System.Text.RegularExpressions.MatchCollection::GetEnumerator
02d7b61c: add     x8, sp, #0x28                              
02d7b620: str     x0, [sp, #0x28]                            
02d7b624: stp     xzr, x8, [sp, #8]                          
02d7b628: add     x8, sp, #0x20                              
02d7b62c: str     x8, [sp, #0x18]                            
02d7b630: ldr     x21, [sp, #0x28]                           
02d7b634: mov     x19, x20                                   
02d7b638: cbz     x21, #0x2d7ba00                            
02d7b63c: ldr     x8, [x21]                                  
02d7b640: ldr     x1, [x25]                                  &2c5bbd4(=a9bd7bfdd503233f)
02d7b644: ldrh    w9, [x8, #0x12e]                           
02d7b648: cbz     x9, #0x2d7b66c                             
02d7b64c: ldr     x10, [x8, #0xb0]                           M:Clicker.Light2DManager/<>c::<RemoveMissingItems>b__6_0
02d7b650: add     x10, x10, #8                               
02d7b654: ldur    x11, [x10, #-8]                            
02d7b658: cmp     x11, x1                                    
02d7b65c: b.eq    #0x2d7b67c                                 
02d7b660: subs    x9, x9, #1                                 
02d7b664: add     x10, x10, #0x10                            
02d7b668: b.ne    #0x2d7b654                                 
02d7b66c: mov     x0, x21                                    
02d7b670: mov     w2, wzr                                    
02d7b674: bl      #0x2baa05c                                 fn_2baa05c
02d7b678: b       #0x2d7b688                                 
02d7b67c: ldrsw   x9, [x10]                                  
02d7b680: add     x8, x8, x9, lsl #4                         &626c000
02d7b684: add     x0, x8, #0x138                             &626c138
02d7b688: ldp     x8, x1, [x0]                               
02d7b68c: mov     x0, x21                                    
02d7b690: blr     x8                                         
02d7b694: tbz     w0, #0, #0x2d7b7a8                         
02d7b698: ldr     x20, [sp, #0x28]                           
02d7b69c: cbz     x20, #0x2d7ba04                            
02d7b6a0: ldr     x8, [x20]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d7b6a4: ldr     x1, [x25]                                  &2c5bbd4(=a9bd7bfdd503233f)
02d7b6a8: ldrh    w9, [x8, #0x12e]                           
02d7b6ac: cbz     x9, #0x2d7b6d0                             
02d7b6b0: ldr     x10, [x8, #0xb0]                           M:Clicker.Light2DManager/<>c::<RemoveMissingItems>b__6_0
02d7b6b4: add     x10, x10, #8                               
02d7b6b8: ldur    x11, [x10, #-8]                            
02d7b6bc: cmp     x11, x1                                    
02d7b6c0: b.eq    #0x2d7b6e0                                 
02d7b6c4: subs    x9, x9, #1                                 
02d7b6c8: add     x10, x10, #0x10                            
02d7b6cc: b.ne    #0x2d7b6b8                                 
02d7b6d0: mov     x0, x20                                    
02d7b6d4: mov     w2, #1                                     
02d7b6d8: bl      #0x2baa05c                                 fn_2baa05c
02d7b6dc: b       #0x2d7b6f0                                 
02d7b6e0: ldr     w9, [x10]                                  
02d7b6e4: add     w9, w9, #1                                 
02d7b6e8: add     x8, x8, w9, sxtw #4                        &626c000
02d7b6ec: add     x0, x8, #0x138                             &626c138
02d7b6f0: ldp     x8, x1, [x0]                               
02d7b6f4: mov     x0, x20                                    
02d7b6f8: blr     x8                                         
02d7b6fc: mov     x21, x0                                    
02d7b700: cbz     x0, #0x2d7ba14                             
02d7b704: ldr     x1, [x26]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d7b708: ldr     x8, [x21]                                  
02d7b70c: ldrb    w10, [x8, #0x130]                          
02d7b710: ldrb    w9, [x1, #0x130]                           
02d7b714: cmp     w10, w9                                    
02d7b718: b.lo    #0x2d7b9f8                                 
02d7b71c: ldr     x8, [x8, #0xc8]                            MS:MonoSingleton`1::.ctor
02d7b720: add     x8, x8, x9, lsl #3                         &626c000
02d7b724: ldur    x8, [x8, #-8]                              
02d7b728: cmp     x8, x1                                     
02d7b72c: b.ne    #0x2d7b9f8                                 
02d7b730: mov     x0, x21                                    
02d7b734: mov     x1, xzr                                    
02d7b738: bl      #0x5380ec4                                 System.Text.RegularExpressions.Capture::get_Value
02d7b73c: mov     x20, x0                                    
02d7b740: mov     x0, x21                                    
02d7b744: mov     x1, xzr                                    
02d7b748: bl      #0x5380ec4                                 System.Text.RegularExpressions.Capture::get_Value
02d7b74c: cbz     x0, #0x2d7ba08                             
02d7b750: ldr     x1, [x27]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d7b754: mov     x2, xzr                                    
02d7b758: mov     x3, xzr                                    
02d7b75c: bl      #0x4ca8ca8                                 System.String::Replace
02d7b760: cbz     x0, #0x2d7ba0c                             
02d7b764: ldr     x1, [x22]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d7b768: ldr     x2, [x28]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d7b76c: mov     x3, xzr                                    
02d7b770: bl      #0x4ca8ca8                                 System.String::Replace
02d7b774: cbz     x0, #0x2d7ba10                             
02d7b778: ldr     x1, [x23]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d7b77c: ldr     x2, [x24]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d7b780: mov     x3, xzr                                    
02d7b784: bl      #0x4ca8ca8                                 System.String::Replace
02d7b788: cbz     x19, #0x2d7ba18                            
02d7b78c: mov     x2, x0                                     
02d7b790: mov     x0, x19                                    
02d7b794: mov     x1, x20                                    
02d7b798: mov     x3, xzr                                    
02d7b79c: bl      #0x4ca8ca8                                 System.String::Replace
02d7b7a0: mov     x20, x0                                    
02d7b7a4: b       #0x2d7b630                                 
02d7b7a8: mov     x20, xzr                                   
02d7b7ac: add     x8, sp, #0x28                              
02d7b7b0: add     x22, sp, #0x20                             
02d7b7b4: ldr     x0, [x8]                                   M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d7b7b8: ldr     x1, [x29]                                  &2c5bbd4(=a9bd7bfdd503233f)
02d7b7bc: bl      #0x2b70f34                                 fn_2b70f34
02d7b7c0: str     x0, [x22]                                  
02d7b7c4: cbz     x0, #0x2d7b824                             
02d7b7c8: ldr     x8, [x0]                                   M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d7b7cc: ldr     x1, [x29]                                  &2c5bbd4(=a9bd7bfdd503233f)
02d7b7d0: mov     x21, x0                                    
02d7b7d4: ldrh    w9, [x8, #0x12e]                           
02d7b7d8: cbz     x9, #0x2d7b7fc                             
02d7b7dc: ldr     x10, [x8, #0xb0]                           M:Clicker.Light2DManager/<>c::<RemoveMissingItems>b__6_0
02d7b7e0: add     x10, x10, #8                               
02d7b7e4: ldur    x11, [x10, #-8]                            
02d7b7e8: cmp     x11, x1                                    
02d7b7ec: b.eq    #0x2d7b80c                                 
02d7b7f0: subs    x9, x9, #1                                 
02d7b7f4: add     x10, x10, #0x10                            
02d7b7f8: b.ne    #0x2d7b7e4                                 
02d7b7fc: mov     x0, x21                                    
02d7b800: mov     w2, wzr                                    
02d7b804: bl      #0x2baa05c                                 fn_2baa05c
02d7b808: b       #0x2d7b818                                 
02d7b80c: ldrsw   x9, [x10]                                  
02d7b810: add     x8, x8, x9, lsl #4                         &626c000
02d7b814: add     x0, x8, #0x138                             &626c138
02d7b818: ldp     x8, x1, [x0]                               
02d7b81c: mov     x0, x21                                    
02d7b820: blr     x8                                         
02d7b824: cbnz    x20, #0x2d7ba20                            
02d7b828: adrp    x22, #0x626c000                            
02d7b82c: ldr     x22, [x22, #0xac0]                         T:Assets.SimpleLocalization.Scripts.LocalizationManager/<>c
02d7b830: cbz     x19, #0x2d7ba1c                            
02d7b834: adrp    x8, #0x626c000                             
02d7b838: mov     x0, x19                                    
02d7b83c: mov     x3, xzr                                    
02d7b840: ldr     x8, [x8, #0xbb8]                           S:'。'
02d7b844: ldr     x1, [x8]                                   M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d7b848: adrp    x8, #0x626c000                             
02d7b84c: ldr     x8, [x8, #0xba0]                           S:'。 '
02d7b850: ldr     x2, [x8]                                   M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d7b854: bl      #0x4ca8ca8                                 System.String::Replace
02d7b858: cbz     x0, #0x2d7ba1c                             
02d7b85c: adrp    x8, #0x626c000                             
02d7b860: mov     x3, xzr                                    
02d7b864: ldr     x8, [x8, #0xbe0]                           S:'、'
02d7b868: ldr     x1, [x8]                                   M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d7b86c: adrp    x8, #0x626c000                             
02d7b870: ldr     x8, [x8, #0xb80]                           S:'、 '
02d7b874: ldr     x2, [x8]                                   M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d7b878: bl      #0x4ca8ca8                                 System.String::Replace
02d7b87c: cbz     x0, #0x2d7ba1c                             
02d7b880: adrp    x8, #0x626c000                             
02d7b884: mov     x3, xzr                                    
02d7b888: ldr     x8, [x8, #0xb90]                           S:'：'
02d7b88c: ldr     x1, [x8]                                   M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d7b890: adrp    x8, #0x626c000                             
02d7b894: ldr     x8, [x8, #0xbb0]                           S:'： '
02d7b898: ldr     x2, [x8]                                   M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d7b89c: bl      #0x4ca8ca8                                 System.String::Replace
02d7b8a0: cbz     x0, #0x2d7ba1c                             
02d7b8a4: adrp    x8, #0x626c000                             
02d7b8a8: mov     x3, xzr                                    
02d7b8ac: ldr     x8, [x8, #0xb68]                           S:'！'
02d7b8b0: ldr     x1, [x8]                                   M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d7b8b4: adrp    x8, #0x626c000                             
02d7b8b8: ldr     x8, [x8, #0xb78]                           S:'！ '
02d7b8bc: ldr     x2, [x8]                                   M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d7b8c0: bl      #0x4ca8ca8                                 System.String::Replace
02d7b8c4: cbz     x0, #0x2d7ba1c                             
02d7b8c8: adrp    x8, #0x626c000                             
02d7b8cc: mov     x3, xzr                                    
02d7b8d0: ldr     x8, [x8, #0xbd8]                           S:'（'
02d7b8d4: ldr     x1, [x8]                                   M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d7b8d8: adrp    x8, #0x626c000                             
02d7b8dc: ldr     x8, [x8, #0xb60]                           S:' （'
02d7b8e0: ldr     x2, [x8]                                   M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d7b8e4: bl      #0x4ca8ca8                                 System.String::Replace
02d7b8e8: cbz     x0, #0x2d7ba1c                             
02d7b8ec: adrp    x8, #0x626c000                             
02d7b8f0: mov     x3, xzr                                    
02d7b8f4: ldr     x8, [x8, #0xb98]                           S:'）'
02d7b8f8: ldr     x1, [x8]                                   M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d7b8fc: adrp    x8, #0x626c000                             
02d7b900: ldr     x8, [x8, #0xb88]                           S:'） '
02d7b904: ldr     x2, [x8]                                   M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d7b908: bl      #0x4ca8ca8                                 System.String::Replace
02d7b90c: cbz     x0, #0x2d7ba1c                             
02d7b910: mov     x1, xzr                                    
02d7b914: bl      #0x4cab1c4                                 System.String::Trim
02d7b918: cbz     x0, #0x2d7ba1c                             
02d7b91c: mov     w1, #0xa                                   
02d7b920: mov     w2, wzr                                    
02d7b924: mov     x3, xzr                                    
02d7b928: bl      #0x4ca92f8                                 System.String::Split
02d7b92c: ldr     x8, [x22]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d7b930: mov     x19, x0                                    
02d7b934: ldr     w9, [x8, #0xe4]                            [626c0e4]=0 f=0,0
02d7b938: cbnz    w9, #0x2d7b948                             
02d7b93c: mov     x0, x8                                     
02d7b940: bl      #0x2b70f30                                 fn_2b70f30
02d7b944: ldr     x8, [x22]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d7b948: ldr     x9, [x8, #0xb8]                            MS:System.Collections.Generic.List`1::Add
02d7b94c: ldr     x20, [x9, #0x10]                           M:Clicker.GlowSprite2DItem::<DoGlow>b__10_4
02d7b950: cbnz    x20, #0x2d7b9b0                            
02d7b954: ldr     w10, [x8, #0xe4]                           [626c0e4]=0 f=0,0
02d7b958: cbnz    w10, #0x2d7b96c                            
02d7b95c: mov     x0, x8                                     
02d7b960: bl      #0x2b70f30                                 fn_2b70f30
02d7b964: ldr     x8, [x22]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d7b968: ldr     x9, [x8, #0xb8]                            MS:System.Collections.Generic.List`1::Add
02d7b96c: adrp    x8, #0x626c000                             
02d7b970: ldr     x8, [x8, #0xb48]                           T:type10541(k15)
02d7b974: ldr     x21, [x9]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d7b978: ldr     x0, [x8]                                   M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d7b97c: bl      #0x2b7104c                                 fn_2b7104c
02d7b980: adrp    x8, #0x626c000                             
02d7b984: mov     x1, x21                                    
02d7b988: mov     x3, xzr                                    
02d7b98c: ldr     x8, [x8, #0xb58]                           M:Assets.SimpleLocalization.Scripts.LocalizationManager/<>c::<GetLines>b__13_0
02d7b990: mov     x20, x0                                    
02d7b994: ldr     x2, [x8]                                   M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d7b998: bl      #0x4940cf8                                 fn_4940cf8
02d7b99c: ldr     x8, [x22]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d7b9a0: mov     x1, x20                                    
02d7b9a4: ldr     x0, [x8, #0xb8]                            MS:System.Collections.Generic.List`1::Add
02d7b9a8: str     x20, [x0, #0x10]!                          ._language
02d7b9ac: bl      #0x2b70d54                                 fn_2b70d54
02d7b9b0: adrp    x8, #0x626c000                             
02d7b9b4: mov     x0, x19                                    
02d7b9b8: mov     x1, x20                                    
02d7b9bc: ldr     x8, [x8, #0xb40]                           MS:System.Linq.Enumerable::Where
02d7b9c0: ldr     x2, [x8]                                   M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d7b9c4: bl      #0x319fec4                                 fn_319fec4
02d7b9c8: adrp    x8, #0x6266000                             
02d7b9cc: ldr     x8, [x8, #0xc50]                           MS:System.Linq.Enumerable::ToList
02d7b9d0: ldr     x1, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d7b9d4: bl      #0x319eb2c                                 fn_319eb2c
02d7b9d8: ldp     x20, x19, [sp, #0x80]                      
02d7b9dc: ldp     x22, x21, [sp, #0x70]                      
02d7b9e0: ldp     x24, x23, [sp, #0x60]                      
02d7b9e4: ldp     x26, x25, [sp, #0x50]                      
02d7b9e8: ldp     x28, x27, [sp, #0x40]                      
02d7b9ec: ldp     x29, x30, [sp, #0x30]                      
02d7b9f0: add     sp, sp, #0x90                              
02d7b9f4: ret                                                
02d7b9f8: mov     x0, x21                                    
02d7b9fc: bl      #0x2b713dc                                 fn_2b713dc
02d7ba00: bl      #0x2b7105c                                 fn_2b7105c
02d7ba04: bl      #0x2b7105c                                 fn_2b7105c
02d7ba08: bl      #0x2b7105c                                 fn_2b7105c
02d7ba0c: bl      #0x2b7105c                                 fn_2b7105c
02d7ba10: bl      #0x2b7105c                                 fn_2b7105c
02d7ba14: bl      #0x2b7105c                                 fn_2b7105c
02d7ba18: bl      #0x2b7105c                                 fn_2b7105c
02d7ba1c: bl      #0x2b7105c                                 fn_2b7105c
02d7ba20: mov     x0, x20                                    
02d7ba24: bl      #0x2b71054                                 fn_2b71054
02d7ba28: b       #0x2d7ba68                                 
02d7ba2c: b       #0x2d7ba68                                 
02d7ba30: b       #0x2d7ba68                                 
02d7ba34: mov     x19, xzr                                   
02d7ba38: b       #0x2d7ba68                                 
02d7ba3c: b       #0x2d7ba68                                 
02d7ba40: b       #0x2d7ba68                                 
02d7ba44: b       #0x2d7ba68                                 
02d7ba48: b       #0x2d7ba68                                 
02d7ba4c: b       #0x2d7ba68                                 
02d7ba50: b       #0x2d7ba68                                 
02d7ba54: b       #0x2d7ba68                                 
02d7ba58: b       #0x2d7ba68                                 
02d7ba5c: b       #0x2d7ba68                                 
02d7ba60: b       #0x2d7ba68                                 
02d7ba64: b       #0x2d7ba68                                 
02d7ba68: cmp     w1, #1                                     
02d7ba6c: b.ne    #0x2d7ba88                                 
02d7ba70: bl      #0x5e90260                                 fn_5e90260
02d7ba74: ldr     x20, [x0]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d7ba78: str     x20, [sp, #8]                              
02d7ba7c: bl      #0x5e90270                                 fn_5e90270
02d7ba80: ldp     x8, x22, [sp, #0x10]                       
02d7ba84: b       #0x2d7b7b4                                 
02d7ba88: mov     x19, x0                                    
02d7ba8c: add     x0, sp, #8                                 
02d7ba90: bl      #0x2736a80                                 fn_2736a80
02d7ba94: mov     x0, x19                                    
02d7ba98: bl      #0x2c6051c                                 fn_2c6051c
02d7ba9c: bl      #0x27369b8                                 fn_27369b8
## GetColumns(string line) -> System.Collections.Generic.List`1<string>
---- Assets.SimpleLocalization.Scripts.LocalizationManager::GetColumns 0x2d7baa0
02d7baa0: str     x30, [sp, #-0x40]!                         
02d7baa4: stp     x24, x23, [sp, #0x10]                      
02d7baa8: stp     x22, x21, [sp, #0x20]                      
02d7baac: stp     x20, x19, [sp, #0x30]                      
02d7bab0: adrp    x20, #0x6630000                            
02d7bab4: mov     x19, x0                                    
02d7bab8: ldrb    w8, [x20, #0x40c]                          
02d7babc: tbnz    w8, #0, #0x2d7bb10                         
02d7bac0: adrp    x0, #0x626c000                             
02d7bac4: ldr     x0, [x0, #0xa78]                           MS:System.Linq.Enumerable::Select
02d7bac8: bl      #0x2b70db0                                 fn_2b70db0
02d7bacc: adrp    x0, #0x6266000                             
02d7bad0: ldr     x0, [x0, #0xc50]                           MS:System.Linq.Enumerable::ToList
02d7bad4: bl      #0x2b70db0                                 fn_2b70db0
02d7bad8: adrp    x0, #0x626c000                             
02d7badc: ldr     x0, [x0, #0xa98]                           T:type10549(k15)
02d7bae0: bl      #0x2b70db0                                 fn_2b70db0
02d7bae4: adrp    x0, #0x626c000                             
02d7bae8: ldr     x0, [x0, #0xbf0]                           M:Assets.SimpleLocalization.Scripts.LocalizationManager/<>c::<GetColumns>b__14_0
02d7baec: bl      #0x2b70db0                                 fn_2b70db0
02d7baf0: adrp    x0, #0x626c000                             
02d7baf4: ldr     x0, [x0, #0xbf8]                           M:Assets.SimpleLocalization.Scripts.LocalizationManager/<>c::<GetColumns>b__14_1
02d7baf8: bl      #0x2b70db0                                 fn_2b70db0
02d7bafc: adrp    x0, #0x626c000                             
02d7bb00: ldr     x0, [x0, #0xac0]                           T:Assets.SimpleLocalization.Scripts.LocalizationManager/<>c
02d7bb04: bl      #0x2b70db0                                 fn_2b70db0
02d7bb08: mov     w8, #1                                     
02d7bb0c: strb    w8, [x20, #0x40c]                          
02d7bb10: cbz     x19, #0x2d7bc80                            
02d7bb14: adrp    x22, #0x626c000                            
02d7bb18: mov     x0, x19                                    
02d7bb1c: mov     w1, #0x2c                                  
02d7bb20: ldr     x22, [x22, #0xac0]                         T:Assets.SimpleLocalization.Scripts.LocalizationManager/<>c
02d7bb24: mov     w2, wzr                                    
02d7bb28: mov     x3, xzr                                    
02d7bb2c: bl      #0x4ca92f8                                 System.String::Split
02d7bb30: ldr     x8, [x22]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d7bb34: mov     x19, x0                                    
02d7bb38: ldr     w9, [x8, #0xe4]                            
02d7bb3c: cbnz    w9, #0x2d7bb4c                             
02d7bb40: mov     x0, x8                                     
02d7bb44: bl      #0x2b70f30                                 fn_2b70f30
02d7bb48: ldr     x8, [x22]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d7bb4c: ldr     x9, [x8, #0xb8]                            
02d7bb50: adrp    x23, #0x626c000                            
02d7bb54: ldr     x20, [x9, #0x18]                           
02d7bb58: ldr     x23, [x23, #0xa78]                         MS:System.Linq.Enumerable::Select
02d7bb5c: cbnz    x20, #0x2d7bbbc                            
02d7bb60: ldr     w10, [x8, #0xe4]                           
02d7bb64: cbnz    w10, #0x2d7bb78                            
02d7bb68: mov     x0, x8                                     
02d7bb6c: bl      #0x2b70f30                                 fn_2b70f30
02d7bb70: ldr     x8, [x22]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d7bb74: ldr     x9, [x8, #0xb8]                            
02d7bb78: adrp    x8, #0x626c000                             
02d7bb7c: ldr     x8, [x8, #0xa98]                           T:type10549(k15)
02d7bb80: ldr     x21, [x9]                                  
02d7bb84: ldr     x0, [x8]                                   M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d7bb88: bl      #0x2b7104c                                 fn_2b7104c
02d7bb8c: adrp    x8, #0x626c000                             
02d7bb90: mov     x1, x21                                    
02d7bb94: mov     x3, xzr                                    
02d7bb98: ldr     x8, [x8, #0xbf0]                           M:Assets.SimpleLocalization.Scripts.LocalizationManager/<>c::<GetColumns>b__14_0
02d7bb9c: mov     x20, x0                                    
02d7bba0: ldr     x2, [x8]                                   M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d7bba4: bl      #0x49416f4                                 fn_49416f4
02d7bba8: ldr     x8, [x22]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d7bbac: mov     x1, x20                                    
02d7bbb0: ldr     x0, [x8, #0xb8]                            MS:System.Collections.Generic.List`1::Add
02d7bbb4: str     x20, [x0, #0x18]!                          
02d7bbb8: bl      #0x2b70d54                                 fn_2b70d54
02d7bbbc: ldr     x2, [x23]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d7bbc0: mov     x0, x19                                    
02d7bbc4: mov     x1, x20                                    
02d7bbc8: bl      #0x3193858                                 fn_3193858
02d7bbcc: ldr     x8, [x22]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d7bbd0: mov     x19, x0                                    
02d7bbd4: ldr     w9, [x8, #0xe4]                            [626c0e4]=0 f=0,0
02d7bbd8: cbnz    w9, #0x2d7bbe8                             
02d7bbdc: mov     x0, x8                                     
02d7bbe0: bl      #0x2b70f30                                 fn_2b70f30
02d7bbe4: ldr     x8, [x22]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d7bbe8: ldr     x9, [x8, #0xb8]                            MS:System.Collections.Generic.List`1::Add
02d7bbec: adrp    x24, #0x6266000                            
02d7bbf0: ldr     x20, [x9, #0x20]                           
02d7bbf4: ldr     x24, [x24, #0xc50]                         MS:System.Linq.Enumerable::ToList
02d7bbf8: cbnz    x20, #0x2d7bc58                            
02d7bbfc: ldr     w10, [x8, #0xe4]                           [626c0e4]=0 f=0,0
02d7bc00: cbnz    w10, #0x2d7bc14                            
02d7bc04: mov     x0, x8                                     
02d7bc08: bl      #0x2b70f30                                 fn_2b70f30
02d7bc0c: ldr     x8, [x22]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d7bc10: ldr     x9, [x8, #0xb8]                            MS:System.Collections.Generic.List`1::Add
02d7bc14: adrp    x8, #0x626c000                             
02d7bc18: ldr     x8, [x8, #0xa98]                           T:type10549(k15)
02d7bc1c: ldr     x21, [x9]                                  
02d7bc20: ldr     x0, [x8]                                   M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d7bc24: bl      #0x2b7104c                                 fn_2b7104c
02d7bc28: adrp    x8, #0x626c000                             
02d7bc2c: mov     x1, x21                                    
02d7bc30: mov     x3, xzr                                    
02d7bc34: ldr     x8, [x8, #0xbf8]                           M:Assets.SimpleLocalization.Scripts.LocalizationManager/<>c::<GetColumns>b__14_1
02d7bc38: mov     x20, x0                                    
02d7bc3c: ldr     x2, [x8]                                   M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d7bc40: bl      #0x49416f4                                 fn_49416f4
02d7bc44: ldr     x8, [x22]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d7bc48: mov     x1, x20                                    
02d7bc4c: ldr     x0, [x8, #0xb8]                            MS:System.Collections.Generic.List`1::Add
02d7bc50: str     x20, [x0, #0x20]!                          
02d7bc54: bl      #0x2b70d54                                 fn_2b70d54
02d7bc58: ldr     x2, [x23]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d7bc5c: mov     x0, x19                                    
02d7bc60: mov     x1, x20                                    
02d7bc64: bl      #0x3193858                                 fn_3193858
02d7bc68: ldr     x1, [x24]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d7bc6c: ldp     x20, x19, [sp, #0x30]                      
02d7bc70: ldp     x22, x21, [sp, #0x20]                      
02d7bc74: ldp     x24, x23, [sp, #0x10]                      
02d7bc78: ldr     x30, [sp], #0x40                           
02d7bc7c: b       #0x319eb2c                                 
02d7bc80: bl      #0x2b7105c                                 fn_2b7105c
## .cctor() -> void
---- Assets.SimpleLocalization.Scripts.LocalizationManager::.cctor 0x2d7bdf4
02d7bdf4: stp     x30, x25, [sp, #-0x40]!                    
02d7bdf8: stp     x24, x23, [sp, #0x10]                      
02d7bdfc: stp     x22, x21, [sp, #0x20]                      
02d7be00: stp     x20, x19, [sp, #0x30]                      
02d7be04: adrp    x20, #0x6630000                            
02d7be08: adrp    x19, #0x626c000                            
02d7be0c: ldrb    w8, [x20, #0x40d]                          
02d7be10: ldr     x19, [x19, #0xac0]                         T:Assets.SimpleLocalization.Scripts.LocalizationManager/<>c
02d7be14: tbnz    w8, #0, #0x2d7be74                         
02d7be18: adrp    x0, #0x6264000                             
02d7be1c: ldr     x0, [x0, #0xf90]                           T:System.Action
02d7be20: bl      #0x2b70db0                                 fn_2b70db0
02d7be24: adrp    x0, #0x626c000                             
02d7be28: ldr     x0, [x0, #0xc00]                           MS:System.Collections.Generic.Dictionary`2::.ctor
02d7be2c: bl      #0x2b70db0                                 fn_2b70db0
02d7be30: adrp    x0, #0x626c000                             
02d7be34: ldr     x0, [x0, #0xc08]                           T:type54439(k15)
02d7be38: bl      #0x2b70db0                                 fn_2b70db0
02d7be3c: adrp    x0, #0x6266000                             
02d7be40: ldr     x0, [x0, #0x9f0]                           T:Assets.SimpleLocalization.Scripts.LocalizationManager
02d7be44: bl      #0x2b70db0                                 fn_2b70db0
02d7be48: adrp    x0, #0x626c000                             
02d7be4c: ldr     x0, [x0, #0xc10]                           M:Assets.SimpleLocalization.Scripts.LocalizationManager/<>c::<.cctor>b__15_0
02d7be50: bl      #0x2b70db0                                 fn_2b70db0
02d7be54: adrp    x0, #0x626c000                             
02d7be58: ldr     x0, [x0, #0xac0]                           T:Assets.SimpleLocalization.Scripts.LocalizationManager/<>c
02d7be5c: bl      #0x2b70db0                                 fn_2b70db0
02d7be60: adrp    x0, #0x6266000                             
02d7be64: ldr     x0, [x0, #0xbc0]                           S:'English'
02d7be68: bl      #0x2b70db0                                 fn_2b70db0
02d7be6c: mov     w8, #1                                     
02d7be70: strb    w8, [x20, #0x40d]                          
02d7be74: adrp    x25, #0x6264000                            
02d7be78: adrp    x20, #0x626c000                            
02d7be7c: adrp    x21, #0x6266000                            
02d7be80: ldr     x25, [x25, #0xf90]                         T:System.Action
02d7be84: ldr     x20, [x20, #0xc10]                         M:Assets.SimpleLocalization.Scripts.LocalizationManager/<>c::<.cctor>b__15_0
02d7be88: ldr     x21, [x21, #0x9f0]                         T:Assets.SimpleLocalization.Scripts.LocalizationManager
02d7be8c: ldr     x0, [x19]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d7be90: adrp    x24, #0x626c000                            
02d7be94: adrp    x23, #0x626c000                            
02d7be98: adrp    x22, #0x6266000                            
02d7be9c: ldr     x24, [x24, #0xc08]                         T:type54439(k15)
02d7bea0: ldr     x23, [x23, #0xc00]                         MS:System.Collections.Generic.Dictionary`2::.ctor
02d7bea4: ldr     w8, [x0, #0xe4]                            [62660e4]=0 f=0,0
02d7bea8: ldr     x22, [x22, #0xbc0]                         S:'English'
02d7beac: cbnz    w8, #0x2d7beb8                             
02d7beb0: bl      #0x2b70f30                                 fn_2b70f30
02d7beb4: ldr     x0, [x19]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d7beb8: ldr     x8, [x0, #0xb8]                            S:'banner_native_refresh_time'
02d7bebc: ldr     x0, [x25]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d7bec0: ldr     x19, [x8]                                  
02d7bec4: bl      #0x2b7104c                                 fn_2b7104c
02d7bec8: ldr     x2, [x20]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d7becc: mov     x1, x19                                    
02d7bed0: mov     x3, xzr                                    
02d7bed4: mov     x20, x0                                    
02d7bed8: bl      #0x4d8ddbc                                 System.Action::.ctor
02d7bedc: ldr     x8, [x21]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d7bee0: mov     x1, x20                                    
02d7bee4: ldr     x8, [x8, #0xb8]                            
02d7bee8: str     x20, [x8]                                  
02d7beec: ldr     x8, [x21]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d7bef0: ldr     x0, [x8, #0xb8]                            
02d7bef4: bl      #0x2b70d54                                 fn_2b70d54
02d7bef8: ldr     x0, [x24]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d7befc: bl      #0x2b7104c                                 fn_2b7104c
02d7bf00: ldr     x1, [x23]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d7bf04: mov     x19, x0                                    
02d7bf08: bl      #0x452b8a0                                 fn_452b8a0
02d7bf0c: ldr     x8, [x21]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d7bf10: mov     x1, x19                                    
02d7bf14: ldr     x0, [x8, #0xb8]                            
02d7bf18: str     x19, [x0, #8]!                             
02d7bf1c: bl      #0x2b70d54                                 fn_2b70d54
02d7bf20: ldr     x8, [x21]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d7bf24: ldr     x1, [x22]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d7bf28: ldp     x20, x19, [sp, #0x30]                      
02d7bf2c: ldr     x0, [x8, #0xb8]                            
02d7bf30: ldp     x22, x21, [sp, #0x20]                      
02d7bf34: ldp     x24, x23, [sp, #0x10]                      
02d7bf38: str     x1, [x0, #0x10]!                           ._language
02d7bf3c: ldp     x30, x25, [sp], #0x40                      
02d7bf40: b       #0x2b70d54                                 
