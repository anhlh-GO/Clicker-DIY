#### CLASS BlindBagCollection.ShowCompleteBoxset parent= UnityEngine.MonoBehaviour
#   field _screenCanvasGroup             UnityEngine.CanvasGroup                            off=0x20 attr=1 SerializeField
#   field _overlay                       UnityEngine.SpriteRenderer                         off=0x28 attr=1 SerializeField
#   field _headerAnimation               DG.Tweening.DOTweenAnimation                       off=0x30 attr=1 SerializeField
#   field _confettiParticle              AssetKits.ParticleImage.ParticleImage              off=0x38 attr=1 SerializeField
#   field _root                          UnityEngine.GameObject                             off=0x40 attr=1 SerializeField
#   field _boxsetStartPosititon          UnityEngine.Vector2                                off=0x48 attr=1 
#   field _boxsetTransform               UnityEngine.Transform                              off=0x50 attr=1 
#   field _boxsetParent                  UnityEngine.Transform                              off=0x58 attr=1 
#   field _2dRaycaster                   UnityEngine.EventSystems.Physics2DRaycaster        off=0x60 attr=1 
#   field _sq                            DG.Tweening.Sequence                               off=0x68 attr=1 
## Start() -> void
---- BlindBagCollection.ShowCompleteBoxset::Start 0x2d3bad8
02d3bad8: str     x30, [sp, #-0x20]!                         
02d3badc: stp     x20, x19, [sp, #0x10]                      
02d3bae0: adrp    x20, #0x6630000                            
02d3bae4: mov     x19, x0                                    
02d3bae8: ldrb    w8, [x20, #0x156]                          
02d3baec: tbnz    w8, #0, #0x2d3bb04                         
02d3baf0: adrp    x0, #0x626a000                             
02d3baf4: ldr     x0, [x0, #0xa48]                           MS:UnityEngine.Component::GetComponent
02d3baf8: bl      #0x2b70db0                                 fn_2b70db0
02d3bafc: mov     w8, #1                                     
02d3bb00: strb    w8, [x20, #0x156]                          
02d3bb04: mov     x0, xzr                                    
02d3bb08: bl      #0x5aefe28                                 UnityEngine.Camera::get_main
02d3bb0c: cbz     x0, #0x2d3bb4c                             
02d3bb10: adrp    x8, #0x626a000                             
02d3bb14: ldr     x8, [x8, #0xa48]                           MS:UnityEngine.Component::GetComponent
02d3bb18: ldr     x1, [x8]                                   T:type56879(k15)
02d3bb1c: bl      #0x3140c84                                 fn_3140c84
02d3bb20: mov     x1, x0                                     
02d3bb24: str     x0, [x19, #0x60]!                          ._2dRaycaster
02d3bb28: mov     x0, x19                                    
02d3bb2c: bl      #0x2b70d54                                 fn_2b70d54
02d3bb30: ldur    x0, [x19, #-0x20]                          
02d3bb34: cbz     x0, #0x2d3bb4c                             
02d3bb38: ldp     x20, x19, [sp, #0x10]                      
02d3bb3c: mov     w1, wzr                                    
02d3bb40: mov     x2, xzr                                    
02d3bb44: ldr     x30, [sp], #0x20                           
02d3bb48: b       #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d3bb4c: bl      #0x2b7105c                                 fn_2b7105c
## Show(UnityEngine.Transform boxsetTransform) -> void
---- BlindBagCollection.ShowCompleteBoxset::Show 0x2d37a88
02d37a88: str     d8, [sp, #-0x60]!                          
02d37a8c: str     x30, [sp, #8]                              
02d37a90: stp     x28, x27, [sp, #0x10]                      
02d37a94: stp     x26, x25, [sp, #0x20]                      
02d37a98: stp     x24, x23, [sp, #0x30]                      
02d37a9c: stp     x22, x21, [sp, #0x40]                      
02d37aa0: stp     x20, x19, [sp, #0x50]                      
02d37aa4: adrp    x20, #0x6630000                            
02d37aa8: mov     x21, x1                                    
02d37aac: mov     x19, x0                                    
02d37ab0: ldrb    w8, [x20, #0x157]                          
02d37ab4: tbnz    w8, #0, #0x2d37b20                         
02d37ab8: adrp    x0, #0x6263000                             
02d37abc: ldr     x0, [x0, #0xfd0]                           T:DG.Tweening.DOTween
02d37ac0: bl      #0x2b70db0                                 fn_2b70db0
02d37ac4: adrp    x0, #0x626a000                             
02d37ac8: ldr     x0, [x0, #0xba8]                           M:BlindBagCollection.ShowCompleteBoxset::OnComplete
02d37acc: bl      #0x2b70db0                                 fn_2b70db0
02d37ad0: adrp    x0, #0x626a000                             
02d37ad4: ldr     x0, [x0, #0xbb0]                           M:BlindBagCollection.ShowCompleteBoxset::SetBoxsetToNormal
02d37ad8: bl      #0x2b70db0                                 fn_2b70db0
02d37adc: adrp    x0, #0x626a000                             
02d37ae0: ldr     x0, [x0, #0xbb8]                           M:BlindBagCollection.ShowCompleteBoxset::<Show>b__11_0
02d37ae4: bl      #0x2b70db0                                 fn_2b70db0
02d37ae8: adrp    x0, #0x626a000                             
02d37aec: ldr     x0, [x0, #0xbc0]                           M:BlindBagCollection.ShowCompleteBoxset::<Show>b__11_1
02d37af0: bl      #0x2b70db0                                 fn_2b70db0
02d37af4: adrp    x0, #0x6264000                             
02d37af8: ldr     x0, [x0, #0xe8]                            T:DG.Tweening.TweenCallback
02d37afc: bl      #0x2b70db0                                 fn_2b70db0
02d37b00: adrp    x0, #0x6266000                             
02d37b04: ldr     x0, [x0, #0x928]                           MS:DG.Tweening.TweenSettingsExtensions::OnComplete
02d37b08: bl      #0x2b70db0                                 fn_2b70db0
02d37b0c: adrp    x0, #0x6266000                             
02d37b10: ldr     x0, [x0, #0x880]                           MS:DG.Tweening.TweenSettingsExtensions::SetEase
02d37b14: bl      #0x2b70db0                                 fn_2b70db0
02d37b18: mov     w8, #1                                     
02d37b1c: strb    w8, [x20, #0x157]                          
02d37b20: mov     x20, x19                                   
02d37b24: mov     x1, x21                                    
02d37b28: str     x21, [x20, #0x50]!                         ._boxsetTransform
02d37b2c: mov     x0, x20                                    
02d37b30: bl      #0x2b70d54                                 fn_2b70d54
02d37b34: cbz     x21, #0x2d37e30                            
02d37b38: mov     x0, x21                                    
02d37b3c: mov     x1, xzr                                    
02d37b40: bl      #0x5b466dc                                 UnityEngine.Transform::get_parent
02d37b44: mov     x21, x19                                   
02d37b48: mov     x1, x0                                     
02d37b4c: str     x0, [x21, #0x58]!                          ._boxsetParent
02d37b50: mov     x0, x21                                    
02d37b54: bl      #0x2b70d54                                 fn_2b70d54
02d37b58: ldur    x0, [x21, #-8]                             
02d37b5c: cbz     x0, #0x2d37e30                             
02d37b60: mov     x1, xzr                                    
02d37b64: bl      #0x5b467ac                                 UnityEngine.Transform::get_position
02d37b68: ldr     x0, [x19, #0x40]                           ._root
02d37b6c: stp     s0, s1, [x19, #0x48]                       ._boxsetStartPosititon
02d37b70: cbz     x0, #0x2d37e30                             
02d37b74: ldr     x21, [x19, #0x50]                          ._boxsetTransform
02d37b78: mov     x1, xzr                                    
02d37b7c: bl      #0x5b368f0                                 UnityEngine.GameObject::get_transform
02d37b80: cbz     x21, #0x2d37e30                            
02d37b84: mov     x1, x0                                     
02d37b88: mov     x0, x21                                    
02d37b8c: mov     x2, xzr                                    
02d37b90: bl      #0x5b472ec                                 UnityEngine.Transform::SetParent
02d37b94: adrp    x21, #0x662f000                            
02d37b98: ldr     x20, [x20]                                 
02d37b9c: ldrb    w8, [x21, #0x91a]                          
02d37ba0: cbnz    w8, #0x2d37bb8                             
02d37ba4: adrp    x0, #0x6264000                             
02d37ba8: ldr     x0, [x0, #0xd8]                            T:UnityEngine.Vector3
02d37bac: bl      #0x2b70db0                                 fn_2b70db0
02d37bb0: mov     w8, #1                                     
02d37bb4: strb    w8, [x21, #0x91a]                          
02d37bb8: cbz     x20, #0x2d37e30                            
02d37bbc: adrp    x21, #0x6263000                            
02d37bc0: adrp    x27, #0x6266000                            
02d37bc4: adrp    x24, #0x6264000                            
02d37bc8: adrp    x8, #0x6264000                             
02d37bcc: ldr     x21, [x21, #0xfd0]                         T:DG.Tweening.DOTween
02d37bd0: ldr     x27, [x27, #0x880]                         MS:DG.Tweening.TweenSettingsExtensions::SetEase
02d37bd4: ldr     x24, [x24, #0xe8]                          T:DG.Tweening.TweenCallback
02d37bd8: ldr     x8, [x8, #0xd8]                            T:UnityEngine.Vector3
02d37bdc: adrp    x22, #0x626a000                            
02d37be0: adrp    x28, #0x626a000                            
02d37be4: ldr     x22, [x22, #0xbb8]                         M:BlindBagCollection.ShowCompleteBoxset::<Show>b__11_0
02d37be8: adrp    x23, #0x626a000                            
02d37bec: ldr     x28, [x28, #0xbc0]                         M:BlindBagCollection.ShowCompleteBoxset::<Show>b__11_1
02d37bf0: ldr     x8, [x8]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d37bf4: adrp    x26, #0x6266000                            
02d37bf8: ldr     x23, [x23, #0xbb0]                         M:BlindBagCollection.ShowCompleteBoxset::SetBoxsetToNormal
02d37bfc: ldr     x26, [x26, #0x928]                         MS:DG.Tweening.TweenSettingsExtensions::OnComplete
02d37c00: adrp    x25, #0x626a000                            
02d37c04: ldr     x8, [x8, #0xb8]                            MS:DG.Tweening.Core.Extensions::SetSpecialStartupMode
02d37c08: ldr     x25, [x25, #0xba8]                         M:BlindBagCollection.ShowCompleteBoxset::OnComplete
02d37c0c: mov     x0, x20                                    
02d37c10: mov     x1, xzr                                    
02d37c14: ldp     s1, s2, [x8, #4]                           
02d37c18: ldr     s0, [x8]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d37c1c: bl      #0x5b45cec                                 UnityEngine.Transform::set_localPosition
02d37c20: mov     x0, x19                                    
02d37c24: bl      #0x2d3bb50                                 BlindBagCollection.ShowCompleteBoxset::OnShow
02d37c28: ldr     x0, [x21]                                  &2c5bbd4(=a9bd7bfdd503233f)
02d37c2c: ldr     w8, [x0, #0xe4]                            [62640e4]=0 f=0,0
02d37c30: cbnz    w8, #0x2d37c38                             
02d37c34: bl      #0x2b70f30                                 fn_2b70f30
02d37c38: mov     x0, xzr                                    
02d37c3c: bl      #0x2d8cfe8                                 DG.Tweening.DOTween::Sequence
02d37c40: mov     x20, x19                                   
02d37c44: mov     x1, x0                                     
02d37c48: str     x0, [x20, #0x68]!                          ._sq
02d37c4c: mov     x0, x20                                    
02d37c50: bl      #0x2b70d54                                 fn_2b70d54
02d37c54: adrp    x8, #0x1084000                             
02d37c58: fmov    s0, #1.00000000                            
02d37c5c: ldr     x0, [x19, #0x50]                           ._boxsetTransform
02d37c60: ldr     s8, [x8, #0xe60]                           [1084e60]=bc8efa353eb33333 f=0.35,-0.0174533
02d37c64: ldr     x21, [x20]                                 
02d37c68: mov     x1, xzr                                    
02d37c6c: fmov    s1, s8                                     
02d37c70: bl      #0x2d98c98                                 DG.Tweening.ShortcutExtensions::DOScale
02d37c74: ldr     x2, [x27]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d37c78: mov     w1, #0x1b                                  
02d37c7c: bl      #0x336fa0c                                 fn_336fa0c
02d37c80: adrp    x8, #0x1084000                             
02d37c84: mov     w1, #1                                     
02d37c88: mov     w2, wzr                                    
02d37c8c: ldr     s0, [x8, #0xf10]                           [1084f10]=4110bc863e99999a f=0.3,9.04603
02d37c90: mov     x3, xzr                                    
02d37c94: bl      #0x2da0560                                 DG.Tweening.TweenSettingsExtensions::From
02d37c98: mov     x1, x0                                     
02d37c9c: mov     x0, x21                                    
02d37ca0: mov     x2, xzr                                    
02d37ca4: bl      #0x2d9b0a8                                 DG.Tweening.TweenSettingsExtensions::Append
02d37ca8: ldr     x0, [x24]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d37cac: ldr     x21, [x20]                                 
02d37cb0: bl      #0x2b7104c                                 fn_2b7104c
02d37cb4: ldr     x2, [x22]                                  T:type56879(k15)
02d37cb8: mov     x1, x19                                    
02d37cbc: mov     x3, xzr                                    
02d37cc0: mov     x22, x0                                    
02d37cc4: bl      #0x2d89dc4                                 DG.Tweening.TweenCallback::.ctor
02d37cc8: mov     x0, x21                                    
02d37ccc: mov     x1, x22                                    
02d37cd0: mov     x2, xzr                                    
02d37cd4: bl      #0x2da03d8                                 DG.Tweening.TweenSettingsExtensions::AppendCallback
02d37cd8: fmov    s0, #2.00000000                            
02d37cdc: ldr     x0, [x20]                                  
02d37ce0: mov     x1, xzr                                    
02d37ce4: bl      #0x2d8f450                                 DG.Tweening.TweenSettingsExtensions::AppendInterval
02d37ce8: ldr     x0, [x24]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d37cec: ldr     x21, [x20]                                 
02d37cf0: bl      #0x2b7104c                                 fn_2b7104c
02d37cf4: ldr     x2, [x28]                                  T:type56879(k15)
02d37cf8: mov     x1, x19                                    
02d37cfc: mov     x3, xzr                                    
02d37d00: mov     x22, x0                                    
02d37d04: bl      #0x2d89dc4                                 DG.Tweening.TweenCallback::.ctor
02d37d08: mov     x0, x21                                    
02d37d0c: mov     x1, x22                                    
02d37d10: mov     x2, xzr                                    
02d37d14: bl      #0x2da03d8                                 DG.Tweening.TweenSettingsExtensions::AppendCallback
02d37d18: fmov    s0, s8                                     
02d37d1c: ldr     x0, [x20]                                  
02d37d20: mov     x1, xzr                                    
02d37d24: bl      #0x2d8f450                                 DG.Tweening.TweenSettingsExtensions::AppendInterval
02d37d28: fmov    s1, #0.50000000                            
02d37d2c: ldr     x0, [x19, #0x50]                           ._boxsetTransform
02d37d30: ldr     s0, [x19, #0x4c]                           
02d37d34: ldr     x21, [x20]                                 
02d37d38: mov     w1, wzr                                    
02d37d3c: mov     x2, xzr                                    
02d37d40: bl      #0x2d97988                                 DG.Tweening.ShortcutExtensions::DOMoveY
02d37d44: ldr     x2, [x27]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d37d48: mov     w1, #0x1b                                  
02d37d4c: bl      #0x336fa0c                                 fn_336fa0c
02d37d50: ldr     x8, [x24]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d37d54: mov     x22, x0                                    
02d37d58: mov     x0, x8                                     
02d37d5c: bl      #0x2b7104c                                 fn_2b7104c
02d37d60: ldr     x2, [x23]                                  T:type56879(k15)
02d37d64: mov     x1, x19                                    
02d37d68: mov     x3, xzr                                    
02d37d6c: mov     x23, x0                                    
02d37d70: bl      #0x2d89dc4                                 DG.Tweening.TweenCallback::.ctor
02d37d74: ldr     x2, [x26]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d37d78: mov     x0, x22                                    
02d37d7c: mov     x1, x23                                    
02d37d80: bl      #0x336f26c                                 fn_336f26c
02d37d84: mov     x1, x0                                     
02d37d88: mov     x0, x21                                    
02d37d8c: mov     x2, xzr                                    
02d37d90: bl      #0x2d9b0a8                                 DG.Tweening.TweenSettingsExtensions::Append
02d37d94: fmov    s0, #1.00000000                            
02d37d98: fmov    s1, #0.25000000                            
02d37d9c: ldr     x0, [x19, #0x20]                           ._screenCanvasGroup
02d37da0: ldr     x21, [x20]                                 
02d37da4: mov     x1, xzr                                    
02d37da8: bl      #0x2c78338                                 DG.Tweening.DOTweenModuleUI::DOFade
02d37dac: mov     x1, x0                                     
02d37db0: mov     x0, x21                                    
02d37db4: mov     x2, xzr                                    
02d37db8: bl      #0x2d9b0ec                                 DG.Tweening.TweenSettingsExtensions::Join
02d37dbc: movi    d0, #0000000000000000                      
02d37dc0: fmov    s1, #0.25000000                            
02d37dc4: ldr     x0, [x19, #0x28]                           ._overlay
02d37dc8: ldr     x21, [x20]                                 
02d37dcc: mov     x1, xzr                                    
02d37dd0: bl      #0x2c77d0c                                 DG.Tweening.DOTweenModuleSprite::DOFade
02d37dd4: mov     x1, x0                                     
02d37dd8: mov     x0, x21                                    
02d37ddc: mov     x2, xzr                                    
02d37de0: bl      #0x2d9b0ec                                 DG.Tweening.TweenSettingsExtensions::Join
02d37de4: ldr     x0, [x24]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d37de8: ldr     x20, [x20]                                 
02d37dec: bl      #0x2b7104c                                 fn_2b7104c
02d37df0: ldr     x2, [x25]                                  T:type56879(k15)
02d37df4: mov     x1, x19                                    
02d37df8: mov     x3, xzr                                    
02d37dfc: mov     x21, x0                                    
02d37e00: bl      #0x2d89dc4                                 DG.Tweening.TweenCallback::.ctor
02d37e04: mov     x0, x20                                    
02d37e08: mov     x1, x21                                    
02d37e0c: ldr     x30, [sp, #8]                              
02d37e10: ldp     x20, x19, [sp, #0x50]                      
02d37e14: mov     x2, xzr                                    
02d37e18: ldp     x22, x21, [sp, #0x40]                      
02d37e1c: ldp     x24, x23, [sp, #0x30]                      
02d37e20: ldp     x26, x25, [sp, #0x20]                      
02d37e24: ldp     x28, x27, [sp, #0x10]                      
02d37e28: ldr     d8, [sp], #0x60                            
02d37e2c: b       #0x2da03d8                                 DG.Tweening.TweenSettingsExtensions::AppendCallback
02d37e30: bl      #0x2b7105c                                 fn_2b7105c
## SetBoxsetToNormal() -> void
---- BlindBagCollection.ShowCompleteBoxset::SetBoxsetToNormal 0x2d3bc38
02d3bc38: str     x30, [sp, #-0x20]!                         
02d3bc3c: stp     x20, x19, [sp, #0x10]                      
02d3bc40: mov     x20, x0                                    
02d3bc44: mov     x19, x0                                    
02d3bc48: ldr     x0, [x20, #0x50]!                          ._boxsetTransform
02d3bc4c: cbz     x0, #0x2d3bc8c                             
02d3bc50: ldr     x1, [x19, #0x58]                           ._boxsetParent
02d3bc54: mov     x2, xzr                                    
02d3bc58: bl      #0x5b472ec                                 UnityEngine.Transform::SetParent
02d3bc5c: ldr     x0, [x19, #0x50]                           ._boxsetTransform
02d3bc60: cbz     x0, #0x2d3bc8c                             
02d3bc64: movi    d2, #0000000000000000                      
02d3bc68: ldp     s0, s1, [x19, #0x48]                       ._boxsetStartPosititon
02d3bc6c: mov     x1, xzr                                    
02d3bc70: bl      #0x5b46888                                 UnityEngine.Transform::set_position
02d3bc74: mov     x0, x20                                    
02d3bc78: str     xzr, [x19, #0x50]                          ._boxsetTransform
02d3bc7c: mov     x1, xzr                                    
02d3bc80: ldp     x20, x19, [sp, #0x10]                      
02d3bc84: ldr     x30, [sp], #0x20                           
02d3bc88: b       #0x2b70d54                                 
02d3bc8c: bl      #0x2b7105c                                 fn_2b7105c
## OnShow() -> void
---- BlindBagCollection.ShowCompleteBoxset::OnShow 0x2d3bb50
02d3bb50: stp     x30, x19, [sp, #-0x10]!                    
02d3bb54: mov     x19, x0                                    
02d3bb58: ldr     x0, [x0, #0x40]                            ._root
02d3bb5c: cbz     x0, #0x2d3bc34                             
02d3bb60: mov     w1, #1                                     
02d3bb64: mov     x2, xzr                                    
02d3bb68: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d3bb6c: ldr     x0, [x19, #0x38]                           ._confettiParticle
02d3bb70: cbz     x0, #0x2d3bc34                             
02d3bb74: mov     x1, xzr                                    
02d3bb78: bl      #0x5b339ec                                 UnityEngine.Component::get_gameObject
02d3bb7c: cbz     x0, #0x2d3bc34                             
02d3bb80: mov     w1, #1                                     
02d3bb84: mov     x2, xzr                                    
02d3bb88: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d3bb8c: ldr     x0, [x19, #0x38]                           ._confettiParticle
02d3bb90: cbz     x0, #0x2d3bc34                             
02d3bb94: mov     x1, xzr                                    
02d3bb98: bl      #0x4f86b74                                 AssetKits.ParticleImage.ParticleImage::Play
02d3bb9c: mov     x0, xzr                                    
02d3bba0: bl      #0x2d6eec8                                 Framework.AudioManager::get_Instance
02d3bba4: cbz     x0, #0x2d3bc34                             
02d3bba8: movi    d1, #0000000000000000                      
02d3bbac: movi    d2, #0000000000000000                      
02d3bbb0: mov     w1, #0xb                                   
02d3bbb4: fmov    s0, #1.00000000                            
02d3bbb8: mov     w2, wzr                                    
02d3bbbc: mov     w3, wzr                                    
02d3bbc0: mov     x4, xzr                                    
02d3bbc4: bl      #0x2d6f03c                                 Framework.AudioManager::PlaySound
02d3bbc8: ldr     x0, [x19, #0x60]                           ._2dRaycaster
02d3bbcc: cbz     x0, #0x2d3bc34                             
02d3bbd0: mov     w1, wzr                                    
02d3bbd4: mov     x2, xzr                                    
02d3bbd8: bl      #0x5b33110                                 UnityEngine.Behaviour::set_enabled
02d3bbdc: ldr     x0, [x19, #0x20]                           ._screenCanvasGroup
02d3bbe0: cbz     x0, #0x2d3bc34                             
02d3bbe4: mov     w1, wzr                                    
02d3bbe8: mov     x2, xzr                                    
02d3bbec: bl      #0x5e45290                                 UnityEngine.CanvasGroup::set_interactable
02d3bbf0: movi    d0, #0000000000000000                      
02d3bbf4: fmov    s1, #0.25000000                            
02d3bbf8: ldr     x0, [x19, #0x20]                           ._screenCanvasGroup
02d3bbfc: mov     x1, xzr                                    
02d3bc00: bl      #0x2c78338                                 DG.Tweening.DOTweenModuleUI::DOFade
02d3bc04: adrp    x8, #0x1084000                             
02d3bc08: fmov    s1, #0.25000000                            
02d3bc0c: ldr     x0, [x19, #0x28]                           ._overlay
02d3bc10: ldr     s0, [x8, #0xcc4]                           [1084cc4]=3f8000543f4ccccd f=0.8,1.00001
02d3bc14: mov     x1, xzr                                    
02d3bc18: bl      #0x2c77d0c                                 DG.Tweening.DOTweenModuleSprite::DOFade
02d3bc1c: movi    d0, #0000000000000000                      
02d3bc20: mov     w1, #1                                     
02d3bc24: mov     w2, wzr                                    
02d3bc28: mov     x3, xzr                                    
02d3bc2c: ldp     x30, x19, [sp], #0x10                      
02d3bc30: b       #0x2da04b8                                 DG.Tweening.TweenSettingsExtensions::From
02d3bc34: bl      #0x2b7105c                                 fn_2b7105c
## OnComplete() -> void
---- BlindBagCollection.ShowCompleteBoxset::OnComplete 0x2d3bc90
02d3bc90: stp     x30, x19, [sp, #-0x10]!                    
02d3bc94: mov     x19, x0                                    
02d3bc98: ldr     x0, [x0, #0x38]                            ._confettiParticle
02d3bc9c: cbz     x0, #0x2d3bcf8                             
02d3bca0: mov     x1, xzr                                    
02d3bca4: bl      #0x5b339ec                                 UnityEngine.Component::get_gameObject
02d3bca8: cbz     x0, #0x2d3bcf8                             
02d3bcac: mov     w1, wzr                                    
02d3bcb0: mov     x2, xzr                                    
02d3bcb4: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d3bcb8: ldr     x0, [x19, #0x20]                           ._screenCanvasGroup
02d3bcbc: cbz     x0, #0x2d3bcf8                             
02d3bcc0: mov     w1, #1                                     
02d3bcc4: mov     x2, xzr                                    
02d3bcc8: bl      #0x5e45290                                 UnityEngine.CanvasGroup::set_interactable
02d3bccc: ldr     x0, [x19, #0x40]                           ._root
02d3bcd0: cbz     x0, #0x2d3bcf8                             
02d3bcd4: mov     w1, wzr                                    
02d3bcd8: mov     x2, xzr                                    
02d3bcdc: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d3bce0: ldr     x0, [x19, #0x60]                           ._2dRaycaster
02d3bce4: cbz     x0, #0x2d3bcf8                             
02d3bce8: mov     w1, #1                                     
02d3bcec: mov     x2, xzr                                    
02d3bcf0: ldp     x30, x19, [sp], #0x10                      
02d3bcf4: b       #0x5b33110                                 UnityEngine.Behaviour::set_enabled
02d3bcf8: bl      #0x2b7105c                                 fn_2b7105c
## .ctor() -> void
---- BlindBagCollection.ShowCompleteBoxset::.ctor 0x2d3bcfc
02d3bcfc: mov     x1, xzr                                    
02d3bd00: b       #0x5b397b0                                 UnityEngine.MonoBehaviour::.ctor
## <Show>b__11_0() -> void
---- BlindBagCollection.ShowCompleteBoxset::<Show>b__11_0 0x2d3bd04
02d3bd04: ldr     x0, [x0, #0x30]                            ._headerAnimation
02d3bd08: cbz     x0, #0x2d3bd18                             
02d3bd0c: ldr     x8, [x0]                                   
02d3bd10: ldp     x2, x1, [x8, #0x1d8]                       
02d3bd14: br      x2                                         
02d3bd18: str     x30, [sp, #-0x10]!                         
02d3bd1c: bl      #0x2b7105c                                 fn_2b7105c
## <Show>b__11_1() -> void
---- BlindBagCollection.ShowCompleteBoxset::<Show>b__11_1 0x2d3bd20
02d3bd20: ldr     x0, [x0, #0x30]                            ._headerAnimation
02d3bd24: cbz     x0, #0x2d3bd34                             
02d3bd28: ldr     x8, [x0]                                   
02d3bd2c: ldp     x2, x1, [x8, #0x188]                       
02d3bd30: br      x2                                         
02d3bd34: str     x30, [sp, #-0x10]!                         
02d3bd38: bl      #0x2b7105c                                 fn_2b7105c
