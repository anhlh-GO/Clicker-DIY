#### CLASS Livestream.DonatePanel parent= UnityEngine.MonoBehaviour
#   field _avatar                        UnityEngine.UI.Image                               off=0x20 attr=1 SerializeField
#   field _claimButton                   UnityEngine.UI.Button                              off=0x28 attr=1 SerializeField
#   field _money                         MoneyManager                                       off=0x30 attr=1 SerializeField
#   field _effect                        Coffee.UIExtensions.ShinyEffectForUGUI             off=0x38 attr=1 SerializeField
#   field _avatarSprites                 System.Collections.Generic.List`1<UnityEngine.Sprite> off=0x40 attr=1 SerializeField
#   field _countdownTween                DG.Tweening.Tween                                  off=0x48 attr=1 
## OnInit() -> void
---- Livestream.DonatePanel::OnInit 0x2d11698
02d11698: stp     x30, x21, [sp, #-0x20]!                    
02d1169c: stp     x20, x19, [sp, #0x10]                      
02d116a0: adrp    x20, #0x662f000                            
02d116a4: adrp    x21, #0x6269000                            
02d116a8: mov     x19, x0                                    
02d116ac: ldrb    w8, [x20, #0xfb7]                          
02d116b0: ldr     x21, [x21, #0x7a0]                         MS:FrameWorkUtility::PickRandom
02d116b4: tbnz    w8, #0, #0x2d116e4                         
02d116b8: adrp    x0, #0x6269000                             
02d116bc: ldr     x0, [x0, #0x7a8]                           M:Livestream.DonatePanel::OnClaimButtonClicked
02d116c0: bl      #0x2b70db0                                 fn_2b70db0
02d116c4: adrp    x0, #0x6269000                             
02d116c8: ldr     x0, [x0, #0x7a0]                           MS:FrameWorkUtility::PickRandom
02d116cc: bl      #0x2b70db0                                 fn_2b70db0
02d116d0: adrp    x0, #0x6265000                             
02d116d4: ldr     x0, [x0, #0x3f0]                           T:UnityEngine.Events.UnityAction
02d116d8: bl      #0x2b70db0                                 fn_2b70db0
02d116dc: mov     w8, #1                                     
02d116e0: strb    w8, [x20, #0xfb7]                          
02d116e4: ldr     x0, [x19, #0x40]                           ._avatarSprites
02d116e8: ldr     x1, [x21]                                  T:Trading.TradingSession/<>c__DisplayClass56_0
02d116ec: ldr     x20, [x19, #0x20]                          ._avatar
02d116f0: bl      #0x31cf844                                 fn_31cf844
02d116f4: cbz     x20, #0x2d117cc                            
02d116f8: mov     x1, x0                                     
02d116fc: mov     x0, x20                                    
02d11700: mov     x2, xzr                                    
02d11704: bl      #0x5c45aa0                                 UnityEngine.UI.Image::set_sprite
02d11708: ldr     x8, [x19, #0x28]                           ._claimButton
02d1170c: cbz     x8, #0x2d117cc                             
02d11710: adrp    x9, #0x6265000                             
02d11714: adrp    x21, #0x6269000                            
02d11718: ldr     x9, [x9, #0x3f0]                           T:UnityEngine.Events.UnityAction
02d1171c: ldr     x21, [x21, #0x7a8]                         M:Livestream.DonatePanel::OnClaimButtonClicked
02d11720: ldr     x20, [x8, #0x100]                          
02d11724: ldr     x0, [x9]                                   M:AdsManager::<OnApplicationPause>b__26_0
02d11728: bl      #0x2b7104c                                 fn_2b7104c
02d1172c: ldr     x2, [x21]                                  T:Trading.TradingSession/<>c__DisplayClass56_0
02d11730: mov     x1, x19                                    
02d11734: mov     x3, xzr                                    
02d11738: mov     x21, x0                                    
02d1173c: bl      #0x5b4cf98                                 UnityEngine.Events.UnityAction::.ctor
02d11740: cbz     x20, #0x2d117cc                            
02d11744: mov     x0, x20                                    
02d11748: mov     x1, x21                                    
02d1174c: mov     x2, xzr                                    
02d11750: bl      #0x5b4d0ac                                 UnityEngine.Events.UnityEvent::AddListener
02d11754: mov     x0, x19                                    
02d11758: mov     x1, xzr                                    
02d1175c: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02d11760: mov     w1, wzr                                    
02d11764: mov     x2, xzr                                    
02d11768: bl      #0x2d9d5d0                                 DG.Tweening.ShortcutExtensions::DOKill
02d1176c: mov     x0, x19                                    
02d11770: mov     x1, xzr                                    
02d11774: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02d11778: adrp    x20, #0x662f000                            
02d1177c: mov     x19, x0                                    
02d11780: ldrb    w8, [x20, #0x91a]                          
02d11784: cbnz    w8, #0x2d1179c                             
02d11788: adrp    x0, #0x6264000                             
02d1178c: ldr     x0, [x0, #0xd8]                            T:UnityEngine.Vector3
02d11790: bl      #0x2b70db0                                 fn_2b70db0
02d11794: mov     w8, #1                                     
02d11798: strb    w8, [x20, #0x91a]                          
02d1179c: cbz     x19, #0x2d117cc                            
02d117a0: adrp    x8, #0x6264000                             
02d117a4: mov     x0, x19                                    
02d117a8: mov     x1, xzr                                    
02d117ac: ldr     x8, [x8, #0xd8]                            T:UnityEngine.Vector3
02d117b0: ldp     x20, x19, [sp, #0x10]                      
02d117b4: ldr     x8, [x8]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d117b8: ldr     x8, [x8, #0xb8]                            MS:DG.Tweening.Core.Extensions::SetSpecialStartupMode
02d117bc: ldp     s0, s1, [x8]                               
02d117c0: ldr     s2, [x8, #8]                               T:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass2_0
02d117c4: ldp     x30, x21, [sp], #0x20                      
02d117c8: b       #0x5b470cc                                 UnityEngine.Transform::set_localScale
02d117cc: bl      #0x2b7105c                                 fn_2b7105c
## OnClaimButtonClicked() -> void
---- Livestream.DonatePanel::OnClaimButtonClicked 0x2d117d0
02d117d0: stp     x30, x19, [sp, #-0x10]!                    
02d117d4: mov     x19, x0                                    
02d117d8: mov     x0, xzr                                    
02d117dc: bl      #0x2d6eec8                                 Framework.AudioManager::get_Instance
02d117e0: cbz     x0, #0x2d1183c                             
02d117e4: movi    d1, #0000000000000000                      
02d117e8: movi    d2, #0000000000000000                      
02d117ec: mov     w1, #1                                     
02d117f0: fmov    s0, #1.00000000                            
02d117f4: mov     w2, wzr                                    
02d117f8: mov     w3, wzr                                    
02d117fc: mov     x4, xzr                                    
02d11800: bl      #0x2d6f03c                                 Framework.AudioManager::PlaySound
02d11804: ldr     x0, [x19, #0x48]                           ._countdownTween
02d11808: mov     w1, wzr                                    
02d1180c: mov     x2, xzr                                    
02d11810: bl      #0x2d8fe94                                 DG.Tweening.TweenExtensions::Kill
02d11814: ldr     x0, [x19, #0x30]                           ._money
02d11818: cbz     x0, #0x2d1183c                             
02d1181c: mov     w1, #0x3e8                                 
02d11820: mov     w2, #0xa                                   
02d11824: mov     x3, xzr                                    
02d11828: mov     x4, xzr                                    
02d1182c: bl      #0x2cdaf30                                 MoneyManager::CollectMoney
02d11830: mov     x0, x19                                    
02d11834: ldp     x30, x19, [sp], #0x10                      
02d11838: b       #0x2d11840                                 Livestream.DonatePanel::OnHide
02d1183c: bl      #0x2b7105c                                 fn_2b7105c
## OnDestroy() -> void
---- Livestream.DonatePanel::OnDestroy 0x2d118ec
02d118ec: stp     x30, x19, [sp, #-0x10]!                    
02d118f0: mov     x1, xzr                                    
02d118f4: mov     x19, x0                                    
02d118f8: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02d118fc: mov     w1, wzr                                    
02d11900: mov     x2, xzr                                    
02d11904: bl      #0x2d9d5d0                                 DG.Tweening.ShortcutExtensions::DOKill
02d11908: ldr     x0, [x19, #0x48]                           ._countdownTween
02d1190c: cbz     x0, #0x2d11920                             
02d11910: mov     w1, wzr                                    
02d11914: mov     x2, xzr                                    
02d11918: ldp     x30, x19, [sp], #0x10                      
02d1191c: b       #0x2d8fe94                                 DG.Tweening.TweenExtensions::Kill
02d11920: ldp     x30, x19, [sp], #0x10                      
02d11924: ret                                                
## OnShow() -> void
---- Livestream.DonatePanel::OnShow 0x2d11928
02d11928: stp     x30, x23, [sp, #-0x30]!                    
02d1192c: stp     x22, x21, [sp, #0x10]                      
02d11930: stp     x20, x19, [sp, #0x20]                      
02d11934: adrp    x20, #0x662f000                            
02d11938: mov     x19, x0                                    
02d1193c: ldrb    w8, [x20, #0xfb8]                          
02d11940: tbnz    w8, #0, #0x2d11964                         
02d11944: adrp    x0, #0x6269000                             
02d11948: ldr     x0, [x0, #0x7b0]                           M:Livestream.DonatePanel::OnHide
02d1194c: bl      #0x2b70db0                                 fn_2b70db0
02d11950: adrp    x0, #0x6264000                             
02d11954: ldr     x0, [x0, #0xe8]                            T:DG.Tweening.TweenCallback
02d11958: bl      #0x2b70db0                                 fn_2b70db0
02d1195c: mov     w8, #1                                     
02d11960: strb    w8, [x20, #0xfb8]                          
02d11964: adrp    x22, #0x6264000                            
02d11968: adrp    x21, #0x6269000                            
02d1196c: mov     x0, x19                                    
02d11970: ldr     x22, [x22, #0xe8]                          T:DG.Tweening.TweenCallback
02d11974: ldr     x21, [x21, #0x7b0]                         M:Livestream.DonatePanel::OnHide
02d11978: mov     x1, xzr                                    
02d1197c: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02d11980: mov     w1, wzr                                    
02d11984: mov     x2, xzr                                    
02d11988: bl      #0x2d9d5d0                                 DG.Tweening.ShortcutExtensions::DOKill
02d1198c: mov     x0, x19                                    
02d11990: mov     x1, xzr                                    
02d11994: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02d11998: adrp    x23, #0x662f000                            
02d1199c: mov     x20, x0                                    
02d119a0: ldrb    w8, [x23, #0xa74]                          
02d119a4: cbnz    w8, #0x2d119bc                             
02d119a8: adrp    x0, #0x6264000                             
02d119ac: ldr     x0, [x0, #0xd8]                            T:UnityEngine.Vector3
02d119b0: bl      #0x2b70db0                                 fn_2b70db0
02d119b4: mov     w8, #1                                     
02d119b8: strb    w8, [x23, #0xa74]                          
02d119bc: adrp    x8, #0x6264000                             
02d119c0: mov     x0, x20                                    
02d119c4: mov     x1, xzr                                    
02d119c8: ldr     x8, [x8, #0xd8]                            T:UnityEngine.Vector3
02d119cc: ldr     x8, [x8]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d119d0: ldr     x8, [x8, #0xb8]                            MS:DG.Tweening.Core.Extensions::SetSpecialStartupMode
02d119d4: ldp     s0, s1, [x8, #0xc]                         
02d119d8: ldr     s2, [x8, #0x14]                            [6264014]=0 f=0,0
02d119dc: adrp    x8, #0x1084000                             
02d119e0: ldr     s3, [x8, #0xe60]                           [1084e60]=bc8efa353eb33333 f=0.35,-0.0174533
02d119e4: bl      #0x2d98af8                                 DG.Tweening.ShortcutExtensions::DOScale
02d119e8: ldr     x0, [x22]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d119ec: bl      #0x2b7104c                                 fn_2b7104c
02d119f0: ldr     x2, [x21]                                  T:Trading.TradingSession/<>c__DisplayClass56_0
02d119f4: mov     x1, x19                                    
02d119f8: mov     x3, xzr                                    
02d119fc: mov     x20, x0                                    
02d11a00: bl      #0x2d89dc4                                 DG.Tweening.TweenCallback::.ctor
02d11a04: fmov    s0, #5.50000000                            
02d11a08: mov     x0, x20                                    
02d11a0c: mov     w1, #1                                     
02d11a10: mov     x2, xzr                                    
02d11a14: bl      #0x2d8f37c                                 DG.Tweening.DOVirtual::DelayedCall
02d11a18: mov     x1, x0                                     
02d11a1c: str     x0, [x19, #0x48]!                          ._countdownTween
02d11a20: mov     x0, x19                                    
02d11a24: bl      #0x2b70d54                                 fn_2b70d54
02d11a28: ldur    x0, [x19, #-0x10]                          
02d11a2c: cbz     x0, #0x2d11a4c                             
02d11a30: ldp     x20, x19, [sp, #0x20]                      
02d11a34: fmov    s0, #1.00000000                            
02d11a38: ldp     x22, x21, [sp, #0x10]                      
02d11a3c: mov     w1, wzr                                    
02d11a40: mov     x2, xzr                                    
02d11a44: ldp     x30, x23, [sp], #0x30                      
02d11a48: b       #0x2d7d34c                                 Coffee.UIExtensions.ShinyEffectForUGUI::PlayLoop
02d11a4c: bl      #0x2b7105c                                 fn_2b7105c
## OnHide() -> void
---- Livestream.DonatePanel::OnHide 0x2d11840
02d11840: stp     x30, x21, [sp, #-0x20]!                    
02d11844: stp     x20, x19, [sp, #0x10]                      
02d11848: mov     x19, x0                                    
02d1184c: ldr     x0, [x0, #0x48]                            ._countdownTween
02d11850: mov     w1, wzr                                    
02d11854: mov     x2, xzr                                    
02d11858: bl      #0x2d8fe94                                 DG.Tweening.TweenExtensions::Kill
02d1185c: mov     x0, x19                                    
02d11860: mov     x1, xzr                                    
02d11864: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02d11868: mov     w1, wzr                                    
02d1186c: mov     x2, xzr                                    
02d11870: bl      #0x2d9d5d0                                 DG.Tweening.ShortcutExtensions::DOKill
02d11874: mov     x0, x19                                    
02d11878: mov     x1, xzr                                    
02d1187c: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02d11880: adrp    x21, #0x662f000                            
02d11884: mov     x20, x0                                    
02d11888: ldrb    w8, [x21, #0x91a]                          
02d1188c: cbnz    w8, #0x2d118a4                             
02d11890: adrp    x0, #0x6264000                             
02d11894: ldr     x0, [x0, #0xd8]                            T:UnityEngine.Vector3
02d11898: bl      #0x2b70db0                                 fn_2b70db0
02d1189c: mov     w8, #1                                     
02d118a0: strb    w8, [x21, #0x91a]                          
02d118a4: adrp    x8, #0x6264000                             
02d118a8: mov     x0, x20                                    
02d118ac: mov     x1, xzr                                    
02d118b0: ldr     x8, [x8, #0xd8]                            T:UnityEngine.Vector3
02d118b4: ldr     x8, [x8]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d118b8: ldr     x8, [x8, #0xb8]                            MS:DG.Tweening.Core.Extensions::SetSpecialStartupMode
02d118bc: ldp     s0, s1, [x8]                               
02d118c0: ldr     s2, [x8, #8]                               T:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass2_0
02d118c4: adrp    x8, #0x1084000                             
02d118c8: ldr     s3, [x8, #0xe60]                           [1084e60]=bc8efa353eb33333 f=0.35,-0.0174533
02d118cc: bl      #0x2d98af8                                 DG.Tweening.ShortcutExtensions::DOScale
02d118d0: ldr     x0, [x19, #0x38]                           ._effect
02d118d4: cbz     x0, #0x2d118e8                             
02d118d8: ldp     x20, x19, [sp, #0x10]                      
02d118dc: mov     x1, xzr                                    
02d118e0: ldp     x30, x21, [sp], #0x20                      
02d118e4: b       #0x2d7d33c                                 Coffee.UIExtensions.ShinyEffectForUGUI::Stop
02d118e8: bl      #0x2b7105c                                 fn_2b7105c
## .ctor() -> void
---- Livestream.DonatePanel::.ctor 0x2d11a50
02d11a50: mov     x1, xzr                                    
02d11a54: b       #0x5b397b0                                 UnityEngine.MonoBehaviour::.ctor
