#### CLASS Clicker.CollectionFullPopup/<>c__DisplayClass11_0 parent= object
#   field onBuySuccess                   System.Action                                      off=0x10 attr=6 
## .ctor() -> void
---- Clicker.CollectionFullPopup/<>c__DisplayClass11_0::.ctor 0x2d673e0
02d673e0: mov     x1, xzr                                    
02d673e4: b       #0x4e53e9c                                 System.Object::.ctor
## <SetEventCallback>b__0() -> void
---- Clicker.CollectionFullPopup/<>c__DisplayClass11_0::<SetEventCallback>b__0 0x2d6794c
02d6794c: ldr     x8, [x0, #0x10]                            .onBuySuccess
02d67950: cbz     x8, #0x2d67964                             
02d67954: ldr     x0, [x8, #0x40]                            
02d67958: ldr     x1, [x8, #0x28]                            
02d6795c: ldr     x2, [x8, #0x18]                            
02d67960: br      x2                                         
02d67964: ret                                                
#### CLASS Clicker.CollectionFullPopup parent= PopupBase
#   field _btnWatchAds                   UnityEngine.UI.Button                              off=0x38 attr=1 SerializeField
#   field _btnCoin                       UnityEngine.UI.Button                              off=0x40 attr=1 SerializeField
#   field _btnClose                      UnityEngine.UI.Button                              off=0x48 attr=1 SerializeField
#   field _btnClose2                     UnityEngine.UI.Button                              off=0x50 attr=1 SerializeField
#   field _txtCoinPrice                  TMPro.TextMeshProUGUI                              off=0x58 attr=1 SerializeField
#   field _tfPanel                       UnityEngine.Transform                              off=0x60 attr=1 SerializeField
#   field _coinPrice                     int                                                off=0x68 attr=1 
#   field _onBuySuccess                  UnityEngine.Events.UnityEvent                      off=0x70 attr=1 
## OnInit(UIManager uiManager) -> void
---- Clicker.CollectionFullPopup::OnInit 0x2d66e5c
02d66e5c: stp     x30, x23, [sp, #-0x30]!                    
02d66e60: stp     x22, x21, [sp, #0x10]                      
02d66e64: stp     x20, x19, [sp, #0x20]                      
02d66e68: adrp    x21, #0x6630000                            
02d66e6c: mov     x20, x1                                    
02d66e70: mov     x19, x0                                    
02d66e74: ldrb    w8, [x21, #0x338]                          
02d66e78: tbnz    w8, #0, #0x2d66eb4                         
02d66e7c: adrp    x0, #0x626c000                             
02d66e80: ldr     x0, [x0, #0x1e8]                           M:Clicker.CollectionFullPopup::OnBtnCoinClick
02d66e84: bl      #0x2b70db0                                 fn_2b70db0
02d66e88: adrp    x0, #0x626c000                             
02d66e8c: ldr     x0, [x0, #0x1f0]                           M:Clicker.CollectionFullPopup::OnBtnNoThankClick
02d66e90: bl      #0x2b70db0                                 fn_2b70db0
02d66e94: adrp    x0, #0x626c000                             
02d66e98: ldr     x0, [x0, #0x1f8]                           M:Clicker.CollectionFullPopup::OnBtnWatchAdsClick
02d66e9c: bl      #0x2b70db0                                 fn_2b70db0
02d66ea0: adrp    x0, #0x6265000                             
02d66ea4: ldr     x0, [x0, #0x3f0]                           T:UnityEngine.Events.UnityAction
02d66ea8: bl      #0x2b70db0                                 fn_2b70db0
02d66eac: mov     w8, #1                                     
02d66eb0: strb    w8, [x21, #0x338]                          
02d66eb4: mov     x0, x19                                    
02d66eb8: mov     x1, x20                                    
02d66ebc: mov     x2, xzr                                    
02d66ec0: bl      #0x2cdd3c4                                 UIBase::OnInit
02d66ec4: ldr     x8, [x19, #0x38]                           ._btnWatchAds
02d66ec8: cbz     x8, #0x2d67040                             
02d66ecc: ldr     x0, [x8, #0x100]                           
02d66ed0: cbz     x0, #0x2d67040                             
02d66ed4: mov     x1, xzr                                    
02d66ed8: bl      #0x5b4ce48                                 UnityEngine.Events.UnityEventBase::RemoveAllListeners
02d66edc: ldr     x8, [x19, #0x40]                           ._btnCoin
02d66ee0: cbz     x8, #0x2d67040                             
02d66ee4: ldr     x0, [x8, #0x100]                           
02d66ee8: cbz     x0, #0x2d67040                             
02d66eec: mov     x1, xzr                                    
02d66ef0: bl      #0x5b4ce48                                 UnityEngine.Events.UnityEventBase::RemoveAllListeners
02d66ef4: ldr     x8, [x19, #0x48]                           ._btnClose
02d66ef8: cbz     x8, #0x2d67040                             
02d66efc: ldr     x0, [x8, #0x100]                           
02d66f00: cbz     x0, #0x2d67040                             
02d66f04: mov     x1, xzr                                    
02d66f08: bl      #0x5b4ce48                                 UnityEngine.Events.UnityEventBase::RemoveAllListeners
02d66f0c: ldr     x8, [x19, #0x50]                           ._btnClose2
02d66f10: cbz     x8, #0x2d67040                             
02d66f14: ldr     x0, [x8, #0x100]                           
02d66f18: cbz     x0, #0x2d67040                             
02d66f1c: mov     x1, xzr                                    
02d66f20: bl      #0x5b4ce48                                 UnityEngine.Events.UnityEventBase::RemoveAllListeners
02d66f24: ldr     x8, [x19, #0x38]                           ._btnWatchAds
02d66f28: cbz     x8, #0x2d67040                             
02d66f2c: adrp    x22, #0x6265000                            
02d66f30: adrp    x21, #0x626c000                            
02d66f34: ldr     x22, [x22, #0x3f0]                         T:UnityEngine.Events.UnityAction
02d66f38: ldr     x21, [x21, #0x1f8]                         M:Clicker.CollectionFullPopup::OnBtnWatchAdsClick
02d66f3c: ldr     x20, [x8, #0x100]                          
02d66f40: ldr     x0, [x22]                                  M:AdsManager::<OnApplicationPause>b__26_0
02d66f44: bl      #0x2b7104c                                 fn_2b7104c
02d66f48: ldr     x2, [x21]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d66f4c: mov     x1, x19                                    
02d66f50: mov     x3, xzr                                    
02d66f54: mov     x21, x0                                    
02d66f58: bl      #0x5b4cf98                                 UnityEngine.Events.UnityAction::.ctor
02d66f5c: cbz     x20, #0x2d67040                            
02d66f60: mov     x0, x20                                    
02d66f64: mov     x1, x21                                    
02d66f68: mov     x2, xzr                                    
02d66f6c: bl      #0x5b4d0ac                                 UnityEngine.Events.UnityEvent::AddListener
02d66f70: ldr     x8, [x19, #0x40]                           ._btnCoin
02d66f74: cbz     x8, #0x2d67040                             
02d66f78: adrp    x21, #0x626c000                            
02d66f7c: ldr     x21, [x21, #0x1e8]                         M:Clicker.CollectionFullPopup::OnBtnCoinClick
02d66f80: ldr     x0, [x22]                                  M:AdsManager::<OnApplicationPause>b__26_0
02d66f84: ldr     x20, [x8, #0x100]                          
02d66f88: bl      #0x2b7104c                                 fn_2b7104c
02d66f8c: ldr     x2, [x21]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d66f90: mov     x1, x19                                    
02d66f94: mov     x3, xzr                                    
02d66f98: mov     x21, x0                                    
02d66f9c: bl      #0x5b4cf98                                 UnityEngine.Events.UnityAction::.ctor
02d66fa0: cbz     x20, #0x2d67040                            
02d66fa4: mov     x0, x20                                    
02d66fa8: mov     x1, x21                                    
02d66fac: mov     x2, xzr                                    
02d66fb0: bl      #0x5b4d0ac                                 UnityEngine.Events.UnityEvent::AddListener
02d66fb4: ldr     x8, [x19, #0x48]                           ._btnClose
02d66fb8: cbz     x8, #0x2d67040                             
02d66fbc: adrp    x23, #0x626c000                            
02d66fc0: ldr     x23, [x23, #0x1f0]                         M:Clicker.CollectionFullPopup::OnBtnNoThankClick
02d66fc4: ldr     x0, [x22]                                  M:AdsManager::<OnApplicationPause>b__26_0
02d66fc8: ldr     x20, [x8, #0x100]                          
02d66fcc: bl      #0x2b7104c                                 fn_2b7104c
02d66fd0: ldr     x2, [x23]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d66fd4: mov     x1, x19                                    
02d66fd8: mov     x3, xzr                                    
02d66fdc: mov     x21, x0                                    
02d66fe0: bl      #0x5b4cf98                                 UnityEngine.Events.UnityAction::.ctor
02d66fe4: cbz     x20, #0x2d67040                            
02d66fe8: mov     x0, x20                                    
02d66fec: mov     x1, x21                                    
02d66ff0: mov     x2, xzr                                    
02d66ff4: bl      #0x5b4d0ac                                 UnityEngine.Events.UnityEvent::AddListener
02d66ff8: ldr     x8, [x19, #0x50]                           ._btnClose2
02d66ffc: cbz     x8, #0x2d67040                             
02d67000: ldr     x0, [x22]                                  M:AdsManager::<OnApplicationPause>b__26_0
02d67004: ldr     x20, [x8, #0x100]                          
02d67008: bl      #0x2b7104c                                 fn_2b7104c
02d6700c: ldr     x2, [x23]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d67010: mov     x1, x19                                    
02d67014: mov     x3, xzr                                    
02d67018: mov     x21, x0                                    
02d6701c: bl      #0x5b4cf98                                 UnityEngine.Events.UnityAction::.ctor
02d67020: cbz     x20, #0x2d67040                            
02d67024: mov     x0, x20                                    
02d67028: mov     x1, x21                                    
02d6702c: mov     x2, xzr                                    
02d67030: ldp     x20, x19, [sp, #0x20]                      
02d67034: ldp     x22, x21, [sp, #0x10]                      
02d67038: ldp     x30, x23, [sp], #0x30                      
02d6703c: b       #0x5b4d0ac                                 UnityEngine.Events.UnityEvent::AddListener
02d67040: bl      #0x2b7105c                                 fn_2b7105c
## OnShow() -> void
---- Clicker.CollectionFullPopup::OnShow 0x2d67044
02d67044: stp     x30, x25, [sp, #-0x40]!                    
02d67048: stp     x24, x23, [sp, #0x10]                      
02d6704c: stp     x22, x21, [sp, #0x20]                      
02d67050: stp     x20, x19, [sp, #0x30]                      
02d67054: adrp    x20, #0x6630000                            
02d67058: adrp    x21, #0x6265000                            
02d6705c: mov     x19, x0                                    
02d67060: ldrb    w8, [x20, #0x339]                          
02d67064: ldr     x21, [x21, #0x310]                         MS:WejoyService.Singleton`1::get_Instance
02d67068: tbnz    w8, #0, #0x2d670bc                         
02d6706c: adrp    x0, #0x626c000                             
02d67070: ldr     x0, [x0, #0x200]                           M:Clicker.CollectionFullPopup::<OnShow>b__9_0
02d67074: bl      #0x2b70db0                                 fn_2b70db0
02d67078: adrp    x0, #0x6266000                             
02d6707c: ldr     x0, [x0, #0xaa0]                           MS:MonoSingleton`1::get_Instance
02d67080: bl      #0x2b70db0                                 fn_2b70db0
02d67084: adrp    x0, #0x6265000                             
02d67088: ldr     x0, [x0, #0x310]                           MS:WejoyService.Singleton`1::get_Instance
02d6708c: bl      #0x2b70db0                                 fn_2b70db0
02d67090: adrp    x0, #0x6264000                             
02d67094: ldr     x0, [x0, #0xe8]                            T:DG.Tweening.TweenCallback
02d67098: bl      #0x2b70db0                                 fn_2b70db0
02d6709c: adrp    x0, #0x6266000                             
02d670a0: ldr     x0, [x0, #0x928]                           MS:DG.Tweening.TweenSettingsExtensions::OnComplete
02d670a4: bl      #0x2b70db0                                 fn_2b70db0
02d670a8: adrp    x0, #0x6266000                             
02d670ac: ldr     x0, [x0, #0x880]                           MS:DG.Tweening.TweenSettingsExtensions::SetEase
02d670b0: bl      #0x2b70db0                                 fn_2b70db0
02d670b4: mov     w8, #1                                     
02d670b8: strb    w8, [x20, #0x339]                          
02d670bc: ldr     x0, [x21]                                  M:AdsManager::<OnApplicationPause>b__26_0
02d670c0: bl      #0x3be7218                                 fn_3be7218
02d670c4: cbz     x0, #0x2d67230                             
02d670c8: mov     w1, #4                                     
02d670cc: mov     x2, xzr                                    
02d670d0: bl      #0x2c8a650                                 AdsManager::ShowMREC
02d670d4: mov     x0, x19                                    
02d670d8: mov     x1, xzr                                    
02d670dc: bl      #0x2cdd6b8                                 UIBase::OnShow
02d670e0: ldr     x0, [x19, #0x38]                           ._btnWatchAds
02d670e4: cbz     x0, #0x2d67230                             
02d670e8: mov     w1, wzr                                    
02d670ec: mov     x2, xzr                                    
02d670f0: bl      #0x5e662d4                                 UnityEngine.UI.Selectable::set_interactable
02d670f4: ldr     x0, [x19, #0x40]                           ._btnCoin
02d670f8: cbz     x0, #0x2d67230                             
02d670fc: mov     w1, wzr                                    
02d67100: mov     x2, xzr                                    
02d67104: bl      #0x5e662d4                                 UnityEngine.UI.Selectable::set_interactable
02d67108: ldr     x0, [x19, #0x48]                           ._btnClose
02d6710c: cbz     x0, #0x2d67230                             
02d67110: mov     w1, wzr                                    
02d67114: mov     x2, xzr                                    
02d67118: bl      #0x5e662d4                                 UnityEngine.UI.Selectable::set_interactable
02d6711c: ldr     x0, [x19, #0x50]                           ._btnClose2
02d67120: cbz     x0, #0x2d67230                             
02d67124: mov     w1, wzr                                    
02d67128: mov     x2, xzr                                    
02d6712c: bl      #0x5e662d4                                 UnityEngine.UI.Selectable::set_interactable
02d67130: ldr     x0, [x19, #0x60]                           ._tfPanel
02d67134: mov     w1, wzr                                    
02d67138: mov     x2, xzr                                    
02d6713c: bl      #0x2d9d5d0                                 DG.Tweening.ShortcutExtensions::DOKill
02d67140: adrp    x21, #0x662f000                            
02d67144: ldr     x20, [x19, #0x60]                          ._tfPanel
02d67148: ldrb    w8, [x21, #0x91a]                          
02d6714c: cbnz    w8, #0x2d67164                             
02d67150: adrp    x0, #0x6264000                             
02d67154: ldr     x0, [x0, #0xd8]                            T:UnityEngine.Vector3
02d67158: bl      #0x2b70db0                                 fn_2b70db0
02d6715c: mov     w8, #1                                     
02d67160: strb    w8, [x21, #0x91a]                          
02d67164: cbz     x20, #0x2d67230                            
02d67168: adrp    x8, #0x6264000                             
02d6716c: adrp    x21, #0x6266000                            
02d67170: adrp    x22, #0x6264000                            
02d67174: ldr     x8, [x8, #0xd8]                            T:UnityEngine.Vector3
02d67178: ldr     x21, [x21, #0x880]                         MS:DG.Tweening.TweenSettingsExtensions::SetEase
02d6717c: ldr     x22, [x22, #0xe8]                          T:DG.Tweening.TweenCallback
02d67180: adrp    x23, #0x626c000                            
02d67184: adrp    x24, #0x6266000                            
02d67188: adrp    x25, #0x6266000                            
02d6718c: ldr     x8, [x8]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d67190: ldr     x23, [x23, #0x200]                         M:Clicker.CollectionFullPopup::<OnShow>b__9_0
02d67194: ldr     x24, [x24, #0x928]                         MS:DG.Tweening.TweenSettingsExtensions::OnComplete
02d67198: mov     x0, x20                                    
02d6719c: mov     x1, xzr                                    
02d671a0: ldr     x8, [x8, #0xb8]                            MS:DG.Tweening.Core.Extensions::SetSpecialStartupMode
02d671a4: ldr     x25, [x25, #0xaa0]                         MS:MonoSingleton`1::get_Instance
02d671a8: ldp     s1, s2, [x8, #4]                           
02d671ac: ldr     s0, [x8]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d671b0: bl      #0x5b470cc                                 UnityEngine.Transform::set_localScale
02d671b4: adrp    x8, #0x1084000                             
02d671b8: fmov    s0, #1.00000000                            
02d671bc: ldr     x0, [x19, #0x60]                           ._tfPanel
02d671c0: ldr     s1, [x8, #0xf10]                           [1084f10]=4110bc863e99999a f=0.3,9.04603
02d671c4: mov     x1, xzr                                    
02d671c8: bl      #0x2d98c98                                 DG.Tweening.ShortcutExtensions::DOScale
02d671cc: ldr     x2, [x21]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d671d0: mov     w1, #0x1b                                  
02d671d4: bl      #0x336fa0c                                 fn_336fa0c
02d671d8: ldr     x8, [x22]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d671dc: mov     x20, x0                                    
02d671e0: mov     x0, x8                                     
02d671e4: bl      #0x2b7104c                                 fn_2b7104c
02d671e8: ldr     x2, [x23]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d671ec: mov     x1, x19                                    
02d671f0: mov     x3, xzr                                    
02d671f4: mov     x21, x0                                    
02d671f8: bl      #0x2d89dc4                                 DG.Tweening.TweenCallback::.ctor
02d671fc: ldr     x2, [x24]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d67200: mov     x0, x20                                    
02d67204: mov     x1, x21                                    
02d67208: bl      #0x336f26c                                 fn_336f26c
02d6720c: ldr     x0, [x25]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d67210: bl      #0x3769600                                 fn_3769600
02d67214: cbz     x0, #0x2d67230                             
02d67218: ldp     x20, x19, [sp, #0x30]                      
02d6721c: mov     x1, xzr                                    
02d67220: ldp     x22, x21, [sp, #0x20]                      
02d67224: ldp     x24, x23, [sp, #0x10]                      
02d67228: ldp     x30, x25, [sp], #0x40                      
02d6722c: b       #0x2cdb26c                                 MoneyManager::ShowUp
02d67230: bl      #0x2b7105c                                 fn_2b7105c
## OnHide() -> void
---- Clicker.CollectionFullPopup::OnHide 0x2d67234
02d67234: stp     x30, x21, [sp, #-0x20]!                    
02d67238: stp     x20, x19, [sp, #0x10]                      
02d6723c: adrp    x21, #0x6630000                            
02d67240: adrp    x20, #0x6265000                            
02d67244: mov     x19, x0                                    
02d67248: ldrb    w8, [x21, #0x33a]                          
02d6724c: ldr     x20, [x20, #0x310]                         MS:WejoyService.Singleton`1::get_Instance
02d67250: tbnz    w8, #0, #0x2d67274                         
02d67254: adrp    x0, #0x6266000                             
02d67258: ldr     x0, [x0, #0xaa0]                           MS:MonoSingleton`1::get_Instance
02d6725c: bl      #0x2b70db0                                 fn_2b70db0
02d67260: adrp    x0, #0x6265000                             
02d67264: ldr     x0, [x0, #0x310]                           MS:WejoyService.Singleton`1::get_Instance
02d67268: bl      #0x2b70db0                                 fn_2b70db0
02d6726c: mov     w8, #1                                     
02d67270: strb    w8, [x21, #0x33a]                          
02d67274: mov     x0, x19                                    
02d67278: mov     x1, xzr                                    
02d6727c: bl      #0x2cddc10                                 UIBase::OnHide
02d67280: ldr     x0, [x20]                                  M:AdsManager::<OnApplicationPause>b__26_0
02d67284: bl      #0x3be7218                                 fn_3be7218
02d67288: cbz     x0, #0x2d672b8                             
02d6728c: adrp    x19, #0x6266000                            
02d67290: mov     x1, xzr                                    
02d67294: ldr     x19, [x19, #0xaa0]                         MS:MonoSingleton`1::get_Instance
02d67298: bl      #0x2c88cec                                 AdsManager::HideMREC
02d6729c: ldr     x0, [x19]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d672a0: bl      #0x3769600                                 fn_3769600
02d672a4: cbz     x0, #0x2d672b8                             
02d672a8: ldp     x20, x19, [sp, #0x10]                      
02d672ac: mov     x1, xzr                                    
02d672b0: ldp     x30, x21, [sp], #0x20                      
02d672b4: b       #0x2cdb2e8                                 MoneyManager::BackToParent
02d672b8: bl      #0x2b7105c                                 fn_2b7105c
## SetEventCallback(System.Action onBuySuccess, int coinPrice) -> void
---- Clicker.CollectionFullPopup::SetEventCallback 0x2d672bc
02d672bc: sub     sp, sp, #0x40                              
02d672c0: stp     x30, x23, [sp, #0x10]                      
02d672c4: stp     x22, x21, [sp, #0x20]                      
02d672c8: stp     x20, x19, [sp, #0x30]                      
02d672cc: adrp    x20, #0x6630000                            
02d672d0: adrp    x23, #0x626c000                            
02d672d4: mov     w21, w2                                    
02d672d8: ldrb    w8, [x20, #0x33b]                          
02d672dc: ldr     x23, [x23, #0x208]                         T:Clicker.CollectionFullPopup/<>c__DisplayClass11_0
02d672e0: mov     x22, x1                                    
02d672e4: mov     x19, x0                                    
02d672e8: str     w2, [sp, #0xc]                             
02d672ec: tbnz    w8, #0, #0x2d6731c                         
02d672f0: adrp    x0, #0x626c000                             
02d672f4: ldr     x0, [x0, #0x210]                           M:Clicker.CollectionFullPopup/<>c__DisplayClass11_0::<SetEventCallback>b__0
02d672f8: bl      #0x2b70db0                                 fn_2b70db0
02d672fc: adrp    x0, #0x626c000                             
02d67300: ldr     x0, [x0, #0x208]                           T:Clicker.CollectionFullPopup/<>c__DisplayClass11_0
02d67304: bl      #0x2b70db0                                 fn_2b70db0
02d67308: adrp    x0, #0x6265000                             
02d6730c: ldr     x0, [x0, #0x3f0]                           T:UnityEngine.Events.UnityAction
02d67310: bl      #0x2b70db0                                 fn_2b70db0
02d67314: mov     w8, #1                                     
02d67318: strb    w8, [x20, #0x33b]                          
02d6731c: ldr     x0, [x23]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d67320: bl      #0x2b7104c                                 fn_2b7104c
02d67324: mov     x1, xzr                                    
02d67328: mov     x20, x0                                    
02d6732c: bl      #0x4e53e9c                                 System.Object::.ctor
02d67330: cbz     x20, #0x2d673dc                            
02d67334: mov     x0, x20                                    
02d67338: mov     x1, x22                                    
02d6733c: str     x22, [x0, #0x10]!                          
02d67340: bl      #0x2b70d54                                 fn_2b70d54
02d67344: ldr     x22, [x19, #0x58]                          ._txtCoinPrice
02d67348: add     x0, sp, #0xc                               
02d6734c: mov     x1, xzr                                    
02d67350: str     w21, [x19, #0x68]                          ._coinPrice
02d67354: bl      #0x4e0ea3c                                 System.Int32::ToString
02d67358: cbz     x22, #0x2d673dc                            
02d6735c: ldr     x8, [x22]                                  
02d67360: mov     x1, x0                                     
02d67364: mov     x0, x22                                    
02d67368: ldr     x9, [x8, #0x558]                           
02d6736c: ldr     x2, [x8, #0x560]                           
02d67370: blr     x9                                         
02d67374: ldr     x0, [x19, #0x70]                           ._onBuySuccess
02d67378: cbz     x0, #0x2d673dc                             
02d6737c: adrp    x21, #0x6265000                            
02d67380: adrp    x22, #0x626c000                            
02d67384: mov     x1, xzr                                    
02d67388: ldr     x21, [x21, #0x3f0]                         T:UnityEngine.Events.UnityAction
02d6738c: ldr     x22, [x22, #0x210]                         M:Clicker.CollectionFullPopup/<>c__DisplayClass11_0::<SetEventCallback>b__0
02d67390: bl      #0x5b4ce48                                 UnityEngine.Events.UnityEventBase::RemoveAllListeners
02d67394: ldr     x0, [x21]                                  M:AdsManager::<OnApplicationPause>b__26_0
02d67398: ldr     x19, [x19, #0x70]                          ._onBuySuccess
02d6739c: bl      #0x2b7104c                                 fn_2b7104c
02d673a0: ldr     x2, [x22]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d673a4: mov     x1, x20                                    
02d673a8: mov     x3, xzr                                    
02d673ac: mov     x21, x0                                    
02d673b0: bl      #0x5b4cf98                                 UnityEngine.Events.UnityAction::.ctor
02d673b4: cbz     x19, #0x2d673dc                            
02d673b8: mov     x0, x19                                    
02d673bc: mov     x1, x21                                    
02d673c0: mov     x2, xzr                                    
02d673c4: bl      #0x5b4d0ac                                 UnityEngine.Events.UnityEvent::AddListener
02d673c8: ldp     x20, x19, [sp, #0x30]                      
02d673cc: ldp     x22, x21, [sp, #0x20]                      
02d673d0: ldp     x30, x23, [sp, #0x10]                      
02d673d4: add     sp, sp, #0x40                              
02d673d8: ret                                                
02d673dc: bl      #0x2b7105c                                 fn_2b7105c
## OnBtnWatchAdsClick() -> void
---- Clicker.CollectionFullPopup::OnBtnWatchAdsClick 0x2d673e8
02d673e8: stp     x30, x19, [sp, #-0x10]!                    
02d673ec: mov     x19, x0                                    
02d673f0: ldr     x0, [x0, #0x38]                            ._btnWatchAds
02d673f4: cbz     x0, #0x2d67490                             
02d673f8: mov     w1, wzr                                    
02d673fc: mov     x2, xzr                                    
02d67400: bl      #0x5e662d4                                 UnityEngine.UI.Selectable::set_interactable
02d67404: ldr     x0, [x19, #0x40]                           ._btnCoin
02d67408: cbz     x0, #0x2d67490                             
02d6740c: mov     w1, wzr                                    
02d67410: mov     x2, xzr                                    
02d67414: bl      #0x5e662d4                                 UnityEngine.UI.Selectable::set_interactable
02d67418: ldr     x0, [x19, #0x48]                           ._btnClose
02d6741c: cbz     x0, #0x2d67490                             
02d67420: mov     w1, wzr                                    
02d67424: mov     x2, xzr                                    
02d67428: bl      #0x5e662d4                                 UnityEngine.UI.Selectable::set_interactable
02d6742c: ldr     x0, [x19, #0x50]                           ._btnClose2
02d67430: cbz     x0, #0x2d67490                             
02d67434: mov     w1, wzr                                    
02d67438: mov     x2, xzr                                    
02d6743c: bl      #0x5e662d4                                 UnityEngine.UI.Selectable::set_interactable
02d67440: mov     x0, xzr                                    
02d67444: bl      #0x2d6eec8                                 Framework.AudioManager::get_Instance
02d67448: cbz     x0, #0x2d67490                             
02d6744c: movi    d1, #0000000000000000                      
02d67450: movi    d2, #0000000000000000                      
02d67454: mov     w1, #1                                     
02d67458: fmov    s0, #1.00000000                            
02d6745c: mov     w2, wzr                                    
02d67460: mov     w3, wzr                                    
02d67464: mov     x4, xzr                                    
02d67468: bl      #0x2d6f03c                                 Framework.AudioManager::PlaySound
02d6746c: ldr     x0, [x19, #0x70]                           ._onBuySuccess
02d67470: cbz     x0, #0x2d6747c                             
02d67474: mov     x1, xzr                                    
02d67478: bl      #0x5b4d278                                 UnityEngine.Events.UnityEvent::Invoke
02d6747c: ldr     x8, [x19]                                  
02d67480: mov     x0, x19                                    
02d67484: ldp     x2, x1, [x8, #0x198]                       
02d67488: ldp     x30, x19, [sp], #0x10                      
02d6748c: br      x2                                         
02d67490: bl      #0x2b7105c                                 fn_2b7105c
## OnBtnCoinClick() -> void
---- Clicker.CollectionFullPopup::OnBtnCoinClick 0x2d67494
02d67494: stp     x30, x21, [sp, #-0x20]!                    
02d67498: stp     x20, x19, [sp, #0x10]                      
02d6749c: adrp    x20, #0x6630000                            
02d674a0: mov     x19, x0                                    
02d674a4: ldrb    w8, [x20, #0x33c]                          
02d674a8: tbnz    w8, #0, #0x2d67520                         
02d674ac: adrp    x0, #0x6264000                             
02d674b0: ldr     x0, [x0, #0xf90]                           T:System.Action
02d674b4: bl      #0x2b70db0                                 fn_2b70db0
02d674b8: adrp    x0, #0x626c000                             
02d674bc: ldr     x0, [x0, #0x218]                           M:Clicker.CollectionFullPopup::<OnBtnCoinClick>b__13_0
02d674c0: bl      #0x2b70db0                                 fn_2b70db0
02d674c4: adrp    x0, #0x6266000                             
02d674c8: ldr     x0, [x0, #0x750]                           MS:DataManager::GetData
02d674cc: bl      #0x2b70db0                                 fn_2b70db0
02d674d0: adrp    x0, #0x6267000                             
02d674d4: ldr     x0, [x0, #0xbd0]                           MS:MonoSingleton`1::get_Instance
02d674d8: bl      #0x2b70db0                                 fn_2b70db0
02d674dc: adrp    x0, #0x6266000                             
02d674e0: ldr     x0, [x0, #0xaa0]                           MS:MonoSingleton`1::get_Instance
02d674e4: bl      #0x2b70db0                                 fn_2b70db0
02d674e8: adrp    x0, #0x6266000                             
02d674ec: ldr     x0, [x0, #0x658]                           MS:MonoSingleton`1::get_Instance
02d674f0: bl      #0x2b70db0                                 fn_2b70db0
02d674f4: adrp    x0, #0x6265000                             
02d674f8: ldr     x0, [x0, #0x310]                           MS:WejoyService.Singleton`1::get_Instance
02d674fc: bl      #0x2b70db0                                 fn_2b70db0
02d67500: adrp    x0, #0x6269000                             
02d67504: ldr     x0, [x0, #0xb40]                           MS:UIManager::ShowPopup
02d67508: bl      #0x2b70db0                                 fn_2b70db0
02d6750c: adrp    x0, #0x626c000                             
02d67510: ldr     x0, [x0, #0x220]                           S:'unlock_slot'
02d67514: bl      #0x2b70db0                                 fn_2b70db0
02d67518: mov     w8, #1                                     
02d6751c: strb    w8, [x20, #0x33c]                          
02d67520: ldr     x0, [x19, #0x38]                           ._btnWatchAds
02d67524: cbz     x0, #0x2d676e8                             
02d67528: mov     w1, wzr                                    
02d6752c: mov     x2, xzr                                    
02d67530: bl      #0x5e662d4                                 UnityEngine.UI.Selectable::set_interactable
02d67534: ldr     x0, [x19, #0x40]                           ._btnCoin
02d67538: cbz     x0, #0x2d676e8                             
02d6753c: mov     w1, wzr                                    
02d67540: mov     x2, xzr                                    
02d67544: bl      #0x5e662d4                                 UnityEngine.UI.Selectable::set_interactable
02d67548: ldr     x0, [x19, #0x48]                           ._btnClose
02d6754c: cbz     x0, #0x2d676e8                             
02d67550: mov     w1, wzr                                    
02d67554: mov     x2, xzr                                    
02d67558: bl      #0x5e662d4                                 UnityEngine.UI.Selectable::set_interactable
02d6755c: ldr     x0, [x19, #0x50]                           ._btnClose2
02d67560: cbz     x0, #0x2d676e8                             
02d67564: mov     w1, wzr                                    
02d67568: mov     x2, xzr                                    
02d6756c: bl      #0x5e662d4                                 UnityEngine.UI.Selectable::set_interactable
02d67570: mov     x0, xzr                                    
02d67574: bl      #0x2d6eec8                                 Framework.AudioManager::get_Instance
02d67578: cbz     x0, #0x2d676e8                             
02d6757c: movi    d1, #0000000000000000                      
02d67580: movi    d2, #0000000000000000                      
02d67584: adrp    x20, #0x6266000                            
02d67588: fmov    s0, #1.00000000                            
02d6758c: ldr     x20, [x20, #0x658]                         MS:MonoSingleton`1::get_Instance
02d67590: mov     w1, #1                                     
02d67594: mov     w2, wzr                                    
02d67598: mov     w3, wzr                                    
02d6759c: mov     x4, xzr                                    
02d675a0: bl      #0x2d6f03c                                 Framework.AudioManager::PlaySound
02d675a4: ldr     x0, [x20]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d675a8: bl      #0x3769600                                 fn_3769600
02d675ac: cbz     x0, #0x2d676e8                             
02d675b0: adrp    x8, #0x6266000                             
02d675b4: ldr     x8, [x8, #0x750]                           MS:DataManager::GetData
02d675b8: ldr     x1, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d675bc: bl      #0x3168dd0                                 fn_3168dd0
02d675c0: cbz     x0, #0x2d676e8                             
02d675c4: mov     x1, xzr                                    
02d675c8: bl      #0x2cabaf8                                 DataUser::GetMoney
02d675cc: ldr     w8, [x19, #0x68]                           ._coinPrice
02d675d0: cmp     w0, w8                                     
02d675d4: b.ge    #0x2d67654                                 
02d675d8: ldr     x0, [x19, #0x38]                           ._btnWatchAds
02d675dc: cbz     x0, #0x2d676e8                             
02d675e0: mov     w1, #1                                     
02d675e4: mov     x2, xzr                                    
02d675e8: bl      #0x5e662d4                                 UnityEngine.UI.Selectable::set_interactable
02d675ec: ldr     x0, [x19, #0x40]                           ._btnCoin
02d675f0: cbz     x0, #0x2d676e8                             
02d675f4: mov     w1, #1                                     
02d675f8: mov     x2, xzr                                    
02d675fc: bl      #0x5e662d4                                 UnityEngine.UI.Selectable::set_interactable
02d67600: ldr     x0, [x19, #0x48]                           ._btnClose
02d67604: cbz     x0, #0x2d676e8                             
02d67608: mov     w1, #1                                     
02d6760c: mov     x2, xzr                                    
02d67610: bl      #0x5e662d4                                 UnityEngine.UI.Selectable::set_interactable
02d67614: ldr     x0, [x19, #0x50]                           ._btnClose2
02d67618: cbz     x0, #0x2d676e8                             
02d6761c: mov     w1, #1                                     
02d67620: mov     x2, xzr                                    
02d67624: bl      #0x5e662d4                                 UnityEngine.UI.Selectable::set_interactable
02d67628: adrp    x8, #0x6267000                             
02d6762c: ldr     x8, [x8, #0xbd0]                           MS:MonoSingleton`1::get_Instance
02d67630: ldr     x0, [x8]                                   S:'didu'
02d67634: bl      #0x3769600                                 fn_3769600
02d67638: cbz     x0, #0x2d676e8                             
02d6763c: adrp    x8, #0x6269000                             
02d67640: ldr     x8, [x8, #0xb40]                           MS:UIManager::ShowPopup
02d67644: ldp     x20, x19, [sp, #0x10]                      
02d67648: ldr     x1, [x8]                                   T:Trading.TradingSession/<>c__DisplayClass56_0
02d6764c: ldp     x30, x21, [sp], #0x20                      
02d67650: b       #0x33fbfac                                 
02d67654: adrp    x8, #0x6266000                             
02d67658: ldr     x8, [x8, #0xaa0]                           MS:MonoSingleton`1::get_Instance
02d6765c: ldr     x0, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d67660: bl      #0x3769600                                 fn_3769600
02d67664: cbz     x0, #0x2d676e8                             
02d67668: ldr     w8, [x19, #0x68]                           ._coinPrice
02d6766c: mov     x2, xzr                                    
02d67670: neg     w1, w8                                     
02d67674: bl      #0x2cdac78                                 MoneyManager::UpdateMoney
02d67678: adrp    x8, #0x6265000                             
02d6767c: ldr     x8, [x8, #0x310]                           MS:WejoyService.Singleton`1::get_Instance
02d67680: ldr     x0, [x8]                                   M:AdsManager::<OnApplicationPause>b__26_0
02d67684: bl      #0x3be7218                                 fn_3be7218
02d67688: adrp    x8, #0x6264000                             
02d6768c: mov     x20, x0                                    
02d67690: ldr     x8, [x8, #0xf90]                           T:System.Action
02d67694: ldr     x8, [x8]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d67698: mov     x0, x8                                     
02d6769c: bl      #0x2b7104c                                 fn_2b7104c
02d676a0: adrp    x8, #0x626c000                             
02d676a4: mov     x1, x19                                    
02d676a8: mov     x3, xzr                                    
02d676ac: ldr     x8, [x8, #0x218]                           M:Clicker.CollectionFullPopup::<OnBtnCoinClick>b__13_0
02d676b0: mov     x21, x0                                    
02d676b4: ldr     x2, [x8]                                   M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d676b8: bl      #0x4d8ddbc                                 System.Action::.ctor
02d676bc: cbz     x20, #0x2d676e8                            
02d676c0: adrp    x8, #0x626c000                             
02d676c4: mov     x0, x20                                    
02d676c8: mov     x2, x21                                    
02d676cc: ldr     x8, [x8, #0x220]                           S:'unlock_slot'
02d676d0: ldp     x20, x19, [sp, #0x10]                      
02d676d4: mov     w3, #1                                     
02d676d8: mov     x4, xzr                                    
02d676dc: ldr     x1, [x8]                                   M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d676e0: ldp     x30, x21, [sp], #0x20                      
02d676e4: b       #0x2c89698                                 AdsManager::ShowInter
02d676e8: bl      #0x2b7105c                                 fn_2b7105c
## OnBtnNoThankClick() -> void
---- Clicker.CollectionFullPopup::OnBtnNoThankClick 0x2d676ec
02d676ec: str     x30, [sp, #-0x30]!                         
02d676f0: stp     x22, x21, [sp, #0x10]                      
02d676f4: stp     x20, x19, [sp, #0x20]                      
02d676f8: adrp    x20, #0x6630000                            
02d676fc: mov     x19, x0                                    
02d67700: ldrb    w8, [x20, #0x33d]                          
02d67704: tbnz    w8, #0, #0x2d67740                         
02d67708: adrp    x0, #0x6264000                             
02d6770c: ldr     x0, [x0, #0xf90]                           T:System.Action
02d67710: bl      #0x2b70db0                                 fn_2b70db0
02d67714: adrp    x0, #0x626c000                             
02d67718: ldr     x0, [x0, #0x228]                           M:Clicker.CollectionFullPopup::<OnBtnNoThankClick>b__14_0
02d6771c: bl      #0x2b70db0                                 fn_2b70db0
02d67720: adrp    x0, #0x6265000                             
02d67724: ldr     x0, [x0, #0x310]                           MS:WejoyService.Singleton`1::get_Instance
02d67728: bl      #0x2b70db0                                 fn_2b70db0
02d6772c: adrp    x0, #0x626c000                             
02d67730: ldr     x0, [x0, #0x230]                           S:'unlock_slot_no_thank'
02d67734: bl      #0x2b70db0                                 fn_2b70db0
02d67738: mov     w8, #1                                     
02d6773c: strb    w8, [x20, #0x33d]                          
02d67740: mov     x0, xzr                                    
02d67744: bl      #0x2d6eec8                                 Framework.AudioManager::get_Instance
02d67748: cbz     x0, #0x2d677e0                             
02d6774c: movi    d1, #0000000000000000                      
02d67750: movi    d2, #0000000000000000                      
02d67754: adrp    x20, #0x6265000                            
02d67758: fmov    s0, #1.00000000                            
02d6775c: adrp    x21, #0x6264000                            
02d67760: adrp    x22, #0x626c000                            
02d67764: ldr     x20, [x20, #0x310]                         MS:WejoyService.Singleton`1::get_Instance
02d67768: ldr     x21, [x21, #0xf90]                         T:System.Action
02d6776c: ldr     x22, [x22, #0x228]                         M:Clicker.CollectionFullPopup::<OnBtnNoThankClick>b__14_0
02d67770: mov     w1, #1                                     
02d67774: mov     w2, wzr                                    
02d67778: mov     w3, wzr                                    
02d6777c: mov     x4, xzr                                    
02d67780: bl      #0x2d6f03c                                 Framework.AudioManager::PlaySound
02d67784: ldr     x0, [x20]                                  M:AdsManager::<OnApplicationPause>b__26_0
02d67788: bl      #0x3be7218                                 fn_3be7218
02d6778c: ldr     x8, [x21]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d67790: mov     x20, x0                                    
02d67794: mov     x0, x8                                     
02d67798: bl      #0x2b7104c                                 fn_2b7104c
02d6779c: ldr     x2, [x22]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d677a0: mov     x1, x19                                    
02d677a4: mov     x3, xzr                                    
02d677a8: mov     x21, x0                                    
02d677ac: bl      #0x4d8ddbc                                 System.Action::.ctor
02d677b0: cbz     x20, #0x2d677e0                            
02d677b4: adrp    x8, #0x626c000                             
02d677b8: mov     x0, x20                                    
02d677bc: mov     x2, x21                                    
02d677c0: ldr     x8, [x8, #0x230]                           S:'unlock_slot_no_thank'
02d677c4: ldp     x20, x19, [sp, #0x20]                      
02d677c8: ldp     x22, x21, [sp, #0x10]                      
02d677cc: mov     w3, #1                                     
02d677d0: ldr     x1, [x8]                                   M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d677d4: mov     x4, xzr                                    
02d677d8: ldr     x30, [sp], #0x30                           
02d677dc: b       #0x2c89698                                 AdsManager::ShowInter
02d677e0: bl      #0x2b7105c                                 fn_2b7105c
## .ctor() -> void
---- Clicker.CollectionFullPopup::.ctor 0x2d677e4
02d677e4: stp     x30, x21, [sp, #-0x20]!                    
02d677e8: stp     x20, x19, [sp, #0x10]                      
02d677ec: adrp    x20, #0x6630000                            
02d677f0: adrp    x21, #0x6267000                            
02d677f4: mov     x19, x0                                    
02d677f8: ldrb    w8, [x20, #0x33e]                          
02d677fc: ldr     x21, [x21, #0xff0]                         T:UnityEngine.Events.UnityEvent
02d67800: tbnz    w8, #0, #0x2d67818                         
02d67804: adrp    x0, #0x6267000                             
02d67808: ldr     x0, [x0, #0xff0]                           T:UnityEngine.Events.UnityEvent
02d6780c: bl      #0x2b70db0                                 fn_2b70db0
02d67810: mov     w8, #1                                     
02d67814: strb    w8, [x20, #0x33e]                          
02d67818: ldr     x0, [x21]                                  S:'didu'
02d6781c: bl      #0x2b7104c                                 fn_2b7104c
02d67820: mov     x1, xzr                                    
02d67824: mov     x20, x0                                    
02d67828: bl      #0x5b4d048                                 UnityEngine.Events.UnityEvent::.ctor
02d6782c: mov     x0, x19                                    
02d67830: mov     x1, x20                                    
02d67834: str     x20, [x0, #0x70]!                          ._onBuySuccess
02d67838: bl      #0x2b70d54                                 fn_2b70d54
02d6783c: mov     x0, x19                                    
02d67840: ldp     x20, x19, [sp, #0x10]                      
02d67844: mov     x1, xzr                                    
02d67848: ldp     x30, x21, [sp], #0x20                      
02d6784c: b       #0x2cddba8                                 PopupBase::.ctor
## <OnShow>b__9_0() -> void
---- Clicker.CollectionFullPopup::<OnShow>b__9_0 0x2d67850
02d67850: stp     x30, x19, [sp, #-0x10]!                    
02d67854: mov     x19, x0                                    
02d67858: ldr     x0, [x0, #0x38]                            ._btnWatchAds
02d6785c: cbz     x0, #0x2d678ac                             
02d67860: mov     w1, #1                                     
02d67864: mov     x2, xzr                                    
02d67868: bl      #0x5e662d4                                 UnityEngine.UI.Selectable::set_interactable
02d6786c: ldr     x0, [x19, #0x40]                           ._btnCoin
02d67870: cbz     x0, #0x2d678ac                             
02d67874: mov     w1, #1                                     
02d67878: mov     x2, xzr                                    
02d6787c: bl      #0x5e662d4                                 UnityEngine.UI.Selectable::set_interactable
02d67880: ldr     x0, [x19, #0x48]                           ._btnClose
02d67884: cbz     x0, #0x2d678ac                             
02d67888: mov     w1, #1                                     
02d6788c: mov     x2, xzr                                    
02d67890: bl      #0x5e662d4                                 UnityEngine.UI.Selectable::set_interactable
02d67894: ldr     x0, [x19, #0x50]                           ._btnClose2
02d67898: cbz     x0, #0x2d678ac                             
02d6789c: mov     w1, #1                                     
02d678a0: mov     x2, xzr                                    
02d678a4: ldp     x30, x19, [sp], #0x10                      
02d678a8: b       #0x5e662d4                                 UnityEngine.UI.Selectable::set_interactable
02d678ac: bl      #0x2b7105c                                 fn_2b7105c
## <OnBtnCoinClick>b__13_0() -> void
---- Clicker.CollectionFullPopup::<OnBtnCoinClick>b__13_0 0x2d678b0
02d678b0: stp     x30, x19, [sp, #-0x10]!                    
02d678b4: mov     x19, x0                                    
02d678b8: ldr     x0, [x0, #0x70]                            ._onBuySuccess
02d678bc: cbz     x0, #0x2d678c8                             
02d678c0: mov     x1, xzr                                    
02d678c4: bl      #0x5b4d278                                 UnityEngine.Events.UnityEvent::Invoke
02d678c8: ldr     x8, [x19]                                  
02d678cc: mov     x0, x19                                    
02d678d0: ldp     x2, x1, [x8, #0x198]                       
02d678d4: ldp     x30, x19, [sp], #0x10                      
02d678d8: br      x2                                         
## <OnBtnNoThankClick>b__14_0() -> void
---- Clicker.CollectionFullPopup::<OnBtnNoThankClick>b__14_0 0x2d678dc
02d678dc: stp     x30, x19, [sp, #-0x10]!                    
02d678e0: mov     x19, x0                                    
02d678e4: ldr     x0, [x0, #0x38]                            ._btnWatchAds
02d678e8: cbz     x0, #0x2d67948                             
02d678ec: mov     w1, wzr                                    
02d678f0: mov     x2, xzr                                    
02d678f4: bl      #0x5e662d4                                 UnityEngine.UI.Selectable::set_interactable
02d678f8: ldr     x0, [x19, #0x40]                           ._btnCoin
02d678fc: cbz     x0, #0x2d67948                             
02d67900: mov     w1, wzr                                    
02d67904: mov     x2, xzr                                    
02d67908: bl      #0x5e662d4                                 UnityEngine.UI.Selectable::set_interactable
02d6790c: ldr     x0, [x19, #0x48]                           ._btnClose
02d67910: cbz     x0, #0x2d67948                             
02d67914: mov     w1, wzr                                    
02d67918: mov     x2, xzr                                    
02d6791c: bl      #0x5e662d4                                 UnityEngine.UI.Selectable::set_interactable
02d67920: ldr     x0, [x19, #0x50]                           ._btnClose2
02d67924: cbz     x0, #0x2d67948                             
02d67928: mov     w1, wzr                                    
02d6792c: mov     x2, xzr                                    
02d67930: bl      #0x5e662d4                                 UnityEngine.UI.Selectable::set_interactable
02d67934: ldr     x8, [x19]                                  
02d67938: mov     x0, x19                                    
02d6793c: ldp     x2, x1, [x8, #0x198]                       
02d67940: ldp     x30, x19, [sp], #0x10                      
02d67944: br      x2                                         
02d67948: bl      #0x2b7105c                                 fn_2b7105c
