#### CLASS AdmobEventBase/<TryLoadAdWithDelay>d__5 parent= object
#   field <>1__state                     int                                                off=0x10 attr=1 
#   field <>2__current                   object                                             off=0x18 attr=1 
#   field <>4__this                      AdmobEventBase                                     off=0x20 attr=6 
#   field action                         System.Action                                      off=0x28 attr=6 
## .ctor(int <>1__state) -> void
---- AdmobEventBase/<TryLoadAdWithDelay>d__5::.ctor 0x2c8f550
02c8f550: str     x30, [sp, #-0x20]!                         
02c8f554: stp     x20, x19, [sp, #0x10]                      
02c8f558: mov     w19, w1                                    
02c8f55c: mov     x1, xzr                                    
02c8f560: mov     x20, x0                                    
02c8f564: bl      #0x4e53e9c                                 System.Object::.ctor
02c8f568: str     w19, [x20, #0x10]                          .<>1__state
02c8f56c: ldp     x20, x19, [sp, #0x10]                      
02c8f570: ldr     x30, [sp], #0x20                           
02c8f574: ret                                                
## System.IDisposable.Dispose() -> void
---- AdmobEventBase/<TryLoadAdWithDelay>d__5::System.IDisposable.Dispose 0x2c8f660
02c8f660: ret                                                
## MoveNext() -> bool
---- AdmobEventBase/<TryLoadAdWithDelay>d__5::MoveNext 0x2c8f664
02c8f664: str     d8, [sp, #-0x40]!                          
02c8f668: stp     x30, x23, [sp, #0x10]                      
02c8f66c: stp     x22, x21, [sp, #0x20]                      
02c8f670: stp     x20, x19, [sp, #0x30]                      
02c8f674: adrp    x20, #0x662f000                            
02c8f678: mov     x19, x0                                    
02c8f67c: ldrb    w8, [x20, #0x9ba]                          
02c8f680: tbnz    w8, #0, #0x2c8f6a4                         
02c8f684: adrp    x0, #0x6264000                             
02c8f688: ldr     x0, [x0, #0xf58]                           T:UnityEngine.WaitForSeconds
02c8f68c: bl      #0x2b70db0                                 fn_2b70db0
02c8f690: adrp    x0, #0x6265000                             
02c8f694: ldr     x0, [x0, #0x478]                           S:'Retrying to load ad in {0} seconds... (Attempt {1})'
02c8f698: bl      #0x2b70db0                                 fn_2b70db0
02c8f69c: mov     w8, #1                                     
02c8f6a0: strb    w8, [x20, #0x9ba]                          
02c8f6a4: ldr     w21, [x19, #0x10]                          .<>1__state
02c8f6a8: ldr     x22, [x19, #0x20]                          .<>4__this
02c8f6ac: cbz     w21, #0x2c8f6ec                            
02c8f6b0: cmp     w21, #1                                    
02c8f6b4: b.ne    #0x2c8f79c                                 
02c8f6b8: ldr     x8, [x19, #0x28]                           .action
02c8f6bc: mov     w9, #-1                                    
02c8f6c0: str     w9, [x19, #0x10]                           .<>1__state
02c8f6c4: cbz     x8, #0x2c8f6d8                             
02c8f6c8: ldr     x9, [x8, #0x18]                            
02c8f6cc: ldr     x0, [x8, #0x40]                            
02c8f6d0: ldr     x1, [x8, #0x28]                            
02c8f6d4: blr     x9                                         
02c8f6d8: cbz     x22, #0x2c8f7b8                            
02c8f6dc: ldr     w8, [x22, #0x30]                           
02c8f6e0: add     w8, w8, #1                                 
02c8f6e4: str     w8, [x22, #0x30]                           
02c8f6e8: b       #0x2c8f79c                                 
02c8f6ec: mov     w8, #-1                                    
02c8f6f0: str     w8, [x19, #0x10]                           .<>1__state
02c8f6f4: cbz     x22, #0x2c8f7b8                            
02c8f6f8: ldr     w8, [x22, #0x30]                           
02c8f6fc: adrp    x23, #0x6263000                            
02c8f700: add     x1, sp, #0xc                               
02c8f704: ldr     x23, [x23, #0x970]                         &6645c70(=0)
02c8f708: add     w8, w8, #1                                 
02c8f70c: scvtf   s0, w8                                     
02c8f710: ldr     x0, [x23, #0x78]                           &2c498b4(=d65f03c0d503245f)
02c8f714: fadd    s8, s0, s0                                 
02c8f718: str     s8, [sp, #0xc]                             
02c8f71c: bl      #0x2b70f38                                 fn_2b70f38
02c8f720: ldr     w8, [x22, #0x30]                           
02c8f724: mov     x20, x0                                    
02c8f728: ldr     x0, [x23, #0x48]                           &6263098(=0)
02c8f72c: add     x1, sp, #8                                 
02c8f730: add     w8, w8, #1                                 
02c8f734: str     w8, [sp, #8]                               
02c8f738: bl      #0x2b70f38                                 fn_2b70f38
02c8f73c: adrp    x8, #0x6265000                             
02c8f740: mov     x2, x0                                     
02c8f744: mov     x1, x20                                    
02c8f748: ldr     x8, [x8, #0x478]                           S:'Retrying to load ad in {0} seconds... (Attempt {1})'
02c8f74c: mov     x3, xzr                                    
02c8f750: ldr     x8, [x8]                                   M:AdsManager::<OnApplicationPause>b__26_0
02c8f754: mov     x0, x8                                     
02c8f758: bl      #0x4ca7720                                 System.String::Format
02c8f75c: mov     x1, xzr                                    
02c8f760: bl      #0x2ca09f8                                 WLog::LogError
02c8f764: adrp    x8, #0x6264000                             
02c8f768: ldr     x8, [x8, #0xf58]                           T:UnityEngine.WaitForSeconds
02c8f76c: ldr     x0, [x8]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c8f770: bl      #0x2b7104c                                 fn_2b7104c
02c8f774: fmov    s0, s8                                     
02c8f778: mov     x1, xzr                                    
02c8f77c: mov     x20, x0                                    
02c8f780: bl      #0x5b3e5e8                                 UnityEngine.WaitForSeconds::.ctor
02c8f784: str     x20, [x19, #0x18]!                         .<>2__current
02c8f788: mov     x0, x19                                    
02c8f78c: mov     x1, x20                                    
02c8f790: bl      #0x2b70d54                                 fn_2b70d54
02c8f794: mov     w8, #1                                     
02c8f798: stur    w8, [x19, #-8]                             
02c8f79c: cmp     w21, #0                                    
02c8f7a0: ldp     x20, x19, [sp, #0x30]                      
02c8f7a4: ldp     x22, x21, [sp, #0x20]                      
02c8f7a8: cset    w0, eq                                     
02c8f7ac: ldp     x30, x23, [sp, #0x10]                      
02c8f7b0: ldr     d8, [sp], #0x40                            
02c8f7b4: ret                                                
02c8f7b8: bl      #0x2b7105c                                 fn_2b7105c
## System.Collections.Generic.IEnumerator<System.Object>.get_Current() -> object
---- AdmobEventBase/<TryLoadAdWithDelay>d__5::System.Collections.Generic.IEnumerator<System.Object>.get_Current 0x2c8f7bc
02c8f7bc: ldr     x0, [x0, #0x18]                            .<>2__current
02c8f7c0: ret                                                
## System.Collections.IEnumerator.Reset() -> void
---- AdmobEventBase/<TryLoadAdWithDelay>d__5::System.Collections.IEnumerator.Reset 0x2c8f7c4
02c8f7c4: stp     x30, x19, [sp, #-0x10]!                    
02c8f7c8: adrp    x0, #0x6264000                             
02c8f7cc: ldr     x0, [x0, #0xf60]                           T:System.NotSupportedException
02c8f7d0: bl      #0x2b70dc4                                 fn_2b70dc4
02c8f7d4: bl      #0x2b7104c                                 fn_2b7104c
02c8f7d8: mov     x1, xzr                                    
02c8f7dc: mov     x19, x0                                    
02c8f7e0: bl      #0x4e14238                                 System.NotSupportedException::.ctor
02c8f7e4: adrp    x0, #0x6265000                             
02c8f7e8: ldr     x0, [x0, #0x480]                           M:AdmobEventBase/<TryLoadAdWithDelay>d__5::System.Collections.IEnumerator.Reset
02c8f7ec: bl      #0x2b70dc4                                 fn_2b70dc4
02c8f7f0: mov     x1, x0                                     
02c8f7f4: mov     x0, x19                                    
02c8f7f8: bl      #0x2b70f20                                 fn_2b70f20
## System.Collections.IEnumerator.get_Current() -> object
---- AdmobEventBase/<TryLoadAdWithDelay>d__5::System.Collections.IEnumerator.get_Current 0x2c8f7fc
02c8f7fc: ldr     x0, [x0, #0x18]                            .<>2__current
02c8f800: ret                                                
#### CLASS AdmobEventBase parent= UnityEngine.MonoBehaviour
#   field placement                      string                                             off=0x20 attr=4 
#   field adKey                          string                                             off=0x28 attr=4 
#   field _retryAttempt                  int                                                off=0x30 attr=1 
#   field _retryCoroutine                UnityEngine.Coroutine                              off=0x38 attr=1 
## TryLoadAd(System.Action action) -> void
---- AdmobEventBase::TryLoadAd 0x2c8f468
02c8f468: stp     x30, x21, [sp, #-0x20]!                    
02c8f46c: stp     x20, x19, [sp, #0x10]                      
02c8f470: mov     x20, x0                                    
02c8f474: mov     x19, x0                                    
02c8f478: mov     x21, x1                                    
02c8f47c: ldr     x8, [x20, #0x38]!                          ._retryCoroutine
02c8f480: cbz     x8, #0x2c8f494                             
02c8f484: mov     x0, x19                                    
02c8f488: mov     x1, x8                                     
02c8f48c: mov     x2, xzr                                    
02c8f490: bl      #0x5b38c4c                                 UnityEngine.MonoBehaviour::StopCoroutine
02c8f494: mov     x0, x19                                    
02c8f498: mov     x1, x21                                    
02c8f49c: bl      #0x2c8f4c8                                 AdmobEventBase::TryLoadAdWithDelay
02c8f4a0: mov     x1, x0                                     
02c8f4a4: mov     x0, x19                                    
02c8f4a8: mov     x2, xzr                                    
02c8f4ac: bl      #0x5b389f0                                 UnityEngine.MonoBehaviour::StartCoroutine
02c8f4b0: mov     x1, x0                                     
02c8f4b4: mov     x0, x20                                    
02c8f4b8: str     x1, [x19, #0x38]                           ._retryCoroutine
02c8f4bc: ldp     x20, x19, [sp, #0x10]                      
02c8f4c0: ldp     x30, x21, [sp], #0x20                      
02c8f4c4: b       #0x2b70d54                                 
## TryLoadAdWithDelay(System.Action action) -> System.Collections.IEnumerator
---- AdmobEventBase::TryLoadAdWithDelay 0x2c8f4c8
02c8f4c8: str     x30, [sp, #-0x30]!                         
02c8f4cc: stp     x22, x21, [sp, #0x10]                      
02c8f4d0: stp     x20, x19, [sp, #0x20]                      
02c8f4d4: adrp    x21, #0x662f000                            
02c8f4d8: adrp    x22, #0x6265000                            
02c8f4dc: mov     x19, x1                                    
02c8f4e0: ldrb    w8, [x21, #0x9b7]                          
02c8f4e4: ldr     x22, [x22, #0x468]                         T:AdmobEventBase/<TryLoadAdWithDelay>d__5
02c8f4e8: mov     x20, x0                                    
02c8f4ec: tbnz    w8, #0, #0x2c8f504                         
02c8f4f0: adrp    x0, #0x6265000                             
02c8f4f4: ldr     x0, [x0, #0x468]                           T:AdmobEventBase/<TryLoadAdWithDelay>d__5
02c8f4f8: bl      #0x2b70db0                                 fn_2b70db0
02c8f4fc: mov     w8, #1                                     
02c8f500: strb    w8, [x21, #0x9b7]                          
02c8f504: ldr     x0, [x22]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c8f508: bl      #0x2b7104c                                 fn_2b7104c
02c8f50c: mov     x1, xzr                                    
02c8f510: mov     x21, x0                                    
02c8f514: bl      #0x4e53e9c                                 System.Object::.ctor
02c8f518: mov     x0, x21                                    
02c8f51c: mov     x1, x20                                    
02c8f520: str     wzr, [x21, #0x10]                          
02c8f524: str     x20, [x0, #0x20]!                          .placement
02c8f528: bl      #0x2b70d54                                 fn_2b70d54
02c8f52c: mov     x0, x21                                    
02c8f530: mov     x1, x19                                    
02c8f534: str     x19, [x0, #0x28]!                          .adKey
02c8f538: bl      #0x2b70d54                                 fn_2b70d54
02c8f53c: mov     x0, x21                                    
02c8f540: ldp     x20, x19, [sp, #0x20]                      
02c8f544: ldp     x22, x21, [sp, #0x10]                      
02c8f548: ldr     x30, [sp], #0x30                           
02c8f54c: ret                                                
## OnAdClicked() -> void
---- AdmobEventBase::OnAdClicked 0x2c8f578
02c8f578: ret                                                
## OnAdFullScreenContentClosed() -> void
---- AdmobEventBase::OnAdFullScreenContentClosed 0x2c8f57c
02c8f57c: ret                                                
## OnAdFullScreenContentOpened() -> void
---- AdmobEventBase::OnAdFullScreenContentOpened 0x2c8f580
02c8f580: ret                                                
## OnAdImpressionRecorded() -> void
---- AdmobEventBase::OnAdImpressionRecorded 0x2c8f584
02c8f584: ret                                                
## OnAdFullScreenContentFailed(GoogleMobileAds.Api.AdError adError) -> void
---- AdmobEventBase::OnAdFullScreenContentFailed 0x2c8f588
02c8f588: str     x30, [sp, #-0x20]!                         
02c8f58c: stp     x20, x19, [sp, #0x10]                      
02c8f590: adrp    x20, #0x662f000                            
02c8f594: mov     x19, x1                                    
02c8f598: ldrb    w8, [x20, #0x9b8]                          
02c8f59c: tbnz    w8, #0, #0x2c8f5b4                         
02c8f5a0: adrp    x0, #0x6265000                             
02c8f5a4: ldr     x0, [x0, #0x470]                           S:'OnAdFullScreenContentFailed '
02c8f5a8: bl      #0x2b70db0                                 fn_2b70db0
02c8f5ac: mov     w8, #1                                     
02c8f5b0: strb    w8, [x20, #0x9b8]                          
02c8f5b4: cbz     x19, #0x2c8f5f0                            
02c8f5b8: adrp    x20, #0x6265000                            
02c8f5bc: mov     x0, x19                                    
02c8f5c0: mov     x1, xzr                                    
02c8f5c4: ldr     x20, [x20, #0x470]                         S:'OnAdFullScreenContentFailed '
02c8f5c8: bl      #0x4c31798                                 GoogleMobileAds.Api.AdError::GetMessage
02c8f5cc: ldr     x8, [x20]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c8f5d0: mov     x1, x0                                     
02c8f5d4: mov     x2, xzr                                    
02c8f5d8: mov     x0, x8                                     
02c8f5dc: bl      #0x4c9c514                                 System.String::Concat
02c8f5e0: ldp     x20, x19, [sp, #0x10]                      
02c8f5e4: mov     x1, xzr                                    
02c8f5e8: ldr     x30, [sp], #0x20                           
02c8f5ec: b       #0x2ca09f8                                 WLog::LogError
02c8f5f0: bl      #0x2b7105c                                 fn_2b7105c
## OnAdPaid(GoogleMobileAds.Api.AdValue adValue) -> void
---- AdmobEventBase::OnAdPaid 0x2c8f5f4
02c8f5f4: ret                                                
## .ctor() -> void
---- AdmobEventBase::.ctor 0x2c8f5f8
02c8f5f8: stp     x30, x21, [sp, #-0x20]!                    
02c8f5fc: stp     x20, x19, [sp, #0x10]                      
02c8f600: adrp    x21, #0x662f000                            
02c8f604: adrp    x20, #0x6263000                            
02c8f608: mov     x19, x0                                    
02c8f60c: ldrb    w8, [x21, #0x9b9]                          
02c8f610: ldr     x20, [x20, #0xa90]                         S:''
02c8f614: tbnz    w8, #0, #0x2c8f62c                         
02c8f618: adrp    x0, #0x6263000                             
02c8f61c: ldr     x0, [x0, #0xa90]                           S:''
02c8f620: bl      #0x2b70db0                                 fn_2b70db0
02c8f624: mov     w8, #1                                     
02c8f628: strb    w8, [x21, #0x9b9]                          
02c8f62c: ldr     x1, [x20]                                  &2c5bbd4(=a9bd7bfdd503233f)
02c8f630: mov     x0, x19                                    
02c8f634: str     x1, [x0, #0x20]!                           .placement
02c8f638: bl      #0x2b70d54                                 fn_2b70d54
02c8f63c: ldr     x1, [x20]                                  &2c5bbd4(=a9bd7bfdd503233f)
02c8f640: mov     x0, x19                                    
02c8f644: str     x1, [x0, #0x28]!                           .adKey
02c8f648: bl      #0x2b70d54                                 fn_2b70d54
02c8f64c: mov     x0, x19                                    
02c8f650: ldp     x20, x19, [sp, #0x10]                      
02c8f654: mov     x1, xzr                                    
02c8f658: ldp     x30, x21, [sp], #0x20                      
02c8f65c: b       #0x5b397b0                                 UnityEngine.MonoBehaviour::.ctor
