#### CLASS Framework.FriendlyGUID parent= object
#   field _random                        System.Random                                      off=0x0 attr=11 
## NewId_FromTicks() -> string
---- Framework.FriendlyGUID::NewId_FromTicks 0x2cc6f2c
02cc6f2c: sub     sp, sp, #0x30                              
02cc6f30: str     x30, [sp, #0x10]                           
02cc6f34: stp     x20, x19, [sp, #0x20]                      
02cc6f38: adrp    x20, #0x662f000                            
02cc6f3c: adrp    x19, #0x6266000                            
02cc6f40: ldrb    w8, [x20, #0xc60]                          
02cc6f44: ldr     x19, [x19, #0x128]                         T:System.DateTime
02cc6f48: tbnz    w8, #0, #0x2cc6f6c                         
02cc6f4c: adrp    x0, #0x6266000                             
02cc6f50: ldr     x0, [x0, #0x128]                           T:System.DateTime
02cc6f54: bl      #0x2b70db0                                 fn_2b70db0
02cc6f58: adrp    x0, #0x6267000                             
02cc6f5c: ldr     x0, [x0, #0x300]                           S:'x'
02cc6f60: bl      #0x2b70db0                                 fn_2b70db0
02cc6f64: mov     w8, #1                                     
02cc6f68: strb    w8, [x20, #0xc60]                          
02cc6f6c: ldr     x0, [x19]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cc6f70: adrp    x19, #0x6267000                            
02cc6f74: ldr     w8, [x0, #0xe4]                            [62670e4]=0 f=0,0
02cc6f78: ldr     x19, [x19, #0x300]                         S:'x'
02cc6f7c: str     xzr, [sp, #0x18]                           
02cc6f80: str     xzr, [sp, #8]                              
02cc6f84: cbnz    w8, #0x2cc6f8c                             
02cc6f88: bl      #0x2b70f30                                 fn_2b70f30
02cc6f8c: mov     x0, xzr                                    
02cc6f90: bl      #0x4df25c8                                 System.DateTime::get_Now
02cc6f94: str     x0, [sp, #0x18]                            
02cc6f98: add     x0, sp, #0x18                              
02cc6f9c: mov     x1, xzr                                    
02cc6fa0: bl      #0x4df09d4                                 System.DateTime::get_Ticks
02cc6fa4: ldr     x1, [x19]                                  S:'didu'
02cc6fa8: str     x0, [sp, #8]                               
02cc6fac: add     x0, sp, #8                                 
02cc6fb0: mov     x2, xzr                                    
02cc6fb4: bl      #0x4e0ff28                                 System.Int64::ToString
02cc6fb8: ldp     x20, x19, [sp, #0x20]                      
02cc6fbc: ldr     x30, [sp, #0x10]                           
02cc6fc0: add     sp, sp, #0x30                              
02cc6fc4: ret                                                
## NewId_FromGuid() -> string
---- Framework.FriendlyGUID::NewId_FromGuid 0x2cc6fc8
02cc6fc8: sub     sp, sp, #0x20                              
02cc6fcc: stp     xzr, x30, [sp, #8]                         
02cc6fd0: mov     x0, xzr                                    
02cc6fd4: str     xzr, [sp]                                  
02cc6fd8: bl      #0x4e0958c                                 System.Guid::NewGuid
02cc6fdc: stp     x0, x1, [sp]                               
02cc6fe0: mov     x0, sp                                     
02cc6fe4: mov     x1, xzr                                    
02cc6fe8: bl      #0x4e0b4f8                                 System.Guid::ToString
02cc6fec: ldr     x30, [sp, #0x10]                           
02cc6ff0: add     sp, sp, #0x20                              
02cc6ff4: ret                                                
## NewId_FromGuidBase64() -> string
---- Framework.FriendlyGUID::NewId_FromGuidBase64 0x2cc6ff8
02cc6ff8: sub     sp, sp, #0x30                              
02cc6ffc: str     x30, [sp, #0x10]                           
02cc7000: stp     x20, x19, [sp, #0x20]                      
02cc7004: adrp    x20, #0x662f000                            
02cc7008: adrp    x19, #0x6263000                            
02cc700c: ldrb    w8, [x20, #0xc61]                          
02cc7010: b       #0x5e8fd54                                 
02cc7014: tbnz    w8, #0, #0x2cc705c                         
02cc7018: adrp    x0, #0x6263000                             
02cc701c: ldr     x0, [x0, #0x9d8]                           T:System.Convert
02cc7020: bl      #0x2b70db0                                 fn_2b70db0
02cc7024: adrp    x0, #0x6267000                             
02cc7028: ldr     x0, [x0, #0x308]                           S:'+'
02cc702c: bl      #0x2b70db0                                 fn_2b70db0
02cc7030: adrp    x0, #0x6267000                             
02cc7034: ldr     x0, [x0, #0x310]                           S:'-'
02cc7038: bl      #0x2b70db0                                 fn_2b70db0
02cc703c: adrp    x0, #0x6267000                             
02cc7040: ldr     x0, [x0, #0x318]                           S:'_'
02cc7044: bl      #0x2b70db0                                 fn_2b70db0
02cc7048: adrp    x0, #0x6264000                             
02cc704c: ldr     x0, [x0, #0xe48]                           S:'/'
02cc7050: bl      #0x2b70db0                                 fn_2b70db0
02cc7054: mov     w8, #1                                     
02cc7058: strb    w8, [x20, #0xc61]                          
02cc705c: mov     x0, xzr                                    
02cc7060: stp     xzr, xzr, [sp]                             
02cc7064: bl      #0x4e0958c                                 System.Guid::NewGuid
02cc7068: stp     x0, x1, [sp]                               
02cc706c: mov     x0, sp                                     
02cc7070: mov     x1, xzr                                    
02cc7074: bl      #0x4e0b464                                 System.Guid::ToByteArray
02cc7078: ldr     x8, [x19]                                  &2c5bbd4(=a9bd7bfdd503233f)
02cc707c: mov     x19, x0                                    
02cc7080: ldr     w9, [x8, #0xe4]                            
02cc7084: cbnz    w9, #0x2cc7090                             
02cc7088: mov     x0, x8                                     
02cc708c: bl      #0x2b70f30                                 fn_2b70f30
02cc7090: mov     x0, x19                                    
02cc7094: mov     x1, xzr                                    
02cc7098: bl      #0x4d9c0bc                                 System.Convert::ToBase64String
02cc709c: cbz     x0, #0x2cc7108                             
02cc70a0: adrp    x8, #0x6264000                             
02cc70a4: adrp    x9, #0x6267000                             
02cc70a8: mov     x3, xzr                                    
02cc70ac: ldr     x8, [x8, #0xe48]                           S:'/'
02cc70b0: ldr     x9, [x9, #0x318]                           S:'_'
02cc70b4: ldr     x1, [x8]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02cc70b8: ldr     x2, [x9]                                   S:'didu'
02cc70bc: bl      #0x4ca8ca8                                 System.String::Replace
02cc70c0: cbz     x0, #0x2cc7108                             
02cc70c4: adrp    x8, #0x6267000                             
02cc70c8: adrp    x9, #0x6267000                             
02cc70cc: mov     x3, xzr                                    
02cc70d0: ldr     x8, [x8, #0x308]                           S:'+'
02cc70d4: ldr     x9, [x9, #0x310]                           S:'-'
02cc70d8: ldr     x1, [x8]                                   S:'didu'
02cc70dc: ldr     x2, [x9]                                   S:'didu'
02cc70e0: bl      #0x4ca8ca8                                 System.String::Replace
02cc70e4: cbz     x0, #0x2cc7108                             
02cc70e8: mov     w1, wzr                                    
02cc70ec: mov     w2, #0xf                                   
02cc70f0: mov     x3, xzr                                    
02cc70f4: bl      #0x4ca8a80                                 System.String::Substring
02cc70f8: ldp     x20, x19, [sp, #0x20]                      
02cc70fc: ldr     x30, [sp, #0x10]                           
02cc7100: add     sp, sp, #0x30                              
02cc7104: ret                                                
02cc7108: bl      #0x2b7105c                                 fn_2b7105c
## NewId_FromGuidShorted() -> string
---- Framework.FriendlyGUID::NewId_FromGuidShorted 0x2cc710c
02cc710c: sub     sp, sp, #0x30                              
02cc7110: str     x30, [sp, #0x10]                           
02cc7114: stp     x20, x19, [sp, #0x20]                      
02cc7118: adrp    x20, #0x662f000                            
02cc711c: adrp    x19, #0x6267000                            
02cc7120: ldrb    w8, [x20, #0xc62]                          
02cc7124: ldr     x19, [x19, #0x320]                         S:'N'
02cc7128: tbnz    w8, #0, #0x2cc7140                         
02cc712c: adrp    x0, #0x6267000                             
02cc7130: ldr     x0, [x0, #0x320]                           S:'N'
02cc7134: bl      #0x2b70db0                                 fn_2b70db0
02cc7138: mov     w8, #1                                     
02cc713c: strb    w8, [x20, #0xc62]                          
02cc7140: mov     x0, xzr                                    
02cc7144: stp     xzr, xzr, [sp]                             
02cc7148: bl      #0x4e0958c                                 System.Guid::NewGuid
02cc714c: ldr     x8, [x19]                                  S:'didu'
02cc7150: stp     x0, x1, [sp]                               
02cc7154: mov     x0, sp                                     
02cc7158: mov     x2, xzr                                    
02cc715c: mov     x1, x8                                     
02cc7160: bl      #0x4e0bb00                                 System.Guid::ToString
02cc7164: cbz     x0, #0x2cc7188                             
02cc7168: mov     w1, wzr                                    
02cc716c: mov     w2, #0xf                                   
02cc7170: mov     x3, xzr                                    
02cc7174: bl      #0x4ca8a80                                 System.String::Substring
02cc7178: ldp     x20, x19, [sp, #0x20]                      
02cc717c: ldr     x30, [sp, #0x10]                           
02cc7180: add     sp, sp, #0x30                              
02cc7184: ret                                                
02cc7188: bl      #0x2b7105c                                 fn_2b7105c
## NewId_FromRandomInt() -> string
---- Framework.FriendlyGUID::NewId_FromRandomInt 0x2cc718c
02cc718c: str     x30, [sp, #-0x20]!                         
02cc7190: stp     x20, x19, [sp, #0x10]                      
02cc7194: adrp    x20, #0x662f000                            
02cc7198: adrp    x19, #0x6267000                            
02cc719c: ldrb    w8, [x20, #0xc63]                          
02cc71a0: ldr     x19, [x19, #0x328]                         T:Framework.FriendlyGUID
02cc71a4: tbnz    w8, #0, #0x2cc71c8                         
02cc71a8: adrp    x0, #0x6267000                             
02cc71ac: ldr     x0, [x0, #0x328]                           T:Framework.FriendlyGUID
02cc71b0: bl      #0x2b70db0                                 fn_2b70db0
02cc71b4: adrp    x0, #0x6267000                             
02cc71b8: ldr     x0, [x0, #0x300]                           S:'x'
02cc71bc: bl      #0x2b70db0                                 fn_2b70db0
02cc71c0: mov     w8, #1                                     
02cc71c4: strb    w8, [x20, #0xc63]                          
02cc71c8: ldr     x0, [x19]                                  S:'didu'
02cc71cc: str     wzr, [sp, #0xc]                            
02cc71d0: ldr     w8, [x0, #0xe4]                            [62670e4]=0 f=0,0
02cc71d4: cbnz    w8, #0x2cc71e0                             
02cc71d8: bl      #0x2b70f30                                 fn_2b70f30
02cc71dc: ldr     x0, [x19]                                  S:'didu'
02cc71e0: ldr     x8, [x0, #0xb8]                            M:Framework.SceneUtils/<CRUnloadSceneAsync>d__2::System.Collections.IEnumerator.Reset
02cc71e4: ldr     x0, [x8]                                   
02cc71e8: cbz     x0, #0x2cc7224                             
02cc71ec: ldr     x8, [x0]                                   S:'didu'
02cc71f0: adrp    x19, #0x6267000                            
02cc71f4: mov     w1, #0x7fffffff                            
02cc71f8: ldr     x19, [x19, #0x300]                         S:'x'
02cc71fc: ldp     x9, x2, [x8, #0x1a8]                       
02cc7200: blr     x9                                         
02cc7204: ldr     x1, [x19]                                  S:'didu'
02cc7208: str     w0, [sp, #0xc]                             
02cc720c: add     x0, sp, #0xc                               
02cc7210: mov     x2, xzr                                    
02cc7214: bl      #0x4e0ead0                                 System.Int32::ToString
02cc7218: ldp     x20, x19, [sp, #0x10]                      
02cc721c: ldr     x30, [sp], #0x20                           
02cc7220: ret                                                
02cc7224: bl      #0x2b7105c                                 fn_2b7105c
## NewId_FromRandomLong() -> string
---- Framework.FriendlyGUID::NewId_FromRandomLong 0x2cc7228
02cc7228: str     x30, [sp, #-0x20]!                         
02cc722c: stp     x20, x19, [sp, #0x10]                      
02cc7230: adrp    x20, #0x662f000                            
02cc7234: adrp    x19, #0x6267000                            
02cc7238: ldrb    w8, [x20, #0xc64]                          
02cc723c: ldr     x19, [x19, #0x328]                         T:Framework.FriendlyGUID
02cc7240: tbnz    w8, #0, #0x2cc7264                         
02cc7244: adrp    x0, #0x6267000                             
02cc7248: ldr     x0, [x0, #0x328]                           T:Framework.FriendlyGUID
02cc724c: bl      #0x2b70db0                                 fn_2b70db0
02cc7250: adrp    x0, #0x6267000                             
02cc7254: ldr     x0, [x0, #0x300]                           S:'x'
02cc7258: bl      #0x2b70db0                                 fn_2b70db0
02cc725c: mov     w8, #1                                     
02cc7260: strb    w8, [x20, #0xc64]                          
02cc7264: ldr     x0, [x19]                                  S:'didu'
02cc7268: str     wzr, [sp, #0xc]                            
02cc726c: ldr     w8, [x0, #0xe4]                            [62670e4]=0 f=0,0
02cc7270: cbnz    w8, #0x2cc727c                             
02cc7274: bl      #0x2b70f30                                 fn_2b70f30
02cc7278: ldr     x0, [x19]                                  S:'didu'
02cc727c: ldr     x8, [x0, #0xb8]                            M:Framework.SceneUtils/<CRUnloadSceneAsync>d__2::System.Collections.IEnumerator.Reset
02cc7280: ldr     x0, [x8]                                   
02cc7284: cbz     x0, #0x2cc72bc                             
02cc7288: ldr     x8, [x0]                                   S:'didu'
02cc728c: adrp    x19, #0x6267000                            
02cc7290: ldr     x19, [x19, #0x300]                         S:'x'
02cc7294: ldp     x9, x1, [x8, #0x188]                       
02cc7298: blr     x9                                         
02cc729c: ldr     x1, [x19]                                  S:'didu'
02cc72a0: str     w0, [sp, #0xc]                             
02cc72a4: add     x0, sp, #0xc                               
02cc72a8: mov     x2, xzr                                    
02cc72ac: bl      #0x4e0ead0                                 System.Int32::ToString
02cc72b0: ldp     x20, x19, [sp, #0x10]                      
02cc72b4: ldr     x30, [sp], #0x20                           
02cc72b8: ret                                                
02cc72bc: bl      #0x2b7105c                                 fn_2b7105c
## NewId_FromRandomDoubleLong() -> string
---- Framework.FriendlyGUID::NewId_FromRandomDoubleLong 0x2cc72c0
02cc72c0: str     x30, [sp, #-0x20]!                         
02cc72c4: stp     x20, x19, [sp, #0x10]                      
02cc72c8: adrp    x20, #0x662f000                            
02cc72cc: adrp    x19, #0x6267000                            
02cc72d0: ldrb    w8, [x20, #0xc65]                          
02cc72d4: ldr     x19, [x19, #0x328]                         T:Framework.FriendlyGUID
02cc72d8: tbnz    w8, #0, #0x2cc72fc                         
02cc72dc: adrp    x0, #0x6267000                             
02cc72e0: ldr     x0, [x0, #0x328]                           T:Framework.FriendlyGUID
02cc72e4: bl      #0x2b70db0                                 fn_2b70db0
02cc72e8: adrp    x0, #0x6267000                             
02cc72ec: ldr     x0, [x0, #0x300]                           S:'x'
02cc72f0: bl      #0x2b70db0                                 fn_2b70db0
02cc72f4: mov     w8, #1                                     
02cc72f8: strb    w8, [x20, #0xc65]                          
02cc72fc: ldr     x0, [x19]                                  S:'didu'
02cc7300: str     wzr, [sp, #0xc]                            
02cc7304: ldr     w8, [x0, #0xe4]                            [62670e4]=0 f=0,0
02cc7308: cbnz    w8, #0x2cc7314                             
02cc730c: bl      #0x2b70f30                                 fn_2b70f30
02cc7310: ldr     x0, [x19]                                  S:'didu'
02cc7314: ldr     x8, [x0, #0xb8]                            M:Framework.SceneUtils/<CRUnloadSceneAsync>d__2::System.Collections.IEnumerator.Reset
02cc7318: ldr     x0, [x8]                                   
02cc731c: cbz     x0, #0x2cc739c                             
02cc7320: ldr     x8, [x0]                                   S:'didu'
02cc7324: adrp    x20, #0x6267000                            
02cc7328: ldr     x20, [x20, #0x300]                         S:'x'
02cc732c: ldp     x9, x1, [x8, #0x188]                       
02cc7330: blr     x9                                         
02cc7334: ldr     x1, [x20]                                  S:'didu'
02cc7338: str     w0, [sp, #0xc]                             
02cc733c: add     x0, sp, #0xc                               
02cc7340: mov     x2, xzr                                    
02cc7344: bl      #0x4e0ead0                                 System.Int32::ToString
02cc7348: ldr     x8, [x19]                                  S:'didu'
02cc734c: ldr     x8, [x8, #0xb8]                            
02cc7350: ldr     x8, [x8]                                   
02cc7354: cbz     x8, #0x2cc739c                             
02cc7358: ldr     x9, [x8]                                   
02cc735c: mov     x19, x0                                    
02cc7360: mov     x0, x8                                     
02cc7364: ldp     x10, x1, [x9, #0x188]                      
02cc7368: blr     x10                                        
02cc736c: ldr     x1, [x20]                                  S:'didu'
02cc7370: str     w0, [sp, #0xc]                             
02cc7374: add     x0, sp, #0xc                               
02cc7378: mov     x2, xzr                                    
02cc737c: bl      #0x4e0ead0                                 System.Int32::ToString
02cc7380: mov     x1, x0                                     
02cc7384: mov     x0, x19                                    
02cc7388: mov     x2, xzr                                    
02cc738c: bl      #0x4c9c514                                 System.String::Concat
02cc7390: ldp     x20, x19, [sp, #0x10]                      
02cc7394: ldr     x30, [sp], #0x20                           
02cc7398: ret                                                
02cc739c: bl      #0x2b7105c                                 fn_2b7105c
## .cctor() -> void
---- Framework.FriendlyGUID::.cctor 0x2cc73a0
02cc73a0: stp     x30, x21, [sp, #-0x20]!                    
02cc73a4: stp     x20, x19, [sp, #0x10]                      
02cc73a8: adrp    x19, #0x662f000                            
02cc73ac: adrp    x21, #0x6267000                            
02cc73b0: adrp    x20, #0x6267000                            
02cc73b4: ldrb    w8, [x19, #0xc66]                          
02cc73b8: ldr     x21, [x21, #0x330]                         T:System.Random
02cc73bc: ldr     x20, [x20, #0x328]                         T:Framework.FriendlyGUID
02cc73c0: tbnz    w8, #0, #0x2cc73e4                         
02cc73c4: adrp    x0, #0x6267000                             
02cc73c8: ldr     x0, [x0, #0x328]                           T:Framework.FriendlyGUID
02cc73cc: bl      #0x2b70db0                                 fn_2b70db0
02cc73d0: adrp    x0, #0x6267000                             
02cc73d4: ldr     x0, [x0, #0x330]                           T:System.Random
02cc73d8: bl      #0x2b70db0                                 fn_2b70db0
02cc73dc: mov     w8, #1                                     
02cc73e0: strb    w8, [x19, #0xc66]                          
02cc73e4: ldr     x0, [x21]                                  S:'didu'
02cc73e8: bl      #0x2b7104c                                 fn_2b7104c
02cc73ec: mov     x1, xzr                                    
02cc73f0: mov     x19, x0                                    
02cc73f4: bl      #0x4e22b98                                 System.Random::.ctor
02cc73f8: ldr     x8, [x20]                                  S:'didu'
02cc73fc: mov     x1, x19                                    
02cc7400: ldr     x8, [x8, #0xb8]                            
02cc7404: str     x19, [x8]                                  
02cc7408: ldr     x8, [x20]                                  S:'didu'
02cc740c: ldp     x20, x19, [sp, #0x10]                      
02cc7410: ldr     x0, [x8, #0xb8]                            
02cc7414: ldp     x30, x21, [sp], #0x20                      
02cc7418: b       #0x2b70d54                                 
