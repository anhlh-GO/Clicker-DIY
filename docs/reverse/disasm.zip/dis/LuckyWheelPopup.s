#### CLASS LuckyWheelPopup/<>c parent= object
#   field <>9                            LuckyWheelPopup/<>c                                off=0x0 attr=36 
#   field <>9__53_0                      System.Predicate`1<RewardMysteryBox>               off=0x8 attr=16 
#   field <>9__53_3                      System.Predicate`1<RewardMysteryBox>               off=0x10 attr=16 
#   field <>9__62_0                      System.Action                                      off=0x18 attr=16 
## .cctor() -> void
---- LuckyWheelPopup/<>c::.cctor 0x2ce377c
02ce377c: str     x30, [sp, #-0x20]!                         
02ce3780: stp     x20, x19, [sp, #0x10]                      
02ce3784: adrp    x19, #0x662f000                            
02ce3788: adrp    x20, #0x6268000                            
02ce378c: ldrb    w8, [x19, #0xdcc]                          
02ce3790: ldr     x20, [x20, #0xa8]                          T:LuckyWheelPopup/<>c
02ce3794: tbnz    w8, #0, #0x2ce37ac                         
02ce3798: adrp    x0, #0x6268000                             
02ce379c: ldr     x0, [x0, #0xa8]                            T:LuckyWheelPopup/<>c
02ce37a0: bl      #0x2b70db0                                 fn_2b70db0
02ce37a4: mov     w8, #1                                     
02ce37a8: strb    w8, [x19, #0xdcc]                          
02ce37ac: ldr     x0, [x20]                                  S:'{0}/2'
02ce37b0: bl      #0x2b7104c                                 fn_2b7104c
02ce37b4: mov     x1, xzr                                    
02ce37b8: mov     x19, x0                                    
02ce37bc: bl      #0x4e53e9c                                 System.Object::.ctor
02ce37c0: ldr     x8, [x20]                                  S:'{0}/2'
02ce37c4: mov     x1, x19                                    
02ce37c8: ldr     x8, [x8, #0xb8]                            
02ce37cc: str     x19, [x8]                                  
02ce37d0: ldr     x8, [x20]                                  S:'{0}/2'
02ce37d4: ldp     x20, x19, [sp, #0x10]                      
02ce37d8: ldr     x0, [x8, #0xb8]                            
02ce37dc: ldr     x30, [sp], #0x20                           
02ce37e0: b       #0x2b70d54                                 
## .ctor() -> void
---- LuckyWheelPopup/<>c::.ctor 0x2ce37e4
02ce37e4: mov     x1, xzr                                    
02ce37e8: b       #0x4e53e9c                                 System.Object::.ctor
## <GetRewardItem>b__53_0(RewardMysteryBox x) -> bool
---- LuckyWheelPopup/<>c::<GetRewardItem>b__53_0 0x2ce37ec
02ce37ec: cbz     x1, #0x2ce3800                             
02ce37f0: ldrb    w8, [x1, #0x10]                            
02ce37f4: cmp     w8, #0                                     
02ce37f8: cset    w0, eq                                     
02ce37fc: ret                                                
02ce3800: str     x30, [sp, #-0x10]!                         
02ce3804: bl      #0x2b7105c                                 fn_2b7105c
## <GetRewardItem>b__53_3(RewardMysteryBox x) -> bool
---- LuckyWheelPopup/<>c::<GetRewardItem>b__53_3 0x2ce3808
02ce3808: cbz     x1, #0x2ce3814                             
02ce380c: ldrb    w0, [x1, #0x10]                            
02ce3810: ret                                                
02ce3814: str     x30, [sp, #-0x10]!                         
02ce3818: bl      #0x2b7105c                                 fn_2b7105c
## <StartFreeSpin>b__62_0() -> void
---- LuckyWheelPopup/<>c::<StartFreeSpin>b__62_0 0x2ce381c
02ce381c: str     x30, [sp, #-0x20]!                         
02ce3820: stp     x20, x19, [sp, #0x10]                      
02ce3824: adrp    x19, #0x662f000                            
02ce3828: adrp    x20, #0x6267000                            
02ce382c: ldrb    w8, [x19, #0xdcd]                          
02ce3830: ldr     x20, [x20, #0xfa0]                         S:'IsCountdown'
02ce3834: tbnz    w8, #0, #0x2ce384c                         
02ce3838: adrp    x0, #0x6267000                             
02ce383c: ldr     x0, [x0, #0xfa0]                           S:'IsCountdown'
02ce3840: bl      #0x2b70db0                                 fn_2b70db0
02ce3844: mov     w8, #1                                     
02ce3848: strb    w8, [x19, #0xdcd]                          
02ce384c: ldr     x0, [x20]                                  S:'didu'
02ce3850: mov     w1, #1                                     
02ce3854: mov     x2, xzr                                    
02ce3858: bl      #0x5b2d184                                 UnityEngine.PlayerPrefs::SetInt
02ce385c: ldp     x20, x19, [sp, #0x10]                      
02ce3860: mov     x0, xzr                                    
02ce3864: ldr     x30, [sp], #0x20                           
02ce3868: b       #0x5b2d914                                 UnityEngine.PlayerPrefs::Save
#### CLASS LuckyWheelPopup/<>c__DisplayClass50_0 parent= object
#   field animationCompleted             UnityEngine.Events.UnityAction                     off=0x10 attr=6 
## .ctor() -> void
---- LuckyWheelPopup/<>c__DisplayClass50_0::.ctor 0x2ce21d0
02ce21d0: mov     x1, xzr                                    
02ce21d4: b       #0x4e53e9c                                 System.Object::.ctor
## <RunAnimation>b__0() -> void
---- LuckyWheelPopup/<>c__DisplayClass50_0::<RunAnimation>b__0 0x2ce386c
02ce386c: ldr     x8, [x0, #0x10]                            .animationCompleted
02ce3870: cbz     x8, #0x2ce3884                             
02ce3874: ldr     x0, [x8, #0x40]                            
02ce3878: ldr     x1, [x8, #0x28]                            
02ce387c: ldr     x2, [x8, #0x18]                            
02ce3880: br      x2                                         
02ce3884: ret                                                
#### CLASS LuckyWheelPopup/<>c__DisplayClass51_0 parent= object
#   field resultID                       string                                             off=0x10 attr=6 
## .ctor() -> void
---- LuckyWheelPopup/<>c__DisplayClass51_0::.ctor 0x2ce3888
02ce3888: mov     x1, xzr                                    
02ce388c: b       #0x4e53e9c                                 System.Object::.ctor
## <SpinAnimation>b__0(LuckyWheelNode node) -> bool
---- LuckyWheelPopup/<>c__DisplayClass51_0::<SpinAnimation>b__0 0x2ce3890
02ce3890: cbz     x1, #0x2ce38a8                             
02ce3894: ldr     x8, [x1, #0x20]                            
02ce3898: ldr     x1, [x0, #0x10]                            .resultID
02ce389c: mov     x2, xzr                                    
02ce38a0: mov     x0, x8                                     
02ce38a4: b       #0x4ca52b8                                 System.String::op_Equality
02ce38a8: str     x30, [sp, #-0x10]!                         
02ce38ac: bl      #0x2b7105c                                 fn_2b7105c
#### CLASS LuckyWheelPopup/<>c__DisplayClass52_0 parent= object
#   field <>4__this                      LuckyWheelPopup                                    off=0x10 attr=6 
#   field rewardConfig                   LuckyWheelRewardConfig                             off=0x18 attr=6 
#   field onComplete                     System.Action                                      off=0x20 attr=6 
#   field <>9__1                         System.Predicate`1<LuckyWheelNode>                 off=0x28 attr=6 
#   field <>9__2                         System.Action                                      off=0x30 attr=6 
#   field <>9__3                         System.Action                                      off=0x38 attr=6 
## .ctor() -> void
---- LuckyWheelPopup/<>c__DisplayClass52_0::.ctor 0x2ce2474
02ce2474: mov     x1, xzr                                    
02ce2478: b       #0x4e53e9c                                 System.Object::.ctor
## <StartSpin>b__0() -> void
---- LuckyWheelPopup/<>c__DisplayClass52_0::<StartSpin>b__0 0x2ce38b0
02ce38b0: str     x30, [sp, #-0x40]!                         
02ce38b4: stp     x24, x23, [sp, #0x10]                      
02ce38b8: stp     x22, x21, [sp, #0x20]                      
02ce38bc: stp     x20, x19, [sp, #0x30]                      
02ce38c0: adrp    x20, #0x662f000                            
02ce38c4: mov     x19, x0                                    
02ce38c8: ldrb    w8, [x20, #0xdce]                          
02ce38cc: tbnz    w8, #0, #0x2ce3950                         
02ce38d0: adrp    x0, #0x6264000                             
02ce38d4: ldr     x0, [x0, #0xf90]                           T:System.Action
02ce38d8: bl      #0x2b70db0                                 fn_2b70db0
02ce38dc: adrp    x0, #0x6266000                             
02ce38e0: ldr     x0, [x0, #0x128]                           T:System.DateTime
02ce38e4: bl      #0x2b70db0                                 fn_2b70db0
02ce38e8: adrp    x0, #0x6268000                             
02ce38ec: ldr     x0, [x0, #0x110]                           MS:System.Collections.Generic.List`1::Find
02ce38f0: bl      #0x2b70db0                                 fn_2b70db0
02ce38f4: adrp    x0, #0x6263000                             
02ce38f8: ldr     x0, [x0, #0x918]                           T:UnityEngine.Object
02ce38fc: bl      #0x2b70db0                                 fn_2b70db0
02ce3900: adrp    x0, #0x6268000                             
02ce3904: ldr     x0, [x0, #0x118]                           T:type57261(k15)
02ce3908: bl      #0x2b70db0                                 fn_2b70db0
02ce390c: adrp    x0, #0x6268000                             
02ce3910: ldr     x0, [x0, #0x120]                           M:LuckyWheelPopup/<>c__DisplayClass52_0::<StartSpin>b__1
02ce3914: bl      #0x2b70db0                                 fn_2b70db0
02ce3918: adrp    x0, #0x6268000                             
02ce391c: ldr     x0, [x0, #0x128]                           M:LuckyWheelPopup/<>c__DisplayClass52_0::<StartSpin>b__2
02ce3920: bl      #0x2b70db0                                 fn_2b70db0
02ce3924: adrp    x0, #0x6268000                             
02ce3928: ldr     x0, [x0, #0x130]                           M:LuckyWheelPopup/<>c__DisplayClass52_0::<StartSpin>b__3
02ce392c: bl      #0x2b70db0                                 fn_2b70db0
02ce3930: adrp    x0, #0x6268000                             
02ce3934: ldr     x0, [x0, #0x138]                           S:'penguin_open_mouth'
02ce3938: bl      #0x2b70db0                                 fn_2b70db0
02ce393c: adrp    x0, #0x6267000                             
02ce3940: ldr     x0, [x0, #0xfa0]                           S:'IsCountdown'
02ce3944: bl      #0x2b70db0                                 fn_2b70db0
02ce3948: mov     w8, #1                                     
02ce394c: strb    w8, [x20, #0xdce]                          
02ce3950: ldr     x8, [x19, #0x10]                           .<>4__this
02ce3954: str     xzr, [sp, #8]                              
02ce3958: cbz     x8, #0x2ce3ba8                             
02ce395c: bl      #0x2ce18ac                                 LuckyWheelPopup::get_Count
02ce3960: ldr     x8, [x19, #0x10]                           .<>4__this
02ce3964: cbz     x8, #0x2ce3ba8                             
02ce3968: add     w8, w0, #1                                 
02ce396c: cmp     w8, #2                                     
02ce3970: mov     w8, #2                                     
02ce3974: csinc   w8, w8, w0, ge                             
02ce3978: bic     w1, w8, w8, asr #31                        
02ce397c: bl      #0x2ce18f4                                 LuckyWheelPopup::set_Count
02ce3980: ldr     x8, [x19, #0x10]                           .<>4__this
02ce3984: cbz     x8, #0x2ce3ba8                             
02ce3988: bl      #0x2ce18ac                                 LuckyWheelPopup::get_Count
02ce398c: cmp     w0, #1                                     
02ce3990: b.lt    #0x2ce39e0                                 
02ce3994: adrp    x8, #0x6266000                             
02ce3998: adrp    x20, #0x6267000                            
02ce399c: ldr     x8, [x8, #0x128]                           T:System.DateTime
02ce39a0: ldr     x0, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ce39a4: ldr     w8, [x0, #0xe4]                            [62670e4]=0 f=0,0
02ce39a8: ldr     x20, [x20, #0xfa0]                         S:'IsCountdown'
02ce39ac: cbnz    w8, #0x2ce39b4                             
02ce39b0: bl      #0x2b70f30                                 fn_2b70f30
02ce39b4: mov     x0, xzr                                    
02ce39b8: bl      #0x4df25c8                                 System.DateTime::get_Now
02ce39bc: str     x0, [sp, #8]                               
02ce39c0: add     x0, sp, #8                                 
02ce39c4: mov     x1, xzr                                    
02ce39c8: bl      #0x4df3550                                 System.DateTime::ToString
02ce39cc: ldr     x8, [x20]                                  S:'didu'
02ce39d0: mov     x1, x0                                     
02ce39d4: mov     x2, xzr                                    
02ce39d8: mov     x0, x8                                     
02ce39dc: bl      #0x5b2d398                                 UnityEngine.PlayerPrefs::SetString
02ce39e0: ldr     x0, [x19, #0x10]                           .<>4__this
02ce39e4: cbz     x0, #0x2ce3ba8                             
02ce39e8: bl      #0x2ce1e08                                 LuckyWheelPopup::CheckCounterSpin
02ce39ec: ldr     x8, [x19, #0x10]                           .<>4__this
02ce39f0: cbz     x8, #0x2ce3ba8                             
02ce39f4: mov     x22, x19                                   
02ce39f8: ldr     x20, [x8, #0xb0]                           S:'native_banner_ad_on_off'
02ce39fc: ldr     x21, [x22, #0x28]!                         
02ce3a00: cbnz    x21, #0x2ce3a40                            
02ce3a04: adrp    x8, #0x6268000                             
02ce3a08: ldr     x8, [x8, #0x118]                           T:type57261(k15)
02ce3a0c: ldr     x0, [x8]                                   S:'{0}/2'
02ce3a10: bl      #0x2b7104c                                 fn_2b7104c
02ce3a14: adrp    x8, #0x6268000                             
02ce3a18: mov     x1, x19                                    
02ce3a1c: mov     x3, xzr                                    
02ce3a20: ldr     x8, [x8, #0x120]                           M:LuckyWheelPopup/<>c__DisplayClass52_0::<StartSpin>b__1
02ce3a24: mov     x21, x0                                    
02ce3a28: ldr     x2, [x8]                                   S:'{0}/2'
02ce3a2c: bl      #0x399ba10                                 fn_399ba10
02ce3a30: mov     x0, x22                                    
02ce3a34: mov     x1, x21                                    
02ce3a38: str     x21, [x19, #0x28]                          .<>9__1
02ce3a3c: bl      #0x2b70d54                                 fn_2b70d54
02ce3a40: cbz     x20, #0x2ce3ba8                            
02ce3a44: adrp    x8, #0x6268000                             
02ce3a48: adrp    x22, #0x6263000                            
02ce3a4c: mov     x0, x20                                    
02ce3a50: ldr     x8, [x8, #0x110]                           MS:System.Collections.Generic.List`1::Find
02ce3a54: ldr     x22, [x22, #0x918]                         T:UnityEngine.Object
02ce3a58: mov     x1, x21                                    
02ce3a5c: ldr     x2, [x8]                                   S:'{0}/2'
02ce3a60: bl      #0x35a9868                                 fn_35a9868
02ce3a64: ldr     x8, [x22]                                  &2c5bbd4(=a9bd7bfdd503233f)
02ce3a68: mov     x20, x0                                    
02ce3a6c: ldr     w9, [x8, #0xe4]                            [62680e4]=0 f=0,0
02ce3a70: cbnz    w9, #0x2ce3a7c                             
02ce3a74: mov     x0, x8                                     
02ce3a78: bl      #0x2b70f30                                 fn_2b70f30
02ce3a7c: mov     x0, x20                                    
02ce3a80: mov     x1, xzr                                    
02ce3a84: bl      #0x5b3bb1c                                 UnityEngine.Object::op_Implicit
02ce3a88: tbz     w0, #0, #0x2ce3b94                         
02ce3a8c: adrp    x8, #0x6268000                             
02ce3a90: mov     x24, x19                                   
02ce3a94: ldr     x8, [x8, #0x138]                           S:'penguin_open_mouth'
02ce3a98: ldr     x23, [x24, #0x30]!                         
02ce3a9c: ldur    x21, [x24, #-0x20]                         
02ce3aa0: ldr     x22, [x8]                                  S:'{0}/2'
02ce3aa4: cbnz    x23, #0x2ce3ae4                            
02ce3aa8: adrp    x8, #0x6264000                             
02ce3aac: ldr     x8, [x8, #0xf90]                           T:System.Action
02ce3ab0: ldr     x0, [x8]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02ce3ab4: bl      #0x2b7104c                                 fn_2b7104c
02ce3ab8: adrp    x8, #0x6268000                             
02ce3abc: mov     x1, x19                                    
02ce3ac0: mov     x3, xzr                                    
02ce3ac4: ldr     x8, [x8, #0x128]                           M:LuckyWheelPopup/<>c__DisplayClass52_0::<StartSpin>b__2
02ce3ac8: mov     x23, x0                                    
02ce3acc: ldr     x2, [x8]                                   S:'{0}/2'
02ce3ad0: bl      #0x4d8ddbc                                 System.Action::.ctor
02ce3ad4: mov     x0, x24                                    
02ce3ad8: mov     x1, x23                                    
02ce3adc: str     x23, [x19, #0x30]                          .<>9__2
02ce3ae0: bl      #0x2b70d54                                 fn_2b70d54
02ce3ae4: cbz     x21, #0x2ce3ba8                            
02ce3ae8: mov     x0, x21                                    
02ce3aec: mov     x1, x22                                    
02ce3af0: mov     w2, wzr                                    
02ce3af4: mov     x3, x23                                    
02ce3af8: bl      #0x2ce1b80                                 LuckyWheelPopup::PlayAnimation
02ce3afc: ldr     x8, [x19, #0x18]                           .rewardConfig
02ce3b00: cbz     x8, #0x2ce3ba8                             
02ce3b04: ldr     w8, [x8, #0x1c]                            [626801c]=0 f=0,0
02ce3b08: cbnz    w8, #0x2ce3b38                             
02ce3b0c: mov     x0, xzr                                    
02ce3b10: bl      #0x2d6eec8                                 Framework.AudioManager::get_Instance
02ce3b14: cbz     x0, #0x2ce3ba8                             
02ce3b18: movi    d1, #0000000000000000                      
02ce3b1c: movi    d2, #0000000000000000                      
02ce3b20: mov     w1, #0x2c                                  
02ce3b24: fmov    s0, #1.00000000                            
02ce3b28: mov     w2, wzr                                    
02ce3b2c: mov     w3, wzr                                    
02ce3b30: mov     x4, xzr                                    
02ce3b34: bl      #0x2d6f03c                                 Framework.AudioManager::PlaySound
02ce3b38: mov     x22, x19                                   
02ce3b3c: ldr     x21, [x22, #0x38]!                         &6260bd8(=0)
02ce3b40: cbnz    x21, #0x2ce3b80                            
02ce3b44: adrp    x8, #0x6264000                             
02ce3b48: ldr     x8, [x8, #0xf90]                           T:System.Action
02ce3b4c: ldr     x0, [x8]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02ce3b50: bl      #0x2b7104c                                 fn_2b7104c
02ce3b54: adrp    x8, #0x6268000                             
02ce3b58: mov     x1, x19                                    
02ce3b5c: mov     x3, xzr                                    
02ce3b60: ldr     x8, [x8, #0x130]                           M:LuckyWheelPopup/<>c__DisplayClass52_0::<StartSpin>b__3
02ce3b64: mov     x21, x0                                    
02ce3b68: ldr     x2, [x8]                                   S:'{0}/2'
02ce3b6c: bl      #0x4d8ddbc                                 System.Action::.ctor
02ce3b70: mov     x0, x22                                    
02ce3b74: mov     x1, x21                                    
02ce3b78: str     x21, [x19, #0x38]                          .<>9__3
02ce3b7c: bl      #0x2b70d54                                 fn_2b70d54
02ce3b80: cbz     x20, #0x2ce3ba8                            
02ce3b84: adrp    x8, #0x1084000                             
02ce3b88: mov     x1, x21                                    
02ce3b8c: ldr     s0, [x8, #0xcc4]                           [1084cc4]=3f8000543f4ccccd f=0.8,1.00001
02ce3b90: bl      #0x2ce1654                                 LuckyWheelNode::PlayAnimationReward
02ce3b94: ldp     x20, x19, [sp, #0x30]                      
02ce3b98: ldp     x22, x21, [sp, #0x20]                      
02ce3b9c: ldp     x24, x23, [sp, #0x10]                      
02ce3ba0: ldr     x30, [sp], #0x40                           
02ce3ba4: ret                                                
02ce3ba8: bl      #0x2b7105c                                 fn_2b7105c
## <StartSpin>b__1(LuckyWheelNode x) -> bool
---- LuckyWheelPopup/<>c__DisplayClass52_0::<StartSpin>b__1 0x2ce3bac
02ce3bac: str     x30, [sp, #-0x10]!                         
02ce3bb0: cbz     x1, #0x2ce3bd0                             
02ce3bb4: ldr     x8, [x0, #0x18]                            .rewardConfig
02ce3bb8: cbz     x8, #0x2ce3bd0                             
02ce3bbc: ldr     x0, [x1, #0x20]                            
02ce3bc0: ldr     x1, [x8, #0x10]                            
02ce3bc4: mov     x2, xzr                                    
02ce3bc8: ldr     x30, [sp], #0x10                           
02ce3bcc: b       #0x4ca52b8                                 System.String::op_Equality
02ce3bd0: bl      #0x2b7105c                                 fn_2b7105c
## <StartSpin>b__2() -> void
---- LuckyWheelPopup/<>c__DisplayClass52_0::<StartSpin>b__2 0x2ce3bd4
02ce3bd4: str     x30, [sp, #-0x20]!                         
02ce3bd8: stp     x20, x19, [sp, #0x10]                      
02ce3bdc: adrp    x20, #0x662f000                            
02ce3be0: mov     x19, x0                                    
02ce3be4: ldrb    w8, [x20, #0xdcf]                          
02ce3be8: tbnz    w8, #0, #0x2ce3c00                         
02ce3bec: adrp    x0, #0x6268000                             
02ce3bf0: ldr     x0, [x0, #0x140]                           S:'penguin_open_mouth_loop'
02ce3bf4: bl      #0x2b70db0                                 fn_2b70db0
02ce3bf8: mov     w8, #1                                     
02ce3bfc: strb    w8, [x20, #0xdcf]                          
02ce3c00: ldr     x0, [x19, #0x10]                           .<>4__this
02ce3c04: cbz     x0, #0x2ce3c28                             
02ce3c08: adrp    x8, #0x6268000                             
02ce3c0c: mov     w2, #1                                     
02ce3c10: mov     x3, xzr                                    
02ce3c14: ldr     x8, [x8, #0x140]                           S:'penguin_open_mouth_loop'
02ce3c18: ldp     x20, x19, [sp, #0x10]                      
02ce3c1c: ldr     x1, [x8]                                   S:'{0}/2'
02ce3c20: ldr     x30, [sp], #0x20                           
02ce3c24: b       #0x2ce1b80                                 LuckyWheelPopup::PlayAnimation
02ce3c28: bl      #0x2b7105c                                 fn_2b7105c
## <StartSpin>b__3() -> void
---- LuckyWheelPopup/<>c__DisplayClass52_0::<StartSpin>b__3 0x2ce3c2c
02ce3c2c: str     x30, [sp, #-0x20]!                         
02ce3c30: stp     x20, x19, [sp, #0x10]                      
02ce3c34: adrp    x20, #0x662f000                            
02ce3c38: mov     x19, x0                                    
02ce3c3c: ldrb    w8, [x20, #0xdd0]                          
02ce3c40: tbnz    w8, #0, #0x2ce3c58                         
02ce3c44: adrp    x0, #0x6268000                             
02ce3c48: ldr     x0, [x0, #0x148]                           S:'1'
02ce3c4c: bl      #0x2b70db0                                 fn_2b70db0
02ce3c50: mov     w8, #1                                     
02ce3c54: strb    w8, [x20, #0xdd0]                          
02ce3c58: ldr     x8, [x19, #0x18]                           .rewardConfig
02ce3c5c: cbz     x8, #0x2ce3cec                             
02ce3c60: ldr     w9, [x8, #0x1c]                            
02ce3c64: ldr     x0, [x19, #0x10]                           .<>4__this
02ce3c68: cmp     w9, #1                                     
02ce3c6c: b.ne    #0x2ce3cbc                                 
02ce3c70: cbz     x0, #0x2ce3cec                             
02ce3c74: adrp    x9, #0x6268000                             
02ce3c78: mov     x2, xzr                                    
02ce3c7c: ldr     x9, [x9, #0x148]                           S:'1'
02ce3c80: ldr     x20, [x0, #0xc0]                           M:LuckyWheelPopup/<>c__DisplayClass54_0::<GetMoney>b__0
02ce3c84: ldr     x0, [x8, #0x10]                            
02ce3c88: ldr     x1, [x9]                                   S:'{0}/2'
02ce3c8c: bl      #0x4ca52b8                                 System.String::op_Equality
02ce3c90: cbz     x20, #0x2ce3cec                            
02ce3c94: mov     w8, #1                                     
02ce3c98: bic     w1, w8, w0                                 
02ce3c9c: mov     x0, x20                                    
02ce3ca0: bl      #0x2ce03a0                                 GiftBoxLuckyWheel::SetGiftBox
02ce3ca4: ldr     x0, [x19, #0x10]                           .<>4__this
02ce3ca8: cbz     x0, #0x2ce3cec                             
02ce3cac: ldr     x1, [x19, #0x20]                           .onComplete
02ce3cb0: ldp     x20, x19, [sp, #0x10]                      
02ce3cb4: ldr     x30, [sp], #0x20                           
02ce3cb8: b       #0x2ce247c                                 LuckyWheelPopup::GetRewardItem
02ce3cbc: cbz     x0, #0x2ce3cec                             
02ce3cc0: ldr     s0, [x8, #0x20]                            
02ce3cc4: mov     w8, #0x7f800000                            
02ce3cc8: ldr     x2, [x19, #0x20]                           .onComplete
02ce3ccc: fmov    s1, w8                                     
02ce3cd0: ldp     x20, x19, [sp, #0x10]                      
02ce3cd4: fcvtzs  w9, s0                                     
02ce3cd8: mov     w8, #-0xffffffff80000000                   
02ce3cdc: fcmp    s0, s1                                     
02ce3ce0: csel    w1, w8, w9, eq                             
02ce3ce4: ldr     x30, [sp], #0x20                           
02ce3ce8: b       #0x2ce2a00                                 LuckyWheelPopup::GetMoney
02ce3cec: bl      #0x2b7105c                                 fn_2b7105c
#### CLASS LuckyWheelPopup/<>c__DisplayClass53_0 parent= object
#   field <>4__this                      LuckyWheelPopup                                    off=0x10 attr=6 
#   field onComplete                     System.Action                                      off=0x18 attr=6 
#   field <>9__5                         System.Action                                      off=0x20 attr=6 
## .ctor() -> void
---- LuckyWheelPopup/<>c__DisplayClass53_0::.ctor 0x2ce29f0
02ce29f0: mov     x1, xzr                                    
02ce29f4: b       #0x4e53e9c                                 System.Object::.ctor
## <GetRewardItem>b__1() -> void
---- LuckyWheelPopup/<>c__DisplayClass53_0::<GetRewardItem>b__1 0x2ce3cf0
02ce3cf0: str     x30, [sp, #-0x20]!                         
02ce3cf4: stp     x20, x19, [sp, #0x10]                      
02ce3cf8: adrp    x20, #0x662f000                            
02ce3cfc: mov     x19, x0                                    
02ce3d00: ldrb    w8, [x20, #0xdd1]                          
02ce3d04: tbnz    w8, #0, #0x2ce3d1c                         
02ce3d08: adrp    x0, #0x6267000                             
02ce3d0c: ldr     x0, [x0, #0xfc0]                           S:'idle'
02ce3d10: bl      #0x2b70db0                                 fn_2b70db0
02ce3d14: mov     w8, #1                                     
02ce3d18: strb    w8, [x20, #0xdd1]                          
02ce3d1c: ldr     x0, [x19, #0x10]                           .<>4__this
02ce3d20: cbz     x0, #0x2ce3d44                             
02ce3d24: adrp    x8, #0x6267000                             
02ce3d28: mov     w2, #1                                     
02ce3d2c: mov     x3, xzr                                    
02ce3d30: ldr     x8, [x8, #0xfc0]                           S:'idle'
02ce3d34: ldp     x20, x19, [sp, #0x10]                      
02ce3d38: ldr     x1, [x8]                                   S:'didu'
02ce3d3c: ldr     x30, [sp], #0x20                           
02ce3d40: b       #0x2ce1b80                                 LuckyWheelPopup::PlayAnimation
02ce3d44: bl      #0x2b7105c                                 fn_2b7105c
## <GetRewardItem>b__2() -> void
---- LuckyWheelPopup/<>c__DisplayClass53_0::<GetRewardItem>b__2 0x2ce3d48
02ce3d48: str     x30, [sp, #-0x20]!                         
02ce3d4c: stp     x20, x19, [sp, #0x10]                      
02ce3d50: ldr     x20, [x0, #0x10]                           .<>4__this
02ce3d54: cbz     x20, #0x2ce3db4                            
02ce3d58: mov     x19, x0                                    
02ce3d5c: ldr     x0, [x20, #0x58]                           
02ce3d60: strb    wzr, [x20, #0xf4]                          
02ce3d64: cbz     x0, #0x2ce3db4                             
02ce3d68: mov     x1, xzr                                    
02ce3d6c: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02ce3d70: mov     x1, x0                                     
02ce3d74: mov     x0, x20                                    
02ce3d78: bl      #0x2ce2ca0                                 LuckyWheelPopup::StartButtonSpinAnim
02ce3d7c: ldr     x0, [x19, #0x10]                           .<>4__this
02ce3d80: cbz     x0, #0x2ce3db4                             
02ce3d84: bl      #0x2ce2dbc                                 LuckyWheelPopup::ActiveButtonBack
02ce3d88: ldr     x8, [x19, #0x18]                           .onComplete
02ce3d8c: cbz     x8, #0x2ce3da8                             
02ce3d90: ldp     x20, x19, [sp, #0x10]                      
02ce3d94: ldr     x0, [x8, #0x40]                            
02ce3d98: ldr     x1, [x8, #0x28]                            
02ce3d9c: ldr     x2, [x8, #0x18]                            
02ce3da0: ldr     x30, [sp], #0x20                           
02ce3da4: br      x2                                         
02ce3da8: ldp     x20, x19, [sp, #0x10]                      
02ce3dac: ldr     x30, [sp], #0x20                           
02ce3db0: ret                                                
02ce3db4: bl      #0x2b7105c                                 fn_2b7105c
## <GetRewardItem>b__5() -> void
---- LuckyWheelPopup/<>c__DisplayClass53_0::<GetRewardItem>b__5 0x2ce3db8
02ce3db8: str     x30, [sp, #-0x20]!                         
02ce3dbc: stp     x20, x19, [sp, #0x10]                      
02ce3dc0: ldr     x20, [x0, #0x10]                           .<>4__this
02ce3dc4: cbz     x20, #0x2ce3e24                            
02ce3dc8: mov     x19, x0                                    
02ce3dcc: ldr     x0, [x20, #0x58]                           
02ce3dd0: strb    wzr, [x20, #0xf4]                          
02ce3dd4: cbz     x0, #0x2ce3e24                             
02ce3dd8: mov     x1, xzr                                    
02ce3ddc: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02ce3de0: mov     x1, x0                                     
02ce3de4: mov     x0, x20                                    
02ce3de8: bl      #0x2ce2ca0                                 LuckyWheelPopup::StartButtonSpinAnim
02ce3dec: ldr     x0, [x19, #0x10]                           .<>4__this
02ce3df0: cbz     x0, #0x2ce3e24                             
02ce3df4: bl      #0x2ce2dbc                                 LuckyWheelPopup::ActiveButtonBack
02ce3df8: ldr     x8, [x19, #0x18]                           .onComplete
02ce3dfc: cbz     x8, #0x2ce3e18                             
02ce3e00: ldp     x20, x19, [sp, #0x10]                      
02ce3e04: ldr     x0, [x8, #0x40]                            
02ce3e08: ldr     x1, [x8, #0x28]                            
02ce3e0c: ldr     x2, [x8, #0x18]                            
02ce3e10: ldr     x30, [sp], #0x20                           
02ce3e14: br      x2                                         
02ce3e18: ldp     x20, x19, [sp, #0x10]                      
02ce3e1c: ldr     x30, [sp], #0x20                           
02ce3e20: ret                                                
02ce3e24: bl      #0x2b7105c                                 fn_2b7105c
#### CLASS LuckyWheelPopup/<>c__DisplayClass53_1 parent= object
#   field coin                           RewardMysteryBox                                   off=0x10 attr=6 
#   field CS$<>8__locals1                LuckyWheelPopup/<>c__DisplayClass53_0              off=0x18 attr=6 
## .ctor() -> void
---- LuckyWheelPopup/<>c__DisplayClass53_1::.ctor 0x2ce29f8
02ce29f8: mov     x1, xzr                                    
02ce29fc: b       #0x4e53e9c                                 System.Object::.ctor
## <GetRewardItem>b__4() -> void
---- LuckyWheelPopup/<>c__DisplayClass53_1::<GetRewardItem>b__4 0x2ce3e28
02ce3e28: stp     x30, x23, [sp, #-0x30]!                    
02ce3e2c: stp     x22, x21, [sp, #0x10]                      
02ce3e30: stp     x20, x19, [sp, #0x20]                      
02ce3e34: adrp    x21, #0x662f000                            
02ce3e38: adrp    x20, #0x6266000                            
02ce3e3c: mov     x19, x0                                    
02ce3e40: ldrb    w8, [x21, #0xdd2]                          
02ce3e44: ldr     x20, [x20, #0xaa0]                         MS:MonoSingleton`1::get_Instance
02ce3e48: tbnz    w8, #0, #0x2ce3e78                         
02ce3e4c: adrp    x0, #0x6264000                             
02ce3e50: ldr     x0, [x0, #0xf90]                           T:System.Action
02ce3e54: bl      #0x2b70db0                                 fn_2b70db0
02ce3e58: adrp    x0, #0x6266000                             
02ce3e5c: ldr     x0, [x0, #0xaa0]                           MS:MonoSingleton`1::get_Instance
02ce3e60: bl      #0x2b70db0                                 fn_2b70db0
02ce3e64: adrp    x0, #0x6268000                             
02ce3e68: ldr     x0, [x0, #0x150]                           M:LuckyWheelPopup/<>c__DisplayClass53_0::<GetRewardItem>b__5
02ce3e6c: bl      #0x2b70db0                                 fn_2b70db0
02ce3e70: mov     w8, #1                                     
02ce3e74: strb    w8, [x21, #0xdd2]                          
02ce3e78: ldr     x0, [x20]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ce3e7c: bl      #0x3769600                                 fn_3769600
02ce3e80: ldr     x8, [x19, #0x10]                           .coin
02ce3e84: cbz     x8, #0x2ce3f30                             
02ce3e88: cbz     x0, #0x2ce3f30                             
02ce3e8c: ldr     x0, [x0, #0x38]                            T:LuckyWheelPopup/<>c__DisplayClass53_0
02ce3e90: cbz     x0, #0x2ce3ea4                             
02ce3e94: fmov    s0, #2.00000000                            
02ce3e98: ldr     w1, [x8, #0x14]                            
02ce3e9c: mov     x2, xzr                                    
02ce3ea0: bl      #0x2d24708                                 Home.MoneyItem::Show
02ce3ea4: ldr     x0, [x20]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ce3ea8: bl      #0x3769600                                 fn_3769600
02ce3eac: ldr     x8, [x19, #0x10]                           .coin
02ce3eb0: cbz     x8, #0x2ce3f30                             
02ce3eb4: ldr     x21, [x19, #0x18]                          .CS$<>8__locals1
02ce3eb8: cbz     x21, #0x2ce3f30                            
02ce3ebc: mov     x23, x21                                   
02ce3ec0: ldr     w19, [x8, #0x14]                           
02ce3ec4: mov     x20, x0                                    
02ce3ec8: ldr     x22, [x23, #0x20]!                         
02ce3ecc: cbnz    x22, #0x2ce3f0c                            
02ce3ed0: adrp    x8, #0x6264000                             
02ce3ed4: ldr     x8, [x8, #0xf90]                           T:System.Action
02ce3ed8: ldr     x0, [x8]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02ce3edc: bl      #0x2b7104c                                 fn_2b7104c
02ce3ee0: adrp    x8, #0x6268000                             
02ce3ee4: mov     x1, x21                                    
02ce3ee8: mov     x3, xzr                                    
02ce3eec: ldr     x8, [x8, #0x150]                           M:LuckyWheelPopup/<>c__DisplayClass53_0::<GetRewardItem>b__5
02ce3ef0: mov     x22, x0                                    
02ce3ef4: ldr     x2, [x8]                                   S:'{0}/2'
02ce3ef8: bl      #0x4d8ddbc                                 System.Action::.ctor
02ce3efc: mov     x0, x23                                    
02ce3f00: mov     x1, x22                                    
02ce3f04: str     x22, [x21, #0x20]                          
02ce3f08: bl      #0x2b70d54                                 fn_2b70d54
02ce3f0c: cbz     x20, #0x2ce3f30                            
02ce3f10: mov     x0, x20                                    
02ce3f14: mov     w1, w19                                    
02ce3f18: mov     x3, x22                                    
02ce3f1c: ldp     x20, x19, [sp, #0x20]                      
02ce3f20: mov     w2, #0xa                                   
02ce3f24: ldp     x22, x21, [sp, #0x10]                      
02ce3f28: ldp     x30, x23, [sp], #0x30                      
02ce3f2c: b       #0x2cdaf30                                 MoneyManager::CollectMoney
02ce3f30: bl      #0x2b7105c                                 fn_2b7105c
#### CLASS LuckyWheelPopup/<>c__DisplayClass54_0 parent= object
#   field <>4__this                      LuckyWheelPopup                                    off=0x10 attr=6 
#   field onComplete                     System.Action                                      off=0x18 attr=6 
#   field <>9__2                         System.Action                                      off=0x20 attr=6 
## .ctor() -> void
---- LuckyWheelPopup/<>c__DisplayClass54_0::.ctor 0x2ce2bf8
02ce2bf8: mov     x1, xzr                                    
02ce2bfc: b       #0x4e53e9c                                 System.Object::.ctor
## <GetMoney>b__0() -> void
---- LuckyWheelPopup/<>c__DisplayClass54_0::<GetMoney>b__0 0x2ce3f34
02ce3f34: str     x30, [sp, #-0x20]!                         
02ce3f38: stp     x20, x19, [sp, #0x10]                      
02ce3f3c: ldr     x20, [x0, #0x10]                           .<>4__this
02ce3f40: cbz     x20, #0x2ce3fc8                            
02ce3f44: mov     x19, x0                                    
02ce3f48: ldr     x0, [x20, #0x58]                           
02ce3f4c: strb    wzr, [x20, #0xf4]                          
02ce3f50: cbz     x0, #0x2ce3fc8                             
02ce3f54: mov     x1, xzr                                    
02ce3f58: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02ce3f5c: mov     x1, x0                                     
02ce3f60: mov     x0, x20                                    
02ce3f64: bl      #0x2ce2ca0                                 LuckyWheelPopup::StartButtonSpinAnim
02ce3f68: ldr     x0, [x19, #0x10]                           .<>4__this
02ce3f6c: cbz     x0, #0x2ce3fc8                             
02ce3f70: bl      #0x2ce2dbc                                 LuckyWheelPopup::ActiveButtonBack
02ce3f74: ldr     x8, [x19, #0x10]                           .<>4__this
02ce3f78: cbz     x8, #0x2ce3fc8                             
02ce3f7c: ldr     x0, [x8, #0x60]                            
02ce3f80: cbz     x0, #0x2ce3fc8                             
02ce3f84: mov     x1, xzr                                    
02ce3f88: bl      #0x5b339ec                                 UnityEngine.Component::get_gameObject
02ce3f8c: cbz     x0, #0x2ce3fc8                             
02ce3f90: mov     w1, wzr                                    
02ce3f94: mov     x2, xzr                                    
02ce3f98: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02ce3f9c: ldr     x8, [x19, #0x18]                           .onComplete
02ce3fa0: cbz     x8, #0x2ce3fbc                             
02ce3fa4: ldp     x20, x19, [sp, #0x10]                      
02ce3fa8: ldr     x0, [x8, #0x40]                            
02ce3fac: ldr     x1, [x8, #0x28]                            
02ce3fb0: ldr     x2, [x8, #0x18]                            
02ce3fb4: ldr     x30, [sp], #0x20                           
02ce3fb8: br      x2                                         
02ce3fbc: ldp     x20, x19, [sp, #0x10]                      
02ce3fc0: ldr     x30, [sp], #0x20                           
02ce3fc4: ret                                                
02ce3fc8: bl      #0x2b7105c                                 fn_2b7105c
## <GetMoney>b__1() -> void
---- LuckyWheelPopup/<>c__DisplayClass54_0::<GetMoney>b__1 0x2ce3fcc
02ce3fcc: stp     x30, x23, [sp, #-0x30]!                    
02ce3fd0: stp     x22, x21, [sp, #0x10]                      
02ce3fd4: stp     x20, x19, [sp, #0x20]                      
02ce3fd8: adrp    x20, #0x662f000                            
02ce3fdc: adrp    x21, #0x6268000                            
02ce3fe0: mov     x19, x0                                    
02ce3fe4: ldrb    w8, [x20, #0xdd3]                          
02ce3fe8: ldr     x21, [x21, #0xb0]                          S:'penguin_close_mouth'
02ce3fec: tbnz    w8, #0, #0x2ce4034                         
02ce3ff0: adrp    x0, #0x6264000                             
02ce3ff4: ldr     x0, [x0, #0xf90]                           T:System.Action
02ce3ff8: bl      #0x2b70db0                                 fn_2b70db0
02ce3ffc: adrp    x0, #0x6265000                             
02ce4000: ldr     x0, [x0, #0x310]                           MS:WejoyService.Singleton`1::get_Instance
02ce4004: bl      #0x2b70db0                                 fn_2b70db0
02ce4008: adrp    x0, #0x6266000                             
02ce400c: ldr     x0, [x0, #0x880]                           MS:DG.Tweening.TweenSettingsExtensions::SetEase
02ce4010: bl      #0x2b70db0                                 fn_2b70db0
02ce4014: adrp    x0, #0x6268000                             
02ce4018: ldr     x0, [x0, #0x158]                           M:LuckyWheelPopup/<>c__DisplayClass54_0::<GetMoney>b__2
02ce401c: bl      #0x2b70db0                                 fn_2b70db0
02ce4020: adrp    x0, #0x6268000                             
02ce4024: ldr     x0, [x0, #0xb0]                            S:'penguin_close_mouth'
02ce4028: bl      #0x2b70db0                                 fn_2b70db0
02ce402c: mov     w8, #1                                     
02ce4030: strb    w8, [x20, #0xdd3]                          
02ce4034: mov     x23, x19                                   
02ce4038: ldr     x21, [x21]                                 S:'{0}/2'
02ce403c: ldr     x22, [x23, #0x20]!                         
02ce4040: ldur    x20, [x23, #-0x10]                         
02ce4044: cbnz    x22, #0x2ce4084                            
02ce4048: adrp    x8, #0x6264000                             
02ce404c: ldr     x8, [x8, #0xf90]                           T:System.Action
02ce4050: ldr     x0, [x8]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02ce4054: bl      #0x2b7104c                                 fn_2b7104c
02ce4058: adrp    x8, #0x6268000                             
02ce405c: mov     x1, x19                                    
02ce4060: mov     x3, xzr                                    
02ce4064: ldr     x8, [x8, #0x158]                           M:LuckyWheelPopup/<>c__DisplayClass54_0::<GetMoney>b__2
02ce4068: mov     x22, x0                                    
02ce406c: ldr     x2, [x8]                                   S:'{0}/2'
02ce4070: bl      #0x4d8ddbc                                 System.Action::.ctor
02ce4074: mov     x0, x23                                    
02ce4078: mov     x1, x22                                    
02ce407c: str     x22, [x19, #0x20]                          .<>9__2
02ce4080: bl      #0x2b70d54                                 fn_2b70d54
02ce4084: cbz     x20, #0x2ce41e8                            
02ce4088: mov     x0, x20                                    
02ce408c: mov     x1, x21                                    
02ce4090: mov     w2, wzr                                    
02ce4094: mov     x3, x22                                    
02ce4098: bl      #0x2ce1b80                                 LuckyWheelPopup::PlayAnimation
02ce409c: ldr     x8, [x19, #0x10]                           .<>4__this
02ce40a0: cbz     x8, #0x2ce41e8                             
02ce40a4: ldr     x0, [x8, #0x90]                            M:LuckyWheelPopup/<>c__DisplayClass53_0::<GetRewardItem>b__2
02ce40a8: mov     w1, wzr                                    
02ce40ac: mov     x2, xzr                                    
02ce40b0: bl      #0x2d9d5d0                                 DG.Tweening.ShortcutExtensions::DOKill
02ce40b4: ldr     x8, [x19, #0x10]                           .<>4__this
02ce40b8: cbz     x8, #0x2ce41e8                             
02ce40bc: adrp    x21, #0x662f000                            
02ce40c0: ldr     x20, [x8, #0x90]                           M:LuckyWheelPopup/<>c__DisplayClass53_0::<GetRewardItem>b__2
02ce40c4: ldrb    w9, [x21, #0x91a]                          
02ce40c8: cbnz    w9, #0x2ce40e0                             
02ce40cc: adrp    x0, #0x6264000                             
02ce40d0: ldr     x0, [x0, #0xd8]                            T:UnityEngine.Vector3
02ce40d4: bl      #0x2b70db0                                 fn_2b70db0
02ce40d8: mov     w8, #1                                     
02ce40dc: strb    w8, [x21, #0x91a]                          
02ce40e0: cbz     x20, #0x2ce41e8                            
02ce40e4: adrp    x21, #0x6264000                            
02ce40e8: mov     x0, x20                                    
02ce40ec: mov     x1, xzr                                    
02ce40f0: ldr     x21, [x21, #0xd8]                          T:UnityEngine.Vector3
02ce40f4: ldr     x8, [x21]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02ce40f8: ldr     x8, [x8, #0xb8]                            T:LuckyWheelPopup/<>c__DisplayClass54_0
02ce40fc: ldp     s1, s2, [x8, #4]                           
02ce4100: ldr     s0, [x8]                                   S:'{0}/2'
02ce4104: bl      #0x5b470cc                                 UnityEngine.Transform::set_localScale
02ce4108: ldr     x8, [x19, #0x10]                           .<>4__this
02ce410c: cbz     x8, #0x2ce41e8                             
02ce4110: adrp    x23, #0x662f000                            
02ce4114: adrp    x22, #0x6266000                            
02ce4118: ldrb    w9, [x23, #0xa74]                          
02ce411c: ldr     x22, [x22, #0x880]                         MS:DG.Tweening.TweenSettingsExtensions::SetEase
02ce4120: ldr     x20, [x8, #0x90]                           M:LuckyWheelPopup/<>c__DisplayClass53_0::<GetRewardItem>b__2
02ce4124: cbnz    w9, #0x2ce413c                             
02ce4128: adrp    x0, #0x6264000                             
02ce412c: ldr     x0, [x0, #0xd8]                            T:UnityEngine.Vector3
02ce4130: bl      #0x2b70db0                                 fn_2b70db0
02ce4134: mov     w8, #1                                     
02ce4138: strb    w8, [x23, #0xa74]                          
02ce413c: ldr     x8, [x21]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02ce4140: mov     x0, x20                                    
02ce4144: mov     x1, xzr                                    
02ce4148: ldr     x8, [x8, #0xb8]                            T:LuckyWheelPopup/<>c__DisplayClass54_0
02ce414c: ldp     s0, s1, [x8, #0xc]                         
02ce4150: ldr     s2, [x8, #0x14]                            [6268014]=0 f=0,0
02ce4154: adrp    x8, #0x1084000                             
02ce4158: ldr     s3, [x8, #0xdd8]                           [1084dd8]=3f7333333e4ccccd f=0.2,0.95
02ce415c: bl      #0x2d98af8                                 DG.Tweening.ShortcutExtensions::DOScale
02ce4160: ldr     x2, [x22]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ce4164: mov     w1, #0x1b                                  
02ce4168: bl      #0x336fa0c                                 fn_336fa0c
02ce416c: ldr     x8, [x19, #0x10]                           .<>4__this
02ce4170: cbz     x8, #0x2ce41e8                             
02ce4174: ldr     x0, [x8, #0x60]                            [1084060]=6c6c417473616379 f=1.78571e+31,1.14246e+27
02ce4178: cbz     x0, #0x2ce41e8                             
02ce417c: mov     x1, xzr                                    
02ce4180: bl      #0x5b339ec                                 UnityEngine.Component::get_gameObject
02ce4184: cbz     x0, #0x2ce41e8                             
02ce4188: adrp    x19, #0x6265000                            
02ce418c: mov     w1, #1                                     
02ce4190: mov     x2, xzr                                    
02ce4194: ldr     x19, [x19, #0x310]                         MS:WejoyService.Singleton`1::get_Instance
02ce4198: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02ce419c: ldr     x0, [x19]                                  M:AdsManager::<OnApplicationPause>b__26_0
02ce41a0: bl      #0x3be7218                                 fn_3be7218
02ce41a4: cbz     x0, #0x2ce41e8                             
02ce41a8: mov     x1, xzr                                    
02ce41ac: bl      #0x2c8a7a4                                 AdsManager::ShowCollap
02ce41b0: mov     x0, xzr                                    
02ce41b4: bl      #0x2d6eec8                                 Framework.AudioManager::get_Instance
02ce41b8: cbz     x0, #0x2ce41e8                             
02ce41bc: ldp     x20, x19, [sp, #0x20]                      
02ce41c0: movi    d1, #0000000000000000                      
02ce41c4: ldp     x22, x21, [sp, #0x10]                      
02ce41c8: movi    d2, #0000000000000000                      
02ce41cc: fmov    s0, #1.00000000                            
02ce41d0: mov     w1, #0x32                                  
02ce41d4: mov     w2, wzr                                    
02ce41d8: mov     w3, wzr                                    
02ce41dc: mov     x4, xzr                                    
02ce41e0: ldp     x30, x23, [sp], #0x30                      
02ce41e4: b       #0x2d6f03c                                 Framework.AudioManager::PlaySound
02ce41e8: bl      #0x2b7105c                                 fn_2b7105c
## <GetMoney>b__2() -> void
---- LuckyWheelPopup/<>c__DisplayClass54_0::<GetMoney>b__2 0x2ce41ec
02ce41ec: str     x30, [sp, #-0x20]!                         
02ce41f0: stp     x20, x19, [sp, #0x10]                      
02ce41f4: adrp    x20, #0x662f000                            
02ce41f8: mov     x19, x0                                    
02ce41fc: ldrb    w8, [x20, #0xdd4]                          
02ce4200: tbnz    w8, #0, #0x2ce4218                         
02ce4204: adrp    x0, #0x6267000                             
02ce4208: ldr     x0, [x0, #0xfc0]                           S:'idle'
02ce420c: bl      #0x2b70db0                                 fn_2b70db0
02ce4210: mov     w8, #1                                     
02ce4214: strb    w8, [x20, #0xdd4]                          
02ce4218: ldr     x0, [x19, #0x10]                           .<>4__this
02ce421c: cbz     x0, #0x2ce4240                             
02ce4220: adrp    x8, #0x6267000                             
02ce4224: mov     w2, #1                                     
02ce4228: mov     x3, xzr                                    
02ce422c: ldr     x8, [x8, #0xfc0]                           S:'idle'
02ce4230: ldp     x20, x19, [sp, #0x10]                      
02ce4234: ldr     x1, [x8]                                   S:'didu'
02ce4238: ldr     x30, [sp], #0x20                           
02ce423c: b       #0x2ce1b80                                 LuckyWheelPopup::PlayAnimation
02ce4240: bl      #0x2b7105c                                 fn_2b7105c
#### CLASS LuckyWheelPopup/<>c__DisplayClass66_0 parent= object
#   field onComplete                     System.Action                                      off=0x10 attr=6 
## .ctor() -> void
---- LuckyWheelPopup/<>c__DisplayClass66_0::.ctor 0x2ce3488
02ce3488: mov     x1, xzr                                    
02ce348c: b       #0x4e53e9c                                 System.Object::.ctor
## <PlayAnimation>b__0() -> void
---- LuckyWheelPopup/<>c__DisplayClass66_0::<PlayAnimation>b__0 0x2ce4244
02ce4244: ldr     x8, [x0, #0x10]                            .onComplete
02ce4248: cbz     x8, #0x2ce425c                             
02ce424c: ldr     x0, [x8, #0x40]                            
02ce4250: ldr     x1, [x8, #0x28]                            
02ce4254: ldr     x2, [x8, #0x18]                            
02ce4258: br      x2                                         
02ce425c: str     x30, [sp, #-0x10]!                         
02ce4260: bl      #0x2b7105c                                 fn_2b7105c
#### CLASS LuckyWheelPopup/<OnShow>d__46 parent= System.ValueType
#   field <>1__state                     int                                                off=0x10 attr=6 
#   field <>t__builder                   System.Runtime.CompilerServices.AsyncVoidMethodBuilder off=0x18 attr=6 
#   field <>4__this                      LuckyWheelPopup                                    off=0x38 attr=6 
#   field <>u__1                         Cysharp.Threading.Tasks.UniTask/Awaiter            off=0x40 attr=1 
## MoveNext() -> void
---- LuckyWheelPopup/<OnShow>d__46::MoveNext 0x2ce4264
02ce4264: sub     sp, sp, #0x70                              
02ce4268: str     x30, [sp, #0x30]                           
02ce426c: stp     x24, x23, [sp, #0x40]                      
02ce4270: stp     x22, x21, [sp, #0x50]                      
02ce4274: stp     x20, x19, [sp, #0x60]                      
02ce4278: adrp    x20, #0x662f000                            
02ce427c: mov     x19, x0                                    
02ce4280: ldrb    w8, [x20, #0xdd5]                          
02ce4284: tbnz    w8, #0, #0x2ce42c0                         
02ce4288: adrp    x0, #0x6268000                             
02ce428c: ldr     x0, [x0, #0x160]                           MS:System.Runtime.CompilerServices.AsyncVoidMethodBuilder::AwaitUnsafeOnCompleted
02ce4290: bl      #0x2b70db0                                 fn_2b70db0
02ce4294: adrp    x0, #0x6266000                             
02ce4298: ldr     x0, [x0, #0xac0]                           MS:MonoSingleton`1::get_Instance
02ce429c: bl      #0x2b70db0                                 fn_2b70db0
02ce42a0: adrp    x0, #0x6266000                             
02ce42a4: ldr     x0, [x0, #0xaa0]                           MS:MonoSingleton`1::get_Instance
02ce42a8: bl      #0x2b70db0                                 fn_2b70db0
02ce42ac: adrp    x0, #0x6266000                             
02ce42b0: ldr     x0, [x0, #0xcc8]                           T:Cysharp.Threading.Tasks.UniTask
02ce42b4: bl      #0x2b70db0                                 fn_2b70db0
02ce42b8: mov     w8, #1                                     
02ce42bc: strb    w8, [x20, #0xdd5]                          
02ce42c0: ldr     w8, [x19]                                  
02ce42c4: ldr     x20, [x19, #0x28]                          
02ce42c8: stp     xzr, xzr, [sp, #0x10]                      
02ce42cc: str     wzr, [sp, #8]                              
02ce42d0: cbz     w8, #0x2ce4410                             
02ce42d4: cbz     x20, #0x2ce45c8                            
02ce42d8: ldr     x0, [x20, #0x28]                           [662f028]=6000015 f=2.40742e-35,0
02ce42dc: movi    d0, #0000000000000000                      
02ce42e0: mov     w1, #1                                     
02ce42e4: mov     x2, xzr                                    
02ce42e8: mov     w21, #1                                    
02ce42ec: bl      #0x2cf1928                                 FrameWorkUtility::SetActive
02ce42f0: adrp    x8, #0x6266000                             
02ce42f4: ldr     x8, [x8, #0xaa0]                           MS:MonoSingleton`1::get_Instance
02ce42f8: strb    w21, [x20, #0x20]                          
02ce42fc: ldr     x0, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ce4300: bl      #0x3769600                                 fn_3769600
02ce4304: mov     x21, x0                                    
02ce4308: mov     x0, x20                                    
02ce430c: mov     x1, xzr                                    
02ce4310: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02ce4314: mov     x1, x0                                     
02ce4318: cbz     x21, #0x2ce45cc                            
02ce431c: mov     x0, x21                                    
02ce4320: bl      #0x2cdac14                                 MoneyManager::SetCurrentParent
02ce4324: adrp    x8, #0x6266000                             
02ce4328: ldr     x8, [x8, #0xac0]                           MS:MonoSingleton`1::get_Instance
02ce432c: ldr     x0, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ce4330: bl      #0x3769600                                 fn_3769600
02ce4334: cbz     x0, #0x2ce45d0                             
02ce4338: mov     w1, wzr                                    
02ce433c: mov     x2, xzr                                    
02ce4340: bl      #0x2cacd8c                                 GameSession::SetActiveCharacter
02ce4344: mov     x0, x20                                    
02ce4348: bl      #0x2ce1e08                                 LuckyWheelPopup::CheckCounterSpin
02ce434c: ldr     x0, [x20, #0x58]                           [662f058]=6000018 f=2.40742e-35,0
02ce4350: cbz     x0, #0x2ce45d4                             
02ce4354: mov     x1, xzr                                    
02ce4358: bl      #0x5b339ec                                 UnityEngine.Component::get_gameObject
02ce435c: cbz     x0, #0x2ce45d8                             
02ce4360: mov     w1, wzr                                    
02ce4364: mov     x2, xzr                                    
02ce4368: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02ce436c: ldr     x0, [x20, #0x48]                           [662f048]=6000017 f=2.40742e-35,0
02ce4370: cbz     x0, #0x2ce45dc                             
02ce4374: mov     x1, xzr                                    
02ce4378: bl      #0x5b339ec                                 UnityEngine.Component::get_gameObject
02ce437c: cbz     x0, #0x2ce45e0                             
02ce4380: mov     w1, wzr                                    
02ce4384: mov     x2, xzr                                    
02ce4388: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02ce438c: mov     x0, x20                                    
02ce4390: bl      #0x2ce2c00                                 LuckyWheelPopup::ShowLuckyWheel
02ce4394: adrp    x23, #0x6266000                            
02ce4398: mov     x21, x0                                    
02ce439c: mov     x22, x1                                    
02ce43a0: ldr     x23, [x23, #0xcc8]                         T:Cysharp.Threading.Tasks.UniTask
02ce43a4: ldr     x0, [x23]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ce43a8: ldr     w8, [x0, #0xe4]                            [62660e4]=0 f=0,0
02ce43ac: cbnz    w8, #0x2ce43b4                             
02ce43b0: bl      #0x2b70f30                                 fn_2b70f30
02ce43b4: stp     x21, x22, [sp, #0x20]                      
02ce43b8: add     x0, sp, #0x20                              
02ce43bc: mov     x1, xzr                                    
02ce43c0: bl      #0x2b70d54                                 fn_2b70d54
02ce43c4: adrp    x24, #0x662f000                            
02ce43c8: ldp     x21, x22, [sp, #0x20]                      
02ce43cc: ldrb    w8, [x24, #0xbdc]                          
02ce43d0: stp     x21, x22, [sp, #0x10]                      
02ce43d4: cbnz    w8, #0x2ce43ec                             
02ce43d8: adrp    x0, #0x6266000                             
02ce43dc: ldr     x0, [x0, #0xcc8]                           T:Cysharp.Threading.Tasks.UniTask
02ce43e0: bl      #0x2b70db0                                 fn_2b70db0
02ce43e4: mov     w8, #1                                     
02ce43e8: strb    w8, [x24, #0xbdc]                          
02ce43ec: ldr     x0, [x23]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ce43f0: ldr     w8, [x0, #0xe4]                            [62660e4]=0 f=0,0
02ce43f4: cbnz    w8, #0x2ce43fc                             
02ce43f8: bl      #0x2b70f30                                 fn_2b70f30
02ce43fc: adrp    x23, #0x662f000                            
02ce4400: ldrb    w8, [x23, #0xbdd]                          
02ce4404: cbz     w8, #0x2ce4428                             
02ce4408: cbnz    x21, #0x2ce4440                            
02ce440c: b       #0x2ce44a8                                 
02ce4410: ldr     q0, [x19, #0x30]                           
02ce4414: mov     w8, #-1                                    
02ce4418: stp     xzr, xzr, [x19, #0x30]                     
02ce441c: str     w8, [x19]                                  
02ce4420: str     q0, [sp, #0x10]                            
02ce4424: b       #0x2ce44a8                                 
02ce4428: adrp    x0, #0x6266000                             
02ce442c: ldr     x0, [x0, #0xcd0]                           T:Cysharp.Threading.Tasks.IUniTaskSource
02ce4430: bl      #0x2b70db0                                 fn_2b70db0
02ce4434: mov     w8, #1                                     
02ce4438: strb    w8, [x23, #0xbdd]                          
02ce443c: cbz     x21, #0x2ce44a8                            
02ce4440: adrp    x10, #0x6266000                            
02ce4444: ldr     x8, [x21]                                  
02ce4448: ldr     x10, [x10, #0xcd0]                         T:Cysharp.Threading.Tasks.IUniTaskSource
02ce444c: ldrh    w9, [x8, #0x12e]                           
02ce4450: ldr     x1, [x10]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ce4454: cbz     x9, #0x2ce4478                             
02ce4458: ldr     x10, [x8, #0xb0]                           S:'native_banner_ad_on_off'
02ce445c: add     x10, x10, #8                               &6266008
02ce4460: ldur    x11, [x10, #-8]                            
02ce4464: cmp     x11, x1                                    
02ce4468: b.eq    #0x2ce4488                                 
02ce446c: subs    x9, x9, #1                                 
02ce4470: add     x10, x10, #0x10                            &6266010
02ce4474: b.ne    #0x2ce4460                                 
02ce4478: mov     x0, x21                                    
02ce447c: mov     w2, wzr                                    
02ce4480: bl      #0x2baa05c                                 fn_2baa05c
02ce4484: b       #0x2ce4494                                 
02ce4488: ldrsw   x9, [x10]                                  
02ce448c: add     x8, x8, x9, lsl #4                         &6266000
02ce4490: add     x0, x8, #0x138                             &6266138
02ce4494: ldp     x8, x2, [x0]                               
02ce4498: mov     x0, x21                                    
02ce449c: mov     w1, w22                                    
02ce44a0: blr     x8                                         
02ce44a4: cbz     w0, #0x2ce4588                             
02ce44a8: adrp    x21, #0x662f000                            
02ce44ac: ldrb    w8, [x21, #0xbde]                          
02ce44b0: cbnz    w8, #0x2ce44c8                             
02ce44b4: adrp    x0, #0x6266000                             
02ce44b8: ldr     x0, [x0, #0xcd0]                           T:Cysharp.Threading.Tasks.IUniTaskSource
02ce44bc: bl      #0x2b70db0                                 fn_2b70db0
02ce44c0: mov     w8, #1                                     
02ce44c4: strb    w8, [x21, #0xbde]                          
02ce44c8: ldr     x21, [sp, #0x10]                           
02ce44cc: cbz     x21, #0x2ce453c                            
02ce44d0: adrp    x10, #0x6266000                            
02ce44d4: ldr     x8, [x21]                                  &2b706c4(=eb01011ff9400808)
02ce44d8: ldr     x10, [x10, #0xcd0]                         T:Cysharp.Threading.Tasks.IUniTaskSource
02ce44dc: ldrh    w22, [sp, #0x18]                           
02ce44e0: ldrh    w9, [x8, #0x12e]                           
02ce44e4: ldr     x1, [x10]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ce44e8: cbz     x9, #0x2ce450c                             
02ce44ec: ldr     x10, [x8, #0xb0]                           S:'native_banner_ad_on_off'
02ce44f0: add     x10, x10, #8                               &6266008
02ce44f4: ldur    x11, [x10, #-8]                            
02ce44f8: cmp     x11, x1                                    
02ce44fc: b.eq    #0x2ce451c                                 
02ce4500: subs    x9, x9, #1                                 
02ce4504: add     x10, x10, #0x10                            &6266010
02ce4508: b.ne    #0x2ce44f4                                 
02ce450c: mov     x0, x21                                    
02ce4510: mov     w2, #2                                     
02ce4514: bl      #0x2baa05c                                 fn_2baa05c
02ce4518: b       #0x2ce452c                                 
02ce451c: ldr     w9, [x10]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ce4520: add     w9, w9, #2                                 
02ce4524: add     x8, x8, w9, sxtw #4                        &6266000
02ce4528: add     x0, x8, #0x138                             &6266138
02ce452c: ldp     x8, x2, [x0]                               
02ce4530: mov     x0, x21                                    
02ce4534: mov     w1, w22                                    
02ce4538: blr     x8                                         
02ce453c: cbz     x20, #0x2ce45c0                            
02ce4540: ldr     x0, [x20, #0x58]                           [662f058]=6000018 f=2.40742e-35,0
02ce4544: cbz     x0, #0x2ce45c4                             
02ce4548: mov     x1, xzr                                    
02ce454c: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02ce4550: mov     x1, x0                                     
02ce4554: mov     x0, x20                                    
02ce4558: bl      #0x2ce2ca0                                 LuckyWheelPopup::StartButtonSpinAnim
02ce455c: mov     w8, #-2                                    
02ce4560: mov     x1, xzr                                    
02ce4564: str     w8, [x19], #8                              
02ce4568: mov     x0, x19                                    
02ce456c: bl      #0x4d43b50                                 System.Runtime.CompilerServices.AsyncVoidMethodBuilder::SetResult
02ce4570: ldp     x20, x19, [sp, #0x60]                      
02ce4574: ldr     x30, [sp, #0x30]                           
02ce4578: ldp     x22, x21, [sp, #0x50]                      
02ce457c: ldp     x24, x23, [sp, #0x40]                      
02ce4580: add     sp, sp, #0x70                              
02ce4584: ret                                                
02ce4588: ldr     q0, [sp, #0x10]                            
02ce458c: str     wzr, [x19]                                 
02ce4590: str     q0, [x19, #0x30]                           
02ce4594: add     x0, x19, #0x30                             
02ce4598: mov     x1, xzr                                    
02ce459c: bl      #0x2b70d54                                 fn_2b70d54
02ce45a0: adrp    x8, #0x6268000                             
02ce45a4: ldr     x8, [x8, #0x160]                           MS:System.Runtime.CompilerServices.AsyncVoidMethodBuilder::AwaitUnsafeOnCompleted
02ce45a8: ldr     x3, [x8]                                   S:'{0}/2'
02ce45ac: add     x0, x19, #8                                
02ce45b0: add     x1, sp, #0x10                              
02ce45b4: mov     x2, x19                                    
02ce45b8: bl      #0x30c3e4c                                 fn_30c3e4c
02ce45bc: b       #0x2ce4570                                 
02ce45c0: bl      #0x2b7105c                                 fn_2b7105c
02ce45c4: bl      #0x2b7105c                                 fn_2b7105c
02ce45c8: bl      #0x2b7105c                                 fn_2b7105c
02ce45cc: bl      #0x2b7105c                                 fn_2b7105c
02ce45d0: bl      #0x2b7105c                                 fn_2b7105c
02ce45d4: bl      #0x2b7105c                                 fn_2b7105c
02ce45d8: bl      #0x2b7105c                                 fn_2b7105c
02ce45dc: bl      #0x2b7105c                                 fn_2b7105c
02ce45e0: bl      #0x2b7105c                                 fn_2b7105c
02ce45e4: b       #0x2ce4630                                 
02ce45e8: b       #0x2ce4630                                 
02ce45ec: b       #0x2ce4630                                 
02ce45f0: b       #0x2ce4630                                 
02ce45f4: b       #0x2ce4630                                 
02ce45f8: b       #0x2ce4630                                 
02ce45fc: b       #0x2ce4630                                 
02ce4600: b       #0x2ce4630                                 
02ce4604: b       #0x2ce4630                                 
02ce4608: b       #0x2ce4630                                 
02ce460c: b       #0x2ce4630                                 
02ce4610: b       #0x2ce4630                                 
02ce4614: b       #0x2ce4630                                 
02ce4618: b       #0x2ce4630                                 
02ce461c: b       #0x2ce4630                                 
02ce4620: b       #0x2ce4630                                 
02ce4624: b       #0x2ce4630                                 
02ce4628: b       #0x2ce4630                                 
02ce462c: b       #0x2ce4630                                 
02ce4630: mov     x20, x0                                    
02ce4634: cmp     w1, #1                                     
02ce4638: b.ne    #0x2ce46c8                                 
02ce463c: mov     x0, x20                                    
02ce4640: bl      #0x5e90260                                 fn_5e90260
02ce4644: mov     x20, x0                                    
02ce4648: adrp    x0, #0x6263000                             
02ce464c: ldr     x0, [x0, #0xae0]                           T:System.Exception
02ce4650: bl      #0x2b70dc4                                 fn_2b70dc4
02ce4654: ldr     x8, [x20]                                  &2b706c4(=eb01011ff9400808)
02ce4658: ldr     x1, [x8]                                   S:'{0}/2'
02ce465c: bl      #0x2b71464                                 fn_2b71464
02ce4660: tbz     w0, #0, #0x2ce46a0                         
02ce4664: ldrsw   x21, [sp, #8]                              
02ce4668: ldr     x20, [x20]                                 &2b706c4(=eb01011ff9400808)
02ce466c: mov     x8, sp                                     
02ce4670: str     x20, [x8, x21, lsl #3]                     
02ce4674: add     w8, w21, #1                                
02ce4678: str     w8, [sp, #8]                               
02ce467c: bl      #0x5e90270                                 fn_5e90270
02ce4680: mov     w8, #-2                                    
02ce4684: mov     x1, x20                                    
02ce4688: mov     x2, xzr                                    
02ce468c: str     w8, [x19], #8                              
02ce4690: mov     x0, x19                                    
02ce4694: bl      #0x4d43cc0                                 System.Runtime.CompilerServices.AsyncVoidMethodBuilder::SetException
02ce4698: str     w21, [sp, #8]                              
02ce469c: b       #0x2ce4570                                 
02ce46a0: mov     w0, #8                                     
02ce46a4: bl      #0x5e90290                                 fn_5e90290
02ce46a8: ldr     x8, [x20]                                  &2b706c4(=eb01011ff9400808)
02ce46ac: str     x8, [x0]                                   
02ce46b0: adrp    x1, #0x5e96000                             
02ce46b4: add     x1, x1, #0x758                             &5e96758
02ce46b8: mov     x2, xzr                                    
02ce46bc: bl      #0x5e902a0                                 fn_5e902a0
02ce46c0: mov     x20, x0                                    
02ce46c4: bl      #0x5e90270                                 fn_5e90270
02ce46c8: mov     x0, x20                                    
02ce46cc: bl      #0x2c6051c                                 fn_2c6051c
02ce46d0: bl      #0x27369b8                                 fn_27369b8
## SetStateMachine(System.Runtime.CompilerServices.IAsyncStateMachine stateMachine) -> void
---- LuckyWheelPopup/<OnShow>d__46::SetStateMachine 0x2ce46d4
02ce46d4: add     x0, x0, #8                                 
02ce46d8: mov     x2, xzr                                    
02ce46dc: b       #0x4d43a8c                                 System.Runtime.CompilerServices.AsyncVoidMethodBuilder::SetStateMachine
#### CLASS LuckyWheelPopup/<ShowLuckyWheel>d__55 parent= System.ValueType
#   field <>1__state                     int                                                off=0x10 attr=6 
#   field <>t__builder                   Cysharp.Threading.Tasks.CompilerServices.AsyncUniTaskMethodBuilder off=0x18 attr=6 
#   field <>4__this                      LuckyWheelPopup                                    off=0x28 attr=6 
#   field <>u__1                         Cysharp.Threading.Tasks.UniTask/Awaiter            off=0x30 attr=1 
## MoveNext() -> void
---- LuckyWheelPopup/<ShowLuckyWheel>d__55::MoveNext 0x2ce46e0
02ce46e0: sub     sp, sp, #0x70                              
02ce46e4: str     x30, [sp, #0x30]                           
02ce46e8: stp     x24, x23, [sp, #0x40]                      
02ce46ec: stp     x22, x21, [sp, #0x50]                      
02ce46f0: stp     x20, x19, [sp, #0x60]                      
02ce46f4: adrp    x20, #0x662f000                            
02ce46f8: mov     x19, x0                                    
02ce46fc: ldrb    w8, [x20, #0xdd6]                          
02ce4700: tbnz    w8, #0, #0x2ce4724                         
02ce4704: adrp    x0, #0x6268000                             
02ce4708: ldr     x0, [x0, #0x168]                           MS:Cysharp.Threading.Tasks.CompilerServices.AsyncUniTaskMethodBuilder::AwaitUnsafeOnCompleted
02ce470c: bl      #0x2b70db0                                 fn_2b70db0
02ce4710: adrp    x0, #0x6266000                             
02ce4714: ldr     x0, [x0, #0xcc8]                           T:Cysharp.Threading.Tasks.UniTask
02ce4718: bl      #0x2b70db0                                 fn_2b70db0
02ce471c: mov     w8, #1                                     
02ce4720: strb    w8, [x20, #0xdd6]                          
02ce4724: ldr     w8, [x19]                                  
02ce4728: ldr     x22, [x19, #0x18]                          .<>t__builder
02ce472c: stp     xzr, xzr, [sp, #0x10]                      
02ce4730: str     wzr, [sp, #8]                              
02ce4734: cbz     w8, #0x2ce4814                             
02ce4738: cbz     x22, #0x2ce4a90                            
02ce473c: ldr     x0, [x22, #0x80]                           
02ce4740: cbz     x0, #0x2ce4a94                             
02ce4744: mov     x1, xzr                                    
02ce4748: bl      #0x5b368f0                                 UnityEngine.GameObject::get_transform
02ce474c: mov     w1, wzr                                    
02ce4750: mov     x2, xzr                                    
02ce4754: bl      #0x2d9d5d0                                 DG.Tweening.ShortcutExtensions::DOKill
02ce4758: ldr     x0, [x22, #0x80]                           
02ce475c: cbz     x0, #0x2ce4a98                             
02ce4760: mov     x1, xzr                                    
02ce4764: bl      #0x5b368f0                                 UnityEngine.GameObject::get_transform
02ce4768: movi    d0, #0000000000000000                      
02ce476c: movi    d1, #0000000000000000                      
02ce4770: mov     w8, #0x43b40000                            
02ce4774: fmov    s3, #2.00000000                            
02ce4778: fmov    s2, w8                                     
02ce477c: mov     w1, #1                                     
02ce4780: mov     x2, xzr                                    
02ce4784: bl      #0x2d983c8                                 DG.Tweening.ShortcutExtensions::DORotate
02ce4788: mov     w1, wzr                                    
02ce478c: mov     x2, xzr                                    
02ce4790: mov     x3, xzr                                    
02ce4794: bl      #0x545d870                                 Cysharp.Threading.Tasks.DOTweenAsyncExtensions::ToUniTask
02ce4798: adrp    x23, #0x6266000                            
02ce479c: mov     x20, x0                                    
02ce47a0: mov     x21, x1                                    
02ce47a4: ldr     x23, [x23, #0xcc8]                         T:Cysharp.Threading.Tasks.UniTask
02ce47a8: ldr     x0, [x23]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ce47ac: ldr     w8, [x0, #0xe4]                            [62660e4]=0 f=0,0
02ce47b0: cbnz    w8, #0x2ce47b8                             
02ce47b4: bl      #0x2b70f30                                 fn_2b70f30
02ce47b8: stp     x20, x21, [sp, #0x20]                      
02ce47bc: add     x0, sp, #0x20                              
02ce47c0: mov     x1, xzr                                    
02ce47c4: bl      #0x2b70d54                                 fn_2b70d54
02ce47c8: adrp    x24, #0x662f000                            
02ce47cc: ldp     x20, x21, [sp, #0x20]                      
02ce47d0: ldrb    w8, [x24, #0xbdc]                          
02ce47d4: stp     x20, x21, [sp, #0x10]                      
02ce47d8: cbnz    w8, #0x2ce47f0                             
02ce47dc: adrp    x0, #0x6266000                             
02ce47e0: ldr     x0, [x0, #0xcc8]                           T:Cysharp.Threading.Tasks.UniTask
02ce47e4: bl      #0x2b70db0                                 fn_2b70db0
02ce47e8: mov     w8, #1                                     
02ce47ec: strb    w8, [x24, #0xbdc]                          
02ce47f0: ldr     x0, [x23]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ce47f4: ldr     w8, [x0, #0xe4]                            [62660e4]=0 f=0,0
02ce47f8: cbnz    w8, #0x2ce4800                             
02ce47fc: bl      #0x2b70f30                                 fn_2b70f30
02ce4800: adrp    x23, #0x662f000                            
02ce4804: ldrb    w8, [x23, #0xbdd]                          
02ce4808: cbz     w8, #0x2ce482c                             
02ce480c: cbnz    x20, #0x2ce4844                            
02ce4810: b       #0x2ce48ac                                 
02ce4814: ldr     q0, [x19, #0x20]                           
02ce4818: mov     w8, #-1                                    
02ce481c: stp     xzr, xzr, [x19, #0x20]                     
02ce4820: str     w8, [x19]                                  
02ce4824: str     q0, [sp, #0x10]                            
02ce4828: b       #0x2ce48ac                                 
02ce482c: adrp    x0, #0x6266000                             
02ce4830: ldr     x0, [x0, #0xcd0]                           T:Cysharp.Threading.Tasks.IUniTaskSource
02ce4834: bl      #0x2b70db0                                 fn_2b70db0
02ce4838: mov     w8, #1                                     
02ce483c: strb    w8, [x23, #0xbdd]                          
02ce4840: cbz     x20, #0x2ce48ac                            
02ce4844: adrp    x10, #0x6266000                            
02ce4848: ldr     x8, [x20]                                  &2b706c4(=eb01011ff9400808)
02ce484c: ldr     x10, [x10, #0xcd0]                         T:Cysharp.Threading.Tasks.IUniTaskSource
02ce4850: ldrh    w9, [x8, #0x12e]                           
02ce4854: ldr     x1, [x10]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ce4858: cbz     x9, #0x2ce487c                             
02ce485c: ldr     x10, [x8, #0xb0]                           
02ce4860: add     x10, x10, #8                               &6266008
02ce4864: ldur    x11, [x10, #-8]                            
02ce4868: cmp     x11, x1                                    
02ce486c: b.eq    #0x2ce488c                                 
02ce4870: subs    x9, x9, #1                                 
02ce4874: add     x10, x10, #0x10                            &6266010
02ce4878: b.ne    #0x2ce4864                                 
02ce487c: mov     x0, x20                                    
02ce4880: mov     w2, wzr                                    
02ce4884: bl      #0x2baa05c                                 fn_2baa05c
02ce4888: b       #0x2ce4898                                 
02ce488c: ldrsw   x9, [x10]                                  
02ce4890: add     x8, x8, x9, lsl #4                         
02ce4894: add     x0, x8, #0x138                             
02ce4898: ldp     x8, x2, [x0]                               
02ce489c: mov     x0, x20                                    
02ce48a0: mov     w1, w21                                    
02ce48a4: blr     x8                                         
02ce48a8: cbz     w0, #0x2ce4a38                             
02ce48ac: adrp    x20, #0x662f000                            
02ce48b0: ldrb    w8, [x20, #0xbde]                          
02ce48b4: cbnz    w8, #0x2ce48cc                             
02ce48b8: adrp    x0, #0x6266000                             
02ce48bc: ldr     x0, [x0, #0xcd0]                           T:Cysharp.Threading.Tasks.IUniTaskSource
02ce48c0: bl      #0x2b70db0                                 fn_2b70db0
02ce48c4: mov     w8, #1                                     
02ce48c8: strb    w8, [x20, #0xbde]                          
02ce48cc: ldr     x20, [sp, #0x10]                           
02ce48d0: cbz     x20, #0x2ce4940                            
02ce48d4: adrp    x10, #0x6266000                            
02ce48d8: ldr     x8, [x20]                                  &2b706c4(=eb01011ff9400808)
02ce48dc: ldr     x10, [x10, #0xcd0]                         T:Cysharp.Threading.Tasks.IUniTaskSource
02ce48e0: ldrh    w21, [sp, #0x18]                           
02ce48e4: ldrh    w9, [x8, #0x12e]                           
02ce48e8: ldr     x1, [x10]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ce48ec: cbz     x9, #0x2ce4910                             
02ce48f0: ldr     x10, [x8, #0xb0]                           
02ce48f4: add     x10, x10, #8                               &6266008
02ce48f8: ldur    x11, [x10, #-8]                            
02ce48fc: cmp     x11, x1                                    
02ce4900: b.eq    #0x2ce4920                                 
02ce4904: subs    x9, x9, #1                                 
02ce4908: add     x10, x10, #0x10                            &6266010
02ce490c: b.ne    #0x2ce48f8                                 
02ce4910: mov     x0, x20                                    
02ce4914: mov     w2, #2                                     
02ce4918: bl      #0x2baa05c                                 fn_2baa05c
02ce491c: b       #0x2ce4930                                 
02ce4920: ldr     w9, [x10]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ce4924: add     w9, w9, #2                                 
02ce4928: add     x8, x8, w9, sxtw #4                        
02ce492c: add     x0, x8, #0x138                             
02ce4930: ldp     x8, x2, [x0]                               
02ce4934: mov     x0, x20                                    
02ce4938: mov     w1, w21                                    
02ce493c: blr     x8                                         
02ce4940: cbz     x22, #0x2ce4a84                            
02ce4944: ldr     x0, [x22, #0x80]                           
02ce4948: cbz     x0, #0x2ce4a88                             
02ce494c: mov     x1, xzr                                    
02ce4950: bl      #0x5b368f0                                 UnityEngine.GameObject::get_transform
02ce4954: adrp    x21, #0x662f000                            
02ce4958: mov     x20, x0                                    
02ce495c: ldrb    w8, [x21, #0x91a]                          
02ce4960: cbnz    w8, #0x2ce4978                             
02ce4964: adrp    x0, #0x6264000                             
02ce4968: ldr     x0, [x0, #0xd8]                            T:UnityEngine.Vector3
02ce496c: bl      #0x2b70db0                                 fn_2b70db0
02ce4970: mov     w8, #1                                     
02ce4974: strb    w8, [x21, #0x91a]                          
02ce4978: cbz     x20, #0x2ce4a8c                            
02ce497c: adrp    x8, #0x6264000                             
02ce4980: ldr     x8, [x8, #0xd8]                            T:UnityEngine.Vector3
02ce4984: ldr     x8, [x8]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02ce4988: ldr     x8, [x8, #0xb8]                            MS:DG.Tweening.Core.Extensions::SetSpecialStartupMode
02ce498c: ldp     s1, s2, [x8, #4]                           
02ce4990: ldr     s0, [x8]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02ce4994: mov     x0, x20                                    
02ce4998: mov     x1, xzr                                    
02ce499c: bl      #0x5b46ac4                                 UnityEngine.Transform::set_eulerAngles
02ce49a0: adrp    x20, #0x662f000                            
02ce49a4: mov     w9, #-2                                    
02ce49a8: ldrb    w8, [x20, #0xe25]                          
02ce49ac: str     w9, [x19]                                  
02ce49b0: cbnz    w8, #0x2ce49c8                             
02ce49b4: adrp    x0, #0x6268000                             
02ce49b8: ldr     x0, [x0, #0xd8]                            T:Cysharp.Threading.Tasks.CompilerServices.IStateMachineRunnerPromise
02ce49bc: bl      #0x2b70db0                                 fn_2b70db0
02ce49c0: mov     w8, #1                                     
02ce49c4: strb    w8, [x20, #0xe25]                          
02ce49c8: ldr     x19, [x19, #8]                             
02ce49cc: cbz     x19, #0x2ce4a6c                            
02ce49d0: adrp    x10, #0x6268000                            
02ce49d4: ldr     x8, [x19]                                  
02ce49d8: ldr     x10, [x10, #0xd8]                          T:Cysharp.Threading.Tasks.CompilerServices.IStateMachineRunnerPromise
02ce49dc: ldrh    w9, [x8, #0x12e]                           
02ce49e0: ldr     x1, [x10]                                  S:'{0}/2'
02ce49e4: cbz     x9, #0x2ce4a08                             
02ce49e8: ldr     x10, [x8, #0xb0]                           T:DG.Tweening.DOTweenModulePhysics/<>c__DisplayClass5_0
02ce49ec: add     x10, x10, #8                               &6268008
02ce49f0: ldur    x11, [x10, #-8]                            
02ce49f4: cmp     x11, x1                                    
02ce49f8: b.eq    #0x2ce4a18                                 
02ce49fc: subs    x9, x9, #1                                 
02ce4a00: add     x10, x10, #0x10                            &6268010
02ce4a04: b.ne    #0x2ce49f0                                 
02ce4a08: mov     x0, x19                                    
02ce4a0c: mov     w2, #2                                     
02ce4a10: bl      #0x2baa05c                                 fn_2baa05c
02ce4a14: b       #0x2ce4a28                                 
02ce4a18: ldr     w9, [x10]                                  S:'{0}/2'
02ce4a1c: add     w9, w9, #2                                 
02ce4a20: add     x8, x8, w9, sxtw #4                        &6264000
02ce4a24: add     x0, x8, #0x138                             &6264138
02ce4a28: ldp     x8, x1, [x0]                               
02ce4a2c: mov     x0, x19                                    
02ce4a30: blr     x8                                         
02ce4a34: b       #0x2ce4a6c                                 
02ce4a38: ldr     q0, [sp, #0x10]                            
02ce4a3c: str     wzr, [x19]                                 
02ce4a40: str     q0, [x19, #0x20]                           
02ce4a44: add     x0, x19, #0x20                             
02ce4a48: mov     x1, xzr                                    
02ce4a4c: bl      #0x2b70d54                                 fn_2b70d54
02ce4a50: adrp    x8, #0x6268000                             
02ce4a54: ldr     x8, [x8, #0x168]                           MS:Cysharp.Threading.Tasks.CompilerServices.AsyncUniTaskMethodBuilder::AwaitUnsafeOnCompleted
02ce4a58: ldr     x3, [x8]                                   S:'{0}/2'
02ce4a5c: add     x0, x19, #8                                
02ce4a60: add     x1, sp, #0x10                              
02ce4a64: mov     x2, x19                                    
02ce4a68: bl      #0x2ceaf68                                 fn_2ceaf68
02ce4a6c: ldp     x20, x19, [sp, #0x60]                      
02ce4a70: ldr     x30, [sp, #0x30]                           
02ce4a74: ldp     x22, x21, [sp, #0x50]                      
02ce4a78: ldp     x24, x23, [sp, #0x40]                      
02ce4a7c: add     sp, sp, #0x70                              
02ce4a80: ret                                                
02ce4a84: bl      #0x2b7105c                                 fn_2b7105c
02ce4a88: bl      #0x2b7105c                                 fn_2b7105c
02ce4a8c: bl      #0x2b7105c                                 fn_2b7105c
02ce4a90: bl      #0x2b7105c                                 fn_2b7105c
02ce4a94: bl      #0x2b7105c                                 fn_2b7105c
02ce4a98: bl      #0x2b7105c                                 fn_2b7105c
02ce4a9c: b       #0x2ce4ae4                                 
02ce4aa0: b       #0x2ce4ae4                                 
02ce4aa4: b       #0x2ce4ae4                                 
02ce4aa8: b       #0x2ce4ae4                                 
02ce4aac: b       #0x2ce4ae4                                 
02ce4ab0: b       #0x2ce4ae4                                 
02ce4ab4: b       #0x2ce4ae4                                 
02ce4ab8: b       #0x2ce4ae4                                 
02ce4abc: b       #0x2ce4ae4                                 
02ce4ac0: b       #0x2ce4ae4                                 
02ce4ac4: b       #0x2ce4ae4                                 
02ce4ac8: b       #0x2ce4ae4                                 
02ce4acc: b       #0x2ce4ae4                                 
02ce4ad0: b       #0x2ce4ae4                                 
02ce4ad4: b       #0x2ce4ae4                                 
02ce4ad8: b       #0x2ce4ae4                                 
02ce4adc: b       #0x2ce4ae4                                 
02ce4ae0: b       #0x2ce4ae4                                 
02ce4ae4: mov     x20, x0                                    
02ce4ae8: cmp     w1, #1                                     
02ce4aec: b.ne    #0x2ce4b7c                                 
02ce4af0: mov     x0, x20                                    
02ce4af4: bl      #0x5e90260                                 fn_5e90260
02ce4af8: mov     x20, x0                                    
02ce4afc: adrp    x0, #0x6263000                             
02ce4b00: ldr     x0, [x0, #0xae0]                           T:System.Exception
02ce4b04: bl      #0x2b70dc4                                 fn_2b70dc4
02ce4b08: ldr     x8, [x20]                                  &2b706c4(=eb01011ff9400808)
02ce4b0c: ldr     x1, [x8]                                   S:'{0}/2'
02ce4b10: bl      #0x2b71464                                 fn_2b71464
02ce4b14: tbz     w0, #0, #0x2ce4b54                         
02ce4b18: ldrsw   x21, [sp, #8]                              
02ce4b1c: ldr     x20, [x20]                                 &2b706c4(=eb01011ff9400808)
02ce4b20: mov     x8, sp                                     
02ce4b24: str     x20, [x8, x21, lsl #3]                     
02ce4b28: add     w8, w21, #1                                
02ce4b2c: str     w8, [sp, #8]                               
02ce4b30: bl      #0x5e90270                                 fn_5e90270
02ce4b34: mov     w8, #-2                                    
02ce4b38: mov     x1, x20                                    
02ce4b3c: mov     x2, xzr                                    
02ce4b40: str     w8, [x19], #8                              
02ce4b44: mov     x0, x19                                    
02ce4b48: bl      #0x2ceaea8                                 fn_2ceaea8
02ce4b4c: str     w21, [sp, #8]                              
02ce4b50: b       #0x2ce4a6c                                 
02ce4b54: mov     w0, #8                                     
02ce4b58: bl      #0x5e90290                                 fn_5e90290
02ce4b5c: ldr     x8, [x20]                                  &2b706c4(=eb01011ff9400808)
02ce4b60: str     x8, [x0]                                   
02ce4b64: adrp    x1, #0x5e96000                             
02ce4b68: add     x1, x1, #0x758                             &5e96758
02ce4b6c: mov     x2, xzr                                    
02ce4b70: bl      #0x5e902a0                                 fn_5e902a0
02ce4b74: mov     x20, x0                                    
02ce4b78: bl      #0x5e90270                                 fn_5e90270
02ce4b7c: mov     x0, x20                                    
02ce4b80: bl      #0x2c6051c                                 fn_2c6051c
02ce4b84: bl      #0x27369b8                                 fn_27369b8
## SetStateMachine(System.Runtime.CompilerServices.IAsyncStateMachine stateMachine) -> void
---- LuckyWheelPopup/<ShowLuckyWheel>d__55::SetStateMachine 0x2ce4b88
02ce4b88: add     x0, x0, #8                                 
02ce4b8c: mov     x2, xzr                                    
02ce4b90: b       #0x545f130                                 Cysharp.Threading.Tasks.CompilerServices.AsyncUniTaskMethodBuilder::SetStateMachine
#### CLASS LuckyWheelPopup/<SpinAnimation>d__51 parent= object
#   field <>1__state                     int                                                off=0x10 attr=1 
#   field <>2__current                   object                                             off=0x18 attr=1 
#   field resultID                       string                                             off=0x20 attr=6 
#   field <>4__this                      LuckyWheelPopup                                    off=0x28 attr=6 
#   field animationCompleted             UnityEngine.Events.UnityAction                     off=0x30 attr=6 
#   field <targetRotationValue>5__2      float                                              off=0x38 attr=1 
#   field <spinAmount>5__3               float                                              off=0x3c attr=1 
#   field <elapsedTime>5__4              float                                              off=0x40 attr=1 
#   field <startRotation>5__5            float                                              off=0x44 attr=1 
#   field <totalRotation>5__6            float                                              off=0x48 attr=1 
#   field <decelerationElapsedTime>5__7  float                                              off=0x4c attr=1 
## .ctor(int <>1__state) -> void
---- LuckyWheelPopup/<SpinAnimation>d__51::.ctor 0x2ce2274
02ce2274: str     x30, [sp, #-0x20]!                         
02ce2278: stp     x20, x19, [sp, #0x10]                      
02ce227c: mov     w19, w1                                    
02ce2280: mov     x1, xzr                                    
02ce2284: mov     x20, x0                                    
02ce2288: bl      #0x4e53e9c                                 System.Object::.ctor
02ce228c: str     w19, [x20, #0x10]                          .<>1__state
02ce2290: ldp     x20, x19, [sp, #0x10]                      
02ce2294: ldr     x30, [sp], #0x20                           
02ce2298: ret                                                
## System.IDisposable.Dispose() -> void
---- LuckyWheelPopup/<SpinAnimation>d__51::System.IDisposable.Dispose 0x2ce4b94
02ce4b94: ret                                                
## MoveNext() -> bool
---- LuckyWheelPopup/<SpinAnimation>d__51::MoveNext 0x2ce4b98
02ce4b98: str     d10, [sp, #-0x50]!                         
02ce4b9c: stp     d9, d8, [sp, #0x10]                        
02ce4ba0: stp     x30, x23, [sp, #0x20]                      
02ce4ba4: stp     x22, x21, [sp, #0x30]                      
02ce4ba8: stp     x20, x19, [sp, #0x40]                      
02ce4bac: adrp    x20, #0x662f000                            
02ce4bb0: mov     x19, x0                                    
02ce4bb4: ldrb    w8, [x20, #0xdd7]                          
02ce4bb8: tbnz    w8, #0, #0x2ce4c00                         
02ce4bbc: adrp    x0, #0x6268000                             
02ce4bc0: ldr     x0, [x0, #0x170]                           MS:System.Linq.Enumerable::FirstOrDefault
02ce4bc4: bl      #0x2b70db0                                 fn_2b70db0
02ce4bc8: adrp    x0, #0x6268000                             
02ce4bcc: ldr     x0, [x0, #0x178]                           T:type55588(k15)
02ce4bd0: bl      #0x2b70db0                                 fn_2b70db0
02ce4bd4: adrp    x0, #0x6263000                             
02ce4bd8: ldr     x0, [x0, #0x918]                           T:UnityEngine.Object
02ce4bdc: bl      #0x2b70db0                                 fn_2b70db0
02ce4be0: adrp    x0, #0x6268000                             
02ce4be4: ldr     x0, [x0, #0x180]                           M:LuckyWheelPopup/<>c__DisplayClass51_0::<SpinAnimation>b__0
02ce4be8: bl      #0x2b70db0                                 fn_2b70db0
02ce4bec: adrp    x0, #0x6268000                             
02ce4bf0: ldr     x0, [x0, #0x188]                           T:LuckyWheelPopup/<>c__DisplayClass51_0
02ce4bf4: bl      #0x2b70db0                                 fn_2b70db0
02ce4bf8: mov     w8, #1                                     
02ce4bfc: strb    w8, [x20, #0xdd7]                          
02ce4c00: ldr     w8, [x19, #0x10]                           .<>1__state
02ce4c04: ldr     x23, [x19, #0x28]                          .<>4__this
02ce4c08: cmp     w8, #2                                     
02ce4c0c: b.eq    #0x2ce4db4                                 
02ce4c10: cmp     w8, #1                                     
02ce4c14: b.eq    #0x2ce4cec                                 
02ce4c18: cbnz    w8, #0x2ce4ee8                             
02ce4c1c: adrp    x8, #0x6268000                             
02ce4c20: mov     w9, #-1                                    
02ce4c24: ldr     x8, [x8, #0x188]                           T:LuckyWheelPopup/<>c__DisplayClass51_0
02ce4c28: str     w9, [x19, #0x10]                           .<>1__state
02ce4c2c: ldr     x0, [x8]                                   S:'{0}/2'
02ce4c30: bl      #0x2b7104c                                 fn_2b7104c
02ce4c34: mov     x1, xzr                                    
02ce4c38: mov     x20, x0                                    
02ce4c3c: bl      #0x4e53e9c                                 System.Object::.ctor
02ce4c40: cbz     x20, #0x2ce4f04                            
02ce4c44: ldr     x1, [x19, #0x20]                           .resultID
02ce4c48: mov     x0, x20                                    
02ce4c4c: str     x1, [x0, #0x10]!                           .<>1__state
02ce4c50: bl      #0x2b70d54                                 fn_2b70d54
02ce4c54: cbz     x23, #0x2ce4f04                            
02ce4c58: adrp    x8, #0x6268000                             
02ce4c5c: ldr     x8, [x8, #0x178]                           T:type55588(k15)
02ce4c60: ldr     x21, [x23, #0xb0]                          
02ce4c64: ldr     x0, [x8]                                   S:'{0}/2'
02ce4c68: bl      #0x2b7104c                                 fn_2b7104c
02ce4c6c: adrp    x8, #0x6268000                             
02ce4c70: mov     x1, x20                                    
02ce4c74: mov     x3, xzr                                    
02ce4c78: ldr     x8, [x8, #0x180]                           M:LuckyWheelPopup/<>c__DisplayClass51_0::<SpinAnimation>b__0
02ce4c7c: mov     x22, x0                                    
02ce4c80: ldr     x2, [x8]                                   S:'{0}/2'
02ce4c84: bl      #0x4940cf8                                 fn_4940cf8
02ce4c88: adrp    x8, #0x6268000                             
02ce4c8c: mov     x0, x21                                    
02ce4c90: mov     x1, x22                                    
02ce4c94: ldr     x8, [x8, #0x170]                           MS:System.Linq.Enumerable::FirstOrDefault
02ce4c98: ldr     x2, [x8]                                   S:'{0}/2'
02ce4c9c: bl      #0x318c658                                 fn_318c658
02ce4ca0: adrp    x8, #0x6263000                             
02ce4ca4: mov     x20, x0                                    
02ce4ca8: ldr     x8, [x8, #0x918]                           T:UnityEngine.Object
02ce4cac: ldr     x8, [x8]                                   &2c5bbd4(=a9bd7bfdd503233f)
02ce4cb0: ldr     w9, [x8, #0xe4]                            [62630e4]=0 f=0,0
02ce4cb4: cbnz    w9, #0x2ce4cc0                             
02ce4cb8: mov     x0, x8                                     
02ce4cbc: bl      #0x2b70f30                                 fn_2b70f30
02ce4cc0: mov     x0, x20                                    
02ce4cc4: mov     x1, xzr                                    
02ce4cc8: mov     x2, xzr                                    
02ce4ccc: bl      #0x5b37d84                                 UnityEngine.Object::op_Equality
02ce4cd0: tbnz    w0, #0, #0x2ce4ee8                         
02ce4cd4: cbz     x20, #0x2ce4f04                            
02ce4cd8: ldr     s1, [x20, #0x28]                           [662f028]=6000015 f=2.40742e-35,0 .<>4__this
02ce4cdc: movi    d0, #0000000000000000                      
02ce4ce0: stp     wzr, wzr, [x19, #0x3c]                     .<spinAmount>5__3
02ce4ce4: str     s1, [x19, #0x38]                           .<targetRotationValue>5__2
02ce4ce8: b       #0x2ce4cfc                                 
02ce4cec: mov     w8, #-1                                    
02ce4cf0: str     w8, [x19, #0x10]                           .<>1__state
02ce4cf4: cbz     x23, #0x2ce4f04                            
02ce4cf8: ldr     s0, [x19, #0x40]                           .<elapsedTime>5__4
02ce4cfc: ldr     s1, [x23, #0x38]                           
02ce4d00: fcmp    s0, s1                                     
02ce4d04: b.pl    #0x2ce4dc8                                 
02ce4d08: ldr     s8, [x19, #0x3c]                           .<spinAmount>5__3
02ce4d0c: ldr     s9, [x23, #0x40]                           
02ce4d10: mov     x0, xzr                                    
02ce4d14: bl      #0x5b433a4                                 UnityEngine.Time::get_deltaTime
02ce4d18: fmul    s0, s9, s0                                 
02ce4d1c: ldr     x0, [x23, #0x80]                           
02ce4d20: fadd    s0, s8, s0                                 
02ce4d24: str     s0, [x19, #0x3c]                           .<spinAmount>5__3
02ce4d28: cbz     x0, #0x2ce4f04                             
02ce4d2c: mov     x1, xzr                                    
02ce4d30: bl      #0x5b368f0                                 UnityEngine.GameObject::get_transform
02ce4d34: adrp    x21, #0x662f000                            
02ce4d38: mov     x20, x0                                    
02ce4d3c: ldrb    w8, [x21, #0x91c]                          
02ce4d40: cbnz    w8, #0x2ce4d58                             
02ce4d44: adrp    x0, #0x6264000                             
02ce4d48: ldr     x0, [x0, #0xd8]                            T:UnityEngine.Vector3
02ce4d4c: bl      #0x2b70db0                                 fn_2b70db0
02ce4d50: mov     w8, #1                                     
02ce4d54: strb    w8, [x21, #0x91c]                          
02ce4d58: cbz     x20, #0x2ce4f04                            
02ce4d5c: adrp    x8, #0x6264000                             
02ce4d60: mov     x0, x20                                    
02ce4d64: mov     x1, xzr                                    
02ce4d68: ldr     x8, [x8, #0xd8]                            T:UnityEngine.Vector3
02ce4d6c: ldr     s3, [x19, #0x3c]                           .<spinAmount>5__3
02ce4d70: ldr     x8, [x8]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02ce4d74: ldr     x8, [x8, #0xb8]                            MS:DG.Tweening.Core.Extensions::SetSpecialStartupMode
02ce4d78: ldp     s1, s2, [x8, #0x4c]                        
02ce4d7c: ldr     s0, [x8, #0x48]                            M:DG.Tweening.DOTweenModulePhysics/<>c__DisplayClass0_0::<DOMove>b__0
02ce4d80: bl      #0x5b47cbc                                 UnityEngine.Transform::Rotate
02ce4d84: ldr     s8, [x19, #0x40]                           .<elapsedTime>5__4
02ce4d88: mov     x0, xzr                                    
02ce4d8c: bl      #0x5b433a4                                 UnityEngine.Time::get_deltaTime
02ce4d90: fadd    s0, s8, s0                                 
02ce4d94: mov     x1, xzr                                    
02ce4d98: str     s0, [x19, #0x40]                           .<elapsedTime>5__4
02ce4d9c: str     xzr, [x19, #0x18]!                         .<>2__current
02ce4da0: mov     x0, x19                                    
02ce4da4: bl      #0x2b70d54                                 fn_2b70d54
02ce4da8: mov     w0, #1                                     
02ce4dac: stur    w0, [x19, #-8]                             
02ce4db0: b       #0x2ce4eec                                 
02ce4db4: mov     w8, #-1                                    
02ce4db8: str     w8, [x19, #0x10]                           .<>1__state
02ce4dbc: cbz     x23, #0x2ce4f04                            
02ce4dc0: ldr     s8, [x19, #0x4c]                           .<decelerationElapsedTime>5__7
02ce4dc4: b       #0x2ce4e08                                 
02ce4dc8: ldr     x0, [x23, #0x80]                           
02ce4dcc: cbz     x0, #0x2ce4f04                             
02ce4dd0: mov     x1, xzr                                    
02ce4dd4: bl      #0x5b368f0                                 UnityEngine.GameObject::get_transform
02ce4dd8: cbz     x0, #0x2ce4f04                             
02ce4ddc: mov     x1, xzr                                    
02ce4de0: bl      #0x5b469e4                                 UnityEngine.Transform::get_eulerAngles
02ce4de4: mov     w8, #0x44340000                            
02ce4de8: ldr     s0, [x19, #0x38]                           .<targetRotationValue>5__2
02ce4dec: movi    d8, #0000000000000000                      
02ce4df0: fmov    s1, w8                                     
02ce4df4: str     wzr, [x19, #0x4c]                          .<decelerationElapsedTime>5__7
02ce4df8: fsub    s0, s0, s2                                 
02ce4dfc: fadd    s1, s2, s1                                 
02ce4e00: fadd    s0, s1, s0                                 
02ce4e04: stp     s2, s0, [x19, #0x44]                       .<startRotation>5__5
02ce4e08: ldr     s9, [x23, #0x3c]                           
02ce4e0c: ldr     x0, [x23, #0x80]                           
02ce4e10: fcmp    s8, s9                                     
02ce4e14: b.pl    #0x2ce4eac                                 
02ce4e18: cbz     x0, #0x2ce4f04                             
02ce4e1c: mov     x1, xzr                                    
02ce4e20: bl      #0x5b368f0                                 UnityEngine.GameObject::get_transform
02ce4e24: cbz     x0, #0x2ce4f04                             
02ce4e28: fdiv    s0, s8, s9                                 
02ce4e2c: fmov    s8, #1.00000000                            
02ce4e30: mov     x20, x0                                    
02ce4e34: ldp     s9, s1, [x19, #0x44]                       .<startRotation>5__5
02ce4e38: fsub    s10, s1, s9                                
02ce4e3c: fmov    s1, #3.00000000                            
02ce4e40: fsub    s0, s8, s0                                 
02ce4e44: bl      #0x5e90320                                 fn_5e90320
02ce4e48: fsub    s0, s8, s0                                 
02ce4e4c: movi    d1, #0000000000000000                      
02ce4e50: mov     x0, x20                                    
02ce4e54: mov     x1, xzr                                    
02ce4e58: fcmp    s0, s8                                     
02ce4e5c: fcsel   s2, s8, s0, gt                             
02ce4e60: fcmp    s0, #0.0                                   
02ce4e64: fcsel   s0, s1, s2, mi                             
02ce4e68: fmul    s0, s0, s10                                
02ce4e6c: fadd    s2, s9, s0                                 
02ce4e70: movi    d0, #0000000000000000                      
02ce4e74: bl      #0x5b46ac4                                 UnityEngine.Transform::set_eulerAngles
02ce4e78: ldr     s8, [x19, #0x4c]                           .<decelerationElapsedTime>5__7
02ce4e7c: mov     x0, xzr                                    
02ce4e80: bl      #0x5b433a4                                 UnityEngine.Time::get_deltaTime
02ce4e84: fadd    s0, s8, s0                                 
02ce4e88: mov     x1, xzr                                    
02ce4e8c: str     s0, [x19, #0x4c]                           .<decelerationElapsedTime>5__7
02ce4e90: str     xzr, [x19, #0x18]!                         .<>2__current
02ce4e94: mov     x0, x19                                    
02ce4e98: bl      #0x2b70d54                                 fn_2b70d54
02ce4e9c: mov     w8, #2                                     
02ce4ea0: mov     w0, #1                                     
02ce4ea4: stur    w8, [x19, #-8]                             
02ce4ea8: b       #0x2ce4eec                                 
02ce4eac: cbz     x0, #0x2ce4f04                             
02ce4eb0: mov     x1, xzr                                    
02ce4eb4: bl      #0x5b368f0                                 UnityEngine.GameObject::get_transform
02ce4eb8: cbz     x0, #0x2ce4f04                             
02ce4ebc: movi    d0, #0000000000000000                      
02ce4ec0: movi    d1, #0000000000000000                      
02ce4ec4: ldr     s2, [x19, #0x38]                           .<targetRotationValue>5__2
02ce4ec8: mov     x1, xzr                                    
02ce4ecc: bl      #0x5b46ac4                                 UnityEngine.Transform::set_eulerAngles
02ce4ed0: ldr     x8, [x19, #0x30]                           .animationCompleted
02ce4ed4: cbz     x8, #0x2ce4ee8                             
02ce4ed8: ldr     x9, [x8, #0x18]                            M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass2_0::<DOSetFloat>b__1
02ce4edc: ldr     x0, [x8, #0x40]                            MS:DG.Tweening.TweenSettingsExtensions::SetTarget
02ce4ee0: ldr     x1, [x8, #0x28]                            T:type8534(k15)
02ce4ee4: blr     x9                                         
02ce4ee8: mov     w0, wzr                                    
02ce4eec: ldp     x20, x19, [sp, #0x40]                      
02ce4ef0: ldp     x22, x21, [sp, #0x30]                      
02ce4ef4: ldp     x30, x23, [sp, #0x20]                      
02ce4ef8: ldp     d9, d8, [sp, #0x10]                        
02ce4efc: ldr     d10, [sp], #0x50                           
02ce4f00: ret                                                
02ce4f04: bl      #0x2b7105c                                 fn_2b7105c
## System.Collections.Generic.IEnumerator<System.Object>.get_Current() -> object
---- LuckyWheelPopup/<SpinAnimation>d__51::System.Collections.Generic.IEnumerator<System.Object>.get_Current 0x2ce4f08
02ce4f08: ldr     x0, [x0, #0x18]                            .<>2__current
02ce4f0c: ret                                                
## System.Collections.IEnumerator.Reset() -> void
---- LuckyWheelPopup/<SpinAnimation>d__51::System.Collections.IEnumerator.Reset 0x2ce4f10
02ce4f10: stp     x30, x19, [sp, #-0x10]!                    
02ce4f14: adrp    x0, #0x6264000                             
02ce4f18: ldr     x0, [x0, #0xf60]                           T:System.NotSupportedException
02ce4f1c: bl      #0x2b70dc4                                 fn_2b70dc4
02ce4f20: bl      #0x2b7104c                                 fn_2b7104c
02ce4f24: mov     x1, xzr                                    
02ce4f28: mov     x19, x0                                    
02ce4f2c: bl      #0x4e14238                                 System.NotSupportedException::.ctor
02ce4f30: adrp    x0, #0x6268000                             
02ce4f34: ldr     x0, [x0, #0x190]                           M:LuckyWheelPopup/<SpinAnimation>d__51::System.Collections.IEnumerator.Reset
02ce4f38: bl      #0x2b70dc4                                 fn_2b70dc4
02ce4f3c: mov     x1, x0                                     
02ce4f40: mov     x0, x19                                    
02ce4f44: bl      #0x2b70f20                                 fn_2b70f20
## System.Collections.IEnumerator.get_Current() -> object
---- LuckyWheelPopup/<SpinAnimation>d__51::System.Collections.IEnumerator.get_Current 0x2ce4f48
02ce4f48: ldr     x0, [x0, #0x18]                            .<>2__current
02ce4f4c: ret                                                
#### CLASS LuckyWheelPopup parent= PopupBase
#   field _initSpinDuration              float                                              off=0x38 attr=1 HeaderAttribute,SerializeField
#   field _decelerationDuration          float                                              off=0x3c attr=1 SerializeField
#   field _spinSpeed                     float                                              off=0x40 attr=1 SerializeField
#   field _btnClose                      UnityEngine.UI.Button                              off=0x48 attr=1 HeaderAttribute,SerializeField
#   field _btnClose2                     UnityEngine.UI.Button                              off=0x50 attr=1 SerializeField
#   field _spinButton                    UnityEngine.UI.Button                              off=0x58 attr=1 SerializeField
#   field _getCoinButton                 UnityEngine.UI.Button                              off=0x60 attr=1 SerializeField
#   field _txtCoinGet                    TMPro.TextMeshProUGUI                              off=0x68 attr=1 SerializeField
#   field _fxCoin                        AssetKits.ParticleImage.ParticleImage              off=0x70 attr=1 SerializeField
#   field _textBlank                     TMPro.TextMeshProUGUI                              off=0x78 attr=1 SerializeField
#   field _wheelImage                    UnityEngine.GameObject                             off=0x80 attr=1 SerializeField
#   field _counterText                   TMPro.TextMeshProUGUI                              off=0x88 attr=1 SerializeField
#   field _getCoinButtonContent          UnityEngine.Transform                              off=0x90 attr=1 SerializeField
#   field _spineTextRect                 UnityEngine.RectTransform                          off=0x98 attr=1 SerializeField
#   field _adsIconRect                   UnityEngine.RectTransform                          off=0xa0 attr=1 SerializeField
#   field _blueButtonRect                UnityEngine.RectTransform                          off=0xa8 attr=1 SerializeField
#   field _nodes                         System.Collections.Generic.List`1<LuckyWheelNode>  off=0xb0 attr=1 SerializeField
#   field _mysteryBoxes                  System.Collections.Generic.List`1<RewardMysteryBox> off=0xb8 attr=1 SerializeField
#   field _giftBoxLuckyWheel             GiftBoxLuckyWheel                                  off=0xc0 attr=1 SerializeField
#   field _configSO                      LuckyWheelConfigSO                                 off=0xc8 attr=1 SerializeField
#   field _decorKeycapConfig             Clicker.DecorKeycapConfig                          off=0xd0 attr=1 SerializeField
#   field _pinginSpine                   Spine.Unity.SkeletonGraphic                        off=0xd8 attr=1 HeaderAttribute,SerializeField
#   field IDLE                           string                                             off=0x0 attr=8051 
#   field OPEN_BOX_LOOP                  string                                             off=0x0 attr=8051 
#   field CLOSE_MOUTH_1_5                string                                             off=0x0 attr=8051 
#   field OPEN_MOUTH_0_8                 string                                             off=0x0 attr=8051 
#   field OPEN_MOUTH_LOOP                string                                             off=0x0 attr=8051 
#   field _trackEntry                    Spine.TrackEntry                                   off=0xe0 attr=1 
#   field _onAnimCompleteEvent           UnityEngine.Events.UnityEvent                      off=0xe8 attr=1 
#   field _timer                         float                                              off=0xf0 attr=1 
#   field _isSpinning                    bool                                               off=0xf4 attr=1 
#   field _isAdOn                        bool                                               off=0xf5 attr=1 
#   field _countdownCoroutine            UnityEngine.Coroutine                              off=0xf8 attr=1 
#   field FREE_SPIN_KEY                  string                                             off=0x0 attr=8051 
#   field COUNTDOWN_KEY                  string                                             off=0x0 attr=8051 
#   field _cooldown                      System.TimeSpan                                    off=0x100 attr=21 
#   field _onClosePopupAction            UnityEngine.Events.UnityAction                     off=0x108 attr=1 
## get_ConfigSO() -> LuckyWheelConfigSO
---- LuckyWheelPopup::get_ConfigSO 0x2ce175c
02ce175c: str     x30, [sp, #-0x20]!                         
02ce1760: stp     x20, x19, [sp, #0x10]                      
02ce1764: adrp    x19, #0x662f000                            
02ce1768: adrp    x20, #0x6266000                            
02ce176c: ldrb    w8, [x19, #0xdb3]                          
02ce1770: ldr     x20, [x20, #0x658]                         MS:MonoSingleton`1::get_Instance
02ce1774: tbnz    w8, #0, #0x2ce1798                         
02ce1778: adrp    x0, #0x6267000                             
02ce177c: ldr     x0, [x0, #0xf98]                           MS:DataManager::GetAsset
02ce1780: bl      #0x2b70db0                                 fn_2b70db0
02ce1784: adrp    x0, #0x6266000                             
02ce1788: ldr     x0, [x0, #0x658]                           MS:MonoSingleton`1::get_Instance
02ce178c: bl      #0x2b70db0                                 fn_2b70db0
02ce1790: mov     w8, #1                                     
02ce1794: strb    w8, [x19, #0xdb3]                          
02ce1798: ldr     x0, [x20]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ce179c: bl      #0x3769600                                 fn_3769600
02ce17a0: cbz     x0, #0x2ce17bc                             
02ce17a4: adrp    x8, #0x6267000                             
02ce17a8: ldr     x8, [x8, #0xf98]                           MS:DataManager::GetAsset
02ce17ac: ldp     x20, x19, [sp, #0x10]                      
02ce17b0: ldr     x1, [x8]                                   S:'didu'
02ce17b4: ldr     x30, [sp], #0x20                           
02ce17b8: b       #0x3168af0                                 
02ce17bc: bl      #0x2b7105c                                 fn_2b7105c
## get_IsCountdownDone() -> bool
---- LuckyWheelPopup::get_IsCountdownDone 0x2ce17c0
02ce17c0: sub     sp, sp, #0x30                              
02ce17c4: str     x30, [sp, #0x10]                           
02ce17c8: stp     x20, x19, [sp, #0x20]                      
02ce17cc: adrp    x20, #0x662f000                            
02ce17d0: adrp    x19, #0x6266000                            
02ce17d4: ldrb    w8, [x20, #0xdb4]                          
02ce17d8: ldr     x19, [x19, #0x128]                         T:System.DateTime
02ce17dc: tbnz    w8, #0, #0x2ce1800                         
02ce17e0: adrp    x0, #0x6266000                             
02ce17e4: ldr     x0, [x0, #0x128]                           T:System.DateTime
02ce17e8: bl      #0x2b70db0                                 fn_2b70db0
02ce17ec: adrp    x0, #0x6267000                             
02ce17f0: ldr     x0, [x0, #0xfa0]                           S:'IsCountdown'
02ce17f4: bl      #0x2b70db0                                 fn_2b70db0
02ce17f8: mov     w8, #1                                     
02ce17fc: strb    w8, [x20, #0xdb4]                          
02ce1800: ldr     x0, [x19]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ce1804: adrp    x19, #0x6267000                            
02ce1808: ldr     w8, [x0, #0xe4]                            [62670e4]=0 f=0,0
02ce180c: ldr     x19, [x19, #0xfa0]                         S:'IsCountdown'
02ce1810: str     xzr, [sp, #0x18]                           
02ce1814: str     xzr, [sp, #8]                              
02ce1818: cbnz    w8, #0x2ce1820                             
02ce181c: bl      #0x2b70f30                                 fn_2b70f30
02ce1820: mov     x0, xzr                                    
02ce1824: bl      #0x4df25c8                                 System.DateTime::get_Now
02ce1828: fmov    d0, #-1.00000000                           
02ce182c: str     x0, [sp, #8]                               
02ce1830: add     x0, sp, #8                                 
02ce1834: mov     x1, xzr                                    
02ce1838: bl      #0x4df0f9c                                 System.DateTime::AddDays
02ce183c: str     x0, [sp, #8]                               
02ce1840: add     x0, sp, #8                                 
02ce1844: mov     x1, xzr                                    
02ce1848: bl      #0x4df3550                                 System.DateTime::ToString
02ce184c: ldr     x8, [x19]                                  S:'didu'
02ce1850: mov     x1, x0                                     
02ce1854: mov     x2, xzr                                    
02ce1858: mov     x0, x8                                     
02ce185c: bl      #0x5b2d3f0                                 UnityEngine.PlayerPrefs::GetString
02ce1860: mov     x1, xzr                                    
02ce1864: bl      #0x4df2914                                 System.DateTime::Parse
02ce1868: str     x0, [sp, #0x18]                            
02ce186c: add     x0, sp, #0x18                              
02ce1870: mov     x1, xzr                                    
02ce1874: bl      #0x4df21c4                                 System.DateTime::get_Day
02ce1878: mov     w19, w0                                    
02ce187c: mov     x0, xzr                                    
02ce1880: bl      #0x4df25c8                                 System.DateTime::get_Now
02ce1884: str     x0, [sp, #8]                               
02ce1888: add     x0, sp, #8                                 
02ce188c: mov     x1, xzr                                    
02ce1890: bl      #0x4df21c4                                 System.DateTime::get_Day
02ce1894: cmp     w19, w0                                    
02ce1898: ldp     x20, x19, [sp, #0x20]                      
02ce189c: ldr     x30, [sp, #0x10]                           
02ce18a0: cset    w0, lt                                     
02ce18a4: add     sp, sp, #0x30                              
02ce18a8: ret                                                
## get_Count() -> int
---- LuckyWheelPopup::get_Count 0x2ce18ac
02ce18ac: str     x30, [sp, #-0x20]!                         
02ce18b0: stp     x20, x19, [sp, #0x10]                      
02ce18b4: adrp    x19, #0x662f000                            
02ce18b8: adrp    x20, #0x6267000                            
02ce18bc: ldrb    w8, [x19, #0xdb5]                          
02ce18c0: ldr     x20, [x20, #0xfa8]                         S:'LastFreeSpinTime'
02ce18c4: tbnz    w8, #0, #0x2ce18dc                         
02ce18c8: adrp    x0, #0x6267000                             
02ce18cc: ldr     x0, [x0, #0xfa8]                           S:'LastFreeSpinTime'
02ce18d0: bl      #0x2b70db0                                 fn_2b70db0
02ce18d4: mov     w8, #1                                     
02ce18d8: strb    w8, [x19, #0xdb5]                          
02ce18dc: ldr     x0, [x20]                                  S:'didu'
02ce18e0: ldp     x20, x19, [sp, #0x10]                      
02ce18e4: mov     w1, wzr                                    
02ce18e8: mov     x2, xzr                                    
02ce18ec: ldr     x30, [sp], #0x20                           
02ce18f0: b       #0x5b2d1dc                                 UnityEngine.PlayerPrefs::GetInt
## set_Count(int value) -> void
---- LuckyWheelPopup::set_Count 0x2ce18f4
02ce18f4: stp     x30, x21, [sp, #-0x20]!                    
02ce18f8: stp     x20, x19, [sp, #0x10]                      
02ce18fc: adrp    x20, #0x662f000                            
02ce1900: adrp    x21, #0x6267000                            
02ce1904: mov     w19, w1                                    
02ce1908: ldrb    w8, [x20, #0xdb6]                          
02ce190c: ldr     x21, [x21, #0xfa8]                         S:'LastFreeSpinTime'
02ce1910: tbnz    w8, #0, #0x2ce1928                         
02ce1914: adrp    x0, #0x6267000                             
02ce1918: ldr     x0, [x0, #0xfa8]                           S:'LastFreeSpinTime'
02ce191c: bl      #0x2b70db0                                 fn_2b70db0
02ce1920: mov     w8, #1                                     
02ce1924: strb    w8, [x20, #0xdb6]                          
02ce1928: mov     w1, w19                                    
02ce192c: ldp     x20, x19, [sp, #0x10]                      
02ce1930: ldr     x0, [x21]                                  S:'didu'
02ce1934: mov     x2, xzr                                    
02ce1938: ldp     x30, x21, [sp], #0x20                      
02ce193c: b       #0x5b2d184                                 UnityEngine.PlayerPrefs::SetInt
## RegisterCloseAction(UnityEngine.Events.UnityAction action) -> LuckyWheelPopup
---- LuckyWheelPopup::RegisterCloseAction 0x2ce1940
02ce1940: stp     x30, x19, [sp, #-0x10]!                    
02ce1944: mov     x19, x0                                    
02ce1948: str     x1, [x0, #0x108]                           ._onClosePopupAction
02ce194c: add     x0, x0, #0x108                             
02ce1950: bl      #0x2b70d54                                 fn_2b70d54
02ce1954: mov     x0, x19                                    
02ce1958: ldp     x30, x19, [sp], #0x10                      
02ce195c: ret                                                
## OnInit(UIManager uiManager) -> void
---- LuckyWheelPopup::OnInit 0x2ce1960
02ce1960: str     x30, [sp, #-0x30]!                         
02ce1964: stp     x22, x21, [sp, #0x10]                      
02ce1968: stp     x20, x19, [sp, #0x20]                      
02ce196c: adrp    x21, #0x662f000                            
02ce1970: mov     x20, x1                                    
02ce1974: mov     x19, x0                                    
02ce1978: ldrb    w8, [x21, #0xdb7]                          
02ce197c: tbnz    w8, #0, #0x2ce19b8                         
02ce1980: adrp    x0, #0x6267000                             
02ce1984: ldr     x0, [x0, #0xfb0]                           M:LuckyWheelPopup::OnButtonCloseClicked
02ce1988: bl      #0x2b70db0                                 fn_2b70db0
02ce198c: adrp    x0, #0x6267000                             
02ce1990: ldr     x0, [x0, #0xfb8]                           M:LuckyWheelPopup::OnSpinButtonClick
02ce1994: bl      #0x2b70db0                                 fn_2b70db0
02ce1998: adrp    x0, #0x6265000                             
02ce199c: ldr     x0, [x0, #0x3f0]                           T:UnityEngine.Events.UnityAction
02ce19a0: bl      #0x2b70db0                                 fn_2b70db0
02ce19a4: adrp    x0, #0x6267000                             
02ce19a8: ldr     x0, [x0, #0xfc0]                           S:'idle'
02ce19ac: bl      #0x2b70db0                                 fn_2b70db0
02ce19b0: mov     w8, #1                                     
02ce19b4: strb    w8, [x21, #0xdb7]                          
02ce19b8: mov     x0, x19                                    
02ce19bc: mov     x1, x20                                    
02ce19c0: bl      #0x2cdd3c4                                 UIBase::OnInit
02ce19c4: ldr     x8, [x19, #0x58]                           ._spinButton
02ce19c8: cbz     x8, #0x2ce1aa0                             
02ce19cc: adrp    x22, #0x6265000                            
02ce19d0: adrp    x21, #0x6267000                            
02ce19d4: ldr     x22, [x22, #0x3f0]                         T:UnityEngine.Events.UnityAction
02ce19d8: ldr     x21, [x21, #0xfb8]                         M:LuckyWheelPopup::OnSpinButtonClick
02ce19dc: ldr     x20, [x8, #0x100]                          
02ce19e0: ldr     x0, [x22]                                  M:AdsManager::<OnApplicationPause>b__26_0
02ce19e4: bl      #0x2b7104c                                 fn_2b7104c
02ce19e8: ldr     x2, [x21]                                  S:'didu'
02ce19ec: mov     x1, x19                                    
02ce19f0: mov     x3, xzr                                    
02ce19f4: mov     x21, x0                                    
02ce19f8: bl      #0x5b4cf98                                 UnityEngine.Events.UnityAction::.ctor
02ce19fc: cbz     x20, #0x2ce1aa0                            
02ce1a00: mov     x0, x20                                    
02ce1a04: mov     x1, x21                                    
02ce1a08: mov     x2, xzr                                    
02ce1a0c: bl      #0x5b4d0ac                                 UnityEngine.Events.UnityEvent::AddListener
02ce1a10: ldr     x8, [x19, #0x48]                           ._btnClose
02ce1a14: cbz     x8, #0x2ce1aa0                             
02ce1a18: adrp    x21, #0x6267000                            
02ce1a1c: ldr     x21, [x21, #0xfb0]                         M:LuckyWheelPopup::OnButtonCloseClicked
02ce1a20: ldr     x0, [x22]                                  M:AdsManager::<OnApplicationPause>b__26_0
02ce1a24: ldr     x20, [x8, #0x100]                          
02ce1a28: bl      #0x2b7104c                                 fn_2b7104c
02ce1a2c: ldr     x2, [x21]                                  S:'didu'
02ce1a30: mov     x1, x19                                    
02ce1a34: mov     x3, xzr                                    
02ce1a38: mov     x21, x0                                    
02ce1a3c: bl      #0x5b4cf98                                 UnityEngine.Events.UnityAction::.ctor
02ce1a40: cbz     x20, #0x2ce1aa0                            
02ce1a44: mov     x0, x20                                    
02ce1a48: mov     x1, x21                                    
02ce1a4c: mov     x2, xzr                                    
02ce1a50: bl      #0x5b4d0ac                                 UnityEngine.Events.UnityEvent::AddListener
02ce1a54: bl      #0x2ce175c                                 LuckyWheelPopup::get_ConfigSO
02ce1a58: cbz     x0, #0x2ce1aa0                             
02ce1a5c: adrp    x20, #0x6267000                            
02ce1a60: ldr     x20, [x20, #0xfc0]                         S:'idle'
02ce1a64: ldr     x1, [x0, #0x18]                            S:'android.content.Intent'
02ce1a68: mov     x0, x19                                    
02ce1a6c: bl      #0x2ce1aa4                                 LuckyWheelPopup::LoadConfig
02ce1a70: ldr     x8, [x19]                                  
02ce1a74: mov     x0, x19                                    
02ce1a78: ldp     x9, x1, [x8, #0x198]                       
02ce1a7c: blr     x9                                         
02ce1a80: ldr     x1, [x20]                                  S:'didu'
02ce1a84: mov     x0, x19                                    
02ce1a88: mov     w2, #1                                     
02ce1a8c: ldp     x20, x19, [sp, #0x20]                      
02ce1a90: mov     x3, xzr                                    
02ce1a94: ldp     x22, x21, [sp, #0x10]                      
02ce1a98: ldr     x30, [sp], #0x30                           
02ce1a9c: b       #0x2ce1b80                                 LuckyWheelPopup::PlayAnimation
02ce1aa0: bl      #0x2b7105c                                 fn_2b7105c
## OnShow() -> void
---- LuckyWheelPopup::OnShow 0x2ce1d64
02ce1d64: sub     sp, sp, #0x80                              
02ce1d68: stp     x30, x21, [sp, #0x60]                      
02ce1d6c: stp     x20, x19, [sp, #0x70]                      
02ce1d70: adrp    x21, #0x662f000                            
02ce1d74: adrp    x20, #0x6267000                            
02ce1d78: mov     x19, x0                                    
02ce1d7c: ldrb    w8, [x21, #0xdb8]                          
02ce1d80: ldr     x20, [x20, #0xff8]                         MS:System.Runtime.CompilerServices.AsyncVoidMethodBuilder::Start
02ce1d84: tbnz    w8, #0, #0x2ce1d9c                         
02ce1d88: adrp    x0, #0x6267000                             
02ce1d8c: ldr     x0, [x0, #0xff8]                           MS:System.Runtime.CompilerServices.AsyncVoidMethodBuilder::Start
02ce1d90: bl      #0x2b70db0                                 fn_2b70db0
02ce1d94: mov     w8, #1                                     
02ce1d98: strb    w8, [x21, #0xdb8]                          
02ce1d9c: movi    v0.2d, #0000000000000000                   
02ce1da0: mov     x8, sp                                     
02ce1da4: mov     x0, xzr                                    
02ce1da8: stp     q0, q0, [sp, #0x20]                        
02ce1dac: stp     q0, q0, [sp, #0x40]                        
02ce1db0: bl      #0x4d43a24                                 System.Runtime.CompilerServices.AsyncVoidMethodBuilder::Create
02ce1db4: ldp     q0, q1, [sp]                               
02ce1db8: add     x21, sp, #0x20                             
02ce1dbc: orr     x0, x21, #8                                
02ce1dc0: mov     x1, xzr                                    
02ce1dc4: stur    q0, [sp, #0x28]                            
02ce1dc8: stur    q1, [sp, #0x38]                            
02ce1dcc: bl      #0x2b70d54                                 fn_2b70d54
02ce1dd0: add     x0, x21, #0x28                             &662f028
02ce1dd4: mov     x1, x19                                    
02ce1dd8: str     x19, [sp, #0x48]                           
02ce1ddc: bl      #0x2b70d54                                 fn_2b70d54
02ce1de0: ldr     x2, [x20]                                  S:'didu'
02ce1de4: mov     w8, #-1                                    
02ce1de8: orr     x0, x21, #8                                
02ce1dec: add     x1, sp, #0x20                              
02ce1df0: str     w8, [sp, #0x20]                            
02ce1df4: bl      #0x30c7e80                                 fn_30c7e80
02ce1df8: ldp     x20, x19, [sp, #0x70]                      
02ce1dfc: ldp     x30, x21, [sp, #0x60]                      
02ce1e00: add     sp, sp, #0x80                              
02ce1e04: ret                                                
## CheckCounterSpin() -> void
---- LuckyWheelPopup::CheckCounterSpin 0x2ce1e08
02ce1e08: str     x30, [sp, #-0x20]!                         
02ce1e0c: stp     x20, x19, [sp, #0x10]                      
02ce1e10: adrp    x20, #0x662f000                            
02ce1e14: mov     x19, x0                                    
02ce1e18: ldrb    w8, [x20, #0xdb9]                          
02ce1e1c: tbnz    w8, #0, #0x2ce1e34                         
02ce1e20: adrp    x0, #0x6268000                             
02ce1e24: ldr     x0, [x0]                                   S:'{0}/2'
02ce1e28: bl      #0x2b70db0                                 fn_2b70db0
02ce1e2c: mov     w8, #1                                     
02ce1e30: strb    w8, [x20, #0xdb9]                          
02ce1e34: bl      #0x2ce17c0                                 LuckyWheelPopup::get_IsCountdownDone
02ce1e38: tbz     w0, #0, #0x2ce1e44                         
02ce1e3c: mov     w1, wzr                                    
02ce1e40: bl      #0x2ce18f4                                 LuckyWheelPopup::set_Count
02ce1e44: bl      #0x2ce18ac                                 LuckyWheelPopup::get_Count
02ce1e48: cbz     x19, #0x2ce1ee0                            
02ce1e4c: cmp     w0, #2                                     
02ce1e50: ldr     x0, [x19, #0xa0]                           ._adsIconRect
02ce1e54: cset    w8, eq                                     
02ce1e58: strb    w8, [x19, #0xf5]                           ._isAdOn
02ce1e5c: cbz     x0, #0x2ce1ee0                             
02ce1e60: mov     x1, xzr                                    
02ce1e64: bl      #0x5b339ec                                 UnityEngine.Component::get_gameObject
02ce1e68: cbz     x0, #0x2ce1ee0                             
02ce1e6c: adrp    x20, #0x6268000                            
02ce1e70: mov     x2, xzr                                    
02ce1e74: ldr     x20, [x20]                                 S:'{0}/2'
02ce1e78: ldrb    w1, [x19, #0xf5]                           ._isAdOn
02ce1e7c: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02ce1e80: ldr     x19, [x19, #0x88]                          ._counterText
02ce1e84: bl      #0x2ce18ac                                 LuckyWheelPopup::get_Count
02ce1e88: adrp    x8, #0x6263000                             
02ce1e8c: add     x1, sp, #0xc                               
02ce1e90: ldr     x8, [x8, #0x970]                           &6645c70(=0)
02ce1e94: str     w0, [sp, #0xc]                             
02ce1e98: ldr     x8, [x8, #0x48]                            &6263098(=0)
02ce1e9c: mov     x0, x8                                     
02ce1ea0: bl      #0x2b70f38                                 fn_2b70f38
02ce1ea4: ldr     x8, [x20]                                  S:'{0}/2'
02ce1ea8: mov     x1, x0                                     
02ce1eac: mov     x2, xzr                                    
02ce1eb0: mov     x0, x8                                     
02ce1eb4: bl      #0x4c9d0ec                                 System.String::Format
02ce1eb8: cbz     x19, #0x2ce1ee0                            
02ce1ebc: ldr     x8, [x19]                                  
02ce1ec0: mov     x1, x0                                     
02ce1ec4: mov     x0, x19                                    
02ce1ec8: ldr     x9, [x8, #0x558]                           &2c5d934(=d65f03c0d503245f)
02ce1ecc: ldr     x2, [x8, #0x560]                           &2c5d58c(=14c8cc6cd503245f)
02ce1ed0: blr     x9                                         
02ce1ed4: ldp     x20, x19, [sp, #0x10]                      
02ce1ed8: ldr     x30, [sp], #0x20                           
02ce1edc: ret                                                
02ce1ee0: bl      #0x2b7105c                                 fn_2b7105c
## OnHide() -> void
---- LuckyWheelPopup::OnHide 0x2ce1ee4
02ce1ee4: stp     x30, x19, [sp, #-0x10]!                    
02ce1ee8: mov     x19, x0                                    
02ce1eec: bl      #0x2ce1f18                                 LuckyWheelPopup::StopButtonSpinAnim
02ce1ef0: mov     x0, x19                                    
02ce1ef4: bl      #0x2ce1fe8                                 LuckyWheelPopup::StopCountdown
02ce1ef8: movi    d0, #0000000000000000                      
02ce1efc: ldr     x0, [x19, #0x28]                           
02ce1f00: mov     w1, wzr                                    
02ce1f04: mov     x2, xzr                                    
02ce1f08: bl      #0x2cf1928                                 FrameWorkUtility::SetActive
02ce1f0c: strb    wzr, [x19, #0x20]                          
02ce1f10: ldp     x30, x19, [sp], #0x10                      
02ce1f14: ret                                                
## LoadConfig(System.Collections.Generic.List`1<LuckyWheelRewardConfig> configs) -> void
---- LuckyWheelPopup::LoadConfig 0x2ce1aa4
02ce1aa4: str     x30, [sp, #-0x40]!                         
02ce1aa8: stp     x24, x23, [sp, #0x10]                      
02ce1aac: stp     x22, x21, [sp, #0x20]                      
02ce1ab0: stp     x20, x19, [sp, #0x30]                      
02ce1ab4: adrp    x21, #0x662f000                            
02ce1ab8: mov     x19, x1                                    
02ce1abc: mov     x20, x0                                    
02ce1ac0: ldrb    w8, [x21, #0xdba]                          
02ce1ac4: tbnz    w8, #0, #0x2ce1af4                         
02ce1ac8: adrp    x0, #0x6267000                             
02ce1acc: ldr     x0, [x0, #0xfc8]                           MS:System.Collections.Generic.List`1::get_Count
02ce1ad0: bl      #0x2b70db0                                 fn_2b70db0
02ce1ad4: adrp    x0, #0x6266000                             
02ce1ad8: ldr     x0, [x0, #0x628]                           MS:System.Collections.Generic.List`1::get_Item
02ce1adc: bl      #0x2b70db0                                 fn_2b70db0
02ce1ae0: adrp    x0, #0x6267000                             
02ce1ae4: ldr     x0, [x0, #0xfd0]                           MS:System.Collections.Generic.List`1::get_Item
02ce1ae8: bl      #0x2b70db0                                 fn_2b70db0
02ce1aec: mov     w8, #1                                     
02ce1af0: strb    w8, [x21, #0xdba]                          
02ce1af4: cbz     x19, #0x2ce1b7c                            
02ce1af8: ldr     w8, [x19, #0x18]                           
02ce1afc: cmp     w8, #1                                     
02ce1b00: b.lt    #0x2ce1b68                                 
02ce1b04: adrp    x23, #0x6266000                            
02ce1b08: adrp    x24, #0x6267000                            
02ce1b0c: mov     w21, wzr                                   
02ce1b10: ldr     x23, [x23, #0x628]                         MS:System.Collections.Generic.List`1::get_Item
02ce1b14: ldr     x24, [x24, #0xfd0]                         MS:System.Collections.Generic.List`1::get_Item
02ce1b18: ldr     x2, [x23]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ce1b1c: mov     x0, x19                                    
02ce1b20: mov     w1, w21                                    
02ce1b24: bl      #0x35a8f3c                                 fn_35a8f3c
02ce1b28: ldr     x8, [x20, #0xb0]                           ._nodes
02ce1b2c: cbz     x8, #0x2ce1b7c                             
02ce1b30: ldr     x2, [x24]                                  S:'didu'
02ce1b34: mov     x22, x0                                    
02ce1b38: mov     x0, x8                                     
02ce1b3c: mov     w1, w21                                    
02ce1b40: bl      #0x35a8f3c                                 fn_35a8f3c
02ce1b44: cbz     x0, #0x2ce1b7c                             
02ce1b48: cbz     x22, #0x2ce1b7c                            
02ce1b4c: ldr     x1, [x22, #0x10]                           
02ce1b50: str     x1, [x0, #0x20]!                           
02ce1b54: bl      #0x2b70d54                                 fn_2b70d54
02ce1b58: ldr     w8, [x19, #0x18]                           
02ce1b5c: add     w21, w21, #1                               
02ce1b60: cmp     w21, w8                                    
02ce1b64: b.lt    #0x2ce1b18                                 
02ce1b68: ldp     x20, x19, [sp, #0x30]                      
02ce1b6c: ldp     x22, x21, [sp, #0x20]                      
02ce1b70: ldp     x24, x23, [sp, #0x10]                      
02ce1b74: ldr     x30, [sp], #0x40                           
02ce1b78: ret                                                
02ce1b7c: bl      #0x2b7105c                                 fn_2b7105c
## RunAnimation(string rewardId, UnityEngine.Events.UnityAction animationCompleted) -> void
---- LuckyWheelPopup::RunAnimation 0x2ce202c
02ce202c: stp     x30, x23, [sp, #-0x30]!                    
02ce2030: stp     x22, x21, [sp, #0x10]                      
02ce2034: stp     x20, x19, [sp, #0x20]                      
02ce2038: adrp    x21, #0x662f000                            
02ce203c: adrp    x23, #0x6268000                            
02ce2040: mov     x22, x2                                    
02ce2044: ldrb    w8, [x21, #0xdbb]                          
02ce2048: ldr     x23, [x23, #8]                             T:LuckyWheelPopup/<>c__DisplayClass50_0
02ce204c: mov     x20, x1                                    
02ce2050: mov     x19, x0                                    
02ce2054: tbnz    w8, #0, #0x2ce2090                         
02ce2058: adrp    x0, #0x6268000                             
02ce205c: ldr     x0, [x0, #0x10]                            MS:DG.Tweening.TweenSettingsExtensions::SetLoops
02ce2060: bl      #0x2b70db0                                 fn_2b70db0
02ce2064: adrp    x0, #0x6268000                             
02ce2068: ldr     x0, [x0, #0x18]                            M:LuckyWheelPopup/<>c__DisplayClass50_0::<RunAnimation>b__0
02ce206c: bl      #0x2b70db0                                 fn_2b70db0
02ce2070: adrp    x0, #0x6268000                             
02ce2074: ldr     x0, [x0, #8]                               T:LuckyWheelPopup/<>c__DisplayClass50_0
02ce2078: bl      #0x2b70db0                                 fn_2b70db0
02ce207c: adrp    x0, #0x6265000                             
02ce2080: ldr     x0, [x0, #0x3f0]                           T:UnityEngine.Events.UnityAction
02ce2084: bl      #0x2b70db0                                 fn_2b70db0
02ce2088: mov     w8, #1                                     
02ce208c: strb    w8, [x21, #0xdbb]                          
02ce2090: ldr     x0, [x23]                                  S:'{0}/2'
02ce2094: bl      #0x2b7104c                                 fn_2b7104c
02ce2098: mov     x1, xzr                                    
02ce209c: mov     x21, x0                                    
02ce20a0: bl      #0x4e53e9c                                 System.Object::.ctor
02ce20a4: cbz     x21, #0x2ce21cc                            
02ce20a8: mov     x0, x21                                    
02ce20ac: mov     x1, x22                                    
02ce20b0: str     x22, [x0, #0x10]!                          
02ce20b4: bl      #0x2b70d54                                 fn_2b70d54
02ce20b8: ldr     x0, [x19, #0x58]                           ._spinButton
02ce20bc: cbz     x0, #0x2ce21cc                             
02ce20c0: adrp    x22, #0x6268000                            
02ce20c4: mov     x1, xzr                                    
02ce20c8: ldr     x22, [x22, #0x10]                          MS:DG.Tweening.TweenSettingsExtensions::SetLoops
02ce20cc: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02ce20d0: adrp    x8, #0x1084000                             
02ce20d4: adrp    x9, #0x1084000                             
02ce20d8: mov     x1, xzr                                    
02ce20dc: ldr     s0, [x8, #0xfac]                           [1084fac]=3ecccccd3f333333 f=0.7,0.4
02ce20e0: ldr     s1, [x9, #0xeec]                           [1084eec]=457ff0003dcccccd f=0.1,4095
02ce20e4: bl      #0x2d98fd4                                 DG.Tweening.ShortcutExtensions::DOScaleY
02ce20e8: ldr     x3, [x22]                                  S:'{0}/2'
02ce20ec: mov     w1, #2                                     
02ce20f0: mov     w2, #1                                     
02ce20f4: bl      #0x336fe74                                 fn_336fe74
02ce20f8: adrp    x8, #0x1084000                             
02ce20fc: fmov    s0, #19.00000000                           
02ce2100: ldr     x0, [x19, #0xa8]                           ._blueButtonRect
02ce2104: ldr     s1, [x8, #0xdd8]                           [1084dd8]=3f7333333e4ccccd f=0.2,0.95
02ce2108: mov     w1, wzr                                    
02ce210c: mov     x2, xzr                                    
02ce2110: bl      #0x2c79c1c                                 DG.Tweening.DOTweenModuleUI::DOAnchorPosY
02ce2114: ldr     x0, [x19, #0x48]                           ._btnClose
02ce2118: cbz     x0, #0x2ce21cc                             
02ce211c: mov     x1, xzr                                    
02ce2120: bl      #0x5b339ec                                 UnityEngine.Component::get_gameObject
02ce2124: cbz     x0, #0x2ce21cc                             
02ce2128: mov     w1, wzr                                    
02ce212c: mov     x2, xzr                                    
02ce2130: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02ce2134: ldr     x0, [x19, #0x50]                           ._btnClose2
02ce2138: cbz     x0, #0x2ce21cc                             
02ce213c: mov     x1, xzr                                    
02ce2140: bl      #0x5b339ec                                 UnityEngine.Component::get_gameObject
02ce2144: cbz     x0, #0x2ce21cc                             
02ce2148: mov     w1, wzr                                    
02ce214c: mov     x2, xzr                                    
02ce2150: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02ce2154: ldr     x0, [x19, #0x78]                           ._textBlank
02ce2158: cbz     x0, #0x2ce21cc                             
02ce215c: mov     x1, xzr                                    
02ce2160: bl      #0x5b339ec                                 UnityEngine.Component::get_gameObject
02ce2164: cbz     x0, #0x2ce21cc                             
02ce2168: adrp    x22, #0x6265000                            
02ce216c: adrp    x23, #0x6268000                            
02ce2170: mov     w1, wzr                                    
02ce2174: ldr     x22, [x22, #0x3f0]                         T:UnityEngine.Events.UnityAction
02ce2178: ldr     x23, [x23, #0x18]                          M:LuckyWheelPopup/<>c__DisplayClass50_0::<RunAnimation>b__0
02ce217c: mov     x2, xzr                                    
02ce2180: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02ce2184: ldr     x0, [x22]                                  M:AdsManager::<OnApplicationPause>b__26_0
02ce2188: bl      #0x2b7104c                                 fn_2b7104c
02ce218c: ldr     x2, [x23]                                  S:'{0}/2'
02ce2190: mov     x1, x21                                    
02ce2194: mov     x3, xzr                                    
02ce2198: mov     x22, x0                                    
02ce219c: bl      #0x5b4cf98                                 UnityEngine.Events.UnityAction::.ctor
02ce21a0: mov     x0, x19                                    
02ce21a4: mov     x1, x20                                    
02ce21a8: mov     x2, x22                                    
02ce21ac: bl      #0x2ce21d8                                 LuckyWheelPopup::SpinAnimation
02ce21b0: mov     x1, x0                                     
02ce21b4: mov     x0, x19                                    
02ce21b8: mov     x2, xzr                                    
02ce21bc: ldp     x20, x19, [sp, #0x20]                      
02ce21c0: ldp     x22, x21, [sp, #0x10]                      
02ce21c4: ldp     x30, x23, [sp], #0x30                      
02ce21c8: b       #0x5b389f0                                 UnityEngine.MonoBehaviour::StartCoroutine
02ce21cc: bl      #0x2b7105c                                 fn_2b7105c
## SpinAnimation(string resultID, UnityEngine.Events.UnityAction animationCompleted) -> System.Collections.IEnumerator
---- LuckyWheelPopup::SpinAnimation 0x2ce21d8
02ce21d8: stp     x30, x23, [sp, #-0x30]!                    
02ce21dc: stp     x22, x21, [sp, #0x10]                      
02ce21e0: stp     x20, x19, [sp, #0x20]                      
02ce21e4: adrp    x22, #0x662f000                            
02ce21e8: adrp    x23, #0x6268000                            
02ce21ec: mov     x19, x2                                    
02ce21f0: ldrb    w8, [x22, #0xdbc]                          
02ce21f4: ldr     x23, [x23, #0x20]                          T:LuckyWheelPopup/<SpinAnimation>d__51
02ce21f8: mov     x20, x1                                    
02ce21fc: mov     x21, x0                                    
02ce2200: tbnz    w8, #0, #0x2ce2218                         
02ce2204: adrp    x0, #0x6268000                             
02ce2208: ldr     x0, [x0, #0x20]                            T:LuckyWheelPopup/<SpinAnimation>d__51
02ce220c: bl      #0x2b70db0                                 fn_2b70db0
02ce2210: mov     w8, #1                                     
02ce2214: strb    w8, [x22, #0xdbc]                          
02ce2218: ldr     x0, [x23]                                  S:'{0}/2'
02ce221c: bl      #0x2b7104c                                 fn_2b7104c
02ce2220: mov     x1, xzr                                    
02ce2224: mov     x22, x0                                    
02ce2228: bl      #0x4e53e9c                                 System.Object::.ctor
02ce222c: mov     x0, x22                                    
02ce2230: mov     x1, x21                                    
02ce2234: str     wzr, [x22, #0x10]                          
02ce2238: str     x21, [x0, #0x28]!                          
02ce223c: bl      #0x2b70d54                                 fn_2b70d54
02ce2240: mov     x0, x22                                    
02ce2244: mov     x1, x20                                    
02ce2248: str     x20, [x0, #0x20]!                          
02ce224c: bl      #0x2b70d54                                 fn_2b70d54
02ce2250: mov     x0, x22                                    
02ce2254: mov     x1, x19                                    
02ce2258: str     x19, [x0, #0x30]!                          
02ce225c: bl      #0x2b70d54                                 fn_2b70d54
02ce2260: mov     x0, x22                                    
02ce2264: ldp     x20, x19, [sp, #0x20]                      
02ce2268: ldp     x22, x21, [sp, #0x10]                      
02ce226c: ldp     x30, x23, [sp], #0x30                      
02ce2270: ret                                                
## StartSpin(System.Action onComplete) -> void
---- LuckyWheelPopup::StartSpin 0x2ce229c
02ce229c: str     x30, [sp, #-0x30]!                         
02ce22a0: stp     x22, x21, [sp, #0x10]                      
02ce22a4: stp     x20, x19, [sp, #0x20]                      
02ce22a8: adrp    x20, #0x662f000                            
02ce22ac: adrp    x22, #0x6268000                            
02ce22b0: mov     x21, x1                                    
02ce22b4: ldrb    w8, [x20, #0xdbd]                          
02ce22b8: ldr     x22, [x22, #0x28]                          T:LuckyWheelPopup/<>c__DisplayClass52_0
02ce22bc: mov     x19, x0                                    
02ce22c0: tbnz    w8, #0, #0x2ce2308                         
02ce22c4: adrp    x0, #0x6265000                             
02ce22c8: ldr     x0, [x0, #0x310]                           MS:WejoyService.Singleton`1::get_Instance
02ce22cc: bl      #0x2b70db0                                 fn_2b70db0
02ce22d0: adrp    x0, #0x6268000                             
02ce22d4: ldr     x0, [x0, #0x30]                            M:LuckyWheelPopup/<>c__DisplayClass52_0::<StartSpin>b__0
02ce22d8: bl      #0x2b70db0                                 fn_2b70db0
02ce22dc: adrp    x0, #0x6268000                             
02ce22e0: ldr     x0, [x0, #0x28]                            T:LuckyWheelPopup/<>c__DisplayClass52_0
02ce22e4: bl      #0x2b70db0                                 fn_2b70db0
02ce22e8: adrp    x0, #0x6265000                             
02ce22ec: ldr     x0, [x0, #0x3f0]                           T:UnityEngine.Events.UnityAction
02ce22f0: bl      #0x2b70db0                                 fn_2b70db0
02ce22f4: adrp    x0, #0x6267000                             
02ce22f8: ldr     x0, [x0, #0xea8]                           T:Framework.Vibration
02ce22fc: bl      #0x2b70db0                                 fn_2b70db0
02ce2300: mov     w8, #1                                     
02ce2304: strb    w8, [x20, #0xdbd]                          
02ce2308: ldr     x0, [x22]                                  S:'{0}/2'
02ce230c: bl      #0x2b7104c                                 fn_2b7104c
02ce2310: mov     x1, xzr                                    
02ce2314: mov     x20, x0                                    
02ce2318: bl      #0x4e53e9c                                 System.Object::.ctor
02ce231c: cbz     x20, #0x2ce2470                            
02ce2320: adrp    x22, #0x6265000                            
02ce2324: mov     x0, x20                                    
02ce2328: mov     x1, x19                                    
02ce232c: ldr     x22, [x22, #0x310]                         MS:WejoyService.Singleton`1::get_Instance
02ce2330: str     x19, [x0, #0x10]!                          
02ce2334: bl      #0x2b70d54                                 fn_2b70d54
02ce2338: mov     x0, x20                                    
02ce233c: mov     x1, x21                                    
02ce2340: str     x21, [x0, #0x20]!                          
02ce2344: bl      #0x2b70d54                                 fn_2b70d54
02ce2348: ldr     x0, [x22]                                  M:AdsManager::<OnApplicationPause>b__26_0
02ce234c: bl      #0x3be7218                                 fn_3be7218
02ce2350: cbz     x0, #0x2ce2470                             
02ce2354: mov     x1, xzr                                    
02ce2358: bl      #0x2c8a7a4                                 AdsManager::ShowCollap
02ce235c: ldr     x0, [x19, #0x58]                           ._spinButton
02ce2360: cbz     x0, #0x2ce2470                             
02ce2364: mov     w1, wzr                                    
02ce2368: mov     x2, xzr                                    
02ce236c: bl      #0x5e662d4                                 UnityEngine.UI.Selectable::set_interactable
02ce2370: mov     x0, x19                                    
02ce2374: bl      #0x2ce1f18                                 LuckyWheelPopup::StopButtonSpinAnim
02ce2378: mov     x0, xzr                                    
02ce237c: bl      #0x2d6eec8                                 Framework.AudioManager::get_Instance
02ce2380: cbz     x0, #0x2ce2470                             
02ce2384: movi    d1, #0000000000000000                      
02ce2388: movi    d2, #0000000000000000                      
02ce238c: adrp    x21, #0x6267000                            
02ce2390: fmov    s0, #1.00000000                            
02ce2394: ldr     x21, [x21, #0xea8]                         T:Framework.Vibration
02ce2398: mov     w1, #0x31                                  
02ce239c: mov     w2, wzr                                    
02ce23a0: mov     w3, wzr                                    
02ce23a4: mov     x4, xzr                                    
02ce23a8: bl      #0x2d6f03c                                 Framework.AudioManager::PlaySound
02ce23ac: ldr     x0, [x21]                                  S:'didu'
02ce23b0: ldr     w8, [x0, #0xe4]                            [62670e4]=0 f=0,0
02ce23b4: cbnz    w8, #0x2ce23bc                             
02ce23b8: bl      #0x2b70f30                                 fn_2b70f30
02ce23bc: mov     w0, #0x64                                  
02ce23c0: mov     w1, #-1                                    
02ce23c4: mov     w2, wzr                                    
02ce23c8: mov     x3, xzr                                    
02ce23cc: bl      #0x2d6e144                                 Framework.Vibration::Vibrate
02ce23d0: ldr     x0, [x19, #0x48]                           ._btnClose
02ce23d4: cbz     x0, #0x2ce2470                             
02ce23d8: mov     x1, xzr                                    
02ce23dc: bl      #0x5b339ec                                 UnityEngine.Component::get_gameObject
02ce23e0: cbz     x0, #0x2ce2470                             
02ce23e4: mov     w1, wzr                                    
02ce23e8: mov     x2, xzr                                    
02ce23ec: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02ce23f0: mov     w8, #1                                     
02ce23f4: strb    w8, [x19, #0xf4]                           ._isSpinning
02ce23f8: bl      #0x2ce175c                                 LuckyWheelPopup::get_ConfigSO
02ce23fc: cbz     x0, #0x2ce2470                             
02ce2400: mov     x1, xzr                                    
02ce2404: bl      #0x2ca8694                                 LuckyWheelConfigSO::GetRandomReward
02ce2408: mov     x21, x20                                   
02ce240c: mov     x1, x0                                     
02ce2410: str     x0, [x21, #0x18]!                          
02ce2414: mov     x0, x21                                    
02ce2418: bl      #0x2b70d54                                 fn_2b70d54
02ce241c: ldr     x8, [x21]                                  S:'didu'
02ce2420: cbz     x8, #0x2ce2470                             
02ce2424: adrp    x9, #0x6265000                             
02ce2428: adrp    x22, #0x6268000                            
02ce242c: ldr     x9, [x9, #0x3f0]                           T:UnityEngine.Events.UnityAction
02ce2430: ldr     x22, [x22, #0x30]                          M:LuckyWheelPopup/<>c__DisplayClass52_0::<StartSpin>b__0
02ce2434: ldr     x21, [x8, #0x10]                           
02ce2438: ldr     x0, [x9]                                   M:AdsManager::<OnApplicationPause>b__26_0
02ce243c: bl      #0x2b7104c                                 fn_2b7104c
02ce2440: ldr     x2, [x22]                                  S:'{0}/2'
02ce2444: mov     x1, x20                                    
02ce2448: mov     x3, xzr                                    
02ce244c: mov     x22, x0                                    
02ce2450: bl      #0x5b4cf98                                 UnityEngine.Events.UnityAction::.ctor
02ce2454: mov     x0, x19                                    
02ce2458: mov     x1, x21                                    
02ce245c: mov     x2, x22                                    
02ce2460: ldp     x20, x19, [sp, #0x20]                      
02ce2464: ldp     x22, x21, [sp, #0x10]                      
02ce2468: ldr     x30, [sp], #0x30                           
02ce246c: b       #0x2ce202c                                 LuckyWheelPopup::RunAnimation
02ce2470: bl      #0x2b7105c                                 fn_2b7105c
## GetRewardItem(System.Action onComplete) -> void
---- LuckyWheelPopup::GetRewardItem 0x2ce247c
02ce247c: sub     sp, sp, #0xa0                              
02ce2480: stp     x29, x30, [sp, #0x40]                      
02ce2484: stp     x28, x27, [sp, #0x50]                      
02ce2488: stp     x26, x25, [sp, #0x60]                      
02ce248c: stp     x24, x23, [sp, #0x70]                      
02ce2490: stp     x22, x21, [sp, #0x80]                      
02ce2494: stp     x20, x19, [sp, #0x90]                      
02ce2498: adrp    x22, #0x662f000                            
02ce249c: adrp    x20, #0x6268000                            
02ce24a0: mov     x21, x1                                    
02ce24a4: ldrb    w8, [x22, #0xdbe]                          
02ce24a8: ldr     x20, [x20, #0x38]                          T:LuckyWheelPopup/<>c__DisplayClass53_0 ._initSpinDuration
02ce24ac: mov     x19, x0                                    
02ce24b0: tbnz    w8, #0, #0x2ce25a0                         
02ce24b4: adrp    x0, #0x6264000                             
02ce24b8: ldr     x0, [x0, #0xf90]                           T:System.Action
02ce24bc: bl      #0x2b70db0                                 fn_2b70db0
02ce24c0: adrp    x0, #0x6266000                             
02ce24c4: ldr     x0, [x0, #0x750]                           MS:DataManager::GetData
02ce24c8: bl      #0x2b70db0                                 fn_2b70db0
02ce24cc: adrp    x0, #0x6268000                             
02ce24d0: ldr     x0, [x0, #0x40]                            MS:System.Collections.Generic.List`1/Enumerator::Dispose ._spinSpeed
02ce24d4: bl      #0x2b70db0                                 fn_2b70db0
02ce24d8: adrp    x0, #0x6268000                             
02ce24dc: ldr     x0, [x0, #0x48]                            MS:System.Collections.Generic.List`1/Enumerator::MoveNext ._btnClose
02ce24e0: bl      #0x2b70db0                                 fn_2b70db0
02ce24e4: adrp    x0, #0x6268000                             
02ce24e8: ldr     x0, [x0, #0x50]                            MS:System.Collections.Generic.List`1/Enumerator::get_Current ._btnClose2
02ce24ec: bl      #0x2b70db0                                 fn_2b70db0
02ce24f0: adrp    x0, #0x6268000                             
02ce24f4: ldr     x0, [x0, #0x58]                            MS:FrameWorkUtility::PickRandom ._spinButton
02ce24f8: bl      #0x2b70db0                                 fn_2b70db0
02ce24fc: adrp    x0, #0x6268000                             
02ce2500: ldr     x0, [x0, #0x60]                            MS:System.Collections.Generic.List`1::FindAll ._getCoinButton
02ce2504: bl      #0x2b70db0                                 fn_2b70db0
02ce2508: adrp    x0, #0x6268000                             
02ce250c: ldr     x0, [x0, #0x68]                            MS:System.Collections.Generic.List`1::GetEnumerator ._txtCoinGet
02ce2510: bl      #0x2b70db0                                 fn_2b70db0
02ce2514: adrp    x0, #0x6266000                             
02ce2518: ldr     x0, [x0, #0x658]                           MS:MonoSingleton`1::get_Instance
02ce251c: bl      #0x2b70db0                                 fn_2b70db0
02ce2520: adrp    x0, #0x6268000                             
02ce2524: ldr     x0, [x0, #0x70]                            T:type57276(k15) ._fxCoin
02ce2528: bl      #0x2b70db0                                 fn_2b70db0
02ce252c: adrp    x0, #0x6268000                             
02ce2530: ldr     x0, [x0, #0x78]                            M:LuckyWheelPopup/<>c::<GetRewardItem>b__53_0 ._textBlank
02ce2534: bl      #0x2b70db0                                 fn_2b70db0
02ce2538: adrp    x0, #0x6268000                             
02ce253c: ldr     x0, [x0, #0x80]                            M:LuckyWheelPopup/<>c::<GetRewardItem>b__53_3 ._wheelImage
02ce2540: bl      #0x2b70db0                                 fn_2b70db0
02ce2544: adrp    x0, #0x6268000                             
02ce2548: ldr     x0, [x0, #0x88]                            M:LuckyWheelPopup/<>c__DisplayClass53_0::<GetRewardItem>b__1 ._counterText
02ce254c: bl      #0x2b70db0                                 fn_2b70db0
02ce2550: adrp    x0, #0x6268000                             
02ce2554: ldr     x0, [x0, #0x90]                            M:LuckyWheelPopup/<>c__DisplayClass53_0::<GetRewardItem>b__2 ._getCoinButtonContent
02ce2558: bl      #0x2b70db0                                 fn_2b70db0
02ce255c: adrp    x0, #0x6268000                             
02ce2560: ldr     x0, [x0, #0x38]                            T:LuckyWheelPopup/<>c__DisplayClass53_0 ._initSpinDuration
02ce2564: bl      #0x2b70db0                                 fn_2b70db0
02ce2568: adrp    x0, #0x6268000                             
02ce256c: ldr     x0, [x0, #0x98]                            M:LuckyWheelPopup/<>c__DisplayClass53_1::<GetRewardItem>b__4 ._spineTextRect
02ce2570: bl      #0x2b70db0                                 fn_2b70db0
02ce2574: adrp    x0, #0x6268000                             
02ce2578: ldr     x0, [x0, #0xa0]                            T:LuckyWheelPopup/<>c__DisplayClass53_1 ._adsIconRect
02ce257c: bl      #0x2b70db0                                 fn_2b70db0
02ce2580: adrp    x0, #0x6268000                             
02ce2584: ldr     x0, [x0, #0xa8]                            T:LuckyWheelPopup/<>c ._blueButtonRect
02ce2588: bl      #0x2b70db0                                 fn_2b70db0
02ce258c: adrp    x0, #0x6268000                             
02ce2590: ldr     x0, [x0, #0xb0]                            S:'penguin_close_mouth' ._nodes
02ce2594: bl      #0x2b70db0                                 fn_2b70db0
02ce2598: mov     w8, #1                                     
02ce259c: strb    w8, [x22, #0xdbe]                          
02ce25a0: ldr     x0, [x20]                                  S:'{0}/2'
02ce25a4: stp     xzr, xzr, [sp, #0x20]                      
02ce25a8: str     xzr, [sp, #0x30]                           
02ce25ac: bl      #0x2b7104c                                 fn_2b7104c
02ce25b0: mov     x1, xzr                                    
02ce25b4: mov     x20, x0                                    
02ce25b8: bl      #0x4e53e9c                                 System.Object::.ctor
02ce25bc: cbz     x20, #0x2ce297c                            
02ce25c0: adrp    x24, #0x6268000                            
02ce25c4: mov     x0, x20                                    
02ce25c8: mov     x1, x19                                    
02ce25cc: ldr     x24, [x24, #0xa8]                          T:LuckyWheelPopup/<>c
02ce25d0: str     x19, [x0, #0x10]!                          
02ce25d4: bl      #0x2b70d54                                 fn_2b70d54
02ce25d8: mov     x0, x20                                    
02ce25dc: mov     x1, x21                                    
02ce25e0: str     x21, [x0, #0x18]!                          
02ce25e4: bl      #0x2b70d54                                 fn_2b70d54
02ce25e8: ldr     x0, [x24]                                  S:'{0}/2'
02ce25ec: ldr     x21, [x19, #0xb8]                          ._mysteryBoxes
02ce25f0: ldr     w8, [x0, #0xe4]                            [62680e4]=0 f=0,0
02ce25f4: cbnz    w8, #0x2ce2600                             
02ce25f8: bl      #0x2b70f30                                 fn_2b70f30
02ce25fc: ldr     x0, [x24]                                  S:'{0}/2'
02ce2600: ldr     x8, [x0, #0xb8]                            T:LuckyWheelPopup/<>c__DisplayClass54_0 ._mysteryBoxes
02ce2604: ldr     x22, [x8, #8]                              
02ce2608: cbnz    x22, #0x2ce2664                            
02ce260c: ldr     w9, [x0, #0xe4]                            [62680e4]=0 f=0,0
02ce2610: cbnz    w9, #0x2ce2620                             
02ce2614: bl      #0x2b70f30                                 fn_2b70f30
02ce2618: ldr     x8, [x24]                                  S:'{0}/2'
02ce261c: ldr     x8, [x8, #0xb8]                            
02ce2620: adrp    x9, #0x6268000                             
02ce2624: ldr     x9, [x9, #0x70]                            T:type57276(k15)
02ce2628: ldr     x23, [x8]                                  
02ce262c: ldr     x0, [x9]                                   S:'{0}/2'
02ce2630: bl      #0x2b7104c                                 fn_2b7104c
02ce2634: adrp    x8, #0x6268000                             
02ce2638: mov     x1, x23                                    
02ce263c: mov     x3, xzr                                    
02ce2640: ldr     x8, [x8, #0x78]                            M:LuckyWheelPopup/<>c::<GetRewardItem>b__53_0
02ce2644: mov     x22, x0                                    
02ce2648: ldr     x2, [x8]                                   S:'{0}/2'
02ce264c: bl      #0x399ba10                                 fn_399ba10
02ce2650: ldr     x8, [x24]                                  S:'{0}/2'
02ce2654: mov     x1, x22                                    
02ce2658: ldr     x0, [x8, #0xb8]                            T:LuckyWheelPopup/<>c__DisplayClass54_0
02ce265c: str     x22, [x0, #8]!                             
02ce2660: bl      #0x2b70d54                                 fn_2b70d54
02ce2664: cbz     x21, #0x2ce297c                            
02ce2668: adrp    x26, #0x6268000                            
02ce266c: adrp    x23, #0x6266000                            
02ce2670: mov     x0, x21                                    
02ce2674: ldr     x26, [x26, #0x60]                          MS:System.Collections.Generic.List`1::FindAll
02ce2678: ldr     x23, [x23, #0x658]                         MS:MonoSingleton`1::get_Instance
02ce267c: mov     x1, x22                                    
02ce2680: ldr     x2, [x26]                                  S:'{0}/2'
02ce2684: bl      #0x35a9914                                 fn_35a9914
02ce2688: ldr     x8, [x23]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ce268c: mov     x22, x0                                    
02ce2690: mov     x0, x8                                     
02ce2694: bl      #0x3769600                                 fn_3769600
02ce2698: cbz     x0, #0x2ce297c                             
02ce269c: adrp    x8, #0x6266000                             
02ce26a0: adrp    x25, #0x6264000                            
02ce26a4: adrp    x23, #0x6268000                            
02ce26a8: ldr     x8, [x8, #0x750]                           MS:DataManager::GetData
02ce26ac: adrp    x27, #0x6268000                            
02ce26b0: ldr     x25, [x25, #0xf90]                         T:System.Action
02ce26b4: ldr     x23, [x23, #0x88]                          M:LuckyWheelPopup/<>c__DisplayClass53_0::<GetRewardItem>b__1
02ce26b8: ldr     x27, [x27, #0xb0]                          S:'penguin_close_mouth'
02ce26bc: ldr     x1, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ce26c0: bl      #0x3168dd0                                 fn_3168dd0
02ce26c4: ldr     x8, [x25]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02ce26c8: mov     x21, x0                                    
02ce26cc: mov     x0, x8                                     
02ce26d0: bl      #0x2b7104c                                 fn_2b7104c
02ce26d4: ldr     x2, [x23]                                  S:'{0}/2'
02ce26d8: mov     x1, x20                                    
02ce26dc: mov     x3, xzr                                    
02ce26e0: mov     x23, x0                                    
02ce26e4: bl      #0x4d8ddbc                                 System.Action::.ctor
02ce26e8: ldr     x1, [x27]                                  S:'{0}/2'
02ce26ec: mov     x0, x19                                    
02ce26f0: mov     w2, wzr                                    
02ce26f4: mov     x3, x23                                    
02ce26f8: bl      #0x2ce1b80                                 LuckyWheelPopup::PlayAnimation
02ce26fc: cbz     x22, #0x2ce297c                            
02ce2700: adrp    x8, #0x6268000                             
02ce2704: adrp    x27, #0x6268000                            
02ce2708: adrp    x23, #0x6268000                            
02ce270c: ldr     x8, [x8, #0x68]                            MS:System.Collections.Generic.List`1::GetEnumerator
02ce2710: adrp    x28, #0x6268000                            
02ce2714: adrp    x29, #0x6268000                            
02ce2718: ldr     x27, [x27, #0x48]                          MS:System.Collections.Generic.List`1/Enumerator::MoveNext
02ce271c: ldr     x23, [x23, #0xa0]                          T:LuckyWheelPopup/<>c__DisplayClass53_1
02ce2720: ldr     x28, [x28, #0x58]                          MS:FrameWorkUtility::PickRandom
02ce2724: ldr     x29, [x29, #0x40]                          MS:System.Collections.Generic.List`1/Enumerator::Dispose
02ce2728: ldr     x1, [x8]                                   S:'{0}/2'
02ce272c: add     x8, sp, #8                                 
02ce2730: mov     x0, x22                                    
02ce2734: bl      #0x35a9d9c                                 fn_35a9d9c
02ce2738: ldr     x8, [sp, #0x18]                            
02ce273c: ldur    q0, [sp, #8]                               
02ce2740: str     x8, [sp, #0x30]                            
02ce2744: add     x8, sp, #0x20                              
02ce2748: str     q0, [sp, #0x20]                            
02ce274c: stp     xzr, x8, [sp, #8]                          
02ce2750: ldr     x1, [x27]                                  S:'{0}/2'
02ce2754: add     x0, sp, #0x20                              
02ce2758: bl      #0x4690474                                 fn_4690474
02ce275c: tbz     w0, #0, #0x2ce2814                         
02ce2760: ldr     x22, [sp, #0x30]                           
02ce2764: cbz     x22, #0x2ce2970                            
02ce2768: cbz     x21, #0x2ce2974                            
02ce276c: ldr     w1, [x22, #0x14]                           [662f014]=600001400000000 f=0,2.40742e-35
02ce2770: mov     x0, x21                                    
02ce2774: mov     x2, xzr                                    
02ce2778: bl      #0x2cabd24                                 DataUser::HasUnlockedKeycapDecor
02ce277c: tbnz    w0, #0, #0x2ce2750                         
02ce2780: ldr     x0, [x19, #0xd0]                           ._decorKeycapConfig
02ce2784: cbz     x0, #0x2ce2978                             
02ce2788: ldr     w1, [x22, #0x14]                           [662f014]=600001400000000 f=0,2.40742e-35
02ce278c: mov     x2, xzr                                    
02ce2790: bl      #0x2d5b618                                 Clicker.DecorKeycapConfig::GetData
02ce2794: cbz     x0, #0x2ce2750                             
02ce2798: ldr     x8, [x19, #0xc0]                           ._giftBoxLuckyWheel
02ce279c: cbz     x8, #0x2ce2980                             
02ce27a0: ldr     x1, [x0, #0x28]                            T:LuckyWheelPopup/<>c__DisplayClass52_0
02ce27a4: ldr     w2, [x0, #0x24]                            [6268024]=0 f=0,0
02ce27a8: mov     x0, x8                                     
02ce27ac: bl      #0x2ce0628                                 GiftBoxLuckyWheel::SetReward
02ce27b0: ldr     w1, [x22, #0x14]                           [662f014]=600001400000000 f=0,2.40742e-35
02ce27b4: mov     x0, x21                                    
02ce27b8: mov     x2, xzr                                    
02ce27bc: bl      #0x2cabc2c                                 DataUser::UnlockClickerDecor
02ce27c0: ldr     x1, [x29]                                  S:'{0}/2'
02ce27c4: add     x0, sp, #0x20                              
02ce27c8: bl      #0x4690470                                 fn_4690470
02ce27cc: ldr     x0, [x25]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02ce27d0: ldr     x21, [x19, #0xc0]                          ._giftBoxLuckyWheel
02ce27d4: bl      #0x2b7104c                                 fn_2b7104c
02ce27d8: adrp    x8, #0x6268000                             
02ce27dc: mov     x1, x20                                    
02ce27e0: mov     x3, xzr                                    
02ce27e4: ldr     x8, [x8, #0x90]                            M:LuckyWheelPopup/<>c__DisplayClass53_0::<GetRewardItem>b__2
02ce27e8: mov     x22, x0                                    
02ce27ec: ldr     x2, [x8]                                   S:'{0}/2'
02ce27f0: bl      #0x4d8ddbc                                 System.Action::.ctor
02ce27f4: cbz     x21, #0x2ce297c                            
02ce27f8: mov     x0, x21                                    
02ce27fc: mov     x1, x22                                    
02ce2800: bl      #0x2ce0b68                                 GiftBoxLuckyWheel::SetOnclickEvent
02ce2804: ldr     x0, [x19, #0xc0]                           ._giftBoxLuckyWheel
02ce2808: cbz     x0, #0x2ce297c                             
02ce280c: bl      #0x2ce0c70                                 GiftBoxLuckyWheel::AnimUnbox
02ce2810: b       #0x2ce2950                                 
02ce2814: ldr     x1, [x29]                                  S:'{0}/2'
02ce2818: add     x0, sp, #0x20                              
02ce281c: bl      #0x4690470                                 fn_4690470
02ce2820: ldr     x0, [x23]                                  S:'{0}/2'
02ce2824: bl      #0x2b7104c                                 fn_2b7104c
02ce2828: mov     x1, xzr                                    
02ce282c: mov     x21, x0                                    
02ce2830: bl      #0x4e53e9c                                 System.Object::.ctor
02ce2834: cbz     x21, #0x2ce297c                            
02ce2838: mov     x0, x21                                    
02ce283c: mov     x1, x20                                    
02ce2840: str     x20, [x0, #0x18]!                          
02ce2844: bl      #0x2b70d54                                 fn_2b70d54
02ce2848: ldr     x0, [x24]                                  S:'{0}/2'
02ce284c: ldr     x20, [x19, #0xb8]                          ._mysteryBoxes
02ce2850: ldr     w8, [x0, #0xe4]                            [62680e4]=0 f=0,0
02ce2854: cbnz    w8, #0x2ce2860                             
02ce2858: bl      #0x2b70f30                                 fn_2b70f30
02ce285c: ldr     x0, [x24]                                  S:'{0}/2'
02ce2860: ldr     x8, [x0, #0xb8]                            T:LuckyWheelPopup/<>c__DisplayClass54_0 ._mysteryBoxes
02ce2864: ldr     x22, [x8, #0x10]                           MS:DG.Tweening.TweenSettingsExtensions::SetLoops
02ce2868: cbnz    x22, #0x2ce28c4                            
02ce286c: ldr     w9, [x0, #0xe4]                            [62680e4]=0 f=0,0
02ce2870: cbnz    w9, #0x2ce2880                             
02ce2874: bl      #0x2b70f30                                 fn_2b70f30
02ce2878: ldr     x8, [x24]                                  S:'{0}/2'
02ce287c: ldr     x8, [x8, #0xb8]                            T:LuckyWheelPopup/<>c__DisplayClass54_0
02ce2880: adrp    x9, #0x6268000                             
02ce2884: ldr     x9, [x9, #0x70]                            T:type57276(k15)
02ce2888: ldr     x23, [x8]                                  S:'{0}/2'
02ce288c: ldr     x0, [x9]                                   S:'{0}/2'
02ce2890: bl      #0x2b7104c                                 fn_2b7104c
02ce2894: adrp    x8, #0x6268000                             
02ce2898: mov     x1, x23                                    
02ce289c: mov     x3, xzr                                    
02ce28a0: ldr     x8, [x8, #0x80]                            M:LuckyWheelPopup/<>c::<GetRewardItem>b__53_3
02ce28a4: mov     x22, x0                                    
02ce28a8: ldr     x2, [x8]                                   S:'{0}/2'
02ce28ac: bl      #0x399ba10                                 fn_399ba10
02ce28b0: ldr     x8, [x24]                                  S:'{0}/2'
02ce28b4: mov     x1, x22                                    
02ce28b8: ldr     x0, [x8, #0xb8]                            T:LuckyWheelPopup/<>c__DisplayClass54_0
02ce28bc: str     x22, [x0, #0x10]!                          
02ce28c0: bl      #0x2b70d54                                 fn_2b70d54
02ce28c4: cbz     x20, #0x2ce297c                            
02ce28c8: ldr     x2, [x26]                                  S:'{0}/2'
02ce28cc: mov     x0, x20                                    
02ce28d0: mov     x1, x22                                    
02ce28d4: bl      #0x35a9914                                 fn_35a9914
02ce28d8: ldr     x1, [x28]                                  S:'{0}/2'
02ce28dc: bl      #0x31cf844                                 fn_31cf844
02ce28e0: mov     x20, x21                                   
02ce28e4: mov     x1, x0                                     
02ce28e8: str     x0, [x20, #0x10]!                          
02ce28ec: mov     x0, x20                                    
02ce28f0: bl      #0x2b70d54                                 fn_2b70d54
02ce28f4: ldr     x8, [x20]                                  S:'{0}/2'
02ce28f8: cbz     x8, #0x2ce297c                             
02ce28fc: ldr     x0, [x19, #0xc0]                           ._giftBoxLuckyWheel
02ce2900: cbz     x0, #0x2ce297c                             
02ce2904: ldr     w1, [x8, #0x14]                            [6268014]=0 f=0,0
02ce2908: bl      #0x2ce0944                                 GiftBoxLuckyWheel::SetRewardCoin
02ce290c: ldr     x0, [x19, #0xc0]                           ._giftBoxLuckyWheel
02ce2910: cbz     x0, #0x2ce297c                             
02ce2914: bl      #0x2ce0c70                                 GiftBoxLuckyWheel::AnimUnbox
02ce2918: ldr     x0, [x25]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02ce291c: ldr     x19, [x19, #0xc0]                          ._giftBoxLuckyWheel
02ce2920: bl      #0x2b7104c                                 fn_2b7104c
02ce2924: adrp    x8, #0x6268000                             
02ce2928: mov     x1, x21                                    
02ce292c: mov     x3, xzr                                    
02ce2930: ldr     x8, [x8, #0x98]                            M:LuckyWheelPopup/<>c__DisplayClass53_1::<GetRewardItem>b__4
02ce2934: mov     x20, x0                                    
02ce2938: ldr     x2, [x8]                                   S:'{0}/2'
02ce293c: bl      #0x4d8ddbc                                 System.Action::.ctor
02ce2940: cbz     x19, #0x2ce297c                            
02ce2944: mov     x0, x19                                    
02ce2948: mov     x1, x20                                    
02ce294c: bl      #0x2ce0b68                                 GiftBoxLuckyWheel::SetOnclickEvent
02ce2950: ldp     x20, x19, [sp, #0x90]                      
02ce2954: ldp     x22, x21, [sp, #0x80]                      
02ce2958: ldp     x24, x23, [sp, #0x70]                      
02ce295c: ldp     x26, x25, [sp, #0x60]                      
02ce2960: ldp     x28, x27, [sp, #0x50]                      
02ce2964: ldp     x29, x30, [sp, #0x40]                      
02ce2968: add     sp, sp, #0xa0                              
02ce296c: ret                                                
02ce2970: bl      #0x2b7105c                                 fn_2b7105c
02ce2974: bl      #0x2b7105c                                 fn_2b7105c
02ce2978: bl      #0x2b7105c                                 fn_2b7105c
02ce297c: bl      #0x2b7105c                                 fn_2b7105c
02ce2980: bl      #0x2b7105c                                 fn_2b7105c
02ce2984: b       #0x2ce29a0                                 
02ce2988: b       #0x2ce29a0                                 
02ce298c: b       #0x2ce29a0                                 
02ce2990: b       #0x2ce29a0                                 
02ce2994: b       #0x2ce29a0                                 
02ce2998: b       #0x2ce29a0                                 
02ce299c: b       #0x2ce29a0                                 
02ce29a0: mov     x21, x0                                    
02ce29a4: cmp     w1, #1                                     
02ce29a8: b.ne    #0x2ce29dc                                 
02ce29ac: mov     x0, x21                                    
02ce29b0: bl      #0x5e90260                                 fn_5e90260
02ce29b4: ldr     x21, [x0]                                  S:'{0}/2'
02ce29b8: str     x21, [sp, #8]                              
02ce29bc: bl      #0x5e90270                                 fn_5e90270
02ce29c0: ldr     x0, [sp, #0x10]                            
02ce29c4: ldr     x1, [x29]                                  S:'{0}/2'
02ce29c8: bl      #0x4690470                                 fn_4690470
02ce29cc: cbz     x21, #0x2ce2820                            
02ce29d0: mov     x0, x21                                    
02ce29d4: bl      #0x2b71054                                 fn_2b71054
02ce29d8: mov     x21, x0                                    
02ce29dc: add     x0, sp, #8                                 
02ce29e0: bl      #0x2737890                                 fn_2737890
02ce29e4: mov     x0, x21                                    
02ce29e8: bl      #0x2c6051c                                 fn_2c6051c
02ce29ec: bl      #0x27369b8                                 fn_27369b8
## GetMoney(int amount, System.Action onComplete) -> void
---- LuckyWheelPopup::GetMoney 0x2ce2a00
02ce2a00: sub     sp, sp, #0x40                              
02ce2a04: stp     x30, x23, [sp, #0x10]                      
02ce2a08: stp     x22, x21, [sp, #0x20]                      
02ce2a0c: stp     x20, x19, [sp, #0x30]                      
02ce2a10: adrp    x20, #0x662f000                            
02ce2a14: adrp    x23, #0x6268000                            
02ce2a18: mov     x22, x2                                    
02ce2a1c: ldrb    w8, [x20, #0xdbf]                          
02ce2a20: ldr     x23, [x23, #0xb8]                          T:LuckyWheelPopup/<>c__DisplayClass54_0
02ce2a24: mov     w21, w1                                    
02ce2a28: mov     x19, x0                                    
02ce2a2c: str     w1, [sp, #0xc]                             
02ce2a30: tbnz    w8, #0, #0x2ce2a84                         
02ce2a34: adrp    x0, #0x6266000                             
02ce2a38: ldr     x0, [x0, #0xaa0]                           MS:MonoSingleton`1::get_Instance
02ce2a3c: bl      #0x2b70db0                                 fn_2b70db0
02ce2a40: adrp    x0, #0x6264000                             
02ce2a44: ldr     x0, [x0, #0xe8]                            T:DG.Tweening.TweenCallback ._onAnimCompleteEvent
02ce2a48: bl      #0x2b70db0                                 fn_2b70db0
02ce2a4c: adrp    x0, #0x6268000                             
02ce2a50: ldr     x0, [x0, #0xc0]                            M:LuckyWheelPopup/<>c__DisplayClass54_0::<GetMoney>b__0 ._giftBoxLuckyWheel
02ce2a54: bl      #0x2b70db0                                 fn_2b70db0
02ce2a58: adrp    x0, #0x6268000                             
02ce2a5c: ldr     x0, [x0, #0xc8]                            M:LuckyWheelPopup/<>c__DisplayClass54_0::<GetMoney>b__1 ._configSO
02ce2a60: bl      #0x2b70db0                                 fn_2b70db0
02ce2a64: adrp    x0, #0x6268000                             
02ce2a68: ldr     x0, [x0, #0xb8]                            T:LuckyWheelPopup/<>c__DisplayClass54_0 ._mysteryBoxes
02ce2a6c: bl      #0x2b70db0                                 fn_2b70db0
02ce2a70: adrp    x0, #0x6265000                             
02ce2a74: ldr     x0, [x0, #0x3f0]                           T:UnityEngine.Events.UnityAction
02ce2a78: bl      #0x2b70db0                                 fn_2b70db0
02ce2a7c: mov     w8, #1                                     
02ce2a80: strb    w8, [x20, #0xdbf]                          
02ce2a84: ldr     x0, [x23]                                  S:'{0}/2'
02ce2a88: bl      #0x2b7104c                                 fn_2b7104c
02ce2a8c: mov     x1, xzr                                    
02ce2a90: mov     x20, x0                                    
02ce2a94: bl      #0x4e53e9c                                 System.Object::.ctor
02ce2a98: cbz     x20, #0x2ce2bf4                            
02ce2a9c: adrp    x23, #0x6266000                            
02ce2aa0: mov     x0, x20                                    
02ce2aa4: mov     x1, x19                                    
02ce2aa8: ldr     x23, [x23, #0xaa0]                         MS:MonoSingleton`1::get_Instance
02ce2aac: str     x19, [x0, #0x10]!                          
02ce2ab0: bl      #0x2b70d54                                 fn_2b70d54
02ce2ab4: mov     x0, x20                                    
02ce2ab8: mov     x1, x22                                    
02ce2abc: str     x22, [x0, #0x18]!                          
02ce2ac0: bl      #0x2b70d54                                 fn_2b70d54
02ce2ac4: ldr     x0, [x23]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ce2ac8: bl      #0x3769600                                 fn_3769600
02ce2acc: cbz     x0, #0x2ce2bf4                             
02ce2ad0: mov     w1, w21                                    
02ce2ad4: bl      #0x2cdac78                                 MoneyManager::UpdateMoney
02ce2ad8: ldr     x8, [x19, #0x60]                           ._getCoinButton
02ce2adc: cbz     x8, #0x2ce2bf4                             
02ce2ae0: ldr     x0, [x8, #0x100]                           
02ce2ae4: cbz     x0, #0x2ce2bf4                             
02ce2ae8: mov     x1, xzr                                    
02ce2aec: bl      #0x5b4ce48                                 UnityEngine.Events.UnityEventBase::RemoveAllListeners
02ce2af0: ldr     x8, [x19, #0x60]                           ._getCoinButton
02ce2af4: cbz     x8, #0x2ce2bf4                             
02ce2af8: adrp    x9, #0x6265000                             
02ce2afc: adrp    x22, #0x6268000                            
02ce2b00: ldr     x9, [x9, #0x3f0]                           T:UnityEngine.Events.UnityAction
02ce2b04: ldr     x22, [x22, #0xc0]                          M:LuckyWheelPopup/<>c__DisplayClass54_0::<GetMoney>b__0
02ce2b08: ldr     x21, [x8, #0x100]                          
02ce2b0c: ldr     x0, [x9]                                   M:AdsManager::<OnApplicationPause>b__26_0
02ce2b10: bl      #0x2b7104c                                 fn_2b7104c
02ce2b14: ldr     x2, [x22]                                  S:'{0}/2'
02ce2b18: mov     x1, x20                                    
02ce2b1c: mov     x3, xzr                                    
02ce2b20: mov     x22, x0                                    
02ce2b24: bl      #0x5b4cf98                                 UnityEngine.Events.UnityAction::.ctor
02ce2b28: cbz     x21, #0x2ce2bf4                            
02ce2b2c: mov     x0, x21                                    
02ce2b30: mov     x1, x22                                    
02ce2b34: mov     x2, xzr                                    
02ce2b38: bl      #0x5b4d0ac                                 UnityEngine.Events.UnityEvent::AddListener
02ce2b3c: ldr     x21, [x19, #0x68]                          ._txtCoinGet
02ce2b40: add     x0, sp, #0xc                               
02ce2b44: mov     x1, xzr                                    
02ce2b48: bl      #0x4e0ea3c                                 System.Int32::ToString
02ce2b4c: cbz     x21, #0x2ce2bf4                            
02ce2b50: ldr     x8, [x21]                                  
02ce2b54: mov     x1, x0                                     
02ce2b58: mov     x0, x21                                    
02ce2b5c: ldr     x9, [x8, #0x558]                           
02ce2b60: ldr     x2, [x8, #0x560]                           
02ce2b64: blr     x9                                         
02ce2b68: ldr     x0, [x19, #0x70]                           ._fxCoin
02ce2b6c: cbz     x0, #0x2ce2bf4                             
02ce2b70: ldr     w8, [sp, #0xc]                             
02ce2b74: mov     w9, #0x5556                                
02ce2b78: adrp    x19, #0x6264000                            
02ce2b7c: movk    w9, #0x5555, lsl #16                       
02ce2b80: adrp    x21, #0x6268000                            
02ce2b84: ldr     x19, [x19, #0xe8]                          T:DG.Tweening.TweenCallback ._onAnimCompleteEvent
02ce2b88: lsl     w8, w8, #1                                 
02ce2b8c: ldr     x21, [x21, #0xc8]                          M:LuckyWheelPopup/<>c__DisplayClass54_0::<GetMoney>b__1 ._configSO
02ce2b90: mov     x1, xzr                                    
02ce2b94: smull   x8, w8, w9                                 
02ce2b98: lsr     x9, x8, #0x3f                              
02ce2b9c: lsr     x8, x8, #0x20                              
02ce2ba0: add     w8, w8, w9                                 
02ce2ba4: scvtf   s0, w8                                     
02ce2ba8: str     s0, [x0, #0x708]                           
02ce2bac: bl      #0x4f86b74                                 AssetKits.ParticleImage.ParticleImage::Play
02ce2bb0: ldr     x0, [x19]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02ce2bb4: bl      #0x2b7104c                                 fn_2b7104c
02ce2bb8: ldr     x2, [x21]                                  S:'{0}/2'
02ce2bbc: mov     x1, x20                                    
02ce2bc0: mov     x3, xzr                                    
02ce2bc4: mov     x19, x0                                    
02ce2bc8: bl      #0x2d89dc4                                 DG.Tweening.TweenCallback::.ctor
02ce2bcc: fmov    s0, #1.50000000                            
02ce2bd0: mov     x0, x19                                    
02ce2bd4: mov     w1, #1                                     
02ce2bd8: mov     x2, xzr                                    
02ce2bdc: bl      #0x2d8f37c                                 DG.Tweening.DOVirtual::DelayedCall
02ce2be0: ldp     x20, x19, [sp, #0x30]                      
02ce2be4: ldp     x22, x21, [sp, #0x20]                      
02ce2be8: ldp     x30, x23, [sp, #0x10]                      
02ce2bec: add     sp, sp, #0x40                              
02ce2bf0: ret                                                
02ce2bf4: bl      #0x2b7105c                                 fn_2b7105c
## ShowLuckyWheel() -> Cysharp.Threading.Tasks.UniTask
---- LuckyWheelPopup::ShowLuckyWheel 0x2ce2c00
02ce2c00: sub     sp, sp, #0x50                              
02ce2c04: stp     x30, x21, [sp, #0x30]                      
02ce2c08: stp     x20, x19, [sp, #0x40]                      
02ce2c0c: adrp    x20, #0x662f000                            
02ce2c10: adrp    x21, #0x6268000                            
02ce2c14: mov     x19, x0                                    
02ce2c18: ldrb    w8, [x20, #0xdc0]                          
02ce2c1c: ldr     x21, [x21, #0xd0]                          MS:Cysharp.Threading.Tasks.CompilerServices.AsyncUniTaskMethodBuilder::Start ._decorKeycapConfig
02ce2c20: tbnz    w8, #0, #0x2ce2c38                         
02ce2c24: adrp    x0, #0x6268000                             
02ce2c28: ldr     x0, [x0, #0xd0]                            MS:Cysharp.Threading.Tasks.CompilerServices.AsyncUniTaskMethodBuilder::Start ._decorKeycapConfig
02ce2c2c: bl      #0x2b70db0                                 fn_2b70db0
02ce2c30: mov     w8, #1                                     
02ce2c34: strb    w8, [x20, #0xdc0]                          
02ce2c38: movi    v0.2d, #0000000000000000                   
02ce2c3c: mov     x20, sp                                    
02ce2c40: mov     x1, xzr                                    
02ce2c44: orr     x0, x20, #8                                
02ce2c48: stp     q0, q0, [sp, #0x10]                        
02ce2c4c: str     q0, [sp]                                   
02ce2c50: bl      #0x2b70d54                                 fn_2b70d54
02ce2c54: add     x0, x20, #0x18                             &662f018
02ce2c58: mov     x1, x19                                    
02ce2c5c: str     x19, [sp, #0x18]                           
02ce2c60: bl      #0x2b70d54                                 fn_2b70d54
02ce2c64: ldr     x0, [x21]                                  S:'{0}/2'
02ce2c68: mov     w9, #-1                                    
02ce2c6c: str     w9, [sp]                                   
02ce2c70: ldr     x8, [x0, #0x38]                            T:LuckyWheelPopup/<>c__DisplayClass53_0 ._initSpinDuration
02ce2c74: cbnz    x8, #0x2ce2c7c                             
02ce2c78: bl      #0x2ba9d7c                                 fn_2ba9d7c
02ce2c7c: mov     x0, sp                                     
02ce2c80: bl      #0x2ce46e0                                 LuckyWheelPopup/<ShowLuckyWheel>d__55::MoveNext
02ce2c84: orr     x0, x20, #8                                
02ce2c88: mov     x1, xzr                                    
02ce2c8c: bl      #0x2ceadb0                                 fn_2ceadb0
02ce2c90: ldp     x20, x19, [sp, #0x40]                      
02ce2c94: ldp     x30, x21, [sp, #0x30]                      
02ce2c98: add     sp, sp, #0x50                              
02ce2c9c: ret                                                
## StartButtonSpinAnim(UnityEngine.Transform button) -> void
---- LuckyWheelPopup::StartButtonSpinAnim 0x2ce2ca0
02ce2ca0: stp     x30, x21, [sp, #-0x20]!                    
02ce2ca4: stp     x20, x19, [sp, #0x10]                      
02ce2ca8: adrp    x21, #0x662f000                            
02ce2cac: mov     x19, x1                                    
02ce2cb0: mov     x20, x0                                    
02ce2cb4: ldrb    w8, [x21, #0xdc1]                          
02ce2cb8: tbnz    w8, #0, #0x2ce2cdc                         
02ce2cbc: adrp    x0, #0x6266000                             
02ce2cc0: ldr     x0, [x0, #0x880]                           MS:DG.Tweening.TweenSettingsExtensions::SetEase
02ce2cc4: bl      #0x2b70db0                                 fn_2b70db0
02ce2cc8: adrp    x0, #0x6268000                             
02ce2ccc: ldr     x0, [x0, #0x10]                            MS:DG.Tweening.TweenSettingsExtensions::SetLoops
02ce2cd0: bl      #0x2b70db0                                 fn_2b70db0
02ce2cd4: mov     w8, #1                                     
02ce2cd8: strb    w8, [x21, #0xdc1]                          
02ce2cdc: cbz     x19, #0x2ce2db8                            
02ce2ce0: mov     x0, x19                                    
02ce2ce4: mov     x1, xzr                                    
02ce2ce8: bl      #0x5b339ec                                 UnityEngine.Component::get_gameObject
02ce2cec: cbz     x0, #0x2ce2db8                             
02ce2cf0: mov     w1, #1                                     
02ce2cf4: mov     x2, xzr                                    
02ce2cf8: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02ce2cfc: ldr     x0, [x20, #0x78]                           ._textBlank
02ce2d00: cbz     x0, #0x2ce2db8                             
02ce2d04: mov     x1, xzr                                    
02ce2d08: bl      #0x5b339ec                                 UnityEngine.Component::get_gameObject
02ce2d0c: cbz     x0, #0x2ce2db8                             
02ce2d10: mov     w1, #1                                     
02ce2d14: mov     x2, xzr                                    
02ce2d18: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02ce2d1c: ldr     x0, [x20, #0x48]                           ._btnClose
02ce2d20: cbz     x0, #0x2ce2db8                             
02ce2d24: mov     x1, xzr                                    
02ce2d28: bl      #0x5b339ec                                 UnityEngine.Component::get_gameObject
02ce2d2c: cbz     x0, #0x2ce2db8                             
02ce2d30: mov     w1, #1                                     
02ce2d34: mov     x2, xzr                                    
02ce2d38: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02ce2d3c: ldr     x0, [x20, #0x50]                           ._btnClose2
02ce2d40: cbz     x0, #0x2ce2db8                             
02ce2d44: mov     x1, xzr                                    
02ce2d48: bl      #0x5b339ec                                 UnityEngine.Component::get_gameObject
02ce2d4c: cbz     x0, #0x2ce2db8                             
02ce2d50: adrp    x20, #0x6268000                            
02ce2d54: adrp    x21, #0x6266000                            
02ce2d58: mov     w1, #1                                     
02ce2d5c: ldr     x20, [x20, #0x10]                          MS:DG.Tweening.TweenSettingsExtensions::SetLoops
02ce2d60: ldr     x21, [x21, #0x880]                         MS:DG.Tweening.TweenSettingsExtensions::SetEase
02ce2d64: mov     x2, xzr                                    
02ce2d68: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02ce2d6c: mov     x0, x19                                    
02ce2d70: mov     w1, wzr                                    
02ce2d74: mov     x2, xzr                                    
02ce2d78: bl      #0x2d9d5d0                                 DG.Tweening.ShortcutExtensions::DOKill
02ce2d7c: adrp    x8, #0x1084000                             
02ce2d80: fmov    s1, #0.50000000                            
02ce2d84: mov     x0, x19                                    
02ce2d88: ldr     s0, [x8, #0xcfc]                           [1084cfc]=3e58658c3f8ccccd f=1.1,0.211325
02ce2d8c: mov     x1, xzr                                    
02ce2d90: bl      #0x2d98fd4                                 DG.Tweening.ShortcutExtensions::DOScaleY
02ce2d94: ldr     x3, [x20]                                  S:'{0}/2'
02ce2d98: mov     w1, #-1                                    
02ce2d9c: mov     w2, #1                                     
02ce2da0: bl      #0x336fe74                                 fn_336fe74
02ce2da4: ldp     x20, x19, [sp, #0x10]                      
02ce2da8: mov     w1, #0x1c                                  
02ce2dac: ldr     x2, [x21]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ce2db0: ldp     x30, x21, [sp], #0x20                      
02ce2db4: b       #0x336fa0c                                 
02ce2db8: bl      #0x2b7105c                                 fn_2b7105c
## ActiveButtonBack() -> void
---- LuckyWheelPopup::ActiveButtonBack 0x2ce2dbc
02ce2dbc: stp     x30, x19, [sp, #-0x10]!                    
02ce2dc0: mov     x19, x0                                    
02ce2dc4: ldr     x0, [x0, #0x58]                            ._spinButton
02ce2dc8: cbz     x0, #0x2ce2dfc                             
02ce2dcc: mov     w1, #1                                     
02ce2dd0: mov     x2, xzr                                    
02ce2dd4: bl      #0x5e662d4                                 UnityEngine.UI.Selectable::set_interactable
02ce2dd8: adrp    x9, #0x1084000                             
02ce2ddc: ldr     x0, [x19, #0xa8]                           ._blueButtonRect
02ce2de0: mov     w8, #0x42540000                            
02ce2de4: ldr     s1, [x9, #0xf10]                           [1084f10]=4110bc863e99999a f=0.3,9.04603
02ce2de8: fmov    s0, w8                                     
02ce2dec: mov     w1, wzr                                    
02ce2df0: mov     x2, xzr                                    
02ce2df4: ldp     x30, x19, [sp], #0x10                      
02ce2df8: b       #0x2c79c1c                                 DG.Tweening.DOTweenModuleUI::DOAnchorPosY
02ce2dfc: bl      #0x2b7105c                                 fn_2b7105c
## StopButtonSpinAnim() -> void
---- LuckyWheelPopup::StopButtonSpinAnim 0x2ce1f18
02ce1f18: stp     x30, x21, [sp, #-0x20]!                    
02ce1f1c: stp     x20, x19, [sp, #0x10]                      
02ce1f20: mov     x19, x0                                    
02ce1f24: ldr     x0, [x0, #0x58]                            ._spinButton
02ce1f28: cbz     x0, #0x2ce1fe4                             
02ce1f2c: mov     x1, xzr                                    
02ce1f30: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02ce1f34: mov     w1, wzr                                    
02ce1f38: mov     x2, xzr                                    
02ce1f3c: bl      #0x2d9d5d0                                 DG.Tweening.ShortcutExtensions::DOKill
02ce1f40: ldr     x0, [x19, #0x58]                           ._spinButton
02ce1f44: cbz     x0, #0x2ce1fe4                             
02ce1f48: mov     x1, xzr                                    
02ce1f4c: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02ce1f50: adrp    x21, #0x662f000                            
02ce1f54: mov     x20, x0                                    
02ce1f58: ldrb    w8, [x21, #0xa74]                          
02ce1f5c: cbnz    w8, #0x2ce1f74                             
02ce1f60: adrp    x0, #0x6264000                             
02ce1f64: ldr     x0, [x0, #0xd8]                            T:UnityEngine.Vector3 ._pinginSpine
02ce1f68: bl      #0x2b70db0                                 fn_2b70db0
02ce1f6c: mov     w8, #1                                     
02ce1f70: strb    w8, [x21, #0xa74]                          
02ce1f74: cbz     x20, #0x2ce1fe4                            
02ce1f78: adrp    x8, #0x6264000                             
02ce1f7c: mov     x0, x20                                    
02ce1f80: mov     x1, xzr                                    
02ce1f84: ldr     x8, [x8, #0xd8]                            T:UnityEngine.Vector3
02ce1f88: ldr     x8, [x8]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02ce1f8c: ldr     x8, [x8, #0xb8]                            MS:DG.Tweening.Core.Extensions::SetSpecialStartupMode
02ce1f90: ldp     s1, s2, [x8, #0x10]                        
02ce1f94: ldr     s0, [x8, #0xc]                             [626400c]=0 f=0,0
02ce1f98: bl      #0x5b470cc                                 UnityEngine.Transform::set_localScale
02ce1f9c: ldr     x0, [x19, #0x78]                           ._textBlank
02ce1fa0: cbz     x0, #0x2ce1fe4                             
02ce1fa4: mov     x1, xzr                                    
02ce1fa8: bl      #0x5b339ec                                 UnityEngine.Component::get_gameObject
02ce1fac: cbz     x0, #0x2ce1fe4                             
02ce1fb0: mov     w1, wzr                                    
02ce1fb4: mov     x2, xzr                                    
02ce1fb8: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02ce1fbc: ldr     x0, [x19, #0x50]                           ._btnClose2
02ce1fc0: cbz     x0, #0x2ce1fe4                             
02ce1fc4: mov     x1, xzr                                    
02ce1fc8: bl      #0x5b339ec                                 UnityEngine.Component::get_gameObject
02ce1fcc: cbz     x0, #0x2ce1fe4                             
02ce1fd0: ldp     x20, x19, [sp, #0x10]                      
02ce1fd4: mov     w1, wzr                                    
02ce1fd8: mov     x2, xzr                                    
02ce1fdc: ldp     x30, x21, [sp], #0x20                      
02ce1fe0: b       #0x5b36b38                                 UnityEngine.GameObject::SetActive
02ce1fe4: bl      #0x2b7105c                                 fn_2b7105c
## CanFreeSpin() -> bool
---- LuckyWheelPopup::CanFreeSpin 0x2ce2e00
02ce2e00: str     x30, [sp, #-0x30]!                         
02ce2e04: stp     x22, x21, [sp, #0x10]                      
02ce2e08: stp     x20, x19, [sp, #0x20]                      
02ce2e0c: adrp    x21, #0x662f000                            
02ce2e10: adrp    x20, #0x6267000                            
02ce2e14: mov     x19, x0                                    
02ce2e18: ldrb    w8, [x21, #0xdc2]                          
02ce2e1c: ldr     x20, [x20, #0xfa8]                         S:'LastFreeSpinTime'
02ce2e20: tbnz    w8, #0, #0x2ce2e50                         
02ce2e24: adrp    x0, #0x6266000                             
02ce2e28: ldr     x0, [x0, #0x128]                           T:System.DateTime
02ce2e2c: bl      #0x2b70db0                                 fn_2b70db0
02ce2e30: adrp    x0, #0x6265000                             
02ce2e34: ldr     x0, [x0, #0xf98]                           T:System.TimeSpan
02ce2e38: bl      #0x2b70db0                                 fn_2b70db0
02ce2e3c: adrp    x0, #0x6267000                             
02ce2e40: ldr     x0, [x0, #0xfa8]                           S:'LastFreeSpinTime'
02ce2e44: bl      #0x2b70db0                                 fn_2b70db0
02ce2e48: mov     w8, #1                                     
02ce2e4c: strb    w8, [x21, #0xdc2]                          
02ce2e50: ldr     x0, [x20]                                  S:'didu'
02ce2e54: mov     x1, xzr                                    
02ce2e58: bl      #0x5b2d73c                                 UnityEngine.PlayerPrefs::HasKey
02ce2e5c: tbz     w0, #0, #0x2ce2ef0                         
02ce2e60: adrp    x22, #0x6266000                            
02ce2e64: adrp    x21, #0x6265000                            
02ce2e68: mov     x1, xzr                                    
02ce2e6c: ldr     x22, [x22, #0x128]                         T:System.DateTime
02ce2e70: ldr     x21, [x21, #0xf98]                         T:System.TimeSpan
02ce2e74: ldr     x0, [x20]                                  S:'didu'
02ce2e78: bl      #0x5b2d6f4                                 UnityEngine.PlayerPrefs::GetString
02ce2e7c: ldr     x8, [x22]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ce2e80: mov     x20, x0                                    
02ce2e84: ldr     w9, [x8, #0xe4]                            
02ce2e88: cbnz    w9, #0x2ce2e94                             
02ce2e8c: mov     x0, x8                                     
02ce2e90: bl      #0x2b70f30                                 fn_2b70f30
02ce2e94: mov     x0, x20                                    
02ce2e98: mov     x1, xzr                                    
02ce2e9c: bl      #0x4df2914                                 System.DateTime::Parse
02ce2ea0: mov     x20, x0                                    
02ce2ea4: mov     x0, xzr                                    
02ce2ea8: bl      #0x4df25c8                                 System.DateTime::get_Now
02ce2eac: mov     x1, x20                                    
02ce2eb0: mov     x2, xzr                                    
02ce2eb4: bl      #0x4df3fb4                                 System.DateTime::op_Subtraction
02ce2eb8: ldr     x8, [x21]                                  M:AdsManager::<OnApplicationPause>b__26_0
02ce2ebc: ldr     x19, [x19, #0x100]                         ._cooldown
02ce2ec0: mov     x20, x0                                    
02ce2ec4: ldr     w9, [x8, #0xe4]                            
02ce2ec8: cbnz    w9, #0x2ce2ed4                             
02ce2ecc: mov     x0, x8                                     
02ce2ed0: bl      #0x2b70f30                                 fn_2b70f30
02ce2ed4: mov     x0, x20                                    
02ce2ed8: mov     x1, x19                                    
02ce2edc: mov     x2, xzr                                    
02ce2ee0: ldp     x20, x19, [sp, #0x20]                      
02ce2ee4: ldp     x22, x21, [sp, #0x10]                      
02ce2ee8: ldr     x30, [sp], #0x30                           
02ce2eec: b       #0x4e29f60                                 System.TimeSpan::op_GreaterThanOrEqual
02ce2ef0: ldp     x20, x19, [sp, #0x20]                      
02ce2ef4: mov     w0, #1                                     
02ce2ef8: ldp     x22, x21, [sp, #0x10]                      
02ce2efc: ldr     x30, [sp], #0x30                           
02ce2f00: ret                                                
## GetRemainingTimeForFreeSpin() -> System.TimeSpan
---- LuckyWheelPopup::GetRemainingTimeForFreeSpin 0x2ce2f04
02ce2f04: str     x30, [sp, #-0x30]!                         
02ce2f08: stp     x22, x21, [sp, #0x10]                      
02ce2f0c: stp     x20, x19, [sp, #0x20]                      
02ce2f10: adrp    x21, #0x662f000                            
02ce2f14: adrp    x20, #0x6267000                            
02ce2f18: mov     x19, x0                                    
02ce2f1c: ldrb    w8, [x21, #0xdc3]                          
02ce2f20: ldr     x20, [x20, #0xfa8]                         S:'LastFreeSpinTime'
02ce2f24: tbnz    w8, #0, #0x2ce2f54                         
02ce2f28: adrp    x0, #0x6266000                             
02ce2f2c: ldr     x0, [x0, #0x128]                           T:System.DateTime
02ce2f30: bl      #0x2b70db0                                 fn_2b70db0
02ce2f34: adrp    x0, #0x6265000                             
02ce2f38: ldr     x0, [x0, #0xf98]                           T:System.TimeSpan
02ce2f3c: bl      #0x2b70db0                                 fn_2b70db0
02ce2f40: adrp    x0, #0x6267000                             
02ce2f44: ldr     x0, [x0, #0xfa8]                           S:'LastFreeSpinTime'
02ce2f48: bl      #0x2b70db0                                 fn_2b70db0
02ce2f4c: mov     w8, #1                                     
02ce2f50: strb    w8, [x21, #0xdc3]                          
02ce2f54: adrp    x21, #0x6265000                            
02ce2f58: mov     x1, xzr                                    
02ce2f5c: ldr     x21, [x21, #0xf98]                         T:System.TimeSpan
02ce2f60: ldr     x0, [x20]                                  S:'didu'
02ce2f64: bl      #0x5b2d73c                                 UnityEngine.PlayerPrefs::HasKey
02ce2f68: tbz     w0, #0, #0x2ce2ff4                         
02ce2f6c: adrp    x22, #0x6266000                            
02ce2f70: mov     x1, xzr                                    
02ce2f74: ldr     x22, [x22, #0x128]                         T:System.DateTime
02ce2f78: ldr     x0, [x20]                                  S:'didu'
02ce2f7c: bl      #0x5b2d6f4                                 UnityEngine.PlayerPrefs::GetString
02ce2f80: ldr     x8, [x22]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ce2f84: mov     x20, x0                                    
02ce2f88: ldr     w9, [x8, #0xe4]                            
02ce2f8c: cbnz    w9, #0x2ce2f98                             
02ce2f90: mov     x0, x8                                     
02ce2f94: bl      #0x2b70f30                                 fn_2b70f30
02ce2f98: mov     x0, x20                                    
02ce2f9c: mov     x1, xzr                                    
02ce2fa0: bl      #0x4df2914                                 System.DateTime::Parse
02ce2fa4: mov     x20, x0                                    
02ce2fa8: mov     x0, xzr                                    
02ce2fac: bl      #0x4df25c8                                 System.DateTime::get_Now
02ce2fb0: mov     x1, x20                                    
02ce2fb4: mov     x2, xzr                                    
02ce2fb8: bl      #0x4df3fb4                                 System.DateTime::op_Subtraction
02ce2fbc: ldr     x8, [x21]                                  M:AdsManager::<OnApplicationPause>b__26_0
02ce2fc0: ldr     x20, [x19, #0x100]                         ._cooldown
02ce2fc4: mov     x19, x0                                    
02ce2fc8: ldr     w9, [x8, #0xe4]                            
02ce2fcc: cbnz    w9, #0x2ce2fd8                             
02ce2fd0: mov     x0, x8                                     
02ce2fd4: bl      #0x2b70f30                                 fn_2b70f30
02ce2fd8: mov     x0, x20                                    
02ce2fdc: mov     x1, x19                                    
02ce2fe0: mov     x2, xzr                                    
02ce2fe4: ldp     x20, x19, [sp, #0x20]                      
02ce2fe8: ldp     x22, x21, [sp, #0x10]                      
02ce2fec: ldr     x30, [sp], #0x30                           
02ce2ff0: b       #0x4e29e54                                 System.TimeSpan::op_Subtraction
02ce2ff4: ldr     x0, [x21]                                  M:AdsManager::<OnApplicationPause>b__26_0
02ce2ff8: ldr     w8, [x0, #0xe4]                            [62670e4]=0 f=0,0
02ce2ffc: cbnz    w8, #0x2ce3008                             
02ce3000: bl      #0x2b70f30                                 fn_2b70f30
02ce3004: ldr     x0, [x21]                                  M:AdsManager::<OnApplicationPause>b__26_0
02ce3008: ldr     x8, [x0, #0xb8]                            M:Framework.SceneUtils/<CRUnloadSceneAsync>d__2::System.Collections.IEnumerator.Reset ._mysteryBoxes
02ce300c: ldp     x20, x19, [sp, #0x20]                      
02ce3010: ldp     x22, x21, [sp, #0x10]                      
02ce3014: ldr     x0, [x8]                                   
02ce3018: ldr     x30, [sp], #0x30                           
02ce301c: ret                                                
## StopCountdown() -> void
---- LuckyWheelPopup::StopCountdown 0x2ce1fe8
02ce1fe8: str     x30, [sp, #-0x20]!                         
02ce1fec: stp     x20, x19, [sp, #0x10]                      
02ce1ff0: mov     x20, x0                                    
02ce1ff4: ldr     x1, [x20, #0xf8]!                          ._countdownCoroutine
02ce1ff8: cbz     x1, #0x2ce2020                             
02ce1ffc: mov     x2, xzr                                    
02ce2000: mov     x19, x0                                    
02ce2004: bl      #0x5b38c4c                                 UnityEngine.MonoBehaviour::StopCoroutine
02ce2008: mov     x0, x20                                    
02ce200c: str     xzr, [x19, #0xf8]                          ._countdownCoroutine
02ce2010: mov     x1, xzr                                    
02ce2014: ldp     x20, x19, [sp, #0x10]                      
02ce2018: ldr     x30, [sp], #0x20                           
02ce201c: b       #0x2b70d54                                 
02ce2020: ldp     x20, x19, [sp, #0x10]                      
02ce2024: ldr     x30, [sp], #0x20                           
02ce2028: ret                                                
## StartFreeSpin() -> void
---- LuckyWheelPopup::StartFreeSpin 0x2ce3020
02ce3020: str     x30, [sp, #-0x30]!                         
02ce3024: stp     x22, x21, [sp, #0x10]                      
02ce3028: stp     x20, x19, [sp, #0x20]                      
02ce302c: adrp    x21, #0x662f000                            
02ce3030: adrp    x20, #0x6266000                            
02ce3034: mov     x19, x0                                    
02ce3038: ldrb    w8, [x21, #0xdc4]                          
02ce303c: ldr     x20, [x20, #0x128]                         T:System.DateTime
02ce3040: tbnz    w8, #0, #0x2ce3088                         
02ce3044: adrp    x0, #0x6264000                             
02ce3048: ldr     x0, [x0, #0xf90]                           T:System.Action
02ce304c: bl      #0x2b70db0                                 fn_2b70db0
02ce3050: adrp    x0, #0x6266000                             
02ce3054: ldr     x0, [x0, #0x128]                           T:System.DateTime
02ce3058: bl      #0x2b70db0                                 fn_2b70db0
02ce305c: adrp    x0, #0x6268000                             
02ce3060: ldr     x0, [x0, #0xe0]                            M:LuckyWheelPopup/<>c::<StartFreeSpin>b__62_0 ._trackEntry
02ce3064: bl      #0x2b70db0                                 fn_2b70db0
02ce3068: adrp    x0, #0x6268000                             
02ce306c: ldr     x0, [x0, #0xa8]                            T:LuckyWheelPopup/<>c ._blueButtonRect
02ce3070: bl      #0x2b70db0                                 fn_2b70db0
02ce3074: adrp    x0, #0x6267000                             
02ce3078: ldr     x0, [x0, #0xfa8]                           S:'LastFreeSpinTime'
02ce307c: bl      #0x2b70db0                                 fn_2b70db0
02ce3080: mov     w8, #1                                     
02ce3084: strb    w8, [x21, #0xdc4]                          
02ce3088: ldr     x0, [x20]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ce308c: adrp    x20, #0x6267000                            
02ce3090: adrp    x22, #0x6268000                            
02ce3094: ldr     x20, [x20, #0xfa8]                         S:'LastFreeSpinTime'
02ce3098: ldr     w8, [x0, #0xe4]                            [62670e4]=0 f=0,0
02ce309c: ldr     x22, [x22, #0xa8]                          T:LuckyWheelPopup/<>c
02ce30a0: str     xzr, [sp, #8]                              
02ce30a4: cbnz    w8, #0x2ce30ac                             
02ce30a8: bl      #0x2b70f30                                 fn_2b70f30
02ce30ac: mov     x0, xzr                                    
02ce30b0: bl      #0x4df25c8                                 System.DateTime::get_Now
02ce30b4: str     x0, [sp, #8]                               
02ce30b8: add     x0, sp, #8                                 
02ce30bc: mov     x1, xzr                                    
02ce30c0: bl      #0x4df3550                                 System.DateTime::ToString
02ce30c4: ldr     x8, [x20]                                  S:'didu'
02ce30c8: mov     x1, x0                                     
02ce30cc: mov     x2, xzr                                    
02ce30d0: mov     x0, x8                                     
02ce30d4: bl      #0x5b2d398                                 UnityEngine.PlayerPrefs::SetString
02ce30d8: mov     x0, xzr                                    
02ce30dc: bl      #0x5b2d914                                 UnityEngine.PlayerPrefs::Save
02ce30e0: ldr     x0, [x22]                                  S:'{0}/2'
02ce30e4: ldr     w8, [x0, #0xe4]                            [62670e4]=0 f=0,0
02ce30e8: cbnz    w8, #0x2ce30f4                             
02ce30ec: bl      #0x2b70f30                                 fn_2b70f30
02ce30f0: ldr     x0, [x22]                                  S:'{0}/2'
02ce30f4: ldr     x8, [x0, #0xb8]                            M:Framework.SceneUtils/<CRUnloadSceneAsync>d__2::System.Collections.IEnumerator.Reset ._mysteryBoxes
02ce30f8: ldr     x20, [x8, #0x18]                           
02ce30fc: cbnz    x20, #0x2ce3158                            
02ce3100: ldr     w9, [x0, #0xe4]                            [62670e4]=0 f=0,0
02ce3104: cbnz    w9, #0x2ce3114                             
02ce3108: bl      #0x2b70f30                                 fn_2b70f30
02ce310c: ldr     x8, [x22]                                  S:'{0}/2'
02ce3110: ldr     x8, [x8, #0xb8]                            
02ce3114: adrp    x9, #0x6264000                             
02ce3118: ldr     x9, [x9, #0xf90]                           T:System.Action
02ce311c: ldr     x21, [x8]                                  
02ce3120: ldr     x0, [x9]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02ce3124: bl      #0x2b7104c                                 fn_2b7104c
02ce3128: adrp    x8, #0x6268000                             
02ce312c: mov     x1, x21                                    
02ce3130: mov     x3, xzr                                    
02ce3134: ldr     x8, [x8, #0xe0]                            M:LuckyWheelPopup/<>c::<StartFreeSpin>b__62_0
02ce3138: mov     x20, x0                                    
02ce313c: ldr     x2, [x8]                                   S:'{0}/2'
02ce3140: bl      #0x4d8ddbc                                 System.Action::.ctor
02ce3144: ldr     x8, [x22]                                  S:'{0}/2'
02ce3148: mov     x1, x20                                    
02ce314c: ldr     x0, [x8, #0xb8]                            T:LuckyWheelPopup/<>c__DisplayClass54_0
02ce3150: str     x20, [x0, #0x18]!                          
02ce3154: bl      #0x2b70d54                                 fn_2b70d54
02ce3158: cbz     x19, #0x2ce3178                            
02ce315c: mov     x0, x19                                    
02ce3160: mov     x1, x20                                    
02ce3164: bl      #0x2ce229c                                 LuckyWheelPopup::StartSpin
02ce3168: ldp     x20, x19, [sp, #0x20]                      
02ce316c: ldp     x22, x21, [sp, #0x10]                      
02ce3170: ldr     x30, [sp], #0x30                           
02ce3174: ret                                                
02ce3178: bl      #0x2b7105c                                 fn_2b7105c
## OnSpinFreeButtonClick() -> void
---- LuckyWheelPopup::OnSpinFreeButtonClick 0x2ce317c
02ce317c: str     x30, [sp, #-0x20]!                         
02ce3180: stp     x20, x19, [sp, #0x10]                      
02ce3184: adrp    x20, #0x662f000                            
02ce3188: mov     x19, x0                                    
02ce318c: ldrb    w8, [x20, #0xdc5]                          
02ce3190: tbnz    w8, #0, #0x2ce31a8                         
02ce3194: adrp    x0, #0x6267000                             
02ce3198: ldr     x0, [x0, #0xd50]                           MS:MonoSingleton`1::get_Instance
02ce319c: bl      #0x2b70db0                                 fn_2b70db0
02ce31a0: mov     w8, #1                                     
02ce31a4: strb    w8, [x20, #0xdc5]                          
02ce31a8: mov     x0, xzr                                    
02ce31ac: bl      #0x2d6eec8                                 Framework.AudioManager::get_Instance
02ce31b0: cbz     x0, #0x2ce3204                             
02ce31b4: movi    d1, #0000000000000000                      
02ce31b8: movi    d2, #0000000000000000                      
02ce31bc: adrp    x20, #0x6267000                            
02ce31c0: fmov    s0, #1.00000000                            
02ce31c4: ldr     x20, [x20, #0xd50]                         MS:MonoSingleton`1::get_Instance
02ce31c8: mov     w1, #1                                     
02ce31cc: mov     w2, wzr                                    
02ce31d0: mov     w3, wzr                                    
02ce31d4: mov     x4, xzr                                    
02ce31d8: bl      #0x2d6f03c                                 Framework.AudioManager::PlaySound
02ce31dc: ldr     x0, [x20]                                  S:'didu'
02ce31e0: bl      #0x3769600                                 fn_3769600
02ce31e4: cbz     x0, #0x2ce3204                             
02ce31e8: mov     w1, #4                                     
02ce31ec: mov     x2, xzr                                    
02ce31f0: bl      #0x2cc6ee0                                 Framework.VibrationManager::Haptic
02ce31f4: mov     x0, x19                                    
02ce31f8: ldp     x20, x19, [sp, #0x10]                      
02ce31fc: ldr     x30, [sp], #0x20                           
02ce3200: b       #0x2ce3020                                 LuckyWheelPopup::StartFreeSpin
02ce3204: bl      #0x2b7105c                                 fn_2b7105c
## OnSpinButtonClick() -> void
---- LuckyWheelPopup::OnSpinButtonClick 0x2ce3208
02ce3208: stp     x30, x21, [sp, #-0x20]!                    
02ce320c: stp     x20, x19, [sp, #0x10]                      
02ce3210: adrp    x20, #0x662f000                            
02ce3214: adrp    x21, #0x6266000                            
02ce3218: mov     x19, x0                                    
02ce321c: ldrb    w8, [x20, #0xdc6]                          
02ce3220: ldr     x21, [x21, #0x658]                         MS:MonoSingleton`1::get_Instance
02ce3224: tbnz    w8, #0, #0x2ce3284                         
02ce3228: adrp    x0, #0x6264000                             
02ce322c: ldr     x0, [x0, #0xf90]                           T:System.Action
02ce3230: bl      #0x2b70db0                                 fn_2b70db0
02ce3234: adrp    x0, #0x6266000                             
02ce3238: ldr     x0, [x0, #0x750]                           MS:DataManager::GetData
02ce323c: bl      #0x2b70db0                                 fn_2b70db0
02ce3240: adrp    x0, #0x6268000                             
02ce3244: ldr     x0, [x0, #0xe8]                            M:LuckyWheelPopup::<OnSpinButtonClick>b__64_0 ._onAnimCompleteEvent
02ce3248: bl      #0x2b70db0                                 fn_2b70db0
02ce324c: adrp    x0, #0x6267000                             
02ce3250: ldr     x0, [x0, #0xd50]                           MS:MonoSingleton`1::get_Instance
02ce3254: bl      #0x2b70db0                                 fn_2b70db0
02ce3258: adrp    x0, #0x6266000                             
02ce325c: ldr     x0, [x0, #0x658]                           MS:MonoSingleton`1::get_Instance
02ce3260: bl      #0x2b70db0                                 fn_2b70db0
02ce3264: adrp    x0, #0x6265000                             
02ce3268: ldr     x0, [x0, #0x310]                           MS:WejoyService.Singleton`1::get_Instance
02ce326c: bl      #0x2b70db0                                 fn_2b70db0
02ce3270: adrp    x0, #0x6268000                             
02ce3274: ldr     x0, [x0, #0xf0]                            S:'spin' ._timer
02ce3278: bl      #0x2b70db0                                 fn_2b70db0
02ce327c: mov     w8, #1                                     
02ce3280: strb    w8, [x20, #0xdc6]                          
02ce3284: ldr     x0, [x21]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ce3288: bl      #0x3769600                                 fn_3769600
02ce328c: cbz     x0, #0x2ce338c                             
02ce3290: adrp    x8, #0x6266000                             
02ce3294: ldr     x8, [x8, #0x750]                           MS:DataManager::GetData
02ce3298: ldr     x1, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ce329c: bl      #0x3168dd0                                 fn_3168dd0
02ce32a0: cbz     x0, #0x2ce338c                             
02ce32a4: mov     x1, xzr                                    
02ce32a8: bl      #0x2caaf84                                 DataUser::get_Tracking
02ce32ac: cbz     x0, #0x2ce338c                             
02ce32b0: mov     x1, xzr                                    
02ce32b4: bl      #0x2caaec0                                 TrackingPlayTime::AddSpin
02ce32b8: mov     x0, xzr                                    
02ce32bc: bl      #0x2d6eec8                                 Framework.AudioManager::get_Instance
02ce32c0: cbz     x0, #0x2ce338c                             
02ce32c4: movi    d1, #0000000000000000                      
02ce32c8: movi    d2, #0000000000000000                      
02ce32cc: adrp    x20, #0x6267000                            
02ce32d0: fmov    s0, #1.00000000                            
02ce32d4: ldr     x20, [x20, #0xd50]                         MS:MonoSingleton`1::get_Instance
02ce32d8: mov     w1, #1                                     
02ce32dc: mov     w2, wzr                                    
02ce32e0: mov     w3, wzr                                    
02ce32e4: mov     x4, xzr                                    
02ce32e8: bl      #0x2d6f03c                                 Framework.AudioManager::PlaySound
02ce32ec: ldr     x0, [x20]                                  S:'didu'
02ce32f0: bl      #0x3769600                                 fn_3769600
02ce32f4: cbz     x0, #0x2ce338c                             
02ce32f8: mov     w1, #4                                     
02ce32fc: mov     x2, xzr                                    
02ce3300: bl      #0x2cc6ee0                                 Framework.VibrationManager::Haptic
02ce3304: ldrb    w8, [x19, #0xf5]                           ._isAdOn
02ce3308: cbz     w8, #0x2ce3378                             
02ce330c: adrp    x8, #0x6265000                             
02ce3310: adrp    x20, #0x6264000                            
02ce3314: adrp    x21, #0x6268000                            
02ce3318: ldr     x8, [x8, #0x310]                           MS:WejoyService.Singleton`1::get_Instance
02ce331c: ldr     x20, [x20, #0xf90]                         T:System.Action
02ce3320: ldr     x21, [x21, #0xe8]                          M:LuckyWheelPopup::<OnSpinButtonClick>b__64_0 ._onAnimCompleteEvent
02ce3324: ldr     x0, [x8]                                   M:AdsManager::<OnApplicationPause>b__26_0
02ce3328: bl      #0x3be7218                                 fn_3be7218
02ce332c: ldr     x8, [x20]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02ce3330: mov     x20, x0                                    
02ce3334: mov     x0, x8                                     
02ce3338: bl      #0x2b7104c                                 fn_2b7104c
02ce333c: ldr     x2, [x21]                                  S:'{0}/2'
02ce3340: mov     x1, x19                                    
02ce3344: mov     x3, xzr                                    
02ce3348: mov     x21, x0                                    
02ce334c: bl      #0x4d8ddbc                                 System.Action::.ctor
02ce3350: cbz     x20, #0x2ce338c                            
02ce3354: adrp    x8, #0x6268000                             
02ce3358: mov     x0, x20                                    
02ce335c: mov     x2, x21                                    
02ce3360: ldr     x8, [x8, #0xf0]                            S:'spin'
02ce3364: ldp     x20, x19, [sp, #0x10]                      
02ce3368: mov     x3, xzr                                    
02ce336c: ldr     x1, [x8]                                   S:'{0}/2'
02ce3370: ldp     x30, x21, [sp], #0x20                      
02ce3374: b       #0x2c8a2c0                                 AdsManager::ShowRewarded
02ce3378: mov     x0, x19                                    
02ce337c: ldp     x20, x19, [sp, #0x10]                      
02ce3380: mov     x1, xzr                                    
02ce3384: ldp     x30, x21, [sp], #0x20                      
02ce3388: b       #0x2ce229c                                 LuckyWheelPopup::StartSpin
02ce338c: bl      #0x2b7105c                                 fn_2b7105c
## OnButtonCloseClicked() -> void
---- LuckyWheelPopup::OnButtonCloseClicked 0x2ce3390
02ce3390: str     x30, [sp, #-0x30]!                         
02ce3394: stp     x22, x21, [sp, #0x10]                      
02ce3398: stp     x20, x19, [sp, #0x20]                      
02ce339c: adrp    x20, #0x662f000                            
02ce33a0: mov     x19, x0                                    
02ce33a4: ldrb    w8, [x20, #0xdc7]                          
02ce33a8: tbnz    w8, #0, #0x2ce33e4                         
02ce33ac: adrp    x0, #0x6264000                             
02ce33b0: ldr     x0, [x0, #0xf90]                           T:System.Action
02ce33b4: bl      #0x2b70db0                                 fn_2b70db0
02ce33b8: adrp    x0, #0x6268000                             
02ce33bc: ldr     x0, [x0, #0xf8]                            M:LuckyWheelPopup::<OnButtonCloseClicked>b__65_0 ._countdownCoroutine
02ce33c0: bl      #0x2b70db0                                 fn_2b70db0
02ce33c4: adrp    x0, #0x6265000                             
02ce33c8: ldr     x0, [x0, #0x310]                           MS:WejoyService.Singleton`1::get_Instance
02ce33cc: bl      #0x2b70db0                                 fn_2b70db0
02ce33d0: adrp    x0, #0x6268000                             
02ce33d4: ldr     x0, [x0, #0x100]                           S:'close_lucky_wheel' ._cooldown
02ce33d8: bl      #0x2b70db0                                 fn_2b70db0
02ce33dc: mov     w8, #1                                     
02ce33e0: strb    w8, [x20, #0xdc7]                          
02ce33e4: mov     x0, xzr                                    
02ce33e8: bl      #0x2d6eec8                                 Framework.AudioManager::get_Instance
02ce33ec: cbz     x0, #0x2ce3484                             
02ce33f0: movi    d1, #0000000000000000                      
02ce33f4: movi    d2, #0000000000000000                      
02ce33f8: adrp    x20, #0x6265000                            
02ce33fc: fmov    s0, #1.00000000                            
02ce3400: adrp    x21, #0x6264000                            
02ce3404: adrp    x22, #0x6268000                            
02ce3408: ldr     x20, [x20, #0x310]                         MS:WejoyService.Singleton`1::get_Instance
02ce340c: ldr     x21, [x21, #0xf90]                         T:System.Action
02ce3410: ldr     x22, [x22, #0xf8]                          M:LuckyWheelPopup::<OnButtonCloseClicked>b__65_0
02ce3414: mov     w1, #1                                     
02ce3418: mov     w2, wzr                                    
02ce341c: mov     w3, wzr                                    
02ce3420: mov     x4, xzr                                    
02ce3424: bl      #0x2d6f03c                                 Framework.AudioManager::PlaySound
02ce3428: ldr     x0, [x20]                                  M:AdsManager::<OnApplicationPause>b__26_0
02ce342c: bl      #0x3be7218                                 fn_3be7218
02ce3430: ldr     x8, [x21]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02ce3434: mov     x20, x0                                    
02ce3438: mov     x0, x8                                     
02ce343c: bl      #0x2b7104c                                 fn_2b7104c
02ce3440: ldr     x2, [x22]                                  S:'{0}/2'
02ce3444: mov     x1, x19                                    
02ce3448: mov     x3, xzr                                    
02ce344c: mov     x21, x0                                    
02ce3450: bl      #0x4d8ddbc                                 System.Action::.ctor
02ce3454: cbz     x20, #0x2ce3484                            
02ce3458: adrp    x8, #0x6268000                             
02ce345c: mov     x0, x20                                    
02ce3460: mov     x2, x21                                    
02ce3464: ldr     x8, [x8, #0x100]                           S:'close_lucky_wheel'
02ce3468: ldp     x20, x19, [sp, #0x20]                      
02ce346c: ldp     x22, x21, [sp, #0x10]                      
02ce3470: mov     w3, wzr                                    
02ce3474: ldr     x1, [x8]                                   S:'{0}/2'
02ce3478: mov     x4, xzr                                    
02ce347c: ldr     x30, [sp], #0x30                           
02ce3480: b       #0x2c89698                                 AdsManager::ShowInter
02ce3484: bl      #0x2b7105c                                 fn_2b7105c
## PlayAnimation(string animationName, bool loop, System.Action onComplete) -> void
---- LuckyWheelPopup::PlayAnimation 0x2ce1b80
02ce1b80: stp     x30, x25, [sp, #-0x40]!                    
02ce1b84: stp     x24, x23, [sp, #0x10]                      
02ce1b88: stp     x22, x21, [sp, #0x20]                      
02ce1b8c: stp     x20, x19, [sp, #0x30]                      
02ce1b90: adrp    x20, #0x662f000                            
02ce1b94: adrp    x21, #0x6267000                            
02ce1b98: mov     x24, x3                                    
02ce1b9c: ldrb    w8, [x20, #0xdc8]                          
02ce1ba0: ldr     x21, [x21, #0xfd8]                         T:LuckyWheelPopup/<>c__DisplayClass66_0
02ce1ba4: mov     w23, w2                                    
02ce1ba8: mov     x22, x1                                    
02ce1bac: mov     x19, x0                                    
02ce1bb0: tbnz    w8, #0, #0x2ce1c04                         
02ce1bb4: adrp    x0, #0x6267000                             
02ce1bb8: ldr     x0, [x0, #0xfe0]                           M:LuckyWheelPopup::OnAnimComplete
02ce1bbc: bl      #0x2b70db0                                 fn_2b70db0
02ce1bc0: adrp    x0, #0x6266000                             
02ce1bc4: ldr     x0, [x0, #0xbf0]                           T:Spine.AnimationState/TrackEntryDelegate
02ce1bc8: bl      #0x2b70db0                                 fn_2b70db0
02ce1bcc: adrp    x0, #0x6267000                             
02ce1bd0: ldr     x0, [x0, #0xfe8]                           M:LuckyWheelPopup/<>c__DisplayClass66_0::<PlayAnimation>b__0
02ce1bd4: bl      #0x2b70db0                                 fn_2b70db0
02ce1bd8: adrp    x0, #0x6267000                             
02ce1bdc: ldr     x0, [x0, #0xfd8]                           T:LuckyWheelPopup/<>c__DisplayClass66_0
02ce1be0: bl      #0x2b70db0                                 fn_2b70db0
02ce1be4: adrp    x0, #0x6265000                             
02ce1be8: ldr     x0, [x0, #0x3f0]                           T:UnityEngine.Events.UnityAction
02ce1bec: bl      #0x2b70db0                                 fn_2b70db0
02ce1bf0: adrp    x0, #0x6267000                             
02ce1bf4: ldr     x0, [x0, #0xff0]                           T:UnityEngine.Events.UnityEvent
02ce1bf8: bl      #0x2b70db0                                 fn_2b70db0
02ce1bfc: mov     w8, #1                                     
02ce1c00: strb    w8, [x20, #0xdc8]                          
02ce1c04: ldr     x0, [x21]                                  S:'didu'
02ce1c08: bl      #0x2b7104c                                 fn_2b7104c
02ce1c0c: mov     x1, xzr                                    
02ce1c10: mov     x20, x0                                    
02ce1c14: bl      #0x4e53e9c                                 System.Object::.ctor
02ce1c18: cbz     x20, #0x2ce1d60                            
02ce1c1c: mov     x21, x20                                   
02ce1c20: mov     x1, x24                                    
02ce1c24: str     x24, [x21, #0x10]!                         
02ce1c28: mov     x0, x21                                    
02ce1c2c: bl      #0x2b70d54                                 fn_2b70d54
02ce1c30: ldr     x0, [x19, #0xd8]                           ._pinginSpine
02ce1c34: cbz     x0, #0x2ce1d60                             
02ce1c38: mov     x1, xzr                                    
02ce1c3c: bl      #0x4ff9be0                                 Spine.Unity.SkeletonGraphic::get_AnimationState
02ce1c40: cbz     x0, #0x2ce1d60                             
02ce1c44: adrp    x24, #0x6266000                            
02ce1c48: adrp    x25, #0x6267000                            
02ce1c4c: and     w3, w23, #1                                
02ce1c50: ldr     x24, [x24, #0xbf0]                         T:Spine.AnimationState/TrackEntryDelegate
02ce1c54: ldr     x25, [x25, #0xfe0]                         M:LuckyWheelPopup::OnAnimComplete
02ce1c58: mov     w1, wzr                                    
02ce1c5c: mov     x2, x22                                    
02ce1c60: mov     x4, xzr                                    
02ce1c64: bl      #0x4f97234                                 Spine.AnimationState::SetAnimation
02ce1c68: mov     x22, x19                                   
02ce1c6c: mov     x1, x0                                     
02ce1c70: str     x0, [x22, #0xe0]!                          
02ce1c74: mov     x0, x22                                    
02ce1c78: bl      #0x2b70d54                                 fn_2b70d54
02ce1c7c: ldr     x0, [x24]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ce1c80: ldr     x22, [x22]                                 
02ce1c84: bl      #0x2b7104c                                 fn_2b7104c
02ce1c88: ldr     x2, [x25]                                  S:'didu'
02ce1c8c: mov     x1, x19                                    
02ce1c90: mov     x3, xzr                                    
02ce1c94: mov     x23, x0                                    
02ce1c98: bl      #0x4f98140                                 Spine.AnimationState/TrackEntryDelegate::.ctor
02ce1c9c: cbz     x22, #0x2ce1d60                            
02ce1ca0: mov     x0, x22                                    
02ce1ca4: mov     x1, x23                                    
02ce1ca8: mov     x2, xzr                                    
02ce1cac: bl      #0x4f988bc                                 Spine.TrackEntry::add_Complete
02ce1cb0: ldr     x0, [x19, #0xe8]!                          ._onAnimCompleteEvent
02ce1cb4: cbz     x0, #0x2ce1cc4                             
02ce1cb8: mov     x1, xzr                                    
02ce1cbc: bl      #0x5b4ce48                                 UnityEngine.Events.UnityEventBase::RemoveAllListeners
02ce1cc0: b       #0x2ce1cf0                                 
02ce1cc4: adrp    x8, #0x6267000                             
02ce1cc8: ldr     x8, [x8, #0xff0]                           T:UnityEngine.Events.UnityEvent
02ce1ccc: ldr     x0, [x8]                                   S:'didu'
02ce1cd0: bl      #0x2b7104c                                 fn_2b7104c
02ce1cd4: mov     x1, xzr                                    
02ce1cd8: mov     x22, x0                                    
02ce1cdc: bl      #0x5b4d048                                 UnityEngine.Events.UnityEvent::.ctor
02ce1ce0: mov     x0, x19                                    
02ce1ce4: mov     x1, x22                                    
02ce1ce8: str     x22, [x19]                                 
02ce1cec: bl      #0x2b70d54                                 fn_2b70d54
02ce1cf0: ldr     x8, [x21]                                  S:'didu'
02ce1cf4: cbz     x8, #0x2ce1d4c                             
02ce1cf8: adrp    x8, #0x6265000                             
02ce1cfc: adrp    x21, #0x6267000                            
02ce1d00: ldr     x8, [x8, #0x3f0]                           T:UnityEngine.Events.UnityAction
02ce1d04: ldr     x21, [x21, #0xfe8]                         M:LuckyWheelPopup/<>c__DisplayClass66_0::<PlayAnimation>b__0
02ce1d08: ldr     x19, [x19]                                 
02ce1d0c: ldr     x0, [x8]                                   M:AdsManager::<OnApplicationPause>b__26_0
02ce1d10: bl      #0x2b7104c                                 fn_2b7104c
02ce1d14: ldr     x2, [x21]                                  S:'didu'
02ce1d18: mov     x1, x20                                    
02ce1d1c: mov     x3, xzr                                    
02ce1d20: mov     x21, x0                                    
02ce1d24: bl      #0x5b4cf98                                 UnityEngine.Events.UnityAction::.ctor
02ce1d28: cbz     x19, #0x2ce1d60                            
02ce1d2c: mov     x0, x19                                    
02ce1d30: mov     x1, x21                                    
02ce1d34: mov     x2, xzr                                    
02ce1d38: ldp     x20, x19, [sp, #0x30]                      
02ce1d3c: ldp     x22, x21, [sp, #0x20]                      
02ce1d40: ldp     x24, x23, [sp, #0x10]                      
02ce1d44: ldp     x30, x25, [sp], #0x40                      
02ce1d48: b       #0x5b4d0ac                                 UnityEngine.Events.UnityEvent::AddListener
02ce1d4c: ldp     x20, x19, [sp, #0x30]                      
02ce1d50: ldp     x22, x21, [sp, #0x20]                      
02ce1d54: ldp     x24, x23, [sp, #0x10]                      
02ce1d58: ldp     x30, x25, [sp], #0x40                      
02ce1d5c: ret                                                
02ce1d60: bl      #0x2b7105c                                 fn_2b7105c
## OnAnimComplete(Spine.TrackEntry trackEntry) -> void
---- LuckyWheelPopup::OnAnimComplete 0x2ce3490
02ce3490: str     x30, [sp, #-0x30]!                         
02ce3494: stp     x22, x21, [sp, #0x10]                      
02ce3498: stp     x20, x19, [sp, #0x20]                      
02ce349c: adrp    x20, #0x662f000                            
02ce34a0: adrp    x22, #0x6266000                            
02ce34a4: adrp    x21, #0x6267000                            
02ce34a8: ldrb    w8, [x20, #0xdc9]                          
02ce34ac: ldr     x22, [x22, #0xbf0]                         T:Spine.AnimationState/TrackEntryDelegate
02ce34b0: ldr     x21, [x21, #0xfe0]                         M:LuckyWheelPopup::OnAnimComplete
02ce34b4: mov     x19, x0                                    
02ce34b8: tbnz    w8, #0, #0x2ce34dc                         
02ce34bc: adrp    x0, #0x6267000                             
02ce34c0: ldr     x0, [x0, #0xfe0]                           M:LuckyWheelPopup::OnAnimComplete
02ce34c4: bl      #0x2b70db0                                 fn_2b70db0
02ce34c8: adrp    x0, #0x6266000                             
02ce34cc: ldr     x0, [x0, #0xbf0]                           T:Spine.AnimationState/TrackEntryDelegate
02ce34d0: bl      #0x2b70db0                                 fn_2b70db0
02ce34d4: mov     w8, #1                                     
02ce34d8: strb    w8, [x20, #0xdc9]                          
02ce34dc: ldr     x0, [x22]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ce34e0: ldr     x20, [x19, #0xe0]                          ._trackEntry
02ce34e4: bl      #0x2b7104c                                 fn_2b7104c
02ce34e8: ldr     x2, [x21]                                  S:'didu'
02ce34ec: mov     x1, x19                                    
02ce34f0: mov     x3, xzr                                    
02ce34f4: mov     x21, x0                                    
02ce34f8: bl      #0x4f98140                                 Spine.AnimationState/TrackEntryDelegate::.ctor
02ce34fc: cbz     x20, #0x2ce354c                            
02ce3500: mov     x0, x20                                    
02ce3504: mov     x1, x21                                    
02ce3508: mov     x2, xzr                                    
02ce350c: bl      #0x4f98958                                 Spine.TrackEntry::remove_Complete
02ce3510: ldr     x0, [x19, #0xe8]                           ._onAnimCompleteEvent
02ce3514: cbz     x0, #0x2ce353c                             
02ce3518: mov     x1, xzr                                    
02ce351c: bl      #0x5b4d278                                 UnityEngine.Events.UnityEvent::Invoke
02ce3520: ldr     x0, [x19, #0xe8]                           ._onAnimCompleteEvent
02ce3524: cbz     x0, #0x2ce354c                             
02ce3528: ldp     x20, x19, [sp, #0x20]                      
02ce352c: mov     x1, xzr                                    
02ce3530: ldp     x22, x21, [sp, #0x10]                      
02ce3534: ldr     x30, [sp], #0x30                           
02ce3538: b       #0x5b4ce48                                 UnityEngine.Events.UnityEventBase::RemoveAllListeners
02ce353c: ldp     x20, x19, [sp, #0x20]                      
02ce3540: ldp     x22, x21, [sp, #0x10]                      
02ce3544: ldr     x30, [sp], #0x30                           
02ce3548: ret                                                
02ce354c: bl      #0x2b7105c                                 fn_2b7105c
## OnDestroy() -> void
---- LuckyWheelPopup::OnDestroy 0x2ce3550
02ce3550: stp     x30, x19, [sp, #-0x10]!                    
02ce3554: mov     x19, x0                                    
02ce3558: bl      #0x2ce1fe8                                 LuckyWheelPopup::StopCountdown
02ce355c: ldr     x0, [x19, #0x58]                           ._spinButton
02ce3560: cbz     x0, #0x2ce357c                             
02ce3564: mov     x1, xzr                                    
02ce3568: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02ce356c: mov     w1, wzr                                    
02ce3570: mov     x2, xzr                                    
02ce3574: ldp     x30, x19, [sp], #0x10                      
02ce3578: b       #0x2d9d5d0                                 DG.Tweening.ShortcutExtensions::DOKill
02ce357c: bl      #0x2b7105c                                 fn_2b7105c
## .ctor() -> void
---- LuckyWheelPopup::.ctor 0x2ce3580
02ce3580: str     d8, [sp, #-0x30]!                          
02ce3584: str     x30, [sp, #8]                              
02ce3588: stp     x22, x21, [sp, #0x10]                      
02ce358c: stp     x20, x19, [sp, #0x20]                      
02ce3590: adrp    x22, #0x662f000                            
02ce3594: adrp    x20, #0x6267000                            
02ce3598: adrp    x21, #0x6266000                            
02ce359c: ldrb    w8, [x22, #0xdca]                          
02ce35a0: ldr     x20, [x20, #0xff0]                         T:UnityEngine.Events.UnityEvent
02ce35a4: ldr     x21, [x21, #0x5e0]                         T:GameConfig
02ce35a8: mov     x19, x0                                    
02ce35ac: tbnz    w8, #0, #0x2ce35dc                         
02ce35b0: adrp    x0, #0x6266000                             
02ce35b4: ldr     x0, [x0, #0x5e0]                           T:GameConfig
02ce35b8: bl      #0x2b70db0                                 fn_2b70db0
02ce35bc: adrp    x0, #0x6265000                             
02ce35c0: ldr     x0, [x0, #0xf98]                           T:System.TimeSpan
02ce35c4: bl      #0x2b70db0                                 fn_2b70db0
02ce35c8: adrp    x0, #0x6267000                             
02ce35cc: ldr     x0, [x0, #0xff0]                           T:UnityEngine.Events.UnityEvent
02ce35d0: bl      #0x2b70db0                                 fn_2b70db0
02ce35d4: mov     w8, #1                                     
02ce35d8: strb    w8, [x22, #0xdca]                          
02ce35dc: fmov    v0.2s, #3.00000000                         
02ce35e0: adrp    x22, #0x6265000                            
02ce35e4: mov     w8, #0x42700000                            
02ce35e8: ldr     x22, [x22, #0xf98]                         T:System.TimeSpan
02ce35ec: ldr     x0, [x20]                                  S:'didu'
02ce35f0: str     w8, [x19, #0x40]                           ._spinSpeed
02ce35f4: str     d0, [x19, #0x38]                           ._initSpinDuration
02ce35f8: bl      #0x2b7104c                                 fn_2b7104c
02ce35fc: mov     x1, xzr                                    
02ce3600: mov     x20, x0                                    
02ce3604: bl      #0x5b4d048                                 UnityEngine.Events.UnityEvent::.ctor
02ce3608: mov     x0, x19                                    
02ce360c: mov     x1, x20                                    
02ce3610: str     x20, [x0, #0xe8]!                          ._onAnimCompleteEvent
02ce3614: bl      #0x2b70d54                                 fn_2b70d54
02ce3618: ldr     x0, [x21]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ce361c: ldr     w8, [x0, #0xe4]                            [62670e4]=0 f=0,0
02ce3620: cbnz    w8, #0x2ce362c                             
02ce3624: bl      #0x2b70f30                                 fn_2b70f30
02ce3628: ldr     x0, [x21]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ce362c: ldr     x8, [x22]                                  M:AdsManager::<OnApplicationPause>b__26_0
02ce3630: ldr     x9, [x0, #0xb8]                            M:Framework.SceneUtils/<CRUnloadSceneAsync>d__2::System.Collections.IEnumerator.Reset ._mysteryBoxes
02ce3634: ldr     w10, [x8, #0xe4]                           
02ce3638: ldr     s8, [x9, #0x40]                            
02ce363c: cbnz    w10, #0x2ce3648                            
02ce3640: mov     x0, x8                                     
02ce3644: bl      #0x2b70f30                                 fn_2b70f30
02ce3648: fcvt    d0, s8                                     
02ce364c: mov     x0, xzr                                    
02ce3650: bl      #0x4e29854                                 System.TimeSpan::FromMinutes
02ce3654: mov     x8, x0                                     
02ce3658: mov     x0, x19                                    
02ce365c: ldr     x30, [sp, #8]                              
02ce3660: str     x8, [x19, #0x100]                          ._cooldown
02ce3664: ldp     x20, x19, [sp, #0x20]                      
02ce3668: ldp     x22, x21, [sp, #0x10]                      
02ce366c: mov     x1, xzr                                    
02ce3670: ldr     d8, [sp], #0x30                            
02ce3674: b       #0x5b397b0                                 UnityEngine.MonoBehaviour::.ctor
## <>n__0() -> void
---- LuckyWheelPopup::<>n__0 0x2ce3678
02ce3678: str     x30, [sp, #-0x20]!                         
02ce367c: stp     x20, x19, [sp, #0x10]                      
02ce3680: movi    d0, #0000000000000000                      
02ce3684: mov     x19, x0                                    
02ce3688: ldr     x0, [x0, #0x28]                            
02ce368c: mov     w1, #1                                     
02ce3690: mov     x2, xzr                                    
02ce3694: mov     w20, #1                                    
02ce3698: bl      #0x2cf1928                                 FrameWorkUtility::SetActive
02ce369c: strb    w20, [x19, #0x20]                          
02ce36a0: ldp     x20, x19, [sp, #0x10]                      
02ce36a4: ldr     x30, [sp], #0x20                           
02ce36a8: ret                                                
## <OnSpinButtonClick>b__64_0() -> void
---- LuckyWheelPopup::<OnSpinButtonClick>b__64_0 0x2ce36ac
02ce36ac: mov     x1, xzr                                    
02ce36b0: b       #0x2ce229c                                 LuckyWheelPopup::StartSpin
## <OnButtonCloseClicked>b__65_0() -> void
---- LuckyWheelPopup::<OnButtonCloseClicked>b__65_0 0x2ce36b4
02ce36b4: str     x30, [sp, #-0x20]!                         
02ce36b8: stp     x20, x19, [sp, #0x10]                      
02ce36bc: adrp    x20, #0x662f000                            
02ce36c0: mov     x19, x0                                    
02ce36c4: ldrb    w8, [x20, #0xdcb]                          
02ce36c8: tbnz    w8, #0, #0x2ce36f8                         
02ce36cc: adrp    x0, #0x6266000                             
02ce36d0: ldr     x0, [x0, #0xac0]                           MS:MonoSingleton`1::get_Instance
02ce36d4: bl      #0x2b70db0                                 fn_2b70db0
02ce36d8: adrp    x0, #0x6266000                             
02ce36dc: ldr     x0, [x0, #0xaa0]                           MS:MonoSingleton`1::get_Instance
02ce36e0: bl      #0x2b70db0                                 fn_2b70db0
02ce36e4: adrp    x0, #0x6268000                             
02ce36e8: ldr     x0, [x0, #0x108]                           MS:UIManager::ShowScreen ._onClosePopupAction
02ce36ec: bl      #0x2b70db0                                 fn_2b70db0
02ce36f0: mov     w8, #1                                     
02ce36f4: strb    w8, [x20, #0xdcb]                          
02ce36f8: adrp    x20, #0x6266000                            
02ce36fc: ldr     x8, [x19, #0x108]                          ._onClosePopupAction
02ce3700: ldr     x20, [x20, #0xac0]                         MS:MonoSingleton`1::get_Instance
02ce3704: cbz     x8, #0x2ce3718                             
02ce3708: ldr     x9, [x8, #0x18]                            
02ce370c: ldr     x0, [x8, #0x40]                            
02ce3710: ldr     x1, [x8, #0x28]                            
02ce3714: blr     x9                                         
02ce3718: ldr     x0, [x20]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ce371c: bl      #0x3769600                                 fn_3769600
02ce3720: cbz     x0, #0x2ce3778                             
02ce3724: mov     w1, #1                                     
02ce3728: mov     x2, xzr                                    
02ce372c: bl      #0x2cacd8c                                 GameSession::SetActiveCharacter
02ce3730: ldr     x8, [x19]                                  
02ce3734: mov     x0, x19                                    
02ce3738: ldp     x9, x1, [x8, #0x198]                       
02ce373c: blr     x9                                         
02ce3740: ldr     x0, [x19, #0x30]                           
02ce3744: cbz     x0, #0x2ce3778                             
02ce3748: adrp    x8, #0x6268000                             
02ce374c: adrp    x19, #0x6266000                            
02ce3750: ldr     x8, [x8, #0x108]                           MS:UIManager::ShowScreen
02ce3754: ldr     x19, [x19, #0xaa0]                         MS:MonoSingleton`1::get_Instance
02ce3758: ldr     x1, [x8]                                   S:'{0}/2'
02ce375c: bl      #0x33fc0e8                                 fn_33fc0e8
02ce3760: ldr     x0, [x19]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ce3764: bl      #0x3769600                                 fn_3769600
02ce3768: cbz     x0, #0x2ce3778                             
02ce376c: ldp     x20, x19, [sp, #0x10]                      
02ce3770: ldr     x30, [sp], #0x20                           
02ce3774: b       #0x2cdb2e8                                 MoneyManager::BackToParent
02ce3778: bl      #0x2b7105c                                 fn_2b7105c
