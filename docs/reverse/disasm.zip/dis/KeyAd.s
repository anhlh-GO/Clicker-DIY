#### CLASS KeyAd parent= object
#   field adFormat                       AdFormat                                           off=0x10 attr=6 
#   field ID                             string                                             off=0x18 attr=6 
## .ctor() -> void
---- KeyAd::.ctor 0x2c9bdfc
02c9bdfc: mov     x1, xzr                                    
02c9be00: b       #0x4e53e9c                                 System.Object::.ctor
