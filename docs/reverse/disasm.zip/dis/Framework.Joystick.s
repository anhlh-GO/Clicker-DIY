#### CLASS Framework.Joystick/EAxisOptions parent= int
#   field value__                        int                                                off=0x10 attr=606 
#   field Both                           Framework.Joystick/EAxisOptions                    off=0x0 attr=8056 
#   field Horizontal                     Framework.Joystick/EAxisOptions                    off=0x0 attr=8056 
#   field Vertical                       Framework.Joystick/EAxisOptions                    off=0x0 attr=8056 
#### CLASS Framework.Joystick parent= UnityEngine.MonoBehaviour
#   field _background                    UnityEngine.RectTransform                          off=0x20 attr=4 HeaderAttribute,TooltipAttribute,SerializeField
#   field _handle                        UnityEngine.RectTransform                          off=0x28 attr=4 TooltipAttribute,SerializeField
#   field _handleRange                   float                                              off=0x30 attr=1 HeaderAttribute,TooltipAttribute,SerializeField
#   field _deadZone                      float                                              off=0x34 attr=1 TooltipAttribute,SerializeField
#   field _axisOption                    Framework.Joystick/EAxisOptions                    off=0x38 attr=1 TooltipAttribute,SerializeField
#   field _snapX                         bool                                               off=0x3c attr=1 TooltipAttribute,SerializeField
#   field _snapY                         bool                                               off=0x3d attr=1 TooltipAttribute,SerializeField
#   field _hideVisual                    bool                                               off=0x3e attr=1 TooltipAttribute,SerializeField
#   field _input                         UnityEngine.Vector2                                off=0x40 attr=1 
#   field _baseRect                      UnityEngine.RectTransform                          off=0x48 attr=1 
#   field _canvas                        UnityEngine.Canvas                                 off=0x50 attr=1 
#   field _cam                           UnityEngine.Camera                                 off=0x58 attr=1 
## get_Horizontal() -> float
---- Framework.Joystick::get_Horizontal 0x2cc466c
02cc466c: ldrb    w8, [x0, #0x3c]                            ._snapX
02cc4670: ldr     s0, [x0, #0x40]                            ._input
02cc4674: cbz     w8, #0x2cc4680                             
02cc4678: mov     w1, #1                                     
02cc467c: b       #0x2cc4684                                 Framework.Joystick::SnapFloat
02cc4680: ret                                                
## get_Vertical() -> float
---- Framework.Joystick::get_Vertical 0x2cc483c
02cc483c: ldrb    w8, [x0, #0x3d]                            ._snapY
02cc4840: ldr     s0, [x0, #0x44]                            
02cc4844: cbz     w8, #0x2cc4850                             
02cc4848: mov     w1, #2                                     
02cc484c: b       #0x2cc4684                                 Framework.Joystick::SnapFloat
02cc4850: ret                                                
## get_Direction() -> UnityEngine.Vector2
---- Framework.Joystick::get_Direction 0x2cc4854
02cc4854: str     d8, [sp, #-0x20]!                          
02cc4858: stp     x30, x19, [sp, #0x10]                      
02cc485c: ldrb    w8, [x0, #0x3c]                            ._snapX
02cc4860: ldr     s8, [x0, #0x40]                            ._input
02cc4864: mov     x19, x0                                    
02cc4868: cbz     w8, #0x2cc4880                             
02cc486c: fmov    s0, s8                                     
02cc4870: mov     x0, x19                                    
02cc4874: mov     w1, #1                                     
02cc4878: bl      #0x2cc4684                                 Framework.Joystick::SnapFloat
02cc487c: fmov    s8, s0                                     
02cc4880: ldrb    w8, [x19, #0x3d]                           ._snapY
02cc4884: ldr     s1, [x19, #0x44]                           
02cc4888: cbz     w8, #0x2cc48a0                             
02cc488c: fmov    s0, s1                                     
02cc4890: mov     x0, x19                                    
02cc4894: mov     w1, #2                                     
02cc4898: bl      #0x2cc4684                                 Framework.Joystick::SnapFloat
02cc489c: fmov    s1, s0                                     
02cc48a0: ldp     x30, x19, [sp, #0x10]                      
02cc48a4: fmov    s0, s8                                     
02cc48a8: ldr     d8, [sp], #0x20                            
02cc48ac: ret                                                
## get_HandleRange() -> float
---- Framework.Joystick::get_HandleRange 0x2cc48b0
02cc48b0: ldr     s0, [x0, #0x30]                            ._handleRange
02cc48b4: ret                                                
## set_HandleRange(float value) -> void
---- Framework.Joystick::set_HandleRange 0x2cc48b8
02cc48b8: fabs    s0, s0                                     
02cc48bc: str     s0, [x0, #0x30]                            ._handleRange
02cc48c0: ret                                                
## get_DeadZone() -> float
---- Framework.Joystick::get_DeadZone 0x2cc48c4
02cc48c4: ldr     s0, [x0, #0x34]                            ._deadZone
02cc48c8: ret                                                
## set_DeadZone(float value) -> void
---- Framework.Joystick::set_DeadZone 0x2cc48cc
02cc48cc: fabs    s0, s0                                     
02cc48d0: str     s0, [x0, #0x34]                            ._deadZone
02cc48d4: ret                                                
## get_AxisOption() -> Framework.Joystick/EAxisOptions
---- Framework.Joystick::get_AxisOption 0x2cc48d8
02cc48d8: ldr     w0, [x0, #0x38]                            ._axisOption
02cc48dc: ret                                                
## set_AxisOption(Framework.Joystick/EAxisOptions value) -> void
---- Framework.Joystick::set_AxisOption 0x2cc48e0
02cc48e0: str     w1, [x0, #0x38]                            ._axisOption
02cc48e4: ret                                                
## get_SnapX() -> bool
---- Framework.Joystick::get_SnapX 0x2cc48e8
02cc48e8: ldrb    w0, [x0, #0x3c]                            ._snapX
02cc48ec: ret                                                
## set_SnapX(bool value) -> void
---- Framework.Joystick::set_SnapX 0x2cc48f0
02cc48f0: strb    w1, [x0, #0x3c]                            ._snapX
02cc48f4: ret                                                
## get_SnapY() -> bool
---- Framework.Joystick::get_SnapY 0x2cc48f8
02cc48f8: ldrb    w0, [x0, #0x3d]                            ._snapY
02cc48fc: ret                                                
## set_SnapY(bool value) -> void
---- Framework.Joystick::set_SnapY 0x2cc4900
02cc4900: strb    w1, [x0, #0x3d]                            ._snapY
02cc4904: ret                                                
## Start() -> void
---- Framework.Joystick::Start 0x2cc3a38
02cc3a38: stp     x30, x23, [sp, #-0x30]!                    
02cc3a3c: stp     x22, x21, [sp, #0x10]                      
02cc3a40: stp     x20, x19, [sp, #0x20]                      
02cc3a44: adrp    x23, #0x662f000                            
02cc3a48: adrp    x22, #0x6264000                            
02cc3a4c: adrp    x20, #0x6267000                            
02cc3a50: adrp    x21, #0x6263000                            
02cc3a54: ldr     x22, [x22, #0xd88]                         MS:UnityEngine.Component::GetComponent
02cc3a58: ldrb    w8, [x23, #0xc3f]                          
02cc3a5c: ldr     x20, [x20, #0x1a0]                         MS:UnityEngine.Component::GetComponentInParent
02cc3a60: ldr     x21, [x21, #0x918]                         T:UnityEngine.Object
02cc3a64: mov     x19, x0                                    
02cc3a68: tbnz    w8, #0, #0x2cc3abc                         
02cc3a6c: adrp    x0, #0x6267000                             
02cc3a70: ldr     x0, [x0, #0x1a0]                           MS:UnityEngine.Component::GetComponentInParent
02cc3a74: bl      #0x2b70db0                                 fn_2b70db0
02cc3a78: adrp    x0, #0x6267000                             
02cc3a7c: ldr     x0, [x0, #0x1a8]                           MS:UnityEngine.Component::GetComponent
02cc3a80: bl      #0x2b70db0                                 fn_2b70db0
02cc3a84: adrp    x0, #0x6264000                             
02cc3a88: ldr     x0, [x0, #0xd88]                           MS:UnityEngine.Component::GetComponent
02cc3a8c: bl      #0x2b70db0                                 fn_2b70db0
02cc3a90: adrp    x0, #0x6263000                             
02cc3a94: ldr     x0, [x0, #0x928]                           T:UnityEngine.Debug
02cc3a98: bl      #0x2b70db0                                 fn_2b70db0
02cc3a9c: adrp    x0, #0x6263000                             
02cc3aa0: ldr     x0, [x0, #0x918]                           T:UnityEngine.Object
02cc3aa4: bl      #0x2b70db0                                 fn_2b70db0
02cc3aa8: adrp    x0, #0x6267000                             
02cc3aac: ldr     x0, [x0, #0x1b0]                           S:'The Joystick is not placed inside a canvas'
02cc3ab0: bl      #0x2b70db0                                 fn_2b70db0
02cc3ab4: mov     w8, #1                                     
02cc3ab8: strb    w8, [x23, #0xc3f]                          
02cc3abc: ldr     d0, [x19, #0x30]                           ._handleRange
02cc3ac0: ldr     x1, [x22]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02cc3ac4: mov     x0, x19                                    
02cc3ac8: fabs    v0.2s, v0.2s                               
02cc3acc: str     d0, [x19, #0x30]                           ._handleRange
02cc3ad0: bl      #0x3140c84                                 fn_3140c84
02cc3ad4: mov     x1, x0                                     
02cc3ad8: mov     x0, x19                                    
02cc3adc: str     x1, [x0, #0x48]!                           ._baseRect
02cc3ae0: bl      #0x2b70d54                                 fn_2b70d54
02cc3ae4: ldr     x1, [x20]                                  S:'didu'
02cc3ae8: mov     x0, x19                                    
02cc3aec: bl      #0x3141210                                 fn_3141210
02cc3af0: mov     x20, x19                                   
02cc3af4: mov     x1, x0                                     
02cc3af8: str     x0, [x20, #0x50]!                          ._canvas
02cc3afc: mov     x0, x20                                    
02cc3b00: bl      #0x2b70d54                                 fn_2b70d54
02cc3b04: ldr     x0, [x21]                                  &2c5bbd4(=a9bd7bfdd503233f)
02cc3b08: ldr     x21, [x20]                                 S:'didu'
02cc3b0c: ldr     w8, [x0, #0xe4]                            [62670e4]=0 f=0,0
02cc3b10: cbnz    w8, #0x2cc3b18                             
02cc3b14: bl      #0x2b70f30                                 fn_2b70f30
02cc3b18: mov     x0, x21                                    
02cc3b1c: mov     x1, xzr                                    
02cc3b20: mov     x2, xzr                                    
02cc3b24: bl      #0x5b37d84                                 UnityEngine.Object::op_Equality
02cc3b28: tbz     w0, #0, #0x2cc3b5c                         
02cc3b2c: adrp    x8, #0x6263000                             
02cc3b30: adrp    x21, #0x6267000                            
02cc3b34: ldr     x8, [x8, #0x928]                           T:UnityEngine.Debug
02cc3b38: ldr     x0, [x8]                                   &2c5bbd4(=a9bd7bfdd503233f)
02cc3b3c: ldr     w8, [x0, #0xe4]                            [62670e4]=0 f=0,0
02cc3b40: ldr     x21, [x21, #0x1b0]                         S:'The Joystick is not placed inside a canvas'
02cc3b44: cbnz    w8, #0x2cc3b4c                             
02cc3b48: bl      #0x2b70f30                                 fn_2b70f30
02cc3b4c: ldr     x0, [x21]                                  S:'didu'
02cc3b50: mov     x1, x19                                    
02cc3b54: mov     x2, xzr                                    
02cc3b58: bl      #0x5af2948                                 UnityEngine.Debug::LogError
02cc3b5c: ldr     x0, [x19, #0x20]                           ._background
02cc3b60: cbz     x0, #0x2cc3ca8                             
02cc3b64: fmov    s0, #0.50000000                            
02cc3b68: fmov    s1, #0.50000000                            
02cc3b6c: mov     x1, xzr                                    
02cc3b70: bl      #0x5b45b28                                 UnityEngine.RectTransform::set_pivot
02cc3b74: ldr     x0, [x19, #0x28]                           ._handle
02cc3b78: cbz     x0, #0x2cc3ca8                             
02cc3b7c: fmov    s0, #0.50000000                            
02cc3b80: fmov    s1, #0.50000000                            
02cc3b84: mov     x1, xzr                                    
02cc3b88: bl      #0x5b454d8                                 UnityEngine.RectTransform::set_anchorMin
02cc3b8c: ldr     x0, [x19, #0x28]                           ._handle
02cc3b90: cbz     x0, #0x2cc3ca8                             
02cc3b94: fmov    s0, #0.50000000                            
02cc3b98: fmov    s1, #0.50000000                            
02cc3b9c: mov     x1, xzr                                    
02cc3ba0: bl      #0x5b4566c                                 UnityEngine.RectTransform::set_anchorMax
02cc3ba4: ldr     x0, [x19, #0x28]                           ._handle
02cc3ba8: cbz     x0, #0x2cc3ca8                             
02cc3bac: fmov    s0, #0.50000000                            
02cc3bb0: fmov    s1, #0.50000000                            
02cc3bb4: mov     x1, xzr                                    
02cc3bb8: bl      #0x5b45b28                                 UnityEngine.RectTransform::set_pivot
02cc3bbc: adrp    x22, #0x662f000                            
02cc3bc0: ldr     x21, [x19, #0x28]                          ._handle
02cc3bc4: ldrb    w8, [x22, #0xbda]                          
02cc3bc8: cbnz    w8, #0x2cc3be0                             
02cc3bcc: adrp    x0, #0x6266000                             
02cc3bd0: ldr     x0, [x0, #0x970]                           T:UnityEngine.Vector2
02cc3bd4: bl      #0x2b70db0                                 fn_2b70db0
02cc3bd8: mov     w8, #1                                     
02cc3bdc: strb    w8, [x22, #0xbda]                          
02cc3be0: cbz     x21, #0x2cc3ca8                            
02cc3be4: adrp    x8, #0x6266000                             
02cc3be8: mov     x0, x21                                    
02cc3bec: mov     x1, xzr                                    
02cc3bf0: ldr     x8, [x8, #0x970]                           T:UnityEngine.Vector2
02cc3bf4: ldr     x8, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cc3bf8: ldr     x8, [x8, #0xb8]                            S:'banner_native_refresh_time'
02cc3bfc: ldp     s0, s1, [x8]                               
02cc3c00: bl      #0x5b45800                                 UnityEngine.RectTransform::set_anchoredPosition
02cc3c04: ldr     x0, [x20]                                  S:'didu'
02cc3c08: cbz     x0, #0x2cc3ca8                             
02cc3c0c: mov     x1, xzr                                    
02cc3c10: bl      #0x5e484e8                                 UnityEngine.Canvas::get_renderMode
02cc3c14: cmp     w0, #1                                     
02cc3c18: b.ne    #0x2cc3c3c                                 
02cc3c1c: ldr     x0, [x20]                                  S:'didu'
02cc3c20: cbz     x0, #0x2cc3ca8                             
02cc3c24: mov     x1, xzr                                    
02cc3c28: bl      #0x5e49698                                 UnityEngine.Canvas::get_worldCamera
02cc3c2c: mov     x1, x0                                     
02cc3c30: mov     x0, x19                                    
02cc3c34: str     x1, [x0, #0x58]!                           ._cam
02cc3c38: b       #0x2cc3c48                                 
02cc3c3c: mov     x0, x19                                    
02cc3c40: mov     x1, xzr                                    
02cc3c44: str     xzr, [x0, #0x58]!                          ._cam
02cc3c48: bl      #0x2b70d54                                 fn_2b70d54
02cc3c4c: ldrb    w8, [x19, #0x3e]                           ._hideVisual
02cc3c50: cbz     w8, #0x2cc3c98                             
02cc3c54: ldr     x0, [x19, #0x20]                           ._background
02cc3c58: cbz     x0, #0x2cc3ca8                             
02cc3c5c: adrp    x20, #0x6267000                            
02cc3c60: ldr     x20, [x20, #0x1a8]                         MS:UnityEngine.Component::GetComponent
02cc3c64: ldr     x1, [x20]                                  S:'didu'
02cc3c68: bl      #0x3140c84                                 fn_3140c84
02cc3c6c: movi    d0, #0000000000000000                      
02cc3c70: bl      #0x2cb8cf4                                 Framework.ImageExtension::SetAlpha
02cc3c74: ldr     x0, [x19, #0x28]                           ._handle
02cc3c78: cbz     x0, #0x2cc3ca8                             
02cc3c7c: ldr     x1, [x20]                                  S:'didu'
02cc3c80: bl      #0x3140c84                                 fn_3140c84
02cc3c84: ldp     x20, x19, [sp, #0x20]                      
02cc3c88: movi    d0, #0000000000000000                      
02cc3c8c: ldp     x22, x21, [sp, #0x10]                      
02cc3c90: ldp     x30, x23, [sp], #0x30                      
02cc3c94: b       #0x2cb8cf4                                 Framework.ImageExtension::SetAlpha
02cc3c98: ldp     x20, x19, [sp, #0x20]                      
02cc3c9c: ldp     x22, x21, [sp, #0x10]                      
02cc3ca0: ldp     x30, x23, [sp], #0x30                      
02cc3ca4: ret                                                
02cc3ca8: bl      #0x2b7105c                                 fn_2b7105c
## OnPointerDown(UnityEngine.EventSystems.PointerEventData eventData) -> void
---- Framework.Joystick::OnPointerDown 0x2cc3eb0
02cc3eb0: b       #0x2cc4908                                 Framework.Joystick::OnDrag
## OnDrag(UnityEngine.EventSystems.PointerEventData eventData) -> void
---- Framework.Joystick::OnDrag 0x2cc4908
02cc4908: stp     d11, d10, [sp, #-0x50]!                    
02cc490c: stp     d9, d8, [sp, #0x10]                        
02cc4910: str     x30, [sp, #0x20]                           
02cc4914: stp     x22, x21, [sp, #0x30]                      
02cc4918: stp     x20, x19, [sp, #0x40]                      
02cc491c: adrp    x21, #0x662f000                            
02cc4920: mov     x20, x1                                    
02cc4924: mov     x19, x0                                    
02cc4928: ldrb    w8, [x21, #0xc40]                          
02cc492c: tbnz    w8, #0, #0x2cc4944                         
02cc4930: adrp    x0, #0x6264000                             
02cc4934: ldr     x0, [x0, #0x790]                           T:UnityEngine.RectTransformUtility
02cc4938: bl      #0x2b70db0                                 fn_2b70db0
02cc493c: mov     w8, #1                                     
02cc4940: strb    w8, [x21, #0xc40]                          
02cc4944: ldr     x0, [x19, #0x20]                           ._background
02cc4948: cbz     x0, #0x2cc4ae4                             
02cc494c: adrp    x22, #0x6264000                            
02cc4950: mov     x1, xzr                                    
02cc4954: ldr     x22, [x22, #0x790]                         T:UnityEngine.RectTransformUtility
02cc4958: ldr     x21, [x19, #0x58]                          ._cam
02cc495c: bl      #0x5b467ac                                 UnityEngine.Transform::get_position
02cc4960: fmov    s8, s0                                     
02cc4964: fmov    s9, s1                                     
02cc4968: ldr     x0, [x22]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02cc496c: fmov    s10, s2                                    
02cc4970: ldr     w8, [x0, #0xe4]                            [62640e4]=0 f=0,0
02cc4974: cbnz    w8, #0x2cc497c                             
02cc4978: bl      #0x2b70f30                                 fn_2b70f30
02cc497c: fmov    s0, s8                                     
02cc4980: fmov    s1, s9                                     
02cc4984: mov     x0, x21                                    
02cc4988: fmov    s2, s10                                    
02cc498c: mov     x1, xzr                                    
02cc4990: bl      #0x5e47b7c                                 UnityEngine.RectTransformUtility::WorldToScreenPoint
02cc4994: ldr     x0, [x19, #0x20]                           ._background
02cc4998: cbz     x0, #0x2cc4ae4                             
02cc499c: mov     x1, xzr                                    
02cc49a0: fmov    s10, s0                                    
02cc49a4: fmov    s11, s1                                    
02cc49a8: bl      #0x5b458c8                                 UnityEngine.RectTransform::get_sizeDelta
02cc49ac: cbz     x20, #0x2cc4ae4                            
02cc49b0: ldr     x0, [x19, #0x50]                           ._canvas
02cc49b4: cbz     x0, #0x2cc4ae4                             
02cc49b8: fmov    s2, #0.50000000                            
02cc49bc: ldr     s3, [x20, #0x148]                          
02cc49c0: ldr     s4, [x20, #0x144]                          
02cc49c4: mov     x1, xzr                                    
02cc49c8: fsub    s11, s3, s11                               
02cc49cc: fsub    s10, s4, s10                               
02cc49d0: fmul    s8, s0, s2                                 
02cc49d4: fmul    s9, s1, s2                                 
02cc49d8: bl      #0x5e487ec                                 UnityEngine.Canvas::get_scaleFactor
02cc49dc: fmul    s1, s8, s0                                 
02cc49e0: fmul    s0, s9, s0                                 
02cc49e4: mov     x20, x19                                   
02cc49e8: fdiv    s10, s10, s1                               
02cc49ec: fdiv    s11, s11, s0                               
02cc49f0: str     s10, [x20, #0x40]!                         ._input
02cc49f4: ldur    w8, [x20, #-8]                             
02cc49f8: cmp     w8, #2                                     
02cc49fc: str     s11, [x20, #4]                             
02cc4a00: b.eq    #0x2cc4a18                                 
02cc4a04: cmp     w8, #1                                     
02cc4a08: b.ne    #0x2cc4a20                                 
02cc4a0c: movi    d11, #0000000000000000                     
02cc4a10: str     wzr, [x19, #0x44]                          
02cc4a14: b       #0x2cc4a20                                 
02cc4a18: movi    d10, #0000000000000000                     
02cc4a1c: str     wzr, [x20]                                 
02cc4a20: adrp    x21, #0x662f000                            
02cc4a24: ldrb    w8, [x21, #0xca9]                          
02cc4a28: cbnz    w8, #0x2cc4a44                             
02cc4a2c: adrp    x0, #0x6265000                             
02cc4a30: ldr     x0, [x0, #0xb48]                           T:System.Math
02cc4a34: bl      #0x2b70db0                                 fn_2b70db0
02cc4a38: ldp     s10, s11, [x19, #0x40]                     ._input
02cc4a3c: mov     w8, #1                                     
02cc4a40: strb    w8, [x21, #0xca9]                          
02cc4a44: adrp    x8, #0x6265000                             
02cc4a48: ldr     x8, [x8, #0xb48]                           T:System.Math
02cc4a4c: ldr     x0, [x8]                                   M:AdsManager::<OnApplicationPause>b__26_0
02cc4a50: ldr     w8, [x0, #0xe4]                            [62650e4]=0 f=0,0
02cc4a54: cbnz    w8, #0x2cc4a5c                             
02cc4a58: bl      #0x2b70f30                                 fn_2b70f30
02cc4a5c: fmul    s0, s10, s10                               
02cc4a60: fmul    s1, s11, s11                               
02cc4a64: mov     x0, x20                                    
02cc4a68: mov     x1, xzr                                    
02cc4a6c: fadd    s0, s0, s1                                 
02cc4a70: fsqrt   s10, s0                                    
02cc4a74: bl      #0x5b28290                                 UnityEngine.Vector2::Normalize
02cc4a78: fmov    s2, s0                                     
02cc4a7c: fmov    s3, s1                                     
02cc4a80: ldr     x8, [x19]                                  
02cc4a84: fmov    s0, s10                                    
02cc4a88: fmov    s4, s9                                     
02cc4a8c: ldr     x1, [x19, #0x58]                           ._cam
02cc4a90: ldp     x9, x2, [x8, #0x1d8]                       
02cc4a94: mov     x0, x19                                    
02cc4a98: fmov    s1, s2                                     
02cc4a9c: fmov    s2, s3                                     
02cc4aa0: fmov    s3, s8                                     
02cc4aa4: blr     x9                                         
02cc4aa8: ldr     x0, [x19, #0x28]                           ._handle
02cc4aac: cbz     x0, #0x2cc4ae4                             
02cc4ab0: ldp     s1, s0, [x19, #0x40]                       ._input
02cc4ab4: mov     x1, xzr                                    
02cc4ab8: ldr     s3, [x19, #0x30]                           ._handleRange
02cc4abc: ldp     x20, x19, [sp, #0x40]                      
02cc4ac0: ldp     x22, x21, [sp, #0x30]                      
02cc4ac4: ldr     x30, [sp, #0x20]                           
02cc4ac8: fmul    s0, s9, s0                                 
02cc4acc: fmul    s2, s8, s1                                 
02cc4ad0: ldp     d9, d8, [sp, #0x10]                        
02cc4ad4: fmul    s1, s0, s3                                 
02cc4ad8: fmul    s0, s3, s2                                 
02cc4adc: ldp     d11, d10, [sp], #0x50                      
02cc4ae0: b       #0x5b45800                                 UnityEngine.RectTransform::set_anchoredPosition
02cc4ae4: bl      #0x2b7105c                                 fn_2b7105c
## OnPointerUp(UnityEngine.EventSystems.PointerEventData eventData) -> void
---- Framework.Joystick::OnPointerUp 0x2cc3eec
02cc3eec: str     x30, [sp, #-0x20]!                         
02cc3ef0: stp     x20, x19, [sp, #0x10]                      
02cc3ef4: adrp    x20, #0x662f000                            
02cc3ef8: mov     x19, x0                                    
02cc3efc: ldrb    w8, [x20, #0xbda]                          
02cc3f00: cbnz    w8, #0x2cc3f18                             
02cc3f04: adrp    x0, #0x6266000                             
02cc3f08: ldr     x0, [x0, #0x970]                           T:UnityEngine.Vector2
02cc3f0c: bl      #0x2b70db0                                 fn_2b70db0
02cc3f10: mov     w8, #1                                     
02cc3f14: strb    w8, [x20, #0xbda]                          
02cc3f18: adrp    x8, #0x6266000                             
02cc3f1c: ldr     x8, [x8, #0x970]                           T:UnityEngine.Vector2
02cc3f20: ldr     x0, [x19, #0x28]                           ._handle
02cc3f24: ldr     x8, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cc3f28: ldr     x9, [x8, #0xb8]                            S:'banner_native_refresh_time'
02cc3f2c: ldr     d0, [x9]                                   
02cc3f30: str     d0, [x19, #0x40]                           ._input
02cc3f34: cbz     x0, #0x2cc3f50                             
02cc3f38: ldr     x8, [x8, #0xb8]                            S:'banner_native_refresh_time'
02cc3f3c: ldp     x20, x19, [sp, #0x10]                      
02cc3f40: mov     x1, xzr                                    
02cc3f44: ldp     s0, s1, [x8]                               
02cc3f48: ldr     x30, [sp], #0x20                           
02cc3f4c: b       #0x5b45800                                 UnityEngine.RectTransform::set_anchoredPosition
02cc3f50: bl      #0x2b7105c                                 fn_2b7105c
## HandleInput(float magnitude, UnityEngine.Vector2 normalised, UnityEngine.Vector2 radius, UnityEngine.Camera cam) -> void
---- Framework.Joystick::HandleInput 0x2cc4b0c
02cc4b0c: str     x30, [sp, #-0x20]!                         
02cc4b10: stp     x20, x19, [sp, #0x10]                      
02cc4b14: ldr     s3, [x0, #0x34]                            ._deadZone
02cc4b18: mov     x19, x0                                    
02cc4b1c: fcmp    s3, s0                                     
02cc4b20: b.pl    #0x2cc4b34                                 
02cc4b24: fmov    s3, #1.00000000                            
02cc4b28: fcmp    s0, s3                                     
02cc4b2c: b.gt    #0x2cc4b68                                 
02cc4b30: b       #0x2cc4b6c                                 
02cc4b34: adrp    x20, #0x662f000                            
02cc4b38: ldrb    w8, [x20, #0xbda]                          
02cc4b3c: cbnz    w8, #0x2cc4b54                             
02cc4b40: adrp    x0, #0x6266000                             
02cc4b44: ldr     x0, [x0, #0x970]                           T:UnityEngine.Vector2
02cc4b48: bl      #0x2b70db0                                 fn_2b70db0
02cc4b4c: mov     w8, #1                                     
02cc4b50: strb    w8, [x20, #0xbda]                          
02cc4b54: adrp    x8, #0x6266000                             
02cc4b58: ldr     x8, [x8, #0x970]                           T:UnityEngine.Vector2
02cc4b5c: ldr     x8, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cc4b60: ldr     x8, [x8, #0xb8]                            S:'banner_native_refresh_time'
02cc4b64: ldp     s1, s2, [x8]                               
02cc4b68: stp     s1, s2, [x19, #0x40]                       ._input
02cc4b6c: ldp     x20, x19, [sp, #0x10]                      
02cc4b70: ldr     x30, [sp], #0x20                           
02cc4b74: ret                                                
## FormatInput() -> void
---- Framework.Joystick::FormatInput 0x2cc4ae8
02cc4ae8: ldr     w8, [x0, #0x38]                            ._axisOption
02cc4aec: cmp     w8, #2                                     
02cc4af0: b.eq    #0x2cc4b04                                 
02cc4af4: cmp     w8, #1                                     
02cc4af8: b.ne    #0x2cc4b08                                 
02cc4afc: str     wzr, [x0, #0x44]                           
02cc4b00: ret                                                
02cc4b04: str     wzr, [x0, #0x40]                           ._input
02cc4b08: ret                                                
## SnapFloat(float value, Framework.Joystick/EAxisOptions snapAxis) -> float
---- Framework.Joystick::SnapFloat 0x2cc4684
02cc4684: stp     d13, d12, [sp, #-0x50]!                    
02cc4688: stp     d11, d10, [sp, #0x10]                      
02cc468c: stp     d9, d8, [sp, #0x20]                        
02cc4690: str     x30, [sp, #0x30]                           
02cc4694: stp     x20, x19, [sp, #0x40]                      
02cc4698: fmov    s8, s0                                     
02cc469c: fcmp    s0, #0.0                                   
02cc46a0: b.ne    #0x2cc46c0                                 
02cc46a4: fmov    s0, s8                                     
02cc46a8: ldp     x20, x19, [sp, #0x40]                      
02cc46ac: ldr     x30, [sp, #0x30]                           
02cc46b0: ldp     d9, d8, [sp, #0x20]                        
02cc46b4: ldp     d11, d10, [sp, #0x10]                      
02cc46b8: ldp     d13, d12, [sp], #0x50                      
02cc46bc: ret                                                
02cc46c0: ldr     w8, [x0, #0x38]                            ._axisOption
02cc46c4: cbz     w8, #0x2cc46e4                             
02cc46c8: fcmp    s8, #0.0                                   
02cc46cc: fmov    s0, #1.00000000                            
02cc46d0: b.gt    #0x2cc46a8                                 
02cc46d4: movi    d0, #0000000000000000                      
02cc46d8: fmov    s1, #-1.00000000                           
02cc46dc: fcsel   s0, s0, s1, pl                             
02cc46e0: b       #0x2cc46a8                                 
02cc46e4: adrp    x20, #0x662f000                            
02cc46e8: ldp     s9, s10, [x0, #0x40]                       ._input
02cc46ec: ldrb    w8, [x20, #0xcaa]                          
02cc46f0: mov     w19, w1                                    
02cc46f4: cbnz    w8, #0x2cc470c                             
02cc46f8: adrp    x0, #0x6266000                             
02cc46fc: ldr     x0, [x0, #0x970]                           T:UnityEngine.Vector2
02cc4700: bl      #0x2b70db0                                 fn_2b70db0
02cc4704: mov     w8, #1                                     
02cc4708: strb    w8, [x20, #0xcaa]                          
02cc470c: adrp    x8, #0x6266000                             
02cc4710: adrp    x20, #0x662f000                            
02cc4714: ldr     x8, [x8, #0x970]                           T:UnityEngine.Vector2
02cc4718: ldrb    w9, [x20, #0xca6]                          
02cc471c: ldr     x8, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cc4720: ldr     x8, [x8, #0xb8]                            S:'banner_native_refresh_time'
02cc4724: ldp     s11, s12, [x8, #0x10]                      
02cc4728: cbnz    w9, #0x2cc4740                             
02cc472c: adrp    x0, #0x6265000                             
02cc4730: ldr     x0, [x0, #0xb48]                           T:System.Math
02cc4734: bl      #0x2b70db0                                 fn_2b70db0
02cc4738: mov     w8, #1                                     
02cc473c: strb    w8, [x20, #0xca6]                          
02cc4740: fmul    s0, s9, s9                                 
02cc4744: fmul    s1, s10, s10                               
02cc4748: adrp    x8, #0x1084000                             
02cc474c: fmul    s2, s11, s11                               
02cc4750: fmul    s3, s12, s12                               
02cc4754: fadd    s0, s0, s1                                 
02cc4758: fadd    s1, s2, s3                                 
02cc475c: fmul    s13, s0, s1                                
02cc4760: ldr     s0, [x8, #0xdac]                           [1084dac]=3f0888880da24260 f=1e-30,0.533333
02cc4764: movi    d1, #0000000000000000                      
02cc4768: fcmp    s13, s0                                    
02cc476c: b.mi    #0x2cc47cc                                 
02cc4770: adrp    x8, #0x6265000                             
02cc4774: ldr     x8, [x8, #0xb48]                           T:System.Math
02cc4778: ldr     x0, [x8]                                   M:AdsManager::<OnApplicationPause>b__26_0
02cc477c: ldr     w8, [x0, #0xe4]                            [62650e4]=0 f=0,0
02cc4780: cbnz    w8, #0x2cc4788                             
02cc4784: bl      #0x2b70f30                                 fn_2b70f30
02cc4788: fsqrt   s0, s13                                    
02cc478c: fmul    s1, s9, s11                                
02cc4790: fmul    s2, s10, s12                               
02cc4794: fadd    s1, s1, s2                                 
02cc4798: fmov    s2, #-1.00000000                           
02cc479c: fdiv    s0, s1, s0                                 
02cc47a0: fmov    s1, #1.00000000                            
02cc47a4: fcmp    s0, s1                                     
02cc47a8: fcsel   s1, s1, s0, gt                             
02cc47ac: fcmp    s0, s2                                     
02cc47b0: fcsel   s0, s2, s1, mi                             
02cc47b4: fcvt    d0, s0                                     
02cc47b8: bl      #0x5e90300                                 fn_5e90300
02cc47bc: fcvt    s0, d0                                     
02cc47c0: adrp    x8, #0x1084000                             
02cc47c4: ldr     s1, [x8, #0xdec]                           [1084dec]=3fe6666642652ee1 f=57.2958,1.8
02cc47c8: fmul    s1, s0, s1                                 
02cc47cc: cmp     w19, #2                                    
02cc47d0: b.eq    #0x2cc4804                                 
02cc47d4: cmp     w19, #1                                    
02cc47d8: b.ne    #0x2cc46a4                                 
02cc47dc: mov     w8, #0x41b40000                            
02cc47e0: movi    d0, #0000000000000000                      
02cc47e4: fmov    s2, w8                                     
02cc47e8: fcmp    s1, s2                                     
02cc47ec: b.mi    #0x2cc46a8                                 
02cc47f0: adrp    x8, #0x1084000                             
02cc47f4: ldr     s2, [x8, #0xcf8]                           [1084cf8]=3f8ccccd431d8000 f=157.5,1.1
02cc47f8: fcmp    s1, s2                                     
02cc47fc: b.le    #0x2cc4828                                 
02cc4800: b       #0x2cc46a8                                 
02cc4804: mov     w8, #0x42870000                            
02cc4808: fmov    s0, w8                                     
02cc480c: fcmp    s1, s0                                     
02cc4810: b.le    #0x2cc4828                                 
02cc4814: mov     w8, #0x42e10000                            
02cc4818: movi    d0, #0000000000000000                      
02cc481c: fmov    s2, w8                                     
02cc4820: fcmp    s1, s2                                     
02cc4824: b.mi    #0x2cc46a8                                 
02cc4828: fcmp    s8, #0.0                                   
02cc482c: fmov    s0, #-1.00000000                           
02cc4830: fmov    s1, #1.00000000                            
02cc4834: fcsel   s0, s1, s0, gt                             
02cc4838: b       #0x2cc46a8                                 
## ScreenPointToAnchoredPosition(UnityEngine.Vector2 screenPosition) -> UnityEngine.Vector2
---- Framework.Joystick::ScreenPointToAnchoredPosition 0x2cc3d18
02cc3d18: sub     sp, sp, #0x80                              
02cc3d1c: stp     d15, d14, [sp, #0x10]                      
02cc3d20: stp     d13, d12, [sp, #0x20]                      
02cc3d24: stp     d11, d10, [sp, #0x30]                      
02cc3d28: stp     d9, d8, [sp, #0x40]                        
02cc3d2c: stp     x30, x23, [sp, #0x50]                      
02cc3d30: stp     x22, x21, [sp, #0x60]                      
02cc3d34: stp     x20, x19, [sp, #0x70]                      
02cc3d38: fmov    s8, s1                                     
02cc3d3c: fmov    s9, s0                                     
02cc3d40: adrp    x20, #0x662f000                            
02cc3d44: ldrb    w8, [x20, #0xc41]                          
02cc3d48: mov     x19, x0                                    
02cc3d4c: tbnz    w8, #0, #0x2cc3d64                         
02cc3d50: adrp    x0, #0x6264000                             
02cc3d54: ldr     x0, [x0, #0x790]                           T:UnityEngine.RectTransformUtility
02cc3d58: bl      #0x2b70db0                                 fn_2b70db0
02cc3d5c: mov     w8, #1                                     
02cc3d60: strb    w8, [x20, #0xc41]                          
02cc3d64: adrp    x22, #0x662f000                            
02cc3d68: adrp    x20, #0x6264000                            
02cc3d6c: ldrb    w8, [x22, #0xbda]                          
02cc3d70: ldr     x20, [x20, #0x790]                         T:UnityEngine.RectTransformUtility
02cc3d74: str     xzr, [sp, #8]                              
02cc3d78: cbnz    w8, #0x2cc3d90                             
02cc3d7c: adrp    x0, #0x6266000                             
02cc3d80: ldr     x0, [x0, #0x970]                           T:UnityEngine.Vector2
02cc3d84: bl      #0x2b70db0                                 fn_2b70db0
02cc3d88: mov     w8, #1                                     
02cc3d8c: strb    w8, [x22, #0xbda]                          
02cc3d90: adrp    x23, #0x6266000                            
02cc3d94: ldr     x23, [x23, #0x970]                         T:UnityEngine.Vector2
02cc3d98: ldr     x0, [x20]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02cc3d9c: ldr     x21, [x19, #0x48]                          ._baseRect
02cc3da0: ldr     x20, [x19, #0x58]                          ._cam
02cc3da4: ldr     x8, [x23]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cc3da8: ldr     x8, [x8, #0xb8]                            
02cc3dac: ldr     d0, [x8]                                   
02cc3db0: ldr     w8, [x0, #0xe4]                            [62660e4]=0 f=0,0
02cc3db4: str     d0, [sp, #8]                               
02cc3db8: cbnz    w8, #0x2cc3dc0                             
02cc3dbc: bl      #0x2b70f30                                 fn_2b70f30
02cc3dc0: fmov    s0, s9                                     
02cc3dc4: fmov    s1, s8                                     
02cc3dc8: add     x2, sp, #8                                 
02cc3dcc: mov     x0, x21                                    
02cc3dd0: mov     x1, x20                                    
02cc3dd4: mov     x3, xzr                                    
02cc3dd8: bl      #0x5e47a80                                 UnityEngine.RectTransformUtility::ScreenPointToLocalPointInRectangle
02cc3ddc: tbz     w0, #0, #0x2cc3e60                         
02cc3de0: ldr     x0, [x19, #0x48]                           ._baseRect
02cc3de4: cbz     x0, #0x2cc3eac                             
02cc3de8: mov     x1, xzr                                    
02cc3dec: bl      #0x5b45a5c                                 UnityEngine.RectTransform::get_pivot
02cc3df0: ldr     x0, [x19, #0x48]                           ._baseRect
02cc3df4: cbz     x0, #0x2cc3eac                             
02cc3df8: mov     x1, xzr                                    
02cc3dfc: fmov    s8, s0                                     
02cc3e00: fmov    s9, s1                                     
02cc3e04: bl      #0x5b458c8                                 UnityEngine.RectTransform::get_sizeDelta
02cc3e08: ldr     x0, [x19, #0x20]                           ._background
02cc3e0c: cbz     x0, #0x2cc3eac                             
02cc3e10: ldp     s14, s15, [sp, #8]                         
02cc3e14: mov     x1, xzr                                    
02cc3e18: fmov    s10, s0                                    
02cc3e1c: fmov    s11, s1                                    
02cc3e20: bl      #0x5b455a0                                 UnityEngine.RectTransform::get_anchorMax
02cc3e24: ldr     x0, [x19, #0x48]                           ._baseRect
02cc3e28: cbz     x0, #0x2cc3eac                             
02cc3e2c: mov     x1, xzr                                    
02cc3e30: fmov    s12, s0                                    
02cc3e34: fmov    s13, s1                                    
02cc3e38: fmul    s8, s8, s10                                
02cc3e3c: fmul    s9, s9, s11                                
02cc3e40: bl      #0x5b458c8                                 UnityEngine.RectTransform::get_sizeDelta
02cc3e44: fmul    s0, s12, s0                                
02cc3e48: fmul    s1, s13, s1                                
02cc3e4c: fsub    s0, s14, s0                                
02cc3e50: fsub    s1, s15, s1                                
02cc3e54: fadd    s0, s8, s0                                 
02cc3e58: fadd    s1, s9, s1                                 
02cc3e5c: b       #0x2cc3e88                                 
02cc3e60: ldrb    w8, [x22, #0xbda]                          
02cc3e64: cbnz    w8, #0x2cc3e7c                             
02cc3e68: adrp    x0, #0x6266000                             
02cc3e6c: ldr     x0, [x0, #0x970]                           T:UnityEngine.Vector2
02cc3e70: bl      #0x2b70db0                                 fn_2b70db0
02cc3e74: mov     w8, #1                                     
02cc3e78: strb    w8, [x22, #0xbda]                          
02cc3e7c: ldr     x8, [x23]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cc3e80: ldr     x8, [x8, #0xb8]                            
02cc3e84: ldp     s0, s1, [x8]                               
02cc3e88: ldp     x20, x19, [sp, #0x70]                      
02cc3e8c: ldp     x22, x21, [sp, #0x60]                      
02cc3e90: ldp     x30, x23, [sp, #0x50]                      
02cc3e94: ldp     d9, d8, [sp, #0x40]                        
02cc3e98: ldp     d11, d10, [sp, #0x30]                      
02cc3e9c: ldp     d13, d12, [sp, #0x20]                      
02cc3ea0: ldp     d15, d14, [sp, #0x10]                      
02cc3ea4: add     sp, sp, #0x80                              
02cc3ea8: ret                                                
02cc3eac: bl      #0x2b7105c                                 fn_2b7105c
## .ctor() -> void
---- Framework.Joystick::.ctor 0x2cc3f58
02cc3f58: str     x30, [sp, #-0x20]!                         
02cc3f5c: stp     x20, x19, [sp, #0x10]                      
02cc3f60: adrp    x20, #0x662f000                            
02cc3f64: mov     x19, x0                                    
02cc3f68: mov     w9, #0x3f800000                            
02cc3f6c: ldrb    w8, [x20, #0xbda]                          
02cc3f70: str     w9, [x0, #0x30]                            ._handleRange
02cc3f74: cbnz    w8, #0x2cc3f8c                             
02cc3f78: adrp    x0, #0x6266000                             
02cc3f7c: ldr     x0, [x0, #0x970]                           T:UnityEngine.Vector2
02cc3f80: bl      #0x2b70db0                                 fn_2b70db0
02cc3f84: mov     w8, #1                                     
02cc3f88: strb    w8, [x20, #0xbda]                          
02cc3f8c: adrp    x8, #0x6266000                             
02cc3f90: mov     x0, x19                                    
02cc3f94: mov     x1, xzr                                    
02cc3f98: ldr     x8, [x8, #0x970]                           T:UnityEngine.Vector2
02cc3f9c: ldr     x8, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cc3fa0: ldr     x8, [x8, #0xb8]                            S:'banner_native_refresh_time'
02cc3fa4: ldr     d0, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cc3fa8: str     d0, [x19, #0x40]                           ._input
02cc3fac: ldp     x20, x19, [sp, #0x10]                      
02cc3fb0: ldr     x30, [sp], #0x20                           
02cc3fb4: b       #0x5b397b0                                 UnityEngine.MonoBehaviour::.ctor
