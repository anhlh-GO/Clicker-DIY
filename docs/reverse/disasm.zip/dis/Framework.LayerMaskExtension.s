#### CLASS Framework.LayerMaskExtension parent= object
## GetRaycastValue(UnityEngine.LayerMask mask) -> int
---- Framework.LayerMaskExtension::GetRaycastValue 0x2cb8d3c
02cb8d3c: str     x30, [sp, #-0x10]!                         
02cb8d40: and     x0, x0, #0xffffffff                        
02cb8d44: mov     x1, xzr                                    
02cb8d48: bl      #0x5b37668                                 UnityEngine.LayerMask::op_Implicit
02cb8d4c: mov     w8, #1                                     
02cb8d50: lsl     w0, w8, w0                                 
02cb8d54: ldr     x30, [sp], #0x10                           
02cb8d58: ret                                                
## Contains(UnityEngine.LayerMask mask, int layer) -> bool
---- Framework.LayerMaskExtension::Contains 0x2cb8d5c
02cb8d5c: sub     sp, sp, #0x20                              
02cb8d60: stp     x30, x19, [sp, #0x10]                      
02cb8d64: mov     w19, w1                                    
02cb8d68: str     w0, [sp, #0xc]                             
02cb8d6c: add     x0, sp, #0xc                               
02cb8d70: mov     x1, xzr                                    
02cb8d74: bl      #0x5b37670                                 UnityEngine.LayerMask::get_value
02cb8d78: mov     w8, #1                                     
02cb8d7c: lsl     w8, w8, w19                                
02cb8d80: ldp     x30, x19, [sp, #0x10]                      
02cb8d84: tst     w0, w8                                     
02cb8d88: cset    w0, gt                                     
02cb8d8c: add     sp, sp, #0x20                              
02cb8d90: ret                                                
## Inverse(UnityEngine.LayerMask original) -> UnityEngine.LayerMask
---- Framework.LayerMaskExtension::Inverse 0x2cb8d94
02cb8d94: str     x30, [sp, #-0x10]!                         
02cb8d98: and     x0, x0, #0xffffffff                        
02cb8d9c: mov     x1, xzr                                    
02cb8da0: bl      #0x5b37668                                 UnityEngine.LayerMask::op_Implicit
02cb8da4: mvn     w0, w0                                     
02cb8da8: mov     x1, xzr                                    
02cb8dac: ldr     x30, [sp], #0x10                           
02cb8db0: b       #0x5b3766c                                 UnityEngine.LayerMask::op_Implicit
## AddToMask(UnityEngine.LayerMask original, string[] layerNames) -> UnityEngine.LayerMask
---- Framework.LayerMaskExtension::AddToMask 0x2cb8db4
02cb8db4: str     x30, [sp, #-0x20]!                         
02cb8db8: stp     x20, x19, [sp, #0x10]                      
02cb8dbc: mov     x19, x1                                    
02cb8dc0: and     x0, x0, #0xffffffff                        
02cb8dc4: mov     x1, xzr                                    
02cb8dc8: bl      #0x5b37668                                 UnityEngine.LayerMask::op_Implicit
02cb8dcc: mov     w20, w0                                    
02cb8dd0: mov     x0, x19                                    
02cb8dd4: bl      #0x2cb8df8                                 Framework.LayerMaskHelper::NamesToMask
02cb8dd8: mov     w0, w0                                     
02cb8ddc: mov     x1, xzr                                    
02cb8de0: bl      #0x5b37668                                 UnityEngine.LayerMask::op_Implicit
02cb8de4: orr     w0, w0, w20                                
02cb8de8: ldp     x20, x19, [sp, #0x10]                      
02cb8dec: mov     x1, xzr                                    
02cb8df0: ldr     x30, [sp], #0x20                           
02cb8df4: b       #0x5b3766c                                 UnityEngine.LayerMask::op_Implicit
## RemoveFromMask(UnityEngine.LayerMask original, string[] layerNames) -> UnityEngine.LayerMask
---- Framework.LayerMaskExtension::RemoveFromMask 0x2cb8e9c
02cb8e9c: str     x30, [sp, #-0x20]!                         
02cb8ea0: stp     x20, x19, [sp, #0x10]                      
02cb8ea4: mov     x19, x1                                    
02cb8ea8: and     x0, x0, #0xffffffff                        
02cb8eac: mov     x1, xzr                                    
02cb8eb0: bl      #0x5b37668                                 UnityEngine.LayerMask::op_Implicit
02cb8eb4: mvn     w0, w0                                     
02cb8eb8: mov     x1, xzr                                    
02cb8ebc: bl      #0x5b3766c                                 UnityEngine.LayerMask::op_Implicit
02cb8ec0: mov     w0, w0                                     
02cb8ec4: mov     x1, xzr                                    
02cb8ec8: bl      #0x5b37668                                 UnityEngine.LayerMask::op_Implicit
02cb8ecc: mov     w20, w0                                    
02cb8ed0: mov     x0, x19                                    
02cb8ed4: bl      #0x2cb8df8                                 Framework.LayerMaskHelper::NamesToMask
02cb8ed8: mov     w0, w0                                     
02cb8edc: mov     x1, xzr                                    
02cb8ee0: bl      #0x5b37668                                 UnityEngine.LayerMask::op_Implicit
02cb8ee4: orr     w8, w0, w20                                
02cb8ee8: ldp     x20, x19, [sp, #0x10]                      
02cb8eec: mvn     w0, w8                                     
02cb8ef0: mov     x1, xzr                                    
02cb8ef4: ldr     x30, [sp], #0x20                           
02cb8ef8: b       #0x5b3766c                                 UnityEngine.LayerMask::op_Implicit
## MaskToNames(UnityEngine.LayerMask original) -> string[]
---- Framework.LayerMaskExtension::MaskToNames 0x2cb8efc
02cb8efc: str     x30, [sp, #-0x40]!                         
02cb8f00: stp     x24, x23, [sp, #0x10]                      
02cb8f04: stp     x22, x21, [sp, #0x20]                      
02cb8f08: stp     x20, x19, [sp, #0x30]                      
02cb8f0c: adrp    x22, #0x662f000                            
02cb8f10: adrp    x21, #0x6266000                            
02cb8f14: adrp    x20, #0x6266000                            
02cb8f18: ldrb    w8, [x22, #0xbe6]                          
02cb8f1c: ldr     x21, [x21, #0xe48]                         T:type15376(k15)
02cb8f20: ldr     x20, [x20, #0xe50]                         MS:System.Collections.Generic.List`1::.ctor
02cb8f24: mov     x19, x0                                    
02cb8f28: tbnz    w8, #0, #0x2cb8f64                         
02cb8f2c: adrp    x0, #0x6266000                             
02cb8f30: ldr     x0, [x0, #0xe58]                           MS:System.Collections.Generic.List`1::Add
02cb8f34: bl      #0x2b70db0                                 fn_2b70db0
02cb8f38: adrp    x0, #0x6266000                             
02cb8f3c: ldr     x0, [x0, #0xe60]                           MS:System.Collections.Generic.List`1::ToArray
02cb8f40: bl      #0x2b70db0                                 fn_2b70db0
02cb8f44: adrp    x0, #0x6266000                             
02cb8f48: ldr     x0, [x0, #0xe50]                           MS:System.Collections.Generic.List`1::.ctor
02cb8f4c: bl      #0x2b70db0                                 fn_2b70db0
02cb8f50: adrp    x0, #0x6266000                             
02cb8f54: ldr     x0, [x0, #0xe48]                           T:type15376(k15)
02cb8f58: bl      #0x2b70db0                                 fn_2b70db0
02cb8f5c: mov     w8, #1                                     
02cb8f60: strb    w8, [x22, #0xbe6]                          
02cb8f64: adrp    x24, #0x6266000                            
02cb8f68: adrp    x23, #0x6266000                            
02cb8f6c: ldr     x24, [x24, #0xe58]                         MS:System.Collections.Generic.List`1::Add
02cb8f70: ldr     x23, [x23, #0xe60]                         MS:System.Collections.Generic.List`1::ToArray
02cb8f74: ldr     x0, [x21]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cb8f78: bl      #0x2b7104c                                 fn_2b7104c
02cb8f7c: ldr     x1, [x20]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cb8f80: mov     x20, x0                                    
02cb8f84: bl      #0x35a89a4                                 fn_35a89a4
02cb8f88: mov     w21, wzr                                   
02cb8f8c: and     x0, x19, #0xffffffff                       
02cb8f90: mov     x1, xzr                                    
02cb8f94: bl      #0x5b37668                                 UnityEngine.LayerMask::op_Implicit
02cb8f98: lsr     w8, w0, w21                                
02cb8f9c: tbz     w8, #0, #0x2cb901c                         
02cb8fa0: mov     w0, w21                                    
02cb8fa4: mov     x1, xzr                                    
02cb8fa8: bl      #0x5b37678                                 UnityEngine.LayerMask::LayerToName
02cb8fac: mov     x1, xzr                                    
02cb8fb0: mov     x22, x0                                    
02cb8fb4: bl      #0x4ca6234                                 System.String::IsNullOrEmpty
02cb8fb8: tbnz    w0, #0, #0x2cb901c                         
02cb8fbc: cbz     x20, #0x2cb9048                            
02cb8fc0: ldr     w10, [x20, #0x1c]                          [626601c]=0 f=0,0
02cb8fc4: ldr     x8, [x20, #0x10]                           S:'mrec_ad_on_off'
02cb8fc8: ldr     x9, [x24]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cb8fcc: add     w10, w10, #1                               
02cb8fd0: str     w10, [x20, #0x1c]                          
02cb8fd4: cbz     x8, #0x2cb9048                             
02cb8fd8: ldrsw   x10, [x20, #0x18]                          
02cb8fdc: ldr     w11, [x8, #0x18]                           
02cb8fe0: cmp     w10, w11                                   
02cb8fe4: b.hs    #0x2cb9004                                 
02cb8fe8: add     x0, x8, x10, lsl #3                        
02cb8fec: add     w9, w10, #1                                
02cb8ff0: mov     x1, x22                                    
02cb8ff4: str     w9, [x20, #0x18]                           
02cb8ff8: str     x22, [x0, #0x20]!                          
02cb8ffc: bl      #0x2b70d54                                 fn_2b70d54
02cb9000: b       #0x2cb901c                                 
02cb9004: ldr     x8, [x9, #0x20]                            
02cb9008: mov     x0, x20                                    
02cb900c: mov     x1, x22                                    
02cb9010: ldr     x8, [x8, #0xc0]                            
02cb9014: ldr     x2, [x8, #0x70]                            
02cb9018: bl      #0x35a920c                                 fn_35a920c
02cb901c: add     w21, w21, #1                               
02cb9020: cmp     w21, #0x20                                 
02cb9024: b.ne    #0x2cb8f8c                                 
02cb9028: cbz     x20, #0x2cb9048                            
02cb902c: ldr     x1, [x23]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cb9030: mov     x0, x20                                    
02cb9034: ldp     x20, x19, [sp, #0x30]                      
02cb9038: ldp     x22, x21, [sp, #0x20]                      
02cb903c: ldp     x24, x23, [sp, #0x10]                      
02cb9040: ldr     x30, [sp], #0x40                           
02cb9044: b       #0x35aade4                                 
02cb9048: bl      #0x2b7105c                                 fn_2b7105c
## MaskToNumbers(UnityEngine.LayerMask original) -> int[]
---- Framework.LayerMaskExtension::MaskToNumbers 0x2cb904c
02cb904c: stp     x30, x23, [sp, #-0x30]!                    
02cb9050: stp     x22, x21, [sp, #0x10]                      
02cb9054: stp     x20, x19, [sp, #0x20]                      
02cb9058: adrp    x22, #0x662f000                            
02cb905c: adrp    x21, #0x6266000                            
02cb9060: adrp    x20, #0x6266000                            
02cb9064: ldrb    w8, [x22, #0xbe7]                          
02cb9068: ldr     x21, [x21, #0x648]                         T:type15061(k15)
02cb906c: ldr     x20, [x20, #0x650]                         MS:System.Collections.Generic.List`1::.ctor
02cb9070: mov     x19, x0                                    
02cb9074: tbnz    w8, #0, #0x2cb90b0                         
02cb9078: adrp    x0, #0x6266000                             
02cb907c: ldr     x0, [x0, #0x818]                           MS:System.Collections.Generic.List`1::Add
02cb9080: bl      #0x2b70db0                                 fn_2b70db0
02cb9084: adrp    x0, #0x6266000                             
02cb9088: ldr     x0, [x0, #0xe68]                           MS:System.Collections.Generic.List`1::ToArray
02cb908c: bl      #0x2b70db0                                 fn_2b70db0
02cb9090: adrp    x0, #0x6266000                             
02cb9094: ldr     x0, [x0, #0x650]                           MS:System.Collections.Generic.List`1::.ctor
02cb9098: bl      #0x2b70db0                                 fn_2b70db0
02cb909c: adrp    x0, #0x6266000                             
02cb90a0: ldr     x0, [x0, #0x648]                           T:type15061(k15)
02cb90a4: bl      #0x2b70db0                                 fn_2b70db0
02cb90a8: mov     w8, #1                                     
02cb90ac: strb    w8, [x22, #0xbe7]                          
02cb90b0: adrp    x23, #0x6266000                            
02cb90b4: adrp    x22, #0x6266000                            
02cb90b8: ldr     x23, [x23, #0x818]                         MS:System.Collections.Generic.List`1::Add
02cb90bc: ldr     x22, [x22, #0xe68]                         MS:System.Collections.Generic.List`1::ToArray
02cb90c0: ldr     x0, [x21]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cb90c4: bl      #0x2b7104c                                 fn_2b7104c
02cb90c8: ldr     x1, [x20]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cb90cc: mov     x20, x0                                    
02cb90d0: bl      #0x3569388                                 fn_3569388
02cb90d4: mov     w21, wzr                                   
02cb90d8: and     x0, x19, #0xffffffff                       
02cb90dc: mov     x1, xzr                                    
02cb90e0: bl      #0x5b37668                                 UnityEngine.LayerMask::op_Implicit
02cb90e4: lsr     w8, w0, w21                                
02cb90e8: tbz     w8, #0, #0x2cb9144                         
02cb90ec: cbz     x20, #0x2cb916c                            
02cb90f0: ldr     w10, [x20, #0x1c]                          [626601c]=0 f=0,0
02cb90f4: ldr     x8, [x20, #0x10]                           S:'mrec_ad_on_off'
02cb90f8: ldr     x9, [x23]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cb90fc: add     w10, w10, #1                               
02cb9100: str     w10, [x20, #0x1c]                          
02cb9104: cbz     x8, #0x2cb916c                             
02cb9108: ldrsw   x10, [x20, #0x18]                          
02cb910c: ldr     w11, [x8, #0x18]                           
02cb9110: cmp     w10, w11                                   
02cb9114: b.hs    #0x2cb912c                                 
02cb9118: add     x8, x8, x10, lsl #2                        
02cb911c: add     w9, w10, #1                                
02cb9120: str     w9, [x20, #0x18]                           
02cb9124: str     w21, [x8, #0x20]                           
02cb9128: b       #0x2cb9144                                 
02cb912c: ldr     x8, [x9, #0x20]                            
02cb9130: mov     x0, x20                                    
02cb9134: mov     w1, w21                                    
02cb9138: ldr     x8, [x8, #0xc0]                            
02cb913c: ldr     x2, [x8, #0x70]                            
02cb9140: bl      #0x3569c18                                 fn_3569c18
02cb9144: add     w21, w21, #1                               
02cb9148: cmp     w21, #0x20                                 
02cb914c: b.ne    #0x2cb90d8                                 
02cb9150: cbz     x20, #0x2cb916c                            
02cb9154: ldr     x1, [x22]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cb9158: mov     x0, x20                                    
02cb915c: ldp     x20, x19, [sp, #0x20]                      
02cb9160: ldp     x22, x21, [sp, #0x10]                      
02cb9164: ldp     x30, x23, [sp], #0x30                      
02cb9168: b       #0x356b750                                 
02cb916c: bl      #0x2b7105c                                 fn_2b7105c
## MaskToString(UnityEngine.LayerMask original) -> string
---- Framework.LayerMaskExtension::MaskToString 0x2cb9170
02cb9170: stp     x30, x21, [sp, #-0x20]!                    
02cb9174: stp     x20, x19, [sp, #0x10]                      
02cb9178: adrp    x20, #0x662f000                            
02cb917c: adrp    x21, #0x6266000                            
02cb9180: mov     x19, x0                                    
02cb9184: ldrb    w8, [x20, #0xbe8]                          
02cb9188: ldr     x21, [x21, #0x2f8]                         S:', '
02cb918c: tbnz    w8, #0, #0x2cb91a4                         
02cb9190: adrp    x0, #0x6266000                             
02cb9194: ldr     x0, [x0, #0x2f8]                           S:', '
02cb9198: bl      #0x2b70db0                                 fn_2b70db0
02cb919c: mov     w8, #1                                     
02cb91a0: strb    w8, [x20, #0xbe8]                          
02cb91a4: ldr     x20, [x21]                                 M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cb91a8: and     x0, x19, #0xffffffff                       
02cb91ac: bl      #0x2cb8efc                                 Framework.LayerMaskExtension::MaskToNames
02cb91b0: mov     x1, x0                                     
02cb91b4: mov     x0, x20                                    
02cb91b8: mov     x2, xzr                                    
02cb91bc: ldp     x20, x19, [sp, #0x10]                      
02cb91c0: ldp     x30, x21, [sp], #0x20                      
02cb91c4: b       #0x4ca7b44                                 System.String::Join
## MaskToString(UnityEngine.LayerMask original, string delimiter) -> string
---- Framework.LayerMaskExtension::MaskToString 0x2cb91c8
02cb91c8: stp     x30, x19, [sp, #-0x10]!                    
02cb91cc: and     x0, x0, #0xffffffff                        
02cb91d0: mov     x19, x1                                    
02cb91d4: bl      #0x2cb8efc                                 Framework.LayerMaskExtension::MaskToNames
02cb91d8: mov     x1, x0                                     
02cb91dc: mov     x0, x19                                    
02cb91e0: mov     x2, xzr                                    
02cb91e4: ldp     x30, x19, [sp], #0x10                      
02cb91e8: b       #0x4ca7b44                                 System.String::Join
