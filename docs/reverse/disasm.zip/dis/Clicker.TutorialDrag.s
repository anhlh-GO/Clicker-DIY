#### CLASS Clicker.TutorialDrag parent= UnityEngine.MonoBehaviour
#   field _srHand                        UnityEngine.SpriteRenderer                         off=0x20 attr=1 SerializeField
#   field _tfHand                        UnityEngine.Transform                              off=0x28 attr=1 SerializeField
#   field _appearPos                     UnityEngine.Transform                              off=0x30 attr=1 SerializeField
#   field _movePos                       System.Collections.Generic.List`1<UnityEngine.Transform> off=0x38 attr=1 SerializeField
#   field _endPos                        UnityEngine.Transform                              off=0x40 attr=1 SerializeField
#   field _moveSpeed                     float                                              off=0x48 attr=1 SerializeField
#   field _sequence                      DG.Tweening.Sequence                               off=0x50 attr=1 
## Show() -> void
---- Clicker.TutorialDrag::Show 0x2d747ac
02d747ac: stp     x30, x25, [sp, #-0x40]!                    
02d747b0: stp     x24, x23, [sp, #0x10]                      
02d747b4: stp     x22, x21, [sp, #0x20]                      
02d747b8: stp     x20, x19, [sp, #0x30]                      
02d747bc: adrp    x20, #0x6630000                            
02d747c0: mov     x19, x0                                    
02d747c4: ldrb    w8, [x20, #0x3cc]                          
02d747c8: tbnz    w8, #0, #0x2d74834                         
02d747cc: adrp    x0, #0x6268000                             
02d747d0: ldr     x0, [x0, #0x420]                           T:type53168(k15)
02d747d4: bl      #0x2b70db0                                 fn_2b70db0
02d747d8: adrp    x0, #0x6263000                             
02d747dc: ldr     x0, [x0, #0xfd0]                           T:DG.Tweening.DOTween
02d747e0: bl      #0x2b70db0                                 fn_2b70db0
02d747e4: adrp    x0, #0x6268000                             
02d747e8: ldr     x0, [x0, #0x428]                           MS:System.Collections.Generic.List`1::ForEach
02d747ec: bl      #0x2b70db0                                 fn_2b70db0
02d747f0: adrp    x0, #0x626c000                             
02d747f4: ldr     x0, [x0, #0x788]                           M:Clicker.TutorialDrag::<Show>b__7_0
02d747f8: bl      #0x2b70db0                                 fn_2b70db0
02d747fc: adrp    x0, #0x626c000                             
02d74800: ldr     x0, [x0, #0x790]                           M:Clicker.TutorialDrag::<Show>b__7_1
02d74804: bl      #0x2b70db0                                 fn_2b70db0
02d74808: adrp    x0, #0x6264000                             
02d7480c: ldr     x0, [x0, #0xe8]                            T:DG.Tweening.TweenCallback
02d74810: bl      #0x2b70db0                                 fn_2b70db0
02d74814: adrp    x0, #0x6268000                             
02d74818: ldr     x0, [x0, #0x320]                           MS:DG.Tweening.TweenSettingsExtensions::SetLoops
02d7481c: bl      #0x2b70db0                                 fn_2b70db0
02d74820: adrp    x0, #0x626a000                             
02d74824: ldr     x0, [x0, #0xd08]                           MS:DG.Tweening.TweenSettingsExtensions::SetSpeedBased
02d74828: bl      #0x2b70db0                                 fn_2b70db0
02d7482c: mov     w8, #1                                     
02d74830: strb    w8, [x20, #0x3cc]                          
02d74834: ldr     x0, [x19, #0x20]                           ._srHand
02d74838: mov     w1, wzr                                    
02d7483c: mov     x2, xzr                                    
02d74840: bl      #0x2d9d5d0                                 DG.Tweening.ShortcutExtensions::DOKill
02d74844: movi    d0, #0000000000000000                      
02d74848: movi    d1, #0000000000000000                      
02d7484c: ldr     x0, [x19, #0x20]                           ._srHand
02d74850: mov     x1, xzr                                    
02d74854: bl      #0x2c77d0c                                 DG.Tweening.DOTweenModuleSprite::DOFade
02d74858: ldr     x0, [x19, #0x28]                           ._tfHand
02d7485c: mov     w1, wzr                                    
02d74860: mov     x2, xzr                                    
02d74864: bl      #0x2d9d5d0                                 DG.Tweening.ShortcutExtensions::DOKill
02d74868: ldr     x0, [x19, #0x30]                           ._appearPos
02d7486c: cbz     x0, #0x2d74a18                             
02d74870: ldr     x20, [x19, #0x28]                          ._tfHand
02d74874: mov     x1, xzr                                    
02d74878: bl      #0x5b467ac                                 UnityEngine.Transform::get_position
02d7487c: cbz     x20, #0x2d74a18                            
02d74880: adrp    x23, #0x6263000                            
02d74884: adrp    x22, #0x6268000                            
02d74888: adrp    x21, #0x626c000                            
02d7488c: ldr     x23, [x23, #0xfd0]                         T:DG.Tweening.DOTween
02d74890: ldr     x22, [x22, #0x420]                         T:type53168(k15)
02d74894: ldr     x21, [x21, #0x788]                         M:Clicker.TutorialDrag::<Show>b__7_0
02d74898: mov     x0, x20                                    
02d7489c: mov     x1, xzr                                    
02d748a0: bl      #0x5b46888                                 UnityEngine.Transform::set_position
02d748a4: ldr     x0, [x23]                                  &2c5bbd4(=a9bd7bfdd503233f)
02d748a8: ldr     w8, [x0, #0xe4]                            [626a0e4]=0 f=0,0
02d748ac: cbnz    w8, #0x2d748b4                             
02d748b0: bl      #0x2b70f30                                 fn_2b70f30
02d748b4: mov     x0, xzr                                    
02d748b8: bl      #0x2d8cfe8                                 DG.Tweening.DOTween::Sequence
02d748bc: mov     x20, x19                                   
02d748c0: mov     x1, x0                                     
02d748c4: str     x0, [x20, #0x50]!                          ._sequence
02d748c8: mov     x0, x20                                    
02d748cc: bl      #0x2b70d54                                 fn_2b70d54
02d748d0: fmov    s0, #1.00000000                            
02d748d4: fmov    s1, #0.50000000                            
02d748d8: ldr     x0, [x19, #0x20]                           ._srHand
02d748dc: ldr     x20, [x20]                                 
02d748e0: mov     x1, xzr                                    
02d748e4: bl      #0x2c77d0c                                 DG.Tweening.DOTweenModuleSprite::DOFade
02d748e8: mov     x1, x0                                     
02d748ec: mov     x0, x20                                    
02d748f0: mov     x2, xzr                                    
02d748f4: bl      #0x2d9b0a8                                 DG.Tweening.TweenSettingsExtensions::Append
02d748f8: ldr     x0, [x22]                                  S:'{0}/2'
02d748fc: ldr     x20, [x19, #0x38]                          ._movePos
02d74900: bl      #0x2b7104c                                 fn_2b7104c
02d74904: ldr     x2, [x21]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d74908: mov     x1, x19                                    
02d7490c: mov     x3, xzr                                    
02d74910: mov     x21, x0                                    
02d74914: bl      #0x453418c                                 fn_453418c
02d74918: cbz     x20, #0x2d74a18                            
02d7491c: adrp    x8, #0x6268000                             
02d74920: mov     x0, x20                                    
02d74924: mov     x1, x21                                    
02d74928: ldr     x8, [x8, #0x428]                           MS:System.Collections.Generic.List`1::ForEach
02d7492c: ldr     x2, [x8]                                   S:'{0}/2'
02d74930: bl      #0x35a9ce4                                 fn_35a9ce4
02d74934: ldr     x0, [x19, #0x40]                           ._endPos
02d74938: cbz     x0, #0x2d74a18                             
02d7493c: adrp    x25, #0x626a000                            
02d74940: adrp    x24, #0x6264000                            
02d74944: adrp    x23, #0x626c000                            
02d74948: adrp    x22, #0x6268000                            
02d7494c: ldr     x25, [x25, #0xd08]                         MS:DG.Tweening.TweenSettingsExtensions::SetSpeedBased
02d74950: ldr     x24, [x24, #0xe8]                          T:DG.Tweening.TweenCallback
02d74954: ldr     x23, [x23, #0x790]                         M:Clicker.TutorialDrag::<Show>b__7_1
02d74958: ldr     x22, [x22, #0x320]                         MS:DG.Tweening.TweenSettingsExtensions::SetLoops
02d7495c: ldr     x20, [x19, #0x28]                          ._tfHand
02d74960: ldr     x21, [x19, #0x50]                          ._sequence
02d74964: mov     x1, xzr                                    
02d74968: bl      #0x5b467ac                                 UnityEngine.Transform::get_position
02d7496c: ldr     s3, [x19, #0x48]                           ._moveSpeed
02d74970: mov     x0, x20                                    
02d74974: mov     w1, wzr                                    
02d74978: mov     x2, xzr                                    
02d7497c: bl      #0x2d975e4                                 DG.Tweening.ShortcutExtensions::DOMove
02d74980: ldr     x2, [x25]                                  T:type56879(k15)
02d74984: mov     w1, #1                                     
02d74988: bl      #0x336ff88                                 fn_336ff88
02d7498c: mov     x1, x0                                     
02d74990: mov     x0, x21                                    
02d74994: mov     x2, xzr                                    
02d74998: bl      #0x2d9b0a8                                 DG.Tweening.TweenSettingsExtensions::Append
02d7499c: movi    d0, #0000000000000000                      
02d749a0: fmov    s1, #0.50000000                            
02d749a4: ldr     x0, [x19, #0x20]                           ._srHand
02d749a8: ldr     x20, [x19, #0x50]                          ._sequence
02d749ac: mov     x1, xzr                                    
02d749b0: bl      #0x2c77d0c                                 DG.Tweening.DOTweenModuleSprite::DOFade
02d749b4: mov     x1, x0                                     
02d749b8: mov     x0, x20                                    
02d749bc: mov     x2, xzr                                    
02d749c0: bl      #0x2d9b0a8                                 DG.Tweening.TweenSettingsExtensions::Append
02d749c4: ldr     x0, [x24]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d749c8: ldr     x20, [x19, #0x50]                          ._sequence
02d749cc: bl      #0x2b7104c                                 fn_2b7104c
02d749d0: ldr     x2, [x23]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d749d4: mov     x1, x19                                    
02d749d8: mov     x3, xzr                                    
02d749dc: mov     x21, x0                                    
02d749e0: bl      #0x2d89dc4                                 DG.Tweening.TweenCallback::.ctor
02d749e4: mov     x0, x20                                    
02d749e8: mov     x1, x21                                    
02d749ec: mov     x2, xzr                                    
02d749f0: bl      #0x2da03d8                                 DG.Tweening.TweenSettingsExtensions::AppendCallback
02d749f4: ldr     x0, [x19, #0x50]                           ._sequence
02d749f8: ldr     x3, [x22]                                  S:'{0}/2'
02d749fc: mov     w1, #-1                                    
02d74a00: ldp     x20, x19, [sp, #0x30]                      
02d74a04: mov     w2, wzr                                    
02d74a08: ldp     x22, x21, [sp, #0x20]                      
02d74a0c: ldp     x24, x23, [sp, #0x10]                      
02d74a10: ldp     x30, x25, [sp], #0x40                      
02d74a14: b       #0x336fe74                                 
02d74a18: bl      #0x2b7105c                                 fn_2b7105c
## Hide() -> void
---- Clicker.TutorialDrag::Hide 0x2d74a1c
02d74a1c: str     x30, [sp, #-0x20]!                         
02d74a20: stp     x20, x19, [sp, #0x10]                      
02d74a24: mov     x20, x0                                    
02d74a28: mov     x19, x0                                    
02d74a2c: ldr     x0, [x20, #0x50]!                          ._sequence
02d74a30: cbz     x0, #0x2d74a50                             
02d74a34: mov     w1, wzr                                    
02d74a38: mov     x2, xzr                                    
02d74a3c: bl      #0x2d8fe94                                 DG.Tweening.TweenExtensions::Kill
02d74a40: mov     x0, x20                                    
02d74a44: mov     x1, xzr                                    
02d74a48: str     xzr, [x20]                                 
02d74a4c: bl      #0x2b70d54                                 fn_2b70d54
02d74a50: ldr     x0, [x19, #0x28]                           ._tfHand
02d74a54: mov     w1, wzr                                    
02d74a58: mov     x2, xzr                                    
02d74a5c: bl      #0x2d9d5d0                                 DG.Tweening.ShortcutExtensions::DOKill
02d74a60: ldr     x0, [x19, #0x20]                           ._srHand
02d74a64: mov     w1, wzr                                    
02d74a68: mov     x2, xzr                                    
02d74a6c: bl      #0x2d9d5d0                                 DG.Tweening.ShortcutExtensions::DOKill
02d74a70: ldr     x0, [x19, #0x20]                           ._srHand
02d74a74: ldp     x20, x19, [sp, #0x10]                      
02d74a78: movi    d0, #0000000000000000                      
02d74a7c: movi    d1, #0000000000000000                      
02d74a80: mov     x1, xzr                                    
02d74a84: ldr     x30, [sp], #0x20                           
02d74a88: b       #0x2c77d0c                                 DG.Tweening.DOTweenModuleSprite::DOFade
## .ctor() -> void
---- Clicker.TutorialDrag::.ctor 0x2d74a8c
02d74a8c: mov     x1, xzr                                    
02d74a90: b       #0x5b397b0                                 UnityEngine.MonoBehaviour::.ctor
## <Show>b__7_0(UnityEngine.Transform pos) -> void
---- Clicker.TutorialDrag::<Show>b__7_0 0x2d74a94
02d74a94: stp     x30, x23, [sp, #-0x30]!                    
02d74a98: stp     x22, x21, [sp, #0x10]                      
02d74a9c: stp     x20, x19, [sp, #0x20]                      
02d74aa0: adrp    x21, #0x6630000                            
02d74aa4: mov     x20, x1                                    
02d74aa8: mov     x19, x0                                    
02d74aac: ldrb    w8, [x21, #0x3cd]                          
02d74ab0: tbnz    w8, #0, #0x2d74ac8                         
02d74ab4: adrp    x0, #0x626a000                             
02d74ab8: ldr     x0, [x0, #0xd08]                           MS:DG.Tweening.TweenSettingsExtensions::SetSpeedBased
02d74abc: bl      #0x2b70db0                                 fn_2b70db0
02d74ac0: mov     w8, #1                                     
02d74ac4: strb    w8, [x21, #0x3cd]                          
02d74ac8: cbz     x20, #0x2d74b24                            
02d74acc: adrp    x23, #0x626a000                            
02d74ad0: mov     x0, x20                                    
02d74ad4: mov     x1, xzr                                    
02d74ad8: ldr     x23, [x23, #0xd08]                         MS:DG.Tweening.TweenSettingsExtensions::SetSpeedBased
02d74adc: ldr     x21, [x19, #0x28]                          ._tfHand
02d74ae0: ldr     x22, [x19, #0x50]                          ._sequence
02d74ae4: bl      #0x5b467ac                                 UnityEngine.Transform::get_position
02d74ae8: ldr     s3, [x19, #0x48]                           ._moveSpeed
02d74aec: mov     x0, x21                                    
02d74af0: mov     w1, wzr                                    
02d74af4: mov     x2, xzr                                    
02d74af8: bl      #0x2d975e4                                 DG.Tweening.ShortcutExtensions::DOMove
02d74afc: ldr     x2, [x23]                                  T:type56879(k15)
02d74b00: mov     w1, #1                                     
02d74b04: bl      #0x336ff88                                 fn_336ff88
02d74b08: mov     x1, x0                                     
02d74b0c: mov     x0, x22                                    
02d74b10: mov     x2, xzr                                    
02d74b14: ldp     x20, x19, [sp, #0x20]                      
02d74b18: ldp     x22, x21, [sp, #0x10]                      
02d74b1c: ldp     x30, x23, [sp], #0x30                      
02d74b20: b       #0x2d9b0a8                                 DG.Tweening.TweenSettingsExtensions::Append
02d74b24: bl      #0x2b7105c                                 fn_2b7105c
## <Show>b__7_1() -> void
---- Clicker.TutorialDrag::<Show>b__7_1 0x2d74b28
02d74b28: stp     x30, x19, [sp, #-0x10]!                    
02d74b2c: mov     x19, x0                                    
02d74b30: ldr     x0, [x0, #0x28]                            ._tfHand
02d74b34: mov     w1, wzr                                    
02d74b38: mov     x2, xzr                                    
02d74b3c: bl      #0x2d9d5d0                                 DG.Tweening.ShortcutExtensions::DOKill
02d74b40: ldr     x0, [x19, #0x30]                           ._appearPos
02d74b44: cbz     x0, #0x2d74b68                             
02d74b48: ldr     x19, [x19, #0x28]                          ._tfHand
02d74b4c: mov     x1, xzr                                    
02d74b50: bl      #0x5b467ac                                 UnityEngine.Transform::get_position
02d74b54: cbz     x19, #0x2d74b68                            
02d74b58: mov     x0, x19                                    
02d74b5c: mov     x1, xzr                                    
02d74b60: ldp     x30, x19, [sp], #0x10                      
02d74b64: b       #0x5b46888                                 UnityEngine.Transform::set_position
02d74b68: bl      #0x2b7105c                                 fn_2b7105c
