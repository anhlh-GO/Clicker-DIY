#### CLASS Clicker.ClickerLivestreamController parent= MonoSingleton`1<Clicker.ClickerLivestreamController>
#   field _camera                        UnityEngine.Camera                                 off=0x20 attr=1 SerializeField
## PlayLiveCamera() -> void
---- Clicker.ClickerLivestreamController::PlayLiveCamera 0x2d665a0
02d665a0: ret                                                
## .ctor() -> void
---- Clicker.ClickerLivestreamController::.ctor 0x2d665a4
02d665a4: stp     x30, x21, [sp, #-0x20]!                    
02d665a8: stp     x20, x19, [sp, #0x10]                      
02d665ac: adrp    x20, #0x6630000                            
02d665b0: adrp    x21, #0x626c000                            
02d665b4: mov     x19, x0                                    
02d665b8: ldrb    w8, [x20, #0x334]                          
02d665bc: ldr     x21, [x21, #0x1b0]                         MS:MonoSingleton`1::.ctor
02d665c0: tbnz    w8, #0, #0x2d665d8                         
02d665c4: adrp    x0, #0x626c000                             
02d665c8: ldr     x0, [x0, #0x1b0]                           MS:MonoSingleton`1::.ctor
02d665cc: bl      #0x2b70db0                                 fn_2b70db0
02d665d0: mov     w8, #1                                     
02d665d4: strb    w8, [x20, #0x334]                          
02d665d8: mov     x0, x19                                    
02d665dc: ldp     x20, x19, [sp, #0x10]                      
02d665e0: ldr     x1, [x21]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d665e4: ldp     x30, x21, [sp], #0x20                      
02d665e8: b       #0x3769e18                                 
