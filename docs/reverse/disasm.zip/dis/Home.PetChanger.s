#### CLASS Home.PetChanger parent= UnityEngine.MonoBehaviour
#   field _petName                       string                                             off=0x20 attr=1 SerializeField
#   field _boxTrigger                    Home.BoxTrigger                                    off=0x28 attr=1 SerializeField
#   field _skeleton                      Spine.Unity.SkeletonAnimation                      off=0x30 attr=1 SerializeField
#   field _data                          Home.PetHomeDataItem                               off=0x38 attr=1 SerializeField
## OnEnable() -> void
---- Home.PetChanger::OnEnable 0x2d23d78
02d23d78: stp     x30, x23, [sp, #-0x30]!                    
02d23d7c: stp     x22, x21, [sp, #0x10]                      
02d23d80: stp     x20, x19, [sp, #0x20]                      
02d23d84: adrp    x20, #0x6630000                            
02d23d88: mov     x19, x0                                    
02d23d8c: ldrb    w8, [x20, #0x5b]                           
02d23d90: tbnz    w8, #0, #0x2d23dcc                         
02d23d94: adrp    x0, #0x6269000                             
02d23d98: ldr     x0, [x0, #0xef0]                           M:Home.PetChanger::OnPressed
02d23d9c: bl      #0x2b70db0                                 fn_2b70db0
02d23da0: adrp    x0, #0x6269000                             
02d23da4: ldr     x0, [x0, #0xef8]                           M:Home.PetChanger::<OnEnable>b__4_0
02d23da8: bl      #0x2b70db0                                 fn_2b70db0
02d23dac: adrp    x0, #0x6264000                             
02d23db0: ldr     x0, [x0, #0xe8]                            T:DG.Tweening.TweenCallback
02d23db4: bl      #0x2b70db0                                 fn_2b70db0
02d23db8: adrp    x0, #0x6269000                             
02d23dbc: ldr     x0, [x0, #0xf00]                           T:type58822(k15)
02d23dc0: bl      #0x2b70db0                                 fn_2b70db0
02d23dc4: mov     w8, #1                                     
02d23dc8: strb    w8, [x20, #0x5b]                           
02d23dcc: ldr     x20, [x19, #0x28]                          ._boxTrigger
02d23dd0: cbz     x20, #0x2d23eb4                            
02d23dd4: adrp    x23, #0x6269000                            
02d23dd8: adrp    x22, #0x6269000                            
02d23ddc: ldr     x23, [x23, #0xf00]                         T:type58822(k15)
02d23de0: ldr     x22, [x22, #0xef0]                         M:Home.PetChanger::OnPressed
02d23de4: ldr     x21, [x20, #0x28]!                         ._boxTrigger
02d23de8: ldr     x0, [x23]                                  T:Trading.TradingSession/<>c__DisplayClass56_0
02d23dec: bl      #0x2b7104c                                 fn_2b7104c
02d23df0: ldr     x2, [x22]                                  T:Trading.TradingSession/<>c__DisplayClass56_0
02d23df4: mov     x1, x19                                    
02d23df8: mov     x3, xzr                                    
02d23dfc: mov     x22, x0                                    
02d23e00: bl      #0x3edf920                                 fn_3edf920
02d23e04: mov     x0, x21                                    
02d23e08: mov     x1, x22                                    
02d23e0c: mov     x2, xzr                                    
02d23e10: bl      #0x4e570ac                                 System.Delegate::Combine
02d23e14: cbz     x0, #0x2d23e54                             
02d23e18: ldr     x22, [x23]                                 T:Trading.TradingSession/<>c__DisplayClass56_0
02d23e1c: mov     x21, x0                                    
02d23e20: mov     x1, x22                                    
02d23e24: bl      #0x2b70f34                                 fn_2b70f34
02d23e28: cbz     x0, #0x2d23e48                             
02d23e2c: ldr     x22, [x23]                                 T:Trading.TradingSession/<>c__DisplayClass56_0
02d23e30: str     x0, [x20]                                  
02d23e34: mov     x0, x21                                    
02d23e38: mov     x1, x22                                    
02d23e3c: bl      #0x2b70f34                                 fn_2b70f34
02d23e40: mov     x1, x0                                     
02d23e44: cbnz    x0, #0x2d23e5c                             
02d23e48: mov     x0, x21                                    
02d23e4c: mov     x1, x22                                    
02d23e50: bl      #0x2b713dc                                 fn_2b713dc
02d23e54: mov     x1, xzr                                    
02d23e58: str     xzr, [x20]                                 
02d23e5c: adrp    x21, #0x6264000                            
02d23e60: adrp    x22, #0x6269000                            
02d23e64: mov     x0, x20                                    
02d23e68: ldr     x21, [x21, #0xe8]                          T:DG.Tweening.TweenCallback
02d23e6c: ldr     x22, [x22, #0xef8]                         M:Home.PetChanger::<OnEnable>b__4_0
02d23e70: bl      #0x2b70d54                                 fn_2b70d54
02d23e74: ldr     x0, [x21]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d23e78: bl      #0x2b7104c                                 fn_2b7104c
02d23e7c: ldr     x2, [x22]                                  T:Trading.TradingSession/<>c__DisplayClass56_0
02d23e80: mov     x1, x19                                    
02d23e84: mov     x3, xzr                                    
02d23e88: mov     x20, x0                                    
02d23e8c: bl      #0x2d89dc4                                 DG.Tweening.TweenCallback::.ctor
02d23e90: adrp    x8, #0x1084000                             
02d23e94: mov     x0, x20                                    
02d23e98: mov     w1, #1                                     
02d23e9c: ldp     x20, x19, [sp, #0x20]                      
02d23ea0: ldr     s0, [x8, #0xeec]                           [1084eec]=457ff0003dcccccd f=0.1,4095
02d23ea4: ldp     x22, x21, [sp, #0x10]                      
02d23ea8: mov     x2, xzr                                    
02d23eac: ldp     x30, x23, [sp], #0x30                      
02d23eb0: b       #0x2d8f37c                                 DG.Tweening.DOVirtual::DelayedCall
02d23eb4: bl      #0x2b7105c                                 fn_2b7105c
## OnDisable() -> void
---- Home.PetChanger::OnDisable 0x2d23eb8
02d23eb8: stp     x30, x23, [sp, #-0x30]!                    
02d23ebc: stp     x22, x21, [sp, #0x10]                      
02d23ec0: stp     x20, x19, [sp, #0x20]                      
02d23ec4: adrp    x20, #0x6630000                            
02d23ec8: mov     x19, x0                                    
02d23ecc: ldrb    w8, [x20, #0x5c]                           
02d23ed0: tbnz    w8, #0, #0x2d23f0c                         
02d23ed4: adrp    x0, #0x6269000                             
02d23ed8: ldr     x0, [x0, #0xf08]                           M:Home.PetChanger::OnCompletedAnimation
02d23edc: bl      #0x2b70db0                                 fn_2b70db0
02d23ee0: adrp    x0, #0x6269000                             
02d23ee4: ldr     x0, [x0, #0xef0]                           M:Home.PetChanger::OnPressed
02d23ee8: bl      #0x2b70db0                                 fn_2b70db0
02d23eec: adrp    x0, #0x6266000                             
02d23ef0: ldr     x0, [x0, #0xbf0]                           T:Spine.AnimationState/TrackEntryDelegate
02d23ef4: bl      #0x2b70db0                                 fn_2b70db0
02d23ef8: adrp    x0, #0x6269000                             
02d23efc: ldr     x0, [x0, #0xf00]                           T:type58822(k15)
02d23f00: bl      #0x2b70db0                                 fn_2b70db0
02d23f04: mov     w8, #1                                     
02d23f08: strb    w8, [x20, #0x5c]                           
02d23f0c: ldr     x20, [x19, #0x28]                          ._boxTrigger
02d23f10: cbz     x20, #0x2d23ffc                            
02d23f14: adrp    x23, #0x6269000                            
02d23f18: adrp    x22, #0x6269000                            
02d23f1c: ldr     x23, [x23, #0xf00]                         T:type58822(k15)
02d23f20: ldr     x22, [x22, #0xef0]                         M:Home.PetChanger::OnPressed
02d23f24: ldr     x21, [x20, #0x28]!                         ._boxTrigger
02d23f28: ldr     x0, [x23]                                  T:Trading.TradingSession/<>c__DisplayClass56_0
02d23f2c: bl      #0x2b7104c                                 fn_2b7104c
02d23f30: ldr     x2, [x22]                                  T:Trading.TradingSession/<>c__DisplayClass56_0
02d23f34: mov     x1, x19                                    
02d23f38: mov     x3, xzr                                    
02d23f3c: mov     x22, x0                                    
02d23f40: bl      #0x3edf920                                 fn_3edf920
02d23f44: mov     x0, x21                                    
02d23f48: mov     x1, x22                                    
02d23f4c: mov     x2, xzr                                    
02d23f50: bl      #0x4e57298                                 System.Delegate::Remove
02d23f54: cbz     x0, #0x2d23f94                             
02d23f58: ldr     x22, [x23]                                 T:Trading.TradingSession/<>c__DisplayClass56_0
02d23f5c: mov     x21, x0                                    
02d23f60: mov     x1, x22                                    
02d23f64: bl      #0x2b70f34                                 fn_2b70f34
02d23f68: cbz     x0, #0x2d23f88                             
02d23f6c: ldr     x22, [x23]                                 T:Trading.TradingSession/<>c__DisplayClass56_0
02d23f70: str     x0, [x20]                                  
02d23f74: mov     x0, x21                                    
02d23f78: mov     x1, x22                                    
02d23f7c: bl      #0x2b70f34                                 fn_2b70f34
02d23f80: mov     x1, x0                                     
02d23f84: cbnz    x0, #0x2d23f9c                             
02d23f88: mov     x0, x21                                    
02d23f8c: mov     x1, x22                                    
02d23f90: bl      #0x2b713dc                                 fn_2b713dc
02d23f94: mov     x1, xzr                                    
02d23f98: str     xzr, [x20]                                 
02d23f9c: mov     x0, x20                                    
02d23fa0: bl      #0x2b70d54                                 fn_2b70d54
02d23fa4: ldr     x8, [x19, #0x30]                           ._skeleton
02d23fa8: cbz     x8, #0x2d23ffc                             
02d23fac: adrp    x9, #0x6266000                             
02d23fb0: adrp    x21, #0x6269000                            
02d23fb4: ldr     x9, [x9, #0xbf0]                           T:Spine.AnimationState/TrackEntryDelegate
02d23fb8: ldr     x21, [x21, #0xf08]                         M:Home.PetChanger::OnCompletedAnimation
02d23fbc: ldr     x20, [x8, #0x110]                          
02d23fc0: ldr     x0, [x9]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d23fc4: bl      #0x2b7104c                                 fn_2b7104c
02d23fc8: ldr     x2, [x21]                                  T:Trading.TradingSession/<>c__DisplayClass56_0
02d23fcc: mov     x1, x19                                    
02d23fd0: mov     x3, xzr                                    
02d23fd4: mov     x21, x0                                    
02d23fd8: bl      #0x4f98140                                 Spine.AnimationState/TrackEntryDelegate::.ctor
02d23fdc: cbz     x20, #0x2d23ffc                            
02d23fe0: mov     x0, x20                                    
02d23fe4: mov     x1, x21                                    
02d23fe8: mov     x2, xzr                                    
02d23fec: ldp     x20, x19, [sp, #0x20]                      
02d23ff0: ldp     x22, x21, [sp, #0x10]                      
02d23ff4: ldp     x30, x23, [sp], #0x30                      
02d23ff8: b       #0x4f94c3c                                 Spine.AnimationState::remove_Complete
02d23ffc: bl      #0x2b7105c                                 fn_2b7105c
## AnimIdle() -> void
---- Home.PetChanger::AnimIdle 0x2d24000
02d24000: ldr     x8, [x0, #0x38]                            ._data
02d24004: cbz     x8, #0x2d24014                             
02d24008: ldr     x1, [x8, #0x30]                            
02d2400c: mov     w2, #1                                     
02d24010: b       #0x2d2401c                                 Home.PetChanger::SetAnimation
02d24014: str     x30, [sp, #-0x10]!                         
02d24018: bl      #0x2b7105c                                 fn_2b7105c
## SetAnimation(string code, bool isLoop) -> void
---- Home.PetChanger::SetAnimation 0x2d2401c
02d2401c: stp     x30, x25, [sp, #-0x40]!                    
02d24020: stp     x24, x23, [sp, #0x10]                      
02d24024: stp     x22, x21, [sp, #0x20]                      
02d24028: stp     x20, x19, [sp, #0x30]                      
02d2402c: adrp    x22, #0x6630000                            
02d24030: mov     w21, w2                                    
02d24034: mov     x20, x1                                    
02d24038: ldrb    w8, [x22, #0x5d]                           
02d2403c: mov     x19, x0                                    
02d24040: tbnz    w8, #0, #0x2d24058                         
02d24044: adrp    x0, #0x6266000                             
02d24048: ldr     x0, [x0, #0x880]                           MS:DG.Tweening.TweenSettingsExtensions::SetEase
02d2404c: bl      #0x2b70db0                                 fn_2b70db0
02d24050: mov     w8, #1                                     
02d24054: strb    w8, [x22, #0x5d]                           
02d24058: mov     x0, x19                                    
02d2405c: mov     x1, xzr                                    
02d24060: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02d24064: mov     w1, wzr                                    
02d24068: mov     x2, xzr                                    
02d2406c: bl      #0x2d9d5d0                                 DG.Tweening.ShortcutExtensions::DOKill
02d24070: mov     x0, x19                                    
02d24074: mov     x1, xzr                                    
02d24078: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02d2407c: adrp    x23, #0x662f000                            
02d24080: mov     x22, x0                                    
02d24084: ldrb    w8, [x23, #0x91a]                          
02d24088: cbnz    w8, #0x2d240a0                             
02d2408c: adrp    x0, #0x6264000                             
02d24090: ldr     x0, [x0, #0xd8]                            T:UnityEngine.Vector3
02d24094: bl      #0x2b70db0                                 fn_2b70db0
02d24098: mov     w8, #1                                     
02d2409c: strb    w8, [x23, #0x91a]                          
02d240a0: cbz     x22, #0x2d24180                            
02d240a4: adrp    x24, #0x6264000                            
02d240a8: adrp    x23, #0x6266000                            
02d240ac: mov     x0, x22                                    
02d240b0: ldr     x24, [x24, #0xd8]                          T:UnityEngine.Vector3
02d240b4: mov     x1, xzr                                    
02d240b8: ldr     x8, [x24]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d240bc: ldr     x8, [x8, #0xb8]                            
02d240c0: ldr     x23, [x23, #0x880]                         MS:DG.Tweening.TweenSettingsExtensions::SetEase
02d240c4: ldp     s1, s2, [x8, #4]                           
02d240c8: ldr     s0, [x8]                                   
02d240cc: bl      #0x5b470cc                                 UnityEngine.Transform::set_localScale
02d240d0: mov     x0, x19                                    
02d240d4: mov     x1, xzr                                    
02d240d8: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02d240dc: adrp    x25, #0x662f000                            
02d240e0: mov     x22, x0                                    
02d240e4: ldrb    w8, [x25, #0xa74]                          
02d240e8: cbnz    w8, #0x2d24100                             
02d240ec: adrp    x0, #0x6264000                             
02d240f0: ldr     x0, [x0, #0xd8]                            T:UnityEngine.Vector3
02d240f4: bl      #0x2b70db0                                 fn_2b70db0
02d240f8: mov     w8, #1                                     
02d240fc: strb    w8, [x25, #0xa74]                          
02d24100: ldr     x8, [x24]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d24104: mov     x0, x22                                    
02d24108: mov     x1, xzr                                    
02d2410c: ldr     x8, [x8, #0xb8]                            
02d24110: ldp     s0, s1, [x8, #0xc]                         
02d24114: ldr     s2, [x8, #0x14]                            
02d24118: adrp    x8, #0x1084000                             
02d2411c: ldr     s3, [x8, #0xda8]                           [1084da8]=da242603eb851ec f=0.36,1e-30
02d24120: bl      #0x2d98af8                                 DG.Tweening.ShortcutExtensions::DOScale
02d24124: ldr     x2, [x23]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d24128: mov     w1, #0x1b                                  
02d2412c: bl      #0x336fa0c                                 fn_336fa0c
02d24130: ldr     x8, [x19, #0x30]                           ._skeleton
02d24134: cbz     x8, #0x2d24180                             
02d24138: ldr     x0, [x8, #0x110]                           [1084110]=2926726570706172 f=2.97577e+29,3.69586e-14
02d2413c: cbz     x0, #0x2d24180                             
02d24140: and     w3, w21, #1                                
02d24144: mov     w1, wzr                                    
02d24148: mov     x2, x20                                    
02d2414c: mov     x4, xzr                                    
02d24150: bl      #0x4f97234                                 Spine.AnimationState::SetAnimation
02d24154: ldr     x8, [x19, #0x30]                           ._skeleton
02d24158: cbz     x8, #0x2d24180                             
02d2415c: ldr     x0, [x8, #0x110]                           [1084110]=2926726570706172 f=2.97577e+29,3.69586e-14
02d24160: cbz     x0, #0x2d24180                             
02d24164: ldp     x20, x19, [sp, #0x30]                      
02d24168: mov     x2, xzr                                    
02d2416c: ldp     x22, x21, [sp, #0x20]                      
02d24170: ldr     x1, [x8, #0xc8]                            [10840c8]=552c656c676e6953 f=1.12587e+24,1.1847e+13
02d24174: ldp     x24, x23, [sp, #0x10]                      
02d24178: ldp     x30, x25, [sp], #0x40                      
02d2417c: b       #0x4f95698                                 Spine.AnimationState::Apply
02d24180: bl      #0x2b7105c                                 fn_2b7105c
## SetPet(Home.PetHomeDataItem data) -> void
---- Home.PetChanger::SetPet 0x2d24184
02d24184: str     x30, [sp, #-0x40]!                         
02d24188: stp     x24, x23, [sp, #0x10]                      
02d2418c: stp     x22, x21, [sp, #0x20]                      
02d24190: stp     x20, x19, [sp, #0x30]                      
02d24194: adrp    x21, #0x6630000                            
02d24198: mov     x19, x1                                    
02d2419c: mov     x20, x0                                    
02d241a0: ldrb    w8, [x21, #0x5e]                           
02d241a4: tbnz    w8, #0, #0x2d241e0                         
02d241a8: adrp    x0, #0x6269000                             
02d241ac: ldr     x0, [x0, #0xf08]                           M:Home.PetChanger::OnCompletedAnimation
02d241b0: bl      #0x2b70db0                                 fn_2b70db0
02d241b4: adrp    x0, #0x6269000                             
02d241b8: ldr     x0, [x0, #0xf10]                           M:Home.PetChanger::<SetPet>b__8_0
02d241bc: bl      #0x2b70db0                                 fn_2b70db0
02d241c0: adrp    x0, #0x6266000                             
02d241c4: ldr     x0, [x0, #0xbf0]                           T:Spine.AnimationState/TrackEntryDelegate
02d241c8: bl      #0x2b70db0                                 fn_2b70db0
02d241cc: adrp    x0, #0x6264000                             
02d241d0: ldr     x0, [x0, #0xe8]                            T:DG.Tweening.TweenCallback
02d241d4: bl      #0x2b70db0                                 fn_2b70db0
02d241d8: mov     w8, #1                                     
02d241dc: strb    w8, [x21, #0x5e]                           
02d241e0: mov     x0, x20                                    
02d241e4: mov     x1, x19                                    
02d241e8: str     x19, [x0, #0x38]!                          ._data
02d241ec: bl      #0x2b70d54                                 fn_2b70d54
02d241f0: cbz     x19, #0x2d2431c                            
02d241f4: ldr     x1, [x19, #0x18]                           
02d241f8: mov     x21, x20                                   
02d241fc: str     x1, [x21, #0x20]!                          ._petName
02d24200: mov     x0, x21                                    
02d24204: bl      #0x2b70d54                                 fn_2b70d54
02d24208: ldr     x0, [x21, #0x10]                           
02d2420c: cbz     x0, #0x2d2431c                             
02d24210: ldr     x1, [x19, #0x20]                           ._petName
02d24214: str     x1, [x0, #0x20]!                           ._petName
02d24218: bl      #0x2b70d54                                 fn_2b70d54
02d2421c: ldr     x0, [x20, #0x30]                           ._skeleton
02d24220: cbz     x0, #0x2d2431c                             
02d24224: ldr     x8, [x0]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d24228: mov     w1, #1                                     
02d2422c: mov     w2, wzr                                    
02d24230: ldp     x9, x3, [x8, #0x1c8]                       
02d24234: blr     x9                                         
02d24238: ldr     x8, [x20, #0x30]                           ._skeleton
02d2423c: cbz     x8, #0x2d2431c                             
02d24240: ldr     x0, [x8, #0xc8]                            
02d24244: cbz     x0, #0x2d2431c                             
02d24248: ldr     x1, [x19, #0x28]                           ._boxTrigger
02d2424c: mov     x2, xzr                                    
02d24250: bl      #0x4fa9b14                                 Spine.Skeleton::SetSkin
02d24254: ldr     x8, [x20, #0x30]                           ._skeleton
02d24258: cbz     x8, #0x2d2431c                             
02d2425c: ldr     x0, [x8, #0xc8]                            
02d24260: cbz     x0, #0x2d2431c                             
02d24264: mov     x1, xzr                                    
02d24268: bl      #0x4fa96e4                                 Spine.Skeleton::SetToSetupPose
02d2426c: ldr     x8, [x20, #0x30]                           ._skeleton
02d24270: cbz     x8, #0x2d2431c                             
02d24274: adrp    x9, #0x6266000                             
02d24278: adrp    x22, #0x6269000                            
02d2427c: ldr     x9, [x9, #0xbf0]                           T:Spine.AnimationState/TrackEntryDelegate
02d24280: ldr     x22, [x22, #0xf08]                         M:Home.PetChanger::OnCompletedAnimation
02d24284: ldr     x21, [x8, #0x110]                          
02d24288: ldr     x0, [x9]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d2428c: bl      #0x2b7104c                                 fn_2b7104c
02d24290: ldr     x2, [x22]                                  T:Trading.TradingSession/<>c__DisplayClass56_0
02d24294: mov     x1, x20                                    
02d24298: mov     x3, xzr                                    
02d2429c: mov     x22, x0                                    
02d242a0: bl      #0x4f98140                                 Spine.AnimationState/TrackEntryDelegate::.ctor
02d242a4: cbz     x21, #0x2d2431c                            
02d242a8: adrp    x23, #0x6264000                            
02d242ac: adrp    x24, #0x6269000                            
02d242b0: mov     x0, x21                                    
02d242b4: ldr     x23, [x23, #0xe8]                          T:DG.Tweening.TweenCallback
02d242b8: ldr     x24, [x24, #0xf10]                         M:Home.PetChanger::<SetPet>b__8_0
02d242bc: mov     x1, x22                                    
02d242c0: mov     x2, xzr                                    
02d242c4: bl      #0x4f94c3c                                 Spine.AnimationState::remove_Complete
02d242c8: ldr     x0, [x23]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d242cc: bl      #0x2b7104c                                 fn_2b7104c
02d242d0: ldr     x2, [x24]                                  T:Trading.TradingSession/<>c__DisplayClass56_0
02d242d4: mov     x1, x20                                    
02d242d8: mov     x3, xzr                                    
02d242dc: mov     x21, x0                                    
02d242e0: bl      #0x2d89dc4                                 DG.Tweening.TweenCallback::.ctor
02d242e4: adrp    x8, #0x1084000                             
02d242e8: mov     x0, x21                                    
02d242ec: mov     w1, #1                                     
02d242f0: ldr     s0, [x8, #0xeec]                           [1084eec]=457ff0003dcccccd f=0.1,4095
02d242f4: mov     x2, xzr                                    
02d242f8: bl      #0x2d8f37c                                 DG.Tweening.DOVirtual::DelayedCall
02d242fc: ldr     x1, [x19, #0x30]                           ._skeleton
02d24300: mov     x0, x20                                    
02d24304: mov     w2, #1                                     
02d24308: ldp     x20, x19, [sp, #0x30]                      
02d2430c: ldp     x22, x21, [sp, #0x20]                      
02d24310: ldp     x24, x23, [sp, #0x10]                      
02d24314: ldr     x30, [sp], #0x40                           
02d24318: b       #0x2d2401c                                 Home.PetChanger::SetAnimation
02d2431c: bl      #0x2b7105c                                 fn_2b7105c
## OnCompletedAnimation(Spine.TrackEntry trackentry) -> void
---- Home.PetChanger::OnCompletedAnimation 0x2d24320
02d24320: stp     x30, x19, [sp, #-0x10]!                    
02d24324: ldr     x8, [x0, #0x38]                            ._data
02d24328: cbz     x8, #0x2d24374                             
02d2432c: ldr     x9, [x0, #0x30]                            ._skeleton
02d24330: mov     x19, x0                                    
02d24334: cbz     x9, #0x2d24374                             
02d24338: ldr     x0, [x9, #0x110]                           
02d2433c: cbz     x0, #0x2d24374                             
02d24340: ldr     x2, [x8, #0x30]                            
02d24344: mov     w1, wzr                                    
02d24348: mov     w3, wzr                                    
02d2434c: mov     x4, xzr                                    
02d24350: bl      #0x4f97234                                 Spine.AnimationState::SetAnimation
02d24354: ldr     x8, [x19, #0x28]                           ._boxTrigger
02d24358: cbz     x8, #0x2d24374                             
02d2435c: ldr     x0, [x8, #0x30]                            
02d24360: cbz     x0, #0x2d24374                             
02d24364: mov     w1, #1                                     
02d24368: mov     x2, xzr                                    
02d2436c: ldp     x30, x19, [sp], #0x10                      
02d24370: b       #0x5b33110                                 UnityEngine.Behaviour::set_enabled
02d24374: bl      #0x2b7105c                                 fn_2b7105c
## OnPressed(Home.EntityName name) -> void
---- Home.PetChanger::OnPressed 0x2d24378
02d24378: stp     x30, x19, [sp, #-0x10]!                    
02d2437c: mov     x19, x0                                    
02d24380: mov     x0, xzr                                    
02d24384: bl      #0x2d6eec8                                 Framework.AudioManager::get_Instance
02d24388: cbz     x0, #0x2d243f8                             
02d2438c: movi    d1, #0000000000000000                      
02d24390: movi    d2, #0000000000000000                      
02d24394: mov     w1, #4                                     
02d24398: fmov    s0, #1.00000000                            
02d2439c: mov     w2, wzr                                    
02d243a0: mov     w3, wzr                                    
02d243a4: mov     x4, xzr                                    
02d243a8: bl      #0x2d6f03c                                 Framework.AudioManager::PlaySound
02d243ac: ldr     x8, [x19, #0x28]                           ._boxTrigger
02d243b0: cbz     x8, #0x2d243f8                             
02d243b4: ldr     x0, [x8, #0x30]                            
02d243b8: cbz     x0, #0x2d243f8                             
02d243bc: mov     w1, wzr                                    
02d243c0: mov     x2, xzr                                    
02d243c4: bl      #0x5b33110                                 UnityEngine.Behaviour::set_enabled
02d243c8: ldr     x8, [x19, #0x38]                           ._data
02d243cc: cbz     x8, #0x2d243f8                             
02d243d0: ldr     x9, [x19, #0x30]                           ._skeleton
02d243d4: cbz     x9, #0x2d243f8                             
02d243d8: ldr     x0, [x9, #0x110]                           
02d243dc: cbz     x0, #0x2d243f8                             
02d243e0: ldr     x2, [x8, #0x38]                            
02d243e4: mov     w1, wzr                                    
02d243e8: mov     w3, wzr                                    
02d243ec: mov     x4, xzr                                    
02d243f0: ldp     x30, x19, [sp], #0x10                      
02d243f4: b       #0x4f97234                                 Spine.AnimationState::SetAnimation
02d243f8: bl      #0x2b7105c                                 fn_2b7105c
## .ctor() -> void
---- Home.PetChanger::.ctor 0x2d243fc
02d243fc: mov     x1, xzr                                    
02d24400: b       #0x5b397b0                                 UnityEngine.MonoBehaviour::.ctor
## <OnEnable>b__4_0() -> void
---- Home.PetChanger::<OnEnable>b__4_0 0x2d24404
02d24404: stp     x30, x21, [sp, #-0x20]!                    
02d24408: stp     x20, x19, [sp, #0x10]                      
02d2440c: adrp    x20, #0x6630000                            
02d24410: mov     x19, x0                                    
02d24414: ldrb    w8, [x20, #0x5f]                           
02d24418: tbnz    w8, #0, #0x2d2443c                         
02d2441c: adrp    x0, #0x6269000                             
02d24420: ldr     x0, [x0, #0xf08]                           M:Home.PetChanger::OnCompletedAnimation
02d24424: bl      #0x2b70db0                                 fn_2b70db0
02d24428: adrp    x0, #0x6266000                             
02d2442c: ldr     x0, [x0, #0xbf0]                           T:Spine.AnimationState/TrackEntryDelegate
02d24430: bl      #0x2b70db0                                 fn_2b70db0
02d24434: mov     w8, #1                                     
02d24438: strb    w8, [x20, #0x5f]                           
02d2443c: ldr     x8, [x19, #0x30]                           ._skeleton
02d24440: cbz     x8, #0x2d24490                             
02d24444: adrp    x9, #0x6266000                             
02d24448: adrp    x21, #0x6269000                            
02d2444c: ldr     x9, [x9, #0xbf0]                           T:Spine.AnimationState/TrackEntryDelegate
02d24450: ldr     x21, [x21, #0xf08]                         M:Home.PetChanger::OnCompletedAnimation
02d24454: ldr     x20, [x8, #0x110]                          
02d24458: ldr     x0, [x9]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d2445c: bl      #0x2b7104c                                 fn_2b7104c
02d24460: ldr     x2, [x21]                                  T:Trading.TradingSession/<>c__DisplayClass56_0
02d24464: mov     x1, x19                                    
02d24468: mov     x3, xzr                                    
02d2446c: mov     x21, x0                                    
02d24470: bl      #0x4f98140                                 Spine.AnimationState/TrackEntryDelegate::.ctor
02d24474: cbz     x20, #0x2d24490                            
02d24478: mov     x0, x20                                    
02d2447c: ldp     x20, x19, [sp, #0x10]                      
02d24480: mov     x1, x21                                    
02d24484: mov     x2, xzr                                    
02d24488: ldp     x30, x21, [sp], #0x20                      
02d2448c: b       #0x4f94ba0                                 Spine.AnimationState::add_Complete
02d24490: bl      #0x2b7105c                                 fn_2b7105c
## <SetPet>b__8_0() -> void
---- Home.PetChanger::<SetPet>b__8_0 0x2d24494
02d24494: stp     x30, x21, [sp, #-0x20]!                    
02d24498: stp     x20, x19, [sp, #0x10]                      
02d2449c: adrp    x20, #0x6630000                            
02d244a0: mov     x19, x0                                    
02d244a4: ldrb    w8, [x20, #0x60]                           
02d244a8: tbnz    w8, #0, #0x2d244cc                         
02d244ac: adrp    x0, #0x6269000                             
02d244b0: ldr     x0, [x0, #0xf08]                           M:Home.PetChanger::OnCompletedAnimation
02d244b4: bl      #0x2b70db0                                 fn_2b70db0
02d244b8: adrp    x0, #0x6266000                             
02d244bc: ldr     x0, [x0, #0xbf0]                           T:Spine.AnimationState/TrackEntryDelegate
02d244c0: bl      #0x2b70db0                                 fn_2b70db0
02d244c4: mov     w8, #1                                     
02d244c8: strb    w8, [x20, #0x60]                           
02d244cc: ldr     x8, [x19, #0x30]                           ._skeleton
02d244d0: cbz     x8, #0x2d24520                             
02d244d4: adrp    x9, #0x6266000                             
02d244d8: adrp    x21, #0x6269000                            
02d244dc: ldr     x9, [x9, #0xbf0]                           T:Spine.AnimationState/TrackEntryDelegate
02d244e0: ldr     x21, [x21, #0xf08]                         M:Home.PetChanger::OnCompletedAnimation
02d244e4: ldr     x20, [x8, #0x110]                          
02d244e8: ldr     x0, [x9]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d244ec: bl      #0x2b7104c                                 fn_2b7104c
02d244f0: ldr     x2, [x21]                                  T:Trading.TradingSession/<>c__DisplayClass56_0
02d244f4: mov     x1, x19                                    
02d244f8: mov     x3, xzr                                    
02d244fc: mov     x21, x0                                    
02d24500: bl      #0x4f98140                                 Spine.AnimationState/TrackEntryDelegate::.ctor
02d24504: cbz     x20, #0x2d24520                            
02d24508: mov     x0, x20                                    
02d2450c: ldp     x20, x19, [sp, #0x10]                      
02d24510: mov     x1, x21                                    
02d24514: mov     x2, xzr                                    
02d24518: ldp     x30, x21, [sp], #0x20                      
02d2451c: b       #0x4f94ba0                                 Spine.AnimationState::add_Complete
02d24520: bl      #0x2b7105c                                 fn_2b7105c
