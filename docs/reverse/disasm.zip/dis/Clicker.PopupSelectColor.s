#### CLASS Clicker.PopupSelectColor/<>c__DisplayClass10_0 parent= object
#   field index                          int                                                off=0x10 attr=6 
#   field <>4__this                      Clicker.PopupSelectColor                           off=0x18 attr=6 
## .ctor() -> void
---- Clicker.PopupSelectColor/<>c__DisplayClass10_0::.ctor 0x2d7063c
02d7063c: mov     x1, xzr                                    
02d70640: b       #0x4e53e9c                                 System.Object::.ctor
## <Init>b__0() -> void
---- Clicker.PopupSelectColor/<>c__DisplayClass10_0::<Init>b__0 0x2d709c0
02d709c0: ldr     x8, [x0, #0x18]                            .<>4__this
02d709c4: cbz     x8, #0x2d709d4                             
02d709c8: ldr     w1, [x0, #0x10]                            .index
02d709cc: mov     x0, x8                                     
02d709d0: b       #0x2d707d4                                 Clicker.PopupSelectColor::OnButtonClick
02d709d4: str     x30, [sp, #-0x10]!                         
02d709d8: bl      #0x2b7105c                                 fn_2b7105c
#### CLASS Clicker.PopupSelectColor parent= UnityEngine.MonoBehaviour
#   field _colorButton                   UnityEngine.UI.Button[]                            off=0x20 attr=1 SerializeField
#   field _selected                      UnityEngine.Transform                              off=0x28 attr=1 SerializeField
#   field _canvasGroup                   UnityEngine.CanvasGroup                            off=0x30 attr=1 SerializeField
#   field _tfPanel                       UnityEngine.Transform                              off=0x38 attr=1 SerializeField
#   field _tfSubPanel                    UnityEngine.Transform                              off=0x40 attr=1 SerializeField
#   field _selectedIndex                 int                                                off=0x48 attr=1 
#   field _ingameClickerScreen           Clicker.IngameClickerScreen                        off=0x50 attr=1 
#   field _isShowing                     bool                                               off=0x58 attr=1 
#   field _tfParent                      UnityEngine.Transform                              off=0x60 attr=1 
## Awake() -> void
---- Clicker.PopupSelectColor::Awake 0x2d7047c
02d7047c: stp     x30, x19, [sp, #-0x10]!                    
02d70480: mov     x19, x0                                    
02d70484: ldr     x0, [x0, #0x30]                            ._canvasGroup
02d70488: cbz     x0, #0x2d704c4                             
02d7048c: movi    d0, #0000000000000000                      
02d70490: mov     x1, xzr                                    
02d70494: bl      #0x5e45108                                 UnityEngine.CanvasGroup::set_alpha
02d70498: ldr     x0, [x19, #0x30]                           ._canvasGroup
02d7049c: cbz     x0, #0x2d704c4                             
02d704a0: mov     w1, wzr                                    
02d704a4: mov     x2, xzr                                    
02d704a8: bl      #0x5e45290                                 UnityEngine.CanvasGroup::set_interactable
02d704ac: ldr     x0, [x19, #0x30]                           ._canvasGroup
02d704b0: cbz     x0, #0x2d704c4                             
02d704b4: mov     w1, wzr                                    
02d704b8: mov     x2, xzr                                    
02d704bc: ldp     x30, x19, [sp], #0x10                      
02d704c0: b       #0x5e45408                                 UnityEngine.CanvasGroup::set_blocksRaycasts
02d704c4: bl      #0x2b7105c                                 fn_2b7105c
## Init(Clicker.IngameClickerScreen ingameClickerScreen) -> void
---- Clicker.PopupSelectColor::Init 0x2d704c8
02d704c8: str     x30, [sp, #-0x50]!                         
02d704cc: stp     x26, x25, [sp, #0x10]                      
02d704d0: stp     x24, x23, [sp, #0x20]                      
02d704d4: stp     x22, x21, [sp, #0x30]                      
02d704d8: stp     x20, x19, [sp, #0x40]                      
02d704dc: adrp    x21, #0x6630000                            
02d704e0: mov     x20, x1                                    
02d704e4: mov     x19, x0                                    
02d704e8: ldrb    w8, [x21, #0x39f]                          
02d704ec: tbnz    w8, #0, #0x2d7051c                         
02d704f0: adrp    x0, #0x626c000                             
02d704f4: ldr     x0, [x0, #0x560]                           M:Clicker.PopupSelectColor/<>c__DisplayClass10_0::<Init>b__0
02d704f8: bl      #0x2b70db0                                 fn_2b70db0
02d704fc: adrp    x0, #0x626c000                             
02d70500: ldr     x0, [x0, #0x568]                           T:Clicker.PopupSelectColor/<>c__DisplayClass10_0
02d70504: bl      #0x2b70db0                                 fn_2b70db0
02d70508: adrp    x0, #0x6265000                             
02d7050c: ldr     x0, [x0, #0x3f0]                           T:UnityEngine.Events.UnityAction
02d70510: bl      #0x2b70db0                                 fn_2b70db0
02d70514: mov     w8, #1                                     
02d70518: strb    w8, [x21, #0x39f]                          
02d7051c: mov     x21, x19                                   
02d70520: mov     x1, x20                                    
02d70524: str     x20, [x21, #0x50]!                         ._ingameClickerScreen
02d70528: mov     x0, x21                                    
02d7052c: bl      #0x2b70d54                                 fn_2b70d54
02d70530: ldur    x8, [x21, #-0x30]                          
02d70534: cbz     x8, #0x2d7061c                             
02d70538: adrp    x23, #0x626c000                            
02d7053c: adrp    x24, #0x6265000                            
02d70540: adrp    x25, #0x626c000                            
02d70544: ldr     x23, [x23, #0x568]                         T:Clicker.PopupSelectColor/<>c__DisplayClass10_0
02d70548: ldr     x24, [x24, #0x3f0]                         T:UnityEngine.Events.UnityAction
02d7054c: ldr     x25, [x25, #0x560]                         M:Clicker.PopupSelectColor/<>c__DisplayClass10_0::<Init>b__0
02d70550: mov     w26, #4                                    
02d70554: ldr     w8, [x8, #0x18]                            
02d70558: sub     x22, x26, #4                               
02d7055c: cmp     w22, w8                                    
02d70560: b.ge    #0x2d70620                                 
02d70564: ldr     x0, [x23]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d70568: bl      #0x2b7104c                                 fn_2b7104c
02d7056c: mov     x1, xzr                                    
02d70570: mov     x20, x0                                    
02d70574: bl      #0x4e53e9c                                 System.Object::.ctor
02d70578: cbz     x20, #0x2d7061c                            
02d7057c: mov     x21, x20                                   
02d70580: mov     x1, x19                                    
02d70584: str     x19, [x21, #0x18]!                         
02d70588: mov     x0, x21                                    
02d7058c: bl      #0x2b70d54                                 fn_2b70d54
02d70590: ldr     x8, [x19, #0x20]                           ._colorButton
02d70594: stur    w22, [x21, #-8]                            
02d70598: cbz     x8, #0x2d7061c                             
02d7059c: ldr     w9, [x8, #0x18]                            
02d705a0: cmp     w22, w9                                    
02d705a4: b.hs    #0x2d70638                                 
02d705a8: ldr     x8, [x8, x26, lsl #3]                      
02d705ac: cbz     x8, #0x2d7061c                             
02d705b0: ldr     x0, [x8, #0x100]                           
02d705b4: cbz     x0, #0x2d7061c                             
02d705b8: mov     x1, xzr                                    
02d705bc: bl      #0x5b4ce48                                 UnityEngine.Events.UnityEventBase::RemoveAllListeners
02d705c0: ldr     x8, [x19, #0x20]                           ._colorButton
02d705c4: cbz     x8, #0x2d7061c                             
02d705c8: ldr     w9, [x8, #0x18]                            
02d705cc: cmp     w22, w9                                    
02d705d0: b.hs    #0x2d70638                                 
02d705d4: ldr     x8, [x8, x26, lsl #3]                      
02d705d8: cbz     x8, #0x2d7061c                             
02d705dc: ldr     x0, [x24]                                  M:AdsManager::<OnApplicationPause>b__26_0
02d705e0: ldr     x21, [x8, #0x100]                          
02d705e4: bl      #0x2b7104c                                 fn_2b7104c
02d705e8: ldr     x2, [x25]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d705ec: mov     x1, x20                                    
02d705f0: mov     x3, xzr                                    
02d705f4: mov     x22, x0                                    
02d705f8: bl      #0x5b4cf98                                 UnityEngine.Events.UnityAction::.ctor
02d705fc: cbz     x21, #0x2d7061c                            
02d70600: mov     x0, x21                                    
02d70604: mov     x1, x22                                    
02d70608: mov     x2, xzr                                    
02d7060c: bl      #0x5b4d0ac                                 UnityEngine.Events.UnityEvent::AddListener
02d70610: ldr     x8, [x19, #0x20]                           ._colorButton
02d70614: add     x26, x26, #1                               
02d70618: cbnz    x8, #0x2d70554                             
02d7061c: bl      #0x2b7105c                                 fn_2b7105c
02d70620: ldp     x20, x19, [sp, #0x40]                      
02d70624: ldp     x22, x21, [sp, #0x30]                      
02d70628: ldp     x24, x23, [sp, #0x20]                      
02d7062c: ldp     x26, x25, [sp, #0x10]                      
02d70630: ldr     x30, [sp], #0x50                           
02d70634: ret                                                
02d70638: bl      #0x2b71064                                 fn_2b71064
## ShowAt(UnityEngine.Transform parent, int selectedIndex) -> void
---- Clicker.PopupSelectColor::ShowAt 0x2d70644
02d70644: str     x30, [sp, #-0x50]!                         
02d70648: stp     x26, x25, [sp, #0x10]                      
02d7064c: stp     x24, x23, [sp, #0x20]                      
02d70650: stp     x22, x21, [sp, #0x30]                      
02d70654: stp     x20, x19, [sp, #0x40]                      
02d70658: adrp    x22, #0x6630000                            
02d7065c: mov     w19, w2                                    
02d70660: mov     x21, x1                                    
02d70664: ldrb    w8, [x22, #0x3a0]                          
02d70668: mov     x20, x0                                    
02d7066c: tbnz    w8, #0, #0x2d706a8                         
02d70670: adrp    x0, #0x626c000                             
02d70674: ldr     x0, [x0, #0x570]                           M:Clicker.PopupSelectColor::<ShowAt>b__11_0
02d70678: bl      #0x2b70db0                                 fn_2b70db0
02d7067c: adrp    x0, #0x6264000                             
02d70680: ldr     x0, [x0, #0xe8]                            T:DG.Tweening.TweenCallback
02d70684: bl      #0x2b70db0                                 fn_2b70db0
02d70688: adrp    x0, #0x6266000                             
02d7068c: ldr     x0, [x0, #0xc90]                           MS:DG.Tweening.TweenSettingsExtensions::OnComplete
02d70690: bl      #0x2b70db0                                 fn_2b70db0
02d70694: adrp    x0, #0x6267000                             
02d70698: ldr     x0, [x0, #0x978]                           MS:DG.Tweening.TweenSettingsExtensions::SetEase
02d7069c: bl      #0x2b70db0                                 fn_2b70db0
02d706a0: mov     w8, #1                                     
02d706a4: strb    w8, [x22, #0x3a0]                          
02d706a8: ldr     x0, [x20, #0x38]                           ._tfPanel
02d706ac: mov     w8, #1                                     
02d706b0: strb    w8, [x20, #0x58]                           ._isShowing
02d706b4: cbz     x0, #0x2d707d0                             
02d706b8: mov     x1, xzr                                    
02d706bc: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02d706c0: cbz     x21, #0x2d707d0                            
02d706c4: mov     x22, x0                                    
02d706c8: mov     x0, x21                                    
02d706cc: mov     x1, xzr                                    
02d706d0: bl      #0x5b467ac                                 UnityEngine.Transform::get_position
02d706d4: cbz     x22, #0x2d707d0                            
02d706d8: mov     x0, x22                                    
02d706dc: mov     x1, xzr                                    
02d706e0: bl      #0x5b46888                                 UnityEngine.Transform::set_position
02d706e4: ldr     x0, [x20, #0x40]                           ._tfSubPanel
02d706e8: cbz     x0, #0x2d707d0                             
02d706ec: mov     x1, xzr                                    
02d706f0: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02d706f4: mov     x22, x0                                    
02d706f8: mov     x0, x20                                    
02d706fc: mov     x1, xzr                                    
02d70700: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02d70704: cbz     x0, #0x2d707d0                             
02d70708: adrp    x24, #0x6267000                            
02d7070c: adrp    x25, #0x6264000                            
02d70710: adrp    x26, #0x626c000                            
02d70714: adrp    x23, #0x6266000                            
02d70718: ldr     x24, [x24, #0x978]                         MS:DG.Tweening.TweenSettingsExtensions::SetEase
02d7071c: ldr     x25, [x25, #0xe8]                          T:DG.Tweening.TweenCallback
02d70720: ldr     x26, [x26, #0x570]                         M:Clicker.PopupSelectColor::<ShowAt>b__11_0
02d70724: ldr     x23, [x23, #0xc90]                         MS:DG.Tweening.TweenSettingsExtensions::OnComplete
02d70728: mov     x1, xzr                                    
02d7072c: bl      #0x5b467ac                                 UnityEngine.Transform::get_position
02d70730: movi    d1, #0000000000000000                      
02d70734: mov     x0, x22                                    
02d70738: mov     w1, wzr                                    
02d7073c: mov     x2, xzr                                    
02d70740: bl      #0x2d977b8                                 DG.Tweening.ShortcutExtensions::DOMoveX
02d70744: mov     x0, x20                                    
02d70748: mov     x1, x21                                    
02d7074c: str     x21, [x0, #0x60]!                          ._tfParent
02d70750: bl      #0x2b70d54                                 fn_2b70d54
02d70754: adrp    x8, #0x1084000                             
02d70758: fmov    s0, #1.00000000                            
02d7075c: ldr     x0, [x20, #0x30]                           ._canvasGroup
02d70760: ldr     s1, [x8, #0xf10]                           [1084f10]=4110bc863e99999a f=0.3,9.04603
02d70764: mov     x1, xzr                                    
02d70768: bl      #0x2c78338                                 DG.Tweening.DOTweenModuleUI::DOFade
02d7076c: ldr     x2, [x24]                                  S:'didu'
02d70770: mov     w1, #3                                     
02d70774: bl      #0x336fa0c                                 fn_336fa0c
02d70778: ldr     x8, [x25]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d7077c: mov     x21, x0                                    
02d70780: mov     x0, x8                                     
02d70784: bl      #0x2b7104c                                 fn_2b7104c
02d70788: ldr     x2, [x26]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d7078c: mov     x1, x20                                    
02d70790: mov     x3, xzr                                    
02d70794: mov     x22, x0                                    
02d70798: bl      #0x2d89dc4                                 DG.Tweening.TweenCallback::.ctor
02d7079c: ldr     x2, [x23]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d707a0: mov     x0, x21                                    
02d707a4: mov     x1, x22                                    
02d707a8: bl      #0x336f26c                                 fn_336f26c
02d707ac: mov     x0, x20                                    
02d707b0: mov     w1, w19                                    
02d707b4: str     w19, [x20, #0x48]                          ._selectedIndex
02d707b8: ldp     x20, x19, [sp, #0x40]                      
02d707bc: ldp     x22, x21, [sp, #0x30]                      
02d707c0: ldp     x24, x23, [sp, #0x20]                      
02d707c4: ldp     x26, x25, [sp, #0x10]                      
02d707c8: ldr     x30, [sp], #0x50                           
02d707cc: b       #0x2d707d4                                 Clicker.PopupSelectColor::OnButtonClick
02d707d0: bl      #0x2b7105c                                 fn_2b7105c
## Hide() -> void
---- Clicker.PopupSelectColor::Hide 0x2d708cc
02d708cc: str     x30, [sp, #-0x20]!                         
02d708d0: stp     x20, x19, [sp, #0x10]                      
02d708d4: adrp    x20, #0x6630000                            
02d708d8: mov     x19, x0                                    
02d708dc: ldrb    w8, [x20, #0x3a1]                          
02d708e0: tbnz    w8, #0, #0x2d708f8                         
02d708e4: adrp    x0, #0x6267000                             
02d708e8: ldr     x0, [x0, #0x978]                           MS:DG.Tweening.TweenSettingsExtensions::SetEase
02d708ec: bl      #0x2b70db0                                 fn_2b70db0
02d708f0: mov     w8, #1                                     
02d708f4: strb    w8, [x20, #0x3a1]                          
02d708f8: mov     x20, x19                                   
02d708fc: mov     x1, xzr                                    
02d70900: str     xzr, [x20, #0x60]!                         ._tfParent
02d70904: mov     x0, x20                                    
02d70908: sturb   wzr, [x20, #-8]                            
02d7090c: bl      #0x2b70d54                                 fn_2b70d54
02d70910: ldur    x0, [x20, #-0x30]                          
02d70914: mov     w1, wzr                                    
02d70918: mov     x2, xzr                                    
02d7091c: bl      #0x2d9d5d0                                 DG.Tweening.ShortcutExtensions::DOKill
02d70920: ldur    x0, [x20, #-0x30]                          
02d70924: cbz     x0, #0x2d7097c                             
02d70928: mov     w1, wzr                                    
02d7092c: mov     x2, xzr                                    
02d70930: bl      #0x5e45290                                 UnityEngine.CanvasGroup::set_interactable
02d70934: ldr     x0, [x19, #0x30]                           ._canvasGroup
02d70938: cbz     x0, #0x2d7097c                             
02d7093c: adrp    x20, #0x6267000                            
02d70940: mov     w1, wzr                                    
02d70944: mov     x2, xzr                                    
02d70948: ldr     x20, [x20, #0x978]                         MS:DG.Tweening.TweenSettingsExtensions::SetEase
02d7094c: bl      #0x5e45408                                 UnityEngine.CanvasGroup::set_blocksRaycasts
02d70950: movi    d0, #0000000000000000                      
02d70954: adrp    x8, #0x1084000                             
02d70958: ldr     x0, [x19, #0x30]                           ._canvasGroup
02d7095c: ldr     s1, [x8, #0xf10]                           [1084f10]=4110bc863e99999a f=0.3,9.04603
02d70960: mov     x1, xzr                                    
02d70964: bl      #0x2c78338                                 DG.Tweening.DOTweenModuleUI::DOFade
02d70968: ldr     x2, [x20]                                  S:'didu'
02d7096c: ldp     x20, x19, [sp, #0x10]                      
02d70970: mov     w1, #2                                     
02d70974: ldr     x30, [sp], #0x20                           
02d70978: b       #0x336fa0c                                 
02d7097c: bl      #0x2b7105c                                 fn_2b7105c
## OnButtonClick(int index) -> void
---- Clicker.PopupSelectColor::OnButtonClick 0x2d707d4
02d707d4: str     x30, [sp, #-0x30]!                         
02d707d8: stp     x22, x21, [sp, #0x10]                      
02d707dc: stp     x20, x19, [sp, #0x20]                      
02d707e0: adrp    x22, #0x6630000                            
02d707e4: adrp    x21, #0x626b000                            
02d707e8: mov     w20, w1                                    
02d707ec: ldrb    w8, [x22, #0x3a2]                          
02d707f0: ldr     x21, [x21, #0xee0]                         MS:MonoSingleton`1::get_Instance
02d707f4: mov     x19, x0                                    
02d707f8: tbnz    w8, #0, #0x2d70810                         
02d707fc: adrp    x0, #0x626b000                             
02d70800: ldr     x0, [x0, #0xee0]                           MS:MonoSingleton`1::get_Instance
02d70804: bl      #0x2b70db0                                 fn_2b70db0
02d70808: mov     w8, #1                                     
02d7080c: strb    w8, [x22, #0x3a2]                          
02d70810: bl      #0x2d6ff04                                 Framework.AudioHelper::PlayClickSound
02d70814: ldr     x0, [x21]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d70818: bl      #0x3769600                                 fn_3769600
02d7081c: cbz     x0, #0x2d708c4                             
02d70820: mov     w1, w20                                    
02d70824: mov     x2, xzr                                    
02d70828: bl      #0x2d6cdfc                                 Clicker.KeycapMakerController::SetKeycapColor
02d7082c: ldr     x8, [x19, #0x20]                           ._colorButton
02d70830: cbz     x8, #0x2d708c4                             
02d70834: ldr     w9, [x8, #0x18]                            
02d70838: cmp     w9, w20                                    
02d7083c: b.ls    #0x2d708c8                                 
02d70840: add     x8, x8, w20, sxtw #3                       
02d70844: ldr     x0, [x8, #0x20]                            
02d70848: cbz     x0, #0x2d708c4                             
02d7084c: ldr     x20, [x19, #0x28]                          ._selected
02d70850: mov     x1, xzr                                    
02d70854: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02d70858: cbz     x20, #0x2d708c4                            
02d7085c: mov     x1, x0                                     
02d70860: mov     x0, x20                                    
02d70864: mov     x2, xzr                                    
02d70868: bl      #0x5b472ec                                 UnityEngine.Transform::SetParent
02d7086c: adrp    x20, #0x662f000                            
02d70870: ldr     x19, [x19, #0x28]                          ._selected
02d70874: ldrb    w8, [x20, #0x91a]                          
02d70878: cbnz    w8, #0x2d70890                             
02d7087c: adrp    x0, #0x6264000                             
02d70880: ldr     x0, [x0, #0xd8]                            T:UnityEngine.Vector3
02d70884: bl      #0x2b70db0                                 fn_2b70db0
02d70888: mov     w8, #1                                     
02d7088c: strb    w8, [x20, #0x91a]                          
02d70890: cbz     x19, #0x2d708c4                            
02d70894: adrp    x8, #0x6264000                             
02d70898: mov     x0, x19                                    
02d7089c: mov     x1, xzr                                    
02d708a0: ldr     x8, [x8, #0xd8]                            T:UnityEngine.Vector3
02d708a4: ldp     x20, x19, [sp, #0x20]                      
02d708a8: ldp     x22, x21, [sp, #0x10]                      
02d708ac: ldr     x8, [x8]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d708b0: ldr     x8, [x8, #0xb8]                            MS:DG.Tweening.Core.Extensions::SetSpecialStartupMode
02d708b4: ldp     s0, s1, [x8]                               
02d708b8: ldr     s2, [x8, #8]                               T:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass2_0
02d708bc: ldr     x30, [sp], #0x30                           
02d708c0: b       #0x5b45cec                                 UnityEngine.Transform::set_localPosition
02d708c4: bl      #0x2b7105c                                 fn_2b7105c
02d708c8: bl      #0x2b71064                                 fn_2b71064
## .ctor() -> void
---- Clicker.PopupSelectColor::.ctor 0x2d70980
02d70980: mov     x1, xzr                                    
02d70984: b       #0x5b397b0                                 UnityEngine.MonoBehaviour::.ctor
## <ShowAt>b__11_0() -> void
---- Clicker.PopupSelectColor::<ShowAt>b__11_0 0x2d70988
02d70988: stp     x30, x19, [sp, #-0x10]!                    
02d7098c: mov     x19, x0                                    
02d70990: ldr     x0, [x0, #0x30]                            ._canvasGroup
02d70994: cbz     x0, #0x2d709bc                             
02d70998: mov     w1, #1                                     
02d7099c: mov     x2, xzr                                    
02d709a0: bl      #0x5e45290                                 UnityEngine.CanvasGroup::set_interactable
02d709a4: ldr     x0, [x19, #0x30]                           ._canvasGroup
02d709a8: cbz     x0, #0x2d709bc                             
02d709ac: mov     w1, #1                                     
02d709b0: mov     x2, xzr                                    
02d709b4: ldp     x30, x19, [sp], #0x10                      
02d709b8: b       #0x5e45408                                 UnityEngine.CanvasGroup::set_blocksRaycasts
02d709bc: bl      #0x2b7105c                                 fn_2b7105c
