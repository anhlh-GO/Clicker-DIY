#### CLASS Framework.StandardShaderUtils/BlendMode parent= int
#   field value__                        int                                                off=0x10 attr=606 
#   field Opaque                         Framework.StandardShaderUtils/BlendMode            off=0x0 attr=8056 
#   field Cutout                         Framework.StandardShaderUtils/BlendMode            off=0x0 attr=8056 
#   field Fade                           Framework.StandardShaderUtils/BlendMode            off=0x0 attr=8056 
#   field Transparent                    Framework.StandardShaderUtils/BlendMode            off=0x0 attr=8056 
#### CLASS Framework.StandardShaderUtils parent= object
## ChangeRenderMode(UnityEngine.Material standardShaderMaterial, Framework.StandardShaderUtils/BlendMode blendMode, int overrideZWrite) -> void
---- Framework.StandardShaderUtils::ChangeRenderMode 0x2cc24d4
02cc24d4: str     x30, [sp, #-0x30]!                         
02cc24d8: stp     x22, x21, [sp, #0x10]                      
02cc24dc: stp     x20, x19, [sp, #0x20]                      
02cc24e0: adrp    x22, #0x662f000                            
02cc24e4: mov     w20, w2                                    
02cc24e8: mov     w21, w1                                    
02cc24ec: ldrb    w8, [x22, #0xc2a]                          
02cc24f0: mov     x19, x0                                    
02cc24f4: tbnz    w8, #0, #0x2cc2554                         
02cc24f8: adrp    x0, #0x6267000                             
02cc24fc: ldr     x0, [x0, #0x118]                           S:'_SrcBlend'
02cc2500: bl      #0x2b70db0                                 fn_2b70db0
02cc2504: adrp    x0, #0x6267000                             
02cc2508: ldr     x0, [x0, #0x120]                           S:'_ALPHABLEND_ON'
02cc250c: bl      #0x2b70db0                                 fn_2b70db0
02cc2510: adrp    x0, #0x6267000                             
02cc2514: ldr     x0, [x0, #0x128]                           S:'_ALPHAPREMULTIPLY_ON'
02cc2518: bl      #0x2b70db0                                 fn_2b70db0
02cc251c: adrp    x0, #0x6267000                             
02cc2520: ldr     x0, [x0, #0x130]                           S:'_DstBlend'
02cc2524: bl      #0x2b70db0                                 fn_2b70db0
02cc2528: adrp    x0, #0x6267000                             
02cc252c: ldr     x0, [x0, #0x138]                           S:'_Mode'
02cc2530: bl      #0x2b70db0                                 fn_2b70db0
02cc2534: adrp    x0, #0x6267000                             
02cc2538: ldr     x0, [x0, #0x140]                           S:'_ZWrite'
02cc253c: bl      #0x2b70db0                                 fn_2b70db0
02cc2540: adrp    x0, #0x6267000                             
02cc2544: ldr     x0, [x0, #0x148]                           S:'_ALPHATEST_ON'
02cc2548: bl      #0x2b70db0                                 fn_2b70db0
02cc254c: mov     w8, #1                                     
02cc2550: strb    w8, [x22, #0xc2a]                          
02cc2554: cmp     w21, #1                                    
02cc2558: b.gt    #0x2cc2630                                 
02cc255c: cbz     w21, #0x2cc2714                            
02cc2560: cmp     w21, #1                                    
02cc2564: b.ne    #0x2cc2704                                 
02cc2568: cbz     x19, #0x2cc28b8                            
02cc256c: adrp    x8, #0x6267000                             
02cc2570: fmov    s0, #1.00000000                            
02cc2574: mov     x0, x19                                    
02cc2578: ldr     x8, [x8, #0x138]                           S:'_Mode'
02cc257c: mov     x2, xzr                                    
02cc2580: ldr     x1, [x8]                                   S:'didu'
02cc2584: bl      #0x5b0911c                                 UnityEngine.Material::SetFloat
02cc2588: adrp    x8, #0x6267000                             
02cc258c: mov     x0, x19                                    
02cc2590: mov     w2, #1                                     
02cc2594: ldr     x8, [x8, #0x118]                           S:'_SrcBlend'
02cc2598: mov     x3, xzr                                    
02cc259c: ldr     x1, [x8]                                   S:'didu'
02cc25a0: bl      #0x5b090e4                                 UnityEngine.Material::SetInt
02cc25a4: adrp    x8, #0x6267000                             
02cc25a8: mov     x0, x19                                    
02cc25ac: mov     w2, wzr                                    
02cc25b0: ldr     x8, [x8, #0x130]                           S:'_DstBlend'
02cc25b4: mov     x3, xzr                                    
02cc25b8: ldr     x1, [x8]                                   S:'didu'
02cc25bc: bl      #0x5b090e4                                 UnityEngine.Material::SetInt
02cc25c0: adrp    x8, #0x6267000                             
02cc25c4: cmn     w20, #1                                    
02cc25c8: mov     x0, x19                                    
02cc25cc: ldr     x8, [x8, #0x140]                           S:'_ZWrite'
02cc25d0: csinc   w2, w20, wzr, ne                           
02cc25d4: mov     x3, xzr                                    
02cc25d8: ldr     x1, [x8]                                   S:'didu'
02cc25dc: bl      #0x5b090e4                                 UnityEngine.Material::SetInt
02cc25e0: adrp    x8, #0x6267000                             
02cc25e4: mov     x0, x19                                    
02cc25e8: mov     x2, xzr                                    
02cc25ec: ldr     x8, [x8, #0x148]                           S:'_ALPHATEST_ON'
02cc25f0: ldr     x1, [x8]                                   S:'didu'
02cc25f4: bl      #0x5b06940                                 UnityEngine.Material::EnableKeyword
02cc25f8: adrp    x8, #0x6267000                             
02cc25fc: mov     x0, x19                                    
02cc2600: mov     x2, xzr                                    
02cc2604: ldr     x8, [x8, #0x120]                           S:'_ALPHABLEND_ON'
02cc2608: ldr     x1, [x8]                                   S:'didu'
02cc260c: bl      #0x5b06b44                                 UnityEngine.Material::DisableKeyword
02cc2610: adrp    x8, #0x6267000                             
02cc2614: mov     x0, x19                                    
02cc2618: mov     x2, xzr                                    
02cc261c: ldr     x8, [x8, #0x128]                           S:'_ALPHAPREMULTIPLY_ON'
02cc2620: ldr     x1, [x8]                                   S:'didu'
02cc2624: bl      #0x5b06b44                                 UnityEngine.Material::DisableKeyword
02cc2628: mov     w1, #0x992                                 
02cc262c: b       #0x2cc28a0                                 
02cc2630: cmp     w21, #2                                    
02cc2634: b.eq    #0x2cc27dc                                 
02cc2638: cmp     w21, #3                                    
02cc263c: b.ne    #0x2cc2704                                 
02cc2640: cbz     x19, #0x2cc28b8                            
02cc2644: adrp    x8, #0x6267000                             
02cc2648: fmov    s0, #3.00000000                            
02cc264c: mov     x0, x19                                    
02cc2650: ldr     x8, [x8, #0x138]                           S:'_Mode'
02cc2654: mov     x2, xzr                                    
02cc2658: ldr     x1, [x8]                                   S:'didu'
02cc265c: bl      #0x5b0911c                                 UnityEngine.Material::SetFloat
02cc2660: adrp    x8, #0x6267000                             
02cc2664: mov     x0, x19                                    
02cc2668: mov     w2, #1                                     
02cc266c: ldr     x8, [x8, #0x118]                           S:'_SrcBlend'
02cc2670: mov     x3, xzr                                    
02cc2674: ldr     x1, [x8]                                   S:'didu'
02cc2678: bl      #0x5b090e4                                 UnityEngine.Material::SetInt
02cc267c: adrp    x8, #0x6267000                             
02cc2680: mov     x0, x19                                    
02cc2684: mov     w2, #0xa                                   
02cc2688: ldr     x8, [x8, #0x130]                           S:'_DstBlend'
02cc268c: mov     x3, xzr                                    
02cc2690: ldr     x1, [x8]                                   S:'didu'
02cc2694: bl      #0x5b090e4                                 UnityEngine.Material::SetInt
02cc2698: adrp    x8, #0x6267000                             
02cc269c: cmn     w20, #1                                    
02cc26a0: mov     x0, x19                                    
02cc26a4: ldr     x8, [x8, #0x140]                           S:'_ZWrite'
02cc26a8: csinc   w2, w20, wzr, ne                           
02cc26ac: mov     x3, xzr                                    
02cc26b0: ldr     x1, [x8]                                   S:'didu'
02cc26b4: bl      #0x5b090e4                                 UnityEngine.Material::SetInt
02cc26b8: adrp    x8, #0x6267000                             
02cc26bc: mov     x0, x19                                    
02cc26c0: mov     x2, xzr                                    
02cc26c4: ldr     x8, [x8, #0x148]                           S:'_ALPHATEST_ON'
02cc26c8: ldr     x1, [x8]                                   S:'didu'
02cc26cc: bl      #0x5b06b44                                 UnityEngine.Material::DisableKeyword
02cc26d0: adrp    x8, #0x6267000                             
02cc26d4: mov     x0, x19                                    
02cc26d8: mov     x2, xzr                                    
02cc26dc: ldr     x8, [x8, #0x120]                           S:'_ALPHABLEND_ON'
02cc26e0: ldr     x1, [x8]                                   S:'didu'
02cc26e4: bl      #0x5b06b44                                 UnityEngine.Material::DisableKeyword
02cc26e8: adrp    x8, #0x6267000                             
02cc26ec: mov     x0, x19                                    
02cc26f0: mov     x2, xzr                                    
02cc26f4: ldr     x8, [x8, #0x128]                           S:'_ALPHAPREMULTIPLY_ON'
02cc26f8: ldr     x1, [x8]                                   S:'didu'
02cc26fc: bl      #0x5b06940                                 UnityEngine.Material::EnableKeyword
02cc2700: b       #0x2cc289c                                 
02cc2704: ldp     x20, x19, [sp, #0x20]                      
02cc2708: ldp     x22, x21, [sp, #0x10]                      
02cc270c: ldr     x30, [sp], #0x30                           
02cc2710: ret                                                
02cc2714: cbz     x19, #0x2cc28b8                            
02cc2718: adrp    x8, #0x6267000                             
02cc271c: movi    d0, #0000000000000000                      
02cc2720: mov     x0, x19                                    
02cc2724: ldr     x8, [x8, #0x138]                           S:'_Mode'
02cc2728: mov     x2, xzr                                    
02cc272c: ldr     x1, [x8]                                   S:'didu'
02cc2730: bl      #0x5b0911c                                 UnityEngine.Material::SetFloat
02cc2734: adrp    x8, #0x6267000                             
02cc2738: mov     x0, x19                                    
02cc273c: mov     w2, #1                                     
02cc2740: ldr     x8, [x8, #0x118]                           S:'_SrcBlend'
02cc2744: mov     x3, xzr                                    
02cc2748: ldr     x1, [x8]                                   S:'didu'
02cc274c: bl      #0x5b090e4                                 UnityEngine.Material::SetInt
02cc2750: adrp    x8, #0x6267000                             
02cc2754: mov     x0, x19                                    
02cc2758: mov     w2, wzr                                    
02cc275c: ldr     x8, [x8, #0x130]                           S:'_DstBlend'
02cc2760: mov     x3, xzr                                    
02cc2764: ldr     x1, [x8]                                   S:'didu'
02cc2768: bl      #0x5b090e4                                 UnityEngine.Material::SetInt
02cc276c: adrp    x8, #0x6267000                             
02cc2770: cmn     w20, #1                                    
02cc2774: mov     x0, x19                                    
02cc2778: ldr     x8, [x8, #0x140]                           S:'_ZWrite'
02cc277c: csinc   w2, w20, wzr, ne                           
02cc2780: mov     x3, xzr                                    
02cc2784: ldr     x1, [x8]                                   S:'didu'
02cc2788: bl      #0x5b090e4                                 UnityEngine.Material::SetInt
02cc278c: adrp    x8, #0x6267000                             
02cc2790: mov     x0, x19                                    
02cc2794: mov     x2, xzr                                    
02cc2798: ldr     x8, [x8, #0x148]                           S:'_ALPHATEST_ON'
02cc279c: ldr     x1, [x8]                                   S:'didu'
02cc27a0: bl      #0x5b06b44                                 UnityEngine.Material::DisableKeyword
02cc27a4: adrp    x8, #0x6267000                             
02cc27a8: mov     x0, x19                                    
02cc27ac: mov     x2, xzr                                    
02cc27b0: ldr     x8, [x8, #0x120]                           S:'_ALPHABLEND_ON'
02cc27b4: ldr     x1, [x8]                                   S:'didu'
02cc27b8: bl      #0x5b06b44                                 UnityEngine.Material::DisableKeyword
02cc27bc: adrp    x8, #0x6267000                             
02cc27c0: mov     x0, x19                                    
02cc27c4: mov     x2, xzr                                    
02cc27c8: ldr     x8, [x8, #0x128]                           S:'_ALPHAPREMULTIPLY_ON'
02cc27cc: ldr     x1, [x8]                                   S:'didu'
02cc27d0: bl      #0x5b06b44                                 UnityEngine.Material::DisableKeyword
02cc27d4: mov     w1, #-1                                    
02cc27d8: b       #0x2cc28a0                                 
02cc27dc: cbz     x19, #0x2cc28b8                            
02cc27e0: adrp    x8, #0x6267000                             
02cc27e4: fmov    s0, #2.00000000                            
02cc27e8: mov     x0, x19                                    
02cc27ec: ldr     x8, [x8, #0x138]                           S:'_Mode'
02cc27f0: mov     x2, xzr                                    
02cc27f4: ldr     x1, [x8]                                   S:'didu'
02cc27f8: bl      #0x5b0911c                                 UnityEngine.Material::SetFloat
02cc27fc: adrp    x8, #0x6267000                             
02cc2800: mov     x0, x19                                    
02cc2804: mov     w2, #5                                     
02cc2808: ldr     x8, [x8, #0x118]                           S:'_SrcBlend'
02cc280c: mov     x3, xzr                                    
02cc2810: ldr     x1, [x8]                                   S:'didu'
02cc2814: bl      #0x5b090e4                                 UnityEngine.Material::SetInt
02cc2818: adrp    x8, #0x6267000                             
02cc281c: mov     x0, x19                                    
02cc2820: mov     w2, #0xa                                   
02cc2824: ldr     x8, [x8, #0x130]                           S:'_DstBlend'
02cc2828: mov     x3, xzr                                    
02cc282c: ldr     x1, [x8]                                   S:'didu'
02cc2830: bl      #0x5b090e4                                 UnityEngine.Material::SetInt
02cc2834: adrp    x8, #0x6267000                             
02cc2838: cmn     w20, #1                                    
02cc283c: mov     x0, x19                                    
02cc2840: ldr     x8, [x8, #0x140]                           S:'_ZWrite'
02cc2844: csel    w2, wzr, w20, eq                           
02cc2848: mov     x3, xzr                                    
02cc284c: ldr     x1, [x8]                                   S:'didu'
02cc2850: bl      #0x5b090e4                                 UnityEngine.Material::SetInt
02cc2854: adrp    x8, #0x6267000                             
02cc2858: mov     x0, x19                                    
02cc285c: mov     x2, xzr                                    
02cc2860: ldr     x8, [x8, #0x148]                           S:'_ALPHATEST_ON'
02cc2864: ldr     x1, [x8]                                   S:'didu'
02cc2868: bl      #0x5b06b44                                 UnityEngine.Material::DisableKeyword
02cc286c: adrp    x8, #0x6267000                             
02cc2870: mov     x0, x19                                    
02cc2874: mov     x2, xzr                                    
02cc2878: ldr     x8, [x8, #0x120]                           S:'_ALPHABLEND_ON'
02cc287c: ldr     x1, [x8]                                   S:'didu'
02cc2880: bl      #0x5b06940                                 UnityEngine.Material::EnableKeyword
02cc2884: adrp    x8, #0x6267000                             
02cc2888: mov     x0, x19                                    
02cc288c: mov     x2, xzr                                    
02cc2890: ldr     x8, [x8, #0x128]                           S:'_ALPHAPREMULTIPLY_ON'
02cc2894: ldr     x1, [x8]                                   S:'didu'
02cc2898: bl      #0x5b06b44                                 UnityEngine.Material::DisableKeyword
02cc289c: mov     w1, #0xbb8                                 
02cc28a0: mov     x0, x19                                    
02cc28a4: ldp     x20, x19, [sp, #0x20]                      
02cc28a8: ldp     x22, x21, [sp, #0x10]                      
02cc28ac: mov     x2, xzr                                    
02cc28b0: ldr     x30, [sp], #0x30                           
02cc28b4: b       #0x5b06850                                 UnityEngine.Material::set_renderQueue
02cc28b8: bl      #0x2b7105c                                 fn_2b7105c
