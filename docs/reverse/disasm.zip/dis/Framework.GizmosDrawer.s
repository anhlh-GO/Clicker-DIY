#### CLASS Framework.GizmosDrawer parent= object
## DrawArrow(UnityEngine.Vector3 origin, UnityEngine.Vector3 direction, float arrowLength, float arrowHeadLength, UnityEngine.Color color) -> void
---- Framework.GizmosDrawer::DrawArrow 0x2cbf5b4
02cbf5b4: sub     sp, sp, #0x60                              
02cbf5b8: stp     d15, d14, [sp, #0x10]                      
02cbf5bc: stp     d13, d12, [sp, #0x20]                      
02cbf5c0: stp     d11, d10, [sp, #0x30]                      
02cbf5c4: stp     d9, d8, [sp, #0x40]                        
02cbf5c8: stp     x30, x19, [sp, #0x50]                      
02cbf5cc: fmov    s10, s6                                    
02cbf5d0: fmov    s12, s5                                    
02cbf5d4: stp     s1, s2, [sp, #8]                           
02cbf5d8: fmov    s13, s4                                    
02cbf5dc: fmov    s14, s3                                    
02cbf5e0: adrp    x19, #0x662f000                            
02cbf5e4: ldp     s1, s8, [sp, #0x60]                        
02cbf5e8: ldrb    w8, [x19, #0xc0c]                          
02cbf5ec: ldp     s9, s11, [sp, #0x68]                       
02cbf5f0: stp     s0, s1, [sp]                               
02cbf5f4: tbnz    w8, #0, #0x2cbf60c                         
02cbf5f8: adrp    x0, #0x6263000                             
02cbf5fc: ldr     x0, [x0, #0x928]                           T:UnityEngine.Debug
02cbf600: bl      #0x2b70db0                                 fn_2b70db0
02cbf604: mov     w8, #1                                     
02cbf608: strb    w8, [x19, #0xc0c]                          
02cbf60c: adrp    x19, #0x662f000                            
02cbf610: ldrb    w8, [x19, #0x91a]                          
02cbf614: cbnz    w8, #0x2cbf62c                             
02cbf618: adrp    x0, #0x6264000                             
02cbf61c: ldr     x0, [x0, #0xd8]                            T:UnityEngine.Vector3
02cbf620: bl      #0x2b70db0                                 fn_2b70db0
02cbf624: mov     w8, #1                                     
02cbf628: strb    w8, [x19, #0x91a]                          
02cbf62c: adrp    x8, #0x6264000                             
02cbf630: ldr     x8, [x8, #0xd8]                            T:UnityEngine.Vector3
02cbf634: ldr     x8, [x8]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02cbf638: ldr     x8, [x8, #0xb8]                            MS:DG.Tweening.Core.Extensions::SetSpecialStartupMode
02cbf63c: ldp     s0, s1, [x8]                               
02cbf640: ldr     s2, [x8, #8]                               T:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass2_0
02cbf644: adrp    x8, #0x1084000                             
02cbf648: fsub    s2, s12, s2                                
02cbf64c: ldr     s15, [x8, #0xbd0]                          [1084bd0]=3f6666662edbe6fe f=1e-10,0.9
02cbf650: fsub    s0, s14, s0                                
02cbf654: fsub    s1, s13, s1                                
02cbf658: fmul    s0, s0, s0                                 
02cbf65c: fmul    s1, s1, s1                                 
02cbf660: fadd    s0, s0, s1                                 
02cbf664: fmul    s1, s2, s2                                 
02cbf668: fadd    s0, s1, s0                                 
02cbf66c: fcmp    s0, s15                                    
02cbf670: b.pl    #0x2cbf690                                 
02cbf674: ldp     x30, x19, [sp, #0x50]                      
02cbf678: ldp     d9, d8, [sp, #0x40]                        
02cbf67c: ldp     d11, d10, [sp, #0x30]                      
02cbf680: ldp     d13, d12, [sp, #0x20]                      
02cbf684: ldp     d15, d14, [sp, #0x10]                      
02cbf688: add     sp, sp, #0x60                              
02cbf68c: ret                                                
02cbf690: adrp    x19, #0x662f000                            
02cbf694: ldrb    w8, [x19, #0xca7]                          
02cbf698: cbnz    w8, #0x2cbf6b0                             
02cbf69c: adrp    x0, #0x6265000                             
02cbf6a0: ldr     x0, [x0, #0xb48]                           T:System.Math
02cbf6a4: bl      #0x2b70db0                                 fn_2b70db0
02cbf6a8: mov     w8, #1                                     
02cbf6ac: strb    w8, [x19, #0xca7]                          
02cbf6b0: adrp    x8, #0x6265000                             
02cbf6b4: ldr     x8, [x8, #0xb48]                           T:System.Math
02cbf6b8: ldr     x0, [x8]                                   M:AdsManager::<OnApplicationPause>b__26_0
02cbf6bc: ldr     w8, [x0, #0xe4]                            [62650e4]=0 f=0,0
02cbf6c0: cbnz    w8, #0x2cbf6c8                             
02cbf6c4: bl      #0x2b70f30                                 fn_2b70f30
02cbf6c8: fmul    s0, s14, s14                               
02cbf6cc: fmul    s1, s13, s13                               
02cbf6d0: adrp    x8, #0x1084000                             
02cbf6d4: movi    d2, #0000000000000000                      
02cbf6d8: fadd    s0, s0, s1                                 
02cbf6dc: fmul    s1, s12, s12                               
02cbf6e0: fadd    s0, s1, s0                                 
02cbf6e4: ldr     s1, [x8, #0xfe0]                           [1084fe0]=3d5df3603727c5ac f=1e-05,0.0541872
02cbf6e8: fsqrt   s3, s0                                     
02cbf6ec: movi    d0, #0000000000000000                      
02cbf6f0: fcmp    s3, s1                                     
02cbf6f4: movi    d1, #0000000000000000                      
02cbf6f8: b.le    #0x2cbf708                                 
02cbf6fc: fdiv    s0, s14, s3                                
02cbf700: fdiv    s1, s13, s3                                
02cbf704: fdiv    s2, s12, s3                                
02cbf708: ldr     s14, [sp, #4]                              
02cbf70c: fmul    s4, s8, s8                                 
02cbf710: adrp    x8, #0x6263000                             
02cbf714: ldr     x8, [x8, #0x928]                           T:UnityEngine.Debug
02cbf718: fmul    s3, s14, s14                               
02cbf71c: fadd    s3, s3, s4                                 
02cbf720: fmul    s4, s9, s9                                 
02cbf724: fadd    s3, s4, s3                                 
02cbf728: fmul    s4, s11, s11                               
02cbf72c: fadd    s3, s4, s3                                 
02cbf730: fcmp    s3, s15                                    
02cbf734: b.pl    #0x2cbf748                                 
02cbf738: fmov    s14, #1.00000000                           
02cbf73c: fmov    s8, #1.00000000                            
02cbf740: fmov    s9, #1.00000000                            
02cbf744: fmov    s11, #1.00000000                           
02cbf748: fmul    s12, s0, s10                               
02cbf74c: ldr     x0, [x8]                                   &2c5bbd4(=a9bd7bfdd503233f)
02cbf750: fmul    s13, s1, s10                               
02cbf754: fmul    s10, s2, s10                               
02cbf758: ldr     w8, [x0, #0xe4]                            [62650e4]=0 f=0,0
02cbf75c: cbnz    w8, #0x2cbf764                             
02cbf760: bl      #0x2b70f30                                 fn_2b70f30
02cbf764: stp     s9, s11, [sp, #0x68]                       
02cbf768: ldp     s1, s2, [sp, #8]                           
02cbf76c: stp     s14, s8, [sp, #0x60]                       
02cbf770: fmov    s3, s12                                    
02cbf774: fmov    s4, s13                                    
02cbf778: fmov    s5, s10                                    
02cbf77c: ldp     x30, x19, [sp, #0x50]                      
02cbf780: ldp     d9, d8, [sp, #0x40]                        
02cbf784: mov     x0, xzr                                    
02cbf788: ldp     d11, d10, [sp, #0x30]                      
02cbf78c: ldr     s0, [sp]                                   
02cbf790: ldp     d13, d12, [sp, #0x20]                      
02cbf794: ldp     d15, d14, [sp, #0x10]                      
02cbf798: add     sp, sp, #0x60                              
02cbf79c: b       #0x5af1e20                                 UnityEngine.Debug::DrawRay
## DrawCross(UnityEngine.Vector3 spot, float crossSize, UnityEngine.Color color) -> void
---- Framework.GizmosDrawer::DrawCross 0x2cbf7a0
02cbf7a0: sub     sp, sp, #0x80                              
02cbf7a4: stp     d15, d14, [sp, #0x20]                      
02cbf7a8: stp     d13, d12, [sp, #0x30]                      
02cbf7ac: stp     d11, d10, [sp, #0x40]                      
02cbf7b0: stp     d9, d8, [sp, #0x50]                        
02cbf7b4: str     x30, [sp, #0x60]                           
02cbf7b8: stp     x20, x19, [sp, #0x70]                      
02cbf7bc: fmov    s13, s7                                    
02cbf7c0: fmov    s11, s6                                    
02cbf7c4: adrp    x19, #0x662f000                            
02cbf7c8: fmov    s12, s5                                    
02cbf7cc: fmov    s8, s4                                     
02cbf7d0: ldrb    w8, [x19, #0xc0d]                          
02cbf7d4: fmov    s9, s3                                     
02cbf7d8: str     s2, [sp, #0x6c]                            
02cbf7dc: stp     s0, s1, [sp, #0x18]                        
02cbf7e0: tbnz    w8, #0, #0x2cbf7f8                         
02cbf7e4: adrp    x0, #0x6263000                             
02cbf7e8: ldr     x0, [x0, #0x928]                           T:UnityEngine.Debug
02cbf7ec: bl      #0x2b70db0                                 fn_2b70db0
02cbf7f0: mov     w8, #1                                     
02cbf7f4: strb    w8, [x19, #0xc0d]                          
02cbf7f8: fmul    s0, s8, s8                                 
02cbf7fc: fmul    s1, s12, s12                               
02cbf800: adrp    x8, #0x1084000                             
02cbf804: fadd    s0, s0, s1                                 
02cbf808: fmul    s1, s11, s11                               
02cbf80c: fadd    s0, s1, s0                                 
02cbf810: fmul    s1, s13, s13                               
02cbf814: fadd    s0, s1, s0                                 
02cbf818: ldr     s1, [x8, #0xbd0]                           [1084bd0]=3f6666662edbe6fe f=1e-10,0.9
02cbf81c: fcmp    s0, s1                                     
02cbf820: b.pl    #0x2cbf834                                 
02cbf824: fmov    s8, #1.00000000                            
02cbf828: fmov    s12, #1.00000000                           
02cbf82c: fmov    s11, #1.00000000                           
02cbf830: fmov    s13, #1.00000000                           
02cbf834: str     s11, [sp, #0x68]                           
02cbf838: adrp    x20, #0x662f000                            
02cbf83c: adrp    x19, #0x6263000                            
02cbf840: ldrb    w8, [x20, #0x91a]                          
02cbf844: ldr     x19, [x19, #0x928]                         T:UnityEngine.Debug
02cbf848: cbnz    w8, #0x2cbf860                             
02cbf84c: adrp    x0, #0x6264000                             
02cbf850: ldr     x0, [x0, #0xd8]                            T:UnityEngine.Vector3
02cbf854: bl      #0x2b70db0                                 fn_2b70db0
02cbf858: mov     w8, #1                                     
02cbf85c: strb    w8, [x20, #0x91a]                          
02cbf860: fmov    s11, s8                                    
02cbf864: ldr     x0, [x19]                                  &2c5bbd4(=a9bd7bfdd503233f)
02cbf868: ldr     w8, [x0, #0xe4]                            [62640e4]=0 f=0,0
02cbf86c: cbnz    w8, #0x2cbf874                             
02cbf870: bl      #0x2b70f30                                 fn_2b70f30
02cbf874: fmov    s0, #0.50000000                            
02cbf878: movi    d1, #0000000000000000                      
02cbf87c: str     s13, [sp, #0xc]                            
02cbf880: fmov    s3, s9                                     
02cbf884: fmov    s4, s9                                     
02cbf888: mov     x0, xzr                                    
02cbf88c: str     s11, [sp]                                  
02cbf890: fmul    s14, s9, s0                                
02cbf894: ldp     s0, s15, [sp, #0x18]                       
02cbf898: fmul    s5, s9, s1                                 
02cbf89c: fsub    s10, s0, s14                               
02cbf8a0: fsub    s1, s15, s14                               
02cbf8a4: stp     s5, s13, [sp, #0x14]                       
02cbf8a8: ldp     s13, s8, [sp, #0x68]                       
02cbf8ac: fmov    s0, s10                                    
02cbf8b0: fmov    s2, s8                                     
02cbf8b4: stp     s12, s13, [sp, #4]                         
02cbf8b8: bl      #0x5af1e20                                 UnityEngine.Debug::DrawRay
02cbf8bc: ldp     s5, s0, [sp, #0x14]                        
02cbf8c0: fadd    s1, s15, s14                               
02cbf8c4: fneg    s4, s9                                     
02cbf8c8: fmov    s2, s8                                     
02cbf8cc: fmov    s3, s9                                     
02cbf8d0: mov     x0, xzr                                    
02cbf8d4: stp     s11, s12, [sp]                             
02cbf8d8: stp     s13, s0, [sp, #8]                          
02cbf8dc: fmov    s0, s10                                    
02cbf8e0: bl      #0x5af1e20                                 UnityEngine.Debug::DrawRay
02cbf8e4: ldp     x20, x19, [sp, #0x70]                      
02cbf8e8: ldr     x30, [sp, #0x60]                           
02cbf8ec: ldp     d9, d8, [sp, #0x50]                        
02cbf8f0: ldp     d11, d10, [sp, #0x40]                      
02cbf8f4: ldp     d13, d12, [sp, #0x30]                      
02cbf8f8: ldp     d15, d14, [sp, #0x20]                      
02cbf8fc: add     sp, sp, #0x80                              
02cbf900: ret                                                
## DrawArrowEnd(UnityEngine.Vector3 arrowEndPosition, UnityEngine.Vector3 direction, UnityEngine.Color color, float arrowHeadLength, float arrowHeadAngle) -> void
---- Framework.GizmosDrawer::DrawArrowEnd 0x2cbf904
02cbf904: sub     sp, sp, #0xe0                              
02cbf908: stp     d15, d14, [sp, #0x80]                      
02cbf90c: stp     d13, d12, [sp, #0x90]                      
02cbf910: stp     d11, d10, [sp, #0xa0]                      
02cbf914: stp     d9, d8, [sp, #0xb0]                        
02cbf918: stp     x30, x21, [sp, #0xc0]                      
02cbf91c: stp     x20, x19, [sp, #0xd0]                      
02cbf920: fmov    s8, s5                                     
02cbf924: fmov    s10, s4                                    
02cbf928: adrp    x19, #0x662f000                            
02cbf92c: fmov    s11, s3                                    
02cbf930: fmov    s9, s2                                     
02cbf934: ldrb    w8, [x19, #0xc0e]                          
02cbf938: fmov    s12, s1                                    
02cbf93c: fmov    s13, s0                                    
02cbf940: tbnz    w8, #0, #0x2cbf958                         
02cbf944: adrp    x0, #0x6263000                             
02cbf948: ldr     x0, [x0, #0x928]                           T:UnityEngine.Debug
02cbf94c: bl      #0x2b70db0                                 fn_2b70db0
02cbf950: mov     w8, #1                                     
02cbf954: strb    w8, [x19, #0xc0e]                          
02cbf958: adrp    x19, #0x662f000                            
02cbf95c: ldrb    w8, [x19, #0x91a]                          
02cbf960: cbnz    w8, #0x2cbf978                             
02cbf964: adrp    x0, #0x6264000                             
02cbf968: ldr     x0, [x0, #0xd8]                            T:UnityEngine.Vector3
02cbf96c: bl      #0x2b70db0                                 fn_2b70db0
02cbf970: mov     w8, #1                                     
02cbf974: strb    w8, [x19, #0x91a]                          
02cbf978: adrp    x19, #0x6264000                            
02cbf97c: adrp    x9, #0x1084000                             
02cbf980: ldr     x19, [x19, #0xd8]                          T:UnityEngine.Vector3
02cbf984: ldr     x8, [x19]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02cbf988: ldr     x8, [x8, #0xb8]                            
02cbf98c: ldp     s0, s1, [x8]                               
02cbf990: ldr     s2, [x8, #8]                               
02cbf994: fsub    s2, s8, s2                                 
02cbf998: fsub    s0, s11, s0                                
02cbf99c: fsub    s1, s10, s1                                
02cbf9a0: fmul    s0, s0, s0                                 
02cbf9a4: fmul    s1, s1, s1                                 
02cbf9a8: fadd    s0, s0, s1                                 
02cbf9ac: fmul    s1, s2, s2                                 
02cbf9b0: fadd    s0, s1, s0                                 
02cbf9b4: ldr     s1, [x9, #0xbd0]                           [1084bd0]=3f6666662edbe6fe f=1e-10,0.9
02cbf9b8: fcmp    s0, s1                                     
02cbf9bc: b.mi    #0x2cc0004                                 
02cbf9c0: adrp    x20, #0x662f000                            
02cbf9c4: ldr     s15, [sp, #0xf8]                           
02cbf9c8: stp     s13, s12, [sp, #0x4c]                      
02cbf9cc: ldrb    w9, [x20, #0x918]                          
02cbf9d0: str     s9, [sp, #0x58]                            
02cbf9d4: stp     s11, s10, [sp, #0x70]                      
02cbf9d8: str     s8, [sp, #0x78]                            
02cbf9dc: str     wzr, [sp, #0x68]                           
02cbf9e0: str     xzr, [sp, #0x60]                           
02cbf9e4: cbnz    w9, #0x2cbfa00                             
02cbf9e8: mov     x0, x19                                    
02cbf9ec: bl      #0x2b70db0                                 fn_2b70db0
02cbf9f0: ldr     x8, [x19]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02cbf9f4: mov     w9, #1                                     
02cbf9f8: strb    w9, [x20, #0x918]                          
02cbf9fc: ldr     x8, [x8, #0xb8]                            
02cbfa00: ldr     d0, [x8, #0x18]                            
02cbfa04: ldr     s1, [x8, #0x20]                            
02cbfa08: add     x0, sp, #0x70                              
02cbfa0c: add     x1, sp, #0x60                              
02cbfa10: mov     x2, xzr                                    
02cbfa14: str     d0, [sp, #0x60]                            
02cbfa18: str     s1, [sp, #0x68]                            
02cbfa1c: bl      #0x5b262ec                                 UnityEngine.Quaternion::Internal_LookRotation
02cbfa20: adrp    x8, #0x1085000                             
02cbfa24: fmov    s9, s0                                     
02cbfa28: add     x0, sp, #0x70                              
02cbfa2c: ldr     s0, [x8, #0x10]                            [1085010]=4202c6f23c8efa35 f=0.0174533,32.6943
02cbfa30: mov     x1, xzr                                    
02cbfa34: fmov    s12, s1                                    
02cbfa38: fmov    s13, s2                                    
02cbfa3c: fmov    s14, s3                                    
02cbfa40: str     xzr, [sp, #0x70]                           
02cbfa44: fmul    s0, s15, s0                                
02cbfa48: stp     wzr, wzr, [sp, #0x74]                      
02cbfa4c: str     s0, [sp, #0x5c]                            
02cbfa50: str     s0, [sp, #0x70]                            
02cbfa54: bl      #0x5b2607c                                 UnityEngine.Quaternion::Internal_FromEulerRad
02cbfa58: fmul    s4, s14, s0                                
02cbfa5c: fmul    s5, s9, s3                                 
02cbfa60: adrp    x21, #0x662f000                            
02cbfa64: fmul    s6, s14, s1                                
02cbfa68: fmul    s7, s12, s3                                
02cbfa6c: ldrb    w8, [x21, #0xca4]                          
02cbfa70: fmul    s16, s14, s2                               
02cbfa74: fmul    s17, s13, s3                               
02cbfa78: fmul    s3, s14, s3                                
02cbfa7c: fmul    s18, s9, s0                                
02cbfa80: fadd    s4, s4, s5                                 
02cbfa84: fmul    s5, s12, s2                                
02cbfa88: fadd    s6, s6, s7                                 
02cbfa8c: fmul    s7, s13, s0                                
02cbfa90: fmul    s0, s12, s0                                
02cbfa94: fadd    s16, s16, s17                              
02cbfa98: fmul    s17, s9, s1                                
02cbfa9c: fsub    s3, s3, s18                                
02cbfaa0: fmul    s18, s12, s1                               
02cbfaa4: fmul    s1, s13, s1                                
02cbfaa8: fadd    s4, s5, s4                                 
02cbfaac: fmul    s5, s9, s2                                 
02cbfab0: fmul    s2, s13, s2                                
02cbfab4: fadd    s6, s7, s6                                 
02cbfab8: fadd    s7, s17, s16                               
02cbfabc: fsub    s3, s3, s18                                
02cbfac0: fsub    s9, s4, s1                                 
02cbfac4: fsub    s12, s6, s5                                
02cbfac8: fsub    s13, s7, s0                                
02cbfacc: fsub    s14, s3, s2                                
02cbfad0: cbnz    w8, #0x2cbfae8                             
02cbfad4: adrp    x0, #0x6264000                             
02cbfad8: ldr     x0, [x0, #0xd8]                            T:UnityEngine.Vector3
02cbfadc: bl      #0x2b70db0                                 fn_2b70db0
02cbfae0: mov     w8, #1                                     
02cbfae4: strb    w8, [x21, #0xca4]                          
02cbfae8: ldr     x8, [x19]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02cbfaec: fmov    s0, s9                                     
02cbfaf0: fmov    s1, s12                                    
02cbfaf4: fmov    s2, s13                                    
02cbfaf8: fmov    s3, s14                                    
02cbfafc: mov     x0, xzr                                    
02cbfb00: ldr     x8, [x8, #0xb8]                            [10850b8]=61c8864f85ebca77 f=-2.21737e-35,4.62378e+20
02cbfb04: ldp     s4, s5, [x8, #0x54]                        
02cbfb08: ldr     s6, [x8, #0x5c]                            [108505c]=3f8000003e91eb86 f=0.285,1
02cbfb0c: bl      #0x5b26598                                 UnityEngine.Quaternion::op_Multiply
02cbfb10: ldrb    w8, [x20, #0x918]                          
02cbfb14: stp     s0, s2, [sp, #0x40]                        
02cbfb18: str     s1, [sp, #0x48]                            
02cbfb1c: stp     s11, s10, [sp, #0x70]                      
02cbfb20: str     s8, [sp, #0x78]                            
02cbfb24: str     wzr, [sp, #0x68]                           
02cbfb28: str     xzr, [sp, #0x60]                           
02cbfb2c: cbnz    w8, #0x2cbfb44                             
02cbfb30: adrp    x0, #0x6264000                             
02cbfb34: ldr     x0, [x0, #0xd8]                            T:UnityEngine.Vector3
02cbfb38: bl      #0x2b70db0                                 fn_2b70db0
02cbfb3c: mov     w8, #1                                     
02cbfb40: strb    w8, [x20, #0x918]                          
02cbfb44: ldr     x8, [x19]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02cbfb48: add     x0, sp, #0x70                              
02cbfb4c: add     x1, sp, #0x60                              
02cbfb50: mov     x2, xzr                                    
02cbfb54: ldr     x8, [x8, #0xb8]                            [10850b8]=61c8864f85ebca77 f=-2.21737e-35,4.62378e+20
02cbfb58: ldr     d0, [x8, #0x18]                            [1085018]=47c34f803a83126f f=0.001,99999
02cbfb5c: ldr     s1, [x8, #0x20]                            [1085020]=447fc0004064f92e f=3.57771,1023
02cbfb60: str     d0, [sp, #0x60]                            
02cbfb64: str     s1, [sp, #0x68]                            
02cbfb68: bl      #0x5b262ec                                 UnityEngine.Quaternion::Internal_LookRotation
02cbfb6c: adrp    x8, #0x1084000                             
02cbfb70: fmov    s9, s0                                     
02cbfb74: add     x0, sp, #0x70                              
02cbfb78: ldr     s0, [x8, #0xe64]                           [1084e64]=c0490fdbbc8efa35 f=-0.0174533,-3.14159
02cbfb7c: mov     x1, xzr                                    
02cbfb80: fmov    s12, s1                                    
02cbfb84: fmov    s13, s2                                    
02cbfb88: fmov    s14, s3                                    
02cbfb8c: str     xzr, [sp, #0x70]                           
02cbfb90: fmul    s0, s15, s0                                
02cbfb94: stp     wzr, wzr, [sp, #0x74]                      
02cbfb98: str     s0, [sp, #0x30]                            
02cbfb9c: str     s0, [sp, #0x70]                            
02cbfba0: bl      #0x5b2607c                                 UnityEngine.Quaternion::Internal_FromEulerRad
02cbfba4: fmul    s4, s14, s0                                
02cbfba8: fmul    s5, s9, s3                                 
02cbfbac: ldrb    w8, [x21, #0xca4]                          
02cbfbb0: fmul    s6, s14, s1                                
02cbfbb4: fmul    s7, s12, s3                                
02cbfbb8: fmul    s16, s14, s2                               
02cbfbbc: fmul    s17, s13, s3                               
02cbfbc0: fmul    s3, s14, s3                                
02cbfbc4: fmul    s18, s9, s0                                
02cbfbc8: fadd    s4, s4, s5                                 
02cbfbcc: fmul    s5, s12, s2                                
02cbfbd0: fmul    s19, s9, s2                                
02cbfbd4: fadd    s6, s6, s7                                 
02cbfbd8: fmul    s7, s13, s0                                
02cbfbdc: fmul    s0, s12, s0                                
02cbfbe0: fadd    s16, s16, s17                              
02cbfbe4: fmul    s17, s9, s1                                
02cbfbe8: fmul    s2, s13, s2                                
02cbfbec: fsub    s3, s3, s18                                
02cbfbf0: fmul    s18, s12, s1                               
02cbfbf4: fmul    s1, s13, s1                                
02cbfbf8: fadd    s4, s5, s4                                 
02cbfbfc: fadd    s5, s7, s6                                 
02cbfc00: fadd    s6, s17, s16                               
02cbfc04: fsub    s3, s3, s18                                
02cbfc08: fsub    s9, s4, s1                                 
02cbfc0c: fsub    s12, s5, s19                               
02cbfc10: fsub    s13, s6, s0                                
02cbfc14: fsub    s14, s3, s2                                
02cbfc18: cbnz    w8, #0x2cbfc30                             
02cbfc1c: adrp    x0, #0x6264000                             
02cbfc20: ldr     x0, [x0, #0xd8]                            T:UnityEngine.Vector3
02cbfc24: bl      #0x2b70db0                                 fn_2b70db0
02cbfc28: mov     w8, #1                                     
02cbfc2c: strb    w8, [x21, #0xca4]                          
02cbfc30: ldr     x8, [x19]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02cbfc34: fmov    s0, s9                                     
02cbfc38: fmov    s1, s12                                    
02cbfc3c: fmov    s2, s13                                    
02cbfc40: fmov    s3, s14                                    
02cbfc44: mov     x0, xzr                                    
02cbfc48: ldr     x8, [x8, #0xb8]                            [10840b8]=2632726f74636556 f=7.20646e+31,6.19112e-16
02cbfc4c: ldp     s4, s5, [x8, #0x54]                        
02cbfc50: ldr     s6, [x8, #0x5c]                            [108405c]=7361637961523a3a f=2.42376e+20,1.78571e+31
02cbfc54: bl      #0x5b26598                                 UnityEngine.Quaternion::op_Multiply
02cbfc58: ldrb    w8, [x20, #0x918]                          
02cbfc5c: stp     s1, s0, [sp, #0x38]                        
02cbfc60: str     s2, [sp, #0x34]                            
02cbfc64: stp     s11, s10, [sp, #0x70]                      
02cbfc68: str     s8, [sp, #0x78]                            
02cbfc6c: str     wzr, [sp, #0x68]                           
02cbfc70: str     xzr, [sp, #0x60]                           
02cbfc74: cbnz    w8, #0x2cbfc8c                             
02cbfc78: adrp    x0, #0x6264000                             
02cbfc7c: ldr     x0, [x0, #0xd8]                            T:UnityEngine.Vector3
02cbfc80: bl      #0x2b70db0                                 fn_2b70db0
02cbfc84: mov     w8, #1                                     
02cbfc88: strb    w8, [x20, #0x918]                          
02cbfc8c: ldr     x8, [x19]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02cbfc90: add     x0, sp, #0x70                              
02cbfc94: add     x1, sp, #0x60                              
02cbfc98: mov     x2, xzr                                    
02cbfc9c: ldr     x8, [x8, #0xb8]                            [10840b8]=2632726f74636556 f=7.20646e+31,6.19112e-16
02cbfca0: ldr     d0, [x8, #0x18]                            [1084018]=7974696c69745549 f=1.84613e+25,7.93162e+34
02cbfca4: ldr     s1, [x8, #0x20]                            [1084020]=79654b7465533a3a f=6.23433e+22,7.44104e+34
02cbfca8: str     d0, [sp, #0x60]                            
02cbfcac: str     s1, [sp, #0x68]                            
02cbfcb0: bl      #0x5b262ec                                 UnityEngine.Quaternion::Internal_LookRotation
02cbfcb4: fmov    s9, s0                                     
02cbfcb8: ldr     s0, [sp, #0x5c]                            
02cbfcbc: add     x0, sp, #0x70                              
02cbfcc0: mov     x1, xzr                                    
02cbfcc4: fmov    s12, s1                                    
02cbfcc8: fmov    s13, s2                                    
02cbfccc: fmov    s14, s3                                    
02cbfcd0: str     xzr, [sp, #0x70]                           
02cbfcd4: str     wzr, [sp, #0x78]                           
02cbfcd8: str     s0, [sp, #0x74]                            
02cbfcdc: bl      #0x5b2607c                                 UnityEngine.Quaternion::Internal_FromEulerRad
02cbfce0: fmul    s4, s14, s0                                
02cbfce4: fmul    s5, s9, s3                                 
02cbfce8: ldrb    w8, [x21, #0xca4]                          
02cbfcec: fmul    s6, s14, s1                                
02cbfcf0: fmul    s7, s12, s3                                
02cbfcf4: fmul    s16, s14, s2                               
02cbfcf8: fmul    s17, s13, s3                               
02cbfcfc: fmul    s3, s14, s3                                
02cbfd00: fmul    s18, s9, s0                                
02cbfd04: fadd    s4, s4, s5                                 
02cbfd08: fmul    s5, s12, s2                                
02cbfd0c: fmul    s19, s9, s2                                
02cbfd10: fadd    s6, s6, s7                                 
02cbfd14: fmul    s7, s13, s0                                
02cbfd18: fmul    s0, s12, s0                                
02cbfd1c: fadd    s16, s16, s17                              
02cbfd20: fmul    s17, s9, s1                                
02cbfd24: fmul    s2, s13, s2                                
02cbfd28: fsub    s3, s3, s18                                
02cbfd2c: fmul    s18, s12, s1                               
02cbfd30: fmul    s1, s13, s1                                
02cbfd34: fadd    s4, s5, s4                                 
02cbfd38: fadd    s5, s7, s6                                 
02cbfd3c: fadd    s6, s17, s16                               
02cbfd40: fsub    s3, s3, s18                                
02cbfd44: fsub    s9, s4, s1                                 
02cbfd48: fsub    s12, s5, s19                               
02cbfd4c: fsub    s13, s6, s0                                
02cbfd50: fsub    s14, s3, s2                                
02cbfd54: cbnz    w8, #0x2cbfd6c                             
02cbfd58: adrp    x0, #0x6264000                             
02cbfd5c: ldr     x0, [x0, #0xd8]                            T:UnityEngine.Vector3
02cbfd60: bl      #0x2b70db0                                 fn_2b70db0
02cbfd64: mov     w8, #1                                     
02cbfd68: strb    w8, [x21, #0xca4]                          
02cbfd6c: ldr     x8, [x19]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02cbfd70: fmov    s0, s9                                     
02cbfd74: fmov    s1, s12                                    
02cbfd78: fmov    s2, s13                                    
02cbfd7c: fmov    s3, s14                                    
02cbfd80: mov     x0, xzr                                    
02cbfd84: ldr     x8, [x8, #0xb8]                            [10840b8]=2632726f74636556 f=7.20646e+31,6.19112e-16
02cbfd88: ldp     s4, s5, [x8, #0x54]                        
02cbfd8c: ldr     s6, [x8, #0x5c]                            [108405c]=7361637961523a3a f=2.42376e+20,1.78571e+31
02cbfd90: bl      #0x5b26598                                 UnityEngine.Quaternion::op_Multiply
02cbfd94: ldrb    w8, [x20, #0x918]                          
02cbfd98: stp     s1, s0, [sp, #0x28]                        
02cbfd9c: str     s2, [sp, #0x24]                            
02cbfda0: stp     s11, s10, [sp, #0x70]                      
02cbfda4: str     s10, [sp, #0x54]                           
02cbfda8: str     s8, [sp, #0x5c]                            
02cbfdac: str     s8, [sp, #0x78]                            
02cbfdb0: str     wzr, [sp, #0x68]                           
02cbfdb4: str     xzr, [sp, #0x60]                           
02cbfdb8: cbnz    w8, #0x2cbfdd0                             
02cbfdbc: adrp    x0, #0x6264000                             
02cbfdc0: ldr     x0, [x0, #0xd8]                            T:UnityEngine.Vector3
02cbfdc4: bl      #0x2b70db0                                 fn_2b70db0
02cbfdc8: mov     w8, #1                                     
02cbfdcc: strb    w8, [x20, #0x918]                          
02cbfdd0: ldr     x8, [x19]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02cbfdd4: adrp    x20, #0x6263000                            
02cbfdd8: ldr     s15, [sp, #0xf0]                           
02cbfddc: add     x0, sp, #0x70                              
02cbfde0: add     x1, sp, #0x60                              
02cbfde4: mov     x2, xzr                                    
02cbfde8: ldr     x8, [x8, #0xb8]                            [10840b8]=2632726f74636556 f=7.20646e+31,6.19112e-16
02cbfdec: ldr     d0, [x8, #0x18]                            [1084018]=7974696c69745549 f=1.84613e+25,7.93162e+34
02cbfdf0: ldr     s1, [x8, #0x20]                            [1084020]=79654b7465533a3a f=6.23433e+22,7.44104e+34
02cbfdf4: ldr     x20, [x20, #0x928]                         T:UnityEngine.Debug
02cbfdf8: str     d0, [sp, #0x60]                            
02cbfdfc: str     s1, [sp, #0x68]                            
02cbfe00: bl      #0x5b262ec                                 UnityEngine.Quaternion::Internal_LookRotation
02cbfe04: fmov    s9, s0                                     
02cbfe08: ldr     s0, [sp, #0x30]                            
02cbfe0c: add     x0, sp, #0x70                              
02cbfe10: mov     x1, xzr                                    
02cbfe14: fmov    s12, s1                                    
02cbfe18: fmov    s13, s2                                    
02cbfe1c: fmov    s14, s3                                    
02cbfe20: str     xzr, [sp, #0x70]                           
02cbfe24: str     wzr, [sp, #0x78]                           
02cbfe28: str     s0, [sp, #0x74]                            
02cbfe2c: bl      #0x5b2607c                                 UnityEngine.Quaternion::Internal_FromEulerRad
02cbfe30: fmul    s4, s14, s0                                
02cbfe34: fmul    s5, s9, s3                                 
02cbfe38: ldrb    w8, [x21, #0xca4]                          
02cbfe3c: fmul    s6, s14, s1                                
02cbfe40: fmul    s7, s12, s3                                
02cbfe44: fmul    s16, s14, s2                               
02cbfe48: fmul    s17, s13, s3                               
02cbfe4c: fmul    s3, s14, s3                                
02cbfe50: fmul    s18, s9, s0                                
02cbfe54: fadd    s4, s4, s5                                 
02cbfe58: fmul    s5, s12, s2                                
02cbfe5c: fmul    s19, s9, s2                                
02cbfe60: fadd    s6, s6, s7                                 
02cbfe64: fmul    s7, s13, s0                                
02cbfe68: fmul    s0, s12, s0                                
02cbfe6c: fadd    s16, s16, s17                              
02cbfe70: fmul    s17, s9, s1                                
02cbfe74: fmul    s2, s13, s2                                
02cbfe78: fsub    s3, s3, s18                                
02cbfe7c: fmul    s18, s12, s1                               
02cbfe80: fmul    s1, s13, s1                                
02cbfe84: fadd    s4, s5, s4                                 
02cbfe88: fadd    s5, s7, s6                                 
02cbfe8c: fadd    s6, s17, s16                               
02cbfe90: fsub    s3, s3, s18                                
02cbfe94: fsub    s8, s4, s1                                 
02cbfe98: fsub    s14, s5, s19                               
02cbfe9c: fsub    s13, s6, s0                                
02cbfea0: fsub    s10, s3, s2                                
02cbfea4: cbnz    w8, #0x2cbfebc                             
02cbfea8: adrp    x0, #0x6264000                             
02cbfeac: ldr     x0, [x0, #0xd8]                            T:UnityEngine.Vector3
02cbfeb0: bl      #0x2b70db0                                 fn_2b70db0
02cbfeb4: mov     w8, #1                                     
02cbfeb8: strb    w8, [x21, #0xca4]                          
02cbfebc: ldp     s0, s1, [sp, #0xe8]                        
02cbfec0: fmov    s2, s13                                    
02cbfec4: ldr     x8, [x19]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02cbfec8: fmov    s3, s10                                    
02cbfecc: mov     x0, xzr                                    
02cbfed0: stp     s1, s0, [sp, #0x1c]                        
02cbfed4: ldp     s9, s0, [sp, #0xe0]                        
02cbfed8: ldr     x8, [x8, #0xb8]                            [10840b8]=2632726f74636556 f=7.20646e+31,6.19112e-16
02cbfedc: fmov    s1, s14                                    
02cbfee0: str     s0, [sp, #0x30]                            
02cbfee4: fmov    s0, s8                                     
02cbfee8: ldr     s6, [x8, #0x5c]                            [108405c]=7361637961523a3a f=2.42376e+20,1.78571e+31
02cbfeec: ldp     s4, s5, [x8, #0x54]                        
02cbfef0: bl      #0x5b26598                                 UnityEngine.Quaternion::op_Multiply
02cbfef4: stp     s1, s0, [sp, #0x14]                        
02cbfef8: ldp     s0, s1, [sp, #0x4c]                        
02cbfefc: ldr     x0, [x20]                                  &2c5bbd4(=a9bd7bfdd503233f)
02cbff00: fadd    s11, s0, s11                               
02cbff04: ldr     s0, [sp, #0x54]                            
02cbff08: ldr     w8, [x0, #0xe4]                            [62640e4]=0 f=0,0
02cbff0c: fadd    s10, s1, s0                                
02cbff10: ldr     s0, [sp, #0x40]                            
02cbff14: fmul    s3, s0, s15                                
02cbff18: ldp     s1, s0, [sp, #0x58]                        
02cbff1c: str     s2, [sp, #0x5c]                            
02cbff20: fadd    s8, s1, s0                                 
02cbff24: ldp     s0, s1, [sp, #0x44]                        
02cbff28: fmul    s4, s1, s15                                
02cbff2c: fmul    s14, s0, s15                               
02cbff30: cbnz    w8, #0x2cbff48                             
02cbff34: fmov    s12, s3                                    
02cbff38: fmov    s13, s4                                    
02cbff3c: bl      #0x2b70f30                                 fn_2b70f30
02cbff40: fmov    s4, s13                                    
02cbff44: fmov    s3, s12                                    
02cbff48: fmov    s0, s11                                    
02cbff4c: fmov    s1, s10                                    
02cbff50: ldr     s12, [sp, #0x30]                           
02cbff54: fmov    s2, s8                                     
02cbff58: fmov    s5, s14                                    
02cbff5c: ldr     s13, [sp, #0x20]                           
02cbff60: ldr     s14, [sp, #0x1c]                           
02cbff64: mov     x0, xzr                                    
02cbff68: stp     s9, s12, [sp]                              
02cbff6c: stp     s13, s14, [sp, #8]                         
02cbff70: bl      #0x5af1e20                                 UnityEngine.Debug::DrawRay
02cbff74: ldp     s0, s6, [sp, #0x38]                        
02cbff78: fmov    s1, s10                                    
02cbff7c: fmov    s2, s8                                     
02cbff80: mov     x0, xzr                                    
02cbff84: stp     s13, s14, [sp, #8]                         
02cbff88: stp     s9, s12, [sp]                              
02cbff8c: fmul    s4, s0, s15                                
02cbff90: ldr     s0, [sp, #0x34]                            
02cbff94: fmul    s3, s6, s15                                
02cbff98: fmul    s5, s0, s15                                
02cbff9c: fmov    s0, s11                                    
02cbffa0: bl      #0x5af1e20                                 UnityEngine.Debug::DrawRay
02cbffa4: ldp     s0, s6, [sp, #0x28]                        
02cbffa8: fmov    s1, s10                                    
02cbffac: fmov    s2, s8                                     
02cbffb0: mov     x0, xzr                                    
02cbffb4: stp     s13, s14, [sp, #8]                         
02cbffb8: stp     s9, s12, [sp]                              
02cbffbc: fmul    s4, s0, s15                                
02cbffc0: ldr     s0, [sp, #0x24]                            
02cbffc4: fmul    s3, s6, s15                                
02cbffc8: fmul    s5, s0, s15                                
02cbffcc: fmov    s0, s11                                    
02cbffd0: bl      #0x5af1e20                                 UnityEngine.Debug::DrawRay
02cbffd4: ldp     s0, s6, [sp, #0x14]                        
02cbffd8: fmov    s1, s10                                    
02cbffdc: fmov    s2, s8                                     
02cbffe0: mov     x0, xzr                                    
02cbffe4: stp     s13, s14, [sp, #8]                         
02cbffe8: stp     s9, s12, [sp]                              
02cbffec: fmul    s4, s0, s15                                
02cbfff0: ldr     s0, [sp, #0x5c]                            
02cbfff4: fmul    s3, s6, s15                                
02cbfff8: fmul    s5, s0, s15                                
02cbfffc: fmov    s0, s11                                    
02cc0000: bl      #0x5af1e20                                 UnityEngine.Debug::DrawRay
02cc0004: ldp     x20, x19, [sp, #0xd0]                      
02cc0008: ldp     x30, x21, [sp, #0xc0]                      
02cc000c: ldp     d9, d8, [sp, #0xb0]                        
02cc0010: ldp     d11, d10, [sp, #0xa0]                      
02cc0014: ldp     d13, d12, [sp, #0x90]                      
02cc0018: ldp     d15, d14, [sp, #0x80]                      
02cc001c: add     sp, sp, #0xe0                              
02cc0020: ret                                                
## DrawRectangle(UnityEngine.Rect rectangle, UnityEngine.Color color) -> void
---- Framework.GizmosDrawer::DrawRectangle 0x2cc0024
02cc0024: str     x30, [sp, #-0x20]!                         
02cc0028: stp     x20, x19, [sp, #0x10]                      
02cc002c: adrp    x19, #0x662f000                            
02cc0030: adrp    x20, #0x6264000                            
02cc0034: ldrb    w8, [x19, #0xc0f]                          
02cc0038: ldr     x20, [x20, #0x798]                         T:UnityEngine.Rect
02cc003c: tbnz    w8, #0, #0x2cc0054                         
02cc0040: adrp    x0, #0x6264000                             
02cc0044: ldr     x0, [x0, #0x798]                           T:UnityEngine.Rect
02cc0048: bl      #0x2b70db0                                 fn_2b70db0
02cc004c: mov     w8, #1                                     
02cc0050: strb    w8, [x19, #0xc0f]                          
02cc0054: ldr     x0, [x20]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02cc0058: ldr     w8, [x0, #0xe4]                            [62640e4]=0 f=0,0
02cc005c: cbz     w8, #0x2cc006c                             
02cc0060: ldp     x20, x19, [sp, #0x10]                      
02cc0064: ldr     x30, [sp], #0x20                           
02cc0068: ret                                                
02cc006c: ldp     x20, x19, [sp, #0x10]                      
02cc0070: ldr     x30, [sp], #0x20                           
02cc0074: b       #0x2b70f30                                 
## DrawRectangle(UnityEngine.Vector3 position, UnityEngine.Vector3 size, UnityEngine.Color color) -> void
---- Framework.GizmosDrawer::DrawRectangle 0x2cc0078
02cc0078: sub     sp, sp, #0x70                              
02cc007c: stp     d15, d14, [sp, #0x20]                      
02cc0080: stp     d13, d12, [sp, #0x30]                      
02cc0084: stp     d11, d10, [sp, #0x40]                      
02cc0088: stp     d9, d8, [sp, #0x50]                        
02cc008c: stp     x30, x19, [sp, #0x60]                      
02cc0090: fmov    s12, s4                                    
02cc0094: fmov    s9, s3                                     
02cc0098: adrp    x19, #0x662f000                            
02cc009c: fmov    s10, s1                                    
02cc00a0: fmov    s11, s0                                    
02cc00a4: ldrb    w8, [x19, #0xc10]                          
02cc00a8: ldp     s15, s13, [sp, #0x70]                      
02cc00ac: stp     s5, s2, [sp, #0x18]                        
02cc00b0: ldp     s8, s14, [sp, #0x78]                       
02cc00b4: tbnz    w8, #0, #0x2cc00d8                         
02cc00b8: adrp    x0, #0x6263000                             
02cc00bc: ldr     x0, [x0, #0x928]                           T:UnityEngine.Debug
02cc00c0: bl      #0x2b70db0                                 fn_2b70db0
02cc00c4: adrp    x0, #0x6264000                             
02cc00c8: ldr     x0, [x0, #0x270]                           T:type24806(k1d)
02cc00cc: bl      #0x2b70db0                                 fn_2b70db0
02cc00d0: mov     w8, #1                                     
02cc00d4: strb    w8, [x19, #0xc10]                          
02cc00d8: fmul    s0, s15, s15                               
02cc00dc: fmul    s1, s13, s13                               
02cc00e0: adrp    x8, #0x1084000                             
02cc00e4: fadd    s0, s0, s1                                 
02cc00e8: fmul    s1, s8, s8                                 
02cc00ec: fadd    s0, s1, s0                                 
02cc00f0: fmul    s1, s14, s14                               
02cc00f4: fadd    s0, s1, s0                                 
02cc00f8: ldr     s1, [x8, #0xbd0]                           [1084bd0]=3f6666662edbe6fe f=1e-10,0.9
02cc00fc: adrp    x8, #0x6264000                             
02cc0100: ldr     x8, [x8, #0x270]                           T:type24806(k1d)
02cc0104: fcmp    s0, s1                                     
02cc0108: b.pl    #0x2cc011c                                 
02cc010c: fmov    s15, #1.00000000                           
02cc0110: fmov    s13, #1.00000000                           
02cc0114: fmov    s8, #1.00000000                            
02cc0118: fmov    s14, #1.00000000                           
02cc011c: ldr     x0, [x8]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02cc0120: mov     w1, #4                                     
02cc0124: bl      #0x2b70ea0                                 fn_2b70ea0
02cc0128: cbz     x0, #0x2cc0284                             
02cc012c: ldr     w8, [x0, #0x18]                            M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass2_0::<DOSetFloat>b__1
02cc0130: mov     x19, x0                                    
02cc0134: cbz     w8, #0x2cc0280                             
02cc0138: fmov    s2, #0.50000000                            
02cc013c: ldp     s5, s4, [sp, #0x18]                        
02cc0140: fmov    s3, s10                                    
02cc0144: cmp     w8, #1                                     
02cc0148: fmul    s1, s9, s2                                 
02cc014c: fmul    s0, s12, s2                                
02cc0150: fmul    s2, s5, s2                                 
02cc0154: fadd    s12, s11, s1                               
02cc0158: fadd    s10, s10, s0                               
02cc015c: fadd    s9, s4, s2                                 
02cc0160: stp     s12, s10, [x19, #0x20]                     
02cc0164: str     s9, [x19, #0x28]                           
02cc0168: b.eq    #0x2cc0280                                 
02cc016c: fsub    s11, s11, s1                               
02cc0170: cmp     w8, #2                                     
02cc0174: str     s9, [x19, #0x34]                           
02cc0178: stp     s11, s10, [x19, #0x2c]                     
02cc017c: b.ls    #0x2cc0280                                 
02cc0180: fsub    s0, s3, s0                                 
02cc0184: cmp     w8, #3                                     
02cc0188: str     s9, [x19, #0x40]                           
02cc018c: stp     s11, s0, [x19, #0x38]                      
02cc0190: b.eq    #0x2cc0280                                 
02cc0194: str     s12, [x19, #0x44]                          
02cc0198: adrp    x8, #0x6263000                             
02cc019c: ldr     x8, [x8, #0x928]                           T:UnityEngine.Debug
02cc01a0: stp     s0, s9, [x19, #0x48]                       
02cc01a4: ldr     x0, [x8]                                   &2c5bbd4(=a9bd7bfdd503233f)
02cc01a8: ldr     w8, [x0, #0xe4]                            [62640e4]=0 f=0,0
02cc01ac: cbnz    w8, #0x2cc01b4                             
02cc01b0: bl      #0x2b70f30                                 fn_2b70f30
02cc01b4: fmov    s0, s12                                    
02cc01b8: fmov    s1, s10                                    
02cc01bc: mov     x0, xzr                                    
02cc01c0: fmov    s2, s9                                     
02cc01c4: fmov    s3, s11                                    
02cc01c8: stp     s8, s14, [sp, #8]                          
02cc01cc: fmov    s4, s10                                    
02cc01d0: fmov    s5, s9                                     
02cc01d4: stp     s15, s13, [sp]                             
02cc01d8: bl      #0x5af1cd4                                 UnityEngine.Debug::DrawLine
02cc01dc: ldr     w8, [x19, #0x18]                           [662f018]=6000014 f=2.40742e-35,0
02cc01e0: cmp     w8, #1                                     
02cc01e4: b.ls    #0x2cc0280                                 
02cc01e8: cmp     w8, #2                                     
02cc01ec: b.eq    #0x2cc0280                                 
02cc01f0: ldp     s0, s1, [x19, #0x2c]                       
02cc01f4: mov     x0, xzr                                    
02cc01f8: ldp     s2, s3, [x19, #0x34]                       
02cc01fc: ldp     s4, s5, [x19, #0x3c]                       
02cc0200: stp     s8, s14, [sp, #8]                          
02cc0204: stp     s15, s13, [sp]                             
02cc0208: bl      #0x5af1cd4                                 UnityEngine.Debug::DrawLine
02cc020c: ldr     w8, [x19, #0x18]                           [662f018]=6000014 f=2.40742e-35,0
02cc0210: cmp     w8, #2                                     
02cc0214: b.ls    #0x2cc0280                                 
02cc0218: cmp     w8, #3                                     
02cc021c: b.eq    #0x2cc0280                                 
02cc0220: ldp     s0, s1, [x19, #0x38]                       
02cc0224: mov     x0, xzr                                    
02cc0228: ldp     s2, s3, [x19, #0x40]                       
02cc022c: ldp     s4, s5, [x19, #0x48]                       
02cc0230: stp     s8, s14, [sp, #8]                          
02cc0234: stp     s15, s13, [sp]                             
02cc0238: bl      #0x5af1cd4                                 UnityEngine.Debug::DrawLine
02cc023c: ldr     w8, [x19, #0x18]                           [662f018]=6000014 f=2.40742e-35,0
02cc0240: tst     w8, #0xfffffffc                            
02cc0244: b.eq    #0x2cc0280                                 
02cc0248: ldp     s0, s1, [x19, #0x44]                       
02cc024c: mov     x0, xzr                                    
02cc0250: ldr     s2, [x19, #0x4c]                           [662f04c]=0 f=0,0
02cc0254: ldp     s3, s4, [x19, #0x20]                       
02cc0258: ldr     s5, [x19, #0x28]                           [662f028]=6000015 f=2.40742e-35,0
02cc025c: stp     s15, s13, [sp, #0x70]                      
02cc0260: stp     s8, s14, [sp, #0x78]                       
02cc0264: ldp     x30, x19, [sp, #0x60]                      
02cc0268: ldp     d9, d8, [sp, #0x50]                        
02cc026c: ldp     d11, d10, [sp, #0x40]                      
02cc0270: ldp     d13, d12, [sp, #0x30]                      
02cc0274: ldp     d15, d14, [sp, #0x20]                      
02cc0278: add     sp, sp, #0x70                              
02cc027c: b       #0x5af1cd4                                 UnityEngine.Debug::DrawLine
02cc0280: bl      #0x2b71064                                 fn_2b71064
02cc0284: bl      #0x2b7105c                                 fn_2b7105c
## DrawPoint(UnityEngine.Vector3 position, float size, UnityEngine.Color color) -> void
---- Framework.GizmosDrawer::DrawPoint 0x2cc0288
02cc0288: sub     sp, sp, #0xa0                              
02cc028c: stp     d15, d14, [sp, #0x40]                      
02cc0290: stp     d13, d12, [sp, #0x50]                      
02cc0294: stp     d11, d10, [sp, #0x60]                      
02cc0298: stp     d9, d8, [sp, #0x70]                        
02cc029c: stp     x30, x21, [sp, #0x80]                      
02cc02a0: stp     x20, x19, [sp, #0x90]                      
02cc02a4: fmov    s11, s7                                    
02cc02a8: fmov    s10, s6                                    
02cc02ac: adrp    x19, #0x662f000                            
02cc02b0: fmov    s9, s5                                     
02cc02b4: fmov    s8, s4                                     
02cc02b8: ldrb    w8, [x19, #0xc11]                          
02cc02bc: fmov    s12, s2                                    
02cc02c0: stp     q1, q3, [sp, #0x10]                        
02cc02c4: str     q0, [sp, #0x30]                            
02cc02c8: tbnz    w8, #0, #0x2cc02ec                         
02cc02cc: adrp    x0, #0x6263000                             
02cc02d0: ldr     x0, [x0, #0x928]                           T:UnityEngine.Debug
02cc02d4: bl      #0x2b70db0                                 fn_2b70db0
02cc02d8: adrp    x0, #0x6264000                             
02cc02dc: ldr     x0, [x0, #0x270]                           T:type24806(k1d)
02cc02e0: bl      #0x2b70db0                                 fn_2b70db0
02cc02e4: mov     w8, #1                                     
02cc02e8: strb    w8, [x19, #0xc11]                          
02cc02ec: fmul    s0, s8, s8                                 
02cc02f0: fmul    s1, s9, s9                                 
02cc02f4: adrp    x8, #0x1084000                             
02cc02f8: fadd    s0, s0, s1                                 
02cc02fc: fmul    s1, s10, s10                               
02cc0300: fadd    s0, s1, s0                                 
02cc0304: fmul    s1, s11, s11                               
02cc0308: fadd    s0, s1, s0                                 
02cc030c: ldr     s1, [x8, #0xbd0]                           [1084bd0]=3f6666662edbe6fe f=1e-10,0.9
02cc0310: adrp    x8, #0x6264000                             
02cc0314: ldr     x8, [x8, #0x270]                           T:type24806(k1d)
02cc0318: fcmp    s0, s1                                     
02cc031c: b.pl    #0x2cc0330                                 
02cc0320: fmov    s8, #1.00000000                            
02cc0324: fmov    s9, #1.00000000                            
02cc0328: fmov    s10, #1.00000000                           
02cc032c: fmov    s11, #1.00000000                           
02cc0330: ldr     x0, [x8]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02cc0334: mov     w1, #6                                     
02cc0338: bl      #0x2b70ea0                                 fn_2b70ea0
02cc033c: adrp    x20, #0x662f000                            
02cc0340: mov     x19, x0                                    
02cc0344: ldrb    w8, [x20, #0x918]                          
02cc0348: cbnz    w8, #0x2cc0360                             
02cc034c: adrp    x0, #0x6264000                             
02cc0350: ldr     x0, [x0, #0xd8]                            T:UnityEngine.Vector3
02cc0354: bl      #0x2b70db0                                 fn_2b70db0
02cc0358: mov     w8, #1                                     
02cc035c: strb    w8, [x20, #0x918]                          
02cc0360: cbz     x19, #0x2cc080c                            
02cc0364: ldp     q2, q3, [sp, #0x20]                        
02cc0368: ldr     w8, [x19, #0x18]                           [662f018]=6000014 f=2.40742e-35,0
02cc036c: cbz     x8, #0x2cc0808                             
02cc0370: adrp    x20, #0x6264000                            
02cc0374: tst     x8, #0xfffffffe                            
02cc0378: ldr     x20, [x20, #0xd8]                          T:UnityEngine.Vector3
02cc037c: ldr     q4, [sp, #0x10]                            
02cc0380: ldr     x9, [x20]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02cc0384: mov     v3.s[1], v4.s[0]                           
02cc0388: ldr     x9, [x9, #0xb8]                            
02cc038c: ldr     d0, [x9, #0x18]                            
02cc0390: ldr     s1, [x9, #0x20]                            
02cc0394: fmul    v0.2s, v0.2s, v2.s[0]                      
02cc0398: fmul    s1, s1, s2                                 
02cc039c: fadd    v0.2s, v3.2s, v0.2s                        
02cc03a0: fadd    s1, s12, s1                                
02cc03a4: str     d0, [x19, #0x20]                           
02cc03a8: str     s1, [x19, #0x28]                           
02cc03ac: b.eq    #0x2cc0808                                 
02cc03b0: ldr     x9, [x20]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02cc03b4: adrp    x21, #0x662f000                            
02cc03b8: ldr     x9, [x9, #0xb8]                            
02cc03bc: ldr     d0, [x9, #0x18]                            
02cc03c0: ldr     s1, [x9, #0x20]                            
02cc03c4: ldrb    w9, [x21, #0xca5]                          
02cc03c8: fmul    v0.2s, v0.2s, v2.s[0]                      
02cc03cc: fmul    s1, s1, s2                                 
02cc03d0: fsub    v0.2s, v3.2s, v0.2s                        
02cc03d4: fsub    s1, s12, s1                                
02cc03d8: stur    d0, [x19, #0x2c]                           
02cc03dc: str     s1, [x19, #0x34]                           
02cc03e0: cbnz    w9, #0x2cc0404                             
02cc03e4: adrp    x0, #0x6264000                             
02cc03e8: ldr     x0, [x0, #0xd8]                            T:UnityEngine.Vector3
02cc03ec: str     q3, [sp, #0x30]                            
02cc03f0: bl      #0x2b70db0                                 fn_2b70db0
02cc03f4: ldp     q2, q3, [sp, #0x20]                        
02cc03f8: mov     w9, #1                                     
02cc03fc: ldr     x8, [x19, #0x18]                           [662f018]=6000014 f=2.40742e-35,0
02cc0400: strb    w9, [x21, #0xca5]                          
02cc0404: cmp     w8, #2                                     
02cc0408: b.ls    #0x2cc0808                                 
02cc040c: ldr     x9, [x20]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02cc0410: tst     x8, #0xfffffffc                            
02cc0414: ldr     x9, [x9, #0xb8]                            
02cc0418: ldur    d0, [x9, #0x3c]                            
02cc041c: ldr     s1, [x9, #0x44]                            
02cc0420: fmul    v0.2s, v0.2s, v2.s[0]                      
02cc0424: fmul    s1, s1, s2                                 
02cc0428: fadd    v0.2s, v3.2s, v0.2s                        
02cc042c: fadd    s1, s12, s1                                
02cc0430: str     d0, [x19, #0x38]                           
02cc0434: str     s1, [x19, #0x40]                           
02cc0438: b.eq    #0x2cc0808                                 
02cc043c: ldr     x9, [x20]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02cc0440: adrp    x21, #0x662f000                            
02cc0444: ldr     x9, [x9, #0xb8]                            
02cc0448: ldur    d0, [x9, #0x3c]                            
02cc044c: ldr     s1, [x9, #0x44]                            
02cc0450: ldrb    w9, [x21, #0x91c]                          
02cc0454: fmul    v0.2s, v0.2s, v2.s[0]                      
02cc0458: fmul    s1, s1, s2                                 
02cc045c: fsub    v0.2s, v3.2s, v0.2s                        
02cc0460: fsub    s1, s12, s1                                
02cc0464: stur    d0, [x19, #0x44]                           
02cc0468: str     s1, [x19, #0x4c]                           
02cc046c: cbnz    w9, #0x2cc0490                             
02cc0470: adrp    x0, #0x6264000                             
02cc0474: ldr     x0, [x0, #0xd8]                            T:UnityEngine.Vector3
02cc0478: str     q3, [sp, #0x30]                            
02cc047c: bl      #0x2b70db0                                 fn_2b70db0
02cc0480: ldp     q2, q3, [sp, #0x20]                        
02cc0484: mov     w9, #1                                     
02cc0488: ldr     w8, [x19, #0x18]                           [662f018]=6000014 f=2.40742e-35,0
02cc048c: strb    w9, [x21, #0x91c]                          
02cc0490: cmp     w8, #4                                     
02cc0494: b.ls    #0x2cc0808                                 
02cc0498: ldr     x9, [x20]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02cc049c: cmp     w8, #5                                     
02cc04a0: str     s9, [sp, #0x30]                            
02cc04a4: str     s8, [sp, #0x20]                            
02cc04a8: ldr     x9, [x9, #0xb8]                            
02cc04ac: ldr     d0, [x9, #0x48]                            
02cc04b0: ldr     s1, [x9, #0x50]                            
02cc04b4: fmul    v0.2s, v0.2s, v2.s[0]                      
02cc04b8: fmul    s1, s1, s2                                 
02cc04bc: fadd    v0.2s, v3.2s, v0.2s                        
02cc04c0: fadd    s1, s12, s1                                
02cc04c4: str     d0, [x19, #0x50]                           
02cc04c8: str     s1, [x19, #0x58]                           
02cc04cc: b.eq    #0x2cc0808                                 
02cc04d0: ldr     x8, [x20]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02cc04d4: ldr     x8, [x8, #0xb8]                            MS:DG.Tweening.Core.Extensions::SetSpecialStartupMode
02cc04d8: ldr     d0, [x8, #0x48]                            M:DG.Tweening.DOTweenModulePhysics/<>c__DisplayClass0_0::<DOMove>b__0
02cc04dc: ldr     s1, [x8, #0x50]                            T:DG.Tweening.DOTweenModulePhysics/<>c__DisplayClass1_0
02cc04e0: adrp    x8, #0x6263000                             
02cc04e4: ldr     x8, [x8, #0x928]                           T:UnityEngine.Debug
02cc04e8: ldp     s14, s15, [x19, #0x28]                     
02cc04ec: fmul    v0.2s, v0.2s, v2.s[0]                      
02cc04f0: fmul    s1, s1, s2                                 
02cc04f4: ldp     s8, s9, [x19, #0x30]                       
02cc04f8: fsub    v0.2s, v3.2s, v0.2s                        
02cc04fc: fsub    s1, s12, s1                                
02cc0500: ldp     s12, s13, [x19, #0x20]                     
02cc0504: stur    d0, [x19, #0x5c]                           
02cc0508: str     s1, [x19, #0x64]                           
02cc050c: ldr     x0, [x8]                                   &2c5bbd4(=a9bd7bfdd503233f)
02cc0510: ldr     w8, [x0, #0xe4]                            [62640e4]=0 f=0,0
02cc0514: cbnz    w8, #0x2cc051c                             
02cc0518: bl      #0x2b70f30                                 fn_2b70f30
02cc051c: fmov    s0, s12                                    
02cc0520: fmov    s1, s13                                    
02cc0524: ldr     s6, [sp, #0x30]                            
02cc0528: fmov    s2, s14                                    
02cc052c: fmov    s3, s15                                    
02cc0530: mov     x0, xzr                                    
02cc0534: fmov    s4, s8                                     
02cc0538: fmov    s5, s9                                     
02cc053c: ldr     s8, [sp, #0x20]                            
02cc0540: stp     s10, s11, [sp, #8]                         
02cc0544: stp     s8, s6, [sp]                               
02cc0548: bl      #0x5af1cd4                                 UnityEngine.Debug::DrawLine
02cc054c: ldr     w8, [x19, #0x18]                           [662f018]=6000014 f=2.40742e-35,0
02cc0550: cmp     w8, #2                                     
02cc0554: b.ls    #0x2cc0808                                 
02cc0558: cmp     w8, #3                                     
02cc055c: b.eq    #0x2cc0808                                 
02cc0560: ldp     s0, s1, [x19, #0x38]                       
02cc0564: mov     x0, xzr                                    
02cc0568: ldp     s2, s3, [x19, #0x40]                       
02cc056c: ldr     s9, [sp, #0x30]                            
02cc0570: ldp     s4, s5, [x19, #0x48]                       
02cc0574: stp     s10, s11, [sp, #8]                         
02cc0578: stp     s8, s9, [sp]                               
02cc057c: bl      #0x5af1cd4                                 UnityEngine.Debug::DrawLine
02cc0580: ldr     w8, [x19, #0x18]                           [662f018]=6000014 f=2.40742e-35,0
02cc0584: cmp     w8, #4                                     
02cc0588: b.ls    #0x2cc0808                                 
02cc058c: cmp     w8, #5                                     
02cc0590: b.eq    #0x2cc0808                                 
02cc0594: ldp     s0, s1, [x19, #0x50]                       
02cc0598: mov     x0, xzr                                    
02cc059c: ldp     s2, s3, [x19, #0x58]                       
02cc05a0: ldp     s4, s5, [x19, #0x60]                       
02cc05a4: stp     s10, s11, [sp, #8]                         
02cc05a8: stp     s8, s9, [sp]                               
02cc05ac: bl      #0x5af1cd4                                 UnityEngine.Debug::DrawLine
02cc05b0: ldr     w8, [x19, #0x18]                           [662f018]=6000014 f=2.40742e-35,0
02cc05b4: cbz     w8, #0x2cc0808                             
02cc05b8: cmp     w8, #2                                     
02cc05bc: b.ls    #0x2cc0808                                 
02cc05c0: ldp     s1, s2, [x19, #0x24]                       
02cc05c4: mov     x0, xzr                                    
02cc05c8: ldp     s3, s4, [x19, #0x38]                       
02cc05cc: ldr     s0, [x19, #0x20]                           &2b706f0(=d65f03c0f9400800)
02cc05d0: ldr     s5, [x19, #0x40]                           &2b70700(=14cc750491004000)
02cc05d4: stp     s10, s11, [sp, #8]                         
02cc05d8: stp     s8, s9, [sp]                               
02cc05dc: bl      #0x5af1cd4                                 UnityEngine.Debug::DrawLine
02cc05e0: ldr     w8, [x19, #0x18]                           [662f018]=6000014 f=2.40742e-35,0
02cc05e4: cbz     w8, #0x2cc0808                             
02cc05e8: cmp     w8, #3                                     
02cc05ec: b.ls    #0x2cc0808                                 
02cc05f0: ldp     s1, s2, [x19, #0x24]                       
02cc05f4: mov     x0, xzr                                    
02cc05f8: ldp     s3, s4, [x19, #0x44]                       
02cc05fc: ldr     s0, [x19, #0x20]                           &2b706f0(=d65f03c0f9400800)
02cc0600: ldr     s5, [x19, #0x4c]                           [662f04c]=0 f=0,0
02cc0604: stp     s10, s11, [sp, #8]                         
02cc0608: stp     s8, s9, [sp]                               
02cc060c: bl      #0x5af1cd4                                 UnityEngine.Debug::DrawLine
02cc0610: ldr     w8, [x19, #0x18]                           [662f018]=6000014 f=2.40742e-35,0
02cc0614: cbz     w8, #0x2cc0808                             
02cc0618: cmp     w8, #4                                     
02cc061c: b.ls    #0x2cc0808                                 
02cc0620: ldp     s1, s2, [x19, #0x24]                       
02cc0624: mov     x0, xzr                                    
02cc0628: ldp     s3, s4, [x19, #0x50]                       
02cc062c: ldr     s0, [x19, #0x20]                           &2b706f0(=d65f03c0f9400800)
02cc0630: ldr     s5, [x19, #0x58]                           [662f058]=6000018 f=2.40742e-35,0
02cc0634: stp     s10, s11, [sp, #8]                         
02cc0638: stp     s8, s9, [sp]                               
02cc063c: bl      #0x5af1cd4                                 UnityEngine.Debug::DrawLine
02cc0640: ldr     w8, [x19, #0x18]                           [662f018]=6000014 f=2.40742e-35,0
02cc0644: cbz     w8, #0x2cc0808                             
02cc0648: cmp     w8, #5                                     
02cc064c: b.ls    #0x2cc0808                                 
02cc0650: ldp     s1, s2, [x19, #0x24]                       
02cc0654: mov     x0, xzr                                    
02cc0658: ldp     s3, s4, [x19, #0x5c]                       
02cc065c: ldr     s0, [x19, #0x20]                           &2b706f0(=d65f03c0f9400800)
02cc0660: ldr     s5, [x19, #0x64]                           [662f064]=600001900000000 f=0,2.40742e-35
02cc0664: stp     s10, s11, [sp, #8]                         
02cc0668: stp     s8, s9, [sp]                               
02cc066c: bl      #0x5af1cd4                                 UnityEngine.Debug::DrawLine
02cc0670: ldr     w8, [x19, #0x18]                           [662f018]=6000014 f=2.40742e-35,0
02cc0674: cmp     w8, #1                                     
02cc0678: b.ls    #0x2cc0808                                 
02cc067c: cmp     w8, #2                                     
02cc0680: b.eq    #0x2cc0808                                 
02cc0684: ldp     s0, s1, [x19, #0x2c]                       
02cc0688: mov     x0, xzr                                    
02cc068c: ldp     s2, s3, [x19, #0x34]                       
02cc0690: ldp     s4, s5, [x19, #0x3c]                       
02cc0694: stp     s10, s11, [sp, #8]                         
02cc0698: stp     s8, s9, [sp]                               
02cc069c: bl      #0x5af1cd4                                 UnityEngine.Debug::DrawLine
02cc06a0: ldr     w8, [x19, #0x18]                           [662f018]=6000014 f=2.40742e-35,0
02cc06a4: cmp     w8, #1                                     
02cc06a8: b.ls    #0x2cc0808                                 
02cc06ac: cmp     w8, #3                                     
02cc06b0: b.ls    #0x2cc0808                                 
02cc06b4: ldp     s1, s2, [x19, #0x30]                       
02cc06b8: mov     x0, xzr                                    
02cc06bc: ldp     s3, s4, [x19, #0x44]                       
02cc06c0: ldr     s0, [x19, #0x2c]                           [662f02c]=0 f=0,0
02cc06c4: ldr     s5, [x19, #0x4c]                           [662f04c]=0 f=0,0
02cc06c8: stp     s10, s11, [sp, #8]                         
02cc06cc: stp     s8, s9, [sp]                               
02cc06d0: bl      #0x5af1cd4                                 UnityEngine.Debug::DrawLine
02cc06d4: ldr     w8, [x19, #0x18]                           [662f018]=6000014 f=2.40742e-35,0
02cc06d8: cmp     w8, #1                                     
02cc06dc: b.ls    #0x2cc0808                                 
02cc06e0: cmp     w8, #4                                     
02cc06e4: b.ls    #0x2cc0808                                 
02cc06e8: ldp     s1, s2, [x19, #0x30]                       
02cc06ec: mov     x0, xzr                                    
02cc06f0: ldp     s3, s4, [x19, #0x50]                       
02cc06f4: ldr     s0, [x19, #0x2c]                           [662f02c]=0 f=0,0
02cc06f8: ldr     s5, [x19, #0x58]                           [662f058]=6000018 f=2.40742e-35,0
02cc06fc: stp     s10, s11, [sp, #8]                         
02cc0700: stp     s8, s9, [sp]                               
02cc0704: bl      #0x5af1cd4                                 UnityEngine.Debug::DrawLine
02cc0708: ldr     w8, [x19, #0x18]                           [662f018]=6000014 f=2.40742e-35,0
02cc070c: cmp     w8, #1                                     
02cc0710: b.ls    #0x2cc0808                                 
02cc0714: cmp     w8, #5                                     
02cc0718: b.ls    #0x2cc0808                                 
02cc071c: ldp     s1, s2, [x19, #0x30]                       
02cc0720: mov     x0, xzr                                    
02cc0724: ldp     s3, s4, [x19, #0x5c]                       
02cc0728: ldr     s0, [x19, #0x2c]                           [662f02c]=0 f=0,0
02cc072c: ldr     s5, [x19, #0x64]                           [662f064]=600001900000000 f=0,2.40742e-35
02cc0730: stp     s10, s11, [sp, #8]                         
02cc0734: stp     s8, s9, [sp]                               
02cc0738: bl      #0x5af1cd4                                 UnityEngine.Debug::DrawLine
02cc073c: ldr     w8, [x19, #0x18]                           [662f018]=6000014 f=2.40742e-35,0
02cc0740: cmp     w8, #4                                     
02cc0744: b.ls    #0x2cc0808                                 
02cc0748: ldp     s0, s1, [x19, #0x50]                       
02cc074c: mov     x0, xzr                                    
02cc0750: ldp     s3, s4, [x19, #0x38]                       
02cc0754: ldr     s2, [x19, #0x58]                           [662f058]=6000018 f=2.40742e-35,0
02cc0758: ldr     s5, [x19, #0x40]                           &2b70700(=14cc750491004000)
02cc075c: stp     s10, s11, [sp, #8]                         
02cc0760: stp     s8, s9, [sp]                               
02cc0764: bl      #0x5af1cd4                                 UnityEngine.Debug::DrawLine
02cc0768: ldr     w8, [x19, #0x18]                           [662f018]=6000014 f=2.40742e-35,0
02cc076c: cmp     w8, #4                                     
02cc0770: b.ls    #0x2cc0808                                 
02cc0774: ldp     s1, s2, [x19, #0x54]                       
02cc0778: mov     x0, xzr                                    
02cc077c: ldp     s3, s4, [x19, #0x44]                       
02cc0780: ldp     s5, s0, [x19, #0x4c]                       
02cc0784: stp     s10, s11, [sp, #8]                         
02cc0788: stp     s8, s9, [sp]                               
02cc078c: bl      #0x5af1cd4                                 UnityEngine.Debug::DrawLine
02cc0790: ldr     w8, [x19, #0x18]                           [662f018]=6000014 f=2.40742e-35,0
02cc0794: cmp     w8, #5                                     
02cc0798: b.ls    #0x2cc0808                                 
02cc079c: ldp     s0, s1, [x19, #0x5c]                       
02cc07a0: mov     x0, xzr                                    
02cc07a4: ldp     s3, s4, [x19, #0x38]                       
02cc07a8: ldr     s2, [x19, #0x64]                           [662f064]=600001900000000 f=0,2.40742e-35
02cc07ac: ldr     s5, [x19, #0x40]                           &2b70700(=14cc750491004000)
02cc07b0: stp     s10, s11, [sp, #8]                         
02cc07b4: stp     s8, s9, [sp]                               
02cc07b8: bl      #0x5af1cd4                                 UnityEngine.Debug::DrawLine
02cc07bc: ldr     w8, [x19, #0x18]                           [662f018]=6000014 f=2.40742e-35,0
02cc07c0: cmp     w8, #5                                     
02cc07c4: b.ls    #0x2cc0808                                 
02cc07c8: ldp     s0, s1, [x19, #0x5c]                       
02cc07cc: mov     x0, xzr                                    
02cc07d0: ldp     s3, s4, [x19, #0x44]                       
02cc07d4: ldr     s2, [x19, #0x64]                           [662f064]=600001900000000 f=0,2.40742e-35
02cc07d8: ldr     s5, [x19, #0x4c]                           [662f04c]=0 f=0,0
02cc07dc: stp     s10, s11, [sp, #8]                         
02cc07e0: stp     s8, s9, [sp]                               
02cc07e4: bl      #0x5af1cd4                                 UnityEngine.Debug::DrawLine
02cc07e8: ldp     x20, x19, [sp, #0x90]                      
02cc07ec: ldp     x30, x21, [sp, #0x80]                      
02cc07f0: ldp     d9, d8, [sp, #0x70]                        
02cc07f4: ldp     d11, d10, [sp, #0x60]                      
02cc07f8: ldp     d13, d12, [sp, #0x50]                      
02cc07fc: ldp     d15, d14, [sp, #0x40]                      
02cc0800: add     sp, sp, #0xa0                              
02cc0804: ret                                                
02cc0808: bl      #0x2b71064                                 fn_2b71064
02cc080c: bl      #0x2b7105c                                 fn_2b7105c
## DrawRay(UnityEngine.Ray ray, float length, UnityEngine.Color color, float duration, bool depthTest) -> void
---- Framework.GizmosDrawer::DrawRay 0x2cc0810
02cc0810: sub     sp, sp, #0x90                              
02cc0814: stp     d15, d14, [sp, #0x30]                      
02cc0818: stp     d13, d12, [sp, #0x40]                      
02cc081c: stp     d11, d10, [sp, #0x50]                      
02cc0820: stp     d9, d8, [sp, #0x60]                        
02cc0824: stp     x30, x21, [sp, #0x70]                      
02cc0828: stp     x20, x19, [sp, #0x80]                      
02cc082c: fmov    s7, s5                                     
02cc0830: fmov    s12, s4                                    
02cc0834: adrp    x21, #0x662f000                            
02cc0838: fmov    s11, s3                                    
02cc083c: fmov    s6, s1                                     
02cc0840: ldrb    w8, [x21, #0xc12]                          
02cc0844: fmov    s13, s0                                    
02cc0848: mov     w19, w1                                    
02cc084c: mov     x20, x0                                    
02cc0850: tbnz    w8, #0, #0x2cc0880                         
02cc0854: adrp    x0, #0x6263000                             
02cc0858: fmov    s8, s6                                     
02cc085c: fmov    s9, s2                                     
02cc0860: ldr     x0, [x0, #0x928]                           T:UnityEngine.Debug
02cc0864: fmov    s10, s7                                    
02cc0868: bl      #0x2b70db0                                 fn_2b70db0
02cc086c: fmov    s7, s10                                    
02cc0870: fmov    s2, s9                                     
02cc0874: mov     w8, #1                                     
02cc0878: fmov    s6, s8                                     
02cc087c: strb    w8, [x21, #0xc12]                          
02cc0880: fmul    s0, s6, s6                                 
02cc0884: fmul    s1, s2, s2                                 
02cc0888: adrp    x8, #0x1084000                             
02cc088c: fadd    s0, s0, s1                                 
02cc0890: fmul    s1, s11, s11                               
02cc0894: fadd    s0, s1, s0                                 
02cc0898: fmul    s1, s12, s12                               
02cc089c: fadd    s0, s1, s0                                 
02cc08a0: ldr     s1, [x8, #0xbd0]                           [1084bd0]=3f6666662edbe6fe f=1e-10,0.9
02cc08a4: adrp    x8, #0x6263000                             
02cc08a8: ldr     x8, [x8, #0x928]                           T:UnityEngine.Debug
02cc08ac: fcmp    s0, s1                                     
02cc08b0: b.pl    #0x2cc08c4                                 
02cc08b4: fmov    s6, #1.00000000                            
02cc08b8: fmov    s2, #1.00000000                            
02cc08bc: fmov    s11, #1.00000000                           
02cc08c0: fmov    s12, #1.00000000                           
02cc08c4: ldr     x0, [x8]                                   &2c5bbd4(=a9bd7bfdd503233f)
02cc08c8: ldp     s0, s15, [x20]                             
02cc08cc: ldp     s10, s8, [x20, #8]                         
02cc08d0: ldp     s9, s14, [x20, #0x10]                      
02cc08d4: ldr     w8, [x0, #0xe4]                            [62630e4]=0 f=0,0
02cc08d8: cbnz    w8, #0x2cc08f0                             
02cc08dc: stp     s2, s6, [sp, #0x28]                        
02cc08e0: stp     s0, s7, [sp, #0x20]                        
02cc08e4: bl      #0x2b70f30                                 fn_2b70f30
02cc08e8: ldp     s0, s7, [sp, #0x20]                        
02cc08ec: ldp     s2, s6, [sp, #0x28]                        
02cc08f0: fmul    s5, s14, s13                               
02cc08f4: fmul    s4, s9, s13                                
02cc08f8: stp     s2, s11, [sp, #4]                          
02cc08fc: fmul    s3, s8, s13                                
02cc0900: fmov    s1, s15                                    
02cc0904: fmov    s2, s10                                    
02cc0908: mov     x1, xzr                                    
02cc090c: and     w0, w19, #1                                
02cc0910: stp     s12, s7, [sp, #0xc]                        
02cc0914: str     s6, [sp]                                   
02cc0918: bl      #0x5af1f00                                 UnityEngine.Debug::DrawRay
02cc091c: ldp     x20, x19, [sp, #0x80]                      
02cc0920: ldp     x30, x21, [sp, #0x70]                      
02cc0924: ldp     d9, d8, [sp, #0x60]                        
02cc0928: ldp     d11, d10, [sp, #0x50]                      
02cc092c: ldp     d13, d12, [sp, #0x40]                      
02cc0930: ldp     d15, d14, [sp, #0x30]                      
02cc0934: add     sp, sp, #0x90                              
02cc0938: ret                                                
## DrawGizmoPoint(UnityEngine.Vector3 position, float size, UnityEngine.Color color) -> void
---- Framework.GizmosDrawer::DrawGizmoPoint 0x2cc093c
02cc093c: stp     d11, d10, [sp, #-0x30]!                    
02cc0940: stp     d9, d8, [sp, #0x10]                        
02cc0944: str     x30, [sp, #0x20]                           
02cc0948: fmov    s8, s3                                     
02cc094c: fmov    s9, s2                                     
02cc0950: mov     x0, xzr                                    
02cc0954: fmov    s10, s1                                    
02cc0958: fmov    s11, s0                                    
02cc095c: fmov    s0, s4                                     
02cc0960: fmov    s1, s5                                     
02cc0964: fmov    s2, s6                                     
02cc0968: fmov    s3, s7                                     
02cc096c: bl      #0x5afa294                                 UnityEngine.Gizmos::set_color
02cc0970: fmov    s2, s9                                     
02cc0974: fmov    s3, s8                                     
02cc0978: ldr     x30, [sp, #0x20]                           
02cc097c: ldp     d9, d8, [sp, #0x10]                        
02cc0980: fmov    s0, s11                                    
02cc0984: fmov    s1, s10                                    
02cc0988: mov     x0, xzr                                    
02cc098c: ldp     d11, d10, [sp], #0x30                      
02cc0990: b       #0x5af9e48                                 UnityEngine.Gizmos::DrawWireSphere
## DrawHandlesBounds(UnityEngine.Bounds bounds, UnityEngine.Color color) -> void
---- Framework.GizmosDrawer::DrawHandlesBounds 0x2cc0994
02cc0994: ret                                                
## DrawSolidRectangle(UnityEngine.Vector3 position, UnityEngine.Vector3 size, UnityEngine.Color borderColor, UnityEngine.Color solidColor) -> void
---- Framework.GizmosDrawer::DrawSolidRectangle 0x2cc0998
02cc0998: ret                                                
## DrawCube(UnityEngine.Vector3 position, UnityEngine.Color color, UnityEngine.Vector3 size) -> void
---- Framework.GizmosDrawer::DrawCube 0x2cc099c
02cc099c: sub     sp, sp, #0x70                              
02cc09a0: stp     d15, d14, [sp, #0x10]                      
02cc09a4: stp     d13, d12, [sp, #0x20]                      
02cc09a8: stp     d11, d10, [sp, #0x30]                      
02cc09ac: stp     d9, d8, [sp, #0x40]                        
02cc09b0: str     x30, [sp, #0x50]                           
02cc09b4: stp     x20, x19, [sp, #0x60]                      
02cc09b8: fmov    s11, s6                                    
02cc09bc: fmov    s10, s5                                    
02cc09c0: stp     s4, s3, [sp, #0x58]                        
02cc09c4: fmov    s15, s2                                    
02cc09c8: fmov    s9, s1                                     
02cc09cc: adrp    x19, #0x662f000                            
02cc09d0: fmov    s8, s0                                     
02cc09d4: adrp    x20, #0x6264000                            
02cc09d8: ldrb    w8, [x19, #0xc13]                          
02cc09dc: ldr     x20, [x20, #0x270]                         T:type24806(k1d)
02cc09e0: tbnz    w8, #0, #0x2cc0a04                         
02cc09e4: adrp    x0, #0x6263000                             
02cc09e8: ldr     x0, [x0, #0x928]                           T:UnityEngine.Debug
02cc09ec: bl      #0x2b70db0                                 fn_2b70db0
02cc09f0: adrp    x0, #0x6264000                             
02cc09f4: ldr     x0, [x0, #0x270]                           T:type24806(k1d)
02cc09f8: bl      #0x2b70db0                                 fn_2b70db0
02cc09fc: mov     w8, #1                                     
02cc0a00: strb    w8, [x19, #0xc13]                          
02cc0a04: ldr     x0, [x20]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02cc0a08: mov     w1, #8                                     
02cc0a0c: bl      #0x2b70ea0                                 fn_2b70ea0
02cc0a10: cbz     x0, #0x2cc0bbc                             
02cc0a14: ldr     w8, [x0, #0x18]                            M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass2_0::<DOSetFloat>b__1
02cc0a18: mov     x19, x0                                    
02cc0a1c: cbz     w8, #0x2cc0bb8                             
02cc0a20: fmov    s1, #0.50000000                            
02cc0a24: ldp     s0, s3, [sp, #0x70]                        
02cc0a28: ldr     s4, [sp, #0x78]                            
02cc0a2c: cmp     w8, #1                                     
02cc0a30: fmul    s2, s0, s1                                 
02cc0a34: fmul    s0, s3, s1                                 
02cc0a38: fmul    s1, s4, s1                                 
02cc0a3c: fadd    s14, s8, s2                                
02cc0a40: fadd    s12, s9, s0                                
02cc0a44: fadd    s13, s15, s1                               
02cc0a48: stp     s14, s12, [x19, #0x20]                     
02cc0a4c: str     s13, [x19, #0x28]                          
02cc0a50: b.eq    #0x2cc0bb8                                 
02cc0a54: fsub    s8, s8, s2                                 
02cc0a58: cmp     w8, #2                                     
02cc0a5c: str     s13, [x19, #0x34]                          
02cc0a60: stp     s8, s12, [x19, #0x2c]                      
02cc0a64: b.ls    #0x2cc0bb8                                 
02cc0a68: fsub    s0, s9, s0                                 
02cc0a6c: cmp     w8, #3                                     
02cc0a70: str     s13, [x19, #0x40]                          
02cc0a74: stp     s8, s0, [x19, #0x38]                       
02cc0a78: b.eq    #0x2cc0bb8                                 
02cc0a7c: cmp     w8, #4                                     
02cc0a80: stp     s14, s0, [x19, #0x44]                      
02cc0a84: str     s13, [x19, #0x4c]                          
02cc0a88: b.ls    #0x2cc0bb8                                 
02cc0a8c: fsub    s1, s15, s1                                
02cc0a90: cmp     w8, #5                                     
02cc0a94: stp     s14, s12, [x19, #0x50]                     
02cc0a98: str     s1, [x19, #0x58]                           
02cc0a9c: b.eq    #0x2cc0bb8                                 
02cc0aa0: ldp     s15, s9, [sp, #0x58]                       
02cc0aa4: cmp     w8, #6                                     
02cc0aa8: stp     s8, s12, [x19, #0x5c]                      
02cc0aac: str     s1, [x19, #0x64]                           
02cc0ab0: b.ls    #0x2cc0bb8                                 
02cc0ab4: cmp     w8, #7                                     
02cc0ab8: stp     s8, s0, [x19, #0x68]                       
02cc0abc: str     s1, [x19, #0x70]                           
02cc0ac0: b.eq    #0x2cc0bb8                                 
02cc0ac4: str     s14, [x19, #0x74]                          
02cc0ac8: adrp    x8, #0x6263000                             
02cc0acc: ldr     x8, [x8, #0x928]                           T:UnityEngine.Debug
02cc0ad0: stp     s0, s1, [x19, #0x78]                       
02cc0ad4: ldr     x0, [x8]                                   &2c5bbd4(=a9bd7bfdd503233f)
02cc0ad8: ldr     w8, [x0, #0xe4]                            [62640e4]=0 f=0,0
02cc0adc: cbnz    w8, #0x2cc0ae4                             
02cc0ae0: bl      #0x2b70f30                                 fn_2b70f30
02cc0ae4: fmov    s0, s14                                    
02cc0ae8: fmov    s1, s12                                    
02cc0aec: mov     x0, xzr                                    
02cc0af0: fmov    s2, s13                                    
02cc0af4: fmov    s3, s8                                     
02cc0af8: stp     s9, s15, [sp]                              
02cc0afc: fmov    s4, s12                                    
02cc0b00: fmov    s5, s13                                    
02cc0b04: stp     s10, s11, [sp, #8]                         
02cc0b08: bl      #0x5af1cd4                                 UnityEngine.Debug::DrawLine
02cc0b0c: ldr     w8, [x19, #0x18]                           [662f018]=6000014 f=2.40742e-35,0
02cc0b10: cmp     w8, #1                                     
02cc0b14: b.ls    #0x2cc0bb8                                 
02cc0b18: cmp     w8, #2                                     
02cc0b1c: b.eq    #0x2cc0bb8                                 
02cc0b20: ldp     s0, s1, [x19, #0x2c]                       
02cc0b24: mov     x0, xzr                                    
02cc0b28: ldp     s2, s3, [x19, #0x34]                       
02cc0b2c: ldp     s4, s5, [x19, #0x3c]                       
02cc0b30: stp     s10, s11, [sp, #8]                         
02cc0b34: stp     s9, s15, [sp]                              
02cc0b38: bl      #0x5af1cd4                                 UnityEngine.Debug::DrawLine
02cc0b3c: ldr     w8, [x19, #0x18]                           [662f018]=6000014 f=2.40742e-35,0
02cc0b40: cmp     w8, #2                                     
02cc0b44: b.ls    #0x2cc0bb8                                 
02cc0b48: cmp     w8, #3                                     
02cc0b4c: b.eq    #0x2cc0bb8                                 
02cc0b50: ldp     s0, s1, [x19, #0x38]                       
02cc0b54: mov     x0, xzr                                    
02cc0b58: ldp     s2, s3, [x19, #0x40]                       
02cc0b5c: ldp     s4, s5, [x19, #0x48]                       
02cc0b60: stp     s10, s11, [sp, #8]                         
02cc0b64: stp     s9, s15, [sp]                              
02cc0b68: bl      #0x5af1cd4                                 UnityEngine.Debug::DrawLine
02cc0b6c: ldr     w8, [x19, #0x18]                           [662f018]=6000014 f=2.40742e-35,0
02cc0b70: tst     w8, #0xfffffffc                            
02cc0b74: b.eq    #0x2cc0bb8                                 
02cc0b78: ldp     s0, s1, [x19, #0x44]                       
02cc0b7c: mov     x0, xzr                                    
02cc0b80: ldp     s3, s4, [x19, #0x20]                       
02cc0b84: ldr     s2, [x19, #0x4c]                           [662f04c]=0 f=0,0
02cc0b88: ldr     s5, [x19, #0x28]                           [662f028]=6000015 f=2.40742e-35,0
02cc0b8c: stp     s10, s11, [sp, #8]                         
02cc0b90: stp     s9, s15, [sp]                              
02cc0b94: bl      #0x5af1cd4                                 UnityEngine.Debug::DrawLine
02cc0b98: ldp     x20, x19, [sp, #0x60]                      
02cc0b9c: ldr     x30, [sp, #0x50]                           
02cc0ba0: ldp     d9, d8, [sp, #0x40]                        
02cc0ba4: ldp     d11, d10, [sp, #0x30]                      
02cc0ba8: ldp     d13, d12, [sp, #0x20]                      
02cc0bac: ldp     d15, d14, [sp, #0x10]                      
02cc0bb0: add     sp, sp, #0x70                              
02cc0bb4: ret                                                
02cc0bb8: bl      #0x2b71064                                 fn_2b71064
02cc0bbc: bl      #0x2b7105c                                 fn_2b7105c
## DrawGizmoCube(UnityEngine.Transform transform, UnityEngine.Vector3 offset, UnityEngine.Vector3 cubeSize, bool wireOnly) -> void
---- Framework.GizmosDrawer::DrawGizmoCube 0x2cc0bc0
02cc0bc0: sub     sp, sp, #0xc0                              
02cc0bc4: stp     d13, d12, [sp, #0x80]                      
02cc0bc8: stp     d11, d10, [sp, #0x90]                      
02cc0bcc: stp     d9, d8, [sp, #0xa0]                        
02cc0bd0: stp     x30, x19, [sp, #0xb0]                      
02cc0bd4: cbz     x0, #0x2cc0c60                             
02cc0bd8: mov     w19, w1                                    
02cc0bdc: add     x8, sp, #0x40                              
02cc0be0: mov     x1, xzr                                    
02cc0be4: fmov    s8, s5                                     
02cc0be8: fmov    s9, s4                                     
02cc0bec: fmov    s10, s3                                    
02cc0bf0: fmov    s11, s2                                    
02cc0bf4: fmov    s12, s1                                    
02cc0bf8: fmov    s13, s0                                    
02cc0bfc: bl      #0x5b463b4                                 UnityEngine.Transform::get_localToWorldMatrix
02cc0c00: ldp     q0, q1, [sp, #0x40]                        
02cc0c04: mov     x0, sp                                     
02cc0c08: mov     x1, xzr                                    
02cc0c0c: stp     q0, q1, [sp]                               
02cc0c10: ldp     q0, q2, [sp, #0x60]                        
02cc0c14: stp     q0, q2, [sp, #0x20]                        
02cc0c18: bl      #0x5afa314                                 UnityEngine.Gizmos::set_matrix
02cc0c1c: fmov    s0, s13                                    
02cc0c20: fmov    s1, s12                                    
02cc0c24: mov     x0, xzr                                    
02cc0c28: fmov    s2, s11                                    
02cc0c2c: fmov    s3, s10                                    
02cc0c30: fmov    s4, s9                                     
02cc0c34: fmov    s5, s8                                     
02cc0c38: tbz     w19, #0, #0x2cc0c44                        
02cc0c3c: bl      #0x5af9f88                                 UnityEngine.Gizmos::DrawWireCube
02cc0c40: b       #0x2cc0c48                                 
02cc0c44: bl      #0x5afa01c                                 UnityEngine.Gizmos::DrawCube
02cc0c48: ldp     x30, x19, [sp, #0xb0]                      
02cc0c4c: ldp     d9, d8, [sp, #0xa0]                        
02cc0c50: ldp     d11, d10, [sp, #0x90]                      
02cc0c54: ldp     d13, d12, [sp, #0x80]                      
02cc0c58: add     sp, sp, #0xc0                              
02cc0c5c: ret                                                
02cc0c60: bl      #0x2b7105c                                 fn_2b7105c
