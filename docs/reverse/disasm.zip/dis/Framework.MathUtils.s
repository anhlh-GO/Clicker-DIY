#### CLASS Framework.MathUtils parent= object
## Remap(float x, float A, float B, float C, float D) -> float
---- Framework.MathUtils::Remap 0x2cc1100
02cc1100: fsub    s2, s2, s1                                 
02cc1104: fsub    s0, s0, s1                                 
02cc1108: fsub    s1, s4, s3                                 
02cc110c: fdiv    s0, s0, s2                                 
02cc1110: fmul    s0, s0, s1                                 
02cc1114: fadd    s0, s0, s3                                 
02cc1118: ret                                                
## ClampAngle(float angle, float minimumAngle, float maximumAngle) -> float
---- Framework.MathUtils::ClampAngle 0x2cc111c
02cc111c: mov     w8, #0x43b40000                            
02cc1120: fmov    s3, w8                                     
02cc1124: mov     w8, #-0x3c4c0000                           
02cc1128: fmov    s5, w8                                     
02cc112c: fadd    s4, s0, s3                                 
02cc1130: fcmp    s0, s5                                     
02cc1134: fcsel   s0, s4, s0, mi                             
02cc1138: fadd    s4, s0, s5                                 
02cc113c: fcmp    s0, s3                                     
02cc1140: fcsel   s0, s4, s0, gt                             
02cc1144: fcmp    s0, s2                                     
02cc1148: fcsel   s2, s2, s0, gt                             
02cc114c: fcmp    s0, s1                                     
02cc1150: fcsel   s0, s1, s2, mi                             
02cc1154: ret                                                
## AngleBetween2D(UnityEngine.Vector2 vectorA, UnityEngine.Vector2 vectorB) -> float
---- Framework.MathUtils::AngleBetween2D 0x2cc1158
02cc1158: str     d12, [sp, #-0x40]!                         
02cc115c: stp     d11, d10, [sp, #0x10]                      
02cc1160: stp     d9, d8, [sp, #0x20]                        
02cc1164: stp     x30, x19, [sp, #0x30]                      
02cc1168: fmov    s9, s3                                     
02cc116c: fmov    s8, s2                                     
02cc1170: adrp    x19, #0x662f000                            
02cc1174: fmov    s10, s1                                    
02cc1178: fmov    s11, s0                                    
02cc117c: ldrb    w8, [x19, #0xca6]                          
02cc1180: cbnz    w8, #0x2cc1198                             
02cc1184: adrp    x0, #0x6265000                             
02cc1188: ldr     x0, [x0, #0xb48]                           T:System.Math
02cc118c: bl      #0x2b70db0                                 fn_2b70db0
02cc1190: mov     w8, #1                                     
02cc1194: strb    w8, [x19, #0xca6]                          
02cc1198: fmul    s0, s11, s11                               
02cc119c: fmul    s1, s10, s10                               
02cc11a0: adrp    x8, #0x1084000                             
02cc11a4: fmul    s2, s8, s8                                 
02cc11a8: fmul    s3, s9, s9                                 
02cc11ac: fadd    s0, s0, s1                                 
02cc11b0: fadd    s1, s2, s3                                 
02cc11b4: fmul    s12, s0, s1                                
02cc11b8: ldr     s1, [x8, #0xdac]                           [1084dac]=3f0888880da24260 f=1e-30,0.533333
02cc11bc: movi    d0, #0000000000000000                      
02cc11c0: fcmp    s12, s1                                    
02cc11c4: b.mi    #0x2cc1224                                 
02cc11c8: adrp    x8, #0x6265000                             
02cc11cc: ldr     x8, [x8, #0xb48]                           T:System.Math
02cc11d0: ldr     x0, [x8]                                   M:AdsManager::<OnApplicationPause>b__26_0
02cc11d4: ldr     w8, [x0, #0xe4]                            [62650e4]=0 f=0,0
02cc11d8: cbnz    w8, #0x2cc11e0                             
02cc11dc: bl      #0x2b70f30                                 fn_2b70f30
02cc11e0: fsqrt   s0, s12                                    
02cc11e4: fmul    s1, s11, s8                                
02cc11e8: fmul    s2, s10, s9                                
02cc11ec: fadd    s1, s1, s2                                 
02cc11f0: fmov    s2, #-1.00000000                           
02cc11f4: fdiv    s0, s1, s0                                 
02cc11f8: fmov    s1, #1.00000000                            
02cc11fc: fcmp    s0, s1                                     
02cc1200: fcsel   s1, s1, s0, gt                             
02cc1204: fcmp    s0, s2                                     
02cc1208: fcsel   s0, s2, s1, mi                             
02cc120c: fcvt    d0, s0                                     
02cc1210: bl      #0x5e90300                                 fn_5e90300
02cc1214: fcvt    s0, d0                                     
02cc1218: adrp    x8, #0x1084000                             
02cc121c: ldr     s1, [x8, #0xdec]                           [1084dec]=3fe6666642652ee1 f=57.2958,1.8
02cc1220: fmul    s0, s0, s1                                 
02cc1224: fmul    s1, s11, s9                                
02cc1228: fmul    s2, s10, s8                                
02cc122c: mov     w8, #0x43b40000                            
02cc1230: ldp     x30, x19, [sp, #0x30]                      
02cc1234: ldp     d9, d8, [sp, #0x20]                        
02cc1238: ldp     d11, d10, [sp, #0x10]                      
02cc123c: fsub    s1, s1, s2                                 
02cc1240: fmov    s2, w8                                     
02cc1244: fsub    s2, s2, s0                                 
02cc1248: fcmp    s1, #0.0                                   
02cc124c: fcsel   s0, s2, s0, gt                             
02cc1250: ldr     d12, [sp], #0x40                           
02cc1254: ret                                                
## DirectionFromAngle(float angle) -> UnityEngine.Vector3
---- Framework.MathUtils::DirectionFromAngle 0x2cc1258
02cc1258: str     d8, [sp, #-0x20]!                          
02cc125c: stp     x30, x19, [sp, #0x10]                      
02cc1260: fmov    s8, s0                                     
02cc1264: adrp    x19, #0x662f000                            
02cc1268: ldrb    w8, [x19, #0x91a]                          
02cc126c: cbnz    w8, #0x2cc1284                             
02cc1270: adrp    x0, #0x6264000                             
02cc1274: ldr     x0, [x0, #0xd8]                            T:UnityEngine.Vector3
02cc1278: bl      #0x2b70db0                                 fn_2b70db0
02cc127c: mov     w8, #1                                     
02cc1280: strb    w8, [x19, #0x91a]                          
02cc1284: adrp    x8, #0x1085000                             
02cc1288: add     x0, sp, #0xc                               
02cc128c: add     x1, sp, #8                                 
02cc1290: ldr     s0, [x8, #0x10]                            [1085010]=4202c6f23c8efa35 f=0.0174533,32.6943
02cc1294: fmul    s0, s8, s0                                 
02cc1298: bl      #0x5e90310                                 fn_5e90310
02cc129c: ldp     s2, s0, [sp, #8]                           
02cc12a0: movi    d1, #0000000000000000                      
02cc12a4: ldp     x30, x19, [sp, #0x10]                      
02cc12a8: ldr     d8, [sp], #0x20                            
02cc12ac: ret                                                
## DirectionFromAngle2D(float angle) -> UnityEngine.Vector3
---- Framework.MathUtils::DirectionFromAngle2D 0x2cc12b0
02cc12b0: str     d8, [sp, #-0x20]!                          
02cc12b4: stp     x30, x19, [sp, #0x10]                      
02cc12b8: fmov    s8, s0                                     
02cc12bc: adrp    x19, #0x662f000                            
02cc12c0: ldrb    w8, [x19, #0x91a]                          
02cc12c4: cbnz    w8, #0x2cc12dc                             
02cc12c8: adrp    x0, #0x6264000                             
02cc12cc: ldr     x0, [x0, #0xd8]                            T:UnityEngine.Vector3
02cc12d0: bl      #0x2b70db0                                 fn_2b70db0
02cc12d4: mov     w8, #1                                     
02cc12d8: strb    w8, [x19, #0x91a]                          
02cc12dc: adrp    x8, #0x1085000                             
02cc12e0: add     x0, sp, #0xc                               
02cc12e4: add     x1, sp, #8                                 
02cc12e8: ldr     s0, [x8, #0x10]                            [1085010]=4202c6f23c8efa35 f=0.0174533,32.6943
02cc12ec: fmul    s0, s8, s0                                 
02cc12f0: bl      #0x5e90310                                 fn_5e90310
02cc12f4: ldp     s0, s1, [sp, #8]                           
02cc12f8: movi    d2, #0000000000000000                      
02cc12fc: ldp     x30, x19, [sp, #0x10]                      
02cc1300: ldr     d8, [sp], #0x20                            
02cc1304: ret                                                
## DistanceBetweenPointAndLine(UnityEngine.Vector3 point, UnityEngine.Vector3 lineStart, UnityEngine.Vector3 lineEnd) -> float
---- Framework.MathUtils::DistanceBetweenPointAndLine 0x2cc1308
02cc1308: sub     sp, sp, #0x50                              
02cc130c: stp     d13, d12, [sp, #0x10]                      
02cc1310: stp     d11, d10, [sp, #0x20]                      
02cc1314: stp     d9, d8, [sp, #0x30]                        
02cc1318: stp     x30, x19, [sp, #0x40]                      
02cc131c: fmov    s9, s1                                     
02cc1320: ldr     s1, [sp, #0x58]                            
02cc1324: ldr     x8, [sp, #0x50]                            
02cc1328: fmov    s8, s2                                     
02cc132c: fmov    s10, s0                                    
02cc1330: str     s1, [sp, #8]                               
02cc1334: str     x8, [sp]                                   
02cc1338: fmov    s1, s9                                     
02cc133c: bl      #0x2cc13c0                                 Framework.MathUtils::ProjectPointOnLine
02cc1340: fmov    s11, s0                                    
02cc1344: fmov    s12, s1                                    
02cc1348: adrp    x19, #0x662f000                            
02cc134c: fmov    s13, s2                                    
02cc1350: ldrb    w8, [x19, #0xca7]                          
02cc1354: cbnz    w8, #0x2cc136c                             
02cc1358: adrp    x0, #0x6265000                             
02cc135c: ldr     x0, [x0, #0xb48]                           T:System.Math
02cc1360: bl      #0x2b70db0                                 fn_2b70db0
02cc1364: mov     w8, #1                                     
02cc1368: strb    w8, [x19, #0xca7]                          
02cc136c: adrp    x8, #0x6265000                             
02cc1370: ldr     x8, [x8, #0xb48]                           T:System.Math
02cc1374: ldr     x0, [x8]                                   M:AdsManager::<OnApplicationPause>b__26_0
02cc1378: ldr     w8, [x0, #0xe4]                            [62650e4]=0 f=0,0
02cc137c: cbnz    w8, #0x2cc1384                             
02cc1380: bl      #0x2b70f30                                 fn_2b70f30
02cc1384: fsub    s0, s12, s9                                
02cc1388: fsub    s1, s11, s10                               
02cc138c: fsub    s2, s13, s8                                
02cc1390: ldp     x30, x19, [sp, #0x40]                      
02cc1394: ldp     d9, d8, [sp, #0x30]                        
02cc1398: ldp     d11, d10, [sp, #0x20]                      
02cc139c: fmul    s1, s1, s1                                 
02cc13a0: fmul    s0, s0, s0                                 
02cc13a4: ldp     d13, d12, [sp, #0x10]                      
02cc13a8: fadd    s0, s1, s0                                 
02cc13ac: fmul    s1, s2, s2                                 
02cc13b0: fadd    s0, s1, s0                                 
02cc13b4: fsqrt   s0, s0                                     
02cc13b8: add     sp, sp, #0x50                              
02cc13bc: ret                                                
## ProjectPointOnLine(UnityEngine.Vector3 point, UnityEngine.Vector3 lineStart, UnityEngine.Vector3 lineEnd) -> UnityEngine.Vector3
---- Framework.MathUtils::ProjectPointOnLine 0x2cc13c0
02cc13c0: sub     sp, sp, #0x60                              
02cc13c4: stp     d15, d14, [sp, #0x10]                      
02cc13c8: stp     d13, d12, [sp, #0x20]                      
02cc13cc: stp     d11, d10, [sp, #0x30]                      
02cc13d0: stp     d9, d8, [sp, #0x40]                        
02cc13d4: stp     x30, x19, [sp, #0x50]                      
02cc13d8: fmov    s8, s5                                     
02cc13dc: fmov    s9, s4                                     
02cc13e0: adrp    x19, #0x662f000                            
02cc13e4: fmov    s10, s3                                    
02cc13e8: fmov    s12, s2                                    
02cc13ec: ldrb    w8, [x19, #0xca7]                          
02cc13f0: fmov    s13, s1                                    
02cc13f4: ldp     s15, s14, [sp, #0x64]                      
02cc13f8: ldr     s11, [sp, #0x60]                           
02cc13fc: cbnz    w8, #0x2cc141c                             
02cc1400: adrp    x0, #0x6265000                             
02cc1404: ldr     x0, [x0, #0xb48]                           T:System.Math
02cc1408: str     s0, [sp, #0xc]                             
02cc140c: bl      #0x2b70db0                                 fn_2b70db0
02cc1410: ldr     s0, [sp, #0xc]                             
02cc1414: mov     w8, #1                                     
02cc1418: strb    w8, [x19, #0xca7]                          
02cc141c: adrp    x8, #0x6265000                             
02cc1420: fsub    s11, s11, s10                              
02cc1424: fsub    s15, s15, s9                               
02cc1428: ldr     x8, [x8, #0xb48]                           T:System.Math
02cc142c: fsub    s14, s14, s8                               
02cc1430: ldr     x0, [x8]                                   M:AdsManager::<OnApplicationPause>b__26_0
02cc1434: ldr     w8, [x0, #0xe4]                            [62650e4]=0 f=0,0
02cc1438: cbnz    w8, #0x2cc1448                             
02cc143c: str     s0, [sp, #0xc]                             
02cc1440: bl      #0x2b70f30                                 fn_2b70f30
02cc1444: ldr     s0, [sp, #0xc]                             
02cc1448: fmul    s4, s11, s11                               
02cc144c: fmul    s3, s15, s15                               
02cc1450: adrp    x8, #0x1084000                             
02cc1454: fadd    s4, s4, s3                                 
02cc1458: fmul    s3, s14, s14                               
02cc145c: fadd    s3, s3, s4                                 
02cc1460: fsqrt   s5, s3                                     
02cc1464: ldr     s3, [x8, #0xf70]                           [1084f70]=bf745d17358637bd f=1e-06,-0.954545
02cc1468: fcmp    s5, s3                                     
02cc146c: b.le    #0x2cc147c                                 
02cc1470: fdiv    s11, s11, s5                               
02cc1474: fdiv    s15, s15, s5                               
02cc1478: fdiv    s14, s14, s5                               
02cc147c: fsub    s1, s13, s9                                
02cc1480: fsub    s4, s0, s10                                
02cc1484: fsub    s3, s12, s8                                
02cc1488: ldp     x30, x19, [sp, #0x50]                      
02cc148c: ldp     d13, d12, [sp, #0x20]                      
02cc1490: fmul    s2, s4, s11                                
02cc1494: fmul    s1, s1, s15                                
02cc1498: fmul    s3, s3, s14                                
02cc149c: fadd    s1, s1, s2                                 
02cc14a0: movi    d2, #0000000000000000                      
02cc14a4: fadd    s1, s3, s1                                 
02cc14a8: fcmp    s1, s5                                     
02cc14ac: fcsel   s0, s5, s1, gt                             
02cc14b0: fcmp    s1, #0.0                                   
02cc14b4: fcsel   s0, s2, s0, mi                             
02cc14b8: fmul    s1, s11, s0                                
02cc14bc: fmul    s2, s15, s0                                
02cc14c0: fmul    s3, s14, s0                                
02cc14c4: ldp     d15, d14, [sp, #0x10]                      
02cc14c8: fadd    s0, s10, s1                                
02cc14cc: fadd    s1, s9, s2                                 
02cc14d0: fadd    s2, s8, s3                                 
02cc14d4: ldp     d9, d8, [sp, #0x40]                        
02cc14d8: ldp     d11, d10, [sp, #0x30]                      
02cc14dc: add     sp, sp, #0x60                              
02cc14e0: ret                                                
## NormalizeFloat(float value, int fractNum) -> float
---- Framework.MathUtils::NormalizeFloat 0x2cc14e4
02cc14e4: str     d10, [sp, #-0x30]!                         
02cc14e8: stp     d9, d8, [sp, #0x10]                        
02cc14ec: stp     x30, x19, [sp, #0x20]                      
02cc14f0: scvtf   s1, w0                                     
02cc14f4: fmov    s9, s0                                     
02cc14f8: fmov    s0, #10.00000000                           
02cc14fc: bl      #0x5e90320                                 fn_5e90320
02cc1500: fmov    s8, s0                                     
02cc1504: adrp    x19, #0x662f000                            
02cc1508: ldrb    w8, [x19, #0xa8a]                          
02cc150c: cbnz    w8, #0x2cc1524                             
02cc1510: adrp    x0, #0x6265000                             
02cc1514: ldr     x0, [x0, #0xb48]                           T:System.Math
02cc1518: bl      #0x2b70db0                                 fn_2b70db0
02cc151c: mov     w8, #1                                     
02cc1520: strb    w8, [x19, #0xa8a]                          
02cc1524: adrp    x8, #0x6265000                             
02cc1528: fmul    s10, s8, s9                                
02cc152c: ldr     x8, [x8, #0xb48]                           T:System.Math
02cc1530: ldr     x0, [x8]                                   M:AdsManager::<OnApplicationPause>b__26_0
02cc1534: ldr     w8, [x0, #0xe4]                            [62650e4]=0 f=0,0
02cc1538: cbnz    w8, #0x2cc1540                             
02cc153c: bl      #0x2b70f30                                 fn_2b70f30
02cc1540: fcvt    d9, s10                                    
02cc1544: add     x0, sp, #8                                 
02cc1548: fmov    d0, d9                                     
02cc154c: bl      #0x5e902c0                                 fn_5e902c0
02cc1550: fcmp    s10, #0.0                                  
02cc1554: b.ge    #0x2cc1570                                 
02cc1558: fmov    d1, #-0.50000000                           
02cc155c: fcmp    d0, d1                                     
02cc1560: b.ne    #0x2cc1598                                 
02cc1564: ldr     d0, [sp, #8]                               
02cc1568: fmov    d1, #-1.00000000                           
02cc156c: b       #0x2cc1584                                 
02cc1570: fmov    d1, #0.50000000                            
02cc1574: fcmp    d0, d1                                     
02cc1578: b.ne    #0x2cc15a4                                 
02cc157c: fmov    d1, #1.00000000                            
02cc1580: ldr     d0, [sp, #8]                               
02cc1584: fcvtzs  x8, d0                                     
02cc1588: fadd    d1, d0, d1                                 
02cc158c: tst     x8, #1                                     
02cc1590: fcsel   d0, d0, d1, eq                             
02cc1594: b       #0x2cc15ac                                 
02cc1598: fadd    d0, d9, d1                                 
02cc159c: frintp  d0, d0                                     
02cc15a0: b       #0x2cc15ac                                 
02cc15a4: fadd    d0, d9, d1                                 
02cc15a8: frintm  d0, d0                                     
02cc15ac: fcvtzs  w8, d0                                     
02cc15b0: mov     x9, #0x7ff0000000000000                    
02cc15b4: movi    v3.2s, #0xcf, lsl #24                      
02cc15b8: fmov    d2, x9                                     
02cc15bc: ldp     x30, x19, [sp, #0x20]                      
02cc15c0: scvtf   s1, w8                                     
02cc15c4: fcmp    d0, d2                                     
02cc15c8: fcsel   s0, s3, s1, eq                             
02cc15cc: fdiv    s0, s0, s8                                 
02cc15d0: ldp     d9, d8, [sp, #0x10]                        
02cc15d4: ldr     d10, [sp], #0x30                           
02cc15d8: ret                                                
## GetAngle(UnityEngine.Vector3 start, UnityEngine.Vector3 end) -> float
---- Framework.MathUtils::GetAngle 0x2cc15dc
02cc15dc: str     x30, [sp, #-0x10]!                         
02cc15e0: fsub    s2, s2, s5                                 
02cc15e4: fsub    s1, s0, s3                                 
02cc15e8: fmov    s0, s2                                     
02cc15ec: bl      #0x5e902f0                                 fn_5e902f0
02cc15f0: adrp    x8, #0x1084000                             
02cc15f4: ldr     s1, [x8, #0xdec]                           [1084dec]=3fe6666642652ee1 f=57.2958,1.8
02cc15f8: fmul    s0, s0, s1                                 
02cc15fc: ldr     x30, [sp], #0x10                           
02cc1600: ret                                                
## GetAngle(UnityEngine.Vector2 start, UnityEngine.Vector2 end) -> float
---- Framework.MathUtils::GetAngle 0x2cc1604
02cc1604: str     x30, [sp, #-0x10]!                         
02cc1608: fsub    s3, s1, s3                                 
02cc160c: fsub    s1, s0, s2                                 
02cc1610: fmov    s0, s3                                     
02cc1614: bl      #0x5e902f0                                 fn_5e902f0
02cc1618: adrp    x8, #0x1084000                             
02cc161c: ldr     s1, [x8, #0xdec]                           [1084dec]=3fe6666642652ee1 f=57.2958,1.8
02cc1620: fmul    s0, s0, s1                                 
02cc1624: ldr     x30, [sp], #0x10                           
02cc1628: ret                                                
