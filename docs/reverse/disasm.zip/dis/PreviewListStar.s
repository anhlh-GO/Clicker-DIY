#### CLASS PreviewListStar/<>c parent= object
#   field <>9                            PreviewListStar/<>c                                off=0x0 attr=36 
#   field <>9__10_0                      System.Predicate`1<UnityEngine.SpriteRenderer>     off=0x8 attr=16 
## .cctor() -> void
---- PreviewListStar/<>c::.cctor 0x2cd5c20
02cd5c20: str     x30, [sp, #-0x20]!                         
02cd5c24: stp     x20, x19, [sp, #0x10]                      
02cd5c28: adrp    x19, #0x662f000                            
02cd5c2c: adrp    x20, #0x6267000                            
02cd5c30: ldrb    w8, [x19, #0xd23]                          
02cd5c34: ldr     x20, [x20, #0x8c8]                         T:PreviewListStar/<>c
02cd5c38: tbnz    w8, #0, #0x2cd5c50                         
02cd5c3c: adrp    x0, #0x6267000                             
02cd5c40: ldr     x0, [x0, #0x8c8]                           T:PreviewListStar/<>c
02cd5c44: bl      #0x2b70db0                                 fn_2b70db0
02cd5c48: mov     w8, #1                                     
02cd5c4c: strb    w8, [x19, #0xd23]                          
02cd5c50: ldr     x0, [x20]                                  S:'didu'
02cd5c54: bl      #0x2b7104c                                 fn_2b7104c
02cd5c58: mov     x1, xzr                                    
02cd5c5c: mov     x19, x0                                    
02cd5c60: bl      #0x4e53e9c                                 System.Object::.ctor
02cd5c64: ldr     x8, [x20]                                  S:'didu'
02cd5c68: mov     x1, x19                                    
02cd5c6c: ldr     x8, [x8, #0xb8]                            
02cd5c70: str     x19, [x8]                                  
02cd5c74: ldr     x8, [x20]                                  S:'didu'
02cd5c78: ldp     x20, x19, [sp, #0x10]                      
02cd5c7c: ldr     x0, [x8, #0xb8]                            
02cd5c80: ldr     x30, [sp], #0x20                           
02cd5c84: b       #0x2b70d54                                 
## .ctor() -> void
---- PreviewListStar/<>c::.ctor 0x2cd5c88
02cd5c88: mov     x1, xzr                                    
02cd5c8c: b       #0x4e53e9c                                 System.Object::.ctor
## <ShowPreviewAnim>b__10_0(UnityEngine.SpriteRenderer x) -> bool
---- PreviewListStar/<>c::<ShowPreviewAnim>b__10_0 0x2cd5c90
02cd5c90: str     x30, [sp, #-0x10]!                         
02cd5c94: cbz     x1, #0x2cd5cb4                             
02cd5c98: mov     x0, x1                                     
02cd5c9c: mov     x1, xzr                                    
02cd5ca0: bl      #0x5b339ec                                 UnityEngine.Component::get_gameObject
02cd5ca4: cbz     x0, #0x2cd5cb4                             
02cd5ca8: mov     x1, xzr                                    
02cd5cac: ldr     x30, [sp], #0x10                           
02cd5cb0: b       #0x5b36bfc                                 UnityEngine.GameObject::get_activeSelf
02cd5cb4: bl      #0x2b7105c                                 fn_2b7105c
#### CLASS PreviewListStar/<>c__DisplayClass10_0 parent= object
#   field <>4__this                      PreviewListStar                                    off=0x10 attr=6 
#   field inputSprite                    System.Collections.Generic.List`1<UnityEngine.SpriteRenderer> off=0x18 attr=6 
#   field onHalfTimeEvent                System.Action                                      off=0x20 attr=6 
#   field onComplete                     System.Action                                      off=0x28 attr=6 
## .ctor() -> void
---- PreviewListStar/<>c__DisplayClass10_0::.ctor 0x2cd5c08
02cd5c08: mov     x1, xzr                                    
02cd5c0c: b       #0x4e53e9c                                 System.Object::.ctor
## <ShowPreviewAnim>b__1() -> void
---- PreviewListStar/<>c__DisplayClass10_0::<ShowPreviewAnim>b__1 0x2cd5cb8
02cd5cb8: ldr     x8, [x0, #0x20]                            .onHalfTimeEvent
02cd5cbc: cbz     x8, #0x2cd5cd0                             
02cd5cc0: ldr     x0, [x8, #0x40]                            
02cd5cc4: ldr     x1, [x8, #0x28]                            
02cd5cc8: ldr     x2, [x8, #0x18]                            
02cd5ccc: br      x2                                         
02cd5cd0: ret                                                
## <ShowPreviewAnim>b__2() -> void
---- PreviewListStar/<>c__DisplayClass10_0::<ShowPreviewAnim>b__2 0x2cd5cd4
02cd5cd4: stp     x30, x19, [sp, #-0x10]!                    
02cd5cd8: ldr     x8, [x0, #0x10]                            .<>4__this
02cd5cdc: cbz     x8, #0x2cd5d1c                             
02cd5ce0: mov     x19, x0                                    
02cd5ce4: ldr     x0, [x8, #0x20]                            
02cd5ce8: cbz     x0, #0x2cd5d1c                             
02cd5cec: mov     w1, wzr                                    
02cd5cf0: mov     x2, xzr                                    
02cd5cf4: bl      #0x5e45408                                 UnityEngine.CanvasGroup::set_blocksRaycasts
02cd5cf8: ldr     x8, [x19, #0x28]                           .onComplete
02cd5cfc: cbz     x8, #0x2cd5d14                             
02cd5d00: ldr     x0, [x8, #0x40]                            
02cd5d04: ldr     x1, [x8, #0x28]                            
02cd5d08: ldr     x2, [x8, #0x18]                            
02cd5d0c: ldp     x30, x19, [sp], #0x10                      
02cd5d10: br      x2                                         
02cd5d14: ldp     x30, x19, [sp], #0x10                      
02cd5d18: ret                                                
02cd5d1c: bl      #0x2b7105c                                 fn_2b7105c
#### CLASS PreviewListStar/<>c__DisplayClass10_1 parent= object
#   field index                          int                                                off=0x10 attr=6 
#   field CS$<>8__locals1                PreviewListStar/<>c__DisplayClass10_0              off=0x18 attr=6 
#   field <>9__4                         DG.Tweening.TweenCallback                          off=0x20 attr=6 
#   field <>9__6                         DG.Tweening.TweenCallback                          off=0x28 attr=6 
#   field <>9__5                         DG.Tweening.TweenCallback                          off=0x30 attr=6 
## .ctor() -> void
---- PreviewListStar/<>c__DisplayClass10_1::.ctor 0x2cd5c10
02cd5c10: mov     x1, xzr                                    
02cd5c14: b       #0x4e53e9c                                 System.Object::.ctor
## <ShowPreviewAnim>b__3() -> void
---- PreviewListStar/<>c__DisplayClass10_1::<ShowPreviewAnim>b__3 0x2cd5d20
02cd5d20: str     d8, [sp, #-0x40]!                          
02cd5d24: str     x30, [sp, #8]                              
02cd5d28: stp     x24, x23, [sp, #0x10]                      
02cd5d2c: stp     x22, x21, [sp, #0x20]                      
02cd5d30: stp     x20, x19, [sp, #0x30]                      
02cd5d34: adrp    x20, #0x662f000                            
02cd5d38: mov     x19, x0                                    
02cd5d3c: ldrb    w8, [x20, #0xd24]                          
02cd5d40: tbnz    w8, #0, #0x2cd5db8                         
02cd5d44: adrp    x0, #0x6267000                             
02cd5d48: ldr     x0, [x0, #0x880]                           MS:System.Collections.Generic.List`1::get_Item
02cd5d4c: bl      #0x2b70db0                                 fn_2b70db0
02cd5d50: adrp    x0, #0x6267000                             
02cd5d54: ldr     x0, [x0, #0x890]                           MS:System.Collections.Generic.List`1::get_Item
02cd5d58: bl      #0x2b70db0                                 fn_2b70db0
02cd5d5c: adrp    x0, #0x6264000                             
02cd5d60: ldr     x0, [x0, #0xe8]                            T:DG.Tweening.TweenCallback
02cd5d64: bl      #0x2b70db0                                 fn_2b70db0
02cd5d68: adrp    x0, #0x6266000                             
02cd5d6c: ldr     x0, [x0, #0xa08]                           MS:DG.Tweening.TweenSettingsExtensions::OnComplete
02cd5d70: bl      #0x2b70db0                                 fn_2b70db0
02cd5d74: adrp    x0, #0x6267000                             
02cd5d78: ldr     x0, [x0, #0x8d8]                           MS:DG.Tweening.TweenSettingsExtensions::OnStart
02cd5d7c: bl      #0x2b70db0                                 fn_2b70db0
02cd5d80: adrp    x0, #0x6266000                             
02cd5d84: ldr     x0, [x0, #0xa10]                           MS:DG.Tweening.TweenSettingsExtensions::SetDelay
02cd5d88: bl      #0x2b70db0                                 fn_2b70db0
02cd5d8c: adrp    x0, #0x6266000                             
02cd5d90: ldr     x0, [x0, #0xe08]                           MS:DG.Tweening.TweenSettingsExtensions::SetDelay
02cd5d94: bl      #0x2b70db0                                 fn_2b70db0
02cd5d98: adrp    x0, #0x6267000                             
02cd5d9c: ldr     x0, [x0, #0x8e0]                           M:PreviewListStar/<>c__DisplayClass10_1::<ShowPreviewAnim>b__4
02cd5da0: bl      #0x2b70db0                                 fn_2b70db0
02cd5da4: adrp    x0, #0x6267000                             
02cd5da8: ldr     x0, [x0, #0x8e8]                           M:PreviewListStar/<>c__DisplayClass10_1::<ShowPreviewAnim>b__5
02cd5dac: bl      #0x2b70db0                                 fn_2b70db0
02cd5db0: mov     w8, #1                                     
02cd5db4: strb    w8, [x20, #0xd24]                          
02cd5db8: ldr     x8, [x19, #0x18]                           .CS$<>8__locals1
02cd5dbc: cbz     x8, #0x2cd5fa0                             
02cd5dc0: ldr     x8, [x8, #0x10]                            
02cd5dc4: cbz     x8, #0x2cd5fa0                             
02cd5dc8: ldr     x0, [x8, #0x38]                            
02cd5dcc: cbz     x0, #0x2cd5fa0                             
02cd5dd0: adrp    x23, #0x6267000                            
02cd5dd4: ldr     x23, [x23, #0x880]                         MS:System.Collections.Generic.List`1::get_Item
02cd5dd8: ldr     w1, [x19, #0x10]                           .index
02cd5ddc: ldr     x2, [x23]                                  S:'didu'
02cd5de0: bl      #0x35a8f3c                                 fn_35a8f3c
02cd5de4: cbz     x0, #0x2cd5fa0                             
02cd5de8: adrp    x20, #0x6266000                            
02cd5dec: adrp    x24, #0x6267000                            
02cd5df0: mov     x1, xzr                                    
02cd5df4: ldr     x20, [x20, #0xe08]                         MS:DG.Tweening.TweenSettingsExtensions::SetDelay
02cd5df8: ldr     x24, [x24, #0x8d8]                         MS:DG.Tweening.TweenSettingsExtensions::OnStart
02cd5dfc: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02cd5e00: adrp    x8, #0x1084000                             
02cd5e04: fmov    s0, #1.00000000                            
02cd5e08: mov     x1, xzr                                    
02cd5e0c: ldr     s1, [x8, #0xf10]                           [1084f10]=4110bc863e99999a f=0.3,9.04603
02cd5e10: bl      #0x2d98c98                                 DG.Tweening.ShortcutExtensions::DOScale
02cd5e14: ldr     s0, [x19, #0x10]                           .index
02cd5e18: adrp    x8, #0x1084000                             
02cd5e1c: ldr     x1, [x20]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cd5e20: ldr     s8, [x8, #0xdfc]                           [1084dfc]=3f2666663d4ccccd f=0.05,0.65
02cd5e24: scvtf   s0, s0                                     
02cd5e28: fmul    s0, s0, s8                                 
02cd5e2c: bl      #0x336f7fc                                 fn_336f7fc
02cd5e30: mov     x21, x19                                   
02cd5e34: mov     x20, x0                                    
02cd5e38: ldr     x22, [x21, #0x20]!                         .<>9__4
02cd5e3c: cbnz    x22, #0x2cd5e7c                            
02cd5e40: adrp    x8, #0x6264000                             
02cd5e44: ldr     x8, [x8, #0xe8]                            T:DG.Tweening.TweenCallback
02cd5e48: ldr     x0, [x8]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02cd5e4c: bl      #0x2b7104c                                 fn_2b7104c
02cd5e50: adrp    x8, #0x6267000                             
02cd5e54: mov     x1, x19                                    
02cd5e58: mov     x3, xzr                                    
02cd5e5c: ldr     x8, [x8, #0x8e0]                           M:PreviewListStar/<>c__DisplayClass10_1::<ShowPreviewAnim>b__4
02cd5e60: mov     x22, x0                                    
02cd5e64: ldr     x2, [x8]                                   S:'didu'
02cd5e68: bl      #0x2d89dc4                                 DG.Tweening.TweenCallback::.ctor
02cd5e6c: mov     x0, x21                                    
02cd5e70: mov     x1, x22                                    
02cd5e74: str     x22, [x19, #0x20]                          .<>9__4
02cd5e78: bl      #0x2b70d54                                 fn_2b70d54
02cd5e7c: ldr     x2, [x24]                                  S:'didu'
02cd5e80: mov     x0, x20                                    
02cd5e84: mov     x1, x22                                    
02cd5e88: bl      #0x336f348                                 fn_336f348
02cd5e8c: ldr     x8, [x19, #0x18]                           .CS$<>8__locals1
02cd5e90: cbz     x8, #0x2cd5fa0                             
02cd5e94: ldr     x8, [x8, #0x10]                            S:'startActivity'
02cd5e98: cbz     x8, #0x2cd5fa0                             
02cd5e9c: ldr     x0, [x8, #0x38]                            MS:System.Nullable`1::get_Value
02cd5ea0: cbz     x0, #0x2cd5fa0                             
02cd5ea4: ldr     w1, [x19, #0x10]                           .index
02cd5ea8: ldr     x2, [x23]                                  S:'didu'
02cd5eac: bl      #0x35a8f3c                                 fn_35a8f3c
02cd5eb0: cbz     x0, #0x2cd5fa0                             
02cd5eb4: mov     x1, xzr                                    
02cd5eb8: bl      #0x5c4e1ac                                 UnityEngine.UI.Graphic::get_rectTransform
02cd5ebc: ldr     x8, [x19, #0x18]                           .CS$<>8__locals1
02cd5ec0: cbz     x8, #0x2cd5fa0                             
02cd5ec4: ldr     x21, [x8, #0x10]                           S:'startActivity'
02cd5ec8: cbz     x21, #0x2cd5fa0                            
02cd5ecc: mov     x20, x0                                    
02cd5ed0: ldr     x0, [x21, #0x30]                           .<>9__5
02cd5ed4: cbz     x0, #0x2cd5fa0                             
02cd5ed8: adrp    x8, #0x6267000                             
02cd5edc: adrp    x22, #0x6266000                            
02cd5ee0: adrp    x23, #0x6266000                            
02cd5ee4: ldr     x8, [x8, #0x890]                           MS:System.Collections.Generic.List`1::get_Item
02cd5ee8: ldr     x22, [x22, #0xa10]                         MS:DG.Tweening.TweenSettingsExtensions::SetDelay
02cd5eec: ldr     x23, [x23, #0xa08]                         MS:DG.Tweening.TweenSettingsExtensions::OnComplete
02cd5ef0: ldr     w1, [x19, #0x10]                           .index
02cd5ef4: ldr     x2, [x8]                                   S:'didu'
02cd5ef8: bl      #0x35a8f3c                                 fn_35a8f3c
02cd5efc: mov     x1, x0                                     
02cd5f00: mov     x0, x21                                    
02cd5f04: bl      #0x2cd52f0                                 PreviewListStar::GetAnchoredPositionInCanvas
02cd5f08: fmov    s2, #0.50000000                            
02cd5f0c: mov     x0, x20                                    
02cd5f10: mov     w1, wzr                                    
02cd5f14: mov     x2, xzr                                    
02cd5f18: bl      #0x2c798bc                                 DG.Tweening.DOTweenModuleUI::DOAnchorPos
02cd5f1c: ldr     s0, [x19, #0x10]                           .index
02cd5f20: ldr     x1, [x22]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cd5f24: scvtf   s0, s0                                     
02cd5f28: fmul    s0, s0, s8                                 
02cd5f2c: bl      #0x336f7fc                                 fn_336f7fc
02cd5f30: mov     x21, x19                                   
02cd5f34: mov     x20, x0                                    
02cd5f38: ldr     x22, [x21, #0x30]!                         .<>9__5
02cd5f3c: cbnz    x22, #0x2cd5f7c                            
02cd5f40: adrp    x8, #0x6264000                             
02cd5f44: ldr     x8, [x8, #0xe8]                            T:DG.Tweening.TweenCallback
02cd5f48: ldr     x0, [x8]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02cd5f4c: bl      #0x2b7104c                                 fn_2b7104c
02cd5f50: adrp    x8, #0x6267000                             
02cd5f54: mov     x1, x19                                    
02cd5f58: mov     x3, xzr                                    
02cd5f5c: ldr     x8, [x8, #0x8e8]                           M:PreviewListStar/<>c__DisplayClass10_1::<ShowPreviewAnim>b__5
02cd5f60: mov     x22, x0                                    
02cd5f64: ldr     x2, [x8]                                   S:'didu'
02cd5f68: bl      #0x2d89dc4                                 DG.Tweening.TweenCallback::.ctor
02cd5f6c: mov     x0, x21                                    
02cd5f70: mov     x1, x22                                    
02cd5f74: str     x22, [x19, #0x30]                          .<>9__5
02cd5f78: bl      #0x2b70d54                                 fn_2b70d54
02cd5f7c: ldr     x2, [x23]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cd5f80: mov     x0, x20                                    
02cd5f84: mov     x1, x22                                    
02cd5f88: ldp     x20, x19, [sp, #0x30]                      
02cd5f8c: ldr     x30, [sp, #8]                              
02cd5f90: ldp     x22, x21, [sp, #0x20]                      
02cd5f94: ldp     x24, x23, [sp, #0x10]                      
02cd5f98: ldr     d8, [sp], #0x40                            
02cd5f9c: b       #0x336f26c                                 
02cd5fa0: bl      #0x2b7105c                                 fn_2b7105c
## <ShowPreviewAnim>b__4() -> void
---- PreviewListStar/<>c__DisplayClass10_1::<ShowPreviewAnim>b__4 0x2cd5fa4
02cd5fa4: str     x30, [sp, #-0x20]!                         
02cd5fa8: stp     x20, x19, [sp, #0x10]                      
02cd5fac: adrp    x20, #0x662f000                            
02cd5fb0: mov     x19, x0                                    
02cd5fb4: ldrb    w8, [x20, #0xd25]                          
02cd5fb8: tbnz    w8, #0, #0x2cd5fd0                         
02cd5fbc: adrp    x0, #0x6267000                             
02cd5fc0: ldr     x0, [x0, #0x888]                           MS:System.Collections.Generic.List`1::get_Item
02cd5fc4: bl      #0x2b70db0                                 fn_2b70db0
02cd5fc8: mov     w8, #1                                     
02cd5fcc: strb    w8, [x20, #0xd25]                          
02cd5fd0: ldr     x8, [x19, #0x18]                           .CS$<>8__locals1
02cd5fd4: cbz     x8, #0x2cd6018                             
02cd5fd8: ldr     x0, [x8, #0x18]                            
02cd5fdc: cbz     x0, #0x2cd6018                             
02cd5fe0: adrp    x8, #0x6267000                             
02cd5fe4: ldr     x8, [x8, #0x888]                           MS:System.Collections.Generic.List`1::get_Item
02cd5fe8: ldr     w1, [x19, #0x10]                           .index
02cd5fec: ldr     x2, [x8]                                   S:'didu'
02cd5ff0: bl      #0x35a8f3c                                 fn_35a8f3c
02cd5ff4: cbz     x0, #0x2cd6018                             
02cd5ff8: mov     x1, xzr                                    
02cd5ffc: bl      #0x5b339ec                                 UnityEngine.Component::get_gameObject
02cd6000: cbz     x0, #0x2cd6018                             
02cd6004: ldp     x20, x19, [sp, #0x10]                      
02cd6008: mov     w1, wzr                                    
02cd600c: mov     x2, xzr                                    
02cd6010: ldr     x30, [sp], #0x20                           
02cd6014: b       #0x5b36b38                                 UnityEngine.GameObject::SetActive
02cd6018: bl      #0x2b7105c                                 fn_2b7105c
## <ShowPreviewAnim>b__5() -> void
---- PreviewListStar/<>c__DisplayClass10_1::<ShowPreviewAnim>b__5 0x2cd601c
02cd601c: stp     x30, x23, [sp, #-0x30]!                    
02cd6020: stp     x22, x21, [sp, #0x10]                      
02cd6024: stp     x20, x19, [sp, #0x20]                      
02cd6028: adrp    x20, #0x662f000                            
02cd602c: mov     x19, x0                                    
02cd6030: ldrb    w8, [x20, #0xd26]                          
02cd6034: tbnz    w8, #0, #0x2cd6088                         
02cd6038: adrp    x0, #0x6267000                             
02cd603c: ldr     x0, [x0, #0x880]                           MS:System.Collections.Generic.List`1::get_Item
02cd6040: bl      #0x2b70db0                                 fn_2b70db0
02cd6044: adrp    x0, #0x6264000                             
02cd6048: ldr     x0, [x0, #0xe8]                            T:DG.Tweening.TweenCallback
02cd604c: bl      #0x2b70db0                                 fn_2b70db0
02cd6050: adrp    x0, #0x6266000                             
02cd6054: ldr     x0, [x0, #0x928]                           MS:DG.Tweening.TweenSettingsExtensions::OnComplete
02cd6058: bl      #0x2b70db0                                 fn_2b70db0
02cd605c: adrp    x0, #0x6266000                             
02cd6060: ldr     x0, [x0, #0xe08]                           MS:DG.Tweening.TweenSettingsExtensions::SetDelay
02cd6064: bl      #0x2b70db0                                 fn_2b70db0
02cd6068: adrp    x0, #0x6266000                             
02cd606c: ldr     x0, [x0, #0x880]                           MS:DG.Tweening.TweenSettingsExtensions::SetEase
02cd6070: bl      #0x2b70db0                                 fn_2b70db0
02cd6074: adrp    x0, #0x6267000                             
02cd6078: ldr     x0, [x0, #0x8f0]                           M:PreviewListStar/<>c__DisplayClass10_1::<ShowPreviewAnim>b__6
02cd607c: bl      #0x2b70db0                                 fn_2b70db0
02cd6080: mov     w8, #1                                     
02cd6084: strb    w8, [x20, #0xd26]                          
02cd6088: ldr     x8, [x19, #0x18]                           .CS$<>8__locals1
02cd608c: cbz     x8, #0x2cd6168                             
02cd6090: ldr     x8, [x8, #0x10]                            
02cd6094: cbz     x8, #0x2cd6168                             
02cd6098: ldr     x0, [x8, #0x38]                            
02cd609c: cbz     x0, #0x2cd6168                             
02cd60a0: adrp    x8, #0x6267000                             
02cd60a4: ldr     x8, [x8, #0x880]                           MS:System.Collections.Generic.List`1::get_Item
02cd60a8: ldr     w1, [x19, #0x10]                           .index
02cd60ac: ldr     x2, [x8]                                   S:'didu'
02cd60b0: bl      #0x35a8f3c                                 fn_35a8f3c
02cd60b4: cbz     x0, #0x2cd6168                             
02cd60b8: adrp    x20, #0x6266000                            
02cd60bc: adrp    x21, #0x6266000                            
02cd60c0: adrp    x23, #0x6266000                            
02cd60c4: ldr     x20, [x20, #0x880]                         MS:DG.Tweening.TweenSettingsExtensions::SetEase
02cd60c8: ldr     x21, [x21, #0xe08]                         MS:DG.Tweening.TweenSettingsExtensions::SetDelay
02cd60cc: ldr     x23, [x23, #0x928]                         MS:DG.Tweening.TweenSettingsExtensions::OnComplete
02cd60d0: mov     x1, xzr                                    
02cd60d4: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02cd60d8: movi    d0, #0000000000000000                      
02cd60dc: fmov    s1, #0.50000000                            
02cd60e0: mov     x1, xzr                                    
02cd60e4: bl      #0x2d98c98                                 DG.Tweening.ShortcutExtensions::DOScale
02cd60e8: ldr     x2, [x20]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cd60ec: mov     w1, #0x1a                                  
02cd60f0: bl      #0x336fa0c                                 fn_336fa0c
02cd60f4: fmov    s0, #2.00000000                            
02cd60f8: ldr     x1, [x21]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cd60fc: bl      #0x336f7fc                                 fn_336f7fc
02cd6100: mov     x21, x19                                   
02cd6104: mov     x20, x0                                    
02cd6108: ldr     x22, [x21, #0x28]!                         S:'banner_ad_on_off' .<>9__6
02cd610c: cbnz    x22, #0x2cd614c                            
02cd6110: adrp    x8, #0x6264000                             
02cd6114: ldr     x8, [x8, #0xe8]                            T:DG.Tweening.TweenCallback
02cd6118: ldr     x0, [x8]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02cd611c: bl      #0x2b7104c                                 fn_2b7104c
02cd6120: adrp    x8, #0x6267000                             
02cd6124: mov     x1, x19                                    
02cd6128: mov     x3, xzr                                    
02cd612c: ldr     x8, [x8, #0x8f0]                           M:PreviewListStar/<>c__DisplayClass10_1::<ShowPreviewAnim>b__6
02cd6130: mov     x22, x0                                    
02cd6134: ldr     x2, [x8]                                   S:'didu'
02cd6138: bl      #0x2d89dc4                                 DG.Tweening.TweenCallback::.ctor
02cd613c: mov     x0, x21                                    
02cd6140: mov     x1, x22                                    
02cd6144: str     x22, [x19, #0x28]                          .<>9__6
02cd6148: bl      #0x2b70d54                                 fn_2b70d54
02cd614c: mov     x0, x20                                    
02cd6150: mov     x1, x22                                    
02cd6154: ldr     x2, [x23]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cd6158: ldp     x20, x19, [sp, #0x20]                      
02cd615c: ldp     x22, x21, [sp, #0x10]                      
02cd6160: ldp     x30, x23, [sp], #0x30                      
02cd6164: b       #0x336f26c                                 
02cd6168: bl      #0x2b7105c                                 fn_2b7105c
## <ShowPreviewAnim>b__6() -> void
---- PreviewListStar/<>c__DisplayClass10_1::<ShowPreviewAnim>b__6 0x2cd616c
02cd616c: str     x30, [sp, #-0x20]!                         
02cd6170: stp     x20, x19, [sp, #0x10]                      
02cd6174: adrp    x20, #0x662f000                            
02cd6178: mov     x19, x0                                    
02cd617c: ldrb    w8, [x20, #0xd27]                          
02cd6180: tbnz    w8, #0, #0x2cd61a4                         
02cd6184: adrp    x0, #0x6267000                             
02cd6188: ldr     x0, [x0, #0x868]                           MS:Framework.GameObjectExtension::SetActive
02cd618c: bl      #0x2b70db0                                 fn_2b70db0
02cd6190: adrp    x0, #0x6267000                             
02cd6194: ldr     x0, [x0, #0x880]                           MS:System.Collections.Generic.List`1::get_Item
02cd6198: bl      #0x2b70db0                                 fn_2b70db0
02cd619c: mov     w8, #1                                     
02cd61a0: strb    w8, [x20, #0xd27]                          
02cd61a4: ldr     x8, [x19, #0x18]                           .CS$<>8__locals1
02cd61a8: cbz     x8, #0x2cd61ec                             
02cd61ac: ldr     x8, [x8, #0x10]                            
02cd61b0: cbz     x8, #0x2cd61ec                             
02cd61b4: ldr     x0, [x8, #0x38]                            
02cd61b8: cbz     x0, #0x2cd61ec                             
02cd61bc: adrp    x8, #0x6267000                             
02cd61c0: adrp    x20, #0x6267000                            
02cd61c4: ldr     x8, [x8, #0x880]                           MS:System.Collections.Generic.List`1::get_Item
02cd61c8: ldr     x20, [x20, #0x868]                         MS:Framework.GameObjectExtension::SetActive
02cd61cc: ldr     w1, [x19, #0x10]                           .index
02cd61d0: ldr     x2, [x8]                                   S:'didu'
02cd61d4: bl      #0x35a8f3c                                 fn_35a8f3c
02cd61d8: ldr     x2, [x20]                                  S:'didu'
02cd61dc: ldp     x20, x19, [sp, #0x10]                      
02cd61e0: mov     w1, wzr                                    
02cd61e4: ldr     x30, [sp], #0x20                           
02cd61e8: b       #0x31d24a4                                 
02cd61ec: bl      #0x2b7105c                                 fn_2b7105c
#### CLASS PreviewListStar parent= UnityEngine.MonoBehaviour
#   field _cvGroup                       UnityEngine.CanvasGroup                            off=0x20 attr=1 SerializeField
#   field _tfContent                     UnityEngine.Transform                              off=0x28 attr=1 SerializeField
#   field _previewPos                    System.Collections.Generic.List`1<UnityEngine.RectTransform> off=0x30 attr=1 SerializeField
#   field _previewImages                 System.Collections.Generic.List`1<UnityEngine.UI.Image> off=0x38 attr=1 SerializeField
#   field _canvas                        UnityEngine.Canvas                                 off=0x40 attr=1 SerializeField
#   field _txtMessage                    TMPro.TextMeshProUGUI                              off=0x48 attr=1 SerializeField
#   field sequence                       DG.Tweening.Sequence                               off=0x50 attr=1 
## Awake() -> void
---- PreviewListStar::Awake 0x2cd5160
02cd5160: str     x30, [sp, #-0x20]!                         
02cd5164: stp     x20, x19, [sp, #0x10]                      
02cd5168: movi    d0, #0000000000000000                      
02cd516c: movi    d1, #0000000000000000                      
02cd5170: mov     x19, x0                                    
02cd5174: ldr     x0, [x0, #0x20]                            ._cvGroup
02cd5178: mov     x1, xzr                                    
02cd517c: bl      #0x2c78338                                 DG.Tweening.DOTweenModuleUI::DOFade
02cd5180: ldr     x0, [x19, #0x20]                           ._cvGroup
02cd5184: cbz     x0, #0x2cd51e8                             
02cd5188: mov     w1, wzr                                    
02cd518c: mov     x2, xzr                                    
02cd5190: bl      #0x5e45408                                 UnityEngine.CanvasGroup::set_blocksRaycasts
02cd5194: adrp    x20, #0x662f000                            
02cd5198: ldr     x19, [x19, #0x28]                          ._tfContent
02cd519c: ldrb    w8, [x20, #0x91a]                          
02cd51a0: cbnz    w8, #0x2cd51b8                             
02cd51a4: adrp    x0, #0x6264000                             
02cd51a8: ldr     x0, [x0, #0xd8]                            T:UnityEngine.Vector3
02cd51ac: bl      #0x2b70db0                                 fn_2b70db0
02cd51b0: mov     w8, #1                                     
02cd51b4: strb    w8, [x20, #0x91a]                          
02cd51b8: cbz     x19, #0x2cd51e8                            
02cd51bc: adrp    x8, #0x6264000                             
02cd51c0: mov     x0, x19                                    
02cd51c4: mov     x1, xzr                                    
02cd51c8: ldr     x8, [x8, #0xd8]                            T:UnityEngine.Vector3
02cd51cc: ldp     x20, x19, [sp, #0x10]                      
02cd51d0: ldr     x8, [x8]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02cd51d4: ldr     x8, [x8, #0xb8]                            MS:DG.Tweening.Core.Extensions::SetSpecialStartupMode
02cd51d8: ldp     s0, s1, [x8]                               
02cd51dc: ldr     s2, [x8, #8]                               T:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass2_0
02cd51e0: ldr     x30, [sp], #0x20                           
02cd51e4: b       #0x5b470cc                                 UnityEngine.Transform::set_localScale
02cd51e8: bl      #0x2b7105c                                 fn_2b7105c
## WorldToCanvasPosition(UnityEngine.Vector3 worldPos) -> UnityEngine.Vector2
---- PreviewListStar::WorldToCanvasPosition 0x2cd51ec
02cd51ec: sub     sp, sp, #0x40                              
02cd51f0: str     d10, [sp, #0x10]                           
02cd51f4: stp     d9, d8, [sp, #0x18]                        
02cd51f8: str     x30, [sp, #0x28]                           
02cd51fc: stp     x20, x19, [sp, #0x30]                      
02cd5200: fmov    s8, s2                                     
02cd5204: fmov    s9, s1                                     
02cd5208: adrp    x19, #0x662f000                            
02cd520c: fmov    s10, s0                                    
02cd5210: ldrb    w8, [x19, #0xd20]                          
02cd5214: mov     x20, x0                                    
02cd5218: tbnz    w8, #0, #0x2cd523c                         
02cd521c: adrp    x0, #0x6264000                             
02cd5220: ldr     x0, [x0, #0xd88]                           MS:UnityEngine.Component::GetComponent
02cd5224: bl      #0x2b70db0                                 fn_2b70db0
02cd5228: adrp    x0, #0x6264000                             
02cd522c: ldr     x0, [x0, #0x790]                           T:UnityEngine.RectTransformUtility
02cd5230: bl      #0x2b70db0                                 fn_2b70db0
02cd5234: mov     w8, #1                                     
02cd5238: strb    w8, [x19, #0xd20]                          
02cd523c: ldr     x0, [x20, #0x40]                           ._canvas
02cd5240: str     xzr, [sp, #8]                              
02cd5244: cbz     x0, #0x2cd52ec                             
02cd5248: mov     x1, xzr                                    
02cd524c: bl      #0x5e49698                                 UnityEngine.Canvas::get_worldCamera
02cd5250: mov     x19, x0                                    
02cd5254: mov     x0, xzr                                    
02cd5258: bl      #0x5aefe28                                 UnityEngine.Camera::get_main
02cd525c: cbz     x0, #0x2cd52ec                             
02cd5260: fmov    s0, s10                                    
02cd5264: fmov    s1, s9                                     
02cd5268: mov     x1, xzr                                    
02cd526c: fmov    s2, s8                                     
02cd5270: bl      #0x5aefba0                                 UnityEngine.Camera::WorldToScreenPoint
02cd5274: ldr     x0, [x20, #0x40]                           ._canvas
02cd5278: cbz     x0, #0x2cd52ec                             
02cd527c: adrp    x8, #0x6264000                             
02cd5280: adrp    x20, #0x6264000                            
02cd5284: fmov    s8, s0                                     
02cd5288: ldr     x8, [x8, #0xd88]                           MS:UnityEngine.Component::GetComponent
02cd528c: ldr     x20, [x20, #0x790]                         T:UnityEngine.RectTransformUtility
02cd5290: fmov    s9, s1                                     
02cd5294: ldr     x1, [x8]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02cd5298: bl      #0x3140c84                                 fn_3140c84
02cd529c: ldr     x8, [x20]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02cd52a0: mov     x20, x0                                    
02cd52a4: ldr     w9, [x8, #0xe4]                            [62640e4]=0 f=0,0
02cd52a8: cbnz    w9, #0x2cd52b4                             
02cd52ac: mov     x0, x8                                     
02cd52b0: bl      #0x2b70f30                                 fn_2b70f30
02cd52b4: fmov    s0, s8                                     
02cd52b8: fmov    s1, s9                                     
02cd52bc: add     x2, sp, #8                                 
02cd52c0: mov     x0, x20                                    
02cd52c4: mov     x1, x19                                    
02cd52c8: mov     x3, xzr                                    
02cd52cc: bl      #0x5e47a80                                 UnityEngine.RectTransformUtility::ScreenPointToLocalPointInRectangle
02cd52d0: ldp     s0, s1, [sp, #8]                           
02cd52d4: ldr     x30, [sp, #0x28]                           
02cd52d8: ldp     x20, x19, [sp, #0x30]                      
02cd52dc: ldr     d10, [sp, #0x10]                           
02cd52e0: ldp     d9, d8, [sp, #0x18]                        
02cd52e4: add     sp, sp, #0x40                              
02cd52e8: ret                                                
02cd52ec: bl      #0x2b7105c                                 fn_2b7105c
## GetAnchoredPositionInCanvas(UnityEngine.RectTransform item) -> UnityEngine.Vector2
---- PreviewListStar::GetAnchoredPositionInCanvas 0x2cd52f0
02cd52f0: sub     sp, sp, #0x50                              
02cd52f4: str     d10, [sp, #0x10]                           
02cd52f8: stp     d9, d8, [sp, #0x18]                        
02cd52fc: str     x30, [sp, #0x28]                           
02cd5300: stp     x22, x21, [sp, #0x30]                      
02cd5304: stp     x20, x19, [sp, #0x40]                      
02cd5308: adrp    x21, #0x662f000                            
02cd530c: mov     x20, x1                                    
02cd5310: mov     x19, x0                                    
02cd5314: ldrb    w8, [x21, #0xd21]                          
02cd5318: tbnz    w8, #0, #0x2cd533c                         
02cd531c: adrp    x0, #0x6264000                             
02cd5320: ldr     x0, [x0, #0xd88]                           MS:UnityEngine.Component::GetComponent
02cd5324: bl      #0x2b70db0                                 fn_2b70db0
02cd5328: adrp    x0, #0x6264000                             
02cd532c: ldr     x0, [x0, #0x790]                           T:UnityEngine.RectTransformUtility
02cd5330: bl      #0x2b70db0                                 fn_2b70db0
02cd5334: mov     w8, #1                                     
02cd5338: strb    w8, [x21, #0xd21]                          
02cd533c: ldr     x0, [x19, #0x40]                           ._canvas
02cd5340: str     xzr, [sp, #8]                              
02cd5344: cbz     x0, #0x2cd5414                             
02cd5348: mov     x1, xzr                                    
02cd534c: bl      #0x5e49698                                 UnityEngine.Canvas::get_worldCamera
02cd5350: cbz     x20, #0x2cd5414                            
02cd5354: adrp    x22, #0x6264000                            
02cd5358: mov     x21, x0                                    
02cd535c: mov     x0, x20                                    
02cd5360: ldr     x22, [x22, #0x790]                         T:UnityEngine.RectTransformUtility
02cd5364: mov     x1, xzr                                    
02cd5368: bl      #0x5b467ac                                 UnityEngine.Transform::get_position
02cd536c: fmov    s8, s0                                     
02cd5370: fmov    s9, s1                                     
02cd5374: ldr     x0, [x22]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02cd5378: fmov    s10, s2                                    
02cd537c: ldr     w8, [x0, #0xe4]                            [62640e4]=0 f=0,0
02cd5380: cbnz    w8, #0x2cd5388                             
02cd5384: bl      #0x2b70f30                                 fn_2b70f30
02cd5388: fmov    s0, s8                                     
02cd538c: fmov    s1, s9                                     
02cd5390: mov     x0, x21                                    
02cd5394: fmov    s2, s10                                    
02cd5398: mov     x1, xzr                                    
02cd539c: bl      #0x5e47b7c                                 UnityEngine.RectTransformUtility::WorldToScreenPoint
02cd53a0: ldr     x0, [x19, #0x40]                           ._canvas
02cd53a4: cbz     x0, #0x2cd5414                             
02cd53a8: adrp    x8, #0x6264000                             
02cd53ac: fmov    s8, s0                                     
02cd53b0: fmov    s9, s1                                     
02cd53b4: ldr     x8, [x8, #0xd88]                           MS:UnityEngine.Component::GetComponent
02cd53b8: ldr     x1, [x8]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02cd53bc: bl      #0x3140c84                                 fn_3140c84
02cd53c0: ldr     x8, [x19, #0x40]                           ._canvas
02cd53c4: cbz     x8, #0x2cd5414                             
02cd53c8: mov     x19, x0                                    
02cd53cc: mov     x0, x8                                     
02cd53d0: mov     x1, xzr                                    
02cd53d4: bl      #0x5e49698                                 UnityEngine.Canvas::get_worldCamera
02cd53d8: fmov    s0, s8                                     
02cd53dc: fmov    s1, s9                                     
02cd53e0: mov     x1, x0                                     
02cd53e4: add     x2, sp, #8                                 
02cd53e8: mov     x0, x19                                    
02cd53ec: mov     x3, xzr                                    
02cd53f0: bl      #0x5e47a80                                 UnityEngine.RectTransformUtility::ScreenPointToLocalPointInRectangle
02cd53f4: ldp     s0, s1, [sp, #8]                           
02cd53f8: ldr     x30, [sp, #0x28]                           
02cd53fc: ldp     x20, x19, [sp, #0x40]                      
02cd5400: ldr     d10, [sp, #0x10]                           
02cd5404: ldp     x22, x21, [sp, #0x30]                      
02cd5408: ldp     d9, d8, [sp, #0x18]                        
02cd540c: add     sp, sp, #0x50                              
02cd5410: ret                                                
02cd5414: bl      #0x2b7105c                                 fn_2b7105c
## ShowPreviewAnim(System.Collections.Generic.List`1<UnityEngine.SpriteRenderer> inputSprite, System.Action onHalfTimeEvent, System.Action onComplete) -> void
---- PreviewListStar::ShowPreviewAnim 0x2cd5418
02cd5418: sub     sp, sp, #0x80                              
02cd541c: str     d8, [sp, #0x10]                            
02cd5420: stp     x29, x30, [sp, #0x20]                      
02cd5424: stp     x28, x27, [sp, #0x30]                      
02cd5428: stp     x26, x25, [sp, #0x40]                      
02cd542c: stp     x24, x23, [sp, #0x50]                      
02cd5430: stp     x22, x21, [sp, #0x60]                      
02cd5434: stp     x20, x19, [sp, #0x70]                      
02cd5438: adrp    x21, #0x662f000                            
02cd543c: adrp    x20, #0x6267000                            
02cd5440: mov     x22, x3                                    
02cd5444: ldrb    w8, [x21, #0xd22]                          
02cd5448: ldr     x20, [x20, #0x860]                         T:PreviewListStar/<>c__DisplayClass10_0
02cd544c: mov     x23, x2                                    
02cd5450: mov     x24, x1                                    
02cd5454: mov     x19, x0                                    
02cd5458: tbnz    w8, #0, #0x2cd556c                         
02cd545c: adrp    x0, #0x6263000                             
02cd5460: ldr     x0, [x0, #0xfd0]                           T:DG.Tweening.DOTween
02cd5464: bl      #0x2b70db0                                 fn_2b70db0
02cd5468: adrp    x0, #0x6267000                             
02cd546c: ldr     x0, [x0, #0x868]                           MS:Framework.GameObjectExtension::SetActive
02cd5470: bl      #0x2b70db0                                 fn_2b70db0
02cd5474: adrp    x0, #0x6267000                             
02cd5478: ldr     x0, [x0, #0x870]                           MS:System.Collections.Generic.List`1::FindAll
02cd547c: bl      #0x2b70db0                                 fn_2b70db0
02cd5480: adrp    x0, #0x6267000                             
02cd5484: ldr     x0, [x0, #0x878]                           MS:System.Collections.Generic.List`1::get_Count
02cd5488: bl      #0x2b70db0                                 fn_2b70db0
02cd548c: adrp    x0, #0x6267000                             
02cd5490: ldr     x0, [x0, #0x880]                           MS:System.Collections.Generic.List`1::get_Item
02cd5494: bl      #0x2b70db0                                 fn_2b70db0
02cd5498: adrp    x0, #0x6267000                             
02cd549c: ldr     x0, [x0, #0x888]                           MS:System.Collections.Generic.List`1::get_Item
02cd54a0: bl      #0x2b70db0                                 fn_2b70db0
02cd54a4: adrp    x0, #0x6267000                             
02cd54a8: ldr     x0, [x0, #0x890]                           MS:System.Collections.Generic.List`1::get_Item
02cd54ac: bl      #0x2b70db0                                 fn_2b70db0
02cd54b0: adrp    x0, #0x6266000                             
02cd54b4: ldr     x0, [x0, #0x9f0]                           T:Assets.SimpleLocalization.Scripts.LocalizationManager
02cd54b8: bl      #0x2b70db0                                 fn_2b70db0
02cd54bc: adrp    x0, #0x6267000                             
02cd54c0: ldr     x0, [x0, #0x898]                           T:type57284(k15)
02cd54c4: bl      #0x2b70db0                                 fn_2b70db0
02cd54c8: adrp    x0, #0x6264000                             
02cd54cc: ldr     x0, [x0, #0xe8]                            T:DG.Tweening.TweenCallback
02cd54d0: bl      #0x2b70db0                                 fn_2b70db0
02cd54d4: adrp    x0, #0x6266000                             
02cd54d8: ldr     x0, [x0, #0xe00]                           MS:DG.Tweening.TweenSettingsExtensions::SetDelay
02cd54dc: bl      #0x2b70db0                                 fn_2b70db0
02cd54e0: adrp    x0, #0x6266000                             
02cd54e4: ldr     x0, [x0, #0xe08]                           MS:DG.Tweening.TweenSettingsExtensions::SetDelay
02cd54e8: bl      #0x2b70db0                                 fn_2b70db0
02cd54ec: adrp    x0, #0x6266000                             
02cd54f0: ldr     x0, [x0, #0x880]                           MS:DG.Tweening.TweenSettingsExtensions::SetEase
02cd54f4: bl      #0x2b70db0                                 fn_2b70db0
02cd54f8: adrp    x0, #0x6267000                             
02cd54fc: ldr     x0, [x0, #0x8a0]                           M:PreviewListStar/<>c::<ShowPreviewAnim>b__10_0
02cd5500: bl      #0x2b70db0                                 fn_2b70db0
02cd5504: adrp    x0, #0x6267000                             
02cd5508: ldr     x0, [x0, #0x8a8]                           M:PreviewListStar/<>c__DisplayClass10_0::<ShowPreviewAnim>b__1
02cd550c: bl      #0x2b70db0                                 fn_2b70db0
02cd5510: adrp    x0, #0x6267000                             
02cd5514: ldr     x0, [x0, #0x8b0]                           M:PreviewListStar/<>c__DisplayClass10_0::<ShowPreviewAnim>b__2
02cd5518: bl      #0x2b70db0                                 fn_2b70db0
02cd551c: adrp    x0, #0x6267000                             
02cd5520: ldr     x0, [x0, #0x860]                           T:PreviewListStar/<>c__DisplayClass10_0
02cd5524: bl      #0x2b70db0                                 fn_2b70db0
02cd5528: adrp    x0, #0x6267000                             
02cd552c: ldr     x0, [x0, #0x8b8]                           M:PreviewListStar/<>c__DisplayClass10_1::<ShowPreviewAnim>b__3
02cd5530: bl      #0x2b70db0                                 fn_2b70db0
02cd5534: adrp    x0, #0x6267000                             
02cd5538: ldr     x0, [x0, #0x8c0]                           T:PreviewListStar/<>c__DisplayClass10_1
02cd553c: bl      #0x2b70db0                                 fn_2b70db0
02cd5540: adrp    x0, #0x6267000                             
02cd5544: ldr     x0, [x0, #0x8c8]                           T:PreviewListStar/<>c
02cd5548: bl      #0x2b70db0                                 fn_2b70db0
02cd554c: adrp    x0, #0x6266000                             
02cd5550: ldr     x0, [x0, #0xdc8]                           S:'$'
02cd5554: bl      #0x2b70db0                                 fn_2b70db0
02cd5558: adrp    x0, #0x6267000                             
02cd555c: ldr     x0, [x0, #0x8d0]                           S:"You've got $ charms"
02cd5560: bl      #0x2b70db0                                 fn_2b70db0
02cd5564: mov     w8, #1                                     
02cd5568: strb    w8, [x21, #0xd22]                          
02cd556c: ldr     x0, [x20]                                  S:'didu'
02cd5570: str     wzr, [sp, #0x1c]                           
02cd5574: bl      #0x2b7104c                                 fn_2b7104c
02cd5578: mov     x1, xzr                                    
02cd557c: mov     x20, x0                                    
02cd5580: bl      #0x4e53e9c                                 System.Object::.ctor
02cd5584: cbz     x20, #0x2cd5a00                            
02cd5588: mov     x0, x20                                    
02cd558c: mov     x1, x19                                    
02cd5590: str     x19, [x0, #0x10]!                          
02cd5594: bl      #0x2b70d54                                 fn_2b70d54
02cd5598: mov     x21, x20                                   
02cd559c: mov     x1, x24                                    
02cd55a0: str     x24, [x21, #0x18]!                         
02cd55a4: mov     x0, x21                                    
02cd55a8: bl      #0x2b70d54                                 fn_2b70d54
02cd55ac: mov     x0, x20                                    
02cd55b0: mov     x1, x23                                    
02cd55b4: str     x23, [x0, #0x20]!                          ._cvGroup
02cd55b8: bl      #0x2b70d54                                 fn_2b70d54
02cd55bc: mov     x0, x20                                    
02cd55c0: mov     x1, x22                                    
02cd55c4: str     x22, [x0, #0x28]!                          ._tfContent
02cd55c8: bl      #0x2b70d54                                 fn_2b70d54
02cd55cc: mov     x29, x19                                   
02cd55d0: ldr     x0, [x29, #0x50]!                          
02cd55d4: cbz     x0, #0x2cd55e4                             
02cd55d8: mov     w1, wzr                                    
02cd55dc: mov     x2, xzr                                    
02cd55e0: bl      #0x2d8fe94                                 DG.Tweening.TweenExtensions::Kill
02cd55e4: mov     x0, xzr                                    
02cd55e8: bl      #0x2d6eec8                                 Framework.AudioManager::get_Instance
02cd55ec: cbz     x0, #0x2cd5a00                             
02cd55f0: movi    d1, #0000000000000000                      
02cd55f4: movi    d2, #0000000000000000                      
02cd55f8: adrp    x23, #0x6266000                            
02cd55fc: fmov    s0, #1.00000000                            
02cd5600: adrp    x24, #0x6267000                            
02cd5604: adrp    x22, #0x6267000                            
02cd5608: ldr     x23, [x23, #0x9f0]                         T:Assets.SimpleLocalization.Scripts.LocalizationManager
02cd560c: ldr     x24, [x24, #0x8d0]                         S:"You've got $ charms"
02cd5610: ldr     x22, [x22, #0x8c8]                         T:PreviewListStar/<>c
02cd5614: mov     w1, #0xd                                   
02cd5618: mov     w2, wzr                                    
02cd561c: mov     w3, wzr                                    
02cd5620: mov     x4, xzr                                    
02cd5624: bl      #0x2d6f03c                                 Framework.AudioManager::PlaySound
02cd5628: ldr     x0, [x23]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cd562c: ldr     x23, [x19, #0x48]                          ._txtMessage
02cd5630: ldr     w8, [x0, #0xe4]                            [62670e4]=0 f=0,0
02cd5634: cbnz    w8, #0x2cd563c                             
02cd5638: bl      #0x2b70f30                                 fn_2b70f30
02cd563c: adrp    x25, #0x6266000                            
02cd5640: mov     x1, xzr                                    
02cd5644: ldr     x25, [x25, #0xdc8]                         S:'$'
02cd5648: ldr     x0, [x24]                                  S:'didu'
02cd564c: bl      #0x2d76794                                 Assets.SimpleLocalization.Scripts.LocalizationManager::Localize
02cd5650: ldr     x8, [x22]                                  S:'didu'
02cd5654: ldr     x26, [x21]                                 &2b706c4(=eb01011ff9400808)
02cd5658: mov     x24, x0                                    
02cd565c: ldr     w9, [x8, #0xe4]                            
02cd5660: cbnz    w9, #0x2cd5670                             
02cd5664: mov     x0, x8                                     
02cd5668: bl      #0x2b70f30                                 fn_2b70f30
02cd566c: ldr     x8, [x22]                                  S:'didu'
02cd5670: ldr     x9, [x8, #0xb8]                            
02cd5674: ldr     x25, [x25]                                 M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cd5678: ldr     x27, [x9, #8]                              
02cd567c: cbnz    x27, #0x2cd56dc                            
02cd5680: ldr     w10, [x8, #0xe4]                           
02cd5684: cbnz    w10, #0x2cd5698                            
02cd5688: mov     x0, x8                                     
02cd568c: bl      #0x2b70f30                                 fn_2b70f30
02cd5690: ldr     x8, [x22]                                  S:'didu'
02cd5694: ldr     x9, [x8, #0xb8]                            
02cd5698: adrp    x8, #0x6267000                             
02cd569c: ldr     x8, [x8, #0x898]                           T:type57284(k15)
02cd56a0: ldr     x28, [x9]                                  
02cd56a4: ldr     x0, [x8]                                   S:'didu'
02cd56a8: bl      #0x2b7104c                                 fn_2b7104c
02cd56ac: adrp    x8, #0x6267000                             
02cd56b0: mov     x1, x28                                    
02cd56b4: mov     x3, xzr                                    
02cd56b8: ldr     x8, [x8, #0x8a0]                           M:PreviewListStar/<>c::<ShowPreviewAnim>b__10_0
02cd56bc: mov     x27, x0                                    
02cd56c0: ldr     x2, [x8]                                   S:'didu'
02cd56c4: bl      #0x399ba10                                 fn_399ba10
02cd56c8: ldr     x8, [x22]                                  S:'didu'
02cd56cc: mov     x1, x27                                    
02cd56d0: ldr     x0, [x8, #0xb8]                            M:Framework.SceneUtils/<CRUnloadSceneAsync>d__2::System.Collections.IEnumerator.Reset
02cd56d4: str     x27, [x0, #8]!                             
02cd56d8: bl      #0x2b70d54                                 fn_2b70d54
02cd56dc: cbz     x26, #0x2cd5a00                            
02cd56e0: adrp    x8, #0x6267000                             
02cd56e4: mov     x0, x26                                    
02cd56e8: mov     x1, x27                                    
02cd56ec: ldr     x8, [x8, #0x870]                           MS:System.Collections.Generic.List`1::FindAll
02cd56f0: ldr     x2, [x8]                                   S:'didu'
02cd56f4: bl      #0x35a9914                                 fn_35a9914
02cd56f8: cbz     x0, #0x2cd5a00                             
02cd56fc: ldr     w8, [x0, #0x18]                            S:'android.content.Intent'
02cd5700: add     x0, sp, #0x1c                              
02cd5704: mov     x1, xzr                                    
02cd5708: str     w8, [sp, #0x1c]                            
02cd570c: bl      #0x4e0ea3c                                 System.Int32::ToString
02cd5710: cbz     x24, #0x2cd5a00                            
02cd5714: mov     x2, x0                                     
02cd5718: mov     x0, x24                                    
02cd571c: mov     x1, x25                                    
02cd5720: mov     x3, xzr                                    
02cd5724: str     x29, [sp, #8]                              
02cd5728: bl      #0x4ca8ca8                                 System.String::Replace
02cd572c: cbz     x23, #0x2cd5a00                            
02cd5730: ldr     x8, [x23]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cd5734: mov     x1, x0                                     
02cd5738: mov     x0, x23                                    
02cd573c: ldr     x9, [x8, #0x558]                           S:'addView'
02cd5740: ldr     x2, [x8, #0x560]                           S:'getResources'
02cd5744: blr     x9                                         
02cd5748: ldr     x8, [x21]                                  &2b706c4(=eb01011ff9400808)
02cd574c: cbz     x8, #0x2cd5a00                             
02cd5750: adrp    x22, #0x6267000                            
02cd5754: adrp    x28, #0x6267000                            
02cd5758: adrp    x9, #0x1084000                             
02cd575c: adrp    x24, #0x6264000                            
02cd5760: ldr     x22, [x22, #0x880]                         MS:System.Collections.Generic.List`1::get_Item
02cd5764: ldr     x28, [x28, #0x888]                         MS:System.Collections.Generic.List`1::get_Item
02cd5768: ldr     x24, [x24, #0xd8]                          T:UnityEngine.Vector3
02cd576c: ldr     s8, [x9, #0xf30]                           [1084f30]=3f6b851f3ca3d70a f=0.02,0.92
02cd5770: mov     w23, wzr                                   
02cd5774: adrp    x29, #0x662f000                            
02cd5778: ldr     w8, [x8, #0x18]                            S:'android.content.Intent'
02cd577c: cmp     w23, w8                                    
02cd5780: b.ge    #0x2cd5a04                                 
02cd5784: adrp    x8, #0x6267000                             
02cd5788: ldr     x8, [x8, #0x8c0]                           T:PreviewListStar/<>c__DisplayClass10_1
02cd578c: ldr     x0, [x8]                                   S:'didu'
02cd5790: bl      #0x2b7104c                                 fn_2b7104c
02cd5794: mov     x1, xzr                                    
02cd5798: mov     x25, x0                                    
02cd579c: bl      #0x4e53e9c                                 System.Object::.ctor
02cd57a0: cbz     x25, #0x2cd5a00                            
02cd57a4: mov     x26, x25                                   
02cd57a8: mov     x1, x20                                    
02cd57ac: str     x20, [x26, #0x18]!                         
02cd57b0: mov     x0, x26                                    
02cd57b4: bl      #0x2b70d54                                 fn_2b70d54
02cd57b8: ldr     x0, [x19, #0x38]                           ._previewImages
02cd57bc: stur    w23, [x26, #-8]                            
02cd57c0: cbz     x0, #0x2cd5a00                             
02cd57c4: ldr     x2, [x22]                                  S:'didu'
02cd57c8: mov     w1, w23                                    
02cd57cc: bl      #0x35a8f3c                                 fn_35a8f3c
02cd57d0: ldr     x8, [x26]                                  
02cd57d4: cbz     x8, #0x2cd5a00                             
02cd57d8: mov     x27, x0                                    
02cd57dc: ldr     x0, [x8, #0x18]                            S:'android.content.Intent'
02cd57e0: cbz     x0, #0x2cd5a00                             
02cd57e4: ldr     w1, [x25, #0x10]                           S:'mrec_ad_on_off'
02cd57e8: ldr     x2, [x28]                                  S:'didu'
02cd57ec: bl      #0x35a8f3c                                 fn_35a8f3c
02cd57f0: cbz     x0, #0x2cd5a00                             
02cd57f4: mov     x1, xzr                                    
02cd57f8: bl      #0x5b339ec                                 UnityEngine.Component::get_gameObject
02cd57fc: cbz     x0, #0x2cd5a00                             
02cd5800: mov     x1, xzr                                    
02cd5804: bl      #0x5b36bfc                                 UnityEngine.GameObject::get_activeSelf
02cd5808: adrp    x8, #0x6267000                             
02cd580c: and     w1, w0, #1                                 
02cd5810: mov     x0, x27                                    
02cd5814: ldr     x8, [x8, #0x868]                           MS:Framework.GameObjectExtension::SetActive
02cd5818: ldr     x2, [x8]                                   S:'didu'
02cd581c: bl      #0x31d24a4                                 fn_31d24a4
02cd5820: ldr     x0, [x19, #0x30]                           ._previewPos
02cd5824: cbz     x0, #0x2cd5a00                             
02cd5828: adrp    x8, #0x6267000                             
02cd582c: ldr     w1, [x25, #0x10]                           S:'mrec_ad_on_off'
02cd5830: ldr     x8, [x8, #0x890]                           MS:System.Collections.Generic.List`1::get_Item
02cd5834: ldr     x2, [x8]                                   S:'didu'
02cd5838: bl      #0x35a8f3c                                 fn_35a8f3c
02cd583c: cbz     x0, #0x2cd5a00                             
02cd5840: mov     x1, xzr                                    
02cd5844: bl      #0x5b339ec                                 UnityEngine.Component::get_gameObject
02cd5848: ldr     x8, [x26]                                  
02cd584c: cbz     x8, #0x2cd5a00                             
02cd5850: mov     x27, x0                                    
02cd5854: ldr     x0, [x8, #0x18]                            S:'android.content.Intent'
02cd5858: cbz     x0, #0x2cd5a00                             
02cd585c: ldr     w1, [x25, #0x10]                           S:'mrec_ad_on_off'
02cd5860: ldr     x2, [x28]                                  S:'didu'
02cd5864: bl      #0x35a8f3c                                 fn_35a8f3c
02cd5868: cbz     x0, #0x2cd5a00                             
02cd586c: mov     x1, xzr                                    
02cd5870: bl      #0x5b339ec                                 UnityEngine.Component::get_gameObject
02cd5874: cbz     x0, #0x2cd5a00                             
02cd5878: mov     x1, xzr                                    
02cd587c: bl      #0x5b36bfc                                 UnityEngine.GameObject::get_activeSelf
02cd5880: cbz     x27, #0x2cd5a00                            
02cd5884: and     w1, w0, #1                                 
02cd5888: mov     x0, x27                                    
02cd588c: mov     x2, xzr                                    
02cd5890: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02cd5894: ldr     x0, [x19, #0x38]                           ._previewImages
02cd5898: cbz     x0, #0x2cd5a00                             
02cd589c: ldr     w1, [x25, #0x10]                           S:'mrec_ad_on_off'
02cd58a0: ldr     x2, [x22]                                  S:'didu'
02cd58a4: bl      #0x35a8f3c                                 fn_35a8f3c
02cd58a8: cbz     x0, #0x2cd5a00                             
02cd58ac: mov     x1, xzr                                    
02cd58b0: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02cd58b4: ldrb    w8, [x29, #0x91a]                          
02cd58b8: mov     x27, x0                                    
02cd58bc: cbnz    w8, #0x2cd58d0                             
02cd58c0: mov     x0, x24                                    
02cd58c4: bl      #0x2b70db0                                 fn_2b70db0
02cd58c8: mov     w8, #1                                     
02cd58cc: strb    w8, [x29, #0x91a]                          
02cd58d0: cbz     x27, #0x2cd5a00                            
02cd58d4: ldr     x8, [x24]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02cd58d8: mov     x0, x27                                    
02cd58dc: mov     x1, xzr                                    
02cd58e0: ldr     x8, [x8, #0xb8]                            M:Framework.SceneUtils/<CRUnloadSceneAsync>d__2::System.Collections.IEnumerator.Reset
02cd58e4: ldp     s1, s2, [x8, #4]                           
02cd58e8: ldr     s0, [x8]                                   S:'didu'
02cd58ec: bl      #0x5b470cc                                 UnityEngine.Transform::set_localScale
02cd58f0: ldr     x0, [x19, #0x38]                           ._previewImages
02cd58f4: cbz     x0, #0x2cd5a00                             
02cd58f8: ldr     w1, [x25, #0x10]                           S:'mrec_ad_on_off'
02cd58fc: ldr     x2, [x22]                                  S:'didu'
02cd5900: bl      #0x35a8f3c                                 fn_35a8f3c
02cd5904: cbz     x0, #0x2cd5a00                             
02cd5908: mov     x1, xzr                                    
02cd590c: bl      #0x5c4e1ac                                 UnityEngine.UI.Graphic::get_rectTransform
02cd5910: ldr     x8, [x26]                                  
02cd5914: cbz     x8, #0x2cd5a00                             
02cd5918: mov     x26, x0                                    
02cd591c: ldr     x0, [x8, #0x18]                            S:'android.content.Intent'
02cd5920: cbz     x0, #0x2cd5a00                             
02cd5924: ldr     w1, [x25, #0x10]                           S:'mrec_ad_on_off'
02cd5928: ldr     x2, [x28]                                  S:'didu'
02cd592c: bl      #0x35a8f3c                                 fn_35a8f3c
02cd5930: cbz     x0, #0x2cd5a00                             
02cd5934: mov     x1, xzr                                    
02cd5938: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02cd593c: cbz     x0, #0x2cd5a00                             
02cd5940: mov     x1, xzr                                    
02cd5944: bl      #0x5b467ac                                 UnityEngine.Transform::get_position
02cd5948: mov     x0, x19                                    
02cd594c: bl      #0x2cd51ec                                 PreviewListStar::WorldToCanvasPosition
02cd5950: cbz     x26, #0x2cd5a00                            
02cd5954: mov     x0, x26                                    
02cd5958: mov     x1, xzr                                    
02cd595c: bl      #0x5b45800                                 UnityEngine.RectTransform::set_anchoredPosition
02cd5960: ldr     x0, [x19, #0x38]                           ._previewImages
02cd5964: cbz     x0, #0x2cd5a00                             
02cd5968: ldr     w1, [x25, #0x10]                           S:'mrec_ad_on_off'
02cd596c: ldr     x2, [x22]                                  S:'didu'
02cd5970: bl      #0x35a8f3c                                 fn_35a8f3c
02cd5974: ldr     x8, [x25, #0x18]                           S:'level_show_popuprate'
02cd5978: cbz     x8, #0x2cd5a00                             
02cd597c: mov     x26, x0                                    
02cd5980: ldr     x0, [x8, #0x18]                            S:'android.content.Intent'
02cd5984: cbz     x0, #0x2cd5a00                             
02cd5988: ldr     w1, [x25, #0x10]                           S:'mrec_ad_on_off'
02cd598c: ldr     x2, [x28]                                  S:'didu'
02cd5990: bl      #0x35a8f3c                                 fn_35a8f3c
02cd5994: cbz     x0, #0x2cd5a00                             
02cd5998: mov     x1, xzr                                    
02cd599c: bl      #0x5ae6cfc                                 UnityEngine.SpriteRenderer::get_sprite
02cd59a0: cbz     x26, #0x2cd5a00                            
02cd59a4: mov     x1, x0                                     
02cd59a8: mov     x0, x26                                    
02cd59ac: mov     x2, xzr                                    
02cd59b0: bl      #0x5c45aa0                                 UnityEngine.UI.Image::set_sprite
02cd59b4: adrp    x8, #0x6264000                             
02cd59b8: ldr     x8, [x8, #0xe8]                            T:DG.Tweening.TweenCallback
02cd59bc: ldr     x0, [x8]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02cd59c0: bl      #0x2b7104c                                 fn_2b7104c
02cd59c4: adrp    x8, #0x6267000                             
02cd59c8: mov     x1, x25                                    
02cd59cc: mov     x3, xzr                                    
02cd59d0: ldr     x8, [x8, #0x8b8]                           M:PreviewListStar/<>c__DisplayClass10_1::<ShowPreviewAnim>b__3
02cd59d4: mov     x26, x0                                    
02cd59d8: ldr     x2, [x8]                                   S:'didu'
02cd59dc: bl      #0x2d89dc4                                 DG.Tweening.TweenCallback::.ctor
02cd59e0: fmov    s0, s8                                     
02cd59e4: mov     x0, x26                                    
02cd59e8: mov     w1, #1                                     
02cd59ec: mov     x2, xzr                                    
02cd59f0: bl      #0x2d8f37c                                 DG.Tweening.DOVirtual::DelayedCall
02cd59f4: ldr     x8, [x21]                                  &2b706c4(=eb01011ff9400808)
02cd59f8: add     w23, w23, #1                               
02cd59fc: cbnz    x8, #0x2cd5778                             
02cd5a00: bl      #0x2b7105c                                 fn_2b7105c
02cd5a04: adrp    x8, #0x6263000                             
02cd5a08: ldr     x8, [x8, #0xfd0]                           T:DG.Tweening.DOTween
02cd5a0c: ldr     x0, [x8]                                   &2c5bbd4(=a9bd7bfdd503233f)
02cd5a10: ldr     w8, [x0, #0xe4]                            [62670e4]=0 f=0,0
02cd5a14: cbnz    w8, #0x2cd5a1c                             
02cd5a18: bl      #0x2b70f30                                 fn_2b70f30
02cd5a1c: mov     x0, xzr                                    
02cd5a20: bl      #0x2d8cfe8                                 DG.Tweening.DOTween::Sequence
02cd5a24: mov     x1, x0                                     
02cd5a28: str     x0, [x19, #0x50]                           .sequence
02cd5a2c: ldr     x0, [sp, #8]                               
02cd5a30: bl      #0x2b70d54                                 fn_2b70d54
02cd5a34: ldr     x0, [x19, #0x20]                           ._cvGroup
02cd5a38: cbz     x0, #0x2cd5a00                             
02cd5a3c: mov     w1, #1                                     
02cd5a40: mov     x2, xzr                                    
02cd5a44: bl      #0x5e45408                                 UnityEngine.CanvasGroup::set_blocksRaycasts
02cd5a48: adrp    x8, #0x1084000                             
02cd5a4c: fmov    s0, #1.00000000                            
02cd5a50: ldr     x0, [x19, #0x20]                           ._cvGroup
02cd5a54: ldr     s1, [x8, #0xf10]                           [1084f10]=4110bc863e99999a f=0.3,9.04603
02cd5a58: ldr     x21, [x19, #0x50]                          .sequence
02cd5a5c: mov     x1, xzr                                    
02cd5a60: bl      #0x2c78338                                 DG.Tweening.DOTweenModuleUI::DOFade
02cd5a64: mov     x1, x0                                     
02cd5a68: mov     x0, x21                                    
02cd5a6c: mov     x2, xzr                                    
02cd5a70: bl      #0x2d9b0a8                                 DG.Tweening.TweenSettingsExtensions::Append
02cd5a74: fmov    s0, #1.00000000                            
02cd5a78: fmov    s1, #0.50000000                            
02cd5a7c: ldr     x0, [x19, #0x28]                           ._tfContent
02cd5a80: ldr     x21, [x19, #0x50]                          .sequence
02cd5a84: mov     x1, xzr                                    
02cd5a88: bl      #0x2d98c98                                 DG.Tweening.ShortcutExtensions::DOScale
02cd5a8c: adrp    x24, #0x6266000                            
02cd5a90: mov     w1, #0x1b                                  
02cd5a94: ldr     x24, [x24, #0x880]                         MS:DG.Tweening.TweenSettingsExtensions::SetEase
02cd5a98: ldr     x2, [x24]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cd5a9c: bl      #0x336fa0c                                 fn_336fa0c
02cd5aa0: mov     x1, x0                                     
02cd5aa4: mov     x0, x21                                    
02cd5aa8: mov     x2, xzr                                    
02cd5aac: bl      #0x2d9b0a8                                 DG.Tweening.TweenSettingsExtensions::Append
02cd5ab0: fmov    s0, #1.00000000                            
02cd5ab4: fmov    s1, #0.50000000                            
02cd5ab8: ldr     x0, [x19, #0x28]                           ._tfContent
02cd5abc: ldr     x21, [x19, #0x50]                          .sequence
02cd5ac0: mov     x1, xzr                                    
02cd5ac4: bl      #0x2d98c98                                 DG.Tweening.ShortcutExtensions::DOScale
02cd5ac8: mov     x1, x0                                     
02cd5acc: mov     x0, x21                                    
02cd5ad0: mov     x2, xzr                                    
02cd5ad4: bl      #0x2d9b0a8                                 DG.Tweening.TweenSettingsExtensions::Append
02cd5ad8: adrp    x23, #0x6264000                            
02cd5adc: ldr     x21, [x19, #0x50]                          .sequence
02cd5ae0: ldr     x23, [x23, #0xe8]                          T:DG.Tweening.TweenCallback
02cd5ae4: ldr     x0, [x23]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02cd5ae8: bl      #0x2b7104c                                 fn_2b7104c
02cd5aec: adrp    x8, #0x6267000                             
02cd5af0: mov     x1, x20                                    
02cd5af4: mov     x3, xzr                                    
02cd5af8: ldr     x8, [x8, #0x8a8]                           M:PreviewListStar/<>c__DisplayClass10_0::<ShowPreviewAnim>b__1
02cd5afc: mov     x22, x0                                    
02cd5b00: ldr     x2, [x8]                                   S:'didu'
02cd5b04: bl      #0x2d89dc4                                 DG.Tweening.TweenCallback::.ctor
02cd5b08: mov     x0, x21                                    
02cd5b0c: mov     x1, x22                                    
02cd5b10: mov     x2, xzr                                    
02cd5b14: bl      #0x2da03d8                                 DG.Tweening.TweenSettingsExtensions::AppendCallback
02cd5b18: fmov    s0, #0.50000000                            
02cd5b1c: ldr     x0, [x19, #0x50]                           .sequence
02cd5b20: mov     x1, xzr                                    
02cd5b24: bl      #0x2d8f450                                 DG.Tweening.TweenSettingsExtensions::AppendInterval
02cd5b28: movi    d0, #0000000000000000                      
02cd5b2c: fmov    s1, #0.50000000                            
02cd5b30: ldr     x0, [x19, #0x28]                           ._tfContent
02cd5b34: ldr     x21, [x19, #0x50]                          .sequence
02cd5b38: mov     x1, xzr                                    
02cd5b3c: bl      #0x2d98c98                                 DG.Tweening.ShortcutExtensions::DOScale
02cd5b40: adrp    x8, #0x6266000                             
02cd5b44: fmov    s0, #0.50000000                            
02cd5b48: ldr     x8, [x8, #0xe08]                           MS:DG.Tweening.TweenSettingsExtensions::SetDelay
02cd5b4c: ldr     x1, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cd5b50: bl      #0x336f7fc                                 fn_336f7fc
02cd5b54: ldr     x2, [x24]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cd5b58: mov     w1, #0x1a                                  
02cd5b5c: bl      #0x336fa0c                                 fn_336fa0c
02cd5b60: mov     x1, x0                                     
02cd5b64: mov     x0, x21                                    
02cd5b68: mov     x2, xzr                                    
02cd5b6c: bl      #0x2d9b0a8                                 DG.Tweening.TweenSettingsExtensions::Append
02cd5b70: movi    d0, #0000000000000000                      
02cd5b74: fmov    s1, #0.50000000                            
02cd5b78: ldr     x0, [x19, #0x20]                           ._cvGroup
02cd5b7c: ldr     x21, [x19, #0x50]                          .sequence
02cd5b80: mov     x1, xzr                                    
02cd5b84: bl      #0x2c78338                                 DG.Tweening.DOTweenModuleUI::DOFade
02cd5b88: adrp    x8, #0x6266000                             
02cd5b8c: fmov    s0, #0.75000000                            
02cd5b90: ldr     x8, [x8, #0xe00]                           MS:DG.Tweening.TweenSettingsExtensions::SetDelay
02cd5b94: ldr     x1, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cd5b98: bl      #0x336f7fc                                 fn_336f7fc
02cd5b9c: mov     x1, x0                                     
02cd5ba0: mov     x0, x21                                    
02cd5ba4: mov     x2, xzr                                    
02cd5ba8: bl      #0x2d9b0ec                                 DG.Tweening.TweenSettingsExtensions::Join
02cd5bac: ldr     x0, [x23]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02cd5bb0: ldr     x19, [x19, #0x50]                          .sequence
02cd5bb4: bl      #0x2b7104c                                 fn_2b7104c
02cd5bb8: adrp    x8, #0x6267000                             
02cd5bbc: mov     x1, x20                                    
02cd5bc0: mov     x3, xzr                                    
02cd5bc4: ldr     x8, [x8, #0x8b0]                           M:PreviewListStar/<>c__DisplayClass10_0::<ShowPreviewAnim>b__2
02cd5bc8: mov     x21, x0                                    
02cd5bcc: ldr     x2, [x8]                                   S:'didu'
02cd5bd0: bl      #0x2d89dc4                                 DG.Tweening.TweenCallback::.ctor
02cd5bd4: mov     x0, x19                                    
02cd5bd8: mov     x1, x21                                    
02cd5bdc: mov     x2, xzr                                    
02cd5be0: bl      #0x2da03d8                                 DG.Tweening.TweenSettingsExtensions::AppendCallback
02cd5be4: ldp     x20, x19, [sp, #0x70]                      
02cd5be8: ldr     d8, [sp, #0x10]                            
02cd5bec: ldp     x22, x21, [sp, #0x60]                      
02cd5bf0: ldp     x24, x23, [sp, #0x50]                      
02cd5bf4: ldp     x26, x25, [sp, #0x40]                      
02cd5bf8: ldp     x28, x27, [sp, #0x30]                      
02cd5bfc: ldp     x29, x30, [sp, #0x20]                      
02cd5c00: add     sp, sp, #0x80                              
02cd5c04: ret                                                
## .ctor() -> void
---- PreviewListStar::.ctor 0x2cd5c18
02cd5c18: mov     x1, xzr                                    
02cd5c1c: b       #0x5b397b0                                 UnityEngine.MonoBehaviour::.ctor
