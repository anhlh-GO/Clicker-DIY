#### CLASS NotEnoughMoneyPopup parent= PopupBase
#   field _panel                         UnityEngine.Transform                              off=0x38 attr=1 SerializeField
#   field _closeButton                   UnityEngine.UI.Button                              off=0x40 attr=1 SerializeField
#   field _closeButtonHidden             UnityEngine.UI.Button                              off=0x48 attr=1 SerializeField
#   field _purchaseButton                UnityEngine.UI.Button                              off=0x50 attr=1 SerializeField
#   field _lastParent                    UnityEngine.Transform                              off=0x58 attr=1 
#   field _featureUsing                  string                                             off=0x60 attr=1 
## OnShow() -> void
---- NotEnoughMoneyPopup::OnShow 0x2ce561c
02ce561c: str     x30, [sp, #-0x40]!                         
02ce5620: stp     x24, x23, [sp, #0x10]                      
02ce5624: stp     x22, x21, [sp, #0x20]                      
02ce5628: stp     x20, x19, [sp, #0x30]                      
02ce562c: adrp    x20, #0x662f000                            
02ce5630: mov     x19, x0                                    
02ce5634: ldrb    w8, [x20, #0xddc]                          
02ce5638: tbnz    w8, #0, #0x2ce5668                         
02ce563c: adrp    x0, #0x6266000                             
02ce5640: ldr     x0, [x0, #0xaa0]                           MS:MonoSingleton`1::get_Instance
02ce5644: bl      #0x2b70db0                                 fn_2b70db0
02ce5648: adrp    x0, #0x6265000                             
02ce564c: ldr     x0, [x0, #0x310]                           MS:WejoyService.Singleton`1::get_Instance
02ce5650: bl      #0x2b70db0                                 fn_2b70db0
02ce5654: adrp    x0, #0x6266000                             
02ce5658: ldr     x0, [x0, #0x880]                           MS:DG.Tweening.TweenSettingsExtensions::SetEase
02ce565c: bl      #0x2b70db0                                 fn_2b70db0
02ce5660: mov     w8, #1                                     
02ce5664: strb    w8, [x20, #0xddc]                          
02ce5668: movi    d0, #0000000000000000                      
02ce566c: ldr     x0, [x19, #0x28]                           
02ce5670: mov     w1, #1                                     
02ce5674: mov     x2, xzr                                    
02ce5678: mov     w21, #1                                    
02ce567c: bl      #0x2cf1928                                 FrameWorkUtility::SetActive
02ce5680: ldr     x0, [x19, #0x38]                           ._panel
02ce5684: mov     w1, wzr                                    
02ce5688: mov     x2, xzr                                    
02ce568c: strb    w21, [x19, #0x20]                          
02ce5690: bl      #0x2d9d5d0                                 DG.Tweening.ShortcutExtensions::DOKill
02ce5694: adrp    x22, #0x662f000                            
02ce5698: ldr     x20, [x19, #0x38]                          ._panel
02ce569c: ldrb    w8, [x22, #0x91a]                          
02ce56a0: cbnz    w8, #0x2ce56b4                             
02ce56a4: adrp    x0, #0x6264000                             
02ce56a8: ldr     x0, [x0, #0xd8]                            T:UnityEngine.Vector3
02ce56ac: bl      #0x2b70db0                                 fn_2b70db0
02ce56b0: strb    w21, [x22, #0x91a]                         
02ce56b4: cbz     x20, #0x2ce57c8                            
02ce56b8: adrp    x23, #0x6264000                            
02ce56bc: adrp    x22, #0x6266000                            
02ce56c0: adrp    x21, #0x6266000                            
02ce56c4: ldr     x23, [x23, #0xd8]                          T:UnityEngine.Vector3
02ce56c8: mov     x0, x20                                    
02ce56cc: mov     x1, xzr                                    
02ce56d0: ldr     x8, [x23]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02ce56d4: ldr     x22, [x22, #0x880]                         MS:DG.Tweening.TweenSettingsExtensions::SetEase
02ce56d8: ldr     x8, [x8, #0xb8]                            
02ce56dc: ldr     x21, [x21, #0xaa0]                         MS:MonoSingleton`1::get_Instance
02ce56e0: ldp     s1, s2, [x8, #4]                           
02ce56e4: ldr     s0, [x8]                                   
02ce56e8: bl      #0x5b470cc                                 UnityEngine.Transform::set_localScale
02ce56ec: adrp    x24, #0x662f000                            
02ce56f0: ldr     x20, [x19, #0x38]                          ._panel
02ce56f4: ldrb    w8, [x24, #0xa74]                          
02ce56f8: cbnz    w8, #0x2ce5710                             
02ce56fc: adrp    x0, #0x6264000                             
02ce5700: ldr     x0, [x0, #0xd8]                            T:UnityEngine.Vector3
02ce5704: bl      #0x2b70db0                                 fn_2b70db0
02ce5708: mov     w8, #1                                     
02ce570c: strb    w8, [x24, #0xa74]                          
02ce5710: ldr     x8, [x23]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02ce5714: mov     x0, x20                                    
02ce5718: mov     x1, xzr                                    
02ce571c: ldr     x8, [x8, #0xb8]                            
02ce5720: ldp     s0, s1, [x8, #0xc]                         
02ce5724: ldr     s2, [x8, #0x14]                            
02ce5728: adrp    x8, #0x1084000                             
02ce572c: ldr     s3, [x8, #0xda8]                           [1084da8]=da242603eb851ec f=0.36,1e-30
02ce5730: bl      #0x2d98af8                                 DG.Tweening.ShortcutExtensions::DOScale
02ce5734: ldr     x2, [x22]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ce5738: mov     w1, #0x1b                                  
02ce573c: bl      #0x336fa0c                                 fn_336fa0c
02ce5740: ldr     x0, [x21]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ce5744: bl      #0x3769600                                 fn_3769600
02ce5748: cbz     x0, #0x2ce57c8                             
02ce574c: mov     x1, xzr                                    
02ce5750: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02ce5754: cbz     x0, #0x2ce57c8                             
02ce5758: mov     x1, xzr                                    
02ce575c: bl      #0x5b466dc                                 UnityEngine.Transform::get_parent
02ce5760: mov     x1, x0                                     
02ce5764: mov     x0, x19                                    
02ce5768: str     x1, [x0, #0x58]!                           ._lastParent
02ce576c: bl      #0x2b70d54                                 fn_2b70d54
02ce5770: ldr     x0, [x21]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ce5774: bl      #0x3769600                                 fn_3769600
02ce5778: mov     x20, x0                                    
02ce577c: mov     x0, x19                                    
02ce5780: mov     x1, xzr                                    
02ce5784: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02ce5788: cbz     x20, #0x2ce57c8                            
02ce578c: adrp    x19, #0x6265000                            
02ce5790: mov     x1, x0                                     
02ce5794: mov     x0, x20                                    
02ce5798: ldr     x19, [x19, #0x310]                         MS:WejoyService.Singleton`1::get_Instance
02ce579c: bl      #0x2cdac14                                 MoneyManager::SetCurrentParent
02ce57a0: ldr     x0, [x19]                                  M:AdsManager::<OnApplicationPause>b__26_0
02ce57a4: bl      #0x3be7218                                 fn_3be7218
02ce57a8: cbz     x0, #0x2ce57c8                             
02ce57ac: ldp     x20, x19, [sp, #0x30]                      
02ce57b0: mov     w1, #4                                     
02ce57b4: ldp     x22, x21, [sp, #0x20]                      
02ce57b8: mov     x2, xzr                                    
02ce57bc: ldp     x24, x23, [sp, #0x10]                      
02ce57c0: ldr     x30, [sp], #0x40                           
02ce57c4: b       #0x2c8a650                                 AdsManager::ShowMREC
02ce57c8: bl      #0x2b7105c                                 fn_2b7105c
## OnInit(UIManager uiManager) -> void
---- NotEnoughMoneyPopup::OnInit 0x2ce57cc
02ce57cc: str     x30, [sp, #-0x30]!                         
02ce57d0: stp     x22, x21, [sp, #0x10]                      
02ce57d4: stp     x20, x19, [sp, #0x20]                      
02ce57d8: adrp    x21, #0x662f000                            
02ce57dc: mov     x20, x1                                    
02ce57e0: mov     x19, x0                                    
02ce57e4: ldrb    w8, [x21, #0xddd]                          
02ce57e8: tbnz    w8, #0, #0x2ce5824                         
02ce57ec: adrp    x0, #0x6268000                             
02ce57f0: ldr     x0, [x0, #0x1a0]                           M:NotEnoughMoneyPopup::<OnInit>b__6_0
02ce57f4: bl      #0x2b70db0                                 fn_2b70db0
02ce57f8: adrp    x0, #0x6268000                             
02ce57fc: ldr     x0, [x0, #0x1a8]                           M:NotEnoughMoneyPopup::<OnInit>b__6_1
02ce5800: bl      #0x2b70db0                                 fn_2b70db0
02ce5804: adrp    x0, #0x6268000                             
02ce5808: ldr     x0, [x0, #0x1b0]                           M:NotEnoughMoneyPopup::<OnInit>b__6_2
02ce580c: bl      #0x2b70db0                                 fn_2b70db0
02ce5810: adrp    x0, #0x6265000                             
02ce5814: ldr     x0, [x0, #0x3f0]                           T:UnityEngine.Events.UnityAction
02ce5818: bl      #0x2b70db0                                 fn_2b70db0
02ce581c: mov     w8, #1                                     
02ce5820: strb    w8, [x21, #0xddd]                          
02ce5824: mov     x0, x19                                    
02ce5828: mov     x1, x20                                    
02ce582c: bl      #0x2cdd3c4                                 UIBase::OnInit
02ce5830: ldr     x8, [x19, #0x40]                           ._closeButton
02ce5834: cbz     x8, #0x2ce5910                             
02ce5838: adrp    x22, #0x6265000                            
02ce583c: adrp    x21, #0x6268000                            
02ce5840: ldr     x22, [x22, #0x3f0]                         T:UnityEngine.Events.UnityAction
02ce5844: ldr     x21, [x21, #0x1a0]                         M:NotEnoughMoneyPopup::<OnInit>b__6_0
02ce5848: ldr     x20, [x8, #0x100]                          
02ce584c: ldr     x0, [x22]                                  M:AdsManager::<OnApplicationPause>b__26_0
02ce5850: bl      #0x2b7104c                                 fn_2b7104c
02ce5854: ldr     x2, [x21]                                  S:'{0}/2'
02ce5858: mov     x1, x19                                    
02ce585c: mov     x3, xzr                                    
02ce5860: mov     x21, x0                                    
02ce5864: bl      #0x5b4cf98                                 UnityEngine.Events.UnityAction::.ctor
02ce5868: cbz     x20, #0x2ce5910                            
02ce586c: mov     x0, x20                                    
02ce5870: mov     x1, x21                                    
02ce5874: mov     x2, xzr                                    
02ce5878: bl      #0x5b4d0ac                                 UnityEngine.Events.UnityEvent::AddListener
02ce587c: ldr     x8, [x19, #0x48]                           ._closeButtonHidden
02ce5880: cbz     x8, #0x2ce5910                             
02ce5884: adrp    x21, #0x6268000                            
02ce5888: ldr     x21, [x21, #0x1a8]                         M:NotEnoughMoneyPopup::<OnInit>b__6_1
02ce588c: ldr     x0, [x22]                                  M:AdsManager::<OnApplicationPause>b__26_0
02ce5890: ldr     x20, [x8, #0x100]                          
02ce5894: bl      #0x2b7104c                                 fn_2b7104c
02ce5898: ldr     x2, [x21]                                  S:'{0}/2'
02ce589c: mov     x1, x19                                    
02ce58a0: mov     x3, xzr                                    
02ce58a4: mov     x21, x0                                    
02ce58a8: bl      #0x5b4cf98                                 UnityEngine.Events.UnityAction::.ctor
02ce58ac: cbz     x20, #0x2ce5910                            
02ce58b0: mov     x0, x20                                    
02ce58b4: mov     x1, x21                                    
02ce58b8: mov     x2, xzr                                    
02ce58bc: bl      #0x5b4d0ac                                 UnityEngine.Events.UnityEvent::AddListener
02ce58c0: ldr     x8, [x19, #0x50]                           ._purchaseButton
02ce58c4: cbz     x8, #0x2ce5910                             
02ce58c8: adrp    x21, #0x6268000                            
02ce58cc: ldr     x21, [x21, #0x1b0]                         M:NotEnoughMoneyPopup::<OnInit>b__6_2
02ce58d0: ldr     x0, [x22]                                  M:AdsManager::<OnApplicationPause>b__26_0
02ce58d4: ldr     x20, [x8, #0x100]                          
02ce58d8: bl      #0x2b7104c                                 fn_2b7104c
02ce58dc: ldr     x2, [x21]                                  S:'{0}/2'
02ce58e0: mov     x1, x19                                    
02ce58e4: mov     x3, xzr                                    
02ce58e8: mov     x21, x0                                    
02ce58ec: bl      #0x5b4cf98                                 UnityEngine.Events.UnityAction::.ctor
02ce58f0: cbz     x20, #0x2ce5910                            
02ce58f4: mov     x0, x20                                    
02ce58f8: mov     x1, x21                                    
02ce58fc: mov     x2, xzr                                    
02ce5900: ldp     x20, x19, [sp, #0x20]                      
02ce5904: ldp     x22, x21, [sp, #0x10]                      
02ce5908: ldr     x30, [sp], #0x30                           
02ce590c: b       #0x5b4d0ac                                 UnityEngine.Events.UnityEvent::AddListener
02ce5910: bl      #0x2b7105c                                 fn_2b7105c
## SetFeatureUsing(string feature) -> void
---- NotEnoughMoneyPopup::SetFeatureUsing 0x2ce5914
02ce5914: str     x1, [x0, #0x60]!                           ._featureUsing
02ce5918: b       #0x2b70d54                                 
## OnCoinCompleted() -> void
---- NotEnoughMoneyPopup::OnCoinCompleted 0x2ce591c
02ce591c: ldr     x8, [x0]                                   
02ce5920: ldp     x2, x1, [x8, #0x198]                       
02ce5924: br      x2                                         
## OnHide() -> void
---- NotEnoughMoneyPopup::OnHide 0x2ce5928
02ce5928: stp     x30, x21, [sp, #-0x20]!                    
02ce592c: stp     x20, x19, [sp, #0x10]                      
02ce5930: adrp    x21, #0x662f000                            
02ce5934: adrp    x20, #0x6263000                            
02ce5938: mov     x19, x0                                    
02ce593c: ldrb    w8, [x21, #0xdde]                          
02ce5940: ldr     x20, [x20, #0x918]                         T:UnityEngine.Object
02ce5944: tbnz    w8, #0, #0x2ce5974                         
02ce5948: adrp    x0, #0x6266000                             
02ce594c: ldr     x0, [x0, #0xaa0]                           MS:MonoSingleton`1::get_Instance
02ce5950: bl      #0x2b70db0                                 fn_2b70db0
02ce5954: adrp    x0, #0x6263000                             
02ce5958: ldr     x0, [x0, #0x918]                           T:UnityEngine.Object
02ce595c: bl      #0x2b70db0                                 fn_2b70db0
02ce5960: adrp    x0, #0x6265000                             
02ce5964: ldr     x0, [x0, #0x310]                           MS:WejoyService.Singleton`1::get_Instance
02ce5968: bl      #0x2b70db0                                 fn_2b70db0
02ce596c: mov     w8, #1                                     
02ce5970: strb    w8, [x21, #0xdde]                          
02ce5974: movi    d0, #0000000000000000                      
02ce5978: ldr     x0, [x19, #0x28]                           
02ce597c: mov     w1, wzr                                    
02ce5980: mov     x2, xzr                                    
02ce5984: bl      #0x2cf1928                                 FrameWorkUtility::SetActive
02ce5988: ldr     x0, [x20]                                  &2c5bbd4(=a9bd7bfdd503233f)
02ce598c: ldr     x20, [x19, #0x58]                          ._lastParent
02ce5990: strb    wzr, [x19, #0x20]                          
02ce5994: ldr     w8, [x0, #0xe4]                            [62650e4]=0 f=0,0
02ce5998: cbnz    w8, #0x2ce59a0                             
02ce599c: bl      #0x2b70f30                                 fn_2b70f30
02ce59a0: mov     x0, x20                                    
02ce59a4: mov     x1, xzr                                    
02ce59a8: mov     x2, xzr                                    
02ce59ac: bl      #0x5b3666c                                 UnityEngine.Object::op_Inequality
02ce59b0: tbz     w0, #0, #0x2ce59d0                         
02ce59b4: adrp    x8, #0x6266000                             
02ce59b8: ldr     x8, [x8, #0xaa0]                           MS:MonoSingleton`1::get_Instance
02ce59bc: ldr     x0, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ce59c0: bl      #0x3769600                                 fn_3769600
02ce59c4: cbz     x0, #0x2ce59f4                             
02ce59c8: ldr     x1, [x19, #0x58]                           ._lastParent
02ce59cc: bl      #0x2cdac14                                 MoneyManager::SetCurrentParent
02ce59d0: adrp    x8, #0x6265000                             
02ce59d4: ldr     x8, [x8, #0x310]                           MS:WejoyService.Singleton`1::get_Instance
02ce59d8: ldr     x0, [x8]                                   M:AdsManager::<OnApplicationPause>b__26_0
02ce59dc: bl      #0x3be7218                                 fn_3be7218
02ce59e0: cbz     x0, #0x2ce59f4                             
02ce59e4: ldp     x20, x19, [sp, #0x10]                      
02ce59e8: mov     x1, xzr                                    
02ce59ec: ldp     x30, x21, [sp], #0x20                      
02ce59f0: b       #0x2c88cec                                 AdsManager::HideMREC
02ce59f4: bl      #0x2b7105c                                 fn_2b7105c
## .ctor() -> void
---- NotEnoughMoneyPopup::.ctor 0x2ce59f8
02ce59f8: stp     x30, x21, [sp, #-0x20]!                    
02ce59fc: stp     x20, x19, [sp, #0x10]                      
02ce5a00: adrp    x20, #0x662f000                            
02ce5a04: adrp    x21, #0x6263000                            
02ce5a08: mov     x19, x0                                    
02ce5a0c: ldrb    w8, [x20, #0xddf]                          
02ce5a10: ldr     x21, [x21, #0xa90]                         S:''
02ce5a14: tbnz    w8, #0, #0x2ce5a2c                         
02ce5a18: adrp    x0, #0x6263000                             
02ce5a1c: ldr     x0, [x0, #0xa90]                           S:''
02ce5a20: bl      #0x2b70db0                                 fn_2b70db0
02ce5a24: mov     w8, #1                                     
02ce5a28: strb    w8, [x20, #0xddf]                          
02ce5a2c: ldr     x1, [x21]                                  &2c5bbd4(=a9bd7bfdd503233f)
02ce5a30: mov     x0, x19                                    
02ce5a34: str     x1, [x0, #0x60]!                           ._featureUsing
02ce5a38: bl      #0x2b70d54                                 fn_2b70d54
02ce5a3c: mov     x0, x19                                    
02ce5a40: ldp     x20, x19, [sp, #0x10]                      
02ce5a44: mov     x1, xzr                                    
02ce5a48: ldp     x30, x21, [sp], #0x20                      
02ce5a4c: b       #0x5b397b0                                 UnityEngine.MonoBehaviour::.ctor
## <OnInit>b__6_0() -> void
---- NotEnoughMoneyPopup::<OnInit>b__6_0 0x2ce5a50
02ce5a50: stp     x30, x19, [sp, #-0x10]!                    
02ce5a54: movi    d1, #0000000000000000                      
02ce5a58: movi    d2, #0000000000000000                      
02ce5a5c: mov     x19, x0                                    
02ce5a60: fmov    s0, #1.00000000                            
02ce5a64: mov     w0, #1                                     
02ce5a68: mov     w1, wzr                                    
02ce5a6c: mov     w2, wzr                                    
02ce5a70: mov     x3, xzr                                    
02ce5a74: bl      #0x2d84264                                 Framework.AudioHelper::PlaySound
02ce5a78: ldr     x8, [x19]                                  
02ce5a7c: mov     x0, x19                                    
02ce5a80: ldp     x2, x1, [x8, #0x198]                       
02ce5a84: ldp     x30, x19, [sp], #0x10                      
02ce5a88: br      x2                                         
## <OnInit>b__6_1() -> void
---- NotEnoughMoneyPopup::<OnInit>b__6_1 0x2ce5a8c
02ce5a8c: stp     x30, x19, [sp, #-0x10]!                    
02ce5a90: movi    d1, #0000000000000000                      
02ce5a94: movi    d2, #0000000000000000                      
02ce5a98: mov     x19, x0                                    
02ce5a9c: fmov    s0, #1.00000000                            
02ce5aa0: mov     w0, #1                                     
02ce5aa4: mov     w1, wzr                                    
02ce5aa8: mov     w2, wzr                                    
02ce5aac: mov     x3, xzr                                    
02ce5ab0: bl      #0x2d84264                                 Framework.AudioHelper::PlaySound
02ce5ab4: ldr     x8, [x19]                                  
02ce5ab8: mov     x0, x19                                    
02ce5abc: ldp     x2, x1, [x8, #0x198]                       
02ce5ac0: ldp     x30, x19, [sp], #0x10                      
02ce5ac4: br      x2                                         
## <OnInit>b__6_2() -> void
---- NotEnoughMoneyPopup::<OnInit>b__6_2 0x2ce5ac8
02ce5ac8: stp     x30, x23, [sp, #-0x30]!                    
02ce5acc: stp     x22, x21, [sp, #0x10]                      
02ce5ad0: stp     x20, x19, [sp, #0x20]                      
02ce5ad4: adrp    x23, #0x662f000                            
02ce5ad8: adrp    x22, #0x6265000                            
02ce5adc: adrp    x20, #0x6264000                            
02ce5ae0: adrp    x21, #0x6268000                            
02ce5ae4: ldr     x22, [x22, #0x310]                         MS:WejoyService.Singleton`1::get_Instance
02ce5ae8: ldrb    w8, [x23, #0xde0]                          
02ce5aec: ldr     x20, [x20, #0xf90]                         T:System.Action
02ce5af0: ldr     x21, [x21, #0x1b8]                         M:NotEnoughMoneyPopup::<OnInit>b__6_3
02ce5af4: mov     x19, x0                                    
02ce5af8: tbnz    w8, #0, #0x2ce5b34                         
02ce5afc: adrp    x0, #0x6264000                             
02ce5b00: ldr     x0, [x0, #0xf90]                           T:System.Action
02ce5b04: bl      #0x2b70db0                                 fn_2b70db0
02ce5b08: adrp    x0, #0x6268000                             
02ce5b0c: ldr     x0, [x0, #0x1b8]                           M:NotEnoughMoneyPopup::<OnInit>b__6_3
02ce5b10: bl      #0x2b70db0                                 fn_2b70db0
02ce5b14: adrp    x0, #0x6265000                             
02ce5b18: ldr     x0, [x0, #0x310]                           MS:WejoyService.Singleton`1::get_Instance
02ce5b1c: bl      #0x2b70db0                                 fn_2b70db0
02ce5b20: adrp    x0, #0x6268000                             
02ce5b24: ldr     x0, [x0, #0x1c0]                           S:'get_money'
02ce5b28: bl      #0x2b70db0                                 fn_2b70db0
02ce5b2c: mov     w8, #1                                     
02ce5b30: strb    w8, [x23, #0xde0]                          
02ce5b34: movi    d1, #0000000000000000                      
02ce5b38: movi    d2, #0000000000000000                      
02ce5b3c: mov     w0, #1                                     
02ce5b40: fmov    s0, #1.00000000                            
02ce5b44: mov     w1, wzr                                    
02ce5b48: mov     w2, wzr                                    
02ce5b4c: mov     x3, xzr                                    
02ce5b50: bl      #0x2d84264                                 Framework.AudioHelper::PlaySound
02ce5b54: ldr     x0, [x22]                                  M:AdsManager::<OnApplicationPause>b__26_0
02ce5b58: bl      #0x3be7218                                 fn_3be7218
02ce5b5c: ldr     x8, [x20]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02ce5b60: mov     x20, x0                                    
02ce5b64: mov     x0, x8                                     
02ce5b68: bl      #0x2b7104c                                 fn_2b7104c
02ce5b6c: ldr     x2, [x21]                                  S:'{0}/2'
02ce5b70: mov     x1, x19                                    
02ce5b74: mov     x3, xzr                                    
02ce5b78: mov     x21, x0                                    
02ce5b7c: bl      #0x4d8ddbc                                 System.Action::.ctor
02ce5b80: cbz     x20, #0x2ce5bac                            
02ce5b84: adrp    x8, #0x6268000                             
02ce5b88: mov     x0, x20                                    
02ce5b8c: mov     x2, x21                                    
02ce5b90: ldr     x8, [x8, #0x1c0]                           S:'get_money'
02ce5b94: ldp     x20, x19, [sp, #0x20]                      
02ce5b98: ldp     x22, x21, [sp, #0x10]                      
02ce5b9c: mov     x3, xzr                                    
02ce5ba0: ldr     x1, [x8]                                   S:'{0}/2'
02ce5ba4: ldp     x30, x23, [sp], #0x30                      
02ce5ba8: b       #0x2c8a2c0                                 AdsManager::ShowRewarded
02ce5bac: bl      #0x2b7105c                                 fn_2b7105c
## <OnInit>b__6_3() -> void
---- NotEnoughMoneyPopup::<OnInit>b__6_3 0x2ce5bb0
02ce5bb0: stp     x30, x23, [sp, #-0x30]!                    
02ce5bb4: stp     x22, x21, [sp, #0x10]                      
02ce5bb8: stp     x20, x19, [sp, #0x20]                      
02ce5bbc: adrp    x22, #0x662f000                            
02ce5bc0: adrp    x23, #0x6266000                            
02ce5bc4: adrp    x20, #0x6264000                            
02ce5bc8: adrp    x21, #0x6268000                            
02ce5bcc: ldr     x23, [x23, #0xaa0]                         MS:MonoSingleton`1::get_Instance
02ce5bd0: ldrb    w8, [x22, #0xde1]                          
02ce5bd4: ldr     x20, [x20, #0xf90]                         T:System.Action
02ce5bd8: ldr     x21, [x21, #0x1c8]                         M:NotEnoughMoneyPopup::OnCoinCompleted
02ce5bdc: mov     x19, x0                                    
02ce5be0: tbnz    w8, #0, #0x2ce5c10                         
02ce5be4: adrp    x0, #0x6264000                             
02ce5be8: ldr     x0, [x0, #0xf90]                           T:System.Action
02ce5bec: bl      #0x2b70db0                                 fn_2b70db0
02ce5bf0: adrp    x0, #0x6266000                             
02ce5bf4: ldr     x0, [x0, #0xaa0]                           MS:MonoSingleton`1::get_Instance
02ce5bf8: bl      #0x2b70db0                                 fn_2b70db0
02ce5bfc: adrp    x0, #0x6268000                             
02ce5c00: ldr     x0, [x0, #0x1c8]                           M:NotEnoughMoneyPopup::OnCoinCompleted
02ce5c04: bl      #0x2b70db0                                 fn_2b70db0
02ce5c08: mov     w8, #1                                     
02ce5c0c: strb    w8, [x22, #0xde1]                          
02ce5c10: ldr     x0, [x23]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ce5c14: bl      #0x3769600                                 fn_3769600
02ce5c18: ldr     x8, [x20]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02ce5c1c: mov     x20, x0                                    
02ce5c20: mov     x0, x8                                     
02ce5c24: bl      #0x2b7104c                                 fn_2b7104c
02ce5c28: ldr     x2, [x21]                                  S:'{0}/2'
02ce5c2c: mov     x1, x19                                    
02ce5c30: mov     x3, xzr                                    
02ce5c34: mov     x21, x0                                    
02ce5c38: bl      #0x4d8ddbc                                 System.Action::.ctor
02ce5c3c: cbz     x20, #0x2ce5c70                            
02ce5c40: mov     x0, x20                                    
02ce5c44: mov     w1, #0x3e8                                 
02ce5c48: mov     w2, #0xa                                   
02ce5c4c: mov     x3, x21                                    
02ce5c50: bl      #0x2cdaf30                                 MoneyManager::CollectMoney
02ce5c54: ldr     x8, [x19]                                  
02ce5c58: mov     x0, x19                                    
02ce5c5c: ldp     x20, x19, [sp, #0x20]                      
02ce5c60: ldp     x2, x1, [x8, #0x198]                       
02ce5c64: ldp     x22, x21, [sp, #0x10]                      
02ce5c68: ldp     x30, x23, [sp], #0x30                      
02ce5c6c: br      x2                                         
02ce5c70: bl      #0x2b7105c                                 fn_2b7105c
