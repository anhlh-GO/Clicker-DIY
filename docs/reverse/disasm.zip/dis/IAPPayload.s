#### CLASS IAPPayload parent= object
#   field json                           string                                             off=0x10 attr=6 
#   field signature                      string                                             off=0x18 attr=6 
## .ctor() -> void
---- IAPPayload::.ctor 0x2ca7f28
02ca7f28: mov     x1, xzr                                    
02ca7f2c: b       #0x4e53e9c                                 System.Object::.ctor
