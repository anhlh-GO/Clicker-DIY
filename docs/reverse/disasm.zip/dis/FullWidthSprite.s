#### CLASS FullWidthSprite parent= UnityEngine.MonoBehaviour
## Start() -> void
---- FullWidthSprite::Start 0x2cae4f8
02cae4f8: b       #0x2cae4fc                                 FullWidthSprite::FitSpriteToScreenWidth
## FitSpriteToScreenWidth() -> void
---- FullWidthSprite::FitSpriteToScreenWidth 0x2cae4fc
02cae4fc: sub     sp, sp, #0x60                              
02cae500: stp     d9, d8, [sp, #0x20]                        
02cae504: str     x30, [sp, #0x30]                           
02cae508: stp     x22, x21, [sp, #0x40]                      
02cae50c: stp     x20, x19, [sp, #0x50]                      
02cae510: adrp    x21, #0x662f000                            
02cae514: adrp    x22, #0x6266000                            
02cae518: adrp    x20, #0x6263000                            
02cae51c: ldrb    w8, [x21, #0xb4b]                          
02cae520: ldr     x22, [x22, #0x910]                         MS:UnityEngine.Component::GetComponent
02cae524: ldr     x20, [x20, #0x918]                         T:UnityEngine.Object
02cae528: mov     x19, x0                                    
02cae52c: tbnz    w8, #0, #0x2cae550                         
02cae530: adrp    x0, #0x6266000                             
02cae534: ldr     x0, [x0, #0x910]                           MS:UnityEngine.Component::GetComponent
02cae538: bl      #0x2b70db0                                 fn_2b70db0
02cae53c: adrp    x0, #0x6263000                             
02cae540: ldr     x0, [x0, #0x918]                           T:UnityEngine.Object
02cae544: bl      #0x2b70db0                                 fn_2b70db0
02cae548: mov     w8, #1                                     
02cae54c: strb    w8, [x21, #0xb4b]                          
02cae550: ldr     x1, [x22]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cae554: mov     x0, x19                                    
02cae558: bl      #0x3140c84                                 fn_3140c84
02cae55c: ldr     x8, [x20]                                  &2c5bbd4(=a9bd7bfdd503233f)
02cae560: mov     x20, x0                                    
02cae564: ldr     w9, [x8, #0xe4]                            
02cae568: cbnz    w9, #0x2cae574                             
02cae56c: mov     x0, x8                                     
02cae570: bl      #0x2b70f30                                 fn_2b70f30
02cae574: mov     x0, x20                                    
02cae578: mov     x1, xzr                                    
02cae57c: mov     x2, xzr                                    
02cae580: bl      #0x5b37d84                                 UnityEngine.Object::op_Equality
02cae584: tbnz    w0, #0, #0x2cae64c                         
02cae588: mov     x0, xzr                                    
02cae58c: bl      #0x5aefe28                                 UnityEngine.Camera::get_main
02cae590: cbz     x0, #0x2cae664                             
02cae594: mov     x1, xzr                                    
02cae598: bl      #0x5aedba0                                 UnityEngine.Camera::get_orthographicSize
02cae59c: mov     x0, xzr                                    
02cae5a0: fmov    s8, s0                                     
02cae5a4: bl      #0x5afb6fc                                 UnityEngine.Screen::get_width
02cae5a8: mov     w21, w0                                    
02cae5ac: mov     x0, xzr                                    
02cae5b0: bl      #0x5afb724                                 UnityEngine.Screen::get_height
02cae5b4: cbz     x20, #0x2cae664                            
02cae5b8: mov     w22, w0                                    
02cae5bc: add     x8, sp, #8                                 
02cae5c0: mov     x0, x20                                    
02cae5c4: mov     x1, xzr                                    
02cae5c8: bl      #0x5b02028                                 UnityEngine.Renderer::get_bounds
02cae5cc: ldr     s9, [sp, #0x14]                            
02cae5d0: mov     x0, x19                                    
02cae5d4: mov     x1, xzr                                    
02cae5d8: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02cae5dc: cbz     x0, #0x2cae664                             
02cae5e0: fadd    s0, s8, s8                                 
02cae5e4: scvtf   s1, w21                                    
02cae5e8: mov     x1, xzr                                    
02cae5ec: fmul    s0, s0, s1                                 
02cae5f0: scvtf   s1, w22                                    
02cae5f4: fdiv    s0, s0, s1                                 
02cae5f8: fadd    s1, s9, s9                                 
02cae5fc: fdiv    s8, s0, s1                                 
02cae600: bl      #0x5b46ff0                                 UnityEngine.Transform::get_localScale
02cae604: fcmp    s8, s0                                     
02cae608: b.mi    #0x2cae64c                                 
02cae60c: mov     x0, x19                                    
02cae610: mov     x1, xzr                                    
02cae614: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02cae618: mov     x20, x0                                    
02cae61c: mov     x0, x19                                    
02cae620: mov     x1, xzr                                    
02cae624: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02cae628: cbz     x0, #0x2cae664                             
02cae62c: mov     x1, xzr                                    
02cae630: bl      #0x5b46ff0                                 UnityEngine.Transform::get_localScale
02cae634: cbz     x20, #0x2cae664                            
02cae638: fmov    s0, s8                                     
02cae63c: fmov    s2, #1.00000000                            
02cae640: mov     x0, x20                                    
02cae644: mov     x1, xzr                                    
02cae648: bl      #0x5b470cc                                 UnityEngine.Transform::set_localScale
02cae64c: ldp     x20, x19, [sp, #0x50]                      
02cae650: ldr     x30, [sp, #0x30]                           
02cae654: ldp     x22, x21, [sp, #0x40]                      
02cae658: ldp     d9, d8, [sp, #0x20]                        
02cae65c: add     sp, sp, #0x60                              
02cae660: ret                                                
02cae664: bl      #0x2b7105c                                 fn_2b7105c
## .ctor() -> void
---- FullWidthSprite::.ctor 0x2cae668
02cae668: mov     x1, xzr                                    
02cae66c: b       #0x5b397b0                                 UnityEngine.MonoBehaviour::.ctor
