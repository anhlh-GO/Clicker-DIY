#### CLASS Framework.TypeExtensions/<>c parent= object
#   field <>9                            Framework.TypeExtensions/<>c                       off=0x0 attr=36 
#   field <>9__3_0                       System.Func`2<System.Reflection.FieldInfo,bool>    off=0x8 attr=16 
## .cctor() -> void
---- Framework.TypeExtensions/<>c::.cctor 0x2cbc088
02cbc088: str     x30, [sp, #-0x20]!                         
02cbc08c: stp     x20, x19, [sp, #0x10]                      
02cbc090: adrp    x19, #0x662f000                            
02cbc094: adrp    x20, #0x6266000                            
02cbc098: ldrb    w8, [x19, #0xbf7]                          
02cbc09c: ldr     x20, [x20, #0xf38]                         T:Framework.TypeExtensions/<>c
02cbc0a0: tbnz    w8, #0, #0x2cbc0b8                         
02cbc0a4: adrp    x0, #0x6266000                             
02cbc0a8: ldr     x0, [x0, #0xf38]                           T:Framework.TypeExtensions/<>c
02cbc0ac: bl      #0x2b70db0                                 fn_2b70db0
02cbc0b0: mov     w8, #1                                     
02cbc0b4: strb    w8, [x19, #0xbf7]                          
02cbc0b8: ldr     x0, [x20]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cbc0bc: bl      #0x2b7104c                                 fn_2b7104c
02cbc0c0: mov     x1, xzr                                    
02cbc0c4: mov     x19, x0                                    
02cbc0c8: bl      #0x4e53e9c                                 System.Object::.ctor
02cbc0cc: ldr     x8, [x20]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cbc0d0: mov     x1, x19                                    
02cbc0d4: ldr     x8, [x8, #0xb8]                            
02cbc0d8: str     x19, [x8]                                  
02cbc0dc: ldr     x8, [x20]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cbc0e0: ldp     x20, x19, [sp, #0x10]                      
02cbc0e4: ldr     x0, [x8, #0xb8]                            
02cbc0e8: ldr     x30, [sp], #0x20                           
02cbc0ec: b       #0x2b70d54                                 
## .ctor() -> void
---- Framework.TypeExtensions/<>c::.ctor 0x2cbc0f0
02cbc0f0: mov     x1, xzr                                    
02cbc0f4: b       #0x4e53e9c                                 System.Object::.ctor
## <GetSerializedFields>b__3_0(System.Reflection.FieldInfo field) -> bool
---- Framework.TypeExtensions/<>c::<GetSerializedFields>b__3_0 0x2cbc0f8
02cbc0f8: str     x30, [sp, #-0x20]!                         
02cbc0fc: stp     x20, x19, [sp, #0x10]                      
02cbc100: adrp    x20, #0x662f000                            
02cbc104: mov     x19, x1                                    
02cbc108: ldrb    w8, [x20, #0xbf8]                          
02cbc10c: tbnz    w8, #0, #0x2cbc124                         
02cbc110: adrp    x0, #0x6266000                             
02cbc114: ldr     x0, [x0, #0xfc8]                           MS:System.Reflection.CustomAttributeExtensions::GetCustomAttribute
02cbc118: bl      #0x2b70db0                                 fn_2b70db0
02cbc11c: mov     w8, #1                                     
02cbc120: strb    w8, [x20, #0xbf8]                          
02cbc124: cbz     x19, #0x2cbc168                            
02cbc128: mov     x0, x19                                    
02cbc12c: mov     x1, xzr                                    
02cbc130: bl      #0x4d4cf0c                                 System.Reflection.FieldInfo::get_IsPublic
02cbc134: tbz     w0, #0, #0x2cbc140                         
02cbc138: mov     w0, #1                                     
02cbc13c: b       #0x2cbc15c                                 
02cbc140: adrp    x8, #0x6266000                             
02cbc144: mov     x0, x19                                    
02cbc148: ldr     x8, [x8, #0xfc8]                           MS:System.Reflection.CustomAttributeExtensions::GetCustomAttribute
02cbc14c: ldr     x1, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cbc150: bl      #0x315ae2c                                 fn_315ae2c
02cbc154: cmp     x0, #0                                     
02cbc158: cset    w0, ne                                     
02cbc15c: ldp     x20, x19, [sp, #0x10]                      
02cbc160: ldr     x30, [sp], #0x20                           
02cbc164: ret                                                
02cbc168: bl      #0x2b7105c                                 fn_2b7105c
#### CLASS Framework.TypeExtensions parent= object
#   field unitySerializablePrimitiveTypes System.Collections.Generic.HashSet`1<System.Type>  off=0x0 attr=31 
#   field unitySerializableBuiltinTypes  System.Collections.Generic.HashSet`1<System.Type>  off=0x8 attr=31 
## IsUnitySerializable(System.Type type) -> bool
---- Framework.TypeExtensions::IsUnitySerializable 0x2cbb5c8
02cbb5c8: stp     x30, x21, [sp, #-0x20]!                    
02cbb5cc: stp     x20, x19, [sp, #0x10]                      
02cbb5d0: adrp    x20, #0x662f000                            
02cbb5d4: mov     x19, x0                                    
02cbb5d8: ldrb    w8, [x20, #0xbf1]                          
02cbb5dc: tbnz    w8, #0, #0x2cbb60c                         
02cbb5e0: adrp    x0, #0x6266000                             
02cbb5e4: ldr     x0, [x0, #0xf00]                           MS:System.Collections.Generic.HashSet`1::Contains
02cbb5e8: bl      #0x2b70db0                                 fn_2b70db0
02cbb5ec: adrp    x0, #0x6266000                             
02cbb5f0: ldr     x0, [x0, #0xf08]                           T:UnityEngine.Object
02cbb5f4: bl      #0x2b70db0                                 fn_2b70db0
02cbb5f8: adrp    x0, #0x6266000                             
02cbb5fc: ldr     x0, [x0, #0xf10]                           T:Framework.TypeExtensions
02cbb600: bl      #0x2b70db0                                 fn_2b70db0
02cbb604: mov     w8, #1                                     
02cbb608: strb    w8, [x20, #0xbf1]                          
02cbb60c: cbz     x19, #0x2cbb750                            
02cbb610: mov     x0, x19                                    
02cbb614: mov     x1, xzr                                    
02cbb618: bl      #0x4e2c264                                 System.Type::get_IsAbstract
02cbb61c: tbz     w0, #0, #0x2cbb628                         
02cbb620: mov     w0, wzr                                    
02cbb624: b       #0x2cbb710                                 
02cbb628: adrp    x21, #0x6266000                            
02cbb62c: ldr     x21, [x21, #0xf10]                         T:Framework.TypeExtensions
02cbb630: ldr     x0, [x21]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cbb634: ldr     w8, [x0, #0xe4]                            [62660e4]=0 f=0,0
02cbb638: cbnz    w8, #0x2cbb640                             
02cbb63c: bl      #0x2b70f30                                 fn_2b70f30
02cbb640: mov     x0, x19                                    
02cbb644: bl      #0x2cbb754                                 Framework.TypeExtensions::<IsUnitySerializable>g__IsCustomSerializableType|2_1
02cbb648: tbnz    w0, #0, #0x2cbb70c                         
02cbb64c: adrp    x8, #0x6263000                             
02cbb650: ldr     x8, [x8, #0x970]                           &6645c70(=0)
02cbb654: ldr     x0, [x8, #0xe0]                            &2c5bf4c(=a9be7bfdd503233f)
02cbb658: adrp    x8, #0x6266000                             
02cbb65c: ldr     x8, [x8, #0xf08]                           T:UnityEngine.Object
02cbb660: ldr     w9, [x0, #0xe4]                            [62660e4]=0 f=0,0
02cbb664: ldr     x20, [x8]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cbb668: cbnz    w9, #0x2cbb670                             
02cbb66c: bl      #0x2b70f30                                 fn_2b70f30
02cbb670: mov     x0, x20                                    
02cbb674: mov     x1, xzr                                    
02cbb678: bl      #0x4e20e5c                                 System.Type::GetTypeFromHandle
02cbb67c: ldr     x8, [x21]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cbb680: mov     x20, x0                                    
02cbb684: ldr     w9, [x8, #0xe4]                            [62660e4]=0 f=0,0
02cbb688: cbnz    w9, #0x2cbb694                             
02cbb68c: mov     x0, x8                                     
02cbb690: bl      #0x2b70f30                                 fn_2b70f30
02cbb694: mov     x0, x19                                    
02cbb698: mov     x1, x20                                    
02cbb69c: bl      #0x2cbb814                                 Framework.TypeExtensions::InheritsFrom
02cbb6a0: tbz     w0, #0, #0x2cbb6bc                         
02cbb6a4: ldr     x8, [x19]                                  
02cbb6a8: mov     x0, x19                                    
02cbb6ac: ldr     x9, [x8, #0x3e8]                           T:UnityEngine.Purchasing.PurchasesFetchFailureReason
02cbb6b0: ldr     x1, [x8, #0x3f0]                           S:'Purchases fetch failed: {0}'
02cbb6b4: blr     x9                                         
02cbb6b8: tbz     w0, #0, #0x2cbb70c                         
02cbb6bc: ldr     x8, [x19]                                  
02cbb6c0: mov     x0, x19                                    
02cbb6c4: ldr     x9, [x8, #0x5b8]                           MS:NFramework.GoogleSheetConfigSO`1::.ctor
02cbb6c8: ldr     x1, [x8, #0x5c0]                           MS:System.Collections.Generic.List`1::get_Count
02cbb6cc: blr     x9                                         
02cbb6d0: tbnz    w0, #0, #0x2cbb70c                         
02cbb6d4: ldr     x0, [x21]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cbb6d8: ldr     w8, [x0, #0xe4]                            [62660e4]=0 f=0,0
02cbb6dc: cbnz    w8, #0x2cbb6e8                             
02cbb6e0: bl      #0x2b70f30                                 fn_2b70f30
02cbb6e4: ldr     x0, [x21]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cbb6e8: ldr     x8, [x0, #0xb8]                            S:'banner_native_refresh_time'
02cbb6ec: ldr     x0, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cbb6f0: cbz     x0, #0x2cbb750                             
02cbb6f4: adrp    x20, #0x6266000                            
02cbb6f8: mov     x1, x19                                    
02cbb6fc: ldr     x20, [x20, #0xf00]                         MS:System.Collections.Generic.HashSet`1::Contains
02cbb700: ldr     x2, [x20]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cbb704: bl      #0x4986fec                                 fn_4986fec
02cbb708: tbz     w0, #0, #0x2cbb71c                         
02cbb70c: mov     w0, #1                                     
02cbb710: ldp     x20, x19, [sp, #0x10]                      
02cbb714: ldp     x30, x21, [sp], #0x20                      
02cbb718: ret                                                
02cbb71c: ldr     x0, [x21]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cbb720: ldr     w8, [x0, #0xe4]                            [62660e4]=0 f=0,0
02cbb724: cbnz    w8, #0x2cbb730                             
02cbb728: bl      #0x2b70f30                                 fn_2b70f30
02cbb72c: ldr     x0, [x21]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cbb730: ldr     x8, [x0, #0xb8]                            S:'banner_native_refresh_time'
02cbb734: ldr     x0, [x8, #8]                               MS:Firebase.Extensions.TaskExtension::ContinueWithOnMainThread
02cbb738: cbz     x0, #0x2cbb750                             
02cbb73c: ldr     x2, [x20]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cbb740: mov     x1, x19                                    
02cbb744: ldp     x20, x19, [sp, #0x10]                      
02cbb748: ldp     x30, x21, [sp], #0x20                      
02cbb74c: b       #0x4986fec                                 
02cbb750: bl      #0x2b7105c                                 fn_2b7105c
## GetSerializedFields(System.Type type) -> System.Collections.Generic.IEnumerable`1<System.Reflection.FieldInfo>
---- Framework.TypeExtensions::GetSerializedFields 0x2cbb8c0
02cbb8c0: stp     x30, x23, [sp, #-0x30]!                    
02cbb8c4: stp     x22, x21, [sp, #0x10]                      
02cbb8c8: stp     x20, x19, [sp, #0x20]                      
02cbb8cc: adrp    x20, #0x662f000                            
02cbb8d0: mov     x19, x0                                    
02cbb8d4: ldrb    w8, [x20, #0xbf2]                          
02cbb8d8: tbnz    w8, #0, #0x2cbb914                         
02cbb8dc: adrp    x0, #0x6266000                             
02cbb8e0: ldr     x0, [x0, #0xf20]                           MS:System.Linq.Enumerable::Where
02cbb8e4: bl      #0x2b70db0                                 fn_2b70db0
02cbb8e8: adrp    x0, #0x6266000                             
02cbb8ec: ldr     x0, [x0, #0xf28]                           T:type10363(k15)
02cbb8f0: bl      #0x2b70db0                                 fn_2b70db0
02cbb8f4: adrp    x0, #0x6266000                             
02cbb8f8: ldr     x0, [x0, #0xf30]                           M:Framework.TypeExtensions/<>c::<GetSerializedFields>b__3_0
02cbb8fc: bl      #0x2b70db0                                 fn_2b70db0
02cbb900: adrp    x0, #0x6266000                             
02cbb904: ldr     x0, [x0, #0xf38]                           T:Framework.TypeExtensions/<>c
02cbb908: bl      #0x2b70db0                                 fn_2b70db0
02cbb90c: mov     w8, #1                                     
02cbb910: strb    w8, [x20, #0xbf2]                          
02cbb914: cbz     x19, #0x2cbb9e0                            
02cbb918: ldr     x8, [x19]                                  
02cbb91c: adrp    x22, #0x6266000                            
02cbb920: mov     x0, x19                                    
02cbb924: ldr     x22, [x22, #0xf38]                         T:Framework.TypeExtensions/<>c
02cbb928: mov     w1, #0x34                                  
02cbb92c: ldr     x9, [x8, #0x6f8]                           
02cbb930: ldr     x2, [x8, #0x700]                           
02cbb934: blr     x9                                         
02cbb938: ldr     x8, [x22]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cbb93c: mov     x19, x0                                    
02cbb940: ldr     w9, [x8, #0xe4]                            
02cbb944: cbnz    w9, #0x2cbb954                             
02cbb948: mov     x0, x8                                     
02cbb94c: bl      #0x2b70f30                                 fn_2b70f30
02cbb950: ldr     x8, [x22]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cbb954: ldr     x9, [x8, #0xb8]                            
02cbb958: adrp    x23, #0x6266000                            
02cbb95c: ldr     x20, [x9, #8]                              
02cbb960: ldr     x23, [x23, #0xf20]                         MS:System.Linq.Enumerable::Where
02cbb964: cbnz    x20, #0x2cbb9c4                            
02cbb968: ldr     w10, [x8, #0xe4]                           
02cbb96c: cbnz    w10, #0x2cbb980                            
02cbb970: mov     x0, x8                                     
02cbb974: bl      #0x2b70f30                                 fn_2b70f30
02cbb978: ldr     x8, [x22]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cbb97c: ldr     x9, [x8, #0xb8]                            
02cbb980: adrp    x8, #0x6266000                             
02cbb984: ldr     x8, [x8, #0xf28]                           T:type10363(k15)
02cbb988: ldr     x21, [x9]                                  
02cbb98c: ldr     x0, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cbb990: bl      #0x2b7104c                                 fn_2b7104c
02cbb994: adrp    x8, #0x6266000                             
02cbb998: mov     x1, x21                                    
02cbb99c: mov     x3, xzr                                    
02cbb9a0: ldr     x8, [x8, #0xf30]                           M:Framework.TypeExtensions/<>c::<GetSerializedFields>b__3_0
02cbb9a4: mov     x20, x0                                    
02cbb9a8: ldr     x2, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cbb9ac: bl      #0x4940cf8                                 fn_4940cf8
02cbb9b0: ldr     x8, [x22]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cbb9b4: mov     x1, x20                                    
02cbb9b8: ldr     x0, [x8, #0xb8]                            S:'banner_native_refresh_time'
02cbb9bc: str     x20, [x0, #8]!                             
02cbb9c0: bl      #0x2b70d54                                 fn_2b70d54
02cbb9c4: mov     x0, x19                                    
02cbb9c8: mov     x1, x20                                    
02cbb9cc: ldr     x2, [x23]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cbb9d0: ldp     x20, x19, [sp, #0x20]                      
02cbb9d4: ldp     x22, x21, [sp, #0x10]                      
02cbb9d8: ldp     x30, x23, [sp], #0x30                      
02cbb9dc: b       #0x319fec4                                 
02cbb9e0: bl      #0x2b7105c                                 fn_2b7105c
## IsSubclassOfRawGeneric(System.Type typeToCheck, System.Type generic) -> bool
---- Framework.TypeExtensions::IsSubclassOfRawGeneric 0x2cbb9e4
02cbb9e4: str     x30, [sp, #-0x30]!                         
02cbb9e8: stp     x22, x21, [sp, #0x10]                      
02cbb9ec: stp     x20, x19, [sp, #0x20]                      
02cbb9f0: adrp    x22, #0x6263000                            
02cbb9f4: mov     x19, x1                                    
02cbb9f8: ldr     x22, [x22, #0x970]                         &6645c70(=0)
02cbb9fc: mov     x20, x0                                    
02cbba00: ldr     x0, [x22, #0xe0]                           &2c5bf4c(=a9be7bfdd503233f)
02cbba04: ldr     w8, [x0, #0xe4]                            
02cbba08: cbnz    w8, #0x2cbba10                             
02cbba0c: bl      #0x2b70f30                                 fn_2b70f30
02cbba10: mov     x0, x20                                    
02cbba14: mov     x1, xzr                                    
02cbba18: mov     x2, xzr                                    
02cbba1c: bl      #0x4e2b088                                 System.Type::op_Inequality
02cbba20: tbz     w0, #0, #0x2cbbacc                         
02cbba24: ldr     x0, [x22, #0xe0]                           &2c5bf4c(=a9be7bfdd503233f)
02cbba28: ldr     x21, [x22, #0x10]                          &2c498bc(=aa1f03e0d503245f)
02cbba2c: ldr     w8, [x0, #0xe4]                            
02cbba30: cbnz    w8, #0x2cbba38                             
02cbba34: bl      #0x2b70f30                                 fn_2b70f30
02cbba38: add     x0, x21, #0x20                             
02cbba3c: mov     x1, xzr                                    
02cbba40: bl      #0x4e20e5c                                 System.Type::GetTypeFromHandle
02cbba44: mov     x1, x0                                     
02cbba48: mov     x0, x20                                    
02cbba4c: mov     x2, xzr                                    
02cbba50: bl      #0x4e2b088                                 System.Type::op_Inequality
02cbba54: tbz     w0, #0, #0x2cbbacc                         
02cbba58: cbz     x20, #0x2cbbae8                            
02cbba5c: ldr     x8, [x20]                                  
02cbba60: mov     x0, x20                                    
02cbba64: ldr     x9, [x8, #0x3d8]                           
02cbba68: ldr     x1, [x8, #0x3e0]                           
02cbba6c: blr     x9                                         
02cbba70: mov     x21, x20                                   
02cbba74: tbz     w0, #0, #0x2cbba90                         
02cbba78: ldr     x8, [x20]                                  
02cbba7c: mov     x0, x20                                    
02cbba80: ldr     x9, [x8, #0x458]                           
02cbba84: ldr     x1, [x8, #0x460]                           
02cbba88: blr     x9                                         
02cbba8c: mov     x21, x0                                    
02cbba90: ldr     x0, [x22, #0xe0]                           &2c5bf4c(=a9be7bfdd503233f)
02cbba94: ldr     w8, [x0, #0xe4]                            
02cbba98: cbnz    w8, #0x2cbbaa0                             
02cbba9c: bl      #0x2b70f30                                 fn_2b70f30
02cbbaa0: mov     x0, x19                                    
02cbbaa4: mov     x1, x21                                    
02cbbaa8: mov     x2, xzr                                    
02cbbaac: bl      #0x4e2a3e8                                 System.Type::op_Equality
02cbbab0: tbnz    w0, #0, #0x2cbbad4                         
02cbbab4: ldr     x8, [x20]                                  
02cbbab8: mov     x0, x20                                    
02cbbabc: ldr     x9, [x8, #0x898]                           
02cbbac0: ldr     x1, [x8, #0x8a0]                           
02cbbac4: blr     x9                                         
02cbbac8: b       #0x2cbb9fc                                 
02cbbacc: mov     w0, wzr                                    
02cbbad0: b       #0x2cbbad8                                 
02cbbad4: mov     w0, #1                                     
02cbbad8: ldp     x20, x19, [sp, #0x20]                      
02cbbadc: ldp     x22, x21, [sp, #0x10]                      
02cbbae0: ldr     x30, [sp], #0x30                           
02cbbae4: ret                                                
02cbbae8: bl      #0x2b7105c                                 fn_2b7105c
## InheritsFrom(System.Type typeToCheck, System.Type baseType) -> bool
---- Framework.TypeExtensions::InheritsFrom 0x2cbb814
02cbb814: stp     x30, x21, [sp, #-0x20]!                    
02cbb818: stp     x20, x19, [sp, #0x10]                      
02cbb81c: adrp    x21, #0x662f000                            
02cbb820: mov     x19, x1                                    
02cbb824: mov     x20, x0                                    
02cbb828: ldrb    w8, [x21, #0xbf3]                          
02cbb82c: tbnz    w8, #0, #0x2cbb844                         
02cbb830: adrp    x0, #0x6266000                             
02cbb834: ldr     x0, [x0, #0xf10]                           T:Framework.TypeExtensions
02cbb838: bl      #0x2b70db0                                 fn_2b70db0
02cbb83c: mov     w8, #1                                     
02cbb840: strb    w8, [x21, #0xbf3]                          
02cbb844: cbz     x19, #0x2cbb8bc                            
02cbb848: ldr     x8, [x19]                                  
02cbb84c: mov     x0, x19                                    
02cbb850: ldr     x9, [x8, #0x3d8]                           
02cbb854: ldr     x1, [x8, #0x3e0]                           
02cbb858: blr     x9                                         
02cbb85c: tbz     w0, #0, #0x2cbb88c                         
02cbb860: adrp    x8, #0x6266000                             
02cbb864: ldr     x8, [x8, #0xf10]                           T:Framework.TypeExtensions
02cbb868: ldr     x0, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cbb86c: ldr     w8, [x0, #0xe4]                            [62660e4]=0 f=0,0
02cbb870: cbnz    w8, #0x2cbb878                             
02cbb874: bl      #0x2b70f30                                 fn_2b70f30
02cbb878: mov     x0, x20                                    
02cbb87c: mov     x1, x19                                    
02cbb880: bl      #0x2cbb9e4                                 Framework.TypeExtensions::IsSubclassOfRawGeneric
02cbb884: and     w21, w0, #1                                
02cbb888: b       #0x2cbb890                                 
02cbb88c: mov     w21, wzr                                   
02cbb890: ldr     x8, [x19]                                  
02cbb894: mov     x0, x19                                    
02cbb898: mov     x1, x20                                    
02cbb89c: ldr     x9, [x8, #0x2b8]                           T:type55989(k15)
02cbb8a0: ldr     x2, [x8, #0x2c0]                           T:type56094(k15)
02cbb8a4: blr     x9                                         
02cbb8a8: ldp     x20, x19, [sp, #0x10]                      
02cbb8ac: and     w8, w0, #1                                 
02cbb8b0: orr     w0, w21, w8                                
02cbb8b4: ldp     x30, x21, [sp], #0x20                      
02cbb8b8: ret                                                
02cbb8bc: bl      #0x2b7105c                                 fn_2b7105c
## .cctor() -> void
---- Framework.TypeExtensions::.cctor 0x2cbbaec
02cbbaec: stp     x29, x30, [sp, #-0x60]!                    
02cbbaf0: stp     x28, x27, [sp, #0x10]                      
02cbbaf4: stp     x26, x25, [sp, #0x20]                      
02cbbaf8: stp     x24, x23, [sp, #0x30]                      
02cbbafc: stp     x22, x21, [sp, #0x40]                      
02cbbb00: stp     x20, x19, [sp, #0x50]                      
02cbbb04: adrp    x19, #0x662f000                            
02cbbb08: adrp    x23, #0x6266000                            
02cbbb0c: adrp    x22, #0x6266000                            
02cbbb10: ldrb    w8, [x19, #0xbf4]                          
02cbbb14: ldr     x23, [x23, #0xf40]                         T:type10855(k15)
02cbbb18: ldr     x22, [x22, #0xf48]                         MS:System.Collections.Generic.HashSet`1::.ctor
02cbbb1c: tbnz    w8, #0, #0x2cbbbf4                         
02cbbb20: adrp    x0, #0x6266000                             
02cbbb24: ldr     x0, [x0, #0xf50]                           T:UnityEngine.AnimationCurve
02cbbb28: bl      #0x2b70db0                                 fn_2b70db0
02cbbb2c: adrp    x0, #0x6266000                             
02cbbb30: ldr     x0, [x0, #0xf58]                           T:UnityEngine.Color32
02cbbb34: bl      #0x2b70db0                                 fn_2b70db0
02cbbb38: adrp    x0, #0x6266000                             
02cbbb3c: ldr     x0, [x0, #0xf60]                           T:UnityEngine.Color
02cbbb40: bl      #0x2b70db0                                 fn_2b70db0
02cbbb44: adrp    x0, #0x6266000                             
02cbbb48: ldr     x0, [x0, #0xf68]                           T:UnityEngine.GUIStyle
02cbbb4c: bl      #0x2b70db0                                 fn_2b70db0
02cbbb50: adrp    x0, #0x6266000                             
02cbbb54: ldr     x0, [x0, #0xf70]                           T:UnityEngine.Gradient
02cbbb58: bl      #0x2b70db0                                 fn_2b70db0
02cbbb5c: adrp    x0, #0x6266000                             
02cbbb60: ldr     x0, [x0, #0xf78]                           MS:System.Collections.Generic.HashSet`1::Add
02cbbb64: bl      #0x2b70db0                                 fn_2b70db0
02cbbb68: adrp    x0, #0x6266000                             
02cbbb6c: ldr     x0, [x0, #0xf48]                           MS:System.Collections.Generic.HashSet`1::.ctor
02cbbb70: bl      #0x2b70db0                                 fn_2b70db0
02cbbb74: adrp    x0, #0x6266000                             
02cbbb78: ldr     x0, [x0, #0xf40]                           T:type10855(k15)
02cbbb7c: bl      #0x2b70db0                                 fn_2b70db0
02cbbb80: adrp    x0, #0x6266000                             
02cbbb84: ldr     x0, [x0, #0xf80]                           T:UnityEngine.LayerMask
02cbbb88: bl      #0x2b70db0                                 fn_2b70db0
02cbbb8c: adrp    x0, #0x6266000                             
02cbbb90: ldr     x0, [x0, #0xf88]                           T:UnityEngine.Matrix4x4
02cbbb94: bl      #0x2b70db0                                 fn_2b70db0
02cbbb98: adrp    x0, #0x6266000                             
02cbbb9c: ldr     x0, [x0, #0xf90]                           T:UnityEngine.Quaternion
02cbbba0: bl      #0x2b70db0                                 fn_2b70db0
02cbbba4: adrp    x0, #0x6266000                             
02cbbba8: ldr     x0, [x0, #0xf98]                           T:UnityEngine.RectOffset
02cbbbac: bl      #0x2b70db0                                 fn_2b70db0
02cbbbb0: adrp    x0, #0x6266000                             
02cbbbb4: ldr     x0, [x0, #0xfa0]                           T:UnityEngine.Rect
02cbbbb8: bl      #0x2b70db0                                 fn_2b70db0
02cbbbbc: adrp    x0, #0x6266000                             
02cbbbc0: ldr     x0, [x0, #0xf10]                           T:Framework.TypeExtensions
02cbbbc4: bl      #0x2b70db0                                 fn_2b70db0
02cbbbc8: adrp    x0, #0x6266000                             
02cbbbcc: ldr     x0, [x0, #0xfa8]                           T:UnityEngine.Vector2
02cbbbd0: bl      #0x2b70db0                                 fn_2b70db0
02cbbbd4: adrp    x0, #0x6266000                             
02cbbbd8: ldr     x0, [x0, #0xfb0]                           T:UnityEngine.Vector3
02cbbbdc: bl      #0x2b70db0                                 fn_2b70db0
02cbbbe0: adrp    x0, #0x6266000                             
02cbbbe4: ldr     x0, [x0, #0xfb8]                           T:UnityEngine.Vector4
02cbbbe8: bl      #0x2b70db0                                 fn_2b70db0
02cbbbec: mov     w8, #1                                     
02cbbbf0: strb    w8, [x19, #0xbf4]                          
02cbbbf4: ldr     x0, [x23]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cbbbf8: bl      #0x2b7104c                                 fn_2b7104c
02cbbbfc: ldr     x1, [x22]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cbbc00: mov     x19, x0                                    
02cbbc04: bl      #0x49868e0                                 fn_49868e0
02cbbc08: adrp    x25, #0x6263000                            
02cbbc0c: ldr     x25, [x25, #0x970]                         &6645c70(=0)
02cbbc10: ldr     x0, [x25, #0xe0]                           &2c5bf4c(=a9be7bfdd503233f)
02cbbc14: ldr     x20, [x25, #0x28]                          [6263028]=0 f=0,0
02cbbc18: ldr     w8, [x0, #0xe4]                            [62660e4]=0 f=0,0
02cbbc1c: cbnz    w8, #0x2cbbc24                             
02cbbc20: bl      #0x2b70f30                                 fn_2b70f30
02cbbc24: add     x0, x20, #0x20                             
02cbbc28: mov     x1, xzr                                    
02cbbc2c: bl      #0x4e20e5c                                 System.Type::GetTypeFromHandle
02cbbc30: cbz     x19, #0x2cbc010                            
02cbbc34: adrp    x21, #0x6266000                            
02cbbc38: adrp    x20, #0x6266000                            
02cbbc3c: adrp    x24, #0x6266000                            
02cbbc40: ldr     x21, [x21, #0xf78]                         MS:System.Collections.Generic.HashSet`1::Add
02cbbc44: ldr     x20, [x20, #0xf10]                         T:Framework.TypeExtensions
02cbbc48: ldr     x24, [x24, #0xfa8]                         T:UnityEngine.Vector2
02cbbc4c: mov     x1, x0                                     
02cbbc50: mov     x0, x19                                    
02cbbc54: ldr     x2, [x21]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cbbc58: bl      #0x4987adc                                 fn_4987adc
02cbbc5c: ldr     x8, [x25, #0x18]                           &2c5d934(=d65f03c0d503245f)
02cbbc60: mov     x1, xzr                                    
02cbbc64: add     x0, x8, #0x20                              
02cbbc68: bl      #0x4e20e5c                                 System.Type::GetTypeFromHandle
02cbbc6c: ldr     x2, [x21]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cbbc70: mov     x1, x0                                     
02cbbc74: mov     x0, x19                                    
02cbbc78: bl      #0x4987adc                                 fn_4987adc
02cbbc7c: ldr     x8, [x25, #0x30]                           &16c9019(=424f4c475f32314e)
02cbbc80: mov     x1, xzr                                    
02cbbc84: add     x0, x8, #0x20                              
02cbbc88: bl      #0x4e20e5c                                 System.Type::GetTypeFromHandle
02cbbc8c: ldr     x2, [x21]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cbbc90: mov     x1, x0                                     
02cbbc94: mov     x0, x19                                    
02cbbc98: bl      #0x4987adc                                 fn_4987adc
02cbbc9c: ldr     x8, [x25, #0x88]                           &2c5d934(=d65f03c0d503245f)
02cbbca0: mov     x1, xzr                                    
02cbbca4: add     x0, x8, #0x20                              
02cbbca8: bl      #0x4e20e5c                                 System.Type::GetTypeFromHandle
02cbbcac: ldr     x2, [x21]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cbbcb0: mov     x1, x0                                     
02cbbcb4: mov     x0, x19                                    
02cbbcb8: bl      #0x4987adc                                 fn_4987adc
02cbbcbc: ldr     x8, [x25, #0x80]                           &2c498bc(=aa1f03e0d503245f)
02cbbcc0: mov     x1, xzr                                    
02cbbcc4: add     x0, x8, #0x20                              
02cbbcc8: bl      #0x4e20e5c                                 System.Type::GetTypeFromHandle
02cbbccc: ldr     x2, [x21]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cbbcd0: mov     x1, x0                                     
02cbbcd4: mov     x0, x19                                    
02cbbcd8: bl      #0x4987adc                                 fn_4987adc
02cbbcdc: ldr     x8, [x25, #0x78]                           &2c498b4(=d65f03c0d503245f)
02cbbce0: mov     x1, xzr                                    
02cbbce4: add     x0, x8, #0x20                              
02cbbce8: bl      #0x4e20e5c                                 System.Type::GetTypeFromHandle
02cbbcec: ldr     x2, [x21]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cbbcf0: mov     x1, x0                                     
02cbbcf4: mov     x0, x19                                    
02cbbcf8: bl      #0x4987adc                                 fn_4987adc
02cbbcfc: ldr     x8, [x25, #0x48]                           &6263098(=0)
02cbbd00: mov     x1, xzr                                    
02cbbd04: add     x0, x8, #0x20                              
02cbbd08: bl      #0x4e20e5c                                 System.Type::GetTypeFromHandle
02cbbd0c: ldr     x2, [x21]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cbbd10: mov     x1, x0                                     
02cbbd14: mov     x0, x19                                    
02cbbd18: bl      #0x4987adc                                 fn_4987adc
02cbbd1c: ldr     x8, [x25, #0x50]                           &2c497a8(=2a1f03e0d503245f)
02cbbd20: mov     x1, xzr                                    
02cbbd24: add     x0, x8, #0x20                              
02cbbd28: bl      #0x4e20e5c                                 System.Type::GetTypeFromHandle
02cbbd2c: ldr     x2, [x21]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cbbd30: mov     x1, x0                                     
02cbbd34: mov     x0, x19                                    
02cbbd38: bl      #0x4987adc                                 fn_4987adc
02cbbd3c: ldr     x8, [x25, #0x68]                           &2c497cc(=d65f03c0d503245f)
02cbbd40: mov     x1, xzr                                    
02cbbd44: add     x0, x8, #0x20                              
02cbbd48: bl      #0x4e20e5c                                 System.Type::GetTypeFromHandle
02cbbd4c: ldr     x2, [x21]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cbbd50: mov     x1, x0                                     
02cbbd54: mov     x0, x19                                    
02cbbd58: bl      #0x4987adc                                 fn_4987adc
02cbbd5c: ldr     x8, [x25, #0x70]                           &2c5bd48(=a9bd7bfdd503233f)
02cbbd60: mov     x1, xzr                                    
02cbbd64: add     x0, x8, #0x20                              
02cbbd68: bl      #0x4e20e5c                                 System.Type::GetTypeFromHandle
02cbbd6c: ldr     x2, [x21]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cbbd70: mov     x1, x0                                     
02cbbd74: mov     x0, x19                                    
02cbbd78: bl      #0x4987adc                                 fn_4987adc
02cbbd7c: ldr     x8, [x25, #0x38]                           &6260bd8(=0)
02cbbd80: mov     x1, xzr                                    
02cbbd84: add     x0, x8, #0x20                              
02cbbd88: bl      #0x4e20e5c                                 System.Type::GetTypeFromHandle
02cbbd8c: ldr     x2, [x21]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cbbd90: mov     x1, x0                                     
02cbbd94: mov     x0, x19                                    
02cbbd98: bl      #0x4987adc                                 fn_4987adc
02cbbd9c: ldr     x8, [x25, #0x40]                           [6263040]=0 f=0,0
02cbbda0: mov     x1, xzr                                    
02cbbda4: add     x0, x8, #0x20                              
02cbbda8: bl      #0x4e20e5c                                 System.Type::GetTypeFromHandle
02cbbdac: ldr     x2, [x21]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cbbdb0: mov     x1, x0                                     
02cbbdb4: mov     x0, x19                                    
02cbbdb8: bl      #0x4987adc                                 fn_4987adc
02cbbdbc: ldr     x8, [x25, #0x90]                           &2c5beb4(=14c8d222d503245f)
02cbbdc0: mov     x1, xzr                                    
02cbbdc4: add     x0, x8, #0x20                              
02cbbdc8: bl      #0x4e20e5c                                 System.Type::GetTypeFromHandle
02cbbdcc: ldr     x2, [x21]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cbbdd0: mov     x1, x0                                     
02cbbdd4: mov     x0, x19                                    
02cbbdd8: bl      #0x4987adc                                 fn_4987adc
02cbbddc: ldr     x8, [x20]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cbbde0: mov     x1, x19                                    
02cbbde4: ldr     x8, [x8, #0xb8]                            
02cbbde8: str     x19, [x8]                                  
02cbbdec: ldr     x8, [x20]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cbbdf0: ldr     x0, [x8, #0xb8]                            
02cbbdf4: bl      #0x2b70d54                                 fn_2b70d54
02cbbdf8: ldr     x0, [x23]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cbbdfc: bl      #0x2b7104c                                 fn_2b7104c
02cbbe00: ldr     x1, [x22]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cbbe04: mov     x19, x0                                    
02cbbe08: bl      #0x49868e0                                 fn_49868e0
02cbbe0c: ldr     x0, [x24]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cbbe10: mov     x1, xzr                                    
02cbbe14: bl      #0x4e20e5c                                 System.Type::GetTypeFromHandle
02cbbe18: cbz     x19, #0x2cbc010                            
02cbbe1c: adrp    x22, #0x6266000                            
02cbbe20: adrp    x23, #0x6266000                            
02cbbe24: adrp    x24, #0x6266000                            
02cbbe28: adrp    x20, #0x6266000                            
02cbbe2c: adrp    x29, #0x6266000                            
02cbbe30: adrp    x28, #0x6266000                            
02cbbe34: adrp    x27, #0x6266000                            
02cbbe38: adrp    x26, #0x6266000                            
02cbbe3c: adrp    x25, #0x6266000                            
02cbbe40: ldr     x22, [x22, #0xfb0]                         T:UnityEngine.Vector3
02cbbe44: ldr     x23, [x23, #0xfb8]                         T:UnityEngine.Vector4
02cbbe48: ldr     x24, [x24, #0xfa0]                         T:UnityEngine.Rect
02cbbe4c: ldr     x20, [x20, #0xf90]                         T:UnityEngine.Quaternion
02cbbe50: ldr     x29, [x29, #0xf88]                         T:UnityEngine.Matrix4x4
02cbbe54: ldr     x28, [x28, #0xf60]                         T:UnityEngine.Color
02cbbe58: ldr     x27, [x27, #0xf58]                         T:UnityEngine.Color32
02cbbe5c: ldr     x26, [x26, #0xf80]                         T:UnityEngine.LayerMask
02cbbe60: ldr     x25, [x25, #0xf50]                         T:UnityEngine.AnimationCurve
02cbbe64: ldr     x2, [x21]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cbbe68: mov     x1, x0                                     
02cbbe6c: mov     x0, x19                                    
02cbbe70: bl      #0x4987adc                                 fn_4987adc
02cbbe74: ldr     x0, [x22]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cbbe78: mov     x1, xzr                                    
02cbbe7c: bl      #0x4e20e5c                                 System.Type::GetTypeFromHandle
02cbbe80: ldr     x2, [x21]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cbbe84: mov     x1, x0                                     
02cbbe88: mov     x0, x19                                    
02cbbe8c: bl      #0x4987adc                                 fn_4987adc
02cbbe90: ldr     x0, [x23]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cbbe94: mov     x1, xzr                                    
02cbbe98: bl      #0x4e20e5c                                 System.Type::GetTypeFromHandle
02cbbe9c: ldr     x2, [x21]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cbbea0: mov     x1, x0                                     
02cbbea4: mov     x0, x19                                    
02cbbea8: bl      #0x4987adc                                 fn_4987adc
02cbbeac: ldr     x0, [x24]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cbbeb0: mov     x1, xzr                                    
02cbbeb4: bl      #0x4e20e5c                                 System.Type::GetTypeFromHandle
02cbbeb8: ldr     x2, [x21]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cbbebc: mov     x1, x0                                     
02cbbec0: mov     x0, x19                                    
02cbbec4: bl      #0x4987adc                                 fn_4987adc
02cbbec8: ldr     x0, [x20]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cbbecc: mov     x1, xzr                                    
02cbbed0: bl      #0x4e20e5c                                 System.Type::GetTypeFromHandle
02cbbed4: ldr     x2, [x21]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cbbed8: mov     x1, x0                                     
02cbbedc: mov     x0, x19                                    
02cbbee0: bl      #0x4987adc                                 fn_4987adc
02cbbee4: ldr     x0, [x29]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cbbee8: mov     x1, xzr                                    
02cbbeec: bl      #0x4e20e5c                                 System.Type::GetTypeFromHandle
02cbbef0: ldr     x2, [x21]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cbbef4: mov     x1, x0                                     
02cbbef8: mov     x0, x19                                    
02cbbefc: bl      #0x4987adc                                 fn_4987adc
02cbbf00: ldr     x0, [x28]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cbbf04: mov     x1, xzr                                    
02cbbf08: bl      #0x4e20e5c                                 System.Type::GetTypeFromHandle
02cbbf0c: ldr     x2, [x21]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cbbf10: mov     x1, x0                                     
02cbbf14: mov     x0, x19                                    
02cbbf18: bl      #0x4987adc                                 fn_4987adc
02cbbf1c: ldr     x0, [x27]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cbbf20: mov     x1, xzr                                    
02cbbf24: bl      #0x4e20e5c                                 System.Type::GetTypeFromHandle
02cbbf28: ldr     x2, [x21]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cbbf2c: mov     x1, x0                                     
02cbbf30: mov     x0, x19                                    
02cbbf34: bl      #0x4987adc                                 fn_4987adc
02cbbf38: ldr     x0, [x26]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cbbf3c: mov     x1, xzr                                    
02cbbf40: bl      #0x4e20e5c                                 System.Type::GetTypeFromHandle
02cbbf44: ldr     x2, [x21]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cbbf48: mov     x1, x0                                     
02cbbf4c: mov     x0, x19                                    
02cbbf50: bl      #0x4987adc                                 fn_4987adc
02cbbf54: ldr     x0, [x25]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cbbf58: mov     x1, xzr                                    
02cbbf5c: bl      #0x4e20e5c                                 System.Type::GetTypeFromHandle
02cbbf60: ldr     x2, [x21]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cbbf64: mov     x1, x0                                     
02cbbf68: mov     x0, x19                                    
02cbbf6c: bl      #0x4987adc                                 fn_4987adc
02cbbf70: adrp    x8, #0x6266000                             
02cbbf74: mov     x1, xzr                                    
02cbbf78: ldr     x8, [x8, #0xf70]                           T:UnityEngine.Gradient
02cbbf7c: ldr     x0, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cbbf80: bl      #0x4e20e5c                                 System.Type::GetTypeFromHandle
02cbbf84: ldr     x2, [x21]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cbbf88: mov     x1, x0                                     
02cbbf8c: mov     x0, x19                                    
02cbbf90: bl      #0x4987adc                                 fn_4987adc
02cbbf94: adrp    x8, #0x6266000                             
02cbbf98: mov     x1, xzr                                    
02cbbf9c: ldr     x8, [x8, #0xf98]                           T:UnityEngine.RectOffset
02cbbfa0: ldr     x0, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cbbfa4: bl      #0x4e20e5c                                 System.Type::GetTypeFromHandle
02cbbfa8: ldr     x2, [x21]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cbbfac: mov     x1, x0                                     
02cbbfb0: mov     x0, x19                                    
02cbbfb4: bl      #0x4987adc                                 fn_4987adc
02cbbfb8: adrp    x8, #0x6266000                             
02cbbfbc: mov     x1, xzr                                    
02cbbfc0: ldr     x8, [x8, #0xf68]                           T:UnityEngine.GUIStyle
02cbbfc4: ldr     x0, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cbbfc8: bl      #0x4e20e5c                                 System.Type::GetTypeFromHandle
02cbbfcc: ldr     x2, [x21]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cbbfd0: mov     x1, x0                                     
02cbbfd4: mov     x0, x19                                    
02cbbfd8: bl      #0x4987adc                                 fn_4987adc
02cbbfdc: adrp    x8, #0x6266000                             
02cbbfe0: mov     x1, x19                                    
02cbbfe4: ldr     x8, [x8, #0xf10]                           T:Framework.TypeExtensions
02cbbfe8: ldp     x22, x21, [sp, #0x40]                      
02cbbfec: ldp     x24, x23, [sp, #0x30]                      
02cbbff0: ldr     x8, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cbbff4: ldp     x26, x25, [sp, #0x20]                      
02cbbff8: ldp     x28, x27, [sp, #0x10]                      
02cbbffc: ldr     x0, [x8, #0xb8]                            S:'banner_native_refresh_time'
02cbc000: str     x19, [x0, #8]!                             
02cbc004: ldp     x20, x19, [sp, #0x50]                      
02cbc008: ldp     x29, x30, [sp], #0x60                      
02cbc00c: b       #0x2b70d54                                 
02cbc010: bl      #0x2b7105c                                 fn_2b7105c
## <IsUnitySerializable>g__IsSystemType|2_0(System.Type typeToCheck) -> bool
---- Framework.TypeExtensions::<IsUnitySerializable>g__IsSystemType|2_0 0x2cbc014
02cbc014: str     x30, [sp, #-0x20]!                         
02cbc018: stp     x20, x19, [sp, #0x10]                      
02cbc01c: adrp    x20, #0x662f000                            
02cbc020: mov     x19, x0                                    
02cbc024: ldrb    w8, [x20, #0xbf5]                          
02cbc028: tbnz    w8, #0, #0x2cbc040                         
02cbc02c: adrp    x0, #0x6266000                             
02cbc030: ldr     x0, [x0, #0xfc0]                           S:'System'
02cbc034: bl      #0x2b70db0                                 fn_2b70db0
02cbc038: mov     w8, #1                                     
02cbc03c: strb    w8, [x20, #0xbf5]                          
02cbc040: cbz     x19, #0x2cbc084                            
02cbc044: ldr     x8, [x19]                                  
02cbc048: mov     x0, x19                                    
02cbc04c: ldr     x9, [x8, #0x2d8]                           
02cbc050: ldr     x1, [x8, #0x2e0]                           
02cbc054: blr     x9                                         
02cbc058: cbz     x0, #0x2cbc078                             
02cbc05c: adrp    x8, #0x6266000                             
02cbc060: mov     x2, xzr                                    
02cbc064: ldr     x8, [x8, #0xfc0]                           S:'System'
02cbc068: ldp     x20, x19, [sp, #0x10]                      
02cbc06c: ldr     x1, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cbc070: ldr     x30, [sp], #0x20                           
02cbc074: b       #0x4ca532c                                 System.String::StartsWith
02cbc078: ldp     x20, x19, [sp, #0x10]                      
02cbc07c: ldr     x30, [sp], #0x20                           
02cbc080: ret                                                
02cbc084: bl      #0x2b7105c                                 fn_2b7105c
## <IsUnitySerializable>g__IsCustomSerializableType|2_1(System.Type typeToCheck) -> bool
---- Framework.TypeExtensions::<IsUnitySerializable>g__IsCustomSerializableType|2_1 0x2cbb754
02cbb754: str     x30, [sp, #-0x20]!                         
02cbb758: stp     x20, x19, [sp, #0x10]                      
02cbb75c: adrp    x20, #0x662f000                            
02cbb760: mov     x19, x0                                    
02cbb764: ldrb    w8, [x20, #0xbf6]                          
02cbb768: tbnz    w8, #0, #0x2cbb78c                         
02cbb76c: adrp    x0, #0x6266000                             
02cbb770: ldr     x0, [x0, #0xf18]                           MS:System.Linq.Enumerable::Any
02cbb774: bl      #0x2b70db0                                 fn_2b70db0
02cbb778: adrp    x0, #0x6266000                             
02cbb77c: ldr     x0, [x0, #0xf10]                           T:Framework.TypeExtensions
02cbb780: bl      #0x2b70db0                                 fn_2b70db0
02cbb784: mov     w8, #1                                     
02cbb788: strb    w8, [x20, #0xbf6]                          
02cbb78c: cbz     x19, #0x2cbb810                            
02cbb790: ldr     x8, [x19]                                  
02cbb794: mov     x0, x19                                    
02cbb798: ldr     x9, [x8, #0x288]                           
02cbb79c: ldr     x1, [x8, #0x290]                           
02cbb7a0: blr     x9                                         
02cbb7a4: tbz     w0, #0, #0x2cbb7fc                         
02cbb7a8: adrp    x20, #0x6266000                            
02cbb7ac: ldr     x20, [x20, #0xf10]                         T:Framework.TypeExtensions
02cbb7b0: ldr     x0, [x20]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cbb7b4: ldr     w8, [x0, #0xe4]                            [62660e4]=0 f=0,0
02cbb7b8: cbnz    w8, #0x2cbb7c0                             
02cbb7bc: bl      #0x2b70f30                                 fn_2b70f30
02cbb7c0: mov     x0, x19                                    
02cbb7c4: bl      #0x2cbb8c0                                 Framework.TypeExtensions::GetSerializedFields
02cbb7c8: adrp    x8, #0x6266000                             
02cbb7cc: ldr     x8, [x8, #0xf18]                           MS:System.Linq.Enumerable::Any
02cbb7d0: ldr     x1, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cbb7d4: bl      #0x317b3f0                                 fn_317b3f0
02cbb7d8: tbz     w0, #0, #0x2cbb7fc                         
02cbb7dc: ldr     x0, [x20]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cbb7e0: ldr     w8, [x0, #0xe4]                            [62660e4]=0 f=0,0
02cbb7e4: cbnz    w8, #0x2cbb7ec                             
02cbb7e8: bl      #0x2b70f30                                 fn_2b70f30
02cbb7ec: mov     x0, x19                                    
02cbb7f0: bl      #0x2cbc014                                 Framework.TypeExtensions::<IsUnitySerializable>g__IsSystemType|2_0
02cbb7f4: eor     w8, w0, #1                                 
02cbb7f8: b       #0x2cbb800                                 
02cbb7fc: mov     w8, wzr                                    
02cbb800: ldp     x20, x19, [sp, #0x10]                      
02cbb804: and     w0, w8, #1                                 
02cbb808: ldr     x30, [sp], #0x20                           
02cbb80c: ret                                                
02cbb810: bl      #0x2b7105c                                 fn_2b7105c
