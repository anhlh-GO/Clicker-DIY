#### CLASS Clicker.DecorKeycapType parent= int
#   field value__                        int                                                off=0x10 attr=606 
#   field None                           Clicker.DecorKeycapType                            off=0x0 attr=8056 
#   field OnTop                          Clicker.DecorKeycapType                            off=0x0 attr=8056 
#   field Replace                        Clicker.DecorKeycapType                            off=0x0 attr=8056 
#   field CustomPaint                    Clicker.DecorKeycapType                            off=0x0 attr=8056 
#   field ReplaceButOnBase               Clicker.DecorKeycapType                            off=0x0 attr=8056 
