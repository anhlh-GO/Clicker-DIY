#### CLASS Blindbag.DoorScreen parent= ScreenBase
#   field _openDoorButton                UnityEngine.UI.Button                              off=0x38 attr=1 SerializeField
#   field OnOpenDoorAction               UnityEngine.Events.UnityAction                     off=0x40 attr=6 
## OnInit(UIManager uiManager) -> void
---- Blindbag.DoorScreen::OnInit 0x2d575e4
02d575e4: stp     x30, x21, [sp, #-0x20]!                    
02d575e8: stp     x20, x19, [sp, #0x10]                      
02d575ec: adrp    x21, #0x6630000                            
02d575f0: mov     x20, x1                                    
02d575f4: mov     x19, x0                                    
02d575f8: ldrb    w8, [x21, #0x293]                          
02d575fc: tbnz    w8, #0, #0x2d57620                         
02d57600: adrp    x0, #0x626b000                             
02d57604: ldr     x0, [x0, #0xa68]                           M:Blindbag.DoorScreen::<OnInit>b__2_0
02d57608: bl      #0x2b70db0                                 fn_2b70db0
02d5760c: adrp    x0, #0x6265000                             
02d57610: ldr     x0, [x0, #0x3f0]                           T:UnityEngine.Events.UnityAction
02d57614: bl      #0x2b70db0                                 fn_2b70db0
02d57618: mov     w8, #1                                     
02d5761c: strb    w8, [x21, #0x293]                          
02d57620: mov     x0, x19                                    
02d57624: mov     x1, x20                                    
02d57628: mov     x2, xzr                                    
02d5762c: bl      #0x2cdd3c4                                 UIBase::OnInit
02d57630: ldr     x8, [x19, #0x38]                           ._openDoorButton
02d57634: cbz     x8, #0x2d57684                             
02d57638: adrp    x9, #0x6265000                             
02d5763c: adrp    x21, #0x626b000                            
02d57640: ldr     x9, [x9, #0x3f0]                           T:UnityEngine.Events.UnityAction
02d57644: ldr     x21, [x21, #0xa68]                         M:Blindbag.DoorScreen::<OnInit>b__2_0
02d57648: ldr     x20, [x8, #0x100]                          
02d5764c: ldr     x0, [x9]                                   M:AdsManager::<OnApplicationPause>b__26_0
02d57650: bl      #0x2b7104c                                 fn_2b7104c
02d57654: ldr     x2, [x21]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d57658: mov     x1, x19                                    
02d5765c: mov     x3, xzr                                    
02d57660: mov     x21, x0                                    
02d57664: bl      #0x5b4cf98                                 UnityEngine.Events.UnityAction::.ctor
02d57668: cbz     x20, #0x2d57684                            
02d5766c: mov     x0, x20                                    
02d57670: ldp     x20, x19, [sp, #0x10]                      
02d57674: mov     x1, x21                                    
02d57678: mov     x2, xzr                                    
02d5767c: ldp     x30, x21, [sp], #0x20                      
02d57680: b       #0x5b4d0ac                                 UnityEngine.Events.UnityEvent::AddListener
02d57684: bl      #0x2b7105c                                 fn_2b7105c
## OnShow() -> void
---- Blindbag.DoorScreen::OnShow 0x2d57688
02d57688: str     d8, [sp, #-0x40]!                          
02d5768c: str     x30, [sp, #8]                              
02d57690: stp     x24, x23, [sp, #0x10]                      
02d57694: stp     x22, x21, [sp, #0x20]                      
02d57698: stp     x20, x19, [sp, #0x30]                      
02d5769c: adrp    x20, #0x6630000                            
02d576a0: mov     x19, x0                                    
02d576a4: ldrb    w8, [x20, #0x294]                          
02d576a8: tbnz    w8, #0, #0x2d576d8                         
02d576ac: adrp    x0, #0x6265000                             
02d576b0: ldr     x0, [x0, #0xb38]                           T:DevTrack
02d576b4: bl      #0x2b70db0                                 fn_2b70db0
02d576b8: adrp    x0, #0x6266000                             
02d576bc: ldr     x0, [x0, #0xb48]                           MS:MonoSingleton`1::get_Instance
02d576c0: bl      #0x2b70db0                                 fn_2b70db0
02d576c4: adrp    x0, #0x6265000                             
02d576c8: ldr     x0, [x0, #0x310]                           MS:WejoyService.Singleton`1::get_Instance
02d576cc: bl      #0x2b70db0                                 fn_2b70db0
02d576d0: mov     w8, #1                                     
02d576d4: strb    w8, [x20, #0x294]                          
02d576d8: mov     x0, x19                                    
02d576dc: mov     x1, xzr                                    
02d576e0: bl      #0x2cdd6b8                                 UIBase::OnShow
02d576e4: mov     x0, xzr                                    
02d576e8: bl      #0x2d6eec8                                 Framework.AudioManager::get_Instance
02d576ec: cbz     x0, #0x2d57818                             
02d576f0: fmov    s0, #1.00000000                            
02d576f4: adrp    x19, #0x6265000                            
02d576f8: mov     w1, #4                                     
02d576fc: ldr     x19, [x19, #0x310]                         MS:WejoyService.Singleton`1::get_Instance
02d57700: mov     x2, xzr                                    
02d57704: bl      #0x2d846d8                                 Framework.AudioManager::PlayMusic
02d57708: ldr     x0, [x19]                                  M:AdsManager::<OnApplicationPause>b__26_0
02d5770c: bl      #0x3be7218                                 fn_3be7218
02d57710: cbz     x0, #0x2d57818                             
02d57714: adrp    x23, #0x6266000                            
02d57718: mov     x1, xzr                                    
02d5771c: ldr     x23, [x23, #0xb48]                         MS:MonoSingleton`1::get_Instance
02d57720: bl      #0x2c8a7a4                                 AdsManager::ShowCollap
02d57724: ldr     x0, [x23]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d57728: bl      #0x3769600                                 fn_3769600
02d5772c: cbz     x0, #0x2d57818                             
02d57730: ldr     x19, [x0, #0x30]                           T:AdsManager/<>c__DisplayClass32_0
02d57734: ldr     x0, [x23]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d57738: bl      #0x3769600                                 fn_3769600
02d5773c: cbz     x0, #0x2d57818                             
02d57740: adrp    x24, #0x6265000                            
02d57744: mov     x8, x0                                     
02d57748: ldr     x24, [x24, #0xb38]                         T:DevTrack
02d5774c: ldr     w20, [x8, #0x3c]                           
02d57750: ldr     x0, [x24]                                  M:AdsManager::<OnApplicationPause>b__26_0
02d57754: ldr     w9, [x0, #0xe4]                            [62650e4]=0 f=0,0
02d57758: cbnz    w9, #0x2d57764                             
02d5775c: bl      #0x2b70f30                                 fn_2b70f30
02d57760: ldr     x0, [x24]                                  M:AdsManager::<OnApplicationPause>b__26_0
02d57764: ldr     x8, [x0, #0xb8]                            T:AdsManager/<>c__DisplayClass42_0
02d57768: mov     x0, xzr                                    
02d5776c: ldr     x21, [x8, #0x218]                          
02d57770: ldr     w22, [x8, #0x270]                          
02d57774: bl      #0x5b432fc                                 UnityEngine.Time::get_time
02d57778: ldr     x0, [x23]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d5777c: fmov    s8, s0                                     
02d57780: bl      #0x3769600                                 fn_3769600
02d57784: cbz     x0, #0x2d57818                             
02d57788: ldr     s0, [x0, #0x38]                            M:AdsManager/<>c__DisplayClass32_0::<ShowAppOpenLoading>g__OnComplete|0 ._openDoorButton
02d5778c: mov     x0, x19                                    
02d57790: mov     w1, w20                                    
02d57794: mov     x2, x21                                    
02d57798: mov     w3, w22                                    
02d5779c: mov     x4, xzr                                    
02d577a0: fsub    s0, s8, s0                                 
02d577a4: bl      #0x2c9c898                                 DevTrack::GameModeStepComplete
02d577a8: ldr     x0, [x23]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d577ac: bl      #0x3769600                                 fn_3769600
02d577b0: cbz     x0, #0x2d57818                             
02d577b4: ldr     x19, [x0, #0x30]                           T:AdsManager/<>c__DisplayClass32_0
02d577b8: ldr     x0, [x23]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d577bc: bl      #0x3769600                                 fn_3769600
02d577c0: cbz     x0, #0x2d57818                             
02d577c4: ldr     x8, [x24]                                  M:AdsManager::<OnApplicationPause>b__26_0
02d577c8: ldr     w1, [x0, #0x3c]                            [626503c]=0 f=0,0
02d577cc: mov     x0, x19                                    
02d577d0: mov     x4, xzr                                    
02d577d4: ldr     x8, [x8, #0xb8]                            
02d577d8: ldr     x2, [x8, #0x2a0]                           
02d577dc: ldr     w3, [x8, #0x2d0]                           
02d577e0: bl      #0x2c9c714                                 DevTrack::GameModeStepEnter
02d577e4: ldr     x0, [x23]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d577e8: bl      #0x3769600                                 fn_3769600
02d577ec: cbz     x0, #0x2d57818                             
02d577f0: ldr     x8, [x24]                                  M:AdsManager::<OnApplicationPause>b__26_0
02d577f4: ldp     x20, x19, [sp, #0x30]                      
02d577f8: ldp     x22, x21, [sp, #0x20]                      
02d577fc: ldr     x30, [sp, #8]                              
02d57800: ldr     x8, [x8, #0xb8]                            
02d57804: ldp     x24, x23, [sp, #0x10]                      
02d57808: ldr     x1, [x8, #0x2a0]                           
02d5780c: str     x1, [x0, #0x40]!                           .OnOpenDoorAction
02d57810: ldr     d8, [sp], #0x40                            
02d57814: b       #0x2b70d54                                 
02d57818: bl      #0x2b7105c                                 fn_2b7105c
## .ctor() -> void
---- Blindbag.DoorScreen::.ctor 0x2d5781c
02d5781c: mov     x1, xzr                                    
02d57820: b       #0x2cde678                                 ScreenBase::.ctor
## <OnInit>b__2_0() -> void
---- Blindbag.DoorScreen::<OnInit>b__2_0 0x2d57824
02d57824: str     d8, [sp, #-0x40]!                          
02d57828: str     x30, [sp, #8]                              
02d5782c: stp     x24, x23, [sp, #0x10]                      
02d57830: stp     x22, x21, [sp, #0x20]                      
02d57834: stp     x20, x19, [sp, #0x30]                      
02d57838: adrp    x20, #0x6630000                            
02d5783c: mov     x19, x0                                    
02d57840: ldrb    w8, [x20, #0x295]                          
02d57844: tbnz    w8, #0, #0x2d57880                         
02d57848: adrp    x0, #0x6266000                             
02d5784c: ldr     x0, [x0, #0x750]                           MS:DataManager::GetData
02d57850: bl      #0x2b70db0                                 fn_2b70db0
02d57854: adrp    x0, #0x6265000                             
02d57858: ldr     x0, [x0, #0xb38]                           T:DevTrack
02d5785c: bl      #0x2b70db0                                 fn_2b70db0
02d57860: adrp    x0, #0x6266000                             
02d57864: ldr     x0, [x0, #0x658]                           MS:MonoSingleton`1::get_Instance
02d57868: bl      #0x2b70db0                                 fn_2b70db0
02d5786c: adrp    x0, #0x6266000                             
02d57870: ldr     x0, [x0, #0xb48]                           MS:MonoSingleton`1::get_Instance
02d57874: bl      #0x2b70db0                                 fn_2b70db0
02d57878: mov     w8, #1                                     
02d5787c: strb    w8, [x20, #0x295]                          
02d57880: ldr     x0, [x19, #0x38]                           ._openDoorButton
02d57884: cbz     x0, #0x2d579e4                             
02d57888: mov     x1, xzr                                    
02d5788c: bl      #0x5b339ec                                 UnityEngine.Component::get_gameObject
02d57890: cbz     x0, #0x2d579e4                             
02d57894: adrp    x20, #0x6266000                            
02d57898: mov     w1, wzr                                    
02d5789c: mov     x2, xzr                                    
02d578a0: ldr     x20, [x20, #0x658]                         MS:MonoSingleton`1::get_Instance
02d578a4: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d578a8: ldr     x8, [x19, #0x40]                           .OnOpenDoorAction
02d578ac: cbz     x8, #0x2d578c0                             
02d578b0: ldr     x9, [x8, #0x18]                            
02d578b4: ldr     x0, [x8, #0x40]                            
02d578b8: ldr     x1, [x8, #0x28]                            
02d578bc: blr     x9                                         
02d578c0: ldr     x0, [x20]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d578c4: bl      #0x3769600                                 fn_3769600
02d578c8: cbz     x0, #0x2d579e4                             
02d578cc: adrp    x8, #0x6266000                             
02d578d0: ldr     x8, [x8, #0x750]                           MS:DataManager::GetData
02d578d4: ldr     x1, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d578d8: bl      #0x3168dd0                                 fn_3168dd0
02d578dc: cbz     x0, #0x2d579e4                             
02d578e0: ldr     x8, [x0, #0x20]                            S:'inter_ad_capping_time'
02d578e4: cbz     x8, #0x2d579e4                             
02d578e8: adrp    x23, #0x6266000                            
02d578ec: ldr     x23, [x23, #0xb48]                         MS:MonoSingleton`1::get_Instance
02d578f0: ldr     x0, [x23]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d578f4: bl      #0x3769600                                 fn_3769600
02d578f8: cbz     x0, #0x2d579e4                             
02d578fc: ldr     x19, [x0, #0x30]                           S:'popup_rate_on_off'
02d57900: ldr     x0, [x23]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d57904: bl      #0x3769600                                 fn_3769600
02d57908: cbz     x0, #0x2d579e4                             
02d5790c: adrp    x24, #0x6265000                            
02d57910: mov     x8, x0                                     
02d57914: ldr     x24, [x24, #0xb38]                         T:DevTrack
02d57918: ldr     w20, [x8, #0x3c]                           [626603c]=0 f=0,0
02d5791c: ldr     x0, [x24]                                  M:AdsManager::<OnApplicationPause>b__26_0
02d57920: ldr     w9, [x0, #0xe4]                            [62660e4]=0 f=0,0
02d57924: cbnz    w9, #0x2d57930                             
02d57928: bl      #0x2b70f30                                 fn_2b70f30
02d5792c: ldr     x0, [x24]                                  M:AdsManager::<OnApplicationPause>b__26_0
02d57930: ldr     x8, [x0, #0xb8]                            S:'banner_native_refresh_time'
02d57934: mov     x0, xzr                                    
02d57938: ldr     x21, [x8, #0x2a0]                          MS:System.Collections.Generic.HashSet`1::Clear
02d5793c: ldr     w22, [x8, #0x2d0]                          T:type56243(k15)
02d57940: bl      #0x5b432fc                                 UnityEngine.Time::get_time
02d57944: ldr     x0, [x23]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d57948: fmov    s8, s0                                     
02d5794c: bl      #0x3769600                                 fn_3769600
02d57950: cbz     x0, #0x2d579e4                             
02d57954: ldr     s0, [x0, #0x38]                            S:'native_collap_id' ._openDoorButton
02d57958: mov     x0, x19                                    
02d5795c: mov     w1, w20                                    
02d57960: mov     x2, x21                                    
02d57964: mov     w3, w22                                    
02d57968: mov     x4, xzr                                    
02d5796c: fsub    s0, s8, s0                                 
02d57970: bl      #0x2c9c898                                 DevTrack::GameModeStepComplete
02d57974: ldr     x0, [x23]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d57978: bl      #0x3769600                                 fn_3769600
02d5797c: cbz     x0, #0x2d579e4                             
02d57980: ldr     x19, [x0, #0x30]                           S:'popup_rate_on_off'
02d57984: ldr     x0, [x23]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d57988: bl      #0x3769600                                 fn_3769600
02d5798c: cbz     x0, #0x2d579e4                             
02d57990: ldr     x8, [x24]                                  M:AdsManager::<OnApplicationPause>b__26_0
02d57994: ldr     w1, [x0, #0x3c]                            [626603c]=0 f=0,0
02d57998: mov     x0, x19                                    
02d5799c: mov     x4, xzr                                    
02d579a0: ldr     x8, [x8, #0xb8]                            S:'banner_native_refresh_time'
02d579a4: ldr     x2, [x8, #0x2a8]                           T:UnityEngine.Purchasing.ICart
02d579a8: ldr     w3, [x8, #0x2d4]                           [62662d4]=0 f=0,0
02d579ac: bl      #0x2c9c714                                 DevTrack::GameModeStepEnter
02d579b0: ldr     x0, [x23]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d579b4: bl      #0x3769600                                 fn_3769600
02d579b8: cbz     x0, #0x2d579e4                             
02d579bc: ldr     x8, [x24]                                  M:AdsManager::<OnApplicationPause>b__26_0
02d579c0: ldp     x20, x19, [sp, #0x30]                      
02d579c4: ldp     x22, x21, [sp, #0x20]                      
02d579c8: ldr     x30, [sp, #8]                              
02d579cc: ldr     x8, [x8, #0xb8]                            S:'banner_native_refresh_time'
02d579d0: ldp     x24, x23, [sp, #0x10]                      
02d579d4: ldr     x1, [x8, #0x2a8]                           T:UnityEngine.Purchasing.ICart
02d579d8: str     x1, [x0, #0x40]!                           .OnOpenDoorAction
02d579dc: ldr     d8, [sp], #0x40                            
02d579e0: b       #0x2b70d54                                 
02d579e4: bl      #0x2b7105c                                 fn_2b7105c
