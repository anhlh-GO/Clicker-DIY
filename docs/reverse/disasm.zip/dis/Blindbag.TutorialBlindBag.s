#### CLASS Blindbag.TutorialBlindBag parent= MonoSingleton`1<Blindbag.TutorialBlindBag>
#   field _tutorialClickBagOnShelf       UnityEngine.GameObject                             off=0x20 attr=1 SerializeField
#   field _tutorialScanItem              UnityEngine.GameObject                             off=0x28 attr=1 SerializeField
#   field _tutorialUnbox                 UnityEngine.GameObject                             off=0x30 attr=1 SerializeField
## get__canTutorial() -> bool
---- Blindbag.TutorialBlindBag::get__canTutorial 0x2d567cc
02d567cc: str     x30, [sp, #-0x20]!                         
02d567d0: stp     x20, x19, [sp, #0x10]                      
02d567d4: adrp    x19, #0x6630000                            
02d567d8: adrp    x20, #0x6266000                            
02d567dc: ldrb    w8, [x19, #0x285]                          
02d567e0: ldr     x20, [x20, #0x658]                         MS:MonoSingleton`1::get_Instance
02d567e4: tbnz    w8, #0, #0x2d56808                         
02d567e8: adrp    x0, #0x6266000                             
02d567ec: ldr     x0, [x0, #0x750]                           MS:DataManager::GetData
02d567f0: bl      #0x2b70db0                                 fn_2b70db0
02d567f4: adrp    x0, #0x6266000                             
02d567f8: ldr     x0, [x0, #0x658]                           MS:MonoSingleton`1::get_Instance
02d567fc: bl      #0x2b70db0                                 fn_2b70db0
02d56800: mov     w8, #1                                     
02d56804: strb    w8, [x19, #0x285]                          
02d56808: ldr     x0, [x20]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d5680c: bl      #0x3769600                                 fn_3769600
02d56810: cbz     x0, #0x2d56848                             
02d56814: adrp    x8, #0x6266000                             
02d56818: ldr     x8, [x8, #0x750]                           MS:DataManager::GetData
02d5681c: ldr     x1, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d56820: bl      #0x3168dd0                                 fn_3168dd0
02d56824: cbz     x0, #0x2d56848                             
02d56828: ldr     x8, [x0, #0x20]                            S:'inter_ad_capping_time' ._tutorialClickBagOnShelf
02d5682c: cbz     x8, #0x2d56848                             
02d56830: ldrb    w8, [x8, #0x45]                            
02d56834: ldp     x20, x19, [sp, #0x10]                      
02d56838: cmp     w8, #0                                     
02d5683c: cset    w0, eq                                     
02d56840: ldr     x30, [sp], #0x20                           
02d56844: ret                                                
02d56848: bl      #0x2b7105c                                 fn_2b7105c
## Initiate() -> void
---- Blindbag.TutorialBlindBag::Initiate 0x2d5684c
02d5684c: stp     x30, x21, [sp, #-0x20]!                    
02d56850: stp     x20, x19, [sp, #0x10]                      
02d56854: adrp    x20, #0x6630000                            
02d56858: adrp    x21, #0x626b000                            
02d5685c: mov     x19, x0                                    
02d56860: ldrb    w8, [x20, #0x286]                          
02d56864: ldr     x21, [x21, #0xa38]                         MS:MonoSingleton`1::Initiate
02d56868: tbnz    w8, #0, #0x2d56880                         
02d5686c: adrp    x0, #0x626b000                             
02d56870: ldr     x0, [x0, #0xa38]                           MS:MonoSingleton`1::Initiate
02d56874: bl      #0x2b70db0                                 fn_2b70db0
02d56878: mov     w8, #1                                     
02d5687c: strb    w8, [x20, #0x286]                          
02d56880: ldr     x1, [x21]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d56884: mov     x0, x19                                    
02d56888: bl      #0x3769de4                                 fn_3769de4
02d5688c: mov     x0, x19                                    
02d56890: ldp     x20, x19, [sp, #0x10]                      
02d56894: ldp     x30, x21, [sp], #0x20                      
02d56898: b       #0x2d5689c                                 Blindbag.TutorialBlindBag::HideAllTutorial
## ShowTutorialClickBagOnShelf(bool isShow) -> void
---- Blindbag.TutorialBlindBag::ShowTutorialClickBagOnShelf 0x2d52038
02d52038: str     x30, [sp, #-0x20]!                         
02d5203c: stp     x20, x19, [sp, #0x10]                      
02d52040: mov     x19, x0                                    
02d52044: ldr     x0, [x0, #0x20]                            ._tutorialClickBagOnShelf
02d52048: cbz     x0, #0x2d52090                             
02d5204c: mov     w20, w1                                    
02d52050: mov     w1, wzr                                    
02d52054: mov     x2, xzr                                    
02d52058: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d5205c: bl      #0x2d567cc                                 Blindbag.TutorialBlindBag::get__canTutorial
02d52060: tbz     w0, #0, #0x2d52084                         
02d52064: tbz     w20, #0, #0x2d52084                        
02d52068: ldr     x0, [x19, #0x20]                           ._tutorialClickBagOnShelf
02d5206c: cbz     x0, #0x2d52090                             
02d52070: ldp     x20, x19, [sp, #0x10]                      
02d52074: mov     w1, #1                                     
02d52078: mov     x2, xzr                                    
02d5207c: ldr     x30, [sp], #0x20                           
02d52080: b       #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d52084: ldp     x20, x19, [sp, #0x10]                      
02d52088: ldr     x30, [sp], #0x20                           
02d5208c: ret                                                
02d52090: bl      #0x2b7105c                                 fn_2b7105c
## ShowTutorialScanItem(bool isShow) -> void
---- Blindbag.TutorialBlindBag::ShowTutorialScanItem 0x2d522b8
02d522b8: str     x30, [sp, #-0x20]!                         
02d522bc: stp     x20, x19, [sp, #0x10]                      
02d522c0: mov     x19, x0                                    
02d522c4: ldr     x0, [x0, #0x28]                            ._tutorialScanItem
02d522c8: cbz     x0, #0x2d52310                             
02d522cc: mov     w20, w1                                    
02d522d0: mov     w1, wzr                                    
02d522d4: mov     x2, xzr                                    
02d522d8: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d522dc: bl      #0x2d567cc                                 Blindbag.TutorialBlindBag::get__canTutorial
02d522e0: tbz     w0, #0, #0x2d52304                         
02d522e4: tbz     w20, #0, #0x2d52304                        
02d522e8: ldr     x0, [x19, #0x28]                           ._tutorialScanItem
02d522ec: cbz     x0, #0x2d52310                             
02d522f0: ldp     x20, x19, [sp, #0x10]                      
02d522f4: mov     w1, #1                                     
02d522f8: mov     x2, xzr                                    
02d522fc: ldr     x30, [sp], #0x20                           
02d52300: b       #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d52304: ldp     x20, x19, [sp, #0x10]                      
02d52308: ldr     x30, [sp], #0x20                           
02d5230c: ret                                                
02d52310: bl      #0x2b7105c                                 fn_2b7105c
## ShowTutorialUnbox(UnityEngine.Transform target, bool isShow) -> void
---- Blindbag.TutorialBlindBag::ShowTutorialUnbox 0x2d5699c
02d5699c: str     x30, [sp, #-0x30]!                         
02d569a0: stp     x22, x21, [sp, #0x10]                      
02d569a4: stp     x20, x19, [sp, #0x20]                      
02d569a8: adrp    x22, #0x6630000                            
02d569ac: mov     w21, w2                                    
02d569b0: mov     x20, x1                                    
02d569b4: ldrb    w8, [x22, #0x287]                          
02d569b8: mov     x19, x0                                    
02d569bc: tbnz    w8, #0, #0x2d569d4                         
02d569c0: adrp    x0, #0x6263000                             
02d569c4: ldr     x0, [x0, #0x918]                           T:UnityEngine.Object
02d569c8: bl      #0x2b70db0                                 fn_2b70db0
02d569cc: mov     w8, #1                                     
02d569d0: strb    w8, [x22, #0x287]                          
02d569d4: ldr     x0, [x19, #0x30]                           ._tutorialUnbox
02d569d8: cbz     x0, #0x2d56a84                             
02d569dc: mov     w1, wzr                                    
02d569e0: mov     x2, xzr                                    
02d569e4: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d569e8: bl      #0x2d567cc                                 Blindbag.TutorialBlindBag::get__canTutorial
02d569ec: tbz     w0, #0, #0x2d56a74                         
02d569f0: tbz     w21, #0, #0x2d56a74                        
02d569f4: adrp    x8, #0x6263000                             
02d569f8: ldr     x8, [x8, #0x918]                           T:UnityEngine.Object
02d569fc: ldr     x0, [x8]                                   &2c5bbd4(=a9bd7bfdd503233f)
02d56a00: ldr     w8, [x0, #0xe4]                            [62630e4]=0 f=0,0
02d56a04: cbnz    w8, #0x2d56a0c                             
02d56a08: bl      #0x2b70f30                                 fn_2b70f30
02d56a0c: mov     x0, x20                                    
02d56a10: mov     x1, xzr                                    
02d56a14: mov     x2, xzr                                    
02d56a18: bl      #0x5b3666c                                 UnityEngine.Object::op_Inequality
02d56a1c: tbz     w0, #0, #0x2d56a54                         
02d56a20: ldr     x0, [x19, #0x30]                           ._tutorialUnbox
02d56a24: cbz     x0, #0x2d56a84                             
02d56a28: mov     x1, xzr                                    
02d56a2c: bl      #0x5b368f0                                 UnityEngine.GameObject::get_transform
02d56a30: cbz     x20, #0x2d56a84                            
02d56a34: mov     x21, x0                                    
02d56a38: mov     x0, x20                                    
02d56a3c: mov     x1, xzr                                    
02d56a40: bl      #0x5b467ac                                 UnityEngine.Transform::get_position
02d56a44: cbz     x21, #0x2d56a84                            
02d56a48: mov     x0, x21                                    
02d56a4c: mov     x1, xzr                                    
02d56a50: bl      #0x5b46888                                 UnityEngine.Transform::set_position
02d56a54: ldr     x0, [x19, #0x30]                           ._tutorialUnbox
02d56a58: cbz     x0, #0x2d56a84                             
02d56a5c: ldp     x20, x19, [sp, #0x20]                      
02d56a60: mov     w1, #1                                     
02d56a64: ldp     x22, x21, [sp, #0x10]                      
02d56a68: mov     x2, xzr                                    
02d56a6c: ldr     x30, [sp], #0x30                           
02d56a70: b       #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d56a74: ldp     x20, x19, [sp, #0x20]                      
02d56a78: ldp     x22, x21, [sp, #0x10]                      
02d56a7c: ldr     x30, [sp], #0x30                           
02d56a80: ret                                                
02d56a84: bl      #0x2b7105c                                 fn_2b7105c
## HideAllTutorial() -> void
---- Blindbag.TutorialBlindBag::HideAllTutorial 0x2d5689c
02d5689c: stp     x30, x21, [sp, #-0x20]!                    
02d568a0: stp     x20, x19, [sp, #0x10]                      
02d568a4: adrp    x20, #0x6630000                            
02d568a8: adrp    x21, #0x6263000                            
02d568ac: mov     x19, x0                                    
02d568b0: ldrb    w8, [x20, #0x288]                          
02d568b4: ldr     x21, [x21, #0x918]                         T:UnityEngine.Object
02d568b8: tbnz    w8, #0, #0x2d568d0                         
02d568bc: adrp    x0, #0x6263000                             
02d568c0: ldr     x0, [x0, #0x918]                           T:UnityEngine.Object
02d568c4: bl      #0x2b70db0                                 fn_2b70db0
02d568c8: mov     w8, #1                                     
02d568cc: strb    w8, [x20, #0x288]                          
02d568d0: ldr     x0, [x21]                                  &2c5bbd4(=a9bd7bfdd503233f)
02d568d4: ldr     x20, [x19, #0x20]                          ._tutorialClickBagOnShelf
02d568d8: ldr     w8, [x0, #0xe4]                            [62630e4]=0 f=0,0
02d568dc: cbnz    w8, #0x2d568e4                             
02d568e0: bl      #0x2b70f30                                 fn_2b70f30
02d568e4: mov     x0, x20                                    
02d568e8: mov     x1, xzr                                    
02d568ec: mov     x2, xzr                                    
02d568f0: bl      #0x5b3666c                                 UnityEngine.Object::op_Inequality
02d568f4: tbz     w0, #0, #0x2d5690c                         
02d568f8: ldr     x0, [x19, #0x20]                           ._tutorialClickBagOnShelf
02d568fc: cbz     x0, #0x2d56998                             
02d56900: mov     w1, wzr                                    
02d56904: mov     x2, xzr                                    
02d56908: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d5690c: ldr     x0, [x21]                                  &2c5bbd4(=a9bd7bfdd503233f)
02d56910: ldr     x20, [x19, #0x28]                          ._tutorialScanItem
02d56914: ldr     w8, [x0, #0xe4]                            [62630e4]=0 f=0,0
02d56918: cbnz    w8, #0x2d56920                             
02d5691c: bl      #0x2b70f30                                 fn_2b70f30
02d56920: mov     x0, x20                                    
02d56924: mov     x1, xzr                                    
02d56928: mov     x2, xzr                                    
02d5692c: bl      #0x5b3666c                                 UnityEngine.Object::op_Inequality
02d56930: tbz     w0, #0, #0x2d56948                         
02d56934: ldr     x0, [x19, #0x28]                           ._tutorialScanItem
02d56938: cbz     x0, #0x2d56998                             
02d5693c: mov     w1, wzr                                    
02d56940: mov     x2, xzr                                    
02d56944: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d56948: ldr     x0, [x21]                                  &2c5bbd4(=a9bd7bfdd503233f)
02d5694c: ldr     x20, [x19, #0x30]                          ._tutorialUnbox
02d56950: ldr     w8, [x0, #0xe4]                            [62630e4]=0 f=0,0
02d56954: cbnz    w8, #0x2d5695c                             
02d56958: bl      #0x2b70f30                                 fn_2b70f30
02d5695c: mov     x0, x20                                    
02d56960: mov     x1, xzr                                    
02d56964: mov     x2, xzr                                    
02d56968: bl      #0x5b3666c                                 UnityEngine.Object::op_Inequality
02d5696c: tbz     w0, #0, #0x2d5698c                         
02d56970: ldr     x0, [x19, #0x30]                           ._tutorialUnbox
02d56974: cbz     x0, #0x2d56998                             
02d56978: ldp     x20, x19, [sp, #0x10]                      
02d5697c: mov     w1, wzr                                    
02d56980: mov     x2, xzr                                    
02d56984: ldp     x30, x21, [sp], #0x20                      
02d56988: b       #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d5698c: ldp     x20, x19, [sp, #0x10]                      
02d56990: ldp     x30, x21, [sp], #0x20                      
02d56994: ret                                                
02d56998: bl      #0x2b7105c                                 fn_2b7105c
## .ctor() -> void
---- Blindbag.TutorialBlindBag::.ctor 0x2d56a88
02d56a88: stp     x30, x21, [sp, #-0x20]!                    
02d56a8c: stp     x20, x19, [sp, #0x10]                      
02d56a90: adrp    x20, #0x6630000                            
02d56a94: adrp    x21, #0x626b000                            
02d56a98: mov     x19, x0                                    
02d56a9c: ldrb    w8, [x20, #0x289]                          
02d56aa0: ldr     x21, [x21, #0xa40]                         MS:MonoSingleton`1::.ctor
02d56aa4: tbnz    w8, #0, #0x2d56abc                         
02d56aa8: adrp    x0, #0x626b000                             
02d56aac: ldr     x0, [x0, #0xa40]                           MS:MonoSingleton`1::.ctor
02d56ab0: bl      #0x2b70db0                                 fn_2b70db0
02d56ab4: mov     w8, #1                                     
02d56ab8: strb    w8, [x20, #0x289]                          
02d56abc: mov     x0, x19                                    
02d56ac0: ldp     x20, x19, [sp, #0x10]                      
02d56ac4: ldr     x1, [x21]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d56ac8: ldp     x30, x21, [sp], #0x20                      
02d56acc: b       #0x3769e18                                 
