#### CLASS Decor.OptionItem/<>c__DisplayClass16_0 parent= object
#   field onClickSelected                System.Action`1<Decor.OptionItem>                  off=0x10 attr=6 
#   field <>4__this                      Decor.OptionItem                                   off=0x18 attr=6 
#   field onClickBuy                     System.Action`1<Decor.OptionItem>                  off=0x20 attr=6 
## .ctor() -> void
---- Decor.OptionItem/<>c__DisplayClass16_0::.ctor 0x2d2843c
02d2843c: mov     x1, xzr                                    
02d28440: b       #0x4e53e9c                                 System.Object::.ctor
## <OnInit>b__0() -> void
---- Decor.OptionItem/<>c__DisplayClass16_0::<OnInit>b__0 0x2d28a0c
02d28a0c: ldr     x8, [x0, #0x10]                            .onClickSelected
02d28a10: cbz     x8, #0x2d28a28                             
02d28a14: ldr     x1, [x0, #0x18]                            .<>4__this
02d28a18: ldr     x0, [x8, #0x40]                            
02d28a1c: ldr     x2, [x8, #0x28]                            
02d28a20: ldr     x3, [x8, #0x18]                            
02d28a24: br      x3                                         
02d28a28: ret                                                
## <OnInit>b__1() -> void
---- Decor.OptionItem/<>c__DisplayClass16_0::<OnInit>b__1 0x2d28a2c
02d28a2c: ldr     x8, [x0, #0x20]                            .onClickBuy
02d28a30: cbz     x8, #0x2d28a48                             
02d28a34: ldr     x1, [x0, #0x18]                            .<>4__this
02d28a38: ldr     x0, [x8, #0x40]                            
02d28a3c: ldr     x2, [x8, #0x28]                            
02d28a40: ldr     x3, [x8, #0x18]                            
02d28a44: br      x3                                         
02d28a48: ret                                                
#### CLASS Decor.OptionItem parent= PoolElement
#   field _id                            int                                                off=0x28 attr=1 SerializeField,ReadOnlyAttribute
#   field _icon                          UnityEngine.UI.Image                               off=0x30 attr=1 SerializeField
#   field _btnSelected                   UnityEngine.UI.Button                              off=0x38 attr=1 SerializeField
#   field _btnBuy                        UnityEngine.UI.Button                              off=0x40 attr=1 SerializeField
#   field _optionByMoney                 UnityEngine.GameObject                             off=0x48 attr=1 SerializeField
#   field _optionByAds                   UnityEngine.GameObject                             off=0x50 attr=1 SerializeField
#   field _optionByIAP                   UnityEngine.GameObject                             off=0x58 attr=1 SerializeField
#   field _optionByDay                   UnityEngine.GameObject                             off=0x60 attr=1 SerializeField
#   field _selected                      UnityEngine.GameObject                             off=0x68 attr=1 SerializeField
#   field _iconNoti                      UnityEngine.GameObject                             off=0x70 attr=1 SerializeField
#   field _panel                         UnityEngine.RectTransform                          off=0x78 attr=1 SerializeField
#   field _txtPrice                      TMPro.TextMeshProUGUI                              off=0x80 attr=1 SerializeField
#   field _txtStatus                     TMPro.TextMeshProUGUI                              off=0x88 attr=1 SerializeField
#   field _txtDay                        TMPro.TextMeshProUGUI                              off=0x90 attr=1 SerializeField
#   field _equippingLocalized            string                                             off=0x98 attr=1 SerializeField
#   field _ownedLocalized                string                                             off=0xa0 attr=1 SerializeField
## OnInit(System.Action`1<Decor.OptionItem> onClickSelected, System.Action`1<Decor.OptionItem> onClickBuy) -> Decor.OptionItem
---- Decor.OptionItem::OnInit 0x2d282b4
02d282b4: stp     x30, x23, [sp, #-0x30]!                    
02d282b8: stp     x22, x21, [sp, #0x10]                      
02d282bc: stp     x20, x19, [sp, #0x20]                      
02d282c0: adrp    x20, #0x6630000                            
02d282c4: adrp    x23, #0x626a000                            
02d282c8: mov     x21, x2                                    
02d282cc: ldrb    w8, [x20, #0x95]                           
02d282d0: ldr     x23, [x23, #0x1e0]                         T:Decor.OptionItem/<>c__DisplayClass16_0
02d282d4: mov     x22, x1                                    
02d282d8: mov     x19, x0                                    
02d282dc: tbnz    w8, #0, #0x2d28318                         
02d282e0: adrp    x0, #0x626a000                             
02d282e4: ldr     x0, [x0, #0x1e8]                           M:Decor.OptionItem/<>c__DisplayClass16_0::<OnInit>b__0
02d282e8: bl      #0x2b70db0                                 fn_2b70db0
02d282ec: adrp    x0, #0x626a000                             
02d282f0: ldr     x0, [x0, #0x1f0]                           M:Decor.OptionItem/<>c__DisplayClass16_0::<OnInit>b__1
02d282f4: bl      #0x2b70db0                                 fn_2b70db0
02d282f8: adrp    x0, #0x626a000                             
02d282fc: ldr     x0, [x0, #0x1e0]                           T:Decor.OptionItem/<>c__DisplayClass16_0
02d28300: bl      #0x2b70db0                                 fn_2b70db0
02d28304: adrp    x0, #0x6265000                             
02d28308: ldr     x0, [x0, #0x3f0]                           T:UnityEngine.Events.UnityAction
02d2830c: bl      #0x2b70db0                                 fn_2b70db0
02d28310: mov     w8, #1                                     
02d28314: strb    w8, [x20, #0x95]                           
02d28318: ldr     x0, [x23]                                  T:type56879(k15)
02d2831c: bl      #0x2b7104c                                 fn_2b7104c
02d28320: mov     x1, xzr                                    
02d28324: mov     x20, x0                                    
02d28328: bl      #0x4e53e9c                                 System.Object::.ctor
02d2832c: cbz     x20, #0x2d28438                            
02d28330: mov     x0, x20                                    
02d28334: mov     x1, x22                                    
02d28338: str     x22, [x0, #0x10]!                          
02d2833c: bl      #0x2b70d54                                 fn_2b70d54
02d28340: mov     x0, x20                                    
02d28344: mov     x1, x19                                    
02d28348: str     x19, [x0, #0x18]!                          
02d2834c: bl      #0x2b70d54                                 fn_2b70d54
02d28350: mov     x0, x20                                    
02d28354: mov     x1, x21                                    
02d28358: str     x21, [x0, #0x20]!                          
02d2835c: bl      #0x2b70d54                                 fn_2b70d54
02d28360: ldr     x8, [x19, #0x38]                           ._btnSelected
02d28364: cbz     x8, #0x2d28438                             
02d28368: ldr     x0, [x8, #0x100]                           
02d2836c: cbz     x0, #0x2d28438                             
02d28370: mov     x1, xzr                                    
02d28374: bl      #0x5b4ce48                                 UnityEngine.Events.UnityEventBase::RemoveAllListeners
02d28378: ldr     x8, [x19, #0x40]                           ._btnBuy
02d2837c: cbz     x8, #0x2d28438                             
02d28380: ldr     x0, [x8, #0x100]                           
02d28384: cbz     x0, #0x2d28438                             
02d28388: mov     x1, xzr                                    
02d2838c: bl      #0x5b4ce48                                 UnityEngine.Events.UnityEventBase::RemoveAllListeners
02d28390: ldr     x8, [x19, #0x38]                           ._btnSelected
02d28394: cbz     x8, #0x2d28438                             
02d28398: adrp    x23, #0x6265000                            
02d2839c: adrp    x22, #0x626a000                            
02d283a0: ldr     x23, [x23, #0x3f0]                         T:UnityEngine.Events.UnityAction
02d283a4: ldr     x22, [x22, #0x1e8]                         M:Decor.OptionItem/<>c__DisplayClass16_0::<OnInit>b__0
02d283a8: ldr     x21, [x8, #0x100]                          
02d283ac: ldr     x0, [x23]                                  M:AdsManager::<OnApplicationPause>b__26_0
02d283b0: bl      #0x2b7104c                                 fn_2b7104c
02d283b4: ldr     x2, [x22]                                  T:type56879(k15)
02d283b8: mov     x1, x20                                    
02d283bc: mov     x3, xzr                                    
02d283c0: mov     x22, x0                                    
02d283c4: bl      #0x5b4cf98                                 UnityEngine.Events.UnityAction::.ctor
02d283c8: cbz     x21, #0x2d28438                            
02d283cc: mov     x0, x21                                    
02d283d0: mov     x1, x22                                    
02d283d4: mov     x2, xzr                                    
02d283d8: bl      #0x5b4d0ac                                 UnityEngine.Events.UnityEvent::AddListener
02d283dc: ldr     x8, [x19, #0x40]                           ._btnBuy
02d283e0: cbz     x8, #0x2d28438                             
02d283e4: adrp    x22, #0x626a000                            
02d283e8: ldr     x22, [x22, #0x1f0]                         M:Decor.OptionItem/<>c__DisplayClass16_0::<OnInit>b__1
02d283ec: ldr     x0, [x23]                                  M:AdsManager::<OnApplicationPause>b__26_0
02d283f0: ldr     x21, [x8, #0x100]                          
02d283f4: bl      #0x2b7104c                                 fn_2b7104c
02d283f8: ldr     x2, [x22]                                  T:type56879(k15)
02d283fc: mov     x1, x20                                    
02d28400: mov     x3, xzr                                    
02d28404: mov     x22, x0                                    
02d28408: bl      #0x5b4cf98                                 UnityEngine.Events.UnityAction::.ctor
02d2840c: cbz     x21, #0x2d28438                            
02d28410: mov     x0, x21                                    
02d28414: mov     x1, x22                                    
02d28418: mov     x2, xzr                                    
02d2841c: bl      #0x5b4d0ac                                 UnityEngine.Events.UnityEvent::AddListener
02d28420: mov     x0, x19                                    
02d28424: ldp     x20, x19, [sp, #0x20]                      
02d28428: ldp     x22, x21, [sp, #0x10]                      
02d2842c: mov     w1, wzr                                    
02d28430: ldp     x30, x23, [sp], #0x30                      
02d28434: b       #0x2d28444                                 Decor.OptionItem::SetSelected
02d28438: bl      #0x2b7105c                                 fn_2b7105c
## SetIcon(UnityEngine.Sprite sprite) -> Decor.OptionItem
---- Decor.OptionItem::SetIcon 0x2d28518
02d28518: stp     x30, x19, [sp, #-0x10]!                    
02d2851c: mov     x19, x0                                    
02d28520: ldr     x0, [x0, #0x30]                            ._icon
02d28524: cbz     x0, #0x2d2853c                             
02d28528: mov     x2, xzr                                    
02d2852c: bl      #0x5c45aa0                                 UnityEngine.UI.Image::set_sprite
02d28530: mov     x0, x19                                    
02d28534: ldp     x30, x19, [sp], #0x10                      
02d28538: ret                                                
02d2853c: bl      #0x2b7105c                                 fn_2b7105c
## SetUnlockType(Games.Common.EUnlockType unlockType) -> Decor.OptionItem
---- Decor.OptionItem::SetUnlockType 0x2d28540
02d28540: str     x30, [sp, #-0x30]!                         
02d28544: stp     x22, x21, [sp, #0x10]                      
02d28548: stp     x20, x19, [sp, #0x20]                      
02d2854c: adrp    x21, #0x6630000                            
02d28550: mov     w20, w1                                    
02d28554: mov     x19, x0                                    
02d28558: ldrb    w8, [x21, #0x96]                           
02d2855c: tbnz    w8, #0, #0x2d28574                         
02d28560: adrp    x0, #0x6263000                             
02d28564: ldr     x0, [x0, #0x918]                           T:UnityEngine.Object
02d28568: bl      #0x2b70db0                                 fn_2b70db0
02d2856c: mov     w8, #1                                     
02d28570: strb    w8, [x21, #0x96]                           
02d28574: ldr     x0, [x19, #0x48]                           ._optionByMoney
02d28578: cbz     x0, #0x2d28640                             
02d2857c: cmp     w20, #2                                    
02d28580: mov     x2, xzr                                    
02d28584: cset    w1, eq                                     
02d28588: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d2858c: ldr     x0, [x19, #0x50]                           ._optionByAds
02d28590: cbz     x0, #0x2d28640                             
02d28594: adrp    x22, #0x6263000                            
02d28598: cmp     w20, #1                                    
02d2859c: mov     x2, xzr                                    
02d285a0: ldr     x22, [x22, #0x918]                         T:UnityEngine.Object
02d285a4: cset    w1, eq                                     
02d285a8: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d285ac: ldr     x0, [x22]                                  &2c5bbd4(=a9bd7bfdd503233f)
02d285b0: ldr     x21, [x19, #0x58]                          ._optionByIAP
02d285b4: ldr     w8, [x0, #0xe4]                            [62630e4]=0 f=0,0
02d285b8: cbnz    w8, #0x2d285c0                             
02d285bc: bl      #0x2b70f30                                 fn_2b70f30
02d285c0: mov     x0, x21                                    
02d285c4: mov     x1, xzr                                    
02d285c8: mov     x2, xzr                                    
02d285cc: bl      #0x5b3666c                                 UnityEngine.Object::op_Inequality
02d285d0: tbz     w0, #0, #0x2d285ec                         
02d285d4: ldr     x0, [x19, #0x58]                           ._optionByIAP
02d285d8: cbz     x0, #0x2d28640                             
02d285dc: cmp     w20, #5                                    
02d285e0: mov     x2, xzr                                    
02d285e4: cset    w1, eq                                     
02d285e8: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d285ec: ldr     x0, [x22]                                  &2c5bbd4(=a9bd7bfdd503233f)
02d285f0: ldr     x21, [x19, #0x60]                          ._optionByDay
02d285f4: ldr     w8, [x0, #0xe4]                            [62630e4]=0 f=0,0
02d285f8: cbnz    w8, #0x2d28600                             
02d285fc: bl      #0x2b70f30                                 fn_2b70f30
02d28600: mov     x0, x21                                    
02d28604: mov     x1, xzr                                    
02d28608: mov     x2, xzr                                    
02d2860c: bl      #0x5b3666c                                 UnityEngine.Object::op_Inequality
02d28610: tbz     w0, #0, #0x2d2862c                         
02d28614: ldr     x0, [x19, #0x60]                           ._optionByDay
02d28618: cbz     x0, #0x2d28640                             
02d2861c: cmp     w20, #3                                    
02d28620: mov     x2, xzr                                    
02d28624: cset    w1, eq                                     
02d28628: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d2862c: mov     x0, x19                                    
02d28630: ldp     x20, x19, [sp, #0x20]                      
02d28634: ldp     x22, x21, [sp, #0x10]                      
02d28638: ldr     x30, [sp], #0x30                           
02d2863c: ret                                                
02d28640: bl      #0x2b7105c                                 fn_2b7105c
## SetID(int id) -> Decor.OptionItem
---- Decor.OptionItem::SetID 0x2d28644
02d28644: str     w1, [x0, #0x28]                            ._id
02d28648: ret                                                
## SetActiveNotification(bool isActive) -> Decor.OptionItem
---- Decor.OptionItem::SetActiveNotification 0x2d2864c
02d2864c: stp     x30, x19, [sp, #-0x10]!                    
02d28650: mov     x19, x0                                    
02d28654: ldr     x0, [x0, #0x70]                            ._iconNoti
02d28658: cbz     x0, #0x2d28674                             
02d2865c: and     w1, w1, #1                                 
02d28660: mov     x2, xzr                                    
02d28664: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d28668: mov     x0, x19                                    
02d2866c: ldp     x30, x19, [sp], #0x10                      
02d28670: ret                                                
02d28674: bl      #0x2b7105c                                 fn_2b7105c
## SetSelected(bool isSelected) -> Decor.OptionItem
---- Decor.OptionItem::SetSelected 0x2d28444
02d28444: stp     x30, x23, [sp, #-0x30]!                    
02d28448: stp     x22, x21, [sp, #0x10]                      
02d2844c: stp     x20, x19, [sp, #0x20]                      
02d28450: adrp    x21, #0x6630000                            
02d28454: mov     w20, w1                                    
02d28458: mov     x19, x0                                    
02d2845c: ldrb    w8, [x21, #0x97]                           
02d28460: tbnz    w8, #0, #0x2d28490                         
02d28464: adrp    x0, #0x6266000                             
02d28468: ldr     x0, [x0, #0x9f0]                           T:Assets.SimpleLocalization.Scripts.LocalizationManager
02d2846c: bl      #0x2b70db0                                 fn_2b70db0
02d28470: adrp    x0, #0x626a000                             
02d28474: ldr     x0, [x0, #0x1f8]                           S:'Equipped'
02d28478: bl      #0x2b70db0                                 fn_2b70db0
02d2847c: adrp    x0, #0x626a000                             
02d28480: ldr     x0, [x0, #0x200]                           S:'Owned'
02d28484: bl      #0x2b70db0                                 fn_2b70db0
02d28488: mov     w8, #1                                     
02d2848c: strb    w8, [x21, #0x97]                           
02d28490: ldr     x0, [x19, #0x68]                           ._selected
02d28494: cbz     x0, #0x2d28514                             
02d28498: adrp    x23, #0x6266000                            
02d2849c: adrp    x21, #0x626a000                            
02d284a0: adrp    x22, #0x626a000                            
02d284a4: ldr     x23, [x23, #0x9f0]                         T:Assets.SimpleLocalization.Scripts.LocalizationManager
02d284a8: ldr     x21, [x21, #0x1f8]                         S:'Equipped'
02d284ac: ldr     x22, [x22, #0x200]                         S:'Owned'
02d284b0: and     w1, w20, #1                                
02d284b4: mov     x2, xzr                                    
02d284b8: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d284bc: ldr     x0, [x23]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d284c0: ldr     w8, [x0, #0xe4]                            [626a0e4]=0 f=0,0
02d284c4: cbnz    w8, #0x2d284cc                             
02d284c8: bl      #0x2b70f30                                 fn_2b70f30
02d284cc: tst     w20, #1                                    
02d284d0: mov     x1, xzr                                    
02d284d4: csel    x8, x21, x22, ne                           
02d284d8: ldr     x0, [x8]                                   
02d284dc: bl      #0x2d76794                                 Assets.SimpleLocalization.Scripts.LocalizationManager::Localize
02d284e0: ldr     x8, [x19, #0x88]                           ._txtStatus
02d284e4: cbz     x8, #0x2d28514                             
02d284e8: ldr     x9, [x8]                                   
02d284ec: mov     x1, x0                                     
02d284f0: mov     x0, x8                                     
02d284f4: ldr     x10, [x9, #0x558]                          
02d284f8: ldr     x2, [x9, #0x560]                           
02d284fc: blr     x10                                        
02d28500: mov     x0, x19                                    
02d28504: ldp     x20, x19, [sp, #0x20]                      
02d28508: ldp     x22, x21, [sp, #0x10]                      
02d2850c: ldp     x30, x23, [sp], #0x30                      
02d28510: ret                                                
02d28514: bl      #0x2b7105c                                 fn_2b7105c
## SetPrice(int price) -> Decor.OptionItem
---- Decor.OptionItem::SetPrice 0x2d286a8
02d286a8: str     x30, [sp, #-0x20]!                         
02d286ac: stp     x20, x19, [sp, #0x10]                      
02d286b0: mov     x19, x0                                    
02d286b4: ldr     x20, [x0, #0x80]                           ._txtPrice
02d286b8: str     w1, [sp, #0xc]                             
02d286bc: add     x0, sp, #0xc                               
02d286c0: mov     x1, xzr                                    
02d286c4: bl      #0x4e0ea3c                                 System.Int32::ToString
02d286c8: cbz     x20, #0x2d286f4                            
02d286cc: ldr     x8, [x20]                                  
02d286d0: mov     x1, x0                                     
02d286d4: mov     x0, x20                                    
02d286d8: ldr     x9, [x8, #0x558]                           
02d286dc: ldr     x2, [x8, #0x560]                           
02d286e0: blr     x9                                         
02d286e4: mov     x0, x19                                    
02d286e8: ldp     x20, x19, [sp, #0x10]                      
02d286ec: ldr     x30, [sp], #0x20                           
02d286f0: ret                                                
02d286f4: bl      #0x2b7105c                                 fn_2b7105c
## SetDay(int day) -> Decor.OptionItem
---- Decor.OptionItem::SetDay 0x2d286f8
02d286f8: sub     sp, sp, #0x30                              
02d286fc: stp     x30, x21, [sp, #0x10]                      
02d28700: stp     x20, x19, [sp, #0x20]                      
02d28704: adrp    x21, #0x6630000                            
02d28708: adrp    x20, #0x6266000                            
02d2870c: mov     x19, x0                                    
02d28710: ldrb    w8, [x21, #0x98]                           ._equippingLocalized
02d28714: ldr     x20, [x20, #0x9f0]                         T:Assets.SimpleLocalization.Scripts.LocalizationManager
02d28718: str     w1, [sp, #0xc]                             
02d2871c: tbnz    w8, #0, #0x2d2874c                         
02d28720: adrp    x0, #0x6266000                             
02d28724: ldr     x0, [x0, #0x9f0]                           T:Assets.SimpleLocalization.Scripts.LocalizationManager
02d28728: bl      #0x2b70db0                                 fn_2b70db0
02d2872c: adrp    x0, #0x6266000                             
02d28730: ldr     x0, [x0, #0xdc8]                           S:'$'
02d28734: bl      #0x2b70db0                                 fn_2b70db0
02d28738: adrp    x0, #0x626a000                             
02d2873c: ldr     x0, [x0, #0x208]                           S:'Day $'
02d28740: bl      #0x2b70db0                                 fn_2b70db0
02d28744: mov     w8, #1                                     
02d28748: strb    w8, [x21, #0x98]                           ._equippingLocalized
02d2874c: ldr     x0, [x20]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d28750: adrp    x21, #0x626a000                            
02d28754: ldr     w8, [x0, #0xe4]                            [626a0e4]=0 f=0,0
02d28758: ldr     x21, [x21, #0x208]                         S:'Day $'
02d2875c: ldr     x20, [x19, #0x90]                          ._txtDay
02d28760: cbnz    w8, #0x2d28768                             
02d28764: bl      #0x2b70f30                                 fn_2b70f30
02d28768: ldr     x0, [x21]                                  T:type56879(k15)
02d2876c: mov     x1, xzr                                    
02d28770: bl      #0x2d76794                                 Assets.SimpleLocalization.Scripts.LocalizationManager::Localize
02d28774: mov     x21, x0                                    
02d28778: add     x0, sp, #0xc                               
02d2877c: mov     x1, xzr                                    
02d28780: bl      #0x4e0ea3c                                 System.Int32::ToString
02d28784: cbz     x21, #0x2d287d4                            
02d28788: adrp    x8, #0x6266000                             
02d2878c: mov     x2, x0                                     
02d28790: mov     x0, x21                                    
02d28794: ldr     x8, [x8, #0xdc8]                           S:'$'
02d28798: mov     x3, xzr                                    
02d2879c: ldr     x1, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d287a0: bl      #0x4ca8ca8                                 System.String::Replace
02d287a4: cbz     x20, #0x2d287d4                            
02d287a8: ldr     x8, [x20]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d287ac: mov     x1, x0                                     
02d287b0: mov     x0, x20                                    
02d287b4: ldr     x9, [x8, #0x558]                           MS:NFramework.GoogleSheetConfigSO`1::.ctor
02d287b8: ldr     x2, [x8, #0x560]                           MS:NFramework.GoogleSheetConfigSO`1::OpenSheet
02d287bc: blr     x9                                         
02d287c0: mov     x0, x19                                    
02d287c4: ldp     x20, x19, [sp, #0x20]                      
02d287c8: ldp     x30, x21, [sp, #0x10]                      
02d287cc: add     sp, sp, #0x30                              
02d287d0: ret                                                
02d287d4: bl      #0x2b7105c                                 fn_2b7105c
## SetStatus(string status) -> Decor.OptionItem
---- Decor.OptionItem::SetStatus 0x2d28678
02d28678: stp     x30, x19, [sp, #-0x10]!                    
02d2867c: mov     x19, x0                                    
02d28680: ldr     x0, [x0, #0x88]                            ._txtStatus
02d28684: cbz     x0, #0x2d286a4                             
02d28688: ldr     x8, [x0]                                   
02d2868c: ldr     x9, [x8, #0x558]                           
02d28690: ldr     x2, [x8, #0x560]                           
02d28694: blr     x9                                         
02d28698: mov     x0, x19                                    
02d2869c: ldp     x30, x19, [sp], #0x10                      
02d286a0: ret                                                
02d286a4: bl      #0x2b7105c                                 fn_2b7105c
## SetActiveStatus(bool isActive) -> Decor.OptionItem
---- Decor.OptionItem::SetActiveStatus 0x2d287d8
02d287d8: str     x30, [sp, #-0x30]!                         
02d287dc: stp     x22, x21, [sp, #0x10]                      
02d287e0: stp     x20, x19, [sp, #0x20]                      
02d287e4: adrp    x22, #0x6630000                            
02d287e8: adrp    x21, #0x6263000                            
02d287ec: mov     w20, w1                                    
02d287f0: ldrb    w8, [x22, #0x99]                           
02d287f4: ldr     x21, [x21, #0x918]                         T:UnityEngine.Object
02d287f8: mov     x19, x0                                    
02d287fc: tbnz    w8, #0, #0x2d28814                         
02d28800: adrp    x0, #0x6263000                             
02d28804: ldr     x0, [x0, #0x918]                           T:UnityEngine.Object
02d28808: bl      #0x2b70db0                                 fn_2b70db0
02d2880c: mov     w8, #1                                     
02d28810: strb    w8, [x22, #0x99]                           
02d28814: ldr     x0, [x21]                                  &2c5bbd4(=a9bd7bfdd503233f)
02d28818: ldr     x21, [x19, #0x88]                          ._txtStatus
02d2881c: ldr     w8, [x0, #0xe4]                            [62630e4]=0 f=0,0
02d28820: cbnz    w8, #0x2d28828                             
02d28824: bl      #0x2b70f30                                 fn_2b70f30
02d28828: mov     x0, x21                                    
02d2882c: mov     x1, xzr                                    
02d28830: mov     x2, xzr                                    
02d28834: bl      #0x5b3666c                                 UnityEngine.Object::op_Inequality
02d28838: tbz     w0, #0, #0x2d2885c                         
02d2883c: ldr     x0, [x19, #0x88]                           ._txtStatus
02d28840: cbz     x0, #0x2d28870                             
02d28844: mov     x1, xzr                                    
02d28848: bl      #0x5b339ec                                 UnityEngine.Component::get_gameObject
02d2884c: cbz     x0, #0x2d28870                             
02d28850: and     w1, w20, #1                                
02d28854: mov     x2, xzr                                    
02d28858: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d2885c: mov     x0, x19                                    
02d28860: ldp     x20, x19, [sp, #0x20]                      
02d28864: ldp     x22, x21, [sp, #0x10]                      
02d28868: ldr     x30, [sp], #0x30                           
02d2886c: ret                                                
02d28870: bl      #0x2b7105c                                 fn_2b7105c
## SetActiveBuyButton(bool isActive) -> Decor.OptionItem
---- Decor.OptionItem::SetActiveBuyButton 0x2d28874
02d28874: str     x30, [sp, #-0x20]!                         
02d28878: stp     x20, x19, [sp, #0x10]                      
02d2887c: mov     x19, x0                                    
02d28880: ldr     x0, [x0, #0x40]                            ._btnBuy
02d28884: cbz     x0, #0x2d288a4                             
02d28888: mov     w20, w1                                    
02d2888c: mov     x1, xzr                                    
02d28890: bl      #0x5b339ec                                 UnityEngine.Component::get_gameObject
02d28894: cbz     x0, #0x2d288a4                             
02d28898: and     w1, w20, #1                                
02d2889c: mov     x2, xzr                                    
02d288a0: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d288a4: mov     x0, x19                                    
02d288a8: ldp     x20, x19, [sp, #0x10]                      
02d288ac: ldr     x30, [sp], #0x20                           
02d288b0: ret                                                
## SetInteractableBtnSelected(bool isInteractable) -> Decor.OptionItem
---- Decor.OptionItem::SetInteractableBtnSelected 0x2d288b4
02d288b4: stp     x30, x19, [sp, #-0x10]!                    
02d288b8: mov     x19, x0                                    
02d288bc: ldr     x0, [x0, #0x38]                            ._btnSelected
02d288c0: cbz     x0, #0x2d288dc                             
02d288c4: and     w1, w1, #1                                 
02d288c8: mov     x2, xzr                                    
02d288cc: bl      #0x5e662d4                                 UnityEngine.UI.Selectable::set_interactable
02d288d0: mov     x0, x19                                    
02d288d4: ldp     x30, x19, [sp], #0x10                      
02d288d8: ret                                                
02d288dc: bl      #0x2b7105c                                 fn_2b7105c
## SetInteractableBtnBuy(bool isInteractable) -> Decor.OptionItem
---- Decor.OptionItem::SetInteractableBtnBuy 0x2d288e0
02d288e0: stp     x30, x19, [sp, #-0x10]!                    
02d288e4: mov     x19, x0                                    
02d288e8: ldr     x0, [x0, #0x40]                            ._btnBuy
02d288ec: cbz     x0, #0x2d28908                             
02d288f0: and     w1, w1, #1                                 
02d288f4: mov     x2, xzr                                    
02d288f8: bl      #0x5e662d4                                 UnityEngine.UI.Selectable::set_interactable
02d288fc: mov     x0, x19                                    
02d28900: ldp     x30, x19, [sp], #0x10                      
02d28904: ret                                                
02d28908: bl      #0x2b7105c                                 fn_2b7105c
## StartClickEffect() -> Decor.OptionItem
---- Decor.OptionItem::StartClickEffect 0x2d2890c
02d2890c: str     x30, [sp, #-0x30]!                         
02d28910: stp     x22, x21, [sp, #0x10]                      
02d28914: stp     x20, x19, [sp, #0x20]                      
02d28918: adrp    x21, #0x662f000                            
02d2891c: ldr     x20, [x0, #0x78]                           ._panel
02d28920: mov     x19, x0                                    
02d28924: ldrb    w8, [x21, #0xa74]                          
02d28928: cbnz    w8, #0x2d28940                             
02d2892c: adrp    x0, #0x6264000                             
02d28930: ldr     x0, [x0, #0xd8]                            T:UnityEngine.Vector3
02d28934: bl      #0x2b70db0                                 fn_2b70db0
02d28938: mov     w8, #1                                     
02d2893c: strb    w8, [x21, #0xa74]                          
02d28940: cbz     x20, #0x2d289f8                            
02d28944: adrp    x22, #0x6264000                            
02d28948: mov     x0, x20                                    
02d2894c: mov     x1, xzr                                    
02d28950: ldr     x22, [x22, #0xd8]                          T:UnityEngine.Vector3
02d28954: ldr     x8, [x22]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d28958: ldr     x8, [x8, #0xb8]                            
02d2895c: ldp     s1, s2, [x8, #0x10]                        
02d28960: ldr     s0, [x8, #0xc]                             
02d28964: bl      #0x5b470cc                                 UnityEngine.Transform::set_localScale
02d28968: ldr     x0, [x19, #0x78]                           ._panel
02d2896c: mov     w1, wzr                                    
02d28970: mov     x2, xzr                                    
02d28974: bl      #0x2d9d5d0                                 DG.Tweening.ShortcutExtensions::DOKill
02d28978: ldrb    w8, [x21, #0xa74]                          
02d2897c: ldr     x20, [x19, #0x78]                          ._panel
02d28980: cbnz    w8, #0x2d28998                             
02d28984: adrp    x0, #0x6264000                             
02d28988: ldr     x0, [x0, #0xd8]                            T:UnityEngine.Vector3
02d2898c: bl      #0x2b70db0                                 fn_2b70db0
02d28990: mov     w8, #1                                     
02d28994: strb    w8, [x21, #0xa74]                          
02d28998: ldr     x8, [x22]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d2899c: mov     w9, #0xcccd                                
02d289a0: fmov    s4, #1.00000000                            
02d289a4: movk    w9, #0x3dcc, lsl #16                       
02d289a8: mov     x0, x20                                    
02d289ac: mov     w1, #0xa                                   
02d289b0: ldr     x8, [x8, #0xb8]                            
02d289b4: dup     v0.2s, w9                                  
02d289b8: adrp    x9, #0x1084000                             
02d289bc: ldr     s2, [x9, #0xeec]                           [1084eec]=457ff0003dcccccd f=0.1,4095
02d289c0: mov     x2, xzr                                    
02d289c4: ldur    d1, [x8, #0xc]                             
02d289c8: fmul    v0.2s, v1.2s, v0.2s                        
02d289cc: ldr     s1, [x8, #0x14]                            
02d289d0: adrp    x8, #0x1084000                             
02d289d4: ldr     s3, [x8, #0xdd8]                           [1084dd8]=3f7333333e4ccccd f=0.2,0.95
02d289d8: fmul    s2, s1, s2                                 
02d289dc: mov     s1, v0.s[1]                                
02d289e0: bl      #0x2d9982c                                 DG.Tweening.ShortcutExtensions::DOPunchScale
02d289e4: mov     x0, x19                                    
02d289e8: ldp     x20, x19, [sp, #0x20]                      
02d289ec: ldp     x22, x21, [sp, #0x10]                      
02d289f0: ldr     x30, [sp], #0x30                           
02d289f4: ret                                                
02d289f8: bl      #0x2b7105c                                 fn_2b7105c
## GetID() -> int
---- Decor.OptionItem::GetID 0x2d289fc
02d289fc: ldr     w0, [x0, #0x28]                            ._id
02d28a00: ret                                                
## .ctor() -> void
---- Decor.OptionItem::.ctor 0x2d28a04
02d28a04: mov     x1, xzr                                    
02d28a08: b       #0x2cd6228                                 PoolElement::.ctor
