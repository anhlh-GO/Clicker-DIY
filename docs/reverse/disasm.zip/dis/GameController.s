#### CLASS GameController parent= MonoSingleton`1<GameController>
## .ctor() -> void
---- GameController::.ctor 0x2cda860
02cda860: stp     x30, x21, [sp, #-0x20]!                    
02cda864: stp     x20, x19, [sp, #0x10]                      
02cda868: adrp    x20, #0x662f000                            
02cda86c: adrp    x21, #0x6267000                            
02cda870: mov     x19, x0                                    
02cda874: ldrb    w8, [x20, #0xd53]                          
02cda878: ldr     x21, [x21, #0xb98]                         MS:MonoSingleton`1::.ctor
02cda87c: tbnz    w8, #0, #0x2cda894                         
02cda880: adrp    x0, #0x6267000                             
02cda884: ldr     x0, [x0, #0xb98]                           MS:MonoSingleton`1::.ctor
02cda888: bl      #0x2b70db0                                 fn_2b70db0
02cda88c: mov     w8, #1                                     
02cda890: strb    w8, [x20, #0xd53]                          
02cda894: mov     x0, x19                                    
02cda898: ldp     x20, x19, [sp, #0x10]                      
02cda89c: ldr     x1, [x21]                                  S:'didu'
02cda8a0: ldp     x30, x21, [sp], #0x20                      
02cda8a4: b       #0x3769e18                                 
