#### CLASS Clicker.HandFollowClick parent= UnityEngine.MonoBehaviour
#   field _movableHand                   UnityEngine.Transform                              off=0x20 attr=1 SerializeField
## ShowHand(bool isShow) -> void
---- Clicker.HandFollowClick::ShowHand 0x2d5e4d8
02d5e4d8: stp     x30, x19, [sp, #-0x10]!                    
02d5e4dc: mov     w19, w1                                    
02d5e4e0: mov     x1, xzr                                    
02d5e4e4: bl      #0x5b339ec                                 UnityEngine.Component::get_gameObject
02d5e4e8: cbz     x0, #0x2d5e4fc                             
02d5e4ec: and     w1, w19, #1                                
02d5e4f0: mov     x2, xzr                                    
02d5e4f4: ldp     x30, x19, [sp], #0x10                      
02d5e4f8: b       #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d5e4fc: bl      #0x2b7105c                                 fn_2b7105c
## ClickAt(UnityEngine.Transform target) -> void
---- Clicker.HandFollowClick::ClickAt 0x2d638f4
02d638f4: stp     x30, x25, [sp, #-0x40]!                    
02d638f8: stp     x24, x23, [sp, #0x10]                      
02d638fc: stp     x22, x21, [sp, #0x20]                      
02d63900: stp     x20, x19, [sp, #0x30]                      
02d63904: adrp    x21, #0x6630000                            
02d63908: mov     x20, x1                                    
02d6390c: mov     x19, x0                                    
02d63910: ldrb    w8, [x21, #0x361]                          
02d63914: tbnz    w8, #0, #0x2d63950                         
02d63918: adrp    x0, #0x626c000                             
02d6391c: ldr     x0, [x0, #0x70]                            M:Clicker.HandFollowClick::<ClickAt>b__2_0
02d63920: bl      #0x2b70db0                                 fn_2b70db0
02d63924: adrp    x0, #0x6264000                             
02d63928: ldr     x0, [x0, #0xe8]                            T:DG.Tweening.TweenCallback
02d6392c: bl      #0x2b70db0                                 fn_2b70db0
02d63930: adrp    x0, #0x6266000                             
02d63934: ldr     x0, [x0, #0x928]                           MS:DG.Tweening.TweenSettingsExtensions::OnComplete
02d63938: bl      #0x2b70db0                                 fn_2b70db0
02d6393c: adrp    x0, #0x6266000                             
02d63940: ldr     x0, [x0, #0x880]                           MS:DG.Tweening.TweenSettingsExtensions::SetEase
02d63944: bl      #0x2b70db0                                 fn_2b70db0
02d63948: mov     w8, #1                                     
02d6394c: strb    w8, [x21, #0x361]                          
02d63950: ldr     x0, [x19, #0x20]                           ._movableHand
02d63954: mov     w1, wzr                                    
02d63958: mov     x2, xzr                                    
02d6395c: bl      #0x2d9d5d0                                 DG.Tweening.ShortcutExtensions::DOKill
02d63960: adrp    x22, #0x662f000                            
02d63964: ldr     x21, [x19, #0x20]                          ._movableHand
02d63968: ldrb    w8, [x22, #0x91a]                          
02d6396c: cbnz    w8, #0x2d63984                             
02d63970: adrp    x0, #0x6264000                             
02d63974: ldr     x0, [x0, #0xd8]                            T:UnityEngine.Vector3
02d63978: bl      #0x2b70db0                                 fn_2b70db0
02d6397c: mov     w8, #1                                     
02d63980: strb    w8, [x22, #0x91a]                          
02d63984: cbz     x21, #0x2d63a48                            
02d63988: adrp    x8, #0x6264000                             
02d6398c: mov     x0, x21                                    
02d63990: mov     x1, xzr                                    
02d63994: ldr     x8, [x8, #0xd8]                            T:UnityEngine.Vector3
02d63998: ldr     x8, [x8]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d6399c: ldr     x8, [x8, #0xb8]                            MS:DG.Tweening.Core.Extensions::SetSpecialStartupMode
02d639a0: ldp     s1, s2, [x8, #4]                           
02d639a4: ldr     s0, [x8]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d639a8: bl      #0x5b45cec                                 UnityEngine.Transform::set_localPosition
02d639ac: cbz     x20, #0x2d63a48                            
02d639b0: adrp    x22, #0x6266000                            
02d639b4: adrp    x23, #0x6264000                            
02d639b8: adrp    x24, #0x626c000                            
02d639bc: adrp    x25, #0x6266000                            
02d639c0: ldr     x22, [x22, #0x880]                         MS:DG.Tweening.TweenSettingsExtensions::SetEase
02d639c4: ldr     x23, [x23, #0xe8]                          T:DG.Tweening.TweenCallback
02d639c8: ldr     x24, [x24, #0x70]                          M:Clicker.HandFollowClick::<ClickAt>b__2_0
02d639cc: ldr     x25, [x25, #0x928]                         MS:DG.Tweening.TweenSettingsExtensions::OnComplete
02d639d0: ldr     x21, [x19, #0x20]                          ._movableHand
02d639d4: mov     x0, x20                                    
02d639d8: mov     x1, xzr                                    
02d639dc: bl      #0x5b467ac                                 UnityEngine.Transform::get_position
02d639e0: adrp    x8, #0x1084000                             
02d639e4: mov     x0, x21                                    
02d639e8: mov     w1, wzr                                    
02d639ec: ldr     s3, [x8, #0xeec]                           [1084eec]=457ff0003dcccccd f=0.1,4095
02d639f0: mov     x2, xzr                                    
02d639f4: bl      #0x2d975e4                                 DG.Tweening.ShortcutExtensions::DOMove
02d639f8: ldr     x2, [x22]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d639fc: mov     w1, #2                                     
02d63a00: bl      #0x336fa0c                                 fn_336fa0c
02d63a04: ldr     x8, [x23]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d63a08: mov     x20, x0                                    
02d63a0c: mov     x0, x8                                     
02d63a10: bl      #0x2b7104c                                 fn_2b7104c
02d63a14: ldr     x2, [x24]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d63a18: mov     x1, x19                                    
02d63a1c: mov     x3, xzr                                    
02d63a20: mov     x21, x0                                    
02d63a24: bl      #0x2d89dc4                                 DG.Tweening.TweenCallback::.ctor
02d63a28: mov     x0, x20                                    
02d63a2c: mov     x1, x21                                    
02d63a30: ldr     x2, [x25]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d63a34: ldp     x20, x19, [sp, #0x30]                      
02d63a38: ldp     x22, x21, [sp, #0x20]                      
02d63a3c: ldp     x24, x23, [sp, #0x10]                      
02d63a40: ldp     x30, x25, [sp], #0x40                      
02d63a44: b       #0x336f26c                                 
02d63a48: bl      #0x2b7105c                                 fn_2b7105c
## .ctor() -> void
---- Clicker.HandFollowClick::.ctor 0x2d6b1b8
02d6b1b8: mov     x1, xzr                                    
02d6b1bc: b       #0x5b397b0                                 UnityEngine.MonoBehaviour::.ctor
## <ClickAt>b__2_0() -> void
---- Clicker.HandFollowClick::<ClickAt>b__2_0 0x2d6b1c0
02d6b1c0: stp     x30, x21, [sp, #-0x20]!                    
02d6b1c4: stp     x20, x19, [sp, #0x10]                      
02d6b1c8: adrp    x20, #0x6630000                            
02d6b1cc: mov     x19, x0                                    
02d6b1d0: ldrb    w8, [x20, #0x362]                          
02d6b1d4: tbnz    w8, #0, #0x2d6b1ec                         
02d6b1d8: adrp    x0, #0x6266000                             
02d6b1dc: ldr     x0, [x0, #0x880]                           MS:DG.Tweening.TweenSettingsExtensions::SetEase
02d6b1e0: bl      #0x2b70db0                                 fn_2b70db0
02d6b1e4: mov     w8, #1                                     
02d6b1e8: strb    w8, [x20, #0x362]                          
02d6b1ec: adrp    x21, #0x662f000                            
02d6b1f0: adrp    x20, #0x6266000                            
02d6b1f4: ldrb    w8, [x21, #0x91a]                          
02d6b1f8: ldr     x20, [x20, #0x880]                         MS:DG.Tweening.TweenSettingsExtensions::SetEase
02d6b1fc: ldr     x19, [x19, #0x20]                          ._movableHand
02d6b200: cbnz    w8, #0x2d6b218                             
02d6b204: adrp    x0, #0x6264000                             
02d6b208: ldr     x0, [x0, #0xd8]                            T:UnityEngine.Vector3
02d6b20c: bl      #0x2b70db0                                 fn_2b70db0
02d6b210: mov     w8, #1                                     
02d6b214: strb    w8, [x21, #0x91a]                          
02d6b218: adrp    x8, #0x6264000                             
02d6b21c: mov     x0, x19                                    
02d6b220: mov     w1, wzr                                    
02d6b224: ldr     x8, [x8, #0xd8]                            T:UnityEngine.Vector3
02d6b228: mov     x2, xzr                                    
02d6b22c: ldr     x8, [x8]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d6b230: ldr     x8, [x8, #0xb8]                            MS:DG.Tweening.Core.Extensions::SetSpecialStartupMode
02d6b234: ldp     s0, s1, [x8]                               
02d6b238: ldr     s2, [x8, #8]                               T:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass2_0
02d6b23c: adrp    x8, #0x1084000                             
02d6b240: ldr     s3, [x8, #0xeec]                           [1084eec]=457ff0003dcccccd f=0.1,4095
02d6b244: bl      #0x2d97cf0                                 DG.Tweening.ShortcutExtensions::DOLocalMove
02d6b248: ldr     x2, [x20]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d6b24c: ldp     x20, x19, [sp, #0x10]                      
02d6b250: mov     w1, #3                                     
02d6b254: ldp     x30, x21, [sp], #0x20                      
02d6b258: b       #0x336fa0c                                 
