#### CLASS Framework.Logger parent= object
## Log(object message, UnityEngine.Object context, System.Nullable`1<UnityEngine.Color> color) -> void
---- Framework.Logger::Log 0x2cc0cf8
02cc0cf8: sub     sp, sp, #0x50                              
02cc0cfc: stp     x30, x23, [sp, #0x20]                      
02cc0d00: stp     x22, x21, [sp, #0x30]                      
02cc0d04: stp     x20, x19, [sp, #0x40]                      
02cc0d08: adrp    x23, #0x662f000                            
02cc0d0c: adrp    x22, #0x6263000                            
02cc0d10: mov     x21, x2                                    
02cc0d14: ldrb    w8, [x23, #0xc14]                          
02cc0d18: ldr     x22, [x22, #0x928]                         T:UnityEngine.Debug
02cc0d1c: mov     x19, x1                                    
02cc0d20: mov     x20, x0                                    
02cc0d24: tbnz    w8, #0, #0x2cc0d3c                         
02cc0d28: adrp    x0, #0x6263000                             
02cc0d2c: ldr     x0, [x0, #0x928]                           T:UnityEngine.Debug
02cc0d30: bl      #0x2b70db0                                 fn_2b70db0
02cc0d34: mov     w8, #1                                     
02cc0d38: strb    w8, [x23, #0xc14]                          
02cc0d3c: ldr     q0, [x21]                                  
02cc0d40: ldr     w8, [x21, #0x10]                           
02cc0d44: mov     x2, sp                                     
02cc0d48: mov     x0, x20                                    
02cc0d4c: mov     x1, x19                                    
02cc0d50: str     q0, [sp]                                   
02cc0d54: str     w8, [sp, #0x10]                            
02cc0d58: bl      #0x2cc0d98                                 Framework.Logger::FormatMessage
02cc0d5c: ldr     x8, [x22]                                  &2c5bbd4(=a9bd7bfdd503233f)
02cc0d60: mov     x20, x0                                    
02cc0d64: ldr     w9, [x8, #0xe4]                            
02cc0d68: cbnz    w9, #0x2cc0d74                             
02cc0d6c: mov     x0, x8                                     
02cc0d70: bl      #0x2b70f30                                 fn_2b70f30
02cc0d74: mov     x0, x20                                    
02cc0d78: mov     x1, x19                                    
02cc0d7c: mov     x2, xzr                                    
02cc0d80: bl      #0x5af22fc                                 UnityEngine.Debug::Log
02cc0d84: ldp     x20, x19, [sp, #0x40]                      
02cc0d88: ldp     x22, x21, [sp, #0x30]                      
02cc0d8c: ldp     x30, x23, [sp, #0x20]                      
02cc0d90: add     sp, sp, #0x50                              
02cc0d94: ret                                                
## LogWarning(object message, UnityEngine.Object context, System.Nullable`1<UnityEngine.Color> color) -> void
---- Framework.Logger::LogWarning 0x2cc0fbc
02cc0fbc: sub     sp, sp, #0x50                              
02cc0fc0: stp     x30, x23, [sp, #0x20]                      
02cc0fc4: stp     x22, x21, [sp, #0x30]                      
02cc0fc8: stp     x20, x19, [sp, #0x40]                      
02cc0fcc: adrp    x23, #0x662f000                            
02cc0fd0: adrp    x22, #0x6263000                            
02cc0fd4: mov     x21, x2                                    
02cc0fd8: ldrb    w8, [x23, #0xc15]                          
02cc0fdc: ldr     x22, [x22, #0x928]                         T:UnityEngine.Debug
02cc0fe0: mov     x19, x1                                    
02cc0fe4: mov     x20, x0                                    
02cc0fe8: tbnz    w8, #0, #0x2cc1000                         
02cc0fec: adrp    x0, #0x6263000                             
02cc0ff0: ldr     x0, [x0, #0x928]                           T:UnityEngine.Debug
02cc0ff4: bl      #0x2b70db0                                 fn_2b70db0
02cc0ff8: mov     w8, #1                                     
02cc0ffc: strb    w8, [x23, #0xc15]                          
02cc1000: ldr     q0, [x21]                                  
02cc1004: ldr     w8, [x21, #0x10]                           
02cc1008: mov     x2, sp                                     
02cc100c: mov     x0, x20                                    
02cc1010: mov     x1, x19                                    
02cc1014: str     q0, [sp]                                   
02cc1018: str     w8, [sp, #0x10]                            
02cc101c: bl      #0x2cc0d98                                 Framework.Logger::FormatMessage
02cc1020: ldr     x8, [x22]                                  &2c5bbd4(=a9bd7bfdd503233f)
02cc1024: mov     x20, x0                                    
02cc1028: ldr     w9, [x8, #0xe4]                            
02cc102c: cbnz    w9, #0x2cc1038                             
02cc1030: mov     x0, x8                                     
02cc1034: bl      #0x2b70f30                                 fn_2b70f30
02cc1038: mov     x0, x20                                    
02cc103c: mov     x1, x19                                    
02cc1040: mov     x2, xzr                                    
02cc1044: bl      #0x5af2d9c                                 UnityEngine.Debug::LogWarning
02cc1048: ldp     x20, x19, [sp, #0x40]                      
02cc104c: ldp     x22, x21, [sp, #0x30]                      
02cc1050: ldp     x30, x23, [sp, #0x20]                      
02cc1054: add     sp, sp, #0x50                              
02cc1058: ret                                                
## LogError(object message, UnityEngine.Object context, System.Nullable`1<UnityEngine.Color> color) -> void
---- Framework.Logger::LogError 0x2cc105c
02cc105c: sub     sp, sp, #0x50                              
02cc1060: stp     x30, x23, [sp, #0x20]                      
02cc1064: stp     x22, x21, [sp, #0x30]                      
02cc1068: stp     x20, x19, [sp, #0x40]                      
02cc106c: adrp    x23, #0x662f000                            
02cc1070: adrp    x22, #0x6263000                            
02cc1074: mov     x21, x2                                    
02cc1078: ldrb    w8, [x23, #0xc16]                          
02cc107c: ldr     x22, [x22, #0x928]                         T:UnityEngine.Debug
02cc1080: mov     x19, x1                                    
02cc1084: mov     x20, x0                                    
02cc1088: tbnz    w8, #0, #0x2cc10a0                         
02cc108c: adrp    x0, #0x6263000                             
02cc1090: ldr     x0, [x0, #0x928]                           T:UnityEngine.Debug
02cc1094: bl      #0x2b70db0                                 fn_2b70db0
02cc1098: mov     w8, #1                                     
02cc109c: strb    w8, [x23, #0xc16]                          
02cc10a0: ldr     q0, [x21]                                  
02cc10a4: ldr     w8, [x21, #0x10]                           
02cc10a8: mov     x2, sp                                     
02cc10ac: mov     x0, x20                                    
02cc10b0: mov     x1, x19                                    
02cc10b4: str     q0, [sp]                                   
02cc10b8: str     w8, [sp, #0x10]                            
02cc10bc: bl      #0x2cc0d98                                 Framework.Logger::FormatMessage
02cc10c0: ldr     x8, [x22]                                  &2c5bbd4(=a9bd7bfdd503233f)
02cc10c4: mov     x20, x0                                    
02cc10c8: ldr     w9, [x8, #0xe4]                            
02cc10cc: cbnz    w9, #0x2cc10d8                             
02cc10d0: mov     x0, x8                                     
02cc10d4: bl      #0x2b70f30                                 fn_2b70f30
02cc10d8: mov     x0, x20                                    
02cc10dc: mov     x1, x19                                    
02cc10e0: mov     x2, xzr                                    
02cc10e4: bl      #0x5af2948                                 UnityEngine.Debug::LogError
02cc10e8: ldp     x20, x19, [sp, #0x40]                      
02cc10ec: ldp     x22, x21, [sp, #0x30]                      
02cc10f0: ldp     x30, x23, [sp, #0x20]                      
02cc10f4: add     sp, sp, #0x50                              
02cc10f8: ret                                                
## LogAssert(bool condition, object message, UnityEngine.Object context, System.Nullable`1<UnityEngine.Color> color) -> void
---- Framework.Logger::LogAssert 0x2cc10fc
02cc10fc: ret                                                
## FormatMessage(object message, UnityEngine.Object context, System.Nullable`1<UnityEngine.Color> color) -> string
---- Framework.Logger::FormatMessage 0x2cc0d98
02cc0d98: sub     sp, sp, #0x40                              
02cc0d9c: stp     x30, x23, [sp, #0x10]                      
02cc0da0: stp     x22, x21, [sp, #0x20]                      
02cc0da4: stp     x20, x19, [sp, #0x30]                      
02cc0da8: adrp    x22, #0x662f000                            
02cc0dac: mov     x19, x2                                    
02cc0db0: mov     x21, x1                                    
02cc0db4: ldrb    w8, [x22, #0xc17]                          
02cc0db8: mov     x20, x0                                    
02cc0dbc: tbnz    w8, #0, #0x2cc0e34                         
02cc0dc0: adrp    x0, #0x6267000                             
02cc0dc4: ldr     x0, [x0, #0x30]                            MS:System.Nullable`1::get_HasValue
02cc0dc8: bl      #0x2b70db0                                 fn_2b70db0
02cc0dcc: adrp    x0, #0x6267000                             
02cc0dd0: ldr     x0, [x0, #0x38]                            MS:System.Nullable`1::get_Value
02cc0dd4: bl      #0x2b70db0                                 fn_2b70db0
02cc0dd8: adrp    x0, #0x6263000                             
02cc0ddc: ldr     x0, [x0, #0x918]                           T:UnityEngine.Object
02cc0de0: bl      #0x2b70db0                                 fn_2b70db0
02cc0de4: adrp    x0, #0x6263000                             
02cc0de8: ldr     x0, [x0, #0x9c8]                           T:System.Text.StringBuilder
02cc0dec: bl      #0x2b70db0                                 fn_2b70db0
02cc0df0: adrp    x0, #0x6266000                             
02cc0df4: ldr     x0, [x0, #0x1a8]                           S:'] '
02cc0df8: bl      #0x2b70db0                                 fn_2b70db0
02cc0dfc: adrp    x0, #0x6267000                             
02cc0e00: ldr     x0, [x0, #0x40]                            S:'<color=#'
02cc0e04: bl      #0x2b70db0                                 fn_2b70db0
02cc0e08: adrp    x0, #0x6267000                             
02cc0e0c: ldr     x0, [x0, #0x48]                            S:'</color>'
02cc0e10: bl      #0x2b70db0                                 fn_2b70db0
02cc0e14: adrp    x0, #0x6267000                             
02cc0e18: ldr     x0, [x0, #0x50]                            S:'['
02cc0e1c: bl      #0x2b70db0                                 fn_2b70db0
02cc0e20: adrp    x0, #0x6267000                             
02cc0e24: ldr     x0, [x0, #0x58]                            S:'>'
02cc0e28: bl      #0x2b70db0                                 fn_2b70db0
02cc0e2c: mov     w8, #1                                     
02cc0e30: strb    w8, [x22, #0xc17]                          
02cc0e34: cbz     x20, #0x2cc0f78                            
02cc0e38: adrp    x22, #0x6263000                            
02cc0e3c: adrp    x23, #0x6263000                            
02cc0e40: mov     x0, x20                                    
02cc0e44: ldr     x22, [x22, #0x9c8]                         T:System.Text.StringBuilder
02cc0e48: ldr     x8, [x20]                                  
02cc0e4c: ldr     x23, [x23, #0x918]                         T:UnityEngine.Object
02cc0e50: ldp     x9, x1, [x8, #0x168]                       
02cc0e54: blr     x9                                         
02cc0e58: ldr     x8, [x22]                                  &2c5bbd4(=a9bd7bfdd503233f)
02cc0e5c: mov     x22, x0                                    
02cc0e60: mov     x0, x8                                     
02cc0e64: bl      #0x2b7104c                                 fn_2b7104c
02cc0e68: mov     x1, x22                                    
02cc0e6c: mov     x2, xzr                                    
02cc0e70: mov     x20, x0                                    
02cc0e74: bl      #0x4caf988                                 System.Text.StringBuilder::.ctor
02cc0e78: ldr     x0, [x23]                                  &2c5bbd4(=a9bd7bfdd503233f)
02cc0e7c: ldr     w8, [x0, #0xe4]                            [62670e4]=0 f=0,0
02cc0e80: cbnz    w8, #0x2cc0e88                             
02cc0e84: bl      #0x2b70f30                                 fn_2b70f30
02cc0e88: mov     x0, x21                                    
02cc0e8c: mov     x1, xzr                                    
02cc0e90: mov     x2, xzr                                    
02cc0e94: bl      #0x5b3666c                                 UnityEngine.Object::op_Inequality
02cc0e98: tbz     w0, #0, #0x2cc0eec                         
02cc0e9c: cbz     x21, #0x2cc0fb8                            
02cc0ea0: mov     x0, x21                                    
02cc0ea4: mov     x1, xzr                                    
02cc0ea8: bl      #0x5b3bba4                                 UnityEngine.Object::get_name
02cc0eac: adrp    x8, #0x6267000                             
02cc0eb0: adrp    x9, #0x6266000                             
02cc0eb4: mov     x1, x0                                     
02cc0eb8: ldr     x8, [x8, #0x50]                            S:'['
02cc0ebc: ldr     x9, [x9, #0x1a8]                           S:'] '
02cc0ec0: mov     x3, xzr                                    
02cc0ec4: ldr     x8, [x8]                                   S:'didu'
02cc0ec8: ldr     x2, [x9]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cc0ecc: mov     x0, x8                                     
02cc0ed0: bl      #0x4ca6dbc                                 System.String::Concat
02cc0ed4: cbz     x20, #0x2cc0fb8                            
02cc0ed8: mov     x2, x0                                     
02cc0edc: mov     x0, x20                                    
02cc0ee0: mov     w1, wzr                                    
02cc0ee4: mov     x3, xzr                                    
02cc0ee8: bl      #0x4cb1ad0                                 System.Text.StringBuilder::Insert
02cc0eec: ldrb    w8, [x19]                                  
02cc0ef0: cbz     w8, #0x2cc0f90                             
02cc0ef4: adrp    x8, #0x6267000                             
02cc0ef8: mov     x0, x19                                    
02cc0efc: ldr     x8, [x8, #0x38]                            MS:System.Nullable`1::get_Value
02cc0f00: ldr     x1, [x8]                                   S:'didu'
02cc0f04: bl      #0x38e6140                                 fn_38e6140
02cc0f08: mov     x0, sp                                     
02cc0f0c: mov     x1, xzr                                    
02cc0f10: stp     s0, s1, [sp]                               
02cc0f14: stp     s2, s3, [sp, #8]                           
02cc0f18: bl      #0x5b21048                                 UnityEngine.ColorUtility::ToHtmlStringRGB
02cc0f1c: adrp    x8, #0x6267000                             
02cc0f20: adrp    x9, #0x6267000                             
02cc0f24: mov     x1, x0                                     
02cc0f28: ldr     x8, [x8, #0x40]                            S:'<color=#'
02cc0f2c: ldr     x9, [x9, #0x58]                            S:'>'
02cc0f30: mov     x3, xzr                                    
02cc0f34: ldr     x8, [x8]                                   S:'didu'
02cc0f38: ldr     x2, [x9]                                   S:'didu'
02cc0f3c: mov     x0, x8                                     
02cc0f40: bl      #0x4ca6dbc                                 System.String::Concat
02cc0f44: cbz     x20, #0x2cc0fb8                            
02cc0f48: mov     x2, x0                                     
02cc0f4c: mov     x0, x20                                    
02cc0f50: mov     w1, wzr                                    
02cc0f54: mov     x3, xzr                                    
02cc0f58: bl      #0x4cb1ad0                                 System.Text.StringBuilder::Insert
02cc0f5c: adrp    x8, #0x6267000                             
02cc0f60: mov     x0, x20                                    
02cc0f64: mov     x2, xzr                                    
02cc0f68: ldr     x8, [x8, #0x48]                            S:'</color>'
02cc0f6c: ldr     x1, [x8]                                   S:'didu'
02cc0f70: bl      #0x4cb0f1c                                 System.Text.StringBuilder::Append
02cc0f74: b       #0x2cc0f94                                 
02cc0f78: adrp    x8, #0x6263000                             
02cc0f7c: ldr     x8, [x8, #0x970]                           &6645c70(=0)
02cc0f80: ldr     x8, [x8, #0x90]                            &2c5beb4(=14c8d222d503245f)
02cc0f84: ldr     x8, [x8, #0xb8]                            &6263108(=0)
02cc0f88: ldr     x0, [x8]                                   &2c5bbd4(=a9bd7bfdd503233f)
02cc0f8c: b       #0x2cc0fa4                                 
02cc0f90: cbz     x20, #0x2cc0fb8                            
02cc0f94: ldr     x8, [x20]                                  
02cc0f98: mov     x0, x20                                    
02cc0f9c: ldp     x9, x1, [x8, #0x168]                       
02cc0fa0: blr     x9                                         
02cc0fa4: ldp     x20, x19, [sp, #0x30]                      
02cc0fa8: ldp     x22, x21, [sp, #0x20]                      
02cc0fac: ldp     x30, x23, [sp, #0x10]                      
02cc0fb0: add     sp, sp, #0x40                              
02cc0fb4: ret                                                
02cc0fb8: bl      #0x2b7105c                                 fn_2b7105c
