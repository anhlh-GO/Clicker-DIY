#### CLASS Home.HomeController parent= UnityEngine.MonoBehaviour
#   field UIManager                      UIManager                                          off=0x20 attr=1 SerializeField
#   field _envGo                         UnityEngine.GameObject                             off=0x28 attr=1 SerializeField
#   field _luckyWheelGo                  UnityEngine.GameObject                             off=0x30 attr=1 SerializeField
#   field _worldBlockGo                  UnityEngine.GameObject                             off=0x38 attr=1 SerializeField
#   field _decorGo                       UnityEngine.GameObject                             off=0x40 attr=1 SerializeField
#   field _blindbagDecorGo               UnityEngine.GameObject                             off=0x48 attr=1 SerializeField
#   field _isOverUi                      bool                                               off=0x50 attr=1 SerializeField
#   field _luckyWheelShowed              bool                                               off=0x51 attr=1 
## Start() -> void
---- Home.HomeController::Start 0x2d1e354
02d1e354: str     x30, [sp, #-0x40]!                         
02d1e358: stp     x24, x23, [sp, #0x10]                      
02d1e35c: stp     x22, x21, [sp, #0x20]                      
02d1e360: stp     x20, x19, [sp, #0x30]                      
02d1e364: adrp    x20, #0x6630000                            
02d1e368: mov     x19, x0                                    
02d1e36c: ldrb    w8, [x20, #0x32]                           
02d1e370: tbnz    w8, #0, #0x2d1e3b8                         
02d1e374: adrp    x0, #0x6269000                             
02d1e378: ldr     x0, [x0, #0xd38]                           M:Home.HomeController::OnHideDecorPanelHandler
02d1e37c: bl      #0x2b70db0                                 fn_2b70db0
02d1e380: adrp    x0, #0x6269000                             
02d1e384: ldr     x0, [x0, #0xd40]                           M:Home.HomeController::OnShowDecorPanelHandler
02d1e388: bl      #0x2b70db0                                 fn_2b70db0
02d1e38c: adrp    x0, #0x6266000                             
02d1e390: ldr     x0, [x0, #0xac0]                           MS:MonoSingleton`1::get_Instance
02d1e394: bl      #0x2b70db0                                 fn_2b70db0
02d1e398: adrp    x0, #0x6268000                             
02d1e39c: ldr     x0, [x0, #0x108]                           MS:UIManager::ShowScreen
02d1e3a0: bl      #0x2b70db0                                 fn_2b70db0
02d1e3a4: adrp    x0, #0x6266000                             
02d1e3a8: ldr     x0, [x0, #0xb38]                           T:type19687(k15)
02d1e3ac: bl      #0x2b70db0                                 fn_2b70db0
02d1e3b0: mov     w8, #1                                     
02d1e3b4: strb    w8, [x20, #0x32]                           
02d1e3b8: ldr     x0, [x19, #0x20]                           .UIManager
02d1e3bc: cbz     x0, #0x2d1e544                             
02d1e3c0: adrp    x8, #0x6268000                             
02d1e3c4: ldr     x8, [x8, #0x108]                           MS:UIManager::ShowScreen
02d1e3c8: ldr     x1, [x8]                                   S:'{0}/2'
02d1e3cc: bl      #0x33fc0e8                                 fn_33fc0e8
02d1e3d0: cbz     x0, #0x2d1e544                             
02d1e3d4: ldr     x21, [x0, #0xb8]                           S:'banner_native_refresh_time'
02d1e3d8: mov     x20, x0                                    
02d1e3dc: cbz     x21, #0x2d1e544                            
02d1e3e0: adrp    x24, #0x6266000                            
02d1e3e4: adrp    x23, #0x6269000                            
02d1e3e8: ldr     x24, [x24, #0xb38]                         T:type19687(k15)
02d1e3ec: ldr     x23, [x23, #0xd40]                         M:Home.HomeController::OnShowDecorPanelHandler
02d1e3f0: ldr     x22, [x21, #0x90]!                         
02d1e3f4: ldr     x0, [x24]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d1e3f8: bl      #0x2b7104c                                 fn_2b7104c
02d1e3fc: ldr     x2, [x23]                                  T:Trading.TradingSession/<>c__DisplayClass56_0
02d1e400: mov     x1, x19                                    
02d1e404: mov     x3, xzr                                    
02d1e408: mov     x23, x0                                    
02d1e40c: bl      #0x3edfba8                                 fn_3edfba8
02d1e410: mov     x0, x22                                    
02d1e414: mov     x1, x23                                    
02d1e418: mov     x2, xzr                                    
02d1e41c: bl      #0x4e570ac                                 System.Delegate::Combine
02d1e420: cbz     x0, #0x2d1e460                             
02d1e424: ldr     x23, [x24]                                 M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d1e428: mov     x22, x0                                    
02d1e42c: mov     x1, x23                                    
02d1e430: bl      #0x2b70f34                                 fn_2b70f34
02d1e434: cbz     x0, #0x2d1e454                             
02d1e438: ldr     x23, [x24]                                 M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d1e43c: str     x0, [x21]                                  
02d1e440: mov     x0, x22                                    
02d1e444: mov     x1, x23                                    
02d1e448: bl      #0x2b70f34                                 fn_2b70f34
02d1e44c: mov     x1, x0                                     
02d1e450: cbnz    x0, #0x2d1e468                             
02d1e454: mov     x0, x22                                    
02d1e458: mov     x1, x23                                    
02d1e45c: bl      #0x2b713dc                                 fn_2b713dc
02d1e460: mov     x1, xzr                                    
02d1e464: str     xzr, [x21]                                 
02d1e468: mov     x0, x21                                    
02d1e46c: bl      #0x2b70d54                                 fn_2b70d54
02d1e470: ldr     x20, [x20, #0xb8]                          
02d1e474: cbz     x20, #0x2d1e544                            
02d1e478: adrp    x22, #0x6269000                            
02d1e47c: ldr     x22, [x22, #0xd38]                         M:Home.HomeController::OnHideDecorPanelHandler
02d1e480: ldr     x0, [x24]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d1e484: ldr     x21, [x20, #0x98]!                         
02d1e488: bl      #0x2b7104c                                 fn_2b7104c
02d1e48c: ldr     x2, [x22]                                  T:Trading.TradingSession/<>c__DisplayClass56_0
02d1e490: mov     x1, x19                                    
02d1e494: mov     x3, xzr                                    
02d1e498: mov     x22, x0                                    
02d1e49c: bl      #0x3edfba8                                 fn_3edfba8
02d1e4a0: mov     x0, x21                                    
02d1e4a4: mov     x1, x22                                    
02d1e4a8: mov     x2, xzr                                    
02d1e4ac: bl      #0x4e570ac                                 System.Delegate::Combine
02d1e4b0: cbz     x0, #0x2d1e4f0                             
02d1e4b4: ldr     x21, [x24]                                 M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d1e4b8: mov     x19, x0                                    
02d1e4bc: mov     x1, x21                                    
02d1e4c0: bl      #0x2b70f34                                 fn_2b70f34
02d1e4c4: cbz     x0, #0x2d1e4e4                             
02d1e4c8: ldr     x21, [x24]                                 M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d1e4cc: str     x0, [x20]                                  
02d1e4d0: mov     x0, x19                                    
02d1e4d4: mov     x1, x21                                    
02d1e4d8: bl      #0x2b70f34                                 fn_2b70f34
02d1e4dc: mov     x1, x0                                     
02d1e4e0: cbnz    x0, #0x2d1e4f8                             
02d1e4e4: mov     x0, x19                                    
02d1e4e8: mov     x1, x21                                    
02d1e4ec: bl      #0x2b713dc                                 fn_2b713dc
02d1e4f0: mov     x1, xzr                                    
02d1e4f4: str     xzr, [x20]                                 
02d1e4f8: adrp    x19, #0x6266000                            
02d1e4fc: mov     x0, x20                                    
02d1e500: ldr     x19, [x19, #0xac0]                         MS:MonoSingleton`1::get_Instance
02d1e504: bl      #0x2b70d54                                 fn_2b70d54
02d1e508: ldr     x0, [x19]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d1e50c: bl      #0x3769600                                 fn_3769600
02d1e510: cbz     x0, #0x2d1e544                             
02d1e514: mov     x1, xzr                                    
02d1e518: bl      #0x2cac928                                 GameSession::get_CharacterContainer
02d1e51c: cbz     x0, #0x2d1e544                             
02d1e520: mov     x1, xzr                                    
02d1e524: bl      #0x5b368f0                                 UnityEngine.GameObject::get_transform
02d1e528: ldp     x20, x19, [sp, #0x30]                      
02d1e52c: fmov    s0, #-1.50000000                           
02d1e530: ldp     x22, x21, [sp, #0x20]                      
02d1e534: mov     x1, xzr                                    
02d1e538: ldp     x24, x23, [sp, #0x10]                      
02d1e53c: ldr     x30, [sp], #0x40                           
02d1e540: b       #0x2dbfda4                                 Redcode.Extensions.TransformExtensions::SetLocalPositionY
02d1e544: bl      #0x2b7105c                                 fn_2b7105c
## ShowBlindbagDecor(bool isShow) -> void
---- Home.HomeController::ShowBlindbagDecor 0x2d1e548
02d1e548: stp     x30, x21, [sp, #-0x20]!                    
02d1e54c: stp     x20, x19, [sp, #0x10]                      
02d1e550: mov     x19, x0                                    
02d1e554: ldr     x0, [x0, #0x48]                            ._blindbagDecorGo
02d1e558: cbz     x0, #0x2d1e5f0                             
02d1e55c: mov     w20, w1                                    
02d1e560: and     w1, w1, #1                                 
02d1e564: mov     x2, xzr                                    
02d1e568: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d1e56c: ldr     x0, [x19, #0x40]                           ._decorGo
02d1e570: cbz     x0, #0x2d1e5f0                             
02d1e574: mov     w8, #1                                     
02d1e578: mov     x2, xzr                                    
02d1e57c: mvn     w21, w20                                   
02d1e580: bic     w1, w8, w20                                
02d1e584: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d1e588: tbnz    w21, #0, #0x2d1e5c4                        
02d1e58c: ldr     x0, [x19, #0x30]                           ._luckyWheelGo
02d1e590: cbz     x0, #0x2d1e5f0                             
02d1e594: mov     x1, xzr                                    
02d1e598: bl      #0x5b36bfc                                 UnityEngine.GameObject::get_activeSelf
02d1e59c: tbz     w0, #0, #0x2d1e5e4                         
02d1e5a0: ldr     x0, [x19, #0x30]                           ._luckyWheelGo
02d1e5a4: mov     w8, #1                                     
02d1e5a8: strb    w8, [x19, #0x51]                           ._luckyWheelShowed
02d1e5ac: cbz     x0, #0x2d1e5f0                             
02d1e5b0: ldp     x20, x19, [sp, #0x10]                      
02d1e5b4: mov     w1, wzr                                    
02d1e5b8: mov     x2, xzr                                    
02d1e5bc: ldp     x30, x21, [sp], #0x20                      
02d1e5c0: b       #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d1e5c4: ldrb    w8, [x19, #0x51]                           ._luckyWheelShowed
02d1e5c8: cbz     w8, #0x2d1e5e4                             
02d1e5cc: ldr     x0, [x19, #0x30]                           ._luckyWheelGo
02d1e5d0: cbz     x0, #0x2d1e5f0                             
02d1e5d4: mov     w1, #1                                     
02d1e5d8: mov     x2, xzr                                    
02d1e5dc: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d1e5e0: strb    wzr, [x19, #0x51]                          ._luckyWheelShowed
02d1e5e4: ldp     x20, x19, [sp, #0x10]                      
02d1e5e8: ldp     x30, x21, [sp], #0x20                      
02d1e5ec: ret                                                
02d1e5f0: bl      #0x2b7105c                                 fn_2b7105c
## SetActiveLuckWheel(bool value) -> Home.HomeController
---- Home.HomeController::SetActiveLuckWheel 0x2d1e5f4
02d1e5f4: ret                                                
## SetActiveWorldBlock(bool value) -> Home.HomeController
---- Home.HomeController::SetActiveWorldBlock 0x2d1e5f8
02d1e5f8: stp     x30, x19, [sp, #-0x10]!                    
02d1e5fc: mov     x19, x0                                    
02d1e600: ldr     x0, [x0, #0x38]                            ._worldBlockGo
02d1e604: cbz     x0, #0x2d1e620                             
02d1e608: and     w1, w1, #1                                 
02d1e60c: mov     x2, xzr                                    
02d1e610: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d1e614: mov     x0, x19                                    
02d1e618: ldp     x30, x19, [sp], #0x10                      
02d1e61c: ret                                                
02d1e620: bl      #0x2b7105c                                 fn_2b7105c
## SetActiveDecor(bool value) -> Home.HomeController
---- Home.HomeController::SetActiveDecor 0x2d1e624
02d1e624: stp     x30, x19, [sp, #-0x10]!                    
02d1e628: mov     x19, x0                                    
02d1e62c: ldr     x0, [x0, #0x40]                            ._decorGo
02d1e630: cbz     x0, #0x2d1e64c                             
02d1e634: and     w1, w1, #1                                 
02d1e638: mov     x2, xzr                                    
02d1e63c: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d1e640: mov     x0, x19                                    
02d1e644: ldp     x30, x19, [sp], #0x10                      
02d1e648: ret                                                
02d1e64c: bl      #0x2b7105c                                 fn_2b7105c
## OnDisable() -> void
---- Home.HomeController::OnDisable 0x2d1e650
02d1e650: str     x30, [sp, #-0x40]!                         
02d1e654: stp     x24, x23, [sp, #0x10]                      
02d1e658: stp     x22, x21, [sp, #0x20]                      
02d1e65c: stp     x20, x19, [sp, #0x30]                      
02d1e660: adrp    x20, #0x6630000                            
02d1e664: mov     x19, x0                                    
02d1e668: ldrb    w8, [x20, #0x33]                           
02d1e66c: tbnz    w8, #0, #0x2d1e6a8                         
02d1e670: adrp    x0, #0x6269000                             
02d1e674: ldr     x0, [x0, #0xd38]                           M:Home.HomeController::OnHideDecorPanelHandler
02d1e678: bl      #0x2b70db0                                 fn_2b70db0
02d1e67c: adrp    x0, #0x6269000                             
02d1e680: ldr     x0, [x0, #0xd40]                           M:Home.HomeController::OnShowDecorPanelHandler
02d1e684: bl      #0x2b70db0                                 fn_2b70db0
02d1e688: adrp    x0, #0x6267000                             
02d1e68c: ldr     x0, [x0, #0xd58]                           MS:UIManager::GetScreen
02d1e690: bl      #0x2b70db0                                 fn_2b70db0
02d1e694: adrp    x0, #0x6266000                             
02d1e698: ldr     x0, [x0, #0xb38]                           T:type19687(k15)
02d1e69c: bl      #0x2b70db0                                 fn_2b70db0
02d1e6a0: mov     w8, #1                                     
02d1e6a4: strb    w8, [x20, #0x33]                           
02d1e6a8: ldr     x0, [x19, #0x20]                           .UIManager
02d1e6ac: cbz     x0, #0x2d1e800                             
02d1e6b0: adrp    x8, #0x6267000                             
02d1e6b4: ldr     x8, [x8, #0xd58]                           MS:UIManager::GetScreen
02d1e6b8: ldr     x1, [x8]                                   S:'didu'
02d1e6bc: bl      #0x33fbbd0                                 fn_33fbbd0
02d1e6c0: cbz     x0, #0x2d1e800                             
02d1e6c4: ldr     x21, [x0, #0xb8]                           S:'banner_native_refresh_time'
02d1e6c8: mov     x20, x0                                    
02d1e6cc: cbz     x21, #0x2d1e800                            
02d1e6d0: adrp    x24, #0x6266000                            
02d1e6d4: adrp    x23, #0x6269000                            
02d1e6d8: ldr     x24, [x24, #0xb38]                         T:type19687(k15)
02d1e6dc: ldr     x23, [x23, #0xd40]                         M:Home.HomeController::OnShowDecorPanelHandler
02d1e6e0: ldr     x22, [x21, #0x90]!                         
02d1e6e4: ldr     x0, [x24]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d1e6e8: bl      #0x2b7104c                                 fn_2b7104c
02d1e6ec: ldr     x2, [x23]                                  T:Trading.TradingSession/<>c__DisplayClass56_0
02d1e6f0: mov     x1, x19                                    
02d1e6f4: mov     x3, xzr                                    
02d1e6f8: mov     x23, x0                                    
02d1e6fc: bl      #0x3edfba8                                 fn_3edfba8
02d1e700: mov     x0, x22                                    
02d1e704: mov     x1, x23                                    
02d1e708: mov     x2, xzr                                    
02d1e70c: bl      #0x4e57298                                 System.Delegate::Remove
02d1e710: cbz     x0, #0x2d1e750                             
02d1e714: ldr     x23, [x24]                                 M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d1e718: mov     x22, x0                                    
02d1e71c: mov     x1, x23                                    
02d1e720: bl      #0x2b70f34                                 fn_2b70f34
02d1e724: cbz     x0, #0x2d1e744                             
02d1e728: ldr     x23, [x24]                                 M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d1e72c: str     x0, [x21]                                  
02d1e730: mov     x0, x22                                    
02d1e734: mov     x1, x23                                    
02d1e738: bl      #0x2b70f34                                 fn_2b70f34
02d1e73c: mov     x1, x0                                     
02d1e740: cbnz    x0, #0x2d1e758                             
02d1e744: mov     x0, x22                                    
02d1e748: mov     x1, x23                                    
02d1e74c: bl      #0x2b713dc                                 fn_2b713dc
02d1e750: mov     x1, xzr                                    
02d1e754: str     xzr, [x21]                                 
02d1e758: mov     x0, x21                                    
02d1e75c: bl      #0x2b70d54                                 fn_2b70d54
02d1e760: ldr     x20, [x20, #0xb8]                          
02d1e764: cbz     x20, #0x2d1e800                            
02d1e768: adrp    x22, #0x6269000                            
02d1e76c: ldr     x22, [x22, #0xd38]                         M:Home.HomeController::OnHideDecorPanelHandler
02d1e770: ldr     x0, [x24]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d1e774: ldr     x21, [x20, #0x98]!                         
02d1e778: bl      #0x2b7104c                                 fn_2b7104c
02d1e77c: ldr     x2, [x22]                                  T:Trading.TradingSession/<>c__DisplayClass56_0
02d1e780: mov     x1, x19                                    
02d1e784: mov     x3, xzr                                    
02d1e788: mov     x22, x0                                    
02d1e78c: bl      #0x3edfba8                                 fn_3edfba8
02d1e790: mov     x0, x21                                    
02d1e794: mov     x1, x22                                    
02d1e798: mov     x2, xzr                                    
02d1e79c: bl      #0x4e57298                                 System.Delegate::Remove
02d1e7a0: cbz     x0, #0x2d1e7e0                             
02d1e7a4: ldr     x21, [x24]                                 M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d1e7a8: mov     x19, x0                                    
02d1e7ac: mov     x1, x21                                    
02d1e7b0: bl      #0x2b70f34                                 fn_2b70f34
02d1e7b4: cbz     x0, #0x2d1e7d4                             
02d1e7b8: ldr     x21, [x24]                                 M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d1e7bc: str     x0, [x20]                                  
02d1e7c0: mov     x0, x19                                    
02d1e7c4: mov     x1, x21                                    
02d1e7c8: bl      #0x2b70f34                                 fn_2b70f34
02d1e7cc: mov     x1, x0                                     
02d1e7d0: cbnz    x0, #0x2d1e7e8                             
02d1e7d4: mov     x0, x19                                    
02d1e7d8: mov     x1, x21                                    
02d1e7dc: bl      #0x2b713dc                                 fn_2b713dc
02d1e7e0: mov     x1, xzr                                    
02d1e7e4: str     xzr, [x20]                                 
02d1e7e8: mov     x0, x20                                    
02d1e7ec: ldp     x20, x19, [sp, #0x30]                      
02d1e7f0: ldp     x22, x21, [sp, #0x20]                      
02d1e7f4: ldp     x24, x23, [sp, #0x10]                      
02d1e7f8: ldr     x30, [sp], #0x40                           
02d1e7fc: b       #0x2b70d54                                 
02d1e800: bl      #0x2b7105c                                 fn_2b7105c
## OnHideDecorPanelHandler(float duration) -> void
---- Home.HomeController::OnHideDecorPanelHandler 0x2d1e804
02d1e804: str     d8, [sp, #-0x20]!                          
02d1e808: str     x30, [sp, #8]                              
02d1e80c: stp     x20, x19, [sp, #0x10]                      
02d1e810: fmov    s8, s0                                     
02d1e814: adrp    x20, #0x6630000                            
02d1e818: mov     x19, x0                                    
02d1e81c: ldrb    w8, [x20, #0x34]                           
02d1e820: tbnz    w8, #0, #0x2d1e838                         
02d1e824: adrp    x0, #0x6266000                             
02d1e828: ldr     x0, [x0, #0xac0]                           MS:MonoSingleton`1::get_Instance
02d1e82c: bl      #0x2b70db0                                 fn_2b70db0
02d1e830: mov     w8, #1                                     
02d1e834: strb    w8, [x20, #0x34]                           
02d1e838: ldr     x0, [x19, #0x28]                           ._envGo
02d1e83c: cbz     x0, #0x2d1e8dc                             
02d1e840: mov     x1, xzr                                    
02d1e844: bl      #0x5b368f0                                 UnityEngine.GameObject::get_transform
02d1e848: mov     w1, wzr                                    
02d1e84c: mov     x2, xzr                                    
02d1e850: bl      #0x2d9d5d0                                 DG.Tweening.ShortcutExtensions::DOKill
02d1e854: ldr     x0, [x19, #0x28]                           ._envGo
02d1e858: cbz     x0, #0x2d1e8dc                             
02d1e85c: adrp    x19, #0x6266000                            
02d1e860: mov     x1, xzr                                    
02d1e864: ldr     x19, [x19, #0xac0]                         MS:MonoSingleton`1::get_Instance
02d1e868: bl      #0x5b368f0                                 UnityEngine.GameObject::get_transform
02d1e86c: movi    d0, #0000000000000000                      
02d1e870: fmov    s1, s8                                     
02d1e874: mov     w1, wzr                                    
02d1e878: mov     x2, xzr                                    
02d1e87c: bl      #0x2d98060                                 DG.Tweening.ShortcutExtensions::DOLocalMoveY
02d1e880: ldr     x0, [x19]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d1e884: bl      #0x3769600                                 fn_3769600
02d1e888: cbz     x0, #0x2d1e8dc                             
02d1e88c: mov     x1, xzr                                    
02d1e890: bl      #0x2cac928                                 GameSession::get_CharacterContainer
02d1e894: cbz     x0, #0x2d1e8dc                             
02d1e898: mov     x1, xzr                                    
02d1e89c: mov     x19, x0                                    
02d1e8a0: bl      #0x5b368f0                                 UnityEngine.GameObject::get_transform
02d1e8a4: mov     w1, wzr                                    
02d1e8a8: mov     x2, xzr                                    
02d1e8ac: bl      #0x2d9d5d0                                 DG.Tweening.ShortcutExtensions::DOKill
02d1e8b0: mov     x0, x19                                    
02d1e8b4: mov     x1, xzr                                    
02d1e8b8: bl      #0x5b368f0                                 UnityEngine.GameObject::get_transform
02d1e8bc: ldp     x20, x19, [sp, #0x10]                      
02d1e8c0: fmov    s0, #-1.50000000                           
02d1e8c4: ldr     x30, [sp, #8]                              
02d1e8c8: fmov    s1, s8                                     
02d1e8cc: mov     w1, wzr                                    
02d1e8d0: mov     x2, xzr                                    
02d1e8d4: ldr     d8, [sp], #0x20                            
02d1e8d8: b       #0x2d98060                                 DG.Tweening.ShortcutExtensions::DOLocalMoveY
02d1e8dc: bl      #0x2b7105c                                 fn_2b7105c
## OnShowDecorPanelHandler(float duration) -> void
---- Home.HomeController::OnShowDecorPanelHandler 0x2d1e8e0
02d1e8e0: str     d8, [sp, #-0x20]!                          
02d1e8e4: str     x30, [sp, #8]                              
02d1e8e8: stp     x20, x19, [sp, #0x10]                      
02d1e8ec: fmov    s8, s0                                     
02d1e8f0: adrp    x20, #0x6630000                            
02d1e8f4: mov     x19, x0                                    
02d1e8f8: ldrb    w8, [x20, #0x35]                           
02d1e8fc: tbnz    w8, #0, #0x2d1e914                         
02d1e900: adrp    x0, #0x6266000                             
02d1e904: ldr     x0, [x0, #0xac0]                           MS:MonoSingleton`1::get_Instance
02d1e908: bl      #0x2b70db0                                 fn_2b70db0
02d1e90c: mov     w8, #1                                     
02d1e910: strb    w8, [x20, #0x35]                           
02d1e914: ldr     x0, [x19, #0x28]                           ._envGo
02d1e918: cbz     x0, #0x2d1e9b8                             
02d1e91c: mov     x1, xzr                                    
02d1e920: bl      #0x5b368f0                                 UnityEngine.GameObject::get_transform
02d1e924: mov     w1, wzr                                    
02d1e928: mov     x2, xzr                                    
02d1e92c: bl      #0x2d9d5d0                                 DG.Tweening.ShortcutExtensions::DOKill
02d1e930: ldr     x0, [x19, #0x28]                           ._envGo
02d1e934: cbz     x0, #0x2d1e9b8                             
02d1e938: adrp    x19, #0x6266000                            
02d1e93c: mov     x1, xzr                                    
02d1e940: ldr     x19, [x19, #0xac0]                         MS:MonoSingleton`1::get_Instance
02d1e944: bl      #0x5b368f0                                 UnityEngine.GameObject::get_transform
02d1e948: fmov    s1, s8                                     
02d1e94c: fmov    s0, #1.00000000                            
02d1e950: mov     w1, wzr                                    
02d1e954: mov     x2, xzr                                    
02d1e958: bl      #0x2d98060                                 DG.Tweening.ShortcutExtensions::DOLocalMoveY
02d1e95c: ldr     x0, [x19]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d1e960: bl      #0x3769600                                 fn_3769600
02d1e964: cbz     x0, #0x2d1e9b8                             
02d1e968: mov     x1, xzr                                    
02d1e96c: bl      #0x2cac928                                 GameSession::get_CharacterContainer
02d1e970: cbz     x0, #0x2d1e9b8                             
02d1e974: mov     x1, xzr                                    
02d1e978: mov     x19, x0                                    
02d1e97c: bl      #0x5b368f0                                 UnityEngine.GameObject::get_transform
02d1e980: mov     w1, wzr                                    
02d1e984: mov     x2, xzr                                    
02d1e988: bl      #0x2d9d5d0                                 DG.Tweening.ShortcutExtensions::DOKill
02d1e98c: mov     x0, x19                                    
02d1e990: mov     x1, xzr                                    
02d1e994: bl      #0x5b368f0                                 UnityEngine.GameObject::get_transform
02d1e998: ldp     x20, x19, [sp, #0x10]                      
02d1e99c: fmov    s0, #-0.50000000                           
02d1e9a0: ldr     x30, [sp, #8]                              
02d1e9a4: fmov    s1, s8                                     
02d1e9a8: mov     w1, wzr                                    
02d1e9ac: mov     x2, xzr                                    
02d1e9b0: ldr     d8, [sp], #0x20                            
02d1e9b4: b       #0x2d98060                                 DG.Tweening.ShortcutExtensions::DOLocalMoveY
02d1e9b8: bl      #0x2b7105c                                 fn_2b7105c
## Update() -> void
---- Home.HomeController::Update 0x2d1e9bc
02d1e9bc: sub     sp, sp, #0xa0                              
02d1e9c0: stp     d11, d10, [sp, #0x60]                      
02d1e9c4: stp     d9, d8, [sp, #0x70]                        
02d1e9c8: str     x30, [sp, #0x80]                           
02d1e9cc: stp     x20, x19, [sp, #0x90]                      
02d1e9d0: adrp    x20, #0x6630000                            
02d1e9d4: mov     x19, x0                                    
02d1e9d8: ldrb    w8, [x20, #0x36]                           
02d1e9dc: tbnz    w8, #0, #0x2d1ea24                         
02d1e9e0: adrp    x0, #0x6269000                             
02d1e9e4: ldr     x0, [x0, #0xd48]                           MS:UnityEngine.Component::GetComponent
02d1e9e8: bl      #0x2b70db0                                 fn_2b70db0
02d1e9ec: adrp    x0, #0x6266000                             
02d1e9f0: ldr     x0, [x0, #0x938]                           MS:UnityEngine.InputSystem.InputControl`1::ReadValue
02d1e9f4: bl      #0x2b70db0                                 fn_2b70db0
02d1e9f8: adrp    x0, #0x6263000                             
02d1e9fc: ldr     x0, [x0, #0x918]                           T:UnityEngine.Object
02d1ea00: bl      #0x2b70db0                                 fn_2b70db0
02d1ea04: adrp    x0, #0x6266000                             
02d1ea08: ldr     x0, [x0, #0x940]                           T:UnityEngine.Physics2D
02d1ea0c: bl      #0x2b70db0                                 fn_2b70db0
02d1ea10: adrp    x0, #0x6266000                             
02d1ea14: ldr     x0, [x0, #0x948]                           T:Touch
02d1ea18: bl      #0x2b70db0                                 fn_2b70db0
02d1ea1c: mov     w8, #1                                     
02d1ea20: strb    w8, [x20, #0x36]                           
02d1ea24: movi    v0.2d, #0000000000000000                   
02d1ea28: adrp    x20, #0x662f000                            
02d1ea2c: str     wzr, [sp, #0x50]                           
02d1ea30: ldrb    w8, [x20, #0xbd9]                          
02d1ea34: stp     q0, q0, [sp, #0x30]                        
02d1ea38: cbnz    w8, #0x2d1ea50                             
02d1ea3c: adrp    x0, #0x6266000                             
02d1ea40: ldr     x0, [x0, #0x950]                           T:UnityEngine.InputSystem.Pointer
02d1ea44: bl      #0x2b70db0                                 fn_2b70db0
02d1ea48: mov     w8, #1                                     
02d1ea4c: strb    w8, [x20, #0xbd9]                          
02d1ea50: adrp    x8, #0x6266000                             
02d1ea54: ldr     x8, [x8, #0x950]                           T:UnityEngine.InputSystem.Pointer
02d1ea58: ldr     x8, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d1ea5c: ldr     x8, [x8, #0xb8]                            S:'banner_native_refresh_time'
02d1ea60: ldr     x20, [x8]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d1ea64: cbz     x20, #0x2d1ec1c                            
02d1ea68: ldr     x0, [x20, #0x1a8]                          [662f1a8]=600006c f=2.40744e-35,0
02d1ea6c: cbz     x0, #0x2d1ec34                             
02d1ea70: mov     x1, xzr                                    
02d1ea74: bl      #0x55532f0                                 UnityEngine.InputSystem.Controls.ButtonControl::get_wasPressedThisFrame
02d1ea78: tbz     w0, #0, #0x2d1ec1c                         
02d1ea7c: adrp    x8, #0x6266000                             
02d1ea80: ldr     x8, [x8, #0x948]                           T:Touch
02d1ea84: ldr     x0, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d1ea88: ldr     w8, [x0, #0xe4]                            [62660e4]=0 f=0,0
02d1ea8c: cbnz    w8, #0x2d1ea94                             
02d1ea90: bl      #0x2b70f30                                 fn_2b70f30
02d1ea94: mov     x0, xzr                                    
02d1ea98: bl      #0x2cd6230                                 Touch::IsPointerOverUIObject
02d1ea9c: and     w8, w0, #1                                 
02d1eaa0: strb    w8, [x19, #0x50]                           ._isOverUi
02d1eaa4: tbnz    w0, #0, #0x2d1ec1c                         
02d1eaa8: mov     x0, xzr                                    
02d1eaac: bl      #0x5aefe28                                 UnityEngine.Camera::get_main
02d1eab0: ldr     x8, [x20, #0x188]                          [662f188]=600006a f=2.40744e-35,0
02d1eab4: cbz     x8, #0x2d1ec34                             
02d1eab8: adrp    x9, #0x6266000                             
02d1eabc: mov     x19, x0                                    
02d1eac0: mov     x0, x8                                     
02d1eac4: ldr     x9, [x9, #0x938]                           MS:UnityEngine.InputSystem.InputControl`1::ReadValue
02d1eac8: ldr     x1, [x9]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d1eacc: bl      #0x4a187c4                                 fn_4a187c4
02d1ead0: cbz     x19, #0x2d1ec34                            
02d1ead4: movi    d2, #0000000000000000                      
02d1ead8: mov     x0, x19                                    
02d1eadc: mov     x1, xzr                                    
02d1eae0: bl      #0x5aefbb0                                 UnityEngine.Camera::ScreenToWorldPoint
02d1eae4: fmov    s8, s0                                     
02d1eae8: fmov    s9, s1                                     
02d1eaec: adrp    x19, #0x662f000                            
02d1eaf0: ldrb    w8, [x19, #0xbda]                          
02d1eaf4: cbnz    w8, #0x2d1eb0c                             
02d1eaf8: adrp    x0, #0x6266000                             
02d1eafc: ldr     x0, [x0, #0x970]                           T:UnityEngine.Vector2
02d1eb00: bl      #0x2b70db0                                 fn_2b70db0
02d1eb04: mov     w8, #1                                     
02d1eb08: strb    w8, [x19, #0xbda]                          
02d1eb0c: adrp    x8, #0x6266000                             
02d1eb10: adrp    x9, #0x6266000                             
02d1eb14: ldr     x8, [x8, #0x970]                           T:UnityEngine.Vector2
02d1eb18: ldr     x9, [x9, #0x940]                           T:UnityEngine.Physics2D
02d1eb1c: ldr     x8, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d1eb20: ldr     x0, [x9]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d1eb24: ldr     x8, [x8, #0xb8]                            S:'banner_native_refresh_time'
02d1eb28: ldr     w9, [x0, #0xe4]                            [62660e4]=0 f=0,0
02d1eb2c: ldp     s10, s11, [x8]                             
02d1eb30: cbnz    w9, #0x2d1eb38                             
02d1eb34: bl      #0x2b70f30                                 fn_2b70f30
02d1eb38: mov     w9, #0x42c80000                            
02d1eb3c: fmov    s0, s8                                     
02d1eb40: fmov    s1, s9                                     
02d1eb44: fmov    s2, s10                                    
02d1eb48: fmov    s3, s11                                    
02d1eb4c: add     x8, sp, #0xc                               
02d1eb50: fmov    s4, w9                                     
02d1eb54: mov     x0, xzr                                    
02d1eb58: bl      #0x5bbcac8                                 UnityEngine.Physics2D::Raycast
02d1eb5c: ldur    q0, [sp, #0xc]                             
02d1eb60: ldur    q1, [sp, #0x1c]                            
02d1eb64: add     x0, sp, #0x30                              
02d1eb68: ldr     w8, [sp, #0x2c]                            
02d1eb6c: mov     x1, xzr                                    
02d1eb70: stp     q0, q1, [sp, #0x30]                        
02d1eb74: str     w8, [sp, #0x50]                            
02d1eb78: bl      #0x5bbe11c                                 UnityEngine.RaycastHit2D::get_collider
02d1eb7c: adrp    x20, #0x6263000                            
02d1eb80: mov     x19, x0                                    
02d1eb84: ldr     x20, [x20, #0x918]                         T:UnityEngine.Object
02d1eb88: ldr     x8, [x20]                                  &2c5bbd4(=a9bd7bfdd503233f)
02d1eb8c: ldr     w9, [x8, #0xe4]                            [62660e4]=0 f=0,0
02d1eb90: cbnz    w9, #0x2d1eb9c                             
02d1eb94: mov     x0, x8                                     
02d1eb98: bl      #0x2b70f30                                 fn_2b70f30
02d1eb9c: mov     x0, x19                                    
02d1eba0: mov     x1, xzr                                    
02d1eba4: mov     x2, xzr                                    
02d1eba8: bl      #0x5b37d84                                 UnityEngine.Object::op_Equality
02d1ebac: tbnz    w0, #0, #0x2d1ec1c                         
02d1ebb0: add     x0, sp, #0x30                              
02d1ebb4: mov     x1, xzr                                    
02d1ebb8: bl      #0x5bbe11c                                 UnityEngine.RaycastHit2D::get_collider
02d1ebbc: cbz     x0, #0x2d1ec34                             
02d1ebc0: adrp    x8, #0x6269000                             
02d1ebc4: ldr     x8, [x8, #0xd48]                           MS:UnityEngine.Component::GetComponent
02d1ebc8: ldr     x1, [x8]                                   T:Trading.TradingSession/<>c__DisplayClass56_0
02d1ebcc: bl      #0x3140c84                                 fn_3140c84
02d1ebd0: ldr     x8, [x20]                                  &2c5bbd4(=a9bd7bfdd503233f)
02d1ebd4: mov     x19, x0                                    
02d1ebd8: ldr     w9, [x8, #0xe4]                            [62690e4]=0 f=0,0
02d1ebdc: cbnz    w9, #0x2d1ebe8                             
02d1ebe0: mov     x0, x8                                     
02d1ebe4: bl      #0x2b70f30                                 fn_2b70f30
02d1ebe8: mov     x0, x19                                    
02d1ebec: mov     x1, xzr                                    
02d1ebf0: mov     x2, xzr                                    
02d1ebf4: bl      #0x5b3666c                                 UnityEngine.Object::op_Inequality
02d1ebf8: tbz     w0, #0, #0x2d1ec1c                         
02d1ebfc: cbz     x19, #0x2d1ec34                            
02d1ec00: ldr     x8, [x19, #0x28]                           [662f028]=6000015 f=2.40742e-35,0 ._envGo
02d1ec04: cbz     x8, #0x2d1ec1c                             
02d1ec08: ldr     w1, [x19, #0x20]                           &2b706f0(=d65f03c0f9400800) .UIManager
02d1ec0c: ldr     x9, [x8, #0x18]                            M:Trading.TradingSession::<ValidateTrade>b__57_0
02d1ec10: ldr     x0, [x8, #0x40]                            MS:System.Linq.Enumerable::Select
02d1ec14: ldr     x2, [x8, #0x28]                            T:Trading.TradingCounterRequest
02d1ec18: blr     x9                                         
02d1ec1c: ldp     x20, x19, [sp, #0x90]                      
02d1ec20: ldr     x30, [sp, #0x80]                           
02d1ec24: ldp     d9, d8, [sp, #0x70]                        
02d1ec28: ldp     d11, d10, [sp, #0x60]                      
02d1ec2c: add     sp, sp, #0xa0                              
02d1ec30: ret                                                
02d1ec34: bl      #0x2b7105c                                 fn_2b7105c
## .ctor() -> void
---- Home.HomeController::.ctor 0x2d1ec58
02d1ec58: mov     x1, xzr                                    
02d1ec5c: b       #0x5b397b0                                 UnityEngine.MonoBehaviour::.ctor
