#### CLASS DreamHouse.DecorItemAsset parent= object
#   field ItemList                       System.Collections.Generic.List`1<DreamHouse.DecorItemConfig> off=0x10 attr=6 
## GetDecorItemConfigByIndex(int index) -> DreamHouse.DecorItemConfig
---- DreamHouse.DecorItemAsset::GetDecorItemConfigByIndex 0x2d15c80
02d15c80: sub     sp, sp, #0x30                              
02d15c84: stp     x30, x21, [sp, #0x10]                      
02d15c88: stp     x20, x19, [sp, #0x20]                      
02d15c8c: adrp    x21, #0x662f000                            
02d15c90: mov     w19, w1                                    
02d15c94: mov     x20, x0                                    
02d15c98: ldrb    w8, [x21, #0xfd2]                          
02d15c9c: tbnz    w8, #0, #0x2d15cd8                         
02d15ca0: adrp    x0, #0x6263000                             
02d15ca4: ldr     x0, [x0, #0x928]                           T:UnityEngine.Debug
02d15ca8: bl      #0x2b70db0                                 fn_2b70db0
02d15cac: adrp    x0, #0x6269000                             
02d15cb0: ldr     x0, [x0, #0x8d8]                           MS:System.Collections.Generic.List`1::get_Count
02d15cb4: bl      #0x2b70db0                                 fn_2b70db0
02d15cb8: adrp    x0, #0x6269000                             
02d15cbc: ldr     x0, [x0, #0x8e0]                           MS:System.Collections.Generic.List`1::get_Item
02d15cc0: bl      #0x2b70db0                                 fn_2b70db0
02d15cc4: adrp    x0, #0x6269000                             
02d15cc8: ldr     x0, [x0, #0x8e8]                           S:'Index {0} is out of range for ItemList.'
02d15ccc: bl      #0x2b70db0                                 fn_2b70db0
02d15cd0: mov     w8, #1                                     
02d15cd4: strb    w8, [x21, #0xfd2]                          
02d15cd8: tbnz    w19, #0x1f, #0x2d15d10                     
02d15cdc: ldr     x0, [x20, #0x10]                           .ItemList
02d15ce0: cbz     x0, #0x2d15d84                             
02d15ce4: ldr     w8, [x0, #0x18]                            M:Trading.TradingSession::<ValidateTrade>b__57_0
02d15ce8: cmp     w8, w19                                    
02d15cec: b.le    #0x2d15d10                                 
02d15cf0: adrp    x8, #0x6269000                             
02d15cf4: mov     w1, w19                                    
02d15cf8: ldr     x8, [x8, #0x8e0]                           MS:System.Collections.Generic.List`1::get_Item
02d15cfc: ldp     x20, x19, [sp, #0x20]                      
02d15d00: ldp     x30, x21, [sp, #0x10]                      
02d15d04: ldr     x2, [x8]                                   T:Trading.TradingSession/<>c__DisplayClass56_0
02d15d08: add     sp, sp, #0x30                              
02d15d0c: b       #0x35a8f3c                                 
02d15d10: adrp    x8, #0x6263000                             
02d15d14: adrp    x20, #0x6269000                            
02d15d18: adrp    x21, #0x6263000                            
02d15d1c: ldr     x8, [x8, #0x970]                           &6645c70(=0)
02d15d20: ldr     x20, [x20, #0x8e8]                         S:'Index {0} is out of range for ItemList.'
02d15d24: ldr     x21, [x21, #0x928]                         T:UnityEngine.Debug
02d15d28: add     x1, sp, #0xc                               
02d15d2c: str     w19, [sp, #0xc]                            
02d15d30: ldr     x0, [x8, #0x48]                            &6263098(=0)
02d15d34: bl      #0x2b70f38                                 fn_2b70f38
02d15d38: ldr     x8, [x20]                                  T:Trading.TradingSession/<>c__DisplayClass56_0
02d15d3c: mov     x1, x0                                     
02d15d40: mov     x2, xzr                                    
02d15d44: mov     x0, x8                                     
02d15d48: bl      #0x4c9d0ec                                 System.String::Format
02d15d4c: ldr     x8, [x21]                                  &2c5bbd4(=a9bd7bfdd503233f)
02d15d50: mov     x19, x0                                    
02d15d54: ldr     w9, [x8, #0xe4]                            [62630e4]=0 f=0,0
02d15d58: cbnz    w9, #0x2d15d64                             
02d15d5c: mov     x0, x8                                     
02d15d60: bl      #0x2b70f30                                 fn_2b70f30
02d15d64: mov     x0, x19                                    
02d15d68: mov     x1, xzr                                    
02d15d6c: bl      #0x5af2840                                 UnityEngine.Debug::LogError
02d15d70: ldp     x20, x19, [sp, #0x20]                      
02d15d74: mov     x0, xzr                                    
02d15d78: ldp     x30, x21, [sp, #0x10]                      
02d15d7c: add     sp, sp, #0x30                              
02d15d80: ret                                                
02d15d84: bl      #0x2b7105c                                 fn_2b7105c
## .ctor() -> void
---- DreamHouse.DecorItemAsset::.ctor 0x2d15d88
02d15d88: mov     x1, xzr                                    
02d15d8c: b       #0x4e53e9c                                 System.Object::.ctor
