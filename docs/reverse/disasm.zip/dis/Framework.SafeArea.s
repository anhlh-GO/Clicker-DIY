#### CLASS Framework.SafeArea/SimDevice parent= int
#   field value__                        int                                                off=0x10 attr=606 
#   field None                           Framework.SafeArea/SimDevice                       off=0x0 attr=8056 
#   field iPhoneX                        Framework.SafeArea/SimDevice                       off=0x0 attr=8056 
#   field iPhoneXsMax                    Framework.SafeArea/SimDevice                       off=0x0 attr=8056 
#   field Pixel3XL_LSL                   Framework.SafeArea/SimDevice                       off=0x0 attr=8056 
#   field Pixel3XL_LSR                   Framework.SafeArea/SimDevice                       off=0x0 attr=8056 
#### CLASS Framework.SafeArea parent= UnityEngine.MonoBehaviour
#   field Sim                            Framework.SafeArea/SimDevice                       off=0x0 attr=16 
#   field NSA_iPhoneX                    UnityEngine.Rect[]                                 off=0x20 attr=1 
#   field NSA_iPhoneXsMax                UnityEngine.Rect[]                                 off=0x28 attr=1 
#   field NSA_Pixel3XL_LSL               UnityEngine.Rect[]                                 off=0x30 attr=1 
#   field NSA_Pixel3XL_LSR               UnityEngine.Rect[]                                 off=0x38 attr=1 
#   field _conformX                      bool                                               off=0x40 attr=1 SerializeField
#   field _conformY                      bool                                               off=0x41 attr=1 SerializeField
#   field _logging                       bool                                               off=0x42 attr=1 SerializeField
#   field _panels                        System.Collections.Generic.List`1<UnityEngine.RectTransform> off=0x48 attr=1 SerializeField
#   field _lastSafeArea                  UnityEngine.Rect                                   off=0x50 attr=1 
#   field _lastScreenSize                UnityEngine.Vector2Int                             off=0x60 attr=1 
#   field _lastOrientation               UnityEngine.ScreenOrientation                      off=0x68 attr=1 
## Awake() -> void
---- Framework.SafeArea::Awake 0x2cc4b78
02cc4b78: stp     x30, x21, [sp, #-0x20]!                    
02cc4b7c: stp     x20, x19, [sp, #0x10]                      
02cc4b80: adrp    x21, #0x662f000                            
02cc4b84: adrp    x20, #0x6267000                            
02cc4b88: mov     x19, x0                                    
02cc4b8c: ldrb    w8, [x21, #0xc42]                          
02cc4b90: ldr     x20, [x20, #0x1c0]                         MS:Framework.IListExtension::IsNullOrEmpty
02cc4b94: tbnz    w8, #0, #0x2cc4bb8                         
02cc4b98: adrp    x0, #0x6267000                             
02cc4b9c: ldr     x0, [x0, #0x1c0]                           MS:Framework.IListExtension::IsNullOrEmpty
02cc4ba0: bl      #0x2b70db0                                 fn_2b70db0
02cc4ba4: adrp    x0, #0x6263000                             
02cc4ba8: ldr     x0, [x0, #0x918]                           T:UnityEngine.Object
02cc4bac: bl      #0x2b70db0                                 fn_2b70db0
02cc4bb0: mov     w8, #1                                     
02cc4bb4: strb    w8, [x21, #0xc42]                          
02cc4bb8: ldr     x0, [x19, #0x48]                           ._panels
02cc4bbc: ldr     x1, [x20]                                  S:'didu'
02cc4bc0: bl      #0x3202f88                                 fn_3202f88
02cc4bc4: tbz     w0, #0, #0x2cc4bf4                         
02cc4bc8: adrp    x8, #0x6263000                             
02cc4bcc: ldr     x8, [x8, #0x918]                           T:UnityEngine.Object
02cc4bd0: ldr     x0, [x8]                                   &2c5bbd4(=a9bd7bfdd503233f)
02cc4bd4: ldr     w8, [x0, #0xe4]                            [62630e4]=0 f=0,0
02cc4bd8: cbnz    w8, #0x2cc4be0                             
02cc4bdc: bl      #0x2b70f30                                 fn_2b70f30
02cc4be0: mov     x0, x19                                    
02cc4be4: ldp     x20, x19, [sp, #0x10]                      
02cc4be8: mov     x1, xzr                                    
02cc4bec: ldp     x30, x21, [sp], #0x20                      
02cc4bf0: b       #0x5b3ca38                                 UnityEngine.Object::Destroy
02cc4bf4: mov     x0, x19                                    
02cc4bf8: ldp     x20, x19, [sp, #0x10]                      
02cc4bfc: ldp     x30, x21, [sp], #0x20                      
02cc4c00: b       #0x2cc4c04                                 Framework.SafeArea::Refresh
## Refresh() -> void
---- Framework.SafeArea::Refresh 0x2cc4c04
02cc4c04: stp     d15, d14, [sp, #-0x60]!                    
02cc4c08: stp     d13, d12, [sp, #0x10]                      
02cc4c0c: stp     d11, d10, [sp, #0x20]                      
02cc4c10: stp     d9, d8, [sp, #0x30]                        
02cc4c14: stp     x30, x21, [sp, #0x40]                      
02cc4c18: stp     x20, x19, [sp, #0x50]                      
02cc4c1c: adrp    x21, #0x662f000                            
02cc4c20: adrp    x20, #0x6264000                            
02cc4c24: mov     x19, x0                                    
02cc4c28: ldrb    w8, [x21, #0xc43]                          
02cc4c2c: ldr     x20, [x20, #0x798]                         T:UnityEngine.Rect
02cc4c30: tbnz    w8, #0, #0x2cc4c48                         
02cc4c34: adrp    x0, #0x6264000                             
02cc4c38: ldr     x0, [x0, #0x798]                           T:UnityEngine.Rect
02cc4c3c: bl      #0x2b70db0                                 fn_2b70db0
02cc4c40: mov     w8, #1                                     
02cc4c44: strb    w8, [x21, #0xc43]                          
02cc4c48: mov     x0, x19                                    
02cc4c4c: bl      #0x2cc4d78                                 Framework.SafeArea::GetSafeArea
02cc4c50: fmov    s8, s0                                     
02cc4c54: fmov    s9, s1                                     
02cc4c58: ldr     x0, [x20]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02cc4c5c: fmov    s10, s2                                    
02cc4c60: fmov    s11, s3                                    
02cc4c64: ldp     s15, s14, [x19, #0x50]                     ._lastSafeArea
02cc4c68: ldr     w8, [x0, #0xe4]                            [62640e4]=0 f=0,0
02cc4c6c: ldp     s13, s12, [x19, #0x58]                     
02cc4c70: cbnz    w8, #0x2cc4c78                             
02cc4c74: bl      #0x2b70f30                                 fn_2b70f30
02cc4c78: adrp    x21, #0x662f000                            
02cc4c7c: ldrb    w8, [x21, #0xcab]                          
02cc4c80: cbnz    w8, #0x2cc4c98                             
02cc4c84: adrp    x0, #0x6264000                             
02cc4c88: ldr     x0, [x0, #0x798]                           T:UnityEngine.Rect
02cc4c8c: bl      #0x2b70db0                                 fn_2b70db0
02cc4c90: mov     w8, #1                                     
02cc4c94: strb    w8, [x21, #0xcab]                          
02cc4c98: ldr     x0, [x20]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02cc4c9c: ldr     w8, [x0, #0xe4]                            [62640e4]=0 f=0,0
02cc4ca0: cbnz    w8, #0x2cc4ca8                             
02cc4ca4: bl      #0x2b70f30                                 fn_2b70f30
02cc4ca8: fcmp    s8, s15                                    
02cc4cac: b.ne    #0x2cc4d20                                 
02cc4cb0: fcmp    s9, s14                                    
02cc4cb4: b.ne    #0x2cc4d20                                 
02cc4cb8: fcmp    s10, s13                                   
02cc4cbc: b.ne    #0x2cc4d20                                 
02cc4cc0: fcmp    s11, s12                                   
02cc4cc4: b.ne    #0x2cc4d20                                 
02cc4cc8: mov     x0, xzr                                    
02cc4ccc: bl      #0x5afb6fc                                 UnityEngine.Screen::get_width
02cc4cd0: ldr     w8, [x19, #0x60]                           ._lastScreenSize
02cc4cd4: cmp     w0, w8                                     
02cc4cd8: b.ne    #0x2cc4d20                                 
02cc4cdc: mov     x0, xzr                                    
02cc4ce0: bl      #0x5afb724                                 UnityEngine.Screen::get_height
02cc4ce4: ldr     w8, [x19, #0x64]                           
02cc4ce8: cmp     w0, w8                                     
02cc4cec: b.ne    #0x2cc4d20                                 
02cc4cf0: mov     x0, xzr                                    
02cc4cf4: bl      #0x5afb7d8                                 UnityEngine.Screen::get_orientation
02cc4cf8: ldr     w8, [x19, #0x68]                           ._lastOrientation
02cc4cfc: cmp     w0, w8                                     
02cc4d00: b.ne    #0x2cc4d20                                 
02cc4d04: ldp     x20, x19, [sp, #0x50]                      
02cc4d08: ldp     x30, x21, [sp, #0x40]                      
02cc4d0c: ldp     d9, d8, [sp, #0x30]                        
02cc4d10: ldp     d11, d10, [sp, #0x20]                      
02cc4d14: ldp     d13, d12, [sp, #0x10]                      
02cc4d18: ldp     d15, d14, [sp], #0x60                      
02cc4d1c: ret                                                
02cc4d20: mov     x0, xzr                                    
02cc4d24: bl      #0x5afb6fc                                 UnityEngine.Screen::get_width
02cc4d28: str     w0, [x19, #0x60]                           ._lastScreenSize
02cc4d2c: mov     x0, xzr                                    
02cc4d30: bl      #0x5afb724                                 UnityEngine.Screen::get_height
02cc4d34: str     w0, [x19, #0x64]                           
02cc4d38: mov     x0, xzr                                    
02cc4d3c: bl      #0x5afb7d8                                 UnityEngine.Screen::get_orientation
02cc4d40: mov     w8, w0                                     
02cc4d44: mov     x0, x19                                    
02cc4d48: fmov    s0, s8                                     
02cc4d4c: fmov    s1, s9                                     
02cc4d50: fmov    s2, s10                                    
02cc4d54: fmov    s3, s11                                    
02cc4d58: str     w8, [x19, #0x68]                           ._lastOrientation
02cc4d5c: ldp     x20, x19, [sp, #0x50]                      
02cc4d60: ldp     x30, x21, [sp, #0x40]                      
02cc4d64: ldp     d9, d8, [sp, #0x30]                        
02cc4d68: ldp     d11, d10, [sp, #0x20]                      
02cc4d6c: ldp     d13, d12, [sp, #0x10]                      
02cc4d70: ldp     d15, d14, [sp], #0x60                      
02cc4d74: b       #0x2cc4fec                                 Framework.SafeArea::ApplySafeArea
## GetSafeArea() -> UnityEngine.Rect
---- Framework.SafeArea::GetSafeArea 0x2cc4d78
02cc4d78: stp     d11, d10, [sp, #-0x50]!                    
02cc4d7c: stp     d9, d8, [sp, #0x10]                        
02cc4d80: stp     x30, x23, [sp, #0x20]                      
02cc4d84: stp     x22, x21, [sp, #0x30]                      
02cc4d88: stp     x20, x19, [sp, #0x40]                      
02cc4d8c: adrp    x21, #0x662f000                            
02cc4d90: adrp    x20, #0x6264000                            
02cc4d94: mov     x19, x0                                    
02cc4d98: ldrb    w8, [x21, #0xc44]                          
02cc4d9c: ldr     x20, [x20, #0xa70]                         T:UnityEngine.Application
02cc4da0: tbnz    w8, #0, #0x2cc4dd0                         
02cc4da4: adrp    x0, #0x6264000                             
02cc4da8: ldr     x0, [x0, #0xa70]                           T:UnityEngine.Application
02cc4dac: bl      #0x2b70db0                                 fn_2b70db0
02cc4db0: adrp    x0, #0x6264000                             
02cc4db4: ldr     x0, [x0, #0x798]                           T:UnityEngine.Rect
02cc4db8: bl      #0x2b70db0                                 fn_2b70db0
02cc4dbc: adrp    x0, #0x6267000                             
02cc4dc0: ldr     x0, [x0, #0x1c8]                           T:Framework.SafeArea
02cc4dc4: bl      #0x2b70db0                                 fn_2b70db0
02cc4dc8: mov     w8, #1                                     
02cc4dcc: strb    w8, [x21, #0xc44]                          
02cc4dd0: mov     x0, xzr                                    
02cc4dd4: bl      #0x5afb940                                 UnityEngine.Screen::get_safeArea
02cc4dd8: fmov    s8, s0                                     
02cc4ddc: fmov    s9, s1                                     
02cc4de0: ldr     x0, [x20]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02cc4de4: fmov    s10, s2                                    
02cc4de8: fmov    s11, s3                                    
02cc4dec: ldr     w8, [x0, #0xe4]                            [62670e4]=0 f=0,0
02cc4df0: cbnz    w8, #0x2cc4df8                             
02cc4df4: bl      #0x2b70f30                                 fn_2b70f30
02cc4df8: mov     x0, xzr                                    
02cc4dfc: bl      #0x5aed094                                 UnityEngine.Application::get_isEditor
02cc4e00: tbz     w0, #0, #0x2cc4fbc                         
02cc4e04: adrp    x23, #0x6267000                            
02cc4e08: ldr     x23, [x23, #0x1c8]                         T:Framework.SafeArea
02cc4e0c: ldr     x8, [x23]                                  S:'didu'
02cc4e10: ldr     x8, [x8, #0xb8]                            
02cc4e14: ldr     w8, [x8]                                   
02cc4e18: cbz     w8, #0x2cc4fbc                             
02cc4e1c: mov     x0, xzr                                    
02cc4e20: bl      #0x5afb6fc                                 UnityEngine.Screen::get_width
02cc4e24: mov     w20, w0                                    
02cc4e28: mov     x0, xzr                                    
02cc4e2c: bl      #0x5afb724                                 UnityEngine.Screen::get_height
02cc4e30: adrp    x22, #0x6264000                            
02cc4e34: mov     w21, w0                                    
02cc4e38: ldr     x22, [x22, #0x798]                         T:UnityEngine.Rect
02cc4e3c: ldr     x8, [x22]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02cc4e40: ldr     w9, [x8, #0xe4]                            
02cc4e44: cbnz    w9, #0x2cc4e50                             
02cc4e48: mov     x0, x8                                     
02cc4e4c: bl      #0x2b70f30                                 fn_2b70f30
02cc4e50: ldr     x8, [x23]                                  S:'didu'
02cc4e54: scvtf   s10, w20                                   
02cc4e58: scvtf   s11, w21                                   
02cc4e5c: movi    d8, #0000000000000000                      
02cc4e60: ldr     x8, [x8, #0xb8]                            
02cc4e64: ldr     w8, [x8]                                   
02cc4e68: cmp     w8, #2                                     
02cc4e6c: b.gt    #0x2cc4ea0                                 
02cc4e70: cmp     w8, #1                                     
02cc4e74: b.eq    #0x2cc4ed0                                 
02cc4e78: movi    d9, #0000000000000000                      
02cc4e7c: cmp     w8, #2                                     
02cc4e80: b.ne    #0x2cc4f5c                                 
02cc4e84: mov     x0, xzr                                    
02cc4e88: bl      #0x5afb724                                 UnityEngine.Screen::get_height
02cc4e8c: mov     w20, w0                                    
02cc4e90: mov     x0, xzr                                    
02cc4e94: bl      #0x5afb6fc                                 UnityEngine.Screen::get_width
02cc4e98: ldr     x11, [x19, #0x28]                          .NSA_iPhoneXsMax
02cc4e9c: b       #0x2cc4f04                                 
02cc4ea0: cmp     w8, #3                                     
02cc4ea4: b.eq    #0x2cc4eec                                 
02cc4ea8: movi    d9, #0000000000000000                      
02cc4eac: cmp     w8, #4                                     
02cc4eb0: b.ne    #0x2cc4f5c                                 
02cc4eb4: mov     x0, xzr                                    
02cc4eb8: bl      #0x5afb724                                 UnityEngine.Screen::get_height
02cc4ebc: mov     w20, w0                                    
02cc4ec0: mov     x0, xzr                                    
02cc4ec4: bl      #0x5afb6fc                                 UnityEngine.Screen::get_width
02cc4ec8: ldr     x11, [x19, #0x38]                          .NSA_Pixel3XL_LSR
02cc4ecc: b       #0x2cc4f04                                 
02cc4ed0: mov     x0, xzr                                    
02cc4ed4: bl      #0x5afb724                                 UnityEngine.Screen::get_height
02cc4ed8: mov     w20, w0                                    
02cc4edc: mov     x0, xzr                                    
02cc4ee0: bl      #0x5afb6fc                                 UnityEngine.Screen::get_width
02cc4ee4: ldr     x11, [x19, #0x20]                          .NSA_iPhoneX
02cc4ee8: b       #0x2cc4f04                                 
02cc4eec: mov     x0, xzr                                    
02cc4ef0: bl      #0x5afb724                                 UnityEngine.Screen::get_height
02cc4ef4: mov     w20, w0                                    
02cc4ef8: mov     x0, xzr                                    
02cc4efc: bl      #0x5afb6fc                                 UnityEngine.Screen::get_width
02cc4f00: ldr     x11, [x19, #0x30]                          .NSA_Pixel3XL_LSL
02cc4f04: cmp     w20, w0                                    
02cc4f08: b.le    #0x2cc4f2c                                 
02cc4f0c: cbz     x11, #0x2cc4fe8                            
02cc4f10: ldr     w8, [x11, #0x18]                           
02cc4f14: cbz     w8, #0x2cc4fe4                             
02cc4f18: add     x8, x11, #0x20                             
02cc4f1c: add     x9, x11, #0x24                             
02cc4f20: add     x10, x11, #0x28                            
02cc4f24: add     x11, x11, #0x2c                            
02cc4f28: b       #0x2cc4f4c                                 
02cc4f2c: cbz     x11, #0x2cc4fe8                            
02cc4f30: ldr     w8, [x11, #0x18]                           
02cc4f34: tst     w8, #0xfffffffe                            
02cc4f38: b.eq    #0x2cc4fe4                                 
02cc4f3c: add     x8, x11, #0x30                             
02cc4f40: add     x9, x11, #0x34                             
02cc4f44: add     x10, x11, #0x38                            
02cc4f48: add     x11, x11, #0x3c                            
02cc4f4c: ldr     s10, [x10]                                 
02cc4f50: ldr     s9, [x9]                                   
02cc4f54: ldr     s8, [x8]                                   
02cc4f58: ldr     s11, [x11]                                 
02cc4f5c: mov     x0, xzr                                    
02cc4f60: bl      #0x5afb6fc                                 UnityEngine.Screen::get_width
02cc4f64: ldr     x8, [x22]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02cc4f68: mov     w19, w0                                    
02cc4f6c: ldr     w9, [x8, #0xe4]                            
02cc4f70: cbnz    w9, #0x2cc4f7c                             
02cc4f74: mov     x0, x8                                     
02cc4f78: bl      #0x2b70f30                                 fn_2b70f30
02cc4f7c: mov     x0, xzr                                    
02cc4f80: bl      #0x5afb724                                 UnityEngine.Screen::get_height
02cc4f84: mov     w20, w0                                    
02cc4f88: mov     x0, xzr                                    
02cc4f8c: bl      #0x5afb6fc                                 UnityEngine.Screen::get_width
02cc4f90: mov     w21, w0                                    
02cc4f94: mov     x0, xzr                                    
02cc4f98: bl      #0x5afb724                                 UnityEngine.Screen::get_height
02cc4f9c: scvtf   s0, w19                                    
02cc4fa0: scvtf   s1, w20                                    
02cc4fa4: scvtf   s2, w21                                    
02cc4fa8: scvtf   s3, w0                                     
02cc4fac: fmul    s8, s8, s0                                 
02cc4fb0: fmul    s9, s9, s1                                 
02cc4fb4: fmul    s10, s10, s2                               
02cc4fb8: fmul    s11, s11, s3                               
02cc4fbc: fmov    s0, s8                                     
02cc4fc0: fmov    s1, s9                                     
02cc4fc4: fmov    s2, s10                                    
02cc4fc8: ldp     x20, x19, [sp, #0x40]                      
02cc4fcc: fmov    s3, s11                                    
02cc4fd0: ldp     x22, x21, [sp, #0x30]                      
02cc4fd4: ldp     x30, x23, [sp, #0x20]                      
02cc4fd8: ldp     d9, d8, [sp, #0x10]                        
02cc4fdc: ldp     d11, d10, [sp], #0x50                      
02cc4fe0: ret                                                
02cc4fe4: bl      #0x2b71064                                 fn_2b71064
02cc4fe8: bl      #0x2b7105c                                 fn_2b7105c
## ApplySafeArea(UnityEngine.Rect r) -> void
---- Framework.SafeArea::ApplySafeArea 0x2cc4fec
02cc4fec: sub     sp, sp, #0x80                              
02cc4ff0: stp     d13, d12, [sp, #0x30]                      
02cc4ff4: stp     d11, d10, [sp, #0x40]                      
02cc4ff8: stp     d9, d8, [sp, #0x50]                        
02cc4ffc: stp     x30, x21, [sp, #0x60]                      
02cc5000: stp     x20, x19, [sp, #0x70]                      
02cc5004: fmov    s8, s3                                     
02cc5008: fmov    s10, s2                                    
02cc500c: adrp    x20, #0x662f000                            
02cc5010: fmov    s9, s1                                     
02cc5014: fmov    s11, s0                                    
02cc5018: ldrb    w8, [x20, #0xc45]                          
02cc501c: mov     x19, x0                                    
02cc5020: tbnz    w8, #0, #0x2cc5068                         
02cc5024: adrp    x0, #0x6267000                             
02cc5028: ldr     x0, [x0, #0x1d0]                           MS:System.Collections.Generic.List`1/Enumerator::Dispose
02cc502c: bl      #0x2b70db0                                 fn_2b70db0
02cc5030: adrp    x0, #0x6267000                             
02cc5034: ldr     x0, [x0, #0x1d8]                           MS:System.Collections.Generic.List`1/Enumerator::MoveNext
02cc5038: bl      #0x2b70db0                                 fn_2b70db0
02cc503c: adrp    x0, #0x6267000                             
02cc5040: ldr     x0, [x0, #0x1e0]                           MS:System.Collections.Generic.List`1/Enumerator::get_Current
02cc5044: bl      #0x2b70db0                                 fn_2b70db0
02cc5048: adrp    x0, #0x6267000                             
02cc504c: ldr     x0, [x0, #0x1e8]                           MS:System.Collections.Generic.List`1::GetEnumerator
02cc5050: bl      #0x2b70db0                                 fn_2b70db0
02cc5054: adrp    x0, #0x6264000                             
02cc5058: ldr     x0, [x0, #0x798]                           T:UnityEngine.Rect
02cc505c: bl      #0x2b70db0                                 fn_2b70db0
02cc5060: mov     w8, #1                                     
02cc5064: strb    w8, [x20, #0xc45]                          
02cc5068: ldrb    w8, [x19, #0x40]                           ._conformX
02cc506c: stp     xzr, xzr, [sp, #0x18]                      
02cc5070: str     xzr, [sp, #0x28]                           
02cc5074: stp     s11, s9, [x19, #0x50]                      ._lastSafeArea
02cc5078: stp     s10, s8, [x19, #0x58]                      
02cc507c: cbnz    w8, #0x2cc50a8                             
02cc5080: adrp    x8, #0x6264000                             
02cc5084: ldr     x8, [x8, #0x798]                           T:UnityEngine.Rect
02cc5088: ldr     x0, [x8]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02cc508c: ldr     w8, [x0, #0xe4]                            [62640e4]=0 f=0,0
02cc5090: cbnz    w8, #0x2cc5098                             
02cc5094: bl      #0x2b70f30                                 fn_2b70f30
02cc5098: mov     x0, xzr                                    
02cc509c: bl      #0x5afb6fc                                 UnityEngine.Screen::get_width
02cc50a0: movi    d11, #0000000000000000                     
02cc50a4: scvtf   s10, w0                                    
02cc50a8: ldrb    w8, [x19, #0x41]                           ._conformY
02cc50ac: cbnz    w8, #0x2cc50d8                             
02cc50b0: adrp    x8, #0x6264000                             
02cc50b4: ldr     x8, [x8, #0x798]                           T:UnityEngine.Rect
02cc50b8: ldr     x0, [x8]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02cc50bc: ldr     w8, [x0, #0xe4]                            [62640e4]=0 f=0,0
02cc50c0: cbnz    w8, #0x2cc50c8                             
02cc50c4: bl      #0x2b70f30                                 fn_2b70f30
02cc50c8: mov     x0, xzr                                    
02cc50cc: bl      #0x5afb724                                 UnityEngine.Screen::get_height
02cc50d0: movi    d9, #0000000000000000                      
02cc50d4: scvtf   s8, w0                                     
02cc50d8: mov     x0, xzr                                    
02cc50dc: bl      #0x5afb6fc                                 UnityEngine.Screen::get_width
02cc50e0: cmp     w0, #1                                     
02cc50e4: b.lt    #0x2cc522c                                 
02cc50e8: mov     x0, xzr                                    
02cc50ec: bl      #0x5afb724                                 UnityEngine.Screen::get_height
02cc50f0: cmp     w0, #1                                     
02cc50f4: b.lt    #0x2cc522c                                 
02cc50f8: adrp    x8, #0x6264000                             
02cc50fc: ldr     x8, [x8, #0x798]                           T:UnityEngine.Rect
02cc5100: ldr     x0, [x8]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02cc5104: ldr     w8, [x0, #0xe4]                            [62640e4]=0 f=0,0
02cc5108: cbnz    w8, #0x2cc5110                             
02cc510c: bl      #0x2b70f30                                 fn_2b70f30
02cc5110: mov     x0, xzr                                    
02cc5114: bl      #0x5afb6fc                                 UnityEngine.Screen::get_width
02cc5118: scvtf   s0, w0                                     
02cc511c: mov     x0, xzr                                    
02cc5120: fdiv    s12, s11, s0                               
02cc5124: bl      #0x5afb724                                 UnityEngine.Screen::get_height
02cc5128: mov     w21, w0                                    
02cc512c: mov     x0, xzr                                    
02cc5130: bl      #0x5afb6fc                                 UnityEngine.Screen::get_width
02cc5134: mov     w20, w0                                    
02cc5138: mov     x0, xzr                                    
02cc513c: bl      #0x5afb724                                 UnityEngine.Screen::get_height
02cc5140: fcmp    s12, #0.0                                  
02cc5144: b.lt    #0x2cc522c                                 
02cc5148: scvtf   s0, w21                                    
02cc514c: fdiv    s13, s9, s0                                
02cc5150: fcmp    s13, #0.0                                  
02cc5154: b.lt    #0x2cc522c                                 
02cc5158: fadd    s0, s10, s11                               
02cc515c: scvtf   s1, w20                                    
02cc5160: fdiv    s10, s0, s1                                
02cc5164: fcmp    s10, #0.0                                  
02cc5168: b.lt    #0x2cc522c                                 
02cc516c: fadd    s0, s9, s8                                 
02cc5170: scvtf   s1, w0                                     
02cc5174: fdiv    s8, s0, s1                                 
02cc5178: fcmp    s8, #0.0                                   
02cc517c: b.lt    #0x2cc522c                                 
02cc5180: ldr     x0, [x19, #0x48]                           ._panels
02cc5184: cbz     x0, #0x2cc51f4                             
02cc5188: adrp    x8, #0x6267000                             
02cc518c: add     x19, sp, #0x18                             
02cc5190: ldr     x8, [x8, #0x1e8]                           MS:System.Collections.Generic.List`1::GetEnumerator
02cc5194: ldr     x1, [x8]                                   S:'didu'
02cc5198: add     x8, sp, #0x18                              
02cc519c: bl      #0x35a9d9c                                 fn_35a9d9c
02cc51a0: adrp    x20, #0x6267000                            
02cc51a4: ldr     x20, [x20, #0x1d8]                         MS:System.Collections.Generic.List`1/Enumerator::MoveNext
02cc51a8: stp     xzr, x19, [sp, #8]                         
02cc51ac: ldr     x1, [x20]                                  S:'didu'
02cc51b0: add     x0, sp, #0x18                              
02cc51b4: bl      #0x4690474                                 fn_4690474
02cc51b8: tbz     w0, #0, #0x2cc5224                         
02cc51bc: ldr     x19, [sp, #0x28]                           
02cc51c0: cbz     x19, #0x2cc51f0                            
02cc51c4: fmov    s0, s12                                    
02cc51c8: fmov    s1, s13                                    
02cc51cc: mov     x0, x19                                    
02cc51d0: mov     x1, xzr                                    
02cc51d4: bl      #0x5b454d8                                 UnityEngine.RectTransform::set_anchorMin
02cc51d8: fmov    s0, s10                                    
02cc51dc: fmov    s1, s8                                     
02cc51e0: mov     x0, x19                                    
02cc51e4: mov     x1, xzr                                    
02cc51e8: bl      #0x5b4566c                                 UnityEngine.RectTransform::set_anchorMax
02cc51ec: b       #0x2cc51ac                                 
02cc51f0: bl      #0x2b7105c                                 fn_2b7105c
02cc51f4: bl      #0x2b7105c                                 fn_2b7105c
02cc51f8: b       #0x2cc5204                                 
02cc51fc: b       #0x2cc5204                                 
02cc5200: b       #0x2cc5204                                 
02cc5204: mov     x19, x0                                    
02cc5208: cmp     w1, #1                                     
02cc520c: b.ne    #0x2cc524c                                 
02cc5210: mov     x0, x19                                    
02cc5214: bl      #0x5e90260                                 fn_5e90260
02cc5218: ldr     x8, [x0]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02cc521c: str     x8, [sp, #8]                               
02cc5220: bl      #0x5e90270                                 fn_5e90270
02cc5224: add     x0, sp, #8                                 
02cc5228: bl      #0x27370fc                                 fn_27370fc
02cc522c: ldp     x20, x19, [sp, #0x70]                      
02cc5230: ldp     x30, x21, [sp, #0x60]                      
02cc5234: ldp     d9, d8, [sp, #0x50]                        
02cc5238: ldp     d11, d10, [sp, #0x40]                      
02cc523c: ldp     d13, d12, [sp, #0x30]                      
02cc5240: add     sp, sp, #0x80                              
02cc5244: ret                                                
02cc5248: mov     x19, x0                                    
02cc524c: add     x0, sp, #8                                 
02cc5250: bl      #0x27370fc                                 fn_27370fc
02cc5254: mov     x0, x19                                    
02cc5258: bl      #0x2c6051c                                 fn_2c6051c
02cc525c: bl      #0x27369b8                                 fn_27369b8
## .ctor() -> void
---- Framework.SafeArea::.ctor 0x2cc5260
02cc5260: sub     sp, sp, #0x30                              
02cc5264: stp     x30, x21, [sp, #0x10]                      
02cc5268: stp     x20, x19, [sp, #0x20]                      
02cc526c: adrp    x21, #0x662f000                            
02cc5270: adrp    x20, #0x6267000                            
02cc5274: mov     x19, x0                                    
02cc5278: ldrb    w8, [x21, #0xc46]                          
02cc527c: ldr     x20, [x20, #0x1f0]                         T:type24559(k1d)
02cc5280: tbnz    w8, #0, #0x2cc52b0                         
02cc5284: adrp    x0, #0x6267000                             
02cc5288: ldr     x0, [x0, #0x1f8]                           MS:System.Collections.Generic.List`1::.ctor
02cc528c: bl      #0x2b70db0                                 fn_2b70db0
02cc5290: adrp    x0, #0x6267000                             
02cc5294: ldr     x0, [x0, #0x200]                           T:type15264(k15)
02cc5298: bl      #0x2b70db0                                 fn_2b70db0
02cc529c: adrp    x0, #0x6267000                             
02cc52a0: ldr     x0, [x0, #0x1f0]                           T:type24559(k1d)
02cc52a4: bl      #0x2b70db0                                 fn_2b70db0
02cc52a8: mov     w8, #1                                     
02cc52ac: strb    w8, [x21, #0xc46]                          
02cc52b0: ldr     x0, [x20]                                  S:'didu'
02cc52b4: mov     w1, #2                                     
02cc52b8: bl      #0x2b70ea0                                 fn_2b70ea0
02cc52bc: cbz     x0, #0x2cc5438                             
02cc52c0: ldr     w8, [x0, #0x18]                            S:'android.content.Intent'
02cc52c4: mov     x1, x0                                     
02cc52c8: cbz     w8, #0x2cc5434                             
02cc52cc: adrp    x9, #0x1085000                             
02cc52d0: cmp     w8, #1                                     
02cc52d4: ldr     q0, [x9, #0xf20]                           [1085f20]=3d2b81e400000000 f=0,0.0418719
02cc52d8: str     q0, [x1, #0x20]                            
02cc52dc: b.eq    #0x2cc5434                                 
02cc52e0: adrp    x8, #0x1086000                             
02cc52e4: mov     x0, x19                                    
02cc52e8: ldr     q0, [x8, #0x6e0]                           [10866e0]=3d6560423d5df364 f=0.0541872,0.056
02cc52ec: str     q0, [x1, #0x30]                            
02cc52f0: str     x1, [x0, #0x20]!                           .NSA_iPhoneX
02cc52f4: bl      #0x2b70d54                                 fn_2b70d54
02cc52f8: ldr     x0, [x20]                                  S:'didu'
02cc52fc: mov     w1, #2                                     
02cc5300: bl      #0x2b70ea0                                 fn_2b70ea0
02cc5304: cbz     x0, #0x2cc5438                             
02cc5308: ldr     w8, [x0, #0x18]                            S:'android.content.Intent'
02cc530c: mov     x1, x0                                     
02cc5310: cbz     w8, #0x2cc5434                             
02cc5314: adrp    x9, #0x1086000                             
02cc5318: cmp     w8, #1                                     
02cc531c: ldr     q0, [x9, #0xf70]                           [1086f70]=3d1b6db700000000 f=0,0.0379464
02cc5320: str     q0, [x1, #0x20]                            
02cc5324: b.eq    #0x2cc5434                                 
02cc5328: adrp    x8, #0x1087000                             
02cc532c: mov     x0, x19                                    
02cc5330: ldr     q0, [x8, #0xf00]                           [1087f00]=3d4fc4a33d492492 f=0.0491071,0.0507246
02cc5334: str     q0, [x1, #0x30]                            
02cc5338: str     x1, [x0, #0x28]!                           .NSA_iPhoneXsMax
02cc533c: bl      #0x2b70d54                                 fn_2b70d54
02cc5340: ldr     x0, [x20]                                  S:'didu'
02cc5344: mov     w1, #2                                     
02cc5348: bl      #0x2b70ea0                                 fn_2b70ea0
02cc534c: cbz     x0, #0x2cc5438                             
02cc5350: ldr     w8, [x0, #0x18]                            S:'android.content.Intent'
02cc5354: mov     x1, x0                                     
02cc5358: cbz     w8, #0x2cc5434                             
02cc535c: adrp    x9, #0x1086000                             
02cc5360: cmp     w8, #1                                     
02cc5364: ldr     q0, [x9, #0x9e0]                           [10869e0]=0 f=0,0
02cc5368: str     q0, [sp]                                   
02cc536c: str     q0, [x1, #0x20]                            
02cc5370: b.eq    #0x2cc5434                                 
02cc5374: adrp    x8, #0x1085000                             
02cc5378: mov     x0, x19                                    
02cc537c: ldr     q0, [x8, #0xa00]                           [1085a00]=0 f=0,0
02cc5380: str     q0, [x1, #0x30]                            
02cc5384: str     x1, [x0, #0x30]!                           .NSA_Pixel3XL_LSL
02cc5388: bl      #0x2b70d54                                 fn_2b70d54
02cc538c: ldr     x0, [x20]                                  S:'didu'
02cc5390: mov     w1, #2                                     
02cc5394: bl      #0x2b70ea0                                 fn_2b70ea0
02cc5398: cbz     x0, #0x2cc5438                             
02cc539c: ldr     w8, [x0, #0x18]                            S:'android.content.Intent'
02cc53a0: mov     x1, x0                                     
02cc53a4: cbz     w8, #0x2cc5434                             
02cc53a8: ldr     q0, [sp]                                   
02cc53ac: cmp     w8, #1                                     
02cc53b0: str     q0, [x1, #0x20]                            
02cc53b4: b.eq    #0x2cc5434                                 
02cc53b8: adrp    x8, #0x1087000                             
02cc53bc: adrp    x20, #0x6267000                            
02cc53c0: adrp    x21, #0x6267000                            
02cc53c4: ldr     q0, [x8, #0x720]                           [1087720]=3d6ca085 f=0.0577703,0
02cc53c8: ldr     x20, [x20, #0x200]                         T:type15264(k15)
02cc53cc: ldr     x21, [x21, #0x1f8]                         MS:System.Collections.Generic.List`1::.ctor
02cc53d0: mov     x0, x19                                    
02cc53d4: str     q0, [x1, #0x30]                            
02cc53d8: str     x1, [x0, #0x38]!                           .NSA_Pixel3XL_LSR
02cc53dc: bl      #0x2b70d54                                 fn_2b70d54
02cc53e0: ldr     x0, [x20]                                  S:'didu'
02cc53e4: mov     w8, #0x101                                 
02cc53e8: strh    w8, [x19, #0x40]                           ._conformX
02cc53ec: bl      #0x2b7104c                                 fn_2b7104c
02cc53f0: ldr     x1, [x21]                                  S:'didu'
02cc53f4: mov     x20, x0                                    
02cc53f8: bl      #0x35a89a4                                 fn_35a89a4
02cc53fc: mov     x0, x19                                    
02cc5400: mov     x1, x20                                    
02cc5404: str     x20, [x0, #0x48]!                          ._panels
02cc5408: bl      #0x2b70d54                                 fn_2b70d54
02cc540c: mov     w8, #5                                     
02cc5410: stp     xzr, xzr, [x19, #0x50]                     ._lastSafeArea
02cc5414: mov     x0, x19                                    
02cc5418: str     xzr, [x19, #0x60]                          ._lastScreenSize
02cc541c: ldp     x30, x21, [sp, #0x10]                      
02cc5420: str     w8, [x19, #0x68]                           ._lastOrientation
02cc5424: ldp     x20, x19, [sp, #0x20]                      
02cc5428: mov     x1, xzr                                    
02cc542c: add     sp, sp, #0x30                              
02cc5430: b       #0x5b397b0                                 UnityEngine.MonoBehaviour::.ctor
02cc5434: bl      #0x2b71064                                 fn_2b71064
02cc5438: bl      #0x2b7105c                                 fn_2b7105c
