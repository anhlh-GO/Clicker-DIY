#### CLASS Clicker.BaseKeycapConfig/<>c__DisplayClass6_0 parent= object
#   field id                             int                                                off=0x10 attr=6 
## .ctor() -> void
---- Clicker.BaseKeycapConfig/<>c__DisplayClass6_0::.ctor 0x2d5b460
02d5b460: mov     x1, xzr                                    
02d5b464: b       #0x4e53e9c                                 System.Object::.ctor
## <GetData>b__0(Clicker.BaseKeycapItemData data) -> bool
---- Clicker.BaseKeycapConfig/<>c__DisplayClass6_0::<GetData>b__0 0x2d5b478
02d5b478: cbz     x1, #0x2d5b490                             
02d5b47c: ldr     w8, [x1, #0x10]                            
02d5b480: ldr     w9, [x0, #0x10]                            .id
02d5b484: cmp     w8, w9                                     
02d5b488: cset    w0, eq                                     
02d5b48c: ret                                                
02d5b490: str     x30, [sp, #-0x10]!                         
02d5b494: bl      #0x2b7105c                                 fn_2b7105c
## <GetData>b__1(Clicker.BaseKeycapItemData data) -> bool
---- Clicker.BaseKeycapConfig/<>c__DisplayClass6_0::<GetData>b__1 0x2d5b498
02d5b498: cbz     x1, #0x2d5b4b0                             
02d5b49c: ldr     w8, [x1, #0x10]                            
02d5b4a0: ldr     w9, [x0, #0x10]                            .id
02d5b4a4: cmp     w8, w9                                     
02d5b4a8: cset    w0, eq                                     
02d5b4ac: ret                                                
02d5b4b0: str     x30, [sp, #-0x10]!                         
02d5b4b4: bl      #0x2b7105c                                 fn_2b7105c
#### CLASS Clicker.BaseKeycapConfig parent= Clicker.GameConfig
#   field _dataList                      System.Collections.Generic.List`1<Clicker.BaseKeycapItemData> off=0x18 attr=1 SerializeField
#   field _dataListAB                    System.Collections.Generic.List`1<Clicker.BaseKeycapItemData> off=0x20 attr=1 SerializeField
## get_DataList() -> System.Collections.Generic.List`1<Clicker.BaseKeycapItemData>
---- Clicker.BaseKeycapConfig::get_DataList 0x2d5b1a8
02d5b1a8: stp     x30, x21, [sp, #-0x20]!                    
02d5b1ac: stp     x20, x19, [sp, #0x10]                      
02d5b1b0: adrp    x21, #0x6630000                            
02d5b1b4: adrp    x20, #0x6264000                            
02d5b1b8: mov     x19, x0                                    
02d5b1bc: ldrb    w8, [x21, #0x2bb]                          
02d5b1c0: ldr     x20, [x20, #0xfc0]                         T:RemoteConfigManager
02d5b1c4: tbnz    w8, #0, #0x2d5b1dc                         
02d5b1c8: adrp    x0, #0x6264000                             
02d5b1cc: ldr     x0, [x0, #0xfc0]                           T:RemoteConfigManager
02d5b1d0: bl      #0x2b70db0                                 fn_2b70db0
02d5b1d4: mov     w8, #1                                     
02d5b1d8: strb    w8, [x21, #0x2bb]                          
02d5b1dc: ldr     x0, [x20]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d5b1e0: ldr     w8, [x0, #0xe4]                            [62640e4]=0 f=0,0
02d5b1e4: cbnz    w8, #0x2d5b1ec                             
02d5b1e8: bl      #0x2b70f30                                 fn_2b70f30
02d5b1ec: adrp    x21, #0x662f000                            
02d5b1f0: ldrb    w8, [x21, #0xbc1]                          
02d5b1f4: cbnz    w8, #0x2d5b20c                             
02d5b1f8: adrp    x0, #0x6264000                             
02d5b1fc: ldr     x0, [x0, #0xfc0]                           T:RemoteConfigManager
02d5b200: bl      #0x2b70db0                                 fn_2b70db0
02d5b204: mov     w8, #1                                     
02d5b208: strb    w8, [x21, #0xbc1]                          
02d5b20c: ldr     x0, [x20]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d5b210: ldr     w8, [x0, #0xe4]                            [62640e4]=0 f=0,0
02d5b214: cbnz    w8, #0x2d5b220                             
02d5b218: bl      #0x2b70f30                                 fn_2b70f30
02d5b21c: ldr     x0, [x20]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d5b220: ldr     x8, [x0, #0xb8]                            MS:DG.Tweening.Core.Extensions::SetSpecialStartupMode
02d5b224: mov     w9, #0x18                                  
02d5b228: ldr     w8, [x8, #0x10]                            
02d5b22c: cmp     w8, #1                                     
02d5b230: mov     w8, #0x20                                  
02d5b234: csel    x8, x9, x8, eq                             
02d5b238: ldr     x0, [x19, x8]                              
02d5b23c: ldp     x20, x19, [sp, #0x10]                      
02d5b240: ldp     x30, x21, [sp], #0x20                      
02d5b244: ret                                                
## get_Count() -> int
---- Clicker.BaseKeycapConfig::get_Count 0x2d5b248
02d5b248: stp     x30, x21, [sp, #-0x20]!                    
02d5b24c: stp     x20, x19, [sp, #0x10]                      
02d5b250: adrp    x21, #0x6630000                            
02d5b254: adrp    x20, #0x6264000                            
02d5b258: mov     x19, x0                                    
02d5b25c: ldrb    w8, [x21, #0x2bc]                          
02d5b260: ldr     x20, [x20, #0xfc0]                         T:RemoteConfigManager
02d5b264: tbnz    w8, #0, #0x2d5b288                         
02d5b268: adrp    x0, #0x626b000                             
02d5b26c: ldr     x0, [x0, #0xc00]                           MS:System.Collections.Generic.List`1::get_Count
02d5b270: bl      #0x2b70db0                                 fn_2b70db0
02d5b274: adrp    x0, #0x6264000                             
02d5b278: ldr     x0, [x0, #0xfc0]                           T:RemoteConfigManager
02d5b27c: bl      #0x2b70db0                                 fn_2b70db0
02d5b280: mov     w8, #1                                     
02d5b284: strb    w8, [x21, #0x2bc]                          
02d5b288: ldr     x0, [x20]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d5b28c: ldr     w8, [x0, #0xe4]                            [62640e4]=0 f=0,0
02d5b290: cbnz    w8, #0x2d5b298                             
02d5b294: bl      #0x2b70f30                                 fn_2b70f30
02d5b298: adrp    x21, #0x662f000                            
02d5b29c: ldrb    w8, [x21, #0xbc1]                          
02d5b2a0: cbnz    w8, #0x2d5b2b8                             
02d5b2a4: adrp    x0, #0x6264000                             
02d5b2a8: ldr     x0, [x0, #0xfc0]                           T:RemoteConfigManager
02d5b2ac: bl      #0x2b70db0                                 fn_2b70db0
02d5b2b0: mov     w8, #1                                     
02d5b2b4: strb    w8, [x21, #0xbc1]                          
02d5b2b8: ldr     x0, [x20]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d5b2bc: ldr     w8, [x0, #0xe4]                            [62640e4]=0 f=0,0
02d5b2c0: cbnz    w8, #0x2d5b2cc                             
02d5b2c4: bl      #0x2b70f30                                 fn_2b70f30
02d5b2c8: ldr     x0, [x20]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d5b2cc: ldr     x8, [x0, #0xb8]                            MS:DG.Tweening.Core.Extensions::SetSpecialStartupMode
02d5b2d0: ldr     w8, [x8, #0x10]                            
02d5b2d4: cmp     w8, #1                                     
02d5b2d8: b.ne    #0x2d5b2e8                                 
02d5b2dc: ldr     x8, [x19, #0x18]                           ._dataList
02d5b2e0: cbnz    x8, #0x2d5b2f0                             
02d5b2e4: bl      #0x2b7105c                                 fn_2b7105c
02d5b2e8: ldr     x8, [x19, #0x20]                           ._dataListAB
02d5b2ec: cbz     x8, #0x2d5b2e4                             
02d5b2f0: ldp     x20, x19, [sp, #0x10]                      
02d5b2f4: ldr     w0, [x8, #0x18]                            
02d5b2f8: ldp     x30, x21, [sp], #0x20                      
02d5b2fc: ret                                                
## GetData(int id) -> Clicker.BaseKeycapItemData
---- Clicker.BaseKeycapConfig::GetData 0x2d5b300
02d5b300: str     x30, [sp, #-0x30]!                         
02d5b304: stp     x22, x21, [sp, #0x10]                      
02d5b308: stp     x20, x19, [sp, #0x20]                      
02d5b30c: adrp    x20, #0x6630000                            
02d5b310: adrp    x22, #0x626b000                            
02d5b314: mov     w21, w1                                    
02d5b318: ldrb    w8, [x20, #0x2bd]                          
02d5b31c: ldr     x22, [x22, #0xc08]                         T:Clicker.BaseKeycapConfig/<>c__DisplayClass6_0
02d5b320: mov     x19, x0                                    
02d5b324: tbnz    w8, #0, #0x2d5b378                         
02d5b328: adrp    x0, #0x626b000                             
02d5b32c: ldr     x0, [x0, #0xc10]                           MS:System.Collections.Generic.List`1::Find
02d5b330: bl      #0x2b70db0                                 fn_2b70db0
02d5b334: adrp    x0, #0x626b000                             
02d5b338: ldr     x0, [x0, #0xc18]                           T:type57218(k15)
02d5b33c: bl      #0x2b70db0                                 fn_2b70db0
02d5b340: adrp    x0, #0x6264000                             
02d5b344: ldr     x0, [x0, #0xfc0]                           T:RemoteConfigManager
02d5b348: bl      #0x2b70db0                                 fn_2b70db0
02d5b34c: adrp    x0, #0x626b000                             
02d5b350: ldr     x0, [x0, #0xc20]                           M:Clicker.BaseKeycapConfig/<>c__DisplayClass6_0::<GetData>b__0
02d5b354: bl      #0x2b70db0                                 fn_2b70db0
02d5b358: adrp    x0, #0x626b000                             
02d5b35c: ldr     x0, [x0, #0xc28]                           M:Clicker.BaseKeycapConfig/<>c__DisplayClass6_0::<GetData>b__1
02d5b360: bl      #0x2b70db0                                 fn_2b70db0
02d5b364: adrp    x0, #0x626b000                             
02d5b368: ldr     x0, [x0, #0xc08]                           T:Clicker.BaseKeycapConfig/<>c__DisplayClass6_0
02d5b36c: bl      #0x2b70db0                                 fn_2b70db0
02d5b370: mov     w8, #1                                     
02d5b374: strb    w8, [x20, #0x2bd]                          
02d5b378: ldr     x0, [x22]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d5b37c: bl      #0x2b7104c                                 fn_2b7104c
02d5b380: mov     x1, xzr                                    
02d5b384: mov     x20, x0                                    
02d5b388: bl      #0x4e53e9c                                 System.Object::.ctor
02d5b38c: cbz     x20, #0x2d5b45c                            
02d5b390: adrp    x22, #0x6264000                            
02d5b394: ldr     x22, [x22, #0xfc0]                         T:RemoteConfigManager
02d5b398: str     w21, [x20, #0x10]                          
02d5b39c: ldr     x0, [x22]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d5b3a0: ldr     w8, [x0, #0xe4]                            [626b0e4]=0 f=0,0
02d5b3a4: cbnz    w8, #0x2d5b3ac                             
02d5b3a8: bl      #0x2b70f30                                 fn_2b70f30
02d5b3ac: adrp    x21, #0x662f000                            
02d5b3b0: ldrb    w8, [x21, #0xbc1]                          
02d5b3b4: cbnz    w8, #0x2d5b3cc                             
02d5b3b8: adrp    x0, #0x6264000                             
02d5b3bc: ldr     x0, [x0, #0xfc0]                           T:RemoteConfigManager
02d5b3c0: bl      #0x2b70db0                                 fn_2b70db0
02d5b3c4: mov     w8, #1                                     
02d5b3c8: strb    w8, [x21, #0xbc1]                          
02d5b3cc: ldr     x0, [x22]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d5b3d0: adrp    x21, #0x626b000                            
02d5b3d4: ldr     w8, [x0, #0xe4]                            [62640e4]=0 f=0,0
02d5b3d8: ldr     x21, [x21, #0xc18]                         T:type57218(k15)
02d5b3dc: cbnz    w8, #0x2d5b3e8                             
02d5b3e0: bl      #0x2b70f30                                 fn_2b70f30
02d5b3e4: ldr     x0, [x22]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d5b3e8: ldr     x8, [x0, #0xb8]                            MS:DG.Tweening.Core.Extensions::SetSpecialStartupMode
02d5b3ec: ldr     x0, [x21]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d5b3f0: ldr     w8, [x8, #0x10]                            
02d5b3f4: cmp     w8, #1                                     
02d5b3f8: b.ne    #0x2d5b410                                 
02d5b3fc: ldr     x19, [x19, #0x18]                          ._dataList
02d5b400: bl      #0x2b7104c                                 fn_2b7104c
02d5b404: adrp    x8, #0x626b000                             
02d5b408: ldr     x8, [x8, #0xc20]                           M:Clicker.BaseKeycapConfig/<>c__DisplayClass6_0::<GetData>b__0
02d5b40c: b       #0x2d5b420                                 
02d5b410: ldr     x19, [x19, #0x20]                          ._dataListAB
02d5b414: bl      #0x2b7104c                                 fn_2b7104c
02d5b418: adrp    x8, #0x626b000                             
02d5b41c: ldr     x8, [x8, #0xc28]                           M:Clicker.BaseKeycapConfig/<>c__DisplayClass6_0::<GetData>b__1
02d5b420: ldr     x2, [x8]                                   T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d5b424: mov     x1, x20                                    
02d5b428: mov     x3, xzr                                    
02d5b42c: mov     x21, x0                                    
02d5b430: bl      #0x399ba10                                 fn_399ba10
02d5b434: cbz     x19, #0x2d5b45c                            
02d5b438: adrp    x8, #0x626b000                             
02d5b43c: mov     x0, x19                                    
02d5b440: mov     x1, x21                                    
02d5b444: ldr     x8, [x8, #0xc10]                           MS:System.Collections.Generic.List`1::Find
02d5b448: ldp     x20, x19, [sp, #0x20]                      
02d5b44c: ldp     x22, x21, [sp, #0x10]                      
02d5b450: ldr     x2, [x8]                                   T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d5b454: ldr     x30, [sp], #0x30                           
02d5b458: b       #0x35a9868                                 
02d5b45c: bl      #0x2b7105c                                 fn_2b7105c
## .ctor() -> void
---- Clicker.BaseKeycapConfig::.ctor 0x2d5b468
02d5b468: mov     x1, xzr                                    
02d5b46c: b       #0x5b398f0                                 UnityEngine.ScriptableObject::.ctor
