#### CLASS Clicker.PrinterProcess/<>c parent= object
#   field <>9                            Clicker.PrinterProcess/<>c                         off=0x0 attr=36 
#   field <>9__3_0                       System.Action`1<UnityEngine.GameObject>            off=0x8 attr=16 
## .cctor() -> void
---- Clicker.PrinterProcess/<>c::.cctor 0x2d651d4
02d651d4: str     x30, [sp, #-0x20]!                         
02d651d8: stp     x20, x19, [sp, #0x10]                      
02d651dc: adrp    x19, #0x6630000                            
02d651e0: adrp    x20, #0x626c000                            
02d651e4: ldrb    w8, [x19, #0x323]                          
02d651e8: ldr     x20, [x20, #0xf0]                          T:Clicker.PrinterProcess/<>c
02d651ec: tbnz    w8, #0, #0x2d65204                         
02d651f0: adrp    x0, #0x626c000                             
02d651f4: ldr     x0, [x0, #0xf0]                            T:Clicker.PrinterProcess/<>c
02d651f8: bl      #0x2b70db0                                 fn_2b70db0
02d651fc: mov     w8, #1                                     
02d65200: strb    w8, [x19, #0x323]                          
02d65204: ldr     x0, [x20]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d65208: bl      #0x2b7104c                                 fn_2b7104c
02d6520c: mov     x1, xzr                                    
02d65210: mov     x19, x0                                    
02d65214: bl      #0x4e53e9c                                 System.Object::.ctor
02d65218: ldr     x8, [x20]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d6521c: mov     x1, x19                                    
02d65220: ldr     x8, [x8, #0xb8]                            
02d65224: str     x19, [x8]                                  
02d65228: ldr     x8, [x20]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d6522c: ldp     x20, x19, [sp, #0x10]                      
02d65230: ldr     x0, [x8, #0xb8]                            
02d65234: ldr     x30, [sp], #0x20                           
02d65238: b       #0x2b70d54                                 
## .ctor() -> void
---- Clicker.PrinterProcess/<>c::.ctor 0x2d6523c
02d6523c: mov     x1, xzr                                    
02d65240: b       #0x4e53e9c                                 System.Object::.ctor
## <ResetStatus>b__3_0(UnityEngine.GameObject p) -> void
---- Clicker.PrinterProcess/<>c::<ResetStatus>b__3_0 0x2d65244
02d65244: cbz     x1, #0x2d65258                             
02d65248: mov     x0, x1                                     
02d6524c: mov     w1, wzr                                    
02d65250: mov     x2, xzr                                    
02d65254: b       #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d65258: str     x30, [sp, #-0x10]!                         
02d6525c: bl      #0x2b7105c                                 fn_2b7105c
#### CLASS Clicker.PrinterProcess parent= UnityEngine.MonoBehaviour
#   field _goOff                         UnityEngine.GameObject                             off=0x20 attr=1 SerializeField
#   field _goOn                          UnityEngine.GameObject                             off=0x28 attr=1 SerializeField
#   field _percents                      System.Collections.Generic.List`1<UnityEngine.GameObject> off=0x30 attr=1 SerializeField
## ResetStatus() -> void
---- Clicker.PrinterProcess::ResetStatus 0x2d64730
02d64730: stp     x30, x23, [sp, #-0x30]!                    
02d64734: stp     x22, x21, [sp, #0x10]                      
02d64738: stp     x20, x19, [sp, #0x20]                      
02d6473c: adrp    x20, #0x6630000                            
02d64740: adrp    x23, #0x626c000                            
02d64744: mov     x19, x0                                    
02d64748: ldrb    w8, [x20, #0x321]                          
02d6474c: ldr     x23, [x23, #0xf0]                          T:Clicker.PrinterProcess/<>c
02d64750: tbnz    w8, #0, #0x2d6478c                         
02d64754: adrp    x0, #0x6266000                             
02d64758: ldr     x0, [x0, #0xda8]                           T:type6904(k15)
02d6475c: bl      #0x2b70db0                                 fn_2b70db0
02d64760: adrp    x0, #0x6266000                             
02d64764: ldr     x0, [x0, #0xdb0]                           MS:System.Collections.Generic.List`1::ForEach
02d64768: bl      #0x2b70db0                                 fn_2b70db0
02d6476c: adrp    x0, #0x626c000                             
02d64770: ldr     x0, [x0, #0xf8]                            M:Clicker.PrinterProcess/<>c::<ResetStatus>b__3_0
02d64774: bl      #0x2b70db0                                 fn_2b70db0
02d64778: adrp    x0, #0x626c000                             
02d6477c: ldr     x0, [x0, #0xf0]                            T:Clicker.PrinterProcess/<>c
02d64780: bl      #0x2b70db0                                 fn_2b70db0
02d64784: mov     w8, #1                                     
02d64788: strb    w8, [x20, #0x321]                          
02d6478c: ldr     x0, [x23]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d64790: ldr     x20, [x19, #0x30]                          ._percents
02d64794: ldr     w8, [x0, #0xe4]                            [626c0e4]=0 f=0,0
02d64798: cbnz    w8, #0x2d647a4                             
02d6479c: bl      #0x2b70f30                                 fn_2b70f30
02d647a0: ldr     x0, [x23]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d647a4: ldr     x8, [x0, #0xb8]                            MS:System.Collections.Generic.List`1::Add
02d647a8: ldr     x21, [x8, #8]                              
02d647ac: cbnz    x21, #0x2d64808                            
02d647b0: ldr     w9, [x0, #0xe4]                            [626c0e4]=0 f=0,0
02d647b4: cbnz    w9, #0x2d647c4                             
02d647b8: bl      #0x2b70f30                                 fn_2b70f30
02d647bc: ldr     x8, [x23]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d647c0: ldr     x8, [x8, #0xb8]                            
02d647c4: adrp    x9, #0x6266000                             
02d647c8: ldr     x9, [x9, #0xda8]                           T:type6904(k15)
02d647cc: ldr     x22, [x8]                                  
02d647d0: ldr     x0, [x9]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d647d4: bl      #0x2b7104c                                 fn_2b7104c
02d647d8: adrp    x8, #0x626c000                             
02d647dc: mov     x1, x22                                    
02d647e0: mov     x3, xzr                                    
02d647e4: ldr     x8, [x8, #0xf8]                            M:Clicker.PrinterProcess/<>c::<ResetStatus>b__3_0
02d647e8: mov     x21, x0                                    
02d647ec: ldr     x2, [x8]                                   M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d647f0: bl      #0x453418c                                 fn_453418c
02d647f4: ldr     x8, [x23]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d647f8: mov     x1, x21                                    
02d647fc: ldr     x0, [x8, #0xb8]                            MS:System.Collections.Generic.List`1::Add
02d64800: str     x21, [x0, #8]!                             
02d64804: bl      #0x2b70d54                                 fn_2b70d54
02d64808: cbz     x20, #0x2d64858                            
02d6480c: adrp    x8, #0x6266000                             
02d64810: mov     x0, x20                                    
02d64814: mov     x1, x21                                    
02d64818: ldr     x8, [x8, #0xdb0]                           MS:System.Collections.Generic.List`1::ForEach
02d6481c: ldr     x2, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d64820: bl      #0x35a9ce4                                 fn_35a9ce4
02d64824: ldr     x0, [x19, #0x20]                           ._goOff
02d64828: cbz     x0, #0x2d64858                             
02d6482c: mov     w1, #1                                     
02d64830: mov     x2, xzr                                    
02d64834: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d64838: ldr     x0, [x19, #0x28]                           ._goOn
02d6483c: cbz     x0, #0x2d64858                             
02d64840: ldp     x20, x19, [sp, #0x20]                      
02d64844: mov     w1, wzr                                    
02d64848: ldp     x22, x21, [sp, #0x10]                      
02d6484c: mov     x2, xzr                                    
02d64850: ldp     x30, x23, [sp], #0x30                      
02d64854: b       #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d64858: bl      #0x2b7105c                                 fn_2b7105c
## OnMachineStateChange(bool isOn) -> void
---- Clicker.PrinterProcess::OnMachineStateChange 0x2d6485c
02d6485c: str     x30, [sp, #-0x20]!                         
02d64860: stp     x20, x19, [sp, #0x10]                      
02d64864: mov     x20, x0                                    
02d64868: ldr     x0, [x0, #0x20]                            ._goOff
02d6486c: cbz     x0, #0x2d648a0                             
02d64870: mov     w8, #1                                     
02d64874: mov     w19, w1                                    
02d64878: mov     x2, xzr                                    
02d6487c: bic     w1, w8, w1                                 
02d64880: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d64884: ldr     x0, [x20, #0x28]                           ._goOn
02d64888: cbz     x0, #0x2d648a0                             
02d6488c: and     w1, w19, #1                                
02d64890: ldp     x20, x19, [sp, #0x10]                      
02d64894: mov     x2, xzr                                    
02d64898: ldr     x30, [sp], #0x20                           
02d6489c: b       #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d648a0: bl      #0x2b7105c                                 fn_2b7105c
## SetProcess(float percent) -> void
---- Clicker.PrinterProcess::SetProcess 0x2d64cc4
02d64cc4: str     d8, [sp, #-0x40]!                          
02d64cc8: stp     x30, x23, [sp, #0x10]                      
02d64ccc: stp     x22, x21, [sp, #0x20]                      
02d64cd0: stp     x20, x19, [sp, #0x30]                      
02d64cd4: fmov    s8, s0                                     
02d64cd8: adrp    x20, #0x6630000                            
02d64cdc: mov     x19, x0                                    
02d64ce0: ldrb    w8, [x20, #0x322]                          
02d64ce4: tbnz    w8, #0, #0x2d64d08                         
02d64ce8: adrp    x0, #0x6266000                             
02d64cec: ldr     x0, [x0, #0x900]                           MS:System.Collections.Generic.List`1::get_Count
02d64cf0: bl      #0x2b70db0                                 fn_2b70db0
02d64cf4: adrp    x0, #0x6266000                             
02d64cf8: ldr     x0, [x0, #0x908]                           MS:System.Collections.Generic.List`1::get_Item
02d64cfc: bl      #0x2b70db0                                 fn_2b70db0
02d64d00: mov     w8, #1                                     
02d64d04: strb    w8, [x20, #0x322]                          
02d64d08: fcmp    s8, #0.0                                   
02d64d0c: b.mi    #0x2d64dc4                                 
02d64d10: mov     w8, #0x42c80000                            
02d64d14: fmov    s0, w8                                     
02d64d18: fcmp    s8, s0                                     
02d64d1c: b.gt    #0x2d64dc4                                 
02d64d20: adrp    x20, #0x662f000                            
02d64d24: ldrb    w8, [x20, #0xbd8]                          
02d64d28: cbnz    w8, #0x2d64d40                             
02d64d2c: adrp    x0, #0x6265000                             
02d64d30: ldr     x0, [x0, #0xb48]                           T:System.Math
02d64d34: bl      #0x2b70db0                                 fn_2b70db0
02d64d38: mov     w8, #1                                     
02d64d3c: strb    w8, [x20, #0xbd8]                          
02d64d40: adrp    x8, #0x6265000                             
02d64d44: ldr     x8, [x8, #0xb48]                           T:System.Math
02d64d48: ldr     x0, [x8]                                   M:AdsManager::<OnApplicationPause>b__26_0
02d64d4c: ldr     w8, [x0, #0xe4]                            [62650e4]=0 f=0,0
02d64d50: cbnz    w8, #0x2d64d58                             
02d64d54: bl      #0x2b70f30                                 fn_2b70f30
02d64d58: ldr     x0, [x19, #0x30]                           ._percents
02d64d5c: cbz     x0, #0x2d64dc0                             
02d64d60: fmov    s0, #10.00000000                           
02d64d64: adrp    x22, #0x6266000                            
02d64d68: mov     w20, wzr                                   
02d64d6c: ldr     x22, [x22, #0x908]                         MS:System.Collections.Generic.List`1::get_Item
02d64d70: mov     w23, #0x7f800000                           
02d64d74: fdiv    s0, s8, s0                                 
02d64d78: frintm  s8, s0                                     
02d64d7c: fcvtms  w21, s0                                    
02d64d80: ldr     w8, [x0, #0x18]                            T:AdsManager/<IEHideAdResume>d__30
02d64d84: cmp     w20, w8                                    
02d64d88: b.ge    #0x2d64dc4                                 
02d64d8c: ldr     x2, [x22]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d64d90: mov     w1, w20                                    
02d64d94: bl      #0x35a8f3c                                 fn_35a8f3c
02d64d98: cbz     x0, #0x2d64dc0                             
02d64d9c: fmov    s0, w23                                    
02d64da0: cmp     w20, w21                                   
02d64da4: mov     x2, xzr                                    
02d64da8: fccmp   s8, s0, #4, le                             
02d64dac: cset    w1, ne                                     
02d64db0: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d64db4: ldr     x0, [x19, #0x30]                           ._percents
02d64db8: add     w20, w20, #1                               
02d64dbc: cbnz    x0, #0x2d64d80                             
02d64dc0: bl      #0x2b7105c                                 fn_2b7105c
02d64dc4: ldp     x20, x19, [sp, #0x30]                      
02d64dc8: ldp     x22, x21, [sp, #0x20]                      
02d64dcc: ldp     x30, x23, [sp, #0x10]                      
02d64dd0: ldr     d8, [sp], #0x40                            
02d64dd4: ret                                                
## .ctor() -> void
---- Clicker.PrinterProcess::.ctor 0x2d651cc
02d651cc: mov     x1, xzr                                    
02d651d0: b       #0x5b397b0                                 UnityEngine.MonoBehaviour::.ctor
