#### CLASS ForceUpdate parent= UnityEngine.MonoBehaviour
#   field _view                          UnityEngine.GameObject                             off=0x20 attr=1 SerializeField
#   field _btnUpdate                     UnityEngine.UI.Button                              off=0x28 attr=1 SerializeField
#   field tween                          DG.Tweening.Tween                                  off=0x30 attr=1 
## Start() -> void
---- ForceUpdate::Start 0x2ca36e0
02ca36e0: stp     x30, x23, [sp, #-0x30]!                    
02ca36e4: stp     x22, x21, [sp, #0x10]                      
02ca36e8: stp     x20, x19, [sp, #0x20]                      
02ca36ec: adrp    x20, #0x662f000                            
02ca36f0: mov     x19, x0                                    
02ca36f4: ldrb    w8, [x20, #0xabd]                          
02ca36f8: tbnz    w8, #0, #0x2ca3734                         
02ca36fc: adrp    x0, #0x6266000                             
02ca3700: ldr     x0, [x0, #0x100]                           M:ForceUpdate::OnClickUpdate
02ca3704: bl      #0x2b70db0                                 fn_2b70db0
02ca3708: adrp    x0, #0x6266000                             
02ca370c: ldr     x0, [x0, #0x108]                           M:ForceUpdate::<Start>b__3_0
02ca3710: bl      #0x2b70db0                                 fn_2b70db0
02ca3714: adrp    x0, #0x6264000                             
02ca3718: ldr     x0, [x0, #0xe8]                            T:DG.Tweening.TweenCallback
02ca371c: bl      #0x2b70db0                                 fn_2b70db0
02ca3720: adrp    x0, #0x6265000                             
02ca3724: ldr     x0, [x0, #0x3f0]                           T:UnityEngine.Events.UnityAction
02ca3728: bl      #0x2b70db0                                 fn_2b70db0
02ca372c: mov     w8, #1                                     
02ca3730: strb    w8, [x20, #0xabd]                          
02ca3734: ldr     x8, [x19, #0x28]                           ._btnUpdate
02ca3738: cbz     x8, #0x2ca37dc                             
02ca373c: adrp    x9, #0x6265000                             
02ca3740: adrp    x21, #0x6266000                            
02ca3744: ldr     x9, [x9, #0x3f0]                           T:UnityEngine.Events.UnityAction
02ca3748: ldr     x21, [x21, #0x100]                         M:ForceUpdate::OnClickUpdate
02ca374c: ldr     x20, [x8, #0x100]                          
02ca3750: ldr     x0, [x9]                                   M:AdsManager::<OnApplicationPause>b__26_0
02ca3754: bl      #0x2b7104c                                 fn_2b7104c
02ca3758: ldr     x2, [x21]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca375c: mov     x1, x19                                    
02ca3760: mov     x3, xzr                                    
02ca3764: mov     x21, x0                                    
02ca3768: bl      #0x5b4cf98                                 UnityEngine.Events.UnityAction::.ctor
02ca376c: cbz     x20, #0x2ca37dc                            
02ca3770: adrp    x22, #0x6264000                            
02ca3774: adrp    x23, #0x6266000                            
02ca3778: mov     x0, x20                                    
02ca377c: ldr     x22, [x22, #0xe8]                          T:DG.Tweening.TweenCallback
02ca3780: ldr     x23, [x23, #0x108]                         M:ForceUpdate::<Start>b__3_0
02ca3784: mov     x1, x21                                    
02ca3788: mov     x2, xzr                                    
02ca378c: bl      #0x5b4d0ac                                 UnityEngine.Events.UnityEvent::AddListener
02ca3790: ldr     x0, [x22]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02ca3794: bl      #0x2b7104c                                 fn_2b7104c
02ca3798: ldr     x2, [x23]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca379c: mov     x1, x19                                    
02ca37a0: mov     x3, xzr                                    
02ca37a4: mov     x20, x0                                    
02ca37a8: bl      #0x2d89dc4                                 DG.Tweening.TweenCallback::.ctor
02ca37ac: fmov    s0, #5.00000000                            
02ca37b0: mov     x0, x20                                    
02ca37b4: mov     w1, #1                                     
02ca37b8: mov     x2, xzr                                    
02ca37bc: bl      #0x2d8f37c                                 DG.Tweening.DOVirtual::DelayedCall
02ca37c0: str     x0, [x19, #0x30]!                          .tween
02ca37c4: mov     x1, x0                                     
02ca37c8: mov     x0, x19                                    
02ca37cc: ldp     x20, x19, [sp, #0x20]                      
02ca37d0: ldp     x22, x21, [sp, #0x10]                      
02ca37d4: ldp     x30, x23, [sp], #0x30                      
02ca37d8: b       #0x2b70d54                                 
02ca37dc: bl      #0x2b7105c                                 fn_2b7105c
## OnDestroy() -> void
---- ForceUpdate::OnDestroy 0x2ca37e0
02ca37e0: ldr     x0, [x0, #0x30]                            .tween
02ca37e4: cbz     x0, #0x2ca37f4                             
02ca37e8: mov     w1, wzr                                    
02ca37ec: mov     x2, xzr                                    
02ca37f0: b       #0x2d8fe94                                 DG.Tweening.TweenExtensions::Kill
02ca37f4: ret                                                
## CheckForceUpdate() -> void
---- ForceUpdate::CheckForceUpdate 0x2ca37f8
02ca37f8: stp     x30, x21, [sp, #-0x20]!                    
02ca37fc: stp     x20, x19, [sp, #0x10]                      
02ca3800: adrp    x21, #0x662f000                            
02ca3804: adrp    x20, #0x6264000                            
02ca3808: mov     x19, x0                                    
02ca380c: ldrb    w8, [x21, #0xabe]                          
02ca3810: ldr     x20, [x20, #0xfc0]                         T:RemoteConfigManager
02ca3814: tbnz    w8, #0, #0x2ca382c                         
02ca3818: adrp    x0, #0x6264000                             
02ca381c: ldr     x0, [x0, #0xfc0]                           T:RemoteConfigManager
02ca3820: bl      #0x2b70db0                                 fn_2b70db0
02ca3824: mov     w8, #1                                     
02ca3828: strb    w8, [x21, #0xabe]                          
02ca382c: ldr     x0, [x20]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02ca3830: ldr     w8, [x0, #0xe4]                            [62640e4]=0 f=0,0
02ca3834: cbnz    w8, #0x2ca383c                             
02ca3838: bl      #0x2b70f30                                 fn_2b70f30
02ca383c: adrp    x21, #0x662f000                            
02ca3840: ldrb    w8, [x21, #0xbc3]                          
02ca3844: cbnz    w8, #0x2ca385c                             
02ca3848: adrp    x0, #0x6264000                             
02ca384c: ldr     x0, [x0, #0xfc0]                           T:RemoteConfigManager
02ca3850: bl      #0x2b70db0                                 fn_2b70db0
02ca3854: mov     w8, #1                                     
02ca3858: strb    w8, [x21, #0xbc3]                          
02ca385c: ldr     x0, [x20]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02ca3860: ldr     w8, [x0, #0xe4]                            [62640e4]=0 f=0,0
02ca3864: cbnz    w8, #0x2ca3870                             
02ca3868: bl      #0x2b70f30                                 fn_2b70f30
02ca386c: ldr     x0, [x20]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02ca3870: ldr     x8, [x19, #0x20]                           ._view
02ca3874: cbz     x8, #0x2ca38b4                             
02ca3878: ldr     x9, [x0, #0xb8]                            MS:DG.Tweening.Core.Extensions::SetSpecialStartupMode
02ca387c: mov     x0, x8                                     
02ca3880: mov     x2, xzr                                    
02ca3884: ldrb    w19, [x9, #0x38]                           
02ca3888: mov     w1, w19                                    
02ca388c: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02ca3890: cbz     w19, #0x2ca38a8                            
02ca3894: ldp     x20, x19, [sp, #0x10]                      
02ca3898: movi    d0, #0000000000000000                      
02ca389c: mov     x0, xzr                                    
02ca38a0: ldp     x30, x21, [sp], #0x20                      
02ca38a4: b       #0x5b434bc                                 UnityEngine.Time::set_timeScale
02ca38a8: ldp     x20, x19, [sp, #0x10]                      
02ca38ac: ldp     x30, x21, [sp], #0x20                      
02ca38b0: ret                                                
02ca38b4: bl      #0x2b7105c                                 fn_2b7105c
## OnClickUpdate() -> void
---- ForceUpdate::OnClickUpdate 0x2ca38b8
02ca38b8: b       #0x2ca38bc                                 RateApp::CallRateApp
## .ctor() -> void
---- ForceUpdate::.ctor 0x2ca393c
02ca393c: mov     x1, xzr                                    
02ca3940: b       #0x5b397b0                                 UnityEngine.MonoBehaviour::.ctor
## <Start>b__3_0() -> void
---- ForceUpdate::<Start>b__3_0 0x2ca3944
02ca3944: b       #0x2ca37f8                                 ForceUpdate::CheckForceUpdate
