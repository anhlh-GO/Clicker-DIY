#### CLASS DailyMission.DailyMissionManager parent= MonoSingleton`1<DailyMission.DailyMissionManager>
#   field _currentQuest                  DailyMission.IQuest                                off=0x20 attr=1 
## CheckQuest(DailyMission.QuestContent input) -> void
---- DailyMission.DailyMissionManager::CheckQuest 0x2d76258
02d76258: stp     x30, x21, [sp, #-0x20]!                    
02d7625c: stp     x20, x19, [sp, #0x10]                      
02d76260: adrp    x21, #0x6630000                            
02d76264: mov     x19, x1                                    
02d76268: mov     x20, x0                                    
02d7626c: ldrb    w8, [x21, #0x3d7]                          
02d76270: tbnz    w8, #0, #0x2d762a0                         
02d76274: adrp    x0, #0x6263000                             
02d76278: ldr     x0, [x0, #0x928]                           T:UnityEngine.Debug
02d7627c: bl      #0x2b70db0                                 fn_2b70db0
02d76280: adrp    x0, #0x626c000                             
02d76284: ldr     x0, [x0, #0x820]                           T:DailyMission.IQuest
02d76288: bl      #0x2b70db0                                 fn_2b70db0
02d7628c: adrp    x0, #0x626c000                             
02d76290: ldr     x0, [x0, #0x828]                           S:'Current quest is not set.'
02d76294: bl      #0x2b70db0                                 fn_2b70db0
02d76298: mov     w8, #1                                     
02d7629c: strb    w8, [x21, #0x3d7]                          
02d762a0: ldr     x20, [x20, #0x20]                          ._currentQuest
02d762a4: cbz     x20, #0x2d762f0                            
02d762a8: adrp    x10, #0x626c000                            
02d762ac: ldr     x8, [x20]                                  
02d762b0: ldr     x10, [x10, #0x820]                         T:DailyMission.IQuest
02d762b4: ldrh    w9, [x8, #0x12e]                           
02d762b8: ldr     x1, [x10]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d762bc: cbz     x9, #0x2d762e0                             
02d762c0: ldr     x10, [x8, #0xb0]                           
02d762c4: add     x10, x10, #8                               &626c008
02d762c8: ldur    x11, [x10, #-8]                            
02d762cc: cmp     x11, x1                                    
02d762d0: b.eq    #0x2d76324                                 
02d762d4: subs    x9, x9, #1                                 
02d762d8: add     x10, x10, #0x10                            &626c010
02d762dc: b.ne    #0x2d762c8                                 
02d762e0: mov     x0, x20                                    
02d762e4: mov     w2, wzr                                    
02d762e8: bl      #0x2baa05c                                 fn_2baa05c
02d762ec: b       #0x2d76330                                 
02d762f0: adrp    x8, #0x6263000                             
02d762f4: ldr     x8, [x8, #0x928]                           T:UnityEngine.Debug
02d762f8: ldr     x0, [x8]                                   &2c5bbd4(=a9bd7bfdd503233f)
02d762fc: ldr     w8, [x0, #0xe4]                            [626c0e4]=0 f=0,0
02d76300: cbnz    w8, #0x2d76308                             
02d76304: bl      #0x2b70f30                                 fn_2b70f30
02d76308: adrp    x8, #0x626c000                             
02d7630c: mov     x1, xzr                                    
02d76310: ldr     x8, [x8, #0x828]                           S:'Current quest is not set.'
02d76314: ldp     x20, x19, [sp, #0x10]                      
02d76318: ldr     x0, [x8]                                   M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d7631c: ldp     x30, x21, [sp], #0x20                      
02d76320: b       #0x5af2840                                 UnityEngine.Debug::LogError
02d76324: ldrsw   x9, [x10]                                  
02d76328: add     x8, x8, x9, lsl #4                         &626c000
02d7632c: add     x0, x8, #0x138                             &626c138
02d76330: ldp     x3, x2, [x0]                               
02d76334: mov     x0, x20                                    
02d76338: mov     x1, x19                                    
02d7633c: ldp     x20, x19, [sp, #0x10]                      
02d76340: ldp     x30, x21, [sp], #0x20                      
02d76344: br      x3                                         
## CompleteMission(int missionId) -> void
---- DailyMission.DailyMissionManager::CompleteMission 0x2d76348
02d76348: ret                                                
## ProgressMission(int missionId) -> void
---- DailyMission.DailyMissionManager::ProgressMission 0x2d7634c
02d7634c: ret                                                
## .ctor() -> void
---- DailyMission.DailyMissionManager::.ctor 0x2d76350
02d76350: stp     x30, x21, [sp, #-0x20]!                    
02d76354: stp     x20, x19, [sp, #0x10]                      
02d76358: adrp    x20, #0x6630000                            
02d7635c: adrp    x21, #0x626c000                            
02d76360: mov     x19, x0                                    
02d76364: ldrb    w8, [x20, #0x3d8]                          
02d76368: ldr     x21, [x21, #0x830]                         MS:MonoSingleton`1::.ctor
02d7636c: tbnz    w8, #0, #0x2d76384                         
02d76370: adrp    x0, #0x626c000                             
02d76374: ldr     x0, [x0, #0x830]                           MS:MonoSingleton`1::.ctor
02d76378: bl      #0x2b70db0                                 fn_2b70db0
02d7637c: mov     w8, #1                                     
02d76380: strb    w8, [x20, #0x3d8]                          
02d76384: mov     x0, x19                                    
02d76388: ldp     x20, x19, [sp, #0x10]                      
02d7638c: ldr     x1, [x21]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d76390: ldp     x30, x21, [sp], #0x20                      
02d76394: b       #0x3769e18                                 
