#### CLASS NativeInter/<>c__DisplayClass2_0 parent= object
#   field actionClose                    System.Action                                      off=0x10 attr=6 
#   field <>4__this                      NativeInter                                        off=0x18 attr=6 
## .ctor() -> void
---- NativeInter/<>c__DisplayClass2_0::.ctor 0x2c9b318
02c9b318: mov     x1, xzr                                    
02c9b31c: b       #0x4e53e9c                                 System.Object::.ctor
## <ShowAd>b__0() -> void
---- NativeInter/<>c__DisplayClass2_0::<ShowAd>b__0 0x2c9b474
02c9b474: str     x30, [sp, #-0x20]!                         
02c9b478: stp     x20, x19, [sp, #0x10]                      
02c9b47c: adrp    x20, #0x662f000                            
02c9b480: mov     x19, x0                                    
02c9b484: ldrb    w8, [x20, #0xa3b]                          
02c9b488: tbnz    w8, #0, #0x2c9b4a0                         
02c9b48c: adrp    x0, #0x6263000                             
02c9b490: ldr     x0, [x0, #0x918]                           T:UnityEngine.Object
02c9b494: bl      #0x2b70db0                                 fn_2b70db0
02c9b498: mov     w8, #1                                     
02c9b49c: strb    w8, [x20, #0xa3b]                          
02c9b4a0: ldr     x8, [x19, #0x10]                           .actionClose
02c9b4a4: cbz     x8, #0x2c9b4fc                             
02c9b4a8: ldr     x9, [x8, #0x18]                            
02c9b4ac: ldr     x0, [x8, #0x40]                            
02c9b4b0: ldr     x1, [x8, #0x28]                            
02c9b4b4: blr     x9                                         
02c9b4b8: ldr     x0, [x19, #0x18]                           .<>4__this
02c9b4bc: cbz     x0, #0x2c9b4fc                             
02c9b4c0: adrp    x19, #0x6263000                            
02c9b4c4: mov     x1, xzr                                    
02c9b4c8: ldr     x19, [x19, #0x918]                         T:UnityEngine.Object
02c9b4cc: bl      #0x5b339ec                                 UnityEngine.Component::get_gameObject
02c9b4d0: ldr     x8, [x19]                                  &2c5bbd4(=a9bd7bfdd503233f)
02c9b4d4: mov     x19, x0                                    
02c9b4d8: ldr     w9, [x8, #0xe4]                            
02c9b4dc: cbnz    w9, #0x2c9b4e8                             
02c9b4e0: mov     x0, x8                                     
02c9b4e4: bl      #0x2b70f30                                 fn_2b70f30
02c9b4e8: mov     x0, x19                                    
02c9b4ec: ldp     x20, x19, [sp, #0x10]                      
02c9b4f0: mov     x1, xzr                                    
02c9b4f4: ldr     x30, [sp], #0x20                           
02c9b4f8: b       #0x5b3ca38                                 UnityEngine.Object::Destroy
02c9b4fc: bl      #0x2b7105c                                 fn_2b7105c
#### CLASS NativeInter parent= UnityEngine.MonoBehaviour
#   field _nativeAdBase                  NativeAdBase                                       off=0x20 attr=1 SerializeField
#   field _nativeInterTimeCount          NativeInterTimeCount                               off=0x28 attr=1 SerializeField
## ShowAd(string placement, System.Action actionClose) -> void
---- NativeInter::ShowAd 0x2c9b218
02c9b218: stp     x30, x23, [sp, #-0x30]!                    
02c9b21c: stp     x22, x21, [sp, #0x10]                      
02c9b220: stp     x20, x19, [sp, #0x20]                      
02c9b224: adrp    x21, #0x662f000                            
02c9b228: adrp    x23, #0x6265000                            
02c9b22c: mov     x22, x2                                    
02c9b230: ldrb    w8, [x21, #0xa3a]                          
02c9b234: ldr     x23, [x23, #0xa60]                         T:NativeInter/<>c__DisplayClass2_0
02c9b238: mov     x20, x1                                    
02c9b23c: mov     x19, x0                                    
02c9b240: tbnz    w8, #0, #0x2c9b270                         
02c9b244: adrp    x0, #0x6264000                             
02c9b248: ldr     x0, [x0, #0xf90]                           T:System.Action
02c9b24c: bl      #0x2b70db0                                 fn_2b70db0
02c9b250: adrp    x0, #0x6265000                             
02c9b254: ldr     x0, [x0, #0xa68]                           M:NativeInter/<>c__DisplayClass2_0::<ShowAd>b__0
02c9b258: bl      #0x2b70db0                                 fn_2b70db0
02c9b25c: adrp    x0, #0x6265000                             
02c9b260: ldr     x0, [x0, #0xa60]                           T:NativeInter/<>c__DisplayClass2_0
02c9b264: bl      #0x2b70db0                                 fn_2b70db0
02c9b268: mov     w8, #1                                     
02c9b26c: strb    w8, [x21, #0xa3a]                          
02c9b270: ldr     x0, [x23]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9b274: bl      #0x2b7104c                                 fn_2b7104c
02c9b278: mov     x1, xzr                                    
02c9b27c: mov     x21, x0                                    
02c9b280: bl      #0x4e53e9c                                 System.Object::.ctor
02c9b284: cbz     x21, #0x2c9b314                            
02c9b288: mov     x0, x21                                    
02c9b28c: mov     x1, x22                                    
02c9b290: str     x22, [x0, #0x10]!                          
02c9b294: bl      #0x2b70d54                                 fn_2b70d54
02c9b298: mov     x0, x21                                    
02c9b29c: mov     x1, x19                                    
02c9b2a0: str     x19, [x0, #0x18]!                          
02c9b2a4: bl      #0x2b70d54                                 fn_2b70d54
02c9b2a8: ldr     x0, [x19, #0x20]                           ._nativeAdBase
02c9b2ac: cbz     x0, #0x2c9b314                             
02c9b2b0: mov     x1, x20                                    
02c9b2b4: mov     w2, #8                                     
02c9b2b8: bl      #0x2c96b28                                 NativeAdBase::ShowAd
02c9b2bc: ldr     x0, [x19, #0x28]                           ._nativeInterTimeCount
02c9b2c0: cbz     x0, #0x2c9b314                             
02c9b2c4: adrp    x20, #0x6264000                            
02c9b2c8: adrp    x22, #0x6265000                            
02c9b2cc: ldr     x20, [x20, #0xf90]                         T:System.Action
02c9b2d0: ldr     x22, [x22, #0xa68]                         M:NativeInter/<>c__DisplayClass2_0::<ShowAd>b__0
02c9b2d4: bl      #0x2c9b320                                 NativeInterTimeCount::ShowTime
02c9b2d8: ldr     x0, [x20]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c9b2dc: ldr     x19, [x19, #0x28]                          ._nativeInterTimeCount
02c9b2e0: bl      #0x2b7104c                                 fn_2b7104c
02c9b2e4: ldr     x2, [x22]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9b2e8: mov     x1, x21                                    
02c9b2ec: mov     x3, xzr                                    
02c9b2f0: mov     x20, x0                                    
02c9b2f4: bl      #0x4d8ddbc                                 System.Action::.ctor
02c9b2f8: cbz     x19, #0x2c9b314                            
02c9b2fc: mov     x0, x19                                    
02c9b300: mov     x1, x20                                    
02c9b304: ldp     x20, x19, [sp, #0x20]                      
02c9b308: ldp     x22, x21, [sp, #0x10]                      
02c9b30c: ldp     x30, x23, [sp], #0x30                      
02c9b310: b       #0x2c9b3d0                                 NativeInterTimeCount::add_OnClose
02c9b314: bl      #0x2b7105c                                 fn_2b7105c
## .ctor() -> void
---- NativeInter::.ctor 0x2c9b46c
02c9b46c: mov     x1, xzr                                    
02c9b470: b       #0x5b397b0                                 UnityEngine.MonoBehaviour::.ctor
