#### CLASS ProfilePanel/<>c__DisplayClass20_0 parent= object
#   field onCompleted                    System.Action                                      off=0x10 attr=6 
## .ctor() -> void
---- ProfilePanel/<>c__DisplayClass20_0::.ctor 0x2cde2ac
02cde2ac: mov     x1, xzr                                    
02cde2b0: b       #0x4e53e9c                                 System.Object::.ctor
## <OnChangeAnchorPositionY>b__0() -> void
---- ProfilePanel/<>c__DisplayClass20_0::<OnChangeAnchorPositionY>b__0 0x2cde3a8
02cde3a8: ldr     x8, [x0, #0x10]                            .onCompleted
02cde3ac: cbz     x8, #0x2cde3c0                             
02cde3b0: ldr     x0, [x8, #0x40]                            
02cde3b4: ldr     x1, [x8, #0x28]                            
02cde3b8: ldr     x2, [x8, #0x18]                            
02cde3bc: br      x2                                         
02cde3c0: ret                                                
#### CLASS ProfilePanel parent= UnityEngine.MonoBehaviour
#   field _avatarImage                   UnityEngine.UI.Image                               off=0x20 attr=1 SerializeField
#   field _nameText                      TMPro.TextMeshProUGUI                              off=0x28 attr=1 SerializeField
#   field _levelText                     TMPro.TextMeshProUGUI                              off=0x30 attr=1 SerializeField
#   field _experienceText                TMPro.TextMeshProUGUI                              off=0x38 attr=1 SerializeField
#   field _levelProgressImage            UnityEngine.UI.Image                               off=0x40 attr=1 SerializeField
#   field _changeNameButton              UnityEngine.UI.Button                              off=0x48 attr=1 SerializeField
#   field _openAction                    System.Action                                      off=0x50 attr=1 
#   field _closeAction                   System.Action                                      off=0x58 attr=1 
#   field _uiManager                     UIManager                                          off=0x60 attr=1 
#   field _rectTransform                 UnityEngine.RectTransform                          off=0x68 attr=1 
## OnInit(UIManager uiManager) -> void
---- ProfilePanel::OnInit 0x2cddc38
02cddc38: stp     x30, x25, [sp, #-0x40]!                    
02cddc3c: stp     x24, x23, [sp, #0x10]                      
02cddc40: stp     x22, x21, [sp, #0x20]                      
02cddc44: stp     x20, x19, [sp, #0x30]                      
02cddc48: adrp    x21, #0x662f000                            
02cddc4c: mov     x20, x1                                    
02cddc50: mov     x19, x0                                    
02cddc54: ldrb    w8, [x21, #0xd86]                          
02cddc58: tbnz    w8, #0, #0x2cddcac                         
02cddc5c: adrp    x0, #0x6264000                             
02cddc60: ldr     x0, [x0, #0xf90]                           T:System.Action
02cddc64: bl      #0x2b70db0                                 fn_2b70db0
02cddc68: adrp    x0, #0x6264000                             
02cddc6c: ldr     x0, [x0, #0xd88]                           MS:UnityEngine.Component::GetComponent
02cddc70: bl      #0x2b70db0                                 fn_2b70db0
02cddc74: adrp    x0, #0x6266000                             
02cddc78: ldr     x0, [x0, #0x9f0]                           T:Assets.SimpleLocalization.Scripts.LocalizationManager
02cddc7c: bl      #0x2b70db0                                 fn_2b70db0
02cddc80: adrp    x0, #0x6267000                             
02cddc84: ldr     x0, [x0, #0xd60]                           M:ProfilePanel::<OnInit>b__10_0
02cddc88: bl      #0x2b70db0                                 fn_2b70db0
02cddc8c: adrp    x0, #0x6267000                             
02cddc90: ldr     x0, [x0, #0xd68]                           M:ProfilePanel::UpdateLevelText
02cddc94: bl      #0x2b70db0                                 fn_2b70db0
02cddc98: adrp    x0, #0x6265000                             
02cddc9c: ldr     x0, [x0, #0x3f0]                           T:UnityEngine.Events.UnityAction
02cddca0: bl      #0x2b70db0                                 fn_2b70db0
02cddca4: mov     w8, #1                                     
02cddca8: strb    w8, [x21, #0xd86]                          
02cddcac: mov     x21, x19                                   
02cddcb0: mov     x1, x20                                    
02cddcb4: str     x20, [x21, #0x60]!                         ._uiManager
02cddcb8: mov     x0, x21                                    
02cddcbc: bl      #0x2b70d54                                 fn_2b70d54
02cddcc0: ldur    x8, [x21, #-0x18]                          
02cddcc4: cbz     x8, #0x2cdddb8                             
02cddcc8: adrp    x9, #0x6265000                             
02cddccc: adrp    x21, #0x6267000                            
02cddcd0: ldr     x9, [x9, #0x3f0]                           T:UnityEngine.Events.UnityAction
02cddcd4: ldr     x21, [x21, #0xd60]                         M:ProfilePanel::<OnInit>b__10_0
02cddcd8: ldr     x20, [x8, #0x100]                          
02cddcdc: ldr     x0, [x9]                                   M:AdsManager::<OnApplicationPause>b__26_0
02cddce0: bl      #0x2b7104c                                 fn_2b7104c
02cddce4: ldr     x2, [x21]                                  S:'didu'
02cddce8: mov     x1, x19                                    
02cddcec: mov     x3, xzr                                    
02cddcf0: mov     x21, x0                                    
02cddcf4: bl      #0x5b4cf98                                 UnityEngine.Events.UnityAction::.ctor
02cddcf8: cbz     x20, #0x2cdddb8                            
02cddcfc: adrp    x24, #0x6264000                            
02cddd00: adrp    x23, #0x6264000                            
02cddd04: adrp    x22, #0x6267000                            
02cddd08: adrp    x25, #0x6266000                            
02cddd0c: ldr     x24, [x24, #0xd88]                         MS:UnityEngine.Component::GetComponent
02cddd10: ldr     x23, [x23, #0xf90]                         T:System.Action
02cddd14: ldr     x22, [x22, #0xd68]                         M:ProfilePanel::UpdateLevelText
02cddd18: ldr     x25, [x25, #0x9f0]                         T:Assets.SimpleLocalization.Scripts.LocalizationManager
02cddd1c: mov     x0, x20                                    
02cddd20: mov     x1, x21                                    
02cddd24: mov     x2, xzr                                    
02cddd28: bl      #0x5b4d0ac                                 UnityEngine.Events.UnityEvent::AddListener
02cddd2c: ldr     x1, [x24]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02cddd30: mov     x0, x19                                    
02cddd34: bl      #0x3140c84                                 fn_3140c84
02cddd38: mov     x1, x0                                     
02cddd3c: mov     x0, x19                                    
02cddd40: str     x1, [x0, #0x68]!                           ._rectTransform
02cddd44: bl      #0x2b70d54                                 fn_2b70d54
02cddd48: ldr     x0, [x23]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02cddd4c: bl      #0x2b7104c                                 fn_2b7104c
02cddd50: ldr     x2, [x22]                                  S:'didu'
02cddd54: mov     x1, x19                                    
02cddd58: mov     x3, xzr                                    
02cddd5c: mov     x20, x0                                    
02cddd60: bl      #0x4d8ddbc                                 System.Action::.ctor
02cddd64: ldr     x0, [x25]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cddd68: ldr     w8, [x0, #0xe4]                            [62650e4]=0 f=0,0
02cddd6c: cbnz    w8, #0x2cddd74                             
02cddd70: bl      #0x2b70f30                                 fn_2b70f30
02cddd74: mov     x0, x20                                    
02cddd78: mov     x1, xzr                                    
02cddd7c: bl      #0x2d7b144                                 Assets.SimpleLocalization.Scripts.LocalizationManager::remove_OnLocalizationChanged
02cddd80: ldr     x0, [x23]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02cddd84: bl      #0x2b7104c                                 fn_2b7104c
02cddd88: ldr     x2, [x22]                                  S:'didu'
02cddd8c: mov     x1, x19                                    
02cddd90: mov     x3, xzr                                    
02cddd94: mov     x20, x0                                    
02cddd98: bl      #0x4d8ddbc                                 System.Action::.ctor
02cddd9c: mov     x0, x20                                    
02cddda0: ldp     x20, x19, [sp, #0x30]                      
02cddda4: ldp     x22, x21, [sp, #0x20]                      
02cddda8: mov     x1, xzr                                    
02cdddac: ldp     x24, x23, [sp, #0x10]                      
02cdddb0: ldp     x30, x25, [sp], #0x40                      
02cdddb4: b       #0x2d7ad04                                 Assets.SimpleLocalization.Scripts.LocalizationManager::add_OnLocalizationChanged
02cdddb8: bl      #0x2b7105c                                 fn_2b7105c
## OnShow() -> void
---- ProfilePanel::OnShow 0x2cdddbc
02cdddbc: ret                                                
## OnHide() -> void
---- ProfilePanel::OnHide 0x2cdddc0
02cdddc0: ret                                                
## RegisterOpenAction(System.Action action) -> ProfilePanel
---- ProfilePanel::RegisterOpenAction 0x2cdddc4
02cdddc4: stp     x30, x19, [sp, #-0x10]!                    
02cdddc8: mov     x19, x0                                    
02cdddcc: str     x1, [x0, #0x50]!                           ._openAction
02cdddd0: bl      #0x2b70d54                                 fn_2b70d54
02cdddd4: mov     x0, x19                                    
02cdddd8: ldp     x30, x19, [sp], #0x10                      
02cddddc: ret                                                
## RegisterCloseAction(System.Action action) -> ProfilePanel
---- ProfilePanel::RegisterCloseAction 0x2cddde0
02cddde0: stp     x30, x19, [sp, #-0x10]!                    
02cddde4: mov     x19, x0                                    
02cddde8: str     x1, [x0, #0x58]!                           ._closeAction
02cdddec: bl      #0x2b70d54                                 fn_2b70d54
02cdddf0: mov     x0, x19                                    
02cdddf4: ldp     x30, x19, [sp], #0x10                      
02cdddf8: ret                                                
## UpdateProgress() -> ProfilePanel
---- ProfilePanel::UpdateProgress 0x2cdddfc
02cdddfc: sub     sp, sp, #0x50                              
02cdde00: str     d8, [sp, #0x10]                            
02cdde04: str     x30, [sp, #0x18]                           
02cdde08: stp     x24, x23, [sp, #0x20]                      
02cdde0c: stp     x22, x21, [sp, #0x30]                      
02cdde10: stp     x20, x19, [sp, #0x40]                      
02cdde14: adrp    x20, #0x662f000                            
02cdde18: adrp    x21, #0x6267000                            
02cdde1c: mov     x19, x0                                    
02cdde20: ldrb    w8, [x20, #0xd87]                          
02cdde24: ldr     x21, [x21, #0xd20]                         MS:MonoSingleton`1::get_Instance
02cdde28: tbnz    w8, #0, #0x2cdde58                         
02cdde2c: adrp    x0, #0x6266000                             
02cdde30: ldr     x0, [x0, #0x5e0]                           T:GameConfig
02cdde34: bl      #0x2b70db0                                 fn_2b70db0
02cdde38: adrp    x0, #0x6267000                             
02cdde3c: ldr     x0, [x0, #0xd20]                           MS:MonoSingleton`1::get_Instance
02cdde40: bl      #0x2b70db0                                 fn_2b70db0
02cdde44: adrp    x0, #0x6267000                             
02cdde48: ldr     x0, [x0, #0xd70]                           S:'{0}/{1}'
02cdde4c: bl      #0x2b70db0                                 fn_2b70db0
02cdde50: mov     w8, #1                                     
02cdde54: strb    w8, [x20, #0xd87]                          
02cdde58: ldr     x0, [x21]                                  S:'didu'
02cdde5c: bl      #0x3769600                                 fn_3769600
02cdde60: cbz     x0, #0x2cddf78                             
02cdde64: ldr     x8, [x0, #0x20]                            T:System.IO.FileInfo ._avatarImage
02cdde68: cbz     x8, #0x2cddf78                             
02cdde6c: adrp    x20, #0x6266000                            
02cdde70: ldr     x20, [x20, #0x5e0]                         T:GameConfig
02cdde74: ldr     s8, [x8, #0x1c]                            
02cdde78: ldr     w21, [x8, #0x18]                           
02cdde7c: ldr     x0, [x20]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cdde80: ldr     w9, [x0, #0xe4]                            [62670e4]=0 f=0,0
02cdde84: cbnz    w9, #0x2cdde8c                             
02cdde88: bl      #0x2b70f30                                 fn_2b70f30
02cdde8c: ldr     x0, [x19, #0x40]                           ._levelProgressImage
02cdde90: cbz     x0, #0x2cddf78                             
02cdde94: ldr     x8, [x20]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cdde98: adrp    x22, #0x6267000                            
02cdde9c: mov     x1, xzr                                    
02cddea0: ldr     x8, [x8, #0xb8]                            
02cddea4: ldr     w8, [x8, #0x8c]                            
02cddea8: ldr     x22, [x22, #0xd70]                         S:'{0}/{1}'
02cddeac: mul     w23, w8, w21                               
02cddeb0: scvtf   s0, w23                                    
02cddeb4: fdiv    s0, s8, s0                                 
02cddeb8: bl      #0x5c53138                                 UnityEngine.UI.Image::set_fillAmount
02cddebc: cbnz    w23, #0x2cddedc                            
02cddec0: ldr     x0, [x20]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cddec4: ldr     w8, [x0, #0xe4]                            [62670e4]=0 f=0,0
02cddec8: cbnz    w8, #0x2cdded4                             
02cddecc: bl      #0x2b70f30                                 fn_2b70f30
02cdded0: ldr     x0, [x20]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cdded4: ldr     x8, [x0, #0xb8]                            M:Framework.SceneUtils/<CRUnloadSceneAsync>d__2::System.Collections.IEnumerator.Reset
02cdded8: ldr     w23, [x8, #0x8c]                           
02cddedc: mov     w8, #0x7f800000                            
02cddee0: fcvtzs  w9, s8                                     
02cddee4: adrp    x24, #0x6263000                            
02cddee8: fmov    s0, w8                                     
02cddeec: ldr     x24, [x24, #0x970]                         &6645c70(=0)
02cddef0: mov     w8, #-0xffffffff80000000                   
02cddef4: ldr     x20, [x19, #0x38]                          ._experienceText
02cddef8: add     x1, sp, #0xc                               
02cddefc: ldr     x0, [x24, #0x48]                           &6263098(=0)
02cddf00: fcmp    s8, s0                                     
02cddf04: csel    w8, w8, w9, eq                             
02cddf08: str     w8, [sp, #0xc]                             
02cddf0c: bl      #0x2b70f38                                 fn_2b70f38
02cddf10: mov     x21, x0                                    
02cddf14: ldr     x0, [x24, #0x48]                           &6263098(=0)
02cddf18: add     x1, sp, #8                                 
02cddf1c: str     w23, [sp, #8]                              
02cddf20: bl      #0x2b70f38                                 fn_2b70f38
02cddf24: ldr     x8, [x22]                                  S:'didu'
02cddf28: mov     x2, x0                                     
02cddf2c: mov     x1, x21                                    
02cddf30: mov     x3, xzr                                    
02cddf34: mov     x0, x8                                     
02cddf38: bl      #0x4ca7720                                 System.String::Format
02cddf3c: cbz     x20, #0x2cddf78                            
02cddf40: ldr     x8, [x20]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cddf44: mov     x1, x0                                     
02cddf48: mov     x0, x20                                    
02cddf4c: ldr     x9, [x8, #0x558]                           
02cddf50: ldr     x2, [x8, #0x560]                           
02cddf54: blr     x9                                         
02cddf58: mov     x0, x19                                    
02cddf5c: ldp     x20, x19, [sp, #0x40]                      
02cddf60: ldp     x22, x21, [sp, #0x30]                      
02cddf64: ldr     x30, [sp, #0x18]                           
02cddf68: ldp     x24, x23, [sp, #0x20]                      
02cddf6c: ldr     d8, [sp, #0x10]                            
02cddf70: add     sp, sp, #0x50                              
02cddf74: ret                                                
02cddf78: bl      #0x2b7105c                                 fn_2b7105c
## UpdateAvatar() -> ProfilePanel
---- ProfilePanel::UpdateAvatar 0x2cddf7c
02cddf7c: stp     x30, x21, [sp, #-0x20]!                    
02cddf80: stp     x20, x19, [sp, #0x10]                      
02cddf84: adrp    x20, #0x662f000                            
02cddf88: adrp    x21, #0x6266000                            
02cddf8c: mov     x19, x0                                    
02cddf90: ldrb    w8, [x20, #0xd88]                          
02cddf94: ldr     x21, [x21, #0xac0]                         MS:MonoSingleton`1::get_Instance
02cddf98: tbnz    w8, #0, #0x2cddfb0                         
02cddf9c: adrp    x0, #0x6266000                             
02cddfa0: ldr     x0, [x0, #0xac0]                           MS:MonoSingleton`1::get_Instance
02cddfa4: bl      #0x2b70db0                                 fn_2b70db0
02cddfa8: mov     w8, #1                                     
02cddfac: strb    w8, [x20, #0xd88]                          
02cddfb0: ldr     x0, [x21]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cddfb4: ldr     x20, [x19, #0x20]                          ._avatarImage
02cddfb8: bl      #0x3769600                                 fn_3769600
02cddfbc: cbz     x0, #0x2cddfe4                             
02cddfc0: cbz     x20, #0x2cddfe4                            
02cddfc4: ldr     x1, [x0, #0x38]                            S:'native_collap_id' ._experienceText
02cddfc8: mov     x0, x20                                    
02cddfcc: mov     x2, xzr                                    
02cddfd0: bl      #0x5c45aa0                                 UnityEngine.UI.Image::set_sprite
02cddfd4: mov     x0, x19                                    
02cddfd8: ldp     x20, x19, [sp, #0x10]                      
02cddfdc: ldp     x30, x21, [sp], #0x20                      
02cddfe0: ret                                                
02cddfe4: bl      #0x2b7105c                                 fn_2b7105c
## UpdateLevelText() -> void
---- ProfilePanel::UpdateLevelText 0x2cddfe8
02cddfe8: b       #0x2cddfec                                 ProfilePanel::UpdateLevel
## UpdateLevel() -> ProfilePanel
---- ProfilePanel::UpdateLevel 0x2cddfec
02cddfec: str     x30, [sp, #-0x30]!                         
02cddff0: stp     x22, x21, [sp, #0x10]                      
02cddff4: stp     x20, x19, [sp, #0x20]                      
02cddff8: adrp    x20, #0x662f000                            
02cddffc: adrp    x21, #0x6266000                            
02cde000: mov     x19, x0                                    
02cde004: ldrb    w8, [x20, #0xd89]                          
02cde008: ldr     x21, [x21, #0x658]                         MS:MonoSingleton`1::get_Instance
02cde00c: tbnz    w8, #0, #0x2cde060                         
02cde010: adrp    x0, #0x6266000                             
02cde014: ldr     x0, [x0, #0x750]                           MS:DataManager::GetData
02cde018: bl      #0x2b70db0                                 fn_2b70db0
02cde01c: adrp    x0, #0x6266000                             
02cde020: ldr     x0, [x0, #0x9f0]                           T:Assets.SimpleLocalization.Scripts.LocalizationManager
02cde024: bl      #0x2b70db0                                 fn_2b70db0
02cde028: adrp    x0, #0x6267000                             
02cde02c: ldr     x0, [x0, #0xd20]                           MS:MonoSingleton`1::get_Instance
02cde030: bl      #0x2b70db0                                 fn_2b70db0
02cde034: adrp    x0, #0x6266000                             
02cde038: ldr     x0, [x0, #0x658]                           MS:MonoSingleton`1::get_Instance
02cde03c: bl      #0x2b70db0                                 fn_2b70db0
02cde040: adrp    x0, #0x6267000                             
02cde044: ldr     x0, [x0, #0xd78]                           S:'Level $'
02cde048: bl      #0x2b70db0                                 fn_2b70db0
02cde04c: adrp    x0, #0x6266000                             
02cde050: ldr     x0, [x0, #0xdc8]                           S:'$'
02cde054: bl      #0x2b70db0                                 fn_2b70db0
02cde058: mov     w8, #1                                     
02cde05c: strb    w8, [x20, #0xd89]                          
02cde060: ldr     x0, [x21]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cde064: bl      #0x3769600                                 fn_3769600
02cde068: cbz     x0, #0x2cde12c                             
02cde06c: adrp    x8, #0x6266000                             
02cde070: adrp    x20, #0x6266000                            
02cde074: adrp    x22, #0x6267000                            
02cde078: ldr     x8, [x8, #0x750]                           MS:DataManager::GetData
02cde07c: adrp    x21, #0x6267000                            
02cde080: ldr     x20, [x20, #0x9f0]                         T:Assets.SimpleLocalization.Scripts.LocalizationManager
02cde084: ldr     x22, [x22, #0xd78]                         S:'Level $'
02cde088: ldr     x21, [x21, #0xd20]                         MS:MonoSingleton`1::get_Instance
02cde08c: ldr     x1, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cde090: bl      #0x3168dd0                                 fn_3168dd0
02cde094: ldr     x0, [x20]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cde098: ldr     x20, [x19, #0x30]                          ._levelText
02cde09c: ldr     w8, [x0, #0xe4]                            [62660e4]=0 f=0,0
02cde0a0: cbnz    w8, #0x2cde0a8                             
02cde0a4: bl      #0x2b70f30                                 fn_2b70f30
02cde0a8: ldr     x0, [x22]                                  S:'didu'
02cde0ac: mov     x1, xzr                                    
02cde0b0: bl      #0x2d76794                                 Assets.SimpleLocalization.Scripts.LocalizationManager::Localize
02cde0b4: ldr     x8, [x21]                                  S:'didu'
02cde0b8: mov     x21, x0                                    
02cde0bc: mov     x0, x8                                     
02cde0c0: bl      #0x3769600                                 fn_3769600
02cde0c4: cbz     x0, #0x2cde12c                             
02cde0c8: ldr     x8, [x0, #0x20]                            S:'inter_ad_capping_time' ._avatarImage
02cde0cc: cbz     x8, #0x2cde12c                             
02cde0d0: add     x0, x8, #0x18                              &6266018
02cde0d4: mov     x1, xzr                                    
02cde0d8: bl      #0x4e0ea3c                                 System.Int32::ToString
02cde0dc: cbz     x21, #0x2cde12c                            
02cde0e0: adrp    x8, #0x6266000                             
02cde0e4: mov     x2, x0                                     
02cde0e8: mov     x0, x21                                    
02cde0ec: ldr     x8, [x8, #0xdc8]                           S:'$'
02cde0f0: mov     x3, xzr                                    
02cde0f4: ldr     x1, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cde0f8: bl      #0x4ca8ca8                                 System.String::Replace
02cde0fc: cbz     x20, #0x2cde12c                            
02cde100: ldr     x8, [x20]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cde104: mov     x1, x0                                     
02cde108: mov     x0, x20                                    
02cde10c: ldr     x9, [x8, #0x558]                           MS:NFramework.GoogleSheetConfigSO`1::.ctor
02cde110: ldr     x2, [x8, #0x560]                           MS:NFramework.GoogleSheetConfigSO`1::OpenSheet
02cde114: blr     x9                                         
02cde118: mov     x0, x19                                    
02cde11c: ldp     x20, x19, [sp, #0x20]                      
02cde120: ldp     x22, x21, [sp, #0x10]                      
02cde124: ldr     x30, [sp], #0x30                           
02cde128: ret                                                
02cde12c: bl      #0x2b7105c                                 fn_2b7105c
## UpdateName() -> ProfilePanel
---- ProfilePanel::UpdateName 0x2cdda80
02cdda80: stp     x30, x21, [sp, #-0x20]!                    
02cdda84: stp     x20, x19, [sp, #0x10]                      
02cdda88: adrp    x20, #0x662f000                            
02cdda8c: adrp    x21, #0x6267000                            
02cdda90: mov     x19, x0                                    
02cdda94: ldrb    w8, [x20, #0xd8a]                          
02cdda98: ldr     x21, [x21, #0xd20]                         MS:MonoSingleton`1::get_Instance
02cdda9c: tbnz    w8, #0, #0x2cddab4                         
02cddaa0: adrp    x0, #0x6267000                             
02cddaa4: ldr     x0, [x0, #0xd20]                           MS:MonoSingleton`1::get_Instance
02cddaa8: bl      #0x2b70db0                                 fn_2b70db0
02cddaac: mov     w8, #1                                     
02cddab0: strb    w8, [x20, #0xd8a]                          
02cddab4: ldr     x0, [x21]                                  S:'didu'
02cddab8: ldr     x20, [x19, #0x28]                          ._nameText
02cddabc: bl      #0x3769600                                 fn_3769600
02cddac0: cbz     x0, #0x2cddaf8                             
02cddac4: ldr     x8, [x0, #0x20]                            T:System.IO.FileInfo ._avatarImage
02cddac8: cbz     x8, #0x2cddaf8                             
02cddacc: cbz     x20, #0x2cddaf8                            
02cddad0: ldr     x9, [x20]                                  &2b706c4(=eb01011ff9400808)
02cddad4: ldr     x1, [x8, #0x10]                            
02cddad8: mov     x0, x20                                    
02cddadc: ldr     x8, [x9, #0x558]                           
02cddae0: ldr     x2, [x9, #0x560]                           
02cddae4: blr     x8                                         
02cddae8: mov     x0, x19                                    
02cddaec: ldp     x20, x19, [sp, #0x10]                      
02cddaf0: ldp     x30, x21, [sp], #0x20                      
02cddaf4: ret                                                
02cddaf8: bl      #0x2b7105c                                 fn_2b7105c
## OnChangeAnchorPositionY(float delay, float duration, int anchorPosY, DG.Tweening.Ease ease, System.Action onCompleted) -> void
---- ProfilePanel::OnChangeAnchorPositionY 0x2cde130
02cde130: stp     d9, d8, [sp, #-0x70]!                      
02cde134: str     x30, [sp, #0x10]                           
02cde138: stp     x28, x27, [sp, #0x20]                      
02cde13c: stp     x26, x25, [sp, #0x30]                      
02cde140: stp     x24, x23, [sp, #0x40]                      
02cde144: stp     x22, x21, [sp, #0x50]                      
02cde148: stp     x20, x19, [sp, #0x60]                      
02cde14c: fmov    s9, s1                                     
02cde150: fmov    s8, s0                                     
02cde154: adrp    x22, #0x662f000                            
02cde158: adrp    x24, #0x6267000                            
02cde15c: ldrb    w8, [x22, #0xd8b]                          
02cde160: mov     x23, x3                                    
02cde164: ldr     x24, [x24, #0xd80]                         T:ProfilePanel/<>c__DisplayClass20_0
02cde168: mov     w19, w2                                    
02cde16c: mov     w20, w1                                    
02cde170: mov     x21, x0                                    
02cde174: tbnz    w8, #0, #0x2cde1c8                         
02cde178: adrp    x0, #0x6264000                             
02cde17c: ldr     x0, [x0, #0xe8]                            T:DG.Tweening.TweenCallback
02cde180: bl      #0x2b70db0                                 fn_2b70db0
02cde184: adrp    x0, #0x6266000                             
02cde188: ldr     x0, [x0, #0xa08]                           MS:DG.Tweening.TweenSettingsExtensions::OnComplete
02cde18c: bl      #0x2b70db0                                 fn_2b70db0
02cde190: adrp    x0, #0x6266000                             
02cde194: ldr     x0, [x0, #0xa10]                           MS:DG.Tweening.TweenSettingsExtensions::SetDelay
02cde198: bl      #0x2b70db0                                 fn_2b70db0
02cde19c: adrp    x0, #0x6266000                             
02cde1a0: ldr     x0, [x0, #0xa18]                           MS:DG.Tweening.TweenSettingsExtensions::SetEase
02cde1a4: bl      #0x2b70db0                                 fn_2b70db0
02cde1a8: adrp    x0, #0x6267000                             
02cde1ac: ldr     x0, [x0, #0xd88]                           M:ProfilePanel/<>c__DisplayClass20_0::<OnChangeAnchorPositionY>b__0
02cde1b0: bl      #0x2b70db0                                 fn_2b70db0
02cde1b4: adrp    x0, #0x6267000                             
02cde1b8: ldr     x0, [x0, #0xd80]                           T:ProfilePanel/<>c__DisplayClass20_0
02cde1bc: bl      #0x2b70db0                                 fn_2b70db0
02cde1c0: mov     w8, #1                                     
02cde1c4: strb    w8, [x22, #0xd8b]                          
02cde1c8: ldr     x0, [x24]                                  S:'didu'
02cde1cc: bl      #0x2b7104c                                 fn_2b7104c
02cde1d0: mov     x1, xzr                                    
02cde1d4: mov     x22, x0                                    
02cde1d8: bl      #0x4e53e9c                                 System.Object::.ctor
02cde1dc: cbz     x22, #0x2cde2a8                            
02cde1e0: adrp    x25, #0x6266000                            
02cde1e4: adrp    x26, #0x6266000                            
02cde1e8: adrp    x27, #0x6264000                            
02cde1ec: adrp    x28, #0x6267000                            
02cde1f0: adrp    x24, #0x6266000                            
02cde1f4: ldr     x25, [x25, #0xa10]                         MS:DG.Tweening.TweenSettingsExtensions::SetDelay
02cde1f8: ldr     x26, [x26, #0xa18]                         MS:DG.Tweening.TweenSettingsExtensions::SetEase
02cde1fc: ldr     x27, [x27, #0xe8]                          T:DG.Tweening.TweenCallback
02cde200: ldr     x28, [x28, #0xd88]                         M:ProfilePanel/<>c__DisplayClass20_0::<OnChangeAnchorPositionY>b__0
02cde204: ldr     x24, [x24, #0xa08]                         MS:DG.Tweening.TweenSettingsExtensions::OnComplete
02cde208: mov     x0, x22                                    
02cde20c: mov     x1, x23                                    
02cde210: str     x23, [x0, #0x10]!                          
02cde214: bl      #0x2b70d54                                 fn_2b70d54
02cde218: ldr     x0, [x21, #0x68]                           ._rectTransform
02cde21c: mov     w1, wzr                                    
02cde220: mov     x2, xzr                                    
02cde224: bl      #0x2d9d5d0                                 DG.Tweening.ShortcutExtensions::DOKill
02cde228: scvtf   s0, w20                                    
02cde22c: fmov    s1, s9                                     
02cde230: ldr     x0, [x21, #0x68]                           ._rectTransform
02cde234: mov     w1, wzr                                    
02cde238: mov     x2, xzr                                    
02cde23c: bl      #0x2c79c1c                                 DG.Tweening.DOTweenModuleUI::DOAnchorPosY
02cde240: fmov    s0, s8                                     
02cde244: ldr     x1, [x25]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cde248: bl      #0x336f7fc                                 fn_336f7fc
02cde24c: ldr     x2, [x26]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cde250: mov     w1, w19                                    
02cde254: bl      #0x336fa0c                                 fn_336fa0c
02cde258: ldr     x8, [x27]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02cde25c: mov     x19, x0                                    
02cde260: mov     x0, x8                                     
02cde264: bl      #0x2b7104c                                 fn_2b7104c
02cde268: ldr     x2, [x28]                                  S:'didu'
02cde26c: mov     x1, x22                                    
02cde270: mov     x3, xzr                                    
02cde274: mov     x20, x0                                    
02cde278: bl      #0x2d89dc4                                 DG.Tweening.TweenCallback::.ctor
02cde27c: ldr     x2, [x24]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cde280: mov     x0, x19                                    
02cde284: mov     x1, x20                                    
02cde288: ldp     x20, x19, [sp, #0x60]                      
02cde28c: ldr     x30, [sp, #0x10]                           
02cde290: ldp     x22, x21, [sp, #0x50]                      
02cde294: ldp     x24, x23, [sp, #0x40]                      
02cde298: ldp     x26, x25, [sp, #0x30]                      
02cde29c: ldp     x28, x27, [sp, #0x20]                      
02cde2a0: ldp     d9, d8, [sp], #0x70                        
02cde2a4: b       #0x336f26c                                 
02cde2a8: bl      #0x2b7105c                                 fn_2b7105c
## .ctor() -> void
---- ProfilePanel::.ctor 0x2cde2b4
02cde2b4: mov     x1, xzr                                    
02cde2b8: b       #0x5b397b0                                 UnityEngine.MonoBehaviour::.ctor
## <OnInit>b__10_0() -> void
---- ProfilePanel::<OnInit>b__10_0 0x2cde2bc
02cde2bc: stp     x30, x21, [sp, #-0x20]!                    
02cde2c0: stp     x20, x19, [sp, #0x10]                      
02cde2c4: adrp    x20, #0x662f000                            
02cde2c8: mov     x19, x0                                    
02cde2cc: ldrb    w8, [x20, #0xd8c]                          
02cde2d0: tbnz    w8, #0, #0x2cde300                         
02cde2d4: adrp    x0, #0x6264000                             
02cde2d8: ldr     x0, [x0, #0xf90]                           T:System.Action
02cde2dc: bl      #0x2b70db0                                 fn_2b70db0
02cde2e0: adrp    x0, #0x6267000                             
02cde2e4: ldr     x0, [x0, #0xd90]                           M:ProfilePanel::<OnInit>b__10_1
02cde2e8: bl      #0x2b70db0                                 fn_2b70db0
02cde2ec: adrp    x0, #0x6267000                             
02cde2f0: ldr     x0, [x0, #0xd98]                           MS:UIManager::ShowPopup
02cde2f4: bl      #0x2b70db0                                 fn_2b70db0
02cde2f8: mov     w8, #1                                     
02cde2fc: strb    w8, [x20, #0xd8c]                          
02cde300: mov     x0, xzr                                    
02cde304: bl      #0x2d6ff04                                 Framework.AudioHelper::PlayClickSound
02cde308: ldr     x8, [x19, #0x50]                           ._openAction
02cde30c: cbz     x8, #0x2cde320                             
02cde310: ldr     x9, [x8, #0x18]                            
02cde314: ldr     x0, [x8, #0x40]                            
02cde318: ldr     x1, [x8, #0x28]                            
02cde31c: blr     x9                                         
02cde320: ldr     x0, [x19, #0x60]                           ._uiManager
02cde324: cbz     x0, #0x2cde388                             
02cde328: adrp    x8, #0x6267000                             
02cde32c: adrp    x20, #0x6264000                            
02cde330: adrp    x21, #0x6267000                            
02cde334: ldr     x8, [x8, #0xd98]                           MS:UIManager::ShowPopup
02cde338: ldr     x20, [x20, #0xf90]                         T:System.Action
02cde33c: ldr     x21, [x21, #0xd90]                         M:ProfilePanel::<OnInit>b__10_1
02cde340: ldr     x1, [x8]                                   S:'didu'
02cde344: bl      #0x33fbfac                                 fn_33fbfac
02cde348: ldr     x8, [x20]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02cde34c: mov     x20, x0                                    
02cde350: mov     x0, x8                                     
02cde354: bl      #0x2b7104c                                 fn_2b7104c
02cde358: ldr     x2, [x21]                                  S:'didu'
02cde35c: mov     x1, x19                                    
02cde360: mov     x3, xzr                                    
02cde364: mov     x21, x0                                    
02cde368: bl      #0x4d8ddbc                                 System.Action::.ctor
02cde36c: cbz     x20, #0x2cde388                            
02cde370: str     x21, [x20, #0x80]!                         
02cde374: mov     x0, x20                                    
02cde378: ldp     x20, x19, [sp, #0x10]                      
02cde37c: mov     x1, x21                                    
02cde380: ldp     x30, x21, [sp], #0x20                      
02cde384: b       #0x2b70d54                                 
02cde388: bl      #0x2b7105c                                 fn_2b7105c
## <OnInit>b__10_1() -> void
---- ProfilePanel::<OnInit>b__10_1 0x2cde38c
02cde38c: ldr     x8, [x0, #0x58]                            ._closeAction
02cde390: cbz     x8, #0x2cde3a4                             
02cde394: ldr     x0, [x8, #0x40]                            
02cde398: ldr     x1, [x8, #0x28]                            
02cde39c: ldr     x2, [x8, #0x18]                            
02cde3a0: br      x2                                         
02cde3a4: ret                                                
