#### CLASS LoadingControl/<>c__DisplayClass9_0 parent= object
#   field <>4__this                      LoadingControl                                     off=0x10 attr=6 
#   field consentRequestComplete         bool                                               off=0x18 attr=6 
## .ctor() -> void
---- LoadingControl/<>c__DisplayClass9_0::.ctor 0x2cd6cf8
02cd6cf8: mov     x1, xzr                                    
02cd6cfc: b       #0x4e53e9c                                 System.Object::.ctor
## <IELoadScene>b__0(float value) -> void
---- LoadingControl/<>c__DisplayClass9_0::<IELoadScene>b__0 0x2cd6d00
02cd6d00: sub     sp, sp, #0x30                              
02cd6d04: str     d8, [sp, #0x10]                            
02cd6d08: str     x30, [sp, #0x18]                           
02cd6d0c: stp     x20, x19, [sp, #0x20]                      
02cd6d10: fmov    s8, s0                                     
02cd6d14: adrp    x20, #0x662f000                            
02cd6d18: mov     x19, x0                                    
02cd6d1c: ldrb    w8, [x20, #0xd31]                          
02cd6d20: tbnz    w8, #0, #0x2cd6d38                         
02cd6d24: adrp    x0, #0x6267000                             
02cd6d28: ldr     x0, [x0, #0x960]                           S:'Loading {0}%'
02cd6d2c: bl      #0x2b70db0                                 fn_2b70db0
02cd6d30: mov     w8, #1                                     
02cd6d34: strb    w8, [x20, #0xd31]                          
02cd6d38: ldr     x8, [x19, #0x10]                           .<>4__this
02cd6d3c: cbz     x8, #0x2cd6db8                             
02cd6d40: mov     w9, #0x7f800000                            
02cd6d44: fcvtzs  w10, s8                                    
02cd6d48: adrp    x20, #0x6267000                            
02cd6d4c: fmov    s0, w9                                     
02cd6d50: adrp    x9, #0x6263000                             
02cd6d54: mov     w11, #-0xffffffff80000000                  
02cd6d58: ldr     x9, [x9, #0x970]                           &6645c70(=0)
02cd6d5c: ldr     x20, [x20, #0x960]                         S:'Loading {0}%'
02cd6d60: ldr     x19, [x8, #0x28]                           
02cd6d64: add     x1, sp, #0xc                               
02cd6d68: fcmp    s8, s0                                     
02cd6d6c: ldr     x0, [x9, #0x48]                            &6263098(=0)
02cd6d70: csel    w8, w11, w10, eq                           
02cd6d74: str     w8, [sp, #0xc]                             
02cd6d78: bl      #0x2b70f38                                 fn_2b70f38
02cd6d7c: ldr     x8, [x20]                                  S:'didu'
02cd6d80: mov     x1, x0                                     
02cd6d84: mov     x2, xzr                                    
02cd6d88: mov     x0, x8                                     
02cd6d8c: bl      #0x4c9d0ec                                 System.String::Format
02cd6d90: cbz     x19, #0x2cd6db8                            
02cd6d94: mov     x1, x0                                     
02cd6d98: mov     x0, x19                                    
02cd6d9c: mov     x2, xzr                                    
02cd6da0: bl      #0x5a7b18c                                 TMPro.TMP_Text::SetText
02cd6da4: ldp     x20, x19, [sp, #0x20]                      
02cd6da8: ldr     x30, [sp, #0x18]                           
02cd6dac: ldr     d8, [sp, #0x10]                            
02cd6db0: add     sp, sp, #0x30                              
02cd6db4: ret                                                
02cd6db8: bl      #0x2b7105c                                 fn_2b7105c
## <IELoadScene>b__1() -> void
---- LoadingControl/<>c__DisplayClass9_0::<IELoadScene>b__1 0x2cd6dbc
02cd6dbc: mov     w8, #1                                     
02cd6dc0: strb    w8, [x0, #0x18]                            .consentRequestComplete
02cd6dc4: ret                                                
## <IELoadScene>b__2() -> void
---- LoadingControl/<>c__DisplayClass9_0::<IELoadScene>b__2 0x2cd6dc8
02cd6dc8: str     x30, [sp, #-0x10]!                         
02cd6dcc: ldr     x9, [x0, #0x10]                            .<>4__this
02cd6dd0: cbz     x9, #0x2cd6dfc                             
02cd6dd4: ldr     x8, [x9, #0x30]                            
02cd6dd8: cbz     x8, #0x2cd6dfc                             
02cd6ddc: ldr     x0, [x9, #0x38]                            
02cd6de0: cbz     x0, #0x2cd6dfc                             
02cd6de4: ldr     x9, [x0]                                   
02cd6de8: ldr     s0, [x8, #0xf4]                            
02cd6dec: ldr     x1, [x9, #0x430]                           
02cd6df0: ldr     x2, [x9, #0x428]                           
02cd6df4: ldr     x30, [sp], #0x10                           
02cd6df8: br      x2                                         
02cd6dfc: bl      #0x2b7105c                                 fn_2b7105c
## <IELoadScene>b__3() -> bool
---- LoadingControl/<>c__DisplayClass9_0::<IELoadScene>b__3 0x2cd6e00
02cd6e00: str     x30, [sp, #-0x10]!                         
02cd6e04: ldr     x8, [x0, #0x10]                            .<>4__this
02cd6e08: cbz     x8, #0x2cd6e34                             
02cd6e0c: ldr     x0, [x8, #0x48]                            
02cd6e10: cbz     x0, #0x2cd6e34                             
02cd6e14: mov     x1, xzr                                    
02cd6e18: bl      #0x5b2f3f0                                 UnityEngine.AsyncOperation::get_progress
02cd6e1c: adrp    x8, #0x1084000                             
02cd6e20: ldr     s1, [x8, #0xbd4]                           [1084bd4]=440980003f666666 f=0.9,550
02cd6e24: fcmp    s0, s1                                     
02cd6e28: cset    w0, ge                                     
02cd6e2c: ldr     x30, [sp], #0x10                           
02cd6e30: ret                                                
02cd6e34: bl      #0x2b7105c                                 fn_2b7105c
## <IELoadScene>b__4() -> bool
---- LoadingControl/<>c__DisplayClass9_0::<IELoadScene>b__4 0x2cd6e38
02cd6e38: ldrb    w0, [x0, #0x18]                            .consentRequestComplete
02cd6e3c: ret                                                
## <IELoadScene>b__5() -> void
---- LoadingControl/<>c__DisplayClass9_0::<IELoadScene>b__5 0x2cd6e40
02cd6e40: str     x30, [sp, #-0x10]!                         
02cd6e44: ldr     x8, [x0, #0x10]                            .<>4__this
02cd6e48: cbz     x8, #0x2cd6e64                             
02cd6e4c: ldr     x0, [x8, #0x48]                            
02cd6e50: cbz     x0, #0x2cd6e64                             
02cd6e54: mov     w1, #1                                     
02cd6e58: mov     x2, xzr                                    
02cd6e5c: ldr     x30, [sp], #0x10                           
02cd6e60: b       #0x5b2f47c                                 UnityEngine.AsyncOperation::set_allowSceneActivation
02cd6e64: bl      #0x2b7105c                                 fn_2b7105c
#### CLASS LoadingControl/<IELoadScene>d__9 parent= object
#   field <>1__state                     int                                                off=0x10 attr=1 
#   field <>2__current                   object                                             off=0x18 attr=1 
#   field <>4__this                      LoadingControl                                     off=0x20 attr=6 
#   field id                             string                                             off=0x28 attr=6 
#   field time                           float                                              off=0x30 attr=6 
#   field <>8__1                         LoadingControl/<>c__DisplayClass9_0                off=0x38 attr=1 
## .ctor(int <>1__state) -> void
---- LoadingControl/<IELoadScene>d__9::.ctor 0x2cd6cc8
02cd6cc8: str     x30, [sp, #-0x20]!                         
02cd6ccc: stp     x20, x19, [sp, #0x10]                      
02cd6cd0: mov     w19, w1                                    
02cd6cd4: mov     x1, xzr                                    
02cd6cd8: mov     x20, x0                                    
02cd6cdc: bl      #0x4e53e9c                                 System.Object::.ctor
02cd6ce0: str     w19, [x20, #0x10]                          .<>1__state
02cd6ce4: ldp     x20, x19, [sp, #0x10]                      
02cd6ce8: ldr     x30, [sp], #0x20                           
02cd6cec: ret                                                
## System.IDisposable.Dispose() -> void
---- LoadingControl/<IELoadScene>d__9::System.IDisposable.Dispose 0x2cd6e68
02cd6e68: ret                                                
## MoveNext() -> bool
---- LoadingControl/<IELoadScene>d__9::MoveNext 0x2cd6e6c
02cd6e6c: str     d8, [sp, #-0x40]!                          
02cd6e70: stp     x30, x23, [sp, #0x10]                      
02cd6e74: stp     x22, x21, [sp, #0x20]                      
02cd6e78: stp     x20, x19, [sp, #0x30]                      
02cd6e7c: adrp    x20, #0x662f000                            
02cd6e80: mov     x19, x0                                    
02cd6e84: ldrb    w8, [x20, #0xd32]                          
02cd6e88: tbnz    w8, #0, #0x2cd6f90                         
02cd6e8c: adrp    x0, #0x6264000                             
02cd6e90: ldr     x0, [x0, #0xf90]                           T:System.Action
02cd6e94: bl      #0x2b70db0                                 fn_2b70db0
02cd6e98: adrp    x0, #0x6266000                             
02cd6e9c: ldr     x0, [x0, #0x750]                           MS:DataManager::GetData
02cd6ea0: bl      #0x2b70db0                                 fn_2b70db0
02cd6ea4: adrp    x0, #0x6265000                             
02cd6ea8: ldr     x0, [x0, #0xfb0]                           T:type9979(k15)
02cd6eac: bl      #0x2b70db0                                 fn_2b70db0
02cd6eb0: adrp    x0, #0x6266000                             
02cd6eb4: ldr     x0, [x0, #0x658]                           MS:MonoSingleton`1::get_Instance
02cd6eb8: bl      #0x2b70db0                                 fn_2b70db0
02cd6ebc: adrp    x0, #0x6264000                             
02cd6ec0: ldr     x0, [x0, #0xb58]                           T:UnityEngine.SceneManagement.SceneManager
02cd6ec4: bl      #0x2b70db0                                 fn_2b70db0
02cd6ec8: adrp    x0, #0x6265000                             
02cd6ecc: ldr     x0, [x0, #0x310]                           MS:WejoyService.Singleton`1::get_Instance
02cd6ed0: bl      #0x2b70db0                                 fn_2b70db0
02cd6ed4: adrp    x0, #0x6267000                             
02cd6ed8: ldr     x0, [x0, #0x968]                           T:type18539(k15)
02cd6edc: bl      #0x2b70db0                                 fn_2b70db0
02cd6ee0: adrp    x0, #0x6264000                             
02cd6ee4: ldr     x0, [x0, #0xe8]                            T:DG.Tweening.TweenCallback
02cd6ee8: bl      #0x2b70db0                                 fn_2b70db0
02cd6eec: adrp    x0, #0x6267000                             
02cd6ef0: ldr     x0, [x0, #0x970]                           MS:DG.Tweening.TweenSettingsExtensions::OnUpdate
02cd6ef4: bl      #0x2b70db0                                 fn_2b70db0
02cd6ef8: adrp    x0, #0x6267000                             
02cd6efc: ldr     x0, [x0, #0x978]                           MS:DG.Tweening.TweenSettingsExtensions::SetEase
02cd6f00: bl      #0x2b70db0                                 fn_2b70db0
02cd6f04: adrp    x0, #0x6264000                             
02cd6f08: ldr     x0, [x0, #0x108]                           MS:DG.Tweening.TweenSettingsExtensions::SetEase
02cd6f0c: bl      #0x2b70db0                                 fn_2b70db0
02cd6f10: adrp    x0, #0x6267000                             
02cd6f14: ldr     x0, [x0, #0x980]                           M:LoadingControl/<>c__DisplayClass9_0::<IELoadScene>b__0
02cd6f18: bl      #0x2b70db0                                 fn_2b70db0
02cd6f1c: adrp    x0, #0x6267000                             
02cd6f20: ldr     x0, [x0, #0x988]                           M:LoadingControl/<>c__DisplayClass9_0::<IELoadScene>b__1
02cd6f24: bl      #0x2b70db0                                 fn_2b70db0
02cd6f28: adrp    x0, #0x6267000                             
02cd6f2c: ldr     x0, [x0, #0x990]                           M:LoadingControl/<>c__DisplayClass9_0::<IELoadScene>b__2
02cd6f30: bl      #0x2b70db0                                 fn_2b70db0
02cd6f34: adrp    x0, #0x6267000                             
02cd6f38: ldr     x0, [x0, #0x998]                           M:LoadingControl/<>c__DisplayClass9_0::<IELoadScene>b__3
02cd6f3c: bl      #0x2b70db0                                 fn_2b70db0
02cd6f40: adrp    x0, #0x6267000                             
02cd6f44: ldr     x0, [x0, #0x9a0]                           M:LoadingControl/<>c__DisplayClass9_0::<IELoadScene>b__4
02cd6f48: bl      #0x2b70db0                                 fn_2b70db0
02cd6f4c: adrp    x0, #0x6267000                             
02cd6f50: ldr     x0, [x0, #0x9a8]                           M:LoadingControl/<>c__DisplayClass9_0::<IELoadScene>b__5
02cd6f54: bl      #0x2b70db0                                 fn_2b70db0
02cd6f58: adrp    x0, #0x6267000                             
02cd6f5c: ldr     x0, [x0, #0x9b0]                           T:LoadingControl/<>c__DisplayClass9_0
02cd6f60: bl      #0x2b70db0                                 fn_2b70db0
02cd6f64: adrp    x0, #0x6264000                             
02cd6f68: ldr     x0, [x0, #0xf58]                           T:UnityEngine.WaitForSeconds
02cd6f6c: bl      #0x2b70db0                                 fn_2b70db0
02cd6f70: adrp    x0, #0x6265000                             
02cd6f74: ldr     x0, [x0, #0xfd8]                           T:UnityEngine.WaitUntil
02cd6f78: bl      #0x2b70db0                                 fn_2b70db0
02cd6f7c: adrp    x0, #0x6267000                             
02cd6f80: ldr     x0, [x0, #0x9b8]                           S:'loading'
02cd6f84: bl      #0x2b70db0                                 fn_2b70db0
02cd6f88: mov     w8, #1                                     
02cd6f8c: strb    w8, [x20, #0xd32]                          
02cd6f90: ldr     w8, [x19, #0x10]                           .<>1__state
02cd6f94: ldr     x23, [x19, #0x20]                          .<>4__this
02cd6f98: mov     w20, wzr                                   
02cd6f9c: cmp     w8, #1                                     
02cd6fa0: b.le    #0x2cd7098                                 
02cd6fa4: cmp     w8, #2                                     
02cd6fa8: b.eq    #0x2cd72b4                                 
02cd6fac: cmp     w8, #3                                     
02cd6fb0: b.eq    #0x2cd7324                                 
02cd6fb4: cmp     w8, #4                                     
02cd6fb8: b.ne    #0x2cd7430                                 
02cd6fbc: adrp    x8, #0x6266000                             
02cd6fc0: mov     w9, #-1                                    
02cd6fc4: ldr     x8, [x8, #0x658]                           MS:MonoSingleton`1::get_Instance
02cd6fc8: str     w9, [x19, #0x10]                           .<>1__state
02cd6fcc: ldr     x0, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cd6fd0: bl      #0x3769600                                 fn_3769600
02cd6fd4: cbz     x0, #0x2cd7448                             
02cd6fd8: adrp    x8, #0x6266000                             
02cd6fdc: ldr     x8, [x8, #0x750]                           MS:DataManager::GetData
02cd6fe0: ldr     x1, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cd6fe4: bl      #0x3168dd0                                 fn_3168dd0
02cd6fe8: cbz     x0, #0x2cd7448                             
02cd6fec: ldr     x8, [x0, #0x20]                            T:System.IO.FileInfo .<>4__this
02cd6ff0: mov     x20, x0                                    
02cd6ff4: cbz     x8, #0x2cd7448                             
02cd6ff8: ldr     w9, [x8, #0xa0]                            S:'open_ad_capping_time'
02cd6ffc: mov     x0, x20                                    
02cd7000: add     w9, w9, #1                                 
02cd7004: str     w9, [x8, #0xa0]                            
02cd7008: ldr     x8, [x20]                                  &2b706c4(=eb01011ff9400808)
02cd700c: ldr     x9, [x8, #0x258]                           MS:System.Collections.Generic.List`1/Enumerator::Dispose
02cd7010: ldr     x1, [x8, #0x260]                           MS:System.Collections.Generic.List`1/Enumerator::MoveNext
02cd7014: blr     x9                                         
02cd7018: ldr     x8, [x20, #0x20]                           &2b706f0(=d65f03c0f9400800) .<>4__this
02cd701c: cbz     x8, #0x2cd7448                             
02cd7020: ldr     w8, [x8, #0xa0]                            S:'open_ad_capping_time'
02cd7024: cmp     w8, #1                                     
02cd7028: b.le    #0x2cd73f8                                 
02cd702c: adrp    x8, #0x6265000                             
02cd7030: ldr     x8, [x8, #0x310]                           MS:WejoyService.Singleton`1::get_Instance
02cd7034: ldr     x0, [x8]                                   M:AdsManager::<OnApplicationPause>b__26_0
02cd7038: bl      #0x3be7218                                 fn_3be7218
02cd703c: adrp    x8, #0x6264000                             
02cd7040: ldr     x8, [x8, #0xf90]                           T:System.Action
02cd7044: ldr     x21, [x19, #0x38]                          .<>8__1
02cd7048: mov     x19, x0                                    
02cd704c: ldr     x8, [x8]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02cd7050: mov     x0, x8                                     
02cd7054: bl      #0x2b7104c                                 fn_2b7104c
02cd7058: adrp    x8, #0x6267000                             
02cd705c: mov     x1, x21                                    
02cd7060: mov     x3, xzr                                    
02cd7064: ldr     x8, [x8, #0x9a8]                           M:LoadingControl/<>c__DisplayClass9_0::<IELoadScene>b__5
02cd7068: mov     x20, x0                                    
02cd706c: ldr     x2, [x8]                                   S:'didu'
02cd7070: bl      #0x4d8ddbc                                 System.Action::.ctor
02cd7074: cbz     x19, #0x2cd7448                            
02cd7078: adrp    x8, #0x6267000                             
02cd707c: mov     x0, x19                                    
02cd7080: mov     x2, x20                                    
02cd7084: ldr     x8, [x8, #0x9b8]                           S:'loading'
02cd7088: mov     x3, xzr                                    
02cd708c: ldr     x1, [x8]                                   S:'didu'
02cd7090: bl      #0x2c89314                                 AdsManager::ShowAppOpenLoading
02cd7094: b       #0x2cd742c                                 
02cd7098: cbz     w8, #0x2cd7370                             
02cd709c: cmp     w8, #1                                     
02cd70a0: b.ne    #0x2cd7430                                 
02cd70a4: adrp    x8, #0x6264000                             
02cd70a8: mov     w9, #-1                                    
02cd70ac: ldr     x8, [x8, #0xb58]                           T:UnityEngine.SceneManagement.SceneManager
02cd70b0: ldr     x20, [x19, #0x28]                          .id
02cd70b4: str     w9, [x19, #0x10]                           .<>1__state
02cd70b8: ldr     x0, [x8]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02cd70bc: ldr     w8, [x0, #0xe4]                            [62670e4]=0 f=0,0
02cd70c0: cbnz    w8, #0x2cd70c8                             
02cd70c4: bl      #0x2b70f30                                 fn_2b70f30
02cd70c8: mov     x0, x20                                    
02cd70cc: mov     x1, xzr                                    
02cd70d0: bl      #0x5b4f8e8                                 UnityEngine.SceneManagement.SceneManager::LoadSceneAsync
02cd70d4: cbz     x23, #0x2cd7448                            
02cd70d8: mov     x20, x23                                   
02cd70dc: mov     x1, x0                                     
02cd70e0: str     x0, [x20, #0x48]!                          
02cd70e4: mov     x0, x20                                    
02cd70e8: bl      #0x2b70d54                                 fn_2b70d54
02cd70ec: ldr     x0, [x20]                                  &2b706c4(=eb01011ff9400808)
02cd70f0: cbz     x0, #0x2cd7448                             
02cd70f4: mov     w1, wzr                                    
02cd70f8: mov     x2, xzr                                    
02cd70fc: bl      #0x5b2f47c                                 UnityEngine.AsyncOperation::set_allowSceneActivation
02cd7100: adrp    x8, #0x6267000                             
02cd7104: ldr     x8, [x8, #0x968]                           T:type18539(k15)
02cd7108: ldr     s8, [x19, #0x30]                           .time
02cd710c: ldr     x20, [x19, #0x38]                          .<>8__1
02cd7110: ldr     x0, [x8]                                   S:'didu'
02cd7114: bl      #0x2b7104c                                 fn_2b7104c
02cd7118: adrp    x8, #0x6267000                             
02cd711c: mov     x1, x20                                    
02cd7120: mov     x3, xzr                                    
02cd7124: ldr     x8, [x8, #0x980]                           M:LoadingControl/<>c__DisplayClass9_0::<IELoadScene>b__0
02cd7128: mov     x21, x0                                    
02cd712c: ldr     x2, [x8]                                   S:'didu'
02cd7130: bl      #0x3dde36c                                 fn_3dde36c
02cd7134: mov     w8, #0x42c80000                            
02cd7138: movi    d0, #0000000000000000                      
02cd713c: fmov    s2, s8                                     
02cd7140: fmov    s1, w8                                     
02cd7144: mov     x0, x21                                    
02cd7148: mov     x1, xzr                                    
02cd714c: bl      #0x2d8e914                                 DG.Tweening.DOVirtual::Float
02cd7150: adrp    x8, #0x6264000                             
02cd7154: mov     w1, #1                                     
02cd7158: ldr     x8, [x8, #0x108]                           MS:DG.Tweening.TweenSettingsExtensions::SetEase
02cd715c: ldr     x2, [x8]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02cd7160: bl      #0x336fa0c                                 fn_336fa0c
02cd7164: ldr     x8, [x19, #0x38]                           .<>8__1
02cd7168: cbz     x8, #0x2cd7448                             
02cd716c: adrp    x9, #0x6265000                             
02cd7170: ldr     x9, [x9, #0x310]                           MS:WejoyService.Singleton`1::get_Instance
02cd7174: strb    wzr, [x8, #0x18]                           
02cd7178: ldr     x0, [x9]                                   M:AdsManager::<OnApplicationPause>b__26_0
02cd717c: bl      #0x3be7218                                 fn_3be7218
02cd7180: adrp    x8, #0x6264000                             
02cd7184: mov     x20, x0                                    
02cd7188: ldr     x8, [x8, #0xf90]                           T:System.Action
02cd718c: ldr     x22, [x19, #0x38]                          .<>8__1
02cd7190: ldr     x8, [x8]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02cd7194: mov     x0, x8                                     
02cd7198: bl      #0x2b7104c                                 fn_2b7104c
02cd719c: adrp    x8, #0x6267000                             
02cd71a0: mov     x1, x22                                    
02cd71a4: mov     x3, xzr                                    
02cd71a8: ldr     x8, [x8, #0x988]                           M:LoadingControl/<>c__DisplayClass9_0::<IELoadScene>b__1
02cd71ac: mov     x21, x0                                    
02cd71b0: ldr     x2, [x8]                                   S:'didu'
02cd71b4: bl      #0x4d8ddbc                                 System.Action::.ctor
02cd71b8: cbz     x20, #0x2cd7448                            
02cd71bc: mov     x0, x20                                    
02cd71c0: mov     x1, x21                                    
02cd71c4: mov     x2, xzr                                    
02cd71c8: bl      #0x2c88b7c                                 AdsManager::RequestConsent
02cd71cc: fmov    s0, #1.00000000                            
02cd71d0: ldr     x0, [x23, #0x30]                           
02cd71d4: ldr     s1, [x19, #0x30]                           .time
02cd71d8: mov     x1, xzr                                    
02cd71dc: bl      #0x2c78b44                                 DG.Tweening.DOTweenModuleUI::DOFillAmount
02cd71e0: adrp    x8, #0x6267000                             
02cd71e4: mov     w1, #1                                     
02cd71e8: mov     w20, #1                                    
02cd71ec: ldr     x8, [x8, #0x978]                           MS:DG.Tweening.TweenSettingsExtensions::SetEase
02cd71f0: ldr     x2, [x8]                                   S:'didu'
02cd71f4: bl      #0x336fa0c                                 fn_336fa0c
02cd71f8: adrp    x8, #0x6264000                             
02cd71fc: mov     x22, x0                                    
02cd7200: ldr     x8, [x8, #0xe8]                            T:DG.Tweening.TweenCallback
02cd7204: ldr     x21, [x19, #0x38]                          .<>8__1
02cd7208: ldr     x8, [x8]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02cd720c: mov     x0, x8                                     
02cd7210: bl      #0x2b7104c                                 fn_2b7104c
02cd7214: adrp    x8, #0x6267000                             
02cd7218: mov     x1, x21                                    
02cd721c: mov     x3, xzr                                    
02cd7220: ldr     x8, [x8, #0x990]                           M:LoadingControl/<>c__DisplayClass9_0::<IELoadScene>b__2
02cd7224: mov     x23, x0                                    
02cd7228: ldr     x2, [x8]                                   S:'didu'
02cd722c: bl      #0x2d89dc4                                 DG.Tweening.TweenCallback::.ctor
02cd7230: adrp    x8, #0x6267000                             
02cd7234: mov     x0, x22                                    
02cd7238: mov     x1, x23                                    
02cd723c: ldr     x8, [x8, #0x970]                           MS:DG.Tweening.TweenSettingsExtensions::OnUpdate
02cd7240: ldr     x2, [x8]                                   S:'didu'
02cd7244: bl      #0x336f3a0                                 fn_336f3a0
02cd7248: adrp    x8, #0x6265000                             
02cd724c: ldr     x8, [x8, #0xfb0]                           T:type9979(k15)
02cd7250: ldr     x21, [x19, #0x38]                          .<>8__1
02cd7254: ldr     x0, [x8]                                   M:AdsManager::<OnApplicationPause>b__26_0
02cd7258: bl      #0x2b7104c                                 fn_2b7104c
02cd725c: adrp    x8, #0x6267000                             
02cd7260: mov     x1, x21                                    
02cd7264: mov     x3, xzr                                    
02cd7268: ldr     x8, [x8, #0x998]                           M:LoadingControl/<>c__DisplayClass9_0::<IELoadScene>b__3
02cd726c: mov     x22, x0                                    
02cd7270: ldr     x2, [x8]                                   S:'didu'
02cd7274: bl      #0x4932dc8                                 fn_4932dc8
02cd7278: adrp    x8, #0x6265000                             
02cd727c: ldr     x8, [x8, #0xfd8]                           T:UnityEngine.WaitUntil
02cd7280: ldr     x0, [x8]                                   M:AdsManager::<OnApplicationPause>b__26_0
02cd7284: bl      #0x2b7104c                                 fn_2b7104c
02cd7288: mov     x1, x22                                    
02cd728c: mov     x2, xzr                                    
02cd7290: mov     x21, x0                                    
02cd7294: bl      #0x5b3e7e4                                 UnityEngine.WaitUntil::.ctor
02cd7298: str     x21, [x19, #0x18]!                         .<>2__current
02cd729c: mov     x0, x19                                    
02cd72a0: mov     x1, x21                                    
02cd72a4: bl      #0x2b70d54                                 fn_2b70d54
02cd72a8: mov     w8, #2                                     
02cd72ac: stur    w8, [x19, #-8]                             
02cd72b0: b       #0x2cd7430                                 
02cd72b4: adrp    x8, #0x6265000                             
02cd72b8: mov     w9, #-1                                    
02cd72bc: ldr     x8, [x8, #0xfb0]                           T:type9979(k15)
02cd72c0: ldr     x20, [x19, #0x38]                          .<>8__1
02cd72c4: str     w9, [x19, #0x10]                           .<>1__state
02cd72c8: ldr     x0, [x8]                                   M:AdsManager::<OnApplicationPause>b__26_0
02cd72cc: bl      #0x2b7104c                                 fn_2b7104c
02cd72d0: adrp    x8, #0x6267000                             
02cd72d4: mov     x1, x20                                    
02cd72d8: mov     x3, xzr                                    
02cd72dc: ldr     x8, [x8, #0x9a0]                           M:LoadingControl/<>c__DisplayClass9_0::<IELoadScene>b__4
02cd72e0: mov     x21, x0                                    
02cd72e4: ldr     x2, [x8]                                   S:'didu'
02cd72e8: bl      #0x4932dc8                                 fn_4932dc8
02cd72ec: adrp    x8, #0x6265000                             
02cd72f0: ldr     x8, [x8, #0xfd8]                           T:UnityEngine.WaitUntil
02cd72f4: ldr     x0, [x8]                                   M:AdsManager::<OnApplicationPause>b__26_0
02cd72f8: bl      #0x2b7104c                                 fn_2b7104c
02cd72fc: mov     x1, x21                                    
02cd7300: mov     x2, xzr                                    
02cd7304: mov     x20, x0                                    
02cd7308: bl      #0x5b3e7e4                                 UnityEngine.WaitUntil::.ctor
02cd730c: mov     x0, x19                                    
02cd7310: mov     x1, x20                                    
02cd7314: str     x20, [x0, #0x18]!                          .<>2__current
02cd7318: bl      #0x2b70d54                                 fn_2b70d54
02cd731c: mov     w8, #3                                     
02cd7320: b       #0x2cd7364                                 
02cd7324: adrp    x8, #0x6264000                             
02cd7328: mov     w9, #-1                                    
02cd732c: ldr     x8, [x8, #0xf58]                           T:UnityEngine.WaitForSeconds
02cd7330: ldr     s8, [x19, #0x30]                           .time
02cd7334: str     w9, [x19, #0x10]                           .<>1__state
02cd7338: ldr     x0, [x8]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02cd733c: bl      #0x2b7104c                                 fn_2b7104c
02cd7340: fmov    s0, s8                                     
02cd7344: mov     x1, xzr                                    
02cd7348: mov     x20, x0                                    
02cd734c: bl      #0x5b3e5e8                                 UnityEngine.WaitForSeconds::.ctor
02cd7350: mov     x0, x19                                    
02cd7354: mov     x1, x20                                    
02cd7358: str     x20, [x0, #0x18]!                          .<>2__current
02cd735c: bl      #0x2b70d54                                 fn_2b70d54
02cd7360: mov     w8, #4                                     
02cd7364: str     w8, [x19, #0x10]                           .<>1__state
02cd7368: mov     w20, #1                                    
02cd736c: b       #0x2cd7430                                 
02cd7370: adrp    x8, #0x6267000                             
02cd7374: mov     w9, #-1                                    
02cd7378: ldr     x8, [x8, #0x9b0]                           T:LoadingControl/<>c__DisplayClass9_0
02cd737c: str     w9, [x19, #0x10]                           .<>1__state
02cd7380: ldr     x0, [x8]                                   S:'didu'
02cd7384: bl      #0x2b7104c                                 fn_2b7104c
02cd7388: mov     x1, xzr                                    
02cd738c: mov     x20, x0                                    
02cd7390: bl      #0x4e53e9c                                 System.Object::.ctor
02cd7394: mov     x21, x19                                   
02cd7398: mov     x1, x20                                    
02cd739c: str     x20, [x21, #0x38]!                         .<>8__1
02cd73a0: mov     x0, x21                                    
02cd73a4: bl      #0x2b70d54                                 fn_2b70d54
02cd73a8: ldr     x0, [x21]                                  
02cd73ac: cbz     x0, #0x2cd7448                             
02cd73b0: ldr     x1, [x19, #0x20]                           .<>4__this
02cd73b4: str     x1, [x0, #0x10]!                           .<>1__state
02cd73b8: bl      #0x2b70d54                                 fn_2b70d54
02cd73bc: adrp    x8, #0x6264000                             
02cd73c0: ldr     x8, [x8, #0xf58]                           T:UnityEngine.WaitForSeconds
02cd73c4: ldr     x0, [x8]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02cd73c8: bl      #0x2b7104c                                 fn_2b7104c
02cd73cc: fmov    s0, #1.00000000                            
02cd73d0: mov     x1, xzr                                    
02cd73d4: mov     x20, x0                                    
02cd73d8: bl      #0x5b3e5e8                                 UnityEngine.WaitForSeconds::.ctor
02cd73dc: str     x20, [x19, #0x18]!                         .<>2__current
02cd73e0: mov     x0, x19                                    
02cd73e4: mov     x1, x20                                    
02cd73e8: bl      #0x2b70d54                                 fn_2b70d54
02cd73ec: mov     w20, #1                                    
02cd73f0: stur    w20, [x19, #-8]                            
02cd73f4: b       #0x2cd7430                                 
02cd73f8: cbz     x23, #0x2cd7448                            
02cd73fc: ldr     x0, [x23, #0x48]                           
02cd7400: cbz     x0, #0x2cd7448                             
02cd7404: mov     w1, #1                                     
02cd7408: mov     x2, xzr                                    
02cd740c: bl      #0x5b2f47c                                 UnityEngine.AsyncOperation::set_allowSceneActivation
02cd7410: adrp    x8, #0x6265000                             
02cd7414: ldr     x8, [x8, #0x310]                           MS:WejoyService.Singleton`1::get_Instance
02cd7418: ldr     x0, [x8]                                   M:AdsManager::<OnApplicationPause>b__26_0
02cd741c: bl      #0x3be7218                                 fn_3be7218
02cd7420: cbz     x0, #0x2cd7448                             
02cd7424: mov     x1, xzr                                    
02cd7428: bl      #0x2c8a4e8                                 AdsManager::ShowBanner
02cd742c: mov     w20, wzr                                   
02cd7430: mov     w0, w20                                    
02cd7434: ldp     x20, x19, [sp, #0x30]                      
02cd7438: ldp     x22, x21, [sp, #0x20]                      
02cd743c: ldp     x30, x23, [sp, #0x10]                      
02cd7440: ldr     d8, [sp], #0x40                            
02cd7444: ret                                                
02cd7448: bl      #0x2b7105c                                 fn_2b7105c
## System.Collections.Generic.IEnumerator<System.Object>.get_Current() -> object
---- LoadingControl/<IELoadScene>d__9::System.Collections.Generic.IEnumerator<System.Object>.get_Current 0x2cd744c
02cd744c: ldr     x0, [x0, #0x18]                            .<>2__current
02cd7450: ret                                                
## System.Collections.IEnumerator.Reset() -> void
---- LoadingControl/<IELoadScene>d__9::System.Collections.IEnumerator.Reset 0x2cd7454
02cd7454: stp     x30, x19, [sp, #-0x10]!                    
02cd7458: adrp    x0, #0x6264000                             
02cd745c: ldr     x0, [x0, #0xf60]                           T:System.NotSupportedException
02cd7460: bl      #0x2b70dc4                                 fn_2b70dc4
02cd7464: bl      #0x2b7104c                                 fn_2b7104c
02cd7468: mov     x1, xzr                                    
02cd746c: mov     x19, x0                                    
02cd7470: bl      #0x4e14238                                 System.NotSupportedException::.ctor
02cd7474: adrp    x0, #0x6267000                             
02cd7478: ldr     x0, [x0, #0x9c0]                           M:LoadingControl/<IELoadScene>d__9::System.Collections.IEnumerator.Reset
02cd747c: bl      #0x2b70dc4                                 fn_2b70dc4
02cd7480: mov     x1, x0                                     
02cd7484: mov     x0, x19                                    
02cd7488: bl      #0x2b70f20                                 fn_2b70f20
## System.Collections.IEnumerator.get_Current() -> object
---- LoadingControl/<IELoadScene>d__9::System.Collections.IEnumerator.get_Current 0x2cd748c
02cd748c: ldr     x0, [x0, #0x18]                            .<>2__current
02cd7490: ret                                                
#### CLASS LoadingControl parent= UnityEngine.MonoBehaviour
#   field _loadingDuration               float                                              off=0x20 attr=1 SerializeField
#   field _targetScene                   SceneNames                                         off=0x24 attr=1 SerializeField
#   field _loadingText                   TMPro.TextMeshProUGUI                              off=0x28 attr=1 SerializeField
#   field _loadingFillImage              UnityEngine.UI.Image                               off=0x30 attr=1 SerializeField
#   field _hiddenSlider                  UnityEngine.UI.Slider                              off=0x38 attr=1 SerializeField
#   field _charmAnimation                CharmRandomLoading                                 off=0x40 attr=1 SerializeField
#   field async                          UnityEngine.AsyncOperation                         off=0x48 attr=1 
## Start() -> void
---- LoadingControl::Start 0x2cd6b88
02cd6b88: sub     sp, sp, #0x40                              
02cd6b8c: stp     x30, x21, [sp, #0x20]                      
02cd6b90: stp     x20, x19, [sp, #0x30]                      
02cd6b94: adrp    x20, #0x662f000                            
02cd6b98: adrp    x21, #0x6267000                            
02cd6b9c: mov     x19, x0                                    
02cd6ba0: ldrb    w8, [x20, #0xd2f]                          
02cd6ba4: ldr     x21, [x21, #0x950]                         T:SceneNames
02cd6ba8: tbnz    w8, #0, #0x2cd6bc0                         
02cd6bac: adrp    x0, #0x6267000                             
02cd6bb0: ldr     x0, [x0, #0x950]                           T:SceneNames
02cd6bb4: bl      #0x2b70db0                                 fn_2b70db0
02cd6bb8: mov     w8, #1                                     
02cd6bbc: strb    w8, [x20, #0xd2f]                          
02cd6bc0: ldr     x8, [x21]                                  S:'didu'
02cd6bc4: ldr     w10, [x19, #0x24]                          ._targetScene
02cd6bc8: mov     x9, #-1                                    
02cd6bcc: add     x0, sp, #8                                 
02cd6bd0: mov     x1, xzr                                    
02cd6bd4: stp     x8, x9, [sp, #8]                           
02cd6bd8: str     w10, [sp, #0x18]                           
02cd6bdc: bl      #0x4e47e48                                 System.Enum::ToString
02cd6be0: ldr     s0, [x19, #0x20]                           ._loadingDuration
02cd6be4: mov     x1, x0                                     
02cd6be8: mov     x0, x19                                    
02cd6bec: bl      #0x2cd6c30                                 LoadingControl::IELoadScene
02cd6bf0: mov     x1, x0                                     
02cd6bf4: mov     x0, x19                                    
02cd6bf8: mov     x2, xzr                                    
02cd6bfc: bl      #0x5b389f0                                 UnityEngine.MonoBehaviour::StartCoroutine
02cd6c00: ldp     x20, x19, [sp, #0x30]                      
02cd6c04: ldp     x30, x21, [sp, #0x20]                      
02cd6c08: add     sp, sp, #0x40                              
02cd6c0c: ret                                                
## LoadScene(string id, float time) -> void
---- LoadingControl::LoadScene 0x2cd6c10
02cd6c10: stp     x30, x19, [sp, #-0x10]!                    
02cd6c14: mov     x19, x0                                    
02cd6c18: bl      #0x2cd6c30                                 LoadingControl::IELoadScene
02cd6c1c: mov     x1, x0                                     
02cd6c20: mov     x0, x19                                    
02cd6c24: mov     x2, xzr                                    
02cd6c28: ldp     x30, x19, [sp], #0x10                      
02cd6c2c: b       #0x5b389f0                                 UnityEngine.MonoBehaviour::StartCoroutine
## IELoadScene(string id, float time) -> System.Collections.IEnumerator
---- LoadingControl::IELoadScene 0x2cd6c30
02cd6c30: str     d8, [sp, #-0x30]!                          
02cd6c34: str     x30, [sp, #8]                              
02cd6c38: stp     x22, x21, [sp, #0x10]                      
02cd6c3c: stp     x20, x19, [sp, #0x20]                      
02cd6c40: fmov    s8, s0                                     
02cd6c44: adrp    x21, #0x662f000                            
02cd6c48: adrp    x22, #0x6267000                            
02cd6c4c: ldrb    w8, [x21, #0xd30]                          
02cd6c50: ldr     x22, [x22, #0x958]                         T:LoadingControl/<IELoadScene>d__9
02cd6c54: mov     x19, x1                                    
02cd6c58: mov     x20, x0                                    
02cd6c5c: tbnz    w8, #0, #0x2cd6c74                         
02cd6c60: adrp    x0, #0x6267000                             
02cd6c64: ldr     x0, [x0, #0x958]                           T:LoadingControl/<IELoadScene>d__9
02cd6c68: bl      #0x2b70db0                                 fn_2b70db0
02cd6c6c: mov     w8, #1                                     
02cd6c70: strb    w8, [x21, #0xd30]                          
02cd6c74: ldr     x0, [x22]                                  S:'didu'
02cd6c78: bl      #0x2b7104c                                 fn_2b7104c
02cd6c7c: mov     x1, xzr                                    
02cd6c80: mov     x21, x0                                    
02cd6c84: bl      #0x4e53e9c                                 System.Object::.ctor
02cd6c88: mov     x0, x21                                    
02cd6c8c: mov     x1, x20                                    
02cd6c90: str     wzr, [x21, #0x10]                          
02cd6c94: str     x20, [x0, #0x20]!                          ._loadingDuration
02cd6c98: bl      #0x2b70d54                                 fn_2b70d54
02cd6c9c: mov     x0, x21                                    
02cd6ca0: mov     x1, x19                                    
02cd6ca4: str     x19, [x0, #0x28]!                          ._loadingText
02cd6ca8: bl      #0x2b70d54                                 fn_2b70d54
02cd6cac: mov     x0, x21                                    
02cd6cb0: str     s8, [x21, #0x30]                           ._loadingFillImage
02cd6cb4: ldr     x30, [sp, #8]                              
02cd6cb8: ldp     x20, x19, [sp, #0x20]                      
02cd6cbc: ldp     x22, x21, [sp, #0x10]                      
02cd6cc0: ldr     d8, [sp], #0x30                            
02cd6cc4: ret                                                
## .ctor() -> void
---- LoadingControl::.ctor 0x2cd6cf0
02cd6cf0: mov     x1, xzr                                    
02cd6cf4: b       #0x5b397b0                                 UnityEngine.MonoBehaviour::.ctor
