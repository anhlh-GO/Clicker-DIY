#### CLASS LocalizeText parent= UnityEngine.MonoBehaviour
#   field _txtLocalize                   TMPro.TextMeshProUGUI                              off=0x20 attr=1 SerializeField
#   field _hasCustomKey                  bool                                               off=0x28 attr=1 SerializeField
#   field _key                           string                                             off=0x30 attr=1 SerializeField
#   field _textMaterial                  UnityEngine.Material                               off=0x38 attr=1 
## Awake() -> void
---- LocalizeText::Awake 0x2cd95b4
02cd95b4: str     x30, [sp, #-0x30]!                         
02cd95b8: stp     x22, x21, [sp, #0x10]                      
02cd95bc: stp     x20, x19, [sp, #0x20]                      
02cd95c0: adrp    x20, #0x662f000                            
02cd95c4: adrp    x21, #0x6267000                            
02cd95c8: mov     x19, x0                                    
02cd95cc: ldrb    w8, [x20, #0xd47]                          
02cd95d0: ldr     x21, [x21, #0xaa0]                         MS:UnityEngine.Component::GetComponent
02cd95d4: tbnz    w8, #0, #0x2cd9610                         
02cd95d8: adrp    x0, #0x6264000                             
02cd95dc: ldr     x0, [x0, #0xf90]                           T:System.Action
02cd95e0: bl      #0x2b70db0                                 fn_2b70db0
02cd95e4: adrp    x0, #0x6267000                             
02cd95e8: ldr     x0, [x0, #0xaa0]                           MS:UnityEngine.Component::GetComponent
02cd95ec: bl      #0x2b70db0                                 fn_2b70db0
02cd95f0: adrp    x0, #0x6266000                             
02cd95f4: ldr     x0, [x0, #0x9f0]                           T:Assets.SimpleLocalization.Scripts.LocalizationManager
02cd95f8: bl      #0x2b70db0                                 fn_2b70db0
02cd95fc: adrp    x0, #0x6267000                             
02cd9600: ldr     x0, [x0, #0xb10]                           M:LocalizeText::ChangeText
02cd9604: bl      #0x2b70db0                                 fn_2b70db0
02cd9608: mov     w8, #1                                     
02cd960c: strb    w8, [x20, #0xd47]                          
02cd9610: ldr     x1, [x21]                                  S:'didu'
02cd9614: mov     x0, x19                                    
02cd9618: bl      #0x3140c84                                 fn_3140c84
02cd961c: mov     x20, x19                                   
02cd9620: mov     x1, x0                                     
02cd9624: str     x0, [x20, #0x20]!                          ._txtLocalize
02cd9628: mov     x0, x20                                    
02cd962c: bl      #0x2b70d54                                 fn_2b70d54
02cd9630: ldrb    w8, [x20, #8]                              
02cd9634: cbnz    w8, #0x2cd9660                             
02cd9638: ldr     x0, [x20]                                  &2b706c4(=eb01011ff9400808)
02cd963c: cbz     x0, #0x2cd96e4                             
02cd9640: ldr     x8, [x0]                                   S:'didu'
02cd9644: ldr     x9, [x8, #0x548]                           
02cd9648: ldr     x1, [x8, #0x550]                           
02cd964c: blr     x9                                         
02cd9650: mov     x1, x0                                     
02cd9654: mov     x0, x19                                    
02cd9658: str     x1, [x0, #0x30]!                           ._key
02cd965c: bl      #0x2b70d54                                 fn_2b70d54
02cd9660: adrp    x8, #0x6264000                             
02cd9664: adrp    x21, #0x6267000                            
02cd9668: adrp    x22, #0x6266000                            
02cd966c: ldr     x8, [x8, #0xf90]                           T:System.Action
02cd9670: ldr     x21, [x21, #0xb10]                         M:LocalizeText::ChangeText
02cd9674: ldr     x22, [x22, #0x9f0]                         T:Assets.SimpleLocalization.Scripts.LocalizationManager
02cd9678: ldr     x0, [x8]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02cd967c: bl      #0x2b7104c                                 fn_2b7104c
02cd9680: ldr     x2, [x21]                                  S:'didu'
02cd9684: mov     x1, x19                                    
02cd9688: mov     x3, xzr                                    
02cd968c: mov     x21, x0                                    
02cd9690: bl      #0x4d8ddbc                                 System.Action::.ctor
02cd9694: ldr     x0, [x22]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cd9698: ldr     w8, [x0, #0xe4]                            [62670e4]=0 f=0,0
02cd969c: cbnz    w8, #0x2cd96a4                             
02cd96a0: bl      #0x2b70f30                                 fn_2b70f30
02cd96a4: mov     x0, x21                                    
02cd96a8: mov     x1, xzr                                    
02cd96ac: bl      #0x2d7ad04                                 Assets.SimpleLocalization.Scripts.LocalizationManager::add_OnLocalizationChanged
02cd96b0: ldr     x0, [x20]                                  &2b706c4(=eb01011ff9400808)
02cd96b4: cbz     x0, #0x2cd96e4                             
02cd96b8: ldr     x8, [x0]                                   S:'didu'
02cd96bc: ldr     x9, [x8, #0x568]                           M:DG.Tweening.DOTweenModuleUI/<>c__DisplayClass24_0::<DOPivotY>b__0
02cd96c0: ldr     x1, [x8, #0x570]                           M:DG.Tweening.DOTweenModuleUI/<>c__DisplayClass24_0::<DOPivotY>b__1
02cd96c4: blr     x9                                         
02cd96c8: str     x0, [x19, #0x38]!                          ._textMaterial
02cd96cc: mov     x1, x0                                     
02cd96d0: mov     x0, x19                                    
02cd96d4: ldp     x20, x19, [sp, #0x20]                      
02cd96d8: ldp     x22, x21, [sp, #0x10]                      
02cd96dc: ldr     x30, [sp], #0x30                           
02cd96e0: b       #0x2b70d54                                 
02cd96e4: bl      #0x2b7105c                                 fn_2b7105c
## OnEnable() -> void
---- LocalizeText::OnEnable 0x2cd96e8
02cd96e8: stp     x30, x19, [sp, #-0x10]!                    
02cd96ec: mov     x19, x0                                    
02cd96f0: bl      #0x2cd9700                                 LocalizeText::ChangeText
02cd96f4: mov     x0, x19                                    
02cd96f8: ldp     x30, x19, [sp], #0x10                      
02cd96fc: b       #0x2cd9830                                 LocalizeText::ApplyFontMaterial
## OnDestroy() -> void
---- LocalizeText::OnDestroy 0x2cd9b30
02cd9b30: stp     x30, x23, [sp, #-0x30]!                    
02cd9b34: stp     x22, x21, [sp, #0x10]                      
02cd9b38: stp     x20, x19, [sp, #0x20]                      
02cd9b3c: adrp    x22, #0x662f000                            
02cd9b40: adrp    x23, #0x6264000                            
02cd9b44: adrp    x20, #0x6267000                            
02cd9b48: adrp    x21, #0x6266000                            
02cd9b4c: ldr     x23, [x23, #0xf90]                         T:System.Action
02cd9b50: ldrb    w8, [x22, #0xd48]                          
02cd9b54: ldr     x20, [x20, #0xb10]                         M:LocalizeText::ChangeText
02cd9b58: ldr     x21, [x21, #0x9f0]                         T:Assets.SimpleLocalization.Scripts.LocalizationManager
02cd9b5c: mov     x19, x0                                    
02cd9b60: tbnz    w8, #0, #0x2cd9b90                         
02cd9b64: adrp    x0, #0x6264000                             
02cd9b68: ldr     x0, [x0, #0xf90]                           T:System.Action
02cd9b6c: bl      #0x2b70db0                                 fn_2b70db0
02cd9b70: adrp    x0, #0x6266000                             
02cd9b74: ldr     x0, [x0, #0x9f0]                           T:Assets.SimpleLocalization.Scripts.LocalizationManager
02cd9b78: bl      #0x2b70db0                                 fn_2b70db0
02cd9b7c: adrp    x0, #0x6267000                             
02cd9b80: ldr     x0, [x0, #0xb10]                           M:LocalizeText::ChangeText
02cd9b84: bl      #0x2b70db0                                 fn_2b70db0
02cd9b88: mov     w8, #1                                     
02cd9b8c: strb    w8, [x22, #0xd48]                          
02cd9b90: ldr     x0, [x23]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02cd9b94: bl      #0x2b7104c                                 fn_2b7104c
02cd9b98: ldr     x2, [x20]                                  S:'didu'
02cd9b9c: mov     x1, x19                                    
02cd9ba0: mov     x3, xzr                                    
02cd9ba4: mov     x20, x0                                    
02cd9ba8: bl      #0x4d8ddbc                                 System.Action::.ctor
02cd9bac: ldr     x0, [x21]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cd9bb0: ldr     w8, [x0, #0xe4]                            [62670e4]=0 f=0,0
02cd9bb4: cbnz    w8, #0x2cd9bbc                             
02cd9bb8: bl      #0x2b70f30                                 fn_2b70f30
02cd9bbc: mov     x0, x20                                    
02cd9bc0: ldp     x20, x19, [sp, #0x20]                      
02cd9bc4: ldp     x22, x21, [sp, #0x10]                      
02cd9bc8: mov     x1, xzr                                    
02cd9bcc: ldp     x30, x23, [sp], #0x30                      
02cd9bd0: b       #0x2d7b144                                 Assets.SimpleLocalization.Scripts.LocalizationManager::remove_OnLocalizationChanged
## ForceUpdateText(string text) -> void
---- LocalizeText::ForceUpdateText 0x2cd9bd4
02cd9bd4: stp     x30, x21, [sp, #-0x20]!                    
02cd9bd8: stp     x20, x19, [sp, #0x10]                      
02cd9bdc: mov     x21, x0                                    
02cd9be0: mov     x19, x0                                    
02cd9be4: mov     x20, x1                                    
02cd9be8: str     x1, [x21, #0x30]!                          ._key
02cd9bec: mov     x0, x21                                    
02cd9bf0: bl      #0x2b70d54                                 fn_2b70d54
02cd9bf4: ldur    x0, [x21, #-0x10]                          
02cd9bf8: cbz     x0, #0x2cd9c20                             
02cd9bfc: ldr     x8, [x0]                                   
02cd9c00: mov     x1, x20                                    
02cd9c04: ldr     x9, [x8, #0x558]                           
02cd9c08: ldr     x2, [x8, #0x560]                           
02cd9c0c: blr     x9                                         
02cd9c10: mov     x0, x19                                    
02cd9c14: ldp     x20, x19, [sp, #0x10]                      
02cd9c18: ldp     x30, x21, [sp], #0x20                      
02cd9c1c: b       #0x2cd9700                                 LocalizeText::ChangeText
02cd9c20: bl      #0x2b7105c                                 fn_2b7105c
## GetKey() -> string
---- LocalizeText::GetKey 0x2cd9c24
02cd9c24: ldr     x0, [x0, #0x30]                            ._key
02cd9c28: ret                                                
## ChangeText() -> void
---- LocalizeText::ChangeText 0x2cd9700
02cd9700: str     x30, [sp, #-0x30]!                         
02cd9704: stp     x22, x21, [sp, #0x10]                      
02cd9708: stp     x20, x19, [sp, #0x20]                      
02cd970c: adrp    x20, #0x662f000                            
02cd9710: adrp    x22, #0x6263000                            
02cd9714: mov     x19, x0                                    
02cd9718: ldrb    w8, [x20, #0xd49]                          
02cd971c: ldr     x22, [x22, #0x918]                         T:UnityEngine.Object
02cd9720: tbnz    w8, #0, #0x2cd9750                         
02cd9724: adrp    x0, #0x6267000                             
02cd9728: ldr     x0, [x0, #0xaa0]                           MS:UnityEngine.Component::GetComponent
02cd972c: bl      #0x2b70db0                                 fn_2b70db0
02cd9730: adrp    x0, #0x6266000                             
02cd9734: ldr     x0, [x0, #0x9f0]                           T:Assets.SimpleLocalization.Scripts.LocalizationManager
02cd9738: bl      #0x2b70db0                                 fn_2b70db0
02cd973c: adrp    x0, #0x6263000                             
02cd9740: ldr     x0, [x0, #0x918]                           T:UnityEngine.Object
02cd9744: bl      #0x2b70db0                                 fn_2b70db0
02cd9748: mov     w8, #1                                     
02cd974c: strb    w8, [x20, #0xd49]                          
02cd9750: ldr     x0, [x22]                                  &2c5bbd4(=a9bd7bfdd503233f)
02cd9754: mov     x20, x19                                   
02cd9758: ldr     x21, [x20, #0x20]!                         &2b706f0(=d65f03c0f9400800) ._txtLocalize
02cd975c: ldr     w8, [x0, #0xe4]                            [62630e4]=0 f=0,0
02cd9760: cbnz    w8, #0x2cd9768                             
02cd9764: bl      #0x2b70f30                                 fn_2b70f30
02cd9768: mov     x0, x21                                    
02cd976c: mov     x1, xzr                                    
02cd9770: mov     x2, xzr                                    
02cd9774: bl      #0x5b37d84                                 UnityEngine.Object::op_Equality
02cd9778: tbz     w0, #0, #0x2cd97a0                         
02cd977c: adrp    x8, #0x6267000                             
02cd9780: mov     x0, x19                                    
02cd9784: ldr     x8, [x8, #0xaa0]                           MS:UnityEngine.Component::GetComponent
02cd9788: ldr     x1, [x8]                                   S:'didu'
02cd978c: bl      #0x3140c84                                 fn_3140c84
02cd9790: mov     x1, x0                                     
02cd9794: str     x0, [x19, #0x20]                           ._txtLocalize
02cd9798: mov     x0, x20                                    
02cd979c: bl      #0x2b70d54                                 fn_2b70d54
02cd97a0: ldr     x0, [x22]                                  &2c5bbd4(=a9bd7bfdd503233f)
02cd97a4: ldr     x20, [x20]                                 &2b706c4(=eb01011ff9400808)
02cd97a8: ldr     w8, [x0, #0xe4]                            [62630e4]=0 f=0,0
02cd97ac: cbnz    w8, #0x2cd97b4                             
02cd97b0: bl      #0x2b70f30                                 fn_2b70f30
02cd97b4: mov     x0, x20                                    
02cd97b8: mov     x1, xzr                                    
02cd97bc: mov     x2, xzr                                    
02cd97c0: bl      #0x5b3666c                                 UnityEngine.Object::op_Inequality
02cd97c4: tbz     w0, #0, #0x2cd981c                         
02cd97c8: adrp    x8, #0x6266000                             
02cd97cc: ldr     x8, [x8, #0x9f0]                           T:Assets.SimpleLocalization.Scripts.LocalizationManager
02cd97d0: ldr     x20, [x19, #0x20]                          ._txtLocalize
02cd97d4: ldr     x19, [x19, #0x30]                          ._key
02cd97d8: ldr     x0, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cd97dc: ldr     w8, [x0, #0xe4]                            [62630e4]=0 f=0,0
02cd97e0: cbnz    w8, #0x2cd97e8                             
02cd97e4: bl      #0x2b70f30                                 fn_2b70f30
02cd97e8: mov     x0, x19                                    
02cd97ec: mov     x1, xzr                                    
02cd97f0: bl      #0x2d76794                                 Assets.SimpleLocalization.Scripts.LocalizationManager::Localize
02cd97f4: cbz     x20, #0x2cd982c                            
02cd97f8: ldr     x8, [x20]                                  &2b706c4(=eb01011ff9400808)
02cd97fc: mov     x1, x0                                     
02cd9800: mov     x0, x20                                    
02cd9804: ldp     x20, x19, [sp, #0x20]                      
02cd9808: ldp     x22, x21, [sp, #0x10]                      
02cd980c: ldr     x2, [x8, #0x560]                           MS:NFramework.GoogleSheetConfigSO`1::OpenSheet
02cd9810: ldr     x3, [x8, #0x558]                           MS:NFramework.GoogleSheetConfigSO`1::.ctor
02cd9814: ldr     x30, [sp], #0x30                           
02cd9818: br      x3                                         
02cd981c: ldp     x20, x19, [sp, #0x20]                      
02cd9820: ldp     x22, x21, [sp, #0x10]                      
02cd9824: ldr     x30, [sp], #0x30                           
02cd9828: ret                                                
02cd982c: bl      #0x2b7105c                                 fn_2b7105c
## ApplyFontMaterial() -> void
---- LocalizeText::ApplyFontMaterial 0x2cd9830
02cd9830: sub     sp, sp, #0x90                              
02cd9834: stp     x30, x25, [sp, #0x50]                      
02cd9838: stp     x24, x23, [sp, #0x60]                      
02cd983c: stp     x22, x21, [sp, #0x70]                      
02cd9840: stp     x20, x19, [sp, #0x80]                      
02cd9844: adrp    x20, #0x662f000                            
02cd9848: adrp    x23, #0x6263000                            
02cd984c: mov     x19, x0                                    
02cd9850: ldrb    w8, [x20, #0xd4a]                          
02cd9854: ldr     x23, [x23, #0x918]                         T:UnityEngine.Object
02cd9858: tbnz    w8, #0, #0x2cd98ac                         
02cd985c: adrp    x0, #0x6267000                             
02cd9860: ldr     x0, [x0, #0xb18]                           MS:System.Collections.Generic.List`1/Enumerator::Dispose
02cd9864: bl      #0x2b70db0                                 fn_2b70db0
02cd9868: adrp    x0, #0x6267000                             
02cd986c: ldr     x0, [x0, #0xb20]                           MS:System.Collections.Generic.List`1/Enumerator::MoveNext
02cd9870: bl      #0x2b70db0                                 fn_2b70db0
02cd9874: adrp    x0, #0x6267000                             
02cd9878: ldr     x0, [x0, #0xb28]                           MS:System.Collections.Generic.List`1/Enumerator::get_Current
02cd987c: bl      #0x2b70db0                                 fn_2b70db0
02cd9880: adrp    x0, #0x6267000                             
02cd9884: ldr     x0, [x0, #0xb30]                           MS:System.Collections.Generic.List`1::GetEnumerator
02cd9888: bl      #0x2b70db0                                 fn_2b70db0
02cd988c: adrp    x0, #0x6267000                             
02cd9890: ldr     x0, [x0, #0x188]                           T:UnityEngine.Material
02cd9894: bl      #0x2b70db0                                 fn_2b70db0
02cd9898: adrp    x0, #0x6263000                             
02cd989c: ldr     x0, [x0, #0x918]                           T:UnityEngine.Object
02cd98a0: bl      #0x2b70db0                                 fn_2b70db0
02cd98a4: mov     w8, #1                                     
02cd98a8: strb    w8, [x20, #0xd4a]                          
02cd98ac: ldr     x0, [x23]                                  &2c5bbd4(=a9bd7bfdd503233f)
02cd98b0: ldr     x20, [x19, #0x20]                          ._txtLocalize
02cd98b4: stp     xzr, xzr, [sp, #0x30]                      
02cd98b8: str     xzr, [sp, #0x40]                           
02cd98bc: ldr     w8, [x0, #0xe4]                            [62630e4]=0 f=0,0
02cd98c0: str     wzr, [sp, #0x28]                           
02cd98c4: cbnz    w8, #0x2cd98cc                             
02cd98c8: bl      #0x2b70f30                                 fn_2b70f30
02cd98cc: mov     x0, x20                                    
02cd98d0: mov     x1, xzr                                    
02cd98d4: mov     x2, xzr                                    
02cd98d8: bl      #0x5b37d84                                 UnityEngine.Object::op_Equality
02cd98dc: tbnz    w0, #0, #0x2cd99e4                         
02cd98e0: ldr     x0, [x23]                                  &2c5bbd4(=a9bd7bfdd503233f)
02cd98e4: ldr     x20, [x19, #0x38]                          ._textMaterial
02cd98e8: ldr     w8, [x0, #0xe4]                            [62630e4]=0 f=0,0
02cd98ec: cbnz    w8, #0x2cd98f4                             
02cd98f0: bl      #0x2b70f30                                 fn_2b70f30
02cd98f4: mov     x0, x20                                    
02cd98f8: mov     x1, xzr                                    
02cd98fc: mov     x2, xzr                                    
02cd9900: bl      #0x5b37d84                                 UnityEngine.Object::op_Equality
02cd9904: tbnz    w0, #0, #0x2cd99e4                         
02cd9908: ldr     x8, [x19, #0x20]                           ._txtLocalize
02cd990c: cbz     x8, #0x2cd9a00                             
02cd9910: ldr     x8, [x8, #0xf8]                            
02cd9914: cbz     x8, #0x2cd9a04                             
02cd9918: ldr     x0, [x8, #0x188]                           
02cd991c: cbz     x0, #0x2cd9a08                             
02cd9920: adrp    x8, #0x6267000                             
02cd9924: ldr     x8, [x8, #0xb30]                           MS:System.Collections.Generic.List`1::GetEnumerator
02cd9928: ldr     x1, [x8]                                   S:'didu'
02cd992c: add     x8, sp, #8                                 
02cd9930: bl      #0x35a9d9c                                 fn_35a9d9c
02cd9934: ldur    q0, [sp, #8]                               
02cd9938: ldr     x8, [sp, #0x18]                            
02cd993c: adrp    x24, #0x6267000                            
02cd9940: adrp    x25, #0x6267000                            
02cd9944: add     x9, sp, #0x30                              
02cd9948: str     q0, [sp, #0x30]                            
02cd994c: ldr     x24, [x24, #0xb20]                         MS:System.Collections.Generic.List`1/Enumerator::MoveNext
02cd9950: str     x8, [sp, #0x40]                            
02cd9954: ldr     x25, [x25, #0x188]                         T:UnityEngine.Material
02cd9958: stp     xzr, x9, [sp, #8]                          
02cd995c: ldr     x1, [x24]                                  S:'didu'
02cd9960: add     x0, sp, #0x30                              
02cd9964: bl      #0x4690474                                 fn_4690474
02cd9968: tbz     w0, #0, #0x2cd99c8                         
02cd996c: ldr     x0, [x23]                                  &2c5bbd4(=a9bd7bfdd503233f)
02cd9970: ldr     x20, [sp, #0x40]                           
02cd9974: ldr     w8, [x0, #0xe4]                            [62630e4]=0 f=0,0
02cd9978: cbnz    w8, #0x2cd9980                             
02cd997c: bl      #0x2b70f30                                 fn_2b70f30
02cd9980: mov     x0, x20                                    
02cd9984: mov     x1, xzr                                    
02cd9988: mov     x2, xzr                                    
02cd998c: bl      #0x5b3666c                                 UnityEngine.Object::op_Inequality
02cd9990: tbz     w0, #0, #0x2cd995c                         
02cd9994: ldr     x22, [x19, #0x38]                          ._textMaterial
02cd9998: ldr     x0, [x25]                                  S:'didu'
02cd999c: bl      #0x2b7104c                                 fn_2b7104c
02cd99a0: mov     x1, x22                                    
02cd99a4: mov     x2, xzr                                    
02cd99a8: mov     x21, x0                                    
02cd99ac: bl      #0x5b05e18                                 UnityEngine.Material::.ctor
02cd99b0: cbz     x20, #0x2cd99fc                            
02cd99b4: str     x21, [x20, #0x88]!                         
02cd99b8: mov     x0, x20                                    
02cd99bc: mov     x1, x21                                    
02cd99c0: bl      #0x2b70d54                                 fn_2b70d54
02cd99c4: b       #0x2cd995c                                 
02cd99c8: mov     x19, xzr                                   
02cd99cc: add     x0, sp, #0x30                              
02cd99d0: adrp    x8, #0x6267000                             
02cd99d4: ldr     x8, [x8, #0xb18]                           MS:System.Collections.Generic.List`1/Enumerator::Dispose
02cd99d8: ldr     x1, [x8]                                   S:'didu'
02cd99dc: bl      #0x4690470                                 fn_4690470
02cd99e0: cbnz    x19, #0x2cd9a0c                            
02cd99e4: ldp     x20, x19, [sp, #0x80]                      
02cd99e8: ldp     x22, x21, [sp, #0x70]                      
02cd99ec: ldp     x24, x23, [sp, #0x60]                      
02cd99f0: ldp     x30, x25, [sp, #0x50]                      
02cd99f4: add     sp, sp, #0x90                              
02cd99f8: ret                                                
02cd99fc: bl      #0x2b7105c                                 fn_2b7105c
02cd9a00: bl      #0x2b7105c                                 fn_2b7105c
02cd9a04: bl      #0x2b7105c                                 fn_2b7105c
02cd9a08: bl      #0x2b7105c                                 fn_2b7105c
02cd9a0c: mov     x0, x19                                    
02cd9a10: bl      #0x2b71054                                 fn_2b71054
02cd9a14: b       #0x2cd9a24                                 
02cd9a18: b       #0x2cd9a24                                 
02cd9a1c: b       #0x2cd9a24                                 
02cd9a20: b       #0x2cd9a24                                 
02cd9a24: mov     x20, x1                                    
02cd9a28: mov     x19, x0                                    
02cd9a2c: b       #0x2cd9a7c                                 
02cd9a30: b       #0x2cd9a40                                 
02cd9a34: b       #0x2cd9a40                                 
02cd9a38: b       #0x2cd9a40                                 
02cd9a3c: b       #0x2cd9a40                                 
02cd9a40: mov     x20, x1                                    
02cd9a44: mov     x19, x0                                    
02cd9a48: cmp     w20, #1                                    
02cd9a4c: b.ne    #0x2cd9a74                                 
02cd9a50: mov     x0, x19                                    
02cd9a54: bl      #0x5e90260                                 fn_5e90260
02cd9a58: ldr     x19, [x0]                                  &2c5bbd4(=a9bd7bfdd503233f)
02cd9a5c: str     x19, [sp, #8]                              
02cd9a60: bl      #0x5e90270                                 fn_5e90270
02cd9a64: ldr     x0, [sp, #0x10]                            
02cd9a68: b       #0x2cd99d0                                 
02cd9a6c: mov     x20, x1                                    
02cd9a70: mov     x19, x0                                    
02cd9a74: add     x0, sp, #8                                 
02cd9a78: bl      #0x2737830                                 fn_2737830
02cd9a7c: cmp     w20, #1                                    
02cd9a80: b.ne    #0x2cd9b24                                 
02cd9a84: mov     x0, x19                                    
02cd9a88: bl      #0x5e90260                                 fn_5e90260
02cd9a8c: mov     x19, x0                                    
02cd9a90: adrp    x0, #0x6263000                             
02cd9a94: ldr     x0, [x0, #0xae0]                           T:System.Exception
02cd9a98: bl      #0x2b70dc4                                 fn_2b70dc4
02cd9a9c: ldr     x8, [x19]                                  
02cd9aa0: ldr     x1, [x8]                                   S:'didu'
02cd9aa4: bl      #0x2b71464                                 fn_2b71464
02cd9aa8: tbz     w0, #0, #0x2cd9afc                         
02cd9aac: ldrsw   x20, [sp, #0x28]                           
02cd9ab0: ldr     x8, [x19]                                  
02cd9ab4: add     x9, sp, #0x20                              
02cd9ab8: str     x8, [x9, x20, lsl #3]                      
02cd9abc: add     w8, w20, #1                                
02cd9ac0: str     w8, [sp, #0x28]                            
02cd9ac4: bl      #0x5e90270                                 fn_5e90270
02cd9ac8: adrp    x0, #0x6263000                             
02cd9acc: ldr     x0, [x0, #0x928]                           T:UnityEngine.Debug
02cd9ad0: bl      #0x2b70dc4                                 fn_2b70dc4
02cd9ad4: ldr     w8, [x0, #0xe4]                            [62630e4]=0 f=0,0
02cd9ad8: cbnz    w8, #0x2cd9ae0                             
02cd9adc: bl      #0x2b70f30                                 fn_2b70f30
02cd9ae0: adrp    x0, #0x6267000                             
02cd9ae4: ldr     x0, [x0, #0xb38]                           S:'=====dev log try change material on new font text, but call 911'
02cd9ae8: bl      #0x2b70dc4                                 fn_2b70dc4
02cd9aec: mov     x1, xzr                                    
02cd9af0: bl      #0x5af2840                                 UnityEngine.Debug::LogError
02cd9af4: str     w20, [sp, #0x28]                           
02cd9af8: b       #0x2cd99e4                                 
02cd9afc: mov     w0, #8                                     
02cd9b00: bl      #0x5e90290                                 fn_5e90290
02cd9b04: ldr     x8, [x19]                                  
02cd9b08: str     x8, [x0]                                   
02cd9b0c: adrp    x1, #0x5e96000                             
02cd9b10: add     x1, x1, #0x758                             &5e96758
02cd9b14: mov     x2, xzr                                    
02cd9b18: bl      #0x5e902a0                                 fn_5e902a0
02cd9b1c: mov     x19, x0                                    
02cd9b20: bl      #0x5e90270                                 fn_5e90270
02cd9b24: mov     x0, x19                                    
02cd9b28: bl      #0x2c6051c                                 fn_2c6051c
02cd9b2c: bl      #0x27369b8                                 fn_27369b8
## ApplyFontMaterial(TMPro.TextMeshProUGUI baseText) -> void
---- LocalizeText::ApplyFontMaterial 0x2cd9c2c
02cd9c2c: sub     sp, sp, #0x90                              
02cd9c30: str     x30, [sp, #0x50]                           
02cd9c34: stp     x24, x23, [sp, #0x60]                      
02cd9c38: stp     x22, x21, [sp, #0x70]                      
02cd9c3c: stp     x20, x19, [sp, #0x80]                      
02cd9c40: adrp    x19, #0x662f000                            
02cd9c44: adrp    x22, #0x6263000                            
02cd9c48: mov     x20, x0                                    
02cd9c4c: ldrb    w8, [x19, #0xd4b]                          
02cd9c50: ldr     x22, [x22, #0x918]                         T:UnityEngine.Object
02cd9c54: tbnz    w8, #0, #0x2cd9ca8                         
02cd9c58: adrp    x0, #0x6267000                             
02cd9c5c: ldr     x0, [x0, #0xb18]                           MS:System.Collections.Generic.List`1/Enumerator::Dispose
02cd9c60: bl      #0x2b70db0                                 fn_2b70db0
02cd9c64: adrp    x0, #0x6267000                             
02cd9c68: ldr     x0, [x0, #0xb20]                           MS:System.Collections.Generic.List`1/Enumerator::MoveNext
02cd9c6c: bl      #0x2b70db0                                 fn_2b70db0
02cd9c70: adrp    x0, #0x6267000                             
02cd9c74: ldr     x0, [x0, #0xb28]                           MS:System.Collections.Generic.List`1/Enumerator::get_Current
02cd9c78: bl      #0x2b70db0                                 fn_2b70db0
02cd9c7c: adrp    x0, #0x6267000                             
02cd9c80: ldr     x0, [x0, #0xb30]                           MS:System.Collections.Generic.List`1::GetEnumerator
02cd9c84: bl      #0x2b70db0                                 fn_2b70db0
02cd9c88: adrp    x0, #0x6267000                             
02cd9c8c: ldr     x0, [x0, #0x188]                           T:UnityEngine.Material
02cd9c90: bl      #0x2b70db0                                 fn_2b70db0
02cd9c94: adrp    x0, #0x6263000                             
02cd9c98: ldr     x0, [x0, #0x918]                           T:UnityEngine.Object
02cd9c9c: bl      #0x2b70db0                                 fn_2b70db0
02cd9ca0: mov     w8, #1                                     
02cd9ca4: strb    w8, [x19, #0xd4b]                          
02cd9ca8: ldr     x0, [x22]                                  &2c5bbd4(=a9bd7bfdd503233f)
02cd9cac: stp     xzr, xzr, [sp, #0x30]                      
02cd9cb0: str     xzr, [sp, #0x40]                           
02cd9cb4: ldr     w8, [x0, #0xe4]                            [62630e4]=0 f=0,0
02cd9cb8: str     wzr, [sp, #0x28]                           
02cd9cbc: cbnz    w8, #0x2cd9cc4                             
02cd9cc0: bl      #0x2b70f30                                 fn_2b70f30
02cd9cc4: mov     x0, x20                                    
02cd9cc8: mov     x1, xzr                                    
02cd9ccc: mov     x2, xzr                                    
02cd9cd0: bl      #0x5b37d84                                 UnityEngine.Object::op_Equality
02cd9cd4: tbnz    w0, #0, #0x2cd9dc4                         
02cd9cd8: cbz     x20, #0x2cd9de0                            
02cd9cdc: ldr     x8, [x20]                                  
02cd9ce0: ldr     x1, [x8, #0x570]                           
02cd9ce4: ldr     x9, [x8, #0x568]                           
02cd9ce8: mov     x0, x20                                    
02cd9cec: blr     x9                                         
02cd9cf0: ldr     x8, [x20, #0xf8]                           
02cd9cf4: cbz     x8, #0x2cd9de4                             
02cd9cf8: mov     x19, x0                                    
02cd9cfc: ldr     x0, [x8, #0x188]                           
02cd9d00: cbz     x0, #0x2cd9de8                             
02cd9d04: adrp    x8, #0x6267000                             
02cd9d08: ldr     x8, [x8, #0xb30]                           MS:System.Collections.Generic.List`1::GetEnumerator
02cd9d0c: ldr     x1, [x8]                                   S:'didu'
02cd9d10: add     x8, sp, #8                                 
02cd9d14: bl      #0x35a9d9c                                 fn_35a9d9c
02cd9d18: ldur    q0, [sp, #8]                               
02cd9d1c: ldr     x8, [sp, #0x18]                            
02cd9d20: adrp    x23, #0x6267000                            
02cd9d24: adrp    x24, #0x6267000                            
02cd9d28: add     x9, sp, #0x30                              
02cd9d2c: str     q0, [sp, #0x30]                            
02cd9d30: ldr     x23, [x23, #0xb20]                         MS:System.Collections.Generic.List`1/Enumerator::MoveNext
02cd9d34: str     x8, [sp, #0x40]                            
02cd9d38: ldr     x24, [x24, #0x188]                         T:UnityEngine.Material
02cd9d3c: stp     xzr, x9, [sp, #8]                          
02cd9d40: ldr     x1, [x23]                                  S:'didu'
02cd9d44: add     x0, sp, #0x30                              
02cd9d48: bl      #0x4690474                                 fn_4690474
02cd9d4c: tbz     w0, #0, #0x2cd9da8                         
02cd9d50: ldr     x0, [x22]                                  &2c5bbd4(=a9bd7bfdd503233f)
02cd9d54: ldr     x20, [sp, #0x40]                           
02cd9d58: ldr     w8, [x0, #0xe4]                            [62630e4]=0 f=0,0
02cd9d5c: cbnz    w8, #0x2cd9d64                             
02cd9d60: bl      #0x2b70f30                                 fn_2b70f30
02cd9d64: mov     x0, x20                                    
02cd9d68: mov     x1, xzr                                    
02cd9d6c: mov     x2, xzr                                    
02cd9d70: bl      #0x5b3666c                                 UnityEngine.Object::op_Inequality
02cd9d74: tbz     w0, #0, #0x2cd9d40                         
02cd9d78: ldr     x0, [x24]                                  S:'didu'
02cd9d7c: bl      #0x2b7104c                                 fn_2b7104c
02cd9d80: mov     x1, x19                                    
02cd9d84: mov     x2, xzr                                    
02cd9d88: mov     x21, x0                                    
02cd9d8c: bl      #0x5b05e18                                 UnityEngine.Material::.ctor
02cd9d90: cbz     x20, #0x2cd9ddc                            
02cd9d94: str     x21, [x20, #0x88]!                         
02cd9d98: mov     x0, x20                                    
02cd9d9c: mov     x1, x21                                    
02cd9da0: bl      #0x2b70d54                                 fn_2b70d54
02cd9da4: b       #0x2cd9d40                                 
02cd9da8: mov     x19, xzr                                   
02cd9dac: add     x0, sp, #0x30                              
02cd9db0: adrp    x8, #0x6267000                             
02cd9db4: ldr     x8, [x8, #0xb18]                           MS:System.Collections.Generic.List`1/Enumerator::Dispose
02cd9db8: ldr     x1, [x8]                                   S:'didu'
02cd9dbc: bl      #0x4690470                                 fn_4690470
02cd9dc0: cbnz    x19, #0x2cd9dec                            
02cd9dc4: ldp     x20, x19, [sp, #0x80]                      
02cd9dc8: ldr     x30, [sp, #0x50]                           
02cd9dcc: ldp     x22, x21, [sp, #0x70]                      
02cd9dd0: ldp     x24, x23, [sp, #0x60]                      
02cd9dd4: add     sp, sp, #0x90                              
02cd9dd8: ret                                                
02cd9ddc: bl      #0x2b7105c                                 fn_2b7105c
02cd9de0: bl      #0x2b7105c                                 fn_2b7105c
02cd9de4: bl      #0x2b7105c                                 fn_2b7105c
02cd9de8: bl      #0x2b7105c                                 fn_2b7105c
02cd9dec: mov     x0, x19                                    
02cd9df0: bl      #0x2b71054                                 fn_2b71054
02cd9df4: b       #0x2cd9e08                                 
02cd9df8: b       #0x2cd9e08                                 
02cd9dfc: b       #0x2cd9e08                                 
02cd9e00: b       #0x2cd9e08                                 
02cd9e04: b       #0x2cd9e08                                 
02cd9e08: mov     x19, x1                                    
02cd9e0c: mov     x20, x0                                    
02cd9e10: b       #0x2cd9e58                                 
02cd9e14: b       #0x2cd9e24                                 
02cd9e18: b       #0x2cd9e24                                 
02cd9e1c: b       #0x2cd9e24                                 
02cd9e20: b       #0x2cd9e24                                 
02cd9e24: mov     x20, x0                                    
02cd9e28: cmp     w1, #1                                     
02cd9e2c: b.ne    #0x2cd9e4c                                 
02cd9e30: mov     x0, x20                                    
02cd9e34: bl      #0x5e90260                                 fn_5e90260
02cd9e38: ldr     x19, [x0]                                  &2c5bbd4(=a9bd7bfdd503233f)
02cd9e3c: str     x19, [sp, #8]                              
02cd9e40: bl      #0x5e90270                                 fn_5e90270
02cd9e44: ldr     x0, [sp, #0x10]                            
02cd9e48: b       #0x2cd9db0                                 
02cd9e4c: mov     x19, x1                                    
02cd9e50: add     x0, sp, #8                                 
02cd9e54: bl      #0x2737830                                 fn_2737830
02cd9e58: cmp     w19, #1                                    
02cd9e5c: b.ne    #0x2cd9f0c                                 
02cd9e60: mov     x0, x20                                    
02cd9e64: bl      #0x5e90260                                 fn_5e90260
02cd9e68: mov     x19, x0                                    
02cd9e6c: adrp    x0, #0x6263000                             
02cd9e70: ldr     x0, [x0, #0xae0]                           T:System.Exception
02cd9e74: bl      #0x2b70dc4                                 fn_2b70dc4
02cd9e78: ldr     x8, [x19]                                  &2b706c4(=eb01011ff9400808)
02cd9e7c: ldr     x1, [x8]                                   S:'didu'
02cd9e80: bl      #0x2b71464                                 fn_2b71464
02cd9e84: tbz     w0, #0, #0x2cd9ed8                         
02cd9e88: ldrsw   x20, [sp, #0x28]                           
02cd9e8c: ldr     x8, [x19]                                  &2b706c4(=eb01011ff9400808)
02cd9e90: add     x9, sp, #0x20                              
02cd9e94: str     x8, [x9, x20, lsl #3]                      
02cd9e98: add     w8, w20, #1                                
02cd9e9c: str     w8, [sp, #0x28]                            
02cd9ea0: bl      #0x5e90270                                 fn_5e90270
02cd9ea4: adrp    x0, #0x6263000                             
02cd9ea8: ldr     x0, [x0, #0x928]                           T:UnityEngine.Debug
02cd9eac: bl      #0x2b70dc4                                 fn_2b70dc4
02cd9eb0: ldr     w8, [x0, #0xe4]                            [62630e4]=0 f=0,0
02cd9eb4: cbnz    w8, #0x2cd9ebc                             
02cd9eb8: bl      #0x2b70f30                                 fn_2b70f30
02cd9ebc: adrp    x0, #0x6267000                             
02cd9ec0: ldr     x0, [x0, #0xb38]                           S:'=====dev log try change material on new font text, but call 911'
02cd9ec4: bl      #0x2b70dc4                                 fn_2b70dc4
02cd9ec8: mov     x1, xzr                                    
02cd9ecc: bl      #0x5af2840                                 UnityEngine.Debug::LogError
02cd9ed0: str     w20, [sp, #0x28]                           
02cd9ed4: b       #0x2cd9dc4                                 
02cd9ed8: mov     w0, #8                                     
02cd9edc: bl      #0x5e90290                                 fn_5e90290
02cd9ee0: ldr     x8, [x19]                                  &2b706c4(=eb01011ff9400808)
02cd9ee4: str     x8, [x0]                                   
02cd9ee8: adrp    x1, #0x5e96000                             
02cd9eec: add     x1, x1, #0x758                             &5e96758
02cd9ef0: mov     x2, xzr                                    
02cd9ef4: bl      #0x5e902a0                                 fn_5e902a0
02cd9ef8: mov     x19, x1                                    
02cd9efc: mov     x20, x0                                    
02cd9f00: b       #0x2cd9e50                                 
02cd9f04: mov     x20, x0                                    
02cd9f08: bl      #0x5e90270                                 fn_5e90270
02cd9f0c: mov     x0, x20                                    
02cd9f10: bl      #0x2c6051c                                 fn_2c6051c
02cd9f14: bl      #0x27369b8                                 fn_27369b8
## .ctor() -> void
---- LocalizeText::.ctor 0x2cd9f18
02cd9f18: mov     x1, xzr                                    
02cd9f1c: b       #0x5b397b0                                 UnityEngine.MonoBehaviour::.ctor
