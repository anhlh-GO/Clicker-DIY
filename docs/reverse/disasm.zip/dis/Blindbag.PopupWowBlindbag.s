#### CLASS Blindbag.PopupWowBlindbag parent= PopupBase
#   field _fx                            AssetKits.ParticleImage.ParticleImage              off=0x38 attr=1 SerializeField
#   field _tfContentNormal               UnityEngine.Transform                              off=0x40 attr=1 SerializeField
#   field _tfContentGetOneMore           UnityEngine.Transform                              off=0x48 attr=1 SerializeField
#   field _txtReaction                   TMPro.TextMeshProUGUI                              off=0x50 attr=1 SerializeField
#   field _reactionText                  System.Collections.Generic.List`1<string>          off=0x58 attr=1 SerializeField
## ShowGetOneMore(bool isTrue) -> void
---- Blindbag.PopupWowBlindbag::ShowGetOneMore 0x2d586fc
02d586fc: str     d8, [sp, #-0x30]!                          
02d58700: str     x30, [sp, #8]                              
02d58704: stp     x22, x21, [sp, #0x10]                      
02d58708: stp     x20, x19, [sp, #0x20]                      
02d5870c: adrp    x21, #0x6630000                            
02d58710: mov     w20, w1                                    
02d58714: mov     x19, x0                                    
02d58718: ldrb    w8, [x21, #0x2a1]                          
02d5871c: tbnz    w8, #0, #0x2d58758                         
02d58720: adrp    x0, #0x626a000                             
02d58724: ldr     x0, [x0, #0x668]                           MS:System.Collections.Generic.List`1::get_Count
02d58728: bl      #0x2b70db0                                 fn_2b70db0
02d5872c: adrp    x0, #0x626a000                             
02d58730: ldr     x0, [x0, #0x670]                           MS:System.Collections.Generic.List`1::get_Item
02d58734: bl      #0x2b70db0                                 fn_2b70db0
02d58738: adrp    x0, #0x6266000                             
02d5873c: ldr     x0, [x0, #0x9f0]                           T:Assets.SimpleLocalization.Scripts.LocalizationManager
02d58740: bl      #0x2b70db0                                 fn_2b70db0
02d58744: adrp    x0, #0x6266000                             
02d58748: ldr     x0, [x0, #0x880]                           MS:DG.Tweening.TweenSettingsExtensions::SetEase
02d5874c: bl      #0x2b70db0                                 fn_2b70db0
02d58750: mov     w8, #1                                     
02d58754: strb    w8, [x21, #0x2a1]                          
02d58758: ldr     x0, [x19, #0x40]                           ._tfContentNormal
02d5875c: cbz     x0, #0x2d588c8                             
02d58760: mov     x1, xzr                                    
02d58764: bl      #0x5b339ec                                 UnityEngine.Component::get_gameObject
02d58768: cbz     x0, #0x2d588c8                             
02d5876c: mov     w8, #1                                     
02d58770: mov     x2, xzr                                    
02d58774: bic     w1, w8, w20                                
02d58778: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d5877c: ldr     x0, [x19, #0x48]                           ._tfContentGetOneMore
02d58780: cbz     x0, #0x2d588c8                             
02d58784: mov     x1, xzr                                    
02d58788: bl      #0x5b339ec                                 UnityEngine.Component::get_gameObject
02d5878c: cbz     x0, #0x2d588c8                             
02d58790: adrp    x21, #0x6266000                            
02d58794: and     w1, w20, #1                                
02d58798: mov     x2, xzr                                    
02d5879c: ldr     x21, [x21, #0x880]                         MS:DG.Tweening.TweenSettingsExtensions::SetEase
02d587a0: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d587a4: ldr     x0, [x19, #0x40]                           ._tfContentNormal
02d587a8: mov     w1, wzr                                    
02d587ac: mov     x2, xzr                                    
02d587b0: bl      #0x2d9d5d0                                 DG.Tweening.ShortcutExtensions::DOKill
02d587b4: ldr     x0, [x19, #0x48]                           ._tfContentGetOneMore
02d587b8: mov     w1, wzr                                    
02d587bc: mov     x2, xzr                                    
02d587c0: bl      #0x2d9d5d0                                 DG.Tweening.ShortcutExtensions::DOKill
02d587c4: adrp    x8, #0x1084000                             
02d587c8: fmov    s0, #1.00000000                            
02d587cc: ldr     x0, [x19, #0x40]                           ._tfContentNormal
02d587d0: ldr     s8, [x8, #0xf10]                           [1084f10]=4110bc863e99999a f=0.3,9.04603
02d587d4: mov     x1, xzr                                    
02d587d8: fmov    s1, s8                                     
02d587dc: bl      #0x2d98c98                                 DG.Tweening.ShortcutExtensions::DOScale
02d587e0: ldr     x2, [x21]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d587e4: mov     w1, #0x1b                                  
02d587e8: bl      #0x336fa0c                                 fn_336fa0c
02d587ec: fmov    s1, s8                                     
02d587f0: fmov    s0, #1.00000000                            
02d587f4: ldr     x0, [x19, #0x48]                           ._tfContentGetOneMore
02d587f8: mov     x1, xzr                                    
02d587fc: bl      #0x2d98c98                                 DG.Tweening.ShortcutExtensions::DOScale
02d58800: ldr     x2, [x21]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d58804: mov     w1, #0x1b                                  
02d58808: bl      #0x336fa0c                                 fn_336fa0c
02d5880c: ldr     x0, [x19, #0x38]                           ._fx
02d58810: cbz     x0, #0x2d588c8                             
02d58814: mov     x1, xzr                                    
02d58818: bl      #0x5b339ec                                 UnityEngine.Component::get_gameObject
02d5881c: cbz     x0, #0x2d588c8                             
02d58820: mov     w1, #1                                     
02d58824: mov     x2, xzr                                    
02d58828: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d5882c: ldr     x0, [x19, #0x38]                           ._fx
02d58830: cbz     x0, #0x2d588c8                             
02d58834: mov     x1, xzr                                    
02d58838: bl      #0x4f86b74                                 AssetKits.ParticleImage.ParticleImage::Play
02d5883c: ldr     x20, [x19, #0x58]                          ._reactionText
02d58840: cbz     x20, #0x2d588c8                            
02d58844: adrp    x21, #0x626a000                            
02d58848: adrp    x22, #0x6266000                            
02d5884c: mov     w0, wzr                                    
02d58850: ldr     x21, [x21, #0x670]                         MS:System.Collections.Generic.List`1::get_Item
02d58854: ldr     x22, [x22, #0x9f0]                         T:Assets.SimpleLocalization.Scripts.LocalizationManager
02d58858: ldr     w1, [x20, #0x18]                           
02d5885c: ldr     x19, [x19, #0x50]                          ._txtReaction
02d58860: mov     x2, xzr                                    
02d58864: bl      #0x5b2e000                                 UnityEngine.Random::Range
02d58868: ldr     x2, [x21]                                  T:type56879(k15)
02d5886c: mov     w1, w0                                     
02d58870: mov     x0, x20                                    
02d58874: bl      #0x35a8f3c                                 fn_35a8f3c
02d58878: ldr     x8, [x22]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d5887c: mov     x20, x0                                    
02d58880: ldr     w9, [x8, #0xe4]                            [10840e4]=2c2644327265746c f=4.54482e+30,2.36279e-12
02d58884: cbnz    w9, #0x2d58890                             
02d58888: mov     x0, x8                                     
02d5888c: bl      #0x2b70f30                                 fn_2b70f30
02d58890: mov     x0, x20                                    
02d58894: mov     x1, xzr                                    
02d58898: bl      #0x2d76794                                 Assets.SimpleLocalization.Scripts.LocalizationManager::Localize
02d5889c: cbz     x19, #0x2d588c8                            
02d588a0: ldr     x8, [x19]                                  
02d588a4: mov     x1, x0                                     
02d588a8: mov     x0, x19                                    
02d588ac: ldp     x20, x19, [sp, #0x20]                      
02d588b0: ldr     x30, [sp, #8]                              
02d588b4: ldp     x22, x21, [sp, #0x10]                      
02d588b8: ldr     x2, [x8, #0x560]                           [1084560]=69676e457974696e f=7.93162e+34,1.74864e+25
02d588bc: ldr     x3, [x8, #0x558]                           [1084558]=5500292632726f74 f=1.41116e-08,8.80714e+12
02d588c0: ldr     d8, [sp], #0x30                            
02d588c4: br      x3                                         
02d588c8: bl      #0x2b7105c                                 fn_2b7105c
## OnHide() -> void
---- Blindbag.PopupWowBlindbag::OnHide 0x2d588cc
02d588cc: str     d8, [sp, #-0x40]!                          
02d588d0: str     x30, [sp, #8]                              
02d588d4: stp     x24, x23, [sp, #0x10]                      
02d588d8: stp     x22, x21, [sp, #0x20]                      
02d588dc: stp     x20, x19, [sp, #0x30]                      
02d588e0: adrp    x23, #0x6266000                            
02d588e4: adrp    x24, #0x6630000                            
02d588e8: adrp    x20, #0x6264000                            
02d588ec: adrp    x21, #0x626b000                            
02d588f0: adrp    x22, #0x6266000                            
02d588f4: ldr     x23, [x23, #0x880]                         MS:DG.Tweening.TweenSettingsExtensions::SetEase
02d588f8: ldr     x20, [x20, #0xe8]                          T:DG.Tweening.TweenCallback
02d588fc: ldrb    w8, [x24, #0x2a2]                          
02d58900: ldr     x21, [x21, #0xaa8]                         M:Blindbag.PopupWowBlindbag::<OnHide>b__6_0
02d58904: ldr     x22, [x22, #0x928]                         MS:DG.Tweening.TweenSettingsExtensions::OnComplete
02d58908: mov     x19, x0                                    
02d5890c: tbnz    w8, #0, #0x2d58948                         
02d58910: adrp    x0, #0x626b000                             
02d58914: ldr     x0, [x0, #0xaa8]                           M:Blindbag.PopupWowBlindbag::<OnHide>b__6_0
02d58918: bl      #0x2b70db0                                 fn_2b70db0
02d5891c: adrp    x0, #0x6264000                             
02d58920: ldr     x0, [x0, #0xe8]                            T:DG.Tweening.TweenCallback
02d58924: bl      #0x2b70db0                                 fn_2b70db0
02d58928: adrp    x0, #0x6266000                             
02d5892c: ldr     x0, [x0, #0x928]                           MS:DG.Tweening.TweenSettingsExtensions::OnComplete
02d58930: bl      #0x2b70db0                                 fn_2b70db0
02d58934: adrp    x0, #0x6266000                             
02d58938: ldr     x0, [x0, #0x880]                           MS:DG.Tweening.TweenSettingsExtensions::SetEase
02d5893c: bl      #0x2b70db0                                 fn_2b70db0
02d58940: mov     w8, #1                                     
02d58944: strb    w8, [x24, #0x2a2]                          
02d58948: ldr     x0, [x19, #0x40]                           ._tfContentNormal
02d5894c: mov     w1, wzr                                    
02d58950: mov     x2, xzr                                    
02d58954: bl      #0x2d9d5d0                                 DG.Tweening.ShortcutExtensions::DOKill
02d58958: ldr     x0, [x19, #0x48]                           ._tfContentGetOneMore
02d5895c: mov     w1, wzr                                    
02d58960: mov     x2, xzr                                    
02d58964: bl      #0x2d9d5d0                                 DG.Tweening.ShortcutExtensions::DOKill
02d58968: adrp    x8, #0x1084000                             
02d5896c: movi    d0, #0000000000000000                      
02d58970: ldr     x0, [x19, #0x40]                           ._tfContentNormal
02d58974: ldr     s8, [x8, #0xf10]                           [1084f10]=4110bc863e99999a f=0.3,9.04603
02d58978: mov     x1, xzr                                    
02d5897c: fmov    s1, s8                                     
02d58980: bl      #0x2d98c98                                 DG.Tweening.ShortcutExtensions::DOScale
02d58984: ldr     x2, [x23]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d58988: mov     w1, #0x1a                                  
02d5898c: bl      #0x336fa0c                                 fn_336fa0c
02d58990: movi    d0, #0000000000000000                      
02d58994: fmov    s1, s8                                     
02d58998: ldr     x0, [x19, #0x48]                           ._tfContentGetOneMore
02d5899c: mov     x1, xzr                                    
02d589a0: bl      #0x2d98c98                                 DG.Tweening.ShortcutExtensions::DOScale
02d589a4: ldr     x2, [x23]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d589a8: mov     w1, #0x1a                                  
02d589ac: bl      #0x336fa0c                                 fn_336fa0c
02d589b0: ldr     x8, [x20]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d589b4: mov     x20, x0                                    
02d589b8: mov     x0, x8                                     
02d589bc: bl      #0x2b7104c                                 fn_2b7104c
02d589c0: ldr     x2, [x21]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d589c4: mov     x1, x19                                    
02d589c8: mov     x3, xzr                                    
02d589cc: mov     x21, x0                                    
02d589d0: bl      #0x2d89dc4                                 DG.Tweening.TweenCallback::.ctor
02d589d4: ldr     x2, [x22]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d589d8: mov     x0, x20                                    
02d589dc: mov     x1, x21                                    
02d589e0: ldp     x20, x19, [sp, #0x30]                      
02d589e4: ldr     x30, [sp, #8]                              
02d589e8: ldp     x22, x21, [sp, #0x20]                      
02d589ec: ldp     x24, x23, [sp, #0x10]                      
02d589f0: ldr     d8, [sp], #0x40                            
02d589f4: b       #0x336f26c                                 
## .ctor() -> void
---- Blindbag.PopupWowBlindbag::.ctor 0x2d589f8
02d589f8: mov     x1, xzr                                    
02d589fc: b       #0x2cddba8                                 PopupBase::.ctor
## <OnHide>b__6_0() -> void
---- Blindbag.PopupWowBlindbag::<OnHide>b__6_0 0x2d58a00
02d58a00: stp     x30, x19, [sp, #-0x10]!                    
02d58a04: mov     x1, xzr                                    
02d58a08: mov     x19, x0                                    
02d58a0c: bl      #0x2cddc10                                 UIBase::OnHide
02d58a10: ldr     x0, [x19, #0x38]                           ._fx
02d58a14: cbz     x0, #0x2d58a44                             
02d58a18: mov     x1, xzr                                    
02d58a1c: bl      #0x5b339ec                                 UnityEngine.Component::get_gameObject
02d58a20: cbz     x0, #0x2d58a44                             
02d58a24: mov     w1, wzr                                    
02d58a28: mov     x2, xzr                                    
02d58a2c: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d58a30: ldr     x0, [x19, #0x38]                           ._fx
02d58a34: cbz     x0, #0x2d58a44                             
02d58a38: mov     x1, xzr                                    
02d58a3c: ldp     x30, x19, [sp], #0x10                      
02d58a40: b       #0x4f871ec                                 AssetKits.ParticleImage.ParticleImage::Stop
02d58a44: bl      #0x2b7105c                                 fn_2b7105c
