#### CLASS IAPKey parent= int
#   field value__                        int                                                off=0x10 attr=606 
#   field dumbling_normal_pack           IAPKey                                             off=0x0 attr=8056 
#   field dumbling_special_pack          IAPKey                                             off=0x0 attr=8056 
