#### CLASS RewardMysteryBox parent= object
#   field IsCoin                         bool                                               off=0x10 attr=6 
#   field Value                          int                                                off=0x14 attr=6 
## .ctor() -> void
---- RewardMysteryBox::.ctor 0x2ce1754
02ce1754: mov     x1, xzr                                    
02ce1758: b       #0x4e53e9c                                 System.Object::.ctor
