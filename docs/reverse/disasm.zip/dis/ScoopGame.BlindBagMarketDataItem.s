#### CLASS ScoopGame.BlindBagMarketDataItem parent= object
#   field ID                             int                                                off=0x10 attr=6 
#   field BuyType                        Games.Common.EUnlockType                           off=0x14 attr=6 
#   field Price                          int                                                off=0x18 attr=6 
#   field Name                           string                                             off=0x20 attr=6 
## .ctor() -> void
---- ScoopGame.BlindBagMarketDataItem::.ctor 0x2d3c09c
02d3c09c: mov     x1, xzr                                    
02d3c0a0: b       #0x4e53e9c                                 System.Object::.ctor
