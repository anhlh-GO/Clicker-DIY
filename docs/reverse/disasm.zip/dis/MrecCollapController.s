#### CLASS MrecCollapController/<IAutoHide>d__13 parent= object
#   field <>1__state                     int                                                off=0x10 attr=1 
#   field <>2__current                   object                                             off=0x18 attr=1 
#   field <>4__this                      MrecCollapController                               off=0x20 attr=6 
## .ctor(int <>1__state) -> void
---- MrecCollapController/<IAutoHide>d__13::.ctor 0x2c8e9cc
02c8e9cc: str     x30, [sp, #-0x20]!                         
02c8e9d0: stp     x20, x19, [sp, #0x10]                      
02c8e9d4: mov     w19, w1                                    
02c8e9d8: mov     x1, xzr                                    
02c8e9dc: mov     x20, x0                                    
02c8e9e0: bl      #0x4e53e9c                                 System.Object::.ctor
02c8e9e4: str     w19, [x20, #0x10]                          .<>1__state
02c8e9e8: ldp     x20, x19, [sp, #0x10]                      
02c8e9ec: ldr     x30, [sp], #0x20                           
02c8e9f0: ret                                                
## System.IDisposable.Dispose() -> void
---- MrecCollapController/<IAutoHide>d__13::System.IDisposable.Dispose 0x2c8ead8
02c8ead8: ret                                                
## MoveNext() -> bool
---- MrecCollapController/<IAutoHide>d__13::MoveNext 0x2c8eadc
02c8eadc: stp     x30, x21, [sp, #-0x20]!                    
02c8eae0: stp     x20, x19, [sp, #0x10]                      
02c8eae4: adrp    x20, #0x662f000                            
02c8eae8: mov     x19, x0                                    
02c8eaec: ldrb    w8, [x20, #0x9aa]                          
02c8eaf0: tbnz    w8, #0, #0x2c8eb08                         
02c8eaf4: adrp    x0, #0x6264000                             
02c8eaf8: ldr     x0, [x0, #0xf58]                           T:UnityEngine.WaitForSeconds
02c8eafc: bl      #0x2b70db0                                 fn_2b70db0
02c8eb00: mov     w8, #1                                     
02c8eb04: strb    w8, [x20, #0x9aa]                          
02c8eb08: ldr     w21, [x19, #0x10]                          .<>1__state
02c8eb0c: cbz     w21, #0x2c8eb34                            
02c8eb10: cmp     w21, #1                                    
02c8eb14: b.ne    #0x2c8eb78                                 
02c8eb18: ldr     x0, [x19, #0x20]                           .<>4__this
02c8eb1c: mov     w8, #-1                                    
02c8eb20: str     w8, [x19, #0x10]                           .<>1__state
02c8eb24: cbz     x0, #0x2c8eb8c                             
02c8eb28: mov     w1, wzr                                    
02c8eb2c: bl      #0x2c8e7d0                                 MrecCollapController::HideAd
02c8eb30: b       #0x2c8eb78                                 
02c8eb34: adrp    x8, #0x6264000                             
02c8eb38: mov     w9, #-1                                    
02c8eb3c: ldr     x8, [x8, #0xf58]                           T:UnityEngine.WaitForSeconds
02c8eb40: str     w9, [x19, #0x10]                           .<>1__state
02c8eb44: ldr     x0, [x8]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c8eb48: bl      #0x2b7104c                                 fn_2b7104c
02c8eb4c: mov     w8, #0x42c80000                            
02c8eb50: mov     x1, xzr                                    
02c8eb54: mov     x20, x0                                    
02c8eb58: fmov    s0, w8                                     
02c8eb5c: bl      #0x5b3e5e8                                 UnityEngine.WaitForSeconds::.ctor
02c8eb60: mov     x0, x19                                    
02c8eb64: mov     x1, x20                                    
02c8eb68: str     x20, [x0, #0x18]!                          .<>2__current
02c8eb6c: bl      #0x2b70d54                                 fn_2b70d54
02c8eb70: mov     w8, #1                                     
02c8eb74: str     w8, [x19, #0x10]                           .<>1__state
02c8eb78: ldp     x20, x19, [sp, #0x10]                      
02c8eb7c: cmp     w21, #0                                    
02c8eb80: cset    w0, eq                                     
02c8eb84: ldp     x30, x21, [sp], #0x20                      
02c8eb88: ret                                                
02c8eb8c: bl      #0x2b7105c                                 fn_2b7105c
## System.Collections.Generic.IEnumerator<System.Object>.get_Current() -> object
---- MrecCollapController/<IAutoHide>d__13::System.Collections.Generic.IEnumerator<System.Object>.get_Current 0x2c8eb90
02c8eb90: ldr     x0, [x0, #0x18]                            .<>2__current
02c8eb94: ret                                                
## System.Collections.IEnumerator.Reset() -> void
---- MrecCollapController/<IAutoHide>d__13::System.Collections.IEnumerator.Reset 0x2c8eb98
02c8eb98: stp     x30, x19, [sp, #-0x10]!                    
02c8eb9c: adrp    x0, #0x6264000                             
02c8eba0: ldr     x0, [x0, #0xf60]                           T:System.NotSupportedException
02c8eba4: bl      #0x2b70dc4                                 fn_2b70dc4
02c8eba8: bl      #0x2b7104c                                 fn_2b7104c
02c8ebac: mov     x1, xzr                                    
02c8ebb0: mov     x19, x0                                    
02c8ebb4: bl      #0x4e14238                                 System.NotSupportedException::.ctor
02c8ebb8: adrp    x0, #0x6265000                             
02c8ebbc: ldr     x0, [x0, #0x418]                           M:MrecCollapController/<IAutoHide>d__13::System.Collections.IEnumerator.Reset
02c8ebc0: bl      #0x2b70dc4                                 fn_2b70dc4
02c8ebc4: mov     x1, x0                                     
02c8ebc8: mov     x0, x19                                    
02c8ebcc: bl      #0x2b70f20                                 fn_2b70f20
## System.Collections.IEnumerator.get_Current() -> object
---- MrecCollapController/<IAutoHide>d__13::System.Collections.IEnumerator.get_Current 0x2c8ebd0
02c8ebd0: ldr     x0, [x0, #0x18]                            .<>2__current
02c8ebd4: ret                                                
#### CLASS MrecCollapController/<IAutoReshown>d__16 parent= object
#   field <>1__state                     int                                                off=0x10 attr=1 
#   field <>2__current                   object                                             off=0x18 attr=1 
#   field <>4__this                      MrecCollapController                               off=0x20 attr=6 
## .ctor(int <>1__state) -> void
---- MrecCollapController/<IAutoReshown>d__16::.ctor 0x2c8ea60
02c8ea60: str     x30, [sp, #-0x20]!                         
02c8ea64: stp     x20, x19, [sp, #0x10]                      
02c8ea68: mov     w19, w1                                    
02c8ea6c: mov     x1, xzr                                    
02c8ea70: mov     x20, x0                                    
02c8ea74: bl      #0x4e53e9c                                 System.Object::.ctor
02c8ea78: str     w19, [x20, #0x10]                          .<>1__state
02c8ea7c: ldp     x20, x19, [sp, #0x10]                      
02c8ea80: ldr     x30, [sp], #0x20                           
02c8ea84: ret                                                
## System.IDisposable.Dispose() -> void
---- MrecCollapController/<IAutoReshown>d__16::System.IDisposable.Dispose 0x2c8ebd8
02c8ebd8: ret                                                
## MoveNext() -> bool
---- MrecCollapController/<IAutoReshown>d__16::MoveNext 0x2c8ebdc
02c8ebdc: stp     x30, x21, [sp, #-0x20]!                    
02c8ebe0: stp     x20, x19, [sp, #0x10]                      
02c8ebe4: adrp    x20, #0x662f000                            
02c8ebe8: mov     x19, x0                                    
02c8ebec: ldrb    w8, [x20, #0x9ab]                          
02c8ebf0: tbnz    w8, #0, #0x2c8ec08                         
02c8ebf4: adrp    x0, #0x6264000                             
02c8ebf8: ldr     x0, [x0, #0xf58]                           T:UnityEngine.WaitForSeconds
02c8ebfc: bl      #0x2b70db0                                 fn_2b70db0
02c8ec00: mov     w8, #1                                     
02c8ec04: strb    w8, [x20, #0x9ab]                          
02c8ec08: ldr     w21, [x19, #0x10]                          .<>1__state
02c8ec0c: cbz     w21, #0x2c8ec48                            
02c8ec10: cmp     w21, #1                                    
02c8ec14: b.ne    #0x2c8ec8c                                 
02c8ec18: ldr     x20, [x19, #0x20]                          .<>4__this
02c8ec1c: mov     w8, #-1                                    
02c8ec20: str     w8, [x19, #0x10]                           .<>1__state
02c8ec24: cbz     x20, #0x2c8eca0                            
02c8ec28: mov     x0, x20                                    
02c8ec2c: mov     w1, wzr                                    
02c8ec30: bl      #0x2c8e728                                 MrecCollapController::ShowAdAfterDelay
02c8ec34: mov     x1, x0                                     
02c8ec38: mov     x0, x20                                    
02c8ec3c: mov     x2, xzr                                    
02c8ec40: bl      #0x5b389f0                                 UnityEngine.MonoBehaviour::StartCoroutine
02c8ec44: b       #0x2c8ec8c                                 
02c8ec48: adrp    x8, #0x6264000                             
02c8ec4c: mov     w9, #-1                                    
02c8ec50: ldr     x8, [x8, #0xf58]                           T:UnityEngine.WaitForSeconds
02c8ec54: str     w9, [x19, #0x10]                           .<>1__state
02c8ec58: ldr     x0, [x8]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c8ec5c: bl      #0x2b7104c                                 fn_2b7104c
02c8ec60: mov     w8, #0x42c80000                            
02c8ec64: mov     x1, xzr                                    
02c8ec68: mov     x20, x0                                    
02c8ec6c: fmov    s0, w8                                     
02c8ec70: bl      #0x5b3e5e8                                 UnityEngine.WaitForSeconds::.ctor
02c8ec74: mov     x0, x19                                    
02c8ec78: mov     x1, x20                                    
02c8ec7c: str     x20, [x0, #0x18]!                          .<>2__current
02c8ec80: bl      #0x2b70d54                                 fn_2b70d54
02c8ec84: mov     w8, #1                                     
02c8ec88: str     w8, [x19, #0x10]                           .<>1__state
02c8ec8c: ldp     x20, x19, [sp, #0x10]                      
02c8ec90: cmp     w21, #0                                    
02c8ec94: cset    w0, eq                                     
02c8ec98: ldp     x30, x21, [sp], #0x20                      
02c8ec9c: ret                                                
02c8eca0: bl      #0x2b7105c                                 fn_2b7105c
## System.Collections.Generic.IEnumerator<System.Object>.get_Current() -> object
---- MrecCollapController/<IAutoReshown>d__16::System.Collections.Generic.IEnumerator<System.Object>.get_Current 0x2c8eca4
02c8eca4: ldr     x0, [x0, #0x18]                            .<>2__current
02c8eca8: ret                                                
## System.Collections.IEnumerator.Reset() -> void
---- MrecCollapController/<IAutoReshown>d__16::System.Collections.IEnumerator.Reset 0x2c8ecac
02c8ecac: stp     x30, x19, [sp, #-0x10]!                    
02c8ecb0: adrp    x0, #0x6264000                             
02c8ecb4: ldr     x0, [x0, #0xf60]                           T:System.NotSupportedException
02c8ecb8: bl      #0x2b70dc4                                 fn_2b70dc4
02c8ecbc: bl      #0x2b7104c                                 fn_2b7104c
02c8ecc0: mov     x1, xzr                                    
02c8ecc4: mov     x19, x0                                    
02c8ecc8: bl      #0x4e14238                                 System.NotSupportedException::.ctor
02c8eccc: adrp    x0, #0x6265000                             
02c8ecd0: ldr     x0, [x0, #0x420]                           M:MrecCollapController/<IAutoReshown>d__16::System.Collections.IEnumerator.Reset
02c8ecd4: bl      #0x2b70dc4                                 fn_2b70dc4
02c8ecd8: mov     x1, x0                                     
02c8ecdc: mov     x0, x19                                    
02c8ece0: bl      #0x2b70f20                                 fn_2b70f20
## System.Collections.IEnumerator.get_Current() -> object
---- MrecCollapController/<IAutoReshown>d__16::System.Collections.IEnumerator.get_Current 0x2c8ece4
02c8ece4: ldr     x0, [x0, #0x18]                            .<>2__current
02c8ece8: ret                                                
#### CLASS MrecCollapController/<ShowAdAfterDelay>d__8 parent= object
#   field <>1__state                     int                                                off=0x10 attr=1 
#   field <>2__current                   object                                             off=0x18 attr=1 
#   field <>4__this                      MrecCollapController                               off=0x20 attr=6 
#   field withoutBanner                  bool                                               off=0x28 attr=6 
## .ctor(int <>1__state) -> void
---- MrecCollapController/<ShowAdAfterDelay>d__8::.ctor 0x2c8e7a8
02c8e7a8: str     x30, [sp, #-0x20]!                         
02c8e7ac: stp     x20, x19, [sp, #0x10]                      
02c8e7b0: mov     w19, w1                                    
02c8e7b4: mov     x1, xzr                                    
02c8e7b8: mov     x20, x0                                    
02c8e7bc: bl      #0x4e53e9c                                 System.Object::.ctor
02c8e7c0: str     w19, [x20, #0x10]                          .<>1__state
02c8e7c4: ldp     x20, x19, [sp, #0x10]                      
02c8e7c8: ldr     x30, [sp], #0x20                           
02c8e7cc: ret                                                
## System.IDisposable.Dispose() -> void
---- MrecCollapController/<ShowAdAfterDelay>d__8::System.IDisposable.Dispose 0x2c8ecec
02c8ecec: ret                                                
## MoveNext() -> bool
---- MrecCollapController/<ShowAdAfterDelay>d__8::MoveNext 0x2c8ecf0
02c8ecf0: stp     x30, x21, [sp, #-0x20]!                    
02c8ecf4: stp     x20, x19, [sp, #0x10]                      
02c8ecf8: adrp    x20, #0x662f000                            
02c8ecfc: mov     x19, x0                                    
02c8ed00: ldrb    w8, [x20, #0x9ac]                          
02c8ed04: tbnz    w8, #0, #0x2c8ed1c                         
02c8ed08: adrp    x0, #0x6264000                             
02c8ed0c: ldr     x0, [x0, #0xf58]                           T:UnityEngine.WaitForSeconds
02c8ed10: bl      #0x2b70db0                                 fn_2b70db0
02c8ed14: mov     w8, #1                                     
02c8ed18: strb    w8, [x20, #0x9ac]                          
02c8ed1c: ldr     w21, [x19, #0x10]                          .<>1__state
02c8ed20: cbz     w21, #0x2c8ed34                            
02c8ed24: cmp     w21, #1                                    
02c8ed28: b.ne    #0x2c8ed78                                 
02c8ed2c: mov     w8, #-1                                    
02c8ed30: b       #0x2c8ed74                                 
02c8ed34: adrp    x8, #0x6264000                             
02c8ed38: mov     w9, #-1                                    
02c8ed3c: ldr     x8, [x8, #0xf58]                           T:UnityEngine.WaitForSeconds
02c8ed40: str     w9, [x19, #0x10]                           .<>1__state
02c8ed44: ldr     x0, [x8]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c8ed48: bl      #0x2b7104c                                 fn_2b7104c
02c8ed4c: adrp    x8, #0x1084000                             
02c8ed50: mov     x1, xzr                                    
02c8ed54: mov     x20, x0                                    
02c8ed58: ldr     s0, [x8, #0xda4]                           [1084da4]=3eb851ec3e19999a f=0.15,0.36
02c8ed5c: bl      #0x5b3e5e8                                 UnityEngine.WaitForSeconds::.ctor
02c8ed60: mov     x0, x19                                    
02c8ed64: mov     x1, x20                                    
02c8ed68: str     x20, [x0, #0x18]!                          .<>2__current
02c8ed6c: bl      #0x2b70d54                                 fn_2b70d54
02c8ed70: mov     w8, #1                                     
02c8ed74: str     w8, [x19, #0x10]                           .<>1__state
02c8ed78: ldp     x20, x19, [sp, #0x10]                      
02c8ed7c: cmp     w21, #0                                    
02c8ed80: cset    w0, eq                                     
02c8ed84: ldp     x30, x21, [sp], #0x20                      
02c8ed88: ret                                                
## System.Collections.Generic.IEnumerator<System.Object>.get_Current() -> object
---- MrecCollapController/<ShowAdAfterDelay>d__8::System.Collections.Generic.IEnumerator<System.Object>.get_Current 0x2c8ed8c
02c8ed8c: ldr     x0, [x0, #0x18]                            .<>2__current
02c8ed90: ret                                                
## System.Collections.IEnumerator.Reset() -> void
---- MrecCollapController/<ShowAdAfterDelay>d__8::System.Collections.IEnumerator.Reset 0x2c8ed94
02c8ed94: stp     x30, x19, [sp, #-0x10]!                    
02c8ed98: adrp    x0, #0x6264000                             
02c8ed9c: ldr     x0, [x0, #0xf60]                           T:System.NotSupportedException
02c8eda0: bl      #0x2b70dc4                                 fn_2b70dc4
02c8eda4: bl      #0x2b7104c                                 fn_2b7104c
02c8eda8: mov     x1, xzr                                    
02c8edac: mov     x19, x0                                    
02c8edb0: bl      #0x4e14238                                 System.NotSupportedException::.ctor
02c8edb4: adrp    x0, #0x6265000                             
02c8edb8: ldr     x0, [x0, #0x428]                           M:MrecCollapController/<ShowAdAfterDelay>d__8::System.Collections.IEnumerator.Reset
02c8edbc: bl      #0x2b70dc4                                 fn_2b70dc4
02c8edc0: mov     x1, x0                                     
02c8edc4: mov     x0, x19                                    
02c8edc8: bl      #0x2b70f20                                 fn_2b70f20
## System.Collections.IEnumerator.get_Current() -> object
---- MrecCollapController/<ShowAdAfterDelay>d__8::System.Collections.IEnumerator.get_Current 0x2c8edcc
02c8edcc: ldr     x0, [x0, #0x18]                            .<>2__current
02c8edd0: ret                                                
#### CLASS MrecCollapController parent= WejoyService.Singleton`1<MrecCollapController>
#   field canReload                      bool                                               off=0x20 attr=1 SerializeField
#   field _viewObj                       UnityEngine.GameObject                             off=0x28 attr=1 SerializeField
#   field _closeBtn                      UnityEngine.UI.Button                              off=0x30 attr=1 SerializeField
#   field _hideCoroutine                 UnityEngine.Coroutine                              off=0x38 attr=1 
#   field _reshownCoroutine              UnityEngine.Coroutine                              off=0x40 attr=1 
## OnDisable() -> void
---- MrecCollapController::OnDisable 0x2c8e5e8
02c8e5e8: stp     x30, x21, [sp, #-0x20]!                    
02c8e5ec: stp     x20, x19, [sp, #0x10]                      
02c8e5f0: adrp    x20, #0x662f000                            
02c8e5f4: mov     x19, x0                                    
02c8e5f8: ldrb    w8, [x20, #0x9a3]                          
02c8e5fc: tbnz    w8, #0, #0x2c8e620                         
02c8e600: adrp    x0, #0x6265000                             
02c8e604: ldr     x0, [x0, #0x3e8]                           M:MrecCollapController::OnCloseClick
02c8e608: bl      #0x2b70db0                                 fn_2b70db0
02c8e60c: adrp    x0, #0x6265000                             
02c8e610: ldr     x0, [x0, #0x3f0]                           T:UnityEngine.Events.UnityAction
02c8e614: bl      #0x2b70db0                                 fn_2b70db0
02c8e618: mov     w8, #1                                     
02c8e61c: strb    w8, [x20, #0x9a3]                          
02c8e620: ldr     x8, [x19, #0x30]                           ._closeBtn
02c8e624: cbz     x8, #0x2c8e674                             
02c8e628: adrp    x9, #0x6265000                             
02c8e62c: adrp    x21, #0x6265000                            
02c8e630: ldr     x9, [x9, #0x3f0]                           T:UnityEngine.Events.UnityAction
02c8e634: ldr     x21, [x21, #0x3e8]                         M:MrecCollapController::OnCloseClick
02c8e638: ldr     x20, [x8, #0x100]                          
02c8e63c: ldr     x0, [x9]                                   M:AdsManager::<OnApplicationPause>b__26_0
02c8e640: bl      #0x2b7104c                                 fn_2b7104c
02c8e644: ldr     x2, [x21]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c8e648: mov     x1, x19                                    
02c8e64c: mov     x3, xzr                                    
02c8e650: mov     x21, x0                                    
02c8e654: bl      #0x5b4cf98                                 UnityEngine.Events.UnityAction::.ctor
02c8e658: cbz     x20, #0x2c8e674                            
02c8e65c: mov     x0, x20                                    
02c8e660: ldp     x20, x19, [sp, #0x10]                      
02c8e664: mov     x1, x21                                    
02c8e668: mov     x2, xzr                                    
02c8e66c: ldp     x30, x21, [sp], #0x20                      
02c8e670: b       #0x5b4d13c                                 UnityEngine.Events.UnityEvent::RemoveListener
02c8e674: bl      #0x2b7105c                                 fn_2b7105c
## OnEnable() -> void
---- MrecCollapController::OnEnable 0x2c8e678
02c8e678: stp     x30, x21, [sp, #-0x20]!                    
02c8e67c: stp     x20, x19, [sp, #0x10]                      
02c8e680: adrp    x20, #0x662f000                            
02c8e684: mov     x19, x0                                    
02c8e688: ldrb    w8, [x20, #0x9a4]                          
02c8e68c: tbnz    w8, #0, #0x2c8e6b0                         
02c8e690: adrp    x0, #0x6265000                             
02c8e694: ldr     x0, [x0, #0x3e8]                           M:MrecCollapController::OnCloseClick
02c8e698: bl      #0x2b70db0                                 fn_2b70db0
02c8e69c: adrp    x0, #0x6265000                             
02c8e6a0: ldr     x0, [x0, #0x3f0]                           T:UnityEngine.Events.UnityAction
02c8e6a4: bl      #0x2b70db0                                 fn_2b70db0
02c8e6a8: mov     w8, #1                                     
02c8e6ac: strb    w8, [x20, #0x9a4]                          
02c8e6b0: ldr     x8, [x19, #0x30]                           ._closeBtn
02c8e6b4: cbz     x8, #0x2c8e704                             
02c8e6b8: adrp    x9, #0x6265000                             
02c8e6bc: adrp    x21, #0x6265000                            
02c8e6c0: ldr     x9, [x9, #0x3f0]                           T:UnityEngine.Events.UnityAction
02c8e6c4: ldr     x21, [x21, #0x3e8]                         M:MrecCollapController::OnCloseClick
02c8e6c8: ldr     x20, [x8, #0x100]                          
02c8e6cc: ldr     x0, [x9]                                   M:AdsManager::<OnApplicationPause>b__26_0
02c8e6d0: bl      #0x2b7104c                                 fn_2b7104c
02c8e6d4: ldr     x2, [x21]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c8e6d8: mov     x1, x19                                    
02c8e6dc: mov     x3, xzr                                    
02c8e6e0: mov     x21, x0                                    
02c8e6e4: bl      #0x5b4cf98                                 UnityEngine.Events.UnityAction::.ctor
02c8e6e8: cbz     x20, #0x2c8e704                            
02c8e6ec: mov     x0, x20                                    
02c8e6f0: ldp     x20, x19, [sp, #0x10]                      
02c8e6f4: mov     x1, x21                                    
02c8e6f8: mov     x2, xzr                                    
02c8e6fc: ldp     x30, x21, [sp], #0x20                      
02c8e700: b       #0x5b4d0ac                                 UnityEngine.Events.UnityEvent::AddListener
02c8e704: bl      #0x2b7105c                                 fn_2b7105c
## ShowAd(bool withoutBanner) -> void
---- MrecCollapController::ShowAd 0x2c8e708
02c8e708: stp     x30, x19, [sp, #-0x10]!                    
02c8e70c: mov     x19, x0                                    
02c8e710: bl      #0x2c8e728                                 MrecCollapController::ShowAdAfterDelay
02c8e714: mov     x1, x0                                     
02c8e718: mov     x0, x19                                    
02c8e71c: mov     x2, xzr                                    
02c8e720: ldp     x30, x19, [sp], #0x10                      
02c8e724: b       #0x5b389f0                                 UnityEngine.MonoBehaviour::StartCoroutine
## ShowAdAfterDelay(bool withoutBanner) -> System.Collections.IEnumerator
---- MrecCollapController::ShowAdAfterDelay 0x2c8e728
02c8e728: str     x30, [sp, #-0x30]!                         
02c8e72c: stp     x22, x21, [sp, #0x10]                      
02c8e730: stp     x20, x19, [sp, #0x20]                      
02c8e734: adrp    x22, #0x662f000                            
02c8e738: adrp    x21, #0x6265000                            
02c8e73c: mov     w20, w1                                    
02c8e740: ldrb    w8, [x22, #0x9a5]                          
02c8e744: ldr     x21, [x21, #0x3f8]                         T:MrecCollapController/<ShowAdAfterDelay>d__8
02c8e748: mov     x19, x0                                    
02c8e74c: tbnz    w8, #0, #0x2c8e764                         
02c8e750: adrp    x0, #0x6265000                             
02c8e754: ldr     x0, [x0, #0x3f8]                           T:MrecCollapController/<ShowAdAfterDelay>d__8
02c8e758: bl      #0x2b70db0                                 fn_2b70db0
02c8e75c: mov     w8, #1                                     
02c8e760: strb    w8, [x22, #0x9a5]                          
02c8e764: ldr     x0, [x21]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c8e768: and     w21, w20, #1                               
02c8e76c: bl      #0x2b7104c                                 fn_2b7104c
02c8e770: mov     x1, xzr                                    
02c8e774: mov     x20, x0                                    
02c8e778: bl      #0x4e53e9c                                 System.Object::.ctor
02c8e77c: mov     x0, x20                                    
02c8e780: mov     x1, x19                                    
02c8e784: str     wzr, [x20, #0x10]                          
02c8e788: str     x19, [x0, #0x20]!                          .canReload
02c8e78c: bl      #0x2b70d54                                 fn_2b70d54
02c8e790: mov     x0, x20                                    
02c8e794: strb    w21, [x20, #0x28]                          ._viewObj
02c8e798: ldp     x20, x19, [sp, #0x20]                      
02c8e79c: ldp     x22, x21, [sp, #0x10]                      
02c8e7a0: ldr     x30, [sp], #0x30                           
02c8e7a4: ret                                                
## HideAd(bool stopReload) -> void
---- MrecCollapController::HideAd 0x2c8e7d0
02c8e7d0: stp     x30, x21, [sp, #-0x20]!                    
02c8e7d4: stp     x20, x19, [sp, #0x10]                      
02c8e7d8: adrp    x21, #0x662f000                            
02c8e7dc: mov     w20, w1                                    
02c8e7e0: mov     x19, x0                                    
02c8e7e4: ldrb    w8, [x21, #0x9a6]                          
02c8e7e8: tbnz    w8, #0, #0x2c8e800                         
02c8e7ec: adrp    x0, #0x6265000                             
02c8e7f0: ldr     x0, [x0, #0x310]                           MS:WejoyService.Singleton`1::get_Instance
02c8e7f4: bl      #0x2b70db0                                 fn_2b70db0
02c8e7f8: mov     w8, #1                                     
02c8e7fc: strb    w8, [x21, #0x9a6]                          
02c8e800: ldr     x0, [x19, #0x28]                           ._viewObj
02c8e804: cbz     x0, #0x2c8e884                             
02c8e808: adrp    x21, #0x6265000                            
02c8e80c: mov     w1, wzr                                    
02c8e810: mov     x2, xzr                                    
02c8e814: ldr     x21, [x21, #0x310]                         MS:WejoyService.Singleton`1::get_Instance
02c8e818: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02c8e81c: ldr     x0, [x21]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c8e820: bl      #0x3be7218                                 fn_3be7218
02c8e824: cbz     x0, #0x2c8e884                             
02c8e828: bl      #0x2c88cec                                 AdsManager::HideMREC
02c8e82c: ldr     x1, [x19, #0x38]                           ._hideCoroutine
02c8e830: cbz     x1, #0x2c8e840                             
02c8e834: mov     x0, x19                                    
02c8e838: mov     x2, xzr                                    
02c8e83c: bl      #0x5b38c4c                                 UnityEngine.MonoBehaviour::StopCoroutine
02c8e840: ldrb    w8, [x19, #0x20]                           .canReload
02c8e844: cbz     w8, #0x2c8e868                             
02c8e848: tbz     w20, #0, #0x2c8e874                        
02c8e84c: ldr     x1, [x19, #0x40]                           ._reshownCoroutine
02c8e850: cbz     x1, #0x2c8e868                             
02c8e854: mov     x0, x19                                    
02c8e858: ldp     x20, x19, [sp, #0x10]                      
02c8e85c: mov     x2, xzr                                    
02c8e860: ldp     x30, x21, [sp], #0x20                      
02c8e864: b       #0x5b38c4c                                 UnityEngine.MonoBehaviour::StopCoroutine
02c8e868: ldp     x20, x19, [sp, #0x10]                      
02c8e86c: ldp     x30, x21, [sp], #0x20                      
02c8e870: ret                                                
02c8e874: mov     x0, x19                                    
02c8e878: ldp     x20, x19, [sp, #0x10]                      
02c8e87c: ldp     x30, x21, [sp], #0x20                      
02c8e880: b       #0x2c8e8b0                                 MrecCollapController::SetAutoReshown
02c8e884: bl      #0x2b7105c                                 fn_2b7105c
## OnCloseClick() -> void
---- MrecCollapController::OnCloseClick 0x2c8e904
02c8e904: mov     w1, wzr                                    
02c8e908: b       #0x2c8e7d0                                 MrecCollapController::HideAd
## SetAutoHide() -> void
---- MrecCollapController::SetAutoHide 0x2c8e90c
02c8e90c: str     x30, [sp, #-0x20]!                         
02c8e910: stp     x20, x19, [sp, #0x10]                      
02c8e914: mov     x20, x0                                    
02c8e918: mov     x19, x0                                    
02c8e91c: ldr     x1, [x20, #0x38]!                          ._hideCoroutine
02c8e920: cbz     x1, #0x2c8e930                             
02c8e924: mov     x0, x19                                    
02c8e928: mov     x2, xzr                                    
02c8e92c: bl      #0x5b38c4c                                 UnityEngine.MonoBehaviour::StopCoroutine
02c8e930: mov     x0, x19                                    
02c8e934: bl      #0x2c8e960                                 MrecCollapController::IAutoHide
02c8e938: mov     x1, x0                                     
02c8e93c: mov     x0, x19                                    
02c8e940: mov     x2, xzr                                    
02c8e944: bl      #0x5b389f0                                 UnityEngine.MonoBehaviour::StartCoroutine
02c8e948: mov     x1, x0                                     
02c8e94c: mov     x0, x20                                    
02c8e950: str     x1, [x19, #0x38]                           ._hideCoroutine
02c8e954: ldp     x20, x19, [sp, #0x10]                      
02c8e958: ldr     x30, [sp], #0x20                           
02c8e95c: b       #0x2b70d54                                 
## StopAutoHide() -> void
---- MrecCollapController::StopAutoHide 0x2c8e888
02c8e888: ldr     x1, [x0, #0x38]                            ._hideCoroutine
02c8e88c: cbz     x1, #0x2c8e898                             
02c8e890: mov     x2, xzr                                    
02c8e894: b       #0x5b38c4c                                 UnityEngine.MonoBehaviour::StopCoroutine
02c8e898: ret                                                
## IAutoHide() -> System.Collections.IEnumerator
---- MrecCollapController::IAutoHide 0x2c8e960
02c8e960: stp     x30, x21, [sp, #-0x20]!                    
02c8e964: stp     x20, x19, [sp, #0x10]                      
02c8e968: adrp    x20, #0x662f000                            
02c8e96c: adrp    x21, #0x6265000                            
02c8e970: mov     x19, x0                                    
02c8e974: ldrb    w8, [x20, #0x9a7]                          
02c8e978: ldr     x21, [x21, #0x400]                         T:MrecCollapController/<IAutoHide>d__13
02c8e97c: tbnz    w8, #0, #0x2c8e994                         
02c8e980: adrp    x0, #0x6265000                             
02c8e984: ldr     x0, [x0, #0x400]                           T:MrecCollapController/<IAutoHide>d__13
02c8e988: bl      #0x2b70db0                                 fn_2b70db0
02c8e98c: mov     w8, #1                                     
02c8e990: strb    w8, [x20, #0x9a7]                          
02c8e994: ldr     x0, [x21]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c8e998: bl      #0x2b7104c                                 fn_2b7104c
02c8e99c: mov     x1, xzr                                    
02c8e9a0: mov     x20, x0                                    
02c8e9a4: bl      #0x4e53e9c                                 System.Object::.ctor
02c8e9a8: mov     x0, x20                                    
02c8e9ac: mov     x1, x19                                    
02c8e9b0: str     wzr, [x20, #0x10]                          
02c8e9b4: str     x19, [x0, #0x20]!                          .canReload
02c8e9b8: bl      #0x2b70d54                                 fn_2b70d54
02c8e9bc: mov     x0, x20                                    
02c8e9c0: ldp     x20, x19, [sp, #0x10]                      
02c8e9c4: ldp     x30, x21, [sp], #0x20                      
02c8e9c8: ret                                                
## SetAutoReshown() -> void
---- MrecCollapController::SetAutoReshown 0x2c8e8b0
02c8e8b0: str     x30, [sp, #-0x20]!                         
02c8e8b4: stp     x20, x19, [sp, #0x10]                      
02c8e8b8: mov     x20, x0                                    
02c8e8bc: mov     x19, x0                                    
02c8e8c0: ldr     x1, [x20, #0x40]!                          ._reshownCoroutine
02c8e8c4: cbz     x1, #0x2c8e8d4                             
02c8e8c8: mov     x0, x19                                    
02c8e8cc: mov     x2, xzr                                    
02c8e8d0: bl      #0x5b38c4c                                 UnityEngine.MonoBehaviour::StopCoroutine
02c8e8d4: mov     x0, x19                                    
02c8e8d8: bl      #0x2c8e9f4                                 MrecCollapController::IAutoReshown
02c8e8dc: mov     x1, x0                                     
02c8e8e0: mov     x0, x19                                    
02c8e8e4: mov     x2, xzr                                    
02c8e8e8: bl      #0x5b389f0                                 UnityEngine.MonoBehaviour::StartCoroutine
02c8e8ec: mov     x1, x0                                     
02c8e8f0: mov     x0, x20                                    
02c8e8f4: str     x1, [x19, #0x40]                           ._reshownCoroutine
02c8e8f8: ldp     x20, x19, [sp, #0x10]                      
02c8e8fc: ldr     x30, [sp], #0x20                           
02c8e900: b       #0x2b70d54                                 
## StopAutoReshow() -> void
---- MrecCollapController::StopAutoReshow 0x2c8e89c
02c8e89c: ldr     x1, [x0, #0x40]                            ._reshownCoroutine
02c8e8a0: cbz     x1, #0x2c8e8ac                             
02c8e8a4: mov     x2, xzr                                    
02c8e8a8: b       #0x5b38c4c                                 UnityEngine.MonoBehaviour::StopCoroutine
02c8e8ac: ret                                                
## IAutoReshown() -> System.Collections.IEnumerator
---- MrecCollapController::IAutoReshown 0x2c8e9f4
02c8e9f4: stp     x30, x21, [sp, #-0x20]!                    
02c8e9f8: stp     x20, x19, [sp, #0x10]                      
02c8e9fc: adrp    x20, #0x662f000                            
02c8ea00: adrp    x21, #0x6265000                            
02c8ea04: mov     x19, x0                                    
02c8ea08: ldrb    w8, [x20, #0x9a8]                          
02c8ea0c: ldr     x21, [x21, #0x408]                         T:MrecCollapController/<IAutoReshown>d__16
02c8ea10: tbnz    w8, #0, #0x2c8ea28                         
02c8ea14: adrp    x0, #0x6265000                             
02c8ea18: ldr     x0, [x0, #0x408]                           T:MrecCollapController/<IAutoReshown>d__16
02c8ea1c: bl      #0x2b70db0                                 fn_2b70db0
02c8ea20: mov     w8, #1                                     
02c8ea24: strb    w8, [x20, #0x9a8]                          
02c8ea28: ldr     x0, [x21]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c8ea2c: bl      #0x2b7104c                                 fn_2b7104c
02c8ea30: mov     x1, xzr                                    
02c8ea34: mov     x20, x0                                    
02c8ea38: bl      #0x4e53e9c                                 System.Object::.ctor
02c8ea3c: mov     x0, x20                                    
02c8ea40: mov     x1, x19                                    
02c8ea44: str     wzr, [x20, #0x10]                          
02c8ea48: str     x19, [x0, #0x20]!                          .canReload
02c8ea4c: bl      #0x2b70d54                                 fn_2b70d54
02c8ea50: mov     x0, x20                                    
02c8ea54: ldp     x20, x19, [sp, #0x10]                      
02c8ea58: ldp     x30, x21, [sp], #0x20                      
02c8ea5c: ret                                                
## .ctor() -> void
---- MrecCollapController::.ctor 0x2c8ea88
02c8ea88: stp     x30, x21, [sp, #-0x20]!                    
02c8ea8c: stp     x20, x19, [sp, #0x10]                      
02c8ea90: adrp    x21, #0x662f000                            
02c8ea94: adrp    x20, #0x6265000                            
02c8ea98: mov     x19, x0                                    
02c8ea9c: ldrb    w8, [x21, #0x9a9]                          
02c8eaa0: ldr     x20, [x20, #0x410]                         MS:WejoyService.Singleton`1::.ctor
02c8eaa4: tbnz    w8, #0, #0x2c8eabc                         
02c8eaa8: adrp    x0, #0x6265000                             
02c8eaac: ldr     x0, [x0, #0x410]                           MS:WejoyService.Singleton`1::.ctor
02c8eab0: bl      #0x2b70db0                                 fn_2b70db0
02c8eab4: mov     w8, #1                                     
02c8eab8: strb    w8, [x21, #0x9a9]                          
02c8eabc: mov     w8, #1                                     
02c8eac0: ldr     x1, [x20]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c8eac4: mov     x0, x19                                    
02c8eac8: strb    w8, [x19, #0x20]                           .canReload
02c8eacc: ldp     x20, x19, [sp, #0x10]                      
02c8ead0: ldp     x30, x21, [sp], #0x20                      
02c8ead4: b       #0x3be76dc                                 
