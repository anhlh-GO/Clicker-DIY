#### CLASS BlindBagCollection.CollectionBox parent= UnityEngine.MonoBehaviour
#   field _boxsetType                    BlindBagCollection.CollectionBoxsetType            off=0x20 attr=1 SerializeField
#   field _dataIndex                     int                                                off=0x24 attr=1 SerializeField
#   field _setupData                     System.Collections.Generic.List`1<UnityEngine.SpriteRenderer> off=0x28 attr=1 SerializeField
#   field _collectionItems               System.Collections.Generic.List`1<BlindBagCollection.BoxItem> off=0x30 attr=1 SerializeField
#   field _collectionAsset               BlindBagCollection.BlindbagCollectionAsset         off=0x38 attr=1 SerializeField
#   field _enumSetup                     System.Collections.Generic.List`1<BlindBagCollection.CollectionItemType> off=0x40 attr=1 
#   field _currentBoxItem                BlindBagCollection.BoxItem                         off=0x48 attr=1 
#   field _highlightTween                DG.Tweening.Tween                                  off=0x50 attr=1 
#   field _collectionDataUser            BlindBagCollection.BlindbagCollectionData          off=0x58 attr=1 
## get_BoxsetType() -> BlindBagCollection.CollectionBoxsetType
---- BlindBagCollection.CollectionBox::get_BoxsetType 0x2d38d3c
02d38d3c: ldr     w0, [x0, #0x20]                            ._boxsetType
02d38d40: ret                                                
## Start() -> void
---- BlindBagCollection.CollectionBox::Start 0x2d38d44
02d38d44: sub     sp, sp, #0xa0                              
02d38d48: stp     x29, x30, [sp, #0x40]                      
02d38d4c: stp     x28, x27, [sp, #0x50]                      
02d38d50: stp     x26, x25, [sp, #0x60]                      
02d38d54: stp     x24, x23, [sp, #0x70]                      
02d38d58: stp     x22, x21, [sp, #0x80]                      
02d38d5c: stp     x20, x19, [sp, #0x90]                      
02d38d60: adrp    x21, #0x6630000                            
02d38d64: adrp    x20, #0x6266000                            
02d38d68: mov     x19, x0                                    
02d38d6c: ldrb    w8, [x21, #0x13e]                          
02d38d70: ldr     x20, [x20, #0x658]                         MS:MonoSingleton`1::get_Instance
02d38d74: tbnz    w8, #0, #0x2d38de0                         
02d38d78: adrp    x0, #0x626a000                             
02d38d7c: ldr     x0, [x0, #0xc38]                           MS:UnityEngine.Component::GetComponentsInChildren
02d38d80: bl      #0x2b70db0                                 fn_2b70db0
02d38d84: adrp    x0, #0x626a000                             
02d38d88: ldr     x0, [x0, #0x800]                           MS:DataManager::GetData
02d38d8c: bl      #0x2b70db0                                 fn_2b70db0
02d38d90: adrp    x0, #0x626a000                             
02d38d94: ldr     x0, [x0, #0xc40]                           MS:System.Collections.Generic.List`1/Enumerator::Dispose
02d38d98: bl      #0x2b70db0                                 fn_2b70db0
02d38d9c: adrp    x0, #0x626a000                             
02d38da0: ldr     x0, [x0, #0xc48]                           MS:System.Collections.Generic.List`1/Enumerator::MoveNext
02d38da4: bl      #0x2b70db0                                 fn_2b70db0
02d38da8: adrp    x0, #0x626a000                             
02d38dac: ldr     x0, [x0, #0xc50]                           MS:System.Collections.Generic.List`1/Enumerator::get_Current
02d38db0: bl      #0x2b70db0                                 fn_2b70db0
02d38db4: adrp    x0, #0x626a000                             
02d38db8: ldr     x0, [x0, #0xc58]                           MS:System.Collections.Generic.List`1::GetEnumerator
02d38dbc: bl      #0x2b70db0                                 fn_2b70db0
02d38dc0: adrp    x0, #0x6266000                             
02d38dc4: ldr     x0, [x0, #0x658]                           MS:MonoSingleton`1::get_Instance
02d38dc8: bl      #0x2b70db0                                 fn_2b70db0
02d38dcc: adrp    x0, #0x6263000                             
02d38dd0: ldr     x0, [x0, #0x918]                           T:UnityEngine.Object
02d38dd4: bl      #0x2b70db0                                 fn_2b70db0
02d38dd8: mov     w8, #1                                     
02d38ddc: strb    w8, [x21, #0x13e]                          
02d38de0: ldr     x0, [x20]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d38de4: stp     xzr, xzr, [sp, #0x20]                      
02d38de8: str     xzr, [sp, #0x30]                           
02d38dec: bl      #0x3769600                                 fn_3769600
02d38df0: cbz     x0, #0x2d38fd4                             
02d38df4: adrp    x8, #0x626a000                             
02d38df8: ldr     x8, [x8, #0x800]                           MS:DataManager::GetData
02d38dfc: ldr     x1, [x8]                                   T:type56879(k15)
02d38e00: bl      #0x3168dd0                                 fn_3168dd0
02d38e04: mov     x20, x19                                   
02d38e08: mov     x1, x0                                     
02d38e0c: str     x0, [x20, #0x58]!                          ._collectionDataUser
02d38e10: mov     x0, x20                                    
02d38e14: bl      #0x2b70d54                                 fn_2b70d54
02d38e18: ldur    x0, [x20, #-0x28]                          
02d38e1c: cbz     x0, #0x2d38fd4                             
02d38e20: adrp    x8, #0x626a000                             
02d38e24: adrp    x24, #0x626a000                            
02d38e28: adrp    x25, #0x626a000                            
02d38e2c: ldr     x8, [x8, #0xc58]                           MS:System.Collections.Generic.List`1::GetEnumerator
02d38e30: adrp    x26, #0x6263000                            
02d38e34: adrp    x23, #0x626a000                            
02d38e38: ldr     x24, [x24, #0xc48]                         MS:System.Collections.Generic.List`1/Enumerator::MoveNext
02d38e3c: ldr     x25, [x25, #0xc38]                         MS:UnityEngine.Component::GetComponentsInChildren
02d38e40: ldr     x26, [x26, #0x918]                         T:UnityEngine.Object
02d38e44: ldr     x23, [x23, #0xc40]                         MS:System.Collections.Generic.List`1/Enumerator::Dispose
02d38e48: ldr     x1, [x8]                                   T:type56879(k15)
02d38e4c: add     x8, sp, #8                                 
02d38e50: bl      #0x35a9d9c                                 fn_35a9d9c
02d38e54: ldr     x8, [sp, #0x18]                            
02d38e58: ldur    q0, [sp, #8]                               
02d38e5c: str     x8, [sp, #0x30]                            
02d38e60: add     x8, sp, #0x20                              
02d38e64: str     q0, [sp, #0x20]                            
02d38e68: stp     xzr, x8, [sp, #8]                          
02d38e6c: ldr     x1, [x24]                                  T:type56879(k15)
02d38e70: add     x0, sp, #0x20                              
02d38e74: bl      #0x4690474                                 fn_4690474
02d38e78: tbz     w0, #0, #0x2d38f80                         
02d38e7c: ldr     x27, [sp, #0x30]                           
02d38e80: cbz     x27, #0x2d38fc0                            
02d38e84: ldr     x0, [x19, #0x58]                           ._collectionDataUser
02d38e88: cbz     x0, #0x2d38fc4                             
02d38e8c: ldr     w1, [x19, #0x20]                           ._boxsetType
02d38e90: ldr     w2, [x27, #0x14]                           
02d38e94: bl      #0x2d3521c                                 BlindBagCollection.BlindbagCollectionData::IsUnlocked
02d38e98: mov     w8, w0                                     
02d38e9c: ldr     x0, [x27, #0x18]                           
02d38ea0: and     w8, w8, #1                                 
02d38ea4: strb    w8, [x27, #0x10]                           
02d38ea8: cbz     x0, #0x2d38fbc                             
02d38eac: mov     x1, xzr                                    
02d38eb0: bl      #0x5b339ec                                 UnityEngine.Component::get_gameObject
02d38eb4: cbz     x0, #0x2d38fc8                             
02d38eb8: ldrb    w1, [x27, #0x10]                           
02d38ebc: mov     x2, xzr                                    
02d38ec0: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d38ec4: ldr     w8, [x27, #0x14]                           
02d38ec8: cbnz    w8, #0x2d38e6c                             
02d38ecc: ldrb    w8, [x27, #0x10]                           
02d38ed0: cbz     w8, #0x2d38e6c                             
02d38ed4: ldr     x0, [x27, #0x18]                           
02d38ed8: cbz     x0, #0x2d38fcc                             
02d38edc: ldr     x2, [x25]                                  T:type56879(k15)
02d38ee0: mov     w1, #1                                     
02d38ee4: bl      #0x31417a8                                 fn_31417a8
02d38ee8: mov     x20, x0                                    
02d38eec: cbz     x0, #0x2d38fd0                             
02d38ef0: ldr     x8, [x20, #0x18]                           S:'level_show_popuprate'
02d38ef4: cmp     w8, #1                                     
02d38ef8: b.lt    #0x2d38e6c                                 
02d38efc: mov     x28, xzr                                   
02d38f00: and     x8, x8, #0xffffffff                        
02d38f04: add     x29, x20, #0x20                            &6266020
02d38f08: cmp     x28, w8, uxtw                              
02d38f0c: b.hs    #0x2d38fac                                 
02d38f10: ldr     x0, [x27, #0x18]                           
02d38f14: cbz     x0, #0x2d38fb0                             
02d38f18: ldr     x21, [x29, x28, lsl #3]                    
02d38f1c: mov     x1, xzr                                    
02d38f20: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02d38f24: mov     x22, x0                                    
02d38f28: ldr     x0, [x26]                                  &2c5bbd4(=a9bd7bfdd503233f)
02d38f2c: ldr     w8, [x0, #0xe4]                            [62630e4]=0 f=0,0
02d38f30: cbnz    w8, #0x2d38f38                             
02d38f34: bl      #0x2b70f30                                 fn_2b70f30
02d38f38: mov     x0, x21                                    
02d38f3c: mov     x1, x22                                    
02d38f40: mov     x2, xzr                                    
02d38f44: bl      #0x5b3666c                                 UnityEngine.Object::op_Inequality
02d38f48: tbz     w0, #0, #0x2d38f6c                         
02d38f4c: cbz     x21, #0x2d38fb4                            
02d38f50: mov     x0, x21                                    
02d38f54: mov     x1, xzr                                    
02d38f58: bl      #0x5b339ec                                 UnityEngine.Component::get_gameObject
02d38f5c: cbz     x0, #0x2d38fb8                             
02d38f60: ldrb    w1, [x27, #0x10]                           
02d38f64: mov     x2, xzr                                    
02d38f68: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d38f6c: ldr     w8, [x20, #0x18]                           S:'level_show_popuprate'
02d38f70: add     x28, x28, #1                               
02d38f74: cmp     x28, w8, sxtw                              
02d38f78: b.lt    #0x2d38f08                                 
02d38f7c: b       #0x2d38e6c                                 
02d38f80: ldr     x1, [x23]                                  T:type56879(k15)
02d38f84: add     x0, sp, #0x20                              
02d38f88: bl      #0x4690470                                 fn_4690470
02d38f8c: ldp     x20, x19, [sp, #0x90]                      
02d38f90: ldp     x22, x21, [sp, #0x80]                      
02d38f94: ldp     x24, x23, [sp, #0x70]                      
02d38f98: ldp     x26, x25, [sp, #0x60]                      
02d38f9c: ldp     x28, x27, [sp, #0x50]                      
02d38fa0: ldp     x29, x30, [sp, #0x40]                      
02d38fa4: add     sp, sp, #0xa0                              
02d38fa8: ret                                                
02d38fac: bl      #0x2b71064                                 fn_2b71064
02d38fb0: bl      #0x2b7105c                                 fn_2b7105c
02d38fb4: bl      #0x2b7105c                                 fn_2b7105c
02d38fb8: bl      #0x2b7105c                                 fn_2b7105c
02d38fbc: bl      #0x2b7105c                                 fn_2b7105c
02d38fc0: bl      #0x2b7105c                                 fn_2b7105c
02d38fc4: bl      #0x2b7105c                                 fn_2b7105c
02d38fc8: bl      #0x2b7105c                                 fn_2b7105c
02d38fcc: bl      #0x2b7105c                                 fn_2b7105c
02d38fd0: bl      #0x2b7105c                                 fn_2b7105c
02d38fd4: bl      #0x2b7105c                                 fn_2b7105c
02d38fd8: b       #0x2d39020                                 
02d38fdc: b       #0x2d39020                                 
02d38fe0: b       #0x2d39020                                 
02d38fe4: b       #0x2d39020                                 
02d38fe8: b       #0x2d39020                                 
02d38fec: b       #0x2d39020                                 
02d38ff0: b       #0x2d39020                                 
02d38ff4: b       #0x2d39020                                 
02d38ff8: b       #0x2d39020                                 
02d38ffc: b       #0x2d39020                                 
02d39000: b       #0x2d39020                                 
02d39004: b       #0x2d39020                                 
02d39008: b       #0x2d39020                                 
02d3900c: b       #0x2d39020                                 
02d39010: b       #0x2d39020                                 
02d39014: b       #0x2d39020                                 
02d39018: b       #0x2d39020                                 
02d3901c: b       #0x2d39020                                 
02d39020: mov     x19, x0                                    
02d39024: cmp     w1, #1                                     
02d39028: b.ne    #0x2d3905c                                 
02d3902c: mov     x0, x19                                    
02d39030: bl      #0x5e90260                                 fn_5e90260
02d39034: ldr     x19, [x0]                                  &2c5bbd4(=a9bd7bfdd503233f)
02d39038: str     x19, [sp, #8]                              
02d3903c: bl      #0x5e90270                                 fn_5e90270
02d39040: ldr     x0, [sp, #0x10]                            
02d39044: ldr     x1, [x23]                                  T:type56879(k15)
02d39048: bl      #0x4690470                                 fn_4690470
02d3904c: cbz     x19, #0x2d38f8c                            
02d39050: mov     x0, x19                                    
02d39054: bl      #0x2b71054                                 fn_2b71054
02d39058: mov     x19, x0                                    
02d3905c: add     x0, sp, #8                                 
02d39060: bl      #0x2738368                                 fn_2738368
02d39064: mov     x0, x19                                    
02d39068: bl      #0x2c6051c                                 fn_2c6051c
02d3906c: bl      #0x27369b8                                 fn_27369b8
## SetupData() -> void
---- BlindBagCollection.CollectionBox::SetupData 0x2d39070
02d39070: stp     x30, x25, [sp, #-0x40]!                    
02d39074: stp     x24, x23, [sp, #0x10]                      
02d39078: stp     x22, x21, [sp, #0x20]                      
02d3907c: stp     x20, x19, [sp, #0x30]                      
02d39080: adrp    x20, #0x6630000                            
02d39084: mov     x19, x0                                    
02d39088: ldrb    w8, [x20, #0x13f]                          
02d3908c: tbnz    w8, #0, #0x2d390e0                         
02d39090: adrp    x0, #0x626a000                             
02d39094: ldr     x0, [x0, #0xc60]                           T:BlindBagCollection.BoxItem
02d39098: bl      #0x2b70db0                                 fn_2b70db0
02d3909c: adrp    x0, #0x626a000                             
02d390a0: ldr     x0, [x0, #0xc68]                           MS:System.Collections.Generic.List`1::Add
02d390a4: bl      #0x2b70db0                                 fn_2b70db0
02d390a8: adrp    x0, #0x626a000                             
02d390ac: ldr     x0, [x0, #0xc70]                           MS:System.Collections.Generic.List`1::Clear
02d390b0: bl      #0x2b70db0                                 fn_2b70db0
02d390b4: adrp    x0, #0x6267000                             
02d390b8: ldr     x0, [x0, #0x878]                           MS:System.Collections.Generic.List`1::get_Count
02d390bc: bl      #0x2b70db0                                 fn_2b70db0
02d390c0: adrp    x0, #0x626a000                             
02d390c4: ldr     x0, [x0, #0xc78]                           MS:System.Collections.Generic.List`1::get_Item
02d390c8: bl      #0x2b70db0                                 fn_2b70db0
02d390cc: adrp    x0, #0x6267000                             
02d390d0: ldr     x0, [x0, #0x888]                           MS:System.Collections.Generic.List`1::get_Item
02d390d4: bl      #0x2b70db0                                 fn_2b70db0
02d390d8: mov     w8, #1                                     
02d390dc: strb    w8, [x20, #0x13f]                          
02d390e0: ldr     x8, [x19, #0x30]                           ._collectionItems
02d390e4: cbz     x8, #0x2d39210                             
02d390e8: ldp     w2, w9, [x8, #0x18]                        
02d390ec: add     w9, w9, #1                                 
02d390f0: cmp     w2, #1                                     
02d390f4: stp     wzr, w9, [x8, #0x18]                       
02d390f8: b.lt    #0x2d3910c                                 
02d390fc: ldr     x0, [x8, #0x10]                            
02d39100: mov     w1, wzr                                    
02d39104: mov     x3, xzr                                    
02d39108: bl      #0x4e3494c                                 System.Array::Clear
02d3910c: ldr     x8, [x19, #0x28]                           ._setupData
02d39110: cbz     x8, #0x2d39210                             
02d39114: adrp    x22, #0x626a000                            
02d39118: adrp    x23, #0x6267000                            
02d3911c: adrp    x24, #0x626a000                            
02d39120: adrp    x25, #0x626a000                            
02d39124: ldr     x22, [x22, #0xc60]                         T:BlindBagCollection.BoxItem
02d39128: ldr     x23, [x23, #0x888]                         MS:System.Collections.Generic.List`1::get_Item
02d3912c: ldr     x24, [x24, #0xc78]                         MS:System.Collections.Generic.List`1::get_Item
02d39130: ldr     x25, [x25, #0xc68]                         MS:System.Collections.Generic.List`1::Add
02d39134: mov     w20, wzr                                   
02d39138: ldr     w8, [x8, #0x18]                            
02d3913c: cmp     w20, w8                                    
02d39140: b.ge    #0x2d39214                                 
02d39144: ldr     x0, [x22]                                  T:type56879(k15)
02d39148: bl      #0x2b7104c                                 fn_2b7104c
02d3914c: mov     x1, xzr                                    
02d39150: mov     x21, x0                                    
02d39154: bl      #0x4e53e9c                                 System.Object::.ctor
02d39158: ldr     x0, [x19, #0x28]                           ._setupData
02d3915c: cbz     x0, #0x2d39210                             
02d39160: ldr     x2, [x23]                                  S:'didu'
02d39164: mov     w1, w20                                    
02d39168: bl      #0x35a8f3c                                 fn_35a8f3c
02d3916c: cbz     x21, #0x2d39210                            
02d39170: mov     x1, x0                                     
02d39174: mov     x0, x21                                    
02d39178: str     x1, [x0, #0x18]!                           
02d3917c: bl      #0x2b70d54                                 fn_2b70d54
02d39180: ldr     x0, [x19, #0x40]                           ._enumSetup
02d39184: cbz     x0, #0x2d39210                             
02d39188: ldr     x2, [x24]                                  T:type56879(k15)
02d3918c: mov     w1, w20                                    
02d39190: bl      #0x356c280                                 fn_356c280
02d39194: mov     w8, w0                                     
02d39198: ldr     x0, [x19, #0x30]                           ._collectionItems
02d3919c: strb    wzr, [x21, #0x10]                          
02d391a0: str     w8, [x21, #0x14]                           
02d391a4: cbz     x0, #0x2d39210                             
02d391a8: ldr     w10, [x0, #0x1c]                           [626701c]=0 f=0,0
02d391ac: ldr     x8, [x0, #0x10]                            S:'startActivity'
02d391b0: ldr     x9, [x25]                                  T:type56879(k15)
02d391b4: add     w10, w10, #1                               
02d391b8: str     w10, [x0, #0x1c]                           
02d391bc: cbz     x8, #0x2d39210                             
02d391c0: ldrsw   x10, [x0, #0x18]                           
02d391c4: ldr     w11, [x8, #0x18]                           
02d391c8: cmp     w10, w11                                   
02d391cc: b.hs    #0x2d391f0                                 
02d391d0: add     x8, x8, x10, lsl #3                        
02d391d4: add     w9, w10, #1                                
02d391d8: mov     x1, x21                                    
02d391dc: str     w9, [x0, #0x18]                            
02d391e0: str     x21, [x8, #0x20]!                          
02d391e4: mov     x0, x8                                     
02d391e8: bl      #0x2b70d54                                 fn_2b70d54
02d391ec: b       #0x2d39204                                 
02d391f0: ldr     x8, [x9, #0x20]                            
02d391f4: mov     x1, x21                                    
02d391f8: ldr     x8, [x8, #0xc0]                            
02d391fc: ldr     x2, [x8, #0x70]                            
02d39200: bl      #0x35a920c                                 fn_35a920c
02d39204: ldr     x8, [x19, #0x28]                           ._setupData
02d39208: add     w20, w20, #1                               
02d3920c: cbnz    x8, #0x2d39138                             
02d39210: bl      #0x2b7105c                                 fn_2b7105c
02d39214: ldp     x20, x19, [sp, #0x30]                      
02d39218: ldp     x22, x21, [sp, #0x20]                      
02d3921c: ldp     x24, x23, [sp, #0x10]                      
02d39220: ldp     x30, x25, [sp], #0x40                      
02d39224: ret                                                
## GetCurrentItemPosition() -> UnityEngine.Vector2
---- BlindBagCollection.CollectionBox::GetCurrentItemPosition 0x2d39230
02d39230: str     x30, [sp, #-0x10]!                         
02d39234: ldr     x8, [x0, #0x48]                            ._currentBoxItem
02d39238: cbz     x8, #0x2d3925c                             
02d3923c: ldr     x0, [x8, #0x18]                            
02d39240: cbz     x0, #0x2d39270                             
02d39244: mov     x1, xzr                                    
02d39248: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02d3924c: cbz     x0, #0x2d39270                             
02d39250: mov     x1, xzr                                    
02d39254: bl      #0x5b467ac                                 UnityEngine.Transform::get_position
02d39258: b       #0x2d39268                                 
02d3925c: adrp    x8, #0x1084000                             
02d39260: ldr     s1, [x8, #0xeac]                           [1084eac]=3fb333334479c000 f=999,1.4
02d39264: fmov    s0, s1                                     
02d39268: ldr     x30, [sp], #0x10                           
02d3926c: ret                                                
02d39270: bl      #0x2b7105c                                 fn_2b7105c
## SetHighlight(BlindBagCollection.CollectionItemType itemType) -> void
---- BlindBagCollection.CollectionBox::SetHighlight 0x2d39274
02d39274: sub     sp, sp, #0x70                              
02d39278: stp     x30, x23, [sp, #0x40]                      
02d3927c: stp     x22, x21, [sp, #0x50]                      
02d39280: stp     x20, x19, [sp, #0x60]                      
02d39284: adrp    x21, #0x6630000                            
02d39288: mov     w20, w1                                    
02d3928c: mov     x19, x0                                    
02d39290: ldrb    w8, [x21, #0x140]                          
02d39294: tbnz    w8, #0, #0x2d392e8                         
02d39298: adrp    x0, #0x626a000                             
02d3929c: ldr     x0, [x0, #0xc40]                           MS:System.Collections.Generic.List`1/Enumerator::Dispose
02d392a0: bl      #0x2b70db0                                 fn_2b70db0
02d392a4: adrp    x0, #0x626a000                             
02d392a8: ldr     x0, [x0, #0xc48]                           MS:System.Collections.Generic.List`1/Enumerator::MoveNext
02d392ac: bl      #0x2b70db0                                 fn_2b70db0
02d392b0: adrp    x0, #0x626a000                             
02d392b4: ldr     x0, [x0, #0xc50]                           MS:System.Collections.Generic.List`1/Enumerator::get_Current
02d392b8: bl      #0x2b70db0                                 fn_2b70db0
02d392bc: adrp    x0, #0x626a000                             
02d392c0: ldr     x0, [x0, #0xc58]                           MS:System.Collections.Generic.List`1::GetEnumerator
02d392c4: bl      #0x2b70db0                                 fn_2b70db0
02d392c8: adrp    x0, #0x6264000                             
02d392cc: ldr     x0, [x0, #0x308]                           MS:DG.Tweening.TweenSettingsExtensions::SetEase
02d392d0: bl      #0x2b70db0                                 fn_2b70db0
02d392d4: adrp    x0, #0x626a000                             
02d392d8: ldr     x0, [x0, #0xc80]                           MS:DG.Tweening.TweenSettingsExtensions::SetLoops
02d392dc: bl      #0x2b70db0                                 fn_2b70db0
02d392e0: mov     w8, #1                                     
02d392e4: strb    w8, [x21, #0x140]                          
02d392e8: ldr     x0, [x19, #0x30]                           ._collectionItems
02d392ec: stp     xzr, xzr, [sp, #0x20]                      
02d392f0: str     xzr, [sp, #0x30]                           
02d392f4: cbz     x0, #0x2d39444                             
02d392f8: adrp    x8, #0x626a000                             
02d392fc: adrp    x23, #0x626a000                            
02d39300: adrp    x22, #0x626a000                            
02d39304: ldr     x8, [x8, #0xc58]                           MS:System.Collections.Generic.List`1::GetEnumerator
02d39308: ldr     x23, [x23, #0xc48]                         MS:System.Collections.Generic.List`1/Enumerator::MoveNext
02d3930c: ldr     x22, [x22, #0xc40]                         MS:System.Collections.Generic.List`1/Enumerator::Dispose
02d39310: ldr     x1, [x8]                                   T:type56879(k15)
02d39314: add     x8, sp, #8                                 
02d39318: bl      #0x35a9d9c                                 fn_35a9d9c
02d3931c: ldr     x8, [sp, #0x18]                            
02d39320: ldur    q0, [sp, #8]                               
02d39324: str     x8, [sp, #0x30]                            
02d39328: add     x8, sp, #0x20                              
02d3932c: str     q0, [sp, #0x20]                            
02d39330: stp     xzr, x8, [sp, #8]                          
02d39334: ldr     x1, [x23]                                  T:type56879(k15)
02d39338: add     x0, sp, #0x20                              
02d3933c: bl      #0x4690474                                 fn_4690474
02d39340: tbz     w0, #0, #0x2d39420                         
02d39344: ldr     x21, [sp, #0x30]                           
02d39348: cbz     x21, #0x2d39440                            
02d3934c: ldr     w8, [x21, #0x14]                           
02d39350: cmp     w8, w20                                    
02d39354: b.ne    #0x2d39334                                 
02d39358: mov     x20, x19                                   
02d3935c: str     x21, [x20, #0x48]!                         ._currentBoxItem
02d39360: mov     x0, x20                                    
02d39364: mov     x1, x21                                    
02d39368: bl      #0x2b70d54                                 fn_2b70d54
02d3936c: ldrb    w8, [x21, #0x10]                           
02d39370: cbnz    w8, #0x2d39420                             
02d39374: ldr     x8, [x20]                                  
02d39378: cbz     x8, #0x2d39448                             
02d3937c: ldr     x0, [x8, #0x18]                            MS:System.Collections.Generic.List`1::Add
02d39380: cbz     x0, #0x2d3944c                             
02d39384: mov     x1, xzr                                    
02d39388: bl      #0x5b339ec                                 UnityEngine.Component::get_gameObject
02d3938c: cbz     x0, #0x2d39450                             
02d39390: mov     w1, #1                                     
02d39394: mov     x2, xzr                                    
02d39398: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d3939c: ldr     x0, [x19, #0x50]!                          ._highlightTween
02d393a0: cbz     x0, #0x2d393b0                             
02d393a4: mov     w1, wzr                                    
02d393a8: mov     x2, xzr                                    
02d393ac: bl      #0x2d8fe94                                 DG.Tweening.TweenExtensions::Kill
02d393b0: ldr     x8, [x20]                                  
02d393b4: cbz     x8, #0x2d39454                             
02d393b8: ldr     x0, [x8, #0x18]                            MS:System.Collections.Generic.List`1::Add
02d393bc: adrp    x8, #0x1084000                             
02d393c0: fmov    s0, #0.50000000                            
02d393c4: mov     x1, xzr                                    
02d393c8: ldr     s1, [x8, #0xcc4]                           [1084cc4]=3f8000543f4ccccd f=0.8,1.00001
02d393cc: bl      #0x2c77d0c                                 DG.Tweening.DOTweenModuleSprite::DOFade
02d393d0: adrp    x8, #0x626a000                             
02d393d4: ldr     x8, [x8, #0xc80]                           MS:DG.Tweening.TweenSettingsExtensions::SetLoops
02d393d8: ldr     x3, [x8]                                   T:type56879(k15)
02d393dc: mov     w1, #-1                                    
02d393e0: mov     w2, #1                                     
02d393e4: bl      #0x336fe74                                 fn_336fe74
02d393e8: adrp    x8, #0x6264000                             
02d393ec: ldr     x8, [x8, #0x308]                           MS:DG.Tweening.TweenSettingsExtensions::SetEase
02d393f0: ldr     x2, [x8]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d393f4: mov     w1, #4                                     
02d393f8: bl      #0x336fa0c                                 fn_336fa0c
02d393fc: movi    d0, #0000000000000000                      
02d39400: mov     w1, #1                                     
02d39404: mov     w2, wzr                                    
02d39408: mov     x3, xzr                                    
02d3940c: bl      #0x2da04b8                                 DG.Tweening.TweenSettingsExtensions::From
02d39410: mov     x1, x0                                     
02d39414: str     x1, [x19]                                  
02d39418: mov     x0, x19                                    
02d3941c: bl      #0x2b70d54                                 fn_2b70d54
02d39420: ldr     x1, [x22]                                  T:type56879(k15)
02d39424: add     x0, sp, #0x20                              
02d39428: bl      #0x4690470                                 fn_4690470
02d3942c: ldp     x20, x19, [sp, #0x60]                      
02d39430: ldp     x22, x21, [sp, #0x50]                      
02d39434: ldp     x30, x23, [sp, #0x40]                      
02d39438: add     sp, sp, #0x70                              
02d3943c: ret                                                
02d39440: bl      #0x2b7105c                                 fn_2b7105c
02d39444: bl      #0x2b7105c                                 fn_2b7105c
02d39448: bl      #0x2b7105c                                 fn_2b7105c
02d3944c: bl      #0x2b7105c                                 fn_2b7105c
02d39450: bl      #0x2b7105c                                 fn_2b7105c
02d39454: bl      #0x2b7105c                                 fn_2b7105c
02d39458: b       #0x2d39484                                 
02d3945c: b       #0x2d39484                                 
02d39460: b       #0x2d39484                                 
02d39464: b       #0x2d39484                                 
02d39468: b       #0x2d39484                                 
02d3946c: b       #0x2d39484                                 
02d39470: b       #0x2d39484                                 
02d39474: b       #0x2d39484                                 
02d39478: b       #0x2d39484                                 
02d3947c: b       #0x2d39484                                 
02d39480: b       #0x2d39484                                 
02d39484: mov     x19, x0                                    
02d39488: cmp     w1, #1                                     
02d3948c: b.ne    #0x2d394c0                                 
02d39490: mov     x0, x19                                    
02d39494: bl      #0x5e90260                                 fn_5e90260
02d39498: ldr     x19, [x0]                                  T:type56879(k15)
02d3949c: str     x19, [sp, #8]                              
02d394a0: bl      #0x5e90270                                 fn_5e90270
02d394a4: ldr     x0, [sp, #0x10]                            
02d394a8: ldr     x1, [x22]                                  T:type56879(k15)
02d394ac: bl      #0x4690470                                 fn_4690470
02d394b0: cbz     x19, #0x2d3942c                            
02d394b4: mov     x0, x19                                    
02d394b8: bl      #0x2b71054                                 fn_2b71054
02d394bc: mov     x19, x0                                    
02d394c0: add     x0, sp, #8                                 
02d394c4: bl      #0x2738368                                 fn_2738368
02d394c8: mov     x0, x19                                    
02d394cc: bl      #0x2c6051c                                 fn_2c6051c
02d394d0: bl      #0x27369b8                                 fn_27369b8
## DisableHighlight() -> void
---- BlindBagCollection.CollectionBox::DisableHighlight 0x2d394d4
02d394d4: stp     x30, x19, [sp, #-0x10]!                    
02d394d8: mov     x19, x0                                    
02d394dc: ldr     x0, [x0, #0x50]                            ._highlightTween
02d394e0: cbz     x0, #0x2d394f0                             
02d394e4: mov     w1, wzr                                    
02d394e8: mov     x2, xzr                                    
02d394ec: bl      #0x2d8fe94                                 DG.Tweening.TweenExtensions::Kill
02d394f0: ldr     x8, [x19, #0x48]!                          ._currentBoxItem
02d394f4: cbz     x8, #0x2d39534                             
02d394f8: ldrb    w9, [x8, #0x10]                            
02d394fc: cbnz    w9, #0x2d39520                             
02d39500: ldr     x0, [x8, #0x18]                            
02d39504: cbz     x0, #0x2d39520                             
02d39508: mov     x1, xzr                                    
02d3950c: bl      #0x5b339ec                                 UnityEngine.Component::get_gameObject
02d39510: cbz     x0, #0x2d39534                             
02d39514: mov     w1, wzr                                    
02d39518: mov     x2, xzr                                    
02d3951c: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d39520: mov     x0, x19                                    
02d39524: mov     x1, xzr                                    
02d39528: str     xzr, [x19]                                 
02d3952c: ldp     x30, x19, [sp], #0x10                      
02d39530: b       #0x2b70d54                                 
02d39534: bl      #0x2b7105c                                 fn_2b7105c
## UnlockCurrentBox() -> void
---- BlindBagCollection.CollectionBox::UnlockCurrentBox 0x2d39538
02d39538: sub     sp, sp, #0x90                              
02d3953c: stp     x30, x27, [sp, #0x40]                      
02d39540: stp     x26, x25, [sp, #0x50]                      
02d39544: stp     x24, x23, [sp, #0x60]                      
02d39548: stp     x22, x21, [sp, #0x70]                      
02d3954c: stp     x20, x19, [sp, #0x80]                      
02d39550: adrp    x20, #0x6630000                            
02d39554: mov     x19, x0                                    
02d39558: ldrb    w8, [x20, #0x141]                          
02d3955c: tbnz    w8, #0, #0x2d395b0                         
02d39560: adrp    x0, #0x626a000                             
02d39564: ldr     x0, [x0, #0xc38]                           MS:UnityEngine.Component::GetComponentsInChildren
02d39568: bl      #0x2b70db0                                 fn_2b70db0
02d3956c: adrp    x0, #0x626a000                             
02d39570: ldr     x0, [x0, #0xc40]                           MS:System.Collections.Generic.List`1/Enumerator::Dispose
02d39574: bl      #0x2b70db0                                 fn_2b70db0
02d39578: adrp    x0, #0x626a000                             
02d3957c: ldr     x0, [x0, #0xc48]                           MS:System.Collections.Generic.List`1/Enumerator::MoveNext
02d39580: bl      #0x2b70db0                                 fn_2b70db0
02d39584: adrp    x0, #0x626a000                             
02d39588: ldr     x0, [x0, #0xc50]                           MS:System.Collections.Generic.List`1/Enumerator::get_Current
02d3958c: bl      #0x2b70db0                                 fn_2b70db0
02d39590: adrp    x0, #0x626a000                             
02d39594: ldr     x0, [x0, #0xc58]                           MS:System.Collections.Generic.List`1::GetEnumerator
02d39598: bl      #0x2b70db0                                 fn_2b70db0
02d3959c: adrp    x0, #0x6263000                             
02d395a0: ldr     x0, [x0, #0x918]                           T:UnityEngine.Object
02d395a4: bl      #0x2b70db0                                 fn_2b70db0
02d395a8: mov     w8, #1                                     
02d395ac: strb    w8, [x20, #0x141]                          
02d395b0: mov     x20, x19                                   
02d395b4: stp     xzr, xzr, [sp, #0x20]                      
02d395b8: ldr     x8, [x20, #0x48]!                          ._currentBoxItem
02d395bc: str     xzr, [sp, #0x30]                           
02d395c0: cbz     x8, #0x2d39758                             
02d395c4: ldrb    w8, [x8, #0x10]                            
02d395c8: cbnz    w8, #0x2d39758                             
02d395cc: ldr     x0, [x19, #0x30]                           ._collectionItems
02d395d0: cbz     x0, #0x2d3978c                             
02d395d4: adrp    x8, #0x626a000                             
02d395d8: ldr     x8, [x8, #0xc58]                           MS:System.Collections.Generic.List`1::GetEnumerator
02d395dc: ldr     x1, [x8]                                   T:type56879(k15)
02d395e0: add     x8, sp, #8                                 
02d395e4: bl      #0x35a9d9c                                 fn_35a9d9c
02d395e8: ldur    q0, [sp, #8]                               
02d395ec: ldr     x8, [sp, #0x18]                            
02d395f0: adrp    x21, #0x626a000                            
02d395f4: add     x9, sp, #0x20                              
02d395f8: str     q0, [sp, #0x20]                            
02d395fc: str     x8, [sp, #0x30]                            
02d39600: ldr     x21, [x21, #0xc48]                         MS:System.Collections.Generic.List`1/Enumerator::MoveNext
02d39604: stp     xzr, x9, [sp, #8]                          
02d39608: ldr     x1, [x21]                                  T:type56879(k15)
02d3960c: add     x0, sp, #0x20                              
02d39610: bl      #0x4690474                                 fn_4690474
02d39614: tbz     w0, #0, #0x2d39744                         
02d39618: ldr     x24, [sp, #0x30]                           
02d3961c: cbz     x24, #0x2d39774                            
02d39620: ldr     x8, [x20]                                  
02d39624: cbz     x8, #0x2d39778                             
02d39628: ldr     w9, [x24, #0x14]                           
02d3962c: ldr     w8, [x8, #0x14]                            [626a014]=0 f=0,0
02d39630: cmp     w9, w8                                     
02d39634: b.ne    #0x2d39608                                 
02d39638: ldr     x0, [x24, #0x18]                           
02d3963c: mov     w8, #1                                     
02d39640: strb    w8, [x24, #0x10]                           
02d39644: cbz     x0, #0x2d39790                             
02d39648: fmov    s0, #1.00000000                            
02d3964c: fmov    s1, #1.00000000                            
02d39650: mov     x1, xzr                                    
02d39654: fmov    s2, #1.00000000                            
02d39658: fmov    s3, #1.00000000                            
02d3965c: bl      #0x5ae711c                                 UnityEngine.SpriteRenderer::set_color
02d39660: ldr     w8, [x24, #0x14]                           
02d39664: cbnz    w8, #0x2d39720                             
02d39668: ldr     x0, [x24, #0x18]                           
02d3966c: cbz     x0, #0x2d39794                             
02d39670: adrp    x8, #0x626a000                             
02d39674: ldr     x8, [x8, #0xc38]                           MS:UnityEngine.Component::GetComponentsInChildren
02d39678: ldr     x2, [x8]                                   T:type56879(k15)
02d3967c: mov     w1, #1                                     
02d39680: bl      #0x31417a8                                 fn_31417a8
02d39684: mov     x21, x0                                    
02d39688: cbz     x0, #0x2d39798                             
02d3968c: ldr     x8, [x21, #0x18]                           MS:System.Collections.Generic.List`1::Add
02d39690: cmp     w8, #1                                     
02d39694: b.lt    #0x2d39720                                 
02d39698: adrp    x26, #0x6263000                            
02d3969c: mov     x25, xzr                                   
02d396a0: and     x8, x8, #0xffffffff                        
02d396a4: ldr     x26, [x26, #0x918]                         T:UnityEngine.Object
02d396a8: add     x27, x21, #0x20                            &626a020
02d396ac: cmp     x25, w8, uxtw                              
02d396b0: b.hs    #0x2d3977c                                 
02d396b4: ldr     x0, [x24, #0x18]                           
02d396b8: cbz     x0, #0x2d39780                             
02d396bc: ldr     x22, [x27, x25, lsl #3]                    
02d396c0: mov     x1, xzr                                    
02d396c4: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02d396c8: mov     x23, x0                                    
02d396cc: ldr     x0, [x26]                                  &2c5bbd4(=a9bd7bfdd503233f)
02d396d0: ldr     w8, [x0, #0xe4]                            [62630e4]=0 f=0,0
02d396d4: cbnz    w8, #0x2d396dc                             
02d396d8: bl      #0x2b70f30                                 fn_2b70f30
02d396dc: mov     x0, x22                                    
02d396e0: mov     x1, x23                                    
02d396e4: mov     x2, xzr                                    
02d396e8: bl      #0x5b3666c                                 UnityEngine.Object::op_Inequality
02d396ec: tbz     w0, #0, #0x2d39710                         
02d396f0: cbz     x22, #0x2d39784                            
02d396f4: mov     x0, x22                                    
02d396f8: mov     x1, xzr                                    
02d396fc: bl      #0x5b339ec                                 UnityEngine.Component::get_gameObject
02d39700: cbz     x0, #0x2d39788                             
02d39704: mov     w1, #1                                     
02d39708: mov     x2, xzr                                    
02d3970c: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d39710: ldr     w8, [x21, #0x18]                           MS:System.Collections.Generic.List`1::Add
02d39714: add     x25, x25, #1                               
02d39718: cmp     x25, w8, sxtw                              
02d3971c: b.lt    #0x2d396ac                                 
02d39720: ldr     x0, [x19, #0x50]                           ._highlightTween
02d39724: cbz     x0, #0x2d39734                             
02d39728: mov     w1, wzr                                    
02d3972c: mov     x2, xzr                                    
02d39730: bl      #0x2d8fe94                                 DG.Tweening.TweenExtensions::Kill
02d39734: str     xzr, [x20]                                 
02d39738: mov     x0, x20                                    
02d3973c: mov     x1, xzr                                    
02d39740: bl      #0x2b70d54                                 fn_2b70d54
02d39744: adrp    x8, #0x626a000                             
02d39748: add     x0, sp, #0x20                              
02d3974c: ldr     x8, [x8, #0xc40]                           MS:System.Collections.Generic.List`1/Enumerator::Dispose
02d39750: ldr     x1, [x8]                                   T:type56879(k15)
02d39754: bl      #0x4690470                                 fn_4690470
02d39758: ldp     x20, x19, [sp, #0x80]                      
02d3975c: ldp     x22, x21, [sp, #0x70]                      
02d39760: ldp     x24, x23, [sp, #0x60]                      
02d39764: ldp     x26, x25, [sp, #0x50]                      
02d39768: ldp     x30, x27, [sp, #0x40]                      
02d3976c: add     sp, sp, #0x90                              
02d39770: ret                                                
02d39774: bl      #0x2b7105c                                 fn_2b7105c
02d39778: bl      #0x2b7105c                                 fn_2b7105c
02d3977c: bl      #0x2b71064                                 fn_2b71064
02d39780: bl      #0x2b7105c                                 fn_2b7105c
02d39784: bl      #0x2b7105c                                 fn_2b7105c
02d39788: bl      #0x2b7105c                                 fn_2b7105c
02d3978c: bl      #0x2b7105c                                 fn_2b7105c
02d39790: bl      #0x2b7105c                                 fn_2b7105c
02d39794: bl      #0x2b7105c                                 fn_2b7105c
02d39798: bl      #0x2b7105c                                 fn_2b7105c
02d3979c: b       #0x2d397d4                                 
02d397a0: b       #0x2d397d4                                 
02d397a4: b       #0x2d397d4                                 
02d397a8: b       #0x2d397d4                                 
02d397ac: b       #0x2d397d4                                 
02d397b0: b       #0x2d397d4                                 
02d397b4: b       #0x2d397d4                                 
02d397b8: b       #0x2d397d4                                 
02d397bc: b       #0x2d397d4                                 
02d397c0: b       #0x2d397d4                                 
02d397c4: b       #0x2d397d4                                 
02d397c8: b       #0x2d397d4                                 
02d397cc: b       #0x2d397d4                                 
02d397d0: b       #0x2d397d4                                 
02d397d4: mov     x19, x0                                    
02d397d8: cmp     w1, #1                                     
02d397dc: b.ne    #0x2d39818                                 
02d397e0: mov     x0, x19                                    
02d397e4: bl      #0x5e90260                                 fn_5e90260
02d397e8: ldr     x19, [x0]                                  &2c5bbd4(=a9bd7bfdd503233f)
02d397ec: str     x19, [sp, #8]                              
02d397f0: bl      #0x5e90270                                 fn_5e90270
02d397f4: adrp    x8, #0x626a000                             
02d397f8: ldr     x8, [x8, #0xc40]                           MS:System.Collections.Generic.List`1/Enumerator::Dispose
02d397fc: ldr     x0, [sp, #0x10]                            
02d39800: ldr     x1, [x8]                                   T:type56879(k15)
02d39804: bl      #0x4690470                                 fn_4690470
02d39808: cbz     x19, #0x2d39758                            
02d3980c: mov     x0, x19                                    
02d39810: bl      #0x2b71054                                 fn_2b71054
02d39814: mov     x19, x0                                    
02d39818: add     x0, sp, #8                                 
02d3981c: bl      #0x2738368                                 fn_2738368
02d39820: mov     x0, x19                                    
02d39824: bl      #0x2c6051c                                 fn_2c6051c
02d39828: bl      #0x27369b8                                 fn_27369b8
## .ctor() -> void
---- BlindBagCollection.CollectionBox::.ctor 0x2d3982c
02d3982c: str     x30, [sp, #-0x30]!                         
02d39830: stp     x22, x21, [sp, #0x10]                      
02d39834: stp     x20, x19, [sp, #0x20]                      
02d39838: adrp    x21, #0x6630000                            
02d3983c: adrp    x22, #0x626a000                            
02d39840: adrp    x20, #0x626a000                            
02d39844: ldrb    w8, [x21, #0x142]                          
02d39848: ldr     x22, [x22, #0xaf0]                         T:type56657(k15)
02d3984c: ldr     x20, [x20, #0xae8]                         MS:System.Collections.Generic.List`1::.ctor
02d39850: mov     x19, x0                                    
02d39854: tbnz    w8, #0, #0x2d39884                         
02d39858: adrp    x0, #0x626a000                             
02d3985c: ldr     x0, [x0, #0xad8]                           MS:System.Collections.Generic.List`1::Add
02d39860: bl      #0x2b70db0                                 fn_2b70db0
02d39864: adrp    x0, #0x626a000                             
02d39868: ldr     x0, [x0, #0xae8]                           MS:System.Collections.Generic.List`1::.ctor
02d3986c: bl      #0x2b70db0                                 fn_2b70db0
02d39870: adrp    x0, #0x626a000                             
02d39874: ldr     x0, [x0, #0xaf0]                           T:type56657(k15)
02d39878: bl      #0x2b70db0                                 fn_2b70db0
02d3987c: mov     w8, #1                                     
02d39880: strb    w8, [x21, #0x142]                          
02d39884: ldr     x0, [x22]                                  T:type56879(k15)
02d39888: bl      #0x2b7104c                                 fn_2b7104c
02d3988c: ldr     x1, [x20]                                  T:type56879(k15)
02d39890: mov     x20, x0                                    
02d39894: bl      #0x356bce8                                 fn_356bce8
02d39898: cbz     x20, #0x2d39dd0                            
02d3989c: adrp    x21, #0x626a000                            
02d398a0: ldr     x21, [x21, #0xad8]                         MS:System.Collections.Generic.List`1::Add
02d398a4: ldr     w10, [x20, #0x1c]                          [626a01c]=0 f=0,0
02d398a8: ldr     x8, [x20, #0x10]                           T:Decor.DataDecor/CategoryData
02d398ac: ldr     x9, [x21]                                  T:type56879(k15)
02d398b0: add     w10, w10, #1                               
02d398b4: str     w10, [x20, #0x1c]                          
02d398b8: cbz     x8, #0x2d39dd0                             
02d398bc: ldrsw   x10, [x20, #0x18]                          
02d398c0: ldr     w11, [x8, #0x18]                           
02d398c4: cmp     w10, w11                                   
02d398c8: b.hs    #0x2d398ec                                 
02d398cc: add     w11, w10, #1                               
02d398d0: add     x10, x8, x10, lsl #2                       
02d398d4: str     w11, [x20, #0x18]                          
02d398d8: str     wzr, [x10, #0x20]                          
02d398dc: ldr     w10, [x20, #0x1c]                          [626a01c]=0 f=0,0
02d398e0: add     w10, w10, #1                               
02d398e4: str     w10, [x20, #0x1c]                          
02d398e8: b       #0x2d3991c                                 
02d398ec: ldr     x8, [x9, #0x20]                            
02d398f0: mov     x0, x20                                    
02d398f4: mov     w1, wzr                                    
02d398f8: ldr     x8, [x8, #0xc0]                            
02d398fc: ldr     x2, [x8, #0x70]                            
02d39900: bl      #0x356c578                                 fn_356c578
02d39904: ldr     w10, [x20, #0x1c]                          [626a01c]=0 f=0,0
02d39908: ldr     x8, [x20, #0x10]                           T:Decor.DataDecor/CategoryData
02d3990c: ldr     x9, [x21]                                  T:type56879(k15)
02d39910: add     w10, w10, #1                               
02d39914: str     w10, [x20, #0x1c]                          
02d39918: cbz     x8, #0x2d39dd0                             
02d3991c: ldrsw   x10, [x20, #0x18]                          
02d39920: ldr     w11, [x8, #0x18]                           
02d39924: cmp     w10, w11                                   
02d39928: b.hs    #0x2d39950                                 
02d3992c: add     w11, w10, #1                               
02d39930: add     x10, x8, x10, lsl #2                       
02d39934: str     w11, [x20, #0x18]                          
02d39938: mov     w11, #1                                    
02d3993c: str     w11, [x10, #0x20]                          
02d39940: ldr     w10, [x20, #0x1c]                          [626a01c]=0 f=0,0
02d39944: add     w10, w10, #1                               
02d39948: str     w10, [x20, #0x1c]                          
02d3994c: b       #0x2d39980                                 
02d39950: ldr     x8, [x9, #0x20]                            
02d39954: mov     x0, x20                                    
02d39958: mov     w1, #1                                     
02d3995c: ldr     x8, [x8, #0xc0]                            
02d39960: ldr     x2, [x8, #0x70]                            
02d39964: bl      #0x356c578                                 fn_356c578
02d39968: ldr     w10, [x20, #0x1c]                          [626a01c]=0 f=0,0
02d3996c: ldr     x8, [x20, #0x10]                           T:Decor.DataDecor/CategoryData
02d39970: ldr     x9, [x21]                                  T:type56879(k15)
02d39974: add     w10, w10, #1                               
02d39978: str     w10, [x20, #0x1c]                          
02d3997c: cbz     x8, #0x2d39dd0                             
02d39980: ldrsw   x10, [x20, #0x18]                          
02d39984: ldr     w11, [x8, #0x18]                           
02d39988: cmp     w10, w11                                   
02d3998c: b.hs    #0x2d399b4                                 
02d39990: add     w11, w10, #1                               
02d39994: add     x10, x8, x10, lsl #2                       
02d39998: str     w11, [x20, #0x18]                          
02d3999c: mov     w11, #2                                    
02d399a0: str     w11, [x10, #0x20]                          
02d399a4: ldr     w10, [x20, #0x1c]                          [626a01c]=0 f=0,0
02d399a8: add     w10, w10, #1                               
02d399ac: str     w10, [x20, #0x1c]                          
02d399b0: b       #0x2d399e4                                 
02d399b4: ldr     x8, [x9, #0x20]                            
02d399b8: mov     x0, x20                                    
02d399bc: mov     w1, #2                                     
02d399c0: ldr     x8, [x8, #0xc0]                            
02d399c4: ldr     x2, [x8, #0x70]                            
02d399c8: bl      #0x356c578                                 fn_356c578
02d399cc: ldr     w10, [x20, #0x1c]                          [626a01c]=0 f=0,0
02d399d0: ldr     x8, [x20, #0x10]                           T:Decor.DataDecor/CategoryData
02d399d4: ldr     x9, [x21]                                  T:type56879(k15)
02d399d8: add     w10, w10, #1                               
02d399dc: str     w10, [x20, #0x1c]                          
02d399e0: cbz     x8, #0x2d39dd0                             
02d399e4: ldrsw   x10, [x20, #0x18]                          
02d399e8: ldr     w11, [x8, #0x18]                           
02d399ec: cmp     w10, w11                                   
02d399f0: b.hs    #0x2d39a18                                 
02d399f4: add     w11, w10, #1                               
02d399f8: add     x10, x8, x10, lsl #2                       
02d399fc: str     w11, [x20, #0x18]                          
02d39a00: mov     w11, #3                                    
02d39a04: str     w11, [x10, #0x20]                          
02d39a08: ldr     w10, [x20, #0x1c]                          [626a01c]=0 f=0,0
02d39a0c: add     w10, w10, #1                               
02d39a10: str     w10, [x20, #0x1c]                          
02d39a14: b       #0x2d39a48                                 
02d39a18: ldr     x8, [x9, #0x20]                            
02d39a1c: mov     x0, x20                                    
02d39a20: mov     w1, #3                                     
02d39a24: ldr     x8, [x8, #0xc0]                            
02d39a28: ldr     x2, [x8, #0x70]                            
02d39a2c: bl      #0x356c578                                 fn_356c578
02d39a30: ldr     w10, [x20, #0x1c]                          [626a01c]=0 f=0,0
02d39a34: ldr     x8, [x20, #0x10]                           T:Decor.DataDecor/CategoryData
02d39a38: ldr     x9, [x21]                                  T:type56879(k15)
02d39a3c: add     w10, w10, #1                               
02d39a40: str     w10, [x20, #0x1c]                          
02d39a44: cbz     x8, #0x2d39dd0                             
02d39a48: ldrsw   x10, [x20, #0x18]                          
02d39a4c: ldr     w11, [x8, #0x18]                           
02d39a50: cmp     w10, w11                                   
02d39a54: b.hs    #0x2d39a7c                                 
02d39a58: add     w11, w10, #1                               
02d39a5c: add     x10, x8, x10, lsl #2                       
02d39a60: str     w11, [x20, #0x18]                          
02d39a64: mov     w11, #4                                    
02d39a68: str     w11, [x10, #0x20]                          
02d39a6c: ldr     w10, [x20, #0x1c]                          [626a01c]=0 f=0,0
02d39a70: add     w10, w10, #1                               
02d39a74: str     w10, [x20, #0x1c]                          
02d39a78: b       #0x2d39aac                                 
02d39a7c: ldr     x8, [x9, #0x20]                            
02d39a80: mov     x0, x20                                    
02d39a84: mov     w1, #4                                     
02d39a88: ldr     x8, [x8, #0xc0]                            
02d39a8c: ldr     x2, [x8, #0x70]                            
02d39a90: bl      #0x356c578                                 fn_356c578
02d39a94: ldr     w10, [x20, #0x1c]                          [626a01c]=0 f=0,0
02d39a98: ldr     x8, [x20, #0x10]                           T:Decor.DataDecor/CategoryData
02d39a9c: ldr     x9, [x21]                                  T:type56879(k15)
02d39aa0: add     w10, w10, #1                               
02d39aa4: str     w10, [x20, #0x1c]                          
02d39aa8: cbz     x8, #0x2d39dd0                             
02d39aac: ldrsw   x10, [x20, #0x18]                          
02d39ab0: ldr     w11, [x8, #0x18]                           
02d39ab4: cmp     w10, w11                                   
02d39ab8: b.hs    #0x2d39ae0                                 
02d39abc: add     w11, w10, #1                               
02d39ac0: add     x10, x8, x10, lsl #2                       
02d39ac4: str     w11, [x20, #0x18]                          
02d39ac8: mov     w11, #5                                    
02d39acc: str     w11, [x10, #0x20]                          
02d39ad0: ldr     w10, [x20, #0x1c]                          [626a01c]=0 f=0,0
02d39ad4: add     w10, w10, #1                               
02d39ad8: str     w10, [x20, #0x1c]                          
02d39adc: b       #0x2d39b10                                 
02d39ae0: ldr     x8, [x9, #0x20]                            
02d39ae4: mov     x0, x20                                    
02d39ae8: mov     w1, #5                                     
02d39aec: ldr     x8, [x8, #0xc0]                            
02d39af0: ldr     x2, [x8, #0x70]                            
02d39af4: bl      #0x356c578                                 fn_356c578
02d39af8: ldr     w10, [x20, #0x1c]                          [626a01c]=0 f=0,0
02d39afc: ldr     x8, [x20, #0x10]                           T:Decor.DataDecor/CategoryData
02d39b00: ldr     x9, [x21]                                  T:type56879(k15)
02d39b04: add     w10, w10, #1                               
02d39b08: str     w10, [x20, #0x1c]                          
02d39b0c: cbz     x8, #0x2d39dd0                             
02d39b10: ldrsw   x10, [x20, #0x18]                          
02d39b14: ldr     w11, [x8, #0x18]                           
02d39b18: cmp     w10, w11                                   
02d39b1c: b.hs    #0x2d39b44                                 
02d39b20: add     w11, w10, #1                               
02d39b24: add     x10, x8, x10, lsl #2                       
02d39b28: str     w11, [x20, #0x18]                          
02d39b2c: mov     w11, #6                                    
02d39b30: str     w11, [x10, #0x20]                          
02d39b34: ldr     w10, [x20, #0x1c]                          [626a01c]=0 f=0,0
02d39b38: add     w10, w10, #1                               
02d39b3c: str     w10, [x20, #0x1c]                          
02d39b40: b       #0x2d39b74                                 
02d39b44: ldr     x8, [x9, #0x20]                            
02d39b48: mov     x0, x20                                    
02d39b4c: mov     w1, #6                                     
02d39b50: ldr     x8, [x8, #0xc0]                            
02d39b54: ldr     x2, [x8, #0x70]                            
02d39b58: bl      #0x356c578                                 fn_356c578
02d39b5c: ldr     w10, [x20, #0x1c]                          [626a01c]=0 f=0,0
02d39b60: ldr     x8, [x20, #0x10]                           T:Decor.DataDecor/CategoryData
02d39b64: ldr     x9, [x21]                                  T:type56879(k15)
02d39b68: add     w10, w10, #1                               
02d39b6c: str     w10, [x20, #0x1c]                          
02d39b70: cbz     x8, #0x2d39dd0                             
02d39b74: ldrsw   x10, [x20, #0x18]                          
02d39b78: ldr     w11, [x8, #0x18]                           
02d39b7c: cmp     w10, w11                                   
02d39b80: b.hs    #0x2d39ba8                                 
02d39b84: add     w11, w10, #1                               
02d39b88: add     x10, x8, x10, lsl #2                       
02d39b8c: str     w11, [x20, #0x18]                          
02d39b90: mov     w11, #7                                    
02d39b94: str     w11, [x10, #0x20]                          
02d39b98: ldr     w10, [x20, #0x1c]                          [626a01c]=0 f=0,0
02d39b9c: add     w10, w10, #1                               
02d39ba0: str     w10, [x20, #0x1c]                          
02d39ba4: b       #0x2d39bd8                                 
02d39ba8: ldr     x8, [x9, #0x20]                            
02d39bac: mov     x0, x20                                    
02d39bb0: mov     w1, #7                                     
02d39bb4: ldr     x8, [x8, #0xc0]                            
02d39bb8: ldr     x2, [x8, #0x70]                            
02d39bbc: bl      #0x356c578                                 fn_356c578
02d39bc0: ldr     w10, [x20, #0x1c]                          [626a01c]=0 f=0,0
02d39bc4: ldr     x8, [x20, #0x10]                           T:Decor.DataDecor/CategoryData
02d39bc8: ldr     x9, [x21]                                  T:type56879(k15)
02d39bcc: add     w10, w10, #1                               
02d39bd0: str     w10, [x20, #0x1c]                          
02d39bd4: cbz     x8, #0x2d39dd0                             
02d39bd8: ldrsw   x10, [x20, #0x18]                          
02d39bdc: ldr     w11, [x8, #0x18]                           
02d39be0: cmp     w10, w11                                   
02d39be4: b.hs    #0x2d39c0c                                 
02d39be8: add     w11, w10, #1                               
02d39bec: add     x10, x8, x10, lsl #2                       
02d39bf0: str     w11, [x20, #0x18]                          
02d39bf4: mov     w11, #8                                    
02d39bf8: str     w11, [x10, #0x20]                          
02d39bfc: ldr     w10, [x20, #0x1c]                          [626a01c]=0 f=0,0
02d39c00: add     w10, w10, #1                               
02d39c04: str     w10, [x20, #0x1c]                          
02d39c08: b       #0x2d39c3c                                 
02d39c0c: ldr     x8, [x9, #0x20]                            
02d39c10: mov     x0, x20                                    
02d39c14: mov     w1, #8                                     
02d39c18: ldr     x8, [x8, #0xc0]                            
02d39c1c: ldr     x2, [x8, #0x70]                            
02d39c20: bl      #0x356c578                                 fn_356c578
02d39c24: ldr     w10, [x20, #0x1c]                          [626a01c]=0 f=0,0
02d39c28: ldr     x8, [x20, #0x10]                           T:Decor.DataDecor/CategoryData
02d39c2c: ldr     x9, [x21]                                  T:type56879(k15)
02d39c30: add     w10, w10, #1                               
02d39c34: str     w10, [x20, #0x1c]                          
02d39c38: cbz     x8, #0x2d39dd0                             
02d39c3c: ldrsw   x10, [x20, #0x18]                          
02d39c40: ldr     w11, [x8, #0x18]                           
02d39c44: cmp     w10, w11                                   
02d39c48: b.hs    #0x2d39c70                                 
02d39c4c: add     w11, w10, #1                               
02d39c50: add     x10, x8, x10, lsl #2                       
02d39c54: str     w11, [x20, #0x18]                          
02d39c58: mov     w11, #9                                    
02d39c5c: str     w11, [x10, #0x20]                          
02d39c60: ldr     w10, [x20, #0x1c]                          [626a01c]=0 f=0,0
02d39c64: add     w10, w10, #1                               
02d39c68: str     w10, [x20, #0x1c]                          
02d39c6c: b       #0x2d39ca0                                 
02d39c70: ldr     x8, [x9, #0x20]                            
02d39c74: mov     x0, x20                                    
02d39c78: mov     w1, #9                                     
02d39c7c: ldr     x8, [x8, #0xc0]                            
02d39c80: ldr     x2, [x8, #0x70]                            
02d39c84: bl      #0x356c578                                 fn_356c578
02d39c88: ldr     w10, [x20, #0x1c]                          [626a01c]=0 f=0,0
02d39c8c: ldr     x8, [x20, #0x10]                           T:Decor.DataDecor/CategoryData
02d39c90: ldr     x9, [x21]                                  T:type56879(k15)
02d39c94: add     w10, w10, #1                               
02d39c98: str     w10, [x20, #0x1c]                          
02d39c9c: cbz     x8, #0x2d39dd0                             
02d39ca0: ldrsw   x10, [x20, #0x18]                          
02d39ca4: ldr     w11, [x8, #0x18]                           
02d39ca8: cmp     w10, w11                                   
02d39cac: b.hs    #0x2d39cd4                                 
02d39cb0: add     w11, w10, #1                               
02d39cb4: add     x10, x8, x10, lsl #2                       
02d39cb8: str     w11, [x20, #0x18]                          
02d39cbc: mov     w11, #0xa                                  
02d39cc0: str     w11, [x10, #0x20]                          
02d39cc4: ldr     w10, [x20, #0x1c]                          [626a01c]=0 f=0,0
02d39cc8: add     w10, w10, #1                               
02d39ccc: str     w10, [x20, #0x1c]                          
02d39cd0: b       #0x2d39d04                                 
02d39cd4: ldr     x8, [x9, #0x20]                            
02d39cd8: mov     x0, x20                                    
02d39cdc: mov     w1, #0xa                                   
02d39ce0: ldr     x8, [x8, #0xc0]                            
02d39ce4: ldr     x2, [x8, #0x70]                            
02d39ce8: bl      #0x356c578                                 fn_356c578
02d39cec: ldr     w10, [x20, #0x1c]                          [626a01c]=0 f=0,0
02d39cf0: ldr     x8, [x20, #0x10]                           T:Decor.DataDecor/CategoryData
02d39cf4: ldr     x9, [x21]                                  T:type56879(k15)
02d39cf8: add     w10, w10, #1                               
02d39cfc: str     w10, [x20, #0x1c]                          
02d39d00: cbz     x8, #0x2d39dd0                             
02d39d04: ldrsw   x10, [x20, #0x18]                          
02d39d08: ldr     w11, [x8, #0x18]                           
02d39d0c: cmp     w10, w11                                   
02d39d10: b.hs    #0x2d39d38                                 
02d39d14: add     w11, w10, #1                               
02d39d18: add     x10, x8, x10, lsl #2                       
02d39d1c: str     w11, [x20, #0x18]                          
02d39d20: mov     w11, #0xb                                  
02d39d24: str     w11, [x10, #0x20]                          
02d39d28: ldr     w10, [x20, #0x1c]                          [626a01c]=0 f=0,0
02d39d2c: add     w10, w10, #1                               
02d39d30: str     w10, [x20, #0x1c]                          
02d39d34: b       #0x2d39d68                                 
02d39d38: ldr     x8, [x9, #0x20]                            
02d39d3c: mov     x0, x20                                    
02d39d40: mov     w1, #0xb                                   
02d39d44: ldr     x8, [x8, #0xc0]                            
02d39d48: ldr     x2, [x8, #0x70]                            
02d39d4c: bl      #0x356c578                                 fn_356c578
02d39d50: ldr     w10, [x20, #0x1c]                          [626a01c]=0 f=0,0
02d39d54: ldr     x8, [x20, #0x10]                           T:Decor.DataDecor/CategoryData
02d39d58: ldr     x9, [x21]                                  T:type56879(k15)
02d39d5c: add     w10, w10, #1                               
02d39d60: str     w10, [x20, #0x1c]                          
02d39d64: cbz     x8, #0x2d39dd0                             
02d39d68: ldrsw   x10, [x20, #0x18]                          
02d39d6c: ldr     w11, [x8, #0x18]                           
02d39d70: cmp     w10, w11                                   
02d39d74: b.hs    #0x2d39d90                                 
02d39d78: add     w9, w10, #1                                
02d39d7c: add     x8, x8, x10, lsl #2                        
02d39d80: str     w9, [x20, #0x18]                           
02d39d84: mov     w9, #0xc                                   
02d39d88: str     w9, [x8, #0x20]                            
02d39d8c: b       #0x2d39da8                                 
02d39d90: ldr     x8, [x9, #0x20]                            
02d39d94: mov     x0, x20                                    
02d39d98: mov     w1, #0xc                                   
02d39d9c: ldr     x8, [x8, #0xc0]                            
02d39da0: ldr     x2, [x8, #0x70]                            
02d39da4: bl      #0x356c578                                 fn_356c578
02d39da8: mov     x0, x19                                    
02d39dac: mov     x1, x20                                    
02d39db0: str     x20, [x0, #0x40]!                          ._enumSetup
02d39db4: bl      #0x2b70d54                                 fn_2b70d54
02d39db8: mov     x0, x19                                    
02d39dbc: ldp     x20, x19, [sp, #0x20]                      
02d39dc0: ldp     x22, x21, [sp, #0x10]                      
02d39dc4: mov     x1, xzr                                    
02d39dc8: ldr     x30, [sp], #0x30                           
02d39dcc: b       #0x5b397b0                                 UnityEngine.MonoBehaviour::.ctor
02d39dd0: bl      #0x2b7105c                                 fn_2b7105c
