#### CLASS Games.RandomAnimation parent= UnityEngine.MonoBehaviour
#   field _skeletonGraphic               Spine.Unity.SkeletonGraphic                        off=0x20 attr=1 SerializeField
#   field _animationList                 System.Collections.Generic.List`1<string>          off=0x28 attr=1 
## Awake() -> void
---- Games.RandomAnimation::Awake 0x2d301d8
02d301d8: b       #0x2d301dc                                 Games.RandomAnimation::GetAllAnimationName
## GetAllAnimationName() -> void
---- Games.RandomAnimation::GetAllAnimationName 0x2d301dc
02d301dc: sub     sp, sp, #0x60                              
02d301e0: str     x30, [sp, #0x30]                           
02d301e4: stp     x22, x21, [sp, #0x40]                      
02d301e8: stp     x20, x19, [sp, #0x50]                      
02d301ec: adrp    x22, #0x6630000                            
02d301f0: adrp    x21, #0x6266000                            
02d301f4: adrp    x20, #0x6266000                            
02d301f8: ldrb    w8, [x22, #0xef]                           
02d301fc: ldr     x21, [x21, #0xe48]                         T:type15376(k15)
02d30200: ldr     x20, [x20, #0xe50]                         MS:System.Collections.Generic.List`1::.ctor
02d30204: mov     x19, x0                                    
02d30208: tbnz    w8, #0, #0x2d30274                         
02d3020c: adrp    x0, #0x6266000                             
02d30210: ldr     x0, [x0, #0xc08]                           MS:Spine.ExposedList`1/Enumerator::Dispose
02d30214: bl      #0x2b70db0                                 fn_2b70db0
02d30218: adrp    x0, #0x6266000                             
02d3021c: ldr     x0, [x0, #0xc10]                           MS:Spine.ExposedList`1/Enumerator::MoveNext
02d30220: bl      #0x2b70db0                                 fn_2b70db0
02d30224: adrp    x0, #0x6266000                             
02d30228: ldr     x0, [x0, #0xc18]                           MS:Spine.ExposedList`1/Enumerator::get_Current
02d3022c: bl      #0x2b70db0                                 fn_2b70db0
02d30230: adrp    x0, #0x6266000                             
02d30234: ldr     x0, [x0, #0xc20]                           MS:Spine.ExposedList`1::GetEnumerator
02d30238: bl      #0x2b70db0                                 fn_2b70db0
02d3023c: adrp    x0, #0x6266000                             
02d30240: ldr     x0, [x0, #0xe58]                           MS:System.Collections.Generic.List`1::Add
02d30244: bl      #0x2b70db0                                 fn_2b70db0
02d30248: adrp    x0, #0x6266000                             
02d3024c: ldr     x0, [x0, #0xe50]                           MS:System.Collections.Generic.List`1::.ctor
02d30250: bl      #0x2b70db0                                 fn_2b70db0
02d30254: adrp    x0, #0x6266000                             
02d30258: ldr     x0, [x0, #0xe48]                           T:type15376(k15)
02d3025c: bl      #0x2b70db0                                 fn_2b70db0
02d30260: adrp    x0, #0x6263000                             
02d30264: ldr     x0, [x0, #0x918]                           T:UnityEngine.Object
02d30268: bl      #0x2b70db0                                 fn_2b70db0
02d3026c: mov     w8, #1                                     
02d30270: strb    w8, [x22, #0xef]                           
02d30274: ldr     x0, [x21]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d30278: stp     xzr, xzr, [sp, #0x18]                      
02d3027c: str     xzr, [sp, #0x28]                           
02d30280: bl      #0x2b7104c                                 fn_2b7104c
02d30284: ldr     x1, [x20]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d30288: mov     x20, x0                                    
02d3028c: bl      #0x35a89a4                                 fn_35a89a4
02d30290: str     x20, [x19, #0x28]!                         ._animationList
02d30294: mov     x0, x19                                    
02d30298: mov     x1, x20                                    
02d3029c: bl      #0x2b70d54                                 fn_2b70d54
02d302a0: ldur    x8, [x19, #-8]                             
02d302a4: cbz     x8, #0x2d303d0                             
02d302a8: adrp    x9, #0x6263000                             
02d302ac: ldr     x9, [x9, #0x918]                           T:UnityEngine.Object
02d302b0: ldr     x20, [x8, #0xd8]                           
02d302b4: ldr     x0, [x9]                                   &2c5bbd4(=a9bd7bfdd503233f)
02d302b8: ldr     w9, [x0, #0xe4]                            [62630e4]=0 f=0,0
02d302bc: cbnz    w9, #0x2d302c4                             
02d302c0: bl      #0x2b70f30                                 fn_2b70f30
02d302c4: mov     x0, x20                                    
02d302c8: mov     x1, xzr                                    
02d302cc: mov     x2, xzr                                    
02d302d0: bl      #0x5b37d84                                 UnityEngine.Object::op_Equality
02d302d4: tbnz    w0, #0, #0x2d303b4                         
02d302d8: cbz     x20, #0x2d303d0                            
02d302dc: mov     x0, x20                                    
02d302e0: mov     w1, wzr                                    
02d302e4: mov     x2, xzr                                    
02d302e8: bl      #0x4fe7d38                                 Spine.Unity.SkeletonDataAsset::GetSkeletonData
02d302ec: cbz     x0, #0x2d303d0                             
02d302f0: ldr     x0, [x0, #0x40]                            [6263040]=0 f=0,0
02d302f4: cbz     x0, #0x2d303d0                             
02d302f8: adrp    x8, #0x6266000                             
02d302fc: add     x22, sp, #0x18                             
02d30300: ldr     x8, [x8, #0xc20]                           MS:Spine.ExposedList`1::GetEnumerator
02d30304: ldr     x1, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d30308: add     x8, sp, #0x18                              
02d3030c: bl      #0x48a9ecc                                 fn_48a9ecc
02d30310: adrp    x20, #0x6266000                            
02d30314: adrp    x21, #0x6266000                            
02d30318: ldr     x20, [x20, #0xc10]                         MS:Spine.ExposedList`1/Enumerator::MoveNext
02d3031c: ldr     x21, [x21, #0xe58]                         MS:System.Collections.Generic.List`1::Add
02d30320: stp     xzr, x22, [sp, #8]                         
02d30324: ldr     x1, [x20]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d30328: add     x0, sp, #0x18                              
02d3032c: bl      #0x468fb10                                 fn_468fb10
02d30330: tbz     w0, #0, #0x2d303a0                         
02d30334: ldr     x9, [sp, #0x28]                            
02d30338: cbz     x9, #0x2d303cc                             
02d3033c: ldr     x0, [x19]                                  
02d30340: cbz     x0, #0x2d303c8                             
02d30344: ldr     w10, [x0, #0x1c]                           [626301c]=0 f=0,0
02d30348: ldr     x8, [x0, #0x10]                            &2c498bc(=aa1f03e0d503245f)
02d3034c: ldr     x1, [x9, #0x10]                            &2c498bc(=aa1f03e0d503245f)
02d30350: ldr     x9, [x21]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d30354: add     w10, w10, #1                               
02d30358: str     w10, [x0, #0x1c]                           
02d3035c: cbz     x8, #0x2d303c8                             
02d30360: ldrsw   x10, [x0, #0x18]                           
02d30364: ldr     w11, [x8, #0x18]                           S:'level_show_popuprate'
02d30368: cmp     w10, w11                                   
02d3036c: b.hs    #0x2d3038c                                 
02d30370: add     x8, x8, x10, lsl #3                        &6266000
02d30374: add     w9, w10, #1                                
02d30378: str     w9, [x0, #0x18]                            
02d3037c: str     x1, [x8, #0x20]!                           
02d30380: mov     x0, x8                                     
02d30384: bl      #0x2b70d54                                 fn_2b70d54
02d30388: b       #0x2d30324                                 
02d3038c: ldr     x8, [x9, #0x20]                            &2c5bd40(=14c8d27fd503245f)
02d30390: ldr     x8, [x8, #0xc0]                            T:Firebase.RemoteConfig.ConfigValue
02d30394: ldr     x2, [x8, #0x70]                            S:'open_ad_id'
02d30398: bl      #0x35a920c                                 fn_35a920c
02d3039c: b       #0x2d30324                                 
02d303a0: adrp    x8, #0x6266000                             
02d303a4: add     x0, sp, #0x18                              
02d303a8: ldr     x8, [x8, #0xc08]                           MS:Spine.ExposedList`1/Enumerator::Dispose
02d303ac: ldr     x1, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d303b0: bl      #0x468fa14                                 fn_468fa14
02d303b4: ldp     x20, x19, [sp, #0x50]                      
02d303b8: ldr     x30, [sp, #0x30]                           
02d303bc: ldp     x22, x21, [sp, #0x40]                      
02d303c0: add     sp, sp, #0x60                              
02d303c4: ret                                                
02d303c8: bl      #0x2b7105c                                 fn_2b7105c
02d303cc: bl      #0x2b7105c                                 fn_2b7105c
02d303d0: bl      #0x2b7105c                                 fn_2b7105c
02d303d4: b       #0x2d303e0                                 
02d303d8: b       #0x2d303e0                                 
02d303dc: b       #0x2d303e0                                 
02d303e0: mov     x19, x0                                    
02d303e4: cmp     w1, #1                                     
02d303e8: b.ne    #0x2d30424                                 
02d303ec: mov     x0, x19                                    
02d303f0: bl      #0x5e90260                                 fn_5e90260
02d303f4: ldr     x19, [x0]                                  &2c5bbd4(=a9bd7bfdd503233f)
02d303f8: str     x19, [sp, #8]                              
02d303fc: bl      #0x5e90270                                 fn_5e90270
02d30400: adrp    x8, #0x6266000                             
02d30404: ldr     x8, [x8, #0xc08]                           MS:Spine.ExposedList`1/Enumerator::Dispose
02d30408: ldr     x0, [sp, #0x10]                            
02d3040c: ldr     x1, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d30410: bl      #0x468fa14                                 fn_468fa14
02d30414: cbz     x19, #0x2d303b4                            
02d30418: mov     x0, x19                                    
02d3041c: bl      #0x2b71054                                 fn_2b71054
02d30420: mov     x19, x0                                    
02d30424: add     x0, sp, #8                                 
02d30428: bl      #0x2736fdc                                 fn_2736fdc
02d3042c: mov     x0, x19                                    
02d30430: bl      #0x2c6051c                                 fn_2c6051c
02d30434: bl      #0x27369b8                                 fn_27369b8
## PlayRandomAnimation() -> void
---- Games.RandomAnimation::PlayRandomAnimation 0x2d3004c
02d3004c: stp     x30, x21, [sp, #-0x20]!                    
02d30050: stp     x20, x19, [sp, #0x10]                      
02d30054: adrp    x20, #0x6630000                            
02d30058: mov     x19, x0                                    
02d3005c: ldrb    w8, [x20, #0xf0]                           
02d30060: tbnz    w8, #0, #0x2d30084                         
02d30064: adrp    x0, #0x626a000                             
02d30068: ldr     x0, [x0, #0x668]                           MS:System.Collections.Generic.List`1::get_Count
02d3006c: bl      #0x2b70db0                                 fn_2b70db0
02d30070: adrp    x0, #0x626a000                             
02d30074: ldr     x0, [x0, #0x670]                           MS:System.Collections.Generic.List`1::get_Item
02d30078: bl      #0x2b70db0                                 fn_2b70db0
02d3007c: mov     w8, #1                                     
02d30080: strb    w8, [x20, #0xf0]                           
02d30084: ldr     x8, [x19, #0x28]                           ._animationList
02d30088: cbz     x8, #0x2d3010c                             
02d3008c: ldr     w8, [x8, #0x18]                            
02d30090: cmp     w8, #1                                     
02d30094: b.lt    #0x2d30100                                 
02d30098: ldr     x0, [x19, #0x20]                           ._skeletonGraphic
02d3009c: cbz     x0, #0x2d3010c                             
02d300a0: mov     x1, xzr                                    
02d300a4: bl      #0x4ff9be0                                 Spine.Unity.SkeletonGraphic::get_AnimationState
02d300a8: ldr     x20, [x19, #0x28]                          ._animationList
02d300ac: cbz     x20, #0x2d3010c                            
02d300b0: adrp    x21, #0x626a000                            
02d300b4: mov     x19, x0                                    
02d300b8: mov     w0, wzr                                    
02d300bc: ldr     x21, [x21, #0x670]                         MS:System.Collections.Generic.List`1::get_Item
02d300c0: ldr     w1, [x20, #0x18]                           
02d300c4: mov     x2, xzr                                    
02d300c8: bl      #0x5b2e000                                 UnityEngine.Random::Range
02d300cc: ldr     x2, [x21]                                  T:type56879(k15)
02d300d0: mov     w1, w0                                     
02d300d4: mov     x0, x20                                    
02d300d8: bl      #0x35a8f3c                                 fn_35a8f3c
02d300dc: cbz     x19, #0x2d3010c                            
02d300e0: mov     x2, x0                                     
02d300e4: mov     x0, x19                                    
02d300e8: mov     w1, wzr                                    
02d300ec: ldp     x20, x19, [sp, #0x10]                      
02d300f0: mov     w3, #1                                     
02d300f4: mov     x4, xzr                                    
02d300f8: ldp     x30, x21, [sp], #0x20                      
02d300fc: b       #0x4f97234                                 Spine.AnimationState::SetAnimation
02d30100: ldp     x20, x19, [sp, #0x10]                      
02d30104: ldp     x30, x21, [sp], #0x20                      
02d30108: ret                                                
02d3010c: bl      #0x2b7105c                                 fn_2b7105c
## .ctor() -> void
---- Games.RandomAnimation::.ctor 0x2d30438
02d30438: mov     x1, xzr                                    
02d3043c: b       #0x5b397b0                                 UnityEngine.MonoBehaviour::.ctor
