#### CLASS Home.WorldButton parent= UnityEngine.MonoBehaviour
#   field _boxTrigger                    Home.BoxTrigger                                    off=0x20 attr=1 SerializeField
#   field onClick                        UnityEngine.Events.UnityEvent                      off=0x28 attr=6 
## OnEnable() -> void
---- Home.WorldButton::OnEnable 0x2d24524
02d24524: stp     x30, x23, [sp, #-0x30]!                    
02d24528: stp     x22, x21, [sp, #0x10]                      
02d2452c: stp     x20, x19, [sp, #0x20]                      
02d24530: adrp    x19, #0x6630000                            
02d24534: mov     x20, x0                                    
02d24538: ldrb    w8, [x19, #0x61]                           
02d2453c: tbnz    w8, #0, #0x2d24560                         
02d24540: adrp    x0, #0x6269000                             
02d24544: ldr     x0, [x0, #0xf00]                           T:type58822(k15)
02d24548: bl      #0x2b70db0                                 fn_2b70db0
02d2454c: adrp    x0, #0x6269000                             
02d24550: ldr     x0, [x0, #0xf18]                           M:Home.WorldButton::OnPressed
02d24554: bl      #0x2b70db0                                 fn_2b70db0
02d24558: mov     w8, #1                                     
02d2455c: strb    w8, [x19, #0x61]                           
02d24560: ldr     x19, [x20, #0x20]                          ._boxTrigger
02d24564: cbz     x19, #0x2d24604                            
02d24568: adrp    x23, #0x6269000                            
02d2456c: adrp    x22, #0x6269000                            
02d24570: ldr     x23, [x23, #0xf00]                         T:type58822(k15)
02d24574: ldr     x22, [x22, #0xf18]                         M:Home.WorldButton::OnPressed
02d24578: ldr     x21, [x19, #0x28]!                         .onClick
02d2457c: ldr     x0, [x23]                                  T:Trading.TradingSession/<>c__DisplayClass56_0
02d24580: bl      #0x2b7104c                                 fn_2b7104c
02d24584: ldr     x2, [x22]                                  T:Trading.TradingSession/<>c__DisplayClass56_0
02d24588: mov     x1, x20                                    
02d2458c: mov     x3, xzr                                    
02d24590: mov     x22, x0                                    
02d24594: bl      #0x3edf920                                 fn_3edf920
02d24598: mov     x0, x21                                    
02d2459c: mov     x1, x22                                    
02d245a0: mov     x2, xzr                                    
02d245a4: bl      #0x4e570ac                                 System.Delegate::Combine
02d245a8: cbz     x0, #0x2d245e8                             
02d245ac: ldr     x21, [x23]                                 T:Trading.TradingSession/<>c__DisplayClass56_0
02d245b0: mov     x20, x0                                    
02d245b4: mov     x1, x21                                    
02d245b8: bl      #0x2b70f34                                 fn_2b70f34
02d245bc: cbz     x0, #0x2d245dc                             
02d245c0: ldr     x21, [x23]                                 T:Trading.TradingSession/<>c__DisplayClass56_0
02d245c4: str     x0, [x19]                                  
02d245c8: mov     x0, x20                                    
02d245cc: mov     x1, x21                                    
02d245d0: bl      #0x2b70f34                                 fn_2b70f34
02d245d4: mov     x1, x0                                     
02d245d8: cbnz    x0, #0x2d245f0                             
02d245dc: mov     x0, x20                                    
02d245e0: mov     x1, x21                                    
02d245e4: bl      #0x2b713dc                                 fn_2b713dc
02d245e8: mov     x1, xzr                                    
02d245ec: str     xzr, [x19]                                 
02d245f0: mov     x0, x19                                    
02d245f4: ldp     x20, x19, [sp, #0x20]                      
02d245f8: ldp     x22, x21, [sp, #0x10]                      
02d245fc: ldp     x30, x23, [sp], #0x30                      
02d24600: b       #0x2b70d54                                 
02d24604: bl      #0x2b7105c                                 fn_2b7105c
## OnDisable() -> void
---- Home.WorldButton::OnDisable 0x2d24608
02d24608: stp     x30, x23, [sp, #-0x30]!                    
02d2460c: stp     x22, x21, [sp, #0x10]                      
02d24610: stp     x20, x19, [sp, #0x20]                      
02d24614: adrp    x19, #0x6630000                            
02d24618: mov     x20, x0                                    
02d2461c: ldrb    w8, [x19, #0x62]                           
02d24620: tbnz    w8, #0, #0x2d24644                         
02d24624: adrp    x0, #0x6269000                             
02d24628: ldr     x0, [x0, #0xf00]                           T:type58822(k15)
02d2462c: bl      #0x2b70db0                                 fn_2b70db0
02d24630: adrp    x0, #0x6269000                             
02d24634: ldr     x0, [x0, #0xf18]                           M:Home.WorldButton::OnPressed
02d24638: bl      #0x2b70db0                                 fn_2b70db0
02d2463c: mov     w8, #1                                     
02d24640: strb    w8, [x19, #0x62]                           
02d24644: ldr     x19, [x20, #0x20]                          ._boxTrigger
02d24648: cbz     x19, #0x2d246e8                            
02d2464c: adrp    x23, #0x6269000                            
02d24650: adrp    x22, #0x6269000                            
02d24654: ldr     x23, [x23, #0xf00]                         T:type58822(k15)
02d24658: ldr     x22, [x22, #0xf18]                         M:Home.WorldButton::OnPressed
02d2465c: ldr     x21, [x19, #0x28]!                         .onClick
02d24660: ldr     x0, [x23]                                  T:Trading.TradingSession/<>c__DisplayClass56_0
02d24664: bl      #0x2b7104c                                 fn_2b7104c
02d24668: ldr     x2, [x22]                                  T:Trading.TradingSession/<>c__DisplayClass56_0
02d2466c: mov     x1, x20                                    
02d24670: mov     x3, xzr                                    
02d24674: mov     x22, x0                                    
02d24678: bl      #0x3edf920                                 fn_3edf920
02d2467c: mov     x0, x21                                    
02d24680: mov     x1, x22                                    
02d24684: mov     x2, xzr                                    
02d24688: bl      #0x4e57298                                 System.Delegate::Remove
02d2468c: cbz     x0, #0x2d246cc                             
02d24690: ldr     x21, [x23]                                 T:Trading.TradingSession/<>c__DisplayClass56_0
02d24694: mov     x20, x0                                    
02d24698: mov     x1, x21                                    
02d2469c: bl      #0x2b70f34                                 fn_2b70f34
02d246a0: cbz     x0, #0x2d246c0                             
02d246a4: ldr     x21, [x23]                                 T:Trading.TradingSession/<>c__DisplayClass56_0
02d246a8: str     x0, [x19]                                  
02d246ac: mov     x0, x20                                    
02d246b0: mov     x1, x21                                    
02d246b4: bl      #0x2b70f34                                 fn_2b70f34
02d246b8: mov     x1, x0                                     
02d246bc: cbnz    x0, #0x2d246d4                             
02d246c0: mov     x0, x20                                    
02d246c4: mov     x1, x21                                    
02d246c8: bl      #0x2b713dc                                 fn_2b713dc
02d246cc: mov     x1, xzr                                    
02d246d0: str     xzr, [x19]                                 
02d246d4: mov     x0, x19                                    
02d246d8: ldp     x20, x19, [sp, #0x20]                      
02d246dc: ldp     x22, x21, [sp, #0x10]                      
02d246e0: ldp     x30, x23, [sp], #0x30                      
02d246e4: b       #0x2b70d54                                 
02d246e8: bl      #0x2b7105c                                 fn_2b7105c
## OnPressed(Home.EntityName arg0) -> void
---- Home.WorldButton::OnPressed 0x2d246ec
02d246ec: ldr     x0, [x0, #0x28]                            .onClick
02d246f0: cbz     x0, #0x2d246fc                             
02d246f4: mov     x1, xzr                                    
02d246f8: b       #0x5b4d278                                 UnityEngine.Events.UnityEvent::Invoke
02d246fc: ret                                                
## .ctor() -> void
---- Home.WorldButton::.ctor 0x2d24700
02d24700: mov     x1, xzr                                    
02d24704: b       #0x5b397b0                                 UnityEngine.MonoBehaviour::.ctor
