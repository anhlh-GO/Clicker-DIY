#### CLASS BlindBagCollection.BlindbagGameScreen/<>c parent= object
#   field <>9                            BlindBagCollection.BlindbagGameScreen/<>c          off=0x0 attr=36 
#   field <>9__10_0                      UnityEngine.Events.UnityAction                     off=0x8 attr=16 
#   field <>9__18_1                      System.Action                                      off=0x10 attr=16 
## .cctor() -> void
---- BlindBagCollection.BlindbagGameScreen/<>c::.cctor 0x2d385b0
02d385b0: str     x30, [sp, #-0x20]!                         
02d385b4: stp     x20, x19, [sp, #0x10]                      
02d385b8: adrp    x19, #0x6630000                            
02d385bc: adrp    x20, #0x626a000                            
02d385c0: ldrb    w8, [x19, #0x132]                          
02d385c4: ldr     x20, [x20, #0xbd0]                         T:BlindBagCollection.BlindbagGameScreen/<>c
02d385c8: tbnz    w8, #0, #0x2d385e0                         
02d385cc: adrp    x0, #0x626a000                             
02d385d0: ldr     x0, [x0, #0xbd0]                           T:BlindBagCollection.BlindbagGameScreen/<>c
02d385d4: bl      #0x2b70db0                                 fn_2b70db0
02d385d8: mov     w8, #1                                     
02d385dc: strb    w8, [x19, #0x132]                          
02d385e0: ldr     x0, [x20]                                  T:type56879(k15)
02d385e4: bl      #0x2b7104c                                 fn_2b7104c
02d385e8: mov     x1, xzr                                    
02d385ec: mov     x19, x0                                    
02d385f0: bl      #0x4e53e9c                                 System.Object::.ctor
02d385f4: ldr     x8, [x20]                                  T:type56879(k15)
02d385f8: mov     x1, x19                                    
02d385fc: ldr     x8, [x8, #0xb8]                            
02d38600: str     x19, [x8]                                  
02d38604: ldr     x8, [x20]                                  T:type56879(k15)
02d38608: ldp     x20, x19, [sp, #0x10]                      
02d3860c: ldr     x0, [x8, #0xb8]                            
02d38610: ldr     x30, [sp], #0x20                           
02d38614: b       #0x2b70d54                                 
## .ctor() -> void
---- BlindBagCollection.BlindbagGameScreen/<>c::.ctor 0x2d38618
02d38618: mov     x1, xzr                                    
02d3861c: b       #0x4e53e9c                                 System.Object::.ctor
## <OnInit>b__10_0() -> void
---- BlindBagCollection.BlindbagGameScreen/<>c::<OnInit>b__10_0 0x2d38620
02d38620: stp     x30, x19, [sp, #-0x10]!                    
02d38624: adrp    x19, #0x6630000                            
02d38628: ldrb    w8, [x19, #0x133]                          
02d3862c: tbnz    w8, #0, #0x2d38650                         
02d38630: adrp    x0, #0x6267000                             
02d38634: ldr     x0, [x0, #0xbd0]                           MS:MonoSingleton`1::get_Instance
02d38638: bl      #0x2b70db0                                 fn_2b70db0
02d3863c: adrp    x0, #0x626a000                             
02d38640: ldr     x0, [x0, #0xc08]                           MS:UIManager::ShowPopup
02d38644: bl      #0x2b70db0                                 fn_2b70db0
02d38648: mov     w8, #1                                     
02d3864c: strb    w8, [x19, #0x133]                          
02d38650: mov     x0, xzr                                    
02d38654: bl      #0x2d6eec8                                 Framework.AudioManager::get_Instance
02d38658: cbz     x0, #0x2d386a4                             
02d3865c: movi    d1, #0000000000000000                      
02d38660: movi    d2, #0000000000000000                      
02d38664: adrp    x19, #0x6267000                            
02d38668: fmov    s0, #1.00000000                            
02d3866c: ldr     x19, [x19, #0xbd0]                         MS:MonoSingleton`1::get_Instance
02d38670: mov     w1, #1                                     
02d38674: mov     w2, wzr                                    
02d38678: mov     w3, wzr                                    
02d3867c: mov     x4, xzr                                    
02d38680: bl      #0x2d6f03c                                 Framework.AudioManager::PlaySound
02d38684: ldr     x0, [x19]                                  S:'didu'
02d38688: bl      #0x3769600                                 fn_3769600
02d3868c: cbz     x0, #0x2d386a4                             
02d38690: adrp    x8, #0x626a000                             
02d38694: ldr     x8, [x8, #0xc08]                           MS:UIManager::ShowPopup
02d38698: ldr     x1, [x8]                                   T:type56879(k15)
02d3869c: ldp     x30, x19, [sp], #0x10                      
02d386a0: b       #0x33fbfac                                 
02d386a4: bl      #0x2b7105c                                 fn_2b7105c
## <HandleCharmFlyToPlate>b__18_1() -> void
---- BlindBagCollection.BlindbagGameScreen/<>c::<HandleCharmFlyToPlate>b__18_1 0x2d386a8
02d386a8: ret                                                
#### CLASS BlindBagCollection.BlindbagGameScreen/<>c__DisplayClass16_0 parent= object
#   field dataUser                       DataUser                                           off=0x10 attr=6 
## .ctor() -> void
---- BlindBagCollection.BlindbagGameScreen/<>c__DisplayClass16_0::.ctor 0x2d383c8
02d383c8: mov     x1, xzr                                    
02d383cc: b       #0x4e53e9c                                 System.Object::.ctor
## <UpdateUnlockedItemData>b__0(int x) -> void
---- BlindBagCollection.BlindbagGameScreen/<>c__DisplayClass16_0::<UpdateUnlockedItemData>b__0 0x2d386ac
02d386ac: str     x30, [sp, #-0x20]!                         
02d386b0: stp     x20, x19, [sp, #0x10]                      
02d386b4: mov     x20, x0                                    
02d386b8: ldr     x0, [x0, #0x10]                            .dataUser
02d386bc: cbz     x0, #0x2d386f8                             
02d386c0: mov     x2, xzr                                    
02d386c4: mov     w19, w1                                    
02d386c8: bl      #0x2cabfd4                                 DataUser::HasUnlockedClickerBase
02d386cc: tbz     w0, #0, #0x2d386dc                         
02d386d0: ldp     x20, x19, [sp, #0x10]                      
02d386d4: ldr     x30, [sp], #0x20                           
02d386d8: ret                                                
02d386dc: ldr     x0, [x20, #0x10]                           .dataUser
02d386e0: cbz     x0, #0x2d386f8                             
02d386e4: mov     w1, w19                                    
02d386e8: ldp     x20, x19, [sp, #0x10]                      
02d386ec: mov     x2, xzr                                    
02d386f0: ldr     x30, [sp], #0x20                           
02d386f4: b       #0x2cabedc                                 DataUser::UnlockClickerBase
02d386f8: bl      #0x2b7105c                                 fn_2b7105c
## <UpdateUnlockedItemData>b__1(int x) -> void
---- BlindBagCollection.BlindbagGameScreen/<>c__DisplayClass16_0::<UpdateUnlockedItemData>b__1 0x2d386fc
02d386fc: str     x30, [sp, #-0x20]!                         
02d38700: stp     x20, x19, [sp, #0x10]                      
02d38704: mov     x20, x0                                    
02d38708: ldr     x0, [x0, #0x10]                            .dataUser
02d3870c: cbz     x0, #0x2d38748                             
02d38710: mov     x2, xzr                                    
02d38714: mov     w19, w1                                    
02d38718: bl      #0x2cabd24                                 DataUser::HasUnlockedKeycapDecor
02d3871c: tbz     w0, #0, #0x2d3872c                         
02d38720: ldp     x20, x19, [sp, #0x10]                      
02d38724: ldr     x30, [sp], #0x20                           
02d38728: ret                                                
02d3872c: ldr     x0, [x20, #0x10]                           .dataUser
02d38730: cbz     x0, #0x2d38748                             
02d38734: mov     w1, w19                                    
02d38738: ldp     x20, x19, [sp, #0x10]                      
02d3873c: mov     x2, xzr                                    
02d38740: ldr     x30, [sp], #0x20                           
02d38744: b       #0x2cabc2c                                 DataUser::UnlockClickerDecor
02d38748: bl      #0x2b7105c                                 fn_2b7105c
#### CLASS BlindBagCollection.BlindbagGameScreen parent= ScreenBase
#   field _goBlockScreen                 UnityEngine.GameObject                             off=0x38 attr=1 SerializeField
#   field _closeButton                   UnityEngine.UI.Button                              off=0x40 attr=1 SerializeField
#   field _blindbagCollectionController  BlindBagCollection.BlindbagCollectionController    off=0x48 attr=1 SerializeField
#   field _livestreamPanel               Livestream.LivestreamPanel                         off=0x50 attr=1 SerializeField
#   field _contentUnbox                  UnityEngine.GameObject                             off=0x58 attr=1 HeaderAttribute,SerializeField
#   field _charmFlyToBasket              BlindBagCollection.CharmFlyToBasketBB              off=0x60 attr=1 SerializeField
#   field _contentChat                   UnityEngine.GameObject                             off=0x68 attr=1 HeaderAttribute,SerializeField
#   field _commentHandler                CommentHandler                                     off=0x70 attr=1 SerializeField
#   field _chatInput                     Livestream.ChatInput                               off=0x78 attr=1 SerializeField
#   field _fxEmoji                       UnityEngine.ParticleSystem                         off=0x80 attr=1 SerializeField
#   field _doneFlag                      bool                                               off=0x88 attr=1 
## OnInit(UIManager uiManager) -> void
---- BlindBagCollection.BlindbagGameScreen::OnInit 0x2d37e34
02d37e34: str     x30, [sp, #-0x30]!                         
02d37e38: stp     x22, x21, [sp, #0x10]                      
02d37e3c: stp     x20, x19, [sp, #0x20]                      
02d37e40: adrp    x21, #0x6630000                            
02d37e44: mov     x20, x1                                    
02d37e48: mov     x19, x0                                    
02d37e4c: ldrb    w8, [x21, #0x12b]                          
02d37e50: tbnz    w8, #0, #0x2d37e80                         
02d37e54: adrp    x0, #0x626a000                             
02d37e58: ldr     x0, [x0, #0xbc8]                           M:BlindBagCollection.BlindbagGameScreen/<>c::<OnInit>b__10_0
02d37e5c: bl      #0x2b70db0                                 fn_2b70db0
02d37e60: adrp    x0, #0x626a000                             
02d37e64: ldr     x0, [x0, #0xbd0]                           T:BlindBagCollection.BlindbagGameScreen/<>c
02d37e68: bl      #0x2b70db0                                 fn_2b70db0
02d37e6c: adrp    x0, #0x6265000                             
02d37e70: ldr     x0, [x0, #0x3f0]                           T:UnityEngine.Events.UnityAction
02d37e74: bl      #0x2b70db0                                 fn_2b70db0
02d37e78: mov     w8, #1                                     
02d37e7c: strb    w8, [x21, #0x12b]                          
02d37e80: mov     x0, x19                                    
02d37e84: mov     x1, x20                                    
02d37e88: mov     x2, xzr                                    
02d37e8c: bl      #0x2cdd3c4                                 UIBase::OnInit
02d37e90: ldr     x0, [x19, #0x78]                           ._chatInput
02d37e94: cbz     x0, #0x2d37f60                             
02d37e98: mov     x1, xzr                                    
02d37e9c: bl      #0x2d11580                                 Livestream.ChatInput::OnInit
02d37ea0: ldr     x0, [x19, #0x38]                           ._goBlockScreen
02d37ea4: cbz     x0, #0x2d37f60                             
02d37ea8: mov     w1, wzr                                    
02d37eac: mov     x2, xzr                                    
02d37eb0: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d37eb4: ldr     x8, [x19, #0x40]                           ._closeButton
02d37eb8: cbz     x8, #0x2d37f60                             
02d37ebc: adrp    x22, #0x626a000                            
02d37ec0: ldr     x22, [x22, #0xbd0]                         T:BlindBagCollection.BlindbagGameScreen/<>c
02d37ec4: ldr     x19, [x8, #0x100]                          
02d37ec8: ldr     x0, [x22]                                  T:type56879(k15)
02d37ecc: ldr     w9, [x0, #0xe4]                            [62650e4]=0 f=0,0
02d37ed0: cbnz    w9, #0x2d37edc                             
02d37ed4: bl      #0x2b70f30                                 fn_2b70f30
02d37ed8: ldr     x0, [x22]                                  T:type56879(k15)
02d37edc: ldr     x8, [x0, #0xb8]                            T:AdsManager/<>c__DisplayClass42_0
02d37ee0: ldr     x20, [x8, #8]                              
02d37ee4: cbnz    x20, #0x2d37f40                            
02d37ee8: ldr     w9, [x0, #0xe4]                            [62650e4]=0 f=0,0
02d37eec: cbnz    w9, #0x2d37efc                             
02d37ef0: bl      #0x2b70f30                                 fn_2b70f30
02d37ef4: ldr     x8, [x22]                                  T:type56879(k15)
02d37ef8: ldr     x8, [x8, #0xb8]                            
02d37efc: adrp    x9, #0x6265000                             
02d37f00: ldr     x9, [x9, #0x3f0]                           T:UnityEngine.Events.UnityAction
02d37f04: ldr     x21, [x8]                                  
02d37f08: ldr     x0, [x9]                                   M:AdsManager::<OnApplicationPause>b__26_0
02d37f0c: bl      #0x2b7104c                                 fn_2b7104c
02d37f10: adrp    x8, #0x626a000                             
02d37f14: mov     x1, x21                                    
02d37f18: mov     x3, xzr                                    
02d37f1c: ldr     x8, [x8, #0xbc8]                           M:BlindBagCollection.BlindbagGameScreen/<>c::<OnInit>b__10_0
02d37f20: mov     x20, x0                                    
02d37f24: ldr     x2, [x8]                                   T:type56879(k15)
02d37f28: bl      #0x5b4cf98                                 UnityEngine.Events.UnityAction::.ctor
02d37f2c: ldr     x8, [x22]                                  T:type56879(k15)
02d37f30: mov     x1, x20                                    
02d37f34: ldr     x0, [x8, #0xb8]                            MS:UnityEngine.Object::FindObjectsOfType
02d37f38: str     x20, [x0, #8]!                             
02d37f3c: bl      #0x2b70d54                                 fn_2b70d54
02d37f40: cbz     x19, #0x2d37f60                            
02d37f44: mov     x0, x19                                    
02d37f48: mov     x1, x20                                    
02d37f4c: mov     x2, xzr                                    
02d37f50: ldp     x20, x19, [sp, #0x20]                      
02d37f54: ldp     x22, x21, [sp, #0x10]                      
02d37f58: ldr     x30, [sp], #0x30                           
02d37f5c: b       #0x5b4d0ac                                 UnityEngine.Events.UnityEvent::AddListener
02d37f60: bl      #0x2b7105c                                 fn_2b7105c
## OnShow() -> void
---- BlindBagCollection.BlindbagGameScreen::OnShow 0x2d37f64
02d37f64: stp     x30, x21, [sp, #-0x20]!                    
02d37f68: stp     x20, x19, [sp, #0x10]                      
02d37f6c: adrp    x21, #0x6630000                            
02d37f70: adrp    x20, #0x6265000                            
02d37f74: mov     x19, x0                                    
02d37f78: ldrb    w8, [x21, #0x12c]                          
02d37f7c: ldr     x20, [x20, #0x10]                          MS:MonoSingleton`1::get_Instance
02d37f80: tbnz    w8, #0, #0x2d37fc8                         
02d37f84: adrp    x0, #0x6266000                             
02d37f88: ldr     x0, [x0, #0x750]                           MS:DataManager::GetData
02d37f8c: bl      #0x2b70db0                                 fn_2b70db0
02d37f90: adrp    x0, #0x6265000                             
02d37f94: ldr     x0, [x0, #0x10]                            MS:MonoSingleton`1::get_Instance
02d37f98: bl      #0x2b70db0                                 fn_2b70db0
02d37f9c: adrp    x0, #0x6266000                             
02d37fa0: ldr     x0, [x0, #0x658]                           MS:MonoSingleton`1::get_Instance
02d37fa4: bl      #0x2b70db0                                 fn_2b70db0
02d37fa8: adrp    x0, #0x6263000                             
02d37fac: ldr     x0, [x0, #0x918]                           T:UnityEngine.Object
02d37fb0: bl      #0x2b70db0                                 fn_2b70db0
02d37fb4: adrp    x0, #0x6265000                             
02d37fb8: ldr     x0, [x0, #0x310]                           MS:WejoyService.Singleton`1::get_Instance
02d37fbc: bl      #0x2b70db0                                 fn_2b70db0
02d37fc0: mov     w8, #1                                     
02d37fc4: strb    w8, [x21, #0x12c]                          
02d37fc8: mov     x0, x19                                    
02d37fcc: mov     x1, xzr                                    
02d37fd0: bl      #0x2cdd6b8                                 UIBase::OnShow
02d37fd4: ldr     x0, [x20]                                  M:AdsManager::<OnApplicationPause>b__26_0
02d37fd8: bl      #0x3769600                                 fn_3769600
02d37fdc: cbz     x0, #0x2d380e4                             
02d37fe0: mov     x1, xzr                                    
02d37fe4: bl      #0x2cdff7c                                 SimpleSceneTransition::FadeOut
02d37fe8: ldr     x0, [x19, #0x78]                           ._chatInput
02d37fec: cbz     x0, #0x2d380e4                             
02d37ff0: mov     x1, xzr                                    
02d37ff4: bl      #0x5b339ec                                 UnityEngine.Component::get_gameObject
02d37ff8: cbz     x0, #0x2d380e4                             
02d37ffc: mov     w1, #1                                     
02d38000: mov     x2, xzr                                    
02d38004: mov     w20, #1                                    
02d38008: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d3800c: ldr     x8, [x19, #0x70]                           ._commentHandler
02d38010: cbz     x8, #0x2d380e4                             
02d38014: ldr     x0, [x19, #0x80]                           ._fxEmoji
02d38018: strb    w20, [x8, #0x20]                           
02d3801c: cbz     x0, #0x2d380e4                             
02d38020: adrp    x20, #0x6263000                            
02d38024: mov     x1, xzr                                    
02d38028: ldr     x20, [x20, #0x918]                         T:UnityEngine.Object
02d3802c: bl      #0x5bba8cc                                 UnityEngine.ParticleSystem::Play
02d38030: ldr     x0, [x20]                                  &2c5bbd4(=a9bd7bfdd503233f)
02d38034: ldr     x20, [x19, #0x50]                          ._livestreamPanel
02d38038: ldr     w8, [x0, #0xe4]                            [62650e4]=0 f=0,0
02d3803c: cbnz    w8, #0x2d38044                             
02d38040: bl      #0x2b70f30                                 fn_2b70f30
02d38044: mov     x0, x20                                    
02d38048: mov     x1, xzr                                    
02d3804c: mov     x2, xzr                                    
02d38050: bl      #0x5b3666c                                 UnityEngine.Object::op_Inequality
02d38054: tbz     w0, #0, #0x2d38068                         
02d38058: ldr     x0, [x19, #0x50]                           ._livestreamPanel
02d3805c: cbz     x0, #0x2d380e4                             
02d38060: mov     x1, xzr                                    
02d38064: bl      #0x2d11ba0                                 Livestream.LivestreamPanel::OnShow
02d38068: adrp    x8, #0x6266000                             
02d3806c: ldr     x8, [x8, #0x658]                           MS:MonoSingleton`1::get_Instance
02d38070: ldr     x0, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d38074: bl      #0x3769600                                 fn_3769600
02d38078: cbz     x0, #0x2d380e4                             
02d3807c: adrp    x8, #0x6266000                             
02d38080: ldr     x8, [x8, #0x750]                           MS:DataManager::GetData
02d38084: ldr     x1, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d38088: bl      #0x3168dd0                                 fn_3168dd0
02d3808c: cbz     x0, #0x2d380e4                             
02d38090: ldr     x8, [x0, #0x20]                            S:'dev log AdsManager show app open ad'
02d38094: cbz     x8, #0x2d380e4                             
02d38098: ldrb    w8, [x8, #0x45]                            
02d3809c: cbnz    w8, #0x2d380c0                             
02d380a0: ldr     x0, [x19, #0x40]                           ._closeButton
02d380a4: cbz     x0, #0x2d380e4                             
02d380a8: mov     x1, xzr                                    
02d380ac: bl      #0x5b339ec                                 UnityEngine.Component::get_gameObject
02d380b0: cbz     x0, #0x2d380e4                             
02d380b4: mov     w1, wzr                                    
02d380b8: mov     x2, xzr                                    
02d380bc: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d380c0: adrp    x8, #0x6265000                             
02d380c4: ldr     x8, [x8, #0x310]                           MS:WejoyService.Singleton`1::get_Instance
02d380c8: ldr     x0, [x8]                                   M:AdsManager::<OnApplicationPause>b__26_0
02d380cc: bl      #0x3be7218                                 fn_3be7218
02d380d0: cbz     x0, #0x2d380e4                             
02d380d4: ldp     x20, x19, [sp, #0x10]                      
02d380d8: mov     x1, xzr                                    
02d380dc: ldp     x30, x21, [sp], #0x20                      
02d380e0: b       #0x2c8a7a4                                 AdsManager::ShowCollap
02d380e4: bl      #0x2b7105c                                 fn_2b7105c
## OnHide() -> void
---- BlindBagCollection.BlindbagGameScreen::OnHide 0x2d380e8
02d380e8: str     x30, [sp, #-0x20]!                         
02d380ec: stp     x20, x19, [sp, #0x10]                      
02d380f0: adrp    x20, #0x6630000                            
02d380f4: mov     x19, x0                                    
02d380f8: ldrb    w8, [x20, #0x12d]                          
02d380fc: tbnz    w8, #0, #0x2d38114                         
02d38100: adrp    x0, #0x6263000                             
02d38104: ldr     x0, [x0, #0x918]                           T:UnityEngine.Object
02d38108: bl      #0x2b70db0                                 fn_2b70db0
02d3810c: mov     w8, #1                                     
02d38110: strb    w8, [x20, #0x12d]                          
02d38114: mov     x0, x19                                    
02d38118: mov     x1, xzr                                    
02d3811c: bl      #0x2cddc10                                 UIBase::OnHide
02d38120: ldr     x8, [x19, #0x70]                           ._commentHandler
02d38124: cbz     x8, #0x2d38180                             
02d38128: adrp    x9, #0x6263000                             
02d3812c: ldr     x9, [x9, #0x918]                           T:UnityEngine.Object
02d38130: ldr     x20, [x19, #0x50]                          ._livestreamPanel
02d38134: strb    wzr, [x8, #0x20]                           
02d38138: ldr     x0, [x9]                                   &2c5bbd4(=a9bd7bfdd503233f)
02d3813c: ldr     w9, [x0, #0xe4]                            [62630e4]=0 f=0,0
02d38140: cbnz    w9, #0x2d38148                             
02d38144: bl      #0x2b70f30                                 fn_2b70f30
02d38148: mov     x0, x20                                    
02d3814c: mov     x1, xzr                                    
02d38150: mov     x2, xzr                                    
02d38154: bl      #0x5b3666c                                 UnityEngine.Object::op_Inequality
02d38158: tbz     w0, #0, #0x2d38174                         
02d3815c: ldr     x0, [x19, #0x50]                           ._livestreamPanel
02d38160: cbz     x0, #0x2d38180                             
02d38164: ldp     x20, x19, [sp, #0x10]                      
02d38168: mov     x1, xzr                                    
02d3816c: ldr     x30, [sp], #0x20                           
02d38170: b       #0x2d11cdc                                 Livestream.LivestreamPanel::OnHide
02d38174: ldp     x20, x19, [sp, #0x10]                      
02d38178: ldr     x30, [sp], #0x20                           
02d3817c: ret                                                
02d38180: bl      #0x2b7105c                                 fn_2b7105c
## ShowBlockScreen(bool isShow) -> void
---- BlindBagCollection.BlindbagGameScreen::ShowBlockScreen 0x2d355a0
02d355a0: ldr     x0, [x0, #0x38]                            ._goBlockScreen
02d355a4: cbz     x0, #0x2d355b4                             
02d355a8: and     w1, w1, #1                                 
02d355ac: mov     x2, xzr                                    
02d355b0: b       #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d355b4: str     x30, [sp, #-0x10]!                         
02d355b8: bl      #0x2b7105c                                 fn_2b7105c
## ShowContentUnbox() -> void
---- BlindBagCollection.BlindbagGameScreen::ShowContentUnbox 0x2d32ef0
02d32ef0: ldr     x0, [x0, #0x58]                            ._contentUnbox
02d32ef4: cbz     x0, #0x2d32f04                             
02d32ef8: mov     w1, #1                                     
02d32efc: mov     x2, xzr                                    
02d32f00: b       #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d32f04: str     x30, [sp, #-0x10]!                         
02d32f08: bl      #0x2b7105c                                 fn_2b7105c
## ShowContentSelectBox() -> void
---- BlindBagCollection.BlindbagGameScreen::ShowContentSelectBox 0x2d38184
02d38184: str     x30, [sp, #-0x20]!                         
02d38188: stp     x20, x19, [sp, #0x10]                      
02d3818c: adrp    x20, #0x6630000                            
02d38190: mov     x19, x0                                    
02d38194: ldrb    w8, [x20, #0x12e]                          
02d38198: tbnz    w8, #0, #0x2d381b0                         
02d3819c: adrp    x0, #0x6263000                             
02d381a0: ldr     x0, [x0, #0x918]                           T:UnityEngine.Object
02d381a4: bl      #0x2b70db0                                 fn_2b70db0
02d381a8: mov     w8, #1                                     
02d381ac: strb    w8, [x20, #0x12e]                          
02d381b0: ldr     x0, [x19, #0x38]                           ._goBlockScreen
02d381b4: cbz     x0, #0x2d38248                             
02d381b8: mov     w1, wzr                                    
02d381bc: mov     x2, xzr                                    
02d381c0: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d381c4: mov     x0, x19                                    
02d381c8: mov     w1, wzr                                    
02d381cc: bl      #0x2d355bc                                 BlindBagCollection.BlindbagGameScreen::ShowChatContent
02d381d0: ldr     x0, [x19, #0x58]                           ._contentUnbox
02d381d4: cbz     x0, #0x2d38248                             
02d381d8: adrp    x20, #0x6263000                            
02d381dc: mov     w1, wzr                                    
02d381e0: mov     x2, xzr                                    
02d381e4: ldr     x20, [x20, #0x918]                         T:UnityEngine.Object
02d381e8: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d381ec: ldr     x0, [x20]                                  &2c5bbd4(=a9bd7bfdd503233f)
02d381f0: ldr     x20, [x19, #0x50]                          ._livestreamPanel
02d381f4: ldr     w8, [x0, #0xe4]                            [62630e4]=0 f=0,0
02d381f8: cbnz    w8, #0x2d38200                             
02d381fc: bl      #0x2b70f30                                 fn_2b70f30
02d38200: mov     x0, x20                                    
02d38204: mov     x1, xzr                                    
02d38208: mov     x2, xzr                                    
02d3820c: bl      #0x5b3666c                                 UnityEngine.Object::op_Inequality
02d38210: tbz     w0, #0, #0x2d3823c                         
02d38214: ldr     x0, [x19, #0x50]                           ._livestreamPanel
02d38218: cbz     x0, #0x2d38248                             
02d3821c: mov     x1, xzr                                    
02d38220: bl      #0x5b339ec                                 UnityEngine.Component::get_gameObject
02d38224: cbz     x0, #0x2d38248                             
02d38228: ldp     x20, x19, [sp, #0x10]                      
02d3822c: mov     w1, wzr                                    
02d38230: mov     x2, xzr                                    
02d38234: ldr     x30, [sp], #0x20                           
02d38238: b       #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d3823c: ldp     x20, x19, [sp, #0x10]                      
02d38240: ldr     x30, [sp], #0x20                           
02d38244: ret                                                
02d38248: bl      #0x2b7105c                                 fn_2b7105c
## UpdateUnlockedItemData() -> void
---- BlindBagCollection.BlindbagGameScreen::UpdateUnlockedItemData 0x2d3824c
02d3824c: str     x30, [sp, #-0x40]!                         
02d38250: stp     x24, x23, [sp, #0x10]                      
02d38254: stp     x22, x21, [sp, #0x20]                      
02d38258: stp     x20, x19, [sp, #0x30]                      
02d3825c: adrp    x20, #0x6630000                            
02d38260: adrp    x22, #0x626a000                            
02d38264: adrp    x21, #0x6266000                            
02d38268: ldrb    w8, [x20, #0x12f]                          
02d3826c: ldr     x22, [x22, #0xbd8]                         T:BlindBagCollection.BlindbagGameScreen/<>c__DisplayClass16_0
02d38270: ldr     x21, [x21, #0x658]                         MS:MonoSingleton`1::get_Instance
02d38274: mov     x19, x0                                    
02d38278: tbnz    w8, #0, #0x2d382d8                         
02d3827c: adrp    x0, #0x6269000                             
02d38280: ldr     x0, [x0, #0x5e8]                           T:type6940(k15)
02d38284: bl      #0x2b70db0                                 fn_2b70db0
02d38288: adrp    x0, #0x6266000                             
02d3828c: ldr     x0, [x0, #0x750]                           MS:DataManager::GetData
02d38290: bl      #0x2b70db0                                 fn_2b70db0
02d38294: adrp    x0, #0x6269000                             
02d38298: ldr     x0, [x0, #0x5f0]                           MS:System.Collections.Generic.List`1::ForEach
02d3829c: bl      #0x2b70db0                                 fn_2b70db0
02d382a0: adrp    x0, #0x6266000                             
02d382a4: ldr     x0, [x0, #0x658]                           MS:MonoSingleton`1::get_Instance
02d382a8: bl      #0x2b70db0                                 fn_2b70db0
02d382ac: adrp    x0, #0x626a000                             
02d382b0: ldr     x0, [x0, #0xbe0]                           M:BlindBagCollection.BlindbagGameScreen/<>c__DisplayClass16_0::<UpdateUnlockedItemData>b__0
02d382b4: bl      #0x2b70db0                                 fn_2b70db0
02d382b8: adrp    x0, #0x626a000                             
02d382bc: ldr     x0, [x0, #0xbe8]                           M:BlindBagCollection.BlindbagGameScreen/<>c__DisplayClass16_0::<UpdateUnlockedItemData>b__1
02d382c0: bl      #0x2b70db0                                 fn_2b70db0
02d382c4: adrp    x0, #0x626a000                             
02d382c8: ldr     x0, [x0, #0xbd8]                           T:BlindBagCollection.BlindbagGameScreen/<>c__DisplayClass16_0
02d382cc: bl      #0x2b70db0                                 fn_2b70db0
02d382d0: mov     w8, #1                                     
02d382d4: strb    w8, [x20, #0x12f]                          
02d382d8: ldr     x0, [x22]                                  T:type56879(k15)
02d382dc: bl      #0x2b7104c                                 fn_2b7104c
02d382e0: mov     x1, xzr                                    
02d382e4: mov     x20, x0                                    
02d382e8: bl      #0x4e53e9c                                 System.Object::.ctor
02d382ec: ldr     x0, [x21]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d382f0: bl      #0x3769600                                 fn_3769600
02d382f4: cbz     x0, #0x2d383c4                             
02d382f8: adrp    x8, #0x6266000                             
02d382fc: ldr     x8, [x8, #0x750]                           MS:DataManager::GetData
02d38300: ldr     x1, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d38304: bl      #0x3168dd0                                 fn_3168dd0
02d38308: cbz     x20, #0x2d383c4                            
02d3830c: mov     x1, x0                                     
02d38310: mov     x0, x20                                    
02d38314: str     x1, [x0, #0x10]!                           
02d38318: bl      #0x2b70d54                                 fn_2b70d54
02d3831c: ldr     x8, [x19, #0x48]                           ._blindbagCollectionController
02d38320: cbz     x8, #0x2d383c4                             
02d38324: adrp    x23, #0x6269000                            
02d38328: adrp    x22, #0x626a000                            
02d3832c: ldr     x23, [x23, #0x5e8]                         T:type6940(k15)
02d38330: ldr     x22, [x22, #0xbe0]                         M:BlindBagCollection.BlindbagGameScreen/<>c__DisplayClass16_0::<UpdateUnlockedItemData>b__0
02d38334: ldr     x21, [x8, #0xa8]                           S:'data_config_type'
02d38338: ldr     x0, [x23]                                  T:Trading.TradingSession/<>c__DisplayClass56_0
02d3833c: bl      #0x2b7104c                                 fn_2b7104c
02d38340: ldr     x2, [x22]                                  T:type56879(k15)
02d38344: mov     x1, x20                                    
02d38348: mov     x3, xzr                                    
02d3834c: mov     x22, x0                                    
02d38350: bl      #0x4532eb0                                 fn_4532eb0
02d38354: cbz     x21, #0x2d383c4                            
02d38358: adrp    x24, #0x6269000                            
02d3835c: mov     x0, x21                                    
02d38360: mov     x1, x22                                    
02d38364: ldr     x24, [x24, #0x5f0]                         MS:System.Collections.Generic.List`1::ForEach
02d38368: ldr     x2, [x24]                                  T:Trading.TradingSession/<>c__DisplayClass56_0
02d3836c: bl      #0x356a6c8                                 fn_356a6c8
02d38370: ldr     x8, [x19, #0x48]                           ._blindbagCollectionController
02d38374: cbz     x8, #0x2d383c4                             
02d38378: adrp    x21, #0x626a000                            
02d3837c: ldr     x21, [x21, #0xbe8]                         M:BlindBagCollection.BlindbagGameScreen/<>c__DisplayClass16_0::<UpdateUnlockedItemData>b__1
02d38380: ldr     x0, [x23]                                  T:Trading.TradingSession/<>c__DisplayClass56_0
02d38384: ldr     x19, [x8, #0xb0]                           S:'native_banner_ad_on_off'
02d38388: bl      #0x2b7104c                                 fn_2b7104c
02d3838c: ldr     x2, [x21]                                  T:type56879(k15)
02d38390: mov     x1, x20                                    
02d38394: mov     x3, xzr                                    
02d38398: mov     x21, x0                                    
02d3839c: bl      #0x4532eb0                                 fn_4532eb0
02d383a0: cbz     x19, #0x2d383c4                            
02d383a4: ldr     x2, [x24]                                  T:Trading.TradingSession/<>c__DisplayClass56_0
02d383a8: mov     x0, x19                                    
02d383ac: mov     x1, x21                                    
02d383b0: ldp     x20, x19, [sp, #0x30]                      
02d383b4: ldp     x22, x21, [sp, #0x20]                      
02d383b8: ldp     x24, x23, [sp, #0x10]                      
02d383bc: ldr     x30, [sp], #0x40                           
02d383c0: b       #0x356a6c8                                 
02d383c4: bl      #0x2b7105c                                 fn_2b7105c
## HandleCharmFlyToPlate(bool isLuck) -> void
---- BlindBagCollection.BlindbagGameScreen::HandleCharmFlyToPlate 0x2d32148
02d32148: stp     x30, x21, [sp, #-0x20]!                    
02d3214c: stp     x20, x19, [sp, #0x10]                      
02d32150: adrp    x20, #0x6630000                            
02d32154: mov     x19, x0                                    
02d32158: ldrb    w8, [x20, #0x130]                          
02d3215c: tbnz    w8, #0, #0x2d32180                         
02d32160: adrp    x0, #0x626a000                             
02d32164: ldr     x0, [x0, #0x7c0]                           M:BlindBagCollection.BlindbagGameScreen::<HandleCharmFlyToPlate>b__18_0
02d32168: bl      #0x2b70db0                                 fn_2b70db0
02d3216c: adrp    x0, #0x6264000                             
02d32170: ldr     x0, [x0, #0xe8]                            T:DG.Tweening.TweenCallback
02d32174: bl      #0x2b70db0                                 fn_2b70db0
02d32178: mov     w8, #1                                     
02d3217c: strb    w8, [x20, #0x130]                          
02d32180: ldr     x0, [x19, #0x38]                           ._goBlockScreen
02d32184: cbz     x0, #0x2d321dc                             
02d32188: adrp    x20, #0x6264000                            
02d3218c: adrp    x21, #0x626a000                            
02d32190: mov     w1, wzr                                    
02d32194: ldr     x20, [x20, #0xe8]                          T:DG.Tweening.TweenCallback
02d32198: ldr     x21, [x21, #0x7c0]                         M:BlindBagCollection.BlindbagGameScreen::<HandleCharmFlyToPlate>b__18_0
02d3219c: mov     x2, xzr                                    
02d321a0: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d321a4: ldr     x0, [x20]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d321a8: bl      #0x2b7104c                                 fn_2b7104c
02d321ac: ldr     x2, [x21]                                  T:type56879(k15)
02d321b0: mov     x1, x19                                    
02d321b4: mov     x3, xzr                                    
02d321b8: mov     x20, x0                                    
02d321bc: bl      #0x2d89dc4                                 DG.Tweening.TweenCallback::.ctor
02d321c0: mov     x0, x20                                    
02d321c4: ldp     x20, x19, [sp, #0x10]                      
02d321c8: fmov    s0, #2.00000000                            
02d321cc: mov     w1, #1                                     
02d321d0: mov     x2, xzr                                    
02d321d4: ldp     x30, x21, [sp], #0x20                      
02d321d8: b       #0x2d8f37c                                 DG.Tweening.DOVirtual::DelayedCall
02d321dc: bl      #0x2b7105c                                 fn_2b7105c
## RemoteCallAddMoreBag() -> void
---- BlindBagCollection.BlindbagGameScreen::RemoteCallAddMoreBag 0x2d31f68
02d31f68: ldr     x0, [x0, #0x48]                            ._blindbagCollectionController
02d31f6c: cbz     x0, #0x2d31f74                             
02d31f70: b       #0x2d33488                                 BlindBagCollection.BlindbagCollectionController::AddMoreBlindBox
02d31f74: str     x30, [sp, #-0x10]!                         
02d31f78: bl      #0x2b7105c                                 fn_2b7105c
## ShowChatContent(bool isShow) -> void
---- BlindBagCollection.BlindbagGameScreen::ShowChatContent 0x2d355bc
02d355bc: str     x30, [sp, #-0x20]!                         
02d355c0: stp     x20, x19, [sp, #0x10]                      
02d355c4: mov     x19, x0                                    
02d355c8: ldr     x0, [x0, #0x68]                            ._contentChat
02d355cc: cbz     x0, #0x2d3563c                             
02d355d0: mov     w20, w1                                    
02d355d4: mov     x1, xzr                                    
02d355d8: bl      #0x5b37654                                 UnityEngine.GameObject::get_gameObject
02d355dc: cbz     x0, #0x2d3563c                             
02d355e0: and     w1, w20, #1                                
02d355e4: mov     x2, xzr                                    
02d355e8: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d355ec: ldr     x0, [x19, #0x80]                           ._fxEmoji
02d355f0: cbz     x0, #0x2d3563c                             
02d355f4: mov     x1, xzr                                    
02d355f8: bl      #0x5b339ec                                 UnityEngine.Component::get_gameObject
02d355fc: cbz     x0, #0x2d3563c                             
02d35600: and     w1, w20, #1                                
02d35604: mov     x2, xzr                                    
02d35608: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d3560c: ldr     x0, [x19, #0x80]                           ._fxEmoji
02d35610: tbz     w20, #0, #0x2d35628                        
02d35614: cbz     x0, #0x2d3563c                             
02d35618: ldp     x20, x19, [sp, #0x10]                      
02d3561c: mov     x1, xzr                                    
02d35620: ldr     x30, [sp], #0x20                           
02d35624: b       #0x5bba8cc                                 UnityEngine.ParticleSystem::Play
02d35628: cbz     x0, #0x2d3563c                             
02d3562c: ldp     x20, x19, [sp, #0x10]                      
02d35630: mov     x1, xzr                                    
02d35634: ldr     x30, [sp], #0x20                           
02d35638: b       #0x5bba9c0                                 UnityEngine.ParticleSystem::Stop
02d3563c: bl      #0x2b7105c                                 fn_2b7105c
## .ctor() -> void
---- BlindBagCollection.BlindbagGameScreen::.ctor 0x2d383d0
02d383d0: mov     x1, xzr                                    
02d383d4: b       #0x2cde678                                 ScreenBase::.ctor
## <HandleCharmFlyToPlate>b__18_0() -> void
---- BlindBagCollection.BlindbagGameScreen::<HandleCharmFlyToPlate>b__18_0 0x2d383d8
02d383d8: str     x30, [sp, #-0x40]!                         
02d383dc: stp     x24, x23, [sp, #0x10]                      
02d383e0: stp     x22, x21, [sp, #0x20]                      
02d383e4: stp     x20, x19, [sp, #0x30]                      
02d383e8: adrp    x21, #0x6630000                            
02d383ec: adrp    x20, #0x6263000                            
02d383f0: mov     x19, x0                                    
02d383f4: ldrb    w8, [x21, #0x131]                          
02d383f8: ldr     x20, [x20, #0x928]                         T:UnityEngine.Debug
02d383fc: tbnz    w8, #0, #0x2d3845c                         
02d38400: adrp    x0, #0x6264000                             
02d38404: ldr     x0, [x0, #0xf90]                           T:System.Action
02d38408: bl      #0x2b70db0                                 fn_2b70db0
02d3840c: adrp    x0, #0x6263000                             
02d38410: ldr     x0, [x0, #0x928]                           T:UnityEngine.Debug
02d38414: bl      #0x2b70db0                                 fn_2b70db0
02d38418: adrp    x0, #0x6265000                             
02d3841c: ldr     x0, [x0, #0x310]                           MS:WejoyService.Singleton`1::get_Instance
02d38420: bl      #0x2b70db0                                 fn_2b70db0
02d38424: adrp    x0, #0x626a000                             
02d38428: ldr     x0, [x0, #0xbf0]                           M:BlindBagCollection.BlindbagGameScreen/<>c::<HandleCharmFlyToPlate>b__18_1
02d3842c: bl      #0x2b70db0                                 fn_2b70db0
02d38430: adrp    x0, #0x626a000                             
02d38434: ldr     x0, [x0, #0xbd0]                           T:BlindBagCollection.BlindbagGameScreen/<>c
02d38438: bl      #0x2b70db0                                 fn_2b70db0
02d3843c: adrp    x0, #0x626a000                             
02d38440: ldr     x0, [x0, #0xbf8]                           S:'done_unbox'
02d38444: bl      #0x2b70db0                                 fn_2b70db0
02d38448: adrp    x0, #0x626a000                             
02d3844c: ldr     x0, [x0, #0xc00]                           S:'dev log _spawnedBlindBox check logic'
02d38450: bl      #0x2b70db0                                 fn_2b70db0
02d38454: mov     w8, #1                                     
02d38458: strb    w8, [x21, #0x131]                          
02d3845c: ldr     x0, [x20]                                  &2c5bbd4(=a9bd7bfdd503233f)
02d38460: adrp    x20, #0x626a000                            
02d38464: ldr     w8, [x0, #0xe4]                            [626a0e4]=0 f=0,0
02d38468: ldr     x20, [x20, #0xc00]                         S:'dev log _spawnedBlindBox check logic'
02d3846c: cbnz    w8, #0x2d38474                             
02d38470: bl      #0x2b70f30                                 fn_2b70f30
02d38474: ldr     x0, [x20]                                  T:type56879(k15)
02d38478: mov     x1, xzr                                    
02d3847c: bl      #0x5af21f4                                 UnityEngine.Debug::Log
02d38480: ldr     x8, [x19, #0x48]                           ._blindbagCollectionController
02d38484: cbz     x8, #0x2d385ac                             
02d38488: ldr     x0, [x8, #0x20]                            
02d3848c: cbz     x0, #0x2d385ac                             
02d38490: bl      #0x2d35350                                 BlindBagCollection.BlindBoxPlate::get_DoneUnbox
02d38494: tbz     w0, #0, #0x2d384a0                         
02d38498: ldrb    w8, [x19, #0x88]                           ._doneFlag
02d3849c: cbz     w8, #0x2d384b4                             
02d384a0: ldp     x20, x19, [sp, #0x30]                      
02d384a4: ldp     x22, x21, [sp, #0x20]                      
02d384a8: ldp     x24, x23, [sp, #0x10]                      
02d384ac: ldr     x30, [sp], #0x40                           
02d384b0: ret                                                
02d384b4: adrp    x8, #0x6265000                             
02d384b8: ldr     x8, [x8, #0x310]                           MS:WejoyService.Singleton`1::get_Instance
02d384bc: ldr     x0, [x8]                                   M:AdsManager::<OnApplicationPause>b__26_0
02d384c0: bl      #0x3be7218                                 fn_3be7218
02d384c4: adrp    x24, #0x626a000                            
02d384c8: mov     x20, x0                                    
02d384cc: ldr     x24, [x24, #0xbd0]                         T:BlindBagCollection.BlindbagGameScreen/<>c
02d384d0: ldr     x8, [x24]                                  T:type56879(k15)
02d384d4: ldr     w9, [x8, #0xe4]                            [62650e4]=0 f=0,0
02d384d8: cbnz    w9, #0x2d384e8                             
02d384dc: mov     x0, x8                                     
02d384e0: bl      #0x2b70f30                                 fn_2b70f30
02d384e4: ldr     x8, [x24]                                  T:type56879(k15)
02d384e8: adrp    x10, #0x626a000                            
02d384ec: ldr     x9, [x8, #0xb8]                            T:AdsManager/<>c__DisplayClass42_0
02d384f0: ldr     x10, [x10, #0xbf8]                         S:'done_unbox'
02d384f4: ldr     x22, [x9, #0x10]                           
02d384f8: ldr     x21, [x10]                                 T:type56879(k15)
02d384fc: cbnz    x22, #0x2d3855c                            
02d38500: ldr     w10, [x8, #0xe4]                           [62650e4]=0 f=0,0
02d38504: cbnz    w10, #0x2d38518                            
02d38508: mov     x0, x8                                     
02d3850c: bl      #0x2b70f30                                 fn_2b70f30
02d38510: ldr     x8, [x24]                                  T:type56879(k15)
02d38514: ldr     x9, [x8, #0xb8]                            T:AdsManager/<>c__DisplayClass42_0
02d38518: adrp    x8, #0x6264000                             
02d3851c: ldr     x8, [x8, #0xf90]                           T:System.Action
02d38520: ldr     x23, [x9]                                  
02d38524: ldr     x0, [x8]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d38528: bl      #0x2b7104c                                 fn_2b7104c
02d3852c: adrp    x8, #0x626a000                             
02d38530: mov     x1, x23                                    
02d38534: mov     x3, xzr                                    
02d38538: ldr     x8, [x8, #0xbf0]                           M:BlindBagCollection.BlindbagGameScreen/<>c::<HandleCharmFlyToPlate>b__18_1
02d3853c: mov     x22, x0                                    
02d38540: ldr     x2, [x8]                                   T:type56879(k15)
02d38544: bl      #0x4d8ddbc                                 System.Action::.ctor
02d38548: ldr     x8, [x24]                                  T:type56879(k15)
02d3854c: mov     x1, x22                                    
02d38550: ldr     x0, [x8, #0xb8]                            MS:UnityEngine.Object::FindObjectsOfType
02d38554: str     x22, [x0, #0x10]!                          
02d38558: bl      #0x2b70d54                                 fn_2b70d54
02d3855c: cbz     x20, #0x2d385ac                            
02d38560: mov     x0, x20                                    
02d38564: mov     x1, x21                                    
02d38568: mov     x2, x22                                    
02d3856c: mov     w3, #1                                     
02d38570: mov     x4, xzr                                    
02d38574: mov     w20, #1                                    
02d38578: bl      #0x2c89698                                 AdsManager::ShowInter
02d3857c: mov     x0, x19                                    
02d38580: strb    w20, [x19, #0x88]                          ._doneFlag
02d38584: bl      #0x2d38184                                 BlindBagCollection.BlindbagGameScreen::ShowContentSelectBox
02d38588: mov     x0, x19                                    
02d3858c: bl      #0x2d3824c                                 BlindBagCollection.BlindbagGameScreen::UpdateUnlockedItemData
02d38590: ldr     x0, [x19, #0x48]                           ._blindbagCollectionController
02d38594: cbz     x0, #0x2d385ac                             
02d38598: ldp     x20, x19, [sp, #0x30]                      
02d3859c: ldp     x22, x21, [sp, #0x20]                      
02d385a0: ldp     x24, x23, [sp, #0x10]                      
02d385a4: ldr     x30, [sp], #0x40                           
02d385a8: b       #0x2d32f0c                                 BlindBagCollection.BlindbagCollectionController::GoToCollectionStep
02d385ac: bl      #0x2b7105c                                 fn_2b7105c
