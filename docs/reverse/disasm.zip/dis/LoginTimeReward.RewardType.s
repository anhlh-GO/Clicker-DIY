#### CLASS LoginTimeReward.RewardType parent= int
#   field value__                        int                                                off=0x10 attr=606 
#   field Coin                           LoginTimeReward.RewardType                         off=0x0 attr=8056 
#   field RandomKeycapCommon             LoginTimeReward.RewardType                         off=0x0 attr=8056 
#   field RandomDecorSkin                LoginTimeReward.RewardType                         off=0x0 attr=8056 
#   field RandomKeycapRare               LoginTimeReward.RewardType                         off=0x0 attr=8056 
