#### CLASS Framework.FileUtils parent= object
## IsValidFile(string filePath) -> bool
---- Framework.FileUtils::IsValidFile 0x2cbf210
02cbf210: stp     x30, x21, [sp, #-0x20]!                    
02cbf214: stp     x20, x19, [sp, #0x10]                      
02cbf218: adrp    x19, #0x662f000                            
02cbf21c: adrp    x21, #0x6267000                            
02cbf220: mov     x20, x0                                    
02cbf224: ldrb    w8, [x19, #0xc09]                          
02cbf228: ldr     x21, [x21, #0x20]                          T:System.IO.FileInfo
02cbf22c: tbnz    w8, #0, #0x2cbf244                         
02cbf230: adrp    x0, #0x6267000                             
02cbf234: ldr     x0, [x0, #0x20]                            T:System.IO.FileInfo
02cbf238: bl      #0x2b70db0                                 fn_2b70db0
02cbf23c: mov     w8, #1                                     
02cbf240: strb    w8, [x19, #0xc09]                          
02cbf244: ldr     x0, [x21]                                  S:'didu'
02cbf248: bl      #0x2b7104c                                 fn_2b7104c
02cbf24c: mov     x1, x20                                    
02cbf250: mov     x2, xzr                                    
02cbf254: mov     x19, x0                                    
02cbf258: bl      #0x4ddaa34                                 System.IO.FileInfo::.ctor
02cbf25c: cbz     x19, #0x2cbf29c                            
02cbf260: ldr     x8, [x19]                                  &2b706c4(=eb01011ff9400808)
02cbf264: mov     x0, x19                                    
02cbf268: ldp     x9, x1, [x8, #0x1d8]                       
02cbf26c: blr     x9                                         
02cbf270: tbz     w0, #0, #0x2cbf28c                         
02cbf274: mov     x0, x19                                    
02cbf278: mov     x1, xzr                                    
02cbf27c: bl      #0x4ddaa44                                 System.IO.FileInfo::get_Length
02cbf280: cmp     x0, #0                                     
02cbf284: cset    w0, gt                                     
02cbf288: b       #0x2cbf290                                 
02cbf28c: mov     w0, wzr                                    
02cbf290: ldp     x20, x19, [sp, #0x10]                      
02cbf294: ldp     x30, x21, [sp], #0x20                      
02cbf298: ret                                                
02cbf29c: bl      #0x2b7105c                                 fn_2b7105c
## GetValidFileName(string fileName) -> string
---- Framework.FileUtils::GetValidFileName 0x2cbf2a0
02cbf2a0: str     x30, [sp, #-0x30]!                         
02cbf2a4: stp     x22, x21, [sp, #0x10]                      
02cbf2a8: stp     x20, x19, [sp, #0x20]                      
02cbf2ac: adrp    x20, #0x662f000                            
02cbf2b0: mov     x19, x0                                    
02cbf2b4: ldrb    w8, [x20, #0xc0a]                          
02cbf2b8: tbnz    w8, #0, #0x2cbf2f4                         
02cbf2bc: adrp    x0, #0x6266000                             
02cbf2c0: ldr     x0, [x0, #0xea0]                           T:System.Text.RegularExpressions.Regex
02cbf2c4: bl      #0x2b70db0                                 fn_2b70db0
02cbf2c8: adrp    x0, #0x6265000                             
02cbf2cc: ldr     x0, [x0, #0x260]                           S:' '
02cbf2d0: bl      #0x2b70db0                                 fn_2b70db0
02cbf2d4: adrp    x0, #0x6267000                             
02cbf2d8: ldr     x0, [x0, #0x28]                            S:'[^A-Za-z0-9_. ]+'
02cbf2dc: bl      #0x2b70db0                                 fn_2b70db0
02cbf2e0: adrp    x0, #0x6263000                             
02cbf2e4: ldr     x0, [x0, #0xa90]                           S:''
02cbf2e8: bl      #0x2b70db0                                 fn_2b70db0
02cbf2ec: mov     w8, #1                                     
02cbf2f0: strb    w8, [x20, #0xc0a]                          
02cbf2f4: cbz     x19, #0x2cbf380                            
02cbf2f8: adrp    x22, #0x6266000                            
02cbf2fc: adrp    x20, #0x6267000                            
02cbf300: adrp    x21, #0x6263000                            
02cbf304: ldr     x22, [x22, #0xea0]                         T:System.Text.RegularExpressions.Regex
02cbf308: ldr     x20, [x20, #0x28]                          S:'[^A-Za-z0-9_. ]+'
02cbf30c: ldr     x21, [x21, #0xa90]                         S:''
02cbf310: mov     x0, x19                                    
02cbf314: mov     x1, xzr                                    
02cbf318: bl      #0x4cab1c4                                 System.String::Trim
02cbf31c: ldr     x8, [x22]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cbf320: mov     x19, x0                                    
02cbf324: ldr     w9, [x8, #0xe4]                            
02cbf328: cbnz    w9, #0x2cbf334                             
02cbf32c: mov     x0, x8                                     
02cbf330: bl      #0x2b70f30                                 fn_2b70f30
02cbf334: ldr     x1, [x20]                                  S:'didu'
02cbf338: ldr     x2, [x21]                                  &2c5bbd4(=a9bd7bfdd503233f)
02cbf33c: mov     x0, x19                                    
02cbf340: mov     x3, xzr                                    
02cbf344: bl      #0x5386608                                 System.Text.RegularExpressions.Regex::Replace
02cbf348: cbz     x0, #0x2cbf380                             
02cbf34c: adrp    x8, #0x6263000                             
02cbf350: adrp    x9, #0x6265000                             
02cbf354: mov     x3, xzr                                    
02cbf358: ldr     x8, [x8, #0x970]                           &6645c70(=0)
02cbf35c: ldr     x8, [x8, #0x90]                            &2c5beb4(=14c8d222d503245f)
02cbf360: ldr     x9, [x9, #0x260]                           S:' '
02cbf364: ldp     x20, x19, [sp, #0x20]                      
02cbf368: ldr     x8, [x8, #0xb8]                            &6263108(=0)
02cbf36c: ldp     x22, x21, [sp, #0x10]                      
02cbf370: ldr     x1, [x9]                                   M:AdsManager::<OnApplicationPause>b__26_0
02cbf374: ldr     x2, [x8]                                   &2c5bbd4(=a9bd7bfdd503233f)
02cbf378: ldr     x30, [sp], #0x30                           
02cbf37c: b       #0x4ca8ca8                                 System.String::Replace
02cbf380: bl      #0x2b7105c                                 fn_2b7105c
## DeleteDirectory(string targetDir) -> void
---- Framework.FileUtils::DeleteDirectory 0x2cbf384
02cbf384: str     x30, [sp, #-0x40]!                         
02cbf388: stp     x24, x23, [sp, #0x10]                      
02cbf38c: stp     x22, x21, [sp, #0x20]                      
02cbf390: stp     x20, x19, [sp, #0x30]                      
02cbf394: mov     x1, xzr                                    
02cbf398: mov     x19, x0                                    
02cbf39c: bl      #0x4dd8c3c                                 System.IO.Directory::GetFiles
02cbf3a0: mov     x21, x0                                    
02cbf3a4: mov     x0, x19                                    
02cbf3a8: mov     x1, xzr                                    
02cbf3ac: bl      #0x4dd8fac                                 System.IO.Directory::GetDirectories
02cbf3b0: cbz     x21, #0x2cbf468                            
02cbf3b4: ldr     x8, [x21, #0x18]                           
02cbf3b8: mov     x20, x0                                    
02cbf3bc: cmp     w8, #1                                     
02cbf3c0: b.lt    #0x2cbf408                                 
02cbf3c4: mov     x23, xzr                                   
02cbf3c8: and     x8, x8, #0xffffffff                        
02cbf3cc: add     x24, x21, #0x20                            
02cbf3d0: cmp     x23, w8, uxtw                              
02cbf3d4: b.hs    #0x2cbf464                                 
02cbf3d8: ldr     x22, [x24, x23, lsl #3]                    
02cbf3dc: mov     w1, #0x80                                  
02cbf3e0: mov     x2, xzr                                    
02cbf3e4: mov     x0, x22                                    
02cbf3e8: bl      #0x4dd9a5c                                 System.IO.File::SetAttributes
02cbf3ec: mov     x0, x22                                    
02cbf3f0: mov     x1, xzr                                    
02cbf3f4: bl      #0x4dd991c                                 System.IO.File::Delete
02cbf3f8: ldr     w8, [x21, #0x18]                           
02cbf3fc: add     x23, x23, #1                               
02cbf400: cmp     x23, w8, sxtw                              
02cbf404: b.lt    #0x2cbf3d0                                 
02cbf408: cbz     x20, #0x2cbf468                            
02cbf40c: ldr     x8, [x20, #0x18]                           
02cbf410: cmp     w8, #1                                     
02cbf414: b.lt    #0x2cbf444                                 
02cbf418: mov     x21, xzr                                   
02cbf41c: and     x8, x8, #0xffffffff                        
02cbf420: add     x22, x20, #0x20                            
02cbf424: cmp     x21, w8, uxtw                              
02cbf428: b.hs    #0x2cbf464                                 
02cbf42c: ldr     x0, [x22, x21, lsl #3]                     
02cbf430: bl      #0x2cbf384                                 Framework.FileUtils::DeleteDirectory
02cbf434: ldr     w8, [x20, #0x18]                           
02cbf438: add     x21, x21, #1                               
02cbf43c: cmp     x21, w8, sxtw                              
02cbf440: b.lt    #0x2cbf424                                 
02cbf444: mov     x0, x19                                    
02cbf448: ldp     x20, x19, [sp, #0x30]                      
02cbf44c: ldp     x22, x21, [sp, #0x20]                      
02cbf450: mov     w1, wzr                                    
02cbf454: ldp     x24, x23, [sp, #0x10]                      
02cbf458: mov     x2, xzr                                    
02cbf45c: ldr     x30, [sp], #0x40                           
02cbf460: b       #0x4dd90d0                                 System.IO.Directory::Delete
02cbf464: bl      #0x2b71064                                 fn_2b71064
02cbf468: bl      #0x2b7105c                                 fn_2b7105c
## GetDirectorySize(string target_dir) -> long
---- Framework.FileUtils::GetDirectorySize 0x2cbf46c
02cbf46c: str     x30, [sp, #-0x50]!                         
02cbf470: stp     x26, x25, [sp, #0x10]                      
02cbf474: stp     x24, x23, [sp, #0x20]                      
02cbf478: stp     x22, x21, [sp, #0x30]                      
02cbf47c: stp     x20, x19, [sp, #0x40]                      
02cbf480: adrp    x20, #0x662f000                            
02cbf484: mov     x19, x0                                    
02cbf488: ldrb    w8, [x20, #0xc0b]                          
02cbf48c: tbnz    w8, #0, #0x2cbf4a4                         
02cbf490: adrp    x0, #0x6267000                             
02cbf494: ldr     x0, [x0, #0x20]                            T:System.IO.FileInfo
02cbf498: bl      #0x2b70db0                                 fn_2b70db0
02cbf49c: mov     w8, #1                                     
02cbf4a0: strb    w8, [x20, #0xc0b]                          
02cbf4a4: mov     x0, x19                                    
02cbf4a8: mov     x1, xzr                                    
02cbf4ac: bl      #0x4dd8ac0                                 System.IO.Directory::Exists
02cbf4b0: mov     x20, xzr                                   
02cbf4b4: tbz     w0, #0, #0x2cbf588                         
02cbf4b8: mov     x0, x19                                    
02cbf4bc: mov     x1, xzr                                    
02cbf4c0: bl      #0x4dd8c3c                                 System.IO.Directory::GetFiles
02cbf4c4: mov     x21, x0                                    
02cbf4c8: mov     x0, x19                                    
02cbf4cc: mov     x1, xzr                                    
02cbf4d0: bl      #0x4dd8fac                                 System.IO.Directory::GetDirectories
02cbf4d4: cbz     x21, #0x2cbf5ac                            
02cbf4d8: ldr     x8, [x21, #0x18]                           
02cbf4dc: mov     x19, x0                                    
02cbf4e0: cmp     w8, #1                                     
02cbf4e4: b.lt    #0x2cbf5a4                                 
02cbf4e8: adrp    x25, #0x6267000                            
02cbf4ec: mov     x20, xzr                                   
02cbf4f0: mov     x24, xzr                                   
02cbf4f4: ldr     x25, [x25, #0x20]                          T:System.IO.FileInfo
02cbf4f8: and     x8, x8, #0xffffffff                        
02cbf4fc: add     x26, x21, #0x20                            
02cbf500: cmp     x24, w8, uxtw                              
02cbf504: b.hs    #0x2cbf5b0                                 
02cbf508: ldr     x0, [x25]                                  S:'didu'
02cbf50c: ldr     x23, [x26, x24, lsl #3]                    
02cbf510: bl      #0x2b7104c                                 fn_2b7104c
02cbf514: mov     x1, x23                                    
02cbf518: mov     x2, xzr                                    
02cbf51c: mov     x22, x0                                    
02cbf520: bl      #0x4ddaa34                                 System.IO.FileInfo::.ctor
02cbf524: cbz     x22, #0x2cbf5ac                            
02cbf528: mov     x0, x22                                    
02cbf52c: mov     x1, xzr                                    
02cbf530: bl      #0x4ddaa44                                 System.IO.FileInfo::get_Length
02cbf534: ldr     w8, [x21, #0x18]                           
02cbf538: add     x24, x24, #1                               
02cbf53c: add     x20, x0, x20                               &6267000
02cbf540: cmp     x24, w8, sxtw                              
02cbf544: b.lt    #0x2cbf500                                 
02cbf548: cbz     x19, #0x2cbf5ac                            
02cbf54c: ldr     x8, [x19, #0x18]                           
02cbf550: cmp     w8, #1                                     
02cbf554: b.lt    #0x2cbf588                                 
02cbf558: mov     x21, xzr                                   
02cbf55c: and     x8, x8, #0xffffffff                        
02cbf560: add     x22, x19, #0x20                            
02cbf564: cmp     x21, w8, uxtw                              
02cbf568: b.hs    #0x2cbf5b0                                 
02cbf56c: ldr     x0, [x22, x21, lsl #3]                     
02cbf570: bl      #0x2cbf46c                                 Framework.FileUtils::GetDirectorySize
02cbf574: ldr     w8, [x19, #0x18]                           
02cbf578: add     x21, x21, #1                               
02cbf57c: add     x20, x0, x20                               &6267000
02cbf580: cmp     x21, w8, sxtw                              
02cbf584: b.lt    #0x2cbf564                                 
02cbf588: mov     x0, x20                                    
02cbf58c: ldp     x20, x19, [sp, #0x40]                      
02cbf590: ldp     x22, x21, [sp, #0x30]                      
02cbf594: ldp     x24, x23, [sp, #0x20]                      
02cbf598: ldp     x26, x25, [sp, #0x10]                      
02cbf59c: ldr     x30, [sp], #0x50                           
02cbf5a0: ret                                                
02cbf5a4: mov     x20, xzr                                   
02cbf5a8: cbnz    x19, #0x2cbf54c                            
02cbf5ac: bl      #0x2b7105c                                 fn_2b7105c
02cbf5b0: bl      #0x2b71064                                 fn_2b71064
