#### CLASS Clicker.KeychainItemData parent= object
#   field Id                             int                                                off=0x10 attr=6 
#   field Icon                           UnityEngine.Sprite                                 off=0x18 attr=6 
#   field KeychainSprite                 UnityEngine.Sprite                                 off=0x20 attr=6 
#   field UnlockMethod                   Clicker.UnlockMethod                               off=0x28 attr=6 
## .ctor() -> void
---- Clicker.KeychainItemData::.ctor 0x2d5bc38
02d5bc38: mov     x1, xzr                                    
02d5bc3c: b       #0x4e53e9c                                 System.Object::.ctor
