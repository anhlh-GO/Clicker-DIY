#### CLASS ReadOnlyAttribute parent= UnityEngine.PropertyAttribute
## .ctor() -> void
---- ReadOnlyAttribute::.ctor 0x2cf2a68
02cf2a68: mov     x1, xzr                                    
02cf2a6c: b       #0x5b2d93c                                 UnityEngine.PropertyAttribute::.ctor
