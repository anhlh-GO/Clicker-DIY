#### CLASS DreamHouse.MarkPointAnimation parent= UnityEngine.MonoBehaviour
#   field _duration                      float                                              off=0x20 attr=1 
#   field _yValue                        float                                              off=0x24 attr=1 
#   field _moveTween                     DG.Tweening.Tween                                  off=0x28 attr=1 
#   field _scaleTween                    DG.Tweening.Tween                                  off=0x30 attr=1 
## OnEnable() -> void
---- DreamHouse.MarkPointAnimation::OnEnable 0x2d18540
02d18540: b       #0x2d18544                                 DreamHouse.MarkPointAnimation::Play
## OnDisable() -> void
---- DreamHouse.MarkPointAnimation::OnDisable 0x2d186a4
02d186a4: stp     x30, x19, [sp, #-0x10]!                    
02d186a8: mov     x19, x0                                    
02d186ac: ldr     x0, [x0, #0x28]                            ._moveTween
02d186b0: cbz     x0, #0x2d186c0                             
02d186b4: mov     w1, wzr                                    
02d186b8: mov     x2, xzr                                    
02d186bc: bl      #0x2d8fe94                                 DG.Tweening.TweenExtensions::Kill
02d186c0: ldr     x0, [x19, #0x30]                           ._scaleTween
02d186c4: cbz     x0, #0x2d186d8                             
02d186c8: mov     w1, wzr                                    
02d186cc: mov     x2, xzr                                    
02d186d0: ldp     x30, x19, [sp], #0x10                      
02d186d4: b       #0x2d8fe94                                 DG.Tweening.TweenExtensions::Kill
02d186d8: ldp     x30, x19, [sp], #0x10                      
02d186dc: ret                                                
## Play() -> void
---- DreamHouse.MarkPointAnimation::Play 0x2d18544
02d18544: str     x30, [sp, #-0x40]!                         
02d18548: stp     x24, x23, [sp, #0x10]                      
02d1854c: stp     x22, x21, [sp, #0x20]                      
02d18550: stp     x20, x19, [sp, #0x30]                      
02d18554: adrp    x23, #0x662f000                            
02d18558: adrp    x22, #0x6268000                            
02d1855c: adrp    x21, #0x6266000                            
02d18560: adrp    x20, #0x6269000                            
02d18564: ldr     x22, [x22, #0x10]                          MS:DG.Tweening.TweenSettingsExtensions::SetLoops
02d18568: ldrb    w8, [x23, #0xfeb]                          
02d1856c: ldr     x21, [x21, #0x880]                         MS:DG.Tweening.TweenSettingsExtensions::SetEase
02d18570: ldr     x20, [x20, #0xa60]                         MS:DG.Tweening.TweenSettingsExtensions::SetRelative
02d18574: mov     x19, x0                                    
02d18578: tbnz    w8, #0, #0x2d185a8                         
02d1857c: adrp    x0, #0x6266000                             
02d18580: ldr     x0, [x0, #0x880]                           MS:DG.Tweening.TweenSettingsExtensions::SetEase
02d18584: bl      #0x2b70db0                                 fn_2b70db0
02d18588: adrp    x0, #0x6268000                             
02d1858c: ldr     x0, [x0, #0x10]                            MS:DG.Tweening.TweenSettingsExtensions::SetLoops
02d18590: bl      #0x2b70db0                                 fn_2b70db0
02d18594: adrp    x0, #0x6269000                             
02d18598: ldr     x0, [x0, #0xa60]                           MS:DG.Tweening.TweenSettingsExtensions::SetRelative
02d1859c: bl      #0x2b70db0                                 fn_2b70db0
02d185a0: mov     w8, #1                                     
02d185a4: strb    w8, [x23, #0xfeb]                          
02d185a8: mov     x0, x19                                    
02d185ac: mov     x1, xzr                                    
02d185b0: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02d185b4: ldp     s1, s0, [x19, #0x20]                       ._duration
02d185b8: mov     w1, wzr                                    
02d185bc: mov     x2, xzr                                    
02d185c0: bl      #0x2d98060                                 DG.Tweening.ShortcutExtensions::DOLocalMoveY
02d185c4: ldr     x3, [x22]                                  S:'{0}/2'
02d185c8: mov     w1, #-1                                    
02d185cc: mov     w2, #1                                     
02d185d0: mov     w23, #1                                    
02d185d4: bl      #0x336fe74                                 fn_336fe74
02d185d8: ldr     x2, [x21]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d185dc: mov     w1, #4                                     
02d185e0: bl      #0x336fa0c                                 fn_336fa0c
02d185e4: ldr     x2, [x20]                                  T:Trading.TradingSession/<>c__DisplayClass56_0
02d185e8: mov     w1, #1                                     
02d185ec: bl      #0x336ff30                                 fn_336ff30
02d185f0: mov     x1, x0                                     
02d185f4: mov     x0, x19                                    
02d185f8: str     x1, [x0, #0x28]!                           ._moveTween
02d185fc: bl      #0x2b70d54                                 fn_2b70d54
02d18600: mov     x0, x19                                    
02d18604: mov     x1, xzr                                    
02d18608: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02d1860c: adrp    x24, #0x662f000                            
02d18610: mov     x20, x0                                    
02d18614: ldrb    w8, [x24, #0xca2]                          
02d18618: cbnz    w8, #0x2d1862c                             
02d1861c: adrp    x0, #0x6266000                             
02d18620: ldr     x0, [x0, #0x970]                           T:UnityEngine.Vector2
02d18624: bl      #0x2b70db0                                 fn_2b70db0
02d18628: strb    w23, [x24, #0xca2]                         
02d1862c: adrp    x8, #0x6266000                             
02d18630: mov     w9, #0xcccd                                
02d18634: movi    d2, #0000000000000000                      
02d18638: ldr     x8, [x8, #0x970]                           T:UnityEngine.Vector2
02d1863c: movk    w9, #0x3f8c, lsl #16                       
02d18640: ldr     s3, [x19, #0x20]                           ._duration
02d18644: dup     v0.2s, w9                                  
02d18648: mov     x0, x20                                    
02d1864c: mov     x1, xzr                                    
02d18650: ldr     x8, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d18654: ldr     x8, [x8, #0xb8]                            S:'banner_native_refresh_time'
02d18658: ldr     d1, [x8, #8]                               MS:Firebase.Extensions.TaskExtension::ContinueWithOnMainThread
02d1865c: fmul    v0.2s, v1.2s, v0.2s                        
02d18660: mov     s1, v0.s[1]                                
02d18664: bl      #0x2d98af8                                 DG.Tweening.ShortcutExtensions::DOScale
02d18668: ldr     x3, [x22]                                  S:'{0}/2'
02d1866c: mov     w1, #-1                                    
02d18670: mov     w2, #1                                     
02d18674: bl      #0x336fe74                                 fn_336fe74
02d18678: ldr     x2, [x21]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d1867c: mov     w1, #7                                     
02d18680: bl      #0x336fa0c                                 fn_336fa0c
02d18684: str     x0, [x19, #0x30]!                          ._scaleTween
02d18688: mov     x1, x0                                     
02d1868c: mov     x0, x19                                    
02d18690: ldp     x20, x19, [sp, #0x30]                      
02d18694: ldp     x22, x21, [sp, #0x20]                      
02d18698: ldp     x24, x23, [sp, #0x10]                      
02d1869c: ldr     x30, [sp], #0x40                           
02d186a0: b       #0x2b70d54                                 
## .ctor() -> void
---- DreamHouse.MarkPointAnimation::.ctor 0x2d186e0
02d186e0: adrp    x8, #0x1040000                             
02d186e4: mov     x1, xzr                                    
02d186e8: ldr     d0, [x8, #0x7a0]                           [10407a0]=3eb333333f4ccccd f=0.8,0.35
02d186ec: str     d0, [x0, #0x20]                            ._duration
02d186f0: b       #0x5b397b0                                 UnityEngine.MonoBehaviour::.ctor
