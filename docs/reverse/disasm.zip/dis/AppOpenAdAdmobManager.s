#### CLASS AppOpenAdAdmobManager parent= AdmobEventBase
#   field _appOpenAd                     GoogleMobileAds.Api.AppOpenAd                      off=0x40 attr=1 
#   field _action                        System.Action                                      off=0x48 attr=1 
## Start() -> void
---- AppOpenAdAdmobManager::Start 0x2c8f804
02c8f804: stp     x30, x21, [sp, #-0x20]!                    
02c8f808: stp     x20, x19, [sp, #0x10]                      
02c8f80c: adrp    x21, #0x662f000                            
02c8f810: adrp    x20, #0x6265000                            
02c8f814: mov     x19, x0                                    
02c8f818: ldrb    w8, [x21, #0x9bb]                          
02c8f81c: ldr     x20, [x20, #0x310]                         MS:WejoyService.Singleton`1::get_Instance
02c8f820: tbnz    w8, #0, #0x2c8f844                         
02c8f824: adrp    x0, #0x6265000                             
02c8f828: ldr     x0, [x0, #0x488]                           T:KeyTest
02c8f82c: bl      #0x2b70db0                                 fn_2b70db0
02c8f830: adrp    x0, #0x6265000                             
02c8f834: ldr     x0, [x0, #0x310]                           MS:WejoyService.Singleton`1::get_Instance
02c8f838: bl      #0x2b70db0                                 fn_2b70db0
02c8f83c: mov     w8, #1                                     
02c8f840: strb    w8, [x21, #0x9bb]                          
02c8f844: mov     w0, #5                                     
02c8f848: bl      #0x2c8de38                                 KeyAds::Get
02c8f84c: mov     x1, x0                                     
02c8f850: str     x0, [x19, #0x28]!                          
02c8f854: mov     x0, x19                                    
02c8f858: bl      #0x2b70d54                                 fn_2b70d54
02c8f85c: ldr     x0, [x20]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c8f860: bl      #0x3be7218                                 fn_3be7218
02c8f864: cbz     x0, #0x2c8f8b4                             
02c8f868: ldrb    w8, [x0, #0x31]                            
02c8f86c: cbz     w8, #0x2c8f8a8                             
02c8f870: adrp    x20, #0x6265000                            
02c8f874: ldr     x20, [x20, #0x488]                         T:KeyTest
02c8f878: ldr     x0, [x20]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c8f87c: ldr     w8, [x0, #0xe4]                            [62650e4]=0 f=0,0
02c8f880: cbnz    w8, #0x2c8f88c                             
02c8f884: bl      #0x2b70f30                                 fn_2b70f30
02c8f888: ldr     x0, [x20]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c8f88c: ldr     x8, [x0, #0xb8]                            T:AdsManager/<>c__DisplayClass42_0
02c8f890: mov     x0, x19                                    
02c8f894: ldr     x1, [x8]                                   
02c8f898: str     x1, [x19]                                  
02c8f89c: ldp     x20, x19, [sp, #0x10]                      
02c8f8a0: ldp     x30, x21, [sp], #0x20                      
02c8f8a4: b       #0x2b70d54                                 
02c8f8a8: ldp     x20, x19, [sp, #0x10]                      
02c8f8ac: ldp     x30, x21, [sp], #0x20                      
02c8f8b0: ret                                                
02c8f8b4: bl      #0x2b7105c                                 fn_2b7105c
## LoadAd() -> void
---- AppOpenAdAdmobManager::LoadAd 0x2c8f8b8
02c8f8b8: stp     x30, x23, [sp, #-0x30]!                    
02c8f8bc: stp     x22, x21, [sp, #0x10]                      
02c8f8c0: stp     x20, x19, [sp, #0x20]                      
02c8f8c4: adrp    x21, #0x662f000                            
02c8f8c8: adrp    x20, #0x6264000                            
02c8f8cc: mov     x19, x0                                    
02c8f8d0: ldrb    w8, [x21, #0x9bc]                          
02c8f8d4: ldr     x20, [x20, #0xfc0]                         T:RemoteConfigManager
02c8f8d8: tbnz    w8, #0, #0x2c8f938                         
02c8f8dc: adrp    x0, #0x6265000                             
02c8f8e0: ldr     x0, [x0, #0x490]                           T:type7117(k15)
02c8f8e4: bl      #0x2b70db0                                 fn_2b70db0
02c8f8e8: adrp    x0, #0x6265000                             
02c8f8ec: ldr     x0, [x0, #0x498]                           T:GoogleMobileAds.Api.AdRequest
02c8f8f0: bl      #0x2b70db0                                 fn_2b70db0
02c8f8f4: adrp    x0, #0x6265000                             
02c8f8f8: ldr     x0, [x0, #0x4a0]                           M:AppOpenAdAdmobManager::<LoadAd>b__3_0
02c8f8fc: bl      #0x2b70db0                                 fn_2b70db0
02c8f900: adrp    x0, #0x6265000                             
02c8f904: ldr     x0, [x0, #0x488]                           T:KeyTest
02c8f908: bl      #0x2b70db0                                 fn_2b70db0
02c8f90c: adrp    x0, #0x6264000                             
02c8f910: ldr     x0, [x0, #0xfc0]                           T:RemoteConfigManager
02c8f914: bl      #0x2b70db0                                 fn_2b70db0
02c8f918: adrp    x0, #0x6265000                             
02c8f91c: ldr     x0, [x0, #0x310]                           MS:WejoyService.Singleton`1::get_Instance
02c8f920: bl      #0x2b70db0                                 fn_2b70db0
02c8f924: adrp    x0, #0x6265000                             
02c8f928: ldr     x0, [x0, #0x4a8]                           S:'Loading app open ad.'
02c8f92c: bl      #0x2b70db0                                 fn_2b70db0
02c8f930: mov     w8, #1                                     
02c8f934: strb    w8, [x21, #0x9bc]                          
02c8f938: ldr     x0, [x20]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c8f93c: ldr     w8, [x0, #0xe4]                            [62650e4]=0 f=0,0
02c8f940: cbnz    w8, #0x2c8f948                             
02c8f944: bl      #0x2b70f30                                 fn_2b70f30
02c8f948: adrp    x21, #0x662f000                            
02c8f94c: ldrb    w8, [x21, #0xa7f]                          
02c8f950: cbnz    w8, #0x2c8f968                             
02c8f954: adrp    x0, #0x6264000                             
02c8f958: ldr     x0, [x0, #0xfc0]                           T:RemoteConfigManager
02c8f95c: bl      #0x2b70db0                                 fn_2b70db0
02c8f960: mov     w8, #1                                     
02c8f964: strb    w8, [x21, #0xa7f]                          
02c8f968: ldr     x0, [x20]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c8f96c: adrp    x21, #0x6265000                            
02c8f970: ldr     w8, [x0, #0xe4]                            [62640e4]=0 f=0,0
02c8f974: ldr     x21, [x21, #0x310]                         MS:WejoyService.Singleton`1::get_Instance
02c8f978: cbnz    w8, #0x2c8f984                             
02c8f97c: bl      #0x2b70f30                                 fn_2b70f30
02c8f980: ldr     x0, [x20]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c8f984: ldr     x8, [x0, #0xb8]                            MS:DG.Tweening.Core.Extensions::SetSpecialStartupMode
02c8f988: mov     x20, x19                                   
02c8f98c: ldr     x1, [x8, #0x18]                            
02c8f990: str     x1, [x20, #0x28]!                          
02c8f994: mov     x0, x20                                    
02c8f998: bl      #0x2b70d54                                 fn_2b70d54
02c8f99c: ldr     x0, [x21]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c8f9a0: bl      #0x3be7218                                 fn_3be7218
02c8f9a4: cbz     x0, #0x2c8fa70                             
02c8f9a8: ldrb    w8, [x0, #0x31]                            
02c8f9ac: cbz     w8, #0x2c8f9e0                             
02c8f9b0: adrp    x21, #0x6265000                            
02c8f9b4: ldr     x21, [x21, #0x488]                         T:KeyTest
02c8f9b8: ldr     x0, [x21]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c8f9bc: ldr     w8, [x0, #0xe4]                            [62640e4]=0 f=0,0
02c8f9c0: cbnz    w8, #0x2c8f9cc                             
02c8f9c4: bl      #0x2b70f30                                 fn_2b70f30
02c8f9c8: ldr     x0, [x21]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c8f9cc: ldr     x8, [x0, #0xb8]                            MS:DG.Tweening.Core.Extensions::SetSpecialStartupMode
02c8f9d0: mov     x0, x20                                    
02c8f9d4: ldr     x1, [x8]                                   
02c8f9d8: str     x1, [x20]                                  
02c8f9dc: bl      #0x2b70d54                                 fn_2b70d54
02c8f9e0: adrp    x21, #0x6265000                            
02c8f9e4: adrp    x20, #0x6265000                            
02c8f9e8: adrp    x23, #0x6265000                            
02c8f9ec: adrp    x22, #0x6265000                            
02c8f9f0: ldr     x21, [x21, #0x4a8]                         S:'Loading app open ad.'
02c8f9f4: ldr     x20, [x20, #0x498]                         T:GoogleMobileAds.Api.AdRequest
02c8f9f8: ldr     x23, [x23, #0x490]                         T:type7117(k15)
02c8f9fc: ldr     x8, [x19, #0x40]                           ._appOpenAd
02c8fa00: ldr     x22, [x22, #0x4a0]                         M:AppOpenAdAdmobManager::<LoadAd>b__3_0
02c8fa04: cbz     x8, #0x2c8fa10                             
02c8fa08: mov     x0, x19                                    
02c8fa0c: bl      #0x2c8fa74                                 AppOpenAdAdmobManager::DestroyAd
02c8fa10: ldr     x0, [x21]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c8fa14: mov     x1, xzr                                    
02c8fa18: bl      #0x2ca46ac                                 WLog::Log
02c8fa1c: ldr     x0, [x20]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c8fa20: bl      #0x2b7104c                                 fn_2b7104c
02c8fa24: mov     x1, xzr                                    
02c8fa28: mov     x20, x0                                    
02c8fa2c: bl      #0x4c2fe94                                 GoogleMobileAds.Api.AdRequest::.ctor
02c8fa30: ldr     x0, [x23]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c8fa34: ldr     x21, [x19, #0x28]                          
02c8fa38: bl      #0x2b7104c                                 fn_2b7104c
02c8fa3c: ldr     x2, [x22]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c8fa40: mov     x1, x19                                    
02c8fa44: mov     x3, xzr                                    
02c8fa48: mov     x22, x0                                    
02c8fa4c: bl      #0x453ce6c                                 fn_453ce6c
02c8fa50: mov     x0, x21                                    
02c8fa54: mov     x1, x20                                    
02c8fa58: mov     x2, x22                                    
02c8fa5c: ldp     x20, x19, [sp, #0x20]                      
02c8fa60: mov     x3, xzr                                    
02c8fa64: ldp     x22, x21, [sp, #0x10]                      
02c8fa68: ldp     x30, x23, [sp], #0x30                      
02c8fa6c: b       #0x4c3540c                                 GoogleMobileAds.Api.AppOpenAd::Load
02c8fa70: bl      #0x2b7105c                                 fn_2b7105c
## ShowAd(string placement, System.Action action) -> void
---- AppOpenAdAdmobManager::ShowAd 0x2c8fac8
02c8fac8: str     x30, [sp, #-0x30]!                         
02c8facc: stp     x22, x21, [sp, #0x10]                      
02c8fad0: stp     x20, x19, [sp, #0x20]                      
02c8fad4: adrp    x22, #0x662f000                            
02c8fad8: mov     x19, x2                                    
02c8fadc: mov     x21, x1                                    
02c8fae0: ldrb    w8, [x22, #0x9bd]                          
02c8fae4: mov     x20, x0                                    
02c8fae8: tbnz    w8, #0, #0x2c8fb00                         
02c8faec: adrp    x0, #0x6265000                             
02c8faf0: ldr     x0, [x0, #0x4b0]                           S:'App open ad is not ready yet.'
02c8faf4: bl      #0x2b70db0                                 fn_2b70db0
02c8faf8: mov     w8, #1                                     
02c8fafc: strb    w8, [x22, #0x9bd]                          
02c8fb00: mov     x22, x20                                   
02c8fb04: mov     x1, x21                                    
02c8fb08: str     x21, [x22, #0x20]!                         
02c8fb0c: mov     x0, x22                                    
02c8fb10: bl      #0x2b70d54                                 fn_2b70d54
02c8fb14: ldr     x0, [x22, #0x20]                           &2b706f0(=d65f03c0f9400800)
02c8fb18: cbz     x0, #0x2c8fb54                             
02c8fb1c: mov     x1, xzr                                    
02c8fb20: bl      #0x4c357c8                                 GoogleMobileAds.Api.AppOpenAd::CanShowAd
02c8fb24: tbz     w0, #0, #0x2c8fb54                         
02c8fb28: ldr     x0, [x20, #0x40]                           ._appOpenAd
02c8fb2c: cbz     x0, #0x2c8fb88                             
02c8fb30: mov     x1, xzr                                    
02c8fb34: bl      #0x4c357e8                                 GoogleMobileAds.Api.AppOpenAd::Show
02c8fb38: str     x19, [x20, #0x48]!                         ._action
02c8fb3c: mov     x0, x20                                    
02c8fb40: mov     x1, x19                                    
02c8fb44: ldp     x20, x19, [sp, #0x20]                      
02c8fb48: ldp     x22, x21, [sp, #0x10]                      
02c8fb4c: ldr     x30, [sp], #0x30                           
02c8fb50: b       #0x2b70d54                                 
02c8fb54: adrp    x8, #0x6265000                             
02c8fb58: mov     x1, xzr                                    
02c8fb5c: ldr     x8, [x8, #0x4b0]                           S:'App open ad is not ready yet.'
02c8fb60: ldr     x0, [x8]                                   M:AdsManager::<OnApplicationPause>b__26_0
02c8fb64: bl      #0x2ca09f8                                 WLog::LogError
02c8fb68: cbz     x19, #0x2c8fb88                            
02c8fb6c: ldr     x0, [x19, #0x40]                           ._appOpenAd
02c8fb70: ldr     x1, [x19, #0x28]                           
02c8fb74: ldr     x2, [x19, #0x18]                           
02c8fb78: ldp     x20, x19, [sp, #0x20]                      
02c8fb7c: ldp     x22, x21, [sp, #0x10]                      
02c8fb80: ldr     x30, [sp], #0x30                           
02c8fb84: br      x2                                         
02c8fb88: bl      #0x2b7105c                                 fn_2b7105c
## DestroyAd() -> void
---- AppOpenAdAdmobManager::DestroyAd 0x2c8fa74
02c8fa74: str     x30, [sp, #-0x20]!                         
02c8fa78: stp     x20, x19, [sp, #0x10]                      
02c8fa7c: mov     x19, x0                                    
02c8fa80: ldr     x1, [x19, #0x40]!                          ._appOpenAd
02c8fa84: cbz     x1, #0x2c8fab8                             
02c8fa88: mov     x20, x0                                    
02c8fa8c: bl      #0x2c8fb8c                                 AppOpenAdAdmobManager::RemoveEventHandlers
02c8fa90: ldr     x0, [x20, #0x40]                           ._appOpenAd
02c8fa94: cbz     x0, #0x2c8fac4                             
02c8fa98: mov     x1, xzr                                    
02c8fa9c: bl      #0x4c358a0                                 GoogleMobileAds.Api.AppOpenAd::Destroy
02c8faa0: mov     x0, x19                                    
02c8faa4: str     xzr, [x19]                                 
02c8faa8: mov     x1, xzr                                    
02c8faac: ldp     x20, x19, [sp, #0x10]                      
02c8fab0: ldr     x30, [sp], #0x20                           
02c8fab4: b       #0x2b70d54                                 
02c8fab8: ldp     x20, x19, [sp, #0x10]                      
02c8fabc: ldr     x30, [sp], #0x20                           
02c8fac0: ret                                                
02c8fac4: bl      #0x2b7105c                                 fn_2b7105c
## RegisterEventHandlers(GoogleMobileAds.Api.AppOpenAd ad) -> void
---- AppOpenAdAdmobManager::RegisterEventHandlers 0x2c8fd30
02c8fd30: str     x30, [sp, #-0x40]!                         
02c8fd34: stp     x24, x23, [sp, #0x10]                      
02c8fd38: stp     x22, x21, [sp, #0x20]                      
02c8fd3c: stp     x20, x19, [sp, #0x30]                      
02c8fd40: adrp    x21, #0x662f000                            
02c8fd44: adrp    x22, #0x6264000                            
02c8fd48: mov     x19, x1                                    
02c8fd4c: ldrb    w8, [x21, #0x9be]                          
02c8fd50: ldr     x22, [x22, #0xf90]                         T:System.Action
02c8fd54: mov     x20, x0                                    
02c8fd58: tbnz    w8, #0, #0x2c8fd88                         
02c8fd5c: adrp    x0, #0x6265000                             
02c8fd60: ldr     x0, [x0, #0x4b8]                           T:type6799(k15)
02c8fd64: bl      #0x2b70db0                                 fn_2b70db0
02c8fd68: adrp    x0, #0x6265000                             
02c8fd6c: ldr     x0, [x0, #0x4c0]                           T:type6805(k15)
02c8fd70: bl      #0x2b70db0                                 fn_2b70db0
02c8fd74: adrp    x0, #0x6264000                             
02c8fd78: ldr     x0, [x0, #0xf90]                           T:System.Action
02c8fd7c: bl      #0x2b70db0                                 fn_2b70db0
02c8fd80: mov     w8, #1                                     
02c8fd84: strb    w8, [x21, #0x9be]                          
02c8fd88: ldr     x0, [x22]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c8fd8c: bl      #0x2b7104c                                 fn_2b7104c
02c8fd90: cbz     x20, #0x2c8fed0                            
02c8fd94: ldr     x8, [x20]                                  
02c8fd98: mov     x1, x20                                    
02c8fd9c: mov     x3, xzr                                    
02c8fda0: mov     x21, x0                                    
02c8fda4: ldr     x2, [x8, #0x180]                           
02c8fda8: bl      #0x4d8ddbc                                 System.Action::.ctor
02c8fdac: cbz     x19, #0x2c8fed0                            
02c8fdb0: adrp    x24, #0x6265000                            
02c8fdb4: adrp    x23, #0x6265000                            
02c8fdb8: mov     x0, x19                                    
02c8fdbc: ldr     x24, [x24, #0x4b8]                         T:type6799(k15)
02c8fdc0: ldr     x23, [x23, #0x4c0]                         T:type6805(k15)
02c8fdc4: mov     x1, x21                                    
02c8fdc8: mov     x2, xzr                                    
02c8fdcc: bl      #0x4c348cc                                 GoogleMobileAds.Api.AppOpenAd::add_OnAdClicked
02c8fdd0: ldr     x0, [x22]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c8fdd4: bl      #0x2b7104c                                 fn_2b7104c
02c8fdd8: ldr     x8, [x20]                                  
02c8fddc: mov     x1, x20                                    
02c8fde0: mov     x3, xzr                                    
02c8fde4: mov     x21, x0                                    
02c8fde8: ldr     x2, [x8, #0x190]                           
02c8fdec: bl      #0x4d8ddbc                                 System.Action::.ctor
02c8fdf0: mov     x0, x19                                    
02c8fdf4: mov     x1, x21                                    
02c8fdf8: mov     x2, xzr                                    
02c8fdfc: bl      #0x4c34c74                                 GoogleMobileAds.Api.AppOpenAd::add_OnAdFullScreenContentClosed
02c8fe00: ldr     x0, [x24]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c8fe04: bl      #0x2b7104c                                 fn_2b7104c
02c8fe08: ldr     x8, [x20]                                  
02c8fe0c: mov     x1, x20                                    
02c8fe10: mov     x3, xzr                                    
02c8fe14: mov     x21, x0                                    
02c8fe18: ldr     x2, [x8, #0x1c0]                           
02c8fe1c: bl      #0x453418c                                 fn_453418c
02c8fe20: mov     x0, x19                                    
02c8fe24: mov     x1, x21                                    
02c8fe28: mov     x2, xzr                                    
02c8fe2c: bl      #0x4c34dac                                 GoogleMobileAds.Api.AppOpenAd::add_OnAdFullScreenContentFailed
02c8fe30: ldr     x0, [x22]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c8fe34: bl      #0x2b7104c                                 fn_2b7104c
02c8fe38: ldr     x8, [x20]                                  
02c8fe3c: mov     x1, x20                                    
02c8fe40: mov     x3, xzr                                    
02c8fe44: mov     x21, x0                                    
02c8fe48: ldr     x2, [x8, #0x1a0]                           
02c8fe4c: bl      #0x4d8ddbc                                 System.Action::.ctor
02c8fe50: mov     x0, x19                                    
02c8fe54: mov     x1, x21                                    
02c8fe58: mov     x2, xzr                                    
02c8fe5c: bl      #0x4c34b3c                                 GoogleMobileAds.Api.AppOpenAd::add_OnAdFullScreenContentOpened
02c8fe60: ldr     x0, [x22]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c8fe64: bl      #0x2b7104c                                 fn_2b7104c
02c8fe68: ldr     x8, [x20]                                  
02c8fe6c: mov     x1, x20                                    
02c8fe70: mov     x3, xzr                                    
02c8fe74: mov     x21, x0                                    
02c8fe78: ldr     x2, [x8, #0x1b0]                           
02c8fe7c: bl      #0x4d8ddbc                                 System.Action::.ctor
02c8fe80: mov     x0, x19                                    
02c8fe84: mov     x1, x21                                    
02c8fe88: mov     x2, xzr                                    
02c8fe8c: bl      #0x4c34a04                                 GoogleMobileAds.Api.AppOpenAd::add_OnAdImpressionRecorded
02c8fe90: ldr     x0, [x23]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c8fe94: bl      #0x2b7104c                                 fn_2b7104c
02c8fe98: ldr     x8, [x20]                                  
02c8fe9c: mov     x1, x20                                    
02c8fea0: mov     x3, xzr                                    
02c8fea4: mov     x21, x0                                    
02c8fea8: ldr     x2, [x8, #0x1d0]                           
02c8feac: bl      #0x453418c                                 fn_453418c
02c8feb0: mov     x0, x19                                    
02c8feb4: mov     x1, x21                                    
02c8feb8: mov     x2, xzr                                    
02c8febc: ldp     x20, x19, [sp, #0x30]                      
02c8fec0: ldp     x22, x21, [sp, #0x20]                      
02c8fec4: ldp     x24, x23, [sp, #0x10]                      
02c8fec8: ldr     x30, [sp], #0x40                           
02c8fecc: b       #0x4c3476c                                 GoogleMobileAds.Api.AppOpenAd::add_OnAdPaid
02c8fed0: bl      #0x2b7105c                                 fn_2b7105c
## RemoveEventHandlers(GoogleMobileAds.Api.AppOpenAd ad) -> void
---- AppOpenAdAdmobManager::RemoveEventHandlers 0x2c8fb8c
02c8fb8c: str     x30, [sp, #-0x40]!                         
02c8fb90: stp     x24, x23, [sp, #0x10]                      
02c8fb94: stp     x22, x21, [sp, #0x20]                      
02c8fb98: stp     x20, x19, [sp, #0x30]                      
02c8fb9c: adrp    x21, #0x662f000                            
02c8fba0: adrp    x22, #0x6264000                            
02c8fba4: mov     x19, x1                                    
02c8fba8: ldrb    w8, [x21, #0x9bf]                          
02c8fbac: ldr     x22, [x22, #0xf90]                         T:System.Action
02c8fbb0: mov     x20, x0                                    
02c8fbb4: tbnz    w8, #0, #0x2c8fbe4                         
02c8fbb8: adrp    x0, #0x6265000                             
02c8fbbc: ldr     x0, [x0, #0x4b8]                           T:type6799(k15)
02c8fbc0: bl      #0x2b70db0                                 fn_2b70db0
02c8fbc4: adrp    x0, #0x6265000                             
02c8fbc8: ldr     x0, [x0, #0x4c0]                           T:type6805(k15)
02c8fbcc: bl      #0x2b70db0                                 fn_2b70db0
02c8fbd0: adrp    x0, #0x6264000                             
02c8fbd4: ldr     x0, [x0, #0xf90]                           T:System.Action
02c8fbd8: bl      #0x2b70db0                                 fn_2b70db0
02c8fbdc: mov     w8, #1                                     
02c8fbe0: strb    w8, [x21, #0x9bf]                          
02c8fbe4: ldr     x0, [x22]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c8fbe8: bl      #0x2b7104c                                 fn_2b7104c
02c8fbec: cbz     x20, #0x2c8fd2c                            
02c8fbf0: ldr     x8, [x20]                                  
02c8fbf4: mov     x1, x20                                    
02c8fbf8: mov     x3, xzr                                    
02c8fbfc: mov     x21, x0                                    
02c8fc00: ldr     x2, [x8, #0x180]                           
02c8fc04: bl      #0x4d8ddbc                                 System.Action::.ctor
02c8fc08: cbz     x19, #0x2c8fd2c                            
02c8fc0c: adrp    x24, #0x6265000                            
02c8fc10: adrp    x23, #0x6265000                            
02c8fc14: mov     x0, x19                                    
02c8fc18: ldr     x24, [x24, #0x4b8]                         T:type6799(k15)
02c8fc1c: ldr     x23, [x23, #0x4c0]                         T:type6805(k15)
02c8fc20: mov     x1, x21                                    
02c8fc24: mov     x2, xzr                                    
02c8fc28: bl      #0x4c348cc                                 GoogleMobileAds.Api.AppOpenAd::add_OnAdClicked
02c8fc2c: ldr     x0, [x22]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c8fc30: bl      #0x2b7104c                                 fn_2b7104c
02c8fc34: ldr     x8, [x20]                                  
02c8fc38: mov     x1, x20                                    
02c8fc3c: mov     x3, xzr                                    
02c8fc40: mov     x21, x0                                    
02c8fc44: ldr     x2, [x8, #0x190]                           
02c8fc48: bl      #0x4d8ddbc                                 System.Action::.ctor
02c8fc4c: mov     x0, x19                                    
02c8fc50: mov     x1, x21                                    
02c8fc54: mov     x2, xzr                                    
02c8fc58: bl      #0x4c34d10                                 GoogleMobileAds.Api.AppOpenAd::remove_OnAdFullScreenContentClosed
02c8fc5c: ldr     x0, [x24]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c8fc60: bl      #0x2b7104c                                 fn_2b7104c
02c8fc64: ldr     x8, [x20]                                  
02c8fc68: mov     x1, x20                                    
02c8fc6c: mov     x3, xzr                                    
02c8fc70: mov     x21, x0                                    
02c8fc74: ldr     x2, [x8, #0x1c0]                           
02c8fc78: bl      #0x453418c                                 fn_453418c
02c8fc7c: mov     x0, x19                                    
02c8fc80: mov     x1, x21                                    
02c8fc84: mov     x2, xzr                                    
02c8fc88: bl      #0x4c34e5c                                 GoogleMobileAds.Api.AppOpenAd::remove_OnAdFullScreenContentFailed
02c8fc8c: ldr     x0, [x22]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c8fc90: bl      #0x2b7104c                                 fn_2b7104c
02c8fc94: ldr     x8, [x20]                                  
02c8fc98: mov     x1, x20                                    
02c8fc9c: mov     x3, xzr                                    
02c8fca0: mov     x21, x0                                    
02c8fca4: ldr     x2, [x8, #0x1a0]                           
02c8fca8: bl      #0x4d8ddbc                                 System.Action::.ctor
02c8fcac: mov     x0, x19                                    
02c8fcb0: mov     x1, x21                                    
02c8fcb4: mov     x2, xzr                                    
02c8fcb8: bl      #0x4c34bd8                                 GoogleMobileAds.Api.AppOpenAd::remove_OnAdFullScreenContentOpened
02c8fcbc: ldr     x0, [x22]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c8fcc0: bl      #0x2b7104c                                 fn_2b7104c
02c8fcc4: ldr     x8, [x20]                                  
02c8fcc8: mov     x1, x20                                    
02c8fccc: mov     x3, xzr                                    
02c8fcd0: mov     x21, x0                                    
02c8fcd4: ldr     x2, [x8, #0x1b0]                           
02c8fcd8: bl      #0x4d8ddbc                                 System.Action::.ctor
02c8fcdc: mov     x0, x19                                    
02c8fce0: mov     x1, x21                                    
02c8fce4: mov     x2, xzr                                    
02c8fce8: bl      #0x4c34a04                                 GoogleMobileAds.Api.AppOpenAd::add_OnAdImpressionRecorded
02c8fcec: ldr     x0, [x23]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c8fcf0: bl      #0x2b7104c                                 fn_2b7104c
02c8fcf4: ldr     x8, [x20]                                  
02c8fcf8: mov     x1, x20                                    
02c8fcfc: mov     x3, xzr                                    
02c8fd00: mov     x21, x0                                    
02c8fd04: ldr     x2, [x8, #0x1d0]                           
02c8fd08: bl      #0x453418c                                 fn_453418c
02c8fd0c: mov     x0, x19                                    
02c8fd10: mov     x1, x21                                    
02c8fd14: mov     x2, xzr                                    
02c8fd18: ldp     x20, x19, [sp, #0x30]                      
02c8fd1c: ldp     x22, x21, [sp, #0x20]                      
02c8fd20: ldp     x24, x23, [sp, #0x10]                      
02c8fd24: ldr     x30, [sp], #0x40                           
02c8fd28: b       #0x4c3476c                                 GoogleMobileAds.Api.AppOpenAd::add_OnAdPaid
02c8fd2c: bl      #0x2b7105c                                 fn_2b7105c
## OnAdFullScreenContentClosed() -> void
---- AppOpenAdAdmobManager::OnAdFullScreenContentClosed 0x2c8fed4
02c8fed4: stp     x30, x19, [sp, #-0x10]!                    
02c8fed8: ldr     x8, [x0, #0x48]                            ._action
02c8fedc: mov     x19, x0                                    
02c8fee0: cbz     x8, #0x2c8fef4                             
02c8fee4: ldr     x9, [x8, #0x18]                            
02c8fee8: ldr     x0, [x8, #0x40]                            
02c8feec: ldr     x1, [x8, #0x28]                            
02c8fef0: blr     x9                                         
02c8fef4: mov     x0, x19                                    
02c8fef8: ldp     x30, x19, [sp], #0x10                      
02c8fefc: b       #0x2c8f8b8                                 AppOpenAdAdmobManager::LoadAd
## OnAdFullScreenContentFailed(GoogleMobileAds.Api.AdError adError) -> void
---- AppOpenAdAdmobManager::OnAdFullScreenContentFailed 0x2c8ff00
02c8ff00: stp     x30, x19, [sp, #-0x10]!                    
02c8ff04: mov     x19, x0                                    
02c8ff08: bl      #0x2c8f588                                 AdmobEventBase::OnAdFullScreenContentFailed
02c8ff0c: ldr     x8, [x19, #0x48]                           ._action
02c8ff10: cbz     x8, #0x2c8ff24                             
02c8ff14: ldr     x9, [x8, #0x18]                            
02c8ff18: ldr     x0, [x8, #0x40]                            
02c8ff1c: ldr     x1, [x8, #0x28]                            
02c8ff20: blr     x9                                         
02c8ff24: mov     x0, x19                                    
02c8ff28: ldp     x30, x19, [sp], #0x10                      
02c8ff2c: b       #0x2c8f8b8                                 AppOpenAdAdmobManager::LoadAd
## OnAdPaid(GoogleMobileAds.Api.AdValue adValue) -> void
---- AppOpenAdAdmobManager::OnAdPaid 0x2c8ff30
02c8ff30: str     x30, [sp, #-0x30]!                         
02c8ff34: stp     x22, x21, [sp, #0x10]                      
02c8ff38: stp     x20, x19, [sp, #0x20]                      
02c8ff3c: adrp    x22, #0x662f000                            
02c8ff40: adrp    x21, #0x6265000                            
02c8ff44: mov     x19, x1                                    
02c8ff48: ldrb    w8, [x22, #0x9c0]                          
02c8ff4c: ldr     x21, [x21, #0x210]                         T:AdFormat
02c8ff50: mov     x20, x0                                    
02c8ff54: tbnz    w8, #0, #0x2c8ff6c                         
02c8ff58: adrp    x0, #0x6265000                             
02c8ff5c: ldr     x0, [x0, #0x210]                           T:AdFormat
02c8ff60: bl      #0x2b70db0                                 fn_2b70db0
02c8ff64: mov     w8, #1                                     
02c8ff68: strb    w8, [x22, #0x9c0]                          
02c8ff6c: ldr     x2, [x20, #0x40]                           ._appOpenAd
02c8ff70: mov     w0, #5                                     
02c8ff74: mov     x1, x19                                    
02c8ff78: mov     w22, #5                                    
02c8ff7c: bl      #0x2c8ffb4                                 AnalyticsManager::LogFirebaseAdmobRevenue
02c8ff80: ldr     x2, [x20, #0x40]                           ._appOpenAd
02c8ff84: ldr     x3, [x20, #0x20]                           
02c8ff88: mov     w0, #5                                     
02c8ff8c: mov     x1, x19                                    
02c8ff90: bl      #0x2c904f0                                 AnalyticsManager::LogAppsflyerAdmobRevenue
02c8ff94: ldr     x0, [x21]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c8ff98: add     x1, sp, #0xc                               
02c8ff9c: str     w22, [sp, #0xc]                            
02c8ffa0: bl      #0x2b70f38                                 fn_2b70f38
02c8ffa4: ldp     x20, x19, [sp, #0x20]                      
02c8ffa8: ldp     x22, x21, [sp, #0x10]                      
02c8ffac: ldr     x30, [sp], #0x30                           
02c8ffb0: ret                                                
## .ctor() -> void
---- AppOpenAdAdmobManager::.ctor 0x2c90840
02c90840: b       #0x2c8f5f8                                 AdmobEventBase::.ctor
## <LoadAd>b__3_0(GoogleMobileAds.Api.AppOpenAd ad, GoogleMobileAds.Api.LoadAdError error) -> void
---- AppOpenAdAdmobManager::<LoadAd>b__3_0 0x2c90844
02c90844: stp     x30, x23, [sp, #-0x30]!                    
02c90848: stp     x22, x21, [sp, #0x10]                      
02c9084c: stp     x20, x19, [sp, #0x20]                      
02c90850: adrp    x22, #0x662f000                            
02c90854: mov     x21, x2                                    
02c90858: mov     x20, x1                                    
02c9085c: ldrb    w8, [x22, #0x9c1]                          
02c90860: mov     x19, x0                                    
02c90864: tbnz    w8, #0, #0x2c908a0                         
02c90868: adrp    x0, #0x6264000                             
02c9086c: ldr     x0, [x0, #0xf90]                           T:System.Action
02c90870: bl      #0x2b70db0                                 fn_2b70db0
02c90874: adrp    x0, #0x6265000                             
02c90878: ldr     x0, [x0, #0x4c8]                           M:AppOpenAdAdmobManager::LoadAd
02c9087c: bl      #0x2b70db0                                 fn_2b70db0
02c90880: adrp    x0, #0x6265000                             
02c90884: ldr     x0, [x0, #0x4d0]                           S:'App open ad failed to load an ad with error : '
02c90888: bl      #0x2b70db0                                 fn_2b70db0
02c9088c: adrp    x0, #0x6265000                             
02c90890: ldr     x0, [x0, #0x4d8]                           S:'Unexpected error: App open ad load event fired with  null ad and null '
02c90894: bl      #0x2b70db0                                 fn_2b70db0
02c90898: mov     w8, #1                                     
02c9089c: strb    w8, [x22, #0x9c1]                          
02c908a0: cbz     x21, #0x2c9091c                            
02c908a4: adrp    x8, #0x6265000                             
02c908a8: adrp    x22, #0x6264000                            
02c908ac: adrp    x23, #0x6265000                            
02c908b0: ldr     x8, [x8, #0x4d0]                           S:'App open ad failed to load an ad with error : '
02c908b4: ldr     x22, [x22, #0xf90]                         T:System.Action
02c908b8: ldr     x9, [x21]                                  
02c908bc: ldr     x23, [x23, #0x4c8]                         M:AppOpenAdAdmobManager::LoadAd
02c908c0: mov     x0, x21                                    
02c908c4: ldr     x20, [x8]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c908c8: ldp     x8, x1, [x9, #0x168]                       
02c908cc: blr     x8                                         
02c908d0: mov     x1, x0                                     
02c908d4: mov     x0, x20                                    
02c908d8: mov     x2, xzr                                    
02c908dc: bl      #0x4c9c514                                 System.String::Concat
02c908e0: mov     x1, xzr                                    
02c908e4: bl      #0x2ca09f8                                 WLog::LogError
02c908e8: ldr     x0, [x22]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c908ec: bl      #0x2b7104c                                 fn_2b7104c
02c908f0: ldr     x2, [x23]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c908f4: mov     x1, x19                                    
02c908f8: mov     x3, xzr                                    
02c908fc: mov     x20, x0                                    
02c90900: bl      #0x4d8ddbc                                 System.Action::.ctor
02c90904: mov     x0, x19                                    
02c90908: mov     x1, x20                                    
02c9090c: ldp     x20, x19, [sp, #0x20]                      
02c90910: ldp     x22, x21, [sp, #0x10]                      
02c90914: ldp     x30, x23, [sp], #0x30                      
02c90918: b       #0x2c8f468                                 AdmobEventBase::TryLoadAd
02c9091c: cbz     x20, #0x2c90948                            
02c90920: mov     x0, x19                                    
02c90924: mov     x1, x20                                    
02c90928: str     x20, [x0, #0x40]!                          ._appOpenAd
02c9092c: bl      #0x2b70d54                                 fn_2b70d54
02c90930: mov     x0, x19                                    
02c90934: mov     x1, x20                                    
02c90938: ldp     x20, x19, [sp, #0x20]                      
02c9093c: ldp     x22, x21, [sp, #0x10]                      
02c90940: ldp     x30, x23, [sp], #0x30                      
02c90944: b       #0x2c8fd30                                 AppOpenAdAdmobManager::RegisterEventHandlers
02c90948: adrp    x8, #0x6265000                             
02c9094c: mov     x1, xzr                                    
02c90950: ldr     x8, [x8, #0x4d8]                           S:'Unexpected error: App open ad load event fired with  null ad and null '
02c90954: ldp     x20, x19, [sp, #0x20]                      
02c90958: ldp     x22, x21, [sp, #0x10]                      
02c9095c: ldr     x0, [x8]                                   M:AdsManager::<OnApplicationPause>b__26_0
02c90960: ldp     x30, x23, [sp], #0x30                      
02c90964: b       #0x2ca09f8                                 WLog::LogError
