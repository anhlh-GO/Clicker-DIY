#### CLASS Clicker.TutorialSelectKeycapBase parent= UnityEngine.MonoBehaviour
#   field _tfPreviewKeycap               UnityEngine.Transform                              off=0x20 attr=1 SerializeField
#   field _srPreviewKeycap               UnityEngine.SpriteRenderer                         off=0x28 attr=1 SerializeField
#   field _previewSprite                 System.Collections.Generic.List`1<UnityEngine.Sprite> off=0x30 attr=1 SerializeField
#   field _currentIndex                  int                                                off=0x38 attr=1 
## Awake() -> void
---- Clicker.TutorialSelectKeycapBase::Awake 0x2d74b6c
02d74b6c: ret                                                
## ShowWithAnim() -> void
---- Clicker.TutorialSelectKeycapBase::ShowWithAnim 0x2d74b70
02d74b70: stp     x30, x19, [sp, #-0x10]!                    
02d74b74: mov     x1, xzr                                    
02d74b78: mov     x19, x0                                    
02d74b7c: bl      #0x5b339ec                                 UnityEngine.Component::get_gameObject
02d74b80: cbz     x0, #0x2d74b9c                             
02d74b84: mov     w1, #1                                     
02d74b88: mov     x2, xzr                                    
02d74b8c: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d74b90: mov     x0, x19                                    
02d74b94: ldp     x30, x19, [sp], #0x10                      
02d74b98: b       #0x2d74ba0                                 Clicker.TutorialSelectKeycapBase::Show1StepTutorial
02d74b9c: bl      #0x2b7105c                                 fn_2b7105c
## Show1StepTutorial() -> void
---- Clicker.TutorialSelectKeycapBase::Show1StepTutorial 0x2d74ba0
02d74ba0: str     x30, [sp, #-0x40]!                         
02d74ba4: stp     x24, x23, [sp, #0x10]                      
02d74ba8: stp     x22, x21, [sp, #0x20]                      
02d74bac: stp     x20, x19, [sp, #0x30]                      
02d74bb0: adrp    x23, #0x6266000                            
02d74bb4: adrp    x24, #0x6630000                            
02d74bb8: adrp    x20, #0x6264000                            
02d74bbc: adrp    x21, #0x626c000                            
02d74bc0: adrp    x22, #0x6266000                            
02d74bc4: ldr     x23, [x23, #0xe08]                         MS:DG.Tweening.TweenSettingsExtensions::SetDelay
02d74bc8: ldr     x20, [x20, #0xe8]                          T:DG.Tweening.TweenCallback
02d74bcc: ldrb    w8, [x24, #0x3ce]                          
02d74bd0: ldr     x21, [x21, #0x798]                         M:Clicker.TutorialSelectKeycapBase::<Show1StepTutorial>b__6_0
02d74bd4: ldr     x22, [x22, #0x928]                         MS:DG.Tweening.TweenSettingsExtensions::OnComplete
02d74bd8: mov     x19, x0                                    
02d74bdc: tbnz    w8, #0, #0x2d74c18                         
02d74be0: adrp    x0, #0x626c000                             
02d74be4: ldr     x0, [x0, #0x798]                           M:Clicker.TutorialSelectKeycapBase::<Show1StepTutorial>b__6_0
02d74be8: bl      #0x2b70db0                                 fn_2b70db0
02d74bec: adrp    x0, #0x6264000                             
02d74bf0: ldr     x0, [x0, #0xe8]                            T:DG.Tweening.TweenCallback
02d74bf4: bl      #0x2b70db0                                 fn_2b70db0
02d74bf8: adrp    x0, #0x6266000                             
02d74bfc: ldr     x0, [x0, #0x928]                           MS:DG.Tweening.TweenSettingsExtensions::OnComplete
02d74c00: bl      #0x2b70db0                                 fn_2b70db0
02d74c04: adrp    x0, #0x6266000                             
02d74c08: ldr     x0, [x0, #0xe08]                           MS:DG.Tweening.TweenSettingsExtensions::SetDelay
02d74c0c: bl      #0x2b70db0                                 fn_2b70db0
02d74c10: mov     w8, #1                                     
02d74c14: strb    w8, [x24, #0x3ce]                          
02d74c18: ldr     x0, [x19, #0x20]                           ._tfPreviewKeycap
02d74c1c: mov     w1, wzr                                    
02d74c20: mov     x2, xzr                                    
02d74c24: bl      #0x2d9d5d0                                 DG.Tweening.ShortcutExtensions::DOKill
02d74c28: movi    d0, #0000000000000000                      
02d74c2c: adrp    x8, #0x1084000                             
02d74c30: ldr     x0, [x19, #0x20]                           ._tfPreviewKeycap
02d74c34: ldr     s1, [x8, #0xeec]                           [1084eec]=457ff0003dcccccd f=0.1,4095
02d74c38: mov     x1, xzr                                    
02d74c3c: bl      #0x2d98c98                                 DG.Tweening.ShortcutExtensions::DOScale
02d74c40: fmov    s0, #1.50000000                            
02d74c44: ldr     x1, [x23]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d74c48: bl      #0x336f7fc                                 fn_336f7fc
02d74c4c: ldr     x8, [x20]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d74c50: mov     x20, x0                                    
02d74c54: mov     x0, x8                                     
02d74c58: bl      #0x2b7104c                                 fn_2b7104c
02d74c5c: ldr     x2, [x21]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d74c60: mov     x1, x19                                    
02d74c64: mov     x3, xzr                                    
02d74c68: mov     x21, x0                                    
02d74c6c: bl      #0x2d89dc4                                 DG.Tweening.TweenCallback::.ctor
02d74c70: ldr     x2, [x22]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d74c74: mov     x0, x20                                    
02d74c78: mov     x1, x21                                    
02d74c7c: ldp     x20, x19, [sp, #0x30]                      
02d74c80: ldp     x22, x21, [sp, #0x20]                      
02d74c84: ldp     x24, x23, [sp, #0x10]                      
02d74c88: ldr     x30, [sp], #0x40                           
02d74c8c: b       #0x336f26c                                 
## HideTutorial() -> void
---- Clicker.TutorialSelectKeycapBase::HideTutorial 0x2d74c90
02d74c90: stp     x30, x19, [sp, #-0x10]!                    
02d74c94: mov     x19, x0                                    
02d74c98: ldr     x0, [x0, #0x20]                            ._tfPreviewKeycap
02d74c9c: mov     w1, wzr                                    
02d74ca0: mov     x2, xzr                                    
02d74ca4: bl      #0x2d9d5d0                                 DG.Tweening.ShortcutExtensions::DOKill
02d74ca8: mov     x0, x19                                    
02d74cac: mov     x1, xzr                                    
02d74cb0: bl      #0x5b339ec                                 UnityEngine.Component::get_gameObject
02d74cb4: cbz     x0, #0x2d74cc8                             
02d74cb8: mov     w1, wzr                                    
02d74cbc: mov     x2, xzr                                    
02d74cc0: ldp     x30, x19, [sp], #0x10                      
02d74cc4: b       #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d74cc8: bl      #0x2b7105c                                 fn_2b7105c
## .ctor() -> void
---- Clicker.TutorialSelectKeycapBase::.ctor 0x2d74ccc
02d74ccc: mov     x1, xzr                                    
02d74cd0: b       #0x5b397b0                                 UnityEngine.MonoBehaviour::.ctor
## <Show1StepTutorial>b__6_0() -> void
---- Clicker.TutorialSelectKeycapBase::<Show1StepTutorial>b__6_0 0x2d74cd4
02d74cd4: stp     x30, x23, [sp, #-0x30]!                    
02d74cd8: stp     x22, x21, [sp, #0x10]                      
02d74cdc: stp     x20, x19, [sp, #0x20]                      
02d74ce0: adrp    x20, #0x6630000                            
02d74ce4: mov     x19, x0                                    
02d74ce8: ldrb    w8, [x20, #0x3cf]                          
02d74cec: tbnz    w8, #0, #0x2d74d40                         
02d74cf0: adrp    x0, #0x6266000                             
02d74cf4: ldr     x0, [x0, #0xc30]                           MS:System.Collections.Generic.List`1::get_Count
02d74cf8: bl      #0x2b70db0                                 fn_2b70db0
02d74cfc: adrp    x0, #0x6266000                             
02d74d00: ldr     x0, [x0, #0xc38]                           MS:System.Collections.Generic.List`1::get_Item
02d74d04: bl      #0x2b70db0                                 fn_2b70db0
02d74d08: adrp    x0, #0x626c000                             
02d74d0c: ldr     x0, [x0, #0x7a0]                           M:Clicker.TutorialSelectKeycapBase::Show1StepTutorial
02d74d10: bl      #0x2b70db0                                 fn_2b70db0
02d74d14: adrp    x0, #0x6264000                             
02d74d18: ldr     x0, [x0, #0xe8]                            T:DG.Tweening.TweenCallback
02d74d1c: bl      #0x2b70db0                                 fn_2b70db0
02d74d20: adrp    x0, #0x6266000                             
02d74d24: ldr     x0, [x0, #0x928]                           MS:DG.Tweening.TweenSettingsExtensions::OnComplete
02d74d28: bl      #0x2b70db0                                 fn_2b70db0
02d74d2c: adrp    x0, #0x6266000                             
02d74d30: ldr     x0, [x0, #0x880]                           MS:DG.Tweening.TweenSettingsExtensions::SetEase
02d74d34: bl      #0x2b70db0                                 fn_2b70db0
02d74d38: mov     w8, #1                                     
02d74d3c: strb    w8, [x20, #0x3cf]                          
02d74d40: ldr     x0, [x19, #0x30]                           ._previewSprite
02d74d44: cbz     x0, #0x2d74e1c                             
02d74d48: adrp    x8, #0x6266000                             
02d74d4c: ldr     x8, [x8, #0xc38]                           MS:System.Collections.Generic.List`1::get_Item
02d74d50: ldr     w1, [x19, #0x38]                           ._currentIndex
02d74d54: ldr     x20, [x19, #0x28]                          ._srPreviewKeycap
02d74d58: ldr     x2, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d74d5c: bl      #0x35a8f3c                                 fn_35a8f3c
02d74d60: cbz     x20, #0x2d74e1c                            
02d74d64: mov     x1, x0                                     
02d74d68: mov     x0, x20                                    
02d74d6c: mov     x2, xzr                                    
02d74d70: bl      #0x5ae6dcc                                 UnityEngine.SpriteRenderer::set_sprite
02d74d74: ldr     w8, [x19, #0x38]                           ._currentIndex
02d74d78: ldr     x9, [x19, #0x30]                           ._previewSprite
02d74d7c: add     w8, w8, #1                                 
02d74d80: str     w8, [x19, #0x38]                           ._currentIndex
02d74d84: cbz     x9, #0x2d74e1c                             
02d74d88: adrp    x23, #0x6266000                            
02d74d8c: adrp    x20, #0x6264000                            
02d74d90: adrp    x21, #0x626c000                            
02d74d94: ldr     x23, [x23, #0x880]                         MS:DG.Tweening.TweenSettingsExtensions::SetEase
02d74d98: ldr     x20, [x20, #0xe8]                          T:DG.Tweening.TweenCallback
02d74d9c: ldr     w9, [x9, #0x18]                            
02d74da0: adrp    x22, #0x6266000                            
02d74da4: ldr     x21, [x21, #0x7a0]                         M:Clicker.TutorialSelectKeycapBase::Show1StepTutorial
02d74da8: ldr     x22, [x22, #0x928]                         MS:DG.Tweening.TweenSettingsExtensions::OnComplete
02d74dac: cmp     w8, w9                                     
02d74db0: b.lt    #0x2d74db8                                 
02d74db4: str     wzr, [x19, #0x38]                          ._currentIndex
02d74db8: adrp    x8, #0x1084000                             
02d74dbc: fmov    s0, #1.00000000                            
02d74dc0: ldr     x0, [x19, #0x20]                           ._tfPreviewKeycap
02d74dc4: ldr     s1, [x8, #0xf10]                           [1084f10]=4110bc863e99999a f=0.3,9.04603
02d74dc8: mov     x1, xzr                                    
02d74dcc: bl      #0x2d98c98                                 DG.Tweening.ShortcutExtensions::DOScale
02d74dd0: ldr     x2, [x23]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d74dd4: mov     w1, #0x1b                                  
02d74dd8: bl      #0x336fa0c                                 fn_336fa0c
02d74ddc: ldr     x8, [x20]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d74de0: mov     x20, x0                                    
02d74de4: mov     x0, x8                                     
02d74de8: bl      #0x2b7104c                                 fn_2b7104c
02d74dec: ldr     x2, [x21]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d74df0: mov     x1, x19                                    
02d74df4: mov     x3, xzr                                    
02d74df8: mov     x21, x0                                    
02d74dfc: bl      #0x2d89dc4                                 DG.Tweening.TweenCallback::.ctor
02d74e00: ldr     x2, [x22]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d74e04: mov     x0, x20                                    
02d74e08: mov     x1, x21                                    
02d74e0c: ldp     x20, x19, [sp, #0x20]                      
02d74e10: ldp     x22, x21, [sp, #0x10]                      
02d74e14: ldp     x30, x23, [sp], #0x30                      
02d74e18: b       #0x336f26c                                 
02d74e1c: bl      #0x2b7105c                                 fn_2b7105c
