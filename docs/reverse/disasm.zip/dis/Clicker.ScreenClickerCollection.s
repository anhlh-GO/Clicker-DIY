#### CLASS Clicker.ScreenClickerCollection parent= ScreenBase
#   field _btnHome                       UnityEngine.UI.Button                              off=0x38 attr=1 SerializeField
#   field _btnBack                       UnityEngine.UI.Button                              off=0x40 attr=1 SerializeField
#   field _btnRemoveKeycap               UnityEngine.UI.Button                              off=0x48 attr=1 SerializeField
#   field _goContentCollection           UnityEngine.GameObject                             off=0x50 attr=1 SerializeField
#   field _goContentPreviewCollection    UnityEngine.GameObject                             off=0x58 attr=1 SerializeField
#   field _petAtHome                     UnityEngine.GameObject                             off=0x60 attr=1 SerializeField
#   field _handTutorial                  UnityEngine.GameObject                             off=0x68 attr=1 SerializeField
#   field _drag2D                        AxisDrag2D                                         off=0x70 attr=1 SerializeField
#   field _collectionShelfs              System.Collections.Generic.List`1<Clicker.CollectionShelf> off=0x78 attr=1 SerializeField
#   field _collectionItems               System.Collections.Generic.List`1<Clicker.CollectionKeycapItem> off=0x80 attr=1 SerializeField
#   field _showingShelfCount             int                                                off=0x88 attr=1 SerializeField
#   field _tfInspectPos                  UnityEngine.Transform                              off=0x90 attr=1 SerializeField
#   field _inspectIndex                  int                                                off=0x98 attr=1 SerializeField,ReadOnlyAttribute
#   field _inputSystemUIInputModule      UnityEngine.InputSystem.UI.InputSystemUIInputModule off=0xa0 attr=1 HeaderAttribute,SerializeField
#   field _inspectKeycap                 Clicker.BaseKeycapObject                           off=0xa8 attr=1 
#   field _inspectItem                   Clicker.CollectionKeycapItem                       off=0xb0 attr=1 
#   field _minShelfCount                 int                                                off=0x0 attr=8051 
## OnInit(UIManager uiManager) -> void
---- Clicker.ScreenClickerCollection::OnInit 0x2d5bf60
02d5bf60: str     x30, [sp, #-0x30]!                         
02d5bf64: stp     x22, x21, [sp, #0x10]                      
02d5bf68: stp     x20, x19, [sp, #0x20]                      
02d5bf6c: adrp    x21, #0x6630000                            
02d5bf70: mov     x20, x1                                    
02d5bf74: mov     x19, x0                                    
02d5bf78: ldrb    w8, [x21, #0x2cb]                          
02d5bf7c: tbnz    w8, #0, #0x2d5bfe8                         
02d5bf80: adrp    x0, #0x626b000                             
02d5bf84: ldr     x0, [x0, #0xcd0]                           T:type53122(k15)
02d5bf88: bl      #0x2b70db0                                 fn_2b70db0
02d5bf8c: adrp    x0, #0x626b000                             
02d5bf90: ldr     x0, [x0, #0xcd8]                           MS:System.Collections.Generic.List`1::Clear
02d5bf94: bl      #0x2b70db0                                 fn_2b70db0
02d5bf98: adrp    x0, #0x626b000                             
02d5bf9c: ldr     x0, [x0, #0xce0]                           MS:System.Collections.Generic.List`1::ForEach
02d5bfa0: bl      #0x2b70db0                                 fn_2b70db0
02d5bfa4: adrp    x0, #0x626b000                             
02d5bfa8: ldr     x0, [x0, #0xce8]                           M:Clicker.ScreenClickerCollection::OnBtnBackClick
02d5bfac: bl      #0x2b70db0                                 fn_2b70db0
02d5bfb0: adrp    x0, #0x626b000                             
02d5bfb4: ldr     x0, [x0, #0xcf0]                           M:Clicker.ScreenClickerCollection::OnBtnHomeClick
02d5bfb8: bl      #0x2b70db0                                 fn_2b70db0
02d5bfbc: adrp    x0, #0x626b000                             
02d5bfc0: ldr     x0, [x0, #0xcf8]                           M:Clicker.ScreenClickerCollection::OnBtnRemoveKeycapClick
02d5bfc4: bl      #0x2b70db0                                 fn_2b70db0
02d5bfc8: adrp    x0, #0x626b000                             
02d5bfcc: ldr     x0, [x0, #0xd00]                           M:Clicker.ScreenClickerCollection::<OnInit>b__17_0
02d5bfd0: bl      #0x2b70db0                                 fn_2b70db0
02d5bfd4: adrp    x0, #0x6265000                             
02d5bfd8: ldr     x0, [x0, #0x3f0]                           T:UnityEngine.Events.UnityAction
02d5bfdc: bl      #0x2b70db0                                 fn_2b70db0
02d5bfe0: mov     w8, #1                                     
02d5bfe4: strb    w8, [x21, #0x2cb]                          
02d5bfe8: mov     x0, x19                                    
02d5bfec: mov     x1, x20                                    
02d5bff0: mov     x2, xzr                                    
02d5bff4: bl      #0x2cdd3c4                                 UIBase::OnInit
02d5bff8: ldr     x8, [x19, #0x38]                           ._btnHome
02d5bffc: cbz     x8, #0x2d5c1c8                             
02d5c000: ldr     x0, [x8, #0x100]                           
02d5c004: cbz     x0, #0x2d5c1c8                             
02d5c008: mov     x1, xzr                                    
02d5c00c: bl      #0x5b4ce48                                 UnityEngine.Events.UnityEventBase::RemoveAllListeners
02d5c010: ldr     x8, [x19, #0x38]                           ._btnHome
02d5c014: cbz     x8, #0x2d5c1c8                             
02d5c018: adrp    x22, #0x6265000                            
02d5c01c: adrp    x21, #0x626b000                            
02d5c020: ldr     x22, [x22, #0x3f0]                         T:UnityEngine.Events.UnityAction
02d5c024: ldr     x21, [x21, #0xcf0]                         M:Clicker.ScreenClickerCollection::OnBtnHomeClick
02d5c028: ldr     x20, [x8, #0x100]                          
02d5c02c: ldr     x0, [x22]                                  M:AdsManager::<OnApplicationPause>b__26_0
02d5c030: bl      #0x2b7104c                                 fn_2b7104c
02d5c034: ldr     x2, [x21]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d5c038: mov     x1, x19                                    
02d5c03c: mov     x3, xzr                                    
02d5c040: mov     x21, x0                                    
02d5c044: bl      #0x5b4cf98                                 UnityEngine.Events.UnityAction::.ctor
02d5c048: cbz     x20, #0x2d5c1c8                            
02d5c04c: mov     x0, x20                                    
02d5c050: mov     x1, x21                                    
02d5c054: mov     x2, xzr                                    
02d5c058: bl      #0x5b4d0ac                                 UnityEngine.Events.UnityEvent::AddListener
02d5c05c: ldr     x8, [x19, #0x40]                           ._btnBack
02d5c060: cbz     x8, #0x2d5c1c8                             
02d5c064: ldr     x0, [x8, #0x100]                           
02d5c068: cbz     x0, #0x2d5c1c8                             
02d5c06c: mov     x1, xzr                                    
02d5c070: bl      #0x5b4ce48                                 UnityEngine.Events.UnityEventBase::RemoveAllListeners
02d5c074: ldr     x8, [x19, #0x40]                           ._btnBack
02d5c078: cbz     x8, #0x2d5c1c8                             
02d5c07c: adrp    x21, #0x626b000                            
02d5c080: ldr     x21, [x21, #0xce8]                         M:Clicker.ScreenClickerCollection::OnBtnBackClick
02d5c084: ldr     x0, [x22]                                  M:AdsManager::<OnApplicationPause>b__26_0
02d5c088: ldr     x20, [x8, #0x100]                          
02d5c08c: bl      #0x2b7104c                                 fn_2b7104c
02d5c090: ldr     x2, [x21]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d5c094: mov     x1, x19                                    
02d5c098: mov     x3, xzr                                    
02d5c09c: mov     x21, x0                                    
02d5c0a0: bl      #0x5b4cf98                                 UnityEngine.Events.UnityAction::.ctor
02d5c0a4: cbz     x20, #0x2d5c1c8                            
02d5c0a8: mov     x0, x20                                    
02d5c0ac: mov     x1, x21                                    
02d5c0b0: mov     x2, xzr                                    
02d5c0b4: bl      #0x5b4d0ac                                 UnityEngine.Events.UnityEvent::AddListener
02d5c0b8: ldr     x8, [x19, #0x48]                           ._btnRemoveKeycap
02d5c0bc: cbz     x8, #0x2d5c1c8                             
02d5c0c0: ldr     x0, [x8, #0x100]                           
02d5c0c4: cbz     x0, #0x2d5c1c8                             
02d5c0c8: mov     x1, xzr                                    
02d5c0cc: bl      #0x5b4ce48                                 UnityEngine.Events.UnityEventBase::RemoveAllListeners
02d5c0d0: ldr     x8, [x19, #0x48]                           ._btnRemoveKeycap
02d5c0d4: cbz     x8, #0x2d5c1c8                             
02d5c0d8: adrp    x21, #0x626b000                            
02d5c0dc: ldr     x21, [x21, #0xcf8]                         M:Clicker.ScreenClickerCollection::OnBtnRemoveKeycapClick
02d5c0e0: ldr     x0, [x22]                                  M:AdsManager::<OnApplicationPause>b__26_0
02d5c0e4: ldr     x20, [x8, #0x100]                          
02d5c0e8: bl      #0x2b7104c                                 fn_2b7104c
02d5c0ec: ldr     x2, [x21]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d5c0f0: mov     x1, x19                                    
02d5c0f4: mov     x3, xzr                                    
02d5c0f8: mov     x21, x0                                    
02d5c0fc: bl      #0x5b4cf98                                 UnityEngine.Events.UnityAction::.ctor
02d5c100: cbz     x20, #0x2d5c1c8                            
02d5c104: mov     x0, x20                                    
02d5c108: mov     x1, x21                                    
02d5c10c: mov     x2, xzr                                    
02d5c110: bl      #0x5b4d0ac                                 UnityEngine.Events.UnityEvent::AddListener
02d5c114: ldr     x0, [x19, #0x50]                           ._goContentCollection
02d5c118: cbz     x0, #0x2d5c1c8                             
02d5c11c: mov     w1, wzr                                    
02d5c120: mov     x2, xzr                                    
02d5c124: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d5c128: ldr     x0, [x19, #0x58]                           ._goContentPreviewCollection
02d5c12c: cbz     x0, #0x2d5c1c8                             
02d5c130: mov     w1, wzr                                    
02d5c134: mov     x2, xzr                                    
02d5c138: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d5c13c: ldr     x8, [x19, #0x80]                           ._collectionItems
02d5c140: cbz     x8, #0x2d5c1c8                             
02d5c144: ldp     w2, w9, [x8, #0x18]                        
02d5c148: adrp    x22, #0x626b000                            
02d5c14c: adrp    x21, #0x626b000                            
02d5c150: ldr     x22, [x22, #0xcd0]                         T:type53122(k15)
02d5c154: ldr     x21, [x21, #0xd00]                         M:Clicker.ScreenClickerCollection::<OnInit>b__17_0
02d5c158: add     w9, w9, #1                                 
02d5c15c: cmp     w2, #1                                     
02d5c160: stp     wzr, w9, [x8, #0x18]                       
02d5c164: b.lt    #0x2d5c178                                 
02d5c168: ldr     x0, [x8, #0x10]                            
02d5c16c: mov     w1, wzr                                    
02d5c170: mov     x3, xzr                                    
02d5c174: bl      #0x4e3494c                                 System.Array::Clear
02d5c178: ldr     x0, [x22]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d5c17c: ldr     x20, [x19, #0x78]                          ._collectionShelfs
02d5c180: bl      #0x2b7104c                                 fn_2b7104c
02d5c184: ldr     x2, [x21]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d5c188: mov     x1, x19                                    
02d5c18c: mov     x3, xzr                                    
02d5c190: mov     x21, x0                                    
02d5c194: bl      #0x453418c                                 fn_453418c
02d5c198: cbz     x20, #0x2d5c1c8                            
02d5c19c: adrp    x8, #0x626b000                             
02d5c1a0: mov     x0, x20                                    
02d5c1a4: mov     x1, x21                                    
02d5c1a8: ldr     x8, [x8, #0xce0]                           MS:System.Collections.Generic.List`1::ForEach
02d5c1ac: ldr     x2, [x8]                                   T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d5c1b0: bl      #0x35a9ce4                                 fn_35a9ce4
02d5c1b4: mov     x0, x19                                    
02d5c1b8: ldp     x20, x19, [sp, #0x20]                      
02d5c1bc: ldp     x22, x21, [sp, #0x10]                      
02d5c1c0: ldr     x30, [sp], #0x30                           
02d5c1c4: b       #0x2d5c1cc                                 Clicker.ScreenClickerCollection::LoadSavedData
02d5c1c8: bl      #0x2b7105c                                 fn_2b7105c
## UpdateShelf() -> void
---- Clicker.ScreenClickerCollection::UpdateShelf 0x2d5c44c
02d5c44c: str     x30, [sp, #-0x20]!                         
02d5c450: stp     x20, x19, [sp, #0x10]                      
02d5c454: adrp    x20, #0x6630000                            
02d5c458: mov     x19, x0                                    
02d5c45c: ldrb    w8, [x20, #0x2cc]                          
02d5c460: tbnz    w8, #0, #0x2d5c484                         
02d5c464: adrp    x0, #0x626b000                             
02d5c468: ldr     x0, [x0, #0xd08]                           MS:System.Collections.Generic.List`1::get_Count
02d5c46c: bl      #0x2b70db0                                 fn_2b70db0
02d5c470: adrp    x0, #0x626b000                             
02d5c474: ldr     x0, [x0, #0xd20]                           MS:System.Collections.Generic.List`1::get_Item
02d5c478: bl      #0x2b70db0                                 fn_2b70db0
02d5c47c: mov     w8, #1                                     
02d5c480: strb    w8, [x20, #0x2cc]                          
02d5c484: ldr     x8, [x19, #0x78]                           ._collectionShelfs
02d5c488: cbz     x8, #0x2d5c4f0                             
02d5c48c: ldr     w8, [x8, #0x18]                            
02d5c490: cbz     w8, #0x2d5c4f0                             
02d5c494: ldr     w9, [x19, #0x88]                           ._showingShelfCount
02d5c498: sub     w8, w8, #1                                 
02d5c49c: ldr     x0, [x19, #0x70]                           ._drag2D
02d5c4a0: cmp     w9, w8                                     
02d5c4a4: csel    w8, w9, w8, lt                             
02d5c4a8: cmp     w9, #0                                     
02d5c4ac: csel    w8, wzr, w8, lt                            
02d5c4b0: str     w8, [x19, #0x88]                           ._showingShelfCount
02d5c4b4: cbz     x0, #0x2d5c4fc                             
02d5c4b8: mov     x1, xzr                                    
02d5c4bc: bl      #0x2caeae0                                 AxisDrag2D::ScrollToTop
02d5c4c0: ldr     x0, [x19, #0x78]                           ._collectionShelfs
02d5c4c4: cbz     x0, #0x2d5c4fc                             
02d5c4c8: adrp    x8, #0x626b000                             
02d5c4cc: ldr     x8, [x8, #0xd20]                           MS:System.Collections.Generic.List`1::get_Item
02d5c4d0: ldr     w1, [x19, #0x88]                           ._showingShelfCount
02d5c4d4: ldr     x20, [x19, #0x70]                          ._drag2D
02d5c4d8: ldr     x2, [x8]                                   T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d5c4dc: bl      #0x35a8f3c                                 fn_35a8f3c
02d5c4e0: cbz     x0, #0x2d5c4fc                             
02d5c4e4: cbz     x20, #0x2d5c4fc                            
02d5c4e8: ldr     s0, [x0, #0x30]                            MS:System.Collections.Generic.List`1::IndexOf
02d5c4ec: str     s0, [x20, #0x34]                           
02d5c4f0: ldp     x20, x19, [sp, #0x10]                      
02d5c4f4: ldr     x30, [sp], #0x20                           
02d5c4f8: ret                                                
02d5c4fc: bl      #0x2b7105c                                 fn_2b7105c
## SetMultipleInput(bool isEnable) -> void
---- Clicker.ScreenClickerCollection::SetMultipleInput 0x2d5c500
02d5c500: str     x30, [sp, #-0x30]!                         
02d5c504: stp     x22, x21, [sp, #0x10]                      
02d5c508: stp     x20, x19, [sp, #0x20]                      
02d5c50c: adrp    x22, #0x6630000                            
02d5c510: adrp    x21, #0x6263000                            
02d5c514: mov     w19, w1                                    
02d5c518: ldrb    w8, [x22, #0x2cd]                          
02d5c51c: ldr     x21, [x21, #0x918]                         T:UnityEngine.Object
02d5c520: mov     x20, x0                                    
02d5c524: tbnz    w8, #0, #0x2d5c53c                         
02d5c528: adrp    x0, #0x6263000                             
02d5c52c: ldr     x0, [x0, #0x918]                           T:UnityEngine.Object
02d5c530: bl      #0x2b70db0                                 fn_2b70db0
02d5c534: mov     w8, #1                                     
02d5c538: strb    w8, [x22, #0x2cd]                          
02d5c53c: ldr     x0, [x21]                                  &2c5bbd4(=a9bd7bfdd503233f)
02d5c540: ldr     x21, [x20, #0xa0]                          ._inputSystemUIInputModule
02d5c544: ldr     w8, [x0, #0xe4]                            [62630e4]=0 f=0,0
02d5c548: cbnz    w8, #0x2d5c550                             
02d5c54c: bl      #0x2b70f30                                 fn_2b70f30
02d5c550: mov     x0, x21                                    
02d5c554: mov     x1, xzr                                    
02d5c558: mov     x2, xzr                                    
02d5c55c: bl      #0x5b3666c                                 UnityEngine.Object::op_Inequality
02d5c560: tbz     w0, #0, #0x2d5c578                         
02d5c564: ldr     x8, [x20, #0xa0]                           ._inputSystemUIInputModule
02d5c568: cbz     x8, #0x2d5c588                             
02d5c56c: mov     w9, #1                                     
02d5c570: bic     w9, w9, w19                                
02d5c574: str     w9, [x8, #0xcc]                            
02d5c578: ldp     x20, x19, [sp, #0x20]                      
02d5c57c: ldp     x22, x21, [sp, #0x10]                      
02d5c580: ldr     x30, [sp], #0x30                           
02d5c584: ret                                                
02d5c588: bl      #0x2b7105c                                 fn_2b7105c
## LoadSavedData() -> void
---- Clicker.ScreenClickerCollection::LoadSavedData 0x2d5c1cc
02d5c1cc: stp     x30, x27, [sp, #-0x50]!                    
02d5c1d0: stp     x26, x25, [sp, #0x10]                      
02d5c1d4: stp     x24, x23, [sp, #0x20]                      
02d5c1d8: stp     x22, x21, [sp, #0x30]                      
02d5c1dc: stp     x20, x19, [sp, #0x40]                      
02d5c1e0: adrp    x20, #0x6630000                            
02d5c1e4: adrp    x21, #0x6266000                            
02d5c1e8: mov     x19, x0                                    
02d5c1ec: ldrb    w8, [x20, #0x2ce]                          
02d5c1f0: ldr     x21, [x21, #0x658]                         MS:MonoSingleton`1::get_Instance
02d5c1f4: tbnz    w8, #0, #0x2d5c254                         
02d5c1f8: adrp    x0, #0x6269000                             
02d5c1fc: ldr     x0, [x0, #0x3f8]                           MS:DataManager::GetData
02d5c200: bl      #0x2b70db0                                 fn_2b70db0
02d5c204: adrp    x0, #0x6266000                             
02d5c208: ldr     x0, [x0, #0x6a0]                           MS:System.Collections.Generic.List`1::get_Count
02d5c20c: bl      #0x2b70db0                                 fn_2b70db0
02d5c210: adrp    x0, #0x626b000                             
02d5c214: ldr     x0, [x0, #0xd08]                           MS:System.Collections.Generic.List`1::get_Count
02d5c218: bl      #0x2b70db0                                 fn_2b70db0
02d5c21c: adrp    x0, #0x626b000                             
02d5c220: ldr     x0, [x0, #0xd10]                           MS:System.Collections.Generic.List`1::get_Count
02d5c224: bl      #0x2b70db0                                 fn_2b70db0
02d5c228: adrp    x0, #0x626b000                             
02d5c22c: ldr     x0, [x0, #0xd18]                           MS:System.Collections.Generic.List`1::get_Item
02d5c230: bl      #0x2b70db0                                 fn_2b70db0
02d5c234: adrp    x0, #0x6269000                             
02d5c238: ldr     x0, [x0, #0x1e8]                           MS:System.Collections.Generic.List`1::get_Item
02d5c23c: bl      #0x2b70db0                                 fn_2b70db0
02d5c240: adrp    x0, #0x6266000                             
02d5c244: ldr     x0, [x0, #0x658]                           MS:MonoSingleton`1::get_Instance
02d5c248: bl      #0x2b70db0                                 fn_2b70db0
02d5c24c: mov     w8, #1                                     
02d5c250: strb    w8, [x20, #0x2ce]                          
02d5c254: ldr     x0, [x21]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d5c258: bl      #0x3769600                                 fn_3769600
02d5c25c: cbz     x0, #0x2d5c430                             
02d5c260: adrp    x8, #0x6269000                             
02d5c264: ldr     x8, [x8, #0x3f8]                           MS:DataManager::GetData
02d5c268: ldr     x1, [x8]                                   T:Trading.TradingSession/<>c__DisplayClass56_0
02d5c26c: bl      #0x3168dd0                                 fn_3168dd0
02d5c270: cbz     x0, #0x2d5c430                             
02d5c274: ldr     x8, [x0, #0x20]                            S:'inter_ad_capping_time'
02d5c278: mov     x22, x0                                    
02d5c27c: cbz     x8, #0x2d5c430                             
02d5c280: ldr     x9, [x8, #0x18]                            M:Trading.TradingSession::<ValidateTrade>b__57_0
02d5c284: cbz     x9, #0x2d5c430                             
02d5c288: ldr     x10, [x19, #0x80]                          ._collectionItems
02d5c28c: cbz     x10, #0x2d5c430                            
02d5c290: ldr     w26, [x9, #0x18]                           
02d5c294: ldr     w9, [x10, #0x18]                           
02d5c298: mov     w10, #0xaaab                               
02d5c29c: ldr     w8, [x8, #0x10]                            M:Trading.TradingSession/<>c__DisplayClass56_0::<RemovePlayerItem>b__0
02d5c2a0: movk    w10, #0xaaaa, lsl #16                      
02d5c2a4: mov     w11, #0xaaaa                               
02d5c2a8: cmp     w26, w9                                    
02d5c2ac: movk    w11, #0x2aaa, lsl #16                      
02d5c2b0: csel    w21, w26, w9, lt                           
02d5c2b4: cmp     w8, w21                                    
02d5c2b8: madd    w10, w21, w10, w11                         
02d5c2bc: mov     w11, #0x5554                               
02d5c2c0: csel    w8, w26, w8, lt                            
02d5c2c4: movk    w11, #0x5555, lsl #16                      
02d5c2c8: cmp     w8, w9                                     
02d5c2cc: csel    w20, w8, w9, lt                            
02d5c2d0: cmp     w10, w11                                   
02d5c2d4: mov     w8, #4                                     
02d5c2d8: str     w8, [x19, #0x88]                           ._showingShelfCount
02d5c2dc: b.ls    #0x2d5c2fc                                 
02d5c2e0: cmp     w21, #0xf                                  
02d5c2e4: b.lt    #0x2d5c320                                 
02d5c2e8: mov     w8, #0xaaab                                
02d5c2ec: movk    w8, #0xaaaa, lsl #16                       
02d5c2f0: umull   x8, w21, w8                                
02d5c2f4: lsr     x8, x8, #0x21                              
02d5c2f8: b       #0x2d5c318                                 
02d5c2fc: cmp     w21, #0xc                                  
02d5c300: b.lt    #0x2d5c320                                 
02d5c304: mov     w8, #0xaaab                                
02d5c308: movk    w8, #0xaaaa, lsl #16                       
02d5c30c: umull   x8, w21, w8                                
02d5c310: lsr     x8, x8, #0x21                              
02d5c314: add     w8, w8, #1                                 
02d5c318: str     w8, [x19, #0x88]                           ._showingShelfCount
02d5c31c: b       #0x2d5c324                                 
02d5c320: mov     w8, #4                                     
02d5c324: ldr     x9, [x19, #0x78]                           ._collectionShelfs
02d5c328: cbz     x9, #0x2d5c34c                             
02d5c32c: ldr     w10, [x9, #0x18]                           
02d5c330: subs    w9, w10, #1                                
02d5c334: b.lt    #0x2d5c34c                                 
02d5c338: cmp     w8, w10                                    
02d5c33c: b.lo    #0x2d5c344                                 
02d5c340: str     w9, [x19, #0x88]                           ._showingShelfCount
02d5c344: mov     x0, x19                                    
02d5c348: bl      #0x2d5c44c                                 Clicker.ScreenClickerCollection::UpdateShelf
02d5c34c: adrp    x25, #0x626b000                            
02d5c350: cmp     w21, #1                                    
02d5c354: ldr     x25, [x25, #0xd18]                         MS:System.Collections.Generic.List`1::get_Item
02d5c358: b.lt    #0x2d5c3bc                                 
02d5c35c: adrp    x27, #0x6269000                            
02d5c360: mov     w23, wzr                                   
02d5c364: ldr     x27, [x27, #0x1e8]                         MS:System.Collections.Generic.List`1::get_Item
02d5c368: ldr     x0, [x19, #0x80]                           ._collectionItems
02d5c36c: cbz     x0, #0x2d5c430                             
02d5c370: ldr     x2, [x25]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d5c374: mov     w1, w23                                    
02d5c378: bl      #0x35a8f3c                                 fn_35a8f3c
02d5c37c: ldr     x8, [x22, #0x20]                           
02d5c380: cbz     x8, #0x2d5c430                             
02d5c384: mov     x24, x0                                    
02d5c388: ldr     x0, [x8, #0x18]                            M:Trading.TradingSession::<ValidateTrade>b__57_0
02d5c38c: cbz     x0, #0x2d5c430                             
02d5c390: ldr     x2, [x27]                                  T:Trading.TradingSession/<>c__DisplayClass56_0
02d5c394: mov     w1, w23                                    
02d5c398: bl      #0x35a8f3c                                 fn_35a8f3c
02d5c39c: cbz     x24, #0x2d5c430                            
02d5c3a0: mov     x2, x0                                     
02d5c3a4: mov     x0, x24                                    
02d5c3a8: mov     w1, #2                                     
02d5c3ac: bl      #0x2d5c58c                                 Clicker.CollectionKeycapItem::SetData
02d5c3b0: add     w23, w23, #1                               
02d5c3b4: cmp     w21, w23                                   
02d5c3b8: b.ne    #0x2d5c368                                 
02d5c3bc: cmp     w26, w20                                   
02d5c3c0: b.ge    #0x2d5c3f4                                 
02d5c3c4: ldr     x0, [x19, #0x80]                           ._collectionItems
02d5c3c8: cbz     x0, #0x2d5c430                             
02d5c3cc: ldr     x2, [x25]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d5c3d0: mov     w1, w21                                    
02d5c3d4: bl      #0x35a8f3c                                 fn_35a8f3c
02d5c3d8: cbz     x0, #0x2d5c430                             
02d5c3dc: mov     w1, wzr                                    
02d5c3e0: mov     x2, xzr                                    
02d5c3e4: bl      #0x2d5c58c                                 Clicker.CollectionKeycapItem::SetData
02d5c3e8: add     w21, w21, #1                               
02d5c3ec: cmp     w20, w21                                   
02d5c3f0: b.ne    #0x2d5c3c4                                 
02d5c3f4: ldr     x0, [x19, #0x80]                           ._collectionItems
02d5c3f8: cbz     x0, #0x2d5c430                             
02d5c3fc: ldr     w8, [x0, #0x18]                            S:'level_show_popuprate'
02d5c400: cmp     w20, w8                                    
02d5c404: b.ge    #0x2d5c434                                 
02d5c408: ldr     x2, [x25]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d5c40c: mov     w1, w20                                    
02d5c410: bl      #0x35a8f3c                                 fn_35a8f3c
02d5c414: cbz     x0, #0x2d5c430                             
02d5c418: mov     w1, #1                                     
02d5c41c: mov     x2, xzr                                    
02d5c420: bl      #0x2d5c58c                                 Clicker.CollectionKeycapItem::SetData
02d5c424: ldr     x0, [x19, #0x80]                           ._collectionItems
02d5c428: add     w20, w20, #1                               
02d5c42c: cbnz    x0, #0x2d5c3fc                             
02d5c430: bl      #0x2b7105c                                 fn_2b7105c
02d5c434: ldp     x20, x19, [sp, #0x40]                      
02d5c438: ldp     x22, x21, [sp, #0x30]                      
02d5c43c: ldp     x24, x23, [sp, #0x20]                      
02d5c440: ldp     x26, x25, [sp, #0x10]                      
02d5c444: ldp     x30, x27, [sp], #0x50                      
02d5c448: ret                                                
## OnShow() -> void
---- Clicker.ScreenClickerCollection::OnShow 0x2d5c6a0
02d5c6a0: stp     x30, x21, [sp, #-0x20]!                    
02d5c6a4: stp     x20, x19, [sp, #0x10]                      
02d5c6a8: adrp    x20, #0x6630000                            
02d5c6ac: mov     x19, x0                                    
02d5c6b0: ldrb    w8, [x20, #0x2cf]                          
02d5c6b4: tbnz    w8, #0, #0x2d5c6e4                         
02d5c6b8: adrp    x0, #0x6266000                             
02d5c6bc: ldr     x0, [x0, #0x750]                           MS:DataManager::GetData
02d5c6c0: bl      #0x2b70db0                                 fn_2b70db0
02d5c6c4: adrp    x0, #0x6266000                             
02d5c6c8: ldr     x0, [x0, #0x658]                           MS:MonoSingleton`1::get_Instance
02d5c6cc: bl      #0x2b70db0                                 fn_2b70db0
02d5c6d0: adrp    x0, #0x6265000                             
02d5c6d4: ldr     x0, [x0, #0x310]                           MS:WejoyService.Singleton`1::get_Instance
02d5c6d8: bl      #0x2b70db0                                 fn_2b70db0
02d5c6dc: mov     w8, #1                                     
02d5c6e0: strb    w8, [x20, #0x2cf]                          
02d5c6e4: mov     x0, x19                                    
02d5c6e8: mov     x1, xzr                                    
02d5c6ec: bl      #0x2cdd6b8                                 UIBase::OnShow
02d5c6f0: ldr     x0, [x19, #0x50]                           ._goContentCollection
02d5c6f4: cbz     x0, #0x2d5c844                             
02d5c6f8: mov     w1, #1                                     
02d5c6fc: mov     x2, xzr                                    
02d5c700: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d5c704: ldr     x0, [x19, #0x58]                           ._goContentPreviewCollection
02d5c708: cbz     x0, #0x2d5c844                             
02d5c70c: mov     w1, wzr                                    
02d5c710: mov     x2, xzr                                    
02d5c714: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d5c718: ldr     x0, [x19, #0x38]                           ._btnHome
02d5c71c: cbz     x0, #0x2d5c844                             
02d5c720: mov     x1, xzr                                    
02d5c724: bl      #0x5b339ec                                 UnityEngine.Component::get_gameObject
02d5c728: cbz     x0, #0x2d5c844                             
02d5c72c: mov     w1, #1                                     
02d5c730: mov     x2, xzr                                    
02d5c734: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d5c738: ldr     x0, [x19, #0x40]                           ._btnBack
02d5c73c: cbz     x0, #0x2d5c844                             
02d5c740: mov     x1, xzr                                    
02d5c744: bl      #0x5b339ec                                 UnityEngine.Component::get_gameObject
02d5c748: cbz     x0, #0x2d5c844                             
02d5c74c: mov     w1, wzr                                    
02d5c750: mov     x2, xzr                                    
02d5c754: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d5c758: ldr     x0, [x19, #0x48]                           ._btnRemoveKeycap
02d5c75c: cbz     x0, #0x2d5c844                             
02d5c760: mov     x1, xzr                                    
02d5c764: bl      #0x5b339ec                                 UnityEngine.Component::get_gameObject
02d5c768: cbz     x0, #0x2d5c844                             
02d5c76c: mov     w1, wzr                                    
02d5c770: mov     x2, xzr                                    
02d5c774: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d5c778: ldr     x0, [x19, #0x60]                           ._petAtHome
02d5c77c: cbz     x0, #0x2d5c844                             
02d5c780: mov     w1, wzr                                    
02d5c784: mov     x2, xzr                                    
02d5c788: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d5c78c: ldr     x0, [x19, #0x68]                           ._handTutorial
02d5c790: cbz     x0, #0x2d5c844                             
02d5c794: adrp    x20, #0x6266000                            
02d5c798: mov     w1, wzr                                    
02d5c79c: mov     x2, xzr                                    
02d5c7a0: ldr     x20, [x20, #0x658]                         MS:MonoSingleton`1::get_Instance
02d5c7a4: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d5c7a8: ldr     x0, [x20]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d5c7ac: bl      #0x3769600                                 fn_3769600
02d5c7b0: cbz     x0, #0x2d5c844                             
02d5c7b4: adrp    x8, #0x6266000                             
02d5c7b8: ldr     x8, [x8, #0x750]                           MS:DataManager::GetData
02d5c7bc: ldr     x1, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d5c7c0: bl      #0x3168dd0                                 fn_3168dd0
02d5c7c4: cbz     x0, #0x2d5c844                             
02d5c7c8: ldr     x8, [x0, #0x20]                            S:'dev log AdsManager show app open ad'
02d5c7cc: mov     x20, x0                                    
02d5c7d0: cbz     x8, #0x2d5c844                             
02d5c7d4: ldrb    w8, [x8, #0x44]                            
02d5c7d8: cbnz    w8, #0x2d5c814                             
02d5c7dc: ldr     x0, [x19, #0x68]                           ._handTutorial
02d5c7e0: cbz     x0, #0x2d5c844                             
02d5c7e4: mov     w1, #1                                     
02d5c7e8: mov     x2, xzr                                    
02d5c7ec: mov     w21, #1                                    
02d5c7f0: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d5c7f4: ldr     x8, [x20, #0x20]                           S:'inter_ad_capping_time'
02d5c7f8: cbz     x8, #0x2d5c844                             
02d5c7fc: strb    w21, [x8, #0x44]                           
02d5c800: mov     x0, x20                                    
02d5c804: ldr     x8, [x20]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d5c808: ldr     x9, [x8, #0x258]                           MS:System.Collections.Generic.List`1/Enumerator::Dispose
02d5c80c: ldr     x1, [x8, #0x260]                           MS:System.Collections.Generic.List`1/Enumerator::MoveNext
02d5c810: blr     x9                                         
02d5c814: adrp    x20, #0x6265000                            
02d5c818: mov     x0, x19                                    
02d5c81c: mov     w1, wzr                                    
02d5c820: ldr     x20, [x20, #0x310]                         MS:WejoyService.Singleton`1::get_Instance
02d5c824: bl      #0x2d5c500                                 Clicker.ScreenClickerCollection::SetMultipleInput
02d5c828: ldr     x0, [x20]                                  M:AdsManager::<OnApplicationPause>b__26_0
02d5c82c: bl      #0x3be7218                                 fn_3be7218
02d5c830: cbz     x0, #0x2d5c844                             
02d5c834: ldp     x20, x19, [sp, #0x10]                      
02d5c838: mov     x1, xzr                                    
02d5c83c: ldp     x30, x21, [sp], #0x20                      
02d5c840: b       #0x2c8a7a4                                 AdsManager::ShowCollap
02d5c844: bl      #0x2b7105c                                 fn_2b7105c
## OnHide() -> void
---- Clicker.ScreenClickerCollection::OnHide 0x2d5c848
02d5c848: stp     x30, x19, [sp, #-0x10]!                    
02d5c84c: mov     x1, xzr                                    
02d5c850: mov     x19, x0                                    
02d5c854: bl      #0x2cddc10                                 UIBase::OnHide
02d5c858: ldr     x0, [x19, #0x50]                           ._goContentCollection
02d5c85c: cbz     x0, #0x2d5c890                             
02d5c860: mov     w1, wzr                                    
02d5c864: mov     x2, xzr                                    
02d5c868: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d5c86c: ldr     x0, [x19, #0x58]                           ._goContentPreviewCollection
02d5c870: cbz     x0, #0x2d5c890                             
02d5c874: mov     w1, wzr                                    
02d5c878: mov     x2, xzr                                    
02d5c87c: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d5c880: mov     x0, x19                                    
02d5c884: mov     w1, wzr                                    
02d5c888: ldp     x30, x19, [sp], #0x10                      
02d5c88c: b       #0x2d5c500                                 Clicker.ScreenClickerCollection::SetMultipleInput
02d5c890: bl      #0x2b7105c                                 fn_2b7105c
## ShowPreviewClick(Clicker.CollectionKeycapItem item) -> void
---- Clicker.ScreenClickerCollection::ShowPreviewClick 0x2d5c894
02d5c894: str     d8, [sp, #-0x30]!                          
02d5c898: str     x30, [sp, #8]                              
02d5c89c: stp     x22, x21, [sp, #0x10]                      
02d5c8a0: stp     x20, x19, [sp, #0x20]                      
02d5c8a4: adrp    x21, #0x6630000                            
02d5c8a8: mov     x20, x1                                    
02d5c8ac: mov     x19, x0                                    
02d5c8b0: ldrb    w8, [x21, #0x2d0]                          
02d5c8b4: tbnz    w8, #0, #0x2d5c8cc                         
02d5c8b8: adrp    x0, #0x6266000                             
02d5c8bc: ldr     x0, [x0, #0x880]                           MS:DG.Tweening.TweenSettingsExtensions::SetEase
02d5c8c0: bl      #0x2b70db0                                 fn_2b70db0
02d5c8c4: mov     w8, #1                                     
02d5c8c8: strb    w8, [x21, #0x2d0]                          
02d5c8cc: mov     x0, x19                                    
02d5c8d0: mov     w1, #1                                     
02d5c8d4: bl      #0x2d5c500                                 Clicker.ScreenClickerCollection::SetMultipleInput
02d5c8d8: ldr     x0, [x19, #0x68]                           ._handTutorial
02d5c8dc: cbz     x0, #0x2d5cacc                             
02d5c8e0: mov     w1, wzr                                    
02d5c8e4: mov     x2, xzr                                    
02d5c8e8: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d5c8ec: ldr     x0, [x19, #0x50]                           ._goContentCollection
02d5c8f0: cbz     x0, #0x2d5cacc                             
02d5c8f4: mov     w1, wzr                                    
02d5c8f8: mov     x2, xzr                                    
02d5c8fc: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d5c900: ldr     x0, [x19, #0x58]                           ._goContentPreviewCollection
02d5c904: cbz     x0, #0x2d5cacc                             
02d5c908: mov     w1, #1                                     
02d5c90c: mov     x2, xzr                                    
02d5c910: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d5c914: ldr     x0, [x19, #0x38]                           ._btnHome
02d5c918: cbz     x0, #0x2d5cacc                             
02d5c91c: mov     x1, xzr                                    
02d5c920: bl      #0x5b339ec                                 UnityEngine.Component::get_gameObject
02d5c924: cbz     x0, #0x2d5cacc                             
02d5c928: mov     w1, wzr                                    
02d5c92c: mov     x2, xzr                                    
02d5c930: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d5c934: ldr     x0, [x19, #0x40]                           ._btnBack
02d5c938: cbz     x0, #0x2d5cacc                             
02d5c93c: mov     x1, xzr                                    
02d5c940: bl      #0x5b339ec                                 UnityEngine.Component::get_gameObject
02d5c944: cbz     x0, #0x2d5cacc                             
02d5c948: mov     w1, #1                                     
02d5c94c: mov     x2, xzr                                    
02d5c950: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d5c954: ldr     x0, [x19, #0x48]                           ._btnRemoveKeycap
02d5c958: cbz     x0, #0x2d5cacc                             
02d5c95c: mov     x1, xzr                                    
02d5c960: bl      #0x5b339ec                                 UnityEngine.Component::get_gameObject
02d5c964: cbz     x0, #0x2d5cacc                             
02d5c968: mov     w1, #1                                     
02d5c96c: mov     x2, xzr                                    
02d5c970: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d5c974: mov     x21, x19                                   
02d5c978: mov     x1, x20                                    
02d5c97c: str     x20, [x21, #0xb0]!                         ._inspectItem
02d5c980: mov     x0, x21                                    
02d5c984: bl      #0x2b70d54                                 fn_2b70d54
02d5c988: ldr     x8, [x21]                                  
02d5c98c: cbz     x8, #0x2d5cacc                             
02d5c990: ldr     x8, [x8, #0x20]                            
02d5c994: cbz     x8, #0x2d5cacc                             
02d5c998: ldr     x1, [x8, #0x50]                            
02d5c99c: mov     x21, x19                                   
02d5c9a0: str     x1, [x21, #0xa8]!                          ._inspectKeycap
02d5c9a4: mov     x0, x21                                    
02d5c9a8: bl      #0x2b70d54                                 fn_2b70d54
02d5c9ac: cbz     x20, #0x2d5cacc                            
02d5c9b0: ldr     x8, [x20, #0x20]                           
02d5c9b4: cbz     x8, #0x2d5cacc                             
02d5c9b8: ldr     x8, [x8, #0x58]                            
02d5c9bc: cbz     x8, #0x2d5cacc                             
02d5c9c0: ldr     w8, [x8, #0x10]                            
02d5c9c4: ldr     x0, [x19, #0xa8]                           ._inspectKeycap
02d5c9c8: str     w8, [x19, #0x98]                           ._inspectIndex
02d5c9cc: cbz     x0, #0x2d5cacc                             
02d5c9d0: mov     w1, wzr                                    
02d5c9d4: bl      #0x2d5cae8                                 Clicker.BaseKeycapObject::TurnModeSetup
02d5c9d8: ldr     x0, [x21]                                  
02d5c9dc: cbz     x0, #0x2d5cacc                             
02d5c9e0: mov     x1, xzr                                    
02d5c9e4: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02d5c9e8: cbz     x0, #0x2d5cacc                             
02d5c9ec: ldr     x1, [x19, #0x90]                           ._tfInspectPos
02d5c9f0: mov     x2, xzr                                    
02d5c9f4: bl      #0x5b472ec                                 UnityEngine.Transform::SetParent
02d5c9f8: ldr     x0, [x19, #0xa8]                           ._inspectKeycap
02d5c9fc: cbz     x0, #0x2d5cacc                             
02d5ca00: mov     x1, xzr                                    
02d5ca04: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02d5ca08: mov     w1, wzr                                    
02d5ca0c: mov     x2, xzr                                    
02d5ca10: bl      #0x2d9d5d0                                 DG.Tweening.ShortcutExtensions::DOKill
02d5ca14: ldr     x0, [x21]                                  
02d5ca18: cbz     x0, #0x2d5cacc                             
02d5ca1c: adrp    x20, #0x6266000                            
02d5ca20: mov     x1, xzr                                    
02d5ca24: ldr     x20, [x20, #0x880]                         MS:DG.Tweening.TweenSettingsExtensions::SetEase
02d5ca28: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02d5ca2c: adrp    x22, #0x662f000                            
02d5ca30: mov     x19, x0                                    
02d5ca34: ldrb    w8, [x22, #0x91a]                          
02d5ca38: cbnz    w8, #0x2d5ca50                             
02d5ca3c: adrp    x0, #0x6264000                             
02d5ca40: ldr     x0, [x0, #0xd8]                            T:UnityEngine.Vector3
02d5ca44: bl      #0x2b70db0                                 fn_2b70db0
02d5ca48: mov     w8, #1                                     
02d5ca4c: strb    w8, [x22, #0x91a]                          
02d5ca50: adrp    x8, #0x6264000                             
02d5ca54: mov     x0, x19                                    
02d5ca58: mov     w1, wzr                                    
02d5ca5c: ldr     x8, [x8, #0xd8]                            T:UnityEngine.Vector3
02d5ca60: mov     x2, xzr                                    
02d5ca64: ldr     x8, [x8]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d5ca68: ldr     x8, [x8, #0xb8]                            MS:DG.Tweening.Core.Extensions::SetSpecialStartupMode
02d5ca6c: ldp     s0, s1, [x8]                               
02d5ca70: ldr     s2, [x8, #8]                               T:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass2_0
02d5ca74: adrp    x8, #0x1084000                             
02d5ca78: ldr     s8, [x8, #0xeec]                           [1084eec]=457ff0003dcccccd f=0.1,4095
02d5ca7c: fmov    s3, s8                                     
02d5ca80: bl      #0x2d97cf0                                 DG.Tweening.ShortcutExtensions::DOLocalMove
02d5ca84: ldr     x2, [x20]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d5ca88: mov     w1, #1                                     
02d5ca8c: bl      #0x336fa0c                                 fn_336fa0c
02d5ca90: ldr     x0, [x21]                                  
02d5ca94: cbz     x0, #0x2d5cacc                             
02d5ca98: mov     x1, xzr                                    
02d5ca9c: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02d5caa0: fmov    s1, s8                                     
02d5caa4: fmov    s0, #1.00000000                            
02d5caa8: mov     x1, xzr                                    
02d5caac: bl      #0x2d98c98                                 DG.Tweening.ShortcutExtensions::DOScale
02d5cab0: ldr     x2, [x20]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d5cab4: ldp     x20, x19, [sp, #0x20]                      
02d5cab8: ldp     x22, x21, [sp, #0x10]                      
02d5cabc: mov     w1, #1                                     
02d5cac0: ldr     x30, [sp, #8]                              
02d5cac4: ldr     d8, [sp], #0x30                            
02d5cac8: b       #0x336fa0c                                 
02d5cacc: bl      #0x2b7105c                                 fn_2b7105c
## BackToCollection() -> void
---- Clicker.ScreenClickerCollection::BackToCollection 0x2d5cbc4
02d5cbc4: str     d8, [sp, #-0x30]!                          
02d5cbc8: str     x30, [sp, #8]                              
02d5cbcc: stp     x22, x21, [sp, #0x10]                      
02d5cbd0: stp     x20, x19, [sp, #0x20]                      
02d5cbd4: adrp    x20, #0x6630000                            
02d5cbd8: mov     x19, x0                                    
02d5cbdc: ldrb    w8, [x20, #0x2d1]                          
02d5cbe0: tbnz    w8, #0, #0x2d5cbf8                         
02d5cbe4: adrp    x0, #0x6266000                             
02d5cbe8: ldr     x0, [x0, #0x880]                           MS:DG.Tweening.TweenSettingsExtensions::SetEase
02d5cbec: bl      #0x2b70db0                                 fn_2b70db0
02d5cbf0: mov     w8, #1                                     
02d5cbf4: strb    w8, [x20, #0x2d1]                          
02d5cbf8: mov     x0, x19                                    
02d5cbfc: mov     w1, wzr                                    
02d5cc00: bl      #0x2d5c500                                 Clicker.ScreenClickerCollection::SetMultipleInput
02d5cc04: ldr     x0, [x19, #0xa8]                           ._inspectKeycap
02d5cc08: cbz     x0, #0x2d5cdb4                             
02d5cc0c: mov     w1, #1                                     
02d5cc10: bl      #0x2d5cae8                                 Clicker.BaseKeycapObject::TurnModeSetup
02d5cc14: ldr     x0, [x19, #0x50]                           ._goContentCollection
02d5cc18: cbz     x0, #0x2d5cdb4                             
02d5cc1c: mov     w1, #1                                     
02d5cc20: mov     x2, xzr                                    
02d5cc24: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d5cc28: ldr     x0, [x19, #0x58]                           ._goContentPreviewCollection
02d5cc2c: cbz     x0, #0x2d5cdb4                             
02d5cc30: mov     w1, wzr                                    
02d5cc34: mov     x2, xzr                                    
02d5cc38: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d5cc3c: ldr     x0, [x19, #0x38]                           ._btnHome
02d5cc40: cbz     x0, #0x2d5cdb4                             
02d5cc44: mov     x1, xzr                                    
02d5cc48: bl      #0x5b339ec                                 UnityEngine.Component::get_gameObject
02d5cc4c: cbz     x0, #0x2d5cdb4                             
02d5cc50: mov     w1, #1                                     
02d5cc54: mov     x2, xzr                                    
02d5cc58: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d5cc5c: ldr     x0, [x19, #0x40]                           ._btnBack
02d5cc60: cbz     x0, #0x2d5cdb4                             
02d5cc64: mov     x1, xzr                                    
02d5cc68: bl      #0x5b339ec                                 UnityEngine.Component::get_gameObject
02d5cc6c: cbz     x0, #0x2d5cdb4                             
02d5cc70: mov     w1, wzr                                    
02d5cc74: mov     x2, xzr                                    
02d5cc78: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d5cc7c: ldr     x0, [x19, #0x48]                           ._btnRemoveKeycap
02d5cc80: cbz     x0, #0x2d5cdb4                             
02d5cc84: mov     x1, xzr                                    
02d5cc88: bl      #0x5b339ec                                 UnityEngine.Component::get_gameObject
02d5cc8c: cbz     x0, #0x2d5cdb4                             
02d5cc90: mov     w1, wzr                                    
02d5cc94: mov     x2, xzr                                    
02d5cc98: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d5cc9c: ldr     x0, [x19, #0xa8]                           ._inspectKeycap
02d5cca0: cbz     x0, #0x2d5cdb4                             
02d5cca4: mov     x1, xzr                                    
02d5cca8: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02d5ccac: ldr     x8, [x19, #0xb0]                           ._inspectItem
02d5ccb0: cbz     x8, #0x2d5cdb4                             
02d5ccb4: mov     x20, x0                                    
02d5ccb8: ldr     x0, [x8, #0x20]                            
02d5ccbc: cbz     x0, #0x2d5cdb4                             
02d5ccc0: mov     x1, xzr                                    
02d5ccc4: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02d5ccc8: cbz     x20, #0x2d5cdb4                            
02d5cccc: mov     x1, x0                                     
02d5ccd0: mov     x0, x20                                    
02d5ccd4: mov     x2, xzr                                    
02d5ccd8: bl      #0x5b472ec                                 UnityEngine.Transform::SetParent
02d5ccdc: ldr     x0, [x19, #0xa8]                           ._inspectKeycap
02d5cce0: cbz     x0, #0x2d5cdb4                             
02d5cce4: mov     x1, xzr                                    
02d5cce8: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02d5ccec: mov     w1, wzr                                    
02d5ccf0: mov     x2, xzr                                    
02d5ccf4: bl      #0x2d9d5d0                                 DG.Tweening.ShortcutExtensions::DOKill
02d5ccf8: ldr     x0, [x19, #0xa8]                           ._inspectKeycap
02d5ccfc: cbz     x0, #0x2d5cdb4                             
02d5cd00: adrp    x21, #0x6266000                            
02d5cd04: mov     x1, xzr                                    
02d5cd08: ldr     x21, [x21, #0x880]                         MS:DG.Tweening.TweenSettingsExtensions::SetEase
02d5cd0c: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02d5cd10: adrp    x22, #0x662f000                            
02d5cd14: mov     x20, x0                                    
02d5cd18: ldrb    w8, [x22, #0x91a]                          
02d5cd1c: cbnz    w8, #0x2d5cd34                             
02d5cd20: adrp    x0, #0x6264000                             
02d5cd24: ldr     x0, [x0, #0xd8]                            T:UnityEngine.Vector3
02d5cd28: bl      #0x2b70db0                                 fn_2b70db0
02d5cd2c: mov     w8, #1                                     
02d5cd30: strb    w8, [x22, #0x91a]                          
02d5cd34: adrp    x8, #0x6264000                             
02d5cd38: mov     x0, x20                                    
02d5cd3c: mov     w1, wzr                                    
02d5cd40: ldr     x8, [x8, #0xd8]                            T:UnityEngine.Vector3
02d5cd44: mov     x2, xzr                                    
02d5cd48: ldr     x8, [x8]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d5cd4c: ldr     x8, [x8, #0xb8]                            MS:DG.Tweening.Core.Extensions::SetSpecialStartupMode
02d5cd50: ldp     s0, s1, [x8]                               
02d5cd54: ldr     s2, [x8, #8]                               T:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass2_0
02d5cd58: adrp    x8, #0x1084000                             
02d5cd5c: ldr     s8, [x8, #0xeec]                           [1084eec]=457ff0003dcccccd f=0.1,4095
02d5cd60: fmov    s3, s8                                     
02d5cd64: bl      #0x2d97cf0                                 DG.Tweening.ShortcutExtensions::DOLocalMove
02d5cd68: ldr     x2, [x21]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d5cd6c: mov     w1, #1                                     
02d5cd70: bl      #0x336fa0c                                 fn_336fa0c
02d5cd74: ldr     x0, [x19, #0xa8]                           ._inspectKeycap
02d5cd78: cbz     x0, #0x2d5cdb4                             
02d5cd7c: mov     x1, xzr                                    
02d5cd80: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02d5cd84: fmov    s1, s8                                     
02d5cd88: adrp    x8, #0x1084000                             
02d5cd8c: mov     x1, xzr                                    
02d5cd90: ldr     s0, [x8, #0xe60]                           [1084e60]=bc8efa353eb33333 f=0.35,-0.0174533
02d5cd94: bl      #0x2d98c98                                 DG.Tweening.ShortcutExtensions::DOScale
02d5cd98: ldr     x2, [x21]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d5cd9c: ldp     x20, x19, [sp, #0x20]                      
02d5cda0: ldp     x22, x21, [sp, #0x10]                      
02d5cda4: mov     w1, #1                                     
02d5cda8: ldr     x30, [sp, #8]                              
02d5cdac: ldr     d8, [sp], #0x30                            
02d5cdb0: b       #0x336fa0c                                 
02d5cdb4: bl      #0x2b7105c                                 fn_2b7105c
## UnlockNewSlot() -> void
---- Clicker.ScreenClickerCollection::UnlockNewSlot 0x2d5cdb8
02d5cdb8: stp     x30, x21, [sp, #-0x20]!                    
02d5cdbc: stp     x20, x19, [sp, #0x10]                      
02d5cdc0: adrp    x20, #0x6630000                            
02d5cdc4: mov     x19, x0                                    
02d5cdc8: ldrb    w8, [x20, #0x2d2]                          
02d5cdcc: tbnz    w8, #0, #0x2d5cdf0                         
02d5cdd0: adrp    x0, #0x626b000                             
02d5cdd4: ldr     x0, [x0, #0xd10]                           MS:System.Collections.Generic.List`1::get_Count
02d5cdd8: bl      #0x2b70db0                                 fn_2b70db0
02d5cddc: adrp    x0, #0x626b000                             
02d5cde0: ldr     x0, [x0, #0xd18]                           MS:System.Collections.Generic.List`1::get_Item
02d5cde4: bl      #0x2b70db0                                 fn_2b70db0
02d5cde8: mov     w8, #1                                     
02d5cdec: strb    w8, [x20, #0x2d2]                          
02d5cdf0: ldr     x0, [x19, #0x80]                           ._collectionItems
02d5cdf4: cbz     x0, #0x2d5ce38                             
02d5cdf8: adrp    x21, #0x626b000                            
02d5cdfc: mov     w20, wzr                                   
02d5ce00: ldr     x21, [x21, #0xd18]                         MS:System.Collections.Generic.List`1::get_Item
02d5ce04: ldr     w8, [x0, #0x18]                            T:type57265(k15)
02d5ce08: cmp     w20, w8                                    
02d5ce0c: b.ge    #0x2d5ce3c                                 
02d5ce10: ldr     x2, [x21]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d5ce14: mov     w1, w20                                    
02d5ce18: bl      #0x35a8f3c                                 fn_35a8f3c
02d5ce1c: cbz     x0, #0x2d5ce38                             
02d5ce20: ldr     w8, [x0, #0x58]                            M:ScoopGame.CharmDrag::<OnRelease>b__13_0 ._goContentPreviewCollection
02d5ce24: cmp     w8, #1                                     
02d5ce28: b.eq    #0x2d5ce48                                 
02d5ce2c: ldr     x0, [x19, #0x80]                           ._collectionItems
02d5ce30: add     w20, w20, #1                               
02d5ce34: cbnz    x0, #0x2d5ce04                             
02d5ce38: bl      #0x2b7105c                                 fn_2b7105c
02d5ce3c: ldp     x20, x19, [sp, #0x10]                      
02d5ce40: ldp     x30, x21, [sp], #0x20                      
02d5ce44: ret                                                
02d5ce48: ldr     x0, [x19, #0x80]                           ._collectionItems
02d5ce4c: cbz     x0, #0x2d5ce38                             
02d5ce50: ldr     x2, [x21]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d5ce54: mov     w1, w20                                    
02d5ce58: bl      #0x35a8f3c                                 fn_35a8f3c
02d5ce5c: cbz     x0, #0x2d5ce38                             
02d5ce60: ldp     x20, x19, [sp, #0x10]                      
02d5ce64: mov     w1, wzr                                    
02d5ce68: mov     x2, xzr                                    
02d5ce6c: ldp     x30, x21, [sp], #0x20                      
02d5ce70: b       #0x2d5c58c                                 Clicker.CollectionKeycapItem::SetData
## OnBtnHomeClick() -> void
---- Clicker.ScreenClickerCollection::OnBtnHomeClick 0x2d5ce74
02d5ce74: stp     x30, x23, [sp, #-0x30]!                    
02d5ce78: stp     x22, x21, [sp, #0x10]                      
02d5ce7c: stp     x20, x19, [sp, #0x20]                      
02d5ce80: adrp    x23, #0x6630000                            
02d5ce84: adrp    x22, #0x6265000                            
02d5ce88: adrp    x20, #0x6264000                            
02d5ce8c: adrp    x21, #0x626b000                            
02d5ce90: ldr     x22, [x22, #0x310]                         MS:WejoyService.Singleton`1::get_Instance
02d5ce94: ldrb    w8, [x23, #0x2d3]                          
02d5ce98: ldr     x20, [x20, #0xf90]                         T:System.Action
02d5ce9c: ldr     x21, [x21, #0xd48]                         M:Clicker.ScreenClickerCollection::<OnBtnHomeClick>b__26_0
02d5cea0: mov     x19, x0                                    
02d5cea4: tbnz    w8, #0, #0x2d5cee0                         
02d5cea8: adrp    x0, #0x6264000                             
02d5ceac: ldr     x0, [x0, #0xf90]                           T:System.Action
02d5ceb0: bl      #0x2b70db0                                 fn_2b70db0
02d5ceb4: adrp    x0, #0x626b000                             
02d5ceb8: ldr     x0, [x0, #0xd48]                           M:Clicker.ScreenClickerCollection::<OnBtnHomeClick>b__26_0
02d5cebc: bl      #0x2b70db0                                 fn_2b70db0
02d5cec0: adrp    x0, #0x6265000                             
02d5cec4: ldr     x0, [x0, #0x310]                           MS:WejoyService.Singleton`1::get_Instance
02d5cec8: bl      #0x2b70db0                                 fn_2b70db0
02d5cecc: adrp    x0, #0x626b000                             
02d5ced0: ldr     x0, [x0, #0xd50]                           S:'collection_back'
02d5ced4: bl      #0x2b70db0                                 fn_2b70db0
02d5ced8: mov     w8, #1                                     
02d5cedc: strb    w8, [x23, #0x2d3]                          
02d5cee0: mov     x0, xzr                                    
02d5cee4: bl      #0x2d6ff04                                 Framework.AudioHelper::PlayClickSound
02d5cee8: ldr     x0, [x22]                                  M:AdsManager::<OnApplicationPause>b__26_0
02d5ceec: bl      #0x3be7218                                 fn_3be7218
02d5cef0: ldr     x8, [x20]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d5cef4: mov     x20, x0                                    
02d5cef8: mov     x0, x8                                     
02d5cefc: bl      #0x2b7104c                                 fn_2b7104c
02d5cf00: ldr     x2, [x21]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d5cf04: mov     x1, x19                                    
02d5cf08: mov     x3, xzr                                    
02d5cf0c: mov     x21, x0                                    
02d5cf10: bl      #0x4d8ddbc                                 System.Action::.ctor
02d5cf14: cbz     x20, #0x2d5cf44                            
02d5cf18: adrp    x8, #0x626b000                             
02d5cf1c: mov     x0, x20                                    
02d5cf20: mov     x2, x21                                    
02d5cf24: ldr     x8, [x8, #0xd50]                           S:'collection_back'
02d5cf28: ldp     x20, x19, [sp, #0x20]                      
02d5cf2c: ldp     x22, x21, [sp, #0x10]                      
02d5cf30: mov     w3, #1                                     
02d5cf34: ldr     x1, [x8]                                   T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d5cf38: mov     x4, xzr                                    
02d5cf3c: ldp     x30, x23, [sp], #0x30                      
02d5cf40: b       #0x2c89698                                 AdsManager::ShowInter
02d5cf44: bl      #0x2b7105c                                 fn_2b7105c
## OnBtnRemoveKeycapClick() -> void
---- Clicker.ScreenClickerCollection::OnBtnRemoveKeycapClick 0x2d5cf48
02d5cf48: stp     x30, x21, [sp, #-0x20]!                    
02d5cf4c: stp     x20, x19, [sp, #0x10]                      
02d5cf50: adrp    x21, #0x6630000                            
02d5cf54: adrp    x20, #0x6267000                            
02d5cf58: mov     x19, x0                                    
02d5cf5c: ldrb    w8, [x21, #0x2d4]                          
02d5cf60: ldr     x20, [x20, #0xbd0]                         MS:MonoSingleton`1::get_Instance
02d5cf64: tbnz    w8, #0, #0x2d5cfa0                         
02d5cf68: adrp    x0, #0x6264000                             
02d5cf6c: ldr     x0, [x0, #0xf90]                           T:System.Action
02d5cf70: bl      #0x2b70db0                                 fn_2b70db0
02d5cf74: adrp    x0, #0x6267000                             
02d5cf78: ldr     x0, [x0, #0xbd0]                           MS:MonoSingleton`1::get_Instance
02d5cf7c: bl      #0x2b70db0                                 fn_2b70db0
02d5cf80: adrp    x0, #0x626b000                             
02d5cf84: ldr     x0, [x0, #0xd58]                           M:Clicker.ScreenClickerCollection::<OnBtnRemoveKeycapClick>b__27_0
02d5cf88: bl      #0x2b70db0                                 fn_2b70db0
02d5cf8c: adrp    x0, #0x626b000                             
02d5cf90: ldr     x0, [x0, #0xd60]                           MS:UIManager::ShowPopup
02d5cf94: bl      #0x2b70db0                                 fn_2b70db0
02d5cf98: mov     w8, #1                                     
02d5cf9c: strb    w8, [x21, #0x2d4]                          
02d5cfa0: mov     x0, xzr                                    
02d5cfa4: bl      #0x2d6ff04                                 Framework.AudioHelper::PlayClickSound
02d5cfa8: ldr     x0, [x20]                                  S:'didu'
02d5cfac: bl      #0x3769600                                 fn_3769600
02d5cfb0: cbz     x0, #0x2d5d010                             
02d5cfb4: adrp    x8, #0x626b000                             
02d5cfb8: adrp    x20, #0x6264000                            
02d5cfbc: adrp    x21, #0x626b000                            
02d5cfc0: ldr     x8, [x8, #0xd60]                           MS:UIManager::ShowPopup
02d5cfc4: ldr     x20, [x20, #0xf90]                         T:System.Action
02d5cfc8: ldr     x21, [x21, #0xd58]                         M:Clicker.ScreenClickerCollection::<OnBtnRemoveKeycapClick>b__27_0
02d5cfcc: ldr     x1, [x8]                                   T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d5cfd0: bl      #0x33fbfac                                 fn_33fbfac
02d5cfd4: ldr     x8, [x20]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d5cfd8: mov     x20, x0                                    
02d5cfdc: mov     x0, x8                                     
02d5cfe0: bl      #0x2b7104c                                 fn_2b7104c
02d5cfe4: ldr     x2, [x21]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d5cfe8: mov     x1, x19                                    
02d5cfec: mov     x3, xzr                                    
02d5cff0: mov     x21, x0                                    
02d5cff4: bl      #0x4d8ddbc                                 System.Action::.ctor
02d5cff8: cbz     x20, #0x2d5d010                            
02d5cffc: mov     x0, x20                                    
02d5d000: ldp     x20, x19, [sp, #0x10]                      
02d5d004: mov     x1, x21                                    
02d5d008: ldp     x30, x21, [sp], #0x20                      
02d5d00c: b       #0x2d5d014                                 Clicker.DeleteKeycapPopup::SetEventCallback
02d5d010: bl      #0x2b7105c                                 fn_2b7105c
## DeleteCurrentKeycap() -> void
---- Clicker.ScreenClickerCollection::DeleteCurrentKeycap 0x2d5d0f4
02d5d0f4: str     x30, [sp, #-0x30]!                         
02d5d0f8: stp     x22, x21, [sp, #0x10]                      
02d5d0fc: stp     x20, x19, [sp, #0x20]                      
02d5d100: adrp    x20, #0x6630000                            
02d5d104: adrp    x21, #0x6266000                            
02d5d108: mov     x19, x0                                    
02d5d10c: ldrb    w8, [x20, #0x2d5]                          
02d5d110: ldr     x21, [x21, #0x658]                         MS:MonoSingleton`1::get_Instance
02d5d114: tbnz    w8, #0, #0x2d5d168                         
02d5d118: adrp    x0, #0x6269000                             
02d5d11c: ldr     x0, [x0, #0x3f8]                           MS:DataManager::GetData
02d5d120: bl      #0x2b70db0                                 fn_2b70db0
02d5d124: adrp    x0, #0x6266000                             
02d5d128: ldr     x0, [x0, #0x688]                           MS:System.Collections.Generic.List`1::Find
02d5d12c: bl      #0x2b70db0                                 fn_2b70db0
02d5d130: adrp    x0, #0x6266000                             
02d5d134: ldr     x0, [x0, #0x720]                           MS:System.Collections.Generic.List`1::Remove
02d5d138: bl      #0x2b70db0                                 fn_2b70db0
02d5d13c: adrp    x0, #0x6266000                             
02d5d140: ldr     x0, [x0, #0x658]                           MS:MonoSingleton`1::get_Instance
02d5d144: bl      #0x2b70db0                                 fn_2b70db0
02d5d148: adrp    x0, #0x6266000                             
02d5d14c: ldr     x0, [x0, #0x690]                           T:type57233(k15)
02d5d150: bl      #0x2b70db0                                 fn_2b70db0
02d5d154: adrp    x0, #0x626b000                             
02d5d158: ldr     x0, [x0, #0xd78]                           M:Clicker.ScreenClickerCollection::<DeleteCurrentKeycap>b__28_0
02d5d15c: bl      #0x2b70db0                                 fn_2b70db0
02d5d160: mov     w8, #1                                     
02d5d164: strb    w8, [x20, #0x2d5]                          
02d5d168: ldr     x0, [x21]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d5d16c: bl      #0x3769600                                 fn_3769600
02d5d170: cbz     x0, #0x2d5d240                             
02d5d174: adrp    x8, #0x6269000                             
02d5d178: ldr     x8, [x8, #0x3f8]                           MS:DataManager::GetData
02d5d17c: ldr     x1, [x8]                                   T:Trading.TradingSession/<>c__DisplayClass56_0
02d5d180: bl      #0x3168dd0                                 fn_3168dd0
02d5d184: cbz     x0, #0x2d5d240                             
02d5d188: ldr     x8, [x0, #0x20]                            M:ScoopGame.CategoryAsset/<>c__DisplayClass4_0::<GetOptionDataByID>b__0
02d5d18c: mov     x20, x0                                    
02d5d190: cbz     x8, #0x2d5d240                             
02d5d194: adrp    x9, #0x6266000                             
02d5d198: adrp    x22, #0x626b000                            
02d5d19c: ldr     x9, [x9, #0x690]                           T:type57233(k15)
02d5d1a0: ldr     x22, [x22, #0xd78]                         M:Clicker.ScreenClickerCollection::<DeleteCurrentKeycap>b__28_0
02d5d1a4: ldr     x21, [x8, #0x18]                           M:Trading.TradingSession::<ValidateTrade>b__57_0
02d5d1a8: ldr     x0, [x9]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d5d1ac: bl      #0x2b7104c                                 fn_2b7104c
02d5d1b0: ldr     x2, [x22]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d5d1b4: mov     x1, x19                                    
02d5d1b8: mov     x3, xzr                                    
02d5d1bc: mov     x22, x0                                    
02d5d1c0: bl      #0x399ba10                                 fn_399ba10
02d5d1c4: cbz     x21, #0x2d5d240                            
02d5d1c8: adrp    x8, #0x6266000                             
02d5d1cc: mov     x0, x21                                    
02d5d1d0: mov     x1, x22                                    
02d5d1d4: ldr     x8, [x8, #0x688]                           MS:System.Collections.Generic.List`1::Find
02d5d1d8: ldr     x2, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d5d1dc: bl      #0x35a9868                                 fn_35a9868
02d5d1e0: cbz     x0, #0x2d5d230                             
02d5d1e4: ldr     x8, [x20, #0x20]                           
02d5d1e8: cbz     x8, #0x2d5d240                             
02d5d1ec: mov     x1, x0                                     
02d5d1f0: ldr     x0, [x8, #0x18]                            S:'level_show_popuprate'
02d5d1f4: cbz     x0, #0x2d5d240                             
02d5d1f8: adrp    x8, #0x6266000                             
02d5d1fc: ldr     x8, [x8, #0x720]                           MS:System.Collections.Generic.List`1::Remove
02d5d200: ldr     x2, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d5d204: bl      #0x35aa7b4                                 fn_35aa7b4
02d5d208: ldr     x8, [x20]                                  
02d5d20c: mov     x0, x20                                    
02d5d210: ldr     x9, [x8, #0x258]                           MS:System.Collections.Generic.List`1/Enumerator::Dispose
02d5d214: ldr     x1, [x8, #0x260]                           MS:System.Collections.Generic.List`1/Enumerator::MoveNext
02d5d218: blr     x9                                         
02d5d21c: mov     x0, x19                                    
02d5d220: ldp     x20, x19, [sp, #0x20]                      
02d5d224: ldp     x22, x21, [sp, #0x10]                      
02d5d228: ldr     x30, [sp], #0x30                           
02d5d22c: b       #0x2d5c1cc                                 Clicker.ScreenClickerCollection::LoadSavedData
02d5d230: ldp     x20, x19, [sp, #0x20]                      
02d5d234: ldp     x22, x21, [sp, #0x10]                      
02d5d238: ldr     x30, [sp], #0x30                           
02d5d23c: ret                                                
02d5d240: bl      #0x2b7105c                                 fn_2b7105c
## OnBtnBackClick() -> void
---- Clicker.ScreenClickerCollection::OnBtnBackClick 0x2d5d244
02d5d244: stp     x30, x23, [sp, #-0x30]!                    
02d5d248: stp     x22, x21, [sp, #0x10]                      
02d5d24c: stp     x20, x19, [sp, #0x20]                      
02d5d250: adrp    x23, #0x6630000                            
02d5d254: adrp    x22, #0x6265000                            
02d5d258: adrp    x20, #0x6264000                            
02d5d25c: adrp    x21, #0x626b000                            
02d5d260: ldr     x22, [x22, #0x310]                         MS:WejoyService.Singleton`1::get_Instance
02d5d264: ldrb    w8, [x23, #0x2d6]                          
02d5d268: ldr     x20, [x20, #0xf90]                         T:System.Action
02d5d26c: ldr     x21, [x21, #0xd80]                         M:Clicker.ScreenClickerCollection::<OnBtnBackClick>b__29_0
02d5d270: mov     x19, x0                                    
02d5d274: tbnz    w8, #0, #0x2d5d2b0                         
02d5d278: adrp    x0, #0x6264000                             
02d5d27c: ldr     x0, [x0, #0xf90]                           T:System.Action
02d5d280: bl      #0x2b70db0                                 fn_2b70db0
02d5d284: adrp    x0, #0x626b000                             
02d5d288: ldr     x0, [x0, #0xd80]                           M:Clicker.ScreenClickerCollection::<OnBtnBackClick>b__29_0
02d5d28c: bl      #0x2b70db0                                 fn_2b70db0
02d5d290: adrp    x0, #0x6265000                             
02d5d294: ldr     x0, [x0, #0x310]                           MS:WejoyService.Singleton`1::get_Instance
02d5d298: bl      #0x2b70db0                                 fn_2b70db0
02d5d29c: adrp    x0, #0x626b000                             
02d5d2a0: ldr     x0, [x0, #0xd50]                           S:'collection_back'
02d5d2a4: bl      #0x2b70db0                                 fn_2b70db0
02d5d2a8: mov     w8, #1                                     
02d5d2ac: strb    w8, [x23, #0x2d6]                          
02d5d2b0: mov     x0, xzr                                    
02d5d2b4: bl      #0x2d6ff04                                 Framework.AudioHelper::PlayClickSound
02d5d2b8: ldr     x0, [x22]                                  M:AdsManager::<OnApplicationPause>b__26_0
02d5d2bc: bl      #0x3be7218                                 fn_3be7218
02d5d2c0: ldr     x8, [x20]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d5d2c4: mov     x20, x0                                    
02d5d2c8: mov     x0, x8                                     
02d5d2cc: bl      #0x2b7104c                                 fn_2b7104c
02d5d2d0: ldr     x2, [x21]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d5d2d4: mov     x1, x19                                    
02d5d2d8: mov     x3, xzr                                    
02d5d2dc: mov     x21, x0                                    
02d5d2e0: bl      #0x4d8ddbc                                 System.Action::.ctor
02d5d2e4: cbz     x20, #0x2d5d314                            
02d5d2e8: adrp    x8, #0x626b000                             
02d5d2ec: mov     x0, x20                                    
02d5d2f0: mov     x2, x21                                    
02d5d2f4: ldr     x8, [x8, #0xd50]                           S:'collection_back'
02d5d2f8: ldp     x20, x19, [sp, #0x20]                      
02d5d2fc: ldp     x22, x21, [sp, #0x10]                      
02d5d300: mov     w3, wzr                                    
02d5d304: ldr     x1, [x8]                                   T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d5d308: mov     x4, xzr                                    
02d5d30c: ldp     x30, x23, [sp], #0x30                      
02d5d310: b       #0x2c89698                                 AdsManager::ShowInter
02d5d314: bl      #0x2b7105c                                 fn_2b7105c
## .ctor() -> void
---- Clicker.ScreenClickerCollection::.ctor 0x2d5d318
02d5d318: mov     x1, xzr                                    
02d5d31c: b       #0x2cde678                                 ScreenBase::.ctor
## <OnInit>b__17_0(Clicker.CollectionShelf x) -> void
---- Clicker.ScreenClickerCollection::<OnInit>b__17_0 0x2d5d320
02d5d320: str     x30, [sp, #-0x30]!                         
02d5d324: stp     x22, x21, [sp, #0x10]                      
02d5d328: stp     x20, x19, [sp, #0x20]                      
02d5d32c: adrp    x21, #0x6630000                            
02d5d330: mov     x20, x1                                    
02d5d334: mov     x19, x0                                    
02d5d338: ldrb    w8, [x21, #0x2d7]                          
02d5d33c: tbnz    w8, #0, #0x2d5d378                         
02d5d340: adrp    x0, #0x626b000                             
02d5d344: ldr     x0, [x0, #0xd88]                           T:type53121(k15)
02d5d348: bl      #0x2b70db0                                 fn_2b70db0
02d5d34c: adrp    x0, #0x626b000                             
02d5d350: ldr     x0, [x0, #0xd90]                           MS:System.Collections.Generic.List`1::AddRange
02d5d354: bl      #0x2b70db0                                 fn_2b70db0
02d5d358: adrp    x0, #0x626b000                             
02d5d35c: ldr     x0, [x0, #0xd98]                           MS:System.Collections.Generic.List`1::ForEach
02d5d360: bl      #0x2b70db0                                 fn_2b70db0
02d5d364: adrp    x0, #0x626b000                             
02d5d368: ldr     x0, [x0, #0xda0]                           M:Clicker.ScreenClickerCollection::<OnInit>b__17_1
02d5d36c: bl      #0x2b70db0                                 fn_2b70db0
02d5d370: mov     w8, #1                                     
02d5d374: strb    w8, [x21, #0x2d7]                          
02d5d378: cbz     x20, #0x2d5d3f0                            
02d5d37c: ldr     x0, [x19, #0x80]                           ._collectionItems
02d5d380: cbz     x0, #0x2d5d3f0                             
02d5d384: adrp    x8, #0x626b000                             
02d5d388: adrp    x21, #0x626b000                            
02d5d38c: adrp    x22, #0x626b000                            
02d5d390: ldr     x8, [x8, #0xd90]                           MS:System.Collections.Generic.List`1::AddRange
02d5d394: ldr     x21, [x21, #0xd88]                         T:type53121(k15)
02d5d398: ldr     x22, [x22, #0xda0]                         M:Clicker.ScreenClickerCollection::<OnInit>b__17_1
02d5d39c: ldr     x1, [x20, #0x28]                           
02d5d3a0: ldr     x2, [x8]                                   T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d5d3a4: bl      #0x35a941c                                 fn_35a941c
02d5d3a8: ldr     x0, [x21]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d5d3ac: ldr     x20, [x20, #0x28]                          
02d5d3b0: bl      #0x2b7104c                                 fn_2b7104c
02d5d3b4: ldr     x2, [x22]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d5d3b8: mov     x1, x19                                    
02d5d3bc: mov     x3, xzr                                    
02d5d3c0: mov     x21, x0                                    
02d5d3c4: bl      #0x453418c                                 fn_453418c
02d5d3c8: cbz     x20, #0x2d5d3f0                            
02d5d3cc: adrp    x8, #0x626b000                             
02d5d3d0: mov     x0, x20                                    
02d5d3d4: mov     x1, x21                                    
02d5d3d8: ldr     x8, [x8, #0xd98]                           MS:System.Collections.Generic.List`1::ForEach
02d5d3dc: ldp     x20, x19, [sp, #0x20]                      
02d5d3e0: ldp     x22, x21, [sp, #0x10]                      
02d5d3e4: ldr     x2, [x8]                                   T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d5d3e8: ldr     x30, [sp], #0x30                           
02d5d3ec: b       #0x35a9ce4                                 
02d5d3f0: bl      #0x2b7105c                                 fn_2b7105c
## <OnInit>b__17_1(Clicker.CollectionKeycapItem y) -> void
---- Clicker.ScreenClickerCollection::<OnInit>b__17_1 0x2d5d3f4
02d5d3f4: cbz     x1, #0x2d5d40c                             
02d5d3f8: mov     x8, x0                                     
02d5d3fc: str     x0, [x1, #0x60]!                           
02d5d400: mov     x0, x1                                     
02d5d404: mov     x1, x8                                     
02d5d408: b       #0x2b70d54                                 
02d5d40c: str     x30, [sp, #-0x10]!                         
02d5d410: bl      #0x2b7105c                                 fn_2b7105c
## <OnBtnHomeClick>b__26_0() -> void
---- Clicker.ScreenClickerCollection::<OnBtnHomeClick>b__26_0 0x2d5d414
02d5d414: stp     x30, x21, [sp, #-0x20]!                    
02d5d418: stp     x20, x19, [sp, #0x10]                      
02d5d41c: adrp    x20, #0x6630000                            
02d5d420: adrp    x21, #0x6265000                            
02d5d424: mov     x19, x0                                    
02d5d428: ldrb    w8, [x20, #0x2d8]                          
02d5d42c: ldr     x21, [x21, #0x310]                         MS:WejoyService.Singleton`1::get_Instance
02d5d430: tbnz    w8, #0, #0x2d5d478                         
02d5d434: adrp    x0, #0x6266000                             
02d5d438: ldr     x0, [x0, #0xac0]                           MS:MonoSingleton`1::get_Instance
02d5d43c: bl      #0x2b70db0                                 fn_2b70db0
02d5d440: adrp    x0, #0x6263000                             
02d5d444: ldr     x0, [x0, #0x918]                           T:UnityEngine.Object
02d5d448: bl      #0x2b70db0                                 fn_2b70db0
02d5d44c: adrp    x0, #0x6265000                             
02d5d450: ldr     x0, [x0, #0x310]                           MS:WejoyService.Singleton`1::get_Instance
02d5d454: bl      #0x2b70db0                                 fn_2b70db0
02d5d458: adrp    x0, #0x6266000                             
02d5d45c: ldr     x0, [x0, #0xb78]                           MS:UIManager::ShowPopup
02d5d460: bl      #0x2b70db0                                 fn_2b70db0
02d5d464: adrp    x0, #0x6268000                             
02d5d468: ldr     x0, [x0, #0x108]                           MS:UIManager::ShowScreen
02d5d46c: bl      #0x2b70db0                                 fn_2b70db0
02d5d470: mov     w8, #1                                     
02d5d474: strb    w8, [x20, #0x2d8]                          
02d5d478: ldr     x0, [x21]                                  M:AdsManager::<OnApplicationPause>b__26_0
02d5d47c: bl      #0x3be7218                                 fn_3be7218
02d5d480: cbz     x0, #0x2d5d558                             
02d5d484: mov     x1, xzr                                    
02d5d488: bl      #0x2c895d4                                 AdsManager::SetStartShowAd
02d5d48c: ldr     x8, [x19]                                  
02d5d490: mov     x0, x19                                    
02d5d494: ldp     x9, x1, [x8, #0x198]                       
02d5d498: blr     x9                                         
02d5d49c: ldr     x0, [x19, #0x30]                           
02d5d4a0: cbz     x0, #0x2d5d558                             
02d5d4a4: adrp    x8, #0x6268000                             
02d5d4a8: ldr     x8, [x8, #0x108]                           MS:UIManager::ShowScreen
02d5d4ac: ldr     x1, [x8]                                   S:'{0}/2'
02d5d4b0: bl      #0x33fc0e8                                 fn_33fc0e8
02d5d4b4: ldr     x0, [x19, #0x30]                           
02d5d4b8: cbz     x0, #0x2d5d558                             
02d5d4bc: adrp    x8, #0x6266000                             
02d5d4c0: adrp    x20, #0x6263000                            
02d5d4c4: ldr     x8, [x8, #0xb78]                           MS:UIManager::ShowPopup
02d5d4c8: ldr     x20, [x20, #0x918]                         T:UnityEngine.Object
02d5d4cc: ldr     x1, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d5d4d0: bl      #0x33fbfac                                 fn_33fbfac
02d5d4d4: ldr     x8, [x20]                                  &2c5bbd4(=a9bd7bfdd503233f)
02d5d4d8: mov     x20, x0                                    
02d5d4dc: ldr     w9, [x8, #0xe4]                            [62660e4]=0 f=0,0
02d5d4e0: cbnz    w9, #0x2d5d4ec                             
02d5d4e4: mov     x0, x8                                     
02d5d4e8: bl      #0x2b70f30                                 fn_2b70f30
02d5d4ec: mov     x0, x20                                    
02d5d4f0: mov     x1, xzr                                    
02d5d4f4: mov     x2, xzr                                    
02d5d4f8: bl      #0x5b3666c                                 UnityEngine.Object::op_Inequality
02d5d4fc: tbz     w0, #0, #0x2d5d51c                         
02d5d500: cbz     x20, #0x2d5d558                            
02d5d504: mov     x0, x20                                    
02d5d508: mov     x1, xzr                                    
02d5d50c: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02d5d510: cbz     x0, #0x2d5d558                             
02d5d514: mov     x1, xzr                                    
02d5d518: bl      #0x5b4842c                                 UnityEngine.Transform::SetAsLastSibling
02d5d51c: adrp    x8, #0x6266000                             
02d5d520: ldr     x8, [x8, #0xac0]                           MS:MonoSingleton`1::get_Instance
02d5d524: ldr     x0, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d5d528: bl      #0x3769600                                 fn_3769600
02d5d52c: cbz     x0, #0x2d5d558                             
02d5d530: mov     w1, #1                                     
02d5d534: mov     x2, xzr                                    
02d5d538: bl      #0x2cacd8c                                 GameSession::SetActiveCharacter
02d5d53c: ldr     x0, [x19, #0x60]                           ._petAtHome
02d5d540: cbz     x0, #0x2d5d558                             
02d5d544: ldp     x20, x19, [sp, #0x10]                      
02d5d548: mov     w1, #1                                     
02d5d54c: mov     x2, xzr                                    
02d5d550: ldp     x30, x21, [sp], #0x20                      
02d5d554: b       #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d5d558: bl      #0x2b7105c                                 fn_2b7105c
## <OnBtnRemoveKeycapClick>b__27_0() -> void
---- Clicker.ScreenClickerCollection::<OnBtnRemoveKeycapClick>b__27_0 0x2d5d55c
02d5d55c: stp     x30, x19, [sp, #-0x10]!                    
02d5d560: mov     x19, x0                                    
02d5d564: bl      #0x2d5d0f4                                 Clicker.ScreenClickerCollection::DeleteCurrentKeycap
02d5d568: mov     x0, x19                                    
02d5d56c: ldp     x30, x19, [sp], #0x10                      
02d5d570: b       #0x2d5cbc4                                 Clicker.ScreenClickerCollection::BackToCollection
## <DeleteCurrentKeycap>b__28_0(ClickerSaveDataItem x) -> bool
---- Clicker.ScreenClickerCollection::<DeleteCurrentKeycap>b__28_0 0x2d5d574
02d5d574: cbz     x1, #0x2d5d58c                             
02d5d578: ldr     w8, [x1, #0x10]                            
02d5d57c: ldr     w9, [x0, #0x98]                            ._inspectIndex
02d5d580: cmp     w8, w9                                     
02d5d584: cset    w0, eq                                     
02d5d588: ret                                                
02d5d58c: str     x30, [sp, #-0x10]!                         
02d5d590: bl      #0x2b7105c                                 fn_2b7105c
## <OnBtnBackClick>b__29_0() -> void
---- Clicker.ScreenClickerCollection::<OnBtnBackClick>b__29_0 0x2d5d594
02d5d594: stp     x30, x21, [sp, #-0x20]!                    
02d5d598: stp     x20, x19, [sp, #0x10]                      
02d5d59c: adrp    x21, #0x6630000                            
02d5d5a0: adrp    x20, #0x626b000                            
02d5d5a4: mov     x19, x0                                    
02d5d5a8: ldrb    w8, [x21, #0x2d9]                          
02d5d5ac: ldr     x20, [x20, #0xda8]                         MS:MonoSingleton`1::get_Instance
02d5d5b0: tbnz    w8, #0, #0x2d5d5c8                         
02d5d5b4: adrp    x0, #0x626b000                             
02d5d5b8: ldr     x0, [x0, #0xda8]                           MS:MonoSingleton`1::get_Instance
02d5d5bc: bl      #0x2b70db0                                 fn_2b70db0
02d5d5c0: mov     w8, #1                                     
02d5d5c4: strb    w8, [x21, #0x2d9]                          
02d5d5c8: mov     x0, x19                                    
02d5d5cc: bl      #0x2d5cbc4                                 Clicker.ScreenClickerCollection::BackToCollection
02d5d5d0: ldr     x0, [x20]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d5d5d4: bl      #0x3769600                                 fn_3769600
02d5d5d8: cbz     x0, #0x2d5d5e8                             
02d5d5dc: ldp     x20, x19, [sp, #0x10]                      
02d5d5e0: ldp     x30, x21, [sp], #0x20                      
02d5d5e4: b       #0x2d5d5ec                                 Clicker.Light2DManager::ReleaseAllItem
02d5d5e8: bl      #0x2b7105c                                 fn_2b7105c
