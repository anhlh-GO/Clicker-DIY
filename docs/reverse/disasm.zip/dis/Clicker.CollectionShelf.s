#### CLASS Clicker.CollectionShelf parent= UnityEngine.MonoBehaviour
#   field _tfBottom                      UnityEngine.Transform                              off=0x20 attr=1 SerializeField
#   field _3ItemsHolding                 System.Collections.Generic.List`1<Clicker.CollectionKeycapItem> off=0x28 attr=1 SerializeField
#   field LimitBottomDragValue           float                                              off=0x30 attr=6 
#   field _limitTop                      UnityEngine.Transform                              off=0x38 attr=1 SerializeField
#   field _limitBottom                   UnityEngine.Transform                              off=0x40 attr=1 SerializeField
## get_TfBottom() -> UnityEngine.Transform
---- Clicker.CollectionShelf::get_TfBottom 0x2d6862c
02d6862c: ldr     x0, [x0, #0x20]                            ._tfBottom
02d68630: ret                                                
## get_ItemsHolding() -> System.Collections.Generic.List`1<Clicker.CollectionKeycapItem>
---- Clicker.CollectionShelf::get_ItemsHolding 0x2d68634
02d68634: ldr     x0, [x0, #0x28]                            ._3ItemsHolding
02d68638: ret                                                
## Update() -> void
---- Clicker.CollectionShelf::Update 0x2d6863c
02d6863c: str     d8, [sp, #-0x20]!                          
02d68640: str     x30, [sp, #8]                              
02d68644: stp     x20, x19, [sp, #0x10]                      
02d68648: mov     x1, xzr                                    
02d6864c: mov     x19, x0                                    
02d68650: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02d68654: cbz     x0, #0x2d68774                             
02d68658: mov     x1, xzr                                    
02d6865c: bl      #0x5b467ac                                 UnityEngine.Transform::get_position
02d68660: ldr     x0, [x19, #0x38]                           ._limitTop
02d68664: cbz     x0, #0x2d68774                             
02d68668: mov     x1, xzr                                    
02d6866c: fmov    s8, s1                                     
02d68670: bl      #0x5b467ac                                 UnityEngine.Transform::get_position
02d68674: fcmp    s8, s1                                     
02d68678: b.gt    #0x2d686b0                                 
02d6867c: mov     x0, x19                                    
02d68680: mov     x1, xzr                                    
02d68684: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02d68688: cbz     x0, #0x2d68774                             
02d6868c: mov     x1, xzr                                    
02d68690: bl      #0x5b467ac                                 UnityEngine.Transform::get_position
02d68694: ldr     x0, [x19, #0x40]                           ._limitBottom
02d68698: cbz     x0, #0x2d68774                             
02d6869c: mov     x1, xzr                                    
02d686a0: fmov    s8, s1                                     
02d686a4: bl      #0x5b467ac                                 UnityEngine.Transform::get_position
02d686a8: fcmp    s8, s1                                     
02d686ac: b.pl    #0x2d68700                                 
02d686b0: mov     x0, x19                                    
02d686b4: mov     x1, xzr                                    
02d686b8: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02d686bc: adrp    x20, #0x662f000                            
02d686c0: mov     x19, x0                                    
02d686c4: ldrb    w8, [x20, #0x91a]                          
02d686c8: cbnz    w8, #0x2d686e0                             
02d686cc: adrp    x0, #0x6264000                             
02d686d0: ldr     x0, [x0, #0xd8]                            T:UnityEngine.Vector3
02d686d4: bl      #0x2b70db0                                 fn_2b70db0
02d686d8: mov     w8, #1                                     
02d686dc: strb    w8, [x20, #0x91a]                          
02d686e0: cbz     x19, #0x2d68774                            
02d686e4: adrp    x8, #0x6264000                             
02d686e8: ldr     x8, [x8, #0xd8]                            T:UnityEngine.Vector3
02d686ec: ldr     x8, [x8]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d686f0: ldr     x8, [x8, #0xb8]                            MS:DG.Tweening.Core.Extensions::SetSpecialStartupMode
02d686f4: add     x9, x8, #8                                 &6264008
02d686f8: add     x10, x8, #4                                &6264004
02d686fc: b       #0x2d68750                                 
02d68700: mov     x0, x19                                    
02d68704: mov     x1, xzr                                    
02d68708: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02d6870c: adrp    x20, #0x662f000                            
02d68710: mov     x19, x0                                    
02d68714: ldrb    w8, [x20, #0xa74]                          
02d68718: cbnz    w8, #0x2d68730                             
02d6871c: adrp    x0, #0x6264000                             
02d68720: ldr     x0, [x0, #0xd8]                            T:UnityEngine.Vector3
02d68724: bl      #0x2b70db0                                 fn_2b70db0
02d68728: mov     w8, #1                                     
02d6872c: strb    w8, [x20, #0xa74]                          
02d68730: cbz     x19, #0x2d68774                            
02d68734: adrp    x8, #0x6264000                             
02d68738: ldr     x8, [x8, #0xd8]                            T:UnityEngine.Vector3
02d6873c: ldr     x8, [x8]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d68740: ldr     x10, [x8, #0xb8]                           MS:DG.Tweening.Core.Extensions::SetSpecialStartupMode
02d68744: add     x9, x10, #0x14                             
02d68748: add     x8, x10, #0xc                              
02d6874c: add     x10, x10, #0x10                            
02d68750: mov     x0, x19                                    
02d68754: ldp     x20, x19, [sp, #0x10]                      
02d68758: ldr     s0, [x8]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d6875c: ldr     s2, [x9]                                   
02d68760: mov     x1, xzr                                    
02d68764: ldr     s1, [x10]                                  
02d68768: ldr     x30, [sp, #8]                              
02d6876c: ldr     d8, [sp], #0x20                            
02d68770: b       #0x5b470cc                                 UnityEngine.Transform::set_localScale
02d68774: bl      #0x2b7105c                                 fn_2b7105c
## .ctor() -> void
---- Clicker.CollectionShelf::.ctor 0x2d68778
02d68778: mov     x1, xzr                                    
02d6877c: b       #0x5b397b0                                 UnityEngine.MonoBehaviour::.ctor
