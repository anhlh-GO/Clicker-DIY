#### CLASS BaseKeychainSyncData parent= object
#   field ShowIndex                      string                                             off=0x10 attr=6 
#   field SpriteName                     string                                             off=0x18 attr=6 
#   field LockType                       string                                             off=0x20 attr=6 
#   field value                          int                                                off=0x28 attr=6 
## .ctor() -> void
---- BaseKeychainSyncData::.ctor 0x2ca83a8
02ca83a8: mov     x1, xzr                                    
02ca83ac: b       #0x4e53e9c                                 System.Object::.ctor
