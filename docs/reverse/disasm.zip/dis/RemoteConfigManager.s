#### CLASS RemoteConfigManager/<RetryFetch>d__84 parent= System.ValueType
#   field <>1__state                     int                                                off=0x10 attr=6 
#   field <>t__builder                   System.Runtime.CompilerServices.AsyncVoidMethodBuilder off=0x18 attr=6 
#   field <>4__this                      RemoteConfigManager                                off=0x38 attr=6 
#   field <>u__1                         System.Runtime.CompilerServices.TaskAwaiter        off=0x40 attr=1 
## MoveNext() -> void
---- RemoteConfigManager/<RetryFetch>d__84::MoveNext 0x2ca3484
02ca3484: sub     sp, sp, #0x40                              
02ca3488: stp     x30, x21, [sp, #0x20]                      
02ca348c: stp     x20, x19, [sp, #0x30]                      
02ca3490: adrp    x20, #0x662f000                            
02ca3494: mov     x19, x0                                    
02ca3498: ldrb    w8, [x20, #0xabc]                          
02ca349c: tbnz    w8, #0, #0x2ca34cc                         
02ca34a0: adrp    x0, #0x6266000                             
02ca34a4: ldr     x0, [x0, #0xf0]                            MS:System.Runtime.CompilerServices.AsyncVoidMethodBuilder::AwaitUnsafeOnCompleted
02ca34a8: bl      #0x2b70db0                                 fn_2b70db0
02ca34ac: adrp    x0, #0x6264000                             
02ca34b0: ldr     x0, [x0, #0x848]                           T:System.Threading.Tasks.Task
02ca34b4: bl      #0x2b70db0                                 fn_2b70db0
02ca34b8: adrp    x0, #0x6266000                             
02ca34bc: ldr     x0, [x0, #0xf8]                            S:'Retry fetch in {0}s'
02ca34c0: bl      #0x2b70db0                                 fn_2b70db0
02ca34c4: mov     w8, #1                                     
02ca34c8: strb    w8, [x20, #0xabc]                          
02ca34cc: ldr     w8, [x19]                                  
02ca34d0: ldr     x20, [x19, #0x28]                          
02ca34d4: str     xzr, [sp, #0x18]                           
02ca34d8: str     wzr, [sp, #0x10]                           
02ca34dc: cbz     w8, #0x2ca35a0                             
02ca34e0: cbz     x20, #0x2ca3600                            
02ca34e4: adrp    x8, #0x6263000                             
02ca34e8: ldr     x8, [x8, #0x970]                           &6645c70(=0)
02ca34ec: ldr     w9, [x20, #0x24]                           [662f024]=600001500000000 f=0,2.40742e-35
02ca34f0: ldr     x0, [x8, #0x48]                            &6263098(=0)
02ca34f4: str     w9, [sp, #4]                               
02ca34f8: add     x1, sp, #4                                 
02ca34fc: bl      #0x2b70f38                                 fn_2b70f38
02ca3500: mov     x1, x0                                     
02ca3504: adrp    x8, #0x6266000                             
02ca3508: ldr     x8, [x8, #0xf8]                            S:'Retry fetch in {0}s'
02ca350c: ldr     x0, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca3510: mov     x2, xzr                                    
02ca3514: bl      #0x4c9d0ec                                 System.String::Format
02ca3518: bl      #0x2ca09f8                                 WLog::LogError
02ca351c: adrp    x8, #0x6264000                             
02ca3520: ldr     x8, [x8, #0x848]                           T:System.Threading.Tasks.Task
02ca3524: ldr     w21, [x20, #0x24]                          [662f024]=600001500000000 f=0,2.40742e-35
02ca3528: ldr     x0, [x8]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02ca352c: ldr     w8, [x0, #0xe4]                            [62660e4]=0 f=0,0
02ca3530: cbnz    w8, #0x2ca3538                             
02ca3534: bl      #0x2b70f30                                 fn_2b70f30
02ca3538: mov     w8, #0x3e8                                 
02ca353c: mul     w0, w21, w8                                
02ca3540: mov     x1, xzr                                    
02ca3544: bl      #0x4e8d608                                 System.Threading.Tasks.Task::Delay
02ca3548: cbz     x0, #0x2ca3604                             
02ca354c: mov     x1, xzr                                    
02ca3550: bl      #0x4e85740                                 System.Threading.Tasks.Task::GetAwaiter
02ca3554: str     x0, [sp, #0x18]                            
02ca3558: add     x0, sp, #0x18                              
02ca355c: mov     x1, xzr                                    
02ca3560: bl      #0x4d43364                                 System.Runtime.CompilerServices.TaskAwaiter::get_IsCompleted
02ca3564: tbnz    w0, #0, #0x2ca35b4                         
02ca3568: ldr     x8, [sp, #0x18]                            
02ca356c: mov     x0, x19                                    
02ca3570: str     wzr, [x19]                                 
02ca3574: str     x8, [x0, #0x30]!                           
02ca3578: mov     x1, xzr                                    
02ca357c: bl      #0x2b70d54                                 fn_2b70d54
02ca3580: adrp    x8, #0x6266000                             
02ca3584: ldr     x8, [x8, #0xf0]                            MS:System.Runtime.CompilerServices.AsyncVoidMethodBuilder::AwaitUnsafeOnCompleted
02ca3588: ldr     x3, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca358c: add     x0, x19, #8                                
02ca3590: add     x1, sp, #0x18                              
02ca3594: mov     x2, x19                                    
02ca3598: bl      #0x30be7c0                                 fn_30be7c0
02ca359c: b       #0x2ca35ec                                 
02ca35a0: ldr     x8, [x19, #0x30]                           
02ca35a4: mov     w9, #-1                                    
02ca35a8: str     xzr, [x19, #0x30]                          
02ca35ac: str     w9, [x19]                                  
02ca35b0: str     x8, [sp, #0x18]                            
02ca35b4: add     x0, sp, #0x18                              
02ca35b8: mov     x1, xzr                                    
02ca35bc: bl      #0x4d4342c                                 System.Runtime.CompilerServices.TaskAwaiter::GetResult
02ca35c0: cbz     x20, #0x2ca35fc                            
02ca35c4: mov     x0, x20                                    
02ca35c8: bl      #0x2ca0a84                                 RemoteConfigManager::FetchAndActivate
02ca35cc: ldp     w9, w8, [x20, #0x20]                       
02ca35d0: mov     x1, xzr                                    
02ca35d4: mul     w8, w9, w8                                 
02ca35d8: mov     w9, #-2                                    
02ca35dc: str     w9, [x19], #8                              
02ca35e0: mov     x0, x19                                    
02ca35e4: str     w8, [x20, #0x24]                           
02ca35e8: bl      #0x4d43b50                                 System.Runtime.CompilerServices.AsyncVoidMethodBuilder::SetResult
02ca35ec: ldp     x20, x19, [sp, #0x30]                      
02ca35f0: ldp     x30, x21, [sp, #0x20]                      
02ca35f4: add     sp, sp, #0x40                              
02ca35f8: ret                                                
02ca35fc: bl      #0x2b7105c                                 fn_2b7105c
02ca3600: bl      #0x2b7105c                                 fn_2b7105c
02ca3604: bl      #0x2b7105c                                 fn_2b7105c
02ca3608: b       #0x2ca3630                                 
02ca360c: b       #0x2ca3630                                 
02ca3610: b       #0x2ca3630                                 
02ca3614: b       #0x2ca3630                                 
02ca3618: b       #0x2ca3630                                 
02ca361c: b       #0x2ca3630                                 
02ca3620: b       #0x2ca3630                                 
02ca3624: b       #0x2ca3630                                 
02ca3628: b       #0x2ca3630                                 
02ca362c: b       #0x2ca3630                                 
02ca3630: mov     x20, x0                                    
02ca3634: cmp     w1, #1                                     
02ca3638: b.ne    #0x2ca36c8                                 
02ca363c: mov     x0, x20                                    
02ca3640: bl      #0x5e90260                                 fn_5e90260
02ca3644: mov     x20, x0                                    
02ca3648: adrp    x0, #0x6263000                             
02ca364c: ldr     x0, [x0, #0xae0]                           T:System.Exception
02ca3650: bl      #0x2b70dc4                                 fn_2b70dc4
02ca3654: ldr     x8, [x20]                                  &2b706c4(=eb01011ff9400808)
02ca3658: ldr     x1, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca365c: bl      #0x2b71464                                 fn_2b71464
02ca3660: tbz     w0, #0, #0x2ca36a0                         
02ca3664: ldrsw   x21, [sp, #0x10]                           
02ca3668: ldr     x20, [x20]                                 &2b706c4(=eb01011ff9400808)
02ca366c: add     x8, sp, #8                                 
02ca3670: str     x20, [x8, x21, lsl #3]                     
02ca3674: add     w8, w21, #1                                
02ca3678: str     w8, [sp, #0x10]                            
02ca367c: bl      #0x5e90270                                 fn_5e90270
02ca3680: mov     w8, #-2                                    
02ca3684: mov     x1, x20                                    
02ca3688: mov     x2, xzr                                    
02ca368c: str     w8, [x19], #8                              
02ca3690: mov     x0, x19                                    
02ca3694: bl      #0x4d43cc0                                 System.Runtime.CompilerServices.AsyncVoidMethodBuilder::SetException
02ca3698: str     w21, [sp, #0x10]                           
02ca369c: b       #0x2ca35ec                                 
02ca36a0: mov     w0, #8                                     
02ca36a4: bl      #0x5e90290                                 fn_5e90290
02ca36a8: ldr     x8, [x20]                                  &2b706c4(=eb01011ff9400808)
02ca36ac: str     x8, [x0]                                   
02ca36b0: adrp    x1, #0x5e96000                             
02ca36b4: add     x1, x1, #0x758                             &5e96758
02ca36b8: mov     x2, xzr                                    
02ca36bc: bl      #0x5e902a0                                 fn_5e902a0
02ca36c0: mov     x20, x0                                    
02ca36c4: bl      #0x5e90270                                 fn_5e90270
02ca36c8: mov     x0, x20                                    
02ca36cc: bl      #0x2c6051c                                 fn_2c6051c
02ca36d0: bl      #0x27369b8                                 fn_27369b8
## SetStateMachine(System.Runtime.CompilerServices.IAsyncStateMachine stateMachine) -> void
---- RemoteConfigManager/<RetryFetch>d__84::SetStateMachine 0x2ca36d4
02ca36d4: add     x0, x0, #8                                 
02ca36d8: mov     x2, xzr                                    
02ca36dc: b       #0x4d43a8c                                 System.Runtime.CompilerServices.AsyncVoidMethodBuilder::SetStateMachine
#### CLASS RemoteConfigManager parent= UnityEngine.MonoBehaviour
#   field <inter_ad_on_off>k__BackingField bool                                               off=0x0 attr=11 CompilerGeneratedAttribute
#   field <mrec_ad_on_off>k__BackingField bool                                               off=0x1 attr=11 CompilerGeneratedAttribute
#   field <banner_ad_on_off>k__BackingField bool                                               off=0x2 attr=11 CompilerGeneratedAttribute
#   field <open_ad_on_off>k__BackingField bool                                               off=0x3 attr=11 CompilerGeneratedAttribute
#   field <inter_ad_capping_time>k__BackingField int                                                off=0x4 attr=11 CompilerGeneratedAttribute
#   field <open_ad_capping_time>k__BackingField int                                                off=0x8 attr=11 CompilerGeneratedAttribute
#   field <level_show_popuprate>k__BackingField int                                                off=0xc attr=11 CompilerGeneratedAttribute
#   field <data_config_type>k__BackingField int                                                off=0x10 attr=11 CompilerGeneratedAttribute
#   field <native_fullscreen_on_off>k__BackingField bool                                               off=0x14 attr=11 CompilerGeneratedAttribute
#   field <popup_rate_on_off>k__BackingField bool                                               off=0x15 attr=11 CompilerGeneratedAttribute
#   field <open_ad_id>k__BackingField    string                                             off=0x18 attr=11 CompilerGeneratedAttribute
#   field <native_full_srceen_id>k__BackingField string                                             off=0x20 attr=11 CompilerGeneratedAttribute
#   field <native_full_srceen_time_showbtn>k__BackingField int                                                off=0x28 attr=11 CompilerGeneratedAttribute
#   field <mrec_ad_id>k__BackingField    string                                             off=0x30 attr=11 CompilerGeneratedAttribute
#   field <force_update_version>k__BackingField bool                                               off=0x38 attr=11 CompilerGeneratedAttribute
#   field <native_banner_ad_on_off>k__BackingField bool                                               off=0x39 attr=11 CompilerGeneratedAttribute
#   field <native_collap_ad_on_off>k__BackingField bool                                               off=0x3a attr=11 CompilerGeneratedAttribute
#   field <banner_native_refresh_time>k__BackingField int                                                off=0x3c attr=11 CompilerGeneratedAttribute
#   field <native_banner_id>k__BackingField string                                             off=0x40 attr=11 CompilerGeneratedAttribute
#   field <native_collap_id>k__BackingField string                                             off=0x48 attr=11 CompilerGeneratedAttribute
#   field _currentRetry                  int                                                off=0x20 attr=1 
#   field _initRetryDelay                int                                                off=0x24 attr=1 
#   field defaults                       System.Collections.Generic.Dictionary`2<string,object> off=0x28 attr=1 
## get_inter_ad_on_off() -> bool
---- RemoteConfigManager::get_inter_ad_on_off 0x2ca0f18
02ca0f18: str     x30, [sp, #-0x20]!                         
02ca0f1c: stp     x20, x19, [sp, #0x10]                      
02ca0f20: adrp    x20, #0x662f000                            
02ca0f24: adrp    x19, #0x6264000                            
02ca0f28: ldrb    w8, [x20, #0xa8f]                          
02ca0f2c: ldr     x19, [x19, #0xfc0]                         T:RemoteConfigManager
02ca0f30: tbnz    w8, #0, #0x2ca0f48                         
02ca0f34: adrp    x0, #0x6264000                             
02ca0f38: ldr     x0, [x0, #0xfc0]                           T:RemoteConfigManager
02ca0f3c: bl      #0x2b70db0                                 fn_2b70db0
02ca0f40: mov     w8, #1                                     
02ca0f44: strb    w8, [x20, #0xa8f]                          
02ca0f48: ldr     x0, [x19]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02ca0f4c: ldr     w8, [x0, #0xe4]                            [62640e4]=0 f=0,0
02ca0f50: cbnz    w8, #0x2ca0f5c                             
02ca0f54: bl      #0x2b70f30                                 fn_2b70f30
02ca0f58: ldr     x0, [x19]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02ca0f5c: ldr     x8, [x0, #0xb8]                            MS:DG.Tweening.Core.Extensions::SetSpecialStartupMode
02ca0f60: ldp     x20, x19, [sp, #0x10]                      
02ca0f64: ldrb    w0, [x8]                                   
02ca0f68: ldr     x30, [sp], #0x20                           
02ca0f6c: ret                                                
## set_inter_ad_on_off(bool value) -> void
---- RemoteConfigManager::set_inter_ad_on_off 0x2ca0f70
02ca0f70: stp     x30, x21, [sp, #-0x20]!                    
02ca0f74: stp     x20, x19, [sp, #0x10]                      
02ca0f78: adrp    x21, #0x662f000                            
02ca0f7c: adrp    x20, #0x6264000                            
02ca0f80: mov     w19, w0                                    
02ca0f84: ldrb    w8, [x21, #0xa90]                          
02ca0f88: ldr     x20, [x20, #0xfc0]                         T:RemoteConfigManager
02ca0f8c: tbnz    w8, #0, #0x2ca0fa4                         
02ca0f90: adrp    x0, #0x6264000                             
02ca0f94: ldr     x0, [x0, #0xfc0]                           T:RemoteConfigManager
02ca0f98: bl      #0x2b70db0                                 fn_2b70db0
02ca0f9c: mov     w8, #1                                     
02ca0fa0: strb    w8, [x21, #0xa90]                          
02ca0fa4: ldr     x0, [x20]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02ca0fa8: ldr     w8, [x0, #0xe4]                            [62640e4]=0 f=0,0
02ca0fac: cbnz    w8, #0x2ca0fb8                             
02ca0fb0: bl      #0x2b70f30                                 fn_2b70f30
02ca0fb4: ldr     x0, [x20]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02ca0fb8: ldr     x8, [x0, #0xb8]                            MS:DG.Tweening.Core.Extensions::SetSpecialStartupMode
02ca0fbc: and     w9, w19, #1                                
02ca0fc0: ldp     x20, x19, [sp, #0x10]                      
02ca0fc4: strb    w9, [x8]                                   
02ca0fc8: ldp     x30, x21, [sp], #0x20                      
02ca0fcc: ret                                                
## get_mrec_ad_on_off() -> bool
---- RemoteConfigManager::get_mrec_ad_on_off 0x2ca0fd0
02ca0fd0: str     x30, [sp, #-0x20]!                         
02ca0fd4: stp     x20, x19, [sp, #0x10]                      
02ca0fd8: adrp    x20, #0x662f000                            
02ca0fdc: adrp    x19, #0x6264000                            
02ca0fe0: ldrb    w8, [x20, #0xa91]                          
02ca0fe4: ldr     x19, [x19, #0xfc0]                         T:RemoteConfigManager
02ca0fe8: tbnz    w8, #0, #0x2ca1000                         
02ca0fec: adrp    x0, #0x6264000                             
02ca0ff0: ldr     x0, [x0, #0xfc0]                           T:RemoteConfigManager
02ca0ff4: bl      #0x2b70db0                                 fn_2b70db0
02ca0ff8: mov     w8, #1                                     
02ca0ffc: strb    w8, [x20, #0xa91]                          
02ca1000: ldr     x0, [x19]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02ca1004: ldr     w8, [x0, #0xe4]                            [62640e4]=0 f=0,0
02ca1008: cbnz    w8, #0x2ca1014                             
02ca100c: bl      #0x2b70f30                                 fn_2b70f30
02ca1010: ldr     x0, [x19]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02ca1014: ldr     x8, [x0, #0xb8]                            MS:DG.Tweening.Core.Extensions::SetSpecialStartupMode
02ca1018: ldp     x20, x19, [sp, #0x10]                      
02ca101c: ldrb    w0, [x8, #1]                               
02ca1020: ldr     x30, [sp], #0x20                           
02ca1024: ret                                                
## set_mrec_ad_on_off(bool value) -> void
---- RemoteConfigManager::set_mrec_ad_on_off 0x2ca1028
02ca1028: stp     x30, x21, [sp, #-0x20]!                    
02ca102c: stp     x20, x19, [sp, #0x10]                      
02ca1030: adrp    x21, #0x662f000                            
02ca1034: adrp    x20, #0x6264000                            
02ca1038: mov     w19, w0                                    
02ca103c: ldrb    w8, [x21, #0xa92]                          
02ca1040: ldr     x20, [x20, #0xfc0]                         T:RemoteConfigManager
02ca1044: tbnz    w8, #0, #0x2ca105c                         
02ca1048: adrp    x0, #0x6264000                             
02ca104c: ldr     x0, [x0, #0xfc0]                           T:RemoteConfigManager
02ca1050: bl      #0x2b70db0                                 fn_2b70db0
02ca1054: mov     w8, #1                                     
02ca1058: strb    w8, [x21, #0xa92]                          
02ca105c: ldr     x0, [x20]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02ca1060: ldr     w8, [x0, #0xe4]                            [62640e4]=0 f=0,0
02ca1064: cbnz    w8, #0x2ca1070                             
02ca1068: bl      #0x2b70f30                                 fn_2b70f30
02ca106c: ldr     x0, [x20]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02ca1070: ldr     x8, [x0, #0xb8]                            MS:DG.Tweening.Core.Extensions::SetSpecialStartupMode
02ca1074: and     w9, w19, #1                                
02ca1078: ldp     x20, x19, [sp, #0x10]                      
02ca107c: strb    w9, [x8, #1]                               
02ca1080: ldp     x30, x21, [sp], #0x20                      
02ca1084: ret                                                
## get_banner_ad_on_off() -> bool
---- RemoteConfigManager::get_banner_ad_on_off 0x2ca1088
02ca1088: str     x30, [sp, #-0x20]!                         
02ca108c: stp     x20, x19, [sp, #0x10]                      
02ca1090: adrp    x20, #0x662f000                            
02ca1094: adrp    x19, #0x6264000                            
02ca1098: ldrb    w8, [x20, #0xa93]                          
02ca109c: ldr     x19, [x19, #0xfc0]                         T:RemoteConfigManager
02ca10a0: tbnz    w8, #0, #0x2ca10b8                         
02ca10a4: adrp    x0, #0x6264000                             
02ca10a8: ldr     x0, [x0, #0xfc0]                           T:RemoteConfigManager
02ca10ac: bl      #0x2b70db0                                 fn_2b70db0
02ca10b0: mov     w8, #1                                     
02ca10b4: strb    w8, [x20, #0xa93]                          
02ca10b8: ldr     x0, [x19]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02ca10bc: ldr     w8, [x0, #0xe4]                            [62640e4]=0 f=0,0
02ca10c0: cbnz    w8, #0x2ca10cc                             
02ca10c4: bl      #0x2b70f30                                 fn_2b70f30
02ca10c8: ldr     x0, [x19]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02ca10cc: ldr     x8, [x0, #0xb8]                            MS:DG.Tweening.Core.Extensions::SetSpecialStartupMode
02ca10d0: ldp     x20, x19, [sp, #0x10]                      
02ca10d4: ldrb    w0, [x8, #2]                               
02ca10d8: ldr     x30, [sp], #0x20                           
02ca10dc: ret                                                
## set_banner_ad_on_off(bool value) -> void
---- RemoteConfigManager::set_banner_ad_on_off 0x2ca10e0
02ca10e0: stp     x30, x21, [sp, #-0x20]!                    
02ca10e4: stp     x20, x19, [sp, #0x10]                      
02ca10e8: adrp    x21, #0x662f000                            
02ca10ec: adrp    x20, #0x6264000                            
02ca10f0: mov     w19, w0                                    
02ca10f4: ldrb    w8, [x21, #0xa94]                          
02ca10f8: ldr     x20, [x20, #0xfc0]                         T:RemoteConfigManager
02ca10fc: tbnz    w8, #0, #0x2ca1114                         
02ca1100: adrp    x0, #0x6264000                             
02ca1104: ldr     x0, [x0, #0xfc0]                           T:RemoteConfigManager
02ca1108: bl      #0x2b70db0                                 fn_2b70db0
02ca110c: mov     w8, #1                                     
02ca1110: strb    w8, [x21, #0xa94]                          
02ca1114: ldr     x0, [x20]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02ca1118: ldr     w8, [x0, #0xe4]                            [62640e4]=0 f=0,0
02ca111c: cbnz    w8, #0x2ca1128                             
02ca1120: bl      #0x2b70f30                                 fn_2b70f30
02ca1124: ldr     x0, [x20]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02ca1128: ldr     x8, [x0, #0xb8]                            MS:DG.Tweening.Core.Extensions::SetSpecialStartupMode
02ca112c: and     w9, w19, #1                                
02ca1130: ldp     x20, x19, [sp, #0x10]                      
02ca1134: strb    w9, [x8, #2]                               
02ca1138: ldp     x30, x21, [sp], #0x20                      
02ca113c: ret                                                
## get_open_ad_on_off() -> bool
---- RemoteConfigManager::get_open_ad_on_off 0x2ca1140
02ca1140: str     x30, [sp, #-0x20]!                         
02ca1144: stp     x20, x19, [sp, #0x10]                      
02ca1148: adrp    x20, #0x662f000                            
02ca114c: adrp    x19, #0x6264000                            
02ca1150: ldrb    w8, [x20, #0xa95]                          
02ca1154: ldr     x19, [x19, #0xfc0]                         T:RemoteConfigManager
02ca1158: tbnz    w8, #0, #0x2ca1170                         
02ca115c: adrp    x0, #0x6264000                             
02ca1160: ldr     x0, [x0, #0xfc0]                           T:RemoteConfigManager
02ca1164: bl      #0x2b70db0                                 fn_2b70db0
02ca1168: mov     w8, #1                                     
02ca116c: strb    w8, [x20, #0xa95]                          
02ca1170: ldr     x0, [x19]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02ca1174: ldr     w8, [x0, #0xe4]                            [62640e4]=0 f=0,0
02ca1178: cbnz    w8, #0x2ca1184                             
02ca117c: bl      #0x2b70f30                                 fn_2b70f30
02ca1180: ldr     x0, [x19]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02ca1184: ldr     x8, [x0, #0xb8]                            MS:DG.Tweening.Core.Extensions::SetSpecialStartupMode
02ca1188: ldp     x20, x19, [sp, #0x10]                      
02ca118c: ldrb    w0, [x8, #3]                               
02ca1190: ldr     x30, [sp], #0x20                           
02ca1194: ret                                                
## set_open_ad_on_off(bool value) -> void
---- RemoteConfigManager::set_open_ad_on_off 0x2ca1198
02ca1198: stp     x30, x21, [sp, #-0x20]!                    
02ca119c: stp     x20, x19, [sp, #0x10]                      
02ca11a0: adrp    x21, #0x662f000                            
02ca11a4: adrp    x20, #0x6264000                            
02ca11a8: mov     w19, w0                                    
02ca11ac: ldrb    w8, [x21, #0xa96]                          
02ca11b0: ldr     x20, [x20, #0xfc0]                         T:RemoteConfigManager
02ca11b4: tbnz    w8, #0, #0x2ca11cc                         
02ca11b8: adrp    x0, #0x6264000                             
02ca11bc: ldr     x0, [x0, #0xfc0]                           T:RemoteConfigManager
02ca11c0: bl      #0x2b70db0                                 fn_2b70db0
02ca11c4: mov     w8, #1                                     
02ca11c8: strb    w8, [x21, #0xa96]                          
02ca11cc: ldr     x0, [x20]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02ca11d0: ldr     w8, [x0, #0xe4]                            [62640e4]=0 f=0,0
02ca11d4: cbnz    w8, #0x2ca11e0                             
02ca11d8: bl      #0x2b70f30                                 fn_2b70f30
02ca11dc: ldr     x0, [x20]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02ca11e0: ldr     x8, [x0, #0xb8]                            MS:DG.Tweening.Core.Extensions::SetSpecialStartupMode
02ca11e4: and     w9, w19, #1                                
02ca11e8: ldp     x20, x19, [sp, #0x10]                      
02ca11ec: strb    w9, [x8, #3]                               
02ca11f0: ldp     x30, x21, [sp], #0x20                      
02ca11f4: ret                                                
## get_inter_ad_capping_time() -> int
---- RemoteConfigManager::get_inter_ad_capping_time 0x2ca11f8
02ca11f8: str     x30, [sp, #-0x20]!                         
02ca11fc: stp     x20, x19, [sp, #0x10]                      
02ca1200: adrp    x20, #0x662f000                            
02ca1204: adrp    x19, #0x6264000                            
02ca1208: ldrb    w8, [x20, #0xa97]                          
02ca120c: ldr     x19, [x19, #0xfc0]                         T:RemoteConfigManager
02ca1210: tbnz    w8, #0, #0x2ca1228                         
02ca1214: adrp    x0, #0x6264000                             
02ca1218: ldr     x0, [x0, #0xfc0]                           T:RemoteConfigManager
02ca121c: bl      #0x2b70db0                                 fn_2b70db0
02ca1220: mov     w8, #1                                     
02ca1224: strb    w8, [x20, #0xa97]                          
02ca1228: ldr     x0, [x19]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02ca122c: ldr     w8, [x0, #0xe4]                            [62640e4]=0 f=0,0
02ca1230: cbnz    w8, #0x2ca123c                             
02ca1234: bl      #0x2b70f30                                 fn_2b70f30
02ca1238: ldr     x0, [x19]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02ca123c: ldr     x8, [x0, #0xb8]                            MS:DG.Tweening.Core.Extensions::SetSpecialStartupMode
02ca1240: ldp     x20, x19, [sp, #0x10]                      
02ca1244: ldr     w0, [x8, #4]                               
02ca1248: ldr     x30, [sp], #0x20                           
02ca124c: ret                                                
## set_inter_ad_capping_time(int value) -> void
---- RemoteConfigManager::set_inter_ad_capping_time 0x2ca1250
02ca1250: stp     x30, x21, [sp, #-0x20]!                    
02ca1254: stp     x20, x19, [sp, #0x10]                      
02ca1258: adrp    x21, #0x662f000                            
02ca125c: adrp    x20, #0x6264000                            
02ca1260: mov     w19, w0                                    
02ca1264: ldrb    w8, [x21, #0xa98]                          
02ca1268: ldr     x20, [x20, #0xfc0]                         T:RemoteConfigManager
02ca126c: tbnz    w8, #0, #0x2ca1284                         
02ca1270: adrp    x0, #0x6264000                             
02ca1274: ldr     x0, [x0, #0xfc0]                           T:RemoteConfigManager
02ca1278: bl      #0x2b70db0                                 fn_2b70db0
02ca127c: mov     w8, #1                                     
02ca1280: strb    w8, [x21, #0xa98]                          
02ca1284: ldr     x0, [x20]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02ca1288: ldr     w8, [x0, #0xe4]                            [62640e4]=0 f=0,0
02ca128c: cbnz    w8, #0x2ca1298                             
02ca1290: bl      #0x2b70f30                                 fn_2b70f30
02ca1294: ldr     x0, [x20]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02ca1298: ldr     x8, [x0, #0xb8]                            MS:DG.Tweening.Core.Extensions::SetSpecialStartupMode
02ca129c: str     w19, [x8, #4]                              
02ca12a0: ldp     x20, x19, [sp, #0x10]                      
02ca12a4: ldp     x30, x21, [sp], #0x20                      
02ca12a8: ret                                                
## get_open_ad_capping_time() -> int
---- RemoteConfigManager::get_open_ad_capping_time 0x2ca12ac
02ca12ac: str     x30, [sp, #-0x20]!                         
02ca12b0: stp     x20, x19, [sp, #0x10]                      
02ca12b4: adrp    x20, #0x662f000                            
02ca12b8: adrp    x19, #0x6264000                            
02ca12bc: ldrb    w8, [x20, #0xa99]                          
02ca12c0: ldr     x19, [x19, #0xfc0]                         T:RemoteConfigManager
02ca12c4: tbnz    w8, #0, #0x2ca12dc                         
02ca12c8: adrp    x0, #0x6264000                             
02ca12cc: ldr     x0, [x0, #0xfc0]                           T:RemoteConfigManager
02ca12d0: bl      #0x2b70db0                                 fn_2b70db0
02ca12d4: mov     w8, #1                                     
02ca12d8: strb    w8, [x20, #0xa99]                          
02ca12dc: ldr     x0, [x19]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02ca12e0: ldr     w8, [x0, #0xe4]                            [62640e4]=0 f=0,0
02ca12e4: cbnz    w8, #0x2ca12f0                             
02ca12e8: bl      #0x2b70f30                                 fn_2b70f30
02ca12ec: ldr     x0, [x19]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02ca12f0: ldr     x8, [x0, #0xb8]                            MS:DG.Tweening.Core.Extensions::SetSpecialStartupMode
02ca12f4: ldp     x20, x19, [sp, #0x10]                      
02ca12f8: ldr     w0, [x8, #8]                               
02ca12fc: ldr     x30, [sp], #0x20                           
02ca1300: ret                                                
## set_open_ad_capping_time(int value) -> void
---- RemoteConfigManager::set_open_ad_capping_time 0x2ca1304
02ca1304: stp     x30, x21, [sp, #-0x20]!                    
02ca1308: stp     x20, x19, [sp, #0x10]                      
02ca130c: adrp    x21, #0x662f000                            
02ca1310: adrp    x20, #0x6264000                            
02ca1314: mov     w19, w0                                    
02ca1318: ldrb    w8, [x21, #0xa9a]                          
02ca131c: ldr     x20, [x20, #0xfc0]                         T:RemoteConfigManager
02ca1320: tbnz    w8, #0, #0x2ca1338                         
02ca1324: adrp    x0, #0x6264000                             
02ca1328: ldr     x0, [x0, #0xfc0]                           T:RemoteConfigManager
02ca132c: bl      #0x2b70db0                                 fn_2b70db0
02ca1330: mov     w8, #1                                     
02ca1334: strb    w8, [x21, #0xa9a]                          
02ca1338: ldr     x0, [x20]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02ca133c: ldr     w8, [x0, #0xe4]                            [62640e4]=0 f=0,0
02ca1340: cbnz    w8, #0x2ca134c                             
02ca1344: bl      #0x2b70f30                                 fn_2b70f30
02ca1348: ldr     x0, [x20]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02ca134c: ldr     x8, [x0, #0xb8]                            MS:DG.Tweening.Core.Extensions::SetSpecialStartupMode
02ca1350: str     w19, [x8, #8]                              
02ca1354: ldp     x20, x19, [sp, #0x10]                      
02ca1358: ldp     x30, x21, [sp], #0x20                      
02ca135c: ret                                                
## get_level_show_popuprate() -> int
---- RemoteConfigManager::get_level_show_popuprate 0x2ca1360
02ca1360: str     x30, [sp, #-0x20]!                         
02ca1364: stp     x20, x19, [sp, #0x10]                      
02ca1368: adrp    x20, #0x662f000                            
02ca136c: adrp    x19, #0x6264000                            
02ca1370: ldrb    w8, [x20, #0xa9b]                          
02ca1374: ldr     x19, [x19, #0xfc0]                         T:RemoteConfigManager
02ca1378: tbnz    w8, #0, #0x2ca1390                         
02ca137c: adrp    x0, #0x6264000                             
02ca1380: ldr     x0, [x0, #0xfc0]                           T:RemoteConfigManager
02ca1384: bl      #0x2b70db0                                 fn_2b70db0
02ca1388: mov     w8, #1                                     
02ca138c: strb    w8, [x20, #0xa9b]                          
02ca1390: ldr     x0, [x19]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02ca1394: ldr     w8, [x0, #0xe4]                            [62640e4]=0 f=0,0
02ca1398: cbnz    w8, #0x2ca13a4                             
02ca139c: bl      #0x2b70f30                                 fn_2b70f30
02ca13a0: ldr     x0, [x19]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02ca13a4: ldr     x8, [x0, #0xb8]                            MS:DG.Tweening.Core.Extensions::SetSpecialStartupMode
02ca13a8: ldp     x20, x19, [sp, #0x10]                      
02ca13ac: ldr     w0, [x8, #0xc]                             
02ca13b0: ldr     x30, [sp], #0x20                           
02ca13b4: ret                                                
## set_level_show_popuprate(int value) -> void
---- RemoteConfigManager::set_level_show_popuprate 0x2ca13b8
02ca13b8: stp     x30, x21, [sp, #-0x20]!                    
02ca13bc: stp     x20, x19, [sp, #0x10]                      
02ca13c0: adrp    x21, #0x662f000                            
02ca13c4: adrp    x20, #0x6264000                            
02ca13c8: mov     w19, w0                                    
02ca13cc: ldrb    w8, [x21, #0xa9c]                          
02ca13d0: ldr     x20, [x20, #0xfc0]                         T:RemoteConfigManager
02ca13d4: tbnz    w8, #0, #0x2ca13ec                         
02ca13d8: adrp    x0, #0x6264000                             
02ca13dc: ldr     x0, [x0, #0xfc0]                           T:RemoteConfigManager
02ca13e0: bl      #0x2b70db0                                 fn_2b70db0
02ca13e4: mov     w8, #1                                     
02ca13e8: strb    w8, [x21, #0xa9c]                          
02ca13ec: ldr     x0, [x20]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02ca13f0: ldr     w8, [x0, #0xe4]                            [62640e4]=0 f=0,0
02ca13f4: cbnz    w8, #0x2ca1400                             
02ca13f8: bl      #0x2b70f30                                 fn_2b70f30
02ca13fc: ldr     x0, [x20]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02ca1400: ldr     x8, [x0, #0xb8]                            MS:DG.Tweening.Core.Extensions::SetSpecialStartupMode
02ca1404: str     w19, [x8, #0xc]                            
02ca1408: ldp     x20, x19, [sp, #0x10]                      
02ca140c: ldp     x30, x21, [sp], #0x20                      
02ca1410: ret                                                
## get_data_config_type() -> int
---- RemoteConfigManager::get_data_config_type 0x2ca1414
02ca1414: str     x30, [sp, #-0x20]!                         
02ca1418: stp     x20, x19, [sp, #0x10]                      
02ca141c: adrp    x20, #0x662f000                            
02ca1420: adrp    x19, #0x6264000                            
02ca1424: ldrb    w8, [x20, #0xa9d]                          
02ca1428: ldr     x19, [x19, #0xfc0]                         T:RemoteConfigManager
02ca142c: tbnz    w8, #0, #0x2ca1444                         
02ca1430: adrp    x0, #0x6264000                             
02ca1434: ldr     x0, [x0, #0xfc0]                           T:RemoteConfigManager
02ca1438: bl      #0x2b70db0                                 fn_2b70db0
02ca143c: mov     w8, #1                                     
02ca1440: strb    w8, [x20, #0xa9d]                          
02ca1444: ldr     x0, [x19]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02ca1448: ldr     w8, [x0, #0xe4]                            [62640e4]=0 f=0,0
02ca144c: cbnz    w8, #0x2ca1458                             
02ca1450: bl      #0x2b70f30                                 fn_2b70f30
02ca1454: ldr     x0, [x19]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02ca1458: ldr     x8, [x0, #0xb8]                            MS:DG.Tweening.Core.Extensions::SetSpecialStartupMode
02ca145c: ldp     x20, x19, [sp, #0x10]                      
02ca1460: ldr     w0, [x8, #0x10]                            
02ca1464: ldr     x30, [sp], #0x20                           
02ca1468: ret                                                
## set_data_config_type(int value) -> void
---- RemoteConfigManager::set_data_config_type 0x2ca146c
02ca146c: stp     x30, x21, [sp, #-0x20]!                    
02ca1470: stp     x20, x19, [sp, #0x10]                      
02ca1474: adrp    x21, #0x662f000                            
02ca1478: adrp    x20, #0x6264000                            
02ca147c: mov     w19, w0                                    
02ca1480: ldrb    w8, [x21, #0xa9e]                          
02ca1484: ldr     x20, [x20, #0xfc0]                         T:RemoteConfigManager
02ca1488: tbnz    w8, #0, #0x2ca14a0                         
02ca148c: adrp    x0, #0x6264000                             
02ca1490: ldr     x0, [x0, #0xfc0]                           T:RemoteConfigManager
02ca1494: bl      #0x2b70db0                                 fn_2b70db0
02ca1498: mov     w8, #1                                     
02ca149c: strb    w8, [x21, #0xa9e]                          
02ca14a0: ldr     x0, [x20]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02ca14a4: ldr     w8, [x0, #0xe4]                            [62640e4]=0 f=0,0
02ca14a8: cbnz    w8, #0x2ca14b4                             
02ca14ac: bl      #0x2b70f30                                 fn_2b70f30
02ca14b0: ldr     x0, [x20]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02ca14b4: ldr     x8, [x0, #0xb8]                            MS:DG.Tweening.Core.Extensions::SetSpecialStartupMode
02ca14b8: str     w19, [x8, #0x10]                           
02ca14bc: ldp     x20, x19, [sp, #0x10]                      
02ca14c0: ldp     x30, x21, [sp], #0x20                      
02ca14c4: ret                                                
## get_native_fullscreen_on_off() -> bool
---- RemoteConfigManager::get_native_fullscreen_on_off 0x2ca14c8
02ca14c8: str     x30, [sp, #-0x20]!                         
02ca14cc: stp     x20, x19, [sp, #0x10]                      
02ca14d0: adrp    x20, #0x662f000                            
02ca14d4: adrp    x19, #0x6264000                            
02ca14d8: ldrb    w8, [x20, #0xa9f]                          
02ca14dc: ldr     x19, [x19, #0xfc0]                         T:RemoteConfigManager
02ca14e0: tbnz    w8, #0, #0x2ca14f8                         
02ca14e4: adrp    x0, #0x6264000                             
02ca14e8: ldr     x0, [x0, #0xfc0]                           T:RemoteConfigManager
02ca14ec: bl      #0x2b70db0                                 fn_2b70db0
02ca14f0: mov     w8, #1                                     
02ca14f4: strb    w8, [x20, #0xa9f]                          
02ca14f8: ldr     x0, [x19]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02ca14fc: ldr     w8, [x0, #0xe4]                            [62640e4]=0 f=0,0
02ca1500: cbnz    w8, #0x2ca150c                             
02ca1504: bl      #0x2b70f30                                 fn_2b70f30
02ca1508: ldr     x0, [x19]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02ca150c: ldr     x8, [x0, #0xb8]                            MS:DG.Tweening.Core.Extensions::SetSpecialStartupMode
02ca1510: ldp     x20, x19, [sp, #0x10]                      
02ca1514: ldrb    w0, [x8, #0x14]                            
02ca1518: ldr     x30, [sp], #0x20                           
02ca151c: ret                                                
## set_native_fullscreen_on_off(bool value) -> void
---- RemoteConfigManager::set_native_fullscreen_on_off 0x2ca1520
02ca1520: stp     x30, x21, [sp, #-0x20]!                    
02ca1524: stp     x20, x19, [sp, #0x10]                      
02ca1528: adrp    x21, #0x662f000                            
02ca152c: adrp    x20, #0x6264000                            
02ca1530: mov     w19, w0                                    
02ca1534: ldrb    w8, [x21, #0xaa0]                          
02ca1538: ldr     x20, [x20, #0xfc0]                         T:RemoteConfigManager
02ca153c: tbnz    w8, #0, #0x2ca1554                         
02ca1540: adrp    x0, #0x6264000                             
02ca1544: ldr     x0, [x0, #0xfc0]                           T:RemoteConfigManager
02ca1548: bl      #0x2b70db0                                 fn_2b70db0
02ca154c: mov     w8, #1                                     
02ca1550: strb    w8, [x21, #0xaa0]                          
02ca1554: ldr     x0, [x20]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02ca1558: ldr     w8, [x0, #0xe4]                            [62640e4]=0 f=0,0
02ca155c: cbnz    w8, #0x2ca1568                             
02ca1560: bl      #0x2b70f30                                 fn_2b70f30
02ca1564: ldr     x0, [x20]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02ca1568: ldr     x8, [x0, #0xb8]                            MS:DG.Tweening.Core.Extensions::SetSpecialStartupMode
02ca156c: and     w9, w19, #1                                
02ca1570: ldp     x20, x19, [sp, #0x10]                      
02ca1574: strb    w9, [x8, #0x14]                            
02ca1578: ldp     x30, x21, [sp], #0x20                      
02ca157c: ret                                                
## get_popup_rate_on_off() -> bool
---- RemoteConfigManager::get_popup_rate_on_off 0x2ca1580
02ca1580: str     x30, [sp, #-0x20]!                         
02ca1584: stp     x20, x19, [sp, #0x10]                      
02ca1588: adrp    x20, #0x662f000                            
02ca158c: adrp    x19, #0x6264000                            
02ca1590: ldrb    w8, [x20, #0xaa1]                          
02ca1594: ldr     x19, [x19, #0xfc0]                         T:RemoteConfigManager
02ca1598: tbnz    w8, #0, #0x2ca15b0                         
02ca159c: adrp    x0, #0x6264000                             
02ca15a0: ldr     x0, [x0, #0xfc0]                           T:RemoteConfigManager
02ca15a4: bl      #0x2b70db0                                 fn_2b70db0
02ca15a8: mov     w8, #1                                     
02ca15ac: strb    w8, [x20, #0xaa1]                          
02ca15b0: ldr     x0, [x19]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02ca15b4: ldr     w8, [x0, #0xe4]                            [62640e4]=0 f=0,0
02ca15b8: cbnz    w8, #0x2ca15c4                             
02ca15bc: bl      #0x2b70f30                                 fn_2b70f30
02ca15c0: ldr     x0, [x19]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02ca15c4: ldr     x8, [x0, #0xb8]                            MS:DG.Tweening.Core.Extensions::SetSpecialStartupMode
02ca15c8: ldp     x20, x19, [sp, #0x10]                      
02ca15cc: ldrb    w0, [x8, #0x15]                            
02ca15d0: ldr     x30, [sp], #0x20                           
02ca15d4: ret                                                
## set_popup_rate_on_off(bool value) -> void
---- RemoteConfigManager::set_popup_rate_on_off 0x2ca15d8
02ca15d8: stp     x30, x21, [sp, #-0x20]!                    
02ca15dc: stp     x20, x19, [sp, #0x10]                      
02ca15e0: adrp    x21, #0x662f000                            
02ca15e4: adrp    x20, #0x6264000                            
02ca15e8: mov     w19, w0                                    
02ca15ec: ldrb    w8, [x21, #0xaa2]                          
02ca15f0: ldr     x20, [x20, #0xfc0]                         T:RemoteConfigManager
02ca15f4: tbnz    w8, #0, #0x2ca160c                         
02ca15f8: adrp    x0, #0x6264000                             
02ca15fc: ldr     x0, [x0, #0xfc0]                           T:RemoteConfigManager
02ca1600: bl      #0x2b70db0                                 fn_2b70db0
02ca1604: mov     w8, #1                                     
02ca1608: strb    w8, [x21, #0xaa2]                          
02ca160c: ldr     x0, [x20]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02ca1610: ldr     w8, [x0, #0xe4]                            [62640e4]=0 f=0,0
02ca1614: cbnz    w8, #0x2ca1620                             
02ca1618: bl      #0x2b70f30                                 fn_2b70f30
02ca161c: ldr     x0, [x20]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02ca1620: ldr     x8, [x0, #0xb8]                            MS:DG.Tweening.Core.Extensions::SetSpecialStartupMode
02ca1624: and     w9, w19, #1                                
02ca1628: ldp     x20, x19, [sp, #0x10]                      
02ca162c: strb    w9, [x8, #0x15]                            
02ca1630: ldp     x30, x21, [sp], #0x20                      
02ca1634: ret                                                
## get_open_ad_id() -> string
---- RemoteConfigManager::get_open_ad_id 0x2ca1638
02ca1638: str     x30, [sp, #-0x20]!                         
02ca163c: stp     x20, x19, [sp, #0x10]                      
02ca1640: adrp    x20, #0x662f000                            
02ca1644: adrp    x19, #0x6264000                            
02ca1648: ldrb    w8, [x20, #0xaa3]                          
02ca164c: ldr     x19, [x19, #0xfc0]                         T:RemoteConfigManager
02ca1650: tbnz    w8, #0, #0x2ca1668                         
02ca1654: adrp    x0, #0x6264000                             
02ca1658: ldr     x0, [x0, #0xfc0]                           T:RemoteConfigManager
02ca165c: bl      #0x2b70db0                                 fn_2b70db0
02ca1660: mov     w8, #1                                     
02ca1664: strb    w8, [x20, #0xaa3]                          
02ca1668: ldr     x0, [x19]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02ca166c: ldr     w8, [x0, #0xe4]                            [62640e4]=0 f=0,0
02ca1670: cbnz    w8, #0x2ca167c                             
02ca1674: bl      #0x2b70f30                                 fn_2b70f30
02ca1678: ldr     x0, [x19]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02ca167c: ldr     x8, [x0, #0xb8]                            MS:DG.Tweening.Core.Extensions::SetSpecialStartupMode
02ca1680: ldp     x20, x19, [sp, #0x10]                      
02ca1684: ldr     x0, [x8, #0x18]                            
02ca1688: ldr     x30, [sp], #0x20                           
02ca168c: ret                                                
## set_open_ad_id(string value) -> void
---- RemoteConfigManager::set_open_ad_id 0x2ca1690
02ca1690: stp     x30, x21, [sp, #-0x20]!                    
02ca1694: stp     x20, x19, [sp, #0x10]                      
02ca1698: adrp    x21, #0x662f000                            
02ca169c: adrp    x20, #0x6264000                            
02ca16a0: mov     x19, x0                                    
02ca16a4: ldrb    w8, [x21, #0xaa4]                          
02ca16a8: ldr     x20, [x20, #0xfc0]                         T:RemoteConfigManager
02ca16ac: tbnz    w8, #0, #0x2ca16c4                         
02ca16b0: adrp    x0, #0x6264000                             
02ca16b4: ldr     x0, [x0, #0xfc0]                           T:RemoteConfigManager
02ca16b8: bl      #0x2b70db0                                 fn_2b70db0
02ca16bc: mov     w8, #1                                     
02ca16c0: strb    w8, [x21, #0xaa4]                          
02ca16c4: ldr     x0, [x20]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02ca16c8: ldr     w8, [x0, #0xe4]                            [62640e4]=0 f=0,0
02ca16cc: cbnz    w8, #0x2ca16d8                             
02ca16d0: bl      #0x2b70f30                                 fn_2b70f30
02ca16d4: ldr     x0, [x20]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02ca16d8: ldr     x0, [x0, #0xb8]                            MS:DG.Tweening.Core.Extensions::SetSpecialStartupMode
02ca16dc: mov     x1, x19                                    
02ca16e0: str     x19, [x0, #0x18]!                          .<open_ad_id>k__BackingField
02ca16e4: ldp     x20, x19, [sp, #0x10]                      
02ca16e8: ldp     x30, x21, [sp], #0x20                      
02ca16ec: b       #0x2b70d54                                 
## get_native_full_srceen_id() -> string
---- RemoteConfigManager::get_native_full_srceen_id 0x2ca16f0
02ca16f0: str     x30, [sp, #-0x20]!                         
02ca16f4: stp     x20, x19, [sp, #0x10]                      
02ca16f8: adrp    x20, #0x662f000                            
02ca16fc: adrp    x19, #0x6264000                            
02ca1700: ldrb    w8, [x20, #0xaa5]                          
02ca1704: ldr     x19, [x19, #0xfc0]                         T:RemoteConfigManager
02ca1708: tbnz    w8, #0, #0x2ca1720                         
02ca170c: adrp    x0, #0x6264000                             
02ca1710: ldr     x0, [x0, #0xfc0]                           T:RemoteConfigManager
02ca1714: bl      #0x2b70db0                                 fn_2b70db0
02ca1718: mov     w8, #1                                     
02ca171c: strb    w8, [x20, #0xaa5]                          
02ca1720: ldr     x0, [x19]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02ca1724: ldr     w8, [x0, #0xe4]                            [62640e4]=0 f=0,0
02ca1728: cbnz    w8, #0x2ca1734                             
02ca172c: bl      #0x2b70f30                                 fn_2b70f30
02ca1730: ldr     x0, [x19]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02ca1734: ldr     x8, [x0, #0xb8]                            MS:DG.Tweening.Core.Extensions::SetSpecialStartupMode
02ca1738: ldp     x20, x19, [sp, #0x10]                      
02ca173c: ldr     x0, [x8, #0x20]                            
02ca1740: ldr     x30, [sp], #0x20                           
02ca1744: ret                                                
## set_native_full_srceen_id(string value) -> void
---- RemoteConfigManager::set_native_full_srceen_id 0x2ca1748
02ca1748: stp     x30, x21, [sp, #-0x20]!                    
02ca174c: stp     x20, x19, [sp, #0x10]                      
02ca1750: adrp    x21, #0x662f000                            
02ca1754: adrp    x20, #0x6264000                            
02ca1758: mov     x19, x0                                    
02ca175c: ldrb    w8, [x21, #0xaa6]                          
02ca1760: ldr     x20, [x20, #0xfc0]                         T:RemoteConfigManager
02ca1764: tbnz    w8, #0, #0x2ca177c                         
02ca1768: adrp    x0, #0x6264000                             
02ca176c: ldr     x0, [x0, #0xfc0]                           T:RemoteConfigManager
02ca1770: bl      #0x2b70db0                                 fn_2b70db0
02ca1774: mov     w8, #1                                     
02ca1778: strb    w8, [x21, #0xaa6]                          
02ca177c: ldr     x0, [x20]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02ca1780: ldr     w8, [x0, #0xe4]                            [62640e4]=0 f=0,0
02ca1784: cbnz    w8, #0x2ca1790                             
02ca1788: bl      #0x2b70f30                                 fn_2b70f30
02ca178c: ldr     x0, [x20]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02ca1790: ldr     x0, [x0, #0xb8]                            MS:DG.Tweening.Core.Extensions::SetSpecialStartupMode
02ca1794: mov     x1, x19                                    
02ca1798: str     x19, [x0, #0x20]!                          ._currentRetry
02ca179c: ldp     x20, x19, [sp, #0x10]                      
02ca17a0: ldp     x30, x21, [sp], #0x20                      
02ca17a4: b       #0x2b70d54                                 
## get_native_full_srceen_time_showbtn() -> int
---- RemoteConfigManager::get_native_full_srceen_time_showbtn 0x2ca17a8
02ca17a8: str     x30, [sp, #-0x20]!                         
02ca17ac: stp     x20, x19, [sp, #0x10]                      
02ca17b0: adrp    x20, #0x662f000                            
02ca17b4: adrp    x19, #0x6264000                            
02ca17b8: ldrb    w8, [x20, #0xaa7]                          
02ca17bc: ldr     x19, [x19, #0xfc0]                         T:RemoteConfigManager
02ca17c0: tbnz    w8, #0, #0x2ca17d8                         
02ca17c4: adrp    x0, #0x6264000                             
02ca17c8: ldr     x0, [x0, #0xfc0]                           T:RemoteConfigManager
02ca17cc: bl      #0x2b70db0                                 fn_2b70db0
02ca17d0: mov     w8, #1                                     
02ca17d4: strb    w8, [x20, #0xaa7]                          
02ca17d8: ldr     x0, [x19]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02ca17dc: ldr     w8, [x0, #0xe4]                            [62640e4]=0 f=0,0
02ca17e0: cbnz    w8, #0x2ca17ec                             
02ca17e4: bl      #0x2b70f30                                 fn_2b70f30
02ca17e8: ldr     x0, [x19]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02ca17ec: ldr     x8, [x0, #0xb8]                            MS:DG.Tweening.Core.Extensions::SetSpecialStartupMode
02ca17f0: ldp     x20, x19, [sp, #0x10]                      
02ca17f4: ldr     w0, [x8, #0x28]                            
02ca17f8: ldr     x30, [sp], #0x20                           
02ca17fc: ret                                                
## set_native_full_srceen_time_showbtn(int value) -> void
---- RemoteConfigManager::set_native_full_srceen_time_showbtn 0x2ca1800
02ca1800: stp     x30, x21, [sp, #-0x20]!                    
02ca1804: stp     x20, x19, [sp, #0x10]                      
02ca1808: adrp    x21, #0x662f000                            
02ca180c: adrp    x20, #0x6264000                            
02ca1810: mov     w19, w0                                    
02ca1814: ldrb    w8, [x21, #0xaa8]                          
02ca1818: ldr     x20, [x20, #0xfc0]                         T:RemoteConfigManager
02ca181c: tbnz    w8, #0, #0x2ca1834                         
02ca1820: adrp    x0, #0x6264000                             
02ca1824: ldr     x0, [x0, #0xfc0]                           T:RemoteConfigManager
02ca1828: bl      #0x2b70db0                                 fn_2b70db0
02ca182c: mov     w8, #1                                     
02ca1830: strb    w8, [x21, #0xaa8]                          
02ca1834: ldr     x0, [x20]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02ca1838: ldr     w8, [x0, #0xe4]                            [62640e4]=0 f=0,0
02ca183c: cbnz    w8, #0x2ca1848                             
02ca1840: bl      #0x2b70f30                                 fn_2b70f30
02ca1844: ldr     x0, [x20]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02ca1848: ldr     x8, [x0, #0xb8]                            MS:DG.Tweening.Core.Extensions::SetSpecialStartupMode
02ca184c: str     w19, [x8, #0x28]                           
02ca1850: ldp     x20, x19, [sp, #0x10]                      
02ca1854: ldp     x30, x21, [sp], #0x20                      
02ca1858: ret                                                
## get_mrec_ad_id() -> string
---- RemoteConfigManager::get_mrec_ad_id 0x2ca185c
02ca185c: str     x30, [sp, #-0x20]!                         
02ca1860: stp     x20, x19, [sp, #0x10]                      
02ca1864: adrp    x20, #0x662f000                            
02ca1868: adrp    x19, #0x6264000                            
02ca186c: ldrb    w8, [x20, #0xaa9]                          
02ca1870: ldr     x19, [x19, #0xfc0]                         T:RemoteConfigManager
02ca1874: tbnz    w8, #0, #0x2ca188c                         
02ca1878: adrp    x0, #0x6264000                             
02ca187c: ldr     x0, [x0, #0xfc0]                           T:RemoteConfigManager
02ca1880: bl      #0x2b70db0                                 fn_2b70db0
02ca1884: mov     w8, #1                                     
02ca1888: strb    w8, [x20, #0xaa9]                          
02ca188c: ldr     x0, [x19]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02ca1890: ldr     w8, [x0, #0xe4]                            [62640e4]=0 f=0,0
02ca1894: cbnz    w8, #0x2ca18a0                             
02ca1898: bl      #0x2b70f30                                 fn_2b70f30
02ca189c: ldr     x0, [x19]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02ca18a0: ldr     x8, [x0, #0xb8]                            MS:DG.Tweening.Core.Extensions::SetSpecialStartupMode
02ca18a4: ldp     x20, x19, [sp, #0x10]                      
02ca18a8: ldr     x0, [x8, #0x30]                            
02ca18ac: ldr     x30, [sp], #0x20                           
02ca18b0: ret                                                
## set_mrec_ad_id(string value) -> void
---- RemoteConfigManager::set_mrec_ad_id 0x2ca18b4
02ca18b4: stp     x30, x21, [sp, #-0x20]!                    
02ca18b8: stp     x20, x19, [sp, #0x10]                      
02ca18bc: adrp    x21, #0x662f000                            
02ca18c0: adrp    x20, #0x6264000                            
02ca18c4: mov     x19, x0                                    
02ca18c8: ldrb    w8, [x21, #0xaaa]                          
02ca18cc: ldr     x20, [x20, #0xfc0]                         T:RemoteConfigManager
02ca18d0: tbnz    w8, #0, #0x2ca18e8                         
02ca18d4: adrp    x0, #0x6264000                             
02ca18d8: ldr     x0, [x0, #0xfc0]                           T:RemoteConfigManager
02ca18dc: bl      #0x2b70db0                                 fn_2b70db0
02ca18e0: mov     w8, #1                                     
02ca18e4: strb    w8, [x21, #0xaaa]                          
02ca18e8: ldr     x0, [x20]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02ca18ec: ldr     w8, [x0, #0xe4]                            [62640e4]=0 f=0,0
02ca18f0: cbnz    w8, #0x2ca18fc                             
02ca18f4: bl      #0x2b70f30                                 fn_2b70f30
02ca18f8: ldr     x0, [x20]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02ca18fc: ldr     x0, [x0, #0xb8]                            MS:DG.Tweening.Core.Extensions::SetSpecialStartupMode
02ca1900: mov     x1, x19                                    
02ca1904: str     x19, [x0, #0x30]!                          .<mrec_ad_id>k__BackingField
02ca1908: ldp     x20, x19, [sp, #0x10]                      
02ca190c: ldp     x30, x21, [sp], #0x20                      
02ca1910: b       #0x2b70d54                                 
## get_force_update_version() -> bool
---- RemoteConfigManager::get_force_update_version 0x2ca1914
02ca1914: str     x30, [sp, #-0x20]!                         
02ca1918: stp     x20, x19, [sp, #0x10]                      
02ca191c: adrp    x20, #0x662f000                            
02ca1920: adrp    x19, #0x6264000                            
02ca1924: ldrb    w8, [x20, #0xaab]                          
02ca1928: ldr     x19, [x19, #0xfc0]                         T:RemoteConfigManager
02ca192c: tbnz    w8, #0, #0x2ca1944                         
02ca1930: adrp    x0, #0x6264000                             
02ca1934: ldr     x0, [x0, #0xfc0]                           T:RemoteConfigManager
02ca1938: bl      #0x2b70db0                                 fn_2b70db0
02ca193c: mov     w8, #1                                     
02ca1940: strb    w8, [x20, #0xaab]                          
02ca1944: ldr     x0, [x19]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02ca1948: ldr     w8, [x0, #0xe4]                            [62640e4]=0 f=0,0
02ca194c: cbnz    w8, #0x2ca1958                             
02ca1950: bl      #0x2b70f30                                 fn_2b70f30
02ca1954: ldr     x0, [x19]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02ca1958: ldr     x8, [x0, #0xb8]                            MS:DG.Tweening.Core.Extensions::SetSpecialStartupMode
02ca195c: ldp     x20, x19, [sp, #0x10]                      
02ca1960: ldrb    w0, [x8, #0x38]                            
02ca1964: ldr     x30, [sp], #0x20                           
02ca1968: ret                                                
## set_force_update_version(bool value) -> void
---- RemoteConfigManager::set_force_update_version 0x2ca196c
02ca196c: stp     x30, x21, [sp, #-0x20]!                    
02ca1970: stp     x20, x19, [sp, #0x10]                      
02ca1974: adrp    x21, #0x662f000                            
02ca1978: adrp    x20, #0x6264000                            
02ca197c: mov     w19, w0                                    
02ca1980: ldrb    w8, [x21, #0xaac]                          
02ca1984: ldr     x20, [x20, #0xfc0]                         T:RemoteConfigManager
02ca1988: tbnz    w8, #0, #0x2ca19a0                         
02ca198c: adrp    x0, #0x6264000                             
02ca1990: ldr     x0, [x0, #0xfc0]                           T:RemoteConfigManager
02ca1994: bl      #0x2b70db0                                 fn_2b70db0
02ca1998: mov     w8, #1                                     
02ca199c: strb    w8, [x21, #0xaac]                          
02ca19a0: ldr     x0, [x20]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02ca19a4: ldr     w8, [x0, #0xe4]                            [62640e4]=0 f=0,0
02ca19a8: cbnz    w8, #0x2ca19b4                             
02ca19ac: bl      #0x2b70f30                                 fn_2b70f30
02ca19b0: ldr     x0, [x20]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02ca19b4: ldr     x8, [x0, #0xb8]                            MS:DG.Tweening.Core.Extensions::SetSpecialStartupMode
02ca19b8: and     w9, w19, #1                                
02ca19bc: ldp     x20, x19, [sp, #0x10]                      
02ca19c0: strb    w9, [x8, #0x38]                            
02ca19c4: ldp     x30, x21, [sp], #0x20                      
02ca19c8: ret                                                
## get_native_banner_ad_on_off() -> bool
---- RemoteConfigManager::get_native_banner_ad_on_off 0x2ca19cc
02ca19cc: str     x30, [sp, #-0x20]!                         
02ca19d0: stp     x20, x19, [sp, #0x10]                      
02ca19d4: adrp    x20, #0x662f000                            
02ca19d8: adrp    x19, #0x6264000                            
02ca19dc: ldrb    w8, [x20, #0xaad]                          
02ca19e0: ldr     x19, [x19, #0xfc0]                         T:RemoteConfigManager
02ca19e4: tbnz    w8, #0, #0x2ca19fc                         
02ca19e8: adrp    x0, #0x6264000                             
02ca19ec: ldr     x0, [x0, #0xfc0]                           T:RemoteConfigManager
02ca19f0: bl      #0x2b70db0                                 fn_2b70db0
02ca19f4: mov     w8, #1                                     
02ca19f8: strb    w8, [x20, #0xaad]                          
02ca19fc: ldr     x0, [x19]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02ca1a00: ldr     w8, [x0, #0xe4]                            [62640e4]=0 f=0,0
02ca1a04: cbnz    w8, #0x2ca1a10                             
02ca1a08: bl      #0x2b70f30                                 fn_2b70f30
02ca1a0c: ldr     x0, [x19]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02ca1a10: ldr     x8, [x0, #0xb8]                            MS:DG.Tweening.Core.Extensions::SetSpecialStartupMode
02ca1a14: ldp     x20, x19, [sp, #0x10]                      
02ca1a18: ldrb    w0, [x8, #0x39]                            
02ca1a1c: ldr     x30, [sp], #0x20                           
02ca1a20: ret                                                
## set_native_banner_ad_on_off(bool value) -> void
---- RemoteConfigManager::set_native_banner_ad_on_off 0x2ca1a24
02ca1a24: stp     x30, x21, [sp, #-0x20]!                    
02ca1a28: stp     x20, x19, [sp, #0x10]                      
02ca1a2c: adrp    x21, #0x662f000                            
02ca1a30: adrp    x20, #0x6264000                            
02ca1a34: mov     w19, w0                                    
02ca1a38: ldrb    w8, [x21, #0xaae]                          
02ca1a3c: ldr     x20, [x20, #0xfc0]                         T:RemoteConfigManager
02ca1a40: tbnz    w8, #0, #0x2ca1a58                         
02ca1a44: adrp    x0, #0x6264000                             
02ca1a48: ldr     x0, [x0, #0xfc0]                           T:RemoteConfigManager
02ca1a4c: bl      #0x2b70db0                                 fn_2b70db0
02ca1a50: mov     w8, #1                                     
02ca1a54: strb    w8, [x21, #0xaae]                          
02ca1a58: ldr     x0, [x20]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02ca1a5c: ldr     w8, [x0, #0xe4]                            [62640e4]=0 f=0,0
02ca1a60: cbnz    w8, #0x2ca1a6c                             
02ca1a64: bl      #0x2b70f30                                 fn_2b70f30
02ca1a68: ldr     x0, [x20]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02ca1a6c: ldr     x8, [x0, #0xb8]                            MS:DG.Tweening.Core.Extensions::SetSpecialStartupMode
02ca1a70: and     w9, w19, #1                                
02ca1a74: ldp     x20, x19, [sp, #0x10]                      
02ca1a78: strb    w9, [x8, #0x39]                            
02ca1a7c: ldp     x30, x21, [sp], #0x20                      
02ca1a80: ret                                                
## get_native_collap_ad_on_off() -> bool
---- RemoteConfigManager::get_native_collap_ad_on_off 0x2ca1a84
02ca1a84: str     x30, [sp, #-0x20]!                         
02ca1a88: stp     x20, x19, [sp, #0x10]                      
02ca1a8c: adrp    x20, #0x662f000                            
02ca1a90: adrp    x19, #0x6264000                            
02ca1a94: ldrb    w8, [x20, #0xaaf]                          
02ca1a98: ldr     x19, [x19, #0xfc0]                         T:RemoteConfigManager
02ca1a9c: tbnz    w8, #0, #0x2ca1ab4                         
02ca1aa0: adrp    x0, #0x6264000                             
02ca1aa4: ldr     x0, [x0, #0xfc0]                           T:RemoteConfigManager
02ca1aa8: bl      #0x2b70db0                                 fn_2b70db0
02ca1aac: mov     w8, #1                                     
02ca1ab0: strb    w8, [x20, #0xaaf]                          
02ca1ab4: ldr     x0, [x19]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02ca1ab8: ldr     w8, [x0, #0xe4]                            [62640e4]=0 f=0,0
02ca1abc: cbnz    w8, #0x2ca1ac8                             
02ca1ac0: bl      #0x2b70f30                                 fn_2b70f30
02ca1ac4: ldr     x0, [x19]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02ca1ac8: ldr     x8, [x0, #0xb8]                            MS:DG.Tweening.Core.Extensions::SetSpecialStartupMode
02ca1acc: ldp     x20, x19, [sp, #0x10]                      
02ca1ad0: ldrb    w0, [x8, #0x3a]                            
02ca1ad4: ldr     x30, [sp], #0x20                           
02ca1ad8: ret                                                
## set_native_collap_ad_on_off(bool value) -> void
---- RemoteConfigManager::set_native_collap_ad_on_off 0x2ca1adc
02ca1adc: stp     x30, x21, [sp, #-0x20]!                    
02ca1ae0: stp     x20, x19, [sp, #0x10]                      
02ca1ae4: adrp    x21, #0x662f000                            
02ca1ae8: adrp    x20, #0x6264000                            
02ca1aec: mov     w19, w0                                    
02ca1af0: ldrb    w8, [x21, #0xab0]                          
02ca1af4: ldr     x20, [x20, #0xfc0]                         T:RemoteConfigManager
02ca1af8: tbnz    w8, #0, #0x2ca1b10                         
02ca1afc: adrp    x0, #0x6264000                             
02ca1b00: ldr     x0, [x0, #0xfc0]                           T:RemoteConfigManager
02ca1b04: bl      #0x2b70db0                                 fn_2b70db0
02ca1b08: mov     w8, #1                                     
02ca1b0c: strb    w8, [x21, #0xab0]                          
02ca1b10: ldr     x0, [x20]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02ca1b14: ldr     w8, [x0, #0xe4]                            [62640e4]=0 f=0,0
02ca1b18: cbnz    w8, #0x2ca1b24                             
02ca1b1c: bl      #0x2b70f30                                 fn_2b70f30
02ca1b20: ldr     x0, [x20]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02ca1b24: ldr     x8, [x0, #0xb8]                            MS:DG.Tweening.Core.Extensions::SetSpecialStartupMode
02ca1b28: and     w9, w19, #1                                
02ca1b2c: ldp     x20, x19, [sp, #0x10]                      
02ca1b30: strb    w9, [x8, #0x3a]                            
02ca1b34: ldp     x30, x21, [sp], #0x20                      
02ca1b38: ret                                                
## get_banner_native_refresh_time() -> int
---- RemoteConfigManager::get_banner_native_refresh_time 0x2ca1b3c
02ca1b3c: str     x30, [sp, #-0x20]!                         
02ca1b40: stp     x20, x19, [sp, #0x10]                      
02ca1b44: adrp    x20, #0x662f000                            
02ca1b48: adrp    x19, #0x6264000                            
02ca1b4c: ldrb    w8, [x20, #0xab1]                          
02ca1b50: ldr     x19, [x19, #0xfc0]                         T:RemoteConfigManager
02ca1b54: tbnz    w8, #0, #0x2ca1b6c                         
02ca1b58: adrp    x0, #0x6264000                             
02ca1b5c: ldr     x0, [x0, #0xfc0]                           T:RemoteConfigManager
02ca1b60: bl      #0x2b70db0                                 fn_2b70db0
02ca1b64: mov     w8, #1                                     
02ca1b68: strb    w8, [x20, #0xab1]                          
02ca1b6c: ldr     x0, [x19]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02ca1b70: ldr     w8, [x0, #0xe4]                            [62640e4]=0 f=0,0
02ca1b74: cbnz    w8, #0x2ca1b80                             
02ca1b78: bl      #0x2b70f30                                 fn_2b70f30
02ca1b7c: ldr     x0, [x19]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02ca1b80: ldr     x8, [x0, #0xb8]                            MS:DG.Tweening.Core.Extensions::SetSpecialStartupMode
02ca1b84: ldp     x20, x19, [sp, #0x10]                      
02ca1b88: ldr     w0, [x8, #0x3c]                            
02ca1b8c: ldr     x30, [sp], #0x20                           
02ca1b90: ret                                                
## set_banner_native_refresh_time(int value) -> void
---- RemoteConfigManager::set_banner_native_refresh_time 0x2ca1b94
02ca1b94: stp     x30, x21, [sp, #-0x20]!                    
02ca1b98: stp     x20, x19, [sp, #0x10]                      
02ca1b9c: adrp    x21, #0x662f000                            
02ca1ba0: adrp    x20, #0x6264000                            
02ca1ba4: mov     w19, w0                                    
02ca1ba8: ldrb    w8, [x21, #0xab2]                          
02ca1bac: ldr     x20, [x20, #0xfc0]                         T:RemoteConfigManager
02ca1bb0: tbnz    w8, #0, #0x2ca1bc8                         
02ca1bb4: adrp    x0, #0x6264000                             
02ca1bb8: ldr     x0, [x0, #0xfc0]                           T:RemoteConfigManager
02ca1bbc: bl      #0x2b70db0                                 fn_2b70db0
02ca1bc0: mov     w8, #1                                     
02ca1bc4: strb    w8, [x21, #0xab2]                          
02ca1bc8: ldr     x0, [x20]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02ca1bcc: ldr     w8, [x0, #0xe4]                            [62640e4]=0 f=0,0
02ca1bd0: cbnz    w8, #0x2ca1bdc                             
02ca1bd4: bl      #0x2b70f30                                 fn_2b70f30
02ca1bd8: ldr     x0, [x20]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02ca1bdc: ldr     x8, [x0, #0xb8]                            MS:DG.Tweening.Core.Extensions::SetSpecialStartupMode
02ca1be0: str     w19, [x8, #0x3c]                           
02ca1be4: ldp     x20, x19, [sp, #0x10]                      
02ca1be8: ldp     x30, x21, [sp], #0x20                      
02ca1bec: ret                                                
## get_native_banner_id() -> string
---- RemoteConfigManager::get_native_banner_id 0x2ca1bf0
02ca1bf0: str     x30, [sp, #-0x20]!                         
02ca1bf4: stp     x20, x19, [sp, #0x10]                      
02ca1bf8: adrp    x20, #0x662f000                            
02ca1bfc: adrp    x19, #0x6264000                            
02ca1c00: ldrb    w8, [x20, #0xab3]                          
02ca1c04: ldr     x19, [x19, #0xfc0]                         T:RemoteConfigManager
02ca1c08: tbnz    w8, #0, #0x2ca1c20                         
02ca1c0c: adrp    x0, #0x6264000                             
02ca1c10: ldr     x0, [x0, #0xfc0]                           T:RemoteConfigManager
02ca1c14: bl      #0x2b70db0                                 fn_2b70db0
02ca1c18: mov     w8, #1                                     
02ca1c1c: strb    w8, [x20, #0xab3]                          
02ca1c20: ldr     x0, [x19]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02ca1c24: ldr     w8, [x0, #0xe4]                            [62640e4]=0 f=0,0
02ca1c28: cbnz    w8, #0x2ca1c34                             
02ca1c2c: bl      #0x2b70f30                                 fn_2b70f30
02ca1c30: ldr     x0, [x19]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02ca1c34: ldr     x8, [x0, #0xb8]                            MS:DG.Tweening.Core.Extensions::SetSpecialStartupMode
02ca1c38: ldp     x20, x19, [sp, #0x10]                      
02ca1c3c: ldr     x0, [x8, #0x40]                            
02ca1c40: ldr     x30, [sp], #0x20                           
02ca1c44: ret                                                
## set_native_banner_id(string value) -> void
---- RemoteConfigManager::set_native_banner_id 0x2ca1c48
02ca1c48: stp     x30, x21, [sp, #-0x20]!                    
02ca1c4c: stp     x20, x19, [sp, #0x10]                      
02ca1c50: adrp    x21, #0x662f000                            
02ca1c54: adrp    x20, #0x6264000                            
02ca1c58: mov     x19, x0                                    
02ca1c5c: ldrb    w8, [x21, #0xab4]                          
02ca1c60: ldr     x20, [x20, #0xfc0]                         T:RemoteConfigManager
02ca1c64: tbnz    w8, #0, #0x2ca1c7c                         
02ca1c68: adrp    x0, #0x6264000                             
02ca1c6c: ldr     x0, [x0, #0xfc0]                           T:RemoteConfigManager
02ca1c70: bl      #0x2b70db0                                 fn_2b70db0
02ca1c74: mov     w8, #1                                     
02ca1c78: strb    w8, [x21, #0xab4]                          
02ca1c7c: ldr     x0, [x20]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02ca1c80: ldr     w8, [x0, #0xe4]                            [62640e4]=0 f=0,0
02ca1c84: cbnz    w8, #0x2ca1c90                             
02ca1c88: bl      #0x2b70f30                                 fn_2b70f30
02ca1c8c: ldr     x0, [x20]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02ca1c90: ldr     x0, [x0, #0xb8]                            MS:DG.Tweening.Core.Extensions::SetSpecialStartupMode
02ca1c94: mov     x1, x19                                    
02ca1c98: str     x19, [x0, #0x40]!                          .<native_banner_id>k__BackingField
02ca1c9c: ldp     x20, x19, [sp, #0x10]                      
02ca1ca0: ldp     x30, x21, [sp], #0x20                      
02ca1ca4: b       #0x2b70d54                                 
## get_native_collap_id() -> string
---- RemoteConfigManager::get_native_collap_id 0x2ca1ca8
02ca1ca8: str     x30, [sp, #-0x20]!                         
02ca1cac: stp     x20, x19, [sp, #0x10]                      
02ca1cb0: adrp    x20, #0x662f000                            
02ca1cb4: adrp    x19, #0x6264000                            
02ca1cb8: ldrb    w8, [x20, #0xab5]                          
02ca1cbc: ldr     x19, [x19, #0xfc0]                         T:RemoteConfigManager
02ca1cc0: tbnz    w8, #0, #0x2ca1cd8                         
02ca1cc4: adrp    x0, #0x6264000                             
02ca1cc8: ldr     x0, [x0, #0xfc0]                           T:RemoteConfigManager
02ca1ccc: bl      #0x2b70db0                                 fn_2b70db0
02ca1cd0: mov     w8, #1                                     
02ca1cd4: strb    w8, [x20, #0xab5]                          
02ca1cd8: ldr     x0, [x19]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02ca1cdc: ldr     w8, [x0, #0xe4]                            [62640e4]=0 f=0,0
02ca1ce0: cbnz    w8, #0x2ca1cec                             
02ca1ce4: bl      #0x2b70f30                                 fn_2b70f30
02ca1ce8: ldr     x0, [x19]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02ca1cec: ldr     x8, [x0, #0xb8]                            MS:DG.Tweening.Core.Extensions::SetSpecialStartupMode
02ca1cf0: ldp     x20, x19, [sp, #0x10]                      
02ca1cf4: ldr     x0, [x8, #0x48]                            
02ca1cf8: ldr     x30, [sp], #0x20                           
02ca1cfc: ret                                                
## set_native_collap_id(string value) -> void
---- RemoteConfigManager::set_native_collap_id 0x2ca1d00
02ca1d00: stp     x30, x21, [sp, #-0x20]!                    
02ca1d04: stp     x20, x19, [sp, #0x10]                      
02ca1d08: adrp    x21, #0x662f000                            
02ca1d0c: adrp    x20, #0x6264000                            
02ca1d10: mov     x19, x0                                    
02ca1d14: ldrb    w8, [x21, #0xab6]                          
02ca1d18: ldr     x20, [x20, #0xfc0]                         T:RemoteConfigManager
02ca1d1c: tbnz    w8, #0, #0x2ca1d34                         
02ca1d20: adrp    x0, #0x6264000                             
02ca1d24: ldr     x0, [x0, #0xfc0]                           T:RemoteConfigManager
02ca1d28: bl      #0x2b70db0                                 fn_2b70db0
02ca1d2c: mov     w8, #1                                     
02ca1d30: strb    w8, [x21, #0xab6]                          
02ca1d34: ldr     x0, [x20]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02ca1d38: ldr     w8, [x0, #0xe4]                            [62640e4]=0 f=0,0
02ca1d3c: cbnz    w8, #0x2ca1d48                             
02ca1d40: bl      #0x2b70f30                                 fn_2b70f30
02ca1d44: ldr     x0, [x20]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02ca1d48: ldr     x0, [x0, #0xb8]                            MS:DG.Tweening.Core.Extensions::SetSpecialStartupMode
02ca1d4c: mov     x1, x19                                    
02ca1d50: str     x19, [x0, #0x48]!                          .<native_collap_id>k__BackingField
02ca1d54: ldp     x20, x19, [sp, #0x10]                      
02ca1d58: ldp     x30, x21, [sp], #0x20                      
02ca1d5c: b       #0x2b70d54                                 
## FetchAndActivate() -> void
---- RemoteConfigManager::FetchAndActivate 0x2ca0a84
02ca0a84: str     x30, [sp, #-0x30]!                         
02ca0a88: stp     x22, x21, [sp, #0x10]                      
02ca0a8c: stp     x20, x19, [sp, #0x20]                      
02ca0a90: adrp    x21, #0x662f000                            
02ca0a94: adrp    x20, #0x6263000                            
02ca0a98: mov     x19, x0                                    
02ca0a9c: ldrb    w8, [x21, #0xab7]                          
02ca0aa0: ldr     x20, [x20, #0x928]                         T:UnityEngine.Debug
02ca0aa4: tbnz    w8, #0, #0x2ca0af8                         
02ca0aa8: adrp    x0, #0x6265000                             
02ca0aac: ldr     x0, [x0, #0xf80]                           T:type7042(k15)
02ca0ab0: bl      #0x2b70db0                                 fn_2b70db0
02ca0ab4: adrp    x0, #0x6263000                             
02ca0ab8: ldr     x0, [x0, #0x928]                           T:UnityEngine.Debug
02ca0abc: bl      #0x2b70db0                                 fn_2b70db0
02ca0ac0: adrp    x0, #0x6265000                             
02ca0ac4: ldr     x0, [x0, #0xf88]                           T:Firebase.RemoteConfig.FirebaseRemoteConfig
02ca0ac8: bl      #0x2b70db0                                 fn_2b70db0
02ca0acc: adrp    x0, #0x6265000                             
02ca0ad0: ldr     x0, [x0, #0xf90]                           M:RemoteConfigManager::FetchDataRemote
02ca0ad4: bl      #0x2b70db0                                 fn_2b70db0
02ca0ad8: adrp    x0, #0x6265000                             
02ca0adc: ldr     x0, [x0, #0xf98]                           T:System.TimeSpan
02ca0ae0: bl      #0x2b70db0                                 fn_2b70db0
02ca0ae4: adrp    x0, #0x6265000                             
02ca0ae8: ldr     x0, [x0, #0xfa0]                           S:'Fetching data...'
02ca0aec: bl      #0x2b70db0                                 fn_2b70db0
02ca0af0: mov     w8, #1                                     
02ca0af4: strb    w8, [x21, #0xab7]                          
02ca0af8: ldr     x0, [x20]                                  &2c5bbd4(=a9bd7bfdd503233f)
02ca0afc: adrp    x22, #0x6265000                            
02ca0b00: adrp    x20, #0x6265000                            
02ca0b04: ldr     x22, [x22, #0xfa0]                         S:'Fetching data...'
02ca0b08: ldr     w8, [x0, #0xe4]                            [62650e4]=0 f=0,0
02ca0b0c: ldr     x20, [x20, #0xf88]                         T:Firebase.RemoteConfig.FirebaseRemoteConfig
02ca0b10: cbnz    w8, #0x2ca0b18                             
02ca0b14: bl      #0x2b70f30                                 fn_2b70f30
02ca0b18: adrp    x21, #0x6265000                            
02ca0b1c: mov     x1, xzr                                    
02ca0b20: ldr     x21, [x21, #0xf98]                         T:System.TimeSpan
02ca0b24: ldr     x0, [x22]                                  M:AdsManager::<OnApplicationPause>b__26_0
02ca0b28: bl      #0x5af21f4                                 UnityEngine.Debug::Log
02ca0b2c: ldr     x0, [x20]                                  M:AdsManager::<OnApplicationPause>b__26_0
02ca0b30: ldr     w8, [x0, #0xe4]                            [62650e4]=0 f=0,0
02ca0b34: cbnz    w8, #0x2ca0b3c                             
02ca0b38: bl      #0x2b70f30                                 fn_2b70f30
02ca0b3c: mov     x0, xzr                                    
02ca0b40: bl      #0x2e45fa0                                 Firebase.RemoteConfig.FirebaseRemoteConfig::get_DefaultInstance
02ca0b44: ldr     x8, [x21]                                  M:AdsManager::<OnApplicationPause>b__26_0
02ca0b48: mov     x20, x0                                    
02ca0b4c: ldr     w9, [x8, #0xe4]                            
02ca0b50: cbnz    w9, #0x2ca0b5c                             
02ca0b54: mov     x0, x8                                     
02ca0b58: bl      #0x2b70f30                                 fn_2b70f30
02ca0b5c: cbz     x20, #0x2ca0bc8                            
02ca0b60: ldr     x8, [x21]                                  M:AdsManager::<OnApplicationPause>b__26_0
02ca0b64: adrp    x21, #0x6265000                            
02ca0b68: adrp    x22, #0x6265000                            
02ca0b6c: mov     x0, x20                                    
02ca0b70: mov     x2, xzr                                    
02ca0b74: ldr     x8, [x8, #0xb8]                            
02ca0b78: ldr     x21, [x21, #0xf80]                         T:type7042(k15)
02ca0b7c: ldr     x22, [x22, #0xf90]                         M:RemoteConfigManager::FetchDataRemote
02ca0b80: ldr     x1, [x8]                                   
02ca0b84: bl      #0x2e464a0                                 Firebase.RemoteConfig.FirebaseRemoteConfig::FetchAsync
02ca0b88: ldr     x8, [x21]                                  M:AdsManager::<OnApplicationPause>b__26_0
02ca0b8c: mov     x20, x0                                    
02ca0b90: mov     x0, x8                                     
02ca0b94: bl      #0x2b7104c                                 fn_2b7104c
02ca0b98: ldr     x2, [x22]                                  M:AdsManager::<OnApplicationPause>b__26_0
02ca0b9c: mov     x1, x19                                    
02ca0ba0: mov     x3, xzr                                    
02ca0ba4: mov     x21, x0                                    
02ca0ba8: bl      #0x453418c                                 fn_453418c
02ca0bac: mov     x0, x20                                    
02ca0bb0: mov     x1, x21                                    
02ca0bb4: mov     x2, xzr                                    
02ca0bb8: ldp     x20, x19, [sp, #0x20]                      
02ca0bbc: ldp     x22, x21, [sp, #0x10]                      
02ca0bc0: ldr     x30, [sp], #0x30                           
02ca0bc4: b       #0x2e4ea2c                                 Firebase.Extensions.TaskExtension::ContinueWithOnMainThread
02ca0bc8: bl      #0x2b7105c                                 fn_2b7105c
## RetryFetch() -> void
---- RemoteConfigManager::RetryFetch 0x2ca1d60
02ca1d60: sub     sp, sp, #0x80                              
02ca1d64: stp     x30, x21, [sp, #0x60]                      
02ca1d68: stp     x20, x19, [sp, #0x70]                      
02ca1d6c: adrp    x21, #0x662f000                            
02ca1d70: adrp    x20, #0x6265000                            
02ca1d74: mov     x19, x0                                    
02ca1d78: ldrb    w8, [x21, #0xab8]                          
02ca1d7c: ldr     x20, [x20, #0xff0]                         MS:System.Runtime.CompilerServices.AsyncVoidMethodBuilder::Start
02ca1d80: tbnz    w8, #0, #0x2ca1d98                         
02ca1d84: adrp    x0, #0x6265000                             
02ca1d88: ldr     x0, [x0, #0xff0]                           MS:System.Runtime.CompilerServices.AsyncVoidMethodBuilder::Start
02ca1d8c: bl      #0x2b70db0                                 fn_2b70db0
02ca1d90: mov     w8, #1                                     
02ca1d94: strb    w8, [x21, #0xab8]                          
02ca1d98: movi    v0.2d, #0000000000000000                   
02ca1d9c: mov     x8, sp                                     
02ca1da0: mov     x0, xzr                                    
02ca1da4: str     xzr, [sp, #0x50]                           
02ca1da8: stp     q0, q0, [sp, #0x30]                        
02ca1dac: str     q0, [sp, #0x20]                            
02ca1db0: bl      #0x4d43a24                                 System.Runtime.CompilerServices.AsyncVoidMethodBuilder::Create
02ca1db4: ldp     q0, q1, [sp]                               
02ca1db8: add     x21, sp, #0x20                             
02ca1dbc: orr     x0, x21, #8                                
02ca1dc0: mov     x1, xzr                                    
02ca1dc4: stur    q0, [sp, #0x28]                            
02ca1dc8: stur    q1, [sp, #0x38]                            
02ca1dcc: bl      #0x2b70d54                                 fn_2b70d54
02ca1dd0: add     x0, x21, #0x28                             &662f028
02ca1dd4: mov     x1, x19                                    
02ca1dd8: str     x19, [sp, #0x48]                           
02ca1ddc: bl      #0x2b70d54                                 fn_2b70d54
02ca1de0: ldr     x2, [x20]                                  M:AdsManager::<OnApplicationPause>b__26_0
02ca1de4: mov     w8, #-1                                    
02ca1de8: orr     x0, x21, #8                                
02ca1dec: add     x1, sp, #0x20                              
02ca1df0: str     w8, [sp, #0x20]                            
02ca1df4: bl      #0x30c8eb4                                 fn_30c8eb4
02ca1df8: ldp     x20, x19, [sp, #0x70]                      
02ca1dfc: ldp     x30, x21, [sp, #0x60]                      
02ca1e00: add     sp, sp, #0x80                              
02ca1e04: ret                                                
## FetchDataRemote(System.Threading.Tasks.Task fetchTask) -> void
---- RemoteConfigManager::FetchDataRemote 0x2ca1e08
02ca1e08: sub     sp, sp, #0x80                              
02ca1e0c: str     x30, [sp, #0x40]                           
02ca1e10: stp     x24, x23, [sp, #0x50]                      
02ca1e14: stp     x22, x21, [sp, #0x60]                      
02ca1e18: stp     x20, x19, [sp, #0x70]                      
02ca1e1c: adrp    x22, #0x662f000                            
02ca1e20: adrp    x23, #0x6263000                            
02ca1e24: adrp    x20, #0x6263000                            
02ca1e28: adrp    x21, #0x6264000                            
02ca1e2c: ldr     x23, [x23, #0x938]                         T:type8922(k15)
02ca1e30: ldrb    w8, [x22, #0xab9]                          
02ca1e34: ldr     x20, [x20, #0x9a0]                         MS:System.Collections.Generic.Dictionary`2::.ctor
02ca1e38: ldr     x21, [x21, #0xfc0]                         T:RemoteConfigManager
02ca1e3c: mov     x19, x0                                    
02ca1e40: tbnz    w8, #0, #0x2ca1fb4                         
02ca1e44: adrp    x0, #0x6265000                             
02ca1e48: ldr     x0, [x0, #0xff8]                           T:type53111(k15)
02ca1e4c: bl      #0x2b70db0                                 fn_2b70db0
02ca1e50: adrp    x0, #0x6265000                             
02ca1e54: ldr     x0, [x0, #0xb40]                           MS:System.Collections.Generic.Dictionary`2::Add
02ca1e58: bl      #0x2b70db0                                 fn_2b70db0
02ca1e5c: adrp    x0, #0x6263000                             
02ca1e60: ldr     x0, [x0, #0x9a0]                           MS:System.Collections.Generic.Dictionary`2::.ctor
02ca1e64: bl      #0x2b70db0                                 fn_2b70db0
02ca1e68: adrp    x0, #0x6263000                             
02ca1e6c: ldr     x0, [x0, #0x938]                           T:type8922(k15)
02ca1e70: bl      #0x2b70db0                                 fn_2b70db0
02ca1e74: adrp    x0, #0x6265000                             
02ca1e78: ldr     x0, [x0, #0xf88]                           T:Firebase.RemoteConfig.FirebaseRemoteConfig
02ca1e7c: bl      #0x2b70db0                                 fn_2b70db0
02ca1e80: adrp    x0, #0x6266000                             
02ca1e84: ldr     x0, [x0]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca1e88: bl      #0x2b70db0                                 fn_2b70db0
02ca1e8c: adrp    x0, #0x6264000                             
02ca1e90: ldr     x0, [x0, #0xfc0]                           T:RemoteConfigManager
02ca1e94: bl      #0x2b70db0                                 fn_2b70db0
02ca1e98: adrp    x0, #0x6266000                             
02ca1e9c: ldr     x0, [x0, #8]                               MS:Firebase.Extensions.TaskExtension::ContinueWithOnMainThread
02ca1ea0: bl      #0x2b70db0                                 fn_2b70db0
02ca1ea4: adrp    x0, #0x6266000                             
02ca1ea8: ldr     x0, [x0, #0x10]                            S:'mrec_ad_on_off' .<data_config_type>k__BackingField
02ca1eac: bl      #0x2b70db0                                 fn_2b70db0
02ca1eb0: adrp    x0, #0x6266000                             
02ca1eb4: ldr     x0, [x0, #0x18]                            S:'level_show_popuprate' .<open_ad_id>k__BackingField
02ca1eb8: bl      #0x2b70db0                                 fn_2b70db0
02ca1ebc: adrp    x0, #0x6266000                             
02ca1ec0: ldr     x0, [x0, #0x20]                            S:'inter_ad_capping_time' ._currentRetry
02ca1ec4: bl      #0x2b70db0                                 fn_2b70db0
02ca1ec8: adrp    x0, #0x6266000                             
02ca1ecc: ldr     x0, [x0, #0x28]                            S:'banner_ad_on_off' .defaults
02ca1ed0: bl      #0x2b70db0                                 fn_2b70db0
02ca1ed4: adrp    x0, #0x6266000                             
02ca1ed8: ldr     x0, [x0, #0x30]                            S:'popup_rate_on_off' .<mrec_ad_id>k__BackingField
02ca1edc: bl      #0x2b70db0                                 fn_2b70db0
02ca1ee0: adrp    x0, #0x6266000                             
02ca1ee4: ldr     x0, [x0, #0x38]                            S:'native_collap_id' .<force_update_version>k__BackingField
02ca1ee8: bl      #0x2b70db0                                 fn_2b70db0
02ca1eec: adrp    x0, #0x6266000                             
02ca1ef0: ldr     x0, [x0, #0x40]                            S:'native_collap_ad_on_off' .<native_banner_id>k__BackingField
02ca1ef4: bl      #0x2b70db0                                 fn_2b70db0
02ca1ef8: adrp    x0, #0x6266000                             
02ca1efc: ldr     x0, [x0, #0x48]                            S:'native_full_srceen_id' .<native_collap_id>k__BackingField
02ca1f00: bl      #0x2b70db0                                 fn_2b70db0
02ca1f04: adrp    x0, #0x6266000                             
02ca1f08: ldr     x0, [x0, #0x50]                            S:'native_fullscreen_on_off'
02ca1f0c: bl      #0x2b70db0                                 fn_2b70db0
02ca1f10: adrp    x0, #0x6266000                             
02ca1f14: ldr     x0, [x0, #0x58]                            S:'inter_ad_on_off'
02ca1f18: bl      #0x2b70db0                                 fn_2b70db0
02ca1f1c: adrp    x0, #0x6266000                             
02ca1f20: ldr     x0, [x0, #0x60]                            S:'open_ad_on_off'
02ca1f24: bl      #0x2b70db0                                 fn_2b70db0
02ca1f28: adrp    x0, #0x6266000                             
02ca1f2c: ldr     x0, [x0, #0x68]                            S:'native_full_srceen_time_showbtn'
02ca1f30: bl      #0x2b70db0                                 fn_2b70db0
02ca1f34: adrp    x0, #0x6266000                             
02ca1f38: ldr     x0, [x0, #0x70]                            S:'open_ad_id'
02ca1f3c: bl      #0x2b70db0                                 fn_2b70db0
02ca1f40: adrp    x0, #0x6266000                             
02ca1f44: ldr     x0, [x0, #0x78]                            S:'Latest Fetch call still pending.'
02ca1f48: bl      #0x2b70db0                                 fn_2b70db0
02ca1f4c: adrp    x0, #0x6266000                             
02ca1f50: ldr     x0, [x0, #0x80]                            S:'Fetch failed.'
02ca1f54: bl      #0x2b70db0                                 fn_2b70db0
02ca1f58: adrp    x0, #0x6266000                             
02ca1f5c: ldr     x0, [x0, #0x88]                            S:'native_banner_id'
02ca1f60: bl      #0x2b70db0                                 fn_2b70db0
02ca1f64: adrp    x0, #0x6266000                             
02ca1f68: ldr     x0, [x0, #0x90]                            S:'mrec_ad_id'
02ca1f6c: bl      #0x2b70db0                                 fn_2b70db0
02ca1f70: adrp    x0, #0x6266000                             
02ca1f74: ldr     x0, [x0, #0x98]                            S:'force_update_version'
02ca1f78: bl      #0x2b70db0                                 fn_2b70db0
02ca1f7c: adrp    x0, #0x6266000                             
02ca1f80: ldr     x0, [x0, #0xa0]                            S:'open_ad_capping_time'
02ca1f84: bl      #0x2b70db0                                 fn_2b70db0
02ca1f88: adrp    x0, #0x6266000                             
02ca1f8c: ldr     x0, [x0, #0xa8]                            S:'data_config_type'
02ca1f90: bl      #0x2b70db0                                 fn_2b70db0
02ca1f94: adrp    x0, #0x6266000                             
02ca1f98: ldr     x0, [x0, #0xb0]                            S:'native_banner_ad_on_off'
02ca1f9c: bl      #0x2b70db0                                 fn_2b70db0
02ca1fa0: adrp    x0, #0x6266000                             
02ca1fa4: ldr     x0, [x0, #0xb8]                            S:'banner_native_refresh_time'
02ca1fa8: bl      #0x2b70db0                                 fn_2b70db0
02ca1fac: mov     w8, #1                                     
02ca1fb0: strb    w8, [x22, #0xab9]                          
02ca1fb4: ldr     x0, [x23]                                  &2c5bbd4(=a9bd7bfdd503233f)
02ca1fb8: bl      #0x2b7104c                                 fn_2b7104c
02ca1fbc: ldr     x1, [x20]                                  &2c5bbd4(=a9bd7bfdd503233f)
02ca1fc0: mov     x20, x0                                    
02ca1fc4: bl      #0x452b8a0                                 fn_452b8a0
02ca1fc8: ldr     x0, [x21]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02ca1fcc: ldr     w8, [x0, #0xe4]                            [62660e4]=0 f=0,0
02ca1fd0: cbnz    w8, #0x2ca1fd8                             
02ca1fd4: bl      #0x2b70f30                                 fn_2b70f30
02ca1fd8: adrp    x22, #0x662f000                            
02ca1fdc: ldrb    w8, [x22, #0xa7a]                          
02ca1fe0: cbnz    w8, #0x2ca1ff8                             
02ca1fe4: adrp    x0, #0x6264000                             
02ca1fe8: ldr     x0, [x0, #0xfc0]                           T:RemoteConfigManager
02ca1fec: bl      #0x2b70db0                                 fn_2b70db0
02ca1ff0: mov     w8, #1                                     
02ca1ff4: strb    w8, [x22, #0xa7a]                          
02ca1ff8: ldr     x0, [x21]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02ca1ffc: ldr     w8, [x0, #0xe4]                            [62640e4]=0 f=0,0
02ca2000: cbnz    w8, #0x2ca200c                             
02ca2004: bl      #0x2b70f30                                 fn_2b70f30
02ca2008: ldr     x0, [x21]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02ca200c: adrp    x23, #0x6263000                            
02ca2010: ldr     x8, [x0, #0xb8]                            MS:DG.Tweening.Core.Extensions::SetSpecialStartupMode
02ca2014: add     x1, sp, #0x4c                              
02ca2018: b       #0x5e8fd44                                 
02ca201c: ldrb    w8, [x8]                                   
02ca2020: ldr     x0, [x23, #0x28]                           [6263028]=0 f=0,0
02ca2024: strb    w8, [sp, #0x4c]                            
02ca2028: bl      #0x2b70f38                                 fn_2b70f38
02ca202c: cbz     x20, #0x2ca28d4                            
02ca2030: adrp    x8, #0x6266000                             
02ca2034: adrp    x22, #0x6265000                            
02ca2038: mov     x2, x0                                     
02ca203c: ldr     x8, [x8, #0x58]                            S:'inter_ad_on_off'
02ca2040: ldr     x22, [x22, #0xb40]                         MS:System.Collections.Generic.Dictionary`2::Add
02ca2044: mov     x0, x20                                    
02ca2048: ldr     x1, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca204c: ldr     x3, [x22]                                  M:AdsManager::<OnApplicationPause>b__26_0
02ca2050: bl      #0x452c61c                                 fn_452c61c
02ca2054: adrp    x24, #0x662f000                            
02ca2058: ldrb    w8, [x24, #0xa7e]                          
02ca205c: cbnz    w8, #0x2ca2074                             
02ca2060: adrp    x0, #0x6264000                             
02ca2064: ldr     x0, [x0, #0xfc0]                           T:RemoteConfigManager
02ca2068: bl      #0x2b70db0                                 fn_2b70db0
02ca206c: mov     w8, #1                                     
02ca2070: strb    w8, [x24, #0xa7e]                          
02ca2074: ldr     x0, [x21]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02ca2078: adrp    x24, #0x6266000                            
02ca207c: ldr     w8, [x0, #0xe4]                            [62640e4]=0 f=0,0
02ca2080: ldr     x24, [x24, #0x10]                          S:'mrec_ad_on_off'
02ca2084: cbnz    w8, #0x2ca2090                             
02ca2088: bl      #0x2b70f30                                 fn_2b70f30
02ca208c: ldr     x0, [x21]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02ca2090: ldr     x8, [x0, #0xb8]                            MS:DG.Tweening.Core.Extensions::SetSpecialStartupMode
02ca2094: ldr     x0, [x23, #0x28]                           [6263028]=0 f=0,0
02ca2098: add     x1, sp, #0x48                              
02ca209c: ldrb    w8, [x8, #1]                               
02ca20a0: strb    w8, [sp, #0x48]                            
02ca20a4: bl      #0x2b70f38                                 fn_2b70f38
02ca20a8: ldr     x1, [x24]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca20ac: ldr     x3, [x22]                                  M:AdsManager::<OnApplicationPause>b__26_0
02ca20b0: mov     x2, x0                                     
02ca20b4: mov     x0, x20                                    
02ca20b8: bl      #0x452c61c                                 fn_452c61c
02ca20bc: adrp    x24, #0x662f000                            
02ca20c0: ldrb    w8, [x24, #0xa7d]                          
02ca20c4: cbnz    w8, #0x2ca20dc                             
02ca20c8: adrp    x0, #0x6264000                             
02ca20cc: ldr     x0, [x0, #0xfc0]                           T:RemoteConfigManager
02ca20d0: bl      #0x2b70db0                                 fn_2b70db0
02ca20d4: mov     w8, #1                                     
02ca20d8: strb    w8, [x24, #0xa7d]                          
02ca20dc: ldr     x0, [x21]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02ca20e0: adrp    x24, #0x6266000                            
02ca20e4: ldr     w8, [x0, #0xe4]                            [62640e4]=0 f=0,0
02ca20e8: ldr     x24, [x24, #0x28]                          S:'banner_ad_on_off'
02ca20ec: cbnz    w8, #0x2ca20f8                             
02ca20f0: bl      #0x2b70f30                                 fn_2b70f30
02ca20f4: ldr     x0, [x21]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02ca20f8: ldr     x8, [x0, #0xb8]                            MS:DG.Tweening.Core.Extensions::SetSpecialStartupMode
02ca20fc: ldr     x0, [x23, #0x28]                           [6263028]=0 f=0,0
02ca2100: add     x1, sp, #0x3c                              
02ca2104: ldrb    w8, [x8, #2]                               
02ca2108: strb    w8, [sp, #0x3c]                            
02ca210c: bl      #0x2b70f38                                 fn_2b70f38
02ca2110: ldr     x1, [x24]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca2114: ldr     x3, [x22]                                  M:AdsManager::<OnApplicationPause>b__26_0
02ca2118: mov     x2, x0                                     
02ca211c: mov     x0, x20                                    
02ca2120: bl      #0x452c61c                                 fn_452c61c
02ca2124: adrp    x24, #0x662f000                            
02ca2128: ldrb    w8, [x24, #0xa78]                          
02ca212c: cbnz    w8, #0x2ca2144                             
02ca2130: adrp    x0, #0x6264000                             
02ca2134: ldr     x0, [x0, #0xfc0]                           T:RemoteConfigManager
02ca2138: bl      #0x2b70db0                                 fn_2b70db0
02ca213c: mov     w8, #1                                     
02ca2140: strb    w8, [x24, #0xa78]                          
02ca2144: ldr     x0, [x21]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02ca2148: adrp    x24, #0x6266000                            
02ca214c: ldr     w8, [x0, #0xe4]                            [62640e4]=0 f=0,0
02ca2150: ldr     x24, [x24, #0x60]                          S:'open_ad_on_off'
02ca2154: cbnz    w8, #0x2ca2160                             
02ca2158: bl      #0x2b70f30                                 fn_2b70f30
02ca215c: ldr     x0, [x21]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02ca2160: ldr     x8, [x0, #0xb8]                            MS:DG.Tweening.Core.Extensions::SetSpecialStartupMode
02ca2164: ldr     x0, [x23, #0x28]                           [6263028]=0 f=0,0
02ca2168: add     x1, sp, #0x38                              
02ca216c: ldrb    w8, [x8, #3]                               
02ca2170: strb    w8, [sp, #0x38]                            
02ca2174: bl      #0x2b70f38                                 fn_2b70f38
02ca2178: ldr     x1, [x24]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca217c: ldr     x3, [x22]                                  M:AdsManager::<OnApplicationPause>b__26_0
02ca2180: mov     x2, x0                                     
02ca2184: mov     x0, x20                                    
02ca2188: bl      #0x452c61c                                 fn_452c61c
02ca218c: adrp    x24, #0x662f000                            
02ca2190: ldrb    w8, [x24, #0xa7b]                          
02ca2194: cbnz    w8, #0x2ca21ac                             
02ca2198: adrp    x0, #0x6264000                             
02ca219c: ldr     x0, [x0, #0xfc0]                           T:RemoteConfigManager
02ca21a0: bl      #0x2b70db0                                 fn_2b70db0
02ca21a4: mov     w8, #1                                     
02ca21a8: strb    w8, [x24, #0xa7b]                          
02ca21ac: ldr     x0, [x21]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02ca21b0: adrp    x24, #0x6266000                            
02ca21b4: ldr     w8, [x0, #0xe4]                            [62640e4]=0 f=0,0
02ca21b8: ldr     x24, [x24, #0x20]                          S:'inter_ad_capping_time'
02ca21bc: cbnz    w8, #0x2ca21c8                             
02ca21c0: bl      #0x2b70f30                                 fn_2b70f30
02ca21c4: ldr     x0, [x21]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02ca21c8: ldr     x8, [x0, #0xb8]                            MS:DG.Tweening.Core.Extensions::SetSpecialStartupMode
02ca21cc: ldr     x0, [x23, #0x48]                           &6263098(=0)
02ca21d0: add     x1, sp, #0x34                              
02ca21d4: ldr     w8, [x8, #4]                               [6266004]=0 f=0,0
02ca21d8: str     w8, [sp, #0x34]                            
02ca21dc: bl      #0x2b70f38                                 fn_2b70f38
02ca21e0: ldr     x1, [x24]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca21e4: ldr     x3, [x22]                                  M:AdsManager::<OnApplicationPause>b__26_0
02ca21e8: mov     x2, x0                                     
02ca21ec: mov     x0, x20                                    
02ca21f0: bl      #0x452c61c                                 fn_452c61c
02ca21f4: adrp    x24, #0x662f000                            
02ca21f8: ldrb    w8, [x24, #0xa79]                          
02ca21fc: cbnz    w8, #0x2ca2214                             
02ca2200: adrp    x0, #0x6264000                             
02ca2204: ldr     x0, [x0, #0xfc0]                           T:RemoteConfigManager
02ca2208: bl      #0x2b70db0                                 fn_2b70db0
02ca220c: mov     w8, #1                                     
02ca2210: strb    w8, [x24, #0xa79]                          
02ca2214: ldr     x0, [x21]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02ca2218: adrp    x24, #0x6266000                            
02ca221c: ldr     w8, [x0, #0xe4]                            [62640e4]=0 f=0,0
02ca2220: ldr     x24, [x24, #0xa0]                          S:'open_ad_capping_time'
02ca2224: cbnz    w8, #0x2ca2230                             
02ca2228: bl      #0x2b70f30                                 fn_2b70f30
02ca222c: ldr     x0, [x21]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02ca2230: ldr     x8, [x0, #0xb8]                            MS:DG.Tweening.Core.Extensions::SetSpecialStartupMode
02ca2234: ldr     x0, [x23, #0x48]                           &6263098(=0)
02ca2238: add     x1, sp, #0x30                              
02ca223c: ldr     w8, [x8, #8]                               MS:Firebase.Extensions.TaskExtension::ContinueWithOnMainThread
02ca2240: str     w8, [sp, #0x30]                            
02ca2244: bl      #0x2b70f38                                 fn_2b70f38
02ca2248: ldr     x1, [x24]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca224c: ldr     x3, [x22]                                  M:AdsManager::<OnApplicationPause>b__26_0
02ca2250: mov     x2, x0                                     
02ca2254: mov     x0, x20                                    
02ca2258: bl      #0x452c61c                                 fn_452c61c
02ca225c: adrp    x24, #0x662f000                            
02ca2260: ldrb    w8, [x24, #0xbc0]                          
02ca2264: cbnz    w8, #0x2ca227c                             
02ca2268: adrp    x0, #0x6264000                             
02ca226c: ldr     x0, [x0, #0xfc0]                           T:RemoteConfigManager
02ca2270: bl      #0x2b70db0                                 fn_2b70db0
02ca2274: mov     w8, #1                                     
02ca2278: strb    w8, [x24, #0xbc0]                          
02ca227c: ldr     x0, [x21]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02ca2280: adrp    x24, #0x6266000                            
02ca2284: ldr     w8, [x0, #0xe4]                            [62640e4]=0 f=0,0
02ca2288: ldr     x24, [x24, #0x18]                          S:'level_show_popuprate'
02ca228c: cbnz    w8, #0x2ca2298                             
02ca2290: bl      #0x2b70f30                                 fn_2b70f30
02ca2294: ldr     x0, [x21]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02ca2298: ldr     x8, [x0, #0xb8]                            MS:DG.Tweening.Core.Extensions::SetSpecialStartupMode
02ca229c: ldr     x0, [x23, #0x48]                           &6263098(=0)
02ca22a0: add     x1, sp, #0x2c                              
02ca22a4: ldr     w8, [x8, #0xc]                             [626600c]=0 f=0,0
02ca22a8: str     w8, [sp, #0x2c]                            
02ca22ac: bl      #0x2b70f38                                 fn_2b70f38
02ca22b0: ldr     x1, [x24]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca22b4: ldr     x3, [x22]                                  M:AdsManager::<OnApplicationPause>b__26_0
02ca22b8: mov     x2, x0                                     
02ca22bc: mov     x0, x20                                    
02ca22c0: bl      #0x452c61c                                 fn_452c61c
02ca22c4: adrp    x24, #0x662f000                            
02ca22c8: ldrb    w8, [x24, #0xbc1]                          
02ca22cc: cbnz    w8, #0x2ca22e4                             
02ca22d0: adrp    x0, #0x6264000                             
02ca22d4: ldr     x0, [x0, #0xfc0]                           T:RemoteConfigManager
02ca22d8: bl      #0x2b70db0                                 fn_2b70db0
02ca22dc: mov     w8, #1                                     
02ca22e0: strb    w8, [x24, #0xbc1]                          
02ca22e4: ldr     x0, [x21]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02ca22e8: adrp    x24, #0x6266000                            
02ca22ec: ldr     w8, [x0, #0xe4]                            [62640e4]=0 f=0,0
02ca22f0: ldr     x24, [x24, #0xa8]                          S:'data_config_type'
02ca22f4: cbnz    w8, #0x2ca2300                             
02ca22f8: bl      #0x2b70f30                                 fn_2b70f30
02ca22fc: ldr     x0, [x21]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02ca2300: ldr     x8, [x0, #0xb8]                            MS:DG.Tweening.Core.Extensions::SetSpecialStartupMode
02ca2304: ldr     x0, [x23, #0x48]                           &6263098(=0)
02ca2308: add     x1, sp, #0x28                              
02ca230c: ldr     w8, [x8, #0x10]                            S:'mrec_ad_on_off'
02ca2310: str     w8, [sp, #0x28]                            
02ca2314: bl      #0x2b70f38                                 fn_2b70f38
02ca2318: ldr     x1, [x24]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca231c: ldr     x3, [x22]                                  M:AdsManager::<OnApplicationPause>b__26_0
02ca2320: mov     x2, x0                                     
02ca2324: mov     x0, x20                                    
02ca2328: bl      #0x452c61c                                 fn_452c61c
02ca232c: adrp    x24, #0x662f000                            
02ca2330: ldrb    w8, [x24, #0xa7c]                          
02ca2334: cbnz    w8, #0x2ca234c                             
02ca2338: adrp    x0, #0x6264000                             
02ca233c: ldr     x0, [x0, #0xfc0]                           T:RemoteConfigManager
02ca2340: bl      #0x2b70db0                                 fn_2b70db0
02ca2344: mov     w8, #1                                     
02ca2348: strb    w8, [x24, #0xa7c]                          
02ca234c: ldr     x0, [x21]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02ca2350: adrp    x24, #0x6266000                            
02ca2354: ldr     w8, [x0, #0xe4]                            [62640e4]=0 f=0,0
02ca2358: ldr     x24, [x24, #0x50]                          S:'native_fullscreen_on_off'
02ca235c: cbnz    w8, #0x2ca2368                             
02ca2360: bl      #0x2b70f30                                 fn_2b70f30
02ca2364: ldr     x0, [x21]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02ca2368: ldr     x8, [x0, #0xb8]                            MS:DG.Tweening.Core.Extensions::SetSpecialStartupMode
02ca236c: ldr     x0, [x23, #0x28]                           [6263028]=0 f=0,0
02ca2370: add     x1, sp, #0x24                              
02ca2374: ldrb    w8, [x8, #0x14]                            
02ca2378: strb    w8, [sp, #0x24]                            
02ca237c: bl      #0x2b70f38                                 fn_2b70f38
02ca2380: ldr     x1, [x24]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca2384: ldr     x3, [x22]                                  M:AdsManager::<OnApplicationPause>b__26_0
02ca2388: mov     x2, x0                                     
02ca238c: mov     x0, x20                                    
02ca2390: bl      #0x452c61c                                 fn_452c61c
02ca2394: adrp    x24, #0x662f000                            
02ca2398: ldrb    w8, [x24, #0xbc2]                          
02ca239c: cbnz    w8, #0x2ca23b4                             
02ca23a0: adrp    x0, #0x6264000                             
02ca23a4: ldr     x0, [x0, #0xfc0]                           T:RemoteConfigManager
02ca23a8: bl      #0x2b70db0                                 fn_2b70db0
02ca23ac: mov     w8, #1                                     
02ca23b0: strb    w8, [x24, #0xbc2]                          
02ca23b4: ldr     x0, [x21]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02ca23b8: adrp    x24, #0x6266000                            
02ca23bc: ldr     w8, [x0, #0xe4]                            [62640e4]=0 f=0,0
02ca23c0: ldr     x24, [x24, #0x30]                          S:'popup_rate_on_off'
02ca23c4: cbnz    w8, #0x2ca23d0                             
02ca23c8: bl      #0x2b70f30                                 fn_2b70f30
02ca23cc: ldr     x0, [x21]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02ca23d0: ldr     x8, [x0, #0xb8]                            MS:DG.Tweening.Core.Extensions::SetSpecialStartupMode
02ca23d4: ldr     x0, [x23, #0x28]                           [6263028]=0 f=0,0
02ca23d8: add     x1, sp, #0x20                              
02ca23dc: ldrb    w8, [x8, #0x15]                            
02ca23e0: strb    w8, [sp, #0x20]                            
02ca23e4: bl      #0x2b70f38                                 fn_2b70f38
02ca23e8: ldr     x1, [x24]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca23ec: ldr     x3, [x22]                                  M:AdsManager::<OnApplicationPause>b__26_0
02ca23f0: mov     x2, x0                                     
02ca23f4: mov     x0, x20                                    
02ca23f8: bl      #0x452c61c                                 fn_452c61c
02ca23fc: adrp    x24, #0x662f000                            
02ca2400: ldrb    w8, [x24, #0xa7f]                          
02ca2404: cbnz    w8, #0x2ca241c                             
02ca2408: adrp    x0, #0x6264000                             
02ca240c: ldr     x0, [x0, #0xfc0]                           T:RemoteConfigManager
02ca2410: bl      #0x2b70db0                                 fn_2b70db0
02ca2414: mov     w8, #1                                     
02ca2418: strb    w8, [x24, #0xa7f]                          
02ca241c: ldr     x0, [x21]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02ca2420: adrp    x24, #0x6266000                            
02ca2424: ldr     w8, [x0, #0xe4]                            [62640e4]=0 f=0,0
02ca2428: ldr     x24, [x24, #0x70]                          S:'open_ad_id'
02ca242c: cbnz    w8, #0x2ca2438                             
02ca2430: bl      #0x2b70f30                                 fn_2b70f30
02ca2434: ldr     x0, [x21]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02ca2438: ldr     x8, [x0, #0xb8]                            MS:DG.Tweening.Core.Extensions::SetSpecialStartupMode
02ca243c: ldr     x1, [x24]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca2440: mov     x0, x20                                    
02ca2444: ldr     x3, [x22]                                  M:AdsManager::<OnApplicationPause>b__26_0
02ca2448: ldr     x2, [x8, #0x18]                            S:'level_show_popuprate'
02ca244c: bl      #0x452c61c                                 fn_452c61c
02ca2450: adrp    x24, #0x662f000                            
02ca2454: ldrb    w8, [x24, #0xa83]                          
02ca2458: cbnz    w8, #0x2ca2470                             
02ca245c: adrp    x0, #0x6264000                             
02ca2460: ldr     x0, [x0, #0xfc0]                           T:RemoteConfigManager
02ca2464: bl      #0x2b70db0                                 fn_2b70db0
02ca2468: mov     w8, #1                                     
02ca246c: strb    w8, [x24, #0xa83]                          
02ca2470: ldr     x0, [x21]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02ca2474: adrp    x24, #0x6266000                            
02ca2478: ldr     w8, [x0, #0xe4]                            [62640e4]=0 f=0,0
02ca247c: ldr     x24, [x24, #0x48]                          S:'native_full_srceen_id'
02ca2480: cbnz    w8, #0x2ca248c                             
02ca2484: bl      #0x2b70f30                                 fn_2b70f30
02ca2488: ldr     x0, [x21]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02ca248c: ldr     x8, [x0, #0xb8]                            MS:DG.Tweening.Core.Extensions::SetSpecialStartupMode
02ca2490: ldr     x1, [x24]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca2494: mov     x0, x20                                    
02ca2498: ldr     x3, [x22]                                  M:AdsManager::<OnApplicationPause>b__26_0
02ca249c: ldr     x2, [x8, #0x20]                            S:'inter_ad_capping_time'
02ca24a0: bl      #0x452c61c                                 fn_452c61c
02ca24a4: adrp    x24, #0x662f000                            
02ca24a8: ldrb    w8, [x24, #0xa84]                          
02ca24ac: cbnz    w8, #0x2ca24c4                             
02ca24b0: adrp    x0, #0x6264000                             
02ca24b4: ldr     x0, [x0, #0xfc0]                           T:RemoteConfigManager
02ca24b8: bl      #0x2b70db0                                 fn_2b70db0
02ca24bc: mov     w8, #1                                     
02ca24c0: strb    w8, [x24, #0xa84]                          
02ca24c4: ldr     x0, [x21]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02ca24c8: adrp    x24, #0x6266000                            
02ca24cc: ldr     w8, [x0, #0xe4]                            [62640e4]=0 f=0,0
02ca24d0: ldr     x24, [x24, #0x68]                          S:'native_full_srceen_time_showbtn'
02ca24d4: cbnz    w8, #0x2ca24e0                             
02ca24d8: bl      #0x2b70f30                                 fn_2b70f30
02ca24dc: ldr     x0, [x21]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02ca24e0: ldr     x8, [x0, #0xb8]                            MS:DG.Tweening.Core.Extensions::SetSpecialStartupMode
02ca24e4: ldr     x0, [x23, #0x48]                           &6263098(=0)
02ca24e8: add     x1, sp, #0x1c                              
02ca24ec: ldr     w8, [x8, #0x28]                            S:'banner_ad_on_off'
02ca24f0: str     w8, [sp, #0x1c]                            
02ca24f4: bl      #0x2b70f38                                 fn_2b70f38
02ca24f8: ldr     x1, [x24]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca24fc: ldr     x3, [x22]                                  M:AdsManager::<OnApplicationPause>b__26_0
02ca2500: mov     x2, x0                                     
02ca2504: mov     x0, x20                                    
02ca2508: bl      #0x452c61c                                 fn_452c61c
02ca250c: adrp    x24, #0x662f000                            
02ca2510: ldrb    w8, [x24, #0xa80]                          
02ca2514: cbnz    w8, #0x2ca252c                             
02ca2518: adrp    x0, #0x6264000                             
02ca251c: ldr     x0, [x0, #0xfc0]                           T:RemoteConfigManager
02ca2520: bl      #0x2b70db0                                 fn_2b70db0
02ca2524: mov     w8, #1                                     
02ca2528: strb    w8, [x24, #0xa80]                          
02ca252c: ldr     x0, [x21]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02ca2530: adrp    x24, #0x6266000                            
02ca2534: ldr     w8, [x0, #0xe4]                            [62640e4]=0 f=0,0
02ca2538: ldr     x24, [x24, #0x90]                          S:'mrec_ad_id'
02ca253c: cbnz    w8, #0x2ca2548                             
02ca2540: bl      #0x2b70f30                                 fn_2b70f30
02ca2544: ldr     x0, [x21]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02ca2548: ldr     x8, [x0, #0xb8]                            MS:DG.Tweening.Core.Extensions::SetSpecialStartupMode
02ca254c: ldr     x1, [x24]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca2550: mov     x0, x20                                    
02ca2554: ldr     x3, [x22]                                  M:AdsManager::<OnApplicationPause>b__26_0
02ca2558: ldr     x2, [x8, #0x30]                            S:'popup_rate_on_off'
02ca255c: bl      #0x452c61c                                 fn_452c61c
02ca2560: adrp    x24, #0x662f000                            
02ca2564: ldrb    w8, [x24, #0xbc3]                          
02ca2568: cbnz    w8, #0x2ca2580                             
02ca256c: adrp    x0, #0x6264000                             
02ca2570: ldr     x0, [x0, #0xfc0]                           T:RemoteConfigManager
02ca2574: bl      #0x2b70db0                                 fn_2b70db0
02ca2578: mov     w8, #1                                     
02ca257c: strb    w8, [x24, #0xbc3]                          
02ca2580: ldr     x0, [x21]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02ca2584: adrp    x24, #0x6266000                            
02ca2588: ldr     w8, [x0, #0xe4]                            [62640e4]=0 f=0,0
02ca258c: ldr     x24, [x24, #0x98]                          S:'force_update_version'
02ca2590: cbnz    w8, #0x2ca259c                             
02ca2594: bl      #0x2b70f30                                 fn_2b70f30
02ca2598: ldr     x0, [x21]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02ca259c: ldr     x8, [x0, #0xb8]                            MS:DG.Tweening.Core.Extensions::SetSpecialStartupMode
02ca25a0: ldr     x0, [x23, #0x28]                           [6263028]=0 f=0,0
02ca25a4: add     x1, sp, #0x18                              
02ca25a8: ldrb    w8, [x8, #0x38]                            
02ca25ac: strb    w8, [sp, #0x18]                            
02ca25b0: bl      #0x2b70f38                                 fn_2b70f38
02ca25b4: ldr     x1, [x24]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca25b8: ldr     x3, [x22]                                  M:AdsManager::<OnApplicationPause>b__26_0
02ca25bc: mov     x2, x0                                     
02ca25c0: mov     x0, x20                                    
02ca25c4: bl      #0x452c61c                                 fn_452c61c
02ca25c8: adrp    x24, #0x662f000                            
02ca25cc: ldrb    w8, [x24, #0xa86]                          
02ca25d0: cbnz    w8, #0x2ca25e8                             
02ca25d4: adrp    x0, #0x6264000                             
02ca25d8: ldr     x0, [x0, #0xfc0]                           T:RemoteConfigManager
02ca25dc: bl      #0x2b70db0                                 fn_2b70db0
02ca25e0: mov     w8, #1                                     
02ca25e4: strb    w8, [x24, #0xa86]                          
02ca25e8: ldr     x0, [x21]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02ca25ec: adrp    x24, #0x6266000                            
02ca25f0: ldr     w8, [x0, #0xe4]                            [62640e4]=0 f=0,0
02ca25f4: ldr     x24, [x24, #0xb0]                          S:'native_banner_ad_on_off'
02ca25f8: cbnz    w8, #0x2ca2604                             
02ca25fc: bl      #0x2b70f30                                 fn_2b70f30
02ca2600: ldr     x0, [x21]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02ca2604: ldr     x8, [x0, #0xb8]                            MS:DG.Tweening.Core.Extensions::SetSpecialStartupMode
02ca2608: ldr     x0, [x23, #0x28]                           [6263028]=0 f=0,0
02ca260c: add     x1, sp, #0x14                              
02ca2610: ldrb    w8, [x8, #0x39]                            
02ca2614: strb    w8, [sp, #0x14]                            
02ca2618: bl      #0x2b70f38                                 fn_2b70f38
02ca261c: ldr     x1, [x24]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca2620: ldr     x3, [x22]                                  M:AdsManager::<OnApplicationPause>b__26_0
02ca2624: mov     x2, x0                                     
02ca2628: mov     x0, x20                                    
02ca262c: bl      #0x452c61c                                 fn_452c61c
02ca2630: adrp    x24, #0x662f000                            
02ca2634: ldrb    w8, [x24, #0xa88]                          
02ca2638: cbnz    w8, #0x2ca2650                             
02ca263c: adrp    x0, #0x6264000                             
02ca2640: ldr     x0, [x0, #0xfc0]                           T:RemoteConfigManager
02ca2644: bl      #0x2b70db0                                 fn_2b70db0
02ca2648: mov     w8, #1                                     
02ca264c: strb    w8, [x24, #0xa88]                          
02ca2650: ldr     x0, [x21]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02ca2654: adrp    x24, #0x6266000                            
02ca2658: ldr     w8, [x0, #0xe4]                            [62640e4]=0 f=0,0
02ca265c: ldr     x24, [x24, #0x40]                          S:'native_collap_ad_on_off'
02ca2660: cbnz    w8, #0x2ca266c                             
02ca2664: bl      #0x2b70f30                                 fn_2b70f30
02ca2668: ldr     x0, [x21]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02ca266c: ldr     x8, [x0, #0xb8]                            MS:DG.Tweening.Core.Extensions::SetSpecialStartupMode
02ca2670: ldr     x0, [x23, #0x28]                           [6263028]=0 f=0,0
02ca2674: add     x1, sp, #0x10                              
02ca2678: ldrb    w8, [x8, #0x3a]                            
02ca267c: strb    w8, [sp, #0x10]                            
02ca2680: bl      #0x2b70f38                                 fn_2b70f38
02ca2684: ldr     x1, [x24]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca2688: ldr     x3, [x22]                                  M:AdsManager::<OnApplicationPause>b__26_0
02ca268c: mov     x2, x0                                     
02ca2690: mov     x0, x20                                    
02ca2694: bl      #0x452c61c                                 fn_452c61c
02ca2698: adrp    x24, #0x662f000                            
02ca269c: ldrb    w8, [x24, #0xa87]                          
02ca26a0: cbnz    w8, #0x2ca26b8                             
02ca26a4: adrp    x0, #0x6264000                             
02ca26a8: ldr     x0, [x0, #0xfc0]                           T:RemoteConfigManager
02ca26ac: bl      #0x2b70db0                                 fn_2b70db0
02ca26b0: mov     w8, #1                                     
02ca26b4: strb    w8, [x24, #0xa87]                          
02ca26b8: ldr     x0, [x21]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02ca26bc: adrp    x24, #0x6266000                            
02ca26c0: ldr     w8, [x0, #0xe4]                            [62640e4]=0 f=0,0
02ca26c4: ldr     x24, [x24, #0xb8]                          S:'banner_native_refresh_time'
02ca26c8: cbnz    w8, #0x2ca26d4                             
02ca26cc: bl      #0x2b70f30                                 fn_2b70f30
02ca26d0: ldr     x0, [x21]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02ca26d4: ldr     x8, [x0, #0xb8]                            MS:DG.Tweening.Core.Extensions::SetSpecialStartupMode
02ca26d8: ldr     x0, [x23, #0x48]                           &6263098(=0)
02ca26dc: add     x1, sp, #0xc                               
02ca26e0: ldr     w8, [x8, #0x3c]                            [626603c]=0 f=0,0
02ca26e4: str     w8, [sp, #0xc]                             
02ca26e8: bl      #0x2b70f38                                 fn_2b70f38
02ca26ec: ldr     x1, [x24]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca26f0: ldr     x3, [x22]                                  M:AdsManager::<OnApplicationPause>b__26_0
02ca26f4: mov     x2, x0                                     
02ca26f8: mov     x0, x20                                    
02ca26fc: bl      #0x452c61c                                 fn_452c61c
02ca2700: adrp    x23, #0x662f000                            
02ca2704: ldrb    w8, [x23, #0xa82]                          
02ca2708: cbnz    w8, #0x2ca2720                             
02ca270c: adrp    x0, #0x6264000                             
02ca2710: ldr     x0, [x0, #0xfc0]                           T:RemoteConfigManager
02ca2714: bl      #0x2b70db0                                 fn_2b70db0
02ca2718: mov     w8, #1                                     
02ca271c: strb    w8, [x23, #0xa82]                          
02ca2720: ldr     x0, [x21]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02ca2724: adrp    x23, #0x6266000                            
02ca2728: ldr     w8, [x0, #0xe4]                            [62640e4]=0 f=0,0
02ca272c: ldr     x23, [x23, #0x88]                          S:'native_banner_id'
02ca2730: cbnz    w8, #0x2ca273c                             
02ca2734: bl      #0x2b70f30                                 fn_2b70f30
02ca2738: ldr     x0, [x21]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02ca273c: ldr     x8, [x0, #0xb8]                            MS:DG.Tweening.Core.Extensions::SetSpecialStartupMode
02ca2740: ldr     x1, [x23]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca2744: mov     x0, x20                                    
02ca2748: ldr     x3, [x22]                                  M:AdsManager::<OnApplicationPause>b__26_0
02ca274c: ldr     x2, [x8, #0x40]                            S:'native_collap_ad_on_off'
02ca2750: bl      #0x452c61c                                 fn_452c61c
02ca2754: adrp    x23, #0x662f000                            
02ca2758: ldrb    w8, [x23, #0xa85]                          
02ca275c: cbnz    w8, #0x2ca2774                             
02ca2760: adrp    x0, #0x6264000                             
02ca2764: ldr     x0, [x0, #0xfc0]                           T:RemoteConfigManager
02ca2768: bl      #0x2b70db0                                 fn_2b70db0
02ca276c: mov     w8, #1                                     
02ca2770: strb    w8, [x23, #0xa85]                          
02ca2774: ldr     x0, [x21]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02ca2778: adrp    x24, #0x6266000                            
02ca277c: adrp    x23, #0x6265000                            
02ca2780: ldr     x24, [x24, #0x38]                          S:'native_collap_id'
02ca2784: ldr     w8, [x0, #0xe4]                            [62640e4]=0 f=0,0
02ca2788: ldr     x23, [x23, #0xf88]                         T:Firebase.RemoteConfig.FirebaseRemoteConfig
02ca278c: cbnz    w8, #0x2ca2798                             
02ca2790: bl      #0x2b70f30                                 fn_2b70f30
02ca2794: ldr     x0, [x21]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02ca2798: ldr     x8, [x0, #0xb8]                            MS:DG.Tweening.Core.Extensions::SetSpecialStartupMode
02ca279c: ldr     x1, [x24]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca27a0: mov     x0, x20                                    
02ca27a4: ldr     x3, [x22]                                  M:AdsManager::<OnApplicationPause>b__26_0
02ca27a8: ldr     x2, [x8, #0x48]                            S:'native_full_srceen_id'
02ca27ac: bl      #0x452c61c                                 fn_452c61c
02ca27b0: mov     x21, x19                                   
02ca27b4: mov     x1, x20                                    
02ca27b8: str     x20, [x21, #0x28]!                         .defaults
02ca27bc: mov     x0, x21                                    
02ca27c0: bl      #0x2b70d54                                 fn_2b70d54
02ca27c4: ldr     x0, [x23]                                  M:AdsManager::<OnApplicationPause>b__26_0
02ca27c8: ldr     w8, [x0, #0xe4]                            [62640e4]=0 f=0,0
02ca27cc: cbnz    w8, #0x2ca27d4                             
02ca27d0: bl      #0x2b70f30                                 fn_2b70f30
02ca27d4: mov     x0, xzr                                    
02ca27d8: bl      #0x2e45fa0                                 Firebase.RemoteConfig.FirebaseRemoteConfig::get_DefaultInstance
02ca27dc: cbz     x0, #0x2ca28d4                             
02ca27e0: ldr     x1, [x21]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02ca27e4: mov     x2, xzr                                    
02ca27e8: bl      #0x2e465f4                                 Firebase.RemoteConfig.FirebaseRemoteConfig::SetDefaultsAsync
02ca27ec: mov     x0, xzr                                    
02ca27f0: bl      #0x2e45fa0                                 Firebase.RemoteConfig.FirebaseRemoteConfig::get_DefaultInstance
02ca27f4: cbz     x0, #0x2ca28d4                             
02ca27f8: mov     x1, xzr                                    
02ca27fc: bl      #0x2e47b90                                 Firebase.RemoteConfig.FirebaseRemoteConfig::get_Info
02ca2800: cbz     x0, #0x2ca28d4                             
02ca2804: ldr     w8, [x0, #0x28]                            T:type8534(k15) .defaults
02ca2808: cmp     w8, #2                                     
02ca280c: b.eq    #0x2ca28ac                                 
02ca2810: cmp     w8, #1                                     
02ca2814: b.eq    #0x2ca2890                                 
02ca2818: cbnz    w8, #0x2ca28bc                             
02ca281c: ldr     x0, [x23]                                  M:AdsManager::<OnApplicationPause>b__26_0
02ca2820: ldr     w8, [x0, #0xe4]                            [62640e4]=0 f=0,0
02ca2824: cbnz    w8, #0x2ca282c                             
02ca2828: bl      #0x2b70f30                                 fn_2b70f30
02ca282c: mov     x0, xzr                                    
02ca2830: bl      #0x2e45fa0                                 Firebase.RemoteConfig.FirebaseRemoteConfig::get_DefaultInstance
02ca2834: cbz     x0, #0x2ca28d4                             
02ca2838: mov     x1, xzr                                    
02ca283c: bl      #0x2e46168                                 Firebase.RemoteConfig.FirebaseRemoteConfig::ActivateAsync
02ca2840: adrp    x8, #0x6265000                             
02ca2844: mov     x20, x0                                    
02ca2848: ldr     x8, [x8, #0xff8]                           T:type53111(k15)
02ca284c: ldr     x8, [x8]                                   M:AdsManager::<OnApplicationPause>b__26_0
02ca2850: mov     x0, x8                                     
02ca2854: bl      #0x2b7104c                                 fn_2b7104c
02ca2858: adrp    x8, #0x6266000                             
02ca285c: mov     x1, x19                                    
02ca2860: mov     x3, xzr                                    
02ca2864: ldr     x8, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca2868: mov     x21, x0                                    
02ca286c: ldr     x2, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca2870: bl      #0x453418c                                 fn_453418c
02ca2874: adrp    x8, #0x6266000                             
02ca2878: mov     x0, x20                                    
02ca287c: mov     x1, x21                                    
02ca2880: ldr     x8, [x8, #8]                               MS:Firebase.Extensions.TaskExtension::ContinueWithOnMainThread
02ca2884: ldr     x2, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca2888: bl      #0x3360fe4                                 fn_3360fe4
02ca288c: b       #0x2ca28bc                                 
02ca2890: adrp    x8, #0x6266000                             
02ca2894: ldr     x8, [x8, #0x80]                            S:'Fetch failed.'
02ca2898: ldr     x0, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca289c: bl      #0x2ca09f8                                 WLog::LogError
02ca28a0: mov     x0, x19                                    
02ca28a4: bl      #0x2ca1d60                                 RemoteConfigManager::RetryFetch
02ca28a8: b       #0x2ca28bc                                 
02ca28ac: adrp    x8, #0x6266000                             
02ca28b0: ldr     x8, [x8, #0x78]                            S:'Latest Fetch call still pending.'
02ca28b4: ldr     x0, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca28b8: bl      #0x2ca09f8                                 WLog::LogError
02ca28bc: ldp     x20, x19, [sp, #0x70]                      
02ca28c0: ldr     x30, [sp, #0x40]                           
02ca28c4: ldp     x22, x21, [sp, #0x60]                      
02ca28c8: ldp     x24, x23, [sp, #0x50]                      
02ca28cc: add     sp, sp, #0x80                              
02ca28d0: ret                                                
02ca28d4: bl      #0x2b7105c                                 fn_2b7105c
## SetRemoteValue() -> void
---- RemoteConfigManager::SetRemoteValue 0x2ca28d8
02ca28d8: sub     sp, sp, #0x30                              
02ca28dc: stp     x30, x21, [sp, #0x10]                      
02ca28e0: stp     x20, x19, [sp, #0x20]                      
02ca28e4: adrp    x20, #0x662f000                            
02ca28e8: adrp    x19, #0x6265000                            
02ca28ec: ldrb    w8, [x20, #0xaba]                          
02ca28f0: ldr     x19, [x19, #0xf88]                         T:Firebase.RemoteConfig.FirebaseRemoteConfig
02ca28f4: tbnz    w8, #0, #0x2ca29f0                         
02ca28f8: adrp    x0, #0x6266000                             
02ca28fc: ldr     x0, [x0, #0xc0]                            T:Firebase.RemoteConfig.ConfigValue
02ca2900: bl      #0x2b70db0                                 fn_2b70db0
02ca2904: adrp    x0, #0x6265000                             
02ca2908: ldr     x0, [x0, #0xf88]                           T:Firebase.RemoteConfig.FirebaseRemoteConfig
02ca290c: bl      #0x2b70db0                                 fn_2b70db0
02ca2910: adrp    x0, #0x6264000                             
02ca2914: ldr     x0, [x0, #0xfc0]                           T:RemoteConfigManager
02ca2918: bl      #0x2b70db0                                 fn_2b70db0
02ca291c: adrp    x0, #0x6266000                             
02ca2920: ldr     x0, [x0, #0x10]                            S:'mrec_ad_on_off' .<data_config_type>k__BackingField
02ca2924: bl      #0x2b70db0                                 fn_2b70db0
02ca2928: adrp    x0, #0x6266000                             
02ca292c: ldr     x0, [x0, #0x18]                            S:'level_show_popuprate' .<open_ad_id>k__BackingField
02ca2930: bl      #0x2b70db0                                 fn_2b70db0
02ca2934: adrp    x0, #0x6266000                             
02ca2938: ldr     x0, [x0, #0x20]                            S:'inter_ad_capping_time' ._currentRetry
02ca293c: bl      #0x2b70db0                                 fn_2b70db0
02ca2940: adrp    x0, #0x6266000                             
02ca2944: ldr     x0, [x0, #0x28]                            S:'banner_ad_on_off' .defaults
02ca2948: bl      #0x2b70db0                                 fn_2b70db0
02ca294c: adrp    x0, #0x6266000                             
02ca2950: ldr     x0, [x0, #0x30]                            S:'popup_rate_on_off' .<mrec_ad_id>k__BackingField
02ca2954: bl      #0x2b70db0                                 fn_2b70db0
02ca2958: adrp    x0, #0x6266000                             
02ca295c: ldr     x0, [x0, #0x38]                            S:'native_collap_id' .<force_update_version>k__BackingField
02ca2960: bl      #0x2b70db0                                 fn_2b70db0
02ca2964: adrp    x0, #0x6266000                             
02ca2968: ldr     x0, [x0, #0x48]                            S:'native_full_srceen_id' .<native_collap_id>k__BackingField
02ca296c: bl      #0x2b70db0                                 fn_2b70db0
02ca2970: adrp    x0, #0x6266000                             
02ca2974: ldr     x0, [x0, #0x58]                            S:'inter_ad_on_off'
02ca2978: bl      #0x2b70db0                                 fn_2b70db0
02ca297c: adrp    x0, #0x6266000                             
02ca2980: ldr     x0, [x0, #0x60]                            S:'open_ad_on_off'
02ca2984: bl      #0x2b70db0                                 fn_2b70db0
02ca2988: adrp    x0, #0x6266000                             
02ca298c: ldr     x0, [x0, #0x68]                            S:'native_full_srceen_time_showbtn'
02ca2990: bl      #0x2b70db0                                 fn_2b70db0
02ca2994: adrp    x0, #0x6266000                             
02ca2998: ldr     x0, [x0, #0x70]                            S:'open_ad_id'
02ca299c: bl      #0x2b70db0                                 fn_2b70db0
02ca29a0: adrp    x0, #0x6266000                             
02ca29a4: ldr     x0, [x0, #0x88]                            S:'native_banner_id'
02ca29a8: bl      #0x2b70db0                                 fn_2b70db0
02ca29ac: adrp    x0, #0x6266000                             
02ca29b0: ldr     x0, [x0, #0x90]                            S:'mrec_ad_id'
02ca29b4: bl      #0x2b70db0                                 fn_2b70db0
02ca29b8: adrp    x0, #0x6266000                             
02ca29bc: ldr     x0, [x0, #0x98]                            S:'force_update_version'
02ca29c0: bl      #0x2b70db0                                 fn_2b70db0
02ca29c4: adrp    x0, #0x6266000                             
02ca29c8: ldr     x0, [x0, #0xa0]                            S:'open_ad_capping_time'
02ca29cc: bl      #0x2b70db0                                 fn_2b70db0
02ca29d0: adrp    x0, #0x6266000                             
02ca29d4: ldr     x0, [x0, #0xa8]                            S:'data_config_type'
02ca29d8: bl      #0x2b70db0                                 fn_2b70db0
02ca29dc: adrp    x0, #0x6266000                             
02ca29e0: ldr     x0, [x0, #0xb8]                            S:'banner_native_refresh_time'
02ca29e4: bl      #0x2b70db0                                 fn_2b70db0
02ca29e8: mov     w8, #1                                     
02ca29ec: strb    w8, [x20, #0xaba]                          
02ca29f0: ldr     x0, [x19]                                  M:AdsManager::<OnApplicationPause>b__26_0
02ca29f4: stp     xzr, xzr, [sp]                             
02ca29f8: ldr     w8, [x0, #0xe4]                            [62660e4]=0 f=0,0
02ca29fc: cbnz    w8, #0x2ca2a04                             
02ca2a00: bl      #0x2b70f30                                 fn_2b70f30
02ca2a04: mov     x0, xzr                                    
02ca2a08: bl      #0x2e45fa0                                 Firebase.RemoteConfig.FirebaseRemoteConfig::get_DefaultInstance
02ca2a0c: cbz     x0, #0x2ca3324                             
02ca2a10: adrp    x8, #0x6266000                             
02ca2a14: adrp    x20, #0x6266000                            
02ca2a18: adrp    x19, #0x6264000                            
02ca2a1c: ldr     x8, [x8, #0x58]                            S:'inter_ad_on_off'
02ca2a20: ldr     x20, [x20, #0xc0]                          T:Firebase.RemoteConfig.ConfigValue
02ca2a24: ldr     x19, [x19, #0xfc0]                         T:RemoteConfigManager
02ca2a28: mov     x2, xzr                                    
02ca2a2c: ldr     x1, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca2a30: bl      #0x2e471a0                                 Firebase.RemoteConfig.FirebaseRemoteConfig::GetValue
02ca2a34: mov     x8, x0                                     
02ca2a38: ldr     x0, [x20]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca2a3c: stp     x8, x1, [sp]                               
02ca2a40: ldr     w9, [x0, #0xe4]                            [62660e4]=0 f=0,0
02ca2a44: cbnz    w9, #0x2ca2a4c                             
02ca2a48: bl      #0x2b70f30                                 fn_2b70f30
02ca2a4c: mov     x0, sp                                     
02ca2a50: mov     x1, xzr                                    
02ca2a54: bl      #0x2e44b88                                 Firebase.RemoteConfig.ConfigValue::get_BooleanValue
02ca2a58: ldr     x8, [x19]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02ca2a5c: mov     w20, w0                                    
02ca2a60: ldr     w9, [x8, #0xe4]                            [62660e4]=0 f=0,0
02ca2a64: cbnz    w9, #0x2ca2a70                             
02ca2a68: mov     x0, x8                                     
02ca2a6c: bl      #0x2b70f30                                 fn_2b70f30
02ca2a70: adrp    x21, #0x662f000                            
02ca2a74: ldrb    w8, [x21, #0xbc4]                          
02ca2a78: cbnz    w8, #0x2ca2a90                             
02ca2a7c: adrp    x0, #0x6264000                             
02ca2a80: ldr     x0, [x0, #0xfc0]                           T:RemoteConfigManager
02ca2a84: bl      #0x2b70db0                                 fn_2b70db0
02ca2a88: mov     w8, #1                                     
02ca2a8c: strb    w8, [x21, #0xbc4]                          
02ca2a90: ldr     x0, [x19]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02ca2a94: ldr     w8, [x0, #0xe4]                            [62640e4]=0 f=0,0
02ca2a98: cbnz    w8, #0x2ca2aa4                             
02ca2a9c: bl      #0x2b70f30                                 fn_2b70f30
02ca2aa0: ldr     x0, [x19]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02ca2aa4: ldr     x8, [x0, #0xb8]                            MS:DG.Tweening.Core.Extensions::SetSpecialStartupMode
02ca2aa8: and     w9, w20, #1                                
02ca2aac: mov     x0, xzr                                    
02ca2ab0: strb    w9, [x8]                                   
02ca2ab4: bl      #0x2e45fa0                                 Firebase.RemoteConfig.FirebaseRemoteConfig::get_DefaultInstance
02ca2ab8: cbz     x0, #0x2ca3324                             
02ca2abc: adrp    x8, #0x6266000                             
02ca2ac0: mov     x2, xzr                                    
02ca2ac4: ldr     x8, [x8, #0x20]                            S:'inter_ad_capping_time'
02ca2ac8: ldr     x1, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca2acc: bl      #0x2e471a0                                 Firebase.RemoteConfig.FirebaseRemoteConfig::GetValue
02ca2ad0: stp     x0, x1, [sp]                               
02ca2ad4: mov     x0, sp                                     
02ca2ad8: mov     x1, xzr                                    
02ca2adc: bl      #0x2e44d68                                 Firebase.RemoteConfig.ConfigValue::get_DoubleValue
02ca2ae0: mov     x8, #0x7ff0000000000000                    
02ca2ae4: fcvtzs  w9, d0                                     
02ca2ae8: adrp    x21, #0x662f000                            
02ca2aec: fmov    d1, x8                                     
02ca2af0: ldrb    w8, [x21, #0xbc5]                          
02ca2af4: mov     w10, #-0xffffffff80000000                  
02ca2af8: fcmp    d0, d1                                     
02ca2afc: csel    w20, w10, w9, eq                           
02ca2b00: cbnz    w8, #0x2ca2b18                             
02ca2b04: adrp    x0, #0x6264000                             
02ca2b08: ldr     x0, [x0, #0xfc0]                           T:RemoteConfigManager
02ca2b0c: bl      #0x2b70db0                                 fn_2b70db0
02ca2b10: mov     w8, #1                                     
02ca2b14: strb    w8, [x21, #0xbc5]                          
02ca2b18: ldr     x0, [x19]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02ca2b1c: ldr     w8, [x0, #0xe4]                            [62640e4]=0 f=0,0
02ca2b20: cbnz    w8, #0x2ca2b2c                             
02ca2b24: bl      #0x2b70f30                                 fn_2b70f30
02ca2b28: ldr     x0, [x19]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02ca2b2c: ldr     x8, [x0, #0xb8]                            MS:DG.Tweening.Core.Extensions::SetSpecialStartupMode
02ca2b30: mov     x0, xzr                                    
02ca2b34: str     w20, [x8, #4]                              
02ca2b38: bl      #0x2e45fa0                                 Firebase.RemoteConfig.FirebaseRemoteConfig::get_DefaultInstance
02ca2b3c: cbz     x0, #0x2ca3324                             
02ca2b40: adrp    x8, #0x6266000                             
02ca2b44: mov     x2, xzr                                    
02ca2b48: ldr     x8, [x8, #0x10]                            S:'mrec_ad_on_off'
02ca2b4c: ldr     x1, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca2b50: bl      #0x2e471a0                                 Firebase.RemoteConfig.FirebaseRemoteConfig::GetValue
02ca2b54: stp     x0, x1, [sp]                               
02ca2b58: mov     x0, sp                                     
02ca2b5c: mov     x1, xzr                                    
02ca2b60: bl      #0x2e44b88                                 Firebase.RemoteConfig.ConfigValue::get_BooleanValue
02ca2b64: adrp    x21, #0x662f000                            
02ca2b68: mov     w20, w0                                    
02ca2b6c: ldrb    w8, [x21, #0xbc6]                          
02ca2b70: cbnz    w8, #0x2ca2b88                             
02ca2b74: adrp    x0, #0x6264000                             
02ca2b78: ldr     x0, [x0, #0xfc0]                           T:RemoteConfigManager
02ca2b7c: bl      #0x2b70db0                                 fn_2b70db0
02ca2b80: mov     w8, #1                                     
02ca2b84: strb    w8, [x21, #0xbc6]                          
02ca2b88: ldr     x0, [x19]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02ca2b8c: ldr     w8, [x0, #0xe4]                            [62640e4]=0 f=0,0
02ca2b90: cbnz    w8, #0x2ca2b9c                             
02ca2b94: bl      #0x2b70f30                                 fn_2b70f30
02ca2b98: ldr     x0, [x19]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02ca2b9c: ldr     x8, [x0, #0xb8]                            MS:DG.Tweening.Core.Extensions::SetSpecialStartupMode
02ca2ba0: and     w9, w20, #1                                
02ca2ba4: mov     x0, xzr                                    
02ca2ba8: strb    w9, [x8, #1]                               
02ca2bac: bl      #0x2e45fa0                                 Firebase.RemoteConfig.FirebaseRemoteConfig::get_DefaultInstance
02ca2bb0: cbz     x0, #0x2ca3324                             
02ca2bb4: adrp    x8, #0x6266000                             
02ca2bb8: mov     x2, xzr                                    
02ca2bbc: ldr     x8, [x8, #0x28]                            S:'banner_ad_on_off'
02ca2bc0: ldr     x1, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca2bc4: bl      #0x2e471a0                                 Firebase.RemoteConfig.FirebaseRemoteConfig::GetValue
02ca2bc8: stp     x0, x1, [sp]                               
02ca2bcc: mov     x0, sp                                     
02ca2bd0: mov     x1, xzr                                    
02ca2bd4: bl      #0x2e44b88                                 Firebase.RemoteConfig.ConfigValue::get_BooleanValue
02ca2bd8: adrp    x21, #0x662f000                            
02ca2bdc: mov     w20, w0                                    
02ca2be0: ldrb    w8, [x21, #0xbc7]                          
02ca2be4: cbnz    w8, #0x2ca2bfc                             
02ca2be8: adrp    x0, #0x6264000                             
02ca2bec: ldr     x0, [x0, #0xfc0]                           T:RemoteConfigManager
02ca2bf0: bl      #0x2b70db0                                 fn_2b70db0
02ca2bf4: mov     w8, #1                                     
02ca2bf8: strb    w8, [x21, #0xbc7]                          
02ca2bfc: ldr     x0, [x19]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02ca2c00: ldr     w8, [x0, #0xe4]                            [62640e4]=0 f=0,0
02ca2c04: cbnz    w8, #0x2ca2c10                             
02ca2c08: bl      #0x2b70f30                                 fn_2b70f30
02ca2c0c: ldr     x0, [x19]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02ca2c10: ldr     x8, [x0, #0xb8]                            MS:DG.Tweening.Core.Extensions::SetSpecialStartupMode
02ca2c14: and     w9, w20, #1                                
02ca2c18: mov     x0, xzr                                    
02ca2c1c: strb    w9, [x8, #2]                               
02ca2c20: bl      #0x2e45fa0                                 Firebase.RemoteConfig.FirebaseRemoteConfig::get_DefaultInstance
02ca2c24: cbz     x0, #0x2ca3324                             
02ca2c28: adrp    x8, #0x6266000                             
02ca2c2c: mov     x2, xzr                                    
02ca2c30: ldr     x8, [x8, #0x60]                            S:'open_ad_on_off'
02ca2c34: ldr     x1, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca2c38: bl      #0x2e471a0                                 Firebase.RemoteConfig.FirebaseRemoteConfig::GetValue
02ca2c3c: stp     x0, x1, [sp]                               
02ca2c40: mov     x0, sp                                     
02ca2c44: mov     x1, xzr                                    
02ca2c48: bl      #0x2e44b88                                 Firebase.RemoteConfig.ConfigValue::get_BooleanValue
02ca2c4c: adrp    x21, #0x662f000                            
02ca2c50: mov     w20, w0                                    
02ca2c54: ldrb    w8, [x21, #0xbc8]                          
02ca2c58: cbnz    w8, #0x2ca2c70                             
02ca2c5c: adrp    x0, #0x6264000                             
02ca2c60: ldr     x0, [x0, #0xfc0]                           T:RemoteConfigManager
02ca2c64: bl      #0x2b70db0                                 fn_2b70db0
02ca2c68: mov     w8, #1                                     
02ca2c6c: strb    w8, [x21, #0xbc8]                          
02ca2c70: ldr     x0, [x19]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02ca2c74: ldr     w8, [x0, #0xe4]                            [62640e4]=0 f=0,0
02ca2c78: cbnz    w8, #0x2ca2c84                             
02ca2c7c: bl      #0x2b70f30                                 fn_2b70f30
02ca2c80: ldr     x0, [x19]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02ca2c84: ldr     x8, [x0, #0xb8]                            MS:DG.Tweening.Core.Extensions::SetSpecialStartupMode
02ca2c88: and     w9, w20, #1                                
02ca2c8c: mov     x0, xzr                                    
02ca2c90: strb    w9, [x8, #3]                               
02ca2c94: bl      #0x2e45fa0                                 Firebase.RemoteConfig.FirebaseRemoteConfig::get_DefaultInstance
02ca2c98: cbz     x0, #0x2ca3324                             
02ca2c9c: adrp    x8, #0x6266000                             
02ca2ca0: mov     x2, xzr                                    
02ca2ca4: ldr     x8, [x8, #0xa0]                            S:'open_ad_capping_time'
02ca2ca8: ldr     x1, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca2cac: bl      #0x2e471a0                                 Firebase.RemoteConfig.FirebaseRemoteConfig::GetValue
02ca2cb0: stp     x0, x1, [sp]                               
02ca2cb4: mov     x0, sp                                     
02ca2cb8: mov     x1, xzr                                    
02ca2cbc: bl      #0x2e44d68                                 Firebase.RemoteConfig.ConfigValue::get_DoubleValue
02ca2cc0: mov     x8, #0x7ff0000000000000                    
02ca2cc4: fcvtzs  w9, d0                                     
02ca2cc8: adrp    x21, #0x662f000                            
02ca2ccc: fmov    d1, x8                                     
02ca2cd0: ldrb    w8, [x21, #0xbc9]                          
02ca2cd4: mov     w10, #-0xffffffff80000000                  
02ca2cd8: fcmp    d0, d1                                     
02ca2cdc: csel    w20, w10, w9, eq                           
02ca2ce0: cbnz    w8, #0x2ca2cf8                             
02ca2ce4: adrp    x0, #0x6264000                             
02ca2ce8: ldr     x0, [x0, #0xfc0]                           T:RemoteConfigManager
02ca2cec: bl      #0x2b70db0                                 fn_2b70db0
02ca2cf0: mov     w8, #1                                     
02ca2cf4: strb    w8, [x21, #0xbc9]                          
02ca2cf8: ldr     x0, [x19]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02ca2cfc: ldr     w8, [x0, #0xe4]                            [62640e4]=0 f=0,0
02ca2d00: cbnz    w8, #0x2ca2d0c                             
02ca2d04: bl      #0x2b70f30                                 fn_2b70f30
02ca2d08: ldr     x0, [x19]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02ca2d0c: ldr     x8, [x0, #0xb8]                            MS:DG.Tweening.Core.Extensions::SetSpecialStartupMode
02ca2d10: mov     x0, xzr                                    
02ca2d14: str     w20, [x8, #8]                              
02ca2d18: bl      #0x2e45fa0                                 Firebase.RemoteConfig.FirebaseRemoteConfig::get_DefaultInstance
02ca2d1c: cbz     x0, #0x2ca3324                             
02ca2d20: adrp    x8, #0x6266000                             
02ca2d24: mov     x2, xzr                                    
02ca2d28: ldr     x8, [x8, #0x18]                            S:'level_show_popuprate'
02ca2d2c: ldr     x1, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca2d30: bl      #0x2e471a0                                 Firebase.RemoteConfig.FirebaseRemoteConfig::GetValue
02ca2d34: stp     x0, x1, [sp]                               
02ca2d38: mov     x0, sp                                     
02ca2d3c: mov     x1, xzr                                    
02ca2d40: bl      #0x2e44d68                                 Firebase.RemoteConfig.ConfigValue::get_DoubleValue
02ca2d44: mov     x8, #0x7ff0000000000000                    
02ca2d48: fcvtzs  w9, d0                                     
02ca2d4c: adrp    x21, #0x662f000                            
02ca2d50: fmov    d1, x8                                     
02ca2d54: ldrb    w8, [x21, #0xbca]                          
02ca2d58: mov     w10, #-0xffffffff80000000                  
02ca2d5c: fcmp    d0, d1                                     
02ca2d60: csel    w20, w10, w9, eq                           
02ca2d64: cbnz    w8, #0x2ca2d7c                             
02ca2d68: adrp    x0, #0x6264000                             
02ca2d6c: ldr     x0, [x0, #0xfc0]                           T:RemoteConfigManager
02ca2d70: bl      #0x2b70db0                                 fn_2b70db0
02ca2d74: mov     w8, #1                                     
02ca2d78: strb    w8, [x21, #0xbca]                          
02ca2d7c: ldr     x0, [x19]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02ca2d80: ldr     w8, [x0, #0xe4]                            [62640e4]=0 f=0,0
02ca2d84: cbnz    w8, #0x2ca2d90                             
02ca2d88: bl      #0x2b70f30                                 fn_2b70f30
02ca2d8c: ldr     x0, [x19]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02ca2d90: ldr     x8, [x0, #0xb8]                            MS:DG.Tweening.Core.Extensions::SetSpecialStartupMode
02ca2d94: mov     x0, xzr                                    
02ca2d98: str     w20, [x8, #0xc]                            
02ca2d9c: bl      #0x2e45fa0                                 Firebase.RemoteConfig.FirebaseRemoteConfig::get_DefaultInstance
02ca2da0: cbz     x0, #0x2ca3324                             
02ca2da4: adrp    x8, #0x6266000                             
02ca2da8: mov     x2, xzr                                    
02ca2dac: ldr     x8, [x8, #0xa8]                            S:'data_config_type'
02ca2db0: ldr     x1, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca2db4: bl      #0x2e471a0                                 Firebase.RemoteConfig.FirebaseRemoteConfig::GetValue
02ca2db8: stp     x0, x1, [sp]                               
02ca2dbc: mov     x0, sp                                     
02ca2dc0: mov     x1, xzr                                    
02ca2dc4: bl      #0x2e44d68                                 Firebase.RemoteConfig.ConfigValue::get_DoubleValue
02ca2dc8: mov     x8, #0x7ff0000000000000                    
02ca2dcc: fcvtzs  w9, d0                                     
02ca2dd0: adrp    x21, #0x662f000                            
02ca2dd4: fmov    d1, x8                                     
02ca2dd8: ldrb    w8, [x21, #0xbcb]                          
02ca2ddc: mov     w10, #-0xffffffff80000000                  
02ca2de0: fcmp    d0, d1                                     
02ca2de4: csel    w20, w10, w9, eq                           
02ca2de8: cbnz    w8, #0x2ca2e00                             
02ca2dec: adrp    x0, #0x6264000                             
02ca2df0: ldr     x0, [x0, #0xfc0]                           T:RemoteConfigManager
02ca2df4: bl      #0x2b70db0                                 fn_2b70db0
02ca2df8: mov     w8, #1                                     
02ca2dfc: strb    w8, [x21, #0xbcb]                          
02ca2e00: ldr     x0, [x19]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02ca2e04: ldr     w8, [x0, #0xe4]                            [62640e4]=0 f=0,0
02ca2e08: cbnz    w8, #0x2ca2e14                             
02ca2e0c: bl      #0x2b70f30                                 fn_2b70f30
02ca2e10: ldr     x0, [x19]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02ca2e14: adrp    x21, #0x662f000                            
02ca2e18: ldr     x8, [x0, #0xb8]                            MS:DG.Tweening.Core.Extensions::SetSpecialStartupMode
02ca2e1c: ldrb    w9, [x21, #0xbcc]                          
02ca2e20: str     w20, [x8, #0x10]                           
02ca2e24: cbnz    w9, #0x2ca2e3c                             
02ca2e28: mov     x0, x19                                    
02ca2e2c: bl      #0x2b70db0                                 fn_2b70db0
02ca2e30: ldr     x0, [x19]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02ca2e34: mov     w8, #1                                     
02ca2e38: strb    w8, [x21, #0xbcc]                          
02ca2e3c: ldr     w8, [x0, #0xe4]                            [62640e4]=0 f=0,0
02ca2e40: cbnz    w8, #0x2ca2e4c                             
02ca2e44: bl      #0x2b70f30                                 fn_2b70f30
02ca2e48: ldr     x0, [x19]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02ca2e4c: ldr     x8, [x0, #0xb8]                            MS:DG.Tweening.Core.Extensions::SetSpecialStartupMode
02ca2e50: mov     w9, #1                                     
02ca2e54: mov     x0, xzr                                    
02ca2e58: strb    w9, [x8, #0x14]                            
02ca2e5c: bl      #0x2e45fa0                                 Firebase.RemoteConfig.FirebaseRemoteConfig::get_DefaultInstance
02ca2e60: cbz     x0, #0x2ca3324                             
02ca2e64: adrp    x8, #0x6266000                             
02ca2e68: mov     x2, xzr                                    
02ca2e6c: ldr     x8, [x8, #0x30]                            S:'popup_rate_on_off'
02ca2e70: ldr     x1, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca2e74: bl      #0x2e471a0                                 Firebase.RemoteConfig.FirebaseRemoteConfig::GetValue
02ca2e78: stp     x0, x1, [sp]                               
02ca2e7c: mov     x0, sp                                     
02ca2e80: mov     x1, xzr                                    
02ca2e84: bl      #0x2e44b88                                 Firebase.RemoteConfig.ConfigValue::get_BooleanValue
02ca2e88: adrp    x21, #0x662f000                            
02ca2e8c: mov     w20, w0                                    
02ca2e90: ldrb    w8, [x21, #0xbcd]                          
02ca2e94: cbnz    w8, #0x2ca2eac                             
02ca2e98: adrp    x0, #0x6264000                             
02ca2e9c: ldr     x0, [x0, #0xfc0]                           T:RemoteConfigManager
02ca2ea0: bl      #0x2b70db0                                 fn_2b70db0
02ca2ea4: mov     w8, #1                                     
02ca2ea8: strb    w8, [x21, #0xbcd]                          
02ca2eac: ldr     x0, [x19]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02ca2eb0: ldr     w8, [x0, #0xe4]                            [62640e4]=0 f=0,0
02ca2eb4: cbnz    w8, #0x2ca2ec0                             
02ca2eb8: bl      #0x2b70f30                                 fn_2b70f30
02ca2ebc: ldr     x0, [x19]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02ca2ec0: ldr     x8, [x0, #0xb8]                            MS:DG.Tweening.Core.Extensions::SetSpecialStartupMode
02ca2ec4: and     w9, w20, #1                                
02ca2ec8: mov     x0, xzr                                    
02ca2ecc: strb    w9, [x8, #0x15]                            
02ca2ed0: bl      #0x2e45fa0                                 Firebase.RemoteConfig.FirebaseRemoteConfig::get_DefaultInstance
02ca2ed4: cbz     x0, #0x2ca3324                             
02ca2ed8: adrp    x8, #0x6266000                             
02ca2edc: mov     x2, xzr                                    
02ca2ee0: ldr     x8, [x8, #0x70]                            S:'open_ad_id'
02ca2ee4: ldr     x1, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca2ee8: bl      #0x2e471a0                                 Firebase.RemoteConfig.FirebaseRemoteConfig::GetValue
02ca2eec: stp     x0, x1, [sp]                               
02ca2ef0: mov     x0, sp                                     
02ca2ef4: mov     x1, xzr                                    
02ca2ef8: bl      #0x2e44c98                                 Firebase.RemoteConfig.ConfigValue::get_StringValue
02ca2efc: adrp    x21, #0x662f000                            
02ca2f00: mov     x20, x0                                    
02ca2f04: ldrb    w8, [x21, #0xbce]                          
02ca2f08: cbnz    w8, #0x2ca2f20                             
02ca2f0c: adrp    x0, #0x6264000                             
02ca2f10: ldr     x0, [x0, #0xfc0]                           T:RemoteConfigManager
02ca2f14: bl      #0x2b70db0                                 fn_2b70db0
02ca2f18: mov     w8, #1                                     
02ca2f1c: strb    w8, [x21, #0xbce]                          
02ca2f20: ldr     x0, [x19]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02ca2f24: ldr     w8, [x0, #0xe4]                            [62640e4]=0 f=0,0
02ca2f28: cbnz    w8, #0x2ca2f34                             
02ca2f2c: bl      #0x2b70f30                                 fn_2b70f30
02ca2f30: ldr     x0, [x19]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02ca2f34: ldr     x0, [x0, #0xb8]                            MS:DG.Tweening.Core.Extensions::SetSpecialStartupMode
02ca2f38: mov     x1, x20                                    
02ca2f3c: str     x20, [x0, #0x18]!                          .<open_ad_id>k__BackingField
02ca2f40: bl      #0x2b70d54                                 fn_2b70d54
02ca2f44: mov     x0, xzr                                    
02ca2f48: bl      #0x2e45fa0                                 Firebase.RemoteConfig.FirebaseRemoteConfig::get_DefaultInstance
02ca2f4c: cbz     x0, #0x2ca3324                             
02ca2f50: adrp    x8, #0x6266000                             
02ca2f54: mov     x2, xzr                                    
02ca2f58: ldr     x8, [x8, #0x48]                            S:'native_full_srceen_id'
02ca2f5c: ldr     x1, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca2f60: bl      #0x2e471a0                                 Firebase.RemoteConfig.FirebaseRemoteConfig::GetValue
02ca2f64: stp     x0, x1, [sp]                               
02ca2f68: mov     x0, sp                                     
02ca2f6c: mov     x1, xzr                                    
02ca2f70: bl      #0x2e44c98                                 Firebase.RemoteConfig.ConfigValue::get_StringValue
02ca2f74: adrp    x21, #0x662f000                            
02ca2f78: mov     x20, x0                                    
02ca2f7c: ldrb    w8, [x21, #0xbcf]                          
02ca2f80: cbnz    w8, #0x2ca2f98                             
02ca2f84: adrp    x0, #0x6264000                             
02ca2f88: ldr     x0, [x0, #0xfc0]                           T:RemoteConfigManager
02ca2f8c: bl      #0x2b70db0                                 fn_2b70db0
02ca2f90: mov     w8, #1                                     
02ca2f94: strb    w8, [x21, #0xbcf]                          
02ca2f98: ldr     x0, [x19]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02ca2f9c: ldr     w8, [x0, #0xe4]                            [62640e4]=0 f=0,0
02ca2fa0: cbnz    w8, #0x2ca2fac                             
02ca2fa4: bl      #0x2b70f30                                 fn_2b70f30
02ca2fa8: ldr     x0, [x19]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02ca2fac: ldr     x0, [x0, #0xb8]                            MS:DG.Tweening.Core.Extensions::SetSpecialStartupMode
02ca2fb0: mov     x1, x20                                    
02ca2fb4: str     x20, [x0, #0x20]!                          ._currentRetry
02ca2fb8: bl      #0x2b70d54                                 fn_2b70d54
02ca2fbc: mov     x0, xzr                                    
02ca2fc0: bl      #0x2e45fa0                                 Firebase.RemoteConfig.FirebaseRemoteConfig::get_DefaultInstance
02ca2fc4: cbz     x0, #0x2ca3324                             
02ca2fc8: adrp    x8, #0x6266000                             
02ca2fcc: mov     x2, xzr                                    
02ca2fd0: ldr     x8, [x8, #0x68]                            S:'native_full_srceen_time_showbtn'
02ca2fd4: ldr     x1, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca2fd8: bl      #0x2e471a0                                 Firebase.RemoteConfig.FirebaseRemoteConfig::GetValue
02ca2fdc: stp     x0, x1, [sp]                               
02ca2fe0: mov     x0, sp                                     
02ca2fe4: mov     x1, xzr                                    
02ca2fe8: bl      #0x2e44d68                                 Firebase.RemoteConfig.ConfigValue::get_DoubleValue
02ca2fec: mov     x8, #0x7ff0000000000000                    
02ca2ff0: fcvtzs  w9, d0                                     
02ca2ff4: adrp    x21, #0x662f000                            
02ca2ff8: fmov    d1, x8                                     
02ca2ffc: ldrb    w8, [x21, #0xbd0]                          
02ca3000: mov     w10, #-0xffffffff80000000                  
02ca3004: fcmp    d0, d1                                     
02ca3008: csel    w20, w10, w9, eq                           
02ca300c: cbnz    w8, #0x2ca3024                             
02ca3010: adrp    x0, #0x6264000                             
02ca3014: ldr     x0, [x0, #0xfc0]                           T:RemoteConfigManager
02ca3018: bl      #0x2b70db0                                 fn_2b70db0
02ca301c: mov     w8, #1                                     
02ca3020: strb    w8, [x21, #0xbd0]                          
02ca3024: ldr     x0, [x19]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02ca3028: ldr     w8, [x0, #0xe4]                            [62640e4]=0 f=0,0
02ca302c: cbnz    w8, #0x2ca3038                             
02ca3030: bl      #0x2b70f30                                 fn_2b70f30
02ca3034: ldr     x0, [x19]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02ca3038: ldr     x8, [x0, #0xb8]                            MS:DG.Tweening.Core.Extensions::SetSpecialStartupMode
02ca303c: mov     x0, xzr                                    
02ca3040: str     w20, [x8, #0x28]                           
02ca3044: bl      #0x2e45fa0                                 Firebase.RemoteConfig.FirebaseRemoteConfig::get_DefaultInstance
02ca3048: cbz     x0, #0x2ca3324                             
02ca304c: adrp    x8, #0x6266000                             
02ca3050: mov     x2, xzr                                    
02ca3054: ldr     x8, [x8, #0x90]                            S:'mrec_ad_id'
02ca3058: ldr     x1, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca305c: bl      #0x2e471a0                                 Firebase.RemoteConfig.FirebaseRemoteConfig::GetValue
02ca3060: stp     x0, x1, [sp]                               
02ca3064: mov     x0, sp                                     
02ca3068: mov     x1, xzr                                    
02ca306c: bl      #0x2e44c98                                 Firebase.RemoteConfig.ConfigValue::get_StringValue
02ca3070: adrp    x21, #0x662f000                            
02ca3074: mov     x20, x0                                    
02ca3078: ldrb    w8, [x21, #0xbd1]                          
02ca307c: cbnz    w8, #0x2ca3094                             
02ca3080: adrp    x0, #0x6264000                             
02ca3084: ldr     x0, [x0, #0xfc0]                           T:RemoteConfigManager
02ca3088: bl      #0x2b70db0                                 fn_2b70db0
02ca308c: mov     w8, #1                                     
02ca3090: strb    w8, [x21, #0xbd1]                          
02ca3094: ldr     x0, [x19]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02ca3098: ldr     w8, [x0, #0xe4]                            [62640e4]=0 f=0,0
02ca309c: cbnz    w8, #0x2ca30a8                             
02ca30a0: bl      #0x2b70f30                                 fn_2b70f30
02ca30a4: ldr     x0, [x19]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02ca30a8: ldr     x0, [x0, #0xb8]                            MS:DG.Tweening.Core.Extensions::SetSpecialStartupMode
02ca30ac: mov     x1, x20                                    
02ca30b0: str     x20, [x0, #0x30]!                          .<mrec_ad_id>k__BackingField
02ca30b4: bl      #0x2b70d54                                 fn_2b70d54
02ca30b8: mov     x0, xzr                                    
02ca30bc: bl      #0x2e45fa0                                 Firebase.RemoteConfig.FirebaseRemoteConfig::get_DefaultInstance
02ca30c0: cbz     x0, #0x2ca3324                             
02ca30c4: adrp    x8, #0x6266000                             
02ca30c8: mov     x2, xzr                                    
02ca30cc: ldr     x8, [x8, #0x98]                            S:'force_update_version'
02ca30d0: ldr     x1, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca30d4: bl      #0x2e471a0                                 Firebase.RemoteConfig.FirebaseRemoteConfig::GetValue
02ca30d8: stp     x0, x1, [sp]                               
02ca30dc: mov     x0, sp                                     
02ca30e0: mov     x1, xzr                                    
02ca30e4: bl      #0x2e44b88                                 Firebase.RemoteConfig.ConfigValue::get_BooleanValue
02ca30e8: adrp    x21, #0x662f000                            
02ca30ec: mov     w20, w0                                    
02ca30f0: ldrb    w8, [x21, #0xbd2]                          
02ca30f4: cbnz    w8, #0x2ca310c                             
02ca30f8: adrp    x0, #0x6264000                             
02ca30fc: ldr     x0, [x0, #0xfc0]                           T:RemoteConfigManager
02ca3100: bl      #0x2b70db0                                 fn_2b70db0
02ca3104: mov     w8, #1                                     
02ca3108: strb    w8, [x21, #0xbd2]                          
02ca310c: ldr     x0, [x19]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02ca3110: ldr     w8, [x0, #0xe4]                            [62640e4]=0 f=0,0
02ca3114: cbnz    w8, #0x2ca3120                             
02ca3118: bl      #0x2b70f30                                 fn_2b70f30
02ca311c: ldr     x0, [x19]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02ca3120: adrp    x21, #0x662f000                            
02ca3124: ldr     x8, [x0, #0xb8]                            MS:DG.Tweening.Core.Extensions::SetSpecialStartupMode
02ca3128: and     w10, w20, #1                               
02ca312c: ldrb    w9, [x21, #0xbd3]                          
02ca3130: strb    w10, [x8, #0x38]                           
02ca3134: cbnz    w9, #0x2ca314c                             
02ca3138: mov     x0, x19                                    
02ca313c: bl      #0x2b70db0                                 fn_2b70db0
02ca3140: ldr     x0, [x19]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02ca3144: mov     w8, #1                                     
02ca3148: strb    w8, [x21, #0xbd3]                          
02ca314c: ldr     w8, [x0, #0xe4]                            [62640e4]=0 f=0,0
02ca3150: cbnz    w8, #0x2ca315c                             
02ca3154: bl      #0x2b70f30                                 fn_2b70f30
02ca3158: ldr     x0, [x19]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02ca315c: adrp    x20, #0x662f000                            
02ca3160: ldr     x8, [x0, #0xb8]                            MS:DG.Tweening.Core.Extensions::SetSpecialStartupMode
02ca3164: mov     w21, #1                                    
02ca3168: ldrb    w9, [x20, #0xbd4]                          
02ca316c: strb    w21, [x8, #0x39]                           
02ca3170: cbnz    w9, #0x2ca3184                             
02ca3174: mov     x0, x19                                    
02ca3178: bl      #0x2b70db0                                 fn_2b70db0
02ca317c: ldr     x0, [x19]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02ca3180: strb    w21, [x20, #0xbd4]                         
02ca3184: ldr     w8, [x0, #0xe4]                            [62640e4]=0 f=0,0
02ca3188: cbnz    w8, #0x2ca3194                             
02ca318c: bl      #0x2b70f30                                 fn_2b70f30
02ca3190: ldr     x0, [x19]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02ca3194: ldr     x8, [x0, #0xb8]                            MS:DG.Tweening.Core.Extensions::SetSpecialStartupMode
02ca3198: mov     w9, #1                                     
02ca319c: mov     x0, xzr                                    
02ca31a0: strb    w9, [x8, #0x3a]                            
02ca31a4: bl      #0x2e45fa0                                 Firebase.RemoteConfig.FirebaseRemoteConfig::get_DefaultInstance
02ca31a8: cbz     x0, #0x2ca3324                             
02ca31ac: adrp    x8, #0x6266000                             
02ca31b0: mov     x2, xzr                                    
02ca31b4: ldr     x8, [x8, #0xb8]                            S:'banner_native_refresh_time'
02ca31b8: ldr     x1, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca31bc: bl      #0x2e471a0                                 Firebase.RemoteConfig.FirebaseRemoteConfig::GetValue
02ca31c0: stp     x0, x1, [sp]                               
02ca31c4: mov     x0, sp                                     
02ca31c8: mov     x1, xzr                                    
02ca31cc: bl      #0x2e44d68                                 Firebase.RemoteConfig.ConfigValue::get_DoubleValue
02ca31d0: mov     x8, #0x7ff0000000000000                    
02ca31d4: fcvtzs  w9, d0                                     
02ca31d8: adrp    x21, #0x662f000                            
02ca31dc: fmov    d1, x8                                     
02ca31e0: ldrb    w8, [x21, #0xbd5]                          
02ca31e4: mov     w10, #-0xffffffff80000000                  
02ca31e8: fcmp    d0, d1                                     
02ca31ec: csel    w20, w10, w9, eq                           
02ca31f0: cbnz    w8, #0x2ca3208                             
02ca31f4: adrp    x0, #0x6264000                             
02ca31f8: ldr     x0, [x0, #0xfc0]                           T:RemoteConfigManager
02ca31fc: bl      #0x2b70db0                                 fn_2b70db0
02ca3200: mov     w8, #1                                     
02ca3204: strb    w8, [x21, #0xbd5]                          
02ca3208: ldr     x0, [x19]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02ca320c: ldr     w8, [x0, #0xe4]                            [62640e4]=0 f=0,0
02ca3210: cbnz    w8, #0x2ca321c                             
02ca3214: bl      #0x2b70f30                                 fn_2b70f30
02ca3218: ldr     x0, [x19]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02ca321c: ldr     x8, [x0, #0xb8]                            MS:DG.Tweening.Core.Extensions::SetSpecialStartupMode
02ca3220: mov     x0, xzr                                    
02ca3224: str     w20, [x8, #0x3c]                           
02ca3228: bl      #0x2e45fa0                                 Firebase.RemoteConfig.FirebaseRemoteConfig::get_DefaultInstance
02ca322c: cbz     x0, #0x2ca3324                             
02ca3230: adrp    x8, #0x6266000                             
02ca3234: mov     x2, xzr                                    
02ca3238: ldr     x8, [x8, #0x88]                            S:'native_banner_id'
02ca323c: ldr     x1, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca3240: bl      #0x2e471a0                                 Firebase.RemoteConfig.FirebaseRemoteConfig::GetValue
02ca3244: stp     x0, x1, [sp]                               
02ca3248: mov     x0, sp                                     
02ca324c: mov     x1, xzr                                    
02ca3250: bl      #0x2e44c98                                 Firebase.RemoteConfig.ConfigValue::get_StringValue
02ca3254: adrp    x21, #0x662f000                            
02ca3258: mov     x20, x0                                    
02ca325c: ldrb    w8, [x21, #0xbd6]                          
02ca3260: cbnz    w8, #0x2ca3278                             
02ca3264: adrp    x0, #0x6264000                             
02ca3268: ldr     x0, [x0, #0xfc0]                           T:RemoteConfigManager
02ca326c: bl      #0x2b70db0                                 fn_2b70db0
02ca3270: mov     w8, #1                                     
02ca3274: strb    w8, [x21, #0xbd6]                          
02ca3278: ldr     x0, [x19]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02ca327c: ldr     w8, [x0, #0xe4]                            [62640e4]=0 f=0,0
02ca3280: cbnz    w8, #0x2ca328c                             
02ca3284: bl      #0x2b70f30                                 fn_2b70f30
02ca3288: ldr     x0, [x19]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02ca328c: ldr     x0, [x0, #0xb8]                            MS:DG.Tweening.Core.Extensions::SetSpecialStartupMode
02ca3290: mov     x1, x20                                    
02ca3294: str     x20, [x0, #0x40]!                          .<native_banner_id>k__BackingField
02ca3298: bl      #0x2b70d54                                 fn_2b70d54
02ca329c: mov     x0, xzr                                    
02ca32a0: bl      #0x2e45fa0                                 Firebase.RemoteConfig.FirebaseRemoteConfig::get_DefaultInstance
02ca32a4: cbz     x0, #0x2ca3324                             
02ca32a8: adrp    x8, #0x6266000                             
02ca32ac: mov     x2, xzr                                    
02ca32b0: ldr     x8, [x8, #0x38]                            S:'native_collap_id'
02ca32b4: ldr     x1, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca32b8: bl      #0x2e471a0                                 Firebase.RemoteConfig.FirebaseRemoteConfig::GetValue
02ca32bc: stp     x0, x1, [sp]                               
02ca32c0: mov     x0, sp                                     
02ca32c4: mov     x1, xzr                                    
02ca32c8: bl      #0x2e44c98                                 Firebase.RemoteConfig.ConfigValue::get_StringValue
02ca32cc: adrp    x21, #0x662f000                            
02ca32d0: mov     x20, x0                                    
02ca32d4: ldrb    w8, [x21, #0xbd7]                          
02ca32d8: cbnz    w8, #0x2ca32f0                             
02ca32dc: adrp    x0, #0x6264000                             
02ca32e0: ldr     x0, [x0, #0xfc0]                           T:RemoteConfigManager
02ca32e4: bl      #0x2b70db0                                 fn_2b70db0
02ca32e8: mov     w8, #1                                     
02ca32ec: strb    w8, [x21, #0xbd7]                          
02ca32f0: ldr     x0, [x19]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02ca32f4: ldr     w8, [x0, #0xe4]                            [62640e4]=0 f=0,0
02ca32f8: cbnz    w8, #0x2ca3304                             
02ca32fc: bl      #0x2b70f30                                 fn_2b70f30
02ca3300: ldr     x0, [x19]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02ca3304: ldr     x0, [x0, #0xb8]                            MS:DG.Tweening.Core.Extensions::SetSpecialStartupMode
02ca3308: mov     x1, x20                                    
02ca330c: str     x20, [x0, #0x48]!                          .<native_collap_id>k__BackingField
02ca3310: bl      #0x2b70d54                                 fn_2b70d54
02ca3314: ldp     x20, x19, [sp, #0x20]                      
02ca3318: ldp     x30, x21, [sp, #0x10]                      
02ca331c: add     sp, sp, #0x30                              
02ca3320: ret                                                
02ca3324: bl      #0x2b7105c                                 fn_2b7105c
## .ctor() -> void
---- RemoteConfigManager::.ctor 0x2ca3328
02ca3328: adrp    x8, #0x1041000                             
02ca332c: mov     x1, xzr                                    
02ca3330: ldr     d0, [x8, #0x128]                           [1041128]=100000002 f=2.8026e-45,1.4013e-45
02ca3334: str     d0, [x0, #0x20]                            ._currentRetry
02ca3338: b       #0x5b397b0                                 UnityEngine.MonoBehaviour::.ctor
## .cctor() -> void
---- RemoteConfigManager::.cctor 0x2ca333c
02ca333c: stp     x30, x25, [sp, #-0x40]!                    
02ca3340: stp     x24, x23, [sp, #0x10]                      
02ca3344: stp     x22, x21, [sp, #0x20]                      
02ca3348: stp     x20, x19, [sp, #0x30]                      
02ca334c: adrp    x19, #0x6264000                            
02ca3350: adrp    x24, #0x6266000                            
02ca3354: adrp    x23, #0x6266000                            
02ca3358: adrp    x25, #0x662f000                            
02ca335c: adrp    x22, #0x6266000                            
02ca3360: adrp    x21, #0x6266000                            
02ca3364: adrp    x20, #0x6266000                            
02ca3368: ldr     x19, [x19, #0xfc0]                         T:RemoteConfigManager
02ca336c: ldr     x24, [x24, #0xc8]                          S:'ca-app-pub-6038046981135391/7620843755'
02ca3370: ldr     x23, [x23, #0xd0]                          S:'ca-app-pub-6038046981135391/4258641252'
02ca3374: ldr     x22, [x22, #0xd8]                          S:'01d46223aaa98262'
02ca3378: ldrb    w8, [x25, #0xabb]                          
02ca337c: ldr     x21, [x21, #0xe0]                          S:'ca-app-pub-6038046981135391/9510967936'
02ca3380: ldr     x20, [x20, #0xe8]                          S:'ca-app-pub-6038046981135391/2402186996'
02ca3384: tbnz    w8, #0, #0x2ca33d8                         
02ca3388: adrp    x0, #0x6264000                             
02ca338c: ldr     x0, [x0, #0xfc0]                           T:RemoteConfigManager
02ca3390: bl      #0x2b70db0                                 fn_2b70db0
02ca3394: adrp    x0, #0x6266000                             
02ca3398: ldr     x0, [x0, #0xd0]                            S:'ca-app-pub-6038046981135391/4258641252'
02ca339c: bl      #0x2b70db0                                 fn_2b70db0
02ca33a0: adrp    x0, #0x6266000                             
02ca33a4: ldr     x0, [x0, #0xc8]                            S:'ca-app-pub-6038046981135391/7620843755'
02ca33a8: bl      #0x2b70db0                                 fn_2b70db0
02ca33ac: adrp    x0, #0x6266000                             
02ca33b0: ldr     x0, [x0, #0xd8]                            S:'01d46223aaa98262'
02ca33b4: bl      #0x2b70db0                                 fn_2b70db0
02ca33b8: adrp    x0, #0x6266000                             
02ca33bc: ldr     x0, [x0, #0xe8]                            S:'ca-app-pub-6038046981135391/2402186996'
02ca33c0: bl      #0x2b70db0                                 fn_2b70db0
02ca33c4: adrp    x0, #0x6266000                             
02ca33c8: ldr     x0, [x0, #0xe0]                            S:'ca-app-pub-6038046981135391/9510967936'
02ca33cc: bl      #0x2b70db0                                 fn_2b70db0
02ca33d0: mov     w8, #1                                     
02ca33d4: strb    w8, [x25, #0xabb]                          
02ca33d8: ldr     x8, [x19]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02ca33dc: adrp    x9, #0x1088000                             
02ca33e0: ldr     q0, [x9, #0x9a0]                           [10889a0]=c01010101 f=2.36943e-38,1.68156e-44
02ca33e4: ldr     x0, [x8, #0xb8]                            
02ca33e8: str     q0, [x0]                                   
02ca33ec: ldr     x1, [x24]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca33f0: mov     w24, #1                                    
02ca33f4: str     x1, [x0, #0x18]!                           .<open_ad_id>k__BackingField
02ca33f8: stur    w24, [x0, #-8]                             
02ca33fc: sturh   w24, [x0, #-4]                             
02ca3400: bl      #0x2b70d54                                 fn_2b70d54
02ca3404: ldr     x8, [x19]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02ca3408: ldr     x1, [x23]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca340c: ldr     x0, [x8, #0xb8]                            
02ca3410: str     x1, [x0, #0x20]!                           ._currentRetry
02ca3414: bl      #0x2b70d54                                 fn_2b70d54
02ca3418: ldr     x8, [x19]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02ca341c: ldr     x1, [x22]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca3420: ldr     x0, [x8, #0xb8]                            
02ca3424: mov     w8, #5                                     
02ca3428: str     x1, [x0, #0x30]!                           .<mrec_ad_id>k__BackingField
02ca342c: stur    w8, [x0, #-8]                              
02ca3430: bl      #0x2b70d54                                 fn_2b70d54
02ca3434: ldr     x8, [x19]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02ca3438: ldr     x1, [x21]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca343c: ldr     x0, [x8, #0xb8]                            
02ca3440: mov     w8, #0x100                                 
02ca3444: str     x1, [x0, #0x40]!                           .<native_banner_id>k__BackingField
02ca3448: sturh   w8, [x0, #-8]                              
02ca344c: mov     w8, #0x1e                                  
02ca3450: sturb   w24, [x0, #-6]                             
02ca3454: stur    w8, [x0, #-4]                              
02ca3458: bl      #0x2b70d54                                 fn_2b70d54
02ca345c: ldr     x8, [x19]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02ca3460: ldr     x1, [x20]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca3464: ldp     x20, x19, [sp, #0x30]                      
02ca3468: ldr     x0, [x8, #0xb8]                            
02ca346c: ldp     x22, x21, [sp, #0x20]                      
02ca3470: ldp     x24, x23, [sp, #0x10]                      
02ca3474: str     x1, [x0, #0x48]!                           .<native_collap_id>k__BackingField
02ca3478: ldp     x30, x25, [sp], #0x40                      
02ca347c: b       #0x2b70d54                                 
## <FetchDataRemote>b__85_0(System.Threading.Tasks.Task`1<bool> task) -> void
---- RemoteConfigManager::<FetchDataRemote>b__85_0 0x2ca3480
02ca3480: b       #0x2ca28d8                                 RemoteConfigManager::SetRemoteValue
