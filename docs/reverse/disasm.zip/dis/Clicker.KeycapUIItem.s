#### CLASS Clicker.KeycapUIItem parent= Clicker.ClickerUIItem
## OnSelected(bool isSelected) -> void
---- Clicker.KeycapUIItem::OnSelected 0x2d6e6d8
02d6e6d8: mov     x2, xzr                                    
02d6e6dc: b       #0x2d664a8                                 Clicker.ClickerUIItem::OnSelected
## .ctor() -> void
---- Clicker.KeycapUIItem::.ctor 0x2d6e6e0
02d6e6e0: mov     x1, xzr                                    
02d6e6e4: b       #0x2d664b4                                 Clicker.ClickerUIItem::.ctor
