#### CLASS Level parent= PoolElement
## OnInit() -> void
---- Level::OnInit 0x2cd6728
02cd6728: ret                                                
## Clear() -> void
---- Level::Clear 0x2cd672c
02cd672c: ret                                                
## .ctor() -> void
---- Level::.ctor 0x2cd6730
02cd6730: mov     x1, xzr                                    
02cd6734: b       #0x5b397b0                                 UnityEngine.MonoBehaviour::.ctor
