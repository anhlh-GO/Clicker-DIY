#### CLASS Clicker.KeycapMakerController/<>c parent= object
#   field <>9                            Clicker.KeycapMakerController/<>c                  off=0x0 attr=36 
#   field <>9__48_0                      System.Action`1<Clicker.SwitchObject>              off=0x8 attr=16 
#   field <>9__48_1                      System.Action`1<Clicker.KeycapObject>              off=0x10 attr=16 
#   field <>9__55_0                      DG.Tweening.TweenCallback                          off=0x18 attr=16 
#   field <>9__57_0                      DG.Tweening.TweenCallback                          off=0x20 attr=16 
## .cctor() -> void
---- Clicker.KeycapMakerController/<>c::.cctor 0x2d6e024
02d6e024: str     x30, [sp, #-0x20]!                         
02d6e028: stp     x20, x19, [sp, #0x10]                      
02d6e02c: adrp    x19, #0x6630000                            
02d6e030: adrp    x20, #0x626c000                            
02d6e034: ldrb    w8, [x19, #0x38a]                          
02d6e038: ldr     x20, [x20, #0x440]                         T:Clicker.KeycapMakerController/<>c
02d6e03c: tbnz    w8, #0, #0x2d6e054                         
02d6e040: adrp    x0, #0x626c000                             
02d6e044: ldr     x0, [x0, #0x440]                           T:Clicker.KeycapMakerController/<>c
02d6e048: bl      #0x2b70db0                                 fn_2b70db0
02d6e04c: mov     w8, #1                                     
02d6e050: strb    w8, [x19, #0x38a]                          
02d6e054: ldr     x0, [x20]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d6e058: bl      #0x2b7104c                                 fn_2b7104c
02d6e05c: mov     x1, xzr                                    
02d6e060: mov     x19, x0                                    
02d6e064: bl      #0x4e53e9c                                 System.Object::.ctor
02d6e068: ldr     x8, [x20]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d6e06c: mov     x1, x19                                    
02d6e070: ldr     x8, [x8, #0xb8]                            
02d6e074: str     x19, [x8]                                  
02d6e078: ldr     x8, [x20]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d6e07c: ldp     x20, x19, [sp, #0x10]                      
02d6e080: ldr     x0, [x8, #0xb8]                            
02d6e084: ldr     x30, [sp], #0x20                           
02d6e088: b       #0x2b70d54                                 
## .ctor() -> void
---- Clicker.KeycapMakerController/<>c::.ctor 0x2d6e08c
02d6e08c: mov     x1, xzr                                    
02d6e090: b       #0x4e53e9c                                 System.Object::.ctor
## <Initiate>b__48_0(Clicker.SwitchObject s) -> void
---- Clicker.KeycapMakerController/<>c::<Initiate>b__48_0 0x2d6e094
02d6e094: str     x30, [sp, #-0x10]!                         
02d6e098: cbz     x1, #0x2d6e0bc                             
02d6e09c: mov     x0, x1                                     
02d6e0a0: mov     x1, xzr                                    
02d6e0a4: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02d6e0a8: movi    d0, #0000000000000000                      
02d6e0ac: movi    d1, #0000000000000000                      
02d6e0b0: mov     x1, xzr                                    
02d6e0b4: ldr     x30, [sp], #0x10                           
02d6e0b8: b       #0x2d98c98                                 DG.Tweening.ShortcutExtensions::DOScale
02d6e0bc: bl      #0x2b7105c                                 fn_2b7105c
## <Initiate>b__48_1(Clicker.KeycapObject s) -> void
---- Clicker.KeycapMakerController/<>c::<Initiate>b__48_1 0x2d6e0c0
02d6e0c0: str     x30, [sp, #-0x10]!                         
02d6e0c4: cbz     x1, #0x2d6e0e8                             
02d6e0c8: mov     x0, x1                                     
02d6e0cc: mov     x1, xzr                                    
02d6e0d0: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02d6e0d4: movi    d0, #0000000000000000                      
02d6e0d8: movi    d1, #0000000000000000                      
02d6e0dc: mov     x1, xzr                                    
02d6e0e0: ldr     x30, [sp], #0x10                           
02d6e0e4: b       #0x2d98c98                                 DG.Tweening.ShortcutExtensions::DOScale
02d6e0e8: bl      #0x2b7105c                                 fn_2b7105c
## <SpawnSwitch>b__55_0() -> void
---- Clicker.KeycapMakerController/<>c::<SpawnSwitch>b__55_0 0x2d6e0ec
02d6e0ec: str     x30, [sp, #-0x20]!                         
02d6e0f0: stp     x20, x19, [sp, #0x10]                      
02d6e0f4: adrp    x19, #0x6630000                            
02d6e0f8: adrp    x20, #0x6267000                            
02d6e0fc: ldrb    w8, [x19, #0x38b]                          
02d6e100: ldr     x20, [x20, #0xea8]                         T:Framework.Vibration
02d6e104: tbnz    w8, #0, #0x2d6e11c                         
02d6e108: adrp    x0, #0x6267000                             
02d6e10c: ldr     x0, [x0, #0xea8]                           T:Framework.Vibration
02d6e110: bl      #0x2b70db0                                 fn_2b70db0
02d6e114: mov     w8, #1                                     
02d6e118: strb    w8, [x19, #0x38b]                          
02d6e11c: ldr     x0, [x20]                                  S:'didu'
02d6e120: ldr     w8, [x0, #0xe4]                            [62670e4]=0 f=0,0
02d6e124: cbnz    w8, #0x2d6e12c                             
02d6e128: bl      #0x2b70f30                                 fn_2b70f30
02d6e12c: ldp     x20, x19, [sp, #0x10]                      
02d6e130: mov     w0, #0x28                                  
02d6e134: mov     w1, #-1                                    
02d6e138: mov     w2, wzr                                    
02d6e13c: ldr     x30, [sp], #0x20                           
02d6e140: b       #0x2d6e144                                 Framework.Vibration::Vibrate
## <SpawnKeycap>b__57_0() -> void
---- Clicker.KeycapMakerController/<>c::<SpawnKeycap>b__57_0 0x2d6e44c
02d6e44c: str     x30, [sp, #-0x20]!                         
02d6e450: stp     x20, x19, [sp, #0x10]                      
02d6e454: adrp    x19, #0x6630000                            
02d6e458: adrp    x20, #0x6267000                            
02d6e45c: ldrb    w8, [x19, #0x38c]                          
02d6e460: ldr     x20, [x20, #0xea8]                         T:Framework.Vibration
02d6e464: tbnz    w8, #0, #0x2d6e47c                         
02d6e468: adrp    x0, #0x6267000                             
02d6e46c: ldr     x0, [x0, #0xea8]                           T:Framework.Vibration
02d6e470: bl      #0x2b70db0                                 fn_2b70db0
02d6e474: mov     w8, #1                                     
02d6e478: strb    w8, [x19, #0x38c]                          
02d6e47c: ldr     x0, [x20]                                  S:'didu'
02d6e480: ldr     w8, [x0, #0xe4]                            [62670e4]=0 f=0,0
02d6e484: cbnz    w8, #0x2d6e48c                             
02d6e488: bl      #0x2b70f30                                 fn_2b70f30
02d6e48c: ldp     x20, x19, [sp, #0x10]                      
02d6e490: mov     w0, #0x28                                  
02d6e494: mov     w1, #-1                                    
02d6e498: mov     w2, wzr                                    
02d6e49c: ldr     x30, [sp], #0x20                           
02d6e4a0: b       #0x2d6e144                                 Framework.Vibration::Vibrate
#### CLASS Clicker.KeycapMakerController/<>c__DisplayClass51_0 parent= object
#   field <>4__this                      Clicker.KeycapMakerController                      off=0x10 attr=6 
#   field spriteNew                      UnityEngine.Sprite                                 off=0x18 attr=6 
## .ctor() -> void
---- Clicker.KeycapMakerController/<>c__DisplayClass51_0::.ctor 0x2d6e4a4
02d6e4a4: mov     x1, xzr                                    
02d6e4a8: b       #0x4e53e9c                                 System.Object::.ctor
## <ChangePrinterBasePreview>b__0() -> void
---- Clicker.KeycapMakerController/<>c__DisplayClass51_0::<ChangePrinterBasePreview>b__0 0x2d6e4ac
02d6e4ac: str     x30, [sp, #-0x20]!                         
02d6e4b0: stp     x20, x19, [sp, #0x10]                      
02d6e4b4: adrp    x20, #0x6630000                            
02d6e4b8: mov     x19, x0                                    
02d6e4bc: ldrb    w8, [x20, #0x38d]                          
02d6e4c0: tbnz    w8, #0, #0x2d6e4d8                         
02d6e4c4: adrp    x0, #0x6266000                             
02d6e4c8: ldr     x0, [x0, #0x880]                           MS:DG.Tweening.TweenSettingsExtensions::SetEase
02d6e4cc: bl      #0x2b70db0                                 fn_2b70db0
02d6e4d0: mov     w8, #1                                     
02d6e4d4: strb    w8, [x20, #0x38d]                          
02d6e4d8: ldr     x8, [x19, #0x10]                           .<>4__this
02d6e4dc: cbz     x8, #0x2d6e53c                             
02d6e4e0: ldr     x0, [x8, #0x68]                            
02d6e4e4: cbz     x0, #0x2d6e53c                             
02d6e4e8: ldr     x1, [x19, #0x18]                           .spriteNew
02d6e4ec: mov     x2, xzr                                    
02d6e4f0: bl      #0x5ae6dcc                                 UnityEngine.SpriteRenderer::set_sprite
02d6e4f4: ldr     x8, [x19, #0x10]                           .<>4__this
02d6e4f8: cbz     x8, #0x2d6e53c                             
02d6e4fc: ldr     x0, [x8, #0x68]                            
02d6e500: cbz     x0, #0x2d6e53c                             
02d6e504: adrp    x19, #0x6266000                            
02d6e508: mov     x1, xzr                                    
02d6e50c: ldr     x19, [x19, #0x880]                         MS:DG.Tweening.TweenSettingsExtensions::SetEase
02d6e510: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02d6e514: adrp    x8, #0x1084000                             
02d6e518: fmov    s0, #1.00000000                            
02d6e51c: mov     x1, xzr                                    
02d6e520: ldr     s1, [x8, #0xf10]                           [1084f10]=4110bc863e99999a f=0.3,9.04603
02d6e524: bl      #0x2d98c98                                 DG.Tweening.ShortcutExtensions::DOScale
02d6e528: ldr     x2, [x19]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d6e52c: ldp     x20, x19, [sp, #0x10]                      
02d6e530: mov     w1, #0x1b                                  
02d6e534: ldr     x30, [sp], #0x20                           
02d6e538: b       #0x336fa0c                                 
02d6e53c: bl      #0x2b7105c                                 fn_2b7105c
#### CLASS Clicker.KeycapMakerController/<>c__DisplayClass66_0 parent= object
#   field <>4__this                      Clicker.KeycapMakerController                      off=0x10 attr=6 
#   field spriteNew                      UnityEngine.Sprite                                 off=0x18 attr=6 
## .ctor() -> void
---- Clicker.KeycapMakerController/<>c__DisplayClass66_0::.ctor 0x2d6e540
02d6e540: mov     x1, xzr                                    
02d6e544: b       #0x4e53e9c                                 System.Object::.ctor
## <ChangeKeychainPreview>b__0() -> void
---- Clicker.KeycapMakerController/<>c__DisplayClass66_0::<ChangeKeychainPreview>b__0 0x2d6e548
02d6e548: str     x30, [sp, #-0x20]!                         
02d6e54c: stp     x20, x19, [sp, #0x10]                      
02d6e550: adrp    x20, #0x6630000                            
02d6e554: mov     x19, x0                                    
02d6e558: ldrb    w8, [x20, #0x38e]                          
02d6e55c: tbnz    w8, #0, #0x2d6e574                         
02d6e560: adrp    x0, #0x6266000                             
02d6e564: ldr     x0, [x0, #0x880]                           MS:DG.Tweening.TweenSettingsExtensions::SetEase
02d6e568: bl      #0x2b70db0                                 fn_2b70db0
02d6e56c: mov     w8, #1                                     
02d6e570: strb    w8, [x20, #0x38e]                          
02d6e574: ldr     x8, [x19, #0x10]                           .<>4__this
02d6e578: cbz     x8, #0x2d6e5d8                             
02d6e57c: ldr     x0, [x8, #0xc0]                            
02d6e580: cbz     x0, #0x2d6e5d8                             
02d6e584: ldr     x1, [x19, #0x18]                           .spriteNew
02d6e588: mov     x2, xzr                                    
02d6e58c: bl      #0x5ae6dcc                                 UnityEngine.SpriteRenderer::set_sprite
02d6e590: ldr     x8, [x19, #0x10]                           .<>4__this
02d6e594: cbz     x8, #0x2d6e5d8                             
02d6e598: ldr     x0, [x8, #0xc0]                            
02d6e59c: cbz     x0, #0x2d6e5d8                             
02d6e5a0: adrp    x19, #0x6266000                            
02d6e5a4: mov     x1, xzr                                    
02d6e5a8: ldr     x19, [x19, #0x880]                         MS:DG.Tweening.TweenSettingsExtensions::SetEase
02d6e5ac: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02d6e5b0: adrp    x8, #0x1084000                             
02d6e5b4: fmov    s0, #1.00000000                            
02d6e5b8: mov     x1, xzr                                    
02d6e5bc: ldr     s1, [x8, #0xf10]                           [1084f10]=4110bc863e99999a f=0.3,9.04603
02d6e5c0: bl      #0x2d98c98                                 DG.Tweening.ShortcutExtensions::DOScale
02d6e5c4: ldr     x2, [x19]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d6e5c8: ldp     x20, x19, [sp, #0x10]                      
02d6e5cc: mov     w1, #0x1b                                  
02d6e5d0: ldr     x30, [sp], #0x20                           
02d6e5d4: b       #0x336fa0c                                 
02d6e5d8: bl      #0x2b7105c                                 fn_2b7105c
#### CLASS Clicker.KeycapMakerController/<>c__DisplayClass69_0 parent= object
#   field onComplete                     System.Action                                      off=0x10 attr=6 
## .ctor() -> void
---- Clicker.KeycapMakerController/<>c__DisplayClass69_0::.ctor 0x2d6e5dc
02d6e5dc: mov     x1, xzr                                    
02d6e5e0: b       #0x4e53e9c                                 System.Object::.ctor
## <MoveResultToComplete>b__0() -> void
---- Clicker.KeycapMakerController/<>c__DisplayClass69_0::<MoveResultToComplete>b__0 0x2d6e5e4
02d6e5e4: ldr     x8, [x0, #0x10]                            .onComplete
02d6e5e8: cbz     x8, #0x2d6e5fc                             
02d6e5ec: ldr     x0, [x8, #0x40]                            
02d6e5f0: ldr     x1, [x8, #0x28]                            
02d6e5f4: ldr     x2, [x8, #0x18]                            
02d6e5f8: br      x2                                         
02d6e5fc: ret                                                
#### CLASS Clicker.KeycapMakerController/<>c__DisplayClass83_0 parent= object
#   field dataClicker                    DataClicker                                        off=0x10 attr=6 
#   field <>4__this                      Clicker.KeycapMakerController                      off=0x18 attr=6 
## .ctor() -> void
---- Clicker.KeycapMakerController/<>c__DisplayClass83_0::.ctor 0x2d6e600
02d6e600: mov     x1, xzr                                    
02d6e604: b       #0x4e53e9c                                 System.Object::.ctor
## <TrySaveKeycapToDatabase>b__0() -> void
---- Clicker.KeycapMakerController/<>c__DisplayClass83_0::<TrySaveKeycapToDatabase>b__0 0x2d6e608
02d6e608: str     x30, [sp, #-0x20]!                         
02d6e60c: stp     x20, x19, [sp, #0x10]                      
02d6e610: adrp    x20, #0x6630000                            
02d6e614: mov     x19, x0                                    
02d6e618: ldrb    w8, [x20, #0x38f]                          
02d6e61c: tbnz    w8, #0, #0x2d6e634                         
02d6e620: adrp    x0, #0x6266000                             
02d6e624: ldr     x0, [x0, #0x6b0]                           T:ClickerSaveDataItem
02d6e628: bl      #0x2b70db0                                 fn_2b70db0
02d6e62c: mov     w8, #1                                     
02d6e630: strb    w8, [x20, #0x38f]                          
02d6e634: ldr     x0, [x19, #0x10]                           .dataClicker
02d6e638: cbz     x0, #0x2d6e6d4                             
02d6e63c: ldr     x8, [x0, #0x20]                            S:'inter_ad_capping_time'
02d6e640: cbz     x8, #0x2d6e6d4                             
02d6e644: ldr     w9, [x8, #0x10]                            
02d6e648: adrp    x20, #0x6266000                            
02d6e64c: add     w9, w9, #1                                 
02d6e650: str     w9, [x8, #0x10]                            
02d6e654: ldr     x8, [x0]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d6e658: ldr     x20, [x20, #0x6b0]                         T:ClickerSaveDataItem
02d6e65c: ldr     x9, [x8, #0x258]                           
02d6e660: ldr     x1, [x8, #0x260]                           
02d6e664: blr     x9                                         
02d6e668: ldr     x0, [x20]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d6e66c: bl      #0x2b7104c                                 fn_2b7104c
02d6e670: mov     x1, xzr                                    
02d6e674: mov     x20, x0                                    
02d6e678: bl      #0x2ca8bd4                                 ClickerSaveDataItem::.ctor
02d6e67c: ldr     x8, [x19, #0x18]                           .<>4__this
02d6e680: cbz     x8, #0x2d6e6d4                             
02d6e684: cbz     x20, #0x2d6e6d4                            
02d6e688: ldr     q0, [x8, #0x20]                            
02d6e68c: ldr     x0, [x8, #0xa0]                            
02d6e690: stur    q0, [x20, #0x14]                           
02d6e694: ldr     w9, [x8, #0x30]                            
02d6e698: str     w9, [x20, #0x24]                           
02d6e69c: cbz     x0, #0x2d6e6d4                             
02d6e6a0: mov     x1, xzr                                    
02d6e6a4: bl      #0x2d60470                                 Clicker.BaseKeycapObject::GetDecorData
02d6e6a8: mov     x1, x0                                     
02d6e6ac: mov     x0, x20                                    
02d6e6b0: str     x1, [x0, #0x28]!                           
02d6e6b4: bl      #0x2b70d54                                 fn_2b70d54
02d6e6b8: ldr     x0, [x19, #0x10]                           .dataClicker
02d6e6bc: cbz     x0, #0x2d6e6d4                             
02d6e6c0: mov     x1, x20                                    
02d6e6c4: ldp     x20, x19, [sp, #0x10]                      
02d6e6c8: mov     x2, xzr                                    
02d6e6cc: ldr     x30, [sp], #0x20                           
02d6e6d0: b       #0x2ca8f48                                 DataClicker::RegisterNewKeycap
02d6e6d4: bl      #0x2b7105c                                 fn_2b7105c
#### CLASS Clicker.KeycapMakerController parent= MonoSingleton`1<Clicker.KeycapMakerController>
#   field _baseKeycapId                  int                                                off=0x20 attr=1 HeaderAttribute,SerializeField
#   field _switchId                      int                                                off=0x24 attr=1 SerializeField
#   field _keycapId                      int                                                off=0x28 attr=1 SerializeField
#   field _keycapColorId                 int                                                off=0x2c attr=1 SerializeField
#   field _keychainId                    int                                                off=0x30 attr=1 SerializeField
#   field _goTray                        UnityEngine.GameObject                             off=0x38 attr=1 HeaderAttribute,SerializeField
#   field _srTray                        UnityEngine.SpriteRenderer                         off=0x40 attr=1 SerializeField
#   field _traySprite                    UnityEngine.Sprite                                 off=0x48 attr=1 SerializeField
#   field _trayTopViewSprite             UnityEngine.Sprite                                 off=0x50 attr=1 SerializeField
#   field _srBaseKeycapOnTray            UnityEngine.SpriteRenderer                         off=0x58 attr=1 SerializeField
#   field _baseKeycapConfig              Clicker.BaseKeycapConfig                           off=0x60 attr=1 HeaderAttribute,SerializeField
#   field _srPreviewPrinter              UnityEngine.SpriteRenderer                         off=0x68 attr=1 SerializeField
#   field _tutorialSelectKeycapBase      Clicker.TutorialSelectKeycapBase                   off=0x70 attr=1 SerializeField
#   field _printerMachine                Clicker.PrinterMachine                             off=0x78 attr=1 HeaderAttribute,SerializeField
#   field _switchList                    System.Collections.Generic.List`1<Clicker.SwitchObject> off=0x80 attr=1 HeaderAttribute,SerializeField
#   field _switchConfig                  Clicker.SwitchConfig                               off=0x88 attr=1 SerializeField
#   field _keycapList                    System.Collections.Generic.List`1<Clicker.KeycapObject> off=0x90 attr=1 HeaderAttribute,SerializeField
#   field _keycapConfig                  Clicker.KeycapConfig                               off=0x98 attr=1 SerializeField
#   field _baseKeycapObject              Clicker.BaseKeycapObject                           off=0xa0 attr=1 HeaderAttribute,SerializeField
#   field _tfBaseKeycapHolder            UnityEngine.Transform                              off=0xa8 attr=1 SerializeField
#   field _tfHighlight                   UnityEngine.Transform                              off=0xb0 attr=1 SerializeField
#   field _keychainConfig                Clicker.KeychainConfig                             off=0xb8 attr=1 HeaderAttribute,SerializeField
#   field _srKeychain                    UnityEngine.SpriteRenderer                         off=0xc0 attr=1 SerializeField
#   field _dragManager                   Clicker.DragManager                                off=0xc8 attr=1 HeaderAttribute,SerializeField
#   field _bgTable                       UnityEngine.GameObject                             off=0xd0 attr=1 HeaderAttribute,SerializeField
#   field _bgWall                        UnityEngine.GameObject                             off=0xd8 attr=1 SerializeField
#   field _srBGForPopupComplete          UnityEngine.SpriteRenderer                         off=0xe0 attr=1 SerializeField
#   field _pointerHandTutorial           Clicker.TutorialDrag                               off=0xe8 attr=1 HeaderAttribute,SerializeField
#   field _dragHandTutorial              Clicker.TutorialDrag                               off=0xf0 attr=1 SerializeField
#   field _tfFinalPose                   UnityEngine.Transform                              off=0xf8 attr=1 HeaderAttribute,SerializeField
#   field _tfLivestreamPose              UnityEngine.Transform                              off=0x100 attr=1 SerializeField
#   field _tfCompletePose                UnityEngine.Transform                              off=0x108 attr=1 SerializeField
#   field _srBG                          UnityEngine.SpriteRenderer                         off=0x110 attr=1 SerializeField
#   field _tfFinalEffect                 UnityEngine.Transform                              off=0x118 attr=1 SerializeField
#   field _ingameClickerScreen           Clicker.IngameClickerScreen                        off=0x120 attr=1 
#   field _switchAmount                  int                                                off=0x128 attr=1 
#   field _inputSystemUIInputModule      UnityEngine.InputSystem.UI.InputSystemUIInputModule off=0x130 attr=1 HeaderAttribute,SerializeField
## get_BaseKeycapId() -> int
---- Clicker.KeycapMakerController::get_BaseKeycapId 0x2d6c0a4
02d6c0a4: ldr     w0, [x0, #0x20]                            ._baseKeycapId
02d6c0a8: ret                                                
## get_SwitchId() -> int
---- Clicker.KeycapMakerController::get_SwitchId 0x2d6c0ac
02d6c0ac: ldr     w0, [x0, #0x24]                            ._switchId
02d6c0b0: ret                                                
## get_KeycapId() -> int
---- Clicker.KeycapMakerController::get_KeycapId 0x2d6c0b4
02d6c0b4: ldr     w0, [x0, #0x28]                            ._keycapId
02d6c0b8: ret                                                
## get_KeycapColorId() -> int
---- Clicker.KeycapMakerController::get_KeycapColorId 0x2d6c0bc
02d6c0bc: ldr     w0, [x0, #0x2c]                            ._keycapColorId
02d6c0c0: ret                                                
## get_KeychainId() -> int
---- Clicker.KeycapMakerController::get_KeychainId 0x2d6c0c4
02d6c0c4: ldr     w0, [x0, #0x30]                            ._keychainId
02d6c0c8: ret                                                
## SetMultipleInput(bool isEnable) -> void
---- Clicker.KeycapMakerController::SetMultipleInput 0x2d6c0cc
02d6c0cc: str     x30, [sp, #-0x30]!                         
02d6c0d0: stp     x22, x21, [sp, #0x10]                      
02d6c0d4: stp     x20, x19, [sp, #0x20]                      
02d6c0d8: adrp    x22, #0x6630000                            
02d6c0dc: adrp    x21, #0x6263000                            
02d6c0e0: mov     w19, w1                                    
02d6c0e4: ldrb    w8, [x22, #0x373]                          
02d6c0e8: ldr     x21, [x21, #0x918]                         T:UnityEngine.Object
02d6c0ec: mov     x20, x0                                    
02d6c0f0: tbnz    w8, #0, #0x2d6c108                         
02d6c0f4: adrp    x0, #0x6263000                             
02d6c0f8: ldr     x0, [x0, #0x918]                           T:UnityEngine.Object
02d6c0fc: bl      #0x2b70db0                                 fn_2b70db0
02d6c100: mov     w8, #1                                     
02d6c104: strb    w8, [x22, #0x373]                          
02d6c108: ldr     x0, [x21]                                  &2c5bbd4(=a9bd7bfdd503233f)
02d6c10c: ldr     x21, [x20, #0x130]                         ._inputSystemUIInputModule
02d6c110: ldr     w8, [x0, #0xe4]                            [62630e4]=0 f=0,0
02d6c114: cbnz    w8, #0x2d6c11c                             
02d6c118: bl      #0x2b70f30                                 fn_2b70f30
02d6c11c: mov     x0, x21                                    
02d6c120: mov     x1, xzr                                    
02d6c124: mov     x2, xzr                                    
02d6c128: bl      #0x5b3666c                                 UnityEngine.Object::op_Inequality
02d6c12c: tbz     w0, #0, #0x2d6c144                         
02d6c130: ldr     x8, [x20, #0x130]                          ._inputSystemUIInputModule
02d6c134: cbz     x8, #0x2d6c154                             
02d6c138: mov     w9, #1                                     
02d6c13c: bic     w9, w9, w19                                
02d6c140: str     w9, [x8, #0xcc]                            
02d6c144: ldp     x20, x19, [sp, #0x20]                      
02d6c148: ldp     x22, x21, [sp, #0x10]                      
02d6c14c: ldr     x30, [sp], #0x30                           
02d6c150: ret                                                
02d6c154: bl      #0x2b7105c                                 fn_2b7105c
## Initiate() -> void
---- Clicker.KeycapMakerController::Initiate 0x2d6c158
02d6c158: stp     x30, x23, [sp, #-0x30]!                    
02d6c15c: stp     x22, x21, [sp, #0x10]                      
02d6c160: stp     x20, x19, [sp, #0x20]                      
02d6c164: adrp    x21, #0x6630000                            
02d6c168: adrp    x22, #0x626c000                            
02d6c16c: adrp    x20, #0x6267000                            
02d6c170: ldrb    w8, [x21, #0x374]                          
02d6c174: ldr     x22, [x22, #0x428]                         MS:MonoSingleton`1::Initiate
02d6c178: ldr     x20, [x20, #0xbd0]                         MS:MonoSingleton`1::get_Instance
02d6c17c: mov     x19, x0                                    
02d6c180: tbnz    w8, #0, #0x2d6c204                         
02d6c184: adrp    x0, #0x626b000                             
02d6c188: ldr     x0, [x0, #0xe20]                           T:type53140(k15)
02d6c18c: bl      #0x2b70db0                                 fn_2b70db0
02d6c190: adrp    x0, #0x626b000                             
02d6c194: ldr     x0, [x0, #0xe28]                           T:type53160(k15)
02d6c198: bl      #0x2b70db0                                 fn_2b70db0
02d6c19c: adrp    x0, #0x626b000                             
02d6c1a0: ldr     x0, [x0, #0xe50]                           MS:System.Collections.Generic.List`1::ForEach
02d6c1a4: bl      #0x2b70db0                                 fn_2b70db0
02d6c1a8: adrp    x0, #0x626b000                             
02d6c1ac: ldr     x0, [x0, #0xe58]                           MS:System.Collections.Generic.List`1::ForEach
02d6c1b0: bl      #0x2b70db0                                 fn_2b70db0
02d6c1b4: adrp    x0, #0x626c000                             
02d6c1b8: ldr     x0, [x0, #0x428]                           MS:MonoSingleton`1::Initiate
02d6c1bc: bl      #0x2b70db0                                 fn_2b70db0
02d6c1c0: adrp    x0, #0x6267000                             
02d6c1c4: ldr     x0, [x0, #0xbd0]                           MS:MonoSingleton`1::get_Instance
02d6c1c8: bl      #0x2b70db0                                 fn_2b70db0
02d6c1cc: adrp    x0, #0x626c000                             
02d6c1d0: ldr     x0, [x0, #0x430]                           M:Clicker.KeycapMakerController/<>c::<Initiate>b__48_0
02d6c1d4: bl      #0x2b70db0                                 fn_2b70db0
02d6c1d8: adrp    x0, #0x626c000                             
02d6c1dc: ldr     x0, [x0, #0x438]                           M:Clicker.KeycapMakerController/<>c::<Initiate>b__48_1
02d6c1e0: bl      #0x2b70db0                                 fn_2b70db0
02d6c1e4: adrp    x0, #0x626c000                             
02d6c1e8: ldr     x0, [x0, #0x440]                           T:Clicker.KeycapMakerController/<>c
02d6c1ec: bl      #0x2b70db0                                 fn_2b70db0
02d6c1f0: adrp    x0, #0x626c000                             
02d6c1f4: ldr     x0, [x0, #0xe8]                            MS:UIManager::GetScreen ._pointerHandTutorial
02d6c1f8: bl      #0x2b70db0                                 fn_2b70db0
02d6c1fc: mov     w8, #1                                     
02d6c200: strb    w8, [x21, #0x374]                          
02d6c204: ldr     x1, [x22]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d6c208: mov     x0, x19                                    
02d6c20c: bl      #0x3769de4                                 fn_3769de4
02d6c210: ldr     x0, [x20]                                  S:'didu'
02d6c214: bl      #0x3769600                                 fn_3769600
02d6c218: cbz     x0, #0x2d6c444                             
02d6c21c: adrp    x8, #0x626c000                             
02d6c220: adrp    x23, #0x626c000                            
02d6c224: ldr     x8, [x8, #0xe8]                            MS:UIManager::GetScreen
02d6c228: ldr     x23, [x23, #0x440]                         T:Clicker.KeycapMakerController/<>c
02d6c22c: ldr     x1, [x8]                                   M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d6c230: bl      #0x33fbbd0                                 fn_33fbbd0
02d6c234: mov     x1, x0                                     
02d6c238: str     x0, [x19, #0x120]                          ._ingameClickerScreen
02d6c23c: add     x0, x19, #0x120                            
02d6c240: bl      #0x2b70d54                                 fn_2b70d54
02d6c244: ldr     x0, [x23]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d6c248: ldr     x20, [x19, #0x80]                          ._switchList
02d6c24c: ldr     w8, [x0, #0xe4]                            [626c0e4]=0 f=0,0
02d6c250: cbnz    w8, #0x2d6c25c                             
02d6c254: bl      #0x2b70f30                                 fn_2b70f30
02d6c258: ldr     x0, [x23]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d6c25c: ldr     x8, [x0, #0xb8]                            MS:System.Collections.Generic.List`1::Add ._keychainConfig
02d6c260: ldr     x21, [x8, #8]                              M:Clicker.GlowSprite2DItem::<DoGlow>b__10_3
02d6c264: cbnz    x21, #0x2d6c2c0                            
02d6c268: ldr     w9, [x0, #0xe4]                            [626c0e4]=0 f=0,0
02d6c26c: cbnz    w9, #0x2d6c27c                             
02d6c270: bl      #0x2b70f30                                 fn_2b70f30
02d6c274: ldr     x8, [x23]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d6c278: ldr     x8, [x8, #0xb8]                            MS:System.Collections.Generic.List`1::Add
02d6c27c: adrp    x9, #0x626b000                             
02d6c280: ldr     x9, [x9, #0xe28]                           T:type53160(k15)
02d6c284: ldr     x22, [x8]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d6c288: ldr     x0, [x9]                                   T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d6c28c: bl      #0x2b7104c                                 fn_2b7104c
02d6c290: adrp    x8, #0x626c000                             
02d6c294: mov     x1, x22                                    
02d6c298: mov     x3, xzr                                    
02d6c29c: ldr     x8, [x8, #0x430]                           M:Clicker.KeycapMakerController/<>c::<Initiate>b__48_0
02d6c2a0: mov     x21, x0                                    
02d6c2a4: ldr     x2, [x8]                                   M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d6c2a8: bl      #0x453418c                                 fn_453418c
02d6c2ac: ldr     x8, [x23]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d6c2b0: mov     x1, x21                                    
02d6c2b4: ldr     x0, [x8, #0xb8]                            MS:System.Collections.Generic.List`1::Add
02d6c2b8: str     x21, [x0, #8]!                             
02d6c2bc: bl      #0x2b70d54                                 fn_2b70d54
02d6c2c0: cbz     x20, #0x2d6c444                            
02d6c2c4: adrp    x8, #0x626b000                             
02d6c2c8: mov     x0, x20                                    
02d6c2cc: mov     x1, x21                                    
02d6c2d0: ldr     x8, [x8, #0xe50]                           MS:System.Collections.Generic.List`1::ForEach
02d6c2d4: ldr     x2, [x8]                                   T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d6c2d8: bl      #0x35a9ce4                                 fn_35a9ce4
02d6c2dc: ldr     x0, [x23]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d6c2e0: ldr     x20, [x19, #0x90]                          ._keycapList
02d6c2e4: ldr     w8, [x0, #0xe4]                            [626c0e4]=0 f=0,0
02d6c2e8: cbnz    w8, #0x2d6c2f4                             
02d6c2ec: bl      #0x2b70f30                                 fn_2b70f30
02d6c2f0: ldr     x0, [x23]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d6c2f4: ldr     x8, [x0, #0xb8]                            MS:System.Collections.Generic.List`1::Add ._keychainConfig
02d6c2f8: ldr     x21, [x8, #0x10]                           MS:System.Collections.Generic.List`1::Find
02d6c2fc: cbnz    x21, #0x2d6c358                            
02d6c300: ldr     w9, [x0, #0xe4]                            [626c0e4]=0 f=0,0
02d6c304: cbnz    w9, #0x2d6c314                             
02d6c308: bl      #0x2b70f30                                 fn_2b70f30
02d6c30c: ldr     x8, [x23]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d6c310: ldr     x8, [x8, #0xb8]                            S:'scoop_no_thank'
02d6c314: adrp    x9, #0x626b000                             
02d6c318: ldr     x9, [x9, #0xe20]                           T:type53140(k15)
02d6c31c: ldr     x22, [x8]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d6c320: ldr     x0, [x9]                                   T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d6c324: bl      #0x2b7104c                                 fn_2b7104c
02d6c328: adrp    x8, #0x626c000                             
02d6c32c: mov     x1, x22                                    
02d6c330: mov     x3, xzr                                    
02d6c334: ldr     x8, [x8, #0x438]                           M:Clicker.KeycapMakerController/<>c::<Initiate>b__48_1
02d6c338: mov     x21, x0                                    
02d6c33c: ldr     x2, [x8]                                   M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d6c340: bl      #0x453418c                                 fn_453418c
02d6c344: ldr     x8, [x23]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d6c348: mov     x1, x21                                    
02d6c34c: ldr     x0, [x8, #0xb8]                            MS:System.Collections.Generic.List`1::Add
02d6c350: str     x21, [x0, #0x10]!                          
02d6c354: bl      #0x2b70d54                                 fn_2b70d54
02d6c358: cbz     x20, #0x2d6c444                            
02d6c35c: adrp    x8, #0x626b000                             
02d6c360: mov     x0, x20                                    
02d6c364: mov     x1, x21                                    
02d6c368: ldr     x8, [x8, #0xe58]                           MS:System.Collections.Generic.List`1::ForEach
02d6c36c: ldr     x2, [x8]                                   T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d6c370: bl      #0x35a9ce4                                 fn_35a9ce4
02d6c374: ldr     x0, [x19, #0x38]                           ._goTray
02d6c378: cbz     x0, #0x2d6c444                             
02d6c37c: mov     w1, wzr                                    
02d6c380: mov     x2, xzr                                    
02d6c384: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d6c388: ldr     x0, [x19, #0xc0]                           ._srKeychain
02d6c38c: cbz     x0, #0x2d6c444                             
02d6c390: mov     x1, xzr                                    
02d6c394: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02d6c398: movi    d0, #0000000000000000                      
02d6c39c: movi    d1, #0000000000000000                      
02d6c3a0: mov     x1, xzr                                    
02d6c3a4: bl      #0x2d98c98                                 DG.Tweening.ShortcutExtensions::DOScale
02d6c3a8: ldr     x0, [x19, #0xb0]                           ._tfHighlight
02d6c3ac: cbz     x0, #0x2d6c444                             
02d6c3b0: mov     x1, xzr                                    
02d6c3b4: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02d6c3b8: movi    d0, #0000000000000000                      
02d6c3bc: movi    d1, #0000000000000000                      
02d6c3c0: mov     x1, xzr                                    
02d6c3c4: bl      #0x2d98c98                                 DG.Tweening.ShortcutExtensions::DOScale
02d6c3c8: ldr     x0, [x19, #0xc8]                           ._dragManager
02d6c3cc: cbz     x0, #0x2d6c444                             
02d6c3d0: mov     w1, wzr                                    
02d6c3d4: bl      #0x2d61d74                                 Clicker.DragManager::SetDraggable
02d6c3d8: movi    d0, #0000000000000000                      
02d6c3dc: movi    d1, #0000000000000000                      
02d6c3e0: ldr     x0, [x19, #0x110]                          ._srBG
02d6c3e4: mov     x1, xzr                                    
02d6c3e8: bl      #0x2c77d0c                                 DG.Tweening.DOTweenModuleSprite::DOFade
02d6c3ec: movi    d0, #0000000000000000                      
02d6c3f0: movi    d1, #0000000000000000                      
02d6c3f4: ldr     x0, [x19, #0xe0]                           ._srBGForPopupComplete
02d6c3f8: mov     x1, xzr                                    
02d6c3fc: bl      #0x2c77d0c                                 DG.Tweening.DOTweenModuleSprite::DOFade
02d6c400: movi    d0, #0000000000000000                      
02d6c404: movi    d1, #0000000000000000                      
02d6c408: ldr     x0, [x19, #0x118]                          ._tfFinalEffect
02d6c40c: mov     x1, xzr                                    
02d6c410: bl      #0x2d98c98                                 DG.Tweening.ShortcutExtensions::DOScale
02d6c414: mov     x0, x19                                    
02d6c418: bl      #0x2d6c448                                 Clicker.KeycapMakerController::ShowTableBG
02d6c41c: mov     x0, x19                                    
02d6c420: mov     w1, wzr                                    
02d6c424: bl      #0x2d6c0cc                                 Clicker.KeycapMakerController::SetMultipleInput
02d6c428: ldr     x0, [x19, #0x70]                           ._tutorialSelectKeycapBase
02d6c42c: cbz     x0, #0x2d6c444                             
02d6c430: ldp     x20, x19, [sp, #0x20]                      
02d6c434: mov     x1, xzr                                    
02d6c438: ldp     x22, x21, [sp, #0x10]                      
02d6c43c: ldp     x30, x23, [sp], #0x30                      
02d6c440: b       #0x2d74b70                                 Clicker.TutorialSelectKeycapBase::ShowWithAnim
02d6c444: bl      #0x2b7105c                                 fn_2b7105c
## ShowStepPreviewBaseKeycap(bool isShow) -> void
---- Clicker.KeycapMakerController::ShowStepPreviewBaseKeycap 0x2d6c480
02d6c480: str     x30, [sp, #-0x20]!                         
02d6c484: stp     x20, x19, [sp, #0x10]                      
02d6c488: mov     x19, x0                                    
02d6c48c: ldr     x0, [x0, #0x68]                            ._srPreviewPrinter
02d6c490: cbz     x0, #0x2d6c4e8                             
02d6c494: mov     w20, w1                                    
02d6c498: mov     x1, xzr                                    
02d6c49c: bl      #0x5b339ec                                 UnityEngine.Component::get_gameObject
02d6c4a0: cbz     x0, #0x2d6c4e8                             
02d6c4a4: and     w1, w20, #1                                
02d6c4a8: mov     x2, xzr                                    
02d6c4ac: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d6c4b0: tbz     w20, #0, #0x2d6c4dc                        
02d6c4b4: ldr     x0, [x19, #0x68]                           ._srPreviewPrinter
02d6c4b8: cbz     x0, #0x2d6c4e8                             
02d6c4bc: mov     x1, xzr                                    
02d6c4c0: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02d6c4c4: ldp     x20, x19, [sp, #0x10]                      
02d6c4c8: movi    d0, #0000000000000000                      
02d6c4cc: movi    d1, #0000000000000000                      
02d6c4d0: mov     x1, xzr                                    
02d6c4d4: ldr     x30, [sp], #0x20                           
02d6c4d8: b       #0x2d98c98                                 DG.Tweening.ShortcutExtensions::DOScale
02d6c4dc: ldp     x20, x19, [sp, #0x10]                      
02d6c4e0: ldr     x30, [sp], #0x20                           
02d6c4e4: ret                                                
02d6c4e8: bl      #0x2b7105c                                 fn_2b7105c
## SetBaseKeycapId(int id) -> void
---- Clicker.KeycapMakerController::SetBaseKeycapId 0x2d6c4ec
02d6c4ec: stp     x30, x21, [sp, #-0x20]!                    
02d6c4f0: stp     x20, x19, [sp, #0x10]                      
02d6c4f4: mov     x19, x0                                    
02d6c4f8: ldr     x0, [x0, #0x70]                            ._tutorialSelectKeycapBase
02d6c4fc: cbz     x0, #0x2d6c55c                             
02d6c500: mov     w20, w1                                    
02d6c504: mov     x1, xzr                                    
02d6c508: bl      #0x2d74c90                                 Clicker.TutorialSelectKeycapBase::HideTutorial
02d6c50c: ldr     x0, [x19, #0x60]                           ._baseKeycapConfig
02d6c510: cbz     x0, #0x2d6c55c                             
02d6c514: mov     w1, w20                                    
02d6c518: bl      #0x2d5b300                                 Clicker.BaseKeycapConfig::GetData
02d6c51c: cbz     x0, #0x2d6c550                             
02d6c520: ldr     x1, [x0, #0x30]                            ._keychainId
02d6c524: mov     x21, x0                                    
02d6c528: mov     x0, x19                                    
02d6c52c: str     w20, [x19, #0x20]                          ._baseKeycapId
02d6c530: bl      #0x2d6c560                                 Clicker.KeycapMakerController::ChangePrinterBasePreview
02d6c534: ldr     x0, [x19, #0x58]                           ._srBaseKeycapOnTray
02d6c538: cbz     x0, #0x2d6c55c                             
02d6c53c: ldr     x1, [x21, #0x30]                           ._keychainId
02d6c540: mov     x2, xzr                                    
02d6c544: bl      #0x5ae6dcc                                 UnityEngine.SpriteRenderer::set_sprite
02d6c548: ldr     w8, [x21, #0x20]                           ._baseKeycapId
02d6c54c: str     w8, [x19, #0x128]                          ._switchAmount
02d6c550: ldp     x20, x19, [sp, #0x10]                      
02d6c554: ldp     x30, x21, [sp], #0x20                      
02d6c558: ret                                                
02d6c55c: bl      #0x2b7105c                                 fn_2b7105c
## ChangePrinterBasePreview(UnityEngine.Sprite spriteNew) -> void
---- Clicker.KeycapMakerController::ChangePrinterBasePreview 0x2d6c560
02d6c560: str     x30, [sp, #-0x30]!                         
02d6c564: stp     x22, x21, [sp, #0x10]                      
02d6c568: stp     x20, x19, [sp, #0x20]                      
02d6c56c: adrp    x19, #0x6630000                            
02d6c570: adrp    x22, #0x626c000                            
02d6c574: mov     x21, x1                                    
02d6c578: ldrb    w8, [x19, #0x375]                          
02d6c57c: ldr     x22, [x22, #0x448]                         T:Clicker.KeycapMakerController/<>c__DisplayClass51_0
02d6c580: mov     x20, x0                                    
02d6c584: tbnz    w8, #0, #0x2d6c5cc                         
02d6c588: adrp    x0, #0x6264000                             
02d6c58c: ldr     x0, [x0, #0xe8]                            T:DG.Tweening.TweenCallback ._pointerHandTutorial
02d6c590: bl      #0x2b70db0                                 fn_2b70db0
02d6c594: adrp    x0, #0x6266000                             
02d6c598: ldr     x0, [x0, #0x928]                           MS:DG.Tweening.TweenSettingsExtensions::OnComplete
02d6c59c: bl      #0x2b70db0                                 fn_2b70db0
02d6c5a0: adrp    x0, #0x626c000                             
02d6c5a4: ldr     x0, [x0, #0x450]                           M:Clicker.KeycapMakerController/<>c__DisplayClass51_0::<ChangePrinterBasePreview>b__0
02d6c5a8: bl      #0x2b70db0                                 fn_2b70db0
02d6c5ac: adrp    x0, #0x626c000                             
02d6c5b0: ldr     x0, [x0, #0x448]                           T:Clicker.KeycapMakerController/<>c__DisplayClass51_0
02d6c5b4: bl      #0x2b70db0                                 fn_2b70db0
02d6c5b8: adrp    x0, #0x6267000                             
02d6c5bc: ldr     x0, [x0, #0xea8]                           T:Framework.Vibration
02d6c5c0: bl      #0x2b70db0                                 fn_2b70db0
02d6c5c4: mov     w8, #1                                     
02d6c5c8: strb    w8, [x19, #0x375]                          
02d6c5cc: ldr     x0, [x22]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d6c5d0: bl      #0x2b7104c                                 fn_2b7104c
02d6c5d4: mov     x1, xzr                                    
02d6c5d8: mov     x19, x0                                    
02d6c5dc: bl      #0x2d6e4a4                                 Clicker.KeycapMakerController/<>c__DisplayClass51_0::.ctor
02d6c5e0: cbz     x19, #0x2d6c6c8                            
02d6c5e4: adrp    x22, #0x6267000                            
02d6c5e8: mov     x0, x19                                    
02d6c5ec: mov     x1, x20                                    
02d6c5f0: ldr     x22, [x22, #0xea8]                         T:Framework.Vibration
02d6c5f4: str     x20, [x0, #0x10]!                          
02d6c5f8: bl      #0x2b70d54                                 fn_2b70d54
02d6c5fc: mov     x0, x19                                    
02d6c600: mov     x1, x21                                    
02d6c604: str     x21, [x0, #0x18]!                          
02d6c608: bl      #0x2b70d54                                 fn_2b70d54
02d6c60c: ldr     x0, [x22]                                  S:'didu'
02d6c610: ldr     w8, [x0, #0xe4]                            [62670e4]=0 f=0,0
02d6c614: cbnz    w8, #0x2d6c61c                             
02d6c618: bl      #0x2b70f30                                 fn_2b70f30
02d6c61c: mov     w0, #0x32                                  
02d6c620: mov     w1, #-1                                    
02d6c624: mov     w2, wzr                                    
02d6c628: mov     x3, xzr                                    
02d6c62c: bl      #0x2d6e144                                 Framework.Vibration::Vibrate
02d6c630: ldr     x0, [x20, #0x68]                           ._srPreviewPrinter
02d6c634: cbz     x0, #0x2d6c6c8                             
02d6c638: mov     x1, xzr                                    
02d6c63c: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02d6c640: mov     w1, wzr                                    
02d6c644: mov     x2, xzr                                    
02d6c648: bl      #0x2d9d5d0                                 DG.Tweening.ShortcutExtensions::DOKill
02d6c64c: ldr     x0, [x20, #0x68]                           ._srPreviewPrinter
02d6c650: cbz     x0, #0x2d6c6c8                             
02d6c654: adrp    x20, #0x6264000                            
02d6c658: adrp    x21, #0x626c000                            
02d6c65c: adrp    x22, #0x6266000                            
02d6c660: ldr     x20, [x20, #0xe8]                          T:DG.Tweening.TweenCallback ._pointerHandTutorial
02d6c664: ldr     x21, [x21, #0x450]                         M:Clicker.KeycapMakerController/<>c__DisplayClass51_0::<ChangePrinterBasePreview>b__0
02d6c668: ldr     x22, [x22, #0x928]                         MS:DG.Tweening.TweenSettingsExtensions::OnComplete
02d6c66c: mov     x1, xzr                                    
02d6c670: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02d6c674: movi    d0, #0000000000000000                      
02d6c678: adrp    x8, #0x1084000                             
02d6c67c: mov     x1, xzr                                    
02d6c680: ldr     s1, [x8, #0xeec]                           [1084eec]=457ff0003dcccccd f=0.1,4095
02d6c684: bl      #0x2d98c98                                 DG.Tweening.ShortcutExtensions::DOScale
02d6c688: ldr     x8, [x20]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d6c68c: mov     x20, x0                                    
02d6c690: mov     x0, x8                                     
02d6c694: bl      #0x2b7104c                                 fn_2b7104c
02d6c698: ldr     x2, [x21]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d6c69c: mov     x1, x19                                    
02d6c6a0: mov     x3, xzr                                    
02d6c6a4: mov     x21, x0                                    
02d6c6a8: bl      #0x2d89dc4                                 DG.Tweening.TweenCallback::.ctor
02d6c6ac: ldr     x2, [x22]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d6c6b0: mov     x0, x20                                    
02d6c6b4: mov     x1, x21                                    
02d6c6b8: ldp     x20, x19, [sp, #0x20]                      
02d6c6bc: ldp     x22, x21, [sp, #0x10]                      
02d6c6c0: ldr     x30, [sp], #0x30                           
02d6c6c4: b       #0x336f26c                                 
02d6c6c8: bl      #0x2b7105c                                 fn_2b7105c
## HidePreviewShowPrinter() -> void
---- Clicker.KeycapMakerController::HidePreviewShowPrinter 0x2d6c6cc
02d6c6cc: stp     x30, x19, [sp, #-0x10]!                    
02d6c6d0: mov     x19, x0                                    
02d6c6d4: ldr     x0, [x0, #0x68]                            ._srPreviewPrinter
02d6c6d8: cbz     x0, #0x2d6c76c                             
02d6c6dc: mov     x1, xzr                                    
02d6c6e0: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02d6c6e4: mov     w1, wzr                                    
02d6c6e8: mov     x2, xzr                                    
02d6c6ec: bl      #0x2d9d5d0                                 DG.Tweening.ShortcutExtensions::DOKill
02d6c6f0: ldr     x0, [x19, #0x68]                           ._srPreviewPrinter
02d6c6f4: cbz     x0, #0x2d6c76c                             
02d6c6f8: mov     x1, xzr                                    
02d6c6fc: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02d6c700: movi    d0, #0000000000000000                      
02d6c704: movi    d1, #0000000000000000                      
02d6c708: mov     x1, xzr                                    
02d6c70c: bl      #0x2d98c98                                 DG.Tweening.ShortcutExtensions::DOScale
02d6c710: ldr     x0, [x19, #0x60]                           ._baseKeycapConfig
02d6c714: cbz     x0, #0x2d6c76c                             
02d6c718: ldr     w1, [x19, #0x20]                           ._baseKeycapId
02d6c71c: bl      #0x2d5b300                                 Clicker.BaseKeycapConfig::GetData
02d6c720: cbz     x0, #0x2d6c764                             
02d6c724: ldr     x8, [x19, #0x78]                           ._printerMachine
02d6c728: cbz     x8, #0x2d6c76c                             
02d6c72c: ldr     x1, [x0, #0x38]                            ._goTray
02d6c730: mov     x0, x8                                     
02d6c734: bl      #0x2d64dd8                                 Clicker.PrinterMachine::ChangeBaseKeycap
02d6c738: ldr     x0, [x19, #0x78]                           ._printerMachine
02d6c73c: cbz     x0, #0x2d6c76c                             
02d6c740: mov     x1, xzr                                    
02d6c744: bl      #0x5b339ec                                 UnityEngine.Component::get_gameObject
02d6c748: cbz     x0, #0x2d6c76c                             
02d6c74c: mov     w1, #1                                     
02d6c750: mov     x2, xzr                                    
02d6c754: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d6c758: mov     x0, x19                                    
02d6c75c: ldp     x30, x19, [sp], #0x10                      
02d6c760: b       #0x2d6c770                                 Clicker.KeycapMakerController::ShowWallBG
02d6c764: ldp     x30, x19, [sp], #0x10                      
02d6c768: ret                                                
02d6c76c: bl      #0x2b7105c                                 fn_2b7105c
## SpeedUpPrinter() -> void
---- Clicker.KeycapMakerController::SpeedUpPrinter 0x2d6c7a8
02d6c7a8: str     x30, [sp, #-0x10]!                         
02d6c7ac: ldr     x8, [x0, #0x78]                            ._printerMachine
02d6c7b0: cbz     x8, #0x2d6c7c4                             
02d6c7b4: ldr     x0, [x8, #0x28]                            
02d6c7b8: cbz     x0, #0x2d6c7c4                             
02d6c7bc: ldr     x30, [sp], #0x10                           
02d6c7c0: b       #0x2d64b84                                 Clicker.PrinterRail::SpeedUp
02d6c7c4: bl      #0x2b7105c                                 fn_2b7105c
## HidePrinterShowTray() -> void
---- Clicker.KeycapMakerController::HidePrinterShowTray 0x2d6c7c8
02d6c7c8: stp     x30, x19, [sp, #-0x10]!                    
02d6c7cc: mov     x19, x0                                    
02d6c7d0: ldr     x0, [x0, #0x78]                            ._printerMachine
02d6c7d4: cbz     x0, #0x2d6c810                             
02d6c7d8: mov     x1, xzr                                    
02d6c7dc: bl      #0x5b339ec                                 UnityEngine.Component::get_gameObject
02d6c7e0: cbz     x0, #0x2d6c810                             
02d6c7e4: mov     w1, wzr                                    
02d6c7e8: mov     x2, xzr                                    
02d6c7ec: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d6c7f0: ldr     x0, [x19, #0x38]                           ._goTray
02d6c7f4: cbz     x0, #0x2d6c810                             
02d6c7f8: mov     w1, #1                                     
02d6c7fc: mov     x2, xzr                                    
02d6c800: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d6c804: mov     x0, x19                                    
02d6c808: ldp     x30, x19, [sp], #0x10                      
02d6c80c: b       #0x2d6c770                                 Clicker.KeycapMakerController::ShowWallBG
02d6c810: bl      #0x2b7105c                                 fn_2b7105c
## SpawnSwitch(int id) -> void
---- Clicker.KeycapMakerController::SpawnSwitch 0x2d6c814
02d6c814: stp     d9, d8, [sp, #-0x70]!                      
02d6c818: stp     x29, x30, [sp, #0x10]                      
02d6c81c: stp     x28, x27, [sp, #0x20]                      
02d6c820: stp     x26, x25, [sp, #0x30]                      
02d6c824: stp     x24, x23, [sp, #0x40]                      
02d6c828: stp     x22, x21, [sp, #0x50]                      
02d6c82c: stp     x20, x19, [sp, #0x60]                      
02d6c830: adrp    x20, #0x6630000                            
02d6c834: mov     w21, w1                                    
02d6c838: mov     x19, x0                                    
02d6c83c: ldrb    w8, [x20, #0x376]                          
02d6c840: tbnz    w8, #0, #0x2d6c8b8                         
02d6c844: adrp    x0, #0x626b000                             
02d6c848: ldr     x0, [x0, #0xec0]                           MS:System.Collections.Generic.List`1::get_Count
02d6c84c: bl      #0x2b70db0                                 fn_2b70db0
02d6c850: adrp    x0, #0x626b000                             
02d6c854: ldr     x0, [x0, #0xec8]                           MS:System.Collections.Generic.List`1::get_Item
02d6c858: bl      #0x2b70db0                                 fn_2b70db0
02d6c85c: adrp    x0, #0x6263000                             
02d6c860: ldr     x0, [x0, #0x918]                           T:UnityEngine.Object
02d6c864: bl      #0x2b70db0                                 fn_2b70db0
02d6c868: adrp    x0, #0x6264000                             
02d6c86c: ldr     x0, [x0, #0xe8]                            T:DG.Tweening.TweenCallback ._pointerHandTutorial
02d6c870: bl      #0x2b70db0                                 fn_2b70db0
02d6c874: adrp    x0, #0x6267000                             
02d6c878: ldr     x0, [x0, #0x8d8]                           MS:DG.Tweening.TweenSettingsExtensions::OnStart
02d6c87c: bl      #0x2b70db0                                 fn_2b70db0
02d6c880: adrp    x0, #0x6266000                             
02d6c884: ldr     x0, [x0, #0xe08]                           MS:DG.Tweening.TweenSettingsExtensions::SetDelay
02d6c888: bl      #0x2b70db0                                 fn_2b70db0
02d6c88c: adrp    x0, #0x6266000                             
02d6c890: ldr     x0, [x0, #0x880]                           MS:DG.Tweening.TweenSettingsExtensions::SetEase
02d6c894: bl      #0x2b70db0                                 fn_2b70db0
02d6c898: adrp    x0, #0x626c000                             
02d6c89c: ldr     x0, [x0, #0x458]                           M:Clicker.KeycapMakerController/<>c::<SpawnSwitch>b__55_0
02d6c8a0: bl      #0x2b70db0                                 fn_2b70db0
02d6c8a4: adrp    x0, #0x626c000                             
02d6c8a8: ldr     x0, [x0, #0x440]                           T:Clicker.KeycapMakerController/<>c
02d6c8ac: bl      #0x2b70db0                                 fn_2b70db0
02d6c8b0: mov     w8, #1                                     
02d6c8b4: strb    w8, [x20, #0x376]                          
02d6c8b8: ldr     x0, [x19, #0x88]                           ._switchConfig
02d6c8bc: cbz     x0, #0x2d6ca9c                             
02d6c8c0: mov     w1, w21                                    
02d6c8c4: bl      #0x2d5bd98                                 Clicker.SwitchConfig::GetData
02d6c8c8: cbz     x0, #0x2d6cafc                             
02d6c8cc: mov     x20, x0                                    
02d6c8d0: ldr     x0, [x19, #0x80]                           ._switchList
02d6c8d4: str     w21, [x19, #0x24]                          ._switchId
02d6c8d8: cbz     x0, #0x2d6ca9c                             
02d6c8dc: adrp    x25, #0x626b000                            
02d6c8e0: adrp    x26, #0x6266000                            
02d6c8e4: adrp    x27, #0x6266000                            
02d6c8e8: adrp    x28, #0x626c000                            
02d6c8ec: adrp    x29, #0x6267000                            
02d6c8f0: adrp    x8, #0x1084000                             
02d6c8f4: adrp    x9, #0x1084000                             
02d6c8f8: ldr     x25, [x25, #0xec8]                         MS:System.Collections.Generic.List`1::get_Item
02d6c8fc: ldr     x26, [x26, #0x880]                         MS:DG.Tweening.TweenSettingsExtensions::SetEase
02d6c900: ldr     x27, [x27, #0xe08]                         MS:DG.Tweening.TweenSettingsExtensions::SetDelay
02d6c904: ldr     x28, [x28, #0x440]                         T:Clicker.KeycapMakerController/<>c
02d6c908: ldr     x29, [x29, #0x8d8]                         MS:DG.Tweening.TweenSettingsExtensions::OnStart
02d6c90c: ldr     s8, [x8, #0xf10]                           [1084f10]=4110bc863e99999a f=0.3,9.04603
02d6c910: ldr     s9, [x9, #0xeec]                           [1084eec]=457ff0003dcccccd f=0.1,4095
02d6c914: mov     w21, wzr                                   
02d6c918: ldr     w8, [x0, #0x18]                            M:Clicker.GlowSprite2DItem::<DoGlow>b__10_5
02d6c91c: cmp     w21, w8                                    
02d6c920: b.ge    #0x2d6caa0                                 
02d6c924: ldr     x2, [x25]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d6c928: mov     w1, w21                                    
02d6c92c: bl      #0x35a8f3c                                 fn_35a8f3c
02d6c930: cbz     x0, #0x2d6ca9c                             
02d6c934: mov     x1, xzr                                    
02d6c938: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02d6c93c: mov     w1, wzr                                    
02d6c940: mov     x2, xzr                                    
02d6c944: bl      #0x2d9d5d0                                 DG.Tweening.ShortcutExtensions::DOKill
02d6c948: ldr     x0, [x19, #0x80]                           ._switchList
02d6c94c: cbz     x0, #0x2d6ca9c                             
02d6c950: ldr     x2, [x25]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d6c954: mov     w1, w21                                    
02d6c958: bl      #0x35a8f3c                                 fn_35a8f3c
02d6c95c: cbz     x0, #0x2d6ca9c                             
02d6c960: mov     x1, xzr                                    
02d6c964: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02d6c968: movi    d0, #0000000000000000                      
02d6c96c: movi    d1, #0000000000000000                      
02d6c970: mov     x1, xzr                                    
02d6c974: bl      #0x2d98c98                                 DG.Tweening.ShortcutExtensions::DOScale
02d6c978: ldr     w8, [x19, #0x128]                          ._switchAmount
02d6c97c: cmp     w21, w8                                    
02d6c980: b.ge    #0x2d6ca90                                 
02d6c984: ldr     x0, [x19, #0x80]                           ._switchList
02d6c988: cbz     x0, #0x2d6ca9c                             
02d6c98c: ldr     x2, [x25]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d6c990: mov     w1, w21                                    
02d6c994: bl      #0x35a8f3c                                 fn_35a8f3c
02d6c998: cbz     x0, #0x2d6ca9c                             
02d6c99c: ldr     x0, [x0, #0x20]                            M:Clicker.GlowSprite2DItem::<DoGlow>b__10_6 ._baseKeycapId
02d6c9a0: cbz     x0, #0x2d6ca9c                             
02d6c9a4: ldr     x1, [x20, #0x18]                           
02d6c9a8: mov     x2, xzr                                    
02d6c9ac: bl      #0x5ae6dcc                                 UnityEngine.SpriteRenderer::set_sprite
02d6c9b0: ldr     x0, [x19, #0x80]                           ._switchList
02d6c9b4: cbz     x0, #0x2d6ca9c                             
02d6c9b8: ldr     x2, [x25]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d6c9bc: mov     w1, w21                                    
02d6c9c0: bl      #0x35a8f3c                                 fn_35a8f3c
02d6c9c4: cbz     x0, #0x2d6ca9c                             
02d6c9c8: mov     x1, xzr                                    
02d6c9cc: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02d6c9d0: fmov    s1, s8                                     
02d6c9d4: fmov    s0, #1.00000000                            
02d6c9d8: mov     x1, xzr                                    
02d6c9dc: bl      #0x2d98c98                                 DG.Tweening.ShortcutExtensions::DOScale
02d6c9e0: ldr     x2, [x26]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d6c9e4: mov     w1, #0x1b                                  
02d6c9e8: bl      #0x336fa0c                                 fn_336fa0c
02d6c9ec: scvtf   s0, w21                                    
02d6c9f0: ldr     x1, [x27]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d6c9f4: fmul    s0, s0, s9                                 
02d6c9f8: bl      #0x336f7fc                                 fn_336f7fc
02d6c9fc: ldr     x8, [x28]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d6ca00: mov     x22, x0                                    
02d6ca04: ldr     w9, [x8, #0xe4]                            [10840e4]=2c2644327265746c f=4.54482e+30,2.36279e-12
02d6ca08: cbnz    w9, #0x2d6ca18                             
02d6ca0c: mov     x0, x8                                     
02d6ca10: bl      #0x2b70f30                                 fn_2b70f30
02d6ca14: ldr     x8, [x28]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d6ca18: ldr     x9, [x8, #0xb8]                            [10840b8]=2632726f74636556 f=7.20646e+31,6.19112e-16
02d6ca1c: ldr     x23, [x9, #0x18]                           [1084018]=7974696c69745549 f=1.84613e+25,7.93162e+34
02d6ca20: cbnz    x23, #0x2d6ca80                            
02d6ca24: ldr     w10, [x8, #0xe4]                           [10840e4]=2c2644327265746c f=4.54482e+30,2.36279e-12
02d6ca28: cbnz    w10, #0x2d6ca3c                            
02d6ca2c: mov     x0, x8                                     
02d6ca30: bl      #0x2b70f30                                 fn_2b70f30
02d6ca34: ldr     x8, [x28]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d6ca38: ldr     x9, [x8, #0xb8]                            [10840b8]=2632726f74636556 f=7.20646e+31,6.19112e-16
02d6ca3c: adrp    x8, #0x6264000                             
02d6ca40: ldr     x24, [x9]                                  [1084000]=287475706e49646c f=1.5582e+28,1.35702e-14
02d6ca44: ldr     x8, [x8, #0xe8]                            T:DG.Tweening.TweenCallback
02d6ca48: ldr     x0, [x8]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d6ca4c: bl      #0x2b7104c                                 fn_2b7104c
02d6ca50: adrp    x8, #0x626c000                             
02d6ca54: mov     x1, x24                                    
02d6ca58: mov     x3, xzr                                    
02d6ca5c: ldr     x8, [x8, #0x458]                           M:Clicker.KeycapMakerController/<>c::<SpawnSwitch>b__55_0
02d6ca60: mov     x23, x0                                    
02d6ca64: ldr     x2, [x8]                                   M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d6ca68: bl      #0x2d89dc4                                 DG.Tweening.TweenCallback::.ctor
02d6ca6c: ldr     x8, [x28]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d6ca70: mov     x1, x23                                    
02d6ca74: ldr     x0, [x8, #0xb8]                            MS:System.Collections.Generic.List`1::Add
02d6ca78: str     x23, [x0, #0x18]!                          
02d6ca7c: bl      #0x2b70d54                                 fn_2b70d54
02d6ca80: ldr     x2, [x29]                                  S:'didu'
02d6ca84: mov     x0, x22                                    
02d6ca88: mov     x1, x23                                    
02d6ca8c: bl      #0x336f348                                 fn_336f348
02d6ca90: ldr     x0, [x19, #0x80]                           ._switchList
02d6ca94: add     w21, w21, #1                               
02d6ca98: cbnz    x0, #0x2d6c918                             
02d6ca9c: bl      #0x2b7105c                                 fn_2b7105c
02d6caa0: adrp    x8, #0x6263000                             
02d6caa4: ldr     x8, [x8, #0x918]                           T:UnityEngine.Object
02d6caa8: ldr     x21, [x19, #0xa0]                          ._baseKeycapObject
02d6caac: ldr     x0, [x8]                                   &2c5bbd4(=a9bd7bfdd503233f)
02d6cab0: ldr     w8, [x0, #0xe4]                            [626c0e4]=0 f=0,0
02d6cab4: cbnz    w8, #0x2d6cabc                             
02d6cab8: bl      #0x2b70f30                                 fn_2b70f30
02d6cabc: mov     x0, x21                                    
02d6cac0: mov     x1, xzr                                    
02d6cac4: mov     x2, xzr                                    
02d6cac8: bl      #0x5b3666c                                 UnityEngine.Object::op_Inequality
02d6cacc: tbz     w0, #0, #0x2d6cafc                         
02d6cad0: ldr     x0, [x19, #0xa0]                           ._baseKeycapObject
02d6cad4: cbz     x0, #0x2d6ca9c                             
02d6cad8: ldr     x1, [x20, #0x18]                           
02d6cadc: ldp     x20, x19, [sp, #0x60]                      
02d6cae0: ldp     x22, x21, [sp, #0x50]                      
02d6cae4: ldp     x24, x23, [sp, #0x40]                      
02d6cae8: ldp     x26, x25, [sp, #0x30]                      
02d6caec: ldp     x28, x27, [sp, #0x20]                      
02d6caf0: ldp     x29, x30, [sp, #0x10]                      
02d6caf4: ldp     d9, d8, [sp], #0x70                        
02d6caf8: b       #0x2d5e850                                 Clicker.BaseKeycapObject::SetSwitch
02d6cafc: ldp     x20, x19, [sp, #0x60]                      
02d6cb00: ldp     x22, x21, [sp, #0x50]                      
02d6cb04: ldp     x24, x23, [sp, #0x40]                      
02d6cb08: ldp     x26, x25, [sp, #0x30]                      
02d6cb0c: ldp     x28, x27, [sp, #0x20]                      
02d6cb10: ldp     x29, x30, [sp, #0x10]                      
02d6cb14: ldp     d9, d8, [sp], #0x70                        
02d6cb18: ret                                                
## SetSwitchSound(Framework.ESound sound) -> void
---- Clicker.KeycapMakerController::SetSwitchSound 0x2d6cb1c
02d6cb1c: ldr     x0, [x0, #0xa0]                            ._baseKeycapObject
02d6cb20: cbz     x0, #0x2d6cb28                             
02d6cb24: b       #0x2d5e93c                                 Clicker.BaseKeycapObject::SetSwitchSound
02d6cb28: str     x30, [sp, #-0x10]!                         
02d6cb2c: bl      #0x2b7105c                                 fn_2b7105c
## SpawnKeycap(int id) -> void
---- Clicker.KeycapMakerController::SpawnKeycap 0x2d6cb30
02d6cb30: stp     d9, d8, [sp, #-0x70]!                      
02d6cb34: stp     x29, x30, [sp, #0x10]                      
02d6cb38: stp     x28, x27, [sp, #0x20]                      
02d6cb3c: stp     x26, x25, [sp, #0x30]                      
02d6cb40: stp     x24, x23, [sp, #0x40]                      
02d6cb44: stp     x22, x21, [sp, #0x50]                      
02d6cb48: stp     x20, x19, [sp, #0x60]                      
02d6cb4c: adrp    x20, #0x6630000                            
02d6cb50: mov     w21, w1                                    
02d6cb54: mov     x19, x0                                    
02d6cb58: ldrb    w8, [x20, #0x377]                          
02d6cb5c: tbnz    w8, #0, #0x2d6cbc8                         
02d6cb60: adrp    x0, #0x626b000                             
02d6cb64: ldr     x0, [x0, #0xe80]                           MS:System.Collections.Generic.List`1::get_Count
02d6cb68: bl      #0x2b70db0                                 fn_2b70db0
02d6cb6c: adrp    x0, #0x626b000                             
02d6cb70: ldr     x0, [x0, #0xe88]                           MS:System.Collections.Generic.List`1::get_Item
02d6cb74: bl      #0x2b70db0                                 fn_2b70db0
02d6cb78: adrp    x0, #0x6264000                             
02d6cb7c: ldr     x0, [x0, #0xe8]                            T:DG.Tweening.TweenCallback ._pointerHandTutorial
02d6cb80: bl      #0x2b70db0                                 fn_2b70db0
02d6cb84: adrp    x0, #0x6267000                             
02d6cb88: ldr     x0, [x0, #0x8d8]                           MS:DG.Tweening.TweenSettingsExtensions::OnStart
02d6cb8c: bl      #0x2b70db0                                 fn_2b70db0
02d6cb90: adrp    x0, #0x6266000                             
02d6cb94: ldr     x0, [x0, #0xe08]                           MS:DG.Tweening.TweenSettingsExtensions::SetDelay
02d6cb98: bl      #0x2b70db0                                 fn_2b70db0
02d6cb9c: adrp    x0, #0x6266000                             
02d6cba0: ldr     x0, [x0, #0x880]                           MS:DG.Tweening.TweenSettingsExtensions::SetEase
02d6cba4: bl      #0x2b70db0                                 fn_2b70db0
02d6cba8: adrp    x0, #0x626c000                             
02d6cbac: ldr     x0, [x0, #0x460]                           M:Clicker.KeycapMakerController/<>c::<SpawnKeycap>b__57_0
02d6cbb0: bl      #0x2b70db0                                 fn_2b70db0
02d6cbb4: adrp    x0, #0x626c000                             
02d6cbb8: ldr     x0, [x0, #0x440]                           T:Clicker.KeycapMakerController/<>c
02d6cbbc: bl      #0x2b70db0                                 fn_2b70db0
02d6cbc0: mov     w8, #1                                     
02d6cbc4: strb    w8, [x20, #0x377]                          
02d6cbc8: ldr     x0, [x19, #0x98]                           ._keycapConfig
02d6cbcc: cbz     x0, #0x2d6cda8                             
02d6cbd0: mov     w1, w21                                    
02d6cbd4: bl      #0x2d5b820                                 Clicker.KeycapConfig::GetData
02d6cbd8: cbz     x0, #0x2d6cddc                             
02d6cbdc: mov     x20, x0                                    
02d6cbe0: ldr     x0, [x19, #0x90]                           ._keycapList
02d6cbe4: str     w21, [x19, #0x28]                          ._keycapId
02d6cbe8: cbz     x0, #0x2d6cda8                             
02d6cbec: adrp    x25, #0x626b000                            
02d6cbf0: adrp    x26, #0x6266000                            
02d6cbf4: adrp    x27, #0x6266000                            
02d6cbf8: adrp    x28, #0x626c000                            
02d6cbfc: adrp    x29, #0x6267000                            
02d6cc00: adrp    x8, #0x1084000                             
02d6cc04: adrp    x9, #0x1084000                             
02d6cc08: ldr     x25, [x25, #0xe88]                         MS:System.Collections.Generic.List`1::get_Item
02d6cc0c: ldr     x26, [x26, #0x880]                         MS:DG.Tweening.TweenSettingsExtensions::SetEase
02d6cc10: ldr     x27, [x27, #0xe08]                         MS:DG.Tweening.TweenSettingsExtensions::SetDelay
02d6cc14: ldr     x28, [x28, #0x440]                         T:Clicker.KeycapMakerController/<>c
02d6cc18: ldr     x29, [x29, #0x8d8]                         MS:DG.Tweening.TweenSettingsExtensions::OnStart
02d6cc1c: ldr     s8, [x8, #0xf10]                           [1084f10]=4110bc863e99999a f=0.3,9.04603
02d6cc20: ldr     s9, [x9, #0xeec]                           [1084eec]=457ff0003dcccccd f=0.1,4095
02d6cc24: mov     w21, wzr                                   
02d6cc28: ldr     w8, [x0, #0x18]                            M:Clicker.GlowSprite2DItem::<DoGlow>b__10_5
02d6cc2c: cmp     w21, w8                                    
02d6cc30: b.ge    #0x2d6cdac                                 
02d6cc34: ldr     x2, [x25]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d6cc38: mov     w1, w21                                    
02d6cc3c: bl      #0x35a8f3c                                 fn_35a8f3c
02d6cc40: cbz     x0, #0x2d6cda8                             
02d6cc44: mov     x1, xzr                                    
02d6cc48: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02d6cc4c: mov     w1, wzr                                    
02d6cc50: mov     x2, xzr                                    
02d6cc54: bl      #0x2d9d5d0                                 DG.Tweening.ShortcutExtensions::DOKill
02d6cc58: ldr     x0, [x19, #0x90]                           ._keycapList
02d6cc5c: cbz     x0, #0x2d6cda8                             
02d6cc60: ldr     x2, [x25]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d6cc64: mov     w1, w21                                    
02d6cc68: bl      #0x35a8f3c                                 fn_35a8f3c
02d6cc6c: cbz     x0, #0x2d6cda8                             
02d6cc70: mov     x1, xzr                                    
02d6cc74: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02d6cc78: movi    d0, #0000000000000000                      
02d6cc7c: movi    d1, #0000000000000000                      
02d6cc80: mov     x1, xzr                                    
02d6cc84: bl      #0x2d98c98                                 DG.Tweening.ShortcutExtensions::DOScale
02d6cc88: ldr     w8, [x19, #0x128]                          ._switchAmount
02d6cc8c: cmp     w21, w8                                    
02d6cc90: b.ge    #0x2d6cd9c                                 
02d6cc94: ldr     x0, [x19, #0x90]                           ._keycapList
02d6cc98: cbz     x0, #0x2d6cda8                             
02d6cc9c: ldr     x2, [x25]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d6cca0: mov     w1, w21                                    
02d6cca4: bl      #0x35a8f3c                                 fn_35a8f3c
02d6cca8: cbz     x0, #0x2d6cda8                             
02d6ccac: ldr     x1, [x20, #0x18]                           
02d6ccb0: mov     w2, wzr                                    
02d6ccb4: mov     w3, #-1                                    
02d6ccb8: bl      #0x2d5eac0                                 Clicker.KeycapObject::SetDecor
02d6ccbc: ldr     x0, [x19, #0x90]                           ._keycapList
02d6ccc0: cbz     x0, #0x2d6cda8                             
02d6ccc4: ldr     x2, [x25]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d6ccc8: mov     w1, w21                                    
02d6cccc: bl      #0x35a8f3c                                 fn_35a8f3c
02d6ccd0: cbz     x0, #0x2d6cda8                             
02d6ccd4: mov     x1, xzr                                    
02d6ccd8: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02d6ccdc: fmov    s1, s8                                     
02d6cce0: fmov    s0, #1.00000000                            
02d6cce4: mov     x1, xzr                                    
02d6cce8: bl      #0x2d98c98                                 DG.Tweening.ShortcutExtensions::DOScale
02d6ccec: ldr     x2, [x26]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d6ccf0: mov     w1, #0x1b                                  
02d6ccf4: bl      #0x336fa0c                                 fn_336fa0c
02d6ccf8: scvtf   s0, w21                                    
02d6ccfc: ldr     x1, [x27]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d6cd00: fmul    s0, s0, s9                                 
02d6cd04: bl      #0x336f7fc                                 fn_336f7fc
02d6cd08: ldr     x8, [x28]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d6cd0c: mov     x22, x0                                    
02d6cd10: ldr     w9, [x8, #0xe4]                            [10840e4]=2c2644327265746c f=4.54482e+30,2.36279e-12
02d6cd14: cbnz    w9, #0x2d6cd24                             
02d6cd18: mov     x0, x8                                     
02d6cd1c: bl      #0x2b70f30                                 fn_2b70f30
02d6cd20: ldr     x8, [x28]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d6cd24: ldr     x9, [x8, #0xb8]                            [10840b8]=2632726f74636556 f=7.20646e+31,6.19112e-16
02d6cd28: ldr     x23, [x9, #0x20]                           [1084020]=79654b7465533a3a f=6.23433e+22,7.44104e+34
02d6cd2c: cbnz    x23, #0x2d6cd8c                            
02d6cd30: ldr     w10, [x8, #0xe4]                           [10840e4]=2c2644327265746c f=4.54482e+30,2.36279e-12
02d6cd34: cbnz    w10, #0x2d6cd48                            
02d6cd38: mov     x0, x8                                     
02d6cd3c: bl      #0x2b70f30                                 fn_2b70f30
02d6cd40: ldr     x8, [x28]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d6cd44: ldr     x9, [x8, #0xb8]                            [10840b8]=2632726f74636556 f=7.20646e+31,6.19112e-16
02d6cd48: adrp    x8, #0x6264000                             
02d6cd4c: ldr     x24, [x9]                                  [1084000]=287475706e49646c f=1.5582e+28,1.35702e-14
02d6cd50: ldr     x8, [x8, #0xe8]                            T:DG.Tweening.TweenCallback
02d6cd54: ldr     x0, [x8]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d6cd58: bl      #0x2b7104c                                 fn_2b7104c
02d6cd5c: adrp    x8, #0x626c000                             
02d6cd60: mov     x1, x24                                    
02d6cd64: mov     x3, xzr                                    
02d6cd68: ldr     x8, [x8, #0x460]                           M:Clicker.KeycapMakerController/<>c::<SpawnKeycap>b__57_0
02d6cd6c: mov     x23, x0                                    
02d6cd70: ldr     x2, [x8]                                   M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d6cd74: bl      #0x2d89dc4                                 DG.Tweening.TweenCallback::.ctor
02d6cd78: ldr     x8, [x28]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d6cd7c: mov     x1, x23                                    
02d6cd80: ldr     x0, [x8, #0xb8]                            MS:System.Collections.Generic.List`1::Add
02d6cd84: str     x23, [x0, #0x20]!                          ._baseKeycapId
02d6cd88: bl      #0x2b70d54                                 fn_2b70d54
02d6cd8c: ldr     x2, [x29]                                  S:'didu'
02d6cd90: mov     x0, x22                                    
02d6cd94: mov     x1, x23                                    
02d6cd98: bl      #0x336f348                                 fn_336f348
02d6cd9c: ldr     x0, [x19, #0x90]                           ._keycapList
02d6cda0: add     w21, w21, #1                               
02d6cda4: cbnz    x0, #0x2d6cc28                             
02d6cda8: bl      #0x2b7105c                                 fn_2b7105c
02d6cdac: ldr     x0, [x19, #0xa0]                           ._baseKeycapObject
02d6cdb0: cbz     x0, #0x2d6cda8                             
02d6cdb4: ldr     x1, [x20, #0x18]                           
02d6cdb8: ldp     x20, x19, [sp, #0x60]                      
02d6cdbc: ldp     x22, x21, [sp, #0x50]                      
02d6cdc0: mov     w2, wzr                                    
02d6cdc4: ldp     x24, x23, [sp, #0x40]                      
02d6cdc8: ldp     x26, x25, [sp, #0x30]                      
02d6cdcc: ldp     x28, x27, [sp, #0x20]                      
02d6cdd0: ldp     x29, x30, [sp, #0x10]                      
02d6cdd4: ldp     d9, d8, [sp], #0x70                        
02d6cdd8: b       #0x2d5ea1c                                 Clicker.BaseKeycapObject::SetKeycap
02d6cddc: ldp     x20, x19, [sp, #0x60]                      
02d6cde0: ldp     x22, x21, [sp, #0x50]                      
02d6cde4: ldp     x24, x23, [sp, #0x40]                      
02d6cde8: ldp     x26, x25, [sp, #0x30]                      
02d6cdec: ldp     x28, x27, [sp, #0x20]                      
02d6cdf0: ldp     x29, x30, [sp, #0x10]                      
02d6cdf4: ldp     d9, d8, [sp], #0x70                        
02d6cdf8: ret                                                
## SetKeycapColor(int colorIndex) -> void
---- Clicker.KeycapMakerController::SetKeycapColor 0x2d6cdfc
02d6cdfc: stp     x30, x25, [sp, #-0x40]!                    
02d6ce00: stp     x24, x23, [sp, #0x10]                      
02d6ce04: stp     x22, x21, [sp, #0x20]                      
02d6ce08: stp     x20, x19, [sp, #0x30]                      
02d6ce0c: adrp    x21, #0x6630000                            
02d6ce10: mov     w19, w1                                    
02d6ce14: mov     x20, x0                                    
02d6ce18: ldrb    w8, [x21, #0x378]                          
02d6ce1c: tbnz    w8, #0, #0x2d6ce4c                         
02d6ce20: adrp    x0, #0x626b000                             
02d6ce24: ldr     x0, [x0, #0xe80]                           MS:System.Collections.Generic.List`1::get_Count
02d6ce28: bl      #0x2b70db0                                 fn_2b70db0
02d6ce2c: adrp    x0, #0x6266000                             
02d6ce30: ldr     x0, [x0, #0xc38]                           MS:System.Collections.Generic.List`1::get_Item
02d6ce34: bl      #0x2b70db0                                 fn_2b70db0
02d6ce38: adrp    x0, #0x626b000                             
02d6ce3c: ldr     x0, [x0, #0xe88]                           MS:System.Collections.Generic.List`1::get_Item
02d6ce40: bl      #0x2b70db0                                 fn_2b70db0
02d6ce44: mov     w8, #1                                     
02d6ce48: strb    w8, [x21, #0x378]                          
02d6ce4c: ldr     x0, [x20, #0x98]                           ._keycapConfig
02d6ce50: str     w19, [x20, #0x2c]                          ._keycapColorId
02d6ce54: cbz     x0, #0x2d6cee8                             
02d6ce58: ldr     w1, [x20, #0x28]                           ._keycapId
02d6ce5c: bl      #0x2d5b820                                 Clicker.KeycapConfig::GetData
02d6ce60: cbz     x0, #0x2d6cf28                             
02d6ce64: mov     x21, x0                                    
02d6ce68: ldr     x0, [x20, #0x90]                           ._keycapList
02d6ce6c: cbz     x0, #0x2d6cee8                             
02d6ce70: adrp    x25, #0x626b000                            
02d6ce74: adrp    x24, #0x6266000                            
02d6ce78: mov     w22, wzr                                   
02d6ce7c: ldr     x25, [x25, #0xe88]                         MS:System.Collections.Generic.List`1::get_Item
02d6ce80: ldr     x24, [x24, #0xc38]                         MS:System.Collections.Generic.List`1::get_Item
02d6ce84: ldr     w8, [x0, #0x18]                            T:type57265(k15)
02d6ce88: cmp     w22, w8                                    
02d6ce8c: b.ge    #0x2d6ceec                                 
02d6ce90: ldr     w8, [x20, #0x128]                          ._switchAmount
02d6ce94: cmp     w22, w8                                    
02d6ce98: b.ge    #0x2d6cee0                                 
02d6ce9c: ldr     x2, [x25]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d6cea0: mov     w1, w22                                    
02d6cea4: bl      #0x35a8f3c                                 fn_35a8f3c
02d6cea8: ldr     x8, [x21, #0x20]                           ._baseKeycapId
02d6ceac: cbz     x8, #0x2d6cee8                             
02d6ceb0: ldr     x2, [x24]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d6ceb4: mov     x23, x0                                    
02d6ceb8: mov     x0, x8                                     
02d6cebc: mov     w1, w19                                    
02d6cec0: bl      #0x35a8f3c                                 fn_35a8f3c
02d6cec4: cbz     x23, #0x2d6cee8                            
02d6cec8: mov     x1, x0                                     
02d6cecc: mov     x0, x23                                    
02d6ced0: mov     w2, wzr                                    
02d6ced4: mov     w3, #-1                                    
02d6ced8: bl      #0x2d5eac0                                 Clicker.KeycapObject::SetDecor
02d6cedc: ldr     x0, [x20, #0x90]                           ._keycapList
02d6cee0: add     w22, w22, #1                               
02d6cee4: cbnz    x0, #0x2d6ce84                             
02d6cee8: bl      #0x2b7105c                                 fn_2b7105c
02d6ceec: ldr     x0, [x21, #0x20]                           ._baseKeycapId
02d6cef0: cbz     x0, #0x2d6cee8                             
02d6cef4: ldr     x2, [x24]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d6cef8: ldr     x20, [x20, #0xa0]                          ._baseKeycapObject
02d6cefc: mov     w1, w19                                    
02d6cf00: bl      #0x35a8f3c                                 fn_35a8f3c
02d6cf04: cbz     x20, #0x2d6cee8                            
02d6cf08: mov     x1, x0                                     
02d6cf0c: mov     x0, x20                                    
02d6cf10: mov     w2, wzr                                    
02d6cf14: ldp     x20, x19, [sp, #0x30]                      
02d6cf18: ldp     x22, x21, [sp, #0x20]                      
02d6cf1c: ldp     x24, x23, [sp, #0x10]                      
02d6cf20: ldp     x30, x25, [sp], #0x40                      
02d6cf24: b       #0x2d5ea1c                                 Clicker.BaseKeycapObject::SetKeycap
02d6cf28: ldp     x20, x19, [sp, #0x30]                      
02d6cf2c: ldp     x22, x21, [sp, #0x20]                      
02d6cf30: ldp     x24, x23, [sp, #0x10]                      
02d6cf34: ldp     x30, x25, [sp], #0x40                      
02d6cf38: ret                                                
## SetKeycapDecor(int decorId, UnityEngine.Sprite sprite, Clicker.DecorKeycapType type) -> void
---- Clicker.KeycapMakerController::SetKeycapDecor 0x2d6a96c
02d6a96c: ldr     x8, [x0, #0xa0]                            ._baseKeycapObject
02d6a970: cbz     x8, #0x2d6a988                             
02d6a974: mov     w4, w3                                     
02d6a978: mov     x3, x2                                     
02d6a97c: mov     w2, w1                                     
02d6a980: ldr     w1, [x8, #0x90]                            
02d6a984: b       #0x2d6cf3c                                 Clicker.KeycapMakerController::SetKeycapIndexDecor
02d6a988: str     x30, [sp, #-0x10]!                         
02d6a98c: bl      #0x2b7105c                                 fn_2b7105c
## SetKeycapIndexDecor(int index, int decorId, UnityEngine.Sprite sprite, Clicker.DecorKeycapType type) -> void
---- Clicker.KeycapMakerController::SetKeycapIndexDecor 0x2d6cf3c
02d6cf3c: str     x30, [sp, #-0x40]!                         
02d6cf40: stp     x24, x23, [sp, #0x10]                      
02d6cf44: stp     x22, x21, [sp, #0x20]                      
02d6cf48: stp     x20, x19, [sp, #0x30]                      
02d6cf4c: adrp    x24, #0x6630000                            
02d6cf50: mov     w19, w4                                    
02d6cf54: mov     x21, x3                                    
02d6cf58: ldrb    w8, [x24, #0x379]                          
02d6cf5c: mov     w20, w2                                    
02d6cf60: mov     w22, w1                                    
02d6cf64: mov     x23, x0                                    
02d6cf68: tbnz    w8, #0, #0x2d6cf80                         
02d6cf6c: adrp    x0, #0x626b000                             
02d6cf70: ldr     x0, [x0, #0xe88]                           MS:System.Collections.Generic.List`1::get_Item
02d6cf74: bl      #0x2b70db0                                 fn_2b70db0
02d6cf78: mov     w8, #1                                     
02d6cf7c: strb    w8, [x24, #0x379]                          
02d6cf80: ldr     x0, [x23, #0x90]                           
02d6cf84: cbz     x0, #0x2d6cfdc                             
02d6cf88: adrp    x8, #0x626b000                             
02d6cf8c: mov     w1, w22                                    
02d6cf90: ldr     x8, [x8, #0xe88]                           MS:System.Collections.Generic.List`1::get_Item
02d6cf94: ldr     x2, [x8]                                   T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d6cf98: bl      #0x35a8f3c                                 fn_35a8f3c
02d6cf9c: cbz     x0, #0x2d6cfdc                             
02d6cfa0: mov     x1, x21                                    
02d6cfa4: mov     w2, w19                                    
02d6cfa8: mov     w3, w20                                    
02d6cfac: bl      #0x2d5eac0                                 Clicker.KeycapObject::SetDecor
02d6cfb0: ldr     x0, [x23, #0xa0]                           
02d6cfb4: cbz     x0, #0x2d6cfdc                             
02d6cfb8: mov     w1, w22                                    
02d6cfbc: mov     x2, x21                                    
02d6cfc0: mov     w3, w19                                    
02d6cfc4: mov     w4, w20                                    
02d6cfc8: ldp     x20, x19, [sp, #0x30]                      
02d6cfcc: ldp     x22, x21, [sp, #0x20]                      
02d6cfd0: ldp     x24, x23, [sp, #0x10]                      
02d6cfd4: ldr     x30, [sp], #0x40                           
02d6cfd8: b       #0x2d5ed04                                 Clicker.BaseKeycapObject::SetKeycapIndex
02d6cfdc: bl      #0x2b7105c                                 fn_2b7105c
## SpawnAssembleKeycap() -> void
---- Clicker.KeycapMakerController::SpawnAssembleKeycap 0x2d6cfe0
02d6cfe0: stp     x30, x23, [sp, #-0x30]!                    
02d6cfe4: stp     x22, x21, [sp, #0x10]                      
02d6cfe8: stp     x20, x19, [sp, #0x20]                      
02d6cfec: adrp    x20, #0x6630000                            
02d6cff0: mov     x19, x0                                    
02d6cff4: ldrb    w8, [x20, #0x37a]                          
02d6cff8: tbnz    w8, #0, #0x2d6d01c                         
02d6cffc: adrp    x0, #0x626c000                             
02d6d000: ldr     x0, [x0, #0x260]                           MS:UnityEngine.Object::Instantiate
02d6d004: bl      #0x2b70db0                                 fn_2b70db0
02d6d008: adrp    x0, #0x6263000                             
02d6d00c: ldr     x0, [x0, #0x918]                           T:UnityEngine.Object
02d6d010: bl      #0x2b70db0                                 fn_2b70db0
02d6d014: mov     w8, #1                                     
02d6d018: strb    w8, [x20, #0x37a]                          
02d6d01c: ldr     x0, [x19, #0x60]                           ._baseKeycapConfig
02d6d020: cbz     x0, #0x2d6d190                             
02d6d024: ldr     w1, [x19, #0x20]                           ._baseKeycapId
02d6d028: bl      #0x2d5b300                                 Clicker.BaseKeycapConfig::GetData
02d6d02c: cbz     x0, #0x2d6d064                             
02d6d030: adrp    x23, #0x6263000                            
02d6d034: mov     x21, x0                                    
02d6d038: ldr     x23, [x23, #0x918]                         T:UnityEngine.Object
02d6d03c: ldr     x20, [x21, #0x40]                          ._srTray
02d6d040: ldr     x0, [x23]                                  &2c5bbd4(=a9bd7bfdd503233f)
02d6d044: ldr     w8, [x0, #0xe4]                            [62630e4]=0 f=0,0
02d6d048: cbnz    w8, #0x2d6d050                             
02d6d04c: bl      #0x2b70f30                                 fn_2b70f30
02d6d050: mov     x0, x20                                    
02d6d054: mov     x1, xzr                                    
02d6d058: mov     x2, xzr                                    
02d6d05c: bl      #0x5b37d84                                 UnityEngine.Object::op_Equality
02d6d060: tbz     w0, #0, #0x2d6d074                         
02d6d064: ldp     x20, x19, [sp, #0x20]                      
02d6d068: ldp     x22, x21, [sp, #0x10]                      
02d6d06c: ldp     x30, x23, [sp], #0x30                      
02d6d070: ret                                                
02d6d074: ldr     x0, [x23]                                  &2c5bbd4(=a9bd7bfdd503233f)
02d6d078: mov     x20, x19                                   
02d6d07c: ldr     x22, [x20, #0xa0]!                         ._baseKeycapObject
02d6d080: ldr     w8, [x0, #0xe4]                            [62630e4]=0 f=0,0
02d6d084: cbnz    w8, #0x2d6d08c                             
02d6d088: bl      #0x2b70f30                                 fn_2b70f30
02d6d08c: mov     x0, x22                                    
02d6d090: mov     x1, xzr                                    
02d6d094: mov     x2, xzr                                    
02d6d098: bl      #0x5b3666c                                 UnityEngine.Object::op_Inequality
02d6d09c: tbz     w0, #0, #0x2d6d0d4                         
02d6d0a0: ldr     x0, [x20]                                  
02d6d0a4: cbz     x0, #0x2d6d190                             
02d6d0a8: mov     x1, xzr                                    
02d6d0ac: bl      #0x5b339ec                                 UnityEngine.Component::get_gameObject
02d6d0b0: ldr     x8, [x23]                                  &2c5bbd4(=a9bd7bfdd503233f)
02d6d0b4: mov     x22, x0                                    
02d6d0b8: ldr     w9, [x8, #0xe4]                            
02d6d0bc: cbnz    w9, #0x2d6d0c8                             
02d6d0c0: mov     x0, x8                                     
02d6d0c4: bl      #0x2b70f30                                 fn_2b70f30
02d6d0c8: mov     x0, x22                                    
02d6d0cc: mov     x1, xzr                                    
02d6d0d0: bl      #0x5b3ca38                                 UnityEngine.Object::Destroy
02d6d0d4: ldr     x0, [x23]                                  &2c5bbd4(=a9bd7bfdd503233f)
02d6d0d8: ldr     x21, [x21, #0x40]                          ._srTray
02d6d0dc: ldr     x22, [x19, #0xa8]                          ._tfBaseKeycapHolder
02d6d0e0: ldr     w8, [x0, #0xe4]                            [62630e4]=0 f=0,0
02d6d0e4: cbnz    w8, #0x2d6d0ec                             
02d6d0e8: bl      #0x2b70f30                                 fn_2b70f30
02d6d0ec: adrp    x8, #0x626c000                             
02d6d0f0: mov     x0, x21                                    
02d6d0f4: mov     x1, x22                                    
02d6d0f8: ldr     x8, [x8, #0x260]                           MS:UnityEngine.Object::Instantiate
02d6d0fc: ldr     x2, [x8]                                   M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d6d100: bl      #0x3275fcc                                 fn_3275fcc
02d6d104: mov     x1, x0                                     
02d6d108: str     x0, [x20]                                  
02d6d10c: mov     x0, x20                                    
02d6d110: bl      #0x2b70d54                                 fn_2b70d54
02d6d114: ldr     x0, [x20]                                  
02d6d118: cbz     x0, #0x2d6d190                             
02d6d11c: mov     x1, xzr                                    
02d6d120: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02d6d124: adrp    x22, #0x662f000                            
02d6d128: mov     x21, x0                                    
02d6d12c: ldrb    w8, [x22, #0x91a]                          
02d6d130: cbnz    w8, #0x2d6d148                             
02d6d134: adrp    x0, #0x6264000                             
02d6d138: ldr     x0, [x0, #0xd8]                            T:UnityEngine.Vector3 ._bgWall
02d6d13c: bl      #0x2b70db0                                 fn_2b70db0
02d6d140: mov     w8, #1                                     
02d6d144: strb    w8, [x22, #0x91a]                          
02d6d148: cbz     x21, #0x2d6d190                            
02d6d14c: adrp    x8, #0x6264000                             
02d6d150: mov     x0, x21                                    
02d6d154: mov     x1, xzr                                    
02d6d158: ldr     x8, [x8, #0xd8]                            T:UnityEngine.Vector3
02d6d15c: ldr     x8, [x8]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d6d160: ldr     x8, [x8, #0xb8]                            MS:DG.Tweening.Core.Extensions::SetSpecialStartupMode
02d6d164: ldp     s1, s2, [x8, #4]                           
02d6d168: ldr     s0, [x8]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d6d16c: bl      #0x5b45cec                                 UnityEngine.Transform::set_localPosition
02d6d170: ldr     x0, [x19, #0xc8]                           ._dragManager
02d6d174: cbz     x0, #0x2d6d190                             
02d6d178: ldr     x1, [x20]                                  
02d6d17c: ldp     x20, x19, [sp, #0x20]                      
02d6d180: ldp     x22, x21, [sp, #0x10]                      
02d6d184: str     x1, [x0, #0x78]!                           ._printerMachine
02d6d188: ldp     x30, x23, [sp], #0x30                      
02d6d18c: b       #0x2b70d54                                 
02d6d190: bl      #0x2b7105c                                 fn_2b7105c
## ShowStepDecorKeycap() -> void
---- Clicker.KeycapMakerController::ShowStepDecorKeycap 0x2d6d194
02d6d194: stp     x30, x19, [sp, #-0x10]!                    
02d6d198: mov     x19, x0                                    
02d6d19c: ldr     x0, [x0, #0x38]                            ._goTray
02d6d1a0: cbz     x0, #0x2d6d1e8                             
02d6d1a4: mov     w1, wzr                                    
02d6d1a8: mov     x2, xzr                                    
02d6d1ac: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d6d1b0: ldr     x0, [x19, #0xa0]                           ._baseKeycapObject
02d6d1b4: cbz     x0, #0x2d6d1e8                             
02d6d1b8: bl      #0x2d5e500                                 Clicker.BaseKeycapObject::ShowKeycapsOnly
02d6d1bc: ldr     x0, [x19, #0xa0]                           ._baseKeycapObject
02d6d1c0: cbz     x0, #0x2d6d1e8                             
02d6d1c4: mov     w1, #1                                     
02d6d1c8: bl      #0x2d5cae8                                 Clicker.BaseKeycapObject::TurnModeSetup
02d6d1cc: ldr     x0, [x19, #0xa0]                           ._baseKeycapObject
02d6d1d0: cbz     x0, #0x2d6d1e8                             
02d6d1d4: mov     w1, wzr                                    
02d6d1d8: bl      #0x2d5f278                                 Clicker.BaseKeycapObject::OnSetupKeycap
02d6d1dc: mov     x0, x19                                    
02d6d1e0: ldp     x30, x19, [sp], #0x10                      
02d6d1e4: b       #0x2d6c448                                 Clicker.KeycapMakerController::ShowTableBG
02d6d1e8: bl      #0x2b7105c                                 fn_2b7105c
## JumpToNextKeycap() -> void
---- Clicker.KeycapMakerController::JumpToNextKeycap 0x2d6a990
02d6a990: ldr     x0, [x0, #0xa0]                            ._baseKeycapObject
02d6a994: cbz     x0, #0x2d6a99c                             
02d6a998: b       #0x2d5f3ec                                 Clicker.BaseKeycapObject::JumpToNextKeycap
02d6a99c: str     x30, [sp, #-0x10]!                         
02d6a9a0: bl      #0x2b7105c                                 fn_2b7105c
## ShowSelectKeychain() -> void
---- Clicker.KeycapMakerController::ShowSelectKeychain 0x2d6a600
02d6a600: stp     x30, x21, [sp, #-0x20]!                    
02d6a604: stp     x20, x19, [sp, #0x10]                      
02d6a608: mov     x19, x0                                    
02d6a60c: ldr     x0, [x0, #0xb0]                            ._tfHighlight
02d6a610: mov     w1, wzr                                    
02d6a614: mov     x2, xzr                                    
02d6a618: bl      #0x2d9d5d0                                 DG.Tweening.ShortcutExtensions::DOKill
02d6a61c: adrp    x21, #0x662f000                            
02d6a620: ldr     x20, [x19, #0xb0]                          ._tfHighlight
02d6a624: ldrb    w8, [x21, #0x91a]                          
02d6a628: cbnz    w8, #0x2d6a640                             
02d6a62c: adrp    x0, #0x6264000                             
02d6a630: ldr     x0, [x0, #0xd8]                            T:UnityEngine.Vector3 ._bgWall
02d6a634: bl      #0x2b70db0                                 fn_2b70db0
02d6a638: mov     w8, #1                                     
02d6a63c: strb    w8, [x21, #0x91a]                          
02d6a640: cbz     x20, #0x2d6a6b8                            
02d6a644: adrp    x8, #0x6264000                             
02d6a648: mov     x0, x20                                    
02d6a64c: mov     x1, xzr                                    
02d6a650: ldr     x8, [x8, #0xd8]                            T:UnityEngine.Vector3
02d6a654: ldr     x8, [x8]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d6a658: ldr     x8, [x8, #0xb8]                            MS:DG.Tweening.Core.Extensions::SetSpecialStartupMode
02d6a65c: ldp     s1, s2, [x8, #4]                           
02d6a660: ldr     s0, [x8]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d6a664: bl      #0x5b470cc                                 UnityEngine.Transform::set_localScale
02d6a668: ldr     x0, [x19, #0x38]                           ._goTray
02d6a66c: cbz     x0, #0x2d6a6b8                             
02d6a670: mov     w1, #1                                     
02d6a674: mov     x2, xzr                                    
02d6a678: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d6a67c: ldr     x0, [x19, #0xa0]                           ._baseKeycapObject
02d6a680: cbz     x0, #0x2d6a6b8                             
02d6a684: bl      #0x2d5e74c                                 Clicker.BaseKeycapObject::HideKeycaps
02d6a688: ldr     x0, [x19, #0xb0]                           ._tfHighlight
02d6a68c: cbz     x0, #0x2d6a6b8                             
02d6a690: mov     x1, xzr                                    
02d6a694: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02d6a698: movi    d0, #0000000000000000                      
02d6a69c: movi    d1, #0000000000000000                      
02d6a6a0: mov     x1, xzr                                    
02d6a6a4: bl      #0x2d98c98                                 DG.Tweening.ShortcutExtensions::DOScale
02d6a6a8: mov     x0, x19                                    
02d6a6ac: ldp     x20, x19, [sp, #0x10]                      
02d6a6b0: ldp     x30, x21, [sp], #0x20                      
02d6a6b4: b       #0x2d6c770                                 Clicker.KeycapMakerController::ShowWallBG
02d6a6b8: bl      #0x2b7105c                                 fn_2b7105c
## SetKeychain(int id) -> void
---- Clicker.KeycapMakerController::SetKeychain 0x2d6d1ec
02d6d1ec: str     x30, [sp, #-0x30]!                         
02d6d1f0: stp     x22, x21, [sp, #0x10]                      
02d6d1f4: stp     x20, x19, [sp, #0x20]                      
02d6d1f8: adrp    x20, #0x6630000                            
02d6d1fc: mov     w21, w1                                    
02d6d200: mov     x19, x0                                    
02d6d204: ldrb    w8, [x20, #0x37b]                          
02d6d208: tbnz    w8, #0, #0x2d6d220                         
02d6d20c: adrp    x0, #0x6263000                             
02d6d210: ldr     x0, [x0, #0x918]                           T:UnityEngine.Object
02d6d214: bl      #0x2b70db0                                 fn_2b70db0
02d6d218: mov     w8, #1                                     
02d6d21c: strb    w8, [x20, #0x37b]                          
02d6d220: ldr     x0, [x19, #0xb8]                           ._keychainConfig
02d6d224: cbz     x0, #0x2d6d2b0                             
02d6d228: mov     w1, w21                                    
02d6d22c: bl      #0x2d5ba88                                 Clicker.KeychainConfig::GetData
02d6d230: cbz     x0, #0x2d6d2a0                             
02d6d234: adrp    x22, #0x6263000                            
02d6d238: mov     x20, x0                                    
02d6d23c: ldr     x22, [x22, #0x918]                         T:UnityEngine.Object
02d6d240: ldr     x1, [x0, #0x18]                            &2c5d934(=d65f03c0d503245f)
02d6d244: mov     x0, x19                                    
02d6d248: str     w21, [x19, #0x30]                          ._keychainId
02d6d24c: bl      #0x2d6d2b4                                 Clicker.KeycapMakerController::ChangeKeychainPreview
02d6d250: ldr     x0, [x22]                                  &2c5bbd4(=a9bd7bfdd503233f)
02d6d254: ldr     x21, [x19, #0xa0]                          ._baseKeycapObject
02d6d258: ldr     w8, [x0, #0xe4]                            [62630e4]=0 f=0,0
02d6d25c: cbnz    w8, #0x2d6d264                             
02d6d260: bl      #0x2b70f30                                 fn_2b70f30
02d6d264: mov     x0, x21                                    
02d6d268: mov     x1, xzr                                    
02d6d26c: mov     x2, xzr                                    
02d6d270: bl      #0x5b3666c                                 UnityEngine.Object::op_Inequality
02d6d274: tbz     w0, #0, #0x2d6d2a0                         
02d6d278: ldr     x8, [x19, #0xa0]                           ._baseKeycapObject
02d6d27c: cbz     x8, #0x2d6d2b0                             
02d6d280: ldr     x0, [x8, #0x78]                            
02d6d284: cbz     x0, #0x2d6d2b0                             
02d6d288: ldr     x1, [x20, #0x20]                           ._baseKeycapId
02d6d28c: ldp     x20, x19, [sp, #0x20]                      
02d6d290: ldp     x22, x21, [sp, #0x10]                      
02d6d294: mov     x2, xzr                                    
02d6d298: ldr     x30, [sp], #0x30                           
02d6d29c: b       #0x5ae6dcc                                 UnityEngine.SpriteRenderer::set_sprite
02d6d2a0: ldp     x20, x19, [sp, #0x20]                      
02d6d2a4: ldp     x22, x21, [sp, #0x10]                      
02d6d2a8: ldr     x30, [sp], #0x30                           
02d6d2ac: ret                                                
02d6d2b0: bl      #0x2b7105c                                 fn_2b7105c
## ChangeKeychainPreview(UnityEngine.Sprite spriteNew) -> void
---- Clicker.KeycapMakerController::ChangeKeychainPreview 0x2d6d2b4
02d6d2b4: str     x30, [sp, #-0x30]!                         
02d6d2b8: stp     x22, x21, [sp, #0x10]                      
02d6d2bc: stp     x20, x19, [sp, #0x20]                      
02d6d2c0: adrp    x19, #0x6630000                            
02d6d2c4: adrp    x22, #0x626c000                            
02d6d2c8: mov     x21, x1                                    
02d6d2cc: ldrb    w8, [x19, #0x37c]                          
02d6d2d0: ldr     x22, [x22, #0x468]                         T:Clicker.KeycapMakerController/<>c__DisplayClass66_0
02d6d2d4: mov     x20, x0                                    
02d6d2d8: tbnz    w8, #0, #0x2d6d314                         
02d6d2dc: adrp    x0, #0x6264000                             
02d6d2e0: ldr     x0, [x0, #0xe8]                            T:DG.Tweening.TweenCallback ._pointerHandTutorial
02d6d2e4: bl      #0x2b70db0                                 fn_2b70db0
02d6d2e8: adrp    x0, #0x6266000                             
02d6d2ec: ldr     x0, [x0, #0x928]                           MS:DG.Tweening.TweenSettingsExtensions::OnComplete
02d6d2f0: bl      #0x2b70db0                                 fn_2b70db0
02d6d2f4: adrp    x0, #0x626c000                             
02d6d2f8: ldr     x0, [x0, #0x470]                           M:Clicker.KeycapMakerController/<>c__DisplayClass66_0::<ChangeKeychainPreview>b__0
02d6d2fc: bl      #0x2b70db0                                 fn_2b70db0
02d6d300: adrp    x0, #0x626c000                             
02d6d304: ldr     x0, [x0, #0x468]                           T:Clicker.KeycapMakerController/<>c__DisplayClass66_0
02d6d308: bl      #0x2b70db0                                 fn_2b70db0
02d6d30c: mov     w8, #1                                     
02d6d310: strb    w8, [x19, #0x37c]                          
02d6d314: ldr     x0, [x22]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d6d318: bl      #0x2b7104c                                 fn_2b7104c
02d6d31c: mov     x1, xzr                                    
02d6d320: mov     x19, x0                                    
02d6d324: bl      #0x2d6e540                                 Clicker.KeycapMakerController/<>c__DisplayClass66_0::.ctor
02d6d328: cbz     x19, #0x2d6d3e4                            
02d6d32c: mov     x0, x19                                    
02d6d330: mov     x1, x20                                    
02d6d334: str     x20, [x0, #0x10]!                          
02d6d338: bl      #0x2b70d54                                 fn_2b70d54
02d6d33c: mov     x0, x19                                    
02d6d340: mov     x1, x21                                    
02d6d344: str     x21, [x0, #0x18]!                          
02d6d348: bl      #0x2b70d54                                 fn_2b70d54
02d6d34c: ldr     x0, [x20, #0xc0]                           ._srKeychain
02d6d350: cbz     x0, #0x2d6d3e4                             
02d6d354: mov     x1, xzr                                    
02d6d358: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02d6d35c: mov     w1, wzr                                    
02d6d360: mov     x2, xzr                                    
02d6d364: bl      #0x2d9d5d0                                 DG.Tweening.ShortcutExtensions::DOKill
02d6d368: ldr     x0, [x20, #0xc0]                           ._srKeychain
02d6d36c: cbz     x0, #0x2d6d3e4                             
02d6d370: adrp    x20, #0x6264000                            
02d6d374: adrp    x21, #0x626c000                            
02d6d378: adrp    x22, #0x6266000                            
02d6d37c: ldr     x20, [x20, #0xe8]                          T:DG.Tweening.TweenCallback ._pointerHandTutorial
02d6d380: ldr     x21, [x21, #0x470]                         M:Clicker.KeycapMakerController/<>c__DisplayClass66_0::<ChangeKeychainPreview>b__0
02d6d384: ldr     x22, [x22, #0x928]                         MS:DG.Tweening.TweenSettingsExtensions::OnComplete
02d6d388: mov     x1, xzr                                    
02d6d38c: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02d6d390: movi    d0, #0000000000000000                      
02d6d394: adrp    x8, #0x1084000                             
02d6d398: mov     x1, xzr                                    
02d6d39c: ldr     s1, [x8, #0xeec]                           [1084eec]=457ff0003dcccccd f=0.1,4095
02d6d3a0: bl      #0x2d98c98                                 DG.Tweening.ShortcutExtensions::DOScale
02d6d3a4: ldr     x8, [x20]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d6d3a8: mov     x20, x0                                    
02d6d3ac: mov     x0, x8                                     
02d6d3b0: bl      #0x2b7104c                                 fn_2b7104c
02d6d3b4: ldr     x2, [x21]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d6d3b8: mov     x1, x19                                    
02d6d3bc: mov     x3, xzr                                    
02d6d3c0: mov     x21, x0                                    
02d6d3c4: bl      #0x2d89dc4                                 DG.Tweening.TweenCallback::.ctor
02d6d3c8: ldr     x2, [x22]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d6d3cc: mov     x0, x20                                    
02d6d3d0: mov     x1, x21                                    
02d6d3d4: ldp     x20, x19, [sp, #0x20]                      
02d6d3d8: ldp     x22, x21, [sp, #0x10]                      
02d6d3dc: ldr     x30, [sp], #0x30                           
02d6d3e0: b       #0x336f26c                                 
02d6d3e4: bl      #0x2b7105c                                 fn_2b7105c
## ShowResult() -> void
---- Clicker.KeycapMakerController::ShowResult 0x2d600f0
02d600f0: str     d8, [sp, #-0x50]!                          
02d600f4: stp     x30, x25, [sp, #0x10]                      
02d600f8: stp     x24, x23, [sp, #0x20]                      
02d600fc: stp     x22, x21, [sp, #0x30]                      
02d60100: stp     x20, x19, [sp, #0x40]                      
02d60104: adrp    x20, #0x6630000                            
02d60108: adrp    x21, #0x6266000                            
02d6010c: mov     x19, x0                                    
02d60110: ldrb    w8, [x20, #0x37d]                          
02d60114: ldr     x21, [x21, #0x658]                         MS:MonoSingleton`1::get_Instance
02d60118: tbnz    w8, #0, #0x2d601a8                         
02d6011c: adrp    x0, #0x6266000                             
02d60120: ldr     x0, [x0, #0x750]                           MS:DataManager::GetData
02d60124: bl      #0x2b70db0                                 fn_2b70db0
02d60128: adrp    x0, #0x6265000                             
02d6012c: ldr     x0, [x0, #0xb38]                           T:DevTrack
02d60130: bl      #0x2b70db0                                 fn_2b70db0
02d60134: adrp    x0, #0x626b000                             
02d60138: ldr     x0, [x0, #0xf00]                           M:Clicker.KeycapMakerController::<ShowResult>b__67_0
02d6013c: bl      #0x2b70db0                                 fn_2b70db0
02d60140: adrp    x0, #0x6267000                             
02d60144: ldr     x0, [x0, #0xbd0]                           MS:MonoSingleton`1::get_Instance
02d60148: bl      #0x2b70db0                                 fn_2b70db0
02d6014c: adrp    x0, #0x6266000                             
02d60150: ldr     x0, [x0, #0x658]                           MS:MonoSingleton`1::get_Instance
02d60154: bl      #0x2b70db0                                 fn_2b70db0
02d60158: adrp    x0, #0x6266000                             
02d6015c: ldr     x0, [x0, #0xb48]                           MS:MonoSingleton`1::get_Instance
02d60160: bl      #0x2b70db0                                 fn_2b70db0
02d60164: adrp    x0, #0x6264000                             
02d60168: ldr     x0, [x0, #0xe8]                            T:DG.Tweening.TweenCallback ._pointerHandTutorial
02d6016c: bl      #0x2b70db0                                 fn_2b70db0
02d60170: adrp    x0, #0x6266000                             
02d60174: ldr     x0, [x0, #0x928]                           MS:DG.Tweening.TweenSettingsExtensions::OnComplete
02d60178: bl      #0x2b70db0                                 fn_2b70db0
02d6017c: adrp    x0, #0x626b000                             
02d60180: ldr     x0, [x0, #0xf08]                           MS:DG.Tweening.TweenSettingsExtensions::SetEase
02d60184: bl      #0x2b70db0                                 fn_2b70db0
02d60188: adrp    x0, #0x6266000                             
02d6018c: ldr     x0, [x0, #0x880]                           MS:DG.Tweening.TweenSettingsExtensions::SetEase
02d60190: bl      #0x2b70db0                                 fn_2b70db0
02d60194: adrp    x0, #0x626b000                             
02d60198: ldr     x0, [x0, #0xf10]                           MS:UIManager::HideScreen
02d6019c: bl      #0x2b70db0                                 fn_2b70db0
02d601a0: mov     w8, #1                                     
02d601a4: strb    w8, [x20, #0x37d]                          
02d601a8: ldr     x0, [x21]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d601ac: bl      #0x3769600                                 fn_3769600
02d601b0: cbz     x0, #0x2d6046c                             
02d601b4: adrp    x8, #0x6266000                             
02d601b8: ldr     x8, [x8, #0x750]                           MS:DataManager::GetData
02d601bc: ldr     x1, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d601c0: bl      #0x3168dd0                                 fn_3168dd0
02d601c4: cbz     x0, #0x2d6046c                             
02d601c8: ldr     x8, [x0, #0x20]                            M:ScoopGame.CategoryAsset/<>c__DisplayClass4_0::<GetOptionDataByID>b__0 ._baseKeycapId
02d601cc: cbz     x8, #0x2d6046c                             
02d601d0: adrp    x24, #0x6265000                            
02d601d4: adrp    x25, #0x6266000                            
02d601d8: ldr     x24, [x24, #0xb38]                         T:DevTrack
02d601dc: ldrb    w8, [x8, #0x3a]                            
02d601e0: ldr     x25, [x25, #0xb48]                         MS:MonoSingleton`1::get_Instance
02d601e4: cbz     w8, #0x2d60214                             
02d601e8: ldr     x0, [x24]                                  M:AdsManager::<OnApplicationPause>b__26_0
02d601ec: ldr     w8, [x0, #0xe4]                            [626b0e4]=0 f=0,0
02d601f0: cbnz    w8, #0x2d601fc                             
02d601f4: bl      #0x2b70f30                                 fn_2b70f30
02d601f8: ldr     x0, [x24]                                  M:AdsManager::<OnApplicationPause>b__26_0
02d601fc: ldr     x8, [x0, #0xb8]                            S:'scoop_no_thank' ._keychainConfig
02d60200: mov     x3, xzr                                    
02d60204: ldr     x0, [x8, #0x1f8]                           MS:System.Collections.Generic.List`1/Enumerator::get_Current
02d60208: ldr     x1, [x8, #0x250]                           S:"' has an empty productId – skipped."
02d6020c: ldr     w2, [x8, #0x28c]                           [626628c]=0 f=0,0
02d60210: bl      #0x2c9c1e0                                 DevTrack::OnboardingStep
02d60214: ldr     x0, [x25]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d60218: bl      #0x3769600                                 fn_3769600
02d6021c: cbz     x0, #0x2d6046c                             
02d60220: ldr     x20, [x0, #0x30]                           MS:System.Collections.Generic.List`1::IndexOf ._keychainId
02d60224: ldr     x0, [x25]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d60228: bl      #0x3769600                                 fn_3769600
02d6022c: cbz     x0, #0x2d6046c                             
02d60230: mov     x8, x0                                     
02d60234: ldr     x0, [x24]                                  M:AdsManager::<OnApplicationPause>b__26_0
02d60238: ldr     w21, [x8, #0x3c]                           [626603c]=0 f=0,0
02d6023c: ldr     w9, [x0, #0xe4]                            [626b0e4]=0 f=0,0
02d60240: cbnz    w9, #0x2d6024c                             
02d60244: bl      #0x2b70f30                                 fn_2b70f30
02d60248: ldr     x0, [x24]                                  M:AdsManager::<OnApplicationPause>b__26_0
02d6024c: ldr     x8, [x0, #0xb8]                            S:'scoop_no_thank' ._keychainConfig
02d60250: mov     x0, xzr                                    
02d60254: ldr     x22, [x8, #0x250]                          S:"' has an empty productId – skipped."
02d60258: ldr     w23, [x8, #0x28c]                          [626628c]=0 f=0,0
02d6025c: bl      #0x5b432fc                                 UnityEngine.Time::get_time
02d60260: ldr     x0, [x25]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d60264: fmov    s8, s0                                     
02d60268: bl      #0x3769600                                 fn_3769600
02d6026c: cbz     x0, #0x2d6046c                             
02d60270: ldr     s0, [x0, #0x38]                            MS:UnityEngine.Component::GetComponent ._goTray
02d60274: mov     x0, x20                                    
02d60278: mov     w1, w21                                    
02d6027c: mov     x2, x22                                    
02d60280: mov     w3, w23                                    
02d60284: mov     x4, xzr                                    
02d60288: fsub    s0, s8, s0                                 
02d6028c: bl      #0x2c9c898                                 DevTrack::GameModeStepComplete
02d60290: ldr     x0, [x25]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d60294: bl      #0x3769600                                 fn_3769600
02d60298: cbz     x0, #0x2d6046c                             
02d6029c: ldr     x20, [x0, #0x30]                           MS:System.Collections.Generic.List`1::IndexOf ._keychainId
02d602a0: ldr     x0, [x25]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d602a4: bl      #0x3769600                                 fn_3769600
02d602a8: cbz     x0, #0x2d6046c                             
02d602ac: ldr     x8, [x24]                                  M:AdsManager::<OnApplicationPause>b__26_0
02d602b0: ldr     w1, [x0, #0x3c]                            [626b03c]=0 f=0,0
02d602b4: mov     x0, x20                                    
02d602b8: mov     x4, xzr                                    
02d602bc: ldr     x8, [x8, #0xb8]                            S:'banner_native_refresh_time'
02d602c0: ldr     x2, [x8, #0x258]                           MS:System.Collections.Generic.List`1/Enumerator::Dispose
02d602c4: ldr     w3, [x8, #0x290]                           S:'{0} products fetched from store.'
02d602c8: bl      #0x2c9c714                                 DevTrack::GameModeStepEnter
02d602cc: ldr     x0, [x25]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d602d0: bl      #0x3769600                                 fn_3769600
02d602d4: cbz     x0, #0x2d6046c                             
02d602d8: ldr     x8, [x24]                                  M:AdsManager::<OnApplicationPause>b__26_0
02d602dc: ldr     x8, [x8, #0xb8]                            S:'banner_native_refresh_time'
02d602e0: ldr     x1, [x8, #0x258]                           MS:System.Collections.Generic.List`1/Enumerator::Dispose
02d602e4: str     x1, [x0, #0x40]!                           ._srTray
02d602e8: bl      #0x2b70d54                                 fn_2b70d54
02d602ec: ldr     x0, [x19, #0x38]                           ._goTray
02d602f0: cbz     x0, #0x2d6046c                             
02d602f4: mov     w1, wzr                                    
02d602f8: mov     x2, xzr                                    
02d602fc: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d60300: ldr     x0, [x19, #0x88]                           ._switchConfig
02d60304: cbz     x0, #0x2d6046c                             
02d60308: ldr     w1, [x19, #0x24]                           ._switchId
02d6030c: bl      #0x2d5bd98                                 Clicker.SwitchConfig::GetData
02d60310: cbz     x0, #0x2d60324                             
02d60314: ldr     x8, [x19, #0xa0]                           ._baseKeycapObject
02d60318: cbz     x8, #0x2d6046c                             
02d6031c: ldur    q0, [x0, #0x28]                            ._keycapId
02d60320: str     q0, [x8, #0x50]                            
02d60324: ldr     x0, [x19, #0xa0]                           ._baseKeycapObject
02d60328: cbz     x0, #0x2d6046c                             
02d6032c: bl      #0x2d60ba4                                 Clicker.BaseKeycapObject::ApplyGlowColor
02d60330: ldr     x0, [x19, #0xa0]                           ._baseKeycapObject
02d60334: cbz     x0, #0x2d6046c                             
02d60338: adrp    x20, #0x6267000                            
02d6033c: ldr     x20, [x20, #0xbd0]                         MS:MonoSingleton`1::get_Instance
02d60340: bl      #0x2d60c48                                 Clicker.BaseKeycapObject::UpdateGlowSprite
02d60344: ldr     x0, [x20]                                  S:'didu'
02d60348: bl      #0x3769600                                 fn_3769600
02d6034c: cbz     x0, #0x2d6046c                             
02d60350: adrp    x8, #0x626b000                             
02d60354: ldr     x8, [x8, #0xf10]                           MS:UIManager::HideScreen
02d60358: ldr     x1, [x8]                                   T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d6035c: bl      #0x33fbe70                                 fn_33fbe70
02d60360: ldr     x0, [x19, #0xa0]                           ._baseKeycapObject
02d60364: cbz     x0, #0x2d6046c                             
02d60368: mov     w1, #1                                     
02d6036c: bl      #0x2d60978                                 Clicker.BaseKeycapObject::RotateKeychain
02d60370: ldr     x0, [x19, #0xa0]                           ._baseKeycapObject
02d60374: cbz     x0, #0x2d6046c                             
02d60378: mov     x1, xzr                                    
02d6037c: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02d60380: ldr     x8, [x19, #0xf8]                           ._tfFinalPose
02d60384: cbz     x8, #0x2d6046c                             
02d60388: adrp    x21, #0x626b000                            
02d6038c: mov     x20, x0                                    
02d60390: mov     x0, x8                                     
02d60394: ldr     x21, [x21, #0xf08]                         MS:DG.Tweening.TweenSettingsExtensions::SetEase
02d60398: mov     x1, xzr                                    
02d6039c: bl      #0x5b46a30                                 UnityEngine.Transform::get_rotation
02d603a0: fmov    s4, #0.50000000                            
02d603a4: mov     x0, x20                                    
02d603a8: mov     x1, xzr                                    
02d603ac: bl      #0x2d9857c                                 DG.Tweening.ShortcutExtensions::DORotateQuaternion
02d603b0: ldr     x2, [x21]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d603b4: mov     w1, #4                                     
02d603b8: bl      #0x336fa0c                                 fn_336fa0c
02d603bc: ldr     x0, [x19, #0xa0]                           ._baseKeycapObject
02d603c0: cbz     x0, #0x2d6046c                             
02d603c4: mov     x1, xzr                                    
02d603c8: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02d603cc: ldr     x8, [x19, #0xf8]                           ._tfFinalPose
02d603d0: cbz     x8, #0x2d6046c                             
02d603d4: adrp    x21, #0x6266000                            
02d603d8: adrp    x22, #0x6264000                            
02d603dc: adrp    x23, #0x626b000                            
02d603e0: adrp    x24, #0x6266000                            
02d603e4: mov     x20, x0                                    
02d603e8: ldr     x21, [x21, #0x880]                         MS:DG.Tweening.TweenSettingsExtensions::SetEase
02d603ec: ldr     x22, [x22, #0xe8]                          T:DG.Tweening.TweenCallback
02d603f0: ldr     x23, [x23, #0xf00]                         M:Clicker.KeycapMakerController::<ShowResult>b__67_0
02d603f4: ldr     x24, [x24, #0x928]                         MS:DG.Tweening.TweenSettingsExtensions::OnComplete
02d603f8: mov     x0, x8                                     
02d603fc: mov     x1, xzr                                    
02d60400: bl      #0x5b467ac                                 UnityEngine.Transform::get_position
02d60404: fmov    s3, #0.50000000                            
02d60408: mov     x0, x20                                    
02d6040c: mov     w1, wzr                                    
02d60410: mov     x2, xzr                                    
02d60414: bl      #0x2d975e4                                 DG.Tweening.ShortcutExtensions::DOMove
02d60418: ldr     x2, [x21]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d6041c: mov     w1, #4                                     
02d60420: bl      #0x336fa0c                                 fn_336fa0c
02d60424: ldr     x8, [x22]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d60428: mov     x20, x0                                    
02d6042c: mov     x0, x8                                     
02d60430: bl      #0x2b7104c                                 fn_2b7104c
02d60434: ldr     x2, [x23]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d60438: mov     x1, x19                                    
02d6043c: mov     x3, xzr                                    
02d60440: mov     x21, x0                                    
02d60444: bl      #0x2d89dc4                                 DG.Tweening.TweenCallback::.ctor
02d60448: ldr     x2, [x24]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d6044c: mov     x0, x20                                    
02d60450: mov     x1, x21                                    
02d60454: ldp     x20, x19, [sp, #0x40]                      
02d60458: ldp     x22, x21, [sp, #0x30]                      
02d6045c: ldp     x24, x23, [sp, #0x20]                      
02d60460: ldp     x30, x25, [sp, #0x10]                      
02d60464: ldr     d8, [sp], #0x50                            
02d60468: b       #0x336f26c                                 
02d6046c: bl      #0x2b7105c                                 fn_2b7105c
## MoveResultToCenter() -> void
---- Clicker.KeycapMakerController::MoveResultToCenter 0x2d6d3e8
02d6d3e8: str     x30, [sp, #-0x30]!                         
02d6d3ec: stp     x22, x21, [sp, #0x10]                      
02d6d3f0: stp     x20, x19, [sp, #0x20]                      
02d6d3f4: adrp    x20, #0x6630000                            
02d6d3f8: adrp    x21, #0x6266000                            
02d6d3fc: mov     x19, x0                                    
02d6d400: ldrb    w8, [x20, #0x37e]                          
02d6d404: ldr     x21, [x21, #0x880]                         MS:DG.Tweening.TweenSettingsExtensions::SetEase
02d6d408: tbnz    w8, #0, #0x2d6d42c                         
02d6d40c: adrp    x0, #0x626b000                             
02d6d410: ldr     x0, [x0, #0xf08]                           MS:DG.Tweening.TweenSettingsExtensions::SetEase
02d6d414: bl      #0x2b70db0                                 fn_2b70db0
02d6d418: adrp    x0, #0x6266000                             
02d6d41c: ldr     x0, [x0, #0x880]                           MS:DG.Tweening.TweenSettingsExtensions::SetEase
02d6d420: bl      #0x2b70db0                                 fn_2b70db0
02d6d424: mov     w8, #1                                     
02d6d428: strb    w8, [x20, #0x37e]                          
02d6d42c: movi    d0, #0000000000000000                      
02d6d430: fmov    s1, #0.50000000                            
02d6d434: ldr     x0, [x19, #0x110]                          ._srBG
02d6d438: mov     x1, xzr                                    
02d6d43c: bl      #0x2c77d0c                                 DG.Tweening.DOTweenModuleSprite::DOFade
02d6d440: movi    d0, #0000000000000000                      
02d6d444: fmov    s1, #0.50000000                            
02d6d448: ldr     x0, [x19, #0x118]                          ._tfFinalEffect
02d6d44c: mov     x1, xzr                                    
02d6d450: bl      #0x2d98c98                                 DG.Tweening.ShortcutExtensions::DOScale
02d6d454: ldr     x2, [x21]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d6d458: mov     w1, #0x1a                                  
02d6d45c: bl      #0x336fa0c                                 fn_336fa0c
02d6d460: ldr     x0, [x19, #0xa0]                           ._baseKeycapObject
02d6d464: cbz     x0, #0x2d6d510                             
02d6d468: mov     w1, wzr                                    
02d6d46c: bl      #0x2d60978                                 Clicker.BaseKeycapObject::RotateKeychain
02d6d470: ldr     x0, [x19, #0xa0]                           ._baseKeycapObject
02d6d474: cbz     x0, #0x2d6d510                             
02d6d478: mov     x1, xzr                                    
02d6d47c: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02d6d480: ldr     x8, [x19, #0x100]                          ._tfLivestreamPose
02d6d484: cbz     x8, #0x2d6d510                             
02d6d488: adrp    x22, #0x626b000                            
02d6d48c: mov     x20, x0                                    
02d6d490: mov     x0, x8                                     
02d6d494: ldr     x22, [x22, #0xf08]                         MS:DG.Tweening.TweenSettingsExtensions::SetEase
02d6d498: mov     x1, xzr                                    
02d6d49c: bl      #0x5b46a30                                 UnityEngine.Transform::get_rotation
02d6d4a0: fmov    s4, #0.50000000                            
02d6d4a4: mov     x0, x20                                    
02d6d4a8: mov     x1, xzr                                    
02d6d4ac: bl      #0x2d9857c                                 DG.Tweening.ShortcutExtensions::DORotateQuaternion
02d6d4b0: ldr     x2, [x22]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d6d4b4: mov     w1, #4                                     
02d6d4b8: bl      #0x336fa0c                                 fn_336fa0c
02d6d4bc: ldr     x0, [x19, #0xa0]                           ._baseKeycapObject
02d6d4c0: cbz     x0, #0x2d6d510                             
02d6d4c4: mov     x1, xzr                                    
02d6d4c8: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02d6d4cc: ldr     x8, [x19, #0x100]                          ._tfLivestreamPose
02d6d4d0: cbz     x8, #0x2d6d510                             
02d6d4d4: mov     x19, x0                                    
02d6d4d8: mov     x0, x8                                     
02d6d4dc: mov     x1, xzr                                    
02d6d4e0: bl      #0x5b467ac                                 UnityEngine.Transform::get_position
02d6d4e4: fmov    s3, #0.50000000                            
02d6d4e8: mov     x0, x19                                    
02d6d4ec: mov     w1, wzr                                    
02d6d4f0: mov     x2, xzr                                    
02d6d4f4: bl      #0x2d975e4                                 DG.Tweening.ShortcutExtensions::DOMove
02d6d4f8: ldr     x2, [x21]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d6d4fc: ldp     x20, x19, [sp, #0x20]                      
02d6d500: ldp     x22, x21, [sp, #0x10]                      
02d6d504: mov     w1, #4                                     
02d6d508: ldr     x30, [sp], #0x30                           
02d6d50c: b       #0x336fa0c                                 
02d6d510: bl      #0x2b7105c                                 fn_2b7105c
## MoveResultToComplete(System.Action onComplete) -> void
---- Clicker.KeycapMakerController::MoveResultToComplete 0x2d6d514
02d6d514: str     x30, [sp, #-0x40]!                         
02d6d518: stp     x24, x23, [sp, #0x10]                      
02d6d51c: stp     x22, x21, [sp, #0x20]                      
02d6d520: stp     x20, x19, [sp, #0x30]                      
02d6d524: adrp    x19, #0x6630000                            
02d6d528: adrp    x22, #0x626c000                            
02d6d52c: mov     x21, x1                                    
02d6d530: ldrb    w8, [x19, #0x37f]                          
02d6d534: ldr     x22, [x22, #0x478]                         T:Clicker.KeycapMakerController/<>c__DisplayClass69_0
02d6d538: mov     x20, x0                                    
02d6d53c: tbnz    w8, #0, #0x2d6d590                         
02d6d540: adrp    x0, #0x6264000                             
02d6d544: ldr     x0, [x0, #0xe8]                            T:DG.Tweening.TweenCallback ._pointerHandTutorial
02d6d548: bl      #0x2b70db0                                 fn_2b70db0
02d6d54c: adrp    x0, #0x6266000                             
02d6d550: ldr     x0, [x0, #0x928]                           MS:DG.Tweening.TweenSettingsExtensions::OnComplete
02d6d554: bl      #0x2b70db0                                 fn_2b70db0
02d6d558: adrp    x0, #0x626b000                             
02d6d55c: ldr     x0, [x0, #0xf08]                           MS:DG.Tweening.TweenSettingsExtensions::SetEase
02d6d560: bl      #0x2b70db0                                 fn_2b70db0
02d6d564: adrp    x0, #0x6266000                             
02d6d568: ldr     x0, [x0, #0x880]                           MS:DG.Tweening.TweenSettingsExtensions::SetEase
02d6d56c: bl      #0x2b70db0                                 fn_2b70db0
02d6d570: adrp    x0, #0x626c000                             
02d6d574: ldr     x0, [x0, #0x480]                           M:Clicker.KeycapMakerController/<>c__DisplayClass69_0::<MoveResultToComplete>b__0
02d6d578: bl      #0x2b70db0                                 fn_2b70db0
02d6d57c: adrp    x0, #0x626c000                             
02d6d580: ldr     x0, [x0, #0x478]                           T:Clicker.KeycapMakerController/<>c__DisplayClass69_0
02d6d584: bl      #0x2b70db0                                 fn_2b70db0
02d6d588: mov     w8, #1                                     
02d6d58c: strb    w8, [x19, #0x37f]                          
02d6d590: ldr     x0, [x22]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d6d594: bl      #0x2b7104c                                 fn_2b7104c
02d6d598: mov     x1, xzr                                    
02d6d59c: mov     x19, x0                                    
02d6d5a0: bl      #0x2d6e5dc                                 Clicker.KeycapMakerController/<>c__DisplayClass69_0::.ctor
02d6d5a4: cbz     x19, #0x2d6d6d8                            
02d6d5a8: mov     x0, x19                                    
02d6d5ac: mov     x1, x21                                    
02d6d5b0: str     x21, [x0, #0x10]!                          
02d6d5b4: bl      #0x2b70d54                                 fn_2b70d54
02d6d5b8: adrp    x8, #0x1084000                             
02d6d5bc: fmov    s0, #1.00000000                            
02d6d5c0: ldr     x0, [x20, #0xe0]                           ._srBGForPopupComplete
02d6d5c4: ldr     s1, [x8, #0xf10]                           [1084f10]=4110bc863e99999a f=0.3,9.04603
02d6d5c8: mov     x1, xzr                                    
02d6d5cc: bl      #0x2c77d0c                                 DG.Tweening.DOTweenModuleSprite::DOFade
02d6d5d0: ldr     x0, [x20, #0xa0]                           ._baseKeycapObject
02d6d5d4: cbz     x0, #0x2d6d6d8                             
02d6d5d8: mov     w1, #1                                     
02d6d5dc: bl      #0x2d60978                                 Clicker.BaseKeycapObject::RotateKeychain
02d6d5e0: ldr     x0, [x20, #0xa0]                           ._baseKeycapObject
02d6d5e4: cbz     x0, #0x2d6d6d8                             
02d6d5e8: mov     x1, xzr                                    
02d6d5ec: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02d6d5f0: ldr     x8, [x20, #0x108]                          ._tfCompletePose
02d6d5f4: cbz     x8, #0x2d6d6d8                             
02d6d5f8: adrp    x22, #0x626b000                            
02d6d5fc: mov     x21, x0                                    
02d6d600: mov     x0, x8                                     
02d6d604: ldr     x22, [x22, #0xf08]                         MS:DG.Tweening.TweenSettingsExtensions::SetEase
02d6d608: mov     x1, xzr                                    
02d6d60c: bl      #0x5b46a30                                 UnityEngine.Transform::get_rotation
02d6d610: fmov    s4, #0.50000000                            
02d6d614: mov     x0, x21                                    
02d6d618: mov     x1, xzr                                    
02d6d61c: bl      #0x2d9857c                                 DG.Tweening.ShortcutExtensions::DORotateQuaternion
02d6d620: ldr     x2, [x22]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d6d624: mov     w1, #4                                     
02d6d628: bl      #0x336fa0c                                 fn_336fa0c
02d6d62c: ldr     x0, [x20, #0xa0]                           ._baseKeycapObject
02d6d630: cbz     x0, #0x2d6d6d8                             
02d6d634: mov     x1, xzr                                    
02d6d638: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02d6d63c: ldr     x8, [x20, #0x108]                          ._tfCompletePose
02d6d640: cbz     x8, #0x2d6d6d8                             
02d6d644: adrp    x21, #0x6266000                            
02d6d648: adrp    x22, #0x6264000                            
02d6d64c: adrp    x23, #0x626c000                            
02d6d650: adrp    x24, #0x6266000                            
02d6d654: mov     x20, x0                                    
02d6d658: ldr     x21, [x21, #0x880]                         MS:DG.Tweening.TweenSettingsExtensions::SetEase
02d6d65c: ldr     x22, [x22, #0xe8]                          T:DG.Tweening.TweenCallback
02d6d660: ldr     x23, [x23, #0x480]                         M:Clicker.KeycapMakerController/<>c__DisplayClass69_0::<MoveResultToComplete>b__0
02d6d664: ldr     x24, [x24, #0x928]                         MS:DG.Tweening.TweenSettingsExtensions::OnComplete
02d6d668: mov     x0, x8                                     
02d6d66c: mov     x1, xzr                                    
02d6d670: bl      #0x5b467ac                                 UnityEngine.Transform::get_position
02d6d674: fmov    s3, #0.50000000                            
02d6d678: mov     x0, x20                                    
02d6d67c: mov     w1, wzr                                    
02d6d680: mov     x2, xzr                                    
02d6d684: bl      #0x2d975e4                                 DG.Tweening.ShortcutExtensions::DOMove
02d6d688: ldr     x2, [x21]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d6d68c: mov     w1, #4                                     
02d6d690: bl      #0x336fa0c                                 fn_336fa0c
02d6d694: ldr     x8, [x22]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d6d698: mov     x20, x0                                    
02d6d69c: mov     x0, x8                                     
02d6d6a0: bl      #0x2b7104c                                 fn_2b7104c
02d6d6a4: ldr     x2, [x23]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d6d6a8: mov     x1, x19                                    
02d6d6ac: mov     x3, xzr                                    
02d6d6b0: mov     x21, x0                                    
02d6d6b4: bl      #0x2d89dc4                                 DG.Tweening.TweenCallback::.ctor
02d6d6b8: ldr     x2, [x24]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d6d6bc: mov     x0, x20                                    
02d6d6c0: mov     x1, x21                                    
02d6d6c4: ldp     x20, x19, [sp, #0x30]                      
02d6d6c8: ldp     x22, x21, [sp, #0x20]                      
02d6d6cc: ldp     x24, x23, [sp, #0x10]                      
02d6d6d0: ldr     x30, [sp], #0x40                           
02d6d6d4: b       #0x336f26c                                 
02d6d6d8: bl      #0x2b7105c                                 fn_2b7105c
## ShowHighlightSetupAt(UnityEngine.Transform tfPosition) -> void
---- Clicker.KeycapMakerController::ShowHighlightSetupAt 0x2d5f31c
02d5f31c: stp     x30, x21, [sp, #-0x20]!                    
02d5f320: stp     x20, x19, [sp, #0x10]                      
02d5f324: cbz     x1, #0x2d5f3e8                             
02d5f328: mov     x19, x0                                    
02d5f32c: ldr     x20, [x0, #0xb0]                           ._tfHighlight
02d5f330: mov     x0, x1                                     
02d5f334: mov     x1, xzr                                    
02d5f338: bl      #0x5b467ac                                 UnityEngine.Transform::get_position
02d5f33c: cbz     x20, #0x2d5f3e8                            
02d5f340: mov     x0, x20                                    
02d5f344: mov     x1, xzr                                    
02d5f348: bl      #0x5b46888                                 UnityEngine.Transform::set_position
02d5f34c: ldr     x0, [x19, #0xb0]                           ._tfHighlight
02d5f350: mov     w1, wzr                                    
02d5f354: mov     x2, xzr                                    
02d5f358: bl      #0x2d9d5d0                                 DG.Tweening.ShortcutExtensions::DOKill
02d5f35c: adrp    x21, #0x662f000                            
02d5f360: ldr     x20, [x19, #0xb0]                          ._tfHighlight
02d5f364: ldrb    w8, [x21, #0xa74]                          
02d5f368: cbnz    w8, #0x2d5f380                             
02d5f36c: adrp    x0, #0x6264000                             
02d5f370: ldr     x0, [x0, #0xd8]                            T:UnityEngine.Vector3 ._bgWall
02d5f374: bl      #0x2b70db0                                 fn_2b70db0
02d5f378: mov     w8, #1                                     
02d5f37c: strb    w8, [x21, #0xa74]                          
02d5f380: cbz     x20, #0x2d5f3e8                            
02d5f384: adrp    x8, #0x6264000                             
02d5f388: mov     w9, #0x999a                                
02d5f38c: mov     x0, x20                                    
02d5f390: ldr     x8, [x8, #0xd8]                            T:UnityEngine.Vector3
02d5f394: movk    w9, #0x3f99, lsl #16                       
02d5f398: mov     x1, xzr                                    
02d5f39c: dup     v0.2s, w9                                  
02d5f3a0: adrp    x9, #0x1084000                             
02d5f3a4: ldr     x8, [x8]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d5f3a8: ldr     s2, [x9, #0xcf4]                           [1084cf4]=431d80003f99999a f=1.2,157.5
02d5f3ac: ldr     x8, [x8, #0xb8]                            MS:DG.Tweening.Core.Extensions::SetSpecialStartupMode
02d5f3b0: ldur    d1, [x8, #0xc]                             
02d5f3b4: fmul    v0.2s, v1.2s, v0.2s                        
02d5f3b8: ldr     s1, [x8, #0x14]                            [6264014]=0 f=0,0
02d5f3bc: fmul    s2, s1, s2                                 
02d5f3c0: mov     s1, v0.s[1]                                
02d5f3c4: bl      #0x5b470cc                                 UnityEngine.Transform::set_localScale
02d5f3c8: adrp    x8, #0x1084000                             
02d5f3cc: ldr     x0, [x19, #0xb0]                           ._tfHighlight
02d5f3d0: fmov    s0, #1.00000000                            
02d5f3d4: ldp     x20, x19, [sp, #0x10]                      
02d5f3d8: ldr     s1, [x8, #0xf10]                           [1084f10]=4110bc863e99999a f=0.3,9.04603
02d5f3dc: mov     x1, xzr                                    
02d5f3e0: ldp     x30, x21, [sp], #0x20                      
02d5f3e4: b       #0x2d98c98                                 DG.Tweening.ShortcutExtensions::DOScale
02d5f3e8: bl      #0x2b7105c                                 fn_2b7105c
## MoveTrayToLowPos(float delay) -> void
---- Clicker.KeycapMakerController::MoveTrayToLowPos 0x2d6d6f4
02d6d6f4: stp     d9, d8, [sp, #-0x50]!                      
02d6d6f8: stp     x30, x25, [sp, #0x10]                      
02d6d6fc: stp     x24, x23, [sp, #0x20]                      
02d6d700: stp     x22, x21, [sp, #0x30]                      
02d6d704: stp     x20, x19, [sp, #0x40]                      
02d6d708: fmov    s8, s0                                     
02d6d70c: adrp    x20, #0x6630000                            
02d6d710: mov     x19, x0                                    
02d6d714: ldrb    w8, [x20, #0x380]                          
02d6d718: tbnz    w8, #0, #0x2d6d760                         
02d6d71c: adrp    x0, #0x626c000                             
02d6d720: ldr     x0, [x0, #0x488]                           M:Clicker.KeycapMakerController::<MoveTrayToLowPos>b__71_0
02d6d724: bl      #0x2b70db0                                 fn_2b70db0
02d6d728: adrp    x0, #0x6264000                             
02d6d72c: ldr     x0, [x0, #0xe8]                            T:DG.Tweening.TweenCallback ._pointerHandTutorial
02d6d730: bl      #0x2b70db0                                 fn_2b70db0
02d6d734: adrp    x0, #0x6266000                             
02d6d738: ldr     x0, [x0, #0x928]                           MS:DG.Tweening.TweenSettingsExtensions::OnComplete
02d6d73c: bl      #0x2b70db0                                 fn_2b70db0
02d6d740: adrp    x0, #0x6267000                             
02d6d744: ldr     x0, [x0, #0xf70]                           MS:DG.Tweening.TweenSettingsExtensions::SetDelay
02d6d748: bl      #0x2b70db0                                 fn_2b70db0
02d6d74c: adrp    x0, #0x6266000                             
02d6d750: ldr     x0, [x0, #0xe08]                           MS:DG.Tweening.TweenSettingsExtensions::SetDelay
02d6d754: bl      #0x2b70db0                                 fn_2b70db0
02d6d758: mov     w8, #1                                     
02d6d75c: strb    w8, [x20, #0x380]                          
02d6d760: ldr     x0, [x19, #0x40]                           ._srTray
02d6d764: cbz     x0, #0x2d6d898                             
02d6d768: ldr     x1, [x19, #0x50]                           ._trayTopViewSprite
02d6d76c: mov     x2, xzr                                    
02d6d770: bl      #0x5ae6dcc                                 UnityEngine.SpriteRenderer::set_sprite
02d6d774: ldr     x0, [x19, #0x38]                           ._goTray
02d6d778: cbz     x0, #0x2d6d898                             
02d6d77c: adrp    x21, #0x6266000                            
02d6d780: mov     x1, xzr                                    
02d6d784: ldr     x21, [x21, #0xe08]                         MS:DG.Tweening.TweenSettingsExtensions::SetDelay
02d6d788: bl      #0x5b368f0                                 UnityEngine.GameObject::get_transform
02d6d78c: fmov    s0, #-8.00000000                           
02d6d790: fmov    s1, #1.00000000                            
02d6d794: mov     w1, wzr                                    
02d6d798: mov     x2, xzr                                    
02d6d79c: bl      #0x2d98060                                 DG.Tweening.ShortcutExtensions::DOLocalMoveY
02d6d7a0: fmov    s0, s8                                     
02d6d7a4: ldr     x1, [x21]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d6d7a8: bl      #0x336f7fc                                 fn_336f7fc
02d6d7ac: ldr     x0, [x19, #0x58]                           ._srBaseKeycapOnTray
02d6d7b0: cbz     x0, #0x2d6d898                             
02d6d7b4: mov     x1, xzr                                    
02d6d7b8: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02d6d7bc: ldr     x8, [x19, #0x58]                           ._srBaseKeycapOnTray
02d6d7c0: cbz     x8, #0x2d6d898                             
02d6d7c4: mov     x20, x0                                    
02d6d7c8: mov     x0, x8                                     
02d6d7cc: mov     x1, xzr                                    
02d6d7d0: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02d6d7d4: cbz     x0, #0x2d6d898                             
02d6d7d8: adrp    x23, #0x6264000                            
02d6d7dc: adrp    x24, #0x626c000                            
02d6d7e0: adrp    x25, #0x6266000                            
02d6d7e4: adrp    x22, #0x6267000                            
02d6d7e8: ldr     x23, [x23, #0xe8]                          T:DG.Tweening.TweenCallback
02d6d7ec: ldr     x24, [x24, #0x488]                         M:Clicker.KeycapMakerController::<MoveTrayToLowPos>b__71_0
02d6d7f0: ldr     x25, [x25, #0x928]                         MS:DG.Tweening.TweenSettingsExtensions::OnComplete
02d6d7f4: ldr     x22, [x22, #0xf70]                         MS:DG.Tweening.TweenSettingsExtensions::SetDelay
02d6d7f8: mov     x1, xzr                                    
02d6d7fc: bl      #0x5b45c24                                 UnityEngine.Transform::get_localPosition
02d6d800: fmov    s0, #1.00000000                            
02d6d804: mov     x0, x20                                    
02d6d808: mov     w1, wzr                                    
02d6d80c: mov     x2, xzr                                    
02d6d810: fmov    s9, #0.50000000                            
02d6d814: fadd    s0, s1, s0                                 
02d6d818: fmov    s1, #0.50000000                            
02d6d81c: bl      #0x2d98060                                 DG.Tweening.ShortcutExtensions::DOLocalMoveY
02d6d820: fadd    s8, s8, s9                                 
02d6d824: ldr     x1, [x21]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d6d828: fmov    s0, s8                                     
02d6d82c: bl      #0x336f7fc                                 fn_336f7fc
02d6d830: ldr     x8, [x23]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d6d834: mov     x20, x0                                    
02d6d838: mov     x0, x8                                     
02d6d83c: bl      #0x2b7104c                                 fn_2b7104c
02d6d840: ldr     x2, [x24]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d6d844: mov     x1, x19                                    
02d6d848: mov     x3, xzr                                    
02d6d84c: mov     x21, x0                                    
02d6d850: bl      #0x2d89dc4                                 DG.Tweening.TweenCallback::.ctor
02d6d854: ldr     x2, [x25]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d6d858: mov     x0, x20                                    
02d6d85c: mov     x1, x21                                    
02d6d860: bl      #0x336f26c                                 fn_336f26c
02d6d864: movi    d0, #0000000000000000                      
02d6d868: fmov    s1, #0.50000000                            
02d6d86c: ldr     x0, [x19, #0x58]                           ._srBaseKeycapOnTray
02d6d870: mov     x1, xzr                                    
02d6d874: bl      #0x2c77d0c                                 DG.Tweening.DOTweenModuleSprite::DOFade
02d6d878: ldr     x1, [x22]                                  S:'didu'
02d6d87c: ldp     x20, x19, [sp, #0x40]                      
02d6d880: ldp     x22, x21, [sp, #0x30]                      
02d6d884: fmov    s0, s8                                     
02d6d888: ldp     x24, x23, [sp, #0x20]                      
02d6d88c: ldp     x30, x25, [sp, #0x10]                      
02d6d890: ldp     d9, d8, [sp], #0x50                        
02d6d894: b       #0x336f7fc                                 
02d6d898: bl      #0x2b7105c                                 fn_2b7105c
## AnimAppearBaseKeycap(float delay) -> void
---- Clicker.KeycapMakerController::AnimAppearBaseKeycap 0x2d6d89c
02d6d89c: str     d8, [sp, #-0x30]!                          
02d6d8a0: stp     x30, x21, [sp, #0x10]                      
02d6d8a4: stp     x20, x19, [sp, #0x20]                      
02d6d8a8: fmov    s8, s0                                     
02d6d8ac: adrp    x20, #0x6630000                            
02d6d8b0: mov     x19, x0                                    
02d6d8b4: ldrb    w8, [x20, #0x381]                          
02d6d8b8: tbnz    w8, #0, #0x2d6d8dc                         
02d6d8bc: adrp    x0, #0x6266000                             
02d6d8c0: ldr     x0, [x0, #0xe08]                           MS:DG.Tweening.TweenSettingsExtensions::SetDelay
02d6d8c4: bl      #0x2b70db0                                 fn_2b70db0
02d6d8c8: adrp    x0, #0x6266000                             
02d6d8cc: ldr     x0, [x0, #0x880]                           MS:DG.Tweening.TweenSettingsExtensions::SetEase
02d6d8d0: bl      #0x2b70db0                                 fn_2b70db0
02d6d8d4: mov     w8, #1                                     
02d6d8d8: strb    w8, [x20, #0x381]                          
02d6d8dc: ldr     x0, [x19, #0xa0]                           ._baseKeycapObject
02d6d8e0: cbz     x0, #0x2d6d99c                             
02d6d8e4: mov     x1, xzr                                    
02d6d8e8: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02d6d8ec: adrp    x21, #0x662f000                            
02d6d8f0: mov     x20, x0                                    
02d6d8f4: ldrb    w8, [x21, #0x91a]                          
02d6d8f8: cbnz    w8, #0x2d6d910                             
02d6d8fc: adrp    x0, #0x6264000                             
02d6d900: ldr     x0, [x0, #0xd8]                            T:UnityEngine.Vector3 ._bgWall
02d6d904: bl      #0x2b70db0                                 fn_2b70db0
02d6d908: mov     w8, #1                                     
02d6d90c: strb    w8, [x21, #0x91a]                          
02d6d910: cbz     x20, #0x2d6d99c                            
02d6d914: adrp    x8, #0x6264000                             
02d6d918: mov     x0, x20                                    
02d6d91c: mov     x1, xzr                                    
02d6d920: ldr     x8, [x8, #0xd8]                            T:UnityEngine.Vector3
02d6d924: ldr     x8, [x8]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d6d928: ldr     x8, [x8, #0xb8]                            MS:DG.Tweening.Core.Extensions::SetSpecialStartupMode
02d6d92c: ldp     s1, s2, [x8, #4]                           
02d6d930: ldr     s0, [x8]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d6d934: bl      #0x5b470cc                                 UnityEngine.Transform::set_localScale
02d6d938: ldr     x0, [x19, #0xa0]                           ._baseKeycapObject
02d6d93c: cbz     x0, #0x2d6d99c                             
02d6d940: bl      #0x2d5f45c                                 Clicker.BaseKeycapObject::ShowBaseOnly
02d6d944: ldr     x0, [x19, #0xa0]                           ._baseKeycapObject
02d6d948: cbz     x0, #0x2d6d99c                             
02d6d94c: adrp    x19, #0x6266000                            
02d6d950: adrp    x20, #0x6266000                            
02d6d954: mov     x1, xzr                                    
02d6d958: ldr     x19, [x19, #0xe08]                         MS:DG.Tweening.TweenSettingsExtensions::SetDelay
02d6d95c: ldr     x20, [x20, #0x880]                         MS:DG.Tweening.TweenSettingsExtensions::SetEase
02d6d960: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02d6d964: adrp    x8, #0x1084000                             
02d6d968: fmov    s0, #1.00000000                            
02d6d96c: mov     x1, xzr                                    
02d6d970: ldr     s1, [x8, #0xf10]                           [1084f10]=4110bc863e99999a f=0.3,9.04603
02d6d974: bl      #0x2d98c98                                 DG.Tweening.ShortcutExtensions::DOScale
02d6d978: fmov    s0, s8                                     
02d6d97c: ldr     x1, [x19]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d6d980: bl      #0x336f7fc                                 fn_336f7fc
02d6d984: ldr     x2, [x20]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d6d988: ldp     x20, x19, [sp, #0x20]                      
02d6d98c: ldp     x30, x21, [sp, #0x10]                      
02d6d990: mov     w1, #0x1b                                  
02d6d994: ldr     d8, [sp], #0x30                            
02d6d998: b       #0x336fa0c                                 
02d6d99c: bl      #0x2b7105c                                 fn_2b7105c
## PrepareAssembleStep() -> void
---- Clicker.KeycapMakerController::PrepareAssembleStep 0x2d6d9a0
02d6d9a0: str     d8, [sp, #-0x40]!                          
02d6d9a4: str     x30, [sp, #8]                              
02d6d9a8: stp     x24, x23, [sp, #0x10]                      
02d6d9ac: stp     x22, x21, [sp, #0x20]                      
02d6d9b0: stp     x20, x19, [sp, #0x30]                      
02d6d9b4: adrp    x20, #0x6630000                            
02d6d9b8: mov     x19, x0                                    
02d6d9bc: ldrb    w8, [x20, #0x382]                          
02d6d9c0: tbnz    w8, #0, #0x2d6d9e4                         
02d6d9c4: adrp    x0, #0x6265000                             
02d6d9c8: ldr     x0, [x0, #0xb38]                           T:DevTrack
02d6d9cc: bl      #0x2b70db0                                 fn_2b70db0
02d6d9d0: adrp    x0, #0x6266000                             
02d6d9d4: ldr     x0, [x0, #0xb48]                           MS:MonoSingleton`1::get_Instance
02d6d9d8: bl      #0x2b70db0                                 fn_2b70db0
02d6d9dc: mov     w8, #1                                     
02d6d9e0: strb    w8, [x20, #0x382]                          
02d6d9e4: ldr     x0, [x19, #0xa0]                           ._baseKeycapObject
02d6d9e8: cbz     x0, #0x2d6db0c                             
02d6d9ec: adrp    x23, #0x6266000                            
02d6d9f0: ldr     x23, [x23, #0xb48]                         MS:MonoSingleton`1::get_Instance
02d6d9f4: bl      #0x2d5e648                                 Clicker.BaseKeycapObject::RemoveSetupEvent
02d6d9f8: mov     x0, x19                                    
02d6d9fc: bl      #0x2d6c448                                 Clicker.KeycapMakerController::ShowTableBG
02d6da00: movi    d0, #0000000000000000                      
02d6da04: mov     x0, x19                                    
02d6da08: bl      #0x2d6d6f4                                 Clicker.KeycapMakerController::MoveTrayToLowPos
02d6da0c: fmov    s0, #1.00000000                            
02d6da10: mov     x0, x19                                    
02d6da14: bl      #0x2d6d89c                                 Clicker.KeycapMakerController::AnimAppearBaseKeycap
02d6da18: ldr     x0, [x23]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d6da1c: bl      #0x3769600                                 fn_3769600
02d6da20: cbz     x0, #0x2d6db0c                             
02d6da24: ldr     x19, [x0, #0x30]                           S:'popup_rate_on_off' ._keychainId
02d6da28: ldr     x0, [x23]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d6da2c: bl      #0x3769600                                 fn_3769600
02d6da30: cbz     x0, #0x2d6db0c                             
02d6da34: adrp    x24, #0x6265000                            
02d6da38: mov     x8, x0                                     
02d6da3c: ldr     x24, [x24, #0xb38]                         T:DevTrack
02d6da40: ldr     w20, [x8, #0x3c]                           
02d6da44: ldr     x0, [x24]                                  M:AdsManager::<OnApplicationPause>b__26_0
02d6da48: ldr     w9, [x0, #0xe4]                            [62660e4]=0 f=0,0
02d6da4c: cbnz    w9, #0x2d6da58                             
02d6da50: bl      #0x2b70f30                                 fn_2b70f30
02d6da54: ldr     x0, [x24]                                  M:AdsManager::<OnApplicationPause>b__26_0
02d6da58: ldr     x8, [x0, #0xb8]                            S:'banner_native_refresh_time' ._keychainConfig
02d6da5c: mov     x0, xzr                                    
02d6da60: ldr     x21, [x8, #0x248]                          
02d6da64: ldr     w22, [x8, #0x288]                          
02d6da68: bl      #0x5b432fc                                 UnityEngine.Time::get_time
02d6da6c: ldr     x0, [x23]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d6da70: fmov    s8, s0                                     
02d6da74: bl      #0x3769600                                 fn_3769600
02d6da78: cbz     x0, #0x2d6db0c                             
02d6da7c: ldr     s0, [x0, #0x38]                            S:'native_collap_id' ._goTray
02d6da80: mov     x0, x19                                    
02d6da84: mov     w1, w20                                    
02d6da88: mov     x2, x21                                    
02d6da8c: mov     w3, w22                                    
02d6da90: mov     x4, xzr                                    
02d6da94: fsub    s0, s8, s0                                 
02d6da98: bl      #0x2c9c898                                 DevTrack::GameModeStepComplete
02d6da9c: ldr     x0, [x23]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d6daa0: bl      #0x3769600                                 fn_3769600
02d6daa4: cbz     x0, #0x2d6db0c                             
02d6daa8: ldr     x19, [x0, #0x30]                           S:'popup_rate_on_off' ._keychainId
02d6daac: ldr     x0, [x23]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d6dab0: bl      #0x3769600                                 fn_3769600
02d6dab4: cbz     x0, #0x2d6db0c                             
02d6dab8: ldr     x8, [x24]                                  M:AdsManager::<OnApplicationPause>b__26_0
02d6dabc: ldr     w1, [x0, #0x3c]                            [626603c]=0 f=0,0
02d6dac0: mov     x0, x19                                    
02d6dac4: mov     x4, xzr                                    
02d6dac8: ldr     x8, [x8, #0xb8]                            
02d6dacc: ldr     x2, [x8, #0x250]                           
02d6dad0: ldr     w3, [x8, #0x28c]                           
02d6dad4: bl      #0x2c9c714                                 DevTrack::GameModeStepEnter
02d6dad8: ldr     x0, [x23]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d6dadc: bl      #0x3769600                                 fn_3769600
02d6dae0: cbz     x0, #0x2d6db0c                             
02d6dae4: ldr     x8, [x24]                                  M:AdsManager::<OnApplicationPause>b__26_0
02d6dae8: ldp     x20, x19, [sp, #0x30]                      
02d6daec: ldp     x22, x21, [sp, #0x20]                      
02d6daf0: ldr     x30, [sp, #8]                              
02d6daf4: ldr     x8, [x8, #0xb8]                            
02d6daf8: ldp     x24, x23, [sp, #0x10]                      
02d6dafc: ldr     x1, [x8, #0x250]                           
02d6db00: str     x1, [x0, #0x40]!                           ._srTray
02d6db04: ldr     d8, [sp], #0x40                            
02d6db08: b       #0x2b70d54                                 
02d6db0c: bl      #0x2b7105c                                 fn_2b7105c
## ShowTableBG() -> void
---- Clicker.KeycapMakerController::ShowTableBG 0x2d6c448
02d6c448: stp     x30, x19, [sp, #-0x10]!                    
02d6c44c: mov     x19, x0                                    
02d6c450: ldr     x0, [x0, #0xd0]                            ._bgTable
02d6c454: cbz     x0, #0x2d6c47c                             
02d6c458: mov     w1, #1                                     
02d6c45c: mov     x2, xzr                                    
02d6c460: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d6c464: ldr     x0, [x19, #0xd8]                           ._bgWall
02d6c468: cbz     x0, #0x2d6c47c                             
02d6c46c: mov     w1, wzr                                    
02d6c470: mov     x2, xzr                                    
02d6c474: ldp     x30, x19, [sp], #0x10                      
02d6c478: b       #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d6c47c: bl      #0x2b7105c                                 fn_2b7105c
## ShowWallBG() -> void
---- Clicker.KeycapMakerController::ShowWallBG 0x2d6c770
02d6c770: stp     x30, x19, [sp, #-0x10]!                    
02d6c774: mov     x19, x0                                    
02d6c778: ldr     x0, [x0, #0xd0]                            ._bgTable
02d6c77c: cbz     x0, #0x2d6c7a4                             
02d6c780: mov     w1, wzr                                    
02d6c784: mov     x2, xzr                                    
02d6c788: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d6c78c: ldr     x0, [x19, #0xd8]                           ._bgWall
02d6c790: cbz     x0, #0x2d6c7a4                             
02d6c794: mov     w1, #1                                     
02d6c798: mov     x2, xzr                                    
02d6c79c: ldp     x30, x19, [sp], #0x10                      
02d6c7a0: b       #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d6c7a4: bl      #0x2b7105c                                 fn_2b7105c
## ShowBGComplete() -> void
---- Clicker.KeycapMakerController::ShowBGComplete 0x2d6d6dc
02d6d6dc: adrp    x8, #0x1084000                             
02d6d6e0: fmov    s0, #1.00000000                            
02d6d6e4: ldr     x0, [x0, #0xe0]                            ._srBGForPopupComplete
02d6d6e8: ldr     s1, [x8, #0xf10]                           [1084f10]=4110bc863e99999a f=0.3,9.04603
02d6d6ec: mov     x1, xzr                                    
02d6d6f0: b       #0x2c77d0c                                 DG.Tweening.DOTweenModuleSprite::DOFade
## ShowHandComplete() -> void
---- Clicker.KeycapMakerController::ShowHandComplete 0x2d6db10
02d6db10: stp     x30, x19, [sp, #-0x10]!                    
02d6db14: ldr     x8, [x0, #0xa0]                            ._baseKeycapObject
02d6db18: cbz     x8, #0x2d6db3c                             
02d6db1c: mov     x19, x0                                    
02d6db20: ldr     x0, [x8, #0x98]                            
02d6db24: cbz     x0, #0x2d6db3c                             
02d6db28: mov     w1, #1                                     
02d6db2c: bl      #0x2d5e4d8                                 Clicker.HandFollowClick::ShowHand
02d6db30: mov     x0, x19                                    
02d6db34: ldp     x30, x19, [sp], #0x10                      
02d6db38: b       #0x2d6db40                                 Clicker.KeycapMakerController::AutoClickRandomTime
02d6db3c: bl      #0x2b7105c                                 fn_2b7105c
## AutoClickRandomTime() -> void
---- Clicker.KeycapMakerController::AutoClickRandomTime 0x2d6db40
02d6db40: stp     d9, d8, [sp, #-0x40]!                      
02d6db44: stp     x30, x23, [sp, #0x10]                      
02d6db48: stp     x22, x21, [sp, #0x20]                      
02d6db4c: stp     x20, x19, [sp, #0x30]                      
02d6db50: adrp    x20, #0x6630000                            
02d6db54: mov     x19, x0                                    
02d6db58: ldrb    w8, [x20, #0x383]                          
02d6db5c: tbnz    w8, #0, #0x2d6db80                         
02d6db60: adrp    x0, #0x626c000                             
02d6db64: ldr     x0, [x0, #0x490]                           M:Clicker.KeycapMakerController::<AutoClickRandomTime>b__78_0
02d6db68: bl      #0x2b70db0                                 fn_2b70db0
02d6db6c: adrp    x0, #0x6264000                             
02d6db70: ldr     x0, [x0, #0xe8]                            T:DG.Tweening.TweenCallback ._pointerHandTutorial
02d6db74: bl      #0x2b70db0                                 fn_2b70db0
02d6db78: mov     w8, #1                                     
02d6db7c: strb    w8, [x20, #0x383]                          
02d6db80: mov     w0, #3                                     
02d6db84: mov     w1, #5                                     
02d6db88: mov     x2, xzr                                    
02d6db8c: bl      #0x5b2e000                                 UnityEngine.Random::Range
02d6db90: cmp     w0, #1                                     
02d6db94: b.lt    #0x2d6dc00                                 
02d6db98: adrp    x22, #0x6264000                            
02d6db9c: adrp    x8, #0x1084000                             
02d6dba0: adrp    x23, #0x626c000                            
02d6dba4: ldr     x22, [x22, #0xe8]                          T:DG.Tweening.TweenCallback
02d6dba8: ldr     x23, [x23, #0x490]                         M:Clicker.KeycapMakerController::<AutoClickRandomTime>b__78_0
02d6dbac: ldr     s8, [x8, #0xeec]                           [1084eec]=457ff0003dcccccd f=0.1,4095
02d6dbb0: mov     w20, w0                                    
02d6dbb4: fmov    s0, s8                                     
02d6dbb8: fmov    s1, #1.50000000                            
02d6dbbc: mov     x0, xzr                                    
02d6dbc0: bl      #0x5b2dfc0                                 UnityEngine.Random::Range
02d6dbc4: ldr     x0, [x22]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d6dbc8: fmov    s9, s0                                     
02d6dbcc: bl      #0x2b7104c                                 fn_2b7104c
02d6dbd0: ldr     x2, [x23]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d6dbd4: mov     x1, x19                                    
02d6dbd8: mov     x3, xzr                                    
02d6dbdc: mov     x21, x0                                    
02d6dbe0: bl      #0x2d89dc4                                 DG.Tweening.TweenCallback::.ctor
02d6dbe4: fmov    s0, s9                                     
02d6dbe8: mov     x0, x21                                    
02d6dbec: mov     w1, #1                                     
02d6dbf0: mov     x2, xzr                                    
02d6dbf4: bl      #0x2d8f37c                                 DG.Tweening.DOVirtual::DelayedCall
02d6dbf8: subs    w20, w20, #1                               
02d6dbfc: b.ne    #0x2d6dbb4                                 
02d6dc00: ldp     x20, x19, [sp, #0x30]                      
02d6dc04: ldp     x22, x21, [sp, #0x20]                      
02d6dc08: ldp     x30, x23, [sp, #0x10]                      
02d6dc0c: ldp     d9, d8, [sp], #0x40                        
02d6dc10: ret                                                
## CallHandTouchThisSpot(UnityEngine.Transform target) -> void
---- Clicker.KeycapMakerController::CallHandTouchThisSpot 0x2d6dc14
02d6dc14: str     x30, [sp, #-0x10]!                         
02d6dc18: ldr     x8, [x0, #0xa0]                            ._baseKeycapObject
02d6dc1c: cbz     x8, #0x2d6dc30                             
02d6dc20: ldr     x0, [x8, #0x98]                            
02d6dc24: cbz     x0, #0x2d6dc30                             
02d6dc28: ldr     x30, [sp], #0x10                           
02d6dc2c: b       #0x2d638f4                                 Clicker.HandFollowClick::ClickAt
02d6dc30: bl      #0x2b7105c                                 fn_2b7105c
## ShowTapHandTutorial(bool isShow) -> void
---- Clicker.KeycapMakerController::ShowTapHandTutorial 0x2d63a4c
02d63a4c: str     x30, [sp, #-0x30]!                         
02d63a50: stp     x22, x21, [sp, #0x10]                      
02d63a54: stp     x20, x19, [sp, #0x20]                      
02d63a58: adrp    x21, #0x6630000                            
02d63a5c: adrp    x22, #0x6266000                            
02d63a60: mov     w19, w1                                    
02d63a64: ldrb    w8, [x21, #0x384]                          
02d63a68: ldr     x22, [x22, #0x658]                         MS:MonoSingleton`1::get_Instance
02d63a6c: mov     x20, x0                                    
02d63a70: tbnz    w8, #0, #0x2d63a94                         
02d63a74: adrp    x0, #0x6266000                             
02d63a78: ldr     x0, [x0, #0x750]                           MS:DataManager::GetData
02d63a7c: bl      #0x2b70db0                                 fn_2b70db0
02d63a80: adrp    x0, #0x6266000                             
02d63a84: ldr     x0, [x0, #0x658]                           MS:MonoSingleton`1::get_Instance
02d63a88: bl      #0x2b70db0                                 fn_2b70db0
02d63a8c: mov     w8, #1                                     
02d63a90: strb    w8, [x21, #0x384]                          
02d63a94: ldr     x0, [x22]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d63a98: bl      #0x3769600                                 fn_3769600
02d63a9c: cbz     x0, #0x2d63b0c                             
02d63aa0: adrp    x8, #0x6266000                             
02d63aa4: ldr     x8, [x8, #0x750]                           MS:DataManager::GetData
02d63aa8: ldr     x1, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d63aac: bl      #0x3168dd0                                 fn_3168dd0
02d63ab0: cbz     x0, #0x2d63b0c                             
02d63ab4: ldr     x8, [x0, #0x20]                            S:'inter_ad_capping_time' ._baseKeycapId
02d63ab8: cbz     x8, #0x2d63b0c                             
02d63abc: ldrb    w8, [x8, #0x3b]                            
02d63ac0: cbz     w8, #0x2d63ae4                             
02d63ac4: ldr     x0, [x20, #0xe8]                           ._pointerHandTutorial
02d63ac8: tbz     w19, #0, #0x2d63af4                        
02d63acc: cbz     x0, #0x2d63b0c                             
02d63ad0: ldp     x20, x19, [sp, #0x20]                      
02d63ad4: mov     x1, xzr                                    
02d63ad8: ldp     x22, x21, [sp, #0x10]                      
02d63adc: ldr     x30, [sp], #0x30                           
02d63ae0: b       #0x2d747ac                                 Clicker.TutorialDrag::Show
02d63ae4: ldp     x20, x19, [sp, #0x20]                      
02d63ae8: ldp     x22, x21, [sp, #0x10]                      
02d63aec: ldr     x30, [sp], #0x30                           
02d63af0: ret                                                
02d63af4: cbz     x0, #0x2d63b0c                             
02d63af8: ldp     x20, x19, [sp, #0x20]                      
02d63afc: mov     x1, xzr                                    
02d63b00: ldp     x22, x21, [sp, #0x10]                      
02d63b04: ldr     x30, [sp], #0x30                           
02d63b08: b       #0x2d74a1c                                 Clicker.TutorialDrag::Hide
02d63b0c: bl      #0x2b7105c                                 fn_2b7105c
## ShowDragHandTutorial(bool isShow) -> void
---- Clicker.KeycapMakerController::ShowDragHandTutorial 0x2d62830
02d62830: str     x30, [sp, #-0x30]!                         
02d62834: stp     x22, x21, [sp, #0x10]                      
02d62838: stp     x20, x19, [sp, #0x20]                      
02d6283c: adrp    x21, #0x6630000                            
02d62840: adrp    x22, #0x6266000                            
02d62844: mov     w19, w1                                    
02d62848: ldrb    w8, [x21, #0x385]                          
02d6284c: ldr     x22, [x22, #0x658]                         MS:MonoSingleton`1::get_Instance
02d62850: mov     x20, x0                                    
02d62854: tbnz    w8, #0, #0x2d62878                         
02d62858: adrp    x0, #0x6266000                             
02d6285c: ldr     x0, [x0, #0x750]                           MS:DataManager::GetData
02d62860: bl      #0x2b70db0                                 fn_2b70db0
02d62864: adrp    x0, #0x6266000                             
02d62868: ldr     x0, [x0, #0x658]                           MS:MonoSingleton`1::get_Instance
02d6286c: bl      #0x2b70db0                                 fn_2b70db0
02d62870: mov     w8, #1                                     
02d62874: strb    w8, [x21, #0x385]                          
02d62878: ldr     x0, [x22]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d6287c: bl      #0x3769600                                 fn_3769600
02d62880: cbz     x0, #0x2d628f0                             
02d62884: adrp    x8, #0x6266000                             
02d62888: ldr     x8, [x8, #0x750]                           MS:DataManager::GetData
02d6288c: ldr     x1, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d62890: bl      #0x3168dd0                                 fn_3168dd0
02d62894: cbz     x0, #0x2d628f0                             
02d62898: ldr     x8, [x0, #0x20]                            S:'inter_ad_capping_time' ._baseKeycapId
02d6289c: cbz     x8, #0x2d628f0                             
02d628a0: ldrb    w8, [x8, #0x3b]                            
02d628a4: cbz     w8, #0x2d628c8                             
02d628a8: ldr     x0, [x20, #0xf0]                           ._dragHandTutorial
02d628ac: tbz     w19, #0, #0x2d628d8                        
02d628b0: cbz     x0, #0x2d628f0                             
02d628b4: ldp     x20, x19, [sp, #0x20]                      
02d628b8: mov     x1, xzr                                    
02d628bc: ldp     x22, x21, [sp, #0x10]                      
02d628c0: ldr     x30, [sp], #0x30                           
02d628c4: b       #0x2d747ac                                 Clicker.TutorialDrag::Show
02d628c8: ldp     x20, x19, [sp, #0x20]                      
02d628cc: ldp     x22, x21, [sp, #0x10]                      
02d628d0: ldr     x30, [sp], #0x30                           
02d628d4: ret                                                
02d628d8: cbz     x0, #0x2d628f0                             
02d628dc: ldp     x20, x19, [sp, #0x20]                      
02d628e0: mov     x1, xzr                                    
02d628e4: ldp     x22, x21, [sp, #0x10]                      
02d628e8: ldr     x30, [sp], #0x30                           
02d628ec: b       #0x2d74a1c                                 Clicker.TutorialDrag::Hide
02d628f0: bl      #0x2b7105c                                 fn_2b7105c
## CallRemoveKeycapAt(int index) -> void
---- Clicker.KeycapMakerController::CallRemoveKeycapAt 0x2d61ad8
02d61ad8: ldr     x0, [x0, #0xa0]                            ._baseKeycapObject
02d61adc: cbz     x0, #0x2d61ae4                             
02d61ae0: b       #0x2d60014                                 Clicker.BaseKeycapObject::PullBackKeycap
02d61ae4: str     x30, [sp, #-0x10]!                         
02d61ae8: bl      #0x2b7105c                                 fn_2b7105c
## TrySaveKeycapToDatabase() -> void
---- Clicker.KeycapMakerController::TrySaveKeycapToDatabase 0x2d6dc34
02d6dc34: stp     x30, x21, [sp, #-0x20]!                    
02d6dc38: stp     x20, x19, [sp, #0x10]                      
02d6dc3c: adrp    x20, #0x6630000                            
02d6dc40: adrp    x21, #0x626c000                            
02d6dc44: mov     x19, x0                                    
02d6dc48: ldrb    w8, [x20, #0x386]                          
02d6dc4c: ldr     x21, [x21, #0x498]                         T:Clicker.KeycapMakerController/<>c__DisplayClass83_0
02d6dc50: tbnz    w8, #0, #0x2d6dcbc                         
02d6dc54: adrp    x0, #0x6264000                             
02d6dc58: ldr     x0, [x0, #0xf90]                           T:System.Action
02d6dc5c: bl      #0x2b70db0                                 fn_2b70db0
02d6dc60: adrp    x0, #0x6266000                             
02d6dc64: ldr     x0, [x0, #0x6b0]                           T:ClickerSaveDataItem
02d6dc68: bl      #0x2b70db0                                 fn_2b70db0
02d6dc6c: adrp    x0, #0x6269000                             
02d6dc70: ldr     x0, [x0, #0x3f8]                           MS:DataManager::GetData
02d6dc74: bl      #0x2b70db0                                 fn_2b70db0
02d6dc78: adrp    x0, #0x6267000                             
02d6dc7c: ldr     x0, [x0, #0xbd0]                           MS:MonoSingleton`1::get_Instance
02d6dc80: bl      #0x2b70db0                                 fn_2b70db0
02d6dc84: adrp    x0, #0x6266000                             
02d6dc88: ldr     x0, [x0, #0x658]                           MS:MonoSingleton`1::get_Instance
02d6dc8c: bl      #0x2b70db0                                 fn_2b70db0
02d6dc90: adrp    x0, #0x626c000                             
02d6dc94: ldr     x0, [x0, #0x4a0]                           M:Clicker.KeycapMakerController/<>c__DisplayClass83_0::<TrySaveKeycapToDatabase>b__0
02d6dc98: bl      #0x2b70db0                                 fn_2b70db0
02d6dc9c: adrp    x0, #0x626c000                             
02d6dca0: ldr     x0, [x0, #0x498]                           T:Clicker.KeycapMakerController/<>c__DisplayClass83_0
02d6dca4: bl      #0x2b70db0                                 fn_2b70db0
02d6dca8: adrp    x0, #0x626c000                             
02d6dcac: ldr     x0, [x0, #0x4a8]                           MS:UIManager::ShowPopup
02d6dcb0: bl      #0x2b70db0                                 fn_2b70db0
02d6dcb4: mov     w8, #1                                     
02d6dcb8: strb    w8, [x20, #0x386]                          
02d6dcbc: ldr     x0, [x21]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d6dcc0: bl      #0x2b7104c                                 fn_2b7104c
02d6dcc4: mov     x1, xzr                                    
02d6dcc8: mov     x20, x0                                    
02d6dccc: bl      #0x2d6e600                                 Clicker.KeycapMakerController/<>c__DisplayClass83_0::.ctor
02d6dcd0: cbz     x20, #0x2d6de0c                            
02d6dcd4: adrp    x21, #0x6266000                            
02d6dcd8: mov     x0, x20                                    
02d6dcdc: mov     x1, x19                                    
02d6dce0: ldr     x21, [x21, #0x658]                         MS:MonoSingleton`1::get_Instance
02d6dce4: str     x19, [x0, #0x18]!                          
02d6dce8: bl      #0x2b70d54                                 fn_2b70d54
02d6dcec: ldr     x0, [x21]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d6dcf0: bl      #0x3769600                                 fn_3769600
02d6dcf4: cbz     x0, #0x2d6de0c                             
02d6dcf8: adrp    x8, #0x6269000                             
02d6dcfc: ldr     x8, [x8, #0x3f8]                           MS:DataManager::GetData
02d6dd00: ldr     x1, [x8]                                   T:Trading.TradingSession/<>c__DisplayClass56_0
02d6dd04: bl      #0x3168dd0                                 fn_3168dd0
02d6dd08: mov     x21, x20                                   
02d6dd0c: mov     x1, x0                                     
02d6dd10: str     x0, [x21, #0x10]!                          
02d6dd14: mov     x0, x21                                    
02d6dd18: bl      #0x2b70d54                                 fn_2b70d54
02d6dd1c: ldr     x0, [x21]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d6dd20: cbz     x0, #0x2d6de0c                             
02d6dd24: mov     x1, xzr                                    
02d6dd28: bl      #0x2ca97f8                                 DataClicker::CanAddNewKeycap
02d6dd2c: tbz     w0, #0, #0x2d6dd98                         
02d6dd30: adrp    x8, #0x6266000                             
02d6dd34: ldr     x8, [x8, #0x6b0]                           T:ClickerSaveDataItem
02d6dd38: ldr     x0, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d6dd3c: bl      #0x2b7104c                                 fn_2b7104c
02d6dd40: mov     x1, xzr                                    
02d6dd44: mov     x20, x0                                    
02d6dd48: bl      #0x2ca8bd4                                 ClickerSaveDataItem::.ctor
02d6dd4c: cbz     x20, #0x2d6de0c                            
02d6dd50: ldr     q0, [x19, #0x20]                           ._baseKeycapId
02d6dd54: ldr     x0, [x19, #0xa0]                           ._baseKeycapObject
02d6dd58: stur    q0, [x20, #0x14]                           
02d6dd5c: ldr     w8, [x19, #0x30]                           ._keychainId
02d6dd60: str     w8, [x20, #0x24]                           ._switchId
02d6dd64: cbz     x0, #0x2d6de0c                             
02d6dd68: bl      #0x2d60470                                 Clicker.BaseKeycapObject::GetDecorData
02d6dd6c: mov     x1, x0                                     
02d6dd70: mov     x0, x20                                    
02d6dd74: str     x1, [x0, #0x28]!                           ._keycapId
02d6dd78: bl      #0x2b70d54                                 fn_2b70d54
02d6dd7c: ldr     x0, [x21]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d6dd80: cbz     x0, #0x2d6de0c                             
02d6dd84: mov     x1, x20                                    
02d6dd88: ldp     x20, x19, [sp, #0x10]                      
02d6dd8c: mov     x2, xzr                                    
02d6dd90: ldp     x30, x21, [sp], #0x20                      
02d6dd94: b       #0x2ca8f48                                 DataClicker::RegisterNewKeycap
02d6dd98: adrp    x8, #0x6267000                             
02d6dd9c: ldr     x8, [x8, #0xbd0]                           MS:MonoSingleton`1::get_Instance
02d6dda0: ldr     x0, [x8]                                   S:'didu'
02d6dda4: bl      #0x3769600                                 fn_3769600
02d6dda8: cbz     x0, #0x2d6de0c                             
02d6ddac: adrp    x8, #0x626c000                             
02d6ddb0: ldr     x8, [x8, #0x4a8]                           MS:UIManager::ShowPopup
02d6ddb4: ldr     x1, [x8]                                   M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d6ddb8: bl      #0x33fbfac                                 fn_33fbfac
02d6ddbc: adrp    x8, #0x6264000                             
02d6ddc0: mov     x19, x0                                    
02d6ddc4: ldr     x8, [x8, #0xf90]                           T:System.Action
02d6ddc8: ldr     x8, [x8]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d6ddcc: mov     x0, x8                                     
02d6ddd0: bl      #0x2b7104c                                 fn_2b7104c
02d6ddd4: adrp    x8, #0x626c000                             
02d6ddd8: mov     x1, x20                                    
02d6dddc: mov     x3, xzr                                    
02d6dde0: ldr     x8, [x8, #0x4a0]                           M:Clicker.KeycapMakerController/<>c__DisplayClass83_0::<TrySaveKeycapToDatabase>b__0
02d6dde4: mov     x21, x0                                    
02d6dde8: ldr     x2, [x8]                                   M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d6ddec: bl      #0x4d8ddbc                                 System.Action::.ctor
02d6ddf0: cbz     x19, #0x2d6de0c                            
02d6ddf4: mov     x0, x19                                    
02d6ddf8: ldp     x20, x19, [sp, #0x10]                      
02d6ddfc: mov     x1, x21                                    
02d6de00: mov     w2, #0x1f4                                 
02d6de04: ldp     x30, x21, [sp], #0x20                      
02d6de08: b       #0x2d672bc                                 Clicker.CollectionFullPopup::SetEventCallback
02d6de0c: bl      #0x2b7105c                                 fn_2b7105c
## .ctor() -> void
---- Clicker.KeycapMakerController::.ctor 0x2d6de10
02d6de10: stp     x30, x21, [sp, #-0x20]!                    
02d6de14: stp     x20, x19, [sp, #0x10]                      
02d6de18: adrp    x20, #0x6630000                            
02d6de1c: adrp    x21, #0x626c000                            
02d6de20: mov     x19, x0                                    
02d6de24: ldrb    w8, [x20, #0x387]                          
02d6de28: ldr     x21, [x21, #0x4b0]                         MS:MonoSingleton`1::.ctor
02d6de2c: tbnz    w8, #0, #0x2d6de44                         
02d6de30: adrp    x0, #0x626c000                             
02d6de34: ldr     x0, [x0, #0x4b0]                           MS:MonoSingleton`1::.ctor
02d6de38: bl      #0x2b70db0                                 fn_2b70db0
02d6de3c: mov     w8, #1                                     
02d6de40: strb    w8, [x20, #0x387]                          
02d6de44: mov     x0, x19                                    
02d6de48: ldp     x20, x19, [sp, #0x10]                      
02d6de4c: ldr     x1, [x21]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d6de50: ldp     x30, x21, [sp], #0x20                      
02d6de54: b       #0x3769e18                                 
## <ShowResult>b__67_0() -> void
---- Clicker.KeycapMakerController::<ShowResult>b__67_0 0x2d6de58
02d6de58: str     x30, [sp, #-0x40]!                         
02d6de5c: stp     x24, x23, [sp, #0x10]                      
02d6de60: stp     x22, x21, [sp, #0x20]                      
02d6de64: stp     x20, x19, [sp, #0x30]                      
02d6de68: adrp    x23, #0x6266000                            
02d6de6c: adrp    x24, #0x6630000                            
02d6de70: adrp    x20, #0x6264000                            
02d6de74: adrp    x21, #0x626c000                            
02d6de78: adrp    x22, #0x6266000                            
02d6de7c: ldr     x23, [x23, #0x880]                         MS:DG.Tweening.TweenSettingsExtensions::SetEase
02d6de80: ldr     x20, [x20, #0xe8]                          T:DG.Tweening.TweenCallback ._pointerHandTutorial
02d6de84: ldrb    w8, [x24, #0x388]                          
02d6de88: ldr     x21, [x21, #0x4b8]                         M:Clicker.KeycapMakerController::<ShowResult>b__67_1
02d6de8c: ldr     x22, [x22, #0x928]                         MS:DG.Tweening.TweenSettingsExtensions::OnComplete
02d6de90: mov     x19, x0                                    
02d6de94: tbnz    w8, #0, #0x2d6ded0                         
02d6de98: adrp    x0, #0x626c000                             
02d6de9c: ldr     x0, [x0, #0x4b8]                           M:Clicker.KeycapMakerController::<ShowResult>b__67_1
02d6dea0: bl      #0x2b70db0                                 fn_2b70db0
02d6dea4: adrp    x0, #0x6264000                             
02d6dea8: ldr     x0, [x0, #0xe8]                            T:DG.Tweening.TweenCallback ._pointerHandTutorial
02d6deac: bl      #0x2b70db0                                 fn_2b70db0
02d6deb0: adrp    x0, #0x6266000                             
02d6deb4: ldr     x0, [x0, #0x928]                           MS:DG.Tweening.TweenSettingsExtensions::OnComplete
02d6deb8: bl      #0x2b70db0                                 fn_2b70db0
02d6debc: adrp    x0, #0x6266000                             
02d6dec0: ldr     x0, [x0, #0x880]                           MS:DG.Tweening.TweenSettingsExtensions::SetEase
02d6dec4: bl      #0x2b70db0                                 fn_2b70db0
02d6dec8: mov     w8, #1                                     
02d6decc: strb    w8, [x24, #0x388]                          
02d6ded0: adrp    x8, #0x1084000                             
02d6ded4: fmov    s1, #0.50000000                            
02d6ded8: ldr     x0, [x19, #0x110]                          ._srBG
02d6dedc: ldr     s0, [x8, #0xddc]                           [1084ddc]=c77fe0003f733333 f=0.95,-65504
02d6dee0: mov     x1, xzr                                    
02d6dee4: bl      #0x2c77d0c                                 DG.Tweening.DOTweenModuleSprite::DOFade
02d6dee8: fmov    s0, #1.00000000                            
02d6deec: fmov    s1, #0.50000000                            
02d6def0: ldr     x0, [x19, #0x118]                          ._tfFinalEffect
02d6def4: mov     x1, xzr                                    
02d6def8: bl      #0x2d98c98                                 DG.Tweening.ShortcutExtensions::DOScale
02d6defc: ldr     x2, [x23]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d6df00: mov     w1, #0x1b                                  
02d6df04: bl      #0x336fa0c                                 fn_336fa0c
02d6df08: ldr     x8, [x20]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d6df0c: mov     x20, x0                                    
02d6df10: mov     x0, x8                                     
02d6df14: bl      #0x2b7104c                                 fn_2b7104c
02d6df18: ldr     x2, [x21]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d6df1c: mov     x1, x19                                    
02d6df20: mov     x3, xzr                                    
02d6df24: mov     x21, x0                                    
02d6df28: bl      #0x2d89dc4                                 DG.Tweening.TweenCallback::.ctor
02d6df2c: ldr     x2, [x22]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d6df30: mov     x0, x20                                    
02d6df34: mov     x1, x21                                    
02d6df38: ldp     x20, x19, [sp, #0x30]                      
02d6df3c: ldp     x22, x21, [sp, #0x20]                      
02d6df40: ldp     x24, x23, [sp, #0x10]                      
02d6df44: ldr     x30, [sp], #0x40                           
02d6df48: b       #0x336f26c                                 
## <ShowResult>b__67_1() -> void
---- Clicker.KeycapMakerController::<ShowResult>b__67_1 0x2d6df4c
02d6df4c: str     x30, [sp, #-0x20]!                         
02d6df50: stp     x20, x19, [sp, #0x10]                      
02d6df54: adrp    x20, #0x6630000                            
02d6df58: mov     x19, x0                                    
02d6df5c: ldrb    w8, [x20, #0x389]                          
02d6df60: tbnz    w8, #0, #0x2d6df84                         
02d6df64: adrp    x0, #0x6267000                             
02d6df68: ldr     x0, [x0, #0xbd0]                           MS:MonoSingleton`1::get_Instance
02d6df6c: bl      #0x2b70db0                                 fn_2b70db0
02d6df70: adrp    x0, #0x626c000                             
02d6df74: ldr     x0, [x0, #0x4c0]                           MS:UIManager::ShowPopup
02d6df78: bl      #0x2b70db0                                 fn_2b70db0
02d6df7c: mov     w8, #1                                     
02d6df80: strb    w8, [x20, #0x389]                          
02d6df84: ldr     x0, [x19, #0xa0]                           ._baseKeycapObject
02d6df88: cbz     x0, #0x2d6dfd4                             
02d6df8c: adrp    x20, #0x6267000                            
02d6df90: mov     w1, wzr                                    
02d6df94: ldr     x20, [x20, #0xbd0]                         MS:MonoSingleton`1::get_Instance
02d6df98: bl      #0x2d5cae8                                 Clicker.BaseKeycapObject::TurnModeSetup
02d6df9c: ldr     x0, [x20]                                  S:'didu'
02d6dfa0: bl      #0x3769600                                 fn_3769600
02d6dfa4: cbz     x0, #0x2d6dfd4                             
02d6dfa8: adrp    x8, #0x626c000                             
02d6dfac: ldr     x8, [x8, #0x4c0]                           MS:UIManager::ShowPopup
02d6dfb0: ldr     x1, [x8]                                   M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d6dfb4: bl      #0x33fbfac                                 fn_33fbfac
02d6dfb8: mov     x0, x19                                    
02d6dfbc: bl      #0x2d6c770                                 Clicker.KeycapMakerController::ShowWallBG
02d6dfc0: mov     x0, x19                                    
02d6dfc4: ldp     x20, x19, [sp, #0x10]                      
02d6dfc8: mov     w1, #1                                     
02d6dfcc: ldr     x30, [sp], #0x20                           
02d6dfd0: b       #0x2d6c0cc                                 Clicker.KeycapMakerController::SetMultipleInput
02d6dfd4: bl      #0x2b7105c                                 fn_2b7105c
## <MoveTrayToLowPos>b__71_0() -> void
---- Clicker.KeycapMakerController::<MoveTrayToLowPos>b__71_0 0x2d6dfd8
02d6dfd8: stp     x30, x19, [sp, #-0x10]!                    
02d6dfdc: mov     x19, x0                                    
02d6dfe0: ldr     x0, [x0, #0xc8]                            ._dragManager
02d6dfe4: cbz     x0, #0x2d6e00c                             
02d6dfe8: bl      #0x2d61f4c                                 Clicker.DragManager::UpdateFallbackPosition
02d6dfec: ldr     x0, [x19, #0xc8]                           ._dragManager
02d6dff0: cbz     x0, #0x2d6e00c                             
02d6dff4: mov     w1, #1                                     
02d6dff8: bl      #0x2d61d74                                 Clicker.DragManager::SetDraggable
02d6dffc: mov     x0, x19                                    
02d6e000: mov     w1, #1                                     
02d6e004: ldp     x30, x19, [sp], #0x10                      
02d6e008: b       #0x2d62830                                 Clicker.KeycapMakerController::ShowDragHandTutorial
02d6e00c: bl      #0x2b7105c                                 fn_2b7105c
## <AutoClickRandomTime>b__78_0() -> void
---- Clicker.KeycapMakerController::<AutoClickRandomTime>b__78_0 0x2d6e010
02d6e010: ldr     x0, [x0, #0xa0]                            ._baseKeycapObject
02d6e014: cbz     x0, #0x2d6e01c                             
02d6e018: b       #0x2d605a8                                 Clicker.BaseKeycapObject::ClickRandomKeycap
02d6e01c: str     x30, [sp, #-0x10]!                         
02d6e020: bl      #0x2b7105c                                 fn_2b7105c
