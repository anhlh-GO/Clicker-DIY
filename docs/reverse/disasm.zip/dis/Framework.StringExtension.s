#### CLASS Framework.StringExtension parent= object
## IsMatchWith(string this, string comparedString, Framework.EStringMatchType matchType) -> bool
---- Framework.StringExtension::IsMatchWith 0x2cba130
02cba130: cmp     w2, #1                                     
02cba134: b.eq    #0x2cba15c                                 
02cba138: cmp     w2, #2                                     
02cba13c: b.eq    #0x2cba150                                 
02cba140: cmp     w2, #3                                     
02cba144: b.ne    #0x2cba164                                 
02cba148: mov     w2, #1                                     
02cba14c: b       #0x2cba178                                 Framework.StringExtension::Contains
02cba150: cbz     x0, #0x2cba170                             
02cba154: mov     x2, xzr                                    
02cba158: b       #0x4cab570                                 System.String::Contains
02cba15c: mov     w2, #5                                     
02cba160: b       #0x2cba168                                 
02cba164: mov     w2, #4                                     
02cba168: mov     x3, xzr                                    
02cba16c: b       #0x4ca5010                                 System.String::Equals
02cba170: str     x30, [sp, #-0x10]!                         
02cba174: bl      #0x2b7105c                                 fn_2b7105c
## Contains(string this, string comparedString, bool ignoreCase) -> bool
---- Framework.StringExtension::Contains 0x2cba178
02cba178: str     x30, [sp, #-0x20]!                         
02cba17c: stp     x20, x19, [sp, #0x10]                      
02cba180: mov     x19, x1                                    
02cba184: mov     x20, x0                                    
02cba188: tbz     w2, #0, #0x2cba1b4                         
02cba18c: cbz     x19, #0x2cba1d0                            
02cba190: mov     x0, x19                                    
02cba194: mov     x1, xzr                                    
02cba198: bl      #0x4caaecc                                 System.String::ToLower
02cba19c: cbz     x20, #0x2cba1d0                            
02cba1a0: mov     x19, x0                                    
02cba1a4: mov     x0, x20                                    
02cba1a8: mov     x1, xzr                                    
02cba1ac: bl      #0x4caaecc                                 System.String::ToLower
02cba1b0: mov     x20, x0                                    
02cba1b4: cbz     x20, #0x2cba1d0                            
02cba1b8: mov     x0, x20                                    
02cba1bc: mov     x1, x19                                    
02cba1c0: mov     x2, xzr                                    
02cba1c4: ldp     x20, x19, [sp, #0x10]                      
02cba1c8: ldr     x30, [sp], #0x20                           
02cba1cc: b       #0x4cab570                                 System.String::Contains
02cba1d0: bl      #0x2b7105c                                 fn_2b7105c
## SplitCamelCase(string camelCaseString) -> string
---- Framework.StringExtension::SplitCamelCase 0x2cba1d4
02cba1d4: str     x30, [sp, #-0x30]!                         
02cba1d8: stp     x22, x21, [sp, #0x10]                      
02cba1dc: stp     x20, x19, [sp, #0x20]                      
02cba1e0: adrp    x20, #0x662f000                            
02cba1e4: mov     x19, x0                                    
02cba1e8: ldrb    w8, [x20, #0xbec]                          
02cba1ec: tbnz    w8, #0, #0x2cba228                         
02cba1f0: adrp    x0, #0x6266000                             
02cba1f4: ldr     x0, [x0, #0xea0]                           T:System.Text.RegularExpressions.Regex
02cba1f8: bl      #0x2b70db0                                 fn_2b70db0
02cba1fc: adrp    x0, #0x6266000                             
02cba200: ldr     x0, [x0, #0xea8]                           S:'(\\P{Ll})(\\P{Ll}\\p{Ll})'
02cba204: bl      #0x2b70db0                                 fn_2b70db0
02cba208: adrp    x0, #0x6266000                             
02cba20c: ldr     x0, [x0, #0xeb0]                           S:'$1 $2'
02cba210: bl      #0x2b70db0                                 fn_2b70db0
02cba214: adrp    x0, #0x6266000                             
02cba218: ldr     x0, [x0, #0xeb8]                           S:'(\\p{Ll})(\\P{Ll})'
02cba21c: bl      #0x2b70db0                                 fn_2b70db0
02cba220: mov     w8, #1                                     
02cba224: strb    w8, [x20, #0xbec]                          
02cba228: mov     x0, x19                                    
02cba22c: mov     x1, xzr                                    
02cba230: bl      #0x4ca6234                                 System.String::IsNullOrEmpty
02cba234: tbnz    w0, #0, #0x2cba2f4                         
02cba238: adrp    x8, #0x6266000                             
02cba23c: adrp    x22, #0x6266000                            
02cba240: adrp    x20, #0x6266000                            
02cba244: ldr     x8, [x8, #0xea0]                           T:System.Text.RegularExpressions.Regex
02cba248: adrp    x21, #0x6266000                            
02cba24c: ldr     x0, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cba250: ldr     x22, [x22, #0xea8]                         S:'(\\P{Ll})(\\P{Ll}\\p{Ll})'
02cba254: ldr     x20, [x20, #0xeb0]                         S:'$1 $2'
02cba258: ldr     w8, [x0, #0xe4]                            [62660e4]=0 f=0,0
02cba25c: ldr     x21, [x21, #0xeb8]                         S:'(\\p{Ll})(\\P{Ll})'
02cba260: cbnz    w8, #0x2cba268                             
02cba264: bl      #0x2b70f30                                 fn_2b70f30
02cba268: ldr     x1, [x22]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cba26c: ldr     x2, [x20]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cba270: mov     x0, x19                                    
02cba274: mov     x3, xzr                                    
02cba278: bl      #0x5386608                                 System.Text.RegularExpressions.Regex::Replace
02cba27c: ldr     x1, [x21]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cba280: ldr     x2, [x20]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cba284: mov     x3, xzr                                    
02cba288: bl      #0x5386608                                 System.Text.RegularExpressions.Regex::Replace
02cba28c: cbz     x0, #0x2cba308                             
02cba290: mov     w1, wzr                                    
02cba294: mov     w2, #1                                     
02cba298: mov     x3, xzr                                    
02cba29c: mov     x20, x0                                    
02cba2a0: bl      #0x4ca8a80                                 System.String::Substring
02cba2a4: cbz     x0, #0x2cba308                             
02cba2a8: mov     x1, xzr                                    
02cba2ac: bl      #0x4cab048                                 System.String::ToUpper
02cba2b0: cbz     x19, #0x2cba308                            
02cba2b4: ldr     w8, [x19, #0x10]                           
02cba2b8: mov     x21, x0                                    
02cba2bc: cmp     w8, #2                                     
02cba2c0: b.lt    #0x2cba2f0                                 
02cba2c4: mov     x0, x20                                    
02cba2c8: mov     w1, #1                                     
02cba2cc: mov     x2, xzr                                    
02cba2d0: bl      #0x4caad78                                 System.String::Substring
02cba2d4: mov     x1, x0                                     
02cba2d8: mov     x0, x21                                    
02cba2dc: mov     x2, xzr                                    
02cba2e0: ldp     x20, x19, [sp, #0x20]                      
02cba2e4: ldp     x22, x21, [sp, #0x10]                      
02cba2e8: ldr     x30, [sp], #0x30                           
02cba2ec: b       #0x4c9c514                                 System.String::Concat
02cba2f0: mov     x19, x21                                   
02cba2f4: mov     x0, x19                                    
02cba2f8: ldp     x20, x19, [sp, #0x20]                      
02cba2fc: ldp     x22, x21, [sp, #0x10]                      
02cba300: ldr     x30, [sp], #0x30                           
02cba304: ret                                                
02cba308: bl      #0x2b7105c                                 fn_2b7105c
## CapitalizeFirstChar(string input) -> string
---- Framework.StringExtension::CapitalizeFirstChar 0x2cba30c
02cba30c: stp     x30, x21, [sp, #-0x20]!                    
02cba310: stp     x20, x19, [sp, #0x10]                      
02cba314: cbz     x0, #0x2cba3c4                             
02cba318: mov     w1, wzr                                    
02cba31c: mov     x2, xzr                                    
02cba320: mov     x20, x0                                    
02cba324: bl      #0x4ca0d58                                 System.String::get_Chars
02cba328: adrp    x21, #0x6263000                            
02cba32c: mov     w19, w0                                    
02cba330: ldr     x21, [x21, #0x970]                         &6645c70(=0)
02cba334: ldr     x8, [x21, #0x88]                           &2c5d934(=d65f03c0d503245f)
02cba338: ldr     w9, [x8, #0xe4]                            
02cba33c: cbnz    w9, #0x2cba348                             
02cba340: mov     x0, x8                                     
02cba344: bl      #0x2b70f30                                 fn_2b70f30
02cba348: mov     w0, w19                                    
02cba34c: mov     x1, xzr                                    
02cba350: bl      #0x4d93fe0                                 System.Char::IsUpper
02cba354: tbz     w0, #0, #0x2cba368                         
02cba358: mov     x0, x20                                    
02cba35c: ldp     x20, x19, [sp, #0x10]                      
02cba360: ldp     x30, x21, [sp], #0x20                      
02cba364: ret                                                
02cba368: mov     x0, x20                                    
02cba36c: mov     x1, xzr                                    
02cba370: bl      #0x4ca6140                                 System.String::ToCharArray
02cba374: ldr     x8, [x21, #0x88]                           &2c5d934(=d65f03c0d503245f)
02cba378: mov     x20, x0                                    
02cba37c: ldr     w9, [x8, #0xe4]                            
02cba380: cbnz    w9, #0x2cba38c                             
02cba384: mov     x0, x8                                     
02cba388: bl      #0x2b70f30                                 fn_2b70f30
02cba38c: mov     w0, w19                                    
02cba390: mov     x1, xzr                                    
02cba394: bl      #0x4d94308                                 System.Char::ToUpper
02cba398: cbz     x20, #0x2cba40c                            
02cba39c: ldr     w9, [x20, #0x18]                           
02cba3a0: cbz     w9, #0x2cba410                             
02cba3a4: mov     w8, w0                                     
02cba3a8: mov     x1, x20                                    
02cba3ac: mov     x0, xzr                                    
02cba3b0: strh    w8, [x20, #0x20]                           
02cba3b4: ldp     x20, x19, [sp, #0x10]                      
02cba3b8: mov     x2, xzr                                    
02cba3bc: ldp     x30, x21, [sp], #0x20                      
02cba3c0: b       #0x4ca3ae4                                 System.String::CreateString
02cba3c4: adrp    x0, #0x6266000                             
02cba3c8: ldr     x0, [x0, #0xec0]                           T:System.ArgumentNullException
02cba3cc: bl      #0x2b70dc4                                 fn_2b70dc4
02cba3d0: bl      #0x2b7104c                                 fn_2b7104c
02cba3d4: mov     x19, x0                                    
02cba3d8: adrp    x0, #0x6266000                             
02cba3dc: ldr     x0, [x0, #0xec8]                           S:'input'
02cba3e0: bl      #0x2b70dc4                                 fn_2b70dc4
02cba3e4: mov     x1, x0                                     
02cba3e8: mov     x0, x19                                    
02cba3ec: mov     x2, xzr                                    
02cba3f0: bl      #0x4d87a40                                 System.ArgumentNullException::.ctor
02cba3f4: adrp    x0, #0x6266000                             
02cba3f8: ldr     x0, [x0, #0xed0]                           M:Framework.StringExtension::CapitalizeFirstChar
02cba3fc: bl      #0x2b70dc4                                 fn_2b70dc4
02cba400: mov     x1, x0                                     
02cba404: mov     x0, x19                                    
02cba408: bl      #0x2b70f20                                 fn_2b70f20
02cba40c: bl      #0x2b7105c                                 fn_2b7105c
02cba410: bl      #0x2b71064                                 fn_2b71064
## TryParseToFloat(string this) -> float
---- Framework.StringExtension::TryParseToFloat 0x2cba414
02cba414: sub     sp, sp, #0x30                              
02cba418: stp     x30, x21, [sp, #0x10]                      
02cba41c: stp     x20, x19, [sp, #0x20]                      
02cba420: adrp    x21, #0x662f000                            
02cba424: adrp    x20, #0x6264000                            
02cba428: mov     x19, x0                                    
02cba42c: ldrb    w8, [x21, #0xbed]                          
02cba430: ldr     x20, [x20, #0x6a8]                         T:System.Globalization.CultureInfo
02cba434: tbnz    w8, #0, #0x2cba44c                         
02cba438: adrp    x0, #0x6264000                             
02cba43c: ldr     x0, [x0, #0x6a8]                           T:System.Globalization.CultureInfo
02cba440: bl      #0x2b70db0                                 fn_2b70db0
02cba444: mov     w8, #1                                     
02cba448: strb    w8, [x21, #0xbed]                          
02cba44c: ldr     x0, [x20]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02cba450: str     wzr, [sp, #0xc]                            
02cba454: ldr     w8, [x0, #0xe4]                            [62640e4]=0 f=0,0
02cba458: cbnz    w8, #0x2cba460                             
02cba45c: bl      #0x2b70f30                                 fn_2b70f30
02cba460: mov     x0, xzr                                    
02cba464: bl      #0x4d9ea74                                 System.Globalization.CultureInfo::get_InvariantCulture
02cba468: cbz     x0, #0x2cba4b4                             
02cba46c: ldr     x8, [x0]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02cba470: ldr     x9, [x8, #0x218]                           
02cba474: ldr     x1, [x8, #0x220]                           
02cba478: blr     x9                                         
02cba47c: mov     x2, x0                                     
02cba480: add     x3, sp, #0xc                               
02cba484: mov     x0, x19                                    
02cba488: mov     w1, #0xa7                                  
02cba48c: mov     x4, xzr                                    
02cba490: bl      #0x4e24f40                                 System.Single::TryParse
02cba494: movi    d0, #0000000000000000                      
02cba498: ldr     s1, [sp, #0xc]                             
02cba49c: tst     w0, #1                                     
02cba4a0: ldp     x20, x19, [sp, #0x20]                      
02cba4a4: ldp     x30, x21, [sp, #0x10]                      
02cba4a8: fcsel   s0, s1, s0, ne                             
02cba4ac: add     sp, sp, #0x30                              
02cba4b0: ret                                                
02cba4b4: bl      #0x2b7105c                                 fn_2b7105c
