#### CLASS BlindBagCollection.BlindbagCollectionData/<>c__DisplayClass4_0 parent= object
#   field boxsetType                     BlindBagCollection.CollectionBoxsetType            off=0x10 attr=6 
## .ctor() -> void
---- BlindBagCollection.BlindbagCollectionData/<>c__DisplayClass4_0::.ctor 0x2d364bc
02d364bc: mov     x1, xzr                                    
02d364c0: b       #0x4e53e9c                                 System.Object::.ctor
## <Unlock>b__0(BlindBagCollection.BoxsetData x) -> bool
---- BlindBagCollection.BlindbagCollectionData/<>c__DisplayClass4_0::<Unlock>b__0 0x2d36660
02d36660: cbz     x1, #0x2d36678                             
02d36664: ldr     w8, [x1, #0x10]                            
02d36668: ldr     w9, [x0, #0x10]                            .boxsetType
02d3666c: cmp     w8, w9                                     
02d36670: cset    w0, eq                                     
02d36674: ret                                                
02d36678: str     x30, [sp, #-0x10]!                         
02d3667c: bl      #0x2b7105c                                 fn_2b7105c
#### CLASS BlindBagCollection.BlindbagCollectionData/<>c__DisplayClass5_0 parent= object
#   field boxsetType                     BlindBagCollection.CollectionBoxsetType            off=0x10 attr=6 
## .ctor() -> void
---- BlindBagCollection.BlindbagCollectionData/<>c__DisplayClass5_0::.ctor 0x2d364cc
02d364cc: mov     x1, xzr                                    
02d364d0: b       #0x4e53e9c                                 System.Object::.ctor
## <IsUnlocked>b__0(BlindBagCollection.BoxsetData x) -> bool
---- BlindBagCollection.BlindbagCollectionData/<>c__DisplayClass5_0::<IsUnlocked>b__0 0x2d36680
02d36680: cbz     x1, #0x2d36698                             
02d36684: ldr     w8, [x1, #0x10]                            
02d36688: ldr     w9, [x0, #0x10]                            .boxsetType
02d3668c: cmp     w8, w9                                     
02d36690: cset    w0, eq                                     
02d36694: ret                                                
02d36698: str     x30, [sp, #-0x10]!                         
02d3669c: bl      #0x2b7105c                                 fn_2b7105c
#### CLASS BlindBagCollection.BlindbagCollectionData/<>c__DisplayClass6_0 parent= object
#   field boxsetType                     BlindBagCollection.CollectionBoxsetType            off=0x10 attr=6 
## .ctor() -> void
---- BlindBagCollection.BlindbagCollectionData/<>c__DisplayClass6_0::.ctor 0x2d36650
02d36650: mov     x1, xzr                                    
02d36654: b       #0x4e53e9c                                 System.Object::.ctor
## <IsBoxsetCompleted>b__0(BlindBagCollection.BoxsetData x) -> bool
---- BlindBagCollection.BlindbagCollectionData/<>c__DisplayClass6_0::<IsBoxsetCompleted>b__0 0x2d366a0
02d366a0: cbz     x1, #0x2d366b8                             
02d366a4: ldr     w8, [x1, #0x10]                            
02d366a8: ldr     w9, [x0, #0x10]                            .boxsetType
02d366ac: cmp     w8, w9                                     
02d366b0: cset    w0, eq                                     
02d366b4: ret                                                
02d366b8: str     x30, [sp, #-0x10]!                         
02d366bc: bl      #0x2b7105c                                 fn_2b7105c
#### CLASS BlindBagCollection.BlindbagCollectionData parent= GameData
#   field _dataSave                      BlindBagCollection.BlindbagCollectionDataSave      off=0x20 attr=1 SerializeField
## SaveData() -> void
---- BlindBagCollection.BlindbagCollectionData::SaveData 0x2d36044
02d36044: stp     x30, x21, [sp, #-0x20]!                    
02d36048: stp     x20, x19, [sp, #0x10]                      
02d3604c: adrp    x20, #0x6630000                            
02d36050: adrp    x21, #0x6266000                            
02d36054: mov     x19, x0                                    
02d36058: ldrb    w8, [x20, #0x118]                          
02d3605c: ldr     x21, [x21, #0x658]                         MS:MonoSingleton`1::get_Instance
02d36060: tbnz    w8, #0, #0x2d36084                         
02d36064: adrp    x0, #0x626a000                             
02d36068: ldr     x0, [x0, #0xaa0]                           MS:DataManager::SaveData
02d3606c: bl      #0x2b70db0                                 fn_2b70db0
02d36070: adrp    x0, #0x6266000                             
02d36074: ldr     x0, [x0, #0x658]                           MS:MonoSingleton`1::get_Instance
02d36078: bl      #0x2b70db0                                 fn_2b70db0
02d3607c: mov     w8, #1                                     
02d36080: strb    w8, [x20, #0x118]                          
02d36084: ldr     x0, [x21]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d36088: bl      #0x3769600                                 fn_3769600
02d3608c: ldr     x8, [x19]                                  
02d36090: mov     x20, x0                                    
02d36094: mov     x0, x19                                    
02d36098: ldr     x9, [x8, #0x2a8]                           
02d3609c: ldr     x1, [x8, #0x2b0]                           
02d360a0: blr     x9                                         
02d360a4: cbz     x20, #0x2d360cc                            
02d360a8: adrp    x8, #0x626a000                             
02d360ac: mov     x1, x0                                     
02d360b0: mov     x0, x20                                    
02d360b4: ldr     x8, [x8, #0xaa0]                           MS:DataManager::SaveData
02d360b8: ldr     x2, [x19, #0x20]                           ._dataSave
02d360bc: ldp     x20, x19, [sp, #0x10]                      
02d360c0: ldr     x3, [x8]                                   T:type56879(k15)
02d360c4: ldp     x30, x21, [sp], #0x20                      
02d360c8: b       #0x3169790                                 
02d360cc: bl      #0x2b7105c                                 fn_2b7105c
## LoadData() -> void
---- BlindBagCollection.BlindbagCollectionData::LoadData 0x2d360d0
02d360d0: stp     x30, x21, [sp, #-0x20]!                    
02d360d4: stp     x20, x19, [sp, #0x10]                      
02d360d8: adrp    x20, #0x6630000                            
02d360dc: adrp    x21, #0x6266000                            
02d360e0: mov     x19, x0                                    
02d360e4: ldrb    w8, [x20, #0x119]                          
02d360e8: ldr     x21, [x21, #0x658]                         MS:MonoSingleton`1::get_Instance
02d360ec: tbnz    w8, #0, #0x2d36110                         
02d360f0: adrp    x0, #0x626a000                             
02d360f4: ldr     x0, [x0, #0xaa8]                           MS:DataManager::LoadData
02d360f8: bl      #0x2b70db0                                 fn_2b70db0
02d360fc: adrp    x0, #0x6266000                             
02d36100: ldr     x0, [x0, #0x658]                           MS:MonoSingleton`1::get_Instance
02d36104: bl      #0x2b70db0                                 fn_2b70db0
02d36108: mov     w8, #1                                     
02d3610c: strb    w8, [x20, #0x119]                          
02d36110: ldr     x0, [x21]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d36114: bl      #0x3769600                                 fn_3769600
02d36118: ldr     x8, [x19]                                  
02d3611c: mov     x20, x0                                    
02d36120: mov     x0, x19                                    
02d36124: ldr     x9, [x8, #0x2a8]                           
02d36128: ldr     x1, [x8, #0x2b0]                           
02d3612c: blr     x9                                         
02d36130: cbz     x20, #0x2d36164                            
02d36134: adrp    x8, #0x626a000                             
02d36138: mov     x1, x0                                     
02d3613c: mov     x0, x20                                    
02d36140: ldr     x8, [x8, #0xaa8]                           MS:DataManager::LoadData
02d36144: ldr     x2, [x8]                                   T:type56879(k15)
02d36148: bl      #0x31690b0                                 fn_31690b0
02d3614c: str     x0, [x19, #0x20]!                          ._dataSave
02d36150: mov     x1, x0                                     
02d36154: mov     x0, x19                                    
02d36158: ldp     x20, x19, [sp, #0x10]                      
02d3615c: ldp     x30, x21, [sp], #0x20                      
02d36160: b       #0x2b70d54                                 
02d36164: bl      #0x2b7105c                                 fn_2b7105c
## NewData() -> void
---- BlindBagCollection.BlindbagCollectionData::NewData 0x2d36168
02d36168: stp     x30, x23, [sp, #-0x30]!                    
02d3616c: stp     x22, x21, [sp, #0x10]                      
02d36170: stp     x20, x19, [sp, #0x20]                      
02d36174: adrp    x20, #0x6630000                            
02d36178: adrp    x23, #0x626a000                            
02d3617c: adrp    x22, #0x626a000                            
02d36180: adrp    x21, #0x626a000                            
02d36184: ldr     x23, [x23, #0xab0]                         T:BlindBagCollection.BlindbagCollectionDataSave
02d36188: ldrb    w8, [x20, #0x11a]                          
02d3618c: ldr     x22, [x22, #0xab8]                         T:type56639(k15)
02d36190: ldr     x21, [x21, #0xac0]                         MS:System.Collections.Generic.List`1::.ctor
02d36194: mov     x19, x0                                    
02d36198: tbnz    w8, #0, #0x2d361c8                         
02d3619c: adrp    x0, #0x626a000                             
02d361a0: ldr     x0, [x0, #0xab0]                           T:BlindBagCollection.BlindbagCollectionDataSave
02d361a4: bl      #0x2b70db0                                 fn_2b70db0
02d361a8: adrp    x0, #0x626a000                             
02d361ac: ldr     x0, [x0, #0xac0]                           MS:System.Collections.Generic.List`1::.ctor
02d361b0: bl      #0x2b70db0                                 fn_2b70db0
02d361b4: adrp    x0, #0x626a000                             
02d361b8: ldr     x0, [x0, #0xab8]                           T:type56639(k15)
02d361bc: bl      #0x2b70db0                                 fn_2b70db0
02d361c0: mov     w8, #1                                     
02d361c4: strb    w8, [x20, #0x11a]                          
02d361c8: ldr     x0, [x23]                                  T:type56879(k15)
02d361cc: bl      #0x2b7104c                                 fn_2b7104c
02d361d0: mov     x1, xzr                                    
02d361d4: mov     x20, x0                                    
02d361d8: bl      #0x4e53e9c                                 System.Object::.ctor
02d361dc: ldr     x0, [x22]                                  T:type56879(k15)
02d361e0: bl      #0x2b7104c                                 fn_2b7104c
02d361e4: ldr     x1, [x21]                                  T:type56879(k15)
02d361e8: mov     x21, x0                                    
02d361ec: bl      #0x35a89a4                                 fn_35a89a4
02d361f0: cbz     x20, #0x2d36220                            
02d361f4: mov     x0, x20                                    
02d361f8: mov     x1, x21                                    
02d361fc: str     x21, [x0, #0x10]!                          
02d36200: bl      #0x2b70d54                                 fn_2b70d54
02d36204: str     x20, [x19, #0x20]!                         ._dataSave
02d36208: mov     x0, x19                                    
02d3620c: mov     x1, x20                                    
02d36210: ldp     x20, x19, [sp, #0x20]                      
02d36214: ldp     x22, x21, [sp, #0x10]                      
02d36218: ldp     x30, x23, [sp], #0x30                      
02d3621c: b       #0x2b70d54                                 
02d36220: bl      #0x2b7105c                                 fn_2b7105c
## Unlock(BlindBagCollection.CollectionBoxsetType boxsetType, BlindBagCollection.CollectionItemType itemType) -> void
---- BlindBagCollection.BlindbagCollectionData::Unlock 0x2d3622c
02d3622c: stp     x30, x23, [sp, #-0x30]!                    
02d36230: stp     x22, x21, [sp, #0x10]                      
02d36234: stp     x20, x19, [sp, #0x20]                      
02d36238: adrp    x22, #0x6630000                            
02d3623c: adrp    x23, #0x626a000                            
02d36240: mov     w19, w2                                    
02d36244: ldrb    w8, [x22, #0x11b]                          
02d36248: ldr     x23, [x23, #0xac8]                         T:BlindBagCollection.BlindbagCollectionData/<>c__DisplayClass4_0
02d3624c: mov     w21, w1                                    
02d36250: mov     x20, x0                                    
02d36254: tbnz    w8, #0, #0x2d362d8                         
02d36258: adrp    x0, #0x626a000                             
02d3625c: ldr     x0, [x0, #0xad0]                           T:BlindBagCollection.BoxsetData
02d36260: bl      #0x2b70db0                                 fn_2b70db0
02d36264: adrp    x0, #0x626a000                             
02d36268: ldr     x0, [x0, #0xad8]                           MS:System.Collections.Generic.List`1::Add
02d3626c: bl      #0x2b70db0                                 fn_2b70db0
02d36270: adrp    x0, #0x626a000                             
02d36274: ldr     x0, [x0, #0xae0]                           MS:System.Collections.Generic.List`1::Add
02d36278: bl      #0x2b70db0                                 fn_2b70db0
02d3627c: adrp    x0, #0x626a000                             
02d36280: ldr     x0, [x0, #0x9c0]                           MS:System.Collections.Generic.List`1::Contains
02d36284: bl      #0x2b70db0                                 fn_2b70db0
02d36288: adrp    x0, #0x626a000                             
02d3628c: ldr     x0, [x0, #0x9c8]                           MS:System.Collections.Generic.List`1::Find
02d36290: bl      #0x2b70db0                                 fn_2b70db0
02d36294: adrp    x0, #0x626a000                             
02d36298: ldr     x0, [x0, #0xae8]                           MS:System.Collections.Generic.List`1::.ctor
02d3629c: bl      #0x2b70db0                                 fn_2b70db0
02d362a0: adrp    x0, #0x626a000                             
02d362a4: ldr     x0, [x0, #0xaf0]                           T:type56657(k15)
02d362a8: bl      #0x2b70db0                                 fn_2b70db0
02d362ac: adrp    x0, #0x626a000                             
02d362b0: ldr     x0, [x0, #0x9d0]                           T:type57226(k15)
02d362b4: bl      #0x2b70db0                                 fn_2b70db0
02d362b8: adrp    x0, #0x626a000                             
02d362bc: ldr     x0, [x0, #0xaf8]                           M:BlindBagCollection.BlindbagCollectionData/<>c__DisplayClass4_0::<Unlock>b__0
02d362c0: bl      #0x2b70db0                                 fn_2b70db0
02d362c4: adrp    x0, #0x626a000                             
02d362c8: ldr     x0, [x0, #0xac8]                           T:BlindBagCollection.BlindbagCollectionData/<>c__DisplayClass4_0
02d362cc: bl      #0x2b70db0                                 fn_2b70db0
02d362d0: mov     w8, #1                                     
02d362d4: strb    w8, [x22, #0x11b]                          
02d362d8: ldr     x0, [x23]                                  T:type56879(k15)
02d362dc: bl      #0x2b7104c                                 fn_2b7104c
02d362e0: mov     x1, xzr                                    
02d362e4: mov     x22, x0                                    
02d362e8: bl      #0x4e53e9c                                 System.Object::.ctor
02d362ec: cbz     x22, #0x2d364b8                            
02d362f0: ldr     x8, [x20, #0x20]                           ._dataSave
02d362f4: str     w21, [x22, #0x10]                          
02d362f8: cbz     x8, #0x2d364b8                             
02d362fc: adrp    x9, #0x626a000                             
02d36300: adrp    x23, #0x626a000                            
02d36304: ldr     x9, [x9, #0x9d0]                           T:type57226(k15)
02d36308: ldr     x23, [x23, #0xaf8]                         M:BlindBagCollection.BlindbagCollectionData/<>c__DisplayClass4_0::<Unlock>b__0
02d3630c: ldr     x21, [x8, #0x10]                           
02d36310: ldr     x0, [x9]                                   T:type56879(k15)
02d36314: bl      #0x2b7104c                                 fn_2b7104c
02d36318: ldr     x2, [x23]                                  T:type56879(k15)
02d3631c: mov     x1, x22                                    
02d36320: mov     x3, xzr                                    
02d36324: mov     x23, x0                                    
02d36328: bl      #0x399ba10                                 fn_399ba10
02d3632c: cbz     x21, #0x2d364b8                            
02d36330: adrp    x8, #0x626a000                             
02d36334: mov     x0, x21                                    
02d36338: mov     x1, x23                                    
02d3633c: ldr     x8, [x8, #0x9c8]                           MS:System.Collections.Generic.List`1::Find
02d36340: ldr     x2, [x8]                                   T:type56879(k15)
02d36344: bl      #0x35a9868                                 fn_35a9868
02d36348: mov     x21, x0                                    
02d3634c: cbnz    x0, #0x2d36420                             
02d36350: adrp    x8, #0x626a000                             
02d36354: ldr     x8, [x8, #0xad0]                           T:BlindBagCollection.BoxsetData
02d36358: ldr     x0, [x8]                                   T:type56879(k15)
02d3635c: bl      #0x2b7104c                                 fn_2b7104c
02d36360: mov     x1, xzr                                    
02d36364: mov     x21, x0                                    
02d36368: bl      #0x4e53e9c                                 System.Object::.ctor
02d3636c: cbz     x21, #0x2d364b8                            
02d36370: adrp    x8, #0x626a000                             
02d36374: ldr     x8, [x8, #0xaf0]                           T:type56657(k15)
02d36378: ldr     w9, [x22, #0x10]                           
02d3637c: ldr     x0, [x8]                                   T:type56879(k15)
02d36380: str     w9, [x21, #0x10]                           
02d36384: bl      #0x2b7104c                                 fn_2b7104c
02d36388: adrp    x8, #0x626a000                             
02d3638c: mov     x22, x0                                    
02d36390: ldr     x8, [x8, #0xae8]                           MS:System.Collections.Generic.List`1::.ctor
02d36394: ldr     x1, [x8]                                   T:type56879(k15)
02d36398: bl      #0x356bce8                                 fn_356bce8
02d3639c: mov     x0, x21                                    
02d363a0: mov     x1, x22                                    
02d363a4: str     x22, [x0, #0x18]!                          
02d363a8: bl      #0x2b70d54                                 fn_2b70d54
02d363ac: ldr     x8, [x20, #0x20]                           ._dataSave
02d363b0: cbz     x8, #0x2d364b8                             
02d363b4: ldr     x0, [x8, #0x10]                            T:Decor.DataDecor/CategoryData
02d363b8: cbz     x0, #0x2d364b8                             
02d363bc: adrp    x9, #0x626a000                             
02d363c0: ldr     x9, [x9, #0xae0]                           MS:System.Collections.Generic.List`1::Add
02d363c4: ldr     w10, [x0, #0x1c]                           [626a01c]=0 f=0,0
02d363c8: ldr     x8, [x0, #0x10]                            T:Decor.DataDecor/CategoryData
02d363cc: ldr     x9, [x9]                                   T:type56879(k15)
02d363d0: add     w10, w10, #1                               
02d363d4: str     w10, [x0, #0x1c]                           
02d363d8: cbz     x8, #0x2d364b8                             
02d363dc: ldrsw   x10, [x0, #0x18]                           
02d363e0: ldr     w11, [x8, #0x18]                           MS:System.Collections.Generic.List`1::Add
02d363e4: cmp     w10, w11                                   
02d363e8: b.hs    #0x2d3640c                                 
02d363ec: add     x8, x8, x10, lsl #3                        &626a000
02d363f0: add     w9, w10, #1                                
02d363f4: mov     x1, x21                                    
02d363f8: str     w9, [x0, #0x18]                            
02d363fc: str     x21, [x8, #0x20]!                          
02d36400: mov     x0, x8                                     
02d36404: bl      #0x2b70d54                                 fn_2b70d54
02d36408: b       #0x2d36420                                 
02d3640c: ldr     x8, [x9, #0x20]                            M:Decor.DataDecor/<>c__DisplayClass8_0::<NewData>b__0
02d36410: mov     x1, x21                                    
02d36414: ldr     x8, [x8, #0xc0]                            S:'Main character is null'
02d36418: ldr     x2, [x8, #0x70]                            MS:System.Collections.Generic.List`1::FindIndex
02d3641c: bl      #0x35a920c                                 fn_35a920c
02d36420: ldr     x0, [x21, #0x18]                           
02d36424: cbz     x0, #0x2d364b8                             
02d36428: adrp    x8, #0x626a000                             
02d3642c: mov     w1, w19                                    
02d36430: ldr     x8, [x8, #0x9c0]                           MS:System.Collections.Generic.List`1::Contains
02d36434: ldr     x2, [x8]                                   T:type56879(k15)
02d36438: bl      #0x356c8f8                                 fn_356c8f8
02d3643c: tbnz    w0, #0, #0x2d36488                         
02d36440: ldr     x0, [x21, #0x18]                           
02d36444: cbz     x0, #0x2d364b8                             
02d36448: adrp    x9, #0x626a000                             
02d3644c: ldr     x9, [x9, #0xad8]                           MS:System.Collections.Generic.List`1::Add
02d36450: ldr     w10, [x0, #0x1c]                           [626a01c]=0 f=0,0
02d36454: ldr     x8, [x0, #0x10]                            T:Decor.DataDecor/CategoryData
02d36458: ldr     x9, [x9]                                   T:type56879(k15)
02d3645c: add     w10, w10, #1                               
02d36460: str     w10, [x0, #0x1c]                           
02d36464: cbz     x8, #0x2d364b8                             
02d36468: ldrsw   x10, [x0, #0x18]                           
02d3646c: ldr     w11, [x8, #0x18]                           MS:System.Collections.Generic.List`1::Add
02d36470: cmp     w10, w11                                   
02d36474: b.hs    #0x2d36498                                 
02d36478: add     x8, x8, x10, lsl #2                        &626a000
02d3647c: add     w9, w10, #1                                
02d36480: str     w9, [x0, #0x18]                            
02d36484: str     w19, [x8, #0x20]                           
02d36488: ldp     x20, x19, [sp, #0x20]                      
02d3648c: ldp     x22, x21, [sp, #0x10]                      
02d36490: ldp     x30, x23, [sp], #0x30                      
02d36494: ret                                                
02d36498: ldr     x8, [x9, #0x20]                            M:Decor.DataDecor/<>c__DisplayClass8_0::<NewData>b__0
02d3649c: mov     w1, w19                                    
02d364a0: ldp     x20, x19, [sp, #0x20]                      
02d364a4: ldr     x8, [x8, #0xc0]                            S:'Main character is null'
02d364a8: ldp     x22, x21, [sp, #0x10]                      
02d364ac: ldr     x2, [x8, #0x70]                            MS:System.Collections.Generic.List`1::FindIndex
02d364b0: ldp     x30, x23, [sp], #0x30                      
02d364b4: b       #0x356c578                                 
02d364b8: bl      #0x2b7105c                                 fn_2b7105c
## IsUnlocked(BlindBagCollection.CollectionBoxsetType boxsetType, BlindBagCollection.CollectionItemType itemType) -> bool
---- BlindBagCollection.BlindbagCollectionData::IsUnlocked 0x2d3521c
02d3521c: stp     x30, x23, [sp, #-0x30]!                    
02d35220: stp     x22, x21, [sp, #0x10]                      
02d35224: stp     x20, x19, [sp, #0x20]                      
02d35228: adrp    x22, #0x6630000                            
02d3522c: adrp    x23, #0x626a000                            
02d35230: mov     w19, w2                                    
02d35234: ldrb    w8, [x22, #0x11c]                          
02d35238: ldr     x23, [x23, #0x9b8]                         T:BlindBagCollection.BlindbagCollectionData/<>c__DisplayClass5_0
02d3523c: mov     w20, w1                                    
02d35240: mov     x21, x0                                    
02d35244: tbnz    w8, #0, #0x2d3528c                         
02d35248: adrp    x0, #0x626a000                             
02d3524c: ldr     x0, [x0, #0x9c0]                           MS:System.Collections.Generic.List`1::Contains
02d35250: bl      #0x2b70db0                                 fn_2b70db0
02d35254: adrp    x0, #0x626a000                             
02d35258: ldr     x0, [x0, #0x9c8]                           MS:System.Collections.Generic.List`1::Find
02d3525c: bl      #0x2b70db0                                 fn_2b70db0
02d35260: adrp    x0, #0x626a000                             
02d35264: ldr     x0, [x0, #0x9d0]                           T:type57226(k15)
02d35268: bl      #0x2b70db0                                 fn_2b70db0
02d3526c: adrp    x0, #0x626a000                             
02d35270: ldr     x0, [x0, #0x9d8]                           M:BlindBagCollection.BlindbagCollectionData/<>c__DisplayClass5_0::<IsUnlocked>b__0
02d35274: bl      #0x2b70db0                                 fn_2b70db0
02d35278: adrp    x0, #0x626a000                             
02d3527c: ldr     x0, [x0, #0x9b8]                           T:BlindBagCollection.BlindbagCollectionData/<>c__DisplayClass5_0
02d35280: bl      #0x2b70db0                                 fn_2b70db0
02d35284: mov     w8, #1                                     
02d35288: strb    w8, [x22, #0x11c]                          
02d3528c: ldr     x0, [x23]                                  T:type56879(k15)
02d35290: bl      #0x2b7104c                                 fn_2b7104c
02d35294: mov     x1, xzr                                    
02d35298: mov     x22, x0                                    
02d3529c: bl      #0x4e53e9c                                 System.Object::.ctor
02d352a0: cbz     x22, #0x2d35338                            
02d352a4: ldr     x8, [x21, #0x20]                           ._dataSave
02d352a8: str     w20, [x22, #0x10]                          
02d352ac: cbz     x8, #0x2d35338                             
02d352b0: adrp    x9, #0x626a000                             
02d352b4: adrp    x21, #0x626a000                            
02d352b8: ldr     x9, [x9, #0x9d0]                           T:type57226(k15)
02d352bc: ldr     x21, [x21, #0x9d8]                         M:BlindBagCollection.BlindbagCollectionData/<>c__DisplayClass5_0::<IsUnlocked>b__0
02d352c0: ldr     x20, [x8, #0x10]                           
02d352c4: ldr     x0, [x9]                                   T:type56879(k15)
02d352c8: bl      #0x2b7104c                                 fn_2b7104c
02d352cc: ldr     x2, [x21]                                  T:type56879(k15)
02d352d0: mov     x1, x22                                    
02d352d4: mov     x3, xzr                                    
02d352d8: mov     x21, x0                                    
02d352dc: bl      #0x399ba10                                 fn_399ba10
02d352e0: cbz     x20, #0x2d35338                            
02d352e4: adrp    x8, #0x626a000                             
02d352e8: mov     x0, x20                                    
02d352ec: mov     x1, x21                                    
02d352f0: ldr     x8, [x8, #0x9c8]                           MS:System.Collections.Generic.List`1::Find
02d352f4: ldr     x2, [x8]                                   T:type56879(k15)
02d352f8: bl      #0x35a9868                                 fn_35a9868
02d352fc: cbz     x0, #0x2d35328                             
02d35300: ldr     x0, [x0, #0x18]                            MS:System.Collections.Generic.List`1::Add
02d35304: cbz     x0, #0x2d35338                             
02d35308: adrp    x8, #0x626a000                             
02d3530c: mov     w1, w19                                    
02d35310: ldr     x8, [x8, #0x9c0]                           MS:System.Collections.Generic.List`1::Contains
02d35314: ldp     x20, x19, [sp, #0x20]                      
02d35318: ldp     x22, x21, [sp, #0x10]                      
02d3531c: ldr     x2, [x8]                                   T:type56879(k15)
02d35320: ldp     x30, x23, [sp], #0x30                      
02d35324: b       #0x356c8f8                                 
02d35328: ldp     x20, x19, [sp, #0x20]                      
02d3532c: ldp     x22, x21, [sp, #0x10]                      
02d35330: ldp     x30, x23, [sp], #0x30                      
02d35334: ret                                                
02d35338: bl      #0x2b7105c                                 fn_2b7105c
## IsBoxsetCompleted(BlindBagCollection.CollectionBoxsetType boxsetType) -> bool
---- BlindBagCollection.BlindbagCollectionData::IsBoxsetCompleted 0x2d364d4
02d364d4: str     x30, [sp, #-0x30]!                         
02d364d8: stp     x22, x21, [sp, #0x10]                      
02d364dc: stp     x20, x19, [sp, #0x20]                      
02d364e0: adrp    x21, #0x6630000                            
02d364e4: adrp    x22, #0x626a000                            
02d364e8: mov     w19, w1                                    
02d364ec: ldrb    w8, [x21, #0x11d]                          
02d364f0: ldr     x22, [x22, #0xb00]                         T:BlindBagCollection.BlindbagCollectionData/<>c__DisplayClass6_0
02d364f4: mov     x20, x0                                    
02d364f8: tbnz    w8, #0, #0x2d3654c                         
02d364fc: adrp    x0, #0x626a000                             
02d36500: ldr     x0, [x0, #0x8f8]                           T:BlindBagCollection.CollectionItemType
02d36504: bl      #0x2b70db0                                 fn_2b70db0
02d36508: adrp    x0, #0x626a000                             
02d3650c: ldr     x0, [x0, #0x9c8]                           MS:System.Collections.Generic.List`1::Find
02d36510: bl      #0x2b70db0                                 fn_2b70db0
02d36514: adrp    x0, #0x626a000                             
02d36518: ldr     x0, [x0, #0xb08]                           MS:System.Collections.Generic.List`1::get_Count
02d3651c: bl      #0x2b70db0                                 fn_2b70db0
02d36520: adrp    x0, #0x626a000                             
02d36524: ldr     x0, [x0, #0x9d0]                           T:type57226(k15)
02d36528: bl      #0x2b70db0                                 fn_2b70db0
02d3652c: adrp    x0, #0x626a000                             
02d36530: ldr     x0, [x0, #0xb10]                           M:BlindBagCollection.BlindbagCollectionData/<>c__DisplayClass6_0::<IsBoxsetCompleted>b__0
02d36534: bl      #0x2b70db0                                 fn_2b70db0
02d36538: adrp    x0, #0x626a000                             
02d3653c: ldr     x0, [x0, #0xb00]                           T:BlindBagCollection.BlindbagCollectionData/<>c__DisplayClass6_0
02d36540: bl      #0x2b70db0                                 fn_2b70db0
02d36544: mov     w8, #1                                     
02d36548: strb    w8, [x21, #0x11d]                          
02d3654c: ldr     x0, [x22]                                  T:type56879(k15)
02d36550: bl      #0x2b7104c                                 fn_2b7104c
02d36554: mov     x1, xzr                                    
02d36558: mov     x21, x0                                    
02d3655c: bl      #0x4e53e9c                                 System.Object::.ctor
02d36560: cbz     x21, #0x2d3664c                            
02d36564: ldr     x8, [x20, #0x20]                           ._dataSave
02d36568: str     w19, [x21, #0x10]                          
02d3656c: cbz     x8, #0x2d3664c                             
02d36570: adrp    x9, #0x626a000                             
02d36574: adrp    x20, #0x626a000                            
02d36578: ldr     x9, [x9, #0x9d0]                           T:type57226(k15)
02d3657c: ldr     x20, [x20, #0xb10]                         M:BlindBagCollection.BlindbagCollectionData/<>c__DisplayClass6_0::<IsBoxsetCompleted>b__0
02d36580: ldr     x19, [x8, #0x10]                           
02d36584: ldr     x0, [x9]                                   T:type56879(k15)
02d36588: bl      #0x2b7104c                                 fn_2b7104c
02d3658c: ldr     x2, [x20]                                  T:type56879(k15)
02d36590: mov     x1, x21                                    
02d36594: mov     x3, xzr                                    
02d36598: mov     x20, x0                                    
02d3659c: bl      #0x399ba10                                 fn_399ba10
02d365a0: cbz     x19, #0x2d3664c                            
02d365a4: adrp    x8, #0x626a000                             
02d365a8: adrp    x22, #0x626a000                            
02d365ac: mov     x0, x19                                    
02d365b0: ldr     x8, [x8, #0x9c8]                           MS:System.Collections.Generic.List`1::Find
02d365b4: ldr     x22, [x22, #0x8f8]                         T:BlindBagCollection.CollectionItemType
02d365b8: mov     x1, x20                                    
02d365bc: ldr     x2, [x8]                                   T:type56879(k15)
02d365c0: bl      #0x35a9868                                 fn_35a9868
02d365c4: adrp    x21, #0x6263000                            
02d365c8: mov     x19, x0                                    
02d365cc: ldr     x21, [x21, #0x970]                         &6645c70(=0)
02d365d0: ldr     x20, [x22]                                 T:type56879(k15)
02d365d4: ldr     x8, [x21, #0xe0]                           &2c5bf4c(=a9be7bfdd503233f)
02d365d8: ldr     w9, [x8, #0xe4]                            [626a0e4]=0 f=0,0
02d365dc: cbnz    w9, #0x2d365e8                             
02d365e0: mov     x0, x8                                     
02d365e4: bl      #0x2b70f30                                 fn_2b70f30
02d365e8: mov     x0, x20                                    
02d365ec: mov     x1, xzr                                    
02d365f0: bl      #0x4e20e5c                                 System.Type::GetTypeFromHandle
02d365f4: ldr     x8, [x21, #0x98]                           [6263098]=0 f=0,0
02d365f8: mov     x20, x0                                    
02d365fc: ldr     w9, [x8, #0xe4]                            [626a0e4]=0 f=0,0
02d36600: cbnz    w9, #0x2d3660c                             
02d36604: mov     x0, x8                                     
02d36608: bl      #0x2b70f30                                 fn_2b70f30
02d3660c: mov     x0, x20                                    
02d36610: mov     x1, xzr                                    
02d36614: bl      #0x4e4676c                                 System.Enum::GetValues
02d36618: cbz     x0, #0x2d3664c                             
02d3661c: mov     x1, xzr                                    
02d36620: bl      #0x4e2ad14                                 System.Array::get_Length
02d36624: cbz     x19, #0x2d3664c                            
02d36628: ldr     x8, [x19, #0x18]                           
02d3662c: cbz     x8, #0x2d3664c                             
02d36630: ldr     w8, [x8, #0x18]                            MS:System.Collections.Generic.List`1::Add
02d36634: ldp     x20, x19, [sp, #0x20]                      
02d36638: ldp     x22, x21, [sp, #0x10]                      
02d3663c: cmp     w8, w0                                     
02d36640: cset    w0, ge                                     
02d36644: ldr     x30, [sp], #0x30                           
02d36648: ret                                                
02d3664c: bl      #0x2b7105c                                 fn_2b7105c
## .ctor() -> void
---- BlindBagCollection.BlindbagCollectionData::.ctor 0x2d36658
02d36658: mov     x1, xzr                                    
02d3665c: b       #0x2ca9988                                 GameData::.ctor
