#### CLASS IAPPurchaseResult parent= int
#   field value__                        int                                                off=0x10 attr=606 
#   field Success                        IAPPurchaseResult                                  off=0x0 attr=8056 
#   field Pending                        IAPPurchaseResult                                  off=0x0 attr=8056 
#   field Failed                         IAPPurchaseResult                                  off=0x0 attr=8056 
#   field NotInitialized                 IAPPurchaseResult                                  off=0x0 attr=8056 
