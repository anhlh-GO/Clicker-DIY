#### CLASS Clicker.SelectKeycapPanel/<>c__DisplayClass13_0 parent= object
#   field dataUser                       DataUser                                           off=0x10 attr=6 
#   field <>4__this                      Clicker.SelectKeycapPanel                          off=0x18 attr=6 
## .ctor() -> void
---- Clicker.SelectKeycapPanel/<>c__DisplayClass13_0::.ctor 0x2d72aa8
02d72aa8: mov     x1, xzr                                    
02d72aac: b       #0x4e53e9c                                 System.Object::.ctor
#### CLASS Clicker.SelectKeycapPanel/<>c__DisplayClass13_1 parent= object
#   field index                          int                                                off=0x10 attr=6 
#   field CS$<>8__locals1                Clicker.SelectKeycapPanel/<>c__DisplayClass13_0    off=0x18 attr=6 
## .ctor() -> void
---- Clicker.SelectKeycapPanel/<>c__DisplayClass13_1::.ctor 0x2d72ab0
02d72ab0: mov     x1, xzr                                    
02d72ab4: b       #0x4e53e9c                                 System.Object::.ctor
## <LoadData>b__0(int id) -> void
---- Clicker.SelectKeycapPanel/<>c__DisplayClass13_1::<LoadData>b__0 0x2d72d84
02d72d84: stp     x30, x21, [sp, #-0x20]!                    
02d72d88: stp     x20, x19, [sp, #0x10]                      
02d72d8c: adrp    x21, #0x6630000                            
02d72d90: mov     w19, w1                                    
02d72d94: mov     x20, x0                                    
02d72d98: ldrb    w8, [x21, #0x3bc]                          
02d72d9c: tbnz    w8, #0, #0x2d72dc0                         
02d72da0: adrp    x0, #0x626c000                             
02d72da4: ldr     x0, [x0, #0x648]                           MS:System.Collections.Generic.List`1::get_Item
02d72da8: bl      #0x2b70db0                                 fn_2b70db0
02d72dac: adrp    x0, #0x626b000                             
02d72db0: ldr     x0, [x0, #0xee0]                           MS:MonoSingleton`1::get_Instance
02d72db4: bl      #0x2b70db0                                 fn_2b70db0
02d72db8: mov     w8, #1                                     
02d72dbc: strb    w8, [x21, #0x3bc]                          
02d72dc0: ldr     x8, [x20, #0x18]                           .CS$<>8__locals1
02d72dc4: cbz     x8, #0x2d72eb8                             
02d72dc8: ldr     x0, [x8, #0x10]                            
02d72dcc: cbz     x0, #0x2d72eb8                             
02d72dd0: adrp    x21, #0x626b000                            
02d72dd4: mov     w1, w19                                    
02d72dd8: mov     x2, xzr                                    
02d72ddc: ldr     x21, [x21, #0xee0]                         MS:MonoSingleton`1::get_Instance
02d72de0: bl      #0x2cac034                                 DataUser::UnlockClickerKeycap
02d72de4: ldr     x0, [x21]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d72de8: bl      #0x3769600                                 fn_3769600
02d72dec: cbz     x0, #0x2d72eb8                             
02d72df0: mov     w1, w19                                    
02d72df4: mov     x2, xzr                                    
02d72df8: bl      #0x2d6cb30                                 Clicker.KeycapMakerController::SpawnKeycap
02d72dfc: ldr     x8, [x20, #0x18]                           .CS$<>8__locals1
02d72e00: cbz     x8, #0x2d72eb8                             
02d72e04: ldr     x8, [x8, #0x18]                            
02d72e08: cbz     x8, #0x2d72eb8                             
02d72e0c: ldr     x0, [x8, #0x58]                            
02d72e10: cbz     x0, #0x2d72eb8                             
02d72e14: mov     w1, #1                                     
02d72e18: mov     x2, xzr                                    
02d72e1c: bl      #0x2d6519c                                 Clicker.IngameClickerScreen::ShowBtnNext
02d72e20: ldr     x8, [x20, #0x18]                           .CS$<>8__locals1
02d72e24: cbz     x8, #0x2d72eb8                             
02d72e28: ldr     x8, [x8, #0x18]                            
02d72e2c: cbz     x8, #0x2d72eb8                             
02d72e30: ldr     x0, [x8, #0x28]                            
02d72e34: cbz     x0, #0x2d72eb8                             
02d72e38: adrp    x9, #0x626c000                             
02d72e3c: ldr     x9, [x9, #0x648]                           MS:System.Collections.Generic.List`1::get_Item
02d72e40: ldr     w1, [x20, #0x10]                           .index
02d72e44: ldr     x21, [x8, #0x58]                           
02d72e48: ldr     x2, [x9]                                   M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d72e4c: bl      #0x35a8f3c                                 fn_35a8f3c
02d72e50: cbz     x0, #0x2d72eb8                             
02d72e54: mov     x1, xzr                                    
02d72e58: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02d72e5c: cbz     x21, #0x2d72eb8                            
02d72e60: mov     x1, x0                                     
02d72e64: mov     x0, x21                                    
02d72e68: mov     x2, xzr                                    
02d72e6c: bl      #0x2d6bae4                                 Clicker.IngameClickerScreen::ShowPopupColor
02d72e70: ldr     x8, [x20, #0x18]                           .CS$<>8__locals1
02d72e74: cbz     x8, #0x2d72eb8                             
02d72e78: ldr     x0, [x8, #0x18]                            
02d72e7c: cbz     x0, #0x2d72eb8                             
02d72e80: mov     w1, w19                                    
02d72e84: bl      #0x2d72ab8                                 Clicker.SelectKeycapPanel::OnItemSelect
02d72e88: ldr     x8, [x20, #0x18]                           .CS$<>8__locals1
02d72e8c: cbz     x8, #0x2d72eb8                             
02d72e90: ldr     x8, [x8, #0x18]                            
02d72e94: cbz     x8, #0x2d72eb8                             
02d72e98: ldr     x0, [x8, #0x58]                            
02d72e9c: mov     w9, #1                                     
02d72ea0: strb    w9, [x8, #0x60]                            
02d72ea4: cbz     x0, #0x2d72eb8                             
02d72ea8: ldp     x20, x19, [sp, #0x10]                      
02d72eac: mov     x1, xzr                                    
02d72eb0: ldp     x30, x21, [sp], #0x20                      
02d72eb4: b       #0x2d6a9a4                                 Clicker.IngameClickerScreen::HideTutorial
02d72eb8: bl      #0x2b7105c                                 fn_2b7105c
#### CLASS Clicker.SelectKeycapPanel/<>c__DisplayClass14_0 parent= object
#   field id                             int                                                off=0x10 attr=6 
## .ctor() -> void
---- Clicker.SelectKeycapPanel/<>c__DisplayClass14_0::.ctor 0x2d72b90
02d72b90: mov     x1, xzr                                    
02d72b94: b       #0x4e53e9c                                 System.Object::.ctor
## <OnItemSelect>b__0(Clicker.KeycapUIItem item) -> void
---- Clicker.SelectKeycapPanel/<>c__DisplayClass14_0::<OnItemSelect>b__0 0x2d72ebc
02d72ebc: str     x30, [sp, #-0x20]!                         
02d72ec0: stp     x20, x19, [sp, #0x10]                      
02d72ec4: cbz     x1, #0x2d72f20                             
02d72ec8: mov     x19, x1                                    
02d72ecc: mov     x20, x0                                    
02d72ed0: mov     x0, x1                                     
02d72ed4: mov     x1, xzr                                    
02d72ed8: bl      #0x5b339ec                                 UnityEngine.Component::get_gameObject
02d72edc: cbz     x0, #0x2d72f20                             
02d72ee0: mov     x1, xzr                                    
02d72ee4: bl      #0x5b36bfc                                 UnityEngine.GameObject::get_activeSelf
02d72ee8: tbz     w0, #0, #0x2d72f14                         
02d72eec: ldr     x10, [x19]                                 
02d72ef0: ldr     w8, [x19, #0x6c]                           
02d72ef4: mov     x0, x19                                    
02d72ef8: ldr     w9, [x20, #0x10]                           .id
02d72efc: ldp     x20, x19, [sp, #0x10]                      
02d72f00: ldp     x3, x2, [x10, #0x188]                      
02d72f04: cmp     w8, w9                                     
02d72f08: cset    w1, eq                                     
02d72f0c: ldr     x30, [sp], #0x20                           
02d72f10: br      x3                                         
02d72f14: ldp     x20, x19, [sp, #0x10]                      
02d72f18: ldr     x30, [sp], #0x20                           
02d72f1c: ret                                                
02d72f20: bl      #0x2b7105c                                 fn_2b7105c
#### CLASS Clicker.SelectKeycapPanel parent= UnityEngine.MonoBehaviour
#   field _keycapUIItem                  Clicker.KeycapUIItem                               off=0x20 attr=1 SerializeField
#   field _listItem                      System.Collections.Generic.List`1<Clicker.KeycapUIItem> off=0x28 attr=1 SerializeField
#   field _configKeycap                  Clicker.KeycapConfig                               off=0x30 attr=1 SerializeField
#   field _rtShowPos                     UnityEngine.RectTransform                          off=0x38 attr=1 SerializeField
#   field _rtHidePos                     UnityEngine.RectTransform                          off=0x40 attr=1 SerializeField
#   field _thisPanelRect                 UnityEngine.RectTransform                          off=0x48 attr=1 SerializeField
#   field _btnNextPos                    UnityEngine.Transform                              off=0x50 attr=1 SerializeField
#   field _ingameClickerScreen           Clicker.IngameClickerScreen                        off=0x58 attr=1 
#   field _tutorialShown                 bool                                               off=0x60 attr=1 
## Init(Clicker.IngameClickerScreen ingameClickerScreen) -> void
---- Clicker.SelectKeycapPanel::Init 0x2d72330
02d72330: str     x1, [x0, #0x58]!                           ._ingameClickerScreen
02d72334: b       #0x2b70d54                                 
## Awake() -> void
---- Clicker.SelectKeycapPanel::Awake 0x2d72338
02d72338: str     x30, [sp, #-0x20]!                         
02d7233c: stp     x20, x19, [sp, #0x10]                      
02d72340: mov     x19, x0                                    
02d72344: ldr     x0, [x0, #0x40]                            ._rtHidePos
02d72348: cbz     x0, #0x2d72398                             
02d7234c: ldr     x20, [x19, #0x48]                          ._thisPanelRect
02d72350: mov     x1, xzr                                    
02d72354: bl      #0x5b45734                                 UnityEngine.RectTransform::get_anchoredPosition
02d72358: cbz     x20, #0x2d72398                            
02d7235c: mov     x0, x20                                    
02d72360: mov     x1, xzr                                    
02d72364: bl      #0x5b45800                                 UnityEngine.RectTransform::set_anchoredPosition
02d72368: ldr     x0, [x19, #0x48]                           ._thisPanelRect
02d7236c: cbz     x0, #0x2d72398                             
02d72370: mov     x1, xzr                                    
02d72374: bl      #0x5b339ec                                 UnityEngine.Component::get_gameObject
02d72378: cbz     x0, #0x2d72398                             
02d7237c: mov     w1, wzr                                    
02d72380: mov     x2, xzr                                    
02d72384: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d72388: mov     x0, x19                                    
02d7238c: ldp     x20, x19, [sp, #0x10]                      
02d72390: ldr     x30, [sp], #0x20                           
02d72394: b       #0x2d7239c                                 Clicker.SelectKeycapPanel::LoadData
02d72398: bl      #0x2b7105c                                 fn_2b7105c
## ShowPanel() -> void
---- Clicker.SelectKeycapPanel::ShowPanel 0x2d72818
02d72818: str     x30, [sp, #-0x50]!                         
02d7281c: stp     x26, x25, [sp, #0x10]                      
02d72820: stp     x24, x23, [sp, #0x20]                      
02d72824: stp     x22, x21, [sp, #0x30]                      
02d72828: stp     x20, x19, [sp, #0x40]                      
02d7282c: adrp    x20, #0x6630000                            
02d72830: mov     x19, x0                                    
02d72834: ldrb    w8, [x20, #0x3b6]                          
02d72838: tbnz    w8, #0, #0x2d7288c                         
02d7283c: adrp    x0, #0x6264000                             
02d72840: ldr     x0, [x0, #0xf90]                           T:System.Action
02d72844: bl      #0x2b70db0                                 fn_2b70db0
02d72848: adrp    x0, #0x626c000                             
02d7284c: ldr     x0, [x0, #0x668]                           M:Clicker.SelectKeycapPanel::<ShowPanel>b__11_0
02d72850: bl      #0x2b70db0                                 fn_2b70db0
02d72854: adrp    x0, #0x626c000                             
02d72858: ldr     x0, [x0, #0x670]                           M:Clicker.SelectKeycapPanel::<ShowPanel>b__11_1
02d7285c: bl      #0x2b70db0                                 fn_2b70db0
02d72860: adrp    x0, #0x6264000                             
02d72864: ldr     x0, [x0, #0xe8]                            T:DG.Tweening.TweenCallback
02d72868: bl      #0x2b70db0                                 fn_2b70db0
02d7286c: adrp    x0, #0x6266000                             
02d72870: ldr     x0, [x0, #0xa08]                           MS:DG.Tweening.TweenSettingsExtensions::OnComplete
02d72874: bl      #0x2b70db0                                 fn_2b70db0
02d72878: adrp    x0, #0x6266000                             
02d7287c: ldr     x0, [x0, #0xa18]                           MS:DG.Tweening.TweenSettingsExtensions::SetEase
02d72880: bl      #0x2b70db0                                 fn_2b70db0
02d72884: mov     w8, #1                                     
02d72888: strb    w8, [x20, #0x3b6]                          
02d7288c: ldr     x0, [x19, #0x48]                           ._thisPanelRect
02d72890: cbz     x0, #0x2d729b0                             
02d72894: mov     x1, xzr                                    
02d72898: bl      #0x5b339ec                                 UnityEngine.Component::get_gameObject
02d7289c: cbz     x0, #0x2d729b0                             
02d728a0: mov     w1, #1                                     
02d728a4: mov     x2, xzr                                    
02d728a8: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d728ac: ldr     x0, [x19, #0x38]                           ._rtShowPos
02d728b0: cbz     x0, #0x2d729b0                             
02d728b4: adrp    x21, #0x6266000                            
02d728b8: adrp    x23, #0x6264000                            
02d728bc: adrp    x24, #0x626c000                            
02d728c0: adrp    x25, #0x6266000                            
02d728c4: adrp    x26, #0x6264000                            
02d728c8: adrp    x22, #0x626c000                            
02d728cc: ldr     x21, [x21, #0xa18]                         MS:DG.Tweening.TweenSettingsExtensions::SetEase
02d728d0: ldr     x23, [x23, #0xe8]                          T:DG.Tweening.TweenCallback
02d728d4: ldr     x24, [x24, #0x668]                         M:Clicker.SelectKeycapPanel::<ShowPanel>b__11_0
02d728d8: ldr     x25, [x25, #0xa08]                         MS:DG.Tweening.TweenSettingsExtensions::OnComplete
02d728dc: ldr     x26, [x26, #0xf90]                         T:System.Action
02d728e0: ldr     x22, [x22, #0x670]                         M:Clicker.SelectKeycapPanel::<ShowPanel>b__11_1
02d728e4: ldr     x20, [x19, #0x48]                          ._thisPanelRect
02d728e8: mov     x1, xzr                                    
02d728ec: bl      #0x5b45734                                 UnityEngine.RectTransform::get_anchoredPosition
02d728f0: fmov    s2, #0.50000000                            
02d728f4: mov     x0, x20                                    
02d728f8: mov     w1, wzr                                    
02d728fc: mov     x2, xzr                                    
02d72900: bl      #0x2c798bc                                 DG.Tweening.DOTweenModuleUI::DOAnchorPos
02d72904: ldr     x2, [x21]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d72908: mov     w1, #3                                     
02d7290c: bl      #0x336fa0c                                 fn_336fa0c
02d72910: ldr     x8, [x23]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d72914: mov     x20, x0                                    
02d72918: mov     x0, x8                                     
02d7291c: bl      #0x2b7104c                                 fn_2b7104c
02d72920: ldr     x2, [x24]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d72924: mov     x1, x19                                    
02d72928: mov     x3, xzr                                    
02d7292c: mov     x21, x0                                    
02d72930: bl      #0x2d89dc4                                 DG.Tweening.TweenCallback::.ctor
02d72934: ldr     x2, [x25]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d72938: mov     x0, x20                                    
02d7293c: mov     x1, x21                                    
02d72940: bl      #0x336f26c                                 fn_336f26c
02d72944: ldr     x0, [x26]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d72948: ldr     x20, [x19, #0x58]                          ._ingameClickerScreen
02d7294c: bl      #0x2b7104c                                 fn_2b7104c
02d72950: ldr     x2, [x22]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d72954: mov     x1, x19                                    
02d72958: mov     x3, xzr                                    
02d7295c: mov     x21, x0                                    
02d72960: bl      #0x4d8ddbc                                 System.Action::.ctor
02d72964: cbz     x20, #0x2d729b0                            
02d72968: mov     x0, x20                                    
02d7296c: mov     x1, x21                                    
02d72970: mov     x2, xzr                                    
02d72974: bl      #0x2d69948                                 Clicker.IngameClickerScreen::RegisterButtonNextEvent
02d72978: ldr     x0, [x19, #0x50]                           ._btnNextPos
02d7297c: cbz     x0, #0x2d729b0                             
02d72980: ldr     x19, [x19, #0x58]                          ._ingameClickerScreen
02d72984: mov     x1, xzr                                    
02d72988: bl      #0x5b467ac                                 UnityEngine.Transform::get_position
02d7298c: cbz     x19, #0x2d729b0                            
02d72990: mov     x0, x19                                    
02d72994: ldp     x20, x19, [sp, #0x40]                      
02d72998: ldp     x22, x21, [sp, #0x30]                      
02d7299c: mov     x1, xzr                                    
02d729a0: ldp     x24, x23, [sp, #0x20]                      
02d729a4: ldp     x26, x25, [sp, #0x10]                      
02d729a8: ldr     x30, [sp], #0x50                           
02d729ac: b       #0x2d69a28                                 Clicker.IngameClickerScreen::SetBtnNextPosition
02d729b0: bl      #0x2b7105c                                 fn_2b7105c
## HidePanel() -> void
---- Clicker.SelectKeycapPanel::HidePanel 0x2d729b4
02d729b4: str     x30, [sp, #-0x40]!                         
02d729b8: stp     x24, x23, [sp, #0x10]                      
02d729bc: stp     x22, x21, [sp, #0x20]                      
02d729c0: stp     x20, x19, [sp, #0x30]                      
02d729c4: adrp    x20, #0x6630000                            
02d729c8: mov     x19, x0                                    
02d729cc: ldrb    w8, [x20, #0x3b7]                          
02d729d0: tbnz    w8, #0, #0x2d72a0c                         
02d729d4: adrp    x0, #0x626c000                             
02d729d8: ldr     x0, [x0, #0x678]                           M:Clicker.SelectKeycapPanel::<HidePanel>b__12_0
02d729dc: bl      #0x2b70db0                                 fn_2b70db0
02d729e0: adrp    x0, #0x6264000                             
02d729e4: ldr     x0, [x0, #0xe8]                            T:DG.Tweening.TweenCallback
02d729e8: bl      #0x2b70db0                                 fn_2b70db0
02d729ec: adrp    x0, #0x6266000                             
02d729f0: ldr     x0, [x0, #0xa08]                           MS:DG.Tweening.TweenSettingsExtensions::OnComplete
02d729f4: bl      #0x2b70db0                                 fn_2b70db0
02d729f8: adrp    x0, #0x6266000                             
02d729fc: ldr     x0, [x0, #0xa18]                           MS:DG.Tweening.TweenSettingsExtensions::SetEase
02d72a00: bl      #0x2b70db0                                 fn_2b70db0
02d72a04: mov     w8, #1                                     
02d72a08: strb    w8, [x20, #0x3b7]                          
02d72a0c: ldr     x0, [x19, #0x40]                           ._rtHidePos
02d72a10: cbz     x0, #0x2d72aa4                             
02d72a14: adrp    x21, #0x6266000                            
02d72a18: adrp    x22, #0x6264000                            
02d72a1c: adrp    x23, #0x626c000                            
02d72a20: adrp    x24, #0x6266000                            
02d72a24: ldr     x21, [x21, #0xa18]                         MS:DG.Tweening.TweenSettingsExtensions::SetEase
02d72a28: ldr     x22, [x22, #0xe8]                          T:DG.Tweening.TweenCallback
02d72a2c: ldr     x23, [x23, #0x678]                         M:Clicker.SelectKeycapPanel::<HidePanel>b__12_0
02d72a30: ldr     x24, [x24, #0xa08]                         MS:DG.Tweening.TweenSettingsExtensions::OnComplete
02d72a34: ldr     x20, [x19, #0x48]                          ._thisPanelRect
02d72a38: mov     x1, xzr                                    
02d72a3c: bl      #0x5b45734                                 UnityEngine.RectTransform::get_anchoredPosition
02d72a40: fmov    s2, #0.50000000                            
02d72a44: mov     x0, x20                                    
02d72a48: mov     w1, wzr                                    
02d72a4c: mov     x2, xzr                                    
02d72a50: bl      #0x2c798bc                                 DG.Tweening.DOTweenModuleUI::DOAnchorPos
02d72a54: ldr     x2, [x21]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d72a58: mov     w1, #2                                     
02d72a5c: bl      #0x336fa0c                                 fn_336fa0c
02d72a60: ldr     x8, [x22]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d72a64: mov     x20, x0                                    
02d72a68: mov     x0, x8                                     
02d72a6c: bl      #0x2b7104c                                 fn_2b7104c
02d72a70: ldr     x2, [x23]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d72a74: mov     x1, x19                                    
02d72a78: mov     x3, xzr                                    
02d72a7c: mov     x21, x0                                    
02d72a80: bl      #0x2d89dc4                                 DG.Tweening.TweenCallback::.ctor
02d72a84: ldr     x2, [x24]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d72a88: mov     x0, x20                                    
02d72a8c: mov     x1, x21                                    
02d72a90: ldp     x20, x19, [sp, #0x30]                      
02d72a94: ldp     x22, x21, [sp, #0x20]                      
02d72a98: ldp     x24, x23, [sp, #0x10]                      
02d72a9c: ldr     x30, [sp], #0x40                           
02d72aa0: b       #0x336f26c                                 
02d72aa4: bl      #0x2b7105c                                 fn_2b7105c
## LoadData() -> void
---- Clicker.SelectKeycapPanel::LoadData 0x2d7239c
02d7239c: stp     x29, x30, [sp, #-0x60]!                    
02d723a0: stp     x28, x27, [sp, #0x10]                      
02d723a4: stp     x26, x25, [sp, #0x20]                      
02d723a8: stp     x24, x23, [sp, #0x30]                      
02d723ac: stp     x22, x21, [sp, #0x40]                      
02d723b0: stp     x20, x19, [sp, #0x50]                      
02d723b4: adrp    x20, #0x6630000                            
02d723b8: adrp    x21, #0x626c000                            
02d723bc: mov     x19, x0                                    
02d723c0: ldrb    w8, [x20, #0x3b8]                          
02d723c4: ldr     x21, [x21, #0x630]                         T:Clicker.SelectKeycapPanel/<>c__DisplayClass13_0
02d723c8: tbnz    w8, #0, #0x2d72458                         
02d723cc: adrp    x0, #0x6269000                             
02d723d0: ldr     x0, [x0, #0x5e8]                           T:type6940(k15)
02d723d4: bl      #0x2b70db0                                 fn_2b70db0
02d723d8: adrp    x0, #0x6266000                             
02d723dc: ldr     x0, [x0, #0x750]                           MS:DataManager::GetData
02d723e0: bl      #0x2b70db0                                 fn_2b70db0
02d723e4: adrp    x0, #0x626c000                             
02d723e8: ldr     x0, [x0, #0x638]                           MS:System.Collections.Generic.List`1::Add
02d723ec: bl      #0x2b70db0                                 fn_2b70db0
02d723f0: adrp    x0, #0x626c000                             
02d723f4: ldr     x0, [x0, #0x640]                           MS:System.Collections.Generic.List`1::get_Count
02d723f8: bl      #0x2b70db0                                 fn_2b70db0
02d723fc: adrp    x0, #0x626c000                             
02d72400: ldr     x0, [x0, #0x648]                           MS:System.Collections.Generic.List`1::get_Item
02d72404: bl      #0x2b70db0                                 fn_2b70db0
02d72408: adrp    x0, #0x6266000                             
02d7240c: ldr     x0, [x0, #0x658]                           MS:MonoSingleton`1::get_Instance
02d72410: bl      #0x2b70db0                                 fn_2b70db0
02d72414: adrp    x0, #0x626c000                             
02d72418: ldr     x0, [x0, #0x650]                           MS:UnityEngine.Object::Instantiate
02d7241c: bl      #0x2b70db0                                 fn_2b70db0
02d72420: adrp    x0, #0x6263000                             
02d72424: ldr     x0, [x0, #0x918]                           T:UnityEngine.Object
02d72428: bl      #0x2b70db0                                 fn_2b70db0
02d7242c: adrp    x0, #0x626c000                             
02d72430: ldr     x0, [x0, #0x630]                           T:Clicker.SelectKeycapPanel/<>c__DisplayClass13_0
02d72434: bl      #0x2b70db0                                 fn_2b70db0
02d72438: adrp    x0, #0x626c000                             
02d7243c: ldr     x0, [x0, #0x658]                           M:Clicker.SelectKeycapPanel/<>c__DisplayClass13_1::<LoadData>b__0
02d72440: bl      #0x2b70db0                                 fn_2b70db0
02d72444: adrp    x0, #0x626c000                             
02d72448: ldr     x0, [x0, #0x660]                           T:Clicker.SelectKeycapPanel/<>c__DisplayClass13_1
02d7244c: bl      #0x2b70db0                                 fn_2b70db0
02d72450: mov     w8, #1                                     
02d72454: strb    w8, [x20, #0x3b8]                          
02d72458: ldr     x0, [x21]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d7245c: bl      #0x2b7104c                                 fn_2b7104c
02d72460: mov     x1, xzr                                    
02d72464: mov     x20, x0                                    
02d72468: bl      #0x4e53e9c                                 System.Object::.ctor
02d7246c: cbz     x20, #0x2d727f8                            
02d72470: mov     x0, x20                                    
02d72474: mov     x1, x19                                    
02d72478: str     x19, [x0, #0x18]!                          
02d7247c: bl      #0x2b70d54                                 fn_2b70d54
02d72480: ldr     x8, [x19, #0x28]                           ._listItem
02d72484: cbz     x8, #0x2d727f8                             
02d72488: adrp    x27, #0x626c000                            
02d7248c: adrp    x29, #0x6269000                            
02d72490: adrp    x28, #0x626c000                            
02d72494: adrp    x26, #0x6263000                            
02d72498: adrp    x24, #0x626c000                            
02d7249c: adrp    x25, #0x626c000                            
02d724a0: ldr     x27, [x27, #0x648]                         MS:System.Collections.Generic.List`1::get_Item
02d724a4: ldr     x29, [x29, #0x5e8]                         T:type6940(k15)
02d724a8: ldr     x28, [x28, #0x658]                         M:Clicker.SelectKeycapPanel/<>c__DisplayClass13_1::<LoadData>b__0
02d724ac: ldr     x26, [x26, #0x918]                         T:UnityEngine.Object
02d724b0: ldr     x24, [x24, #0x650]                         MS:UnityEngine.Object::Instantiate
02d724b4: ldr     x25, [x25, #0x638]                         MS:System.Collections.Generic.List`1::Add
02d724b8: ldr     x0, [x19, #0x30]                           ._configKeycap
02d724bc: cbz     x0, #0x2d727f8                             
02d724c0: ldr     w21, [x8, #0x18]                           
02d724c4: mov     x1, xzr                                    
02d724c8: bl      #0x2d5b7d8                                 Clicker.KeycapConfig::get_Count
02d724cc: cmp     w21, w0                                    
02d724d0: b.ge    #0x2d72588                                 
02d724d4: ldr     x22, [x19, #0x20]                          ._keycapUIItem
02d724d8: cbz     x22, #0x2d727f8                            
02d724dc: ldr     x21, [x19, #0x28]                          ._listItem
02d724e0: mov     x0, x22                                    
02d724e4: mov     x1, xzr                                    
02d724e8: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02d724ec: cbz     x0, #0x2d727f8                             
02d724f0: mov     x1, xzr                                    
02d724f4: bl      #0x5b466dc                                 UnityEngine.Transform::get_parent
02d724f8: ldr     x8, [x26]                                  &2c5bbd4(=a9bd7bfdd503233f)
02d724fc: mov     x23, x0                                    
02d72500: ldr     w9, [x8, #0xe4]                            
02d72504: cbnz    w9, #0x2d72510                             
02d72508: mov     x0, x8                                     
02d7250c: bl      #0x2b70f30                                 fn_2b70f30
02d72510: ldr     x2, [x24]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d72514: mov     x0, x22                                    
02d72518: mov     x1, x23                                    
02d7251c: bl      #0x3275fcc                                 fn_3275fcc
02d72520: cbz     x21, #0x2d727f8                            
02d72524: ldr     w10, [x21, #0x1c]                          [626c01c]=0 f=0,0
02d72528: ldr     x8, [x21, #0x10]                           M:Clicker.GlowSprite2DItem::<DoGlow>b__10_4
02d7252c: ldr     x9, [x25]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d72530: add     w10, w10, #1                               
02d72534: str     w10, [x21, #0x1c]                          
02d72538: cbz     x8, #0x2d727f8                             
02d7253c: ldrsw   x10, [x21, #0x18]                          
02d72540: ldr     w11, [x8, #0x18]                           
02d72544: mov     x1, x0                                     
02d72548: cmp     w10, w11                                   
02d7254c: b.hs    #0x2d72568                                 
02d72550: add     x0, x8, x10, lsl #3                        
02d72554: add     w9, w10, #1                                
02d72558: str     w9, [x21, #0x18]                           
02d7255c: str     x1, [x0, #0x20]!                           ._keycapUIItem
02d72560: bl      #0x2b70d54                                 fn_2b70d54
02d72564: b       #0x2d7257c                                 
02d72568: ldr     x8, [x9, #0x20]                            
02d7256c: mov     x0, x21                                    
02d72570: ldr     x8, [x8, #0xc0]                            
02d72574: ldr     x2, [x8, #0x70]                            
02d72578: bl      #0x35a920c                                 fn_35a920c
02d7257c: ldr     x8, [x19, #0x28]                           ._listItem
02d72580: cbnz    x8, #0x2d724b8                             
02d72584: b       #0x2d727f8                                 
02d72588: adrp    x8, #0x6266000                             
02d7258c: ldr     x8, [x8, #0x658]                           MS:MonoSingleton`1::get_Instance
02d72590: ldr     x0, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d72594: bl      #0x3769600                                 fn_3769600
02d72598: cbz     x0, #0x2d727f8                             
02d7259c: adrp    x8, #0x6266000                             
02d725a0: ldr     x8, [x8, #0x750]                           MS:DataManager::GetData
02d725a4: ldr     x1, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d725a8: bl      #0x3168dd0                                 fn_3168dd0
02d725ac: mov     x1, x0                                     
02d725b0: mov     x0, x20                                    
02d725b4: str     x1, [x0, #0x10]!                           
02d725b8: bl      #0x2b70d54                                 fn_2b70d54
02d725bc: ldr     x0, [x19, #0x30]                           ._configKeycap
02d725c0: cbz     x0, #0x2d727f8                             
02d725c4: mov     w21, wzr                                   
02d725c8: mov     x1, xzr                                    
02d725cc: bl      #0x2d5b7d8                                 Clicker.KeycapConfig::get_Count
02d725d0: mov     w8, w0                                     
02d725d4: ldr     x0, [x19, #0x30]                           ._configKeycap
02d725d8: cmp     w21, w8                                    
02d725dc: b.ge    #0x2d7279c                                 
02d725e0: cbz     x0, #0x2d727f8                             
02d725e4: mov     w1, w21                                    
02d725e8: mov     x2, xzr                                    
02d725ec: bl      #0x2d5b820                                 Clicker.KeycapConfig::GetData
02d725f0: cbz     x0, #0x2d726a4                             
02d725f4: adrp    x8, #0x626c000                             
02d725f8: mov     x23, x0                                    
02d725fc: ldr     x8, [x8, #0x660]                           T:Clicker.SelectKeycapPanel/<>c__DisplayClass13_1
02d72600: ldr     x0, [x8]                                   M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d72604: bl      #0x2b7104c                                 fn_2b7104c
02d72608: mov     x1, xzr                                    
02d7260c: mov     x22, x0                                    
02d72610: bl      #0x4e53e9c                                 System.Object::.ctor
02d72614: cbz     x22, #0x2d727f8                            
02d72618: mov     x24, x22                                   
02d7261c: mov     x1, x20                                    
02d72620: str     x20, [x24, #0x18]!                         
02d72624: mov     x0, x24                                    
02d72628: bl      #0x2b70d54                                 fn_2b70d54
02d7262c: ldr     x0, [x19, #0x28]                           ._listItem
02d72630: cbz     x0, #0x2d727f8                             
02d72634: ldr     x2, [x27]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d72638: mov     w1, w21                                    
02d7263c: bl      #0x35a8f3c                                 fn_35a8f3c
02d72640: cbz     x0, #0x2d727f8                             
02d72644: ldr     x8, [x0]                                   M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d72648: ldr     x2, [x23, #0x18]                           
02d7264c: ldr     w1, [x23, #0x10]                           
02d72650: ldp     x9, x3, [x8, #0x178]                       
02d72654: blr     x9                                         
02d72658: ldr     x0, [x19, #0x28]                           ._listItem
02d7265c: cbz     x0, #0x2d727f8                             
02d72660: ldr     x2, [x27]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d72664: mov     w1, w21                                    
02d72668: bl      #0x35a8f3c                                 fn_35a8f3c
02d7266c: ldr     x8, [x23, #0x28]                           
02d72670: cbz     x8, #0x2d727f8                             
02d72674: ldr     x9, [x24]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d72678: cbz     x9, #0x2d727f8                             
02d7267c: mov     x25, x0                                    
02d72680: ldr     x0, [x9, #0x10]                            
02d72684: cbz     x0, #0x2d727f8                             
02d72688: ldp     w24, w26, [x8, #0x10]                      
02d7268c: ldr     w1, [x23, #0x10]                           
02d72690: mov     x2, xzr                                    
02d72694: bl      #0x2cac12c                                 DataUser::HasUnlockedClickerKeycap
02d72698: tbz     w0, #0, #0x2d726d8                         
02d7269c: mov     w3, #1                                     
02d726a0: b       #0x2d726ec                                 
02d726a4: ldr     x0, [x19, #0x28]                           ._listItem
02d726a8: cbz     x0, #0x2d727f8                             
02d726ac: ldr     x2, [x27]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d726b0: mov     w1, w21                                    
02d726b4: bl      #0x35a8f3c                                 fn_35a8f3c
02d726b8: cbz     x0, #0x2d727f8                             
02d726bc: mov     x1, xzr                                    
02d726c0: bl      #0x5b339ec                                 UnityEngine.Component::get_gameObject
02d726c4: cbz     x0, #0x2d727f8                             
02d726c8: mov     w1, wzr                                    
02d726cc: mov     x2, xzr                                    
02d726d0: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d726d4: b       #0x2d7278c                                 
02d726d8: ldr     x8, [x23, #0x28]                           
02d726dc: cbz     x8, #0x2d727f8                             
02d726e0: ldr     w8, [x8, #0x10]                            M:Clicker.GlowSprite2DItem::<DoGlow>b__10_4
02d726e4: cmp     w8, #0                                     
02d726e8: cset    w3, eq                                     
02d726ec: cbz     x25, #0x2d727f8                            
02d726f0: ldr     x8, [x25]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d726f4: mov     x0, x25                                    
02d726f8: mov     w1, w24                                    
02d726fc: mov     w2, w26                                    
02d72700: ldp     x9, x4, [x8, #0x1a8]                       
02d72704: blr     x9                                         
02d72708: ldr     x0, [x19, #0x28]                           ._listItem
02d7270c: cbz     x0, #0x2d727f8                             
02d72710: ldr     x2, [x27]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d72714: mov     w1, w21                                    
02d72718: bl      #0x35a8f3c                                 fn_35a8f3c
02d7271c: cbz     x0, #0x2d727f8                             
02d72720: mov     x1, xzr                                    
02d72724: bl      #0x5b339ec                                 UnityEngine.Component::get_gameObject
02d72728: cbz     x0, #0x2d727f8                             
02d7272c: mov     w1, #1                                     
02d72730: mov     x2, xzr                                    
02d72734: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d72738: ldr     x0, [x19, #0x28]                           ._listItem
02d7273c: str     w21, [x22, #0x10]                          
02d72740: cbz     x0, #0x2d727f8                             
02d72744: ldr     x2, [x27]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d72748: mov     w1, w21                                    
02d7274c: bl      #0x35a8f3c                                 fn_35a8f3c
02d72750: ldr     x8, [x29]                                  T:Trading.TradingSession/<>c__DisplayClass56_0
02d72754: mov     x23, x0                                    
02d72758: mov     x0, x8                                     
02d7275c: bl      #0x2b7104c                                 fn_2b7104c
02d72760: ldr     x2, [x28]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d72764: mov     x1, x22                                    
02d72768: mov     x3, xzr                                    
02d7276c: mov     x24, x0                                    
02d72770: bl      #0x4532eb0                                 fn_4532eb0
02d72774: cbz     x23, #0x2d727f8                            
02d72778: ldr     x8, [x23]                                  
02d7277c: mov     x0, x23                                    
02d72780: mov     x1, x24                                    
02d72784: ldp     x9, x2, [x8, #0x198]                       
02d72788: blr     x9                                         
02d7278c: ldr     x0, [x19, #0x30]                           ._configKeycap
02d72790: add     w21, w21, #1                               
02d72794: cbnz    x0, #0x2d725c8                             
02d72798: b       #0x2d727f8                                 
02d7279c: cbz     x0, #0x2d727f8                             
02d727a0: mov     x1, xzr                                    
02d727a4: bl      #0x2d5b7d8                                 Clicker.KeycapConfig::get_Count
02d727a8: ldr     x8, [x19, #0x28]                           ._listItem
02d727ac: cbz     x8, #0x2d727f8                             
02d727b0: mov     w20, w0                                    
02d727b4: ldr     w9, [x8, #0x18]                            M:Clicker.GlowSprite2DItem::<DoGlow>b__10_5
02d727b8: cmp     w20, w9                                    
02d727bc: b.ge    #0x2d727fc                                 
02d727c0: ldr     x2, [x27]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d727c4: mov     x0, x8                                     
02d727c8: mov     w1, w20                                    
02d727cc: bl      #0x35a8f3c                                 fn_35a8f3c
02d727d0: cbz     x0, #0x2d727f8                             
02d727d4: mov     x1, xzr                                    
02d727d8: bl      #0x5b339ec                                 UnityEngine.Component::get_gameObject
02d727dc: cbz     x0, #0x2d727f8                             
02d727e0: mov     w1, wzr                                    
02d727e4: mov     x2, xzr                                    
02d727e8: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d727ec: ldr     x8, [x19, #0x28]                           ._listItem
02d727f0: add     w20, w20, #1                               
02d727f4: cbnz    x8, #0x2d727b4                             
02d727f8: bl      #0x2b7105c                                 fn_2b7105c
02d727fc: ldp     x20, x19, [sp, #0x50]                      
02d72800: ldp     x22, x21, [sp, #0x40]                      
02d72804: ldp     x24, x23, [sp, #0x30]                      
02d72808: ldp     x26, x25, [sp, #0x20]                      
02d7280c: ldp     x28, x27, [sp, #0x10]                      
02d72810: ldp     x29, x30, [sp], #0x60                      
02d72814: ret                                                
## OnItemSelect(int id) -> void
---- Clicker.SelectKeycapPanel::OnItemSelect 0x2d72ab8
02d72ab8: str     x30, [sp, #-0x30]!                         
02d72abc: stp     x22, x21, [sp, #0x10]                      
02d72ac0: stp     x20, x19, [sp, #0x20]                      
02d72ac4: adrp    x21, #0x6630000                            
02d72ac8: adrp    x22, #0x626c000                            
02d72acc: mov     w19, w1                                    
02d72ad0: ldrb    w8, [x21, #0x3b9]                          
02d72ad4: ldr     x22, [x22, #0x680]                         T:Clicker.SelectKeycapPanel/<>c__DisplayClass14_0
02d72ad8: mov     x20, x0                                    
02d72adc: tbnz    w8, #0, #0x2d72b18                         
02d72ae0: adrp    x0, #0x626c000                             
02d72ae4: ldr     x0, [x0, #0x688]                           T:type53141(k15)
02d72ae8: bl      #0x2b70db0                                 fn_2b70db0
02d72aec: adrp    x0, #0x626c000                             
02d72af0: ldr     x0, [x0, #0x690]                           MS:System.Collections.Generic.List`1::ForEach
02d72af4: bl      #0x2b70db0                                 fn_2b70db0
02d72af8: adrp    x0, #0x626c000                             
02d72afc: ldr     x0, [x0, #0x698]                           M:Clicker.SelectKeycapPanel/<>c__DisplayClass14_0::<OnItemSelect>b__0
02d72b00: bl      #0x2b70db0                                 fn_2b70db0
02d72b04: adrp    x0, #0x626c000                             
02d72b08: ldr     x0, [x0, #0x680]                           T:Clicker.SelectKeycapPanel/<>c__DisplayClass14_0
02d72b0c: bl      #0x2b70db0                                 fn_2b70db0
02d72b10: mov     w8, #1                                     
02d72b14: strb    w8, [x21, #0x3b9]                          
02d72b18: ldr     x0, [x22]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d72b1c: bl      #0x2b7104c                                 fn_2b7104c
02d72b20: mov     x1, xzr                                    
02d72b24: mov     x21, x0                                    
02d72b28: bl      #0x4e53e9c                                 System.Object::.ctor
02d72b2c: cbz     x21, #0x2d72b8c                            
02d72b30: adrp    x8, #0x626c000                             
02d72b34: adrp    x22, #0x626c000                            
02d72b38: ldr     x8, [x8, #0x688]                           T:type53141(k15)
02d72b3c: ldr     x22, [x22, #0x698]                         M:Clicker.SelectKeycapPanel/<>c__DisplayClass14_0::<OnItemSelect>b__0
02d72b40: ldr     x20, [x20, #0x28]                          ._listItem
02d72b44: str     w19, [x21, #0x10]                          
02d72b48: ldr     x0, [x8]                                   M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d72b4c: bl      #0x2b7104c                                 fn_2b7104c
02d72b50: ldr     x2, [x22]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d72b54: mov     x1, x21                                    
02d72b58: mov     x3, xzr                                    
02d72b5c: mov     x19, x0                                    
02d72b60: bl      #0x453418c                                 fn_453418c
02d72b64: cbz     x20, #0x2d72b8c                            
02d72b68: adrp    x8, #0x626c000                             
02d72b6c: mov     x0, x20                                    
02d72b70: mov     x1, x19                                    
02d72b74: ldr     x8, [x8, #0x690]                           MS:System.Collections.Generic.List`1::ForEach
02d72b78: ldp     x20, x19, [sp, #0x20]                      
02d72b7c: ldp     x22, x21, [sp, #0x10]                      
02d72b80: ldr     x2, [x8]                                   M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d72b84: ldr     x30, [sp], #0x30                           
02d72b88: b       #0x35a9ce4                                 
02d72b8c: bl      #0x2b7105c                                 fn_2b7105c
## .ctor() -> void
---- Clicker.SelectKeycapPanel::.ctor 0x2d72b98
02d72b98: mov     x1, xzr                                    
02d72b9c: b       #0x5b397b0                                 UnityEngine.MonoBehaviour::.ctor
## <ShowPanel>b__11_0() -> void
---- Clicker.SelectKeycapPanel::<ShowPanel>b__11_0 0x2d72ba0
02d72ba0: str     x30, [sp, #-0x20]!                         
02d72ba4: stp     x20, x19, [sp, #0x10]                      
02d72ba8: adrp    x20, #0x6630000                            
02d72bac: mov     x19, x0                                    
02d72bb0: ldrb    w8, [x20, #0x3ba]                          
02d72bb4: tbnz    w8, #0, #0x2d72bcc                         
02d72bb8: adrp    x0, #0x626c000                             
02d72bbc: ldr     x0, [x0, #0x648]                           MS:System.Collections.Generic.List`1::get_Item
02d72bc0: bl      #0x2b70db0                                 fn_2b70db0
02d72bc4: mov     w8, #1                                     
02d72bc8: strb    w8, [x20, #0x3ba]                          
02d72bcc: ldrb    w8, [x19, #0x60]                           ._tutorialShown
02d72bd0: cbz     w8, #0x2d72be0                             
02d72bd4: ldp     x20, x19, [sp, #0x10]                      
02d72bd8: ldr     x30, [sp], #0x20                           
02d72bdc: ret                                                
02d72be0: ldr     x0, [x19, #0x28]                           ._listItem
02d72be4: cbz     x0, #0x2d72c28                             
02d72be8: adrp    x8, #0x626c000                             
02d72bec: mov     w1, wzr                                    
02d72bf0: ldr     x8, [x8, #0x648]                           MS:System.Collections.Generic.List`1::get_Item
02d72bf4: ldr     x19, [x19, #0x58]                          ._ingameClickerScreen
02d72bf8: ldr     x2, [x8]                                   M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d72bfc: bl      #0x35a8f3c                                 fn_35a8f3c
02d72c00: cbz     x0, #0x2d72c28                             
02d72c04: mov     x1, xzr                                    
02d72c08: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02d72c0c: cbz     x19, #0x2d72c28                            
02d72c10: mov     x1, x0                                     
02d72c14: mov     x0, x19                                    
02d72c18: mov     x2, xzr                                    
02d72c1c: ldp     x20, x19, [sp, #0x10]                      
02d72c20: ldr     x30, [sp], #0x20                           
02d72c24: b       #0x2d6a2c0                                 Clicker.IngameClickerScreen::ShowTutorialAt
02d72c28: bl      #0x2b7105c                                 fn_2b7105c
## <ShowPanel>b__11_1() -> void
---- Clicker.SelectKeycapPanel::<ShowPanel>b__11_1 0x2d72c2c
02d72c2c: str     x30, [sp, #-0x20]!                         
02d72c30: stp     x20, x19, [sp, #0x10]                      
02d72c34: adrp    x20, #0x6630000                            
02d72c38: mov     x19, x0                                    
02d72c3c: ldrb    w8, [x20, #0x3bb]                          
02d72c40: tbnz    w8, #0, #0x2d72c7c                         
02d72c44: adrp    x0, #0x6266000                             
02d72c48: ldr     x0, [x0, #0x750]                           MS:DataManager::GetData
02d72c4c: bl      #0x2b70db0                                 fn_2b70db0
02d72c50: adrp    x0, #0x6265000                             
02d72c54: ldr     x0, [x0, #0xb38]                           T:DevTrack
02d72c58: bl      #0x2b70db0                                 fn_2b70db0
02d72c5c: adrp    x0, #0x626b000                             
02d72c60: ldr     x0, [x0, #0xee0]                           MS:MonoSingleton`1::get_Instance
02d72c64: bl      #0x2b70db0                                 fn_2b70db0
02d72c68: adrp    x0, #0x6266000                             
02d72c6c: ldr     x0, [x0, #0x658]                           MS:MonoSingleton`1::get_Instance
02d72c70: bl      #0x2b70db0                                 fn_2b70db0
02d72c74: mov     w8, #1                                     
02d72c78: strb    w8, [x20, #0x3bb]                          
02d72c7c: mov     x0, x19                                    
02d72c80: bl      #0x2d729b4                                 Clicker.SelectKeycapPanel::HidePanel
02d72c84: ldr     x0, [x19, #0x58]                           ._ingameClickerScreen
02d72c88: cbz     x0, #0x2d72d54                             
02d72c8c: mov     w1, wzr                                    
02d72c90: mov     x2, xzr                                    
02d72c94: bl      #0x2d6519c                                 Clicker.IngameClickerScreen::ShowBtnNext
02d72c98: ldr     x0, [x19, #0x58]                           ._ingameClickerScreen
02d72c9c: cbz     x0, #0x2d72d54                             
02d72ca0: mov     x1, xzr                                    
02d72ca4: bl      #0x2d6bb00                                 Clicker.IngameClickerScreen::HidePopupColor
02d72ca8: ldr     x0, [x19, #0x58]                           ._ingameClickerScreen
02d72cac: cbz     x0, #0x2d72d54                             
02d72cb0: adrp    x19, #0x626b000                            
02d72cb4: mov     x1, xzr                                    
02d72cb8: ldr     x19, [x19, #0xee0]                         MS:MonoSingleton`1::get_Instance
02d72cbc: bl      #0x2d6bb18                                 Clicker.IngameClickerScreen::GoToStepDecorKeycap
02d72cc0: ldr     x0, [x19]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d72cc4: bl      #0x3769600                                 fn_3769600
02d72cc8: cbz     x0, #0x2d72d54                             
02d72ccc: adrp    x19, #0x6266000                            
02d72cd0: mov     x1, xzr                                    
02d72cd4: ldr     x19, [x19, #0x658]                         MS:MonoSingleton`1::get_Instance
02d72cd8: bl      #0x2d6d194                                 Clicker.KeycapMakerController::ShowStepDecorKeycap
02d72cdc: ldr     x0, [x19]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d72ce0: bl      #0x3769600                                 fn_3769600
02d72ce4: cbz     x0, #0x2d72d54                             
02d72ce8: adrp    x8, #0x6266000                             
02d72cec: ldr     x8, [x8, #0x750]                           MS:DataManager::GetData
02d72cf0: ldr     x1, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d72cf4: bl      #0x3168dd0                                 fn_3168dd0
02d72cf8: cbz     x0, #0x2d72d54                             
02d72cfc: ldr     x8, [x0, #0x20]                            S:'inter_ad_capping_time' ._keycapUIItem
02d72d00: cbz     x8, #0x2d72d54                             
02d72d04: ldrb    w8, [x8, #0x3a]                            
02d72d08: cbz     w8, #0x2d72d48                             
02d72d0c: adrp    x19, #0x6265000                            
02d72d10: ldr     x19, [x19, #0xb38]                         T:DevTrack
02d72d14: ldr     x0, [x19]                                  M:AdsManager::<OnApplicationPause>b__26_0
02d72d18: ldr     w8, [x0, #0xe4]                            [62660e4]=0 f=0,0
02d72d1c: cbnz    w8, #0x2d72d28                             
02d72d20: bl      #0x2b70f30                                 fn_2b70f30
02d72d24: ldr     x0, [x19]                                  M:AdsManager::<OnApplicationPause>b__26_0
02d72d28: ldr     x8, [x0, #0xb8]                            S:'banner_native_refresh_time'
02d72d2c: ldp     x20, x19, [sp, #0x10]                      
02d72d30: mov     x3, xzr                                    
02d72d34: ldr     x0, [x8, #0x1f8]                           MS:System.Collections.Generic.List`1/Enumerator::get_Current
02d72d38: ldr     x1, [x8, #0x238]                           S:"Product '"
02d72d3c: ldr     w2, [x8, #0x280]                           S:'  - '
02d72d40: ldr     x30, [sp], #0x20                           
02d72d44: b       #0x2c9c1e0                                 DevTrack::OnboardingStep
02d72d48: ldp     x20, x19, [sp, #0x10]                      
02d72d4c: ldr     x30, [sp], #0x20                           
02d72d50: ret                                                
02d72d54: bl      #0x2b7105c                                 fn_2b7105c
## <HidePanel>b__12_0() -> void
---- Clicker.SelectKeycapPanel::<HidePanel>b__12_0 0x2d72d58
02d72d58: str     x30, [sp, #-0x10]!                         
02d72d5c: ldr     x0, [x0, #0x48]                            ._thisPanelRect
02d72d60: cbz     x0, #0x2d72d80                             
02d72d64: mov     x1, xzr                                    
02d72d68: bl      #0x5b339ec                                 UnityEngine.Component::get_gameObject
02d72d6c: cbz     x0, #0x2d72d80                             
02d72d70: mov     w1, wzr                                    
02d72d74: mov     x2, xzr                                    
02d72d78: ldr     x30, [sp], #0x10                           
02d72d7c: b       #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d72d80: bl      #0x2b7105c                                 fn_2b7105c
