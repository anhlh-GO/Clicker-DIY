#### CLASS Define/Layer parent= object
#   field DEFAULT                        string                                             off=0x0 attr=16 
#   field UI                             string                                             off=0x8 attr=16 
## .ctor() -> void
---- Define/Layer::.ctor 0x2cee948
02cee948: mov     x1, xzr                                    
02cee94c: b       #0x4e53e9c                                 System.Object::.ctor
## .cctor() -> void
---- Define/Layer::.cctor 0x2cee950
02cee950: str     x30, [sp, #-0x30]!                         
02cee954: stp     x22, x21, [sp, #0x10]                      
02cee958: stp     x20, x19, [sp, #0x20]                      
02cee95c: adrp    x22, #0x662f000                            
02cee960: adrp    x21, #0x6268000                            
02cee964: adrp    x19, #0x6268000                            
02cee968: adrp    x20, #0x6267000                            
02cee96c: ldr     x21, [x21, #0x508]                         S:'Default'
02cee970: ldrb    w8, [x22, #0xe43]                          
02cee974: ldr     x19, [x19, #0x510]                         T:Define/Layer
02cee978: ldr     x20, [x20, #0x920]                         S:'UI'
02cee97c: tbnz    w8, #0, #0x2cee9ac                         
02cee980: adrp    x0, #0x6268000                             
02cee984: ldr     x0, [x0, #0x510]                           T:Define/Layer
02cee988: bl      #0x2b70db0                                 fn_2b70db0
02cee98c: adrp    x0, #0x6268000                             
02cee990: ldr     x0, [x0, #0x508]                           S:'Default'
02cee994: bl      #0x2b70db0                                 fn_2b70db0
02cee998: adrp    x0, #0x6267000                             
02cee99c: ldr     x0, [x0, #0x920]                           S:'UI'
02cee9a0: bl      #0x2b70db0                                 fn_2b70db0
02cee9a4: mov     w8, #1                                     
02cee9a8: strb    w8, [x22, #0xe43]                          
02cee9ac: ldr     x8, [x19]                                  S:'{0}/2'
02cee9b0: ldr     x1, [x21]                                  S:'{0}/2'
02cee9b4: ldr     x8, [x8, #0xb8]                            
02cee9b8: str     x1, [x8]                                   
02cee9bc: ldr     x8, [x19]                                  S:'{0}/2'
02cee9c0: ldr     x0, [x8, #0xb8]                            
02cee9c4: bl      #0x2b70d54                                 fn_2b70d54
02cee9c8: ldr     x8, [x19]                                  S:'{0}/2'
02cee9cc: ldr     x1, [x20]                                  S:'didu'
02cee9d0: ldp     x20, x19, [sp, #0x20]                      
02cee9d4: ldr     x0, [x8, #0xb8]                            
02cee9d8: ldp     x22, x21, [sp, #0x10]                      
02cee9dc: str     x1, [x0, #8]!                              
02cee9e0: ldr     x30, [sp], #0x30                           
02cee9e4: b       #0x2b70d54                                 
#### CLASS Define parent= object
## .ctor() -> void
---- Define::.ctor 0x2cee940
02cee940: mov     x1, xzr                                    
02cee944: b       #0x4e53e9c                                 System.Object::.ctor
