#### CLASS Framework.Invoker parent= MonoSingleton`1<Framework.Invoker>
## .ctor() -> void
---- Framework.Invoker::.ctor 0x2cc69f4
02cc69f4: stp     x30, x21, [sp, #-0x20]!                    
02cc69f8: stp     x20, x19, [sp, #0x10]                      
02cc69fc: adrp    x20, #0x662f000                            
02cc6a00: adrp    x21, #0x6267000                            
02cc6a04: mov     x19, x0                                    
02cc6a08: ldrb    w8, [x20, #0xc57]                          
02cc6a0c: ldr     x21, [x21, #0x2d0]                         MS:MonoSingleton`1::.ctor
02cc6a10: tbnz    w8, #0, #0x2cc6a28                         
02cc6a14: adrp    x0, #0x6267000                             
02cc6a18: ldr     x0, [x0, #0x2d0]                           MS:MonoSingleton`1::.ctor
02cc6a1c: bl      #0x2b70db0                                 fn_2b70db0
02cc6a20: mov     w8, #1                                     
02cc6a24: strb    w8, [x20, #0xc57]                          
02cc6a28: mov     x0, x19                                    
02cc6a2c: ldp     x20, x19, [sp, #0x10]                      
02cc6a30: ldr     x1, [x21]                                  S:'didu'
02cc6a34: ldp     x30, x21, [sp], #0x20                      
02cc6a38: b       #0x3769e18                                 
