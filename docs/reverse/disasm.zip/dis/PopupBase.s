#### CLASS PopupBase parent= UIBase
## .ctor() -> void
---- PopupBase::.ctor 0x2cddba8
02cddba8: mov     x1, xzr                                    
02cddbac: b       #0x5b397b0                                 UnityEngine.MonoBehaviour::.ctor
