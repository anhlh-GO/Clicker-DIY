#### CLASS CachedValue parent= MonoSingleton`1<CachedValue>
#   field TutorialId                     string                                             off=0x20 attr=6 
#   field TutorialStartTime              float                                              off=0x28 attr=6 
#   field CurrentGameMode                string                                             off=0x30 attr=6 
#   field GameModeStartTime              float                                              off=0x38 attr=6 
#   field GameModePlayCount              int                                                off=0x3c attr=6 
#   field LatestStep                     string                                             off=0x40 attr=6 
## .ctor() -> void
---- CachedValue::.ctor 0x2ca89dc
02ca89dc: stp     x30, x21, [sp, #-0x20]!                    
02ca89e0: stp     x20, x19, [sp, #0x10]                      
02ca89e4: adrp    x20, #0x662f000                            
02ca89e8: adrp    x21, #0x6266000                            
02ca89ec: mov     x19, x0                                    
02ca89f0: ldrb    w8, [x20, #0xb00]                          
02ca89f4: ldr     x21, [x21, #0x630]                         MS:MonoSingleton`1::.ctor
02ca89f8: tbnz    w8, #0, #0x2ca8a10                         
02ca89fc: adrp    x0, #0x6266000                             
02ca8a00: ldr     x0, [x0, #0x630]                           MS:MonoSingleton`1::.ctor
02ca8a04: bl      #0x2b70db0                                 fn_2b70db0
02ca8a08: mov     w8, #1                                     
02ca8a0c: strb    w8, [x20, #0xb00]                          
02ca8a10: mov     x0, x19                                    
02ca8a14: ldp     x20, x19, [sp, #0x10]                      
02ca8a18: ldr     x1, [x21]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca8a1c: ldp     x30, x21, [sp], #0x20                      
02ca8a20: b       #0x3769e18                                 
