#### CLASS NotificationsData parent= UnityEngine.ScriptableObject
#   field notificationDatas              System.Collections.Generic.List`1<NotificationData> off=0x18 attr=1 SerializeField
## GetData() -> System.Collections.Generic.List`1<NotificationData>
---- NotificationsData::GetData 0x2ca8054
02ca8054: ldr     x0, [x0, #0x18]                            .notificationDatas
02ca8058: ret                                                
## .ctor() -> void
---- NotificationsData::.ctor 0x2ca805c
02ca805c: mov     x1, xzr                                    
02ca8060: b       #0x5b398f0                                 UnityEngine.ScriptableObject::.ctor
