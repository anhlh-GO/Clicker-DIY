#### CLASS Clicker.DragType parent= int
#   field value__                        int                                                off=0x10 attr=606 
#   field Switch                         Clicker.DragType                                   off=0x0 attr=8056 
#   field Keycap                         Clicker.DragType                                   off=0x0 attr=8056 
#   field Keychain                       Clicker.DragType                                   off=0x0 attr=8056 
