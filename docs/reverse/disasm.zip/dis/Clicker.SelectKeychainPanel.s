#### CLASS Clicker.SelectKeychainPanel/<>c__DisplayClass13_0 parent= object
#   field dataUser                       DataUser                                           off=0x10 attr=6 
#   field <>4__this                      Clicker.SelectKeychainPanel                        off=0x18 attr=6 
#   field <>9__0                         System.Action`1<int>                               off=0x20 attr=6 
## .ctor() -> void
---- Clicker.SelectKeychainPanel/<>c__DisplayClass13_0::.ctor 0x2d73664
02d73664: mov     x1, xzr                                    
02d73668: b       #0x4e53e9c                                 System.Object::.ctor
## <LoadData>b__0(int id) -> void
---- Clicker.SelectKeychainPanel/<>c__DisplayClass13_0::<LoadData>b__0 0x2d73a50
02d73a50: stp     x30, x21, [sp, #-0x20]!                    
02d73a54: stp     x20, x19, [sp, #0x10]                      
02d73a58: adrp    x21, #0x6630000                            
02d73a5c: mov     w19, w1                                    
02d73a60: mov     x20, x0                                    
02d73a64: ldrb    w8, [x21, #0x3c4]                          
02d73a68: tbnz    w8, #0, #0x2d73a80                         
02d73a6c: adrp    x0, #0x626b000                             
02d73a70: ldr     x0, [x0, #0xee0]                           MS:MonoSingleton`1::get_Instance
02d73a74: bl      #0x2b70db0                                 fn_2b70db0
02d73a78: mov     w8, #1                                     
02d73a7c: strb    w8, [x21, #0x3c4]                          
02d73a80: ldr     x0, [x20, #0x10]                           .dataUser
02d73a84: cbz     x0, #0x2d73b08                             
02d73a88: adrp    x21, #0x626b000                            
02d73a8c: mov     w1, w19                                    
02d73a90: mov     x2, xzr                                    
02d73a94: ldr     x21, [x21, #0xee0]                         MS:MonoSingleton`1::get_Instance
02d73a98: bl      #0x2cac18c                                 DataUser::UnlockClickerKeychain
02d73a9c: ldr     x0, [x21]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d73aa0: bl      #0x3769600                                 fn_3769600
02d73aa4: cbz     x0, #0x2d73b08                             
02d73aa8: mov     w1, w19                                    
02d73aac: mov     x2, xzr                                    
02d73ab0: bl      #0x2d6d1ec                                 Clicker.KeycapMakerController::SetKeychain
02d73ab4: ldr     x8, [x20, #0x18]                           .<>4__this
02d73ab8: cbz     x8, #0x2d73b08                             
02d73abc: ldr     x0, [x8, #0x58]                            
02d73ac0: cbz     x0, #0x2d73b08                             
02d73ac4: mov     w1, #1                                     
02d73ac8: mov     x2, xzr                                    
02d73acc: bl      #0x2d6519c                                 Clicker.IngameClickerScreen::ShowBtnNext
02d73ad0: ldr     x0, [x20, #0x18]                           .<>4__this
02d73ad4: cbz     x0, #0x2d73b08                             
02d73ad8: mov     w1, w19                                    
02d73adc: bl      #0x2d7366c                                 Clicker.SelectKeychainPanel::OnItemSelect
02d73ae0: ldr     x8, [x20, #0x18]                           .<>4__this
02d73ae4: cbz     x8, #0x2d73b08                             
02d73ae8: ldr     x0, [x8, #0x58]                            
02d73aec: mov     w9, #1                                     
02d73af0: strb    w9, [x8, #0x60]                            
02d73af4: cbz     x0, #0x2d73b08                             
02d73af8: ldp     x20, x19, [sp, #0x10]                      
02d73afc: mov     x1, xzr                                    
02d73b00: ldp     x30, x21, [sp], #0x20                      
02d73b04: b       #0x2d6a9a4                                 Clicker.IngameClickerScreen::HideTutorial
02d73b08: bl      #0x2b7105c                                 fn_2b7105c
#### CLASS Clicker.SelectKeychainPanel/<>c__DisplayClass14_0 parent= object
#   field id                             int                                                off=0x10 attr=6 
## .ctor() -> void
---- Clicker.SelectKeychainPanel/<>c__DisplayClass14_0::.ctor 0x2d73744
02d73744: mov     x1, xzr                                    
02d73748: b       #0x4e53e9c                                 System.Object::.ctor
## <OnItemSelect>b__0(Clicker.KeychainUIItem item) -> void
---- Clicker.SelectKeychainPanel/<>c__DisplayClass14_0::<OnItemSelect>b__0 0x2d73b0c
02d73b0c: str     x30, [sp, #-0x20]!                         
02d73b10: stp     x20, x19, [sp, #0x10]                      
02d73b14: cbz     x1, #0x2d73b70                             
02d73b18: mov     x19, x1                                    
02d73b1c: mov     x20, x0                                    
02d73b20: mov     x0, x1                                     
02d73b24: mov     x1, xzr                                    
02d73b28: bl      #0x5b339ec                                 UnityEngine.Component::get_gameObject
02d73b2c: cbz     x0, #0x2d73b70                             
02d73b30: mov     x1, xzr                                    
02d73b34: bl      #0x5b36bfc                                 UnityEngine.GameObject::get_activeSelf
02d73b38: tbz     w0, #0, #0x2d73b64                         
02d73b3c: ldr     x10, [x19]                                 
02d73b40: ldr     w8, [x19, #0x6c]                           
02d73b44: mov     x0, x19                                    
02d73b48: ldr     w9, [x20, #0x10]                           .id
02d73b4c: ldp     x20, x19, [sp, #0x10]                      
02d73b50: ldp     x3, x2, [x10, #0x188]                      
02d73b54: cmp     w8, w9                                     
02d73b58: cset    w1, eq                                     
02d73b5c: ldr     x30, [sp], #0x20                           
02d73b60: br      x3                                         
02d73b64: ldp     x20, x19, [sp, #0x10]                      
02d73b68: ldr     x30, [sp], #0x20                           
02d73b6c: ret                                                
02d73b70: bl      #0x2b7105c                                 fn_2b7105c
#### CLASS Clicker.SelectKeychainPanel parent= UnityEngine.MonoBehaviour
#   field _keychainUIItem                Clicker.KeychainUIItem                             off=0x20 attr=1 SerializeField
#   field _listItem                      System.Collections.Generic.List`1<Clicker.KeychainUIItem> off=0x28 attr=1 SerializeField
#   field _configKeychain                Clicker.KeychainConfig                             off=0x30 attr=1 SerializeField
#   field _rtShowPos                     UnityEngine.RectTransform                          off=0x38 attr=1 SerializeField
#   field _rtHidePos                     UnityEngine.RectTransform                          off=0x40 attr=1 SerializeField
#   field _thisPanelRect                 UnityEngine.RectTransform                          off=0x48 attr=1 SerializeField
#   field _btnNextPos                    UnityEngine.Transform                              off=0x50 attr=1 SerializeField
#   field _ingameClickerScreen           Clicker.IngameClickerScreen                        off=0x58 attr=1 
#   field _tutorialShown                 bool                                               off=0x60 attr=1 
## Init(Clicker.IngameClickerScreen ingameClickerScreen) -> void
---- Clicker.SelectKeychainPanel::Init 0x2d72f24
02d72f24: str     x1, [x0, #0x58]!                           ._ingameClickerScreen
02d72f28: b       #0x2b70d54                                 
## Awake() -> void
---- Clicker.SelectKeychainPanel::Awake 0x2d72f2c
02d72f2c: str     x30, [sp, #-0x20]!                         
02d72f30: stp     x20, x19, [sp, #0x10]                      
02d72f34: mov     x19, x0                                    
02d72f38: ldr     x0, [x0, #0x40]                            ._rtHidePos
02d72f3c: cbz     x0, #0x2d72f8c                             
02d72f40: ldr     x20, [x19, #0x48]                          ._thisPanelRect
02d72f44: mov     x1, xzr                                    
02d72f48: bl      #0x5b45734                                 UnityEngine.RectTransform::get_anchoredPosition
02d72f4c: cbz     x20, #0x2d72f8c                            
02d72f50: mov     x0, x20                                    
02d72f54: mov     x1, xzr                                    
02d72f58: bl      #0x5b45800                                 UnityEngine.RectTransform::set_anchoredPosition
02d72f5c: ldr     x0, [x19, #0x48]                           ._thisPanelRect
02d72f60: cbz     x0, #0x2d72f8c                             
02d72f64: mov     x1, xzr                                    
02d72f68: bl      #0x5b339ec                                 UnityEngine.Component::get_gameObject
02d72f6c: cbz     x0, #0x2d72f8c                             
02d72f70: mov     w1, wzr                                    
02d72f74: mov     x2, xzr                                    
02d72f78: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d72f7c: mov     x0, x19                                    
02d72f80: ldp     x20, x19, [sp, #0x10]                      
02d72f84: ldr     x30, [sp], #0x20                           
02d72f88: b       #0x2d72f90                                 Clicker.SelectKeychainPanel::LoadData
02d72f8c: bl      #0x2b7105c                                 fn_2b7105c
## ShowPanel() -> void
---- Clicker.SelectKeychainPanel::ShowPanel 0x2d733d4
02d733d4: str     x30, [sp, #-0x50]!                         
02d733d8: stp     x26, x25, [sp, #0x10]                      
02d733dc: stp     x24, x23, [sp, #0x20]                      
02d733e0: stp     x22, x21, [sp, #0x30]                      
02d733e4: stp     x20, x19, [sp, #0x40]                      
02d733e8: adrp    x20, #0x6630000                            
02d733ec: mov     x19, x0                                    
02d733f0: ldrb    w8, [x20, #0x3bd]                          
02d733f4: tbnz    w8, #0, #0x2d73448                         
02d733f8: adrp    x0, #0x6264000                             
02d733fc: ldr     x0, [x0, #0xf90]                           T:System.Action
02d73400: bl      #0x2b70db0                                 fn_2b70db0
02d73404: adrp    x0, #0x626c000                             
02d73408: ldr     x0, [x0, #0x6d0]                           M:Clicker.SelectKeychainPanel::<ShowPanel>b__11_0
02d7340c: bl      #0x2b70db0                                 fn_2b70db0
02d73410: adrp    x0, #0x626c000                             
02d73414: ldr     x0, [x0, #0x6d8]                           M:Clicker.SelectKeychainPanel::<ShowPanel>b__11_1
02d73418: bl      #0x2b70db0                                 fn_2b70db0
02d7341c: adrp    x0, #0x6264000                             
02d73420: ldr     x0, [x0, #0xe8]                            T:DG.Tweening.TweenCallback
02d73424: bl      #0x2b70db0                                 fn_2b70db0
02d73428: adrp    x0, #0x6266000                             
02d7342c: ldr     x0, [x0, #0xa08]                           MS:DG.Tweening.TweenSettingsExtensions::OnComplete
02d73430: bl      #0x2b70db0                                 fn_2b70db0
02d73434: adrp    x0, #0x6266000                             
02d73438: ldr     x0, [x0, #0xa18]                           MS:DG.Tweening.TweenSettingsExtensions::SetEase
02d7343c: bl      #0x2b70db0                                 fn_2b70db0
02d73440: mov     w8, #1                                     
02d73444: strb    w8, [x20, #0x3bd]                          
02d73448: ldr     x0, [x19, #0x48]                           ._thisPanelRect
02d7344c: cbz     x0, #0x2d7356c                             
02d73450: mov     x1, xzr                                    
02d73454: bl      #0x5b339ec                                 UnityEngine.Component::get_gameObject
02d73458: cbz     x0, #0x2d7356c                             
02d7345c: mov     w1, #1                                     
02d73460: mov     x2, xzr                                    
02d73464: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d73468: ldr     x0, [x19, #0x38]                           ._rtShowPos
02d7346c: cbz     x0, #0x2d7356c                             
02d73470: adrp    x21, #0x6266000                            
02d73474: adrp    x23, #0x6264000                            
02d73478: adrp    x24, #0x626c000                            
02d7347c: adrp    x25, #0x6266000                            
02d73480: adrp    x26, #0x6264000                            
02d73484: adrp    x22, #0x626c000                            
02d73488: ldr     x21, [x21, #0xa18]                         MS:DG.Tweening.TweenSettingsExtensions::SetEase
02d7348c: ldr     x23, [x23, #0xe8]                          T:DG.Tweening.TweenCallback
02d73490: ldr     x24, [x24, #0x6d0]                         M:Clicker.SelectKeychainPanel::<ShowPanel>b__11_0
02d73494: ldr     x25, [x25, #0xa08]                         MS:DG.Tweening.TweenSettingsExtensions::OnComplete
02d73498: ldr     x26, [x26, #0xf90]                         T:System.Action
02d7349c: ldr     x22, [x22, #0x6d8]                         M:Clicker.SelectKeychainPanel::<ShowPanel>b__11_1
02d734a0: ldr     x20, [x19, #0x48]                          ._thisPanelRect
02d734a4: mov     x1, xzr                                    
02d734a8: bl      #0x5b45734                                 UnityEngine.RectTransform::get_anchoredPosition
02d734ac: fmov    s2, #0.50000000                            
02d734b0: mov     x0, x20                                    
02d734b4: mov     w1, wzr                                    
02d734b8: mov     x2, xzr                                    
02d734bc: bl      #0x2c798bc                                 DG.Tweening.DOTweenModuleUI::DOAnchorPos
02d734c0: ldr     x2, [x21]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d734c4: mov     w1, #3                                     
02d734c8: bl      #0x336fa0c                                 fn_336fa0c
02d734cc: ldr     x8, [x23]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d734d0: mov     x20, x0                                    
02d734d4: mov     x0, x8                                     
02d734d8: bl      #0x2b7104c                                 fn_2b7104c
02d734dc: ldr     x2, [x24]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d734e0: mov     x1, x19                                    
02d734e4: mov     x3, xzr                                    
02d734e8: mov     x21, x0                                    
02d734ec: bl      #0x2d89dc4                                 DG.Tweening.TweenCallback::.ctor
02d734f0: ldr     x2, [x25]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d734f4: mov     x0, x20                                    
02d734f8: mov     x1, x21                                    
02d734fc: bl      #0x336f26c                                 fn_336f26c
02d73500: ldr     x0, [x26]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d73504: ldr     x20, [x19, #0x58]                          ._ingameClickerScreen
02d73508: bl      #0x2b7104c                                 fn_2b7104c
02d7350c: ldr     x2, [x22]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d73510: mov     x1, x19                                    
02d73514: mov     x3, xzr                                    
02d73518: mov     x21, x0                                    
02d7351c: bl      #0x4d8ddbc                                 System.Action::.ctor
02d73520: cbz     x20, #0x2d7356c                            
02d73524: mov     x0, x20                                    
02d73528: mov     x1, x21                                    
02d7352c: mov     x2, xzr                                    
02d73530: bl      #0x2d69948                                 Clicker.IngameClickerScreen::RegisterButtonNextEvent
02d73534: ldr     x0, [x19, #0x50]                           ._btnNextPos
02d73538: cbz     x0, #0x2d7356c                             
02d7353c: ldr     x19, [x19, #0x58]                          ._ingameClickerScreen
02d73540: mov     x1, xzr                                    
02d73544: bl      #0x5b467ac                                 UnityEngine.Transform::get_position
02d73548: cbz     x19, #0x2d7356c                            
02d7354c: mov     x0, x19                                    
02d73550: ldp     x20, x19, [sp, #0x40]                      
02d73554: ldp     x22, x21, [sp, #0x30]                      
02d73558: mov     x1, xzr                                    
02d7355c: ldp     x24, x23, [sp, #0x20]                      
02d73560: ldp     x26, x25, [sp, #0x10]                      
02d73564: ldr     x30, [sp], #0x50                           
02d73568: b       #0x2d69a28                                 Clicker.IngameClickerScreen::SetBtnNextPosition
02d7356c: bl      #0x2b7105c                                 fn_2b7105c
## HidePanel() -> void
---- Clicker.SelectKeychainPanel::HidePanel 0x2d73570
02d73570: str     x30, [sp, #-0x40]!                         
02d73574: stp     x24, x23, [sp, #0x10]                      
02d73578: stp     x22, x21, [sp, #0x20]                      
02d7357c: stp     x20, x19, [sp, #0x30]                      
02d73580: adrp    x20, #0x6630000                            
02d73584: mov     x19, x0                                    
02d73588: ldrb    w8, [x20, #0x3be]                          
02d7358c: tbnz    w8, #0, #0x2d735c8                         
02d73590: adrp    x0, #0x626c000                             
02d73594: ldr     x0, [x0, #0x6e0]                           M:Clicker.SelectKeychainPanel::<HidePanel>b__12_0
02d73598: bl      #0x2b70db0                                 fn_2b70db0
02d7359c: adrp    x0, #0x6264000                             
02d735a0: ldr     x0, [x0, #0xe8]                            T:DG.Tweening.TweenCallback
02d735a4: bl      #0x2b70db0                                 fn_2b70db0
02d735a8: adrp    x0, #0x6266000                             
02d735ac: ldr     x0, [x0, #0xa08]                           MS:DG.Tweening.TweenSettingsExtensions::OnComplete
02d735b0: bl      #0x2b70db0                                 fn_2b70db0
02d735b4: adrp    x0, #0x6266000                             
02d735b8: ldr     x0, [x0, #0xa18]                           MS:DG.Tweening.TweenSettingsExtensions::SetEase
02d735bc: bl      #0x2b70db0                                 fn_2b70db0
02d735c0: mov     w8, #1                                     
02d735c4: strb    w8, [x20, #0x3be]                          
02d735c8: ldr     x0, [x19, #0x40]                           ._rtHidePos
02d735cc: cbz     x0, #0x2d73660                             
02d735d0: adrp    x21, #0x6266000                            
02d735d4: adrp    x22, #0x6264000                            
02d735d8: adrp    x23, #0x626c000                            
02d735dc: adrp    x24, #0x6266000                            
02d735e0: ldr     x21, [x21, #0xa18]                         MS:DG.Tweening.TweenSettingsExtensions::SetEase
02d735e4: ldr     x22, [x22, #0xe8]                          T:DG.Tweening.TweenCallback
02d735e8: ldr     x23, [x23, #0x6e0]                         M:Clicker.SelectKeychainPanel::<HidePanel>b__12_0
02d735ec: ldr     x24, [x24, #0xa08]                         MS:DG.Tweening.TweenSettingsExtensions::OnComplete
02d735f0: ldr     x20, [x19, #0x48]                          ._thisPanelRect
02d735f4: mov     x1, xzr                                    
02d735f8: bl      #0x5b45734                                 UnityEngine.RectTransform::get_anchoredPosition
02d735fc: fmov    s2, #0.50000000                            
02d73600: mov     x0, x20                                    
02d73604: mov     w1, wzr                                    
02d73608: mov     x2, xzr                                    
02d7360c: bl      #0x2c798bc                                 DG.Tweening.DOTweenModuleUI::DOAnchorPos
02d73610: ldr     x2, [x21]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d73614: mov     w1, #2                                     
02d73618: bl      #0x336fa0c                                 fn_336fa0c
02d7361c: ldr     x8, [x22]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d73620: mov     x20, x0                                    
02d73624: mov     x0, x8                                     
02d73628: bl      #0x2b7104c                                 fn_2b7104c
02d7362c: ldr     x2, [x23]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d73630: mov     x1, x19                                    
02d73634: mov     x3, xzr                                    
02d73638: mov     x21, x0                                    
02d7363c: bl      #0x2d89dc4                                 DG.Tweening.TweenCallback::.ctor
02d73640: ldr     x2, [x24]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d73644: mov     x0, x20                                    
02d73648: mov     x1, x21                                    
02d7364c: ldp     x20, x19, [sp, #0x30]                      
02d73650: ldp     x22, x21, [sp, #0x20]                      
02d73654: ldp     x24, x23, [sp, #0x10]                      
02d73658: ldr     x30, [sp], #0x40                           
02d7365c: b       #0x336f26c                                 
02d73660: bl      #0x2b7105c                                 fn_2b7105c
## LoadData() -> void
---- Clicker.SelectKeychainPanel::LoadData 0x2d72f90
02d72f90: stp     x29, x30, [sp, #-0x60]!                    
02d72f94: stp     x28, x27, [sp, #0x10]                      
02d72f98: stp     x26, x25, [sp, #0x20]                      
02d72f9c: stp     x24, x23, [sp, #0x30]                      
02d72fa0: stp     x22, x21, [sp, #0x40]                      
02d72fa4: stp     x20, x19, [sp, #0x50]                      
02d72fa8: adrp    x20, #0x6630000                            
02d72fac: adrp    x21, #0x626c000                            
02d72fb0: mov     x19, x0                                    
02d72fb4: ldrb    w8, [x20, #0x3bf]                          
02d72fb8: ldr     x21, [x21, #0x6a0]                         T:Clicker.SelectKeychainPanel/<>c__DisplayClass13_0
02d72fbc: tbnz    w8, #0, #0x2d73040                         
02d72fc0: adrp    x0, #0x6269000                             
02d72fc4: ldr     x0, [x0, #0x5e8]                           T:type6940(k15)
02d72fc8: bl      #0x2b70db0                                 fn_2b70db0
02d72fcc: adrp    x0, #0x6266000                             
02d72fd0: ldr     x0, [x0, #0x750]                           MS:DataManager::GetData
02d72fd4: bl      #0x2b70db0                                 fn_2b70db0
02d72fd8: adrp    x0, #0x626c000                             
02d72fdc: ldr     x0, [x0, #0x6a8]                           MS:System.Collections.Generic.List`1::Add
02d72fe0: bl      #0x2b70db0                                 fn_2b70db0
02d72fe4: adrp    x0, #0x626c000                             
02d72fe8: ldr     x0, [x0, #0x6b0]                           MS:System.Collections.Generic.List`1::get_Count
02d72fec: bl      #0x2b70db0                                 fn_2b70db0
02d72ff0: adrp    x0, #0x626c000                             
02d72ff4: ldr     x0, [x0, #0x6b8]                           MS:System.Collections.Generic.List`1::get_Item
02d72ff8: bl      #0x2b70db0                                 fn_2b70db0
02d72ffc: adrp    x0, #0x6266000                             
02d73000: ldr     x0, [x0, #0x658]                           MS:MonoSingleton`1::get_Instance
02d73004: bl      #0x2b70db0                                 fn_2b70db0
02d73008: adrp    x0, #0x626c000                             
02d7300c: ldr     x0, [x0, #0x6c0]                           MS:UnityEngine.Object::Instantiate
02d73010: bl      #0x2b70db0                                 fn_2b70db0
02d73014: adrp    x0, #0x6263000                             
02d73018: ldr     x0, [x0, #0x918]                           T:UnityEngine.Object
02d7301c: bl      #0x2b70db0                                 fn_2b70db0
02d73020: adrp    x0, #0x626c000                             
02d73024: ldr     x0, [x0, #0x6c8]                           M:Clicker.SelectKeychainPanel/<>c__DisplayClass13_0::<LoadData>b__0
02d73028: bl      #0x2b70db0                                 fn_2b70db0
02d7302c: adrp    x0, #0x626c000                             
02d73030: ldr     x0, [x0, #0x6a0]                           T:Clicker.SelectKeychainPanel/<>c__DisplayClass13_0
02d73034: bl      #0x2b70db0                                 fn_2b70db0
02d73038: mov     w8, #1                                     
02d7303c: strb    w8, [x20, #0x3bf]                          
02d73040: ldr     x0, [x21]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d73044: bl      #0x2b7104c                                 fn_2b7104c
02d73048: mov     x1, xzr                                    
02d7304c: mov     x20, x0                                    
02d73050: bl      #0x4e53e9c                                 System.Object::.ctor
02d73054: cbz     x20, #0x2d733b4                            
02d73058: mov     x0, x20                                    
02d7305c: mov     x1, x19                                    
02d73060: str     x19, [x0, #0x18]!                          
02d73064: bl      #0x2b70d54                                 fn_2b70d54
02d73068: ldr     x8, [x19, #0x28]                           ._listItem
02d7306c: cbz     x8, #0x2d733b4                             
02d73070: adrp    x27, #0x626c000                            
02d73074: adrp    x28, #0x6269000                            
02d73078: adrp    x29, #0x626c000                            
02d7307c: adrp    x26, #0x6263000                            
02d73080: adrp    x24, #0x626c000                            
02d73084: adrp    x25, #0x626c000                            
02d73088: ldr     x27, [x27, #0x6b8]                         MS:System.Collections.Generic.List`1::get_Item
02d7308c: ldr     x28, [x28, #0x5e8]                         T:type6940(k15)
02d73090: ldr     x29, [x29, #0x6c8]                         M:Clicker.SelectKeychainPanel/<>c__DisplayClass13_0::<LoadData>b__0
02d73094: ldr     x26, [x26, #0x918]                         T:UnityEngine.Object
02d73098: ldr     x24, [x24, #0x6c0]                         MS:UnityEngine.Object::Instantiate
02d7309c: ldr     x25, [x25, #0x6a8]                         MS:System.Collections.Generic.List`1::Add
02d730a0: ldr     x0, [x19, #0x30]                           ._configKeychain
02d730a4: cbz     x0, #0x2d733b4                             
02d730a8: ldr     w21, [x8, #0x18]                           
02d730ac: mov     x1, xzr                                    
02d730b0: bl      #0x2d5b9d0                                 Clicker.KeychainConfig::get_Count
02d730b4: cmp     w21, w0                                    
02d730b8: b.ge    #0x2d73170                                 
02d730bc: ldr     x22, [x19, #0x20]                          ._keychainUIItem
02d730c0: cbz     x22, #0x2d733b4                            
02d730c4: ldr     x21, [x19, #0x28]                          ._listItem
02d730c8: mov     x0, x22                                    
02d730cc: mov     x1, xzr                                    
02d730d0: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02d730d4: cbz     x0, #0x2d733b4                             
02d730d8: mov     x1, xzr                                    
02d730dc: bl      #0x5b466dc                                 UnityEngine.Transform::get_parent
02d730e0: ldr     x8, [x26]                                  &2c5bbd4(=a9bd7bfdd503233f)
02d730e4: mov     x23, x0                                    
02d730e8: ldr     w9, [x8, #0xe4]                            
02d730ec: cbnz    w9, #0x2d730f8                             
02d730f0: mov     x0, x8                                     
02d730f4: bl      #0x2b70f30                                 fn_2b70f30
02d730f8: ldr     x2, [x24]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d730fc: mov     x0, x22                                    
02d73100: mov     x1, x23                                    
02d73104: bl      #0x3275fcc                                 fn_3275fcc
02d73108: cbz     x21, #0x2d733b4                            
02d7310c: ldr     w10, [x21, #0x1c]                          [626c01c]=0 f=0,0
02d73110: ldr     x8, [x21, #0x10]                           M:Clicker.GlowSprite2DItem::<DoGlow>b__10_4
02d73114: ldr     x9, [x25]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d73118: add     w10, w10, #1                               
02d7311c: str     w10, [x21, #0x1c]                          
02d73120: cbz     x8, #0x2d733b4                             
02d73124: ldrsw   x10, [x21, #0x18]                          
02d73128: ldr     w11, [x8, #0x18]                           
02d7312c: mov     x1, x0                                     
02d73130: cmp     w10, w11                                   
02d73134: b.hs    #0x2d73150                                 
02d73138: add     x0, x8, x10, lsl #3                        
02d7313c: add     w9, w10, #1                                
02d73140: str     w9, [x21, #0x18]                           
02d73144: str     x1, [x0, #0x20]!                           ._keychainUIItem
02d73148: bl      #0x2b70d54                                 fn_2b70d54
02d7314c: b       #0x2d73164                                 
02d73150: ldr     x8, [x9, #0x20]                            
02d73154: mov     x0, x21                                    
02d73158: ldr     x8, [x8, #0xc0]                            
02d7315c: ldr     x2, [x8, #0x70]                            
02d73160: bl      #0x35a920c                                 fn_35a920c
02d73164: ldr     x8, [x19, #0x28]                           ._listItem
02d73168: cbnz    x8, #0x2d730a0                             
02d7316c: b       #0x2d733b4                                 
02d73170: adrp    x8, #0x6266000                             
02d73174: ldr     x8, [x8, #0x658]                           MS:MonoSingleton`1::get_Instance
02d73178: ldr     x0, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d7317c: bl      #0x3769600                                 fn_3769600
02d73180: cbz     x0, #0x2d733b4                             
02d73184: adrp    x8, #0x6266000                             
02d73188: ldr     x8, [x8, #0x750]                           MS:DataManager::GetData
02d7318c: ldr     x1, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d73190: bl      #0x3168dd0                                 fn_3168dd0
02d73194: mov     x21, x20                                   
02d73198: mov     x1, x0                                     
02d7319c: str     x0, [x21, #0x10]!                          
02d731a0: mov     x0, x21                                    
02d731a4: bl      #0x2b70d54                                 fn_2b70d54
02d731a8: ldr     x0, [x19, #0x30]                           ._configKeychain
02d731ac: cbz     x0, #0x2d733b4                             
02d731b0: mov     w22, wzr                                   
02d731b4: mov     x1, xzr                                    
02d731b8: bl      #0x2d5b9d0                                 Clicker.KeychainConfig::get_Count
02d731bc: mov     w8, w0                                     
02d731c0: ldr     x0, [x19, #0x30]                           ._configKeychain
02d731c4: cmp     w22, w8                                    
02d731c8: b.ge    #0x2d73358                                 
02d731cc: cbz     x0, #0x2d733b4                             
02d731d0: mov     w1, w22                                    
02d731d4: mov     x2, xzr                                    
02d731d8: bl      #0x2d5ba88                                 Clicker.KeychainConfig::GetData
02d731dc: mov     x23, x0                                    
02d731e0: ldr     x0, [x19, #0x28]                           ._listItem
02d731e4: cbz     x23, #0x2d73254                            
02d731e8: cbz     x0, #0x2d733b4                             
02d731ec: ldr     x2, [x27]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d731f0: mov     w1, w22                                    
02d731f4: bl      #0x35a8f3c                                 fn_35a8f3c
02d731f8: cbz     x0, #0x2d733b4                             
02d731fc: ldr     x8, [x0]                                   M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d73200: ldr     x2, [x23, #0x18]                           
02d73204: ldr     w1, [x23, #0x10]                           
02d73208: ldp     x9, x3, [x8, #0x178]                       
02d7320c: blr     x9                                         
02d73210: ldr     x0, [x19, #0x28]                           ._listItem
02d73214: cbz     x0, #0x2d733b4                             
02d73218: ldr     x2, [x27]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d7321c: mov     w1, w22                                    
02d73220: bl      #0x35a8f3c                                 fn_35a8f3c
02d73224: ldr     x8, [x23, #0x28]                           
02d73228: cbz     x8, #0x2d733b4                             
02d7322c: mov     x24, x0                                    
02d73230: ldr     x0, [x21]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d73234: cbz     x0, #0x2d733b4                             
02d73238: ldp     w25, w26, [x8, #0x10]                      
02d7323c: ldr     w1, [x23, #0x10]                           
02d73240: mov     x2, xzr                                    
02d73244: bl      #0x2cac284                                 DataUser::HasUnlockedClickerKeychain
02d73248: tbz     w0, #0, #0x2d73284                         
02d7324c: mov     w3, #1                                     
02d73250: b       #0x2d73298                                 
02d73254: cbz     x0, #0x2d733b4                             
02d73258: ldr     x2, [x27]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d7325c: mov     w1, w22                                    
02d73260: bl      #0x35a8f3c                                 fn_35a8f3c
02d73264: cbz     x0, #0x2d733b4                             
02d73268: mov     x1, xzr                                    
02d7326c: bl      #0x5b339ec                                 UnityEngine.Component::get_gameObject
02d73270: cbz     x0, #0x2d733b4                             
02d73274: mov     w1, wzr                                    
02d73278: mov     x2, xzr                                    
02d7327c: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d73280: b       #0x2d73348                                 
02d73284: ldr     x8, [x23, #0x28]                           
02d73288: cbz     x8, #0x2d733b4                             
02d7328c: ldr     w8, [x8, #0x10]                            S:'mrec_ad_on_off'
02d73290: cmp     w8, #0                                     
02d73294: cset    w3, eq                                     
02d73298: cbz     x24, #0x2d733b4                            
02d7329c: ldr     x8, [x24]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d732a0: mov     x0, x24                                    
02d732a4: mov     w1, w25                                    
02d732a8: mov     w2, w26                                    
02d732ac: ldp     x9, x4, [x8, #0x1a8]                       
02d732b0: blr     x9                                         
02d732b4: ldr     x0, [x19, #0x28]                           ._listItem
02d732b8: cbz     x0, #0x2d733b4                             
02d732bc: ldr     x2, [x27]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d732c0: mov     w1, w22                                    
02d732c4: bl      #0x35a8f3c                                 fn_35a8f3c
02d732c8: cbz     x0, #0x2d733b4                             
02d732cc: mov     x1, xzr                                    
02d732d0: bl      #0x5b339ec                                 UnityEngine.Component::get_gameObject
02d732d4: cbz     x0, #0x2d733b4                             
02d732d8: mov     w1, #1                                     
02d732dc: mov     x2, xzr                                    
02d732e0: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d732e4: ldr     x0, [x19, #0x28]                           ._listItem
02d732e8: cbz     x0, #0x2d733b4                             
02d732ec: ldr     x2, [x27]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d732f0: mov     w1, w22                                    
02d732f4: bl      #0x35a8f3c                                 fn_35a8f3c
02d732f8: ldur    x24, [x20, #0x20]                          ._keychainUIItem
02d732fc: mov     x23, x0                                    
02d73300: cbnz    x24, #0x2d73330                            
02d73304: ldr     x0, [x28]                                  T:Trading.TradingSession/<>c__DisplayClass56_0
02d73308: bl      #0x2b7104c                                 fn_2b7104c
02d7330c: ldr     x2, [x29]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d73310: mov     x1, x20                                    
02d73314: mov     x3, xzr                                    
02d73318: mov     x24, x0                                    
02d7331c: bl      #0x4532eb0                                 fn_4532eb0
02d73320: add     x0, x20, #0x20                             &6630020
02d73324: mov     x1, x24                                    
02d73328: str     x24, [x20, #0x20]                          ._keychainUIItem
02d7332c: bl      #0x2b70d54                                 fn_2b70d54
02d73330: cbz     x23, #0x2d733b4                            
02d73334: ldr     x8, [x23]                                  
02d73338: mov     x0, x23                                    
02d7333c: mov     x1, x24                                    
02d73340: ldp     x9, x2, [x8, #0x198]                       
02d73344: blr     x9                                         
02d73348: ldr     x0, [x19, #0x30]                           ._configKeychain
02d7334c: add     w22, w22, #1                               
02d73350: cbnz    x0, #0x2d731b4                             
02d73354: b       #0x2d733b4                                 
02d73358: cbz     x0, #0x2d733b4                             
02d7335c: mov     x1, xzr                                    
02d73360: bl      #0x2d5b9d0                                 Clicker.KeychainConfig::get_Count
02d73364: ldr     x8, [x19, #0x28]                           ._listItem
02d73368: cbz     x8, #0x2d733b4                             
02d7336c: mov     w20, w0                                    
02d73370: ldr     w9, [x8, #0x18]                            S:'level_show_popuprate'
02d73374: cmp     w20, w9                                    
02d73378: b.ge    #0x2d733b8                                 
02d7337c: ldr     x2, [x27]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d73380: mov     x0, x8                                     
02d73384: mov     w1, w20                                    
02d73388: bl      #0x35a8f3c                                 fn_35a8f3c
02d7338c: cbz     x0, #0x2d733b4                             
02d73390: mov     x1, xzr                                    
02d73394: bl      #0x5b339ec                                 UnityEngine.Component::get_gameObject
02d73398: cbz     x0, #0x2d733b4                             
02d7339c: mov     w1, wzr                                    
02d733a0: mov     x2, xzr                                    
02d733a4: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d733a8: ldr     x8, [x19, #0x28]                           ._listItem
02d733ac: add     w20, w20, #1                               
02d733b0: cbnz    x8, #0x2d73370                             
02d733b4: bl      #0x2b7105c                                 fn_2b7105c
02d733b8: ldp     x20, x19, [sp, #0x50]                      
02d733bc: ldp     x22, x21, [sp, #0x40]                      
02d733c0: ldp     x24, x23, [sp, #0x30]                      
02d733c4: ldp     x26, x25, [sp, #0x20]                      
02d733c8: ldp     x28, x27, [sp, #0x10]                      
02d733cc: ldp     x29, x30, [sp], #0x60                      
02d733d0: ret                                                
## OnItemSelect(int id) -> void
---- Clicker.SelectKeychainPanel::OnItemSelect 0x2d7366c
02d7366c: str     x30, [sp, #-0x30]!                         
02d73670: stp     x22, x21, [sp, #0x10]                      
02d73674: stp     x20, x19, [sp, #0x20]                      
02d73678: adrp    x21, #0x6630000                            
02d7367c: adrp    x22, #0x626c000                            
02d73680: mov     w19, w1                                    
02d73684: ldrb    w8, [x21, #0x3c0]                          
02d73688: ldr     x22, [x22, #0x6e8]                         T:Clicker.SelectKeychainPanel/<>c__DisplayClass14_0
02d7368c: mov     x20, x0                                    
02d73690: tbnz    w8, #0, #0x2d736cc                         
02d73694: adrp    x0, #0x626c000                             
02d73698: ldr     x0, [x0, #0x6f0]                           T:type53142(k15)
02d7369c: bl      #0x2b70db0                                 fn_2b70db0
02d736a0: adrp    x0, #0x626c000                             
02d736a4: ldr     x0, [x0, #0x6f8]                           MS:System.Collections.Generic.List`1::ForEach
02d736a8: bl      #0x2b70db0                                 fn_2b70db0
02d736ac: adrp    x0, #0x626c000                             
02d736b0: ldr     x0, [x0, #0x700]                           M:Clicker.SelectKeychainPanel/<>c__DisplayClass14_0::<OnItemSelect>b__0
02d736b4: bl      #0x2b70db0                                 fn_2b70db0
02d736b8: adrp    x0, #0x626c000                             
02d736bc: ldr     x0, [x0, #0x6e8]                           T:Clicker.SelectKeychainPanel/<>c__DisplayClass14_0
02d736c0: bl      #0x2b70db0                                 fn_2b70db0
02d736c4: mov     w8, #1                                     
02d736c8: strb    w8, [x21, #0x3c0]                          
02d736cc: ldr     x0, [x22]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d736d0: bl      #0x2b7104c                                 fn_2b7104c
02d736d4: mov     x1, xzr                                    
02d736d8: mov     x21, x0                                    
02d736dc: bl      #0x4e53e9c                                 System.Object::.ctor
02d736e0: cbz     x21, #0x2d73740                            
02d736e4: adrp    x8, #0x626c000                             
02d736e8: adrp    x22, #0x626c000                            
02d736ec: ldr     x8, [x8, #0x6f0]                           T:type53142(k15)
02d736f0: ldr     x22, [x22, #0x700]                         M:Clicker.SelectKeychainPanel/<>c__DisplayClass14_0::<OnItemSelect>b__0
02d736f4: ldr     x20, [x20, #0x28]                          ._listItem
02d736f8: str     w19, [x21, #0x10]                          
02d736fc: ldr     x0, [x8]                                   M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d73700: bl      #0x2b7104c                                 fn_2b7104c
02d73704: ldr     x2, [x22]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d73708: mov     x1, x21                                    
02d7370c: mov     x3, xzr                                    
02d73710: mov     x19, x0                                    
02d73714: bl      #0x453418c                                 fn_453418c
02d73718: cbz     x20, #0x2d73740                            
02d7371c: adrp    x8, #0x626c000                             
02d73720: mov     x0, x20                                    
02d73724: mov     x1, x19                                    
02d73728: ldr     x8, [x8, #0x6f8]                           MS:System.Collections.Generic.List`1::ForEach
02d7372c: ldp     x20, x19, [sp, #0x20]                      
02d73730: ldp     x22, x21, [sp, #0x10]                      
02d73734: ldr     x2, [x8]                                   M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d73738: ldr     x30, [sp], #0x30                           
02d7373c: b       #0x35a9ce4                                 
02d73740: bl      #0x2b7105c                                 fn_2b7105c
## .ctor() -> void
---- Clicker.SelectKeychainPanel::.ctor 0x2d7374c
02d7374c: mov     x1, xzr                                    
02d73750: b       #0x5b397b0                                 UnityEngine.MonoBehaviour::.ctor
## <ShowPanel>b__11_0() -> void
---- Clicker.SelectKeychainPanel::<ShowPanel>b__11_0 0x2d73754
02d73754: str     x30, [sp, #-0x20]!                         
02d73758: stp     x20, x19, [sp, #0x10]                      
02d7375c: adrp    x20, #0x6630000                            
02d73760: mov     x19, x0                                    
02d73764: ldrb    w8, [x20, #0x3c1]                          
02d73768: tbnz    w8, #0, #0x2d73780                         
02d7376c: adrp    x0, #0x626c000                             
02d73770: ldr     x0, [x0, #0x6b8]                           MS:System.Collections.Generic.List`1::get_Item
02d73774: bl      #0x2b70db0                                 fn_2b70db0
02d73778: mov     w8, #1                                     
02d7377c: strb    w8, [x20, #0x3c1]                          
02d73780: ldrb    w8, [x19, #0x60]                           ._tutorialShown
02d73784: cbz     w8, #0x2d73794                             
02d73788: ldp     x20, x19, [sp, #0x10]                      
02d7378c: ldr     x30, [sp], #0x20                           
02d73790: ret                                                
02d73794: ldr     x0, [x19, #0x28]                           ._listItem
02d73798: cbz     x0, #0x2d737dc                             
02d7379c: adrp    x8, #0x626c000                             
02d737a0: mov     w1, wzr                                    
02d737a4: ldr     x8, [x8, #0x6b8]                           MS:System.Collections.Generic.List`1::get_Item
02d737a8: ldr     x19, [x19, #0x58]                          ._ingameClickerScreen
02d737ac: ldr     x2, [x8]                                   M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d737b0: bl      #0x35a8f3c                                 fn_35a8f3c
02d737b4: cbz     x0, #0x2d737dc                             
02d737b8: mov     x1, xzr                                    
02d737bc: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02d737c0: cbz     x19, #0x2d737dc                            
02d737c4: mov     x1, x0                                     
02d737c8: mov     x0, x19                                    
02d737cc: mov     x2, xzr                                    
02d737d0: ldp     x20, x19, [sp, #0x10]                      
02d737d4: ldr     x30, [sp], #0x20                           
02d737d8: b       #0x2d6a2c0                                 Clicker.IngameClickerScreen::ShowTutorialAt
02d737dc: bl      #0x2b7105c                                 fn_2b7105c
## <ShowPanel>b__11_1() -> void
---- Clicker.SelectKeychainPanel::<ShowPanel>b__11_1 0x2d737e0
02d737e0: stp     x30, x21, [sp, #-0x20]!                    
02d737e4: stp     x20, x19, [sp, #0x10]                      
02d737e8: adrp    x20, #0x6630000                            
02d737ec: adrp    x21, #0x6266000                            
02d737f0: mov     x19, x0                                    
02d737f4: ldrb    w8, [x20, #0x3c2]                          
02d737f8: ldr     x21, [x21, #0x658]                         MS:MonoSingleton`1::get_Instance
02d737fc: tbnz    w8, #0, #0x2d73850                         
02d73800: adrp    x0, #0x6264000                             
02d73804: ldr     x0, [x0, #0xf90]                           T:System.Action
02d73808: bl      #0x2b70db0                                 fn_2b70db0
02d7380c: adrp    x0, #0x6266000                             
02d73810: ldr     x0, [x0, #0x750]                           MS:DataManager::GetData
02d73814: bl      #0x2b70db0                                 fn_2b70db0
02d73818: adrp    x0, #0x6266000                             
02d7381c: ldr     x0, [x0, #0x658]                           MS:MonoSingleton`1::get_Instance
02d73820: bl      #0x2b70db0                                 fn_2b70db0
02d73824: adrp    x0, #0x626c000                             
02d73828: ldr     x0, [x0, #0x708]                           M:Clicker.SelectKeychainPanel::<ShowPanel>g__ContinueToAssemble|11_2
02d7382c: bl      #0x2b70db0                                 fn_2b70db0
02d73830: adrp    x0, #0x6265000                             
02d73834: ldr     x0, [x0, #0x310]                           MS:WejoyService.Singleton`1::get_Instance
02d73838: bl      #0x2b70db0                                 fn_2b70db0
02d7383c: adrp    x0, #0x626c000                             
02d73840: ldr     x0, [x0, #0x710]                           S:'done_selecte_item'
02d73844: bl      #0x2b70db0                                 fn_2b70db0
02d73848: mov     w8, #1                                     
02d7384c: strb    w8, [x20, #0x3c2]                          
02d73850: ldr     x0, [x21]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d73854: bl      #0x3769600                                 fn_3769600
02d73858: cbz     x0, #0x2d73904                             
02d7385c: adrp    x8, #0x6266000                             
02d73860: ldr     x8, [x8, #0x750]                           MS:DataManager::GetData
02d73864: ldr     x1, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d73868: bl      #0x3168dd0                                 fn_3168dd0
02d7386c: cbz     x0, #0x2d73904                             
02d73870: ldr     x8, [x0, #0x20]                            M:Clicker.GlowSprite2DItem::<DoGlow>b__10_6 ._keychainUIItem
02d73874: cbz     x8, #0x2d73904                             
02d73878: ldr     w8, [x8, #0x3c]                            [626603c]=0 f=0,0
02d7387c: cmp     w8, #1                                     
02d73880: b.lt    #0x2d738f4                                 
02d73884: adrp    x8, #0x6265000                             
02d73888: adrp    x20, #0x6264000                            
02d7388c: adrp    x21, #0x626c000                            
02d73890: ldr     x8, [x8, #0x310]                           MS:WejoyService.Singleton`1::get_Instance
02d73894: ldr     x20, [x20, #0xf90]                         T:System.Action
02d73898: ldr     x21, [x21, #0x708]                         M:Clicker.SelectKeychainPanel::<ShowPanel>g__ContinueToAssemble|11_2
02d7389c: ldr     x0, [x8]                                   M:AdsManager::<OnApplicationPause>b__26_0
02d738a0: bl      #0x3be7218                                 fn_3be7218
02d738a4: ldr     x8, [x20]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d738a8: mov     x20, x0                                    
02d738ac: mov     x0, x8                                     
02d738b0: bl      #0x2b7104c                                 fn_2b7104c
02d738b4: ldr     x2, [x21]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d738b8: mov     x1, x19                                    
02d738bc: mov     x3, xzr                                    
02d738c0: mov     x21, x0                                    
02d738c4: bl      #0x4d8ddbc                                 System.Action::.ctor
02d738c8: cbz     x20, #0x2d73904                            
02d738cc: adrp    x8, #0x626c000                             
02d738d0: mov     x0, x20                                    
02d738d4: mov     x2, x21                                    
02d738d8: ldr     x8, [x8, #0x710]                           S:'done_selecte_item'
02d738dc: ldp     x20, x19, [sp, #0x10]                      
02d738e0: mov     w3, #1                                     
02d738e4: mov     x4, xzr                                    
02d738e8: ldr     x1, [x8]                                   M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d738ec: ldp     x30, x21, [sp], #0x20                      
02d738f0: b       #0x2c89698                                 AdsManager::ShowInter
02d738f4: mov     x0, x19                                    
02d738f8: ldp     x20, x19, [sp, #0x10]                      
02d738fc: ldp     x30, x21, [sp], #0x20                      
02d73900: b       #0x2d73908                                 Clicker.SelectKeychainPanel::<ShowPanel>g__ContinueToAssemble|11_2
02d73904: bl      #0x2b7105c                                 fn_2b7105c
## <ShowPanel>g__ContinueToAssemble|11_2() -> void
---- Clicker.SelectKeychainPanel::<ShowPanel>g__ContinueToAssemble|11_2 0x2d73908
02d73908: str     x30, [sp, #-0x20]!                         
02d7390c: stp     x20, x19, [sp, #0x10]                      
02d73910: adrp    x20, #0x6630000                            
02d73914: mov     x19, x0                                    
02d73918: ldrb    w8, [x20, #0x3c3]                          
02d7391c: tbnz    w8, #0, #0x2d73958                         
02d73920: adrp    x0, #0x6266000                             
02d73924: ldr     x0, [x0, #0x750]                           MS:DataManager::GetData
02d73928: bl      #0x2b70db0                                 fn_2b70db0
02d7392c: adrp    x0, #0x6265000                             
02d73930: ldr     x0, [x0, #0xb38]                           T:DevTrack
02d73934: bl      #0x2b70db0                                 fn_2b70db0
02d73938: adrp    x0, #0x626b000                             
02d7393c: ldr     x0, [x0, #0xee0]                           MS:MonoSingleton`1::get_Instance
02d73940: bl      #0x2b70db0                                 fn_2b70db0
02d73944: adrp    x0, #0x6266000                             
02d73948: ldr     x0, [x0, #0x658]                           MS:MonoSingleton`1::get_Instance
02d7394c: bl      #0x2b70db0                                 fn_2b70db0
02d73950: mov     w8, #1                                     
02d73954: strb    w8, [x20, #0x3c3]                          
02d73958: mov     x0, x19                                    
02d7395c: bl      #0x2d73570                                 Clicker.SelectKeychainPanel::HidePanel
02d73960: ldr     x0, [x19, #0x58]                           ._ingameClickerScreen
02d73964: cbz     x0, #0x2d73a20                             
02d73968: mov     w1, wzr                                    
02d7396c: mov     x2, xzr                                    
02d73970: bl      #0x2d6519c                                 Clicker.IngameClickerScreen::ShowBtnNext
02d73974: ldr     x0, [x19, #0x58]                           ._ingameClickerScreen
02d73978: cbz     x0, #0x2d73a20                             
02d7397c: adrp    x19, #0x626b000                            
02d73980: mov     x1, xzr                                    
02d73984: ldr     x19, [x19, #0xee0]                         MS:MonoSingleton`1::get_Instance
02d73988: bl      #0x2d6bb00                                 Clicker.IngameClickerScreen::HidePopupColor
02d7398c: ldr     x0, [x19]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d73990: bl      #0x3769600                                 fn_3769600
02d73994: cbz     x0, #0x2d73a20                             
02d73998: adrp    x19, #0x6266000                            
02d7399c: mov     x1, xzr                                    
02d739a0: ldr     x19, [x19, #0x658]                         MS:MonoSingleton`1::get_Instance
02d739a4: bl      #0x2d6d9a0                                 Clicker.KeycapMakerController::PrepareAssembleStep
02d739a8: ldr     x0, [x19]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d739ac: bl      #0x3769600                                 fn_3769600
02d739b0: cbz     x0, #0x2d73a20                             
02d739b4: adrp    x8, #0x6266000                             
02d739b8: ldr     x8, [x8, #0x750]                           MS:DataManager::GetData
02d739bc: ldr     x1, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d739c0: bl      #0x3168dd0                                 fn_3168dd0
02d739c4: cbz     x0, #0x2d73a20                             
02d739c8: ldr     x8, [x0, #0x20]                            S:'inter_ad_capping_time' ._keychainUIItem
02d739cc: cbz     x8, #0x2d73a20                             
02d739d0: ldrb    w8, [x8, #0x3a]                            
02d739d4: cbz     w8, #0x2d73a14                             
02d739d8: adrp    x19, #0x6265000                            
02d739dc: ldr     x19, [x19, #0xb38]                         T:DevTrack
02d739e0: ldr     x0, [x19]                                  M:AdsManager::<OnApplicationPause>b__26_0
02d739e4: ldr     w8, [x0, #0xe4]                            [62660e4]=0 f=0,0
02d739e8: cbnz    w8, #0x2d739f4                             
02d739ec: bl      #0x2b70f30                                 fn_2b70f30
02d739f0: ldr     x0, [x19]                                  M:AdsManager::<OnApplicationPause>b__26_0
02d739f4: ldr     x8, [x0, #0xb8]                            S:'banner_native_refresh_time'
02d739f8: ldp     x20, x19, [sp, #0x10]                      
02d739fc: mov     x3, xzr                                    
02d73a00: ldr     x0, [x8, #0x1f8]                           MS:System.Collections.Generic.List`1/Enumerator::get_Current
02d73a04: ldr     x1, [x8, #0x248]                           S:'Product is not assigned! Assign it in the Inspector.'
02d73a08: ldr     w2, [x8, #0x288]                           S:' | '
02d73a0c: ldr     x30, [sp], #0x20                           
02d73a10: b       #0x2c9c1e0                                 DevTrack::OnboardingStep
02d73a14: ldp     x20, x19, [sp, #0x10]                      
02d73a18: ldr     x30, [sp], #0x20                           
02d73a1c: ret                                                
02d73a20: bl      #0x2b7105c                                 fn_2b7105c
## <HidePanel>b__12_0() -> void
---- Clicker.SelectKeychainPanel::<HidePanel>b__12_0 0x2d73a24
02d73a24: str     x30, [sp, #-0x10]!                         
02d73a28: ldr     x0, [x0, #0x48]                            ._thisPanelRect
02d73a2c: cbz     x0, #0x2d73a4c                             
02d73a30: mov     x1, xzr                                    
02d73a34: bl      #0x5b339ec                                 UnityEngine.Component::get_gameObject
02d73a38: cbz     x0, #0x2d73a4c                             
02d73a3c: mov     w1, wzr                                    
02d73a40: mov     x2, xzr                                    
02d73a44: ldr     x30, [sp], #0x10                           
02d73a48: b       #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d73a4c: bl      #0x2b7105c                                 fn_2b7105c
