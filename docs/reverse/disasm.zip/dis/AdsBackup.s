#### CLASS AdsBackup parent= object
#   field _canBackup                     bool                                               off=0x10 attr=1 
#   field _onBackup                      System.Action                                      off=0x18 attr=1 
## .ctor(bool canBackup, System.Action onBackup) -> void
---- AdsBackup::.ctor 0x2c88578
02c88578: stp     x30, x21, [sp, #-0x20]!                    
02c8857c: stp     x20, x19, [sp, #0x10]                      
02c88580: mov     w20, w1                                    
02c88584: mov     x1, xzr                                    
02c88588: mov     x19, x2                                    
02c8858c: mov     x21, x0                                    
02c88590: bl      #0x4e53e9c                                 System.Object::.ctor
02c88594: str     x19, [x21, #0x18]!                         ._onBackup
02c88598: mov     x1, x19                                    
02c8859c: sturb   w20, [x21, #-8]                            
02c885a0: ldp     x20, x19, [sp, #0x10]                      
02c885a4: mov     x0, x21                                    
02c885a8: ldp     x30, x21, [sp], #0x20                      
02c885ac: b       #0x2b70d54                                 
## ShowAdBackup() -> void
---- AdsBackup::ShowAdBackup 0x2c885b0
02c885b0: ldrb    w8, [x0, #0x10]                            ._canBackup
02c885b4: cbz     w8, #0x2c885bc                             
02c885b8: ret                                                
02c885bc: ldr     x8, [x0, #0x18]                            ._onBackup
02c885c0: cbz     x8, #0x2c885b8                             
02c885c4: ldr     x0, [x8, #0x40]                            
02c885c8: ldr     x1, [x8, #0x28]                            
02c885cc: ldr     x2, [x8, #0x18]                            
02c885d0: br      x2                                         
