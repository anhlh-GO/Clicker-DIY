#### CLASS DailyTask.DailyTaskSO/<>c parent= object
#   field <>9                            DailyTask.DailyTaskSO/<>c                          off=0x0 attr=36 
#   field <>9__3_0                       System.Func`2<DailyTask.RewardWeight,int>          off=0x8 attr=16 
## .cctor() -> void
---- DailyTask.DailyTaskSO/<>c::.cctor 0x2d2bf1c
02d2bf1c: str     x30, [sp, #-0x20]!                         
02d2bf20: stp     x20, x19, [sp, #0x10]                      
02d2bf24: adrp    x19, #0x6630000                            
02d2bf28: adrp    x20, #0x626a000                            
02d2bf2c: ldrb    w8, [x19, #0xbd]                           
02d2bf30: ldr     x20, [x20, #0x418]                         T:DailyTask.DailyTaskSO/<>c
02d2bf34: tbnz    w8, #0, #0x2d2bf4c                         
02d2bf38: adrp    x0, #0x626a000                             
02d2bf3c: ldr     x0, [x0, #0x418]                           T:DailyTask.DailyTaskSO/<>c
02d2bf40: bl      #0x2b70db0                                 fn_2b70db0
02d2bf44: mov     w8, #1                                     
02d2bf48: strb    w8, [x19, #0xbd]                           
02d2bf4c: ldr     x0, [x20]                                  T:type56879(k15)
02d2bf50: bl      #0x2b7104c                                 fn_2b7104c
02d2bf54: mov     x1, xzr                                    
02d2bf58: mov     x19, x0                                    
02d2bf5c: bl      #0x4e53e9c                                 System.Object::.ctor
02d2bf60: ldr     x8, [x20]                                  T:type56879(k15)
02d2bf64: mov     x1, x19                                    
02d2bf68: ldr     x8, [x8, #0xb8]                            
02d2bf6c: str     x19, [x8]                                  
02d2bf70: ldr     x8, [x20]                                  T:type56879(k15)
02d2bf74: ldp     x20, x19, [sp, #0x10]                      
02d2bf78: ldr     x0, [x8, #0xb8]                            
02d2bf7c: ldr     x30, [sp], #0x20                           
02d2bf80: b       #0x2b70d54                                 
## .ctor() -> void
---- DailyTask.DailyTaskSO/<>c::.ctor 0x2d2bf84
02d2bf84: mov     x1, xzr                                    
02d2bf88: b       #0x4e53e9c                                 System.Object::.ctor
## <GetRandomRewardAmount>b__3_0(DailyTask.RewardWeight item) -> int
---- DailyTask.DailyTaskSO/<>c::<GetRandomRewardAmount>b__3_0 0x2d2bf8c
02d2bf8c: cbz     x1, #0x2d2bf98                             
02d2bf90: ldr     w0, [x1, #0x14]                            
02d2bf94: ret                                                
02d2bf98: str     x30, [sp, #-0x10]!                         
02d2bf9c: bl      #0x2b7105c                                 fn_2b7105c
#### CLASS DailyTask.DailyTaskSO/<>c__DisplayClass2_0 parent= object
#   field id                             int                                                off=0x10 attr=6 
## .ctor() -> void
---- DailyTask.DailyTaskSO/<>c__DisplayClass2_0::.ctor 0x2d2bc84
02d2bc84: mov     x1, xzr                                    
02d2bc88: b       #0x4e53e9c                                 System.Object::.ctor
## <GetMissionById>b__0(DailyTask.Mission mission) -> bool
---- DailyTask.DailyTaskSO/<>c__DisplayClass2_0::<GetMissionById>b__0 0x2d2bfa0
02d2bfa0: cbz     x1, #0x2d2bfb8                             
02d2bfa4: ldr     w8, [x1, #0x10]                            
02d2bfa8: ldr     w9, [x0, #0x10]                            .id
02d2bfac: cmp     w8, w9                                     
02d2bfb0: cset    w0, eq                                     
02d2bfb4: ret                                                
02d2bfb8: str     x30, [sp, #-0x10]!                         
02d2bfbc: bl      #0x2b7105c                                 fn_2b7105c
#### CLASS DailyTask.DailyTaskSO parent= UnityEngine.ScriptableObject
#   field DailyTasks                     System.Collections.Generic.List`1<DailyTask.Mission> off=0x18 attr=6 
#   field Rewards                        System.Collections.Generic.List`1<DailyTask.RewardWeight> off=0x20 attr=6 
## GetMissionById(int id) -> DailyTask.Mission
---- DailyTask.DailyTaskSO::GetMissionById 0x2d2b6fc
02d2b6fc: str     x30, [sp, #-0x30]!                         
02d2b700: stp     x22, x21, [sp, #0x10]                      
02d2b704: stp     x20, x19, [sp, #0x20]                      
02d2b708: adrp    x21, #0x6630000                            
02d2b70c: adrp    x22, #0x626a000                            
02d2b710: mov     w19, w1                                    
02d2b714: ldrb    w8, [x21, #0xbb]                           
02d2b718: ldr     x22, [x22, #0x3e0]                         T:DailyTask.DailyTaskSO/<>c__DisplayClass2_0
02d2b71c: mov     x20, x0                                    
02d2b720: tbnz    w8, #0, #0x2d2b75c                         
02d2b724: adrp    x0, #0x626a000                             
02d2b728: ldr     x0, [x0, #0x3e8]                           MS:System.Collections.Generic.List`1::Find
02d2b72c: bl      #0x2b70db0                                 fn_2b70db0
02d2b730: adrp    x0, #0x626a000                             
02d2b734: ldr     x0, [x0, #0x3f0]                           T:type57262(k15)
02d2b738: bl      #0x2b70db0                                 fn_2b70db0
02d2b73c: adrp    x0, #0x626a000                             
02d2b740: ldr     x0, [x0, #0x3f8]                           M:DailyTask.DailyTaskSO/<>c__DisplayClass2_0::<GetMissionById>b__0
02d2b744: bl      #0x2b70db0                                 fn_2b70db0
02d2b748: adrp    x0, #0x626a000                             
02d2b74c: ldr     x0, [x0, #0x3e0]                           T:DailyTask.DailyTaskSO/<>c__DisplayClass2_0
02d2b750: bl      #0x2b70db0                                 fn_2b70db0
02d2b754: mov     w8, #1                                     
02d2b758: strb    w8, [x21, #0xbb]                           
02d2b75c: ldr     x0, [x22]                                  T:type56879(k15)
02d2b760: bl      #0x2b7104c                                 fn_2b7104c
02d2b764: mov     x1, xzr                                    
02d2b768: mov     x21, x0                                    
02d2b76c: bl      #0x4e53e9c                                 System.Object::.ctor
02d2b770: cbz     x21, #0x2d2b7d0                            
02d2b774: adrp    x8, #0x626a000                             
02d2b778: adrp    x22, #0x626a000                            
02d2b77c: ldr     x8, [x8, #0x3f0]                           T:type57262(k15)
02d2b780: ldr     x22, [x22, #0x3f8]                         M:DailyTask.DailyTaskSO/<>c__DisplayClass2_0::<GetMissionById>b__0
02d2b784: ldr     x20, [x20, #0x18]                          .DailyTasks
02d2b788: str     w19, [x21, #0x10]                          
02d2b78c: ldr     x0, [x8]                                   T:type56879(k15)
02d2b790: bl      #0x2b7104c                                 fn_2b7104c
02d2b794: ldr     x2, [x22]                                  T:type56879(k15)
02d2b798: mov     x1, x21                                    
02d2b79c: mov     x3, xzr                                    
02d2b7a0: mov     x19, x0                                    
02d2b7a4: bl      #0x399ba10                                 fn_399ba10
02d2b7a8: cbz     x20, #0x2d2b7d0                            
02d2b7ac: adrp    x8, #0x626a000                             
02d2b7b0: mov     x0, x20                                    
02d2b7b4: mov     x1, x19                                    
02d2b7b8: ldr     x8, [x8, #0x3e8]                           MS:System.Collections.Generic.List`1::Find
02d2b7bc: ldp     x20, x19, [sp, #0x20]                      
02d2b7c0: ldp     x22, x21, [sp, #0x10]                      
02d2b7c4: ldr     x2, [x8]                                   T:type56879(k15)
02d2b7c8: ldr     x30, [sp], #0x30                           
02d2b7cc: b       #0x35a9868                                 
02d2b7d0: bl      #0x2b7105c                                 fn_2b7105c
## GetRandomRewardAmount() -> int
---- DailyTask.DailyTaskSO::GetRandomRewardAmount 0x2d2bc8c
02d2bc8c: sub     sp, sp, #0x80                              
02d2bc90: stp     d9, d8, [sp, #0x30]                        
02d2bc94: str     x30, [sp, #0x40]                           
02d2bc98: stp     x24, x23, [sp, #0x50]                      
02d2bc9c: stp     x22, x21, [sp, #0x60]                      
02d2bca0: stp     x20, x19, [sp, #0x70]                      
02d2bca4: adrp    x20, #0x6630000                            
02d2bca8: adrp    x23, #0x626a000                            
02d2bcac: mov     x19, x0                                    
02d2bcb0: ldrb    w8, [x20, #0xbc]                           
02d2bcb4: ldr     x23, [x23, #0x418]                         T:DailyTask.DailyTaskSO/<>c
02d2bcb8: tbnz    w8, #0, #0x2d2bd3c                         
02d2bcbc: adrp    x0, #0x626a000                             
02d2bcc0: ldr     x0, [x0, #0x420]                           MS:System.Linq.Enumerable::Sum
02d2bcc4: bl      #0x2b70db0                                 fn_2b70db0
02d2bcc8: adrp    x0, #0x626a000                             
02d2bccc: ldr     x0, [x0, #0x428]                           MS:System.Collections.Generic.List`1/Enumerator::Dispose
02d2bcd0: bl      #0x2b70db0                                 fn_2b70db0
02d2bcd4: adrp    x0, #0x626a000                             
02d2bcd8: ldr     x0, [x0, #0x430]                           MS:System.Collections.Generic.List`1/Enumerator::MoveNext
02d2bcdc: bl      #0x2b70db0                                 fn_2b70db0
02d2bce0: adrp    x0, #0x626a000                             
02d2bce4: ldr     x0, [x0, #0x438]                           MS:System.Collections.Generic.List`1/Enumerator::get_Current
02d2bce8: bl      #0x2b70db0                                 fn_2b70db0
02d2bcec: adrp    x0, #0x626a000                             
02d2bcf0: ldr     x0, [x0, #0x440]                           T:type55639(k15)
02d2bcf4: bl      #0x2b70db0                                 fn_2b70db0
02d2bcf8: adrp    x0, #0x626a000                             
02d2bcfc: ldr     x0, [x0, #0x448]                           MS:System.Collections.Generic.List`1::GetEnumerator
02d2bd00: bl      #0x2b70db0                                 fn_2b70db0
02d2bd04: adrp    x0, #0x626a000                             
02d2bd08: ldr     x0, [x0, #0x450]                           MS:System.Collections.Generic.List`1::get_Count
02d2bd0c: bl      #0x2b70db0                                 fn_2b70db0
02d2bd10: adrp    x0, #0x626a000                             
02d2bd14: ldr     x0, [x0, #0x458]                           MS:System.Collections.Generic.List`1::get_Item
02d2bd18: bl      #0x2b70db0                                 fn_2b70db0
02d2bd1c: adrp    x0, #0x626a000                             
02d2bd20: ldr     x0, [x0, #0x460]                           M:DailyTask.DailyTaskSO/<>c::<GetRandomRewardAmount>b__3_0
02d2bd24: bl      #0x2b70db0                                 fn_2b70db0
02d2bd28: adrp    x0, #0x626a000                             
02d2bd2c: ldr     x0, [x0, #0x418]                           T:DailyTask.DailyTaskSO/<>c
02d2bd30: bl      #0x2b70db0                                 fn_2b70db0
02d2bd34: mov     w8, #1                                     
02d2bd38: strb    w8, [x20, #0xbc]                           
02d2bd3c: ldr     x0, [x23]                                  T:type56879(k15)
02d2bd40: ldr     x20, [x19, #0x20]                          .Rewards
02d2bd44: stp     xzr, xzr, [sp, #0x18]                      
02d2bd48: str     xzr, [sp, #0x28]                           
02d2bd4c: ldr     w8, [x0, #0xe4]                            [626a0e4]=0 f=0,0
02d2bd50: cbnz    w8, #0x2d2bd5c                             
02d2bd54: bl      #0x2b70f30                                 fn_2b70f30
02d2bd58: ldr     x0, [x23]                                  T:type56879(k15)
02d2bd5c: ldr     x8, [x0, #0xb8]                            MS:UnityEngine.Object::FindObjectsOfType
02d2bd60: adrp    x24, #0x626a000                            
02d2bd64: ldr     x21, [x8, #8]                              
02d2bd68: ldr     x24, [x24, #0x420]                         MS:System.Linq.Enumerable::Sum
02d2bd6c: cbnz    x21, #0x2d2bdc8                            
02d2bd70: ldr     w9, [x0, #0xe4]                            [626a0e4]=0 f=0,0
02d2bd74: cbnz    w9, #0x2d2bd84                             
02d2bd78: bl      #0x2b70f30                                 fn_2b70f30
02d2bd7c: ldr     x8, [x23]                                  T:type56879(k15)
02d2bd80: ldr     x8, [x8, #0xb8]                            
02d2bd84: adrp    x9, #0x626a000                             
02d2bd88: ldr     x9, [x9, #0x440]                           T:type55639(k15)
02d2bd8c: ldr     x22, [x8]                                  
02d2bd90: ldr     x0, [x9]                                   T:type56879(k15)
02d2bd94: bl      #0x2b7104c                                 fn_2b7104c
02d2bd98: adrp    x8, #0x626a000                             
02d2bd9c: mov     x1, x22                                    
02d2bda0: mov     x3, xzr                                    
02d2bda4: ldr     x8, [x8, #0x460]                           M:DailyTask.DailyTaskSO/<>c::<GetRandomRewardAmount>b__3_0
02d2bda8: mov     x21, x0                                    
02d2bdac: ldr     x2, [x8]                                   T:type56879(k15)
02d2bdb0: bl      #0x4941168                                 fn_4941168
02d2bdb4: ldr     x8, [x23]                                  T:type56879(k15)
02d2bdb8: mov     x1, x21                                    
02d2bdbc: ldr     x0, [x8, #0xb8]                            MS:UnityEngine.Object::FindObjectsOfType
02d2bdc0: str     x21, [x0, #8]!                             
02d2bdc4: bl      #0x2b70d54                                 fn_2b70d54
02d2bdc8: ldr     x2, [x24]                                  T:type56879(k15)
02d2bdcc: mov     x0, x20                                    
02d2bdd0: mov     x1, x21                                    
02d2bdd4: bl      #0x319babc                                 fn_319babc
02d2bdd8: scvtf   s1, w0                                     
02d2bddc: movi    d0, #0000000000000000                      
02d2bde0: mov     x0, xzr                                    
02d2bde4: movi    d9, #0000000000000000                      
02d2bde8: bl      #0x5b2dfc0                                 UnityEngine.Random::Range
02d2bdec: ldr     x0, [x19, #0x20]                           .Rewards
02d2bdf0: cbz     x0, #0x2d2bebc                             
02d2bdf4: adrp    x8, #0x626a000                             
02d2bdf8: adrp    x20, #0x626a000                            
02d2bdfc: adrp    x21, #0x626a000                            
02d2be00: ldr     x8, [x8, #0x448]                           MS:System.Collections.Generic.List`1::GetEnumerator
02d2be04: adrp    x22, #0x626a000                            
02d2be08: ldr     x20, [x20, #0x430]                         MS:System.Collections.Generic.List`1/Enumerator::MoveNext
02d2be0c: ldr     x21, [x21, #0x458]                         MS:System.Collections.Generic.List`1::get_Item
02d2be10: ldr     x22, [x22, #0x428]                         MS:System.Collections.Generic.List`1/Enumerator::Dispose
02d2be14: fmov    s8, s0                                     
02d2be18: ldr     x1, [x8]                                   T:type56879(k15)
02d2be1c: add     x8, sp, #0x18                              
02d2be20: add     x23, sp, #0x18                             
02d2be24: bl      #0x35a9d9c                                 fn_35a9d9c
02d2be28: stp     xzr, x23, [sp, #8]                         
02d2be2c: ldr     x1, [x20]                                  T:type56879(k15)
02d2be30: add     x0, sp, #0x18                              
02d2be34: bl      #0x4690474                                 fn_4690474
02d2be38: tbz     w0, #0, #0x2d2be6c                         
02d2be3c: ldr     x8, [sp, #0x28]                            
02d2be40: cbz     x8, #0x2d2beb8                             
02d2be44: ldr     s0, [x8, #0x14]                            [626a014]=0 f=0,0
02d2be48: scvtf   s0, s0                                     
02d2be4c: fadd    s9, s9, s0                                 
02d2be50: fcmp    s8, s9                                     
02d2be54: b.pl    #0x2d2be2c                                 
02d2be58: ldr     x1, [x22]                                  T:type56879(k15)
02d2be5c: ldr     w19, [x8, #0x10]                           T:Decor.DataDecor/CategoryData
02d2be60: add     x0, sp, #0x18                              
02d2be64: bl      #0x4690470                                 fn_4690470
02d2be68: b       #0x2d2be98                                 
02d2be6c: ldr     x1, [x22]                                  T:type56879(k15)
02d2be70: add     x0, sp, #0x18                              
02d2be74: bl      #0x4690470                                 fn_4690470
02d2be78: ldr     x0, [x19, #0x20]                           .Rewards
02d2be7c: cbz     x0, #0x2d2bebc                             
02d2be80: ldr     w8, [x0, #0x18]                            MS:System.Collections.Generic.List`1::Add .DailyTasks
02d2be84: ldr     x2, [x21]                                  T:type56879(k15)
02d2be88: sub     w1, w8, #1                                 
02d2be8c: bl      #0x35a8f3c                                 fn_35a8f3c
02d2be90: cbz     x0, #0x2d2bebc                             
02d2be94: ldr     w19, [x0, #0x10]                           T:Decor.DataDecor/CategoryData
02d2be98: mov     w0, w19                                    
02d2be9c: ldp     x20, x19, [sp, #0x70]                      
02d2bea0: ldp     x22, x21, [sp, #0x60]                      
02d2bea4: ldr     x30, [sp, #0x40]                           
02d2bea8: ldp     x24, x23, [sp, #0x50]                      
02d2beac: ldp     d9, d8, [sp, #0x30]                        
02d2beb0: add     sp, sp, #0x80                              
02d2beb4: ret                                                
02d2beb8: bl      #0x2b7105c                                 fn_2b7105c
02d2bebc: bl      #0x2b7105c                                 fn_2b7105c
02d2bec0: b       #0x2d2bec4                                 
02d2bec4: mov     x20, x0                                    
02d2bec8: cmp     w1, #1                                     
02d2becc: b.ne    #0x2d2bf00                                 
02d2bed0: mov     x0, x20                                    
02d2bed4: bl      #0x5e90260                                 fn_5e90260
02d2bed8: ldr     x20, [x0]                                  T:type56879(k15)
02d2bedc: str     x20, [sp, #8]                              
02d2bee0: bl      #0x5e90270                                 fn_5e90270
02d2bee4: ldr     x0, [sp, #0x10]                            
02d2bee8: ldr     x1, [x22]                                  T:type56879(k15)
02d2beec: bl      #0x4690470                                 fn_4690470
02d2bef0: cbz     x20, #0x2d2be78                            
02d2bef4: mov     x0, x20                                    
02d2bef8: bl      #0x2b71054                                 fn_2b71054
02d2befc: mov     x20, x0                                    
02d2bf00: add     x0, sp, #8                                 
02d2bf04: bl      #0x2738198                                 fn_2738198
02d2bf08: mov     x0, x20                                    
02d2bf0c: bl      #0x2c6051c                                 fn_2c6051c
02d2bf10: bl      #0x27369b8                                 fn_27369b8
## .ctor() -> void
---- DailyTask.DailyTaskSO::.ctor 0x2d2bf14
02d2bf14: mov     x1, xzr                                    
02d2bf18: b       #0x5b398f0                                 UnityEngine.ScriptableObject::.ctor
