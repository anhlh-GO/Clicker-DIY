#### CLASS DreamHouse.RoomConfig parent= UnityEngine.ScriptableObject
#   field Name                           string                                             off=0x18 attr=6 
#   field Icon                           UnityEngine.Sprite                                 off=0x20 attr=6 
#   field RoomPrefab                     UnityEngine.GameObject                             off=0x28 attr=6 
#   field DecorItems                     System.Collections.Generic.List`1<DreamHouse.DecorItemAsset> off=0x30 attr=6 
## GetDecorItemAssetByIndex(int index) -> DreamHouse.DecorItemAsset
---- DreamHouse.RoomConfig::GetDecorItemAssetByIndex 0x2d15b28
02d15b28: sub     sp, sp, #0x30                              
02d15b2c: stp     x30, x21, [sp, #0x10]                      
02d15b30: stp     x20, x19, [sp, #0x20]                      
02d15b34: adrp    x21, #0x662f000                            
02d15b38: mov     w19, w1                                    
02d15b3c: mov     x20, x0                                    
02d15b40: ldrb    w8, [x21, #0xfd0]                          
02d15b44: tbnz    w8, #0, #0x2d15b80                         
02d15b48: adrp    x0, #0x6263000                             
02d15b4c: ldr     x0, [x0, #0x928]                           T:UnityEngine.Debug
02d15b50: bl      #0x2b70db0                                 fn_2b70db0
02d15b54: adrp    x0, #0x6269000                             
02d15b58: ldr     x0, [x0, #0x8c0]                           MS:System.Collections.Generic.List`1::get_Count
02d15b5c: bl      #0x2b70db0                                 fn_2b70db0
02d15b60: adrp    x0, #0x6269000                             
02d15b64: ldr     x0, [x0, #0x8c8]                           MS:System.Collections.Generic.List`1::get_Item
02d15b68: bl      #0x2b70db0                                 fn_2b70db0
02d15b6c: adrp    x0, #0x6269000                             
02d15b70: ldr     x0, [x0, #0x8d0]                           S:'Index {0} is out of range for DecorItems.'
02d15b74: bl      #0x2b70db0                                 fn_2b70db0
02d15b78: mov     w8, #1                                     
02d15b7c: strb    w8, [x21, #0xfd0]                          
02d15b80: tbnz    w19, #0x1f, #0x2d15bb8                     
02d15b84: ldr     x0, [x20, #0x30]                           .DecorItems
02d15b88: cbz     x0, #0x2d15c2c                             
02d15b8c: ldr     w8, [x0, #0x18]                            M:Trading.TradingSession::<ValidateTrade>b__57_0 .Name
02d15b90: cmp     w8, w19                                    
02d15b94: b.le    #0x2d15bb8                                 
02d15b98: adrp    x8, #0x6269000                             
02d15b9c: mov     w1, w19                                    
02d15ba0: ldr     x8, [x8, #0x8c8]                           MS:System.Collections.Generic.List`1::get_Item
02d15ba4: ldp     x20, x19, [sp, #0x20]                      
02d15ba8: ldp     x30, x21, [sp, #0x10]                      
02d15bac: ldr     x2, [x8]                                   T:Trading.TradingSession/<>c__DisplayClass56_0
02d15bb0: add     sp, sp, #0x30                              
02d15bb4: b       #0x35a8f3c                                 
02d15bb8: adrp    x8, #0x6263000                             
02d15bbc: adrp    x20, #0x6269000                            
02d15bc0: adrp    x21, #0x6263000                            
02d15bc4: ldr     x8, [x8, #0x970]                           &6645c70(=0)
02d15bc8: ldr     x20, [x20, #0x8d0]                         S:'Index {0} is out of range for DecorItems.'
02d15bcc: ldr     x21, [x21, #0x928]                         T:UnityEngine.Debug
02d15bd0: add     x1, sp, #0xc                               
02d15bd4: str     w19, [sp, #0xc]                            
02d15bd8: ldr     x0, [x8, #0x48]                            &6263098(=0)
02d15bdc: bl      #0x2b70f38                                 fn_2b70f38
02d15be0: ldr     x8, [x20]                                  T:Trading.TradingSession/<>c__DisplayClass56_0
02d15be4: mov     x1, x0                                     
02d15be8: mov     x2, xzr                                    
02d15bec: mov     x0, x8                                     
02d15bf0: bl      #0x4c9d0ec                                 System.String::Format
02d15bf4: ldr     x8, [x21]                                  &2c5bbd4(=a9bd7bfdd503233f)
02d15bf8: mov     x19, x0                                    
02d15bfc: ldr     w9, [x8, #0xe4]                            [62630e4]=0 f=0,0
02d15c00: cbnz    w9, #0x2d15c0c                             
02d15c04: mov     x0, x8                                     
02d15c08: bl      #0x2b70f30                                 fn_2b70f30
02d15c0c: mov     x0, x19                                    
02d15c10: mov     x1, xzr                                    
02d15c14: bl      #0x5af2840                                 UnityEngine.Debug::LogError
02d15c18: ldp     x20, x19, [sp, #0x20]                      
02d15c1c: mov     x0, xzr                                    
02d15c20: ldp     x30, x21, [sp, #0x10]                      
02d15c24: add     sp, sp, #0x30                              
02d15c28: ret                                                
02d15c2c: bl      #0x2b7105c                                 fn_2b7105c
## GetDecorItemAssetCount() -> int
---- DreamHouse.RoomConfig::GetDecorItemAssetCount 0x2d15c30
02d15c30: str     x30, [sp, #-0x20]!                         
02d15c34: stp     x20, x19, [sp, #0x10]                      
02d15c38: adrp    x20, #0x662f000                            
02d15c3c: mov     x19, x0                                    
02d15c40: ldrb    w8, [x20, #0xfd1]                          
02d15c44: tbnz    w8, #0, #0x2d15c5c                         
02d15c48: adrp    x0, #0x6269000                             
02d15c4c: ldr     x0, [x0, #0x8c0]                           MS:System.Collections.Generic.List`1::get_Count
02d15c50: bl      #0x2b70db0                                 fn_2b70db0
02d15c54: mov     w8, #1                                     
02d15c58: strb    w8, [x20, #0xfd1]                          
02d15c5c: ldr     x8, [x19, #0x30]                           .DecorItems
02d15c60: cbz     x8, #0x2d15c74                             
02d15c64: ldp     x20, x19, [sp, #0x10]                      
02d15c68: ldr     w0, [x8, #0x18]                            
02d15c6c: ldr     x30, [sp], #0x20                           
02d15c70: ret                                                
02d15c74: bl      #0x2b7105c                                 fn_2b7105c
## .ctor() -> void
---- DreamHouse.RoomConfig::.ctor 0x2d15c78
02d15c78: mov     x1, xzr                                    
02d15c7c: b       #0x5b398f0                                 UnityEngine.ScriptableObject::.ctor
