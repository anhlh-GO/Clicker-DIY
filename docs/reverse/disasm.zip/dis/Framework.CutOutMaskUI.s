#### CLASS Framework.CutOutMaskUI parent= UnityEngine.UI.Image
## get_materialForRendering() -> UnityEngine.Material
---- Framework.CutOutMaskUI::get_materialForRendering 0x2cc390c
02cc390c: stp     x30, x21, [sp, #-0x20]!                    
02cc3910: stp     x20, x19, [sp, #0x10]                      
02cc3914: adrp    x21, #0x662f000                            
02cc3918: adrp    x20, #0x6267000                            
02cc391c: mov     x19, x0                                    
02cc3920: ldrb    w8, [x21, #0xc37]                          
02cc3924: ldr     x20, [x20, #0x188]                         T:UnityEngine.Material
02cc3928: tbnz    w8, #0, #0x2cc394c                         
02cc392c: adrp    x0, #0x6267000                             
02cc3930: ldr     x0, [x0, #0x188]                           T:UnityEngine.Material
02cc3934: bl      #0x2b70db0                                 fn_2b70db0
02cc3938: adrp    x0, #0x6267000                             
02cc393c: ldr     x0, [x0, #0x190]                           S:'_StencilComp'
02cc3940: bl      #0x2b70db0                                 fn_2b70db0
02cc3944: mov     w8, #1                                     
02cc3948: strb    w8, [x21, #0xc37]                          
02cc394c: mov     x0, x19                                    
02cc3950: mov     x1, xzr                                    
02cc3954: bl      #0x5c4ecbc                                 UnityEngine.UI.Graphic::get_materialForRendering
02cc3958: ldr     x8, [x20]                                  S:'didu'
02cc395c: mov     x20, x0                                    
02cc3960: mov     x0, x8                                     
02cc3964: bl      #0x2b7104c                                 fn_2b7104c
02cc3968: mov     x1, x20                                    
02cc396c: mov     x2, xzr                                    
02cc3970: mov     x19, x0                                    
02cc3974: bl      #0x5b05e18                                 UnityEngine.Material::.ctor
02cc3978: cbz     x19, #0x2cc39a8                            
02cc397c: adrp    x8, #0x6267000                             
02cc3980: mov     x0, x19                                    
02cc3984: mov     w2, #6                                     
02cc3988: ldr     x8, [x8, #0x190]                           S:'_StencilComp'
02cc398c: mov     x3, xzr                                    
02cc3990: ldr     x1, [x8]                                   S:'didu'
02cc3994: bl      #0x5b090e4                                 UnityEngine.Material::SetInt
02cc3998: mov     x0, x19                                    
02cc399c: ldp     x20, x19, [sp, #0x10]                      
02cc39a0: ldp     x30, x21, [sp], #0x20                      
02cc39a4: ret                                                
02cc39a8: bl      #0x2b7105c                                 fn_2b7105c
## .ctor() -> void
---- Framework.CutOutMaskUI::.ctor 0x2cc39ac
02cc39ac: stp     x30, x21, [sp, #-0x20]!                    
02cc39b0: stp     x20, x19, [sp, #0x10]                      
02cc39b4: adrp    x20, #0x662f000                            
02cc39b8: adrp    x21, #0x6267000                            
02cc39bc: mov     x19, x0                                    
02cc39c0: ldrb    w8, [x20, #0xc38]                          
02cc39c4: ldr     x21, [x21, #0x198]                         T:UnityEngine.UI.Image
02cc39c8: tbnz    w8, #0, #0x2cc39e0                         
02cc39cc: adrp    x0, #0x6267000                             
02cc39d0: ldr     x0, [x0, #0x198]                           T:UnityEngine.UI.Image
02cc39d4: bl      #0x2b70db0                                 fn_2b70db0
02cc39d8: mov     w8, #1                                     
02cc39dc: strb    w8, [x20, #0xc38]                          
02cc39e0: ldr     x0, [x21]                                  S:'didu'
02cc39e4: ldr     w8, [x0, #0xe4]                            [62670e4]=0 f=0,0
02cc39e8: cbnz    w8, #0x2cc39f0                             
02cc39ec: bl      #0x2b70f30                                 fn_2b70f30
02cc39f0: mov     x0, x19                                    
02cc39f4: ldp     x20, x19, [sp, #0x10]                      
02cc39f8: mov     x1, xzr                                    
02cc39fc: ldp     x30, x21, [sp], #0x20                      
02cc3a00: b       #0x5c534c8                                 UnityEngine.UI.Image::.ctor
