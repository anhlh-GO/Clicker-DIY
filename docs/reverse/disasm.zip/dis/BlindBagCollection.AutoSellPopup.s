#### CLASS BlindBagCollection.AutoSellPopup/<>c__DisplayClass12_0 parent= object
#   field Icon                           UnityEngine.Sprite                                 off=0x10 attr=6 
## .ctor() -> void
---- BlindBagCollection.AutoSellPopup/<>c__DisplayClass12_0::.ctor 0x2d30974
02d30974: mov     x1, xzr                                    
02d30978: b       #0x4e53e9c                                 System.Object::.ctor
## <InitalizePrice>b__0(BlindBagCollection.SellItem item) -> bool
---- BlindBagCollection.AutoSellPopup/<>c__DisplayClass12_0::<InitalizePrice>b__0 0x2d30f74
02d30f74: stp     x30, x21, [sp, #-0x20]!                    
02d30f78: stp     x20, x19, [sp, #0x10]                      
02d30f7c: adrp    x21, #0x6630000                            
02d30f80: mov     x20, x1                                    
02d30f84: mov     x19, x0                                    
02d30f88: ldrb    w8, [x21, #0xf8]                           
02d30f8c: tbnz    w8, #0, #0x2d30fa4                         
02d30f90: adrp    x0, #0x6263000                             
02d30f94: ldr     x0, [x0, #0x918]                           T:UnityEngine.Object
02d30f98: bl      #0x2b70db0                                 fn_2b70db0
02d30f9c: mov     w8, #1                                     
02d30fa0: strb    w8, [x21, #0xf8]                           
02d30fa4: cbz     x20, #0x2d30fe8                            
02d30fa8: ldr     x8, [x20, #0x20]                           
02d30fac: cbz     x8, #0x2d30fe8                             
02d30fb0: adrp    x9, #0x6263000                             
02d30fb4: ldr     x9, [x9, #0x918]                           T:UnityEngine.Object
02d30fb8: ldr     x20, [x8, #0xd8]                           
02d30fbc: ldr     x19, [x19, #0x10]                          .Icon
02d30fc0: ldr     x0, [x9]                                   &2c5bbd4(=a9bd7bfdd503233f)
02d30fc4: ldr     w9, [x0, #0xe4]                            [62630e4]=0 f=0,0
02d30fc8: cbnz    w9, #0x2d30fd0                             
02d30fcc: bl      #0x2b70f30                                 fn_2b70f30
02d30fd0: mov     x0, x20                                    
02d30fd4: mov     x1, x19                                    
02d30fd8: mov     x2, xzr                                    
02d30fdc: ldp     x20, x19, [sp, #0x10]                      
02d30fe0: ldp     x30, x21, [sp], #0x20                      
02d30fe4: b       #0x5b37d84                                 UnityEngine.Object::op_Equality
02d30fe8: bl      #0x2b7105c                                 fn_2b7105c
#### CLASS BlindBagCollection.AutoSellPopup parent= PopupBase
#   field _panel                         UnityEngine.Transform                              off=0x38 attr=1 SerializeField
#   field _tradeAdButton                 UnityEngine.UI.Button                              off=0x40 attr=1 SerializeField
#   field _tradeNormalButton             UnityEngine.UI.Button                              off=0x48 attr=1 SerializeField
#   field _sellItemInstance              BlindBagCollection.SellItem                        off=0x50 attr=1 SerializeField
#   field _collectionAsset               BlindBagCollection.BlindbagCollectionAsset         off=0x58 attr=1 SerializeField
#   field _txtTradeAdPrice               TMPro.TextMeshProUGUI                              off=0x60 attr=1 SerializeField
#   field _txtTradeNormalPrice           TMPro.TextMeshProUGUI                              off=0x68 attr=1 SerializeField
#   field _normalTradeScale              float                                              off=0x70 attr=1 
#   field _onComplete                    System.Action                                      off=0x78 attr=1 
#   field _totalPrice                    int                                                off=0x80 attr=1 
#   field _sellItems                     System.Collections.Generic.List`1<BlindBagCollection.SellItem> off=0x88 attr=1 
## OnShow() -> void
---- BlindBagCollection.AutoSellPopup::OnShow 0x2d30440
02d30440: stp     x30, x21, [sp, #-0x20]!                    
02d30444: stp     x20, x19, [sp, #0x10]                      
02d30448: adrp    x21, #0x6630000                            
02d3044c: adrp    x20, #0x6265000                            
02d30450: mov     x19, x0                                    
02d30454: ldrb    w8, [x21, #0xf1]                           
02d30458: ldr     x20, [x20, #0x310]                         MS:WejoyService.Singleton`1::get_Instance
02d3045c: tbnz    w8, #0, #0x2d30474                         
02d30460: adrp    x0, #0x6265000                             
02d30464: ldr     x0, [x0, #0x310]                           MS:WejoyService.Singleton`1::get_Instance
02d30468: bl      #0x2b70db0                                 fn_2b70db0
02d3046c: mov     w8, #1                                     
02d30470: strb    w8, [x21, #0xf1]                           
02d30474: mov     x0, x19                                    
02d30478: mov     x1, xzr                                    
02d3047c: bl      #0x2cdd6b8                                 UIBase::OnShow
02d30480: ldr     x0, [x20]                                  M:AdsManager::<OnApplicationPause>b__26_0
02d30484: bl      #0x3be7218                                 fn_3be7218
02d30488: cbz     x0, #0x2d304a0                             
02d3048c: ldp     x20, x19, [sp, #0x10]                      
02d30490: mov     w1, #4                                     
02d30494: mov     x2, xzr                                    
02d30498: ldp     x30, x21, [sp], #0x20                      
02d3049c: b       #0x2c8a650                                 AdsManager::ShowMREC
02d304a0: bl      #0x2b7105c                                 fn_2b7105c
## InitalizePrice(System.Collections.Generic.List`1<System.ValueTuple`2<UnityEngine.Sprite,int>> items, System.Action onComplete) -> void
---- BlindBagCollection.AutoSellPopup::InitalizePrice 0x2d304a4
02d304a4: sub     sp, sp, #0xb0                              
02d304a8: stp     x29, x30, [sp, #0x50]                      
02d304ac: stp     x28, x27, [sp, #0x60]                      
02d304b0: stp     x26, x25, [sp, #0x70]                      
02d304b4: stp     x24, x23, [sp, #0x80]                      
02d304b8: stp     x22, x21, [sp, #0x90]                      
02d304bc: stp     x20, x19, [sp, #0xa0]                      
02d304c0: adrp    x23, #0x6630000                            
02d304c4: adrp    x21, #0x626a000                            
02d304c8: adrp    x19, #0x626a000                            
02d304cc: ldrb    w8, [x23, #0xf2]                           
02d304d0: ldr     x21, [x21, #0x678]                         T:type56804(k15)
02d304d4: ldr     x19, [x19, #0x680]                         MS:System.Collections.Generic.List`1::.ctor
02d304d8: mov     x20, x2                                    
02d304dc: mov     x22, x1                                    
02d304e0: mov     x24, x0                                    
02d304e4: tbnz    w8, #0, #0x2d3058c                         
02d304e8: adrp    x0, #0x626a000                             
02d304ec: ldr     x0, [x0, #0x688]                           MS:System.Collections.Generic.List`1/Enumerator::Dispose
02d304f0: bl      #0x2b70db0                                 fn_2b70db0
02d304f4: adrp    x0, #0x626a000                             
02d304f8: ldr     x0, [x0, #0x690]                           MS:System.Collections.Generic.List`1/Enumerator::MoveNext
02d304fc: bl      #0x2b70db0                                 fn_2b70db0
02d30500: adrp    x0, #0x626a000                             
02d30504: ldr     x0, [x0, #0x698]                           MS:System.Collections.Generic.List`1/Enumerator::get_Current
02d30508: bl      #0x2b70db0                                 fn_2b70db0
02d3050c: adrp    x0, #0x626a000                             
02d30510: ldr     x0, [x0, #0x6a0]                           MS:System.Collections.Generic.List`1::Add
02d30514: bl      #0x2b70db0                                 fn_2b70db0
02d30518: adrp    x0, #0x626a000                             
02d3051c: ldr     x0, [x0, #0x6a8]                           MS:System.Collections.Generic.List`1::Find
02d30520: bl      #0x2b70db0                                 fn_2b70db0
02d30524: adrp    x0, #0x626a000                             
02d30528: ldr     x0, [x0, #0x6b0]                           MS:System.Collections.Generic.List`1::GetEnumerator
02d3052c: bl      #0x2b70db0                                 fn_2b70db0
02d30530: adrp    x0, #0x626a000                             
02d30534: ldr     x0, [x0, #0x680]                           MS:System.Collections.Generic.List`1::.ctor
02d30538: bl      #0x2b70db0                                 fn_2b70db0
02d3053c: adrp    x0, #0x626a000                             
02d30540: ldr     x0, [x0, #0x678]                           T:type56804(k15)
02d30544: bl      #0x2b70db0                                 fn_2b70db0
02d30548: adrp    x0, #0x626a000                             
02d3054c: ldr     x0, [x0, #0x6b8]                           MS:UnityEngine.Object::Instantiate
02d30550: bl      #0x2b70db0                                 fn_2b70db0
02d30554: adrp    x0, #0x6263000                             
02d30558: ldr     x0, [x0, #0x918]                           T:UnityEngine.Object
02d3055c: bl      #0x2b70db0                                 fn_2b70db0
02d30560: adrp    x0, #0x626a000                             
02d30564: ldr     x0, [x0, #0x6c0]                           T:type57280(k15)
02d30568: bl      #0x2b70db0                                 fn_2b70db0
02d3056c: adrp    x0, #0x626a000                             
02d30570: ldr     x0, [x0, #0x6c8]                           M:BlindBagCollection.AutoSellPopup/<>c__DisplayClass12_0::<InitalizePrice>b__0
02d30574: bl      #0x2b70db0                                 fn_2b70db0
02d30578: adrp    x0, #0x626a000                             
02d3057c: ldr     x0, [x0, #0x6d0]                           T:BlindBagCollection.AutoSellPopup/<>c__DisplayClass12_0
02d30580: bl      #0x2b70db0                                 fn_2b70db0
02d30584: mov     w8, #1                                     
02d30588: strb    w8, [x23, #0xf2]                           
02d3058c: movi    v0.2d, #0000000000000000                   
02d30590: mov     x0, x24                                    
02d30594: mov     x1, x20                                    
02d30598: str     wzr, [sp, #0x2c]                           
02d3059c: str     x20, [x0, #0x78]!                          ._onComplete
02d305a0: stp     q0, q0, [sp, #0x30]                        
02d305a4: bl      #0x2b70d54                                 fn_2b70d54
02d305a8: ldr     x0, [x21]                                  T:type56879(k15)
02d305ac: mov     x20, x24                                   
02d305b0: str     wzr, [x20, #0x80]!                         ._totalPrice
02d305b4: bl      #0x2b7104c                                 fn_2b7104c
02d305b8: ldr     x1, [x19]                                  T:type56879(k15)
02d305bc: mov     x23, x0                                    
02d305c0: bl      #0x35a89a4                                 fn_35a89a4
02d305c4: mov     x21, x24                                   
02d305c8: mov     x1, x23                                    
02d305cc: str     x24, [sp]                                  
02d305d0: str     x23, [x21, #0x88]!                         ._sellItems
02d305d4: mov     x0, x21                                    
02d305d8: bl      #0x2b70d54                                 fn_2b70d54
02d305dc: cbz     x22, #0x2d308c0                            
02d305e0: adrp    x8, #0x626a000                             
02d305e4: adrp    x28, #0x626a000                            
02d305e8: adrp    x19, #0x626a000                            
02d305ec: ldr     x8, [x8, #0x6b0]                           MS:System.Collections.Generic.List`1::GetEnumerator
02d305f0: adrp    x29, #0x626a000                            
02d305f4: adrp    x27, #0x6263000                            
02d305f8: ldr     x28, [x28, #0x690]                         MS:System.Collections.Generic.List`1/Enumerator::MoveNext
02d305fc: ldr     x19, [x19, #0x6c8]                         M:BlindBagCollection.AutoSellPopup/<>c__DisplayClass12_0::<InitalizePrice>b__0
02d30600: ldr     x29, [x29, #0x6a8]                         MS:System.Collections.Generic.List`1::Find
02d30604: ldr     x27, [x27, #0x918]                         T:UnityEngine.Object
02d30608: ldr     x1, [x8]                                   T:type56879(k15)
02d3060c: add     x8, sp, #8                                 
02d30610: mov     x0, x22                                    
02d30614: bl      #0x4b8bb14                                 fn_4b8bb14
02d30618: ldur    q0, [sp, #8]                               
02d3061c: ldur    q1, [sp, #0x18]                            
02d30620: add     x8, sp, #0x30                              
02d30624: stp     xzr, x8, [sp, #8]                          
02d30628: stp     q0, q1, [sp, #0x30]                        
02d3062c: ldr     x1, [x28]                                  T:type56879(k15)
02d30630: add     x0, sp, #0x30                              
02d30634: bl      #0x4655d2c                                 fn_4655d2c
02d30638: tbz     w0, #0, #0x2d307e4                         
02d3063c: adrp    x8, #0x626a000                             
02d30640: ldr     x8, [x8, #0x6d0]                           T:BlindBagCollection.AutoSellPopup/<>c__DisplayClass12_0
02d30644: ldr     x0, [x8]                                   T:type56879(k15)
02d30648: bl      #0x2b7104c                                 fn_2b7104c
02d3064c: mov     x1, xzr                                    
02d30650: mov     x24, x0                                    
02d30654: bl      #0x4e53e9c                                 System.Object::.ctor
02d30658: cbz     x24, #0x2d308a0                            
02d3065c: ldp     x1, x22, [sp, #0x40]                       
02d30660: mov     x23, x24                                   
02d30664: str     x1, [x23, #0x10]!                          
02d30668: mov     x0, x23                                    
02d3066c: bl      #0x2b70d54                                 fn_2b70d54
02d30670: adrp    x8, #0x626a000                             
02d30674: ldr     x25, [x21]                                 T:type56879(k15)
02d30678: ldr     x8, [x8, #0x6c0]                           T:type57280(k15)
02d3067c: ldr     x0, [x8]                                   T:type56879(k15)
02d30680: bl      #0x2b7104c                                 fn_2b7104c
02d30684: mov     x26, x0                                    
02d30688: ldr     x2, [x19]                                  T:type56879(k15)
02d3068c: mov     x1, x24                                    
02d30690: mov     x3, xzr                                    
02d30694: bl      #0x399ba10                                 fn_399ba10
02d30698: cbz     x25, #0x2d308a4                            
02d3069c: ldr     x2, [x29]                                  T:type56879(k15)
02d306a0: mov     x0, x25                                    
02d306a4: mov     x1, x26                                    
02d306a8: bl      #0x35a9868                                 fn_35a9868
02d306ac: mov     x24, x0                                    
02d306b0: ldr     x0, [x27]                                  &2c5bbd4(=a9bd7bfdd503233f)
02d306b4: ldr     w8, [x0, #0xe4]                            [626a0e4]=0 f=0,0
02d306b8: cbnz    w8, #0x2d306c0                             
02d306bc: bl      #0x2b70f30                                 fn_2b70f30
02d306c0: mov     x0, x24                                    
02d306c4: mov     x1, xzr                                    
02d306c8: mov     x2, xzr                                    
02d306cc: bl      #0x5b3666c                                 UnityEngine.Object::op_Inequality
02d306d0: tbz     w0, #0, #0x2d306e4                         
02d306d4: cbz     x24, #0x2d308ac                            
02d306d8: mov     x0, x24                                    
02d306dc: bl      #0x2d3097c                                 BlindBagCollection.SellItem::AddDuplicate
02d306e0: b       #0x2d307d4                                 
02d306e4: ldr     x8, [sp]                                   
02d306e8: ldr     x24, [x8, #0x50]                           MS:System.Collections.Generic.List`1::Find
02d306ec: cbz     x24, #0x2d308b8                            
02d306f0: mov     x0, x24                                    
02d306f4: mov     x1, xzr                                    
02d306f8: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02d306fc: cbz     x0, #0x2d308b4                             
02d30700: mov     x1, xzr                                    
02d30704: bl      #0x5b466dc                                 UnityEngine.Transform::get_parent
02d30708: mov     x25, x0                                    
02d3070c: ldr     x0, [x27]                                  &2c5bbd4(=a9bd7bfdd503233f)
02d30710: ldr     w8, [x0, #0xe4]                            [626a0e4]=0 f=0,0
02d30714: cbnz    w8, #0x2d3071c                             
02d30718: bl      #0x2b70f30                                 fn_2b70f30
02d3071c: adrp    x8, #0x626a000                             
02d30720: ldr     x8, [x8, #0x6b8]                           MS:UnityEngine.Object::Instantiate
02d30724: ldr     x2, [x8]                                   T:type56879(k15)
02d30728: mov     x0, x24                                    
02d3072c: mov     x1, x25                                    
02d30730: bl      #0x3275fcc                                 fn_3275fcc
02d30734: mov     x24, x0                                    
02d30738: cbz     x0, #0x2d308bc                             
02d3073c: ldr     x1, [x23]                                  
02d30740: mov     x0, x24                                    
02d30744: mov     w2, w22                                    
02d30748: bl      #0x2d30a08                                 BlindBagCollection.SellItem::SetItem
02d3074c: mov     x0, x24                                    
02d30750: mov     x1, xzr                                    
02d30754: bl      #0x5b339ec                                 UnityEngine.Component::get_gameObject
02d30758: cbz     x0, #0x2d308b0                             
02d3075c: mov     w1, #1                                     
02d30760: mov     x2, xzr                                    
02d30764: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d30768: ldr     x0, [x21]                                  T:type56879(k15)
02d3076c: cbz     x0, #0x2d308a8                             
02d30770: adrp    x9, #0x626a000                             
02d30774: ldr     w10, [x0, #0x1c]                           [626a01c]=0 f=0,0
02d30778: ldr     x8, [x0, #0x10]                            T:Decor.DataDecor/CategoryData
02d3077c: ldr     x9, [x9, #0x6a0]                           MS:System.Collections.Generic.List`1::Add
02d30780: add     w10, w10, #1                               
02d30784: ldr     x9, [x9]                                   T:type56879(k15)
02d30788: str     w10, [x0, #0x1c]                           
02d3078c: cbz     x8, #0x2d308a8                             
02d30790: ldrsw   x10, [x0, #0x18]                           
02d30794: ldr     w11, [x8, #0x18]                           MS:System.Collections.Generic.List`1::Add
02d30798: cmp     w10, w11                                   
02d3079c: b.hs    #0x2d307c0                                 
02d307a0: add     x8, x8, x10, lsl #3                        &626a000
02d307a4: add     w9, w10, #1                                
02d307a8: str     w9, [x0, #0x18]                            
02d307ac: str     x24, [x8, #0x20]!                          
02d307b0: mov     x0, x8                                     
02d307b4: mov     x1, x24                                    
02d307b8: bl      #0x2b70d54                                 fn_2b70d54
02d307bc: b       #0x2d307d4                                 
02d307c0: ldr     x8, [x9, #0x20]                            M:Decor.DataDecor/<>c__DisplayClass8_0::<NewData>b__0
02d307c4: ldr     x8, [x8, #0xc0]                            S:'Main character is null'
02d307c8: ldr     x2, [x8, #0x70]                            MS:System.Collections.Generic.List`1::FindIndex
02d307cc: mov     x1, x24                                    
02d307d0: bl      #0x35a920c                                 fn_35a920c
02d307d4: ldr     w8, [x20]                                  
02d307d8: add     w8, w8, w22                                
02d307dc: str     w8, [x20]                                  
02d307e0: b       #0x2d3062c                                 
02d307e4: adrp    x8, #0x626a000                             
02d307e8: add     x0, sp, #0x30                              
02d307ec: ldr     x8, [x8, #0x688]                           MS:System.Collections.Generic.List`1/Enumerator::Dispose
02d307f0: ldr     x1, [x8]                                   T:type56879(k15)
02d307f4: bl      #0x4655d28                                 fn_4655d28
02d307f8: ldr     x19, [sp]                                  
02d307fc: ldr     x21, [x19, #0x60]                          M:Decor.DecorAsset/<>c__DisplayClass4_0::<GetCategoryAssetByName>b__0 ._txtTradeAdPrice
02d30800: mov     x0, x20                                    
02d30804: mov     x1, xzr                                    
02d30808: bl      #0x4e0ea3c                                 System.Int32::ToString
02d3080c: cbz     x21, #0x2d308c0                            
02d30810: ldr     x8, [x21]                                  T:type56879(k15)
02d30814: mov     x1, x0                                     
02d30818: mov     x0, x21                                    
02d3081c: ldr     x9, [x8, #0x558]                           MS:System.Runtime.CompilerServices.AsyncVoidMethodBuilder::Start
02d30820: ldr     x2, [x8, #0x560]                           M:DailyTask.PopupDailyTask::<OnButtonCloseClicked>b__25_0
02d30824: blr     x9                                         
02d30828: ldr     s0, [x19, #0x80]                           T:type56651(k15) ._totalPrice
02d3082c: ldr     s1, [x19, #0x70]                           MS:System.Collections.Generic.List`1::FindIndex ._normalTradeScale
02d30830: mov     w8, #0x7f800000                            
02d30834: ldr     x19, [x19, #0x68]                          T:Decor.DecorAsset/<>c__DisplayClass5_0 ._txtTradeNormalPrice
02d30838: add     x0, sp, #0x2c                              
02d3083c: mov     x1, xzr                                    
02d30840: scvtf   s0, s0                                     
02d30844: fmul    s0, s1, s0                                 
02d30848: fmov    s1, w8                                     
02d3084c: mov     w8, #-0xffffffff80000000                   
02d30850: fcvtzs  w9, s0                                     
02d30854: fcmp    s0, s1                                     
02d30858: csel    w8, w8, w9, eq                             
02d3085c: str     w8, [sp, #0x2c]                            
02d30860: bl      #0x4e0ea3c                                 System.Int32::ToString
02d30864: cbz     x19, #0x2d308c0                            
02d30868: ldr     x8, [x19]                                  T:type56879(k15)
02d3086c: mov     x1, x0                                     
02d30870: mov     x0, x19                                    
02d30874: ldr     x9, [x8, #0x558]                           MS:System.Runtime.CompilerServices.AsyncVoidMethodBuilder::Start
02d30878: ldr     x2, [x8, #0x560]                           M:DailyTask.PopupDailyTask::<OnButtonCloseClicked>b__25_0
02d3087c: blr     x9                                         
02d30880: ldp     x20, x19, [sp, #0xa0]                      
02d30884: ldp     x22, x21, [sp, #0x90]                      
02d30888: ldp     x24, x23, [sp, #0x80]                      
02d3088c: ldp     x26, x25, [sp, #0x70]                      
02d30890: ldp     x28, x27, [sp, #0x60]                      
02d30894: ldp     x29, x30, [sp, #0x50]                      
02d30898: add     sp, sp, #0xb0                              
02d3089c: ret                                                
02d308a0: bl      #0x2b7105c                                 fn_2b7105c
02d308a4: bl      #0x2b7105c                                 fn_2b7105c
02d308a8: bl      #0x2b7105c                                 fn_2b7105c
02d308ac: bl      #0x2b7105c                                 fn_2b7105c
02d308b0: bl      #0x2b7105c                                 fn_2b7105c
02d308b4: bl      #0x2b7105c                                 fn_2b7105c
02d308b8: bl      #0x2b7105c                                 fn_2b7105c
02d308bc: bl      #0x2b7105c                                 fn_2b7105c
02d308c0: bl      #0x2b7105c                                 fn_2b7105c
02d308c4: b       #0x2d30918                                 
02d308c8: b       #0x2d30918                                 
02d308cc: b       #0x2d30918                                 
02d308d0: b       #0x2d30918                                 
02d308d4: b       #0x2d30918                                 
02d308d8: b       #0x2d30918                                 
02d308dc: b       #0x2d30918                                 
02d308e0: b       #0x2d30918                                 
02d308e4: b       #0x2d30918                                 
02d308e8: b       #0x2d30918                                 
02d308ec: b       #0x2d30918                                 
02d308f0: b       #0x2d30918                                 
02d308f4: b       #0x2d30918                                 
02d308f8: b       #0x2d30918                                 
02d308fc: b       #0x2d30918                                 
02d30900: b       #0x2d30918                                 
02d30904: b       #0x2d30918                                 
02d30908: b       #0x2d30918                                 
02d3090c: b       #0x2d30918                                 
02d30910: b       #0x2d30918                                 
02d30914: b       #0x2d30918                                 
02d30918: ldr     x19, [sp]                                  
02d3091c: mov     x21, x0                                    
02d30920: cmp     w1, #1                                     
02d30924: b.ne    #0x2d30960                                 
02d30928: mov     x0, x21                                    
02d3092c: bl      #0x5e90260                                 fn_5e90260
02d30930: ldr     x21, [x0]                                  T:type56879(k15)
02d30934: str     x21, [sp, #8]                              
02d30938: bl      #0x5e90270                                 fn_5e90270
02d3093c: adrp    x8, #0x626a000                             
02d30940: ldr     x0, [sp, #0x10]                            
02d30944: ldr     x8, [x8, #0x688]                           MS:System.Collections.Generic.List`1/Enumerator::Dispose
02d30948: ldr     x1, [x8]                                   T:type56879(k15)
02d3094c: bl      #0x4655d28                                 fn_4655d28
02d30950: cbz     x21, #0x2d307fc                            
02d30954: mov     x0, x21                                    
02d30958: bl      #0x2b71054                                 fn_2b71054
02d3095c: mov     x21, x0                                    
02d30960: add     x0, sp, #8                                 
02d30964: bl      #0x27382a8                                 fn_27382a8
02d30968: mov     x0, x21                                    
02d3096c: bl      #0x2c6051c                                 fn_2c6051c
02d30970: bl      #0x27369b8                                 fn_27369b8
## OnInit(UIManager uiManager) -> void
---- BlindBagCollection.AutoSellPopup::OnInit 0x2d30ae4
02d30ae4: str     x30, [sp, #-0x30]!                         
02d30ae8: stp     x22, x21, [sp, #0x10]                      
02d30aec: stp     x20, x19, [sp, #0x20]                      
02d30af0: adrp    x21, #0x6630000                            
02d30af4: mov     x20, x1                                    
02d30af8: mov     x19, x0                                    
02d30afc: ldrb    w8, [x21, #0xf3]                           
02d30b00: tbnz    w8, #0, #0x2d30b30                         
02d30b04: adrp    x0, #0x626a000                             
02d30b08: ldr     x0, [x0, #0x6d8]                           M:BlindBagCollection.AutoSellPopup::<OnInit>b__13_0
02d30b0c: bl      #0x2b70db0                                 fn_2b70db0
02d30b10: adrp    x0, #0x626a000                             
02d30b14: ldr     x0, [x0, #0x6e0]                           M:BlindBagCollection.AutoSellPopup::<OnInit>b__13_1
02d30b18: bl      #0x2b70db0                                 fn_2b70db0
02d30b1c: adrp    x0, #0x6265000                             
02d30b20: ldr     x0, [x0, #0x3f0]                           T:UnityEngine.Events.UnityAction
02d30b24: bl      #0x2b70db0                                 fn_2b70db0
02d30b28: mov     w8, #1                                     
02d30b2c: strb    w8, [x21, #0xf3]                           
02d30b30: mov     x0, x19                                    
02d30b34: mov     x1, x20                                    
02d30b38: mov     x2, xzr                                    
02d30b3c: bl      #0x2cdd3c4                                 UIBase::OnInit
02d30b40: ldr     x8, [x19, #0x40]                           ._tradeAdButton
02d30b44: cbz     x8, #0x2d30bdc                             
02d30b48: adrp    x22, #0x6265000                            
02d30b4c: adrp    x21, #0x626a000                            
02d30b50: ldr     x22, [x22, #0x3f0]                         T:UnityEngine.Events.UnityAction
02d30b54: ldr     x21, [x21, #0x6d8]                         M:BlindBagCollection.AutoSellPopup::<OnInit>b__13_0
02d30b58: ldr     x20, [x8, #0x100]                          
02d30b5c: ldr     x0, [x22]                                  M:AdsManager::<OnApplicationPause>b__26_0
02d30b60: bl      #0x2b7104c                                 fn_2b7104c
02d30b64: ldr     x2, [x21]                                  T:type56879(k15)
02d30b68: mov     x1, x19                                    
02d30b6c: mov     x3, xzr                                    
02d30b70: mov     x21, x0                                    
02d30b74: bl      #0x5b4cf98                                 UnityEngine.Events.UnityAction::.ctor
02d30b78: cbz     x20, #0x2d30bdc                            
02d30b7c: mov     x0, x20                                    
02d30b80: mov     x1, x21                                    
02d30b84: mov     x2, xzr                                    
02d30b88: bl      #0x5b4d0ac                                 UnityEngine.Events.UnityEvent::AddListener
02d30b8c: ldr     x8, [x19, #0x48]                           ._tradeNormalButton
02d30b90: cbz     x8, #0x2d30bdc                             
02d30b94: adrp    x21, #0x626a000                            
02d30b98: ldr     x21, [x21, #0x6e0]                         M:BlindBagCollection.AutoSellPopup::<OnInit>b__13_1
02d30b9c: ldr     x0, [x22]                                  M:AdsManager::<OnApplicationPause>b__26_0
02d30ba0: ldr     x20, [x8, #0x100]                          
02d30ba4: bl      #0x2b7104c                                 fn_2b7104c
02d30ba8: ldr     x2, [x21]                                  T:type56879(k15)
02d30bac: mov     x1, x19                                    
02d30bb0: mov     x3, xzr                                    
02d30bb4: mov     x21, x0                                    
02d30bb8: bl      #0x5b4cf98                                 UnityEngine.Events.UnityAction::.ctor
02d30bbc: cbz     x20, #0x2d30bdc                            
02d30bc0: mov     x0, x20                                    
02d30bc4: mov     x1, x21                                    
02d30bc8: mov     x2, xzr                                    
02d30bcc: ldp     x20, x19, [sp, #0x20]                      
02d30bd0: ldp     x22, x21, [sp, #0x10]                      
02d30bd4: ldr     x30, [sp], #0x30                           
02d30bd8: b       #0x5b4d0ac                                 UnityEngine.Events.UnityEvent::AddListener
02d30bdc: bl      #0x2b7105c                                 fn_2b7105c
## OnHide() -> void
---- BlindBagCollection.AutoSellPopup::OnHide 0x2d30be0
02d30be0: sub     sp, sp, #0x60                              
02d30be4: stp     x30, x23, [sp, #0x30]                      
02d30be8: stp     x22, x21, [sp, #0x40]                      
02d30bec: stp     x20, x19, [sp, #0x50]                      
02d30bf0: adrp    x20, #0x6630000                            
02d30bf4: mov     x19, x0                                    
02d30bf8: ldrb    w8, [x20, #0xf4]                           
02d30bfc: tbnz    w8, #0, #0x2d30c50                         
02d30c00: adrp    x0, #0x626a000                             
02d30c04: ldr     x0, [x0, #0x6e8]                           MS:System.Collections.Generic.List`1/Enumerator::Dispose
02d30c08: bl      #0x2b70db0                                 fn_2b70db0
02d30c0c: adrp    x0, #0x626a000                             
02d30c10: ldr     x0, [x0, #0x6f0]                           MS:System.Collections.Generic.List`1/Enumerator::MoveNext
02d30c14: bl      #0x2b70db0                                 fn_2b70db0
02d30c18: adrp    x0, #0x626a000                             
02d30c1c: ldr     x0, [x0, #0x6f8]                           MS:System.Collections.Generic.List`1/Enumerator::get_Current
02d30c20: bl      #0x2b70db0                                 fn_2b70db0
02d30c24: adrp    x0, #0x626a000                             
02d30c28: ldr     x0, [x0, #0x700]                           MS:System.Collections.Generic.List`1::GetEnumerator
02d30c2c: bl      #0x2b70db0                                 fn_2b70db0
02d30c30: adrp    x0, #0x6263000                             
02d30c34: ldr     x0, [x0, #0x918]                           T:UnityEngine.Object
02d30c38: bl      #0x2b70db0                                 fn_2b70db0
02d30c3c: adrp    x0, #0x6265000                             
02d30c40: ldr     x0, [x0, #0x310]                           MS:WejoyService.Singleton`1::get_Instance
02d30c44: bl      #0x2b70db0                                 fn_2b70db0
02d30c48: mov     w8, #1                                     
02d30c4c: strb    w8, [x20, #0xf4]                           
02d30c50: mov     x0, x19                                    
02d30c54: mov     x1, xzr                                    
02d30c58: stp     xzr, xzr, [sp, #0x18]                      
02d30c5c: str     xzr, [sp, #0x28]                           
02d30c60: bl      #0x2cddc10                                 UIBase::OnHide
02d30c64: ldr     x8, [x19, #0x78]                           ._onComplete
02d30c68: cbz     x8, #0x2d30c7c                             
02d30c6c: ldr     x9, [x8, #0x18]                            
02d30c70: ldr     x0, [x8, #0x40]                            
02d30c74: ldr     x1, [x8, #0x28]                            
02d30c78: blr     x9                                         
02d30c7c: ldr     x0, [x19, #0x88]                           ._sellItems
02d30c80: cbz     x0, #0x2d30d3c                             
02d30c84: adrp    x8, #0x626a000                             
02d30c88: adrp    x22, #0x626a000                            
02d30c8c: adrp    x23, #0x6263000                            
02d30c90: ldr     x8, [x8, #0x700]                           MS:System.Collections.Generic.List`1::GetEnumerator
02d30c94: adrp    x20, #0x6265000                            
02d30c98: adrp    x21, #0x626a000                            
02d30c9c: ldr     x22, [x22, #0x6f0]                         MS:System.Collections.Generic.List`1/Enumerator::MoveNext
02d30ca0: ldr     x23, [x23, #0x918]                         T:UnityEngine.Object
02d30ca4: ldr     x20, [x20, #0x310]                         MS:WejoyService.Singleton`1::get_Instance
02d30ca8: ldr     x21, [x21, #0x6e8]                         MS:System.Collections.Generic.List`1/Enumerator::Dispose
02d30cac: ldr     x1, [x8]                                   T:type56879(k15)
02d30cb0: add     x8, sp, #0x18                              
02d30cb4: add     x19, sp, #0x18                             
02d30cb8: bl      #0x35a9d9c                                 fn_35a9d9c
02d30cbc: stp     xzr, x19, [sp, #8]                         
02d30cc0: ldr     x1, [x22]                                  T:type56879(k15)
02d30cc4: add     x0, sp, #0x18                              
02d30cc8: bl      #0x4690474                                 fn_4690474
02d30ccc: tbz     w0, #0, #0x2d30d04                         
02d30cd0: ldr     x0, [sp, #0x28]                            
02d30cd4: cbz     x0, #0x2d30d38                             
02d30cd8: mov     x1, xzr                                    
02d30cdc: bl      #0x5b339ec                                 UnityEngine.Component::get_gameObject
02d30ce0: mov     x19, x0                                    
02d30ce4: ldr     x0, [x23]                                  &2c5bbd4(=a9bd7bfdd503233f)
02d30ce8: ldr     w8, [x0, #0xe4]                            [62650e4]=0 f=0,0
02d30cec: cbnz    w8, #0x2d30cf4                             
02d30cf0: bl      #0x2b70f30                                 fn_2b70f30
02d30cf4: mov     x0, x19                                    
02d30cf8: mov     x1, xzr                                    
02d30cfc: bl      #0x5b3ca38                                 UnityEngine.Object::Destroy
02d30d00: b       #0x2d30cc0                                 
02d30d04: ldr     x1, [x21]                                  T:type56879(k15)
02d30d08: add     x0, sp, #0x18                              
02d30d0c: bl      #0x4690470                                 fn_4690470
02d30d10: ldr     x0, [x20]                                  M:AdsManager::<OnApplicationPause>b__26_0
02d30d14: bl      #0x3be7218                                 fn_3be7218
02d30d18: cbz     x0, #0x2d30d3c                             
02d30d1c: mov     x1, xzr                                    
02d30d20: bl      #0x2c88cec                                 AdsManager::HideMREC
02d30d24: ldp     x20, x19, [sp, #0x50]                      
02d30d28: ldp     x22, x21, [sp, #0x40]                      
02d30d2c: ldp     x30, x23, [sp, #0x30]                      
02d30d30: add     sp, sp, #0x60                              
02d30d34: ret                                                
02d30d38: bl      #0x2b7105c                                 fn_2b7105c
02d30d3c: bl      #0x2b7105c                                 fn_2b7105c
02d30d40: b       #0x2d30d48                                 
02d30d44: b       #0x2d30d48                                 
02d30d48: mov     x19, x0                                    
02d30d4c: cmp     w1, #1                                     
02d30d50: b.ne    #0x2d30d84                                 
02d30d54: mov     x0, x19                                    
02d30d58: bl      #0x5e90260                                 fn_5e90260
02d30d5c: ldr     x19, [x0]                                  M:AdsManager::<OnApplicationPause>b__26_0
02d30d60: str     x19, [sp, #8]                              
02d30d64: bl      #0x5e90270                                 fn_5e90270
02d30d68: ldr     x0, [sp, #0x10]                            
02d30d6c: ldr     x1, [x21]                                  T:type56879(k15)
02d30d70: bl      #0x4690470                                 fn_4690470
02d30d74: cbz     x19, #0x2d30d10                            
02d30d78: mov     x0, x19                                    
02d30d7c: bl      #0x2b71054                                 fn_2b71054
02d30d80: mov     x19, x0                                    
02d30d84: add     x0, sp, #8                                 
02d30d88: bl      #0x27382d8                                 fn_27382d8
02d30d8c: mov     x0, x19                                    
02d30d90: bl      #0x2c6051c                                 fn_2c6051c
02d30d94: bl      #0x27369b8                                 fn_27369b8
## .ctor() -> void
---- BlindBagCollection.AutoSellPopup::.ctor 0x2d30d98
02d30d98: str     x30, [sp, #-0x30]!                         
02d30d9c: stp     x22, x21, [sp, #0x10]                      
02d30da0: stp     x20, x19, [sp, #0x20]                      
02d30da4: adrp    x22, #0x6630000                            
02d30da8: adrp    x21, #0x626a000                            
02d30dac: adrp    x20, #0x626a000                            
02d30db0: ldrb    w8, [x22, #0xf5]                           
02d30db4: ldr     x21, [x21, #0x678]                         T:type56804(k15)
02d30db8: ldr     x20, [x20, #0x680]                         MS:System.Collections.Generic.List`1::.ctor
02d30dbc: mov     x19, x0                                    
02d30dc0: tbnz    w8, #0, #0x2d30de4                         
02d30dc4: adrp    x0, #0x626a000                             
02d30dc8: ldr     x0, [x0, #0x680]                           MS:System.Collections.Generic.List`1::.ctor
02d30dcc: bl      #0x2b70db0                                 fn_2b70db0
02d30dd0: adrp    x0, #0x626a000                             
02d30dd4: ldr     x0, [x0, #0x678]                           T:type56804(k15)
02d30dd8: bl      #0x2b70db0                                 fn_2b70db0
02d30ddc: mov     w8, #1                                     
02d30de0: strb    w8, [x22, #0xf5]                           
02d30de4: mov     w8, #0xcccd                                
02d30de8: ldr     x0, [x21]                                  T:type56879(k15)
02d30dec: movk    w8, #0x3e4c, lsl #16                       
02d30df0: str     w8, [x19, #0x70]                           ._normalTradeScale
02d30df4: bl      #0x2b7104c                                 fn_2b7104c
02d30df8: ldr     x1, [x20]                                  T:type56879(k15)
02d30dfc: mov     x20, x0                                    
02d30e00: bl      #0x35a89a4                                 fn_35a89a4
02d30e04: mov     x0, x19                                    
02d30e08: mov     x1, x20                                    
02d30e0c: str     x20, [x0, #0x88]!                          ._sellItems
02d30e10: bl      #0x2b70d54                                 fn_2b70d54
02d30e14: mov     x0, x19                                    
02d30e18: ldp     x20, x19, [sp, #0x20]                      
02d30e1c: ldp     x22, x21, [sp, #0x10]                      
02d30e20: mov     x1, xzr                                    
02d30e24: ldr     x30, [sp], #0x30                           
02d30e28: b       #0x2cddba8                                 PopupBase::.ctor
## <OnInit>b__13_0() -> void
---- BlindBagCollection.AutoSellPopup::<OnInit>b__13_0 0x2d30e2c
02d30e2c: stp     x30, x21, [sp, #-0x20]!                    
02d30e30: stp     x20, x19, [sp, #0x10]                      
02d30e34: adrp    x21, #0x6630000                            
02d30e38: adrp    x20, #0x6266000                            
02d30e3c: mov     x19, x0                                    
02d30e40: ldrb    w8, [x21, #0xf6]                           
02d30e44: ldr     x20, [x20, #0xaa0]                         MS:MonoSingleton`1::get_Instance
02d30e48: tbnz    w8, #0, #0x2d30e60                         
02d30e4c: adrp    x0, #0x6266000                             
02d30e50: ldr     x0, [x0, #0xaa0]                           MS:MonoSingleton`1::get_Instance
02d30e54: bl      #0x2b70db0                                 fn_2b70db0
02d30e58: mov     w8, #1                                     
02d30e5c: strb    w8, [x21, #0xf6]                           
02d30e60: movi    d1, #0000000000000000                      
02d30e64: movi    d2, #0000000000000000                      
02d30e68: mov     w0, #1                                     
02d30e6c: fmov    s0, #1.00000000                            
02d30e70: mov     w1, wzr                                    
02d30e74: mov     w2, wzr                                    
02d30e78: mov     x3, xzr                                    
02d30e7c: bl      #0x2d84264                                 Framework.AudioHelper::PlaySound
02d30e80: ldr     x0, [x20]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d30e84: bl      #0x3769600                                 fn_3769600
02d30e88: cbz     x0, #0x2d30eb8                             
02d30e8c: ldr     w1, [x19, #0x80]                           ._totalPrice
02d30e90: mov     w2, #0xa                                   
02d30e94: mov     x3, xzr                                    
02d30e98: mov     x4, xzr                                    
02d30e9c: bl      #0x2cdaf30                                 MoneyManager::CollectMoney
02d30ea0: ldr     x8, [x19]                                  
02d30ea4: mov     x0, x19                                    
02d30ea8: ldp     x20, x19, [sp, #0x10]                      
02d30eac: ldp     x2, x1, [x8, #0x198]                       
02d30eb0: ldp     x30, x21, [sp], #0x20                      
02d30eb4: br      x2                                         
02d30eb8: bl      #0x2b7105c                                 fn_2b7105c
## <OnInit>b__13_1() -> void
---- BlindBagCollection.AutoSellPopup::<OnInit>b__13_1 0x2d30ebc
02d30ebc: stp     x30, x21, [sp, #-0x20]!                    
02d30ec0: stp     x20, x19, [sp, #0x10]                      
02d30ec4: adrp    x21, #0x6630000                            
02d30ec8: adrp    x20, #0x6266000                            
02d30ecc: mov     x19, x0                                    
02d30ed0: ldrb    w8, [x21, #0xf7]                           
02d30ed4: ldr     x20, [x20, #0xaa0]                         MS:MonoSingleton`1::get_Instance
02d30ed8: tbnz    w8, #0, #0x2d30ef0                         
02d30edc: adrp    x0, #0x6266000                             
02d30ee0: ldr     x0, [x0, #0xaa0]                           MS:MonoSingleton`1::get_Instance
02d30ee4: bl      #0x2b70db0                                 fn_2b70db0
02d30ee8: mov     w8, #1                                     
02d30eec: strb    w8, [x21, #0xf7]                           
02d30ef0: movi    d1, #0000000000000000                      
02d30ef4: movi    d2, #0000000000000000                      
02d30ef8: mov     w0, #1                                     
02d30efc: fmov    s0, #1.00000000                            
02d30f00: mov     w1, wzr                                    
02d30f04: mov     w2, wzr                                    
02d30f08: mov     x3, xzr                                    
02d30f0c: bl      #0x2d84264                                 Framework.AudioHelper::PlaySound
02d30f10: ldr     x0, [x20]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d30f14: bl      #0x3769600                                 fn_3769600
02d30f18: cbz     x0, #0x2d30f70                             
02d30f1c: ldr     s0, [x19, #0x80]                           ._totalPrice
02d30f20: adrp    x8, #0x1084000                             
02d30f24: mov     w2, #0xa                                   
02d30f28: ldr     s1, [x8, #0xdd8]                           [1084dd8]=3f7333333e4ccccd f=0.2,0.95
02d30f2c: mov     w8, #0x7f800000                            
02d30f30: mov     x3, xzr                                    
02d30f34: scvtf   s0, s0                                     
02d30f38: mov     x4, xzr                                    
02d30f3c: fmul    s0, s0, s1                                 
02d30f40: fmov    s1, w8                                     
02d30f44: mov     w8, #-0xffffffff80000000                   
02d30f48: fcvtzs  w9, s0                                     
02d30f4c: fcmp    s0, s1                                     
02d30f50: csel    w1, w8, w9, eq                             
02d30f54: bl      #0x2cdaf30                                 MoneyManager::CollectMoney
02d30f58: ldr     x8, [x19]                                  
02d30f5c: mov     x0, x19                                    
02d30f60: ldp     x20, x19, [sp, #0x10]                      
02d30f64: ldp     x2, x1, [x8, #0x198]                       
02d30f68: ldp     x30, x21, [sp], #0x20                      
02d30f6c: br      x2                                         
02d30f70: bl      #0x2b7105c                                 fn_2b7105c
