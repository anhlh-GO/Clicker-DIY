#### CLASS PopupUnlockAt parent= PopupBase
#   field _panel                         UnityEngine.RectTransform                          off=0x38 attr=1 SerializeField
#   field _contentText                   TMPro.TextMeshProUGUI                              off=0x40 attr=1 SerializeField
#   field _initialPos                    UnityEngine.Vector3                                off=0x48 attr=1 
## OnInit(UIManager uiManager) -> void
---- PopupUnlockAt::OnInit 0x2cb075c
02cb075c: stp     x30, x19, [sp, #-0x10]!                    
02cb0760: mov     x2, xzr                                    
02cb0764: mov     x19, x0                                    
02cb0768: bl      #0x2cdd3c4                                 UIBase::OnInit
02cb076c: ldr     x0, [x19, #0x38]                           ._panel
02cb0770: cbz     x0, #0x2cb078c                             
02cb0774: mov     x1, xzr                                    
02cb0778: bl      #0x5b45c24                                 UnityEngine.Transform::get_localPosition
02cb077c: stp     s0, s1, [x19, #0x48]                       ._initialPos
02cb0780: str     s2, [x19, #0x50]                           
02cb0784: ldp     x30, x19, [sp], #0x10                      
02cb0788: ret                                                
02cb078c: bl      #0x2b7105c                                 fn_2b7105c
## OnShow() -> void
---- PopupUnlockAt::OnShow 0x2cb0790
02cb0790: stp     x30, x23, [sp, #-0x30]!                    
02cb0794: stp     x22, x21, [sp, #0x10]                      
02cb0798: stp     x20, x19, [sp, #0x20]                      
02cb079c: adrp    x20, #0x662f000                            
02cb07a0: mov     x19, x0                                    
02cb07a4: ldrb    w8, [x20, #0xb68]                          
02cb07a8: tbnz    w8, #0, #0x2cb07e4                         
02cb07ac: adrp    x0, #0x6266000                             
02cb07b0: ldr     x0, [x0, #0xa38]                           M:PopupUnlockAt::<OnShow>b__4_0
02cb07b4: bl      #0x2b70db0                                 fn_2b70db0
02cb07b8: adrp    x0, #0x6264000                             
02cb07bc: ldr     x0, [x0, #0xe8]                            T:DG.Tweening.TweenCallback
02cb07c0: bl      #0x2b70db0                                 fn_2b70db0
02cb07c4: adrp    x0, #0x6266000                             
02cb07c8: ldr     x0, [x0, #0x928]                           MS:DG.Tweening.TweenSettingsExtensions::OnComplete
02cb07cc: bl      #0x2b70db0                                 fn_2b70db0
02cb07d0: adrp    x0, #0x6266000                             
02cb07d4: ldr     x0, [x0, #0xa40]                           S:' - [Showing]'
02cb07d8: bl      #0x2b70db0                                 fn_2b70db0
02cb07dc: mov     w8, #1                                     
02cb07e0: strb    w8, [x20, #0xb68]                          
02cb07e4: ldr     x0, [x19, #0x38]                           ._panel
02cb07e8: cbz     x0, #0x2cb090c                             
02cb07ec: ldp     s1, s2, [x19, #0x4c]                       
02cb07f0: mov     x1, xzr                                    
02cb07f4: ldr     s0, [x19, #0x48]                           ._initialPos
02cb07f8: bl      #0x5b45cec                                 UnityEngine.Transform::set_localPosition
02cb07fc: mov     x0, xzr                                    
02cb0800: bl      #0x2d6eec8                                 Framework.AudioManager::get_Instance
02cb0804: cbz     x0, #0x2cb090c                             
02cb0808: movi    d1, #0000000000000000                      
02cb080c: movi    d2, #0000000000000000                      
02cb0810: adrp    x21, #0x6266000                            
02cb0814: fmov    s0, #0.50000000                            
02cb0818: ldr     x21, [x21, #0xa40]                         S:' - [Showing]'
02cb081c: mov     w1, #4                                     
02cb0820: mov     w2, wzr                                    
02cb0824: mov     w3, wzr                                    
02cb0828: mov     x4, xzr                                    
02cb082c: bl      #0x2d6f03c                                 Framework.AudioManager::PlaySound
02cb0830: movi    d0, #0000000000000000                      
02cb0834: ldr     x0, [x19, #0x28]                           
02cb0838: mov     w1, #1                                     
02cb083c: mov     x2, xzr                                    
02cb0840: bl      #0x2cf1928                                 FrameWorkUtility::SetActive
02cb0844: mov     x0, x19                                    
02cb0848: mov     x1, xzr                                    
02cb084c: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02cb0850: mov     x20, x0                                    
02cb0854: mov     x0, x19                                    
02cb0858: mov     x1, xzr                                    
02cb085c: bl      #0x5b3bba4                                 UnityEngine.Object::get_name
02cb0860: ldr     x1, [x21]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cb0864: mov     x2, xzr                                    
02cb0868: bl      #0x4c9c514                                 System.String::Concat
02cb086c: cbz     x20, #0x2cb090c                            
02cb0870: adrp    x21, #0x6264000                            
02cb0874: adrp    x22, #0x6266000                            
02cb0878: adrp    x23, #0x6266000                            
02cb087c: mov     x1, x0                                     
02cb0880: ldr     x21, [x21, #0xe8]                          T:DG.Tweening.TweenCallback
02cb0884: ldr     x22, [x22, #0xa38]                         M:PopupUnlockAt::<OnShow>b__4_0
02cb0888: ldr     x23, [x23, #0x928]                         MS:DG.Tweening.TweenSettingsExtensions::OnComplete
02cb088c: mov     x0, x20                                    
02cb0890: mov     x2, xzr                                    
02cb0894: bl      #0x5b3bcf8                                 UnityEngine.Object::set_name
02cb0898: ldr     x0, [x19, #0x38]                           ._panel
02cb089c: mov     w1, wzr                                    
02cb08a0: mov     x2, xzr                                    
02cb08a4: bl      #0x2d9d5d0                                 DG.Tweening.ShortcutExtensions::DOKill
02cb08a8: mov     w8, #0x43020000                            
02cb08ac: ldr     s0, [x19, #0x4c]                           
02cb08b0: ldr     x0, [x19, #0x38]                           ._panel
02cb08b4: fmov    s1, w8                                     
02cb08b8: mov     w1, wzr                                    
02cb08bc: mov     x2, xzr                                    
02cb08c0: fadd    s0, s0, s1                                 
02cb08c4: fmov    s1, #2.00000000                            
02cb08c8: bl      #0x2d98060                                 DG.Tweening.ShortcutExtensions::DOLocalMoveY
02cb08cc: ldr     x8, [x21]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02cb08d0: mov     x20, x0                                    
02cb08d4: mov     x0, x8                                     
02cb08d8: bl      #0x2b7104c                                 fn_2b7104c
02cb08dc: ldr     x2, [x22]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cb08e0: mov     x1, x19                                    
02cb08e4: mov     x3, xzr                                    
02cb08e8: mov     x21, x0                                    
02cb08ec: bl      #0x2d89dc4                                 DG.Tweening.TweenCallback::.ctor
02cb08f0: mov     x0, x20                                    
02cb08f4: mov     x1, x21                                    
02cb08f8: ldr     x2, [x23]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cb08fc: ldp     x20, x19, [sp, #0x20]                      
02cb0900: ldp     x22, x21, [sp, #0x10]                      
02cb0904: ldp     x30, x23, [sp], #0x30                      
02cb0908: b       #0x336f26c                                 
02cb090c: bl      #0x2b7105c                                 fn_2b7105c
## SetUnlockLevelText(int level) -> void
---- PopupUnlockAt::SetUnlockLevelText 0x2cb0910
02cb0910: ret                                                
## SetContent(string content) -> void
---- PopupUnlockAt::SetContent 0x2cb0914
02cb0914: ldr     x0, [x0, #0x40]                            ._contentText
02cb0918: cbz     x0, #0x2cb092c                             
02cb091c: ldr     x8, [x0]                                   
02cb0920: ldr     x2, [x8, #0x560]                           
02cb0924: ldr     x3, [x8, #0x558]                           
02cb0928: br      x3                                         
02cb092c: str     x30, [sp, #-0x10]!                         
02cb0930: bl      #0x2b7105c                                 fn_2b7105c
## .ctor() -> void
---- PopupUnlockAt::.ctor 0x2cb0934
02cb0934: mov     x1, xzr                                    
02cb0938: b       #0x2cddba8                                 PopupBase::.ctor
## <OnShow>b__4_0() -> void
---- PopupUnlockAt::<OnShow>b__4_0 0x2cb093c
02cb093c: ldr     x8, [x0]                                   
02cb0940: ldp     x2, x1, [x8, #0x198]                       
02cb0944: br      x2                                         
