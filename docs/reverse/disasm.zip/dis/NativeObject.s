#### CLASS NativeObject parent= object
#   field _adFormat                      AdFormat                                           off=0x10 attr=1 
## get_AdFormat() -> AdFormat
---- NativeObject::get_AdFormat 0x2c9bba8
02c9bba8: ldr     w0, [x0, #0x10]                            ._adFormat
02c9bbac: ret                                                
## .ctor() -> void
---- NativeObject::.ctor 0x2c9bbb0
02c9bbb0: mov     x1, xzr                                    
02c9bbb4: b       #0x4e53e9c                                 System.Object::.ctor
