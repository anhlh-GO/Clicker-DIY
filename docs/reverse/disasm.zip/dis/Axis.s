#### CLASS Axis parent= int
#   field value__                        int                                                off=0x10 attr=606 
#   field X                              Axis                                               off=0x0 attr=8056 
#   field Y                              Axis                                               off=0x0 attr=8056 
#   field Z                              Axis                                               off=0x0 attr=8056 
