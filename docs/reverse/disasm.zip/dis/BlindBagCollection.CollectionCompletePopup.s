#### CLASS BlindBagCollection.CollectionCompletePopup/<>c parent= object
#   field <>9                            BlindBagCollection.CollectionCompletePopup/<>c     off=0x0 attr=36 
#   field <>9__18_1                      System.Action                                      off=0x8 attr=16 
#   field <>9__19_1                      System.Action                                      off=0x10 attr=16 
## .cctor() -> void
---- BlindBagCollection.CollectionCompletePopup/<>c::.cctor 0x2d3a9ac
02d3a9ac: str     x30, [sp, #-0x20]!                         
02d3a9b0: stp     x20, x19, [sp, #0x10]                      
02d3a9b4: adrp    x19, #0x6630000                            
02d3a9b8: adrp    x20, #0x626a000                            
02d3a9bc: ldrb    w8, [x19, #0x148]                          
02d3a9c0: ldr     x20, [x20, #0xcc0]                         T:BlindBagCollection.CollectionCompletePopup/<>c
02d3a9c4: tbnz    w8, #0, #0x2d3a9dc                         
02d3a9c8: adrp    x0, #0x626a000                             
02d3a9cc: ldr     x0, [x0, #0xcc0]                           T:BlindBagCollection.CollectionCompletePopup/<>c
02d3a9d0: bl      #0x2b70db0                                 fn_2b70db0
02d3a9d4: mov     w8, #1                                     
02d3a9d8: strb    w8, [x19, #0x148]                          
02d3a9dc: ldr     x0, [x20]                                  T:type56879(k15)
02d3a9e0: bl      #0x2b7104c                                 fn_2b7104c
02d3a9e4: mov     x1, xzr                                    
02d3a9e8: mov     x19, x0                                    
02d3a9ec: bl      #0x4e53e9c                                 System.Object::.ctor
02d3a9f0: ldr     x8, [x20]                                  T:type56879(k15)
02d3a9f4: mov     x1, x19                                    
02d3a9f8: ldr     x8, [x8, #0xb8]                            
02d3a9fc: str     x19, [x8]                                  
02d3aa00: ldr     x8, [x20]                                  T:type56879(k15)
02d3aa04: ldp     x20, x19, [sp, #0x10]                      
02d3aa08: ldr     x0, [x8, #0xb8]                            
02d3aa0c: ldr     x30, [sp], #0x20                           
02d3aa10: b       #0x2b70d54                                 
## .ctor() -> void
---- BlindBagCollection.CollectionCompletePopup/<>c::.ctor 0x2d3aa14
02d3aa14: mov     x1, xzr                                    
02d3aa18: b       #0x4e53e9c                                 System.Object::.ctor
## <OnBtnRewardClick>b__18_1() -> void
---- BlindBagCollection.CollectionCompletePopup/<>c::<OnBtnRewardClick>b__18_1 0x2d3aa1c
02d3aa1c: ret                                                
## <OnBtnAdRewardClick>b__19_1() -> void
---- BlindBagCollection.CollectionCompletePopup/<>c::<OnBtnAdRewardClick>b__19_1 0x2d3aa20
02d3aa20: str     d8, [sp, #-0x40]!                          
02d3aa24: stp     x30, x23, [sp, #0x10]                      
02d3aa28: stp     x22, x21, [sp, #0x20]                      
02d3aa2c: stp     x20, x19, [sp, #0x30]                      
02d3aa30: adrp    x19, #0x6630000                            
02d3aa34: adrp    x20, #0x6266000                            
02d3aa38: ldrb    w8, [x19, #0x149]                          
02d3aa3c: ldr     x20, [x20, #0x658]                         MS:MonoSingleton`1::get_Instance
02d3aa40: tbnz    w8, #0, #0x2d3aaa0                         
02d3aa44: adrp    x0, #0x6266000                             
02d3aa48: ldr     x0, [x0, #0x750]                           MS:DataManager::GetData
02d3aa4c: bl      #0x2b70db0                                 fn_2b70db0
02d3aa50: adrp    x0, #0x6265000                             
02d3aa54: ldr     x0, [x0, #0xb38]                           T:DevTrack
02d3aa58: bl      #0x2b70db0                                 fn_2b70db0
02d3aa5c: adrp    x0, #0x6266000                             
02d3aa60: ldr     x0, [x0, #0x5e0]                           T:GameConfig
02d3aa64: bl      #0x2b70db0                                 fn_2b70db0
02d3aa68: adrp    x0, #0x6266000                             
02d3aa6c: ldr     x0, [x0, #0xac0]                           MS:MonoSingleton`1::get_Instance
02d3aa70: bl      #0x2b70db0                                 fn_2b70db0
02d3aa74: adrp    x0, #0x6265000                             
02d3aa78: ldr     x0, [x0, #0x10]                            MS:MonoSingleton`1::get_Instance .<>9__19_1
02d3aa7c: bl      #0x2b70db0                                 fn_2b70db0
02d3aa80: adrp    x0, #0x6266000                             
02d3aa84: ldr     x0, [x0, #0x658]                           MS:MonoSingleton`1::get_Instance
02d3aa88: bl      #0x2b70db0                                 fn_2b70db0
02d3aa8c: adrp    x0, #0x6266000                             
02d3aa90: ldr     x0, [x0, #0xb48]                           MS:MonoSingleton`1::get_Instance
02d3aa94: bl      #0x2b70db0                                 fn_2b70db0
02d3aa98: mov     w8, #1                                     
02d3aa9c: strb    w8, [x19, #0x149]                          
02d3aaa0: ldr     x0, [x20]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d3aaa4: bl      #0x3769600                                 fn_3769600
02d3aaa8: cbz     x0, #0x2d3ac44                             
02d3aaac: adrp    x8, #0x6266000                             
02d3aab0: ldr     x8, [x8, #0x750]                           MS:DataManager::GetData
02d3aab4: ldr     x1, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d3aab8: bl      #0x3168dd0                                 fn_3168dd0
02d3aabc: cbz     x0, #0x2d3ac44                             
02d3aac0: ldr     x8, [x0, #0x20]                            S:'inter_ad_capping_time'
02d3aac4: cbz     x8, #0x2d3ac44                             
02d3aac8: adrp    x19, #0x6266000                            
02d3aacc: ldrb    w9, [x8, #0x45]                            
02d3aad0: ldr     x19, [x19, #0xac0]                         MS:MonoSingleton`1::get_Instance
02d3aad4: cbnz    w9, #0x2d3aaf0                             
02d3aad8: mov     w9, #1                                     
02d3aadc: strb    w9, [x8, #0x45]                            
02d3aae0: ldr     x8, [x0]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d3aae4: ldr     x9, [x8, #0x258]                           MS:System.Collections.Generic.List`1/Enumerator::Dispose
02d3aae8: ldr     x1, [x8, #0x260]                           MS:System.Collections.Generic.List`1/Enumerator::MoveNext
02d3aaec: blr     x9                                         
02d3aaf0: ldr     x0, [x19]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d3aaf4: bl      #0x3769600                                 fn_3769600
02d3aaf8: cbz     x0, #0x2d3ac44                             
02d3aafc: adrp    x8, #0x6265000                             
02d3ab00: adrp    x20, #0x6266000                            
02d3ab04: mov     w9, #2                                     
02d3ab08: ldr     x8, [x8, #0x10]                            MS:MonoSingleton`1::get_Instance
02d3ab0c: ldr     x20, [x20, #0x5e0]                         T:GameConfig
02d3ab10: str     w9, [x0, #0x60]                            
02d3ab14: ldr     x8, [x8]                                   M:AdsManager::<OnApplicationPause>b__26_0
02d3ab18: mov     x0, x8                                     
02d3ab1c: bl      #0x3769600                                 fn_3769600
02d3ab20: ldr     x8, [x20]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d3ab24: mov     x19, x0                                    
02d3ab28: ldr     w9, [x8, #0xe4]                            [62650e4]=0 f=0,0
02d3ab2c: cbnz    w9, #0x2d3ab38                             
02d3ab30: mov     x0, x8                                     
02d3ab34: bl      #0x2b70f30                                 fn_2b70f30
02d3ab38: cbz     x19, #0x2d3ac44                            
02d3ab3c: ldr     x8, [x20]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d3ab40: adrp    x23, #0x6266000                            
02d3ab44: mov     x0, x19                                    
02d3ab48: mov     w2, wzr                                    
02d3ab4c: mov     x3, xzr                                    
02d3ab50: ldr     x8, [x8, #0xb8]                            T:AdsManager/<>c__DisplayClass42_0
02d3ab54: ldr     x23, [x23, #0xb48]                         MS:MonoSingleton`1::get_Instance
02d3ab58: ldr     x1, [x8, #8]                               M:AdsManager::<OnApplicationPause>b__26_1
02d3ab5c: bl      #0x2ce9e58                                 SimpleSceneTransition::FlashIn
02d3ab60: ldr     x0, [x23]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d3ab64: bl      #0x3769600                                 fn_3769600
02d3ab68: cbz     x0, #0x2d3ac44                             
02d3ab6c: ldr     x19, [x0, #0x30]                           S:'popup_rate_on_off'
02d3ab70: ldr     x0, [x23]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d3ab74: bl      #0x3769600                                 fn_3769600
02d3ab78: cbz     x0, #0x2d3ac44                             
02d3ab7c: adrp    x21, #0x6265000                            
02d3ab80: mov     x8, x0                                     
02d3ab84: ldr     x21, [x21, #0xb38]                         T:DevTrack
02d3ab88: ldr     w20, [x8, #0x3c]                           [626503c]=0 f=0,0
02d3ab8c: ldr     x0, [x21]                                  M:AdsManager::<OnApplicationPause>b__26_0
02d3ab90: ldr     w9, [x0, #0xe4]                            [62660e4]=0 f=0,0
02d3ab94: cbnz    w9, #0x2d3aba0                             
02d3ab98: bl      #0x2b70f30                                 fn_2b70f30
02d3ab9c: ldr     x0, [x21]                                  M:AdsManager::<OnApplicationPause>b__26_0
02d3aba0: ldr     x8, [x0, #0xb8]                            S:'banner_native_refresh_time'
02d3aba4: mov     x0, xzr                                    
02d3aba8: ldr     x21, [x8, #0x2c8]                          S:'ad_platform'
02d3abac: ldr     w22, [x8, #0x2e4]                          [62652e4]=0 f=0,0
02d3abb0: bl      #0x5b432fc                                 UnityEngine.Time::get_time
02d3abb4: ldr     x0, [x23]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d3abb8: fmov    s8, s0                                     
02d3abbc: bl      #0x3769600                                 fn_3769600
02d3abc0: cbz     x0, #0x2d3ac44                             
02d3abc4: ldr     s0, [x0, #0x38]                            S:'native_collap_id'
02d3abc8: mov     x0, x19                                    
02d3abcc: mov     w1, w20                                    
02d3abd0: mov     x2, x21                                    
02d3abd4: mov     w3, w22                                    
02d3abd8: mov     x4, xzr                                    
02d3abdc: fsub    s0, s8, s0                                 
02d3abe0: bl      #0x2c9c898                                 DevTrack::GameModeStepComplete
02d3abe4: ldr     x0, [x23]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d3abe8: bl      #0x3769600                                 fn_3769600
02d3abec: cbz     x0, #0x2d3ac44                             
02d3abf0: ldr     x19, [x0, #0x30]                           S:'popup_rate_on_off'
02d3abf4: ldr     x0, [x23]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d3abf8: bl      #0x3769600                                 fn_3769600
02d3abfc: cbz     x0, #0x2d3ac44                             
02d3ac00: ldr     w20, [x0, #0x3c]                           [626603c]=0 f=0,0
02d3ac04: mov     x0, xzr                                    
02d3ac08: bl      #0x5b432fc                                 UnityEngine.Time::get_time
02d3ac0c: ldr     x0, [x23]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d3ac10: fmov    s8, s0                                     
02d3ac14: bl      #0x3769600                                 fn_3769600
02d3ac18: cbz     x0, #0x2d3ac44                             
02d3ac1c: ldr     s0, [x0, #0x38]                            S:'native_collap_id'
02d3ac20: mov     x0, x19                                    
02d3ac24: mov     w1, w20                                    
02d3ac28: ldp     x20, x19, [sp, #0x30]                      
02d3ac2c: mov     x2, xzr                                    
02d3ac30: ldp     x22, x21, [sp, #0x20]                      
02d3ac34: fsub    s0, s8, s0                                 
02d3ac38: ldp     x30, x23, [sp, #0x10]                      
02d3ac3c: ldr     d8, [sp], #0x40                            
02d3ac40: b       #0x2c9cd1c                                 DevTrack::GameModeComplete
02d3ac44: bl      #0x2b7105c                                 fn_2b7105c
#### CLASS BlindBagCollection.CollectionCompletePopup/<>c__DisplayClass18_0 parent= object
#   field dataUser                       DataUser                                           off=0x10 attr=6 
## .ctor() -> void
---- BlindBagCollection.CollectionCompletePopup/<>c__DisplayClass18_0::.ctor 0x2d3a748
02d3a748: mov     x1, xzr                                    
02d3a74c: b       #0x4e53e9c                                 System.Object::.ctor
## <OnBtnRewardClick>b__0() -> void
---- BlindBagCollection.CollectionCompletePopup/<>c__DisplayClass18_0::<OnBtnRewardClick>b__0 0x2d3ac48
02d3ac48: str     d8, [sp, #-0x40]!                          
02d3ac4c: str     x30, [sp, #8]                              
02d3ac50: stp     x24, x23, [sp, #0x10]                      
02d3ac54: stp     x22, x21, [sp, #0x20]                      
02d3ac58: stp     x20, x19, [sp, #0x30]                      
02d3ac5c: adrp    x21, #0x6630000                            
02d3ac60: adrp    x20, #0x6265000                            
02d3ac64: adrp    x24, #0x626a000                            
02d3ac68: ldrb    w8, [x21, #0x14a]                          
02d3ac6c: ldr     x20, [x20, #0x310]                         MS:WejoyService.Singleton`1::get_Instance
02d3ac70: ldr     x24, [x24, #0xcc0]                         T:BlindBagCollection.CollectionCompletePopup/<>c
02d3ac74: mov     x19, x0                                    
02d3ac78: tbnz    w8, #0, #0x2d3acfc                         
02d3ac7c: adrp    x0, #0x6264000                             
02d3ac80: ldr     x0, [x0, #0xf90]                           T:System.Action
02d3ac84: bl      #0x2b70db0                                 fn_2b70db0
02d3ac88: adrp    x0, #0x6265000                             
02d3ac8c: ldr     x0, [x0, #0xb38]                           T:DevTrack
02d3ac90: bl      #0x2b70db0                                 fn_2b70db0
02d3ac94: adrp    x0, #0x6266000                             
02d3ac98: ldr     x0, [x0, #0x5e0]                           T:GameConfig
02d3ac9c: bl      #0x2b70db0                                 fn_2b70db0
02d3aca0: adrp    x0, #0x6266000                             
02d3aca4: ldr     x0, [x0, #0xac0]                           MS:MonoSingleton`1::get_Instance
02d3aca8: bl      #0x2b70db0                                 fn_2b70db0
02d3acac: adrp    x0, #0x6265000                             
02d3acb0: ldr     x0, [x0, #0x10]                            MS:MonoSingleton`1::get_Instance .dataUser
02d3acb4: bl      #0x2b70db0                                 fn_2b70db0
02d3acb8: adrp    x0, #0x6266000                             
02d3acbc: ldr     x0, [x0, #0xb48]                           MS:MonoSingleton`1::get_Instance
02d3acc0: bl      #0x2b70db0                                 fn_2b70db0
02d3acc4: adrp    x0, #0x6265000                             
02d3acc8: ldr     x0, [x0, #0x310]                           MS:WejoyService.Singleton`1::get_Instance
02d3accc: bl      #0x2b70db0                                 fn_2b70db0
02d3acd0: adrp    x0, #0x626a000                             
02d3acd4: ldr     x0, [x0, #0xcc8]                           M:BlindBagCollection.CollectionCompletePopup/<>c::<OnBtnRewardClick>b__18_1
02d3acd8: bl      #0x2b70db0                                 fn_2b70db0
02d3acdc: adrp    x0, #0x626a000                             
02d3ace0: ldr     x0, [x0, #0xcc0]                           T:BlindBagCollection.CollectionCompletePopup/<>c
02d3ace4: bl      #0x2b70db0                                 fn_2b70db0
02d3ace8: adrp    x0, #0x626a000                             
02d3acec: ldr     x0, [x0, #0xcd0]                           S:'no_thanks'
02d3acf0: bl      #0x2b70db0                                 fn_2b70db0
02d3acf4: mov     w8, #1                                     
02d3acf8: strb    w8, [x21, #0x14a]                          
02d3acfc: adrp    x21, #0x626a000                            
02d3ad00: ldr     x21, [x21, #0xcd0]                         S:'no_thanks'
02d3ad04: ldr     x0, [x20]                                  M:AdsManager::<OnApplicationPause>b__26_0
02d3ad08: bl      #0x3be7218                                 fn_3be7218
02d3ad0c: ldr     x8, [x24]                                  T:type56879(k15)
02d3ad10: mov     x20, x0                                    
02d3ad14: ldr     w9, [x8, #0xe4]                            
02d3ad18: cbnz    w9, #0x2d3ad28                             
02d3ad1c: mov     x0, x8                                     
02d3ad20: bl      #0x2b70f30                                 fn_2b70f30
02d3ad24: ldr     x8, [x24]                                  T:type56879(k15)
02d3ad28: ldr     x9, [x8, #0xb8]                            
02d3ad2c: ldr     x21, [x21]                                 T:type56879(k15)
02d3ad30: ldr     x22, [x9, #8]                              
02d3ad34: cbnz    x22, #0x2d3ad94                            
02d3ad38: ldr     w10, [x8, #0xe4]                           
02d3ad3c: cbnz    w10, #0x2d3ad50                            
02d3ad40: mov     x0, x8                                     
02d3ad44: bl      #0x2b70f30                                 fn_2b70f30
02d3ad48: ldr     x8, [x24]                                  T:type56879(k15)
02d3ad4c: ldr     x9, [x8, #0xb8]                            
02d3ad50: adrp    x8, #0x6264000                             
02d3ad54: ldr     x8, [x8, #0xf90]                           T:System.Action
02d3ad58: ldr     x23, [x9]                                  
02d3ad5c: ldr     x0, [x8]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d3ad60: bl      #0x2b7104c                                 fn_2b7104c
02d3ad64: adrp    x8, #0x626a000                             
02d3ad68: mov     x1, x23                                    
02d3ad6c: mov     x3, xzr                                    
02d3ad70: ldr     x8, [x8, #0xcc8]                           M:BlindBagCollection.CollectionCompletePopup/<>c::<OnBtnRewardClick>b__18_1
02d3ad74: mov     x22, x0                                    
02d3ad78: ldr     x2, [x8]                                   T:type56879(k15)
02d3ad7c: bl      #0x4d8ddbc                                 System.Action::.ctor
02d3ad80: ldr     x8, [x24]                                  T:type56879(k15)
02d3ad84: mov     x1, x22                                    
02d3ad88: ldr     x0, [x8, #0xb8]                            MS:UnityEngine.Object::FindObjectsOfType
02d3ad8c: str     x22, [x0, #8]!                             
02d3ad90: bl      #0x2b70d54                                 fn_2b70d54
02d3ad94: cbz     x20, #0x2d3af40                            
02d3ad98: mov     x0, x20                                    
02d3ad9c: mov     x1, x21                                    
02d3ada0: mov     x2, x22                                    
02d3ada4: mov     w3, #1                                     
02d3ada8: mov     x4, xzr                                    
02d3adac: bl      #0x2c89698                                 AdsManager::ShowInter
02d3adb0: ldr     x0, [x19, #0x10]                           .dataUser
02d3adb4: cbz     x0, #0x2d3af40                             
02d3adb8: ldr     x8, [x0, #0x20]                            M:Decor.DataDecor/<>c__DisplayClass8_0::<NewData>b__0
02d3adbc: cbz     x8, #0x2d3af40                             
02d3adc0: adrp    x19, #0x6266000                            
02d3adc4: ldrb    w9, [x8, #0x45]                            
02d3adc8: ldr     x19, [x19, #0xac0]                         MS:MonoSingleton`1::get_Instance
02d3adcc: cbnz    w9, #0x2d3ade8                             
02d3add0: mov     w9, #1                                     
02d3add4: strb    w9, [x8, #0x45]                            
02d3add8: ldr     x8, [x0]                                   T:type56879(k15)
02d3addc: ldr     x9, [x8, #0x258]                           M:Decor.OptionPanel::<Refresh>b__19_0
02d3ade0: ldr     x1, [x8, #0x260]                           MS:System.Collections.Generic.List`1/Enumerator::Dispose
02d3ade4: blr     x9                                         
02d3ade8: ldr     x0, [x19]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d3adec: bl      #0x3769600                                 fn_3769600
02d3adf0: cbz     x0, #0x2d3af40                             
02d3adf4: adrp    x8, #0x6265000                             
02d3adf8: adrp    x20, #0x6266000                            
02d3adfc: mov     w9, #2                                     
02d3ae00: ldr     x8, [x8, #0x10]                            MS:MonoSingleton`1::get_Instance
02d3ae04: ldr     x20, [x20, #0x5e0]                         T:GameConfig
02d3ae08: str     w9, [x0, #0x60]                            
02d3ae0c: ldr     x8, [x8]                                   M:AdsManager::<OnApplicationPause>b__26_0
02d3ae10: mov     x0, x8                                     
02d3ae14: bl      #0x3769600                                 fn_3769600
02d3ae18: ldr     x8, [x20]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d3ae1c: mov     x19, x0                                    
02d3ae20: ldr     w9, [x8, #0xe4]                            [62650e4]=0 f=0,0
02d3ae24: cbnz    w9, #0x2d3ae30                             
02d3ae28: mov     x0, x8                                     
02d3ae2c: bl      #0x2b70f30                                 fn_2b70f30
02d3ae30: cbz     x19, #0x2d3af40                            
02d3ae34: ldr     x8, [x20]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d3ae38: adrp    x23, #0x6266000                            
02d3ae3c: mov     x0, x19                                    
02d3ae40: mov     w2, wzr                                    
02d3ae44: mov     x3, xzr                                    
02d3ae48: ldr     x8, [x8, #0xb8]                            T:AdsManager/<>c__DisplayClass42_0
02d3ae4c: ldr     x23, [x23, #0xb48]                         MS:MonoSingleton`1::get_Instance
02d3ae50: ldr     x1, [x8, #8]                               M:AdsManager::<OnApplicationPause>b__26_1
02d3ae54: bl      #0x2ce9e58                                 SimpleSceneTransition::FlashIn
02d3ae58: ldr     x0, [x23]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d3ae5c: bl      #0x3769600                                 fn_3769600
02d3ae60: cbz     x0, #0x2d3af40                             
02d3ae64: ldr     x19, [x0, #0x30]                           S:'======================================================  i : '
02d3ae68: ldr     x0, [x23]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d3ae6c: bl      #0x3769600                                 fn_3769600
02d3ae70: cbz     x0, #0x2d3af40                             
02d3ae74: adrp    x21, #0x6265000                            
02d3ae78: mov     x8, x0                                     
02d3ae7c: ldr     x21, [x21, #0xb38]                         T:DevTrack
02d3ae80: ldr     w20, [x8, #0x3c]                           [626503c]=0 f=0,0
02d3ae84: ldr     x0, [x21]                                  M:AdsManager::<OnApplicationPause>b__26_0
02d3ae88: ldr     w9, [x0, #0xe4]                            [626a0e4]=0 f=0,0
02d3ae8c: cbnz    w9, #0x2d3ae98                             
02d3ae90: bl      #0x2b70f30                                 fn_2b70f30
02d3ae94: ldr     x0, [x21]                                  M:AdsManager::<OnApplicationPause>b__26_0
02d3ae98: ldr     x8, [x0, #0xb8]                            MS:UnityEngine.Object::FindObjectsOfType
02d3ae9c: mov     x0, xzr                                    
02d3aea0: ldr     x21, [x8, #0x2c8]                          S:'ad_platform'
02d3aea4: ldr     w22, [x8, #0x2e4]                          [62652e4]=0 f=0,0
02d3aea8: bl      #0x5b432fc                                 UnityEngine.Time::get_time
02d3aeac: ldr     x0, [x23]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d3aeb0: fmov    s8, s0                                     
02d3aeb4: bl      #0x3769600                                 fn_3769600
02d3aeb8: cbz     x0, #0x2d3af40                             
02d3aebc: ldr     s0, [x0, #0x38]                            MS:System.Collections.Generic.List`1::get_Item
02d3aec0: mov     x0, x19                                    
02d3aec4: mov     w1, w20                                    
02d3aec8: mov     x2, x21                                    
02d3aecc: mov     w3, w22                                    
02d3aed0: mov     x4, xzr                                    
02d3aed4: fsub    s0, s8, s0                                 
02d3aed8: bl      #0x2c9c898                                 DevTrack::GameModeStepComplete
02d3aedc: ldr     x0, [x23]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d3aee0: bl      #0x3769600                                 fn_3769600
02d3aee4: cbz     x0, #0x2d3af40                             
02d3aee8: ldr     x19, [x0, #0x30]                           S:'======================================================  i : '
02d3aeec: ldr     x0, [x23]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d3aef0: bl      #0x3769600                                 fn_3769600
02d3aef4: cbz     x0, #0x2d3af40                             
02d3aef8: ldr     w20, [x0, #0x3c]                           [626a03c]=0 f=0,0
02d3aefc: mov     x0, xzr                                    
02d3af00: bl      #0x5b432fc                                 UnityEngine.Time::get_time
02d3af04: ldr     x0, [x23]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d3af08: fmov    s8, s0                                     
02d3af0c: bl      #0x3769600                                 fn_3769600
02d3af10: cbz     x0, #0x2d3af40                             
02d3af14: ldr     s0, [x0, #0x38]                            MS:System.Collections.Generic.List`1::get_Item
02d3af18: mov     x0, x19                                    
02d3af1c: mov     w1, w20                                    
02d3af20: ldp     x20, x19, [sp, #0x30]                      
02d3af24: ldr     x30, [sp, #8]                              
02d3af28: ldp     x22, x21, [sp, #0x20]                      
02d3af2c: fsub    s0, s8, s0                                 
02d3af30: ldp     x24, x23, [sp, #0x10]                      
02d3af34: mov     x2, xzr                                    
02d3af38: ldr     d8, [sp], #0x40                            
02d3af3c: b       #0x2c9cd1c                                 DevTrack::GameModeComplete
02d3af40: bl      #0x2b7105c                                 fn_2b7105c
#### CLASS BlindBagCollection.CollectionCompletePopup parent= PopupBase
#   field _btnAdReward                   UnityEngine.UI.Button                              off=0x38 attr=1 SerializeField
#   field _btnReward                     UnityEngine.UI.Button                              off=0x40 attr=1 SerializeField
#   field _imgCustomer                   UnityEngine.UI.Image                               off=0x48 attr=1 SerializeField
#   field _viewerAvatarAsset             ViewerAvatarAsset                                  off=0x50 attr=1 SerializeField
#   field _txtCompliment                 TMPro.TextMeshProUGUI                              off=0x58 attr=1 SerializeField
#   field _txtEarnings                   TMPro.TextMeshProUGUI                              off=0x60 attr=1 SerializeField
#   field _txtTips                       TMPro.TextMeshProUGUI                              off=0x68 attr=1 SerializeField
#   field _fxConfetti                    AssetKits.ParticleImage.ParticleImage              off=0x70 attr=1 SerializeField
#   field _tfTitle                       UnityEngine.Transform                              off=0x78 attr=1 SerializeField
#   field _tfCompliment                  UnityEngine.Transform                              off=0x80 attr=1 SerializeField
#   field _tfRewardInfo                  UnityEngine.Transform                              off=0x88 attr=1 SerializeField
#   field _tfBtnAdReward                 UnityEngine.Transform                              off=0x90 attr=1 SerializeField
#   field _tfBtnReward                   UnityEngine.Transform                              off=0x98 attr=1 SerializeField
#   field _moneyReward                   int                                                off=0xa0 attr=1 
#   field _moneyBonus                    int                                                off=0xa4 attr=1 
## OnInit(UIManager uiManager) -> void
---- BlindBagCollection.CollectionCompletePopup::OnInit 0x2d39dd4
02d39dd4: str     x30, [sp, #-0x30]!                         
02d39dd8: stp     x22, x21, [sp, #0x10]                      
02d39ddc: stp     x20, x19, [sp, #0x20]                      
02d39de0: adrp    x21, #0x6630000                            
02d39de4: mov     x20, x1                                    
02d39de8: mov     x19, x0                                    
02d39dec: ldrb    w8, [x21, #0x143]                          
02d39df0: tbnz    w8, #0, #0x2d39e2c                         
02d39df4: adrp    x0, #0x626a000                             
02d39df8: ldr     x0, [x0, #0xc88]                           M:BlindBagCollection.CollectionCompletePopup::OnBtnAdRewardClick
02d39dfc: bl      #0x2b70db0                                 fn_2b70db0
02d39e00: adrp    x0, #0x626a000                             
02d39e04: ldr     x0, [x0, #0xc90]                           M:BlindBagCollection.CollectionCompletePopup::OnBtnRewardClick
02d39e08: bl      #0x2b70db0                                 fn_2b70db0
02d39e0c: adrp    x0, #0x6264000                             
02d39e10: ldr     x0, [x0, #0xfc0]                           T:RemoteConfigManager
02d39e14: bl      #0x2b70db0                                 fn_2b70db0
02d39e18: adrp    x0, #0x6265000                             
02d39e1c: ldr     x0, [x0, #0x3f0]                           T:UnityEngine.Events.UnityAction
02d39e20: bl      #0x2b70db0                                 fn_2b70db0
02d39e24: mov     w8, #1                                     
02d39e28: strb    w8, [x21, #0x143]                          
02d39e2c: mov     x0, x19                                    
02d39e30: mov     x1, x20                                    
02d39e34: mov     x2, xzr                                    
02d39e38: bl      #0x2cdd3c4                                 UIBase::OnInit
02d39e3c: ldr     x8, [x19, #0x40]                           ._btnReward
02d39e40: cbz     x8, #0x2d39f98                             
02d39e44: ldr     x0, [x8, #0x100]                           
02d39e48: cbz     x0, #0x2d39f98                             
02d39e4c: mov     x1, xzr                                    
02d39e50: bl      #0x5b4ce48                                 UnityEngine.Events.UnityEventBase::RemoveAllListeners
02d39e54: ldr     x8, [x19, #0x40]                           ._btnReward
02d39e58: cbz     x8, #0x2d39f98                             
02d39e5c: adrp    x22, #0x6265000                            
02d39e60: adrp    x21, #0x626a000                            
02d39e64: ldr     x22, [x22, #0x3f0]                         T:UnityEngine.Events.UnityAction
02d39e68: ldr     x21, [x21, #0xc90]                         M:BlindBagCollection.CollectionCompletePopup::OnBtnRewardClick
02d39e6c: ldr     x20, [x8, #0x100]                          
02d39e70: ldr     x0, [x22]                                  M:AdsManager::<OnApplicationPause>b__26_0
02d39e74: bl      #0x2b7104c                                 fn_2b7104c
02d39e78: ldr     x2, [x21]                                  T:type56879(k15)
02d39e7c: mov     x1, x19                                    
02d39e80: mov     x3, xzr                                    
02d39e84: mov     x21, x0                                    
02d39e88: bl      #0x5b4cf98                                 UnityEngine.Events.UnityAction::.ctor
02d39e8c: cbz     x20, #0x2d39f98                            
02d39e90: mov     x0, x20                                    
02d39e94: mov     x1, x21                                    
02d39e98: mov     x2, xzr                                    
02d39e9c: bl      #0x5b4d0ac                                 UnityEngine.Events.UnityEvent::AddListener
02d39ea0: ldr     x8, [x19, #0x38]                           ._btnAdReward
02d39ea4: cbz     x8, #0x2d39f98                             
02d39ea8: ldr     x0, [x8, #0x100]                           
02d39eac: cbz     x0, #0x2d39f98                             
02d39eb0: mov     x1, xzr                                    
02d39eb4: bl      #0x5b4ce48                                 UnityEngine.Events.UnityEventBase::RemoveAllListeners
02d39eb8: ldr     x8, [x19, #0x38]                           ._btnAdReward
02d39ebc: cbz     x8, #0x2d39f98                             
02d39ec0: adrp    x21, #0x626a000                            
02d39ec4: ldr     x21, [x21, #0xc88]                         M:BlindBagCollection.CollectionCompletePopup::OnBtnAdRewardClick
02d39ec8: ldr     x0, [x22]                                  M:AdsManager::<OnApplicationPause>b__26_0
02d39ecc: ldr     x20, [x8, #0x100]                          
02d39ed0: bl      #0x2b7104c                                 fn_2b7104c
02d39ed4: ldr     x2, [x21]                                  T:type56879(k15)
02d39ed8: mov     x1, x19                                    
02d39edc: mov     x3, xzr                                    
02d39ee0: mov     x21, x0                                    
02d39ee4: bl      #0x5b4cf98                                 UnityEngine.Events.UnityAction::.ctor
02d39ee8: cbz     x20, #0x2d39f98                            
02d39eec: mov     x0, x20                                    
02d39ef0: mov     x1, x21                                    
02d39ef4: mov     x2, xzr                                    
02d39ef8: bl      #0x5b4d0ac                                 UnityEngine.Events.UnityEvent::AddListener
02d39efc: ldr     x0, [x19, #0x70]                           ._fxConfetti
02d39f00: cbz     x0, #0x2d39f98                             
02d39f04: mov     x1, xzr                                    
02d39f08: bl      #0x5b339ec                                 UnityEngine.Component::get_gameObject
02d39f0c: cbz     x0, #0x2d39f98                             
02d39f10: adrp    x20, #0x6264000                            
02d39f14: mov     w1, wzr                                    
02d39f18: mov     x2, xzr                                    
02d39f1c: ldr     x20, [x20, #0xfc0]                         T:RemoteConfigManager
02d39f20: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d39f24: ldr     x0, [x20]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d39f28: ldr     w8, [x0, #0xe4]                            [62650e4]=0 f=0,0
02d39f2c: cbnz    w8, #0x2d39f34                             
02d39f30: bl      #0x2b70f30                                 fn_2b70f30
02d39f34: adrp    x21, #0x662f000                            
02d39f38: ldrb    w8, [x21, #0xbc1]                          
02d39f3c: cbnz    w8, #0x2d39f54                             
02d39f40: adrp    x0, #0x6264000                             
02d39f44: ldr     x0, [x0, #0xfc0]                           T:RemoteConfigManager
02d39f48: bl      #0x2b70db0                                 fn_2b70db0
02d39f4c: mov     w8, #1                                     
02d39f50: strb    w8, [x21, #0xbc1]                          
02d39f54: ldr     x0, [x20]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d39f58: ldr     w8, [x0, #0xe4]                            [62640e4]=0 f=0,0
02d39f5c: cbnz    w8, #0x2d39f68                             
02d39f60: bl      #0x2b70f30                                 fn_2b70f30
02d39f64: ldr     x0, [x20]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d39f68: ldr     x8, [x0, #0xb8]                            MS:DG.Tweening.Core.Extensions::SetSpecialStartupMode
02d39f6c: mov     w9, #0x12c                                 
02d39f70: mov     w10, #0x1f4                                
02d39f74: ldp     x22, x21, [sp, #0x10]                      
02d39f78: ldr     w8, [x8, #0x10]                            
02d39f7c: cmp     w8, #1                                     
02d39f80: csel    w8, w10, w9, eq                            
02d39f84: mov     w9, #0x64                                  
02d39f88: stp     w8, w9, [x19, #0xa0]                       ._moneyReward
02d39f8c: ldp     x20, x19, [sp, #0x20]                      
02d39f90: ldr     x30, [sp], #0x30                           
02d39f94: ret                                                
02d39f98: bl      #0x2b7105c                                 fn_2b7105c
## OnShow() -> void
---- BlindBagCollection.CollectionCompletePopup::OnShow 0x2d39f9c
02d39f9c: str     d8, [sp, #-0x40]!                          
02d39fa0: str     x30, [sp, #8]                              
02d39fa4: stp     x24, x23, [sp, #0x10]                      
02d39fa8: stp     x22, x21, [sp, #0x20]                      
02d39fac: stp     x20, x19, [sp, #0x30]                      
02d39fb0: adrp    x21, #0x6630000                            
02d39fb4: adrp    x20, #0x6265000                            
02d39fb8: mov     x19, x0                                    
02d39fbc: ldrb    w8, [x21, #0x144]                          
02d39fc0: ldr     x20, [x20, #0x310]                         MS:WejoyService.Singleton`1::get_Instance
02d39fc4: tbnz    w8, #0, #0x2d3a054                         
02d39fc8: adrp    x0, #0x6266000                             
02d39fcc: ldr     x0, [x0, #0x750]                           MS:DataManager::GetData
02d39fd0: bl      #0x2b70db0                                 fn_2b70db0
02d39fd4: adrp    x0, #0x6265000                             
02d39fd8: ldr     x0, [x0, #0xb38]                           T:DevTrack
02d39fdc: bl      #0x2b70db0                                 fn_2b70db0
02d39fe0: adrp    x0, #0x6267000                             
02d39fe4: ldr     x0, [x0, #0xd20]                           MS:MonoSingleton`1::get_Instance
02d39fe8: bl      #0x2b70db0                                 fn_2b70db0
02d39fec: adrp    x0, #0x6266000                             
02d39ff0: ldr     x0, [x0, #0xac0]                           MS:MonoSingleton`1::get_Instance
02d39ff4: bl      #0x2b70db0                                 fn_2b70db0
02d39ff8: adrp    x0, #0x6266000                             
02d39ffc: ldr     x0, [x0, #0x658]                           MS:MonoSingleton`1::get_Instance
02d3a000: bl      #0x2b70db0                                 fn_2b70db0
02d3a004: adrp    x0, #0x6266000                             
02d3a008: ldr     x0, [x0, #0xb48]                           MS:MonoSingleton`1::get_Instance
02d3a00c: bl      #0x2b70db0                                 fn_2b70db0
02d3a010: adrp    x0, #0x6263000                             
02d3a014: ldr     x0, [x0, #0x918]                           T:UnityEngine.Object
02d3a018: bl      #0x2b70db0                                 fn_2b70db0
02d3a01c: adrp    x0, #0x6265000                             
02d3a020: ldr     x0, [x0, #0x310]                           MS:WejoyService.Singleton`1::get_Instance
02d3a024: bl      #0x2b70db0                                 fn_2b70db0
02d3a028: adrp    x0, #0x6266000                             
02d3a02c: ldr     x0, [x0, #0xe08]                           MS:DG.Tweening.TweenSettingsExtensions::SetDelay
02d3a030: bl      #0x2b70db0                                 fn_2b70db0
02d3a034: adrp    x0, #0x6266000                             
02d3a038: ldr     x0, [x0, #0x880]                           MS:DG.Tweening.TweenSettingsExtensions::SetEase
02d3a03c: bl      #0x2b70db0                                 fn_2b70db0
02d3a040: adrp    x0, #0x6267000                             
02d3a044: ldr     x0, [x0, #0x308]                           S:'+'
02d3a048: bl      #0x2b70db0                                 fn_2b70db0
02d3a04c: mov     w8, #1                                     
02d3a050: strb    w8, [x21, #0x144]                          
02d3a054: mov     x0, x19                                    
02d3a058: mov     x1, xzr                                    
02d3a05c: bl      #0x2cdd6b8                                 UIBase::OnShow
02d3a060: ldr     x0, [x20]                                  M:AdsManager::<OnApplicationPause>b__26_0
02d3a064: bl      #0x3be7218                                 fn_3be7218
02d3a068: cbz     x0, #0x2d3a530                             
02d3a06c: mov     x1, xzr                                    
02d3a070: bl      #0x2c8a7a4                                 AdsManager::ShowCollap
02d3a074: mov     x0, xzr                                    
02d3a078: bl      #0x2d6eec8                                 Framework.AudioManager::get_Instance
02d3a07c: cbz     x0, #0x2d3a530                             
02d3a080: movi    d1, #0000000000000000                      
02d3a084: movi    d2, #0000000000000000                      
02d3a088: mov     w1, #0x30                                  
02d3a08c: fmov    s0, #1.00000000                            
02d3a090: mov     w2, wzr                                    
02d3a094: mov     w3, wzr                                    
02d3a098: mov     x4, xzr                                    
02d3a09c: bl      #0x2d6f03c                                 Framework.AudioManager::PlaySound
02d3a0a0: ldr     x0, [x19, #0x70]                           ._fxConfetti
02d3a0a4: cbz     x0, #0x2d3a530                             
02d3a0a8: mov     x1, xzr                                    
02d3a0ac: bl      #0x5b339ec                                 UnityEngine.Component::get_gameObject
02d3a0b0: cbz     x0, #0x2d3a530                             
02d3a0b4: mov     w1, #1                                     
02d3a0b8: mov     x2, xzr                                    
02d3a0bc: mov     w21, #1                                    
02d3a0c0: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d3a0c4: ldr     x0, [x19, #0x78]                           ._tfTitle
02d3a0c8: mov     w1, wzr                                    
02d3a0cc: mov     x2, xzr                                    
02d3a0d0: bl      #0x2d9d5d0                                 DG.Tweening.ShortcutExtensions::DOKill
02d3a0d4: adrp    x22, #0x662f000                            
02d3a0d8: ldr     x20, [x19, #0x78]                          ._tfTitle
02d3a0dc: ldrb    w8, [x22, #0x91a]                          
02d3a0e0: cbnz    w8, #0x2d3a0f4                             
02d3a0e4: adrp    x0, #0x6264000                             
02d3a0e8: ldr     x0, [x0, #0xd8]                            T:UnityEngine.Vector3
02d3a0ec: bl      #0x2b70db0                                 fn_2b70db0
02d3a0f0: strb    w21, [x22, #0x91a]                         
02d3a0f4: cbz     x20, #0x2d3a530                            
02d3a0f8: adrp    x23, #0x6264000                            
02d3a0fc: adrp    x21, #0x6266000                            
02d3a100: mov     x0, x20                                    
02d3a104: ldr     x23, [x23, #0xd8]                          T:UnityEngine.Vector3
02d3a108: mov     x1, xzr                                    
02d3a10c: ldr     x8, [x23]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d3a110: ldr     x8, [x8, #0xb8]                            
02d3a114: ldr     x21, [x21, #0x880]                         MS:DG.Tweening.TweenSettingsExtensions::SetEase
02d3a118: ldp     s1, s2, [x8, #4]                           
02d3a11c: ldr     s0, [x8]                                   
02d3a120: bl      #0x5b470cc                                 UnityEngine.Transform::set_localScale
02d3a124: adrp    x8, #0x1084000                             
02d3a128: fmov    s0, #1.00000000                            
02d3a12c: ldr     x0, [x19, #0x78]                           ._tfTitle
02d3a130: ldr     s8, [x8, #0xf10]                           [1084f10]=4110bc863e99999a f=0.3,9.04603
02d3a134: mov     x1, xzr                                    
02d3a138: fmov    s1, s8                                     
02d3a13c: bl      #0x2d98c98                                 DG.Tweening.ShortcutExtensions::DOScale
02d3a140: ldr     x2, [x21]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d3a144: mov     w1, #0x1b                                  
02d3a148: bl      #0x336fa0c                                 fn_336fa0c
02d3a14c: ldr     x0, [x19, #0x80]                           ._tfCompliment
02d3a150: mov     w1, wzr                                    
02d3a154: mov     x2, xzr                                    
02d3a158: bl      #0x2d9d5d0                                 DG.Tweening.ShortcutExtensions::DOKill
02d3a15c: ldr     x0, [x19, #0x88]                           ._tfRewardInfo
02d3a160: mov     w1, wzr                                    
02d3a164: mov     x2, xzr                                    
02d3a168: bl      #0x2d9d5d0                                 DG.Tweening.ShortcutExtensions::DOKill
02d3a16c: ldrb    w8, [x22, #0x91a]                          
02d3a170: ldr     x20, [x19, #0x88]                          ._tfRewardInfo
02d3a174: cbnz    w8, #0x2d3a18c                             
02d3a178: adrp    x0, #0x6264000                             
02d3a17c: ldr     x0, [x0, #0xd8]                            T:UnityEngine.Vector3
02d3a180: bl      #0x2b70db0                                 fn_2b70db0
02d3a184: mov     w8, #1                                     
02d3a188: strb    w8, [x22, #0x91a]                          
02d3a18c: cbz     x20, #0x2d3a530                            
02d3a190: ldr     x8, [x23]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d3a194: adrp    x24, #0x6266000                            
02d3a198: mov     x0, x20                                    
02d3a19c: mov     x1, xzr                                    
02d3a1a0: ldr     x8, [x8, #0xb8]                            [10840b8]=2632726f74636556 f=7.20646e+31,6.19112e-16
02d3a1a4: ldr     x24, [x24, #0xe08]                         MS:DG.Tweening.TweenSettingsExtensions::SetDelay
02d3a1a8: ldp     s1, s2, [x8, #4]                           
02d3a1ac: ldr     s0, [x8]                                   [1084000]=287475706e49646c f=1.5582e+28,1.35702e-14
02d3a1b0: bl      #0x5b470cc                                 UnityEngine.Transform::set_localScale
02d3a1b4: fmov    s1, s8                                     
02d3a1b8: fmov    s0, #1.00000000                            
02d3a1bc: ldr     x0, [x19, #0x88]                           ._tfRewardInfo
02d3a1c0: mov     x1, xzr                                    
02d3a1c4: bl      #0x2d98c98                                 DG.Tweening.ShortcutExtensions::DOScale
02d3a1c8: ldr     x2, [x21]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d3a1cc: mov     w1, #0x1b                                  
02d3a1d0: bl      #0x336fa0c                                 fn_336fa0c
02d3a1d4: fmov    s0, #0.75000000                            
02d3a1d8: ldr     x1, [x24]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d3a1dc: bl      #0x336f7fc                                 fn_336f7fc
02d3a1e0: ldr     x0, [x19, #0x90]                           ._tfBtnAdReward
02d3a1e4: mov     w1, wzr                                    
02d3a1e8: mov     x2, xzr                                    
02d3a1ec: bl      #0x2d9d5d0                                 DG.Tweening.ShortcutExtensions::DOKill
02d3a1f0: ldrb    w8, [x22, #0x91a]                          
02d3a1f4: ldr     x20, [x19, #0x90]                          ._tfBtnAdReward
02d3a1f8: cbnz    w8, #0x2d3a210                             
02d3a1fc: adrp    x0, #0x6264000                             
02d3a200: ldr     x0, [x0, #0xd8]                            T:UnityEngine.Vector3
02d3a204: bl      #0x2b70db0                                 fn_2b70db0
02d3a208: mov     w8, #1                                     
02d3a20c: strb    w8, [x22, #0x91a]                          
02d3a210: cbz     x20, #0x2d3a530                            
02d3a214: ldr     x8, [x23]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d3a218: mov     x0, x20                                    
02d3a21c: mov     x1, xzr                                    
02d3a220: ldr     x8, [x8, #0xb8]                            [10840b8]=2632726f74636556 f=7.20646e+31,6.19112e-16
02d3a224: ldp     s1, s2, [x8, #4]                           
02d3a228: ldr     s0, [x8]                                   [1084000]=287475706e49646c f=1.5582e+28,1.35702e-14
02d3a22c: bl      #0x5b470cc                                 UnityEngine.Transform::set_localScale
02d3a230: fmov    s1, s8                                     
02d3a234: fmov    s0, #1.00000000                            
02d3a238: ldr     x0, [x19, #0x90]                           ._tfBtnAdReward
02d3a23c: mov     x1, xzr                                    
02d3a240: bl      #0x2d98c98                                 DG.Tweening.ShortcutExtensions::DOScale
02d3a244: ldr     x2, [x21]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d3a248: mov     w1, #0x1b                                  
02d3a24c: bl      #0x336fa0c                                 fn_336fa0c
02d3a250: fmov    s0, #1.00000000                            
02d3a254: ldr     x1, [x24]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d3a258: bl      #0x336f7fc                                 fn_336f7fc
02d3a25c: ldr     x0, [x19, #0x98]                           ._tfBtnReward
02d3a260: mov     w1, wzr                                    
02d3a264: mov     x2, xzr                                    
02d3a268: bl      #0x2d9d5d0                                 DG.Tweening.ShortcutExtensions::DOKill
02d3a26c: ldrb    w8, [x22, #0x91a]                          
02d3a270: ldr     x20, [x19, #0x98]                          ._tfBtnReward
02d3a274: cbnz    w8, #0x2d3a28c                             
02d3a278: adrp    x0, #0x6264000                             
02d3a27c: ldr     x0, [x0, #0xd8]                            T:UnityEngine.Vector3
02d3a280: bl      #0x2b70db0                                 fn_2b70db0
02d3a284: mov     w8, #1                                     
02d3a288: strb    w8, [x22, #0x91a]                          
02d3a28c: cbz     x20, #0x2d3a530                            
02d3a290: ldr     x8, [x23]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d3a294: adrp    x22, #0x6267000                            
02d3a298: mov     x0, x20                                    
02d3a29c: mov     x1, xzr                                    
02d3a2a0: ldr     x8, [x8, #0xb8]                            [10840b8]=2632726f74636556 f=7.20646e+31,6.19112e-16
02d3a2a4: ldr     x22, [x22, #0x308]                         S:'+'
02d3a2a8: ldp     s1, s2, [x8, #4]                           
02d3a2ac: ldr     s0, [x8]                                   [1084000]=287475706e49646c f=1.5582e+28,1.35702e-14
02d3a2b0: bl      #0x5b470cc                                 UnityEngine.Transform::set_localScale
02d3a2b4: fmov    s1, s8                                     
02d3a2b8: fmov    s0, #1.00000000                            
02d3a2bc: ldr     x0, [x19, #0x98]                           ._tfBtnReward
02d3a2c0: mov     x1, xzr                                    
02d3a2c4: bl      #0x2d98c98                                 DG.Tweening.ShortcutExtensions::DOScale
02d3a2c8: ldr     x2, [x21]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d3a2cc: mov     w1, #0x1b                                  
02d3a2d0: bl      #0x336fa0c                                 fn_336fa0c
02d3a2d4: fmov    s0, #1.50000000                            
02d3a2d8: ldr     x1, [x24]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d3a2dc: bl      #0x336f7fc                                 fn_336f7fc
02d3a2e0: ldr     x20, [x19, #0x60]                          ._txtEarnings
02d3a2e4: add     x0, x19, #0xa0                             
02d3a2e8: mov     x1, xzr                                    
02d3a2ec: bl      #0x4e0ea3c                                 System.Int32::ToString
02d3a2f0: ldr     x8, [x22]                                  S:'didu'
02d3a2f4: mov     x1, x0                                     
02d3a2f8: mov     x2, xzr                                    
02d3a2fc: mov     x0, x8                                     
02d3a300: bl      #0x4c9c514                                 System.String::Concat
02d3a304: cbz     x20, #0x2d3a530                            
02d3a308: ldr     x8, [x20]                                  M:AdsManager::<OnApplicationPause>b__26_0
02d3a30c: mov     x1, x0                                     
02d3a310: mov     x0, x20                                    
02d3a314: ldr     x9, [x8, #0x558]                           [1084558]=5500292632726f74 f=1.41116e-08,8.80714e+12
02d3a318: ldr     x2, [x8, #0x560]                           [1084560]=69676e457974696e f=7.93162e+34,1.74864e+25
02d3a31c: blr     x9                                         
02d3a320: ldr     x20, [x19, #0x68]                          ._txtTips
02d3a324: add     x0, x19, #0xa4                             
02d3a328: mov     x1, xzr                                    
02d3a32c: bl      #0x4e0ea3c                                 System.Int32::ToString
02d3a330: ldr     x8, [x22]                                  S:'didu'
02d3a334: mov     x1, x0                                     
02d3a338: mov     x2, xzr                                    
02d3a33c: mov     x0, x8                                     
02d3a340: bl      #0x4c9c514                                 System.String::Concat
02d3a344: cbz     x20, #0x2d3a530                            
02d3a348: ldr     x8, [x20]                                  M:AdsManager::<OnApplicationPause>b__26_0
02d3a34c: adrp    x21, #0x6266000                            
02d3a350: mov     x1, x0                                     
02d3a354: ldr     x21, [x21, #0x658]                         MS:MonoSingleton`1::get_Instance
02d3a358: mov     x0, x20                                    
02d3a35c: ldr     x9, [x8, #0x558]                           [1084558]=5500292632726f74 f=1.41116e-08,8.80714e+12
02d3a360: ldr     x2, [x8, #0x560]                           [1084560]=69676e457974696e f=7.93162e+34,1.74864e+25
02d3a364: blr     x9                                         
02d3a368: ldr     x0, [x21]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d3a36c: bl      #0x3769600                                 fn_3769600
02d3a370: cbz     x0, #0x2d3a530                             
02d3a374: adrp    x8, #0x6266000                             
02d3a378: ldr     x8, [x8, #0x750]                           MS:DataManager::GetData
02d3a37c: ldr     x1, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d3a380: bl      #0x3168dd0                                 fn_3168dd0
02d3a384: cbz     x0, #0x2d3a530                             
02d3a388: ldr     x8, [x0, #0x20]                            T:DG.Tweening.DOTweenModulePhysics/<>c__DisplayClass0_0
02d3a38c: cbz     x8, #0x2d3a530                             
02d3a390: ldr     w9, [x8, #0x50]                            S:'native_fullscreen_on_off'
02d3a394: adrp    x21, #0x6266000                            
02d3a398: add     w9, w9, #1                                 
02d3a39c: str     w9, [x8, #0x50]                            
02d3a3a0: ldr     x8, [x0]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d3a3a4: ldr     x21, [x21, #0xac0]                         MS:MonoSingleton`1::get_Instance
02d3a3a8: ldr     x9, [x8, #0x258]                           MS:System.Collections.Generic.List`1/Enumerator::Dispose
02d3a3ac: ldr     x1, [x8, #0x260]                           MS:System.Collections.Generic.List`1/Enumerator::MoveNext
02d3a3b0: blr     x9                                         
02d3a3b4: ldr     x0, [x21]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d3a3b8: bl      #0x3769600                                 fn_3769600
02d3a3bc: cbz     x0, #0x2d3a530                             
02d3a3c0: adrp    x8, #0x6263000                             
02d3a3c4: ldr     x8, [x8, #0x918]                           T:UnityEngine.Object
02d3a3c8: ldr     x20, [x0, #0x68]                           M:DG.Tweening.DOTweenModulePhysics/<>c__DisplayClass2_0::<DOMoveY>b__0 ._txtTips
02d3a3cc: ldr     x8, [x8]                                   &2c5bbd4(=a9bd7bfdd503233f)
02d3a3d0: ldr     w9, [x8, #0xe4]                            [62630e4]=0 f=0,0
02d3a3d4: cbnz    w9, #0x2d3a3e0                             
02d3a3d8: mov     x0, x8                                     
02d3a3dc: bl      #0x2b70f30                                 fn_2b70f30
02d3a3e0: mov     x0, x20                                    
02d3a3e4: mov     x1, xzr                                    
02d3a3e8: mov     x2, xzr                                    
02d3a3ec: bl      #0x5b3666c                                 UnityEngine.Object::op_Inequality
02d3a3f0: tbz     w0, #0, #0x2d3a418                         
02d3a3f4: ldr     x0, [x21]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d3a3f8: ldr     x19, [x19, #0x48]                          ._imgCustomer
02d3a3fc: bl      #0x3769600                                 fn_3769600
02d3a400: cbz     x0, #0x2d3a530                             
02d3a404: cbz     x19, #0x2d3a530                            
02d3a408: ldr     x1, [x0, #0x68]                            M:DG.Tweening.DOTweenModulePhysics/<>c__DisplayClass2_0::<DOMoveY>b__0 ._txtTips
02d3a40c: mov     x0, x19                                    
02d3a410: mov     x2, xzr                                    
02d3a414: bl      #0x5c45aa0                                 UnityEngine.UI.Image::set_sprite
02d3a418: adrp    x8, #0x6267000                             
02d3a41c: ldr     x8, [x8, #0xd20]                           MS:MonoSingleton`1::get_Instance
02d3a420: ldr     x0, [x8]                                   S:'didu'
02d3a424: bl      #0x3769600                                 fn_3769600
02d3a428: cbz     x0, #0x2d3a530                             
02d3a42c: adrp    x23, #0x6266000                            
02d3a430: mov     x1, xzr                                    
02d3a434: ldr     x23, [x23, #0xb48]                         MS:MonoSingleton`1::get_Instance
02d3a438: bl      #0x2cf4100                                 Profile.ProfileManager::ObtainExperiencePoint
02d3a43c: ldr     x0, [x23]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d3a440: bl      #0x3769600                                 fn_3769600
02d3a444: cbz     x0, #0x2d3a530                             
02d3a448: ldr     x19, [x0, #0x30]                           T:type8556(k15)
02d3a44c: ldr     x0, [x23]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d3a450: bl      #0x3769600                                 fn_3769600
02d3a454: cbz     x0, #0x2d3a530                             
02d3a458: adrp    x24, #0x6265000                            
02d3a45c: mov     x8, x0                                     
02d3a460: ldr     x24, [x24, #0xb38]                         T:DevTrack
02d3a464: ldr     w20, [x8, #0x3c]                           [626703c]=0 f=0,0
02d3a468: ldr     x0, [x24]                                  M:AdsManager::<OnApplicationPause>b__26_0
02d3a46c: ldr     w9, [x0, #0xe4]                            [62640e4]=0 f=0,0
02d3a470: cbnz    w9, #0x2d3a47c                             
02d3a474: bl      #0x2b70f30                                 fn_2b70f30
02d3a478: ldr     x0, [x24]                                  M:AdsManager::<OnApplicationPause>b__26_0
02d3a47c: ldr     x8, [x0, #0xb8]                            MS:DG.Tweening.Core.Extensions::SetSpecialStartupMode
02d3a480: mov     x0, xzr                                    
02d3a484: ldr     x21, [x8, #0x2c0]                          T:UnityEngine.GUI
02d3a488: ldr     w22, [x8, #0x2e0]                          MS:UnityEngine.Events.UnityEvent`1::Invoke
02d3a48c: bl      #0x5b432fc                                 UnityEngine.Time::get_time
02d3a490: ldr     x0, [x23]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d3a494: fmov    s8, s0                                     
02d3a498: bl      #0x3769600                                 fn_3769600
02d3a49c: cbz     x0, #0x2d3a530                             
02d3a4a0: ldr     s0, [x0, #0x38]                            M:UnityEngine.Rigidbody::MovePosition ._btnAdReward
02d3a4a4: mov     x0, x19                                    
02d3a4a8: mov     w1, w20                                    
02d3a4ac: mov     x2, x21                                    
02d3a4b0: mov     w3, w22                                    
02d3a4b4: mov     x4, xzr                                    
02d3a4b8: fsub    s0, s8, s0                                 
02d3a4bc: bl      #0x2c9c898                                 DevTrack::GameModeStepComplete
02d3a4c0: ldr     x0, [x23]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d3a4c4: bl      #0x3769600                                 fn_3769600
02d3a4c8: cbz     x0, #0x2d3a530                             
02d3a4cc: ldr     x19, [x0, #0x30]                           T:type8556(k15)
02d3a4d0: ldr     x0, [x23]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d3a4d4: bl      #0x3769600                                 fn_3769600
02d3a4d8: cbz     x0, #0x2d3a530                             
02d3a4dc: ldr     x8, [x24]                                  M:AdsManager::<OnApplicationPause>b__26_0
02d3a4e0: ldr     w1, [x0, #0x3c]                            [626403c]=0 f=0,0
02d3a4e4: mov     x0, x19                                    
02d3a4e8: mov     x4, xzr                                    
02d3a4ec: ldr     x8, [x8, #0xb8]                            M:Framework.SceneUtils/<CRUnloadSceneAsync>d__2::System.Collections.IEnumerator.Reset
02d3a4f0: ldr     x2, [x8, #0x2c8]                           S:'FPS: '
02d3a4f4: ldr     w3, [x8, #0x2e4]                           [62672e4]=0 f=0,0
02d3a4f8: bl      #0x2c9c714                                 DevTrack::GameModeStepEnter
02d3a4fc: ldr     x0, [x23]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d3a500: bl      #0x3769600                                 fn_3769600
02d3a504: cbz     x0, #0x2d3a530                             
02d3a508: ldr     x8, [x24]                                  M:AdsManager::<OnApplicationPause>b__26_0
02d3a50c: ldp     x20, x19, [sp, #0x30]                      
02d3a510: ldp     x22, x21, [sp, #0x20]                      
02d3a514: ldr     x30, [sp, #8]                              
02d3a518: ldr     x8, [x8, #0xb8]                            M:Framework.SceneUtils/<CRUnloadSceneAsync>d__2::System.Collections.IEnumerator.Reset
02d3a51c: ldp     x24, x23, [sp, #0x10]                      
02d3a520: ldr     x1, [x8, #0x2c8]                           S:'FPS: '
02d3a524: str     x1, [x0, #0x40]!                           ._btnReward
02d3a528: ldr     d8, [sp], #0x40                            
02d3a52c: b       #0x2b70d54                                 
02d3a530: bl      #0x2b7105c                                 fn_2b7105c
## OnHide() -> void
---- BlindBagCollection.CollectionCompletePopup::OnHide 0x2d3a534
02d3a534: stp     x30, x19, [sp, #-0x10]!                    
02d3a538: mov     x1, xzr                                    
02d3a53c: mov     x19, x0                                    
02d3a540: bl      #0x2cddc10                                 UIBase::OnHide
02d3a544: ldr     x0, [x19, #0x70]                           ._fxConfetti
02d3a548: cbz     x0, #0x2d3a578                             
02d3a54c: mov     x1, xzr                                    
02d3a550: bl      #0x4f871ec                                 AssetKits.ParticleImage.ParticleImage::Stop
02d3a554: ldr     x0, [x19, #0x70]                           ._fxConfetti
02d3a558: cbz     x0, #0x2d3a578                             
02d3a55c: mov     x1, xzr                                    
02d3a560: bl      #0x5b339ec                                 UnityEngine.Component::get_gameObject
02d3a564: cbz     x0, #0x2d3a578                             
02d3a568: mov     w1, wzr                                    
02d3a56c: mov     x2, xzr                                    
02d3a570: ldp     x30, x19, [sp], #0x10                      
02d3a574: b       #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d3a578: bl      #0x2b7105c                                 fn_2b7105c
## OnBtnRewardClick() -> void
---- BlindBagCollection.CollectionCompletePopup::OnBtnRewardClick 0x2d3a57c
02d3a57c: stp     x30, x25, [sp, #-0x40]!                    
02d3a580: stp     x24, x23, [sp, #0x10]                      
02d3a584: stp     x22, x21, [sp, #0x20]                      
02d3a588: stp     x20, x19, [sp, #0x30]                      
02d3a58c: adrp    x20, #0x6630000                            
02d3a590: adrp    x21, #0x626a000                            
02d3a594: mov     x19, x0                                    
02d3a598: ldrb    w8, [x20, #0x145]                          
02d3a59c: ldr     x21, [x21, #0xc98]                         T:BlindBagCollection.CollectionCompletePopup/<>c__DisplayClass18_0
02d3a5a0: tbnz    w8, #0, #0x2d3a5f4                         
02d3a5a4: adrp    x0, #0x6264000                             
02d3a5a8: ldr     x0, [x0, #0xf90]                           T:System.Action
02d3a5ac: bl      #0x2b70db0                                 fn_2b70db0
02d3a5b0: adrp    x0, #0x6266000                             
02d3a5b4: ldr     x0, [x0, #0x750]                           MS:DataManager::GetData
02d3a5b8: bl      #0x2b70db0                                 fn_2b70db0
02d3a5bc: adrp    x0, #0x6266000                             
02d3a5c0: ldr     x0, [x0, #0xaa0]                           MS:MonoSingleton`1::get_Instance
02d3a5c4: bl      #0x2b70db0                                 fn_2b70db0
02d3a5c8: adrp    x0, #0x6266000                             
02d3a5cc: ldr     x0, [x0, #0x658]                           MS:MonoSingleton`1::get_Instance
02d3a5d0: bl      #0x2b70db0                                 fn_2b70db0
02d3a5d4: adrp    x0, #0x626a000                             
02d3a5d8: ldr     x0, [x0, #0xca0]                           M:BlindBagCollection.CollectionCompletePopup/<>c__DisplayClass18_0::<OnBtnRewardClick>b__0
02d3a5dc: bl      #0x2b70db0                                 fn_2b70db0
02d3a5e0: adrp    x0, #0x626a000                             
02d3a5e4: ldr     x0, [x0, #0xc98]                           T:BlindBagCollection.CollectionCompletePopup/<>c__DisplayClass18_0
02d3a5e8: bl      #0x2b70db0                                 fn_2b70db0
02d3a5ec: mov     w8, #1                                     
02d3a5f0: strb    w8, [x20, #0x145]                          
02d3a5f4: ldr     x0, [x21]                                  T:type56879(k15)
02d3a5f8: bl      #0x2b7104c                                 fn_2b7104c
02d3a5fc: mov     x1, xzr                                    
02d3a600: mov     x20, x0                                    
02d3a604: bl      #0x4e53e9c                                 System.Object::.ctor
02d3a608: mov     x0, xzr                                    
02d3a60c: bl      #0x2d6eec8                                 Framework.AudioManager::get_Instance
02d3a610: cbz     x0, #0x2d3a744                             
02d3a614: movi    d1, #0000000000000000                      
02d3a618: movi    d2, #0000000000000000                      
02d3a61c: mov     w1, #1                                     
02d3a620: fmov    s0, #1.00000000                            
02d3a624: mov     w2, wzr                                    
02d3a628: mov     w3, wzr                                    
02d3a62c: mov     x4, xzr                                    
02d3a630: bl      #0x2d6f03c                                 Framework.AudioManager::PlaySound
02d3a634: ldr     x0, [x19, #0x38]                           ._btnAdReward
02d3a638: cbz     x0, #0x2d3a744                             
02d3a63c: mov     w1, wzr                                    
02d3a640: mov     x2, xzr                                    
02d3a644: bl      #0x5e662d4                                 UnityEngine.UI.Selectable::set_interactable
02d3a648: ldr     x0, [x19, #0x40]                           ._btnReward
02d3a64c: cbz     x0, #0x2d3a744                             
02d3a650: adrp    x21, #0x6266000                            
02d3a654: mov     w1, wzr                                    
02d3a658: mov     x2, xzr                                    
02d3a65c: ldr     x21, [x21, #0x658]                         MS:MonoSingleton`1::get_Instance
02d3a660: bl      #0x5e662d4                                 UnityEngine.UI.Selectable::set_interactable
02d3a664: ldr     x0, [x21]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d3a668: bl      #0x3769600                                 fn_3769600
02d3a66c: cbz     x0, #0x2d3a744                             
02d3a670: adrp    x8, #0x6266000                             
02d3a674: ldr     x8, [x8, #0x750]                           MS:DataManager::GetData
02d3a678: ldr     x1, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d3a67c: bl      #0x3168dd0                                 fn_3168dd0
02d3a680: cbz     x20, #0x2d3a744                            
02d3a684: mov     x21, x20                                   
02d3a688: mov     x1, x0                                     
02d3a68c: str     x0, [x21, #0x10]!                          
02d3a690: mov     x0, x21                                    
02d3a694: bl      #0x2b70d54                                 fn_2b70d54
02d3a698: ldr     x0, [x21]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d3a69c: cbz     x0, #0x2d3a744                             
02d3a6a0: ldr     x8, [x0, #0x20]                            M:Decor.DataDecor/<>c__DisplayClass8_0::<NewData>b__0
02d3a6a4: cbz     x8, #0x2d3a744                             
02d3a6a8: ldr     w9, [x8, #0x3c]                            [626603c]=0 f=0,0
02d3a6ac: adrp    x21, #0x6266000                            
02d3a6b0: adrp    x24, #0x6264000                            
02d3a6b4: ldr     x21, [x21, #0xaa0]                         MS:MonoSingleton`1::get_Instance
02d3a6b8: adrp    x25, #0x626a000                            
02d3a6bc: add     w10, w9, #1                                
02d3a6c0: cmp     w10, #4                                    
02d3a6c4: mov     w10, #4                                    
02d3a6c8: csinc   w9, w10, w9, ge                            
02d3a6cc: str     w9, [x8, #0x3c]                            
02d3a6d0: ldr     x24, [x24, #0xf90]                         T:System.Action
02d3a6d4: ldr     x8, [x0]                                   T:type56879(k15)
02d3a6d8: ldr     x25, [x25, #0xca0]                         M:BlindBagCollection.CollectionCompletePopup/<>c__DisplayClass18_0::<OnBtnRewardClick>b__0
02d3a6dc: ldr     x9, [x8, #0x258]                           MS:System.Collections.Generic.List`1/Enumerator::Dispose
02d3a6e0: ldr     x1, [x8, #0x260]                           MS:System.Collections.Generic.List`1/Enumerator::MoveNext
02d3a6e4: blr     x9                                         
02d3a6e8: ldr     x0, [x21]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d3a6ec: bl      #0x3769600                                 fn_3769600
02d3a6f0: ldr     x8, [x24]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d3a6f4: ldp     w22, w23, [x19, #0xa0]                     ._moneyReward
02d3a6f8: mov     x19, x0                                    
02d3a6fc: mov     x0, x8                                     
02d3a700: bl      #0x2b7104c                                 fn_2b7104c
02d3a704: ldr     x2, [x25]                                  T:type56879(k15)
02d3a708: mov     x1, x20                                    
02d3a70c: mov     x3, xzr                                    
02d3a710: mov     x21, x0                                    
02d3a714: bl      #0x4d8ddbc                                 System.Action::.ctor
02d3a718: cbz     x19, #0x2d3a744                            
02d3a71c: add     w1, w23, w22                               
02d3a720: mov     x0, x19                                    
02d3a724: mov     x3, x21                                    
02d3a728: ldp     x20, x19, [sp, #0x30]                      
02d3a72c: mov     w2, #0xa                                   
02d3a730: ldp     x22, x21, [sp, #0x20]                      
02d3a734: mov     x4, xzr                                    
02d3a738: ldp     x24, x23, [sp, #0x10]                      
02d3a73c: ldp     x30, x25, [sp], #0x40                      
02d3a740: b       #0x2cdaf30                                 MoneyManager::CollectMoney
02d3a744: bl      #0x2b7105c                                 fn_2b7105c
## OnBtnAdRewardClick() -> void
---- BlindBagCollection.CollectionCompletePopup::OnBtnAdRewardClick 0x2d3a750
02d3a750: str     x30, [sp, #-0x30]!                         
02d3a754: stp     x22, x21, [sp, #0x10]                      
02d3a758: stp     x20, x19, [sp, #0x20]                      
02d3a75c: adrp    x20, #0x6630000                            
02d3a760: mov     x19, x0                                    
02d3a764: ldrb    w8, [x20, #0x146]                          
02d3a768: tbnz    w8, #0, #0x2d3a7a4                         
02d3a76c: adrp    x0, #0x6264000                             
02d3a770: ldr     x0, [x0, #0xf90]                           T:System.Action
02d3a774: bl      #0x2b70db0                                 fn_2b70db0
02d3a778: adrp    x0, #0x626a000                             
02d3a77c: ldr     x0, [x0, #0xca8]                           M:BlindBagCollection.CollectionCompletePopup::<OnBtnAdRewardClick>b__19_0
02d3a780: bl      #0x2b70db0                                 fn_2b70db0
02d3a784: adrp    x0, #0x6265000                             
02d3a788: ldr     x0, [x0, #0x310]                           MS:WejoyService.Singleton`1::get_Instance
02d3a78c: bl      #0x2b70db0                                 fn_2b70db0
02d3a790: adrp    x0, #0x626a000                             
02d3a794: ldr     x0, [x0, #0xcb0]                           S:'x2_reward'
02d3a798: bl      #0x2b70db0                                 fn_2b70db0
02d3a79c: mov     w8, #1                                     
02d3a7a0: strb    w8, [x20, #0x146]                          
02d3a7a4: mov     x0, xzr                                    
02d3a7a8: bl      #0x2d6eec8                                 Framework.AudioManager::get_Instance
02d3a7ac: cbz     x0, #0x2d3a840                             
02d3a7b0: movi    d1, #0000000000000000                      
02d3a7b4: movi    d2, #0000000000000000                      
02d3a7b8: adrp    x20, #0x6265000                            
02d3a7bc: fmov    s0, #1.00000000                            
02d3a7c0: adrp    x21, #0x6264000                            
02d3a7c4: adrp    x22, #0x626a000                            
02d3a7c8: ldr     x20, [x20, #0x310]                         MS:WejoyService.Singleton`1::get_Instance
02d3a7cc: ldr     x21, [x21, #0xf90]                         T:System.Action
02d3a7d0: ldr     x22, [x22, #0xca8]                         M:BlindBagCollection.CollectionCompletePopup::<OnBtnAdRewardClick>b__19_0
02d3a7d4: mov     w1, #1                                     
02d3a7d8: mov     w2, wzr                                    
02d3a7dc: mov     w3, wzr                                    
02d3a7e0: mov     x4, xzr                                    
02d3a7e4: bl      #0x2d6f03c                                 Framework.AudioManager::PlaySound
02d3a7e8: ldr     x0, [x20]                                  M:AdsManager::<OnApplicationPause>b__26_0
02d3a7ec: bl      #0x3be7218                                 fn_3be7218
02d3a7f0: ldr     x8, [x21]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d3a7f4: mov     x20, x0                                    
02d3a7f8: mov     x0, x8                                     
02d3a7fc: bl      #0x2b7104c                                 fn_2b7104c
02d3a800: ldr     x2, [x22]                                  T:type56879(k15)
02d3a804: mov     x1, x19                                    
02d3a808: mov     x3, xzr                                    
02d3a80c: mov     x21, x0                                    
02d3a810: bl      #0x4d8ddbc                                 System.Action::.ctor
02d3a814: cbz     x20, #0x2d3a840                            
02d3a818: adrp    x8, #0x626a000                             
02d3a81c: mov     x0, x20                                    
02d3a820: mov     x2, x21                                    
02d3a824: ldr     x8, [x8, #0xcb0]                           S:'x2_reward'
02d3a828: ldp     x20, x19, [sp, #0x20]                      
02d3a82c: ldp     x22, x21, [sp, #0x10]                      
02d3a830: mov     x3, xzr                                    
02d3a834: ldr     x1, [x8]                                   T:type56879(k15)
02d3a838: ldr     x30, [sp], #0x30                           
02d3a83c: b       #0x2c8a2c0                                 AdsManager::ShowRewarded
02d3a840: bl      #0x2b7105c                                 fn_2b7105c
## .ctor() -> void
---- BlindBagCollection.CollectionCompletePopup::.ctor 0x2d3a844
02d3a844: adrp    x8, #0x1041000                             
02d3a848: mov     x1, xzr                                    
02d3a84c: ldr     d0, [x8, #0x18]                            [1041018]=64000001f4 f=7.00649e-43,1.4013e-43
02d3a850: str     d0, [x0, #0xa0]                            ._moneyReward
02d3a854: b       #0x2cddba8                                 PopupBase::.ctor
## <OnBtnAdRewardClick>b__19_0() -> void
---- BlindBagCollection.CollectionCompletePopup::<OnBtnAdRewardClick>b__19_0 0x2d3a858
02d3a858: str     x30, [sp, #-0x40]!                         
02d3a85c: stp     x24, x23, [sp, #0x10]                      
02d3a860: stp     x22, x21, [sp, #0x20]                      
02d3a864: stp     x20, x19, [sp, #0x30]                      
02d3a868: adrp    x20, #0x6630000                            
02d3a86c: mov     x19, x0                                    
02d3a870: ldrb    w8, [x20, #0x147]                          
02d3a874: tbnz    w8, #0, #0x2d3a8b0                         
02d3a878: adrp    x0, #0x6264000                             
02d3a87c: ldr     x0, [x0, #0xf90]                           T:System.Action
02d3a880: bl      #0x2b70db0                                 fn_2b70db0
02d3a884: adrp    x0, #0x6266000                             
02d3a888: ldr     x0, [x0, #0xaa0]                           MS:MonoSingleton`1::get_Instance
02d3a88c: bl      #0x2b70db0                                 fn_2b70db0
02d3a890: adrp    x0, #0x626a000                             
02d3a894: ldr     x0, [x0, #0xcb8]                           M:BlindBagCollection.CollectionCompletePopup/<>c::<OnBtnAdRewardClick>b__19_1
02d3a898: bl      #0x2b70db0                                 fn_2b70db0
02d3a89c: adrp    x0, #0x626a000                             
02d3a8a0: ldr     x0, [x0, #0xcc0]                           T:BlindBagCollection.CollectionCompletePopup/<>c
02d3a8a4: bl      #0x2b70db0                                 fn_2b70db0
02d3a8a8: mov     w8, #1                                     
02d3a8ac: strb    w8, [x20, #0x147]                          
02d3a8b0: ldr     x0, [x19, #0x38]                           ._btnAdReward
02d3a8b4: cbz     x0, #0x2d3a9a8                             
02d3a8b8: mov     w1, wzr                                    
02d3a8bc: mov     x2, xzr                                    
02d3a8c0: bl      #0x5e662d4                                 UnityEngine.UI.Selectable::set_interactable
02d3a8c4: ldr     x0, [x19, #0x40]                           ._btnReward
02d3a8c8: cbz     x0, #0x2d3a9a8                             
02d3a8cc: adrp    x20, #0x6266000                            
02d3a8d0: adrp    x22, #0x626a000                            
02d3a8d4: mov     w1, wzr                                    
02d3a8d8: ldr     x20, [x20, #0xaa0]                         MS:MonoSingleton`1::get_Instance
02d3a8dc: ldr     x22, [x22, #0xcc0]                         T:BlindBagCollection.CollectionCompletePopup/<>c
02d3a8e0: mov     x2, xzr                                    
02d3a8e4: bl      #0x5e662d4                                 UnityEngine.UI.Selectable::set_interactable
02d3a8e8: ldr     x0, [x20]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d3a8ec: bl      #0x3769600                                 fn_3769600
02d3a8f0: ldr     x8, [x22]                                  T:type56879(k15)
02d3a8f4: ldp     w23, w24, [x19, #0xa0]                     ._moneyReward
02d3a8f8: ldr     w9, [x8, #0xe4]                            
02d3a8fc: mov     x19, x0                                    
02d3a900: cbnz    w9, #0x2d3a910                             
02d3a904: mov     x0, x8                                     
02d3a908: bl      #0x2b70f30                                 fn_2b70f30
02d3a90c: ldr     x8, [x22]                                  T:type56879(k15)
02d3a910: ldr     x9, [x8, #0xb8]                            
02d3a914: ldr     x20, [x9, #0x10]                           
02d3a918: cbnz    x20, #0x2d3a978                            
02d3a91c: ldr     w10, [x8, #0xe4]                           
02d3a920: cbnz    w10, #0x2d3a934                            
02d3a924: mov     x0, x8                                     
02d3a928: bl      #0x2b70f30                                 fn_2b70f30
02d3a92c: ldr     x8, [x22]                                  T:type56879(k15)
02d3a930: ldr     x9, [x8, #0xb8]                            
02d3a934: adrp    x8, #0x6264000                             
02d3a938: ldr     x8, [x8, #0xf90]                           T:System.Action
02d3a93c: ldr     x21, [x9]                                  
02d3a940: ldr     x0, [x8]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d3a944: bl      #0x2b7104c                                 fn_2b7104c
02d3a948: adrp    x8, #0x626a000                             
02d3a94c: mov     x1, x21                                    
02d3a950: mov     x3, xzr                                    
02d3a954: ldr     x8, [x8, #0xcb8]                           M:BlindBagCollection.CollectionCompletePopup/<>c::<OnBtnAdRewardClick>b__19_1
02d3a958: mov     x20, x0                                    
02d3a95c: ldr     x2, [x8]                                   T:type56879(k15)
02d3a960: bl      #0x4d8ddbc                                 System.Action::.ctor
02d3a964: ldr     x8, [x22]                                  T:type56879(k15)
02d3a968: mov     x1, x20                                    
02d3a96c: ldr     x0, [x8, #0xb8]                            MS:UnityEngine.Object::FindObjectsOfType
02d3a970: str     x20, [x0, #0x10]!                          
02d3a974: bl      #0x2b70d54                                 fn_2b70d54
02d3a978: cbz     x19, #0x2d3a9a8                            
02d3a97c: add     w8, w24, w23                               
02d3a980: mov     x0, x19                                    
02d3a984: mov     x3, x20                                    
02d3a988: ldp     x20, x19, [sp, #0x30]                      
02d3a98c: lsl     w1, w8, #1                                 
02d3a990: ldp     x22, x21, [sp, #0x20]                      
02d3a994: mov     w2, #0xa                                   
02d3a998: ldp     x24, x23, [sp, #0x10]                      
02d3a99c: mov     x4, xzr                                    
02d3a9a0: ldr     x30, [sp], #0x40                           
02d3a9a4: b       #0x2cdaf30                                 MoneyManager::CollectMoney
02d3a9a8: bl      #0x2b7105c                                 fn_2b7105c
