#### CLASS InGameScreen parent= ScreenBase
## .ctor() -> void
---- InGameScreen::.ctor 0x2ce0388
02ce0388: mov     x1, xzr                                    
02ce038c: b       #0x5b397b0                                 UnityEngine.MonoBehaviour::.ctor
