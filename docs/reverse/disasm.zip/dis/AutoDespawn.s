#### CLASS AutoDespawn parent= PoolElement
#   field timeLife                       float                                              off=0x28 attr=1 SerializeField
## OnEnable() -> void
---- AutoDespawn::OnEnable 0x2cdc2d8
02cdc2d8: ldr     s0, [x0, #0x28]                            .timeLife
02cdc2dc: b       #0x2cdc2e0                                 PoolElement::DespawnSelf
## .ctor() -> void
---- AutoDespawn::.ctor 0x2cdc388
02cdc388: mov     w8, #0xcccd                                
02cdc38c: mov     x1, xzr                                    
02cdc390: movk    w8, #0x3e4c, lsl #16                       
02cdc394: str     w8, [x0, #0x28]                            .timeLife
02cdc398: b       #0x5b397b0                                 UnityEngine.MonoBehaviour::.ctor
