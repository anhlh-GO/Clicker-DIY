#### CLASS IAPBundleRewardSO/<>c__DisplayClass1_0 parent= object
#   field productId                      IAPKey                                             off=0x10 attr=6 
## .ctor() -> void
---- IAPBundleRewardSO/<>c__DisplayClass1_0::.ctor 0x2ca4978
02ca4978: mov     x1, xzr                                    
02ca497c: b       #0x4e53e9c                                 System.Object::.ctor
## <GetRewardBundle>b__0(IAPRewardBundle bundle) -> bool
---- IAPBundleRewardSO/<>c__DisplayClass1_0::<GetRewardBundle>b__0 0x2ca4988
02ca4988: cbz     x1, #0x2ca49a0                             
02ca498c: ldr     w8, [x1, #0x10]                            
02ca4990: ldr     w9, [x0, #0x10]                            .productId
02ca4994: cmp     w8, w9                                     
02ca4998: cset    w0, eq                                     
02ca499c: ret                                                
02ca49a0: str     x30, [sp, #-0x10]!                         
02ca49a4: bl      #0x2b7105c                                 fn_2b7105c
#### CLASS IAPBundleRewardSO parent= UnityEngine.ScriptableObject
#   field RewardBundles                  System.Collections.Generic.List`1<IAPRewardBundle> off=0x18 attr=6 
## GetRewardBundle(IAPKey productId) -> IAPRewardBundle
---- IAPBundleRewardSO::GetRewardBundle 0x2ca48a0
02ca48a0: str     x30, [sp, #-0x30]!                         
02ca48a4: stp     x22, x21, [sp, #0x10]                      
02ca48a8: stp     x20, x19, [sp, #0x20]                      
02ca48ac: adrp    x21, #0x662f000                            
02ca48b0: adrp    x22, #0x6266000                            
02ca48b4: mov     w19, w1                                    
02ca48b8: ldrb    w8, [x21, #0xace]                          
02ca48bc: ldr     x22, [x22, #0x1b0]                         T:IAPBundleRewardSO/<>c__DisplayClass1_0
02ca48c0: mov     x20, x0                                    
02ca48c4: tbnz    w8, #0, #0x2ca4900                         
02ca48c8: adrp    x0, #0x6266000                             
02ca48cc: ldr     x0, [x0, #0x1b8]                           MS:System.Collections.Generic.List`1::Find
02ca48d0: bl      #0x2b70db0                                 fn_2b70db0
02ca48d4: adrp    x0, #0x6266000                             
02ca48d8: ldr     x0, [x0, #0x1c0]                           T:type57248(k15)
02ca48dc: bl      #0x2b70db0                                 fn_2b70db0
02ca48e0: adrp    x0, #0x6266000                             
02ca48e4: ldr     x0, [x0, #0x1c8]                           M:IAPBundleRewardSO/<>c__DisplayClass1_0::<GetRewardBundle>b__0
02ca48e8: bl      #0x2b70db0                                 fn_2b70db0
02ca48ec: adrp    x0, #0x6266000                             
02ca48f0: ldr     x0, [x0, #0x1b0]                           T:IAPBundleRewardSO/<>c__DisplayClass1_0
02ca48f4: bl      #0x2b70db0                                 fn_2b70db0
02ca48f8: mov     w8, #1                                     
02ca48fc: strb    w8, [x21, #0xace]                          
02ca4900: ldr     x0, [x22]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca4904: bl      #0x2b7104c                                 fn_2b7104c
02ca4908: mov     x1, xzr                                    
02ca490c: mov     x21, x0                                    
02ca4910: bl      #0x4e53e9c                                 System.Object::.ctor
02ca4914: cbz     x21, #0x2ca4974                            
02ca4918: adrp    x8, #0x6266000                             
02ca491c: adrp    x22, #0x6266000                            
02ca4920: ldr     x8, [x8, #0x1c0]                           T:type57248(k15)
02ca4924: ldr     x22, [x22, #0x1c8]                         M:IAPBundleRewardSO/<>c__DisplayClass1_0::<GetRewardBundle>b__0
02ca4928: ldr     x20, [x20, #0x18]                          .RewardBundles
02ca492c: str     w19, [x21, #0x10]                          
02ca4930: ldr     x0, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca4934: bl      #0x2b7104c                                 fn_2b7104c
02ca4938: ldr     x2, [x22]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca493c: mov     x1, x21                                    
02ca4940: mov     x3, xzr                                    
02ca4944: mov     x19, x0                                    
02ca4948: bl      #0x399ba10                                 fn_399ba10
02ca494c: cbz     x20, #0x2ca4974                            
02ca4950: adrp    x8, #0x6266000                             
02ca4954: mov     x0, x20                                    
02ca4958: mov     x1, x19                                    
02ca495c: ldr     x8, [x8, #0x1b8]                           MS:System.Collections.Generic.List`1::Find
02ca4960: ldp     x20, x19, [sp, #0x20]                      
02ca4964: ldp     x22, x21, [sp, #0x10]                      
02ca4968: ldr     x2, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca496c: ldr     x30, [sp], #0x30                           
02ca4970: b       #0x35a9868                                 
02ca4974: bl      #0x2b7105c                                 fn_2b7105c
## .ctor() -> void
---- IAPBundleRewardSO::.ctor 0x2ca4980
02ca4980: mov     x1, xzr                                    
02ca4984: b       #0x5b398f0                                 UnityEngine.ScriptableObject::.ctor
