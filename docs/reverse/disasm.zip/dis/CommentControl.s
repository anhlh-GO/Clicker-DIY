#### CLASS CommentControl/<>c parent= object
#   field <>9                            CommentControl/<>c                                 off=0x0 attr=36 
#   field <>9__18_0                      DG.Tweening.TweenCallback                          off=0x8 attr=16 
## .cctor() -> void
---- CommentControl/<>c::.cctor 0x2cb5570
02cb5570: str     x30, [sp, #-0x20]!                         
02cb5574: stp     x20, x19, [sp, #0x10]                      
02cb5578: adrp    x19, #0x662f000                            
02cb557c: adrp    x20, #0x6266000                            
02cb5580: ldrb    w8, [x19, #0xba8]                          
02cb5584: ldr     x20, [x20, #0xca0]                         T:CommentControl/<>c
02cb5588: tbnz    w8, #0, #0x2cb55a0                         
02cb558c: adrp    x0, #0x6266000                             
02cb5590: ldr     x0, [x0, #0xca0]                           T:CommentControl/<>c
02cb5594: bl      #0x2b70db0                                 fn_2b70db0
02cb5598: mov     w8, #1                                     
02cb559c: strb    w8, [x19, #0xba8]                          
02cb55a0: ldr     x0, [x20]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cb55a4: bl      #0x2b7104c                                 fn_2b7104c
02cb55a8: mov     x1, xzr                                    
02cb55ac: mov     x19, x0                                    
02cb55b0: bl      #0x4e53e9c                                 System.Object::.ctor
02cb55b4: ldr     x8, [x20]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cb55b8: mov     x1, x19                                    
02cb55bc: ldr     x8, [x8, #0xb8]                            
02cb55c0: str     x19, [x8]                                  
02cb55c4: ldr     x8, [x20]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cb55c8: ldp     x20, x19, [sp, #0x10]                      
02cb55cc: ldr     x0, [x8, #0xb8]                            
02cb55d0: ldr     x30, [sp], #0x20                           
02cb55d4: b       #0x2b70d54                                 
## .ctor() -> void
---- CommentControl/<>c::.ctor 0x2cb55d8
02cb55d8: mov     x1, xzr                                    
02cb55dc: b       #0x4e53e9c                                 System.Object::.ctor
## <OnDespawn>b__18_0() -> void
---- CommentControl/<>c::<OnDespawn>b__18_0 0x2cb55e0
02cb55e0: ret                                                
#### CLASS CommentControl/<>c__DisplayClass17_0 parent= object
#   field callback                       System.Action                                      off=0x10 attr=6 
## .ctor() -> void
---- CommentControl/<>c__DisplayClass17_0::.ctor 0x2cb5158
02cb5158: mov     x1, xzr                                    
02cb515c: b       #0x4e53e9c                                 System.Object::.ctor
## <OnMoveUp>b__0() -> void
---- CommentControl/<>c__DisplayClass17_0::<OnMoveUp>b__0 0x2cb55e4
02cb55e4: ldr     x8, [x0, #0x10]                            .callback
02cb55e8: cbz     x8, #0x2cb55fc                             
02cb55ec: ldr     x0, [x8, #0x40]                            
02cb55f0: ldr     x1, [x8, #0x28]                            
02cb55f4: ldr     x2, [x8, #0x18]                            
02cb55f8: br      x2                                         
02cb55fc: ret                                                
#### CLASS CommentControl/<>c__DisplayClass22_0 parent= object
#   field callback                       System.Action                                      off=0x10 attr=6 
## .ctor() -> void
---- CommentControl/<>c__DisplayClass22_0::.ctor 0x2cb54f0
02cb54f0: mov     x1, xzr                                    
02cb54f4: b       #0x4e53e9c                                 System.Object::.ctor
## <AnimFadeOut>b__0() -> void
---- CommentControl/<>c__DisplayClass22_0::<AnimFadeOut>b__0 0x2cb5600
02cb5600: ldr     x8, [x0, #0x10]                            .callback
02cb5604: cbz     x8, #0x2cb5618                             
02cb5608: ldr     x0, [x8, #0x40]                            
02cb560c: ldr     x1, [x8, #0x28]                            
02cb5610: ldr     x2, [x8, #0x18]                            
02cb5614: br      x2                                         
02cb5618: ret                                                
#### CLASS CommentControl/<Init>d__16 parent= System.ValueType
#   field <>1__state                     int                                                off=0x10 attr=6 
#   field <>t__builder                   System.Runtime.CompilerServices.AsyncVoidMethodBuilder off=0x18 attr=6 
#   field <>4__this                      CommentControl                                     off=0x38 attr=6 
#   field avatar                         UnityEngine.Sprite                                 off=0x40 attr=6 
#   field <>u__1                         Cysharp.Threading.Tasks.UniTask/Awaiter            off=0x48 attr=1 
## MoveNext() -> void
---- CommentControl/<Init>d__16::MoveNext 0x2cb561c
02cb561c: sub     sp, sp, #0x70                              
02cb5620: stp     x30, x25, [sp, #0x30]                      
02cb5624: stp     x24, x23, [sp, #0x40]                      
02cb5628: stp     x22, x21, [sp, #0x50]                      
02cb562c: stp     x20, x19, [sp, #0x60]                      
02cb5630: adrp    x20, #0x662f000                            
02cb5634: mov     x19, x0                                    
02cb5638: ldrb    w8, [x20, #0xba9]                          
02cb563c: tbnz    w8, #0, #0x2cb566c                         
02cb5640: adrp    x0, #0x6266000                             
02cb5644: ldr     x0, [x0, #0xcc0]                           MS:System.Runtime.CompilerServices.AsyncVoidMethodBuilder::AwaitUnsafeOnCompleted
02cb5648: bl      #0x2b70db0                                 fn_2b70db0
02cb564c: adrp    x0, #0x6266000                             
02cb5650: ldr     x0, [x0, #0x880]                           MS:DG.Tweening.TweenSettingsExtensions::SetEase
02cb5654: bl      #0x2b70db0                                 fn_2b70db0
02cb5658: adrp    x0, #0x6266000                             
02cb565c: ldr     x0, [x0, #0xcc8]                           T:Cysharp.Threading.Tasks.UniTask
02cb5660: bl      #0x2b70db0                                 fn_2b70db0
02cb5664: mov     w8, #1                                     
02cb5668: strb    w8, [x20, #0xba9]                          
02cb566c: stp     xzr, xzr, [sp, #0x10]                      
02cb5670: adrp    x23, #0x6264000                            
02cb5674: ldr     w8, [x19]                                  
02cb5678: ldr     x20, [x19, #0x28]                          
02cb567c: ldr     x23, [x23, #0xd8]                          T:UnityEngine.Vector3
02cb5680: str     wzr, [sp, #8]                              
02cb5684: cbz     w8, #0x2cb5764                             
02cb5688: cbz     x20, #0x2cb5958                            
02cb568c: ldr     x0, [x20, #0x60]                           &2b7072c(=14cc752491004000)
02cb5690: cbz     x0, #0x2cb595c                             
02cb5694: ldr     x1, [x19, #0x30]                           
02cb5698: mov     x2, xzr                                    
02cb569c: bl      #0x5c52f10                                 UnityEngine.UI.Image::set_overrideSprite
02cb56a0: adrp    x22, #0x662f000                            
02cb56a4: ldr     x21, [x20, #0x68]                          [662f068]=6000019 f=2.40742e-35,0
02cb56a8: ldrb    w8, [x22, #0x91a]                          
02cb56ac: cbnz    w8, #0x2cb56c4                             
02cb56b0: adrp    x0, #0x6264000                             
02cb56b4: ldr     x0, [x0, #0xd8]                            T:UnityEngine.Vector3
02cb56b8: bl      #0x2b70db0                                 fn_2b70db0
02cb56bc: mov     w8, #1                                     
02cb56c0: strb    w8, [x22, #0x91a]                          
02cb56c4: cbz     x21, #0x2cb5960                            
02cb56c8: ldr     x8, [x23]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02cb56cc: ldr     x8, [x8, #0xb8]                            
02cb56d0: ldp     s1, s2, [x8, #4]                           
02cb56d4: ldr     s0, [x8]                                   
02cb56d8: mov     x0, x21                                    
02cb56dc: mov     x1, xzr                                    
02cb56e0: bl      #0x5b470cc                                 UnityEngine.Transform::set_localScale
02cb56e4: adrp    x24, #0x6266000                            
02cb56e8: ldr     x24, [x24, #0xcc8]                         T:Cysharp.Threading.Tasks.UniTask
02cb56ec: ldr     x0, [x24]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cb56f0: ldr     w8, [x0, #0xe4]                            [62640e4]=0 f=0,0
02cb56f4: cbnz    w8, #0x2cb56fc                             
02cb56f8: bl      #0x2b70f30                                 fn_2b70f30
02cb56fc: mov     x0, x20                                    
02cb5700: mov     x1, xzr                                    
02cb5704: bl      #0x5447638                                 Cysharp.Threading.Tasks.UniTask::WaitForEndOfFrame
02cb5708: stp     x0, x1, [sp, #0x20]                        
02cb570c: add     x0, sp, #0x20                              
02cb5710: mov     x1, xzr                                    
02cb5714: bl      #0x2b70d54                                 fn_2b70d54
02cb5718: adrp    x25, #0x662f000                            
02cb571c: ldp     x21, x22, [sp, #0x20]                      
02cb5720: ldrb    w8, [x25, #0xbdc]                          
02cb5724: stp     x21, x22, [sp, #0x10]                      
02cb5728: cbnz    w8, #0x2cb5740                             
02cb572c: adrp    x0, #0x6266000                             
02cb5730: ldr     x0, [x0, #0xcc8]                           T:Cysharp.Threading.Tasks.UniTask
02cb5734: bl      #0x2b70db0                                 fn_2b70db0
02cb5738: mov     w8, #1                                     
02cb573c: strb    w8, [x25, #0xbdc]                          
02cb5740: ldr     x0, [x24]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cb5744: ldr     w8, [x0, #0xe4]                            [62660e4]=0 f=0,0
02cb5748: cbnz    w8, #0x2cb5750                             
02cb574c: bl      #0x2b70f30                                 fn_2b70f30
02cb5750: adrp    x24, #0x662f000                            
02cb5754: ldrb    w8, [x24, #0xbdd]                          
02cb5758: cbz     w8, #0x2cb577c                             
02cb575c: cbnz    x21, #0x2cb5794                            
02cb5760: b       #0x2cb57fc                                 
02cb5764: ldur    q0, [x19, #0x38]                           .<>4__this
02cb5768: mov     w8, #-1                                    
02cb576c: stp     xzr, xzr, [x19, #0x38]                     .<>4__this
02cb5770: str     w8, [x19]                                  
02cb5774: str     q0, [sp, #0x10]                            
02cb5778: b       #0x2cb57fc                                 
02cb577c: adrp    x0, #0x6266000                             
02cb5780: ldr     x0, [x0, #0xcd0]                           T:Cysharp.Threading.Tasks.IUniTaskSource
02cb5784: bl      #0x2b70db0                                 fn_2b70db0
02cb5788: mov     w8, #1                                     
02cb578c: strb    w8, [x24, #0xbdd]                          
02cb5790: cbz     x21, #0x2cb57fc                            
02cb5794: adrp    x10, #0x6266000                            
02cb5798: ldr     x8, [x21]                                  
02cb579c: ldr     x10, [x10, #0xcd0]                         T:Cysharp.Threading.Tasks.IUniTaskSource
02cb57a0: ldrh    w9, [x8, #0x12e]                           
02cb57a4: ldr     x1, [x10]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cb57a8: cbz     x9, #0x2cb57cc                             
02cb57ac: ldr     x10, [x8, #0xb0]                           
02cb57b0: add     x10, x10, #8                               &6266008
02cb57b4: ldur    x11, [x10, #-8]                            
02cb57b8: cmp     x11, x1                                    
02cb57bc: b.eq    #0x2cb57dc                                 
02cb57c0: subs    x9, x9, #1                                 
02cb57c4: add     x10, x10, #0x10                            &6266010
02cb57c8: b.ne    #0x2cb57b4                                 
02cb57cc: mov     x0, x21                                    
02cb57d0: mov     w2, wzr                                    
02cb57d4: bl      #0x2baa05c                                 fn_2baa05c
02cb57d8: b       #0x2cb57e8                                 
02cb57dc: ldrsw   x9, [x10]                                  
02cb57e0: add     x8, x8, x9, lsl #4                         
02cb57e4: add     x0, x8, #0x138                             
02cb57e8: ldp     x8, x2, [x0]                               
02cb57ec: mov     x0, x21                                    
02cb57f0: mov     w1, w22                                    
02cb57f4: blr     x8                                         
02cb57f8: cbz     w0, #0x2cb591c                             
02cb57fc: adrp    x21, #0x662f000                            
02cb5800: ldrb    w8, [x21, #0xbde]                          
02cb5804: cbnz    w8, #0x2cb581c                             
02cb5808: adrp    x0, #0x6266000                             
02cb580c: ldr     x0, [x0, #0xcd0]                           T:Cysharp.Threading.Tasks.IUniTaskSource
02cb5810: bl      #0x2b70db0                                 fn_2b70db0
02cb5814: mov     w8, #1                                     
02cb5818: strb    w8, [x21, #0xbde]                          
02cb581c: ldr     x21, [sp, #0x10]                           
02cb5820: cbz     x21, #0x2cb5890                            
02cb5824: adrp    x10, #0x6266000                            
02cb5828: ldr     x8, [x21]                                  &2b706c4(=eb01011ff9400808)
02cb582c: ldr     x10, [x10, #0xcd0]                         T:Cysharp.Threading.Tasks.IUniTaskSource
02cb5830: ldrh    w22, [sp, #0x18]                           
02cb5834: ldrh    w9, [x8, #0x12e]                           
02cb5838: ldr     x1, [x10]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cb583c: cbz     x9, #0x2cb5860                             
02cb5840: ldr     x10, [x8, #0xb0]                           
02cb5844: add     x10, x10, #8                               &6266008
02cb5848: ldur    x11, [x10, #-8]                            
02cb584c: cmp     x11, x1                                    
02cb5850: b.eq    #0x2cb5870                                 
02cb5854: subs    x9, x9, #1                                 
02cb5858: add     x10, x10, #0x10                            &6266010
02cb585c: b.ne    #0x2cb5848                                 
02cb5860: mov     x0, x21                                    
02cb5864: mov     w2, #2                                     
02cb5868: bl      #0x2baa05c                                 fn_2baa05c
02cb586c: b       #0x2cb5880                                 
02cb5870: ldr     w9, [x10]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cb5874: add     w9, w9, #2                                 
02cb5878: add     x8, x8, w9, sxtw #4                        
02cb587c: add     x0, x8, #0x138                             
02cb5880: ldp     x8, x2, [x0]                               
02cb5884: mov     x0, x21                                    
02cb5888: mov     w1, w22                                    
02cb588c: blr     x8                                         
02cb5890: cbz     x20, #0x2cb5954                            
02cb5894: adrp    x21, #0x662f000                            
02cb5898: ldr     x20, [x20, #0x68]                          [662f068]=6000019 f=2.40742e-35,0
02cb589c: ldrb    w8, [x21, #0xa74]                          
02cb58a0: cbnz    w8, #0x2cb58b8                             
02cb58a4: adrp    x0, #0x6264000                             
02cb58a8: ldr     x0, [x0, #0xd8]                            T:UnityEngine.Vector3
02cb58ac: bl      #0x2b70db0                                 fn_2b70db0
02cb58b0: mov     w8, #1                                     
02cb58b4: strb    w8, [x21, #0xa74]                          
02cb58b8: ldr     x8, [x23]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02cb58bc: ldr     x8, [x8, #0xb8]                            
02cb58c0: ldp     s0, s1, [x8, #0xc]                         
02cb58c4: ldr     s2, [x8, #0x14]                            
02cb58c8: adrp    x8, #0x1084000                             
02cb58cc: mov     x0, x20                                    
02cb58d0: mov     x1, xzr                                    
02cb58d4: ldr     s3, [x8, #0xdd8]                           [1084dd8]=3f7333333e4ccccd f=0.2,0.95
02cb58d8: bl      #0x2d98af8                                 DG.Tweening.ShortcutExtensions::DOScale
02cb58dc: adrp    x8, #0x6266000                             
02cb58e0: ldr     x8, [x8, #0x880]                           MS:DG.Tweening.TweenSettingsExtensions::SetEase
02cb58e4: ldr     x2, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cb58e8: mov     w1, #0x1b                                  
02cb58ec: bl      #0x336fa0c                                 fn_336fa0c
02cb58f0: mov     w8, #-2                                    
02cb58f4: mov     x1, xzr                                    
02cb58f8: str     w8, [x19], #8                              
02cb58fc: mov     x0, x19                                    
02cb5900: bl      #0x4d43b50                                 System.Runtime.CompilerServices.AsyncVoidMethodBuilder::SetResult
02cb5904: ldp     x20, x19, [sp, #0x60]                      
02cb5908: ldp     x22, x21, [sp, #0x50]                      
02cb590c: ldp     x24, x23, [sp, #0x40]                      
02cb5910: ldp     x30, x25, [sp, #0x30]                      
02cb5914: add     sp, sp, #0x70                              
02cb5918: ret                                                
02cb591c: ldr     q0, [sp, #0x10]                            
02cb5920: str     wzr, [x19]                                 
02cb5924: stur    q0, [x19, #0x38]                           .<>4__this
02cb5928: add     x0, x19, #0x38                             
02cb592c: mov     x1, xzr                                    
02cb5930: bl      #0x2b70d54                                 fn_2b70d54
02cb5934: adrp    x8, #0x6266000                             
02cb5938: ldr     x8, [x8, #0xcc0]                           MS:System.Runtime.CompilerServices.AsyncVoidMethodBuilder::AwaitUnsafeOnCompleted
02cb593c: ldr     x3, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cb5940: add     x0, x19, #8                                
02cb5944: add     x1, sp, #0x10                              
02cb5948: mov     x2, x19                                    
02cb594c: bl      #0x30c2f98                                 fn_30c2f98
02cb5950: b       #0x2cb5904                                 
02cb5954: bl      #0x2b7105c                                 fn_2b7105c
02cb5958: bl      #0x2b7105c                                 fn_2b7105c
02cb595c: bl      #0x2b7105c                                 fn_2b7105c
02cb5960: bl      #0x2b7105c                                 fn_2b7105c
02cb5964: b       #0x2cb599c                                 
02cb5968: b       #0x2cb599c                                 
02cb596c: b       #0x2cb599c                                 
02cb5970: b       #0x2cb599c                                 
02cb5974: b       #0x2cb599c                                 
02cb5978: b       #0x2cb599c                                 
02cb597c: b       #0x2cb599c                                 
02cb5980: b       #0x2cb599c                                 
02cb5984: b       #0x2cb599c                                 
02cb5988: b       #0x2cb599c                                 
02cb598c: b       #0x2cb599c                                 
02cb5990: b       #0x2cb599c                                 
02cb5994: b       #0x2cb599c                                 
02cb5998: b       #0x2cb599c                                 
02cb599c: mov     x20, x0                                    
02cb59a0: cmp     w1, #1                                     
02cb59a4: b.ne    #0x2cb5a34                                 
02cb59a8: mov     x0, x20                                    
02cb59ac: bl      #0x5e90260                                 fn_5e90260
02cb59b0: mov     x20, x0                                    
02cb59b4: adrp    x0, #0x6263000                             
02cb59b8: ldr     x0, [x0, #0xae0]                           T:System.Exception
02cb59bc: bl      #0x2b70dc4                                 fn_2b70dc4
02cb59c0: ldr     x8, [x20]                                  &2b706c4(=eb01011ff9400808)
02cb59c4: ldr     x1, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cb59c8: bl      #0x2b71464                                 fn_2b71464
02cb59cc: tbz     w0, #0, #0x2cb5a0c                         
02cb59d0: ldrsw   x21, [sp, #8]                              
02cb59d4: ldr     x20, [x20]                                 &2b706c4(=eb01011ff9400808)
02cb59d8: mov     x8, sp                                     
02cb59dc: str     x20, [x8, x21, lsl #3]                     
02cb59e0: add     w8, w21, #1                                
02cb59e4: str     w8, [sp, #8]                               
02cb59e8: bl      #0x5e90270                                 fn_5e90270
02cb59ec: mov     w8, #-2                                    
02cb59f0: mov     x1, x20                                    
02cb59f4: mov     x2, xzr                                    
02cb59f8: str     w8, [x19], #8                              
02cb59fc: mov     x0, x19                                    
02cb5a00: bl      #0x4d43cc0                                 System.Runtime.CompilerServices.AsyncVoidMethodBuilder::SetException
02cb5a04: str     w21, [sp, #8]                              
02cb5a08: b       #0x2cb5904                                 
02cb5a0c: mov     w0, #8                                     
02cb5a10: bl      #0x5e90290                                 fn_5e90290
02cb5a14: ldr     x8, [x20]                                  &2b706c4(=eb01011ff9400808)
02cb5a18: str     x8, [x0]                                   
02cb5a1c: adrp    x1, #0x5e96000                             
02cb5a20: add     x1, x1, #0x758                             &5e96758
02cb5a24: mov     x2, xzr                                    
02cb5a28: bl      #0x5e902a0                                 fn_5e902a0
02cb5a2c: mov     x20, x0                                    
02cb5a30: bl      #0x5e90270                                 fn_5e90270
02cb5a34: mov     x0, x20                                    
02cb5a38: bl      #0x2c6051c                                 fn_2c6051c
02cb5a3c: bl      #0x27369b8                                 fn_27369b8
## SetStateMachine(System.Runtime.CompilerServices.IAsyncStateMachine stateMachine) -> void
---- CommentControl/<Init>d__16::SetStateMachine 0x2cb5a40
02cb5a40: add     x0, x0, #8                                 
02cb5a44: mov     x2, xzr                                    
02cb5a48: b       #0x4d43a8c                                 System.Runtime.CompilerServices.AsyncVoidMethodBuilder::SetStateMachine
#### CLASS CommentControl parent= PoolElement
#   field timeAnim                       float                                              off=0x28 attr=1 SerializeField
#   field widthMaxScaleText              float                                              off=0x2c attr=1 SerializeField
#   field widthScaleText                 float                                              off=0x30 attr=1 SerializeField
#   field rect                           UnityEngine.RectTransform                          off=0x38 attr=1 SerializeField
#   field layout_txt                     UnityEngine.RectTransform                          off=0x40 attr=1 SerializeField
#   field _layoutImage                   UnityEngine.UI.Image                               off=0x48 attr=1 SerializeField
#   field _layoutBG                      UnityEngine.UI.Image                               off=0x50 attr=1 SerializeField
#   field text_meshPro                   TMPro.TextMeshProUGUI                              off=0x58 attr=1 SerializeField
#   field img_avatar                     UnityEngine.UI.Image                               off=0x60 attr=1 SerializeField
#   field _localScale                    UnityEngine.Transform                              off=0x68 attr=1 SerializeField
#   field _viewerRectSprite              UnityEngine.Sprite                                 off=0x70 attr=1 SerializeField
#   field _streamerRectSprite            UnityEngine.Sprite                                 off=0x78 attr=1 SerializeField
#   field Tween                          DG.Tweening.Tween                                  off=0x80 attr=1 
## OnDespawned() -> void
---- CommentControl::OnDespawned 0x2cb4f2c
02cb4f2c: ldr     x0, [x0, #0x80]                            .Tween
02cb4f30: cbz     x0, #0x2cb4f40                             
02cb4f34: mov     w1, wzr                                    
02cb4f38: mov     x2, xzr                                    
02cb4f3c: b       #0x2d8fe94                                 DG.Tweening.TweenExtensions::Kill
02cb4f40: ret                                                
## OnSpawned() -> void
---- CommentControl::OnSpawned 0x2cb4f44
02cb4f44: ret                                                
## EnableAutoSizeFont(bool value) -> void
---- CommentControl::EnableAutoSizeFont 0x2cb4f48
02cb4f48: ldr     x0, [x0, #0x58]                            .text_meshPro
02cb4f4c: cbz     x0, #0x2cb4f5c                             
02cb4f50: and     w1, w1, #1                                 
02cb4f54: mov     x2, xzr                                    
02cb4f58: b       #0x5a7729c                                 TMPro.TMP_Text::set_enableAutoSizing
02cb4f5c: str     x30, [sp, #-0x10]!                         
02cb4f60: bl      #0x2b7105c                                 fn_2b7105c
## Init(UnityEngine.Sprite avatar) -> void
---- CommentControl::Init 0x2cb4f64
02cb4f64: sub     sp, sp, #0xa0                              
02cb4f68: str     x30, [sp, #0x70]                           
02cb4f6c: stp     x22, x21, [sp, #0x80]                      
02cb4f70: stp     x20, x19, [sp, #0x90]                      
02cb4f74: adrp    x22, #0x662f000                            
02cb4f78: adrp    x21, #0x6266000                            
02cb4f7c: mov     x19, x1                                    
02cb4f80: ldrb    w8, [x22, #0xba4]                          
02cb4f84: ldr     x21, [x21, #0xc70]                         MS:System.Runtime.CompilerServices.AsyncVoidMethodBuilder::Start
02cb4f88: mov     x20, x0                                    
02cb4f8c: tbnz    w8, #0, #0x2cb4fa4                         
02cb4f90: adrp    x0, #0x6266000                             
02cb4f94: ldr     x0, [x0, #0xc70]                           MS:System.Runtime.CompilerServices.AsyncVoidMethodBuilder::Start
02cb4f98: bl      #0x2b70db0                                 fn_2b70db0
02cb4f9c: mov     w8, #1                                     
02cb4fa0: strb    w8, [x22, #0xba4]                          
02cb4fa4: movi    v0.2d, #0000000000000000                   
02cb4fa8: mov     x8, sp                                     
02cb4fac: mov     x0, xzr                                    
02cb4fb0: str     xzr, [sp, #0x60]                           
02cb4fb4: add     x22, sp, #0x20                             
02cb4fb8: stp     q0, q0, [sp, #0x20]                        
02cb4fbc: stp     q0, q0, [sp, #0x40]                        
02cb4fc0: bl      #0x4d43a24                                 System.Runtime.CompilerServices.AsyncVoidMethodBuilder::Create
02cb4fc4: ldp     q0, q1, [sp]                               
02cb4fc8: orr     x0, x22, #8                                
02cb4fcc: mov     x1, xzr                                    
02cb4fd0: stur    q0, [sp, #0x28]                            
02cb4fd4: stur    q1, [sp, #0x38]                            
02cb4fd8: bl      #0x2b70d54                                 fn_2b70d54
02cb4fdc: add     x0, x22, #0x28                             &662f028
02cb4fe0: mov     x1, x20                                    
02cb4fe4: str     x20, [sp, #0x48]                           
02cb4fe8: bl      #0x2b70d54                                 fn_2b70d54
02cb4fec: add     x0, x22, #0x30                             &662f030
02cb4ff0: mov     x1, x19                                    
02cb4ff4: str     x19, [sp, #0x50]                           
02cb4ff8: bl      #0x2b70d54                                 fn_2b70d54
02cb4ffc: ldr     x2, [x21]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cb5000: mov     w8, #-1                                    
02cb5004: orr     x0, x22, #8                                
02cb5008: add     x1, sp, #0x20                              
02cb500c: str     w8, [sp, #0x20]                            
02cb5010: bl      #0x30c67a0                                 fn_30c67a0
02cb5014: ldp     x20, x19, [sp, #0x90]                      
02cb5018: ldr     x30, [sp, #0x70]                           
02cb501c: ldp     x22, x21, [sp, #0x80]                      
02cb5020: add     sp, sp, #0xa0                              
02cb5024: ret                                                
## OnMoveUp(System.Action callback) -> void
---- CommentControl::OnMoveUp 0x2cb5028
02cb5028: str     x30, [sp, #-0x40]!                         
02cb502c: stp     x24, x23, [sp, #0x10]                      
02cb5030: stp     x22, x21, [sp, #0x20]                      
02cb5034: stp     x20, x19, [sp, #0x30]                      
02cb5038: adrp    x20, #0x662f000                            
02cb503c: adrp    x22, #0x6266000                            
02cb5040: mov     x21, x1                                    
02cb5044: ldrb    w8, [x20, #0xba5]                          
02cb5048: ldr     x22, [x22, #0xc78]                         T:CommentControl/<>c__DisplayClass17_0
02cb504c: mov     x19, x0                                    
02cb5050: tbnz    w8, #0, #0x2cb508c                         
02cb5054: adrp    x0, #0x6264000                             
02cb5058: ldr     x0, [x0, #0xe8]                            T:DG.Tweening.TweenCallback
02cb505c: bl      #0x2b70db0                                 fn_2b70db0
02cb5060: adrp    x0, #0x6266000                             
02cb5064: ldr     x0, [x0, #0xa08]                           MS:DG.Tweening.TweenSettingsExtensions::OnComplete
02cb5068: bl      #0x2b70db0                                 fn_2b70db0
02cb506c: adrp    x0, #0x6266000                             
02cb5070: ldr     x0, [x0, #0xc80]                           M:CommentControl/<>c__DisplayClass17_0::<OnMoveUp>b__0
02cb5074: bl      #0x2b70db0                                 fn_2b70db0
02cb5078: adrp    x0, #0x6266000                             
02cb507c: ldr     x0, [x0, #0xc78]                           T:CommentControl/<>c__DisplayClass17_0
02cb5080: bl      #0x2b70db0                                 fn_2b70db0
02cb5084: mov     w8, #1                                     
02cb5088: strb    w8, [x20, #0xba5]                          
02cb508c: ldr     x0, [x22]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cb5090: bl      #0x2b7104c                                 fn_2b7104c
02cb5094: mov     x1, xzr                                    
02cb5098: mov     x20, x0                                    
02cb509c: bl      #0x4e53e9c                                 System.Object::.ctor
02cb50a0: cbz     x20, #0x2cb5154                            
02cb50a4: mov     x0, x20                                    
02cb50a8: mov     x1, x21                                    
02cb50ac: str     x21, [x0, #0x10]!                          
02cb50b0: bl      #0x2b70d54                                 fn_2b70d54
02cb50b4: ldr     x21, [x19, #0x38]                          .rect
02cb50b8: cbz     x21, #0x2cb5154                            
02cb50bc: adrp    x22, #0x6264000                            
02cb50c0: adrp    x23, #0x6266000                            
02cb50c4: adrp    x24, #0x6266000                            
02cb50c8: ldr     x22, [x22, #0xe8]                          T:DG.Tweening.TweenCallback
02cb50cc: ldr     x23, [x23, #0xc80]                         M:CommentControl/<>c__DisplayClass17_0::<OnMoveUp>b__0
02cb50d0: ldr     x24, [x24, #0xa08]                         MS:DG.Tweening.TweenSettingsExtensions::OnComplete
02cb50d4: mov     x0, x21                                    
02cb50d8: mov     x1, xzr                                    
02cb50dc: bl      #0x5b45c24                                 UnityEngine.Transform::get_localPosition
02cb50e0: mov     w8, #0x430c0000                            
02cb50e4: mov     x0, x21                                    
02cb50e8: mov     w1, wzr                                    
02cb50ec: fmov    s0, w8                                     
02cb50f0: mov     x2, xzr                                    
02cb50f4: fadd    s0, s1, s0                                 
02cb50f8: ldr     s1, [x19, #0x28]                           .timeAnim
02cb50fc: bl      #0x2c79c1c                                 DG.Tweening.DOTweenModuleUI::DOAnchorPosY
02cb5100: ldr     x8, [x22]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02cb5104: mov     x21, x0                                    
02cb5108: mov     x0, x8                                     
02cb510c: bl      #0x2b7104c                                 fn_2b7104c
02cb5110: ldr     x2, [x23]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cb5114: mov     x1, x20                                    
02cb5118: mov     x3, xzr                                    
02cb511c: mov     x22, x0                                    
02cb5120: bl      #0x2d89dc4                                 DG.Tweening.TweenCallback::.ctor
02cb5124: ldr     x2, [x24]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cb5128: mov     x0, x21                                    
02cb512c: mov     x1, x22                                    
02cb5130: bl      #0x336f26c                                 fn_336f26c
02cb5134: str     x0, [x19, #0x80]!                          .Tween
02cb5138: mov     x1, x0                                     
02cb513c: mov     x0, x19                                    
02cb5140: ldp     x20, x19, [sp, #0x30]                      
02cb5144: ldp     x22, x21, [sp, #0x20]                      
02cb5148: ldp     x24, x23, [sp, #0x10]                      
02cb514c: ldr     x30, [sp], #0x40                           
02cb5150: b       #0x2b70d54                                 
02cb5154: bl      #0x2b7105c                                 fn_2b7105c
## OnDespawn() -> void
---- CommentControl::OnDespawn 0x2cb5160
02cb5160: stp     x30, x23, [sp, #-0x30]!                    
02cb5164: stp     x22, x21, [sp, #0x10]                      
02cb5168: stp     x20, x19, [sp, #0x20]                      
02cb516c: adrp    x20, #0x662f000                            
02cb5170: mov     x19, x0                                    
02cb5174: ldrb    w8, [x20, #0xba6]                          
02cb5178: tbnz    w8, #0, #0x2cb51c0                         
02cb517c: adrp    x0, #0x6266000                             
02cb5180: ldr     x0, [x0, #0xc88]                           MS:UnityEngine.Component::GetComponent
02cb5184: bl      #0x2b70db0                                 fn_2b70db0
02cb5188: adrp    x0, #0x6264000                             
02cb518c: ldr     x0, [x0, #0xe8]                            T:DG.Tweening.TweenCallback
02cb5190: bl      #0x2b70db0                                 fn_2b70db0
02cb5194: adrp    x0, #0x6266000                             
02cb5198: ldr     x0, [x0, #0xc90]                           MS:DG.Tweening.TweenSettingsExtensions::OnComplete
02cb519c: bl      #0x2b70db0                                 fn_2b70db0
02cb51a0: adrp    x0, #0x6266000                             
02cb51a4: ldr     x0, [x0, #0xc98]                           M:CommentControl/<>c::<OnDespawn>b__18_0
02cb51a8: bl      #0x2b70db0                                 fn_2b70db0
02cb51ac: adrp    x0, #0x6266000                             
02cb51b0: ldr     x0, [x0, #0xca0]                           T:CommentControl/<>c
02cb51b4: bl      #0x2b70db0                                 fn_2b70db0
02cb51b8: mov     w8, #1                                     
02cb51bc: strb    w8, [x20, #0xba6]                          
02cb51c0: ldr     x0, [x19, #0x38]                           .rect
02cb51c4: cbz     x0, #0x2cb5298                             
02cb51c8: adrp    x8, #0x6266000                             
02cb51cc: adrp    x22, #0x6266000                            
02cb51d0: ldr     x8, [x8, #0xc88]                           MS:UnityEngine.Component::GetComponent
02cb51d4: ldr     x22, [x22, #0xca0]                         T:CommentControl/<>c
02cb51d8: ldr     x1, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cb51dc: bl      #0x3140c84                                 fn_3140c84
02cb51e0: movi    d0, #0000000000000000                      
02cb51e4: ldr     s1, [x19, #0x28]                           .timeAnim
02cb51e8: mov     x1, xzr                                    
02cb51ec: bl      #0x2c78338                                 DG.Tweening.DOTweenModuleUI::DOFade
02cb51f0: ldr     x8, [x22]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cb51f4: mov     x19, x0                                    
02cb51f8: ldr     w9, [x8, #0xe4]                            [62660e4]=0 f=0,0
02cb51fc: cbnz    w9, #0x2cb520c                             
02cb5200: mov     x0, x8                                     
02cb5204: bl      #0x2b70f30                                 fn_2b70f30
02cb5208: ldr     x8, [x22]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cb520c: ldr     x9, [x8, #0xb8]                            S:'banner_native_refresh_time'
02cb5210: adrp    x23, #0x6266000                            
02cb5214: ldr     x20, [x9, #8]                              
02cb5218: ldr     x23, [x23, #0xc90]                         MS:DG.Tweening.TweenSettingsExtensions::OnComplete
02cb521c: cbnz    x20, #0x2cb527c                            
02cb5220: ldr     w10, [x8, #0xe4]                           [62660e4]=0 f=0,0
02cb5224: cbnz    w10, #0x2cb5238                            
02cb5228: mov     x0, x8                                     
02cb522c: bl      #0x2b70f30                                 fn_2b70f30
02cb5230: ldr     x8, [x22]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cb5234: ldr     x9, [x8, #0xb8]                            S:'banner_native_refresh_time'
02cb5238: adrp    x8, #0x6264000                             
02cb523c: ldr     x8, [x8, #0xe8]                            T:DG.Tweening.TweenCallback
02cb5240: ldr     x21, [x9]                                  
02cb5244: ldr     x0, [x8]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02cb5248: bl      #0x2b7104c                                 fn_2b7104c
02cb524c: adrp    x8, #0x6266000                             
02cb5250: mov     x1, x21                                    
02cb5254: mov     x3, xzr                                    
02cb5258: ldr     x8, [x8, #0xc98]                           M:CommentControl/<>c::<OnDespawn>b__18_0
02cb525c: mov     x20, x0                                    
02cb5260: ldr     x2, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cb5264: bl      #0x2d89dc4                                 DG.Tweening.TweenCallback::.ctor
02cb5268: ldr     x8, [x22]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cb526c: mov     x1, x20                                    
02cb5270: ldr     x0, [x8, #0xb8]                            S:'banner_native_refresh_time'
02cb5274: str     x20, [x0, #8]!                             
02cb5278: bl      #0x2b70d54                                 fn_2b70d54
02cb527c: mov     x0, x19                                    
02cb5280: mov     x1, x20                                    
02cb5284: ldr     x2, [x23]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cb5288: ldp     x20, x19, [sp, #0x20]                      
02cb528c: ldp     x22, x21, [sp, #0x10]                      
02cb5290: ldp     x30, x23, [sp], #0x30                      
02cb5294: b       #0x336f26c                                 
02cb5298: bl      #0x2b7105c                                 fn_2b7105c
## SetText(string text) -> void
---- CommentControl::SetText 0x2cb529c
02cb529c: str     x30, [sp, #-0x20]!                         
02cb52a0: stp     x20, x19, [sp, #0x10]                      
02cb52a4: mov     x19, x0                                    
02cb52a8: ldr     x0, [x0, #0x58]                            .text_meshPro
02cb52ac: cbz     x0, #0x2cb52dc                             
02cb52b0: ldr     x8, [x0]                                   
02cb52b4: mov     x20, x1                                    
02cb52b8: ldr     x9, [x8, #0x558]                           
02cb52bc: ldr     x2, [x8, #0x560]                           
02cb52c0: blr     x9                                         
02cb52c4: ldr     x0, [x19, #0x40]                           .layout_txt
02cb52c8: ldp     s1, s0, [x19, #0x2c]                       .widthMaxScaleText
02cb52cc: mov     x1, x20                                    
02cb52d0: ldp     x20, x19, [sp, #0x10]                      
02cb52d4: ldr     x30, [sp], #0x20                           
02cb52d8: b       #0x2cb52e0                                 Utilities::WidthTextCalculator
02cb52dc: bl      #0x2b7105c                                 fn_2b7105c
## SetLayoutType(bool isViewer) -> void
---- CommentControl::SetLayoutType 0x2cb5330
02cb5330: mov     x8, x0                                     
02cb5334: ldr     x0, [x0, #0x48]                            ._layoutImage
02cb5338: cbz     x0, #0x2cb5358                             
02cb533c: tst     w1, #1                                     
02cb5340: mov     w9, #0x78                                  
02cb5344: mov     w10, #0x70                                 
02cb5348: csel    x9, x10, x9, ne                            
02cb534c: mov     x2, xzr                                    
02cb5350: ldr     x1, [x8, x9]                               
02cb5354: b       #0x5c45aa0                                 UnityEngine.UI.Image::set_sprite
02cb5358: str     x30, [sp, #-0x10]!                         
02cb535c: bl      #0x2b7105c                                 fn_2b7105c
## SetLocalizeString() -> void
---- CommentControl::SetLocalizeString 0x2cb5360
02cb5360: str     x30, [sp, #-0x20]!                         
02cb5364: stp     x20, x19, [sp, #0x10]                      
02cb5368: mov     x19, x0                                    
02cb536c: ldr     x0, [x0, #0x58]                            .text_meshPro
02cb5370: cbz     x0, #0x2cb53a0                             
02cb5374: ldr     x8, [x0]                                   
02cb5378: ldr     x20, [x19, #0x40]                          .layout_txt
02cb537c: ldr     x9, [x8, #0x548]                           
02cb5380: ldr     x1, [x8, #0x550]                           
02cb5384: blr     x9                                         
02cb5388: ldp     s1, s0, [x19, #0x2c]                       .widthMaxScaleText
02cb538c: mov     x1, x0                                     
02cb5390: mov     x0, x20                                    
02cb5394: ldp     x20, x19, [sp, #0x10]                      
02cb5398: ldr     x30, [sp], #0x20                           
02cb539c: b       #0x2cb52e0                                 Utilities::WidthTextCalculator
02cb53a0: bl      #0x2b7105c                                 fn_2b7105c
## AnimFadeOut(System.Action callback) -> void
---- CommentControl::AnimFadeOut 0x2cb53a4
02cb53a4: str     d8, [sp, #-0x40]!                          
02cb53a8: str     x30, [sp, #8]                              
02cb53ac: stp     x24, x23, [sp, #0x10]                      
02cb53b0: stp     x22, x21, [sp, #0x20]                      
02cb53b4: stp     x20, x19, [sp, #0x30]                      
02cb53b8: adrp    x20, #0x662f000                            
02cb53bc: adrp    x22, #0x6266000                            
02cb53c0: mov     x21, x1                                    
02cb53c4: ldrb    w8, [x20, #0xba7]                          
02cb53c8: ldr     x22, [x22, #0xca8]                         T:CommentControl/<>c__DisplayClass22_0
02cb53cc: mov     x19, x0                                    
02cb53d0: tbnz    w8, #0, #0x2cb540c                         
02cb53d4: adrp    x0, #0x6264000                             
02cb53d8: ldr     x0, [x0, #0xe8]                            T:DG.Tweening.TweenCallback
02cb53dc: bl      #0x2b70db0                                 fn_2b70db0
02cb53e0: adrp    x0, #0x6266000                             
02cb53e4: ldr     x0, [x0, #0xcb0]                           MS:DG.Tweening.TweenSettingsExtensions::OnComplete
02cb53e8: bl      #0x2b70db0                                 fn_2b70db0
02cb53ec: adrp    x0, #0x6266000                             
02cb53f0: ldr     x0, [x0, #0xcb8]                           M:CommentControl/<>c__DisplayClass22_0::<AnimFadeOut>b__0
02cb53f4: bl      #0x2b70db0                                 fn_2b70db0
02cb53f8: adrp    x0, #0x6266000                             
02cb53fc: ldr     x0, [x0, #0xca8]                           T:CommentControl/<>c__DisplayClass22_0
02cb5400: bl      #0x2b70db0                                 fn_2b70db0
02cb5404: mov     w8, #1                                     
02cb5408: strb    w8, [x20, #0xba7]                          
02cb540c: ldr     x0, [x22]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cb5410: bl      #0x2b7104c                                 fn_2b7104c
02cb5414: mov     x1, xzr                                    
02cb5418: mov     x20, x0                                    
02cb541c: bl      #0x4e53e9c                                 System.Object::.ctor
02cb5420: cbz     x20, #0x2cb54ec                            
02cb5424: adrp    x23, #0x6264000                            
02cb5428: adrp    x24, #0x6266000                            
02cb542c: adrp    x22, #0x6266000                            
02cb5430: ldr     x23, [x23, #0xe8]                          T:DG.Tweening.TweenCallback
02cb5434: ldr     x24, [x24, #0xcb8]                         M:CommentControl/<>c__DisplayClass22_0::<AnimFadeOut>b__0
02cb5438: ldr     x22, [x22, #0xcb0]                         MS:DG.Tweening.TweenSettingsExtensions::OnComplete
02cb543c: mov     x0, x20                                    
02cb5440: mov     x1, x21                                    
02cb5444: str     x21, [x0, #0x10]!                          
02cb5448: bl      #0x2b70d54                                 fn_2b70d54
02cb544c: adrp    x8, #0x1084000                             
02cb5450: movi    d0, #0000000000000000                      
02cb5454: ldr     x0, [x19, #0x58]                           .text_meshPro
02cb5458: ldr     s8, [x8, #0xf10]                           [1084f10]=4110bc863e99999a f=0.3,9.04603
02cb545c: mov     x1, xzr                                    
02cb5460: fmov    s1, s8                                     
02cb5464: bl      #0x2c78678                                 DG.Tweening.DOTweenModuleUI::DOFade
02cb5468: movi    d0, #0000000000000000                      
02cb546c: fmov    s1, s8                                     
02cb5470: ldr     x0, [x19, #0x48]                           ._layoutImage
02cb5474: mov     x1, xzr                                    
02cb5478: bl      #0x2c789b8                                 DG.Tweening.DOTweenModuleUI::DOFade
02cb547c: movi    d0, #0000000000000000                      
02cb5480: fmov    s1, s8                                     
02cb5484: ldr     x0, [x19, #0x50]                           ._layoutBG
02cb5488: mov     x1, xzr                                    
02cb548c: bl      #0x2c789b8                                 DG.Tweening.DOTweenModuleUI::DOFade
02cb5490: movi    d0, #0000000000000000                      
02cb5494: fmov    s1, s8                                     
02cb5498: ldr     x0, [x19, #0x60]                           .img_avatar
02cb549c: mov     x1, xzr                                    
02cb54a0: bl      #0x2c789b8                                 DG.Tweening.DOTweenModuleUI::DOFade
02cb54a4: ldr     x8, [x23]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02cb54a8: mov     x19, x0                                    
02cb54ac: mov     x0, x8                                     
02cb54b0: bl      #0x2b7104c                                 fn_2b7104c
02cb54b4: ldr     x2, [x24]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cb54b8: mov     x1, x20                                    
02cb54bc: mov     x3, xzr                                    
02cb54c0: mov     x21, x0                                    
02cb54c4: bl      #0x2d89dc4                                 DG.Tweening.TweenCallback::.ctor
02cb54c8: ldr     x2, [x22]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cb54cc: mov     x0, x19                                    
02cb54d0: mov     x1, x21                                    
02cb54d4: ldp     x20, x19, [sp, #0x30]                      
02cb54d8: ldr     x30, [sp, #8]                              
02cb54dc: ldp     x22, x21, [sp, #0x20]                      
02cb54e0: ldp     x24, x23, [sp, #0x10]                      
02cb54e4: ldr     d8, [sp], #0x40                            
02cb54e8: b       #0x336f26c                                 
02cb54ec: bl      #0x2b7105c                                 fn_2b7105c
## Appear() -> void
---- CommentControl::Appear 0x2cb54f8
02cb54f8: stp     x30, x19, [sp, #-0x10]!                    
02cb54fc: movi    d1, #0000000000000000                      
02cb5500: fmov    s0, #1.00000000                            
02cb5504: mov     x19, x0                                    
02cb5508: ldr     x0, [x0, #0x58]                            .text_meshPro
02cb550c: mov     x1, xzr                                    
02cb5510: bl      #0x2c78678                                 DG.Tweening.DOTweenModuleUI::DOFade
02cb5514: movi    d1, #0000000000000000                      
02cb5518: fmov    s0, #1.00000000                            
02cb551c: ldr     x0, [x19, #0x48]                           ._layoutImage
02cb5520: mov     x1, xzr                                    
02cb5524: bl      #0x2c789b8                                 DG.Tweening.DOTweenModuleUI::DOFade
02cb5528: movi    d1, #0000000000000000                      
02cb552c: fmov    s0, #1.00000000                            
02cb5530: ldr     x0, [x19, #0x50]                           ._layoutBG
02cb5534: mov     x1, xzr                                    
02cb5538: bl      #0x2c789b8                                 DG.Tweening.DOTweenModuleUI::DOFade
02cb553c: ldr     x0, [x19, #0x60]                           .img_avatar
02cb5540: movi    d1, #0000000000000000                      
02cb5544: fmov    s0, #1.00000000                            
02cb5548: mov     x1, xzr                                    
02cb554c: ldp     x30, x19, [sp], #0x10                      
02cb5550: b       #0x2c789b8                                 DG.Tweening.DOTweenModuleUI::DOFade
## .ctor() -> void
---- CommentControl::.ctor 0x2cb5554
02cb5554: adrp    x8, #0x1040000                             
02cb5558: mov     x1, xzr                                    
02cb555c: ldr     d0, [x8, #0xa78]                           [1040a78]=43a200003e99999a f=0.3,324
02cb5560: mov     w8, #0x42200000                            
02cb5564: str     w8, [x0, #0x30]                            .widthScaleText
02cb5568: str     d0, [x0, #0x28]                            .timeAnim
02cb556c: b       #0x2cd6228                                 PoolElement::.ctor
