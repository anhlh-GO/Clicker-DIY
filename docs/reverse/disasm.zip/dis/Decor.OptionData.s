#### CLASS Decor.OptionData parent= object
#   field ID                             int                                                off=0x10 attr=6 
#   field Icon                           UnityEngine.Sprite                                 off=0x18 attr=6 
#   field UnlockType                     Games.Common.EUnlockType                           off=0x20 attr=6 
#   field Price                          int                                                off=0x24 attr=6 
#   field IconDefault                    UnityEngine.Sprite                                 off=0x28 attr=6 ConditionalFieldAttribute
#   field HasIconDefault                 bool                                               off=0x30 attr=6 
#   field IsSkin                         bool                                               off=0x31 attr=6 
#   field PrefabSpine                    UnityEngine.GameObject                             off=0x38 attr=6 
#   field ImageSprite                    UnityEngine.Sprite                                 off=0x40 attr=6 ConditionalFieldAttribute
#   field SkinName                       string                                             off=0x48 attr=6 ConditionalFieldAttribute
## .ctor() -> void
---- Decor.OptionData::.ctor 0x2d2510c
02d2510c: mov     x1, xzr                                    
02d25110: b       #0x4e53e9c                                 System.Object::.ctor
