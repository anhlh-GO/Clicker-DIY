#### CLASS Blindbag.ScanMachine/<>c parent= object
#   field <>9                            Blindbag.ScanMachine/<>c                           off=0x0 attr=36 
#   field <>9__29_0                      System.Action`1<Blindbag.BlindBagAnimation>        off=0x8 attr=16 
#   field <>9__29_1                      System.Func`2<Blindbag.BlindBagAnimation,int>      off=0x10 attr=16 
#   field <>9__31_0                      DG.Tweening.TweenCallback                          off=0x18 attr=16 
#   field <>9__34_0                      System.Func`2<System.Collections.Generic.KeyValuePair`2<string,Blindbag.BillLine>,int> off=0x20 attr=16 
## .cctor() -> void
---- Blindbag.ScanMachine/<>c::.cctor 0x2d56138
02d56138: str     x30, [sp, #-0x20]!                         
02d5613c: stp     x20, x19, [sp, #0x10]                      
02d56140: adrp    x19, #0x6630000                            
02d56144: adrp    x20, #0x626b000                            
02d56148: ldrb    w8, [x19, #0x27f]                          
02d5614c: ldr     x20, [x20, #0x878]                         T:Blindbag.ScanMachine/<>c
02d56150: tbnz    w8, #0, #0x2d56168                         
02d56154: adrp    x0, #0x626b000                             
02d56158: ldr     x0, [x0, #0x878]                           T:Blindbag.ScanMachine/<>c
02d5615c: bl      #0x2b70db0                                 fn_2b70db0
02d56160: mov     w8, #1                                     
02d56164: strb    w8, [x19, #0x27f]                          
02d56168: ldr     x0, [x20]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d5616c: bl      #0x2b7104c                                 fn_2b7104c
02d56170: mov     x1, xzr                                    
02d56174: mov     x19, x0                                    
02d56178: bl      #0x4e53e9c                                 System.Object::.ctor
02d5617c: ldr     x8, [x20]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d56180: mov     x1, x19                                    
02d56184: ldr     x8, [x8, #0xb8]                            
02d56188: str     x19, [x8]                                  
02d5618c: ldr     x8, [x20]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d56190: ldp     x20, x19, [sp, #0x10]                      
02d56194: ldr     x0, [x8, #0xb8]                            
02d56198: ldr     x30, [sp], #0x20                           
02d5619c: b       #0x2b70d54                                 
## .ctor() -> void
---- Blindbag.ScanMachine/<>c::.ctor 0x2d561a0
02d561a0: mov     x1, xzr                                    
02d561a4: b       #0x4e53e9c                                 System.Object::.ctor
## <OnBuyCompleted>b__29_0(Blindbag.BlindBagAnimation x) -> void
---- Blindbag.ScanMachine/<>c::<OnBuyCompleted>b__29_0 0x2d561a8
02d561a8: str     x30, [sp, #-0x20]!                         
02d561ac: stp     x20, x19, [sp, #0x10]                      
02d561b0: adrp    x20, #0x6630000                            
02d561b4: mov     x19, x1                                    
02d561b8: ldrb    w8, [x20, #0x280]                          
02d561bc: tbnz    w8, #0, #0x2d561e0                         
02d561c0: adrp    x0, #0x6263000                             
02d561c4: ldr     x0, [x0, #0x928]                           T:UnityEngine.Debug
02d561c8: bl      #0x2b70db0                                 fn_2b70db0
02d561cc: adrp    x0, #0x626b000                             
02d561d0: ldr     x0, [x0, #0x9f8]                           S:'dev log Dung mua blindbag id {0}'
02d561d4: bl      #0x2b70db0                                 fn_2b70db0
02d561d8: mov     w8, #1                                     
02d561dc: strb    w8, [x20, #0x280]                          
02d561e0: cbz     x19, #0x2d56254                            
02d561e4: adrp    x8, #0x6263000                             
02d561e8: adrp    x20, #0x626b000                            
02d561ec: add     x1, sp, #0xc                               
02d561f0: ldr     x8, [x8, #0x970]                           &6645c70(=0)
02d561f4: ldr     x20, [x20, #0x9f8]                         S:'dev log Dung mua blindbag id {0}'
02d561f8: ldr     w9, [x19, #0x40]                           
02d561fc: adrp    x19, #0x6263000                            
02d56200: ldr     x19, [x19, #0x928]                         T:UnityEngine.Debug
02d56204: ldr     x0, [x8, #0x48]                            &6263098(=0)
02d56208: str     w9, [sp, #0xc]                             
02d5620c: bl      #0x2b70f38                                 fn_2b70f38
02d56210: ldr     x8, [x20]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d56214: mov     x1, x0                                     
02d56218: mov     x2, xzr                                    
02d5621c: mov     x0, x8                                     
02d56220: bl      #0x4c9d0ec                                 System.String::Format
02d56224: ldr     x8, [x19]                                  &2c5bbd4(=a9bd7bfdd503233f)
02d56228: mov     x19, x0                                    
02d5622c: ldr     w9, [x8, #0xe4]                            [62630e4]=0 f=0,0
02d56230: cbnz    w9, #0x2d5623c                             
02d56234: mov     x0, x8                                     
02d56238: bl      #0x2b70f30                                 fn_2b70f30
02d5623c: mov     x0, x19                                    
02d56240: mov     x1, xzr                                    
02d56244: bl      #0x5af21f4                                 UnityEngine.Debug::Log
02d56248: ldp     x20, x19, [sp, #0x10]                      
02d5624c: ldr     x30, [sp], #0x20                           
02d56250: ret                                                
02d56254: bl      #0x2b7105c                                 fn_2b7105c
## <OnBuyCompleted>b__29_1(Blindbag.BlindBagAnimation x) -> int
---- Blindbag.ScanMachine/<>c::<OnBuyCompleted>b__29_1 0x2d56258
02d56258: cbz     x1, #0x2d56264                             
02d5625c: ldr     w0, [x1, #0x40]                            
02d56260: ret                                                
02d56264: str     x30, [sp, #-0x10]!                         
02d56268: bl      #0x2b7105c                                 fn_2b7105c
## <SetData>b__31_0() -> void
---- Blindbag.ScanMachine/<>c::<SetData>b__31_0 0x2d5626c
02d5626c: str     x30, [sp, #-0x10]!                         
02d56270: mov     x0, xzr                                    
02d56274: bl      #0x2d6eec8                                 Framework.AudioManager::get_Instance
02d56278: cbz     x0, #0x2d562a0                             
02d5627c: movi    d1, #0000000000000000                      
02d56280: movi    d2, #0000000000000000                      
02d56284: mov     w1, #0x11                                  
02d56288: fmov    s0, #1.00000000                            
02d5628c: mov     w2, wzr                                    
02d56290: mov     w3, wzr                                    
02d56294: mov     x4, xzr                                    
02d56298: ldr     x30, [sp], #0x10                           
02d5629c: b       #0x2d6f03c                                 Framework.AudioManager::PlaySound
02d562a0: bl      #0x2b7105c                                 fn_2b7105c
## <UpdateTotalText>b__34_0(System.Collections.Generic.KeyValuePair`2<string,Blindbag.BillLine> billLine) -> int
---- Blindbag.ScanMachine/<>c::<UpdateTotalText>b__34_0 0x2d562a4
02d562a4: str     x30, [sp, #-0x20]!                         
02d562a8: stp     x20, x19, [sp, #0x10]                      
02d562ac: adrp    x20, #0x6630000                            
02d562b0: mov     x19, x2                                    
02d562b4: ldrb    w8, [x20, #0x281]                          
02d562b8: tbnz    w8, #0, #0x2d562d0                         
02d562bc: adrp    x0, #0x626b000                             
02d562c0: ldr     x0, [x0, #0xa00]                           MS:System.Collections.Generic.KeyValuePair`2::get_Value
02d562c4: bl      #0x2b70db0                                 fn_2b70db0
02d562c8: mov     w8, #1                                     
02d562cc: strb    w8, [x20, #0x281]                          
02d562d0: cbz     x19, #0x2d562e4                            
02d562d4: ldr     w0, [x19, #0x38]                           
02d562d8: ldp     x20, x19, [sp, #0x10]                      
02d562dc: ldr     x30, [sp], #0x20                           
02d562e0: ret                                                
02d562e4: bl      #0x2b7105c                                 fn_2b7105c
#### CLASS Blindbag.ScanMachine/<>c__DisplayClass31_0 parent= object
#   field orderBag                       Blindbag.BlindBagAnimation                         off=0x10 attr=6 
#   field <>4__this                      Blindbag.ScanMachine                               off=0x18 attr=6 
## .ctor() -> void
---- Blindbag.ScanMachine/<>c__DisplayClass31_0::.ctor 0x2d556a4
02d556a4: mov     x1, xzr                                    
02d556a8: b       #0x4e53e9c                                 System.Object::.ctor
## <SetData>b__1() -> void
---- Blindbag.ScanMachine/<>c__DisplayClass31_0::<SetData>b__1 0x2d562e8
02d562e8: str     x30, [sp, #-0x10]!                         
02d562ec: ldr     x8, [x0, #0x18]                            .<>4__this
02d562f0: cbz     x8, #0x2d56308                             
02d562f4: ldr     x0, [x0, #0x10]                            .orderBag
02d562f8: cbz     x0, #0x2d56308                             
02d562fc: ldr     x1, [x8, #0x48]                            
02d56300: ldr     x30, [sp], #0x10                           
02d56304: b       #0x2d50910                                 Blindbag.BlindBagAnimation::InitializedBuying
02d56308: bl      #0x2b7105c                                 fn_2b7105c
#### CLASS Blindbag.ScanMachine/<>c__DisplayClass32_0 parent= object
#   field <>4__this                      Blindbag.ScanMachine                               off=0x10 attr=6 
#   field bag                            Blindbag.BlindBagAnimation                         off=0x18 attr=6 
#   field <>9__2                         DG.Tweening.TweenCallback                          off=0x20 attr=6 
## .ctor() -> void
---- Blindbag.ScanMachine/<>c__DisplayClass32_0::.ctor 0x2d55830
02d55830: mov     x1, xzr                                    
02d55834: b       #0x4e53e9c                                 System.Object::.ctor
## <OnScanItemHandler>b__0() -> void
---- Blindbag.ScanMachine/<>c__DisplayClass32_0::<OnScanItemHandler>b__0 0x2d5630c
02d5630c: stp     x30, x21, [sp, #-0x20]!                    
02d56310: stp     x20, x19, [sp, #0x10]                      
02d56314: adrp    x20, #0x6630000                            
02d56318: mov     x19, x0                                    
02d5631c: ldrb    w8, [x20, #0x282]                          
02d56320: tbnz    w8, #0, #0x2d56374                         
02d56324: adrp    x0, #0x626b000                             
02d56328: ldr     x0, [x0, #0xa08]                           MS:System.Collections.Generic.Dictionary`2::Add
02d5632c: bl      #0x2b70db0                                 fn_2b70db0
02d56330: adrp    x0, #0x626b000                             
02d56334: ldr     x0, [x0, #0xa10]                           MS:System.Collections.Generic.Dictionary`2::ContainsKey
02d56338: bl      #0x2b70db0                                 fn_2b70db0
02d5633c: adrp    x0, #0x626b000                             
02d56340: ldr     x0, [x0, #0xa18]                           MS:System.Collections.Generic.Dictionary`2::get_Item
02d56344: bl      #0x2b70db0                                 fn_2b70db0
02d56348: adrp    x0, #0x626b000                             
02d5634c: ldr     x0, [x0, #0xa20]                           MS:UnityEngine.Object::Instantiate
02d56350: bl      #0x2b70db0                                 fn_2b70db0
02d56354: adrp    x0, #0x6263000                             
02d56358: ldr     x0, [x0, #0x918]                           T:UnityEngine.Object
02d5635c: bl      #0x2b70db0                                 fn_2b70db0
02d56360: adrp    x0, #0x6267000                             
02d56364: ldr     x0, [x0, #0xea8]                           T:Framework.Vibration
02d56368: bl      #0x2b70db0                                 fn_2b70db0
02d5636c: mov     w8, #1                                     
02d56370: strb    w8, [x20, #0x282]                          
02d56374: ldr     x9, [x19, #0x10]                           .<>4__this
02d56378: cbz     x9, #0x2d564b0                             
02d5637c: ldr     x8, [x19, #0x18]                           .bag
02d56380: cbz     x8, #0x2d564b0                             
02d56384: ldr     x0, [x9, #0xb0]                            
02d56388: cbz     x0, #0x2d564b0                             
02d5638c: adrp    x9, #0x626b000                             
02d56390: ldr     x9, [x9, #0xa10]                           MS:System.Collections.Generic.Dictionary`2::ContainsKey
02d56394: ldr     x1, [x8, #0x48]                            
02d56398: ldr     x2, [x9]                                   T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d5639c: bl      #0x452c810                                 fn_452c810
02d563a0: ldr     x8, [x19, #0x10]                           .<>4__this
02d563a4: tbz     w0, #0, #0x2d563e8                         
02d563a8: cbz     x8, #0x2d564b0                             
02d563ac: ldr     x9, [x19, #0x18]                           .bag
02d563b0: cbz     x9, #0x2d564b0                             
02d563b4: ldr     x0, [x8, #0xb0]                            
02d563b8: cbz     x0, #0x2d564b0                             
02d563bc: adrp    x8, #0x626b000                             
02d563c0: ldr     x8, [x8, #0xa18]                           MS:System.Collections.Generic.Dictionary`2::get_Item
02d563c4: ldr     x1, [x9, #0x48]                            T:type56654(k15)
02d563c8: ldr     x2, [x8]                                   T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d563cc: bl      #0x452c59c                                 fn_452c59c
02d563d0: ldr     x8, [x19, #0x18]                           .bag
02d563d4: cbz     x8, #0x2d564b0                             
02d563d8: cbz     x0, #0x2d564b0                             
02d563dc: ldr     w1, [x8, #0x50]                            MS:System.Collections.Generic.List`1::.ctor
02d563e0: bl      #0x2d4ffac                                 Blindbag.BillLine::UpdatePrice
02d563e4: b       #0x2d56470                                 
02d563e8: cbz     x8, #0x2d564b0                             
02d563ec: adrp    x9, #0x6263000                             
02d563f0: ldr     x9, [x9, #0x918]                           T:UnityEngine.Object
02d563f4: ldp     x20, x21, [x8, #0x28]                      
02d563f8: ldr     x0, [x9]                                   &2c5bbd4(=a9bd7bfdd503233f)
02d563fc: ldr     w9, [x0, #0xe4]                            [62670e4]=0 f=0,0
02d56400: cbnz    w9, #0x2d56408                             
02d56404: bl      #0x2b70f30                                 fn_2b70f30
02d56408: adrp    x8, #0x626b000                             
02d5640c: mov     x0, x20                                    
02d56410: mov     x1, x21                                    
02d56414: ldr     x8, [x8, #0xa20]                           MS:UnityEngine.Object::Instantiate
02d56418: ldr     x2, [x8]                                   T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d5641c: bl      #0x3275fcc                                 fn_3275fcc
02d56420: ldr     x8, [x19, #0x18]                           .bag
02d56424: cbz     x8, #0x2d564b0                             
02d56428: mov     x20, x0                                    
02d5642c: cbz     x0, #0x2d564b0                             
02d56430: ldr     w2, [x8, #0x50]                            MS:System.Collections.Generic.List`1::.ctor
02d56434: ldr     x1, [x8, #0x48]                            T:type56654(k15)
02d56438: mov     x0, x20                                    
02d5643c: bl      #0x2d4fe6c                                 Blindbag.BillLine::SetData
02d56440: ldr     x9, [x19, #0x10]                           .<>4__this
02d56444: cbz     x9, #0x2d564b0                             
02d56448: ldr     x8, [x19, #0x18]                           .bag
02d5644c: cbz     x8, #0x2d564b0                             
02d56450: ldr     x0, [x9, #0xb0]                            [62630b0]=0 f=0,0
02d56454: cbz     x0, #0x2d564b0                             
02d56458: adrp    x9, #0x626b000                             
02d5645c: mov     x2, x20                                    
02d56460: ldr     x9, [x9, #0xa08]                           MS:System.Collections.Generic.Dictionary`2::Add
02d56464: ldr     x1, [x8, #0x48]                            T:type56654(k15)
02d56468: ldr     x3, [x9]                                   T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d5646c: bl      #0x452c61c                                 fn_452c61c
02d56470: ldr     x0, [x19, #0x10]                           .<>4__this
02d56474: cbz     x0, #0x2d564b0                             
02d56478: adrp    x19, #0x6267000                            
02d5647c: ldr     x19, [x19, #0xea8]                         T:Framework.Vibration
02d56480: bl      #0x2d55a98                                 Blindbag.ScanMachine::UpdateTotalText
02d56484: ldr     x0, [x19]                                  S:'didu'
02d56488: ldr     w8, [x0, #0xe4]                            [62670e4]=0 f=0,0
02d5648c: cbnz    w8, #0x2d56494                             
02d56490: bl      #0x2b70f30                                 fn_2b70f30
02d56494: ldp     x20, x19, [sp, #0x10]                      
02d56498: mov     w0, #0x32                                  
02d5649c: mov     w1, #-1                                    
02d564a0: mov     w2, wzr                                    
02d564a4: mov     x3, xzr                                    
02d564a8: ldp     x30, x21, [sp], #0x20                      
02d564ac: b       #0x2d6e144                                 Framework.Vibration::Vibrate
02d564b0: bl      #0x2b7105c                                 fn_2b7105c
## <OnScanItemHandler>b__1() -> void
---- Blindbag.ScanMachine/<>c__DisplayClass32_0::<OnScanItemHandler>b__1 0x2d564b4
02d564b4: stp     x30, x23, [sp, #-0x30]!                    
02d564b8: stp     x22, x21, [sp, #0x10]                      
02d564bc: stp     x20, x19, [sp, #0x20]                      
02d564c0: adrp    x20, #0x6630000                            
02d564c4: mov     x19, x0                                    
02d564c8: ldrb    w8, [x20, #0x283]                          
02d564cc: tbnz    w8, #0, #0x2d564fc                         
02d564d0: adrp    x0, #0x6264000                             
02d564d4: ldr     x0, [x0, #0xe8]                            T:DG.Tweening.TweenCallback
02d564d8: bl      #0x2b70db0                                 fn_2b70db0
02d564dc: adrp    x0, #0x6266000                             
02d564e0: ldr     x0, [x0, #0x928]                           MS:DG.Tweening.TweenSettingsExtensions::OnComplete
02d564e4: bl      #0x2b70db0                                 fn_2b70db0
02d564e8: adrp    x0, #0x626b000                             
02d564ec: ldr     x0, [x0, #0xa28]                           M:Blindbag.ScanMachine/<>c__DisplayClass32_0::<OnScanItemHandler>b__2
02d564f0: bl      #0x2b70db0                                 fn_2b70db0
02d564f4: mov     w8, #1                                     
02d564f8: strb    w8, [x20, #0x283]                          
02d564fc: ldr     x8, [x19, #0x10]                           .<>4__this
02d56500: cbz     x8, #0x2d565cc                             
02d56504: ldr     x0, [x19, #0x18]                           .bag
02d56508: mov     w9, #1                                     
02d5650c: strb    w9, [x8, #0x20]                            
02d56510: cbz     x0, #0x2d565cc                             
02d56514: mov     x1, xzr                                    
02d56518: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02d5651c: ldr     x8, [x19, #0x18]                           .bag
02d56520: cbz     x8, #0x2d565cc                             
02d56524: mov     x20, x0                                    
02d56528: mov     x0, x8                                     
02d5652c: mov     x1, xzr                                    
02d56530: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02d56534: cbz     x0, #0x2d565cc                             
02d56538: adrp    x23, #0x6266000                            
02d5653c: mov     x1, xzr                                    
02d56540: ldr     x23, [x23, #0x928]                         MS:DG.Tweening.TweenSettingsExtensions::OnComplete
02d56544: bl      #0x5b45c24                                 UnityEngine.Transform::get_localPosition
02d56548: fmov    s1, #10.00000000                           
02d5654c: mov     x0, x20                                    
02d56550: mov     w1, wzr                                    
02d56554: mov     x2, xzr                                    
02d56558: fadd    s0, s0, s1                                 
02d5655c: fmov    s1, #0.50000000                            
02d56560: bl      #0x2d97eac                                 DG.Tweening.ShortcutExtensions::DOLocalMoveX
02d56564: mov     x21, x19                                   
02d56568: mov     x20, x0                                    
02d5656c: ldr     x22, [x21, #0x20]!                         .<>9__2
02d56570: cbnz    x22, #0x2d565b0                            
02d56574: adrp    x8, #0x6264000                             
02d56578: ldr     x8, [x8, #0xe8]                            T:DG.Tweening.TweenCallback
02d5657c: ldr     x0, [x8]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d56580: bl      #0x2b7104c                                 fn_2b7104c
02d56584: adrp    x8, #0x626b000                             
02d56588: mov     x1, x19                                    
02d5658c: mov     x3, xzr                                    
02d56590: ldr     x8, [x8, #0xa28]                           M:Blindbag.ScanMachine/<>c__DisplayClass32_0::<OnScanItemHandler>b__2
02d56594: mov     x22, x0                                    
02d56598: ldr     x2, [x8]                                   T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d5659c: bl      #0x2d89dc4                                 DG.Tweening.TweenCallback::.ctor
02d565a0: mov     x0, x21                                    
02d565a4: mov     x1, x22                                    
02d565a8: str     x22, [x19, #0x20]                          .<>9__2
02d565ac: bl      #0x2b70d54                                 fn_2b70d54
02d565b0: mov     x0, x20                                    
02d565b4: mov     x1, x22                                    
02d565b8: ldr     x2, [x23]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d565bc: ldp     x20, x19, [sp, #0x20]                      
02d565c0: ldp     x22, x21, [sp, #0x10]                      
02d565c4: ldp     x30, x23, [sp], #0x30                      
02d565c8: b       #0x336f26c                                 
02d565cc: bl      #0x2b7105c                                 fn_2b7105c
## <OnScanItemHandler>b__2() -> void
---- Blindbag.ScanMachine/<>c__DisplayClass32_0::<OnScanItemHandler>b__2 0x2d565d0
02d565d0: stp     x30, x19, [sp, #-0x10]!                    
02d565d4: mov     x19, x0                                    
02d565d8: ldr     x0, [x0, #0x18]                            .bag
02d565dc: cbz     x0, #0x2d565f8                             
02d565e0: mov     x1, xzr                                    
02d565e4: bl      #0x2cdc880                                 PoolElement::DespawnSelf
02d565e8: ldr     x0, [x19, #0x10]                           .<>4__this
02d565ec: cbz     x0, #0x2d565f8                             
02d565f0: ldp     x30, x19, [sp], #0x10                      
02d565f4: b       #0x2d55a5c                                 Blindbag.ScanMachine::CheckOrderingCompleted
02d565f8: bl      #0x2b7105c                                 fn_2b7105c
#### CLASS Blindbag.ScanMachine/<>c__DisplayClass36_0 parent= object
#   field onTriggerBillLine              System.Action                                      off=0x10 attr=6 
#   field <>4__this                      Blindbag.ScanMachine                               off=0x18 attr=6 
#   field onAnimationCompleted           System.Action                                      off=0x20 attr=6 
#   field <>9__1                         DG.Tweening.TweenCallback                          off=0x28 attr=6 
## .ctor() -> void
---- Blindbag.ScanMachine/<>c__DisplayClass36_0::.ctor 0x2d55bd8
02d55bd8: mov     x1, xzr                                    
02d55bdc: b       #0x4e53e9c                                 System.Object::.ctor
## <ScanAnimation>b__0() -> void
---- Blindbag.ScanMachine/<>c__DisplayClass36_0::<ScanAnimation>b__0 0x2d565fc
02d565fc: stp     x30, x23, [sp, #-0x30]!                    
02d56600: stp     x22, x21, [sp, #0x10]                      
02d56604: stp     x20, x19, [sp, #0x20]                      
02d56608: adrp    x20, #0x6630000                            
02d5660c: mov     x19, x0                                    
02d56610: ldrb    w8, [x20, #0x284]                          
02d56614: tbnz    w8, #0, #0x2d56650                         
02d56618: adrp    x0, #0x6264000                             
02d5661c: ldr     x0, [x0, #0xe8]                            T:DG.Tweening.TweenCallback
02d56620: bl      #0x2b70db0                                 fn_2b70db0
02d56624: adrp    x0, #0x6266000                             
02d56628: ldr     x0, [x0, #0x928]                           MS:DG.Tweening.TweenSettingsExtensions::OnComplete
02d5662c: bl      #0x2b70db0                                 fn_2b70db0
02d56630: adrp    x0, #0x6266000                             
02d56634: ldr     x0, [x0, #0x880]                           MS:DG.Tweening.TweenSettingsExtensions::SetEase
02d56638: bl      #0x2b70db0                                 fn_2b70db0
02d5663c: adrp    x0, #0x626b000                             
02d56640: ldr     x0, [x0, #0xa30]                           M:Blindbag.ScanMachine/<>c__DisplayClass36_0::<ScanAnimation>b__1
02d56644: bl      #0x2b70db0                                 fn_2b70db0
02d56648: mov     w8, #1                                     
02d5664c: strb    w8, [x20, #0x284]                          
02d56650: ldr     x8, [x19, #0x10]                           .onTriggerBillLine
02d56654: cbz     x8, #0x2d56668                             
02d56658: ldr     x9, [x8, #0x18]                            
02d5665c: ldr     x0, [x8, #0x40]                            
02d56660: ldr     x1, [x8, #0x28]                            
02d56664: blr     x9                                         
02d56668: ldr     x8, [x19, #0x18]                           .<>4__this
02d5666c: cbz     x8, #0x2d56710                             
02d56670: adrp    x20, #0x6266000                            
02d56674: adrp    x23, #0x6266000                            
02d56678: fmov    s1, #0.50000000                            
02d5667c: ldr     x20, [x20, #0x880]                         MS:DG.Tweening.TweenSettingsExtensions::SetEase
02d56680: ldr     x23, [x23, #0x928]                         MS:DG.Tweening.TweenSettingsExtensions::OnComplete
02d56684: ldr     x0, [x8, #0x40]                            
02d56688: adrp    x8, #0x1084000                             
02d5668c: mov     w1, wzr                                    
02d56690: mov     x2, xzr                                    
02d56694: ldr     s0, [x8, #0xd20]                           [1084d20]=bf51745dbf19999a f=-0.6,-0.818182
02d56698: bl      #0x2d98060                                 DG.Tweening.ShortcutExtensions::DOLocalMoveY
02d5669c: ldr     x2, [x20]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d566a0: mov     w1, #1                                     
02d566a4: bl      #0x336fa0c                                 fn_336fa0c
02d566a8: mov     x21, x19                                   
02d566ac: mov     x20, x0                                    
02d566b0: ldr     x22, [x21, #0x28]!                         .<>9__1
02d566b4: cbnz    x22, #0x2d566f4                            
02d566b8: adrp    x8, #0x6264000                             
02d566bc: ldr     x8, [x8, #0xe8]                            T:DG.Tweening.TweenCallback
02d566c0: ldr     x0, [x8]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d566c4: bl      #0x2b7104c                                 fn_2b7104c
02d566c8: adrp    x8, #0x626b000                             
02d566cc: mov     x1, x19                                    
02d566d0: mov     x3, xzr                                    
02d566d4: ldr     x8, [x8, #0xa30]                           M:Blindbag.ScanMachine/<>c__DisplayClass36_0::<ScanAnimation>b__1
02d566d8: mov     x22, x0                                    
02d566dc: ldr     x2, [x8]                                   T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d566e0: bl      #0x2d89dc4                                 DG.Tweening.TweenCallback::.ctor
02d566e4: mov     x0, x21                                    
02d566e8: mov     x1, x22                                    
02d566ec: str     x22, [x19, #0x28]                          .<>9__1
02d566f0: bl      #0x2b70d54                                 fn_2b70d54
02d566f4: mov     x0, x20                                    
02d566f8: mov     x1, x22                                    
02d566fc: ldr     x2, [x23]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d56700: ldp     x20, x19, [sp, #0x20]                      
02d56704: ldp     x22, x21, [sp, #0x10]                      
02d56708: ldp     x30, x23, [sp], #0x30                      
02d5670c: b       #0x336f26c                                 
02d56710: bl      #0x2b7105c                                 fn_2b7105c
## <ScanAnimation>b__1() -> void
---- Blindbag.ScanMachine/<>c__DisplayClass36_0::<ScanAnimation>b__1 0x2d56714
02d56714: str     d8, [sp, #-0x30]!                          
02d56718: stp     x30, x21, [sp, #0x10]                      
02d5671c: stp     x20, x19, [sp, #0x20]                      
02d56720: ldr     x8, [x0, #0x18]                            .<>4__this
02d56724: cbz     x8, #0x2d567c8                             
02d56728: mov     x19, x0                                    
02d5672c: ldr     s8, [x8, #0xc8]                            
02d56730: mov     x0, xzr                                    
02d56734: bl      #0x5b432fc                                 UnityEngine.Time::get_time
02d56738: fcmp    s8, s0                                     
02d5673c: b.pl    #0x2d56794                                 
02d56740: ldr     x8, [x19, #0x18]                           .<>4__this
02d56744: cbz     x8, #0x2d567c8                             
02d56748: adrp    x21, #0x662f000                            
02d5674c: ldr     x20, [x8, #0x40]                           
02d56750: ldrb    w9, [x21, #0x91a]                          
02d56754: cbnz    w9, #0x2d5676c                             
02d56758: adrp    x0, #0x6264000                             
02d5675c: ldr     x0, [x0, #0xd8]                            T:UnityEngine.Vector3
02d56760: bl      #0x2b70db0                                 fn_2b70db0
02d56764: mov     w8, #1                                     
02d56768: strb    w8, [x21, #0x91a]                          
02d5676c: cbz     x20, #0x2d567c8                            
02d56770: adrp    x8, #0x6264000                             
02d56774: mov     x0, x20                                    
02d56778: mov     x1, xzr                                    
02d5677c: ldr     x8, [x8, #0xd8]                            T:UnityEngine.Vector3
02d56780: ldr     x8, [x8]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d56784: ldr     x8, [x8, #0xb8]                            MS:DG.Tweening.Core.Extensions::SetSpecialStartupMode
02d56788: ldp     s1, s2, [x8, #4]                           
02d5678c: ldr     s0, [x8]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d56790: bl      #0x5b470cc                                 UnityEngine.Transform::set_localScale
02d56794: ldr     x8, [x19, #0x20]                           .onAnimationCompleted
02d56798: cbz     x8, #0x2d567b8                             
02d5679c: ldp     x20, x19, [sp, #0x20]                      
02d567a0: ldr     x0, [x8, #0x40]                            MS:DG.Tweening.TweenSettingsExtensions::SetTarget
02d567a4: ldp     x30, x21, [sp, #0x10]                      
02d567a8: ldr     x1, [x8, #0x28]                            T:type8534(k15)
02d567ac: ldr     x2, [x8, #0x18]                            M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass2_0::<DOSetFloat>b__1
02d567b0: ldr     d8, [sp], #0x30                            
02d567b4: br      x2                                         
02d567b8: ldp     x20, x19, [sp, #0x20]                      
02d567bc: ldp     x30, x21, [sp, #0x10]                      
02d567c0: ldr     d8, [sp], #0x30                            
02d567c4: ret                                                
02d567c8: bl      #0x2b7105c                                 fn_2b7105c
#### CLASS Blindbag.ScanMachine parent= UnityEngine.MonoBehaviour
#   field _draggable                     bool                                               off=0x20 attr=1 HeaderAttribute,SerializeField
#   field _isOverUi                      bool                                               off=0x21 attr=1 SerializeField
#   field _isDown                        bool                                               off=0x22 attr=1 SerializeField
#   field _isProgressCompleted           bool                                               off=0x23 attr=1 SerializeField
#   field _billLinePrefab                Blindbag.BillLine                                  off=0x28 attr=1 HeaderAttribute,SerializeField
#   field _billContainer                 UnityEngine.Transform                              off=0x30 attr=1 SerializeField
#   field _totalText                     TMPro.TextMeshProUGUI                              off=0x38 attr=1 SerializeField
#   field _scanLineTf                    UnityEngine.Transform                              off=0x40 attr=1 SerializeField
#   field _scanPos                       UnityEngine.Transform                              off=0x48 attr=1 SerializeField
#   field _containerBag                  UnityEngine.Transform                              off=0x50 attr=1 SerializeField
#   field _topRight                      UnityEngine.Transform                              off=0x58 attr=1 SerializeField
#   field _bottomLeft                    UnityEngine.Transform                              off=0x60 attr=1 SerializeField
#   field _billGo                        UnityEngine.GameObject                             off=0x68 attr=1 SerializeField
#   field _introGo                       UnityEngine.GameObject                             off=0x70 attr=1 SerializeField
#   field _outroGo                       UnityEngine.GameObject                             off=0x78 attr=1 SerializeField
#   field _outroHeart                    UnityEngine.Transform                              off=0x80 attr=1 SerializeField
#   field _pinginCashier                 Spine.Unity.SkeletonAnimation                      off=0x88 attr=1 SerializeField
#   field _outroBag                      UnityEngine.Transform                              off=0x90 attr=1 SerializeField
#   field _cameraMain                    UnityEngine.Camera                                 off=0x98 attr=1 
#   field _clickable                     Jelly.IClickable                                   off=0xa0 attr=1 
#   field _hitItemStatus                 bool                                               off=0xa8 attr=1 
#   field _bagsDictionary                System.Collections.Generic.Dictionary`2<string,Blindbag.BillLine> off=0xb0 attr=1 
#   field _blindbagGameController        Blindbag.BlindbagGameController                    off=0xb8 attr=1 
#   field <OrderBags>k__BackingField     System.Collections.Generic.List`1<Blindbag.BlindBagAnimation> off=0xc0 attr=1 CompilerGeneratedAttribute
#   field _scanLineDoneTime              float                                              off=0xc8 attr=1 
## get_OrderBags() -> System.Collections.Generic.List`1<Blindbag.BlindBagAnimation>
---- Blindbag.ScanMachine::get_OrderBags 0x2d55688
02d55688: ldr     x0, [x0, #0xc0]                            .<OrderBags>k__BackingField
02d5568c: ret                                                
## set_OrderBags(System.Collections.Generic.List`1<Blindbag.BlindBagAnimation> value) -> void
---- Blindbag.ScanMachine::set_OrderBags 0x2d55690
02d55690: str     x1, [x0, #0xc0]!                           .<OrderBags>k__BackingField
02d55694: b       #0x2b70d54                                 
## OnEnable() -> void
---- Blindbag.ScanMachine::OnEnable 0x2d55698
02d55698: mov     w8, #1                                     
02d5569c: strb    w8, [x0, #0x20]                            ._draggable
02d556a0: ret                                                
## OnInitialized(Blindbag.BlindbagGameController blindbagGameController) -> void
---- Blindbag.ScanMachine::OnInitialized 0x2d516bc
02d516bc: stp     x30, x23, [sp, #-0x30]!                    
02d516c0: stp     x22, x21, [sp, #0x10]                      
02d516c4: stp     x20, x19, [sp, #0x20]                      
02d516c8: adrp    x23, #0x6630000                            
02d516cc: adrp    x22, #0x626b000                            
02d516d0: adrp    x21, #0x626b000                            
02d516d4: ldrb    w8, [x23, #0x274]                          
02d516d8: ldr     x22, [x22, #0x888]                         T:type54455(k15)
02d516dc: ldr     x21, [x21, #0x890]                         MS:System.Collections.Generic.Dictionary`2::.ctor
02d516e0: mov     x20, x1                                    
02d516e4: mov     x19, x0                                    
02d516e8: tbnz    w8, #0, #0x2d5170c                         
02d516ec: adrp    x0, #0x626b000                             
02d516f0: ldr     x0, [x0, #0x890]                           MS:System.Collections.Generic.Dictionary`2::.ctor
02d516f4: bl      #0x2b70db0                                 fn_2b70db0
02d516f8: adrp    x0, #0x626b000                             
02d516fc: ldr     x0, [x0, #0x888]                           T:type54455(k15)
02d51700: bl      #0x2b70db0                                 fn_2b70db0
02d51704: mov     w8, #1                                     
02d51708: strb    w8, [x23, #0x274]                          
02d5170c: mov     x0, xzr                                    
02d51710: bl      #0x5aefe28                                 UnityEngine.Camera::get_main
02d51714: mov     x1, x0                                     
02d51718: mov     x0, x19                                    
02d5171c: str     x1, [x0, #0x98]!                           ._cameraMain
02d51720: bl      #0x2b70d54                                 fn_2b70d54
02d51724: mov     x0, x19                                    
02d51728: mov     x1, x20                                    
02d5172c: str     x20, [x0, #0xb8]!                          ._blindbagGameController
02d51730: bl      #0x2b70d54                                 fn_2b70d54
02d51734: ldr     x0, [x22]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d51738: bl      #0x2b7104c                                 fn_2b7104c
02d5173c: ldr     x1, [x21]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d51740: mov     x20, x0                                    
02d51744: bl      #0x452b8a0                                 fn_452b8a0
02d51748: str     x20, [x19, #0xb0]!                         ._bagsDictionary
02d5174c: mov     x0, x19                                    
02d51750: mov     x1, x20                                    
02d51754: bl      #0x2b70d54                                 fn_2b70d54
02d51758: movi    d0, #0000000000000000                      
02d5175c: movi    d1, #0000000000000000                      
02d51760: ldur    x0, [x19, #-0x30]                          
02d51764: mov     x1, xzr                                    
02d51768: bl      #0x2d98c98                                 DG.Tweening.ShortcutExtensions::DOScale
02d5176c: ldur    x0, [x19, #-0x20]                          
02d51770: ldp     x20, x19, [sp, #0x20]                      
02d51774: ldp     x22, x21, [sp, #0x10]                      
02d51778: movi    d0, #0000000000000000                      
02d5177c: movi    d1, #0000000000000000                      
02d51780: mov     x1, xzr                                    
02d51784: ldp     x30, x23, [sp], #0x30                      
02d51788: b       #0x2d98c98                                 DG.Tweening.ShortcutExtensions::DOScale
## OnBuyCompleted() -> void
---- Blindbag.ScanMachine::OnBuyCompleted 0x2d51364
02d51364: stp     x30, x25, [sp, #-0x40]!                    
02d51368: stp     x24, x23, [sp, #0x10]                      
02d5136c: stp     x22, x21, [sp, #0x20]                      
02d51370: stp     x20, x19, [sp, #0x30]                      
02d51374: adrp    x20, #0x6630000                            
02d51378: mov     x19, x0                                    
02d5137c: ldrb    w8, [x20, #0x275]                          
02d51380: tbnz    w8, #0, #0x2d51434                         
02d51384: adrp    x0, #0x626b000                             
02d51388: ldr     x0, [x0, #0x840]                           T:type53118(k15)
02d5138c: bl      #0x2b70db0                                 fn_2b70db0
02d51390: adrp    x0, #0x626a000                             
02d51394: ldr     x0, [x0, #0x828]                           T:BlindBagCollection.BlindbagCollectionController
02d51398: bl      #0x2b70db0                                 fn_2b70db0
02d5139c: adrp    x0, #0x6266000                             
02d513a0: ldr     x0, [x0, #0x750]                           MS:DataManager::GetData
02d513a4: bl      #0x2b70db0                                 fn_2b70db0
02d513a8: adrp    x0, #0x626b000                             
02d513ac: ldr     x0, [x0, #0x848]                           MS:System.Linq.Enumerable::Select
02d513b0: bl      #0x2b70db0                                 fn_2b70db0
02d513b4: adrp    x0, #0x626b000                             
02d513b8: ldr     x0, [x0, #0x850]                           T:type55502(k15)
02d513bc: bl      #0x2b70db0                                 fn_2b70db0
02d513c0: adrp    x0, #0x626b000                             
02d513c4: ldr     x0, [x0, #0x858]                           MS:System.Collections.Generic.List`1::AddRange
02d513c8: bl      #0x2b70db0                                 fn_2b70db0
02d513cc: adrp    x0, #0x626b000                             
02d513d0: ldr     x0, [x0, #0x860]                           MS:System.Collections.Generic.List`1::ForEach
02d513d4: bl      #0x2b70db0                                 fn_2b70db0
02d513d8: adrp    x0, #0x6266000                             
02d513dc: ldr     x0, [x0, #0x658]                           MS:MonoSingleton`1::get_Instance
02d513e0: bl      #0x2b70db0                                 fn_2b70db0
02d513e4: adrp    x0, #0x6266000                             
02d513e8: ldr     x0, [x0, #0xe08]                           MS:DG.Tweening.TweenSettingsExtensions::SetDelay
02d513ec: bl      #0x2b70db0                                 fn_2b70db0
02d513f0: adrp    x0, #0x6266000                             
02d513f4: ldr     x0, [x0, #0x880]                           MS:DG.Tweening.TweenSettingsExtensions::SetEase
02d513f8: bl      #0x2b70db0                                 fn_2b70db0
02d513fc: adrp    x0, #0x626b000                             
02d51400: ldr     x0, [x0, #0x868]                           M:Blindbag.ScanMachine/<>c::<OnBuyCompleted>b__29_0
02d51404: bl      #0x2b70db0                                 fn_2b70db0
02d51408: adrp    x0, #0x626b000                             
02d5140c: ldr     x0, [x0, #0x870]                           M:Blindbag.ScanMachine/<>c::<OnBuyCompleted>b__29_1
02d51410: bl      #0x2b70db0                                 fn_2b70db0
02d51414: adrp    x0, #0x626b000                             
02d51418: ldr     x0, [x0, #0x878]                           T:Blindbag.ScanMachine/<>c
02d5141c: bl      #0x2b70db0                                 fn_2b70db0
02d51420: adrp    x0, #0x626b000                             
02d51424: ldr     x0, [x0, #0x880]                           S:'happy_idle'
02d51428: bl      #0x2b70db0                                 fn_2b70db0
02d5142c: mov     w8, #1                                     
02d51430: strb    w8, [x20, #0x275]                          
02d51434: ldr     x0, [x19, #0x70]                           ._introGo
02d51438: cbz     x0, #0x2d516b8                             
02d5143c: mov     w1, wzr                                    
02d51440: mov     x2, xzr                                    
02d51444: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d51448: ldr     x0, [x19, #0x68]                           ._billGo
02d5144c: cbz     x0, #0x2d516b8                             
02d51450: mov     w1, wzr                                    
02d51454: mov     x2, xzr                                    
02d51458: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d5145c: ldr     x0, [x19, #0x78]                           ._outroGo
02d51460: cbz     x0, #0x2d516b8                             
02d51464: adrp    x20, #0x6266000                            
02d51468: adrp    x21, #0x6266000                            
02d5146c: adrp    x24, #0x626b000                            
02d51470: ldr     x20, [x20, #0x880]                         MS:DG.Tweening.TweenSettingsExtensions::SetEase
02d51474: ldr     x21, [x21, #0xe08]                         MS:DG.Tweening.TweenSettingsExtensions::SetDelay
02d51478: ldr     x24, [x24, #0x878]                         T:Blindbag.ScanMachine/<>c
02d5147c: mov     w1, #1                                     
02d51480: mov     x2, xzr                                    
02d51484: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d51488: fmov    s0, #1.00000000                            
02d5148c: fmov    s1, #0.50000000                            
02d51490: ldr     x0, [x19, #0x80]                           ._outroHeart
02d51494: mov     x1, xzr                                    
02d51498: bl      #0x2d98c98                                 DG.Tweening.ShortcutExtensions::DOScale
02d5149c: ldr     x2, [x20]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d514a0: mov     w1, #0x1b                                  
02d514a4: bl      #0x336fa0c                                 fn_336fa0c
02d514a8: fmov    s0, #0.50000000                            
02d514ac: ldr     x1, [x21]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d514b0: bl      #0x336f7fc                                 fn_336f7fc
02d514b4: fmov    s0, #1.00000000                            
02d514b8: fmov    s1, #0.50000000                            
02d514bc: ldr     x0, [x19, #0x90]                           ._outroBag
02d514c0: mov     x1, xzr                                    
02d514c4: bl      #0x2d98c98                                 DG.Tweening.ShortcutExtensions::DOScale
02d514c8: ldr     x2, [x20]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d514cc: mov     w1, #0x1b                                  
02d514d0: bl      #0x336fa0c                                 fn_336fa0c
02d514d4: ldr     x0, [x24]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d514d8: ldr     x20, [x19, #0xc0]                          .<OrderBags>k__BackingField
02d514dc: ldr     w8, [x0, #0xe4]                            [626b0e4]=0 f=0,0
02d514e0: cbnz    w8, #0x2d514ec                             
02d514e4: bl      #0x2b70f30                                 fn_2b70f30
02d514e8: ldr     x0, [x24]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d514ec: ldr     x8, [x0, #0xb8]                            S:'scoop_no_thank' ._blindbagGameController
02d514f0: ldr     x21, [x8, #8]                              
02d514f4: cbnz    x21, #0x2d51550                            
02d514f8: ldr     w9, [x0, #0xe4]                            [626b0e4]=0 f=0,0
02d514fc: cbnz    w9, #0x2d5150c                             
02d51500: bl      #0x2b70f30                                 fn_2b70f30
02d51504: ldr     x8, [x24]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d51508: ldr     x8, [x8, #0xb8]                            
02d5150c: adrp    x9, #0x626b000                             
02d51510: ldr     x9, [x9, #0x840]                           T:type53118(k15)
02d51514: ldr     x22, [x8]                                  
02d51518: ldr     x0, [x9]                                   T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d5151c: bl      #0x2b7104c                                 fn_2b7104c
02d51520: adrp    x8, #0x626b000                             
02d51524: mov     x1, x22                                    
02d51528: mov     x3, xzr                                    
02d5152c: ldr     x8, [x8, #0x868]                           M:Blindbag.ScanMachine/<>c::<OnBuyCompleted>b__29_0
02d51530: mov     x21, x0                                    
02d51534: ldr     x2, [x8]                                   T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d51538: bl      #0x453418c                                 fn_453418c
02d5153c: ldr     x8, [x24]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d51540: mov     x1, x21                                    
02d51544: ldr     x0, [x8, #0xb8]                            S:'scoop_no_thank'
02d51548: str     x21, [x0, #8]!                             
02d5154c: bl      #0x2b70d54                                 fn_2b70d54
02d51550: cbz     x20, #0x2d516b8                            
02d51554: adrp    x8, #0x626b000                             
02d51558: adrp    x22, #0x626a000                            
02d5155c: mov     x0, x20                                    
02d51560: ldr     x8, [x8, #0x860]                           MS:System.Collections.Generic.List`1::ForEach
02d51564: ldr     x22, [x22, #0x828]                         T:BlindBagCollection.BlindbagCollectionController
02d51568: mov     x1, x21                                    
02d5156c: ldr     x2, [x8]                                   T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d51570: bl      #0x35a9ce4                                 fn_35a9ce4
02d51574: ldr     x8, [x22]                                  T:type56879(k15)
02d51578: ldr     w9, [x8, #0xe4]                            [626b0e4]=0 f=0,0
02d5157c: cbnz    w9, #0x2d5158c                             
02d51580: mov     x0, x8                                     
02d51584: bl      #0x2b70f30                                 fn_2b70f30
02d51588: ldr     x8, [x22]                                  T:type56879(k15)
02d5158c: ldr     x0, [x24]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d51590: ldr     x8, [x8, #0xb8]                            S:'scoop_no_thank'
02d51594: ldr     x21, [x19, #0xc0]                          .<OrderBags>k__BackingField
02d51598: ldr     w9, [x0, #0xe4]                            [626b0e4]=0 f=0,0
02d5159c: ldr     x20, [x8]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d515a0: cbnz    w9, #0x2d515ac                             
02d515a4: bl      #0x2b70f30                                 fn_2b70f30
02d515a8: ldr     x0, [x24]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d515ac: ldr     x8, [x0, #0xb8]                            S:'scoop_no_thank' ._blindbagGameController
02d515b0: adrp    x25, #0x626b000                            
02d515b4: ldr     x22, [x8, #0x10]                           MS:System.Collections.Generic.List`1::Find
02d515b8: ldr     x25, [x25, #0x848]                         MS:System.Linq.Enumerable::Select
02d515bc: cbnz    x22, #0x2d51618                            
02d515c0: ldr     w9, [x0, #0xe4]                            [626b0e4]=0 f=0,0
02d515c4: cbnz    w9, #0x2d515d4                             
02d515c8: bl      #0x2b70f30                                 fn_2b70f30
02d515cc: ldr     x8, [x24]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d515d0: ldr     x8, [x8, #0xb8]                            S:'scoop_no_thank'
02d515d4: adrp    x9, #0x626b000                             
02d515d8: ldr     x9, [x9, #0x850]                           T:type55502(k15)
02d515dc: ldr     x23, [x8]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d515e0: ldr     x0, [x9]                                   T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d515e4: bl      #0x2b7104c                                 fn_2b7104c
02d515e8: adrp    x8, #0x626b000                             
02d515ec: mov     x1, x23                                    
02d515f0: mov     x3, xzr                                    
02d515f4: ldr     x8, [x8, #0x870]                           M:Blindbag.ScanMachine/<>c::<OnBuyCompleted>b__29_1
02d515f8: mov     x22, x0                                    
02d515fc: ldr     x2, [x8]                                   T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d51600: bl      #0x4941168                                 fn_4941168
02d51604: ldr     x8, [x24]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d51608: mov     x1, x22                                    
02d5160c: ldr     x0, [x8, #0xb8]                            S:'scoop_no_thank'
02d51610: str     x22, [x0, #0x10]!                          
02d51614: bl      #0x2b70d54                                 fn_2b70d54
02d51618: ldr     x2, [x25]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d5161c: mov     x0, x21                                    
02d51620: mov     x1, x22                                    
02d51624: bl      #0x3192eec                                 fn_3192eec
02d51628: cbz     x20, #0x2d516b8                            
02d5162c: adrp    x8, #0x626b000                             
02d51630: mov     x1, x0                                     
02d51634: mov     x0, x20                                    
02d51638: ldr     x8, [x8, #0x858]                           MS:System.Collections.Generic.List`1::AddRange
02d5163c: ldr     x2, [x8]                                   T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d51640: bl      #0x3569e24                                 fn_3569e24
02d51644: ldr     x0, [x19, #0x88]                           ._pinginCashier
02d51648: cbz     x0, #0x2d516b8                             
02d5164c: mov     x1, xzr                                    
02d51650: bl      #0x4ff6f18                                 Spine.Unity.SkeletonAnimation::get_AnimationState
02d51654: cbz     x0, #0x2d516b8                             
02d51658: adrp    x8, #0x626b000                             
02d5165c: adrp    x19, #0x6266000                            
02d51660: mov     w1, wzr                                    
02d51664: ldr     x8, [x8, #0x880]                           S:'happy_idle'
02d51668: ldr     x19, [x19, #0x658]                         MS:MonoSingleton`1::get_Instance
02d5166c: mov     w3, #1                                     
02d51670: mov     x4, xzr                                    
02d51674: ldr     x2, [x8]                                   T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d51678: bl      #0x4f97234                                 Spine.AnimationState::SetAnimation
02d5167c: ldr     x0, [x19]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d51680: bl      #0x3769600                                 fn_3769600
02d51684: cbz     x0, #0x2d516b8                             
02d51688: adrp    x8, #0x6266000                             
02d5168c: ldr     x8, [x8, #0x750]                           MS:DataManager::GetData
02d51690: ldr     x1, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d51694: bl      #0x3168dd0                                 fn_3168dd0
02d51698: cbz     x0, #0x2d516b8                             
02d5169c: ldr     x8, [x0, #0x20]                            M:ScoopGame.CategoryAsset/<>c__DisplayClass4_0::<GetOptionDataByID>b__0 ._draggable
02d516a0: cbz     x8, #0x2d516b8                             
02d516a4: ldp     x20, x19, [sp, #0x30]                      
02d516a8: ldp     x22, x21, [sp, #0x20]                      
02d516ac: ldp     x24, x23, [sp, #0x10]                      
02d516b0: ldp     x30, x25, [sp], #0x40                      
02d516b4: ret                                                
02d516b8: bl      #0x2b7105c                                 fn_2b7105c
## SetActive(bool value) -> void
---- Blindbag.ScanMachine::SetActive 0x2d5178c
02d5178c: str     x30, [sp, #-0x20]!                         
02d51790: stp     x20, x19, [sp, #0x10]                      
02d51794: mov     w19, w1                                    
02d51798: mov     x1, xzr                                    
02d5179c: mov     x20, x0                                    
02d517a0: bl      #0x5b339ec                                 UnityEngine.Component::get_gameObject
02d517a4: cbz     x0, #0x2d517d0                             
02d517a8: and     w1, w19, #1                                
02d517ac: mov     x2, xzr                                    
02d517b0: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d517b4: ldr     x0, [x20, #0x70]                           ._introGo
02d517b8: cbz     x0, #0x2d517d0                             
02d517bc: and     w1, w19, #1                                
02d517c0: ldp     x20, x19, [sp, #0x10]                      
02d517c4: mov     x2, xzr                                    
02d517c8: ldr     x30, [sp], #0x20                           
02d517cc: b       #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d517d0: bl      #0x2b7105c                                 fn_2b7105c
## SetData(System.Collections.Generic.List`1<Blindbag.BlindBagAnimation> listOrderBag) -> void
---- Blindbag.ScanMachine::SetData 0x2d52314
02d52314: sub     sp, sp, #0xe0                              
02d52318: stp     d15, d14, [sp, #0x40]                      
02d5231c: stp     d13, d12, [sp, #0x50]                      
02d52320: stp     d11, d10, [sp, #0x60]                      
02d52324: stp     d9, d8, [sp, #0x70]                        
02d52328: stp     x29, x30, [sp, #0x80]                      
02d5232c: stp     x28, x27, [sp, #0x90]                      
02d52330: stp     x26, x25, [sp, #0xa0]                      
02d52334: stp     x24, x23, [sp, #0xb0]                      
02d52338: stp     x22, x21, [sp, #0xc0]                      
02d5233c: stp     x20, x19, [sp, #0xd0]                      
02d52340: adrp    x21, #0x6630000                            
02d52344: mov     x20, x1                                    
02d52348: mov     x19, x0                                    
02d5234c: ldrb    w8, [x21, #0x276]                          
02d52350: tbnz    w8, #0, #0x2d5241c                         
02d52354: adrp    x0, #0x626b000                             
02d52358: ldr     x0, [x0, #0x840]                           T:type53118(k15)
02d5235c: bl      #0x2b70db0                                 fn_2b70db0
02d52360: adrp    x0, #0x626b000                             
02d52364: ldr     x0, [x0, #0x900]                           MS:System.Collections.Generic.List`1/Enumerator::Dispose
02d52368: bl      #0x2b70db0                                 fn_2b70db0
02d5236c: adrp    x0, #0x626b000                             
02d52370: ldr     x0, [x0, #0x908]                           MS:System.Collections.Generic.List`1/Enumerator::MoveNext
02d52374: bl      #0x2b70db0                                 fn_2b70db0
02d52378: adrp    x0, #0x626b000                             
02d5237c: ldr     x0, [x0, #0x910]                           MS:System.Collections.Generic.List`1/Enumerator::get_Current
02d52380: bl      #0x2b70db0                                 fn_2b70db0
02d52384: adrp    x0, #0x626b000                             
02d52388: ldr     x0, [x0, #0x918]                           MS:System.Collections.Generic.List`1::GetEnumerator
02d5238c: bl      #0x2b70db0                                 fn_2b70db0
02d52390: adrp    x0, #0x626b000                             
02d52394: ldr     x0, [x0, #0x920]                           M:Blindbag.ScanMachine::OnScanItemHandler
02d52398: bl      #0x2b70db0                                 fn_2b70db0
02d5239c: adrp    x0, #0x6264000                             
02d523a0: ldr     x0, [x0, #0xe8]                            T:DG.Tweening.TweenCallback
02d523a4: bl      #0x2b70db0                                 fn_2b70db0
02d523a8: adrp    x0, #0x6266000                             
02d523ac: ldr     x0, [x0, #0xa88]                           MS:DG.Tweening.TweenSettingsExtensions::OnComplete
02d523b0: bl      #0x2b70db0                                 fn_2b70db0
02d523b4: adrp    x0, #0x6267000                             
02d523b8: ldr     x0, [x0, #0x8d8]                           MS:DG.Tweening.TweenSettingsExtensions::OnStart
02d523bc: bl      #0x2b70db0                                 fn_2b70db0
02d523c0: adrp    x0, #0x6266000                             
02d523c4: ldr     x0, [x0, #0xa90]                           MS:DG.Tweening.TweenSettingsExtensions::SetDelay
02d523c8: bl      #0x2b70db0                                 fn_2b70db0
02d523cc: adrp    x0, #0x6266000                             
02d523d0: ldr     x0, [x0, #0xe08]                           MS:DG.Tweening.TweenSettingsExtensions::SetDelay
02d523d4: bl      #0x2b70db0                                 fn_2b70db0
02d523d8: adrp    x0, #0x6266000                             
02d523dc: ldr     x0, [x0, #0x880]                           MS:DG.Tweening.TweenSettingsExtensions::SetEase
02d523e0: bl      #0x2b70db0                                 fn_2b70db0
02d523e4: adrp    x0, #0x626b000                             
02d523e8: ldr     x0, [x0, #0x928]                           M:Blindbag.ScanMachine/<>c::<SetData>b__31_0
02d523ec: bl      #0x2b70db0                                 fn_2b70db0
02d523f0: adrp    x0, #0x626b000                             
02d523f4: ldr     x0, [x0, #0x930]                           M:Blindbag.ScanMachine/<>c__DisplayClass31_0::<SetData>b__1
02d523f8: bl      #0x2b70db0                                 fn_2b70db0
02d523fc: adrp    x0, #0x626b000                             
02d52400: ldr     x0, [x0, #0x938]                           T:Blindbag.ScanMachine/<>c__DisplayClass31_0
02d52404: bl      #0x2b70db0                                 fn_2b70db0
02d52408: adrp    x0, #0x626b000                             
02d5240c: ldr     x0, [x0, #0x878]                           T:Blindbag.ScanMachine/<>c
02d52410: bl      #0x2b70db0                                 fn_2b70db0
02d52414: mov     w8, #1                                     
02d52418: strb    w8, [x21, #0x276]                          
02d5241c: mov     x21, x19                                   
02d52420: mov     x1, x20                                    
02d52424: stp     xzr, xzr, [sp, #0x20]                      
02d52428: str     x20, [x21, #0xc0]!                         .<OrderBags>k__BackingField
02d5242c: mov     x0, x21                                    
02d52430: str     xzr, [sp, #0x30]                           
02d52434: bl      #0x2b70d54                                 fn_2b70d54
02d52438: ldr     x0, [x21]                                  
02d5243c: cbz     x0, #0x2d528c4                             
02d52440: adrp    x8, #0x626b000                             
02d52444: adrp    x25, #0x626b000                            
02d52448: adrp    x29, #0x626b000                            
02d5244c: ldr     x8, [x8, #0x918]                           MS:System.Collections.Generic.List`1::GetEnumerator
02d52450: adrp    x20, #0x6266000                            
02d52454: adrp    x27, #0x6266000                            
02d52458: adrp    x28, #0x626b000                            
02d5245c: adrp    x26, #0x6267000                            
02d52460: ldr     x25, [x25, #0x908]                         MS:System.Collections.Generic.List`1/Enumerator::MoveNext
02d52464: ldr     x29, [x29, #0x938]                         T:Blindbag.ScanMachine/<>c__DisplayClass31_0
02d52468: ldr     x20, [x20, #0x880]                         MS:DG.Tweening.TweenSettingsExtensions::SetEase
02d5246c: ldr     x27, [x27, #0xe08]                         MS:DG.Tweening.TweenSettingsExtensions::SetDelay
02d52470: ldr     x28, [x28, #0x878]                         T:Blindbag.ScanMachine/<>c
02d52474: ldr     x26, [x26, #0x8d8]                         MS:DG.Tweening.TweenSettingsExtensions::OnStart
02d52478: ldr     x1, [x8]                                   T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d5247c: add     x8, sp, #8                                 
02d52480: bl      #0x35a9d9c                                 fn_35a9d9c
02d52484: ldr     x8, [sp, #0x18]                            
02d52488: ldur    q0, [sp, #8]                               
02d5248c: adrp    x10, #0x1084000                            
02d52490: add     x9, sp, #0x20                              
02d52494: ldr     s14, [x10, #0xeec]                         [1084eec]=457ff0003dcccccd f=0.1,4095
02d52498: movi    d8, #0000000000000000                      
02d5249c: str     x8, [sp, #0x30]                            
02d524a0: adrp    x8, #0x1084000                             
02d524a4: ldr     s15, [x8, #0xeb0]                          [1084eb0]=43b480003fb33333 f=1.4,361
02d524a8: str     q0, [sp, #0x20]                            
02d524ac: stp     xzr, x9, [sp, #8]                          
02d524b0: ldr     x1, [x25]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d524b4: add     x0, sp, #0x20                              
02d524b8: bl      #0x4690474                                 fn_4690474
02d524bc: tbz     w0, #0, #0x2d52844                         
02d524c0: ldr     x0, [x29]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d524c4: bl      #0x2b7104c                                 fn_2b7104c
02d524c8: mov     x1, xzr                                    
02d524cc: mov     x22, x0                                    
02d524d0: bl      #0x4e53e9c                                 System.Object::.ctor
02d524d4: cbz     x22, #0x2d528a0                            
02d524d8: mov     x0, x22                                    
02d524dc: str     x19, [x0, #0x18]!                          
02d524e0: mov     x1, x19                                    
02d524e4: bl      #0x2b70d54                                 fn_2b70d54
02d524e8: ldr     x1, [sp, #0x30]                            
02d524ec: mov     x21, x22                                   
02d524f0: str     x1, [x21, #0x10]!                          
02d524f4: mov     x0, x21                                    
02d524f8: bl      #0x2b70d54                                 fn_2b70d54
02d524fc: ldr     x0, [x21]                                  
02d52500: cbz     x0, #0x2d528a4                             
02d52504: mov     x1, xzr                                    
02d52508: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02d5250c: mov     w1, wzr                                    
02d52510: mov     x2, xzr                                    
02d52514: bl      #0x2d9d5d0                                 DG.Tweening.ShortcutExtensions::DOKill
02d52518: ldr     x0, [x21]                                  
02d5251c: cbz     x0, #0x2d52898                             
02d52520: mov     x1, xzr                                    
02d52524: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02d52528: cbz     x0, #0x2d5289c                             
02d5252c: ldr     x1, [x19, #0x50]                           ._containerBag
02d52530: mov     x2, xzr                                    
02d52534: bl      #0x5b472ec                                 UnityEngine.Transform::SetParent
02d52538: ldr     x0, [x21]                                  
02d5253c: cbz     x0, #0x2d52894                             
02d52540: mov     x1, xzr                                    
02d52544: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02d52548: adrp    x8, #0x662f000                             
02d5254c: mov     x23, x0                                    
02d52550: ldrb    w8, [x8, #0xa74]                           
02d52554: cbnz    w8, #0x2d52570                             
02d52558: adrp    x0, #0x6264000                             
02d5255c: ldr     x0, [x0, #0xd8]                            T:UnityEngine.Vector3
02d52560: bl      #0x2b70db0                                 fn_2b70db0
02d52564: adrp    x8, #0x662f000                             
02d52568: mov     w9, #1                                     
02d5256c: strb    w9, [x8, #0xa74]                           
02d52570: adrp    x8, #0x6264000                             
02d52574: ldr     x8, [x8, #0xd8]                            T:UnityEngine.Vector3
02d52578: ldr     x8, [x8]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d5257c: ldr     x8, [x8, #0xb8]                            MS:DG.Tweening.Core.Extensions::SetSpecialStartupMode
02d52580: ldp     s0, s1, [x8, #0xc]                         
02d52584: ldr     s2, [x8, #0x14]                            [6264014]=0 f=0,0
02d52588: fmul    s2, s2, s15                                
02d5258c: fmul    s0, s0, s15                                
02d52590: fmul    s1, s1, s15                                
02d52594: fmov    s3, #0.50000000                            
02d52598: mov     x0, x23                                    
02d5259c: mov     x1, xzr                                    
02d525a0: bl      #0x2d98af8                                 DG.Tweening.ShortcutExtensions::DOScale
02d525a4: ldr     x2, [x20]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d525a8: mov     w1, #1                                     
02d525ac: bl      #0x336fa0c                                 fn_336fa0c
02d525b0: fadd    s8, s8, s14                                
02d525b4: ldr     x1, [x27]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d525b8: fadd    s9, s8, s8                                 
02d525bc: fmov    s0, s9                                     
02d525c0: bl      #0x336f7fc                                 fn_336f7fc
02d525c4: mov     x23, x0                                    
02d525c8: ldr     x0, [x28]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d525cc: ldr     w8, [x0, #0xe4]                            [62640e4]=0 f=0,0
02d525d0: cbnz    w8, #0x2d525dc                             
02d525d4: bl      #0x2b70f30                                 fn_2b70f30
02d525d8: ldr     x0, [x28]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d525dc: ldr     x8, [x0, #0xb8]                            MS:DG.Tweening.Core.Extensions::SetSpecialStartupMode ._blindbagGameController
02d525e0: ldr     x24, [x8, #0x18]                           M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass2_0::<DOSetFloat>b__1
02d525e4: cbnz    x24, #0x2d52678                            
02d525e8: ldr     w9, [x0, #0xe4]                            [62640e4]=0 f=0,0
02d525ec: cbnz    w9, #0x2d525fc                             
02d525f0: bl      #0x2b70f30                                 fn_2b70f30
02d525f4: ldr     x8, [x28]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d525f8: ldr     x8, [x8, #0xb8]                            MS:DG.Tweening.Core.Extensions::SetSpecialStartupMode
02d525fc: str     x22, [sp]                                  
02d52600: mov     x22, x19                                   
02d52604: mov     x19, x26                                   
02d52608: mov     x26, x27                                   
02d5260c: mov     x27, x20                                   
02d52610: mov     x20, x29                                   
02d52614: mov     x29, x25                                   
02d52618: ldr     x25, [x8]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d5261c: adrp    x8, #0x6264000                             
02d52620: ldr     x8, [x8, #0xe8]                            T:DG.Tweening.TweenCallback
02d52624: ldr     x0, [x8]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d52628: bl      #0x2b7104c                                 fn_2b7104c
02d5262c: adrp    x8, #0x626b000                             
02d52630: mov     x24, x0                                    
02d52634: ldr     x8, [x8, #0x928]                           M:Blindbag.ScanMachine/<>c::<SetData>b__31_0
02d52638: ldr     x2, [x8]                                   T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d5263c: mov     x1, x25                                    
02d52640: mov     x3, xzr                                    
02d52644: bl      #0x2d89dc4                                 DG.Tweening.TweenCallback::.ctor
02d52648: ldr     x8, [x28]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d5264c: ldr     x0, [x8, #0xb8]                            S:'scoop_no_thank'
02d52650: str     x24, [x0, #0x18]!                          
02d52654: mov     x1, x24                                    
02d52658: bl      #0x2b70d54                                 fn_2b70d54
02d5265c: mov     x25, x29                                   
02d52660: mov     x29, x20                                   
02d52664: mov     x20, x27                                   
02d52668: mov     x27, x26                                   
02d5266c: mov     x26, x19                                   
02d52670: mov     x19, x22                                   
02d52674: ldr     x22, [sp]                                  
02d52678: ldr     x2, [x26]                                  S:'didu'
02d5267c: mov     x0, x23                                    
02d52680: mov     x1, x24                                    
02d52684: bl      #0x336f348                                 fn_336f348
02d52688: ldr     x0, [x19, #0x60]                           ._bottomLeft
02d5268c: cbz     x0, #0x2d528bc                             
02d52690: mov     x1, xzr                                    
02d52694: bl      #0x5b467ac                                 UnityEngine.Transform::get_position
02d52698: ldr     x0, [x19, #0x58]                           ._topRight
02d5269c: cbz     x0, #0x2d528b4                             
02d526a0: mov     x1, xzr                                    
02d526a4: fmov    s10, s0                                    
02d526a8: bl      #0x5b467ac                                 UnityEngine.Transform::get_position
02d526ac: ldr     x0, [x19, #0x60]                           ._bottomLeft
02d526b0: cbz     x0, #0x2d528b0                             
02d526b4: mov     x1, xzr                                    
02d526b8: fmov    s11, s0                                    
02d526bc: bl      #0x5b467ac                                 UnityEngine.Transform::get_position
02d526c0: ldr     x0, [x19, #0x58]                           ._topRight
02d526c4: cbz     x0, #0x2d528b8                             
02d526c8: mov     x1, xzr                                    
02d526cc: fmov    s12, s1                                    
02d526d0: bl      #0x5b467ac                                 UnityEngine.Transform::get_position
02d526d4: fmov    s13, s1                                    
02d526d8: fmov    s0, s10                                    
02d526dc: mov     x0, xzr                                    
02d526e0: fmov    s1, s11                                    
02d526e4: bl      #0x5b2dfc0                                 UnityEngine.Random::Range
02d526e8: fmov    s10, s0                                    
02d526ec: fmov    s0, s12                                    
02d526f0: mov     x0, xzr                                    
02d526f4: fmov    s1, s13                                    
02d526f8: bl      #0x5b2dfc0                                 UnityEngine.Random::Range
02d526fc: ldr     x0, [x21]                                  
02d52700: cbz     x0, #0x2d528c0                             
02d52704: mov     x1, xzr                                    
02d52708: fmov    s11, s0                                    
02d5270c: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02d52710: fmov    s0, s10                                    
02d52714: fmov    s1, s11                                    
02d52718: mov     w1, #1                                     
02d5271c: fmov    s2, s8                                     
02d52720: fmov    s3, #1.00000000                            
02d52724: mov     w2, wzr                                    
02d52728: fmov    s4, #0.50000000                            
02d5272c: mov     x3, xzr                                    
02d52730: bl      #0x2d9abb0                                 DG.Tweening.ShortcutExtensions::DOJump
02d52734: adrp    x8, #0x6266000                             
02d52738: ldr     x8, [x8, #0xa90]                           MS:DG.Tweening.TweenSettingsExtensions::SetDelay
02d5273c: ldr     x1, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d52740: fmov    s0, s9                                     
02d52744: bl      #0x336f7fc                                 fn_336f7fc
02d52748: adrp    x8, #0x6264000                             
02d5274c: mov     x23, x0                                    
02d52750: ldr     x8, [x8, #0xe8]                            T:DG.Tweening.TweenCallback
02d52754: ldr     x0, [x8]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d52758: bl      #0x2b7104c                                 fn_2b7104c
02d5275c: adrp    x8, #0x626b000                             
02d52760: mov     x24, x0                                    
02d52764: ldr     x8, [x8, #0x930]                           M:Blindbag.ScanMachine/<>c__DisplayClass31_0::<SetData>b__1
02d52768: ldr     x2, [x8]                                   T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d5276c: mov     x1, x22                                    
02d52770: mov     x3, xzr                                    
02d52774: bl      #0x2d89dc4                                 DG.Tweening.TweenCallback::.ctor
02d52778: adrp    x8, #0x6266000                             
02d5277c: ldr     x8, [x8, #0xa88]                           MS:DG.Tweening.TweenSettingsExtensions::OnComplete
02d52780: ldr     x2, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d52784: mov     x0, x23                                    
02d52788: mov     x1, x24                                    
02d5278c: bl      #0x336f26c                                 fn_336f26c
02d52790: ldr     x22, [x21]                                 
02d52794: cbz     x22, #0x2d528ac                            
02d52798: adrp    x8, #0x626b000                             
02d5279c: ldr     x23, [x22, #0x38]!                         
02d527a0: ldr     x8, [x8, #0x840]                           T:type53118(k15)
02d527a4: ldr     x0, [x8]                                   T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d527a8: bl      #0x2b7104c                                 fn_2b7104c
02d527ac: adrp    x8, #0x626b000                             
02d527b0: mov     x24, x0                                    
02d527b4: ldr     x8, [x8, #0x920]                           M:Blindbag.ScanMachine::OnScanItemHandler
02d527b8: ldr     x2, [x8]                                   T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d527bc: mov     x1, x19                                    
02d527c0: mov     x3, xzr                                    
02d527c4: bl      #0x453418c                                 fn_453418c
02d527c8: mov     x0, x23                                    
02d527cc: mov     x1, x24                                    
02d527d0: mov     x2, xzr                                    
02d527d4: bl      #0x4e570ac                                 System.Delegate::Combine
02d527d8: mov     x23, x0                                    
02d527dc: cbz     x0, #0x2d52824                             
02d527e0: adrp    x8, #0x626b000                             
02d527e4: mov     x0, x23                                    
02d527e8: ldr     x8, [x8, #0x840]                           T:type53118(k15)
02d527ec: ldr     x24, [x8]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d527f0: mov     x1, x24                                    
02d527f4: bl      #0x2b70f34                                 fn_2b70f34
02d527f8: cbz     x0, #0x2d52888                             
02d527fc: adrp    x8, #0x626b000                             
02d52800: ldr     x8, [x8, #0x840]                           T:type53118(k15)
02d52804: str     x0, [x22]                                  
02d52808: ldr     x24, [x8]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d5280c: mov     x0, x23                                    
02d52810: mov     x1, x24                                    
02d52814: bl      #0x2b70f34                                 fn_2b70f34
02d52818: mov     x1, x0                                     
02d5281c: cbnz    x1, #0x2d5282c                             
02d52820: b       #0x2d52888                                 
02d52824: mov     x1, xzr                                    
02d52828: str     xzr, [x22]                                 
02d5282c: mov     x0, x22                                    
02d52830: bl      #0x2b70d54                                 fn_2b70d54
02d52834: ldr     x0, [x21]                                  
02d52838: cbz     x0, #0x2d528a8                             
02d5283c: bl      #0x2d5050c                                 Blindbag.BlindBagAnimation::AddCollider
02d52840: b       #0x2d524b0                                 
02d52844: adrp    x8, #0x626b000                             
02d52848: add     x0, sp, #0x20                              
02d5284c: ldr     x8, [x8, #0x900]                           MS:System.Collections.Generic.List`1/Enumerator::Dispose
02d52850: ldr     x1, [x8]                                   T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d52854: bl      #0x4690470                                 fn_4690470
02d52858: ldp     x20, x19, [sp, #0xd0]                      
02d5285c: ldp     x22, x21, [sp, #0xc0]                      
02d52860: ldp     x24, x23, [sp, #0xb0]                      
02d52864: ldp     x26, x25, [sp, #0xa0]                      
02d52868: ldp     x28, x27, [sp, #0x90]                      
02d5286c: ldp     x29, x30, [sp, #0x80]                      
02d52870: ldp     d9, d8, [sp, #0x70]                        
02d52874: ldp     d11, d10, [sp, #0x60]                      
02d52878: ldp     d13, d12, [sp, #0x50]                      
02d5287c: ldp     d15, d14, [sp, #0x40]                      
02d52880: add     sp, sp, #0xe0                              
02d52884: ret                                                
02d52888: mov     x0, x23                                    
02d5288c: mov     x1, x24                                    
02d52890: bl      #0x2b713dc                                 fn_2b713dc
02d52894: bl      #0x2b7105c                                 fn_2b7105c
02d52898: bl      #0x2b7105c                                 fn_2b7105c
02d5289c: bl      #0x2b7105c                                 fn_2b7105c
02d528a0: bl      #0x2b7105c                                 fn_2b7105c
02d528a4: bl      #0x2b7105c                                 fn_2b7105c
02d528a8: bl      #0x2b7105c                                 fn_2b7105c
02d528ac: bl      #0x2b7105c                                 fn_2b7105c
02d528b0: bl      #0x2b7105c                                 fn_2b7105c
02d528b4: bl      #0x2b7105c                                 fn_2b7105c
02d528b8: bl      #0x2b7105c                                 fn_2b7105c
02d528bc: bl      #0x2b7105c                                 fn_2b7105c
02d528c0: bl      #0x2b7105c                                 fn_2b7105c
02d528c4: bl      #0x2b7105c                                 fn_2b7105c
02d528c8: b       #0x2d52974                                 
02d528cc: b       #0x2d52974                                 
02d528d0: b       #0x2d52974                                 
02d528d4: b       #0x2d52974                                 
02d528d8: b       #0x2d52974                                 
02d528dc: b       #0x2d52974                                 
02d528e0: b       #0x2d52974                                 
02d528e4: b       #0x2d52974                                 
02d528e8: b       #0x2d52974                                 
02d528ec: b       #0x2d52974                                 
02d528f0: b       #0x2d52974                                 
02d528f4: b       #0x2d52974                                 
02d528f8: b       #0x2d52974                                 
02d528fc: b       #0x2d52974                                 
02d52900: b       #0x2d52974                                 
02d52904: b       #0x2d52974                                 
02d52908: b       #0x2d52974                                 
02d5290c: b       #0x2d52974                                 
02d52910: b       #0x2d52974                                 
02d52914: b       #0x2d52974                                 
02d52918: b       #0x2d52974                                 
02d5291c: b       #0x2d52974                                 
02d52920: b       #0x2d52974                                 
02d52924: b       #0x2d52974                                 
02d52928: b       #0x2d52974                                 
02d5292c: b       #0x2d52974                                 
02d52930: b       #0x2d52974                                 
02d52934: b       #0x2d52974                                 
02d52938: b       #0x2d52974                                 
02d5293c: b       #0x2d52974                                 
02d52940: b       #0x2d52974                                 
02d52944: b       #0x2d52974                                 
02d52948: b       #0x2d52974                                 
02d5294c: b       #0x2d52974                                 
02d52950: b       #0x2d52974                                 
02d52954: b       #0x2d52974                                 
02d52958: b       #0x2d52974                                 
02d5295c: b       #0x2d52974                                 
02d52960: b       #0x2d52974                                 
02d52964: b       #0x2d52974                                 
02d52968: b       #0x2d52974                                 
02d5296c: b       #0x2d52974                                 
02d52970: b       #0x2d52974                                 
02d52974: mov     x19, x0                                    
02d52978: cmp     w1, #1                                     
02d5297c: b.ne    #0x2d529b8                                 
02d52980: mov     x0, x19                                    
02d52984: bl      #0x5e90260                                 fn_5e90260
02d52988: ldr     x19, [x0]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d5298c: str     x19, [sp, #8]                              
02d52990: bl      #0x5e90270                                 fn_5e90270
02d52994: adrp    x8, #0x626b000                             
02d52998: ldr     x0, [sp, #0x10]                            
02d5299c: ldr     x8, [x8, #0x900]                           MS:System.Collections.Generic.List`1/Enumerator::Dispose
02d529a0: ldr     x1, [x8]                                   T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d529a4: bl      #0x4690470                                 fn_4690470
02d529a8: cbz     x19, #0x2d52858                            
02d529ac: mov     x0, x19                                    
02d529b0: bl      #0x2b71054                                 fn_2b71054
02d529b4: mov     x19, x0                                    
02d529b8: add     x0, sp, #8                                 
02d529bc: bl      #0x2738770                                 fn_2738770
02d529c0: mov     x0, x19                                    
02d529c4: bl      #0x2c6051c                                 fn_2c6051c
02d529c8: bl      #0x27369b8                                 fn_27369b8
## OnScanItemHandler(Blindbag.BlindBagAnimation bag) -> void
---- Blindbag.ScanMachine::OnScanItemHandler 0x2d556ac
02d556ac: stp     x30, x23, [sp, #-0x30]!                    
02d556b0: stp     x22, x21, [sp, #0x10]                      
02d556b4: stp     x20, x19, [sp, #0x20]                      
02d556b8: adrp    x20, #0x6630000                            
02d556bc: adrp    x22, #0x626b000                            
02d556c0: mov     x21, x1                                    
02d556c4: ldrb    w8, [x20, #0x277]                          
02d556c8: ldr     x22, [x22, #0x9b8]                         T:Blindbag.ScanMachine/<>c__DisplayClass32_0
02d556cc: mov     x19, x0                                    
02d556d0: tbnz    w8, #0, #0x2d55718                         
02d556d4: adrp    x0, #0x6264000                             
02d556d8: ldr     x0, [x0, #0xf90]                           T:System.Action
02d556dc: bl      #0x2b70db0                                 fn_2b70db0
02d556e0: adrp    x0, #0x626a000                             
02d556e4: ldr     x0, [x0, #0x730]                           MS:MonoSingleton`1::get_Instance
02d556e8: bl      #0x2b70db0                                 fn_2b70db0
02d556ec: adrp    x0, #0x626b000                             
02d556f0: ldr     x0, [x0, #0x9c0]                           M:Blindbag.ScanMachine/<>c__DisplayClass32_0::<OnScanItemHandler>b__0
02d556f4: bl      #0x2b70db0                                 fn_2b70db0
02d556f8: adrp    x0, #0x626b000                             
02d556fc: ldr     x0, [x0, #0x9c8]                           M:Blindbag.ScanMachine/<>c__DisplayClass32_0::<OnScanItemHandler>b__1
02d55700: bl      #0x2b70db0                                 fn_2b70db0
02d55704: adrp    x0, #0x626b000                             
02d55708: ldr     x0, [x0, #0x9b8]                           T:Blindbag.ScanMachine/<>c__DisplayClass32_0
02d5570c: bl      #0x2b70db0                                 fn_2b70db0
02d55710: mov     w8, #1                                     
02d55714: strb    w8, [x20, #0x277]                          
02d55718: ldr     x0, [x22]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d5571c: bl      #0x2b7104c                                 fn_2b7104c
02d55720: mov     x1, xzr                                    
02d55724: mov     x20, x0                                    
02d55728: bl      #0x4e53e9c                                 System.Object::.ctor
02d5572c: cbz     x20, #0x2d5582c                            
02d55730: mov     x0, x20                                    
02d55734: mov     x1, x19                                    
02d55738: str     x19, [x0, #0x10]!                          
02d5573c: bl      #0x2b70d54                                 fn_2b70d54
02d55740: mov     x0, x20                                    
02d55744: mov     x1, x21                                    
02d55748: str     x21, [x0, #0x18]!                          
02d5574c: bl      #0x2b70d54                                 fn_2b70d54
02d55750: ldr     x0, [x19, #0x70]                           ._introGo
02d55754: cbz     x0, #0x2d5582c                             
02d55758: mov     w1, wzr                                    
02d5575c: mov     x2, xzr                                    
02d55760: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d55764: ldr     x0, [x19, #0x68]                           ._billGo
02d55768: cbz     x0, #0x2d5582c                             
02d5576c: mov     w1, #1                                     
02d55770: mov     x2, xzr                                    
02d55774: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d55778: mov     x0, xzr                                    
02d5577c: bl      #0x2d6eec8                                 Framework.AudioManager::get_Instance
02d55780: cbz     x0, #0x2d5582c                             
02d55784: movi    d1, #0000000000000000                      
02d55788: movi    d2, #0000000000000000                      
02d5578c: adrp    x21, #0x626a000                            
02d55790: fmov    s0, #1.00000000                            
02d55794: ldr     x21, [x21, #0x730]                         MS:MonoSingleton`1::get_Instance
02d55798: mov     w1, #0x3b                                  
02d5579c: mov     w2, wzr                                    
02d557a0: mov     w3, wzr                                    
02d557a4: mov     x4, xzr                                    
02d557a8: bl      #0x2d6f03c                                 Framework.AudioManager::PlaySound
02d557ac: ldr     x0, [x21]                                  T:type56879(k15)
02d557b0: bl      #0x3769600                                 fn_3769600
02d557b4: cbz     x0, #0x2d5582c                             
02d557b8: adrp    x22, #0x6264000                            
02d557bc: adrp    x21, #0x626b000                            
02d557c0: adrp    x23, #0x626b000                            
02d557c4: ldr     x22, [x22, #0xf90]                         T:System.Action
02d557c8: ldr     x21, [x21, #0x9c0]                         M:Blindbag.ScanMachine/<>c__DisplayClass32_0::<OnScanItemHandler>b__0
02d557cc: ldr     x23, [x23, #0x9c8]                         M:Blindbag.ScanMachine/<>c__DisplayClass32_0::<OnScanItemHandler>b__1
02d557d0: mov     w1, wzr                                    
02d557d4: bl      #0x2d522b8                                 Blindbag.TutorialBlindBag::ShowTutorialScanItem
02d557d8: ldr     x0, [x22]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d557dc: bl      #0x2b7104c                                 fn_2b7104c
02d557e0: ldr     x2, [x21]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d557e4: mov     x1, x20                                    
02d557e8: mov     x3, xzr                                    
02d557ec: mov     x21, x0                                    
02d557f0: bl      #0x4d8ddbc                                 System.Action::.ctor
02d557f4: ldr     x0, [x22]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d557f8: bl      #0x2b7104c                                 fn_2b7104c
02d557fc: ldr     x2, [x23]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d55800: mov     x1, x20                                    
02d55804: mov     x3, xzr                                    
02d55808: mov     x22, x0                                    
02d5580c: bl      #0x4d8ddbc                                 System.Action::.ctor
02d55810: mov     x0, x19                                    
02d55814: mov     x1, x21                                    
02d55818: mov     x2, x22                                    
02d5581c: ldp     x20, x19, [sp, #0x20]                      
02d55820: ldp     x22, x21, [sp, #0x10]                      
02d55824: ldp     x30, x23, [sp], #0x30                      
02d55828: b       #0x2d55838                                 Blindbag.ScanMachine::ScanAnimation
02d5582c: bl      #0x2b7105c                                 fn_2b7105c
## CheckOrderingCompleted() -> void
---- Blindbag.ScanMachine::CheckOrderingCompleted 0x2d55a5c
02d55a5c: stp     x30, x19, [sp, #-0x10]!                    
02d55a60: mov     x19, x0                                    
02d55a64: ldr     x0, [x0, #0x50]                            ._containerBag
02d55a68: cbz     x0, #0x2d55a94                             
02d55a6c: mov     x1, xzr                                    
02d55a70: bl      #0x5b482c4                                 UnityEngine.Transform::get_childCount
02d55a74: cmp     w0, #1                                     
02d55a78: b.ne    #0x2d55a8c                                 
02d55a7c: ldr     x0, [x19, #0xb8]                           ._blindbagGameController
02d55a80: cbz     x0, #0x2d55a94                             
02d55a84: ldp     x30, x19, [sp], #0x10                      
02d55a88: b       #0x2d51340                                 Blindbag.BlindbagGameController::OrderingCompletedHandler
02d55a8c: ldp     x30, x19, [sp], #0x10                      
02d55a90: ret                                                
02d55a94: bl      #0x2b7105c                                 fn_2b7105c
## UpdateTotalText() -> void
---- Blindbag.ScanMachine::UpdateTotalText 0x2d55a98
02d55a98: str     x30, [sp, #-0x40]!                         
02d55a9c: stp     x24, x23, [sp, #0x10]                      
02d55aa0: stp     x22, x21, [sp, #0x20]                      
02d55aa4: stp     x20, x19, [sp, #0x30]                      
02d55aa8: adrp    x20, #0x6630000                            
02d55aac: adrp    x23, #0x626b000                            
02d55ab0: mov     x19, x0                                    
02d55ab4: ldrb    w8, [x20, #0x278]                          
02d55ab8: ldr     x23, [x23, #0x878]                         T:Blindbag.ScanMachine/<>c
02d55abc: tbnz    w8, #0, #0x2d55af8                         
02d55ac0: adrp    x0, #0x626b000                             
02d55ac4: ldr     x0, [x0, #0x9e0]                           MS:System.Linq.Enumerable::Sum
02d55ac8: bl      #0x2b70db0                                 fn_2b70db0
02d55acc: adrp    x0, #0x626b000                             
02d55ad0: ldr     x0, [x0, #0x9e8]                           T:type55446(k15)
02d55ad4: bl      #0x2b70db0                                 fn_2b70db0
02d55ad8: adrp    x0, #0x626b000                             
02d55adc: ldr     x0, [x0, #0x9f0]                           M:Blindbag.ScanMachine/<>c::<UpdateTotalText>b__34_0
02d55ae0: bl      #0x2b70db0                                 fn_2b70db0
02d55ae4: adrp    x0, #0x626b000                             
02d55ae8: ldr     x0, [x0, #0x878]                           T:Blindbag.ScanMachine/<>c
02d55aec: bl      #0x2b70db0                                 fn_2b70db0
02d55af0: mov     w8, #1                                     
02d55af4: strb    w8, [x20, #0x278]                          
02d55af8: ldr     x0, [x23]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d55afc: ldr     x20, [x19, #0xb0]                          ._bagsDictionary
02d55b00: str     wzr, [sp, #0xc]                            
02d55b04: ldr     w8, [x0, #0xe4]                            [626b0e4]=0 f=0,0
02d55b08: cbnz    w8, #0x2d55b14                             
02d55b0c: bl      #0x2b70f30                                 fn_2b70f30
02d55b10: ldr     x0, [x23]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d55b14: ldr     x8, [x0, #0xb8]                            S:'scoop_no_thank' ._blindbagGameController
02d55b18: adrp    x24, #0x626b000                            
02d55b1c: ldr     x21, [x8, #0x20]                           
02d55b20: ldr     x24, [x24, #0x9e0]                         MS:System.Linq.Enumerable::Sum
02d55b24: cbnz    x21, #0x2d55b80                            
02d55b28: ldr     w9, [x0, #0xe4]                            [626b0e4]=0 f=0,0
02d55b2c: cbnz    w9, #0x2d55b3c                             
02d55b30: bl      #0x2b70f30                                 fn_2b70f30
02d55b34: ldr     x8, [x23]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d55b38: ldr     x8, [x8, #0xb8]                            
02d55b3c: adrp    x9, #0x626b000                             
02d55b40: ldr     x9, [x9, #0x9e8]                           T:type55446(k15)
02d55b44: ldr     x22, [x8]                                  
02d55b48: ldr     x0, [x9]                                   T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d55b4c: bl      #0x2b7104c                                 fn_2b7104c
02d55b50: adrp    x8, #0x626b000                             
02d55b54: mov     x1, x22                                    
02d55b58: mov     x3, xzr                                    
02d55b5c: ldr     x8, [x8, #0x9f0]                           M:Blindbag.ScanMachine/<>c::<UpdateTotalText>b__34_0
02d55b60: mov     x21, x0                                    
02d55b64: ldr     x2, [x8]                                   T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d55b68: bl      #0x4937998                                 fn_4937998
02d55b6c: ldr     x8, [x23]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d55b70: mov     x1, x21                                    
02d55b74: ldr     x0, [x8, #0xb8]                            S:'scoop_no_thank'
02d55b78: str     x21, [x0, #0x20]!                          ._draggable
02d55b7c: bl      #0x2b70d54                                 fn_2b70d54
02d55b80: ldr     x2, [x24]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d55b84: mov     x0, x20                                    
02d55b88: mov     x1, x21                                    
02d55b8c: bl      #0x319ba74                                 fn_319ba74
02d55b90: ldr     x19, [x19, #0x38]                          ._totalText
02d55b94: str     w0, [sp, #0xc]                             
02d55b98: add     x0, sp, #0xc                               
02d55b9c: mov     x1, xzr                                    
02d55ba0: bl      #0x4e0ea3c                                 System.Int32::ToString
02d55ba4: cbz     x19, #0x2d55bd4                            
02d55ba8: ldr     x8, [x19]                                  
02d55bac: mov     x1, x0                                     
02d55bb0: mov     x0, x19                                    
02d55bb4: ldr     x9, [x8, #0x558]                           MS:UnityEngine.Object::Instantiate
02d55bb8: ldr     x2, [x8, #0x560]                           M:ScoopGame.SelectCard::OnBtnAdUnlockClick
02d55bbc: blr     x9                                         
02d55bc0: ldp     x20, x19, [sp, #0x30]                      
02d55bc4: ldp     x22, x21, [sp, #0x20]                      
02d55bc8: ldp     x24, x23, [sp, #0x10]                      
02d55bcc: ldr     x30, [sp], #0x40                           
02d55bd0: ret                                                
02d55bd4: bl      #0x2b7105c                                 fn_2b7105c
## ScanAnimation(System.Action onTriggerBillLine, System.Action onAnimationCompleted) -> void
---- Blindbag.ScanMachine::ScanAnimation 0x2d55838
02d55838: stp     x30, x25, [sp, #-0x40]!                    
02d5583c: stp     x24, x23, [sp, #0x10]                      
02d55840: stp     x22, x21, [sp, #0x20]                      
02d55844: stp     x20, x19, [sp, #0x30]                      
02d55848: adrp    x20, #0x6630000                            
02d5584c: adrp    x23, #0x626b000                            
02d55850: mov     x21, x2                                    
02d55854: ldrb    w8, [x20, #0x279]                          
02d55858: ldr     x23, [x23, #0x9d0]                         T:Blindbag.ScanMachine/<>c__DisplayClass36_0
02d5585c: mov     x22, x1                                    
02d55860: mov     x19, x0                                    
02d55864: tbnz    w8, #0, #0x2d558ac                         
02d55868: adrp    x0, #0x6264000                             
02d5586c: ldr     x0, [x0, #0xe8]                            T:DG.Tweening.TweenCallback
02d55870: bl      #0x2b70db0                                 fn_2b70db0
02d55874: adrp    x0, #0x6266000                             
02d55878: ldr     x0, [x0, #0x928]                           MS:DG.Tweening.TweenSettingsExtensions::OnComplete
02d5587c: bl      #0x2b70db0                                 fn_2b70db0
02d55880: adrp    x0, #0x6266000                             
02d55884: ldr     x0, [x0, #0x880]                           MS:DG.Tweening.TweenSettingsExtensions::SetEase
02d55888: bl      #0x2b70db0                                 fn_2b70db0
02d5588c: adrp    x0, #0x626b000                             
02d55890: ldr     x0, [x0, #0x9d8]                           M:Blindbag.ScanMachine/<>c__DisplayClass36_0::<ScanAnimation>b__0
02d55894: bl      #0x2b70db0                                 fn_2b70db0
02d55898: adrp    x0, #0x626b000                             
02d5589c: ldr     x0, [x0, #0x9d0]                           T:Blindbag.ScanMachine/<>c__DisplayClass36_0
02d558a0: bl      #0x2b70db0                                 fn_2b70db0
02d558a4: mov     w8, #1                                     
02d558a8: strb    w8, [x20, #0x279]                          
02d558ac: ldr     x0, [x23]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d558b0: bl      #0x2b7104c                                 fn_2b7104c
02d558b4: mov     x1, xzr                                    
02d558b8: mov     x20, x0                                    
02d558bc: bl      #0x4e53e9c                                 System.Object::.ctor
02d558c0: cbz     x20, #0x2d55a58                            
02d558c4: mov     x0, x20                                    
02d558c8: mov     x1, x22                                    
02d558cc: str     x22, [x0, #0x10]!                          
02d558d0: bl      #0x2b70d54                                 fn_2b70d54
02d558d4: mov     x0, x20                                    
02d558d8: mov     x1, x19                                    
02d558dc: str     x19, [x0, #0x18]!                          
02d558e0: bl      #0x2b70d54                                 fn_2b70d54
02d558e4: mov     x0, x20                                    
02d558e8: mov     x1, x21                                    
02d558ec: str     x21, [x0, #0x20]!                          ._draggable
02d558f0: bl      #0x2b70d54                                 fn_2b70d54
02d558f4: adrp    x22, #0x662f000                            
02d558f8: ldr     x21, [x19, #0x40]                          ._scanLineTf
02d558fc: ldrb    w8, [x22, #0x918]                          
02d55900: cbnz    w8, #0x2d55918                             
02d55904: adrp    x0, #0x6264000                             
02d55908: ldr     x0, [x0, #0xd8]                            T:UnityEngine.Vector3
02d5590c: bl      #0x2b70db0                                 fn_2b70db0
02d55910: mov     w8, #1                                     
02d55914: strb    w8, [x22, #0x918]                          
02d55918: cbz     x21, #0x2d55a58                            
02d5591c: adrp    x22, #0x6264000                            
02d55920: mov     w9, #0xcccd                                
02d55924: mov     x0, x21                                    
02d55928: ldr     x22, [x22, #0xd8]                          T:UnityEngine.Vector3
02d5592c: movk    w9, #0xbecc, lsl #16                       
02d55930: mov     x1, xzr                                    
02d55934: dup     v0.2s, w9                                  
02d55938: adrp    x9, #0x1084000                             
02d5593c: ldr     x8, [x22]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d55940: ldr     s2, [x9, #0xc0c]                           [1084c0c]=3fc33333becccccd f=-0.4,1.525
02d55944: ldr     x8, [x8, #0xb8]                            
02d55948: ldr     d1, [x8, #0x18]                            
02d5594c: fmul    v0.2s, v1.2s, v0.2s                        
02d55950: ldr     s1, [x8, #0x20]                            
02d55954: fmul    s2, s1, s2                                 
02d55958: mov     s1, v0.s[1]                                
02d5595c: bl      #0x5b45cec                                 UnityEngine.Transform::set_localPosition
02d55960: adrp    x23, #0x662f000                            
02d55964: ldr     x21, [x19, #0x40]                          ._scanLineTf
02d55968: ldrb    w8, [x23, #0xa74]                          
02d5596c: cbnz    w8, #0x2d55984                             
02d55970: adrp    x0, #0x6264000                             
02d55974: ldr     x0, [x0, #0xd8]                            T:UnityEngine.Vector3
02d55978: bl      #0x2b70db0                                 fn_2b70db0
02d5597c: mov     w8, #1                                     
02d55980: strb    w8, [x23, #0xa74]                          
02d55984: cbz     x21, #0x2d55a58                            
02d55988: ldr     x8, [x22]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d5598c: movi    v0.2s, #0x3f, lsl #24                      
02d55990: adrp    x22, #0x6266000                            
02d55994: adrp    x23, #0x6264000                            
02d55998: adrp    x24, #0x626b000                            
02d5599c: adrp    x25, #0x6266000                            
02d559a0: ldr     x8, [x8, #0xb8]                            
02d559a4: mov     x0, x21                                    
02d559a8: mov     x1, xzr                                    
02d559ac: ldur    d1, [x8, #0xc]                             
02d559b0: ldr     x22, [x22, #0x880]                         MS:DG.Tweening.TweenSettingsExtensions::SetEase
02d559b4: ldr     s2, [x8, #0x14]                            
02d559b8: ldr     x23, [x23, #0xe8]                          T:DG.Tweening.TweenCallback
02d559bc: ldr     x24, [x24, #0x9d8]                         M:Blindbag.ScanMachine/<>c__DisplayClass36_0::<ScanAnimation>b__0
02d559c0: ldr     x25, [x25, #0x928]                         MS:DG.Tweening.TweenSettingsExtensions::OnComplete
02d559c4: fmul    v0.2s, v1.2s, v0.2s                        
02d559c8: fmov    s1, #0.50000000                            
02d559cc: fmul    s2, s2, s1                                 
02d559d0: mov     s1, v0.s[1]                                
02d559d4: bl      #0x5b470cc                                 UnityEngine.Transform::set_localScale
02d559d8: mov     x0, xzr                                    
02d559dc: bl      #0x5b432fc                                 UnityEngine.Time::get_time
02d559e0: fmov    s1, #1.00000000                            
02d559e4: adrp    x8, #0x1084000                             
02d559e8: ldr     x0, [x19, #0x40]                           ._scanLineTf
02d559ec: mov     w1, wzr                                    
02d559f0: mov     x2, xzr                                    
02d559f4: fadd    s0, s0, s1                                 
02d559f8: fmov    s1, #0.50000000                            
02d559fc: str     s0, [x19, #0xc8]                           ._scanLineDoneTime
02d55a00: ldr     s0, [x8, #0xca0]                           [1084ca0]=3eaaaaab3f19999a f=0.6,0.333333
02d55a04: bl      #0x2d98060                                 DG.Tweening.ShortcutExtensions::DOLocalMoveY
02d55a08: ldr     x2, [x22]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d55a0c: mov     w1, #1                                     
02d55a10: bl      #0x336fa0c                                 fn_336fa0c
02d55a14: ldr     x8, [x23]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d55a18: mov     x19, x0                                    
02d55a1c: mov     x0, x8                                     
02d55a20: bl      #0x2b7104c                                 fn_2b7104c
02d55a24: ldr     x2, [x24]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d55a28: mov     x1, x20                                    
02d55a2c: mov     x3, xzr                                    
02d55a30: mov     x21, x0                                    
02d55a34: bl      #0x2d89dc4                                 DG.Tweening.TweenCallback::.ctor
02d55a38: mov     x0, x19                                    
02d55a3c: mov     x1, x21                                    
02d55a40: ldr     x2, [x25]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d55a44: ldp     x20, x19, [sp, #0x30]                      
02d55a48: ldp     x22, x21, [sp, #0x20]                      
02d55a4c: ldp     x24, x23, [sp, #0x10]                      
02d55a50: ldp     x30, x25, [sp], #0x40                      
02d55a54: b       #0x336f26c                                 
02d55a58: bl      #0x2b7105c                                 fn_2b7105c
## Update() -> void
---- Blindbag.ScanMachine::Update 0x2d55be0
02d55be0: str     x30, [sp, #-0x20]!                         
02d55be4: stp     x20, x19, [sp, #0x10]                      
02d55be8: adrp    x20, #0x6630000                            
02d55bec: mov     x19, x0                                    
02d55bf0: ldrb    w8, [x20, #0x27a]                          
02d55bf4: tbnz    w8, #0, #0x2d55c0c                         
02d55bf8: adrp    x0, #0x6266000                             
02d55bfc: ldr     x0, [x0, #0x948]                           T:Touch
02d55c00: bl      #0x2b70db0                                 fn_2b70db0
02d55c04: mov     w8, #1                                     
02d55c08: strb    w8, [x20, #0x27a]                          
02d55c0c: ldrb    w8, [x19, #0x23]                           ._isProgressCompleted
02d55c10: cbz     w8, #0x2d55c20                             
02d55c14: ldp     x20, x19, [sp, #0x10]                      
02d55c18: ldr     x30, [sp], #0x20                           
02d55c1c: ret                                                
02d55c20: adrp    x20, #0x662f000                            
02d55c24: ldrb    w8, [x20, #0xbd9]                          
02d55c28: cbnz    w8, #0x2d55c40                             
02d55c2c: adrp    x0, #0x6266000                             
02d55c30: ldr     x0, [x0, #0x950]                           T:UnityEngine.InputSystem.Pointer
02d55c34: bl      #0x2b70db0                                 fn_2b70db0
02d55c38: mov     w8, #1                                     
02d55c3c: strb    w8, [x20, #0xbd9]                          
02d55c40: adrp    x8, #0x6266000                             
02d55c44: ldr     x8, [x8, #0x950]                           T:UnityEngine.InputSystem.Pointer
02d55c48: ldr     x8, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d55c4c: ldr     x8, [x8, #0xb8]                            S:'banner_native_refresh_time'
02d55c50: ldr     x20, [x8]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d55c54: cbz     x20, #0x2d55c14                            
02d55c58: ldrb    w8, [x19, #0x20]                           ._draggable
02d55c5c: cbz     w8, #0x2d55c14                             
02d55c60: ldr     x0, [x20, #0x1a8]                          [662f1a8]=600006c f=2.40744e-35,0
02d55c64: cbz     x0, #0x2d55d28                             
02d55c68: mov     x1, xzr                                    
02d55c6c: bl      #0x55532f0                                 UnityEngine.InputSystem.Controls.ButtonControl::get_wasPressedThisFrame
02d55c70: tbz     w0, #0, #0x2d55cb4                         
02d55c74: adrp    x8, #0x6266000                             
02d55c78: ldr     x8, [x8, #0x948]                           T:Touch
02d55c7c: ldr     x0, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d55c80: ldr     w8, [x0, #0xe4]                            [62660e4]=0 f=0,0
02d55c84: cbnz    w8, #0x2d55c8c                             
02d55c88: bl      #0x2b70f30                                 fn_2b70f30
02d55c8c: mov     x0, xzr                                    
02d55c90: bl      #0x2cd6230                                 Touch::IsPointerOverUIObject
02d55c94: and     w8, w0, #1                                 
02d55c98: strb    w8, [x19, #0x21]                           ._isOverUi
02d55c9c: tbnz    w0, #0, #0x2d55c14                         
02d55ca0: mov     x0, x19                                    
02d55ca4: bl      #0x2d55d2c                                 Blindbag.ScanMachine::OnMousePressed
02d55ca8: mov     w8, #1                                     
02d55cac: strb    w8, [x19, #0x22]                           ._isDown
02d55cb0: b       #0x2d55c14                                 
02d55cb4: ldr     x0, [x20, #0x1a8]                          [662f1a8]=600006c f=2.40744e-35,0
02d55cb8: cbz     x0, #0x2d55d28                             
02d55cbc: mov     x1, xzr                                    
02d55cc0: bl      #0x5553134                                 UnityEngine.InputSystem.Controls.ButtonControl::get_isPressed
02d55cc4: tbz     w0, #0, #0x2d55cd0                         
02d55cc8: ldrb    w8, [x19, #0x21]                           ._isOverUi
02d55ccc: cbz     w8, #0x2d55d08                             
02d55cd0: ldr     x0, [x20, #0x1a8]                          [662f1a8]=600006c f=2.40744e-35,0
02d55cd4: cbz     x0, #0x2d55d28                             
02d55cd8: mov     x1, xzr                                    
02d55cdc: bl      #0x5553460                                 UnityEngine.InputSystem.Controls.ButtonControl::get_wasReleasedThisFrame
02d55ce0: tbz     w0, #0, #0x2d55c14                         
02d55ce4: ldrb    w8, [x19, #0x21]                           ._isOverUi
02d55ce8: cbnz    w8, #0x2d55c14                             
02d55cec: ldrb    w8, [x19, #0xa8]                           ._hitItemStatus
02d55cf0: cbz     w8, #0x2d55c14                             
02d55cf4: mov     x0, x19                                    
02d55cf8: strb    wzr, [x19, #0x22]                          ._isDown
02d55cfc: ldp     x20, x19, [sp, #0x10]                      
02d55d00: ldr     x30, [sp], #0x20                           
02d55d04: b       #0x2d56010                                 Blindbag.ScanMachine::OnMouseRelease
02d55d08: ldrb    w8, [x19, #0x22]                           ._isDown
02d55d0c: cbz     w8, #0x2d55cd0                             
02d55d10: ldrb    w8, [x19, #0xa8]                           ._hitItemStatus
02d55d14: cbz     w8, #0x2d55cd0                             
02d55d18: mov     x0, x19                                    
02d55d1c: ldp     x20, x19, [sp, #0x10]                      
02d55d20: ldr     x30, [sp], #0x20                           
02d55d24: b       #0x2d55f64                                 Blindbag.ScanMachine::OnMouseDragging
02d55d28: bl      #0x2b7105c                                 fn_2b7105c
## OnMousePressed() -> void
---- Blindbag.ScanMachine::OnMousePressed 0x2d55d2c
02d55d2c: sub     sp, sp, #0xa0                              
02d55d30: stp     d11, d10, [sp, #0x60]                      
02d55d34: stp     d9, d8, [sp, #0x70]                        
02d55d38: stp     x30, x21, [sp, #0x80]                      
02d55d3c: stp     x20, x19, [sp, #0x90]                      
02d55d40: adrp    x20, #0x6630000                            
02d55d44: mov     x19, x0                                    
02d55d48: ldrb    w8, [x20, #0x27b]                          
02d55d4c: tbnz    w8, #0, #0x2d55d88                         
02d55d50: adrp    x0, #0x626b000                             
02d55d54: ldr     x0, [x0, #0x8c0]                           T:Jelly.IClickable
02d55d58: bl      #0x2b70db0                                 fn_2b70db0
02d55d5c: adrp    x0, #0x6266000                             
02d55d60: ldr     x0, [x0, #0x938]                           MS:UnityEngine.InputSystem.InputControl`1::ReadValue
02d55d64: bl      #0x2b70db0                                 fn_2b70db0
02d55d68: adrp    x0, #0x6263000                             
02d55d6c: ldr     x0, [x0, #0x918]                           T:UnityEngine.Object
02d55d70: bl      #0x2b70db0                                 fn_2b70db0
02d55d74: adrp    x0, #0x6266000                             
02d55d78: ldr     x0, [x0, #0x940]                           T:UnityEngine.Physics2D
02d55d7c: bl      #0x2b70db0                                 fn_2b70db0
02d55d80: mov     w8, #1                                     
02d55d84: strb    w8, [x20, #0x27b]                          
02d55d88: movi    v0.2d, #0000000000000000                   
02d55d8c: adrp    x20, #0x662f000                            
02d55d90: str     wzr, [sp, #0x50]                           
02d55d94: ldrb    w8, [x20, #0xbd9]                          
02d55d98: stp     q0, q0, [sp, #0x30]                        
02d55d9c: cbnz    w8, #0x2d55db4                             
02d55da0: adrp    x0, #0x6266000                             
02d55da4: ldr     x0, [x0, #0x950]                           T:UnityEngine.InputSystem.Pointer
02d55da8: bl      #0x2b70db0                                 fn_2b70db0
02d55dac: mov     w8, #1                                     
02d55db0: strb    w8, [x20, #0xbd9]                          
02d55db4: adrp    x8, #0x6266000                             
02d55db8: ldr     x8, [x8, #0x950]                           T:UnityEngine.InputSystem.Pointer
02d55dbc: ldr     x8, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d55dc0: ldr     x8, [x8, #0xb8]                            S:'banner_native_refresh_time'
02d55dc4: ldr     x8, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d55dc8: cbz     x8, #0x2d55f48                             
02d55dcc: ldr     x0, [x8, #0x188]                           S:'makeText'
02d55dd0: cbz     x0, #0x2d55f60                             
02d55dd4: adrp    x8, #0x6266000                             
02d55dd8: ldr     x8, [x8, #0x938]                           MS:UnityEngine.InputSystem.InputControl`1::ReadValue
02d55ddc: ldr     x20, [x19, #0x98]                          ._cameraMain
02d55de0: ldr     x1, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d55de4: bl      #0x4a187c4                                 fn_4a187c4
02d55de8: cbz     x20, #0x2d55f60                            
02d55dec: movi    d2, #0000000000000000                      
02d55df0: adrp    x21, #0x6266000                            
02d55df4: mov     x0, x20                                    
02d55df8: ldr     x21, [x21, #0x940]                         T:UnityEngine.Physics2D
02d55dfc: mov     x1, xzr                                    
02d55e00: bl      #0x5aefbb0                                 UnityEngine.Camera::ScreenToWorldPoint
02d55e04: fmov    s8, s0                                     
02d55e08: fmov    s9, s1                                     
02d55e0c: adrp    x20, #0x662f000                            
02d55e10: ldrb    w8, [x20, #0xbda]                          
02d55e14: cbnz    w8, #0x2d55e2c                             
02d55e18: adrp    x0, #0x6266000                             
02d55e1c: ldr     x0, [x0, #0x970]                           T:UnityEngine.Vector2
02d55e20: bl      #0x2b70db0                                 fn_2b70db0
02d55e24: mov     w8, #1                                     
02d55e28: strb    w8, [x20, #0xbda]                          
02d55e2c: adrp    x8, #0x6266000                             
02d55e30: adrp    x20, #0x6263000                            
02d55e34: ldr     x8, [x8, #0x970]                           T:UnityEngine.Vector2
02d55e38: ldr     x0, [x21]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d55e3c: ldr     x8, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d55e40: ldr     x8, [x8, #0xb8]                            S:'banner_native_refresh_time'
02d55e44: ldr     x20, [x20, #0x918]                         T:UnityEngine.Object
02d55e48: ldr     w9, [x0, #0xe4]                            [62660e4]=0 f=0,0
02d55e4c: ldp     s10, s11, [x8]                             
02d55e50: cbnz    w9, #0x2d55e58                             
02d55e54: bl      #0x2b70f30                                 fn_2b70f30
02d55e58: fmov    s0, s8                                     
02d55e5c: fmov    s1, s9                                     
02d55e60: add     x8, sp, #0xc                               
02d55e64: fmov    s2, s10                                    
02d55e68: fmov    s3, s11                                    
02d55e6c: mov     x0, xzr                                    
02d55e70: bl      #0x5bbca04                                 UnityEngine.Physics2D::Raycast
02d55e74: ldur    q0, [sp, #0xc]                             
02d55e78: ldur    q1, [sp, #0x1c]                            
02d55e7c: add     x0, sp, #0x30                              
02d55e80: ldr     w8, [sp, #0x2c]                            
02d55e84: mov     x1, xzr                                    
02d55e88: stp     q0, q1, [sp, #0x30]                        
02d55e8c: str     w8, [sp, #0x50]                            
02d55e90: bl      #0x5bbe11c                                 UnityEngine.RaycastHit2D::get_collider
02d55e94: ldr     x8, [x20]                                  &2c5bbd4(=a9bd7bfdd503233f)
02d55e98: mov     x20, x0                                    
02d55e9c: ldr     w9, [x8, #0xe4]                            [62660e4]=0 f=0,0
02d55ea0: cbnz    w9, #0x2d55eac                             
02d55ea4: mov     x0, x8                                     
02d55ea8: bl      #0x2b70f30                                 fn_2b70f30
02d55eac: mov     x0, x20                                    
02d55eb0: mov     x1, xzr                                    
02d55eb4: mov     x2, xzr                                    
02d55eb8: bl      #0x5b3666c                                 UnityEngine.Object::op_Inequality
02d55ebc: tbz     w0, #0, #0x2d55f48                         
02d55ec0: add     x0, sp, #0x30                              
02d55ec4: mov     x1, xzr                                    
02d55ec8: bl      #0x5bbe11c                                 UnityEngine.RaycastHit2D::get_collider
02d55ecc: add     x2, x19, #0xa0                             
02d55ed0: mov     x1, x0                                     
02d55ed4: bl      #0x2d560bc                                 Blindbag.ScanMachine::CheckHit
02d55ed8: ldr     x20, [x19, #0xa0]                          ._clickable
02d55edc: and     w8, w0, #1                                 
02d55ee0: strb    w8, [x19, #0xa8]                           ._hitItemStatus
02d55ee4: cbz     x20, #0x2d55f48                            
02d55ee8: adrp    x10, #0x626b000                            
02d55eec: ldr     x8, [x20]                                  &2c5bbd4(=a9bd7bfdd503233f)
02d55ef0: ldr     x10, [x10, #0x8c0]                         T:Jelly.IClickable
02d55ef4: ldrh    w9, [x8, #0x12e]                           
02d55ef8: ldr     x1, [x10]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d55efc: cbz     x9, #0x2d55f20                             
02d55f00: ldr     x10, [x8, #0xb0]                           S:'native_banner_ad_on_off'
02d55f04: add     x10, x10, #8                               &626b008
02d55f08: ldur    x11, [x10, #-8]                            
02d55f0c: cmp     x11, x1                                    
02d55f10: b.eq    #0x2d55f30                                 
02d55f14: subs    x9, x9, #1                                 
02d55f18: add     x10, x10, #0x10                            &626b010
02d55f1c: b.ne    #0x2d55f08                                 
02d55f20: mov     x0, x20                                    
02d55f24: mov     w2, wzr                                    
02d55f28: bl      #0x2baa05c                                 fn_2baa05c
02d55f2c: b       #0x2d55f3c                                 
02d55f30: ldrsw   x9, [x10]                                  
02d55f34: add     x8, x8, x9, lsl #4                         &6266000
02d55f38: add     x0, x8, #0x138                             &6266138
02d55f3c: ldp     x8, x1, [x0]                               
02d55f40: mov     x0, x20                                    
02d55f44: blr     x8                                         
02d55f48: ldp     x20, x19, [sp, #0x90]                      
02d55f4c: ldp     x30, x21, [sp, #0x80]                      
02d55f50: ldp     d9, d8, [sp, #0x70]                        
02d55f54: ldp     d11, d10, [sp, #0x60]                      
02d55f58: add     sp, sp, #0xa0                              
02d55f5c: ret                                                
02d55f60: bl      #0x2b7105c                                 fn_2b7105c
## CheckHit(UnityEngine.Collider2D col, Jelly.IClickable draggable) -> bool
---- Blindbag.ScanMachine::CheckHit 0x2d560bc
02d560bc: stp     x30, x21, [sp, #-0x20]!                    
02d560c0: stp     x20, x19, [sp, #0x10]                      
02d560c4: adrp    x21, #0x6630000                            
02d560c8: mov     x19, x2                                    
02d560cc: mov     x20, x1                                    
02d560d0: ldrb    w8, [x21, #0x27c]                          
02d560d4: tbnz    w8, #0, #0x2d560ec                         
02d560d8: adrp    x0, #0x626b000                             
02d560dc: ldr     x0, [x0, #0x8b8]                           MS:UnityEngine.Component::GetComponent
02d560e0: bl      #0x2b70db0                                 fn_2b70db0
02d560e4: mov     w8, #1                                     
02d560e8: strb    w8, [x21, #0x27c]                          
02d560ec: cbz     x20, #0x2d5612c                            
02d560f0: adrp    x8, #0x626b000                             
02d560f4: mov     x0, x20                                    
02d560f8: ldr     x8, [x8, #0x8b8]                           MS:UnityEngine.Component::GetComponent
02d560fc: ldr     x1, [x8]                                   T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d56100: bl      #0x3140c84                                 fn_3140c84
02d56104: mov     x1, x0                                     
02d56108: str     x0, [x19]                                  
02d5610c: mov     x0, x19                                    
02d56110: bl      #0x2b70d54                                 fn_2b70d54
02d56114: ldr     x8, [x19]                                  
02d56118: ldp     x20, x19, [sp, #0x10]                      
02d5611c: cmp     x8, #0                                     
02d56120: cset    w0, ne                                     
02d56124: ldp     x30, x21, [sp], #0x20                      
02d56128: ret                                                
02d5612c: bl      #0x2b7105c                                 fn_2b7105c
## OnMouseDragging() -> void
---- Blindbag.ScanMachine::OnMouseDragging 0x2d55f64
02d55f64: str     x30, [sp, #-0x20]!                         
02d55f68: stp     x20, x19, [sp, #0x10]                      
02d55f6c: adrp    x20, #0x6630000                            
02d55f70: mov     x19, x0                                    
02d55f74: ldrb    w8, [x20, #0x27d]                          
02d55f78: tbnz    w8, #0, #0x2d55f90                         
02d55f7c: adrp    x0, #0x626b000                             
02d55f80: ldr     x0, [x0, #0x8c0]                           T:Jelly.IClickable
02d55f84: bl      #0x2b70db0                                 fn_2b70db0
02d55f88: mov     w8, #1                                     
02d55f8c: strb    w8, [x20, #0x27d]                          
02d55f90: ldr     x19, [x19, #0xa0]                          ._clickable
02d55f94: cbz     x19, #0x2d55fe0                            
02d55f98: adrp    x10, #0x626b000                            
02d55f9c: ldr     x8, [x19]                                  
02d55fa0: ldr     x10, [x10, #0x8c0]                         T:Jelly.IClickable
02d55fa4: ldrh    w9, [x8, #0x12e]                           
02d55fa8: ldr     x1, [x10]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d55fac: cbz     x9, #0x2d55fd0                             
02d55fb0: ldr     x10, [x8, #0xb0]                           
02d55fb4: add     x10, x10, #8                               &626b008
02d55fb8: ldur    x11, [x10, #-8]                            
02d55fbc: cmp     x11, x1                                    
02d55fc0: b.eq    #0x2d55fec                                 
02d55fc4: subs    x9, x9, #1                                 
02d55fc8: add     x10, x10, #0x10                            &626b010
02d55fcc: b.ne    #0x2d55fb8                                 
02d55fd0: mov     x0, x19                                    
02d55fd4: mov     w2, #1                                     
02d55fd8: bl      #0x2baa05c                                 fn_2baa05c
02d55fdc: b       #0x2d55ffc                                 
02d55fe0: ldp     x20, x19, [sp, #0x10]                      
02d55fe4: ldr     x30, [sp], #0x20                           
02d55fe8: ret                                                
02d55fec: ldr     w9, [x10]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d55ff0: add     w9, w9, #1                                 
02d55ff4: add     x8, x8, w9, sxtw #4                        
02d55ff8: add     x0, x8, #0x138                             
02d55ffc: ldp     x2, x1, [x0]                               
02d56000: mov     x0, x19                                    
02d56004: ldp     x20, x19, [sp, #0x10]                      
02d56008: ldr     x30, [sp], #0x20                           
02d5600c: br      x2                                         
## OnMouseRelease() -> void
---- Blindbag.ScanMachine::OnMouseRelease 0x2d56010
02d56010: str     x30, [sp, #-0x20]!                         
02d56014: stp     x20, x19, [sp, #0x10]                      
02d56018: adrp    x20, #0x6630000                            
02d5601c: mov     x19, x0                                    
02d56020: ldrb    w8, [x20, #0x27e]                          
02d56024: tbnz    w8, #0, #0x2d5603c                         
02d56028: adrp    x0, #0x626b000                             
02d5602c: ldr     x0, [x0, #0x8c0]                           T:Jelly.IClickable
02d56030: bl      #0x2b70db0                                 fn_2b70db0
02d56034: mov     w8, #1                                     
02d56038: strb    w8, [x20, #0x27e]                          
02d5603c: ldr     x19, [x19, #0xa0]                          ._clickable
02d56040: cbz     x19, #0x2d5608c                            
02d56044: adrp    x10, #0x626b000                            
02d56048: ldr     x8, [x19]                                  
02d5604c: ldr     x10, [x10, #0x8c0]                         T:Jelly.IClickable
02d56050: ldrh    w9, [x8, #0x12e]                           
02d56054: ldr     x1, [x10]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d56058: cbz     x9, #0x2d5607c                             
02d5605c: ldr     x10, [x8, #0xb0]                           
02d56060: add     x10, x10, #8                               &626b008
02d56064: ldur    x11, [x10, #-8]                            
02d56068: cmp     x11, x1                                    
02d5606c: b.eq    #0x2d56098                                 
02d56070: subs    x9, x9, #1                                 
02d56074: add     x10, x10, #0x10                            &626b010
02d56078: b.ne    #0x2d56064                                 
02d5607c: mov     x0, x19                                    
02d56080: mov     w2, #2                                     
02d56084: bl      #0x2baa05c                                 fn_2baa05c
02d56088: b       #0x2d560a8                                 
02d5608c: ldp     x20, x19, [sp, #0x10]                      
02d56090: ldr     x30, [sp], #0x20                           
02d56094: ret                                                
02d56098: ldr     w9, [x10]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d5609c: add     w9, w9, #2                                 
02d560a0: add     x8, x8, w9, sxtw #4                        
02d560a4: add     x0, x8, #0x138                             
02d560a8: ldp     x2, x1, [x0]                               
02d560ac: mov     x0, x19                                    
02d560b0: ldp     x20, x19, [sp, #0x10]                      
02d560b4: ldr     x30, [sp], #0x20                           
02d560b8: br      x2                                         
## .ctor() -> void
---- Blindbag.ScanMachine::.ctor 0x2d56130
02d56130: mov     x1, xzr                                    
02d56134: b       #0x5b397b0                                 UnityEngine.MonoBehaviour::.ctor
