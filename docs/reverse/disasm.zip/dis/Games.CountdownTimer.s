#### CLASS Games.CountdownTimer parent= UnityEngine.MonoBehaviour
#   field OnTrigger                      UnityEngine.Events.UnityAction                     off=0x20 attr=6 
#   field _countdownTween                DG.Tweening.Tween                                  off=0x28 attr=1 
## StartCountdown(float duration) -> void
---- Games.CountdownTimer::StartCountdown 0x2d2f3f4
02d2f3f4: str     d8, [sp, #-0x30]!                          
02d2f3f8: str     x30, [sp, #8]                              
02d2f3fc: stp     x22, x21, [sp, #0x10]                      
02d2f400: stp     x20, x19, [sp, #0x20]                      
02d2f404: fmov    s8, s0                                     
02d2f408: adrp    x20, #0x6630000                            
02d2f40c: adrp    x22, #0x6264000                            
02d2f410: adrp    x21, #0x626a000                            
02d2f414: ldrb    w8, [x20, #0xe8]                           
02d2f418: ldr     x22, [x22, #0xe8]                          T:DG.Tweening.TweenCallback
02d2f41c: ldr     x21, [x21, #0x610]                         M:Games.CountdownTimer::<StartCountdown>b__2_0
02d2f420: mov     x19, x0                                    
02d2f424: tbnz    w8, #0, #0x2d2f448                         
02d2f428: adrp    x0, #0x626a000                             
02d2f42c: ldr     x0, [x0, #0x610]                           M:Games.CountdownTimer::<StartCountdown>b__2_0
02d2f430: bl      #0x2b70db0                                 fn_2b70db0
02d2f434: adrp    x0, #0x6264000                             
02d2f438: ldr     x0, [x0, #0xe8]                            T:DG.Tweening.TweenCallback
02d2f43c: bl      #0x2b70db0                                 fn_2b70db0
02d2f440: mov     w8, #1                                     
02d2f444: strb    w8, [x20, #0xe8]                           
02d2f448: mov     x20, x19                                   
02d2f44c: mov     w1, wzr                                    
02d2f450: mov     x2, xzr                                    
02d2f454: ldr     x0, [x20, #0x28]!                          ._countdownTween
02d2f458: bl      #0x2d8fe94                                 DG.Tweening.TweenExtensions::Kill
02d2f45c: ldr     x0, [x22]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d2f460: bl      #0x2b7104c                                 fn_2b7104c
02d2f464: ldr     x2, [x21]                                  T:type56879(k15)
02d2f468: mov     x1, x19                                    
02d2f46c: mov     x3, xzr                                    
02d2f470: mov     x21, x0                                    
02d2f474: bl      #0x2d89dc4                                 DG.Tweening.TweenCallback::.ctor
02d2f478: fmov    s0, s8                                     
02d2f47c: mov     x0, x21                                    
02d2f480: mov     w1, #1                                     
02d2f484: mov     x2, xzr                                    
02d2f488: bl      #0x2d8f37c                                 DG.Tweening.DOVirtual::DelayedCall
02d2f48c: mov     x1, x0                                     
02d2f490: mov     x0, x20                                    
02d2f494: ldr     x30, [sp, #8]                              
02d2f498: str     x1, [x20]                                  
02d2f49c: ldp     x20, x19, [sp, #0x20]                      
02d2f4a0: ldp     x22, x21, [sp, #0x10]                      
02d2f4a4: ldr     d8, [sp], #0x30                            
02d2f4a8: b       #0x2b70d54                                 
## StopCountdown() -> void
---- Games.CountdownTimer::StopCountdown 0x2d2f4ac
02d2f4ac: ldr     x0, [x0, #0x28]                            ._countdownTween
02d2f4b0: mov     w1, wzr                                    
02d2f4b4: mov     x2, xzr                                    
02d2f4b8: b       #0x2d8fe94                                 DG.Tweening.TweenExtensions::Kill
## .ctor() -> void
---- Games.CountdownTimer::.ctor 0x2d2f4bc
02d2f4bc: mov     x1, xzr                                    
02d2f4c0: b       #0x5b397b0                                 UnityEngine.MonoBehaviour::.ctor
## <StartCountdown>b__2_0() -> void
---- Games.CountdownTimer::<StartCountdown>b__2_0 0x2d2f4c4
02d2f4c4: ldr     x8, [x0, #0x20]                            .OnTrigger
02d2f4c8: cbz     x8, #0x2d2f4dc                             
02d2f4cc: ldr     x0, [x8, #0x40]                            
02d2f4d0: ldr     x1, [x8, #0x28]                            
02d2f4d4: ldr     x2, [x8, #0x18]                            
02d2f4d8: br      x2                                         
02d2f4dc: ret                                                
02d2f4e0: stp     x30, x21, [sp, #-0x20]!                    
02d2f4e4: stp     x20, x19, [sp, #0x10]                      
02d2f4e8: adrp    x21, #0x6630000                            
02d2f4ec: mov     x19, x1                                    
02d2f4f0: mov     x20, x0                                    
02d2f4f4: ldrb    w8, [x21, #0xe9]                           
02d2f4f8: cbnz    w8, #0x2d2f528                             
02d2f4fc: adrp    x0, #0x639c000                             
02d2f500: add     x0, x0, #0x180                             &639c180
02d2f504: bl      #0x2b70db0                                 fn_2b70db0
02d2f508: adrp    x0, #0x639e000                             
02d2f50c: add     x0, x0, #0x340                             &639e340
02d2f510: bl      #0x2b70db0                                 fn_2b70db0
02d2f514: adrp    x0, #0x63a0000                             
02d2f518: add     x0, x0, #0xc30                             &63a0c30
02d2f51c: bl      #0x2b70db0                                 fn_2b70db0
02d2f520: mov     w8, #1                                     
02d2f524: strb    w8, [x21, #0xe9]                           
02d2f528: ldr     x21, [x20]                                 
02d2f52c: cbz     x21, #0x2d2f5d4                            
02d2f530: adrp    x10, #0x6269000                            
02d2f534: ldr     x8, [x21]                                  
02d2f538: ldr     x10, [x10, #0xb68]                         T:Cysharp.Threading.Tasks.CompilerServices.IStateMachineRunner
02d2f53c: ldrh    w9, [x8, #0x12e]                           
02d2f540: ldr     x1, [x10]                                  T:Trading.TradingSession/<>c__DisplayClass56_0
02d2f544: cbz     x9, #0x2d2f568                             
02d2f548: ldr     x10, [x8, #0xb0]                           
02d2f54c: add     x10, x10, #8                               &6269008
02d2f550: ldur    x11, [x10, #-8]                            
02d2f554: cmp     x11, x1                                    
02d2f558: b.eq    #0x2d2f578                                 
02d2f55c: subs    x9, x9, #1                                 
02d2f560: add     x10, x10, #0x10                            &6269010
02d2f564: b.ne    #0x2d2f550                                 
02d2f568: mov     x0, x21                                    
02d2f56c: mov     w2, #2                                     
02d2f570: bl      #0x2baa05c                                 fn_2baa05c
02d2f574: b       #0x2d2f588                                 
02d2f578: ldr     w9, [x10]                                  T:Trading.TradingSession/<>c__DisplayClass56_0
02d2f57c: add     w9, w9, #2                                 
02d2f580: add     x8, x8, w9, sxtw #4                        
02d2f584: add     x0, x8, #0x138                             
02d2f588: ldp     x8, x1, [x0]                               
02d2f58c: mov     x0, x21                                    
02d2f590: blr     x8                                         
02d2f594: adrp    x8, #0x6269000                             
02d2f598: mov     x21, x0                                    
02d2f59c: ldr     x8, [x8, #0xb70]                           T:Cysharp.Threading.Tasks.PlayerLoopHelper
02d2f5a0: ldr     x8, [x8]                                   T:Trading.TradingSession/<>c__DisplayClass56_0
02d2f5a4: ldr     w9, [x8, #0xe4]                            [62690e4]=0 f=0,0
02d2f5a8: cbnz    w9, #0x2d2f5b4                             
02d2f5ac: mov     x0, x8                                     
02d2f5b0: bl      #0x2b70f30                                 fn_2b70f30
02d2f5b4: mov     w0, #0xd                                   
02d2f5b8: mov     x1, x21                                    
02d2f5bc: mov     x2, xzr                                    
02d2f5c0: bl      #0x5443ef0                                 Cysharp.Threading.Tasks.PlayerLoopHelper::AddContinuation
02d2f5c4: mov     x0, x20                                    
02d2f5c8: mov     x1, xzr                                    
02d2f5cc: str     xzr, [x20]                                 
02d2f5d0: bl      #0x2b70d54                                 fn_2b70d54
02d2f5d4: adrp    x8, #0x63a0000                             
02d2f5d8: add     x8, x8, #0xc30                             &63a0c30
02d2f5dc: ldr     x0, [x8]                                   [63a0000]=200139d5 f=1.09459e-19,0
02d2f5e0: ldr     w8, [x0, #0xe4]                            [63a00e4]=20013a7d00000000 f=0,1.09461e-19
02d2f5e4: cbnz    w8, #0x2d2f5ec                             
02d2f5e8: bl      #0x2b70f30                                 fn_2b70f30
02d2f5ec: mov     x0, x19                                    
02d2f5f0: ldp     x20, x19, [sp, #0x10]                      
02d2f5f4: mov     x1, xzr                                    
02d2f5f8: ldp     x30, x21, [sp], #0x20                      
02d2f5fc: b       #0x546089c                                 Cysharp.Threading.Tasks.UniTaskScheduler::PublishUnobservedTaskException
02d2f600: str     x30, [sp, #-0x20]!                         
02d2f604: stp     x20, x19, [sp, #0x10]                      
02d2f608: adrp    x20, #0x6630000                            
02d2f60c: mov     x19, x0                                    
02d2f610: ldrb    w8, [x20, #0xea]                           
02d2f614: cbnz    w8, #0x2d2f638                             
02d2f618: adrp    x0, #0x639c000                             
02d2f61c: add     x0, x0, #0x180                             &639c180
02d2f620: bl      #0x2b70db0                                 fn_2b70db0
02d2f624: adrp    x0, #0x639e000                             
02d2f628: add     x0, x0, #0x340                             &639e340
02d2f62c: bl      #0x2b70db0                                 fn_2b70db0
02d2f630: mov     w8, #1                                     
02d2f634: strb    w8, [x20, #0xea]                           
02d2f638: ldr     x20, [x19]                                 
02d2f63c: cbz     x20, #0x2d2f688                            
02d2f640: adrp    x10, #0x6269000                            
02d2f644: ldr     x8, [x20]                                  
02d2f648: ldr     x10, [x10, #0xb68]                         T:Cysharp.Threading.Tasks.CompilerServices.IStateMachineRunner
02d2f64c: ldrh    w9, [x8, #0x12e]                           
02d2f650: ldr     x1, [x10]                                  T:Trading.TradingSession/<>c__DisplayClass56_0
02d2f654: cbz     x9, #0x2d2f678                             
02d2f658: ldr     x10, [x8, #0xb0]                           [63a00b0]=20013a47 f=1.0946e-19,0
02d2f65c: add     x10, x10, #8                               &6269008
02d2f660: ldur    x11, [x10, #-8]                            
02d2f664: cmp     x11, x1                                    
02d2f668: b.eq    #0x2d2f694                                 
02d2f66c: subs    x9, x9, #1                                 
02d2f670: add     x10, x10, #0x10                            &6269010
02d2f674: b.ne    #0x2d2f660                                 
02d2f678: mov     x0, x20                                    
02d2f67c: mov     w2, #2                                     
02d2f680: bl      #0x2baa05c                                 fn_2baa05c
02d2f684: b       #0x2d2f6a4                                 
02d2f688: ldp     x20, x19, [sp, #0x10]                      
02d2f68c: ldr     x30, [sp], #0x20                           
02d2f690: ret                                                
02d2f694: ldr     w9, [x10]                                  T:Trading.TradingSession/<>c__DisplayClass56_0
02d2f698: add     w9, w9, #2                                 
02d2f69c: add     x8, x8, w9, sxtw #4                        &63a0000
02d2f6a0: add     x0, x8, #0x138                             &63a0138
02d2f6a4: ldp     x8, x1, [x0]                               
02d2f6a8: mov     x0, x20                                    
02d2f6ac: blr     x8                                         
02d2f6b0: adrp    x8, #0x6269000                             
02d2f6b4: mov     x20, x0                                    
02d2f6b8: ldr     x8, [x8, #0xb70]                           T:Cysharp.Threading.Tasks.PlayerLoopHelper
02d2f6bc: ldr     x8, [x8]                                   T:Trading.TradingSession/<>c__DisplayClass56_0
02d2f6c0: ldr     w9, [x8, #0xe4]                            [62690e4]=0 f=0,0
02d2f6c4: cbnz    w9, #0x2d2f6d0                             
02d2f6c8: mov     x0, x8                                     
02d2f6cc: bl      #0x2b70f30                                 fn_2b70f30
02d2f6d0: mov     w0, #0xd                                   
02d2f6d4: mov     x1, x20                                    
02d2f6d8: mov     x2, xzr                                    
02d2f6dc: bl      #0x5443ef0                                 Cysharp.Threading.Tasks.PlayerLoopHelper::AddContinuation
02d2f6e0: mov     x0, x19                                    
02d2f6e4: str     xzr, [x19]                                 
02d2f6e8: mov     x1, xzr                                    
02d2f6ec: ldp     x20, x19, [sp, #0x10]                      
02d2f6f0: ldr     x30, [sp], #0x20                           
02d2f6f4: b       #0x2b70d54                                 
02d2f6f8: stp     x30, x23, [sp, #-0x30]!                    
02d2f6fc: stp     x22, x21, [sp, #0x10]                      
02d2f700: stp     x20, x19, [sp, #0x20]                      
02d2f704: ldr     x8, [x3, #0x38]                            
02d2f708: mov     x20, x3                                    
02d2f70c: mov     x23, x2                                    
02d2f710: mov     x19, x1                                    
02d2f714: mov     x22, x0                                    
02d2f718: cbnz    x8, #0x2d2f738                             
02d2f71c: adrp    x0, #0x639c000                             
02d2f720: add     x0, x0, #0x180                             &639c180
02d2f724: bl      #0x2b70db0                                 fn_2b70db0
02d2f728: ldr     x8, [x20, #0x38]                           
02d2f72c: cbnz    x8, #0x2d2f738                             
02d2f730: mov     x0, x20                                    
02d2f734: bl      #0x2ba9d7c                                 fn_2ba9d7c
02d2f738: ldr     x21, [x22]                                 
02d2f73c: cbnz    x21, #0x2d2f780                            
02d2f740: ldr     x8, [x20, #0x38]                           
02d2f744: ldr     x0, [x8, #0x10]                            M:Trading.TradingSession/<>c__DisplayClass56_0::<RemovePlayerItem>b__0
02d2f748: add     x8, x0, #0x135                             &639c135
02d2f74c: ldrh    w8, [x8]                                   
02d2f750: tbnz    w8, #0, #0x2d2f758                         
02d2f754: bl      #0x2ba9d20                                 fn_2ba9d20
02d2f758: ldr     w8, [x0, #0xe4]                            [639c0e4]=200100e500000000 f=0,1.0927e-19
02d2f75c: cbnz    w8, #0x2d2f764                             
02d2f760: bl      #0x2b70f30                                 fn_2b70f30
02d2f764: ldr     x8, [x20, #0x38]                           
02d2f768: mov     x0, x23                                    
02d2f76c: mov     x1, x22                                    
02d2f770: ldr     x2, [x8, #8]                               MS:System.Collections.Generic.List`1::RemoveAll
02d2f774: bl      #0x3df3fb0                                 fn_3df3fb0
02d2f778: ldr     x21, [x22]                                 
02d2f77c: cbz     x21, #0x2d2f800                            
02d2f780: adrp    x10, #0x6269000                            
02d2f784: ldr     x8, [x21]                                  
02d2f788: ldr     x10, [x10, #0xb68]                         T:Cysharp.Threading.Tasks.CompilerServices.IStateMachineRunner
02d2f78c: ldrh    w9, [x8, #0x12e]                           
02d2f790: ldr     x1, [x10]                                  T:Trading.TradingSession/<>c__DisplayClass56_0
02d2f794: cbz     x9, #0x2d2f7b8                             
02d2f798: ldr     x10, [x8, #0xb0]                           M:Trading.TradingSession/<>c__DisplayClass65_0::<BuildResult>b__0
02d2f79c: add     x10, x10, #8                               &6269008
02d2f7a0: ldur    x11, [x10, #-8]                            
02d2f7a4: cmp     x11, x1                                    
02d2f7a8: b.eq    #0x2d2f7c8                                 
02d2f7ac: subs    x9, x9, #1                                 
02d2f7b0: add     x10, x10, #0x10                            &6269010
02d2f7b4: b.ne    #0x2d2f7a0                                 
02d2f7b8: mov     x0, x21                                    
02d2f7bc: mov     w2, wzr                                    
02d2f7c0: bl      #0x2baa05c                                 fn_2baa05c
02d2f7c4: b       #0x2d2f7d4                                 
02d2f7c8: ldrsw   x9, [x10]                                  
02d2f7cc: add     x8, x8, x9, lsl #4                         &6269000
02d2f7d0: add     x0, x8, #0x138                             &6269138
02d2f7d4: ldp     x8, x1, [x0]                               
02d2f7d8: mov     x0, x21                                    
02d2f7dc: blr     x8                                         
02d2f7e0: ldr     x8, [x20, #0x38]                           
02d2f7e4: mov     x1, x0                                     
02d2f7e8: mov     x0, x19                                    
02d2f7ec: ldp     x20, x19, [sp, #0x20]                      
02d2f7f0: ldp     x22, x21, [sp, #0x10]                      
02d2f7f4: ldr     x2, [x8, #0x28]                            T:Trading.TradingCounterRequest
02d2f7f8: ldp     x30, x23, [sp], #0x30                      
02d2f7fc: b       #0x2ceb074                                 
02d2f800: bl      #0x2b7105c                                 fn_2b7105c
02d2f804: stp     x30, x23, [sp, #-0x30]!                    
02d2f808: stp     x22, x21, [sp, #0x10]                      
02d2f80c: stp     x20, x19, [sp, #0x20]                      
02d2f810: ldr     x8, [x3, #0x38]                            
02d2f814: mov     x20, x3                                    
02d2f818: mov     x23, x2                                    
02d2f81c: mov     x19, x1                                    
02d2f820: mov     x22, x0                                    
02d2f824: cbnz    x8, #0x2d2f844                             
02d2f828: adrp    x0, #0x639c000                             
02d2f82c: add     x0, x0, #0x180                             &639c180
02d2f830: bl      #0x2b70db0                                 fn_2b70db0
02d2f834: ldr     x8, [x20, #0x38]                           
02d2f838: cbnz    x8, #0x2d2f844                             
02d2f83c: mov     x0, x20                                    
02d2f840: bl      #0x2ba9d7c                                 fn_2ba9d7c
02d2f844: ldr     x21, [x22]                                 
02d2f848: cbnz    x21, #0x2d2f88c                            
02d2f84c: ldr     x8, [x20, #0x38]                           
02d2f850: ldr     x0, [x8, #0x10]                            M:Trading.TradingSession/<>c__DisplayClass56_0::<RemovePlayerItem>b__0
02d2f854: add     x8, x0, #0x135                             &639c135
02d2f858: ldrh    w8, [x8]                                   
02d2f85c: tbnz    w8, #0, #0x2d2f864                         
02d2f860: bl      #0x2ba9d20                                 fn_2ba9d20
02d2f864: ldr     w8, [x0, #0xe4]                            [639c0e4]=200100e500000000 f=0,1.0927e-19
02d2f868: cbnz    w8, #0x2d2f870                             
02d2f86c: bl      #0x2b70f30                                 fn_2b70f30
02d2f870: ldr     x8, [x20, #0x38]                           
02d2f874: mov     x0, x23                                    
02d2f878: mov     x1, x22                                    
02d2f87c: ldr     x2, [x8, #8]                               MS:System.Collections.Generic.List`1::RemoveAll
02d2f880: bl      #0x3df441c                                 fn_3df441c
02d2f884: ldr     x21, [x22]                                 
02d2f888: cbz     x21, #0x2d2f90c                            
02d2f88c: adrp    x10, #0x6269000                            
02d2f890: ldr     x8, [x21]                                  
02d2f894: ldr     x10, [x10, #0xb68]                         T:Cysharp.Threading.Tasks.CompilerServices.IStateMachineRunner
02d2f898: ldrh    w9, [x8, #0x12e]                           
02d2f89c: ldr     x1, [x10]                                  T:Trading.TradingSession/<>c__DisplayClass56_0
02d2f8a0: cbz     x9, #0x2d2f8c4                             
02d2f8a4: ldr     x10, [x8, #0xb0]                           M:Trading.TradingSession/<>c__DisplayClass65_0::<BuildResult>b__0
02d2f8a8: add     x10, x10, #8                               &6269008
02d2f8ac: ldur    x11, [x10, #-8]                            
02d2f8b0: cmp     x11, x1                                    
02d2f8b4: b.eq    #0x2d2f8d4                                 
02d2f8b8: subs    x9, x9, #1                                 
02d2f8bc: add     x10, x10, #0x10                            &6269010
02d2f8c0: b.ne    #0x2d2f8ac                                 
02d2f8c4: mov     x0, x21                                    
02d2f8c8: mov     w2, wzr                                    
02d2f8cc: bl      #0x2baa05c                                 fn_2baa05c
02d2f8d0: b       #0x2d2f8e0                                 
02d2f8d4: ldrsw   x9, [x10]                                  
02d2f8d8: add     x8, x8, x9, lsl #4                         &6269000
02d2f8dc: add     x0, x8, #0x138                             &6269138
02d2f8e0: ldp     x8, x1, [x0]                               
02d2f8e4: mov     x0, x21                                    
02d2f8e8: blr     x8                                         
02d2f8ec: ldr     x8, [x20, #0x38]                           
02d2f8f0: mov     x1, x0                                     
02d2f8f4: mov     x0, x19                                    
02d2f8f8: ldp     x20, x19, [sp, #0x20]                      
02d2f8fc: ldp     x22, x21, [sp, #0x10]                      
02d2f900: ldr     x2, [x8, #0x28]                            T:Trading.TradingCounterRequest
02d2f904: ldp     x30, x23, [sp], #0x30                      
02d2f908: b       #0x2ceb074                                 
02d2f90c: bl      #0x2b7105c                                 fn_2b7105c
