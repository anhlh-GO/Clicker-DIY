#### CLASS PoolData parent= object
#   field poolType                       PoolType                                           off=0x10 attr=6 
#   field prefab                         UnityEngine.Transform                              off=0x18 attr=6 
## .ctor() -> void
---- PoolData::.ctor 0x2cdc5d4
02cdc5d4: mov     x1, xzr                                    
02cdc5d8: b       #0x4e53e9c                                 System.Object::.ctor
