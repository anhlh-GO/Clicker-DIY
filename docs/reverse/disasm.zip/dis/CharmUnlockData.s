#### CLASS CharmUnlockData parent= object
#   field id                             int                                                off=0x10 attr=6 
#   field unlockType                     Games.Common.EUnlockType                           off=0x14 attr=6 
#   field unlockValue                    int                                                off=0x18 attr=6 
#   field isLocked                       bool                                               off=0x1c attr=6 
## .ctor() -> void
---- CharmUnlockData::.ctor 0x2caaeb0
02caaeb0: mov     w8, #1                                     
02caaeb4: mov     x1, xzr                                    
02caaeb8: strb    w8, [x0, #0x1c]                            .isLocked
02caaebc: b       #0x4e53e9c                                 System.Object::.ctor
