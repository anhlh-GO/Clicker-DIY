#### CLASS Home.BonusController/<RepeatEvery>d__7 parent= object
#   field <>1__state                     int                                                off=0x10 attr=1 
#   field <>2__current                   object                                             off=0x18 attr=1 
#   field <>4__this                      Home.BonusController                               off=0x20 attr=6 
## .ctor(int <>1__state) -> void
---- Home.BonusController/<RepeatEvery>d__7::.ctor 0x2d1df88
02d1df88: str     x30, [sp, #-0x20]!                         
02d1df8c: stp     x20, x19, [sp, #0x10]                      
02d1df90: mov     w19, w1                                    
02d1df94: mov     x1, xzr                                    
02d1df98: mov     x20, x0                                    
02d1df9c: bl      #0x4e53e9c                                 System.Object::.ctor
02d1dfa0: str     w19, [x20, #0x10]                          .<>1__state
02d1dfa4: ldp     x20, x19, [sp, #0x10]                      
02d1dfa8: ldr     x30, [sp], #0x20                           
02d1dfac: ret                                                
## System.IDisposable.Dispose() -> void
---- Home.BonusController/<RepeatEvery>d__7::System.IDisposable.Dispose 0x2d1e178
02d1e178: ret                                                
## MoveNext() -> bool
---- Home.BonusController/<RepeatEvery>d__7::MoveNext 0x2d1e17c
02d1e17c: stp     d9, d8, [sp, #-0x50]!                      
02d1e180: str     x30, [sp, #0x10]                           
02d1e184: stp     x24, x23, [sp, #0x20]                      
02d1e188: stp     x22, x21, [sp, #0x30]                      
02d1e18c: stp     x20, x19, [sp, #0x40]                      
02d1e190: ldr     w8, [x0, #0x10]                            .<>1__state
02d1e194: cmp     w8, #2                                     
02d1e198: b.hs    #0x2d1e230                                 
02d1e19c: ldr     x21, [x0, #0x20]                           .<>4__this
02d1e1a0: mov     x19, x0                                    
02d1e1a4: mov     w8, #-1                                    
02d1e1a8: str     w8, [x0, #0x10]                            .<>1__state
02d1e1ac: cbz     x21, #0x2d1e308                            
02d1e1b0: ldr     s8, [x21, #0x30]                           
02d1e1b4: fcmp    s8, #0.0                                   
02d1e1b8: b.le    #0x2d1e214                                 
02d1e1bc: mov     x0, xzr                                    
02d1e1c0: bl      #0x5b433a4                                 UnityEngine.Time::get_deltaTime
02d1e1c4: fsub    s8, s8, s0                                 
02d1e1c8: mov     w9, #0x42700000                            
02d1e1cc: adrp    x22, #0x662f000                            
02d1e1d0: fmov    s9, w9                                     
02d1e1d4: ldrb    w8, [x22, #0xbd8]                          
02d1e1d8: str     s8, [x21, #0x30]                           
02d1e1dc: cbnz    w8, #0x2d1e1f4                             
02d1e1e0: adrp    x0, #0x6265000                             
02d1e1e4: ldr     x0, [x0, #0xb48]                           T:System.Math
02d1e1e8: bl      #0x2b70db0                                 fn_2b70db0
02d1e1ec: mov     w8, #1                                     
02d1e1f0: strb    w8, [x22, #0xbd8]                          
02d1e1f4: fdiv    s8, s8, s9                                 
02d1e1f8: adrp    x23, #0x6265000                            
02d1e1fc: ldr     x23, [x23, #0xb48]                         T:System.Math
02d1e200: ldr     x0, [x23]                                  M:AdsManager::<OnApplicationPause>b__26_0
02d1e204: ldr     w8, [x0, #0xe4]                            [62650e4]=0 f=0,0
02d1e208: cbz     w8, #0x2d1e238                             
02d1e20c: mov     w24, wzr                                   
02d1e210: b       #0x2d1e248                                 
02d1e214: ldr     x8, [x21, #0x28]                           
02d1e218: strb    wzr, [x21, #0x34]                          
02d1e21c: cbz     x8, #0x2d1e230                             
02d1e220: ldr     x9, [x8, #0x18]                            
02d1e224: ldr     x0, [x8, #0x40]                            
02d1e228: ldr     x1, [x8, #0x28]                            
02d1e22c: blr     x9                                         
02d1e230: mov     w0, wzr                                    
02d1e234: b       #0x2d1e2f0                                 
02d1e238: bl      #0x2b70f30                                 fn_2b70f30
02d1e23c: ldrb    w8, [x22, #0xbd8]                          
02d1e240: cmp     w8, #0                                     
02d1e244: cset    w24, eq                                    
02d1e248: frintm  s0, s8                                     
02d1e24c: mov     w8, #0x7f800000                            
02d1e250: fcvtms  w9, s8                                     
02d1e254: fmov    s1, w8                                     
02d1e258: mov     w8, #-0xffffffff80000000                   
02d1e25c: fcmp    s0, s1                                     
02d1e260: ldr     s0, [x21, #0x30]                           
02d1e264: csel    w20, w8, w9, eq                            
02d1e268: mov     w8, #0x42700000                            
02d1e26c: fmov    s1, w8                                     
02d1e270: bl      #0x5e90330                                 fn_5e90330
02d1e274: fmov    s8, s0                                     
02d1e278: cbz     w24, #0x2d1e290                            
02d1e27c: adrp    x0, #0x6265000                             
02d1e280: ldr     x0, [x0, #0xb48]                           T:System.Math
02d1e284: bl      #0x2b70db0                                 fn_2b70db0
02d1e288: mov     w8, #1                                     
02d1e28c: strb    w8, [x22, #0xbd8]                          
02d1e290: ldr     x0, [x23]                                  M:AdsManager::<OnApplicationPause>b__26_0
02d1e294: ldr     w8, [x0, #0xe4]                            [62650e4]=0 f=0,0
02d1e298: cbnz    w8, #0x2d1e2a0                             
02d1e29c: bl      #0x2b70f30                                 fn_2b70f30
02d1e2a0: ldr     x8, [x21, #0x20]                           .<>4__this
02d1e2a4: cbz     x8, #0x2d1e2d8                             
02d1e2a8: frintm  s0, s8                                     
02d1e2ac: mov     w9, #0x7f800000                            
02d1e2b0: fcvtms  w10, s8                                    
02d1e2b4: fmov    s1, w9                                     
02d1e2b8: mov     w9, #-0xffffffff80000000                   
02d1e2bc: ldr     x11, [x8, #0x18]                           
02d1e2c0: ldr     x0, [x8, #0x40]                            
02d1e2c4: ldr     x3, [x8, #0x28]                            
02d1e2c8: mov     w1, w20                                    
02d1e2cc: fcmp    s0, s1                                     
02d1e2d0: csel    w2, w9, w10, eq                            
02d1e2d4: blr     x11                                        
02d1e2d8: str     xzr, [x19, #0x18]!                         .<>2__current
02d1e2dc: mov     x0, x19                                    
02d1e2e0: mov     x1, xzr                                    
02d1e2e4: bl      #0x2b70d54                                 fn_2b70d54
02d1e2e8: mov     w0, #1                                     
02d1e2ec: stur    w0, [x19, #-8]                             
02d1e2f0: ldp     x20, x19, [sp, #0x40]                      
02d1e2f4: ldr     x30, [sp, #0x10]                           
02d1e2f8: ldp     x22, x21, [sp, #0x30]                      
02d1e2fc: ldp     x24, x23, [sp, #0x20]                      
02d1e300: ldp     d9, d8, [sp], #0x50                        
02d1e304: ret                                                
02d1e308: bl      #0x2b7105c                                 fn_2b7105c
## System.Collections.Generic.IEnumerator<System.Object>.get_Current() -> object
---- Home.BonusController/<RepeatEvery>d__7::System.Collections.Generic.IEnumerator<System.Object>.get_Current 0x2d1e30c
02d1e30c: ldr     x0, [x0, #0x18]                            .<>2__current
02d1e310: ret                                                
## System.Collections.IEnumerator.Reset() -> void
---- Home.BonusController/<RepeatEvery>d__7::System.Collections.IEnumerator.Reset 0x2d1e314
02d1e314: stp     x30, x19, [sp, #-0x10]!                    
02d1e318: adrp    x0, #0x6264000                             
02d1e31c: ldr     x0, [x0, #0xf60]                           T:System.NotSupportedException
02d1e320: bl      #0x2b70dc4                                 fn_2b70dc4
02d1e324: bl      #0x2b7104c                                 fn_2b7104c
02d1e328: mov     x1, xzr                                    
02d1e32c: mov     x19, x0                                    
02d1e330: bl      #0x4e14238                                 System.NotSupportedException::.ctor
02d1e334: adrp    x0, #0x6269000                             
02d1e338: ldr     x0, [x0, #0xd30]                           M:Home.BonusController/<RepeatEvery>d__7::System.Collections.IEnumerator.Reset
02d1e33c: bl      #0x2b70dc4                                 fn_2b70dc4
02d1e340: mov     x1, x0                                     
02d1e344: mov     x0, x19                                    
02d1e348: bl      #0x2b70f20                                 fn_2b70f20
## System.Collections.IEnumerator.get_Current() -> object
---- Home.BonusController/<RepeatEvery>d__7::System.Collections.IEnumerator.get_Current 0x2d1e34c
02d1e34c: ldr     x0, [x0, #0x18]                            .<>2__current
02d1e350: ret                                                
#### CLASS Home.BonusController parent= MonoSingleton`1<Home.BonusController>
#   field OnTimeRemainingChanged         System.Action`2<int,int>                           off=0x20 attr=6 
#   field OnTimeUp                       System.Action                                      off=0x28 attr=6 
#   field _totalTime                     float                                              off=0x30 attr=1 SerializeField
#   field _isCountingDown                bool                                               off=0x34 attr=1 
## get_IsCountingDown() -> bool
---- Home.BonusController::get_IsCountingDown 0x2d1dedc
02d1dedc: ldrb    w0, [x0, #0x34]                            ._isCountingDown
02d1dee0: ret                                                
## StartCountdown(float minutes) -> void
---- Home.BonusController::StartCountdown 0x2d1dee4
02d1dee4: stp     x30, x19, [sp, #-0x10]!                    
02d1dee8: mov     w8, #0x42700000                            
02d1deec: mov     x19, x0                                    
02d1def0: fmov    s1, w8                                     
02d1def4: mov     w8, #1                                     
02d1def8: strb    w8, [x0, #0x34]                            ._isCountingDown
02d1defc: fmul    s0, s0, s1                                 
02d1df00: str     s0, [x0, #0x30]                            ._totalTime
02d1df04: bl      #0x2d1df1c                                 Home.BonusController::RepeatEvery
02d1df08: mov     x1, x0                                     
02d1df0c: mov     x0, x19                                    
02d1df10: mov     x2, xzr                                    
02d1df14: ldp     x30, x19, [sp], #0x10                      
02d1df18: b       #0x5b389f0                                 UnityEngine.MonoBehaviour::StartCoroutine
## RepeatEvery() -> System.Collections.IEnumerator
---- Home.BonusController::RepeatEvery 0x2d1df1c
02d1df1c: stp     x30, x21, [sp, #-0x20]!                    
02d1df20: stp     x20, x19, [sp, #0x10]                      
02d1df24: adrp    x20, #0x6630000                            
02d1df28: adrp    x21, #0x6269000                            
02d1df2c: mov     x19, x0                                    
02d1df30: ldrb    w8, [x20, #0x2e]                           
02d1df34: ldr     x21, [x21, #0xd10]                         T:Home.BonusController/<RepeatEvery>d__7
02d1df38: tbnz    w8, #0, #0x2d1df50                         
02d1df3c: adrp    x0, #0x6269000                             
02d1df40: ldr     x0, [x0, #0xd10]                           T:Home.BonusController/<RepeatEvery>d__7
02d1df44: bl      #0x2b70db0                                 fn_2b70db0
02d1df48: mov     w8, #1                                     
02d1df4c: strb    w8, [x20, #0x2e]                           
02d1df50: ldr     x0, [x21]                                  T:Trading.TradingSession/<>c__DisplayClass56_0
02d1df54: bl      #0x2b7104c                                 fn_2b7104c
02d1df58: mov     x1, xzr                                    
02d1df5c: mov     x20, x0                                    
02d1df60: bl      #0x4e53e9c                                 System.Object::.ctor
02d1df64: mov     x0, x20                                    
02d1df68: mov     x1, x19                                    
02d1df6c: str     wzr, [x20, #0x10]                          
02d1df70: str     x19, [x0, #0x20]!                          .OnTimeRemainingChanged
02d1df74: bl      #0x2b70d54                                 fn_2b70d54
02d1df78: mov     x0, x20                                    
02d1df7c: ldp     x20, x19, [sp, #0x10]                      
02d1df80: ldp     x30, x21, [sp], #0x20                      
02d1df84: ret                                                
## OnApplicationQuit() -> void
---- Home.BonusController::OnApplicationQuit 0x2d1dfb0
02d1dfb0: str     wzr, [x0, #0x30]                           ._totalTime
02d1dfb4: strb    wzr, [x0, #0x34]                           ._isCountingDown
02d1dfb8: ret                                                
## OnEnable() -> void
---- Home.BonusController::OnEnable 0x2d1dfbc
02d1dfbc: stp     x30, x23, [sp, #-0x30]!                    
02d1dfc0: stp     x22, x21, [sp, #0x10]                      
02d1dfc4: stp     x20, x19, [sp, #0x20]                      
02d1dfc8: adrp    x22, #0x6630000                            
02d1dfcc: adrp    x23, #0x6269000                            
02d1dfd0: adrp    x20, #0x6269000                            
02d1dfd4: adrp    x21, #0x6264000                            
02d1dfd8: ldr     x23, [x23, #0xd18]                         T:type19698(k15)
02d1dfdc: ldrb    w8, [x22, #0x2f]                           
02d1dfe0: ldr     x20, [x20, #0xd20]                         M:Home.BonusController::OnSceneLoaded
02d1dfe4: ldr     x21, [x21, #0xb58]                         T:UnityEngine.SceneManagement.SceneManager
02d1dfe8: mov     x19, x0                                    
02d1dfec: tbnz    w8, #0, #0x2d1e01c                         
02d1dff0: adrp    x0, #0x6269000                             
02d1dff4: ldr     x0, [x0, #0xd20]                           M:Home.BonusController::OnSceneLoaded
02d1dff8: bl      #0x2b70db0                                 fn_2b70db0
02d1dffc: adrp    x0, #0x6264000                             
02d1e000: ldr     x0, [x0, #0xb58]                           T:UnityEngine.SceneManagement.SceneManager
02d1e004: bl      #0x2b70db0                                 fn_2b70db0
02d1e008: adrp    x0, #0x6269000                             
02d1e00c: ldr     x0, [x0, #0xd18]                           T:type19698(k15)
02d1e010: bl      #0x2b70db0                                 fn_2b70db0
02d1e014: mov     w8, #1                                     
02d1e018: strb    w8, [x22, #0x2f]                           
02d1e01c: ldr     x0, [x23]                                  T:Trading.TradingSession/<>c__DisplayClass56_0
02d1e020: bl      #0x2b7104c                                 fn_2b7104c
02d1e024: ldr     x2, [x20]                                  T:Trading.TradingSession/<>c__DisplayClass56_0
02d1e028: mov     x1, x19                                    
02d1e02c: mov     x3, xzr                                    
02d1e030: mov     x20, x0                                    
02d1e034: bl      #0x3edff98                                 fn_3edff98
02d1e038: ldr     x0, [x21]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d1e03c: ldr     w8, [x0, #0xe4]                            [62690e4]=0 f=0,0
02d1e040: cbnz    w8, #0x2d1e048                             
02d1e044: bl      #0x2b70f30                                 fn_2b70f30
02d1e048: mov     x0, x20                                    
02d1e04c: ldp     x20, x19, [sp, #0x20]                      
02d1e050: ldp     x22, x21, [sp, #0x10]                      
02d1e054: mov     x1, xzr                                    
02d1e058: ldp     x30, x23, [sp], #0x30                      
02d1e05c: b       #0x5b4f18c                                 UnityEngine.SceneManagement.SceneManager::add_sceneLoaded
## OnDisable() -> void
---- Home.BonusController::OnDisable 0x2d1e060
02d1e060: stp     x30, x23, [sp, #-0x30]!                    
02d1e064: stp     x22, x21, [sp, #0x10]                      
02d1e068: stp     x20, x19, [sp, #0x20]                      
02d1e06c: adrp    x22, #0x6630000                            
02d1e070: adrp    x23, #0x6269000                            
02d1e074: adrp    x20, #0x6269000                            
02d1e078: adrp    x21, #0x6264000                            
02d1e07c: ldr     x23, [x23, #0xd18]                         T:type19698(k15)
02d1e080: ldrb    w8, [x22, #0x30]                           
02d1e084: ldr     x20, [x20, #0xd20]                         M:Home.BonusController::OnSceneLoaded
02d1e088: ldr     x21, [x21, #0xb58]                         T:UnityEngine.SceneManagement.SceneManager
02d1e08c: mov     x19, x0                                    
02d1e090: tbnz    w8, #0, #0x2d1e0c0                         
02d1e094: adrp    x0, #0x6269000                             
02d1e098: ldr     x0, [x0, #0xd20]                           M:Home.BonusController::OnSceneLoaded
02d1e09c: bl      #0x2b70db0                                 fn_2b70db0
02d1e0a0: adrp    x0, #0x6264000                             
02d1e0a4: ldr     x0, [x0, #0xb58]                           T:UnityEngine.SceneManagement.SceneManager
02d1e0a8: bl      #0x2b70db0                                 fn_2b70db0
02d1e0ac: adrp    x0, #0x6269000                             
02d1e0b0: ldr     x0, [x0, #0xd18]                           T:type19698(k15)
02d1e0b4: bl      #0x2b70db0                                 fn_2b70db0
02d1e0b8: mov     w8, #1                                     
02d1e0bc: strb    w8, [x22, #0x30]                           
02d1e0c0: ldr     x0, [x23]                                  T:Trading.TradingSession/<>c__DisplayClass56_0
02d1e0c4: bl      #0x2b7104c                                 fn_2b7104c
02d1e0c8: ldr     x2, [x20]                                  T:Trading.TradingSession/<>c__DisplayClass56_0
02d1e0cc: mov     x1, x19                                    
02d1e0d0: mov     x3, xzr                                    
02d1e0d4: mov     x20, x0                                    
02d1e0d8: bl      #0x3edff98                                 fn_3edff98
02d1e0dc: ldr     x0, [x21]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d1e0e0: ldr     w8, [x0, #0xe4]                            [62690e4]=0 f=0,0
02d1e0e4: cbnz    w8, #0x2d1e0ec                             
02d1e0e8: bl      #0x2b70f30                                 fn_2b70f30
02d1e0ec: mov     x0, x20                                    
02d1e0f0: ldp     x20, x19, [sp, #0x20]                      
02d1e0f4: ldp     x22, x21, [sp, #0x10]                      
02d1e0f8: mov     x1, xzr                                    
02d1e0fc: ldp     x30, x23, [sp], #0x30                      
02d1e100: b       #0x5b4f280                                 UnityEngine.SceneManagement.SceneManager::remove_sceneLoaded
## OnSceneLoaded(UnityEngine.SceneManagement.Scene scene, UnityEngine.SceneManagement.LoadSceneMode mode) -> void
---- Home.BonusController::OnSceneLoaded 0x2d1e104
02d1e104: ldrb    w8, [x0, #0x34]                            ._isCountingDown
02d1e108: cbz     w8, #0x2d1e12c                             
02d1e10c: stp     x30, x19, [sp, #-0x10]!                    
02d1e110: mov     x19, x0                                    
02d1e114: bl      #0x2d1df1c                                 Home.BonusController::RepeatEvery
02d1e118: mov     x1, x0                                     
02d1e11c: mov     x0, x19                                    
02d1e120: mov     x2, xzr                                    
02d1e124: ldp     x30, x19, [sp], #0x10                      
02d1e128: b       #0x5b389f0                                 UnityEngine.MonoBehaviour::StartCoroutine
02d1e12c: ret                                                
## .ctor() -> void
---- Home.BonusController::.ctor 0x2d1e130
02d1e130: stp     x30, x21, [sp, #-0x20]!                    
02d1e134: stp     x20, x19, [sp, #0x10]                      
02d1e138: adrp    x20, #0x6630000                            
02d1e13c: adrp    x21, #0x6269000                            
02d1e140: mov     x19, x0                                    
02d1e144: ldrb    w8, [x20, #0x31]                           
02d1e148: ldr     x21, [x21, #0xd28]                         MS:MonoSingleton`1::.ctor
02d1e14c: tbnz    w8, #0, #0x2d1e164                         
02d1e150: adrp    x0, #0x6269000                             
02d1e154: ldr     x0, [x0, #0xd28]                           MS:MonoSingleton`1::.ctor
02d1e158: bl      #0x2b70db0                                 fn_2b70db0
02d1e15c: mov     w8, #1                                     
02d1e160: strb    w8, [x20, #0x31]                           
02d1e164: mov     x0, x19                                    
02d1e168: ldp     x20, x19, [sp, #0x10]                      
02d1e16c: ldr     x1, [x21]                                  T:Trading.TradingSession/<>c__DisplayClass56_0
02d1e170: ldp     x30, x21, [sp], #0x20                      
02d1e174: b       #0x3769e18                                 
