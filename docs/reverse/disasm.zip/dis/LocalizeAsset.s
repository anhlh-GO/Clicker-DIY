#### CLASS LocalizeAsset/<>c__DisplayClass1_0 parent= object
#   field language                       string                                             off=0x10 attr=6 
## .ctor() -> void
---- LocalizeAsset/<>c__DisplayClass1_0::.ctor 0x2cd9290
02cd9290: mov     x1, xzr                                    
02cd9294: b       #0x4e53e9c                                 System.Object::.ctor
## <GetData>b__0(LanguageDataItem x) -> bool
---- LocalizeAsset/<>c__DisplayClass1_0::<GetData>b__0 0x2cd954c
02cd954c: cbz     x1, #0x2cd9564                             
02cd9550: ldr     x8, [x1, #0x10]                            
02cd9554: ldr     x1, [x0, #0x10]                            .language
02cd9558: mov     x2, xzr                                    
02cd955c: mov     x0, x8                                     
02cd9560: b       #0x4ca52b8                                 System.String::op_Equality
02cd9564: str     x30, [sp, #-0x10]!                         
02cd9568: bl      #0x2b7105c                                 fn_2b7105c
#### CLASS LocalizeAsset/<>c__DisplayClass2_0 parent= object
#   field language                       string                                             off=0x10 attr=6 
## .ctor() -> void
---- LocalizeAsset/<>c__DisplayClass2_0::.ctor 0x2cd93e0
02cd93e0: mov     x1, xzr                                    
02cd93e4: b       #0x4e53e9c                                 System.Object::.ctor
## <GetNextData>b__0(LanguageDataItem x) -> bool
---- LocalizeAsset/<>c__DisplayClass2_0::<GetNextData>b__0 0x2cd956c
02cd956c: cbz     x1, #0x2cd9584                             
02cd9570: ldr     x8, [x1, #0x10]                            
02cd9574: ldr     x1, [x0, #0x10]                            .language
02cd9578: mov     x2, xzr                                    
02cd957c: mov     x0, x8                                     
02cd9580: b       #0x4ca52b8                                 System.String::op_Equality
02cd9584: str     x30, [sp, #-0x10]!                         
02cd9588: bl      #0x2b7105c                                 fn_2b7105c
#### CLASS LocalizeAsset/<>c__DisplayClass3_0 parent= object
#   field language                       string                                             off=0x10 attr=6 
## .ctor() -> void
---- LocalizeAsset/<>c__DisplayClass3_0::.ctor 0x2cd9534
02cd9534: mov     x1, xzr                                    
02cd9538: b       #0x4e53e9c                                 System.Object::.ctor
## <GetPreviousData>b__0(LanguageDataItem x) -> bool
---- LocalizeAsset/<>c__DisplayClass3_0::<GetPreviousData>b__0 0x2cd958c
02cd958c: cbz     x1, #0x2cd95a4                             
02cd9590: ldr     x8, [x1, #0x10]                            
02cd9594: ldr     x1, [x0, #0x10]                            .language
02cd9598: mov     x2, xzr                                    
02cd959c: mov     x0, x8                                     
02cd95a0: b       #0x4ca52b8                                 System.String::op_Equality
02cd95a4: str     x30, [sp, #-0x10]!                         
02cd95a8: bl      #0x2b7105c                                 fn_2b7105c
#### CLASS LocalizeAsset parent= UnityEngine.ScriptableObject
#   field DataList                       System.Collections.Generic.List`1<LanguageDataItem> off=0x18 attr=6 
## GetData(string language) -> LanguageDataItem
---- LocalizeAsset::GetData 0x2cd91ac
02cd91ac: stp     x30, x23, [sp, #-0x30]!                    
02cd91b0: stp     x22, x21, [sp, #0x10]                      
02cd91b4: stp     x20, x19, [sp, #0x20]                      
02cd91b8: adrp    x21, #0x662f000                            
02cd91bc: adrp    x22, #0x6267000                            
02cd91c0: mov     x19, x1                                    
02cd91c4: ldrb    w8, [x21, #0xd44]                          
02cd91c8: ldr     x22, [x22, #0xab8]                         T:LocalizeAsset/<>c__DisplayClass1_0
02cd91cc: mov     x20, x0                                    
02cd91d0: tbnz    w8, #0, #0x2cd920c                         
02cd91d4: adrp    x0, #0x6267000                             
02cd91d8: ldr     x0, [x0, #0xac0]                           MS:System.Collections.Generic.List`1::Find
02cd91dc: bl      #0x2b70db0                                 fn_2b70db0
02cd91e0: adrp    x0, #0x6267000                             
02cd91e4: ldr     x0, [x0, #0xac8]                           T:type57257(k15)
02cd91e8: bl      #0x2b70db0                                 fn_2b70db0
02cd91ec: adrp    x0, #0x6267000                             
02cd91f0: ldr     x0, [x0, #0xad0]                           M:LocalizeAsset/<>c__DisplayClass1_0::<GetData>b__0
02cd91f4: bl      #0x2b70db0                                 fn_2b70db0
02cd91f8: adrp    x0, #0x6267000                             
02cd91fc: ldr     x0, [x0, #0xab8]                           T:LocalizeAsset/<>c__DisplayClass1_0
02cd9200: bl      #0x2b70db0                                 fn_2b70db0
02cd9204: mov     w8, #1                                     
02cd9208: strb    w8, [x21, #0xd44]                          
02cd920c: ldr     x0, [x22]                                  S:'didu'
02cd9210: bl      #0x2b7104c                                 fn_2b7104c
02cd9214: mov     x1, xzr                                    
02cd9218: mov     x21, x0                                    
02cd921c: bl      #0x4e53e9c                                 System.Object::.ctor
02cd9220: cbz     x21, #0x2cd928c                            
02cd9224: adrp    x22, #0x6267000                            
02cd9228: adrp    x23, #0x6267000                            
02cd922c: mov     x0, x21                                    
02cd9230: ldr     x22, [x22, #0xac8]                         T:type57257(k15)
02cd9234: ldr     x23, [x23, #0xad0]                         M:LocalizeAsset/<>c__DisplayClass1_0::<GetData>b__0
02cd9238: mov     x1, x19                                    
02cd923c: str     x19, [x0, #0x10]!                          
02cd9240: bl      #0x2b70d54                                 fn_2b70d54
02cd9244: ldr     x0, [x22]                                  S:'didu'
02cd9248: ldr     x19, [x20, #0x18]                          .DataList
02cd924c: bl      #0x2b7104c                                 fn_2b7104c
02cd9250: ldr     x2, [x23]                                  S:'didu'
02cd9254: mov     x1, x21                                    
02cd9258: mov     x3, xzr                                    
02cd925c: mov     x20, x0                                    
02cd9260: bl      #0x399ba10                                 fn_399ba10
02cd9264: cbz     x19, #0x2cd928c                            
02cd9268: adrp    x8, #0x6267000                             
02cd926c: mov     x0, x19                                    
02cd9270: mov     x1, x20                                    
02cd9274: ldr     x8, [x8, #0xac0]                           MS:System.Collections.Generic.List`1::Find
02cd9278: ldp     x20, x19, [sp, #0x20]                      
02cd927c: ldp     x22, x21, [sp, #0x10]                      
02cd9280: ldr     x2, [x8]                                   S:'didu'
02cd9284: ldp     x30, x23, [sp], #0x30                      
02cd9288: b       #0x35a9868                                 
02cd928c: bl      #0x2b7105c                                 fn_2b7105c
## GetNextData(string language) -> LanguageDataItem
---- LocalizeAsset::GetNextData 0x2cd9298
02cd9298: str     x30, [sp, #-0x30]!                         
02cd929c: stp     x22, x21, [sp, #0x10]                      
02cd92a0: stp     x20, x19, [sp, #0x20]                      
02cd92a4: adrp    x21, #0x662f000                            
02cd92a8: adrp    x22, #0x6267000                            
02cd92ac: mov     x20, x1                                    
02cd92b0: ldrb    w8, [x21, #0xd45]                          
02cd92b4: ldr     x22, [x22, #0xad8]                         T:LocalizeAsset/<>c__DisplayClass2_0
02cd92b8: mov     x19, x0                                    
02cd92bc: tbnz    w8, #0, #0x2cd9310                         
02cd92c0: adrp    x0, #0x6267000                             
02cd92c4: ldr     x0, [x0, #0xae0]                           MS:System.Collections.Generic.List`1::FindIndex
02cd92c8: bl      #0x2b70db0                                 fn_2b70db0
02cd92cc: adrp    x0, #0x6267000                             
02cd92d0: ldr     x0, [x0, #0xae8]                           MS:System.Collections.Generic.List`1::get_Count
02cd92d4: bl      #0x2b70db0                                 fn_2b70db0
02cd92d8: adrp    x0, #0x6267000                             
02cd92dc: ldr     x0, [x0, #0xaf0]                           MS:System.Collections.Generic.List`1::get_Item
02cd92e0: bl      #0x2b70db0                                 fn_2b70db0
02cd92e4: adrp    x0, #0x6267000                             
02cd92e8: ldr     x0, [x0, #0xac8]                           T:type57257(k15)
02cd92ec: bl      #0x2b70db0                                 fn_2b70db0
02cd92f0: adrp    x0, #0x6267000                             
02cd92f4: ldr     x0, [x0, #0xaf8]                           M:LocalizeAsset/<>c__DisplayClass2_0::<GetNextData>b__0
02cd92f8: bl      #0x2b70db0                                 fn_2b70db0
02cd92fc: adrp    x0, #0x6267000                             
02cd9300: ldr     x0, [x0, #0xad8]                           T:LocalizeAsset/<>c__DisplayClass2_0
02cd9304: bl      #0x2b70db0                                 fn_2b70db0
02cd9308: mov     w8, #1                                     
02cd930c: strb    w8, [x21, #0xd45]                          
02cd9310: ldr     x0, [x22]                                  S:'didu'
02cd9314: bl      #0x2b7104c                                 fn_2b7104c
02cd9318: mov     x1, xzr                                    
02cd931c: mov     x21, x0                                    
02cd9320: bl      #0x4e53e9c                                 System.Object::.ctor
02cd9324: cbz     x21, #0x2cd93dc                            
02cd9328: mov     x0, x21                                    
02cd932c: mov     x1, x20                                    
02cd9330: str     x20, [x0, #0x10]!                          
02cd9334: bl      #0x2b70d54                                 fn_2b70d54
02cd9338: ldr     x20, [x19, #0x18]                          .DataList
02cd933c: cbz     x20, #0x2cd93c8                            
02cd9340: ldr     w8, [x20, #0x18]                           .DataList
02cd9344: cbz     w8, #0x2cd93c8                             
02cd9348: adrp    x8, #0x6267000                             
02cd934c: ldr     x8, [x8, #0xac8]                           T:type57257(k15)
02cd9350: ldr     x0, [x8]                                   S:'didu'
02cd9354: bl      #0x2b7104c                                 fn_2b7104c
02cd9358: adrp    x8, #0x6267000                             
02cd935c: mov     x1, x21                                    
02cd9360: mov     x3, xzr                                    
02cd9364: ldr     x8, [x8, #0xaf8]                           M:LocalizeAsset/<>c__DisplayClass2_0::<GetNextData>b__0
02cd9368: mov     x22, x0                                    
02cd936c: ldr     x2, [x8]                                   S:'didu'
02cd9370: bl      #0x399ba10                                 fn_399ba10
02cd9374: adrp    x8, #0x6267000                             
02cd9378: mov     x0, x20                                    
02cd937c: mov     x1, x22                                    
02cd9380: ldr     x8, [x8, #0xae0]                           MS:System.Collections.Generic.List`1::FindIndex
02cd9384: ldr     x2, [x8]                                   S:'didu'
02cd9388: bl      #0x35a9a60                                 fn_35a9a60
02cd938c: tbnz    w0, #0x1f, #0x2cd93c8                      
02cd9390: mov     w8, w0                                     
02cd9394: ldr     x0, [x19, #0x18]                           .DataList
02cd9398: cbz     x0, #0x2cd93dc                             
02cd939c: ldr     w9, [x0, #0x18]                            S:'android.content.Intent' .DataList
02cd93a0: add     w8, w8, #1                                 
02cd93a4: adrp    x11, #0x6267000                            
02cd93a8: ldr     x11, [x11, #0xaf0]                         MS:System.Collections.Generic.List`1::get_Item
02cd93ac: ldp     x20, x19, [sp, #0x20]                      
02cd93b0: sdiv    w10, w8, w9                                
02cd93b4: ldp     x22, x21, [sp, #0x10]                      
02cd93b8: ldr     x2, [x11]                                  S:'didu'
02cd93bc: msub    w1, w10, w9, w8                            
02cd93c0: ldr     x30, [sp], #0x30                           
02cd93c4: b       #0x35a8f3c                                 
02cd93c8: ldp     x20, x19, [sp, #0x20]                      
02cd93cc: mov     x0, xzr                                    
02cd93d0: ldp     x22, x21, [sp, #0x10]                      
02cd93d4: ldr     x30, [sp], #0x30                           
02cd93d8: ret                                                
02cd93dc: bl      #0x2b7105c                                 fn_2b7105c
## GetPreviousData(string language) -> LanguageDataItem
---- LocalizeAsset::GetPreviousData 0x2cd93e8
02cd93e8: str     x30, [sp, #-0x30]!                         
02cd93ec: stp     x22, x21, [sp, #0x10]                      
02cd93f0: stp     x20, x19, [sp, #0x20]                      
02cd93f4: adrp    x21, #0x662f000                            
02cd93f8: adrp    x22, #0x6267000                            
02cd93fc: mov     x20, x1                                    
02cd9400: ldrb    w8, [x21, #0xd46]                          
02cd9404: ldr     x22, [x22, #0xb00]                         T:LocalizeAsset/<>c__DisplayClass3_0
02cd9408: mov     x19, x0                                    
02cd940c: tbnz    w8, #0, #0x2cd9460                         
02cd9410: adrp    x0, #0x6267000                             
02cd9414: ldr     x0, [x0, #0xae0]                           MS:System.Collections.Generic.List`1::FindIndex
02cd9418: bl      #0x2b70db0                                 fn_2b70db0
02cd941c: adrp    x0, #0x6267000                             
02cd9420: ldr     x0, [x0, #0xae8]                           MS:System.Collections.Generic.List`1::get_Count
02cd9424: bl      #0x2b70db0                                 fn_2b70db0
02cd9428: adrp    x0, #0x6267000                             
02cd942c: ldr     x0, [x0, #0xaf0]                           MS:System.Collections.Generic.List`1::get_Item
02cd9430: bl      #0x2b70db0                                 fn_2b70db0
02cd9434: adrp    x0, #0x6267000                             
02cd9438: ldr     x0, [x0, #0xac8]                           T:type57257(k15)
02cd943c: bl      #0x2b70db0                                 fn_2b70db0
02cd9440: adrp    x0, #0x6267000                             
02cd9444: ldr     x0, [x0, #0xb08]                           M:LocalizeAsset/<>c__DisplayClass3_0::<GetPreviousData>b__0
02cd9448: bl      #0x2b70db0                                 fn_2b70db0
02cd944c: adrp    x0, #0x6267000                             
02cd9450: ldr     x0, [x0, #0xb00]                           T:LocalizeAsset/<>c__DisplayClass3_0
02cd9454: bl      #0x2b70db0                                 fn_2b70db0
02cd9458: mov     w8, #1                                     
02cd945c: strb    w8, [x21, #0xd46]                          
02cd9460: ldr     x0, [x22]                                  S:'didu'
02cd9464: bl      #0x2b7104c                                 fn_2b7104c
02cd9468: mov     x1, xzr                                    
02cd946c: mov     x21, x0                                    
02cd9470: bl      #0x4e53e9c                                 System.Object::.ctor
02cd9474: cbz     x21, #0x2cd9530                            
02cd9478: mov     x0, x21                                    
02cd947c: mov     x1, x20                                    
02cd9480: str     x20, [x0, #0x10]!                          
02cd9484: bl      #0x2b70d54                                 fn_2b70d54
02cd9488: ldr     x20, [x19, #0x18]                          .DataList
02cd948c: cbz     x20, #0x2cd94f4                            
02cd9490: ldr     w8, [x20, #0x18]                           .DataList
02cd9494: cbz     w8, #0x2cd94f4                             
02cd9498: adrp    x8, #0x6267000                             
02cd949c: ldr     x8, [x8, #0xac8]                           T:type57257(k15)
02cd94a0: ldr     x0, [x8]                                   S:'didu'
02cd94a4: bl      #0x2b7104c                                 fn_2b7104c
02cd94a8: adrp    x8, #0x6267000                             
02cd94ac: mov     x1, x21                                    
02cd94b0: mov     x3, xzr                                    
02cd94b4: ldr     x8, [x8, #0xb08]                           M:LocalizeAsset/<>c__DisplayClass3_0::<GetPreviousData>b__0
02cd94b8: mov     x22, x0                                    
02cd94bc: ldr     x2, [x8]                                   S:'didu'
02cd94c0: bl      #0x399ba10                                 fn_399ba10
02cd94c4: adrp    x8, #0x6267000                             
02cd94c8: mov     x0, x20                                    
02cd94cc: mov     x1, x22                                    
02cd94d0: ldr     x8, [x8, #0xae0]                           MS:System.Collections.Generic.List`1::FindIndex
02cd94d4: ldr     x2, [x8]                                   S:'didu'
02cd94d8: bl      #0x35a9a60                                 fn_35a9a60
02cd94dc: tbnz    w0, #0x1f, #0x2cd94f4                      
02cd94e0: mov     w8, w0                                     
02cd94e4: ldr     x0, [x19, #0x18]                           .DataList
02cd94e8: cbz     w8, #0x2cd9508                             
02cd94ec: cbnz    x0, #0x2cd9510                             
02cd94f0: b       #0x2cd9530                                 
02cd94f4: ldp     x20, x19, [sp, #0x20]                      
02cd94f8: mov     x0, xzr                                    
02cd94fc: ldp     x22, x21, [sp, #0x10]                      
02cd9500: ldr     x30, [sp], #0x30                           
02cd9504: ret                                                
02cd9508: cbz     x0, #0x2cd9530                             
02cd950c: ldr     w8, [x0, #0x18]                            S:'android.content.Intent' .DataList
02cd9510: adrp    x9, #0x6267000                             
02cd9514: sub     w1, w8, #1                                 
02cd9518: ldr     x9, [x9, #0xaf0]                           MS:System.Collections.Generic.List`1::get_Item
02cd951c: ldp     x20, x19, [sp, #0x20]                      
02cd9520: ldp     x22, x21, [sp, #0x10]                      
02cd9524: ldr     x2, [x9]                                   S:'didu'
02cd9528: ldr     x30, [sp], #0x30                           
02cd952c: b       #0x35a8f3c                                 
02cd9530: bl      #0x2b7105c                                 fn_2b7105c
## GetAllData() -> System.Collections.Generic.List`1<LanguageDataItem>
---- LocalizeAsset::GetAllData 0x2cd953c
02cd953c: ldr     x0, [x0, #0x18]                            .DataList
02cd9540: ret                                                
## .ctor() -> void
---- LocalizeAsset::.ctor 0x2cd9544
02cd9544: mov     x1, xzr                                    
02cd9548: b       #0x5b398f0                                 UnityEngine.ScriptableObject::.ctor
