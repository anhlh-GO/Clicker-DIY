#### CLASS BaseKeycapSyncData parent= object
#   field ShowIndex                      string                                             off=0x10 attr=6 
#   field SpriteName                     string                                             off=0x18 attr=6 
#   field LockType                       string                                             off=0x20 attr=6 
#   field value                          int                                                off=0x28 attr=6 
## .ctor() -> void
---- BaseKeycapSyncData::.ctor 0x2ca81e8
02ca81e8: mov     x1, xzr                                    
02ca81ec: b       #0x4e53e9c                                 System.Object::.ctor
