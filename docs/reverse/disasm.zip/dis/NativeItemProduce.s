#### CLASS NativeItemProduce parent= NativeProduceBase`1<NativeItemProduce>
## SetAdFormat() -> void
---- NativeItemProduce::SetAdFormat 0x2c9bb48
02c9bb48: mov     w8, #6                                     
02c9bb4c: str     w8, [x0, #0x34]                            
02c9bb50: ret                                                
## Start() -> void
---- NativeItemProduce::Start 0x2c9bb54
02c9bb54: ldr     x8, [x0]                                   
02c9bb58: ldp     x2, x1, [x8, #0x188]                       
02c9bb5c: br      x2                                         
## .ctor() -> void
---- NativeItemProduce::.ctor 0x2c9bb60
02c9bb60: stp     x30, x21, [sp, #-0x20]!                    
02c9bb64: stp     x20, x19, [sp, #0x10]                      
02c9bb68: adrp    x20, #0x662f000                            
02c9bb6c: adrp    x21, #0x6265000                            
02c9bb70: mov     x19, x0                                    
02c9bb74: ldrb    w8, [x20, #0xa46]                          
02c9bb78: ldr     x21, [x21, #0xab8]                         MS:NativeProduceBase`1::.ctor
02c9bb7c: tbnz    w8, #0, #0x2c9bb94                         
02c9bb80: adrp    x0, #0x6265000                             
02c9bb84: ldr     x0, [x0, #0xab8]                           MS:NativeProduceBase`1::.ctor
02c9bb88: bl      #0x2b70db0                                 fn_2b70db0
02c9bb8c: mov     w8, #1                                     
02c9bb90: strb    w8, [x20, #0xa46]                          
02c9bb94: mov     x0, x19                                    
02c9bb98: ldp     x20, x19, [sp, #0x10]                      
02c9bb9c: ldr     x1, [x21]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9bba0: ldp     x30, x21, [sp], #0x20                      
02c9bba4: b       #0x38cf860                                 
