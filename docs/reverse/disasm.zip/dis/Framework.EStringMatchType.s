#### CLASS Framework.EStringMatchType parent= int
#   field value__                        int                                                off=0x10 attr=606 
#   field Exactly                        Framework.EStringMatchType                         off=0x0 attr=8056 
#   field Exactly_IgnoreCase             Framework.EStringMatchType                         off=0x0 attr=8056 
#   field Contains                       Framework.EStringMatchType                         off=0x0 attr=8056 
#   field Contains_IgnoreCase            Framework.EStringMatchType                         off=0x0 attr=8056 
