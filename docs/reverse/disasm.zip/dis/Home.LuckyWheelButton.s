#### CLASS Home.LuckyWheelButton/<>c__DisplayClass3_0 parent= object
#   field value                          bool                                               off=0x10 attr=6 
## .ctor() -> void
---- Home.LuckyWheelButton/<>c__DisplayClass3_0::.ctor 0x2d23d48
02d23d48: mov     x1, xzr                                    
02d23d4c: b       #0x4e53e9c                                 System.Object::.ctor
## <SetActiveNotification>b__0(UnityEngine.GameObject x) -> void
---- Home.LuckyWheelButton/<>c__DisplayClass3_0::<SetActiveNotification>b__0 0x2d23d58
02d23d58: cbz     x1, #0x2d23d70                             
02d23d5c: ldrb    w8, [x0, #0x10]                            .value
02d23d60: mov     x0, x1                                     
02d23d64: mov     x2, xzr                                    
02d23d68: mov     w1, w8                                     
02d23d6c: b       #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d23d70: str     x30, [sp, #-0x10]!                         
02d23d74: bl      #0x2b7105c                                 fn_2b7105c
#### CLASS Home.LuckyWheelButton parent= UnityEngine.MonoBehaviour
#   field _handTutorialGo                UnityEngine.GameObject                             off=0x20 attr=1 SerializeField
#   field _luckyWheelNotificationGos     System.Collections.Generic.List`1<UnityEngine.GameObject> off=0x28 attr=1 SerializeField
## SetActiveTutorial(bool value) -> void
---- Home.LuckyWheelButton::SetActiveTutorial 0x2d23c50
02d23c50: ldr     x0, [x0, #0x20]                            ._handTutorialGo
02d23c54: cbz     x0, #0x2d23c64                             
02d23c58: and     w1, w1, #1                                 
02d23c5c: mov     x2, xzr                                    
02d23c60: b       #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d23c64: str     x30, [sp, #-0x10]!                         
02d23c68: bl      #0x2b7105c                                 fn_2b7105c
## SetActiveNotification(bool value) -> void
---- Home.LuckyWheelButton::SetActiveNotification 0x2d23c6c
02d23c6c: str     x30, [sp, #-0x30]!                         
02d23c70: stp     x22, x21, [sp, #0x10]                      
02d23c74: stp     x20, x19, [sp, #0x20]                      
02d23c78: adrp    x21, #0x6630000                            
02d23c7c: adrp    x22, #0x6269000                            
02d23c80: mov     w19, w1                                    
02d23c84: ldrb    w8, [x21, #0x5a]                           
02d23c88: ldr     x22, [x22, #0xee0]                         T:Home.LuckyWheelButton/<>c__DisplayClass3_0
02d23c8c: mov     x20, x0                                    
02d23c90: tbnz    w8, #0, #0x2d23ccc                         
02d23c94: adrp    x0, #0x6266000                             
02d23c98: ldr     x0, [x0, #0xda8]                           T:type6904(k15)
02d23c9c: bl      #0x2b70db0                                 fn_2b70db0
02d23ca0: adrp    x0, #0x6266000                             
02d23ca4: ldr     x0, [x0, #0xdb0]                           MS:System.Collections.Generic.List`1::ForEach
02d23ca8: bl      #0x2b70db0                                 fn_2b70db0
02d23cac: adrp    x0, #0x6269000                             
02d23cb0: ldr     x0, [x0, #0xee8]                           M:Home.LuckyWheelButton/<>c__DisplayClass3_0::<SetActiveNotification>b__0
02d23cb4: bl      #0x2b70db0                                 fn_2b70db0
02d23cb8: adrp    x0, #0x6269000                             
02d23cbc: ldr     x0, [x0, #0xee0]                           T:Home.LuckyWheelButton/<>c__DisplayClass3_0
02d23cc0: bl      #0x2b70db0                                 fn_2b70db0
02d23cc4: mov     w8, #1                                     
02d23cc8: strb    w8, [x21, #0x5a]                           
02d23ccc: ldr     x0, [x22]                                  T:Trading.TradingSession/<>c__DisplayClass56_0
02d23cd0: bl      #0x2b7104c                                 fn_2b7104c
02d23cd4: mov     x1, xzr                                    
02d23cd8: mov     x21, x0                                    
02d23cdc: bl      #0x4e53e9c                                 System.Object::.ctor
02d23ce0: cbz     x21, #0x2d23d44                            
02d23ce4: adrp    x8, #0x6266000                             
02d23ce8: adrp    x22, #0x6269000                            
02d23cec: and     w9, w19, #1                                
02d23cf0: ldr     x8, [x8, #0xda8]                           T:type6904(k15)
02d23cf4: ldr     x22, [x22, #0xee8]                         M:Home.LuckyWheelButton/<>c__DisplayClass3_0::<SetActiveNotification>b__0
02d23cf8: ldr     x19, [x20, #0x28]                          ._luckyWheelNotificationGos
02d23cfc: strb    w9, [x21, #0x10]                           
02d23d00: ldr     x0, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d23d04: bl      #0x2b7104c                                 fn_2b7104c
02d23d08: ldr     x2, [x22]                                  T:Trading.TradingSession/<>c__DisplayClass56_0
02d23d0c: mov     x1, x21                                    
02d23d10: mov     x3, xzr                                    
02d23d14: mov     x20, x0                                    
02d23d18: bl      #0x453418c                                 fn_453418c
02d23d1c: cbz     x19, #0x2d23d44                            
02d23d20: adrp    x8, #0x6266000                             
02d23d24: mov     x0, x19                                    
02d23d28: mov     x1, x20                                    
02d23d2c: ldr     x8, [x8, #0xdb0]                           MS:System.Collections.Generic.List`1::ForEach
02d23d30: ldp     x20, x19, [sp, #0x20]                      
02d23d34: ldp     x22, x21, [sp, #0x10]                      
02d23d38: ldr     x2, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d23d3c: ldr     x30, [sp], #0x30                           
02d23d40: b       #0x35a9ce4                                 
02d23d44: bl      #0x2b7105c                                 fn_2b7105c
## .ctor() -> void
---- Home.LuckyWheelButton::.ctor 0x2d23d50
02d23d50: mov     x1, xzr                                    
02d23d54: b       #0x5b397b0                                 UnityEngine.MonoBehaviour::.ctor
