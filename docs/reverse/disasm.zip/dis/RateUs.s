#### CLASS RateUs/<>c__DisplayClass13_0 parent= object
#   field starIndex                      int                                                off=0x10 attr=6 
#   field <>4__this                      RateUs                                             off=0x18 attr=6 
## .ctor() -> void
---- RateUs/<>c__DisplayClass13_0::.ctor 0x2ce7040
02ce7040: mov     x1, xzr                                    
02ce7044: b       #0x4e53e9c                                 System.Object::.ctor
## <Start>b__1() -> void
---- RateUs/<>c__DisplayClass13_0::<Start>b__1 0x2ce77dc
02ce77dc: stp     x30, x19, [sp, #-0x10]!                    
02ce77e0: ldr     x19, [x0, #0x18]                           .<>4__this
02ce77e4: cbz     x19, #0x2ce780c                            
02ce77e8: ldr     w8, [x0, #0x10]                            .starIndex
02ce77ec: mov     x0, x19                                    
02ce77f0: str     w8, [x19, #0x80]                           
02ce77f4: bl      #0x2ce73f4                                 RateUs::I_Choose
02ce77f8: mov     x1, x0                                     
02ce77fc: mov     x0, x19                                    
02ce7800: mov     x2, xzr                                    
02ce7804: ldp     x30, x19, [sp], #0x10                      
02ce7808: b       #0x5b389f0                                 UnityEngine.MonoBehaviour::StartCoroutine
02ce780c: bl      #0x2b7105c                                 fn_2b7105c
#### CLASS RateUs/<>c__DisplayClass21_0 parent= object
#   field onClose                        System.Action                                      off=0x10 attr=6 
## .ctor() -> void
---- RateUs/<>c__DisplayClass21_0::.ctor 0x2ce7670
02ce7670: mov     x1, xzr                                    
02ce7674: b       #0x4e53e9c                                 System.Object::.ctor
## <ShowWithCloseEvent>b__0() -> void
---- RateUs/<>c__DisplayClass21_0::<ShowWithCloseEvent>b__0 0x2ce7810
02ce7810: ldr     x8, [x0, #0x10]                            .onClose
02ce7814: cbz     x8, #0x2ce7828                             
02ce7818: ldr     x0, [x8, #0x40]                            
02ce781c: ldr     x1, [x8, #0x28]                            
02ce7820: ldr     x2, [x8, #0x18]                            
02ce7824: br      x2                                         
02ce7828: ret                                                
#### CLASS RateUs/<I_Choose>d__18 parent= object
#   field <>1__state                     int                                                off=0x10 attr=1 
#   field <>2__current                   object                                             off=0x18 attr=1 
#   field <>4__this                      RateUs                                             off=0x20 attr=6 
#   field <i>5__2                        int                                                off=0x28 attr=1 
## .ctor(int <>1__state) -> void
---- RateUs/<I_Choose>d__18::.ctor 0x2ce7460
02ce7460: str     x30, [sp, #-0x20]!                         
02ce7464: stp     x20, x19, [sp, #0x10]                      
02ce7468: mov     w19, w1                                    
02ce746c: mov     x1, xzr                                    
02ce7470: mov     x20, x0                                    
02ce7474: bl      #0x4e53e9c                                 System.Object::.ctor
02ce7478: str     w19, [x20, #0x10]                          .<>1__state
02ce747c: ldp     x20, x19, [sp, #0x10]                      
02ce7480: ldr     x30, [sp], #0x20                           
02ce7484: ret                                                
## System.IDisposable.Dispose() -> void
---- RateUs/<I_Choose>d__18::System.IDisposable.Dispose 0x2ce782c
02ce782c: ret                                                
## MoveNext() -> bool
---- RateUs/<I_Choose>d__18::MoveNext 0x2ce7830
02ce7830: str     x30, [sp, #-0x20]!                         
02ce7834: stp     x20, x19, [sp, #0x10]                      
02ce7838: adrp    x20, #0x662f000                            
02ce783c: mov     x19, x0                                    
02ce7840: ldrb    w8, [x20, #0xdf4]                          
02ce7844: tbnz    w8, #0, #0x2ce785c                         
02ce7848: adrp    x0, #0x6264000                             
02ce784c: ldr     x0, [x0, #0xf58]                           T:UnityEngine.WaitForSeconds
02ce7850: bl      #0x2b70db0                                 fn_2b70db0
02ce7854: mov     w8, #1                                     
02ce7858: strb    w8, [x20, #0xdf4]                          
02ce785c: ldr     w9, [x19, #0x10]                           .<>1__state
02ce7860: ldr     x8, [x19, #0x20]                           .<>4__this
02ce7864: cmp     w9, #1                                     
02ce7868: b.eq    #0x2ce7880                                 
02ce786c: cbnz    w9, #0x2ce78e8                             
02ce7870: mov     w10, #-1                                   
02ce7874: str     wzr, [x19, #0x28]                          .<i>5__2
02ce7878: str     w10, [x19, #0x10]                          .<>1__state
02ce787c: b       #0x2ce7894                                 
02ce7880: ldr     w9, [x19, #0x28]                           .<i>5__2
02ce7884: mov     w10, #-1                                   
02ce7888: str     w10, [x19, #0x10]                          .<>1__state
02ce788c: add     w9, w9, #1                                 
02ce7890: str     w9, [x19, #0x28]                           .<i>5__2
02ce7894: cbz     x8, #0x2ce795c                             
02ce7898: ldr     x10, [x8, #0x40]                           
02ce789c: cbz     x10, #0x2ce795c                            
02ce78a0: ldr     w11, [x10, #0x18]                          
02ce78a4: cmp     w9, w11                                    
02ce78a8: b.ge    #0x2ce78d4                                 
02ce78ac: ldr     w12, [x8, #0x80]                           
02ce78b0: cmp     w9, w12                                    
02ce78b4: b.le    #0x2ce78f0                                 
02ce78b8: cmp     w9, w11                                    
02ce78bc: b.hs    #0x2ce7960                                 
02ce78c0: add     x9, x10, w9, sxtw #3                       
02ce78c4: ldr     x0, [x9, #0x20]                            
02ce78c8: cbz     x0, #0x2ce795c                             
02ce78cc: add     x8, x8, #0x50                              
02ce78d0: b       #0x2ce7908                                 
02ce78d4: ldr     x0, [x8, #0x58]                            
02ce78d8: cbz     x0, #0x2ce795c                             
02ce78dc: mov     w1, #1                                     
02ce78e0: mov     x2, xzr                                    
02ce78e4: bl      #0x5e662d4                                 UnityEngine.UI.Selectable::set_interactable
02ce78e8: mov     w0, wzr                                    
02ce78ec: b       #0x2ce7950                                 
02ce78f0: cmp     w9, w11                                    
02ce78f4: b.hs    #0x2ce7960                                 
02ce78f8: add     x9, x10, w9, sxtw #3                       
02ce78fc: ldr     x0, [x9, #0x20]                            
02ce7900: cbz     x0, #0x2ce795c                             
02ce7904: add     x8, x8, #0x48                              
02ce7908: ldr     x1, [x8]                                   
02ce790c: mov     x2, xzr                                    
02ce7910: bl      #0x5c45aa0                                 UnityEngine.UI.Image::set_sprite
02ce7914: adrp    x8, #0x6264000                             
02ce7918: ldr     x8, [x8, #0xf58]                           T:UnityEngine.WaitForSeconds
02ce791c: ldr     x0, [x8]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02ce7920: bl      #0x2b7104c                                 fn_2b7104c
02ce7924: adrp    x8, #0x1084000                             
02ce7928: mov     x1, xzr                                    
02ce792c: mov     x20, x0                                    
02ce7930: ldr     s0, [x8, #0xeec]                           [1084eec]=457ff0003dcccccd f=0.1,4095
02ce7934: bl      #0x5b3e5e8                                 UnityEngine.WaitForSeconds::.ctor
02ce7938: str     x20, [x19, #0x18]!                         .<>2__current
02ce793c: mov     x0, x19                                    
02ce7940: mov     x1, x20                                    
02ce7944: bl      #0x2b70d54                                 fn_2b70d54
02ce7948: mov     w0, #1                                     
02ce794c: stur    w0, [x19, #-8]                             
02ce7950: ldp     x20, x19, [sp, #0x10]                      
02ce7954: ldr     x30, [sp], #0x20                           
02ce7958: ret                                                
02ce795c: bl      #0x2b7105c                                 fn_2b7105c
02ce7960: bl      #0x2b71064                                 fn_2b71064
## System.Collections.Generic.IEnumerator<System.Object>.get_Current() -> object
---- RateUs/<I_Choose>d__18::System.Collections.Generic.IEnumerator<System.Object>.get_Current 0x2ce7964
02ce7964: ldr     x0, [x0, #0x18]                            .<>2__current
02ce7968: ret                                                
## System.Collections.IEnumerator.Reset() -> void
---- RateUs/<I_Choose>d__18::System.Collections.IEnumerator.Reset 0x2ce796c
02ce796c: stp     x30, x19, [sp, #-0x10]!                    
02ce7970: adrp    x0, #0x6264000                             
02ce7974: ldr     x0, [x0, #0xf60]                           T:System.NotSupportedException
02ce7978: bl      #0x2b70dc4                                 fn_2b70dc4
02ce797c: bl      #0x2b7104c                                 fn_2b7104c
02ce7980: mov     x1, xzr                                    
02ce7984: mov     x19, x0                                    
02ce7988: bl      #0x4e14238                                 System.NotSupportedException::.ctor
02ce798c: adrp    x0, #0x6268000                             
02ce7990: ldr     x0, [x0, #0x270]                           M:RateUs/<I_Choose>d__18::System.Collections.IEnumerator.Reset
02ce7994: bl      #0x2b70dc4                                 fn_2b70dc4
02ce7998: mov     x1, x0                                     
02ce799c: mov     x0, x19                                    
02ce79a0: bl      #0x2b70f20                                 fn_2b70f20
## System.Collections.IEnumerator.get_Current() -> object
---- RateUs/<I_Choose>d__18::System.Collections.IEnumerator.get_Current 0x2ce79a4
02ce79a4: ldr     x0, [x0, #0x18]                            .<>2__current
02ce79a8: ret                                                
#### CLASS RateUs/<I_Rate>d__20 parent= object
#   field <>1__state                     int                                                off=0x10 attr=1 
#   field <>2__current                   object                                             off=0x18 attr=1 
#   field rateCount                      int                                                off=0x20 attr=6 
#   field <>4__this                      RateUs                                             off=0x28 attr=6 
## .ctor(int <>1__state) -> void
---- RateUs/<I_Rate>d__20::.ctor 0x2ce7528
02ce7528: str     x30, [sp, #-0x20]!                         
02ce752c: stp     x20, x19, [sp, #0x10]                      
02ce7530: mov     w19, w1                                    
02ce7534: mov     x1, xzr                                    
02ce7538: mov     x20, x0                                    
02ce753c: bl      #0x4e53e9c                                 System.Object::.ctor
02ce7540: str     w19, [x20, #0x10]                          .<>1__state
02ce7544: ldp     x20, x19, [sp, #0x10]                      
02ce7548: ldr     x30, [sp], #0x20                           
02ce754c: ret                                                
## System.IDisposable.Dispose() -> void
---- RateUs/<I_Rate>d__20::System.IDisposable.Dispose 0x2ce79ac
02ce79ac: ret                                                
## MoveNext() -> bool
---- RateUs/<I_Rate>d__20::MoveNext 0x2ce79b0
02ce79b0: str     d8, [sp, #-0x20]!                          
02ce79b4: str     x30, [sp, #8]                              
02ce79b8: stp     x20, x19, [sp, #0x10]                      
02ce79bc: adrp    x20, #0x662f000                            
02ce79c0: mov     x19, x0                                    
02ce79c4: ldrb    w8, [x20, #0xdf5]                          
02ce79c8: tbnz    w8, #0, #0x2ce79e0                         
02ce79cc: adrp    x0, #0x6264000                             
02ce79d0: ldr     x0, [x0, #0xf58]                           T:UnityEngine.WaitForSeconds
02ce79d4: bl      #0x2b70db0                                 fn_2b70db0
02ce79d8: mov     w8, #1                                     
02ce79dc: strb    w8, [x20, #0xdf5]                          
02ce79e0: ldr     w8, [x19, #0x10]                           .<>1__state
02ce79e4: cmp     w8, #2                                     
02ce79e8: b.eq    #0x2ce7ab4                                 
02ce79ec: cmp     w8, #1                                     
02ce79f0: b.eq    #0x2ce7a68                                 
02ce79f4: cbnz    w8, #0x2ce7af4                             
02ce79f8: ldr     w8, [x19, #0x20]                           .rateCount
02ce79fc: adrp    x9, #0x1084000                             
02ce7a00: ldr     s1, [x9, #0xeec]                           [1084eec]=457ff0003dcccccd f=0.1,4095
02ce7a04: mov     w9, #-1                                    
02ce7a08: scvtf   s0, w8                                     
02ce7a0c: cmp     w8, #4                                     
02ce7a10: str     w9, [x19, #0x10]                           .<>1__state
02ce7a14: fmul    s0, s0, s1                                 
02ce7a18: fmov    s1, #0.50000000                            
02ce7a1c: fadd    s8, s0, s1                                 
02ce7a20: b.lt    #0x2ce7a2c                                 
02ce7a24: mov     x0, xzr                                    
02ce7a28: bl      #0x2ca38bc                                 RateApp::CallRateApp
02ce7a2c: adrp    x8, #0x6264000                             
02ce7a30: ldr     x8, [x8, #0xf58]                           T:UnityEngine.WaitForSeconds
02ce7a34: ldr     x0, [x8]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02ce7a38: bl      #0x2b7104c                                 fn_2b7104c
02ce7a3c: fmov    s0, s8                                     
02ce7a40: mov     x1, xzr                                    
02ce7a44: mov     x20, x0                                    
02ce7a48: bl      #0x5b3e5e8                                 UnityEngine.WaitForSeconds::.ctor
02ce7a4c: str     x20, [x19, #0x18]!                         .<>2__current
02ce7a50: mov     x0, x19                                    
02ce7a54: mov     x1, x20                                    
02ce7a58: bl      #0x2b70d54                                 fn_2b70d54
02ce7a5c: mov     w0, #1                                     
02ce7a60: stur    w0, [x19, #-8]                             
02ce7a64: b       #0x2ce7af8                                 
02ce7a68: adrp    x8, #0x6264000                             
02ce7a6c: mov     w9, #-1                                    
02ce7a70: ldr     x8, [x8, #0xf58]                           T:UnityEngine.WaitForSeconds
02ce7a74: str     w9, [x19, #0x10]                           .<>1__state
02ce7a78: ldr     x0, [x8]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02ce7a7c: bl      #0x2b7104c                                 fn_2b7104c
02ce7a80: adrp    x8, #0x1084000                             
02ce7a84: mov     x1, xzr                                    
02ce7a88: mov     x20, x0                                    
02ce7a8c: ldr     s0, [x8, #0xda4]                           [1084da4]=3eb851ec3e19999a f=0.15,0.36
02ce7a90: bl      #0x5b3e5e8                                 UnityEngine.WaitForSeconds::.ctor
02ce7a94: mov     x0, x19                                    
02ce7a98: mov     x1, x20                                    
02ce7a9c: str     x20, [x0, #0x18]!                          .<>2__current
02ce7aa0: bl      #0x2b70d54                                 fn_2b70d54
02ce7aa4: mov     w8, #2                                     
02ce7aa8: mov     w0, #1                                     
02ce7aac: str     w8, [x19, #0x10]                           .<>1__state
02ce7ab0: b       #0x2ce7af8                                 
02ce7ab4: ldr     x20, [x19, #0x28]                          .<>4__this
02ce7ab8: mov     w8, #-1                                    
02ce7abc: str     w8, [x19, #0x10]                           .<>1__state
02ce7ac0: cbz     x20, #0x2ce7b08                            
02ce7ac4: ldr     x8, [x20]                                  &2b706c4(=eb01011ff9400808)
02ce7ac8: mov     x0, x20                                    
02ce7acc: ldp     x9, x1, [x8, #0x198]                       
02ce7ad0: blr     x9                                         
02ce7ad4: ldr     x0, [x20, #0x88]                           [662f088]=600001b f=2.40742e-35,0
02ce7ad8: cbz     x0, #0x2ce7af8                             
02ce7adc: mov     x1, xzr                                    
02ce7ae0: bl      #0x5b4d278                                 UnityEngine.Events.UnityEvent::Invoke
02ce7ae4: ldr     x0, [x20, #0x88]                           [662f088]=600001b f=2.40742e-35,0
02ce7ae8: cbz     x0, #0x2ce7b08                             
02ce7aec: mov     x1, xzr                                    
02ce7af0: bl      #0x5b4ce48                                 UnityEngine.Events.UnityEventBase::RemoveAllListeners
02ce7af4: mov     w0, wzr                                    
02ce7af8: ldp     x20, x19, [sp, #0x10]                      
02ce7afc: ldr     x30, [sp, #8]                              
02ce7b00: ldr     d8, [sp], #0x20                            
02ce7b04: ret                                                
02ce7b08: bl      #0x2b7105c                                 fn_2b7105c
## System.Collections.Generic.IEnumerator<System.Object>.get_Current() -> object
---- RateUs/<I_Rate>d__20::System.Collections.Generic.IEnumerator<System.Object>.get_Current 0x2ce7b0c
02ce7b0c: ldr     x0, [x0, #0x18]                            .<>2__current
02ce7b10: ret                                                
## System.Collections.IEnumerator.Reset() -> void
---- RateUs/<I_Rate>d__20::System.Collections.IEnumerator.Reset 0x2ce7b14
02ce7b14: stp     x30, x19, [sp, #-0x10]!                    
02ce7b18: adrp    x0, #0x6264000                             
02ce7b1c: ldr     x0, [x0, #0xf60]                           T:System.NotSupportedException
02ce7b20: bl      #0x2b70dc4                                 fn_2b70dc4
02ce7b24: bl      #0x2b7104c                                 fn_2b7104c
02ce7b28: mov     x1, xzr                                    
02ce7b2c: mov     x19, x0                                    
02ce7b30: bl      #0x4e14238                                 System.NotSupportedException::.ctor
02ce7b34: adrp    x0, #0x6268000                             
02ce7b38: ldr     x0, [x0, #0x278]                           M:RateUs/<I_Rate>d__20::System.Collections.IEnumerator.Reset
02ce7b3c: bl      #0x2b70dc4                                 fn_2b70dc4
02ce7b40: mov     x1, x0                                     
02ce7b44: mov     x0, x19                                    
02ce7b48: bl      #0x2b70f20                                 fn_2b70f20
## System.Collections.IEnumerator.get_Current() -> object
---- RateUs/<I_Rate>d__20::System.Collections.IEnumerator.get_Current 0x2ce7b4c
02ce7b4c: ldr     x0, [x0, #0x18]                            .<>2__current
02ce7b50: ret                                                
#### CLASS RateUs parent= PopupBase
#   field btnArray                       UnityEngine.UI.Button[]                            off=0x38 attr=1 SerializeField
#   field imgArray                       UnityEngine.UI.Image[]                             off=0x40 attr=1 SerializeField
#   field goldStar                       UnityEngine.Sprite                                 off=0x48 attr=1 SerializeField
#   field silverStar                     UnityEngine.Sprite                                 off=0x50 attr=1 SerializeField
#   field btnRate                        UnityEngine.UI.Button                              off=0x58 attr=6 
#   field btnClose                       UnityEngine.UI.Button                              off=0x60 attr=6 
#   field _panel                         UnityEngine.RectTransform                          off=0x68 attr=1 SerializeField
#   field androidId                      string                                             off=0x70 attr=1 SerializeField
#   field iosId                          string                                             off=0x78 attr=1 SerializeField
#   field rateCount                      int                                                off=0x80 attr=1 
#   field OnCloseAction                  UnityEngine.Events.UnityEvent                      off=0x88 attr=6 
## get_LevelShowRate() -> int
---- RateUs::get_LevelShowRate 0x2ce6de8
02ce6de8: str     x30, [sp, #-0x20]!                         
02ce6dec: stp     x20, x19, [sp, #0x10]                      
02ce6df0: adrp    x20, #0x662f000                            
02ce6df4: adrp    x19, #0x6264000                            
02ce6df8: ldrb    w8, [x20, #0xdeb]                          
02ce6dfc: ldr     x19, [x19, #0xfc0]                         T:RemoteConfigManager
02ce6e00: tbnz    w8, #0, #0x2ce6e18                         
02ce6e04: adrp    x0, #0x6264000                             
02ce6e08: ldr     x0, [x0, #0xfc0]                           T:RemoteConfigManager
02ce6e0c: bl      #0x2b70db0                                 fn_2b70db0
02ce6e10: mov     w8, #1                                     
02ce6e14: strb    w8, [x20, #0xdeb]                          
02ce6e18: ldr     x0, [x19]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02ce6e1c: ldr     w8, [x0, #0xe4]                            [62640e4]=0 f=0,0
02ce6e20: cbnz    w8, #0x2ce6e28                             
02ce6e24: bl      #0x2b70f30                                 fn_2b70f30
02ce6e28: adrp    x20, #0x662f000                            
02ce6e2c: ldrb    w8, [x20, #0xbc0]                          
02ce6e30: cbnz    w8, #0x2ce6e48                             
02ce6e34: adrp    x0, #0x6264000                             
02ce6e38: ldr     x0, [x0, #0xfc0]                           T:RemoteConfigManager
02ce6e3c: bl      #0x2b70db0                                 fn_2b70db0
02ce6e40: mov     w8, #1                                     
02ce6e44: strb    w8, [x20, #0xbc0]                          
02ce6e48: ldr     x0, [x19]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02ce6e4c: ldr     w8, [x0, #0xe4]                            [62640e4]=0 f=0,0
02ce6e50: cbnz    w8, #0x2ce6e5c                             
02ce6e54: bl      #0x2b70f30                                 fn_2b70f30
02ce6e58: ldr     x0, [x19]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02ce6e5c: ldr     x8, [x0, #0xb8]                            MS:DG.Tweening.Core.Extensions::SetSpecialStartupMode
02ce6e60: ldp     x20, x19, [sp, #0x10]                      
02ce6e64: ldr     w0, [x8, #0xc]                             
02ce6e68: ldr     x30, [sp], #0x20                           
02ce6e6c: ret                                                
## Start() -> void
---- RateUs::Start 0x2ce6e70
02ce6e70: str     x30, [sp, #-0x60]!                         
02ce6e74: stp     x28, x27, [sp, #0x10]                      
02ce6e78: stp     x26, x25, [sp, #0x20]                      
02ce6e7c: stp     x24, x23, [sp, #0x30]                      
02ce6e80: stp     x22, x21, [sp, #0x40]                      
02ce6e84: stp     x20, x19, [sp, #0x50]                      
02ce6e88: adrp    x20, #0x662f000                            
02ce6e8c: mov     x19, x0                                    
02ce6e90: ldrb    w8, [x20, #0xdec]                          
02ce6e94: tbnz    w8, #0, #0x2ce6edc                         
02ce6e98: adrp    x0, #0x6264000                             
02ce6e9c: ldr     x0, [x0, #0xa70]                           T:UnityEngine.Application
02ce6ea0: bl      #0x2b70db0                                 fn_2b70db0
02ce6ea4: adrp    x0, #0x6268000                             
02ce6ea8: ldr     x0, [x0, #0x220]                           M:RateUs::<Start>b__13_0
02ce6eac: bl      #0x2b70db0                                 fn_2b70db0
02ce6eb0: adrp    x0, #0x6268000                             
02ce6eb4: ldr     x0, [x0, #0x228]                           M:RateUs/<>c__DisplayClass13_0::<Start>b__1
02ce6eb8: bl      #0x2b70db0                                 fn_2b70db0
02ce6ebc: adrp    x0, #0x6268000                             
02ce6ec0: ldr     x0, [x0, #0x230]                           T:RateUs/<>c__DisplayClass13_0
02ce6ec4: bl      #0x2b70db0                                 fn_2b70db0
02ce6ec8: adrp    x0, #0x6265000                             
02ce6ecc: ldr     x0, [x0, #0x3f0]                           T:UnityEngine.Events.UnityAction
02ce6ed0: bl      #0x2b70db0                                 fn_2b70db0
02ce6ed4: mov     w8, #1                                     
02ce6ed8: strb    w8, [x20, #0xdec]                          
02ce6edc: ldr     x8, [x19, #0x38]                           .btnArray
02ce6ee0: cbz     x8, #0x2ce6fac                             
02ce6ee4: adrp    x26, #0x6268000                            
02ce6ee8: adrp    x25, #0x6265000                            
02ce6eec: adrp    x27, #0x6268000                            
02ce6ef0: adrp    x24, #0x6268000                            
02ce6ef4: adrp    x23, #0x6264000                            
02ce6ef8: ldr     x26, [x26, #0x230]                         T:RateUs/<>c__DisplayClass13_0
02ce6efc: ldr     x25, [x25, #0x3f0]                         T:UnityEngine.Events.UnityAction
02ce6f00: ldr     x27, [x27, #0x228]                         M:RateUs/<>c__DisplayClass13_0::<Start>b__1
02ce6f04: ldr     x24, [x24, #0x220]                         M:RateUs::<Start>b__13_0
02ce6f08: ldr     x23, [x23, #0xa70]                         T:UnityEngine.Application
02ce6f0c: mov     x28, xzr                                   
02ce6f10: ldr     w8, [x8, #0x18]                            
02ce6f14: cmp     w28, w8                                    
02ce6f18: b.ge    #0x2ce6fb0                                 
02ce6f1c: ldr     x0, [x26]                                  S:'{0}/2'
02ce6f20: bl      #0x2b7104c                                 fn_2b7104c
02ce6f24: mov     x1, xzr                                    
02ce6f28: mov     x20, x0                                    
02ce6f2c: bl      #0x4e53e9c                                 System.Object::.ctor
02ce6f30: cbz     x20, #0x2ce6fac                            
02ce6f34: mov     x21, x20                                   
02ce6f38: mov     x1, x19                                    
02ce6f3c: str     x19, [x21, #0x18]!                         
02ce6f40: mov     x0, x21                                    
02ce6f44: bl      #0x2b70d54                                 fn_2b70d54
02ce6f48: ldr     x8, [x19, #0x38]                           .btnArray
02ce6f4c: stur    w28, [x21, #-8]                            
02ce6f50: cbz     x8, #0x2ce6fac                             
02ce6f54: ldr     w9, [x8, #0x18]                            
02ce6f58: cmp     w28, w9                                    
02ce6f5c: b.hs    #0x2ce703c                                 
02ce6f60: add     x8, x8, x28, lsl #3                        
02ce6f64: ldr     x8, [x8, #0x20]                            
02ce6f68: cbz     x8, #0x2ce6fac                             
02ce6f6c: ldr     x0, [x25]                                  M:AdsManager::<OnApplicationPause>b__26_0
02ce6f70: ldr     x21, [x8, #0x100]                          
02ce6f74: bl      #0x2b7104c                                 fn_2b7104c
02ce6f78: ldr     x2, [x27]                                  S:'{0}/2'
02ce6f7c: mov     x1, x20                                    
02ce6f80: mov     x3, xzr                                    
02ce6f84: mov     x22, x0                                    
02ce6f88: bl      #0x5b4cf98                                 UnityEngine.Events.UnityAction::.ctor
02ce6f8c: cbz     x21, #0x2ce6fac                            
02ce6f90: mov     x0, x21                                    
02ce6f94: mov     x1, x22                                    
02ce6f98: mov     x2, xzr                                    
02ce6f9c: bl      #0x5b4d0ac                                 UnityEngine.Events.UnityEvent::AddListener
02ce6fa0: ldr     x8, [x19, #0x38]                           .btnArray
02ce6fa4: add     x28, x28, #1                               
02ce6fa8: cbnz    x8, #0x2ce6f10                             
02ce6fac: bl      #0x2b7105c                                 fn_2b7105c
02ce6fb0: ldr     x8, [x19, #0x58]                           .btnRate
02ce6fb4: cbz     x8, #0x2ce6fac                             
02ce6fb8: ldr     x0, [x25]                                  M:AdsManager::<OnApplicationPause>b__26_0
02ce6fbc: ldr     x20, [x8, #0x100]                          
02ce6fc0: bl      #0x2b7104c                                 fn_2b7104c
02ce6fc4: ldr     x2, [x24]                                  S:'{0}/2'
02ce6fc8: mov     x1, x19                                    
02ce6fcc: mov     x3, xzr                                    
02ce6fd0: mov     x21, x0                                    
02ce6fd4: bl      #0x5b4cf98                                 UnityEngine.Events.UnityAction::.ctor
02ce6fd8: cbz     x20, #0x2ce6fac                            
02ce6fdc: mov     x0, x20                                    
02ce6fe0: mov     x1, x21                                    
02ce6fe4: mov     x2, xzr                                    
02ce6fe8: bl      #0x5b4d0ac                                 UnityEngine.Events.UnityEvent::AddListener
02ce6fec: ldr     x0, [x23]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02ce6ff0: ldr     w8, [x0, #0xe4]                            [62650e4]=0 f=0,0
02ce6ff4: cbnz    w8, #0x2ce6ffc                             
02ce6ff8: bl      #0x2b70f30                                 fn_2b70f30
02ce6ffc: mov     x0, xzr                                    
02ce7000: bl      #0x5aeac78                                 UnityEngine.Application::get_identifier
02ce7004: mov     x1, x0                                     
02ce7008: mov     x0, x19                                    
02ce700c: str     x1, [x0, #0x70]!                           .androidId
02ce7010: bl      #0x2b70d54                                 fn_2b70d54
02ce7014: ldr     x8, [x19]                                  
02ce7018: mov     x0, x19                                    
02ce701c: ldp     x20, x19, [sp, #0x50]                      
02ce7020: ldp     x2, x1, [x8, #0x198]                       
02ce7024: ldp     x22, x21, [sp, #0x40]                      
02ce7028: ldp     x24, x23, [sp, #0x30]                      
02ce702c: ldp     x26, x25, [sp, #0x20]                      
02ce7030: ldp     x28, x27, [sp, #0x10]                      
02ce7034: ldr     x30, [sp], #0x60                           
02ce7038: br      x2                                         
02ce703c: bl      #0x2b71064                                 fn_2b71064
## OnInit(UIManager uiManager) -> void
---- RateUs::OnInit 0x2ce7048
02ce7048: b       #0x2cdd3c4                                 UIBase::OnInit
## OnShow() -> void
---- RateUs::OnShow 0x2ce704c
02ce704c: str     d8, [sp, #-0x30]!                          
02ce7050: str     x30, [sp, #8]                              
02ce7054: stp     x22, x21, [sp, #0x10]                      
02ce7058: stp     x20, x19, [sp, #0x20]                      
02ce705c: adrp    x21, #0x662f000                            
02ce7060: adrp    x20, #0x6264000                            
02ce7064: mov     x19, x0                                    
02ce7068: ldrb    w8, [x21, #0xded]                          
02ce706c: ldr     x20, [x20, #0xfc0]                         T:RemoteConfigManager
02ce7070: tbnz    w8, #0, #0x2ce70ac                         
02ce7074: adrp    x0, #0x6266000                             
02ce7078: ldr     x0, [x0, #0x750]                           MS:DataManager::GetData
02ce707c: bl      #0x2b70db0                                 fn_2b70db0
02ce7080: adrp    x0, #0x6266000                             
02ce7084: ldr     x0, [x0, #0x658]                           MS:MonoSingleton`1::get_Instance
02ce7088: bl      #0x2b70db0                                 fn_2b70db0
02ce708c: adrp    x0, #0x6264000                             
02ce7090: ldr     x0, [x0, #0xfc0]                           T:RemoteConfigManager
02ce7094: bl      #0x2b70db0                                 fn_2b70db0
02ce7098: adrp    x0, #0x6267000                             
02ce709c: ldr     x0, [x0, #0xd38]                           MS:DG.Tweening.TweenSettingsExtensions::SetEase
02ce70a0: bl      #0x2b70db0                                 fn_2b70db0
02ce70a4: mov     w8, #1                                     
02ce70a8: strb    w8, [x21, #0xded]                          
02ce70ac: ldr     x0, [x20]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02ce70b0: ldr     w8, [x0, #0xe4]                            [62670e4]=0 f=0,0
02ce70b4: cbnz    w8, #0x2ce70bc                             
02ce70b8: bl      #0x2b70f30                                 fn_2b70f30
02ce70bc: adrp    x21, #0x662f000                            
02ce70c0: ldrb    w8, [x21, #0xbc2]                          
02ce70c4: cbnz    w8, #0x2ce70dc                             
02ce70c8: adrp    x0, #0x6264000                             
02ce70cc: ldr     x0, [x0, #0xfc0]                           T:RemoteConfigManager
02ce70d0: bl      #0x2b70db0                                 fn_2b70db0
02ce70d4: mov     w8, #1                                     
02ce70d8: strb    w8, [x21, #0xbc2]                          
02ce70dc: ldr     x0, [x20]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02ce70e0: ldr     w8, [x0, #0xe4]                            [62640e4]=0 f=0,0
02ce70e4: cbnz    w8, #0x2ce70f0                             
02ce70e8: bl      #0x2b70f30                                 fn_2b70f30
02ce70ec: ldr     x0, [x20]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02ce70f0: ldr     x8, [x0, #0xb8]                            MS:DG.Tweening.Core.Extensions::SetSpecialStartupMode
02ce70f4: ldrb    w8, [x8, #0x15]                            
02ce70f8: cbz     w8, #0x2ce714c                             
02ce70fc: adrp    x8, #0x6266000                             
02ce7100: ldr     x8, [x8, #0x658]                           MS:MonoSingleton`1::get_Instance
02ce7104: ldr     x0, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ce7108: bl      #0x3769600                                 fn_3769600
02ce710c: cbz     x0, #0x2ce7274                             
02ce7110: adrp    x8, #0x6266000                             
02ce7114: ldr     x8, [x8, #0x750]                           MS:DataManager::GetData
02ce7118: ldr     x1, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ce711c: bl      #0x3168dd0                                 fn_3168dd0
02ce7120: cbz     x0, #0x2ce7274                             
02ce7124: mov     x1, xzr                                    
02ce7128: mov     x20, x0                                    
02ce712c: bl      #0x2caba38                                 DataUser::HasRateUs
02ce7130: tbnz    w0, #0, #0x2ce714c                         
02ce7134: ldr     x8, [x20, #0x20]                           T:DG.Tweening.DOTweenModulePhysics/<>c__DisplayClass0_0
02ce7138: cbz     x8, #0x2ce7274                             
02ce713c: ldr     w21, [x8, #0x4c]                           [626604c]=0 f=0,0
02ce7140: bl      #0x2ce6de8                                 RateUs::get_LevelShowRate
02ce7144: cmp     w21, w0                                    
02ce7148: b.ge    #0x2ce7160                                 
02ce714c: ldp     x20, x19, [sp, #0x20]                      
02ce7150: ldr     x30, [sp, #8]                              
02ce7154: ldp     x22, x21, [sp, #0x10]                      
02ce7158: ldr     d8, [sp], #0x30                            
02ce715c: ret                                                
02ce7160: mov     x0, x20                                    
02ce7164: mov     w1, #1                                     
02ce7168: mov     x2, xzr                                    
02ce716c: mov     w21, #1                                    
02ce7170: bl      #0x2caba50                                 DataUser::SetRateUs
02ce7174: movi    d0, #0000000000000000                      
02ce7178: ldr     x0, [x19, #0x28]                           
02ce717c: mov     w1, #1                                     
02ce7180: mov     x2, xzr                                    
02ce7184: bl      #0x2cf1928                                 FrameWorkUtility::SetActive
02ce7188: ldr     x0, [x19, #0x68]                           ._panel
02ce718c: mov     w1, wzr                                    
02ce7190: mov     x2, xzr                                    
02ce7194: strb    w21, [x19, #0x20]                          
02ce7198: bl      #0x2d9d5d0                                 DG.Tweening.ShortcutExtensions::DOKill
02ce719c: adrp    x8, #0x1084000                             
02ce71a0: adrp    x9, #0x1084000                             
02ce71a4: fmov    s4, #1.00000000                            
02ce71a8: ldr     s0, [x8, #0xeec]                           [1084eec]=457ff0003dcccccd f=0.1,4095
02ce71ac: ldr     s8, [x9, #0xda8]                           [1084da8]=da242603eb851ec f=0.36,1e-30
02ce71b0: ldr     x0, [x19, #0x68]                           ._panel
02ce71b4: mov     w1, #0xa                                   
02ce71b8: mov     x2, xzr                                    
02ce71bc: fmov    s1, s0                                     
02ce71c0: fmov    s2, s0                                     
02ce71c4: fmov    s3, s8                                     
02ce71c8: bl      #0x2d9982c                                 DG.Tweening.ShortcutExtensions::DOPunchScale
02ce71cc: adrp    x22, #0x662f000                            
02ce71d0: ldr     x20, [x19, #0x68]                          ._panel
02ce71d4: ldrb    w8, [x22, #0x91a]                          
02ce71d8: cbnz    w8, #0x2ce71ec                             
02ce71dc: adrp    x0, #0x6264000                             
02ce71e0: ldr     x0, [x0, #0xd8]                            T:UnityEngine.Vector3
02ce71e4: bl      #0x2b70db0                                 fn_2b70db0
02ce71e8: strb    w21, [x22, #0x91a]                         
02ce71ec: adrp    x8, #0x6264000                             
02ce71f0: fmov    s3, s8                                     
02ce71f4: mov     x0, x20                                    
02ce71f8: ldr     x8, [x8, #0xd8]                            T:UnityEngine.Vector3
02ce71fc: mov     w1, wzr                                    
02ce7200: mov     x2, xzr                                    
02ce7204: ldr     x8, [x8]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02ce7208: ldr     x8, [x8, #0xb8]                            MS:DG.Tweening.Core.Extensions::SetSpecialStartupMode
02ce720c: ldp     s0, s1, [x8]                               
02ce7210: ldr     s2, [x8, #8]                               T:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass2_0
02ce7214: bl      #0x2d98760                                 DG.Tweening.ShortcutExtensions::DOLocalRotate
02ce7218: adrp    x8, #0x6267000                             
02ce721c: mov     w1, #0x1b                                  
02ce7220: ldr     x8, [x8, #0xd38]                           MS:DG.Tweening.TweenSettingsExtensions::SetEase
02ce7224: ldr     x2, [x8]                                   S:'didu'
02ce7228: bl      #0x336fa0c                                 fn_336fa0c
02ce722c: ldr     x8, [x19, #0x40]                           .imgArray
02ce7230: str     wzr, [x19, #0x80]                          .rateCount
02ce7234: cbz     x8, #0x2ce7274                             
02ce7238: mov     x20, xzr                                   
02ce723c: ldr     w9, [x8, #0x18]                            S:'android.content.Intent'
02ce7240: cmp     w20, w9                                    
02ce7244: b.ge    #0x2ce7278                                 
02ce7248: cmp     w20, w9                                    
02ce724c: b.hs    #0x2ce729c                                 
02ce7250: add     x8, x8, x20, lsl #3                        &6267000
02ce7254: ldr     x0, [x8, #0x20]                            T:System.IO.FileInfo
02ce7258: cbz     x0, #0x2ce7274                             
02ce725c: ldr     x1, [x19, #0x50]                           .silverStar
02ce7260: mov     x2, xzr                                    
02ce7264: bl      #0x5c45aa0                                 UnityEngine.UI.Image::set_sprite
02ce7268: ldr     x8, [x19, #0x40]                           .imgArray
02ce726c: add     x20, x20, #1                               &6264001
02ce7270: cbnz    x8, #0x2ce723c                             
02ce7274: bl      #0x2b7105c                                 fn_2b7105c
02ce7278: ldr     x0, [x19, #0x58]                           .btnRate
02ce727c: cbz     x0, #0x2ce7274                             
02ce7280: ldp     x20, x19, [sp, #0x20]                      
02ce7284: mov     w1, wzr                                    
02ce7288: ldp     x22, x21, [sp, #0x10]                      
02ce728c: mov     x2, xzr                                    
02ce7290: ldr     x30, [sp, #8]                              
02ce7294: ldr     d8, [sp], #0x30                            
02ce7298: b       #0x5e662d4                                 UnityEngine.UI.Selectable::set_interactable
02ce729c: bl      #0x2b71064                                 fn_2b71064
## OnHide() -> void
---- RateUs::OnHide 0x2ce72a0
02ce72a0: str     d8, [sp, #-0x40]!                          
02ce72a4: str     x30, [sp, #8]                              
02ce72a8: stp     x24, x23, [sp, #0x10]                      
02ce72ac: stp     x22, x21, [sp, #0x20]                      
02ce72b0: stp     x20, x19, [sp, #0x30]                      
02ce72b4: adrp    x23, #0x6267000                            
02ce72b8: adrp    x24, #0x662f000                            
02ce72bc: adrp    x20, #0x6264000                            
02ce72c0: adrp    x21, #0x6268000                            
02ce72c4: adrp    x22, #0x6267000                            
02ce72c8: ldr     x23, [x23, #0xd38]                         MS:DG.Tweening.TweenSettingsExtensions::SetEase
02ce72cc: ldr     x20, [x20, #0xe8]                          T:DG.Tweening.TweenCallback
02ce72d0: ldrb    w8, [x24, #0xdee]                          
02ce72d4: ldr     x21, [x21, #0x238]                         M:RateUs::<OnHide>b__16_0
02ce72d8: ldr     x22, [x22, #0xd30]                         MS:DG.Tweening.TweenSettingsExtensions::OnComplete
02ce72dc: mov     x19, x0                                    
02ce72e0: tbnz    w8, #0, #0x2ce731c                         
02ce72e4: adrp    x0, #0x6268000                             
02ce72e8: ldr     x0, [x0, #0x238]                           M:RateUs::<OnHide>b__16_0
02ce72ec: bl      #0x2b70db0                                 fn_2b70db0
02ce72f0: adrp    x0, #0x6264000                             
02ce72f4: ldr     x0, [x0, #0xe8]                            T:DG.Tweening.TweenCallback
02ce72f8: bl      #0x2b70db0                                 fn_2b70db0
02ce72fc: adrp    x0, #0x6267000                             
02ce7300: ldr     x0, [x0, #0xd30]                           MS:DG.Tweening.TweenSettingsExtensions::OnComplete
02ce7304: bl      #0x2b70db0                                 fn_2b70db0
02ce7308: adrp    x0, #0x6267000                             
02ce730c: ldr     x0, [x0, #0xd38]                           MS:DG.Tweening.TweenSettingsExtensions::SetEase
02ce7310: bl      #0x2b70db0                                 fn_2b70db0
02ce7314: mov     w8, #1                                     
02ce7318: strb    w8, [x24, #0xdee]                          
02ce731c: ldr     x0, [x19, #0x68]                           ._panel
02ce7320: mov     w1, wzr                                    
02ce7324: mov     x2, xzr                                    
02ce7328: bl      #0x2d9d5d0                                 DG.Tweening.ShortcutExtensions::DOKill
02ce732c: adrp    x8, #0x1084000                             
02ce7330: adrp    x9, #0x1084000                             
02ce7334: fmov    s4, #1.00000000                            
02ce7338: ldr     s0, [x8, #0xeec]                           [1084eec]=457ff0003dcccccd f=0.1,4095
02ce733c: ldr     s8, [x9, #0xda8]                           [1084da8]=da242603eb851ec f=0.36,1e-30
02ce7340: ldr     x0, [x19, #0x68]                           ._panel
02ce7344: mov     w1, #0xa                                   
02ce7348: mov     x2, xzr                                    
02ce734c: fmov    s1, s0                                     
02ce7350: fmov    s2, s0                                     
02ce7354: fmov    s3, s8                                     
02ce7358: bl      #0x2d9982c                                 DG.Tweening.ShortcutExtensions::DOPunchScale
02ce735c: movi    d0, #0000000000000000                      
02ce7360: movi    d1, #0000000000000000                      
02ce7364: ldr     x0, [x19, #0x68]                           ._panel
02ce7368: fmov    s3, s8                                     
02ce736c: fmov    s2, #10.00000000                           
02ce7370: mov     w1, wzr                                    
02ce7374: mov     x2, xzr                                    
02ce7378: bl      #0x2d98760                                 DG.Tweening.ShortcutExtensions::DOLocalRotate
02ce737c: ldr     x2, [x23]                                  S:'didu'
02ce7380: mov     w1, #0x1a                                  
02ce7384: bl      #0x336fa0c                                 fn_336fa0c
02ce7388: ldr     x8, [x20]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02ce738c: mov     x20, x0                                    
02ce7390: mov     x0, x8                                     
02ce7394: bl      #0x2b7104c                                 fn_2b7104c
02ce7398: ldr     x2, [x21]                                  S:'{0}/2'
02ce739c: mov     x1, x19                                    
02ce73a0: mov     x3, xzr                                    
02ce73a4: mov     x21, x0                                    
02ce73a8: bl      #0x2d89dc4                                 DG.Tweening.TweenCallback::.ctor
02ce73ac: ldr     x2, [x22]                                  S:'didu'
02ce73b0: mov     x0, x20                                    
02ce73b4: mov     x1, x21                                    
02ce73b8: ldp     x20, x19, [sp, #0x30]                      
02ce73bc: ldr     x30, [sp, #8]                              
02ce73c0: ldp     x22, x21, [sp, #0x20]                      
02ce73c4: ldp     x24, x23, [sp, #0x10]                      
02ce73c8: ldr     d8, [sp], #0x40                            
02ce73cc: b       #0x336f26c                                 
## OnChooseStar(int star) -> void
---- RateUs::OnChooseStar 0x2ce73d0
02ce73d0: stp     x30, x19, [sp, #-0x10]!                    
02ce73d4: mov     x19, x0                                    
02ce73d8: str     w1, [x0, #0x80]                            .rateCount
02ce73dc: bl      #0x2ce73f4                                 RateUs::I_Choose
02ce73e0: mov     x1, x0                                     
02ce73e4: mov     x0, x19                                    
02ce73e8: mov     x2, xzr                                    
02ce73ec: ldp     x30, x19, [sp], #0x10                      
02ce73f0: b       #0x5b389f0                                 UnityEngine.MonoBehaviour::StartCoroutine
## I_Choose() -> System.Collections.IEnumerator
---- RateUs::I_Choose 0x2ce73f4
02ce73f4: stp     x30, x21, [sp, #-0x20]!                    
02ce73f8: stp     x20, x19, [sp, #0x10]                      
02ce73fc: adrp    x20, #0x662f000                            
02ce7400: adrp    x21, #0x6268000                            
02ce7404: mov     x19, x0                                    
02ce7408: ldrb    w8, [x20, #0xdef]                          
02ce740c: ldr     x21, [x21, #0x240]                         T:RateUs/<I_Choose>d__18
02ce7410: tbnz    w8, #0, #0x2ce7428                         
02ce7414: adrp    x0, #0x6268000                             
02ce7418: ldr     x0, [x0, #0x240]                           T:RateUs/<I_Choose>d__18
02ce741c: bl      #0x2b70db0                                 fn_2b70db0
02ce7420: mov     w8, #1                                     
02ce7424: strb    w8, [x20, #0xdef]                          
02ce7428: ldr     x0, [x21]                                  S:'{0}/2'
02ce742c: bl      #0x2b7104c                                 fn_2b7104c
02ce7430: mov     x1, xzr                                    
02ce7434: mov     x20, x0                                    
02ce7438: bl      #0x4e53e9c                                 System.Object::.ctor
02ce743c: mov     x0, x20                                    
02ce7440: mov     x1, x19                                    
02ce7444: str     wzr, [x20, #0x10]                          
02ce7448: str     x19, [x0, #0x20]!                          
02ce744c: bl      #0x2b70d54                                 fn_2b70d54
02ce7450: mov     x0, x20                                    
02ce7454: ldp     x20, x19, [sp, #0x10]                      
02ce7458: ldp     x30, x21, [sp], #0x20                      
02ce745c: ret                                                
## RateForUs(int rateCount) -> void
---- RateUs::RateForUs 0x2ce7488
02ce7488: stp     x30, x19, [sp, #-0x10]!                    
02ce748c: mov     x19, x0                                    
02ce7490: str     w1, [x0, #0x80]                            .rateCount
02ce7494: bl      #0x2ce74ac                                 RateUs::I_Rate
02ce7498: mov     x1, x0                                     
02ce749c: mov     x0, x19                                    
02ce74a0: mov     x2, xzr                                    
02ce74a4: ldp     x30, x19, [sp], #0x10                      
02ce74a8: b       #0x5b389f0                                 UnityEngine.MonoBehaviour::StartCoroutine
## I_Rate(int rateCount) -> System.Collections.IEnumerator
---- RateUs::I_Rate 0x2ce74ac
02ce74ac: str     x30, [sp, #-0x30]!                         
02ce74b0: stp     x22, x21, [sp, #0x10]                      
02ce74b4: stp     x20, x19, [sp, #0x20]                      
02ce74b8: adrp    x21, #0x662f000                            
02ce74bc: adrp    x22, #0x6268000                            
02ce74c0: mov     w19, w1                                    
02ce74c4: ldrb    w8, [x21, #0xdf0]                          
02ce74c8: ldr     x22, [x22, #0x248]                         T:RateUs/<I_Rate>d__20
02ce74cc: mov     x20, x0                                    
02ce74d0: tbnz    w8, #0, #0x2ce74e8                         
02ce74d4: adrp    x0, #0x6268000                             
02ce74d8: ldr     x0, [x0, #0x248]                           T:RateUs/<I_Rate>d__20
02ce74dc: bl      #0x2b70db0                                 fn_2b70db0
02ce74e0: mov     w8, #1                                     
02ce74e4: strb    w8, [x21, #0xdf0]                          
02ce74e8: ldr     x0, [x22]                                  S:'{0}/2'
02ce74ec: bl      #0x2b7104c                                 fn_2b7104c
02ce74f0: mov     x1, xzr                                    
02ce74f4: mov     x21, x0                                    
02ce74f8: bl      #0x4e53e9c                                 System.Object::.ctor
02ce74fc: mov     x0, x21                                    
02ce7500: mov     x1, x20                                    
02ce7504: str     wzr, [x21, #0x10]                          
02ce7508: str     x20, [x0, #0x28]!                          
02ce750c: bl      #0x2b70d54                                 fn_2b70d54
02ce7510: mov     x0, x21                                    
02ce7514: str     w19, [x21, #0x20]                          
02ce7518: ldp     x20, x19, [sp, #0x20]                      
02ce751c: ldp     x22, x21, [sp, #0x10]                      
02ce7520: ldr     x30, [sp], #0x30                           
02ce7524: ret                                                
## ShowWithCloseEvent(System.Action onClose) -> void
---- RateUs::ShowWithCloseEvent 0x2ce7550
02ce7550: str     x30, [sp, #-0x30]!                         
02ce7554: stp     x22, x21, [sp, #0x10]                      
02ce7558: stp     x20, x19, [sp, #0x20]                      
02ce755c: adrp    x20, #0x662f000                            
02ce7560: adrp    x22, #0x6268000                            
02ce7564: mov     x21, x1                                    
02ce7568: ldrb    w8, [x20, #0xdf1]                          
02ce756c: ldr     x22, [x22, #0x250]                         T:RateUs/<>c__DisplayClass21_0
02ce7570: mov     x19, x0                                    
02ce7574: tbnz    w8, #0, #0x2ce75b0                         
02ce7578: adrp    x0, #0x6268000                             
02ce757c: ldr     x0, [x0, #0x258]                           M:RateUs/<>c__DisplayClass21_0::<ShowWithCloseEvent>b__0
02ce7580: bl      #0x2b70db0                                 fn_2b70db0
02ce7584: adrp    x0, #0x6268000                             
02ce7588: ldr     x0, [x0, #0x250]                           T:RateUs/<>c__DisplayClass21_0
02ce758c: bl      #0x2b70db0                                 fn_2b70db0
02ce7590: adrp    x0, #0x6265000                             
02ce7594: ldr     x0, [x0, #0x3f0]                           T:UnityEngine.Events.UnityAction
02ce7598: bl      #0x2b70db0                                 fn_2b70db0
02ce759c: adrp    x0, #0x6267000                             
02ce75a0: ldr     x0, [x0, #0xff0]                           T:UnityEngine.Events.UnityEvent
02ce75a4: bl      #0x2b70db0                                 fn_2b70db0
02ce75a8: mov     w8, #1                                     
02ce75ac: strb    w8, [x20, #0xdf1]                          
02ce75b0: ldr     x0, [x22]                                  S:'{0}/2'
02ce75b4: bl      #0x2b7104c                                 fn_2b7104c
02ce75b8: mov     x1, xzr                                    
02ce75bc: mov     x20, x0                                    
02ce75c0: bl      #0x4e53e9c                                 System.Object::.ctor
02ce75c4: cbz     x20, #0x2ce766c                            
02ce75c8: mov     x0, x20                                    
02ce75cc: mov     x1, x21                                    
02ce75d0: str     x21, [x0, #0x10]!                          
02ce75d4: bl      #0x2b70d54                                 fn_2b70d54
02ce75d8: ldr     x0, [x19, #0x88]!                          .OnCloseAction
02ce75dc: cbnz    x0, #0x2ce7614                             
02ce75e0: adrp    x8, #0x6267000                             
02ce75e4: ldr     x8, [x8, #0xff0]                           T:UnityEngine.Events.UnityEvent
02ce75e8: ldr     x0, [x8]                                   S:'didu'
02ce75ec: bl      #0x2b7104c                                 fn_2b7104c
02ce75f0: mov     x1, xzr                                    
02ce75f4: mov     x21, x0                                    
02ce75f8: bl      #0x5b4d048                                 UnityEngine.Events.UnityEvent::.ctor
02ce75fc: mov     x0, x19                                    
02ce7600: mov     x1, x21                                    
02ce7604: str     x21, [x19]                                 
02ce7608: bl      #0x2b70d54                                 fn_2b70d54
02ce760c: ldr     x0, [x19]                                  
02ce7610: cbz     x0, #0x2ce766c                             
02ce7614: adrp    x21, #0x6265000                            
02ce7618: adrp    x22, #0x6268000                            
02ce761c: mov     x1, xzr                                    
02ce7620: ldr     x21, [x21, #0x3f0]                         T:UnityEngine.Events.UnityAction
02ce7624: ldr     x22, [x22, #0x258]                         M:RateUs/<>c__DisplayClass21_0::<ShowWithCloseEvent>b__0
02ce7628: bl      #0x5b4ce48                                 UnityEngine.Events.UnityEventBase::RemoveAllListeners
02ce762c: ldr     x0, [x21]                                  M:AdsManager::<OnApplicationPause>b__26_0
02ce7630: ldr     x19, [x19]                                 
02ce7634: bl      #0x2b7104c                                 fn_2b7104c
02ce7638: ldr     x2, [x22]                                  S:'{0}/2'
02ce763c: mov     x1, x20                                    
02ce7640: mov     x3, xzr                                    
02ce7644: mov     x21, x0                                    
02ce7648: bl      #0x5b4cf98                                 UnityEngine.Events.UnityAction::.ctor
02ce764c: cbz     x19, #0x2ce766c                            
02ce7650: mov     x0, x19                                    
02ce7654: mov     x1, x21                                    
02ce7658: mov     x2, xzr                                    
02ce765c: ldp     x20, x19, [sp, #0x20]                      
02ce7660: ldp     x22, x21, [sp, #0x10]                      
02ce7664: ldr     x30, [sp], #0x30                           
02ce7668: b       #0x5b4d0ac                                 UnityEngine.Events.UnityEvent::AddListener
02ce766c: bl      #0x2b7105c                                 fn_2b7105c
## .ctor() -> void
---- RateUs::.ctor 0x2ce7678
02ce7678: str     x30, [sp, #-0x30]!                         
02ce767c: stp     x22, x21, [sp, #0x10]                      
02ce7680: stp     x20, x19, [sp, #0x20]                      
02ce7684: adrp    x21, #0x662f000                            
02ce7688: adrp    x22, #0x6268000                            
02ce768c: adrp    x20, #0x6268000                            
02ce7690: ldrb    w8, [x21, #0xdf2]                          
02ce7694: ldr     x22, [x22, #0x260]                         T:type60867(k1d)
02ce7698: ldr     x20, [x20, #0x268]                         T:type60921(k1d)
02ce769c: mov     x19, x0                                    
02ce76a0: tbnz    w8, #0, #0x2ce76c4                         
02ce76a4: adrp    x0, #0x6268000                             
02ce76a8: ldr     x0, [x0, #0x260]                           T:type60867(k1d)
02ce76ac: bl      #0x2b70db0                                 fn_2b70db0
02ce76b0: adrp    x0, #0x6268000                             
02ce76b4: ldr     x0, [x0, #0x268]                           T:type60921(k1d)
02ce76b8: bl      #0x2b70db0                                 fn_2b70db0
02ce76bc: mov     w8, #1                                     
02ce76c0: strb    w8, [x21, #0xdf2]                          
02ce76c4: ldr     x0, [x22]                                  S:'{0}/2'
02ce76c8: mov     w1, wzr                                    
02ce76cc: bl      #0x2b70ea0                                 fn_2b70ea0
02ce76d0: mov     x1, x0                                     
02ce76d4: mov     x0, x19                                    
02ce76d8: str     x1, [x0, #0x38]!                           .btnArray
02ce76dc: bl      #0x2b70d54                                 fn_2b70d54
02ce76e0: ldr     x0, [x20]                                  S:'{0}/2'
02ce76e4: mov     w1, wzr                                    
02ce76e8: bl      #0x2b70ea0                                 fn_2b70ea0
02ce76ec: mov     x1, x0                                     
02ce76f0: mov     x0, x19                                    
02ce76f4: str     x1, [x0, #0x40]!                           .imgArray
02ce76f8: bl      #0x2b70d54                                 fn_2b70d54
02ce76fc: mov     x0, x19                                    
02ce7700: ldp     x20, x19, [sp, #0x20]                      
02ce7704: ldp     x22, x21, [sp, #0x10]                      
02ce7708: mov     x1, xzr                                    
02ce770c: ldr     x30, [sp], #0x30                           
02ce7710: b       #0x5b397b0                                 UnityEngine.MonoBehaviour::.ctor
## <Start>b__13_0() -> void
---- RateUs::<Start>b__13_0 0x2ce7714
02ce7714: str     x30, [sp, #-0x20]!                         
02ce7718: stp     x20, x19, [sp, #0x10]                      
02ce771c: adrp    x20, #0x662f000                            
02ce7720: mov     x19, x0                                    
02ce7724: ldrb    w8, [x20, #0xdf3]                          
02ce7728: tbnz    w8, #0, #0x2ce7740                         
02ce772c: adrp    x0, #0x6267000                             
02ce7730: ldr     x0, [x0, #0xd50]                           MS:MonoSingleton`1::get_Instance
02ce7734: bl      #0x2b70db0                                 fn_2b70db0
02ce7738: mov     w8, #1                                     
02ce773c: strb    w8, [x20, #0xdf3]                          
02ce7740: mov     x0, xzr                                    
02ce7744: bl      #0x2d6eec8                                 Framework.AudioManager::get_Instance
02ce7748: cbz     x0, #0x2ce77b0                             
02ce774c: movi    d1, #0000000000000000                      
02ce7750: movi    d2, #0000000000000000                      
02ce7754: adrp    x20, #0x6267000                            
02ce7758: fmov    s0, #1.00000000                            
02ce775c: ldr     x20, [x20, #0xd50]                         MS:MonoSingleton`1::get_Instance
02ce7760: mov     w1, #1                                     
02ce7764: mov     w2, wzr                                    
02ce7768: mov     w3, wzr                                    
02ce776c: mov     x4, xzr                                    
02ce7770: bl      #0x2d6f03c                                 Framework.AudioManager::PlaySound
02ce7774: ldr     x0, [x20]                                  S:'didu'
02ce7778: bl      #0x3769600                                 fn_3769600
02ce777c: cbz     x0, #0x2ce77b0                             
02ce7780: mov     w1, #4                                     
02ce7784: mov     x2, xzr                                    
02ce7788: bl      #0x2cc6ee0                                 Framework.VibrationManager::Haptic
02ce778c: ldr     w1, [x19, #0x80]                           .rateCount
02ce7790: mov     x0, x19                                    
02ce7794: bl      #0x2ce74ac                                 RateUs::I_Rate
02ce7798: mov     x1, x0                                     
02ce779c: mov     x0, x19                                    
02ce77a0: mov     x2, xzr                                    
02ce77a4: ldp     x20, x19, [sp, #0x10]                      
02ce77a8: ldr     x30, [sp], #0x20                           
02ce77ac: b       #0x5b389f0                                 UnityEngine.MonoBehaviour::StartCoroutine
02ce77b0: bl      #0x2b7105c                                 fn_2b7105c
## <OnHide>b__16_0() -> void
---- RateUs::<OnHide>b__16_0 0x2ce77b4
02ce77b4: stp     x30, x19, [sp, #-0x10]!                    
02ce77b8: movi    d0, #0000000000000000                      
02ce77bc: mov     x19, x0                                    
02ce77c0: ldr     x0, [x0, #0x28]                            
02ce77c4: mov     w1, wzr                                    
02ce77c8: mov     x2, xzr                                    
02ce77cc: bl      #0x2cf1928                                 FrameWorkUtility::SetActive
02ce77d0: strb    wzr, [x19, #0x20]                          
02ce77d4: ldp     x30, x19, [sp], #0x10                      
02ce77d8: ret                                                
