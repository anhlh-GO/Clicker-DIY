#### CLASS Framework.EnumHelper parent= object
##  ConvertToDictionaryKeyInt (no body)
##  ConvertToDictionaryKeyString (no body)
##  ConvertToListInt (no body)
