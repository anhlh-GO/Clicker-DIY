#### CLASS Framework.VectorExtension parent= object
## GetAngleInRadian(UnityEngine.Vector2 v1, UnityEngine.Vector2 v2) -> float
---- Framework.VectorExtension::GetAngleInRadian 0x2cbc16c
02cbc16c: fsub    s3, s3, s1                                 
02cbc170: fsub    s1, s2, s0                                 
02cbc174: fmov    s0, s3                                     
02cbc178: b       #0x5e902f0                                 
## GetAngleInDegree(UnityEngine.Vector2 v1, UnityEngine.Vector2 v2) -> float
---- Framework.VectorExtension::GetAngleInDegree 0x2cbc17c
02cbc17c: str     x30, [sp, #-0x10]!                         
02cbc180: fsub    s3, s3, s1                                 
02cbc184: fsub    s1, s2, s0                                 
02cbc188: fmov    s0, s3                                     
02cbc18c: bl      #0x5e902f0                                 fn_5e902f0
02cbc190: adrp    x8, #0x1084000                             
02cbc194: ldr     s1, [x8, #0xdec]                           [1084dec]=3fe6666642652ee1 f=57.2958,1.8
02cbc198: fmul    s0, s0, s1                                 
02cbc19c: ldr     x30, [sp], #0x10                           
02cbc1a0: ret                                                
## Rotate(UnityEngine.Vector2 v, float angle) -> UnityEngine.Vector2
---- Framework.VectorExtension::Rotate 0x2cbc1a4
02cbc1a4: sub     sp, sp, #0x40                              
02cbc1a8: str     d10, [sp, #0x10]                           
02cbc1ac: stp     d9, d8, [sp, #0x20]                        
02cbc1b0: stp     x30, x19, [sp, #0x30]                      
02cbc1b4: fmov    s10, s2                                    
02cbc1b8: fmov    s8, s1                                     
02cbc1bc: adrp    x19, #0x662f000                            
02cbc1c0: fmov    s9, s0                                     
02cbc1c4: ldrb    w8, [x19, #0xca4]                          
02cbc1c8: cbnz    w8, #0x2cbc1e0                             
02cbc1cc: adrp    x0, #0x6264000                             
02cbc1d0: ldr     x0, [x0, #0xd8]                            T:UnityEngine.Vector3
02cbc1d4: bl      #0x2b70db0                                 fn_2b70db0
02cbc1d8: mov     w8, #1                                     
02cbc1dc: strb    w8, [x19, #0xca4]                          
02cbc1e0: adrp    x8, #0x6264000                             
02cbc1e4: mov     x0, sp                                     
02cbc1e8: mov     x1, xzr                                    
02cbc1ec: ldr     x8, [x8, #0xd8]                            T:UnityEngine.Vector3
02cbc1f0: ldr     x8, [x8]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02cbc1f4: ldr     x8, [x8, #0xb8]                            MS:DG.Tweening.Core.Extensions::SetSpecialStartupMode
02cbc1f8: ldur    d0, [x8, #0x54]                            
02cbc1fc: ldr     s1, [x8, #0x5c]                            [626405c]=0 f=0,0
02cbc200: str     d0, [sp]                                   
02cbc204: fmov    s0, s10                                    
02cbc208: str     s1, [sp, #8]                               
02cbc20c: bl      #0x5b2620c                                 UnityEngine.Quaternion::Internal_AngleAxis
02cbc210: movi    d6, #0000000000000000                      
02cbc214: fmov    s4, s9                                     
02cbc218: mov     x0, xzr                                    
02cbc21c: fmov    s5, s8                                     
02cbc220: bl      #0x5b26598                                 UnityEngine.Quaternion::op_Multiply
02cbc224: ldp     x30, x19, [sp, #0x30]                      
02cbc228: ldr     d10, [sp, #0x10]                           
02cbc22c: ldp     d9, d8, [sp, #0x20]                        
02cbc230: add     sp, sp, #0x40                              
02cbc234: ret                                                
## GetAngleInDegree(UnityEngine.Vector2 v1) -> float
---- Framework.VectorExtension::GetAngleInDegree 0x2cbc238
02cbc238: str     x30, [sp, #-0x10]!                         
02cbc23c: fmov    s2, s0                                     
02cbc240: fmov    s0, s1                                     
02cbc244: fmov    s1, s2                                     
02cbc248: bl      #0x5e902f0                                 fn_5e902f0
02cbc24c: adrp    x8, #0x1084000                             
02cbc250: ldr     s1, [x8, #0xdec]                           [1084dec]=3fe6666642652ee1 f=57.2958,1.8
02cbc254: fmul    s0, s0, s1                                 
02cbc258: ldr     x30, [sp], #0x10                           
02cbc25c: ret                                                
## GetAngleInRadian(UnityEngine.Vector3 v1, UnityEngine.Vector3 v2) -> float
---- Framework.VectorExtension::GetAngleInRadian 0x2cbc260
02cbc260: fsub    s2, s4, s1                                 
02cbc264: fsub    s1, s3, s0                                 
02cbc268: fmov    s0, s2                                     
02cbc26c: b       #0x5e902f0                                 
## GetAngleInDegree(UnityEngine.Vector3 v1, UnityEngine.Vector3 v2) -> float
---- Framework.VectorExtension::GetAngleInDegree 0x2cbc270
02cbc270: str     x30, [sp, #-0x10]!                         
02cbc274: fsub    s2, s4, s1                                 
02cbc278: fsub    s1, s3, s0                                 
02cbc27c: fmov    s0, s2                                     
02cbc280: bl      #0x5e902f0                                 fn_5e902f0
02cbc284: adrp    x8, #0x1084000                             
02cbc288: ldr     s1, [x8, #0xdec]                           [1084dec]=3fe6666642652ee1 f=57.2958,1.8
02cbc28c: fmul    s0, s0, s1                                 
02cbc290: ldr     x30, [sp], #0x10                           
02cbc294: ret                                                
## GetAngleInDegree(UnityEngine.Vector3 v1) -> float
---- Framework.VectorExtension::GetAngleInDegree 0x2cbc298
02cbc298: str     x30, [sp, #-0x10]!                         
02cbc29c: fmov    s2, s0                                     
02cbc2a0: fmov    s0, s1                                     
02cbc2a4: fmov    s1, s2                                     
02cbc2a8: bl      #0x5e902f0                                 fn_5e902f0
02cbc2ac: adrp    x8, #0x1084000                             
02cbc2b0: ldr     s1, [x8, #0xdec]                           [1084dec]=3fe6666642652ee1 f=57.2958,1.8
02cbc2b4: fmul    s0, s0, s1                                 
02cbc2b8: ldr     x30, [sp], #0x10                           
02cbc2bc: ret                                                
## Rotate(UnityEngine.Vector3 v, float angle) -> UnityEngine.Vector3
---- Framework.VectorExtension::Rotate 0x2cbc2c0
02cbc2c0: sub     sp, sp, #0x40                              
02cbc2c4: stp     d11, d10, [sp, #0x10]                      
02cbc2c8: stp     d9, d8, [sp, #0x20]                        
02cbc2cc: stp     x30, x19, [sp, #0x30]                      
02cbc2d0: fmov    s11, s3                                    
02cbc2d4: fmov    s8, s2                                     
02cbc2d8: adrp    x19, #0x662f000                            
02cbc2dc: fmov    s9, s1                                     
02cbc2e0: fmov    s10, s0                                    
02cbc2e4: ldrb    w8, [x19, #0xca4]                          
02cbc2e8: cbnz    w8, #0x2cbc300                             
02cbc2ec: adrp    x0, #0x6264000                             
02cbc2f0: ldr     x0, [x0, #0xd8]                            T:UnityEngine.Vector3
02cbc2f4: bl      #0x2b70db0                                 fn_2b70db0
02cbc2f8: mov     w8, #1                                     
02cbc2fc: strb    w8, [x19, #0xca4]                          
02cbc300: adrp    x8, #0x6264000                             
02cbc304: mov     x0, sp                                     
02cbc308: mov     x1, xzr                                    
02cbc30c: ldr     x8, [x8, #0xd8]                            T:UnityEngine.Vector3
02cbc310: ldr     x8, [x8]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02cbc314: ldr     x8, [x8, #0xb8]                            MS:DG.Tweening.Core.Extensions::SetSpecialStartupMode
02cbc318: ldur    d0, [x8, #0x54]                            
02cbc31c: ldr     s1, [x8, #0x5c]                            [626405c]=0 f=0,0
02cbc320: str     d0, [sp]                                   
02cbc324: fmov    s0, s11                                    
02cbc328: str     s1, [sp, #8]                               
02cbc32c: bl      #0x5b2620c                                 UnityEngine.Quaternion::Internal_AngleAxis
02cbc330: fmov    s4, s10                                    
02cbc334: fmov    s5, s9                                     
02cbc338: mov     x0, xzr                                    
02cbc33c: fmov    s6, s8                                     
02cbc340: bl      #0x5b26598                                 UnityEngine.Quaternion::op_Multiply
02cbc344: ldp     x30, x19, [sp, #0x30]                      
02cbc348: ldp     d9, d8, [sp, #0x20]                        
02cbc34c: ldp     d11, d10, [sp, #0x10]                      
02cbc350: add     sp, sp, #0x40                              
02cbc354: ret                                                
