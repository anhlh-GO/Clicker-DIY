#### CLASS PoolElement parent= UnityEngine.MonoBehaviour
#   field pool                           PathologicalGames.SpawnPool                        off=0x20 attr=4 HideInInspector
## AssignSelf(PathologicalGames.SpawnPool pool) -> void
---- PoolElement::AssignSelf 0x2cdc878
02cdc878: str     x1, [x0, #0x20]!                           .pool
02cdc87c: b       #0x2b70d54                                 
## DespawnSelf() -> void
---- PoolElement::DespawnSelf 0x2cdc880
02cdc880: stp     x30, x21, [sp, #-0x20]!                    
02cdc884: stp     x20, x19, [sp, #0x10]                      
02cdc888: adrp    x20, #0x662f000                            
02cdc88c: adrp    x21, #0x6263000                            
02cdc890: mov     x19, x0                                    
02cdc894: ldrb    w8, [x20, #0xd74]                          
02cdc898: ldr     x21, [x21, #0x918]                         T:UnityEngine.Object
02cdc89c: tbnz    w8, #0, #0x2cdc8c0                         
02cdc8a0: adrp    x0, #0x6266000                             
02cdc8a4: ldr     x0, [x0, #0xd20]                           MS:MonoSingleton`1::get_Instance
02cdc8a8: bl      #0x2b70db0                                 fn_2b70db0
02cdc8ac: adrp    x0, #0x6263000                             
02cdc8b0: ldr     x0, [x0, #0x918]                           T:UnityEngine.Object
02cdc8b4: bl      #0x2b70db0                                 fn_2b70db0
02cdc8b8: mov     w8, #1                                     
02cdc8bc: strb    w8, [x20, #0xd74]                          
02cdc8c0: ldr     x0, [x21]                                  &2c5bbd4(=a9bd7bfdd503233f)
02cdc8c4: ldr     x20, [x19, #0x20]                          .pool
02cdc8c8: ldr     w8, [x0, #0xe4]                            [62630e4]=0 f=0,0
02cdc8cc: cbnz    w8, #0x2cdc8d4                             
02cdc8d0: bl      #0x2b70f30                                 fn_2b70f30
02cdc8d4: mov     x0, x20                                    
02cdc8d8: mov     x1, xzr                                    
02cdc8dc: mov     x2, xzr                                    
02cdc8e0: bl      #0x5b3666c                                 UnityEngine.Object::op_Inequality
02cdc8e4: tbz     w0, #0, #0x2cdc91c                         
02cdc8e8: adrp    x8, #0x6266000                             
02cdc8ec: ldr     x8, [x8, #0xd20]                           MS:MonoSingleton`1::get_Instance
02cdc8f0: ldr     x0, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cdc8f4: bl      #0x3769600                                 fn_3769600
02cdc8f8: mov     x20, x0                                    
02cdc8fc: mov     x0, x19                                    
02cdc900: mov     x1, xzr                                    
02cdc904: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02cdc908: mov     x1, x0                                     
02cdc90c: cbz     x20, #0x2cdc960                            
02cdc910: mov     x0, x20                                    
02cdc914: bl      #0x2cdc9f4                                 PoolManager::DespawnObject
02cdc918: b       #0x2cdc948                                 
02cdc91c: mov     x0, x19                                    
02cdc920: mov     x1, xzr                                    
02cdc924: bl      #0x5b339ec                                 UnityEngine.Component::get_gameObject
02cdc928: mov     x20, x0                                    
02cdc92c: ldr     x0, [x21]                                  &2c5bbd4(=a9bd7bfdd503233f)
02cdc930: ldr     w8, [x0, #0xe4]                            [62630e4]=0 f=0,0
02cdc934: cbnz    w8, #0x2cdc93c                             
02cdc938: bl      #0x2b70f30                                 fn_2b70f30
02cdc93c: mov     x0, x20                                    
02cdc940: mov     x1, xzr                                    
02cdc944: bl      #0x5b3ca38                                 UnityEngine.Object::Destroy
02cdc948: ldr     x8, [x19]                                  
02cdc94c: mov     x0, x19                                    
02cdc950: ldp     x20, x19, [sp, #0x10]                      
02cdc954: ldp     x2, x1, [x8, #0x188]                       
02cdc958: ldp     x30, x21, [sp], #0x20                      
02cdc95c: br      x2                                         
02cdc960: bl      #0x2b7105c                                 fn_2b7105c
02cdc964: b       #0x2cdc974                                 
02cdc968: b       #0x2cdc974                                 
02cdc96c: b       #0x2cdc974                                 
02cdc970: b       #0x2cdc974                                 
02cdc974: mov     x20, x0                                    
02cdc978: cmp     w1, #1                                     
02cdc97c: b.ne    #0x2cdc9e8                                 
02cdc980: mov     x0, x20                                    
02cdc984: bl      #0x5e90260                                 fn_5e90260
02cdc988: mov     x20, x0                                    
02cdc98c: adrp    x0, #0x6263000                             
02cdc990: ldr     x0, [x0, #0xae0]                           T:System.Exception
02cdc994: bl      #0x2b70dc4                                 fn_2b70dc4
02cdc998: ldr     x8, [x20]                                  &2b706c4(=eb01011ff9400808)
02cdc99c: ldr     x1, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cdc9a0: bl      #0x2b71464                                 fn_2b71464
02cdc9a4: tbz     w0, #0, #0x2cdc9c0                         
02cdc9a8: ldr     x20, [x20]                                 &2b706c4(=eb01011ff9400808)
02cdc9ac: bl      #0x5e90270                                 fn_5e90270
02cdc9b0: mov     x0, x20                                    
02cdc9b4: mov     x1, xzr                                    
02cdc9b8: bl      #0x2cf0434                                 FrameWorkUtility::Log
02cdc9bc: b       #0x2cdc948                                 
02cdc9c0: mov     w0, #8                                     
02cdc9c4: bl      #0x5e90290                                 fn_5e90290
02cdc9c8: ldr     x8, [x20]                                  &2b706c4(=eb01011ff9400808)
02cdc9cc: str     x8, [x0]                                   
02cdc9d0: adrp    x1, #0x5e96000                             
02cdc9d4: add     x1, x1, #0x758                             &5e96758
02cdc9d8: mov     x2, xzr                                    
02cdc9dc: bl      #0x5e902a0                                 fn_5e902a0
02cdc9e0: mov     x20, x0                                    
02cdc9e4: bl      #0x5e90270                                 fn_5e90270
02cdc9e8: mov     x0, x20                                    
02cdc9ec: bl      #0x2c6051c                                 fn_2c6051c
02cdc9f0: bl      #0x27369b8                                 fn_27369b8
## DespawnSelf(float delay) -> void
---- PoolElement::DespawnSelf 0x2cdc2e0
02cdc2e0: str     d8, [sp, #-0x20]!                          
02cdc2e4: str     x30, [sp, #8]                              
02cdc2e8: stp     x20, x19, [sp, #0x10]                      
02cdc2ec: fmov    s8, s0                                     
02cdc2f0: adrp    x20, #0x662f000                            
02cdc2f4: mov     x19, x0                                    
02cdc2f8: ldrb    w8, [x20, #0xd75]                          
02cdc2fc: tbnz    w8, #0, #0x2cdc320                         
02cdc300: adrp    x0, #0x6267000                             
02cdc304: ldr     x0, [x0, #0xc88]                           M:PoolElement::<DespawnSelf>b__3_0
02cdc308: bl      #0x2b70db0                                 fn_2b70db0
02cdc30c: adrp    x0, #0x6264000                             
02cdc310: ldr     x0, [x0, #0xe8]                            T:DG.Tweening.TweenCallback
02cdc314: bl      #0x2b70db0                                 fn_2b70db0
02cdc318: mov     w8, #1                                     
02cdc31c: strb    w8, [x20, #0xd75]                          
02cdc320: fcmp    s8, #0.0                                   
02cdc324: b.le    #0x2cdc374                                 
02cdc328: adrp    x8, #0x6264000                             
02cdc32c: adrp    x20, #0x6267000                            
02cdc330: ldr     x8, [x8, #0xe8]                            T:DG.Tweening.TweenCallback
02cdc334: ldr     x20, [x20, #0xc88]                         M:PoolElement::<DespawnSelf>b__3_0
02cdc338: ldr     x0, [x8]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02cdc33c: bl      #0x2b7104c                                 fn_2b7104c
02cdc340: ldr     x2, [x20]                                  S:'didu'
02cdc344: mov     x1, x19                                    
02cdc348: mov     x3, xzr                                    
02cdc34c: mov     x20, x0                                    
02cdc350: bl      #0x2d89dc4                                 DG.Tweening.TweenCallback::.ctor
02cdc354: mov     x0, x20                                    
02cdc358: ldp     x20, x19, [sp, #0x10]                      
02cdc35c: ldr     x30, [sp, #8]                              
02cdc360: fmov    s0, s8                                     
02cdc364: mov     w1, #1                                     
02cdc368: mov     x2, xzr                                    
02cdc36c: ldr     d8, [sp], #0x20                            
02cdc370: b       #0x2d8f37c                                 DG.Tweening.DOVirtual::DelayedCall
02cdc374: mov     x0, x19                                    
02cdc378: ldp     x20, x19, [sp, #0x10]                      
02cdc37c: ldr     x30, [sp, #8]                              
02cdc380: ldr     d8, [sp], #0x20                            
02cdc384: b       #0x2cdc880                                 PoolElement::DespawnSelf
## OnSpawned() -> void
---- PoolElement::OnSpawned 0x2cdcae0
02cdcae0: ret                                                
## OnDespawned() -> void
---- PoolElement::OnDespawned 0x2cdcae4
02cdcae4: ret                                                
## SetPosition(UnityEngine.Vector3 position) -> void
---- PoolElement::SetPosition 0x2cdcae8
02cdcae8: str     d10, [sp, #-0x20]!                         
02cdcaec: stp     d9, d8, [sp, #8]                           
02cdcaf0: str     x30, [sp, #0x18]                           
02cdcaf4: mov     x1, xzr                                    
02cdcaf8: fmov    s8, s2                                     
02cdcafc: fmov    s9, s1                                     
02cdcb00: fmov    s10, s0                                    
02cdcb04: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02cdcb08: cbz     x0, #0x2cdcb2c                             
02cdcb0c: fmov    s1, s9                                     
02cdcb10: fmov    s2, s8                                     
02cdcb14: ldr     x30, [sp, #0x18]                           
02cdcb18: ldp     d9, d8, [sp, #8]                           
02cdcb1c: fmov    s0, s10                                    
02cdcb20: mov     x1, xzr                                    
02cdcb24: ldr     d10, [sp], #0x20                           
02cdcb28: b       #0x5b46888                                 UnityEngine.Transform::set_position
02cdcb2c: bl      #0x2b7105c                                 fn_2b7105c
## SetRotation(UnityEngine.Quaternion rotation) -> void
---- PoolElement::SetRotation 0x2cdcb30
02cdcb30: stp     d11, d10, [sp, #-0x30]!                    
02cdcb34: stp     d9, d8, [sp, #0x10]                        
02cdcb38: str     x30, [sp, #0x20]                           
02cdcb3c: mov     x1, xzr                                    
02cdcb40: fmov    s8, s3                                     
02cdcb44: fmov    s9, s2                                     
02cdcb48: fmov    s10, s1                                    
02cdcb4c: fmov    s11, s0                                    
02cdcb50: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02cdcb54: cbz     x0, #0x2cdcb7c                             
02cdcb58: fmov    s2, s9                                     
02cdcb5c: fmov    s3, s8                                     
02cdcb60: ldr     x30, [sp, #0x20]                           
02cdcb64: ldp     d9, d8, [sp, #0x10]                        
02cdcb68: fmov    s0, s11                                    
02cdcb6c: fmov    s1, s10                                    
02cdcb70: mov     x1, xzr                                    
02cdcb74: ldp     d11, d10, [sp], #0x30                      
02cdcb78: b       #0x5b46b18                                 UnityEngine.Transform::set_rotation
02cdcb7c: bl      #0x2b7105c                                 fn_2b7105c
## SetScale(UnityEngine.Vector3 scale) -> void
---- PoolElement::SetScale 0x2cdcb80
02cdcb80: str     d10, [sp, #-0x20]!                         
02cdcb84: stp     d9, d8, [sp, #8]                           
02cdcb88: str     x30, [sp, #0x18]                           
02cdcb8c: mov     x1, xzr                                    
02cdcb90: fmov    s8, s2                                     
02cdcb94: fmov    s9, s1                                     
02cdcb98: fmov    s10, s0                                    
02cdcb9c: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02cdcba0: cbz     x0, #0x2cdcbc4                             
02cdcba4: fmov    s1, s9                                     
02cdcba8: fmov    s2, s8                                     
02cdcbac: ldr     x30, [sp, #0x18]                           
02cdcbb0: ldp     d9, d8, [sp, #8]                           
02cdcbb4: fmov    s0, s10                                    
02cdcbb8: mov     x1, xzr                                    
02cdcbbc: ldr     d10, [sp], #0x20                           
02cdcbc0: b       #0x5b470cc                                 UnityEngine.Transform::set_localScale
02cdcbc4: bl      #0x2b7105c                                 fn_2b7105c
## SetEulerAngles(UnityEngine.Vector3 euler) -> void
---- PoolElement::SetEulerAngles 0x2cdcbc8
02cdcbc8: str     d10, [sp, #-0x20]!                         
02cdcbcc: stp     d9, d8, [sp, #8]                           
02cdcbd0: str     x30, [sp, #0x18]                           
02cdcbd4: mov     x1, xzr                                    
02cdcbd8: fmov    s8, s2                                     
02cdcbdc: fmov    s9, s1                                     
02cdcbe0: fmov    s10, s0                                    
02cdcbe4: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02cdcbe8: cbz     x0, #0x2cdcc0c                             
02cdcbec: fmov    s1, s9                                     
02cdcbf0: fmov    s2, s8                                     
02cdcbf4: ldr     x30, [sp, #0x18]                           
02cdcbf8: ldp     d9, d8, [sp, #8]                           
02cdcbfc: fmov    s0, s10                                    
02cdcc00: mov     x1, xzr                                    
02cdcc04: ldr     d10, [sp], #0x20                           
02cdcc08: b       #0x5b46ac4                                 UnityEngine.Transform::set_eulerAngles
02cdcc0c: bl      #0x2b7105c                                 fn_2b7105c
## .ctor() -> void
---- PoolElement::.ctor 0x2cd6228
02cd6228: mov     x1, xzr                                    
02cd622c: b       #0x5b397b0                                 UnityEngine.MonoBehaviour::.ctor
## <DespawnSelf>b__3_0() -> void
---- PoolElement::<DespawnSelf>b__3_0 0x2cdcc10
02cdcc10: b       #0x2cdc880                                 PoolElement::DespawnSelf
