#### CLASS Blindbag.PointData parent= object
#   field Point                          UnityEngine.Transform                              off=0x10 attr=6 
#   field State                          Blindbag.State                                     off=0x18 attr=6 
#   field Bag                            Blindbag.BlindBagAnimation                         off=0x20 attr=6 
## .ctor() -> void
---- Blindbag.PointData::.ctor 0x2d4fe5c
02d4fe5c: mov     x1, xzr                                    
02d4fe60: b       #0x4e53e9c                                 System.Object::.ctor
