#### CLASS HomeScreen parent= ScreenBase
#   field _btnStartGame                  UnityEngine.UI.Button                              off=0x38 attr=1 SerializeField
#   field _btnScoopGame                  UnityEngine.UI.Button                              off=0x40 attr=1 SerializeField
#   field _btnBlindbagGame               UnityEngine.UI.Button                              off=0x48 attr=1 SerializeField
## OnInit(UIManager uiManager) -> void
---- HomeScreen::OnInit 0x2cdfc2c
02cdfc2c: str     x30, [sp, #-0x30]!                         
02cdfc30: stp     x22, x21, [sp, #0x10]                      
02cdfc34: stp     x20, x19, [sp, #0x20]                      
02cdfc38: adrp    x21, #0x662f000                            
02cdfc3c: mov     x20, x1                                    
02cdfc40: mov     x19, x0                                    
02cdfc44: ldrb    w8, [x21, #0xda5]                          
02cdfc48: tbnz    w8, #0, #0x2cdfc9c                         
02cdfc4c: adrp    x0, #0x6267000                             
02cdfc50: ldr     x0, [x0, #0xeb0]                           M:HomeScreen::OnPlayBlindbagGame
02cdfc54: bl      #0x2b70db0                                 fn_2b70db0
02cdfc58: adrp    x0, #0x6267000                             
02cdfc5c: ldr     x0, [x0, #0xeb8]                           M:HomeScreen::OnPlayScoopGame
02cdfc60: bl      #0x2b70db0                                 fn_2b70db0
02cdfc64: adrp    x0, #0x6267000                             
02cdfc68: ldr     x0, [x0, #0xec0]                           M:HomeScreen::OnStartGameClicked
02cdfc6c: bl      #0x2b70db0                                 fn_2b70db0
02cdfc70: adrp    x0, #0x6266000                             
02cdfc74: ldr     x0, [x0, #0xac0]                           MS:MonoSingleton`1::get_Instance
02cdfc78: bl      #0x2b70db0                                 fn_2b70db0
02cdfc7c: adrp    x0, #0x6265000                             
02cdfc80: ldr     x0, [x0, #0x10]                            MS:MonoSingleton`1::get_Instance
02cdfc84: bl      #0x2b70db0                                 fn_2b70db0
02cdfc88: adrp    x0, #0x6265000                             
02cdfc8c: ldr     x0, [x0, #0x3f0]                           T:UnityEngine.Events.UnityAction
02cdfc90: bl      #0x2b70db0                                 fn_2b70db0
02cdfc94: mov     w8, #1                                     
02cdfc98: strb    w8, [x21, #0xda5]                          
02cdfc9c: mov     x0, x19                                    
02cdfca0: mov     x1, x20                                    
02cdfca4: bl      #0x2cdd3c4                                 UIBase::OnInit
02cdfca8: ldr     x8, [x19, #0x38]                           ._btnStartGame
02cdfcac: cbz     x8, #0x2cdfde0                             
02cdfcb0: adrp    x22, #0x6265000                            
02cdfcb4: adrp    x21, #0x6267000                            
02cdfcb8: ldr     x22, [x22, #0x3f0]                         T:UnityEngine.Events.UnityAction
02cdfcbc: ldr     x21, [x21, #0xec0]                         M:HomeScreen::OnStartGameClicked
02cdfcc0: ldr     x20, [x8, #0x100]                          
02cdfcc4: ldr     x0, [x22]                                  M:AdsManager::<OnApplicationPause>b__26_0
02cdfcc8: bl      #0x2b7104c                                 fn_2b7104c
02cdfccc: ldr     x2, [x21]                                  S:'didu'
02cdfcd0: mov     x1, x19                                    
02cdfcd4: mov     x3, xzr                                    
02cdfcd8: mov     x21, x0                                    
02cdfcdc: bl      #0x5b4cf98                                 UnityEngine.Events.UnityAction::.ctor
02cdfce0: cbz     x20, #0x2cdfde0                            
02cdfce4: mov     x0, x20                                    
02cdfce8: mov     x1, x21                                    
02cdfcec: mov     x2, xzr                                    
02cdfcf0: bl      #0x5b4d0ac                                 UnityEngine.Events.UnityEvent::AddListener
02cdfcf4: ldr     x8, [x19, #0x40]                           ._btnScoopGame
02cdfcf8: cbz     x8, #0x2cdfde0                             
02cdfcfc: adrp    x21, #0x6267000                            
02cdfd00: ldr     x21, [x21, #0xeb8]                         M:HomeScreen::OnPlayScoopGame
02cdfd04: ldr     x0, [x22]                                  M:AdsManager::<OnApplicationPause>b__26_0
02cdfd08: ldr     x20, [x8, #0x100]                          
02cdfd0c: bl      #0x2b7104c                                 fn_2b7104c
02cdfd10: ldr     x2, [x21]                                  S:'didu'
02cdfd14: mov     x1, x19                                    
02cdfd18: mov     x3, xzr                                    
02cdfd1c: mov     x21, x0                                    
02cdfd20: bl      #0x5b4cf98                                 UnityEngine.Events.UnityAction::.ctor
02cdfd24: cbz     x20, #0x2cdfde0                            
02cdfd28: mov     x0, x20                                    
02cdfd2c: mov     x1, x21                                    
02cdfd30: mov     x2, xzr                                    
02cdfd34: bl      #0x5b4d0ac                                 UnityEngine.Events.UnityEvent::AddListener
02cdfd38: ldr     x8, [x19, #0x48]                           ._btnBlindbagGame
02cdfd3c: cbz     x8, #0x2cdfde0                             
02cdfd40: adrp    x21, #0x6267000                            
02cdfd44: ldr     x21, [x21, #0xeb0]                         M:HomeScreen::OnPlayBlindbagGame
02cdfd48: ldr     x0, [x22]                                  M:AdsManager::<OnApplicationPause>b__26_0
02cdfd4c: ldr     x20, [x8, #0x100]                          
02cdfd50: bl      #0x2b7104c                                 fn_2b7104c
02cdfd54: ldr     x2, [x21]                                  S:'didu'
02cdfd58: mov     x1, x19                                    
02cdfd5c: mov     x3, xzr                                    
02cdfd60: mov     x21, x0                                    
02cdfd64: bl      #0x5b4cf98                                 UnityEngine.Events.UnityAction::.ctor
02cdfd68: cbz     x20, #0x2cdfde0                            
02cdfd6c: adrp    x19, #0x6266000                            
02cdfd70: mov     x0, x20                                    
02cdfd74: mov     x1, x21                                    
02cdfd78: ldr     x19, [x19, #0xac0]                         MS:MonoSingleton`1::get_Instance
02cdfd7c: mov     x2, xzr                                    
02cdfd80: bl      #0x5b4d0ac                                 UnityEngine.Events.UnityEvent::AddListener
02cdfd84: ldr     x0, [x19]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cdfd88: bl      #0x3769600                                 fn_3769600
02cdfd8c: cbz     x0, #0x2cdfde0                             
02cdfd90: adrp    x8, #0x6265000                             
02cdfd94: ldrb    w9, [x0, #0x4d]                            
02cdfd98: ldr     x8, [x8, #0x10]                            MS:MonoSingleton`1::get_Instance
02cdfd9c: cbz     w9, #0x2cdfdc4                             
02cdfda0: ldr     x8, [x8]                                   M:AdsManager::<OnApplicationPause>b__26_0
02cdfda4: strb    wzr, [x0, #0x4d]                           
02cdfda8: mov     x0, x8                                     
02cdfdac: bl      #0x3769600                                 fn_3769600
02cdfdb0: cbz     x0, #0x2cdfde0                             
02cdfdb4: ldp     x20, x19, [sp, #0x20]                      
02cdfdb8: ldp     x22, x21, [sp, #0x10]                      
02cdfdbc: ldr     x30, [sp], #0x30                           
02cdfdc0: b       #0x2cdfde4                                 SimpleSceneTransition::ForceFadeOut
02cdfdc4: ldr     x0, [x8]                                   M:AdsManager::<OnApplicationPause>b__26_0
02cdfdc8: bl      #0x3769600                                 fn_3769600
02cdfdcc: cbz     x0, #0x2cdfde0                             
02cdfdd0: ldp     x20, x19, [sp, #0x20]                      
02cdfdd4: ldp     x22, x21, [sp, #0x10]                      
02cdfdd8: ldr     x30, [sp], #0x30                           
02cdfddc: b       #0x2cdff7c                                 SimpleSceneTransition::FadeOut
02cdfde0: bl      #0x2b7105c                                 fn_2b7105c
## OnStartGameClicked() -> void
---- HomeScreen::OnStartGameClicked 0x2ce01d4
02ce01d4: sub     sp, sp, #0x40                              
02ce01d8: stp     x30, x21, [sp, #0x20]                      
02ce01dc: stp     x20, x19, [sp, #0x30]                      
02ce01e0: adrp    x20, #0x662f000                            
02ce01e4: adrp    x21, #0x6267000                            
02ce01e8: adrp    x19, #0x6264000                            
02ce01ec: ldrb    w8, [x20, #0xda6]                          
02ce01f0: ldr     x21, [x21, #0x950]                         T:SceneNames
02ce01f4: ldr     x19, [x19, #0xb58]                         T:UnityEngine.SceneManagement.SceneManager
02ce01f8: tbnz    w8, #0, #0x2ce021c                         
02ce01fc: adrp    x0, #0x6264000                             
02ce0200: ldr     x0, [x0, #0xb58]                           T:UnityEngine.SceneManagement.SceneManager
02ce0204: bl      #0x2b70db0                                 fn_2b70db0
02ce0208: adrp    x0, #0x6267000                             
02ce020c: ldr     x0, [x0, #0x950]                           T:SceneNames
02ce0210: bl      #0x2b70db0                                 fn_2b70db0
02ce0214: mov     w8, #1                                     
02ce0218: strb    w8, [x20, #0xda6]                          
02ce021c: ldr     x8, [x21]                                  S:'didu'
02ce0220: mov     x9, #-1                                    
02ce0224: add     x0, sp, #8                                 
02ce0228: mov     x1, xzr                                    
02ce022c: stp     x8, x9, [sp, #8]                           
02ce0230: mov     w8, #2                                     
02ce0234: str     w8, [sp, #0x18]                            
02ce0238: bl      #0x4e47e48                                 System.Enum::ToString
02ce023c: ldr     x8, [x19]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02ce0240: mov     x19, x0                                    
02ce0244: ldr     w9, [x8, #0xe4]                            
02ce0248: cbnz    w9, #0x2ce0254                             
02ce024c: mov     x0, x8                                     
02ce0250: bl      #0x2b70f30                                 fn_2b70f30
02ce0254: mov     x0, x19                                    
02ce0258: mov     x1, xzr                                    
02ce025c: bl      #0x5b4f55c                                 UnityEngine.SceneManagement.SceneManager::LoadScene
02ce0260: ldp     x20, x19, [sp, #0x30]                      
02ce0264: ldp     x30, x21, [sp, #0x20]                      
02ce0268: add     sp, sp, #0x40                              
02ce026c: ret                                                
## OnPlayScoopGame() -> void
---- HomeScreen::OnPlayScoopGame 0x2ce0270
02ce0270: str     x30, [sp, #-0x20]!                         
02ce0274: stp     x20, x19, [sp, #0x10]                      
02ce0278: adrp    x20, #0x662f000                            
02ce027c: adrp    x19, #0x6266000                            
02ce0280: ldrb    w8, [x20, #0xda7]                          
02ce0284: ldr     x19, [x19, #0x5e0]                         T:GameConfig
02ce0288: tbnz    w8, #0, #0x2ce02ac                         
02ce028c: adrp    x0, #0x6266000                             
02ce0290: ldr     x0, [x0, #0x5e0]                           T:GameConfig
02ce0294: bl      #0x2b70db0                                 fn_2b70db0
02ce0298: adrp    x0, #0x6264000                             
02ce029c: ldr     x0, [x0, #0xb58]                           T:UnityEngine.SceneManagement.SceneManager
02ce02a0: bl      #0x2b70db0                                 fn_2b70db0
02ce02a4: mov     w8, #1                                     
02ce02a8: strb    w8, [x20, #0xda7]                          
02ce02ac: ldr     x0, [x19]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ce02b0: adrp    x20, #0x6264000                            
02ce02b4: ldr     w8, [x0, #0xe4]                            [62640e4]=0 f=0,0
02ce02b8: ldr     x20, [x20, #0xb58]                         T:UnityEngine.SceneManagement.SceneManager
02ce02bc: cbnz    w8, #0x2ce02c8                             
02ce02c0: bl      #0x2b70f30                                 fn_2b70f30
02ce02c4: ldr     x0, [x19]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ce02c8: ldr     x8, [x20]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02ce02cc: ldr     x9, [x0, #0xb8]                            MS:DG.Tweening.Core.Extensions::SetSpecialStartupMode
02ce02d0: ldr     w10, [x8, #0xe4]                           
02ce02d4: ldr     x19, [x9, #0x30]                           
02ce02d8: cbnz    w10, #0x2ce02e4                            
02ce02dc: mov     x0, x8                                     
02ce02e0: bl      #0x2b70f30                                 fn_2b70f30
02ce02e4: mov     x0, x19                                    
02ce02e8: ldp     x20, x19, [sp, #0x10]                      
02ce02ec: mov     x1, xzr                                    
02ce02f0: ldr     x30, [sp], #0x20                           
02ce02f4: b       #0x5b4f55c                                 UnityEngine.SceneManagement.SceneManager::LoadScene
## OnPlayBlindbagGame() -> void
---- HomeScreen::OnPlayBlindbagGame 0x2ce02f8
02ce02f8: str     x30, [sp, #-0x20]!                         
02ce02fc: stp     x20, x19, [sp, #0x10]                      
02ce0300: adrp    x20, #0x662f000                            
02ce0304: adrp    x19, #0x6266000                            
02ce0308: ldrb    w8, [x20, #0xda8]                          
02ce030c: ldr     x19, [x19, #0x5e0]                         T:GameConfig
02ce0310: tbnz    w8, #0, #0x2ce0334                         
02ce0314: adrp    x0, #0x6266000                             
02ce0318: ldr     x0, [x0, #0x5e0]                           T:GameConfig
02ce031c: bl      #0x2b70db0                                 fn_2b70db0
02ce0320: adrp    x0, #0x6264000                             
02ce0324: ldr     x0, [x0, #0xb58]                           T:UnityEngine.SceneManagement.SceneManager
02ce0328: bl      #0x2b70db0                                 fn_2b70db0
02ce032c: mov     w8, #1                                     
02ce0330: strb    w8, [x20, #0xda8]                          
02ce0334: ldr     x0, [x19]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ce0338: adrp    x20, #0x6264000                            
02ce033c: ldr     w8, [x0, #0xe4]                            [62640e4]=0 f=0,0
02ce0340: ldr     x20, [x20, #0xb58]                         T:UnityEngine.SceneManagement.SceneManager
02ce0344: cbnz    w8, #0x2ce0350                             
02ce0348: bl      #0x2b70f30                                 fn_2b70f30
02ce034c: ldr     x0, [x19]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ce0350: ldr     x8, [x20]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02ce0354: ldr     x9, [x0, #0xb8]                            MS:DG.Tweening.Core.Extensions::SetSpecialStartupMode
02ce0358: ldr     w10, [x8, #0xe4]                           
02ce035c: ldr     x19, [x9, #0x18]                           
02ce0360: cbnz    w10, #0x2ce036c                            
02ce0364: mov     x0, x8                                     
02ce0368: bl      #0x2b70f30                                 fn_2b70f30
02ce036c: mov     x0, x19                                    
02ce0370: ldp     x20, x19, [sp, #0x10]                      
02ce0374: mov     x1, xzr                                    
02ce0378: ldr     x30, [sp], #0x20                           
02ce037c: b       #0x5b4f55c                                 UnityEngine.SceneManagement.SceneManager::LoadScene
## .ctor() -> void
---- HomeScreen::.ctor 0x2ce0380
02ce0380: mov     x1, xzr                                    
02ce0384: b       #0x5b397b0                                 UnityEngine.MonoBehaviour::.ctor
