#### CLASS Clicker.AssembleResultObject parent= UnityEngine.MonoBehaviour
## .ctor() -> void
---- Clicker.AssembleResultObject::.ctor 0x2d5df20
02d5df20: mov     x1, xzr                                    
02d5df24: b       #0x5b397b0                                 UnityEngine.MonoBehaviour::.ctor
