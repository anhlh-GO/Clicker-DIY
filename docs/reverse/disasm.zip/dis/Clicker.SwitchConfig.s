#### CLASS Clicker.SwitchConfig/<>c__DisplayClass8_0 parent= object
#   field id                             int                                                off=0x10 attr=6 
## .ctor() -> void
---- Clicker.SwitchConfig/<>c__DisplayClass8_0::.ctor 0x2d5bef8
02d5bef8: mov     x1, xzr                                    
02d5befc: b       #0x4e53e9c                                 System.Object::.ctor
## <GetData>b__0(Clicker.SwitchItemData data) -> bool
---- Clicker.SwitchConfig/<>c__DisplayClass8_0::<GetData>b__0 0x2d5bf08
02d5bf08: cbz     x1, #0x2d5bf20                             
02d5bf0c: ldr     w8, [x1, #0x10]                            
02d5bf10: ldr     w9, [x0, #0x10]                            .id
02d5bf14: cmp     w8, w9                                     
02d5bf18: cset    w0, eq                                     
02d5bf1c: ret                                                
02d5bf20: str     x30, [sp, #-0x10]!                         
02d5bf24: bl      #0x2b7105c                                 fn_2b7105c
## <GetData>b__1(Clicker.SwitchItemData data) -> bool
---- Clicker.SwitchConfig/<>c__DisplayClass8_0::<GetData>b__1 0x2d5bf28
02d5bf28: cbz     x1, #0x2d5bf40                             
02d5bf2c: ldr     w8, [x1, #0x10]                            
02d5bf30: ldr     w9, [x0, #0x10]                            .id
02d5bf34: cmp     w8, w9                                     
02d5bf38: cset    w0, eq                                     
02d5bf3c: ret                                                
02d5bf40: str     x30, [sp, #-0x10]!                         
02d5bf44: bl      #0x2b7105c                                 fn_2b7105c
#### CLASS Clicker.SwitchConfig parent= Clicker.GameConfig
#   field _dataList                      System.Collections.Generic.List`1<Clicker.SwitchItemData> off=0x18 attr=1 SerializeField
#   field _dataListAB                    System.Collections.Generic.List`1<Clicker.SwitchItemData> off=0x20 attr=1 SerializeField
#   field _inputSwitchSprites            System.Collections.Generic.List`1<UnityEngine.Sprite> off=0x28 attr=1 SerializeField
#   field _inputSwitchColors             System.Collections.Generic.List`1<UnityEngine.Color> off=0x30 attr=1 SerializeField
## get_DataList() -> System.Collections.Generic.List`1<Clicker.SwitchItemData>
---- Clicker.SwitchConfig::get_DataList 0x2d5bc40
02d5bc40: stp     x30, x21, [sp, #-0x20]!                    
02d5bc44: stp     x20, x19, [sp, #0x10]                      
02d5bc48: adrp    x21, #0x6630000                            
02d5bc4c: adrp    x20, #0x6264000                            
02d5bc50: mov     x19, x0                                    
02d5bc54: ldrb    w8, [x21, #0x2c8]                          
02d5bc58: ldr     x20, [x20, #0xfc0]                         T:RemoteConfigManager
02d5bc5c: tbnz    w8, #0, #0x2d5bc74                         
02d5bc60: adrp    x0, #0x6264000                             
02d5bc64: ldr     x0, [x0, #0xfc0]                           T:RemoteConfigManager
02d5bc68: bl      #0x2b70db0                                 fn_2b70db0
02d5bc6c: mov     w8, #1                                     
02d5bc70: strb    w8, [x21, #0x2c8]                          
02d5bc74: ldr     x0, [x20]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d5bc78: ldr     w8, [x0, #0xe4]                            [62640e4]=0 f=0,0
02d5bc7c: cbnz    w8, #0x2d5bc84                             
02d5bc80: bl      #0x2b70f30                                 fn_2b70f30
02d5bc84: adrp    x21, #0x662f000                            
02d5bc88: ldrb    w8, [x21, #0xbc1]                          
02d5bc8c: cbnz    w8, #0x2d5bca4                             
02d5bc90: adrp    x0, #0x6264000                             
02d5bc94: ldr     x0, [x0, #0xfc0]                           T:RemoteConfigManager
02d5bc98: bl      #0x2b70db0                                 fn_2b70db0
02d5bc9c: mov     w8, #1                                     
02d5bca0: strb    w8, [x21, #0xbc1]                          
02d5bca4: ldr     x0, [x20]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d5bca8: ldr     w8, [x0, #0xe4]                            [62640e4]=0 f=0,0
02d5bcac: cbnz    w8, #0x2d5bcb8                             
02d5bcb0: bl      #0x2b70f30                                 fn_2b70f30
02d5bcb4: ldr     x0, [x20]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d5bcb8: ldr     x8, [x0, #0xb8]                            MS:DG.Tweening.Core.Extensions::SetSpecialStartupMode
02d5bcbc: mov     w9, #0x18                                  
02d5bcc0: ldr     w8, [x8, #0x10]                            
02d5bcc4: cmp     w8, #1                                     
02d5bcc8: mov     w8, #0x20                                  
02d5bccc: csel    x8, x9, x8, eq                             
02d5bcd0: ldr     x0, [x19, x8]                              
02d5bcd4: ldp     x20, x19, [sp, #0x10]                      
02d5bcd8: ldp     x30, x21, [sp], #0x20                      
02d5bcdc: ret                                                
## get_Count() -> int
---- Clicker.SwitchConfig::get_Count 0x2d5bce0
02d5bce0: stp     x30, x21, [sp, #-0x20]!                    
02d5bce4: stp     x20, x19, [sp, #0x10]                      
02d5bce8: adrp    x21, #0x6630000                            
02d5bcec: adrp    x20, #0x6264000                            
02d5bcf0: mov     x19, x0                                    
02d5bcf4: ldrb    w8, [x21, #0x2c9]                          
02d5bcf8: ldr     x20, [x20, #0xfc0]                         T:RemoteConfigManager
02d5bcfc: tbnz    w8, #0, #0x2d5bd20                         
02d5bd00: adrp    x0, #0x626b000                             
02d5bd04: ldr     x0, [x0, #0xca0]                           MS:System.Collections.Generic.List`1::get_Count
02d5bd08: bl      #0x2b70db0                                 fn_2b70db0
02d5bd0c: adrp    x0, #0x6264000                             
02d5bd10: ldr     x0, [x0, #0xfc0]                           T:RemoteConfigManager
02d5bd14: bl      #0x2b70db0                                 fn_2b70db0
02d5bd18: mov     w8, #1                                     
02d5bd1c: strb    w8, [x21, #0x2c9]                          
02d5bd20: ldr     x0, [x20]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d5bd24: ldr     w8, [x0, #0xe4]                            [62640e4]=0 f=0,0
02d5bd28: cbnz    w8, #0x2d5bd30                             
02d5bd2c: bl      #0x2b70f30                                 fn_2b70f30
02d5bd30: adrp    x21, #0x662f000                            
02d5bd34: ldrb    w8, [x21, #0xbc1]                          
02d5bd38: cbnz    w8, #0x2d5bd50                             
02d5bd3c: adrp    x0, #0x6264000                             
02d5bd40: ldr     x0, [x0, #0xfc0]                           T:RemoteConfigManager
02d5bd44: bl      #0x2b70db0                                 fn_2b70db0
02d5bd48: mov     w8, #1                                     
02d5bd4c: strb    w8, [x21, #0xbc1]                          
02d5bd50: ldr     x0, [x20]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d5bd54: ldr     w8, [x0, #0xe4]                            [62640e4]=0 f=0,0
02d5bd58: cbnz    w8, #0x2d5bd64                             
02d5bd5c: bl      #0x2b70f30                                 fn_2b70f30
02d5bd60: ldr     x0, [x20]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d5bd64: ldr     x8, [x0, #0xb8]                            MS:DG.Tweening.Core.Extensions::SetSpecialStartupMode
02d5bd68: ldr     w8, [x8, #0x10]                            
02d5bd6c: cmp     w8, #1                                     
02d5bd70: b.ne    #0x2d5bd80                                 
02d5bd74: ldr     x8, [x19, #0x18]                           ._dataList
02d5bd78: cbnz    x8, #0x2d5bd88                             
02d5bd7c: bl      #0x2b7105c                                 fn_2b7105c
02d5bd80: ldr     x8, [x19, #0x20]                           ._dataListAB
02d5bd84: cbz     x8, #0x2d5bd7c                             
02d5bd88: ldp     x20, x19, [sp, #0x10]                      
02d5bd8c: ldr     w0, [x8, #0x18]                            
02d5bd90: ldp     x30, x21, [sp], #0x20                      
02d5bd94: ret                                                
## GetData(int id) -> Clicker.SwitchItemData
---- Clicker.SwitchConfig::GetData 0x2d5bd98
02d5bd98: str     x30, [sp, #-0x30]!                         
02d5bd9c: stp     x22, x21, [sp, #0x10]                      
02d5bda0: stp     x20, x19, [sp, #0x20]                      
02d5bda4: adrp    x20, #0x6630000                            
02d5bda8: adrp    x22, #0x626b000                            
02d5bdac: mov     w21, w1                                    
02d5bdb0: ldrb    w8, [x20, #0x2ca]                          
02d5bdb4: ldr     x22, [x22, #0xca8]                         T:Clicker.SwitchConfig/<>c__DisplayClass8_0
02d5bdb8: mov     x19, x0                                    
02d5bdbc: tbnz    w8, #0, #0x2d5be10                         
02d5bdc0: adrp    x0, #0x626b000                             
02d5bdc4: ldr     x0, [x0, #0xcb0]                           MS:System.Collections.Generic.List`1::Find
02d5bdc8: bl      #0x2b70db0                                 fn_2b70db0
02d5bdcc: adrp    x0, #0x626b000                             
02d5bdd0: ldr     x0, [x0, #0xcb8]                           T:type57288(k15)
02d5bdd4: bl      #0x2b70db0                                 fn_2b70db0
02d5bdd8: adrp    x0, #0x6264000                             
02d5bddc: ldr     x0, [x0, #0xfc0]                           T:RemoteConfigManager
02d5bde0: bl      #0x2b70db0                                 fn_2b70db0
02d5bde4: adrp    x0, #0x626b000                             
02d5bde8: ldr     x0, [x0, #0xcc0]                           M:Clicker.SwitchConfig/<>c__DisplayClass8_0::<GetData>b__0
02d5bdec: bl      #0x2b70db0                                 fn_2b70db0
02d5bdf0: adrp    x0, #0x626b000                             
02d5bdf4: ldr     x0, [x0, #0xcc8]                           M:Clicker.SwitchConfig/<>c__DisplayClass8_0::<GetData>b__1
02d5bdf8: bl      #0x2b70db0                                 fn_2b70db0
02d5bdfc: adrp    x0, #0x626b000                             
02d5be00: ldr     x0, [x0, #0xca8]                           T:Clicker.SwitchConfig/<>c__DisplayClass8_0
02d5be04: bl      #0x2b70db0                                 fn_2b70db0
02d5be08: mov     w8, #1                                     
02d5be0c: strb    w8, [x20, #0x2ca]                          
02d5be10: ldr     x0, [x22]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d5be14: bl      #0x2b7104c                                 fn_2b7104c
02d5be18: mov     x1, xzr                                    
02d5be1c: mov     x20, x0                                    
02d5be20: bl      #0x4e53e9c                                 System.Object::.ctor
02d5be24: cbz     x20, #0x2d5bef4                            
02d5be28: adrp    x22, #0x6264000                            
02d5be2c: ldr     x22, [x22, #0xfc0]                         T:RemoteConfigManager
02d5be30: str     w21, [x20, #0x10]                          
02d5be34: ldr     x0, [x22]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d5be38: ldr     w8, [x0, #0xe4]                            [626b0e4]=0 f=0,0
02d5be3c: cbnz    w8, #0x2d5be44                             
02d5be40: bl      #0x2b70f30                                 fn_2b70f30
02d5be44: adrp    x21, #0x662f000                            
02d5be48: ldrb    w8, [x21, #0xbc1]                          
02d5be4c: cbnz    w8, #0x2d5be64                             
02d5be50: adrp    x0, #0x6264000                             
02d5be54: ldr     x0, [x0, #0xfc0]                           T:RemoteConfigManager
02d5be58: bl      #0x2b70db0                                 fn_2b70db0
02d5be5c: mov     w8, #1                                     
02d5be60: strb    w8, [x21, #0xbc1]                          
02d5be64: ldr     x0, [x22]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d5be68: adrp    x21, #0x626b000                            
02d5be6c: ldr     w8, [x0, #0xe4]                            [62640e4]=0 f=0,0
02d5be70: ldr     x21, [x21, #0xcb8]                         T:type57288(k15)
02d5be74: cbnz    w8, #0x2d5be80                             
02d5be78: bl      #0x2b70f30                                 fn_2b70f30
02d5be7c: ldr     x0, [x22]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d5be80: ldr     x8, [x0, #0xb8]                            MS:DG.Tweening.Core.Extensions::SetSpecialStartupMode
02d5be84: ldr     x0, [x21]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d5be88: ldr     w8, [x8, #0x10]                            
02d5be8c: cmp     w8, #1                                     
02d5be90: b.ne    #0x2d5bea8                                 
02d5be94: ldr     x19, [x19, #0x18]                          ._dataList
02d5be98: bl      #0x2b7104c                                 fn_2b7104c
02d5be9c: adrp    x8, #0x626b000                             
02d5bea0: ldr     x8, [x8, #0xcc0]                           M:Clicker.SwitchConfig/<>c__DisplayClass8_0::<GetData>b__0
02d5bea4: b       #0x2d5beb8                                 
02d5bea8: ldr     x19, [x19, #0x20]                          ._dataListAB
02d5beac: bl      #0x2b7104c                                 fn_2b7104c
02d5beb0: adrp    x8, #0x626b000                             
02d5beb4: ldr     x8, [x8, #0xcc8]                           M:Clicker.SwitchConfig/<>c__DisplayClass8_0::<GetData>b__1
02d5beb8: ldr     x2, [x8]                                   T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d5bebc: mov     x1, x20                                    
02d5bec0: mov     x3, xzr                                    
02d5bec4: mov     x21, x0                                    
02d5bec8: bl      #0x399ba10                                 fn_399ba10
02d5becc: cbz     x19, #0x2d5bef4                            
02d5bed0: adrp    x8, #0x626b000                             
02d5bed4: mov     x0, x19                                    
02d5bed8: mov     x1, x21                                    
02d5bedc: ldr     x8, [x8, #0xcb0]                           MS:System.Collections.Generic.List`1::Find
02d5bee0: ldp     x20, x19, [sp, #0x20]                      
02d5bee4: ldp     x22, x21, [sp, #0x10]                      
02d5bee8: ldr     x2, [x8]                                   T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d5beec: ldr     x30, [sp], #0x30                           
02d5bef0: b       #0x35a9868                                 
02d5bef4: bl      #0x2b7105c                                 fn_2b7105c
## .ctor() -> void
---- Clicker.SwitchConfig::.ctor 0x2d5bf00
02d5bf00: mov     x1, xzr                                    
02d5bf04: b       #0x5b398f0                                 UnityEngine.ScriptableObject::.ctor
