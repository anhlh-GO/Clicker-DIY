#### CLASS NotchSolutionDebugger/Menu parent= int
#   field value__                        int                                                off=0x10 attr=606 
#   field Home                           NotchSolutionDebugger/Menu                         off=0x0 attr=8056 
#   field Extracting                     NotchSolutionDebugger/Menu                         off=0x0 attr=8056 
#### CLASS NotchSolutionDebugger/<>c parent= object
#   field <>9                            NotchSolutionDebugger/<>c                          off=0x0 attr=36 
#   field <>9__11_0                      System.Func`2<UnityEngine.Rect,string>             off=0x8 attr=16 
#   field <>9__11_1                      System.Func`2<UnityEngine.Resolution,string>       off=0x10 attr=16 
#   field <>9__11_2                      System.Func`2<System.Reflection.PropertyInfo,string> off=0x18 attr=16 
## .cctor() -> void
---- NotchSolutionDebugger/<>c::.cctor 0x2c880d0
02c880d0: str     x30, [sp, #-0x20]!                         
02c880d4: stp     x20, x19, [sp, #0x10]                      
02c880d8: adrp    x19, #0x662f000                            
02c880dc: adrp    x20, #0x6264000                            
02c880e0: ldrb    w8, [x19, #0x957]                          
02c880e4: ldr     x20, [x20, #0xe10]                         T:NotchSolutionDebugger/<>c
02c880e8: tbnz    w8, #0, #0x2c88100                         
02c880ec: adrp    x0, #0x6264000                             
02c880f0: ldr     x0, [x0, #0xe10]                           T:NotchSolutionDebugger/<>c
02c880f4: bl      #0x2b70db0                                 fn_2b70db0
02c880f8: mov     w8, #1                                     
02c880fc: strb    w8, [x19, #0x957]                          
02c88100: ldr     x0, [x20]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c88104: bl      #0x2b7104c                                 fn_2b7104c
02c88108: mov     x1, xzr                                    
02c8810c: mov     x19, x0                                    
02c88110: bl      #0x4e53e9c                                 System.Object::.ctor
02c88114: ldr     x8, [x20]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c88118: mov     x1, x19                                    
02c8811c: ldr     x8, [x8, #0xb8]                            
02c88120: str     x19, [x8]                                  
02c88124: ldr     x8, [x20]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c88128: ldp     x20, x19, [sp, #0x10]                      
02c8812c: ldr     x0, [x8, #0xb8]                            
02c88130: ldr     x30, [sp], #0x20                           
02c88134: b       #0x2b70d54                                 
## .ctor() -> void
---- NotchSolutionDebugger/<>c::.ctor 0x2c88138
02c88138: mov     x1, xzr                                    
02c8813c: b       #0x4e53e9c                                 System.Object::.ctor
## <Update>b__11_0(UnityEngine.Rect x) -> string
---- NotchSolutionDebugger/<>c::<Update>b__11_0 0x2c88140
02c88140: sub     sp, sp, #0x30                              
02c88144: str     x30, [sp, #0x10]                           
02c88148: stp     x20, x19, [sp, #0x20]                      
02c8814c: adrp    x20, #0x662f000                            
02c88150: stp     s0, s1, [sp]                               
02c88154: adrp    x19, #0x6264000                            
02c88158: ldrb    w8, [x20, #0x958]                          
02c8815c: ldr     x19, [x19, #0x798]                         T:UnityEngine.Rect
02c88160: stp     s2, s3, [sp, #8]                           
02c88164: tbnz    w8, #0, #0x2c8817c                         
02c88168: adrp    x0, #0x6264000                             
02c8816c: ldr     x0, [x0, #0x798]                           T:UnityEngine.Rect
02c88170: bl      #0x2b70db0                                 fn_2b70db0
02c88174: mov     w8, #1                                     
02c88178: strb    w8, [x20, #0x958]                          
02c8817c: ldr     x0, [x19]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c88180: ldr     w8, [x0, #0xe4]                            [62640e4]=0 f=0,0
02c88184: cbnz    w8, #0x2c8818c                             
02c88188: bl      #0x2b70f30                                 fn_2b70f30
02c8818c: adrp    x20, #0x662f000                            
02c88190: ldrb    w8, [x20, #0xa75]                          
02c88194: cbnz    w8, #0x2c881ac                             
02c88198: adrp    x0, #0x6264000                             
02c8819c: ldr     x0, [x0, #0x798]                           T:UnityEngine.Rect
02c881a0: bl      #0x2b70db0                                 fn_2b70db0
02c881a4: mov     w8, #1                                     
02c881a8: strb    w8, [x20, #0xa75]                          
02c881ac: ldr     x0, [x19]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c881b0: ldr     w8, [x0, #0xe4]                            [62640e4]=0 f=0,0
02c881b4: cbnz    w8, #0x2c881bc                             
02c881b8: bl      #0x2b70f30                                 fn_2b70f30
02c881bc: mov     x0, sp                                     
02c881c0: mov     x1, xzr                                    
02c881c4: mov     x2, xzr                                    
02c881c8: mov     x3, xzr                                    
02c881cc: bl      #0x2ca048c                                 fn_2ca048c
02c881d0: ldp     x20, x19, [sp, #0x20]                      
02c881d4: ldr     x30, [sp, #0x10]                           
02c881d8: add     sp, sp, #0x30                              
02c881dc: ret                                                
## <Update>b__11_1(UnityEngine.Resolution x) -> string
---- NotchSolutionDebugger/<>c::<Update>b__11_1 0x2c881e0
02c881e0: sub     sp, sp, #0x20                              
02c881e4: stp     x2, x30, [sp, #8]                          
02c881e8: str     x1, [sp]                                   
02c881ec: mov     x0, sp                                     
02c881f0: mov     x1, xzr                                    
02c881f4: bl      #0x5b00154                                 UnityEngine.Resolution::ToString
02c881f8: ldr     x30, [sp, #0x10]                           
02c881fc: add     sp, sp, #0x20                              
02c88200: ret                                                
## <Update>b__11_2(System.Reflection.PropertyInfo x) -> string
---- NotchSolutionDebugger/<>c::<Update>b__11_2 0x2c88204
02c88204: stp     x30, x21, [sp, #-0x20]!                    
02c88208: stp     x20, x19, [sp, #0x10]                      
02c8820c: adrp    x20, #0x662f000                            
02c88210: mov     x19, x1                                    
02c88214: ldrb    w8, [x20, #0x959]                          
02c88218: tbnz    w8, #0, #0x2c88230                         
02c8821c: adrp    x0, #0x6264000                             
02c88220: ldr     x0, [x0, #0xf50]                           S:'{0} : {1}'
02c88224: bl      #0x2b70db0                                 fn_2b70db0
02c88228: mov     w8, #1                                     
02c8822c: strb    w8, [x20, #0x959]                          
02c88230: cbz     x19, #0x2c88280                            
02c88234: ldr     x8, [x19]                                  
02c88238: adrp    x21, #0x6264000                            
02c8823c: mov     x0, x19                                    
02c88240: ldr     x21, [x21, #0xf50]                         S:'{0} : {1}'
02c88244: ldp     x9, x1, [x8, #0x1b8]                       
02c88248: blr     x9                                         
02c8824c: mov     x20, x0                                    
02c88250: mov     x0, x19                                    
02c88254: mov     x1, xzr                                    
02c88258: mov     x2, xzr                                    
02c8825c: bl      #0x4d4fc7c                                 System.Reflection.PropertyInfo::GetValue
02c88260: ldr     x8, [x21]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c88264: mov     x1, x20                                    
02c88268: mov     x2, x0                                     
02c8826c: ldp     x20, x19, [sp, #0x10]                      
02c88270: mov     x3, xzr                                    
02c88274: mov     x0, x8                                     
02c88278: ldp     x30, x21, [sp], #0x20                      
02c8827c: b       #0x4ca7720                                 System.String::Format
02c88280: bl      #0x2b7105c                                 fn_2b7105c
#### CLASS NotchSolutionDebugger/<exportDone>d__18 parent= object
#   field <>1__state                     int                                                off=0x10 attr=1 
#   field <>2__current                   object                                             off=0x18 attr=1 
#   field <>4__this                      NotchSolutionDebugger                              off=0x20 attr=6 
## .ctor(int <>1__state) -> void
---- NotchSolutionDebugger/<exportDone>d__18::.ctor 0x2c87fa0
02c87fa0: str     x30, [sp, #-0x20]!                         
02c87fa4: stp     x20, x19, [sp, #0x10]                      
02c87fa8: mov     w19, w1                                    
02c87fac: mov     x1, xzr                                    
02c87fb0: mov     x20, x0                                    
02c87fb4: bl      #0x4e53e9c                                 System.Object::.ctor
02c87fb8: str     w19, [x20, #0x10]                          .<>1__state
02c87fbc: ldp     x20, x19, [sp, #0x10]                      
02c87fc0: ldr     x30, [sp], #0x20                           
02c87fc4: ret                                                
## System.IDisposable.Dispose() -> void
---- NotchSolutionDebugger/<exportDone>d__18::System.IDisposable.Dispose 0x2c88284
02c88284: ret                                                
## MoveNext() -> bool
---- NotchSolutionDebugger/<exportDone>d__18::MoveNext 0x2c88288
02c88288: stp     x30, x21, [sp, #-0x20]!                    
02c8828c: stp     x20, x19, [sp, #0x10]                      
02c88290: adrp    x20, #0x662f000                            
02c88294: mov     x19, x0                                    
02c88298: ldrb    w8, [x20, #0x95a]                          
02c8829c: tbnz    w8, #0, #0x2c882b4                         
02c882a0: adrp    x0, #0x6264000                             
02c882a4: ldr     x0, [x0, #0xf58]                           T:UnityEngine.WaitForSeconds
02c882a8: bl      #0x2b70db0                                 fn_2b70db0
02c882ac: mov     w8, #1                                     
02c882b0: strb    w8, [x20, #0x95a]                          
02c882b4: ldr     w21, [x19, #0x10]                          .<>1__state
02c882b8: cbz     w21, #0x2c882dc                            
02c882bc: cmp     w21, #1                                    
02c882c0: b.ne    #0x2c8831c                                 
02c882c4: ldr     x8, [x19, #0x20]                           .<>4__this
02c882c8: mov     w9, #-1                                    
02c882cc: str     w9, [x19, #0x10]                           .<>1__state
02c882d0: cbz     x8, #0x2c88330                             
02c882d4: str     wzr, [x8, #0x50]                           
02c882d8: b       #0x2c8831c                                 
02c882dc: adrp    x8, #0x6264000                             
02c882e0: mov     w9, #-1                                    
02c882e4: ldr     x8, [x8, #0xf58]                           T:UnityEngine.WaitForSeconds
02c882e8: str     w9, [x19, #0x10]                           .<>1__state
02c882ec: ldr     x0, [x8]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c882f0: bl      #0x2b7104c                                 fn_2b7104c
02c882f4: fmov    s0, #5.00000000                            
02c882f8: mov     x1, xzr                                    
02c882fc: mov     x20, x0                                    
02c88300: bl      #0x5b3e5e8                                 UnityEngine.WaitForSeconds::.ctor
02c88304: mov     x0, x19                                    
02c88308: mov     x1, x20                                    
02c8830c: str     x20, [x0, #0x18]!                          .<>2__current
02c88310: bl      #0x2b70d54                                 fn_2b70d54
02c88314: mov     w8, #1                                     
02c88318: str     w8, [x19, #0x10]                           .<>1__state
02c8831c: ldp     x20, x19, [sp, #0x10]                      
02c88320: cmp     w21, #0                                    
02c88324: cset    w0, eq                                     
02c88328: ldp     x30, x21, [sp], #0x20                      
02c8832c: ret                                                
02c88330: bl      #0x2b7105c                                 fn_2b7105c
## System.Collections.Generic.IEnumerator<System.Object>.get_Current() -> object
---- NotchSolutionDebugger/<exportDone>d__18::System.Collections.Generic.IEnumerator<System.Object>.get_Current 0x2c88334
02c88334: ldr     x0, [x0, #0x18]                            .<>2__current
02c88338: ret                                                
## System.Collections.IEnumerator.Reset() -> void
---- NotchSolutionDebugger/<exportDone>d__18::System.Collections.IEnumerator.Reset 0x2c8833c
02c8833c: stp     x30, x19, [sp, #-0x10]!                    
02c88340: adrp    x0, #0x6264000                             
02c88344: ldr     x0, [x0, #0xf60]                           T:System.NotSupportedException
02c88348: bl      #0x2b70dc4                                 fn_2b70dc4
02c8834c: bl      #0x2b7104c                                 fn_2b7104c
02c88350: mov     x1, xzr                                    
02c88354: mov     x19, x0                                    
02c88358: bl      #0x4e14238                                 System.NotSupportedException::.ctor
02c8835c: adrp    x0, #0x6264000                             
02c88360: ldr     x0, [x0, #0xf68]                           M:NotchSolutionDebugger/<exportDone>d__18::System.Collections.IEnumerator.Reset
02c88364: bl      #0x2b70dc4                                 fn_2b70dc4
02c88368: mov     x1, x0                                     
02c8836c: mov     x0, x19                                    
02c88370: bl      #0x2b70f20                                 fn_2b70f20
## System.Collections.IEnumerator.get_Current() -> object
---- NotchSolutionDebugger/<exportDone>d__18::System.Collections.IEnumerator.get_Current 0x2c88374
02c88374: ldr     x0, [x0, #0x18]                            .<>2__current
02c88378: ret                                                
#### CLASS NotchSolutionDebugger/<screenData>d__17 parent= object
#   field <>1__state                     int                                                off=0x10 attr=1 
#   field <>2__current                   object                                             off=0x18 attr=1 
#   field screen                         E7.NotchSolution.ScreenData                        off=0x20 attr=6 
#   field <orientation>5__2              UnityEngine.ScreenOrientation                      off=0x28 attr=1 
#   field <i>5__3                        int                                                off=0x2c attr=1 
## .ctor(int <>1__state) -> void
---- NotchSolutionDebugger/<screenData>d__17::.ctor 0x2c87f78
02c87f78: str     x30, [sp, #-0x20]!                         
02c87f7c: stp     x20, x19, [sp, #0x10]                      
02c87f80: mov     w19, w1                                    
02c87f84: mov     x1, xzr                                    
02c87f88: mov     x20, x0                                    
02c87f8c: bl      #0x4e53e9c                                 System.Object::.ctor
02c87f90: str     w19, [x20, #0x10]                          .<>1__state
02c87f94: ldp     x20, x19, [sp, #0x10]                      
02c87f98: ldr     x30, [sp], #0x20                           
02c87f9c: ret                                                
## System.IDisposable.Dispose() -> void
---- NotchSolutionDebugger/<screenData>d__17::System.IDisposable.Dispose 0x2c8837c
02c8837c: ret                                                
## MoveNext() -> bool
---- NotchSolutionDebugger/<screenData>d__17::MoveNext 0x2c88380
02c88380: stp     x30, x21, [sp, #-0x20]!                    
02c88384: stp     x20, x19, [sp, #0x10]                      
02c88388: adrp    x20, #0x662f000                            
02c8838c: mov     x19, x0                                    
02c88390: ldrb    w8, [x20, #0x95b]                          
02c88394: tbnz    w8, #0, #0x2c883d0                         
02c88398: adrp    x0, #0x6264000                             
02c8839c: ldr     x0, [x0, #0xf70]                           MS:System.Collections.Generic.Dictionary`2::Add
02c883a0: bl      #0x2b70db0                                 fn_2b70db0
02c883a4: adrp    x0, #0x6264000                             
02c883a8: ldr     x0, [x0, #0xf78]                           MS:System.Collections.Generic.Dictionary`2::ContainsKey
02c883ac: bl      #0x2b70db0                                 fn_2b70db0
02c883b0: adrp    x0, #0x6264000                             
02c883b4: ldr     x0, [x0, #0xf80]                           T:E7.NotchSolution.OrientationDependentData
02c883b8: bl      #0x2b70db0                                 fn_2b70db0
02c883bc: adrp    x0, #0x6264000                             
02c883c0: ldr     x0, [x0, #0xf58]                           T:UnityEngine.WaitForSeconds
02c883c4: bl      #0x2b70db0                                 fn_2b70db0
02c883c8: mov     w8, #1                                     
02c883cc: strb    w8, [x20, #0x95b]                          
02c883d0: ldr     w8, [x19, #0x10]                           .<>1__state
02c883d4: cmp     w8, #1                                     
02c883d8: b.eq    #0x2c88400                                 
02c883dc: cbnz    w8, #0x2c8851c                             
02c883e0: mov     w8, #-1                                    
02c883e4: mov     x0, xzr                                    
02c883e8: str     w8, [x19, #0x10]                           .<>1__state
02c883ec: bl      #0x5afb7d8                                 UnityEngine.Screen::get_orientation
02c883f0: mov     w8, w0                                     
02c883f4: mov     w0, #1                                     
02c883f8: stp     w8, w0, [x19, #0x28]                       .<orientation>5__2
02c883fc: b       #0x2c884cc                                 
02c88400: ldr     x8, [x19, #0x20]                           .screen
02c88404: mov     w9, #-1                                    
02c88408: str     w9, [x19, #0x10]                           .<>1__state
02c8840c: cbz     x8, #0x2c8852c                             
02c88410: ldr     x20, [x8, #0x20]                           
02c88414: mov     x0, xzr                                    
02c88418: bl      #0x5afb7d8                                 UnityEngine.Screen::get_orientation
02c8841c: cbz     x20, #0x2c8852c                            
02c88420: adrp    x8, #0x6264000                             
02c88424: mov     w1, w0                                     
02c88428: mov     x0, x20                                    
02c8842c: ldr     x8, [x8, #0xf78]                           MS:System.Collections.Generic.Dictionary`2::ContainsKey
02c88430: ldr     x2, [x8]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c88434: bl      #0x44ec5e4                                 fn_44ec5e4
02c88438: tbnz    w0, #0, #0x2c884b8                         
02c8843c: adrp    x8, #0x6264000                             
02c88440: ldr     x8, [x8, #0xf80]                           T:E7.NotchSolution.OrientationDependentData
02c88444: ldr     x0, [x8]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c88448: bl      #0x2b7104c                                 fn_2b7104c
02c8844c: mov     x1, xzr                                    
02c88450: mov     x20, x0                                    
02c88454: bl      #0x2d7eac0                                 E7.NotchSolution.OrientationDependentData::.ctor
02c88458: mov     x0, xzr                                    
02c8845c: bl      #0x5afb940                                 UnityEngine.Screen::get_safeArea
02c88460: cbz     x20, #0x2c8852c                            
02c88464: mov     x0, xzr                                    
02c88468: stp     s0, s1, [x20, #0x10]                       .<>1__state
02c8846c: stp     s2, s3, [x20, #0x18]                       .<>2__current
02c88470: bl      #0x5afb9c4                                 UnityEngine.Screen::get_cutouts
02c88474: mov     x1, x0                                     
02c88478: mov     x0, x20                                    
02c8847c: str     x1, [x0, #0x20]!                           .screen
02c88480: bl      #0x2b70d54                                 fn_2b70d54
02c88484: ldr     x8, [x19, #0x20]                           .screen
02c88488: cbz     x8, #0x2c8852c                             
02c8848c: ldr     x21, [x8, #0x20]                           T:DG.Tweening.DOTweenModulePhysics/<>c__DisplayClass0_0
02c88490: mov     x0, xzr                                    
02c88494: bl      #0x5afb7d8                                 UnityEngine.Screen::get_orientation
02c88498: cbz     x21, #0x2c8852c                            
02c8849c: adrp    x8, #0x6264000                             
02c884a0: mov     w1, w0                                     
02c884a4: mov     x0, x21                                    
02c884a8: ldr     x8, [x8, #0xf70]                           MS:System.Collections.Generic.Dictionary`2::Add
02c884ac: mov     x2, x20                                    
02c884b0: ldr     x3, [x8]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c884b4: bl      #0x44ec3f0                                 fn_44ec3f0
02c884b8: ldr     w8, [x19, #0x2c]                           .<i>5__3
02c884bc: add     w0, w8, #1                                 
02c884c0: cmp     w0, #5                                     
02c884c4: str     w0, [x19, #0x2c]                           .<i>5__3
02c884c8: b.ge    #0x2c88510                                 
02c884cc: mov     x1, xzr                                    
02c884d0: bl      #0x5afb800                                 UnityEngine.Screen::set_orientation
02c884d4: adrp    x8, #0x6264000                             
02c884d8: ldr     x8, [x8, #0xf58]                           T:UnityEngine.WaitForSeconds
02c884dc: ldr     x0, [x8]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c884e0: bl      #0x2b7104c                                 fn_2b7104c
02c884e4: fmov    s0, #1.00000000                            
02c884e8: mov     x1, xzr                                    
02c884ec: mov     x20, x0                                    
02c884f0: bl      #0x5b3e5e8                                 UnityEngine.WaitForSeconds::.ctor
02c884f4: str     x20, [x19, #0x18]!                         .<>2__current
02c884f8: mov     x0, x19                                    
02c884fc: mov     x1, x20                                    
02c88500: bl      #0x2b70d54                                 fn_2b70d54
02c88504: mov     w0, #1                                     
02c88508: stur    w0, [x19, #-8]                             
02c8850c: b       #0x2c88520                                 
02c88510: ldr     w0, [x19, #0x28]                           .<orientation>5__2
02c88514: mov     x1, xzr                                    
02c88518: bl      #0x5afb800                                 UnityEngine.Screen::set_orientation
02c8851c: mov     w0, wzr                                    
02c88520: ldp     x20, x19, [sp, #0x10]                      
02c88524: ldp     x30, x21, [sp], #0x20                      
02c88528: ret                                                
02c8852c: bl      #0x2b7105c                                 fn_2b7105c
## System.Collections.Generic.IEnumerator<System.Object>.get_Current() -> object
---- NotchSolutionDebugger/<screenData>d__17::System.Collections.Generic.IEnumerator<System.Object>.get_Current 0x2c88530
02c88530: ldr     x0, [x0, #0x18]                            .<>2__current
02c88534: ret                                                
## System.Collections.IEnumerator.Reset() -> void
---- NotchSolutionDebugger/<screenData>d__17::System.Collections.IEnumerator.Reset 0x2c88538
02c88538: stp     x30, x19, [sp, #-0x10]!                    
02c8853c: adrp    x0, #0x6264000                             
02c88540: ldr     x0, [x0, #0xf60]                           T:System.NotSupportedException
02c88544: bl      #0x2b70dc4                                 fn_2b70dc4
02c88548: bl      #0x2b7104c                                 fn_2b7104c
02c8854c: mov     x1, xzr                                    
02c88550: mov     x19, x0                                    
02c88554: bl      #0x4e14238                                 System.NotSupportedException::.ctor
02c88558: adrp    x0, #0x6264000                             
02c8855c: ldr     x0, [x0, #0xf88]                           M:NotchSolutionDebugger/<screenData>d__17::System.Collections.IEnumerator.Reset
02c88560: bl      #0x2b70dc4                                 fn_2b70dc4
02c88564: mov     x1, x0                                     
02c88568: mov     x0, x19                                    
02c8856c: bl      #0x2b70f20                                 fn_2b70f20
## System.Collections.IEnumerator.get_Current() -> object
---- NotchSolutionDebugger/<screenData>d__17::System.Collections.IEnumerator.get_Current 0x2c88570
02c88570: ldr     x0, [x0, #0x18]                            .<>2__current
02c88574: ret                                                
#### CLASS NotchSolutionDebugger parent= UnityEngine.MonoBehaviour
#   field debugText                      UnityEngine.UI.Text                                off=0x20 attr=6 
#   field debugRectPrefab                UnityEngine.GameObject                             off=0x28 attr=6 
#   field rootRect                       UnityEngine.RectTransform                          off=0x30 attr=6 
#   field export                         UnityEngine.Transform                              off=0x38 attr=6 
#   field sb                             System.Text.StringBuilder                          off=0x40 attr=1 
#   field device                         E7.NotchSolution.SimulationDevice                  off=0x48 attr=6 
#   field menu                           NotchSolutionDebugger/Menu                         off=0x50 attr=6 
#   field storedSimulatedSafeAreaRelative UnityEngine.Rect                                   off=0x54 attr=1 
#   field storedSimulatedCutoutsRelative UnityEngine.Rect[]                                 off=0x68 attr=1 
#   field debugRects                     System.Collections.Generic.List`1<DebugRect>       off=0x70 attr=1 
## SimulatorUpdate(UnityEngine.Rect simulatedSafeAreaRelative, UnityEngine.Rect[] simulatedCutoutsRelative) -> void
---- NotchSolutionDebugger::SimulatorUpdate 0x2c869d8
02c869d8: str     x1, [x0, #0x68]!                           .storedSimulatedCutoutsRelative
02c869dc: stp     s0, s1, [x0, #-0x14]                       
02c869e0: stp     s2, s3, [x0, #-0xc]                        
02c869e4: b       #0x2b70d54                                 
## Update() -> void
---- NotchSolutionDebugger::Update 0x2c869e8
02c869e8: sub     sp, sp, #0x90                              
02c869ec: stp     d11, d10, [sp, #0x20]                      
02c869f0: stp     d9, d8, [sp, #0x30]                        
02c869f4: stp     x30, x27, [sp, #0x40]                      
02c869f8: stp     x26, x25, [sp, #0x50]                      
02c869fc: stp     x24, x23, [sp, #0x60]                      
02c86a00: stp     x22, x21, [sp, #0x70]                      
02c86a04: stp     x20, x19, [sp, #0x80]                      
02c86a08: adrp    x20, #0x662f000                            
02c86a0c: mov     x19, x0                                    
02c86a10: ldrb    w8, [x20, #0x94f]                          
02c86a14: tbnz    w8, #0, #0x2c86bc4                         
02c86a18: adrp    x0, #0x6264000                             
02c86a1c: ldr     x0, [x0, #0xa70]                           T:UnityEngine.Application
02c86a20: bl      #0x2b70db0                                 fn_2b70db0
02c86a24: adrp    x0, #0x6264000                             
02c86a28: ldr     x0, [x0, #0xd98]                           MS:System.Collections.Generic.Dictionary`2::get_Count
02c86a2c: bl      #0x2b70db0                                 fn_2b70db0
02c86a30: adrp    x0, #0x6264000                             
02c86a34: ldr     x0, [x0, #0xda0]                           MS:System.Linq.Enumerable::FirstOrDefault
02c86a38: bl      #0x2b70db0                                 fn_2b70db0
02c86a3c: adrp    x0, #0x6264000                             
02c86a40: ldr     x0, [x0, #0xda8]                           MS:System.Linq.Enumerable::Select
02c86a44: bl      #0x2b70db0                                 fn_2b70db0
02c86a48: adrp    x0, #0x6264000                             
02c86a4c: ldr     x0, [x0, #0xdb0]                           MS:System.Linq.Enumerable::Select
02c86a50: bl      #0x2b70db0                                 fn_2b70db0
02c86a54: adrp    x0, #0x6264000                             
02c86a58: ldr     x0, [x0, #0xdb8]                           MS:System.Linq.Enumerable::Select
02c86a5c: bl      #0x2b70db0                                 fn_2b70db0
02c86a60: adrp    x0, #0x6264000                             
02c86a64: ldr     x0, [x0, #0xdc0]                           T:type55633(k15)
02c86a68: bl      #0x2b70db0                                 fn_2b70db0
02c86a6c: adrp    x0, #0x6264000                             
02c86a70: ldr     x0, [x0, #0xdc8]                           T:type55635(k15)
02c86a74: bl      #0x2b70db0                                 fn_2b70db0
02c86a78: adrp    x0, #0x6264000                             
02c86a7c: ldr     x0, [x0, #0xdd0]                           T:type55637(k15)
02c86a80: bl      #0x2b70db0                                 fn_2b70db0
02c86a84: adrp    x0, #0x6264000                             
02c86a88: ldr     x0, [x0, #0xdd8]                           T:E7.NotchSolution.NotchSolutionUtility
02c86a8c: bl      #0x2b70db0                                 fn_2b70db0
02c86a90: adrp    x0, #0x6263000                             
02c86a94: ldr     x0, [x0, #0xa80]                           T:type24502(k1d)
02c86a98: bl      #0x2b70db0                                 fn_2b70db0
02c86a9c: adrp    x0, #0x6264000                             
02c86aa0: ldr     x0, [x0, #0x798]                           T:UnityEngine.Rect
02c86aa4: bl      #0x2b70db0                                 fn_2b70db0
02c86aa8: adrp    x0, #0x6264000                             
02c86aac: ldr     x0, [x0, #0xde0]                           T:UnityEngine.Resolution
02c86ab0: bl      #0x2b70db0                                 fn_2b70db0
02c86ab4: adrp    x0, #0x6264000                             
02c86ab8: ldr     x0, [x0, #0xde8]                           T:UnityEngine.ScreenOrientation
02c86abc: bl      #0x2b70db0                                 fn_2b70db0
02c86ac0: adrp    x0, #0x6264000                             
02c86ac4: ldr     x0, [x0, #0xdf0]                           T:UnityEngine.SystemInfo
02c86ac8: bl      #0x2b70db0                                 fn_2b70db0
02c86acc: adrp    x0, #0x6264000                             
02c86ad0: ldr     x0, [x0, #0xdf8]                           M:NotchSolutionDebugger/<>c::<Update>b__11_0
02c86ad4: bl      #0x2b70db0                                 fn_2b70db0
02c86ad8: adrp    x0, #0x6264000                             
02c86adc: ldr     x0, [x0, #0xe00]                           M:NotchSolutionDebugger/<>c::<Update>b__11_1
02c86ae0: bl      #0x2b70db0                                 fn_2b70db0
02c86ae4: adrp    x0, #0x6264000                             
02c86ae8: ldr     x0, [x0, #0xe08]                           M:NotchSolutionDebugger/<>c::<Update>b__11_2
02c86aec: bl      #0x2b70db0                                 fn_2b70db0
02c86af0: adrp    x0, #0x6264000                             
02c86af4: ldr     x0, [x0, #0xe10]                           T:NotchSolutionDebugger/<>c
02c86af8: bl      #0x2b70db0                                 fn_2b70db0
02c86afc: adrp    x0, #0x6264000                             
02c86b00: ldr     x0, [x0, #0xe18]                           S:'\n'
02c86b04: bl      #0x2b70db0                                 fn_2b70db0
02c86b08: adrp    x0, #0x6264000                             
02c86b0c: ldr     x0, [x0, #0xe20]                           S:'<b>Done</b>'
02c86b10: bl      #0x2b70db0                                 fn_2b70db0
02c86b14: adrp    x0, #0x6264000                             
02c86b18: ldr     x0, [x0, #0xe28]                           S:'DPI : {0} WxH : {1}x{2} Orientation : {3}\n'
02c86b1c: bl      #0x2b70db0                                 fn_2b70db0
02c86b20: adrp    x0, #0x6264000                             
02c86b24: ldr     x0, [x0, #0xe30]                           S:"<b>-- PLEASE ROTATE THE DEVICE TO GET BOTH ORIENTATION'S DETAILS! --</"
02c86b28: bl      #0x2b70db0                                 fn_2b70db0
02c86b2c: adrp    x0, #0x6264000                             
02c86b30: ldr     x0, [x0, #0xe38]                           S:' \n'
02c86b34: bl      #0x2b70db0                                 fn_2b70db0
02c86b38: adrp    x0, #0x6264000                             
02c86b3c: ldr     x0, [x0, #0xe40]                           S:'Extracting...'
02c86b40: bl      #0x2b70db0                                 fn_2b70db0
02c86b44: adrp    x0, #0x6264000                             
02c86b48: ldr     x0, [x0, #0xe48]                           S:'/'
02c86b4c: bl      #0x2b70db0                                 fn_2b70db0
02c86b50: adrp    x0, #0x6264000                             
02c86b54: ldr     x0, [x0, #0xe50]                           S:' / '
02c86b58: bl      #0x2b70db0                                 fn_2b70db0
02c86b5c: adrp    x0, #0x6264000                             
02c86b60: ldr     x0, [x0, #0xe58]                           S:'All Resolutions : '
02c86b64: bl      #0x2b70db0                                 fn_2b70db0
02c86b68: adrp    x0, #0x6264000                             
02c86b6c: ldr     x0, [x0, #0xe60]                           S:'Current resolution : {0}\n'
02c86b70: bl      #0x2b70db0                                 fn_2b70db0
02c86b74: adrp    x0, #0x6264000                             
02c86b78: ldr     x0, [x0, #0xe68]                           S:'Safe area : {0}\n'
02c86b7c: bl      #0x2b70db0                                 fn_2b70db0
02c86b80: adrp    x0, #0x6263000                             
02c86b84: ldr     x0, [x0, #0xa90]                           S:''
02c86b88: bl      #0x2b70db0                                 fn_2b70db0
02c86b8c: adrp    x0, #0x6264000                             
02c86b90: ldr     x0, [x0, #0xe70]                           S:'.device.json'
02c86b94: bl      #0x2b70db0                                 fn_2b70db0
02c86b98: adrp    x0, #0x6264000                             
02c86b9c: ldr     x0, [x0, #0xe78]                           S:'Cutouts : '
02c86ba0: bl      #0x2b70db0                                 fn_2b70db0
02c86ba4: adrp    x0, #0x6264000                             
02c86ba8: ldr     x0, [x0, #0xe80]                           S:'File saved at <i>'
02c86bac: bl      #0x2b70db0                                 fn_2b70db0
02c86bb0: adrp    x0, #0x6264000                             
02c86bb4: ldr     x0, [x0, #0xe88]                           S:'</i>'
02c86bb8: bl      #0x2b70db0                                 fn_2b70db0
02c86bbc: mov     w8, #1                                     
02c86bc0: strb    w8, [x20, #0x94f]                          
02c86bc4: ldr     x0, [x19, #0x40]                           .sb
02c86bc8: cbz     x0, #0x2c8750c                             
02c86bcc: mov     x1, xzr                                    
02c86bd0: bl      #0x4cb05c4                                 System.Text.StringBuilder::Clear
02c86bd4: mov     x0, x19                                    
02c86bd8: bl      #0x2c8751c                                 NotchSolutionDebugger::ClearRects
02c86bdc: ldr     w8, [x19, #0x50]                           .menu
02c86be0: cmp     w8, #1                                     
02c86be4: b.eq    #0x2c86c58                                 
02c86be8: cbnz    w8, #0x2c874b0                             
02c86bec: ldr     x0, [x19, #0x38]                           .export
02c86bf0: cbz     x0, #0x2c8750c                             
02c86bf4: mov     x1, xzr                                    
02c86bf8: bl      #0x5b339ec                                 UnityEngine.Component::get_gameObject
02c86bfc: cbz     x0, #0x2c8750c                             
02c86c00: mov     w1, #1                                     
02c86c04: mov     x2, xzr                                    
02c86c08: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02c86c0c: ldr     x0, [x19, #0x40]                           .sb
02c86c10: cbz     x0, #0x2c8750c                             
02c86c14: adrp    x8, #0x6264000                             
02c86c18: mov     x2, xzr                                    
02c86c1c: ldr     x8, [x8, #0xe30]                           S:"<b>-- PLEASE ROTATE THE DEVICE TO GET BOTH ORIENTATION'S DETAILS! --</"
02c86c20: ldr     x1, [x8]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c86c24: bl      #0x4cb13f0                                 System.Text.StringBuilder::AppendLine
02c86c28: adrp    x21, #0x6264000                            
02c86c2c: ldr     x21, [x21, #0xdd8]                         T:E7.NotchSolution.NotchSolutionUtility
02c86c30: ldr     x0, [x21]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c86c34: ldr     w8, [x0, #0xe4]                            [62640e4]=0 f=0,0
02c86c38: cbnz    w8, #0x2c86c40                             
02c86c3c: bl      #0x2b70f30                                 fn_2b70f30
02c86c40: mov     x0, xzr                                    
02c86c44: bl      #0x2d7de30                                 E7.NotchSolution.NotchSolutionUtility::get_ShouldUseNotchSimulatorValue
02c86c48: tbz     w0, #0, #0x2c86dc8                         
02c86c4c: ldp     s0, s1, [x19, #0x54]                       .storedSimulatedSafeAreaRelative
02c86c50: ldp     s2, s3, [x19, #0x5c]                       
02c86c54: b       #0x2c86de0                                 
02c86c58: ldr     x8, [x19, #0x48]                           .device
02c86c5c: cbz     x8, #0x2c8750c                             
02c86c60: adrp    x9, #0x6264000                             
02c86c64: ldr     x9, [x9, #0xda0]                           MS:System.Linq.Enumerable::FirstOrDefault
02c86c68: ldr     x0, [x8, #0x18]                            M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass2_0::<DOSetFloat>b__1
02c86c6c: ldr     x1, [x9]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c86c70: bl      #0x318b9c4                                 fn_318b9c4
02c86c74: ldr     x8, [x19, #0x38]                           .export
02c86c78: cbz     x8, #0x2c8750c                             
02c86c7c: mov     x20, x0                                    
02c86c80: mov     x0, x8                                     
02c86c84: mov     x1, xzr                                    
02c86c88: bl      #0x5b339ec                                 UnityEngine.Component::get_gameObject
02c86c8c: cbz     x0, #0x2c8750c                             
02c86c90: mov     w1, wzr                                    
02c86c94: mov     x2, xzr                                    
02c86c98: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02c86c9c: cbz     x20, #0x2c8750c                            
02c86ca0: ldr     x0, [x20, #0x20]                           &2b706f0(=d65f03c0f9400800) .debugText
02c86ca4: cbz     x0, #0x2c8750c                             
02c86ca8: adrp    x8, #0x6264000                             
02c86cac: ldr     x8, [x8, #0xd98]                           MS:System.Collections.Generic.Dictionary`2::get_Count
02c86cb0: ldr     x1, [x8]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c86cb4: bl      #0x44ec088                                 fn_44ec088
02c86cb8: cmp     w0, #4                                     
02c86cbc: b.ne    #0x2c87494                                 
02c86cc0: adrp    x8, #0x6264000                             
02c86cc4: ldr     x8, [x8, #0xa70]                           T:UnityEngine.Application
02c86cc8: ldr     x0, [x8]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c86ccc: ldr     w8, [x0, #0xe4]                            [62640e4]=0 f=0,0
02c86cd0: cbnz    w8, #0x2c86cd8                             
02c86cd4: bl      #0x2b70f30                                 fn_2b70f30
02c86cd8: mov     x0, xzr                                    
02c86cdc: bl      #0x5aea748                                 UnityEngine.Application::get_persistentDataPath
02c86ce0: ldr     x8, [x19, #0x48]                           .device
02c86ce4: cbz     x8, #0x2c8750c                             
02c86ce8: ldr     x8, [x8, #0x10]                            M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass2_0::<DOSetFloat>b__0
02c86cec: cbz     x8, #0x2c8750c                             
02c86cf0: adrp    x9, #0x6264000                             
02c86cf4: adrp    x10, #0x6264000                            
02c86cf8: mov     x4, xzr                                    
02c86cfc: ldr     x9, [x9, #0xe48]                           S:'/'
02c86d00: ldr     x10, [x10, #0xe70]                         S:'.device.json'
02c86d04: ldr     x2, [x8, #0x10]                            M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass2_0::<DOSetFloat>b__0
02c86d08: ldr     x1, [x9]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c86d0c: ldr     x3, [x10]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c86d10: bl      #0x4ca7320                                 System.String::Concat
02c86d14: ldr     x8, [x19, #0x48]                           .device
02c86d18: mov     x20, x0                                    
02c86d1c: mov     x1, xzr                                    
02c86d20: mov     x0, x8                                     
02c86d24: bl      #0x5bba258                                 UnityEngine.JsonUtility::ToJson
02c86d28: mov     x1, x0                                     
02c86d2c: mov     x0, x20                                    
02c86d30: mov     x2, xzr                                    
02c86d34: bl      #0x4dd9e7c                                 System.IO.File::WriteAllText
02c86d38: ldr     x0, [x19, #0x40]                           .sb
02c86d3c: cbz     x0, #0x2c8750c                             
02c86d40: adrp    x8, #0x6264000                             
02c86d44: mov     x2, xzr                                    
02c86d48: ldr     x8, [x8, #0xe20]                           S:'<b>Done</b>'
02c86d4c: ldr     x1, [x8]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c86d50: bl      #0x4cb13f0                                 System.Text.StringBuilder::AppendLine
02c86d54: ldr     x0, [x19, #0x40]                           .sb
02c86d58: cbz     x0, #0x2c8750c                             
02c86d5c: adrp    x8, #0x6263000                             
02c86d60: mov     x2, xzr                                    
02c86d64: ldr     x8, [x8, #0xa90]                           S:''
02c86d68: ldr     x1, [x8]                                   &2c5bbd4(=a9bd7bfdd503233f)
02c86d6c: bl      #0x4cb13f0                                 System.Text.StringBuilder::AppendLine
02c86d70: adrp    x8, #0x6264000                             
02c86d74: adrp    x9, #0x6264000                             
02c86d78: mov     x1, x20                                    
02c86d7c: ldr     x8, [x8, #0xe80]                           S:'File saved at <i>'
02c86d80: ldr     x9, [x9, #0xe88]                           S:'</i>'
02c86d84: ldr     x21, [x19, #0x40]                          .sb
02c86d88: mov     x3, xzr                                    
02c86d8c: ldr     x0, [x8]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c86d90: ldr     x2, [x9]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c86d94: bl      #0x4ca6dbc                                 System.String::Concat
02c86d98: cbz     x21, #0x2c8750c                            
02c86d9c: mov     x1, x0                                     
02c86da0: mov     x0, x21                                    
02c86da4: mov     x2, xzr                                    
02c86da8: bl      #0x4cb13f0                                 System.Text.StringBuilder::AppendLine
02c86dac: mov     x0, x19                                    
02c86db0: bl      #0x2c87968                                 NotchSolutionDebugger::exportDone
02c86db4: mov     x1, x0                                     
02c86db8: mov     x0, x19                                    
02c86dbc: mov     x2, xzr                                    
02c86dc0: bl      #0x5b389f0                                 UnityEngine.MonoBehaviour::StartCoroutine
02c86dc4: b       #0x2c874b0                                 
02c86dc8: ldr     x0, [x21]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c86dcc: ldr     w8, [x0, #0xe4]                            [62640e4]=0 f=0,0
02c86dd0: cbnz    w8, #0x2c86dd8                             
02c86dd4: bl      #0x2b70f30                                 fn_2b70f30
02c86dd8: mov     x0, xzr                                    
02c86ddc: bl      #0x2d7de38                                 E7.NotchSolution.NotchSolutionUtility::get_ScreenSafeAreaRelative
02c86de0: bl      #0x2c876b8                                 NotchSolutionDebugger::RelativeToReal
02c86de4: movi    d5, #0000000000000000                      
02c86de8: movi    d6, #0000000000000000                      
02c86dec: mov     x0, x19                                    
02c86df0: fmov    s4, #1.00000000                            
02c86df4: fmov    s7, #1.00000000                            
02c86df8: fmov    s10, s0                                    
02c86dfc: fmov    s11, s1                                    
02c86e00: fmov    s8, s2                                     
02c86e04: fmov    s9, s3                                     
02c86e08: bl      #0x2c87770                                 NotchSolutionDebugger::PlaceRect
02c86e0c: mov     x0, xzr                                    
02c86e10: bl      #0x5afb7d8                                 UnityEngine.Screen::get_orientation
02c86e14: ldr     x8, [x21]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c86e18: mov     w20, w0                                    
02c86e1c: ldr     w9, [x8, #0xe4]                            [62640e4]=0 f=0,0
02c86e20: cbnz    w9, #0x2c86e2c                             
02c86e24: mov     x0, x8                                     
02c86e28: bl      #0x2b70f30                                 fn_2b70f30
02c86e2c: mov     x0, xzr                                    
02c86e30: bl      #0x2d7da34                                 E7.NotchSolution.NotchSolutionUtility::GetCurrentOrientation
02c86e34: cmp     w20, w0                                    
02c86e38: b.eq    #0x2c86e7c                                 
02c86e3c: mov     x0, xzr                                    
02c86e40: bl      #0x5afb6fc                                 UnityEngine.Screen::get_width
02c86e44: adrp    x8, #0x6264000                             
02c86e48: mov     w20, w0                                    
02c86e4c: ldr     x8, [x8, #0x798]                           T:UnityEngine.Rect
02c86e50: ldr     x8, [x8]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c86e54: ldr     w9, [x8, #0xe4]                            [62640e4]=0 f=0,0
02c86e58: cbnz    w9, #0x2c86e64                             
02c86e5c: mov     x0, x8                                     
02c86e60: bl      #0x2b70f30                                 fn_2b70f30
02c86e64: mov     x0, xzr                                    
02c86e68: bl      #0x5afb724                                 UnityEngine.Screen::get_height
02c86e6c: scvtf   s0, w20                                    
02c86e70: scvtf   s1, w0                                     
02c86e74: fsub    s10, s0, s10                               
02c86e78: fsub    s11, s1, s11                               
02c86e7c: adrp    x22, #0x6264000                            
02c86e80: add     x1, sp, #0x10                              
02c86e84: ldr     x22, [x22, #0x798]                         T:UnityEngine.Rect
02c86e88: ldr     x20, [x19, #0x40]                          .sb
02c86e8c: stp     s10, s11, [sp, #0x10]                      
02c86e90: stp     s8, s9, [sp, #0x18]                        
02c86e94: ldr     x0, [x22]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c86e98: bl      #0x2b70f38                                 fn_2b70f38
02c86e9c: adrp    x8, #0x6264000                             
02c86ea0: mov     x1, x0                                     
02c86ea4: mov     x2, xzr                                    
02c86ea8: ldr     x8, [x8, #0xe68]                           S:'Safe area : {0}\n'
02c86eac: ldr     x8, [x8]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c86eb0: mov     x0, x8                                     
02c86eb4: bl      #0x4c9d0ec                                 System.String::Format
02c86eb8: cbz     x20, #0x2c8750c                            
02c86ebc: mov     x1, x0                                     
02c86ec0: mov     x0, x20                                    
02c86ec4: mov     x2, xzr                                    
02c86ec8: bl      #0x4cb13f0                                 System.Text.StringBuilder::AppendLine
02c86ecc: mov     x0, xzr                                    
02c86ed0: bl      #0x5afb9c4                                 UnityEngine.Screen::get_cutouts
02c86ed4: cbz     x0, #0x2c8750c                             
02c86ed8: ldr     x8, [x0, #0x18]                            M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass2_0::<DOSetFloat>b__1
02c86edc: mov     x20, x0                                    
02c86ee0: cmp     w8, #1                                     
02c86ee4: b.lt    #0x2c86f30                                 
02c86ee8: mov     x23, xzr                                   
02c86eec: and     x8, x8, #0xffffffff                        
02c86ef0: add     x24, x20, #0x2c                            &662f02c
02c86ef4: cmp     x23, w8, uxtw                              
02c86ef8: b.hs    #0x2c87508                                 
02c86efc: movi    d4, #0000000000000000                      
02c86f00: movi    d5, #0000000000000000                      
02c86f04: mov     x0, x19                                    
02c86f08: ldp     s0, s1, [x24, #-0xc]                       
02c86f0c: fmov    s6, #1.00000000                            
02c86f10: ldp     s2, s3, [x24, #-4]                         
02c86f14: fmov    s7, #1.00000000                            
02c86f18: bl      #0x2c87770                                 NotchSolutionDebugger::PlaceRect
02c86f1c: ldr     w8, [x20, #0x18]                           [662f018]=6000014 f=2.40742e-35,0
02c86f20: add     x23, x23, #1                               
02c86f24: add     x24, x24, #0x10                            
02c86f28: cmp     x23, w8, sxtw                              
02c86f2c: b.lt    #0x2c86ef4                                 
02c86f30: mov     x0, xzr                                    
02c86f34: bl      #0x5afb7d8                                 UnityEngine.Screen::get_orientation
02c86f38: ldr     x8, [x21]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c86f3c: mov     w21, w0                                    
02c86f40: ldr     w9, [x8, #0xe4]                            [62640e4]=0 f=0,0
02c86f44: cbnz    w9, #0x2c86f50                             
02c86f48: mov     x0, x8                                     
02c86f4c: bl      #0x2b70f30                                 fn_2b70f30
02c86f50: mov     x0, xzr                                    
02c86f54: bl      #0x2d7da34                                 E7.NotchSolution.NotchSolutionUtility::GetCurrentOrientation
02c86f58: cmp     w21, w0                                    
02c86f5c: b.eq    #0x2c86fa8                                 
02c86f60: ldr     w8, [x20, #0x18]                           [662f018]=6000014 f=2.40742e-35,0
02c86f64: cmp     w8, #1                                     
02c86f68: b.lt    #0x2c86fa8                                 
02c86f6c: mov     w21, wzr                                   
02c86f70: cmp     w21, w8                                    
02c86f74: b.hs    #0x2c87508                                 
02c86f78: mov     x0, xzr                                    
02c86f7c: bl      #0x5afb6fc                                 UnityEngine.Screen::get_width
02c86f80: ldr     x0, [x22]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c86f84: ldr     w8, [x0, #0xe4]                            [62640e4]=0 f=0,0
02c86f88: cbnz    w8, #0x2c86f90                             
02c86f8c: bl      #0x2b70f30                                 fn_2b70f30
02c86f90: mov     x0, xzr                                    
02c86f94: bl      #0x5afb724                                 UnityEngine.Screen::get_height
02c86f98: ldr     w8, [x20, #0x18]                           [662f018]=6000014 f=2.40742e-35,0
02c86f9c: add     w21, w21, #1                               
02c86fa0: cmp     w21, w8                                    
02c86fa4: b.lt    #0x2c86f70                                 
02c86fa8: adrp    x26, #0x6264000                            
02c86fac: ldr     x26, [x26, #0xe10]                         T:NotchSolutionDebugger/<>c
02c86fb0: ldr     x21, [x19, #0x40]                          .sb
02c86fb4: ldr     x0, [x26]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c86fb8: ldr     w8, [x0, #0xe4]                            [62640e4]=0 f=0,0
02c86fbc: cbnz    w8, #0x2c86fc8                             
02c86fc0: bl      #0x2b70f30                                 fn_2b70f30
02c86fc4: ldr     x0, [x26]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c86fc8: adrp    x27, #0x6264000                            
02c86fcc: adrp    x9, #0x6264000                             
02c86fd0: ldr     x8, [x0, #0xb8]                            MS:DG.Tweening.Core.Extensions::SetSpecialStartupMode
02c86fd4: ldr     x27, [x27, #0xe50]                         S:' / '
02c86fd8: ldr     x9, [x9, #0xe78]                           S:'Cutouts : '
02c86fdc: ldr     x24, [x8, #8]                              T:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass2_0
02c86fe0: ldr     x23, [x27]                                 M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c86fe4: ldr     x22, [x9]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c86fe8: cbnz    x24, #0x2c87044                            
02c86fec: ldr     w9, [x0, #0xe4]                            [62640e4]=0 f=0,0
02c86ff0: cbnz    w9, #0x2c87000                             
02c86ff4: bl      #0x2b70f30                                 fn_2b70f30
02c86ff8: ldr     x8, [x26]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c86ffc: ldr     x8, [x8, #0xb8]                            MS:DG.Tweening.Core.Extensions::SetSpecialStartupMode
02c87000: adrp    x9, #0x6264000                             
02c87004: ldr     x9, [x9, #0xdc8]                           T:type55635(k15)
02c87008: ldr     x25, [x8]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c8700c: ldr     x0, [x9]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c87010: bl      #0x2b7104c                                 fn_2b7104c
02c87014: adrp    x8, #0x6264000                             
02c87018: mov     x1, x25                                    
02c8701c: mov     x3, xzr                                    
02c87020: ldr     x8, [x8, #0xdf8]                           M:NotchSolutionDebugger/<>c::<Update>b__11_0
02c87024: mov     x24, x0                                    
02c87028: ldr     x2, [x8]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c8702c: bl      #0x4942b50                                 fn_4942b50
02c87030: ldr     x8, [x26]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c87034: mov     x1, x24                                    
02c87038: ldr     x0, [x8, #0xb8]                            MS:DG.Tweening.Core.Extensions::SetSpecialStartupMode
02c8703c: str     x24, [x0, #8]!                             
02c87040: bl      #0x2b70d54                                 fn_2b70d54
02c87044: adrp    x8, #0x6264000                             
02c87048: mov     x0, x20                                    
02c8704c: mov     x1, x24                                    
02c87050: ldr     x8, [x8, #0xdb0]                           MS:System.Linq.Enumerable::Select
02c87054: ldr     x2, [x8]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c87058: bl      #0x3193ea0                                 fn_3193ea0
02c8705c: mov     x1, x0                                     
02c87060: mov     x0, x23                                    
02c87064: mov     x2, xzr                                    
02c87068: bl      #0x4ca7bdc                                 System.String::Join
02c8706c: adrp    x8, #0x6264000                             
02c87070: mov     x1, x0                                     
02c87074: mov     x0, x22                                    
02c87078: ldr     x8, [x8, #0xe38]                           S:' \n'
02c8707c: mov     x3, xzr                                    
02c87080: ldr     x2, [x8]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c87084: bl      #0x4ca6dbc                                 System.String::Concat
02c87088: cbz     x21, #0x2c8750c                            
02c8708c: mov     x1, x0                                     
02c87090: mov     x0, x21                                    
02c87094: mov     x2, xzr                                    
02c87098: bl      #0x4cb13f0                                 System.Text.StringBuilder::AppendLine
02c8709c: ldr     x20, [x19, #0x40]                          .sb
02c870a0: mov     x0, xzr                                    
02c870a4: bl      #0x5afb898                                 UnityEngine.Screen::get_currentResolution
02c870a8: adrp    x8, #0x6264000                             
02c870ac: ldr     x8, [x8, #0xde0]                           T:UnityEngine.Resolution
02c870b0: stp     x0, x1, [sp, #0x10]                        
02c870b4: add     x1, sp, #0x10                              
02c870b8: ldr     x8, [x8]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c870bc: mov     x0, x8                                     
02c870c0: bl      #0x2b70f38                                 fn_2b70f38
02c870c4: adrp    x8, #0x6264000                             
02c870c8: mov     x1, x0                                     
02c870cc: mov     x2, xzr                                    
02c870d0: ldr     x8, [x8, #0xe60]                           S:'Current resolution : {0}\n'
02c870d4: ldr     x8, [x8]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c870d8: mov     x0, x8                                     
02c870dc: bl      #0x4c9d0ec                                 System.String::Format
02c870e0: cbz     x20, #0x2c8750c                            
02c870e4: mov     x1, x0                                     
02c870e8: mov     x0, x20                                    
02c870ec: mov     x2, xzr                                    
02c870f0: bl      #0x4cb13f0                                 System.Text.StringBuilder::AppendLine
02c870f4: ldr     x20, [x19, #0x40]                          .sb
02c870f8: mov     x0, xzr                                    
02c870fc: bl      #0x5afbb9c                                 UnityEngine.Screen::get_resolutions
02c87100: ldr     x8, [x26]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c87104: mov     x21, x0                                    
02c87108: ldr     w9, [x8, #0xe4]                            [62640e4]=0 f=0,0
02c8710c: cbnz    w9, #0x2c8711c                             
02c87110: mov     x0, x8                                     
02c87114: bl      #0x2b70f30                                 fn_2b70f30
02c87118: ldr     x8, [x26]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c8711c: adrp    x10, #0x6264000                            
02c87120: ldr     x9, [x8, #0xb8]                            MS:DG.Tweening.Core.Extensions::SetSpecialStartupMode
02c87124: ldr     x10, [x10, #0xe58]                         S:'All Resolutions : '
02c87128: ldr     x23, [x27]                                 M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c8712c: ldr     x24, [x9, #0x10]                           M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass2_0::<DOSetFloat>b__0
02c87130: ldr     x22, [x10]                                 M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c87134: cbnz    x24, #0x2c87194                            
02c87138: ldr     w10, [x8, #0xe4]                           [62640e4]=0 f=0,0
02c8713c: cbnz    w10, #0x2c87150                            
02c87140: mov     x0, x8                                     
02c87144: bl      #0x2b70f30                                 fn_2b70f30
02c87148: ldr     x8, [x26]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c8714c: ldr     x9, [x8, #0xb8]                            MS:DG.Tweening.Core.Extensions::SetSpecialStartupMode
02c87150: adrp    x8, #0x6264000                             
02c87154: ldr     x8, [x8, #0xdd0]                           T:type55637(k15)
02c87158: ldr     x25, [x9]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c8715c: ldr     x0, [x8]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c87160: bl      #0x2b7104c                                 fn_2b7104c
02c87164: adrp    x8, #0x6264000                             
02c87168: mov     x1, x25                                    
02c8716c: mov     x3, xzr                                    
02c87170: ldr     x8, [x8, #0xe00]                           M:NotchSolutionDebugger/<>c::<Update>b__11_1
02c87174: mov     x24, x0                                    
02c87178: ldr     x2, [x8]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c8717c: bl      #0x49431a4                                 fn_49431a4
02c87180: ldr     x8, [x26]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c87184: mov     x1, x24                                    
02c87188: ldr     x0, [x8, #0xb8]                            MS:DG.Tweening.Core.Extensions::SetSpecialStartupMode
02c8718c: str     x24, [x0, #0x10]!                          
02c87190: bl      #0x2b70d54                                 fn_2b70d54
02c87194: adrp    x8, #0x6264000                             
02c87198: mov     x0, x21                                    
02c8719c: mov     x1, x24                                    
02c871a0: ldr     x8, [x8, #0xdb8]                           MS:System.Linq.Enumerable::Select
02c871a4: ldr     x2, [x8]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c871a8: bl      #0x31941c4                                 fn_31941c4
02c871ac: mov     x1, x0                                     
02c871b0: mov     x0, x23                                    
02c871b4: mov     x2, xzr                                    
02c871b8: bl      #0x4ca7bdc                                 System.String::Join
02c871bc: adrp    x8, #0x6264000                             
02c871c0: mov     x1, x0                                     
02c871c4: mov     x0, x22                                    
02c871c8: ldr     x8, [x8, #0xe18]                           S:'\n'
02c871cc: mov     x3, xzr                                    
02c871d0: ldr     x2, [x8]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c871d4: bl      #0x4ca6dbc                                 System.String::Concat
02c871d8: cbz     x20, #0x2c8750c                            
02c871dc: mov     x1, x0                                     
02c871e0: mov     x0, x20                                    
02c871e4: mov     x2, xzr                                    
02c871e8: bl      #0x4cb13f0                                 System.Text.StringBuilder::AppendLine
02c871ec: adrp    x8, #0x6263000                             
02c871f0: mov     w1, #4                                     
02c871f4: ldr     x8, [x8, #0xa80]                           T:type24502(k1d)
02c871f8: ldr     x20, [x19, #0x40]                          .sb
02c871fc: ldr     x0, [x8]                                   &2c5bbd4(=a9bd7bfdd503233f)
02c87200: bl      #0x2b70ea0                                 fn_2b70ea0
02c87204: mov     x21, x0                                    
02c87208: mov     x0, xzr                                    
02c8720c: bl      #0x5afb74c                                 UnityEngine.Screen::get_dpi
02c87210: adrp    x23, #0x6263000                            
02c87214: add     x1, sp, #0x10                              
02c87218: ldr     x23, [x23, #0x970]                         &6645c70(=0)
02c8721c: str     s0, [sp, #0x10]                            
02c87220: ldr     x0, [x23, #0x78]                           &2c498b4(=d65f03c0d503245f)
02c87224: bl      #0x2b70f38                                 fn_2b70f38
02c87228: cbz     x21, #0x2c8750c                            
02c8722c: mov     x22, x0                                    
02c87230: cbz     x0, #0x2c87248                             
02c87234: ldr     x8, [x21]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c87238: mov     x0, x22                                    
02c8723c: ldr     x1, [x8, #0x40]                            [6263040]=0 f=0,0
02c87240: bl      #0x2b70f34                                 fn_2b70f34
02c87244: cbz     x0, #0x2c87510                             
02c87248: ldr     w8, [x21, #0x18]                           M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass2_0::<DOSetFloat>b__1
02c8724c: cbz     w8, #0x2c87508                             
02c87250: mov     x0, x21                                    
02c87254: mov     x1, x22                                    
02c87258: str     x22, [x0, #0x20]!                          .debugText
02c8725c: bl      #0x2b70d54                                 fn_2b70d54
02c87260: mov     x0, xzr                                    
02c87264: bl      #0x5afb6fc                                 UnityEngine.Screen::get_width
02c87268: ldr     x8, [x23, #0x48]                           &6263098(=0)
02c8726c: str     w0, [sp, #0xc]                             
02c87270: add     x1, sp, #0xc                               
02c87274: mov     x0, x8                                     
02c87278: bl      #0x2b70f38                                 fn_2b70f38
02c8727c: mov     x22, x0                                    
02c87280: cbz     x0, #0x2c87298                             
02c87284: ldr     x8, [x21]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c87288: mov     x0, x22                                    
02c8728c: ldr     x1, [x8, #0x40]                            [6263040]=0 f=0,0
02c87290: bl      #0x2b70f34                                 fn_2b70f34
02c87294: cbz     x0, #0x2c87510                             
02c87298: ldr     w8, [x21, #0x18]                           M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass2_0::<DOSetFloat>b__1
02c8729c: tst     w8, #0xfffffffe                            
02c872a0: b.eq    #0x2c87508                                 
02c872a4: mov     x0, x21                                    
02c872a8: mov     x1, x22                                    
02c872ac: str     x22, [x0, #0x28]!                          .debugRectPrefab
02c872b0: bl      #0x2b70d54                                 fn_2b70d54
02c872b4: mov     x0, xzr                                    
02c872b8: bl      #0x5afb724                                 UnityEngine.Screen::get_height
02c872bc: ldr     x8, [x23, #0x48]                           &6263098(=0)
02c872c0: str     w0, [sp, #8]                               
02c872c4: add     x1, sp, #8                                 
02c872c8: mov     x0, x8                                     
02c872cc: bl      #0x2b70f38                                 fn_2b70f38
02c872d0: mov     x22, x0                                    
02c872d4: cbz     x0, #0x2c872ec                             
02c872d8: ldr     x8, [x21]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c872dc: mov     x0, x22                                    
02c872e0: ldr     x1, [x8, #0x40]                            [6263040]=0 f=0,0
02c872e4: bl      #0x2b70f34                                 fn_2b70f34
02c872e8: cbz     x0, #0x2c87510                             
02c872ec: ldr     w8, [x21, #0x18]                           M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass2_0::<DOSetFloat>b__1
02c872f0: cmp     w8, #2                                     
02c872f4: b.ls    #0x2c87508                                 
02c872f8: mov     x0, x21                                    
02c872fc: mov     x1, x22                                    
02c87300: str     x22, [x0, #0x30]!                          .rootRect
02c87304: bl      #0x2b70d54                                 fn_2b70d54
02c87308: mov     x0, xzr                                    
02c8730c: bl      #0x5afb7d8                                 UnityEngine.Screen::get_orientation
02c87310: adrp    x8, #0x6264000                             
02c87314: add     x1, sp, #4                                 
02c87318: ldr     x8, [x8, #0xde8]                           T:UnityEngine.ScreenOrientation
02c8731c: str     w0, [sp, #4]                               
02c87320: ldr     x8, [x8]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c87324: mov     x0, x8                                     
02c87328: bl      #0x2b70f38                                 fn_2b70f38
02c8732c: mov     x22, x0                                    
02c87330: cbz     x0, #0x2c87348                             
02c87334: ldr     x8, [x21]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c87338: mov     x0, x22                                    
02c8733c: ldr     x1, [x8, #0x40]                            MS:DG.Tweening.TweenSettingsExtensions::SetTarget
02c87340: bl      #0x2b70f34                                 fn_2b70f34
02c87344: cbz     x0, #0x2c87510                             
02c87348: ldr     w8, [x21, #0x18]                           M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass2_0::<DOSetFloat>b__1
02c8734c: tst     w8, #0xfffffffc                            
02c87350: b.eq    #0x2c87508                                 
02c87354: mov     x0, x21                                    
02c87358: mov     x1, x22                                    
02c8735c: str     x22, [x0, #0x38]!                          .export
02c87360: bl      #0x2b70d54                                 fn_2b70d54
02c87364: adrp    x8, #0x6264000                             
02c87368: mov     x1, x21                                    
02c8736c: mov     x2, xzr                                    
02c87370: ldr     x8, [x8, #0xe28]                           S:'DPI : {0} WxH : {1}x{2} Orientation : {3}\n'
02c87374: ldr     x0, [x8]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c87378: bl      #0x4ca77a8                                 System.String::Format
02c8737c: cbz     x20, #0x2c8750c                            
02c87380: mov     x1, x0                                     
02c87384: mov     x0, x20                                    
02c87388: mov     x2, xzr                                    
02c8738c: bl      #0x4cb13f0                                 System.Text.StringBuilder::AppendLine
02c87390: adrp    x8, #0x6264000                             
02c87394: ldr     x0, [x23, #0xe0]                           &2c5bf4c(=a9be7bfdd503233f)
02c87398: ldr     x8, [x8, #0xdf0]                           T:UnityEngine.SystemInfo
02c8739c: ldr     w9, [x0, #0xe4]                            [62640e4]=0 f=0,0
02c873a0: ldr     x20, [x8]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c873a4: cbnz    w9, #0x2c873ac                             
02c873a8: bl      #0x2b70f30                                 fn_2b70f30
02c873ac: mov     x0, x20                                    
02c873b0: mov     x1, xzr                                    
02c873b4: bl      #0x4e20e5c                                 System.Type::GetTypeFromHandle
02c873b8: cbz     x0, #0x2c8750c                             
02c873bc: ldr     x8, [x0]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c873c0: mov     w1, #0x18                                  
02c873c4: ldr     x9, [x8, #0x868]                           MS:System.Runtime.CompilerServices.AsyncTaskMethodBuilder::AwaitUnsafeOnCompleted
02c873c8: ldr     x2, [x8, #0x870]                           MS:System.Runtime.CompilerServices.AsyncTaskMethodBuilder::AwaitUnsafeOnCompleted
02c873cc: blr     x9                                         
02c873d0: ldr     x8, [x26]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c873d4: mov     x20, x0                                    
02c873d8: ldr     w9, [x8, #0xe4]                            [62640e4]=0 f=0,0
02c873dc: cbnz    w9, #0x2c873ec                             
02c873e0: mov     x0, x8                                     
02c873e4: bl      #0x2b70f30                                 fn_2b70f30
02c873e8: ldr     x8, [x26]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c873ec: ldr     x9, [x8, #0xb8]                            MS:DG.Tweening.Core.Extensions::SetSpecialStartupMode
02c873f0: ldr     x21, [x27]                                 M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c873f4: ldr     x22, [x9, #0x18]                           M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass2_0::<DOSetFloat>b__1
02c873f8: cbnz    x22, #0x2c87458                            
02c873fc: ldr     w10, [x8, #0xe4]                           [62640e4]=0 f=0,0
02c87400: cbnz    w10, #0x2c87414                            
02c87404: mov     x0, x8                                     
02c87408: bl      #0x2b70f30                                 fn_2b70f30
02c8740c: ldr     x8, [x26]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c87410: ldr     x9, [x8, #0xb8]                            MS:DG.Tweening.Core.Extensions::SetSpecialStartupMode
02c87414: adrp    x8, #0x6264000                             
02c87418: ldr     x8, [x8, #0xdc0]                           T:type55633(k15)
02c8741c: ldr     x23, [x9]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c87420: ldr     x0, [x8]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c87424: bl      #0x2b7104c                                 fn_2b7104c
02c87428: adrp    x8, #0x6264000                             
02c8742c: mov     x1, x23                                    
02c87430: mov     x3, xzr                                    
02c87434: ldr     x8, [x8, #0xe08]                           M:NotchSolutionDebugger/<>c::<Update>b__11_2
02c87438: mov     x22, x0                                    
02c8743c: ldr     x2, [x8]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c87440: bl      #0x49416f4                                 fn_49416f4
02c87444: ldr     x8, [x26]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c87448: mov     x1, x22                                    
02c8744c: ldr     x0, [x8, #0xb8]                            MS:DG.Tweening.Core.Extensions::SetSpecialStartupMode
02c87450: str     x22, [x0, #0x18]!                          
02c87454: bl      #0x2b70d54                                 fn_2b70d54
02c87458: adrp    x8, #0x6264000                             
02c8745c: mov     x0, x20                                    
02c87460: mov     x1, x22                                    
02c87464: ldr     x8, [x8, #0xda8]                           MS:System.Linq.Enumerable::Select
02c87468: ldr     x2, [x8]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c8746c: bl      #0x3193858                                 fn_3193858
02c87470: mov     x1, x0                                     
02c87474: mov     x0, x21                                    
02c87478: mov     x2, xzr                                    
02c8747c: bl      #0x4ca7bdc                                 System.String::Join
02c87480: ldr     x8, [x19, #0x40]                           .sb
02c87484: cbz     x8, #0x2c8750c                             
02c87488: mov     x1, x0                                     
02c8748c: mov     x0, x8                                     
02c87490: b       #0x2c874a8                                 
02c87494: ldr     x0, [x19, #0x40]                           .sb
02c87498: cbz     x0, #0x2c8750c                             
02c8749c: adrp    x8, #0x6264000                             
02c874a0: ldr     x8, [x8, #0xe40]                           S:'Extracting...'
02c874a4: ldr     x1, [x8]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c874a8: mov     x2, xzr                                    
02c874ac: bl      #0x4cb13f0                                 System.Text.StringBuilder::AppendLine
02c874b0: ldr     x0, [x19, #0x40]                           .sb
02c874b4: cbz     x0, #0x2c8750c                             
02c874b8: ldr     x8, [x0]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c874bc: ldr     x19, [x19, #0x20]                          .debugText
02c874c0: ldp     x9, x1, [x8, #0x168]                       
02c874c4: blr     x9                                         
02c874c8: cbz     x19, #0x2c8750c                            
02c874cc: ldr     x8, [x19]                                  
02c874d0: mov     x1, x0                                     
02c874d4: mov     x0, x19                                    
02c874d8: ldr     x9, [x8, #0x5e8]                           T:DG.Tweening.DOTweenModuleUI/<>c__DisplayClass29_0
02c874dc: ldr     x2, [x8, #0x5f0]                           MS:DG.Tweening.TweenSettingsExtensions::OnUpdate
02c874e0: blr     x9                                         
02c874e4: ldp     x20, x19, [sp, #0x80]                      
02c874e8: ldp     x22, x21, [sp, #0x70]                      
02c874ec: ldp     x24, x23, [sp, #0x60]                      
02c874f0: ldp     x26, x25, [sp, #0x50]                      
02c874f4: ldp     x30, x27, [sp, #0x40]                      
02c874f8: ldp     d9, d8, [sp, #0x30]                        
02c874fc: ldp     d11, d10, [sp, #0x20]                      
02c87500: add     sp, sp, #0x90                              
02c87504: ret                                                
02c87508: bl      #0x2b71064                                 fn_2b71064
02c8750c: bl      #0x2b7105c                                 fn_2b7105c
02c87510: bl      #0x2b71080                                 fn_2b71080
02c87514: mov     x1, xzr                                    
02c87518: bl      #0x2b70f20                                 fn_2b70f20
## RelativeToReal(UnityEngine.Rect relative) -> UnityEngine.Rect
---- NotchSolutionDebugger::RelativeToReal 0x2c876b8
02c876b8: stp     d11, d10, [sp, #-0x40]!                    
02c876bc: stp     d9, d8, [sp, #0x10]                        
02c876c0: stp     x30, x21, [sp, #0x20]                      
02c876c4: stp     x20, x19, [sp, #0x30]                      
02c876c8: fmov    s8, s3                                     
02c876cc: fmov    s9, s2                                     
02c876d0: adrp    x19, #0x662f000                            
02c876d4: fmov    s10, s1                                    
02c876d8: fmov    s11, s0                                    
02c876dc: adrp    x20, #0x6264000                            
02c876e0: ldrb    w8, [x19, #0x950]                          
02c876e4: ldr     x20, [x20, #0x798]                         T:UnityEngine.Rect
02c876e8: tbnz    w8, #0, #0x2c87700                         
02c876ec: adrp    x0, #0x6264000                             
02c876f0: ldr     x0, [x0, #0x798]                           T:UnityEngine.Rect
02c876f4: bl      #0x2b70db0                                 fn_2b70db0
02c876f8: mov     w8, #1                                     
02c876fc: strb    w8, [x19, #0x950]                          
02c87700: ldr     x0, [x20]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c87704: ldr     w8, [x0, #0xe4]                            [62640e4]=0 f=0,0
02c87708: cbnz    w8, #0x2c87710                             
02c8770c: bl      #0x2b70f30                                 fn_2b70f30
02c87710: mov     x0, xzr                                    
02c87714: bl      #0x5afb6fc                                 UnityEngine.Screen::get_width
02c87718: mov     w19, w0                                    
02c8771c: mov     x0, xzr                                    
02c87720: bl      #0x5afb724                                 UnityEngine.Screen::get_height
02c87724: mov     w20, w0                                    
02c87728: mov     x0, xzr                                    
02c8772c: bl      #0x5afb6fc                                 UnityEngine.Screen::get_width
02c87730: mov     w21, w0                                    
02c87734: mov     x0, xzr                                    
02c87738: bl      #0x5afb724                                 UnityEngine.Screen::get_height
02c8773c: scvtf   s2, w21                                    
02c87740: scvtf   s3, w0                                     
02c87744: scvtf   s0, w19                                    
02c87748: scvtf   s1, w20                                    
02c8774c: ldp     x20, x19, [sp, #0x30]                      
02c87750: ldp     x30, x21, [sp, #0x20]                      
02c87754: fmul    s2, s9, s2                                 
02c87758: fmul    s3, s8, s3                                 
02c8775c: ldp     d9, d8, [sp, #0x10]                        
02c87760: fmul    s0, s11, s0                                
02c87764: fmul    s1, s10, s1                                
02c87768: ldp     d11, d10, [sp], #0x40                      
02c8776c: ret                                                
## ClearRects() -> void
---- NotchSolutionDebugger::ClearRects 0x2c8751c
02c8751c: sub     sp, sp, #0x60                              
02c87520: stp     x30, x23, [sp, #0x30]                      
02c87524: stp     x22, x21, [sp, #0x40]                      
02c87528: stp     x20, x19, [sp, #0x50]                      
02c8752c: adrp    x20, #0x662f000                            
02c87530: mov     x19, x0                                    
02c87534: ldrb    w8, [x20, #0x951]                          
02c87538: tbnz    w8, #0, #0x2c8758c                         
02c8753c: adrp    x0, #0x6264000                             
02c87540: ldr     x0, [x0, #0xe90]                           MS:System.Collections.Generic.List`1/Enumerator::Dispose
02c87544: bl      #0x2b70db0                                 fn_2b70db0
02c87548: adrp    x0, #0x6264000                             
02c8754c: ldr     x0, [x0, #0xe98]                           MS:System.Collections.Generic.List`1/Enumerator::MoveNext
02c87550: bl      #0x2b70db0                                 fn_2b70db0
02c87554: adrp    x0, #0x6264000                             
02c87558: ldr     x0, [x0, #0xea0]                           MS:System.Collections.Generic.List`1/Enumerator::get_Current
02c8755c: bl      #0x2b70db0                                 fn_2b70db0
02c87560: adrp    x0, #0x6264000                             
02c87564: ldr     x0, [x0, #0xea8]                           MS:System.Collections.Generic.List`1::Clear
02c87568: bl      #0x2b70db0                                 fn_2b70db0
02c8756c: adrp    x0, #0x6264000                             
02c87570: ldr     x0, [x0, #0xeb0]                           MS:System.Collections.Generic.List`1::GetEnumerator
02c87574: bl      #0x2b70db0                                 fn_2b70db0
02c87578: adrp    x0, #0x6263000                             
02c8757c: ldr     x0, [x0, #0x918]                           T:UnityEngine.Object
02c87580: bl      #0x2b70db0                                 fn_2b70db0
02c87584: mov     w8, #1                                     
02c87588: strb    w8, [x20, #0x951]                          
02c8758c: ldr     x0, [x19, #0x70]                           .debugRects
02c87590: stp     xzr, xzr, [sp, #0x18]                      
02c87594: str     xzr, [sp, #0x28]                           
02c87598: cbz     x0, #0x2c87664                             
02c8759c: adrp    x8, #0x6264000                             
02c875a0: adrp    x22, #0x6264000                            
02c875a4: adrp    x23, #0x6263000                            
02c875a8: ldr     x8, [x8, #0xeb0]                           MS:System.Collections.Generic.List`1::GetEnumerator
02c875ac: adrp    x21, #0x6264000                            
02c875b0: ldr     x22, [x22, #0xe98]                         MS:System.Collections.Generic.List`1/Enumerator::MoveNext
02c875b4: ldr     x23, [x23, #0x918]                         T:UnityEngine.Object
02c875b8: ldr     x21, [x21, #0xe90]                         MS:System.Collections.Generic.List`1/Enumerator::Dispose
02c875bc: add     x20, sp, #0x18                             
02c875c0: ldr     x1, [x8]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c875c4: add     x8, sp, #0x18                              
02c875c8: bl      #0x35a9d9c                                 fn_35a9d9c
02c875cc: stp     xzr, x20, [sp, #8]                         
02c875d0: ldr     x1, [x22]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c875d4: add     x0, sp, #0x18                              
02c875d8: bl      #0x4690474                                 fn_4690474
02c875dc: tbz     w0, #0, #0x2c87614                         
02c875e0: ldr     x0, [sp, #0x28]                            
02c875e4: cbz     x0, #0x2c87660                             
02c875e8: mov     x1, xzr                                    
02c875ec: bl      #0x5b339ec                                 UnityEngine.Component::get_gameObject
02c875f0: mov     x20, x0                                    
02c875f4: ldr     x0, [x23]                                  &2c5bbd4(=a9bd7bfdd503233f)
02c875f8: ldr     w8, [x0, #0xe4]                            [62630e4]=0 f=0,0
02c875fc: cbnz    w8, #0x2c87604                             
02c87600: bl      #0x2b70f30                                 fn_2b70f30
02c87604: mov     x0, x20                                    
02c87608: mov     x1, xzr                                    
02c8760c: bl      #0x5b3ca38                                 UnityEngine.Object::Destroy
02c87610: b       #0x2c875d0                                 
02c87614: ldr     x1, [x21]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c87618: add     x0, sp, #0x18                              
02c8761c: bl      #0x4690470                                 fn_4690470
02c87620: ldr     x8, [x19, #0x70]                           .debugRects
02c87624: cbz     x8, #0x2c87664                             
02c87628: ldp     w2, w9, [x8, #0x18]                        
02c8762c: add     w9, w9, #1                                 
02c87630: cmp     w2, #1                                     
02c87634: stp     wzr, w9, [x8, #0x18]                       
02c87638: b.lt    #0x2c8764c                                 
02c8763c: ldr     x0, [x8, #0x10]                            M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass2_0::<DOSetFloat>b__0
02c87640: mov     w1, wzr                                    
02c87644: mov     x3, xzr                                    
02c87648: bl      #0x4e3494c                                 System.Array::Clear
02c8764c: ldp     x20, x19, [sp, #0x50]                      
02c87650: ldp     x22, x21, [sp, #0x40]                      
02c87654: ldp     x30, x23, [sp, #0x30]                      
02c87658: add     sp, sp, #0x60                              
02c8765c: ret                                                
02c87660: bl      #0x2b7105c                                 fn_2b7105c
02c87664: bl      #0x2b7105c                                 fn_2b7105c
02c87668: b       #0x2c87670                                 
02c8766c: b       #0x2c87670                                 
02c87670: cmp     w1, #1                                     
02c87674: b.ne    #0x2c876a0                                 
02c87678: bl      #0x5e90260                                 fn_5e90260
02c8767c: ldr     x20, [x0]                                  &2c5bbd4(=a9bd7bfdd503233f)
02c87680: str     x20, [sp, #8]                              
02c87684: bl      #0x5e90270                                 fn_5e90270
02c87688: ldr     x0, [sp, #0x10]                            
02c8768c: ldr     x1, [x21]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c87690: bl      #0x4690470                                 fn_4690470
02c87694: cbz     x20, #0x2c87620                            
02c87698: mov     x0, x20                                    
02c8769c: bl      #0x2b71054                                 fn_2b71054
02c876a0: mov     x19, x0                                    
02c876a4: add     x0, sp, #8                                 
02c876a8: bl      #0x2736e00                                 fn_2736e00
02c876ac: mov     x0, x19                                    
02c876b0: bl      #0x2c6051c                                 fn_2c6051c
02c876b4: bl      #0x27369b8                                 fn_27369b8
## PlaceRect(UnityEngine.Rect rct, UnityEngine.Color c) -> void
---- NotchSolutionDebugger::PlaceRect 0x2c87770
02c87770: stp     d15, d14, [sp, #-0x70]!                    
02c87774: stp     d13, d12, [sp, #0x10]                      
02c87778: stp     d11, d10, [sp, #0x20]                      
02c8777c: stp     d9, d8, [sp, #0x30]                        
02c87780: str     x30, [sp, #0x40]                           
02c87784: stp     x22, x21, [sp, #0x50]                      
02c87788: stp     x20, x19, [sp, #0x60]                      
02c8778c: fmov    s8, s7                                     
02c87790: fmov    s9, s6                                     
02c87794: adrp    x21, #0x662f000                            
02c87798: fmov    s10, s5                                    
02c8779c: fmov    s11, s4                                    
02c877a0: adrp    x20, #0x6263000                            
02c877a4: fmov    s12, s3                                    
02c877a8: fmov    s13, s2                                    
02c877ac: ldrb    w8, [x21, #0x952]                          
02c877b0: fmov    s14, s1                                    
02c877b4: fmov    s15, s0                                    
02c877b8: ldr     x20, [x20, #0x918]                         T:UnityEngine.Object
02c877bc: mov     x19, x0                                    
02c877c0: tbnz    w8, #0, #0x2c877fc                         
02c877c4: adrp    x0, #0x6264000                             
02c877c8: ldr     x0, [x0, #0xeb8]                           MS:UnityEngine.GameObject::GetComponent
02c877cc: bl      #0x2b70db0                                 fn_2b70db0
02c877d0: adrp    x0, #0x6264000                             
02c877d4: ldr     x0, [x0, #0xec0]                           MS:System.Collections.Generic.List`1::Add
02c877d8: bl      #0x2b70db0                                 fn_2b70db0
02c877dc: adrp    x0, #0x6264000                             
02c877e0: ldr     x0, [x0, #0xec8]                           MS:UnityEngine.Object::Instantiate
02c877e4: bl      #0x2b70db0                                 fn_2b70db0
02c877e8: adrp    x0, #0x6263000                             
02c877ec: ldr     x0, [x0, #0x918]                           T:UnityEngine.Object
02c877f0: bl      #0x2b70db0                                 fn_2b70db0
02c877f4: mov     w8, #1                                     
02c877f8: strb    w8, [x21, #0x952]                          
02c877fc: ldr     x0, [x20]                                  &2c5bbd4(=a9bd7bfdd503233f)
02c87800: adrp    x22, #0x6264000                            
02c87804: ldr     x22, [x22, #0xec8]                         MS:UnityEngine.Object::Instantiate
02c87808: ldp     x20, x21, [x19, #0x28]                     .debugRectPrefab
02c8780c: ldr     w8, [x0, #0xe4]                            [62630e4]=0 f=0,0
02c87810: cbnz    w8, #0x2c87818                             
02c87814: bl      #0x2b70f30                                 fn_2b70f30
02c87818: ldr     x2, [x22]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c8781c: mov     x0, x20                                    
02c87820: mov     x1, x21                                    
02c87824: bl      #0x3275fcc                                 fn_3275fcc
02c87828: cbz     x0, #0x2c87964                             
02c8782c: mov     x1, xzr                                    
02c87830: mov     x20, x0                                    
02c87834: bl      #0x5b368f0                                 UnityEngine.GameObject::get_transform
02c87838: adrp    x22, #0x662f000                            
02c8783c: mov     x21, x0                                    
02c87840: ldrb    w8, [x22, #0xa74]                          
02c87844: cbnz    w8, #0x2c8785c                             
02c87848: adrp    x0, #0x6264000                             
02c8784c: ldr     x0, [x0, #0xd8]                            T:UnityEngine.Vector3
02c87850: bl      #0x2b70db0                                 fn_2b70db0
02c87854: mov     w8, #1                                     
02c87858: strb    w8, [x22, #0xa74]                          
02c8785c: cbz     x21, #0x2c87964                            
02c87860: adrp    x8, #0x6264000                             
02c87864: adrp    x22, #0x6264000                            
02c87868: mov     x0, x21                                    
02c8786c: ldr     x8, [x8, #0xd8]                            T:UnityEngine.Vector3
02c87870: mov     x1, xzr                                    
02c87874: ldr     x8, [x8]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c87878: ldr     x8, [x8, #0xb8]                            MS:DG.Tweening.Core.Extensions::SetSpecialStartupMode
02c8787c: ldr     x22, [x22, #0xeb8]                         MS:UnityEngine.GameObject::GetComponent
02c87880: ldp     s1, s2, [x8, #0x10]                        
02c87884: ldr     s0, [x8, #0xc]                             [626400c]=0 f=0,0
02c87888: bl      #0x5b470cc                                 UnityEngine.Transform::set_localScale
02c8788c: ldr     x1, [x22]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c87890: mov     x0, x20                                    
02c87894: bl      #0x31d11a4                                 fn_31d11a4
02c87898: cbz     x0, #0x2c87964                             
02c8789c: fmov    s0, s15                                    
02c878a0: fmov    s1, s14                                    
02c878a4: mov     x20, x0                                    
02c878a8: fmov    s2, s13                                    
02c878ac: fmov    s3, s12                                    
02c878b0: fmov    s4, s11                                    
02c878b4: fmov    s5, s10                                    
02c878b8: fmov    s6, s9                                     
02c878bc: fmov    s7, s8                                     
02c878c0: bl      #0x2c8675c                                 DebugRect::PlaceItselfAtScreenRect
02c878c4: ldr     x8, [x19, #0x70]                           .debugRects
02c878c8: cbz     x8, #0x2c87964                             
02c878cc: adrp    x10, #0x6264000                            
02c878d0: ldr     x10, [x10, #0xec0]                         MS:System.Collections.Generic.List`1::Add
02c878d4: ldr     w11, [x8, #0x1c]                           [626401c]=0 f=0,0
02c878d8: ldr     x9, [x8, #0x10]                            M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass2_0::<DOSetFloat>b__0
02c878dc: ldr     x10, [x10]                                 M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c878e0: add     w11, w11, #1                               
02c878e4: str     w11, [x8, #0x1c]                           
02c878e8: cbz     x9, #0x2c87964                             
02c878ec: ldrsw   x11, [x8, #0x18]                           
02c878f0: ldr     w12, [x9, #0x18]                           
02c878f4: cmp     w11, w12                                   
02c878f8: b.hs    #0x2c87930                                 
02c878fc: add     x0, x9, x11, lsl #3                        
02c87900: mov     x1, x20                                    
02c87904: add     w9, w11, #1                                
02c87908: ldp     x22, x21, [sp, #0x50]                      
02c8790c: ldr     x30, [sp, #0x40]                           
02c87910: str     x20, [x0, #0x20]!                          .debugText
02c87914: ldp     x20, x19, [sp, #0x60]                      
02c87918: str     w9, [x8, #0x18]                            
02c8791c: ldp     d9, d8, [sp, #0x30]                        
02c87920: ldp     d11, d10, [sp, #0x20]                      
02c87924: ldp     d13, d12, [sp, #0x10]                      
02c87928: ldp     d15, d14, [sp], #0x70                      
02c8792c: b       #0x2b70d54                                 
02c87930: ldr     x9, [x10, #0x20]                           T:DG.Tweening.DOTweenModulePhysics/<>c__DisplayClass0_0
02c87934: mov     x1, x20                                    
02c87938: ldr     x30, [sp, #0x40]                           
02c8793c: ldp     x20, x19, [sp, #0x60]                      
02c87940: mov     x0, x8                                     
02c87944: ldr     x9, [x9, #0xc0]                            
02c87948: ldp     x22, x21, [sp, #0x50]                      
02c8794c: ldp     d9, d8, [sp, #0x30]                        
02c87950: ldp     d11, d10, [sp, #0x20]                      
02c87954: ldr     x2, [x9, #0x70]                            
02c87958: ldp     d13, d12, [sp, #0x10]                      
02c8795c: ldp     d15, d14, [sp], #0x70                      
02c87960: b       #0x35a920c                                 
02c87964: bl      #0x2b7105c                                 fn_2b7105c
## Export() -> void
---- NotchSolutionDebugger::Export 0x2c879d4
02c879d4: str     x30, [sp, #-0x60]!                         
02c879d8: stp     x28, x27, [sp, #0x10]                      
02c879dc: stp     x26, x25, [sp, #0x20]                      
02c879e0: stp     x24, x23, [sp, #0x30]                      
02c879e4: stp     x22, x21, [sp, #0x40]                      
02c879e8: stp     x20, x19, [sp, #0x50]                      
02c879ec: adrp    x20, #0x662f000                            
02c879f0: adrp    x21, #0x6264000                            
02c879f4: adrp    x22, #0x6264000                            
02c879f8: ldrb    w8, [x20, #0x953]                          
02c879fc: ldr     x21, [x21, #0xed8]                         T:E7.NotchSolution.SimulationDevice
02c87a00: ldr     x22, [x22, #0xee0]                         T:E7.NotchSolution.MetaData
02c87a04: mov     x19, x0                                    
02c87a08: tbnz    w8, #0, #0x2c87ab0                         
02c87a0c: adrp    x0, #0x6264000                             
02c87a10: ldr     x0, [x0, #0xee8]                           MS:UnityEngine.Component::GetComponentInChildren
02c87a14: bl      #0x2b70db0                                 fn_2b70db0
02c87a18: adrp    x0, #0x6264000                             
02c87a1c: ldr     x0, [x0, #0xef0]                           MS:System.Collections.Generic.Dictionary`2::.ctor
02c87a20: bl      #0x2b70db0                                 fn_2b70db0
02c87a24: adrp    x0, #0x6264000                             
02c87a28: ldr     x0, [x0, #0xef8]                           T:type54436(k15)
02c87a2c: bl      #0x2b70db0                                 fn_2b70db0
02c87a30: adrp    x0, #0x6264000                             
02c87a34: ldr     x0, [x0, #0xf00]                           T:type60904(k1d)
02c87a38: bl      #0x2b70db0                                 fn_2b70db0
02c87a3c: adrp    x0, #0x6264000                             
02c87a40: ldr     x0, [x0, #0xf08]                           T:E7.NotchSolution.GraphicsDependentSystemInfoData
02c87a44: bl      #0x2b70db0                                 fn_2b70db0
02c87a48: adrp    x0, #0x6264000                             
02c87a4c: ldr     x0, [x0, #0xf10]                           T:E7.NotchSolution.GraphicsDependentSystemInfoData
02c87a50: bl      #0x2b70db0                                 fn_2b70db0
02c87a54: adrp    x0, #0x6264000                             
02c87a58: ldr     x0, [x0, #0xee0]                           T:E7.NotchSolution.MetaData
02c87a5c: bl      #0x2b70db0                                 fn_2b70db0
02c87a60: adrp    x0, #0x6264000                             
02c87a64: ldr     x0, [x0, #0xf18]                           T:type60960(k1d)
02c87a68: bl      #0x2b70db0                                 fn_2b70db0
02c87a6c: adrp    x0, #0x6264000                             
02c87a70: ldr     x0, [x0, #0xf20]                           T:E7.NotchSolution.ScreenData
02c87a74: bl      #0x2b70db0                                 fn_2b70db0
02c87a78: adrp    x0, #0x6264000                             
02c87a7c: ldr     x0, [x0, #0xed8]                           T:E7.NotchSolution.SimulationDevice
02c87a80: bl      #0x2b70db0                                 fn_2b70db0
02c87a84: adrp    x0, #0x6264000                             
02c87a88: ldr     x0, [x0, #0xf28]                           T:E7.NotchSolution.SystemInfoData
02c87a8c: bl      #0x2b70db0                                 fn_2b70db0
02c87a90: adrp    x0, #0x6264000                             
02c87a94: ldr     x0, [x0, #0xf30]                           T:E7.NotchSolution.SystemInfoData
02c87a98: bl      #0x2b70db0                                 fn_2b70db0
02c87a9c: adrp    x0, #0x6264000                             
02c87aa0: ldr     x0, [x0, #0xdf0]                           T:UnityEngine.SystemInfo
02c87aa4: bl      #0x2b70db0                                 fn_2b70db0
02c87aa8: mov     w8, #1                                     
02c87aac: strb    w8, [x20, #0x953]                          
02c87ab0: ldr     x0, [x21]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c87ab4: bl      #0x2b7104c                                 fn_2b7104c
02c87ab8: mov     x1, xzr                                    
02c87abc: mov     x21, x0                                    
02c87ac0: bl      #0x2d7e8cc                                 E7.NotchSolution.SimulationDevice::.ctor
02c87ac4: mov     x20, x19                                   
02c87ac8: mov     x1, x21                                    
02c87acc: str     x21, [x20, #0x48]!                         .device
02c87ad0: mov     x0, x20                                    
02c87ad4: bl      #0x2b70d54                                 fn_2b70d54
02c87ad8: ldr     x0, [x22]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c87adc: ldr     x21, [x20]                                 &2b706c4(=eb01011ff9400808)
02c87ae0: bl      #0x2b7104c                                 fn_2b7104c
02c87ae4: mov     x1, xzr                                    
02c87ae8: mov     x22, x0                                    
02c87aec: bl      #0x2d7e8d4                                 E7.NotchSolution.MetaData::.ctor
02c87af0: cbz     x21, #0x2c87ed4                            
02c87af4: str     x22, [x21, #0x10]!                         
02c87af8: mov     x0, x21                                    
02c87afc: mov     x1, x22                                    
02c87b00: bl      #0x2b70d54                                 fn_2b70d54
02c87b04: ldr     x8, [x20]                                  &2b706c4(=eb01011ff9400808)
02c87b08: cbz     x8, #0x2c87ed4                             
02c87b0c: ldr     x0, [x19, #0x38]                           .export
02c87b10: cbz     x0, #0x2c87ed4                             
02c87b14: adrp    x9, #0x6264000                             
02c87b18: ldr     x9, [x9, #0xee8]                           MS:UnityEngine.Component::GetComponentInChildren
02c87b1c: ldr     x21, [x8, #0x10]                           
02c87b20: ldr     x1, [x9]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c87b24: bl      #0x3140e60                                 fn_3140e60
02c87b28: cbz     x0, #0x2c87ed4                             
02c87b2c: cbz     x21, #0x2c87ed4                            
02c87b30: adrp    x22, #0x6264000                            
02c87b34: adrp    x23, #0x6264000                            
02c87b38: adrp    x24, #0x6264000                            
02c87b3c: ldr     x22, [x22, #0xf30]                         T:E7.NotchSolution.SystemInfoData
02c87b40: ldr     x23, [x23, #0xf00]                         T:type60904(k1d)
02c87b44: ldr     x1, [x0, #0x180]                           T:DG.Tweening.DOTweenModulePhysics/<>c__DisplayClass8_0
02c87b48: ldr     x24, [x24, #0xf10]                         T:E7.NotchSolution.GraphicsDependentSystemInfoData
02c87b4c: str     x1, [x21, #0x10]!                          
02c87b50: mov     x0, x21                                    
02c87b54: bl      #0x2b70d54                                 fn_2b70d54
02c87b58: ldr     x0, [x22]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c87b5c: ldr     x21, [x20]                                 &2b706c4(=eb01011ff9400808)
02c87b60: bl      #0x2b7104c                                 fn_2b7104c
02c87b64: mov     x1, xzr                                    
02c87b68: mov     x22, x0                                    
02c87b6c: bl      #0x2d7eac8                                 E7.NotchSolution.SystemInfoData::.ctor
02c87b70: ldr     x0, [x23]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c87b74: mov     w1, #1                                     
02c87b78: bl      #0x2b70ea0                                 fn_2b70ea0
02c87b7c: ldr     x8, [x24]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c87b80: mov     x23, x0                                    
02c87b84: mov     x0, x8                                     
02c87b88: bl      #0x2b7104c                                 fn_2b7104c
02c87b8c: mov     x1, xzr                                    
02c87b90: mov     x24, x0                                    
02c87b94: bl      #0x2d7ead0                                 E7.NotchSolution.GraphicsDependentSystemInfoData::.ctor
02c87b98: cbz     x23, #0x2c87ed4                            
02c87b9c: cbz     x24, #0x2c87bb4                            
02c87ba0: ldr     x8, [x23]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c87ba4: mov     x0, x24                                    
02c87ba8: ldr     x1, [x8, #0x40]                            
02c87bac: bl      #0x2b70f34                                 fn_2b70f34
02c87bb0: cbz     x0, #0x2c87f00                             
02c87bb4: ldr     w8, [x23, #0x18]                           M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass2_0::<DOSetFloat>b__1
02c87bb8: cbz     w8, #0x2c87efc                             
02c87bbc: mov     x0, x23                                    
02c87bc0: mov     x1, x24                                    
02c87bc4: str     x24, [x0, #0x20]!                          .debugText
02c87bc8: bl      #0x2b70d54                                 fn_2b70d54
02c87bcc: cbz     x22, #0x2c87ed4                            
02c87bd0: mov     x0, x22                                    
02c87bd4: mov     x1, x23                                    
02c87bd8: str     x23, [x0, #0x58]!                          
02c87bdc: bl      #0x2b70d54                                 fn_2b70d54
02c87be0: cbz     x21, #0x2c87ed4                            
02c87be4: adrp    x23, #0x6264000                            
02c87be8: mov     x1, x22                                    
02c87bec: ldr     x23, [x23, #0xdf0]                         T:UnityEngine.SystemInfo
02c87bf0: str     x22, [x21, #0x20]!                         .debugText
02c87bf4: mov     x0, x21                                    
02c87bf8: bl      #0x2b70d54                                 fn_2b70d54
02c87bfc: adrp    x25, #0x6263000                            
02c87c00: ldr     x25, [x25, #0x970]                         &6645c70(=0)
02c87c04: ldr     x21, [x23]                                 M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c87c08: ldr     x0, [x25, #0xe0]                           &2c5bf4c(=a9be7bfdd503233f)
02c87c0c: ldr     w8, [x0, #0xe4]                            [62640e4]=0 f=0,0
02c87c10: cbnz    w8, #0x2c87c18                             
02c87c14: bl      #0x2b70f30                                 fn_2b70f30
02c87c18: mov     x0, x21                                    
02c87c1c: mov     x1, xzr                                    
02c87c20: bl      #0x4e20e5c                                 System.Type::GetTypeFromHandle
02c87c24: cbz     x0, #0x2c87ed4                             
02c87c28: ldr     x8, [x0]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c87c2c: mov     w1, #0x18                                  
02c87c30: ldr     x9, [x8, #0x868]                           
02c87c34: ldr     x2, [x8, #0x870]                           
02c87c38: blr     x9                                         
02c87c3c: cbz     x0, #0x2c87ed4                             
02c87c40: ldr     w8, [x0, #0x18]                            M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass2_0::<DOSetFloat>b__1
02c87c44: mov     x21, x0                                    
02c87c48: cmp     w8, #1                                     
02c87c4c: b.lt    #0x2c87d98                                 
02c87c50: adrp    x26, #0x6264000                            
02c87c54: adrp    x27, #0x6264000                            
02c87c58: mov     w28, wzr                                   
02c87c5c: ldr     x26, [x26, #0xf28]                         T:E7.NotchSolution.SystemInfoData
02c87c60: ldr     x27, [x27, #0xf08]                         T:E7.NotchSolution.GraphicsDependentSystemInfoData
02c87c64: cmp     w28, w8                                    
02c87c68: b.hs    #0x2c87efc                                 
02c87c6c: ldr     x0, [x25, #0xe0]                           &2c5bf4c(=a9be7bfdd503233f)
02c87c70: add     x8, x21, w28, sxtw #3                      &6264000
02c87c74: ldr     x23, [x26]                                 M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c87c78: ldr     w9, [x0, #0xe4]                            [62640e4]=0 f=0,0
02c87c7c: ldr     x22, [x8, #0x20]                           
02c87c80: cbnz    w9, #0x2c87c88                             
02c87c84: bl      #0x2b70f30                                 fn_2b70f30
02c87c88: mov     x0, x23                                    
02c87c8c: mov     x1, xzr                                    
02c87c90: bl      #0x4e20e5c                                 System.Type::GetTypeFromHandle
02c87c94: cbz     x22, #0x2c87ed4                            
02c87c98: ldr     x8, [x22]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c87c9c: mov     x23, x0                                    
02c87ca0: mov     x0, x22                                    
02c87ca4: ldp     x9, x1, [x8, #0x1b8]                       
02c87ca8: blr     x9                                         
02c87cac: cbz     x23, #0x2c87ed4                            
02c87cb0: mov     x1, x0                                     
02c87cb4: mov     x0, x23                                    
02c87cb8: mov     x2, xzr                                    
02c87cbc: bl      #0x4e2c6e4                                 System.Type::GetField
02c87cc0: mov     x1, xzr                                    
02c87cc4: mov     x2, xzr                                    
02c87cc8: mov     x23, x0                                    
02c87ccc: bl      #0x4d4cf70                                 System.Reflection.FieldInfo::op_Inequality
02c87cd0: tbz     w0, #0, #0x2c87ce0                         
02c87cd4: ldr     x8, [x20]                                  &2b706c4(=eb01011ff9400808)
02c87cd8: cbnz    x8, #0x2c87d5c                             
02c87cdc: b       #0x2c87ed4                                 
02c87ce0: ldr     x0, [x25, #0xe0]                           &2c5bf4c(=a9be7bfdd503233f)
02c87ce4: ldr     x23, [x27]                                 M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c87ce8: ldr     w8, [x0, #0xe4]                            [62640e4]=0 f=0,0
02c87cec: cbnz    w8, #0x2c87cf4                             
02c87cf0: bl      #0x2b70f30                                 fn_2b70f30
02c87cf4: mov     x0, x23                                    
02c87cf8: mov     x1, xzr                                    
02c87cfc: bl      #0x4e20e5c                                 System.Type::GetTypeFromHandle
02c87d00: ldr     x8, [x22]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c87d04: mov     x23, x0                                    
02c87d08: mov     x0, x22                                    
02c87d0c: ldp     x9, x1, [x8, #0x1b8]                       
02c87d10: blr     x9                                         
02c87d14: cbz     x23, #0x2c87ed4                            
02c87d18: mov     x1, x0                                     
02c87d1c: mov     x0, x23                                    
02c87d20: mov     x2, xzr                                    
02c87d24: bl      #0x4e2c6e4                                 System.Type::GetField
02c87d28: mov     x1, xzr                                    
02c87d2c: mov     x2, xzr                                    
02c87d30: mov     x23, x0                                    
02c87d34: bl      #0x4d4cf70                                 System.Reflection.FieldInfo::op_Inequality
02c87d38: tbz     w0, #0, #0x2c87d88                         
02c87d3c: ldr     x8, [x20]                                  &2b706c4(=eb01011ff9400808)
02c87d40: cbz     x8, #0x2c87ed4                             
02c87d44: ldr     x8, [x8, #0x20]                            
02c87d48: cbz     x8, #0x2c87ed4                             
02c87d4c: ldr     x8, [x8, #0x58]                            
02c87d50: cbz     x8, #0x2c87ed4                             
02c87d54: ldr     w9, [x8, #0x18]                            
02c87d58: cbz     w9, #0x2c87efc                             
02c87d5c: ldr     x24, [x8, #0x20]                           
02c87d60: mov     x0, x22                                    
02c87d64: mov     x1, xzr                                    
02c87d68: mov     x2, xzr                                    
02c87d6c: bl      #0x4d4fc7c                                 System.Reflection.PropertyInfo::GetValue
02c87d70: cbz     x23, #0x2c87ed4                            
02c87d74: mov     x2, x0                                     
02c87d78: mov     x0, x23                                    
02c87d7c: mov     x1, x24                                    
02c87d80: mov     x3, xzr                                    
02c87d84: bl      #0x4d4cfac                                 System.Reflection.FieldInfo::SetValue
02c87d88: ldr     w8, [x21, #0x18]                           M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass2_0::<DOSetFloat>b__1
02c87d8c: add     w28, w28, #1                               
02c87d90: cmp     w28, w8                                    
02c87d94: b.lt    #0x2c87c64                                 
02c87d98: adrp    x8, #0x6264000                             
02c87d9c: mov     w1, #1                                     
02c87da0: ldr     x8, [x8, #0xf18]                           T:type60960(k1d)
02c87da4: ldr     x21, [x20]                                 &2b706c4(=eb01011ff9400808)
02c87da8: ldr     x0, [x8]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c87dac: bl      #0x2b70ea0                                 fn_2b70ea0
02c87db0: cbz     x21, #0x2c87ed4                            
02c87db4: mov     x1, x0                                     
02c87db8: str     x0, [x21, #0x18]!                          
02c87dbc: mov     x0, x21                                    
02c87dc0: bl      #0x2b70d54                                 fn_2b70d54
02c87dc4: ldr     x8, [x20]                                  &2b706c4(=eb01011ff9400808)
02c87dc8: cbz     x8, #0x2c87ed4                             
02c87dcc: adrp    x25, #0x6264000                            
02c87dd0: adrp    x26, #0x6264000                            
02c87dd4: adrp    x27, #0x6264000                            
02c87dd8: ldr     x25, [x25, #0xf20]                         T:E7.NotchSolution.ScreenData
02c87ddc: ldr     x26, [x26, #0xef8]                         T:type54436(k15)
02c87de0: ldr     x27, [x27, #0xef0]                         MS:System.Collections.Generic.Dictionary`2::.ctor
02c87de4: mov     x24, xzr                                   
02c87de8: mov     w28, #0x20                                 
02c87dec: ldr     x8, [x8, #0x18]                            M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass2_0::<DOSetFloat>b__1
02c87df0: cbz     x8, #0x2c87ed4                             
02c87df4: ldrsw   x8, [x8, #0x18]                            
02c87df8: cmp     x24, x8                                    
02c87dfc: b.ge    #0x2c87ed8                                 
02c87e00: ldr     x0, [x25]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c87e04: bl      #0x2b7104c                                 fn_2b7104c
02c87e08: mov     x1, xzr                                    
02c87e0c: mov     x21, x0                                    
02c87e10: bl      #0x2d7eab8                                 E7.NotchSolution.ScreenData::.ctor
02c87e14: mov     x0, xzr                                    
02c87e18: bl      #0x5afb6fc                                 UnityEngine.Screen::get_width
02c87e1c: cbz     x21, #0x2c87ed4                            
02c87e20: str     w0, [x21, #0x10]                           
02c87e24: mov     x0, xzr                                    
02c87e28: bl      #0x5afb724                                 UnityEngine.Screen::get_height
02c87e2c: ldr     x8, [x26]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c87e30: str     w0, [x21, #0x14]                           
02c87e34: mov     x0, x8                                     
02c87e38: bl      #0x2b7104c                                 fn_2b7104c
02c87e3c: ldr     x1, [x27]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c87e40: mov     x22, x0                                    
02c87e44: bl      #0x44eb650                                 fn_44eb650
02c87e48: mov     x23, x21                                   
02c87e4c: mov     x1, x22                                    
02c87e50: str     x22, [x23, #0x20]!                         
02c87e54: mov     x0, x23                                    
02c87e58: bl      #0x2b70d54                                 fn_2b70d54
02c87e5c: mov     x0, xzr                                    
02c87e60: bl      #0x5afb74c                                 UnityEngine.Screen::get_dpi
02c87e64: ldr     x8, [x20]                                  &2b706c4(=eb01011ff9400808)
02c87e68: stur    s0, [x23, #-4]                             
02c87e6c: cbz     x8, #0x2c87ed4                             
02c87e70: ldr     x22, [x8, #0x18]                           M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass2_0::<DOSetFloat>b__1
02c87e74: cbz     x22, #0x2c87ed4                            
02c87e78: ldr     x8, [x22]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c87e7c: mov     x0, x21                                    
02c87e80: ldr     x1, [x8, #0x40]                            MS:DG.Tweening.TweenSettingsExtensions::SetTarget
02c87e84: bl      #0x2b70f34                                 fn_2b70f34
02c87e88: cbz     x0, #0x2c87f00                             
02c87e8c: ldr     w8, [x22, #0x18]                           M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass2_0::<DOSetFloat>b__1
02c87e90: cmp     x24, x8                                    
02c87e94: b.hs    #0x2c87efc                                 
02c87e98: add     x8, x22, x24, lsl #3                       &6264000
02c87e9c: add     x0, x22, x28                               &6264000
02c87ea0: mov     x1, x21                                    
02c87ea4: str     x21, [x8, #0x20]                           
02c87ea8: bl      #0x2b70d54                                 fn_2b70d54
02c87eac: mov     x1, x21                                    
02c87eb0: bl      #0x2c87f0c                                 NotchSolutionDebugger::screenData
02c87eb4: mov     x1, x0                                     
02c87eb8: mov     x0, x19                                    
02c87ebc: mov     x2, xzr                                    
02c87ec0: bl      #0x5b389f0                                 UnityEngine.MonoBehaviour::StartCoroutine
02c87ec4: ldr     x8, [x19, #0x48]                           .device
02c87ec8: add     x24, x24, #1                               &6264001
02c87ecc: add     x28, x28, #8                               
02c87ed0: cbnz    x8, #0x2c87dec                             
02c87ed4: bl      #0x2b7105c                                 fn_2b7105c
02c87ed8: mov     w8, #1                                     
02c87edc: ldp     x22, x21, [sp, #0x40]                      
02c87ee0: str     w8, [x19, #0x50]                           .menu
02c87ee4: ldp     x20, x19, [sp, #0x50]                      
02c87ee8: ldp     x24, x23, [sp, #0x30]                      
02c87eec: ldp     x26, x25, [sp, #0x20]                      
02c87ef0: ldp     x28, x27, [sp, #0x10]                      
02c87ef4: ldr     x30, [sp], #0x60                           
02c87ef8: ret                                                
02c87efc: bl      #0x2b71064                                 fn_2b71064
02c87f00: bl      #0x2b71080                                 fn_2b71080
02c87f04: mov     x1, xzr                                    
02c87f08: bl      #0x2b70f20                                 fn_2b70f20
## screenData(E7.NotchSolution.ScreenData screen) -> System.Collections.IEnumerator
---- NotchSolutionDebugger::screenData 0x2c87f0c
02c87f0c: stp     x30, x21, [sp, #-0x20]!                    
02c87f10: stp     x20, x19, [sp, #0x10]                      
02c87f14: adrp    x20, #0x662f000                            
02c87f18: adrp    x21, #0x6264000                            
02c87f1c: mov     x19, x1                                    
02c87f20: ldrb    w8, [x20, #0x954]                          
02c87f24: ldr     x21, [x21, #0xf38]                         T:NotchSolutionDebugger/<screenData>d__17
02c87f28: tbnz    w8, #0, #0x2c87f40                         
02c87f2c: adrp    x0, #0x6264000                             
02c87f30: ldr     x0, [x0, #0xf38]                           T:NotchSolutionDebugger/<screenData>d__17
02c87f34: bl      #0x2b70db0                                 fn_2b70db0
02c87f38: mov     w8, #1                                     
02c87f3c: strb    w8, [x20, #0x954]                          
02c87f40: ldr     x0, [x21]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c87f44: bl      #0x2b7104c                                 fn_2b7104c
02c87f48: mov     x1, xzr                                    
02c87f4c: mov     x20, x0                                    
02c87f50: bl      #0x4e53e9c                                 System.Object::.ctor
02c87f54: mov     x0, x20                                    
02c87f58: mov     x1, x19                                    
02c87f5c: str     wzr, [x20, #0x10]                          
02c87f60: str     x19, [x0, #0x20]!                          .debugText
02c87f64: bl      #0x2b70d54                                 fn_2b70d54
02c87f68: mov     x0, x20                                    
02c87f6c: ldp     x20, x19, [sp, #0x10]                      
02c87f70: ldp     x30, x21, [sp], #0x20                      
02c87f74: ret                                                
## exportDone() -> System.Collections.IEnumerator
---- NotchSolutionDebugger::exportDone 0x2c87968
02c87968: stp     x30, x21, [sp, #-0x20]!                    
02c8796c: stp     x20, x19, [sp, #0x10]                      
02c87970: adrp    x20, #0x662f000                            
02c87974: adrp    x21, #0x6264000                            
02c87978: mov     x19, x0                                    
02c8797c: ldrb    w8, [x20, #0x955]                          
02c87980: ldr     x21, [x21, #0xed0]                         T:NotchSolutionDebugger/<exportDone>d__18
02c87984: tbnz    w8, #0, #0x2c8799c                         
02c87988: adrp    x0, #0x6264000                             
02c8798c: ldr     x0, [x0, #0xed0]                           T:NotchSolutionDebugger/<exportDone>d__18
02c87990: bl      #0x2b70db0                                 fn_2b70db0
02c87994: mov     w8, #1                                     
02c87998: strb    w8, [x20, #0x955]                          
02c8799c: ldr     x0, [x21]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c879a0: bl      #0x2b7104c                                 fn_2b7104c
02c879a4: mov     x1, xzr                                    
02c879a8: mov     x20, x0                                    
02c879ac: bl      #0x4e53e9c                                 System.Object::.ctor
02c879b0: mov     x0, x20                                    
02c879b4: mov     x1, x19                                    
02c879b8: str     wzr, [x20, #0x10]                          
02c879bc: str     x19, [x0, #0x20]!                          .debugText
02c879c0: bl      #0x2b70d54                                 fn_2b70d54
02c879c4: mov     x0, x20                                    
02c879c8: ldp     x20, x19, [sp, #0x10]                      
02c879cc: ldp     x30, x21, [sp], #0x20                      
02c879d0: ret                                                
## .ctor() -> void
---- NotchSolutionDebugger::.ctor 0x2c87fc8
02c87fc8: stp     x30, x23, [sp, #-0x30]!                    
02c87fcc: stp     x22, x21, [sp, #0x10]                      
02c87fd0: stp     x20, x19, [sp, #0x20]                      
02c87fd4: adrp    x22, #0x662f000                            
02c87fd8: adrp    x20, #0x6263000                            
02c87fdc: adrp    x21, #0x6264000                            
02c87fe0: ldrb    w8, [x22, #0x956]                          
02c87fe4: ldr     x20, [x20, #0x9c8]                         T:System.Text.StringBuilder
02c87fe8: ldr     x21, [x21, #0xdd8]                         T:E7.NotchSolution.NotchSolutionUtility
02c87fec: mov     x19, x0                                    
02c87ff0: tbnz    w8, #0, #0x2c8802c                         
02c87ff4: adrp    x0, #0x6264000                             
02c87ff8: ldr     x0, [x0, #0xf40]                           MS:System.Collections.Generic.List`1::.ctor
02c87ffc: bl      #0x2b70db0                                 fn_2b70db0
02c88000: adrp    x0, #0x6264000                             
02c88004: ldr     x0, [x0, #0xf48]                           T:type56668(k15)
02c88008: bl      #0x2b70db0                                 fn_2b70db0
02c8800c: adrp    x0, #0x6264000                             
02c88010: ldr     x0, [x0, #0xdd8]                           T:E7.NotchSolution.NotchSolutionUtility
02c88014: bl      #0x2b70db0                                 fn_2b70db0
02c88018: adrp    x0, #0x6263000                             
02c8801c: ldr     x0, [x0, #0x9c8]                           T:System.Text.StringBuilder
02c88020: bl      #0x2b70db0                                 fn_2b70db0
02c88024: mov     w8, #1                                     
02c88028: strb    w8, [x22, #0x956]                          
02c8802c: adrp    x23, #0x6264000                            
02c88030: adrp    x22, #0x6264000                            
02c88034: ldr     x23, [x23, #0xf48]                         T:type56668(k15)
02c88038: ldr     x22, [x22, #0xf40]                         MS:System.Collections.Generic.List`1::.ctor
02c8803c: ldr     x0, [x20]                                  &2c5bbd4(=a9bd7bfdd503233f)
02c88040: bl      #0x2b7104c                                 fn_2b7104c
02c88044: mov     x1, xzr                                    
02c88048: mov     x20, x0                                    
02c8804c: bl      #0x4caf744                                 System.Text.StringBuilder::.ctor
02c88050: mov     x0, x19                                    
02c88054: mov     x1, x20                                    
02c88058: str     x20, [x0, #0x40]!                          .sb
02c8805c: bl      #0x2b70d54                                 fn_2b70d54
02c88060: ldr     x0, [x21]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c88064: ldr     w8, [x0, #0xe4]                            [62630e4]=0 f=0,0
02c88068: cbnz    w8, #0x2c88074                             
02c8806c: bl      #0x2b70f30                                 fn_2b70f30
02c88070: ldr     x0, [x21]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c88074: ldr     x8, [x0, #0xb8]                            &6263108(=0)
02c88078: ldr     q0, [x8]                                   
02c8807c: stur    q0, [x19, #0x54]                           .storedSimulatedSafeAreaRelative
02c88080: ldr     x8, [x0, #0xb8]                            &6263108(=0)
02c88084: mov     x0, x19                                    
02c88088: ldr     x1, [x8, #0x10]                            
02c8808c: str     x1, [x0, #0x68]!                           .storedSimulatedCutoutsRelative
02c88090: bl      #0x2b70d54                                 fn_2b70d54
02c88094: ldr     x0, [x23]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c88098: bl      #0x2b7104c                                 fn_2b7104c
02c8809c: ldr     x1, [x22]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c880a0: mov     x20, x0                                    
02c880a4: bl      #0x35a89a4                                 fn_35a89a4
02c880a8: mov     x0, x19                                    
02c880ac: mov     x1, x20                                    
02c880b0: str     x20, [x0, #0x70]!                          .debugRects
02c880b4: bl      #0x2b70d54                                 fn_2b70d54
02c880b8: mov     x0, x19                                    
02c880bc: ldp     x20, x19, [sp, #0x20]                      
02c880c0: ldp     x22, x21, [sp, #0x10]                      
02c880c4: mov     x1, xzr                                    
02c880c8: ldp     x30, x23, [sp], #0x30                      
02c880cc: b       #0x5b397b0                                 UnityEngine.MonoBehaviour::.ctor
