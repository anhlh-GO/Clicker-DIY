#### CLASS BlindBagCollection.PaperCardData parent= object
#   field Rarity                         RarityType                                         off=0x10 attr=6 
#   field CardSprite                     UnityEngine.Sprite                                 off=0x18 attr=6 
#   field GlowSprite                     UnityEngine.Sprite                                 off=0x20 attr=6 
## .ctor() -> void
---- BlindBagCollection.PaperCardData::.ctor 0x2d32a7c
02d32a7c: mov     x1, xzr                                    
02d32a80: b       #0x4e53e9c                                 System.Object::.ctor
