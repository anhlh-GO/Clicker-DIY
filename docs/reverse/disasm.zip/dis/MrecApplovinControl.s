#### CLASS MrecApplovinControl parent= ApplovinEventBase
#   field mrecBottomX                    float                                              off=0x2c attr=1 
#   field mrecBottomY                    float                                              off=0x30 attr=1 
#   field screenDensity                  float                                              off=0x34 attr=1 
#   field MRECX_DP                       int                                                off=0x0 attr=8051 
#   field MRECY_DP                       int                                                off=0x0 attr=8051 
## Start() -> void
---- MrecApplovinControl::Start 0x2c8e1ec
02c8e1ec: mov     w8, #3                                     
02c8e1f0: str     w8, [x0, #0x28]                            
02c8e1f4: ret                                                
## InitAd() -> void
---- MrecApplovinControl::InitAd 0x2c8d460
02c8d460: str     x30, [sp, #-0x40]!                         
02c8d464: stp     x24, x23, [sp, #0x10]                      
02c8d468: stp     x22, x21, [sp, #0x20]                      
02c8d46c: stp     x20, x19, [sp, #0x30]                      
02c8d470: adrp    x21, #0x662f000                            
02c8d474: adrp    x20, #0x6264000                            
02c8d478: mov     x19, x0                                    
02c8d47c: ldrb    w8, [x21, #0x998]                          
02c8d480: ldr     x20, [x20, #0xfc0]                         T:RemoteConfigManager
02c8d484: tbnz    w8, #0, #0x2c8d4d8                         
02c8d488: adrp    x0, #0x6265000                             
02c8d48c: ldr     x0, [x0, #0x350]                           T:type7232(k15)
02c8d490: bl      #0x2b70db0                                 fn_2b70db0
02c8d494: adrp    x0, #0x6265000                             
02c8d498: ldr     x0, [x0, #0x358]                           T:type7234(k15)
02c8d49c: bl      #0x2b70db0                                 fn_2b70db0
02c8d4a0: adrp    x0, #0x6265000                             
02c8d4a4: ldr     x0, [x0, #0x2f8]                           T:MaxSdkAndroid
02c8d4a8: bl      #0x2b70db0                                 fn_2b70db0
02c8d4ac: adrp    x0, #0x6265000                             
02c8d4b0: ldr     x0, [x0, #0x378]                           M:MrecApplovinControl::OnAdCollapsedEvent
02c8d4b4: bl      #0x2b70db0                                 fn_2b70db0
02c8d4b8: adrp    x0, #0x6265000                             
02c8d4bc: ldr     x0, [x0, #0x380]                           M:MrecApplovinControl::OnAdExpandedEvent
02c8d4c0: bl      #0x2b70db0                                 fn_2b70db0
02c8d4c4: adrp    x0, #0x6264000                             
02c8d4c8: ldr     x0, [x0, #0xfc0]                           T:RemoteConfigManager
02c8d4cc: bl      #0x2b70db0                                 fn_2b70db0
02c8d4d0: mov     w8, #1                                     
02c8d4d4: strb    w8, [x21, #0x998]                          
02c8d4d8: ldr     x0, [x20]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c8d4dc: ldr     w8, [x0, #0xe4]                            [62640e4]=0 f=0,0
02c8d4e0: cbnz    w8, #0x2c8d4e8                             
02c8d4e4: bl      #0x2b70f30                                 fn_2b70f30
02c8d4e8: adrp    x21, #0x662f000                            
02c8d4ec: ldrb    w8, [x21, #0xa80]                          
02c8d4f0: cbnz    w8, #0x2c8d508                             
02c8d4f4: adrp    x0, #0x6264000                             
02c8d4f8: ldr     x0, [x0, #0xfc0]                           T:RemoteConfigManager
02c8d4fc: bl      #0x2b70db0                                 fn_2b70db0
02c8d500: mov     w8, #1                                     
02c8d504: strb    w8, [x21, #0xa80]                          
02c8d508: ldr     x0, [x20]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c8d50c: adrp    x21, #0x6265000                            
02c8d510: ldr     w8, [x0, #0xe4]                            [62640e4]=0 f=0,0
02c8d514: ldr     x21, [x21, #0x2f8]                         T:MaxSdkAndroid
02c8d518: cbnz    w8, #0x2c8d524                             
02c8d51c: bl      #0x2b70f30                                 fn_2b70f30
02c8d520: ldr     x0, [x20]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c8d524: ldr     x8, [x21]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c8d528: ldr     x9, [x0, #0xb8]                            MS:DG.Tweening.Core.Extensions::SetSpecialStartupMode
02c8d52c: adrp    x21, #0x6265000                            
02c8d530: ldr     w10, [x8, #0xe4]                           
02c8d534: ldr     x21, [x21, #0x350]                         T:type7232(k15)
02c8d538: ldr     x20, [x9, #0x30]                           
02c8d53c: cbnz    w10, #0x2c8d548                            
02c8d540: mov     x0, x8                                     
02c8d544: bl      #0x2b70f30                                 fn_2b70f30
02c8d548: mov     x0, x20                                    
02c8d54c: mov     w1, #7                                     
02c8d550: mov     x2, xzr                                    
02c8d554: bl      #0x4c56514                                 MaxSdkAndroid::CreateMRec
02c8d558: ldr     x0, [x21]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c8d55c: bl      #0x2b7104c                                 fn_2b7104c
02c8d560: cbz     x19, #0x2c8d68c                            
02c8d564: adrp    x24, #0x6265000                            
02c8d568: adrp    x23, #0x6265000                            
02c8d56c: adrp    x22, #0x6265000                            
02c8d570: ldr     x24, [x24, #0x358]                         T:type7234(k15)
02c8d574: ldr     x8, [x19]                                  
02c8d578: ldr     x23, [x23, #0x380]                         M:MrecApplovinControl::OnAdExpandedEvent
02c8d57c: ldr     x22, [x22, #0x378]                         M:MrecApplovinControl::OnAdCollapsedEvent
02c8d580: mov     x1, x19                                    
02c8d584: mov     x3, xzr                                    
02c8d588: ldr     x2, [x8, #0x180]                           
02c8d58c: mov     x20, x0                                    
02c8d590: bl      #0x453ce6c                                 fn_453ce6c
02c8d594: mov     x0, x20                                    
02c8d598: mov     x1, xzr                                    
02c8d59c: bl      #0x4c5f95c                                 MaxSdkCallbacks/MRec::add_OnAdLoadedEvent
02c8d5a0: ldr     x0, [x24]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c8d5a4: bl      #0x2b7104c                                 fn_2b7104c
02c8d5a8: ldr     x8, [x19]                                  
02c8d5ac: mov     x1, x19                                    
02c8d5b0: mov     x3, xzr                                    
02c8d5b4: mov     x20, x0                                    
02c8d5b8: ldr     x2, [x8, #0x190]                           
02c8d5bc: bl      #0x453ce6c                                 fn_453ce6c
02c8d5c0: mov     x0, x20                                    
02c8d5c4: mov     x1, xzr                                    
02c8d5c8: bl      #0x4c5fb74                                 MaxSdkCallbacks/MRec::add_OnAdLoadFailedEvent
02c8d5cc: ldr     x0, [x21]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c8d5d0: bl      #0x2b7104c                                 fn_2b7104c
02c8d5d4: ldr     x8, [x19]                                  
02c8d5d8: mov     x1, x19                                    
02c8d5dc: mov     x3, xzr                                    
02c8d5e0: mov     x20, x0                                    
02c8d5e4: ldr     x2, [x8, #0x1b0]                           
02c8d5e8: bl      #0x453ce6c                                 fn_453ce6c
02c8d5ec: mov     x0, x20                                    
02c8d5f0: mov     x1, xzr                                    
02c8d5f4: bl      #0x4c5fd6c                                 MaxSdkCallbacks/MRec::add_OnAdClickedEvent
02c8d5f8: ldr     x0, [x21]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c8d5fc: bl      #0x2b7104c                                 fn_2b7104c
02c8d600: ldr     x8, [x19]                                  
02c8d604: mov     x1, x19                                    
02c8d608: mov     x3, xzr                                    
02c8d60c: mov     x20, x0                                    
02c8d610: ldr     x2, [x8, #0x1e0]                           
02c8d614: bl      #0x453ce6c                                 fn_453ce6c
02c8d618: mov     x0, x20                                    
02c8d61c: mov     x1, xzr                                    
02c8d620: bl      #0x4c5ff64                                 MaxSdkCallbacks/MRec::add_OnAdRevenuePaidEvent
02c8d624: ldr     x0, [x21]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c8d628: bl      #0x2b7104c                                 fn_2b7104c
02c8d62c: ldr     x2, [x23]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c8d630: mov     x1, x19                                    
02c8d634: mov     x3, xzr                                    
02c8d638: mov     x20, x0                                    
02c8d63c: bl      #0x453ce6c                                 fn_453ce6c
02c8d640: mov     x0, x20                                    
02c8d644: mov     x1, xzr                                    
02c8d648: bl      #0x4c60354                                 MaxSdkCallbacks/MRec::add_OnAdExpandedEvent
02c8d64c: ldr     x0, [x21]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c8d650: bl      #0x2b7104c                                 fn_2b7104c
02c8d654: ldr     x2, [x22]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c8d658: mov     x1, x19                                    
02c8d65c: mov     x3, xzr                                    
02c8d660: mov     x20, x0                                    
02c8d664: bl      #0x453ce6c                                 fn_453ce6c
02c8d668: mov     x0, x20                                    
02c8d66c: mov     x1, xzr                                    
02c8d670: bl      #0x4c6054c                                 MaxSdkCallbacks/MRec::add_OnAdCollapsedEvent
02c8d674: mov     x0, x19                                    
02c8d678: ldp     x20, x19, [sp, #0x30]                      
02c8d67c: ldp     x22, x21, [sp, #0x20]                      
02c8d680: ldp     x24, x23, [sp, #0x10]                      
02c8d684: ldr     x30, [sp], #0x40                           
02c8d688: b       #0x2c8e1f8                                 MrecApplovinControl::CalculatorMRECCustomPosition
02c8d68c: bl      #0x2b7105c                                 fn_2b7105c
## CalculatorMRECCustomPosition() -> void
---- MrecApplovinControl::CalculatorMRECCustomPosition 0x2c8e1f8
02c8e1f8: str     d10, [sp, #-0x40]!                         
02c8e1fc: stp     d9, d8, [sp, #0x10]                        
02c8e200: stp     x30, x21, [sp, #0x20]                      
02c8e204: stp     x20, x19, [sp, #0x30]                      
02c8e208: adrp    x20, #0x662f000                            
02c8e20c: adrp    x21, #0x6265000                            
02c8e210: mov     x19, x0                                    
02c8e214: ldrb    w8, [x20, #0x999]                          
02c8e218: ldr     x21, [x21, #0x3d0]                         T:MaxSdkUtils
02c8e21c: tbnz    w8, #0, #0x2c8e234                         
02c8e220: adrp    x0, #0x6265000                             
02c8e224: ldr     x0, [x0, #0x3d0]                           T:MaxSdkUtils
02c8e228: bl      #0x2b70db0                                 fn_2b70db0
02c8e22c: mov     w8, #1                                     
02c8e230: strb    w8, [x20, #0x999]                          
02c8e234: ldr     x0, [x21]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c8e238: ldr     w8, [x0, #0xe4]                            [62650e4]=0 f=0,0
02c8e23c: cbnz    w8, #0x2c8e244                             
02c8e240: bl      #0x2b70f30                                 fn_2b70f30
02c8e244: mov     x0, xzr                                    
02c8e248: bl      #0x4c561a0                                 MaxSdkUtils::GetScreenDensity
02c8e24c: mov     w8, #-0x3c6a0000                           
02c8e250: fmov    s2, #0.50000000                            
02c8e254: mov     x0, xzr                                    
02c8e258: fmov    s1, w8                                     
02c8e25c: mov     w8, #-0x3c860000                           
02c8e260: str     s0, [x19, #0x34]                           .screenDensity
02c8e264: fmov    s3, w8                                     
02c8e268: fmul    s1, s0, s1                                 
02c8e26c: fmul    s9, s0, s3                                 
02c8e270: fmul    s8, s1, s2                                 
02c8e274: bl      #0x5afb6fc                                 UnityEngine.Screen::get_width
02c8e278: scvtf   s10, w0, #1                                
02c8e27c: mov     x0, xzr                                    
02c8e280: bl      #0x5afb724                                 UnityEngine.Screen::get_height
02c8e284: fadd    s0, s10, s8                                
02c8e288: ldr     s1, [x19, #0x34]                           .screenDensity
02c8e28c: mov     x0, xzr                                    
02c8e290: fdiv    s0, s0, s1                                 
02c8e294: str     s0, [x19, #0x2c]                           .mrecBottomX
02c8e298: bl      #0x5afb724                                 UnityEngine.Screen::get_height
02c8e29c: scvtf   s0, w0                                     
02c8e2a0: adrp    x8, #0x1084000                             
02c8e2a4: ldr     s1, [x8, #0xcf0]                           [1084cf0]=3f99999a3f59999a f=0.85,1.2
02c8e2a8: ldp     x30, x21, [sp, #0x20]                      
02c8e2ac: fmul    s0, s0, s1                                 
02c8e2b0: ldr     s1, [x19, #0x34]                           .screenDensity
02c8e2b4: fadd    s0, s0, s9                                 
02c8e2b8: ldp     d9, d8, [sp, #0x10]                        
02c8e2bc: fdiv    s0, s0, s1                                 
02c8e2c0: str     s0, [x19, #0x30]                           .mrecBottomY
02c8e2c4: ldp     x20, x19, [sp, #0x30]                      
02c8e2c8: ldr     d10, [sp], #0x40                           
02c8e2cc: ret                                                
## ShowAd(AdsPosition adsPosition) -> void
---- MrecApplovinControl::ShowAd 0x2c8ceb0
02c8ceb0: sub     sp, sp, #0x50                              
02c8ceb4: stp     x30, x23, [sp, #0x20]                      
02c8ceb8: stp     x22, x21, [sp, #0x30]                      
02c8cebc: stp     x20, x19, [sp, #0x40]                      
02c8cec0: adrp    x22, #0x662f000                            
02c8cec4: adrp    x23, #0x6265000                            
02c8cec8: adrp    x21, #0x6265000                            
02c8cecc: ldrb    w8, [x22, #0x99a]                          
02c8ced0: ldr     x23, [x23, #0x330]                         T:AdsPosition
02c8ced4: ldr     x21, [x21, #0x338]                         S:'Show MREC '
02c8ced8: mov     w20, w1                                    
02c8cedc: mov     x19, x0                                    
02c8cee0: tbnz    w8, #0, #0x2c8cf04                         
02c8cee4: adrp    x0, #0x6265000                             
02c8cee8: ldr     x0, [x0, #0x330]                           T:AdsPosition
02c8ceec: bl      #0x2b70db0                                 fn_2b70db0
02c8cef0: adrp    x0, #0x6265000                             
02c8cef4: ldr     x0, [x0, #0x338]                           S:'Show MREC '
02c8cef8: bl      #0x2b70db0                                 fn_2b70db0
02c8cefc: mov     w8, #1                                     
02c8cf00: strb    w8, [x22, #0x99a]                          
02c8cf04: ldr     x8, [x23]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c8cf08: mov     x9, #-1                                    
02c8cf0c: add     x0, sp, #8                                 
02c8cf10: mov     x1, xzr                                    
02c8cf14: str     w20, [sp, #0x18]                           
02c8cf18: stp     x8, x9, [sp, #8]                           
02c8cf1c: bl      #0x4e47e48                                 System.Enum::ToString
02c8cf20: ldr     x8, [x21]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c8cf24: mov     x1, x0                                     
02c8cf28: mov     x2, xzr                                    
02c8cf2c: mov     x0, x8                                     
02c8cf30: bl      #0x4c9c514                                 System.String::Concat
02c8cf34: mov     x1, xzr                                    
02c8cf38: bl      #0x2ca09f8                                 WLog::LogError
02c8cf3c: cmp     w20, #1                                    
02c8cf40: b.le    #0x2c8cf68                                 
02c8cf44: cmp     w20, #2                                    
02c8cf48: b.eq    #0x2c8cf8c                                 
02c8cf4c: cmp     w20, #3                                    
02c8cf50: b.eq    #0x2c8cf98                                 
02c8cf54: cmp     w20, #4                                    
02c8cf58: b.ne    #0x2c8cf80                                 
02c8cf5c: mov     x0, x19                                    
02c8cf60: bl      #0x2c8e480                                 MrecApplovinControl::ShowCustom
02c8cf64: b       #0x2c8cfa0                                 
02c8cf68: cbz     w20, #0x2c8cf80                            
02c8cf6c: cmp     w20, #1                                    
02c8cf70: b.ne    #0x2c8cf80                                 
02c8cf74: mov     x0, x19                                    
02c8cf78: bl      #0x2c8e33c                                 MrecApplovinControl::ShowCenter
02c8cf7c: b       #0x2c8cfa0                                 
02c8cf80: mov     x0, x19                                    
02c8cf84: bl      #0x2c8e2d0                                 MrecApplovinControl::ShowBottom
02c8cf88: b       #0x2c8cfa0                                 
02c8cf8c: mov     x0, x19                                    
02c8cf90: bl      #0x2c8e3a8                                 MrecApplovinControl::ShowLeft
02c8cf94: b       #0x2c8cfa0                                 
02c8cf98: mov     x0, x19                                    
02c8cf9c: bl      #0x2c8e414                                 MrecApplovinControl::ShowRight
02c8cfa0: ldp     x20, x19, [sp, #0x40]                      
02c8cfa4: ldp     x22, x21, [sp, #0x30]                      
02c8cfa8: ldp     x30, x23, [sp, #0x20]                      
02c8cfac: add     sp, sp, #0x50                              
02c8cfb0: ret                                                
## ShowBottom() -> void
---- MrecApplovinControl::ShowBottom 0x2c8e2d0
02c8e2d0: str     x30, [sp, #-0x20]!                         
02c8e2d4: stp     x20, x19, [sp, #0x10]                      
02c8e2d8: adrp    x20, #0x662f000                            
02c8e2dc: adrp    x19, #0x6265000                            
02c8e2e0: ldrb    w8, [x20, #0x99b]                          
02c8e2e4: ldr     x19, [x19, #0x2f8]                         T:MaxSdkAndroid
02c8e2e8: tbnz    w8, #0, #0x2c8e300                         
02c8e2ec: adrp    x0, #0x6265000                             
02c8e2f0: ldr     x0, [x0, #0x2f8]                           T:MaxSdkAndroid
02c8e2f4: bl      #0x2b70db0                                 fn_2b70db0
02c8e2f8: mov     w8, #1                                     
02c8e2fc: strb    w8, [x20, #0x99b]                          
02c8e300: mov     w0, #3                                     
02c8e304: bl      #0x2c8de38                                 KeyAds::Get
02c8e308: ldr     x8, [x19]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c8e30c: mov     x19, x0                                    
02c8e310: ldr     w9, [x8, #0xe4]                            
02c8e314: cbnz    w9, #0x2c8e320                             
02c8e318: mov     x0, x8                                     
02c8e31c: bl      #0x2b70f30                                 fn_2b70f30
02c8e320: mov     x0, x19                                    
02c8e324: mov     w1, #7                                     
02c8e328: mov     x2, xzr                                    
02c8e32c: bl      #0x4c52b48                                 MaxSdkAndroid::UpdateMRecPosition
02c8e330: ldp     x20, x19, [sp, #0x10]                      
02c8e334: ldr     x30, [sp], #0x20                           
02c8e338: b       #0x2c8e500                                 MrecApplovinControl::HandleShow
## ShowLeft() -> void
---- MrecApplovinControl::ShowLeft 0x2c8e3a8
02c8e3a8: str     x30, [sp, #-0x20]!                         
02c8e3ac: stp     x20, x19, [sp, #0x10]                      
02c8e3b0: adrp    x20, #0x662f000                            
02c8e3b4: adrp    x19, #0x6265000                            
02c8e3b8: ldrb    w8, [x20, #0x99c]                          
02c8e3bc: ldr     x19, [x19, #0x2f8]                         T:MaxSdkAndroid
02c8e3c0: tbnz    w8, #0, #0x2c8e3d8                         
02c8e3c4: adrp    x0, #0x6265000                             
02c8e3c8: ldr     x0, [x0, #0x2f8]                           T:MaxSdkAndroid
02c8e3cc: bl      #0x2b70db0                                 fn_2b70db0
02c8e3d0: mov     w8, #1                                     
02c8e3d4: strb    w8, [x20, #0x99c]                          
02c8e3d8: mov     w0, #3                                     
02c8e3dc: bl      #0x2c8de38                                 KeyAds::Get
02c8e3e0: ldr     x8, [x19]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c8e3e4: mov     x19, x0                                    
02c8e3e8: ldr     w9, [x8, #0xe4]                            
02c8e3ec: cbnz    w9, #0x2c8e3f8                             
02c8e3f0: mov     x0, x8                                     
02c8e3f4: bl      #0x2b70f30                                 fn_2b70f30
02c8e3f8: mov     x0, x19                                    
02c8e3fc: mov     w1, #4                                     
02c8e400: mov     x2, xzr                                    
02c8e404: bl      #0x4c52b48                                 MaxSdkAndroid::UpdateMRecPosition
02c8e408: ldp     x20, x19, [sp, #0x10]                      
02c8e40c: ldr     x30, [sp], #0x20                           
02c8e410: b       #0x2c8e500                                 MrecApplovinControl::HandleShow
## ShowRight() -> void
---- MrecApplovinControl::ShowRight 0x2c8e414
02c8e414: str     x30, [sp, #-0x20]!                         
02c8e418: stp     x20, x19, [sp, #0x10]                      
02c8e41c: adrp    x20, #0x662f000                            
02c8e420: adrp    x19, #0x6265000                            
02c8e424: ldrb    w8, [x20, #0x99d]                          
02c8e428: ldr     x19, [x19, #0x2f8]                         T:MaxSdkAndroid
02c8e42c: tbnz    w8, #0, #0x2c8e444                         
02c8e430: adrp    x0, #0x6265000                             
02c8e434: ldr     x0, [x0, #0x2f8]                           T:MaxSdkAndroid
02c8e438: bl      #0x2b70db0                                 fn_2b70db0
02c8e43c: mov     w8, #1                                     
02c8e440: strb    w8, [x20, #0x99d]                          
02c8e444: mov     w0, #3                                     
02c8e448: bl      #0x2c8de38                                 KeyAds::Get
02c8e44c: ldr     x8, [x19]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c8e450: mov     x19, x0                                    
02c8e454: ldr     w9, [x8, #0xe4]                            
02c8e458: cbnz    w9, #0x2c8e464                             
02c8e45c: mov     x0, x8                                     
02c8e460: bl      #0x2b70f30                                 fn_2b70f30
02c8e464: mov     x0, x19                                    
02c8e468: mov     w1, #5                                     
02c8e46c: mov     x2, xzr                                    
02c8e470: bl      #0x4c52b48                                 MaxSdkAndroid::UpdateMRecPosition
02c8e474: ldp     x20, x19, [sp, #0x10]                      
02c8e478: ldr     x30, [sp], #0x20                           
02c8e47c: b       #0x2c8e500                                 MrecApplovinControl::HandleShow
## ShowCenter() -> void
---- MrecApplovinControl::ShowCenter 0x2c8e33c
02c8e33c: str     x30, [sp, #-0x20]!                         
02c8e340: stp     x20, x19, [sp, #0x10]                      
02c8e344: adrp    x20, #0x662f000                            
02c8e348: adrp    x19, #0x6265000                            
02c8e34c: ldrb    w8, [x20, #0x99e]                          
02c8e350: ldr     x19, [x19, #0x2f8]                         T:MaxSdkAndroid
02c8e354: tbnz    w8, #0, #0x2c8e36c                         
02c8e358: adrp    x0, #0x6265000                             
02c8e35c: ldr     x0, [x0, #0x2f8]                           T:MaxSdkAndroid
02c8e360: bl      #0x2b70db0                                 fn_2b70db0
02c8e364: mov     w8, #1                                     
02c8e368: strb    w8, [x20, #0x99e]                          
02c8e36c: mov     w0, #3                                     
02c8e370: bl      #0x2c8de38                                 KeyAds::Get
02c8e374: ldr     x8, [x19]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c8e378: mov     x19, x0                                    
02c8e37c: ldr     w9, [x8, #0xe4]                            
02c8e380: cbnz    w9, #0x2c8e38c                             
02c8e384: mov     x0, x8                                     
02c8e388: bl      #0x2b70f30                                 fn_2b70f30
02c8e38c: mov     x0, x19                                    
02c8e390: mov     w1, #3                                     
02c8e394: mov     x2, xzr                                    
02c8e398: bl      #0x4c52b48                                 MaxSdkAndroid::UpdateMRecPosition
02c8e39c: ldp     x20, x19, [sp, #0x10]                      
02c8e3a0: ldr     x30, [sp], #0x20                           
02c8e3a4: b       #0x2c8e500                                 MrecApplovinControl::HandleShow
## ShowCustom() -> void
---- MrecApplovinControl::ShowCustom 0x2c8e480
02c8e480: stp     d9, d8, [sp, #-0x30]!                      
02c8e484: stp     x30, x21, [sp, #0x10]                      
02c8e488: stp     x20, x19, [sp, #0x20]                      
02c8e48c: adrp    x21, #0x662f000                            
02c8e490: adrp    x20, #0x6265000                            
02c8e494: mov     x19, x0                                    
02c8e498: ldrb    w8, [x21, #0x99f]                          
02c8e49c: ldr     x20, [x20, #0x2f8]                         T:MaxSdkAndroid
02c8e4a0: tbnz    w8, #0, #0x2c8e4b8                         
02c8e4a4: adrp    x0, #0x6265000                             
02c8e4a8: ldr     x0, [x0, #0x2f8]                           T:MaxSdkAndroid
02c8e4ac: bl      #0x2b70db0                                 fn_2b70db0
02c8e4b0: mov     w8, #1                                     
02c8e4b4: strb    w8, [x21, #0x99f]                          
02c8e4b8: mov     w0, #3                                     
02c8e4bc: bl      #0x2c8de38                                 KeyAds::Get
02c8e4c0: ldr     x8, [x20]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c8e4c4: ldp     s8, s9, [x19, #0x2c]                       .mrecBottomX
02c8e4c8: mov     x19, x0                                    
02c8e4cc: ldr     w9, [x8, #0xe4]                            
02c8e4d0: cbnz    w9, #0x2c8e4dc                             
02c8e4d4: mov     x0, x8                                     
02c8e4d8: bl      #0x2b70f30                                 fn_2b70f30
02c8e4dc: fmov    s0, s8                                     
02c8e4e0: fmov    s1, s9                                     
02c8e4e4: mov     x0, x19                                    
02c8e4e8: mov     x1, xzr                                    
02c8e4ec: bl      #0x4c52ca4                                 MaxSdkAndroid::UpdateMRecPosition
02c8e4f0: ldp     x20, x19, [sp, #0x20]                      
02c8e4f4: ldp     x30, x21, [sp, #0x10]                      
02c8e4f8: ldp     d9, d8, [sp], #0x30                        
02c8e4fc: b       #0x2c8e500                                 MrecApplovinControl::HandleShow
## HandleShow() -> void
---- MrecApplovinControl::HandleShow 0x2c8e500
02c8e500: str     x30, [sp, #-0x20]!                         
02c8e504: stp     x20, x19, [sp, #0x10]                      
02c8e508: adrp    x20, #0x662f000                            
02c8e50c: adrp    x19, #0x6265000                            
02c8e510: ldrb    w8, [x20, #0x9a0]                          
02c8e514: ldr     x19, [x19, #0x2f8]                         T:MaxSdkAndroid
02c8e518: tbnz    w8, #0, #0x2c8e530                         
02c8e51c: adrp    x0, #0x6265000                             
02c8e520: ldr     x0, [x0, #0x2f8]                           T:MaxSdkAndroid
02c8e524: bl      #0x2b70db0                                 fn_2b70db0
02c8e528: mov     w8, #1                                     
02c8e52c: strb    w8, [x20, #0x9a0]                          
02c8e530: mov     w0, #3                                     
02c8e534: bl      #0x2c8de38                                 KeyAds::Get
02c8e538: ldr     x8, [x19]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c8e53c: mov     x19, x0                                    
02c8e540: ldr     w9, [x8, #0xe4]                            
02c8e544: cbnz    w9, #0x2c8e550                             
02c8e548: mov     x0, x8                                     
02c8e54c: bl      #0x2b70f30                                 fn_2b70f30
02c8e550: mov     x0, x19                                    
02c8e554: ldp     x20, x19, [sp, #0x10]                      
02c8e558: mov     x1, xzr                                    
02c8e55c: ldr     x30, [sp], #0x20                           
02c8e560: b       #0x4c52e68                                 MaxSdkAndroid::ShowMRec
## HideAd() -> void
---- MrecApplovinControl::HideAd 0x2c8cfb4
02c8cfb4: stp     x30, x21, [sp, #-0x20]!                    
02c8cfb8: stp     x20, x19, [sp, #0x10]                      
02c8cfbc: adrp    x20, #0x662f000                            
02c8cfc0: adrp    x21, #0x6265000                            
02c8cfc4: adrp    x19, #0x6265000                            
02c8cfc8: ldrb    w8, [x20, #0x9a1]                          
02c8cfcc: ldr     x21, [x21, #0x340]                         S:'Hide MREC'
02c8cfd0: ldr     x19, [x19, #0x2f8]                         T:MaxSdkAndroid
02c8cfd4: tbnz    w8, #0, #0x2c8cff8                         
02c8cfd8: adrp    x0, #0x6265000                             
02c8cfdc: ldr     x0, [x0, #0x2f8]                           T:MaxSdkAndroid
02c8cfe0: bl      #0x2b70db0                                 fn_2b70db0
02c8cfe4: adrp    x0, #0x6265000                             
02c8cfe8: ldr     x0, [x0, #0x340]                           S:'Hide MREC'
02c8cfec: bl      #0x2b70db0                                 fn_2b70db0
02c8cff0: mov     w8, #1                                     
02c8cff4: strb    w8, [x20, #0x9a1]                          
02c8cff8: ldr     x0, [x21]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c8cffc: mov     x1, xzr                                    
02c8d000: bl      #0x2ca09f8                                 WLog::LogError
02c8d004: mov     w0, #3                                     
02c8d008: bl      #0x2c8de38                                 KeyAds::Get
02c8d00c: ldr     x8, [x19]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c8d010: mov     x19, x0                                    
02c8d014: ldr     w9, [x8, #0xe4]                            
02c8d018: cbnz    w9, #0x2c8d024                             
02c8d01c: mov     x0, x8                                     
02c8d020: bl      #0x2b70f30                                 fn_2b70f30
02c8d024: mov     x0, x19                                    
02c8d028: ldp     x20, x19, [sp, #0x10]                      
02c8d02c: mov     x1, xzr                                    
02c8d030: ldp     x30, x21, [sp], #0x20                      
02c8d034: b       #0x4c53098                                 MaxSdkAndroid::HideMRec
## OnAdLoadFailedEvent(string adUnitId, MaxSdkBase/ErrorInfo errorInfo) -> void
---- MrecApplovinControl::OnAdLoadFailedEvent 0x2c8e564
02c8e564: stp     x30, x21, [sp, #-0x20]!                    
02c8e568: stp     x20, x19, [sp, #0x10]                      
02c8e56c: adrp    x21, #0x662f000                            
02c8e570: mov     x19, x2                                    
02c8e574: mov     x20, x0                                    
02c8e578: ldrb    w8, [x21, #0x9a2]                          
02c8e57c: tbnz    w8, #0, #0x2c8e5a0                         
02c8e580: adrp    x0, #0x6265000                             
02c8e584: ldr     x0, [x0, #0x3d8]                           S:'MREC_AD'
02c8e588: bl      #0x2b70db0                                 fn_2b70db0
02c8e58c: adrp    x0, #0x6265000                             
02c8e590: ldr     x0, [x0, #0x3e0]                           S:'MREC_OnAdLoadFailedEvent'
02c8e594: bl      #0x2b70db0                                 fn_2b70db0
02c8e598: mov     w8, #1                                     
02c8e59c: strb    w8, [x21, #0x9a2]                          
02c8e5a0: mov     x0, x20                                    
02c8e5a4: mov     x2, x19                                    
02c8e5a8: bl      #0x2c8bb74                                 ApplovinEventBase::OnAdLoadFailedEvent
02c8e5ac: cbz     x19, #0x2c8e5d8                            
02c8e5b0: adrp    x8, #0x6265000                             
02c8e5b4: adrp    x9, #0x6265000                             
02c8e5b8: ldr     x8, [x8, #0x3d8]                           S:'MREC_AD'
02c8e5bc: ldr     x9, [x9, #0x3e0]                           S:'MREC_OnAdLoadFailedEvent'
02c8e5c0: ldr     x2, [x19, #0x18]                           
02c8e5c4: ldp     x20, x19, [sp, #0x10]                      
02c8e5c8: ldr     x0, [x8]                                   M:AdsManager::<OnApplicationPause>b__26_0
02c8e5cc: ldr     x1, [x9]                                   M:AdsManager::<OnApplicationPause>b__26_0
02c8e5d0: ldp     x30, x21, [sp], #0x20                      
02c8e5d4: b       #0x2c8b88c                                 AnalyticsManager::LogAdsEvent
02c8e5d8: bl      #0x2b7105c                                 fn_2b7105c
## OnAdExpandedEvent(string adUnitID, MaxSdkBase/AdInfo adInfo) -> void
---- MrecApplovinControl::OnAdExpandedEvent 0x2c8e5dc
02c8e5dc: ret                                                
## OnAdCollapsedEvent(string adUnitID, MaxSdkBase/AdInfo adInfo) -> void
---- MrecApplovinControl::OnAdCollapsedEvent 0x2c8e5e0
02c8e5e0: ret                                                
## .ctor() -> void
---- MrecApplovinControl::.ctor 0x2c8e5e4
02c8e5e4: b       #0x2c8c870                                 ApplovinEventBase::.ctor
