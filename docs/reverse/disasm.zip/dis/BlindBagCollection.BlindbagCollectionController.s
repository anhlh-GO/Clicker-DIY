#### CLASS BlindBagCollection.BlindbagCollectionController/<>c parent= object
#   field <>9                            BlindBagCollection.BlindbagCollectionController/<>c off=0x0 attr=36 
#   field <>9__28_1                      System.Action                                      off=0x8 attr=16 
## .cctor() -> void
---- BlindBagCollection.BlindbagCollectionController/<>c::.cctor 0x2d35fd0
02d35fd0: str     x30, [sp, #-0x20]!                         
02d35fd4: stp     x20, x19, [sp, #0x10]                      
02d35fd8: adrp    x19, #0x6630000                            
02d35fdc: adrp    x20, #0x626a000                            
02d35fe0: ldrb    w8, [x19, #0x117]                          
02d35fe4: ldr     x20, [x20, #0xa60]                         T:BlindBagCollection.BlindbagCollectionController/<>c
02d35fe8: tbnz    w8, #0, #0x2d36000                         
02d35fec: adrp    x0, #0x626a000                             
02d35ff0: ldr     x0, [x0, #0xa60]                           T:BlindBagCollection.BlindbagCollectionController/<>c
02d35ff4: bl      #0x2b70db0                                 fn_2b70db0
02d35ff8: mov     w8, #1                                     
02d35ffc: strb    w8, [x19, #0x117]                          
02d36000: ldr     x0, [x20]                                  T:type56879(k15)
02d36004: bl      #0x2b7104c                                 fn_2b7104c
02d36008: mov     x1, xzr                                    
02d3600c: mov     x19, x0                                    
02d36010: bl      #0x4e53e9c                                 System.Object::.ctor
02d36014: ldr     x8, [x20]                                  T:type56879(k15)
02d36018: mov     x1, x19                                    
02d3601c: ldr     x8, [x8, #0xb8]                            
02d36020: str     x19, [x8]                                  
02d36024: ldr     x8, [x20]                                  T:type56879(k15)
02d36028: ldp     x20, x19, [sp, #0x10]                      
02d3602c: ldr     x0, [x8, #0xb8]                            
02d36030: ldr     x30, [sp], #0x20                           
02d36034: b       #0x2b70d54                                 
## .ctor() -> void
---- BlindBagCollection.BlindbagCollectionController/<>c::.ctor 0x2d36038
02d36038: mov     x1, xzr                                    
02d3603c: b       #0x4e53e9c                                 System.Object::.ctor
## <OnGoToCollectionStep>b__28_1() -> void
---- BlindBagCollection.BlindbagCollectionController/<>c::<OnGoToCollectionStep>b__28_1 0x2d36040
02d36040: ret                                                
#### CLASS BlindBagCollection.BlindbagCollectionController parent= UnityEngine.MonoBehaviour
#   field bagIdList                      System.Collections.Generic.List`1<int>             off=0x0 attr=16 
#   field _blindBoxPlate                 BlindBagCollection.BlindBoxPlate                   off=0x20 attr=1 HeaderAttribute,SerializeField
#   field _openBagObject                 UnityEngine.GameObject                             off=0x28 attr=1 SerializeField
#   field _collectionObject              UnityEngine.GameObject                             off=0x30 attr=1 SerializeField
#   field _collectionBoxsetObject        UnityEngine.GameObject                             off=0x38 attr=1 SerializeField
#   field _homeButtonObject              UnityEngine.GameObject                             off=0x40 attr=1 SerializeField
#   field _dragController                BlindBagCollection.BlindbagDragController          off=0x48 attr=1 SerializeField
#   field _collectionAsset               BlindBagCollection.BlindbagCollectionAsset         off=0x50 attr=1 SpaceAttribute,HeaderAttribute,SerializeField
#   field _blindBagVisualAsset           ScoopGame.BlindBagVisualAsset                      off=0x58 attr=1 SerializeField
#   field _physics2DRaycaster            UnityEngine.EventSystems.Physics2DRaycaster        off=0x60 attr=1 SerializeField
#   field _blindBagSkinId                int                                                off=0x68 attr=1 
#   field _collectionDataUser            BlindBagCollection.BlindbagCollectionData          off=0x70 attr=1 
#   field _cacheDataItems                System.Collections.Generic.List`1<System.ValueTuple`3<BlindBagCollection.CollectionItemType,BlindBagCollection.CollectionBoxsetType,UnityEngine.Sprite>> off=0x78 attr=21 
#   field _unlockedItems                 System.Collections.Generic.List`1<System.ValueTuple`2<UnityEngine.Sprite,int>> off=0x80 attr=21 
#   field _lockedItemTypes               System.Collections.Generic.List`1<System.ValueTuple`2<BlindBagCollection.CollectionItemType,BlindBagCollection.CollectionBoxsetType>> off=0x88 attr=21 
#   field _checkDuplicateItems           System.Collections.Generic.List`1<System.ValueTuple`2<BlindBagCollection.CollectionItemType,BlindBagCollection.CollectionBoxsetType>> off=0x90 attr=21 
#   field _screenInGame                  BlindBagCollection.BlindbagGameScreen              off=0x98 attr=1 
#   field _gameSession                   GameSession                                        off=0xa0 attr=1 
#   field _cachedCaseID                  System.Collections.Generic.List`1<int>             off=0xa8 attr=1 
#   field _cachedDecorID                 System.Collections.Generic.List`1<int>             off=0xb0 attr=1 
## get_CachedCaseID() -> System.Collections.Generic.List`1<int>
---- BlindBagCollection.BlindbagCollectionController::get_CachedCaseID 0x2d32a84
02d32a84: ldr     x0, [x0, #0xa8]                            ._cachedCaseID
02d32a88: ret                                                
## get_CachedDecorID() -> System.Collections.Generic.List`1<int>
---- BlindBagCollection.BlindbagCollectionController::get_CachedDecorID 0x2d32a8c
02d32a8c: ldr     x0, [x0, #0xb0]                            ._cachedDecorID
02d32a90: ret                                                
## Start() -> void
---- BlindBagCollection.BlindbagCollectionController::Start 0x2d32a94
02d32a94: str     x30, [sp, #-0x20]!                         
02d32a98: stp     x20, x19, [sp, #0x10]                      
02d32a9c: adrp    x20, #0x6630000                            
02d32aa0: mov     x19, x0                                    
02d32aa4: ldrb    w8, [x20, #0x109]                          
02d32aa8: tbnz    w8, #0, #0x2d32afc                         
02d32aac: adrp    x0, #0x626a000                             
02d32ab0: ldr     x0, [x0, #0x800]                           MS:DataManager::GetData
02d32ab4: bl      #0x2b70db0                                 fn_2b70db0
02d32ab8: adrp    x0, #0x6267000                             
02d32abc: ldr     x0, [x0, #0xbd0]                           MS:MonoSingleton`1::get_Instance
02d32ac0: bl      #0x2b70db0                                 fn_2b70db0
02d32ac4: adrp    x0, #0x6266000                             
02d32ac8: ldr     x0, [x0, #0xac0]                           MS:MonoSingleton`1::get_Instance
02d32acc: bl      #0x2b70db0                                 fn_2b70db0
02d32ad0: adrp    x0, #0x6265000                             
02d32ad4: ldr     x0, [x0, #0x10]                            MS:MonoSingleton`1::get_Instance
02d32ad8: bl      #0x2b70db0                                 fn_2b70db0
02d32adc: adrp    x0, #0x6266000                             
02d32ae0: ldr     x0, [x0, #0x658]                           MS:MonoSingleton`1::get_Instance
02d32ae4: bl      #0x2b70db0                                 fn_2b70db0
02d32ae8: adrp    x0, #0x626a000                             
02d32aec: ldr     x0, [x0, #0x728]                           MS:UIManager::GetScreen
02d32af0: bl      #0x2b70db0                                 fn_2b70db0
02d32af4: mov     w8, #1                                     
02d32af8: strb    w8, [x20, #0x109]                          
02d32afc: mov     x0, xzr                                    
02d32b00: bl      #0x2d6eec8                                 Framework.AudioManager::get_Instance
02d32b04: cbz     x0, #0x2d32c30                             
02d32b08: adrp    x8, #0x1084000                             
02d32b0c: adrp    x20, #0x6266000                            
02d32b10: mov     x1, xzr                                    
02d32b14: ldr     s0, [x8, #0xfb0]                           [1084fb0]=3f7d70a43ecccccd f=0.4,0.99
02d32b18: ldr     x20, [x20, #0xac0]                         MS:MonoSingleton`1::get_Instance
02d32b1c: bl      #0x2d8545c                                 Framework.AudioManager::SetVolumeMusic
02d32b20: ldr     x0, [x20]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d32b24: bl      #0x3769600                                 fn_3769600
02d32b28: mov     x20, x19                                   
02d32b2c: mov     x1, x0                                     
02d32b30: str     x0, [x20, #0xa0]!                          ._gameSession
02d32b34: mov     x0, x20                                    
02d32b38: bl      #0x2b70d54                                 fn_2b70d54
02d32b3c: ldr     x0, [x20]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d32b40: cbz     x0, #0x2d32c30                             
02d32b44: mov     w1, wzr                                    
02d32b48: mov     x2, xzr                                    
02d32b4c: bl      #0x2cacd8c                                 GameSession::SetActiveCharacter
02d32b50: ldr     x0, [x19, #0x20]                           ._blindBoxPlate
02d32b54: cbz     x0, #0x2d32c30                             
02d32b58: mov     x1, xzr                                    
02d32b5c: bl      #0x5b339ec                                 UnityEngine.Component::get_gameObject
02d32b60: cbz     x0, #0x2d32c30                             
02d32b64: mov     w1, wzr                                    
02d32b68: mov     x2, xzr                                    
02d32b6c: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d32b70: ldr     x0, [x19, #0x60]                           ._physics2DRaycaster
02d32b74: cbz     x0, #0x2d32c30                             
02d32b78: adrp    x20, #0x6266000                            
02d32b7c: mov     w1, wzr                                    
02d32b80: mov     x2, xzr                                    
02d32b84: ldr     x20, [x20, #0x658]                         MS:MonoSingleton`1::get_Instance
02d32b88: bl      #0x5b33110                                 UnityEngine.Behaviour::set_enabled
02d32b8c: ldr     x0, [x20]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d32b90: bl      #0x3769600                                 fn_3769600
02d32b94: cbz     x0, #0x2d32c30                             
02d32b98: adrp    x8, #0x626a000                             
02d32b9c: adrp    x20, #0x6267000                            
02d32ba0: ldr     x8, [x8, #0x800]                           MS:DataManager::GetData
02d32ba4: ldr     x20, [x20, #0xbd0]                         MS:MonoSingleton`1::get_Instance
02d32ba8: ldr     x1, [x8]                                   T:type56879(k15)
02d32bac: bl      #0x3168dd0                                 fn_3168dd0
02d32bb0: mov     x1, x0                                     
02d32bb4: mov     x0, x19                                    
02d32bb8: str     x1, [x0, #0x70]!                           ._collectionDataUser
02d32bbc: bl      #0x2b70d54                                 fn_2b70d54
02d32bc0: ldr     x0, [x20]                                  S:'didu'
02d32bc4: bl      #0x3769600                                 fn_3769600
02d32bc8: cbz     x0, #0x2d32c30                             
02d32bcc: adrp    x8, #0x626a000                             
02d32bd0: ldr     x8, [x8, #0x728]                           MS:UIManager::GetScreen
02d32bd4: ldr     x1, [x8]                                   T:type56879(k15)
02d32bd8: bl      #0x33fbbd0                                 fn_33fbbd0
02d32bdc: mov     x20, x19                                   
02d32be0: mov     x1, x0                                     
02d32be4: str     x0, [x20, #0x98]!                          ._screenInGame
02d32be8: mov     x0, x20                                    
02d32bec: bl      #0x2b70d54                                 fn_2b70d54
02d32bf0: ldr     x0, [x20]                                  S:'didu'
02d32bf4: cbz     x0, #0x2d32c30                             
02d32bf8: ldr     x8, [x0]                                   T:type56879(k15)
02d32bfc: adrp    x20, #0x6265000                            
02d32c00: ldr     x20, [x20, #0x10]                          MS:MonoSingleton`1::get_Instance
02d32c04: ldp     x9, x1, [x8, #0x188]                       
02d32c08: blr     x9                                         
02d32c0c: ldr     x0, [x20]                                  M:AdsManager::<OnApplicationPause>b__26_0
02d32c10: bl      #0x3769600                                 fn_3769600
02d32c14: cbz     x0, #0x2d32c30                             
02d32c18: mov     x1, xzr                                    
02d32c1c: bl      #0x2cdff7c                                 SimpleSceneTransition::FadeOut
02d32c20: mov     x0, x19                                    
02d32c24: ldp     x20, x19, [sp, #0x10]                      
02d32c28: ldr     x30, [sp], #0x20                           
02d32c2c: b       #0x2d32c34                                 BlindBagCollection.BlindbagCollectionController::GoToStepBlindBox
02d32c30: bl      #0x2b7105c                                 fn_2b7105c
## GetBlindbagVisual() -> ScoopGame.BlindBagVisualDataItem
---- BlindBagCollection.BlindbagCollectionController::GetBlindbagVisual 0x2d32cb4
02d32cb4: ldr     x8, [x0, #0x58]                            ._blindBagVisualAsset
02d32cb8: cbz     x8, #0x2d32cc8                             
02d32cbc: ldr     w1, [x0, #0x68]                            ._blindBagSkinId
02d32cc0: mov     x0, x8                                     
02d32cc4: b       #0x2d32cd0                                 ScoopGame.BlindBagVisualAsset::GetData
02d32cc8: str     x30, [sp, #-0x10]!                         
02d32ccc: bl      #0x2b7105c                                 fn_2b7105c
## GoToStepBlindBox() -> void
---- BlindBagCollection.BlindbagCollectionController::GoToStepBlindBox 0x2d32c34
02d32c34: stp     x30, x19, [sp, #-0x10]!                    
02d32c38: mov     x19, x0                                    
02d32c3c: ldr     x0, [x0, #0x28]                            ._openBagObject
02d32c40: cbz     x0, #0x2d32cb0                             
02d32c44: mov     w1, #1                                     
02d32c48: mov     x2, xzr                                    
02d32c4c: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d32c50: ldr     x0, [x19, #0x20]                           ._blindBoxPlate
02d32c54: cbz     x0, #0x2d32cb0                             
02d32c58: mov     x1, xzr                                    
02d32c5c: bl      #0x5b339ec                                 UnityEngine.Component::get_gameObject
02d32c60: cbz     x0, #0x2d32cb0                             
02d32c64: mov     w1, #1                                     
02d32c68: mov     x2, xzr                                    
02d32c6c: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d32c70: ldr     x0, [x19, #0x60]                           ._physics2DRaycaster
02d32c74: cbz     x0, #0x2d32cb0                             
02d32c78: mov     w1, #1                                     
02d32c7c: mov     x2, xzr                                    
02d32c80: bl      #0x5b33110                                 UnityEngine.Behaviour::set_enabled
02d32c84: ldr     x0, [x19, #0x30]                           ._collectionObject
02d32c88: cbz     x0, #0x2d32cb0                             
02d32c8c: mov     w1, wzr                                    
02d32c90: mov     x2, xzr                                    
02d32c94: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d32c98: mov     x0, x19                                    
02d32c9c: bl      #0x2d32da8                                 BlindBagCollection.BlindbagCollectionController::SetupBlindBoxPlate
02d32ca0: ldr     x0, [x19, #0x98]                           ._screenInGame
02d32ca4: cbz     x0, #0x2d32cb0                             
02d32ca8: ldp     x30, x19, [sp], #0x10                      
02d32cac: b       #0x2d32ef0                                 BlindBagCollection.BlindbagGameScreen::ShowContentUnbox
02d32cb0: bl      #0x2b7105c                                 fn_2b7105c
## GoToCollectionStep() -> void
---- BlindBagCollection.BlindbagCollectionController::GoToCollectionStep 0x2d32f0c
02d32f0c: stp     x30, x21, [sp, #-0x20]!                    
02d32f10: stp     x20, x19, [sp, #0x10]                      
02d32f14: adrp    x20, #0x6630000                            
02d32f18: adrp    x21, #0x6266000                            
02d32f1c: mov     x19, x0                                    
02d32f20: ldrb    w8, [x20, #0x10a]                          
02d32f24: ldr     x21, [x21, #0x658]                         MS:MonoSingleton`1::get_Instance
02d32f28: tbnz    w8, #0, #0x2d32f4c                         
02d32f2c: adrp    x0, #0x6266000                             
02d32f30: ldr     x0, [x0, #0x750]                           MS:DataManager::GetData
02d32f34: bl      #0x2b70db0                                 fn_2b70db0
02d32f38: adrp    x0, #0x6266000                             
02d32f3c: ldr     x0, [x0, #0x658]                           MS:MonoSingleton`1::get_Instance
02d32f40: bl      #0x2b70db0                                 fn_2b70db0
02d32f44: mov     w8, #1                                     
02d32f48: strb    w8, [x20, #0x10a]                          
02d32f4c: ldr     x0, [x21]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d32f50: bl      #0x3769600                                 fn_3769600
02d32f54: cbz     x0, #0x2d32f98                             
02d32f58: adrp    x8, #0x6266000                             
02d32f5c: ldr     x8, [x8, #0x750]                           MS:DataManager::GetData
02d32f60: ldr     x1, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d32f64: bl      #0x3168dd0                                 fn_3168dd0
02d32f68: cbz     x0, #0x2d32f98                             
02d32f6c: ldr     x8, [x0, #0x20]                            S:'inter_ad_capping_time' ._blindBoxPlate
02d32f70: cbz     x8, #0x2d32f98                             
02d32f74: ldr     x0, [x19, #0x60]                           ._physics2DRaycaster
02d32f78: cbz     x0, #0x2d32f98                             
02d32f7c: mov     w1, wzr                                    
02d32f80: mov     x2, xzr                                    
02d32f84: bl      #0x5b33110                                 UnityEngine.Behaviour::set_enabled
02d32f88: mov     x0, x19                                    
02d32f8c: ldp     x20, x19, [sp, #0x10]                      
02d32f90: ldp     x30, x21, [sp], #0x20                      
02d32f94: b       #0x2d32f9c                                 BlindBagCollection.BlindbagCollectionController::OnGoToCollectionStep
02d32f98: bl      #0x2b7105c                                 fn_2b7105c
## OnGoToCollectionStep() -> void
---- BlindBagCollection.BlindbagCollectionController::OnGoToCollectionStep 0x2d32f9c
02d32f9c: stp     x30, x23, [sp, #-0x30]!                    
02d32fa0: stp     x22, x21, [sp, #0x10]                      
02d32fa4: stp     x20, x19, [sp, #0x20]                      
02d32fa8: adrp    x22, #0x6630000                            
02d32fac: adrp    x23, #0x6265000                            
02d32fb0: adrp    x20, #0x6264000                            
02d32fb4: adrp    x21, #0x626a000                            
02d32fb8: ldr     x23, [x23, #0x10]                          MS:MonoSingleton`1::get_Instance
02d32fbc: ldrb    w8, [x22, #0x10b]                          
02d32fc0: ldr     x20, [x20, #0xf90]                         T:System.Action
02d32fc4: ldr     x21, [x21, #0x838]                         M:BlindBagCollection.BlindbagCollectionController::<OnGoToCollectionStep>b__28_0
02d32fc8: mov     x19, x0                                    
02d32fcc: tbnz    w8, #0, #0x2d32ffc                         
02d32fd0: adrp    x0, #0x6264000                             
02d32fd4: ldr     x0, [x0, #0xf90]                           T:System.Action
02d32fd8: bl      #0x2b70db0                                 fn_2b70db0
02d32fdc: adrp    x0, #0x626a000                             
02d32fe0: ldr     x0, [x0, #0x838]                           M:BlindBagCollection.BlindbagCollectionController::<OnGoToCollectionStep>b__28_0
02d32fe4: bl      #0x2b70db0                                 fn_2b70db0
02d32fe8: adrp    x0, #0x6265000                             
02d32fec: ldr     x0, [x0, #0x10]                            MS:MonoSingleton`1::get_Instance
02d32ff0: bl      #0x2b70db0                                 fn_2b70db0
02d32ff4: mov     w8, #1                                     
02d32ff8: strb    w8, [x22, #0x10b]                          
02d32ffc: ldr     x0, [x23]                                  M:AdsManager::<OnApplicationPause>b__26_0
02d33000: bl      #0x3769600                                 fn_3769600
02d33004: ldr     x8, [x20]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d33008: mov     x20, x0                                    
02d3300c: mov     x0, x8                                     
02d33010: bl      #0x2b7104c                                 fn_2b7104c
02d33014: ldr     x2, [x21]                                  T:type56879(k15)
02d33018: mov     x1, x19                                    
02d3301c: mov     x3, xzr                                    
02d33020: mov     x21, x0                                    
02d33024: bl      #0x4d8ddbc                                 System.Action::.ctor
02d33028: cbz     x20, #0x2d33048                            
02d3302c: mov     x0, x20                                    
02d33030: mov     x1, x21                                    
02d33034: mov     x2, xzr                                    
02d33038: ldp     x20, x19, [sp, #0x20]                      
02d3303c: ldp     x22, x21, [sp, #0x10]                      
02d33040: ldp     x30, x23, [sp], #0x30                      
02d33044: b       #0x2cea318                                 SimpleSceneTransition::Transition
02d33048: bl      #0x2b7105c                                 fn_2b7105c
## SetupBlindBoxPlate() -> void
---- BlindBagCollection.BlindbagCollectionController::SetupBlindBoxPlate 0x2d32da8
02d32da8: stp     x30, x23, [sp, #-0x30]!                    
02d32dac: stp     x22, x21, [sp, #0x10]                      
02d32db0: stp     x20, x19, [sp, #0x20]                      
02d32db4: adrp    x20, #0x6630000                            
02d32db8: mov     x19, x0                                    
02d32dbc: ldrb    w8, [x20, #0x10c]                          
02d32dc0: tbnz    w8, #0, #0x2d32dfc                         
02d32dc4: adrp    x0, #0x626a000                             
02d32dc8: ldr     x0, [x0, #0x828]                           T:BlindBagCollection.BlindbagCollectionController
02d32dcc: bl      #0x2b70db0                                 fn_2b70db0
02d32dd0: adrp    x0, #0x626a000                             
02d32dd4: ldr     x0, [x0, #0x830]                           MS:System.Collections.Generic.List`1::Clear
02d32dd8: bl      #0x2b70db0                                 fn_2b70db0
02d32ddc: adrp    x0, #0x6268000                             
02d32de0: ldr     x0, [x0, #0xea8]                           MS:System.Collections.Generic.List`1::get_Count
02d32de4: bl      #0x2b70db0                                 fn_2b70db0
02d32de8: adrp    x0, #0x626a000                             
02d32dec: ldr     x0, [x0, #0x310]                           MS:System.Collections.Generic.List`1::get_Item
02d32df0: bl      #0x2b70db0                                 fn_2b70db0
02d32df4: mov     w8, #1                                     
02d32df8: strb    w8, [x20, #0x10c]                          
02d32dfc: ldr     x0, [x19, #0x20]                           ._blindBoxPlate
02d32e00: cbz     x0, #0x2d32eec                             
02d32e04: adrp    x22, #0x626a000                            
02d32e08: adrp    x23, #0x626a000                            
02d32e0c: ldr     x22, [x22, #0x828]                         T:BlindBagCollection.BlindbagCollectionController
02d32e10: ldr     x23, [x23, #0x310]                         MS:System.Collections.Generic.List`1::get_Item
02d32e14: bl      #0x2d3304c                                 BlindBagCollection.BlindBoxPlate::ClearPlate
02d32e18: mov     w20, wzr                                   
02d32e1c: ldr     x8, [x22]                                  T:type56879(k15)
02d32e20: ldr     w9, [x8, #0xe4]                            
02d32e24: cbnz    w9, #0x2d32e34                             
02d32e28: mov     x0, x8                                     
02d32e2c: bl      #0x2b70f30                                 fn_2b70f30
02d32e30: ldr     x8, [x22]                                  T:type56879(k15)
02d32e34: ldr     x9, [x8, #0xb8]                            
02d32e38: ldr     x0, [x9]                                   
02d32e3c: cbz     x0, #0x2d32eec                             
02d32e40: ldr     w9, [x0, #0x18]                            MS:System.Collections.Generic.List`1::Add
02d32e44: cmp     w20, w9                                    
02d32e48: b.ge    #0x2d32ea4                                 
02d32e4c: ldr     w9, [x8, #0xe4]                            
02d32e50: ldr     x21, [x19, #0x58]                          ._blindBagVisualAsset
02d32e54: cbnz    w9, #0x2d32e70                             
02d32e58: mov     x0, x8                                     
02d32e5c: bl      #0x2b70f30                                 fn_2b70f30
02d32e60: ldr     x8, [x22]                                  T:type56879(k15)
02d32e64: ldr     x8, [x8, #0xb8]                            
02d32e68: ldr     x0, [x8]                                   
02d32e6c: cbz     x0, #0x2d32eec                             
02d32e70: ldr     x2, [x23]                                  T:type56879(k15)
02d32e74: mov     w1, w20                                    
02d32e78: bl      #0x3569920                                 fn_3569920
02d32e7c: cbz     x21, #0x2d32eec                            
02d32e80: mov     w1, w0                                     
02d32e84: mov     x0, x21                                    
02d32e88: bl      #0x2d32cd0                                 ScoopGame.BlindBagVisualAsset::GetData
02d32e8c: cbz     x0, #0x2d32eec                             
02d32e90: ldr     x1, [x0, #0x18]                            MS:System.Collections.Generic.List`1::Add
02d32e94: mov     x0, x19                                    
02d32e98: bl      #0x2d33234                                 BlindBagCollection.BlindbagCollectionController::PickRandomItemAndSpawn
02d32e9c: add     w20, w20, #1                               
02d32ea0: b       #0x2d32e1c                                 
02d32ea4: ldr     w9, [x8, #0xe4]                            
02d32ea8: cbnz    w9, #0x2d32ec4                             
02d32eac: mov     x0, x8                                     
02d32eb0: bl      #0x2b70f30                                 fn_2b70f30
02d32eb4: ldr     x8, [x22]                                  T:type56879(k15)
02d32eb8: ldr     x8, [x8, #0xb8]                            
02d32ebc: ldr     x0, [x8]                                   
02d32ec0: cbz     x0, #0x2d32eec                             
02d32ec4: ldr     w9, [x0, #0x1c]                            [626a01c]=0 f=0,0
02d32ec8: ldr     x8, [x19, #0x20]                           ._blindBoxPlate
02d32ecc: add     w9, w9, #1                                 
02d32ed0: stp     wzr, w9, [x0, #0x18]                       
02d32ed4: cbz     x8, #0x2d32eec                             
02d32ed8: ldp     x20, x19, [sp, #0x20]                      
02d32edc: mov     x0, x8                                     
02d32ee0: ldp     x22, x21, [sp, #0x10]                      
02d32ee4: ldp     x30, x23, [sp], #0x30                      
02d32ee8: b       #0x2d33370                                 BlindBagCollection.BlindBoxPlate::AutoSpawnBlindBox
02d32eec: bl      #0x2b7105c                                 fn_2b7105c
## AddMoreBlindBox() -> void
---- BlindBagCollection.BlindbagCollectionController::AddMoreBlindBox 0x2d33488
02d33488: sub     sp, sp, #0x70                              
02d3348c: str     x30, [sp, #0x20]                           
02d33490: stp     x26, x25, [sp, #0x30]                      
02d33494: stp     x24, x23, [sp, #0x40]                      
02d33498: stp     x22, x21, [sp, #0x50]                      
02d3349c: stp     x20, x19, [sp, #0x60]                      
02d334a0: adrp    x19, #0x6630000                            
02d334a4: mov     x20, x0                                    
02d334a8: ldrb    w8, [x19, #0x10d]                          
02d334ac: tbnz    w8, #0, #0x2d334c4                         
02d334b0: adrp    x0, #0x6266000                             
02d334b4: ldr     x0, [x0, #0x818]                           MS:System.Collections.Generic.List`1::Add
02d334b8: bl      #0x2b70db0                                 fn_2b70db0
02d334bc: mov     w8, #1                                     
02d334c0: strb    w8, [x19, #0x10d]                          
02d334c4: add     x8, sp, #8                                 
02d334c8: mov     x0, x20                                    
02d334cc: bl      #0x2d335d4                                 BlindBagCollection.BlindbagCollectionController::GetRandomItemData
02d334d0: ldr     x0, [x20, #0x58]                           ._blindBagVisualAsset
02d334d4: cbz     x0, #0x2d335d0                             
02d334d8: ldp     w21, w22, [sp, #8]                         
02d334dc: ldp     w19, w24, [sp, #0x18]                      
02d334e0: ldr     x23, [sp, #0x10]                           
02d334e4: bl      #0x2d336c4                                 ScoopGame.BlindBagVisualAsset::GetRandomData
02d334e8: mov     x25, x0                                    
02d334ec: mov     w0, wzr                                    
02d334f0: mov     w1, #0x65                                  
02d334f4: mov     x2, xzr                                    
02d334f8: bl      #0x5b2e000                                 UnityEngine.Random::Range
02d334fc: ldr     x9, [x20, #0x50]                           ._collectionAsset
02d33500: cbz     x9, #0x2d335d0                             
02d33504: cbz     x25, #0x2d335d0                            
02d33508: ldr     x8, [x20, #0x20]                           ._blindBoxPlate
02d3350c: cbz     x8, #0x2d335d0                             
02d33510: ldr     w9, [x9, #0x28]                            
02d33514: adrp    x26, #0x6266000                            
02d33518: mov     x1, x23                                    
02d3351c: ldr     x26, [x26, #0x818]                         MS:System.Collections.Generic.List`1::Add
02d33520: ldr     x2, [x25, #0x18]                           
02d33524: mov     w4, w24                                    
02d33528: cmp     w0, w9                                     
02d3352c: mov     x0, x8                                     
02d33530: cset    w3, le                                     
02d33534: bl      #0x2d33740                                 BlindBagCollection.BlindBoxPlate::AddMoreRandomBox
02d33538: mov     x0, x20                                    
02d3353c: mov     w1, w21                                    
02d33540: mov     w2, w22                                    
02d33544: mov     x3, x23                                    
02d33548: bl      #0x2d33b64                                 BlindBagCollection.BlindbagCollectionController::AddItemToCacheIfNeeded
02d3354c: cbz     w21, #0x2d3355c                            
02d33550: ldr     x0, [x20, #0xb0]                           ._cachedDecorID
02d33554: cbnz    x0, #0x2d33564                             
02d33558: b       #0x2d335d0                                 
02d3355c: ldr     x0, [x20, #0xa8]                           ._cachedCaseID
02d33560: cbz     x0, #0x2d335d0                             
02d33564: ldr     w10, [x0, #0x1c]                           [626601c]=0 f=0,0
02d33568: ldr     x8, [x0, #0x10]                            S:'mrec_ad_on_off'
02d3356c: ldr     x9, [x26]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d33570: add     w10, w10, #1                               
02d33574: str     w10, [x0, #0x1c]                           
02d33578: cbz     x8, #0x2d335d0                             
02d3357c: ldrsw   x10, [x0, #0x18]                           
02d33580: ldr     w11, [x8, #0x18]                           
02d33584: cmp     w10, w11                                   
02d33588: b.hs    #0x2d335a0                                 
02d3358c: add     x8, x8, x10, lsl #2                        
02d33590: add     w9, w10, #1                                
02d33594: str     w9, [x0, #0x18]                            
02d33598: str     w19, [x8, #0x20]                           
02d3359c: b       #0x2d335b4                                 
02d335a0: ldr     x8, [x9, #0x20]                            
02d335a4: mov     w1, w19                                    
02d335a8: ldr     x8, [x8, #0xc0]                            
02d335ac: ldr     x2, [x8, #0x70]                            
02d335b0: bl      #0x3569c18                                 fn_3569c18
02d335b4: ldp     x20, x19, [sp, #0x60]                      
02d335b8: ldr     x30, [sp, #0x20]                           
02d335bc: ldp     x22, x21, [sp, #0x50]                      
02d335c0: ldp     x24, x23, [sp, #0x40]                      
02d335c4: ldp     x26, x25, [sp, #0x30]                      
02d335c8: add     sp, sp, #0x70                              
02d335cc: ret                                                
02d335d0: bl      #0x2b7105c                                 fn_2b7105c
## PickRandomItemAndSpawn(string skinName) -> void
---- BlindBagCollection.BlindbagCollectionController::PickRandomItemAndSpawn 0x2d33234
02d33234: sub     sp, sp, #0x70                              
02d33238: str     x30, [sp, #0x20]                           
02d3323c: stp     x26, x25, [sp, #0x30]                      
02d33240: stp     x24, x23, [sp, #0x40]                      
02d33244: stp     x22, x21, [sp, #0x50]                      
02d33248: stp     x20, x19, [sp, #0x60]                      
02d3324c: adrp    x19, #0x6630000                            
02d33250: mov     x21, x1                                    
02d33254: mov     x20, x0                                    
02d33258: ldrb    w8, [x19, #0x10e]                          
02d3325c: tbnz    w8, #0, #0x2d33274                         
02d33260: adrp    x0, #0x6266000                             
02d33264: ldr     x0, [x0, #0x818]                           MS:System.Collections.Generic.List`1::Add
02d33268: bl      #0x2b70db0                                 fn_2b70db0
02d3326c: mov     w8, #1                                     
02d33270: strb    w8, [x19, #0x10e]                          
02d33274: add     x8, sp, #8                                 
02d33278: mov     x0, x20                                    
02d3327c: bl      #0x2d335d4                                 BlindBagCollection.BlindbagCollectionController::GetRandomItemData
02d33280: ldp     w22, w23, [sp, #8]                         
02d33284: ldp     w19, w25, [sp, #0x18]                      
02d33288: ldr     x24, [sp, #0x10]                           
02d3328c: mov     w0, wzr                                    
02d33290: mov     w1, #0x65                                  
02d33294: mov     x2, xzr                                    
02d33298: bl      #0x5b2e000                                 UnityEngine.Random::Range
02d3329c: ldr     x9, [x20, #0x50]                           ._collectionAsset
02d332a0: cbz     x9, #0x2d3336c                             
02d332a4: ldr     x8, [x20, #0x20]                           ._blindBoxPlate
02d332a8: cbz     x8, #0x2d3336c                             
02d332ac: ldr     w9, [x9, #0x28]                            
02d332b0: adrp    x26, #0x6266000                            
02d332b4: mov     x1, x24                                    
02d332b8: ldr     x26, [x26, #0x818]                         MS:System.Collections.Generic.List`1::Add
02d332bc: mov     x2, x21                                    
02d332c0: mov     w4, w25                                    
02d332c4: cmp     w0, w9                                     
02d332c8: mov     x0, x8                                     
02d332cc: cset    w3, le                                     
02d332d0: bl      #0x2d33fb4                                 BlindBagCollection.BlindBoxPlate::SpawnBlindBox
02d332d4: mov     x0, x20                                    
02d332d8: mov     w1, w22                                    
02d332dc: mov     w2, w23                                    
02d332e0: mov     x3, x24                                    
02d332e4: bl      #0x2d33b64                                 BlindBagCollection.BlindbagCollectionController::AddItemToCacheIfNeeded
02d332e8: cbz     w22, #0x2d332f8                            
02d332ec: ldr     x0, [x20, #0xb0]                           ._cachedDecorID
02d332f0: cbnz    x0, #0x2d33300                             
02d332f4: b       #0x2d3336c                                 
02d332f8: ldr     x0, [x20, #0xa8]                           ._cachedCaseID
02d332fc: cbz     x0, #0x2d3336c                             
02d33300: ldr     w10, [x0, #0x1c]                           [626601c]=0 f=0,0
02d33304: ldr     x8, [x0, #0x10]                            S:'mrec_ad_on_off'
02d33308: ldr     x9, [x26]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d3330c: add     w10, w10, #1                               
02d33310: str     w10, [x0, #0x1c]                           
02d33314: cbz     x8, #0x2d3336c                             
02d33318: ldrsw   x10, [x0, #0x18]                           
02d3331c: ldr     w11, [x8, #0x18]                           
02d33320: cmp     w10, w11                                   
02d33324: b.hs    #0x2d3333c                                 
02d33328: add     x8, x8, x10, lsl #2                        
02d3332c: add     w9, w10, #1                                
02d33330: str     w9, [x0, #0x18]                            
02d33334: str     w19, [x8, #0x20]                           
02d33338: b       #0x2d33350                                 
02d3333c: ldr     x8, [x9, #0x20]                            
02d33340: mov     w1, w19                                    
02d33344: ldr     x8, [x8, #0xc0]                            
02d33348: ldr     x2, [x8, #0x70]                            
02d3334c: bl      #0x3569c18                                 fn_3569c18
02d33350: ldp     x20, x19, [sp, #0x60]                      
02d33354: ldr     x30, [sp, #0x20]                           
02d33358: ldp     x22, x21, [sp, #0x50]                      
02d3335c: ldp     x24, x23, [sp, #0x40]                      
02d33360: ldp     x26, x25, [sp, #0x30]                      
02d33364: add     sp, sp, #0x70                              
02d33368: ret                                                
02d3336c: bl      #0x2b7105c                                 fn_2b7105c
## GetRandomItemData() -> System.ValueTuple`5<BlindBagCollection.CollectionItemType,BlindBagCollection.CollectionBoxsetType,UnityEngine.Sprite,int,RarityType>
---- BlindBagCollection.BlindbagCollectionController::GetRandomItemData 0x2d335d4
02d335d4: str     x30, [sp, #-0x40]!                         
02d335d8: stp     x24, x23, [sp, #0x10]                      
02d335dc: stp     x22, x21, [sp, #0x20]                      
02d335e0: stp     x20, x19, [sp, #0x30]                      
02d335e4: adrp    x21, #0x6630000                            
02d335e8: mov     x20, x0                                    
02d335ec: mov     x19, x8                                    
02d335f0: ldrb    w9, [x21, #0x10f]                          
02d335f4: tbnz    w9, #0, #0x2d3360c                         
02d335f8: adrp    x0, #0x626a000                             
02d335fc: ldr     x0, [x0, #0x880]                           MS:System.ValueTuple`5::.ctor
02d33600: bl      #0x2b70db0                                 fn_2b70db0
02d33604: mov     w8, #1                                     
02d33608: strb    w8, [x21, #0x10f]                          
02d3360c: ldr     x0, [x20, #0x50]                           ._collectionAsset
02d33610: cbz     x0, #0x2d336c0                             
02d33614: bl      #0x2d342ac                                 BlindBagCollection.BlindbagCollectionAsset::GetRandomCollectionItemType
02d33618: ldr     x8, [x20, #0x50]                           ._collectionAsset
02d3361c: cbz     x8, #0x2d336c0                             
02d33620: mov     w21, w0                                    
02d33624: mov     x0, x8                                     
02d33628: bl      #0x2d34850                                 BlindBagCollection.BlindbagCollectionAsset::GetRandomCollectionBoxsetType
02d3362c: ldr     x8, [x20, #0x50]                           ._collectionAsset
02d33630: cbz     x8, #0x2d336c0                             
02d33634: mov     w22, w0                                    
02d33638: mov     x0, x8                                     
02d3363c: mov     w1, w21                                    
02d33640: mov     w2, w22                                    
02d33644: bl      #0x2d348e0                                 BlindBagCollection.BlindbagCollectionAsset::GetItemSprite
02d33648: ldr     x8, [x20, #0x50]                           ._collectionAsset
02d3364c: cbz     x8, #0x2d336c0                             
02d33650: mov     x23, x0                                    
02d33654: mov     x0, x8                                     
02d33658: mov     w1, w21                                    
02d3365c: mov     w2, w22                                    
02d33660: bl      #0x2d34b78                                 BlindBagCollection.BlindbagCollectionAsset::GetItemID
02d33664: ldr     x8, [x20, #0x50]                           ._collectionAsset
02d33668: cbz     x8, #0x2d336c0                             
02d3366c: adrp    x24, #0x626a000                            
02d33670: mov     w20, w0                                    
02d33674: mov     x0, x8                                     
02d33678: ldr     x24, [x24, #0x880]                         MS:System.ValueTuple`5::.ctor
02d3367c: mov     w1, w21                                    
02d33680: mov     w2, w22                                    
02d33684: bl      #0x2d34e80                                 BlindBagCollection.BlindbagCollectionAsset::GetRarity
02d33688: mov     w5, w0                                     
02d3368c: stp     xzr, xzr, [x19, #8]                        
02d33690: ldr     x6, [x24]                                  T:type56879(k15)
02d33694: str     xzr, [x19]                                 
02d33698: mov     x0, x19                                    
02d3369c: mov     w1, w21                                    
02d336a0: mov     w2, w22                                    
02d336a4: mov     x3, x23                                    
02d336a8: mov     w4, w20                                    
02d336ac: ldp     x20, x19, [sp, #0x30]                      
02d336b0: ldp     x22, x21, [sp, #0x20]                      
02d336b4: ldp     x24, x23, [sp, #0x10]                      
02d336b8: ldr     x30, [sp], #0x40                           
02d336bc: b       #0x40fac94                                 
02d336c0: bl      #0x2b7105c                                 fn_2b7105c
## AddItemToCacheIfNeeded(BlindBagCollection.CollectionItemType itemType, BlindBagCollection.CollectionBoxsetType boxsetType, UnityEngine.Sprite itemSprite) -> void
---- BlindBagCollection.BlindbagCollectionController::AddItemToCacheIfNeeded 0x2d33b64
02d33b64: sub     sp, sp, #0x60                              
02d33b68: stp     x30, x25, [sp, #0x20]                      
02d33b6c: stp     x24, x23, [sp, #0x30]                      
02d33b70: stp     x22, x21, [sp, #0x40]                      
02d33b74: stp     x20, x19, [sp, #0x50]                      
02d33b78: adrp    x23, #0x6630000                            
02d33b7c: adrp    x24, #0x626a000                            
02d33b80: mov     x19, x3                                    
02d33b84: ldrb    w8, [x23, #0x110]                          
02d33b88: ldr     x24, [x24, #0x8c0]                         MS:System.ValueTuple`2::.ctor
02d33b8c: mov     w22, w2                                    
02d33b90: mov     w21, w1                                    
02d33b94: mov     x20, x0                                    
02d33b98: tbnz    w8, #0, #0x2d33bf8                         
02d33b9c: adrp    x0, #0x626a000                             
02d33ba0: ldr     x0, [x0, #0x8c8]                           MS:System.Collections.Generic.List`1::Add
02d33ba4: bl      #0x2b70db0                                 fn_2b70db0
02d33ba8: adrp    x0, #0x626a000                             
02d33bac: ldr     x0, [x0, #0x8d0]                           MS:System.Collections.Generic.List`1::Add
02d33bb0: bl      #0x2b70db0                                 fn_2b70db0
02d33bb4: adrp    x0, #0x626a000                             
02d33bb8: ldr     x0, [x0, #0x8d8]                           MS:System.Collections.Generic.List`1::Add
02d33bbc: bl      #0x2b70db0                                 fn_2b70db0
02d33bc0: adrp    x0, #0x626a000                             
02d33bc4: ldr     x0, [x0, #0x8e0]                           MS:System.Collections.Generic.List`1::Contains
02d33bc8: bl      #0x2b70db0                                 fn_2b70db0
02d33bcc: adrp    x0, #0x626a000                             
02d33bd0: ldr     x0, [x0, #0x8c0]                           MS:System.ValueTuple`2::.ctor
02d33bd4: bl      #0x2b70db0                                 fn_2b70db0
02d33bd8: adrp    x0, #0x626a000                             
02d33bdc: ldr     x0, [x0, #0x8e8]                           MS:System.ValueTuple`2::.ctor
02d33be0: bl      #0x2b70db0                                 fn_2b70db0
02d33be4: adrp    x0, #0x626a000                             
02d33be8: ldr     x0, [x0, #0x8f0]                           MS:System.ValueTuple`3::.ctor
02d33bec: bl      #0x2b70db0                                 fn_2b70db0
02d33bf0: mov     w8, #1                                     
02d33bf4: strb    w8, [x23, #0x110]                          
02d33bf8: ldr     x3, [x24]                                  T:type56879(k15)
02d33bfc: ldr     x23, [x20, #0x88]                          ._lockedItemTypes
02d33c00: add     x0, sp, #0x10                              
02d33c04: mov     w1, w21                                    
02d33c08: mov     w2, w22                                    
02d33c0c: str     xzr, [sp, #0x10]                           
02d33c10: bl      #0x407951c                                 fn_407951c
02d33c14: cbz     x23, #0x2d33fb0                            
02d33c18: adrp    x25, #0x626a000                            
02d33c1c: mov     x0, x23                                    
02d33c20: ldr     x25, [x25, #0x8e0]                         MS:System.Collections.Generic.List`1::Contains
02d33c24: ldr     x1, [sp, #0x10]                            
02d33c28: ldr     x2, [x25]                                  T:type56879(k15)
02d33c2c: bl      #0x4b85aac                                 fn_4b85aac
02d33c30: tbnz    w0, #0, #0x2d33d44                         
02d33c34: adrp    x8, #0x626a000                             
02d33c38: add     x0, sp, #0x10                              
02d33c3c: mov     w1, w21                                    
02d33c40: ldr     x8, [x8, #0x8f0]                           MS:System.ValueTuple`3::.ctor
02d33c44: ldr     x23, [x20, #0x78]                          ._cacheDataItems
02d33c48: mov     w2, w22                                    
02d33c4c: mov     x3, x19                                    
02d33c50: stp     xzr, xzr, [sp, #0x10]                      
02d33c54: ldr     x4, [x8]                                   T:type56879(k15)
02d33c58: bl      #0x4097d34                                 fn_4097d34
02d33c5c: cbz     x23, #0x2d33fb0                            
02d33c60: adrp    x9, #0x626a000                             
02d33c64: ldr     x9, [x9, #0x8c8]                           MS:System.Collections.Generic.List`1::Add
02d33c68: ldr     w10, [x23, #0x1c]                          
02d33c6c: ldr     x8, [x23, #0x10]                           
02d33c70: ldp     x1, x2, [sp, #0x10]                        
02d33c74: ldr     x9, [x9]                                   T:type56879(k15)
02d33c78: add     w10, w10, #1                               
02d33c7c: str     w10, [x23, #0x1c]                          
02d33c80: cbz     x8, #0x2d33fb0                             
02d33c84: ldrsw   x10, [x23, #0x18]                          
02d33c88: ldr     w11, [x8, #0x18]                           MS:System.Collections.Generic.List`1::Add
02d33c8c: cmp     w10, w11                                   
02d33c90: b.hs    #0x2d33cb4                                 
02d33c94: add     x0, x8, x10, lsl #4                        &626a000
02d33c98: add     w9, w10, #1                                
02d33c9c: str     w9, [x23, #0x18]                           
02d33ca0: str     x2, [x0, #0x28]!                           ._openBagObject
02d33ca4: stur    x1, [x0, #-8]                              
02d33ca8: mov     x1, xzr                                    
02d33cac: bl      #0x2b70d54                                 fn_2b70d54
02d33cb0: b       #0x2d33cc8                                 
02d33cb4: ldr     x8, [x9, #0x20]                            M:Decor.DataDecor/<>c__DisplayClass8_0::<NewData>b__0
02d33cb8: mov     x0, x23                                    
02d33cbc: ldr     x8, [x8, #0xc0]                            S:'Main character is null'
02d33cc0: ldr     x3, [x8, #0x70]                            MS:System.Collections.Generic.List`1::FindIndex
02d33cc4: bl      #0x4b9b21c                                 fn_4b9b21c
02d33cc8: ldr     x3, [x24]                                  T:type56879(k15)
02d33ccc: ldr     x23, [x20, #0x88]                          ._lockedItemTypes
02d33cd0: add     x0, sp, #8                                 
02d33cd4: mov     w1, w21                                    
02d33cd8: mov     w2, w22                                    
02d33cdc: str     xzr, [sp, #8]                              
02d33ce0: bl      #0x407951c                                 fn_407951c
02d33ce4: cbz     x23, #0x2d33fb0                            
02d33ce8: adrp    x9, #0x626a000                             
02d33cec: ldr     x9, [x9, #0x8d8]                           MS:System.Collections.Generic.List`1::Add
02d33cf0: ldr     w10, [x23, #0x1c]                          
02d33cf4: ldr     x8, [x23, #0x10]                           
02d33cf8: ldr     x1, [sp, #8]                               
02d33cfc: ldr     x9, [x9]                                   T:type56879(k15)
02d33d00: add     w10, w10, #1                               
02d33d04: str     w10, [x23, #0x1c]                          
02d33d08: cbz     x8, #0x2d33fb0                             
02d33d0c: ldrsw   x10, [x23, #0x18]                          
02d33d10: ldr     w11, [x8, #0x18]                           MS:System.Collections.Generic.List`1::Add
02d33d14: cmp     w10, w11                                   
02d33d18: b.hs    #0x2d33d30                                 
02d33d1c: add     x8, x8, x10, lsl #3                        &626a000
02d33d20: add     w9, w10, #1                                
02d33d24: str     w9, [x23, #0x18]                           
02d33d28: str     x1, [x8, #0x20]                            
02d33d2c: b       #0x2d33d44                                 
02d33d30: ldr     x8, [x9, #0x20]                            M:Decor.DataDecor/<>c__DisplayClass8_0::<NewData>b__0
02d33d34: mov     x0, x23                                    
02d33d38: ldr     x8, [x8, #0xc0]                            S:'Main character is null'
02d33d3c: ldr     x2, [x8, #0x70]                            MS:System.Collections.Generic.List`1::FindIndex
02d33d40: bl      #0x4b8572c                                 fn_4b8572c
02d33d44: ldr     x3, [x24]                                  T:type56879(k15)
02d33d48: ldr     x23, [x20, #0x90]                          ._checkDuplicateItems
02d33d4c: add     x0, sp, #0x10                              
02d33d50: mov     w1, w21                                    
02d33d54: mov     w2, w22                                    
02d33d58: str     xzr, [sp, #0x10]                           
02d33d5c: bl      #0x407951c                                 fn_407951c
02d33d60: cbz     x23, #0x2d33fb0                            
02d33d64: ldr     x1, [sp, #0x10]                            
02d33d68: ldr     x2, [x25]                                  T:type56879(k15)
02d33d6c: mov     x0, x23                                    
02d33d70: bl      #0x4b85aac                                 fn_4b85aac
02d33d74: tbz     w0, #0, #0x2d33e28                         
02d33d78: ldr     x8, [x20, #0x50]                           ._collectionAsset
02d33d7c: cbz     x8, #0x2d33fb0                             
02d33d80: cmp     w21, #0                                    
02d33d84: mov     w9, #0x24                                  
02d33d88: mov     w10, #0x1c                                 
02d33d8c: mov     w11, #0x20                                 
02d33d90: mov     w12, #0x18                                 
02d33d94: csel    x9, x10, x9, eq                            
02d33d98: csel    x10, x12, x11, eq                          
02d33d9c: ldr     x23, [x20, #0x80]                          ._unlockedItems
02d33da0: mov     x2, xzr                                    
02d33da4: ldr     w0, [x8, x10]                              T:type56879(k15)
02d33da8: ldr     w8, [x8, x9]                               T:type56879(k15)
02d33dac: add     w1, w8, #1                                 
02d33db0: bl      #0x5b2e000                                 UnityEngine.Random::Range
02d33db4: adrp    x8, #0x626a000                             
02d33db8: mov     w2, w0                                     
02d33dbc: add     x0, sp, #0x10                              
02d33dc0: ldr     x8, [x8, #0x8e8]                           MS:System.ValueTuple`2::.ctor
02d33dc4: mov     x1, x19                                    
02d33dc8: stp     xzr, xzr, [sp, #0x10]                      
02d33dcc: ldr     x3, [x8]                                   T:type56879(k15)
02d33dd0: bl      #0x407ed98                                 fn_407ed98
02d33dd4: cbz     x23, #0x2d33fb0                            
02d33dd8: adrp    x9, #0x626a000                             
02d33ddc: ldr     x9, [x9, #0x8d0]                           MS:System.Collections.Generic.List`1::Add
02d33de0: ldr     w10, [x23, #0x1c]                          
02d33de4: ldr     x8, [x23, #0x10]                           
02d33de8: ldp     x1, x2, [sp, #0x10]                        
02d33dec: ldr     x9, [x9]                                   T:type56879(k15)
02d33df0: add     w10, w10, #1                               
02d33df4: str     w10, [x23, #0x1c]                          
02d33df8: cbz     x8, #0x2d33fb0                             
02d33dfc: ldrsw   x10, [x23, #0x18]                          
02d33e00: ldr     w11, [x8, #0x18]                           MS:System.Collections.Generic.List`1::Add
02d33e04: cmp     w10, w11                                   
02d33e08: b.hs    #0x2d33ea8                                 
02d33e0c: add     x0, x8, x10, lsl #4                        &626a000
02d33e10: add     w9, w10, #1                                
02d33e14: str     w9, [x23, #0x18]                           
02d33e18: stp     x1, x2, [x0, #0x20]!                       ._blindBoxPlate
02d33e1c: mov     x1, xzr                                    
02d33e20: bl      #0x2b70d54                                 fn_2b70d54
02d33e24: b       #0x2d33ebc                                 
02d33e28: ldr     x3, [x24]                                  T:type56879(k15)
02d33e2c: ldr     x23, [x20, #0x90]                          ._checkDuplicateItems
02d33e30: add     x0, sp, #0x10                              
02d33e34: mov     w1, w21                                    
02d33e38: mov     w2, w22                                    
02d33e3c: str     xzr, [sp, #0x10]                           
02d33e40: bl      #0x407951c                                 fn_407951c
02d33e44: cbz     x23, #0x2d33fb0                            
02d33e48: adrp    x9, #0x626a000                             
02d33e4c: ldr     x9, [x9, #0x8d8]                           MS:System.Collections.Generic.List`1::Add
02d33e50: ldr     w10, [x23, #0x1c]                          
02d33e54: ldr     x8, [x23, #0x10]                           
02d33e58: ldr     x1, [sp, #0x10]                            
02d33e5c: ldr     x9, [x9]                                   T:type56879(k15)
02d33e60: add     w10, w10, #1                               
02d33e64: str     w10, [x23, #0x1c]                          
02d33e68: cbz     x8, #0x2d33fb0                             
02d33e6c: ldrsw   x10, [x23, #0x18]                          
02d33e70: ldr     w11, [x8, #0x18]                           MS:System.Collections.Generic.List`1::Add
02d33e74: cmp     w10, w11                                   
02d33e78: b.hs    #0x2d33e90                                 
02d33e7c: add     x8, x8, x10, lsl #3                        &626a000
02d33e80: add     w9, w10, #1                                
02d33e84: str     w9, [x23, #0x18]                           
02d33e88: str     x1, [x8, #0x20]                            
02d33e8c: b       #0x2d33ebc                                 
02d33e90: ldr     x8, [x9, #0x20]                            M:Decor.DataDecor/<>c__DisplayClass8_0::<NewData>b__0
02d33e94: mov     x0, x23                                    
02d33e98: ldr     x8, [x8, #0xc0]                            S:'Main character is null'
02d33e9c: ldr     x2, [x8, #0x70]                            MS:System.Collections.Generic.List`1::FindIndex
02d33ea0: bl      #0x4b8572c                                 fn_4b8572c
02d33ea4: b       #0x2d33ebc                                 
02d33ea8: ldr     x8, [x9, #0x20]                            M:Decor.DataDecor/<>c__DisplayClass8_0::<NewData>b__0
02d33eac: mov     x0, x23                                    
02d33eb0: ldr     x8, [x8, #0xc0]                            S:'Main character is null'
02d33eb4: ldr     x3, [x8, #0x70]                            MS:System.Collections.Generic.List`1::FindIndex
02d33eb8: bl      #0x4b8af34                                 fn_4b8af34
02d33ebc: ldr     x0, [x20, #0x70]                           ._collectionDataUser
02d33ec0: cbz     x0, #0x2d33fb0                             
02d33ec4: mov     w1, w22                                    
02d33ec8: mov     w2, w21                                    
02d33ecc: bl      #0x2d3521c                                 BlindBagCollection.BlindbagCollectionData::IsUnlocked
02d33ed0: tbz     w0, #0, #0x2d33f98                         
02d33ed4: ldr     x8, [x20, #0x50]                           ._collectionAsset
02d33ed8: cbz     x8, #0x2d33fb0                             
02d33edc: cmp     w21, #0                                    
02d33ee0: mov     w9, #0x24                                  
02d33ee4: mov     w10, #0x1c                                 
02d33ee8: mov     w11, #0x20                                 
02d33eec: mov     w12, #0x18                                 
02d33ef0: csel    x9, x10, x9, eq                            
02d33ef4: csel    x10, x12, x11, eq                          
02d33ef8: ldr     x20, [x20, #0x80]                          ._unlockedItems
02d33efc: mov     x2, xzr                                    
02d33f00: ldr     w0, [x8, x10]                              T:type56879(k15)
02d33f04: ldr     w8, [x8, x9]                               T:type56879(k15)
02d33f08: add     w1, w8, #1                                 
02d33f0c: bl      #0x5b2e000                                 UnityEngine.Random::Range
02d33f10: adrp    x8, #0x626a000                             
02d33f14: mov     w2, w0                                     
02d33f18: add     x0, sp, #0x10                              
02d33f1c: ldr     x8, [x8, #0x8e8]                           MS:System.ValueTuple`2::.ctor
02d33f20: mov     x1, x19                                    
02d33f24: stp     xzr, xzr, [sp, #0x10]                      
02d33f28: ldr     x3, [x8]                                   T:type56879(k15)
02d33f2c: bl      #0x407ed98                                 fn_407ed98
02d33f30: cbz     x20, #0x2d33fb0                            
02d33f34: adrp    x9, #0x626a000                             
02d33f38: ldr     x9, [x9, #0x8d0]                           MS:System.Collections.Generic.List`1::Add
02d33f3c: ldr     w10, [x20, #0x1c]                          
02d33f40: ldr     x8, [x20, #0x10]                           
02d33f44: ldp     x1, x2, [sp, #0x10]                        
02d33f48: ldr     x9, [x9]                                   T:type56879(k15)
02d33f4c: add     w10, w10, #1                               
02d33f50: str     w10, [x20, #0x1c]                          
02d33f54: cbz     x8, #0x2d33fb0                             
02d33f58: ldrsw   x10, [x20, #0x18]                          
02d33f5c: ldr     w11, [x8, #0x18]                           MS:System.Collections.Generic.List`1::Add
02d33f60: cmp     w10, w11                                   
02d33f64: b.hs    #0x2d33f84                                 
02d33f68: add     x0, x8, x10, lsl #4                        &626a000
02d33f6c: add     w9, w10, #1                                
02d33f70: str     w9, [x20, #0x18]                           
02d33f74: stp     x1, x2, [x0, #0x20]!                       ._blindBoxPlate
02d33f78: mov     x1, xzr                                    
02d33f7c: bl      #0x2b70d54                                 fn_2b70d54
02d33f80: b       #0x2d33f98                                 
02d33f84: ldr     x8, [x9, #0x20]                            M:Decor.DataDecor/<>c__DisplayClass8_0::<NewData>b__0
02d33f88: mov     x0, x20                                    
02d33f8c: ldr     x8, [x8, #0xc0]                            S:'Main character is null'
02d33f90: ldr     x3, [x8, #0x70]                            MS:System.Collections.Generic.List`1::FindIndex
02d33f94: bl      #0x4b8af34                                 fn_4b8af34
02d33f98: ldp     x20, x19, [sp, #0x50]                      
02d33f9c: ldp     x22, x21, [sp, #0x40]                      
02d33fa0: ldp     x24, x23, [sp, #0x30]                      
02d33fa4: ldp     x30, x25, [sp, #0x20]                      
02d33fa8: add     sp, sp, #0x60                              
02d33fac: ret                                                
02d33fb0: bl      #0x2b7105c                                 fn_2b7105c
## IsDoneUnbox() -> bool
---- BlindBagCollection.BlindbagCollectionController::IsDoneUnbox 0x2d3533c
02d3533c: ldr     x0, [x0, #0x20]                            ._blindBoxPlate
02d35340: cbz     x0, #0x2d35348                             
02d35344: b       #0x2d35350                                 BlindBagCollection.BlindBoxPlate::get_DoneUnbox
02d35348: str     x30, [sp, #-0x10]!                         
02d3534c: bl      #0x2b7105c                                 fn_2b7105c
## OnCollectionComplete() -> void
---- BlindBagCollection.BlindbagCollectionController::OnCollectionComplete 0x2d354f8
02d354f8: str     x30, [sp, #-0x20]!                         
02d354fc: stp     x20, x19, [sp, #0x10]                      
02d35500: adrp    x20, #0x6630000                            
02d35504: mov     x19, x0                                    
02d35508: ldrb    w8, [x20, #0x111]                          
02d3550c: tbnz    w8, #0, #0x2d35530                         
02d35510: adrp    x0, #0x6267000                             
02d35514: ldr     x0, [x0, #0xbd0]                           MS:MonoSingleton`1::get_Instance
02d35518: bl      #0x2b70db0                                 fn_2b70db0
02d3551c: adrp    x0, #0x626a000                             
02d35520: ldr     x0, [x0, #0xa08]                           MS:UIManager::ShowPopup
02d35524: bl      #0x2b70db0                                 fn_2b70db0
02d35528: mov     w8, #1                                     
02d3552c: strb    w8, [x20, #0x111]                          
02d35530: ldr     x0, [x19, #0x38]                           ._collectionBoxsetObject
02d35534: cbz     x0, #0x2d3559c                             
02d35538: mov     w1, wzr                                    
02d3553c: mov     x2, xzr                                    
02d35540: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d35544: ldr     x8, [x19, #0x98]                           ._screenInGame
02d35548: cbz     x8, #0x2d3559c                             
02d3554c: ldr     x0, [x8, #0x38]                            
02d35550: cbz     x0, #0x2d3559c                             
02d35554: mov     w1, #1                                     
02d35558: mov     x2, xzr                                    
02d3555c: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d35560: ldr     x0, [x19, #0x98]                           ._screenInGame
02d35564: cbz     x0, #0x2d3559c                             
02d35568: adrp    x19, #0x6267000                            
02d3556c: mov     w1, wzr                                    
02d35570: ldr     x19, [x19, #0xbd0]                         MS:MonoSingleton`1::get_Instance
02d35574: bl      #0x2d355bc                                 BlindBagCollection.BlindbagGameScreen::ShowChatContent
02d35578: ldr     x0, [x19]                                  S:'didu'
02d3557c: bl      #0x3769600                                 fn_3769600
02d35580: cbz     x0, #0x2d3559c                             
02d35584: adrp    x8, #0x626a000                             
02d35588: ldr     x8, [x8, #0xa08]                           MS:UIManager::ShowPopup
02d3558c: ldp     x20, x19, [sp, #0x10]                      
02d35590: ldr     x1, [x8]                                   T:type56879(k15)
02d35594: ldr     x30, [sp], #0x20                           
02d35598: b       #0x33fbfac                                 
02d3559c: bl      #0x2b7105c                                 fn_2b7105c
## OnDestroy() -> void
---- BlindBagCollection.BlindbagCollectionController::OnDestroy 0x2d35640
02d35640: str     x30, [sp, #-0x20]!                         
02d35644: stp     x20, x19, [sp, #0x10]                      
02d35648: adrp    x20, #0x6630000                            
02d3564c: mov     x19, x0                                    
02d35650: ldrb    w8, [x20, #0x112]                          
02d35654: tbnz    w8, #0, #0x2d3566c                         
02d35658: adrp    x0, #0x626a000                             
02d3565c: ldr     x0, [x0, #0x830]                           MS:System.Collections.Generic.List`1::Clear
02d35660: bl      #0x2b70db0                                 fn_2b70db0
02d35664: mov     w8, #1                                     
02d35668: strb    w8, [x20, #0x112]                          
02d3566c: ldr     x8, [x19, #0xa8]                           ._cachedCaseID
02d35670: cbz     x8, #0x2d356a0                             
02d35674: ldr     w10, [x8, #0x1c]                           
02d35678: ldr     x9, [x19, #0xb0]                           ._cachedDecorID
02d3567c: add     w10, w10, #1                               
02d35680: stp     wzr, w10, [x8, #0x18]                      
02d35684: cbz     x9, #0x2d356a0                             
02d35688: ldr     w8, [x9, #0x1c]                            
02d3568c: ldp     x20, x19, [sp, #0x10]                      
02d35690: add     w8, w8, #1                                 
02d35694: stp     wzr, w8, [x9, #0x18]                       
02d35698: ldr     x30, [sp], #0x20                           
02d3569c: ret                                                
02d356a0: bl      #0x2b7105c                                 fn_2b7105c
## .ctor() -> void
---- BlindBagCollection.BlindbagCollectionController::.ctor 0x2d356a4
02d356a4: str     x30, [sp, #-0x60]!                         
02d356a8: stp     x28, x27, [sp, #0x10]                      
02d356ac: stp     x26, x25, [sp, #0x20]                      
02d356b0: stp     x24, x23, [sp, #0x30]                      
02d356b4: stp     x22, x21, [sp, #0x40]                      
02d356b8: stp     x20, x19, [sp, #0x50]                      
02d356bc: adrp    x27, #0x626a000                            
02d356c0: adrp    x20, #0x626a000                            
02d356c4: adrp    x26, #0x626a000                            
02d356c8: adrp    x25, #0x626a000                            
02d356cc: adrp    x24, #0x626a000                            
02d356d0: adrp    x28, #0x6630000                            
02d356d4: adrp    x23, #0x626a000                            
02d356d8: adrp    x22, #0x6266000                            
02d356dc: adrp    x21, #0x6266000                            
02d356e0: ldr     x27, [x27, #0xa10]                         T:type14749(k15)
02d356e4: ldr     x20, [x20, #0xa18]                         MS:System.Collections.Generic.List`1::.ctor
02d356e8: ldr     x26, [x26, #0xa20]                         T:type14741(k15)
02d356ec: ldr     x25, [x25, #0xa28]                         MS:System.Collections.Generic.List`1::.ctor
02d356f0: ldr     x24, [x24, #0xa30]                         T:type56610(k15)
02d356f4: ldr     x23, [x23, #0xa38]                         MS:System.Collections.Generic.List`1::.ctor
02d356f8: ldrb    w8, [x28, #0x113]                          
02d356fc: ldr     x22, [x22, #0x648]                         T:type15061(k15)
02d35700: ldr     x21, [x21, #0x650]                         MS:System.Collections.Generic.List`1::.ctor
02d35704: mov     x19, x0                                    
02d35708: tbnz    w8, #0, #0x2d35774                         
02d3570c: adrp    x0, #0x626a000                             
02d35710: ldr     x0, [x0, #0xa38]                           MS:System.Collections.Generic.List`1::.ctor
02d35714: bl      #0x2b70db0                                 fn_2b70db0
02d35718: adrp    x0, #0x6266000                             
02d3571c: ldr     x0, [x0, #0x650]                           MS:System.Collections.Generic.List`1::.ctor
02d35720: bl      #0x2b70db0                                 fn_2b70db0
02d35724: adrp    x0, #0x626a000                             
02d35728: ldr     x0, [x0, #0xa28]                           MS:System.Collections.Generic.List`1::.ctor
02d3572c: bl      #0x2b70db0                                 fn_2b70db0
02d35730: adrp    x0, #0x626a000                             
02d35734: ldr     x0, [x0, #0xa18]                           MS:System.Collections.Generic.List`1::.ctor
02d35738: bl      #0x2b70db0                                 fn_2b70db0
02d3573c: adrp    x0, #0x6266000                             
02d35740: ldr     x0, [x0, #0x648]                           T:type15061(k15)
02d35744: bl      #0x2b70db0                                 fn_2b70db0
02d35748: adrp    x0, #0x626a000                             
02d3574c: ldr     x0, [x0, #0xa20]                           T:type14741(k15)
02d35750: bl      #0x2b70db0                                 fn_2b70db0
02d35754: adrp    x0, #0x626a000                             
02d35758: ldr     x0, [x0, #0xa30]                           T:type56610(k15)
02d3575c: bl      #0x2b70db0                                 fn_2b70db0
02d35760: adrp    x0, #0x626a000                             
02d35764: ldr     x0, [x0, #0xa10]                           T:type14749(k15)
02d35768: bl      #0x2b70db0                                 fn_2b70db0
02d3576c: mov     w8, #1                                     
02d35770: strb    w8, [x28, #0x113]                          
02d35774: ldr     x0, [x27]                                  T:type56879(k15)
02d35778: bl      #0x2b7104c                                 fn_2b7104c
02d3577c: ldr     x1, [x20]                                  T:type56879(k15)
02d35780: mov     x20, x0                                    
02d35784: bl      #0x4b9a964                                 fn_4b9a964
02d35788: mov     x0, x19                                    
02d3578c: mov     x1, x20                                    
02d35790: str     x20, [x0, #0x78]!                          ._cacheDataItems
02d35794: bl      #0x2b70d54                                 fn_2b70d54
02d35798: ldr     x0, [x26]                                  T:type56879(k15)
02d3579c: bl      #0x2b7104c                                 fn_2b7104c
02d357a0: ldr     x1, [x25]                                  T:type56879(k15)
02d357a4: mov     x20, x0                                    
02d357a8: bl      #0x4b8a688                                 fn_4b8a688
02d357ac: mov     x0, x19                                    
02d357b0: mov     x1, x20                                    
02d357b4: str     x20, [x0, #0x80]!                          ._unlockedItems
02d357b8: bl      #0x2b70d54                                 fn_2b70d54
02d357bc: ldr     x0, [x24]                                  T:type56879(k15)
02d357c0: bl      #0x2b7104c                                 fn_2b7104c
02d357c4: ldr     x1, [x23]                                  T:type56879(k15)
02d357c8: mov     x20, x0                                    
02d357cc: bl      #0x4b84ea0                                 fn_4b84ea0
02d357d0: mov     x0, x19                                    
02d357d4: mov     x1, x20                                    
02d357d8: str     x20, [x0, #0x88]!                          ._lockedItemTypes
02d357dc: bl      #0x2b70d54                                 fn_2b70d54
02d357e0: ldr     x0, [x24]                                  T:type56879(k15)
02d357e4: bl      #0x2b7104c                                 fn_2b7104c
02d357e8: ldr     x1, [x23]                                  T:type56879(k15)
02d357ec: mov     x20, x0                                    
02d357f0: bl      #0x4b84ea0                                 fn_4b84ea0
02d357f4: mov     x0, x19                                    
02d357f8: mov     x1, x20                                    
02d357fc: str     x20, [x0, #0x90]!                          ._checkDuplicateItems
02d35800: bl      #0x2b70d54                                 fn_2b70d54
02d35804: ldr     x0, [x22]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d35808: bl      #0x2b7104c                                 fn_2b7104c
02d3580c: ldr     x1, [x21]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d35810: mov     x20, x0                                    
02d35814: bl      #0x3569388                                 fn_3569388
02d35818: mov     x0, x19                                    
02d3581c: mov     x1, x20                                    
02d35820: str     x20, [x0, #0xa8]!                          ._cachedCaseID
02d35824: bl      #0x2b70d54                                 fn_2b70d54
02d35828: ldr     x0, [x22]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d3582c: bl      #0x2b7104c                                 fn_2b7104c
02d35830: ldr     x1, [x21]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d35834: mov     x20, x0                                    
02d35838: bl      #0x3569388                                 fn_3569388
02d3583c: mov     x0, x19                                    
02d35840: mov     x1, x20                                    
02d35844: str     x20, [x0, #0xb0]!                          ._cachedDecorID
02d35848: bl      #0x2b70d54                                 fn_2b70d54
02d3584c: mov     x0, x19                                    
02d35850: ldp     x20, x19, [sp, #0x50]                      
02d35854: ldp     x22, x21, [sp, #0x40]                      
02d35858: mov     x1, xzr                                    
02d3585c: ldp     x24, x23, [sp, #0x30]                      
02d35860: ldp     x26, x25, [sp, #0x20]                      
02d35864: ldp     x28, x27, [sp, #0x10]                      
02d35868: ldr     x30, [sp], #0x60                           
02d3586c: b       #0x5b397b0                                 UnityEngine.MonoBehaviour::.ctor
## .cctor() -> void
---- BlindBagCollection.BlindbagCollectionController::.cctor 0x2d35870
02d35870: str     x30, [sp, #-0x30]!                         
02d35874: stp     x22, x21, [sp, #0x10]                      
02d35878: stp     x20, x19, [sp, #0x20]                      
02d3587c: adrp    x21, #0x6630000                            
02d35880: adrp    x22, #0x6266000                            
02d35884: adrp    x19, #0x6266000                            
02d35888: adrp    x20, #0x626a000                            
02d3588c: ldr     x22, [x22, #0x648]                         T:type15061(k15)
02d35890: ldrb    w8, [x21, #0x114]                          
02d35894: ldr     x19, [x19, #0x650]                         MS:System.Collections.Generic.List`1::.ctor
02d35898: ldr     x20, [x20, #0x828]                         T:BlindBagCollection.BlindbagCollectionController
02d3589c: tbnz    w8, #0, #0x2d358cc                         
02d358a0: adrp    x0, #0x626a000                             
02d358a4: ldr     x0, [x0, #0x828]                           T:BlindBagCollection.BlindbagCollectionController
02d358a8: bl      #0x2b70db0                                 fn_2b70db0
02d358ac: adrp    x0, #0x6266000                             
02d358b0: ldr     x0, [x0, #0x650]                           MS:System.Collections.Generic.List`1::.ctor
02d358b4: bl      #0x2b70db0                                 fn_2b70db0
02d358b8: adrp    x0, #0x6266000                             
02d358bc: ldr     x0, [x0, #0x648]                           T:type15061(k15)
02d358c0: bl      #0x2b70db0                                 fn_2b70db0
02d358c4: mov     w8, #1                                     
02d358c8: strb    w8, [x21, #0x114]                          
02d358cc: ldr     x0, [x22]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d358d0: bl      #0x2b7104c                                 fn_2b7104c
02d358d4: ldr     x1, [x19]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d358d8: mov     x19, x0                                    
02d358dc: bl      #0x3569388                                 fn_3569388
02d358e0: ldr     x8, [x20]                                  T:type56879(k15)
02d358e4: mov     x1, x19                                    
02d358e8: ldp     x22, x21, [sp, #0x10]                      
02d358ec: ldr     x8, [x8, #0xb8]                            
02d358f0: str     x19, [x8]                                  
02d358f4: ldr     x8, [x20]                                  T:type56879(k15)
02d358f8: ldp     x20, x19, [sp, #0x20]                      
02d358fc: ldr     x0, [x8, #0xb8]                            
02d35900: ldr     x30, [sp], #0x30                           
02d35904: b       #0x2b70d54                                 
## <GoToCollectionStep>b__27_0() -> void
---- BlindBagCollection.BlindbagCollectionController::<GoToCollectionStep>b__27_0 0x2d35908
02d35908: stp     x30, x21, [sp, #-0x20]!                    
02d3590c: stp     x20, x19, [sp, #0x10]                      
02d35910: adrp    x20, #0x6630000                            
02d35914: adrp    x21, #0x626a000                            
02d35918: mov     x19, x0                                    
02d3591c: ldrb    w8, [x20, #0x115]                          
02d35920: ldr     x21, [x21, #0xa40]                         S:'OnGoToCollectionStep'
02d35924: tbnz    w8, #0, #0x2d3593c                         
02d35928: adrp    x0, #0x626a000                             
02d3592c: ldr     x0, [x0, #0xa40]                           S:'OnGoToCollectionStep'
02d35930: bl      #0x2b70db0                                 fn_2b70db0
02d35934: mov     w8, #1                                     
02d35938: strb    w8, [x20, #0x115]                          
02d3593c: mov     x0, x19                                    
02d35940: ldp     x20, x19, [sp, #0x10]                      
02d35944: ldr     x1, [x21]                                  T:type56879(k15)
02d35948: fmov    s0, #1.50000000                            
02d3594c: mov     x2, xzr                                    
02d35950: ldp     x30, x21, [sp], #0x20                      
02d35954: b       #0x5b38044                                 UnityEngine.MonoBehaviour::Invoke
## <OnGoToCollectionStep>b__28_0() -> void
---- BlindBagCollection.BlindbagCollectionController::<OnGoToCollectionStep>b__28_0 0x2d35958
02d35958: str     d8, [sp, #-0x40]!                          
02d3595c: str     x30, [sp, #8]                              
02d35960: stp     x24, x23, [sp, #0x10]                      
02d35964: stp     x22, x21, [sp, #0x20]                      
02d35968: stp     x20, x19, [sp, #0x30]                      
02d3596c: adrp    x20, #0x6630000                            
02d35970: mov     x19, x0                                    
02d35974: ldrb    w8, [x20, #0x116]                          
02d35978: tbnz    w8, #0, #0x2d359f0                         
02d3597c: adrp    x0, #0x6264000                             
02d35980: ldr     x0, [x0, #0xf90]                           T:System.Action
02d35984: bl      #0x2b70db0                                 fn_2b70db0
02d35988: adrp    x0, #0x626a000                             
02d3598c: ldr     x0, [x0, #0xa48]                           MS:UnityEngine.Component::GetComponent
02d35990: bl      #0x2b70db0                                 fn_2b70db0
02d35994: adrp    x0, #0x6265000                             
02d35998: ldr     x0, [x0, #0xb38]                           T:DevTrack
02d3599c: bl      #0x2b70db0                                 fn_2b70db0
02d359a0: adrp    x0, #0x626a000                             
02d359a4: ldr     x0, [x0, #0xa50]                           MS:System.Collections.Generic.List`1::get_Count
02d359a8: bl      #0x2b70db0                                 fn_2b70db0
02d359ac: adrp    x0, #0x6267000                             
02d359b0: ldr     x0, [x0, #0xbd0]                           MS:MonoSingleton`1::get_Instance
02d359b4: bl      #0x2b70db0                                 fn_2b70db0
02d359b8: adrp    x0, #0x6266000                             
02d359bc: ldr     x0, [x0, #0xb48]                           MS:MonoSingleton`1::get_Instance
02d359c0: bl      #0x2b70db0                                 fn_2b70db0
02d359c4: adrp    x0, #0x626a000                             
02d359c8: ldr     x0, [x0, #0xa58]                           M:BlindBagCollection.BlindbagCollectionController/<>c::<OnGoToCollectionStep>b__28_1
02d359cc: bl      #0x2b70db0                                 fn_2b70db0
02d359d0: adrp    x0, #0x626a000                             
02d359d4: ldr     x0, [x0, #0xa60]                           T:BlindBagCollection.BlindbagCollectionController/<>c
02d359d8: bl      #0x2b70db0                                 fn_2b70db0
02d359dc: adrp    x0, #0x626a000                             
02d359e0: ldr     x0, [x0, #0xa68]                           MS:UIManager::ShowPopup
02d359e4: bl      #0x2b70db0                                 fn_2b70db0
02d359e8: mov     w8, #1                                     
02d359ec: strb    w8, [x20, #0x116]                          
02d359f0: ldr     x8, [x19, #0x80]                           ._unlockedItems
02d359f4: cbz     x8, #0x2d35c98                             
02d359f8: ldr     w8, [x8, #0x18]                            
02d359fc: cbz     w8, #0x2d35ac8                             
02d35a00: adrp    x8, #0x6267000                             
02d35a04: ldr     x8, [x8, #0xbd0]                           MS:MonoSingleton`1::get_Instance
02d35a08: ldr     x0, [x8]                                   S:'didu'
02d35a0c: bl      #0x3769600                                 fn_3769600
02d35a10: cbz     x0, #0x2d35c98                             
02d35a14: adrp    x8, #0x626a000                             
02d35a18: adrp    x24, #0x626a000                            
02d35a1c: ldr     x8, [x8, #0xa68]                           MS:UIManager::ShowPopup
02d35a20: ldr     x24, [x24, #0xa60]                         T:BlindBagCollection.BlindbagCollectionController/<>c
02d35a24: ldr     x1, [x8]                                   T:type56879(k15)
02d35a28: bl      #0x33fbfac                                 fn_33fbfac
02d35a2c: ldr     x8, [x24]                                  T:type56879(k15)
02d35a30: ldr     x20, [x19, #0x80]                          ._unlockedItems
02d35a34: mov     x21, x0                                    
02d35a38: ldr     w9, [x8, #0xe4]                            [626a0e4]=0 f=0,0
02d35a3c: cbnz    w9, #0x2d35a4c                             
02d35a40: mov     x0, x8                                     
02d35a44: bl      #0x2b70f30                                 fn_2b70f30
02d35a48: ldr     x8, [x24]                                  T:type56879(k15)
02d35a4c: ldr     x9, [x8, #0xb8]                            MS:UnityEngine.Object::FindObjectsOfType
02d35a50: ldr     x22, [x9, #8]                              
02d35a54: cbnz    x22, #0x2d35ab4                            
02d35a58: ldr     w10, [x8, #0xe4]                           [626a0e4]=0 f=0,0
02d35a5c: cbnz    w10, #0x2d35a70                            
02d35a60: mov     x0, x8                                     
02d35a64: bl      #0x2b70f30                                 fn_2b70f30
02d35a68: ldr     x8, [x24]                                  T:type56879(k15)
02d35a6c: ldr     x9, [x8, #0xb8]                            MS:UnityEngine.Object::FindObjectsOfType
02d35a70: adrp    x8, #0x6264000                             
02d35a74: ldr     x8, [x8, #0xf90]                           T:System.Action
02d35a78: ldr     x23, [x9]                                  
02d35a7c: ldr     x0, [x8]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d35a80: bl      #0x2b7104c                                 fn_2b7104c
02d35a84: adrp    x8, #0x626a000                             
02d35a88: mov     x1, x23                                    
02d35a8c: mov     x3, xzr                                    
02d35a90: ldr     x8, [x8, #0xa58]                           M:BlindBagCollection.BlindbagCollectionController/<>c::<OnGoToCollectionStep>b__28_1
02d35a94: mov     x22, x0                                    
02d35a98: ldr     x2, [x8]                                   T:type56879(k15)
02d35a9c: bl      #0x4d8ddbc                                 System.Action::.ctor
02d35aa0: ldr     x8, [x24]                                  T:type56879(k15)
02d35aa4: mov     x1, x22                                    
02d35aa8: ldr     x0, [x8, #0xb8]                            MS:UnityEngine.Object::FindObjectsOfType
02d35aac: str     x22, [x0, #8]!                             
02d35ab0: bl      #0x2b70d54                                 fn_2b70d54
02d35ab4: cbz     x21, #0x2d35c98                            
02d35ab8: mov     x0, x21                                    
02d35abc: mov     x1, x20                                    
02d35ac0: mov     x2, x22                                    
02d35ac4: bl      #0x2d304a4                                 BlindBagCollection.AutoSellPopup::InitalizePrice
02d35ac8: ldr     x0, [x19, #0x20]                           ._blindBoxPlate
02d35acc: cbz     x0, #0x2d35c98                             
02d35ad0: mov     x1, xzr                                    
02d35ad4: bl      #0x5b339ec                                 UnityEngine.Component::get_gameObject
02d35ad8: cbz     x0, #0x2d35c98                             
02d35adc: mov     w1, wzr                                    
02d35ae0: mov     x2, xzr                                    
02d35ae4: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d35ae8: ldr     x0, [x19, #0x28]                           ._openBagObject
02d35aec: cbz     x0, #0x2d35c98                             
02d35af0: mov     w1, wzr                                    
02d35af4: mov     x2, xzr                                    
02d35af8: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d35afc: ldr     x0, [x19, #0x30]                           ._collectionObject
02d35b00: cbz     x0, #0x2d35c98                             
02d35b04: mov     w1, #1                                     
02d35b08: mov     x2, xzr                                    
02d35b0c: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d35b10: ldr     x0, [x19, #0x40]                           ._homeButtonObject
02d35b14: cbz     x0, #0x2d35c98                             
02d35b18: mov     w1, wzr                                    
02d35b1c: mov     x2, xzr                                    
02d35b20: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d35b24: ldr     x0, [x19, #0x48]                           ._dragController
02d35b28: cbz     x0, #0x2d35c98                             
02d35b2c: ldr     x1, [x19, #0x78]                           ._cacheDataItems
02d35b30: bl      #0x2d35c9c                                 BlindBagCollection.BlindbagDragController::InitalizeBlindbag
02d35b34: mov     x0, xzr                                    
02d35b38: bl      #0x5aefe28                                 UnityEngine.Camera::get_main
02d35b3c: cbz     x0, #0x2d35c98                             
02d35b40: adrp    x20, #0x626a000                            
02d35b44: ldr     x20, [x20, #0xa48]                         MS:UnityEngine.Component::GetComponent
02d35b48: ldr     x1, [x20]                                  T:type56879(k15)
02d35b4c: bl      #0x3140c84                                 fn_3140c84
02d35b50: cbz     x0, #0x2d35c98                             
02d35b54: mov     w1, #1                                     
02d35b58: mov     x2, xzr                                    
02d35b5c: bl      #0x5b33110                                 UnityEngine.Behaviour::set_enabled
02d35b60: ldr     x8, [x19, #0x48]                           ._dragController
02d35b64: cbz     x8, #0x2d35c98                             
02d35b68: ldr     w8, [x8, #0x70]                            MS:System.Collections.Generic.List`1::FindIndex
02d35b6c: cbnz    w8, #0x2d35b9c                             
02d35b70: mov     x0, xzr                                    
02d35b74: bl      #0x5aefe28                                 UnityEngine.Camera::get_main
02d35b78: cbz     x0, #0x2d35c98                             
02d35b7c: ldr     x1, [x20]                                  T:type56879(k15)
02d35b80: bl      #0x3140c84                                 fn_3140c84
02d35b84: cbz     x0, #0x2d35c98                             
02d35b88: mov     w1, wzr                                    
02d35b8c: mov     x2, xzr                                    
02d35b90: bl      #0x5b33110                                 UnityEngine.Behaviour::set_enabled
02d35b94: mov     x0, x19                                    
02d35b98: bl      #0x2d354f8                                 BlindBagCollection.BlindbagCollectionController::OnCollectionComplete
02d35b9c: adrp    x23, #0x6266000                            
02d35ba0: ldr     x23, [x23, #0xb48]                         MS:MonoSingleton`1::get_Instance
02d35ba4: ldr     x0, [x23]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d35ba8: bl      #0x3769600                                 fn_3769600
02d35bac: cbz     x0, #0x2d35c98                             
02d35bb0: ldr     x19, [x0, #0x30]                           S:'======================================================  i : ' ._collectionObject
02d35bb4: ldr     x0, [x23]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d35bb8: bl      #0x3769600                                 fn_3769600
02d35bbc: cbz     x0, #0x2d35c98                             
02d35bc0: adrp    x24, #0x6265000                            
02d35bc4: mov     x8, x0                                     
02d35bc8: ldr     x24, [x24, #0xb38]                         T:DevTrack
02d35bcc: ldr     w20, [x8, #0x3c]                           [626a03c]=0 f=0,0
02d35bd0: ldr     x0, [x24]                                  M:AdsManager::<OnApplicationPause>b__26_0
02d35bd4: ldr     w9, [x0, #0xe4]                            [626a0e4]=0 f=0,0
02d35bd8: cbnz    w9, #0x2d35be4                             
02d35bdc: bl      #0x2b70f30                                 fn_2b70f30
02d35be0: ldr     x0, [x24]                                  M:AdsManager::<OnApplicationPause>b__26_0
02d35be4: ldr     x8, [x0, #0xb8]                            MS:UnityEngine.Object::FindObjectsOfType
02d35be8: mov     x0, xzr                                    
02d35bec: ldr     x21, [x8, #0x2b8]                          MS:DataManager::GetAsset
02d35bf0: ldr     w22, [x8, #0x2dc]                          [626a2dc]=0 f=0,0
02d35bf4: bl      #0x5b432fc                                 UnityEngine.Time::get_time
02d35bf8: ldr     x0, [x23]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d35bfc: fmov    s8, s0                                     
02d35c00: bl      #0x3769600                                 fn_3769600
02d35c04: cbz     x0, #0x2d35c98                             
02d35c08: ldr     s0, [x0, #0x38]                            MS:System.Collections.Generic.List`1::get_Item ._collectionBoxsetObject
02d35c0c: mov     x0, x19                                    
02d35c10: mov     w1, w20                                    
02d35c14: mov     x2, x21                                    
02d35c18: mov     w3, w22                                    
02d35c1c: mov     x4, xzr                                    
02d35c20: fsub    s0, s8, s0                                 
02d35c24: bl      #0x2c9c898                                 DevTrack::GameModeStepComplete
02d35c28: ldr     x0, [x23]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d35c2c: bl      #0x3769600                                 fn_3769600
02d35c30: cbz     x0, #0x2d35c98                             
02d35c34: ldr     x19, [x0, #0x30]                           S:'======================================================  i : ' ._collectionObject
02d35c38: ldr     x0, [x23]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d35c3c: bl      #0x3769600                                 fn_3769600
02d35c40: cbz     x0, #0x2d35c98                             
02d35c44: ldr     x8, [x24]                                  M:AdsManager::<OnApplicationPause>b__26_0
02d35c48: ldr     w1, [x0, #0x3c]                            [626a03c]=0 f=0,0
02d35c4c: mov     x0, x19                                    
02d35c50: mov     x4, xzr                                    
02d35c54: ldr     x8, [x8, #0xb8]                            MS:UnityEngine.Object::FindObjectsOfType
02d35c58: ldr     x2, [x8, #0x2c0]                           MS:DataManager::GetData
02d35c5c: ldr     w3, [x8, #0x2e0]                           MS:System.Collections.Generic.List`1/Enumerator::MoveNext
02d35c60: bl      #0x2c9c714                                 DevTrack::GameModeStepEnter
02d35c64: ldr     x0, [x23]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d35c68: bl      #0x3769600                                 fn_3769600
02d35c6c: cbz     x0, #0x2d35c98                             
02d35c70: ldr     x8, [x24]                                  M:AdsManager::<OnApplicationPause>b__26_0
02d35c74: ldp     x20, x19, [sp, #0x30]                      
02d35c78: ldp     x22, x21, [sp, #0x20]                      
02d35c7c: ldr     x30, [sp, #8]                              
02d35c80: ldr     x8, [x8, #0xb8]                            MS:UnityEngine.Object::FindObjectsOfType
02d35c84: ldp     x24, x23, [sp, #0x10]                      
02d35c88: ldr     x1, [x8, #0x2c0]                           MS:DataManager::GetData
02d35c8c: str     x1, [x0, #0x40]!                           ._homeButtonObject
02d35c90: ldr     d8, [sp], #0x40                            
02d35c94: b       #0x2b70d54                                 
02d35c98: bl      #0x2b7105c                                 fn_2b7105c
