#### CLASS Framework.RigidbodyExtention parent= object
## SetPosX(UnityEngine.Rigidbody rb, float x) -> void
---- Framework.RigidbodyExtention::SetPosX 0x2cb992c
02cb992c: stp     d9, d8, [sp, #-0x20]!                      
02cb9930: stp     x30, x19, [sp, #0x10]                      
02cb9934: cbz     x0, #0x2cb9974                             
02cb9938: mov     x1, xzr                                    
02cb993c: mov     x19, x0                                    
02cb9940: fmov    s8, s0                                     
02cb9944: bl      #0x5bd0c3c                                 UnityEngine.Rigidbody::get_position
02cb9948: mov     x0, x19                                    
02cb994c: mov     x1, xzr                                    
02cb9950: fmov    s9, s1                                     
02cb9954: bl      #0x5bd0c3c                                 UnityEngine.Rigidbody::get_position
02cb9958: mov     x0, x19                                    
02cb995c: ldp     x30, x19, [sp, #0x10]                      
02cb9960: fmov    s0, s8                                     
02cb9964: fmov    s1, s9                                     
02cb9968: mov     x1, xzr                                    
02cb996c: ldp     d9, d8, [sp], #0x20                        
02cb9970: b       #0x5bd0d18                                 UnityEngine.Rigidbody::set_position
02cb9974: bl      #0x2b7105c                                 fn_2b7105c
## SetPosY(UnityEngine.Rigidbody rb, float y) -> void
---- Framework.RigidbodyExtention::SetPosY 0x2cb9978
02cb9978: stp     d9, d8, [sp, #-0x20]!                      
02cb997c: stp     x30, x19, [sp, #0x10]                      
02cb9980: cbz     x0, #0x2cb99c0                             
02cb9984: mov     x1, xzr                                    
02cb9988: mov     x19, x0                                    
02cb998c: fmov    s8, s0                                     
02cb9990: bl      #0x5bd0c3c                                 UnityEngine.Rigidbody::get_position
02cb9994: mov     x0, x19                                    
02cb9998: mov     x1, xzr                                    
02cb999c: fmov    s9, s0                                     
02cb99a0: bl      #0x5bd0c3c                                 UnityEngine.Rigidbody::get_position
02cb99a4: mov     x0, x19                                    
02cb99a8: ldp     x30, x19, [sp, #0x10]                      
02cb99ac: fmov    s0, s9                                     
02cb99b0: fmov    s1, s8                                     
02cb99b4: mov     x1, xzr                                    
02cb99b8: ldp     d9, d8, [sp], #0x20                        
02cb99bc: b       #0x5bd0d18                                 UnityEngine.Rigidbody::set_position
02cb99c0: bl      #0x2b7105c                                 fn_2b7105c
## SetPosZ(UnityEngine.Rigidbody rb, float z) -> void
---- Framework.RigidbodyExtention::SetPosZ 0x2cb99c4
02cb99c4: stp     d9, d8, [sp, #-0x20]!                      
02cb99c8: stp     x30, x19, [sp, #0x10]                      
02cb99cc: cbz     x0, #0x2cb9a0c                             
02cb99d0: mov     x1, xzr                                    
02cb99d4: mov     x19, x0                                    
02cb99d8: fmov    s8, s0                                     
02cb99dc: bl      #0x5bd0c3c                                 UnityEngine.Rigidbody::get_position
02cb99e0: mov     x0, x19                                    
02cb99e4: mov     x1, xzr                                    
02cb99e8: fmov    s9, s0                                     
02cb99ec: bl      #0x5bd0c3c                                 UnityEngine.Rigidbody::get_position
02cb99f0: mov     x0, x19                                    
02cb99f4: ldp     x30, x19, [sp, #0x10]                      
02cb99f8: fmov    s0, s9                                     
02cb99fc: fmov    s2, s8                                     
02cb9a00: mov     x1, xzr                                    
02cb9a04: ldp     d9, d8, [sp], #0x20                        
02cb9a08: b       #0x5bd0d18                                 UnityEngine.Rigidbody::set_position
02cb9a0c: bl      #0x2b7105c                                 fn_2b7105c
## SetRotationX(UnityEngine.Rigidbody rb, float x) -> void
---- Framework.RigidbodyExtention::SetRotationX 0x2cb9a10
02cb9a10: sub     sp, sp, #0x40                              
02cb9a14: stp     x30, x19, [sp, #0x30]                      
02cb9a18: str     q0, [sp]                                   
02cb9a1c: stp     xzr, xzr, [sp, #0x10]                      
02cb9a20: cbz     x0, #0x2cb9ab0                             
02cb9a24: mov     x1, xzr                                    
02cb9a28: mov     x19, x0                                    
02cb9a2c: bl      #0x5bd0dec                                 UnityEngine.Rigidbody::get_rotation
02cb9a30: add     x0, sp, #0x10                              
02cb9a34: mov     x1, xzr                                    
02cb9a38: stp     s0, s1, [sp, #0x10]                        
02cb9a3c: stp     s2, s3, [sp, #0x18]                        
02cb9a40: bl      #0x5b26118                                 UnityEngine.Quaternion::Internal_ToEulerRad
02cb9a44: adrp    x8, #0x1084000                             
02cb9a48: mov     x0, xzr                                    
02cb9a4c: ldr     s3, [x8, #0xdec]                           [1084dec]=3fe6666642652ee1 f=57.2958,1.8
02cb9a50: fmul    s0, s0, s3                                 
02cb9a54: fmul    s1, s1, s3                                 
02cb9a58: fmul    s2, s2, s3                                 
02cb9a5c: bl      #0x5b266d8                                 UnityEngine.Quaternion::Internal_MakePositive
02cb9a60: mov     w8, #0xfa35                                
02cb9a64: ldr     q3, [sp]                                   
02cb9a68: add     x0, sp, #0x20                              
02cb9a6c: movk    w8, #0x3c8e, lsl #16                       
02cb9a70: mov     x1, xzr                                    
02cb9a74: mov     v3.s[1], v1.s[0]                           
02cb9a78: dup     v0.2s, w8                                  
02cb9a7c: adrp    x8, #0x1085000                             
02cb9a80: ldr     s1, [x8, #0x10]                            [1085010]=4202c6f23c8efa35 f=0.0174533,32.6943
02cb9a84: fmul    s1, s2, s1                                 
02cb9a88: fmul    v0.2s, v3.2s, v0.2s                        
02cb9a8c: str     s1, [sp, #0x28]                            
02cb9a90: str     d0, [sp, #0x20]                            
02cb9a94: bl      #0x5b2607c                                 UnityEngine.Quaternion::Internal_FromEulerRad
02cb9a98: mov     x0, x19                                    
02cb9a9c: mov     x1, xzr                                    
02cb9aa0: bl      #0x5bd0ec4                                 UnityEngine.Rigidbody::set_rotation
02cb9aa4: ldp     x30, x19, [sp, #0x30]                      
02cb9aa8: add     sp, sp, #0x40                              
02cb9aac: ret                                                
02cb9ab0: bl      #0x2b7105c                                 fn_2b7105c
## SetRotationY(UnityEngine.Rigidbody rb, float y) -> void
---- Framework.RigidbodyExtention::SetRotationY 0x2cb9ab4
02cb9ab4: sub     sp, sp, #0x40                              
02cb9ab8: stp     x30, x19, [sp, #0x30]                      
02cb9abc: str     q0, [sp]                                   
02cb9ac0: stp     xzr, xzr, [sp, #0x10]                      
02cb9ac4: cbz     x0, #0x2cb9b54                             
02cb9ac8: mov     x1, xzr                                    
02cb9acc: mov     x19, x0                                    
02cb9ad0: bl      #0x5bd0dec                                 UnityEngine.Rigidbody::get_rotation
02cb9ad4: add     x0, sp, #0x10                              
02cb9ad8: mov     x1, xzr                                    
02cb9adc: stp     s0, s1, [sp, #0x10]                        
02cb9ae0: stp     s2, s3, [sp, #0x18]                        
02cb9ae4: bl      #0x5b26118                                 UnityEngine.Quaternion::Internal_ToEulerRad
02cb9ae8: adrp    x8, #0x1084000                             
02cb9aec: mov     x0, xzr                                    
02cb9af0: ldr     s3, [x8, #0xdec]                           [1084dec]=3fe6666642652ee1 f=57.2958,1.8
02cb9af4: fmul    s0, s0, s3                                 
02cb9af8: fmul    s1, s1, s3                                 
02cb9afc: fmul    s2, s2, s3                                 
02cb9b00: bl      #0x5b266d8                                 UnityEngine.Quaternion::Internal_MakePositive
02cb9b04: mov     w8, #0xfa35                                
02cb9b08: ldr     q1, [sp]                                   
02cb9b0c: add     x0, sp, #0x20                              
02cb9b10: movk    w8, #0x3c8e, lsl #16                       
02cb9b14: mov     x1, xzr                                    
02cb9b18: mov     v0.s[1], v1.s[0]                           
02cb9b1c: dup     v1.2s, w8                                  
02cb9b20: adrp    x8, #0x1085000                             
02cb9b24: ldr     s3, [x8, #0x10]                            [1085010]=4202c6f23c8efa35 f=0.0174533,32.6943
02cb9b28: fmul    v0.2s, v0.2s, v1.2s                        
02cb9b2c: fmul    s1, s2, s3                                 
02cb9b30: str     d0, [sp, #0x20]                            
02cb9b34: str     s1, [sp, #0x28]                            
02cb9b38: bl      #0x5b2607c                                 UnityEngine.Quaternion::Internal_FromEulerRad
02cb9b3c: mov     x0, x19                                    
02cb9b40: mov     x1, xzr                                    
02cb9b44: bl      #0x5bd0ec4                                 UnityEngine.Rigidbody::set_rotation
02cb9b48: ldp     x30, x19, [sp, #0x30]                      
02cb9b4c: add     sp, sp, #0x40                              
02cb9b50: ret                                                
02cb9b54: bl      #0x2b7105c                                 fn_2b7105c
## SetRotationZ(UnityEngine.Rigidbody rb, float z) -> void
---- Framework.RigidbodyExtention::SetRotationZ 0x2cb9b58
02cb9b58: sub     sp, sp, #0x40                              
02cb9b5c: str     d8, [sp, #0x20]                            
02cb9b60: stp     x30, x19, [sp, #0x30]                      
02cb9b64: stp     xzr, xzr, [sp]                             
02cb9b68: cbz     x0, #0x2cb9bfc                             
02cb9b6c: mov     x1, xzr                                    
02cb9b70: fmov    s8, s0                                     
02cb9b74: mov     x19, x0                                    
02cb9b78: bl      #0x5bd0dec                                 UnityEngine.Rigidbody::get_rotation
02cb9b7c: mov     x0, sp                                     
02cb9b80: mov     x1, xzr                                    
02cb9b84: stp     s0, s1, [sp]                               
02cb9b88: stp     s2, s3, [sp, #8]                           
02cb9b8c: bl      #0x5b26118                                 UnityEngine.Quaternion::Internal_ToEulerRad
02cb9b90: adrp    x8, #0x1084000                             
02cb9b94: mov     x0, xzr                                    
02cb9b98: ldr     s3, [x8, #0xdec]                           [1084dec]=3fe6666642652ee1 f=57.2958,1.8
02cb9b9c: fmul    s0, s0, s3                                 
02cb9ba0: fmul    s1, s1, s3                                 
02cb9ba4: fmul    s2, s2, s3                                 
02cb9ba8: bl      #0x5b266d8                                 UnityEngine.Quaternion::Internal_MakePositive
02cb9bac: mov     w8, #0xfa35                                
02cb9bb0: add     x0, sp, #0x10                              
02cb9bb4: mov     x1, xzr                                    
02cb9bb8: movk    w8, #0x3c8e, lsl #16                       
02cb9bbc: mov     v0.s[1], v1.s[0]                           
02cb9bc0: dup     v1.2s, w8                                  
02cb9bc4: adrp    x8, #0x1085000                             
02cb9bc8: ldr     s2, [x8, #0x10]                            [1085010]=4202c6f23c8efa35 f=0.0174533,32.6943
02cb9bcc: fmul    v0.2s, v0.2s, v1.2s                        
02cb9bd0: fmul    s1, s8, s2                                 
02cb9bd4: str     d0, [sp, #0x10]                            
02cb9bd8: str     s1, [sp, #0x18]                            
02cb9bdc: bl      #0x5b2607c                                 UnityEngine.Quaternion::Internal_FromEulerRad
02cb9be0: mov     x0, x19                                    
02cb9be4: mov     x1, xzr                                    
02cb9be8: bl      #0x5bd0ec4                                 UnityEngine.Rigidbody::set_rotation
02cb9bec: ldp     x30, x19, [sp, #0x30]                      
02cb9bf0: ldr     d8, [sp, #0x20]                            
02cb9bf4: add     sp, sp, #0x40                              
02cb9bf8: ret                                                
02cb9bfc: bl      #0x2b7105c                                 fn_2b7105c
