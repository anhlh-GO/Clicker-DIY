#### CLASS DreamHouseFirstGameTutorial parent= MonoSingleton`1<DreamHouseFirstGameTutorial>
#   field _btnIntro                      UnityEngine.UI.Button                              off=0x20 attr=1 SerializeField
#   field _goScreenInGame                UnityEngine.GameObject                             off=0x28 attr=1 SerializeField
#   field _tfHighlight                   UnityEngine.Transform                              off=0x30 attr=1 SerializeField
#   field _tfIntroContent                UnityEngine.Transform                              off=0x38 attr=1 SerializeField
## Initiate() -> void
---- DreamHouseFirstGameTutorial::Initiate 0x2cae670
02cae670: stp     x30, x21, [sp, #-0x20]!                    
02cae674: stp     x20, x19, [sp, #0x10]                      
02cae678: adrp    x20, #0x662f000                            
02cae67c: adrp    x21, #0x6266000                            
02cae680: mov     x19, x0                                    
02cae684: ldrb    w8, [x20, #0xb4c]                          
02cae688: ldr     x21, [x21, #0x918]                         MS:MonoSingleton`1::Initiate
02cae68c: tbnz    w8, #0, #0x2cae6a4                         
02cae690: adrp    x0, #0x6266000                             
02cae694: ldr     x0, [x0, #0x918]                           MS:MonoSingleton`1::Initiate
02cae698: bl      #0x2b70db0                                 fn_2b70db0
02cae69c: mov     w8, #1                                     
02cae6a0: strb    w8, [x20, #0xb4c]                          
02cae6a4: ldr     x1, [x21]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cae6a8: mov     x0, x19                                    
02cae6ac: bl      #0x3769de4                                 fn_3769de4
02cae6b0: ldr     x0, [x19, #0x20]                           ._btnIntro
02cae6b4: cbz     x0, #0x2cae744                             
02cae6b8: mov     x1, xzr                                    
02cae6bc: bl      #0x5b339ec                                 UnityEngine.Component::get_gameObject
02cae6c0: cbz     x0, #0x2cae744                             
02cae6c4: mov     w1, wzr                                    
02cae6c8: mov     x2, xzr                                    
02cae6cc: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02cae6d0: ldr     x0, [x19, #0x30]                           ._tfHighlight
02cae6d4: cbz     x0, #0x2cae744                             
02cae6d8: mov     x1, xzr                                    
02cae6dc: bl      #0x5b339ec                                 UnityEngine.Component::get_gameObject
02cae6e0: cbz     x0, #0x2cae744                             
02cae6e4: mov     w1, wzr                                    
02cae6e8: mov     x2, xzr                                    
02cae6ec: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02cae6f0: adrp    x20, #0x662f000                            
02cae6f4: ldr     x19, [x19, #0x38]                          ._tfIntroContent
02cae6f8: ldrb    w8, [x20, #0x91a]                          
02cae6fc: cbnz    w8, #0x2cae714                             
02cae700: adrp    x0, #0x6264000                             
02cae704: ldr     x0, [x0, #0xd8]                            T:UnityEngine.Vector3
02cae708: bl      #0x2b70db0                                 fn_2b70db0
02cae70c: mov     w8, #1                                     
02cae710: strb    w8, [x20, #0x91a]                          
02cae714: cbz     x19, #0x2cae744                            
02cae718: adrp    x8, #0x6264000                             
02cae71c: mov     x0, x19                                    
02cae720: mov     x1, xzr                                    
02cae724: ldr     x8, [x8, #0xd8]                            T:UnityEngine.Vector3
02cae728: ldp     x20, x19, [sp, #0x10]                      
02cae72c: ldr     x8, [x8]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02cae730: ldr     x8, [x8, #0xb8]                            MS:DG.Tweening.Core.Extensions::SetSpecialStartupMode
02cae734: ldp     s0, s1, [x8]                               
02cae738: ldr     s2, [x8, #8]                               T:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass2_0
02cae73c: ldp     x30, x21, [sp], #0x20                      
02cae740: b       #0x5b470cc                                 UnityEngine.Transform::set_localScale
02cae744: bl      #0x2b7105c                                 fn_2b7105c
## ShowIntro() -> void
---- DreamHouseFirstGameTutorial::ShowIntro 0x2cae748
02cae748: stp     x30, x21, [sp, #-0x20]!                    
02cae74c: stp     x20, x19, [sp, #0x10]                      
02cae750: adrp    x21, #0x662f000                            
02cae754: adrp    x20, #0x6266000                            
02cae758: mov     x19, x0                                    
02cae75c: ldrb    w8, [x21, #0xb4d]                          
02cae760: ldr     x20, [x20, #0x880]                         MS:DG.Tweening.TweenSettingsExtensions::SetEase
02cae764: tbnz    w8, #0, #0x2cae77c                         
02cae768: adrp    x0, #0x6266000                             
02cae76c: ldr     x0, [x0, #0x880]                           MS:DG.Tweening.TweenSettingsExtensions::SetEase
02cae770: bl      #0x2b70db0                                 fn_2b70db0
02cae774: mov     w8, #1                                     
02cae778: strb    w8, [x21, #0xb4d]                          
02cae77c: fmov    s0, #1.00000000                            
02cae780: fmov    s1, #0.50000000                            
02cae784: ldr     x0, [x19, #0x38]                           ._tfIntroContent
02cae788: mov     x1, xzr                                    
02cae78c: bl      #0x2d98c98                                 DG.Tweening.ShortcutExtensions::DOScale
02cae790: ldr     x2, [x20]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cae794: mov     w1, #0x1b                                  
02cae798: bl      #0x336fa0c                                 fn_336fa0c
02cae79c: ldr     x0, [x19, #0x28]                           ._goScreenInGame
02cae7a0: cbz     x0, #0x2cae7e4                             
02cae7a4: mov     x1, xzr                                    
02cae7a8: bl      #0x5b37654                                 UnityEngine.GameObject::get_gameObject
02cae7ac: cbz     x0, #0x2cae7e4                             
02cae7b0: mov     w1, wzr                                    
02cae7b4: mov     x2, xzr                                    
02cae7b8: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02cae7bc: ldr     x0, [x19, #0x20]                           ._btnIntro
02cae7c0: cbz     x0, #0x2cae7e4                             
02cae7c4: mov     x1, xzr                                    
02cae7c8: bl      #0x5b339ec                                 UnityEngine.Component::get_gameObject
02cae7cc: cbz     x0, #0x2cae7e4                             
02cae7d0: ldp     x20, x19, [sp, #0x10]                      
02cae7d4: mov     w1, #1                                     
02cae7d8: mov     x2, xzr                                    
02cae7dc: ldp     x30, x21, [sp], #0x20                      
02cae7e0: b       #0x5b36b38                                 UnityEngine.GameObject::SetActive
02cae7e4: bl      #0x2b7105c                                 fn_2b7105c
## ShowHighlightAt(UnityEngine.Transform highlight) -> void
---- DreamHouseFirstGameTutorial::ShowHighlightAt 0x2cae7e8
02cae7e8: stp     x30, x21, [sp, #-0x20]!                    
02cae7ec: stp     x20, x19, [sp, #0x10]                      
02cae7f0: mov     x19, x0                                    
02cae7f4: ldr     x0, [x0, #0x30]                            ._tfHighlight
02cae7f8: cbz     x0, #0x2cae878                             
02cae7fc: mov     x2, xzr                                    
02cae800: bl      #0x5b472ec                                 UnityEngine.Transform::SetParent
02cae804: adrp    x21, #0x662f000                            
02cae808: ldr     x20, [x19, #0x30]                          ._tfHighlight
02cae80c: ldrb    w8, [x21, #0x91a]                          
02cae810: cbnz    w8, #0x2cae828                             
02cae814: adrp    x0, #0x6264000                             
02cae818: ldr     x0, [x0, #0xd8]                            T:UnityEngine.Vector3
02cae81c: bl      #0x2b70db0                                 fn_2b70db0
02cae820: mov     w8, #1                                     
02cae824: strb    w8, [x21, #0x91a]                          
02cae828: cbz     x20, #0x2cae878                            
02cae82c: adrp    x8, #0x6264000                             
02cae830: mov     x0, x20                                    
02cae834: mov     x1, xzr                                    
02cae838: ldr     x8, [x8, #0xd8]                            T:UnityEngine.Vector3
02cae83c: ldr     x8, [x8]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02cae840: ldr     x8, [x8, #0xb8]                            MS:DG.Tweening.Core.Extensions::SetSpecialStartupMode
02cae844: ldp     s1, s2, [x8, #4]                           
02cae848: ldr     s0, [x8]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02cae84c: bl      #0x5b45cec                                 UnityEngine.Transform::set_localPosition
02cae850: ldr     x0, [x19, #0x30]                           ._tfHighlight
02cae854: cbz     x0, #0x2cae878                             
02cae858: mov     x1, xzr                                    
02cae85c: bl      #0x5b339ec                                 UnityEngine.Component::get_gameObject
02cae860: cbz     x0, #0x2cae878                             
02cae864: ldp     x20, x19, [sp, #0x10]                      
02cae868: mov     w1, #1                                     
02cae86c: mov     x2, xzr                                    
02cae870: ldp     x30, x21, [sp], #0x20                      
02cae874: b       #0x5b36b38                                 UnityEngine.GameObject::SetActive
02cae878: bl      #0x2b7105c                                 fn_2b7105c
## ShowBackScreenInGame() -> void
---- DreamHouseFirstGameTutorial::ShowBackScreenInGame 0x2cae87c
02cae87c: str     x30, [sp, #-0x10]!                         
02cae880: ldr     x0, [x0, #0x30]                            ._tfHighlight
02cae884: cbz     x0, #0x2cae8a4                             
02cae888: mov     x1, xzr                                    
02cae88c: bl      #0x5b339ec                                 UnityEngine.Component::get_gameObject
02cae890: cbz     x0, #0x2cae8a4                             
02cae894: mov     w1, #1                                     
02cae898: mov     x2, xzr                                    
02cae89c: ldr     x30, [sp], #0x10                           
02cae8a0: b       #0x5b36b38                                 UnityEngine.GameObject::SetActive
02cae8a4: bl      #0x2b7105c                                 fn_2b7105c
## HideTutorial() -> void
---- DreamHouseFirstGameTutorial::HideTutorial 0x2cae8a8
02cae8a8: stp     x30, x23, [sp, #-0x30]!                    
02cae8ac: stp     x22, x21, [sp, #0x10]                      
02cae8b0: stp     x20, x19, [sp, #0x20]                      
02cae8b4: adrp    x20, #0x662f000                            
02cae8b8: mov     x19, x0                                    
02cae8bc: ldrb    w8, [x20, #0xb4e]                          
02cae8c0: tbnz    w8, #0, #0x2cae8fc                         
02cae8c4: adrp    x0, #0x6266000                             
02cae8c8: ldr     x0, [x0, #0x920]                           M:DreamHouseFirstGameTutorial::<HideTutorial>b__8_0
02cae8cc: bl      #0x2b70db0                                 fn_2b70db0
02cae8d0: adrp    x0, #0x6264000                             
02cae8d4: ldr     x0, [x0, #0xe8]                            T:DG.Tweening.TweenCallback
02cae8d8: bl      #0x2b70db0                                 fn_2b70db0
02cae8dc: adrp    x0, #0x6266000                             
02cae8e0: ldr     x0, [x0, #0x928]                           MS:DG.Tweening.TweenSettingsExtensions::OnComplete
02cae8e4: bl      #0x2b70db0                                 fn_2b70db0
02cae8e8: adrp    x0, #0x6266000                             
02cae8ec: ldr     x0, [x0, #0x880]                           MS:DG.Tweening.TweenSettingsExtensions::SetEase
02cae8f0: bl      #0x2b70db0                                 fn_2b70db0
02cae8f4: mov     w8, #1                                     
02cae8f8: strb    w8, [x20, #0xb4e]                          
02cae8fc: ldr     x20, [x19, #0x30]                          ._tfHighlight
02cae900: mov     x0, x19                                    
02cae904: mov     x1, xzr                                    
02cae908: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02cae90c: cbz     x20, #0x2cae9e0                            
02cae910: mov     x1, x0                                     
02cae914: mov     x0, x20                                    
02cae918: mov     x2, xzr                                    
02cae91c: bl      #0x5b472ec                                 UnityEngine.Transform::SetParent
02cae920: ldr     x0, [x19, #0x30]                           ._tfHighlight
02cae924: cbz     x0, #0x2cae9e0                             
02cae928: mov     x1, xzr                                    
02cae92c: bl      #0x5b339ec                                 UnityEngine.Component::get_gameObject
02cae930: cbz     x0, #0x2cae9e0                             
02cae934: mov     w1, wzr                                    
02cae938: mov     x2, xzr                                    
02cae93c: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02cae940: ldr     x0, [x19, #0x28]                           ._goScreenInGame
02cae944: cbz     x0, #0x2cae9e0                             
02cae948: mov     x1, xzr                                    
02cae94c: bl      #0x5b37654                                 UnityEngine.GameObject::get_gameObject
02cae950: cbz     x0, #0x2cae9e0                             
02cae954: adrp    x20, #0x6266000                            
02cae958: adrp    x21, #0x6264000                            
02cae95c: adrp    x22, #0x6266000                            
02cae960: adrp    x23, #0x6266000                            
02cae964: ldr     x20, [x20, #0x880]                         MS:DG.Tweening.TweenSettingsExtensions::SetEase
02cae968: ldr     x21, [x21, #0xe8]                          T:DG.Tweening.TweenCallback
02cae96c: ldr     x22, [x22, #0x920]                         M:DreamHouseFirstGameTutorial::<HideTutorial>b__8_0
02cae970: ldr     x23, [x23, #0x928]                         MS:DG.Tweening.TweenSettingsExtensions::OnComplete
02cae974: mov     w1, #1                                     
02cae978: mov     x2, xzr                                    
02cae97c: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02cae980: movi    d0, #0000000000000000                      
02cae984: fmov    s1, #0.50000000                            
02cae988: ldr     x0, [x19, #0x38]                           ._tfIntroContent
02cae98c: mov     x1, xzr                                    
02cae990: bl      #0x2d98c98                                 DG.Tweening.ShortcutExtensions::DOScale
02cae994: ldr     x2, [x20]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cae998: mov     w1, #0x1a                                  
02cae99c: bl      #0x336fa0c                                 fn_336fa0c
02cae9a0: ldr     x8, [x21]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02cae9a4: mov     x20, x0                                    
02cae9a8: mov     x0, x8                                     
02cae9ac: bl      #0x2b7104c                                 fn_2b7104c
02cae9b0: ldr     x2, [x22]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cae9b4: mov     x1, x19                                    
02cae9b8: mov     x3, xzr                                    
02cae9bc: mov     x21, x0                                    
02cae9c0: bl      #0x2d89dc4                                 DG.Tweening.TweenCallback::.ctor
02cae9c4: mov     x0, x20                                    
02cae9c8: mov     x1, x21                                    
02cae9cc: ldr     x2, [x23]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cae9d0: ldp     x20, x19, [sp, #0x20]                      
02cae9d4: ldp     x22, x21, [sp, #0x10]                      
02cae9d8: ldp     x30, x23, [sp], #0x30                      
02cae9dc: b       #0x336f26c                                 
02cae9e0: bl      #0x2b7105c                                 fn_2b7105c
## .ctor() -> void
---- DreamHouseFirstGameTutorial::.ctor 0x2cae9e4
02cae9e4: stp     x30, x21, [sp, #-0x20]!                    
02cae9e8: stp     x20, x19, [sp, #0x10]                      
02cae9ec: adrp    x20, #0x662f000                            
02cae9f0: adrp    x21, #0x6266000                            
02cae9f4: mov     x19, x0                                    
02cae9f8: ldrb    w8, [x20, #0xb4f]                          
02cae9fc: ldr     x21, [x21, #0x930]                         MS:MonoSingleton`1::.ctor
02caea00: tbnz    w8, #0, #0x2caea18                         
02caea04: adrp    x0, #0x6266000                             
02caea08: ldr     x0, [x0, #0x930]                           MS:MonoSingleton`1::.ctor
02caea0c: bl      #0x2b70db0                                 fn_2b70db0
02caea10: mov     w8, #1                                     
02caea14: strb    w8, [x20, #0xb4f]                          
02caea18: mov     x0, x19                                    
02caea1c: ldp     x20, x19, [sp, #0x10]                      
02caea20: ldr     x1, [x21]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02caea24: ldp     x30, x21, [sp], #0x20                      
02caea28: b       #0x3769e18                                 
## <HideTutorial>b__8_0() -> void
---- DreamHouseFirstGameTutorial::<HideTutorial>b__8_0 0x2caea2c
02caea2c: str     x30, [sp, #-0x10]!                         
02caea30: ldr     x0, [x0, #0x20]                            ._btnIntro
02caea34: cbz     x0, #0x2caea54                             
02caea38: mov     x1, xzr                                    
02caea3c: bl      #0x5b339ec                                 UnityEngine.Component::get_gameObject
02caea40: cbz     x0, #0x2caea54                             
02caea44: mov     w1, wzr                                    
02caea48: mov     x2, xzr                                    
02caea4c: ldr     x30, [sp], #0x10                           
02caea50: b       #0x5b36b38                                 UnityEngine.GameObject::SetActive
02caea54: bl      #0x2b7105c                                 fn_2b7105c
