#### CLASS Home.PopupLanguage/<>c parent= object
#   field <>9                            Home.PopupLanguage/<>c                             off=0x0 attr=36 
#   field <>9__9_0                       System.Predicate`1<LanguageUIItem>                 off=0x8 attr=16 
## .cctor() -> void
---- Home.PopupLanguage/<>c::.cctor 0x2d22714
02d22714: str     x30, [sp, #-0x20]!                         
02d22718: stp     x20, x19, [sp, #0x10]                      
02d2271c: adrp    x19, #0x6630000                            
02d22720: adrp    x20, #0x6269000                            
02d22724: ldrb    w8, [x19, #0x51]                           
02d22728: ldr     x20, [x20, #0xe90]                         T:Home.PopupLanguage/<>c
02d2272c: tbnz    w8, #0, #0x2d22744                         
02d22730: adrp    x0, #0x6269000                             
02d22734: ldr     x0, [x0, #0xe90]                           T:Home.PopupLanguage/<>c
02d22738: bl      #0x2b70db0                                 fn_2b70db0
02d2273c: mov     w8, #1                                     
02d22740: strb    w8, [x19, #0x51]                           
02d22744: ldr     x0, [x20]                                  T:Trading.TradingSession/<>c__DisplayClass56_0
02d22748: bl      #0x2b7104c                                 fn_2b7104c
02d2274c: mov     x1, xzr                                    
02d22750: mov     x19, x0                                    
02d22754: bl      #0x4e53e9c                                 System.Object::.ctor
02d22758: ldr     x8, [x20]                                  T:Trading.TradingSession/<>c__DisplayClass56_0
02d2275c: mov     x1, x19                                    
02d22760: ldr     x8, [x8, #0xb8]                            
02d22764: str     x19, [x8]                                  
02d22768: ldr     x8, [x20]                                  T:Trading.TradingSession/<>c__DisplayClass56_0
02d2276c: ldp     x20, x19, [sp, #0x10]                      
02d22770: ldr     x0, [x8, #0xb8]                            
02d22774: ldr     x30, [sp], #0x20                           
02d22778: b       #0x2b70d54                                 
## .ctor() -> void
---- Home.PopupLanguage/<>c::.ctor 0x2d2277c
02d2277c: mov     x1, xzr                                    
02d22780: b       #0x4e53e9c                                 System.Object::.ctor
## <OnButtonNextClicked>b__9_0(LanguageUIItem x) -> bool
---- Home.PopupLanguage/<>c::<OnButtonNextClicked>b__9_0 0x2d22784
02d22784: cbz     x1, #0x2d22790                             
02d22788: ldrb    w0, [x1, #0x60]                            
02d2278c: ret                                                
02d22790: str     x30, [sp, #-0x10]!                         
02d22794: bl      #0x2b7105c                                 fn_2b7105c
#### CLASS Home.PopupLanguage parent= PopupBase
#   field _btnConfirm                    UnityEngine.UI.Button                              off=0x38 attr=1 SerializeField
#   field _cellItem                      LanguageUIItem                                     off=0x40 attr=1 SerializeField
#   field _languageList                  System.Collections.Generic.List`1<LanguageUIItem>  off=0x48 attr=1 SerializeField
#   field _rtScrollView                  UnityEngine.RectTransform                          off=0x50 attr=1 SerializeField
## OnInit(UIManager uiManager) -> void
---- Home.PopupLanguage::OnInit 0x2d21d10
02d21d10: stp     x30, x21, [sp, #-0x20]!                    
02d21d14: stp     x20, x19, [sp, #0x10]                      
02d21d18: adrp    x21, #0x6630000                            
02d21d1c: mov     x20, x1                                    
02d21d20: mov     x19, x0                                    
02d21d24: ldrb    w8, [x21, #0x4c]                           
02d21d28: tbnz    w8, #0, #0x2d21d4c                         
02d21d2c: adrp    x0, #0x6269000                             
02d21d30: ldr     x0, [x0, #0xe28]                           M:Home.PopupLanguage::OnButtonNextClicked
02d21d34: bl      #0x2b70db0                                 fn_2b70db0
02d21d38: adrp    x0, #0x6265000                             
02d21d3c: ldr     x0, [x0, #0x3f0]                           T:UnityEngine.Events.UnityAction
02d21d40: bl      #0x2b70db0                                 fn_2b70db0
02d21d44: mov     w8, #1                                     
02d21d48: strb    w8, [x21, #0x4c]                           
02d21d4c: mov     x0, x19                                    
02d21d50: mov     x1, x20                                    
02d21d54: mov     x2, xzr                                    
02d21d58: bl      #0x2cdd3c4                                 UIBase::OnInit
02d21d5c: ldr     x8, [x19, #0x38]                           ._btnConfirm
02d21d60: cbz     x8, #0x2d21e18                             
02d21d64: adrp    x9, #0x6265000                             
02d21d68: adrp    x21, #0x6269000                            
02d21d6c: ldr     x9, [x9, #0x3f0]                           T:UnityEngine.Events.UnityAction
02d21d70: ldr     x21, [x21, #0xe28]                         M:Home.PopupLanguage::OnButtonNextClicked
02d21d74: ldr     x20, [x8, #0x100]                          
02d21d78: ldr     x0, [x9]                                   M:AdsManager::<OnApplicationPause>b__26_0
02d21d7c: bl      #0x2b7104c                                 fn_2b7104c
02d21d80: ldr     x2, [x21]                                  T:Trading.TradingSession/<>c__DisplayClass56_0
02d21d84: mov     x1, x19                                    
02d21d88: mov     x3, xzr                                    
02d21d8c: mov     x21, x0                                    
02d21d90: bl      #0x5b4cf98                                 UnityEngine.Events.UnityAction::.ctor
02d21d94: cbz     x20, #0x2d21e18                            
02d21d98: mov     x0, x20                                    
02d21d9c: mov     x1, x21                                    
02d21da0: mov     x2, xzr                                    
02d21da4: bl      #0x5b4d0ac                                 UnityEngine.Events.UnityEvent::AddListener
02d21da8: ldr     x0, [x19, #0x40]                           ._cellItem
02d21dac: cbz     x0, #0x2d21e18                             
02d21db0: mov     x1, xzr                                    
02d21db4: bl      #0x5b339ec                                 UnityEngine.Component::get_gameObject
02d21db8: cbz     x0, #0x2d21e18                             
02d21dbc: mov     x1, xzr                                    
02d21dc0: bl      #0x5b36bfc                                 UnityEngine.GameObject::get_activeSelf
02d21dc4: tbz     w0, #0, #0x2d21de8                         
02d21dc8: ldr     x0, [x19, #0x40]                           ._cellItem
02d21dcc: cbz     x0, #0x2d21e18                             
02d21dd0: mov     x1, xzr                                    
02d21dd4: bl      #0x5b339ec                                 UnityEngine.Component::get_gameObject
02d21dd8: cbz     x0, #0x2d21e18                             
02d21ddc: mov     w1, wzr                                    
02d21de0: mov     x2, xzr                                    
02d21de4: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d21de8: mov     x0, x19                                    
02d21dec: bl      #0x2d21e1c                                 Home.PopupLanguage::LoadLanguage
02d21df0: ldr     x0, [x19, #0x38]                           ._btnConfirm
02d21df4: cbz     x0, #0x2d21e18                             
02d21df8: mov     x1, xzr                                    
02d21dfc: bl      #0x5b339ec                                 UnityEngine.Component::get_gameObject
02d21e00: cbz     x0, #0x2d21e18                             
02d21e04: ldp     x20, x19, [sp, #0x10]                      
02d21e08: mov     w1, wzr                                    
02d21e0c: mov     x2, xzr                                    
02d21e10: ldp     x30, x21, [sp], #0x20                      
02d21e14: b       #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d21e18: bl      #0x2b7105c                                 fn_2b7105c
## OnShow() -> void
---- Home.PopupLanguage::OnShow 0x2d22118
02d22118: str     x30, [sp, #-0x40]!                         
02d2211c: stp     x24, x23, [sp, #0x10]                      
02d22120: stp     x22, x21, [sp, #0x20]                      
02d22124: stp     x20, x19, [sp, #0x30]                      
02d22128: adrp    x20, #0x6630000                            
02d2212c: mov     x19, x0                                    
02d22130: ldrb    w8, [x20, #0x4d]                           
02d22134: tbnz    w8, #0, #0x2d22170                         
02d22138: adrp    x0, #0x6266000                             
02d2213c: ldr     x0, [x0, #0x750]                           MS:DataManager::GetData
02d22140: bl      #0x2b70db0                                 fn_2b70db0
02d22144: adrp    x0, #0x6269000                             
02d22148: ldr     x0, [x0, #0xe38]                           MS:System.Collections.Generic.List`1::get_Count
02d2214c: bl      #0x2b70db0                                 fn_2b70db0
02d22150: adrp    x0, #0x6269000                             
02d22154: ldr     x0, [x0, #0xe40]                           MS:System.Collections.Generic.List`1::get_Item
02d22158: bl      #0x2b70db0                                 fn_2b70db0
02d2215c: adrp    x0, #0x6266000                             
02d22160: ldr     x0, [x0, #0x658]                           MS:MonoSingleton`1::get_Instance
02d22164: bl      #0x2b70db0                                 fn_2b70db0
02d22168: mov     w8, #1                                     
02d2216c: strb    w8, [x20, #0x4d]                           
02d22170: mov     x0, x19                                    
02d22174: mov     x1, xzr                                    
02d22178: bl      #0x2cdd6b8                                 UIBase::OnShow
02d2217c: ldr     x0, [x19, #0x48]                           ._languageList
02d22180: cbz     x0, #0x2d2224c                             
02d22184: adrp    x22, #0x6269000                            
02d22188: adrp    x23, #0x6266000                            
02d2218c: adrp    x24, #0x6266000                            
02d22190: ldr     x22, [x22, #0xe40]                         MS:System.Collections.Generic.List`1::get_Item
02d22194: ldr     x23, [x23, #0x658]                         MS:MonoSingleton`1::get_Instance
02d22198: ldr     x24, [x24, #0x750]                         MS:DataManager::GetData
02d2219c: mov     w20, wzr                                   
02d221a0: ldr     w8, [x0, #0x18]                            S:'level_show_popuprate'
02d221a4: cmp     w20, w8                                    
02d221a8: b.ge    #0x2d22250                                 
02d221ac: ldr     x2, [x22]                                  T:Trading.TradingSession/<>c__DisplayClass56_0
02d221b0: mov     w1, w20                                    
02d221b4: bl      #0x35a8f3c                                 fn_35a8f3c
02d221b8: cbz     x0, #0x2d2224c                             
02d221bc: ldr     x8, [x0, #0x58]                            S:'inter_ad_on_off'
02d221c0: cbz     x8, #0x2d2224c                             
02d221c4: ldr     x0, [x23]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d221c8: ldr     x21, [x8, #0x10]                           
02d221cc: bl      #0x3769600                                 fn_3769600
02d221d0: cbz     x0, #0x2d2224c                             
02d221d4: ldr     x1, [x24]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d221d8: bl      #0x3168dd0                                 fn_3168dd0
02d221dc: cbz     x0, #0x2d2224c                             
02d221e0: ldr     x8, [x0, #0x20]                            S:'inter_ad_capping_time'
02d221e4: cbz     x8, #0x2d2224c                             
02d221e8: ldr     x1, [x8, #0x28]                            
02d221ec: mov     x0, x21                                    
02d221f0: mov     x2, xzr                                    
02d221f4: bl      #0x4ca52b8                                 System.String::op_Equality
02d221f8: tbz     w0, #0, #0x2d22240                         
02d221fc: ldr     x0, [x19, #0x48]                           ._languageList
02d22200: cbz     x0, #0x2d2224c                             
02d22204: ldr     x2, [x22]                                  T:Trading.TradingSession/<>c__DisplayClass56_0
02d22208: mov     w1, w20                                    
02d2220c: bl      #0x35a8f3c                                 fn_35a8f3c
02d22210: cbz     x0, #0x2d2224c                             
02d22214: mov     w1, #1                                     
02d22218: mov     x2, xzr                                    
02d2221c: bl      #0x2cb0124                                 LanguageUIItem::Select
02d22220: ldr     x0, [x19, #0x38]                           ._btnConfirm
02d22224: cbz     x0, #0x2d2224c                             
02d22228: mov     x1, xzr                                    
02d2222c: bl      #0x5b339ec                                 UnityEngine.Component::get_gameObject
02d22230: cbz     x0, #0x2d2224c                             
02d22234: mov     w1, #1                                     
02d22238: mov     x2, xzr                                    
02d2223c: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d22240: ldr     x0, [x19, #0x48]                           ._languageList
02d22244: add     w20, w20, #1                               
02d22248: cbnz    x0, #0x2d221a0                             
02d2224c: bl      #0x2b7105c                                 fn_2b7105c
02d22250: ldp     x20, x19, [sp, #0x30]                      
02d22254: ldp     x22, x21, [sp, #0x20]                      
02d22258: ldp     x24, x23, [sp, #0x10]                      
02d2225c: ldr     x30, [sp], #0x40                           
02d22260: ret                                                
## OnHide() -> void
---- Home.PopupLanguage::OnHide 0x2d22264
02d22264: mov     x1, xzr                                    
02d22268: b       #0x2cddc10                                 UIBase::OnHide
## LoadLanguage() -> void
---- Home.PopupLanguage::LoadLanguage 0x2d21e1c
02d21e1c: stp     x29, x30, [sp, #-0x60]!                    
02d21e20: stp     x28, x27, [sp, #0x10]                      
02d21e24: stp     x26, x25, [sp, #0x20]                      
02d21e28: stp     x24, x23, [sp, #0x30]                      
02d21e2c: stp     x22, x21, [sp, #0x40]                      
02d21e30: stp     x20, x19, [sp, #0x50]                      
02d21e34: adrp    x20, #0x6630000                            
02d21e38: adrp    x21, #0x6266000                            
02d21e3c: mov     x19, x0                                    
02d21e40: ldrb    w8, [x20, #0x4e]                           
02d21e44: ldr     x21, [x21, #0x658]                         MS:MonoSingleton`1::get_Instance
02d21e48: tbnz    w8, #0, #0x2d21ecc                         
02d21e4c: adrp    x0, #0x6268000                             
02d21e50: ldr     x0, [x0, #0x210]                           MS:DataManager::GetAsset
02d21e54: bl      #0x2b70db0                                 fn_2b70db0
02d21e58: adrp    x0, #0x6266000                             
02d21e5c: ldr     x0, [x0, #0x750]                           MS:DataManager::GetData
02d21e60: bl      #0x2b70db0                                 fn_2b70db0
02d21e64: adrp    x0, #0x6269000                             
02d21e68: ldr     x0, [x0, #0xe30]                           MS:System.Collections.Generic.List`1::Add
02d21e6c: bl      #0x2b70db0                                 fn_2b70db0
02d21e70: adrp    x0, #0x6267000                             
02d21e74: ldr     x0, [x0, #0xae8]                           MS:System.Collections.Generic.List`1::get_Count
02d21e78: bl      #0x2b70db0                                 fn_2b70db0
02d21e7c: adrp    x0, #0x6269000                             
02d21e80: ldr     x0, [x0, #0xe38]                           MS:System.Collections.Generic.List`1::get_Count
02d21e84: bl      #0x2b70db0                                 fn_2b70db0
02d21e88: adrp    x0, #0x6267000                             
02d21e8c: ldr     x0, [x0, #0xaf0]                           MS:System.Collections.Generic.List`1::get_Item
02d21e90: bl      #0x2b70db0                                 fn_2b70db0
02d21e94: adrp    x0, #0x6269000                             
02d21e98: ldr     x0, [x0, #0xe40]                           MS:System.Collections.Generic.List`1::get_Item
02d21e9c: bl      #0x2b70db0                                 fn_2b70db0
02d21ea0: adrp    x0, #0x6266000                             
02d21ea4: ldr     x0, [x0, #0x658]                           MS:MonoSingleton`1::get_Instance
02d21ea8: bl      #0x2b70db0                                 fn_2b70db0
02d21eac: adrp    x0, #0x6269000                             
02d21eb0: ldr     x0, [x0, #0xe48]                           MS:UnityEngine.Object::Instantiate
02d21eb4: bl      #0x2b70db0                                 fn_2b70db0
02d21eb8: adrp    x0, #0x6263000                             
02d21ebc: ldr     x0, [x0, #0x918]                           T:UnityEngine.Object
02d21ec0: bl      #0x2b70db0                                 fn_2b70db0
02d21ec4: mov     w8, #1                                     
02d21ec8: strb    w8, [x20, #0x4e]                           
02d21ecc: ldr     x0, [x21]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d21ed0: bl      #0x3769600                                 fn_3769600
02d21ed4: cbz     x0, #0x2d220f8                             
02d21ed8: adrp    x8, #0x6268000                             
02d21edc: ldr     x8, [x8, #0x210]                           MS:DataManager::GetAsset
02d21ee0: ldr     x1, [x8]                                   S:'{0}/2'
02d21ee4: bl      #0x3168af0                                 fn_3168af0
02d21ee8: cbz     x0, #0x2d220f8                             
02d21eec: ldr     x21, [x19, #0x48]                          ._languageList
02d21ef0: cbz     x21, #0x2d220f8                            
02d21ef4: ldr     x20, [x0, #0x18]                           &2c5d934(=d65f03c0d503245f)
02d21ef8: cbz     x20, #0x2d220f8                            
02d21efc: adrp    x25, #0x6269000                            
02d21f00: adrp    x26, #0x6267000                            
02d21f04: adrp    x27, #0x6266000                            
02d21f08: adrp    x28, #0x6263000                            
02d21f0c: adrp    x29, #0x6269000                            
02d21f10: adrp    x24, #0x6269000                            
02d21f14: ldr     x25, [x25, #0xe40]                         MS:System.Collections.Generic.List`1::get_Item
02d21f18: ldr     x26, [x26, #0xaf0]                         MS:System.Collections.Generic.List`1::get_Item
02d21f1c: ldr     x27, [x27, #0x750]                         MS:DataManager::GetData
02d21f20: ldr     x28, [x28, #0x918]                         T:UnityEngine.Object
02d21f24: ldr     x29, [x29, #0xe48]                         MS:UnityEngine.Object::Instantiate
02d21f28: ldr     x24, [x24, #0xe30]                         MS:System.Collections.Generic.List`1::Add
02d21f2c: ldr     w8, [x21, #0x18]                           S:'level_show_popuprate'
02d21f30: ldr     w22, [x20, #0x18]                          
02d21f34: cmp     w8, w22                                    
02d21f38: b.ge    #0x2d21fe8                                 
02d21f3c: ldr     x22, [x19, #0x40]                          ._cellItem
02d21f40: cbz     x22, #0x2d220f8                            
02d21f44: mov     x0, x22                                    
02d21f48: mov     x1, xzr                                    
02d21f4c: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02d21f50: cbz     x0, #0x2d220f8                             
02d21f54: mov     x1, xzr                                    
02d21f58: bl      #0x5b466dc                                 UnityEngine.Transform::get_parent
02d21f5c: ldr     x8, [x28]                                  &2c5bbd4(=a9bd7bfdd503233f)
02d21f60: mov     x23, x0                                    
02d21f64: ldr     w9, [x8, #0xe4]                            [62680e4]=0 f=0,0
02d21f68: cbnz    w9, #0x2d21f74                             
02d21f6c: mov     x0, x8                                     
02d21f70: bl      #0x2b70f30                                 fn_2b70f30
02d21f74: ldr     x2, [x29]                                  T:Trading.TradingSession/<>c__DisplayClass56_0
02d21f78: mov     x0, x22                                    
02d21f7c: mov     x1, x23                                    
02d21f80: bl      #0x3275fcc                                 fn_3275fcc
02d21f84: ldr     w10, [x21, #0x1c]                          [626601c]=0 f=0,0
02d21f88: ldr     x8, [x21, #0x10]                           S:'mrec_ad_on_off'
02d21f8c: ldr     x9, [x24]                                  T:Trading.TradingSession/<>c__DisplayClass56_0
02d21f90: add     w10, w10, #1                               
02d21f94: str     w10, [x21, #0x1c]                          
02d21f98: cbz     x8, #0x2d220f8                             
02d21f9c: ldrsw   x10, [x21, #0x18]                          
02d21fa0: ldr     w11, [x8, #0x18]                           M:LuckyWheelPopup/<>c__DisplayClass50_0::<RunAnimation>b__0
02d21fa4: mov     x1, x0                                     
02d21fa8: cmp     w10, w11                                   
02d21fac: b.hs    #0x2d21fc8                                 
02d21fb0: add     x0, x8, x10, lsl #3                        &6268000
02d21fb4: add     w9, w10, #1                                
02d21fb8: str     w9, [x21, #0x18]                           
02d21fbc: str     x1, [x0, #0x20]!                           
02d21fc0: bl      #0x2b70d54                                 fn_2b70d54
02d21fc4: b       #0x2d21fdc                                 
02d21fc8: ldr     x8, [x9, #0x20]                            
02d21fcc: mov     x0, x21                                    
02d21fd0: ldr     x8, [x8, #0xc0]                            M:LuckyWheelPopup/<>c__DisplayClass54_0::<GetMoney>b__0
02d21fd4: ldr     x2, [x8, #0x70]                            T:type57276(k15)
02d21fd8: bl      #0x35a920c                                 fn_35a920c
02d21fdc: ldr     x21, [x19, #0x48]                          ._languageList
02d21fe0: cbnz    x21, #0x2d21f2c                            
02d21fe4: b       #0x2d220f8                                 
02d21fe8: cmp     w22, #1                                    
02d21fec: b.lt    #0x2d220c0                                 
02d21ff0: adrp    x23, #0x6266000                            
02d21ff4: mov     w21, wzr                                   
02d21ff8: ldr     x23, [x23, #0x658]                         MS:MonoSingleton`1::get_Instance
02d21ffc: ldr     x0, [x19, #0x48]                           ._languageList
02d22000: cbz     x0, #0x2d220f8                             
02d22004: ldr     x2, [x25]                                  T:Trading.TradingSession/<>c__DisplayClass56_0
02d22008: mov     w1, w21                                    
02d2200c: bl      #0x35a8f3c                                 fn_35a8f3c
02d22010: ldr     x2, [x26]                                  S:'didu'
02d22014: mov     x22, x0                                    
02d22018: mov     x0, x20                                    
02d2201c: mov     w1, w21                                    
02d22020: bl      #0x35a8f3c                                 fn_35a8f3c
02d22024: cbz     x22, #0x2d220f8                            
02d22028: mov     x1, x0                                     
02d2202c: mov     x0, x22                                    
02d22030: mov     x2, xzr                                    
02d22034: bl      #0x2caff94                                 LanguageUIItem::SetData
02d22038: ldr     x2, [x26]                                  S:'didu'
02d2203c: mov     x0, x20                                    
02d22040: mov     w1, w21                                    
02d22044: bl      #0x35a8f3c                                 fn_35a8f3c
02d22048: cbz     x0, #0x2d220f8                             
02d2204c: ldr     x22, [x0, #0x10]                           &2c498bc(=aa1f03e0d503245f)
02d22050: ldr     x0, [x23]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d22054: bl      #0x3769600                                 fn_3769600
02d22058: cbz     x0, #0x2d220f8                             
02d2205c: ldr     x1, [x27]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d22060: bl      #0x3168dd0                                 fn_3168dd0
02d22064: cbz     x0, #0x2d220f8                             
02d22068: ldr     x8, [x0, #0x20]                            &2c5bd40(=14c8d27fd503245f)
02d2206c: cbz     x8, #0x2d220f8                             
02d22070: ldr     x1, [x8, #0x28]                            T:LuckyWheelPopup/<>c__DisplayClass52_0
02d22074: mov     x0, x22                                    
02d22078: mov     x2, xzr                                    
02d2207c: bl      #0x4ca52b8                                 System.String::op_Equality
02d22080: tbz     w0, #0, #0x2d220a8                         
02d22084: ldr     x0, [x19, #0x48]                           ._languageList
02d22088: cbz     x0, #0x2d220f8                             
02d2208c: ldr     x2, [x25]                                  T:Trading.TradingSession/<>c__DisplayClass56_0
02d22090: mov     w1, w21                                    
02d22094: bl      #0x35a8f3c                                 fn_35a8f3c
02d22098: cbz     x0, #0x2d220f8                             
02d2209c: mov     w1, #1                                     
02d220a0: mov     x2, xzr                                    
02d220a4: bl      #0x2cb0124                                 LanguageUIItem::Select
02d220a8: ldr     w22, [x20, #0x18]                          
02d220ac: add     w21, w21, #1                               
02d220b0: cmp     w21, w22                                   
02d220b4: b.lt    #0x2d21ffc                                 
02d220b8: ldr     x21, [x19, #0x48]                          ._languageList
02d220bc: cbz     x21, #0x2d220f8                            
02d220c0: ldr     w8, [x21, #0x18]                           S:'level_show_popuprate'
02d220c4: cmp     w22, w8                                    
02d220c8: b.ge    #0x2d220fc                                 
02d220cc: ldr     x2, [x25]                                  T:Trading.TradingSession/<>c__DisplayClass56_0
02d220d0: mov     x0, x21                                    
02d220d4: mov     w1, w22                                    
02d220d8: bl      #0x35a8f3c                                 fn_35a8f3c
02d220dc: cbz     x0, #0x2d220f8                             
02d220e0: mov     x1, xzr                                    
02d220e4: mov     x2, xzr                                    
02d220e8: bl      #0x2caff94                                 LanguageUIItem::SetData
02d220ec: ldr     x21, [x19, #0x48]                          ._languageList
02d220f0: add     w22, w22, #1                               
02d220f4: cbnz    x21, #0x2d220c0                            
02d220f8: bl      #0x2b7105c                                 fn_2b7105c
02d220fc: ldp     x20, x19, [sp, #0x50]                      
02d22100: ldp     x22, x21, [sp, #0x40]                      
02d22104: ldp     x24, x23, [sp, #0x30]                      
02d22108: ldp     x26, x25, [sp, #0x20]                      
02d2210c: ldp     x28, x27, [sp, #0x10]                      
02d22110: ldp     x29, x30, [sp], #0x60                      
02d22114: ret                                                
## ClickLanguageItem(LanguageUIItem item) -> void
---- Home.PopupLanguage::ClickLanguageItem 0x2d2226c
02d2226c: sub     sp, sp, #0x70                              
02d22270: stp     x30, x25, [sp, #0x30]                      
02d22274: stp     x24, x23, [sp, #0x40]                      
02d22278: stp     x22, x21, [sp, #0x50]                      
02d2227c: stp     x20, x19, [sp, #0x60]                      
02d22280: adrp    x21, #0x6630000                            
02d22284: mov     x19, x1                                    
02d22288: mov     x20, x0                                    
02d2228c: ldrb    w8, [x21, #0x4f]                           
02d22290: tbnz    w8, #0, #0x2d222f0                         
02d22294: adrp    x0, #0x6263000                             
02d22298: ldr     x0, [x0, #0x928]                           T:UnityEngine.Debug
02d2229c: bl      #0x2b70db0                                 fn_2b70db0
02d222a0: adrp    x0, #0x6269000                             
02d222a4: ldr     x0, [x0, #0xe50]                           MS:System.Collections.Generic.List`1/Enumerator::Dispose
02d222a8: bl      #0x2b70db0                                 fn_2b70db0
02d222ac: adrp    x0, #0x6269000                             
02d222b0: ldr     x0, [x0, #0xe58]                           MS:System.Collections.Generic.List`1/Enumerator::MoveNext
02d222b4: bl      #0x2b70db0                                 fn_2b70db0
02d222b8: adrp    x0, #0x6269000                             
02d222bc: ldr     x0, [x0, #0xe60]                           MS:System.Collections.Generic.List`1/Enumerator::get_Current
02d222c0: bl      #0x2b70db0                                 fn_2b70db0
02d222c4: adrp    x0, #0x6269000                             
02d222c8: ldr     x0, [x0, #0xe68]                           MS:System.Collections.Generic.List`1::GetEnumerator
02d222cc: bl      #0x2b70db0                                 fn_2b70db0
02d222d0: adrp    x0, #0x6266000                             
02d222d4: ldr     x0, [x0, #0x9f0]                           T:Assets.SimpleLocalization.Scripts.LocalizationManager
02d222d8: bl      #0x2b70db0                                 fn_2b70db0
02d222dc: adrp    x0, #0x6269000                             
02d222e0: ldr     x0, [x0, #0xe70]                           S:'===dev log current language = '
02d222e4: bl      #0x2b70db0                                 fn_2b70db0
02d222e8: mov     w8, #1                                     
02d222ec: strb    w8, [x21, #0x4f]                           
02d222f0: mov     x0, xzr                                    
02d222f4: stp     xzr, xzr, [sp, #0x18]                      
02d222f8: str     xzr, [sp, #0x28]                           
02d222fc: bl      #0x2d6eec8                                 Framework.AudioManager::get_Instance
02d22300: cbz     x0, #0x2d22468                             
02d22304: movi    d1, #0000000000000000                      
02d22308: movi    d2, #0000000000000000                      
02d2230c: mov     w1, #1                                     
02d22310: fmov    s0, #1.00000000                            
02d22314: mov     w2, wzr                                    
02d22318: mov     w3, wzr                                    
02d2231c: mov     x4, xzr                                    
02d22320: bl      #0x2d6f03c                                 Framework.AudioManager::PlaySound
02d22324: cbz     x19, #0x2d22468                            
02d22328: ldr     x8, [x19, #0x58]                           
02d2232c: cbz     x8, #0x2d22468                             
02d22330: adrp    x9, #0x6266000                             
02d22334: ldr     x9, [x9, #0x9f0]                           T:Assets.SimpleLocalization.Scripts.LocalizationManager
02d22338: ldr     x21, [x8, #0x10]                           
02d2233c: ldr     x0, [x9]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d22340: ldr     w9, [x0, #0xe4]                            [62690e4]=0 f=0,0
02d22344: cbnz    w9, #0x2d2234c                             
02d22348: bl      #0x2b70f30                                 fn_2b70f30
02d2234c: mov     x0, x21                                    
02d22350: mov     x1, xzr                                    
02d22354: bl      #0x2d7ac14                                 Assets.SimpleLocalization.Scripts.LocalizationManager::set_Language
02d22358: ldr     x0, [x20, #0x48]                           ._languageList
02d2235c: cbz     x0, #0x2d22468                             
02d22360: adrp    x8, #0x6269000                             
02d22364: adrp    x25, #0x6269000                            
02d22368: adrp    x23, #0x6269000                            
02d2236c: ldr     x8, [x8, #0xe68]                           MS:System.Collections.Generic.List`1::GetEnumerator
02d22370: adrp    x22, #0x6263000                            
02d22374: adrp    x24, #0x6269000                            
02d22378: ldr     x25, [x25, #0xe58]                         MS:System.Collections.Generic.List`1/Enumerator::MoveNext
02d2237c: ldr     x23, [x23, #0xe70]                         S:'===dev log current language = '
02d22380: ldr     x22, [x22, #0x928]                         T:UnityEngine.Debug
02d22384: ldr     x24, [x24, #0xe50]                         MS:System.Collections.Generic.List`1/Enumerator::Dispose
02d22388: ldr     x1, [x8]                                   T:Trading.TradingSession/<>c__DisplayClass56_0
02d2238c: add     x8, sp, #0x18                              
02d22390: add     x21, sp, #0x18                             
02d22394: bl      #0x35a9d9c                                 fn_35a9d9c
02d22398: stp     xzr, x21, [sp, #8]                         
02d2239c: ldr     x1, [x25]                                  T:Trading.TradingSession/<>c__DisplayClass56_0
02d223a0: add     x0, sp, #0x18                              
02d223a4: bl      #0x4690474                                 fn_4690474
02d223a8: tbz     w0, #0, #0x2d223d4                         
02d223ac: ldr     x21, [sp, #0x28]                           
02d223b0: cbz     x21, #0x2d22464                            
02d223b4: mov     x0, x21                                    
02d223b8: mov     w1, wzr                                    
02d223bc: mov     x2, xzr                                    
02d223c0: bl      #0x2cb0124                                 LanguageUIItem::Select
02d223c4: mov     x0, x21                                    
02d223c8: mov     x1, xzr                                    
02d223cc: bl      #0x2cb009c                                 LanguageUIItem::ReloadText
02d223d0: b       #0x2d2239c                                 
02d223d4: ldr     x1, [x24]                                  T:Trading.TradingSession/<>c__DisplayClass56_0
02d223d8: add     x0, sp, #0x18                              
02d223dc: bl      #0x4690470                                 fn_4690470
02d223e0: mov     x0, x19                                    
02d223e4: mov     w1, #1                                     
02d223e8: mov     x2, xzr                                    
02d223ec: bl      #0x2cb0124                                 LanguageUIItem::Select
02d223f0: ldr     x0, [x20, #0x38]                           ._btnConfirm
02d223f4: cbz     x0, #0x2d22468                             
02d223f8: mov     x1, xzr                                    
02d223fc: bl      #0x5b339ec                                 UnityEngine.Component::get_gameObject
02d22400: cbz     x0, #0x2d22468                             
02d22404: mov     w1, #1                                     
02d22408: mov     x2, xzr                                    
02d2240c: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d22410: ldr     x8, [x19, #0x58]                           
02d22414: cbz     x8, #0x2d22468                             
02d22418: ldr     x1, [x8, #0x10]                            M:Trading.TradingSession/<>c__DisplayClass56_0::<RemovePlayerItem>b__0
02d2241c: ldr     x0, [x23]                                  T:Trading.TradingSession/<>c__DisplayClass56_0
02d22420: mov     x2, xzr                                    
02d22424: bl      #0x4c9c514                                 System.String::Concat
02d22428: ldr     x8, [x22]                                  &2c5bbd4(=a9bd7bfdd503233f)
02d2242c: mov     x19, x0                                    
02d22430: ldr     w9, [x8, #0xe4]                            [62690e4]=0 f=0,0
02d22434: cbnz    w9, #0x2d22440                             
02d22438: mov     x0, x8                                     
02d2243c: bl      #0x2b70f30                                 fn_2b70f30
02d22440: mov     x0, x19                                    
02d22444: mov     x1, xzr                                    
02d22448: bl      #0x5af21f4                                 UnityEngine.Debug::Log
02d2244c: ldp     x20, x19, [sp, #0x60]                      
02d22450: ldp     x22, x21, [sp, #0x50]                      
02d22454: ldp     x24, x23, [sp, #0x40]                      
02d22458: ldp     x30, x25, [sp, #0x30]                      
02d2245c: add     sp, sp, #0x70                              
02d22460: ret                                                
02d22464: bl      #0x2b7105c                                 fn_2b7105c
02d22468: bl      #0x2b7105c                                 fn_2b7105c
02d2246c: b       #0x2d22474                                 
02d22470: b       #0x2d22474                                 
02d22474: mov     x21, x0                                    
02d22478: cmp     w1, #1                                     
02d2247c: b.ne    #0x2d224b0                                 
02d22480: mov     x0, x21                                    
02d22484: bl      #0x5e90260                                 fn_5e90260
02d22488: ldr     x21, [x0]                                  T:Trading.TradingSession/<>c__DisplayClass56_0
02d2248c: str     x21, [sp, #8]                              
02d22490: bl      #0x5e90270                                 fn_5e90270
02d22494: ldr     x0, [sp, #0x10]                            
02d22498: ldr     x1, [x24]                                  T:Trading.TradingSession/<>c__DisplayClass56_0
02d2249c: bl      #0x4690470                                 fn_4690470
02d224a0: cbz     x21, #0x2d223e0                            
02d224a4: mov     x0, x21                                    
02d224a8: bl      #0x2b71054                                 fn_2b71054
02d224ac: mov     x21, x0                                    
02d224b0: add     x0, sp, #8                                 
02d224b4: bl      #0x27380c4                                 fn_27380c4
02d224b8: mov     x0, x21                                    
02d224bc: bl      #0x2c6051c                                 fn_2c6051c
02d224c0: bl      #0x27369b8                                 fn_27369b8
## OnButtonNextClicked() -> void
---- Home.PopupLanguage::OnButtonNextClicked 0x2d224c4
02d224c4: str     x30, [sp, #-0x40]!                         
02d224c8: stp     x24, x23, [sp, #0x10]                      
02d224cc: stp     x22, x21, [sp, #0x20]                      
02d224d0: stp     x20, x19, [sp, #0x30]                      
02d224d4: adrp    x20, #0x6630000                            
02d224d8: mov     x19, x0                                    
02d224dc: ldrb    w8, [x20, #0x50]                           ._rtScrollView
02d224e0: tbnz    w8, #0, #0x2d2254c                         
02d224e4: adrp    x0, #0x6266000                             
02d224e8: ldr     x0, [x0, #0x750]                           MS:DataManager::GetData
02d224ec: bl      #0x2b70db0                                 fn_2b70db0
02d224f0: adrp    x0, #0x6269000                             
02d224f4: ldr     x0, [x0, #0xe78]                           MS:System.Collections.Generic.List`1::Find
02d224f8: bl      #0x2b70db0                                 fn_2b70db0
02d224fc: adrp    x0, #0x6266000                             
02d22500: ldr     x0, [x0, #0x658]                           MS:MonoSingleton`1::get_Instance
02d22504: bl      #0x2b70db0                                 fn_2b70db0
02d22508: adrp    x0, #0x6263000                             
02d2250c: ldr     x0, [x0, #0x918]                           T:UnityEngine.Object
02d22510: bl      #0x2b70db0                                 fn_2b70db0
02d22514: adrp    x0, #0x6269000                             
02d22518: ldr     x0, [x0, #0xe80]                           T:type57258(k15)
02d2251c: bl      #0x2b70db0                                 fn_2b70db0
02d22520: adrp    x0, #0x6269000                             
02d22524: ldr     x0, [x0, #0xe88]                           M:Home.PopupLanguage/<>c::<OnButtonNextClicked>b__9_0
02d22528: bl      #0x2b70db0                                 fn_2b70db0
02d2252c: adrp    x0, #0x6269000                             
02d22530: ldr     x0, [x0, #0xe90]                           T:Home.PopupLanguage/<>c
02d22534: bl      #0x2b70db0                                 fn_2b70db0
02d22538: adrp    x0, #0x6269000                             
02d2253c: ldr     x0, [x0, #0xe98]                           MS:UIManager::GetPopup
02d22540: bl      #0x2b70db0                                 fn_2b70db0
02d22544: mov     w8, #1                                     
02d22548: strb    w8, [x20, #0x50]                           ._rtScrollView
02d2254c: mov     x0, xzr                                    
02d22550: bl      #0x2d6eec8                                 Framework.AudioManager::get_Instance
02d22554: cbz     x0, #0x2d22708                             
02d22558: movi    d1, #0000000000000000                      
02d2255c: movi    d2, #0000000000000000                      
02d22560: adrp    x20, #0x6266000                            
02d22564: fmov    s0, #1.00000000                            
02d22568: ldr     x20, [x20, #0x658]                         MS:MonoSingleton`1::get_Instance
02d2256c: mov     w1, #1                                     
02d22570: mov     w2, wzr                                    
02d22574: mov     w3, wzr                                    
02d22578: mov     x4, xzr                                    
02d2257c: bl      #0x2d6f03c                                 Framework.AudioManager::PlaySound
02d22580: ldr     x0, [x20]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d22584: bl      #0x3769600                                 fn_3769600
02d22588: cbz     x0, #0x2d22708                             
02d2258c: adrp    x8, #0x6266000                             
02d22590: adrp    x24, #0x6269000                            
02d22594: ldr     x8, [x8, #0x750]                           MS:DataManager::GetData
02d22598: ldr     x24, [x24, #0xe90]                         T:Home.PopupLanguage/<>c
02d2259c: ldr     x1, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d225a0: bl      #0x3168dd0                                 fn_3168dd0
02d225a4: ldr     x8, [x24]                                  T:Trading.TradingSession/<>c__DisplayClass56_0
02d225a8: ldr     x21, [x19, #0x48]                          ._languageList
02d225ac: mov     x20, x0                                    
02d225b0: ldr     w9, [x8, #0xe4]                            [62660e4]=0 f=0,0
02d225b4: cbnz    w9, #0x2d225c4                             
02d225b8: mov     x0, x8                                     
02d225bc: bl      #0x2b70f30                                 fn_2b70f30
02d225c0: ldr     x8, [x24]                                  T:Trading.TradingSession/<>c__DisplayClass56_0
02d225c4: ldr     x9, [x8, #0xb8]                            S:'banner_native_refresh_time'
02d225c8: ldr     x22, [x9, #8]                              
02d225cc: cbnz    x22, #0x2d2262c                            
02d225d0: ldr     w10, [x8, #0xe4]                           [62660e4]=0 f=0,0
02d225d4: cbnz    w10, #0x2d225e8                            
02d225d8: mov     x0, x8                                     
02d225dc: bl      #0x2b70f30                                 fn_2b70f30
02d225e0: ldr     x8, [x24]                                  T:Trading.TradingSession/<>c__DisplayClass56_0
02d225e4: ldr     x9, [x8, #0xb8]                            S:'banner_native_refresh_time'
02d225e8: adrp    x8, #0x6269000                             
02d225ec: ldr     x8, [x8, #0xe80]                           T:type57258(k15)
02d225f0: ldr     x23, [x9]                                  
02d225f4: ldr     x0, [x8]                                   T:Trading.TradingSession/<>c__DisplayClass56_0
02d225f8: bl      #0x2b7104c                                 fn_2b7104c
02d225fc: adrp    x8, #0x6269000                             
02d22600: mov     x1, x23                                    
02d22604: mov     x3, xzr                                    
02d22608: ldr     x8, [x8, #0xe88]                           M:Home.PopupLanguage/<>c::<OnButtonNextClicked>b__9_0
02d2260c: mov     x22, x0                                    
02d22610: ldr     x2, [x8]                                   T:Trading.TradingSession/<>c__DisplayClass56_0
02d22614: bl      #0x399ba10                                 fn_399ba10
02d22618: ldr     x8, [x24]                                  T:Trading.TradingSession/<>c__DisplayClass56_0
02d2261c: mov     x1, x22                                    
02d22620: ldr     x0, [x8, #0xb8]                            T:Trading.TradingSession/<>c__DisplayClass68_0
02d22624: str     x22, [x0, #8]!                             
02d22628: bl      #0x2b70d54                                 fn_2b70d54
02d2262c: cbz     x21, #0x2d22708                            
02d22630: adrp    x8, #0x6269000                             
02d22634: adrp    x23, #0x6263000                            
02d22638: mov     x0, x21                                    
02d2263c: ldr     x8, [x8, #0xe78]                           MS:System.Collections.Generic.List`1::Find
02d22640: ldr     x23, [x23, #0x918]                         T:UnityEngine.Object
02d22644: mov     x1, x22                                    
02d22648: ldr     x2, [x8]                                   T:Trading.TradingSession/<>c__DisplayClass56_0
02d2264c: bl      #0x35a9868                                 fn_35a9868
02d22650: ldr     x8, [x23]                                  &2c5bbd4(=a9bd7bfdd503233f)
02d22654: mov     x21, x0                                    
02d22658: ldr     w9, [x8, #0xe4]                            [62690e4]=0 f=0,0
02d2265c: cbnz    w9, #0x2d22668                             
02d22660: mov     x0, x8                                     
02d22664: bl      #0x2b70f30                                 fn_2b70f30
02d22668: mov     x0, x21                                    
02d2266c: mov     x1, xzr                                    
02d22670: mov     x2, xzr                                    
02d22674: bl      #0x5b3666c                                 UnityEngine.Object::op_Inequality
02d22678: tbz     w0, #0, #0x2d226c4                         
02d2267c: cbz     x20, #0x2d22708                            
02d22680: cbz     x21, #0x2d22708                            
02d22684: ldr     x8, [x21, #0x58]                           
02d22688: cbz     x8, #0x2d22708                             
02d2268c: ldr     x0, [x20, #0x20]                           S:'inter_ad_capping_time'
02d22690: cbz     x0, #0x2d22708                             
02d22694: ldr     x1, [x8, #0x10]                            M:Trading.TradingSession/<>c__DisplayClass56_0::<RemovePlayerItem>b__0
02d22698: str     x1, [x0, #0x28]!                           
02d2269c: bl      #0x2b70d54                                 fn_2b70d54
02d226a0: ldr     x8, [x20, #0x20]                           S:'inter_ad_capping_time'
02d226a4: cbz     x8, #0x2d22708                             
02d226a8: mov     w9, #1                                     
02d226ac: mov     x0, x20                                    
02d226b0: strb    w9, [x8, #0x39]                            
02d226b4: ldr     x8, [x20]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d226b8: ldr     x9, [x8, #0x258]                           M:Trading.PopupTradingEmptyCollection::OnBtnGoDiyClick
02d226bc: ldr     x1, [x8, #0x260]                           M:Trading.PopupTradingEmptyCollection::OnBtnLaterClick
02d226c0: blr     x9                                         
02d226c4: ldr     x8, [x19]                                  
02d226c8: mov     x0, x19                                    
02d226cc: ldp     x9, x1, [x8, #0x198]                       
02d226d0: blr     x9                                         
02d226d4: ldr     x0, [x19, #0x30]                           
02d226d8: cbz     x0, #0x2d22708                             
02d226dc: adrp    x8, #0x6269000                             
02d226e0: ldr     x8, [x8, #0xe98]                           MS:UIManager::GetPopup
02d226e4: ldr     x1, [x8]                                   T:Trading.TradingSession/<>c__DisplayClass56_0
02d226e8: bl      #0x33fbae4                                 fn_33fbae4
02d226ec: cbz     x0, #0x2d22708                             
02d226f0: ldp     x20, x19, [sp, #0x30]                      
02d226f4: mov     x1, xzr                                    
02d226f8: ldp     x22, x21, [sp, #0x20]                      
02d226fc: ldp     x24, x23, [sp, #0x10]                      
02d22700: ldr     x30, [sp], #0x40                           
02d22704: b       #0x2ce666c                                 ProfilePopup::UpdateLanguage
02d22708: bl      #0x2b7105c                                 fn_2b7105c
## .ctor() -> void
---- Home.PopupLanguage::.ctor 0x2d2270c
02d2270c: mov     x1, xzr                                    
02d22710: b       #0x2cddba8                                 PopupBase::.ctor
