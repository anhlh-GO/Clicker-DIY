#### CLASS Framework.IListExtension parent= object
##  Swap (no body)
##  Shuffle (no body)
##  RandomItem (no body)
##  RemoveRandom (no body)
##  IsNull (no body)
##  IsEmpty (no body)
##  IsIndexOutOfList (no body)
##  IsNullOrEmpty (no body)
