#### CLASS BlindBagCollection.BlindbagDragController parent= UnityEngine.MonoBehaviour
#   field OnDragStart                    System.Action`1<BlindBagCollection.ItemDraggable>  off=0x0 attr=16 
#   field OnDragEnd                      System.Action                                      off=0x8 attr=16 
#   field _itemPrefab                    BlindBagCollection.ItemDraggable                   off=0x20 attr=1 HeaderAttribute,SerializeField
#   field _holder                        UnityEngine.Transform                              off=0x28 attr=1 SerializeField
#   field _focus                         UnityEngine.Transform                              off=0x30 attr=1 SerializeField
#   field _collectionSelector            BlindBagCollection.CollectionSelector              off=0x38 attr=1 SerializeField
#   field _collectionController          BlindBagCollection.BlindbagCollectionController    off=0x40 attr=1 SerializeField
#   field _showCompleteBoxset            BlindBagCollection.ShowCompleteBoxset              off=0x48 attr=1 SerializeField
#   field _randomPositions               UnityEngine.Transform[]                            off=0x50 attr=1 SerializeField
#   field _complimentSprites             System.Collections.Generic.List`1<UnityEngine.Sprite> off=0x58 attr=1 SpaceAttribute,HeaderAttribute,SerializeField
#   field _complimentSoundEnum           System.Collections.Generic.List`1<Framework.ESound> off=0x60 attr=1 SerializeField
#   field _currentItem                   BlindBagCollection.ItemDraggable                   off=0x68 attr=1 SpaceAttribute,HeaderAttribute,SerializeField
#   field _itemLeft                      int                                                off=0x70 attr=1 SerializeField
#   field _dragOffset                    UnityEngine.Vector3                                off=0x74 attr=1 
#   field _dragOffsetBonus               UnityEngine.Vector3                                off=0x80 attr=1 
#   field _mainCamera                    UnityEngine.Camera                                 off=0x90 attr=1 
#   field _collectionDataUser            BlindBagCollection.BlindbagCollectionData          off=0x98 attr=1 
#   field _spawnedItems                  System.Collections.Generic.List`1<UnityEngine.GameObject> off=0xa0 attr=1 
## IsDragging() -> bool
---- BlindBagCollection.BlindbagDragController::IsDragging 0x2d366c0
02d366c0: stp     x30, x21, [sp, #-0x20]!                    
02d366c4: stp     x20, x19, [sp, #0x10]                      
02d366c8: adrp    x21, #0x6630000                            
02d366cc: adrp    x20, #0x6263000                            
02d366d0: mov     x19, x0                                    
02d366d4: ldrb    w8, [x21, #0x11e]                          
02d366d8: ldr     x20, [x20, #0x918]                         T:UnityEngine.Object
02d366dc: tbnz    w8, #0, #0x2d366f4                         
02d366e0: adrp    x0, #0x6263000                             
02d366e4: ldr     x0, [x0, #0x918]                           T:UnityEngine.Object
02d366e8: bl      #0x2b70db0                                 fn_2b70db0
02d366ec: mov     w8, #1                                     
02d366f0: strb    w8, [x21, #0x11e]                          
02d366f4: ldr     x0, [x20]                                  &2c5bbd4(=a9bd7bfdd503233f)
02d366f8: ldr     x19, [x19, #0x68]                          ._currentItem
02d366fc: ldr     w8, [x0, #0xe4]                            [62630e4]=0 f=0,0
02d36700: cbnz    w8, #0x2d36708                             
02d36704: bl      #0x2b70f30                                 fn_2b70f30
02d36708: mov     x0, x19                                    
02d3670c: ldp     x20, x19, [sp, #0x10]                      
02d36710: mov     x1, xzr                                    
02d36714: mov     x2, xzr                                    
02d36718: ldp     x30, x21, [sp], #0x20                      
02d3671c: b       #0x5b3666c                                 UnityEngine.Object::op_Inequality
## GetTotalItem() -> int
---- BlindBagCollection.BlindbagDragController::GetTotalItem 0x2d36720
02d36720: ldr     w0, [x0, #0x70]                            ._itemLeft
02d36724: ret                                                
## GetRandomPositions(int count) -> UnityEngine.Transform[]
---- BlindBagCollection.BlindbagDragController::GetRandomPositions 0x2d36728
02d36728: stp     x30, x23, [sp, #-0x30]!                    
02d3672c: stp     x22, x21, [sp, #0x10]                      
02d36730: stp     x20, x19, [sp, #0x20]                      
02d36734: adrp    x23, #0x6630000                            
02d36738: adrp    x22, #0x626a000                            
02d3673c: adrp    x21, #0x626a000                            
02d36740: ldrb    w8, [x23, #0x11f]                          
02d36744: ldr     x22, [x22, #0xa78]                         MS:FrameWorkUtility::PickRandom
02d36748: ldr     x21, [x21, #0xa70]                         MS:System.Linq.Enumerable::ToArray
02d3674c: mov     w19, w1                                    
02d36750: mov     x20, x0                                    
02d36754: tbnz    w8, #0, #0x2d36778                         
02d36758: adrp    x0, #0x626a000                             
02d3675c: ldr     x0, [x0, #0xa70]                           MS:System.Linq.Enumerable::ToArray
02d36760: bl      #0x2b70db0                                 fn_2b70db0
02d36764: adrp    x0, #0x626a000                             
02d36768: ldr     x0, [x0, #0xa78]                           MS:FrameWorkUtility::PickRandom
02d3676c: bl      #0x2b70db0                                 fn_2b70db0
02d36770: mov     w8, #1                                     
02d36774: strb    w8, [x23, #0x11f]                          
02d36778: ldr     x0, [x20, #0x50]                           ._randomPositions
02d3677c: ldr     x2, [x22]                                  T:type56879(k15)
02d36780: mov     w1, w19                                    
02d36784: bl      #0x31cfb58                                 fn_31cfb58
02d36788: ldr     x1, [x21]                                  T:type56879(k15)
02d3678c: ldp     x20, x19, [sp, #0x20]                      
02d36790: ldp     x22, x21, [sp, #0x10]                      
02d36794: ldp     x30, x23, [sp], #0x30                      
02d36798: b       #0x319c8a8                                 
## Awake() -> void
---- BlindBagCollection.BlindbagDragController::Awake 0x2d3679c
02d3679c: stp     x30, x23, [sp, #-0x30]!                    
02d367a0: stp     x22, x21, [sp, #0x10]                      
02d367a4: stp     x20, x19, [sp, #0x20]                      
02d367a8: adrp    x20, #0x6630000                            
02d367ac: adrp    x22, #0x626a000                            
02d367b0: adrp    x23, #0x626a000                            
02d367b4: adrp    x21, #0x626a000                            
02d367b8: ldr     x22, [x22, #0xb18]                         T:BlindBagCollection.BlindbagDragController
02d367bc: ldrb    w8, [x20, #0x120]                          
02d367c0: ldr     x23, [x23, #0xb20]                         T:type53138(k15)
02d367c4: ldr     x21, [x21, #0xb28]                         M:BlindBagCollection.BlindbagDragController::OnDragStartHandler
02d367c8: mov     x19, x0                                    
02d367cc: tbnz    w8, #0, #0x2d367fc                         
02d367d0: adrp    x0, #0x626a000                             
02d367d4: ldr     x0, [x0, #0xb20]                           T:type53138(k15)
02d367d8: bl      #0x2b70db0                                 fn_2b70db0
02d367dc: adrp    x0, #0x626a000                             
02d367e0: ldr     x0, [x0, #0xb28]                           M:BlindBagCollection.BlindbagDragController::OnDragStartHandler
02d367e4: bl      #0x2b70db0                                 fn_2b70db0
02d367e8: adrp    x0, #0x626a000                             
02d367ec: ldr     x0, [x0, #0xb18]                           T:BlindBagCollection.BlindbagDragController
02d367f0: bl      #0x2b70db0                                 fn_2b70db0
02d367f4: mov     w8, #1                                     
02d367f8: strb    w8, [x20, #0x120]                          
02d367fc: mov     x0, xzr                                    
02d36800: bl      #0x5aefe28                                 UnityEngine.Camera::get_main
02d36804: mov     x1, x0                                     
02d36808: mov     x0, x19                                    
02d3680c: str     x1, [x0, #0x90]!                           ._mainCamera
02d36810: bl      #0x2b70d54                                 fn_2b70d54
02d36814: ldr     x8, [x22]                                  T:type56879(k15)
02d36818: ldr     x0, [x23]                                  T:type56879(k15)
02d3681c: ldr     x8, [x8, #0xb8]                            
02d36820: ldr     x20, [x8]                                  
02d36824: bl      #0x2b7104c                                 fn_2b7104c
02d36828: ldr     x2, [x21]                                  T:type56879(k15)
02d3682c: mov     x1, x19                                    
02d36830: mov     x3, xzr                                    
02d36834: mov     x21, x0                                    
02d36838: bl      #0x453418c                                 fn_453418c
02d3683c: mov     x0, x20                                    
02d36840: mov     x1, x21                                    
02d36844: mov     x2, xzr                                    
02d36848: bl      #0x4e570ac                                 System.Delegate::Combine
02d3684c: cbz     x0, #0x2d36894                             
02d36850: ldr     x20, [x23]                                 T:type56879(k15)
02d36854: mov     x19, x0                                    
02d36858: mov     x1, x20                                    
02d3685c: bl      #0x2b70f34                                 fn_2b70f34
02d36860: cbz     x0, #0x2d368c0                             
02d36864: ldr     x8, [x22]                                  T:type56879(k15)
02d36868: ldr     x8, [x8, #0xb8]                            
02d3686c: str     x0, [x8]                                   
02d36870: mov     x0, x19                                    
02d36874: ldr     x8, [x22]                                  T:type56879(k15)
02d36878: ldr     x21, [x23]                                 T:type56879(k15)
02d3687c: ldr     x20, [x8, #0xb8]                           
02d36880: mov     x1, x21                                    
02d36884: bl      #0x2b70f34                                 fn_2b70f34
02d36888: cbz     x0, #0x2d368cc                             
02d3688c: mov     x1, x0                                     
02d36890: b       #0x2d368ac                                 
02d36894: ldr     x8, [x22]                                  T:type56879(k15)
02d36898: mov     x1, xzr                                    
02d3689c: ldr     x8, [x8, #0xb8]                            
02d368a0: str     xzr, [x8]                                  
02d368a4: ldr     x8, [x22]                                  T:type56879(k15)
02d368a8: ldr     x20, [x8, #0xb8]                           
02d368ac: mov     x0, x20                                    
02d368b0: ldp     x20, x19, [sp, #0x20]                      
02d368b4: ldp     x22, x21, [sp, #0x10]                      
02d368b8: ldp     x30, x23, [sp], #0x30                      
02d368bc: b       #0x2b70d54                                 
02d368c0: mov     x0, x19                                    
02d368c4: mov     x1, x20                                    
02d368c8: bl      #0x2b713dc                                 fn_2b713dc
02d368cc: mov     x0, x19                                    
02d368d0: mov     x1, x21                                    
02d368d4: bl      #0x2b713dc                                 fn_2b713dc
## OnDestroy() -> void
---- BlindBagCollection.BlindbagDragController::OnDestroy 0x2d368d8
02d368d8: stp     x30, x23, [sp, #-0x30]!                    
02d368dc: stp     x22, x21, [sp, #0x10]                      
02d368e0: stp     x20, x19, [sp, #0x20]                      
02d368e4: adrp    x20, #0x6630000                            
02d368e8: adrp    x22, #0x626a000                            
02d368ec: adrp    x23, #0x626a000                            
02d368f0: adrp    x21, #0x626a000                            
02d368f4: ldr     x22, [x22, #0xb18]                         T:BlindBagCollection.BlindbagDragController
02d368f8: ldrb    w8, [x20, #0x121]                          
02d368fc: ldr     x23, [x23, #0xb20]                         T:type53138(k15)
02d36900: ldr     x21, [x21, #0xb28]                         M:BlindBagCollection.BlindbagDragController::OnDragStartHandler
02d36904: mov     x19, x0                                    
02d36908: tbnz    w8, #0, #0x2d36938                         
02d3690c: adrp    x0, #0x626a000                             
02d36910: ldr     x0, [x0, #0xb20]                           T:type53138(k15)
02d36914: bl      #0x2b70db0                                 fn_2b70db0
02d36918: adrp    x0, #0x626a000                             
02d3691c: ldr     x0, [x0, #0xb28]                           M:BlindBagCollection.BlindbagDragController::OnDragStartHandler
02d36920: bl      #0x2b70db0                                 fn_2b70db0
02d36924: adrp    x0, #0x626a000                             
02d36928: ldr     x0, [x0, #0xb18]                           T:BlindBagCollection.BlindbagDragController
02d3692c: bl      #0x2b70db0                                 fn_2b70db0
02d36930: mov     w8, #1                                     
02d36934: strb    w8, [x20, #0x121]                          
02d36938: ldr     x8, [x22]                                  T:type56879(k15)
02d3693c: ldr     x0, [x23]                                  T:type56879(k15)
02d36940: ldr     x8, [x8, #0xb8]                            
02d36944: ldr     x20, [x8]                                  
02d36948: bl      #0x2b7104c                                 fn_2b7104c
02d3694c: ldr     x2, [x21]                                  T:type56879(k15)
02d36950: mov     x1, x19                                    
02d36954: mov     x3, xzr                                    
02d36958: mov     x21, x0                                    
02d3695c: bl      #0x453418c                                 fn_453418c
02d36960: mov     x0, x20                                    
02d36964: mov     x1, x21                                    
02d36968: mov     x2, xzr                                    
02d3696c: bl      #0x4e57298                                 System.Delegate::Remove
02d36970: cbz     x0, #0x2d369b8                             
02d36974: ldr     x20, [x23]                                 T:type56879(k15)
02d36978: mov     x19, x0                                    
02d3697c: mov     x1, x20                                    
02d36980: bl      #0x2b70f34                                 fn_2b70f34
02d36984: cbz     x0, #0x2d369e4                             
02d36988: ldr     x8, [x22]                                  T:type56879(k15)
02d3698c: ldr     x8, [x8, #0xb8]                            
02d36990: str     x0, [x8]                                   
02d36994: mov     x0, x19                                    
02d36998: ldr     x8, [x22]                                  T:type56879(k15)
02d3699c: ldr     x21, [x23]                                 T:type56879(k15)
02d369a0: ldr     x20, [x8, #0xb8]                           
02d369a4: mov     x1, x21                                    
02d369a8: bl      #0x2b70f34                                 fn_2b70f34
02d369ac: cbz     x0, #0x2d369f0                             
02d369b0: mov     x1, x0                                     
02d369b4: b       #0x2d369d0                                 
02d369b8: ldr     x8, [x22]                                  T:type56879(k15)
02d369bc: mov     x1, xzr                                    
02d369c0: ldr     x8, [x8, #0xb8]                            
02d369c4: str     xzr, [x8]                                  
02d369c8: ldr     x8, [x22]                                  T:type56879(k15)
02d369cc: ldr     x20, [x8, #0xb8]                           
02d369d0: mov     x0, x20                                    
02d369d4: ldp     x20, x19, [sp, #0x20]                      
02d369d8: ldp     x22, x21, [sp, #0x10]                      
02d369dc: ldp     x30, x23, [sp], #0x30                      
02d369e0: b       #0x2b70d54                                 
02d369e4: mov     x0, x19                                    
02d369e8: mov     x1, x20                                    
02d369ec: bl      #0x2b713dc                                 fn_2b713dc
02d369f0: mov     x0, x19                                    
02d369f4: mov     x1, x21                                    
02d369f8: bl      #0x2b713dc                                 fn_2b713dc
## Start() -> void
---- BlindBagCollection.BlindbagDragController::Start 0x2d369fc
02d369fc: stp     x30, x21, [sp, #-0x20]!                    
02d36a00: stp     x20, x19, [sp, #0x10]                      
02d36a04: adrp    x20, #0x6630000                            
02d36a08: adrp    x21, #0x6266000                            
02d36a0c: mov     x19, x0                                    
02d36a10: ldrb    w8, [x20, #0x122]                          
02d36a14: ldr     x21, [x21, #0x658]                         MS:MonoSingleton`1::get_Instance
02d36a18: tbnz    w8, #0, #0x2d36a3c                         
02d36a1c: adrp    x0, #0x626a000                             
02d36a20: ldr     x0, [x0, #0x800]                           MS:DataManager::GetData
02d36a24: bl      #0x2b70db0                                 fn_2b70db0
02d36a28: adrp    x0, #0x6266000                             
02d36a2c: ldr     x0, [x0, #0x658]                           MS:MonoSingleton`1::get_Instance
02d36a30: bl      #0x2b70db0                                 fn_2b70db0
02d36a34: mov     w8, #1                                     
02d36a38: strb    w8, [x20, #0x122]                          
02d36a3c: ldr     x0, [x21]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d36a40: bl      #0x3769600                                 fn_3769600
02d36a44: cbz     x0, #0x2d36a70                             
02d36a48: adrp    x8, #0x626a000                             
02d36a4c: ldr     x8, [x8, #0x800]                           MS:DataManager::GetData
02d36a50: ldr     x1, [x8]                                   T:type56879(k15)
02d36a54: bl      #0x3168dd0                                 fn_3168dd0
02d36a58: str     x0, [x19, #0x98]!                          ._collectionDataUser
02d36a5c: mov     x1, x0                                     
02d36a60: mov     x0, x19                                    
02d36a64: ldp     x20, x19, [sp, #0x10]                      
02d36a68: ldp     x30, x21, [sp], #0x20                      
02d36a6c: b       #0x2b70d54                                 
02d36a70: bl      #0x2b7105c                                 fn_2b7105c
## InitalizeBlindbag(System.Collections.Generic.List`1<System.ValueTuple`3<BlindBagCollection.CollectionItemType,BlindBagCollection.CollectionBoxsetType,UnityEngine.Sprite>> all) -> void
---- BlindBagCollection.BlindbagDragController::InitalizeBlindbag 0x2d35c9c
02d35c9c: sub     sp, sp, #0xb0                              
02d35ca0: stp     d15, d14, [sp, #0x10]                      
02d35ca4: stp     d13, d12, [sp, #0x20]                      
02d35ca8: stp     d11, d10, [sp, #0x30]                      
02d35cac: stp     d9, d8, [sp, #0x40]                        
02d35cb0: stp     x29, x30, [sp, #0x50]                      
02d35cb4: stp     x28, x27, [sp, #0x60]                      
02d35cb8: stp     x26, x25, [sp, #0x70]                      
02d35cbc: stp     x24, x23, [sp, #0x80]                      
02d35cc0: stp     x22, x21, [sp, #0x90]                      
02d35cc4: stp     x20, x19, [sp, #0xa0]                      
02d35cc8: adrp    x21, #0x6630000                            
02d35ccc: mov     x19, x1                                    
02d35cd0: mov     x20, x0                                    
02d35cd4: ldrb    w8, [x21, #0x123]                          
02d35cd8: tbnz    w8, #0, #0x2d35d38                         
02d35cdc: adrp    x0, #0x626a000                             
02d35ce0: ldr     x0, [x0, #0xa70]                           MS:System.Linq.Enumerable::ToArray
02d35ce4: bl      #0x2b70db0                                 fn_2b70db0
02d35ce8: adrp    x0, #0x626a000                             
02d35cec: ldr     x0, [x0, #0xa78]                           MS:FrameWorkUtility::PickRandom
02d35cf0: bl      #0x2b70db0                                 fn_2b70db0
02d35cf4: adrp    x0, #0x626a000                             
02d35cf8: ldr     x0, [x0, #0xa80]                           MS:System.Collections.Generic.List`1::Add
02d35cfc: bl      #0x2b70db0                                 fn_2b70db0
02d35d00: adrp    x0, #0x626a000                             
02d35d04: ldr     x0, [x0, #0xa88]                           MS:System.Collections.Generic.List`1::get_Count
02d35d08: bl      #0x2b70db0                                 fn_2b70db0
02d35d0c: adrp    x0, #0x626a000                             
02d35d10: ldr     x0, [x0, #0xa90]                           MS:System.Collections.Generic.List`1::get_Item
02d35d14: bl      #0x2b70db0                                 fn_2b70db0
02d35d18: adrp    x0, #0x626a000                             
02d35d1c: ldr     x0, [x0, #0xa98]                           MS:UnityEngine.Object::Instantiate
02d35d20: bl      #0x2b70db0                                 fn_2b70db0
02d35d24: adrp    x0, #0x6263000                             
02d35d28: ldr     x0, [x0, #0x918]                           T:UnityEngine.Object
02d35d2c: bl      #0x2b70db0                                 fn_2b70db0
02d35d30: mov     w8, #1                                     
02d35d34: strb    w8, [x21, #0x123]                          
02d35d38: cbz     x19, #0x2d35f98                            
02d35d3c: ldr     w8, [x19, #0x18]                           
02d35d40: cbz     w8, #0x2d35f98                             
02d35d44: adrp    x27, #0x6263000                            
02d35d48: ldr     x27, [x27, #0x918]                         T:UnityEngine.Object
02d35d4c: ldr     x21, [x20, #0x98]                          ._collectionDataUser
02d35d50: ldr     x0, [x27]                                  &2c5bbd4(=a9bd7bfdd503233f)
02d35d54: ldr     w8, [x0, #0xe4]                            [62630e4]=0 f=0,0
02d35d58: cbnz    w8, #0x2d35d60                             
02d35d5c: bl      #0x2b70f30                                 fn_2b70f30
02d35d60: mov     x0, x21                                    
02d35d64: mov     x1, xzr                                    
02d35d68: mov     x2, xzr                                    
02d35d6c: bl      #0x5b37d84                                 UnityEngine.Object::op_Equality
02d35d70: tbnz    w0, #0, #0x2d35f98                         
02d35d74: adrp    x8, #0x626a000                             
02d35d78: ldr     x8, [x8, #0xa78]                           MS:FrameWorkUtility::PickRandom
02d35d7c: ldr     w21, [x19, #0x18]                          
02d35d80: ldr     x0, [x20, #0x50]                           ._randomPositions
02d35d84: ldr     x2, [x8]                                   T:type56879(k15)
02d35d88: mov     w1, w21                                    
02d35d8c: bl      #0x31cfb58                                 fn_31cfb58
02d35d90: adrp    x8, #0x626a000                             
02d35d94: ldr     x8, [x8, #0xa70]                           MS:System.Linq.Enumerable::ToArray
02d35d98: ldr     x1, [x8]                                   T:type56879(k15)
02d35d9c: bl      #0x319c8a8                                 fn_319c8a8
02d35da0: cmp     w21, #1                                    
02d35da4: b.lt    #0x2d35f98                                 
02d35da8: adrp    x28, #0x626a000                            
02d35dac: adrp    x8, #0x1085000                             
02d35db0: mov     x22, x0                                    
02d35db4: ldr     x28, [x28, #0xa90]                         MS:System.Collections.Generic.List`1::get_Item
02d35db8: ldr     s15, [x8, #0x10]                           [1085010]=4202c6f23c8efa35 f=0.0174533,32.6943
02d35dbc: mov     x23, xzr                                   
02d35dc0: add     x29, x0, #0x20                             &6263020
02d35dc4: ldr     x2, [x28]                                  T:type56879(k15)
02d35dc8: ldr     x24, [x20, #0x98]                          ._collectionDataUser
02d35dcc: mov     x0, x19                                    
02d35dd0: mov     w1, w23                                    
02d35dd4: bl      #0x4b9aefc                                 fn_4b9aefc
02d35dd8: ldr     x2, [x28]                                  T:type56879(k15)
02d35ddc: mov     x25, x0                                    
02d35de0: mov     x0, x19                                    
02d35de4: mov     w1, w23                                    
02d35de8: bl      #0x4b9aefc                                 fn_4b9aefc
02d35dec: cbz     x24, #0x2d35fc8                            
02d35df0: mov     x2, x0                                     
02d35df4: lsr     x1, x25, #0x20                             
02d35df8: mov     x0, x24                                    
02d35dfc: bl      #0x2d3521c                                 BlindBagCollection.BlindbagCollectionData::IsUnlocked
02d35e00: tbnz    w0, #0, #0x2d35f8c                         
02d35e04: cbz     x22, #0x2d35fc8                            
02d35e08: ldr     w8, [x22, #0x18]                           
02d35e0c: cmp     x23, x8                                    
02d35e10: b.hs    #0x2d35fcc                                 
02d35e14: ldr     x0, [x29, x23, lsl #3]                     
02d35e18: cbz     x0, #0x2d35fc8                             
02d35e1c: ldr     x24, [x20, #0x20]                          ._itemPrefab
02d35e20: mov     x1, xzr                                    
02d35e24: bl      #0x5b467ac                                 UnityEngine.Transform::get_position
02d35e28: mov     w0, #-0x2d                                 
02d35e2c: mov     w1, #0x2d                                  
02d35e30: mov     x2, xzr                                    
02d35e34: fmov    s8, s0                                     
02d35e38: fmov    s9, s1                                     
02d35e3c: fmov    s10, s2                                    
02d35e40: bl      #0x5b2e000                                 UnityEngine.Random::Range
02d35e44: scvtf   s0, w0                                     
02d35e48: mov     x0, sp                                     
02d35e4c: mov     x1, xzr                                    
02d35e50: str     xzr, [sp]                                  
02d35e54: fmul    s0, s0, s15                                
02d35e58: str     s0, [sp, #8]                               
02d35e5c: bl      #0x5b2607c                                 UnityEngine.Quaternion::Internal_FromEulerRad
02d35e60: fmov    s11, s0                                    
02d35e64: fmov    s12, s1                                    
02d35e68: ldr     x0, [x27]                                  &2c5bbd4(=a9bd7bfdd503233f)
02d35e6c: fmov    s13, s2                                    
02d35e70: fmov    s14, s3                                    
02d35e74: ldr     x25, [x20, #0x28]                          ._holder
02d35e78: ldr     w8, [x0, #0xe4]                            [62630e4]=0 f=0,0
02d35e7c: cbnz    w8, #0x2d35e84                             
02d35e80: bl      #0x2b70f30                                 fn_2b70f30
02d35e84: adrp    x8, #0x626a000                             
02d35e88: fmov    s0, s8                                     
02d35e8c: fmov    s1, s9                                     
02d35e90: ldr     x8, [x8, #0xa98]                           MS:UnityEngine.Object::Instantiate
02d35e94: fmov    s2, s10                                    
02d35e98: fmov    s3, s11                                    
02d35e9c: fmov    s4, s12                                    
02d35ea0: fmov    s5, s13                                    
02d35ea4: mov     x0, x24                                    
02d35ea8: fmov    s6, s14                                    
02d35eac: ldr     x2, [x8]                                   T:type56879(k15)
02d35eb0: mov     x1, x25                                    
02d35eb4: bl      #0x3276204                                 fn_3276204
02d35eb8: ldr     x2, [x28]                                  T:type56879(k15)
02d35ebc: mov     x24, x0                                    
02d35ec0: mov     x0, x19                                    
02d35ec4: mov     w1, w23                                    
02d35ec8: bl      #0x4b9aefc                                 fn_4b9aefc
02d35ecc: ldr     x2, [x28]                                  T:type56879(k15)
02d35ed0: mov     x25, x0                                    
02d35ed4: mov     x0, x19                                    
02d35ed8: mov     w1, w23                                    
02d35edc: bl      #0x4b9aefc                                 fn_4b9aefc
02d35ee0: ldr     x2, [x28]                                  T:type56879(k15)
02d35ee4: mov     x26, x0                                    
02d35ee8: mov     x0, x19                                    
02d35eec: mov     w1, w23                                    
02d35ef0: bl      #0x4b9aefc                                 fn_4b9aefc
02d35ef4: cbz     x24, #0x2d35fc8                            
02d35ef8: mov     x3, x1                                     
02d35efc: lsr     x2, x26, #0x20                             
02d35f00: mov     x0, x24                                    
02d35f04: mov     w1, w25                                    
02d35f08: bl      #0x2d36a74                                 BlindBagCollection.ItemDraggable::SetData
02d35f0c: ldr     x25, [x20, #0xa0]                          ._spawnedItems
02d35f10: mov     x0, x24                                    
02d35f14: mov     x1, xzr                                    
02d35f18: bl      #0x5b339ec                                 UnityEngine.Component::get_gameObject
02d35f1c: cbz     x25, #0x2d35fc8                            
02d35f20: adrp    x9, #0x626a000                             
02d35f24: ldr     w10, [x25, #0x1c]                          
02d35f28: ldr     x8, [x25, #0x10]                           
02d35f2c: ldr     x9, [x9, #0xa80]                           MS:System.Collections.Generic.List`1::Add
02d35f30: add     w10, w10, #1                               
02d35f34: ldr     x9, [x9]                                   T:type56879(k15)
02d35f38: str     w10, [x25, #0x1c]                          
02d35f3c: cbz     x8, #0x2d35fc8                             
02d35f40: ldrsw   x10, [x25, #0x18]                          
02d35f44: ldr     w11, [x8, #0x18]                           MS:System.Collections.Generic.List`1::Add
02d35f48: mov     x1, x0                                     
02d35f4c: cmp     w10, w11                                   
02d35f50: b.hs    #0x2d35f6c                                 
02d35f54: add     x0, x8, x10, lsl #3                        &626a000
02d35f58: add     w9, w10, #1                                
02d35f5c: str     w9, [x25, #0x18]                           
02d35f60: str     x1, [x0, #0x20]!                           ._itemPrefab
02d35f64: bl      #0x2b70d54                                 fn_2b70d54
02d35f68: b       #0x2d35f80                                 
02d35f6c: ldr     x8, [x9, #0x20]                            M:Decor.DataDecor/<>c__DisplayClass8_0::<NewData>b__0
02d35f70: mov     x0, x25                                    
02d35f74: ldr     x8, [x8, #0xc0]                            S:'Main character is null'
02d35f78: ldr     x2, [x8, #0x70]                            MS:System.Collections.Generic.List`1::FindIndex
02d35f7c: bl      #0x35a920c                                 fn_35a920c
02d35f80: ldr     w8, [x20, #0x70]                           ._itemLeft
02d35f84: add     w8, w8, #1                                 
02d35f88: str     w8, [x20, #0x70]                           ._itemLeft
02d35f8c: add     x23, x23, #1                               
02d35f90: cmp     x21, x23                                   
02d35f94: b.ne    #0x2d35dc4                                 
02d35f98: ldp     x20, x19, [sp, #0xa0]                      
02d35f9c: ldp     x22, x21, [sp, #0x90]                      
02d35fa0: ldp     x24, x23, [sp, #0x80]                      
02d35fa4: ldp     x26, x25, [sp, #0x70]                      
02d35fa8: ldp     x28, x27, [sp, #0x60]                      
02d35fac: ldp     x29, x30, [sp, #0x50]                      
02d35fb0: ldp     d9, d8, [sp, #0x40]                        
02d35fb4: ldp     d11, d10, [sp, #0x30]                      
02d35fb8: ldp     d13, d12, [sp, #0x20]                      
02d35fbc: ldp     d15, d14, [sp, #0x10]                      
02d35fc0: add     sp, sp, #0xb0                              
02d35fc4: ret                                                
02d35fc8: bl      #0x2b7105c                                 fn_2b7105c
02d35fcc: bl      #0x2b71064                                 fn_2b71064
## Update() -> void
---- BlindBagCollection.BlindbagDragController::Update 0x2d36c18
02d36c18: str     d10, [sp, #-0x40]!                         
02d36c1c: stp     d9, d8, [sp, #8]                           
02d36c20: str     x30, [sp, #0x18]                           
02d36c24: stp     x22, x21, [sp, #0x20]                      
02d36c28: stp     x20, x19, [sp, #0x30]                      
02d36c2c: adrp    x20, #0x6630000                            
02d36c30: adrp    x21, #0x6263000                            
02d36c34: mov     x19, x0                                    
02d36c38: ldrb    w8, [x20, #0x124]                          
02d36c3c: ldr     x21, [x21, #0x918]                         T:UnityEngine.Object
02d36c40: tbnz    w8, #0, #0x2d36c64                         
02d36c44: adrp    x0, #0x6266000                             
02d36c48: ldr     x0, [x0, #0x938]                           MS:UnityEngine.InputSystem.InputControl`1::ReadValue
02d36c4c: bl      #0x2b70db0                                 fn_2b70db0
02d36c50: adrp    x0, #0x6263000                             
02d36c54: ldr     x0, [x0, #0x918]                           T:UnityEngine.Object
02d36c58: bl      #0x2b70db0                                 fn_2b70db0
02d36c5c: mov     w8, #1                                     
02d36c60: strb    w8, [x20, #0x124]                          
02d36c64: ldr     x0, [x21]                                  &2c5bbd4(=a9bd7bfdd503233f)
02d36c68: ldr     x20, [x19, #0x68]                          ._currentItem
02d36c6c: ldr     w8, [x0, #0xe4]                            [62630e4]=0 f=0,0
02d36c70: cbnz    w8, #0x2d36c78                             
02d36c74: bl      #0x2b70f30                                 fn_2b70f30
02d36c78: mov     x0, x20                                    
02d36c7c: mov     x1, xzr                                    
02d36c80: bl      #0x5b3bb1c                                 UnityEngine.Object::op_Implicit
02d36c84: tbz     w0, #0, #0x2d36d9c                         
02d36c88: adrp    x20, #0x662f000                            
02d36c8c: ldrb    w8, [x20, #0xbd9]                          
02d36c90: cbnz    w8, #0x2d36ca8                             
02d36c94: adrp    x0, #0x6266000                             
02d36c98: ldr     x0, [x0, #0x950]                           T:UnityEngine.InputSystem.Pointer
02d36c9c: bl      #0x2b70db0                                 fn_2b70db0
02d36ca0: mov     w8, #1                                     
02d36ca4: strb    w8, [x20, #0xbd9]                          
02d36ca8: adrp    x8, #0x6266000                             
02d36cac: ldr     x8, [x8, #0x950]                           T:UnityEngine.InputSystem.Pointer
02d36cb0: ldr     x8, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d36cb4: ldr     x8, [x8, #0xb8]                            S:'banner_native_refresh_time'
02d36cb8: ldr     x22, [x8]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d36cbc: cbz     x22, #0x2d36d9c                            
02d36cc0: ldr     x0, [x22, #0x188]                          
02d36cc4: cbz     x0, #0x2d36db4                             
02d36cc8: adrp    x8, #0x6266000                             
02d36ccc: ldr     x8, [x8, #0x938]                           MS:UnityEngine.InputSystem.InputControl`1::ReadValue
02d36cd0: ldr     x20, [x19, #0x90]                          ._mainCamera
02d36cd4: ldr     x1, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d36cd8: bl      #0x4a187c4                                 fn_4a187c4
02d36cdc: cbz     x20, #0x2d36db4                            
02d36ce0: movi    d2, #0000000000000000                      
02d36ce4: mov     x0, x20                                    
02d36ce8: mov     x1, xzr                                    
02d36cec: bl      #0x5aefbb0                                 UnityEngine.Camera::ScreenToWorldPoint
02d36cf0: ldr     x0, [x19, #0x68]                           ._currentItem
02d36cf4: cbz     x0, #0x2d36db4                             
02d36cf8: mov     x1, xzr                                    
02d36cfc: fmov    s8, s0                                     
02d36d00: fmov    s9, s1                                     
02d36d04: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02d36d08: cbz     x0, #0x2d36db4                             
02d36d0c: mov     x1, xzr                                    
02d36d10: bl      #0x5b467ac                                 UnityEngine.Transform::get_position
02d36d14: ldr     x0, [x19, #0x68]                           ._currentItem
02d36d18: cbz     x0, #0x2d36db4                             
02d36d1c: mov     x1, xzr                                    
02d36d20: fmov    s10, s2                                    
02d36d24: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02d36d28: cbz     x0, #0x2d36db4                             
02d36d2c: ldp     s1, s0, [x19, #0x78]                       
02d36d30: mov     x1, xzr                                    
02d36d34: ldr     s3, [x19, #0x74]                           ._dragOffset
02d36d38: fadd    s2, s10, s0                                
02d36d3c: fadd    s1, s9, s1                                 
02d36d40: fadd    s0, s8, s3                                 
02d36d44: bl      #0x5b46888                                 UnityEngine.Transform::set_position
02d36d48: ldr     x0, [x21]                                  &2c5bbd4(=a9bd7bfdd503233f)
02d36d4c: ldr     x20, [x19, #0x68]                          ._currentItem
02d36d50: ldr     w8, [x0, #0xe4]                            [62660e4]=0 f=0,0
02d36d54: cbnz    w8, #0x2d36d5c                             
02d36d58: bl      #0x2b70f30                                 fn_2b70f30
02d36d5c: mov     x0, x20                                    
02d36d60: mov     x1, xzr                                    
02d36d64: bl      #0x5b3bb1c                                 UnityEngine.Object::op_Implicit
02d36d68: tbz     w0, #0, #0x2d36d9c                         
02d36d6c: ldr     x0, [x22, #0x1a8]                          
02d36d70: cbz     x0, #0x2d36db4                             
02d36d74: mov     x1, xzr                                    
02d36d78: bl      #0x5553460                                 UnityEngine.InputSystem.Controls.ButtonControl::get_wasReleasedThisFrame
02d36d7c: tbz     w0, #0, #0x2d36d9c                         
02d36d80: mov     x0, x19                                    
02d36d84: ldp     x20, x19, [sp, #0x30]                      
02d36d88: ldp     x22, x21, [sp, #0x20]                      
02d36d8c: ldr     x30, [sp, #0x18]                           
02d36d90: ldp     d9, d8, [sp, #8]                           
02d36d94: ldr     d10, [sp], #0x40                           
02d36d98: b       #0x2d36db8                                 BlindBagCollection.BlindbagDragController::OnDragEnded
02d36d9c: ldp     x20, x19, [sp, #0x30]                      
02d36da0: ldr     x30, [sp, #0x18]                           
02d36da4: ldp     x22, x21, [sp, #0x20]                      
02d36da8: ldp     d9, d8, [sp, #8]                           
02d36dac: ldr     d10, [sp], #0x40                           
02d36db0: ret                                                
02d36db4: bl      #0x2b7105c                                 fn_2b7105c
## OnDragEnded() -> void
---- BlindBagCollection.BlindbagDragController::OnDragEnded 0x2d36db8
02d36db8: stp     d11, d10, [sp, #-0x40]!                    
02d36dbc: stp     d9, d8, [sp, #0x10]                        
02d36dc0: stp     x30, x21, [sp, #0x20]                      
02d36dc4: stp     x20, x19, [sp, #0x30]                      
02d36dc8: adrp    x21, #0x6630000                            
02d36dcc: adrp    x20, #0x6263000                            
02d36dd0: mov     x19, x0                                    
02d36dd4: ldrb    w8, [x21, #0x125]                          
02d36dd8: ldr     x20, [x20, #0x918]                         T:UnityEngine.Object
02d36ddc: tbnz    w8, #0, #0x2d36e18                         
02d36de0: adrp    x0, #0x626a000                             
02d36de4: ldr     x0, [x0, #0xb18]                           T:BlindBagCollection.BlindbagDragController
02d36de8: bl      #0x2b70db0                                 fn_2b70db0
02d36dec: adrp    x0, #0x6263000                             
02d36df0: ldr     x0, [x0, #0x918]                           T:UnityEngine.Object
02d36df4: bl      #0x2b70db0                                 fn_2b70db0
02d36df8: adrp    x0, #0x6267000                             
02d36dfc: ldr     x0, [x0, #0xea8]                           T:Framework.Vibration
02d36e00: bl      #0x2b70db0                                 fn_2b70db0
02d36e04: adrp    x0, #0x626a000                             
02d36e08: ldr     x0, [x0, #0xb30]                           S:'Complete'
02d36e0c: bl      #0x2b70db0                                 fn_2b70db0
02d36e10: mov     w8, #1                                     
02d36e14: strb    w8, [x21, #0x125]                          
02d36e18: ldr     x0, [x20]                                  &2c5bbd4(=a9bd7bfdd503233f)
02d36e1c: mov     x20, x19                                   
02d36e20: ldr     x21, [x20, #0x68]!                         &2c497cc(=d65f03c0d503245f) ._currentItem
02d36e24: ldr     w8, [x0, #0xe4]                            [626a0e4]=0 f=0,0
02d36e28: cbnz    w8, #0x2d36e30                             
02d36e2c: bl      #0x2b70f30                                 fn_2b70f30
02d36e30: mov     x0, x21                                    
02d36e34: mov     x1, xzr                                    
02d36e38: bl      #0x5b3bb1c                                 UnityEngine.Object::op_Implicit
02d36e3c: tbz     w0, #0, #0x2d36fb8                         
02d36e40: ldr     x0, [x20]                                  &2c5bbd4(=a9bd7bfdd503233f)
02d36e44: cbz     x0, #0x2d37040                             
02d36e48: mov     x1, xzr                                    
02d36e4c: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02d36e50: cbz     x0, #0x2d37040                             
02d36e54: mov     x1, xzr                                    
02d36e58: bl      #0x5b467ac                                 UnityEngine.Transform::get_position
02d36e5c: ldr     x8, [x19, #0x38]                           ._collectionSelector
02d36e60: cbz     x8, #0x2d37040                             
02d36e64: ldr     x0, [x8, #0x58]                            
02d36e68: cbz     x0, #0x2d37040                             
02d36e6c: fmov    s8, s0                                     
02d36e70: fmov    s9, s1                                     
02d36e74: bl      #0x2d39230                                 BlindBagCollection.CollectionBox::GetCurrentItemPosition
02d36e78: fmov    s10, s0                                    
02d36e7c: fmov    s11, s1                                    
02d36e80: adrp    x21, #0x6630000                            
02d36e84: ldrb    w8, [x21, #0x1d4]                          
02d36e88: cbnz    w8, #0x2d36ea0                             
02d36e8c: adrp    x0, #0x6265000                             
02d36e90: ldr     x0, [x0, #0xb48]                           T:System.Math
02d36e94: bl      #0x2b70db0                                 fn_2b70db0
02d36e98: mov     w8, #1                                     
02d36e9c: strb    w8, [x21, #0x1d4]                          
02d36ea0: adrp    x8, #0x6265000                             
02d36ea4: ldr     x8, [x8, #0xb48]                           T:System.Math
02d36ea8: ldr     x0, [x8]                                   M:AdsManager::<OnApplicationPause>b__26_0
02d36eac: ldr     w8, [x0, #0xe4]                            [62650e4]=0 f=0,0
02d36eb0: cbnz    w8, #0x2d36eb8                             
02d36eb4: bl      #0x2b70f30                                 fn_2b70f30
02d36eb8: fsub    s0, s9, s11                                
02d36ebc: fsub    s1, s8, s10                                
02d36ec0: adrp    x8, #0x1084000                             
02d36ec4: fmul    s1, s1, s1                                 
02d36ec8: fmul    s0, s0, s0                                 
02d36ecc: fadd    s0, s1, s0                                 
02d36ed0: ldr     s1, [x8, #0xdf0]                           [1084df0]=3fc90fdb3fe66666 f=1.8,1.5708
02d36ed4: fsqrt   s0, s0                                     
02d36ed8: fcmp    s0, s1                                     
02d36edc: b.pl    #0x2d36fcc                                 
02d36ee0: adrp    x8, #0x6267000                             
02d36ee4: ldr     x8, [x8, #0xea8]                           T:Framework.Vibration
02d36ee8: ldr     x0, [x8]                                   S:'didu'
02d36eec: ldr     w8, [x0, #0xe4]                            [62650e4]=0 f=0,0
02d36ef0: cbnz    w8, #0x2d36ef8                             
02d36ef4: bl      #0x2b70f30                                 fn_2b70f30
02d36ef8: mov     w0, #0x3c                                  
02d36efc: mov     w1, #-1                                    
02d36f00: mov     w2, wzr                                    
02d36f04: mov     x3, xzr                                    
02d36f08: bl      #0x2d6e144                                 Framework.Vibration::Vibrate
02d36f0c: adrp    x21, #0x662f000                            
02d36f10: ldrb    w8, [x21, #0xbda]                          
02d36f14: cbnz    w8, #0x2d36f2c                             
02d36f18: adrp    x0, #0x6266000                             
02d36f1c: ldr     x0, [x0, #0x970]                           T:UnityEngine.Vector2
02d36f20: bl      #0x2b70db0                                 fn_2b70db0
02d36f24: mov     w8, #1                                     
02d36f28: strb    w8, [x21, #0xbda]                          
02d36f2c: adrp    x8, #0x6266000                             
02d36f30: mov     x0, x19                                    
02d36f34: ldr     x8, [x8, #0x970]                           T:UnityEngine.Vector2
02d36f38: ldr     x8, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d36f3c: ldr     x8, [x8, #0xb8]                            S:'banner_native_refresh_time'
02d36f40: ldp     s0, s1, [x8]                               
02d36f44: bl      #0x2d37058                                 BlindBagCollection.BlindbagDragController::SpawnCompliment
02d36f48: mov     x0, x19                                    
02d36f4c: bl      #0x2d371c4                                 BlindBagCollection.BlindbagDragController::UnlockCurrentItemInCollection
02d36f50: ldr     x8, [x19, #0x68]                           ._currentItem
02d36f54: cbz     x8, #0x2d37040                             
02d36f58: mov     w21, w0                                    
02d36f5c: mov     x0, x8                                     
02d36f60: mov     x1, xzr                                    
02d36f64: bl      #0x5b339ec                                 UnityEngine.Component::get_gameObject
02d36f68: cbz     x0, #0x2d37040                             
02d36f6c: mov     w1, wzr                                    
02d36f70: mov     x2, xzr                                    
02d36f74: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d36f78: ldr     w8, [x19, #0x70]                           ._itemLeft
02d36f7c: sub     w8, w8, #1                                 
02d36f80: cmp     w8, #0                                     
02d36f84: str     w8, [x19, #0x70]                           ._itemLeft
02d36f88: b.gt    #0x2d36ff4                                 
02d36f8c: fmov    s0, #2.00000000                            
02d36f90: fmov    s1, #6.00000000                            
02d36f94: tst     w21, #1                                    
02d36f98: adrp    x8, #0x626a000                             
02d36f9c: mov     x0, x19                                    
02d36fa0: mov     x2, xzr                                    
02d36fa4: ldr     x8, [x8, #0xb30]                           S:'Complete'
02d36fa8: fcsel   s0, s1, s0, ne                             
02d36fac: ldr     x1, [x8]                                   T:type56879(k15)
02d36fb0: bl      #0x5b38044                                 UnityEngine.MonoBehaviour::Invoke
02d36fb4: b       #0x2d36ff4                                 
02d36fb8: ldp     x20, x19, [sp, #0x30]                      
02d36fbc: ldp     x30, x21, [sp, #0x20]                      
02d36fc0: ldp     d9, d8, [sp, #0x10]                        
02d36fc4: ldp     d11, d10, [sp], #0x40                      
02d36fc8: ret                                                
02d36fcc: adrp    x8, #0x626a000                             
02d36fd0: ldr     x8, [x8, #0xb18]                           T:BlindBagCollection.BlindbagDragController
02d36fd4: ldr     x8, [x8]                                   T:type56879(k15)
02d36fd8: ldr     x8, [x8, #0xb8]                            MS:UnityEngine.Object::FindObjectsOfType
02d36fdc: ldr     x8, [x8, #8]                               MS:System.Collections.Generic.List`1::.ctor
02d36fe0: cbz     x8, #0x2d36ff4                             
02d36fe4: ldr     x9, [x8, #0x18]                            MS:System.Collections.Generic.List`1::Add
02d36fe8: ldr     x0, [x8, #0x40]                            MS:System.Collections.Generic.List`1::IndexOf
02d36fec: ldr     x1, [x8, #0x28]                            T:Decor.DataDecor/<>c__DisplayClass8_0
02d36ff0: blr     x9                                         
02d36ff4: ldr     x0, [x20]                                  &2c5bbd4(=a9bd7bfdd503233f)
02d36ff8: cbz     x0, #0x2d37040                             
02d36ffc: bl      #0x2d372e0                                 BlindBagCollection.ItemDraggable::OnDragEnded
02d37000: ldr     x0, [x20]                                  &2c5bbd4(=a9bd7bfdd503233f)
02d37004: cbz     x0, #0x2d37040                             
02d37008: mov     x1, xzr                                    
02d3700c: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02d37010: cbz     x0, #0x2d37040                             
02d37014: ldr     x1, [x19, #0x28]                           ._holder
02d37018: mov     x2, xzr                                    
02d3701c: bl      #0x5b472ec                                 UnityEngine.Transform::SetParent
02d37020: mov     x0, x20                                    
02d37024: str     xzr, [x19, #0x68]                          ._currentItem
02d37028: mov     x1, xzr                                    
02d3702c: ldp     x20, x19, [sp, #0x30]                      
02d37030: ldp     x30, x21, [sp, #0x20]                      
02d37034: ldp     d9, d8, [sp, #0x10]                        
02d37038: ldp     d11, d10, [sp], #0x40                      
02d3703c: b       #0x2b70d54                                 
02d37040: bl      #0x2b7105c                                 fn_2b7105c
## UnlockCurrentItemInCollection() -> bool
---- BlindBagCollection.BlindbagDragController::UnlockCurrentItemInCollection 0x2d371c4
02d371c4: stp     x30, x21, [sp, #-0x20]!                    
02d371c8: stp     x20, x19, [sp, #0x10]                      
02d371cc: adrp    x20, #0x6630000                            
02d371d0: mov     x19, x0                                    
02d371d4: ldrb    w8, [x20, #0x126]                          
02d371d8: tbnz    w8, #0, #0x2d371fc                         
02d371dc: adrp    x0, #0x626a000                             
02d371e0: ldr     x0, [x0, #0xb48]                           M:BlindBagCollection.BlindbagDragController::<UnlockCurrentItemInCollection>b__27_0
02d371e4: bl      #0x2b70db0                                 fn_2b70db0
02d371e8: adrp    x0, #0x6264000                             
02d371ec: ldr     x0, [x0, #0xe8]                            T:DG.Tweening.TweenCallback
02d371f0: bl      #0x2b70db0                                 fn_2b70db0
02d371f4: mov     w8, #1                                     
02d371f8: strb    w8, [x20, #0x126]                          
02d371fc: mov     x0, xzr                                    
02d37200: bl      #0x2d6eec8                                 Framework.AudioManager::get_Instance
02d37204: cbz     x0, #0x2d372dc                             
02d37208: movi    d1, #0000000000000000                      
02d3720c: movi    d2, #0000000000000000                      
02d37210: mov     w1, #0x10                                  
02d37214: fmov    s0, #1.00000000                            
02d37218: mov     w2, wzr                                    
02d3721c: mov     w3, wzr                                    
02d37220: mov     x4, xzr                                    
02d37224: bl      #0x2d6f03c                                 Framework.AudioManager::PlaySound
02d37228: ldr     x8, [x19, #0x68]                           ._currentItem
02d3722c: cbz     x8, #0x2d372dc                             
02d37230: ldr     x0, [x19, #0x98]                           ._collectionDataUser
02d37234: cbz     x0, #0x2d372dc                             
02d37238: ldp     w2, w1, [x8, #0x20]                        
02d3723c: bl      #0x2d3622c                                 BlindBagCollection.BlindbagCollectionData::Unlock
02d37240: ldr     x0, [x19, #0x98]                           ._collectionDataUser
02d37244: cbz     x0, #0x2d372dc                             
02d37248: ldr     x8, [x0]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d3724c: ldr     x9, [x8, #0x258]                           
02d37250: ldr     x1, [x8, #0x260]                           
02d37254: blr     x9                                         
02d37258: ldr     x8, [x19, #0x38]                           ._collectionSelector
02d3725c: cbz     x8, #0x2d372dc                             
02d37260: ldr     x0, [x8, #0x58]                            
02d37264: cbz     x0, #0x2d3726c                             
02d37268: bl      #0x2d39538                                 BlindBagCollection.CollectionBox::UnlockCurrentBox
02d3726c: ldr     x8, [x19, #0x68]                           ._currentItem
02d37270: cbz     x8, #0x2d372dc                             
02d37274: ldr     x0, [x19, #0x98]                           ._collectionDataUser
02d37278: cbz     x0, #0x2d372dc                             
02d3727c: ldr     w1, [x8, #0x24]                            
02d37280: bl      #0x2d364d4                                 BlindBagCollection.BlindbagCollectionData::IsBoxsetCompleted
02d37284: mov     w20, w0                                    
02d37288: tbz     w0, #0, #0x2d372cc                         
02d3728c: adrp    x8, #0x6264000                             
02d37290: ldr     x8, [x8, #0xe8]                            T:DG.Tweening.TweenCallback
02d37294: ldr     x0, [x8]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d37298: bl      #0x2b7104c                                 fn_2b7104c
02d3729c: adrp    x8, #0x626a000                             
02d372a0: mov     x1, x19                                    
02d372a4: mov     x3, xzr                                    
02d372a8: ldr     x8, [x8, #0xb48]                           M:BlindBagCollection.BlindbagDragController::<UnlockCurrentItemInCollection>b__27_0
02d372ac: mov     x21, x0                                    
02d372b0: ldr     x2, [x8]                                   T:type56879(k15)
02d372b4: bl      #0x2d89dc4                                 DG.Tweening.TweenCallback::.ctor
02d372b8: fmov    s0, #0.50000000                            
02d372bc: mov     x0, x21                                    
02d372c0: mov     w1, #1                                     
02d372c4: mov     x2, xzr                                    
02d372c8: bl      #0x2d8f37c                                 DG.Tweening.DOVirtual::DelayedCall
02d372cc: and     w0, w20, #1                                
02d372d0: ldp     x20, x19, [sp, #0x10]                      
02d372d4: ldp     x30, x21, [sp], #0x20                      
02d372d8: ret                                                
02d372dc: bl      #0x2b7105c                                 fn_2b7105c
## Complete() -> void
---- BlindBagCollection.BlindbagDragController::Complete 0x2d373f4
02d373f4: sub     sp, sp, #0x60                              
02d373f8: str     x30, [sp, #0x30]                           
02d373fc: stp     x22, x21, [sp, #0x40]                      
02d37400: stp     x20, x19, [sp, #0x50]                      
02d37404: adrp    x20, #0x6630000                            
02d37408: mov     x19, x0                                    
02d3740c: ldrb    w8, [x20, #0x127]                          
02d37410: tbnz    w8, #0, #0x2d3744c                         
02d37414: adrp    x0, #0x626a000                             
02d37418: ldr     x0, [x0, #0xb50]                           MS:System.Collections.Generic.List`1/Enumerator::Dispose
02d3741c: bl      #0x2b70db0                                 fn_2b70db0
02d37420: adrp    x0, #0x626a000                             
02d37424: ldr     x0, [x0, #0xb58]                           MS:System.Collections.Generic.List`1/Enumerator::MoveNext
02d37428: bl      #0x2b70db0                                 fn_2b70db0
02d3742c: adrp    x0, #0x626a000                             
02d37430: ldr     x0, [x0, #0xb60]                           MS:System.Collections.Generic.List`1/Enumerator::get_Current
02d37434: bl      #0x2b70db0                                 fn_2b70db0
02d37438: adrp    x0, #0x626a000                             
02d3743c: ldr     x0, [x0, #0xb68]                           MS:System.Collections.Generic.List`1::GetEnumerator
02d37440: bl      #0x2b70db0                                 fn_2b70db0
02d37444: mov     w8, #1                                     
02d37448: strb    w8, [x20, #0x127]                          
02d3744c: ldr     x0, [x19, #0xa0]                           ._spawnedItems
02d37450: stp     xzr, xzr, [sp, #0x18]                      
02d37454: str     xzr, [sp, #0x28]                           
02d37458: cbz     x0, #0x2d374e0                             
02d3745c: adrp    x8, #0x626a000                             
02d37460: adrp    x20, #0x626a000                            
02d37464: adrp    x21, #0x626a000                            
02d37468: ldr     x8, [x8, #0xb68]                           MS:System.Collections.Generic.List`1::GetEnumerator
02d3746c: ldr     x20, [x20, #0xb58]                         MS:System.Collections.Generic.List`1/Enumerator::MoveNext
02d37470: ldr     x21, [x21, #0xb50]                         MS:System.Collections.Generic.List`1/Enumerator::Dispose
02d37474: add     x22, sp, #0x18                             
02d37478: ldr     x1, [x8]                                   T:type56879(k15)
02d3747c: add     x8, sp, #0x18                              
02d37480: bl      #0x35a9d9c                                 fn_35a9d9c
02d37484: stp     xzr, x22, [sp, #8]                         
02d37488: ldr     x1, [x20]                                  T:type56879(k15)
02d3748c: add     x0, sp, #0x18                              
02d37490: bl      #0x4690474                                 fn_4690474
02d37494: tbz     w0, #0, #0x2d374b0                         
02d37498: ldr     x0, [sp, #0x28]                            
02d3749c: cbz     x0, #0x2d374dc                             
02d374a0: mov     w1, #1                                     
02d374a4: mov     x2, xzr                                    
02d374a8: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d374ac: b       #0x2d37488                                 
02d374b0: ldr     x1, [x21]                                  T:type56879(k15)
02d374b4: add     x0, sp, #0x18                              
02d374b8: bl      #0x4690470                                 fn_4690470
02d374bc: ldr     x0, [x19, #0x40]                           ._collectionController
02d374c0: cbz     x0, #0x2d374e0                             
02d374c4: bl      #0x2d354f8                                 BlindBagCollection.BlindbagCollectionController::OnCollectionComplete
02d374c8: ldp     x20, x19, [sp, #0x50]                      
02d374cc: ldr     x30, [sp, #0x30]                           
02d374d0: ldp     x22, x21, [sp, #0x40]                      
02d374d4: add     sp, sp, #0x60                              
02d374d8: ret                                                
02d374dc: bl      #0x2b7105c                                 fn_2b7105c
02d374e0: bl      #0x2b7105c                                 fn_2b7105c
02d374e4: b       #0x2d374ec                                 
02d374e8: b       #0x2d374ec                                 
02d374ec: mov     x20, x0                                    
02d374f0: cmp     w1, #1                                     
02d374f4: b.ne    #0x2d37528                                 
02d374f8: mov     x0, x20                                    
02d374fc: bl      #0x5e90260                                 fn_5e90260
02d37500: ldr     x20, [x0]                                  T:type56879(k15)
02d37504: str     x20, [sp, #8]                              
02d37508: bl      #0x5e90270                                 fn_5e90270
02d3750c: ldr     x0, [sp, #0x10]                            
02d37510: ldr     x1, [x21]                                  T:type56879(k15)
02d37514: bl      #0x4690470                                 fn_4690470
02d37518: cbz     x20, #0x2d374bc                            
02d3751c: mov     x0, x20                                    
02d37520: bl      #0x2b71054                                 fn_2b71054
02d37524: mov     x20, x0                                    
02d37528: add     x0, sp, #8                                 
02d3752c: bl      #0x2738308                                 fn_2738308
02d37530: mov     x0, x20                                    
02d37534: bl      #0x2c6051c                                 fn_2c6051c
02d37538: bl      #0x27369b8                                 fn_27369b8
## OnDragStartHandler(BlindBagCollection.ItemDraggable item) -> void
---- BlindBagCollection.BlindbagDragController::OnDragStartHandler 0x2d3753c
02d3753c: str     d10, [sp, #-0x50]!                         
02d37540: stp     d9, d8, [sp, #0x10]                        
02d37544: stp     x30, x23, [sp, #0x20]                      
02d37548: stp     x22, x21, [sp, #0x30]                      
02d3754c: stp     x20, x19, [sp, #0x40]                      
02d37550: adrp    x20, #0x6630000                            
02d37554: mov     x21, x1                                    
02d37558: mov     x19, x0                                    
02d3755c: ldrb    w8, [x20, #0x128]                          
02d37560: tbnz    w8, #0, #0x2d37584                         
02d37564: adrp    x0, #0x6266000                             
02d37568: ldr     x0, [x0, #0x938]                           MS:UnityEngine.InputSystem.InputControl`1::ReadValue
02d3756c: bl      #0x2b70db0                                 fn_2b70db0
02d37570: adrp    x0, #0x6263000                             
02d37574: ldr     x0, [x0, #0x918]                           T:UnityEngine.Object
02d37578: bl      #0x2b70db0                                 fn_2b70db0
02d3757c: mov     w8, #1                                     
02d37580: strb    w8, [x20, #0x128]                          
02d37584: adrp    x20, #0x662f000                            
02d37588: ldrb    w8, [x20, #0xbd9]                          
02d3758c: cbnz    w8, #0x2d375a4                             
02d37590: adrp    x0, #0x6266000                             
02d37594: ldr     x0, [x0, #0x950]                           T:UnityEngine.InputSystem.Pointer
02d37598: bl      #0x2b70db0                                 fn_2b70db0
02d3759c: mov     w8, #1                                     
02d375a0: strb    w8, [x20, #0xbd9]                          
02d375a4: adrp    x8, #0x6266000                             
02d375a8: ldr     x8, [x8, #0x950]                           T:UnityEngine.InputSystem.Pointer
02d375ac: ldr     x8, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d375b0: ldr     x8, [x8, #0xb8]                            S:'banner_native_refresh_time'
02d375b4: ldr     x23, [x8]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d375b8: cbz     x23, #0x2d37704                            
02d375bc: adrp    x8, #0x6263000                             
02d375c0: mov     x20, x19                                   
02d375c4: ldr     x8, [x8, #0x918]                           T:UnityEngine.Object
02d375c8: ldr     x22, [x20, #0x68]!                         [662f068]=6000019 f=2.40742e-35,0 ._currentItem
02d375cc: ldr     x0, [x8]                                   &2c5bbd4(=a9bd7bfdd503233f)
02d375d0: ldr     w8, [x0, #0xe4]                            [62660e4]=0 f=0,0
02d375d4: cbnz    w8, #0x2d375dc                             
02d375d8: bl      #0x2b70f30                                 fn_2b70f30
02d375dc: mov     x0, x22                                    
02d375e0: mov     x1, xzr                                    
02d375e4: mov     x2, xzr                                    
02d375e8: bl      #0x5b3666c                                 UnityEngine.Object::op_Inequality
02d375ec: tbz     w0, #0, #0x2d375f8                         
02d375f0: mov     x0, x19                                    
02d375f4: bl      #0x2d36db8                                 BlindBagCollection.BlindbagDragController::OnDragEnded
02d375f8: mov     x0, x20                                    
02d375fc: mov     x1, x21                                    
02d37600: str     x21, [x20]                                 
02d37604: bl      #0x2b70d54                                 fn_2b70d54
02d37608: ldr     x0, [x20]                                  &2b706c4(=eb01011ff9400808)
02d3760c: cbz     x0, #0x2d3771c                             
02d37610: mov     x1, xzr                                    
02d37614: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02d37618: cbz     x0, #0x2d3771c                             
02d3761c: ldr     x1, [x19, #0x30]                           ._focus
02d37620: mov     x2, xzr                                    
02d37624: bl      #0x5b472ec                                 UnityEngine.Transform::SetParent
02d37628: ldr     x0, [x23, #0x188]                          
02d3762c: cbz     x0, #0x2d3771c                             
02d37630: adrp    x8, #0x6266000                             
02d37634: ldr     x8, [x8, #0x938]                           MS:UnityEngine.InputSystem.InputControl`1::ReadValue
02d37638: ldr     x21, [x19, #0x90]                          ._mainCamera
02d3763c: ldr     x1, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d37640: bl      #0x4a187c4                                 fn_4a187c4
02d37644: cbz     x21, #0x2d3771c                            
02d37648: movi    d2, #0000000000000000                      
02d3764c: mov     x0, x21                                    
02d37650: mov     x1, xzr                                    
02d37654: bl      #0x5aefbb0                                 UnityEngine.Camera::ScreenToWorldPoint
02d37658: ldr     x0, [x20]                                  &2b706c4(=eb01011ff9400808)
02d3765c: cbz     x0, #0x2d3771c                             
02d37660: mov     x1, xzr                                    
02d37664: fmov    s8, s0                                     
02d37668: fmov    s9, s1                                     
02d3766c: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02d37670: cbz     x0, #0x2d3771c                             
02d37674: mov     x1, xzr                                    
02d37678: bl      #0x5b467ac                                 UnityEngine.Transform::get_position
02d3767c: ldr     x0, [x20]                                  &2b706c4(=eb01011ff9400808)
02d37680: cbz     x0, #0x2d3771c                             
02d37684: mov     x1, xzr                                    
02d37688: fmov    s10, s2                                    
02d3768c: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02d37690: cbz     x0, #0x2d3771c                             
02d37694: mov     x1, xzr                                    
02d37698: bl      #0x5b467ac                                 UnityEngine.Transform::get_position
02d3769c: fsub    s0, s0, s8                                 
02d376a0: fsub    s1, s1, s9                                 
02d376a4: ldr     s5, [x19, #0x88]                           
02d376a8: fsub    s2, s2, s10                                
02d376ac: ldp     s3, s4, [x19, #0x80]                       ._dragOffsetBonus
02d376b0: mov     x0, xzr                                    
02d376b4: fadd    s0, s3, s0                                 
02d376b8: fadd    s1, s1, s4                                 
02d376bc: fadd    s2, s2, s5                                 
02d376c0: stp     s0, s1, [x19, #0x74]                       ._dragOffset
02d376c4: str     s2, [x19, #0x7c]                           
02d376c8: bl      #0x2d6eec8                                 Framework.AudioManager::get_Instance
02d376cc: cbz     x0, #0x2d3771c                             
02d376d0: ldp     x20, x19, [sp, #0x40]                      
02d376d4: movi    d1, #0000000000000000                      
02d376d8: ldp     x22, x21, [sp, #0x30]                      
02d376dc: movi    d2, #0000000000000000                      
02d376e0: ldp     x30, x23, [sp, #0x20]                      
02d376e4: fmov    s0, #1.00000000                            
02d376e8: ldp     d9, d8, [sp, #0x10]                        
02d376ec: mov     w1, #0x10                                  
02d376f0: mov     w2, wzr                                    
02d376f4: mov     w3, wzr                                    
02d376f8: mov     x4, xzr                                    
02d376fc: ldr     d10, [sp], #0x50                           
02d37700: b       #0x2d6f03c                                 Framework.AudioManager::PlaySound
02d37704: ldp     x20, x19, [sp, #0x40]                      
02d37708: ldp     x22, x21, [sp, #0x30]                      
02d3770c: ldp     x30, x23, [sp, #0x20]                      
02d37710: ldp     d9, d8, [sp, #0x10]                        
02d37714: ldr     d10, [sp], #0x50                           
02d37718: ret                                                
02d3771c: bl      #0x2b7105c                                 fn_2b7105c
## SpawnCompliment(UnityEngine.Vector2 spawnPosition) -> void
---- BlindBagCollection.BlindbagDragController::SpawnCompliment 0x2d37058
02d37058: stp     d11, d10, [sp, #-0x40]!                    
02d3705c: stp     d9, d8, [sp, #0x10]                        
02d37060: stp     x30, x21, [sp, #0x20]                      
02d37064: stp     x20, x19, [sp, #0x30]                      
02d37068: fmov    s9, s1                                     
02d3706c: fmov    s8, s0                                     
02d37070: adrp    x20, #0x6630000                            
02d37074: adrp    x21, #0x6266000                            
02d37078: ldrb    w8, [x20, #0x129]                          
02d3707c: mov     x19, x0                                    
02d37080: ldr     x21, [x21, #0xd20]                         MS:MonoSingleton`1::get_Instance
02d37084: tbnz    w8, #0, #0x2d370cc                         
02d37088: adrp    x0, #0x626a000                             
02d3708c: ldr     x0, [x0, #0xb38]                           MS:UnityEngine.Component::GetComponent
02d37090: bl      #0x2b70db0                                 fn_2b70db0
02d37094: adrp    x0, #0x6266000                             
02d37098: ldr     x0, [x0, #0xc30]                           MS:System.Collections.Generic.List`1::get_Count
02d3709c: bl      #0x2b70db0                                 fn_2b70db0
02d370a0: adrp    x0, #0x626a000                             
02d370a4: ldr     x0, [x0, #0xb40]                           MS:System.Collections.Generic.List`1::get_Item
02d370a8: bl      #0x2b70db0                                 fn_2b70db0
02d370ac: adrp    x0, #0x6266000                             
02d370b0: ldr     x0, [x0, #0xc38]                           MS:System.Collections.Generic.List`1::get_Item
02d370b4: bl      #0x2b70db0                                 fn_2b70db0
02d370b8: adrp    x0, #0x6266000                             
02d370bc: ldr     x0, [x0, #0xd20]                           MS:MonoSingleton`1::get_Instance
02d370c0: bl      #0x2b70db0                                 fn_2b70db0
02d370c4: mov     w8, #1                                     
02d370c8: strb    w8, [x20, #0x129]                          
02d370cc: ldr     x0, [x21]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d370d0: bl      #0x3769600                                 fn_3769600
02d370d4: cbz     x0, #0x2d371c0                             
02d370d8: mov     w1, #0x6c                                  
02d370dc: mov     x2, xzr                                    
02d370e0: bl      #0x2cdcf8c                                 PoolManager::SpawnPoolElement
02d370e4: cbz     x0, #0x2d371c0                             
02d370e8: adrp    x8, #0x626a000                             
02d370ec: ldr     x8, [x8, #0xb38]                           MS:UnityEngine.Component::GetComponent
02d370f0: ldr     x1, [x8]                                   T:type56879(k15)
02d370f4: bl      #0x3140c84                                 fn_3140c84
02d370f8: ldr     x8, [x19, #0x58]                           ._complimentSprites
02d370fc: cbz     x8, #0x2d371c0                             
02d37100: ldr     w1, [x8, #0x18]                            MS:System.Collections.Generic.List`1::Add
02d37104: mov     x21, x0                                    
02d37108: mov     w0, wzr                                    
02d3710c: mov     x2, xzr                                    
02d37110: bl      #0x5b2e000                                 UnityEngine.Random::Range
02d37114: fmov    s0, #-4.00000000                           
02d37118: fmov    s1, #4.00000000                            
02d3711c: mov     w20, w0                                    
02d37120: mov     x0, xzr                                    
02d37124: bl      #0x5b2dfc0                                 UnityEngine.Random::Range
02d37128: fmov    s10, s0                                    
02d3712c: fmov    s0, #-4.00000000                           
02d37130: mov     x0, xzr                                    
02d37134: fmov    s1, #4.00000000                            
02d37138: bl      #0x5b2dfc0                                 UnityEngine.Random::Range
02d3713c: ldr     x0, [x19, #0x58]                           ._complimentSprites
02d37140: cbz     x0, #0x2d371c0                             
02d37144: adrp    x8, #0x6266000                             
02d37148: mov     w1, w20                                    
02d3714c: fmov    s11, s0                                    
02d37150: ldr     x8, [x8, #0xc38]                           MS:System.Collections.Generic.List`1::get_Item
02d37154: ldr     x2, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d37158: bl      #0x35a8f3c                                 fn_35a8f3c
02d3715c: cbz     x21, #0x2d371c0                            
02d37160: fadd    s1, s9, s11                                
02d37164: fadd    s0, s8, s10                                
02d37168: mov     x1, x0                                     
02d3716c: movi    d2, #0000000000000000                      
02d37170: mov     x0, x21                                    
02d37174: bl      #0x2d37720                                 ScoopGame.ComplimentItem::ShowEffect
02d37178: ldr     x0, [x19, #0x60]                           ._complimentSoundEnum
02d3717c: cbz     x0, #0x2d371c0                             
02d37180: adrp    x8, #0x626a000                             
02d37184: mov     w1, w20                                    
02d37188: ldr     x8, [x8, #0xb40]                           MS:System.Collections.Generic.List`1::get_Item
02d3718c: ldr     x2, [x8]                                   T:type56879(k15)
02d37190: bl      #0x356c280                                 fn_356c280
02d37194: ldp     x20, x19, [sp, #0x30]                      
02d37198: movi    d1, #0000000000000000                      
02d3719c: ldp     x30, x21, [sp, #0x20]                      
02d371a0: movi    d2, #0000000000000000                      
02d371a4: ldp     d9, d8, [sp, #0x10]                        
02d371a8: fmov    s0, #1.00000000                            
02d371ac: mov     w1, wzr                                    
02d371b0: mov     w2, wzr                                    
02d371b4: mov     x3, xzr                                    
02d371b8: ldp     d11, d10, [sp], #0x40                      
02d371bc: b       #0x2d84264                                 Framework.AudioHelper::PlaySound
02d371c0: bl      #0x2b7105c                                 fn_2b7105c
## .ctor() -> void
---- BlindBagCollection.BlindbagDragController::.ctor 0x2d379b4
02d379b4: str     x30, [sp, #-0x30]!                         
02d379b8: stp     x22, x21, [sp, #0x10]                      
02d379bc: stp     x20, x19, [sp, #0x20]                      
02d379c0: adrp    x22, #0x6630000                            
02d379c4: adrp    x21, #0x626a000                            
02d379c8: adrp    x20, #0x626a000                            
02d379cc: ldrb    w8, [x22, #0x12a]                          
02d379d0: ldr     x21, [x21, #0xb98]                         T:type14982(k15)
02d379d4: ldr     x20, [x20, #0xba0]                         MS:System.Collections.Generic.List`1::.ctor
02d379d8: mov     x19, x0                                    
02d379dc: tbnz    w8, #0, #0x2d37a00                         
02d379e0: adrp    x0, #0x626a000                             
02d379e4: ldr     x0, [x0, #0xba0]                           MS:System.Collections.Generic.List`1::.ctor
02d379e8: bl      #0x2b70db0                                 fn_2b70db0
02d379ec: adrp    x0, #0x626a000                             
02d379f0: ldr     x0, [x0, #0xb98]                           T:type14982(k15)
02d379f4: bl      #0x2b70db0                                 fn_2b70db0
02d379f8: mov     w8, #1                                     
02d379fc: strb    w8, [x22, #0x12a]                          
02d37a00: adrp    x8, #0x1040000                             
02d37a04: ldr     x0, [x21]                                  T:type56879(k15)
02d37a08: str     wzr, [x19, #0x88]                          
02d37a0c: ldr     d0, [x8, #0x500]                           [1040500]=4000000000000000 f=0,2
02d37a10: str     d0, [x19, #0x80]                           ._dragOffsetBonus
02d37a14: bl      #0x2b7104c                                 fn_2b7104c
02d37a18: ldr     x1, [x20]                                  T:type56879(k15)
02d37a1c: mov     x20, x0                                    
02d37a20: bl      #0x35a89a4                                 fn_35a89a4
02d37a24: mov     x0, x19                                    
02d37a28: mov     x1, x20                                    
02d37a2c: str     x20, [x0, #0xa0]!                          ._spawnedItems
02d37a30: bl      #0x2b70d54                                 fn_2b70d54
02d37a34: mov     x0, x19                                    
02d37a38: ldp     x20, x19, [sp, #0x20]                      
02d37a3c: ldp     x22, x21, [sp, #0x10]                      
02d37a40: mov     x1, xzr                                    
02d37a44: ldr     x30, [sp], #0x30                           
02d37a48: b       #0x5b397b0                                 UnityEngine.MonoBehaviour::.ctor
## <UnlockCurrentItemInCollection>b__27_0() -> void
---- BlindBagCollection.BlindbagDragController::<UnlockCurrentItemInCollection>b__27_0 0x2d37a4c
02d37a4c: stp     x30, x19, [sp, #-0x10]!                    
02d37a50: ldr     x8, [x0, #0x38]                            ._collectionSelector
02d37a54: cbz     x8, #0x2d37a84                             
02d37a58: ldr     x8, [x8, #0x58]                            
02d37a5c: cbz     x8, #0x2d37a84                             
02d37a60: ldr     x19, [x0, #0x48]                           ._showCompleteBoxset
02d37a64: mov     x0, x8                                     
02d37a68: mov     x1, xzr                                    
02d37a6c: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02d37a70: cbz     x19, #0x2d37a84                            
02d37a74: mov     x1, x0                                     
02d37a78: mov     x0, x19                                    
02d37a7c: ldp     x30, x19, [sp], #0x10                      
02d37a80: b       #0x2d37a88                                 BlindBagCollection.ShowCompleteBoxset::Show
02d37a84: bl      #0x2b7105c                                 fn_2b7105c
