#### CLASS CommentHandler/<>c__DisplayClass19_0 parent= object
#   field commentControl                 CommentControl                                     off=0x10 attr=6 
## .ctor() -> void
---- CommentHandler/<>c__DisplayClass19_0::.ctor 0x2cb6500
02cb6500: mov     x1, xzr                                    
02cb6504: b       #0x4e53e9c                                 System.Object::.ctor
## <SpawnCommentLive>b__0() -> void
---- CommentHandler/<>c__DisplayClass19_0::<SpawnCommentLive>b__0 0x2cb6dac
02cb6dac: stp     x30, x21, [sp, #-0x20]!                    
02cb6db0: stp     x20, x19, [sp, #0x10]                      
02cb6db4: adrp    x21, #0x662f000                            
02cb6db8: adrp    x20, #0x6263000                            
02cb6dbc: mov     x19, x0                                    
02cb6dc0: ldrb    w8, [x21, #0xbb3]                          
02cb6dc4: ldr     x20, [x20, #0x918]                         T:UnityEngine.Object
02cb6dc8: tbnz    w8, #0, #0x2cb6de0                         
02cb6dcc: adrp    x0, #0x6263000                             
02cb6dd0: ldr     x0, [x0, #0x918]                           T:UnityEngine.Object
02cb6dd4: bl      #0x2b70db0                                 fn_2b70db0
02cb6dd8: mov     w8, #1                                     
02cb6ddc: strb    w8, [x21, #0xbb3]                          
02cb6de0: ldr     x0, [x20]                                  &2c5bbd4(=a9bd7bfdd503233f)
02cb6de4: ldr     x20, [x19, #0x10]                          .commentControl
02cb6de8: ldr     w8, [x0, #0xe4]                            [62630e4]=0 f=0,0
02cb6dec: cbnz    w8, #0x2cb6df4                             
02cb6df0: bl      #0x2b70f30                                 fn_2b70f30
02cb6df4: mov     x0, x20                                    
02cb6df8: mov     x1, xzr                                    
02cb6dfc: mov     x2, xzr                                    
02cb6e00: bl      #0x5b3666c                                 UnityEngine.Object::op_Inequality
02cb6e04: tbz     w0, #0, #0x2cb6e20                         
02cb6e08: ldr     x0, [x19, #0x10]                           .commentControl
02cb6e0c: cbz     x0, #0x2cb6e2c                             
02cb6e10: ldp     x20, x19, [sp, #0x10]                      
02cb6e14: mov     x1, xzr                                    
02cb6e18: ldp     x30, x21, [sp], #0x20                      
02cb6e1c: b       #0x2cdc880                                 PoolElement::DespawnSelf
02cb6e20: ldp     x20, x19, [sp, #0x10]                      
02cb6e24: ldp     x30, x21, [sp], #0x20                      
02cb6e28: ret                                                
02cb6e2c: bl      #0x2b7105c                                 fn_2b7105c
#### CLASS CommentHandler/<>c__DisplayClass20_0 parent= object
#   field commentControl                 CommentControl                                     off=0x10 attr=6 
## .ctor() -> void
---- CommentHandler/<>c__DisplayClass20_0::.ctor 0x2cb6844
02cb6844: mov     x1, xzr                                    
02cb6848: b       #0x4e53e9c                                 System.Object::.ctor
## <SpawnDonateComment>b__0() -> void
---- CommentHandler/<>c__DisplayClass20_0::<SpawnDonateComment>b__0 0x2cb6e30
02cb6e30: stp     x30, x21, [sp, #-0x20]!                    
02cb6e34: stp     x20, x19, [sp, #0x10]                      
02cb6e38: adrp    x21, #0x662f000                            
02cb6e3c: adrp    x20, #0x6263000                            
02cb6e40: mov     x19, x0                                    
02cb6e44: ldrb    w8, [x21, #0xbb4]                          
02cb6e48: ldr     x20, [x20, #0x918]                         T:UnityEngine.Object
02cb6e4c: tbnz    w8, #0, #0x2cb6e64                         
02cb6e50: adrp    x0, #0x6263000                             
02cb6e54: ldr     x0, [x0, #0x918]                           T:UnityEngine.Object
02cb6e58: bl      #0x2b70db0                                 fn_2b70db0
02cb6e5c: mov     w8, #1                                     
02cb6e60: strb    w8, [x21, #0xbb4]                          
02cb6e64: ldr     x0, [x20]                                  &2c5bbd4(=a9bd7bfdd503233f)
02cb6e68: ldr     x20, [x19, #0x10]                          .commentControl
02cb6e6c: ldr     w8, [x0, #0xe4]                            [62630e4]=0 f=0,0
02cb6e70: cbnz    w8, #0x2cb6e78                             
02cb6e74: bl      #0x2b70f30                                 fn_2b70f30
02cb6e78: mov     x0, x20                                    
02cb6e7c: mov     x1, xzr                                    
02cb6e80: mov     x2, xzr                                    
02cb6e84: bl      #0x5b3666c                                 UnityEngine.Object::op_Inequality
02cb6e88: tbz     w0, #0, #0x2cb6ea4                         
02cb6e8c: ldr     x0, [x19, #0x10]                           .commentControl
02cb6e90: cbz     x0, #0x2cb6eb0                             
02cb6e94: ldp     x20, x19, [sp, #0x10]                      
02cb6e98: mov     x1, xzr                                    
02cb6e9c: ldp     x30, x21, [sp], #0x20                      
02cb6ea0: b       #0x2cdc880                                 PoolElement::DespawnSelf
02cb6ea4: ldp     x20, x19, [sp, #0x10]                      
02cb6ea8: ldp     x30, x21, [sp], #0x20                      
02cb6eac: ret                                                
02cb6eb0: bl      #0x2b7105c                                 fn_2b7105c
#### CLASS CommentHandler/<>c__DisplayClass21_0 parent= object
#   field rectComment                    UnityEngine.RectTransform                          off=0x10 attr=6 
#   field <>4__this                      CommentHandler                                     off=0x18 attr=6 
#   field commentControl                 CommentControl                                     off=0x20 attr=6 
#   field <>9__1                         System.Action                                      off=0x28 attr=6 
## .ctor() -> void
---- CommentHandler/<>c__DisplayClass21_0::.ctor 0x2cb6c50
02cb6c50: mov     x1, xzr                                    
02cb6c54: b       #0x4e53e9c                                 System.Object::.ctor
## <StartComment>b__0() -> void
---- CommentHandler/<>c__DisplayClass21_0::<StartComment>b__0 0x2cb6eb4
02cb6eb4: str     x30, [sp, #-0x30]!                         
02cb6eb8: stp     x22, x21, [sp, #0x10]                      
02cb6ebc: stp     x20, x19, [sp, #0x20]                      
02cb6ec0: adrp    x20, #0x662f000                            
02cb6ec4: adrp    x21, #0x6263000                            
02cb6ec8: mov     x19, x0                                    
02cb6ecc: ldrb    w8, [x20, #0xbb5]                          
02cb6ed0: ldr     x21, [x21, #0x918]                         T:UnityEngine.Object
02cb6ed4: tbnz    w8, #0, #0x2cb6f10                         
02cb6ed8: adrp    x0, #0x6264000                             
02cb6edc: ldr     x0, [x0, #0xf90]                           T:System.Action
02cb6ee0: bl      #0x2b70db0                                 fn_2b70db0
02cb6ee4: adrp    x0, #0x6263000                             
02cb6ee8: ldr     x0, [x0, #0x918]                           T:UnityEngine.Object
02cb6eec: bl      #0x2b70db0                                 fn_2b70db0
02cb6ef0: adrp    x0, #0x6266000                             
02cb6ef4: ldr     x0, [x0, #0xa18]                           MS:DG.Tweening.TweenSettingsExtensions::SetEase
02cb6ef8: bl      #0x2b70db0                                 fn_2b70db0
02cb6efc: adrp    x0, #0x6266000                             
02cb6f00: ldr     x0, [x0, #0xd80]                           M:CommentHandler/<>c__DisplayClass21_0::<StartComment>b__1
02cb6f04: bl      #0x2b70db0                                 fn_2b70db0
02cb6f08: mov     w8, #1                                     
02cb6f0c: strb    w8, [x20, #0xbb5]                          
02cb6f10: ldr     x0, [x21]                                  &2c5bbd4(=a9bd7bfdd503233f)
02cb6f14: ldr     x20, [x19, #0x10]                          .rectComment
02cb6f18: ldr     w8, [x0, #0xe4]                            [62660e4]=0 f=0,0
02cb6f1c: cbnz    w8, #0x2cb6f24                             
02cb6f20: bl      #0x2b70f30                                 fn_2b70f30
02cb6f24: mov     x0, x20                                    
02cb6f28: mov     x1, xzr                                    
02cb6f2c: mov     x2, xzr                                    
02cb6f30: bl      #0x5b3666c                                 UnityEngine.Object::op_Inequality
02cb6f34: tbz     w0, #0, #0x2cb6f84                         
02cb6f38: ldr     x8, [x19, #0x18]                           .<>4__this
02cb6f3c: cbz     x8, #0x2cb7024                             
02cb6f40: ldr     w8, [x8, #0x78]                            
02cb6f44: ldr     x0, [x19, #0x10]                           .rectComment
02cb6f48: mov     w1, wzr                                    
02cb6f4c: mov     x2, xzr                                    
02cb6f50: add     w8, w8, #1                                 
02cb6f54: scvtf   s0, w8                                     
02cb6f58: mov     w8, #0x42c80000                            
02cb6f5c: fmov    s1, w8                                     
02cb6f60: adrp    x8, #0x1084000                             
02cb6f64: fmul    s0, s0, s1                                 
02cb6f68: ldr     s1, [x8, #0xca0]                           [1084ca0]=3eaaaaab3f19999a f=0.6,0.333333
02cb6f6c: bl      #0x2c79c1c                                 DG.Tweening.DOTweenModuleUI::DOAnchorPosY
02cb6f70: adrp    x8, #0x6266000                             
02cb6f74: mov     w1, #1                                     
02cb6f78: ldr     x8, [x8, #0xa18]                           MS:DG.Tweening.TweenSettingsExtensions::SetEase
02cb6f7c: ldr     x2, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cb6f80: bl      #0x336fa0c                                 fn_336fa0c
02cb6f84: ldr     x0, [x21]                                  &2c5bbd4(=a9bd7bfdd503233f)
02cb6f88: ldr     x20, [x19, #0x20]                          .commentControl
02cb6f8c: ldr     w8, [x0, #0xe4]                            [62660e4]=0 f=0,0
02cb6f90: cbnz    w8, #0x2cb6f98                             
02cb6f94: bl      #0x2b70f30                                 fn_2b70f30
02cb6f98: mov     x0, x20                                    
02cb6f9c: mov     x1, xzr                                    
02cb6fa0: mov     x2, xzr                                    
02cb6fa4: bl      #0x5b3666c                                 UnityEngine.Object::op_Inequality
02cb6fa8: tbz     w0, #0, #0x2cb7014                         
02cb6fac: mov     x21, x19                                   
02cb6fb0: ldr     x22, [x21, #0x28]!                         [6263028]=0 f=0,0 .<>9__1
02cb6fb4: ldur    x20, [x21, #-8]                            
02cb6fb8: cbnz    x22, #0x2cb6ff8                            
02cb6fbc: adrp    x8, #0x6264000                             
02cb6fc0: ldr     x8, [x8, #0xf90]                           T:System.Action
02cb6fc4: ldr     x0, [x8]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02cb6fc8: bl      #0x2b7104c                                 fn_2b7104c
02cb6fcc: adrp    x8, #0x6266000                             
02cb6fd0: mov     x1, x19                                    
02cb6fd4: mov     x3, xzr                                    
02cb6fd8: ldr     x8, [x8, #0xd80]                           M:CommentHandler/<>c__DisplayClass21_0::<StartComment>b__1
02cb6fdc: mov     x22, x0                                    
02cb6fe0: ldr     x2, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cb6fe4: bl      #0x4d8ddbc                                 System.Action::.ctor
02cb6fe8: mov     x0, x21                                    
02cb6fec: mov     x1, x22                                    
02cb6ff0: str     x22, [x19, #0x28]                          .<>9__1
02cb6ff4: bl      #0x2b70d54                                 fn_2b70d54
02cb6ff8: cbz     x20, #0x2cb7024                            
02cb6ffc: mov     x0, x20                                    
02cb7000: mov     x1, x22                                    
02cb7004: ldp     x20, x19, [sp, #0x20]                      
02cb7008: ldp     x22, x21, [sp, #0x10]                      
02cb700c: ldr     x30, [sp], #0x30                           
02cb7010: b       #0x2cb53a4                                 CommentControl::AnimFadeOut
02cb7014: ldp     x20, x19, [sp, #0x20]                      
02cb7018: ldp     x22, x21, [sp, #0x10]                      
02cb701c: ldr     x30, [sp], #0x30                           
02cb7020: ret                                                
02cb7024: bl      #0x2b7105c                                 fn_2b7105c
## <StartComment>b__1() -> void
---- CommentHandler/<>c__DisplayClass21_0::<StartComment>b__1 0x2cb7028
02cb7028: stp     x30, x21, [sp, #-0x20]!                    
02cb702c: stp     x20, x19, [sp, #0x10]                      
02cb7030: adrp    x20, #0x662f000                            
02cb7034: adrp    x21, #0x6263000                            
02cb7038: mov     x19, x0                                    
02cb703c: ldrb    w8, [x20, #0xbb6]                          
02cb7040: ldr     x21, [x21, #0x918]                         T:UnityEngine.Object
02cb7044: tbnz    w8, #0, #0x2cb705c                         
02cb7048: adrp    x0, #0x6263000                             
02cb704c: ldr     x0, [x0, #0x918]                           T:UnityEngine.Object
02cb7050: bl      #0x2b70db0                                 fn_2b70db0
02cb7054: mov     w8, #1                                     
02cb7058: strb    w8, [x20, #0xbb6]                          
02cb705c: ldr     x0, [x21]                                  &2c5bbd4(=a9bd7bfdd503233f)
02cb7060: ldr     x20, [x19, #0x20]                          .commentControl
02cb7064: ldr     w8, [x0, #0xe4]                            [62630e4]=0 f=0,0
02cb7068: cbnz    w8, #0x2cb7070                             
02cb706c: bl      #0x2b70f30                                 fn_2b70f30
02cb7070: mov     x0, x20                                    
02cb7074: mov     x1, xzr                                    
02cb7078: mov     x2, xzr                                    
02cb707c: bl      #0x5b3666c                                 UnityEngine.Object::op_Inequality
02cb7080: tbz     w0, #0, #0x2cb70d8                         
02cb7084: ldr     x0, [x19, #0x20]                           .commentControl
02cb7088: cbz     x0, #0x2cb70e4                             
02cb708c: mov     x1, xzr                                    
02cb7090: bl      #0x5b339ec                                 UnityEngine.Component::get_gameObject
02cb7094: ldr     x8, [x21]                                  &2c5bbd4(=a9bd7bfdd503233f)
02cb7098: mov     x20, x0                                    
02cb709c: ldr     w9, [x8, #0xe4]                            
02cb70a0: cbnz    w9, #0x2cb70ac                             
02cb70a4: mov     x0, x8                                     
02cb70a8: bl      #0x2b70f30                                 fn_2b70f30
02cb70ac: mov     x0, x20                                    
02cb70b0: mov     x1, xzr                                    
02cb70b4: mov     x2, xzr                                    
02cb70b8: bl      #0x5b3666c                                 UnityEngine.Object::op_Inequality
02cb70bc: tbz     w0, #0, #0x2cb70d8                         
02cb70c0: ldr     x0, [x19, #0x20]                           .commentControl
02cb70c4: cbz     x0, #0x2cb70e4                             
02cb70c8: ldp     x20, x19, [sp, #0x10]                      
02cb70cc: mov     x1, xzr                                    
02cb70d0: ldp     x30, x21, [sp], #0x20                      
02cb70d4: b       #0x2cdc880                                 PoolElement::DespawnSelf
02cb70d8: ldp     x20, x19, [sp, #0x10]                      
02cb70dc: ldp     x30, x21, [sp], #0x20                      
02cb70e0: ret                                                
02cb70e4: bl      #0x2b7105c                                 fn_2b7105c
#### CLASS CommentHandler/<>c__DisplayClass25_0 parent= object
#   field rectComment                    UnityEngine.RectTransform                          off=0x10 attr=6 
#   field <>4__this                      CommentHandler                                     off=0x18 attr=6 
#   field commentControl                 CommentControl                                     off=0x20 attr=6 
#   field <>9__1                         System.Action                                      off=0x28 attr=6 
## .ctor() -> void
---- CommentHandler/<>c__DisplayClass25_0::.ctor 0x2cb6d04
02cb6d04: mov     x1, xzr                                    
02cb6d08: b       #0x4e53e9c                                 System.Object::.ctor
## <Comment>b__0() -> void
---- CommentHandler/<>c__DisplayClass25_0::<Comment>b__0 0x2cb70e8
02cb70e8: str     x30, [sp, #-0x30]!                         
02cb70ec: stp     x22, x21, [sp, #0x10]                      
02cb70f0: stp     x20, x19, [sp, #0x20]                      
02cb70f4: adrp    x20, #0x662f000                            
02cb70f8: adrp    x21, #0x6263000                            
02cb70fc: mov     x19, x0                                    
02cb7100: ldrb    w8, [x20, #0xbb7]                          
02cb7104: ldr     x21, [x21, #0x918]                         T:UnityEngine.Object
02cb7108: tbnz    w8, #0, #0x2cb7144                         
02cb710c: adrp    x0, #0x6264000                             
02cb7110: ldr     x0, [x0, #0xf90]                           T:System.Action
02cb7114: bl      #0x2b70db0                                 fn_2b70db0
02cb7118: adrp    x0, #0x6263000                             
02cb711c: ldr     x0, [x0, #0x918]                           T:UnityEngine.Object
02cb7120: bl      #0x2b70db0                                 fn_2b70db0
02cb7124: adrp    x0, #0x6266000                             
02cb7128: ldr     x0, [x0, #0xa18]                           MS:DG.Tweening.TweenSettingsExtensions::SetEase
02cb712c: bl      #0x2b70db0                                 fn_2b70db0
02cb7130: adrp    x0, #0x6266000                             
02cb7134: ldr     x0, [x0, #0xd88]                           M:CommentHandler/<>c__DisplayClass25_0::<Comment>b__1
02cb7138: bl      #0x2b70db0                                 fn_2b70db0
02cb713c: mov     w8, #1                                     
02cb7140: strb    w8, [x20, #0xbb7]                          
02cb7144: ldr     x0, [x21]                                  &2c5bbd4(=a9bd7bfdd503233f)
02cb7148: ldr     x20, [x19, #0x10]                          .rectComment
02cb714c: ldr     w8, [x0, #0xe4]                            [62660e4]=0 f=0,0
02cb7150: cbnz    w8, #0x2cb7158                             
02cb7154: bl      #0x2b70f30                                 fn_2b70f30
02cb7158: mov     x0, x20                                    
02cb715c: mov     x1, xzr                                    
02cb7160: mov     x2, xzr                                    
02cb7164: bl      #0x5b3666c                                 UnityEngine.Object::op_Inequality
02cb7168: tbz     w0, #0, #0x2cb71b8                         
02cb716c: ldr     x8, [x19, #0x18]                           .<>4__this
02cb7170: cbz     x8, #0x2cb7258                             
02cb7174: ldr     w8, [x8, #0x78]                            
02cb7178: ldr     x0, [x19, #0x10]                           .rectComment
02cb717c: mov     w1, wzr                                    
02cb7180: mov     x2, xzr                                    
02cb7184: add     w8, w8, #1                                 
02cb7188: scvtf   s0, w8                                     
02cb718c: mov     w8, #0x42c80000                            
02cb7190: fmov    s1, w8                                     
02cb7194: adrp    x8, #0x1084000                             
02cb7198: fmul    s0, s0, s1                                 
02cb719c: ldr     s1, [x8, #0xca0]                           [1084ca0]=3eaaaaab3f19999a f=0.6,0.333333
02cb71a0: bl      #0x2c79c1c                                 DG.Tweening.DOTweenModuleUI::DOAnchorPosY
02cb71a4: adrp    x8, #0x6266000                             
02cb71a8: mov     w1, #1                                     
02cb71ac: ldr     x8, [x8, #0xa18]                           MS:DG.Tweening.TweenSettingsExtensions::SetEase
02cb71b0: ldr     x2, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cb71b4: bl      #0x336fa0c                                 fn_336fa0c
02cb71b8: ldr     x0, [x21]                                  &2c5bbd4(=a9bd7bfdd503233f)
02cb71bc: ldr     x20, [x19, #0x20]                          .commentControl
02cb71c0: ldr     w8, [x0, #0xe4]                            [62660e4]=0 f=0,0
02cb71c4: cbnz    w8, #0x2cb71cc                             
02cb71c8: bl      #0x2b70f30                                 fn_2b70f30
02cb71cc: mov     x0, x20                                    
02cb71d0: mov     x1, xzr                                    
02cb71d4: mov     x2, xzr                                    
02cb71d8: bl      #0x5b3666c                                 UnityEngine.Object::op_Inequality
02cb71dc: tbz     w0, #0, #0x2cb7248                         
02cb71e0: mov     x21, x19                                   
02cb71e4: ldr     x22, [x21, #0x28]!                         [6263028]=0 f=0,0 .<>9__1
02cb71e8: ldur    x20, [x21, #-8]                            
02cb71ec: cbnz    x22, #0x2cb722c                            
02cb71f0: adrp    x8, #0x6264000                             
02cb71f4: ldr     x8, [x8, #0xf90]                           T:System.Action
02cb71f8: ldr     x0, [x8]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02cb71fc: bl      #0x2b7104c                                 fn_2b7104c
02cb7200: adrp    x8, #0x6266000                             
02cb7204: mov     x1, x19                                    
02cb7208: mov     x3, xzr                                    
02cb720c: ldr     x8, [x8, #0xd88]                           M:CommentHandler/<>c__DisplayClass25_0::<Comment>b__1
02cb7210: mov     x22, x0                                    
02cb7214: ldr     x2, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cb7218: bl      #0x4d8ddbc                                 System.Action::.ctor
02cb721c: mov     x0, x21                                    
02cb7220: mov     x1, x22                                    
02cb7224: str     x22, [x19, #0x28]                          .<>9__1
02cb7228: bl      #0x2b70d54                                 fn_2b70d54
02cb722c: cbz     x20, #0x2cb7258                            
02cb7230: mov     x0, x20                                    
02cb7234: mov     x1, x22                                    
02cb7238: ldp     x20, x19, [sp, #0x20]                      
02cb723c: ldp     x22, x21, [sp, #0x10]                      
02cb7240: ldr     x30, [sp], #0x30                           
02cb7244: b       #0x2cb53a4                                 CommentControl::AnimFadeOut
02cb7248: ldp     x20, x19, [sp, #0x20]                      
02cb724c: ldp     x22, x21, [sp, #0x10]                      
02cb7250: ldr     x30, [sp], #0x30                           
02cb7254: ret                                                
02cb7258: bl      #0x2b7105c                                 fn_2b7105c
## <Comment>b__1() -> void
---- CommentHandler/<>c__DisplayClass25_0::<Comment>b__1 0x2cb725c
02cb725c: stp     x30, x21, [sp, #-0x20]!                    
02cb7260: stp     x20, x19, [sp, #0x10]                      
02cb7264: adrp    x20, #0x662f000                            
02cb7268: adrp    x21, #0x6263000                            
02cb726c: mov     x19, x0                                    
02cb7270: ldrb    w8, [x20, #0xbb8]                          
02cb7274: ldr     x21, [x21, #0x918]                         T:UnityEngine.Object
02cb7278: tbnz    w8, #0, #0x2cb7290                         
02cb727c: adrp    x0, #0x6263000                             
02cb7280: ldr     x0, [x0, #0x918]                           T:UnityEngine.Object
02cb7284: bl      #0x2b70db0                                 fn_2b70db0
02cb7288: mov     w8, #1                                     
02cb728c: strb    w8, [x20, #0xbb8]                          
02cb7290: ldr     x0, [x21]                                  &2c5bbd4(=a9bd7bfdd503233f)
02cb7294: ldr     x20, [x19, #0x20]                          .commentControl
02cb7298: ldr     w8, [x0, #0xe4]                            [62630e4]=0 f=0,0
02cb729c: cbnz    w8, #0x2cb72a4                             
02cb72a0: bl      #0x2b70f30                                 fn_2b70f30
02cb72a4: mov     x0, x20                                    
02cb72a8: mov     x1, xzr                                    
02cb72ac: mov     x2, xzr                                    
02cb72b0: bl      #0x5b3666c                                 UnityEngine.Object::op_Inequality
02cb72b4: tbz     w0, #0, #0x2cb730c                         
02cb72b8: ldr     x0, [x19, #0x20]                           .commentControl
02cb72bc: cbz     x0, #0x2cb7318                             
02cb72c0: mov     x1, xzr                                    
02cb72c4: bl      #0x5b339ec                                 UnityEngine.Component::get_gameObject
02cb72c8: ldr     x8, [x21]                                  &2c5bbd4(=a9bd7bfdd503233f)
02cb72cc: mov     x20, x0                                    
02cb72d0: ldr     w9, [x8, #0xe4]                            
02cb72d4: cbnz    w9, #0x2cb72e0                             
02cb72d8: mov     x0, x8                                     
02cb72dc: bl      #0x2b70f30                                 fn_2b70f30
02cb72e0: mov     x0, x20                                    
02cb72e4: mov     x1, xzr                                    
02cb72e8: mov     x2, xzr                                    
02cb72ec: bl      #0x5b3666c                                 UnityEngine.Object::op_Inequality
02cb72f0: tbz     w0, #0, #0x2cb730c                         
02cb72f4: ldr     x0, [x19, #0x20]                           .commentControl
02cb72f8: cbz     x0, #0x2cb7318                             
02cb72fc: ldp     x20, x19, [sp, #0x10]                      
02cb7300: mov     x1, xzr                                    
02cb7304: ldp     x30, x21, [sp], #0x20                      
02cb7308: b       #0x2cdc880                                 PoolElement::DespawnSelf
02cb730c: ldp     x20, x19, [sp, #0x10]                      
02cb7310: ldp     x30, x21, [sp], #0x20                      
02cb7314: ret                                                
02cb7318: bl      #0x2b7105c                                 fn_2b7105c
#### CLASS CommentHandler parent= UnityEngine.MonoBehaviour
#   field IsEnableToSpawnComment         bool                                               off=0x20 attr=6 HeaderAttribute,SerializeField
#   field _distanceComment               float                                              off=0x24 attr=1 SerializeField
#   field _prefabComment                 UnityEngine.Transform                              off=0x28 attr=1 HeaderAttribute,SerializeField
#   field _prefabDonateComment           UnityEngine.Transform                              off=0x30 attr=1 SerializeField
#   field _commentParent                 UnityEngine.Transform                              off=0x38 attr=1 SerializeField
#   field _asset                         CommentAsset                                       off=0x40 attr=1 SerializeField
#   field _isRandomTimerComment          bool                                               off=0x48 attr=1 SerializeField
#   field _playSoundSpawn                bool                                               off=0x49 attr=1 SerializeField
#   field _viewerAvatarAsset             ViewerAvatarAsset                                  off=0x50 attr=1 SerializeField
#   field ls_comments                    System.Collections.Generic.List`1<CommentControl>  off=0x58 attr=1 
#   field _targetTime                    float                                              off=0x60 attr=1 
#   field _commentCount                  int                                                off=0x64 attr=1 
#   field _maxComment                    int                                                off=0x68 attr=1 
#   field CommentStringIdQueue           CustomQueue`1<CommentConfig>                       off=0x70 attr=6 
#   field _maxChatShowing                int                                                off=0x78 attr=1 SerializeField
#   field _latestAvatar                  UnityEngine.Sprite                                 off=0x80 attr=1 
## OnEnable() -> void
---- CommentHandler::OnEnable 0x2cb5a54
02cb5a54: str     x30, [sp, #-0x30]!                         
02cb5a58: stp     x22, x21, [sp, #0x10]                      
02cb5a5c: stp     x20, x19, [sp, #0x20]                      
02cb5a60: adrp    x21, #0x662f000                            
02cb5a64: adrp    x22, #0x6266000                            
02cb5a68: adrp    x20, #0x6266000                            
02cb5a6c: ldrb    w8, [x21, #0xbaa]                          
02cb5a70: ldr     x22, [x22, #0xcd8]                         T:type54236(k15)
02cb5a74: ldr     x20, [x20, #0xce0]                         MS:CustomQueue`1::.ctor
02cb5a78: mov     x19, x0                                    
02cb5a7c: tbnz    w8, #0, #0x2cb5aac                         
02cb5a80: adrp    x0, #0x6266000                             
02cb5a84: ldr     x0, [x0, #0xce8]                           MS:CustomQueue`1::Clear
02cb5a88: bl      #0x2b70db0                                 fn_2b70db0
02cb5a8c: adrp    x0, #0x6266000                             
02cb5a90: ldr     x0, [x0, #0xce0]                           MS:CustomQueue`1::.ctor
02cb5a94: bl      #0x2b70db0                                 fn_2b70db0
02cb5a98: adrp    x0, #0x6266000                             
02cb5a9c: ldr     x0, [x0, #0xcd8]                           T:type54236(k15)
02cb5aa0: bl      #0x2b70db0                                 fn_2b70db0
02cb5aa4: mov     w8, #1                                     
02cb5aa8: strb    w8, [x21, #0xbaa]                          
02cb5aac: ldr     x0, [x22]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cb5ab0: bl      #0x2b7104c                                 fn_2b7104c
02cb5ab4: ldr     x1, [x20]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cb5ab8: mov     x20, x0                                    
02cb5abc: bl      #0x442c9fc                                 fn_442c9fc
02cb5ac0: str     x20, [x19, #0x70]!                         .CommentStringIdQueue
02cb5ac4: mov     x0, x19                                    
02cb5ac8: mov     x1, x20                                    
02cb5acc: bl      #0x2b70d54                                 fn_2b70d54
02cb5ad0: ldr     x0, [x19]                                  
02cb5ad4: cbz     x0, #0x2cb5af4                             
02cb5ad8: adrp    x8, #0x6266000                             
02cb5adc: ldr     x8, [x8, #0xce8]                           MS:CustomQueue`1::Clear
02cb5ae0: ldp     x20, x19, [sp, #0x20]                      
02cb5ae4: ldp     x22, x21, [sp, #0x10]                      
02cb5ae8: ldr     x1, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cb5aec: ldr     x30, [sp], #0x30                           
02cb5af0: b       #0x442c9c4                                 
02cb5af4: bl      #0x2b7105c                                 fn_2b7105c
## Update() -> void
---- CommentHandler::Update 0x2cb5af8
02cb5af8: str     d8, [sp, #-0x30]!                          
02cb5afc: stp     x30, x21, [sp, #0x10]                      
02cb5b00: stp     x20, x19, [sp, #0x20]                      
02cb5b04: adrp    x20, #0x662f000                            
02cb5b08: mov     x19, x0                                    
02cb5b0c: ldrb    w8, [x20, #0xbab]                          
02cb5b10: tbnz    w8, #0, #0x2cb5b40                         
02cb5b14: adrp    x0, #0x6266000                             
02cb5b18: ldr     x0, [x0, #0xcf0]                           T:CommentConfig
02cb5b1c: bl      #0x2b70db0                                 fn_2b70db0
02cb5b20: adrp    x0, #0x6266000                             
02cb5b24: ldr     x0, [x0, #0xcf8]                           MS:CustomQueue`1::Enqueue
02cb5b28: bl      #0x2b70db0                                 fn_2b70db0
02cb5b2c: adrp    x0, #0x6266000                             
02cb5b30: ldr     x0, [x0, #0x5e0]                           T:GameConfig
02cb5b34: bl      #0x2b70db0                                 fn_2b70db0
02cb5b38: mov     w8, #1                                     
02cb5b3c: strb    w8, [x20, #0xbab]                          
02cb5b40: ldrb    w8, [x19, #0x20]                           .IsEnableToSpawnComment
02cb5b44: cbz     w8, #0x2cb5ba4                             
02cb5b48: mov     x0, xzr                                    
02cb5b4c: bl      #0x5b432fc                                 UnityEngine.Time::get_time
02cb5b50: ldr     s1, [x19, #0x60]                           ._targetTime
02cb5b54: fcmp    s0, s1                                     
02cb5b58: b.le    #0x2cb5ba4                                 
02cb5b5c: ldrb    w21, [x19, #0x48]                          ._isRandomTimerComment
02cb5b60: mov     x0, xzr                                    
02cb5b64: bl      #0x5b432fc                                 UnityEngine.Time::get_time
02cb5b68: adrp    x20, #0x6266000                            
02cb5b6c: fmov    s8, s0                                     
02cb5b70: ldr     x20, [x20, #0x5e0]                         T:GameConfig
02cb5b74: ldr     x0, [x20]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cb5b78: ldr     w8, [x0, #0xe4]                            [62660e4]=0 f=0,0
02cb5b7c: cbz     w21, #0x2cb5bb4                            
02cb5b80: cbnz    w8, #0x2cb5b8c                             
02cb5b84: bl      #0x2b70f30                                 fn_2b70f30
02cb5b88: ldr     x0, [x20]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cb5b8c: ldr     x8, [x0, #0xb8]                            S:'banner_native_refresh_time'
02cb5b90: mov     x0, xzr                                    
02cb5b94: ldr     s0, [x8, #0x38]                            
02cb5b98: fadd    s1, s0, s0                                 
02cb5b9c: bl      #0x5b2dfc0                                 UnityEngine.Random::Range
02cb5ba0: b       #0x2cb5bc8                                 
02cb5ba4: ldp     x20, x19, [sp, #0x20]                      
02cb5ba8: ldp     x30, x21, [sp, #0x10]                      
02cb5bac: ldr     d8, [sp], #0x30                            
02cb5bb0: ret                                                
02cb5bb4: cbnz    w8, #0x2cb5bc0                             
02cb5bb8: bl      #0x2b70f30                                 fn_2b70f30
02cb5bbc: ldr     x0, [x20]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cb5bc0: ldr     x8, [x0, #0xb8]                            S:'banner_native_refresh_time'
02cb5bc4: ldr     s0, [x8, #0x38]                            
02cb5bc8: fadd    s0, s8, s0                                 
02cb5bcc: mov     x0, x19                                    
02cb5bd0: str     s0, [x19, #0x60]                           ._targetTime
02cb5bd4: bl      #0x2cb5c50                                 CommentHandler::SpawnCommentLive
02cb5bd8: adrp    x8, #0x6266000                             
02cb5bdc: ldr     x8, [x8, #0xcf0]                           T:CommentConfig
02cb5be0: ldr     x20, [x19, #0x70]                          .CommentStringIdQueue
02cb5be4: ldr     x0, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cb5be8: bl      #0x2b7104c                                 fn_2b7104c
02cb5bec: mov     x1, xzr                                    
02cb5bf0: mov     x21, x0                                    
02cb5bf4: bl      #0x4e53e9c                                 System.Object::.ctor
02cb5bf8: cbz     x21, #0x2cb5c4c                            
02cb5bfc: ldr     x0, [x19, #0x40]                           ._asset
02cb5c00: mov     w8, #1                                     
02cb5c04: strb    w8, [x21, #0x10]                           
02cb5c08: cbz     x0, #0x2cb5c4c                             
02cb5c0c: str     xzr, [x21, #0x18]                          
02cb5c10: bl      #0x2cb4cd0                                 CommentAsset::PickRandomLiveComment
02cb5c14: mov     x1, x0                                     
02cb5c18: mov     x0, x21                                    
02cb5c1c: str     x1, [x0, #0x20]!                           .IsEnableToSpawnComment
02cb5c20: bl      #0x2b70d54                                 fn_2b70d54
02cb5c24: cbz     x20, #0x2cb5c4c                            
02cb5c28: adrp    x8, #0x6266000                             
02cb5c2c: mov     x0, x20                                    
02cb5c30: mov     x1, x21                                    
02cb5c34: ldr     x8, [x8, #0xcf8]                           MS:CustomQueue`1::Enqueue
02cb5c38: ldp     x20, x19, [sp, #0x20]                      
02cb5c3c: ldp     x30, x21, [sp, #0x10]                      
02cb5c40: ldr     x2, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cb5c44: ldr     d8, [sp], #0x30                            
02cb5c48: b       #0x442c888                                 
02cb5c4c: bl      #0x2b7105c                                 fn_2b7105c
## Refresh() -> void
---- CommentHandler::Refresh 0x2cb5d1c
02cb5d1c: str     wzr, [x0, #0x64]                           ._commentCount
02cb5d20: ret                                                
## ClearComment() -> void
---- CommentHandler::ClearComment 0x2cb5d24
02cb5d24: ret                                                
## SpawnCommentLive() -> void
---- CommentHandler::SpawnCommentLive 0x2cb5c50
02cb5c50: str     x30, [sp, #-0x20]!                         
02cb5c54: stp     x20, x19, [sp, #0x10]                      
02cb5c58: adrp    x20, #0x662f000                            
02cb5c5c: mov     x19, x0                                    
02cb5c60: ldrb    w8, [x20, #0xbac]                          
02cb5c64: tbnz    w8, #0, #0x2cb5c88                         
02cb5c68: adrp    x0, #0x6266000                             
02cb5c6c: ldr     x0, [x0, #0xd00]                           MS:CustomQueue`1::Dequeue
02cb5c70: bl      #0x2b70db0                                 fn_2b70db0
02cb5c74: adrp    x0, #0x6266000                             
02cb5c78: ldr     x0, [x0, #0xd08]                           MS:CustomQueue`1::get_Count
02cb5c7c: bl      #0x2b70db0                                 fn_2b70db0
02cb5c80: mov     w8, #1                                     
02cb5c84: strb    w8, [x20, #0xbac]                          
02cb5c88: ldr     x0, [x19, #0x70]                           .CommentStringIdQueue
02cb5c8c: cbz     x0, #0x2cb5d18                             
02cb5c90: adrp    x8, #0x6266000                             
02cb5c94: ldr     x8, [x8, #0xd08]                           MS:CustomQueue`1::get_Count
02cb5c98: ldr     x1, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cb5c9c: bl      #0x442c9e4                                 fn_442c9e4
02cb5ca0: cbz     w0, #0x2cb5d0c                             
02cb5ca4: ldrb    w8, [x19, #0x49]                           ._playSoundSpawn
02cb5ca8: cbz     w8, #0x2cb5cd8                             
02cb5cac: mov     x0, xzr                                    
02cb5cb0: bl      #0x2d6eec8                                 Framework.AudioManager::get_Instance
02cb5cb4: cbz     x0, #0x2cb5d18                             
02cb5cb8: movi    d1, #0000000000000000                      
02cb5cbc: movi    d2, #0000000000000000                      
02cb5cc0: mov     w1, #2                                     
02cb5cc4: fmov    s0, #0.50000000                            
02cb5cc8: mov     w2, wzr                                    
02cb5ccc: mov     w3, wzr                                    
02cb5cd0: mov     x4, xzr                                    
02cb5cd4: bl      #0x2d6f03c                                 Framework.AudioManager::PlaySound
02cb5cd8: ldr     x0, [x19, #0x70]                           .CommentStringIdQueue
02cb5cdc: cbz     x0, #0x2cb5d18                             
02cb5ce0: adrp    x8, #0x6266000                             
02cb5ce4: ldr     x8, [x8, #0xd00]                           MS:CustomQueue`1::Dequeue
02cb5ce8: ldr     x1, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cb5cec: bl      #0x442c8c8                                 fn_442c8c8
02cb5cf0: cbz     x0, #0x2cb5d18                             
02cb5cf4: ldr     x1, [x0, #0x20]                            S:'inter_ad_capping_time' .IsEnableToSpawnComment
02cb5cf8: ldrb    w2, [x0, #0x10]                            
02cb5cfc: mov     x0, x19                                    
02cb5d00: ldp     x20, x19, [sp, #0x10]                      
02cb5d04: ldr     x30, [sp], #0x20                           
02cb5d08: b       #0x2cb5d28                                 CommentHandler::Comment
02cb5d0c: ldp     x20, x19, [sp, #0x10]                      
02cb5d10: ldr     x30, [sp], #0x20                           
02cb5d14: ret                                                
02cb5d18: bl      #0x2b7105c                                 fn_2b7105c
## SpawnCommentLive(long localizeStringID, UnityEngine.Sprite sprite, UnityEngine.Transform commentParent, float scaleCmt) -> void
---- CommentHandler::SpawnCommentLive 0x2cb61a4
02cb61a4: str     d12, [sp, #-0x70]!                         
02cb61a8: stp     d11, d10, [sp, #0x10]                      
02cb61ac: stp     d9, d8, [sp, #0x20]                        
02cb61b0: stp     x30, x25, [sp, #0x30]                      
02cb61b4: stp     x24, x23, [sp, #0x40]                      
02cb61b8: stp     x22, x21, [sp, #0x50]                      
02cb61bc: stp     x20, x19, [sp, #0x60]                      
02cb61c0: fmov    s8, s0                                     
02cb61c4: adrp    x19, #0x662f000                            
02cb61c8: adrp    x24, #0x6266000                            
02cb61cc: adrp    x23, #0x6266000                            
02cb61d0: ldrb    w8, [x19, #0xbad]                          
02cb61d4: ldr     x24, [x24, #0xd38]                         T:CommentHandler/<>c__DisplayClass19_0
02cb61d8: ldr     x23, [x23, #0xd20]                         MS:MonoSingleton`1::get_Instance
02cb61dc: mov     x21, x3                                    
02cb61e0: mov     x20, x2                                    
02cb61e4: mov     x22, x0                                    
02cb61e8: tbnz    w8, #0, #0x2cb6260                         
02cb61ec: adrp    x0, #0x6266000                             
02cb61f0: ldr     x0, [x0, #0xd18]                           MS:UnityEngine.Component::GetComponent
02cb61f4: bl      #0x2b70db0                                 fn_2b70db0
02cb61f8: adrp    x0, #0x6264000                             
02cb61fc: ldr     x0, [x0, #0xd88]                           MS:UnityEngine.Component::GetComponent
02cb6200: bl      #0x2b70db0                                 fn_2b70db0
02cb6204: adrp    x0, #0x6266000                             
02cb6208: ldr     x0, [x0, #0xd20]                           MS:MonoSingleton`1::get_Instance
02cb620c: bl      #0x2b70db0                                 fn_2b70db0
02cb6210: adrp    x0, #0x6263000                             
02cb6214: ldr     x0, [x0, #0x918]                           T:UnityEngine.Object
02cb6218: bl      #0x2b70db0                                 fn_2b70db0
02cb621c: adrp    x0, #0x6264000                             
02cb6220: ldr     x0, [x0, #0xe8]                            T:DG.Tweening.TweenCallback
02cb6224: bl      #0x2b70db0                                 fn_2b70db0
02cb6228: adrp    x0, #0x6266000                             
02cb622c: ldr     x0, [x0, #0xa08]                           MS:DG.Tweening.TweenSettingsExtensions::OnComplete
02cb6230: bl      #0x2b70db0                                 fn_2b70db0
02cb6234: adrp    x0, #0x6266000                             
02cb6238: ldr     x0, [x0, #0xa18]                           MS:DG.Tweening.TweenSettingsExtensions::SetEase
02cb623c: bl      #0x2b70db0                                 fn_2b70db0
02cb6240: adrp    x0, #0x6266000                             
02cb6244: ldr     x0, [x0, #0xd40]                           M:CommentHandler/<>c__DisplayClass19_0::<SpawnCommentLive>b__0
02cb6248: bl      #0x2b70db0                                 fn_2b70db0
02cb624c: adrp    x0, #0x6266000                             
02cb6250: ldr     x0, [x0, #0xd38]                           T:CommentHandler/<>c__DisplayClass19_0
02cb6254: bl      #0x2b70db0                                 fn_2b70db0
02cb6258: mov     w8, #1                                     
02cb625c: strb    w8, [x19, #0xbad]                          
02cb6260: ldr     x0, [x24]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cb6264: bl      #0x2b7104c                                 fn_2b7104c
02cb6268: mov     x1, xzr                                    
02cb626c: mov     x19, x0                                    
02cb6270: bl      #0x4e53e9c                                 System.Object::.ctor
02cb6274: ldr     x0, [x23]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cb6278: ldr     s9, [x22, #0x24]                           
02cb627c: bl      #0x3769600                                 fn_3769600
02cb6280: adrp    x24, #0x662f000                            
02cb6284: ldr     x22, [x22, #0x28]                          
02cb6288: mov     x23, x0                                    
02cb628c: ldrb    w8, [x24, #0x91a]                          
02cb6290: cbnz    w8, #0x2cb62a8                             
02cb6294: adrp    x0, #0x6264000                             
02cb6298: ldr     x0, [x0, #0xd8]                            T:UnityEngine.Vector3
02cb629c: bl      #0x2b70db0                                 fn_2b70db0
02cb62a0: mov     w8, #1                                     
02cb62a4: strb    w8, [x24, #0x91a]                          
02cb62a8: adrp    x24, #0x6264000                            
02cb62ac: adrp    x25, #0x662f000                            
02cb62b0: ldr     x24, [x24, #0xd8]                          T:UnityEngine.Vector3
02cb62b4: ldrb    w9, [x25, #0xbdf]                          
02cb62b8: ldr     x8, [x24]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02cb62bc: ldr     x8, [x8, #0xb8]                            
02cb62c0: ldp     s10, s11, [x8]                             
02cb62c4: ldr     s12, [x8, #8]                              
02cb62c8: cbnz    w9, #0x2cb62e0                             
02cb62cc: adrp    x0, #0x6266000                             
02cb62d0: ldr     x0, [x0, #0xd30]                           T:UnityEngine.Quaternion
02cb62d4: bl      #0x2b70db0                                 fn_2b70db0
02cb62d8: mov     w8, #1                                     
02cb62dc: strb    w8, [x25, #0xbdf]                          
02cb62e0: cbz     x23, #0x2cb64fc                            
02cb62e4: adrp    x8, #0x6266000                             
02cb62e8: fmov    s0, s10                                    
02cb62ec: fmov    s1, s11                                    
02cb62f0: ldr     x8, [x8, #0xd30]                           T:UnityEngine.Quaternion
02cb62f4: fmov    s2, s12                                    
02cb62f8: mov     x0, x23                                    
02cb62fc: mov     x1, x22                                    
02cb6300: mov     x2, x21                                    
02cb6304: mov     x3, xzr                                    
02cb6308: ldr     x8, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cb630c: ldr     x8, [x8, #0xb8]                            S:'banner_native_refresh_time'
02cb6310: ldp     s5, s6, [x8, #8]                           
02cb6314: ldp     s3, s4, [x8]                               
02cb6318: bl      #0x2cd69bc                                 PoolManager::SpawnObject
02cb631c: cbz     x0, #0x2cb64fc                             
02cb6320: adrp    x8, #0x6266000                             
02cb6324: ldr     x8, [x8, #0xd18]                           MS:UnityEngine.Component::GetComponent
02cb6328: ldr     x1, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cb632c: bl      #0x3140c84                                 fn_3140c84
02cb6330: cbz     x19, #0x2cb64fc                            
02cb6334: mov     x21, x19                                   
02cb6338: mov     x1, x0                                     
02cb633c: str     x0, [x21, #0x10]!                          
02cb6340: mov     x0, x21                                    
02cb6344: bl      #0x2b70d54                                 fn_2b70d54
02cb6348: ldr     x0, [x21]                                  
02cb634c: cbz     x0, #0x2cb64fc                             
02cb6350: mov     x1, x20                                    
02cb6354: bl      #0x2cb4f64                                 CommentControl::Init
02cb6358: ldr     x0, [x21]                                  
02cb635c: cbz     x0, #0x2cb64fc                             
02cb6360: bl      #0x2cb54f8                                 CommentControl::Appear
02cb6364: ldr     x0, [x21]                                  
02cb6368: cbz     x0, #0x2cb64fc                             
02cb636c: bl      #0x2cb5360                                 CommentControl::SetLocalizeString
02cb6370: ldr     x0, [x21]                                  
02cb6374: cbz     x0, #0x2cb64fc                             
02cb6378: mov     w1, #1                                     
02cb637c: bl      #0x2cb5330                                 CommentControl::SetLayoutType
02cb6380: ldr     x0, [x21]                                  
02cb6384: cbz     x0, #0x2cb64fc                             
02cb6388: adrp    x8, #0x6264000                             
02cb638c: adrp    x20, #0x6263000                            
02cb6390: ldr     x8, [x8, #0xd88]                           MS:UnityEngine.Component::GetComponent
02cb6394: ldr     x20, [x20, #0x918]                         T:UnityEngine.Object
02cb6398: ldr     x1, [x8]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02cb639c: bl      #0x3140c84                                 fn_3140c84
02cb63a0: ldr     x8, [x20]                                  &2c5bbd4(=a9bd7bfdd503233f)
02cb63a4: mov     x20, x0                                    
02cb63a8: ldr     w9, [x8, #0xe4]                            [62640e4]=0 f=0,0
02cb63ac: cbnz    w9, #0x2cb63b8                             
02cb63b0: mov     x0, x8                                     
02cb63b4: bl      #0x2b70f30                                 fn_2b70f30
02cb63b8: mov     x0, x20                                    
02cb63bc: mov     x1, xzr                                    
02cb63c0: mov     x2, xzr                                    
02cb63c4: bl      #0x5b37d84                                 UnityEngine.Object::op_Equality
02cb63c8: tbz     w0, #0, #0x2cb63ec                         
02cb63cc: ldp     x20, x19, [sp, #0x60]                      
02cb63d0: ldp     x22, x21, [sp, #0x50]                      
02cb63d4: ldp     x24, x23, [sp, #0x40]                      
02cb63d8: ldp     x30, x25, [sp, #0x30]                      
02cb63dc: ldp     d9, d8, [sp, #0x20]                        
02cb63e0: ldp     d11, d10, [sp, #0x10]                      
02cb63e4: ldr     d12, [sp], #0x70                           
02cb63e8: ret                                                
02cb63ec: mov     x0, x20                                    
02cb63f0: mov     w1, wzr                                    
02cb63f4: mov     x2, xzr                                    
02cb63f8: bl      #0x2d9d5d0                                 DG.Tweening.ShortcutExtensions::DOKill
02cb63fc: adrp    x21, #0x662f000                            
02cb6400: ldrb    w8, [x21, #0xa74]                          
02cb6404: cbnz    w8, #0x2cb641c                             
02cb6408: adrp    x0, #0x6264000                             
02cb640c: ldr     x0, [x0, #0xd8]                            T:UnityEngine.Vector3
02cb6410: bl      #0x2b70db0                                 fn_2b70db0
02cb6414: mov     w8, #1                                     
02cb6418: strb    w8, [x21, #0xa74]                          
02cb641c: cbz     x20, #0x2cb64fc                            
02cb6420: ldr     x8, [x24]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02cb6424: mov     x0, x20                                    
02cb6428: mov     x1, xzr                                    
02cb642c: ldr     x8, [x8, #0xb8]                            MS:DG.Tweening.Core.Extensions::SetSpecialStartupMode
02cb6430: ldp     s1, s0, [x8, #0x10]                        
02cb6434: ldr     s3, [x8, #0xc]                             [626400c]=0 f=0,0
02cb6438: fmul    s2, s0, s8                                 
02cb643c: fmul    s1, s1, s8                                 
02cb6440: fmul    s0, s3, s8                                 
02cb6444: bl      #0x5b470cc                                 UnityEngine.Transform::set_localScale
02cb6448: movi    d2, #0000000000000000                      
02cb644c: mov     w8, #0x42700000                            
02cb6450: fmov    s1, s9                                     
02cb6454: fmov    s0, w8                                     
02cb6458: mov     x0, x20                                    
02cb645c: mov     x1, xzr                                    
02cb6460: bl      #0x5b45cec                                 UnityEngine.Transform::set_localPosition
02cb6464: mov     w8, #0x447a0000                            
02cb6468: fmov    s1, #6.00000000                            
02cb646c: mov     x0, x20                                    
02cb6470: fmov    s0, w8                                     
02cb6474: mov     w1, wzr                                    
02cb6478: mov     x2, xzr                                    
02cb647c: bl      #0x2c79c1c                                 DG.Tweening.DOTweenModuleUI::DOAnchorPosY
02cb6480: adrp    x8, #0x6266000                             
02cb6484: mov     w1, #1                                     
02cb6488: ldr     x8, [x8, #0xa18]                           MS:DG.Tweening.TweenSettingsExtensions::SetEase
02cb648c: ldr     x2, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cb6490: bl      #0x336fa0c                                 fn_336fa0c
02cb6494: adrp    x8, #0x6264000                             
02cb6498: mov     x20, x0                                    
02cb649c: ldr     x8, [x8, #0xe8]                            T:DG.Tweening.TweenCallback
02cb64a0: ldr     x8, [x8]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02cb64a4: mov     x0, x8                                     
02cb64a8: bl      #0x2b7104c                                 fn_2b7104c
02cb64ac: adrp    x8, #0x6266000                             
02cb64b0: mov     x1, x19                                    
02cb64b4: mov     x3, xzr                                    
02cb64b8: ldr     x8, [x8, #0xd40]                           M:CommentHandler/<>c__DisplayClass19_0::<SpawnCommentLive>b__0
02cb64bc: mov     x21, x0                                    
02cb64c0: ldr     x2, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cb64c4: bl      #0x2d89dc4                                 DG.Tweening.TweenCallback::.ctor
02cb64c8: adrp    x8, #0x6266000                             
02cb64cc: mov     x0, x20                                    
02cb64d0: mov     x1, x21                                    
02cb64d4: ldr     x8, [x8, #0xa08]                           MS:DG.Tweening.TweenSettingsExtensions::OnComplete
02cb64d8: ldp     x20, x19, [sp, #0x60]                      
02cb64dc: ldp     x22, x21, [sp, #0x50]                      
02cb64e0: ldp     x24, x23, [sp, #0x40]                      
02cb64e4: ldr     x2, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cb64e8: ldp     x30, x25, [sp, #0x30]                      
02cb64ec: ldp     d9, d8, [sp, #0x20]                        
02cb64f0: ldp     d11, d10, [sp, #0x10]                      
02cb64f4: ldr     d12, [sp], #0x70                           
02cb64f8: b       #0x336f26c                                 
02cb64fc: bl      #0x2b7105c                                 fn_2b7105c
## SpawnDonateComment(UnityEngine.Sprite sprite, float scaleCmt) -> void
---- CommentHandler::SpawnDonateComment 0x2cb6508
02cb6508: str     d12, [sp, #-0x70]!                         
02cb650c: stp     d11, d10, [sp, #0x10]                      
02cb6510: stp     d9, d8, [sp, #0x20]                        
02cb6514: stp     x30, x25, [sp, #0x30]                      
02cb6518: stp     x24, x23, [sp, #0x40]                      
02cb651c: stp     x22, x21, [sp, #0x50]                      
02cb6520: stp     x20, x19, [sp, #0x60]                      
02cb6524: fmov    s8, s0                                     
02cb6528: adrp    x19, #0x662f000                            
02cb652c: adrp    x23, #0x6266000                            
02cb6530: adrp    x22, #0x6266000                            
02cb6534: ldrb    w8, [x19, #0xbae]                          
02cb6538: ldr     x23, [x23, #0xd48]                         T:CommentHandler/<>c__DisplayClass20_0
02cb653c: ldr     x22, [x22, #0xd20]                         MS:MonoSingleton`1::get_Instance
02cb6540: mov     x20, x1                                    
02cb6544: mov     x21, x0                                    
02cb6548: tbnz    w8, #0, #0x2cb65c0                         
02cb654c: adrp    x0, #0x6266000                             
02cb6550: ldr     x0, [x0, #0xd18]                           MS:UnityEngine.Component::GetComponent
02cb6554: bl      #0x2b70db0                                 fn_2b70db0
02cb6558: adrp    x0, #0x6264000                             
02cb655c: ldr     x0, [x0, #0xd88]                           MS:UnityEngine.Component::GetComponent
02cb6560: bl      #0x2b70db0                                 fn_2b70db0
02cb6564: adrp    x0, #0x6266000                             
02cb6568: ldr     x0, [x0, #0xd20]                           MS:MonoSingleton`1::get_Instance
02cb656c: bl      #0x2b70db0                                 fn_2b70db0
02cb6570: adrp    x0, #0x6263000                             
02cb6574: ldr     x0, [x0, #0x918]                           T:UnityEngine.Object
02cb6578: bl      #0x2b70db0                                 fn_2b70db0
02cb657c: adrp    x0, #0x6264000                             
02cb6580: ldr     x0, [x0, #0xe8]                            T:DG.Tweening.TweenCallback
02cb6584: bl      #0x2b70db0                                 fn_2b70db0
02cb6588: adrp    x0, #0x6266000                             
02cb658c: ldr     x0, [x0, #0xa08]                           MS:DG.Tweening.TweenSettingsExtensions::OnComplete
02cb6590: bl      #0x2b70db0                                 fn_2b70db0
02cb6594: adrp    x0, #0x6266000                             
02cb6598: ldr     x0, [x0, #0xa18]                           MS:DG.Tweening.TweenSettingsExtensions::SetEase
02cb659c: bl      #0x2b70db0                                 fn_2b70db0
02cb65a0: adrp    x0, #0x6266000                             
02cb65a4: ldr     x0, [x0, #0xd50]                           M:CommentHandler/<>c__DisplayClass20_0::<SpawnDonateComment>b__0
02cb65a8: bl      #0x2b70db0                                 fn_2b70db0
02cb65ac: adrp    x0, #0x6266000                             
02cb65b0: ldr     x0, [x0, #0xd48]                           T:CommentHandler/<>c__DisplayClass20_0
02cb65b4: bl      #0x2b70db0                                 fn_2b70db0
02cb65b8: mov     w8, #1                                     
02cb65bc: strb    w8, [x19, #0xbae]                          
02cb65c0: ldr     x0, [x23]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cb65c4: bl      #0x2b7104c                                 fn_2b7104c
02cb65c8: mov     x1, xzr                                    
02cb65cc: mov     x19, x0                                    
02cb65d0: bl      #0x4e53e9c                                 System.Object::.ctor
02cb65d4: ldr     x0, [x22]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cb65d8: ldr     s9, [x21, #0x24]                           ._distanceComment
02cb65dc: bl      #0x3769600                                 fn_3769600
02cb65e0: adrp    x24, #0x662f000                            
02cb65e4: ldr     x22, [x21, #0x30]                          ._prefabDonateComment
02cb65e8: mov     x23, x0                                    
02cb65ec: ldrb    w8, [x24, #0x91a]                          
02cb65f0: cbnz    w8, #0x2cb6608                             
02cb65f4: adrp    x0, #0x6264000                             
02cb65f8: ldr     x0, [x0, #0xd8]                            T:UnityEngine.Vector3
02cb65fc: bl      #0x2b70db0                                 fn_2b70db0
02cb6600: mov     w8, #1                                     
02cb6604: strb    w8, [x24, #0x91a]                          
02cb6608: adrp    x24, #0x6264000                            
02cb660c: adrp    x25, #0x662f000                            
02cb6610: ldr     x24, [x24, #0xd8]                          T:UnityEngine.Vector3
02cb6614: ldrb    w9, [x25, #0xbdf]                          
02cb6618: ldr     x8, [x24]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02cb661c: ldr     x8, [x8, #0xb8]                            
02cb6620: ldp     s10, s11, [x8]                             
02cb6624: ldr     s12, [x8, #8]                              
02cb6628: cbnz    w9, #0x2cb6640                             
02cb662c: adrp    x0, #0x6266000                             
02cb6630: ldr     x0, [x0, #0xd30]                           T:UnityEngine.Quaternion
02cb6634: bl      #0x2b70db0                                 fn_2b70db0
02cb6638: mov     w8, #1                                     
02cb663c: strb    w8, [x25, #0xbdf]                          
02cb6640: cbz     x23, #0x2cb6840                            
02cb6644: adrp    x8, #0x6266000                             
02cb6648: fmov    s0, s10                                    
02cb664c: fmov    s1, s11                                    
02cb6650: ldr     x8, [x8, #0xd30]                           T:UnityEngine.Quaternion
02cb6654: fmov    s2, s12                                    
02cb6658: ldr     x2, [x21, #0x38]                           ._commentParent
02cb665c: mov     x0, x23                                    
02cb6660: mov     x1, x22                                    
02cb6664: mov     x3, xzr                                    
02cb6668: ldr     x8, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cb666c: ldr     x8, [x8, #0xb8]                            S:'banner_native_refresh_time'
02cb6670: ldp     s5, s6, [x8, #8]                           
02cb6674: ldp     s3, s4, [x8]                               
02cb6678: bl      #0x2cd69bc                                 PoolManager::SpawnObject
02cb667c: cbz     x0, #0x2cb6840                             
02cb6680: adrp    x8, #0x6266000                             
02cb6684: ldr     x8, [x8, #0xd18]                           MS:UnityEngine.Component::GetComponent
02cb6688: ldr     x1, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cb668c: bl      #0x3140c84                                 fn_3140c84
02cb6690: cbz     x19, #0x2cb6840                            
02cb6694: mov     x21, x19                                   
02cb6698: mov     x1, x0                                     
02cb669c: str     x0, [x21, #0x10]!                          
02cb66a0: mov     x0, x21                                    
02cb66a4: bl      #0x2b70d54                                 fn_2b70d54
02cb66a8: ldr     x0, [x21]                                  
02cb66ac: cbz     x0, #0x2cb6840                             
02cb66b0: mov     x1, x20                                    
02cb66b4: bl      #0x2cb4f64                                 CommentControl::Init
02cb66b8: ldr     x0, [x21]                                  
02cb66bc: cbz     x0, #0x2cb6840                             
02cb66c0: bl      #0x2cb54f8                                 CommentControl::Appear
02cb66c4: ldr     x0, [x21]                                  
02cb66c8: cbz     x0, #0x2cb6840                             
02cb66cc: adrp    x8, #0x6264000                             
02cb66d0: adrp    x20, #0x6263000                            
02cb66d4: ldr     x8, [x8, #0xd88]                           MS:UnityEngine.Component::GetComponent
02cb66d8: ldr     x20, [x20, #0x918]                         T:UnityEngine.Object
02cb66dc: ldr     x1, [x8]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02cb66e0: bl      #0x3140c84                                 fn_3140c84
02cb66e4: ldr     x8, [x20]                                  &2c5bbd4(=a9bd7bfdd503233f)
02cb66e8: mov     x20, x0                                    
02cb66ec: ldr     w9, [x8, #0xe4]                            [62640e4]=0 f=0,0
02cb66f0: cbnz    w9, #0x2cb66fc                             
02cb66f4: mov     x0, x8                                     
02cb66f8: bl      #0x2b70f30                                 fn_2b70f30
02cb66fc: mov     x0, x20                                    
02cb6700: mov     x1, xzr                                    
02cb6704: mov     x2, xzr                                    
02cb6708: bl      #0x5b37d84                                 UnityEngine.Object::op_Equality
02cb670c: tbz     w0, #0, #0x2cb6730                         
02cb6710: ldp     x20, x19, [sp, #0x60]                      
02cb6714: ldp     x22, x21, [sp, #0x50]                      
02cb6718: ldp     x24, x23, [sp, #0x40]                      
02cb671c: ldp     x30, x25, [sp, #0x30]                      
02cb6720: ldp     d9, d8, [sp, #0x20]                        
02cb6724: ldp     d11, d10, [sp, #0x10]                      
02cb6728: ldr     d12, [sp], #0x70                           
02cb672c: ret                                                
02cb6730: mov     x0, x20                                    
02cb6734: mov     w1, wzr                                    
02cb6738: mov     x2, xzr                                    
02cb673c: bl      #0x2d9d5d0                                 DG.Tweening.ShortcutExtensions::DOKill
02cb6740: adrp    x21, #0x662f000                            
02cb6744: ldrb    w8, [x21, #0xa74]                          
02cb6748: cbnz    w8, #0x2cb6760                             
02cb674c: adrp    x0, #0x6264000                             
02cb6750: ldr     x0, [x0, #0xd8]                            T:UnityEngine.Vector3
02cb6754: bl      #0x2b70db0                                 fn_2b70db0
02cb6758: mov     w8, #1                                     
02cb675c: strb    w8, [x21, #0xa74]                          
02cb6760: cbz     x20, #0x2cb6840                            
02cb6764: ldr     x8, [x24]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02cb6768: mov     x0, x20                                    
02cb676c: mov     x1, xzr                                    
02cb6770: ldr     x8, [x8, #0xb8]                            MS:DG.Tweening.Core.Extensions::SetSpecialStartupMode
02cb6774: ldp     s1, s0, [x8, #0x10]                        
02cb6778: ldr     s3, [x8, #0xc]                             [626400c]=0 f=0,0
02cb677c: fmul    s2, s0, s8                                 
02cb6780: fmul    s1, s1, s8                                 
02cb6784: fmul    s0, s3, s8                                 
02cb6788: bl      #0x5b470cc                                 UnityEngine.Transform::set_localScale
02cb678c: movi    d2, #0000000000000000                      
02cb6790: mov     w8, #0x42700000                            
02cb6794: fmov    s1, s9                                     
02cb6798: fmov    s0, w8                                     
02cb679c: mov     x0, x20                                    
02cb67a0: mov     x1, xzr                                    
02cb67a4: bl      #0x5b45cec                                 UnityEngine.Transform::set_localPosition
02cb67a8: mov     w8, #0x447a0000                            
02cb67ac: fmov    s1, #6.00000000                            
02cb67b0: mov     x0, x20                                    
02cb67b4: fmov    s0, w8                                     
02cb67b8: mov     w1, wzr                                    
02cb67bc: mov     x2, xzr                                    
02cb67c0: bl      #0x2c79c1c                                 DG.Tweening.DOTweenModuleUI::DOAnchorPosY
02cb67c4: adrp    x8, #0x6266000                             
02cb67c8: mov     w1, #1                                     
02cb67cc: ldr     x8, [x8, #0xa18]                           MS:DG.Tweening.TweenSettingsExtensions::SetEase
02cb67d0: ldr     x2, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cb67d4: bl      #0x336fa0c                                 fn_336fa0c
02cb67d8: adrp    x8, #0x6264000                             
02cb67dc: mov     x20, x0                                    
02cb67e0: ldr     x8, [x8, #0xe8]                            T:DG.Tweening.TweenCallback
02cb67e4: ldr     x8, [x8]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02cb67e8: mov     x0, x8                                     
02cb67ec: bl      #0x2b7104c                                 fn_2b7104c
02cb67f0: adrp    x8, #0x6266000                             
02cb67f4: mov     x1, x19                                    
02cb67f8: mov     x3, xzr                                    
02cb67fc: ldr     x8, [x8, #0xd50]                           M:CommentHandler/<>c__DisplayClass20_0::<SpawnDonateComment>b__0
02cb6800: mov     x21, x0                                    
02cb6804: ldr     x2, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cb6808: bl      #0x2d89dc4                                 DG.Tweening.TweenCallback::.ctor
02cb680c: adrp    x8, #0x6266000                             
02cb6810: mov     x0, x20                                    
02cb6814: mov     x1, x21                                    
02cb6818: ldr     x8, [x8, #0xa08]                           MS:DG.Tweening.TweenSettingsExtensions::OnComplete
02cb681c: ldp     x20, x19, [sp, #0x60]                      
02cb6820: ldp     x22, x21, [sp, #0x50]                      
02cb6824: ldp     x24, x23, [sp, #0x40]                      
02cb6828: ldr     x2, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cb682c: ldp     x30, x25, [sp, #0x30]                      
02cb6830: ldp     d9, d8, [sp, #0x20]                        
02cb6834: ldp     d11, d10, [sp, #0x10]                      
02cb6838: ldr     d12, [sp], #0x70                           
02cb683c: b       #0x336f26c                                 
02cb6840: bl      #0x2b7105c                                 fn_2b7105c
## StartComment() -> void
---- CommentHandler::StartComment 0x2cb684c
02cb684c: stp     d11, d10, [sp, #-0x60]!                    
02cb6850: stp     d9, d8, [sp, #0x10]                        
02cb6854: str     x30, [sp, #0x20]                           
02cb6858: stp     x24, x23, [sp, #0x30]                      
02cb685c: stp     x22, x21, [sp, #0x40]                      
02cb6860: stp     x20, x19, [sp, #0x50]                      
02cb6864: adrp    x20, #0x662f000                            
02cb6868: adrp    x21, #0x6266000                            
02cb686c: mov     x19, x0                                    
02cb6870: ldrb    w8, [x20, #0xbaf]                          
02cb6874: ldr     x21, [x21, #0xd58]                         T:CommentHandler/<>c__DisplayClass21_0
02cb6878: tbnz    w8, #0, #0x2cb6914                         
02cb687c: adrp    x0, #0x6266000                             
02cb6880: ldr     x0, [x0, #0xd18]                           MS:UnityEngine.Component::GetComponent
02cb6884: bl      #0x2b70db0                                 fn_2b70db0
02cb6888: adrp    x0, #0x6264000                             
02cb688c: ldr     x0, [x0, #0xd88]                           MS:UnityEngine.Component::GetComponent
02cb6890: bl      #0x2b70db0                                 fn_2b70db0
02cb6894: adrp    x0, #0x6266000                             
02cb6898: ldr     x0, [x0, #0x9f0]                           T:Assets.SimpleLocalization.Scripts.LocalizationManager
02cb689c: bl      #0x2b70db0                                 fn_2b70db0
02cb68a0: adrp    x0, #0x6266000                             
02cb68a4: ldr     x0, [x0, #0xac0]                           MS:MonoSingleton`1::get_Instance
02cb68a8: bl      #0x2b70db0                                 fn_2b70db0
02cb68ac: adrp    x0, #0x6266000                             
02cb68b0: ldr     x0, [x0, #0xd20]                           MS:MonoSingleton`1::get_Instance
02cb68b4: bl      #0x2b70db0                                 fn_2b70db0
02cb68b8: adrp    x0, #0x6263000                             
02cb68bc: ldr     x0, [x0, #0x918]                           T:UnityEngine.Object
02cb68c0: bl      #0x2b70db0                                 fn_2b70db0
02cb68c4: adrp    x0, #0x6264000                             
02cb68c8: ldr     x0, [x0, #0xe8]                            T:DG.Tweening.TweenCallback
02cb68cc: bl      #0x2b70db0                                 fn_2b70db0
02cb68d0: adrp    x0, #0x6266000                             
02cb68d4: ldr     x0, [x0, #0xa08]                           MS:DG.Tweening.TweenSettingsExtensions::OnComplete
02cb68d8: bl      #0x2b70db0                                 fn_2b70db0
02cb68dc: adrp    x0, #0x6266000                             
02cb68e0: ldr     x0, [x0, #0xa18]                           MS:DG.Tweening.TweenSettingsExtensions::SetEase
02cb68e4: bl      #0x2b70db0                                 fn_2b70db0
02cb68e8: adrp    x0, #0x6266000                             
02cb68ec: ldr     x0, [x0, #0xd60]                           M:CommentHandler/<>c__DisplayClass21_0::<StartComment>b__0
02cb68f0: bl      #0x2b70db0                                 fn_2b70db0
02cb68f4: adrp    x0, #0x6266000                             
02cb68f8: ldr     x0, [x0, #0xd58]                           T:CommentHandler/<>c__DisplayClass21_0
02cb68fc: bl      #0x2b70db0                                 fn_2b70db0
02cb6900: adrp    x0, #0x6266000                             
02cb6904: ldr     x0, [x0, #0xd68]                           S:'Welcome !'
02cb6908: bl      #0x2b70db0                                 fn_2b70db0
02cb690c: mov     w8, #1                                     
02cb6910: strb    w8, [x20, #0xbaf]                          
02cb6914: ldr     x0, [x21]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cb6918: bl      #0x2b7104c                                 fn_2b7104c
02cb691c: mov     x1, xzr                                    
02cb6920: mov     x20, x0                                    
02cb6924: bl      #0x4e53e9c                                 System.Object::.ctor
02cb6928: cbz     x20, #0x2cb6c4c                            
02cb692c: adrp    x21, #0x6266000                            
02cb6930: mov     x0, x20                                    
02cb6934: mov     x1, x19                                    
02cb6938: ldr     x21, [x21, #0xd20]                         MS:MonoSingleton`1::get_Instance
02cb693c: str     x19, [x0, #0x18]!                          
02cb6940: bl      #0x2b70d54                                 fn_2b70d54
02cb6944: ldr     x0, [x21]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cb6948: ldr     s8, [x19, #0x24]                           ._distanceComment
02cb694c: bl      #0x3769600                                 fn_3769600
02cb6950: adrp    x23, #0x662f000                            
02cb6954: ldr     x21, [x19, #0x28]                          ._prefabComment
02cb6958: mov     x22, x0                                    
02cb695c: ldrb    w8, [x23, #0x91a]                          
02cb6960: cbnz    w8, #0x2cb6978                             
02cb6964: adrp    x0, #0x6264000                             
02cb6968: ldr     x0, [x0, #0xd8]                            T:UnityEngine.Vector3
02cb696c: bl      #0x2b70db0                                 fn_2b70db0
02cb6970: mov     w8, #1                                     
02cb6974: strb    w8, [x23, #0x91a]                          
02cb6978: adrp    x23, #0x6264000                            
02cb697c: adrp    x24, #0x662f000                            
02cb6980: ldr     x23, [x23, #0xd8]                          T:UnityEngine.Vector3
02cb6984: ldrb    w9, [x24, #0xbdf]                          
02cb6988: ldr     x8, [x23]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02cb698c: ldr     x8, [x8, #0xb8]                            
02cb6990: ldp     s9, s10, [x8]                              
02cb6994: ldr     s11, [x8, #8]                              
02cb6998: cbnz    w9, #0x2cb69b0                             
02cb699c: adrp    x0, #0x6266000                             
02cb69a0: ldr     x0, [x0, #0xd30]                           T:UnityEngine.Quaternion
02cb69a4: bl      #0x2b70db0                                 fn_2b70db0
02cb69a8: mov     w8, #1                                     
02cb69ac: strb    w8, [x24, #0xbdf]                          
02cb69b0: cbz     x22, #0x2cb6c4c                            
02cb69b4: adrp    x8, #0x6266000                             
02cb69b8: fmov    s0, s9                                     
02cb69bc: fmov    s1, s10                                    
02cb69c0: ldr     x8, [x8, #0xd30]                           T:UnityEngine.Quaternion
02cb69c4: fmov    s2, s11                                    
02cb69c8: ldr     x2, [x19, #0x38]                           ._commentParent
02cb69cc: mov     x0, x22                                    
02cb69d0: mov     x1, x21                                    
02cb69d4: mov     x3, xzr                                    
02cb69d8: ldr     x8, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cb69dc: ldr     x8, [x8, #0xb8]                            S:'banner_native_refresh_time'
02cb69e0: ldp     s5, s6, [x8, #8]                           
02cb69e4: ldp     s3, s4, [x8]                               
02cb69e8: bl      #0x2cd69bc                                 PoolManager::SpawnObject
02cb69ec: cbz     x0, #0x2cb6c4c                             
02cb69f0: adrp    x8, #0x6266000                             
02cb69f4: ldr     x8, [x8, #0xd18]                           MS:UnityEngine.Component::GetComponent
02cb69f8: ldr     x1, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cb69fc: bl      #0x3140c84                                 fn_3140c84
02cb6a00: mov     x21, x20                                   
02cb6a04: mov     x1, x0                                     
02cb6a08: str     x0, [x21, #0x20]!                          .IsEnableToSpawnComment
02cb6a0c: mov     x0, x21                                    
02cb6a10: bl      #0x2b70d54                                 fn_2b70d54
02cb6a14: ldr     x0, [x21]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cb6a18: cbz     x0, #0x2cb6c4c                             
02cb6a1c: adrp    x22, #0x6266000                            
02cb6a20: adrp    x24, #0x6266000                            
02cb6a24: ldr     x22, [x22, #0x9f0]                         T:Assets.SimpleLocalization.Scripts.LocalizationManager
02cb6a28: ldr     x24, [x24, #0xd68]                         S:'Welcome !'
02cb6a2c: bl      #0x2cb54f8                                 CommentControl::Appear
02cb6a30: ldr     x0, [x22]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cb6a34: ldr     x22, [x21]                                 M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cb6a38: ldr     w8, [x0, #0xe4]                            [62660e4]=0 f=0,0
02cb6a3c: cbnz    w8, #0x2cb6a44                             
02cb6a40: bl      #0x2b70f30                                 fn_2b70f30
02cb6a44: ldr     x0, [x24]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cb6a48: mov     x1, xzr                                    
02cb6a4c: bl      #0x2d76794                                 Assets.SimpleLocalization.Scripts.LocalizationManager::Localize
02cb6a50: cbz     x22, #0x2cb6c4c                            
02cb6a54: adrp    x24, #0x6266000                            
02cb6a58: mov     x1, x0                                     
02cb6a5c: mov     x0, x22                                    
02cb6a60: ldr     x24, [x24, #0xac0]                         MS:MonoSingleton`1::get_Instance
02cb6a64: bl      #0x2cb529c                                 CommentControl::SetText
02cb6a68: ldr     x0, [x24]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cb6a6c: ldr     x22, [x21]                                 M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cb6a70: bl      #0x3769600                                 fn_3769600
02cb6a74: cbz     x0, #0x2cb6c4c                             
02cb6a78: cbz     x22, #0x2cb6c4c                            
02cb6a7c: ldr     x1, [x0, #0x38]                            S:'native_collap_id' ._commentParent
02cb6a80: mov     x0, x22                                    
02cb6a84: bl      #0x2cb4f64                                 CommentControl::Init
02cb6a88: ldr     x0, [x21]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cb6a8c: cbz     x0, #0x2cb6c4c                             
02cb6a90: mov     w1, wzr                                    
02cb6a94: bl      #0x2cb5330                                 CommentControl::SetLayoutType
02cb6a98: ldr     x0, [x21]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cb6a9c: cbz     x0, #0x2cb6c4c                             
02cb6aa0: adrp    x8, #0x6264000                             
02cb6aa4: adrp    x22, #0x6263000                            
02cb6aa8: ldr     x8, [x8, #0xd88]                           MS:UnityEngine.Component::GetComponent
02cb6aac: ldr     x22, [x22, #0x918]                         T:UnityEngine.Object
02cb6ab0: ldr     x1, [x8]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02cb6ab4: bl      #0x3140c84                                 fn_3140c84
02cb6ab8: mov     x21, x20                                   
02cb6abc: mov     x1, x0                                     
02cb6ac0: str     x0, [x21, #0x10]!                          
02cb6ac4: mov     x0, x21                                    
02cb6ac8: bl      #0x2b70d54                                 fn_2b70d54
02cb6acc: ldr     x0, [x22]                                  &2c5bbd4(=a9bd7bfdd503233f)
02cb6ad0: ldr     x22, [x21]                                 M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cb6ad4: ldr     w8, [x0, #0xe4]                            [62660e4]=0 f=0,0
02cb6ad8: cbnz    w8, #0x2cb6ae0                             
02cb6adc: bl      #0x2b70f30                                 fn_2b70f30
02cb6ae0: mov     x0, x22                                    
02cb6ae4: mov     x1, xzr                                    
02cb6ae8: mov     x2, xzr                                    
02cb6aec: bl      #0x5b37d84                                 UnityEngine.Object::op_Equality
02cb6af0: tbz     w0, #0, #0x2cb6b10                         
02cb6af4: ldp     x20, x19, [sp, #0x50]                      
02cb6af8: ldr     x30, [sp, #0x20]                           
02cb6afc: ldp     x22, x21, [sp, #0x40]                      
02cb6b00: ldp     x24, x23, [sp, #0x30]                      
02cb6b04: ldp     d9, d8, [sp, #0x10]                        
02cb6b08: ldp     d11, d10, [sp], #0x60                      
02cb6b0c: ret                                                
02cb6b10: ldr     x0, [x21]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cb6b14: mov     w1, wzr                                    
02cb6b18: mov     x2, xzr                                    
02cb6b1c: bl      #0x2d9d5d0                                 DG.Tweening.ShortcutExtensions::DOKill
02cb6b20: adrp    x24, #0x662f000                            
02cb6b24: ldr     x22, [x21]                                 M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cb6b28: ldrb    w8, [x24, #0xa74]                          
02cb6b2c: cbnz    w8, #0x2cb6b44                             
02cb6b30: adrp    x0, #0x6264000                             
02cb6b34: ldr     x0, [x0, #0xd8]                            T:UnityEngine.Vector3
02cb6b38: bl      #0x2b70db0                                 fn_2b70db0
02cb6b3c: mov     w8, #1                                     
02cb6b40: strb    w8, [x24, #0xa74]                          
02cb6b44: cbz     x22, #0x2cb6c4c                            
02cb6b48: ldr     x8, [x23]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02cb6b4c: mov     w9, #0x6666                                
02cb6b50: mov     x0, x22                                    
02cb6b54: movk    w9, #0x3fa6, lsl #16                       
02cb6b58: mov     x1, xzr                                    
02cb6b5c: ldr     x8, [x8, #0xb8]                            MS:DG.Tweening.Core.Extensions::SetSpecialStartupMode
02cb6b60: dup     v0.2s, w9                                  
02cb6b64: adrp    x9, #0x1084000                             
02cb6b68: ldr     s2, [x9, #0xf2c]                           [1084f2c]=3ca3d70a3fa66666 f=1.3,0.02
02cb6b6c: ldur    d1, [x8, #0xc]                             
02cb6b70: fmul    v0.2s, v1.2s, v0.2s                        
02cb6b74: ldr     s1, [x8, #0x14]                            [6264014]=0 f=0,0
02cb6b78: fmul    s2, s1, s2                                 
02cb6b7c: mov     s1, v0.s[1]                                
02cb6b80: bl      #0x5b470cc                                 UnityEngine.Transform::set_localScale
02cb6b84: ldr     x0, [x21]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cb6b88: cbz     x0, #0x2cb6c4c                             
02cb6b8c: movi    d2, #0000000000000000                      
02cb6b90: mov     w8, #0x42700000                            
02cb6b94: fmov    s1, s8                                     
02cb6b98: fmov    s0, w8                                     
02cb6b9c: mov     x1, xzr                                    
02cb6ba0: bl      #0x5b45cec                                 UnityEngine.Transform::set_localPosition
02cb6ba4: ldr     s0, [x19, #0x78]                           ._maxChatShowing
02cb6ba8: mov     w9, #0x42c80000                            
02cb6bac: adrp    x8, #0x1084000                             
02cb6bb0: ldr     s2, [x8, #0xca0]                           [1084ca0]=3eaaaaab3f19999a f=0.6,0.333333
02cb6bb4: ldr     x0, [x20, #0x10]                           &2b706e8(=14cc74f191004000)
02cb6bb8: mov     w1, wzr                                    
02cb6bbc: scvtf   s1, s0                                     
02cb6bc0: fmov    s0, w9                                     
02cb6bc4: mov     x2, xzr                                    
02cb6bc8: fmul    s0, s1, s0                                 
02cb6bcc: fmul    s1, s1, s2                                 
02cb6bd0: bl      #0x2c79c1c                                 DG.Tweening.DOTweenModuleUI::DOAnchorPosY
02cb6bd4: adrp    x8, #0x6266000                             
02cb6bd8: mov     w1, #1                                     
02cb6bdc: ldr     x8, [x8, #0xa18]                           MS:DG.Tweening.TweenSettingsExtensions::SetEase
02cb6be0: ldr     x2, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cb6be4: bl      #0x336fa0c                                 fn_336fa0c
02cb6be8: adrp    x8, #0x6264000                             
02cb6bec: mov     x19, x0                                    
02cb6bf0: ldr     x8, [x8, #0xe8]                            T:DG.Tweening.TweenCallback
02cb6bf4: ldr     x8, [x8]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02cb6bf8: mov     x0, x8                                     
02cb6bfc: bl      #0x2b7104c                                 fn_2b7104c
02cb6c00: adrp    x8, #0x6266000                             
02cb6c04: mov     x1, x20                                    
02cb6c08: mov     x3, xzr                                    
02cb6c0c: ldr     x8, [x8, #0xd60]                           M:CommentHandler/<>c__DisplayClass21_0::<StartComment>b__0
02cb6c10: mov     x21, x0                                    
02cb6c14: ldr     x2, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cb6c18: bl      #0x2d89dc4                                 DG.Tweening.TweenCallback::.ctor
02cb6c1c: adrp    x8, #0x6266000                             
02cb6c20: mov     x0, x19                                    
02cb6c24: mov     x1, x21                                    
02cb6c28: ldr     x8, [x8, #0xa08]                           MS:DG.Tweening.TweenSettingsExtensions::OnComplete
02cb6c2c: ldp     x20, x19, [sp, #0x50]                      
02cb6c30: ldp     x22, x21, [sp, #0x40]                      
02cb6c34: ldr     x30, [sp, #0x20]                           
02cb6c38: ldp     x24, x23, [sp, #0x30]                      
02cb6c3c: ldr     x2, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cb6c40: ldp     d9, d8, [sp, #0x10]                        
02cb6c44: ldp     d11, d10, [sp], #0x60                      
02cb6c48: b       #0x336f26c                                 
02cb6c4c: bl      #0x2b7105c                                 fn_2b7105c
## UserComment(string content) -> void
---- CommentHandler::UserComment 0x2cb6c58
02cb6c58: str     x30, [sp, #-0x30]!                         
02cb6c5c: stp     x22, x21, [sp, #0x10]                      
02cb6c60: stp     x20, x19, [sp, #0x20]                      
02cb6c64: adrp    x22, #0x662f000                            
02cb6c68: adrp    x21, #0x6266000                            
02cb6c6c: mov     x19, x1                                    
02cb6c70: ldrb    w8, [x22, #0xbb0]                          
02cb6c74: ldr     x21, [x21, #0xcf0]                         T:CommentConfig
02cb6c78: mov     x20, x0                                    
02cb6c7c: tbnz    w8, #0, #0x2cb6ca0                         
02cb6c80: adrp    x0, #0x6266000                             
02cb6c84: ldr     x0, [x0, #0xcf0]                           T:CommentConfig
02cb6c88: bl      #0x2b70db0                                 fn_2b70db0
02cb6c8c: adrp    x0, #0x6266000                             
02cb6c90: ldr     x0, [x0, #0xcf8]                           MS:CustomQueue`1::Enqueue
02cb6c94: bl      #0x2b70db0                                 fn_2b70db0
02cb6c98: mov     w8, #1                                     
02cb6c9c: strb    w8, [x22, #0xbb0]                          
02cb6ca0: ldr     x0, [x21]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cb6ca4: ldr     x20, [x20, #0x70]                          .CommentStringIdQueue
02cb6ca8: bl      #0x2b7104c                                 fn_2b7104c
02cb6cac: mov     x1, xzr                                    
02cb6cb0: mov     x21, x0                                    
02cb6cb4: bl      #0x4e53e9c                                 System.Object::.ctor
02cb6cb8: cbz     x21, #0x2cb6d00                            
02cb6cbc: mov     x22, x21                                   
02cb6cc0: mov     x1, x19                                    
02cb6cc4: str     x19, [x22, #0x20]!                         
02cb6cc8: mov     x0, x22                                    
02cb6ccc: bl      #0x2b70d54                                 fn_2b70d54
02cb6cd0: sturb   wzr, [x22, #-0x10]                         
02cb6cd4: stur    xzr, [x22, #-8]                            
02cb6cd8: cbz     x20, #0x2cb6d00                            
02cb6cdc: adrp    x8, #0x6266000                             
02cb6ce0: mov     x0, x20                                    
02cb6ce4: mov     x1, x21                                    
02cb6ce8: ldr     x8, [x8, #0xcf8]                           MS:CustomQueue`1::Enqueue
02cb6cec: ldp     x20, x19, [sp, #0x20]                      
02cb6cf0: ldp     x22, x21, [sp, #0x10]                      
02cb6cf4: ldr     x2, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cb6cf8: ldr     x30, [sp], #0x30                           
02cb6cfc: b       #0x442c888                                 
02cb6d00: bl      #0x2b7105c                                 fn_2b7105c
## Comment(string content, bool isViewer) -> void
---- CommentHandler::Comment 0x2cb5d28
02cb5d28: stp     d11, d10, [sp, #-0x70]!                    
02cb5d2c: stp     d9, d8, [sp, #0x10]                        
02cb5d30: stp     x30, x27, [sp, #0x20]                      
02cb5d34: stp     x26, x25, [sp, #0x30]                      
02cb5d38: stp     x24, x23, [sp, #0x40]                      
02cb5d3c: stp     x22, x21, [sp, #0x50]                      
02cb5d40: stp     x20, x19, [sp, #0x60]                      
02cb5d44: adrp    x20, #0x662f000                            
02cb5d48: adrp    x23, #0x6266000                            
02cb5d4c: mov     w21, w2                                    
02cb5d50: ldrb    w8, [x20, #0xbb1]                          
02cb5d54: ldr     x23, [x23, #0xd10]                         T:CommentHandler/<>c__DisplayClass25_0
02cb5d58: mov     x22, x1                                    
02cb5d5c: mov     x19, x0                                    
02cb5d60: tbnz    w8, #0, #0x2cb5df0                         
02cb5d64: adrp    x0, #0x6266000                             
02cb5d68: ldr     x0, [x0, #0xd18]                           MS:UnityEngine.Component::GetComponent
02cb5d6c: bl      #0x2b70db0                                 fn_2b70db0
02cb5d70: adrp    x0, #0x6264000                             
02cb5d74: ldr     x0, [x0, #0xd88]                           MS:UnityEngine.Component::GetComponent
02cb5d78: bl      #0x2b70db0                                 fn_2b70db0
02cb5d7c: adrp    x0, #0x6266000                             
02cb5d80: ldr     x0, [x0, #0x9f0]                           T:Assets.SimpleLocalization.Scripts.LocalizationManager
02cb5d84: bl      #0x2b70db0                                 fn_2b70db0
02cb5d88: adrp    x0, #0x6266000                             
02cb5d8c: ldr     x0, [x0, #0xac0]                           MS:MonoSingleton`1::get_Instance
02cb5d90: bl      #0x2b70db0                                 fn_2b70db0
02cb5d94: adrp    x0, #0x6266000                             
02cb5d98: ldr     x0, [x0, #0xd20]                           MS:MonoSingleton`1::get_Instance
02cb5d9c: bl      #0x2b70db0                                 fn_2b70db0
02cb5da0: adrp    x0, #0x6263000                             
02cb5da4: ldr     x0, [x0, #0x918]                           T:UnityEngine.Object
02cb5da8: bl      #0x2b70db0                                 fn_2b70db0
02cb5dac: adrp    x0, #0x6264000                             
02cb5db0: ldr     x0, [x0, #0xe8]                            T:DG.Tweening.TweenCallback
02cb5db4: bl      #0x2b70db0                                 fn_2b70db0
02cb5db8: adrp    x0, #0x6266000                             
02cb5dbc: ldr     x0, [x0, #0xa08]                           MS:DG.Tweening.TweenSettingsExtensions::OnComplete
02cb5dc0: bl      #0x2b70db0                                 fn_2b70db0
02cb5dc4: adrp    x0, #0x6266000                             
02cb5dc8: ldr     x0, [x0, #0xa18]                           MS:DG.Tweening.TweenSettingsExtensions::SetEase
02cb5dcc: bl      #0x2b70db0                                 fn_2b70db0
02cb5dd0: adrp    x0, #0x6266000                             
02cb5dd4: ldr     x0, [x0, #0xd28]                           M:CommentHandler/<>c__DisplayClass25_0::<Comment>b__0
02cb5dd8: bl      #0x2b70db0                                 fn_2b70db0
02cb5ddc: adrp    x0, #0x6266000                             
02cb5de0: ldr     x0, [x0, #0xd10]                           T:CommentHandler/<>c__DisplayClass25_0
02cb5de4: bl      #0x2b70db0                                 fn_2b70db0
02cb5de8: mov     w8, #1                                     
02cb5dec: strb    w8, [x20, #0xbb1]                          
02cb5df0: ldr     x0, [x23]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cb5df4: bl      #0x2b7104c                                 fn_2b7104c
02cb5df8: mov     x1, xzr                                    
02cb5dfc: mov     x20, x0                                    
02cb5e00: bl      #0x4e53e9c                                 System.Object::.ctor
02cb5e04: cbz     x20, #0x2cb5fa4                            
02cb5e08: adrp    x23, #0x6266000                            
02cb5e0c: mov     x0, x20                                    
02cb5e10: mov     x1, x19                                    
02cb5e14: ldr     x23, [x23, #0xd20]                         MS:MonoSingleton`1::get_Instance
02cb5e18: str     x19, [x0, #0x18]!                          
02cb5e1c: bl      #0x2b70d54                                 fn_2b70d54
02cb5e20: ldr     x0, [x23]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cb5e24: ldr     s8, [x19, #0x24]                           ._distanceComment
02cb5e28: bl      #0x3769600                                 fn_3769600
02cb5e2c: adrp    x25, #0x662f000                            
02cb5e30: ldr     x23, [x19, #0x28]                          ._prefabComment
02cb5e34: mov     x24, x0                                    
02cb5e38: ldrb    w8, [x25, #0x91a]                          
02cb5e3c: cbnz    w8, #0x2cb5e54                             
02cb5e40: adrp    x0, #0x6264000                             
02cb5e44: ldr     x0, [x0, #0xd8]                            T:UnityEngine.Vector3
02cb5e48: bl      #0x2b70db0                                 fn_2b70db0
02cb5e4c: mov     w8, #1                                     
02cb5e50: strb    w8, [x25, #0x91a]                          
02cb5e54: adrp    x25, #0x6264000                            
02cb5e58: adrp    x26, #0x662f000                            
02cb5e5c: ldr     x25, [x25, #0xd8]                          T:UnityEngine.Vector3
02cb5e60: ldrb    w9, [x26, #0xbdf]                          
02cb5e64: ldr     x8, [x25]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02cb5e68: ldr     x8, [x8, #0xb8]                            
02cb5e6c: ldp     s9, s10, [x8]                              
02cb5e70: ldr     s11, [x8, #8]                              
02cb5e74: cbnz    w9, #0x2cb5e8c                             
02cb5e78: adrp    x0, #0x6266000                             
02cb5e7c: ldr     x0, [x0, #0xd30]                           T:UnityEngine.Quaternion
02cb5e80: bl      #0x2b70db0                                 fn_2b70db0
02cb5e84: mov     w8, #1                                     
02cb5e88: strb    w8, [x26, #0xbdf]                          
02cb5e8c: cbz     x24, #0x2cb5fa4                            
02cb5e90: adrp    x8, #0x6266000                             
02cb5e94: fmov    s0, s9                                     
02cb5e98: fmov    s1, s10                                    
02cb5e9c: ldr     x8, [x8, #0xd30]                           T:UnityEngine.Quaternion
02cb5ea0: fmov    s2, s11                                    
02cb5ea4: ldr     x2, [x19, #0x38]                           ._commentParent
02cb5ea8: mov     x0, x24                                    
02cb5eac: mov     x1, x23                                    
02cb5eb0: mov     x3, xzr                                    
02cb5eb4: ldr     x8, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cb5eb8: ldr     x8, [x8, #0xb8]                            S:'banner_native_refresh_time'
02cb5ebc: ldp     s5, s6, [x8, #8]                           
02cb5ec0: ldp     s3, s4, [x8]                               
02cb5ec4: bl      #0x2cd69bc                                 PoolManager::SpawnObject
02cb5ec8: cbz     x0, #0x2cb5fa4                             
02cb5ecc: adrp    x8, #0x6266000                             
02cb5ed0: ldr     x8, [x8, #0xd18]                           MS:UnityEngine.Component::GetComponent
02cb5ed4: ldr     x1, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cb5ed8: bl      #0x3140c84                                 fn_3140c84
02cb5edc: mov     x23, x20                                   
02cb5ee0: mov     x1, x0                                     
02cb5ee4: str     x0, [x23, #0x20]!                          
02cb5ee8: mov     x0, x23                                    
02cb5eec: bl      #0x2b70d54                                 fn_2b70d54
02cb5ef0: ldr     x0, [x23]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cb5ef4: cbz     x0, #0x2cb5fa4                             
02cb5ef8: adrp    x24, #0x6266000                            
02cb5efc: ldr     x24, [x24, #0x9f0]                         T:Assets.SimpleLocalization.Scripts.LocalizationManager
02cb5f00: bl      #0x2cb54f8                                 CommentControl::Appear
02cb5f04: ldr     x0, [x24]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cb5f08: ldr     x24, [x23]                                 M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cb5f0c: ldr     w8, [x0, #0xe4]                            [62660e4]=0 f=0,0
02cb5f10: cbnz    w8, #0x2cb5f18                             
02cb5f14: bl      #0x2b70f30                                 fn_2b70f30
02cb5f18: mov     x0, x22                                    
02cb5f1c: mov     x1, xzr                                    
02cb5f20: bl      #0x2d76794                                 Assets.SimpleLocalization.Scripts.LocalizationManager::Localize
02cb5f24: cbz     x24, #0x2cb5fa4                            
02cb5f28: mov     x1, x0                                     
02cb5f2c: mov     x0, x24                                    
02cb5f30: bl      #0x2cb529c                                 CommentControl::SetText
02cb5f34: ldr     x8, [x23]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cb5f38: cbz     x8, #0x2cb5fa4                             
02cb5f3c: ldr     x0, [x8, #0x58]                            S:'inter_ad_on_off'
02cb5f40: cbz     x0, #0x2cb5fa4                             
02cb5f44: mov     w8, #1                                     
02cb5f48: mov     x2, xzr                                    
02cb5f4c: bic     w1, w8, w21                                
02cb5f50: bl      #0x5a7729c                                 TMPro.TMP_Text::set_enableAutoSizing
02cb5f54: ldr     x0, [x19, #0x50]                           ._viewerAvatarAsset
02cb5f58: cbz     x0, #0x2cb5fa4                             
02cb5f5c: adrp    x26, #0x6263000                            
02cb5f60: adrp    x27, #0x6264000                            
02cb5f64: ldr     x26, [x26, #0x918]                         T:UnityEngine.Object
02cb5f68: ldr     x27, [x27, #0xd88]                         MS:UnityEngine.Component::GetComponent
02cb5f6c: bl      #0x2cb4b80                                 ViewerAvatarAsset::PickRandom
02cb5f70: mov     x22, x0                                    
02cb5f74: ldr     x0, [x26]                                  &2c5bbd4(=a9bd7bfdd503233f)
02cb5f78: ldur    x24, [x19, #0x80]                          ._latestAvatar
02cb5f7c: ldr     w8, [x0, #0xe4]                            [62660e4]=0 f=0,0
02cb5f80: cbnz    w8, #0x2cb5f88                             
02cb5f84: bl      #0x2b70f30                                 fn_2b70f30
02cb5f88: mov     x0, x22                                    
02cb5f8c: mov     x1, x24                                    
02cb5f90: mov     x2, xzr                                    
02cb5f94: bl      #0x5b37d84                                 UnityEngine.Object::op_Equality
02cb5f98: tbz     w0, #0, #0x2cb5fa8                         
02cb5f9c: ldr     x0, [x19, #0x50]                           ._viewerAvatarAsset
02cb5fa0: cbnz    x0, #0x2cb5f6c                             
02cb5fa4: bl      #0x2b7105c                                 fn_2b7105c
02cb5fa8: add     x0, x19, #0x80                             
02cb5fac: mov     x1, x22                                    
02cb5fb0: stur    x22, [x19, #0x80]                          ._latestAvatar
02cb5fb4: bl      #0x2b70d54                                 fn_2b70d54
02cb5fb8: ldr     x24, [x23]                                 M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cb5fbc: tbnz    w21, #0, #0x2cb5fd8                        
02cb5fc0: adrp    x8, #0x6266000                             
02cb5fc4: ldr     x8, [x8, #0xac0]                           MS:MonoSingleton`1::get_Instance
02cb5fc8: ldr     x0, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cb5fcc: bl      #0x3769600                                 fn_3769600
02cb5fd0: cbz     x0, #0x2cb5fa4                             
02cb5fd4: ldr     x22, [x0, #0x38]                           S:'native_collap_id' ._commentParent
02cb5fd8: cbz     x24, #0x2cb5fa4                            
02cb5fdc: mov     x0, x24                                    
02cb5fe0: mov     x1, x22                                    
02cb5fe4: bl      #0x2cb4f64                                 CommentControl::Init
02cb5fe8: ldr     x0, [x23]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cb5fec: cbz     x0, #0x2cb5fa4                             
02cb5ff0: and     w1, w21, #1                                
02cb5ff4: bl      #0x2cb5330                                 CommentControl::SetLayoutType
02cb5ff8: ldr     x0, [x23]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cb5ffc: cbz     x0, #0x2cb5fa4                             
02cb6000: ldr     x1, [x27]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02cb6004: bl      #0x3140c84                                 fn_3140c84
02cb6008: mov     x21, x20                                   
02cb600c: mov     x1, x0                                     
02cb6010: str     x0, [x21, #0x10]!                          
02cb6014: mov     x0, x21                                    
02cb6018: bl      #0x2b70d54                                 fn_2b70d54
02cb601c: ldr     x0, [x26]                                  &2c5bbd4(=a9bd7bfdd503233f)
02cb6020: ldr     x22, [x21]                                 
02cb6024: ldr     w8, [x0, #0xe4]                            [62660e4]=0 f=0,0
02cb6028: cbnz    w8, #0x2cb6030                             
02cb602c: bl      #0x2b70f30                                 fn_2b70f30
02cb6030: mov     x0, x22                                    
02cb6034: mov     x1, xzr                                    
02cb6038: mov     x2, xzr                                    
02cb603c: bl      #0x5b37d84                                 UnityEngine.Object::op_Equality
02cb6040: tbz     w0, #0, #0x2cb6064                         
02cb6044: ldp     x20, x19, [sp, #0x60]                      
02cb6048: ldp     x22, x21, [sp, #0x50]                      
02cb604c: ldp     x24, x23, [sp, #0x40]                      
02cb6050: ldp     x26, x25, [sp, #0x30]                      
02cb6054: ldp     x30, x27, [sp, #0x20]                      
02cb6058: ldp     d9, d8, [sp, #0x10]                        
02cb605c: ldp     d11, d10, [sp], #0x70                      
02cb6060: ret                                                
02cb6064: ldr     x0, [x21]                                  
02cb6068: mov     w1, wzr                                    
02cb606c: mov     x2, xzr                                    
02cb6070: bl      #0x2d9d5d0                                 DG.Tweening.ShortcutExtensions::DOKill
02cb6074: adrp    x23, #0x662f000                            
02cb6078: ldr     x22, [x21]                                 
02cb607c: ldrb    w8, [x23, #0xa74]                          
02cb6080: cbnz    w8, #0x2cb6098                             
02cb6084: adrp    x0, #0x6264000                             
02cb6088: ldr     x0, [x0, #0xd8]                            T:UnityEngine.Vector3
02cb608c: bl      #0x2b70db0                                 fn_2b70db0
02cb6090: mov     w8, #1                                     
02cb6094: strb    w8, [x23, #0xa74]                          
02cb6098: cbz     x22, #0x2cb5fa4                            
02cb609c: ldr     x8, [x25]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02cb60a0: mov     w9, #0x6666                                
02cb60a4: mov     x0, x22                                    
02cb60a8: movk    w9, #0x3fa6, lsl #16                       
02cb60ac: mov     x1, xzr                                    
02cb60b0: ldr     x8, [x8, #0xb8]                            S:'banner_native_refresh_time'
02cb60b4: dup     v0.2s, w9                                  
02cb60b8: adrp    x9, #0x1084000                             
02cb60bc: ldr     s2, [x9, #0xf2c]                           [1084f2c]=3ca3d70a3fa66666 f=1.3,0.02
02cb60c0: ldur    d1, [x8, #0xc]                             
02cb60c4: fmul    v0.2s, v1.2s, v0.2s                        
02cb60c8: ldr     s1, [x8, #0x14]                            [6266014]=0 f=0,0
02cb60cc: fmul    s2, s1, s2                                 
02cb60d0: mov     s1, v0.s[1]                                
02cb60d4: bl      #0x5b470cc                                 UnityEngine.Transform::set_localScale
02cb60d8: ldr     x0, [x21]                                  
02cb60dc: cbz     x0, #0x2cb5fa4                             
02cb60e0: movi    d2, #0000000000000000                      
02cb60e4: mov     w8, #0x42700000                            
02cb60e8: fmov    s1, s8                                     
02cb60ec: fmov    s0, w8                                     
02cb60f0: mov     x1, xzr                                    
02cb60f4: bl      #0x5b45cec                                 UnityEngine.Transform::set_localPosition
02cb60f8: ldr     s0, [x19, #0x78]                           ._maxChatShowing
02cb60fc: mov     w9, #0x42c80000                            
02cb6100: adrp    x8, #0x1084000                             
02cb6104: ldr     s2, [x8, #0xca0]                           [1084ca0]=3eaaaaab3f19999a f=0.6,0.333333
02cb6108: ldr     x0, [x20, #0x10]                           &2b706e8(=14cc74f191004000)
02cb610c: mov     w1, wzr                                    
02cb6110: scvtf   s1, s0                                     
02cb6114: fmov    s0, w9                                     
02cb6118: mov     x2, xzr                                    
02cb611c: fmul    s0, s1, s0                                 
02cb6120: fmul    s1, s1, s2                                 
02cb6124: bl      #0x2c79c1c                                 DG.Tweening.DOTweenModuleUI::DOAnchorPosY
02cb6128: adrp    x8, #0x6266000                             
02cb612c: mov     w1, #1                                     
02cb6130: ldr     x8, [x8, #0xa18]                           MS:DG.Tweening.TweenSettingsExtensions::SetEase
02cb6134: ldr     x2, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cb6138: bl      #0x336fa0c                                 fn_336fa0c
02cb613c: adrp    x8, #0x6264000                             
02cb6140: mov     x19, x0                                    
02cb6144: ldr     x8, [x8, #0xe8]                            T:DG.Tweening.TweenCallback
02cb6148: ldr     x8, [x8]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02cb614c: mov     x0, x8                                     
02cb6150: bl      #0x2b7104c                                 fn_2b7104c
02cb6154: adrp    x8, #0x6266000                             
02cb6158: mov     x1, x20                                    
02cb615c: mov     x3, xzr                                    
02cb6160: ldr     x8, [x8, #0xd28]                           M:CommentHandler/<>c__DisplayClass25_0::<Comment>b__0
02cb6164: mov     x21, x0                                    
02cb6168: ldr     x2, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cb616c: bl      #0x2d89dc4                                 DG.Tweening.TweenCallback::.ctor
02cb6170: adrp    x8, #0x6266000                             
02cb6174: mov     x0, x19                                    
02cb6178: mov     x1, x21                                    
02cb617c: ldr     x8, [x8, #0xa08]                           MS:DG.Tweening.TweenSettingsExtensions::OnComplete
02cb6180: ldp     x20, x19, [sp, #0x60]                      
02cb6184: ldp     x22, x21, [sp, #0x50]                      
02cb6188: ldp     x24, x23, [sp, #0x40]                      
02cb618c: ldr     x2, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cb6190: ldp     x26, x25, [sp, #0x30]                      
02cb6194: ldp     x30, x27, [sp, #0x20]                      
02cb6198: ldp     d9, d8, [sp, #0x10]                        
02cb619c: ldp     d11, d10, [sp], #0x70                      
02cb61a0: b       #0x336f26c                                 
## .ctor() -> void
---- CommentHandler::.ctor 0x2cb6d0c
02cb6d0c: str     x30, [sp, #-0x30]!                         
02cb6d10: stp     x22, x21, [sp, #0x10]                      
02cb6d14: stp     x20, x19, [sp, #0x20]                      
02cb6d18: adrp    x22, #0x662f000                            
02cb6d1c: adrp    x21, #0x6266000                            
02cb6d20: adrp    x20, #0x6266000                            
02cb6d24: ldrb    w8, [x22, #0xbb2]                          
02cb6d28: ldr     x21, [x21, #0xd70]                         T:type56658(k15)
02cb6d2c: ldr     x20, [x20, #0xd78]                         MS:System.Collections.Generic.List`1::.ctor
02cb6d30: mov     x19, x0                                    
02cb6d34: tbnz    w8, #0, #0x2cb6d58                         
02cb6d38: adrp    x0, #0x6266000                             
02cb6d3c: ldr     x0, [x0, #0xd78]                           MS:System.Collections.Generic.List`1::.ctor
02cb6d40: bl      #0x2b70db0                                 fn_2b70db0
02cb6d44: adrp    x0, #0x6266000                             
02cb6d48: ldr     x0, [x0, #0xd70]                           T:type56658(k15)
02cb6d4c: bl      #0x2b70db0                                 fn_2b70db0
02cb6d50: mov     w8, #1                                     
02cb6d54: strb    w8, [x22, #0xbb2]                          
02cb6d58: ldr     x0, [x21]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cb6d5c: mov     w8, #0x43480000                            
02cb6d60: str     w8, [x19, #0x24]                           ._distanceComment
02cb6d64: bl      #0x2b7104c                                 fn_2b7104c
02cb6d68: ldr     x1, [x20]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cb6d6c: mov     x20, x0                                    
02cb6d70: bl      #0x35a89a4                                 fn_35a89a4
02cb6d74: mov     x0, x19                                    
02cb6d78: mov     x1, x20                                    
02cb6d7c: str     x20, [x0, #0x58]!                          .ls_comments
02cb6d80: bl      #0x2b70d54                                 fn_2b70d54
02cb6d84: mov     w8, #5                                     
02cb6d88: mov     w9, #4                                     
02cb6d8c: mov     x0, x19                                    
02cb6d90: str     w8, [x19, #0x68]                           ._maxComment
02cb6d94: ldp     x22, x21, [sp, #0x10]                      
02cb6d98: str     w9, [x19, #0x78]                           ._maxChatShowing
02cb6d9c: ldp     x20, x19, [sp, #0x20]                      
02cb6da0: mov     x1, xzr                                    
02cb6da4: ldr     x30, [sp], #0x30                           
02cb6da8: b       #0x5b397b0                                 UnityEngine.MonoBehaviour::.ctor
