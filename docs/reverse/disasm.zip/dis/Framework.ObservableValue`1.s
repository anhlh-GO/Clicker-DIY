#### CLASS Framework.ObservableValue`1 parent= object
#   field OnValueChanged                 System.Action`1<T>                                 off=0x0 attr=1 CompilerGeneratedAttribute
#   field _value                         T                                                  off=0x0 attr=1 
##  add_OnValueChanged (no body)
##  remove_OnValueChanged (no body)
##  get_Value (no body)
##  set_Value (no body)
##  .ctor (no body)
##  .ctor (no body)
##  ForceSet (no body)
##  SetWithoutNotify (no body)
