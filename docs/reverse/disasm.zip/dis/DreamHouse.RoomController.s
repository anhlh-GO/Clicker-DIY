#### CLASS DreamHouse.RoomController/<>c__DisplayClass25_0 parent= object
#   field <>4__this                      DreamHouse.RoomController                          off=0x10 attr=6 
#   field decorItemAsset                 DreamHouse.DecorItemAsset                          off=0x18 attr=6 
## .ctor() -> void
---- DreamHouse.RoomController/<>c__DisplayClass25_0::.ctor 0x2d19338
02d19338: mov     x1, xzr                                    
02d1933c: b       #0x4e53e9c                                 System.Object::.ctor
## <OnMarkPointButtonPressed>b__0() -> void
---- DreamHouse.RoomController/<>c__DisplayClass25_0::<OnMarkPointButtonPressed>b__0 0x2d19340
02d19340: str     x30, [sp, #-0x10]!                         
02d19344: ldr     x8, [x0, #0x10]                            .<>4__this
02d19348: cbz     x8, #0x2d1936c                             
02d1934c: ldr     x8, [x8, #0x38]                            
02d19350: cbz     x8, #0x2d1936c                             
02d19354: ldr     x8, [x8, #0x48]                            
02d19358: cbz     x8, #0x2d1936c                             
02d1935c: ldr     x1, [x0, #0x18]                            .decorItemAsset
02d19360: mov     x0, x8                                     
02d19364: ldr     x30, [sp], #0x10                           
02d19368: b       #0x2d19370                                 DreamHouse.DecorItemPanel::OnShow
02d1936c: bl      #0x2b7105c                                 fn_2b7105c
#### CLASS DreamHouse.RoomController parent= UnityEngine.MonoBehaviour
#   field OnInitialized                  UnityEngine.Events.UnityAction                     off=0x0 attr=11 CompilerGeneratedAttribute
#   field OnStepChanged                  UnityEngine.Events.UnityAction`1<int>              off=0x20 attr=1 CompilerGeneratedAttribute
#   field OnRoomCompleted                UnityEngine.Events.UnityAction                     off=0x28 attr=1 CompilerGeneratedAttribute
#   field _decorItems                    System.Collections.Generic.List`1<DreamHouse.DecorItem> off=0x30 attr=1 SerializeField
#   field _dreamHouseController          DreamHouse.DreamHouseController                    off=0x38 attr=1 
#   field _roomConfig                    DreamHouse.RoomConfig                              off=0x40 attr=1 
#   field _currentStep                   int                                                off=0x48 attr=1 
#   field <CurrentDecorItem>k__BackingField DreamHouse.DecorItem                               off=0x50 attr=1 CompilerGeneratedAttribute
## add_OnInitialized(UnityEngine.Events.UnityAction value) -> void
---- DreamHouse.RoomController::add_OnInitialized 0x2d186f4
02d186f4: str     x30, [sp, #-0x30]!                         
02d186f8: stp     x22, x21, [sp, #0x10]                      
02d186fc: stp     x20, x19, [sp, #0x20]                      
02d18700: adrp    x20, #0x662f000                            
02d18704: adrp    x21, #0x6269000                            
02d18708: mov     x19, x0                                    
02d1870c: ldrb    w8, [x20, #0xfec]                          
02d18710: ldr     x21, [x21, #0xa48]                         T:DreamHouse.RoomController
02d18714: tbnz    w8, #0, #0x2d18738                         
02d18718: adrp    x0, #0x6269000                             
02d1871c: ldr     x0, [x0, #0xa48]                           T:DreamHouse.RoomController
02d18720: bl      #0x2b70db0                                 fn_2b70db0
02d18724: adrp    x0, #0x6265000                             
02d18728: ldr     x0, [x0, #0x3f0]                           T:UnityEngine.Events.UnityAction
02d1872c: bl      #0x2b70db0                                 fn_2b70db0
02d18730: mov     w8, #1                                     
02d18734: strb    w8, [x20, #0xfec]                          
02d18738: ldr     x8, [x21]                                  T:Trading.TradingSession/<>c__DisplayClass56_0
02d1873c: adrp    x22, #0x6265000                            
02d18740: ldr     x8, [x8, #0xb8]                            
02d18744: ldr     x22, [x22, #0x3f0]                         T:UnityEngine.Events.UnityAction
02d18748: ldr     x20, [x8]                                  
02d1874c: mov     x0, x20                                    
02d18750: mov     x1, x19                                    
02d18754: mov     x2, xzr                                    
02d18758: bl      #0x4e570ac                                 System.Delegate::Combine
02d1875c: mov     x8, x0                                     
02d18760: cbz     x0, #0x2d18774                             
02d18764: ldr     x1, [x22]                                  M:AdsManager::<OnApplicationPause>b__26_0
02d18768: ldr     x9, [x8]                                   
02d1876c: cmp     x9, x1                                     
02d18770: b.ne    #0x2d187a4                                 
02d18774: ldr     x9, [x21]                                  T:Trading.TradingSession/<>c__DisplayClass56_0
02d18778: mov     x1, x8                                     
02d1877c: mov     x2, x20                                    
02d18780: ldr     x0, [x9, #0xb8]                            
02d18784: bl      #0x2ba9880                                 fn_2ba9880
02d18788: cmp     x0, x20                                    
02d1878c: mov     x20, x0                                    
02d18790: b.ne    #0x2d1874c                                 
02d18794: ldp     x20, x19, [sp, #0x20]                      
02d18798: ldp     x22, x21, [sp, #0x10]                      
02d1879c: ldr     x30, [sp], #0x30                           
02d187a0: ret                                                
02d187a4: mov     x0, x8                                     
02d187a8: bl      #0x2b713dc                                 fn_2b713dc
## remove_OnInitialized(UnityEngine.Events.UnityAction value) -> void
---- DreamHouse.RoomController::remove_OnInitialized 0x2d187ac
02d187ac: str     x30, [sp, #-0x30]!                         
02d187b0: stp     x22, x21, [sp, #0x10]                      
02d187b4: stp     x20, x19, [sp, #0x20]                      
02d187b8: adrp    x20, #0x662f000                            
02d187bc: adrp    x21, #0x6269000                            
02d187c0: mov     x19, x0                                    
02d187c4: ldrb    w8, [x20, #0xfed]                          
02d187c8: ldr     x21, [x21, #0xa48]                         T:DreamHouse.RoomController
02d187cc: tbnz    w8, #0, #0x2d187f0                         
02d187d0: adrp    x0, #0x6269000                             
02d187d4: ldr     x0, [x0, #0xa48]                           T:DreamHouse.RoomController
02d187d8: bl      #0x2b70db0                                 fn_2b70db0
02d187dc: adrp    x0, #0x6265000                             
02d187e0: ldr     x0, [x0, #0x3f0]                           T:UnityEngine.Events.UnityAction
02d187e4: bl      #0x2b70db0                                 fn_2b70db0
02d187e8: mov     w8, #1                                     
02d187ec: strb    w8, [x20, #0xfed]                          
02d187f0: ldr     x8, [x21]                                  T:Trading.TradingSession/<>c__DisplayClass56_0
02d187f4: adrp    x22, #0x6265000                            
02d187f8: ldr     x8, [x8, #0xb8]                            
02d187fc: ldr     x22, [x22, #0x3f0]                         T:UnityEngine.Events.UnityAction
02d18800: ldr     x20, [x8]                                  
02d18804: mov     x0, x20                                    
02d18808: mov     x1, x19                                    
02d1880c: mov     x2, xzr                                    
02d18810: bl      #0x4e57298                                 System.Delegate::Remove
02d18814: mov     x8, x0                                     
02d18818: cbz     x0, #0x2d1882c                             
02d1881c: ldr     x1, [x22]                                  M:AdsManager::<OnApplicationPause>b__26_0
02d18820: ldr     x9, [x8]                                   
02d18824: cmp     x9, x1                                     
02d18828: b.ne    #0x2d1885c                                 
02d1882c: ldr     x9, [x21]                                  T:Trading.TradingSession/<>c__DisplayClass56_0
02d18830: mov     x1, x8                                     
02d18834: mov     x2, x20                                    
02d18838: ldr     x0, [x9, #0xb8]                            
02d1883c: bl      #0x2ba9880                                 fn_2ba9880
02d18840: cmp     x0, x20                                    
02d18844: mov     x20, x0                                    
02d18848: b.ne    #0x2d18804                                 
02d1884c: ldp     x20, x19, [sp, #0x20]                      
02d18850: ldp     x22, x21, [sp, #0x10]                      
02d18854: ldr     x30, [sp], #0x30                           
02d18858: ret                                                
02d1885c: mov     x0, x8                                     
02d18860: bl      #0x2b713dc                                 fn_2b713dc
## add_OnStepChanged(UnityEngine.Events.UnityAction`1<int> value) -> void
---- DreamHouse.RoomController::add_OnStepChanged 0x2d18864
02d18864: str     x30, [sp, #-0x40]!                         
02d18868: stp     x24, x23, [sp, #0x10]                      
02d1886c: stp     x22, x21, [sp, #0x20]                      
02d18870: stp     x20, x19, [sp, #0x30]                      
02d18874: adrp    x21, #0x662f000                            
02d18878: mov     x19, x1                                    
02d1887c: mov     x20, x0                                    
02d18880: ldrb    w8, [x21, #0xfee]                          
02d18884: tbnz    w8, #0, #0x2d1889c                         
02d18888: adrp    x0, #0x6269000                             
02d1888c: ldr     x0, [x0, #0xa68]                           T:type19683(k15)
02d18890: bl      #0x2b70db0                                 fn_2b70db0
02d18894: mov     w8, #1                                     
02d18898: strb    w8, [x21, #0xfee]                          
02d1889c: adrp    x24, #0x6269000                            
02d188a0: ldr     x24, [x24, #0xa68]                         T:type19683(k15)
02d188a4: ldr     x21, [x20, #0x20]!                         .OnStepChanged
02d188a8: mov     x0, x21                                    
02d188ac: mov     x1, x19                                    
02d188b0: mov     x2, xzr                                    
02d188b4: bl      #0x4e570ac                                 System.Delegate::Combine
02d188b8: cbz     x0, #0x2d188d8                             
02d188bc: ldr     x23, [x24]                                 T:Trading.TradingSession/<>c__DisplayClass56_0
02d188c0: mov     x22, x0                                    
02d188c4: mov     x1, x23                                    
02d188c8: bl      #0x2b70f34                                 fn_2b70f34
02d188cc: mov     x1, x0                                     
02d188d0: cbnz    x0, #0x2d188dc                             
02d188d4: b       #0x2d18908                                 
02d188d8: mov     x1, xzr                                    
02d188dc: mov     x0, x20                                    
02d188e0: mov     x2, x21                                    
02d188e4: bl      #0x2ba9880                                 fn_2ba9880
02d188e8: cmp     x0, x21                                    
02d188ec: mov     x21, x0                                    
02d188f0: b.ne    #0x2d188a8                                 
02d188f4: ldp     x20, x19, [sp, #0x30]                      
02d188f8: ldp     x22, x21, [sp, #0x20]                      
02d188fc: ldp     x24, x23, [sp, #0x10]                      
02d18900: ldr     x30, [sp], #0x40                           
02d18904: ret                                                
02d18908: mov     x0, x22                                    
02d1890c: mov     x1, x23                                    
02d18910: bl      #0x2b713dc                                 fn_2b713dc
## remove_OnStepChanged(UnityEngine.Events.UnityAction`1<int> value) -> void
---- DreamHouse.RoomController::remove_OnStepChanged 0x2d18914
02d18914: str     x30, [sp, #-0x40]!                         
02d18918: stp     x24, x23, [sp, #0x10]                      
02d1891c: stp     x22, x21, [sp, #0x20]                      
02d18920: stp     x20, x19, [sp, #0x30]                      
02d18924: adrp    x21, #0x662f000                            
02d18928: mov     x19, x1                                    
02d1892c: mov     x20, x0                                    
02d18930: ldrb    w8, [x21, #0xfef]                          
02d18934: tbnz    w8, #0, #0x2d1894c                         
02d18938: adrp    x0, #0x6269000                             
02d1893c: ldr     x0, [x0, #0xa68]                           T:type19683(k15)
02d18940: bl      #0x2b70db0                                 fn_2b70db0
02d18944: mov     w8, #1                                     
02d18948: strb    w8, [x21, #0xfef]                          
02d1894c: adrp    x24, #0x6269000                            
02d18950: ldr     x24, [x24, #0xa68]                         T:type19683(k15)
02d18954: ldr     x21, [x20, #0x20]!                         .OnStepChanged
02d18958: mov     x0, x21                                    
02d1895c: mov     x1, x19                                    
02d18960: mov     x2, xzr                                    
02d18964: bl      #0x4e57298                                 System.Delegate::Remove
02d18968: cbz     x0, #0x2d18988                             
02d1896c: ldr     x23, [x24]                                 T:Trading.TradingSession/<>c__DisplayClass56_0
02d18970: mov     x22, x0                                    
02d18974: mov     x1, x23                                    
02d18978: bl      #0x2b70f34                                 fn_2b70f34
02d1897c: mov     x1, x0                                     
02d18980: cbnz    x0, #0x2d1898c                             
02d18984: b       #0x2d189b8                                 
02d18988: mov     x1, xzr                                    
02d1898c: mov     x0, x20                                    
02d18990: mov     x2, x21                                    
02d18994: bl      #0x2ba9880                                 fn_2ba9880
02d18998: cmp     x0, x21                                    
02d1899c: mov     x21, x0                                    
02d189a0: b.ne    #0x2d18958                                 
02d189a4: ldp     x20, x19, [sp, #0x30]                      
02d189a8: ldp     x22, x21, [sp, #0x20]                      
02d189ac: ldp     x24, x23, [sp, #0x10]                      
02d189b0: ldr     x30, [sp], #0x40                           
02d189b4: ret                                                
02d189b8: mov     x0, x22                                    
02d189bc: mov     x1, x23                                    
02d189c0: bl      #0x2b713dc                                 fn_2b713dc
## add_OnRoomCompleted(UnityEngine.Events.UnityAction value) -> void
---- DreamHouse.RoomController::add_OnRoomCompleted 0x2d189c4
02d189c4: str     x30, [sp, #-0x30]!                         
02d189c8: stp     x22, x21, [sp, #0x10]                      
02d189cc: stp     x20, x19, [sp, #0x20]                      
02d189d0: adrp    x21, #0x662f000                            
02d189d4: mov     x19, x1                                    
02d189d8: mov     x20, x0                                    
02d189dc: ldrb    w8, [x21, #0xff0]                          
02d189e0: tbnz    w8, #0, #0x2d189f8                         
02d189e4: adrp    x0, #0x6265000                             
02d189e8: ldr     x0, [x0, #0x3f0]                           T:UnityEngine.Events.UnityAction
02d189ec: bl      #0x2b70db0                                 fn_2b70db0
02d189f0: mov     w8, #1                                     
02d189f4: strb    w8, [x21, #0xff0]                          
02d189f8: adrp    x22, #0x6265000                            
02d189fc: ldr     x22, [x22, #0x3f0]                         T:UnityEngine.Events.UnityAction
02d18a00: ldr     x21, [x20, #0x28]!                         .OnRoomCompleted
02d18a04: mov     x0, x21                                    
02d18a08: mov     x1, x19                                    
02d18a0c: mov     x2, xzr                                    
02d18a10: bl      #0x4e570ac                                 System.Delegate::Combine
02d18a14: mov     x8, x0                                     
02d18a18: cbz     x0, #0x2d18a2c                             
02d18a1c: ldr     x1, [x22]                                  M:AdsManager::<OnApplicationPause>b__26_0
02d18a20: ldr     x9, [x8]                                   
02d18a24: cmp     x9, x1                                     
02d18a28: b.ne    #0x2d18a58                                 
02d18a2c: mov     x0, x20                                    
02d18a30: mov     x1, x8                                     
02d18a34: mov     x2, x21                                    
02d18a38: bl      #0x2ba9880                                 fn_2ba9880
02d18a3c: cmp     x0, x21                                    
02d18a40: mov     x21, x0                                    
02d18a44: b.ne    #0x2d18a04                                 
02d18a48: ldp     x20, x19, [sp, #0x20]                      
02d18a4c: ldp     x22, x21, [sp, #0x10]                      
02d18a50: ldr     x30, [sp], #0x30                           
02d18a54: ret                                                
02d18a58: mov     x0, x8                                     
02d18a5c: bl      #0x2b713dc                                 fn_2b713dc
## remove_OnRoomCompleted(UnityEngine.Events.UnityAction value) -> void
---- DreamHouse.RoomController::remove_OnRoomCompleted 0x2d18a60
02d18a60: str     x30, [sp, #-0x30]!                         
02d18a64: stp     x22, x21, [sp, #0x10]                      
02d18a68: stp     x20, x19, [sp, #0x20]                      
02d18a6c: adrp    x21, #0x662f000                            
02d18a70: mov     x19, x1                                    
02d18a74: mov     x20, x0                                    
02d18a78: ldrb    w8, [x21, #0xff1]                          
02d18a7c: tbnz    w8, #0, #0x2d18a94                         
02d18a80: adrp    x0, #0x6265000                             
02d18a84: ldr     x0, [x0, #0x3f0]                           T:UnityEngine.Events.UnityAction
02d18a88: bl      #0x2b70db0                                 fn_2b70db0
02d18a8c: mov     w8, #1                                     
02d18a90: strb    w8, [x21, #0xff1]                          
02d18a94: adrp    x22, #0x6265000                            
02d18a98: ldr     x22, [x22, #0x3f0]                         T:UnityEngine.Events.UnityAction
02d18a9c: ldr     x21, [x20, #0x28]!                         .OnRoomCompleted
02d18aa0: mov     x0, x21                                    
02d18aa4: mov     x1, x19                                    
02d18aa8: mov     x2, xzr                                    
02d18aac: bl      #0x4e57298                                 System.Delegate::Remove
02d18ab0: mov     x8, x0                                     
02d18ab4: cbz     x0, #0x2d18ac8                             
02d18ab8: ldr     x1, [x22]                                  M:AdsManager::<OnApplicationPause>b__26_0
02d18abc: ldr     x9, [x8]                                   
02d18ac0: cmp     x9, x1                                     
02d18ac4: b.ne    #0x2d18af4                                 
02d18ac8: mov     x0, x20                                    
02d18acc: mov     x1, x8                                     
02d18ad0: mov     x2, x21                                    
02d18ad4: bl      #0x2ba9880                                 fn_2ba9880
02d18ad8: cmp     x0, x21                                    
02d18adc: mov     x21, x0                                    
02d18ae0: b.ne    #0x2d18aa0                                 
02d18ae4: ldp     x20, x19, [sp, #0x20]                      
02d18ae8: ldp     x22, x21, [sp, #0x10]                      
02d18aec: ldr     x30, [sp], #0x30                           
02d18af0: ret                                                
02d18af4: mov     x0, x8                                     
02d18af8: bl      #0x2b713dc                                 fn_2b713dc
## get_RoomConfig() -> DreamHouse.RoomConfig
---- DreamHouse.RoomController::get_RoomConfig 0x2d18afc
02d18afc: ldr     x0, [x0, #0x40]                            ._roomConfig
02d18b00: ret                                                
## get_CurrentDecorItem() -> DreamHouse.DecorItem
---- DreamHouse.RoomController::get_CurrentDecorItem 0x2d18b04
02d18b04: ldr     x0, [x0, #0x50]                            .<CurrentDecorItem>k__BackingField
02d18b08: ret                                                
## set_CurrentDecorItem(DreamHouse.DecorItem value) -> void
---- DreamHouse.RoomController::set_CurrentDecorItem 0x2d18b0c
02d18b0c: str     x1, [x0, #0x50]!                           .<CurrentDecorItem>k__BackingField
02d18b10: b       #0x2b70d54                                 
## get_CurrentStep() -> int
---- DreamHouse.RoomController::get_CurrentStep 0x2d18b14
02d18b14: ldr     w0, [x0, #0x48]                            ._currentStep
02d18b18: ret                                                
## OnDestroy() -> void
---- DreamHouse.RoomController::OnDestroy 0x2d18b1c
02d18b1c: stp     x30, x19, [sp, #-0x10]!                    
02d18b20: mov     x1, xzr                                    
02d18b24: mov     x19, x0                                    
02d18b28: str     xzr, [x0, #0x20]!                          .OnStepChanged
02d18b2c: bl      #0x2b70d54                                 fn_2b70d54
02d18b30: str     xzr, [x19, #0x28]!                         .OnRoomCompleted
02d18b34: mov     x0, x19                                    
02d18b38: mov     x1, xzr                                    
02d18b3c: ldp     x30, x19, [sp], #0x10                      
02d18b40: b       #0x2b70d54                                 
## Initialize(DreamHouse.RoomConfig roomConfig, DreamHouse.DreamHouseController dreamHouseController) -> void
---- DreamHouse.RoomController::Initialize 0x2d17f6c
02d17f6c: sub     sp, sp, #0x90                              
02d17f70: stp     x29, x30, [sp, #0x30]                      
02d17f74: stp     x28, x27, [sp, #0x40]                      
02d17f78: stp     x26, x25, [sp, #0x50]                      
02d17f7c: stp     x24, x23, [sp, #0x60]                      
02d17f80: stp     x22, x21, [sp, #0x70]                      
02d17f84: stp     x20, x19, [sp, #0x80]                      
02d17f88: adrp    x21, #0x662f000                            
02d17f8c: mov     x22, x2                                    
02d17f90: mov     x20, x1                                    
02d17f94: ldrb    w8, [x21, #0xff2]                          
02d17f98: mov     x19, x0                                    
02d17f9c: tbnz    w8, #0, #0x2d1802c                         
02d17fa0: adrp    x0, #0x6269000                             
02d17fa4: ldr     x0, [x0, #0xa28]                           T:type6867(k15)
02d17fa8: bl      #0x2b70db0                                 fn_2b70db0
02d17fac: adrp    x0, #0x6269000                             
02d17fb0: ldr     x0, [x0, #0x978]                           MS:System.Collections.Generic.Dictionary`2::GetEnumerator
02d17fb4: bl      #0x2b70db0                                 fn_2b70db0
02d17fb8: adrp    x0, #0x6269000                             
02d17fbc: ldr     x0, [x0, #0x990]                           MS:System.Collections.Generic.Dictionary`2/Enumerator::Dispose
02d17fc0: bl      #0x2b70db0                                 fn_2b70db0
02d17fc4: adrp    x0, #0x6269000                             
02d17fc8: ldr     x0, [x0, #0x998]                           MS:System.Collections.Generic.Dictionary`2/Enumerator::MoveNext
02d17fcc: bl      #0x2b70db0                                 fn_2b70db0
02d17fd0: adrp    x0, #0x6269000                             
02d17fd4: ldr     x0, [x0, #0x9a0]                           MS:System.Collections.Generic.Dictionary`2/Enumerator::get_Current
02d17fd8: bl      #0x2b70db0                                 fn_2b70db0
02d17fdc: adrp    x0, #0x6269000                             
02d17fe0: ldr     x0, [x0, #0x9a8]                           MS:System.Collections.Generic.KeyValuePair`2::get_Key
02d17fe4: bl      #0x2b70db0                                 fn_2b70db0
02d17fe8: adrp    x0, #0x6269000                             
02d17fec: ldr     x0, [x0, #0x9b0]                           MS:System.Collections.Generic.KeyValuePair`2::get_Value
02d17ff0: bl      #0x2b70db0                                 fn_2b70db0
02d17ff4: adrp    x0, #0x6269000                             
02d17ff8: ldr     x0, [x0, #0xa30]                           MS:System.Collections.Generic.List`1::get_Count
02d17ffc: bl      #0x2b70db0                                 fn_2b70db0
02d18000: adrp    x0, #0x6269000                             
02d18004: ldr     x0, [x0, #0xa38]                           MS:System.Collections.Generic.List`1::get_Item
02d18008: bl      #0x2b70db0                                 fn_2b70db0
02d1800c: adrp    x0, #0x6269000                             
02d18010: ldr     x0, [x0, #0xa40]                           M:DreamHouse.RoomController::OnMarkPointButtonPressed
02d18014: bl      #0x2b70db0                                 fn_2b70db0
02d18018: adrp    x0, #0x6269000                             
02d1801c: ldr     x0, [x0, #0xa48]                           T:DreamHouse.RoomController
02d18020: bl      #0x2b70db0                                 fn_2b70db0
02d18024: mov     w8, #1                                     
02d18028: strb    w8, [x21, #0xff2]                          
02d1802c: movi    v0.2d, #0000000000000000                   
02d18030: mov     x0, x19                                    
02d18034: mov     x1, x20                                    
02d18038: str     x20, [x0, #0x40]!                          ._roomConfig
02d1803c: stp     q0, q0, [sp, #0x10]                        
02d18040: bl      #0x2b70d54                                 fn_2b70d54
02d18044: mov     x21, x19                                   
02d18048: mov     x1, x22                                    
02d1804c: str     x22, [x21, #0x38]!                         ._dreamHouseController
02d18050: mov     x0, x21                                    
02d18054: bl      #0x2b70d54                                 fn_2b70d54
02d18058: ldur    x0, [x21, #-8]                             
02d1805c: cbz     x0, #0x2d180f4                             
02d18060: adrp    x28, #0x6269000                            
02d18064: adrp    x27, #0x6269000                            
02d18068: adrp    x26, #0x6269000                            
02d1806c: adrp    x29, #0x6269000                            
02d18070: ldr     x28, [x28, #0xa38]                         MS:System.Collections.Generic.List`1::get_Item
02d18074: ldr     x27, [x27, #0xa28]                         T:type6867(k15)
02d18078: ldr     x26, [x26, #0xa40]                         M:DreamHouse.RoomController::OnMarkPointButtonPressed
02d1807c: ldr     x29, [x29, #0x998]                         MS:System.Collections.Generic.Dictionary`2/Enumerator::MoveNext
02d18080: mov     w22, wzr                                   
02d18084: ldr     w8, [x0, #0x18]                            M:Trading.TradingSession::<ValidateTrade>b__57_0
02d18088: cmp     w22, w8                                    
02d1808c: b.ge    #0x2d180f8                                 
02d18090: ldr     x2, [x28]                                  T:Trading.TradingSession/<>c__DisplayClass56_0
02d18094: mov     w1, w22                                    
02d18098: bl      #0x35a8f3c                                 fn_35a8f3c
02d1809c: cbz     x20, #0x2d180f4                            
02d180a0: mov     x23, x0                                    
02d180a4: mov     x0, x20                                    
02d180a8: mov     w1, w22                                    
02d180ac: bl      #0x2d15b28                                 DreamHouse.RoomConfig::GetDecorItemAssetByIndex
02d180b0: ldr     x8, [x27]                                  T:Trading.TradingSession/<>c__DisplayClass56_0
02d180b4: mov     x24, x0                                    
02d180b8: mov     x0, x8                                     
02d180bc: bl      #0x2b7104c                                 fn_2b7104c
02d180c0: ldr     x2, [x26]                                  T:Trading.TradingSession/<>c__DisplayClass56_0
02d180c4: mov     x1, x19                                    
02d180c8: mov     x3, xzr                                    
02d180cc: mov     x25, x0                                    
02d180d0: bl      #0x453418c                                 fn_453418c
02d180d4: cbz     x23, #0x2d180f4                            
02d180d8: mov     x0, x23                                    
02d180dc: mov     x1, x24                                    
02d180e0: mov     x2, x25                                    
02d180e4: bl      #0x2d174c0                                 DreamHouse.DecorItem::OnInit
02d180e8: ldr     x0, [x19, #0x30]                           ._decorItems
02d180ec: add     w22, w22, #1                               
02d180f0: cbnz    x0, #0x2d18084                             
02d180f4: bl      #0x2b7105c                                 fn_2b7105c
02d180f8: ldr     x8, [x21]                                  &2b706c4(=eb01011ff9400808)
02d180fc: cbz     x8, #0x2d180f4                             
02d18100: ldr     x0, [x8, #0x30]                            
02d18104: cbz     x0, #0x2d180f4                             
02d18108: bl      #0x2d1733c                                 DreamHouse.DataDreamHouse::GetCurrentRoomStep
02d1810c: ldr     x8, [x19, #0x30]                           ._decorItems
02d18110: str     w0, [x19, #0x48]                           ._currentStep
02d18114: cbz     x8, #0x2d180f4                             
02d18118: ldr     w9, [x8, #0x18]                            
02d1811c: mov     w1, w0                                     
02d18120: cmp     w0, w9                                     
02d18124: b.ge    #0x2d18158                                 
02d18128: ldr     x2, [x28]                                  T:Trading.TradingSession/<>c__DisplayClass56_0
02d1812c: mov     x0, x8                                     
02d18130: bl      #0x35a8f3c                                 fn_35a8f3c
02d18134: mov     x20, x19                                   
02d18138: mov     x1, x0                                     
02d1813c: str     x0, [x20, #0x50]!                          .<CurrentDecorItem>k__BackingField
02d18140: mov     x0, x20                                    
02d18144: bl      #0x2b70d54                                 fn_2b70d54
02d18148: ldr     x0, [x20]                                  
02d1814c: cbz     x0, #0x2d180f4                             
02d18150: mov     w1, #1                                     
02d18154: bl      #0x2d17600                                 DreamHouse.DecorItem::SetActiveMarkPoint
02d18158: ldr     x8, [x21]                                  &2b706c4(=eb01011ff9400808)
02d1815c: cbz     x8, #0x2d180f4                             
02d18160: ldr     x8, [x8, #0x30]                            
02d18164: cbz     x8, #0x2d180f4                             
02d18168: ldr     x8, [x8, #0x20]                            
02d1816c: cbz     x8, #0x2d180f4                             
02d18170: ldr     x0, [x8, #0x20]                            
02d18174: cbz     x0, #0x2d180f4                             
02d18178: adrp    x8, #0x6269000                             
02d1817c: add     x20, sp, #0x10                             
02d18180: ldr     x8, [x8, #0x978]                           MS:System.Collections.Generic.Dictionary`2::GetEnumerator
02d18184: ldr     x1, [x8]                                   T:Trading.TradingSession/<>c__DisplayClass56_0
02d18188: add     x8, sp, #0x10                              
02d1818c: bl      #0x44accc8                                 fn_44accc8
02d18190: stp     xzr, x20, [sp]                             
02d18194: ldr     x1, [x29]                                  T:Trading.TradingSession/<>c__DisplayClass56_0
02d18198: add     x0, sp, #0x10                              
02d1819c: bl      #0x46e504c                                 fn_46e504c
02d181a0: tbz     w0, #0, #0x2d181cc                         
02d181a4: ldr     x0, [x19, #0x30]                           ._decorItems
02d181a8: cbz     x0, #0x2d18228                             
02d181ac: ldr     x20, [sp, #0x20]                           
02d181b0: ldr     x2, [x28]                                  T:Trading.TradingSession/<>c__DisplayClass56_0
02d181b4: mov     w1, w20                                    
02d181b8: bl      #0x35a8f3c                                 fn_35a8f3c
02d181bc: cbz     x0, #0x2d1822c                             
02d181c0: lsr     x1, x20, #0x20                             
02d181c4: bl      #0x2d1764c                                 DreamHouse.DecorItem::CreateDecorItemObject
02d181c8: b       #0x2d18194                                 
02d181cc: adrp    x8, #0x6269000                             
02d181d0: add     x0, sp, #0x10                              
02d181d4: ldr     x8, [x8, #0x990]                           MS:System.Collections.Generic.Dictionary`2/Enumerator::Dispose
02d181d8: ldr     x1, [x8]                                   T:Trading.TradingSession/<>c__DisplayClass56_0
02d181dc: bl      #0x46e5154                                 fn_46e5154
02d181e0: adrp    x8, #0x6269000                             
02d181e4: ldr     x8, [x8, #0xa48]                           T:DreamHouse.RoomController
02d181e8: ldr     x8, [x8]                                   T:Trading.TradingSession/<>c__DisplayClass56_0
02d181ec: ldr     x8, [x8, #0xb8]                            T:Trading.TradingSession/<>c__DisplayClass68_0
02d181f0: ldr     x8, [x8]                                   T:Trading.TradingSession/<>c__DisplayClass56_0
02d181f4: cbz     x8, #0x2d18208                             
02d181f8: ldr     x9, [x8, #0x18]                            M:Trading.TradingSession::<ValidateTrade>b__57_0
02d181fc: ldr     x0, [x8, #0x40]                            MS:System.Linq.Enumerable::Select
02d18200: ldr     x1, [x8, #0x28]                            T:Trading.TradingCounterRequest
02d18204: blr     x9                                         
02d18208: ldp     x20, x19, [sp, #0x80]                      
02d1820c: ldp     x22, x21, [sp, #0x70]                      
02d18210: ldp     x24, x23, [sp, #0x60]                      
02d18214: ldp     x26, x25, [sp, #0x50]                      
02d18218: ldp     x28, x27, [sp, #0x40]                      
02d1821c: ldp     x29, x30, [sp, #0x30]                      
02d18220: add     sp, sp, #0x90                              
02d18224: ret                                                
02d18228: bl      #0x2b7105c                                 fn_2b7105c
02d1822c: bl      #0x2b7105c                                 fn_2b7105c
02d18230: b       #0x2d18240                                 
02d18234: b       #0x2d18240                                 
02d18238: b       #0x2d18240                                 
02d1823c: b       #0x2d18240                                 
02d18240: mov     x19, x0                                    
02d18244: cmp     w1, #1                                     
02d18248: b.ne    #0x2d18284                                 
02d1824c: mov     x0, x19                                    
02d18250: bl      #0x5e90260                                 fn_5e90260
02d18254: ldr     x19, [x0]                                  T:Trading.TradingSession/<>c__DisplayClass56_0
02d18258: str     x19, [sp]                                  
02d1825c: bl      #0x5e90270                                 fn_5e90270
02d18260: adrp    x8, #0x6269000                             
02d18264: ldr     x0, [sp, #8]                               
02d18268: ldr     x8, [x8, #0x990]                           MS:System.Collections.Generic.Dictionary`2/Enumerator::Dispose
02d1826c: ldr     x1, [x8]                                   T:Trading.TradingSession/<>c__DisplayClass56_0
02d18270: bl      #0x46e5154                                 fn_46e5154
02d18274: cbz     x19, #0x2d181e0                            
02d18278: mov     x0, x19                                    
02d1827c: bl      #0x2b71054                                 fn_2b71054
02d18280: mov     x19, x0                                    
02d18284: mov     x0, sp                                     
02d18288: bl      #0x2737fb4                                 fn_2737fb4
02d1828c: mov     x0, x19                                    
02d18290: bl      #0x2c6051c                                 fn_2c6051c
02d18294: bl      #0x27369b8                                 fn_27369b8
## NextStep() -> void
---- DreamHouse.RoomController::NextStep 0x2d18b44
02d18b44: str     x30, [sp, #-0x20]!                         
02d18b48: stp     x20, x19, [sp, #0x10]                      
02d18b4c: adrp    x20, #0x662f000                            
02d18b50: mov     x19, x0                                    
02d18b54: ldrb    w8, [x20, #0xff3]                          
02d18b58: tbnz    w8, #0, #0x2d18bac                         
02d18b5c: adrp    x0, #0x6269000                             
02d18b60: ldr     x0, [x0, #0x9e8]                           MS:DataManager::GetData
02d18b64: bl      #0x2b70db0                                 fn_2b70db0
02d18b68: adrp    x0, #0x6263000                             
02d18b6c: ldr     x0, [x0, #0x928]                           T:UnityEngine.Debug
02d18b70: bl      #0x2b70db0                                 fn_2b70db0
02d18b74: adrp    x0, #0x6269000                             
02d18b78: ldr     x0, [x0, #0xa30]                           MS:System.Collections.Generic.List`1::get_Count
02d18b7c: bl      #0x2b70db0                                 fn_2b70db0
02d18b80: adrp    x0, #0x6269000                             
02d18b84: ldr     x0, [x0, #0xa38]                           MS:System.Collections.Generic.List`1::get_Item
02d18b88: bl      #0x2b70db0                                 fn_2b70db0
02d18b8c: adrp    x0, #0x6266000                             
02d18b90: ldr     x0, [x0, #0x658]                           MS:MonoSingleton`1::get_Instance
02d18b94: bl      #0x2b70db0                                 fn_2b70db0
02d18b98: adrp    x0, #0x6269000                             
02d18b9c: ldr     x0, [x0, #0xa70]                           S:'No more steps available.'
02d18ba0: bl      #0x2b70db0                                 fn_2b70db0
02d18ba4: mov     w8, #1                                     
02d18ba8: strb    w8, [x20, #0xff3]                          
02d18bac: ldr     x8, [x19, #0x30]                           ._decorItems
02d18bb0: cbz     x8, #0x2d18d2c                             
02d18bb4: ldr     w8, [x8, #0x18]                            
02d18bb8: ldr     w9, [x19, #0x48]                           ._currentStep
02d18bbc: sub     w8, w8, #1                                 
02d18bc0: cmp     w9, w8                                     
02d18bc4: b.ge    #0x2d18c44                                 
02d18bc8: mov     x20, x19                                   
02d18bcc: ldr     x0, [x20, #0x50]!                          &2b70708(=eb01011ff9400808) .<CurrentDecorItem>k__BackingField
02d18bd0: cbz     x0, #0x2d18d2c                             
02d18bd4: mov     w1, wzr                                    
02d18bd8: bl      #0x2d17600                                 DreamHouse.DecorItem::SetActiveMarkPoint
02d18bdc: ldr     w8, [x19, #0x48]                           ._currentStep
02d18be0: ldr     x0, [x19, #0x30]                           ._decorItems
02d18be4: add     w1, w8, #1                                 
02d18be8: str     w1, [x19, #0x48]                           ._currentStep
02d18bec: cbz     x0, #0x2d18d2c                             
02d18bf0: adrp    x8, #0x6269000                             
02d18bf4: ldr     x8, [x8, #0xa38]                           MS:System.Collections.Generic.List`1::get_Item
02d18bf8: ldr     x2, [x8]                                   T:Trading.TradingSession/<>c__DisplayClass56_0
02d18bfc: bl      #0x35a8f3c                                 fn_35a8f3c
02d18c00: mov     x1, x0                                     
02d18c04: str     x0, [x20]                                  
02d18c08: mov     x0, x20                                    
02d18c0c: bl      #0x2b70d54                                 fn_2b70d54
02d18c10: ldr     x0, [x20]                                  &2b706c4(=eb01011ff9400808)
02d18c14: cbz     x0, #0x2d18d2c                             
02d18c18: mov     w1, #1                                     
02d18c1c: bl      #0x2d17600                                 DreamHouse.DecorItem::SetActiveMarkPoint
02d18c20: ldr     x8, [x19, #0x20]                           .OnStepChanged
02d18c24: cbz     x8, #0x2d18d20                             
02d18c28: ldr     w1, [x19, #0x48]                           ._currentStep
02d18c2c: ldp     x20, x19, [sp, #0x10]                      
02d18c30: ldr     x0, [x8, #0x40]                            MS:System.Linq.Enumerable::Select
02d18c34: ldr     x2, [x8, #0x28]                            T:Trading.TradingCounterRequest
02d18c38: ldr     x3, [x8, #0x18]                            M:Trading.TradingSession::<ValidateTrade>b__57_0
02d18c3c: ldr     x30, [sp], #0x20                           
02d18c40: br      x3                                         
02d18c44: adrp    x8, #0x6263000                             
02d18c48: ldr     x8, [x8, #0x928]                           T:UnityEngine.Debug
02d18c4c: ldr     x0, [x8]                                   &2c5bbd4(=a9bd7bfdd503233f)
02d18c50: ldr     w8, [x0, #0xe4]                            [62690e4]=0 f=0,0
02d18c54: cbnz    w8, #0x2d18c5c                             
02d18c58: bl      #0x2b70f30                                 fn_2b70f30
02d18c5c: adrp    x8, #0x6269000                             
02d18c60: mov     x1, xzr                                    
02d18c64: ldr     x8, [x8, #0xa70]                           S:'No more steps available.'
02d18c68: ldr     x0, [x8]                                   T:Trading.TradingSession/<>c__DisplayClass56_0
02d18c6c: bl      #0x5af21f4                                 UnityEngine.Debug::Log
02d18c70: mov     x20, x19                                   
02d18c74: mov     x1, xzr                                    
02d18c78: str     xzr, [x20, #0x50]!                         .<CurrentDecorItem>k__BackingField
02d18c7c: mov     x0, x20                                    
02d18c80: bl      #0x2b70d54                                 fn_2b70d54
02d18c84: ldur    x8, [x20, #-0x30]                          
02d18c88: cbz     x8, #0x2d18ca8                             
02d18c8c: ldr     x9, [x19, #0x30]                           ._decorItems
02d18c90: cbz     x9, #0x2d18d2c                             
02d18c94: ldr     w1, [x9, #0x18]                            
02d18c98: ldr     x9, [x8, #0x18]                            M:Trading.TradingSession::<ValidateTrade>b__57_0
02d18c9c: ldr     x0, [x8, #0x40]                            MS:System.Linq.Enumerable::Select
02d18ca0: ldr     x2, [x8, #0x28]                            T:Trading.TradingCounterRequest
02d18ca4: blr     x9                                         
02d18ca8: ldr     x0, [x19, #0x38]                           ._dreamHouseController
02d18cac: cbz     x0, #0x2d18d2c                             
02d18cb0: bl      #0x2d1832c                                 DreamHouse.DreamHouseController::UnlockNextRoom
02d18cb4: ldr     x8, [x19, #0x28]                           .OnRoomCompleted
02d18cb8: cbz     x8, #0x2d18ccc                             
02d18cbc: ldr     x9, [x8, #0x18]                            M:Trading.TradingSession::<ValidateTrade>b__57_0
02d18cc0: ldr     x0, [x8, #0x40]                            MS:System.Linq.Enumerable::Select
02d18cc4: ldr     x1, [x8, #0x28]                            T:Trading.TradingCounterRequest
02d18cc8: blr     x9                                         
02d18ccc: adrp    x8, #0x6266000                             
02d18cd0: ldr     x8, [x8, #0x658]                           MS:MonoSingleton`1::get_Instance
02d18cd4: ldr     x0, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d18cd8: bl      #0x3769600                                 fn_3769600
02d18cdc: cbz     x0, #0x2d18d2c                             
02d18ce0: adrp    x8, #0x6269000                             
02d18ce4: ldr     x8, [x8, #0x9e8]                           MS:DataManager::GetData
02d18ce8: ldr     x1, [x8]                                   T:Trading.TradingSession/<>c__DisplayClass56_0
02d18cec: bl      #0x3168dd0                                 fn_3168dd0
02d18cf0: cbz     x0, #0x2d18d2c                             
02d18cf4: ldr     x8, [x0, #0x20]                            M:Trading.TradingSession::<ValidateTrade>b__57_1 .OnStepChanged
02d18cf8: cbz     x8, #0x2d18d2c                             
02d18cfc: ldrb    w9, [x8, #0x10]                            
02d18d00: cbz     w9, #0x2d18d20                             
02d18d04: strb    wzr, [x8, #0x10]                           
02d18d08: ldp     x20, x19, [sp, #0x10]                      
02d18d0c: ldr     x8, [x0]                                   T:Trading.TradingSession/<>c__DisplayClass56_0
02d18d10: ldr     x1, [x8, #0x260]                           M:Trading.PopupTradingEmptyCollection::OnBtnLaterClick
02d18d14: ldr     x2, [x8, #0x258]                           M:Trading.PopupTradingEmptyCollection::OnBtnGoDiyClick
02d18d18: ldr     x30, [sp], #0x20                           
02d18d1c: br      x2                                         
02d18d20: ldp     x20, x19, [sp, #0x10]                      
02d18d24: ldr     x30, [sp], #0x20                           
02d18d28: ret                                                
02d18d2c: bl      #0x2b7105c                                 fn_2b7105c
## IsFirstStep() -> bool
---- DreamHouse.RoomController::IsFirstStep 0x2d18d30
02d18d30: ldr     w8, [x0, #0x48]                            ._currentStep
02d18d34: cmp     w8, #0                                     
02d18d38: cset    w0, eq                                     
02d18d3c: ret                                                
## OnMarkPointButtonPressed(DreamHouse.DecorItem decorItem) -> void
---- DreamHouse.RoomController::OnMarkPointButtonPressed 0x2d18d40
02d18d40: stp     x30, x21, [sp, #-0x20]!                    
02d18d44: stp     x20, x19, [sp, #0x10]                      
02d18d48: adrp    x20, #0x662f000                            
02d18d4c: adrp    x21, #0x6269000                            
02d18d50: mov     x19, x0                                    
02d18d54: ldrb    w8, [x20, #0xff4]                          
02d18d58: ldr     x21, [x21, #0xa78]                         T:DreamHouse.RoomController/<>c__DisplayClass25_0
02d18d5c: tbnz    w8, #0, #0x2d18db0                         
02d18d60: adrp    x0, #0x6269000                             
02d18d64: ldr     x0, [x0, #0xa08]                           MS:MonoSingleton`1::get_Instance
02d18d68: bl      #0x2b70db0                                 fn_2b70db0
02d18d6c: adrp    x0, #0x6269000                             
02d18d70: ldr     x0, [x0, #0xa80]                           MS:MonoSingleton`1::get_Instance
02d18d74: bl      #0x2b70db0                                 fn_2b70db0
02d18d78: adrp    x0, #0x6263000                             
02d18d7c: ldr     x0, [x0, #0x918]                           T:UnityEngine.Object
02d18d80: bl      #0x2b70db0                                 fn_2b70db0
02d18d84: adrp    x0, #0x6264000                             
02d18d88: ldr     x0, [x0, #0xe8]                            T:DG.Tweening.TweenCallback
02d18d8c: bl      #0x2b70db0                                 fn_2b70db0
02d18d90: adrp    x0, #0x6269000                             
02d18d94: ldr     x0, [x0, #0xa88]                           M:DreamHouse.RoomController/<>c__DisplayClass25_0::<OnMarkPointButtonPressed>b__0
02d18d98: bl      #0x2b70db0                                 fn_2b70db0
02d18d9c: adrp    x0, #0x6269000                             
02d18da0: ldr     x0, [x0, #0xa78]                           T:DreamHouse.RoomController/<>c__DisplayClass25_0
02d18da4: bl      #0x2b70db0                                 fn_2b70db0
02d18da8: mov     w8, #1                                     
02d18dac: strb    w8, [x20, #0xff4]                          
02d18db0: ldr     x0, [x21]                                  T:Trading.TradingSession/<>c__DisplayClass56_0
02d18db4: bl      #0x2b7104c                                 fn_2b7104c
02d18db8: mov     x1, xzr                                    
02d18dbc: mov     x20, x0                                    
02d18dc0: bl      #0x2d19338                                 DreamHouse.RoomController/<>c__DisplayClass25_0::.ctor
02d18dc4: cbz     x20, #0x2d18efc                            
02d18dc8: adrp    x21, #0x6263000                            
02d18dcc: mov     x0, x20                                    
02d18dd0: mov     x1, x19                                    
02d18dd4: ldr     x21, [x21, #0x918]                         T:UnityEngine.Object
02d18dd8: str     x19, [x0, #0x10]!                          
02d18ddc: bl      #0x2b70d54                                 fn_2b70d54
02d18de0: ldr     x0, [x21]                                  &2c5bbd4(=a9bd7bfdd503233f)
02d18de4: ldr     x21, [x19, #0x50]                          .<CurrentDecorItem>k__BackingField
02d18de8: ldr     w8, [x0, #0xe4]                            [62690e4]=0 f=0,0
02d18dec: cbnz    w8, #0x2d18df4                             
02d18df0: bl      #0x2b70f30                                 fn_2b70f30
02d18df4: mov     x0, x21                                    
02d18df8: mov     x1, xzr                                    
02d18dfc: mov     x2, xzr                                    
02d18e00: bl      #0x5b37d84                                 UnityEngine.Object::op_Equality
02d18e04: tbz     w0, #0, #0x2d18e14                         
02d18e08: ldp     x20, x19, [sp, #0x10]                      
02d18e0c: ldp     x30, x21, [sp], #0x20                      
02d18e10: ret                                                
02d18e14: mov     x0, xzr                                    
02d18e18: bl      #0x2d6eec8                                 Framework.AudioManager::get_Instance
02d18e1c: cbz     x0, #0x2d18efc                             
02d18e20: movi    d1, #0000000000000000                      
02d18e24: movi    d2, #0000000000000000                      
02d18e28: mov     w1, #1                                     
02d18e2c: fmov    s0, #1.00000000                            
02d18e30: mov     w2, wzr                                    
02d18e34: mov     w3, wzr                                    
02d18e38: mov     x4, xzr                                    
02d18e3c: bl      #0x2d6f03c                                 Framework.AudioManager::PlaySound
02d18e40: ldr     x0, [x19, #0x50]                           .<CurrentDecorItem>k__BackingField
02d18e44: cbz     x0, #0x2d18efc                             
02d18e48: mov     w1, wzr                                    
02d18e4c: bl      #0x2d17600                                 DreamHouse.DecorItem::SetActiveMarkPoint
02d18e50: ldr     x0, [x19, #0x40]                           ._roomConfig
02d18e54: cbz     x0, #0x2d18efc                             
02d18e58: ldr     w1, [x19, #0x48]                           ._currentStep
02d18e5c: bl      #0x2d15b28                                 DreamHouse.RoomConfig::GetDecorItemAssetByIndex
02d18e60: mov     x1, x0                                     
02d18e64: mov     x0, x20                                    
02d18e68: str     x1, [x0, #0x18]!                           
02d18e6c: bl      #0x2b70d54                                 fn_2b70d54
02d18e70: adrp    x8, #0x6264000                             
02d18e74: ldr     x8, [x8, #0xe8]                            T:DG.Tweening.TweenCallback
02d18e78: ldr     x0, [x8]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d18e7c: bl      #0x2b7104c                                 fn_2b7104c
02d18e80: adrp    x8, #0x6269000                             
02d18e84: mov     x1, x20                                    
02d18e88: mov     x3, xzr                                    
02d18e8c: ldr     x8, [x8, #0xa88]                           M:DreamHouse.RoomController/<>c__DisplayClass25_0::<OnMarkPointButtonPressed>b__0
02d18e90: mov     x19, x0                                    
02d18e94: ldr     x2, [x8]                                   T:Trading.TradingSession/<>c__DisplayClass56_0
02d18e98: bl      #0x2d89dc4                                 DG.Tweening.TweenCallback::.ctor
02d18e9c: adrp    x8, #0x1084000                             
02d18ea0: mov     x0, x19                                    
02d18ea4: mov     w1, #1                                     
02d18ea8: ldr     s0, [x8, #0xeec]                           [1084eec]=457ff0003dcccccd f=0.1,4095
02d18eac: mov     x2, xzr                                    
02d18eb0: bl      #0x2d8f37c                                 DG.Tweening.DOVirtual::DelayedCall
02d18eb4: adrp    x8, #0x6269000                             
02d18eb8: ldr     x8, [x8, #0xa80]                           MS:MonoSingleton`1::get_Instance
02d18ebc: ldr     x0, [x8]                                   T:Trading.TradingSession/<>c__DisplayClass56_0
02d18ec0: bl      #0x3769600                                 fn_3769600
02d18ec4: cbz     x0, #0x2d18efc                             
02d18ec8: mov     w1, wzr                                    
02d18ecc: mov     w2, wzr                                    
02d18ed0: mov     x3, xzr                                    
02d18ed4: bl      #0x2d19814                                 DreamHouse.TutorialHandler::SetActiveHandTutorial
02d18ed8: adrp    x8, #0x6269000                             
02d18edc: ldr     x8, [x8, #0xa08]                           MS:MonoSingleton`1::get_Instance
02d18ee0: ldr     x0, [x8]                                   T:Trading.TradingSession/<>c__DisplayClass56_0
02d18ee4: bl      #0x3769600                                 fn_3769600
02d18ee8: cbz     x0, #0x2d18efc                             
02d18eec: ldp     x20, x19, [sp, #0x10]                      
02d18ef0: mov     x1, xzr                                    
02d18ef4: ldp     x30, x21, [sp], #0x20                      
02d18ef8: b       #0x2cae8a8                                 DreamHouseFirstGameTutorial::HideTutorial
02d18efc: bl      #0x2b7105c                                 fn_2b7105c
## .ctor() -> void
---- DreamHouse.RoomController::.ctor 0x2d18f00
02d18f00: mov     x1, xzr                                    
02d18f04: b       #0x5b397b0                                 UnityEngine.MonoBehaviour::.ctor
02d18f08: stp     x30, x23, [sp, #-0x30]!                    
02d18f0c: stp     x22, x21, [sp, #0x10]                      
02d18f10: stp     x20, x19, [sp, #0x20]                      
02d18f14: ldr     x8, [x3, #0x38]                            
02d18f18: mov     x20, x3                                    
02d18f1c: mov     x23, x2                                    
02d18f20: mov     x19, x1                                    
02d18f24: mov     x22, x0                                    
02d18f28: cbnz    x8, #0x2d18f48                             
02d18f2c: adrp    x0, #0x639c000                             
02d18f30: add     x0, x0, #0x188                             &639c188
02d18f34: bl      #0x2b70db0                                 fn_2b70db0
02d18f38: ldr     x8, [x20, #0x38]                           ._dreamHouseController
02d18f3c: cbnz    x8, #0x2d18f48                             
02d18f40: mov     x0, x20                                    
02d18f44: bl      #0x2ba9d7c                                 fn_2ba9d7c
02d18f48: ldr     x21, [x22]                                 
02d18f4c: cbnz    x21, #0x2d18f90                            
02d18f50: ldr     x8, [x20, #0x38]                           ._dreamHouseController
02d18f54: ldr     x0, [x8, #0x10]                            
02d18f58: add     x8, x0, #0x135                             &639c135
02d18f5c: ldrh    w8, [x8]                                   
02d18f60: tbnz    w8, #0, #0x2d18f68                         
02d18f64: bl      #0x2ba9d20                                 fn_2ba9d20
02d18f68: ldr     w8, [x0, #0xe4]                            [639c0e4]=200100e500000000 f=0,1.0927e-19
02d18f6c: cbnz    w8, #0x2d18f74                             
02d18f70: bl      #0x2b70f30                                 fn_2b70f30
02d18f74: ldr     x8, [x20, #0x38]                           ._dreamHouseController
02d18f78: mov     x0, x23                                    
02d18f7c: mov     x1, x22                                    
02d18f80: ldr     x2, [x8, #8]                               
02d18f84: bl      #0x3df6ffc                                 fn_3df6ffc
02d18f88: ldr     x21, [x22]                                 
02d18f8c: cbz     x21, #0x2d19010                            
02d18f90: adrp    x10, #0x6268000                            
02d18f94: ldr     x8, [x21]                                  
02d18f98: ldr     x10, [x10, #0xd8]                          T:Cysharp.Threading.Tasks.CompilerServices.IStateMachineRunnerPromise
02d18f9c: ldrh    w9, [x8, #0x12e]                           
02d18fa0: ldr     x1, [x10]                                  S:'{0}/2'
02d18fa4: cbz     x9, #0x2d18fc8                             
02d18fa8: ldr     x10, [x8, #0xb0]                           
02d18fac: add     x10, x10, #8                               &6268008
02d18fb0: ldur    x11, [x10, #-8]                            
02d18fb4: cmp     x11, x1                                    
02d18fb8: b.eq    #0x2d18fd8                                 
02d18fbc: subs    x9, x9, #1                                 
02d18fc0: add     x10, x10, #0x10                            &6268010
02d18fc4: b.ne    #0x2d18fb0                                 
02d18fc8: mov     x0, x21                                    
02d18fcc: mov     w2, wzr                                    
02d18fd0: bl      #0x2baa05c                                 fn_2baa05c
02d18fd4: b       #0x2d18fe4                                 
02d18fd8: ldrsw   x9, [x10]                                  
02d18fdc: add     x8, x8, x9, lsl #4                         
02d18fe0: add     x0, x8, #0x138                             
02d18fe4: ldp     x8, x1, [x0]                               
02d18fe8: mov     x0, x21                                    
02d18fec: blr     x8                                         
02d18ff0: ldr     x8, [x20, #0x38]                           ._dreamHouseController
02d18ff4: mov     x1, x0                                     
02d18ff8: mov     x0, x19                                    
02d18ffc: ldp     x20, x19, [sp, #0x20]                      
02d19000: ldp     x22, x21, [sp, #0x10]                      
02d19004: ldr     x2, [x8, #0x28]                            
02d19008: ldp     x30, x23, [sp], #0x30                      
02d1900c: b       #0x2ceb074                                 
02d19010: bl      #0x2b7105c                                 fn_2b7105c
02d19014: stp     x30, x23, [sp, #-0x30]!                    
02d19018: stp     x22, x21, [sp, #0x10]                      
02d1901c: stp     x20, x19, [sp, #0x20]                      
02d19020: ldr     x8, [x3, #0x38]                            
02d19024: mov     x20, x3                                    
02d19028: mov     x23, x2                                    
02d1902c: mov     x19, x1                                    
02d19030: mov     x22, x0                                    
02d19034: cbnz    x8, #0x2d19054                             
02d19038: adrp    x0, #0x639c000                             
02d1903c: add     x0, x0, #0x188                             &639c188
02d19040: bl      #0x2b70db0                                 fn_2b70db0
02d19044: ldr     x8, [x20, #0x38]                           ._dreamHouseController
02d19048: cbnz    x8, #0x2d19054                             
02d1904c: mov     x0, x20                                    
02d19050: bl      #0x2ba9d7c                                 fn_2ba9d7c
02d19054: ldr     x21, [x22]                                 
02d19058: cbnz    x21, #0x2d1909c                            
02d1905c: ldr     x8, [x20, #0x38]                           ._dreamHouseController
02d19060: ldr     x0, [x8, #0x10]                            
02d19064: add     x8, x0, #0x135                             &639c135
02d19068: ldrh    w8, [x8]                                   
02d1906c: tbnz    w8, #0, #0x2d19074                         
02d19070: bl      #0x2ba9d20                                 fn_2ba9d20
02d19074: ldr     w8, [x0, #0xe4]                            [639c0e4]=200100e500000000 f=0,1.0927e-19
02d19078: cbnz    w8, #0x2d19080                             
02d1907c: bl      #0x2b70f30                                 fn_2b70f30
02d19080: ldr     x8, [x20, #0x38]                           ._dreamHouseController
02d19084: mov     x0, x23                                    
02d19088: mov     x1, x22                                    
02d1908c: ldr     x2, [x8, #8]                               
02d19090: bl      #0x3df78dc                                 fn_3df78dc
02d19094: ldr     x21, [x22]                                 
02d19098: cbz     x21, #0x2d1911c                            
02d1909c: adrp    x10, #0x6268000                            
02d190a0: ldr     x8, [x21]                                  
02d190a4: ldr     x10, [x10, #0xd8]                          T:Cysharp.Threading.Tasks.CompilerServices.IStateMachineRunnerPromise
02d190a8: ldrh    w9, [x8, #0x12e]                           
02d190ac: ldr     x1, [x10]                                  S:'{0}/2'
02d190b0: cbz     x9, #0x2d190d4                             
02d190b4: ldr     x10, [x8, #0xb0]                           
02d190b8: add     x10, x10, #8                               &6268008
02d190bc: ldur    x11, [x10, #-8]                            
02d190c0: cmp     x11, x1                                    
02d190c4: b.eq    #0x2d190e4                                 
02d190c8: subs    x9, x9, #1                                 
02d190cc: add     x10, x10, #0x10                            &6268010
02d190d0: b.ne    #0x2d190bc                                 
02d190d4: mov     x0, x21                                    
02d190d8: mov     w2, wzr                                    
02d190dc: bl      #0x2baa05c                                 fn_2baa05c
02d190e0: b       #0x2d190f0                                 
02d190e4: ldrsw   x9, [x10]                                  
02d190e8: add     x8, x8, x9, lsl #4                         
02d190ec: add     x0, x8, #0x138                             
02d190f0: ldp     x8, x1, [x0]                               
02d190f4: mov     x0, x21                                    
02d190f8: blr     x8                                         
02d190fc: ldr     x8, [x20, #0x38]                           ._dreamHouseController
02d19100: mov     x1, x0                                     
02d19104: mov     x0, x19                                    
02d19108: ldp     x20, x19, [sp, #0x20]                      
02d1910c: ldp     x22, x21, [sp, #0x10]                      
02d19110: ldr     x2, [x8, #0x28]                            
02d19114: ldp     x30, x23, [sp], #0x30                      
02d19118: b       #0x2ceb074                                 
02d1911c: bl      #0x2b7105c                                 fn_2b7105c
02d19120: stp     x30, x23, [sp, #-0x30]!                    
02d19124: stp     x22, x21, [sp, #0x10]                      
02d19128: stp     x20, x19, [sp, #0x20]                      
02d1912c: ldr     x8, [x3, #0x38]                            
02d19130: mov     x20, x3                                    
02d19134: mov     x23, x2                                    
02d19138: mov     x19, x1                                    
02d1913c: mov     x22, x0                                    
02d19140: cbnz    x8, #0x2d19160                             
02d19144: adrp    x0, #0x639c000                             
02d19148: add     x0, x0, #0x188                             &639c188
02d1914c: bl      #0x2b70db0                                 fn_2b70db0
02d19150: ldr     x8, [x20, #0x38]                           ._dreamHouseController
02d19154: cbnz    x8, #0x2d19160                             
02d19158: mov     x0, x20                                    
02d1915c: bl      #0x2ba9d7c                                 fn_2ba9d7c
02d19160: ldr     x21, [x22]                                 
02d19164: cbnz    x21, #0x2d191a8                            
02d19168: ldr     x8, [x20, #0x38]                           ._dreamHouseController
02d1916c: ldr     x0, [x8, #0x10]                            
02d19170: add     x8, x0, #0x135                             &639c135
02d19174: ldrh    w8, [x8]                                   
02d19178: tbnz    w8, #0, #0x2d19180                         
02d1917c: bl      #0x2ba9d20                                 fn_2ba9d20
02d19180: ldr     w8, [x0, #0xe4]                            [639c0e4]=200100e500000000 f=0,1.0927e-19
02d19184: cbnz    w8, #0x2d1918c                             
02d19188: bl      #0x2b70f30                                 fn_2b70f30
02d1918c: ldr     x8, [x20, #0x38]                           ._dreamHouseController
02d19190: mov     x0, x23                                    
02d19194: mov     x1, x22                                    
02d19198: ldr     x2, [x8, #8]                               
02d1919c: bl      #0x3df81c4                                 fn_3df81c4
02d191a0: ldr     x21, [x22]                                 
02d191a4: cbz     x21, #0x2d19228                            
02d191a8: adrp    x10, #0x6268000                            
02d191ac: ldr     x8, [x21]                                  
02d191b0: ldr     x10, [x10, #0xd8]                          T:Cysharp.Threading.Tasks.CompilerServices.IStateMachineRunnerPromise
02d191b4: ldrh    w9, [x8, #0x12e]                           
02d191b8: ldr     x1, [x10]                                  S:'{0}/2'
02d191bc: cbz     x9, #0x2d191e0                             
02d191c0: ldr     x10, [x8, #0xb0]                           
02d191c4: add     x10, x10, #8                               &6268008
02d191c8: ldur    x11, [x10, #-8]                            
02d191cc: cmp     x11, x1                                    
02d191d0: b.eq    #0x2d191f0                                 
02d191d4: subs    x9, x9, #1                                 
02d191d8: add     x10, x10, #0x10                            &6268010
02d191dc: b.ne    #0x2d191c8                                 
02d191e0: mov     x0, x21                                    
02d191e4: mov     w2, wzr                                    
02d191e8: bl      #0x2baa05c                                 fn_2baa05c
02d191ec: b       #0x2d191fc                                 
02d191f0: ldrsw   x9, [x10]                                  
02d191f4: add     x8, x8, x9, lsl #4                         
02d191f8: add     x0, x8, #0x138                             
02d191fc: ldp     x8, x1, [x0]                               
02d19200: mov     x0, x21                                    
02d19204: blr     x8                                         
02d19208: ldr     x8, [x20, #0x38]                           ._dreamHouseController
02d1920c: mov     x1, x0                                     
02d19210: mov     x0, x19                                    
02d19214: ldp     x20, x19, [sp, #0x20]                      
02d19218: ldp     x22, x21, [sp, #0x10]                      
02d1921c: ldr     x2, [x8, #0x28]                            
02d19220: ldp     x30, x23, [sp], #0x30                      
02d19224: b       #0x2ceb074                                 
02d19228: bl      #0x2b7105c                                 fn_2b7105c
02d1922c: stp     x30, x23, [sp, #-0x30]!                    
02d19230: stp     x22, x21, [sp, #0x10]                      
02d19234: stp     x20, x19, [sp, #0x20]                      
02d19238: ldr     x8, [x3, #0x38]                            
02d1923c: mov     x20, x3                                    
02d19240: mov     x23, x2                                    
02d19244: mov     x19, x1                                    
02d19248: mov     x22, x0                                    
02d1924c: cbnz    x8, #0x2d1926c                             
02d19250: adrp    x0, #0x639c000                             
02d19254: add     x0, x0, #0x188                             &639c188
02d19258: bl      #0x2b70db0                                 fn_2b70db0
02d1925c: ldr     x8, [x20, #0x38]                           ._dreamHouseController
02d19260: cbnz    x8, #0x2d1926c                             
02d19264: mov     x0, x20                                    
02d19268: bl      #0x2ba9d7c                                 fn_2ba9d7c
02d1926c: ldr     x21, [x22]                                 
02d19270: cbnz    x21, #0x2d192b4                            
02d19274: ldr     x8, [x20, #0x38]                           ._dreamHouseController
02d19278: ldr     x0, [x8, #0x10]                            
02d1927c: add     x8, x0, #0x135                             &639c135
02d19280: ldrh    w8, [x8]                                   
02d19284: tbnz    w8, #0, #0x2d1928c                         
02d19288: bl      #0x2ba9d20                                 fn_2ba9d20
02d1928c: ldr     w8, [x0, #0xe4]                            [639c0e4]=200100e500000000 f=0,1.0927e-19
02d19290: cbnz    w8, #0x2d19298                             
02d19294: bl      #0x2b70f30                                 fn_2b70f30
02d19298: ldr     x8, [x20, #0x38]                           ._dreamHouseController
02d1929c: mov     x0, x23                                    
02d192a0: mov     x1, x22                                    
02d192a4: ldr     x2, [x8, #8]                               
02d192a8: bl      #0x3df8aa4                                 fn_3df8aa4
02d192ac: ldr     x21, [x22]                                 
02d192b0: cbz     x21, #0x2d19334                            
02d192b4: adrp    x10, #0x6268000                            
02d192b8: ldr     x8, [x21]                                  
02d192bc: ldr     x10, [x10, #0xd8]                          T:Cysharp.Threading.Tasks.CompilerServices.IStateMachineRunnerPromise
02d192c0: ldrh    w9, [x8, #0x12e]                           
02d192c4: ldr     x1, [x10]                                  S:'{0}/2'
02d192c8: cbz     x9, #0x2d192ec                             
02d192cc: ldr     x10, [x8, #0xb0]                           
02d192d0: add     x10, x10, #8                               &6268008
02d192d4: ldur    x11, [x10, #-8]                            
02d192d8: cmp     x11, x1                                    
02d192dc: b.eq    #0x2d192fc                                 
02d192e0: subs    x9, x9, #1                                 
02d192e4: add     x10, x10, #0x10                            &6268010
02d192e8: b.ne    #0x2d192d4                                 
02d192ec: mov     x0, x21                                    
02d192f0: mov     w2, wzr                                    
02d192f4: bl      #0x2baa05c                                 fn_2baa05c
02d192f8: b       #0x2d19308                                 
02d192fc: ldrsw   x9, [x10]                                  
02d19300: add     x8, x8, x9, lsl #4                         
02d19304: add     x0, x8, #0x138                             
02d19308: ldp     x8, x1, [x0]                               
02d1930c: mov     x0, x21                                    
02d19310: blr     x8                                         
02d19314: ldr     x8, [x20, #0x38]                           ._dreamHouseController
02d19318: mov     x1, x0                                     
02d1931c: mov     x0, x19                                    
02d19320: ldp     x20, x19, [sp, #0x20]                      
02d19324: ldp     x22, x21, [sp, #0x10]                      
02d19328: ldr     x2, [x8, #0x28]                            
02d1932c: ldp     x30, x23, [sp], #0x30                      
02d19330: b       #0x2ceb074                                 
02d19334: bl      #0x2b7105c                                 fn_2b7105c
