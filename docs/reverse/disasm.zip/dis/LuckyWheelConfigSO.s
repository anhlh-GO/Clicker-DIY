#### CLASS LuckyWheelConfigSO/<>c parent= object
#   field <>9                            LuckyWheelConfigSO/<>c                             off=0x0 attr=36 
#   field <>9__1_0                       System.Func`2<LuckyWheelRewardConfig,int>          off=0x8 attr=16 
## .cctor() -> void
---- LuckyWheelConfigSO/<>c::.cctor 0x2ca8950
02ca8950: str     x30, [sp, #-0x20]!                         
02ca8954: stp     x20, x19, [sp, #0x10]                      
02ca8958: adrp    x19, #0x662f000                            
02ca895c: adrp    x20, #0x6266000                            
02ca8960: ldrb    w8, [x19, #0xaff]                          
02ca8964: ldr     x20, [x20, #0x5e8]                         T:LuckyWheelConfigSO/<>c
02ca8968: tbnz    w8, #0, #0x2ca8980                         
02ca896c: adrp    x0, #0x6266000                             
02ca8970: ldr     x0, [x0, #0x5e8]                           T:LuckyWheelConfigSO/<>c
02ca8974: bl      #0x2b70db0                                 fn_2b70db0
02ca8978: mov     w8, #1                                     
02ca897c: strb    w8, [x19, #0xaff]                          
02ca8980: ldr     x0, [x20]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca8984: bl      #0x2b7104c                                 fn_2b7104c
02ca8988: mov     x1, xzr                                    
02ca898c: mov     x19, x0                                    
02ca8990: bl      #0x4e53e9c                                 System.Object::.ctor
02ca8994: ldr     x8, [x20]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca8998: mov     x1, x19                                    
02ca899c: ldr     x8, [x8, #0xb8]                            
02ca89a0: str     x19, [x8]                                  
02ca89a4: ldr     x8, [x20]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca89a8: ldp     x20, x19, [sp, #0x10]                      
02ca89ac: ldr     x0, [x8, #0xb8]                            
02ca89b0: ldr     x30, [sp], #0x20                           
02ca89b4: b       #0x2b70d54                                 
## .ctor() -> void
---- LuckyWheelConfigSO/<>c::.ctor 0x2ca89b8
02ca89b8: mov     x1, xzr                                    
02ca89bc: b       #0x4e53e9c                                 System.Object::.ctor
## <GetRandomReward>b__1_0(LuckyWheelRewardConfig config) -> int
---- LuckyWheelConfigSO/<>c::<GetRandomReward>b__1_0 0x2ca89c0
02ca89c0: cbz     x1, #0x2ca89cc                             
02ca89c4: ldr     w0, [x1, #0x18]                            
02ca89c8: ret                                                
02ca89cc: str     x30, [sp, #-0x10]!                         
02ca89d0: bl      #0x2b7105c                                 fn_2b7105c
#### CLASS LuckyWheelConfigSO parent= UnityEngine.ScriptableObject
#   field Configs                        System.Collections.Generic.List`1<LuckyWheelRewardConfig> off=0x18 attr=6 
## GetRandomReward() -> LuckyWheelRewardConfig
---- LuckyWheelConfigSO::GetRandomReward 0x2ca8694
02ca8694: sub     sp, sp, #0x70                              
02ca8698: str     x30, [sp, #0x30]                           
02ca869c: stp     x24, x23, [sp, #0x40]                      
02ca86a0: stp     x22, x21, [sp, #0x50]                      
02ca86a4: stp     x20, x19, [sp, #0x60]                      
02ca86a8: adrp    x20, #0x662f000                            
02ca86ac: adrp    x23, #0x6266000                            
02ca86b0: mov     x19, x0                                    
02ca86b4: ldrb    w8, [x20, #0xafd]                          
02ca86b8: ldr     x23, [x23, #0x5e8]                         T:LuckyWheelConfigSO/<>c
02ca86bc: tbnz    w8, #0, #0x2ca8728                         
02ca86c0: adrp    x0, #0x6266000                             
02ca86c4: ldr     x0, [x0, #0x5f0]                           MS:System.Linq.Enumerable::Sum
02ca86c8: bl      #0x2b70db0                                 fn_2b70db0
02ca86cc: adrp    x0, #0x6266000                             
02ca86d0: ldr     x0, [x0, #0x5f8]                           MS:System.Collections.Generic.List`1/Enumerator::Dispose
02ca86d4: bl      #0x2b70db0                                 fn_2b70db0
02ca86d8: adrp    x0, #0x6266000                             
02ca86dc: ldr     x0, [x0, #0x600]                           MS:System.Collections.Generic.List`1/Enumerator::MoveNext
02ca86e0: bl      #0x2b70db0                                 fn_2b70db0
02ca86e4: adrp    x0, #0x6266000                             
02ca86e8: ldr     x0, [x0, #0x608]                           MS:System.Collections.Generic.List`1/Enumerator::get_Current
02ca86ec: bl      #0x2b70db0                                 fn_2b70db0
02ca86f0: adrp    x0, #0x6266000                             
02ca86f4: ldr     x0, [x0, #0x610]                           T:type55589(k15)
02ca86f8: bl      #0x2b70db0                                 fn_2b70db0
02ca86fc: adrp    x0, #0x6266000                             
02ca8700: ldr     x0, [x0, #0x618]                           MS:System.Collections.Generic.List`1::GetEnumerator
02ca8704: bl      #0x2b70db0                                 fn_2b70db0
02ca8708: adrp    x0, #0x6266000                             
02ca870c: ldr     x0, [x0, #0x620]                           M:LuckyWheelConfigSO/<>c::<GetRandomReward>b__1_0
02ca8710: bl      #0x2b70db0                                 fn_2b70db0
02ca8714: adrp    x0, #0x6266000                             
02ca8718: ldr     x0, [x0, #0x5e8]                           T:LuckyWheelConfigSO/<>c
02ca871c: bl      #0x2b70db0                                 fn_2b70db0
02ca8720: mov     w8, #1                                     
02ca8724: strb    w8, [x20, #0xafd]                          
02ca8728: ldr     x0, [x23]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca872c: ldr     x20, [x19, #0x18]                          .Configs
02ca8730: stp     xzr, xzr, [sp, #0x18]                      
02ca8734: str     xzr, [sp, #0x28]                           
02ca8738: ldr     w8, [x0, #0xe4]                            [62660e4]=0 f=0,0
02ca873c: cbnz    w8, #0x2ca8748                             
02ca8740: bl      #0x2b70f30                                 fn_2b70f30
02ca8744: ldr     x0, [x23]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca8748: ldr     x8, [x0, #0xb8]                            S:'banner_native_refresh_time'
02ca874c: adrp    x24, #0x6266000                            
02ca8750: ldr     x21, [x8, #8]                              
02ca8754: ldr     x24, [x24, #0x5f0]                         MS:System.Linq.Enumerable::Sum
02ca8758: cbnz    x21, #0x2ca87b4                            
02ca875c: ldr     w9, [x0, #0xe4]                            [62660e4]=0 f=0,0
02ca8760: cbnz    w9, #0x2ca8770                             
02ca8764: bl      #0x2b70f30                                 fn_2b70f30
02ca8768: ldr     x8, [x23]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca876c: ldr     x8, [x8, #0xb8]                            
02ca8770: adrp    x9, #0x6266000                             
02ca8774: ldr     x9, [x9, #0x610]                           T:type55589(k15)
02ca8778: ldr     x22, [x8]                                  
02ca877c: ldr     x0, [x9]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca8780: bl      #0x2b7104c                                 fn_2b7104c
02ca8784: adrp    x8, #0x6266000                             
02ca8788: mov     x1, x22                                    
02ca878c: mov     x3, xzr                                    
02ca8790: ldr     x8, [x8, #0x620]                           M:LuckyWheelConfigSO/<>c::<GetRandomReward>b__1_0
02ca8794: mov     x21, x0                                    
02ca8798: ldr     x2, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca879c: bl      #0x4941168                                 fn_4941168
02ca87a0: ldr     x8, [x23]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca87a4: mov     x1, x21                                    
02ca87a8: ldr     x0, [x8, #0xb8]                            S:'banner_native_refresh_time'
02ca87ac: str     x21, [x0, #8]!                             
02ca87b0: bl      #0x2b70d54                                 fn_2b70d54
02ca87b4: ldr     x2, [x24]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca87b8: mov     x0, x20                                    
02ca87bc: mov     x1, x21                                    
02ca87c0: bl      #0x319babc                                 fn_319babc
02ca87c4: mov     w1, w0                                     
02ca87c8: mov     w0, wzr                                    
02ca87cc: mov     x2, xzr                                    
02ca87d0: bl      #0x5b2e000                                 UnityEngine.Random::Range
02ca87d4: ldr     x9, [x19, #0x18]                           .Configs
02ca87d8: cbz     x9, #0x2ca8870                             
02ca87dc: adrp    x8, #0x6266000                             
02ca87e0: adrp    x22, #0x6266000                            
02ca87e4: adrp    x21, #0x6266000                            
02ca87e8: ldr     x8, [x8, #0x618]                           MS:System.Collections.Generic.List`1::GetEnumerator
02ca87ec: ldr     x22, [x22, #0x600]                         MS:System.Collections.Generic.List`1/Enumerator::MoveNext
02ca87f0: ldr     x21, [x21, #0x5f8]                         MS:System.Collections.Generic.List`1/Enumerator::Dispose
02ca87f4: mov     w19, w0                                    
02ca87f8: mov     x0, x9                                     
02ca87fc: add     x20, sp, #0x18                             
02ca8800: ldr     x1, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca8804: add     x8, sp, #0x18                              
02ca8808: bl      #0x35a9d9c                                 fn_35a9d9c
02ca880c: mov     w23, wzr                                   
02ca8810: stp     xzr, x20, [sp, #8]                         
02ca8814: ldr     x1, [x22]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca8818: add     x0, sp, #0x18                              
02ca881c: bl      #0x4690474                                 fn_4690474
02ca8820: tbz     w0, #0, #0x2ca8840                         
02ca8824: ldr     x20, [sp, #0x28]                           
02ca8828: cbz     x20, #0x2ca886c                            
02ca882c: ldr     w8, [x20, #0x18]                           [662f018]=6000014 f=2.40742e-35,0 .Configs
02ca8830: add     w23, w8, w23                               
02ca8834: cmp     w19, w23                                   
02ca8838: b.ge    #0x2ca8814                                 
02ca883c: b       #0x2ca8844                                 
02ca8840: mov     x20, xzr                                   
02ca8844: ldr     x1, [x21]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca8848: add     x0, sp, #0x18                              
02ca884c: bl      #0x4690470                                 fn_4690470
02ca8850: mov     x0, x20                                    
02ca8854: ldp     x20, x19, [sp, #0x60]                      
02ca8858: ldp     x22, x21, [sp, #0x50]                      
02ca885c: ldr     x30, [sp, #0x30]                           
02ca8860: ldp     x24, x23, [sp, #0x40]                      
02ca8864: add     sp, sp, #0x70                              
02ca8868: ret                                                
02ca886c: bl      #0x2b7105c                                 fn_2b7105c
02ca8870: bl      #0x2b7105c                                 fn_2b7105c
02ca8874: b       #0x2ca8878                                 
02ca8878: mov     x19, x0                                    
02ca887c: cmp     w1, #1                                     
02ca8880: b.ne    #0x2ca88bc                                 
02ca8884: mov     x0, x19                                    
02ca8888: bl      #0x5e90260                                 fn_5e90260
02ca888c: ldr     x19, [x0]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca8890: str     x19, [sp, #8]                              
02ca8894: bl      #0x5e90270                                 fn_5e90270
02ca8898: ldr     x0, [sp, #0x10]                            
02ca889c: ldr     x1, [x21]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca88a0: bl      #0x4690470                                 fn_4690470
02ca88a4: cbnz    x19, #0x2ca88b0                            
02ca88a8: mov     x20, xzr                                   
02ca88ac: b       #0x2ca8850                                 
02ca88b0: mov     x0, x19                                    
02ca88b4: bl      #0x2b71054                                 fn_2b71054
02ca88b8: mov     x19, x0                                    
02ca88bc: add     x0, sp, #8                                 
02ca88c0: bl      #0x2736f1c                                 fn_2736f1c
02ca88c4: mov     x0, x19                                    
02ca88c8: bl      #0x2c6051c                                 fn_2c6051c
02ca88cc: bl      #0x27369b8                                 fn_27369b8
## GetRewardNotCoin() -> LuckyWheelRewardConfig
---- LuckyWheelConfigSO::GetRewardNotCoin 0x2ca88d0
02ca88d0: str     x30, [sp, #-0x20]!                         
02ca88d4: stp     x20, x19, [sp, #0x10]                      
02ca88d8: adrp    x20, #0x662f000                            
02ca88dc: mov     x19, x0                                    
02ca88e0: ldrb    w8, [x20, #0xafe]                          
02ca88e4: tbnz    w8, #0, #0x2ca88fc                         
02ca88e8: adrp    x0, #0x6266000                             
02ca88ec: ldr     x0, [x0, #0x628]                           MS:System.Collections.Generic.List`1::get_Item
02ca88f0: bl      #0x2b70db0                                 fn_2b70db0
02ca88f4: mov     w8, #1                                     
02ca88f8: strb    w8, [x20, #0xafe]                          
02ca88fc: mov     w0, wzr                                    
02ca8900: mov     w1, #2                                     
02ca8904: mov     x2, xzr                                    
02ca8908: bl      #0x5b2e000                                 UnityEngine.Random::Range
02ca890c: mov     w8, w0                                     
02ca8910: ldr     x0, [x19, #0x18]                           .Configs
02ca8914: cbz     w8, #0x2ca8924                             
02ca8918: cbz     x0, #0x2ca8944                             
02ca891c: mov     w1, #4                                     
02ca8920: b       #0x2ca892c                                 
02ca8924: cbz     x0, #0x2ca8944                             
02ca8928: mov     w1, #1                                     
02ca892c: adrp    x8, #0x6266000                             
02ca8930: ldr     x8, [x8, #0x628]                           MS:System.Collections.Generic.List`1::get_Item
02ca8934: ldp     x20, x19, [sp, #0x10]                      
02ca8938: ldr     x2, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca893c: ldr     x30, [sp], #0x20                           
02ca8940: b       #0x35a8f3c                                 
02ca8944: bl      #0x2b7105c                                 fn_2b7105c
## .ctor() -> void
---- LuckyWheelConfigSO::.ctor 0x2ca8948
02ca8948: mov     x1, xzr                                    
02ca894c: b       #0x5b398f0                                 UnityEngine.ScriptableObject::.ctor
