#### CLASS LoginTimeReward.LoginTimeRewardConfig/<>c__DisplayClass1_0 parent= object
#   field id                             int                                                off=0x10 attr=6 
## .ctor() -> void
---- LoginTimeReward.LoginTimeRewardConfig/<>c__DisplayClass1_0::.ctor 0x2d5b168
02d5b168: mov     x1, xzr                                    
02d5b16c: b       #0x4e53e9c                                 System.Object::.ctor
## <GetData>b__0(LoginTimeReward.LoginTimeRewardDataItem x) -> bool
---- LoginTimeReward.LoginTimeRewardConfig/<>c__DisplayClass1_0::<GetData>b__0 0x2d5b180
02d5b180: cbz     x1, #0x2d5b198                             
02d5b184: ldr     w8, [x1, #0x10]                            
02d5b188: ldr     w9, [x0, #0x10]                            .id
02d5b18c: cmp     w8, w9                                     
02d5b190: cset    w0, eq                                     
02d5b194: ret                                                
02d5b198: str     x30, [sp, #-0x10]!                         
02d5b19c: bl      #0x2b7105c                                 fn_2b7105c
#### CLASS LoginTimeReward.LoginTimeRewardConfig parent= UnityEngine.ScriptableObject
#   field DataList                       System.Collections.Generic.List`1<LoginTimeReward.LoginTimeRewardDataItem> off=0x18 attr=6 
## GetData(int id) -> LoginTimeReward.LoginTimeRewardDataItem
---- LoginTimeReward.LoginTimeRewardConfig::GetData 0x2d5b090
02d5b090: str     x30, [sp, #-0x30]!                         
02d5b094: stp     x22, x21, [sp, #0x10]                      
02d5b098: stp     x20, x19, [sp, #0x20]                      
02d5b09c: adrp    x21, #0x6630000                            
02d5b0a0: adrp    x22, #0x626b000                            
02d5b0a4: mov     w19, w1                                    
02d5b0a8: ldrb    w8, [x21, #0x2ba]                          
02d5b0ac: ldr     x22, [x22, #0xbe0]                         T:LoginTimeReward.LoginTimeRewardConfig/<>c__DisplayClass1_0
02d5b0b0: mov     x20, x0                                    
02d5b0b4: tbnz    w8, #0, #0x2d5b0f0                         
02d5b0b8: adrp    x0, #0x626b000                             
02d5b0bc: ldr     x0, [x0, #0xbe8]                           MS:System.Collections.Generic.List`1::Find
02d5b0c0: bl      #0x2b70db0                                 fn_2b70db0
02d5b0c4: adrp    x0, #0x626b000                             
02d5b0c8: ldr     x0, [x0, #0xbf0]                           T:type57260(k15)
02d5b0cc: bl      #0x2b70db0                                 fn_2b70db0
02d5b0d0: adrp    x0, #0x626b000                             
02d5b0d4: ldr     x0, [x0, #0xbf8]                           M:LoginTimeReward.LoginTimeRewardConfig/<>c__DisplayClass1_0::<GetData>b__0
02d5b0d8: bl      #0x2b70db0                                 fn_2b70db0
02d5b0dc: adrp    x0, #0x626b000                             
02d5b0e0: ldr     x0, [x0, #0xbe0]                           T:LoginTimeReward.LoginTimeRewardConfig/<>c__DisplayClass1_0
02d5b0e4: bl      #0x2b70db0                                 fn_2b70db0
02d5b0e8: mov     w8, #1                                     
02d5b0ec: strb    w8, [x21, #0x2ba]                          
02d5b0f0: ldr     x0, [x22]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d5b0f4: bl      #0x2b7104c                                 fn_2b7104c
02d5b0f8: mov     x1, xzr                                    
02d5b0fc: mov     x21, x0                                    
02d5b100: bl      #0x4e53e9c                                 System.Object::.ctor
02d5b104: cbz     x21, #0x2d5b164                            
02d5b108: adrp    x8, #0x626b000                             
02d5b10c: adrp    x22, #0x626b000                            
02d5b110: ldr     x8, [x8, #0xbf0]                           T:type57260(k15)
02d5b114: ldr     x22, [x22, #0xbf8]                         M:LoginTimeReward.LoginTimeRewardConfig/<>c__DisplayClass1_0::<GetData>b__0
02d5b118: ldr     x20, [x20, #0x18]                          .DataList
02d5b11c: str     w19, [x21, #0x10]                          
02d5b120: ldr     x0, [x8]                                   T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d5b124: bl      #0x2b7104c                                 fn_2b7104c
02d5b128: ldr     x2, [x22]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d5b12c: mov     x1, x21                                    
02d5b130: mov     x3, xzr                                    
02d5b134: mov     x19, x0                                    
02d5b138: bl      #0x399ba10                                 fn_399ba10
02d5b13c: cbz     x20, #0x2d5b164                            
02d5b140: adrp    x8, #0x626b000                             
02d5b144: mov     x0, x20                                    
02d5b148: mov     x1, x19                                    
02d5b14c: ldr     x8, [x8, #0xbe8]                           MS:System.Collections.Generic.List`1::Find
02d5b150: ldp     x20, x19, [sp, #0x20]                      
02d5b154: ldp     x22, x21, [sp, #0x10]                      
02d5b158: ldr     x2, [x8]                                   T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d5b15c: ldr     x30, [sp], #0x30                           
02d5b160: b       #0x35a9868                                 
02d5b164: bl      #0x2b7105c                                 fn_2b7105c
## GetAllData() -> System.Collections.Generic.List`1<LoginTimeReward.LoginTimeRewardDataItem>
---- LoginTimeReward.LoginTimeRewardConfig::GetAllData 0x2d5b170
02d5b170: ldr     x0, [x0, #0x18]                            .DataList
02d5b174: ret                                                
## .ctor() -> void
---- LoginTimeReward.LoginTimeRewardConfig::.ctor 0x2d5b178
02d5b178: mov     x1, xzr                                    
02d5b17c: b       #0x5b398f0                                 UnityEngine.ScriptableObject::.ctor
