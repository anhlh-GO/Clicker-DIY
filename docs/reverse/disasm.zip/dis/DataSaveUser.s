#### CLASS DataSaveUser parent= object
#   field IsNoAd                         bool                                               off=0x10 attr=6 
#   field HasSpecialPack                 bool                                               off=0x11 attr=6 
#   field StartTime                      System.DateTime                                    off=0x18 attr=6 
#   field StartTimeString                string                                             off=0x20 attr=6 
#   field CurrentLanguage                string                                             off=0x28 attr=6 
#   field LocaleId                       int                                                off=0x30 attr=6 
#   field IsVibrationOn                  bool                                               off=0x34 attr=6 
#   field IsMusicOn                      bool                                               off=0x35 attr=6 
#   field IsSoundOn                      bool                                               off=0x36 attr=6 
#   field IsRateUs                       bool                                               off=0x37 attr=6 
#   field IsFirstLuckWheel               bool                                               off=0x38 attr=6 
#   field IsSelectedLanguage             bool                                               off=0x39 attr=6 
#   field IsFirstGame                    bool                                               off=0x3a attr=6 
#   field IsFirstClicker                 bool                                               off=0x3b attr=6 
#   field ClickerRewardClaimCount        int                                                off=0x3c attr=6 
#   field IsUnlockedDailyTask            bool                                               off=0x40 attr=6 
#   field IsUnlockedDecor                bool                                               off=0x41 attr=6 
#   field IsUnlockedIdleChest            bool                                               off=0x42 attr=6 
#   field IsUnlockedDreamHouse           bool                                               off=0x43 attr=6 
#   field IsDoneTutorialCollection       bool                                               off=0x44 attr=6 
#   field IsDoneTutorialBlindBag         bool                                               off=0x45 attr=6 
#   field Money                          int                                                off=0x48 attr=6 
#   field ClickerPlayTime                int                                                off=0x4c attr=6 
#   field BlindbagPlayTime               int                                                off=0x50 attr=6 
#   field ScoopPlayTime                  int                                                off=0x54 attr=6 
#   field ClaimedAchievement             System.Collections.Generic.List`1<int>             off=0x58 attr=6 
#   field UnlockedClickerDecor           System.Collections.Generic.List`1<int>             off=0x60 attr=6 
#   field UnlockedClickerSwitch          System.Collections.Generic.List`1<int>             off=0x68 attr=6 
#   field UnlockedClickerBase            System.Collections.Generic.List`1<int>             off=0x70 attr=6 
#   field UnlockedClickerKeycap          System.Collections.Generic.List`1<int>             off=0x78 attr=6 ObsoleteAttribute
#   field UnlockedClickerKeychain        System.Collections.Generic.List`1<int>             off=0x80 attr=6 
#   field OwnedGiftBox                   System.Collections.Generic.List`1<int>             off=0x88 attr=6 
#   field OwnedCard                      System.Collections.Generic.List`1<int>             off=0x90 attr=6 
#   field Tracking                       TrackingPlayTime                                   off=0x98 attr=6 
#   field OpenAppTime                    int                                                off=0xa0 attr=6 
#   field Trading                        Trading.TradingSaveData                            off=0xa8 attr=6 
## .ctor() -> void
---- DataSaveUser::.ctor 0x2caacb8
02caacb8: str     x30, [sp, #-0x40]!                         
02caacbc: stp     x24, x23, [sp, #0x10]                      
02caacc0: stp     x22, x21, [sp, #0x20]                      
02caacc4: stp     x20, x19, [sp, #0x30]                      
02caacc8: adrp    x20, #0x6263000                            
02caaccc: adrp    x24, #0x662f000                            
02caacd0: adrp    x23, #0x6266000                            
02caacd4: adrp    x22, #0x6266000                            
02caacd8: adrp    x21, #0x6266000                            
02caacdc: ldr     x20, [x20, #0xa90]                         S:''
02caace0: ldr     x23, [x23, #0x648]                         T:type15061(k15)
02caace4: ldrb    w8, [x24, #0xb1e]                          
02caace8: ldr     x22, [x22, #0x650]                         MS:System.Collections.Generic.List`1::.ctor
02caacec: ldr     x21, [x21, #0x7e8]                         T:Trading.TradingSaveData
02caacf0: mov     x19, x0                                    
02caacf4: tbnz    w8, #0, #0x2caad30                         
02caacf8: adrp    x0, #0x6266000                             
02caacfc: ldr     x0, [x0, #0x650]                           MS:System.Collections.Generic.List`1::.ctor
02caad00: bl      #0x2b70db0                                 fn_2b70db0
02caad04: adrp    x0, #0x6266000                             
02caad08: ldr     x0, [x0, #0x648]                           T:type15061(k15)
02caad0c: bl      #0x2b70db0                                 fn_2b70db0
02caad10: adrp    x0, #0x6266000                             
02caad14: ldr     x0, [x0, #0x7e8]                           T:Trading.TradingSaveData
02caad18: bl      #0x2b70db0                                 fn_2b70db0
02caad1c: adrp    x0, #0x6263000                             
02caad20: ldr     x0, [x0, #0xa90]                           S:''
02caad24: bl      #0x2b70db0                                 fn_2b70db0
02caad28: mov     w8, #1                                     
02caad2c: strb    w8, [x24, #0xb1e]                          
02caad30: ldr     x1, [x20]                                  &2c5bbd4(=a9bd7bfdd503233f)
02caad34: mov     x0, x19                                    
02caad38: str     x1, [x0, #0x28]!                           .CurrentLanguage
02caad3c: bl      #0x2b70d54                                 fn_2b70d54
02caad40: ldr     x0, [x23]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02caad44: mov     w8, #1                                     
02caad48: mov     w9, #0xc8                                  
02caad4c: strb    w8, [x19, #0x3b]                           .IsFirstClicker
02caad50: str     w9, [x19, #0x48]                           .Money
02caad54: bl      #0x2b7104c                                 fn_2b7104c
02caad58: ldr     x1, [x22]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02caad5c: mov     x20, x0                                    
02caad60: bl      #0x3569388                                 fn_3569388
02caad64: mov     x0, x19                                    
02caad68: mov     x1, x20                                    
02caad6c: str     x20, [x0, #0x58]!                          .ClaimedAchievement
02caad70: bl      #0x2b70d54                                 fn_2b70d54
02caad74: ldr     x0, [x23]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02caad78: bl      #0x2b7104c                                 fn_2b7104c
02caad7c: ldr     x1, [x22]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02caad80: mov     x20, x0                                    
02caad84: bl      #0x3569388                                 fn_3569388
02caad88: mov     x0, x19                                    
02caad8c: mov     x1, x20                                    
02caad90: str     x20, [x0, #0x60]!                          .UnlockedClickerDecor
02caad94: bl      #0x2b70d54                                 fn_2b70d54
02caad98: ldr     x0, [x23]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02caad9c: bl      #0x2b7104c                                 fn_2b7104c
02caada0: ldr     x1, [x22]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02caada4: mov     x20, x0                                    
02caada8: bl      #0x3569388                                 fn_3569388
02caadac: mov     x0, x19                                    
02caadb0: mov     x1, x20                                    
02caadb4: str     x20, [x0, #0x68]!                          .UnlockedClickerSwitch
02caadb8: bl      #0x2b70d54                                 fn_2b70d54
02caadbc: ldr     x0, [x23]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02caadc0: bl      #0x2b7104c                                 fn_2b7104c
02caadc4: ldr     x1, [x22]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02caadc8: mov     x20, x0                                    
02caadcc: bl      #0x3569388                                 fn_3569388
02caadd0: mov     x0, x19                                    
02caadd4: mov     x1, x20                                    
02caadd8: str     x20, [x0, #0x70]!                          .UnlockedClickerBase
02caaddc: bl      #0x2b70d54                                 fn_2b70d54
02caade0: ldr     x0, [x23]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02caade4: bl      #0x2b7104c                                 fn_2b7104c
02caade8: ldr     x1, [x22]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02caadec: mov     x20, x0                                    
02caadf0: bl      #0x3569388                                 fn_3569388
02caadf4: mov     x0, x19                                    
02caadf8: mov     x1, x20                                    
02caadfc: str     x20, [x0, #0x78]!                          .UnlockedClickerKeycap
02caae00: bl      #0x2b70d54                                 fn_2b70d54
02caae04: ldr     x0, [x23]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02caae08: bl      #0x2b7104c                                 fn_2b7104c
02caae0c: ldr     x1, [x22]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02caae10: mov     x20, x0                                    
02caae14: bl      #0x3569388                                 fn_3569388
02caae18: mov     x0, x19                                    
02caae1c: mov     x1, x20                                    
02caae20: str     x20, [x0, #0x80]!                          .UnlockedClickerKeychain
02caae24: bl      #0x2b70d54                                 fn_2b70d54
02caae28: ldr     x0, [x23]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02caae2c: bl      #0x2b7104c                                 fn_2b7104c
02caae30: ldr     x1, [x22]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02caae34: mov     x20, x0                                    
02caae38: bl      #0x3569388                                 fn_3569388
02caae3c: mov     x0, x19                                    
02caae40: mov     x1, x20                                    
02caae44: str     x20, [x0, #0x88]!                          .OwnedGiftBox
02caae48: bl      #0x2b70d54                                 fn_2b70d54
02caae4c: ldr     x0, [x23]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02caae50: bl      #0x2b7104c                                 fn_2b7104c
02caae54: ldr     x1, [x22]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02caae58: mov     x20, x0                                    
02caae5c: bl      #0x3569388                                 fn_3569388
02caae60: mov     x0, x19                                    
02caae64: mov     x1, x20                                    
02caae68: str     x20, [x0, #0x90]!                          .OwnedCard
02caae6c: bl      #0x2b70d54                                 fn_2b70d54
02caae70: ldr     x0, [x21]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02caae74: bl      #0x2b7104c                                 fn_2b7104c
02caae78: mov     x1, xzr                                    
02caae7c: mov     x20, x0                                    
02caae80: bl      #0x2d044c0                                 Trading.TradingSaveData::.ctor
02caae84: mov     x0, x19                                    
02caae88: mov     x1, x20                                    
02caae8c: str     x20, [x0, #0xa8]!                          .Trading
02caae90: bl      #0x2b70d54                                 fn_2b70d54
02caae94: mov     x0, x19                                    
02caae98: ldp     x20, x19, [sp, #0x30]                      
02caae9c: ldp     x22, x21, [sp, #0x20]                      
02caaea0: mov     x1, xzr                                    
02caaea4: ldp     x24, x23, [sp, #0x10]                      
02caaea8: ldr     x30, [sp], #0x40                           
02caaeac: b       #0x4e53e9c                                 System.Object::.ctor
