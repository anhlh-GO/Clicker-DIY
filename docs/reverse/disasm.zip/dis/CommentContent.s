#### CLASS CommentContent parent= object
#   field Content                        string                                             off=0x10 attr=6 
## .ctor(string content) -> void
---- CommentContent::.ctor 0x2cb4efc
02cb4efc: str     x30, [sp, #-0x20]!                         
02cb4f00: stp     x20, x19, [sp, #0x10]                      
02cb4f04: mov     x19, x1                                    
02cb4f08: mov     x1, xzr                                    
02cb4f0c: mov     x20, x0                                    
02cb4f10: bl      #0x4e53e9c                                 System.Object::.ctor
02cb4f14: str     x19, [x20, #0x10]!                         .Content
02cb4f18: mov     x0, x20                                    
02cb4f1c: mov     x1, x19                                    
02cb4f20: ldp     x20, x19, [sp, #0x10]                      
02cb4f24: ldr     x30, [sp], #0x20                           
02cb4f28: b       #0x2b70d54                                 
