#### CLASS Decor.DecorPanel parent= UnityEngine.MonoBehaviour
#   field _rectTransform                 UnityEngine.RectTransform                          off=0x20 attr=1 SerializeField
#   field _panel                         UnityEngine.RectTransform                          off=0x28 attr=1 SerializeField
#   field _btnClose                      UnityEngine.UI.Button                              off=0x30 attr=1 SerializeField
#   field _canvasGroup                   UnityEngine.CanvasGroup                            off=0x38 attr=1 SerializeField
#   field _categoryPanel                 Decor.CategoryPanel                                off=0x40 attr=1 SerializeField
#   field _optionPanel                   Decor.OptionPanel                                  off=0x48 attr=1 SerializeField
#   field _iconNoti                      UnityEngine.GameObject                             off=0x50 attr=1 SerializeField
#   field _yOffset                       float                                              off=0x58 attr=1 SerializeField
#   field _closeButton                   UnityEngine.UI.Button                              off=0x60 attr=1 SerializeField
#   field _onClosePopupAction            UnityEngine.Events.UnityAction                     off=0x68 attr=1 
#   field _initialPosition               UnityEngine.Vector3                                off=0x70 attr=1 
#   field _hideYPosition                 float                                              off=0x7c attr=1 
#   field _homeScreen                    HomeScreen                                         off=0x80 attr=1 
#   field _jellyScreen                   ScreenHome                                         off=0x88 attr=1 
#   field OnShowPanel                    UnityEngine.Events.UnityAction`1<float>            off=0x90 attr=6 
#   field OnHidePanel                    UnityEngine.Events.UnityAction`1<float>            off=0x98 attr=6 
## get_CategoryPanel() -> Decor.CategoryPanel
---- Decor.DecorPanel::get_CategoryPanel 0x2d27d04
02d27d04: ldr     x0, [x0, #0x40]                            ._categoryPanel
02d27d08: ret                                                
## get_OptionPanel() -> Decor.OptionPanel
---- Decor.DecorPanel::get_OptionPanel 0x2d27d0c
02d27d0c: ldr     x0, [x0, #0x48]                            ._optionPanel
02d27d10: ret                                                
## OnInit(HomeScreen homeScreen) -> void
---- Decor.DecorPanel::OnInit 0x2d27d14
02d27d14: str     d8, [sp, #-0x30]!                          
02d27d18: stp     x30, x21, [sp, #0x10]                      
02d27d1c: stp     x20, x19, [sp, #0x20]                      
02d27d20: adrp    x21, #0x6630000                            
02d27d24: mov     x20, x1                                    
02d27d28: mov     x19, x0                                    
02d27d2c: ldrb    w8, [x21, #0x92]                           
02d27d30: tbnz    w8, #0, #0x2d27d54                         
02d27d34: adrp    x0, #0x626a000                             
02d27d38: ldr     x0, [x0, #0x1d0]                           M:Decor.DecorPanel::OnButtonCloseClicked
02d27d3c: bl      #0x2b70db0                                 fn_2b70db0
02d27d40: adrp    x0, #0x6265000                             
02d27d44: ldr     x0, [x0, #0x3f0]                           T:UnityEngine.Events.UnityAction
02d27d48: bl      #0x2b70db0                                 fn_2b70db0
02d27d4c: mov     w8, #1                                     
02d27d50: strb    w8, [x21, #0x92]                           
02d27d54: mov     x21, x19                                   
02d27d58: mov     x1, x20                                    
02d27d5c: str     x20, [x21, #0x80]!                         ._homeScreen
02d27d60: mov     x0, x21                                    
02d27d64: bl      #0x2b70d54                                 fn_2b70d54
02d27d68: ldur    x20, [x21, #-0x40]                         
02d27d6c: cbz     x20, #0x2d27e4c                            
02d27d70: mov     x0, x20                                    
02d27d74: mov     x1, x19                                    
02d27d78: str     x19, [x0, #0x38]!                          ._canvasGroup
02d27d7c: bl      #0x2b70d54                                 fn_2b70d54
02d27d80: mov     x0, x20                                    
02d27d84: bl      #0x2d27174                                 Decor.CategoryPanel::Setup
02d27d88: ldr     x0, [x19, #0x48]                           ._optionPanel
02d27d8c: cbz     x0, #0x2d27e4c                             
02d27d90: mov     x1, x19                                    
02d27d94: bl      #0x2d27e50                                 Decor.OptionPanel::OnInit
02d27d98: ldr     x8, [x19, #0x30]                           ._btnClose
02d27d9c: cbz     x8, #0x2d27e4c                             
02d27da0: adrp    x9, #0x6265000                             
02d27da4: adrp    x21, #0x626a000                            
02d27da8: ldr     x9, [x9, #0x3f0]                           T:UnityEngine.Events.UnityAction
02d27dac: ldr     x21, [x21, #0x1d0]                         M:Decor.DecorPanel::OnButtonCloseClicked
02d27db0: ldr     x20, [x8, #0x100]                          
02d27db4: ldr     x0, [x9]                                   M:AdsManager::<OnApplicationPause>b__26_0
02d27db8: bl      #0x2b7104c                                 fn_2b7104c
02d27dbc: ldr     x2, [x21]                                  T:type56879(k15)
02d27dc0: mov     x1, x19                                    
02d27dc4: mov     x3, xzr                                    
02d27dc8: mov     x21, x0                                    
02d27dcc: bl      #0x5b4cf98                                 UnityEngine.Events.UnityAction::.ctor
02d27dd0: cbz     x20, #0x2d27e4c                            
02d27dd4: mov     x0, x20                                    
02d27dd8: mov     x1, x21                                    
02d27ddc: mov     x2, xzr                                    
02d27de0: bl      #0x5b4d0ac                                 UnityEngine.Events.UnityEvent::AddListener
02d27de4: ldr     x0, [x19, #0x28]                           ._panel
02d27de8: cbz     x0, #0x2d27e4c                             
02d27dec: mov     x1, xzr                                    
02d27df0: bl      #0x5b45734                                 UnityEngine.RectTransform::get_anchoredPosition
02d27df4: ldr     x0, [x19, #0x28]                           ._panel
02d27df8: stp     s0, s1, [x19, #0x70]                       ._initialPosition
02d27dfc: str     wzr, [x19, #0x78]                          
02d27e00: cbz     x0, #0x2d27e4c                             
02d27e04: mov     x1, xzr                                    
02d27e08: fmov    s8, s1                                     
02d27e0c: bl      #0x5b458c8                                 UnityEngine.RectTransform::get_sizeDelta
02d27e10: ldr     s0, [x19, #0x58]                           ._yOffset
02d27e14: ldr     x0, [x19, #0x28]                           ._panel
02d27e18: mov     x1, xzr                                    
02d27e1c: fadd    s0, s1, s0                                 
02d27e20: fsub    s0, s8, s0                                 
02d27e24: str     s0, [x19, #0x7c]                           ._hideYPosition
02d27e28: bl      #0x2dbf2fc                                 Redcode.Extensions.RectTransformExtensions::SetAnchoredPositionY
02d27e2c: ldr     x0, [x19, #0x38]                           ._canvasGroup
02d27e30: ldp     x20, x19, [sp, #0x20]                      
02d27e34: ldp     x30, x21, [sp, #0x10]                      
02d27e38: movi    d0, #0000000000000000                      
02d27e3c: mov     w1, wzr                                    
02d27e40: mov     x2, xzr                                    
02d27e44: ldr     d8, [sp], #0x30                            
02d27e48: b       #0x2cf1928                                 FrameWorkUtility::SetActive
02d27e4c: bl      #0x2b7105c                                 fn_2b7105c
## OnInit(ScreenHome homeScreen) -> void
---- Decor.DecorPanel::OnInit 0x2d27ee4
02d27ee4: str     d8, [sp, #-0x40]!                          
02d27ee8: stp     x30, x23, [sp, #0x10]                      
02d27eec: stp     x22, x21, [sp, #0x20]                      
02d27ef0: stp     x20, x19, [sp, #0x30]                      
02d27ef4: adrp    x21, #0x6630000                            
02d27ef8: mov     x20, x1                                    
02d27efc: mov     x19, x0                                    
02d27f00: ldrb    w8, [x21, #0x93]                           
02d27f04: tbnz    w8, #0, #0x2d27f28                         
02d27f08: adrp    x0, #0x626a000                             
02d27f0c: ldr     x0, [x0, #0x1d0]                           M:Decor.DecorPanel::OnButtonCloseClicked
02d27f10: bl      #0x2b70db0                                 fn_2b70db0
02d27f14: adrp    x0, #0x6265000                             
02d27f18: ldr     x0, [x0, #0x3f0]                           T:UnityEngine.Events.UnityAction
02d27f1c: bl      #0x2b70db0                                 fn_2b70db0
02d27f20: mov     w8, #1                                     
02d27f24: strb    w8, [x21, #0x93]                           
02d27f28: mov     x21, x19                                   
02d27f2c: mov     x1, x20                                    
02d27f30: str     x20, [x21, #0x88]!                         ._jellyScreen
02d27f34: mov     x0, x21                                    
02d27f38: bl      #0x2b70d54                                 fn_2b70d54
02d27f3c: ldur    x20, [x21, #-0x48]                         
02d27f40: cbz     x20, #0x2d28060                            
02d27f44: mov     x0, x20                                    
02d27f48: mov     x1, x19                                    
02d27f4c: str     x19, [x0, #0x38]!                          ._canvasGroup
02d27f50: bl      #0x2b70d54                                 fn_2b70d54
02d27f54: mov     x0, x20                                    
02d27f58: bl      #0x2d27174                                 Decor.CategoryPanel::Setup
02d27f5c: ldr     x0, [x19, #0x48]                           ._optionPanel
02d27f60: cbz     x0, #0x2d28060                             
02d27f64: mov     x1, x19                                    
02d27f68: bl      #0x2d27e50                                 Decor.OptionPanel::OnInit
02d27f6c: ldr     x8, [x19, #0x30]                           ._btnClose
02d27f70: cbz     x8, #0x2d28060                             
02d27f74: adrp    x23, #0x6265000                            
02d27f78: adrp    x22, #0x626a000                            
02d27f7c: ldr     x23, [x23, #0x3f0]                         T:UnityEngine.Events.UnityAction
02d27f80: ldr     x22, [x22, #0x1d0]                         M:Decor.DecorPanel::OnButtonCloseClicked
02d27f84: ldr     x20, [x8, #0x100]                          
02d27f88: ldr     x0, [x23]                                  M:AdsManager::<OnApplicationPause>b__26_0
02d27f8c: bl      #0x2b7104c                                 fn_2b7104c
02d27f90: ldr     x2, [x22]                                  T:type56879(k15)
02d27f94: mov     x1, x19                                    
02d27f98: mov     x3, xzr                                    
02d27f9c: mov     x21, x0                                    
02d27fa0: bl      #0x5b4cf98                                 UnityEngine.Events.UnityAction::.ctor
02d27fa4: cbz     x20, #0x2d28060                            
02d27fa8: mov     x0, x20                                    
02d27fac: mov     x1, x21                                    
02d27fb0: mov     x2, xzr                                    
02d27fb4: bl      #0x5b4d0ac                                 UnityEngine.Events.UnityEvent::AddListener
02d27fb8: ldr     x8, [x19, #0x60]                           ._closeButton
02d27fbc: cbz     x8, #0x2d28060                             
02d27fc0: ldr     x0, [x23]                                  M:AdsManager::<OnApplicationPause>b__26_0
02d27fc4: ldr     x20, [x8, #0x100]                          
02d27fc8: bl      #0x2b7104c                                 fn_2b7104c
02d27fcc: ldr     x2, [x22]                                  T:type56879(k15)
02d27fd0: mov     x1, x19                                    
02d27fd4: mov     x3, xzr                                    
02d27fd8: mov     x21, x0                                    
02d27fdc: bl      #0x5b4cf98                                 UnityEngine.Events.UnityAction::.ctor
02d27fe0: cbz     x20, #0x2d28060                            
02d27fe4: mov     x0, x20                                    
02d27fe8: mov     x1, x21                                    
02d27fec: mov     x2, xzr                                    
02d27ff0: bl      #0x5b4d0ac                                 UnityEngine.Events.UnityEvent::AddListener
02d27ff4: ldr     x0, [x19, #0x28]                           ._panel
02d27ff8: cbz     x0, #0x2d28060                             
02d27ffc: mov     x1, xzr                                    
02d28000: bl      #0x5b45734                                 UnityEngine.RectTransform::get_anchoredPosition
02d28004: ldr     x0, [x19, #0x28]                           ._panel
02d28008: stp     s0, s1, [x19, #0x70]                       ._initialPosition
02d2800c: str     wzr, [x19, #0x78]                          
02d28010: cbz     x0, #0x2d28060                             
02d28014: mov     x1, xzr                                    
02d28018: fmov    s8, s1                                     
02d2801c: bl      #0x5b458c8                                 UnityEngine.RectTransform::get_sizeDelta
02d28020: ldr     s0, [x19, #0x58]                           ._yOffset
02d28024: ldr     x0, [x19, #0x28]                           ._panel
02d28028: mov     x1, xzr                                    
02d2802c: fadd    s0, s1, s0                                 
02d28030: fsub    s0, s8, s0                                 
02d28034: str     s0, [x19, #0x7c]                           ._hideYPosition
02d28038: bl      #0x2dbf2fc                                 Redcode.Extensions.RectTransformExtensions::SetAnchoredPositionY
02d2803c: ldr     x0, [x19, #0x38]                           ._canvasGroup
02d28040: ldp     x20, x19, [sp, #0x30]                      
02d28044: ldp     x22, x21, [sp, #0x20]                      
02d28048: movi    d0, #0000000000000000                      
02d2804c: ldp     x30, x23, [sp, #0x10]                      
02d28050: mov     w1, wzr                                    
02d28054: mov     x2, xzr                                    
02d28058: ldr     d8, [sp], #0x40                            
02d2805c: b       #0x2cf1928                                 FrameWorkUtility::SetActive
02d28060: bl      #0x2b7105c                                 fn_2b7105c
## OnShow() -> void
---- Decor.DecorPanel::OnShow 0x2d28064
02d28064: str     d8, [sp, #-0x20]!                          
02d28068: stp     x30, x19, [sp, #0x10]                      
02d2806c: movi    d0, #0000000000000000                      
02d28070: mov     x19, x0                                    
02d28074: ldr     x0, [x0, #0x38]                            ._canvasGroup
02d28078: mov     w1, #1                                     
02d2807c: mov     x2, xzr                                    
02d28080: bl      #0x2cf1928                                 FrameWorkUtility::SetActive
02d28084: ldr     x0, [x19, #0x28]                           ._panel
02d28088: mov     w1, wzr                                    
02d2808c: mov     x2, xzr                                    
02d28090: bl      #0x2d9d5d0                                 DG.Tweening.ShortcutExtensions::DOKill
02d28094: adrp    x8, #0x1084000                             
02d28098: ldr     x0, [x19, #0x28]                           ._panel
02d2809c: ldr     s0, [x19, #0x74]                           
02d280a0: ldr     s8, [x8, #0xda8]                           [1084da8]=da242603eb851ec f=0.36,1e-30
02d280a4: mov     w1, wzr                                    
02d280a8: mov     x2, xzr                                    
02d280ac: fmov    s1, s8                                     
02d280b0: bl      #0x2c79c1c                                 DG.Tweening.DOTweenModuleUI::DOAnchorPosY
02d280b4: ldr     x0, [x19, #0x40]                           ._categoryPanel
02d280b8: cbz     x0, #0x2d280f0                             
02d280bc: bl      #0x2d273ac                                 Decor.CategoryPanel::SelectDefaultCategory
02d280c0: ldr     x8, [x19, #0x90]                           .OnShowPanel
02d280c4: cbz     x8, #0x2d280e4                             
02d280c8: ldp     x30, x19, [sp, #0x10]                      
02d280cc: fmov    s0, s8                                     
02d280d0: ldr     x0, [x8, #0x40]                            [1084040]=5500292864496c6f f=1.48624e+22,8.80714e+12
02d280d4: ldr     x1, [x8, #0x28]                            [1084028]=6e6f436472616f62 f=4.4652e+30,1.85121e+28
02d280d8: ldr     x2, [x8, #0x18]                            [1084018]=7974696c69745549 f=1.84613e+25,7.93162e+34
02d280dc: ldr     d8, [sp], #0x20                            
02d280e0: br      x2                                         
02d280e4: ldp     x30, x19, [sp, #0x10]                      
02d280e8: ldr     d8, [sp], #0x20                            
02d280ec: ret                                                
02d280f0: bl      #0x2b7105c                                 fn_2b7105c
## OnHide() -> void
---- Decor.DecorPanel::OnHide 0x2d280f4
02d280f4: str     d8, [sp, #-0x40]!                          
02d280f8: stp     x30, x23, [sp, #0x10]                      
02d280fc: stp     x22, x21, [sp, #0x20]                      
02d28100: stp     x20, x19, [sp, #0x30]                      
02d28104: adrp    x23, #0x6630000                            
02d28108: adrp    x20, #0x6264000                            
02d2810c: adrp    x21, #0x626a000                            
02d28110: adrp    x22, #0x6266000                            
02d28114: ldr     x20, [x20, #0xe8]                          T:DG.Tweening.TweenCallback
02d28118: ldrb    w8, [x23, #0x94]                           
02d2811c: ldr     x21, [x21, #0x1d8]                         M:Decor.DecorPanel::<OnHide>b__23_0
02d28120: ldr     x22, [x22, #0xa08]                         MS:DG.Tweening.TweenSettingsExtensions::OnComplete
02d28124: mov     x19, x0                                    
02d28128: tbnz    w8, #0, #0x2d28158                         
02d2812c: adrp    x0, #0x626a000                             
02d28130: ldr     x0, [x0, #0x1d8]                           M:Decor.DecorPanel::<OnHide>b__23_0
02d28134: bl      #0x2b70db0                                 fn_2b70db0
02d28138: adrp    x0, #0x6264000                             
02d2813c: ldr     x0, [x0, #0xe8]                            T:DG.Tweening.TweenCallback
02d28140: bl      #0x2b70db0                                 fn_2b70db0
02d28144: adrp    x0, #0x6266000                             
02d28148: ldr     x0, [x0, #0xa08]                           MS:DG.Tweening.TweenSettingsExtensions::OnComplete
02d2814c: bl      #0x2b70db0                                 fn_2b70db0
02d28150: mov     w8, #1                                     
02d28154: strb    w8, [x23, #0x94]                           
02d28158: ldr     x0, [x19, #0x28]                           ._panel
02d2815c: mov     w1, wzr                                    
02d28160: mov     x2, xzr                                    
02d28164: bl      #0x2d9d5d0                                 DG.Tweening.ShortcutExtensions::DOKill
02d28168: adrp    x8, #0x1084000                             
02d2816c: ldr     x0, [x19, #0x28]                           ._panel
02d28170: ldr     s0, [x19, #0x7c]                           ._hideYPosition
02d28174: ldr     s8, [x8, #0xda8]                           [1084da8]=da242603eb851ec f=0.36,1e-30
02d28178: mov     w1, wzr                                    
02d2817c: mov     x2, xzr                                    
02d28180: fmov    s1, s8                                     
02d28184: bl      #0x2c79c1c                                 DG.Tweening.DOTweenModuleUI::DOAnchorPosY
02d28188: ldr     x8, [x20]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d2818c: mov     x20, x0                                    
02d28190: mov     x0, x8                                     
02d28194: bl      #0x2b7104c                                 fn_2b7104c
02d28198: ldr     x2, [x21]                                  T:type56879(k15)
02d2819c: mov     x1, x19                                    
02d281a0: mov     x3, xzr                                    
02d281a4: mov     x21, x0                                    
02d281a8: bl      #0x2d89dc4                                 DG.Tweening.TweenCallback::.ctor
02d281ac: ldr     x2, [x22]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d281b0: mov     x0, x20                                    
02d281b4: mov     x1, x21                                    
02d281b8: bl      #0x336f26c                                 fn_336f26c
02d281bc: ldr     x8, [x19, #0x98]                           .OnHidePanel
02d281c0: cbz     x8, #0x2d281e8                             
02d281c4: ldp     x20, x19, [sp, #0x30]                      
02d281c8: fmov    s0, s8                                     
02d281cc: ldp     x22, x21, [sp, #0x20]                      
02d281d0: ldr     x0, [x8, #0x40]                            [1084040]=5500292864496c6f f=1.48624e+22,8.80714e+12
02d281d4: ldp     x30, x23, [sp, #0x10]                      
02d281d8: ldr     x1, [x8, #0x28]                            [1084028]=6e6f436472616f62 f=4.4652e+30,1.85121e+28
02d281dc: ldr     x2, [x8, #0x18]                            [1084018]=7974696c69745549 f=1.84613e+25,7.93162e+34
02d281e0: ldr     d8, [sp], #0x40                            
02d281e4: br      x2                                         
02d281e8: ldp     x20, x19, [sp, #0x30]                      
02d281ec: ldp     x22, x21, [sp, #0x20]                      
02d281f0: ldp     x30, x23, [sp, #0x10]                      
02d281f4: ldr     d8, [sp], #0x40                            
02d281f8: ret                                                
## RegisterCloseAction(UnityEngine.Events.UnityAction action) -> Decor.DecorPanel
---- Decor.DecorPanel::RegisterCloseAction 0x2d281fc
02d281fc: stp     x30, x19, [sp, #-0x10]!                    
02d28200: mov     x19, x0                                    
02d28204: str     x1, [x0, #0x68]!                           ._onClosePopupAction
02d28208: bl      #0x2b70d54                                 fn_2b70d54
02d2820c: mov     x0, x19                                    
02d28210: ldp     x30, x19, [sp], #0x10                      
02d28214: ret                                                
## SetActiveIconNoti(bool isActive) -> void
---- Decor.DecorPanel::SetActiveIconNoti 0x2d27848
02d27848: ldr     x0, [x0, #0x50]                            ._iconNoti
02d2784c: cbz     x0, #0x2d2785c                             
02d27850: and     w1, w1, #1                                 
02d27854: mov     x2, xzr                                    
02d27858: b       #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d2785c: str     x30, [sp, #-0x10]!                         
02d27860: bl      #0x2b7105c                                 fn_2b7105c
## OnButtonCloseClicked() -> void
---- Decor.DecorPanel::OnButtonCloseClicked 0x2d28218
02d28218: stp     x30, x19, [sp, #-0x10]!                    
02d2821c: mov     x19, x0                                    
02d28220: mov     x0, xzr                                    
02d28224: bl      #0x2d6eec8                                 Framework.AudioManager::get_Instance
02d28228: cbz     x0, #0x2d2828c                             
02d2822c: movi    d1, #0000000000000000                      
02d28230: movi    d2, #0000000000000000                      
02d28234: mov     w1, #1                                     
02d28238: fmov    s0, #1.00000000                            
02d2823c: mov     w2, wzr                                    
02d28240: mov     w3, wzr                                    
02d28244: mov     x4, xzr                                    
02d28248: bl      #0x2d6f03c                                 Framework.AudioManager::PlaySound
02d2824c: mov     x0, x19                                    
02d28250: bl      #0x2d280f4                                 Decor.DecorPanel::OnHide
02d28254: ldr     x0, [x19, #0x88]                           ._jellyScreen
02d28258: cbz     x0, #0x2d2828c                             
02d2825c: fmov    s0, #0.50000000                            
02d28260: mov     x1, xzr                                    
02d28264: bl      #0x2cb28c8                                 ScreenHome::OnShowButtons
02d28268: ldr     x8, [x19, #0x68]                           ._onClosePopupAction
02d2826c: cbz     x8, #0x2d28284                             
02d28270: ldr     x0, [x8, #0x40]                            
02d28274: ldr     x1, [x8, #0x28]                            
02d28278: ldr     x2, [x8, #0x18]                            
02d2827c: ldp     x30, x19, [sp], #0x10                      
02d28280: br      x2                                         
02d28284: ldp     x30, x19, [sp], #0x10                      
02d28288: ret                                                
02d2828c: bl      #0x2b7105c                                 fn_2b7105c
## .ctor() -> void
---- Decor.DecorPanel::.ctor 0x2d28290
02d28290: mov     w8, #0x43480000                            
02d28294: mov     x1, xzr                                    
02d28298: str     w8, [x0, #0x58]                            ._yOffset
02d2829c: b       #0x5b397b0                                 UnityEngine.MonoBehaviour::.ctor
## <OnHide>b__23_0() -> void
---- Decor.DecorPanel::<OnHide>b__23_0 0x2d282a0
02d282a0: movi    d0, #0000000000000000                      
02d282a4: ldr     x0, [x0, #0x38]                            ._canvasGroup
02d282a8: mov     w1, wzr                                    
02d282ac: mov     x2, xzr                                    
02d282b0: b       #0x2cf1928                                 FrameWorkUtility::SetActive
