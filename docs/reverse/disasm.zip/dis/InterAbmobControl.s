#### CLASS InterAbmobControl parent= AdmobEventBase
#   field _interstitialAd                GoogleMobileAds.Api.InterstitialAd                 off=0x40 attr=1 
#   field _action                        System.Action                                      off=0x48 attr=1 
## Start() -> void
---- InterAbmobControl::Start 0x2c92790
02c92790: stp     x30, x21, [sp, #-0x20]!                    
02c92794: stp     x20, x19, [sp, #0x10]                      
02c92798: adrp    x21, #0x662f000                            
02c9279c: adrp    x20, #0x6265000                            
02c927a0: mov     x19, x0                                    
02c927a4: ldrb    w8, [x21, #0x9d4]                          
02c927a8: ldr     x20, [x20, #0x310]                         MS:WejoyService.Singleton`1::get_Instance
02c927ac: tbnz    w8, #0, #0x2c927d0                         
02c927b0: adrp    x0, #0x6265000                             
02c927b4: ldr     x0, [x0, #0x488]                           T:KeyTest
02c927b8: bl      #0x2b70db0                                 fn_2b70db0
02c927bc: adrp    x0, #0x6265000                             
02c927c0: ldr     x0, [x0, #0x310]                           MS:WejoyService.Singleton`1::get_Instance
02c927c4: bl      #0x2b70db0                                 fn_2b70db0
02c927c8: mov     w8, #1                                     
02c927cc: strb    w8, [x21, #0x9d4]                          
02c927d0: mov     w0, #7                                     
02c927d4: bl      #0x2c8de38                                 KeyAds::Get
02c927d8: mov     x1, x0                                     
02c927dc: str     x0, [x19, #0x28]!                          
02c927e0: mov     x0, x19                                    
02c927e4: bl      #0x2b70d54                                 fn_2b70d54
02c927e8: ldr     x0, [x20]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c927ec: bl      #0x3be7218                                 fn_3be7218
02c927f0: cbz     x0, #0x2c92840                             
02c927f4: ldrb    w8, [x0, #0x31]                            
02c927f8: cbz     w8, #0x2c92834                             
02c927fc: adrp    x20, #0x6265000                            
02c92800: ldr     x20, [x20, #0x488]                         T:KeyTest
02c92804: ldr     x0, [x20]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c92808: ldr     w8, [x0, #0xe4]                            [62650e4]=0 f=0,0
02c9280c: cbnz    w8, #0x2c92818                             
02c92810: bl      #0x2b70f30                                 fn_2b70f30
02c92814: ldr     x0, [x20]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c92818: ldr     x8, [x0, #0xb8]                            T:AdsManager/<>c__DisplayClass42_0
02c9281c: mov     x0, x19                                    
02c92820: ldr     x1, [x8, #8]                               
02c92824: str     x1, [x19]                                  
02c92828: ldp     x20, x19, [sp, #0x10]                      
02c9282c: ldp     x30, x21, [sp], #0x20                      
02c92830: b       #0x2b70d54                                 
02c92834: ldp     x20, x19, [sp, #0x10]                      
02c92838: ldp     x30, x21, [sp], #0x20                      
02c9283c: ret                                                
02c92840: bl      #0x2b7105c                                 fn_2b7105c
## LoadAd() -> void
---- InterAbmobControl::LoadAd 0x2c92844
02c92844: stp     x30, x23, [sp, #-0x30]!                    
02c92848: stp     x22, x21, [sp, #0x10]                      
02c9284c: stp     x20, x19, [sp, #0x20]                      
02c92850: adrp    x20, #0x662f000                            
02c92854: mov     x19, x0                                    
02c92858: ldrb    w8, [x20, #0x9d5]                          
02c9285c: tbnz    w8, #0, #0x2c92898                         
02c92860: adrp    x0, #0x6265000                             
02c92864: ldr     x0, [x0, #0x6d0]                           T:type7175(k15)
02c92868: bl      #0x2b70db0                                 fn_2b70db0
02c9286c: adrp    x0, #0x6265000                             
02c92870: ldr     x0, [x0, #0x498]                           T:GoogleMobileAds.Api.AdRequest
02c92874: bl      #0x2b70db0                                 fn_2b70db0
02c92878: adrp    x0, #0x6265000                             
02c9287c: ldr     x0, [x0, #0x6d8]                           M:InterAbmobControl::<LoadAd>b__3_0
02c92880: bl      #0x2b70db0                                 fn_2b70db0
02c92884: adrp    x0, #0x6265000                             
02c92888: ldr     x0, [x0, #0x6e0]                           S:'Loading interstitial ad.'
02c9288c: bl      #0x2b70db0                                 fn_2b70db0
02c92890: mov     w8, #1                                     
02c92894: strb    w8, [x20, #0x9d5]                          
02c92898: adrp    x21, #0x6265000                            
02c9289c: adrp    x20, #0x6265000                            
02c928a0: adrp    x23, #0x6265000                            
02c928a4: adrp    x22, #0x6265000                            
02c928a8: ldr     x21, [x21, #0x6e0]                         S:'Loading interstitial ad.'
02c928ac: ldr     x20, [x20, #0x498]                         T:GoogleMobileAds.Api.AdRequest
02c928b0: ldr     x23, [x23, #0x6d0]                         T:type7175(k15)
02c928b4: ldr     x8, [x19, #0x40]                           ._interstitialAd
02c928b8: ldr     x22, [x22, #0x6d8]                         M:InterAbmobControl::<LoadAd>b__3_0
02c928bc: cbz     x8, #0x2c928c8                             
02c928c0: mov     x0, x19                                    
02c928c4: bl      #0x2c92928                                 InterAbmobControl::DestroyAd
02c928c8: ldr     x0, [x21]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c928cc: mov     x1, xzr                                    
02c928d0: bl      #0x2ca46ac                                 WLog::Log
02c928d4: ldr     x0, [x20]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c928d8: bl      #0x2b7104c                                 fn_2b7104c
02c928dc: mov     x1, xzr                                    
02c928e0: mov     x20, x0                                    
02c928e4: bl      #0x4c2fe94                                 GoogleMobileAds.Api.AdRequest::.ctor
02c928e8: ldr     x0, [x23]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c928ec: ldr     x21, [x19, #0x28]                          
02c928f0: bl      #0x2b7104c                                 fn_2b7104c
02c928f4: ldr     x2, [x22]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c928f8: mov     x1, x19                                    
02c928fc: mov     x3, xzr                                    
02c92900: mov     x22, x0                                    
02c92904: bl      #0x453ce6c                                 fn_453ce6c
02c92908: mov     x0, x21                                    
02c9290c: mov     x1, x20                                    
02c92910: mov     x2, x22                                    
02c92914: ldp     x20, x19, [sp, #0x20]                      
02c92918: mov     x3, xzr                                    
02c9291c: ldp     x22, x21, [sp, #0x10]                      
02c92920: ldp     x30, x23, [sp], #0x30                      
02c92924: b       #0x4c3a158                                 GoogleMobileAds.Api.InterstitialAd::Load
## IsAdReady() -> bool
---- InterAbmobControl::IsAdReady 0x2c91930
02c91930: ldr     x0, [x0, #0x40]                            ._interstitialAd
02c91934: cbz     x0, #0x2c91940                             
02c91938: mov     x1, xzr                                    
02c9193c: b       #0x4c3a514                                 GoogleMobileAds.Api.InterstitialAd::CanShowAd
02c91940: ret                                                
## DestroyAd() -> void
---- InterAbmobControl::DestroyAd 0x2c92928
02c92928: str     x30, [sp, #-0x20]!                         
02c9292c: stp     x20, x19, [sp, #0x10]                      
02c92930: mov     x19, x0                                    
02c92934: ldr     x1, [x19, #0x40]!                          ._interstitialAd
02c92938: cbz     x1, #0x2c9296c                             
02c9293c: mov     x20, x0                                    
02c92940: bl      #0x2c9297c                                 InterAbmobControl::RemoveEventHandlers
02c92944: ldr     x0, [x20, #0x40]                           ._interstitialAd
02c92948: cbz     x0, #0x2c92978                             
02c9294c: mov     x1, xzr                                    
02c92950: bl      #0x4c3a5ec                                 GoogleMobileAds.Api.InterstitialAd::Destroy
02c92954: mov     x0, x19                                    
02c92958: str     xzr, [x19]                                 
02c9295c: mov     x1, xzr                                    
02c92960: ldp     x20, x19, [sp, #0x10]                      
02c92964: ldr     x30, [sp], #0x20                           
02c92968: b       #0x2b70d54                                 
02c9296c: ldp     x20, x19, [sp, #0x10]                      
02c92970: ldr     x30, [sp], #0x20                           
02c92974: ret                                                
02c92978: bl      #0x2b7105c                                 fn_2b7105c
## ShowAd(string placement, System.Action action) -> void
---- InterAbmobControl::ShowAd 0x2c91954
02c91954: str     x30, [sp, #-0x30]!                         
02c91958: stp     x22, x21, [sp, #0x10]                      
02c9195c: stp     x20, x19, [sp, #0x20]                      
02c91960: adrp    x22, #0x662f000                            
02c91964: mov     x19, x2                                    
02c91968: mov     x21, x1                                    
02c9196c: ldrb    w8, [x22, #0x9d6]                          
02c91970: mov     x20, x0                                    
02c91974: tbnz    w8, #0, #0x2c9198c                         
02c91978: adrp    x0, #0x6265000                             
02c9197c: ldr     x0, [x0, #0x5f8]                           S:'Interstitial ad is not ready yet.'
02c91980: bl      #0x2b70db0                                 fn_2b70db0
02c91984: mov     w8, #1                                     
02c91988: strb    w8, [x22, #0x9d6]                          
02c9198c: mov     x22, x20                                   
02c91990: mov     x1, x21                                    
02c91994: str     x21, [x22, #0x20]!                         
02c91998: mov     x0, x22                                    
02c9199c: bl      #0x2b70d54                                 fn_2b70d54
02c919a0: ldr     x0, [x22, #0x20]                           &2b706f0(=d65f03c0f9400800)
02c919a4: cbz     x0, #0x2c919e0                             
02c919a8: mov     x1, xzr                                    
02c919ac: bl      #0x4c3a514                                 GoogleMobileAds.Api.InterstitialAd::CanShowAd
02c919b0: tbz     w0, #0, #0x2c919e0                         
02c919b4: ldr     x0, [x20, #0x40]                           ._interstitialAd
02c919b8: cbz     x0, #0x2c91a00                             
02c919bc: mov     x1, xzr                                    
02c919c0: bl      #0x4c3a534                                 GoogleMobileAds.Api.InterstitialAd::Show
02c919c4: str     x19, [x20, #0x48]!                         ._action
02c919c8: mov     x0, x20                                    
02c919cc: mov     x1, x19                                    
02c919d0: ldp     x20, x19, [sp, #0x20]                      
02c919d4: ldp     x22, x21, [sp, #0x10]                      
02c919d8: ldr     x30, [sp], #0x30                           
02c919dc: b       #0x2b70d54                                 
02c919e0: adrp    x8, #0x6265000                             
02c919e4: mov     x1, xzr                                    
02c919e8: ldr     x8, [x8, #0x5f8]                           S:'Interstitial ad is not ready yet.'
02c919ec: ldp     x20, x19, [sp, #0x20]                      
02c919f0: ldp     x22, x21, [sp, #0x10]                      
02c919f4: ldr     x0, [x8]                                   M:AdsManager::<OnApplicationPause>b__26_0
02c919f8: ldr     x30, [sp], #0x30                           
02c919fc: b       #0x2ca09f8                                 WLog::LogError
02c91a00: bl      #0x2b7105c                                 fn_2b7105c
## RegisterEventHandlers(GoogleMobileAds.Api.InterstitialAd ad) -> void
---- InterAbmobControl::RegisterEventHandlers 0x2c92b20
02c92b20: str     x30, [sp, #-0x40]!                         
02c92b24: stp     x24, x23, [sp, #0x10]                      
02c92b28: stp     x22, x21, [sp, #0x20]                      
02c92b2c: stp     x20, x19, [sp, #0x30]                      
02c92b30: adrp    x21, #0x662f000                            
02c92b34: adrp    x22, #0x6264000                            
02c92b38: mov     x19, x1                                    
02c92b3c: ldrb    w8, [x21, #0x9d7]                          
02c92b40: ldr     x22, [x22, #0xf90]                         T:System.Action
02c92b44: mov     x20, x0                                    
02c92b48: tbnz    w8, #0, #0x2c92b78                         
02c92b4c: adrp    x0, #0x6265000                             
02c92b50: ldr     x0, [x0, #0x4b8]                           T:type6799(k15)
02c92b54: bl      #0x2b70db0                                 fn_2b70db0
02c92b58: adrp    x0, #0x6265000                             
02c92b5c: ldr     x0, [x0, #0x4c0]                           T:type6805(k15)
02c92b60: bl      #0x2b70db0                                 fn_2b70db0
02c92b64: adrp    x0, #0x6264000                             
02c92b68: ldr     x0, [x0, #0xf90]                           T:System.Action
02c92b6c: bl      #0x2b70db0                                 fn_2b70db0
02c92b70: mov     w8, #1                                     
02c92b74: strb    w8, [x21, #0x9d7]                          
02c92b78: ldr     x0, [x22]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c92b7c: bl      #0x2b7104c                                 fn_2b7104c
02c92b80: cbz     x20, #0x2c92cc0                            
02c92b84: ldr     x8, [x20]                                  
02c92b88: mov     x1, x20                                    
02c92b8c: mov     x3, xzr                                    
02c92b90: mov     x21, x0                                    
02c92b94: ldr     x2, [x8, #0x180]                           
02c92b98: bl      #0x4d8ddbc                                 System.Action::.ctor
02c92b9c: cbz     x19, #0x2c92cc0                            
02c92ba0: adrp    x24, #0x6265000                            
02c92ba4: adrp    x23, #0x6265000                            
02c92ba8: mov     x0, x19                                    
02c92bac: ldr     x24, [x24, #0x4b8]                         T:type6799(k15)
02c92bb0: ldr     x23, [x23, #0x4c0]                         T:type6805(k15)
02c92bb4: mov     x1, x21                                    
02c92bb8: mov     x2, xzr                                    
02c92bbc: bl      #0x4c39618                                 GoogleMobileAds.Api.InterstitialAd::add_OnAdClicked
02c92bc0: ldr     x0, [x22]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c92bc4: bl      #0x2b7104c                                 fn_2b7104c
02c92bc8: ldr     x8, [x20]                                  
02c92bcc: mov     x1, x20                                    
02c92bd0: mov     x3, xzr                                    
02c92bd4: mov     x21, x0                                    
02c92bd8: ldr     x2, [x8, #0x190]                           
02c92bdc: bl      #0x4d8ddbc                                 System.Action::.ctor
02c92be0: mov     x0, x19                                    
02c92be4: mov     x1, x21                                    
02c92be8: mov     x2, xzr                                    
02c92bec: bl      #0x4c399c0                                 GoogleMobileAds.Api.InterstitialAd::add_OnAdFullScreenContentClosed
02c92bf0: ldr     x0, [x24]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c92bf4: bl      #0x2b7104c                                 fn_2b7104c
02c92bf8: ldr     x8, [x20]                                  
02c92bfc: mov     x1, x20                                    
02c92c00: mov     x3, xzr                                    
02c92c04: mov     x21, x0                                    
02c92c08: ldr     x2, [x8, #0x1c0]                           
02c92c0c: bl      #0x453418c                                 fn_453418c
02c92c10: mov     x0, x19                                    
02c92c14: mov     x1, x21                                    
02c92c18: mov     x2, xzr                                    
02c92c1c: bl      #0x4c39af8                                 GoogleMobileAds.Api.InterstitialAd::add_OnAdFullScreenContentFailed
02c92c20: ldr     x0, [x22]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c92c24: bl      #0x2b7104c                                 fn_2b7104c
02c92c28: ldr     x8, [x20]                                  
02c92c2c: mov     x1, x20                                    
02c92c30: mov     x3, xzr                                    
02c92c34: mov     x21, x0                                    
02c92c38: ldr     x2, [x8, #0x1a0]                           
02c92c3c: bl      #0x4d8ddbc                                 System.Action::.ctor
02c92c40: mov     x0, x19                                    
02c92c44: mov     x1, x21                                    
02c92c48: mov     x2, xzr                                    
02c92c4c: bl      #0x4c39888                                 GoogleMobileAds.Api.InterstitialAd::add_OnAdFullScreenContentOpened
02c92c50: ldr     x0, [x22]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c92c54: bl      #0x2b7104c                                 fn_2b7104c
02c92c58: ldr     x8, [x20]                                  
02c92c5c: mov     x1, x20                                    
02c92c60: mov     x3, xzr                                    
02c92c64: mov     x21, x0                                    
02c92c68: ldr     x2, [x8, #0x1b0]                           
02c92c6c: bl      #0x4d8ddbc                                 System.Action::.ctor
02c92c70: mov     x0, x19                                    
02c92c74: mov     x1, x21                                    
02c92c78: mov     x2, xzr                                    
02c92c7c: bl      #0x4c39750                                 GoogleMobileAds.Api.InterstitialAd::add_OnAdImpressionRecorded
02c92c80: ldr     x0, [x23]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c92c84: bl      #0x2b7104c                                 fn_2b7104c
02c92c88: ldr     x8, [x20]                                  
02c92c8c: mov     x1, x20                                    
02c92c90: mov     x3, xzr                                    
02c92c94: mov     x21, x0                                    
02c92c98: ldr     x2, [x8, #0x1d0]                           
02c92c9c: bl      #0x453418c                                 fn_453418c
02c92ca0: mov     x0, x19                                    
02c92ca4: mov     x1, x21                                    
02c92ca8: mov     x2, xzr                                    
02c92cac: ldp     x20, x19, [sp, #0x30]                      
02c92cb0: ldp     x22, x21, [sp, #0x20]                      
02c92cb4: ldp     x24, x23, [sp, #0x10]                      
02c92cb8: ldr     x30, [sp], #0x40                           
02c92cbc: b       #0x4c394b8                                 GoogleMobileAds.Api.InterstitialAd::add_OnAdPaid
02c92cc0: bl      #0x2b7105c                                 fn_2b7105c
## RemoveEventHandlers(GoogleMobileAds.Api.InterstitialAd ad) -> void
---- InterAbmobControl::RemoveEventHandlers 0x2c9297c
02c9297c: str     x30, [sp, #-0x40]!                         
02c92980: stp     x24, x23, [sp, #0x10]                      
02c92984: stp     x22, x21, [sp, #0x20]                      
02c92988: stp     x20, x19, [sp, #0x30]                      
02c9298c: adrp    x21, #0x662f000                            
02c92990: adrp    x22, #0x6264000                            
02c92994: mov     x19, x1                                    
02c92998: ldrb    w8, [x21, #0x9d8]                          
02c9299c: ldr     x22, [x22, #0xf90]                         T:System.Action
02c929a0: mov     x20, x0                                    
02c929a4: tbnz    w8, #0, #0x2c929d4                         
02c929a8: adrp    x0, #0x6265000                             
02c929ac: ldr     x0, [x0, #0x4b8]                           T:type6799(k15)
02c929b0: bl      #0x2b70db0                                 fn_2b70db0
02c929b4: adrp    x0, #0x6265000                             
02c929b8: ldr     x0, [x0, #0x4c0]                           T:type6805(k15)
02c929bc: bl      #0x2b70db0                                 fn_2b70db0
02c929c0: adrp    x0, #0x6264000                             
02c929c4: ldr     x0, [x0, #0xf90]                           T:System.Action
02c929c8: bl      #0x2b70db0                                 fn_2b70db0
02c929cc: mov     w8, #1                                     
02c929d0: strb    w8, [x21, #0x9d8]                          
02c929d4: ldr     x0, [x22]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c929d8: bl      #0x2b7104c                                 fn_2b7104c
02c929dc: cbz     x20, #0x2c92b1c                            
02c929e0: ldr     x8, [x20]                                  
02c929e4: mov     x1, x20                                    
02c929e8: mov     x3, xzr                                    
02c929ec: mov     x21, x0                                    
02c929f0: ldr     x2, [x8, #0x180]                           
02c929f4: bl      #0x4d8ddbc                                 System.Action::.ctor
02c929f8: cbz     x19, #0x2c92b1c                            
02c929fc: adrp    x24, #0x6265000                            
02c92a00: adrp    x23, #0x6265000                            
02c92a04: mov     x0, x19                                    
02c92a08: ldr     x24, [x24, #0x4b8]                         T:type6799(k15)
02c92a0c: ldr     x23, [x23, #0x4c0]                         T:type6805(k15)
02c92a10: mov     x1, x21                                    
02c92a14: mov     x2, xzr                                    
02c92a18: bl      #0x4c396b4                                 GoogleMobileAds.Api.InterstitialAd::remove_OnAdClicked
02c92a1c: ldr     x0, [x22]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c92a20: bl      #0x2b7104c                                 fn_2b7104c
02c92a24: ldr     x8, [x20]                                  
02c92a28: mov     x1, x20                                    
02c92a2c: mov     x3, xzr                                    
02c92a30: mov     x21, x0                                    
02c92a34: ldr     x2, [x8, #0x190]                           
02c92a38: bl      #0x4d8ddbc                                 System.Action::.ctor
02c92a3c: mov     x0, x19                                    
02c92a40: mov     x1, x21                                    
02c92a44: mov     x2, xzr                                    
02c92a48: bl      #0x4c39a5c                                 GoogleMobileAds.Api.InterstitialAd::remove_OnAdFullScreenContentClosed
02c92a4c: ldr     x0, [x24]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c92a50: bl      #0x2b7104c                                 fn_2b7104c
02c92a54: ldr     x8, [x20]                                  
02c92a58: mov     x1, x20                                    
02c92a5c: mov     x3, xzr                                    
02c92a60: mov     x21, x0                                    
02c92a64: ldr     x2, [x8, #0x1c0]                           
02c92a68: bl      #0x453418c                                 fn_453418c
02c92a6c: mov     x0, x19                                    
02c92a70: mov     x1, x21                                    
02c92a74: mov     x2, xzr                                    
02c92a78: bl      #0x4c39ba8                                 GoogleMobileAds.Api.InterstitialAd::remove_OnAdFullScreenContentFailed
02c92a7c: ldr     x0, [x22]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c92a80: bl      #0x2b7104c                                 fn_2b7104c
02c92a84: ldr     x8, [x20]                                  
02c92a88: mov     x1, x20                                    
02c92a8c: mov     x3, xzr                                    
02c92a90: mov     x21, x0                                    
02c92a94: ldr     x2, [x8, #0x1a0]                           
02c92a98: bl      #0x4d8ddbc                                 System.Action::.ctor
02c92a9c: mov     x0, x19                                    
02c92aa0: mov     x1, x21                                    
02c92aa4: mov     x2, xzr                                    
02c92aa8: bl      #0x4c39924                                 GoogleMobileAds.Api.InterstitialAd::remove_OnAdFullScreenContentOpened
02c92aac: ldr     x0, [x22]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c92ab0: bl      #0x2b7104c                                 fn_2b7104c
02c92ab4: ldr     x8, [x20]                                  
02c92ab8: mov     x1, x20                                    
02c92abc: mov     x3, xzr                                    
02c92ac0: mov     x21, x0                                    
02c92ac4: ldr     x2, [x8, #0x1b0]                           
02c92ac8: bl      #0x4d8ddbc                                 System.Action::.ctor
02c92acc: mov     x0, x19                                    
02c92ad0: mov     x1, x21                                    
02c92ad4: mov     x2, xzr                                    
02c92ad8: bl      #0x4c397ec                                 GoogleMobileAds.Api.InterstitialAd::remove_OnAdImpressionRecorded
02c92adc: ldr     x0, [x23]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c92ae0: bl      #0x2b7104c                                 fn_2b7104c
02c92ae4: ldr     x8, [x20]                                  
02c92ae8: mov     x1, x20                                    
02c92aec: mov     x3, xzr                                    
02c92af0: mov     x21, x0                                    
02c92af4: ldr     x2, [x8, #0x1d0]                           
02c92af8: bl      #0x453418c                                 fn_453418c
02c92afc: mov     x0, x19                                    
02c92b00: mov     x1, x21                                    
02c92b04: mov     x2, xzr                                    
02c92b08: ldp     x20, x19, [sp, #0x30]                      
02c92b0c: ldp     x22, x21, [sp, #0x20]                      
02c92b10: ldp     x24, x23, [sp, #0x10]                      
02c92b14: ldr     x30, [sp], #0x40                           
02c92b18: b       #0x4c39568                                 GoogleMobileAds.Api.InterstitialAd::remove_OnAdPaid
02c92b1c: bl      #0x2b7105c                                 fn_2b7105c
## OnAdFullScreenContentClosed() -> void
---- InterAbmobControl::OnAdFullScreenContentClosed 0x2c92cc4
02c92cc4: stp     x30, x19, [sp, #-0x10]!                    
02c92cc8: ldr     x8, [x0, #0x48]                            ._action
02c92ccc: mov     x19, x0                                    
02c92cd0: cbz     x8, #0x2c92ce4                             
02c92cd4: ldr     x9, [x8, #0x18]                            
02c92cd8: ldr     x0, [x8, #0x40]                            
02c92cdc: ldr     x1, [x8, #0x28]                            
02c92ce0: blr     x9                                         
02c92ce4: mov     x0, x19                                    
02c92ce8: ldp     x30, x19, [sp], #0x10                      
02c92cec: b       #0x2c92844                                 InterAbmobControl::LoadAd
## OnAdFullScreenContentFailed(GoogleMobileAds.Api.AdError adError) -> void
---- InterAbmobControl::OnAdFullScreenContentFailed 0x2c92cf0
02c92cf0: stp     x30, x19, [sp, #-0x10]!                    
02c92cf4: mov     x19, x0                                    
02c92cf8: bl      #0x2c8f588                                 AdmobEventBase::OnAdFullScreenContentFailed
02c92cfc: ldr     x8, [x19, #0x48]                           ._action
02c92d00: cbz     x8, #0x2c92d14                             
02c92d04: ldr     x9, [x8, #0x18]                            
02c92d08: ldr     x0, [x8, #0x40]                            
02c92d0c: ldr     x1, [x8, #0x28]                            
02c92d10: blr     x9                                         
02c92d14: mov     x0, x19                                    
02c92d18: ldp     x30, x19, [sp], #0x10                      
02c92d1c: b       #0x2c92844                                 InterAbmobControl::LoadAd
## OnAdPaid(GoogleMobileAds.Api.AdValue adValue) -> void
---- InterAbmobControl::OnAdPaid 0x2c92d20
02c92d20: str     x30, [sp, #-0x30]!                         
02c92d24: stp     x22, x21, [sp, #0x10]                      
02c92d28: stp     x20, x19, [sp, #0x20]                      
02c92d2c: adrp    x22, #0x662f000                            
02c92d30: adrp    x21, #0x6265000                            
02c92d34: mov     x19, x1                                    
02c92d38: ldrb    w8, [x22, #0x9d9]                          
02c92d3c: ldr     x21, [x21, #0x210]                         T:AdFormat
02c92d40: mov     x20, x0                                    
02c92d44: tbnz    w8, #0, #0x2c92d5c                         
02c92d48: adrp    x0, #0x6265000                             
02c92d4c: ldr     x0, [x0, #0x210]                           T:AdFormat
02c92d50: bl      #0x2b70db0                                 fn_2b70db0
02c92d54: mov     w8, #1                                     
02c92d58: strb    w8, [x22, #0x9d9]                          
02c92d5c: ldr     x2, [x20, #0x40]                           ._interstitialAd
02c92d60: mov     w0, #7                                     
02c92d64: mov     x1, x19                                    
02c92d68: mov     w22, #7                                    
02c92d6c: bl      #0x2c8ffb4                                 AnalyticsManager::LogFirebaseAdmobRevenue
02c92d70: ldr     x2, [x20, #0x40]                           ._interstitialAd
02c92d74: ldr     x3, [x20, #0x20]                           
02c92d78: mov     w0, #7                                     
02c92d7c: mov     x1, x19                                    
02c92d80: bl      #0x2c904f0                                 AnalyticsManager::LogAppsflyerAdmobRevenue
02c92d84: ldr     x0, [x21]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c92d88: add     x1, sp, #0xc                               
02c92d8c: str     w22, [sp, #0xc]                            
02c92d90: bl      #0x2b70f38                                 fn_2b70f38
02c92d94: ldp     x20, x19, [sp, #0x20]                      
02c92d98: ldp     x22, x21, [sp, #0x10]                      
02c92d9c: ldr     x30, [sp], #0x30                           
02c92da0: ret                                                
## .ctor() -> void
---- InterAbmobControl::.ctor 0x2c92da4
02c92da4: b       #0x2c8f5f8                                 AdmobEventBase::.ctor
## <LoadAd>b__3_0(GoogleMobileAds.Api.InterstitialAd ad, GoogleMobileAds.Api.LoadAdError error) -> void
---- InterAbmobControl::<LoadAd>b__3_0 0x2c92da8
02c92da8: stp     x30, x23, [sp, #-0x30]!                    
02c92dac: stp     x22, x21, [sp, #0x10]                      
02c92db0: stp     x20, x19, [sp, #0x20]                      
02c92db4: adrp    x22, #0x662f000                            
02c92db8: mov     x21, x2                                    
02c92dbc: mov     x20, x1                                    
02c92dc0: ldrb    w8, [x22, #0x9da]                          
02c92dc4: mov     x19, x0                                    
02c92dc8: tbnz    w8, #0, #0x2c92e04                         
02c92dcc: adrp    x0, #0x6264000                             
02c92dd0: ldr     x0, [x0, #0xf90]                           T:System.Action
02c92dd4: bl      #0x2b70db0                                 fn_2b70db0
02c92dd8: adrp    x0, #0x6265000                             
02c92ddc: ldr     x0, [x0, #0x6e8]                           M:InterAbmobControl::LoadAd
02c92de0: bl      #0x2b70db0                                 fn_2b70db0
02c92de4: adrp    x0, #0x6265000                             
02c92de8: ldr     x0, [x0, #0x6f0]                           S:'Unexpected error: Interstitial load event fired with null ad and null '
02c92dec: bl      #0x2b70db0                                 fn_2b70db0
02c92df0: adrp    x0, #0x6265000                             
02c92df4: ldr     x0, [x0, #0x6f8]                           S:'Interstitial ad failed to load an ad with error : '
02c92df8: bl      #0x2b70db0                                 fn_2b70db0
02c92dfc: mov     w8, #1                                     
02c92e00: strb    w8, [x22, #0x9da]                          
02c92e04: cbz     x21, #0x2c92e80                            
02c92e08: adrp    x8, #0x6265000                             
02c92e0c: adrp    x22, #0x6264000                            
02c92e10: adrp    x23, #0x6265000                            
02c92e14: ldr     x8, [x8, #0x6f8]                           S:'Interstitial ad failed to load an ad with error : '
02c92e18: ldr     x22, [x22, #0xf90]                         T:System.Action
02c92e1c: ldr     x9, [x21]                                  
02c92e20: ldr     x23, [x23, #0x6e8]                         M:InterAbmobControl::LoadAd
02c92e24: mov     x0, x21                                    
02c92e28: ldr     x20, [x8]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c92e2c: ldp     x8, x1, [x9, #0x168]                       
02c92e30: blr     x8                                         
02c92e34: mov     x1, x0                                     
02c92e38: mov     x0, x20                                    
02c92e3c: mov     x2, xzr                                    
02c92e40: bl      #0x4c9c514                                 System.String::Concat
02c92e44: mov     x1, xzr                                    
02c92e48: bl      #0x2ca09f8                                 WLog::LogError
02c92e4c: ldr     x0, [x22]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c92e50: bl      #0x2b7104c                                 fn_2b7104c
02c92e54: ldr     x2, [x23]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c92e58: mov     x1, x19                                    
02c92e5c: mov     x3, xzr                                    
02c92e60: mov     x20, x0                                    
02c92e64: bl      #0x4d8ddbc                                 System.Action::.ctor
02c92e68: mov     x0, x19                                    
02c92e6c: mov     x1, x20                                    
02c92e70: ldp     x20, x19, [sp, #0x20]                      
02c92e74: ldp     x22, x21, [sp, #0x10]                      
02c92e78: ldp     x30, x23, [sp], #0x30                      
02c92e7c: b       #0x2c8f468                                 AdmobEventBase::TryLoadAd
02c92e80: cbz     x20, #0x2c92eac                            
02c92e84: mov     x0, x19                                    
02c92e88: mov     x1, x20                                    
02c92e8c: str     x20, [x0, #0x40]!                          ._interstitialAd
02c92e90: bl      #0x2b70d54                                 fn_2b70d54
02c92e94: mov     x0, x19                                    
02c92e98: mov     x1, x20                                    
02c92e9c: ldp     x20, x19, [sp, #0x20]                      
02c92ea0: ldp     x22, x21, [sp, #0x10]                      
02c92ea4: ldp     x30, x23, [sp], #0x30                      
02c92ea8: b       #0x2c92b20                                 InterAbmobControl::RegisterEventHandlers
02c92eac: adrp    x8, #0x6265000                             
02c92eb0: mov     x1, xzr                                    
02c92eb4: ldr     x8, [x8, #0x6f0]                           S:'Unexpected error: Interstitial load event fired with null ad and null '
02c92eb8: ldp     x20, x19, [sp, #0x20]                      
02c92ebc: ldp     x22, x21, [sp, #0x10]                      
02c92ec0: ldr     x0, [x8]                                   M:AdsManager::<OnApplicationPause>b__26_0
02c92ec4: ldp     x30, x23, [sp], #0x30                      
02c92ec8: b       #0x2ca09f8                                 WLog::LogError
