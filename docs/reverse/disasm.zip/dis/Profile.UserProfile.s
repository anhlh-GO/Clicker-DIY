#### CLASS Profile.UserProfile parent= object
#   field Name                           string                                             off=0x10 attr=6 
#   field Level                          int                                                off=0x18 attr=6 
#   field ExperiencePoint                float                                              off=0x1c attr=6 
#   field AvatarId                       int                                                off=0x20 attr=6 
#   field IsLevelUp                      bool                                               off=0x24 attr=6 
## .ctor(Profile.UserProfile userProfile) -> void
---- Profile.UserProfile::.ctor 0x2cf42d0
02cf42d0: str     x30, [sp, #-0x30]!                         
02cf42d4: stp     x22, x21, [sp, #0x10]                      
02cf42d8: stp     x20, x19, [sp, #0x20]                      
02cf42dc: adrp    x21, #0x662f000                            
02cf42e0: adrp    x22, #0x6268000                            
02cf42e4: mov     x19, x1                                    
02cf42e8: ldrb    w8, [x21, #0xe83]                          
02cf42ec: ldr     x22, [x22, #0x6e0]                         S:'You'
02cf42f0: mov     x20, x0                                    
02cf42f4: tbnz    w8, #0, #0x2cf430c                         
02cf42f8: adrp    x0, #0x6268000                             
02cf42fc: ldr     x0, [x0, #0x6e0]                           S:'You'
02cf4300: bl      #0x2b70db0                                 fn_2b70db0
02cf4304: mov     w8, #1                                     
02cf4308: strb    w8, [x21, #0xe83]                          
02cf430c: ldr     x1, [x22]                                  S:'{0}/2'
02cf4310: mov     x21, x20                                   
02cf4314: str     x1, [x21, #0x10]!                          .Name
02cf4318: mov     x0, x21                                    
02cf431c: bl      #0x2b70d54                                 fn_2b70d54
02cf4320: mov     x0, x20                                    
02cf4324: mov     x1, xzr                                    
02cf4328: bl      #0x4e53e9c                                 System.Object::.ctor
02cf432c: cbz     x19, #0x2cf4368                            
02cf4330: ldr     x1, [x19, #0x10]                           .Name
02cf4334: mov     x0, x21                                    
02cf4338: str     x1, [x20, #0x10]                           .Name
02cf433c: bl      #0x2b70d54                                 fn_2b70d54
02cf4340: ldr     w8, [x19, #0x18]                           .Level
02cf4344: ldr     s0, [x19, #0x1c]                           .ExperiencePoint
02cf4348: ldr     w9, [x19, #0x20]                           .AvatarId
02cf434c: ldp     x22, x21, [sp, #0x10]                      
02cf4350: str     w8, [x20, #0x18]                           .Level
02cf4354: str     s0, [x20, #0x1c]                           .ExperiencePoint
02cf4358: str     w9, [x20, #0x20]                           .AvatarId
02cf435c: ldp     x20, x19, [sp, #0x20]                      
02cf4360: ldr     x30, [sp], #0x30                           
02cf4364: ret                                                
02cf4368: bl      #0x2b7105c                                 fn_2b7105c
