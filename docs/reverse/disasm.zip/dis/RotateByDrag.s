#### CLASS RotateByDrag parent= UnityEngine.MonoBehaviour
#   field axis                           Axis                                               off=0x20 attr=6 
#   field rotationSpeed                  float                                              off=0x24 attr=6 
#   field rotationDamping                float                                              off=0x28 attr=6 
#   field _rotationVelocity              float                                              off=0x2c attr=1 
#   field _dragged                       bool                                               off=0x30 attr=1 
#   field rotationAxis                   UnityEngine.Vector3                                off=0x34 attr=1 
## GetAxisRotation() -> UnityEngine.Vector3
---- RotateByDrag::GetAxisRotation 0x2cf2a70
02cf2a70: stp     x30, x19, [sp, #-0x10]!                    
02cf2a74: ldr     w8, [x0, #0x20]                            .axis
02cf2a78: cmp     w8, #2                                     
02cf2a7c: b.eq    #0x2cf2b0c                                 
02cf2a80: cmp     w8, #1                                     
02cf2a84: b.eq    #0x2cf2acc                                 
02cf2a88: cbnz    w8, #0x2cf2acc                             
02cf2a8c: adrp    x19, #0x662f000                            
02cf2a90: ldrb    w8, [x19, #0xca5]                          
02cf2a94: cbnz    w8, #0x2cf2aac                             
02cf2a98: adrp    x0, #0x6264000                             
02cf2a9c: ldr     x0, [x0, #0xd8]                            T:UnityEngine.Vector3
02cf2aa0: bl      #0x2b70db0                                 fn_2b70db0
02cf2aa4: mov     w8, #1                                     
02cf2aa8: strb    w8, [x19, #0xca5]                          
02cf2aac: adrp    x8, #0x6264000                             
02cf2ab0: ldr     x8, [x8, #0xd8]                            T:UnityEngine.Vector3
02cf2ab4: ldr     x8, [x8]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02cf2ab8: ldr     x10, [x8, #0xb8]                           MS:DG.Tweening.Core.Extensions::SetSpecialStartupMode
02cf2abc: add     x8, x10, #0x3c                             
02cf2ac0: add     x9, x10, #0x40                             
02cf2ac4: add     x10, x10, #0x44                            
02cf2ac8: b       #0x2cf2b48                                 
02cf2acc: adrp    x19, #0x662f000                            
02cf2ad0: ldrb    w8, [x19, #0x918]                          
02cf2ad4: cbnz    w8, #0x2cf2aec                             
02cf2ad8: adrp    x0, #0x6264000                             
02cf2adc: ldr     x0, [x0, #0xd8]                            T:UnityEngine.Vector3
02cf2ae0: bl      #0x2b70db0                                 fn_2b70db0
02cf2ae4: mov     w8, #1                                     
02cf2ae8: strb    w8, [x19, #0x918]                          
02cf2aec: adrp    x8, #0x6264000                             
02cf2af0: ldr     x8, [x8, #0xd8]                            T:UnityEngine.Vector3
02cf2af4: ldr     x8, [x8]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02cf2af8: ldr     x10, [x8, #0xb8]                           MS:DG.Tweening.Core.Extensions::SetSpecialStartupMode
02cf2afc: add     x8, x10, #0x18                             
02cf2b00: add     x9, x10, #0x1c                             
02cf2b04: add     x10, x10, #0x20                            
02cf2b08: b       #0x2cf2b48                                 
02cf2b0c: adrp    x19, #0x662f000                            
02cf2b10: ldrb    w8, [x19, #0xca4]                          
02cf2b14: cbnz    w8, #0x2cf2b2c                             
02cf2b18: adrp    x0, #0x6264000                             
02cf2b1c: ldr     x0, [x0, #0xd8]                            T:UnityEngine.Vector3
02cf2b20: bl      #0x2b70db0                                 fn_2b70db0
02cf2b24: mov     w8, #1                                     
02cf2b28: strb    w8, [x19, #0xca4]                          
02cf2b2c: adrp    x8, #0x6264000                             
02cf2b30: ldr     x8, [x8, #0xd8]                            T:UnityEngine.Vector3
02cf2b34: ldr     x8, [x8]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02cf2b38: ldr     x10, [x8, #0xb8]                           MS:DG.Tweening.Core.Extensions::SetSpecialStartupMode
02cf2b3c: add     x8, x10, #0x54                             
02cf2b40: add     x9, x10, #0x58                             
02cf2b44: add     x10, x10, #0x5c                            
02cf2b48: ldr     s2, [x10]                                  
02cf2b4c: ldr     s1, [x9]                                   
02cf2b50: ldr     s0, [x8]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02cf2b54: ldp     x30, x19, [sp], #0x10                      
02cf2b58: ret                                                
## OnBeginDrag(UnityEngine.EventSystems.PointerEventData eventData) -> void
---- RotateByDrag::OnBeginDrag 0x2cf2b5c
02cf2b5c: stp     x30, x19, [sp, #-0x10]!                    
02cf2b60: mov     x19, x0                                    
02cf2b64: bl      #0x2cf2a70                                 RotateByDrag::GetAxisRotation
02cf2b68: mov     w8, #1                                     
02cf2b6c: stp     s0, s1, [x19, #0x34]                       .rotationAxis
02cf2b70: str     s2, [x19, #0x3c]                           
02cf2b74: strb    w8, [x19, #0x30]                           ._dragged
02cf2b78: ldp     x30, x19, [sp], #0x10                      
02cf2b7c: ret                                                
## OnDrag(UnityEngine.EventSystems.PointerEventData eventData) -> void
---- RotateByDrag::OnDrag 0x2cf2b80
02cf2b80: stp     x30, x19, [sp, #-0x10]!                    
02cf2b84: cbz     x1, #0x2cf2bc8                             
02cf2b88: ldr     s0, [x1, #0x14c]                           
02cf2b8c: ldr     s1, [x0, #0x24]                            .rotationSpeed
02cf2b90: mov     x1, xzr                                    
02cf2b94: mov     x19, x0                                    
02cf2b98: fmul    s0, s0, s1                                 
02cf2b9c: str     s0, [x0, #0x2c]                            ._rotationVelocity
02cf2ba0: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02cf2ba4: cbz     x0, #0x2cf2bc8                             
02cf2ba8: ldr     s0, [x19, #0x2c]                           ._rotationVelocity
02cf2bac: ldp     s1, s2, [x19, #0x38]                       
02cf2bb0: mov     w1, #1                                     
02cf2bb4: mov     x2, xzr                                    
02cf2bb8: fneg    s3, s0                                     
02cf2bbc: ldr     s0, [x19, #0x34]                           .rotationAxis
02cf2bc0: ldp     x30, x19, [sp], #0x10                      
02cf2bc4: b       #0x5b47c34                                 UnityEngine.Transform::Rotate
02cf2bc8: bl      #0x2b7105c                                 fn_2b7105c
## OnEndDrag(UnityEngine.EventSystems.PointerEventData eventData) -> void
---- RotateByDrag::OnEndDrag 0x2cf2bcc
02cf2bcc: strb    wzr, [x0, #0x30]                           ._dragged
02cf2bd0: ret                                                
## Update() -> void
---- RotateByDrag::Update 0x2cf2bd4
02cf2bd4: str     d8, [sp, #-0x20]!                          
02cf2bd8: str     x30, [sp, #8]                              
02cf2bdc: stp     x20, x19, [sp, #0x10]                      
02cf2be0: ldrb    w8, [x0, #0x30]                            ._dragged
02cf2be4: cbnz    w8, #0x2cf2ccc                             
02cf2be8: adrp    x20, #0x662f000                            
02cf2bec: ldr     s8, [x0, #0x2c]                            ._rotationVelocity
02cf2bf0: mov     x19, x0                                    
02cf2bf4: ldrb    w8, [x20, #0x91b]                          
02cf2bf8: cbnz    w8, #0x2cf2c10                             
02cf2bfc: adrp    x0, #0x6264000                             
02cf2c00: ldr     x0, [x0, #0xac8]                           T:UnityEngine.Mathf
02cf2c04: bl      #0x2b70db0                                 fn_2b70db0
02cf2c08: mov     w8, #1                                     
02cf2c0c: strb    w8, [x20, #0x91b]                          
02cf2c10: adrp    x8, #0x6264000                             
02cf2c14: fabs    s0, s8                                     
02cf2c18: movi    d1, #0000000000000000                      
02cf2c1c: ldr     x8, [x8, #0xac8]                           T:UnityEngine.Mathf
02cf2c20: adrp    x9, #0x1084000                             
02cf2c24: fmov    s2, #8.00000000                            
02cf2c28: ldr     s4, [x9, #0xf70]                           [1084f70]=bf745d17358637bd f=1e-06,-0.954545
02cf2c2c: ldr     x8, [x8]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02cf2c30: fmaxnm  s0, s0, s1                                 
02cf2c34: fabd    s1, s1, s8                                 
02cf2c38: ldr     x8, [x8, #0xb8]                            MS:DG.Tweening.Core.Extensions::SetSpecialStartupMode
02cf2c3c: ldr     s3, [x8]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02cf2c40: fmul    s0, s0, s4                                 
02cf2c44: fmul    s2, s3, s2                                 
02cf2c48: fcmp    s0, s2                                     
02cf2c4c: fcsel   s0, s0, s2, gt                             
02cf2c50: fcmp    s1, s0                                     
02cf2c54: b.mi    #0x2cf2ccc                                 
02cf2c58: ldr     s8, [x19, #0x2c]                           ._rotationVelocity
02cf2c5c: mov     x0, xzr                                    
02cf2c60: bl      #0x5b433a4                                 UnityEngine.Time::get_deltaTime
02cf2c64: fneg    s1, s0                                     
02cf2c68: fcmp    s8, #0.0                                   
02cf2c6c: mov     x0, x19                                    
02cf2c70: ldp     s3, s2, [x19, #0x28]                       .rotationDamping
02cf2c74: mov     x1, xzr                                    
02cf2c78: fcsel   s0, s1, s0, lt                             
02cf2c7c: fneg    s1, s2                                     
02cf2c80: fcmp    s2, #0.0                                   
02cf2c84: fmul    s0, s0, s3                                 
02cf2c88: fcsel   s1, s1, s2, lt                             
02cf2c8c: fcmp    s0, s1                                     
02cf2c90: fcsel   s0, s0, s1, mi                             
02cf2c94: fsub    s0, s2, s0                                 
02cf2c98: str     s0, [x19, #0x2c]                           ._rotationVelocity
02cf2c9c: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02cf2ca0: cbz     x0, #0x2cf2cdc                             
02cf2ca4: ldr     s0, [x19, #0x2c]                           ._rotationVelocity
02cf2ca8: ldp     s1, s2, [x19, #0x38]                       
02cf2cac: ldr     x30, [sp, #8]                              
02cf2cb0: mov     w1, #1                                     
02cf2cb4: mov     x2, xzr                                    
02cf2cb8: fneg    s3, s0                                     
02cf2cbc: ldr     s0, [x19, #0x34]                           .rotationAxis
02cf2cc0: ldp     x20, x19, [sp, #0x10]                      
02cf2cc4: ldr     d8, [sp], #0x20                            
02cf2cc8: b       #0x5b47c34                                 UnityEngine.Transform::Rotate
02cf2ccc: ldp     x20, x19, [sp, #0x10]                      
02cf2cd0: ldr     x30, [sp, #8]                              
02cf2cd4: ldr     d8, [sp], #0x20                            
02cf2cd8: ret                                                
02cf2cdc: bl      #0x2b7105c                                 fn_2b7105c
## .ctor() -> void
---- RotateByDrag::.ctor 0x2cf2ce0
02cf2ce0: mov     x1, xzr                                    
02cf2ce4: b       #0x5b397b0                                 UnityEngine.MonoBehaviour::.ctor
