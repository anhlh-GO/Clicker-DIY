#### CLASS ApplovinManager parent= UnityEngine.MonoBehaviour
#   field _interApplovinControl          InterApplovinControl                               off=0x20 attr=1 SerializeField
#   field _rewardApplovinControl         RewardApplovinControl                              off=0x28 attr=1 SerializeField
#   field _bannerApplovinControl         BannerApplovinControl                              off=0x30 attr=1 SerializeField
#   field _mrecApplovinControl           MrecApplovinControl                                off=0x38 attr=1 SerializeField
#   field _appOpenAdApplovinControl      AppOpenAdApplovinControl                           off=0x40 attr=1 SerializeField
## get_IsInterReady() -> bool
---- ApplovinManager::get_IsInterReady 0x2c8a144
02c8a144: ldr     x8, [x0, #0x20]                            ._interApplovinControl
02c8a148: cbz     x8, #0x2c8a150                             
02c8a14c: b       #0x2c8c8c8                                 InterApplovinControl::IsAdReady
02c8a150: str     x30, [sp, #-0x10]!                         
02c8a154: bl      #0x2b7105c                                 fn_2b7105c
## get_IsRewardReady() -> bool
---- ApplovinManager::get_IsRewardReady 0x2c8a4c0
02c8a4c0: ldr     x8, [x0, #0x28]                            ._rewardApplovinControl
02c8a4c4: cbz     x8, #0x2c8a4cc                             
02c8a4c8: b       #0x2c8c92c                                 RewardApplovinControl::IsAdReady
02c8a4cc: str     x30, [sp, #-0x10]!                         
02c8a4d0: bl      #0x2b7105c                                 fn_2b7105c
## RequestAd() -> void
---- ApplovinManager::RequestAd 0x2c88a28
02c88a28: b       #0x2c8c990                                 ApplovinManager::Initialized
## Initialized() -> void
---- ApplovinManager::Initialized 0x2c8c990
02c8c990: stp     x30, x23, [sp, #-0x30]!                    
02c8c994: stp     x22, x21, [sp, #0x10]                      
02c8c998: stp     x20, x19, [sp, #0x20]                      
02c8c99c: adrp    x20, #0x662f000                            
02c8c9a0: adrp    x21, #0x6265000                            
02c8c9a4: mov     x19, x0                                    
02c8c9a8: ldrb    w8, [x20, #0x987]                          
02c8c9ac: ldr     x21, [x21, #0x2f8]                         T:MaxSdkAndroid
02c8c9b0: tbnz    w8, #0, #0x2c8c9ec                         
02c8c9b4: adrp    x0, #0x6265000                             
02c8c9b8: ldr     x0, [x0, #0x300]                           T:type7083(k15)
02c8c9bc: bl      #0x2b70db0                                 fn_2b70db0
02c8c9c0: adrp    x0, #0x6265000                             
02c8c9c4: ldr     x0, [x0, #0x308]                           M:ApplovinManager::<Initialized>b__10_0
02c8c9c8: bl      #0x2b70db0                                 fn_2b70db0
02c8c9cc: adrp    x0, #0x6265000                             
02c8c9d0: ldr     x0, [x0, #0x2f8]                           T:MaxSdkAndroid
02c8c9d4: bl      #0x2b70db0                                 fn_2b70db0
02c8c9d8: adrp    x0, #0x6265000                             
02c8c9dc: ldr     x0, [x0, #0x310]                           MS:WejoyService.Singleton`1::get_Instance
02c8c9e0: bl      #0x2b70db0                                 fn_2b70db0
02c8c9e4: mov     w8, #1                                     
02c8c9e8: strb    w8, [x20, #0x987]                          
02c8c9ec: adrp    x23, #0x6265000                            
02c8c9f0: adrp    x20, #0x6265000                            
02c8c9f4: adrp    x22, #0x6265000                            
02c8c9f8: ldr     x23, [x23, #0x300]                         T:type7083(k15)
02c8c9fc: ldr     x20, [x20, #0x308]                         M:ApplovinManager::<Initialized>b__10_0
02c8ca00: ldr     x22, [x22, #0x310]                         MS:WejoyService.Singleton`1::get_Instance
02c8ca04: mov     x0, xzr                                    
02c8ca08: bl      #0x2ccc9d4                                 AudienceNetwork.AudienceNetworkAds::Initialize
02c8ca0c: ldr     x0, [x21]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c8ca10: ldr     w8, [x0, #0xe4]                            [62650e4]=0 f=0,0
02c8ca14: cbnz    w8, #0x2c8ca1c                             
02c8ca18: bl      #0x2b70f30                                 fn_2b70f30
02c8ca1c: mov     w0, wzr                                    
02c8ca20: mov     x1, xzr                                    
02c8ca24: bl      #0x4c5025c                                 MaxSdkAndroid::SetDoNotSell
02c8ca28: mov     w0, #1                                     
02c8ca2c: mov     x1, xzr                                    
02c8ca30: bl      #0x4c4ff40                                 MaxSdkAndroid::SetHasUserConsent
02c8ca34: ldr     x0, [x23]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c8ca38: bl      #0x2b7104c                                 fn_2b7104c
02c8ca3c: ldr     x2, [x20]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c8ca40: mov     x1, x19                                    
02c8ca44: mov     x3, xzr                                    
02c8ca48: mov     x20, x0                                    
02c8ca4c: bl      #0x453418c                                 fn_453418c
02c8ca50: mov     x0, x20                                    
02c8ca54: mov     x1, xzr                                    
02c8ca58: bl      #0x4c5a9b4                                 MaxSdkCallbacks::add_OnSdkInitializedEvent
02c8ca5c: mov     x0, xzr                                    
02c8ca60: mov     x1, xzr                                    
02c8ca64: bl      #0x4c4f168                                 MaxSdkAndroid::InitializeSdk
02c8ca68: ldr     x0, [x22]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c8ca6c: bl      #0x3be7218                                 fn_3be7218
02c8ca70: cbz     x0, #0x2c8cab0                             
02c8ca74: ldrb    w8, [x0, #0x31]                            
02c8ca78: cbz     w8, #0x2c8caa0                             
02c8ca7c: ldr     x0, [x21]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c8ca80: ldr     w8, [x0, #0xe4]                            [62650e4]=0 f=0,0
02c8ca84: cbnz    w8, #0x2c8ca8c                             
02c8ca88: bl      #0x2b70f30                                 fn_2b70f30
02c8ca8c: ldp     x20, x19, [sp, #0x20]                      
02c8ca90: mov     x0, xzr                                    
02c8ca94: ldp     x22, x21, [sp, #0x10]                      
02c8ca98: ldp     x30, x23, [sp], #0x30                      
02c8ca9c: b       #0x4c4f808                                 MaxSdkAndroid::ShowMediationDebugger
02c8caa0: ldp     x20, x19, [sp, #0x20]                      
02c8caa4: ldp     x22, x21, [sp, #0x10]                      
02c8caa8: ldp     x30, x23, [sp], #0x30                      
02c8caac: ret                                                
02c8cab0: bl      #0x2b7105c                                 fn_2b7105c
## ShowAppOpenAd(System.Action action) -> void
---- ApplovinManager::ShowAppOpenAd 0x2c8cab4
02c8cab4: ldr     x0, [x0, #0x40]                            ._appOpenAdApplovinControl
02c8cab8: cbz     x0, #0x2c8cac0                             
02c8cabc: b       #0x2c8cac8                                 AppOpenAdApplovinControl::ShowAd
02c8cac0: str     x30, [sp, #-0x10]!                         
02c8cac4: bl      #0x2b7105c                                 fn_2b7105c
## ShowInterAds(string placment, System.Action action) -> void
---- ApplovinManager::ShowInterAds 0x2c8a158
02c8a158: ldr     x0, [x0, #0x20]                            ._interApplovinControl
02c8a15c: cbz     x0, #0x2c8a164                             
02c8a160: b       #0x2c8cba4                                 InterApplovinControl::ShowAd
02c8a164: str     x30, [sp, #-0x10]!                         
02c8a168: bl      #0x2b7105c                                 fn_2b7105c
## ShowRewardAds(string placment, System.Action action) -> void
---- ApplovinManager::ShowRewardAds 0x2c8a4d4
02c8a4d4: ldr     x0, [x0, #0x28]                            ._rewardApplovinControl
02c8a4d8: cbz     x0, #0x2c8a4e0                             
02c8a4dc: b       #0x2c8cc84                                 RewardApplovinControl::ShowAd
02c8a4e0: str     x30, [sp, #-0x10]!                         
02c8a4e4: bl      #0x2b7105c                                 fn_2b7105c
## ShowBannerAds() -> void
---- ApplovinManager::ShowBannerAds 0x2c8cd80
02c8cd80: ldr     x8, [x0, #0x30]                            ._bannerApplovinControl
02c8cd84: cbz     x8, #0x2c8cd8c                             
02c8cd88: b       #0x2c8cd94                                 BannerApplovinControl::ShowAd
02c8cd8c: str     x30, [sp, #-0x10]!                         
02c8cd90: bl      #0x2b7105c                                 fn_2b7105c
## HideBannerAds() -> void
---- ApplovinManager::HideBannerAds 0x2c8ce18
02c8ce18: ldr     x8, [x0, #0x30]                            ._bannerApplovinControl
02c8ce1c: cbz     x8, #0x2c8ce24                             
02c8ce20: b       #0x2c8ce2c                                 BannerApplovinControl::HideAd
02c8ce24: str     x30, [sp, #-0x10]!                         
02c8ce28: bl      #0x2b7105c                                 fn_2b7105c
## ShowMREC(AdsPosition adsPosition) -> void
---- ApplovinManager::ShowMREC 0x2c8a77c
02c8a77c: ldr     x0, [x0, #0x38]                            ._mrecApplovinControl
02c8a780: cbz     x0, #0x2c8a788                             
02c8a784: b       #0x2c8ceb0                                 MrecApplovinControl::ShowAd
02c8a788: str     x30, [sp, #-0x10]!                         
02c8a78c: bl      #0x2b7105c                                 fn_2b7105c
## HideMREC() -> void
---- ApplovinManager::HideMREC 0x2c8a790
02c8a790: ldr     x8, [x0, #0x38]                            ._mrecApplovinControl
02c8a794: cbz     x8, #0x2c8a79c                             
02c8a798: b       #0x2c8cfb4                                 MrecApplovinControl::HideAd
02c8a79c: str     x30, [sp, #-0x10]!                         
02c8a7a0: bl      #0x2b7105c                                 fn_2b7105c
## .ctor() -> void
---- ApplovinManager::.ctor 0x2c8d038
02c8d038: mov     x1, xzr                                    
02c8d03c: b       #0x5b397b0                                 UnityEngine.MonoBehaviour::.ctor
## <Initialized>b__10_0(MaxSdkBase/SdkConfiguration sdkConfiguration) -> void
---- ApplovinManager::<Initialized>b__10_0 0x2c8d040
02c8d040: stp     x30, x21, [sp, #-0x20]!                    
02c8d044: stp     x20, x19, [sp, #0x10]                      
02c8d048: adrp    x20, #0x662f000                            
02c8d04c: adrp    x21, #0x6265000                            
02c8d050: mov     x19, x0                                    
02c8d054: ldrb    w8, [x20, #0x988]                          
02c8d058: ldr     x21, [x21, #0x348]                         S:'MAX SDK Initialized'
02c8d05c: tbnz    w8, #0, #0x2c8d074                         
02c8d060: adrp    x0, #0x6265000                             
02c8d064: ldr     x0, [x0, #0x348]                           S:'MAX SDK Initialized'
02c8d068: bl      #0x2b70db0                                 fn_2b70db0
02c8d06c: mov     w8, #1                                     
02c8d070: strb    w8, [x20, #0x988]                          
02c8d074: ldr     x0, [x21]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c8d078: mov     x1, xzr                                    
02c8d07c: bl      #0x2ca46ac                                 WLog::Log
02c8d080: ldr     x0, [x19, #0x20]                           ._interApplovinControl
02c8d084: cbz     x0, #0x2c8d0ac                             
02c8d088: bl      #0x2c8d0b0                                 InterApplovinControl::InitAd
02c8d08c: ldr     x0, [x19, #0x28]                           ._rewardApplovinControl
02c8d090: cbz     x0, #0x2c8d0ac                             
02c8d094: bl      #0x2c8d25c                                 RewardApplovinControl::InitAd
02c8d098: ldr     x0, [x19, #0x38]                           ._mrecApplovinControl
02c8d09c: cbz     x0, #0x2c8d0ac                             
02c8d0a0: ldp     x20, x19, [sp, #0x10]                      
02c8d0a4: ldp     x30, x21, [sp], #0x20                      
02c8d0a8: b       #0x2c8d460                                 MrecApplovinControl::InitAd
02c8d0ac: bl      #0x2b7105c                                 fn_2b7105c
