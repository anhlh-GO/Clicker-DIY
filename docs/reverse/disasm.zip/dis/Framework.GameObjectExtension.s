#### CLASS Framework.GameObjectExtension parent= object
## SetLayerRecursively(UnityEngine.GameObject obj, int newLayer) -> void
---- Framework.GameObjectExtension::SetLayerRecursively 0x2cb89c4
02cb89c4: stp     x30, x21, [sp, #-0x20]!                    
02cb89c8: stp     x20, x19, [sp, #0x10]                      
02cb89cc: cbz     x0, #0x2cb8a48                             
02cb89d0: mov     x2, xzr                                    
02cb89d4: mov     x19, x0                                    
02cb89d8: mov     w20, w1                                    
02cb89dc: bl      #0x5b36a74                                 UnityEngine.GameObject::set_layer
02cb89e0: mov     x0, x19                                    
02cb89e4: mov     x1, xzr                                    
02cb89e8: bl      #0x5b368f0                                 UnityEngine.GameObject::get_transform
02cb89ec: cbz     x0, #0x2cb8a48                             
02cb89f0: mov     w21, wzr                                   
02cb89f4: mov     x1, xzr                                    
02cb89f8: bl      #0x5b482c4                                 UnityEngine.Transform::get_childCount
02cb89fc: cmp     w21, w0                                    
02cb8a00: b.ge    #0x2cb8a4c                                 
02cb8a04: mov     x0, x19                                    
02cb8a08: mov     x1, xzr                                    
02cb8a0c: bl      #0x5b368f0                                 UnityEngine.GameObject::get_transform
02cb8a10: cbz     x0, #0x2cb8a48                             
02cb8a14: mov     w1, w21                                    
02cb8a18: mov     x2, xzr                                    
02cb8a1c: bl      #0x5b48d44                                 UnityEngine.Transform::GetChild
02cb8a20: cbz     x0, #0x2cb8a48                             
02cb8a24: mov     x1, xzr                                    
02cb8a28: bl      #0x5b339ec                                 UnityEngine.Component::get_gameObject
02cb8a2c: mov     w1, w20                                    
02cb8a30: bl      #0x2cb89c4                                 Framework.GameObjectExtension::SetLayerRecursively
02cb8a34: mov     x0, x19                                    
02cb8a38: mov     x1, xzr                                    
02cb8a3c: add     w21, w21, #1                               
02cb8a40: bl      #0x5b368f0                                 UnityEngine.GameObject::get_transform
02cb8a44: cbnz    x0, #0x2cb89f4                             
02cb8a48: bl      #0x2b7105c                                 fn_2b7105c
02cb8a4c: ldp     x20, x19, [sp, #0x10]                      
02cb8a50: ldp     x30, x21, [sp], #0x20                      
02cb8a54: ret                                                
## SetActiveChilds(UnityEngine.GameObject obj, bool value) -> void
---- Framework.GameObjectExtension::SetActiveChilds 0x2cb8a58
02cb8a58: str     x30, [sp, #-0x30]!                         
02cb8a5c: stp     x22, x21, [sp, #0x10]                      
02cb8a60: stp     x20, x19, [sp, #0x20]                      
02cb8a64: cbz     x0, #0x2cb8ae8                             
02cb8a68: mov     w20, w1                                    
02cb8a6c: mov     x1, xzr                                    
02cb8a70: mov     x19, x0                                    
02cb8a74: bl      #0x5b368f0                                 UnityEngine.GameObject::get_transform
02cb8a78: cbz     x0, #0x2cb8ae8                             
02cb8a7c: mov     x1, xzr                                    
02cb8a80: bl      #0x5b482c4                                 UnityEngine.Transform::get_childCount
02cb8a84: cmp     w0, #1                                     
02cb8a88: b.lt    #0x2cb8ad8                                 
02cb8a8c: mov     w21, w0                                    
02cb8a90: mov     w22, wzr                                   
02cb8a94: mov     x0, x19                                    
02cb8a98: mov     x1, xzr                                    
02cb8a9c: bl      #0x5b368f0                                 UnityEngine.GameObject::get_transform
02cb8aa0: cbz     x0, #0x2cb8ae8                             
02cb8aa4: mov     w1, w22                                    
02cb8aa8: mov     x2, xzr                                    
02cb8aac: bl      #0x5b48d44                                 UnityEngine.Transform::GetChild
02cb8ab0: cbz     x0, #0x2cb8ae8                             
02cb8ab4: mov     x1, xzr                                    
02cb8ab8: bl      #0x5b339ec                                 UnityEngine.Component::get_gameObject
02cb8abc: cbz     x0, #0x2cb8ae8                             
02cb8ac0: and     w1, w20, #1                                
02cb8ac4: mov     x2, xzr                                    
02cb8ac8: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02cb8acc: add     w22, w22, #1                               
02cb8ad0: cmp     w21, w22                                   
02cb8ad4: b.ne    #0x2cb8a94                                 
02cb8ad8: ldp     x20, x19, [sp, #0x20]                      
02cb8adc: ldp     x22, x21, [sp, #0x10]                      
02cb8ae0: ldr     x30, [sp], #0x30                           
02cb8ae4: ret                                                
02cb8ae8: bl      #0x2b7105c                                 fn_2b7105c
## IsPrefab(UnityEngine.GameObject obj) -> bool
---- Framework.GameObjectExtension::IsPrefab 0x2cb8aec
02cb8aec: str     x30, [sp, #-0x10]!                         
02cb8af0: str     wzr, [sp, #0xc]                            
02cb8af4: cbz     x0, #0x2cb8b20                             
02cb8af8: mov     x1, xzr                                    
02cb8afc: bl      #0x5b374d4                                 UnityEngine.GameObject::get_scene
02cb8b00: str     w0, [sp, #0xc]                             
02cb8b04: add     x0, sp, #0xc                               
02cb8b08: mov     x1, xzr                                    
02cb8b0c: bl      #0x5b4de9c                                 UnityEngine.SceneManagement.Scene::get_rootCount
02cb8b10: cmp     w0, #0                                     
02cb8b14: cset    w0, eq                                     
02cb8b18: ldr     x30, [sp], #0x10                           
02cb8b1c: ret                                                
02cb8b20: bl      #0x2b7105c                                 fn_2b7105c
##  SetActive (no body)
##  SetScale (no body)
##  OrNull (no body)
