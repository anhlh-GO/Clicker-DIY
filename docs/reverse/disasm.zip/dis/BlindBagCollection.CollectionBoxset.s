#### CLASS BlindBagCollection.CollectionBoxset parent= System.ValueType
#   field BoxsetType                     BlindBagCollection.CollectionBoxsetType            off=0x10 attr=6 
#   field FullKeycap                     BlindBagCollection.CollectionItem                  off=0x18 attr=6 
#   field DecorItems                     System.Collections.Generic.List`1<BlindBagCollection.CollectionItem> off=0x30 attr=6 
