#### CLASS Clicker.DraggableClickerItem parent= UnityEngine.MonoBehaviour
#   field _collider                      UnityEngine.Collider2D                             off=0x20 attr=4 SerializeField
#   field _transform                     UnityEngine.Transform                              off=0x28 attr=4 SerializeField
#   field _sortOrder                     int                                                off=0x30 attr=4 SerializeField
#   field _allowDrag                     bool                                               off=0x34 attr=4 SerializeField
#   field _dragType                      Clicker.DragType                                   off=0x38 attr=4 SerializeField
#   field _srVisual                      System.Collections.Generic.List`1<UnityEngine.SpriteRenderer> off=0x40 attr=4 SerializeField
#   field _isDone                        bool                                               off=0x48 attr=4 
#   field _cachedLocalPosition           UnityEngine.Vector3                                off=0x4c attr=4 
#   field _droppedSlot                   int                                                off=0x58 attr=4 
## get_Collider() -> UnityEngine.Collider2D
---- Clicker.DraggableClickerItem::get_Collider 0x2d61748
02d61748: ldr     x0, [x0, #0x20]                            ._collider
02d6174c: ret                                                
## get_Transform() -> UnityEngine.Transform
---- Clicker.DraggableClickerItem::get_Transform 0x2d61750
02d61750: ldr     x0, [x0, #0x28]                            ._transform
02d61754: ret                                                
## get_SortOrder() -> int
---- Clicker.DraggableClickerItem::get_SortOrder 0x2d61758
02d61758: ldr     w0, [x0, #0x30]                            ._sortOrder
02d6175c: ret                                                
## get_AllowDrag() -> bool
---- Clicker.DraggableClickerItem::get_AllowDrag 0x2d61760
02d61760: ldrb    w0, [x0, #0x34]                            ._allowDrag
02d61764: ret                                                
## get_DragType() -> Clicker.DragType
---- Clicker.DraggableClickerItem::get_DragType 0x2d61768
02d61768: ldr     w0, [x0, #0x38]                            ._dragType
02d6176c: ret                                                
## get_IsDone() -> bool
---- Clicker.DraggableClickerItem::get_IsDone 0x2d61770
02d61770: ldrb    w0, [x0, #0x48]                            ._isDone
02d61774: ret                                                
## get_CachedLocalPosition() -> UnityEngine.Vector3
---- Clicker.DraggableClickerItem::get_CachedLocalPosition 0x2d61778
02d61778: ldp     s0, s1, [x0, #0x4c]                        ._cachedLocalPosition
02d6177c: ldr     s2, [x0, #0x54]                            
02d61780: ret                                                
## Awake() -> void
---- Clicker.DraggableClickerItem::Awake 0x2d61784
02d61784: ret                                                
## SetFallBackPosition() -> void
---- Clicker.DraggableClickerItem::SetFallBackPosition 0x2d61788
02d61788: stp     x30, x19, [sp, #-0x10]!                    
02d6178c: mov     x19, x0                                    
02d61790: ldr     x0, [x0, #0x28]                            ._transform
02d61794: cbz     x0, #0x2d617b0                             
02d61798: mov     x1, xzr                                    
02d6179c: bl      #0x5b45c24                                 UnityEngine.Transform::get_localPosition
02d617a0: stp     s0, s1, [x19, #0x4c]                       ._cachedLocalPosition
02d617a4: str     s2, [x19, #0x54]                           
02d617a8: ldp     x30, x19, [sp], #0x10                      
02d617ac: ret                                                
02d617b0: bl      #0x2b7105c                                 fn_2b7105c
## SetDone() -> void
---- Clicker.DraggableClickerItem::SetDone 0x2d617b4
02d617b4: mov     w8, #1                                     
02d617b8: strb    w8, [x0, #0x48]                            ._isDone
02d617bc: ret                                                
## OnDropped(int index) -> void
---- Clicker.DraggableClickerItem::OnDropped 0x2d617c0
02d617c0: str     x30, [sp, #-0x30]!                         
02d617c4: stp     x22, x21, [sp, #0x10]                      
02d617c8: stp     x20, x19, [sp, #0x20]                      
02d617cc: mov     w20, w1                                    
02d617d0: mov     x1, xzr                                    
02d617d4: mov     x19, x0                                    
02d617d8: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02d617dc: adrp    x22, #0x662f000                            
02d617e0: mov     x21, x0                                    
02d617e4: ldrb    w8, [x22, #0xa74]                          
02d617e8: cbnz    w8, #0x2d61800                             
02d617ec: adrp    x0, #0x6264000                             
02d617f0: ldr     x0, [x0, #0xd8]                            T:UnityEngine.Vector3
02d617f4: bl      #0x2b70db0                                 fn_2b70db0
02d617f8: mov     w8, #1                                     
02d617fc: strb    w8, [x22, #0xa74]                          
02d61800: cbz     x21, #0x2d61884                            
02d61804: adrp    x8, #0x6264000                             
02d61808: mov     x0, x21                                    
02d6180c: mov     x1, xzr                                    
02d61810: ldr     x8, [x8, #0xd8]                            T:UnityEngine.Vector3
02d61814: ldr     x8, [x8]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d61818: ldr     x8, [x8, #0xb8]                            MS:DG.Tweening.Core.Extensions::SetSpecialStartupMode
02d6181c: ldp     s1, s2, [x8, #0x10]                        
02d61820: ldr     s0, [x8, #0xc]                             [626400c]=0 f=0,0
02d61824: bl      #0x5b470cc                                 UnityEngine.Transform::set_localScale
02d61828: ldrb    w8, [x19, #0x48]                           ._isDone
02d6182c: cbz     w8, #0x2d61860                             
02d61830: mov     x0, x19                                    
02d61834: mov     x1, xzr                                    
02d61838: str     w20, [x19, #0x58]                          ._droppedSlot
02d6183c: strb    wzr, [x19, #0x34]                          ._allowDrag
02d61840: bl      #0x5b339ec                                 UnityEngine.Component::get_gameObject
02d61844: cbz     x0, #0x2d61884                             
02d61848: ldp     x20, x19, [sp, #0x20]                      
02d6184c: mov     w1, wzr                                    
02d61850: ldp     x22, x21, [sp, #0x10]                      
02d61854: mov     x2, xzr                                    
02d61858: ldr     x30, [sp], #0x30                           
02d6185c: b       #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d61860: ldr     x0, [x19, #0x28]                           ._transform
02d61864: cbz     x0, #0x2d61884                             
02d61868: ldp     s0, s1, [x19, #0x4c]                       ._cachedLocalPosition
02d6186c: mov     x1, xzr                                    
02d61870: ldr     s2, [x19, #0x54]                           
02d61874: ldp     x20, x19, [sp, #0x20]                      
02d61878: ldp     x22, x21, [sp, #0x10]                      
02d6187c: ldr     x30, [sp], #0x30                           
02d61880: b       #0x5b45cec                                 UnityEngine.Transform::set_localPosition
02d61884: bl      #0x2b7105c                                 fn_2b7105c
## OnPickUp() -> void
---- Clicker.DraggableClickerItem::OnPickUp 0x2d61888
02d61888: str     x30, [sp, #-0x20]!                         
02d6188c: stp     x20, x19, [sp, #0x10]                      
02d61890: ldr     x8, [x0]                                   
02d61894: mov     x19, x0                                    
02d61898: ldr     x9, [x8, #0x228]                           
02d6189c: ldr     x1, [x8, #0x230]                           
02d618a0: blr     x9                                         
02d618a4: mov     x0, x19                                    
02d618a8: mov     x1, xzr                                    
02d618ac: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02d618b0: adrp    x20, #0x662f000                            
02d618b4: mov     x19, x0                                    
02d618b8: ldrb    w8, [x20, #0xa74]                          
02d618bc: cbnz    w8, #0x2d618d4                             
02d618c0: adrp    x0, #0x6264000                             
02d618c4: ldr     x0, [x0, #0xd8]                            T:UnityEngine.Vector3
02d618c8: bl      #0x2b70db0                                 fn_2b70db0
02d618cc: mov     w8, #1                                     
02d618d0: strb    w8, [x20, #0xa74]                          
02d618d4: cbz     x19, #0x2d61924                            
02d618d8: adrp    x8, #0x6264000                             
02d618dc: mov     w9, #0x6666                                
02d618e0: mov     x0, x19                                    
02d618e4: ldr     x8, [x8, #0xd8]                            T:UnityEngine.Vector3
02d618e8: movk    w9, #0x3f66, lsl #16                       
02d618ec: mov     x1, xzr                                    
02d618f0: dup     v0.2s, w9                                  
02d618f4: adrp    x9, #0x1084000                             
02d618f8: ldr     x8, [x8]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d618fc: ldr     s2, [x9, #0xbd4]                           [1084bd4]=440980003f666666 f=0.9,550
02d61900: ldp     x20, x19, [sp, #0x10]                      
02d61904: ldr     x8, [x8, #0xb8]                            MS:DG.Tweening.Core.Extensions::SetSpecialStartupMode
02d61908: ldur    d1, [x8, #0xc]                             
02d6190c: fmul    v0.2s, v1.2s, v0.2s                        
02d61910: ldr     s1, [x8, #0x14]                            [6264014]=0 f=0,0
02d61914: fmul    s2, s1, s2                                 
02d61918: mov     s1, v0.s[1]                                
02d6191c: ldr     x30, [sp], #0x20                           
02d61920: b       #0x5b470cc                                 UnityEngine.Transform::set_localScale
02d61924: bl      #0x2b7105c                                 fn_2b7105c
## PlaySoundPickUp() -> void
---- Clicker.DraggableClickerItem::PlaySoundPickUp 0x2d61928
02d61928: str     x30, [sp, #-0x10]!                         
02d6192c: mov     x0, xzr                                    
02d61930: bl      #0x2d6eec8                                 Framework.AudioManager::get_Instance
02d61934: cbz     x0, #0x2d6195c                             
02d61938: movi    d1, #0000000000000000                      
02d6193c: movi    d2, #0000000000000000                      
02d61940: mov     w1, #0x33                                  
02d61944: fmov    s0, #1.00000000                            
02d61948: mov     w2, wzr                                    
02d6194c: mov     w3, wzr                                    
02d61950: mov     x4, xzr                                    
02d61954: ldr     x30, [sp], #0x10                           
02d61958: b       #0x2d6f03c                                 Framework.AudioManager::PlaySound
02d6195c: bl      #0x2b7105c                                 fn_2b7105c
## SetDraggable(bool allowDrag) -> void
---- Clicker.DraggableClickerItem::SetDraggable 0x2d61960
02d61960: strb    w1, [x0, #0x34]                            ._allowDrag
02d61964: ret                                                
## ActiveDragAgain() -> void
---- Clicker.DraggableClickerItem::ActiveDragAgain 0x2d61968
02d61968: strb    wzr, [x0, #0x48]                           ._isDone
02d6196c: ret                                                
## .ctor() -> void
---- Clicker.DraggableClickerItem::.ctor 0x2d61970
02d61970: mov     w8, #-1                                    
02d61974: mov     x1, xzr                                    
02d61978: str     w8, [x0, #0x58]                            ._droppedSlot
02d6197c: b       #0x5b397b0                                 UnityEngine.MonoBehaviour::.ctor
