#### CLASS Home.PetHomeDataItem parent= object
#   field Id                             int                                                off=0x10 attr=6 
#   field Name                           string                                             off=0x18 attr=6 
#   field SkeletonData                   Spine.Unity.SkeletonDataAsset                      off=0x20 attr=6 
#   field SkinName                       string                                             off=0x28 attr=6 
#   field IdleAnimation                  string                                             off=0x30 attr=6 
#   field TouchAnimation                 string                                             off=0x38 attr=6 
## .ctor() -> void
---- Home.PetHomeDataItem::.ctor 0x2d1ded4
02d1ded4: mov     x1, xzr                                    
02d1ded8: b       #0x4e53e9c                                 System.Object::.ctor
