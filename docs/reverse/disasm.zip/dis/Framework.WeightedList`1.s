#### CLASS Framework.WeightedList`1 parent= object
#   field <BadWeightErrorHandling>k__BackingField Framework.WeightErrorHandlingType                  off=0x0 attr=1 CompilerGeneratedAttribute
#   field _list                          System.Collections.Generic.List`1<T>               off=0x0 attr=21 
#   field _weights                       System.Collections.Generic.List`1<int>             off=0x0 attr=21 
#   field _probabilities                 System.Collections.Generic.List`1<int>             off=0x0 attr=21 
#   field _alias                         System.Collections.Generic.List`1<int>             off=0x0 attr=21 
#   field _rand                          System.Random                                      off=0x0 attr=21 
#   field _totalWeight                   int                                                off=0x0 attr=1 
#   field _areAllProbabilitiesIdentical  bool                                               off=0x0 attr=1 
#   field _minWeight                     int                                                off=0x0 attr=1 
#   field _maxWeight                     int                                                off=0x0 attr=1 
##  .ctor (no body)
##  .ctor (no body)
##  get_BadWeightErrorHandling (no body)
##  set_BadWeightErrorHandling (no body)
##  Next (no body)
##  AddWeightToAll (no body)
##  SubtractWeightFromAll (no body)
##  SetWeightOfAll (no body)
##  get_TotalWeight (no body)
##  get_MinWeight (no body)
##  get_MaxWeight (no body)
##  get_Items (no body)
##  GetEnumerator (no body)
##  System.Collections.IEnumerable.GetEnumerator (no body)
##  Add (no body)
##  Add (no body)
##  Clear (no body)
##  Contains (no body)
##  IndexOf (no body)
##  Insert (no body)
##  Remove (no body)
##  RemoveAt (no body)
##  get_Item (no body)
##  get_Count (no body)
##  SetWeight (no body)
##  GetWeightOf (no body)
##  SetWeightAtIndex (no body)
##  GetWeightAtIndex (no body)
##  ToString (no body)
##  Recalculate (no body)
##  FixWeightSetToOne (no body)
##  FixWeightExceptionOnAdd (no body)
##  FixWeight (no body)
