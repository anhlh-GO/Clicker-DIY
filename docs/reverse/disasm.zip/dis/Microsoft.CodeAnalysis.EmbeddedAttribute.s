#### CLASS Microsoft.CodeAnalysis.EmbeddedAttribute parent= System.Attribute
## .ctor() -> void
---- Microsoft.CodeAnalysis.EmbeddedAttribute::.ctor 0x2c84054
02c84054: mov     x1, xzr                                    
02c84058: b       #0x4e3a344                                 System.Attribute::.ctor
