#### CLASS DailyReward.DailyLoginController parent= UnityEngine.MonoBehaviour
#   field LastLoginKey                   string                                             off=0x0 attr=8051 
#   field DayIndexKey                    string                                             off=0x0 attr=8051 
#   field _maxDay                        int                                                off=0x20 attr=1 
## SetLimitDay(int value) -> void
---- DailyReward.DailyLoginController::SetLimitDay 0x2cf3ae8
02cf3ae8: str     w1, [x0, #0x20]                            ._maxDay
02cf3aec: ret                                                
## IsEnable() -> bool
---- DailyReward.DailyLoginController::IsEnable 0x2cf3af0
02cf3af0: str     x30, [sp, #-0x20]!                         
02cf3af4: stp     x20, x19, [sp, #0x10]                      
02cf3af8: adrp    x20, #0x662f000                            
02cf3afc: mov     x19, x0                                    
02cf3b00: ldrb    w8, [x20, #0xe78]                          
02cf3b04: tbnz    w8, #0, #0x2cf3b1c                         
02cf3b08: adrp    x0, #0x6266000                             
02cf3b0c: ldr     x0, [x0, #0x128]                           T:System.DateTime
02cf3b10: bl      #0x2b70db0                                 fn_2b70db0
02cf3b14: mov     w8, #1                                     
02cf3b18: strb    w8, [x20, #0xe78]                          
02cf3b1c: str     xzr, [sp, #8]                              
02cf3b20: bl      #0x2cf3b90                                 DailyReward.DailyLoginController::GetLoginDayIndex
02cf3b24: ldr     w8, [x19, #0x20]                           ._maxDay
02cf3b28: cmp     w0, w8                                     
02cf3b2c: b.ge    #0x2cf3b7c                                 
02cf3b30: adrp    x19, #0x6266000                            
02cf3b34: ldr     x19, [x19, #0x128]                         T:System.DateTime
02cf3b38: bl      #0x2cf3bd8                                 DailyReward.DailyLoginController::GetLastLoginDate
02cf3b3c: ldr     x8, [x19]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cf3b40: str     x0, [sp, #8]                               
02cf3b44: ldr     w9, [x8, #0xe4]                            
02cf3b48: cbnz    w9, #0x2cf3b54                             
02cf3b4c: mov     x0, x8                                     
02cf3b50: bl      #0x2b70f30                                 fn_2b70f30
02cf3b54: mov     x0, xzr                                    
02cf3b58: bl      #0x4df285c                                 System.DateTime::get_Today
02cf3b5c: mov     x19, x0                                    
02cf3b60: add     x0, sp, #8                                 
02cf3b64: mov     x1, xzr                                    
02cf3b68: bl      #0x4df1f38                                 System.DateTime::get_Date
02cf3b6c: mov     x1, x19                                    
02cf3b70: mov     x2, xzr                                    
02cf3b74: bl      #0x4df40ec                                 System.DateTime::op_LessThan
02cf3b78: b       #0x2cf3b80                                 
02cf3b7c: mov     w0, wzr                                    
02cf3b80: ldp     x20, x19, [sp, #0x10]                      
02cf3b84: and     w0, w0, #1                                 
02cf3b88: ldr     x30, [sp], #0x20                           
02cf3b8c: ret                                                
## GetLastLoginDate() -> System.DateTime
---- DailyReward.DailyLoginController::GetLastLoginDate 0x2cf3bd8
02cf3bd8: sub     sp, sp, #0x30                              
02cf3bdc: stp     x30, x21, [sp, #0x10]                      
02cf3be0: stp     x20, x19, [sp, #0x20]                      
02cf3be4: adrp    x20, #0x662f000                            
02cf3be8: adrp    x19, #0x6266000                            
02cf3bec: ldrb    w8, [x20, #0xe79]                          
02cf3bf0: ldr     x19, [x19, #0x128]                         T:System.DateTime
02cf3bf4: tbnz    w8, #0, #0x2cf3c24                         
02cf3bf8: adrp    x0, #0x6266000                             
02cf3bfc: ldr     x0, [x0, #0x128]                           T:System.DateTime
02cf3c00: bl      #0x2b70db0                                 fn_2b70db0
02cf3c04: adrp    x0, #0x6266000                             
02cf3c08: ldr     x0, [x0, #0x810]                           S:'o'
02cf3c0c: bl      #0x2b70db0                                 fn_2b70db0
02cf3c10: adrp    x0, #0x6268000                             
02cf3c14: ldr     x0, [x0, #0x6c0]                           S:'LastLoginDate'
02cf3c18: bl      #0x2b70db0                                 fn_2b70db0
02cf3c1c: mov     w8, #1                                     
02cf3c20: strb    w8, [x20, #0xe79]                          
02cf3c24: ldr     x0, [x19]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cf3c28: adrp    x20, #0x6266000                            
02cf3c2c: adrp    x21, #0x6268000                            
02cf3c30: ldr     x20, [x20, #0x810]                         S:'o'
02cf3c34: ldr     w8, [x0, #0xe4]                            [62680e4]=0 f=0,0
02cf3c38: ldr     x21, [x21, #0x6c0]                         S:'LastLoginDate'
02cf3c3c: stp     xzr, xzr, [sp]                             
02cf3c40: cbnz    w8, #0x2cf3c48                             
02cf3c44: bl      #0x2b70f30                                 fn_2b70f30
02cf3c48: mov     x0, xzr                                    
02cf3c4c: bl      #0x4df285c                                 System.DateTime::get_Today
02cf3c50: fmov    d0, #-1.00000000                           
02cf3c54: str     x0, [sp]                                   
02cf3c58: mov     x0, sp                                     
02cf3c5c: mov     x1, xzr                                    
02cf3c60: bl      #0x4df0f9c                                 System.DateTime::AddDays
02cf3c64: ldr     x1, [x20]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cf3c68: str     x0, [sp]                                   
02cf3c6c: mov     x0, sp                                     
02cf3c70: mov     x2, xzr                                    
02cf3c74: bl      #0x4df35b0                                 System.DateTime::ToString
02cf3c78: ldr     x8, [x21]                                  S:'{0}/2'
02cf3c7c: mov     x1, x0                                     
02cf3c80: mov     x2, xzr                                    
02cf3c84: mov     x0, x8                                     
02cf3c88: bl      #0x5b2d3f0                                 UnityEngine.PlayerPrefs::GetString
02cf3c8c: ldr     x1, [x20]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cf3c90: add     x4, sp, #8                                 
02cf3c94: mov     x2, xzr                                    
02cf3c98: mov     w3, wzr                                    
02cf3c9c: mov     x5, xzr                                    
02cf3ca0: bl      #0x4df3b04                                 System.DateTime::TryParseExact
02cf3ca4: tbz     w0, #0, #0x2cf3cb0                         
02cf3ca8: ldr     x0, [sp, #8]                               
02cf3cac: b       #0x2cf3cdc                                 
02cf3cb0: ldr     x0, [x19]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cf3cb4: ldr     w8, [x0, #0xe4]                            [62680e4]=0 f=0,0
02cf3cb8: cbnz    w8, #0x2cf3cc0                             
02cf3cbc: bl      #0x2b70f30                                 fn_2b70f30
02cf3cc0: mov     x0, xzr                                    
02cf3cc4: bl      #0x4df285c                                 System.DateTime::get_Today
02cf3cc8: fmov    d0, #-1.00000000                           
02cf3ccc: str     x0, [sp]                                   
02cf3cd0: mov     x0, sp                                     
02cf3cd4: mov     x1, xzr                                    
02cf3cd8: bl      #0x4df0f9c                                 System.DateTime::AddDays
02cf3cdc: ldp     x20, x19, [sp, #0x20]                      
02cf3ce0: ldp     x30, x21, [sp, #0x10]                      
02cf3ce4: add     sp, sp, #0x30                              
02cf3ce8: ret                                                
## GetLoginDayIndex() -> int
---- DailyReward.DailyLoginController::GetLoginDayIndex 0x2cf3b90
02cf3b90: str     x30, [sp, #-0x20]!                         
02cf3b94: stp     x20, x19, [sp, #0x10]                      
02cf3b98: adrp    x19, #0x662f000                            
02cf3b9c: adrp    x20, #0x6268000                            
02cf3ba0: ldrb    w8, [x19, #0xe7a]                          
02cf3ba4: ldr     x20, [x20, #0x6b8]                         S:'DayIndex'
02cf3ba8: tbnz    w8, #0, #0x2cf3bc0                         
02cf3bac: adrp    x0, #0x6268000                             
02cf3bb0: ldr     x0, [x0, #0x6b8]                           S:'DayIndex'
02cf3bb4: bl      #0x2b70db0                                 fn_2b70db0
02cf3bb8: mov     w8, #1                                     
02cf3bbc: strb    w8, [x19, #0xe7a]                          
02cf3bc0: ldr     x0, [x20]                                  S:'{0}/2'
02cf3bc4: ldp     x20, x19, [sp, #0x10]                      
02cf3bc8: mov     w1, wzr                                    
02cf3bcc: mov     x2, xzr                                    
02cf3bd0: ldr     x30, [sp], #0x20                           
02cf3bd4: b       #0x5b2d1dc                                 UnityEngine.PlayerPrefs::GetInt
## SaveLoginData() -> void
---- DailyReward.DailyLoginController::SaveLoginData 0x2cf3cec
02cf3cec: sub     sp, sp, #0x30                              
02cf3cf0: stp     x30, x21, [sp, #0x10]                      
02cf3cf4: stp     x20, x19, [sp, #0x20]                      
02cf3cf8: adrp    x20, #0x662f000                            
02cf3cfc: adrp    x19, #0x6266000                            
02cf3d00: ldrb    w8, [x20, #0xe7b]                          
02cf3d04: ldr     x19, [x19, #0x128]                         T:System.DateTime
02cf3d08: tbnz    w8, #0, #0x2cf3d44                         
02cf3d0c: adrp    x0, #0x6266000                             
02cf3d10: ldr     x0, [x0, #0x128]                           T:System.DateTime
02cf3d14: bl      #0x2b70db0                                 fn_2b70db0
02cf3d18: adrp    x0, #0x6266000                             
02cf3d1c: ldr     x0, [x0, #0x810]                           S:'o'
02cf3d20: bl      #0x2b70db0                                 fn_2b70db0
02cf3d24: adrp    x0, #0x6268000                             
02cf3d28: ldr     x0, [x0, #0x6b8]                           S:'DayIndex'
02cf3d2c: bl      #0x2b70db0                                 fn_2b70db0
02cf3d30: adrp    x0, #0x6268000                             
02cf3d34: ldr     x0, [x0, #0x6c0]                           S:'LastLoginDate'
02cf3d38: bl      #0x2b70db0                                 fn_2b70db0
02cf3d3c: mov     w8, #1                                     
02cf3d40: strb    w8, [x20, #0xe7b]                          
02cf3d44: ldr     x0, [x19]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cf3d48: adrp    x21, #0x6266000                            
02cf3d4c: adrp    x20, #0x6268000                            
02cf3d50: adrp    x19, #0x6268000                            
02cf3d54: ldr     x21, [x21, #0x810]                         S:'o'
02cf3d58: ldr     x20, [x20, #0x6c0]                         S:'LastLoginDate'
02cf3d5c: ldr     w8, [x0, #0xe4]                            [62680e4]=0 f=0,0
02cf3d60: ldr     x19, [x19, #0x6b8]                         S:'DayIndex'
02cf3d64: str     xzr, [sp, #8]                              
02cf3d68: cbnz    w8, #0x2cf3d70                             
02cf3d6c: bl      #0x2b70f30                                 fn_2b70f30
02cf3d70: mov     x0, xzr                                    
02cf3d74: bl      #0x4df285c                                 System.DateTime::get_Today
02cf3d78: ldr     x1, [x21]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cf3d7c: str     x0, [sp, #8]                               
02cf3d80: add     x0, sp, #8                                 
02cf3d84: mov     x2, xzr                                    
02cf3d88: bl      #0x4df35b0                                 System.DateTime::ToString
02cf3d8c: ldr     x8, [x20]                                  S:'{0}/2'
02cf3d90: mov     x1, x0                                     
02cf3d94: mov     x2, xzr                                    
02cf3d98: mov     x0, x8                                     
02cf3d9c: bl      #0x5b2d398                                 UnityEngine.PlayerPrefs::SetString
02cf3da0: bl      #0x2cf3b90                                 DailyReward.DailyLoginController::GetLoginDayIndex
02cf3da4: ldr     x8, [x19]                                  S:'{0}/2'
02cf3da8: add     w1, w0, #1                                 
02cf3dac: mov     x2, xzr                                    
02cf3db0: mov     x0, x8                                     
02cf3db4: bl      #0x5b2d184                                 UnityEngine.PlayerPrefs::SetInt
02cf3db8: mov     x0, xzr                                    
02cf3dbc: bl      #0x5b2d914                                 UnityEngine.PlayerPrefs::Save
02cf3dc0: ldp     x20, x19, [sp, #0x20]                      
02cf3dc4: ldp     x30, x21, [sp, #0x10]                      
02cf3dc8: add     sp, sp, #0x30                              
02cf3dcc: ret                                                
## .ctor() -> void
---- DailyReward.DailyLoginController::.ctor 0x2cf3dd0
02cf3dd0: mov     x1, xzr                                    
02cf3dd4: b       #0x5b397b0                                 UnityEngine.MonoBehaviour::.ctor
