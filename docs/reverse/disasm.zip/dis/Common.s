#### CLASS Common parent= object
## Log(object message) -> void
---- Common::Log 0x2cdb63c
02cdb63c: stp     x30, x21, [sp, #-0x20]!                    
02cdb640: stp     x20, x19, [sp, #0x10]                      
02cdb644: adrp    x20, #0x662f000                            
02cdb648: adrp    x21, #0x6263000                            
02cdb64c: mov     x19, x0                                    
02cdb650: ldrb    w8, [x20, #0xd60]                          
02cdb654: ldr     x21, [x21, #0x928]                         T:UnityEngine.Debug
02cdb658: tbnz    w8, #0, #0x2cdb670                         
02cdb65c: adrp    x0, #0x6263000                             
02cdb660: ldr     x0, [x0, #0x928]                           T:UnityEngine.Debug
02cdb664: bl      #0x2b70db0                                 fn_2b70db0
02cdb668: mov     w8, #1                                     
02cdb66c: strb    w8, [x20, #0xd60]                          
02cdb670: ldr     x0, [x21]                                  &2c5bbd4(=a9bd7bfdd503233f)
02cdb674: ldr     w8, [x0, #0xe4]                            [62630e4]=0 f=0,0
02cdb678: cbnz    w8, #0x2cdb680                             
02cdb67c: bl      #0x2b70f30                                 fn_2b70f30
02cdb680: mov     x0, x19                                    
02cdb684: ldp     x20, x19, [sp, #0x10]                      
02cdb688: mov     x1, xzr                                    
02cdb68c: ldp     x30, x21, [sp], #0x20                      
02cdb690: b       #0x5af21f4                                 UnityEngine.Debug::Log
## Log(string format, object[] args) -> void
---- Common::Log 0x2cdb694
02cdb694: str     x30, [sp, #-0x30]!                         
02cdb698: stp     x22, x21, [sp, #0x10]                      
02cdb69c: stp     x20, x19, [sp, #0x20]                      
02cdb6a0: adrp    x22, #0x662f000                            
02cdb6a4: adrp    x21, #0x6263000                            
02cdb6a8: mov     x19, x1                                    
02cdb6ac: ldrb    w8, [x22, #0xd61]                          
02cdb6b0: ldr     x21, [x21, #0x928]                         T:UnityEngine.Debug
02cdb6b4: mov     x20, x0                                    
02cdb6b8: tbnz    w8, #0, #0x2cdb6d0                         
02cdb6bc: adrp    x0, #0x6263000                             
02cdb6c0: ldr     x0, [x0, #0x928]                           T:UnityEngine.Debug
02cdb6c4: bl      #0x2b70db0                                 fn_2b70db0
02cdb6c8: mov     w8, #1                                     
02cdb6cc: strb    w8, [x22, #0xd61]                          
02cdb6d0: mov     x0, x20                                    
02cdb6d4: mov     x1, x19                                    
02cdb6d8: mov     x2, xzr                                    
02cdb6dc: bl      #0x4ca77a8                                 System.String::Format
02cdb6e0: ldr     x8, [x21]                                  &2c5bbd4(=a9bd7bfdd503233f)
02cdb6e4: mov     x19, x0                                    
02cdb6e8: ldr     w9, [x8, #0xe4]                            
02cdb6ec: cbnz    w9, #0x2cdb6f8                             
02cdb6f0: mov     x0, x8                                     
02cdb6f4: bl      #0x2b70f30                                 fn_2b70f30
02cdb6f8: mov     x0, x19                                    
02cdb6fc: ldp     x20, x19, [sp, #0x20]                      
02cdb700: ldp     x22, x21, [sp, #0x10]                      
02cdb704: mov     x1, xzr                                    
02cdb708: ldr     x30, [sp], #0x30                           
02cdb70c: b       #0x5af21f4                                 UnityEngine.Debug::Log
## LogWarning(object message, UnityEngine.Object context) -> void
---- Common::LogWarning 0x2cdb710
02cdb710: str     x30, [sp, #-0x30]!                         
02cdb714: stp     x22, x21, [sp, #0x10]                      
02cdb718: stp     x20, x19, [sp, #0x20]                      
02cdb71c: adrp    x21, #0x662f000                            
02cdb720: adrp    x22, #0x6263000                            
02cdb724: mov     x19, x1                                    
02cdb728: ldrb    w8, [x21, #0xd62]                          
02cdb72c: ldr     x22, [x22, #0x928]                         T:UnityEngine.Debug
02cdb730: mov     x20, x0                                    
02cdb734: tbnz    w8, #0, #0x2cdb74c                         
02cdb738: adrp    x0, #0x6263000                             
02cdb73c: ldr     x0, [x0, #0x928]                           T:UnityEngine.Debug
02cdb740: bl      #0x2b70db0                                 fn_2b70db0
02cdb744: mov     w8, #1                                     
02cdb748: strb    w8, [x21, #0xd62]                          
02cdb74c: ldr     x0, [x22]                                  &2c5bbd4(=a9bd7bfdd503233f)
02cdb750: ldr     w8, [x0, #0xe4]                            [62630e4]=0 f=0,0
02cdb754: cbnz    w8, #0x2cdb75c                             
02cdb758: bl      #0x2b70f30                                 fn_2b70f30
02cdb75c: mov     x0, x20                                    
02cdb760: mov     x1, x19                                    
02cdb764: mov     x2, xzr                                    
02cdb768: ldp     x20, x19, [sp, #0x20]                      
02cdb76c: ldp     x22, x21, [sp, #0x10]                      
02cdb770: ldr     x30, [sp], #0x30                           
02cdb774: b       #0x5af2d9c                                 UnityEngine.Debug::LogWarning
## LogWarning(UnityEngine.Object context, string format, object[] args) -> void
---- Common::LogWarning 0x2cdb778
02cdb778: stp     x30, x23, [sp, #-0x30]!                    
02cdb77c: stp     x22, x21, [sp, #0x10]                      
02cdb780: stp     x20, x19, [sp, #0x20]                      
02cdb784: adrp    x23, #0x662f000                            
02cdb788: adrp    x22, #0x6263000                            
02cdb78c: mov     x20, x2                                    
02cdb790: ldrb    w8, [x23, #0xd63]                          
02cdb794: ldr     x22, [x22, #0x928]                         T:UnityEngine.Debug
02cdb798: mov     x21, x1                                    
02cdb79c: mov     x19, x0                                    
02cdb7a0: tbnz    w8, #0, #0x2cdb7b8                         
02cdb7a4: adrp    x0, #0x6263000                             
02cdb7a8: ldr     x0, [x0, #0x928]                           T:UnityEngine.Debug
02cdb7ac: bl      #0x2b70db0                                 fn_2b70db0
02cdb7b0: mov     w8, #1                                     
02cdb7b4: strb    w8, [x23, #0xd63]                          
02cdb7b8: mov     x0, x21                                    
02cdb7bc: mov     x1, x20                                    
02cdb7c0: mov     x2, xzr                                    
02cdb7c4: bl      #0x4ca77a8                                 System.String::Format
02cdb7c8: ldr     x8, [x22]                                  &2c5bbd4(=a9bd7bfdd503233f)
02cdb7cc: mov     x20, x0                                    
02cdb7d0: ldr     w9, [x8, #0xe4]                            
02cdb7d4: cbnz    w9, #0x2cdb7e0                             
02cdb7d8: mov     x0, x8                                     
02cdb7dc: bl      #0x2b70f30                                 fn_2b70f30
02cdb7e0: mov     x0, x20                                    
02cdb7e4: mov     x1, x19                                    
02cdb7e8: mov     x2, xzr                                    
02cdb7ec: ldp     x20, x19, [sp, #0x20]                      
02cdb7f0: ldp     x22, x21, [sp, #0x10]                      
02cdb7f4: ldp     x30, x23, [sp], #0x30                      
02cdb7f8: b       #0x5af2d9c                                 UnityEngine.Debug::LogWarning
## Warning(bool condition, object message) -> void
---- Common::Warning 0x2cdb7fc
02cdb7fc: stp     x30, x21, [sp, #-0x20]!                    
02cdb800: stp     x20, x19, [sp, #0x10]                      
02cdb804: adrp    x21, #0x662f000                            
02cdb808: mov     x19, x1                                    
02cdb80c: mov     w20, w0                                    
02cdb810: ldrb    w8, [x21, #0xd64]                          
02cdb814: tbnz    w8, #0, #0x2cdb82c                         
02cdb818: adrp    x0, #0x6263000                             
02cdb81c: ldr     x0, [x0, #0x928]                           T:UnityEngine.Debug
02cdb820: bl      #0x2b70db0                                 fn_2b70db0
02cdb824: mov     w8, #1                                     
02cdb828: strb    w8, [x21, #0xd64]                          
02cdb82c: tbz     w20, #0, #0x2cdb83c                        
02cdb830: ldp     x20, x19, [sp, #0x10]                      
02cdb834: ldp     x30, x21, [sp], #0x20                      
02cdb838: ret                                                
02cdb83c: adrp    x8, #0x6263000                             
02cdb840: ldr     x8, [x8, #0x928]                           T:UnityEngine.Debug
02cdb844: ldr     x0, [x8]                                   &2c5bbd4(=a9bd7bfdd503233f)
02cdb848: ldr     w8, [x0, #0xe4]                            [62630e4]=0 f=0,0
02cdb84c: cbnz    w8, #0x2cdb854                             
02cdb850: bl      #0x2b70f30                                 fn_2b70f30
02cdb854: mov     x0, x19                                    
02cdb858: ldp     x20, x19, [sp, #0x10]                      
02cdb85c: mov     x1, xzr                                    
02cdb860: ldp     x30, x21, [sp], #0x20                      
02cdb864: b       #0x5af2c94                                 UnityEngine.Debug::LogWarning
## Warning(bool condition, object message, UnityEngine.Object context) -> void
---- Common::Warning 0x2cdb868
02cdb868: str     x30, [sp, #-0x30]!                         
02cdb86c: stp     x22, x21, [sp, #0x10]                      
02cdb870: stp     x20, x19, [sp, #0x20]                      
02cdb874: adrp    x22, #0x662f000                            
02cdb878: mov     x19, x2                                    
02cdb87c: mov     x20, x1                                    
02cdb880: ldrb    w8, [x22, #0xd65]                          
02cdb884: mov     w21, w0                                    
02cdb888: tbnz    w8, #0, #0x2cdb8a0                         
02cdb88c: adrp    x0, #0x6263000                             
02cdb890: ldr     x0, [x0, #0x928]                           T:UnityEngine.Debug
02cdb894: bl      #0x2b70db0                                 fn_2b70db0
02cdb898: mov     w8, #1                                     
02cdb89c: strb    w8, [x22, #0xd65]                          
02cdb8a0: tbz     w21, #0, #0x2cdb8b4                        
02cdb8a4: ldp     x20, x19, [sp, #0x20]                      
02cdb8a8: ldp     x22, x21, [sp, #0x10]                      
02cdb8ac: ldr     x30, [sp], #0x30                           
02cdb8b0: ret                                                
02cdb8b4: adrp    x8, #0x6263000                             
02cdb8b8: ldr     x8, [x8, #0x928]                           T:UnityEngine.Debug
02cdb8bc: ldr     x0, [x8]                                   &2c5bbd4(=a9bd7bfdd503233f)
02cdb8c0: ldr     w8, [x0, #0xe4]                            [62630e4]=0 f=0,0
02cdb8c4: cbnz    w8, #0x2cdb8cc                             
02cdb8c8: bl      #0x2b70f30                                 fn_2b70f30
02cdb8cc: mov     x0, x20                                    
02cdb8d0: mov     x1, x19                                    
02cdb8d4: mov     x2, xzr                                    
02cdb8d8: ldp     x20, x19, [sp, #0x20]                      
02cdb8dc: ldp     x22, x21, [sp, #0x10]                      
02cdb8e0: ldr     x30, [sp], #0x30                           
02cdb8e4: b       #0x5af2d9c                                 UnityEngine.Debug::LogWarning
## Warning(bool condition, UnityEngine.Object context, string format, object[] args) -> void
---- Common::Warning 0x2cdb8e8
02cdb8e8: stp     x30, x23, [sp, #-0x30]!                    
02cdb8ec: stp     x22, x21, [sp, #0x10]                      
02cdb8f0: stp     x20, x19, [sp, #0x20]                      
02cdb8f4: adrp    x23, #0x662f000                            
02cdb8f8: mov     x20, x3                                    
02cdb8fc: mov     x21, x2                                    
02cdb900: ldrb    w8, [x23, #0xd66]                          
02cdb904: mov     x19, x1                                    
02cdb908: mov     w22, w0                                    
02cdb90c: tbnz    w8, #0, #0x2cdb924                         
02cdb910: adrp    x0, #0x6263000                             
02cdb914: ldr     x0, [x0, #0x928]                           T:UnityEngine.Debug
02cdb918: bl      #0x2b70db0                                 fn_2b70db0
02cdb91c: mov     w8, #1                                     
02cdb920: strb    w8, [x23, #0xd66]                          
02cdb924: tbz     w22, #0, #0x2cdb938                        
02cdb928: ldp     x20, x19, [sp, #0x20]                      
02cdb92c: ldp     x22, x21, [sp, #0x10]                      
02cdb930: ldp     x30, x23, [sp], #0x30                      
02cdb934: ret                                                
02cdb938: adrp    x22, #0x6263000                            
02cdb93c: mov     x0, x21                                    
02cdb940: mov     x1, x20                                    
02cdb944: ldr     x22, [x22, #0x928]                         T:UnityEngine.Debug
02cdb948: mov     x2, xzr                                    
02cdb94c: bl      #0x4ca77a8                                 System.String::Format
02cdb950: ldr     x8, [x22]                                  &2c5bbd4(=a9bd7bfdd503233f)
02cdb954: mov     x20, x0                                    
02cdb958: ldr     w9, [x8, #0xe4]                            
02cdb95c: cbnz    w9, #0x2cdb968                             
02cdb960: mov     x0, x8                                     
02cdb964: bl      #0x2b70f30                                 fn_2b70f30
02cdb968: mov     x0, x20                                    
02cdb96c: mov     x1, x19                                    
02cdb970: mov     x2, xzr                                    
02cdb974: ldp     x20, x19, [sp, #0x20]                      
02cdb978: ldp     x22, x21, [sp, #0x10]                      
02cdb97c: ldp     x30, x23, [sp], #0x30                      
02cdb980: b       #0x5af2d9c                                 UnityEngine.Debug::LogWarning
## Assert(bool condition) -> void
---- Common::Assert 0x2cdb984
02cdb984: tbz     w0, #0, #0x2cdb98c                         
02cdb988: ret                                                
02cdb98c: stp     x30, x19, [sp, #-0x10]!                    
02cdb990: adrp    x0, #0x6267000                             
02cdb994: ldr     x0, [x0, #0xc08]                           T:UnityEngine.UnityException
02cdb998: bl      #0x2b70dc4                                 fn_2b70dc4
02cdb99c: bl      #0x2b7104c                                 fn_2b7104c
02cdb9a0: mov     x1, xzr                                    
02cdb9a4: mov     x19, x0                                    
02cdb9a8: bl      #0x5b3a840                                 UnityEngine.UnityException::.ctor
02cdb9ac: adrp    x0, #0x6267000                             
02cdb9b0: ldr     x0, [x0, #0xc10]                           M:Common::Assert
02cdb9b4: bl      #0x2b70dc4                                 fn_2b70dc4
02cdb9b8: mov     x1, x0                                     
02cdb9bc: mov     x0, x19                                    
02cdb9c0: bl      #0x2b70f20                                 fn_2b70f20
## Assert(bool condition, string message) -> void
---- Common::Assert 0x2cdb9c4
02cdb9c4: tbz     w0, #0, #0x2cdb9cc                         
02cdb9c8: ret                                                
02cdb9cc: str     x30, [sp, #-0x20]!                         
02cdb9d0: stp     x20, x19, [sp, #0x10]                      
02cdb9d4: adrp    x0, #0x6267000                             
02cdb9d8: mov     x19, x1                                    
02cdb9dc: ldr     x0, [x0, #0xc08]                           T:UnityEngine.UnityException
02cdb9e0: bl      #0x2b70dc4                                 fn_2b70dc4
02cdb9e4: bl      #0x2b7104c                                 fn_2b7104c
02cdb9e8: mov     x1, x19                                    
02cdb9ec: mov     x2, xzr                                    
02cdb9f0: mov     x20, x0                                    
02cdb9f4: bl      #0x5b38298                                 UnityEngine.UnityException::.ctor
02cdb9f8: adrp    x0, #0x6267000                             
02cdb9fc: ldr     x0, [x0, #0xc18]                           M:Common::Assert
02cdba00: bl      #0x2b70dc4                                 fn_2b70dc4
02cdba04: mov     x1, x0                                     
02cdba08: mov     x0, x20                                    
02cdba0c: bl      #0x2b70f20                                 fn_2b70f20
## Assert(bool condition, string format, object[] args) -> void
---- Common::Assert 0x2cdba10
02cdba10: tbz     w0, #0, #0x2cdba18                         
02cdba14: ret                                                
02cdba18: str     x30, [sp, #-0x20]!                         
02cdba1c: stp     x20, x19, [sp, #0x10]                      
02cdba20: mov     x0, x1                                     
02cdba24: mov     x1, x2                                     
02cdba28: mov     x2, xzr                                    
02cdba2c: bl      #0x4ca77a8                                 System.String::Format
02cdba30: mov     x19, x0                                    
02cdba34: adrp    x0, #0x6267000                             
02cdba38: ldr     x0, [x0, #0xc08]                           T:UnityEngine.UnityException
02cdba3c: bl      #0x2b70dc4                                 fn_2b70dc4
02cdba40: bl      #0x2b7104c                                 fn_2b7104c
02cdba44: mov     x1, x19                                    
02cdba48: mov     x2, xzr                                    
02cdba4c: mov     x20, x0                                    
02cdba50: bl      #0x5b38298                                 UnityEngine.UnityException::.ctor
02cdba54: adrp    x0, #0x6267000                             
02cdba58: ldr     x0, [x0, #0xc20]                           M:Common::Assert
02cdba5c: bl      #0x2b70dc4                                 fn_2b70dc4
02cdba60: mov     x1, x0                                     
02cdba64: mov     x0, x20                                    
02cdba68: bl      #0x2b70f20                                 fn_2b70f20
## .ctor() -> void
---- Common::.ctor 0x2cdba6c
02cdba6c: mov     x1, xzr                                    
02cdba70: b       #0x4e53e9c                                 System.Object::.ctor
