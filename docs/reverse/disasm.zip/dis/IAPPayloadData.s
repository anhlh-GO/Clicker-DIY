#### CLASS IAPPayloadData parent= object
#   field orderId                        string                                             off=0x10 attr=6 
#   field packageName                    string                                             off=0x18 attr=6 
#   field productId                      string                                             off=0x20 attr=6 
#   field purchaseTime                   long                                               off=0x28 attr=6 
#   field purchaseState                  int                                                off=0x30 attr=6 
#   field purchaseToken                  string                                             off=0x38 attr=6 
#   field quantity                       int                                                off=0x40 attr=6 
#   field acknowledged                   bool                                               off=0x44 attr=6 
## .ctor() -> void
---- IAPPayloadData::.ctor 0x2ca7f30
02ca7f30: mov     x1, xzr                                    
02ca7f34: b       #0x4e53e9c                                 System.Object::.ctor
