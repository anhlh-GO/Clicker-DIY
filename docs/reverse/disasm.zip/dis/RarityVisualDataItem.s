#### CLASS RarityVisualDataItem parent= object
#   field Rarity                         RarityType                                         off=0x10 attr=6 
#   field CircleGlow                     UnityEngine.Sprite                                 off=0x18 attr=6 
#   field Star                           UnityEngine.Sprite                                 off=0x20 attr=6 
#   field Panel                          UnityEngine.Sprite                                 off=0x28 attr=6 
## .ctor() -> void
---- RarityVisualDataItem::.ctor 0x2ce4f80
02ce4f80: mov     x1, xzr                                    
02ce4f84: b       #0x4e53e9c                                 System.Object::.ctor
