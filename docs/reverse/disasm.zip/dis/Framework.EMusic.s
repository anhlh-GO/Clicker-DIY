#### CLASS Framework.EMusic parent= int
#   field value__                        int                                                off=0x10 attr=606 
#   field None                           Framework.EMusic                                   off=0x0 attr=8056 
#   field bgm_home_1                     Framework.EMusic                                   off=0x0 attr=8056 
#   field bgm_home_2                     Framework.EMusic                                   off=0x0 attr=8056 
#   field bgm_home_3                     Framework.EMusic                                   off=0x0 attr=8056 
#   field bgm_ingame_1                   Framework.EMusic                                   off=0x0 attr=8056 
