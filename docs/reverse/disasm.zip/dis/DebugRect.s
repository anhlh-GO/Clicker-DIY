#### CLASS DebugRect parent= UnityEngine.MonoBehaviour
#   field debugText                      UnityEngine.UI.Text                                off=0x20 attr=6 
#   field rectTransform                  UnityEngine.RectTransform                          off=0x28 attr=6 
#   field borderColor                    UnityEngine.UI.Image                               off=0x30 attr=6 
## PlaceItselfAtScreenRect(UnityEngine.Rect screenRect, UnityEngine.Color color) -> void
---- DebugRect::PlaceItselfAtScreenRect 0x2c8675c
02c8675c: sub     sp, sp, #0x90                              
02c86760: stp     d15, d14, [sp, #0x20]                      
02c86764: stp     d13, d12, [sp, #0x30]                      
02c86768: stp     d11, d10, [sp, #0x40]                      
02c8676c: stp     d9, d8, [sp, #0x50]                        
02c86770: str     x30, [sp, #0x60]                           
02c86774: stp     x22, x21, [sp, #0x70]                      
02c86778: stp     x20, x19, [sp, #0x80]                      
02c8677c: fmov    s13, s7                                    
02c86780: fmov    s12, s6                                    
02c86784: adrp    x20, #0x662f000                            
02c86788: fmov    s14, s5                                    
02c8678c: fmov    s15, s4                                    
02c86790: ldrb    w8, [x20, #0x94e]                          
02c86794: fmov    s8, s3                                     
02c86798: fmov    s9, s2                                     
02c8679c: mov     x19, x0                                    
02c867a0: fmov    s10, s1                                    
02c867a4: fmov    s11, s0                                    
02c867a8: tbnz    w8, #0, #0x2c867e4                         
02c867ac: adrp    x0, #0x6264000                             
02c867b0: ldr     x0, [x0, #0xd88]                           MS:UnityEngine.Component::GetComponent
02c867b4: bl      #0x2b70db0                                 fn_2b70db0
02c867b8: adrp    x0, #0x6264000                             
02c867bc: ldr     x0, [x0, #0x790]                           T:UnityEngine.RectTransformUtility
02c867c0: bl      #0x2b70db0                                 fn_2b70db0
02c867c4: adrp    x0, #0x6264000                             
02c867c8: ldr     x0, [x0, #0x798]                           T:UnityEngine.Rect
02c867cc: bl      #0x2b70db0                                 fn_2b70db0
02c867d0: adrp    x0, #0x6264000                             
02c867d4: ldr     x0, [x0, #0xd90]                           S:'{0}'
02c867d8: bl      #0x2b70db0                                 fn_2b70db0
02c867dc: mov     w8, #1                                     
02c867e0: strb    w8, [x20, #0x94e]                          
02c867e4: fmul    s0, s15, s15                               
02c867e8: fmul    s1, s14, s14                               
02c867ec: adrp    x8, #0x1084000                             
02c867f0: ldr     x0, [x19, #0x30]                           .borderColor
02c867f4: str     xzr, [sp, #0x68]                           
02c867f8: str     xzr, [sp, #0x18]                           
02c867fc: fadd    s0, s0, s1                                 
02c86800: fmul    s1, s12, s12                               
02c86804: fadd    s0, s1, s0                                 
02c86808: fmul    s1, s13, s13                               
02c8680c: fadd    s0, s1, s0                                 
02c86810: ldr     s1, [x8, #0xbd0]                           [1084bd0]=3f6666662edbe6fe f=1e-10,0.9
02c86814: fcmp    s0, s1                                     
02c86818: b.pl    #0x2c8682c                                 
02c8681c: movi    d12, #0000000000000000                     
02c86820: movi    d14, #0000000000000000                     
02c86824: fmov    s13, #1.00000000                           
02c86828: fmov    s15, #1.00000000                           
02c8682c: cbz     x0, #0x2c869cc                             
02c86830: ldr     x8, [x0]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c86834: fmov    s0, s15                                    
02c86838: fmov    s1, s14                                    
02c8683c: fmov    s2, s12                                    
02c86840: fmov    s3, s13                                    
02c86844: ldr     x9, [x8, #0x2a8]                           [10842a8]=292633726f746365 f=7.56345e+28,3.6904e-14
02c86848: ldr     x1, [x8, #0x2b0]                           [10842b0]=6e457974696e5500 f=1.80079e+25,1.52788e+28
02c8684c: blr     x9                                         
02c86850: mov     x0, x19                                    
02c86854: mov     x1, xzr                                    
02c86858: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02c8685c: cbz     x0, #0x2c869cc                             
02c86860: mov     x1, xzr                                    
02c86864: bl      #0x5b466dc                                 UnityEngine.Transform::get_parent
02c86868: cbz     x0, #0x2c869cc                             
02c8686c: adrp    x8, #0x6264000                             
02c86870: adrp    x22, #0x6264000                            
02c86874: adrp    x21, #0x6264000                            
02c86878: ldr     x8, [x8, #0xd88]                           MS:UnityEngine.Component::GetComponent
02c8687c: ldr     x22, [x22, #0x798]                         T:UnityEngine.Rect
02c86880: ldr     x21, [x21, #0x790]                         T:UnityEngine.RectTransformUtility
02c86884: ldr     x1, [x8]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c86888: bl      #0x3140c84                                 fn_3140c84
02c8688c: ldr     x8, [x22]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c86890: mov     x20, x0                                    
02c86894: ldr     w9, [x8, #0xe4]                            [62640e4]=0 f=0,0
02c86898: cbnz    w9, #0x2c868a4                             
02c8689c: mov     x0, x8                                     
02c868a0: bl      #0x2b70f30                                 fn_2b70f30
02c868a4: mov     x0, xzr                                    
02c868a8: bl      #0x5aefe28                                 UnityEngine.Camera::get_main
02c868ac: ldr     x8, [x21]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c868b0: mov     x21, x0                                    
02c868b4: ldr     w9, [x8, #0xe4]                            [62640e4]=0 f=0,0
02c868b8: cbnz    w9, #0x2c868c4                             
02c868bc: mov     x0, x8                                     
02c868c0: bl      #0x2b70f30                                 fn_2b70f30
02c868c4: fmov    s0, s11                                    
02c868c8: fmov    s1, s10                                    
02c868cc: add     x2, sp, #0x68                              
02c868d0: mov     x0, x20                                    
02c868d4: mov     x1, x21                                    
02c868d8: mov     x3, xzr                                    
02c868dc: bl      #0x5e47a80                                 UnityEngine.RectTransformUtility::ScreenPointToLocalPointInRectangle
02c868e0: mov     x0, xzr                                    
02c868e4: bl      #0x5aefe28                                 UnityEngine.Camera::get_main
02c868e8: fmov    s0, s9                                     
02c868ec: fmov    s1, s8                                     
02c868f0: mov     x1, x0                                     
02c868f4: add     x2, sp, #0x18                              
02c868f8: mov     x0, x20                                    
02c868fc: mov     x3, xzr                                    
02c86900: bl      #0x5e47a80                                 UnityEngine.RectTransformUtility::ScreenPointToLocalPointInRectangle
02c86904: cbz     x20, #0x2c869cc                            
02c86908: adrp    x21, #0x6264000                            
02c8690c: mov     x0, x20                                    
02c86910: mov     x1, xzr                                    
02c86914: ldr     x21, [x21, #0xd90]                         S:'{0}'
02c86918: ldr     d12, [sp, #0x18]                           
02c8691c: bl      #0x5b458c8                                 UnityEngine.RectTransform::get_sizeDelta
02c86920: movi    v2.2s, #0x3f, lsl #24                      
02c86924: ldr     x0, [x22]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c86928: ldr     x20, [x19, #0x20]                          .debugText
02c8692c: mov     v0.s[1], v1.s[0]                           
02c86930: add     x1, sp, #8                                 
02c86934: stp     s11, s10, [sp, #8]                         
02c86938: stp     s9, s8, [sp, #0x10]                        
02c8693c: fmul    v0.2s, v0.2s, v2.2s                        
02c86940: fadd    v0.2s, v12.2s, v0.2s                       
02c86944: str     d0, [sp, #0x18]                            
02c86948: bl      #0x2b70f38                                 fn_2b70f38
02c8694c: ldr     x8, [x21]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c86950: mov     x1, x0                                     
02c86954: mov     x2, xzr                                    
02c86958: mov     x0, x8                                     
02c8695c: bl      #0x4c9d0ec                                 System.String::Format
02c86960: cbz     x20, #0x2c869cc                            
02c86964: ldr     x8, [x20]                                  &2b706c4(=eb01011ff9400808)
02c86968: mov     x1, x0                                     
02c8696c: mov     x0, x20                                    
02c86970: ldr     x9, [x8, #0x5e8]                           T:DG.Tweening.DOTweenModuleUI/<>c__DisplayClass29_0
02c86974: ldr     x2, [x8, #0x5f0]                           MS:DG.Tweening.TweenSettingsExtensions::OnUpdate
02c86978: blr     x9                                         
02c8697c: ldr     x0, [x19, #0x28]                           .rectTransform
02c86980: cbz     x0, #0x2c869cc                             
02c86984: movi    d2, #0000000000000000                      
02c86988: ldp     s0, s1, [sp, #0x68]                        
02c8698c: mov     x1, xzr                                    
02c86990: bl      #0x5b45cec                                 UnityEngine.Transform::set_localPosition
02c86994: ldr     x0, [x19, #0x28]                           .rectTransform
02c86998: cbz     x0, #0x2c869cc                             
02c8699c: ldp     s0, s1, [sp, #0x18]                        
02c869a0: mov     x1, xzr                                    
02c869a4: bl      #0x5b45994                                 UnityEngine.RectTransform::set_sizeDelta
02c869a8: ldp     x20, x19, [sp, #0x80]                      
02c869ac: ldr     x30, [sp, #0x60]                           
02c869b0: ldp     x22, x21, [sp, #0x70]                      
02c869b4: ldp     d9, d8, [sp, #0x50]                        
02c869b8: ldp     d11, d10, [sp, #0x40]                      
02c869bc: ldp     d13, d12, [sp, #0x30]                      
02c869c0: ldp     d15, d14, [sp, #0x20]                      
02c869c4: add     sp, sp, #0x90                              
02c869c8: ret                                                
02c869cc: bl      #0x2b7105c                                 fn_2b7105c
## .ctor() -> void
---- DebugRect::.ctor 0x2c869d0
02c869d0: mov     x1, xzr                                    
02c869d4: b       #0x5b397b0                                 UnityEngine.MonoBehaviour::.ctor
