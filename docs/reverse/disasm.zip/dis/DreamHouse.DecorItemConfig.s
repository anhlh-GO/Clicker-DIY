#### CLASS DreamHouse.DecorItemConfig parent= UnityEngine.ScriptableObject
#   field Icon                           UnityEngine.Sprite                                 off=0x18 attr=6 
#   field ItemPrefab                     UnityEngine.GameObject                             off=0x20 attr=6 
#   field Position                       UnityEngine.Vector3                                off=0x28 attr=6 
#   field UnlockType                     Games.Common.EUnlockType                           off=0x34 attr=6 
#   field Price                          int                                                off=0x38 attr=6 
## .ctor() -> void
---- DreamHouse.DecorItemConfig::.ctor 0x2d15904
02d15904: mov     x1, xzr                                    
02d15908: b       #0x5b398f0                                 UnityEngine.ScriptableObject::.ctor
